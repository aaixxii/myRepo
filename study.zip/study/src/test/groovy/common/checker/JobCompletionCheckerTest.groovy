package common.checker

class JobCompletionCheckerTest {

    void testWaitFeJobQueue() {
        def checker = new JobCompletionChecker()
        checker.waitFeJobsDone()
    }

}
