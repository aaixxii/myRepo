package common.callback
import groovy.util.GroovyTestCase

class ServiceCallbackServerTest extends GroovyTestCase {

    void testStartServer() {
        def print_arguments = { String payload -> println payload }
        def server = new ServiceCallbackServer(7777, print_arguments )
        // server.start()
        assert 1, 1
    }
}
