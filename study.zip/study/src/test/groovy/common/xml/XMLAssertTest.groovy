package common.xml
import groovy.util.GroovyTestCase

class XMLAssertTest extends GroovyTestCase {

    void testAssertXMLAbsolute() {
        def xml = '''
        <doc>
          <person name="yamada" age="30">taro</person>
          <person name="kitano" age="17">hanako</person>
        </doc>
        '''

        def xmlchecker = new XMLAssert(xml)
        def xpathValueMap = [
            "/doc/person[1]/@name": "hanako",
            "/doc/person[2]/@age": 17,
            "/doc/person[2]": "hanako" 
        ]
        xmlchecker.assertXML(xpathValueMap)
    }

    void testAssertXML() {
        def xml = '''
        <doc>
          <person name="yamada" age="30">taro</person>
          <person name="kitano" age="17">hanako</person>
        </doc>
        '''

        def xmlchecker = new XMLAssert(xml)
        def xpathValueMap = [
            "//person[1]/@name": "hanako",
            "//person[2]/@age": 17,
            "//person[2]": "hanako" 
        ]
        xmlchecker.assertXML(xpathValueMap)
    }


    void testAssertXMLAttribute() {
        def xml = '''
        <doc>
          <person name="yamada" age="30">taro</person>
          <person name="kitano" age="17">hanako</person>
        </doc>
        '''

        def xmlchecker = new XMLAssert(xml)
        def xpathValueMap = [
            "//person[@name='kitano']/@age": 17,
        ]
        xmlchecker.assertXML(xpathValueMap)
    }

    void testAssertXMLElement() {
        println "testAssertXMLElement"
        def xml = '''
        <doc>
           <canditate>
             <extid name="nawata">1</extid>
             <score>100</score>
           </canditate>
           <canditate>
             <extid>2</extid>
             <score>200</score>
           </canditate>
        </doc>
        '''

        def xmlchecker = new XMLAssert(xml)
        def xpathValueMap = [
            "//canditate[extid/@name='nawata']/score": 100,
            "//canditate[extid='2']/score": 200,
        ]
        xmlchecker.assertXML(xpathValueMap)
    }

    void testNamespace() {
        def xml = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<ns2:search-job-result jobId="152" xmlns:ns2="urn:nec:aim">
    <statistics>
        <readCount>3</readCount><matchCount>3</matchCount>
    </statistics>
    <candidate hit="true">
        <externalId>sample_slap-00001</externalId>
        <fusion-score>9999</fusion-score>
        <candidate-template>
            <containerId>2</containerId>
            <eventId>0</eventId>
            <searchRequestIndex>0</searchRequestIndex>
            <composite-score>9999</composite-score>
            <individual-score axis="A" fingerNumber="1" value="9999"/>
            <individual-score axis="A" fingerNumber="2" value="9999"/>
        </candidate-template>
    </candidate>
    <candidate hit="true">
        <externalId>sample_slap-00002</externalId>
        <fusion-score>9999</fusion-score>
        <candidate-template>
            <containerId>4</containerId>
            <eventId>0</eventId>
            <searchRequestIndex>0</searchRequestIndex>
            <composite-score>9999</composite-score>
            <individual-score axis="A" fingerNumber="1" value="9999"/>
            <individual-score axis="A" fingerNumber="2" value="9999"/>
        </candidate-template>
    </candidate>

</ns2:search-job-result>
'''
        def xmlchecker = new XMLAssert(xml)
        xmlchecker.registerNamespace("ns2","urn:nec:aim")
        def xpathValueMap = [
            "/ns2:search-job-result/candidate[externalId='sample_slap-00001']/fusion-score": 9999,
            "//candidate[externalId='sample_slap-00002']/fusion-score": 9999,
        ]
        xmlchecker.assertXML(xpathValueMap)
    }
}
