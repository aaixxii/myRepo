package test.vx.assertion.testcase.searchresult


import test.degrade.util.SoapuiObject;
import test.vx.assertion.verify.intface.VerifyResponseAssertorIF;
import test.vx.assertion.verify.procedure.VerifyAssertionExecutor
import test.vx.assertion.verify.response.VerifyResponseAssertor
import test.vx.xml.response.factory.VerifyResponseFactory;
import test.vx.xml.response.holder.VerifyResponse;

class SearchResultAssertor {
	SoapuiObject soapuiObject
	VerifyAssertionExecutor assertionExecutor
	String testPatternName
	String eventId = "0" // initial setting 0 for IZUMI test case
	String externalId
	String testResultMessg
	String modal
	String outputXmlLabelName = ""
	int position
	int pairLimit
	boolean success = true
	double score
	
	SearchResultAssertor(def context){
		this.soapuiObject = new SoapuiObject(context)
		this.assertionExecutor = new VerifyAssertionExecutor(context)
	}
	
	public void assertion(String responseXml){
		List expectedResValList = make1to1ResponseValList()
		VerifyResponse expectedResponse = VerifyResponseFactory.createFromList(expectedResValList)
		execAssertion(responseXml, expectedResponse)
	}

	public void assertionOne2Few(String responseXml, List expectedResValList){
		VerifyResponse expectedResponse = VerifyResponseFactory.createFromList(expectedResValList)
		execAssertion(responseXml, expectedResponse)
	}
	
	private execAssertion(String responseXml, VerifyResponse expectedResponse) {
		VerifyResponseAssertor responseAssertor = new VerifyResponseAssertor(soapuiObject.getContext())
		setToResponseAssertor(responseAssertor, expectedResponse)
		execute(responseXml, responseAssertor)
	}

	private execute(String responseXml, VerifyResponseAssertorIF responseAssertor) {
		assertionExecutor.setTargetXml(responseXml)
		assertionExecutor.setTestPatternName(testPatternName)
		assertionExecutor.setTestResultMessg(testResultMessg)
		assertionExecutor.setOutputXmlNameLabel(outputXmlLabelName)
		assertionExecutor.setVerifyResponseAssertor(responseAssertor)
		assertionExecutor.execute()
	}

	private setToResponseAssertor(VerifyResponseAssertor responseAssertor, VerifyResponse expectedResponse) {
		responseAssertor.setExpectedResponse(expectedResponse)
		responseAssertor.setPairLimit(pairLimit)
		responseAssertor.setTestName(testPatternName)
	}
	
	private List make1to1ResponseValList(){
		return [ [ eventId, externalId, score, [ [ score, [ [ [[]], position, score ] ], modal ], ], success ] ]
	}
	
	private List make1toFewRequestValList(){
		/****
		List fPramListVal = [
								[  "extId1", 
									[ 
										[ 32, [ [ [ 1, "JJ", 100, 200, 500, true], [ 2, "KK", 10, 22, 33, false] ], "RAW", "modal", 1 ]  ],
										[ 8, [ [ [ 47, "JJ", 512, 512, 500, true], [ 2, "KK", 800, 768, 33, false] ], "RAW", "modal", 2 ] ]
									] 
								],
								[  "extId2", 
									[ 
										[ 32, [ [ [ 1, "JJ", 100, 200, 500, true], [ 2, "KK", 10, 22, 33, false] ], "RAW", "modal", 4 ]  ],
										[ 8, [ [ [ 47, "JJ", 512, 512, 500, true], [ 2, "KK", 800, 768, 33, false] ], "RAW", "modal", 3 ] ]
									] 
								]
							]
		 */
		return null
	}
}
