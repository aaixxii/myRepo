package test.vx.assertion.verify.response

import test.common.message.MessageCreator
import test.degrade.management.AbendProcessor
import test.degrade.util.SoapuiObject
import test.vx.assertion.verify.intface.VerifyResponseAssertorIF
import test.vx.xml.response.factory.VerifyResponseFactory;
import test.vx.xml.response.holder.CandidateResultList;
import test.vx.xml.response.holder.IndividualScoreList;
import test.vx.xml.response.holder.ModalScoreList;
import test.vx.xml.response.holder.PairList
import test.vx.xml.response.holder.StatusList
import test.vx.xml.response.holder.VerifyResponse;

class VerifyResponsePtestAssertor implements VerifyResponseAssertorIF{
	SoapuiObject soapuiObject
	String testName
	boolean isScore0 = false
	String mateExternalId
	String mateExtIdFScore
	
	public VerifyResponsePtestAssertor(def context){
		this.soapuiObject = new SoapuiObject(context)
	}
	
	public void assertion(String verifyResponseStr){
		VerifyResponse actualResponse = VerifyResponseFactory.create(verifyResponseStr)
		List<CandidateResultList> canResultListList = actualResponse.getCandidateResultListList()
		assertCandidateResultListValues(canResultListList)
		
		
	}

	private void assertCandidateResultListValues(List canResultListList) {
		for(i in 0..canResultListList.size()-1){
			CandidateResultList canResultList = canResultListList[i]
			String externalId = canResultList.getExternalId()
			String fusionScore = canResultList.getFusionScore()
			if(externalId == mateExternalId){
				assertEquals(fusionScore, mateExtIdFScore, "fusionScore")
			}else{
				assertLessThan((fusionScore as double) as int, 15, "fusionScore")
			}
			assertEquals(canResultList.getSuccess(), true, "sucess")
		}
	}

	private updateIsScore0(double score) {
		if(score <= 0){
			isScore0 = true
		}else{
			isScore0 = false
		}
	}

	private void assertEquals(def actual, def expected, String propName){
		if(actual != expected) {
			abendTest(expected, actual, propName)
		}
	}
	
	private void assertLessThan(int actual, int limit, String propName){
		if(limit < actual) {
			abendTest("bigger than $limit", actual, propName)
		}
	}
	
	private void assertLimit(int actual, int min, int max, String propName){
		if(actual < min || max < actual) {
			abendTest("between $min and $max", actual, propName)
		}
	}
	
	private void abendTest(def expectedMessg, def actualValue, String propName) {
		String errMessg = mkErrMessg(expectedMessg, actualValue, propName)
		AbendProcessor abendProcessor = new AbendProcessor(soapuiObject.getContext())
		abendProcessor.abendTest(testName, errMessg)
	}

	String mkErrMessg(expected, actual, String propName){
		return new MessageCreator().mkValueErrMessg(propName, expected, actual)
	}

}
