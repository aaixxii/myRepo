package test.vx.assertion.verify.response

import test.common.message.MessageCreator
import test.degrade.management.AbendProcessor
import test.degrade.util.SoapuiObject
import test.vx.assertion.verify.intface.VerifyResponseAssertorIF
import test.vx.xml.response.factory.VerifyResponseFactory;
import test.vx.xml.response.holder.CandidateResultList;
import test.vx.xml.response.holder.IndividualScoreList;
import test.vx.xml.response.holder.ModalScoreList;
import test.vx.xml.response.holder.PairList
import test.vx.xml.response.holder.StatusList
import test.vx.xml.response.holder.VerifyResponse;

class VerifyResponseAssertor implements VerifyResponseAssertorIF{
	SoapuiObject soapuiObject
	String testName
	int pairLimit
	int pairListAppearingCnt
	VerifyResponse expectedResponse
	boolean isScore0 = false
	
	public VerifyResponseAssertor(def context){
		this.soapuiObject = new SoapuiObject(context)
	}
	
	public void assertion(String verifyResponseStr){
		this.pairListAppearingCnt = 1
		VerifyResponse actualResponse = VerifyResponseFactory.create(verifyResponseStr)
		List<CandidateResultList> actualCanResultListList = actualResponse.getCandidateResultListList()
		List<CandidateResultList> expectedCanResultListList = expectedResponse.getCandidateResultListList()
		assertEquals(actualCanResultListList.size(), expectedCanResultListList.size(), "CandidateResultList size")
		assertCandidateResultListValues(actualCanResultListList, expectedCanResultListList)
		
	}

	private void assertCandidateResultListValues(List actualCanResultListList, List expectedCanResultListList) {
		for(i in 0..actualCanResultListList.size()-1){
			CandidateResultList actualCanResultList = actualCanResultListList[i]
			CandidateResultList expectedCanResultList = expectedCanResultListList[i]
			assertEquals(actualCanResultList.getEventId(), expectedCanResultList.getEventId(), "eventId")
			assertEquals(actualCanResultList.getExternalId(), expectedCanResultList.getExternalId(), "externalId")
			assertEquals(actualCanResultList.getFusionScore(), expectedCanResultList.getFusionScore(), "fusionScore")
			assertStatusListAnsModalScoreList(actualCanResultList, expectedCanResultList)
			assertEquals(actualCanResultList.getSuccess(), expectedCanResultList.getSuccess(), "sucess")
		}
	}

	private assertStatusListAnsModalScoreList(CandidateResultList actualCanResultList, CandidateResultList expectedCanResultList) {
		if(expectedCanResultList.getStatusList() != null){
			assertStatusList(actualCanResultList, expectedCanResultList)
			assertEquals(actualCanResultList.getModalScoreListList(), null, "modalScoreList")
		}else{
			updateIsScore0(actualCanResultList.getFusionScore())
			assertModalScoreListValues(actualCanResultList, expectedCanResultList)
			assertEquals(actualCanResultList.getStatusList(), null, "statusList")
		}
	}

	private assertStatusList(CandidateResultList actualCanResultList, CandidateResultList expectedCanResultList) {
		StatusList actualStatusList = actualCanResultList.getStatusList()
		StatusList expectedStatusList = expectedCanResultList.getStatusList()
		assertEquals(actualStatusList.getCode(), expectedStatusList.getCode(), "code")
		assertEquals(actualStatusList.getDetail(), expectedStatusList.getDetail(), "detail")
	}

	private updateIsScore0(double score) {
		if(score <= 0){
			isScore0 = true
		}else{
			isScore0 = false
		}
	}

	private assertModalScoreListValues(CandidateResultList actualCanResultList, CandidateResultList expectedCanResultList) {
		List<ModalScoreList> actualModalScoreListList = actualCanResultList.getModalScoreListList()
		List<ModalScoreList> expectedModalScoreListList = expectedCanResultList.getModalScoreListList()
		assertEquals(actualModalScoreListList.size(), expectedModalScoreListList.size(), "modalScoreList size")
		for(i in 0..actualModalScoreListList.size()-1){
			ModalScoreList actualModalScoreList = actualModalScoreListList[i]
			ModalScoreList expectedModalScoreList = expectedModalScoreListList[i]
			assertEquals(actualModalScoreList.getCompositeScore(), expectedModalScoreList.getCompositeScore(), "composite score")
			assertEquals(actualModalScoreList.getModal(), expectedModalScoreList.getModal(), "modal")
			assertIndividualScoreListValues(actualModalScoreList, expectedModalScoreList)
		}
	}

	private assertIndividualScoreListValues(ModalScoreList actualModalScoreList, ModalScoreList expectedModalScoreList) {
		List<IndividualScoreList> actualIndividualScoreListList = actualModalScoreList.getIndividualScoreListList()
		List<IndividualScoreList> expectedIndividualScoreListList = expectedModalScoreList.getIndividualScoreListList()
		assertEquals(actualIndividualScoreListList.size(), expectedIndividualScoreListList.size(), "individualScoreList size")
		for(i in 0..actualIndividualScoreListList.size()-1){
			IndividualScoreList actualIndividualScoreList = actualIndividualScoreListList[i]
			IndividualScoreList expectedIndividualScoreList = expectedIndividualScoreListList[i]
			assertEquals(actualIndividualScoreList.getPosition(), expectedIndividualScoreList.getPosition(), "position")
			assertEquals(actualIndividualScoreList.getScore(), expectedIndividualScoreList.getScore(), "score")
			List<PairList> actualPairListList = actualIndividualScoreList.getPairListList()
			assertPairListValues(actualPairListList)
		}
	}

	private assertPairListValues(List actualPairListList) {
		assertPairListSize(actualPairListList)
		for(PairList pairList in actualPairListList){
			assertLimit(pairList.getFileDirection(), 0, 800, "fileDirection")
			assertLimit(pairList.getFileX(), 0, 800, "fileX")
			assertLimit(pairList.getFileY(), 0, 800, "fileY")
			assertLimit(pairList.getSearchDirection(), 0, 800, "searchDirection")
			assertLimit(pairList.getSearchX(), 0, 800, "searchX")
			assertLimit(pairList.getSearchY(), 0, 800, "searchY")
			assertLimit(pairList.getSimilitude(), 0, 800, "similitude")
		}
	}

	private assertPairListSize(List actualPairListList) {
		if(isScore0 || pairLimit < pairListAppearingCnt){
			assertEquals(actualPairListList.size(), 0, "pairList size")
		}else{
			assertOverCnt(actualPairListList.size(), 1, "pairList size")
		}
		pairListAppearingCnt++
	}
	
	private void assertEquals(def actual, def expected, String propName){
		if(actual != expected) {
			abendTest(expected, actual, propName)
		}
	}
	
	private void assertOverCnt(int actual, int limit, String propName){
		if(actual < limit) {
			abendTest("less than $limit", actual, propName)
		}
	}
	
	private void assertLimit(int actual, int min, int max, String propName){
		if(actual < min || max < actual) {
			abendTest("between $min and $max", actual, propName)
		}
	}
	
	private void abendTest(def expectedMessg, def actualValue, String propName) {
		String errMessg = mkErrMessg(expectedMessg, actualValue, propName)
		AbendProcessor abendProcessor = new AbendProcessor(soapuiObject.getContext())
		abendProcessor.abendTest(testName, errMessg)
	}

	String mkErrMessg(expected, actual, String propName){
		return new MessageCreator().mkValueErrMessg(propName, expected, actual)
	}

}
