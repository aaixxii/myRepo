package test.vx.assertion.verify.procedure

import test.degrade.evidence.*
import test.degrade.management.*
import test.degrade.util.SoapuiObject;
import test.degrade.assertion.*
import test.degrade.assertion.xml.*
import test.vx.xml.response.holder.*
import test.vx.xml.response.factory.*
import test.vx.assertion.testcase.searchresult.*
import test.vx.assertion.verify.intface.VerifyResponseAssertorIF

class VerifyAssertionExecutor {
	SoapuiObject soapuiObject 
	VerifyResponseAssertorIF verifyResponseAssertor
	String targetXml
	String testPatternName
	String testResultMessg
	String outputXmlNameLabel
	
	public VerifyAssertionExecutor(def context){
		this.soapuiObject = new SoapuiObject(context)
	}

	public void outputXml() {
		EvidenceXmlOutputor xmlOutputor = new EvidenceXmlOutputor(soapuiObject.getContext(), outputXmlNameLabel)
		xmlOutputor.outputXml(targetXml)
	}
	
	public void assertXsd() {
		AssertAimXml assertAimXml = new AssertAimXml(soapuiObject.getContext(), testPatternName, targetXml)
		assertAimXml.assertVxXsdSchem()
	}
	
	public void outputEvidence(){
		EvidenceFileOutputor evidenceFileOutputor = new EvidenceFileOutputor(soapuiObject.getContext())
		evidenceFileOutputor.outputTrueMess("${testPatternName} --> ${testResultMessg}")
	}

	public void addAssertCount(){
		new AssertCountChecker(soapuiObject.getContext()).addAssertCount()
	}
	
	public void assertVerifyResponse(){
		verifyResponseAssertor.assertion(targetXml)
	}

	public void execute(){
		outputXml()
		assertXsd()
		assertVerifyResponse()
		outputEvidence()
		addAssertCount()
	}
}
