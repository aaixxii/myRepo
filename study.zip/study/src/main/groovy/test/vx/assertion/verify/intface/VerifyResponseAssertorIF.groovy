package test.vx.assertion.verify.intface


interface VerifyResponseAssertorIF {
	public void assertion(String verifyResponseStr)
}
