package test.vx.util

class ExpectedVerifyResponseController {
	
	static void sortByScores(List expectedVerfyResValList){
		Collections.sort(expectedVerfyResValList, new Comparator<List>(){
					public int compare(List list1, List list2) {
						compareScore(list2, list1)
					}

					private compareScore(List list2, List list1) {
						double diff = (list2[2] as double) - (list1[2] as double)
						if(diff == 0){
							compareExtId(list1, list2)
						}else{
							return diff
						}
					}

					private compareExtId(List list1, List list2) {
						int extIdDiff = list2[1].compareTo(list1[1])
						if(extIdDiff == 0){
							compareEventId(list1, list2)
						}else{
							return extIdDiff
						}
					}

					private compareEventId(List list1, List list2) {
						int eventIdDiff =  list2[0].compareTo(list1[0])
						return eventIdDiff
					}
				})
	}
	
	static void sortByExtId(List expectedVerfyResValList){
		Collections.sort(expectedVerfyResValList, new Comparator<List>(){
					public int compare(List list1, List list2) {
						compareExtId(list1, list2)
					}

					private compareExtId(List list1, List list2) {
						int extIdDiff = list2[1].compareTo(list1[1])
						if(extIdDiff == 0){
							compareEventId(list1, list2)
						}else{
							return extIdDiff
						}
					}

					private compareEventId(List list1, List list2) {
						int eventIdDiff =  list2[0].compareTo(list1[0])
						return eventIdDiff
					}
				})
	}
}
