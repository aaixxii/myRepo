package test.vx.util

class ExpectedVerifyResValListFactory {
	public static List create(String eventId, String externalId, def score, def pos, String modal, def success){
		return [ eventId, externalId, score, [ [ score, [ [ [[]], pos, score] ], modal ] ], success ] 
	}
	
	public static List createWithStatusList(String eventId, String externalId, String code, String detail){
		return [ eventId, externalId, [ code, detail ] ] 
	}
}
