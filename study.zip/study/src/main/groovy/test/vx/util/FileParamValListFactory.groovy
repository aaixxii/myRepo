package test.vx.util

class FileParamValListFactory {
	public static List create(
	String externalId, def fusionNum, def pos, String imageB64,
	def width, def height, def dpi, def blackBGround,
	String dataType, String modal, def eventId){

		return [
			externalId,
			[
				[
					fusionNum,
					[
						[
							[
								pos,
								imageB64,
								width,
								height,
								dpi,
								blackBGround ]
						],
						dataType,
						modal,
						eventId ]
				]
			]
		]
	}
}
