package test.vx.xml.request.holder

class BinaryDataList {
	private static final String BINARY_DATA_LIST_PRE = "<binaryDataList>"
	private static final String BINARY_DATA_LIST_SUF = "</binaryDataList>"
	private static final String IMAGE_POSITION_PRE = "<imagePosition>"
	private static final String IMAGE_POSITION_SUF = "</imagePosition>"
	private static final String VALUES_PRE = "<values>"
	private static final String VALUES_SUF = "</values>"
	private static final String WIDTH_PRE = "<width>"
	private static final String WIDTH_SUF = "</width>"
	private static final String HEIGHT_PRE = "<height>"
	private static final String HEIGHT_SUF = "</height>"
	private static final String DPI_PRE = "<dpi>"
	private static final String DPI_SUF = "</dpi>"
	private static final String BLACK_BACKGROUND_PRE = "<blackBackground>"
	private static final String BLACK_BACKGROUND_SUF = "</blackBackground>"
	
	int imagePosition
	String values
	int width
	int height
	int dpi
	boolean blackBackGround
	
	public String toXml(){
		StringBuilder sb = new StringBuilder()
		appendBinaryDataList(sb)
		return sb.toString()
	}

	private appendBinaryDataList(StringBuilder sb) {
		sb.append(BINARY_DATA_LIST_PRE)
		appendImagePosition(sb)
		appendValues(sb)
		appendWidth(sb)
		appendHeight(sb)
		appendDpi(sb)
		appendBlackBackGround(sb)
		sb.append(BINARY_DATA_LIST_SUF)
	}

	private appendBlackBackGround(StringBuilder sb) {
		sb.append(BLACK_BACKGROUND_PRE)
		sb.append(blackBackGround)
		sb.append(BLACK_BACKGROUND_SUF)
	}

	private appendDpi(StringBuilder sb) {
		sb.append(DPI_PRE)
		sb.append(dpi)
		sb.append(DPI_SUF)
	}

	private appendHeight(StringBuilder sb) {
		sb.append(HEIGHT_PRE)
		sb.append(height)
		sb.append(HEIGHT_SUF)
	}

	private appendWidth(StringBuilder sb) {
		sb.append(WIDTH_PRE)
		sb.append(width)
		sb.append(WIDTH_SUF)
	}

	private appendValues(StringBuilder sb) {
		sb.append(VALUES_PRE)
		sb.append(values)
		sb.append(VALUES_SUF)
	}

	private appendImagePosition(StringBuilder sb) {
		sb.append(IMAGE_POSITION_PRE)
		sb.append(imagePosition)
		sb.append(IMAGE_POSITION_SUF)
	}
}
