package test.vx.xml.response.factory;

import test.vx.xml.response.holder.CandidateResultList;
import test.vx.xml.response.holder.VerifyResponse

public class VerifyResponseFactory {
	private static final String CANDIDATE_RESULT_LIST = "candidateResultList"
	private static final String RETURN_PRE = "<return>"
	private static final String RETURN_SUF = "</return>"
	
	public static VerifyResponse create(String verifyResponseStr){
		Node returnNode = paseResponseBody(verifyResponseStr)
		return createFromNode(returnNode)
	}

	private static Node paseResponseBody(String verifyResponseStr) {
		int start = verifyResponseStr.indexOf(RETURN_PRE)
		int end = verifyResponseStr.indexOf(RETURN_SUF) + RETURN_SUF.length()
		Node returnNode = new XmlParser().parseText(verifyResponseStr.substring(start, end))
		return returnNode
	}
	
	public static VerifyResponse createFromNode(Node verifyResponseNode){
		VerifyResponse verifyResponse = new VerifyResponse()
		List<CandidateResultList> canListList = createCandidateResultListList(verifyResponseNode)
		verifyResponse.setCandidateResultListList(canListList)
		return verifyResponse
	}

	private static List createCandidateResultListList(Node verifyResponseNode) {
		List<CandidateResultList> canListList = new ArrayList<CandidateResultList>()
		for(Node canListNode in verifyResponseNode."${CANDIDATE_RESULT_LIST}"){
			CandidateResultList canList = CandidateResultListFactory.createFromNode(canListNode)
			canListList.add(canList)
		}
		return canListList
	}
	
	public static VerifyResponse createFromList(List valueList){
		VerifyResponse verifyResponse = new VerifyResponse()
		List<CandidateResultList> canListList = createCandidateResultListListFromList(valueList)
		verifyResponse.setCandidateResultListList(canListList)
		return verifyResponse
	}
	
	private static List createCandidateResultListListFromList(List valueList) {
		List<CandidateResultList> canListList = new ArrayList<CandidateResultList>()
		for(List values in valueList){
			CandidateResultList canList = CandidateResultListFactory.createFromList(values)
			canListList.add(canList)
		}
		return canListList
	}
}
