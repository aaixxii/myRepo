package test.vx.xml.response.factory

import test.vx.xml.response.holder.IndividualScoreList
import test.vx.xml.response.holder.PairList;

class IndividualScoreListFactory {
	private static final String PAIR_LIST = "pairList"
	private static final String POSITION = "position"
	private static final String SCORE = "score"
	
	public static IndividualScoreList create(Node individualScoreListNode){
		IndividualScoreList individualScoreList = new IndividualScoreList()
		individualScoreList.setPairListList(createPairListList(individualScoreListNode))
		individualScoreList.setPosition(individualScoreListNode."${POSITION}".text() as int)
		individualScoreList.setScore(individualScoreListNode."${SCORE}".text() as double)
		return individualScoreList
	}

	private static createPairListList(Node individualScoreListNode) {
		List<PairList> pairListList = new ArrayList<PairList>()
		for(Node pairListNode in individualScoreListNode."${PAIR_LIST}"){
			pairListList.add(PairListFactory.create(pairListNode))
		}
		return pairListList
	}
	
	public static IndividualScoreList create(List valueList){
		IndividualScoreList individualScoreList = new IndividualScoreList()
		List<PairList> pairListList = createPairListList(valueList[0])
		individualScoreList.setPairListList(pairListList)
		individualScoreList.setPosition(valueList[1] as int)
		individualScoreList.setScore(valueList[2] as double)
		return individualScoreList
	}

	private static List createPairListList(List pairListValueList) {
		List<PairList> pairListList = new ArrayList<PairList>()
		for(List pairListValues in pairListValueList){
			if(pairListValues.isEmpty()){
				pairListList.add(null)
			}else{
				pairListList.add(pairListValueList)
			}
		}
		return pairListList
	}
}
