package test.vx.xml.request.holder

class FileParameterList {
	private static final String FILE_PARAMETER_LIST_PRE = "<fileParameterList>"
	private static final String FILE_PARAMETER_LIST_SUF = "</fileParameterList>"
	private static final String EXTERNAL_ID_PRE = "<externalId>"
	private static final String EXTERNAL_ID_SUF = "</externalId>"
	
	String externalId
	List<FileDataList> fileDataListList
	
	public String toXml(){
		StringBuilder sb = new StringBuilder()
		appendFileParameterList(sb)
		return sb.toString()
	}

	private appendFileParameterList(StringBuilder sb) {
		sb.append(FILE_PARAMETER_LIST_PRE)
		appendExternalId(sb)
		appendFileDataListList(sb)
		sb.append(FILE_PARAMETER_LIST_SUF)
	}

	private appendFileDataListList(StringBuilder sb) {
		for(FileDataList fDataList in fileDataListList){
			sb.append(fDataList.toXml())
		}
	}

	private appendExternalId(StringBuilder sb) {
		sb.append(EXTERNAL_ID_PRE)
		sb.append(externalId)
		sb.append(EXTERNAL_ID_SUF)
	}
}
