package test.vx.xml.response.holder

class CandidateResultList {
	String eventId
	String externalId
	double fusionScore
	StatusList statusList
	List<ModalScoreList> modalScoreListList
	boolean success
}
