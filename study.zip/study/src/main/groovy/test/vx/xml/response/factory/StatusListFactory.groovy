package test.vx.xml.response.factory

import java.util.List;

import test.vx.xml.response.holder.CandidateResultList;
import test.vx.xml.response.holder.StatusList

class StatusListFactory {
	private static final String CODE = "code"
	private static final String DETAIL = "detail"
	
	public static StatusList createFromNode(Node statusListNode){
		StatusList statusList = new StatusList()
		statusList.setCode(statusListNode."${CODE}".text())
		statusList.setDetail(statusListNode."${DETAIL}".text())
		return statusList
	}
	
	public static StatusList createFromList(List statusValList){
		StatusList statusList = new StatusList()
		statusList.setCode(statusValList[0])
		statusList.setDetail(statusValList[1])
		return statusList
	}
}
