package test.vx.xml.request.factory

import test.vx.xml.request.holder.FileDataList;
import test.vx.xml.request.holder.FileParameterList

class FileParameterListFactory {
	
	public static FileParameterList create(List valuesList){
		FileParameterList fileParameterList = new FileParameterList()
		fileParameterList.setExternalId(valuesList[0])
		List<FileDataList> fileDataListList = createFileDataListList(valuesList[1])
		fileParameterList.setFileDataListList(fileDataListList)
		return fileParameterList
	}

	private static List createFileDataListList(List fileDataListValuesList) {
		List<FileDataList> fileDataListList = new ArrayList<FileDataList>()
		for(List fileDataListValues in fileDataListValuesList){
			FileDataList fileDataList = FileDataListFactory.create(fileDataListValues)
			fileDataListList.add(fileDataList)
		}
		return fileDataListList
	}

}
