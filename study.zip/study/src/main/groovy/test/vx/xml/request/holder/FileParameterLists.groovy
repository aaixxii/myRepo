package test.vx.xml.request.holder

class FileParameterLists {
	List<FileParameterList> fileParameterListList
	
	public String toXml(){
		StringBuilder sb = new StringBuilder()
		for(FileParameterList fPList in fileParameterListList){
			sb.append(fPList.toXml())
		}
		return sb.toString()
	}
}
