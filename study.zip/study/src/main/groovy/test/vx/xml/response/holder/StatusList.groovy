package test.vx.xml.response.holder

class StatusList {
	String code
	String detail
}
