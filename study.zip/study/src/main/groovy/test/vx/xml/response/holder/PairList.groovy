package test.vx.xml.response.holder

class PairList {
	int fileDirection
	int fileX
	int fileY
	int searchDirection
	int searchX
	int searchY
	int similitude
}
