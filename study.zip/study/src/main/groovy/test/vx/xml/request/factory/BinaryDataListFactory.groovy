package test.vx.xml.request.factory

import test.vx.xml.request.holder.BinaryDataList

class BinaryDataListFactory {
	
	public static BinaryDataList create(List valueList){
		BinaryDataList binaryDataList = new BinaryDataList();
		binaryDataList.setImagePosition(valueList[0])
		binaryDataList.setValues(valueList[1])
		binaryDataList.setWidth(valueList[2])
		binaryDataList.setHeight(valueList[3])
		binaryDataList.setDpi(valueList[4])
		binaryDataList.setBlackBackGround(valueList[5])
		return binaryDataList
	}
}
