package test.vx.xml.request.factory

import test.vx.xml.request.holder.Elft

class ElftFactory {
	
	public static Elft create(int fusionNum){
		Elft elft = new Elft()
		elft.setFusionNumber(fusionNum)
		return elft
	}
}
