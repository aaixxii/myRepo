package test.vx.xml.response.holder

class IndividualScoreList {
	List<PairList> pairListList
	int position
	double score
}
