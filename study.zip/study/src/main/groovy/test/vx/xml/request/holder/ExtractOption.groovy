package test.vx.xml.request.holder

class ExtractOption {
	private static final String EXTRACT_OPTION_PRE = "<extractOption>"
	private static final String EXTRACT_OPTION_SUF = "</extractOption>"
	
	Elft elft
	
	public String toXml(){
		StringBuilder sb = new StringBuilder()
		sb.append(EXTRACT_OPTION_PRE)
		sb.append(elft.toXml())
		sb.append(EXTRACT_OPTION_SUF)
		return sb.toString()
	}
}
