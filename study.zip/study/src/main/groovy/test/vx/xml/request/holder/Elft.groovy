package test.vx.xml.request.holder

class Elft {
	private static final String ELFT_PRE = "<elft>"
	private static final String ELFT_SUF = "</elft>"
	private static final String FUSION_NUMBER_PRE = "<fusionNumber>"
	private static final String FUSION_NUMBER_SUF = "</fusionNumber>"
	
	int fusionNumber
	
	public String toXml(){
		StringBuilder sb = new StringBuilder()
		sb.append(ELFT_PRE)
		sb.append(FUSION_NUMBER_PRE)
		sb.append(fusionNumber)
		sb.append(FUSION_NUMBER_SUF)
		sb.append(ELFT_SUF)
		return sb.toString()
	}
}
