package test.vx.xml.response.holder

class ModalScoreList {
	double compositeScore
	List<IndividualScoreList> individualScoreListList
	String modal
}
