package test.vx.xml.request.factory

import test.vx.xml.request.holder.Elft
import test.vx.xml.request.holder.ExtractOption;

class ExtractOptionFactory {
	
	public static create(int fusionNum){
		ExtractOption extractOption = new ExtractOption()
		Elft elft = new Elft()
		elft.setFusionNumber(fusionNum)
		extractOption.setElft(elft)
		return extractOption
	}

}
