package test.vx.xml.request.factory

import test.vx.xml.request.holder.FileParameterList
import test.vx.xml.request.holder.FileParameterLists

class FileParameterListsFactory {
	
	public static FileParameterLists create(List valuesList){
		FileParameterLists fileParameterLists = new FileParameterLists()
		List<FileParameterList> fileParameterListList = new ArrayList<FileParameterList>()
		for(List fPValuesList in valuesList){
			FileParameterList fileParameterList = FileParameterListFactory.create(fPValuesList)
			fileParameterListList.add(fileParameterList)
		}
		fileParameterLists.setFileParameterListList(fileParameterListList)
		return fileParameterLists
	}

}
