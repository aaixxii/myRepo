package test.vx.xml.request.factory

import test.vx.xml.request.holder.Biometrics
import test.vx.xml.request.holder.ExtractOption;
import test.vx.xml.request.holder.FileDataList;

class FileDataListFactory {
	
	public static FileDataList create(List valuesList){
		FileDataList fileDataList = new FileDataList()
		ExtractOption extractOption = ExtractOptionFactory.create(valuesList[0])
		Biometrics biometrics = BiometricsFactory.create(valuesList[1])
		fileDataList.setExtractOption(extractOption)
		fileDataList.setBiometrics(biometrics)
		return fileDataList
	}

}
