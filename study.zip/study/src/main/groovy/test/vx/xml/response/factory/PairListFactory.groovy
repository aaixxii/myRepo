package test.vx.xml.response.factory;

import groovy.util.Node;
import test.vx.xml.response.holder.PairList;

public class PairListFactory {
	private static final String FILE_DIRECTION = "fileDirection"
	private static final String FILE_X = "fileX"
	private static final String FILE_Y = "fileY"
	private static final String SEARCH_DIRECTION = "searchDirection"
	private static final String SEARCH_X = "searchX"
	private static final String SEARCH_Y = "searchY"
	private static final String SIMILITUDE = "similitude"

	public static PairList create(Node pairListNode){
		PairList pairList = new PairList()
		pairList.setFileDirection(pairListNode."${FILE_DIRECTION}".text() as int)
		pairList.setFileX(pairListNode."${FILE_X}".text() as int)
		pairList.setFileY(pairListNode."${FILE_Y}".text() as int)
		pairList.setSearchDirection(pairListNode."${SEARCH_DIRECTION}".text() as int)
		pairList.setSearchX(pairListNode."${SEARCH_X}".text() as int)
		pairList.setSearchY(pairListNode."${SEARCH_Y}".text() as int)
		pairList.setSimilitude(pairListNode."${SIMILITUDE}".text() as int)
		return pairList
	}
	
	public static PairList create(List valueList){
		PairList pairList = new PairList()
		pairList.setFileDirection(valueList[0])
		pairList.setFileX(valueList[1])
		pairList.setFileY(valueList[2])
		pairList.setSearchDirection(valueList[3])
		pairList.setSearchX(valueList[4])
		pairList.setSearchY(valueList[5])
		pairList.setSimilitude(valueList[6])
		return pairList
	}
}
