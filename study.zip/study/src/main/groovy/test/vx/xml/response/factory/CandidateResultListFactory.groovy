package test.vx.xml.response.factory

import test.vx.xml.response.holder.CandidateResultList
import test.vx.xml.response.holder.ModalScoreList;
import test.vx.xml.response.holder.StatusList

class CandidateResultListFactory {
	private static final String EVENT_ID = "eventId"
	private static final String EXTERNAL_ID = "externalId"
	private static final String FUSION_SCORE = "fusionScore"
	private static final String STATUS_LIST = "statusList"
	private static final String MODAL_SCORE_LIST = "modalScoreList"
	private static final String SUCCESS = "success"
	private static isStatusListExists = false
	
	public static CandidateResultList createFromNode(Node candidateResultListNode){
		isStatusListExists = false
		CandidateResultList candidateResultList = new CandidateResultList()
		candidateResultList.setEventId(candidateResultListNode."${EVENT_ID}".text())
		candidateResultList.setExternalId(candidateResultListNode."${EXTERNAL_ID}".text())
		candidateResultList.setFusionScore(candidateResultListNode."${FUSION_SCORE}".text() as double)
		setStatusListIfNotNull(candidateResultListNode, candidateResultList)
		setModalScoreListIfNotNull(candidateResultListNode, candidateResultList)
		candidateResultList.setSuccess(new Boolean(candidateResultListNode."${SUCCESS}".text()))
		return candidateResultList
	}

	private static setModalScoreListIfNotNull(Node candidateResultListNode, CandidateResultList candidateResultList) {
		if(candidateResultListNode."${MODAL_SCORE_LIST}".size() != 0){
			if(isStatusListExists){
				assert false, "statusList is exists, but modalScoreList is exitst, too."
			}
			List<ModalScoreList> modalScoreListList = createModalScoreListList(candidateResultListNode)
			candidateResultList.setModalScoreListList(modalScoreListList)
		}
	}

	private static setStatusListIfNotNull(Node candidateResultListNode, CandidateResultList candidateResultList) {
		if(candidateResultListNode."${STATUS_LIST}".size() != 0){
			isStatusListExists = true
			StatusList statusList = StatusListFactory.createFromNode(candidateResultListNode."${STATUS_LIST}"[0])
			candidateResultList.setStatusList(statusList)
		}
	}

	private static List createModalScoreListList(Node candidateResultListNode) {
		List<ModalScoreList> modalScoreListList = new ArrayList<ModalScoreList>()
		for(Node modalScoreListNode in candidateResultListNode."${MODAL_SCORE_LIST}"){
			ModalScoreList modalScoreList = ModalScoreListFactory.create(modalScoreListNode)
			modalScoreListList.add(modalScoreList)
		}
		return modalScoreListList
	}
	
	public static CandidateResultList createFromList(List valueList){
		if(valueList.size() == 5){
			return createWithModalScoreFromList(valueList)
		}else{
			return createWithStatusListFromList(valueList)
		}
	}
	public static CandidateResultList createWithModalScoreFromList(List valueList){
		CandidateResultList candidateResultList = new CandidateResultList()
		candidateResultList.setEventId(valueList[0])
		candidateResultList.setExternalId(valueList[1])
		candidateResultList.setFusionScore(valueList[2] as double)
		List<ModalScoreList> modalScoreListList = createModalScoreListList(valueList[3])
		candidateResultList.setModalScoreListList(modalScoreListList)
		candidateResultList.setSuccess(valueList[4] as boolean)
		return candidateResultList
	}
	
	private static List createModalScoreListList(List valueList) {
		List<ModalScoreList> modalScoreListList = new ArrayList<ModalScoreList>()
		for(List values in valueList){
			ModalScoreList modalScoreList = ModalScoreListFactory.create(values)
			modalScoreListList.add(modalScoreList)
		}
		return modalScoreListList
	}

	public static CandidateResultList createWithStatusListFromList(List valueList){
		CandidateResultList candidateResultList = new CandidateResultList()
		candidateResultList.setEventId(valueList[0])
		candidateResultList.setExternalId(valueList[1])
		candidateResultList.setFusionScore(0.0)
		StatusList statusList = StatusListFactory.createFromList(valueList[2])
		candidateResultList.setStatusList(statusList)
		candidateResultList.setSuccess(false)
		return candidateResultList
	}
}
