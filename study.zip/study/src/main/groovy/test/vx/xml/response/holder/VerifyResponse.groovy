package test.vx.xml.response.holder

class VerifyResponse {
	List<CandidateResultList> candidateResultListList
}
