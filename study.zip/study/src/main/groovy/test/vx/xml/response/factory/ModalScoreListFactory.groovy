package test.vx.xml.response.factory

import test.vx.xml.response.holder.IndividualScoreList;
import test.vx.xml.response.holder.ModalScoreList

class ModalScoreListFactory {
	private static final String COMPOSITE_SCORE = "compositeScore"
	private static final String INDIVIDUAL_SCORE_LIST = "individualScoreList"
	private static final String MODAL = "modal"
	
	public static ModalScoreList create(Node modalScoreListNode){
		ModalScoreList modalScoreList = new ModalScoreList()
		modalScoreList.setCompositeScore(modalScoreListNode."${COMPOSITE_SCORE}".text() as double)
		List<IndividualScoreList> individualScoreListList = createIndividualScoreListList(modalScoreListNode)
		modalScoreList.setIndividualScoreListList(individualScoreListList)
		modalScoreList.setModal(modalScoreListNode."${MODAL}".text())
		return modalScoreList
	}

	private static List createIndividualScoreListList(Node modalScoreListNode) {
		List<IndividualScoreList> individualScoreListList = new ArrayList<IndividualScoreList>()
		for(Node individualScoreListNode in modalScoreListNode."${INDIVIDUAL_SCORE_LIST}"){
			IndividualScoreList individualScoreList = IndividualScoreListFactory.create(individualScoreListNode)
			individualScoreListList.add(individualScoreList)
		}
		return individualScoreListList
	}
	
	public static ModalScoreList create(List valueList){
		ModalScoreList modalScoreList = new ModalScoreList()
		modalScoreList.setCompositeScore(valueList[0] as double)
		List<IndividualScoreList> individualScoreListList = createIndividualScoreListList(valueList[1])
		modalScoreList.setIndividualScoreListList(individualScoreListList)
		modalScoreList.setModal(valueList[2])
		return modalScoreList
	}

	private static List createIndividualScoreListList(List valueList) {
		List<IndividualScoreList> individualScoreListList = new ArrayList<IndividualScoreList>()
		for(List values in valueList){
			IndividualScoreList individualScoreList = IndividualScoreListFactory.create(values)
			individualScoreListList.add(individualScoreList)
		}
		return individualScoreListList
	}
	
}
