package test.vx.xml.request.holder

class Biometrics {
	private static final String BIOMETRICS_PRE = "<biometrics>"
	private static final String BIOMETRICS_SUF = "</biometrics>"
	private static final String DATA_TYPE_PRE = "<dataType>"
	private static final String DATA_TYPE_SUF = "</dataType>"
	private static final String MODAL_PRE = "<modal>"
	private static final String MODAL_SUF = "</modal>"
	private static final String EVENT_ID_PRE = "<eventId>"
	private static final String EVENT_ID_SUF = "</eventId>"
	
	
	List<BinaryDataList> binaryDataListList
	String dataType
	String modal
	int eventId
	
	public String toXml(){
		StringBuilder sb = new StringBuilder()
		appendBiometrics(sb)
		return sb.toString()
	}

	private appendBiometrics(StringBuilder sb) {
		sb.append(BIOMETRICS_PRE)
		appendBinaryDataList(sb)
		appendDataType(sb)
		appendModal(sb)
		appendEventId(sb)
		sb.append(BIOMETRICS_SUF)
	}

	private appendEventId(StringBuilder sb) {
		sb.append(EVENT_ID_PRE)
		sb.append(eventId)
		sb.append(EVENT_ID_SUF)
	}

	private appendModal(StringBuilder sb) {
		sb.append(MODAL_PRE)
		sb.append(modal)
		sb.append(MODAL_SUF)
	}

	private appendDataType(StringBuilder sb) {
		sb.append(DATA_TYPE_PRE)
		sb.append(dataType)
		sb.append(DATA_TYPE_SUF)
	}

	private appendBinaryDataList(StringBuilder sb) {
		for(BinaryDataList binaryDataList in binaryDataListList){
			sb.append(binaryDataList.toXml())
		}
	}
}
