package test.vx.xml.request.holder

class FileDataList {
	private static final String FILE_DATA_LIST_PRE = "<fileDataList>"
	private static final String FILE_DATA_LIST_SUF = "</fileDataList>"
	
	ExtractOption extractOption
	Biometrics biometrics
	
	public String toXml(){
		StringBuilder sb = new StringBuilder()
		sb.append(FILE_DATA_LIST_PRE)
		sb.append(extractOption.toXml())
		sb.append(biometrics.toXml())
		sb.append(FILE_DATA_LIST_SUF)
		return sb.toString()
	}
}
