package test.vx.xml.request.factory

import test.vx.xml.request.holder.BinaryDataList;
import test.vx.xml.request.holder.Biometrics

class BiometricsFactory {
	
	public static Biometrics create(List valueList){
		Biometrics biometrics = new Biometrics();
		List<BinaryDataList> binaryDataListList = createBinaryDataListList(valueList[0])
		biometrics.setBinaryDataListList(binaryDataListList)
		biometrics.setDataType(valueList[1])
		biometrics.setModal(valueList[2])
		biometrics.setEventId(valueList[3])
		return biometrics
	}

	private static List createBinaryDataListList(List binaryDataListValuesList) {
		List<BinaryDataList> binaryDataListList = new ArrayList<BinaryDataList>()
		for(List binaryDataListValues in binaryDataListValuesList){
			BinaryDataList binaryDataList = BinaryDataListFactory.create(binaryDataListValues)
			binaryDataListList.add(binaryDataList)
		}
		return binaryDataListList
	}
}
