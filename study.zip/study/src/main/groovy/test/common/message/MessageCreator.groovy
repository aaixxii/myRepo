package test.common.message

import test.common.constants.aim.*

class MessageCreator{

	ConvertErrorMessageCreator convErrMsgCreator

	MessageCreator(){
		this.convErrMsgCreator = new ConvertErrorMessageCreator()
	}

	// For DB externalId and eventId check test
	def mkDBErrMessg(expectedExtId, expectedEventId, actualExtId, actualEventId){
		return "Invalid DB values. externalId/eventId is expected '${expectedExtId}/${expectedEventId}', " +
				"but actual '${actualExtId}/${actualEventId}'."
	}

	// For DB record count check test
	def mkDBErrMessg(expectedCount, actualCount){
		return "Invalid DB values. record count is expected '${expectedCount}', but actual '${actualCount}'."
	}

	def mkValueErrMessg(property, expectedValue, actualValue){
		return "Invalid value of ${property}. expected '${expectedValue}' : actual '${actualValue}'"
	}

	def mkDiffErrMessg(expected, actual){
		return "It is different value of '${expected}' and '${actual}'"
	}

	def String mkNoMinutiaMessg(fingerNumber, jobId){
		return MUMessenger.EXTRACT_ERR_NO_MINUTIA + " ${fingerNumber}, JobID: ${jobId}"
	}

	def String mkInconsistentCropMessg(leftX, leftY, rightX, rightY){
		return MUMessenger.INCONSISTENT_CROP_POINTS + " LEFT=${leftX} RIGHT=${rightX} TOP=${leftY} BOTTOM=${rightY})"
	}

    def String mkInvalidGenderMessg(String actual) {
		return convErrMsgCreator.getGenderErrMessg(actual)
    }

    def String mkInvalidSelectPartsMessg(String actual) {
        return "(Class Convert UnmarshalException occurred, Error message: UnmarshalException: cvc-pattern-valid: Value '${actual}' is not facet-valid with respect to pattern '[0]{1}|[1-9A-G]{1,16}' for type 'selectParts-type'.)"
    }

    def String mkInvalidRaceMessg(String actual) {
		return convErrMsgCreator.getRaceErrMessg(actual)
    }

    def String mkInvalidRegionMessg(String actual) {
        return convErrMsgCreator.getRegionErrMessg(actual)
    }

    def String mkNonExistContainerIdMessg(String actual) {
        return "Inquiry Service (DataBase error occurred, error:CallableStatementCallback; uncategorized SQLException for SQL [{? = call MATCH_MANAGER_API.CREATE_CONTAINER_JOB(?, ?, ?, ?, ?, ?, ?)}]; SQL state [72000]; error code [20003]; ORA-20003: The given container ID, ${actual}, does not exist in the system."
    }


    def String mkSyncNonExistContainerIdMessg(String actual) {
		return "Sync Service (DataBase error occurred, error:org.springframework.jdbc.UncategorizedSQLException: CallableStatementCallback; uncategorized SQLException for SQL [{? = call MATCH_MANAGER_API.ADD_BIOMETRICS(?, ?, ?, ?, ?, ?, ?)}]; SQL state [72000]; error code [20003]; ORA-20003: The given container ID, ${actual}, does not exist in the system."
	}

	def String mkNonExistAfisGropeMessg(){
		return "parent key not found"
	}

	def String mkInvalidLatentPatternMessg(String actual) {
        return convErrMsgCreator.getLatentPatErrMessg(actual)
	}

	def String mkInvalidLatentAdjPatternMessg(String actual) {
		return convErrMsgCreator.getLatentAdjaPatErrMessg(actual)
	}

	def String mkInvalidSelectFinMessg(String actual) {
       return "(Class Convert UnmarshalException occurred, Error message: UnmarshalException: cvc-pattern-valid: Value '${actual}' is not facet-valid with respect to pattern '[0-9]{1,10}' for type 'selectFingers-type'.)"
	}

	def String mkInvalidLeAlgorithmMessg(String actual) {
		return "(Class Convert UnmarshalException occurred, Error message: UnmarshalException: cvc-enumeration-valid: Value '${actual}' is not facet-valid with respect to enumeration '[1, 2, 3]'. It must be a value from the enumeration.)"
	}

	def String mkInvalidLeRotationLimitMessg(String actual) {
		return mkInvalidRotationLimitMessg(actual)
	}

	def String mkInvalidRotationLimitMessg(String actual) {
		return "(Class Convert UnmarshalException occurred, Error message: UnmarshalException: cvc-enumeration-valid: Value '${actual}' is not facet-valid with respect to enumeration '[1, 2, 3, 4]'. It must be a value from the enumeration.)"
	}

	def String mkInvalidLeCorePosMessg(String actual) {
		return "(Class Convert UnmarshalException occurred, Error message: UnmarshalException: cvc-enumeration-valid: Value '${actual}' is not facet-valid with respect to enumeration '[1, 2, 3, 4]'. It must be a value from the enumeration.)"
	}

	def String mkInvalidSearchLvMessg(String actual) {
		return convErrMsgCreator.createEnumErrMesseg(actual, "[1, 2, 3, 4, 5]")
	}

	def String mkInvalidSpeedLvMessg(String actual) {
		return convErrMsgCreator.createEnumErrMesseg(actual, "[1, 2, 3, 4, 5, 6, 7, 8, 9]")
	}

	def String mkInvalidDistotionLvMessg(String actual) {
		return convErrMsgCreator.createEnumErrMesseg(actual, "[1, 2, 3, 4, 5, 6]")
	}

	def String mkInvalidDistotionLvMessg2(String actual) {
		return convErrMsgCreator.createEnumErrMesseg(actual, "[1, 2, 3, 4, 5]")
	}

	def String mkInvalidEnhanceMessg(String actual) {
		return convErrMsgCreator.createEnumErrMesseg(actual, "[0, 1, 2, 3, 4, 5, 6]")
	}

	def String mkTooManyEnhMessg(String actual) {
		return convErrMsgCreator.getTooManyEnhErrMessg()
	}

	def String mkOutOfRangeMinScoreMessg() {
		return mkOutOfRangeMessg("MinScore")
	}

	def String mkOutOfRangeMaxCandMessg() {
		return mkOutOfRangeMessg("MaxCandidates")
	}

	def String mkOutOfRangeDynMessg() {
		return mkOutOfRangeMessg("DynThreshHitThreshold")
	}

	def String mkOutOfRangeDTPMessg() {
		return mkOutOfRangeMessg("DynThreshPercentagePoint")
	}

	def String mkOutOfRangePriorityMessg() {
		return mkOutOfRangeMessg("Priority")
	}

	def String mkOutOfRangeMessg(String propName) {
		return "Inquiry Job (${propName} is out of range)"
	}

    def String mkInvalidAimFmt(def input) {
        return "Invalid aim format(${input})."
    }

    def String mkFaceInvalidAimFmt(def input) {
        return "Invalid face extract aimformat(${input})."
    }

    def String mkIrisInvalidAimFmt(def input) {
        return "Invalid iris extract aimformat(${input})."
    }

    def String mkIrisMinPupGreaterThanMaxMessg(String min, String max) {
        return String.format(MUMessenger.IRIS_MIN_PUPIL_GREATER_THAN_MAX, min, max)
    }

    def String mkIrisMinIrisGreaterThanMaxMessg(String min, String max) {
        return String.format(MUMessenger.IRIS_MIN_IRIS_GREATER_THAN_MAX, min, max)
    }

    def String mkIrisOutOfRangeMinPupMessg(String input) {
        return String.format(MUMessenger.IRIS_OUT_OF_RANGE_MIN_PUPIL, input)
    }

    def String mkIrisOutOfRangeMinIrisMessg(String input) {
        return String.format(MUMessenger.IRIS_OUT_OF_RANGE_MIN_IRIS, input)
    }

    def String mkCmlParamFileLoadFailureMessg(String input) {
        return String.format(MUMessenger.CML_PARAMETER_FILE_LOAD_FAILURE, input)
    }

    public String mkNotSetImageSizeErrMsg(){
        String expWording = "Width and Height must be specified"
        return mkInvalidImageInfo(expWording)
    }

    public String mkInvalidWidhtErrMsg(def input){
        String expWording = "Image-width is invalid.(${input})"
        return mkInvalidImageInfo(expWording)
    }

    public String mkInvalidHeightErrMsg(def input){
        String expWording = "Image-height is invalid.(${input})"
        return mkInvalidImageInfo(expWording)
    }

    public String mkInvalidImageTypeErrMsg(def input){
        String expWording = "Image format type is invalid.(${input})"
        return mkInvalidImageInfo(expWording)
    }

    public String mkInvalidFaceMaxNumErrMsg(def input){
        String expWording = "Detection maximum value is invalid.(${input})"
        return mkInvalidFaceDetectOpt(expWording)
    }

    public String mkDuplicateAttemptNumErrMsg(){
        String expWording = "Detection number is duplicated"
        return mkInvalidFaceDetectOpt(expWording)
    }

    public String mkDuplicatePointNumErrMsg(){
        String expWording = "Points number is duplicated"
        return mkInvalidFaceDetectOpt(expWording)
    }

    public String mkInvalidReliabiliryErrMsg(def input){
        String expWording = "Detection reliability[0] is invalid.(${input})"
        return mkInvalidFaceDetectOpt(expWording)
    }

    public String mkInvalidEyeMinErrMsg(def input){
        String expWording = "Detection eye min[0] is invalid.(${input})"
        return mkInvalidFaceDetectOpt(expWording)
    }

    public String mkInvalidEyeMaxErrMsg(def input){
        String expWording = "Detection eye max[0] is invalid.(${input})"
        return mkInvalidFaceDetectOpt(expWording)
    }

    public String mkInvalidEyeRtationErrMsg(def input){
        String expWording = "Detection eye rotation[0] is invalid.(${input})"
        return mkInvalidFaceDetectOpt(expWording)
    }

    public String mkEqualEyeMinEyeMaxErrMsg(){
        String expWording = "eyeMin and eyeMax, two values equal."
        return mkInvalidFaceDetectOpt(expWording)
    }

    public String mkInvalidPointAttributeErrMsg(){
        String expWording = "Points attribute is invalid."
        return mkInvalidFaceDetectOpt(expWording)
    }

    public String mkAttemptOnlySetSecondeErrMsg(){
        String expWording = "not specified attempt=1, but specifed attempt=2"
        return mkInvalidFaceDetectParams(expWording)
    }

    public String mkInvalidFacePointNumErrMsg(def input){
        String expWording = "Extraction number is invalid.(${input})"
        return mkInvalidFaceExtractOpt(expWording)
    }

    public String mkInvalidImageInfo(def expWording){
        return "Invalid payload IMAGE INFO (${expWording})"
    }

    public String mkInvalidFaceEyeMinDistance(def expWording){
        return "Invalid value of minimum eye distance:[0], ${expWording}"
    }

    public String mkInvalidFaceDetectOpt(def expWording){
        return "Invalid payload Face Detection Option (${expWording})"
    }

    public String mkInvalidFaceDetectParams(def expWording){
        return "Invalid payload Face Detection Params (${expWording})"
    }

    public String mkInvalidFaceExtractOpt(def expWording){
        return "Invalid payload Face Extraction Option (${expWording})"
    }

	public String mkInvalidFaceQualityThErrMessg(def input){
		return "Quality threshold of negative detection parameter is invalid.(${input})"
	}

	public String mkInvalidFaceMatchingScoreThErrMessg(def input){
		return "Matching score threshold of negative detection parameter is invalid.(${input})"
	}

	public String mkFailedQtfOutOfRangeErrMessg(){
		return "Failed to necQTFSetFaceInfo() num[0] detail:Invalid argument: value out of allowed range"
	}

	public String mkFailedQtfAnalyseErrMessg(){
		return "Failed to necQTFDoAnalyse() num[0] detail:Analyse failed"
	}

    public String mkInvalidImageFormat(def input){
        return "Specified image format is invalid.(${input})"
    }

    public String mkMinPupOverHalfWidthErrMessg(def minPup, def imgWidth) {
        return mkIrisDetectPupilOverHalfWidthErrMessg(minPup, imgWidth, "minPupilRadius")
    }

    public String mkMaxPupOverHalfWidthErrMessg(def maxPup, def imgWidth) {
        return mkIrisDetectPupilOverHalfWidthErrMessg(maxPup, imgWidth, "maxPupilRadius")
    }

    public String mkIrisDetectPupilOverHalfWidthErrMessg(def value, def imgWidth, String paramName) {
        return "Error : ${paramName}(${value}) <=0 or ${paramName}(320) >= image width(${imgWidth})/2"
    }

    public String mkIrisDetectMinIrisOverHalfWidthErrMessg(def minIris, def minPup, def imgWidth) {
        return "Error : minIrisRadius(${minIris}) <= minPupilRadius(${minPup}) or minIrisRadius(${minIris}) > image width(${imgWidth})/2"
    }

    public String mkIrisDetectMaxIrisOverHalfWidthErrMessg(def maxIris, def maxPup, def imgWidth) {
        return "Error : maxPupilRadius(${maxPup}) >= maxIrisRadius(${maxIris}) or maxIrisRadius(${maxIris}) > image width(${imgWidth})/2"
    }

    public String mkInvalidYobErrMessg(def input){ 
        return "Invalid payload YOB (${input})"
    }

    public String mkInvalidYobRangeErrMessg(def input){ 
        return "Invalid payload YOB_RANGE (${input})"
    }

    public String mkInvalidIrisRotationErrMessg(def input){ 
        return "Iris matching parameter (rotation limit) is invalid (${input})"
    }

    public String mkSearchKeyDuplicateErrMessg(def input){ 
        return "Inquiry Job (The combination of (key fingerPrintType) was duplicate.)"
    }

    public String mkCannotFetchTemplateErrMessg(){ 
        return "Inquiry Job (Can not fetch template binary with job id and telmplete key)"
    }

    public String mkDuplicateSearchScopeErrMessg(){ 
        return "Inquiry Job (Specified Scope list was duplicate.)"
    }

    public String mkDuplicateSearchTargetFinTypeErrMessg(){ 
        return "Inquiry Service (Scope FingerPrintType is not correct.)"
    }

    public String mkInvalidCombSearchFileParamErrMessg(String funcName, String templateFmtName, String sFinPrint, String fFinPrint){ 
        return "Inquiry Job (The combination of functionName, TemplateFormatType, Search Side FingerPrintType and File side FingerPrintType is not correct, Search Key: SearchKey[function=${funcName},templateFmt=${templateFmtName},sFinPrint=${sFinPrint},fFinPrint=${fFinPrint}])"
    }

	public String mkInvalidCombSearchFileParamErrMessg(String funcName, String templateFmtName, String sFinPrint){
        return "Inquiry Job (The combination of functionName, TemplateFormatType, Search Side FingerPrintType and File side FingerPrintType is not correct, Search Key: SearchKey[function=${funcName},templateFmt=${templateFmtName},sFinPrint=${sFinPrint},fFinPrint=<null>])"
    }

    public String mkSyncKeyDuplicateErrMessg(){
        return "Sync Job (Specified key and indexer list in insertpayload or deletePayload was duplicate.)"
    }

	public String mkTemplateValidatorNotReadyErrMessg(String ip){
		return "(Template validation error, Error message: Exception occurred while post to url http://${ip}:11000/templatevalidator/Validate)"
	}

	public String mkTemplateValidatorCountDiffErrMessg(String fmtType, String tempIndex, String tempCount){
		return "Finger Count and Minutia Entry Count are Different.   TemplateFormat: ${fmtType}.   Index of Invalid Template: ${tempIndex} (All Input Template: ${tempCount})."
	}

	public String mkTemplateValidatorLOCSizeErrMessg(String fmtType, String tempIndex, String tempCount){
		return "LOC and Template Size are Different.   TemplateFormat: ${fmtType}.   Index of Invalid Template: ${tempIndex} (All Input Template: ${tempCount})."
	}

	public String mkTemplateValidatorLOMSizeErrMessg(String fmtType, String tempIndex, String tempCount){
		return "LOM and Template Size are Different.   TemplateFormat: ${fmtType}.   Index of Invalid Template: ${tempIndex} (All Input Template: ${tempCount})."
	}

	public String mkTemplateValidatorCheckSumErrMessg(String tempIndex, String tempCount){
		return "CheckSum is invalid.   TemplateFormat: FDB.   Index of Invalid Template: ${tempIndex} (All Input Template: ${tempCount})."
	}

	public String mkTemplateValidatorIrisTempSizeErrMessg(String tempIndex, String tempCount){
		return "Iris Template Size is Invalid.   TemplateFormat: IDB.   Index of Invalid Template: ${tempIndex} (All Input Template: ${tempCount})."
	}

	public String mkTemplateValidatorTimModeErrMessg(String timEngine, String fmtType, String tempIndex, String tempCount){
		return "${timEngine} Template Data is Invalid.   TemplateFormat: ${fmtType}.   Index of Invalid Template: ${tempIndex} (All Input Template: ${tempCount})."
	}

	public String mkTemplateValidatorIrisModeErrMessg(String tempIndex, String tempCount){
		return "Library ID is Invalid.   TemplateFormat: IDB.   Index of Invalid Template: ${tempIndex} (All Input Template: ${tempCount})."
	}

	public String mkTemplateValidatorFaceModeErrMessg(String tempIndex, String tempCount){
		return "Face Library of Input Template Data is different from It of Config Settings.   TemplateFormat: FDB.   Index of Invalid Template: ${tempIndex} (All Input Template: ${tempCount})."
	}

    public String mkInvalidNirisIiTemplateSizeErrMessg(int expSize, int actSize) {
        return String.format(MUMessenger.INVALID_NIRIS_II_TEMPLATE_SIZE, expSize, actSize)
    }
}
