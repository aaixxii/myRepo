package test.common.message

import common.sql.*
import test.common.util.db.*
import test.common.constants.aim.*

class CommonOptionMessageCreator{

	SqlExecutor sqlExecutor

	CommonOptionMessageCreator(){}

	CommonOptionMessageCreator(context){
		this.sqlExecutor = new SqlExecutorFactory(context).create()
	}

	def getPriorityErrMessg(String actualValue){
		String minPriority = getPropValue(AIMSql.SEARCH_LIMITS_PRIORITY_MIN)
		String maxPriority = getPropValue(AIMSql.SEARCH_LIMITS_PRIORITY_MAX)
		return createErrMessg(minPriority, maxPriority, actualValue, CommonOptions.PRIOTIRY)
	}

	def getMaxCandidatesErrMessg(String actualValue){
		String minPriority = getPropValue(AIMSql.SEARCH_LIMITS_MAX_CANDIDATES_MIN)
		String maxPriority = getPropValue(AIMSql.SEARCH_LIMITS_MAX_CANDIDATES_MAX)
		return createErrMessg(minPriority, maxPriority, actualValue, CommonOptions.MAX_CANDIDATES)
	}

	def getMinScoreErrMessg(String actualValue){
		String minPriority = getPropValue(AIMSql.SEARCH_LIMITS_MIN_SCORE_MIN)
		String maxPriority = getPropValue(AIMSql.SEARCH_LIMITS_MIN_SCORE_MAX)
		return createErrMessg(minPriority, maxPriority, actualValue, CommonOptions.MIN_SCORE)
	}

	def getDynThreshHitThresholdErrMessg(String actualValue){
		String minPriority = getPropValue(AIMSql.DYNAMIC_THRESHOLD_LIMITS_HIT_THRESHOLD_MIN)
		String maxPriority = getPropValue(AIMSql.DYNAMIC_THRESHOLD_LIMITS_HIT_THRESHOLD_MAX)
		return createErrMessg(minPriority, maxPriority, actualValue, CommonOptions.DYN_THRESH_HIT_THRESHOLD)
	}

	def getDynThreshPercentagePointErrMessg(String actualValue){
		String minPriority = getPropValue(AIMSql.DYNAMIC_THRESHOLD_LIMITS_PERCENTAGE_POINT_MIN)
		String maxPriority = getPropValue(AIMSql.DYNAMIC_THRESHOLD_LIMITS_PERCENTAGE_POINT_MAX)
		return createErrMessg(minPriority, maxPriority, actualValue, CommonOptions.DYN_THRESH_PERCENTAGE_POINT)
	}

	def getPropValue(String key){
		String sql = createSql(key)
		return sqlExecutor.getSqlResultOneRecord(sql)
	}
		
	def createSql(String propName){
		return "select property_value from system_config where property_name = '$propName'"
	}

	def createErrMessg(String min, String max, String actual, String name){
		return "CommonOptions ${name} is ${actual}. SYSTEM_CONFIG min is ${min} max is ${max}"
	}
}
