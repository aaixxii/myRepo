package test.common.message

import common.sql.*
import test.common.util.db.*
import test.common.constants.aim.*

class ConvertErrorMessageCreator{

	SqlExecutor sqlExecutor
	private static final String CVC_PATTERN = "cvc-pattern-valid:"
	private static final String CVC_ENUM = "cvc-enumeration-valid:"	
	private static final String CVC_DATA_TYPE = "cvc-datatype-valid.1.2.1:"	
	private static final String CVC_MININCLUSIVE = "cvc-minInclusive-valid:"
	private static final String CVC_MAXINCLUSIVE = "cvc-maxInclusive-valid:"
	private static final String CVC_COMPLEX_TYPE_21 = "cvc-complex-type.2.1:"
	private static final String CVC_COMPLEX_TYPE_24A = "cvc-complex-type.2.4.a:"
	private static final String CVC_COMPLEX_TYPE_24B = "cvc-complex-type.2.4.b:"
	private static final String CVC_COMPLEX_TYPE_24D = "cvc-complex-type.2.4.d:"
	private static final String CVC_COMPLEX_TYPE_24E = "cvc-complex-type.2.4.e:"
	private static final String CVC_COMPLEX_TYPE_24F = "cvc-complex-type.2.4.f:"
	private static final String CVC_COMPLEX_TYPE4 = "cvc-complex-type.4:"
	private static final String CVC_COMPLEX_TYPE_322 = "cvc-complex-type.3.2.2:"
	private static final String UNMARSHAL_EXCEPTION = "(Class Convert UnmarshalException occurred, Error message: UnmarshalException:"
	private static final String INVALID_PARAM_EXCEPTION = "(Class Convert InvalidParameterException occurred, Error message: InvalidParameterException:"
	
	ConvertErrorMessageCreator(){}

	ConvertErrorMessageCreator(context){
		this.sqlExecutor = new SqlExecutorFactory(context).create()
	}

	public String createTimRotationErrMessg(String actual){
        String expected = makeExpEnumStr(1, 5)
		return createEnumErrMesseg(actual, expected)
	}

	public String getSpeedLevelErrMessg(String actual){
        String expected = makeExpEnumStr(1, 9)
		return createEnumErrMesseg(actual, expected)
	}

	public String getDistortionLevelErrMessg(String actual){
        String expected = makeExpEnumStr(1, 6)
		return createEnumErrMesseg(actual, expected)
    }

	public String getFaceProcessModeErrMessg(String actual){
        String expected = makeExpEnumStr(0, 2)
		return createEnumErrMesseg(actual, expected)
    }

	public String getFaceDetectionModeErrMessg(String actual){
        String expected = makeExpEnumStr(0, 1)
		return createEnumErrMesseg(actual, expected)
    }

	public String getFaceSortingOrderErrMessg(String actual){
        String expected = makeExpEnumStr(0, 1)
		return createEnumErrMesseg(actual, expected)
    }

	public String getFaceAlgorithmErrMessg(String actual){
        String expected = makeExpEnumStr(1, 2)
		return createEnumErrMesseg(actual, expected)
    }

	public String getFaceShrinkFactErrMessg(String actual){
        String expected = makeExpEnumStr(0, 4)
		return createEnumErrMesseg(actual, expected)
    }

	public String getFaceRotationMinErrMessg(String actual){
        String expected = makeExpEnumStr(1, 15)
		return createEnumErrMesseg(actual, expected)
    }

	public String getFaceRotationMaxErrMessg(String actual){
        String expected = makeExpEnumStr(1, 15)
		return createEnumErrMesseg(actual, expected)
    }
	public String getIrisSearchModeErrMessg(String actual){
        String expected = makeExpEnumStr(1, 3)
		return createEnumErrMesseg(actual, expected)
    }

	public String getImageTypeErrMessg(String act){
		String exp = "[0, 1, 2, 3, 4, 5, 7, 8]"
		return createEnumErrMesseg(act, exp)
	}

    private String makeExpEnumStr(int min, int max) {
		StringBuilder sb = new StringBuilder()
        sb.append("[")
        appendVals(sb, min, max)
        sb.delete(sb.length()-2, sb.length())
        sb.append("]")
        return sb.toString()
    }

	public String getGenderErrMessg(String actGender){
		String expGender = "[M, F, U]"
		return createEnumErrMesseg(actGender, expGender)
	}

	public String getYobErrMessg(String actYob){
		String expDataType = "integer"
		return createDataTypeErrMesseg(actYob, expDataType)
	}

	public String createYobMethodErrMessg(String input){
		String expected = "[0, 1]"
		return createEnumErrMesseg(input, expected)
	}

	public String createUseYobFRangeErrMessg(String input){
		String expDataType = "boolean"
		return createDataTypeErrMesseg(input, expDataType)
	}

	public String getRaceErrMessg(String actRace){
		String expRace = "[1, 2, 4, 8, -1]"
		return createEnumErrMesseg(actRace, expRace)
	}

	public String getRegionErrMessg(String actReg){
		String expReg = "[1-9A-FU]+" 
		String regType = "region-type"
		return createPatternErrMesseg(actReg, expReg, regType)
	}	
	
	public String getTenprintPatErrMessg(String actPat){
		String expPat = "[ALRWSU]{10}" 
		String patType = "tenprintPattern-type"
		return createPatternErrMesseg(actPat, expPat, patType)
	}	

	public String getLatentPatErrMessg(String actPat){
		String expPat = "[ALRW]{1,4}|S{1}" 
		String patType = "latentPattern-type"
		return createPatternErrMesseg(actPat, expPat, patType)
	}	
	
	public String getLatentAdjaPatErrMessg(String actPat){
		String expPat = "[ALRWS\\*]{8}"
		String patType = "latentAdjacentPattern-type"
		return createPatternErrMesseg(actPat, expPat, patType)
	}

	public String createFinSelectionModeErrMessg(String input){
        String expected = "[1, 2, 3, 19, 20, 21, 27, 28, 29, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 22, 23, 24, 25, 26, 30, 31, 32, 15, 16, 17, 18, 14]"
		return createEnumErrMesseg(input, expected)
	}

	public String createFilterModeErrMessg(String input){
        String expected = makeExpEnumStr(0, 7)
		return createEnumErrMesseg(input, expected)
	}

	public String createTimSearchModeErrMessg(String input){
		String expected = "[1, 2, 3]"
		return createEnumErrMesseg(input, expected)
	}

	public String createImgEnhErrMessg(def input){
        String expected = makeExpEnumStr(0, 6)
		return createEnumErrMesseg(input as String, expected)
	}

    public String getTooManyEnhErrMessg() {
		return createOverMaxOccursElementErrMessg(10, "enh-type")
    }

    public String createTooManyFingerThErrMessg() {
        return createOverMaxOccursElementErrMessg(10, "fingers-thresholds")
    }

    public String createTooManySegInfoErrMessg() {
        return createOverMaxOccursElementErrMessg(4, "seg-info")
    }

	public String getNullParamErrMesseg(){
		return "${INVALID_PARAM_EXCEPTION} An invalid parameter: source is null.)"
	}

	public String getCoreErrMessg(String actCore){
		String expDataType = "integer"
		return createDataTypeErrMesseg(actCore, expDataType)
	}

	public String getQualityErrMessg(String actQuality){
		String expDataType = "integer"
		return createDataTypeErrMesseg(actQuality, expDataType)
	}

	public String getMinutiaNoErrMessg(String actMinutiaNo){
		String expDataType = "integer"
		return createDataTypeErrMesseg(actMinutiaNo, expDataType)
	}

	public String getMinutiaDataErrMessg(String actMinutiaData){
		String expDataType = "base64Binary"
		return createDataTypeErrMesseg(actMinutiaData, expDataType)
	}

	public String getZoneErrMessg(String actMinutiaData){
		String expDataType = "base64Binary"
		return createDataTypeErrMesseg(actMinutiaData, expDataType)
	}

	public String getSkeletonErrMessg(String actSkeleton){
		String expDataType = "base64Binary"
		return createDataTypeErrMesseg(actSkeleton, expDataType)
	}

    public String createInvalidFeTypeErrMessg(String input) {
        return createInvalidParamErrMessg(input)
    }

    public String createCouldNotGetValueErrMessg(String input) {
		return createInvalidParamErrMessg("couldn't get a value with ${input}")
    }

    public String createCouldNotAnyContainerErrMessg() {
		return createInvalidParamErrMessg("there is not any container ID")
    }

    public String createNumberOfAfisGroupIdErrMessg() {
		return createInvalidParamErrMessg("the number of afis group IDs")
    }

    public String createInvalidAfisGroupIdErrMessg() {
		return createInvalidParamErrMessg("there is a invalid group ID")
    }

    public String createInvalidRegistKeyErrMessg(String input) {
		return createInvalidParamErrMessg("there is a invalid key as ${input}")
    }

    public String createNumberOfSearchRequestErrMessg() {
		return createInvalidParamErrMessg("the number of search-request elements")
    }

    public String createDuplicateConIdsErrMessg() {
		return createInvalidParamErrMessg("container IDs overlap")
    }

    public String createNullOfInqSetErrMessg() {
		return createInvalidParamErrMessg("a inquirySet of a fusion-weight element has null")
    }

    public String createInvalidInqSetErrMessg() {
		return createInvalidParamErrMessg("there is a inquirySet of a fusion-weight element")
    }

    public String createInvalidRefKeyWithConIdErrMessg() {
		return createInvalidParamErrMessg("a combination of container ID and key")
    }

    public String createInvalidParamErrMessg(String input) {
        return "${INVALID_PARAM_EXCEPTION} An invalid parameter: ${input}.)"
    }

    public String createEmptyValueErrMessg() {
        return "${INVALID_PARAM_EXCEPTION} An invalid parameter: value is empty.)"
    }

    public String getOmmitCoreErrMessg() {
        String expectParam="A. F. CC. QD. QQ. X. Y. D"
        return createOmmitReExtParamErrMessg(expectParam)
    }

    public String getOmmitQualityErrMessg() {
        String expectParam="VC. VB. VA"
        return createOmmitReExtParamErrMessg(expectParam)
    }

    public String getOmmitMinutiaNoErrMessg() {
        String expectParam="DB. MB"
        return createOmmitReExtParamErrMessg(expectParam)
    }

    private String createOmmitReExtParamErrMessg(String expectParam) {
        return createNoInitializeErrMesseg(expectParam)
    }

	public String createOmitFaceProcessMessg(){
		String attribute = "processMode"
		String element = "face-input"
		return getUnmarshalExceptMustApperarErrMesseg(attribute, element)
	}

	public String createOmitFacePointNumMessg(){
		String attribute = "num"
		String element = "points"
		return getUnmarshalExceptMustApperarErrMesseg(attribute, element)
	}

	public String createFaceImgAnalysisErrMessg(String input){
		String expDataType = "boolean"
		return createDataTypeErrMesseg(input, expDataType)
	}

	public String createNoInitializeErrMesseg(String input){
        return "(Class Convert NoInitializedException occurred, Error message: NoInitializedException: ${input})"
	}

	public String getDupliCoreErrMesseg(){
		String param="core"
		String element="{quality, minutia-no}"
		return createDupliReExtParamErrMesseg(element, param)
	}

	public String getDupliQualityErrMesseg(){
		String param="quality"
		String element="{minutia-no}"
		return createDupliReExtParamErrMesseg(element, param)
	}

	public String getDupliMinutiaNoErrMesseg(){
		String param="minutia-no"
		return createNoExpectedChildErrMesseg(param)
	}

	public String getDupliUrlErrMesseg(){
        String param="url"
        String element="{seg-info}"
        return createDupliReExtParamErrMesseg(element, param)
    }

    public String getSpecifyUrlAndDataErrMesseg(){
        String param="data"
        String element="{seg-info}"
        return createDupliReExtParamErrMesseg(element, param)
    }

    public String getNoLatentElementErrMesseg(){
        String param="rolled"
        String element="{latent}"
        return createDupliReExtParamErrMesseg(element, param)
    }

    public String getManySetPointElementErrMesseg(){
		int maxOccurs = 10
        String element = "points"
        String attribute = "negative-detection-params"
		return createOverMaxOccursElementErrMessg(10, element, attribute)
    }

	private String createDupliReExtParamErrMesseg(String element, String param){
		return "${UNMARSHAL_EXCEPTION} cvc-complex-type.2.4.a: Invalid content was found starting with element '${param}'. One of '${element}' is expected.)"
	}

    public String createInvalidFmtIdErrMessg(String input) {
        StringBuilder sb = new StringBuilder()
        sb.append("[")
        appendVals(sb, 0, 3)
        appendVals(sb, 5, 14)
        appendVals(sb, 16, 40)
        sb.delete(sb.length()-2, sb.length())
        sb.append("]")
        return createEnumErrMesseg(input, sb.toString())
    }

    public String createInvalidSelectPartsErrMessg(String input) {
        return "${UNMARSHAL_EXCEPTION} ${CVC_PATTERN} Value '${input}' is not facet-valid with respect to pattern '[0]{1}|[1-9A-G]{1,16}' for type 'selectParts-type'.)"
    }

    private void appendVals(StringBuilder sb, int start, int end) {
        for(i in start..end) {
            sb.append("${i}, ")
        }
    }

	private String getLostAttributeErrMesseg(String attribute, String element){
		return getUnmarshalExceptMustApperarErrMesseg(attribute, element)
	}

	public String getNotSetTypeAttributeErrMessg(){
		String attribute  = "type"
		String element = "image"
		return getUnmarshalExceptMustApperarErrMesseg(attribute, element)
	}

	public String getNotSetFaceDetectChildErrMessg(){
		String parent = "detection"
		String child = "aimformats, meta-info, prefilter-options, image"
		return createANotCompleteElementErrMesseg(parent, child)
	}

	public String getNotSetFaceDetectChildAndSetAimFormatsErrMessg(){
		String parent = "detection"
		String child = "meta-info, prefilter-options, image"
		return createANotCompleteElementErrMesseg(parent, child)
	}
	public String getSetManyFaceParamErrMessg(){
		int maxOccurs = 2
		String parent = "params"
		String child = "points, negative-detection-params"
		return createOverMaxOccursElementErrMessg(maxOccurs, parent, child)
	}

	public String getNotSetImageAndSetDataErrMessg(){
		String parent = "data"
		String child = "image"
		return createANotCompleteElementErrMesseg(parent, child)
	}

	public String getNotImageChildErrMessg(){
		String parent = "image"
		String child = "data, url"
		return createNotCompleteElementErrMesseg(parent, child)
	}

	public String getNotDataInMinutiaErrMessg(){
        String parent = "minutia"
        String child = "data"
        return createNotCompleteElementErrMesseg(parent, child)
    }

	public String getDepliMinutiaInMarkUpErrMessg(){
        String parent = "minutia"
        String child = "mark-up"
        return createANotCompleteElementErrMesseg(parent, child)
    }

	public String getNotDataInMarkUpErrMessg(){
        String parent = "mark-up"
        String child = "data"
        return createNotCompleteElementErrMesseg(parent, child)
    }

	public String getDupliMarkUpErrMessg(){
        String element = "mark-up"
        return createNoExpectedChildErrMesseg(element)
    }

    public String getDupliDataErrMessg(){
        String element = "data"
        return createNoExpectedChildErrMesseg(element)
    }

	public String getManySetDetectPointElementErrMesseg(){
		String element = "points"
		return createNoExpectedChildErrMesseg(element)
	}

	public String getNotSetDetectPointElementErrMesseg(){
        String parent = "extraction"
        String child = "points"
		return createNotCompleteElementErrMesseg(parent, child)
	}

	public String getReturnCropImageErrMessg(String actual){
		String expDataType = "boolean"
		return createDataTypeErrMesseg(actual, expDataType)
	}

	public String getCenterHasChildrenErrMessg(){
		String element = "center"
		return createElementHasNoChildrenErrMesseg(element)
	}

    public String createInvalidKeyErrMessg() {
        return "${INVALID_PARAM_EXCEPTION} An invalid parameter: there is a invalid key.)"
    }

    public String createInvalidConIdErrMessg() {
        return "${INVALID_PARAM_EXCEPTION} An invalid parameter: there is a invalid container ID.)"
    }

	private String getUnmarshalExceptMustApperarErrMesseg(String attribute, String element){
		return "${UNMARSHAL_EXCEPTION} ${CVC_COMPLEX_TYPE4} Attribute '${attribute}' must appear on element '${element}'.)"
	}

	private String createPatternErrMesseg(String actual, String expected, String patType){
		return "${UNMARSHAL_EXCEPTION} ${CVC_PATTERN} Value '${actual}' is not facet-valid with respect to pattern '${expected}' for type '${patType}'.)"
	}

	private String createEnumErrMesseg(String actual, String expected){
		return "${UNMARSHAL_EXCEPTION} ${CVC_ENUM} Value '${actual}' is not facet-valid with respect to enumeration '${expected}'. It must be a value from the enumeration.)"
	}
	
	private String createDataTypeErrMesseg(String actual, String expected){
		return "${UNMARSHAL_EXCEPTION} ${CVC_DATA_TYPE} '${actual}' is not a valid value for '${expected}'.)"
	}
	
	private String createNoExpectedChildErrMesseg(String element){
		return "${UNMARSHAL_EXCEPTION} ${CVC_COMPLEX_TYPE_24D} Invalid content was found starting with element '${element}'. No child element is expected at this point.)"
	}

	private String createTooManyIrisImgMessg(){
		return createTooManyImgMessg(2)
	}

	private String createTooManyImgMessg(int maxOccurs){
		return createOverMaxOccursElementErrMessg(maxOccurs, "image")
	}

	private String createANoExpectedChildErrMesseg(String element){
		return "${UNMARSHAL_EXCEPTION} ${CVC_COMPLEX_TYPE_24D} Invalid content was found starting with element '${element}'. No child element is expected at this point.)"
	}

	private String createNotAllowedAttributeErrMesseg(String element, String attribute){
		return "${UNMARSHAL_EXCEPTION} ${CVC_COMPLEX_TYPE_322} Attribute '${attribute}' is not allowed to appear in element '${element}'.)"
	}

	private String createNotCompleteElementErrMesseg(String parent, String child){
		return "${UNMARSHAL_EXCEPTION} ${CVC_COMPLEX_TYPE_24B} The content of element '${parent}' is not complete. One of '{${child}}' is expected.)"
	}

	private String createANotCompleteElementErrMesseg(String parent, String child){
		return "${UNMARSHAL_EXCEPTION} ${CVC_COMPLEX_TYPE_24A} Invalid content was found starting with element '${parent}'. One of '{${child}}' is expected.)"
	}

	private String createMinInclusiveErrMesseg(String actual, String min, String attribute){
		return "${UNMARSHAL_EXCEPTION} ${CVC_MININCLUSIVE} Value '${actual}' is not facet-valid with respect to minInclusive '${min}' for type '${attribute}'.)"
	}

	private String createMaxInclusiveErrMesseg(String actual, String max, String attribute){
		return "${UNMARSHAL_EXCEPTION} ${CVC_MAXINCLUSIVE} Value '${actual}' is not facet-valid with respect to maxInclusive '${max}' for type '${attribute}'.)"
	}

	private String createElementHasNoChildrenErrMesseg(String element){
		return "${UNMARSHAL_EXCEPTION} ${CVC_COMPLEX_TYPE_21} Element '${element}' must have no character or element information item [children], because the type's content type is empty.)"
	}

	private String createOverMaxOccursElementErrMessg(int maxOccurs, String parent, String child){
		return "${UNMARSHAL_EXCEPTION} ${CVC_COMPLEX_TYPE_24E} '${parent}' can occur a maximum of '${maxOccurs}' times in the current sequence. This limit was exceeded. At this point one of '{${child}}' is expected.)"
	}

	private String createOverMaxOccursElementErrMessg(int maxOccurs, String parent){
		return "${UNMARSHAL_EXCEPTION} ${CVC_COMPLEX_TYPE_24F} '${parent}' can occur a maximum of '${maxOccurs}' times in the current sequence. This limit was exceeded. No child element is expected at this point.)"
	}
}
