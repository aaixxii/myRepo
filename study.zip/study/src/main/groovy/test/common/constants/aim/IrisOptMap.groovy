package test.common.constants.aim

class IrisOptMap {
	def defaultParamMap=[
		"searchMode":"2",
		"rotationLimit" :"15",
	]
}

