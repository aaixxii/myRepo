package test.common.constants.aim

class CmlPayloadMap implements PayloadMapIF {

    def metaCommonMap = new MetaCommonMap().getDefaultParamMap()
    def cmlOptMap = new CmlOptMap().getDefaultParamMap()

    public List getAllMaps() {
        List mapList = []
        mapList << metaCommonMap
        mapList << cmlOptMap
        return mapList
    }
}

