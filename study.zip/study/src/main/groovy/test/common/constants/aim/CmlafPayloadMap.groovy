package test.common.constants.aim

class CmlafPayloadMap implements PayloadMapIF {

    def metaCommonMap = new MetaCommonMap().getDefaultParamMap()
    def cmlafOptMap = new CmlafOptMap().getDefaultParamMap()
    def matchableFinThOptMap = new MatchableFinThOptMap().getDefaultParamMap()
    def fingerThresholdsOptMap = new FingerThresholdsOptMap().getDefaultParamMap()

    public List getAllMaps() {
        List mapList = []
        mapList << metaCommonMap
        mapList << cmlafOptMap
        mapList << matchableFinThOptMap
        mapList << fingerThresholdsOptMap
        return mapList
    }
}

