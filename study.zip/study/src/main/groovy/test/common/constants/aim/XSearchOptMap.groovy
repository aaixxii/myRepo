package test.common.constants.aim

class XSearchOptMap{
	def defaultParamMap=[
		"applyLeOpt":"false",
		"le-algo" :"1",
		"le-rotLim":"1",
		"le-corePos":"1",
		"pc2-applySpdLv":"false",
		"pc2-spdLv":"6",
		"pc2-applyRotLim":"false",
		"pc2-rotLim":"1",
		"pc2-applyDistLv":"false",
		"pc2-distLv":"1",
		"pc2-rotByAxis":"false",
		"updatePrefilterOpt":"false",
		"useGender":"false",
		"gender":"U",
		"yobMethod":"0",
		"useYob":"false",
		"yob":"-1",
		"useYobFRange":"false",
		"yobRange":"-1",
		"usePattern":"false",
		"useFingerNo":"false",
		"useRace":"false",
		"race":"-1",
		"useRegion":"false",
		"region":"U",	
	]
}

