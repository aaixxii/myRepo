package test.common.constants.aim

class CommonOptMapNoCallbackUrl {
    def defaultParamMap = [
        "priority":"10",
        "maxCandidates":"10",
        "minScore":"100",
        "dynThreshPercentagePoint":"5.2",
        "dynThreshHitThreshold":"2000",
		"consolidateByContainer":"true",
		"multiRecordCandidates":"false"
    ]
}

