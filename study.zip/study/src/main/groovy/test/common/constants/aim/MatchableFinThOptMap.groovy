package test.common.constants.aim

class MatchableFinThOptMap {
	def defaultParamMap = [
		"applyMatchableFingersThresholds":"false",
	]
}

