package test.common.constants.aim

class PrefilterOptMap {
	def defaultParamMap = [
		"updatePrefilter":"false",
		"yobMethod":"0",
		"useYobFRange":"false",
	]
}

