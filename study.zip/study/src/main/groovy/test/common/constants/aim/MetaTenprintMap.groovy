package test.common.constants.aim

class MetaTenprintMap {
	def defaultParamMap = [
		"primaryPatterns":"SSSSSSSSSS",
		"referencePatterns":"UUUUUUUUUU",
	]
}

