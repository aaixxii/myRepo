package test.common.constants.aim

class LixSearchOptMap extends XSearchOptMap {

	public LixSearchOptMap() {
		super.defaultParamMap.put("pattern", "S")
		super.defaultParamMap.put("finger", "0123456789")
		super.defaultParamMap.put("priAdPat", "********")
		super.defaultParamMap.put("refAdPat", "********")
	}
}

