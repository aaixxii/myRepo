package test.common.constants.aim

class PalmOptMap {
	def defaultParamMap=[
		"applyPalmOptions":"false",
		"speedLevelPrimary" :"6",
		"speedLevelSecondary":"3",
		"rotationLimit":"1",
		"distortionLevelPrimary":"2",
		"distortionLevelSecondary":"4",
	]
}

