package test.common.constants.aim

class IrisPayloadMap implements PayloadMapIF {

    def metaCommonMap = new MetaCommonMap().getDefaultParamMap()
    def prefilterOptMap = new PrefilterOptMap().getDefaultParamMap()
    def usePrefilterInfoMap = new UsePrefilterInfoMap().getDefaultParamMap()
    def irisOptMap = new IrisOptMap().getDefaultParamMap()

    public List getAllMaps() {
        List mapList = []
        mapList << metaCommonMap
        mapList << prefilterOptMap
        mapList << usePrefilterInfoMap
        mapList << irisOptMap
        return mapList
    }
}

