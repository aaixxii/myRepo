package test.common.constants.aim

class AIMBioPosition{

	static final int FINGER_UNKNOWN		 = 0
	static final int ROLLED_RIGHT_THUMB  = 1
	static final int ROLLED_RIGHT_INDEX  = 2
	static final int ROLLED_RIGHT_MIDDLE = 3
	static final int ROLLED_RIGHT_RING 	 = 4
	static final int ROLLED_RIGHT_LITTLE = 5
	static final int ROLLED_LEFT_THUMB   = 6
	static final int ROLLED_LEFT_INDEX   = 7
	static final int ROLLED_LEFT_MIDDLE  = 8
	static final int ROLLED_LEFT_RING    = 9
	static final int ROLLED_LEFT_LITTLE  = 10
	static final int SLAP_RIGHT_THUMB 	 = 11
	static final int SLAP_RIGHT_INDEX	 = 40
	static final int SLAP_RIGHT_MIDDLE   = 41
	static final int SLAP_RIGHT_RING     = 42
	static final int SLAP_RIGHT_LITTLE   = 43
	static final int SLAP_LEFT_THUMB	 = 12
	static final int SLAP_LEFT_INDEX	 = 44
	static final int SLAP_LEFT_MIDDLE	 = 45
	static final int SLAP_LEFT_RING		 = 46
	static final int SLAP_LEFT_LITTLE	 = 47


	static final int PALM_UNKNOWN  		 = 20
	static final int PALM_RIGHT_FULL	 = 21
	static final int PALM_RIGHT_WRITER   = 22
	static final int PALM_LEFT_FULL		 = 23
	static final int PALM_LEFT_WRITER	 = 24
	static final int PALM_RIGHT_LOWER	 = 25
	static final int PALM_RIGHT_UPPER	 = 26
	static final int PALM_LEFT_LOWER	 = 27
	static final int PALM_LEFT_UPPER	 = 28
	static final int PALM_RIGHT_OTHER	 = 29
	static final int PALM_LEFT_OTHER	 = 30
	static final int PALM_RIGHT_INTERDIGITAL = 31
	static final int PALM_RIGHT_THENAR	 = 32
	static final int PALM_RIGHT_HYPOTHENAR  = 33
	static final int PALM_LEFT_INTERDIGITAL = 34
	static final int PALM_LEFT_THENAR	  = 35
	static final int PALM_LEFT_HYPOTHENAR = 36
	
	static final int IRIS_RIGHT = 61
	static final int IRIS_LEFT  = 62

}
