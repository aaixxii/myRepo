package test.common.constants.aim


class AIMImgType{
	static final int TYPE_RAW = 0
	static final int TYPE_WSQ = 1
	static final int TYPE_JPEG2000 = 2
	static final int TYPE_JPEG = 3
	static final int TYPE_BMP = 4
	static final int TYPE_PNG = 5
	static final int TYPE_NEC_GRAY = 7
	static final int TYPE_WSQ4BIT = 8
}
