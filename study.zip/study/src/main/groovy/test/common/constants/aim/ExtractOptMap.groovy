package test.common.constants.aim

class ExtractOptMap{
	def defaultParamMap=[
		"gender":"U",
		"yob":"-1",
		"yobRange":"-1",
		"race":"-1",
		"region":"U",
		"primaryPatterns":"SSSSSSSSSS",
		"referencePatterns":"UUUUUUUUUU",
		"selectFingers":"0123456789",
		"latentPatterns":"S",
		"primaryAdjacentPatterns":"********",
		"referenceAdjacentPatterns":"********",
		"enhancements":"",
	]
}
