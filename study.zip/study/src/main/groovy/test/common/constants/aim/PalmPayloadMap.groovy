package test.common.constants.aim

class PalmPayloadMap implements PayloadMapIF {

    def metaCommonMap = new MetaCommonMap().getDefaultParamMap()
    def metaTenprintMap = new MetaTenprintMap().getDefaultParamMap()
    def metaLatentMap = new MetaLatentMap().getDefaultParamMap()
    def palmOptMap = new PalmOptMap().getDefaultParamMap()
    def prefilterOptMap = new PrefilterOptMap().getDefaultParamMap()
    def usePrefilterInfoMap = new UsePrefilterInfoMap().getDefaultParamMap()

    public List getAllMaps() {
        List mapList = []
        mapList << metaCommonMap
        mapList << metaTenprintMap
        mapList << metaLatentMap
        mapList << palmOptMap
        mapList << prefilterOptMap
        mapList << usePrefilterInfoMap
        return mapList
    }
}

