package test.common.constants.aim

class CommonOptMap{
    def defaultParamMap=[
        "callbackUrl":"http://localhost:54321",
        "priority":"10",
        "LOC":"10",
        "minScore":"100",
        "dynHitThreshold":"2000",
        "dynPercentPoint":"5.2",
		"consolidateByContainer":"true",
		"multiRecordCandidates":"false"
    ]
}

