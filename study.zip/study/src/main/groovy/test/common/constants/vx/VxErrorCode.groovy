package test.common.constants.vx

class VxErrorCode {
	static final String GENERAL_ERROR = "854001001"
	static final String VALIDATION_ERROR = "854001003"
	static final String DECODE_ERROR = "864000004"
	
	static final String INVALID_DATA_TYPE = "164000002"
	static final String INVALID_ALGORITHM = "854001003"
	static final String INVALID_IMAGE_POSITION = "164000004"
	static final String UNSUPPORTED_DATA_TYPE = "164000108"
	static final String UNSUPPORTED_TEMPLATE = "164000109"
	static final String DUPLICATE_POSITION = "164000014"
	static final String NO_CORRESPONDING_FINGER = "164000016"
	static final String TOO_MANY_FINGERS = "164000022"
	static final String TEMPLATE_ERROR = "164000102"
	static final String INVALID_FUSION_NUM = "164000110"
	static final String INVALID_RAW_SIZE = "164000112"
	static final String INVALID_RAW_DPI = "164000113"
	static final String UNSUPPORTED_ALGORITHM = "854001003"
	static final String UNSUPPORTED_FUSION_NUMBER = "164000115"
	static final String UNSUPPORTED_FINGER_NUMBER = "164000117"
	static final String INVALID_RAW_WIDTH = "164000028"
	static final String INVALID_RAW_HEIGHT = "164000029"
	static final String NO_VP_IS_AVAILABLE = "154001001"
	static final String INVALID_MINUTIA = "164000106"
	static final String INVALID_UPDATE_NUMBER = "164000121"
	static final String DUPLICATE_IMAGE = "164000120"
	static final String TOO_MANY_TEMPLATES = "164000025"
	
}
