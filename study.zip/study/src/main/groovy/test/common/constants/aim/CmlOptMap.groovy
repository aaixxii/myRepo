package test.common.constants.aim

class CmlOptMap {
	def defaultParamMap = [
		"filterMode":"0",
		"applyGender":"false",
		"applyYob":"false",
		"applyYobThreshold":"false",
		"yobThreshold":"-1",
		"applyParameterId":"false",
		"parameterId":"1",
		"applyRotationLimit":"false",
		"rotationLimit":"3",
	]
}

