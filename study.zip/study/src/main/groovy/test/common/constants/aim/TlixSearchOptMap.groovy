package test.common.constants.aim

class TlixSearchOptMap extends XSearchOptMap {

	public TlixSearchOptMap() {
		super.defaultParamMap.put("priPattns", "SSSSSSSSSS")
		super.defaultParamMap.put("refPattns", "UUUUUUUUUU")
	}
}

