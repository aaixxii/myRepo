package test.common.constants.aim

class FingerThresholdsOptMap {
	def defaultParamMap = [
		"finTh1":"1,0.55,0,0.0,1,9",
		"finTh2":"2,0.55,0,0.0,1,9",
		"finTh3":"3,0.65,0,0.0,1,9",
		"finTh4":"4,0.65,0,0.1,100,9",
		"finTh5":"5,0.85,4,0.1,200,9",
		"finTh6":"6,0.85,4,0.1,200,9",
		"finTh7":"7,0.85,4,0.1,200,9",
		"finTh8":"8,0.85,4,0.1,200,9",
		"finTh9":"9,0.85,4,0.1,200,9",
		"finTh10":"10,0.85,4,0.2,200,9",
	]
}

