package test.common.constants.aim

class MMMessenger{
	static final String MUST_BE_GIVEN_CONTAINER_ID = "At least one search container id must be given."
	static final String NO_ENTITY_FOUND_FOR_QUERY  = "No entity found for query"
	static final String JAVA_SQL_EXCEPTION = "java.sql.SQLException"
	static final String COUDNT_RESOLVE_EXTRACT = "Couldn't resolve reference to extraction result for job ID"
}

