package test.common.constants.aim

class AIMXmlAttribute{

	static final String PC2_ROLLED = "PC2_Rolled"
	static final String PC2_SLAP = "PC2_Slap"
	static final String FMP5_ROLLED = "Fmp5_Rolled"
	static final String FMP5_SLAP = "Fmp5_Slap"
	static final String PC2_LATENT = "PC2_Latent"
	static final String FMP5_LATENT = "Fmp5_Latent"

	static final String GEN = "gender" 
	static final String RACE = "race"
	static final String REGION = "region"
	static final String YOB = "yob"
	static final String YOBR = "yobRange"

	static final String PPATTERN = "primaryPatterns"
	static final String RPATTERN = "referencePatterns"

	static final String LPATTERN = "latentPatterns"
	static final String PADJ = "primaryAdjacentPatterns"
	static final String RADJ = "referenceAdjacentPatterns"
	static final String SFIN = "selectFingers"

	static final String APP_DIS_LEVEL = "applyDistortionLevel"
	static final String APP_ROTATION_LIMIT = "applyRotationLimit"
	static final String APP_SPEED_LEVEL = "applySpeedLevel"
	static final String DIS_LEVEL = "distortionLevel"
	static final String ROTATION_LIMIT = "rotationLimit"
	static final String SPEED_LEVEL = "speedLevel"
	static final String ROTATION_BY_AXIS = "rotationByAxis"

	static final String ALGORITHM = "algorithm"
	static final String APP_LE_OPT = "applyLeOptions"
	static final String CORE_POS = "corePosition"

	static final String APP_SEARCH_LEVEL = "applySearchLevel"
	static final String APP_P_SPEED_LEVEL = "applySpeedLevelPrimary"
	static final String APP_S_SPEED_LEVEL = "applySpeedLevelSecondary"
	static final String APP_P_DIS_LEVEL = "applyDistortionLevelPrimary"
	static final String APP_S_DIS_LEVEL = "applyDistortionLevelSecondary"
	static final String SEARCH_LEVEL = "searchLevel"
	static final String P_SPEED_LEVEL = "speedLevelPrimary"
	static final String S_SPEED_LEVEL = "speedLevelSecondary"
	static final String P_DIS_LEVEL = "distortionLevelPrimary"
	static final String S_DIS_LEVEL = "distortionLevelSecondary"

	static final String UP_PRE = "updatePrefilter"
	static final String USE_YOBFR = "useYobFRange"
	static final String YOBM = "yobMethod"
	static final String USE_FIN = "useFingerNo"
	static final String USE_GEN = "useGender"
	static final String USE_PATTERN = "usePattern"
	static final String USE_RACE = "useRace"
	static final String USE_REGION = "useRegion"
	static final String USE_YOB = "useYob"
}
	
