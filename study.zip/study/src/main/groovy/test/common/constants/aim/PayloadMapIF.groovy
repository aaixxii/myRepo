package test.common.constants.aim

interface PayloadMapIF {

    public List getAllMaps() 

}

