package test.common.constants.aim

class MUMessenger{
	static final String EXTRACT_ERR_NO_MINUTIA 		 = "Error extracting feature data(no minutia) for finger"
	static final String ERROR_CONVERT_24BIT_RAW_IMG 		 = "An error occured in converting 24-bit raw to gray raw."
	
	static final String INVALID_THUMBS_SEG_OCCURENCE = "Invalid payload data SLAP SEGMENT INFO (the occurence of thumbs segmen-info element should be 1 or 2.)"
	static final String INVALID_SLAP4_SEG_OCCURENCE = "Invalid payload data SLAP SEGMENT INFO (the occurence of slap4 segmen-info element should be from 1 to 4.)"
	static final String INCONSISTENT_CROP_POINTS	 = "Invalid payload data SLAP CROP POINTS (inconsistent values between two points elements."

	static final String INVALID_REEXT_MINUTIA = "Invalid input-minutia in payload(A input-minutia element does not appear.)"
	static final String INVALID_REEXT_DUPLICATE = "Invalid input-minutia in payload(A input-minutia element appears more than once.)"
	static final String INVALID_REEXT_MINUTIA_COUNT = "Invalid input-minutia in payload (minutia data count of re-extraction should be 1)"
	static final String INVALID_IMAGE_POS = "Invalid payload IMAGE INFO (image-pos attribute is invalid.(13))"
	static final String INVALID_DUPLICATE = "Invalid input-minutia-data in payload (A finger position which is 1 appears more than twice.)"
	static final String INVALID_WIDTH_INFO = "Invalid payload IMAGE INFO (Invalid width(800) of decoded image.)"
	static final String INVALID_MIN_POSITION = "Invalid input-minutia-data in payload (A finger position is 13)"
	static final String INVALID_MIN_DUPLICATE = "Invalid input-minutia-data in payload (A finger position which is 1 appears more than twice.)"
	static final String INVALID_NUM = "Invalid input-minutia in payload (input-minutia-data (rolled right-index) is not found.)"
	static final String INVALID_NO_IMAGE = "Invalid input-minutia in payload (input-minutia-data was specified without targeting image.)"
	static final String INVALID_NO_FIS = "Invalid input-minutia in payload (input-minutia-data (rolled left-little) is not found.)"
	static final String INVALID_DB_TYPE = "Invalid input-minutia in payload(A dbType is RDBT)"
	static final String INVALID_MIN_TYPE = "Invalid input-minutia in payload(A minutiaType is PC3)"
	static final String INVALID_PAYLOAD_EXT_FMT_DUPLICATE = "Invalid payload EXTRACT FORMAT (Duplicate format.)"
	static final String INVALID_FORMAT_RE_EXT_PAYLOAD = "Invalid payload EXTRACT FORMAT (In case of re-extract, supported formats is only TIM, DBTM and DBLM )"
	static final String INVALID_PAYLOAD_EXT_URL_EMPTY = "image url is empty."

	static final String INVALID_FACE_DETECT_PARAM = "failure in setting 1st detect parameter"
	static final String INVALID_FACE_DETECT_EYEMIN_EQUALS_EYEMAX = "Invalid payload Face Detection Option(eyeMin and eyeMax, two values equal.)"
	static final String INVALID_FACE_DETECTION_OUTPUT = "detection result has invalid property."
	static final String UNEXPECTED_FACE_DETECT_RESULT_VAL_HEAD_RECTANGLE = "detection result has unexpected property value.(Head Rectangle)"


	static final String INVALID_ENH_TYPE = "Invalid payload ENHANCE (image-enhance enh-type is invalid.())"
	static final String OUT_OF_SCOPE_ENH = "Invalid payload ENHANCE (image-enhance enh-type is invalid.(11))"
	static final String INVALID_ENH_SIZE = "Invalid payload ENHANCE (requesting too many image enhancements)"

	static final String FAILED_IN_EXTRACTING_FISFEXT_HYB = "failure in extracting feature data. (FisFext_HYB:flat image)"

	static final String INVALID_FW_0 = "Invalid payload FUSION WEIGHT (0)"
	static final String INVALID_FW_MINUS1 = "Invalid payload FUSION WEIGHT (-1)"

	static final String IRIS_POS_DUPLICATED = "Iris image position is duplicated."
	static final String IRIS_DIFFERENT_PUPIL_TYPE = "Invalid iris detection parameter( different variable type in min pupil and max pupil)"
	static final String IRIS_DIFFERENT_IRIS_TYPE = "Invalid iris detection parameter( different variable type in min iris and max iris)"
	static final String IRIS_MIN_PUPIL_GREATER_THAN_MAX = "Invalid iris detection parameter( min pupil (%s) >= max pupil radius(%s))"
	static final String IRIS_MIN_IRIS_GREATER_THAN_MAX = "Invalid iris detection parameter( min iris (%s) >= max iris(%s))"
    static final String IRIS_OUT_OF_RANGE_MIN_PUPIL = "Invalid iris detection parameter(minimum pupil radius.)(%s)"
    static final String IRIS_OUT_OF_RANGE_MIN_IRIS = "Invalid iris detection parameter(minimum iris radius.)(%s)"
    static final String INVALID_NIRIS_II_TEMPLATE_SIZE = "Unexpected II template size. (expect size:%d, actual size:%d)"
    static final String MISMATCHING_MUCONF_IRIS_ENABLE_FLAG = "error in matching process : Mismatching between the specifed search function and MuConfig Iris Enable flag."
    static final String MISMATCHING_MUCONF_IRIS_ENABLE_FLAG_EXTRACT = "Invalid PAYLOAD (Mismatching between the specified aim format and MuConfig Iris Enable flag.)"

    static final String NO_SPECIFIED_IMAGE_SIZE = "Image size must be fixed width(%d) and height(%d).actual size width=0 height=0"
    
	static final String CML_PARAMETER_FILE_LOAD_FAILURE = "CML extract parameter file load failure (ParameterID:%s)."
	static final String NOT_SUPPORT_RE_EXT_PAYLOAD = "Not supported payload (re-extract option)"

}

