package test.common.constants.aim

class SearchLFMLParameter{
	
	static final def LIM_AUTO_F8_SL1_FILE_INDEX_LIST = [ "0", "1", "2", "3", "4", "5", "6", "7", "4", "0", "4", "2", "0","0", "3", "5" ]
	static final def LIM_AUTO_F8_SL1_SEARCH_INDEX_LIST = [ "9", "8", "2", "10", "7", "3", "4",  "1", "5", "15", "11", "12", "13", "6", "14", "0" ]
	static final def LIM_AUTO_F8_SL3_FILE_INDEX_LIST = [ "0", "1", "2", "3", "4", "5", "6", "7", "4", "0", "4", "2", "0","0", "3", "5" ]
	static final def LIM_AUTO_F8_SL3_SEARCH_INDEX_LIST = [ "9", "8", "2", "10", "7", "3", "4",  "1", "5", "15", "11", "12", "13", "6", "14", "0" ]
	static final def LIM_AUTO_F8_SL5_FILE_INDEX_LIST = [ "0", "1", "2", "3", "4", "5", "6", "7", "4", "0", "4", "2", "0","0", "3", "5" ]
	static final def LIM_AUTO_F8_SL5_SEARCH_INDEX_LIST = [ "9", "8", "2", "10", "7", "3", "4",  "1", "5", "15", "11", "12", "13", "6", "14", "0" ]

	static final def LIM_MANUAL_F8_SL1_FILE_INDEX_LIST = [ "0", "1", "0", "1", "2", "3", "4", "5", "6", "7", "4", "0", "2","3", "4", "5"]
	static final def LIM_MANUAL_F8_SL1_SEARCH_INDEX_LIST = ["0", "0", "9", "8", "2", "10", "7", "3", "4",  "1", "5", "15", "0", "0", "0", "0"]
	static final def LIM_MANUAL_F8_SL3_FILE_INDEX_LIST = [ "0", "1", "0", "1", "2", "3", "4", "5", "6", "7", "4", "0", "2","3", "4", "5"]
	static final def LIM_MANUAL_F8_SL3_SEARCH_INDEX_LIST = ["0", "0", "9", "8", "2", "10", "7", "3", "4",  "1", "5", "15", "0", "0", "0", "0"]
	static final def LIM_MANUAL_F8_SL5_FILE_INDEX_LIST = [ "0",  "0", "1", "2", "3", "4", "5", "6", "7", "4", "0", "1", "2","3", "4", "5"]
	static final def LIM_MANUAL_F8_SL5_SEARCH_INDEX_LIST = ["0", "9", "8", "2", "10", "7", "3", "4",  "1", "5", "15", "0","0", "0", "0", "0"]

	static final def TLIM_AUTO_F8_SL1_FILE_INDEX_LIST = [ "0", "1", "2", "3", "4", "5", "6", "7", "4", "0", "4", "2", "0", "0", "3", "5" ]
	static final def TLIM_AUTO_F8_SL1_SEARCH_INDEX_LIST = [ "9", "8", "2", "10", "7", "3", "4", "1", "5", "15", "11", "12", "13", "6", "14", "0" ]
	static final def TLIM_AUTO_F8_SL3_FILE_INDEX_LIST = [ "0", "1", "2", "3", "4", "5", "6", "7", "4", "0", "4", "2", "0", "0", "3", "5" ]
	static final def TLIM_AUTO_F8_SL3_SEARCH_INDEX_LIST = [ "9", "8", "2", "10", "7", "3", "4", "1", "5", "15", "11", "12", "13", "6", "14", "0" ]
	static final def TLIM_AUTO_F8_SL5_FILE_INDEX_LIST = [ "0", "1", "2", "3", "4", "5", "6", "7", "4", "0", "4", "2", "0", "0", "3", "5" ]
	static final def TLIM_AUTO_F8_SL5_SEARCH_INDEX_LIST = [ "9", "8", "2", "10", "7", "3", "4", "1", "5", "15", "11", "12", "13", "6", "14", "0" ]

	static final def TLIM_MANUAL_F8_SL1_FILE_INDEX_LIST =[ "0", "1", "0", "1", "2", "3", "4", "5", "6", "7", "4", "0", "2", "3", "4", "5" ]
	static final def TLIM_MANUAL_F8_SL1_SEARCH_INDEX_LIST =  [ "0", "0", "9", "8", "2", "10", "7", "3", "4", "1", "5", "15", "0", "0", "0", "0" ]
	static final def TLIM_MANUAL_F8_SL3_FILE_INDEX_LIST =[ "0", "1", "0", "1", "2", "3", "4", "5", "6", "7", "4", "0", "2", "3", "4", "5" ]
	static final def TLIM_MANUAL_F8_SL3_SEARCH_INDEX_LIST =  [ "0", "0", "9", "8", "2", "10", "7", "3", "4", "1", "5", "15", "0", "0", "0", "0" ]
	static final def TLIM_MANUAL_F8_SL5_FILE_INDEX_LIST =[ "0", "0", "1", "2", "3", "4", "5", "6", "7", "4", "0", "1", "2", "3", "4", "5" ]
	static final def TLIM_MANUAL_F8_SL5_SEARCH_INDEX_LIST =  [ "0", "9", "8", "2", "10", "7", "3", "4", "1", "5", "15", "0","0", "0", "0", "0" ]

	static final def S_AUTO_F_AUTO_SL1_FILE_INDEX_LIST = [ "3", "6", "14", "4", "11", "12", "13", "5", "2", "7", "9", "0", "8","1", "15", "10" ]
	static final def S_AUTO_F_AUTO_SL1_SEARCH_INDEX_LIST = [ "3", "6", "14", "4", "11", "12", "13", "5", "2", "7", "9", "0", "8","1", "15", "10" ]
	static final def S_AUTO_F_AUTO_SL3_FILE_INDEX_LIST = [ "3", "6", "14", "4", "11", "12", "13", "5", "2", "7", "9", "0", "8","1", "15", "10" ]
	static final def S_AUTO_F_AUTO_SL3_SEARCH_INDEX_LIST = [ "3", "6", "14", "4", "11", "12", "13", "5", "2", "7", "9", "0", "8","1", "15", "10" ]
	static final def S_AUTO_F_AUTO_SL5_FILE_INDEX_LIST = [ "3", "6", "14", "4", "11", "12", "13", "5", "2", "7", "9", "0", "8","1", "15", "10" ]
	static final def S_AUTO_F_AUTO_SL5_SEARCH_INDEX_LIST = [ "3", "6", "14", "4", "11", "12", "13", "5", "2", "7", "9", "0", "8","1", "15", "10" ]

	static final def S_AUTO_F_MANUAL_SL1_FILE_INDEX_LIST =  [ "0", "3", "6", "14", "4", "11", "12", "13", "5", "2", "7", "9", "8","1", "15", "10" ] 
	static final def S_AUTO_F_MANUAL_SL1_SEARCH_INDEX_LIST =  [ "0", "0", "0", "0" , "4", "11", "12", "13", "5", "2", "7", "9", "0","0", "0", "0" ]
	static final def S_AUTO_F_MANUAL_SL3_FILE_INDEX_LIST =   [ "0", "3", "6", "14", "4", "11", "12", "13", "5", "2", "7", "9", "8","1", "15", "10" ]
	static final def S_AUTO_F_MANUAL_SL3_SEARCH_INDEX_LIST =  [ "0", "0", "6", "14", "4", "11", "12", "13", "5", "2", "0", "0", "0","0", "0", "0" ]
	static final def S_AUTO_F_MANUAL_SL5_FILE_INDEX_LIST =   [ "0", "3", "6", "14", "4", "11", "12", "13", "5", "2", "7", "9", "8","1", "15", "10" ]
	static final def S_AUTO_F_MANUAL_SL5_SEARCH_INDEX_LIST = [ "0", "0", "6", "14", "4", "11", "12", "13", "5", "2", "0", "0", "0","0", "0", "0" ]

	static final def S_MANUAL_F_AUTO_SL1_FILE_INDEX_LIST =   [ "0", "0", "0", "0" , "4", "11", "12", "13", "5", "2", "7", "9", "0","0", "0", "0" ]
	static final def S_MANUAL_F_AUTO_SL1_SEARCH_INDEX_LIST = [ "0", "3", "6", "14", "4", "11", "12", "13", "5", "2", "7", "9", "8","1", "15", "10" ]
	static final def S_MANUAL_F_AUTO_SL3_FILE_INDEX_LIST =   [ "0", "0", "6", "14", "4", "11", "12", "13", "5", "2", "0", "0", "0","0", "0", "0" ]
	static final def S_MANUAL_F_AUTO_SL3_SEARCH_INDEX_LIST = [ "0", "3", "6", "14", "4", "11", "12", "13", "5", "2", "7", "9", "8","1", "15", "10" ]
	static final def S_MANUAL_F_AUTO_SL5_FILE_INDEX_LIST =   [ "0", "0", "6", "14", "4", "11", "12", "13", "5", "2", "0", "0", "0","0", "0", "0" ]
	static final def S_MANUAL_F_AUTO_SL5_SEARCH_INDEX_LIST = [ "0", "3", "6", "14", "4", "11", "12", "13", "5", "2", "7", "9", "8","1", "15", "10" ]

	static final def S_MANUAL_F_MANUAL_SL1_FILE_INDEX_LIST =   [ "0", "0", "6", "14", "4", "11", "12", "13", "5", "2", "7", "9", "0","1", "0", "10" ]
	static final def S_MANUAL_F_MANUAL_SL1_SEARCH_INDEX_LIST = [ "0", "3", "0", "14", "4", "11", "12", "13", "5", "2", "7", "0", "8","0", "15", "0" ]
	static final def S_MANUAL_F_MANUAL_SL3_FILE_INDEX_LIST =   [ "0", "3", "6", "14", "4", "11", "12", "13", "5", "2", "0", "9", "0","1", "0", "10" ]
	static final def S_MANUAL_F_MANUAL_SL3_SEARCH_INDEX_LIST = [ "0", "3", "6", "14", "4", "11", "12", "13", "5", "0", "7", "0", "8","0", "15", "0" ]
	static final def S_MANUAL_F_MANUAL_SL5_FILE_INDEX_LIST =   [ "0", "3", "6", "14", "4", "11", "12", "13", "5", "2", "0", "9", "0","1", "0", "10" ]
	static final def S_MANUAL_F_MANUAL_SL5_SEARCH_INDEX_LIST = [ "0", "3", "6", "14", "4", "11", "12", "13", "5", "0", "7", "0", "8","0", "15", "0" ]
}

