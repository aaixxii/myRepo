package test.common.constants.aim

class UsePrefilterInfoMap {
	def defaultParamMap = [
		"useGender":"false",
		"useRace":"false",
		"useFingerNo":"false",
		"usePattern":"false",
		"useYob":"false",
		"useRegion":"false",
		"usePartNo":"false",
	]
}

