package test.common.constants.aim

class CmlafOptMap {
	def defaultParamMap = [
		"filterMode":"1",
		"applyGender":"false",
		"applyYob":"false",
		"applyPatternThreshold":"false",
		"patternThreshold":"0.85",
		"applyYobThreshold":"false",
		"yobThreshold":"10",
		"applyCardScoreThreshold":"false",
		"cardScoreThreshold":"4",
		"applyMateProbabilityThreshold":"false",
		"mateProbabilityThreshold":"0.2",
		"applyFinalScoreThreshold":"false",
		"finalScoreThreshold":"200",
		"searchMode":"1",
		"applySpeedLevel":"false",
		"speedLevel":"9",
		"applyRotationLimit":"false",
		"rotationLimit":"3",
		"applyDistortionLevel":"false",
		"distortionLevel":"1",
	]
}

