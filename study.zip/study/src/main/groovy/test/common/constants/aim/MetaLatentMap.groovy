package test.common.constants.aim

class MetaLatentMap {
	def defaultParamMap = [
		"selectFingers":"0123456789",
		"latentPatterns":"S",
        "primaryAdjacentPatterns":"********",
        "referenceAdjacentPatterns":"********",
        "selectParts":"0"
	]
}

