package test.common.constants.aim

class AIMXmlElement{

	static final String AIM_FAULT = "AIMFault"
}

