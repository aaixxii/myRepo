package test.common.constants.aim

class CommonOptions{
	static final String PRIOTIRY = "priority"
	static final String CALL_BACK_URL = "callbackURL"
	static final String MAX_CANDIDATES = "maxCandidates"
	static final String MIN_SCORE = "minScore"
	static final String CONSOLIDATE_BY_CONTAINER = "consolidateByContainer"
	static final String MULTI_RECORD_CANDIDATES = "multiRecordCandidates"
	static final String DYN_THRESH_HIT_THRESHOLD = "dynThreshHitThreshold"
	static final String DYN_THRESH_PERCENTAGE_POINT = "dynThreshPercentagePoint"
}

