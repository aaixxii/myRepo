package test.common.format.extraction.payload.impl

import test.common.format.extraction.payload.abst.*
import test.common.format.extraction.payload.factory.*


class OutputPayloadPalm extends OutputPayloadFingerAbstract {

	public OutputPayloadPalm(String outputPayloadXmlString) {
		super(outputPayloadXmlString)
	}

	public void injection() {
		try{
			def parser = new XmlParser().parseText(parseExtOutputsXml(outputPayloadXmlString))
			injectionToPalmOutputList(parser)
		}catch (Exception e ){
			e.printStackTrace()
			assert false, "Error OutputPayloadPalm#injection !!\n" + e
		}
	}	

	private injectionToPalmOutputList(Node outputPayloadRootNode) {
		palmOutputList = OutputPayloadPalmFactory.createPalmOutputList(outputPayloadRootNode)
	}
}
