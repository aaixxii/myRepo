package test.common.format.extraction.payload.impl

import test.common.format.extraction.payload.abst.*
import test.common.format.extraction.payload.factory.*


class OutputPayloadTenprint extends OutputPayloadFingerAbstract {

	public OutputPayloadTenprint(String outputPayloadXmlString) {
		super(outputPayloadXmlString)
	}

	public void injection() {
		try{
			def parser = new XmlParser().parseText(parseExtOutputsXml(outputPayloadXmlString))
			injectionToFingerOutputList(parser)
		}catch (Exception e ){
			e.printStackTrace()
			assert false, "Error OutputPayloadCmlaf#injection !!\n" + e
		}
	}	

	private injectionToFingerOutputList(Node outputPayloadRootNode) {
		fingerOutputList = OutputPayloadTenprintFactory.createFingerOutputList(outputPayloadRootNode)
	}

	public updateDbType(String dbType, int index) {
		fingerOutputList[index].setDbTypes(dbType)
	}

	public updateDbTypes(String dbType, List<Integer> indexList) {
		for(Integer index in indexList) {
			fingerOutputList[index].setDbTypes(dbType)
		}
	}
}
