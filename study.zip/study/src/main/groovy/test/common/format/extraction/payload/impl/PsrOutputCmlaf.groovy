package test.common.format.extraction.payload.impl

import test.common.format.extraction.payload.abst.*

class PsrOutputCmlaf extends PsrOutputAbstract {

	private static final String CMLAF = "CMLaF"
	
	String rolled10Psr1FusionId = "1"
	String rolled10Psr1Type = CMLAF
	String slapPsr1FusionId = "1"
	String slapPsr1Type = CMLAF
	String rolled10Psr2FusionId = "2"
	String rolled10Psr2Type = CMLAF
	String slapPsr2FusionId = "2"
	String slapPsr2Type = CMLAF

	public PsrOutputCmlaf(){}
}

