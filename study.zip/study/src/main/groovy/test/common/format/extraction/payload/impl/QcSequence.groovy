package test.common.format.extraction.payload.impl


class QcSequence{

	List rolledFingers
	List slapFingers

	public QcSequence(List rolledFingers, List slapFingers){
		this.rolledFingers = rolledFingers
		this.slapFingers = slapFingers
	}
	
	public QcSequence(List rolledFingers){
		this.rolledFingers = rolledFingers
	}
}

