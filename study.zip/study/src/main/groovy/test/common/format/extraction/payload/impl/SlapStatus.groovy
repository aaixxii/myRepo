package test.common.format.extraction.payload.impl

class SlapStatus {

        Finger finger

        public SlapStatus(Finger finger) {
                this.finger = finger
        }
}
