package test.common.format.extraction.payload.factory

import test.common.format.extraction.payload.abst.*
import test.common.format.extraction.payload.impl.*

class QcSlapStatusFactory  {

    public static create (Node qcOutputNode){
	List<SlapStatus> slapStatusList = new ArrayList<SlapStatus>()
	for (slapStatus in qcOutputNode."slap-status"){
       		Finger finger = new Finger(slapStatus.finger[0].@pos, slapStatus.finger[0].@status)
		SlapStatus sStatus = new SlapStatus(finger)
		slapStatusList << sStatus
	}
        return slapStatusList
    }
}
