package test.common.format.extraction.payload.impl

import test.common.format.extraction.payload.abst.*

class FisMinutiaNoCmlaf extends FisMinutiaNoAbstract{

	public void setFisMinutiaNoInfo(Node fisMinutiaNode){
		super.setDeletedNumberOfFeaturePoints(fisMinutiaNode.attribute("DB"))
		super.setFeaturePoints(fisMinutiaNode.attribute("MB"))
	}
}
