package test.common.format.extraction.payload.abst

abstract class FisDataAbstract {

	String fisType
	FisCoreAbstract fisCore
	FisQualityAbstract fisQuality
	FisMinutiaNoAbstract fisMinutiaNo
	String minutiaData
	String zone
	String skeleton
}
