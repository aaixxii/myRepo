package test.common.format.extraction.payload.factory

import test.common.format.extraction.payload.abst.*
import test.common.format.extraction.payload.impl.*


class OutputPayloadPalmFactory {

	public static List<PalmOutput> createPalmOutputList(Node outputPayloadRootNode) {
		List<PalmOutput> palmOutputList = new ArrayList<FingerOutputAbstract>()
		for(palmOutputNode in outputPayloadRootNode."tenprint-output"."palm-output"){
			PalmOutput palmOutput = creaetPalmOutput(palmOutputNode)
			palmOutputList.add(palmOutput)
		}
		return palmOutputList
	}

	public static PalmOutput creaetPalmOutput(Node palmOutputNode) {
		PalmOutput palmOutput = new PalmOutput(
													palmOutputNode.attribute("pos"),
													palmOutputNode."cropped-image".text(),
													palmOutputNode."low-res-image".text())
		return palmOutput
	}
}

