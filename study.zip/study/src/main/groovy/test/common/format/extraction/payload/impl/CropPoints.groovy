package test.common.format.extraction.payload.impl


class CropPoints {

	String x
	String y

	public CropPoints(String x, String y) {
		this.x = x
		this.y = y
	}
}

