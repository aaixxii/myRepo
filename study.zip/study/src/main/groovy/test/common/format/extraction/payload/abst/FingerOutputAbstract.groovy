package test.common.format.extraction.payload.abst

import test.common.format.extraction.payload.impl.CropInfo

abstract class FingerOutputAbstract {
	
	String angle
	String fingerConfidence
	String patternPrimary
	String patternReference
	String pos
	String quality
	String nfiqQuality
	String croppedImage
	String lowResImage
	CropInfo cropInifo
	List<MinutiaDataAbstract> minutiaDataList = new ArrayList<MinutiaDataAbstract>()
	List<FisDataAbstract> fisDataList = new ArrayList<FisDataAbstract>()
	
	public FingerOutputAbstract(
		String angle, String fingerConfidence, String patternPrimary,
		String patternReference, String pos, String quality, 
		String nfiqQuality, String croppedImage, String lowResImage) {
		
		this(angle, fingerConfidence, patternPrimary, patternReference, pos, quality, nfiqQuality, croppedImage)
		this.lowResImage = lowResImage
	}


	public FingerOutputAbstract(
		String angle, String fingerConfidence, String patternPrimary, 
		String patternReference, String pos, String quality, String nfiqQuality, String croppedImage) {

		this.angle = angle
		this.fingerConfidence = fingerConfidence
		this.patternPrimary = patternPrimary
		this.patternReference = patternReference
		this.pos = pos
		this.quality = quality
		this.nfiqQuality = nfiqQuality
		this.croppedImage = croppedImage
	}

	public setDbTypes(String dbType){
		for(MinutiaDataAbstract minutiaData in minutiaDataList){
			minutiaData.setDbType(dbType)
		}
	}

	public setFisCore(FisCoreAbstract fisCore) {
		fisDataList[1].setFisCore(fisCore)
	}

	public setFisCoreQp(String qualityOfTheCorePosition) {
		fisDataList[1].getFisCore().setQualityOfTheCorePosition(qualityOfTheCorePosition)
	}

	public setFisCoreA(String activityBit) {
		fisDataList[1].getFisCore().setActivityBit(activityBit)
	}

	public setFisCoreF(String minutiaCoordinate) {
		fisDataList[1].getFisCore().setMinutiaCoordinate(minutiaCoordinate)
	}

	public setFisCoreCc(String flactionCode) {
		fisDataList[1].getFisCore().setFlactionCode(flactionCode)
	}

	public setFisCoreQd(String qualityOfTheAxisDirection) {
		fisDataList[1].getFisCore().setQualityOfTheAxisDirection(qualityOfTheAxisDirection)
	}

	public setFisCoreQq(String qualityOfTheCorePositionAndDirection) {
		fisDataList[1].getFisCore().setQualityOfTheCorePositionAndDirection(qualityOfTheCorePositionAndDirection)
	}

	public setFisCoreX(String corePositionHorizontal) {
		fisDataList[1].getFisCore().setCorePositionHorizontal(corePositionHorizontal)
	}

	public setFisCoreY(String corePositionVertical) {
		fisDataList[1].getFisCore().setCorePositionVertical(corePositionVertical)
	}

	public setFisCoreD(String axisAngle) {
		fisDataList[1].getFisCore().setAxisAngle(axisAngle)
	}

	public setFisQuality(FisQualityAbstract fisQuality) {
		fisDataList[1].setFisQuality(fisQuality)
	}

	public setFisQualityS(String zoneQualityValue) {
		fisDataList[1].getFisQuality().setZoneQualityValue(zoneQualityValue)
	}

	public setFisQualityVa(String qualityOfAZone) {
		fisDataList[1].getFisQuality().setQualityOfAZone(qualityOfAZone)
	}

	public setFisQualityVb(String qualityOfBZone) {
		fisDataList[1].getFisQuality().setQualityOfBZone(qualityOfBZone)
	}

	public setFisQualityVc(String qualityOfCZone) {
		fisDataList[1].getFisQuality().setQualityOfCZone(qualityOfCZone)
	}

	public setFisMinutiaNo(FisMinutiaNoAbstract fisMinutiaNo) {
		fisDataList[1].setFisMinutiaNo(fisMinutiaNo)
	}

	public setFisMinutiaNoDb(String deletedNumberOfFeaturePoints) {
		fisDataList[1].getFisMinutiaNo().setDeletedNumberOfFeaturePoints(deletedNumberOfFeaturePoints)
	}

	public setFisMinutiaNoMb(String featurePoints) {
		fisDataList[1].getFisMinutiaNo().setFeaturePoints(featurePoints)
	}

	public setFisSkeleton(String skeleton) {
		fisDataList[1].setSkeleton(skeleton)
	}

	public setFisMinutiaData(String minutiaData) {
		fisDataList[1].setMinutiaData(minutiaData)
	}

	public setFisMinutiaDataSingle(String minutiaData) {
		fisDataList[0].setMinutiaData(minutiaData)
	}

	public setFisZone(String zone) {
		fisDataList[1].setZone(zone)
	}

        public setMinutiaData(String minutiaData){
                minutiaDataList[0].setBinary(minutiaData)
        }

}

