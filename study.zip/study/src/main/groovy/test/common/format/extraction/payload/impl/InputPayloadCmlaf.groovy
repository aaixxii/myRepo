package test.common.format.extraction.payload.impl

import test.common.format.extraction.payload.abst.*
import test.common.format.extraction.payload.factory.*

class InputPayloadCmlaf extends InputPayloadAbstract {

	static final String EXTRACTION_INPUTS_PAYLOAD_PRE = "<ns2:extraction-inputs-payload xmlns:ns2='urn:nec:aim'>"
	static final String EXTRACTION_INPUTS_PAYLOAD_SUF = "</ns2:extraction-inputs-payload>"
	static final String EXT_INPUT_PRE = "<ext-input>"
	static final String EXT_INPUT_SUF = "</ext-input>"
	static final String TENPRINT_INPUT_PRE = "<tenprint-input>"
	static final String TENPRINT_INPUT_SUF = "</tenprint-input>"
	static final String HEADER = EXTRACTION_INPUTS_PAYLOAD_PRE + EXT_INPUT_PRE + TENPRINT_INPUT_PRE
	static final String FOOTER = TENPRINT_INPUT_SUF + EXT_INPUT_SUF + EXTRACTION_INPUTS_PAYLOAD_SUF
	static final String FIS = "FIS"
	static final String PC2 = "PC2"
	String minutiaType = "FIS"
	String dbType = "RDBTM"

	public String toXmlString() {
		inputMinutiaSb = new StringBuilder()
		return toStringInputMinutia()
	}
	
	public String toXmlString(String minutiaType) {
		this.minutiaType = minutiaType
		return toXmlString()
	}
	
	public String toXmlStringWithHeader(String minutiaType) {
		this.minutiaType = minutiaType
		return toXmlStringWithHeader()
	}

	public String toXmlString(String minutiaType, String dbType){
		this.minutiaType = minutiaType
		this.dbType = dbType
		return toXmlString()
	}
	
	public String toXmlStringWithHeader() {
		inputMinutiaSb = new StringBuilder()
		return toStringInputMinutiaWithHeader()
	}
	
	public String toStringInputMinutiaWithHeader() {
		inputMinutiaSb.append(HEADER)
		toStringInputMinutia()
		inputMinutiaSb.append(FOOTER)
		return inputMinutiaSb.toString()
	}

	public String toXmlStringPc2WithFisData(){
		inputMinutiaSb = new StringBuilder()
		return toStringInputMinutiaPc2WithFisData()
	}

	public String toStringInputMinutiaPc2WithFisData(){
		inputMinutiaSb.append("""<input-minutia dbType="${dbType}" minutiaType="${minutiaType}">""")
		for(FingerOutputAbstract fingerOutput in outputPayload.getFingerOutputList()){
			appendInputMinutiaDataPc2WithFisData(fingerOutput)
		}
		inputMinutiaSb.append("</input-minutia>")
		return inputMinutiaSb.toString()
	}

	private void appendInputMinutiaDataPc2WithFisData(FingerOutputAbstract fingerOutput){
		String pos = fingerOutput.getPos()
		String dbType = fingerOutput.getMinutiaDataList()[fingerOutput.getMinutiaDataList().size()-1].getDbType()
		inputMinutiaSb.append("""<input-minutia-data pos="${pos}">""")
		appendPc2Data(fingerOutput)
		appendFisDataWithoutMinutia(fingerOutput)
		
		inputMinutiaSb.append("</input-minutia-data>")
	}
	

	public String toStringInputMinutia() {
		inputMinutiaSb.append("""<input-minutia dbType="${dbType}" minutiaType="${minutiaType}">""")
		for(FingerOutputAbstract fingerOutput in outputPayload.getFingerOutputList()){
			appendInputMinutiaData(fingerOutput)
		}
		inputMinutiaSb.append("</input-minutia>")
		return inputMinutiaSb.toString()
	}

	private void appendInputMinutiaData(FingerOutputAbstract fingerOutput) {
		String pos = fingerOutput.getPos()
		String dbType = fingerOutput.getMinutiaDataList()[fingerOutput.getMinutiaDataList().size()-1].getDbType()
		inputMinutiaSb.append("""<input-minutia-data pos="${pos}">""")
		if(minutiaType == FIS){
			appendFisData(fingerOutput)
		}else if(minutiaType == PC2){
			appendPc2Data(fingerOutput)
		}else{
			assert false, "minutiaType '${minutiaType} is invalid. expected ${PC2} or ${FIS}"
		}
		
		inputMinutiaSb.append("</input-minutia-data>")
	}

	private appendPc2Data(FingerOutputAbstract fingerOutput) {
		for(MinutiaDataAbstract minutiaData in fingerOutput.getMinutiaDataList()){
			appendMinutiaData(minutiaData.getBinary())
		}
	}

	private appendFisData(FingerOutputAbstract fingerOutput) {
		FisDataAbstract fisData = fingerOutput.getFisDataList()[fingerOutput.getFisDataList().size()-1]
		appendMinutiaData(fisData.getMinutiaData())
		appendZone(fisData.getZone())
		appendSkeleton(fisData.getSkeleton())
		appendFisCoreInfo(fisData.getFisCore())
		appendFisQualityInfo(fisData.getFisQuality())
		appendFisMinutiaNo(fisData.getFisMinutiaNo())
	}

	private appendFisDataWithoutMinutia(FingerOutputAbstract fingerOutput){
		FisDataAbstract fisData = fingerOutput.getFisDataList()[fingerOutput.getFisDataList().size()-1]
		appendZone(fisData.getZone())
		appendSkeleton(fisData.getSkeleton())
		appendFisCoreInfo(fisData.getFisCore())
		appendFisQualityInfo(fisData.getFisQuality())
		appendFisMinutiaNo(fisData.getFisMinutiaNo())
	}


	private void appendFisCoreInfo(FisCoreAbstract fisCore) {
		if(fisCore == null) {
			return 
		}
		inputMinutiaSb.append("""<core A="${fisCore.getActivityBit()}" """ + 
					"""CC="${fisCore.getFlactionCode()}" D="${fisCore.getAxisAngle()}" F="${fisCore.getMinutiaCoordinate()}" """ +
					"""QD="${fisCore.getQualityOfTheAxisDirection()}" QP="${fisCore.getQualityOfTheCorePosition()}" """ +
					"""QQ="${fisCore.getQualityOfTheCorePositionAndDirection()}" """ +
					"""X="${fisCore.getCorePositionHorizontal()}" Y="${fisCore.getCorePositionVertical()}"/>""")
	}

	private void appendFisQualityInfo(FisQualityAbstract fisQuality) {
		if(fisQuality == null) {
			return 
		}
		inputMinutiaSb.append("""<quality S="${fisQuality.getZoneQualityValue()}" """ +
							"""VA="${fisQuality.getQualityOfAZone()}" """ + 
							"""VB="${fisQuality.getQualityOfBZone()}" VC="${fisQuality.getQualityOfCZone()}"/>""")
		
	}

	private void appendFisMinutiaNo(FisMinutiaNoAbstract fisMinutiaNo) {
		if(fisMinutiaNo == null) {
			return 
		}
		inputMinutiaSb.append("""<minutia-no DB="${fisMinutiaNo.getDeletedNumberOfFeaturePoints()}" """ +
							"""MB="${fisMinutiaNo.getFeaturePoints()}"/>""")
		
	}

	private void appendMinutiaData(String minutiaData) {
		if(minutiaData == null) {
			return 
		}
		inputMinutiaSb.append("<minutia-data>")
		inputMinutiaSb.append(minutiaData)
		inputMinutiaSb.append("</minutia-data>")
	}

	private void appendZone(String zone) {
		if(zone == null) {
			return 
		}
		inputMinutiaSb.append("<zone>")
		inputMinutiaSb.append(zone)
		inputMinutiaSb.append("</zone>")
	}

	private void appendSkeleton(String skeleton) {
		if(skeleton == null) {
			return 
		}
		inputMinutiaSb.append("<skeleton>")
		inputMinutiaSb.append(skeleton)
		inputMinutiaSb.append("</skeleton>")
	}

}

