package test.common.format.extraction.payload.impl

import test.common.format.extraction.payload.abst.*

class FisQualityCmlaf extends FisQualityAbstract {

	public void setFisQualityInfo(Node fisQualityNode){
		super.setZoneQualityValue(fisQualityNode.attribute("S"))
		super.setQualityOfAZone(fisQualityNode.attribute("VA"))
		super.setQualityOfBZone(fisQualityNode.attribute("VB"))
		super.setQualityOfCZone(fisQualityNode.attribute("VC"))
	}
}

