package test.common.format

class AimXmlFormatter extends DataFormatter{
	private static final String IMAGE_PRE = "<image pos"
	private static final String IMAGE_SUF = "</image>"
	private static final String DATA_PRE = "<data>"
	private static final String DATA_SUF = "</data>"
	private static final String SEG_INFO_PRE = "<seg-info pos"
	private static final String SEG_INFO_SUF = "</seg-info>"
	private static final String URL_PRE = "<url>"
	private static final String URL_SUF = "</url>"
	
	AimXmlFormatter(){}

	public static trimImagesXml(String imagesXml, int startPos, int endPos){
		String startPosStr = "${IMAGE_PRE}='${startPos}'" 
		String endPosStr = "${IMAGE_PRE}='${endPos}'" 
		int start = imagesXml.indexOf(startPosStr)
		int end = imagesXml.indexOf(endPosStr)
		end = imagesXml.indexOf(IMAGE_SUF, end+1) + IMAGE_SUF.length()
		return imagesXml.substring(start, end)
	}
	
	public static String trimImageXml(String imagesXml, int pos){
		String startPosStr = "${IMAGE_PRE}='${pos}'" 
		int start = imagesXml.indexOf(startPosStr)
		int end = imagesXml.indexOf(IMAGE_SUF, start+1) + IMAGE_SUF.length()
		return imagesXml.substring(start, end)
	}
	
	// remove image xml specified position.
	public static String deleteImageXml(String imagesXml, int pos){
		return deleteXml(imagesXml, pos, IMAGE_PRE, IMAGE_SUF)
	}
	
	public static String deleteSegInfoXml(String imagesXml, int segInfoPos){
		return deleteXml(imagesXml, segInfoPos, SEG_INFO_PRE, SEG_INFO_SUF)
	}
	
	public static String deleteXml(String imagesXml, int pos, String header, String fotter){
		String imageXml2nd = ""
		String startPosStr = "${header}='${pos}'" 
		int delHead = imagesXml.indexOf(startPosStr)
		int delTail = imagesXml.indexOf(fotter, delHead+1) + fotter.length()
		String imageXml1st = imagesXml.substring(0, delHead)
		if(delTail != imagesXml.length()){
			imageXml2nd = imagesXml.substring(delTail)
		}
		return imageXml1st + imageXml2nd
	}
	
	public static String insertSegInfo(String imagesXml, int pos, 
			int segPos, boolean amp, 
			int xCenter, int yCenter, float angle,
			int xA, int yA, 
			int xB, int yB, 
			int xC, int yC, 
			int xD, int yD){
		String startPosStr = "${IMAGE_PRE}='${pos}'" 
		int delHead = imagesXml.indexOf(startPosStr)
		int addPoint = imagesXml.indexOf(IMAGE_SUF, delHead+1) 
		String imageXml1st = imagesXml.substring(0, addPoint)
		String imageXml2nd = imagesXml.substring(addPoint)
		String segInfo = create4PointSegInfoXml(segPos, amp, xCenter, yCenter, angle, xA, yA, xB, yB, xC, yC, xD, yD)
		return imageXml1st + segInfo + imageXml2nd
	}
	
	public static String insertSegInfo(String imagesXml, int pos, 
			int segPos, boolean amp, int xA, int yA, int xB, int yB){
		String startPosStr = "${IMAGE_PRE}='${pos}'" 
		int delHead = imagesXml.indexOf(startPosStr)
		int addPoint = imagesXml.indexOf(IMAGE_SUF, delHead+1) 
		String imageXml1st = imagesXml.substring(0, addPoint)
		String imageXml2nd = imagesXml.substring(addPoint)
		String segInfo = create2PointSegInfoXml(segPos, amp, xA, yA, xB, yB);
		return imageXml1st + segInfo + imageXml2nd
	}
	
	public static String insertSegInfoAmp(String imagesXml, int pos, int segPos, boolean amp){
		String startPosStr = "${IMAGE_PRE}='${pos}'" 
		int delHead = imagesXml.indexOf(startPosStr)
		int addPoint = imagesXml.indexOf(IMAGE_SUF, delHead+1) 
		String imageXml1st = imagesXml.substring(0, addPoint)
		String imageXml2nd = imagesXml.substring(addPoint)
		String segInfo = createAmpSegInfoXml(segPos, amp)
		return imageXml1st + segInfo + imageXml2nd
	}
	
	
	public static String createImageXml(String imgB64, int pos, int type, int dpi, int width, int height){
		StringBuilder sb = new StringBuilder()
		sb.append(IMAGE_PRE)
		sb.append("='${pos}' type='${type}' dpi='${dpi}' width='${width}' height='${height}' horiz-scale='${width}' vert-scale='${height}'>")
		sb.append(DATA_PRE)
		sb.append(imgB64)
		sb.append(DATA_SUF)
		sb.append(IMAGE_SUF)
	}
	
	public static String createImageXml(String imgB64, int pos, int type, int dpi, int width, int height, String segInfoXml){
		StringBuilder sb = new StringBuilder()
		sb.append(IMAGE_PRE)
		sb.append("='${pos}' type='${type}' dpi='${dpi}' width='${width}' height='${height}'>")
		sb.append(DATA_PRE)
		sb.append(imgB64)
		sb.append(DATA_SUF)
		sb.append(segInfoXml)
		sb.append(IMAGE_SUF)
	}
	
	public static String createImageXml(String imgB64, int type, int width, int height){
		StringBuilder sb = new StringBuilder()
		sb.append("<image ")
		sb.append(emptyToAtirivbuteDelete("type", type as String) +  emptyToAtirivbuteDelete("width",width as String) 
					+ emptyToAtirivbuteDelete("height",height as String) + " >")
		sb.append(DATA_PRE)
		sb.append(imgB64)
		sb.append(DATA_SUF)
		sb.append(IMAGE_SUF)
	}

	public static String createImageXml(String imgB64, def type, def width, def height){
		StringBuilder sb = new StringBuilder()
		sb.append("<image ")
		sb.append(emptyToAtirivbuteDelete("type", type as String) +  emptyToAtirivbuteDelete("width",width as String) 
					+ emptyToAtirivbuteDelete("height",height as String) + " >")
		sb.append(DATA_PRE)
		sb.append(imgB64)
		sb.append(DATA_SUF)
		sb.append(IMAGE_SUF)
	}

	public static String createOmitTypeImageXml(String imgB64, int pos, int dpi, int width, int height){
		StringBuilder sb = new StringBuilder()
		sb.append(IMAGE_PRE)
		sb.append("='${pos}' dpi='${dpi}' width='${width}' height='${height}' horiz-scale='${width}' vert-scale='${height}'>")
		sb.append(DATA_PRE)
		sb.append(imgB64)
		sb.append(DATA_SUF)
		sb.append(IMAGE_SUF)
	}
	
	public static String createOmitTypeImageXml(String imgB64, def width, def height){
		StringBuilder sb = new StringBuilder()
		sb.append("<image ")
		sb.append("width='${width}' height='${height}'>")
		sb.append(DATA_PRE)
		sb.append(imgB64)
		sb.append(DATA_SUF)
		sb.append(IMAGE_SUF)
	}

	public static String emptyToAtirivbuteDelete(String attribute, String value){
		if(value == "") return " "
		return "${attribute}='${value}' "
	}

	public static String createUrlImageXml(String url, int pos, int type, int dpi, int width, int height){
		StringBuilder sb = new StringBuilder()
		sb.append(IMAGE_PRE)
		sb.append("='${pos}' type='${type}' dpi='${dpi}' width='${width}' height='${height}' horiz-scale='${width}' vert-scale='${height}'>")
		sb.append(URL_PRE)
		sb.append(url)
		sb.append(URL_SUF)
		sb.append(IMAGE_SUF)
	}
	
	public static String createUrlImageXml(String url, int type, int width, int height){
		StringBuilder sb = new StringBuilder()
		sb.append("<image ")
		sb.append("type='${type}' width='${width}' height='${height}'>")
		sb.append(URL_PRE)
		sb.append(url)
		sb.append(URL_SUF)
		sb.append(IMAGE_SUF)
	}

	public static String create4PointSegInfoXml(
		int pos, boolean amp, 
		int xCenter, int yCenter, float angle,
		int xA, int yA, 
		int xB, int yB, 
		int xC, int yC, 
		int xD, int yD ){
		
		return SegInfoCreater.create4PointXml(pos, amp, xCenter, yCenter, angle, xA, yA, xB, yB, xC, yC, xD, yD)
	}
		
	public static String create2PointSegInfoXml(
		int pos, boolean amp, 
		int xA, int yA, 
		int xB, int yB ){
		
		return SegInfoCreater.create2PointXml(pos, amp, xA, yA, xB, yB)
	}
		
	public static String createAmpSegInfoXml(int pos, boolean amp) { 
		return SegInfoCreater.createAmpXml(pos, amp)
	}
	
	public static String replacePosSlapFromRoll(String imagesXml) {
		for(i in 1..10) {
			int slapPos = ImagePositionConvertor.convertSlapFromRoll(i)
			imagesXml = replacePos(imagesXml, i, slapPos)
		}
		return imagesXml
	}
	
	public static String replacePos(String imagesXml, int from, int to){
		imagesXml = imagesXml.replace("pos='$from'", "pos='$to'")
	}

			/*
			 *start izumi edit
			 */
			
			public static String insertSegInfo(String imagesXml, int pos, int segPos, boolean amp, String segInfo){
				
				String startPosStr = "${IMAGE_PRE}='${pos}'"
				int delHead = imagesXml.indexOf(startPosStr)
				int addPoint = imagesXml.indexOf(IMAGE_SUF, delHead+1)
				String imageXml1st = imagesXml.substring(0, addPoint)
				String imageXml2nd = imagesXml.substring(addPoint)
			//	String segInfo = create4PointSegInfoXml(segPos, amp, xCenter, yCenter, angle, xA, yA, xB, yB, xC, yC, xD, yD)
				return imageXml1st + segInfo + imageXml2nd
				
			}
			
			/*
			 * end izumi edit
			 */

}

