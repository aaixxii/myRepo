package test.common.format.extraction.payload.impl

import test.common.format.extraction.payload.abst.*

class MinutiaDataCmlaf extends MinutiaDataAbstract {
	
	String fusionId

	public MinutiaDataCmlaf() {}

	public MinutiaDataCmlaf(
		String dbType, String fisType, String format, 
		String fusionId, String minutiaCount, String minutiaType) {
		
		super(dbType, fisType, format, minutiaCount, minutiaType)
		this.fusionId = fusionId

	}
}

