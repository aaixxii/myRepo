package test.common.format

import common.util.*

class AimVxXmlFormatter extends DataFormatter{
	AimVxXmlFormatter(){}

	def createSimpleBinaryDataListXml(file){
	
		def b64String = new Encoder().binaryToB64(file)
	
		String b64 = new String(makeElement("values", b64String))
		return makeElement("binaryDataList", b64)
	}

	def createSimpleBinaryDataListXml(file, imagePosition){
	
		def b64String = new Encoder().binaryToB64(file)
	
		String b64 = new String(makeElement("imagePosition", imagePosition))
		b64 += makeElement("values", b64String)
		return makeElement("binaryDataList", b64)
	}
	
	def createSimpleBinaryDataListXml(file, imagePosition, dpi){
	
		def b64String = new Encoder().binaryToB64(file)
	
		String b64 = new String(makeElement("imagePosition", imagePosition))
		b64 += makeElement("values", b64String)
		b64 += makeElement("dpi", dpi)
		return makeElement("binaryDataList", b64)
	}

	def createSimpleBinaryDataListXml(file, imagePosition, dpi, width, height){
	
		def b64String = new Encoder().binaryToB64(file)
	
		String b64 = new String(makeElement("imagePosition", imagePosition))
		b64 += makeElement("values", b64String)
		b64 += makeElement("dpi", dpi)
		b64 += makeElement("width", width)
		b64 += makeElement("height", height)
		return makeElement("binaryDataList", b64)
	}
}

