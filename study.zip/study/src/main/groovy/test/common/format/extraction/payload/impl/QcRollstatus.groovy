package test.common.format.extraction.payload.impl

class QcRollstatus {

    QcRollstatus QcRollstatus

    public QcRollstatus(QcRollstatus QcRollstatus){
        this.QcRollstatus = QcRollstatus
    }
}
