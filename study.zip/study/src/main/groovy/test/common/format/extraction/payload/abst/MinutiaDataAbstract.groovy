package test.common.format.extraction.payload.abst

abstract class MinutiaDataAbstract{
	
	String dbType
	String fisType
	String format
	String minutiaCount
	String minutiaType
	String binary
	String multiFeIndex

	public MinutiaDataAbstract(){}

	public MinutiaDataAbstract(
		String dbType, String fisType, String format, 
		String minutiaCount, String minutiaType, String binary, multiFeIndex) {
		this(dbType, fisType, format, minutiaCount, minutiaType, binary)
		this.multiFeIndex = multiFeIndex
	}
		
	public MinutiaDataAbstract(
		String dbType, String fisType, String format, 
		String minutiaCount, String minutiaType, String binary) {
		this(dbType, fisType, format, minutiaCount, minutiaType)
		this.binary = binary
	}
		
	public MinutiaDataAbstract(
		String dbType, String fisType, String format, 
		String minutiaCount, String minutiaType) {

		this.dbType = dbType
		this.fisType = fisType
		this.format = format
		this.minutiaCount = minutiaCount
		this.minutiaType = minutiaType
	}
}

