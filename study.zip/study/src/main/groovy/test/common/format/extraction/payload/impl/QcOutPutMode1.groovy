package test.common.format.extraction.payload.impl

class QcOutPutMode1 {

	String total 
	List<RollStatus> rollStatusList
	List<SlapStatus> slapStatusList

	public QcOutPutMode1(String total, List rollStatusList, List slapStatusList){
		this.total = total
		this.rollStatusList = rollStatusList
		this.slapStatusList = slapStatusList
	}
}
