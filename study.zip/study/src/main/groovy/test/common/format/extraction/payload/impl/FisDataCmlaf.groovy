package test.common.format.extraction.payload.impl

import test.common.format.extraction.payload.abst.*

class FisDataCmlaf extends FisDataAbstract {

	String fisType = "TYPE_CMLaF"
	String fusionId

}
