package test.common.format.html

import common.sql.SqlExecutor

class JobQueueInfoHtmlCreator {
	private static final String FUNCTION_NAME = "FUNCTION_NAME"
	private static final String JOB_STATE = "JOB_STATE"
	private static final String COUNT = "COUNT"
	private static final String SQL = "select ft.FUNCTION_NAME, decode(jq.job_state, 0, 'Queue', 1, 'Running', 2, 'Done') as JOB_STATE, count(*) as count from job_queue jq, fusion_jobs fj, function_types ft where jq.job_id = fj.job_id and fj.FUNCTION_ID = ft.FUNCTION_ID group by ft.FUNCTION_NAME, jq.JOB_STATE, ft.FUNCTION_ID order by ft.FUNCTION_ID, jq.JOB_STATE"
	private static final String HTML_PRE = "<html>"
	private static final String HTML_SUF = "</html>"
	private static final String HEAD = """
<head>
  <meta http-equiv="refresh" content="5">
</head>
"""
	private static final String STYLE = """
<style>
    table {
        border-collapse: collapse;
		border: ridge 8px;
    }
    th {
        border: ridge 4px;
        padding: 0.5em;
		font-style: italic;
    }
	tr {
		background: #caf0fc;
	}
</style>
"""
	private static final String TABLE_PRE = "<table>"
	private static final String TABLE_SUF = "</table>"
	private SqlExecutor sqlExecutor
	
	JobQueueInfoHtmlCreator(){}
	
	JobQueueInfoHtmlCreator(String ip, String port, String sid, String user, String pass){
		this.sqlExecutor = new SqlExecutor(ip, port, sid, user, pass)
	}
	
	public String create(){
		StringBuilder sb = new StringBuilder()
		sb.append(HTML_PRE + HEAD + STYLE + TABLE_PRE)
		sb.append("<tr style='background:#ccccff'>")
		sb.append("<th>${FUNCTION_NAME}</th>")
		sb.append("<th>${JOB_STATE}</th>")
		sb.append("<th>${COUNT}</th>")
		sb.append("</tr>")
		List<Map> rowMapList = sqlExecutor.getSqlResult(SQL)
		for(rowMap in rowMapList){
			sb.append("<tr>")
			sb.append("<th>" + rowMap.get(FUNCTION_NAME) + "</th>")
			sb.append("<th>" + rowMap.get(JOB_STATE) + "</th>")
			sb.append("<th>" + rowMap.get(COUNT) + "</th>")
			sb.append("</tr>")
		}
		sb.append(TABLE_SUF + HTML_SUF)
		return sb.toString()
	}

}

