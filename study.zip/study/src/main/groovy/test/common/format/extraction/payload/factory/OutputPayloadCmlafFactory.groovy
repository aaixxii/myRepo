package test.common.format.extraction.payload.factory

import test.common.format.extraction.payload.abst.*
import test.common.format.extraction.payload.impl.*


class OutputPayloadCmlafFactory {

	public static createFingerOutputList(Node outputPayloadRootNode) {
		List<FingerOutputAbstract> fingerOutputList = new ArrayList<FingerOutputAbstract>()
		for(fingerOutputNode in outputPayloadRootNode."tenprint-output"."finger-output"){
			FingerOutputAbstract fingerOutput = createFingerOutput(fingerOutputNode)
			fingerOutputList.add(fingerOutput)
		}
		return fingerOutputList
	}

	public static FingerOutputAbstract createFingerOutput(Node fingerOutputNode) {
		FingerOutputAbstract fingerOutput = new FingerOutputCmlaf(
													fingerOutputNode.attribute("angle"),
													fingerOutputNode.attribute("fingerConfidence"),
													fingerOutputNode.attribute("patternPrimary"),
													fingerOutputNode.attribute("patternReference"),
													fingerOutputNode.attribute("pos"),
													fingerOutputNode.attribute("quality"),
													fingerOutputNode.attribute("nfiqQuality"),
													fingerOutputNode."cropped-image".text())
		fingerOutput.setCropInifo(createCropInfo(fingerOutputNode))
		fingerOutput.setMinutiaDataList(createMinutiaDataList(fingerOutputNode))
		fingerOutput.setFisDataList(createFisDataList(fingerOutputNode))
		return fingerOutput
	}
	
	public static CropInfo createCropInfo(Node fingerOutputNode){
		return CropInfoFactory.create(fingerOutputNode."crop-info"[0])
	}

	public static List<MinutiaDataAbstract> createMinutiaDataList(Node fingerOutputNode) {
		List<MinutiaDataAbstract> minutiaDataList = new ArrayList<MinutiaDataAbstract>()
		for(minutiaDataNode in fingerOutputNode."minutia-data"){
			MinutiaDataAbstract minutiaData = createMinutiaData(minutiaDataNode)
			minutiaDataList.add(minutiaData)
		}
		return minutiaDataList
	}

	public static MinutiaDataAbstract createMinutiaData(Node minutiaDataNode) {
			MinutiaDataAbstract minutiaData = new MinutiaDataCmlaf()
			minutiaData.setDbType(minutiaDataNode.attribute("dbType"))
			minutiaData.setFisType(minutiaDataNode.attribute("fisType"))
			minutiaData.setFormat(minutiaDataNode.attribute("format"))
			minutiaData.setFusionId(minutiaDataNode.attribute("fusionId"))
			minutiaData.setMinutiaCount(minutiaDataNode.attribute("minutiaCount"))
			minutiaData.setMinutiaType(minutiaDataNode.attribute("minutiaType"))
			return minutiaData
	}
		
	public static List<FisDataAbstract> createFisDataList(Node fingerOutputNode) {
		List<FisDataAbstract> fisDataList = new ArrayList<FisDataAbstract>()
		for(fisDataNode in fingerOutputNode."fis-data"){
			FisDataAbstract fisData = createFisData(fisDataNode)
			fisDataList.add(fisData)
		}
		return fisDataList
	}

	public static FisDataAbstract createFisData(Node fisDataNode) {
		FisDataAbstract fisData = new FisDataCmlaf()
		fisData.setFisType( fisDataNode.attribute("fisType") )
		fisData.setFusionId( fisDataNode.attribute("fusionId") )
		fisData.setFisCore( createFisCore(fisDataNode."fis-core"[0]) )
		fisData.setFisQuality( createFisQuality(fisDataNode."fis-quality"[0]) )
		fisData.setFisMinutiaNo( createFisMinutiaNo(fisDataNode."fis-minutia-no"[0]) )
		fisData.setMinutiaData( fisDataNode."minutia-data"[0].text() )
		fisData.setZone( fisDataNode."zone"[0].text() )
		fisData.setSkeleton( fisDataNode."skeleton".text() )
		return fisData
	}

	public static FisCoreAbstract createFisCore(Node fisCoreNode) {
		def FisCoreAbstract fisCore = new FisCoreCmlaf()
		fisCore.setFisCoreInfo(fisCoreNode)
		return fisCore
	}
			
	public static FisQualityAbstract createFisQuality(Node fisQualityNode) {
		def FisQualityAbstract fisQuality = new FisQualityCmlaf()
		fisQuality.setFisQualityInfo(fisQualityNode)
		return fisQuality
	}
			
	public static FisMinutiaNoAbstract createFisMinutiaNo(Node fisMinutiaNode) {
		def FisMinutiaNoAbstract fisMinutia = new FisMinutiaNoCmlaf()
		fisMinutia.setFisMinutiaNoInfo(fisMinutiaNode)
		return fisMinutia
	}
}

