package test.common.format.extraction.payload.factory

import test.common.format.extraction.payload.abst.*
import test.common.format.extraction.payload.impl.*

class QcRollStatusFactory  {

    public static create (Node qcOutputNode){
	List<RollStatus> rollStatusList = new ArrayList<RollStatus>()
	for (rollStatus in qcOutputNode."roll-status"){
       		Finger finger = new Finger(rollStatus.finger[0].@pos as String, rollStatus.finger[0].@status as String)
		RollStatus rStatus = new RollStatus(finger)
		rollStatusList << rStatus
	}
        return rollStatusList
    }
}
