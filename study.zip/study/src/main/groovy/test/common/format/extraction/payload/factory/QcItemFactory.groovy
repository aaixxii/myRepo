package test.common.format.extraction.payload.factory

import test.common.format.extraction.payload.abst.*
import test.common.format.extraction.payload.impl.*

class QcItemFactory  {

    public static create (Node qcOutputNode){
    	List<QcItem> qcItemList = new ArrayList<QcItem>()
		char pathSeq = ':'
		for (item in qcOutputNode.history.item){
			List data = item.@data.tokenize(pathSeq)
			QcItem qcItem = new QcItem(item.@activity, data, item.@status)
        	qcItemList << qcItem
   	 	}
		QcHistory history = new QcHistory(qcItemList)	
		return history
	}
}
