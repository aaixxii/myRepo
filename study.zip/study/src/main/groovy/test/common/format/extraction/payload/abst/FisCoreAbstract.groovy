package test.common.format.extraction.payload.abst

abstract class FisCoreAbstract {

	String activityBit 	// A
	String flactionCode	// CC
	String axisAngle	// D
	String minutiaCoordinate	// F
	String qualityOfTheAxisDirection	// QD
	String qualityOfTheCorePosition	// QP
	String qualityOfTheCorePositionAndDirection	// QQ
	String corePositionHorizontal	// X
	String corePositionVertical	// Y

	abstract public void setFisCoreInfo(Node fisCoreNode)

}

