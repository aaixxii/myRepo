package test.common.format.extraction.payload.abst


abstract class OutputPayloadPalmAbstract extends OutputPayloadAbstract {

	protected OutputPayloadPalmAbstract(String outputPayloadXmlString) {
		super(outputPayloadXmlString)
	}
}

