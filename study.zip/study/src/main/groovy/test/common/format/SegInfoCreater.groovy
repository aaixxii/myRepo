package test.common.format

class SegInfoCreater {
	private static final String SEG_INFO_PRE = "<seg-info"
	private static final String SEG_INFO_SUF = "</seg-info>"
	private static final String POS = "pos"
	private static final String AMP = "amp"
	private static final String CROP_INFO_PRE = "<crop-info>"
	private static final String CROP_INFO_SUF = "</crop-info>"
	private static final String CENTER = "<center"
	private static final String CROP_POINTS_PRE = "<crop-points>"
	private static final String CROP_POINTS_SUF = "</crop-points>"
	
	SegInfoCreater(){}

	public static String createAmpXml(int pos, boolean amp){ 
		StringBuilder sb = new StringBuilder()	
		sb.append(SEG_INFO_PRE)
		sb.append(" ${POS}='${pos}'")
		sb.append(" ${AMP}='${amp}'>")
		sb.append(SEG_INFO_SUF)
		return sb.toString()
	}
	
	public static String create2PointXml(
		int pos, boolean amp, 
		int xA, int yA, 
		int xB, int yB){ 
	
		StringBuilder sb = new StringBuilder()	
		sb.append(SEG_INFO_PRE)
		sb.append(" ${POS}='${pos}'")
		sb.append(" ${AMP}='${amp}'>")
		sb.append(CROP_INFO_PRE)
		sb.append(CROP_POINTS_PRE)
		sb.append("<points X='${xA}' Y='${yA}'/>")
		sb.append("<points X='${xB}' Y='${yB}'/>")
		sb.append(CROP_POINTS_SUF)
		sb.append(CROP_INFO_SUF)
		sb.append(SEG_INFO_SUF)
		
		return sb.toString()
	}
		
	public static String create4PointXml(
		int pos, boolean amp, 
		int xCenter, int yCenter, float angle,
		int xA, int yA, 
		int xB, int yB, 
		int xC, int yC, 
		int xD, int yD ){
	
		StringBuilder sb = new StringBuilder()	
		sb.append(SEG_INFO_PRE)
		sb.append(" ${POS}='${pos}'")
		sb.append(" ${AMP}='${amp}'>")
		sb.append(CROP_INFO_PRE)
		sb.append(CENTER)
		sb.append(" X='${xCenter}' Y='${yCenter}' angle='${angle}'/>")
		sb.append(CROP_POINTS_PRE)
		sb.append("<points X='${xA}' Y='${yA}'/>")
		sb.append("<points X='${xB}' Y='${yB}'/>")
		sb.append("<points X='${xC}' Y='${yC}'/>")
		sb.append("<points X='${xD}' Y='${yD}'/>")
		sb.append(CROP_POINTS_SUF)
		sb.append(CROP_INFO_SUF)
		sb.append(SEG_INFO_SUF)
		
		return sb.toString()
	}
}

