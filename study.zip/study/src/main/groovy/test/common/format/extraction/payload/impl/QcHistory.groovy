package test.common.format.extraction.payload.impl

class QcHistory {

	List<QcItem> itemList

	QcHistory(List itemList){
		this.itemList = itemList
	}
}
