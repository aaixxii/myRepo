package test.common.format.extraction.payload.abst

abstract class FisMinutiaNoAbstract {

	String deletedNumberOfFeaturePoints	// DB
	String featurePoints	// MB

	abstract public void setFisMinutiaNoInfo(Node fisMinutiaNode)

}
