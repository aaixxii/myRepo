package test.common.format.extraction.payload.abst

import common.util.*

abstract class InputPayloadAbstract {

	OutputPayloadAbstract outputPayload
	StringBuilder inputMinutiaSb

	abstract public String toXmlString()

	public String makeImagePosXml(String pos, String type, File imageFile) {
		String imageB64 = Encoder.binaryToB64(imageFile)
		StringBuilder sb = new StringBuilder("<image pos='${pos}' type='${type}'><data>")
		sb.append(imageB64)
		sb.append("</data></image>")
		return sb.toString()
	}

	public String makeImagePosXml(String pos, String type, String width, String height, File imageFile) {
		String imageB64 = Encoder.binaryToB64(imageFile)
		StringBuilder sb = new StringBuilder("<image pos='${pos}' type='${type}' width='${width}' height='${height}'><data>")
		sb.append(imageB64)
		sb.append("</data></image>")
		return sb.toString()
	}

	public String replaceRollImagesPosToSlap(String imagesXml) {
		for(i in 1..10) {
			int slapPos = selectSlapPos(i)
			imagesXml = imagesXml.replace("pos='$i'", "pos='$slapPos'")
		}
		return imagesXml
	}

	private int selectSlapPos(int rollPos) {
		if(rollPos == 1) {
			return 11
		} else if (rollPos == 6) {
			return 12
		} else if (2 <= rollPos && rollPos <= 5) {
			return rollPos + 38
		} else if (7 <= rollPos && rollPos <= 10) {
			return rollPos + 37
		} else {
			return rollPos
		}
	}
}

