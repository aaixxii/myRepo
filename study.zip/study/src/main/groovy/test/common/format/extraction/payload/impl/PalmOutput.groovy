package test.common.format.extraction.payload.impl

class PalmOutput{
	String pos
	String croppedImage
	String lowResImage
	
	PalmOutput(String pos, String croppedImage, String lowResImage){
		this.pos = pos
		this.croppedImage = croppedImage
		this.lowResImage = lowResImage
	}
}
