package test.common.format.extraction.payload.impl

class Finger {

    String pos
    String status

    public Finger(String pos, String status) {
        this.pos = pos
        this.status = status
    }
   
}
