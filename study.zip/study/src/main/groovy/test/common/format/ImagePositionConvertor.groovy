package test.common.format

class ImagePositionConvertor {
	public static int convertFromNistPos(int nistPos){
		if(nistPos == 11){
			return 1
		}else if(nistPos <= 12){
			return 6
		}else if(nistPos <= 43){
			return nistPos - 38
		}else if(nistPos <= 47){
			return nistPos - 37
		}else{
			assert false, "cannot convert pos=$nistPos!!"
		}
	}
	
	public static int convertSlapFromRoll(int rollPos) {
		if(rollPos == 1) {
			return 11
		} else if (rollPos == 6) {
			return 12
		} else if (2 <= rollPos && rollPos <= 5) {
			return rollPos + 38
		} else if (7 <= rollPos && rollPos <= 10) {
			return rollPos + 37
		} else {
			return rollPos
		}
	}
	
	public static int convertToSlapNistPos(int pos) {
		return convertSlapFromRoll(pos)
	}
}
