package test.common.format.extraction.payload.factory

import test.common.format.extraction.payload.abst.*
import test.common.format.extraction.payload.impl.*

class QcSequenceFactory {

    public static create (Node qcOutputNode){
		char pathSeq = ':'
		if(qcOutputNode.sequence[0].@rolledFingers != null && qcOutputNode.sequence[0].@slapFingers != null){
			List rolledFingers = qcOutputNode.sequence[0].@rolledFingers.tokenize(pathSeq)
			List slapFingers = qcOutputNode.sequence[0].@slapFingers.tokenize(pathSeq)
			QcSequence seq = new QcSequence(rolledFingers, slapFingers)
    		return seq
		}else if(qcOutputNode.sequence[0].@rolledFingers != null && qcOutputNode.sequence[0].@slapFingers == null){
			List rolledFingers = qcOutputNode.sequence[0].@rolledFingers.tokenize(pathSeq)
			List slapFingers = null
			QcSequence seq = new QcSequence(rolledFingers, slapFingers)
    		return seq
		}else if(qcOutputNode.sequence[0].@rolledFingers == null && qcOutputNode.sequence[0].@slapFingers != null){
			List rolledFingers = null
			List slapFingers = qcOutputNode.sequence[0].@slapFingers.tokenize(pathSeq)
			QcSequence seq = new QcSequence(rolledFingers, slapFingers)
    		return seq
		}
    }
}
