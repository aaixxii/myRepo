package test.common.format.extraction.payload.impl

class QcSlapStatus {

    QcSlapStatus QcSlapStatus

    QcSlapStatus(QcSlapStatus QcSlapStatus){
        this.QcSlapStatus = QcSlapStatus
    }
}
