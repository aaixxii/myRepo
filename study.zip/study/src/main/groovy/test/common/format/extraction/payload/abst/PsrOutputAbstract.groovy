package test.common.format.extraction.payload.abst


abstract class PsrOutputAbstract {

}

