package test.common.format.extraction.payload.abst


abstract class OutputPayloadFingerAbstract extends OutputPayloadAbstract {

	protected OutputPayloadFingerAbstract(String outputPayloadXmlString) {
		super(outputPayloadXmlString)
	}

	public updatePos(String pos, int index) {
		fingerOutputList[index].setPos(pos)
	}

	public removeFingerOutput(int index) {
		fingerOutputList.remove(index)
	}

	public updateFisCore(FisCoreAbstract fisCore, int index) {
		fingerOutputList[index].setFisCore(fisCore)
	}

	public updateFisCoreQp(String qualityOfTheCorePosition, int index) {
		fingerOutputList[index].setFisCoreQp(qualityOfTheCorePosition)
	}

	public updateAllFisCoreQp(String qualityOfTheCorePosition) {
		for(FingerOutputAbstract fingerOutput in fingerOutputList) {
			fingerOutput.setFisCoreQp(qualityOfTheCorePosition)
		}
	}

	public updateFisCoreA(String activityBit, int index) {
		fingerOutputList[index].setFisCoreA(activityBit)
	}

	public updateAllFisCoreA(String activityBit) {
		for(FingerOutputAbstract fingerOutput in fingerOutputList) {
			fingerOutput.setFisCoreA(activityBit)
		}
	}

	public updateFisCoreF(String minutiaCoordinate, int index) {
		fingerOutputList[index].setFisCoreF(minutiaCoordinate)
	}

	public updateAllFisCoreF(String minutiaCoordinate) {
		for(FingerOutputAbstract fingerOutput in fingerOutputList) {
			fingerOutput.setFisCoreF(minutiaCoordinate)
		}
	}

	public updateFisCoreCc(String flactionCode, int index) {
		fingerOutputList[index].setFisCoreCc(flactionCode)
	}

	public updateAllFisCoreCc(String flactionCode) {
		for(FingerOutputAbstract fingerOutput in fingerOutputList) {
			fingerOutput.setFisCoreCc(flactionCode)
		}
	}

	public updateFisCoreQd(String qualityOfTheAxisDirection, int index) {
		fingerOutputList[index].setFisCoreQd(qualityOfTheAxisDirection)
	}

	public updateAllFisCoreQd(String qualityOfTheAxisDirection) {
		for(FingerOutputAbstract fingerOutput in fingerOutputList) {
			fingerOutput.setFisCoreQd(qualityOfTheAxisDirection)
		}
	}

	public updateFisCoreQq(String qualityOfTheCorePositionAndDirection, int index) {
		fingerOutputList[index].setFisCoreQq(qualityOfTheCorePositionAndDirection)
	}

	public updateAllFisCoreQq(String qualityOfTheCorePositionAndDirection) {
		for(FingerOutputAbstract fingerOutput in fingerOutputList) {
			fingerOutput.setFisCoreQq(qualityOfTheCorePositionAndDirection)
		}
	}

	public updateFisCoreX(String corePositionHorizontal, int index) {
		fingerOutputList[index].setFisCoreX(corePositionHorizontal)
	}

	public updateAllFisCoreX(String corePositionHorizontal) {
		for(FingerOutputAbstract fingerOutput in fingerOutputList) {
			fingerOutput.setFisCoreX(corePositionHorizontal)
		}
	}

	public updateFisCoreY(String corePositionVertical, int index) {
		fingerOutputList[index].setFisCoreY(corePositionVertical)
	}

	public updateAllFisCoreY(String corePositionVertical) {
		for(FingerOutputAbstract fingerOutput in fingerOutputList) {
			fingerOutput.setFisCoreY(corePositionVertical)
		}
	}

	public updateFisCoreD(String axisAngle, int index) {
		fingerOutputList[index].setFisCoreD(axisAngle)
	}

	public updateAllFisCoreD(String axisAngle) {
		for(FingerOutputAbstract fingerOutput in fingerOutputList) {
			fingerOutput.setFisCoreD(axisAngle)
		}
	}

	public updateFisQuality(FisCoreAbstract fisQuality, int index) {
		fingerOutputList[index].setFisQuality(fisQuality)
	}

	public updateFisQualityS(String zoneQualityValue, int index) {
		fingerOutputList[index].setFisQualityS(zoneQualityValue)
	}

	public updateAllFisQualityS(String zoneQualityValue) {
		for(FingerOutputAbstract fingerOutput in fingerOutputList) {
			fingerOutput.setFisQualityS(zoneQualityValue)
		}
	}

	public updateFisQualityVa(String qualityOfAZone, int index) {
		fingerOutputList[index].setFisQualityVa(qualityOfAZone)
	}

	public updateAllFisQualityVa(String qualityOfAZone) {
		for(FingerOutputAbstract fingerOutput in fingerOutputList) {
			fingerOutput.setFisQualityVa(qualityOfAZone)
		}
	}

	public updateFisQualityVb(String qualityOfBZone, int index) {
		fingerOutputList[index].setFisQualityVb(qualityOfBZone)
	}

	public updateAllFisQualityVb(String qualityOfBZone) {
		for(FingerOutputAbstract fingerOutput in fingerOutputList) {
			fingerOutput.setFisQualityVb(qualityOfBZone)
		}
	}

	public updateFisQualityVc(String qualityOfCZone, int index) {
		fingerOutputList[index].setFisQualityVc(qualityOfCZone)
	}

	public updateAllFisQualityVc(String qualityOfCZone) {
		for(FingerOutputAbstract fingerOutput in fingerOutputList) {
			fingerOutput.setFisQualityVc(qualityOfCZone)
		}
	}

	public updateFisMinutiaNo(FisMinutiaNoAbstract fisMinutiaNo, int index) {
		fingerOutputList[index].setFisMinutiaNo(fisMinutiaNo)
	}

	public updateFisMinutiaNoDb(String deletedNumberOfFeaturePoints, int index) {
		fingerOutputList[index].setFisMinutiaNoDb(deletedNumberOfFeaturePoints)
	}

	public updateAllFisMinutiaNoDb(String deletedNumberOfFeaturePoints) {
		for(FingerOutputAbstract fingerOutput in fingerOutputList) {
			fingerOutput.setFisMinutiaNoDb(deletedNumberOfFeaturePoints)
		}
	}

	public updateFisMinutiaNoMb(String featurePoints, int index) {
		fingerOutputList[index].setFisMinutiaNoMb(featurePoints)
	}

	public updateAllFisMinutiaNoMb(String featurePoints) {
		for(FingerOutputAbstract fingerOutput in fingerOutputList) {
			fingerOutput.setFisMinutiaNoMb(featurePoints)
		}
	}

	public updateAllFisSkeleton(String skeleton) {
		for(FingerOutputAbstract fingerOutput in fingerOutputList) {
			fingerOutput.setFisSkeleton(skeleton)
		}
	}

	public updateFisSkeleton(String skeleton, int index) {
		fingerOutputList[index].setFisSkeleton(skeleton)
	}

	public updateFisMinutiaData(String minutiaData, int index) {
		fingerOutputList[index].setFisMinutiaData(minutiaData)
	}
	public updateFisMinutiaDataSingle(String minutiaData, int index) {
		fingerOutputList[index].setFisMinutiaDataSingle(minutiaData)
	}

	public updateMinutiaData(String minutiaData, int index){
		fingerOutputList[index].setMinutiaData(minutiaData)
	}

	public updateAllFisMinutiaData(String minutiaData) {
		for(FingerOutputAbstract fingerOutput in fingerOutputList) {
			fingerOutput.setFisMinutiaData(minutiaData)
		}
	}

	public updateFisZone(String zone, int index) {
		fingerOutputList[index].setFisZone(zone)
	}

	public updateAllFisZone(String zone) {
		for(FingerOutputAbstract fingerOutput in fingerOutputList) {
			fingerOutput.setFisZone(zone)
		}
	}
}

