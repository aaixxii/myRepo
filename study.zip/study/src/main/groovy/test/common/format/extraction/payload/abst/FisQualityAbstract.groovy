package test.common.format.extraction.payload.abst

abstract class FisQualityAbstract {

	String zoneQualityValue 	// S
	String qualityOfAZone	// VA
	String qualityOfBZone	// VB
	String qualityOfCZone	// VC

	abstract public void setFisQualityInfo(Node fisQualityNode)

}

