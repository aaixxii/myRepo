package test.common.format.extraction.payload.impl

import test.common.format.extraction.payload.abst.*

class FingerOutputCmlaf extends FingerOutputAbstract {
	
	public FingerOutputCmlaf(
		String angle, String fingerConfidence, String patternPrimary, 
		String patternReference, String pos, String quality, String nfiqQuality, String croppedImage) {
	
		super(angle, fingerConfidence, patternPrimary, patternReference, pos, quality, nfiqQuality, croppedImage)
	}

	public String getPos(){
		return super.getPos()
	}
}

