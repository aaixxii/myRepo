package test.common.format

import common.util.*

class DataFormatter{
	DataFormatter(){}
	
	def getAIMVXBase64(imageInfoList){
		def b64 = new String("")
		for (imageInfo in imageInfoList){
			if (imageInfo.size()==2){
				b64 += getSingleAIMVXBase64(imageInfo[0],imageInfo[1])
			}
			else if (imageInfo.size()==3){
				b64 += getSingleAIMVXBase64(imageInfo[0],imageInfo[1],imageInfo[2])
			}
			else {
				assert false, "Exception of imegeInfo.size(). expected 2 or 3. In fact : " + imageInfo.size()  
			}
		}
		return b64
	}
	
	def getSingleAIMVXBase64(file, ampInfo, imagePosition){
	
		def b64String = new Encoder().binaryToB64(file)
	
		String b64 = new String(makeElement("imagePosition", imagePosition))
		b64 += makeElement("ampInfo", ampInfo)
		b64 += makeElement("values", b64String)
		return makeElement("binaryDataList", b64)
		
	}

	def getSingleAIMVXBase64(file, imagePosition){
	
		def b64String = new Encoder().binaryToB64(file)
	
		String b64 = new String(makeElement("imagePosition", imagePosition))
		b64 += makeElement("values", b64String)
		return makeElement("binaryDataList", b64)
	}
	
	def makeElement(String tag, def value){
		return "<${tag}>${value}</${tag}>"
	}
	
	def getAIMVXBase64WithWidthHeightDpi(imageInfoList){
		def b64 = new String("")
		for (imageInfo in imageInfoList){
			b64 += getSingleAIMVXBase64WithWidthHeightDpi(imageInfo[0], imageInfo[1], imageInfo[2], imageInfo[3], imageInfo[4])
		}
		return b64
	}

	def getSingleAIMVXBase64WithWidthHeightDpi(file, imagePosition, width, height, dpi){
		def b64String = new Encoder().binaryToB64(file)
		String b64 = new String(makeElement("imagePosition", imagePosition))
		b64 += makeElement("values", b64String)
		b64 += makeElement("width", width)
		b64 += makeElement("height", height)
		b64 += makeElement("dpi", dpi)
		return makeElement("binaryDataList", b64)
	}

	// dont use 1st and last pos number 
	public static String trimAimImageXml(String imagesXml, int trimPos) {
		String headTrimStr = "<image pos='${trimPos}'" 
		String nextStrOfTrimStr = "<image pos='${trimPos+1}'" 
		return TextFormatter.trimString(imagesXml, headTrimStr, nextStrOfTrimStr)
	}

	public static String trimAimImageXml(String imagesXml, int trimPosStart, int trimPosEnd) {
		String headTrimStr = "<image pos='${trimPosStart}'" 
		String nextStrOfTrimStr = "<image pos='${trimPosEnd}'" 
		return TextFormatter.trimString(imagesXml, headTrimStr, nextStrOfTrimStr)
	}

	public static String trimAimImageSegInfoPos1Xml(String imagesXml) {
		String headTrimStr = "<seg-info pos='1'" 
		String nextStrOfTrimStr = "<seg-info pos='6'" 
		return TextFormatter.trimString(imagesXml, headTrimStr, nextStrOfTrimStr)
	}

	public static String trimAimImageSegInfoXml(String imagesXml, int trimPos) {
		String headTrimStr = "<seg-info pos='${trimPos}'" 
		String nextStrOfTrimStr = "<seg-info pos='${trimPos+1}'" 
		return TextFormatter.trimString(imagesXml, headTrimStr, nextStrOfTrimStr)
	}

	public static String trimAimImageSegInfosXml(String imagesXml, int trimPos) {
		String headRemoveSegInfo = "<seg-info pos='${trimPos}'" 
		String tailRemoveSegInfo = "</seg-info>"
		int headRemoveIndex = imagesXml.indexOf(headRemoveSegInfo)
		int tailRemoveIndex = imagesXml.indexOf(tailRemoveSegInfo, headRemoveIndex+1) + tailRemoveSegInfo.length()
		return TextFormatter.trimString(imagesXml, headRemoveIndex, tailRemoveIndex)
	}

	public static String trimAimImagePos1Xml(String imagesXml) {
		int start = imagesXml.indexOf("<image pos='2'")
		return imagesXml.substring(start)
	}

	public static String trimAimFirstImagePosXml(String imagesXml) {
		String element = "</image>"
		int start = imagesXml.indexOf(element) + element.length()
		return imagesXml.substring(start)
	}

	public static String trimAimLastImagePosXml(String imagesXml) {
		int end = imagesXml.lastIndexOf("<image pos='")
		return imagesXml.substring(0, end)
	}
}

