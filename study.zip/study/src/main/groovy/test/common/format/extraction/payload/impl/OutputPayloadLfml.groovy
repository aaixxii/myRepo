package test.common.format.extraction.payload.impl

import test.common.format.extraction.payload.abst.*
import test.common.format.extraction.payload.factory.*


class OutputPayloadLfml extends OutputPayloadFingerAbstract {

	public OutputPayloadLfml(String outputPayloadXmlString) {
		super(outputPayloadXmlString)
	}

	public void injection() {
		try{
			def parser = new XmlParser().parseText(parseExtOutputsXml(outputPayloadXmlString))
			injectionToFingerOutputList(parser)
			updateAllDbTypes("LDBM")
		}catch (Exception e ){
			e.printStackTrace()
			assert false, "Error OutputPayloadLfml#injection !!\n" + e
		}
	}	

	public void injectionNoUpdateDbType() {
		try{
			def parser = new XmlParser().parseText(parseExtOutputsXml(outputPayloadXmlString))
			injectionToFingerOutputList(parser)
		}catch (Exception e ){
			e.printStackTrace()
			assert false, "Error OutputPayloadLfml#injection !!\n" + e
		}
	}	

	private injectionToFingerOutputList(Node outputPayloadRootNode) {
		fingerOutputList = OutputPayloadLfmlFactory.createFingerOutputList(outputPayloadRootNode)
	}

	public updateDbType(String dbType, int index) {
		fingerOutputList[index].setDbTypes(dbType)
	}

	public updateDbTypes(String dbType, List<Integer> indexList) {
		for(Integer index in indexList) {
			fingerOutputList[index].setDbTypes(dbType)
		}
	}

	public updateAllDbTypes(String dbType) {
		for(FingerOutputAbstract fingerOutput in fingerOutputList) {
			fingerOutput.setDbTypes(dbType)
		}
	}
}

