package test.common.format.extraction.payload.impl

class QcItem {
	
	String activity
	List data
	String status
	
	public QcItem(String activity, List data, String status) {
		this.activity = activity
		this.data = data
		this.status = status
	}
}
