package test.common.format.extraction.payload.impl

class QcOutPutMode2 {

	QcSequence seq 
	QcHistory history
	String status

	public QcOutPutMode2(String status, QcSequence seq, QcHistory history){
		this.status = status
		this.seq = seq
		this.history = history
	}
}
