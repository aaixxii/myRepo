package test.common.format.extraction.payload.impl

import test.common.format.extraction.payload.abst.*


class FisCoreCmlaf extends FisCoreAbstract {

	public void setFisCoreInfo(Node fisCoreNode){
		super.setActivityBit(fisCoreNode.attribute("A"))
		super.setFlactionCode(fisCoreNode.attribute("CC"))
		super.setAxisAngle(fisCoreNode.attribute("D"))
		super.setMinutiaCoordinate(fisCoreNode.attribute("F"))
		super.setQualityOfTheAxisDirection(fisCoreNode.attribute("QD"))
		super.setQualityOfTheCorePosition(fisCoreNode.attribute("QP"))
		super.setQualityOfTheCorePositionAndDirection(fisCoreNode.attribute("QQ"))
		super.setCorePositionHorizontal(fisCoreNode.attribute("X"))
		super.setCorePositionVertical(fisCoreNode.attribute("Y"))
	}
}

