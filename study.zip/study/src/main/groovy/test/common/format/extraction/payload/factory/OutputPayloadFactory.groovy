package test.common.format.extraction.payload.factory

import test.common.format.extraction.payload.abst.*

interface OutputPayloadFactory {

	public createFingerOutputList(Node outputPayloadRootNode) 
	public FingerOutputAbstract createFingerOutput(Node fingerOutputNode)
	public List<FisDataAbstract> createFisDataList(Node fingerOutputNode)
	public FisDataAbstract createFisData(Node fisDataNode) 
	public FisCoreAbstract createFisCore(Node fisCoreNode)
	public FisQualityAbstract createFisQuality(Node fisQualityNode)
	public FisMinutiaNoAbstract createFisMinutiaNo(Node fisMinutiaNode)
}

