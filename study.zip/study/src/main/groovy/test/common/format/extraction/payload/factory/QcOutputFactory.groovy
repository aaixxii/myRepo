package test.common.format.extraction.payload.factory

import test.common.format.extraction.payload.abst.*
import test.common.format.extraction.payload.impl.*
import test.common.format.extraction.payload.factory.*

class QcOutputFactory {

	public static QcOutPutFactoryMode1(String extractionOutputPayload){
		Node root = new XmlParser().parseText(extractionOutputPayload)
		Node qcOutputNode = root."extraction-outputs-payload"."tenprint-output"."qc-output"[0]
		def	qcOutput = createMode1(qcOutputNode)
		return qcOutput
	}

	public static QcOutPutFactoryMode2(String extractionOutputPayload){
		Node root = new XmlParser().parseText(extractionOutputPayload)
		Node qcOutputNode = root."extraction-outputs-payload"."tenprint-output"."qc-output"[0]
		def	qcOutput = createMode2(qcOutputNode)
		return qcOutput
	}
	
	public static createMode1 (Node qcOutputNode){
		String total = qcOutputNode.attribute("total")
		List<RollStatus> rollStatusList = new ArrayList<RollStatus>()
		List<SlapStatus> slapStatusList = new ArrayList<SlapStatus>()
		rollStatusList = QcRollStatusFactory.create(qcOutputNode)
		slapStatusList = QcSlapStatusFactory.create(qcOutputNode)
		QcOutPutMode1 output = new QcOutPutMode1(total, rollStatusList, slapStatusList)
		return output
	}

	public static createMode2 (Node qcOutputNode){
		String status = qcOutputNode.attribute("status")
		QcSequence seq = QcSequenceFactory.create(qcOutputNode)
		QcHistory history = QcHistoryFactory.create(qcOutputNode)
		QcOutPutMode2 output = new QcOutPutMode2(status, seq, history)
		return output
	}
}
