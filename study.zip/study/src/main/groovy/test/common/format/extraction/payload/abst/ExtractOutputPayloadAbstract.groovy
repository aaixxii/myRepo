package test.common.format.extraction.payload.abst


abstract class ExtractOutputPayloadAbstract {

	String outputPayloadXml

	public ExtractOutputPayloadAbstract(String outputPayloadXml){
		this.outputPayloadXml = outputPayloadXml
	}
}

