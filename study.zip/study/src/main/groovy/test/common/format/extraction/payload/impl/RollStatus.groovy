package test.common.format.extraction.payload.impl

class RollStatus {
    
	Finger finger

	public RollStatus(Finger finger) {
		this.finger = finger
	}
}
