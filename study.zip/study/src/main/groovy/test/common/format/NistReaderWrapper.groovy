package test.common.format

import jp.co.nec.nhm.soapui.util.NistReader
import test.degrade.properties.*


class NistReaderWrapper{
	
	private static final String DEFAULT_NIST="/degradeTest/TI/nist/TR_1.Full.nst"
	private String dataFilePathRoot

	NistReaderWrapper(context){
		this.dataFilePathRoot = new GlobalProperties(context).getDataFilePath()
	}

	def getNistFingerImgXml(String nistPath){
		NistReader reader = new NistReader(nistPath)
		return reader.getFingerPrints()
	}

	def getNistPalmImgXml(String nistPath){
		NistReader reader = new NistReader(nistPath)
		return reader.getPalms()
	}

	def getDefaultNistFingerImgXml() {
		return getNistFingerImgXml(dataFilePathRoot + DEFAULT_NIST)
	}

	def getDefaultNistPalmImgXml() {
		return getNistPalmImgXml(dataFilePathRoot + DEFAULT_NIST)
	}
}
