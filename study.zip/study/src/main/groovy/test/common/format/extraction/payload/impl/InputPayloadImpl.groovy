package test.common.format.extraction.payload.impl

import test.common.format.extraction.payload.abst.*
import test.common.format.extraction.payload.factory.*

class InputPayloadImpl extends InputPayloadAbstract {

	public String toXmlString() {
		println "do nothing"
	}
}

