package test.common.format.extraction.payload.impl

import test.common.format.extraction.payload.abst.*

class FingerOutputTenprint extends FingerOutputAbstract {
	
	public FingerOutputTenprint(
		String angle, String fingerConfidence, String patternPrimary,
		String patternReference, String pos, String quality, String nfiqQuality, String croppedImage, String lowResImage) {
	
		super(angle, fingerConfidence, patternPrimary, patternReference, pos, quality, nfiqQuality, croppedImage, lowResImage)
	}
		
	public FingerOutputTenprint(
		String angle, String fingerConfidence, String patternPrimary, 
		String patternReference, String pos, String quality, String nfiqQuality, String croppedImage) {
	
		super(angle, fingerConfidence, patternPrimary, patternReference, pos, quality, nfiqQuality, croppedImage)
	}

	public String getPos(){
		return super.getPos()
	}
}

