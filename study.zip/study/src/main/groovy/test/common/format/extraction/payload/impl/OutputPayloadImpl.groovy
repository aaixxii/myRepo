package test.common.format.extraction.payload.impl

import test.common.format.extraction.payload.abst.*
import test.common.format.extraction.payload.factory.*


class OutputPayloadImpl extends OutputPayloadFingerAbstract {

	public OutputPayloadImpl(String outputPayloadXmlString) {
		super(outputPayloadXmlString)
	}

	public void injection() {
		println "nothing to do."
	}	
}

