package test.common.format.extraction.payload.factory

import test.common.format.extraction.payload.impl.CropInfo
import test.common.format.extraction.payload.impl.CropPoints

class CropInfoFactory {
	
	public static CropInfo create(Node cropInfoNode){
		CropInfo cropInfo = new CropInfo()
		if(cropInfoNode == null){
			return cropInfo
		}
		cropInfo.setCenter(createCenter(cropInfoNode))
		cropInfo.setCropPoints(create4Points(cropInfoNode))
		return cropInfo
	}

	public static CropInfo createFromInput(Node cropInfoNode){
		CropInfo cropInfo = new CropInfo()
		if(cropInfoNode == null){
			return cropInfo
		}
		Node cropPointsNode = cropInfoNode."crop-points"[0]
		if(cropPointsNode."points".size() == 4){
			return create(cropInfoNode)
		}
		Node pointsNode1 = cropPointsNode."points"[0]
		Node pointsNode2 = cropPointsNode."points"[1]
		set4PointsFrom2Points(pointsNode1, pointsNode2, cropInfo)
		setCenterFrom2Points(pointsNode1, pointsNode2, cropInfo)
		return cropInfo
	}

	private static setCenterFrom2Points(Node pointsNode1, Node pointsNode2, CropInfo cropInfo) {
		CropPoints center = createCenterFrom2Point(pointsNode1, pointsNode2)
		cropInfo.setCenter(center)
	}

	private static set4PointsFrom2Points(Node pointsNode1, Node pointsNode2, CropInfo cropInfo) {
		List<CropPoints> crop4Points = create4PointsFrom2Points(pointsNode1, pointsNode2)
		cropInfo.setCropPoints(crop4Points)
	}

	private static CropPoints createCenterFrom2Point(Node pointsNode1, Node pointsNode2) {
		int x1 = pointsNode1.attribute("X") as int
		int y1 = pointsNode1.attribute("Y") as int
		int x2 = pointsNode2.attribute("X") as int
		int y2 = pointsNode2.attribute("Y") as int
		int x = ((x2+x1)/2)
		int y = ((y2+y1)/2)
		CropPoints center = new CropPoints(x as String, y as String)
		return center
	}

	private static List create4PointsFrom2Points(Node pointsNode1, Node pointsNode2) {
		String x1 = pointsNode1.attribute("X")
		String y1 = pointsNode1.attribute("Y")
		String x2 = pointsNode2.attribute("X")
		String y2 = pointsNode2.attribute("Y")
		CropPoints points1 = new CropPoints(x1, y1)
		CropPoints points2 = new CropPoints(x2, y1)
		CropPoints points3 = new CropPoints(x2, y2)
		CropPoints points4 = new CropPoints(x1, y2)
		List<CropPoints> crop4Points = new ArrayList<CropPoints>()
		crop4Points.add(points1)
		crop4Points.add(points2)
		crop4Points.add(points3)
		crop4Points.add(points4)
		return crop4Points
	}
	
	private static List<CropPoints> create4Points(Node cropInfoNode) {
		Node cropPointsNode = cropInfoNode."crop-points"[0]
		List<CropPoints> crop4Points = new ArrayList<CropPoints>()
		for(Node pointsNode in cropPointsNode."points"){
			String x = pointsNode.attribute("X")
			String y = pointsNode.attribute("Y")
			CropPoints points = new CropPoints(x, y)
			crop4Points.add(points)
		}
		return crop4Points
	}

	private static CropPoints createCenter(Node cropInfoNode) {
		Node centerNode = cropInfoNode."center"[0]
		String centerX = centerNode.attribute("X")
		String centerY = centerNode.attribute("Y")
		CropPoints center = new CropPoints(centerX, centerY)
		return center
	}
}
