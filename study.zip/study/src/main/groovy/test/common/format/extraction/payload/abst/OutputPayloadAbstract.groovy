package test.common.format.extraction.payload.abst

import test.common.format.extraction.payload.impl.PalmOutput


abstract class OutputPayloadAbstract {

    private static String EXTRACTION_OUTPUTS_PAYLOAD_PRE = "<extraction-outputs-payload>"
    private static String EXTRACTION_OUTPUTS_PAYLOAD_SUF = "</extraction-outputs-payload>"
    private static String EXTRACTION_OUTPUTS_PAYLOAD_NS_PRE = "<ns2:ext-output xmlns:ns2='urn:nec:aim'>"
    private static String EXTRACTION_OUTPUTS_PAYLOAD_NS_SUF = "</ns2:ext-output>"


	String outputPayloadXmlString
	List<FingerOutputAbstract> fingerOutputList = new ArrayList<FingerOutputAbstract>()
	List<PalmOutput> palmOutputList = new ArrayList<PalmOutput>()

	protected OutputPayloadAbstract(String outputPayloadXmlString) {
		this.outputPayloadXmlString = outputPayloadXmlString
	}

	abstract public void injection()

    public static String parseExtOutputsXmlWithNs(String extractJobResultXml) {
		extractJobResultXml = parseExtOutputsXml(extractJobResultXml)
		return extractJobResultXml.
						replaceAll(EXTRACTION_OUTPUTS_PAYLOAD_PRE, EXTRACTION_OUTPUTS_PAYLOAD_NS_PRE).
						replaceAll(EXTRACTION_OUTPUTS_PAYLOAD_SUF, EXTRACTION_OUTPUTS_PAYLOAD_NS_SUF)
	}

    public static String parseExtOutputsXml(String extractJobResultXml) {
        int start = extractJobResultXml.indexOf(EXTRACTION_OUTPUTS_PAYLOAD_PRE) 
        int end = extractJobResultXml.indexOf(EXTRACTION_OUTPUTS_PAYLOAD_SUF) + EXTRACTION_OUTPUTS_PAYLOAD_SUF.length()
        return extractJobResultXml.substring(start, end)
    }

}

