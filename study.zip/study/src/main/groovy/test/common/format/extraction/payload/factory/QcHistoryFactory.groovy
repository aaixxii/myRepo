package test.common.format.extraction.payload.factory

import test.common.format.extraction.payload.abst.*
import test.common.format.extraction.payload.impl.*
import test.common.format.extraction.payload.factory.*

class QcHistoryFactory {

    public static create (Node qcOutputNode){
        QcHistory history = QcItemFactory.create(qcOutputNode)
        return history
    }
}
