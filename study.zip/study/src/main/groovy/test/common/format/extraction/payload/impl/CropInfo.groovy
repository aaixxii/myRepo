package test.common.format.extraction.payload.impl


class CropInfo {

	List<CropPoints> cropPoints
	CropPoints center
}

