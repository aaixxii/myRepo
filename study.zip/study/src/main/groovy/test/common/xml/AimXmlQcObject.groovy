package test.common.xml

import common.xml.*
import test.degrade.assertion.xml.*

class AimXmlQcObject extends XMLObject{
	def xmlString
	
	def AimXmlQcObject(xmlString){
		super(xmlString)
		this.xmlString = xmlString
	}
	
	public String getExtractErrMssg(){
		return xmlRoot.error[0].text()
	}

	def getQcSize(){
		return xmlRoot."extraction-outputs-payload"."tenprint-output"."qc-output".size()
	}

	def getQcItemSize(){
		return xmlRoot."extraction-outputs-payload"."tenprint-output"."qc-output".history.item.size()
	}

	def getQcTotalAttribute (){
		return xmlRoot."extraction-outputs-payload"."tenprint-output"."qc-output".@total
	}

	def getQcStatusAttribute (){
		return xmlRoot."extraction-outputs-payload"."tenprint-output"."qc-output".@status
	}

	def getQcSequenceList (){
		String rolledList = xmlRoot."extraction-outputs-payload"."tenprint-output"."qc-output".sequence.@rolledFingers
		String slapList = xmlRoot."extraction-outputs-payload"."tenprint-output"."qc-output".sequence.@slapFingers
		String fingerList = rolledList + slapList
		return fingerList
	}
	
	def getActivitySlapDuplicate(){
		int itemSize = getQcItemSize()
		
		String activityName ="slapDuplicate"
		for(i in itemSize){
			def p = i	
			String activity = xmlRoot."extraction-outputs-payload"."tenprint-output"."qc-output".history.item["$i"].@activity
			if(activityName == activity)
				data = xmlRoot."extraction-outputs-payload"."tenprint-output"."qc-output".history.item["$p"].@data
				status = xmlRoot."extraction-outputs-payload"."tenprint-output"."qc-output".history.item["$p"].@status
				String resultValue = data + status	
			}
		}

	def getExceptionFaults(){
		return xmlRoot."env:Body"."env:Fault"
	}

	def getExceptionFaultSize(){
		return getExceptionFaults().size()
	}

	def getExceptionFaultMessg(){
		return getExceptionFaults().faultstring.text()
	}
}


