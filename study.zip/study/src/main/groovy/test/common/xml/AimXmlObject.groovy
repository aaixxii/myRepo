package test.common.xml

import common.xml.*
import test.degrade.assertion.xml.*

class AimXmlObject extends XMLObject{
	def xmlString
	
	def AimXmlObject(xmlString){
		super(xmlString)
		this.xmlString = xmlString
	}
	
	public String getExtractErrMssg(){
		return xmlRoot.error[0].text()
	}

	def getCandidateSize(){
		return xmlRoot.candidate.size()
	}

	def getCandidates(){
		return xmlRoot.candidate
	}

    	def getQcSize(){
        	return xmlRoot."extraction-outputs-payload"."tenprint-output"."qc-output".size()
    	}

    	def getQcTotalAttribute (){
       		return xmlRoot."extraction-outputs-payload"."tenprint-output"."qc-output".@total
    	}

    	def getQcStatusAttribute (){
        	return xmlRoot."extraction-outputs-payload"."tenprint-output"."qc-output".@status
    	}

	def getExceptionFaults(){
		return xmlRoot."env:Body"."env:Fault"
	}
	
	def getSoapExceptionFaults(){
		return xmlRoot."soap:Body"."soap:Fault"
	}

	def getExceptionFaultSize(){
		return getExceptionFaults().size()
	}

	def getExceptionFaultMessg(){
		return getExceptionFaults().faultstring.text()
	}
	
	def getSoapExceptionFaultMessg(){
		return getSoapExceptionFaults().faultstring.text()
	}

	def getInputCropPoint(fingerNumber, position){
		def point = ""
		def xpathMapper = new XpathMapper()
		def pathX = new XpathMapper().createInputCropPointXpath(fingerNumber, position, "X")
		def pathY = new XpathMapper().createInputCropPointXpath(fingerNumber, position, "Y")
		point += XMLUtil.getElementValue(pathX, xmlString) + ","
		point += XMLUtil.getElementValue(pathY, xmlString)
		return point
	}
}


