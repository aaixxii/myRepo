package test.common.entity

class SegmentEntity {
	def binId
	def segId
	def segSetId
	def bioIdStart
	def bioIdEnd
	def lengthCompacted
	def recCnt
	def version
	def revision
	def lengthUnCompacted
	
}


