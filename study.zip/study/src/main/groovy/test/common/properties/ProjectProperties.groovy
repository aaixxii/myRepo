package test.common.properties

import test.degrade.util.*

class ProjectProperties{
	def soapuiObject

	ProjectProperties(context){
		this.soapuiObject = new SoapuiObject(context)
	}

	def String getProperty(String key){
		return soapuiObject.getProjectProperty(key)
	}
}

