package test.common.util.vm

import test.common.util.db.*
import test.degrade.util.*
import test.degrade.properties.*
import common.os.linux.*

class VerifyManager{
	def final String MAX_THREADS = "max.threads"
	def globalProperties
	def soapuiObject
	String vmIp
	String vmUser
	String vmPass
	String vmHome
	String sshShell
	String scpShell


	VerifyManager(context){
		this.globalProperties = new GlobalProperties(context)
		this.soapuiObject = new SoapuiObject(context)
		this.vmIp = globalProperties.getVmIp()
		this.vmUser = globalProperties.getVmUser()
		this.vmPass = globalProperties.getVmPass()
		this.vmHome = globalProperties.getVmJbossHome()
		String shellDir = globalProperties.getSubtoolDir()
		this.sshShell = "${shellDir}/common_tools/exec_ssh_cmd_automatically_input_pass.sh"
		this.scpShell = "${shellDir}/common_tools/exec_scp_cmd_automatically_input_pass.sh"
	}

	def getDBTime(){
		def sqlExecuter = new SqlExecutorFactory(soapuiObject.getContext()).create()
		return sqlExecuter.getSqlResultOneRecord("select to_char(systimestamp, 'HH24:MI:SS') from dual")
	}

	def startJBoss() {
                String startCmd = "cd ${vmHome}; bin/run.sh -b 0.0.0.0 >> nohup.out 2>&1 < /dev/null &"
                executeVmShell(startCmd)
        }

	def stopJBoss() {
		String stopShellPath = globalProperties.getSubtoolDir() + "/aim/tools/xStopVM.sh"
		List args = [ stopShellPath, "${vmUser}@${vmIp}:${vmHome}" , vmPass ]
		new LinuxCommander().doShWithArgs(scpShell, args)
		String stopCmd = "cd ${vmHome}; ./xStopVM.sh"
		executeVmShell(stopCmd)
	}

	def executeVmShell(String command) {
		List args = [ vmUser, vmIp, command, vmPass ]
		return new LinuxCommander().doShWithArgs(sshShell, args)
	}

	def getMaxThreads() {
		def cmd = createGrepRunConf(MAX_THREADS)
		executeVmShell(cmd)
	}

	def createGrepRunConf(grepWord) {
		return "grep '${grepWord}' ${vmHome}/bin/run.conf |awk -F '=' '{print \$3}' |sed 's/\"//g'"
	}
}


		
