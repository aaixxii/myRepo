package test.common.util.tool

import common.os.linux.*
import test.degrade.properties.GlobalProperties
import test.degrade.util.SoapuiObject
import java.io.*;

class ToolExecutor{
	def globalProperties
	def soapuiObject
	String sshShell
	String edamameShell
	String bunkaiShell

	ToolExecutor(context){
		this.globalProperties = new GlobalProperties(context)
		this.soapuiObject = new SoapuiObject(context)
		String shellDir = globalProperties.getSubtoolDir()
		this.sshShell = "${shellDir}/common_tools/exec_ssh_cmd_automatically_input_pass.sh"
		this.edamameShell = "${shellDir}/common_tools/edamame/eat_edamame.sh"
		this.bunkaiShell = "${shellDir}/common_tools/bunkai/exec_devide.sh"
	}


	public List doBunkai(String multiFePath, String outputDirPath){
		File file = new File(bunkaiShell)
		def tmpType = "dbl"
		if(file.exists()){
			List argList = [ multiFePath,  outputDirPath , tmpType ]
			return doShellList(bunkaiShell, argList)
		}else{
			assert false, "Tool is not exist!"
		}
	}

	public List doBunkai_X(String multiFePath, String outputDirPath){
		File file = new File(bunkaiShell)
		def tmpType = "xdbl"
		if(file.exists()){
                	List argList = [ multiFePath,  outputDirPath , tmpType ]
                	return doShellList(bunkaiShell, argList)
      		}else{
			assert false, "Tool is not exist!"
		}
	}
	
	public void doEdamame(String cmlafTemplatePath, String outputDirPath){
		File file = new File(edamameShell)
		if(file.exists()){
			List argList = [ cmlafTemplatePath, outputDirPath ]
			doShell(edamameShell, argList)
		}else{
                	assert false, "Tool is not exist!"
        	}	
	}
	
	private void doShell(String shellPath, List argList){
		def linuxCmmder = new LinuxCommander()
		linuxCmmder.doShWithArgs(shellPath, argList)
	}

	private List doShellList(String shellPath, List argList){
		def linuxCmmder = new LinuxCommander()
			return linuxCmmder.doShWithArgs(shellPath, argList)
	}

}


		
