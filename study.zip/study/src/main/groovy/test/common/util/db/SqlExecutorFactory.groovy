package test.common.util.db

import common.sql.*
import test.degrade.properties.*

class SqlExecutorFactory{
	def globalProperties

	SqlExecutorFactory(){}

	SqlExecutorFactory(context){
		this.globalProperties = new GlobalProperties(context)
	}

	def create(){
		def ip = globalProperties.getDBIP()
		def port = globalProperties.getDBPort()
		def sid = globalProperties.getDBSID()
		def user = globalProperties.getDBUser()
		def pass = globalProperties.getDBPass()
		return new SqlExecutor(ip, port, sid, user, pass)
	}

	def create(ip, port, sid, user, pass){
		return new SqlExecutor(ip, port, sid, user, pass)
	}
}
