package test.common.util.db

import common.sql.*
import test.common.constants.aim.*
import test.common.runner.*
import test.degrade.util.*

class ClearPersonBio{
	SqlExecutor sqlExecutor
	def testCase
	def testStep

	ClearPersonBio(context, testCaseName, testStepName){
		this(context)
		SoapuiObject soapuiObject = new SoapuiObject(context)
		this.testCase = soapuiObject.getTestCaseInSameSuite(testCaseName)
		this.testStep = soapuiObject.getTestStepInOtherCase(testCase, testStepName)
	}

	ClearPersonBio(context, testSuiteName, testCaseName, testStepName){
		this(context)
		SoapuiObject soapuiObject = new SoapuiObject(context)
		this.testCase = soapuiObject.getTestCaseInOtherSuite(testSuiteName, testCaseName)
		this.testStep = soapuiObject.getTestStepInOtherCase(testCase, testStepName)
	}

	ClearPersonBio(context){
		this.sqlExecutor = new SqlExecutorFactory(context).create()
	}

	def deletePersonBio(){
		def testCaseExecutor = new TestCaseExecutor(testCase, testStep)
		def records = sqlExecutor.getSqlResult(AIMSql.SELECT_EXTID_BINID_EVENTID_FROM_PERSONBIO)

		for(record in records){
			testCaseExecutor.setupTestStep(record)
			testCaseExecutor.runTestCase()
		}
	}
	
	def resetDB(){
		sqlExecutor.sqlExecute("delete from person_biometrics")
		sqlExecutor.sqlExecute("delete from segments")
		sqlExecutor.commit()
	}
}
