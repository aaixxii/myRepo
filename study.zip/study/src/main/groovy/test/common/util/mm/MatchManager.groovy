package test.common.util.mm

import test.common.util.db.*
import test.degrade.util.*
import test.degrade.properties.*
import common.sql.SqlExecutor
import common.os.linux.*
import common.util.*
import common.queue.SingletonMapQueue
import static test.common.constants.aim.AIMWord.*


class MatchManager{
	DeceiveMatchManager dmm
	SqlExecutor sqlExecutor
	def globalProperties
	String mmIp
	String mmUser
	String mmPass
	String mmHome
	String sshShell
	String scpShell

	MatchManager(context){
		this.dmm = new DeceiveMatchManager(context)
		this.sqlExecutor = new SqlExecutorFactory(context).create()
		this.globalProperties = new GlobalProperties(context)
		this.mmIp = globalProperties.getMmIp()
		this.mmUser = globalProperties.getMmUser()
		this.mmPass = globalProperties.getMmPass()
		this.mmHome = globalProperties.getMmHome()
		String shellDir = globalProperties.getSubtoolDir()
		this.sshShell = "${shellDir}/common_tools/exec_ssh_cmd_automatically_input_pass.sh"
		this.scpShell = "${shellDir}/common_tools/exec_scp_cmd_automatically_input_pass.sh"
	}

	def changeSystemConfig(key, value){
		updateSystemConfig(key, value)
//		cacheClear()
	}

	def updateSystemConfig(key, value){
		def sql = "update system_config set property_value = '${value}' where property_name = '${key}'"
		sqlExecutor.sqlExecute(sql)
		sqlExecutor.sqlExecute("commit")
	}

	def getSystemConfig(key){
		def sql = "select property_value from system_config where property_name = '${key}'"
		sqlExecutor.getSqlResult(sql)
		
	}

	def updateExtractJobTimeout(value){
		updateTljTimeout("EXTRACTION", value)
	}

	def updateTljTimeout(funcName, value){
		def sql = "update function_types set TOP_LEVEL_JOB_TIMEOUTS = ${value} where function_name = '${funcName}'"
		sqlExecutor.sqlExecute(sql)
		sqlExecutor.sqlExecute("commit")
	}

	def updateCjTimeout(funcName, value){
		def sql = "update function_types set CONTAINER_JOB_TIMEOUTS = ${value} where function_name = '${funcName}'"
		sqlExecutor.sqlExecute(sql)
		sqlExecutor.sqlExecute("commit")
	}

	def updateJobLimit(funcName, value){
		def sql = "update function_types set JOB_LIMIT = ${value} where function_name = '${funcName}'"
		sqlExecutor.sqlExecute(sql)
		sqlExecutor.sqlExecute("commit")
	}

	def updateXsdSchemaVersion(String value){
		String XSD_SCHEMA_VERSION ="VERSION.XSD_SCHEMA"
		updateSystemConfig(XSD_SCHEMA_VERSION, value)
	}

	
	def setTvOn(){
		String TEMPLATE_VALIDATION_ENABLED = "TEMPLATE_VALIDATION.ENABLED"
		def value = "true"
		updateSystemConfig(TEMPLATE_VALIDATION_ENABLED, value)
	}

	def setTvOff(){
		String TEMPLATE_VALIDATION_ENABLED = "TEMPLATE_VALIDATION.ENABLED"
		def value = "false"
		updateSystemConfig(TEMPLATE_VALIDATION_ENABLED ,value)
	}

	def cacheClear(){
		def serviceEndpoint = globalProperties.getServiceEndpoint()
		def contextRoot = globalProperties.getServiceContextRoot()
		URL url = new URL("${serviceEndpoint}/${contextRoot}/cache/clear");
		HttpURLConnection http = (HttpURLConnection)url.openConnection();
		http.setRequestMethod("GET");
		http.connect();
		BufferedInputStream bis = new BufferedInputStream( http.getInputStream() );
	}

	def getDBTime(){
		return sqlExecutor.getSqlResultOneRecord("select to_char(systimestamp, 'HH24:MI:SS') from dual")
	}

	def startJBoss() {
		String startShellPath = globalProperties.getSubtoolDir() + "/aim/tools/runMM_5.0.sh"
		List args = [ startShellPath," ${mmUser}@${mmIp}:${mmHome}" , mmPass ]
		new LinuxCommander().doShWithArgs(scpShell, args)
		String startCmd = "cd ${mmHome}; ./runMM_5.0.sh"
		executeMmShell(startCmd)
		sleep 3000
		logMmStatus("start")
	}

	def stopJBoss() {
		String stopShellPath = globalProperties.getSubtoolDir() + "/aim/tools/xStopWildFly.sh"
		List args = [ stopShellPath," ${mmUser}@${mmIp}:${mmHome}" , mmPass ]
		new LinuxCommander().doShWithArgs(scpShell, args)
		String stopCmd = "cd ${mmHome}; ./xStopWildFly.sh"
		executeMmShell(stopCmd)
		logMmStatus("stop")
	}
	
	static final String MM_TMP_LOG = "./rebootMM.log"
	
	def logMmStatus(String operation){
		File f = new File(MM_TMP_LOG)
		f.append("--------------------------------\n")
		f.append("After ${operation} MM\n")
		f.append("--------------------------------\n")
		String cmd = "echo; date +'%Y-%m-%d %H:%M:%S.%N'; ps -ef | grep java; ls -l --full-time ${mmHome}/standalone/deployments/"
		List result = executeMmShell(cmd)
		for(line in result){
			f.append("${line}\n")
		}
		f.append("--------------------------------\n\n")
	}
	
	def restartJBoss() {
		stopJBoss()
		startJBoss()
		sleep 60000
	}

	def executeMmShell(String command) {
		List args = [ mmUser, mmIp, command, mmPass ]
		return new LinuxCommander().doShWithArgs(sshShell, args)
	}

	def changeToPZIP() {
		List sqls = ["insert into FORMAT_TYPES values(4,'[PFR] + PZIP(3276)','PDB_PZIP')",
			"insert into FORMAT_TYPES values(5,'[PFR] + PZIP(128)','PLDB_PZIP')",
			"update containers set FORMAT_ID = 4 where FORMAT_ID = 14",
			"update containers set FORMAT_ID = 5 where FORMAT_ID = 15",
			"update function_types set TARGET_FORMAT_ID = 4 where TARGET_FORMAT_ID = 14",
			"update function_types set TARGET_FORMAT_ID = 5 where TARGET_FORMAT_ID = 15",
			"delete from FORMAT_TYPES where DETAILS = '[PFR] + PC3R(3276)'",
			"delete from FORMAT_TYPES where DETAILS = '[PFR] + PC3R(128)'",
			"update FORMAT_TYPES set FORMAT_NAME = 'PDB' where FORMAT_ID = 4",
			"update FORMAT_TYPES set FORMAT_NAME = 'PLDB' where FORMAT_ID = 5"]
		for(sql in sqls) {
			sqlExecutor.sqlExecute(sql)
		}
		sqlExecutor.sqlExecute("commit")

	}
	
	def changeToPC3R() {
		List sqls = ["insert into FORMAT_TYPES values(14,'[PFR] + PC3R(3276)','PDB_PC3R')",
			"insert into FORMAT_TYPES values(15,'[PFR] + PC3R(128)','PLDB_PC3R')",
			"update containers set FORMAT_ID = 14 where FORMAT_ID = 4",
			"update containers set FORMAT_ID = 15 where FORMAT_ID = 5",
			"update function_types set TARGET_FORMAT_ID = 14 where TARGET_FORMAT_ID = 4",
			"update function_types set TARGET_FORMAT_ID = 15 where TARGET_FORMAT_ID = 5",
			"delete from FORMAT_TYPES where DETAILS = '[PFR] + PZIP(3276)'",
			"delete from FORMAT_TYPES where DETAILS = '[PFR] + PZIP(128)'",
			"update FORMAT_TYPES set FORMAT_NAME = 'PDB' where FORMAT_ID = 14",
			"update FORMAT_TYPES set FORMAT_NAME = 'PLDB' where FORMAT_ID = 15"]
		for(sql in sqls) {
			println sql
			sqlExecutor.sqlExecute(sql)
		}
		sqlExecutor.sqlExecute("commit")

	}

	def enableFlowControl(){
		updateFlowControl("true")
	}
	
	def disableFlowControl(){
		updateFlowControl("false")
	}
		
	def updateFlowControl(def flag){
		def sql = "update system_init set KEY_VALUE = '${flag}' where KEY_NAME = 'FLOW_CONTROL_ENABLED'"
		sqlExecutor.sqlExecute(sql)
		sqlExecutor.sqlExecute("commit")
		restartJBoss()
	}

	def insertDummySegRecs(def numRecord){
		insertDummySegRecs(XDBL_ID, numRecord)
	}

	def insertDummySegRecs(def binId, def numRecord){
		dmm.insertDummySegRecs(binId, numRecord)
	}
	
	def insertDummySegRec(int segId,int segSetId,int bioIdStart,int bioIdEnd){
		dmm.insertDummySegRec(segId, segSetId, bioIdStart, bioIdEnd)
	}
	
	def insertDummyMuSegReports(){
		dmm.insertDummyMuSegReports()
	}

	def insertDummyJobQueueRecs(def numRecords){
		dmm.insertDummyJobQueueRecs(numRecords)
	}

	def insertDummyJobQueueRec(int jobId){
		dmm.insertDummyJobQueueRec(jobId)
	}
	
	def fetchNextSegId(){
		dmm.fetchNextSegId()
	}

	def fetchSegSetId(def binId){
		dmm.fetchSegSetId(binId)
	}

	def fetchNextBioId(){
		dmm.fetchNextBioId()
	}
	
	def fetchNextJobId(){
		dmm.fetchNextJobId()
	}
	
	def updateJobQueueJobStateExistMuJobs(){
		dmm.updateJobQueueJobStateExistMuJobs()
	}
	
	def insertAll(Object sqlExecuter, String sql){
		dmm.insertAll(sqlExecuter,sql)
	}
	
	def insertAllUseJdbcTemp(Object JdbcTemp, String sql){
		dmm.insertAllUseJdbcTemp(jdbcTemplate, sql)
	}

	def reCreateJobQueueSeq(startNum){
		dmm.reCreateJobQueueSeq(startNum)
	}
	
	def reCreateJobQueueSeq(){
		dmm.reCreateJobQueueSeq()
	}
	
	def saveSystemConfig(){
		def queue = SingletonMapQueue.getInstance()
		def sql = "select property_name, property_value from system_config"
		for(rec in sqlExecutor.getSqlResult(sql)){
			queue.enqueue(rec.get("property_name"), rec.get("property_value"))
		}
	}
	
	def restoreSystemConfig(){
		def queue = SingletonMapQueue.getInstance()
		def keyList = new ArrayList(queue.keySet())
		for(key in keyList){
			updateSystemConfig(key, queue.dequeue(key))
		}
	}
}
