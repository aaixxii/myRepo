package test.common.util.db


import test.common.util.db.*
import common.util.*
import org.springframework.jdbc.core.PreparedStatementCreator
import static test.common.constants.aim.AIMWord.*
import static test.common.constants.aim.AIMXmlAttribute.*

class HighLevelServiceLayoutsDao {

	def jdbcTemplate
	private static final String CHANGE_STR = "UTF-8\" standalone=\"yes"


	HighLevelServiceLayoutsDao(context){
		this.jdbcTemplate = new JdbcTemplateFactory(context).create()
	}

	public void setupTIRolled(def fw){
		changeFw(TI, PC2_ROLLED, fw)
	}

	public void setupTISlap(def fw){
		changeFw(TI, PC2_SLAP, fw)
	}

	public void setupLI(def fw){
		changeFw(LI, FMP5_LATENT, fw)
	}

	public void setupLIS(def fw){
		changeFw(LI, PC2_LATENT, fw)
	}

	public void setupLLI(def fw){
		changeFw(LLI, FMP5_LATENT, fw)
	}

	public void setupLLIS(def fw){
		changeFw(LLI, PC2_LATENT, fw)
	}

	public void setupTLIRolled(def fw){
		changeFw(TLI, FMP5_ROLLED, fw)
	}

	public void setupTLISlap(def fw){
		changeFw(TLI, FMP5_SLAP, fw)
	}

	public void setupTLISRolled(def fw){
		changeFw(TLI, PC2_ROLLED, fw)
	}

	public void setupTLISSlap(def fw){
		changeFw(TLI, PC2_SLAP, fw)
	}

	public void setupTIMRolled(def fw){
		changeFw(TIM, PC2_ROLLED, fw)
	}

	public void setupTIMSlap(def fw){
		changeFw(TIM, PC2_SLAP, fw)
	}

	public void setupLIM(def fw){
		changeFw(LIM, PC2_LATENT, fw)
	}

	public void setupTLIMRolled(def fw){
		changeFw(TLIM, PC2_ROLLED, fw)
	}

	public void setupTLIMSlap(def fw){
		changeFw(TLIM, PC2_SLAP, fw)
	}

	public void setupLLIM(def fw){
		changeFw(LLIM, PC2_LATENT, fw)
	}

	public void setupLIXPc2Rolled(def fw){
		changeFw(LIX, PC2_ROLLED, fw)
	}

	public void setupLIXPc2Slap(def fw){
		changeFw(LIX, PC2_SLAP, fw)
	}

	public void setupLIXFmp5Rolled(def fw){
		changeFw(LIX, FMP5_ROLLED, fw)
	}

	public void setupLIXFmp5Slap(def fw){
		changeFw(LIX, FMP5_SLAP, fw)
	}

	public void setupTLIXPc2Rolled(def fw){
		changeFw(TLIX, PC2_ROLLED, fw)
	}

	public void setupTLIXPc2Slap(def fw){
		changeFw(TLIX, PC2_SLAP, fw)
	}

	public void setupTLIXFmp5Rolled(def fw){
		changeFw(TLIX, FMP5_ROLLED, fw)
	}

	public void setupTLIXFmp5Slap(def fw){
		changeFw(TLIX, FMP5_SLAP, fw)
	}

	public void setupLLIXPc2(def fw){
		changeFw(LLIX, PC2_LATENT, fw)
	}

	public void setupLLIXFmp5(def fw){
		changeFw(LLIX, FMP5_LATENT, fw)
	}

	public void changeFw(String func, String inqSet, def fw){
		String  scriptXml = getScriptXml(func)
		Node resXml = new XmlParser().parseText(scriptXml)
		resXml."script-item"."fusionWeight".find{it.@inquirySet == inqSet }.setValue(fw)
		String changeVal = convertNodeToString(resXml)
		updateFw(func, changeVal)
	}

	public removeFusionWeight(String func, String inqSet){
		String scriptXml = getScriptXml(func)
		Node resXml = new XmlParser().parseText(scriptXml)
		if (resXml."script-item"."fusionWeight".find{it.@inquirySet == inqSet } != null){
			resXml."script-item"."fusionWeight".find{it.@inquirySet == inqSet }.replaceNode {}
		}
		String changeVal = convertNodeToString(resXml)
		updateFw(func, changeVal)
	}

	public String getScriptXml(String func){
		String sql = "select SCRIPT_XML as xml from HIGH_LEVEL_SERVICE_LAYOUTS where NAME = '${func}'"
		Map resMap =   jdbcTemplate.queryForList(sql)[0]
		return resMap.get("xml").toString()
	}

	public String convertNodeToString(Node xml){
		StringWriter writer = new StringWriter()
        String emptyString = ""
        boolean addLines = false
        new XmlNodePrinter(new IndentPrinter(new PrintWriter(writer), emptyString, addLines)).print(xml)
        String result = writer.toString()
		result =  XmlPrinter.printer(result)
		return result.replaceFirst("UTF-8", CHANGE_STR)
	}

	public void updateFw(String func ,String scriptXml){
		String update = "UPDATE HIGH_LEVEL_SERVICE_LAYOUTS SET script_xml = '${scriptXml}' where name = '${func}'"
		jdbcTemplate.update(update)
	}
}
