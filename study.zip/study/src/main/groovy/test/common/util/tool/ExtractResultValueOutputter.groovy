package test.common.util.tool

import test.degrade.evidence.EvidenceFileOutputor

class ExtractResultValueOutputter {

	private static final String WSQ_EXTENT = ".wsq"

	EvidenceFileOutputor outputor

	ExtractResultValueOutputter(context){
		this.outputor = new EvidenceFileOutputor(context)
	}

	def outputReturnCropImage(def filePath){
		Node root =  new XmlParser().parse(new File(filePath))
		for (def fo in root."extraction-outputs-payload"."tenprint-output"."finger-output"){
			String pos = fo.@pos + WSQ_EXTENT
			String croppedImage = fo."cropped-image".text()
			outputor.outputResultDataAsBinary(pos + WSQ_EXTENT, croppedImage)
		}
	}

}
