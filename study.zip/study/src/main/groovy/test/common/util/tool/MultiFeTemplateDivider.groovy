package test.common.util.tool

import common.util.Encoder
import java.nio.ByteBuffer

class MultiFeTemplateDivider {

    public static List divideXTmpl(String b64MultiTmpl){
        List templateList = []
        byte[] multiTmpl = Encoder.stringToBinary(b64MultiTmpl)
        long tType = getByteBuffer(multiTmpl, 1, 8).getLong()
        short not = getByteBuffer(multiTmpl, 9, 10).getShort()

        int index = 11
        for(i in 1..not){
            def feTypePc2R = getByteBuffer(multiTmpl, index, index+3)
            index += 4
            def feTypePc2S = getByteBuffer(multiTmpl, index, index+3)
            index += 4
            def feTypeFmp5R = getByteBuffer(multiTmpl, index, index+3)
            index += 4
            def feTypeFmp5S = getByteBuffer(multiTmpl, index, index+3)
            index += 4
            int offset = getByteBuffer(multiTmpl, index, index+3).getInt() + 1
            index += 4
            int lom = getByteBuffer(multiTmpl, offset, offset+3).getInt()
            templateList << Encoder.binaryToB64(getBytes(multiTmpl, offset, offset+lom-1))
        }

        return templateList
    }

    private static byte[] getBytes(byte[] input, int start, int end){
        byte[] output = new byte[end - start + 1]
        int k = 0
        for(i in (start-1)..(end-1)){
            output[k] = input[i]
            k++
        }
        return output
    }

    private static ByteBuffer getByteBuffer(byte[] input, int start, int end){
        return ByteBuffer.wrap(getBytes(input, start, end))
    }
}


		
