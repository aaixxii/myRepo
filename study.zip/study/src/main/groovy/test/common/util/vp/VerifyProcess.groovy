package test.common.util.vp

import common.os.linux.*
import test.degrade.properties.*
import common.util.*
import static test.common.constants.aim.AIMWord.*

class VerifyProcess{
	LinuxCommander linuxCommander
	GlobalProperties globalProperties
	String vpIp
	String vpUser
	String vpPass
	String vpHome
	String vpParamXmlPath
	String sshShell
	String scpShell
	String defaultParam
	String updateParam
	private static final String DOT_1ST = ".1st"
	private static final String DOT_2ND = ".2nd"

	private static final String PARAM_START = "<parameter%s>"
	private static final String PARAM_END = "<\\\\/parameter%s>"

	private static final String CSCORE_START = "<composite-score>"
	private static final String CSCORE_END = "<\\\\/composite-score>"
	private static final String FINGER = "<finger>%s<\\\\/finger>"

	private static final String FINGER_START = "<finger>"
	private static final String FINGER_END = "<\\\\/finger>"
	private static final String FACE_START = "<face>"
	private static final String FACE_END = "<\\\\/face>"
	private static final String FASD_START = "<fasd>"
	private static final String FASD_END = "<\\\\/fasd>"
	private static final String IRIS_START = "<iris>"
	private static final String IRIS_END = "<\\\\/iris>"
	private static final String NIRIS_START = "<NIRIS>"
	private static final String NIRIS_END = "<\\\\/NIRIS>"
	private static final String VERIEYE_START = "<VeriEye>"
	private static final String VERIEYE_END = "<\\\\/VeriEye>"
	private static final String ROLLED_START = "<rolled>"
	private static final String ROLLED_END = "<\\\\/rolled>"
	private static final String SLAP_START = "<slap>"
	private static final String SLAP_END = "<\\\\/slap>"
	private static final String PARAMETER_FILE_START = "<parameter-file>"
	private static final String PARAMETER_FILE_END = "<\\\\/parameter-file>"

	private static final String ENGINE = "<engine>%s<\\\\/engine>"
	private static final String OUTPUT_PARAMETER = '<output-parameter enable=\\"%s\\"\\\\/>'
	private static final String SEND_WARNING_MESSAGES = '<send-warning-messages enable=\\"%s\\"\\\\/>'
	private static final String IMAGE_ENHANCE_ENABLE = '<image-enhance enable=\\"%s\\">'
	private static final String ALGORITHM = "<algorithm>%s<\\\\/algorithm>"
	private static final String EXT_ALGORITHM = "<extract-algorithm>%s<\\\\/extract-algorithm>"
	private static final String EXTRACT_TIMEOUT_ELEMENT = "<extract>%s<\\\\/extract>"
	private static final String DEINTERLACE = "<deinterlace>%s<\\\\/deinterlace>"
	private static final String FLEXIBLE_BOUNDARY_MODEL = "<flexible-boundary-model>%s<\\\\/flexible-boundary-model>"
	private static final String MIN_PUPIL_RADIUS = "<min-pupil-radius>%s<\\\\/min-pupil-radius>"
	private static final String MAX_PUPIL_RADIUS = "<max-pupil-radius>%s<\\\\/max-pupil-radius>"
	private static final String MIN_IRIS_RADIUS  = "<min-iris-radius>%s<\\\\/min-iris-radius>"
	private static final String MAX_IRIS_RADIUS  = "<max-iris-radius>%s<\\\\/min-iris-radius>"
	private static final String MODE = "<mode>%s<\\\\/mode>"
	private static final String TOLERANCE = "<tolerance>%s<\\\\/tolerance>"
	private static final String EXTRACT_MODE = "<extract-mode>%s<\\\\/extract-mode>"
	private static final String ENROLL = "<enroll>%s<\\\\/enroll>"
	private static final String FINALIZE = "<finalize>%s<\\\\/finalize>"
	private static final String IDENTIFY = "<identify>%s<\\\\/identify>"
	private static final String FIRST_MATCH = "<first-match>%s<\\\\/first-match>"
	private static final String SECOND_MATCH = "<second-match>%s<\\\\/second-match>"

	private static final String WILD = ".*"
	private static final String ELEMENT_START = "<%s>"
	private static final String ELEMENT_END = "<\\\\/%s>"

	private static final String PARAMETER_XML = "./parameter.xml"
	private static final String PARAMETER_XML_UPDATE = "./parameter.xml.update"
	private static final int SLEEP_TIME = 20000


	VerifyProcess(context){
		this.linuxCommander = new LinuxCommander()
		this.globalProperties = new GlobalProperties(context)
		this.vpIp = globalProperties.getVpIp()
		this.vpUser = globalProperties.getVpUser()
		this.vpPass = globalProperties.getVpPass()
		this.vpHome = globalProperties.getVpHome()
		this.vpParamXmlPath = "${vpUser}@${vpIp}:${vpHome}/config/parameter.xml"
		this.defaultParam = getDefaultParam()
		this.updateParam = globalProperties.getDataFilePath() + "/degradeTest_VX/param/parameter.xml.update"
		String shellDir = globalProperties.getSubtoolDir()
		this.sshShell = "${shellDir}/common_tools/exec_ssh_cmd_automatically_input_pass.sh"
		this.scpShell = "${shellDir}/common_tools/exec_scp_cmd_automatically_input_pass.sh"
	}

	def getDefaultParam(){
		String vpVersion = globalProperties.getVpVersion()
		return globalProperties.getDataFilePath() + "/degradeTest_VX/param/" + vpVersion + "/parameter.xml"
	}


	def executeVpShell(String command){
                List args = [ vpUser, vpIp, command, vpPass ]
                return new LinuxCommander().doShWithArgs(sshShell, args)
	}

	def String getVpHome(){
		return vpHome
	}

	def getParamXmlByScp(String toPath){
		String shellDir = globalProperties.getSubtoolDir()
		this.vpParamXmlPath = "root@${vpIp}:${vpHome}/config/parameter.xml"
		this.scpShell = "${shellDir}/common_tools/exec_scp_cmd_automatically_without_pass.sh"
		List args = [ vpParamXmlPath, toPath, vpPass ]
		linuxCommander.doShWithArgs(scpShell, args)
	}

	def sendParamXmlByScp(String fromPath){
		List args = [ fromPath, vpParamXmlPath, vpPass ]
		linuxCommander.doShWithArgs(scpShell, args)
	}
	
	def sendDefaultParam(){
		sendParamXmlByScp(defaultParam)
		setAlgorithmCondition(false)
		setReportValue("true")
	}

	def sendUpdateParam(){
		sendParamXmlByScp(updateParam)
	}
	
	def sendUpdateParam(def updateParam){
		sendParamXmlByScp(updateParam)
	}
	
	def vpAgentStart(){
		String vpAgentStopCmd = "./runVP.sh"
		List args = [ vpUser, vpIp, vpAgentStopCmd, vpPass ]
		linuxCommander.doShWithArgs(sshShell, args)
	}
	
	def vpAgentStart(int sleepTime){
		String vpAgentStopCmd = "./runVP.sh"
		List args = [ vpUser, vpIp, vpAgentStopCmd, vpPass ]
		linuxCommander.doShWithArgs(sshShell, args)
		sleep sleepTime
	}

	def vpAgentStop(){
		String vpAgentStopCmd = "./stopVP.sh"
		List args = [ vpUser, vpIp, vpAgentStopCmd, vpPass ]
		linuxCommander.doShWithArgs(sshShell, args)
	}

	def reboot(){
		vpAgentStop()
		vpAgentStart()
	}

	def reboot(int sleepTime){
		vpAgentStop()
		vpAgentStart(sleepTime)
	}

	def switchFaceLibS14(){
		setFaceAlgorithm("S14")
	}

	def switchFaceLibS17(){
		setFaceAlgorithm("S17")
	}

	def changeFingerAlgorithmCML(){
		setFingerAlgorithm(CML)
	}

	def changeFingerExtAlgorithmCML(){
		setFingerExtAlgorithm(CML)
	}

	def changeFingerAlgorithmSATOM(){
		setFingerAlgorithm(SATOM)
	}

	def changeFingerExtAlgorithmCMLAF(){
		setFingerExtAlgorithm(CMLAF)
	}

	def changeFingerExtAlgorithmFis(){
		setFingerExtAlgorithm(FIS)
	}

	def changeFingerExtAlgorithmCml(){
		setFingerExtAlgorithm(CML)
	}

	def changeIrisAlgorithmNiris(){
		setIrisAlgorithm(NIRIS)
	}

	def changeIrisAlgorithmVerieye(){
		setIrisAlgorithm(VERIEYE)
	}

	def backupParameter(){
        String vpBkParamcmd  = "cp -fp $vpHome/config/parameter.xml $vpHome/config/parameter.xml.tmp"
        List args = [ vpUser, vpIp, vpBkParamcmd , vpPass ,vpHome]
		linuxCommander.doShWithArgs(sshShell, args)
	}

	def restoreParameter(){
        String vpRestParamcmd  = "mv -f $vpHome/config/parameter.xml.tmp $vpHome/config/parameter.xml"
        List args = [ vpUser, vpIp, vpRestParamcmd , vpPass ,vpHome]
		linuxCommander.doShWithArgs(sshShell, args)
		vpAgentStop()
		vpAgentStart()
	}

	def ddToCreateLogFileOfAnySize(file, blockSize, cnt) {
		String cmd = "dd if=/dev/zero of=${vpHome}/log/${file} bs=${blockSize} count=${cnt}"
		List args = [vpUser, vpIp, cmd, vpPass ]
		linuxCommander.doShWithArgs(sshShell, args)
	}
	
	def getLogFileNum(fileName) {
		List resultList =  executeVpShell("ls -1 ${vpHome}/log/${fileName}* | wc -l")
                return resultList.get(resultList.size()-1) as int
	}
	
	def deleteVpLogs() {
                String cmd = "cd ${vpHome}/log; rm -f *"
                executeVpShell(cmd)
	}
	
	def killAllWorkers() {
		String cmd = "killall VPWorker"
		executeVpShell(cmd)
	}
	
	def getWorkersNum() {
		List resultList = executeVpShell("ps -efa |grep VPWorker |grep -v grep |wc -l")
		return resultList.get(resultList.size()-1) as int
	}

	private Node parseDefaultParam(){
		File vpParameterXml = new File(defaultParam)
		return new XmlParser().parse(vpParameterXml)
	}

	public Node parseCurrentParam(){
		getParamXmlByScp(PARAMETER_XML)
		File vpParameterXml = new File(PARAMETER_XML)
		return new XmlParser().parse(vpParameterXml)
	}

	private void outputUpdateParam(Node xml){
		StringWriter writer = new StringWriter()
		String emptyString = ""
		boolean addLines = false
		new XmlNodePrinter(new IndentPrinter(new PrintWriter(writer), emptyString, addLines)).print(xml)
		String result = writer.toString() + "\n"
		result =  XmlPrinter.printer(result)
		File updateVpParameterXml = new File(updateParam)
		updateVpParameterXml.write(result)
	}
	
	private void outputUpdateParam(Node xml, String fileName){
		StringWriter writer = new StringWriter()
		String emptyString = ""
		boolean addLines = false
		new XmlNodePrinter(new IndentPrinter(new PrintWriter(writer), emptyString, addLines)).print(xml)
		String result = writer.toString() + "\n"
		result =  XmlPrinter.printer(result)
		File updateVpParameterXml = new File(fileName)
		updateVpParameterXml.write(result)
	}
	
	public void setFaceAlgorithm(String algorithm){
		String start = FACE_START
		String end 	 = FASD_START
		String before = String.format(ALGORITHM, WILD)
		String after = String.format(ALGORITHM, algorithm)
		String cmd = "sed -i -e '/${start}/,/${end}/s/${before}/${after}/' ${vpHome}/config/parameter.xml" 
		doLinuxShellCommand(cmd)
	}

	public void setFingerAlgorithm(String algorithm){
		String start = FINGER_START
		String end 	 = FINGER_END
		String before = String.format(ALGORITHM, WILD)
		String after = String.format(ALGORITHM, algorithm)
		String cmd = "sed -i -e '/${start}/,/${end}/s/${before}/${after}/' ${vpHome}/config/parameter.xml" 
		doLinuxShellCommand(cmd)
	}

	public void setFingerExtAlgorithm(String algorithm){
		String start = FINGER_START
		String end 	 = FINGER_END
		String before = String.format(EXT_ALGORITHM, WILD)
		String after = String.format(EXT_ALGORITHM, algorithm)
		String cmd = "sed -i -e '/${start}/,/${end}/s/${before}/${after}/' ${vpHome}/config/parameter.xml" 
		doLinuxShellCommand(cmd)
	}

	public void setImageEnhanceEnable(String value){
		String before = String.format(IMAGE_ENHANCE_ENABLE, WILD)
		String after = String.format(IMAGE_ENHANCE_ENABLE, value)
		String cmd = "sed -i -e 's/${before}/${after}/' ${vpHome}/config/parameter.xml" 
		doLinuxShellCommand(cmd)
	}

	public void setOutputParameterEnable(String value){
		String before = String.format(OUTPUT_PARAMETER, WILD)
		String after = String.format(OUTPUT_PARAMETER, value)
		String cmd = "sed -i -e 's/${before}/${after}/' ${vpHome}/config/parameter.xml" 
		doLinuxShellCommand(cmd)
	}

	public void setSendWarningMessages(String value){
		String before = String.format(SEND_WARNING_MESSAGES, WILD)
		String after = String.format(SEND_WARNING_MESSAGES, value)
		String cmd = "sed -i -e 's/${before}/${after}/' ${vpHome}/config/parameter.xml" 
		doLinuxShellCommand(cmd)
	}

	public void setIrisAlgorithm(String algorithm){
		String start = IRIS_START
		String end 	 = IRIS_END
		String before = String.format(ALGORITHM, WILD)
		String after = String.format(ALGORITHM, algorithm)
		String cmd = "sed -i -e '/${start}/,/${end}/s/${before}/${after}/' ${vpHome}/config/parameter.xml"
		doLinuxShellCommand(cmd)
	}

	public void setVerieyeDeinterlace(String value){
		String start = VERIEYE_START
		String end 	 = VERIEYE_END
		String before = String.format(DEINTERLACE, WILD)
		String after = String.format(DEINTERLACE, value)
		String cmd = "sed -i -e '/${start}/,/${end}/s/${before}/${after}/' ${vpHome}/config/parameter.xml"
		doLinuxShellCommand(cmd)
	}

	public void setVerieyeFlexibleBoundaryModel(String value){
		String start = VERIEYE_START
		String end 	 = VERIEYE_END
		String before = String.format(FLEXIBLE_BOUNDARY_MODEL, WILD)
		String after = String.format(FLEXIBLE_BOUNDARY_MODEL, value)
		String cmd = "sed -i -e '/${start}/,/${end}/s/${before}/${after}/' ${vpHome}/config/parameter.xml"
		doLinuxShellCommand(cmd)
	}

	public void setVerieyeMinPupilRadius(String value){
		String start = VERIEYE_START
		String end 	 = VERIEYE_END
		String before = String.format(MIN_PUPIL_RADIUS, WILD)
		String after = String.format(MIN_PUPIL_RADIUS, value)
		String cmd = "sed -i -e '/${start}/,/${end}/s/${before}/${after}/' ${vpHome}/config/parameter.xml"
		doLinuxShellCommand(cmd)
	}

	public void setVerieyeMaxPupilRadius(String value){
		String start = VERIEYE_START
		String end 	 = VERIEYE_END
		String before = String.format(MAX_PUPIL_RADIUS, WILD)
		String after = String.format(MAX_PUPIL_RADIUS, value)
		String cmd = "sed -i -e '/${start}/,/${end}/s/${before}/${after}/' ${vpHome}/config/parameter.xml"
		doLinuxShellCommand(cmd)
	}

	public void setVerieyeMinIrisRadius(String value){
		String start = VERIEYE_START
		String end 	 = VERIEYE_END
		String before = String.format(MIN_IRIS_RADIUS, WILD)
		String after = String.format(MIN_IRIS_RADIUS, value)
		String cmd = "sed -i -e '/${start}/,/${end}/s/${before}/${after}/' ${vpHome}/config/parameter.xml"
		doLinuxShellCommand(cmd)
	}

	public void setVerieyeMaxIrisRadius(String value){
		String start = VERIEYE_START
		String end 	 = VERIEYE_END
		String before = String.format(MAX_IRIS_RADIUS, WILD)
		String after = String.format(MAX_IRIS_RADIUS, value)
		String cmd = "sed -i -e '/${start}/,/${end}/s/${before}/${after}/' ${vpHome}/config/parameter.xml"
		doLinuxShellCommand(cmd)
	}

	public void setVerieyeMatchMode(String value){
		String start = VERIEYE_START
		String end 	 = VERIEYE_END
		String before = String.format(MODE, WILD)
		String after = String.format(MODE, value)
		String cmd = "sed -i -e '/${start}/,/${end}/s/${before}/${after}/' ${vpHome}/config/parameter.xml"
		doLinuxShellCommand(cmd)
	}

	public void setVerieyeMatchTolerance(String value){
		String start = VERIEYE_START
		String end 	 = VERIEYE_END
		String before = String.format(TOLERANCE, WILD)
		String after = String.format(TOLERANCE, value)
		String cmd = "sed -i -e '/${start}/,/${end}/s/${before}/${after}/' ${vpHome}/config/parameter.xml"
		doLinuxShellCommand(cmd)
	}

	public void setNirisExtractMode(String value){
		String start = NIRIS_START
		String end 	 = NIRIS_END
		String before = String.format(EXTRACT_MODE, WILD)
		String after = String.format(EXTRACT_MODE, value)
		String cmd = "sed -i -e '/${start}/,/${end}/s/${before}/${after}/' ${vpHome}/config/parameter.xml"
		doLinuxShellCommand(cmd)
	}

	public void setNirisMatchMode(String value){
		String start = NIRIS_START
		String end 	 = NIRIS_END
		String before = String.format(MODE, WILD)
		String after = String.format(MODE, value)
		String cmd = "sed -i -e '/${start}/,/${end}/s/${before}/${after}/' ${vpHome}/config/parameter.xml"
		doLinuxShellCommand(cmd)
	}

	public void setNirisMatchTolerance(String value){
		String start = NIRIS_START
		String end 	 = NIRIS_END
		String before = String.format(TOLERANCE, WILD)
		String after = String.format(TOLERANCE, value)
		String cmd = "sed -i -e '/${start}/,/${end}/s/${before}/${after}/' ${vpHome}/config/parameter.xml"
		doLinuxShellCommand(cmd)
	}

	public void setCMLExtractRolledEnroll(String value){
		String start = ROLLED_START
		String end 	 = ROLLED_END
		String before = String.format(ENROLL, WILD)
		String after = String.format(ENROLL, value)
		String cmd = "sed -i -e '/${start}/,/${end}/s/${before}/${after}/' ${vpHome}/config/parameter.xml"
		doLinuxShellCommand(cmd)
	}

	public void setCMLExtractRolledFinalize(String value){
		String start = ROLLED_START
		String end 	 = ROLLED_END
		String before = String.format(FINALIZE, WILD)
		String after = String.format(FINALIZE, value)
		String cmd = "sed -i -e '/${start}/,/${end}/s/${before}/${after}/' ${vpHome}/config/parameter.xml"
		doLinuxShellCommand(cmd)
	}

	public void setCMLExtractSlapEnroll(String value){
		String start = SLAP_START
		String end 	 = SLAP_END
		String before = String.format(ENROLL, WILD)
		String after = String.format(ENROLL, value)
		String cmd = "sed -i -e '/${start}/,/${end}/s/${before}/${after}/' ${vpHome}/config/parameter.xml"
		doLinuxShellCommand(cmd)
	}

	public void setCMLExtractSlapFinalize(String value){
		String start = SLAP_START
		String end 	 = SLAP_END
		String before = String.format(FINALIZE, WILD)
		String after = String.format(FINALIZE, value)
		String cmd = "sed -i -e '/${start}/,/${end}/s/${before}/${after}/' ${vpHome}/config/parameter.xml"
		doLinuxShellCommand(cmd)
	}

	public void setCMLMatchIdentify(String value){
		String start = PARAMETER_FILE_START
		String end 	 = PARAMETER_FILE_END
		String before = String.format(IDENTIFY, WILD)
		String after = String.format(IDENTIFY, value)
		String cmd = "sed -i -e '/${start}/,/${end}/s/${before}/${after}/' ${vpHome}/config/parameter.xml"
		doLinuxShellCommand(cmd)
	}

	public void setCMLMatchFirstMatch(String value){
		String start = PARAMETER_FILE_START
		String end 	 = PARAMETER_FILE_END
		String before = String.format(FIRST_MATCH, WILD)
		String after = String.format(FIRST_MATCH, value)
		String cmd = "sed -i -e '/${start}/,/${end}/s/${before}/${after}/' ${vpHome}/config/parameter.xml"
		doLinuxShellCommand(cmd)
	}

	public void setCMLMatchSecondMatch(String value){
		String start = PARAMETER_FILE_START
		String end 	 = PARAMETER_FILE_END
		String before = String.format(SECOND_MATCH, WILD)
		String after = String.format(SECOND_MATCH, value)
		String cmd = "sed -i -e '/${start}/,/${end}/s/${before}/${after}/' ${vpHome}/config/parameter.xml"
		doLinuxShellCommand(cmd)
	}

	public void updateImageEnhanceEnable(String value){
		setImageEnhanceEnable(value)
	}
	
	private void setImageEnhance(String enh){
		Node root= parseCurrentParam()
		Node enhance = root.verification.finger."feature-extract".Fis."image-enhance".find{it.@enable == 'true' }
		enhance.children().clear()
		for( i in 1..10){
			if(i == 1) {
				enhance.appendNode("enhance-type${i}", enh)
			} else {
				enhance.appendNode("enhance-type${i}", "9")
			}
		}
		outputUpdateParam(root, PARAMETER_XML_UPDATE)
	}
	
	private void setImageEnhance(ArrayList enhList){
		Node root= parseCurrentParam()
		Node enhance = root.verification.finger."feature-extract".Fis."image-enhance".find{it.@enable == 'true' }
		enhance.children().clear()
		int listSize = enhList.size()
		for( i in 1..listSize){
			enhance.appendNode("enhance-type${i}", enhList[i-1])
		}
		outputUpdateParam(root, PARAMETER_XML_UPDATE)
	}

	private void setFasdParameter(Map paramMap){
		String cmd = ""
		def element
		def paramNum

		for(param in paramMap){
			def key = param.getKey()
			if(key.contains(DOT_1ST)){
				element =  key.replaceAll(/$DOT_1ST/,"")
				paramNum = "1"
			}else if(key.contains(DOT_2ND)){
				element =  key.replaceAll(/$DOT_2ND/,"")
				paramNum = "2"
			}
			String start = String.format(PARAM_START, paramNum)
		  	String end = String.format(PARAM_END, paramNum)
			String elementStart = String.format(ELEMENT_START, element)
			String elementEnd = String.format(ELEMENT_END, element)
			String before = elementStart + WILD + elementEnd
			String after = elementStart + param.getValue() + elementEnd
			cmd += "sed -i -e '/${start}/,/${end}/s/${before}/${after}/' ${vpHome}/config/parameter.xml;"
		}
		doLinuxShellCommand(cmd)
	}
	
	private void setCheckWorkersState(String value){
		Node root= parseCurrentParam()
		Node interval = root.controller.interval[0]
		interval.children().clear()
		interval.appendNode("check-workers-state",value)
		outputUpdateParam(root, PARAMETER_XML_UPDATE)
	}
	
	private void setSatom(String attribute, String value){
		Node root= parseCurrentParam()
		root.verification.finger.match.SATOM.@"${attribute}" = value
		outputUpdateParam(root, PARAMETER_XML_UPDATE)
	}

	public void updateImageEnhance(String enh){
		setImageEnhance(enh)
		sendUpdateParam(PARAMETER_XML_UPDATE)
	}
	
	public void updateImageEnhance(ArrayList enhList){
		setImageEnhance(enhList)
		sendUpdateParam(PARAMETER_XML_UPDATE)
	}
	
	public void updateOutputParameterEnable(String value){
		setOutputParameterEnable(value)
	}
	
	public void updateFasdParameter(Map paramMap){
		setFasdParameter(paramMap)
	}
	
	public void updateCheckWorkersState(String value){
		setCheckWorkersState(value)
		sendUpdateParam(PARAMETER_XML_UPDATE)
	}
	
	public void updateSatom(String attribute, String value){
		setSatom(attribute, value)
		sendUpdateParam(PARAMETER_XML_UPDATE)
	}
	
	public void updateSatomSpeedLevel(String value){
		updateSatom("speedLevel", value)
	}
	
	public void updateSatomRotationLimit(String value){
		updateSatom("rotationLimit", value)
	}
	
	public void updateSatomDistortionLevel(String value){
		updateSatom("distortionLevel", value)
	}

	public getFingerExtractAlgorithm(){
		Node root= parseCurrentParam()
		return root.verification.finger."feature-extract"."extract-algorithm".text()
	}

	public getFaceAlgorithm(){
		Node root= parseCurrentParam()
		return root.verification.face.algorithm.text()
	}

	public getSendWarningMessages(){
		Node root= parseCurrentParam()
		return root.report."send-warning-messages".@enable[0]
	}

	public getOutputParameter(){
		Node root= parseCurrentParam()
		return root.report."output-parameter".@enable[0]
	}

	public getVerieyeDeinterlace(){
		Node root= parseCurrentParam()
		return root.verification.iris.VeriEye.extract.deinterlace.text()
	}

	public void doLinuxShellCommand(def cmd){
		List args = [vpUser, vpIp, cmd, vpPass ]
		linuxCommander.doShWithArgs(sshShell, args)
	}

    public void setAlgorithmCondition(boolean needReboot){
        String currentTimEngine = globalProperties.getTimEngine().toUpperCase()
        String currentIrisEngine = globalProperties.getIrisEngine().toUpperCase()
        if(currentTimEngine == CML){
            changeFingerExtAlgorithmCML()
        }else if(currentTimEngine == CMLAF){
            changeFingerExtAlgorithmCMLAF()
        }
        setIrisAlgorithm(currentIrisEngine)
        if(needReboot){
            reboot(SLEEP_TIME)
        }
    }

    public void setReportValue(def value){
		if (value != getOutputParameter() || value != getSendWarningMessages()){
        	setOutputParameterEnable(value)
			setSendWarningMessages(value)
			reboot(SLEEP_TIME)
        }
    }

    public void setFingerExtAlgorithmCondition(String algorithm){
		if(!algorithm.equals(getFingerExtractAlgorithm())){
			setFingerExtAlgorithm(algorithm)
            		reboot(SLEEP_TIME)
		}
    }
}
