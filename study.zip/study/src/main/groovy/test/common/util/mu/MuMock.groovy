package test.common.util.mu

class MuMock {
	String serviceEndpoint
	String ip
	int port
	String id
	
	def MuMock(String serviceEndpoint, String ip, int port){
		this.serviceEndpoint = serviceEndpoint
		this.ip = ip
		this.port = port
	}

	public enter(){
		def url = new URL("${serviceEndpoint}/matchmanager/Enter")
		def postData = """
            <aim:enter-request xmlns:aim="urn:nec:aim">
                <uniqueId>${ip}:${port}</uniqueId>
                <contactURL>http://${ip}:${port}/</contactURL>
                <version>4.2.0</version>
                <segment-report/>
                <resource-report>
                    <cots-resource-report>
                        <numCPUs>128</numCPUs>
                        <ramSpace>107374182400</ramSpace>
                        <diskSpace>1099511627776</diskSpace>
                        <performanceFactor>255</performanceFactor>
                    </cots-resource-report>
                </resource-report>
            </aim:enter-request>
            """
		def enterCallback = new XmlParser().parseText(doPost(url,postData))
		this.id = enterCallback.muid.text()
    }

	public exit(){
		def url = new URL("${serviceEndpoint}/matchmanager/Exit")
		def postData = """
			<aim:exit-request xmlns:aim="urn:nec:aim">
				<muid>${id}</muid>
			</aim:exit-request>
			"""
        doPost(url,postData)
    }

	private doPost(def url,def postData){
		def con = url.openConnection()
		con.doOutput = true
		con.requestMethod = "POST"
		con.outputStream.withWriter {
			it.print postData
		}
		con.inputStream.text
    }
}
