package test.common.util.db

import oracle.jdbc.pool.OracleDataSource
import org.springframework.jdbc.core.JdbcTemplate

import test.degrade.properties.*

class JdbcTemplateFactory {
	private static final String THIN = "thin"
	private static final String TCP = "tcp"
	def globalProperties

	JdbcTemplateFactory(context){
		this.globalProperties = new GlobalProperties(context)
	}

	def create(){
		def ip = globalProperties.getDBIP()
		def port = globalProperties.getDBPort() as int
		def sid = globalProperties.getDBSID()
		def user = globalProperties.getDBUser()
		def pass = globalProperties.getDBPass()
		def ods = new OracleDataSource()
		ods.setDriverType(THIN)
		ods.setNetworkProtocol(TCP)
		ods.setServerName(ip)
		ods.setDatabaseName(sid)
		ods.setPortNumber(port)
		ods.setUser(user)
		ods.setPassword(pass)
		return new JdbcTemplate(ods)
	}
}
