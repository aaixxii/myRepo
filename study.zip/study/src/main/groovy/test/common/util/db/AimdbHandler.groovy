package test.common.util.db

import common.sql.*

class AimdbHandler{

	SqlExecutor sqlExecutor
	def jdbcTemplate
	static final String MAX_SEG_ID = "select max(segment_id) as maxSegId from segments"
	static final String MAX_BIO_ID_END = "select max(bio_id_end) as maxBioIdEnd from segments"
	static final String MAX_JOB_ID = "select max(job_id) as maxJobId from job_queue"
	static final String JOB_ID_IN_JOB_QUEUE = "select job_id from job_queue"
	static final String JOB_ID_IN_FS_JOBS = "select job_id from fusion_jobs"
	static final String FS_JOB_ID_IN_SSJ = "select fusion_job_id from segment_set_jobs"
	static final String SSJ_ID_IN_MU_JOBS = "select segment_set_job_id from mu_jobs"
	private static final String CHANGE_STR = "UTF-8\" standalone=\"yes"
	private static final String INSERT_PB_SQL = "insert into person_biometrics values (?, ?, ?, ?, ?, ?, ?, ?)"


	AimdbHandler(context){
		this.sqlExecutor = new SqlExecutorFactory(context).create()
		this.jdbcTemplate = new JdbcTemplateFactory(context).create()
	}

	def getMaxSegId(){
		return sqlExecutor.getSqlResult(MAX_SEG_ID).maxSegId[0]
	}
	
	def getSegSetId(binId){
		String SEG_SET_ID = "select segment_set_id  from segment_sets where bin_id = ${binId}"
		return sqlExecutor.getSqlResult(SEG_SET_ID).segment_set_id[0]
	}
	
	def getMaxBioIdEnd(){
		return sqlExecutor.getSqlResult(MAX_BIO_ID_END).maxBioIdEnd[0]
	}
	
	def getMaxJobId(){
		return sqlExecutor.getSqlResult(MAX_JOB_ID).maxJobId[0]
	}

	def getJobIdExistMuJobs(){
		String sql = """
					${JOB_ID_IN_JOB_QUEUE} where job_id in (
						${JOB_ID_IN_FS_JOBS} where fusion_job_id in (
							${FS_JOB_ID_IN_SSJ} where segment_set_job_id in (
								${SSJ_ID_IN_MU_JOBS}
							)
						)
					)
					order by 1"""
		return sqlExecutor.getSqlResult(sql).job_id
	}
	
	def getJobIdExistMuJobsAndNonStateIsDone(){
		String sql = """
					${JOB_ID_IN_JOB_QUEUE} where job_id in (
						${JOB_ID_IN_FS_JOBS} where fusion_job_id in (
							${FS_JOB_ID_IN_SSJ} where segment_set_job_id in (
								${SSJ_ID_IN_MU_JOBS}
							)
						)
					)
					and job_state != 2
					order by 1"""
		return sqlExecutor.getSqlResult(sql).job_id
	}

	def updateJobLimit(functionName,value){
		String UPDATE_JOB_LIMIT="update function_types set job_limit = ${value} where function_name = '${functionName}'"
		sqlExecutor.sqlExecute(UPDATE_JOB_LIMIT)
		sqlExecutor.commit()
	}

	def dropSeq(sequenceName){
		String DROP_SEQ = "drop sequence ${sequenceName}"
		sqlExecutor.sqlExecute(DROP_SEQ)
		sqlExecutor.commit()
	}
	
	def createJobQueueSeq(startNum){
		String CREATE_JOB_QUEUE_SEQ = """
										CREATE SEQUENCE JOB_QUEUE_SEQ
    									INCREMENT BY 1
    									START WITH ${startNum}
    									NOMAXVALUE
    									NOCYCLE
    									CACHE 20
										"""
		sqlExecutor.sqlExecute(CREATE_JOB_QUEUE_SEQ)
		sqlExecutor.commit()
	}

	
	def createPbSeq(startNum){
		String CREATE_PERSON_BIOMETRIC_SEQ = """
										CREATE SEQUENCE PERSON_BIOMETRIC_SEQ
    									INCREMENT BY 1
    									START WITH ${startNum}
    									NOMAXVALUE
    									NOCYCLE
    									NOCACHE
										ORDER
										"""
		sqlExecutor.sqlExecute(CREATE_PERSON_BIOMETRIC_SEQ)
		sqlExecutor.commit()
	}


	def insertPersonBio(def externalId, def eventId, def containerId, byte[] binary){
		
		Long bioId = jdbcTemplate.queryForLong("select max(biometrics_id) from person_biometrics");
		if (bioId == null) {
			bioId = 1;
		} else {
			bioId++;
		}
		jdbcTemplate.update(INSERT_PB_SQL, bioId, externalId, binary,
				binary.length, new Date().getTime(), 0, eventId, containerId);

	}
	
}
