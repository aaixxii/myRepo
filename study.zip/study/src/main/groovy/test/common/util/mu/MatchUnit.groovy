package test.common.util.mu

import java.util.regex.*
import common.sql.*
import common.os.linux.*
import common.queue.SingletonMapQueue
import test.degrade.properties.*
import test.common.util.db.*
import test.degrade.util.SoapuiObject
import static test.common.constants.aim.AIMWord.*


class MatchUnit{
	def final String SELECTED_FINGERS 	  	= "SelectedFingers"
	def final String QR				 	  	= "QR"
	def final String ROTATION_LIMIT			= "Rotation Angle"
	def final String SEARCH_MODE  	 	  	= "searchMode"
	def final String ROTATION_LIMIT_CMLAF	= "rotationLimit"
	def final String DISTORTION_LEVEL_CMLAF	= "distortionLevel"
	def final String ALGORITHM			 	= "Algorithm"
	def final String ROTATION_LIMIT_PALM  	= "Rotation Limit"
	def final String CORE_POSITION 		 	= "CorePosition"
	def final String SPEED_LEVEL   		 	= "Speed Level"
	def final String DISTORTION_LEVEL	 	= "Distortion Level"
	def final String SEARCH_LEVEL_LFML		= "SearchLevel"
	def final String SPEED_LEVEL_LFML_P		= "SpeedLevel\\[0\\]"
	def final String SPEED_LEVEL_LFML_S		= "SpeedLevel\\[1\\]"
	def final String ROTATION_LIMIT_LFML_P		= "RotationLimit\\[0\\]"
	def final String ROTATION_LIMIT_LFML_S		= "RotationLimit\\[1\\]"
	def final String DISTORTION_LEVEL_LFML_P	= "DistortionLevel\\[0\\]"
	def final String DISTORTION_LEVEL_LFML_S	= "DistortionLevel\\[1\\]"
	def final String IMAGE_ANALYSIS = "ImageAnalysis"
	def final String NUM_DOWNLOADS	= "NumConcurrentDownloads"
	def final String PROXY					= "Proxy"
	def final String HOST					= "Host"
	def final String PORT					= "Port"
	static final String MU_LOG_DIR = "./mu_log"
	static final String MU_LOG_BK_DIR = "./mu_log_bk"
	static final String MATCHER = "Matcher"
	static final String EXTRACTOR = "Extractor"
	static final String SLAP_SEGMODE_4_FINGERS = "SlapSegMode4Fingers"
	static final String SLAP_SEGMODE_2_THUMBS = "SlapSegMode2Thumbs"
    private static final String MU_CONF_SECTION_MAP_KEY = "sectionMap"
	private	LinuxCommander linuxCmder = new LinuxCommander()
	def globalProperties
	def sqlExecutor
    def soapuiObj
	String muIp
	String muPort
	String muUser
	String muPass
	String muHome
	String sshShell
	String scpShell
	Map muConfigMap
	int startSleepTime = 30000
	int stopSleepTime = 10000


	MatchUnit(context){
        this.soapuiObj = new SoapuiObject(context)
		this.globalProperties = new GlobalProperties(context)
		this.sqlExecutor = new SqlExecutorFactory(context).create()
		this.muIp = globalProperties.getMuIp()
		this.muPort = globalProperties.getMuPort()
		this.muUser = globalProperties.getMuUser()
		this.muPass = globalProperties.getMuPass()
		this.muHome = globalProperties.getMuHome()
		String shellDir = globalProperties.getSubtoolDir()
		this.sshShell = "${shellDir}/common_tools/exec_ssh_cmd_automatically_input_pass.sh"
		this.scpShell = "${shellDir}/common_tools/exec_scp_cmd_automatically_input_pass.sh"
		this.muConfigMap = setMuConfigMap()
	}

	MatchUnit(context, muIp){
        this.soapuiObj = new SoapuiObject(context)
		this.globalProperties = new GlobalProperties(context)
		this.muIp = muIp
		this.muPort = globalProperties.getMuPort()
		this.muUser = globalProperties.getMuUser()
		this.muPass = globalProperties.getMuPass()
		this.muHome = globalProperties.getMuHome()
		String shellDir = globalProperties.getSubtoolDir()
		this.sshShell = "${shellDir}/common_tools/exec_ssh_cmd_automatically_input_pass.sh"
		this.scpShell = "${shellDir}/common_tools/exec_scp_cmd_automatically_input_pass.sh"
		this.muConfigMap = setMuConfigMap()
	}
	

	def Map setMuConfigMap(){
		File muConfig = getMuConfig()
		Map map = new HashMap()
		def pattern = Pattern.compile("=..*")
		muConfig.eachLine{
			def line = it as String
			if(pattern.matcher(line).find()){
				def strTokenizer = new StringTokenizer(line, "=")
				def String key = strTokenizer.nextToken()
				def String value = strTokenizer.nextToken()
				map << [ ("${key}" as String):("${value}" as String) ]
			}
		}
        map << [ (MU_CONF_SECTION_MAP_KEY as String):loadMuConfEachSection(muConfig) ]
		muConfig.delete()
		return map
	}

	def Map loadMuConfEachSection(File muConfig){
		Map configMap = new LinkedHashMap()
		def sectionPattn = Pattern.compile("\\[..*\\]")
		def parmPattn = Pattern.compile("..*=")
        def section = ""
		muConfig.eachLine{
			def line = it as String
            if(sectionPattn.matcher(line).find()) {
                section = line.replaceAll("\\[", "").replaceAll("\\]", "")
				configMap << [ ("${section}" as String):(new LinkedHashMap()) ]
            }else if(parmPattn.matcher(line).find()){
				def strTokenizer = new StringTokenizer(line, "=")
				def String key = strTokenizer.nextToken()
				def String value = ""
                try{
				    value = strTokenizer.nextToken()
                }catch(NoSuchElementException e) {
                    soapuiObj.log("${key} value is empty.")
                }
                def paramMap = configMap.get(section)
				paramMap << [ ("${key}" as String):("${value}" as String) ]
			}
		}
		return configMap
	}

	def getMuConfig() {
		scpMuConfigToCurrentDir()
		return new File("./MuConfig")
	}

	def void scpMuConfigToCurrentDir(){
		List args = [ "${muUser}@${muIp}:${muHome}/config/MuConfig", ".", muPass ]
		linuxCmder.doShWithArgs(scpShell, args)
	}

	def void scpMuConfigFromCurrentDir(){
		List args = [ "./MuConfig", "${muUser}@${muIp}:${muHome}/config/", muPass ]
		linuxCmder.doShWithArgs(scpShell, args)
	}

	def void scpMatcherLogsToHere(){
		new File(MU_LOG_DIR).mkdir()
		deleteCopiedMatcherLogs()

		def matcherSize = getMatcherSize() as int
		def zero = ""
		for(i in 1..matcherSize){
			if(i > 99){
				zero = ""
			}else if(i <= 99 && i > 9){
				zero = "0"
			}else{
				zero = "00"
			}
			List args = [ "${muUser}@${muIp}:${muHome}/log/Matcher_${zero}${i}.log", MU_LOG_DIR, muPass ]
			linuxCmder.doShWithArgs(scpShell, args)
		}
		
		scpMuLogsToBkupDir(MATCHER)
	}

	private scpMuLogsToBkupDir(String functionType) {
		String date = new Date().format("yyyyMMdd_HHmmss")
		String muLogBkDir = "${MU_LOG_BK_DIR}/${date}"
		new File(muLogBkDir).mkdirs()
		List args = [ "${muUser}@${muIp}:${muHome}/log/${functionType}_???.log", muLogBkDir, muPass ]
		linuxCmder.doShWithArgs(scpShell, args)
	}
	
	def void scpExtractorLogsToHere(){
        new File(MU_LOG_DIR).mkdir()
		deleteCopiedExtractorLogs()

		def extractorSize = getExtractorSize() as int
		def zero = ""
		String shellCmd = ""
		for(i in 1..extractorSize){
			if(i > 99){
				zero = ""
			}else if(i <= 99 && i > 9){
				zero = "0"
			}else{
				zero = "00"
			}
        	List args = ["${muUser}@${muIp}:${muHome}/log/Extractor_${zero}${i}.log", MU_LOG_DIR, muPass ]
        	new  LinuxCommander().doShWithArgs(scpShell, args)
		}
		scpMuLogsToBkupDir(EXTRACTOR)
	}
	
	def void scpMuLogToHere(){
        new File(MU_LOG_DIR).mkdir()
        List args = ["${muUser}@${muIp}:${muHome}/log/MU.log", MU_LOG_DIR, muPass ]
        new  LinuxCommander().doShWithArgs(scpShell, args)
		scpMuLogsToBkupDir(EXTRACTOR)
	}
	

	def getNumProcMatcher(){
		return muConfigMap["NumProcMatcher"]
	}

	def getNumProcExtractor(){
		return muConfigMap["NumProcExtractor"]
	}
	
	def getMultiAxisHighScore() {
		return muConfigMap["MultiAxisHighScore"]
	}
	
	def getMinutiaThreshold() {
		return muConfigMap["MinutiaThreshold"]
	}
	
	public String getMuConfigValue(String key){
		return muConfigMap[key]
	}
	
	public String getMuConfigValue(String section, String key){
		return muConfigMap[MU_CONF_SECTION_MAP_KEY][section][key]
	}
	
	public Map getMuConfigSectionValueMap(String section){
		return muConfigMap[MU_CONF_SECTION_MAP_KEY][section]
	}

    public Set getMuConfigSections() {
        return muConfigMap[MU_CONF_SECTION_MAP_KEY].keySet()
    }
	
	public void updateMuConfAndReload(String section, String key, String value){
	    updateMuConfigValue(section, key, value, false)
		reloadConfig()
	}
	
	public void updateMuConfigValue(String section, String key, String value){
	    updateMuConfigValue(section, key, value, true)
	    //updateMuConfigValue(section, key, value, false)
		//reloadConfig()
	}
	
	public boolean updateMuConfigValue(String section, String key, String value, boolean needReboot){
		def muConfKeyVal = muConfigMap[MU_CONF_SECTION_MAP_KEY][section]
        assert (muConfKeyVal != null && muConfKeyVal[key] != null),
            "There are no parameter '${key}' of section '${section}' in MuConfig. Couldn't update MuConfig."

        if(muConfKeyVal[key] == value) {
            soapuiObj.log("${section}/${key} is already ${value}. Nothing to do.")
            return false
        }

        soapuiObj.log("Updating ${section}/${key} to ${value}...")
        muConfKeyVal[key] = value
        mkMuConfFromMem()
        scpMuConfigFromCurrentDir()
        if(needReboot) {
            reboot()
        }else{
            soapuiObj.log("Reboot flag is false. Skip rebooting MU...")
        }
        return true
	}
	
	
	def getMatcherSize(){
		if(getNumProcMatcher() == "0"){
			return getCpuCoreNum()
		}else{
			return getNumProcMatcher() 
		}
	}
	
	def getExtractorSize(){
		if(getNumProcExtractor() == "0"){
			return getCpuCoreNum() as int
		}else{
			return getNumProcExtractor() as int
		}
	}

	def getCpuCoreNum() {
		List resultList =  executeMuShell("grep processor /proc/cpuinfo | wc -l")
		return resultList.get(resultList.size()-1) as int
	}

	def getMuHome(){
		return muHome
	}

	def getMuId(){
		scpMuLogToHere()
		String cmd = "grep Enter ${MU_LOG_DIR}/MU.log"
		String cmdRes = linuxCmder.doCommand(cmd)
		int index = cmdRes.lastIndexOf("MUID:")
		String muId = cmdRes.getAt(index + 6 .. (cmdRes.size() - 16))
		return muId
	}

	// FMatch
	def getFmatchSelectedFingersFromMuLog(logIndex){
		def cmd = createGrepFmatchParamCmd(logIndex, SELECTED_FINGERS, "18", ":")
		return linuxCmder.doShCommand(cmd)
	}

	def getFmatchQRFromMuLog(logIndex){
		def cmd = createGrepFmatchParamCmd(logIndex, QR, "7", "=")
		return linuxCmder.doShCommand(cmd)
	}

	def getFmatchSpeedLevelFromMuLog(logIndex){
		def cmd = createGrepFmatchParamCmd(logIndex, SPEED_LEVEL, "4", ":")
		return linuxCmder.doShCommand(cmd)
	}

	def getFmatchRotationLimitFromMuLog(logIndex){
		def cmd = "grep '${ROTATION_LIMIT}' ${MU_LOG_DIR}/Matcher_???.log | sed 's/^.*.log://g' | \
                    sort | sed 's/.*Angle://g' | sed 's/ Distortion.*//g'"
		return linuxCmder.doShCommand(cmd)
	}

	def getFmatchDistortionLevelFromMuLog(logIndex){
		def cmd = createGrepFmatchParamCmd(logIndex, DISTORTION_LEVEL, "9", ":")
		return linuxCmder.doShCommand(cmd)
	}

	def createGrepFmatchParamCmd(logIndex, grepWord, awkIndex1, separator){
		return "grep '${grepWord}' ${MU_LOG_DIR}/Matcher_???.log | grep -v \"Segment Record Count: 0\" | \
				sed 's/^.*.log://g' | sort | sed 's%^....-..-.. %%' | sed 's/,//g' | awk '{print \$${awkIndex1}}' | awk -F'${separator}' '{print \$2}'"
	}


	// CMLaF
	def getCmlafSearchModeFromMuLog(logIndex){
		def cmd = createGrepCmlafParamCmd(logIndex, SEARCH_MODE, "9")
		return linuxCmder.doShCommand(cmd)
	}

	def getCmlafRotationLimitFromMuLog(logIndex){
		def cmd = createGrepCmlafParamCmd(logIndex, ROTATION_LIMIT_CMLAF, "10")
		return linuxCmder.doShCommand(cmd)
	}

	def getCmlafDistortionLevelFromMuLog(logIndex){
		def cmd = createGrepCmlafParamCmd(logIndex, DISTORTION_LEVEL_CMLAF, "11")
		return linuxCmder.doShCommand(cmd)
	}

	def getIrisRotationLimitFromMuLog(){
		def cmd = createGrepIrisRotationParamCmd()
		return linuxCmder.doShCommand(cmd)
	}

	def getNirisExtModeFromMuLog(){
		def cmd = createGrepNirisExtModeCmd()
		return linuxCmder.doShCommand(cmd)
	}

	def createGrepCmlafParamCmd(logIndex, grepWord, awkIndex1){
		return "grep '${grepWord}' ${MU_LOG_DIR}/Matcher_???.log | \
				sed 's/^.*.log://g' | \
				sort | \
				sed 's%^....-..-.. %%' | \
				sed 's/,//g' | \
				awk '{print \$${awkIndex1}}' | \
				awk -F':' '{print \$2}'"
	}

	def createGrepIrisRotationParamCmd(){
		return "grep -i 'rotationLimit' ${MU_LOG_DIR}/Matcher_???.log | \
				sed 's/^.*.log://g' | \
				sort | \
				sed 's/.*otationLimit //g' | \
				sed 's/ degree//g'"
	}

	def createGrepNirisExtModeCmd(){
		return "grep 'NirisExtractionMode' ${MU_LOG_DIR}/Extractor_???.log | \
				sed 's/^.*.log://g' | \
				sort | \
				sed 's/.*NirisExtractionMode //g'"
	}

	// LE Latent
	def getLatentLEAlgorithmFromMuLog(logIndex){
		def cmd = createGrepLatentLEParamCmd(logIndex, ALGORITHM, "4", "2")
		return linuxCmder.doShCommand(cmd)
	}

	def getLatentLERotationLimitFromMuLog(logIndex){
		def cmd = createGrepLatentLEParamCmd(logIndex, ALGORITHM, "7", "1")
		return linuxCmder.doShCommand(cmd)
	}

	def getLatentLECorePositionFromMuLog(logIndex){
		def cmd = createGrepLatentLEParamCmd(logIndex, ALGORITHM, "9", "1")
		return linuxCmder.doShCommand(cmd)
	}
	def getTLILEAlgorithmFromMuLog(logIndex){
		def cmd = createGrepTLILEParamCmd(logIndex, ALGORITHM, "4", "2")
		return linuxCmder.doShCommand(cmd)
	}

	def getTLILERotationLimitFromMuLog(logIndex){
		def cmd = createGrepTLILEParamCmd(logIndex, ALGORITHM, "7", "1")
		return linuxCmder.doShCommand(cmd)
	}

	def getTLILECorePositionFromMuLog(logIndex){
		def cmd = createGrepTLILEParamCmd(logIndex, ALGORITHM, "9", "1")
		return linuxCmder.doShCommand(cmd)
	}

	def createGrepTLILEParamCmd(logIndex, grepWord, awkIndex1, awkIndex2){
		return "grep '${grepWord}' ${MU_LOG_DIR}/Matcher_???.log | sed 's/^.*.log://g' | sort | sed 's%^....-..-.. %%' | \
				awk '{print \$${awkIndex1}}' | awk -F':' '{print \$${awkIndex2}}'"
	}

	def createGrepLatentLEParamCmd(logIndex, grepWord, awkIndex1, awkIndex2){
		return "grep '${grepWord}' ${MU_LOG_DIR}/Matcher_???.log | grep 'SetSearchMinutia' | sed 's/^.*.log://g' | sort | sed 's%^....-..-.. %%' | \
				awk '{print \$${awkIndex1}}' | awk -F':' '{print \$${awkIndex2}}'"
	}

	// PC2 Latent
	def getLatentPC2SpeedLevelFromMuLog(logIndex){
		def cmd = createGrepLatentPC2ParamCmd(logIndex, SPEED_LEVEL, "5", "2", ":")
		return linuxCmder.doShCommand(cmd)
	}

	def getLatentPC2RotationLimitFromMuLog(logIndex){
		def cmd = createGrepLatentPC2ParamCmd(logIndex, ROTATION_LIMIT, "7", "2", "=", ",")
		return linuxCmder.doShCommand(cmd)
	}

	def getLatentPC2DistortionLevelFromMuLog(logIndex){
		def cmd = createGrepLatentPC2ParamCmd(logIndex, DISTORTION_LEVEL, "10", "2", ":")
		return linuxCmder.doShCommand(cmd)
	}

	def createGrepLatentPC2ParamCmd(logIndex, grepWord, awkIndex1, awkIndex2, separator){
		return "grep '${grepWord}' ${MU_LOG_DIR}/Matcher_???.log | sed 's/^.*.log://g' | sort | \
				awk '{print \$${awkIndex1}}' | awk -F'${separator}' '{print \$${awkIndex2}}'"
	}
	
	def createGrepLatentPC2ParamCmd(logIndex, grepWord, awkIndex1, awkIndex2, separator, separator2){
		return "grep '${grepWord}' ${MU_LOG_DIR}/Matcher_???.log | sed 's/^.*.log://g' | sort | \
				awk '{print \$${awkIndex1}}' | awk -F'${separator}' '{print \$${awkIndex2}}'|awk -F'${separator2}' '{print \$1}'"
	}
	
	//Extract
       def getExtractOptionLmtOfMinFromMuLog(logIndex){
		   def cmd = createGrepExtractCmd(logIndex, "LmtOf", "7", "12", ":")
           return linuxCmder.doShCommand(cmd)
       }
	
      def getExtractOptionFeTypeFromMuLog(logIndex){
		  def cmd = createGrepExtractCmd(logIndex, "FeType", "6", "12", ":")
		  return linuxCmder.doShCommand(cmd)
      }

	  def getExtractOptionEhnTypeFromMuLog(logIndex){
		  def cmd = createGrepExtractCmd(logIndex, "EnhType", "8", "12", ":")
		  return linuxCmder.doShCommand(cmd)
	  }

	  def getExtractOptionEhnTypeFromMuLog(logIndex, fingerType, fusionId){
		  def cmd = createGrepExtractCmd(logIndex, "EnhType", fingerType, fusionId)
		  return linuxCmder.doShCommand(cmd)
	  }

	  def getExtractOptionSpecEhnTypeFromMuLog(logIndex, fingerType, fusionId, enhType){
		  def cmd = createGrepEnhanceCmd(logIndex, "EnhType", fingerType, fusionId, enhType)
		  return linuxCmder.doShCommand(cmd)
	  }

	  def createGrepExtractCmd(logIndex, grepWord, awkIndex1, sortIndex, separator){
		  return "grep '${grepWord}' ${MU_LOG_DIR}/Extractor_???.log | sed 's/^.*.log://g' | sed 's%^....-..-.. %%'| sort -t : -k'${sortIndex}' | \
			  	  awk '{print \$${awkIndex1}}' | awk -F'${separator}' '{print \$2}'"
	  }
	
	  def createGrepExtractCmd(logIndex, grepWord1, grepWord2, fusionId){
		  return "grep '${grepWord1}' ${MU_LOG_DIR}/Extractor_???.log | \
			grep ${grepWord2} | grep 'Multiplicit:${fusionId}' | \
			sed 's/.*FingerIndex://g' | sed 's/Multiplicit://g' | sed 's/FeType.*EhnType://g' | sed 's/,//g' | sort"
	  }

	  def createGrepEnhanceCmd(logIndex, grepWord1, grepWord2, fusionId, enhType){
		  return "grep '${grepWord1}:${enhType}' ${MU_LOG_DIR}/Extractor_???.log | \
			grep '${grepWord2}' | grep 'Multiplicity:${fusionId}' | \
			sed 's/.*FingerIndex://g' | sed 's/Multiplicity://g' | sed 's/FeType.*EnhType://g' | sed 's/,.\$//g' | sort"
	  }
	

	// LFML
	def getLatentLFMLSearchLevelFromMuLog(logIndex){
		def cmd = createGrepLatentLFMLSearchLevelParamCmd(logIndex, SEARCH_LEVEL_LFML, "2")
		return linuxCmder.doShCommand(cmd) 
	}
	
	def getLatentLFMLSpeedLevelPrimaryFromMuLog(logIndex){
		def cmd = createGrepLatentLFMLParamCmd(logIndex, SPEED_LEVEL_LFML_P, "2")
		return linuxCmder.doShCommand(cmd)
	}
	
	def getLatentLFMLSpeedLevelSecondaryFromMuLog(logIndex){
		def cmd = createGrepLatentLFMLParamCmd(logIndex, SPEED_LEVEL_LFML_S, "2")
		return linuxCmder.doShCommand(cmd)
	}
	
	def getLatentLFMLRotationLimitPrimaryFromMuLog(logIndex){
		def cmd = createGrepLatentLFMLParamCmd(logIndex, ROTATION_LIMIT_LFML_P, "2")
		return linuxCmder.doShCommand(cmd)
	}
	
	def getLatentLFMLRotationLimitSecondaryFromMuLog(logIndex){
		def cmd = createGrepLatentLFMLParamCmd(logIndex, ROTATION_LIMIT_LFML_S, "2")
		return linuxCmder.doShCommand(cmd)
	}
	
	def getLatentLFMLDistortionLevelPrimaryFromMuLog(logIndex){
		def cmd = createGrepLatentLFMLParamCmd(logIndex, DISTORTION_LEVEL_LFML_P, "2")
		return linuxCmder.doShCommand(cmd)
	}

	def getLatentLFMLDistortionLevelSecondaryFromMuLog(logIndex){
		def cmd = createGrepLatentLFMLParamCmd(logIndex, DISTORTION_LEVEL_LFML_S, "2")
		return linuxCmder.doShCommand(cmd)
	}

	def getRDBLMExtFileFromMuLog(){
		def cmd = createGrepLFMLExtFileCmd("RDBLM")
		return linuxCmder.doShCommand(cmd)
	}

	def getLDBMMExtFileFromMuLog(){
		def cmd = createGrepLFMLExtFileCmd("LDBM")
		return linuxCmder.doShCommand(cmd)
	}

	def getLIMExtFileFromMuLog(){
		def cmd = createGrepLFMLExtFileCmd("LIM")
		return linuxCmder.doShCommand(cmd)
	}

	def getLLIMExtFileFromMuLog(){
		def cmd = createGrepLFMLExtFileCmd("LLIM")
		return linuxCmder.doShCommand(cmd)
	}

	def getTLIMExtFileFromMuLog(){
		def cmd = createGrepLFMLExtFileCmd("TLIM")
		return linuxCmder.doShCommand(cmd)
	}

	def createGrepLatentLFMLSearchLevelParamCmd(logIndex, grepWord, awkIndex){
		return "grep '${grepWord}' ${MU_LOG_DIR}/Matcher_???.log |sed 's/^.*.log://g' | \
				sort | sed 's/^.*${grepWord}//g' |sed 's/\\[//g' |sed 's/\\]//g' |awk -F '=' '{print \$2}'"
	}

	def createGrepLatentLFMLParamCmd(logIndex, grepWord, awkIndex){
		return "grep '${grepWord}' ${MU_LOG_DIR}/Matcher_???.log |sed 's/^.*.log://g' | \
				sort | sed 's/^.*${grepWord}//g' | awk -F ':' '{print \$${awkIndex}}'"
	}

	def createGrepLFMLExtFileCmd(grepWord){
		return "grep '${grepWord}' ${MU_LOG_DIR}/Extractor_???.log | sed 's/^.*.log://g' | \
				sort | sed 's/^.*${grepWord}/${grepWord}/g' | sed 's/.dat]//'"
	}

	// Palm PC3R
	def getPalmRotationLimitFromMuLog(logIndex){
		def cmd = "grep '${ROTATION_LIMIT_PALM}' ${MU_LOG_DIR}/Matcher_???.log | sed 's/^.*.log://g' | sort | sed 's%^....-..-.. %%' | cut -d' ' -f5"
		return linuxCmder.doShCommand(cmd)
	}

	def getPalmSpeedLevelPrimaryFromMuLog(logIndex){
		def cmd = createGrepPC3RParamCmd(logIndex, SPEED_LEVEL, "7", "2", ",")
		return linuxCmder.doShCommand(cmd)
	}

	def getPalmSpeedLevelSecondaryFromMuLog(logIndex){
		def cmd = createGrepPC3RParamCmd(logIndex, SPEED_LEVEL, "7", "3", "]")
		return linuxCmder.doShCommand(cmd)
	}

	def getPalmDistortionLevelPriomaryFromMuLog(logIndex){
		def cmd = createGrepPC3RParamCmd(logIndex, DISTORTION_LEVEL, "9", "2", ",")
		return linuxCmder.doShCommand(cmd)
	}

	def getPalmDistortionLevelSecondaryFromMuLog(logIndex){
		def cmd = createGrepPC3RParamCmd(logIndex, DISTORTION_LEVEL, "9", "3", "]")
		return linuxCmder.doShCommand(cmd)
	}

	def createGrepPC3RParamCmd(logIndex, grepWord, awkIndex1, awkIndex2, separator){
		return "grep '${grepWord}' ${MU_LOG_DIR}/Matcher_???.log | sed 's/^.*.log://g' | sort | sed 's%^....-..-.. %%' | \
					awk '{print \$${awkIndex1}}' | awk -F':' '{print \$${awkIndex2}}' | awk -F'${separator}' '{print \$1}'"
	}

	def getAppearingCount(extractorSize, sentence) {
		scpExtractorLogsToHere()
		def cmd = createGrepSentenceExistance(extractorSize, sentence)
		return linuxCmder.doShCommand(cmd)
	}

	def createGrepSentenceExistance(logIndex, sentence) {
		return "grep '${sentence}' ${MU_LOG_DIR}/Extractor_0??.log |awk -F ':' '{print \$11}' |wc -l"
	}

	def _clearMatcherLog(){
		def matcherSize = getMatcherSize() as int
		for(i in 1..matcherSize){
			def muLog = new File("${MU_LOG_DIR}/Matcher00${i}.log")
			muLog.write("")
		}
	}

	def clearMatcherLog(){
		def matcherSize = getMatcherSize() as int
		def zero = ""
		String shellCmd = ""
		for(i in 1..matcherSize){
			if(i > 99){
				zero = ""
			}else if(i <= 99 && i > 9){
				zero = "0"
			}else{
				zero = "00"
			}
			shellCmd += "cp -p ${muHome}/log/Matcher_${zero}${i}.log ${muHome}/log/Matcher_${zero}${i}.`date +%Y%m%d-%H%M%S`.log; "
			shellCmd += ": > ${muHome}/log/Matcher_${zero}${i}.log > /dev/null; "
		}
		executeMuShell(shellCmd)
		deleteCopiedExtractorLogs()
		deleteCopiedMatcherLogs()
	}
	
	def clearExtractorLog(){
		def extractorSize = getExtractorSize() as int
		def zero = ""
		String shellCmd = ""
		for(i in 1..extractorSize){
			if(i > 99){
                 zero = ""
             }else if(i <= 99 && i > 9){
                 zero = "0"
             }else{
                 zero = "00"
             }
			shellCmd += "cp -p ${muHome}/log/Extractor_${zero}${i}.log ${muHome}/log/Extractor_${zero}${i}.`date +%Y%m%d-%H%M%S`.log; "
			shellCmd += ": > ${muHome}/log/Extractor_${zero}${i}.log; "
		}
		executeMuShell(shellCmd)
		deleteCopiedExtractorLogs()
		deleteCopiedMatcherLogs()
	}

	def void reboot(){
		muAgentStop(stopSleepTime)
		muAgentStart(startSleepTime)
	}

	def muAgentStart(){
        soapuiObj.log("Starting MU...")
		muAgentStart(startSleepTime)
	}

	def muAgentStart(int sleepTime){
		doNetstat("before")
		//String startCmd = "netstat -na | grep 1300 > ${muHome}/log/netstat_before_runMU_`date +'%m%d_%H%M%S%N'`; ./runMU.sh; netstat -na | grep 1300 > ${muHome}/log/netstat_after_runMU_`date +'%m%d_%H%M%S%N'`"
		String startCmd = "./runMU.sh"
		executeMuShell(startCmd)
		doNetstat("after")
		sleep sleepTime
	}

	def doNetstat(String beforeOrAfter){
		int port = 1300
		String output = "${muHome}/log/netstat_${beforeOrAfter}_runMU_`date +'%m%d_%H%M%S%N'`"
		return linuxCmder.sudoNetstat(port, output) 
	}

	def muAgentStop(){
        soapuiObj.log("Stop MU...")
		muAgentStop(stopSleepTime)
	}

	def muAgentStop(int sleepTime){
		String stopCmd = "./stopMU.sh"
		executeMuShell(stopCmd)
		sleep sleepTime
	}

	def deleteSegments(){
		String delCmd = "rm -f ${muHome}/cache/*"
		executeMuShell(delCmd)
	}
	
	def executeMuShell(String command){
		List args = [ muUser, muIp, command, muPass ]
		return linuxCmder.doShWithArgs(sshShell, args)
	}
	
       def changeToPZIP() {
				updateMuConfigValue(CORE_ENGINE, PALM, PZIP_ENGINE)
        }
		
        def changeToPC3R() {
				updateMuConfigValue(CORE_ENGINE, PALM, PC3R_ENGINE)
        }

	def changeFinalScoreMethod(value){
		String cmd = "cd ${muHome}/config; mv MuConfig MuConfig.tmp; sed -e 's/FinalScoreMethod=.*/FinalScoreMethod=${value}/g' MuConfig.tmp > MuConfig; rm -f MuConfig.tmp"
                executeMuShell(cmd)
	}

	def changeFinalScoreMethodTo3(){
		String cmd = "cd ${muHome}/config; mv MuConfig MuConfig.tmp; sed -e 's/FinalScoreMethod=.*/FinalScoreMethod=3/g' MuConfig.tmp > MuConfig; rm -f MuConfig.tmp"
		executeMuShell(cmd)
	} 
	
	def changeFinalScoreMethodTo2(){
		String cmd = "cd ${muHome}/config; mv MuConfig MuConfig.tmp; sed -e 's/FinalScoreMethod=.*/FinalScoreMethod=2/g' MuConfig.tmp > MuConfig; rm -f MuConfig.tmp"
		executeMuShell(cmd)
	}
	
        def changeFinalScoreMethodTo0(){
                String cmd = "cd ${muHome}/config; mv MuConfig MuConfig.tmp; sed -e 's/FinalScoreMethod=.*/FinalScoreMethod=0/g' MuConfig.tmp > MuConfig; rm -f MuConfig.tmp"
                executeMuShell(cmd)
        }

	def changeExtractModeTo0(){
		String cmd = "cd ${muHome}/config; mv MuConfig MuConfig.tmp; sed -e 's/ExtractMode=2/ExtractMode=0/g' MuConfig.tmp > MuConfig; rm -f MuConfig.tmp"
		executeMuShell(cmd)
	}
	
	def changeExtractModeTo2(){
		String cmd = "cd ${muHome}/config; mv MuConfig MuConfig.tmp; sed -e 's/ExtractMode=0/ExtractMode=2/g' MuConfig.tmp > MuConfig; rm -f MuConfig.tmp"
		executeMuShell(cmd)
	}

		def changeReplaceMinutiaIndexTo2(){
			String cmd = "cd ${muHome}/config; mv MuConfig MuConfig.tmp; sed -e 's/ReplaceMinutiaIndex=.*/ReplaceMinutiaIndex=2/g' MuConfig.tmp > MuConfig; rm -f MuConfig.tmp"
			executeMuShell(cmd)
		}

		def changeReplaceMinutiaIndexTo0(){
			String cmd = "cd ${muHome}/config; mv MuConfig MuConfig.tmp; sed -e 's/ReplaceMinutiaIndex=.*/ReplaceMinutiaIndex=0/g' MuConfig.tmp > MuConfig; rm -f MuConfig.tmp"
			executeMuShell(cmd)
		}

		def changeMinutiaThTo0(){
                String cmd = "cd ${muHome}/config; mv MuConfig MuConfig.tmp; sed -e 's/MinutiaThreshold=1/MinutiaThreshold=0/g' MuConfig.tmp > MuConfig; rm -f MuConfig.tmp"
				executeMuShell(cmd)
		}
		
		def changeMinutiaThTo1(){
			String cmd = "cd ${muHome}/config; mv MuConfig MuConfig.tmp; sed -e 's/MinutiaThreshold=0/MinutiaThreshold=1/g' MuConfig.tmp > MuConfig; rm -f MuConfig.tmp"
			executeMuShell(cmd)
		}
	
	def changeSlapSegMode4Fingers(String value){
		changeMuConfig(SLAP_SEGMODE_4_FINGERS, value)
	}
	
	def changeSlapSegMode2Thumbs(String value){
		changeMuConfig(SLAP_SEGMODE_2_THUMBS, value)
	}

	def changeSlapSegMode4Fingers211(){
		changeSlapSegMode4Fingers("211")
	}

	def changeSlapSegMode2Thumbs80(){
		changeSlapSegMode2Thumbs("80")
	}

	def void changeMuDmpBinaryMode(String bashFile, String destStr){
		String cmd = "cat ${muHome}/${bashFile} | sed 's/^.*MU_DMP_BINARY=1/${destStr}/g' > ${muHome}/bash.tmp; cat ${muHome}/bash.tmp > ${muHome}/${bashFile}; rm -f ${muHome}/bash.tmp"
		executeMuShell(cmd)
	}
	
	def void changeMuDumpBinaryMode(String bashFile, String destStr){
		String cmd = "cat ${muHome}/${bashFile} | sed 's/^.*MU_DUMP_BINARY=1/${destStr}/g' > ${muHome}/bash.tmp; cat ${muHome}/bash.tmp > ${muHome}/${bashFile}; rm -f ${muHome}/bash.tmp"
		executeMuShell(cmd)
	}

	def isMuDunmBinary(String bashFile){
		String cmd = "cat ${muHome}/${bashFile} | grep 'MU_DUMP_BINARY'|wc -l"
		List resultList = executeMuShell(cmd)
		if ( "0" != resultList[(resultList.size() -1)]){
			return true
		}else {
			return false
		}
	}
	
	def void addMuDumpBinaryMode(String bashFile){
		String cmd = "cat ${muHome}/${bashFile} | sed '/dump/a\\export MU_DUMP_BINARY=1' > ${muHome}/bash.tmp; cat ${muHome}/bash.tmp > ${muHome}/${bashFile}; rm -f ${muHome}/bash.tmp"
		executeMuShell(cmd)
	}
	
	
	def void setupMuDmpBinaryOn(){
		setMuDmpBinaryOn()
		reboot()
		cleanDumpFiles()
	}
	
	def void setupMuDmpBinaryOnAfterAim40(){
		setMuDumpBinaryOn()
		setMuDmpBinaryOn()
		reboot()
		cleanDumpFiles()
	}

	def void setupMuDmpBinaryOff(){
		setMuDmpBinaryOff()
		reboot()
		cleanDumpFiles()
	}
	
	def void setupMuDmpBinaryOffAfterAim40(){
		setMuDumpBinaryOff()
		setMuDmpBinaryOff()
		reboot()
		cleanDumpFiles()
	}

	def void setMuDmpBinaryOn(){
		String destStr = "export MU_DMP_BINARY=1"
		changeMuDmpBinaryMode(".bashrc", destStr)
		changeMuDmpBinaryMode(".bash_profile", destStr)
	}
	
	def void setMuDumpBinaryOn(){
		String destStr = "export MU_DUMP_BINARY=1"
		if ( !isMuDunmBinary(".bashrc")){
			addMuDumpBinaryMode(".bashrc")
		}
		if ( !isMuDunmBinary(".bash_profile")){
			addMuDumpBinaryMode(".bash_profile")
		}
		changeMuDumpBinaryMode(".bashrc", destStr)
		changeMuDumpBinaryMode(".bash_profile", destStr)
	}

	def void setMuDmpBinaryOff(){
		String destStr = "#export MU_DMP_BINARY=1"
		changeMuDmpBinaryMode(".bashrc", destStr)
		changeMuDmpBinaryMode(".bash_profile", destStr)
	}
	
	def void setMuDumpBinaryOff(){
		String destStr = "#export MU_DUMP_BINARY=1"
		changeMuDumpBinaryMode(".bashrc", destStr)
		changeMuDumpBinaryMode(".bash_profile", destStr)
	}

	def void cleanDumpFiles(){
        String cmd = "cd ${muHome}/log; rm -f dump/*"
		executeMuShell(cmd)
	}
	
	def void scpCropRawData(String destDir){
		List args = [ "${muUser}@${muIp}:${muHome}/log/dump/*crop.raw", destDir, muPass ]
		linuxCmder.doShWithArgs(scpShell, args)
	}

	def void scpCropRawDataAfterAim40(String destDir){
		List args = [ "${muUser}@${muIp}:${muHome}/log/dump/*org.raw", destDir, muPass ]
		linuxCmder.doShWithArgs(scpShell, args)
	}

	def changeMuConfig(String param, String value) {
		String cmd = "cd ${muHome}/config; mv MuConfig MuConfig.tmp; sed -e 's/^${param}=.*./${param}=${value}/g' MuConfig.tmp > MuConfig; rm -f MuConfig.tmp"
		executeMuShell(cmd)
	}
	
	def changeHeartbeatInterval(String value) {
		String cmd = "cd ${muHome}/config; mv MuConfig MuConfig.tmp; sed -e '/mumgr/,/childproc/s/^HeartbeatInterval=.*/HeartbeatInterval=${value}/' MuConfig.tmp > MuConfig; rm -f MuConfig.tmp"
		executeMuShell(cmd)
	}
	
	def changeNumConcurrentDownloads(def num){
		String cmd = "cd ${muHome}/config; mv MuConfig MuConfig.tmp; sed -e 's/^${NUM_DOWNLOADS}=*.*/${NUM_DOWNLOADS}=${num}/g' MuConfig.tmp > MuConfig; rm -f MuConfig.tmp"
		executeMuShell(cmd)
		reboot()
	}


	def deleteNumConcurrentDownloads(){
		String cmd = "cd ${muHome}/config; mv MuConfig MuConfig.tmp; sed -e 's/^${NUM_DOWNLOADS}=*.*//g' MuConfig.tmp > MuConfig; rm -f MuConfig.tmp"
		executeMuShell(cmd)
		reboot()
	}

	def resetNumConcurrentDownloads(){
		String cmd = "cd ${muHome}/config; echo '${NUM_DOWNLOADS}=0' >> MuConfig;"
		executeMuShell(cmd)
		reboot()
	}

	def changeProxyHost(String host){
		String cmd = "cd ${muHome}/config; mv MuConfig MuConfig.tmp; sed -e 's/^${HOST}=*.*/${HOST}=${host}/g' MuConfig.tmp > MuConfig; rm -f MuConfig.tmp"
		executeMuShell(cmd)
	}

	def changeProxyPort(String port){
		String cmd = "cd ${muHome}/config; mv MuConfig MuConfig.tmp; sed -e 's/^${PORT}=*.*/${PORT}=${port}/g' MuConfig.tmp > MuConfig; rm -f MuConfig.tmp"
		executeMuShell(cmd)
	}

	def changeProxyOn(String host, String port){
		changeMuConfig( PROXY, "enable")
		changeProxyHost(host)
		changeProxyPort(port)
		reboot()
	}

	def changeProxyOff(){
		changeMuConfig( PROXY, "disable")
		reboot()
	}

	def changeImageAnalysisTrue(){
		changeMuConfig(IMAGE_ANALYSIS, "true" )
		reboot()
	}

	def changeImageAnalysisFalse(){
		changeMuConfig(IMAGE_ANALYSIS, "false" )
		reboot()
	}
	
	def deleteMuLogs() {
		String cmd = "cd ${muHome}/log; rm -f *"
		executeMuShell(cmd)
	}

	def deleteCopiedExtractorLogs(){
        def cmd = "rm ${MU_LOG_DIR}/Extractor_???.log; rm ${MU_LOG_DIR}/Extractor_???.`date +%Y%m%d-%H%M%S`.log;"
        return linuxCmder.doShCommand(cmd)
    }
	
	def deleteCopiedMatcherLogs(){
        def cmd = "rm ${MU_LOG_DIR}/Matcher_???.log; rm ${MU_LOG_DIR}/Matcher_???.`date +%Y%m%d-%H%M%S`.log;"
        return linuxCmder.doShCommand(cmd)
    }
	
	def getReplaceMinutiaIndex() {
		return muConfigMap["ReplaceMinutiaIndex"]
	}

    def mkMuConfFromMem() {
        File muConfig = new File("./MuConfig")
        muConfig.write("")
        def muConfSectioMap = muConfigMap[MU_CONF_SECTION_MAP_KEY]
        for(keyVal in muConfSectioMap) {
            def section = keyVal.key
            def paramMap = keyVal.value
            muConfig.append("[${section}]\n")
            for(paramKeyVal in paramMap) {
                def paramKey = paramKeyVal.key
                def paramVal = paramKeyVal.value 
                muConfig.append("${paramKey}=${paramVal}\n")
            }
            muConfig.append("\n")
        }
    }

	def reloadConfig() {
		String cmd = "wget -O /dev/null http://${muIp}:${muPort}/matchunit/reloadconfig"
		linuxCmder.doCommand(cmd)
	}
	
	def enqueueMuSectionValues(String sectionName){
		def muConfMap = getMuConfigSectionValueMap(sectionName)
		def queue = SingletonMapQueue.getInstance()
		for(keyVal in muConfMap){
			queue.enqueue("${sectionName}-${keyVal.key}", keyVal.value)
		}
	}
	
	def saveMuConfToMem(){
		for(section in getMuConfigSections()){
			enqueueMuSectionValues(section)
		}
	}
	
	def restoreMuSectionValues(String sectionName){
		def muConfMap = getMuConfigSectionValueMap(sectionName)
		def queue = SingletonMapQueue.getInstance()
		def needReboot = false
		for(keyVal in muConfMap){
			def curVal = keyVal.value
			def orgVal = queue.dequeue("${sectionName}-${keyVal.key}")
			if(orgVal != null && orgVal != curVal){
				updateMuConfigValue(sectionName, keyVal.key, orgVal, false)
			}
		}
	}
	
	def restoreMuConfFromMem(){
		for(section in getMuConfigSections()){
			restoreMuSectionValues(section)
		}
		reloadConfig()
	}
}
