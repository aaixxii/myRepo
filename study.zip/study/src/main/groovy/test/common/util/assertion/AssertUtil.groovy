package test.common.util.assertion

import test.common.message.MessageCreator
import test.degrade.util.SoapuiObject
import test.degrade.management.AbendProcessor

class AssertUtil {
	SoapuiObject soapuiObject
	String testName

	AssertUtil(context, testName) {
		this.soapuiObject = new SoapuiObject(context)
		this.testName = testName
	}

	public void assertEqualsList(List actual, List expected, def propName) {
		assertEquals(actual.size(), expected.size(), "${propName} list size")
		for(i in 0..actual.size()-1) {
			assertEquals(actual[i], expected[i], propName)
		}
	}

	public void assertEquals(def actual, def expected, def propName) {
		if (actual != expected) {
			abendTest(actual, expected, propName)
		}
	}

	public void assertTrue(boolean isTrue, def propName) {
		if (!(isTrue)) {
			abendTest("False", "True", propName)
		}
	}

	public void assertFalse(boolean isTrue, def propName) {
		if (isTrue) {
			abendTest("False", "True", propName)
		}
	}

	public void abendTest(def actualVal, def expectedVal, def propName) {
		String errMessg = mkErrMessg(propName, expectedVal, actualVal)
		AbendProcessor abendProcessor = new AbendProcessor(soapuiObject.getContext())
		abendProcessor.abendTest(testName, errMessg)
	}

	private String mkErrMessg(name, expected, actual) {
		return new MessageCreator().mkValueErrMessg(name, expected, actual)
	}
}
