package test.common.util.dm

import jp.co.nec.nhm.soapui.util.dm.DmSegFileConsistencyChecker
import test.common.util.db.*
import test.degrade.util.*
import test.degrade.properties.*
import common.os.linux.*
import test.degrade.evidence.*
import test.degrade.management.*


class DataManager{
	def globalProperties
	def soapuiObject
	def segChecker
	String dmIp
	String dmUser
	String dmPass
	String dmHome
	String segDir
	String sshShell
	String scpShell
	String testName
	String DM_SEG_DIR = "./dm_seg"

	DataManager(context){
		this.globalProperties = new GlobalProperties(context)
		this.soapuiObject = new SoapuiObject(context)
		this.segChecker = new DmSegFileConsistencyChecker()
		this.dmIp = globalProperties.getDmIp()
		this.dmUser = globalProperties.getDmUser()
		this.dmPass = globalProperties.getDmPass()
		this.dmHome = globalProperties.getDmHome()
		this.segDir = globalProperties.getDmSegDir()
		String shellDir = globalProperties.getSubtoolDir()
		this.sshShell = "${shellDir}/common_tools/exec_ssh_cmd_automatically_input_pass.sh"
		this.scpShell = "${shellDir}/common_tools/exec_scp_cmd_automatically_input_pass.sh"
	}

	DataManager(context,String testName){
		this.globalProperties = new GlobalProperties(context)
		this.soapuiObject = new SoapuiObject(context)
		this.segChecker = new DmSegFileConsistencyChecker()
		this.dmIp = globalProperties.getDmIp()
		this.dmUser = globalProperties.getDmUser()
		this.dmPass = globalProperties.getDmPass()
		this.dmHome = globalProperties.getDmHome()
		this.segDir = globalProperties.getDmSegDir()
		String shellDir = globalProperties.getSubtoolDir()
		this.sshShell = "${shellDir}/common_tools/exec_ssh_cmd_automatically_input_pass.sh"
		this.testName = testName
		this.DM_SEG_DIR = segDir
	}


	def getDBTime(){
		def sqlExecuter = new SqlExecutorFactory(soapuiObject.getContext()).create()
		return sqlExecuter.getSqlResultOneRecord("select to_char(systimestamp, 'HH24:MI:SS') from dual")
	}

	def startJBoss() {
                String startCmd = "cd ${dmHome};  nohup bin/standalone.sh -c standalone-full.xml -bmanagement 0.0.0.0 -b 0.0.0.0 >> nohup.out 2>&1 < /dev/null &"
                executeDmShell(startCmd)
        }

	def stopJBoss() {
		String stopShellPath = globalProperties.getSubtoolDir() + "/aim/tools/xStopWildFly.sh"
		List args = [ stopShellPath, "${dmUser}@${dmIp}:${dmHome}" , dmPass ]
		new LinuxCommander().doShWithArgs(scpShell, args)
		String stopCmd = "cd ${dmHome}; ./xStopWildFly.sh"
		executeDmShell(stopCmd)
	}
	
	def deleteSegments() {
		String shellCmd = "rm -f ${segDir}/*"
		executeDmShell(shellCmd)
	}

	def deleteIndex() {
		String shellCmd = "rm -f ${segDir}/.*.index"
		executeDmShell(shellCmd)
	}

	def killDMProcess(){
		String shellCmd = "pkill -9 -f '${dmHome}'"
		executeDmShell(shellCmd)
	}

	def executeDmShell(String command) {
		List args = [ dmUser, dmIp, command, dmPass ]
		return new LinuxCommander().doShWithArgs(sshShell, args)
	}


	def segCheck(){
		def dbIp = globalProperties.getDBIP()
		def dbPort = globalProperties.getDBPort()
		def dbUser = globalProperties.getDBUser()
		def dbPass = globalProperties.getDBPass()
		def dbSid  = globalProperties.getDBSID()
		def segDirRoot = new File(DM_SEG_DIR)
		segDirRoot.eachFileRecurse{ segPath ->
			if ( segPath.file && segPath.name =~ /.*\.seg/ ) {
				initializeSegChecker()
 				segChecker.check(dbIp, dbPort, dbUser, dbPass, dbSid, segPath as String)
 				println segChecker.isValid()
				if(!segChecker.isValid()){
					 abendTest(segChecker.getErrDetail())
				}
 			}
		}
	}

	def checkBioId(){
		def dbIp = globalProperties.getDBIP()
		def dbPort = globalProperties.getDBPort()
		def dbUser = globalProperties.getDBUser()
		def dbPass = globalProperties.getDBPass()
		def dbSid  = globalProperties.getDBSID()
		def segDirRoot = new File(DM_SEG_DIR)
		segDirRoot.eachFileRecurse{ segPath ->
			if ( segPath.file && segPath.name =~ /.*\.seg/ ) {
				initializeSegChecker()
 				segChecker.checkBioId(dbIp, dbPort, dbUser, dbPass, dbSid, segPath as String)
 				if(!segChecker.isValid()){
					 abendTest(segChecker.getErrDetail())
				}
 			}
		}
	}
	
	def initializeSegChecker(){
		segChecker.setErrDetail(new StringBuilder())
		segChecker.setValid(true)
	}

	private abendTest(String errMessg) {
        AbendProcessor abendProcessor = new AbendProcessor(soapuiObject.getContext())
        abendProcessor.abendTest(testName, errMessg)
    }

	def void scpDMSegmentsToHere(){
		new File(DM_SEG_DIR).mkdir()
		List args = ["${dmUser}@${dmIp}:${segDir}/.*", DM_SEG_DIR , dmPass ]
		new LinuxCommander().doShWithArgs(scpShell, args)
	}
	
	public void changePidDmProperty(String key, String value) {
		String propFileName = "pid.dm.properties"
		String cmd = "cd ${dmHome}/server/default/conf; mv ${propFileName} ${propFileName}.tmp; sed -e 's/^${key}=.*./${key}=${value}/g' ${propFileName}.tmp > ${propFileName}; rm -f ${propFileName}.tmp"
		executeDmShell(cmd)
	}
	
}


		
