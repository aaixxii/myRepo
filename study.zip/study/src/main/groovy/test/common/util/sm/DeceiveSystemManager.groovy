package test.common.util.sm

import common.os.linux.*


class DeceiveSystemManager{
	private static final WGET = "wget"
	private static final WGET_OPTION = "--quiet --output-document /dev/null --timeout 10 --tries 1 --post-file"
	private static final FE_JOB_DONE_URL_PATH = "systemmanager/MMExtractJobQueueHttpListener"
	private static final JOB_DONE_URL_PATH = "systemmanager/MMJobQueueHttpListener"
	private static final JOB_DONE = "jobdone"
	private static final FE_JOB_DONE = "fejobdone"

	
	DeceiveSystemManager(){}

	public sendStatisticsReport(smIp,smPort){
		def url = new URL("http://${smIp}:${smPort}/systemmanager/MMJobQueueHttpListener")
		//def postData = """113,1,1,2,10,10,true,2013/10/22 12:48:32.252,2013/10/22 12:48:28.831,false,false,100,1000,0,true,false,5.2,2000,\n"""
		def postData = "/home/soapui/work/amrSet/jobdone.log.aaaa"
        doWget(url,postData)
    }

	public sendJobDoneStatisticsReport(def smUrl, def functionType, def date, def rangeType){
		createJobDoneStatisticsReport()	
	}
	
	public sendJobDoneStatisticsReport(def smUrl){
		def type = "jobdone"
		def filePath = createJobDoneStatisticsReport()
		print filePath
		doWget(smUrl, type, filePath)
	}

	public createJobDoneStatisticsReport(def functionType, def date, def rangeType){
		def req = "1,1,1,2,10,10,true,2013/10/22 12:48:32.252,2013/10/22 12:48:28.831,false,false,100,1000,0,true,false,5.2,2000,"
		def fileName = "jobdone.log.TI_1_3M"
		def filePath = "/home/soapui/tmp/${fileName}"
		new File(filePath).write(req)
		return filePath
	}

	public createJobDoneStatisticsReport(){
		def req = "113,1,1,2,10,10,true,2013/10/22 12:48:32.252,2013/10/22 12:48:28.831,false,false,100,1000,0,true,false,5.2,2000,"
		def fileName = "jobdone.log.tmp"
		def filePath = "/home/soapui/tmp/${fileName}"
		new File(filePath).write(req)
		return filePath
	}
	
	public doWget(def smUrl,def type, def file){
		def url = generateSmUrl(smUrl, type)
		def cmd = "$WGET $WGET_OPTION $file $url"
		new  LinuxCommander().doCommand(cmd)
	}

	private generateSmUrl(def smUrl, def type){
		if (type == "fejobdone"){
			return smUrl + FE_JOB_DONE_URL_PATH
		}else if ( type == "jobdone"){
			return smUrl + JOB_DONE_URL_PATH
		}
	}
}
