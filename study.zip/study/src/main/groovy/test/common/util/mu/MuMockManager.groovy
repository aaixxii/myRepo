package test.common.util.mu

import test.degrade.properties.*

class MuMockManager {
	GlobalProperties globalProperties
	String serviceEndpoint
	String muIp
	static List<MuMock> muMockList
	
	def MuMockManager(context){
		this.globalProperties = new GlobalProperties(context)
		this.serviceEndpoint = globalProperties.getServiceEndpoint()
        this.muIp = globalProperties.getMuIp()
	}

	public void initMuMocks(int num){
		def port = 10000
		this.muMockList = new ArrayList<MuMock>()
		for(i in 1..num){
			MuMock mock = new MuMock(serviceEndpoint, muIp, port+i) 
			muMockList << mock
		}
	}

	public void enterMuMocks(){
		for(MuMock mock in muMockList){
			mock.enter()
		}
	}

	public void enterMuMocks(int num){
		for(i in 0..num-1){
			muMockList[i].enter()
		}
	}

	public void exitMuMocks(){
		for(MuMock mock in muMockList){
			mock.exit()
		}
	}	
	
	public void exitMuMocks(int num){
		for(i in 0..num-1){
			muMockList[i].exit()
		}
	}
}
