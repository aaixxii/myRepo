package test.common.util.db

import common.sql.*
import test.common.runner.*
import test.degrade.util.*

class ClearJobQueue{
	SqlExecutor sqlExecutor

	ClearJobQueue(context){
		this.sqlExecutor = new SqlExecutorFactory(context).create()
	}

	def deleteJobQueue(){
		sqlExecutor.sqlExecute("delete from job_queue")
		sqlExecutor.commit()
	}

	def deleteFeJobQueue(){
		sqlExecutor.sqlExecute("delete from fe_job_queue")
		sqlExecutor.commit()
	}
}
