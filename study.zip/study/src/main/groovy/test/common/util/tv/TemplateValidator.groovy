package test.common.util.tv

import java.util.regex.*
import test.common.util.db.*
import test.degrade.util.*
import test.degrade.properties.*
import common.os.linux.*
import common.sql.*
import test.common.util.mm.*
import static test.common.constants.aim.AIMWord.*

class TemplateValidator{
	def globalProperties
	def soapuiObject
	String tvIp
	String tvUser
	String tvPass
	String tvHome
	String sshShell
	String scpShell
	SqlExecutor sqlExecutor
	Map tvConfigMap
	private static final String TV_CONF_SECTION_MAP_KEY = "sectionMap"

	TemplateValidator(context){
		this.globalProperties = new GlobalProperties(context)
		this.soapuiObject = new SoapuiObject(context)
		this.tvIp = globalProperties.getTvIp()
		this.tvUser = globalProperties.getTvUser()
		this.tvPass = globalProperties.getTvPass()
		this.tvHome = globalProperties.getTvHome()
		String shellDir = globalProperties.getSubtoolDir()
		this.sshShell = "${shellDir}/common_tools/exec_ssh_cmd_automatically_input_pass.sh"
		this.scpShell = "${shellDir}/common_tools/exec_scp_cmd_automatically_input_pass.sh"
		this.sqlExecutor = new SqlExecutorFactory(context).create()
		this.tvConfigMap = setTvConfigMap()
	}

	def startTV() {
		String startCmd = "./runTV.sh"
		executeTvShell(startCmd)
	}
	
	def startTV(int sleepTime) {
		startTV()
		sleep sleepTime
	}

	def stopTV() {
		String stopCmd = "./stopTV.sh"
		executeTvShell(stopCmd)
	}
	
	def stopTV(int sleepTime) {
		stopTV()
		sleep sleepTime	
	}

	def rebootTV(){
		stopTV(5000)
		startTV(5000)
	}
	
	def executeTvShell(String command) {
		List args = [ tvUser, tvIp, command, tvPass ]
		return new LinuxCommander().doShWithArgs(sshShell, args)
	}
	
	def Map setTvConfigMap(){
        File tvConfig = getTvConfig()
        Map map = new HashMap()
        def pattern = Pattern.compile("=..*")
        tvConfig.eachLine{
            def line = it as String
            if(pattern.matcher(line).find()){
                def strTokenizer = new StringTokenizer(line, "=")
                def String key = strTokenizer.nextToken()
                def String value = strTokenizer.nextToken()
                map << [ ("${key}" as String):("${value}" as String) ]
            }
        }
        tvConfig.delete()
        return map
    }

	def getTvConfig() {
        scpTvConfigToCurrentDir()
        return new File("./TvConfig")
    }

	public String getTvConfigValue(String key){
        return tvConfigMap[key]
    }

	def void scpTvConfigToCurrentDir(){
        List args = [ "${tvUser}@${tvIp}:${tvHome}/config/TvConfig", ".", tvPass ]
        new LinuxCommander().doShWithArgs(scpShell, args)
    }

	def changeToPZIP() {
        String cmd = "cd ${tvHome}/config; mv TvConfig TvConfig.tmp.1; sed -e 's/Palm=FMATCHPW/Palm=PAMAT/g' TvConfig.tmp.1 > TvConfig; rm -f TvConfig.tmp.*"
        executeTvShell(cmd)
    }

    def changeToPC3R() {
        String cmd = "cd ${tvHome}/config; mv TvConfig TvConfig.tmp.1; sed -e 's/Palm=PAMAT/Palm=FMATCHPW/g' TvConfig.tmp.1 > TvConfig; rm -f TvConfig.tmp.*"
        executeTvShell(cmd)
    }

    def changeToS14() {
        String cmd = "cd ${tvHome}/config; mv TvConfig TvConfig.tmp.1; sed -e 's/Face=S17/Face=S14/g' TvConfig.tmp.1 > TvConfig; rm -f TvConfig.tmp.*"
        executeTvShell(cmd)
    }

    def changeToS17() {
        String cmd = "cd ${tvHome}/config; mv TvConfig TvConfig.tmp.1; sed -e 's/Face=S14/Face=S17/g' TvConfig.tmp.1 > TvConfig; rm -f TvConfig.tmp.*"
        executeTvShell(cmd)
    }
	
	 def changeTvConfig(String param, String value) {
        String cmd = "cd ${tvHome}/config; mv TvConfig TvConfig.tmp; sed -e 's/^${param}=.*./${param}=${value}/g' TvConfig.tmp > TvConfig; rm -f TvConfig.tmp"
        executeTvShell(cmd)
    }

	public void updateTvConfigValue(String section, String key, String value){
        updateTvConfigValue(section, key, value, true)
    }

    public boolean updateTvConfigValue(String section, String key, String value, boolean needReboot){
        def muConfKeyVal = muConfigMap[TV_CONF_SECTION_MAP_KEY][section]
        assert (muConfKeyVal != null && muConfKeyVal[key] != null),
            "There are no parameter '${key}' of section '${section}' in TvConfig. Couldn't update TvConfig."

        if(muConfKeyVal[key] == value) {
            soapuiObj.log("${section}/${key} is already ${value}. Nothing to do.")
            return false
        }

        soapuiObj.log("Updating ${section}/${key} to ${value}...")
        muConfKeyVal[key] = value
        mkTvConfFromMem()
        scpMuConfigFromCurrentDir()
        if(needReboot) {
            reboot()
        }else{
            soapuiObj.log("Reboot flag is false. Skip rebooting MU...")
        }
        return true
    }

    def mkTvConfFromMem() {
        File tvConfig = new File("./TvConfig")
        tvConfig.write("")
        def tvConfSectioMap = muConfigMap[TV_CONF_SECTION_MAP_KEY]
        for(keyVal in tvConfSectioMap) {
            def section = keyVal.key
            def paramMap = keyVal.value
            tvConfig.append("[${section}]\n")
            for(paramKeyVal in paramMap) {
                def paramKey = paramKeyVal.key
                def paramVal = paramKeyVal.value
                tvConfig.append("${paramKey}=${paramVal}\n")
            }
            tvConfig.append("\n")
        }
    }

    public String getTvConfigValue(String section, String key){
        return tvConfigMap[TV_CONF_SECTION_MAP_KEY][section][key]
    }

    public Map getTvConfigSectionValueMap(String section){
        return tvConfigMap[TV_CONF_SECTION_MAP_KEY][section]
    }

    public Set getTvConfigSections() {
        return tvConfigMap[TV_CONF_SECTION_MAP_KEY].keySet()
    }

}


		
