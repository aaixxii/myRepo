package test.common.util.mm

import test.common.util.db.*
import test.degrade.util.*
import test.degrade.properties.*
import common.util.*


class DeceiveMatchManager{
	
	def globalProperties
	def sqlExecuter
	def soapuiObject
	def jdbcTemplate
	String mmIp
	String mmUser
	String mmPass
	String mmHome

	DeceiveMatchManager(context){
		this.globalProperties = new GlobalProperties(context)
		this.soapuiObject = new SoapuiObject(context)
		this.sqlExecuter = new SqlExecutorFactory(context).create()
		this.jdbcTemplate  =new JdbcTemplateFactory(context).create()
		this.mmIp = globalProperties.getMmIp()
		this.mmUser = globalProperties.getMmUser()
		this.mmPass = globalProperties.getMmPass()
		this.mmHome = globalProperties.getMmHome()
	}


	def insertDummySegRecs(def conId, def numRecord){
		String insertSql = ""
		int segId = fetchNextSegId() 
        int bioIdStart = fetchNextBioId()
        int bioIdEnd = fetchNextBioId() + 100
		for ( i in 1..numRecord ){
			def sql = insertDummySegRec(segId, conId, bioIdStart, bioIdEnd)
			insertSql += sql
			segId += 1
			bioIdStart = bioIdEnd + 1
			bioIdEnd = bioIdStart + 100
		}
		insertAllUseJdbcTemp(insertSql)
	}
	
	def insertDummySegRec(int segId, int conId, int bioIdStart, int bioIdEnd){
		def sql = """
				 into 
					segments (
						SEGMENT_ID,
						CONTAINER_ID,
						BIO_ID_START,
						BIO_ID_END,
						BINARY_LENGTH_COMPACTED,
						RECORD_COUNT,
						VERSION,
						REVISION,
						BINARY_LENGTH_UNCOMPACTED
					) values (
						${segId},
						${conId},
						${bioIdStart},
						${bioIdEnd},
						26,
						1000,
						1,
						1,
						10000
					) """
		return sql
	}
	
	def insertDummyMuSegReports(){
		def deleteSql="delete from mu_seg_reports"
		def insertSql="""
				insert into 
					mu_seg_reports(
					mu_id,
					segment_id,
					status,
					segment_version,
					segment_queued_version
				) select 
					mu_id,
					segment_id,
					1,
					1,
					1 
				from mu_segments"""
		sqlExecuter.sqlExecute(deleteSql)
		sqlExecuter.sqlExecute(insertSql)
		sqlExecuter.commit()
	}

	def insertDummyJobQueueRecs(def numRecords){
		if ( numRecords == 0 ){
			return
		}
		List recList = []
		if ( numRecords > 100){
			for(i in 1..100){
				recList << numRecords.intdiv(100)
			}
			if ( numRecords%100 != 0){
				recList << numRecords%100
			}
		}else {
			recList << numRecords
		}
		int jobId = fetchNextJobId()
		for ( numRec in recList){
			String insertSql = ""
			for ( j in 1..numRec ){
				def sql = insertDummyJobQueueRec(jobId)
				insertSql += sql
				jobId += 1
			}
			insertAllUseJdbcTemp(insertSql)
		}
		reCreateJobQueueSeq()
	}

	def insertDummyJobQueueRec(int jobId){
		def sql = """
				into 
					job_queue (
						JOB_ID,
						PRIORITY,
						JOB_STATE,
						SUBMISSION_TS,
						PAUSED_FLAG,
						MIN_SCORE,
						TIMEOUTS,
						FAILURE_COUNT,
						REMAIN_JOBS
					) values (
						${jobId},
						7,
						2,
						systimestamp,
						0,
						200,
						-1,
						0,
						0
					) """
		return sql
	}
	
	def updateJobQueueJobStateExistMuJobs(){
		def aimdb =  new AimdbHandler(soapuiObject.getContext())
		def jobIdList = aimdb.getJobIdExistMuJobsAndNonStateIsDone()
		if (jobIdList.size() == 0){
			return
		}
		String convJobIdList = ""
		for (id in jobIdList){
			convJobIdList += id + ","
		}
		convJobIdList = convJobIdList.substring(0, convJobIdList.length()-1);
		String sql = "update job_queue set job_state = 2 where job_id in (${convJobIdList}) and job_state != 2"
		sqlExecuter.sqlExecute(sql)
		sqlExecuter.commit()
	}
	
	def fetchNextSegId(){
		def aimdb =  new AimdbHandler(soapuiObject.getContext())
		def maxSegId = Convertor.toZeroIfNull(aimdb.getMaxSegId())
		def segmentId = maxSegId + 1
		return segmentId
	}

	def fetchSegSetId(def binId){
		def aimdb =  new AimdbHandler(soapuiObject.getContext())
		return aimdb.getSegSetId(binId)
	}

	def fetchNextBioId(){
		def aimdb =  new AimdbHandler(soapuiObject.getContext())
		def bioIdRoot = Convertor.toZeroIfNull(aimdb.getMaxBioIdEnd())
		return bioIdRoot + 1
	}
	
	def fetchNextJobId(){
		def aimdb =  new AimdbHandler(soapuiObject.getContext())
		def jobIdRoot = Convertor.toZeroIfNull(aimdb.getMaxJobId())
		return jobIdRoot + 1
	}
	
	
	def insertAll(String sql){
		String insertSql = "insert all "
		insertSql += sql
		insertSql += "select * from dual"
		sqlExecuter.sqlExecute(insertSql)
		sqlExecuter.sqlExecute("commit")
	}
	
	def insertAllUseJdbcTemp(String sql){
		String insertSql = "insert all "
		insertSql += sql
		insertSql += "select * from dual"
		jdbcTemplate.batchUpdate(insertSql)
	}

	def reCreateJobQueueSeq(){
		reCreateJobQueueSeq(fetchNextJobId())
	}
	
	def reCreateJobQueueSeq(startNum){
		def aimdb =  new AimdbHandler(soapuiObject.getContext())
		aimdb.dropSeq("JOB_QUEUE_SEQ")
		aimdb.createJobQueueSeq(startNum)
	}
	
	def reCreatePbSeq(startNum){
		def aimdb =  new AimdbHandler(soapuiObject.getContext())
		aimdb.dropSeq("PERSON_BIOMETRIC_SEQ")
		aimdb.createPbSeq(startNum)
	}
}
