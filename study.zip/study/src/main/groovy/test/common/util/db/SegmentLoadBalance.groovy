package test.common.util.db

import common.sql.*
import test.common.runner.*
import test.degrade.util.*
import test.common.util.mu.*

class SegmentLoadBalance{
	SqlExecutor sqlExecutor
	MatchUnit mu

	SegmentLoadBalance(context){
		this.sqlExecutor = new SqlExecutorFactory(context).create()
		this.mu = new MatchUnit(context)
	}

	def initializeSlb(){
		mu.muAgentStop()
		sqlExecutor.sqlExecute("DELETE FROM CONTAINER_JOBS")
		sqlExecutor.sqlExecute("DELETE FROM SEGMENTS")
		sqlExecutor.sqlExecute("DELETE FROM MATCH_UNITS")
		sqlExecutor.sqlExecute("DELETE FROM MU_SEG_REPORTS")
		sqlExecutor.sqlExecute("DELETE FROM MU_SEGMENTS")
		sqlExecutor.commit()
		resetSlbIntervals()
        mu.muAgentStart()
	}

	def _initializeSlb(){
        	mu.muAgentStop()
        	sqlExecutor.sqlExecute("DELETE FROM SEGMENT_JOBS")
        	sqlExecutor.sqlExecute("DELETE FROM SEGMENTS")
        	sqlExecutor.sqlExecute("DELETE FROM MU_SEG_REPORTS")
        	sqlExecutor.sqlExecute("DELETE FROM MU_SEGMENTS")
        	sqlExecutor.sqlExecute("DELETE FROM APPOINTED_MU_SEGMENTS")
        	sqlExecutor.sqlExecute("DELETE FROM PERSON_BIOMETRICS")
        	sqlExecutor.commit()
        	mu.deleteSegments()
        	mu.muAgentStart()
    }

	def setSlbOn(){
		sqlExecutor.sqlExecute("UPDATE SYSTEM_CONFIG SET PROPERTY_VALUE ='true' WHERE PROPERTY_NAME='LOAD_BALANCER.ENABLED'")
		sqlExecutor.commit()
	}

	def setSlbOff(){
		sqlExecutor.sqlExecute("UPDATE SYSTEM_CONFIG SET PROPERTY_VALUE ='false' WHERE PROPERTY_NAME='LOAD_BALANCER.ENABLED'")
		sqlExecutor.commit()
	}

	def setSlbIntervals(interval){
		sqlExecutor.sqlExecute("UPDATE SYSTEM_CONFIG SET PROPERTY_VALUE = ${interval} WHERE PROPERTY_NAME='INTERVALS.LOAD_BALANCING'")
		sqlExecutor.commit()
	}

	def resetSlbIntervals(){
		sqlExecutor.sqlExecute("UPDATE SYSTEM_CONFIG SET PROPERTY_VALUE = 60000 WHERE PROPERTY_NAME='INTERVALS.LOAD_BALANCING'")
		sqlExecutor.commit()
	}

	def setRedunduncy(redunduncy){
		sqlExecutor.sqlExecute("UPDATE SYSTEM_CONFIG SET PROPERTY_VALUE = ${redunduncy} WHERE PROPERTY_NAME='LOAD_BALANCER.DEFAULT_MIN_REDUNDANCY'")
		sqlExecutor.commit()
	}

	def setDmRedunduncy(redunduncy){
		setMinDms(redunduncy)
	}

	def setMinMus(minMus){
		sqlExecutor.sqlExecute("UPDATE SYSTEM_CONFIG SET PROPERTY_VALUE = ${minMus} WHERE PROPERTY_NAME='LOAD_BALANCER.MIN_MUS_FOR_SLB'")
		sqlExecutor.commit()
	}

	def setMinDms(numDms){
		sqlExecutor.sqlExecute("UPDATE SYSTEM_CONFIG SET PROPERTY_VALUE = ${numDms} WHERE PROPERTY_NAME='LOAD_BALANCER.DEFAULT_DM_MIN_REDUNDANCY'")
		sqlExecutor.commit()
	}

	def setReportTimerOff(){
		sqlExecutor.sqlExecute("UPDATE SYSTEM_CONFIG SET PROPERTY_VALUE = -1 WHERE PROPERTY_NAME='TIMEOUTS.HEARTBEAT_MESSAGE'")
		sqlExecutor.sqlExecute("UPDATE SYSTEM_CONFIG SET PROPERTY_VALUE = -1 WHERE PROPERTY_NAME='TIMEOUTS.REPORT_MESSAGE'")
		sqlExecutor.sqlExecute("UPDATE SYSTEM_CONFIG SET PROPERTY_VALUE = -1 WHERE PROPERTY_NAME='HEARTBEAT_INTERVAL'")
		sqlExecutor.sqlExecute("UPDATE SYSTEM_CONFIG SET PROPERTY_VALUE = -1 WHERE PROPERTY_NAME='REPORT_INTERVAL'")
		sqlExecutor.commit()
	}

	def setReportTimerOn(){
		sqlExecutor.sqlExecute("UPDATE SYSTEM_CONFIG SET PROPERTY_VALUE = 60000 WHERE PROPERTY_NAME='TIMEOUTS.HEARTBEAT_MESSAGE'")
		sqlExecutor.sqlExecute("UPDATE SYSTEM_CONFIG SET PROPERTY_VALUE = 60000 WHERE PROPERTY_NAME='TIMEOUTS.REPORT_MESSAGE'")
		sqlExecutor.sqlExecute("UPDATE SYSTEM_CONFIG SET PROPERTY_VALUE = 30000 WHERE PROPERTY_NAME='HEARTBEAT_INTERVAL' and NAMESPACE = 'MU'")
		sqlExecutor.sqlExecute("UPDATE SYSTEM_CONFIG SET PROPERTY_VALUE = 60000 WHERE PROPERTY_NAME='REPORT_INTERVAL' and NAMESPACE = 'MU'")
		sqlExecutor.sqlExecute("UPDATE SYSTEM_CONFIG SET PROPERTY_VALUE = 30 WHERE PROPERTY_NAME='HEARTBEAT_INTERVAL'and NAMESPACE = 'SMS'")
		sqlExecutor.sqlExecute("UPDATE SYSTEM_CONFIG SET PROPERTY_VALUE = 60 WHERE PROPERTY_NAME='REPORT_INTERVAL'and NAMESPACE = 'SMS'")
		sqlExecutor.commit()
	}

	def setAppointedMuSegments(mu_id, segment_id){
		sqlExecutor.sqlExecute("INSERT INTO APPOINTED_MU_SEGMENTS(MU_ID, SEGMENT_ID) VALUES( ${mu_id},${segment_id} )")
		sqlExecutor.commit()
	}

    def getWorkingMuId(numMus){
		return sqlExecutor.getSqlResult("select mu_id from match_units where rownum <= ${numMus} and type = 0 and state = 'WORKING'")
	}

    def getAllWorkingMuId(){
		return sqlExecutor.getSqlResult("select mu_id from match_units where type = 0 and state = 'WORKING' order by 1")
	}

    def getNoWorkingMuId(){
		return sqlExecutor.getSqlResult("select mu_id from match_units where type = 0 and not state = 'WORKING'")
	}

	def getWorkingDmId(numMus){
		return sqlExecutor.getSqlResult("select mu_id from match_units where rownum <= ${numMus} and type = 2 and state = 'WORKING'")
	}

	def getAllWorkingDmId(){
		return sqlExecutor.getSqlResult("select mu_id from match_units where type = 2 and state = 'WORKING' order by 1")
	}

	def getNoWorkingDmId(){
		return sqlExecutor.getSqlResult("select mu_id from match_units where type = 2 and not state = 'WORKING'")
	}

    def gethasSegments(muId){
		return sqlExecutor.getSqlResult("select mu_id, segment_id from mu_segments where mu_id = ${muId}")
	}
    
	def getSegments(){
		return sqlExecutor.getSqlResult("select * from segments")
	}

	def killMus(muId){
		sqlExecutor.sqlExecute("UPDATE MATCH_UNITS SET STATE = 'TIMED_OUT' WHERE MU_ID = ${muId}")
		sqlExecutor.commit()
	}

}
