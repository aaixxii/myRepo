package test.common.util.db

import test.lsm.config.*
import test.degrade.properties.*
import common.sql.*
import common.os.linux.*
import groovy.sql.Sql
import java.sql.*

class ReSegmenter{
	def globalProperties
	def jdbcTemplate
	def sqlExecuter

	ReSegmenter(context){
		this.jdbcTemplate = new JdbcTemplateFactory(context).create()
		this.sqlExecuter = new SqlExecutorFactory(context).create()
	}

	public def reSeg(int containerId, int maxSegSize){
		String plSql = """
DECLARE
	P_CONTAINER_ID NUMBER;
	P_SEGMENT_SIZE NUMBER;
BEGIN	
	P_CONTAINER_ID := ${containerId};
	P_SEGMENT_SIZE := ${maxSegSize};
	MATCH_MANAGER_API.CREATE_SEGMENTS(
		P_CONTAINER_ID,
		P_SEGMENT_SIZE
	);
END;"""
		sqlExecuter.sqlExecute(plSql)
	}

	public def reSegAll(int maxSegSize){
		String plSql = """
DECLARE
	P_SEGMENT_SIZE NUMBER;
BEGIN
	P_SEGMENT_SIZE := ${maxSegSize};
	FOR c IN (SELECT container_id FROM containers)
	LOOP
		MATCH_MANAGER_API.CREATE_SEGMENTS(
			c.container_id,
			P_SEGMENT_SIZE
		);
	END LOOP;
END;
"""
		sqlExecuter.sqlExecute(plSql)
	}
}
