package test.common.runner

import common.util.http.HttpRequestSender;

import org.apache.http.HttpEntity
import org.apache.http.HttpResponse
import org.apache.http.client.ClientProtocolException
import org.apache.commons.io.IOUtils
import org.slf4j.Logger
import org.slf4j.LoggerFactory

class GetBinaryExecutor implements AimFuncExecutorIF {
	
	private static final String XML_1ST = """
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ws="http://ws.mm.nhm.nec.co.jp/">
   <soapenv:Header/>
   <soapenv:Body>
      <ws:getExtractJobBinary>
"""
	private static final String XML_2ND = """
      </ws:getExtractJobBinary>
   </soapenv:Body>
</soapenv:Envelope>
"""
	private final static Logger log = LoggerFactory.getLogger(GetBinaryExecutor.class)
	private String serviceEndPoint
	
	public GetBinaryExecutor(String serviceEndPoint){
		this.serviceEndPoint = serviceEndPoint
	}
	
	public execute(){
		
	}
	
	public String execute(String jobId, String key) {
		String reqXml = makeReqXml(jobId, key)
		String templateB64 = execGetBinary(reqXml)
		return templateB64
	}

	private String execGetBinary(String reqXml) {
		String templateB64 = send(serviceEndPoint, reqXml)
		return templateB64
	}

	private String makeReqXml(String jobId, String key) {
		StringBuilder sb = new StringBuilder(XML_1ST)
		sb.append("<jobId>${jobId}</jobId>")
		sb.append("<key>${key}</key>")
		sb.append(XML_2ND)
		String reqXml = sb.toString()
		return reqXml
	}
	
	private String send(String endpointURL, String reqXml)
		throws ClientProtocolException, IOException{
		HttpResponse res = HttpRequestSender.send(endpointURL, reqXml);
		String resXml = IOUtils.toString( res.getEntity().getContent())
		if(resXml.indexOf("fault") != -1){
			assert false, resXml
		}
		Node root = new XmlParser().parseText(resXml)
		return root."soap:Body"."ns3:getExtractJobBinaryResponse"."return".text()
	}
}

