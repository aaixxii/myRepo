package test.common.runner

import com.eviware.soapui.support.types.StringToObjectMap
import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCaseRunner

class TestCaseExecutor {
	def testCase
	def testStep

	TestCaseExecutor(testCase){
		this.testCase = testCase
	}

	TestCaseExecutor(testCase, testStep){
		this.testCase = testCase
		this.testStep = testStep
	}

    def setupTestStep(propertiesMap)  {
		propertiesMap.each{
			this.testStep.setPropertyValue(it.key, it.value as String)
		}
	}

    def setupTestStep(testStep, propertiesMap)  {
		propertiesMap.each{
			testStep.setPropertyValue(it.key, it.value as String)
		}
	}

	def runTestCase() {
		return this.testCase.run(new StringToObjectMap(), false)
	}
}
