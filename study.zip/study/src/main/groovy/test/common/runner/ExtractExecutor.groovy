package test.common.runner

import jp.co.nec.nhm.soapui.util.NistReader
import common.util.http.HttpRequestSender;

import org.apache.http.HttpEntity
import org.apache.http.HttpResponse
import org.apache.http.client.ClientProtocolException
import org.apache.commons.io.IOUtils
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import test.degrade.util.SoapuiObject
import test.duration.queue.ExtractJobInfoQueue

class ExtractExecutor implements AimFuncExecutorIF {
	
	private static final String XML_1ST = """
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ws="http://ws.mm.nhm.nec.co.jp/">
   <soapenv:Header/>
   <soapenv:Body>
      <ws:extract>
         <extractionInputs>
            <priority>4</priority>
"""
	private static final String XML_2ND = """
 <extraction-inputs-payload>
    <ext-input>
"""
	
	private static final String XML_3RD = """
            <aimformats>
                <fmt>19</fmt>
                <fmt>26</fmt>
                <fmt>35</fmt>
            </aimformats>
       	  <fe-types>
			<xdbl>
				<rolled>
					<pc2 fe-type="B"/>
					<fmp5 fe-type="B"/>
				</rolled>
				<slap>
					<pc2 fe-type="B"/>
					<fmp5 fe-type="B"/>
				</slap>
			</xdbl>
		  </fe-types>
"""
	private static final String XML_4TH = """
            <meta-info>
                <meta-common gender="U" yob="-1" yobRange="-1" race="-1" region="U"/>
                <meta-tenprint primaryPatterns="SSSSSSSSSS" referencePatterns="UUUUUUUUUU"/>
            </meta-info>

			<cmlaf-ext-options multiplicity="2">
				<template-param fetype="9" limitofminutiacount="30" templatenum="1">
                	<enhancements>
                		<enh-type>5</enh-type>
                	</enhancements>
               	</template-param>
       			<template-param fetype="3" limitofminutiacount="63" templatenum="2">
                	<enhancements>
                		<enh-type>0</enh-type>
                		<enh-type>3</enh-type>
                		<enh-type>8</enh-type>
                	</enhancements>
				</template-param>
			</cmlaf-ext-options>
			<enhancements>
				<card-enh min-fingers="1" max-fingers="10" min-qual="0" max-qual="800">
					<enhancements>
						<image-enhance min-qual="0" max-qual="100">
							<enhancements>
								<enh-type>0</enh-type> 
								<enh-type>0</enh-type> 
								<enh-type>1</enh-type> 
								<enh-type>2</enh-type> 
							</enhancements>
						</image-enhance>
					</enhancements>
				</card-enh>
			</enhancements>
        </tenprint-input>
    </ext-input>
</extraction-inputs-payload>

         </extractionInputs>
      </ws:extract>
   </soapenv:Body>
</soapenv:Envelope>
"""
	private static final String IMG_URL_XML = """
              <image pos="1" type="1">
                <url>http://192.168.22.118:18080/nawata-bank/media/usb/aim_tests/AIM/testData/degradeTest/LI/nist/9/LIM_9_f1.L.wsq</url>
              </image>
              <image pos="2" type="1">
                <url>http://192.168.22.118:18080/nawata-bank/media/usb/aim_tests/AIM/testData/degradeTest/LI/nist/9/LIM_9_f2.L.wsq</url>
              </image>
              <image pos="3" type="1">
                <url>http://192.168.22.118:18080/nawata-bank/media/usb/aim_tests/AIM/testData/degradeTest/LI/nist/9/LIM_9_f3.L.wsq</url>
              </image>
              <image pos="4" type="1">
                <url>http://192.168.22.118:18080/nawata-bank/media/usb/aim_tests/AIM/testData/degradeTest/LI/nist/9/LIM_9_f4.L.wsq</url>
              </image>
              <image pos="5" type="1">
                <url>http://192.168.22.118:18080/nawata-bank/media/usb/aim_tests/AIM/testData/degradeTest/LI/nist/9/LIM_9_f5.L.wsq</url>
              </image>
              <image pos="6" type="1">
                <url>http://192.168.22.118:18080/nawata-bank/media/usb/aim_tests/AIM/testData/degradeTest/LI/nist/9/LIM_9_f6.L.wsq</url>
              </image>
              <image pos="7" type="1">
                <url>http://192.168.22.118:18080/nawata-bank/media/usb/aim_tests/AIM/testData/degradeTest/LI/nist/9/LIM_9_f7.L.wsq</url>
              </image>
              <image pos="8" type="1">
                <url>http://192.168.22.118:18080/nawata-bank/media/usb/aim_tests/AIM/testData/degradeTest/LI/nist/9/LIM_9_f8.L.wsq</url>
              </image>
              <image pos="9" type="1">
                <url>http://192.168.22.118:18080/nawata-bank/media/usb/aim_tests/AIM/testData/degradeTest/LI/nist/9/LIM_9_f9.L.wsq</url>
              </image>
              <image pos="10" type="1">
                <url>http://192.168.22.118:18080/nawata-bank/media/usb/aim_tests/AIM/testData/degradeTest/LI/nist/9/LIM_9_f10.L.wsq</url>
              </image>
              <image pos="11" type="1">
                <url>http://192.168.22.118:18080/nawata-bank/media/usb/aim_tests/AIM/testData/degradeTest/LI/nist/9/LIM_9_f11.L.wsq</url>
              </image>
              <image pos="12" type="1">
                <url>http://192.168.22.118:18080/nawata-bank/media/usb/aim_tests/AIM/testData/degradeTest/LI/nist/9/LIM_9_f12.L.wsq</url>
              </image>
              <image pos="13" type="1">
                <url>http://192.168.22.118:18080/nawata-bank/media/usb/aim_tests/AIM/testData/degradeTest/LI/nist/9/LIM_9_f13.L.wsq</url>
              </image>
              <image pos="14" type="1">
                <url>http://192.168.22.118:18080/nawata-bank/media/usb/aim_tests/AIM/testData/degradeTest/LI/nist/9/LIM_9_f14.L.wsq</url>
              </image>
              <image pos="21" type="1">
                <url>http://192.168.22.118:18080/nawata-bank/media/usb/aim_tests/AIM/testData/degradeTest/LIP/wsq/slice_LIP_2_TP/t15-1.wsq</url>
              </image>
              <image pos="22" type="1">
                <url>http://192.168.22.118:18080/nawata-bank/media/usb/aim_tests/AIM/testData/degradeTest/LIP/wsq/slice_LIP_2_TP/t15-2.wsq</url>
              </image>
              <image pos="23" type="1">
                <url>http://192.168.22.118:18080/nawata-bank/media/usb/aim_tests/AIM/testData/degradeTest/LIP/wsq/slice_LIP_2_TP/t15-3.wsq</url>
              </image>
              <image pos="24" type="1">
                <url>http://192.168.22.118:18080/nawata-bank/media/usb/aim_tests/AIM/testData/degradeTest/LIP/wsq/slice_LIP_2_TP/t15-4.wsq</url>
              </image>
"""

	private static String CALLBACK_URL = "callbackURL"
	private static String MM_IP_PORT = "MMURL"
	private static String EXT_INFO_MODE = "extInfoMode"
	private static String SLASH = "/"
	private static int totalExecNum = 0
	private String serviceEndPoint
	private String callbackUrl
	private String extInfoMode
	private SoapuiObject soapuiObj
	private boolean byUrlMode = false
	private final static Logger log = LoggerFactory.getLogger(ExtractExecutor.class)
	
	public ExtractExecutor(context, boolean byUrlMode){
		this(context)
		this.byUrlMode = byUrlMode
	}
	
	public ExtractExecutor(context){
		this.soapuiObj = new SoapuiObject(context)
		this.callbackUrl = soapuiObj.getProjectProperty(CALLBACK_URL);
		this.extInfoMode = soapuiObj.getProjectProperty(EXT_INFO_MODE);
		String mmIpPort = soapuiObj.getProjectProperty(MM_IP_PORT)
		this.serviceEndPoint = "http://${mmIpPort}/PIDWebServices/JobControlService"
	}
	
	public ExtractExecutor(String serviceEndPoint, String callbackUrl, boolean byUrlMode){
		this.serviceEndPoint = serviceEndPoint
		this.callbackUrl = callbackUrl
		this.byUrlMode = byUrlMode
	}
	
	public String execute() {
		totalExecNum++
		if(byUrlMode){
			log.info("Execute ${totalExecNum} times Extract by URL...")
			extractByUrl()
		}else{
			log.info("Execute ${totalExecNum} times Extract by Image...")
			extractByImg()
		}
	}

	private extractByImg() {
		String nistPath = getNextNistFilePath()
		String imgXml = readNistFile(nistPath)
		String jobId = execute(imgXml)
		log.info("${jobId} : ${nistPath}")
		queuedJobIdExternalId(nistPath, jobId)
	}

	public String extractByUrl() {
		String jobId = execute(IMG_URL_XML)
		queuedJobIdExternalId(totalExecNum as String, jobId)
	}

	private queuedJobIdExternalId(String nistPath, String jobId) {
		int index = nistPath.lastIndexOf(SLASH)
		String externalId = nistPath.substring(index+1)
		ExtractJobInfoQueue extractJobInfoQueue = ExtractJobInfoQueue.getInstance()
		extractJobInfoQueue.enqueueExternalId(jobId, externalId)
	}
	
	public String execute(String imgXml) {
		String reqXml = makeReqXml(imgXml)
		String jobId = execExtract(reqXml)
		return jobId
	}

	private String readNistFile(String nistPath) {
		NistReader reader = new NistReader(nistPath)
		StringBuilder sb = new StringBuilder()
		sb.append(reader.getFingerPrints())
		sb.append(reader.getPalms())
		String imgXml = sb.toString()
		return imgXml
	}

	private String execExtract(String reqXml) {
		String jobId = send(serviceEndPoint, reqXml)
		return jobId
	}

	private String makeReqXml(String imgXml) {
		StringBuilder sb = new StringBuilder(XML_1ST)
		sb.append("<callbackURL>${callbackUrl}/extractCallback</callbackURL>")
		sb.append(XML_2ND)
		sb.append("<tenprint-input ext-info-mode='${extInfoMode}'>")
		sb.append(XML_3RD)
		sb.append("<images>")
		sb.append(imgXml)
		sb.append("</images>")
		sb.append(XML_4TH)
		String reqXml = sb.toString()
		return reqXml
	}
	
	private String send(String endpointURL, String reqXml)
		throws ClientProtocolException, IOException{
		HttpResponse res = HttpRequestSender.send(endpointURL, reqXml);
		String resXml = IOUtils.toString( res.getEntity().getContent())
		if(resXml.indexOf("fault") != -1){
			assert false, resXml
		}
		Node root = new XmlParser().parseText(resXml)
		return root."soap:Body"."ns3:extractResponse"."return".text()
	}
		
	private String getNextNistFilePath(){
		ExtractJobInfoQueue extractJobInfoQueue = ExtractJobInfoQueue.getInstance()
		return extractJobInfoQueue.getNextNistFilePath()
	}
}

