package test.common.runner

interface AimFuncExecutorIF {
	
	public execute()
}

