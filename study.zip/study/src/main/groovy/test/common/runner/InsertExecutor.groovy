package test.common.runner

import common.util.http.HttpRequestSender;

import org.apache.http.HttpEntity
import org.apache.http.HttpResponse
import org.apache.http.client.ClientProtocolException
import org.apache.commons.io.IOUtils
import org.slf4j.Logger
import org.slf4j.LoggerFactory

class InsertExecutor implements AimFuncExecutorIF {
	
	private static final String XML_1ST = """
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ws="http://ws.mm.nhm.nec.co.jp/">
   <soapenv:Header/>
   <soapenv:Body>
      <ws:insert>
"""
	private static final String XML_2ND = """
      </ws:insert>
   </soapenv:Body>
</soapenv:Envelope>
"""
	private final static Logger log = LoggerFactory.getLogger(InsertExecutor.class)
	private String serviceEndPoint
	
	public InsertExecutor(String serviceEndPoint){
		this.serviceEndPoint = serviceEndPoint
	}
	
	public execute(){
		
	}
	
	public void execute(String externalId, int eventId, Map binIdTempalteMap) {
		String reqXml = makeReqXml(externalId, eventId, binIdTempalteMap)
		execInsert(reqXml)
	}

	private String execInsert(String reqXml) {
		send(serviceEndPoint, reqXml)
	}

	private String makeReqXml(String externalId, int eventId, Map binIdTemplateMap) {
		StringBuilder sb = new StringBuilder(XML_1ST)
        sb.append("<externalId>${externalId}</externalId>")
		sb.append("<eventId>${eventId}</eventId>")
		for(binId in binIdTemplateMap.keySet()){
			List templateList = binIdTemplateMap.get(binId)
			for(templateB64 in templateList){
				sb.append("<reqs destinationContainer='${binId}'>\n")
				sb.append("<record>\n")
				sb.append("<binary>\n")
				sb.append(templateB64)
				sb.append("</binary>\n")
				sb.append("</record>\n")
				sb.append("</reqs>\n")
			}
		}
		sb.append(XML_2ND)
		String reqXml = sb.toString()
		return reqXml
	}
	
	private void send(String endpointURL, String reqXml)
		throws ClientProtocolException, IOException{
		HttpResponse res = HttpRequestSender.send(endpointURL, reqXml);
		String resXml = IOUtils.toString( res.getEntity().getContent())
		if(resXml.indexOf("fault") != -1){
			assert false, resXml
		}
	}
}

