package test.duration.log

public class DurationLogger {
	private String header

	public DurationLogger(String functionName) {
		this.header = "[ ${functionName} ]"
	}

	public void info(messg) {
		println "${header} : ${messg}" 
	}

	public void info(String messg) {
		println "${header} : ${messg}" 
	}
}

