package test.duration.call

import jp.co.nec.lsm.util.HttpRequestSender

import test.degrade.util.*

/*******************************************
	This Class need bison-jobpusher.jar
********************************************/

class CallFiTestCase {
	static final String CALLBACK_PORT = "callbackPort"
	static final String EXTRACT_SERVLET_NAME = "FiCallback"
	String postUrl

	CallFiTestCase(SoapuiObject soapuiObject) {
		String callbackPort = soapuiObject.getProjectProperty(CALLBACK_PORT)
		this.postUrl = "http://localhost:${callbackPort}/${EXTRACT_SERVLET_NAME}"
	}

	def void call(){
		byte[] serealizedObj = new String("test").getBytes();
		HttpRequestSender.send(postUrl, serealizedObj)
	}
}

