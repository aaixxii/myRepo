package test.duration.queue

public class LatentPalmTemplateList {
	private static LatentPalmTemplateList instance

	private List lipTemplatePathList
	private List lrpTemplatePathList
	private List llipTemplatePathList
	private static lipTemplatePathIndex
	private static lrpTemplatePathIndex
	private static llipTemplatePathIndex

	private LatentPalmTemplateList() {
		this.lipTemplatePathIndex = 0
		this.lrpTemplatePathIndex = 0
		this.llipTemplatePathIndex = 0
	}

	public static synchronized LatentPalmTemplateList getInstance() {
		if (instance == null) {
			instance = new LatentPalmTemplateList()
		}
		return instance
	}

	public void setLipTemplatePathList(List lipTemplatePathList) {
		this.lipTemplatePathList = lipTemplatePathList
	}

	public void setLlipTemplatePathList(List llipTemplatePathList) {
		this.llipTemplatePathList = llipTemplatePathList
	}

	public void setLrpTemplatePathList(List lrpTemplatePathList) {
		this.lrpTemplatePathList = lrpTemplatePathList
	}

	public String getLipTemplatePath() {
		String templatePath = lipTemplatePathList[lipTemplatePathIndex]
		resetIndexIfOverLimitLip()
		return templatePath
	}

	public String getLlipTemplatePath() {
		String templatePath = llipTemplatePathList[llipTemplatePathIndex]
		resetIndexIfOverLimitLlip()
		return templatePath
	}

	public String getLrpTemplatePath() {
		String templatePath = lrpTemplatePathList[lrpTemplatePathIndex]
		resetIndexIfOverLimitLrp()
		return templatePath
	}

	private void resetIndexIfOverLimitLip(){
		if(lipTemplatePathIndex < lipTemplatePathList.size()-1){
			lipTemplatePathIndex++
		}else{
			lipTemplatePathIndex = 0
		}
	}

	private void resetIndexIfOverLimitLlip(){
		if(llipTemplatePathIndex < llipTemplatePathList.size()-1){
			llipTemplatePathIndex++
		}else{
			llipTemplatePathIndex = 0
		}
	}

	private void resetIndexIfOverLimitLrp(){
		if(lrpTemplatePathIndex < lrpTemplatePathList.size()-1){
			lrpTemplatePathIndex++
		}else{
			lrpTemplatePathIndex = 0
		}
	}
}

