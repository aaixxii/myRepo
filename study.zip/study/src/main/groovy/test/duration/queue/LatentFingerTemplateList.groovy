package test.duration.queue

public class LatentFingerTemplateList {
	private static LatentFingerTemplateList instance

	private List liTemplatePathList
	private List lrTemplatePathList
	private List lliTemplatePathList
	private static liTemplatePathIndex
	private static lrTemplatePathIndex
	private static lliTemplatePathIndex

	private LatentFingerTemplateList() {
		this.liTemplatePathIndex = 0
		this.lrTemplatePathIndex = 0
		this.lliTemplatePathIndex = 0
	}

	public static synchronized LatentFingerTemplateList getInstance() {
		if (instance == null) {
			instance = new LatentFingerTemplateList()
		}
		return instance
	}

	public void setLiTemplatePathList(List liTemplatePathList) {
		this.liTemplatePathList = liTemplatePathList
	}

	public void setLliTemplatePathList(List lliTemplatePathList) {
		this.lliTemplatePathList = lliTemplatePathList
	}

	public void setLrTemplatePathList(List lrTemplatePathList) {
		this.lrTemplatePathList = lrTemplatePathList
	}

	public String getLiTemplatePath() {
		String templatePath = liTemplatePathList[liTemplatePathIndex]
		resetIndexIfOverLimitLi()
		return templatePath
	}

	public String getLliTemplatePath() {
		String templatePath = lliTemplatePathList[lliTemplatePathIndex]
		resetIndexIfOverLimitLli()
		return templatePath
	}

	public String getLrTemplatePath() {
		String templatePath = lrTemplatePathList[lrTemplatePathIndex]
		resetIndexIfOverLimitLr()
		return templatePath
	}

	private void resetIndexIfOverLimitLi(){
		if(liTemplatePathIndex < liTemplatePathList.size()-1){
			liTemplatePathIndex++
		}else{
			liTemplatePathIndex = 0
		}
	}

	private void resetIndexIfOverLimitLli(){
		if(lliTemplatePathIndex < lliTemplatePathList.size()-1){
			lliTemplatePathIndex++
		}else{
			lliTemplatePathIndex = 0
		}
	}

	private void resetIndexIfOverLimitLr(){
		if(lrTemplatePathIndex < lrTemplatePathList.size()-1){
			lrTemplatePathIndex++
		}else{
			lrTemplatePathIndex = 0
		}
	}
}

