package test.duration.queue

import java.util.Collections
import java.util.Queue
import java.util.concurrent.ConcurrentLinkedQueue

public class ExtractJobInfoQueue {
	private static ExtractJobInfoQueue instance

	private Queue<String> extractResultQueue
	private Map<String, String> externalIdMap
	private List nistFilePathList
	private static nistFilePathIndex

	private ExtractJobInfoQueue() {
		this.extractResultQueue = new ConcurrentLinkedQueue<String>()
		this.externalIdMap = Collections.synchronizedMap( new HashMap<String, String>() )
		this.nistFilePathIndex = 0
	}

	public static synchronized ExtractJobInfoQueue getInstance() {
		if (instance == null) {
			instance = new ExtractJobInfoQueue()
		}
		return instance
	}

	public void setNistFilePathList(List nistFilePathList) {
		this.nistFilePathList = nistFilePathList
	}

	public void enqueue(String extractJobId) {
		extractResultQueue.add(extractJobId)
	}

	public boolean hasResult() {
		return !extractResultQueue.isEmpty()
	}

	public String dequeue() {
		if (!hasResult()) {
			return -1
		}
		return extractResultQueue.remove()
	}

	public void enqueueExternalId(String jobId, String externalId) {
		externalIdMap.put(jobId, externalId)
	}

	public String dequeueExternalId(String jobId) {
		String externalId = externalIdMap.get(jobId)
		externalIdMap.remove(jobId)
		return externalId
	}

	public String getNextNistFilePath() {
		String nistFilePath = nistFilePathList[nistFilePathIndex]
		resetIndexIfOverLimit()
		return nistFilePath
	}

	private void resetIndexIfOverLimit(){
		if(nistFilePathIndex < nistFilePathList.size()-1){
			nistFilePathIndex++
		}else{
			nistFilePathIndex = 0
		}
	}
}

