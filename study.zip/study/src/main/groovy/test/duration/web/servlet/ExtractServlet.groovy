package test.duration.web.servlet

import com.eviware.soapui.model.testsuite.TestRunner.Status
import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCaseRunner

import javax.servlet.*
import javax.servlet.http.*
import java.util.Enumeration

import test.duration.queue.*
import test.duration.call.*
import test.degrade.util.*
import test.common.runner.*

class ExtractServlet extends HttpServlet {
	static final String PROPERTIES = "Properties"
	static final String NIST_PATH = "nistPath"
	static int totalExecJobSize
	SoapuiObject soapuiObject
	String extractTestCaseName
	int limitJobSize
    def log

	ExtractServlet(context, String testCaseName, int limitJobSize){
		this.soapuiObject = new SoapuiObject(context)
		this.extractTestCaseName = testCaseName
		this.limitJobSize = limitJobSize
		this.totalExecJobSize = 1
	}

	ExtractServlet(context, String testCaseName, int limitJobSize, def log){
        this(context, testCaseName, limitJobSize)
		this.log = log
	}

	def void doGet(HttpServletRequest req, HttpServletResponse res) {
        doPost(req, res)
    }

	def void doPost(HttpServletRequest req, HttpServletResponse res) {
		try{
			WsdlTestCaseRunner result = executeExtractTestCase(res)
			if(result != null && result.status == Status.FAILED){
				callExtractTestCase()
			}
		}catch (Throwable e){
			output( "@@@ Uhyo------ !!")
			println e.printStackTrace()
			res.sendError(400, "receive error")
			res.setContentType("text/plain")
		}
	}

	def synchronized WsdlTestCaseRunner executeExtractTestCase(HttpServletResponse res){
		res.getWriter().close()
		if(totalExecJobSize <= limitJobSize) {
			output( "[ EXTRACT ] : executed ${totalExecJobSize} extract jobs...")
			return execExtract()
		}else{
			output( "[ EXTRACT ] : already ${limitJobSize} extract jobs executed...")
			return null
		}
	}	

	def WsdlTestCaseRunner execExtract(){
		String nistFilePath = getNextNistFilePath()
		def extractTestCase = soapuiObject.getTestCaseInSameSuite(extractTestCaseName)
		setProperty(extractTestCase, nistFilePath)
		totalExecJobSize++
		TestCaseExecutor testCaseExecutor = new TestCaseExecutor(extractTestCase)
		return testCaseExecutor.runTestCase()
	}

	def String getNextNistFilePath(){
		ExtractJobInfoQueue extractJobInfoQueue = ExtractJobInfoQueue.getInstance()
		return extractJobInfoQueue.getNextNistFilePath()
	}

	def void setProperty(testCase, String nistFilePath) {
		def propertiesTestStep = soapuiObject.getTestStepInOtherCase(testCase, PROPERTIES) 
		propertiesTestStep.setPropertyValue(NIST_PATH, nistFilePath)
	}

	def callExtractTestCase(){
		output( "[ Extract ] : @@@ Extract Failed !! Try Extract test case.")
		CallExtractTestCase caller = new CallExtractTestCase(soapuiObject)
		caller.call()
	}

	private void resetIndexIfOverLimit(){
		if(nistFilePathIndex < nistFilePathList.size()-1){
			nistFilePathIndex++
		}else{
			nistFilePathIndex = 0
		}
	}

    def void output(String str) {
        if(log != null) {
            log.info(str)
        }else{
            println (str)
        }
    }
}

