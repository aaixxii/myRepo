package test.duration.web.servlet

import com.eviware.soapui.model.testsuite.TestRunner.Status
import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCaseRunner

import java.text.SimpleDateFormat
import javax.servlet.*
import javax.servlet.http.*
import java.util.Enumeration

import test.duration.queue.*
import test.duration.call.*
import test.duration.log.*
import test.degrade.util.*
import test.common.runner.*
import common.queue.*
import test.common.util.db.*


class FrFaceExtServlet extends HttpServlet {
	static final String FR = "FR"
	static final String FACE_EXTRACT = "Face_Extraction"
	static final String PROPERTIES = "Properties"
	static final String FR_TEMPLATE_PATH = "FrTemplatePath"
	static final DurationLogger logger = new DurationLogger("FrFaceExtServlet")
	static int totalExecJobSize
	int limitJobSize
	SoapuiObject soapuiObject
    static Boolean isOver = false
	

	FrFaceExtServlet(context){
		this.soapuiObject = new SoapuiObject(context)
		this.totalExecJobSize = 1
	}

	FrFaceExtServlet(context, int limitJobSize){
		this.soapuiObject = new SoapuiObject(context)
		this.limitJobSize = limitJobSize
		this.totalExecJobSize = 1
	}

	FrFaceExtServlet(context, int limitJobSize, Boolean isOver){
		this.soapuiObject = new SoapuiObject(context)
		this.limitJobSize = limitJobSize
		this.totalExecJobSize = 1
		this.isOver = isOver
	}

	def void doGet(HttpServletRequest req, HttpServletResponse res) {
		doPost(req, res)
    }

	def void doPost(HttpServletRequest req, HttpServletResponse res) {
		try{
			looseAssertion(req.getInputStream())
			/*WsdlTestCaseRunner result = executeFrTestCase(res)
			if(result != null && result.status == Status.FAILED){
				callFrTestCase()
			}*/
			WsdlTestCaseRunner result = executeFaceExtTestCase(res)
			if(result != null && result.status == Status.FAILED){
				callFaceExtarctTestCase()
			}
		}catch (Throwable e){
			logger.info(e.printStackTrace())
			res.sendError(400, "receive error")
			res.setContentType("text/plain")
		}
	}

	def synchronized WsdlTestCaseRunner executeFaceExtTestCase(HttpServletResponse res){
		res.getWriter().close()
		if(totalExecJobSize <= limitJobSize) {
			logger.info("${totalExecJobSize} Face Extraction executed...")
			return execFaceExtraction()
		}else{
			logger.info("already ${limitJobSize} Face Extraction jobs executed...")
			return null
		}
	}	

	def synchronized WsdlTestCaseRunner  executeFrTestCase(HttpServletResponse res){
		res.getWriter().close()
		if(totalExecJobSize <= limitJobSize) {
			logger.info("${totalExecJobSize} FR executed...")
			return execFr()
		}else{
			logger.info("already ${limitJobSize} FR jobs executed...")
			return null
		}
	}	

	def WsdlTestCaseRunner execFaceExtraction(){
		def FaceExtTestCase = soapuiObject.getTestCaseInSameSuite(FACE_EXTRACT)
		totalExecJobSize++
		TestCaseExecutor testCaseExecutor = new TestCaseExecutor(FaceExtTestCase)
		return testCaseExecutor.runTestCase()
	}

	def WsdlTestCaseRunner execFr(){
		def FrTestCase = soapuiObject.getTestCaseInSameSuite(FR)
		setInsertProp(FrTestCase)
		totalExecJobSize++
		TestCaseExecutor testCaseExecutor = new TestCaseExecutor(FrTestCase)
		return testCaseExecutor.runTestCase()
	}

    def callFaceExtarctTestCase(){
		logger.info("@@@ FACE EXTRACT Failed !! Try FACE EXTRACT test caes.")
        CallFrTestCase caller = new CallFrTestCase(soapuiObject)
        caller.call()
    }

    def callFrTestCase(){
		logger.info("@@@ FR Failed !! Try FR test caes.")
        CallFrTestCase caller = new CallFrTestCase(soapuiObject)
        caller.call()
    }

	def setInsertProp(def testCase){
		def jobId
		def queue = new SingletonListQueue().getInstance()
		def setJobId = queue._dequeue()
		while(true){
			def jdbcTmp = new JdbcTemplateFactory(soapuiObject.getContext()).create()
			String sql = "select count(*) from fe_job_queue where job_state = 2 and job_id = ${setJobId}"
			def recordNum = jdbcTmp.queryForLong(sql)
        	if(recordNum != 0){ 
				jobId = setJobId
        		break
			}
		}
		//ExtractJobInfoQueue extractJobInfoQueue = ExtractJobInfoQueue.getInstance()
		//def externalId = extractJobInfoQueue.dequeueExternalId(jobId)
		setProperty(testCase, "extJobId", jobId)
		//setProperty(testCase, "externalId", externalId)
	}

	def setProperty(def testCase, def key, def value){
		def propertiesTestStep = soapuiObject.getTestStepInOtherCase(testCase, PROPERTIES)
        propertiesTestStep.setPropertyValue(key as String , value as String)
	}

	def looseAssertion(def result){
        Integer expReadCount = 200000
        Integer expMatchCount = 200000
        def extId = "mate"
        def score = 9999
        BufferedReader br = new BufferedReader(new InputStreamReader(result))
        StringBuilder sb = new StringBuilder()
        String line
        while ((line = br.readLine()) != null) {
            sb.append(line)
        }
        Node xml = new XmlParser().parseText(sb.toString())
        int actReadCount = xml.statistics.readCount.text() as int
        int actMatchCount = xml.statistics.readCount.text() as int
        String actExtId = xml.candidate.externalId.text()
        int actScore = xml.candidate."fusion-score".text() as int
        if(!isOver){
            if(actReadCount != expReadCount ||
                expMatchCount != expMatchCount ||
                actExtId != extId ||
                actScore != score){
                    assertErrorMehod(sb.toString())
            }
        }else{
            if( actReadCount < expReadCount||
                actMatchCount < expMatchCount||
                actExtId != extId ||
                actScore != score){
                    assertErrorMehod(sb.toString())
            }
        }
    }

	def assertErrorMehod(def result){
        logger.info("####  Assertion Error !!!!")
        def outputDir = soapuiObject.getGlobalOutputPath() + "/errorXml/"
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss")
        new File(outputDir + "errorXml_Date_" + sdf.format(new Date())).write(result)
    }

}

