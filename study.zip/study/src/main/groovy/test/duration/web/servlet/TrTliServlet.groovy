package test.duration.web.servlet

import com.eviware.soapui.model.testsuite.TestRunner.Status
import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCaseRunner

import javax.servlet.*
import javax.servlet.http.*
import java.util.Enumeration

import test.duration.queue.*
import test.duration.call.*
import test.degrade.util.*
import test.common.runner.*

class TrTliServlet extends HttpServlet {
	static final String PROPERTIES = "Properties"
	static final String EXT_JOB_ID = "extJobId"
	static final String EXTERNAL_ID = "externalId"
	static String nextTestCaseName = "TR_TLI"
	static int totalExecJobSize = 1
	SoapuiObject soapuiObject
    def log

	TrTliServlet(context){
		this.soapuiObject = new SoapuiObject(context)
	}

	TrTliServlet(context, String nextTestCaseName){
		this.soapuiObject = new SoapuiObject(context)
		this.nextTestCaseName = nextTestCaseName
	}

	TrTliServlet(context, String nextTestCaseName, def log){
        this(context, nextTestCaseName)
        this.log = log
	}

	def void doGet(HttpServletRequest req, HttpServletResponse res) {
        doPost(req, res)
    }

	def void doPost(HttpServletRequest req, HttpServletResponse res) {
		try{
			output( "[ ${nextTestCaseName} ] : ${totalExecJobSize} ${nextTestCaseName} testCase is called...")
            WsdlTestCaseRunner runner = executeTrTliTestCase(res)
            if(runner != null && runner.status == Status.FAILED){
                    callExtractTestCase()
            }
		}catch (Throwable e){
			output( "@@@ TIM callback !!")
			println e.printStackTrace()
			res.sendError(400, "receive error")
			res.setContentType("text/plain")
		}
	}

	def synchronized WsdlTestCaseRunner executeTrTliTestCase(HttpServletResponse res){
		res.getWriter().close()
		return execTrTli()
	}	

	def WsdlTestCaseRunner execTrTli(){
		String jobId = dequeueJobId()
		String externalId = dequeueExternalId(jobId)

        if(externalId == null) {
            output("jobId=${jobId} is already poped from job done queue. Skip TR and TLI.")
            return null
        }

        output( "[ TrTliServlet ] : jobId=${jobId} externalId=${externalId}")
		def trTliTestCase = soapuiObject.getTestCaseInSameSuite(nextTestCaseName)
		setProperty(trTliTestCase, jobId, externalId)
		totalExecJobSize++
		TestCaseExecutor testCaseExecutor = new TestCaseExecutor(trTliTestCase)
		return testCaseExecutor.runTestCase()
	}

	def dequeueJobId(){
		ExtractJobInfoQueue extractJobInfoQueue = ExtractJobInfoQueue.getInstance()
		return extractJobInfoQueue.dequeue()
	}

	def dequeueExternalId(String jobId){
		ExtractJobInfoQueue extractJobInfoQueue = ExtractJobInfoQueue.getInstance()
		return extractJobInfoQueue.dequeueExternalId(jobId)
	}

	def setProperty(trTliTestCase, String jobId, String externalId){
		def propertiesTestStep = soapuiObject.getTestStepInOtherCase(trTliTestCase, PROPERTIES) 
		propertiesTestStep.setPropertyValue(EXT_JOB_ID, jobId)
		propertiesTestStep.setPropertyValue(EXTERNAL_ID, externalId)
	}

	def callExtractTestCase(){
		output( "[ TR-TLI ] : @@@ TR-TLI Failed !! Try Extract test case.")
		CallExtractTestCase caller = new CallExtractTestCase(soapuiObject)
		caller.call()
	}

    def void output(String str) {
        if(log != null) {
            log.info(str)
        }else{
            println (str)
        }
    }
}


