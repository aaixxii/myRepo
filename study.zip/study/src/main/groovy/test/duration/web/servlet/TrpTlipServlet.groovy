package test.duration.web.servlet

import com.eviware.soapui.model.testsuite.TestRunner.Status
import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCaseRunner

import javax.servlet.*
import javax.servlet.http.*
import java.util.Enumeration

import test.duration.queue.*
import test.duration.call.*
import test.duration.log.*
import test.degrade.util.*
import test.common.runner.*

class TrpTlipServlet extends HttpServlet {
	static final String TR_TLIP = "TR_TLIP"
	static final String PROPERTIES = "Properties"
	static final String EXT_JOB_ID = "extJobId"
	static final String EXTERNAL_ID = "externalId"
	static final String SLASH = "/"
	static final String TLIP_CALLBACK = "tlipCallback"
	static final DurationLogger logger = new DurationLogger(TR_TLIP)
	static int totalExecJobSize = 1
	SoapuiObject soapuiObject

	TrpTlipServlet(context){
		this.soapuiObject = new SoapuiObject(context)
	}

	def void doGet(HttpServletRequest req, HttpServletResponse res) {
        doPost(req, res)
    }

	def void doPost(HttpServletRequest req, HttpServletResponse res) {
		try{
			logger.info("${totalExecJobSize} TR and TLIP executed...")
			if(executeTrTlipTestCase(req, res).status == Status.FAILED){
				callExtractTestCase()
			}
		}catch (Throwable e){
			println e.printStackTrace()
			res.sendError(400, "receive error")
			res.setContentType("text/plain")
		}
	}

	def synchronized WsdlTestCaseRunner executeTrTlipTestCase(
				HttpServletRequest req, HttpServletResponse res){
		String jobId = parseJobId(req.getRequestURI())
		res.getWriter().close()
		return execTrTlip(jobId)
	}	

    def String parseJobId(String requestUri){
        int index = requestUri.lastIndexOf(SLASH)
        return requestUri.substring(index+1)
    }

	def WsdlTestCaseRunner execTrTlip(String jobId){
		String externalId = dequeueExternalId(jobId)
		def trTlipTestCase = soapuiObject.getTestCaseInSameSuite(TR_TLIP)
		setProperty(trTlipTestCase, jobId, externalId)
		totalExecJobSize++
		TestCaseExecutor testCaseExecutor = new TestCaseExecutor(trTlipTestCase)
		return testCaseExecutor.runTestCase()
	}

	def dequeueJobId(){
		ExtractJobInfoQueue extractJobInfoQueue = ExtractJobInfoQueue.getInstance()
		return extractJobInfoQueue.dequeue()
	}

	def dequeueExternalId(String jobId){
		ExtractJobInfoQueue extractJobInfoQueue = ExtractJobInfoQueue.getInstance()
		return extractJobInfoQueue.dequeueExternalId(jobId)
	}

	def setProperty(trTlipTestCase, String jobId, String externalId){
		def propertiesTestStep = soapuiObject.getTestStepInOtherCase(trTlipTestCase, PROPERTIES) 
		propertiesTestStep.setPropertyValue(EXT_JOB_ID, jobId)
		propertiesTestStep.setPropertyValue(EXTERNAL_ID, externalId)
	}

	def callExtractTestCase(){
		logger.info("@@@ TR-TLIP Failed !! Try Extract test case.")
		CallExtractTestCase caller = new CallExtractTestCase(soapuiObject, TLIP_CALLBACK)
		caller.call()
	}
}


