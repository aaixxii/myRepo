package test.duration.web.servlet

import com.eviware.soapui.model.testsuite.TestRunner.Status
import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCaseRunner

import javax.servlet.*
import javax.servlet.http.*
import java.util.Enumeration

import test.duration.queue.*
import test.duration.call.*
import test.duration.log.*
import test.degrade.util.*
import test.common.runner.*

class LiServlet extends HttpServlet {
	static final String LI = "LI"
	static final String PROPERTIES = "Properties"
	static final String LI_TEMPLATE_PATH = "liTemplatePath"
	static final DurationLogger logger = new DurationLogger(LI)
	static int totalExecJobSize
	int limitJobSize
	SoapuiObject soapuiObject
	

	LiServlet(context, int limitJobSize){
		this.soapuiObject = new SoapuiObject(context)
		this.limitJobSize = limitJobSize
		this.totalExecJobSize = 1
	}

	def void doGet(HttpServletRequest req, HttpServletResponse res) {
        doPost(req, res)
    }

	def void doPost(HttpServletRequest req, HttpServletResponse res) {
		try{
			WsdlTestCaseRunner result = executeLiTestCase(res)
			if(result != null && result.status == Status.FAILED){
				callLiTestCase()
			}
		}catch (Throwable e){
			logger.info(e.printStackTrace())
			res.sendError(400, "receive error")
			res.setContentType("text/plain")
		}
	}

	def synchronized WsdlTestCaseRunner  executeLiTestCase(HttpServletResponse res){
		res.getWriter().close()
        if(totalExecJobSize <= limitJobSize) {
			logger.info("${totalExecJobSize} LI executed...")
			return execLi()
        }else{
            logger.info("already ${limitJobSize} LI jobs executed...")
            return null
        }
	}	

	def WsdlTestCaseRunner execLi(){
		String liTemplatePath = getLiTemplatePath()
		def liTestCase = soapuiObject.getTestCaseInSameSuite(LI)
		setProperty(liTestCase, liTemplatePath)
		totalExecJobSize++
		TestCaseExecutor testCaseExecutor = new TestCaseExecutor(liTestCase)
		return testCaseExecutor.runTestCase()
	}

	def String getLiTemplatePath(){
		LatentFingerTemplateList latentTemplateList = LatentFingerTemplateList.getInstance()
		return latentTemplateList.getLiTemplatePath()
	}

	def void setProperty(liTestCase, String liTemplatePath){
		def propertiesTestStep = soapuiObject.getTestStepInOtherCase(liTestCase, PROPERTIES) 
		propertiesTestStep.setPropertyValue(LI_TEMPLATE_PATH, liTemplatePath)
	}

    def callLiTestCase(){
		logger.info("@@@ LI Failed !! Try LI test caes.")
        CallLiTestCase caller = new CallLiTestCase(soapuiObject)
        caller.call()
    }
}

