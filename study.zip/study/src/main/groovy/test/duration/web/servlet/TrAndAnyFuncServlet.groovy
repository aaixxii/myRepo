package test.duration.web.servlet

import javax.servlet.*
import javax.servlet.http.*
import java.util.Enumeration
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import test.duration.queue.*
import test.duration.call.*
import test.degrade.util.*
import test.common.runner.*
import static test.common.constants.aim.AIMWord.*

class TrAndAnyFuncServlet extends HttpServlet {
	private static final Logger log = LoggerFactory.getLogger(TrAndAnyFuncServlet.class);
	private static final String SLASH = "/"
	private static final int EVENT_ID = 1
	static String serviceEndPoint
	static int totalExecJobSize
	SoapuiObject soapuiObject
	int limitJobSize
	int limitJobSizeForAdditionalFunc = 0
	AimFuncExecutorIF executor
	Map getBinaryMap = [ RDBTM:RDBTM_ID, SDBTM:SDBTM_ID, XDBL:XDBL_ID, "PDB_1":PDB_ID, "PDB_2":PDB_ID, "PDB_3":PDB_ID, "PDB_4":PDB_ID ]

	TrAndAnyFuncServlet(String serviceEndPoint, int limitJobSize, int limiJobSizeForAdditionalFunc, AimFuncExecutorIF executor){
		this(serviceEndPoint, limitJobSize)
		this.limitJobSizeForAdditionalFunc = limiJobSizeForAdditionalFunc
		this.executor = executor
	}

	TrAndAnyFuncServlet(String serviceEndPoint, int limitJobSize){
		this.serviceEndPoint = serviceEndPoint
		this.limitJobSize = limitJobSize
		this.totalExecJobSize = 0
	}

	def void doGet(HttpServletRequest req, HttpServletResponse res) {
        doPost(req, res)
    }

	def void doPost(HttpServletRequest req, HttpServletResponse res) {
		try{
			res.getWriter().close()
			if(totalExecJobSize < limitJobSize) {
				getBinaryTR(req)
				if(totalExecJobSize < limitJobSizeForAdditionalFunc){
					executor.execute()
				}else{
					log.info("Alredy ${totalExecJobSize+1} [ Extract | Search ] executed. Nothing to do...")
				}
			}else{
				log.warn("Already ${limitJobSize} getBinary and TR jobs executed...")
			}
		}catch (Throwable e){
			log.error("@@@ Uhyo---!!", e)
			res.sendError(400, "receive error")
			res.setContentType("text/plain")
			if(totalExecJobSize < limitJobSizeForAdditionalFunc){
				log.info("Retry Extract.")
				executor.execute()
			}
		}finally{
			totalExecJobSize++
		}
	}

	private getBinaryTR(HttpServletRequest req) {
		int currentExecNo = totalExecJobSize + 1
		log.info("try ${currentExecNo} times getBinary and TR...")
		String jobId = parseJobId(req.getRequestURI())
		String externalId = dequeueExternalId(jobId)
		GetBinaryExecutor getBinaryExecutor = new GetBinaryExecutor(serviceEndPoint)
		Map templateMap = getBinary(getBinaryExecutor, jobId)
		InsertExecutor insertExecutor = new InsertExecutor(serviceEndPoint)
		insertExecutor.execute(externalId, EVENT_ID, templateMap)
		log.info("finished ${currentExecNo} times getBinary and TR...")
	}

	private Map getBinary(GetBinaryExecutor getBinaryExecutor, String jobId) {
		Map templateMap = new HashMap()
		for(keyedBinary in getBinaryMap.keySet()){
			String templateB64 = getBinaryExecutor.execute(jobId, keyedBinary)
			int binId = getBinaryMap.get(keyedBinary) as int
			List templateList = templateMap.get(binId)
			if(templateList == null){
				templateList = []
			}
			templateList << templateB64
			templateMap.put(binId, templateList)
		}
		return templateMap
	}

	def dequeueExternalId(String jobId){
		ExtractJobInfoQueue extractJobInfoQueue = ExtractJobInfoQueue.getInstance()
		return extractJobInfoQueue.dequeueExternalId(jobId)
	}


	def String parseJobId(String requestUri){
		int index = requestUri.lastIndexOf(SLASH)
		return requestUri.substring(index+1)
	}

}

