package test.duration.web.servlet

import com.eviware.soapui.model.testsuite.TestRunner.Status
import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCaseRunner

import java.text.SimpleDateFormat
import javax.servlet.*
import javax.servlet.http.*
import java.util.Enumeration

import test.duration.queue.*
import test.duration.call.*
import test.duration.log.*
import test.degrade.util.*
import test.common.runner.*

class IiServlet extends HttpServlet {
	static final String II = "II"
	static final String PROPERTIES = "Properties"
	static final String II_TEMPLATE_PATH = "IiTemplatePath"
	static final String EXT_JOB_ID = "extJobId"
	static final String SLASH = "/"
	static final DurationLogger logger = new DurationLogger(II)
	static int totalExecJobSize
	int limitJobSize
	SoapuiObject soapuiObject
	def log
	static Boolean isOver = false
	static Boolean combi = false
	

	IiServlet(context, int limitJobSize){
		this.soapuiObject = new SoapuiObject(context)
		this.limitJobSize = limitJobSize
		this.totalExecJobSize = 1
	}

	IiServlet(context, int limitJobSize, Boolean isOver){
		this.soapuiObject = new SoapuiObject(context)
		this.limitJobSize = limitJobSize
		this.totalExecJobSize = 1
		this.isOver = isOver
	}

	IiServlet(context, int limitJobSize, def log){
		this.soapuiObject = new SoapuiObject(context)
		this.log = log
		this.totalExecJobSize = 1
		this.limitJobSize = limitJobSize
		this.combi = true
	}

	def void doGet(HttpServletRequest req, HttpServletResponse res) {
		doPost(req, res)
    }

	def void doPost(HttpServletRequest req, HttpServletResponse res) {
		try{
			//looseAssertion(req.getInputStream())
			WsdlTestCaseRunner result = null
			if(combi){
				result = executeIiTestCaseCombi(req, res)
			}else{
				result = executeIiTestCase(res)
			}
			if(result != null && result.status == Status.FAILED){
				callIiTestCase()
			}
		}catch (Throwable e){
			logger.info(e.printStackTrace())
			res.sendError(400, "receive error")
			res.setContentType("text/plain")
		}
	}

	def synchronized WsdlTestCaseRunner  executeIiTestCase(HttpServletResponse res){
		res.getWriter().close()
        if(totalExecJobSize <= limitJobSize) {
			logger.info("${totalExecJobSize} II executed...")
				return execIi()
        }else{
            logger.info("already ${limitJobSize} II jobs executed...")
            return null
        }
	}	

	def synchronized WsdlTestCaseRunner  executeIiTestCaseCombi(HttpServletRequest req, HttpServletResponse res){
		String jobId = parseJobId(req.getRequestURI())
		res.getWriter().close()
		enqueueJobId(jobId)
        totalExecJobSize++
        return execIi(jobId)
	}	

	def String parseJobId(String requestUri){
        int index = requestUri.lastIndexOf(SLASH)
        return requestUri.substring(index+1)
    }

    def enqueueJobId(String jobId){
        ExtractJobInfoQueue extractJobInfoQueue = ExtractJobInfoQueue.getInstance()
        extractJobInfoQueue.enqueue(jobId)
    }

	def WsdlTestCaseRunner execIi(){
		def IiTestCase = soapuiObject.getTestCaseInSameSuite(II)
		totalExecJobSize++
		TestCaseExecutor testCaseExecutor = new TestCaseExecutor(IiTestCase)
		return testCaseExecutor.runTestCase()
	}

	def WsdlTestCaseRunner execIi(String jobId){
		def IiTestCase = soapuiObject.getTestCaseInSameSuite(II)
		setExtJobId(IiTestCase, jobId)
		TestCaseExecutor testCaseExecutor = new TestCaseExecutor(IiTestCase)
		return testCaseExecutor.runTestCase()
	}

	def setExtJobId(IiTestCase, String jobId){
        def propertiesTestStep = soapuiObject.getTestStepInOtherCase(IiTestCase, PROPERTIES)
        propertiesTestStep.setPropertyValue(EXT_JOB_ID, jobId)
    }

    def callIiTestCase(){
		logger.info("@@@ II Failed !! Try II test caes.")
        CallIiTestCase caller = new CallIiTestCase(soapuiObject)
        caller.call()
    }

	def looseAssertion(def result){
		def outputDir = "/home/soapui/work/evidence/500_DTEST/errorXml/"
		def readCount = "200000"
		def matchCount = "200000"
		def extId = "mate"
		def score = "6610"
		BufferedReader br = new BufferedReader(new InputStreamReader(result))
		StringBuilder sb = new StringBuilder()
		String line
		while ((line = br.readLine()) != null) {
	    	sb.append(line)
		} 
		Node xml = new XmlParser().parseText(sb.toString())
		if(xml.statistics.readCount.text() != readCount ||
			xml.statistics.matchCount.text() != matchCount ||
			xml.candidate.externalId.text() != extId ||
			xml.candidate."fusion-score".text() != score){
			logger.info("####  Assertion Error !!!!")
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss")
            new File(outputDir + "errorXml_Date_" + sdf.format(new Date())).write(result)
		}
	}
}

