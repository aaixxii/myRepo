package test.duration.web.servlet

import com.eviware.soapui.model.testsuite.TestRunner.Status
import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCaseRunner

import java.text.SimpleDateFormat
import javax.servlet.*
import javax.servlet.http.*
import java.util.Enumeration

import test.duration.queue.*
import test.duration.call.*
import test.duration.log.*
import test.degrade.util.*
import test.common.runner.*

class FiServlet extends HttpServlet {
	static final String FI = "FI"
	static final String PROPERTIES = "Properties"
	static final String FI_TEMPLATE_PATH = "FiTemplatePath"
	static final DurationLogger logger = new DurationLogger(FI)
	static int totalExecJobSize
	int limitJobSize
	SoapuiObject soapuiObject
	static Boolean isOver = false
	

	FiServlet(context, int limitJobSize){
		this.soapuiObject = new SoapuiObject(context)
		this.limitJobSize = limitJobSize
		this.totalExecJobSize = 1
	}

	FiServlet(context, int limitJobSize, Boolean isOver){
		this.soapuiObject = new SoapuiObject(context)
		this.limitJobSize = limitJobSize
		this.totalExecJobSize = 1
		this.isOver = isOver
	}

	def void doGet(HttpServletRequest req, HttpServletResponse res) {
		doPost(req, res)
    }

	def void doPost(HttpServletRequest req, HttpServletResponse res) {
		try{
			extLooseAssertion(req.getInputStream())
			WsdlTestCaseRunner result = executeFiTestCase(res)
			if(result != null && result.status == Status.FAILED){
				callFiTestCase()
			}
		}catch (Throwable e){
			logger.info(e.printStackTrace())
			res.sendError(400, "receive error")
			res.setContentType("text/plain")
		}
	}

	def synchronized WsdlTestCaseRunner  executeFiTestCase(HttpServletResponse res){
		res.getWriter().close()
        if(totalExecJobSize <= limitJobSize) {
			logger.info("${totalExecJobSize} FI executed...")
			return execFi()
        }else{
            logger.info("already ${limitJobSize} FI jobs executed...")
            return null
        }
	}	

	def WsdlTestCaseRunner execFi(){
		def FiTestCase = soapuiObject.getTestCaseInSameSuite(FI)
		totalExecJobSize++
		TestCaseExecutor testCaseExecutor = new TestCaseExecutor(FiTestCase)
		return testCaseExecutor.runTestCase()
	}

	def String getLiTemplatePath(){
		LatentFingerTemplateList latentTemplateList = LatentFingerTemplateList.getInstance()
		return latentTemplateList.getLiTemplatePath()
	}

	def void setProperty(liTestCase, String liTemplatePath){
		def propertiesTestStep = soapuiObject.getTestStepInOtherCase(liTestCase, PROPERTIES) 
		propertiesTestStep.setPropertyValue(LI_TEMPLATE_PATH, liTemplatePath)
	}

    def callFiTestCase(){
		logger.info("@@@ FI Failed !! Try FI test caes.")
        CallFiTestCase caller = new CallFiTestCase(soapuiObject)
        caller.call()
    }

	def looseAssertion(def result){
		int expReadCount = 200000
		int expMatchCount = 200000
		def extId = "mate"
		int score = 9999
		BufferedReader br = new BufferedReader(new InputStreamReader(result))
		StringBuilder sb = new StringBuilder()
		String line
		while ((line = br.readLine()) != null) {
	    	sb.append(line)
		} 
		Node xml = new XmlParser().parseText(sb.toString())
		int actReadCount = xml.statistics.readCount.text() as int
		int actMatchCount = xml.statistics.readCount.text() as int
		String actExtId = xml.candidate.externalId.text()
		int actScore = xml.candidate."fusion-score".text() as int
		if(!isOver){
			if(actReadCount != expReadCount ||
				actMatchCount != expMatchCount ||
				actExtId != extId ||
				actScore != score){
					assertErrorMehod(result)
			}
		}else{
			if( actReadCount < expReadCount||
				actMatchCount < expMatchCount||
				actExtId != extId ||
				actScore != score){
					assertErrorMehod(result)
			}
		}
	}

	def extLooseAssertion(def result){
        def context = soapuiObject.getContext()
        def dataFilePath = context.expand( '${dataFilePath}' )
        String filePath = "${dataFilePath}" + "/degradeTest/resultXml/5.0.0/Dtest_FI_II/run/run/exp.xml"
        String exp = new File(filePath).getText()
        BufferedReader br = new BufferedReader(new InputStreamReader(result))
        StringBuilder sb = new StringBuilder()
        String line
        while ((line = br.readLine()) != null) {
            sb.append(line)
        }
        String act = sb.toString()
        if (exp != act){
            assertErrorMehod(sb.toString())
        }
    }

	def assertErrorMehod(def result){
		logger.info("####  Assertion Error !!!!")
		def outputDir = soapuiObject.getGlobalOutputPath() + "/errorXml/"
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss")
		new File(outputDir + "errorXml_Date_" + sdf.format(new Date())).write(result)
	}
}

