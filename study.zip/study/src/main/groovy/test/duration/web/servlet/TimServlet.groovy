package test.duration.web.servlet

import com.eviware.soapui.model.testsuite.TestRunner.Status
import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCaseRunner

import javax.servlet.*
import javax.servlet.http.*
import java.util.Enumeration

import test.duration.queue.*
import test.duration.call.*
import test.degrade.util.*
import test.common.runner.*

class TimServlet extends HttpServlet {
	static final String TIM = "TIM"
	static final String PROPERTIES = "Properties"
	static final String EXT_JOB_ID = "extJobId"
	static final String SLASH = "/"
	static int totalExecJobSize = 1
	SoapuiObject soapuiObject
    def log

	TimServlet(context){
		this.soapuiObject = new SoapuiObject(context)
	}

	TimServlet(context, def log){
		this(context)
        this.log = log
	}

	def void doGet(HttpServletRequest req, HttpServletResponse res) {
        doPost(req, res)
    }

	def void doPost(HttpServletRequest req, HttpServletResponse res) {
		try{
			output("[ TIM ] : ${totalExecJobSize} TIM excecuted...")
			if(executeTiTestCase(req, res).status == Status.FAILED){
				callExtractTestCase()
			}
		}catch (Throwable e){
			println e.printStackTrace()
			res.sendError(400, "receive error")
			res.setContentType("text/plain")
		}
	}

	def synchronized WsdlTestCaseRunner executeTiTestCase(
				HttpServletRequest req, HttpServletResponse res){
		String jobId = parseJobId(req.getRequestURI())
		res.getWriter().close()
		enqueueJobId(jobId)
		totalExecJobSize++
		return execTI(jobId)
	}	

	def String parseJobId(String requestUri){
		int index = requestUri.lastIndexOf(SLASH)
		return requestUri.substring(index+1)
	}

	def enqueueJobId(String jobId){
		ExtractJobInfoQueue extractJobInfoQueue = ExtractJobInfoQueue.getInstance()
		extractJobInfoQueue.enqueue(jobId)
	}

	def WsdlTestCaseRunner execTI(String jobId){
		def timTestCase = soapuiObject.getTestCaseInSameSuite(TIM)
		setExtJobId(timTestCase, jobId)
		TestCaseExecutor testCaseExecutor = new TestCaseExecutor(timTestCase)
		return testCaseExecutor.runTestCase()
	}

	def setExtJobId(timTestCase, String jobId){
		def propertiesTestStep = soapuiObject.getTestStepInOtherCase(timTestCase, PROPERTIES) 
		propertiesTestStep.setPropertyValue(EXT_JOB_ID, jobId)
	}

	def callExtractTestCase(){
		output( "[ TIM ] : @@@ TIM Failed !! Try Extract test case.")
		CallExtractTestCase caller = new CallExtractTestCase(soapuiObject)
		caller.call()
	}

    def void output(String str) {
        if(log != null) {
            log.info(str)
        }else{
            println (str)
        }
    }
}

