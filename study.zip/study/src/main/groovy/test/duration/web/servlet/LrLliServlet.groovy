package test.duration.web.servlet

import com.eviware.soapui.model.testsuite.TestRunner.Status
import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCaseRunner

import javax.servlet.*
import javax.servlet.http.*
import java.util.Enumeration

import test.duration.queue.*
import test.duration.call.*
import test.duration.log.*
import test.degrade.util.*
import test.common.runner.*

class LrLliServlet extends HttpServlet {
	static final String LR_LLI = "LR_LLI"
	static final String PROPERTIES = "Properties"
	static final String LR_TEMPLATE_PATH = "lrTemplatePath"
	static final String LLI_TEMPLATE_PATH = "lliTemplatePath"
	static final DurationLogger logger = new DurationLogger(LR_LLI)
	static int totalExecJobSize = 1
	SoapuiObject soapuiObject

	LrLliServlet(context){
		this.soapuiObject = new SoapuiObject(context)
	}

	def void doGet(HttpServletRequest req, HttpServletResponse res) {
        doPost(req, res)
    }

	def void doPost(HttpServletRequest req, HttpServletResponse res) {
		try{
			if(executeLrLliTestCase(res) == Status.FAILED){
				callLiTestCase()
			}
		}catch (Throwable e){
			logger.info(e.printStackTrace())
			res.sendError(400, "receive error")
			res.setContentType("text/plain")
		}
	}

	def synchronized WsdlTestCaseRunner  executeLrLliTestCase(HttpServletResponse res){
		res.getWriter().close()
		logger.info("${totalExecJobSize} LR_LLI executed...")
		return execLrLli()
	}	

	def WsdlTestCaseRunner execLrLli(){
		String lrTemplatePath = getLrTemplatePath()
		String lliTemplatePath = getLliTemplatePath()
		def lrLliTestCase = soapuiObject.getTestCaseInSameSuite(LR_LLI)
		setProperty(lrLliTestCase, lrTemplatePath, lliTemplatePath)
		totalExecJobSize++
		TestCaseExecutor testCaseExecutor = new TestCaseExecutor(lrLliTestCase)
		return testCaseExecutor.runTestCase()
	}

	def String getLrTemplatePath(){
		LatentFingerTemplateList latentTemplateList = LatentFingerTemplateList.getInstance()
		return latentTemplateList.getLrTemplatePath()
	}

	def String getLliTemplatePath(){
		LatentFingerTemplateList latentTemplateList = LatentFingerTemplateList.getInstance()
		return latentTemplateList.getLliTemplatePath()
	}

	def void setProperty(lrLliTestCase, String lrTemplatePath, String lliTemplatePath){
		def propertiesTestStep = soapuiObject.getTestStepInOtherCase(lrLliTestCase, PROPERTIES) 
		propertiesTestStep.setPropertyValue(LR_TEMPLATE_PATH, lrTemplatePath)
		propertiesTestStep.setPropertyValue(LLI_TEMPLATE_PATH, lliTemplatePath)
	}

    def callLiTestCase(){
		logger.info("@@@ LR-LLI Failed !! Try LI test caes.")
        CallLiTestCase caller = new CallLiTestCase(soapuiObject)
        caller.call()
    }

}

