package test.duration.web.servlet

import com.eviware.soapui.model.testsuite.TestRunner.Status
import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCaseRunner

import javax.servlet.*
import javax.servlet.http.*
import java.util.Enumeration

import test.duration.queue.*
import test.duration.call.*
import test.duration.log.*
import test.degrade.util.*
import test.common.runner.*

class LrpLlipServlet extends HttpServlet {
	static final String LRP_LLIP = "LRP_LLIP"
	static final String PROPERTIES = "Properties"
	static final String LRP_TEMPLATE_PATH = "lrpTemplatePath"
	static final String LLIP_TEMPLATE_PATH = "llipTemplatePath"
	static final DurationLogger logger = new DurationLogger(LRP_LLIP)
	static int totalExecJobSize = 1
	SoapuiObject soapuiObject

	LrpLlipServlet(context){
		this.soapuiObject = new SoapuiObject(context)
	}

	def void doGet(HttpServletRequest req, HttpServletResponse res) {
        doPost(req, res)
    }

	def void doPost(HttpServletRequest req, HttpServletResponse res) {
		try{
			if(executeLrpLlipTestCase(res) == Status.FAILED){
				callLipTestCase()
			}
		}catch (Throwable e){
			logger.info(e.printStackTrace())
			res.sendError(400, "receive error")
			res.setContentType("text/plain")
		}
	}

	def synchronized WsdlTestCaseRunner  executeLrpLlipTestCase(HttpServletResponse res){
		res.getWriter().close()
		logger.info("${totalExecJobSize} LRP_LLIP executed...")
		return execLrpLlip()
	}	

	def WsdlTestCaseRunner execLrpLlip(){
		String lrpTemplatePath = getLrpTemplatePath()
		String llipTemplatePath = getLlipTemplatePath()
		def lrpLlipTestCase = soapuiObject.getTestCaseInSameSuite(LRP_LLIP)
		setProperty(lrpLlipTestCase, lrpTemplatePath, llipTemplatePath)
		totalExecJobSize++
		TestCaseExecutor testCaseExecutor = new TestCaseExecutor(lrpLlipTestCase)
		return testCaseExecutor.runTestCase()
	}

	def String getLrpTemplatePath(){
		LatentPalmTemplateList latentTemplateList = LatentPalmTemplateList.getInstance()
		return latentTemplateList.getLrpTemplatePath()
	}

	def String getLlipTemplatePath(){
		LatentPalmTemplateList latentTemplateList = LatentPalmTemplateList.getInstance()
		return latentTemplateList.getLlipTemplatePath()
	}

	def void setProperty(lrpLlipTestCase, String lrpTemplatePath, String llipTemplatePath){
		def propertiesTestStep = soapuiObject.getTestStepInOtherCase(lrpLlipTestCase, PROPERTIES) 
		propertiesTestStep.setPropertyValue(LRP_TEMPLATE_PATH, lrpTemplatePath)
		propertiesTestStep.setPropertyValue(LLIP_TEMPLATE_PATH, llipTemplatePath)
	}

    def callLipTestCase(){
		logger.info("@@@ LRP-LLIP Failed !! Try LIP test caes.")
        CallLipTestCase caller = new CallLipTestCase(soapuiObject)
        caller.call()
    }
}

