package test.duration.web.servlet

import com.eviware.soapui.model.testsuite.TestRunner.Status
import com.eviware.soapui.impl.wsdl.testcase.WsdlTestCaseRunner

import javax.servlet.*
import javax.servlet.http.*
import java.util.Enumeration

import test.duration.queue.*
import test.duration.call.*
import test.duration.log.*
import test.degrade.util.*
import test.common.runner.*

class LipServlet extends HttpServlet {
	static final String LIP = "LIP"
	static final String PROPERTIES = "Properties"
	static final String LIP_TEMPLATE_PATH = "lipTemplatePath"
	static final DurationLogger logger = new DurationLogger(LIP)
	static int totalExecJobSize
	int limitJobSize
	SoapuiObject soapuiObject
	

	LipServlet(context, int limitJobSize){
		this.soapuiObject = new SoapuiObject(context)
		this.limitJobSize = limitJobSize
		this.totalExecJobSize = 1
	}

	def void doGet(HttpServletRequest req, HttpServletResponse res) {
        doPost(req, res)
    }

	def void doPost(HttpServletRequest req, HttpServletResponse res) {
		try{
			WsdlTestCaseRunner result = executeLipTestCase(res)
			if(result != null && result.status == Status.FAILED){
				callLipTestCase()
			}
		}catch (Throwable e){
			logger.info(e.printStackTrace())
			res.sendError(400, "receive error")
			res.setContentType("text/plain")
		}
	}

	def synchronized WsdlTestCaseRunner  executeLipTestCase(HttpServletResponse res){
		res.getWriter().close()
        if(totalExecJobSize <= limitJobSize) {
			logger.info("${totalExecJobSize} LIP executed...")
			return execLip()
        }else{
            logger.info("already ${limitJobSize} LIP jobs executed...")
            return null
        }
	}	

	def WsdlTestCaseRunner execLip(){
		String lipTemplatePath = getLipTemplatePath()
		def lipTestCase = soapuiObject.getTestCaseInSameSuite(LIP)
		setProperty(lipTestCase, lipTemplatePath)
		totalExecJobSize++
		TestCaseExecutor testCaseExecutor = new TestCaseExecutor(lipTestCase)
		return testCaseExecutor.runTestCase()
	}

	def String getLipTemplatePath(){
		LatentPalmTemplateList latentTemplateList = LatentPalmTemplateList.getInstance()
		return latentTemplateList.getLipTemplatePath()
	}

	def void setProperty(lipTestCase, String lipTemplatePath){
		def propertiesTestStep = soapuiObject.getTestStepInOtherCase(lipTestCase, PROPERTIES) 
		propertiesTestStep.setPropertyValue(LIP_TEMPLATE_PATH, lipTemplatePath)
	}

    def callLipTestCase(){
		logger.info("@@@ LIP Failed !! Try LIP test caes.")
        CallLipTestCase caller = new CallLipTestCase(soapuiObject)
        caller.call()
    }
}

