package test.web.servlet

import javax.servlet.*
import javax.servlet.http.*

import test.common.format.html.JobQueueInfoHtmlCreator


class JobQueueMonitorServlet extends HttpServlet {
	private static JobQueueInfoHtmlCreator htmlCreator
	
	public JobQueueMonitorServlet(){}
	
	public JobQueueMonitorServlet(String ip, String port, String sid, String user, String pass){
		this.htmlCreator = new JobQueueInfoHtmlCreator(ip, port, sid, user, pass)
	}

	def void doPost(HttpServletRequest req, HttpServletResponse res) {
		PrintWriter pw = null
		res.setContentType("text/html")
		try {
			pw = res.getWriter()
			pw.println(htmlCreator.create())
			res.setStatus(200)
		}catch (Exception e){
			res.sendError(400, "receive error")
			res.setContentType("text/plain")
		}finally{
			if(pw != null){
				pw.close()
			}
		}
	}

	def void doGet(HttpServletRequest req, HttpServletResponse res) {
		doPost(req, res)
	}
}
