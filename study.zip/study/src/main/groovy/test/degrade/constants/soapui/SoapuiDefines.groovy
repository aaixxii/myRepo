package test.degrade.constants.soapui

class SoapuiDefines{
	static final String RESULT_XML             = "resultXml"
	static final String SOAPUI_TEST_SUMMARY    = "soapUITestSummary"
	static final String RESULT_DATA 		   = "resultData"
	static final String TRUE                   = "  TRUE "
	static final String TRUE_EYE_CHECK         = "%%TRUE "
	static final String FALSE                  = "@@FALSE"
	static final String COMMON_TEST_SUITE_NAME = "called_only"
	static final String COMMON_TEST_CASE_NAME  = "initialize"
	static final String COMMON_TEST_STEP_NAME  = "Properties"
	static final String DELETE_TEST_CASE_NAME  = "delete"
	static final String ACTUAL_ASSERT_COUNT    = "actualAssertCount"
	static final String EXPECTED_ASSERT_COUNT  = "expectedAssertCount"
	static final String DEGRADE_TEST           = "degradeTest"
	static final String CLIENTAIP_XSD          = "clientapi.xsd"
	static final String EXTRACTION_PAYLOAD_XSD = "extraction-payload.xsd"
	static final String PROJECT_PROP_HEADER    = "#Project"
	static final String SKIP = "&&SKIP"
}
