package test.degrade.web.servlet

import javax.servlet.*
import javax.servlet.http.*
import org.apache.commons.io.IOUtils

import test.degrade.evidence.*

class CandidateAssertionServlet extends HttpServlet {
	int expectReadCnt = 0
	int expectMatchCnt = 0
	int expectCandSize = 0
	int expectErrSize = 0
	int assertMode = 0 // 0 is equal, 1 is more than, 2 is less than
	boolean needStopping = false
	String funcName = ""
	EvidenceFileOutputor evidenceFileOutputer

	CandidateAssertionServlet(){}

	CandidateAssertionServlet(context, String funcName, int assertMode, int expectReadCnt, int expectMatchCnt, int expectCandSize){
		this.expectReadCnt = expectReadCnt
		this.expectMatchCnt = expectMatchCnt
		this.expectCandSize = expectCandSize
		this.funcName = funcName
		this.assertMode = assertMode
		this.evidenceFileOutputer = new EvidenceFileOutputor(context)
		evidenceFileOutputer.outputTestProjectTitle()
	}

	def void doGet(HttpServletRequest req, HttpServletResponse res) {
		println "stop"
        this.needStopping = true
    }

	def void doPost(HttpServletRequest req, HttpServletResponse res) {
		def callbackXml = IOUtils.toString(req.getInputStream())
		assertCallbackXml(callbackXml)
	}

	def void assertCallbackXml(String callbackXml) {
		try{
			def root = new XmlParser().parseText(callbackXml)
			int readCnt = root.statistics.readCount.text() as int
			int matchCnt = root.statistics.matchCount.text() as int
			int candSize = root.candidate.size()
			int errSize = root.error.size()
			assertReadMatcnCnt(readCnt, matchCnt)
			assert expectCandSize == candSize, "candidate size is not ${expectCandSize}. actual ${candSize}"
			assert expectErrSize == errSize, "error size is not ${expectErrSize}. actual ${errSize}"
		}catch (Throwable e){
			e.printStackTrace()
			outputEvidence(e)
		}
	}

	def assertReadMatcnCnt(int readCnt, int matchCnt){
		if(assertMode == 0){
			assert expectReadCnt == readCnt, "readCount is not  ${expectReadCnt}. actual ${readCnt}"
			assert expectMatchCnt == matchCnt, "matchCount is not ${expectMatchCnt}. actual ${matchCnt}"
		}else if(assertMode == 1){
			assert expectReadCnt <= readCnt, "readCount is less than ${expectReadCnt}. actual ${readCnt}"
			assert expectMatchCnt <= matchCnt, "matchCount is less than ${expectMatchCnt}. actual ${matchCnt}"
		}else if(assertMode == 2){
			assert expectReadCnt >= readCnt, "readCount is more than ${expectReadCnt}. actual ${readCnt}"
			assert expectMatchCnt >= matchCnt, "matchCount is more than ${expectMatchCnt}. actual ${matchCnt}"
		}
	}

	def boolean needStopping() {
		return needStopping
	}

	def outputEvidence(errMessg){
		evidenceFileOutputer.outputFalseMess("funcName=${funcName} - ${errMessg}")
	}
}

