package test.degrade.properties

import test.degrade.util.*

class Properties{
	def soapuiObject

	Properties(context){
		this.soapuiObject = new SoapuiObject(context)
	}

	def setProperties(key, value){
		soapuiObject.setProperties(key, value)
	}

	def getProperties(key){
		return soapuiObject.getProperties(key)
	}
}

