package test.degrade.properties

import test.degrade.util.*

class GlobalProperties{

	def soapuiObject

	GlobalProperties(context){
		this.soapuiObject = new SoapuiObject(context)
	}

	def getDataFilePath(){
		return soapuiObject.getGlobalDataFilePath()
	}

	def getVerNum(){
		return soapuiObject.getGlobalVerNum()
	}

	def getOutputPath(){
		return soapuiObject.getGlobalOutputPath()
	}

	def getDBIP(){
		return soapuiObject.getGlobalDBIP()
	}

	def getDBPort(){
		return soapuiObject.getGlobalDBPort()
	}

	def getDBSID(){
		return soapuiObject.getGlobalDBSID()
	}

	def getDBUser(){
		return soapuiObject.getGlobalDBUser()
	}

	def getDBPass(){
		return soapuiObject.getGlobalDBPass()
	}

	def getCallbackPort(){
		return soapuiObject.getGlobalCallbackPort()
	}

	def getCallbackUrl(){
		return soapuiObject.getGlobalCallbackUrl()
	}
	
	def getMuIp(){
		return soapuiObject.getGlobalMuIp()
	}

	def getMuPort(){
		return soapuiObject.getGlobalMuPort()
	}

	def getMuUser(){
		return soapuiObject.getGlobalMuUser()
	}

	def getMuPass(){
		return soapuiObject.getGlobalMuPass()
	}

	def getMuHome(){
		return soapuiObject.getGlobalMuHome()
	}

	def getServiceEndpoint(){
		return soapuiObject.getGlobalServiceEndpoint()
	}

	def getServiceContextRoot(){
		return soapuiObject.getGlobalContextRoot()
	}

	def getSubtoolDir(){
		return soapuiObject.getGlobalSubtoolDir()
	}
	def getVmIp(){
		return soapuiObject.getGlobalVmIp()
	}
	def getVmUser(){
		return soapuiObject.getGlobalVmUser()
	}
	def getVmPass(){
		return soapuiObject.getGlobalVmPass()
	}

	def getVmVersion(){
		return soapuiObject.getGlobalVmVersion()
	}

	def getVmJbossHome(){
		return soapuiObject.getGlobalVmJbossHome()
	}

	def getVpHome(){
		return soapuiObject.getGlobalVpHome()
	}

	def getVpVersion(){
		return soapuiObject.getGlobalVpVersion()
	}

	def getVpIp(){
		return soapuiObject.getGlobalVpIp()
	}

	def getVpPort(){
		return soapuiObject.getGlobalVpPort()
	}

	def getVpwNum(){
		return soapuiObject.getGlobalVpwNum()
	}

	def getVpUser(){
		return soapuiObject.getGlobalVpUser()
	}

	def getVpPass(){
		return soapuiObject.getGlobalVpPass()
	}

	def getMmIp(){
		return soapuiObject.getGlobalMmIp()
	}

	def getMmUser(){
		return soapuiObject.getGlobalMmUser()
	}

	def getMmPass(){
		return soapuiObject.getGlobalMmPass()
	}

	def getMmHome(){
		return soapuiObject.getGlobalMmHome()
	}

	def getDmIp(){
		return soapuiObject.getGlobalDmIp()
	}

	def getDmUser(){
		return soapuiObject.getGlobalDmUser()
	}

	def getDmPass(){
		return soapuiObject.getGlobalDmPass()
	}

	def getDmHome(){
		return soapuiObject.getGlobalDmHome()
	}

	def getDmSegDir(){
		return soapuiObject.getGlobalDmSegDir()
	}

    def getTvIp(){
        return soapuiObject.getGlobalTvIp()
    }

    def getTvUser(){
        return soapuiObject.getGlobalTvUser()
    }

    def getTvPass(){
        return soapuiObject.getGlobalTvPass()
    }

    def getTvHome(){
        return soapuiObject.getGlobalTvHome()
    }

    def getFileServerRootURL(){
        return soapuiObject.getGlobalFileServerRootUrl()
    }

    def getFileServerRootDataPath(){
        return soapuiObject.getGlobalFileServerRootDataPath()
    }

    def getTimEngine(){
        return soapuiObject.getGlobalTimEngine()
    }

    def getIrisEngine(){
        return soapuiObject.getGlobalIrisEngine()
    }

    def getIsSoapui(){
        return soapuiObject.getGlobalIsSoapUI()
    }

}

