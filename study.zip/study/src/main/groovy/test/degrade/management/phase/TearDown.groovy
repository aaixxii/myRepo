package test.degrade.management.phase

import test.common.util.db.*
import test.degrade.util.*
import test.degrade.assertion.*
import test.degrade.management.*
import test.degrade.constants.soapui.*

class TearDown{
	def soapuiObject
	
	TearDown(context){
		this.soapuiObject = new SoapuiObject(context)
	}

	def execTearDown(){
		clearPersonBio()
		assertAssertCount()
	}

	def assertAssertCount(){
		checkAssertCount()
		doAssertion()
	}
	
	def checkAssertCount(){
		def assertCountChecher = new AssertCountChecker(soapuiObject.getContext())
		assertCountChecher.outputAssertCountResult()
	}
	
	def doAssertion(){
		def assertCountChecher = new AssertCountChecker(soapuiObject.getContext())
		if(!assertCountChecher.getAessertionResult()){
			new AbendProcessor(soapuiObject.getContext()).assertFalse(assertCountChecher.mkMessg())
		}
	}

	def clearPersonBio(){
		def personBio = new ClearPersonBio(soapuiObject.getContext(), SoapuiDefines.COMMON_TEST_SUITE_NAME,
											SoapuiDefines.DELETE_TEST_CASE_NAME, SoapuiDefines.COMMON_TEST_STEP_NAME)
		personBio.deletePersonBio()
	}
}

