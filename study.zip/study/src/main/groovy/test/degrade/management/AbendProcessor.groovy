package test.degrade.management

import common.xml.*
import test.common.message.*
import test.degrade.evidence.*

class AbendProcessor{
	def context
	
	AbendProcessor(context){
		this.context = context
	}

	def abendTest(testPatternName, XMLAssertResult xmlAssertResult){
		def errMess = createErrMess(xmlAssertResult.xpath, xmlAssertResult.expectedValue, xmlAssertResult.actualValue)
		def evidenceFileOutputor = new EvidenceFileOutputor(context)
		evidenceFileOutputor.outputFalseMess("${testPatternName} --> ${errMess}")
		assertFalse(errMess)
	}

	def abendTest(testPatternName, XMLValidator xmlValidator){
		def evidenceFileOutputor = new EvidenceFileOutputor(context)
		evidenceFileOutputor.outputFalseMess("${testPatternName} --> XSD schem validattion error. " + xmlValidator.getError())
		assertFalse(xmlValidator.getError())
	}

	def abendTest(testPatternName, String errMess){
		def evidenceFileOutputor = new EvidenceFileOutputor(context)
		evidenceFileOutputor.outputFalseMess("${testPatternName} --> ${errMess}")
		assertFalse(errMess)
	}

	def abendTest(String errMess){
		def evidenceFileOutputor = new EvidenceFileOutputor(context)
		evidenceFileOutputor.outputFalseMess(errMess)
		assertFalse(errMess)
	}

	def createErrMess(property, expectedValue, actualValue){
		return new MessageCreator().mkValueErrMessg(property, expectedValue, actualValue)
	}

	def assertFalse(message){
		assert false, message
	}
}

