package test.degrade.management.phase

import test.common.runner.*
import test.common.util.db.*
import test.degrade.util.*
import test.degrade.evidence.*
import test.degrade.constants.soapui.*
import test.degrade.properties.GlobalProperties
import static test.common.constants.aim.AIMWord.*

class Setup{
	def SoapuiObject soapuiObj 
	def GlobalProperties globalProperties 

	Setup(context){
		this.soapuiObj = new SoapuiObject(context)
        this.globalProperties = new GlobalProperties(context)
	}

	def callInitialize(){
		def testSuiteName = soapuiObj.getTestSuiteName()
		def testCaseName = soapuiObj.getTestCaseName()
		def testName = "${testSuiteName}/${testCaseName}"
		def testCase = soapuiObj.getTestCaseInOtherSuite(
                SoapuiDefines.COMMON_TEST_SUITE_NAME, SoapuiDefines.COMMON_TEST_CASE_NAME)
		def testStep = soapuiObj.getTestStepInOtherCase(testCase, SoapuiDefines.COMMON_TEST_STEP_NAME)
		def testCaseExecutor = new TestCaseExecutor(testCase, testStep)
		def propertiesMap = [ "testcase_name":testName ]
		testCaseExecutor.setupTestStep(propertiesMap)
		testCaseExecutor.runTestCase()
	}

	def callInitializeRemainPersonBio(){
		def testTitleOutputor = new EvidenceFileOutputor(soapuiObj.getContext())
		testTitleOutputor.outputTestCaseTitle()
	}

	def execInitialize(){
		callClearPersonBio()
		callOutputEvidenceFile()
	}

	def callClearPersonBio(){
		def testCaseName = "delete"
		def clearPersonBio = new ClearPersonBio(
                soapuiObj.getContext(), testCaseName, SoapuiDefines.COMMON_TEST_STEP_NAME)
		clearPersonBio.deletePersonBio()
	}

	def callOutputEvidenceFile(){
		def testTitleOutputor = new EvidenceFileOutputor(soapuiObj.getContext())
		testTitleOutputor.outputTestCaseTitleUseProperties()
	}

    public void chTestSuiteEnableModeByEngine() {
        chTestSuiteEnableModeByTimEngine()
        chTestSuiteEnableModeByIiEngine()
    }

    private void chTestSuiteEnableModeByTimEngine() {
        def targetEngine = globalProperties.getTimEngine()
        chTestSuiteEnableModeBySearchEngine(targetEngine, CMLAF, CML)
    }

    private void chTestSuiteEnableModeByIiEngine() {
        def targetEngine = globalProperties.getIrisEngine()
        chTestSuiteEnableModeBySearchEngine(targetEngine, VERIEYE, NIRIS)
    }

    private void chTestSuiteEnableModeBySearchEngine(String targetEngine, String engineA, String engineB) {
        def testSuiteList = soapuiObj.getContext().testCase.testSuite.getProject().getTestSuiteList()
        for(testSuite in  testSuiteList) {
            if(testSuite.name.endsWith(engineA)){
                testSuite.setDisabled(engineA != targetEngine)
            }else if(testSuite.name.endsWith(engineB)){
                testSuite.setDisabled(engineB != targetEngine)        
            }
        }
    }

    public void chTestCaseEnableModeByEngine() {
        chTestCaseEnableModeByTimEngine()
		chTestCaseEnableModeByIiEngine()
    }

    private void chTestCaseEnableModeByTimEngine() {
        def targetEngine = globalProperties.getTimEngine()
        chTestCaseEnableModeBySearchEngine(targetEngine, CMLAF, CML)
    }

    private void chTestCaseEnableModeByIiEngine() {
        def targetEngine = globalProperties.getIrisEngine()
        chTestCaseEnableModeBySearchEngine(targetEngine, VERIEYE, NIRIS)
    }

    private void chTestCaseEnableModeBySearchEngine(String targetEngine, String engineA, String engineB) {
        def testCaseList = soapuiObj.getContext().testCase.testSuite.getTestCaseList()
        for(testCase in  testCaseList) {
            if(testCase.name.endsWith(engineA)){
                testCase.setDisabled(engineA != targetEngine)
            }else if(testCase.name.endsWith(engineB)){
                testCase.setDisabled(engineB != targetEngine)        
            }
        }
	}
}

