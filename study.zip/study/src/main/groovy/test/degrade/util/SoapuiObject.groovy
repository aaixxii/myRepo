package test.degrade.util

import test.degrade.constants.soapui.*
import static test.common.constants.aim.AIMWord.*

class SoapuiObject{
	def context
	def propertyNameOfActualAssertCnt
	def propertyNameOfExpectedAssertCnt
	static final int BASE_PORT = 50000
	static final int RANDOM_RANGE = 9999
	static final String CALLBACK_PORT = "callbackPort"
	static final String CALLBACK_IP = "callbackIP"
	static final String CALLBACK_URL = "callbackURL"

	SoapuiObject(context){
		this.context = context
		this.propertyNameOfActualAssertCnt = SoapuiDefines.COMMON_TEST_STEP_NAME + "#" + SoapuiDefines.ACTUAL_ASSERT_COUNT
		this.propertyNameOfExpectedAssertCnt = SoapuiDefines.COMMON_TEST_STEP_NAME + "#" + SoapuiDefines.EXPECTED_ASSERT_COUNT
	}

	def getContext(){
		return context	
	}

	def getTestCaseInSameSuite(testCaseName){
		return context.testCase.getTestSuite().getTestCaseByName(testCaseName)
	}

	def getTestCaseInOtherSuite(testSuiteName, testCaseName){
		return context.testCase.getTestSuite().getProject().
				getTestSuiteByName(testSuiteName).getTestCaseByName(testCaseName)
	}
	
	def getTestStepInOtherCase(testCase, testStepName){
		return testCase.getTestStepByName(testStepName)
	}

	def getTestStepInSameCase(testStepName){
		return context.testCase.getTestStepByName(testStepName)
	}
	
	def getTestProjectName(){
		return context.testCase.testSuite.getProject().getName()
	}

	def getTestCaseName(){
		return "${context.testCase.name}"
	}

	def getTestSuiteName(){
		return "${context.testCase.testSuite.name}"
	}

	def getEnableTestSuiteNameList(){
		List testSuiteNameList = []
		for(testSuite in  context.testCase.testSuite.getProject().getTestSuiteList()){
			if(!testSuite.isDisabled()){
				testSuiteNameList << testSuite.getName()
			}
		}
		return testSuiteNameList
	}

	def getActualAssertCount(){
		return context.getProperty(propertyNameOfActualAssertCnt) as int
	}

	def getExpectedAssertCount(){
		return context.getProperty(propertyNameOfExpectedAssertCnt) as int
	}

	def setActualAssertCount(num){
		def testCase = getTestStepInSameCase(SoapuiDefines.COMMON_TEST_STEP_NAME)
		testCase.setPropertyValue(SoapuiDefines.ACTUAL_ASSERT_COUNT, num as String)	
	}

	def setExpectedAssertCount(num){
		def testCase = getTestStepInSameCase(SoapuiDefines.COMMON_TEST_STEP_NAME)
		testCase.setPropertyValue(SoapuiDefines.EXPECTED_ASSERT_COUNT, num as String)	
	}

	def getGlobalDataFilePath(){
		return context.expand('${dataFilePath}')
	}

	def getGlobalVerNum(){
		return context.expand('${verNum}')
	}

	def getGlobalOutputPath(){
		return context.expand('${OutPutPath}')
	}

	def getGlobalDBIP(){
		return context.expand('${DBIP}')
	}
	
	def getGlobalDBPort(){
		return context.expand('${DBPort}')
	}
	
	def getGlobalDBSID(){
		return context.expand('${DBSID}')
	}
	
	def getGlobalDBUser(){
		return context.expand('${DBUser}')
	}
	
	def getGlobalDBPass(){
		return context.expand('${DBPass}')
	}
	
	def getGlobalCallbackPort(){
		return context.expand('${callbackPort}')
	}

	def getGlobalCallbackUrl(){
		return context.expand('${callbackURL}')
	}

	def getGlobalMuIp(){
		return context.expand('${MU_IP}')
	}

	def getGlobalMuPort(){
		return context.expand('${MU_PORT}')
	}

	def getGlobalMuUser(){
		return context.expand('${MU_USER}')
	}

	def getGlobalMuPass(){
		return context.expand('${MU_PASS}')
	}

	def getGlobalMuHome(){
		return context.expand('${MU_HOME}')
	}

	def getGlobalServiceEndpoint(){
		return context.expand('${serviceEndpoint}')
	}

	def getGlobalContextRoot(){
		return context.expand('${contextRoot}')
	}

	def getGlobalSubtoolDir(){
		return context.expand('${subtoolDir}')
	}

	def getGlobalVmIp(){
		return context.expand('${VM_IP}')
	}

	def getGlobalVmUser(){
		return context.expand('${VM_USER}')
	}

	def getGlobalVmPass(){
		return context.expand('${VM_PASS}')
	}

	def getGlobalVmVersion(){
		return context.expand('${VM_VERSION}')
	}

	def getGlobalVmJbossHome(){
		return context.expand('${VM_JBOSS_HOME}')
	}

	def getGlobalVpHome(){
		return context.expand('${VP_HOME}')
	}

	def getGlobalVpVersion(){
		return context.expand('${VP_VERSION}')
	}

	def getGlobalVpIp(){
		return context.expand('${VP_IP}')
	}

	def getGlobalVpPort(){
		return context.expand('${VP_PORT}')
	}

	def getGlobalVpwNum(){
		return context.expand('${VPW_NUM}')
	}

	def getGlobalVpUser(){
		return context.expand('${VP_USER}')
	}

	def getGlobalVpPass(){
		return context.expand('${VP_PASS}')
	}

	def getGlobalMmIp(){
		return context.expand('${MM_IP}')
	}

	def getGlobalMmUser(){
		return context.expand('${MM_USER}')
	}

	def getGlobalMmPass(){
		return context.expand('${MM_PASS}')
	}

	def getGlobalMmHome(){
		return context.expand('${MM_HOME}')
	}

	def getGlobalDmIp(){
		return context.expand('${DM_IP}')
	}

	def getGlobalDmUser(){
		return context.expand('${DM_USER}')
	}

	def getGlobalDmPass(){
		return context.expand('${DM_PASS}')
	}

	def getGlobalDmHome(){
		return context.expand('${DM_HOME}')
	}

	def getGlobalDmSegDir(){
		return context.expand('${SEG_DIR}')
	}

    def getGlobalTvIp(){
        return context.expand('${TV_IP}')
    }

    def getGlobalTvUser(){
        return context.expand('${TV_USER}')
    }

    def getGlobalTvPass(){
        return context.expand('${TV_PASS}')
    }

    def getGlobalTvHome(){
        return context.expand('${TV_HOME}')
    }

    def getGlobalFileServerRootUrl(){
        return context.expand('${fileServerRootURL}')
    }

    def getGlobalFileServerRootDataPath(){
        return context.expand('${fileServerRootDataPath}')
    }

    def getGlobalTimEngine(){
        return context.expand('${timEngine}')
    }

    def getGlobalIrisEngine(){
        return context.expand('${irisEngine}')
    }

	def getEvidenceXmlDirName(){
		return getEvidenceDirName(SoapuiDefines.RESULT_XML)
	}
	
	def getEvidenceDataDirName(){
		return getEvidenceDirName(SoapuiDefines.RESULT_DATA)
	}

	def getGlobalTempDirName(){
		return context.expand('${tempDirName}')
	}

	def getGlobalIsSoapUI(){
		return context.expand('${isSoapUI}')
	}

	def String getEvidenceDirName(String dirName){
		return  getGlobalOutputPath() + "/" +
				dirName + "/" + 
				getGlobalTimEngine().toUpperCase() + "_" + getGlobalIrisEngine().toUpperCase() + "/" +
				getTestProjectName() + "/" +
				getTestSuiteName() + "/" +
				getTestCaseName() 
	}

	def String getEvidenceDirUnderName(){
		return  getGlobalTimEngine().toUpperCase() + "_" + getGlobalIrisEngine().toUpperCase() + "/" +
				getTestProjectName() + "/" +
				getTestSuiteName() + "/" +
				getTestCaseName() 
	}

	def String getLatestEvidenceXmlDirName(){
		return  getExpectedEvidenceDirName(SoapuiDefines.RESULT_XML)
	}
	
	def String getExpectedEvidenceDataDirName(){
		return  getExpectedEvidenceDirName(SoapuiDefines.RESULT_DATA)
	}

	def String getExpectedEvidenceDataDirName(String subDir){
		return  getExpectedEvidenceDirName(SoapuiDefines.RESULT_DATA) + "/" + subDir
	}

	def String getExpectedEvidenceDirName(String dirName){
		return  getGlobalDataFilePath() + "/" +
				SoapuiDefines.DEGRADE_TEST + "/" + 
				dirName + "/" + 
				getGlobalVerNum() + "/" +
				getGlobalTimEngine().toUpperCase() + "_" + getGlobalIrisEngine().toUpperCase() + "/" +
				getTestProjectName() + "/" +
				getTestSuiteName() + "/" +
				getTestCaseName() 
	}
	
	def File getEvidenceXmlFile(){
		return new File(getEvidenceXmlDirName() + "/" + getTestCaseName() + ".xml")
    }

	def File getEvidenceXmlFile(id){
		return new File(getEvidenceXmlDirName() + "/" + getTestCaseName() + "_${id}.xml")
    }

	def File getLatestEvidenceXmlFile(){
		return new File(getLatestEvidenceXmlDirName() + "/" + getTestCaseName() + ".xml")
	}

	def File getExpectedEvidenceDataDir(){
		return new File(getExpectedEvidenceDataDirName())
	}

	def File getExpectedEvidenceDataDir(String subDir){
		return new File(getExpectedEvidenceDataDirName(subDir))
	}

	def File getExpectedEvidenceDataFile(String fileName){
		return new File(getExpectedEvidenceDataDirName() + "/" + fileName)
	}

	def File getLatestEvidenceXmlFile(id){
		return new File(getLatestEvidenceXmlDirName() + "/" + getTestCaseName() + "_${id}.xml")
	}
	
	def setProjectProperties(key, value){
		context.testCase.getTestSuite().getProject().setPropertyValue(key,value)
	}

	def setProperties(key, value){
		def testCase = getTestStepInSameCase(SoapuiDefines.COMMON_TEST_STEP_NAME)
		testCase.setPropertyValue(key, value)	
	}

	def setPropertiesOtherTestCase(String testCaseName, key, value){
		def testCase = getTestCaseInSameSuite(testCaseName)
		def properties = getTestStepInOtherCase(testCase, SoapuiDefines.COMMON_TEST_STEP_NAME)
		properties.setPropertyValue(key, value)	
	}
	
	def setPropertiesOtherTestSuite(String testSuiteName, String testCaseName, key, value){
		def testCase = getTestCaseInOtherSuite(testSuiteName, testCaseName)
		def properties = getTestStepInOtherCase(testCase, SoapuiDefines.COMMON_TEST_STEP_NAME)
		properties.setPropertyValue(key, value)	
	}


	def getProperties(key){
		def testCase = getTestStepInSameCase(SoapuiDefines.COMMON_TEST_STEP_NAME)
		return testCase.getPropertyValue(key)	
	}

	def getPropertiesOtherTestSuite(String testSuiteName, String testCaseName, key){
		def testCase = getTestCaseInOtherSuite(testSuiteName, testCaseName)
		def properties = getTestStepInOtherCase(testCase, SoapuiDefines.COMMON_TEST_STEP_NAME)
		properties.getPropertyValue(key)	
	}

	def getProjectProperty(String key){
		return context.expand("\${" + SoapuiDefines.PROJECT_PROP_HEADER + "#$key}")
	}
	
	def getTestSuiteProperty(String key){
		return context.testCase.testSuite.getProperty("${key}").value
	}
	
	def getTestCaseProperty(String key){
		return context.testCase.getProperty("${key}").value
	}

	def List<List> createListFromDataSource(String dataSourceName){
		def dataSourceGrid = getDataSourceGrid(dataSourceName)
		return createListFromDataSourceCore(dataSourceGrid)
	}

	def List<List> createListFromDataSource(def testRunner, String dataSourceName, List colNumberList){
		def dataSourceGrid = getDataSourceGrid(dataSourceName, testRunner)
		return createListFromDataSourceCore(dataSourceGrid, colNumberList)
	}

	private List<List> createListFromDataSourceCore(def dataSourceGrid, List colNumberList){
		List<List> dataSourceValsList = []
		for(int lineNumber in 0..(dataSourceGrid.rowCount-2)){
			dataSourceValsList << fetchDataSource1LineVals(colNumberList, dataSourceGrid, lineNumber)
		}
		return dataSourceValsList
	}

	private List<List> createListFromDataSourceCore(def dataSourceGrid){
		List<List> dataSourceValsList = []
		for(int lineNumber in 0..(dataSourceGrid.rowCount-2)){
			dataSourceValsList << fetchDataSource1LineVals(dataSourceGrid, lineNumber)
		}
		return dataSourceValsList
	}

	def getDataSourceGrid(String dataSourceName, def testRunner) {
		return testRunner.testCase.testSteps[dataSourceName].dataSource.gridModel
	}

	def getDataSourceGrid(String dataSourceName) {
		return context.testCase.testSteps[dataSourceName].dataSource.gridModel
	}

	def getDataSourceOriginNumber(){
		if(isSoapUI()) {
			return 0
		} else {
			return 1
		}
	}

	private List fetchDataSource1LineVals(def dataSourceGrid, int lineNumber) {
		List dataSource1LineVals = []
		int startNumber = getDataSourceOriginNumber()
		for(int colNumber in startNumber..dataSourceGrid.getColumnCount()-1){
			dataSource1LineVals << context.expand(dataSourceGrid.getValueAt(lineNumber, colNumber))
		}
		return dataSource1LineVals
	}

	private List fetchDataSource1LineVals(List colNumberList, def dataSourceGrid, int lineNumber) {
		List dataSource1LineVals = []
		for(int colNumber in colNumberList){
			dataSource1LineVals << context.expand(dataSourceGrid.getValueAt(lineNumber, colNumber))
		}
		return dataSource1LineVals
	}

	public void setRandomCallBackPort(){
		int port =  Math.random()*RANDOM_RANGE + BASE_PORT
		String callbackURL = com.eviware.soapui.SoapUI.globalProperties.getPropertyValue(CALLBACK_URL)
		def splitUrl = callbackURL.split(":")
		String newCallbackURL = splitUrl[0] + ":" + splitUrl[1] + ":"  + port
		com.eviware.soapui.SoapUI.globalProperties.setPropertyValue(CALLBACK_PORT, port as String)
		com.eviware.soapui.SoapUI.globalProperties.setPropertyValue(CALLBACK_URL, newCallbackURL)
	}

    public void log(String str) {
        try{
            context.log.info(str)
        }catch (NullPointerException e){
            // From CUI, above log object is null.
        }
    }
		
	public boolean isCml(){
		return getGlobalTimEngine() == CML
	}

	public boolean isSoapUI(){
		return getGlobalIsSoapUI() == "true"
	}
}
