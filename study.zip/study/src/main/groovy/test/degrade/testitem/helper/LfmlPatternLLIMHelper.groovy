package test.degrade.testitem.helper

import static test.common.constants.aim.SearchLFMLParameter.*


class LfmlPatternLLIMHelper {
    
	private static final List S_AUTO_F_AUTO_SL3_RAW_SCORE_LIST = [ 
        2560, 916, 1463, 3494, 809, 1608, 1737, 1773, 671, 2335, 2149, 1433, 1664, 868, 1567, 1235 ]
	private static final List S_AUTO_F_MANUAL_SL3_RAW_SCORE_LIST = [ 
        898, 1612, 916, 1463, 3494, 809, 1608, 1737, 1773, 671, 1542, 1948, 2089, 335, 1434, 539]
	private static final List S_AUTO_F_MANUAL_MULTI_AXIS_A_SL3_RAW_SCORE_LIST = [ 
        1203, 1390, 1407, 1555, 1950, 1928, 2146, 1725, 2291, 804, 2598, 2398, 2237, 789, 2143, 580]
	private static final List S_AUTO_F_MANUAL_MULTI_AXIS_B_SL3_RAW_SCORE_LIST = [ 
        1697, 1390, 1407, 1555, 1950, 1928, 2146, 1725, 2291, 804, 2598, 2398, 2237, 789, 2143, 580]
	private static final List S_AUTO_F_MANUAL_MULTI_AXIS_C_SL3_RAW_SCORE_LIST = [ 
        1789, 1390, 1407, 1555, 1950, 1928, 2146, 1725, 2291, 804, 2598, 2398, 2237, 789, 2143, 580]
	private static final List S_AUTO_F_MANUAL_MULTI_AXIS_D_SL3_RAW_SCORE_LIST = [ 
        1805, 1390, 1407, 1555, 1950, 1928, 2146, 1725, 2291, 804, 2598, 2398, 2237, 789, 2143, 580]
	private static final List S_MANUAL_F_AUTO_SL3_RAW_SCORE_LIST = [ 
        998, 1690, 1040, 1668, 3424, 794, 1533, 1796, 1806, 670, 1488, 2045, 2084, 334, 1410, 539]
	private static final List S_MANUAL_F_MANUAL_SL3_RAW_SCORE_LIST = [ 
        1287, 2560, 1644, 1463, 3494, 809, 1608, 1737, 1773, 76, 32767, 590, 32767, 171, 32767, 106]
	private static final List S_MANUAL_F_MANUAL_MULTI_AXIS_A_SL3_RAW_SCORE_LIST = [ 
        413, 1168, 1323, 1555, 1950, 1928, 2146, 1725, 2291, 407, 1783, 888, 2231, 387, 2029, 45]
	private static final List S_MANUAL_F_MANUAL_MULTI_AXIS_B_SL3_RAW_SCORE_LIST = [ 
        593, 1168, 1323, 1555, 1950, 1928, 2146, 1725, 2291, 407, 1783, 888, 2231, 387, 2029, 45]
	private static final List S_MANUAL_F_AUTO_MULTI_AXIS_A_SL3_RAW_SCORE_LIST = [ 
       	8378, 0, 0, 0, 69, 181, 57, 0, 0, 0, 0, 0, 0, 0, 0, 0 ]
	private static final List S_MANUAL_MULTI_AXIS_A_F_MANUAL_SL3_RAW_SCORE_LIST = [ 
       	634, 0, 0, 0, 0, 0, 0, 126, 0, 53, 0, 119, 0, 0, 0, 0 ]
	private static final List S_AUTO_F_AUTO_SL3_ROTATION_1_RAW_SCORE_LIST = [ 
        2560, 923, 1552, 3600, 974, 1608, 1741, 1806, 651, 2420, 2149, 1433, 1653, 868, 1287, 1314 ]
	private static final List S_AUTO_F_AUTO_SL3_ROTATION_2_RAW_SCORE_LIST = [
        2560, 916, 1463, 3494, 809, 1603, 1737, 1773, 671, 2335, 2149, 1433, 1664, 868, 1567, 1235 ]
	private static final List S_AUTO_F_MANUAL_SL3_ROTATION_1_RAW_SCORE_LIST = [
        898, 1612, 923, 1552, 3600, 974, 1608, 1741, 1806, 651, 1660, 1948, 2089, 512, 1434, 542]
	private static final List S_AUTO_F_MANUAL_SL3_ROTATION_2_RAW_SCORE_LIST = [
        898, 1612, 916, 1463, 3494, 809, 1603, 1737, 1773, 671, 1542, 1968, 2089, 335, 1434, 526]
	private static final List S_MANUAL_F_AUTO_MULTI_AXIS_A_SL3_ROTATION_2_RAW_SCORE_LIST = [ 
       	8378, 0, 0, 0, 108, 181, 134, 0, 0, 0, 0, 0, 0, 0, 121, 66 ]
	private static final List S_MANUAL_MULTI_AXIS_A_F_MANUAL_SL3_ROTATION_2_RAW_SCORE_LIST = [ 
       	634, 0, 0, 0, 0, 0, 0, 0, 24, 0, 0, 119, 0, 31, 0, 0 ]
	

    private static final String A = "A"
    private static final String B = "B"
    private static final String C = "C"
    private static final String D = "D"


    private List rawScoreList
    private List rawScoreSIndexList
    private List rawScoreFIndexList
    private int score = -1

    public void setup(boolean isSManual, boolean isFManual, int searchLevel) {
        if(isSManual && isFManual) {
            if(searchLevel == 3) {
                rawScoreList = S_MANUAL_F_MANUAL_SL3_RAW_SCORE_LIST
                rawScoreFIndexList = S_MANUAL_F_MANUAL_SL3_FILE_INDEX_LIST
                rawScoreSIndexList = S_MANUAL_F_MANUAL_SL3_SEARCH_INDEX_LIST
            }
        }else if(isSManual && !isFManual) {
            if(searchLevel == 3) {
                rawScoreList = S_MANUAL_F_AUTO_SL3_RAW_SCORE_LIST
                rawScoreFIndexList = S_MANUAL_F_AUTO_SL3_FILE_INDEX_LIST
                rawScoreSIndexList = S_MANUAL_F_AUTO_SL3_SEARCH_INDEX_LIST
            }
        }else if(!isSManual && isFManual) {
            if(searchLevel == 3) {
                rawScoreList = S_AUTO_F_MANUAL_SL3_RAW_SCORE_LIST
                rawScoreFIndexList = S_AUTO_F_MANUAL_SL3_FILE_INDEX_LIST
                rawScoreSIndexList = S_AUTO_F_MANUAL_SL3_SEARCH_INDEX_LIST
            }
        }else if(!isSManual && !isFManual) {
            if(searchLevel == 3) {
                rawScoreList = S_AUTO_F_AUTO_SL3_RAW_SCORE_LIST
                rawScoreFIndexList = S_AUTO_F_AUTO_SL3_FILE_INDEX_LIST
                rawScoreSIndexList = S_AUTO_F_AUTO_SL3_SEARCH_INDEX_LIST
            }
        }
    }

    public void setupMultiAxis(boolean isSManual, boolean isFManual, String axis) {
        if(isSManual && isFManual) {
        	rawScoreFIndexList = S_MANUAL_F_MANUAL_SL3_FILE_INDEX_LIST
        	rawScoreSIndexList = S_MANUAL_F_MANUAL_SL3_SEARCH_INDEX_LIST
            if(axis == A) {
                rawScoreList = S_MANUAL_F_MANUAL_MULTI_AXIS_A_SL3_RAW_SCORE_LIST
            }else if(axis == B) {
                rawScoreList = S_MANUAL_F_MANUAL_MULTI_AXIS_B_SL3_RAW_SCORE_LIST
            }else{
                assert false, "Axis value of Properties test step must be A or B!! Actual '${axis}'."
            }
        }else if(!isSManual && isFManual) {
        	rawScoreFIndexList = S_AUTO_F_MANUAL_SL3_FILE_INDEX_LIST
        	rawScoreSIndexList = S_AUTO_F_MANUAL_SL3_SEARCH_INDEX_LIST
            if(axis == A) {
                rawScoreList = S_AUTO_F_MANUAL_MULTI_AXIS_A_SL3_RAW_SCORE_LIST
            }else if(axis == B) {
                rawScoreList = S_AUTO_F_MANUAL_MULTI_AXIS_B_SL3_RAW_SCORE_LIST
            }else if(axis == C) {
                rawScoreList = S_AUTO_F_MANUAL_MULTI_AXIS_C_SL3_RAW_SCORE_LIST
            }else if(axis == D) {
                rawScoreList = S_AUTO_F_MANUAL_MULTI_AXIS_D_SL3_RAW_SCORE_LIST
            }
        }else if(isSManual && !isFManual) {
        	rawScoreFIndexList = S_MANUAL_F_AUTO_SL3_FILE_INDEX_LIST
        	rawScoreSIndexList = S_MANUAL_F_AUTO_SL3_SEARCH_INDEX_LIST
            if(axis == A) {
                rawScoreList = S_MANUAL_F_AUTO_MULTI_AXIS_A_SL3_RAW_SCORE_LIST
            }else if(axis == B) {
                rawScoreList = []
            }else{
                assert false, "Axis value of Properties test step must be A or B!! Actual '${axis}'."
            }
        }
    }

    public void setupNotUseMultiAxis(boolean isSManual, boolean isFManual, String axis) {
        if(isSManual && isFManual) {
            rawScoreFIndexList = S_MANUAL_F_MANUAL_SL3_FILE_INDEX_LIST
            rawScoreSIndexList = S_MANUAL_F_MANUAL_SL3_SEARCH_INDEX_LIST
            if(axis == A) {
                rawScoreList = S_MANUAL_MULTI_AXIS_A_F_MANUAL_SL3_RAW_SCORE_LIST
            }else if(axis == B) {
                rawScoreList = []
            }else{
                assert false, "Axis value of Properties test step must be A or B!! Actual '${axis}'."
            }
        }else if(isSManual && !isFManual) {
            rawScoreFIndexList = S_MANUAL_F_AUTO_SL3_FILE_INDEX_LIST
            rawScoreSIndexList = S_MANUAL_F_AUTO_SL3_SEARCH_INDEX_LIST
            if(axis == A) {
                rawScoreList = S_MANUAL_F_AUTO_MULTI_AXIS_A_SL3_RAW_SCORE_LIST
            }else if(axis == B) {
                rawScoreList = []
            }else{
                assert false, "Axis value of Properties test step must be A or B!! Actual '${axis}'."
            }
        }
    }

    public void setupRotation(boolean isSManual, boolean isFManual, int searchLevel, int rotationLimit) {
        if(!isSManual && isFManual) {
            rawScoreFIndexList = S_AUTO_F_MANUAL_SL3_FILE_INDEX_LIST
            rawScoreSIndexList = S_AUTO_F_MANUAL_SL3_SEARCH_INDEX_LIST
            if(rotationLimit == 1) {
                rawScoreList = S_AUTO_F_MANUAL_SL3_ROTATION_1_RAW_SCORE_LIST
            }else if(rotationLimit == 2) {
                rawScoreList = S_AUTO_F_MANUAL_SL3_ROTATION_2_RAW_SCORE_LIST
            }

        }else if(!isSManual && !isFManual) {
            rawScoreFIndexList = S_AUTO_F_AUTO_SL3_FILE_INDEX_LIST
            rawScoreSIndexList = S_AUTO_F_AUTO_SL3_SEARCH_INDEX_LIST
            if(rotationLimit == 1) {
                rawScoreList = S_AUTO_F_AUTO_SL3_ROTATION_1_RAW_SCORE_LIST
            }else if(rotationLimit == 2) {
                rawScoreList = S_AUTO_F_AUTO_SL3_ROTATION_2_RAW_SCORE_LIST
            }
        }
    }

    public void setupNotUseMultiAxisRotation(boolean isSManual, boolean isFManual, String axis, int rotationLimit) {
        if(isSManual && isFManual) {
            rawScoreFIndexList = S_MANUAL_F_MANUAL_SL3_FILE_INDEX_LIST
            rawScoreSIndexList = S_MANUAL_F_MANUAL_SL3_SEARCH_INDEX_LIST
			if(rotationLimit == 2){
            	if(axis == A) {
               		rawScoreList = S_MANUAL_MULTI_AXIS_A_F_MANUAL_SL3_ROTATION_2_RAW_SCORE_LIST
            	}else if(axis == B) {
                	rawScoreList = []
            	}else{
               		assert false, "Axis value of Properties test step must be A or B!! Actual '${axis}'."
            	}
            }
        }else if(isSManual && !isFManual) {
            rawScoreFIndexList = S_MANUAL_F_AUTO_SL3_FILE_INDEX_LIST
            rawScoreSIndexList = S_MANUAL_F_AUTO_SL3_SEARCH_INDEX_LIST
			if(rotationLimit == 2){
            	if(axis == A) {
                	rawScoreList = S_MANUAL_F_AUTO_MULTI_AXIS_A_SL3_ROTATION_2_RAW_SCORE_LIST
            	}else if(axis == B) {
               		rawScoreList = []
            	}else{
                	assert false, "Axis value of Properties test step must be A or B!! Actual '${axis}'."
            	}
			}
        }
    }

    public int getScore() {
        if(score != -1) {
            return score
        }

        score = 0
        for(rScore in rawScoreList) {
            score += rScore as int
        }

		if(rawScoreList.size() != 0){
        	score /= rawScoreList.size()
		}
		if(9999 <= score){
			score = 9999
		}
        return score
    }

    public List getRawScoreList() {
        return rawScoreList
    }

    public List getRawSearchIndexList() {
        return rawScoreSIndexList
    }

    public List getRawFileIndexList() {
        return rawScoreFIndexList
    }
}

