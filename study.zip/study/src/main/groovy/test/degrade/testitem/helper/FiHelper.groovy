package test.degrade.testitem.helper

import static test.common.constants.aim.AIMXmlAttribute.*

class FiHelper extends ConsolidationHelper {

	private static final String GEN_M_EXT_ID = "M"
	private static final String GEN_F_EXT_ID = "F"
	private static final String GEN_U_EXT_ID = "U"

	private static final String NUMBER_01 = "00001"
	private static final String NUMBER_02 = "00002"
	private static final String NUMBER_03 = "00003"
	private static final String NUMBER_04 = "00004"
	private static final String NUMBER_05 = "00005"
	private static final String NUMBER_06 = "00006"
	private static final String NUMBER_07 = "00007"
	private static final String NUMBER_08 = "00008"
	private static final String NUMBER_09 = "00009"
	private static final String NUMBER_10 = "00010"
	private static final String NUMBER_11 = "00011"
	private static final String NUMBER_12 = "00012"

	private static final String F1_EXT_ID = "FI1-"
	private static final String F2_EXT_ID = "FI2-"
	private static final String F3_EXT_ID = "FI3-"
	private static final String F4_EXT_ID = "FI4-"
	private static final String F5_EXT_ID = "FI5-"
	private static final String F6_EXT_ID = "FI6-"
	private static final String F7_EXT_ID = "FI7-"
	private static final String F8_EXT_ID = "FI8-"
	private static final String F9_EXT_ID = "FI9-"
	private static final String F10_EXT_ID = "FI10-"
	private static final String F11_EXT_ID = "FI11-"
	private static final String F12_EXT_ID = "FI12-"
	private static final String F13_EXT_ID = "FI13-"
	private static final String F14_EXT_ID = "FI14-"
	private static final String F15_EXT_ID = "FI15-"
	private static final String F16_EXT_ID = "FI16-"
	private static final String F17_EXT_ID = "FI17-"
	private static final String F18_EXT_ID = "FI18-"
	private static final String F19_EXT_ID = "FI19-"
	
	private static final int MAX_SCORE = 9999
	private static final int ZERO_SCORE = 0
	private static final int ROT_BY_AXIS_SCORE = 8688
	private static final int BASIC_SCORE_1 = 342
	private static final int BASIC_SCORE_2 = 260
	private static final int BASIC_SCORE_3 = 251

	private int basic_score_1 
	private int basic_score_2
	private int basic_score_3
	
	private Integer FW = 100
	private int eventId = 1
	private int reqIndexZero = 0

	private int sortHighScore_1_10F
	private int sortLowScore_1F
	private int sortLowScore_2_10F

	private List GEN_M_CAND_INFO_LIST = []
	private List GEN_F_CAND_INFO_LIST = []
	private List GEN_U_CAND_INFO_LIST = []

	private List F1_PREFILTER_CAND_INFO_LIST_1 = []
	private List F1_PREFILTER_CAND_INFO_LIST_2 = []
	private List F1_PREFILTER_CAND_INFO_LIST_3 = []
	
	private List F2_USE_GENDER_CAND_INFO_LIST_1 = []
	private List F2_USE_GENDER_CAND_INFO_LIST_2 = []
	private List F2_USE_GENDER_CAND_INFO_LIST_3 = []
	
	private List F3_GENDER_CAND_INFO_LIST_1 = []
	private List F3_GENDER_CAND_INFO_LIST_2 = []
	private List F3_GENDER_CAND_INFO_LIST_3 = []

	private List F4_USE_YOB_CAND_INFO_LIST_1 = []
	private List F4_USE_YOB_CAND_INFO_LIST_2 = []
	private List F4_USE_YOB_CAND_INFO_LIST_3 = []

	private List F5_YOB_CAND_INFO_LIST_01 = []
	private List F5_YOB_CAND_INFO_LIST_02 = []
	private List F5_YOB_CAND_INFO_LIST_03 = []
	private List F5_YOB_CAND_INFO_LIST_04 = []
	private List F5_YOB_CAND_INFO_LIST_05 = []
	private List F5_YOB_CAND_INFO_LIST_06 = []
	private List F5_YOB_CAND_INFO_LIST_07 = []
	private List F5_YOB_CAND_INFO_LIST_08 = []
	private List F5_YOB_CAND_INFO_LIST_09 = []
	private List F5_YOB_CAND_INFO_LIST_10 = []
	private List F5_YOB_CAND_INFO_LIST_11 = []

	private List F6_USE_RACE_CAND_INFO_LIST_1 = []
	private List F6_USE_RACE_CAND_INFO_LIST_2 = []
	private List F6_USE_RACE_CAND_INFO_LIST_3 = []
	
	private List F7_RACE_CAND_INFO_LIST_1 = []
	private List F7_RACE_CAND_INFO_LIST_2 = []
	private List F7_RACE_CAND_INFO_LIST_3 = []
	private List F7_RACE_CAND_INFO_LIST_4 = []
	
	private List F8_USE_REGION_CAND_INFO_LIST_1 = []
	private List F8_USE_REGION_CAND_INFO_LIST_2 = []
	private List F8_USE_REGION_CAND_INFO_LIST_3 = []

	private List F9_REGION_CAND_INFO_LIST_1 = []
	private List F9_REGION_CAND_INFO_LIST_2 = []
	private List F9_REGION_CAND_INFO_LIST_3 = []
	private List F9_REGION_CAND_INFO_LIST_4 = []
	
	private List F10_COLD_SEARCH_CAND_INFO_LIST_01 = []		
	private List F10_COLD_SEARCH_CAND_INFO_LIST_02 = []		
	private List F10_COLD_SEARCH_CAND_INFO_LIST_03 = []	
	private List F10_COLD_SEARCH_CAND_INFO_LIST_04 = []	
	private List F10_COLD_SEARCH_CAND_INFO_LIST_05 = []	
	private List F10_COLD_SEARCH_CAND_INFO_LIST_06 = []	
	private List F10_COLD_SEARCH_CAND_INFO_LIST_07 = []	
	private List F10_COLD_SEARCH_CAND_INFO_LIST_08 = []	
	private List F10_COLD_SEARCH_CAND_INFO_LIST_09 = []	
	private List F10_COLD_SEARCH_CAND_INFO_LIST_10 = []	
	
	private List F11_CONSOLIDATE_CAND_INFO_LIST_1 = []
	private List F11_CONSOLIDATE_CAND_INFO_LIST_2 = []

	private List F13_LOC_CAND_INFO_LIST_1 = []
	private List F13_LOC_CAND_INFO_LIST_2 = []
	private List F13_LOC_CAND_INFO_LIST_3 = []

	private List F14_MIN_CAND_INFO_LIST_1 = []
	private List F14_MIN_CAND_INFO_LIST_2 = []
	private List F14_MIN_CAND_INFO_LIST_3 = []

	private List F17_TARGET_DB_CAND_INFO_LIST_1 = []
	private List F17_TARGET_DB_CAND_INFO_LIST_2 = []
	private List F17_TARGET_DB_CAND_INFO_LIST_3 = []
	
	private List F15_DYN_CAND_INFO_LIST_1 = []
	private List F15_DYN_CAND_INFO_LIST_2 = []
	private List F15_DYN_CAND_INFO_LIST_3 = []
	private List F15_DYN_CAND_INFO_LIST_4 = []
	private List F15_DYN_CAND_INFO_LIST_5 = []
	
	private List F16_AFIS_CAND_INFO_LIST_1 = []
	private List F16_AFIS_CAND_INFO_LIST_2 = []
	private List F16_AFIS_CAND_INFO_LIST_3 = []
	
	private List F17_SCOPE12_CAND_INFO_LIST_1 = []
	private List F17_SCOPE12_CAND_INFO_LIST_2 = []

	private List F18_SCOPE123_CAND_INFO_LIST_1 = []
	private List F18_SCOPE123_CAND_INFO_LIST_2 = []
	private List F18_SCOPE123_CAND_INFO_LIST_3 = []
	
	private List F19_FW_CAND_INFO_LIST_1 = []
	
	private List MAX_INDIVIDUAL_SCORES = [] 
	private List ROT_BY_AXIS_INDIVIDUAL_SCORES = []
	private	List MAX_SCORE_CANDIDATE_1 = []
	private	List MAX_SCORE_CANDIDATE_SCOPE2_1 = []
	private	List MAX_SCORE_CANDIDATE_SCOPE3_1 = []
	private List BASIC_SCORE_CANDIDATE_1 = []
	private List BASIC_SCORE_CANDIDATE_2 = []
	private List BASIC_SCORE_CANDIDATE_3 = []

	FiHelper(context){
		super(context)
		initCandInfoLists()
	}

	FiHelper(context, String level){
		super(context)
		setNullFwIfHighLevel(level)
		initCandInfoLists()
	}

	private void initCandInfoLists() {
		initScores()
		initCommonCandInfoList()
		initGenderCandInfoList()
		initYobCandInfoList()
		initRaceCandInfoList()
		initRegionCandInfoList()
		initColdSearchCandInfoList()
		initConsolidateCandInfoList()
		initLocCandInfoList()
		initMinCandInfoList()
		initDynCandInfoList()
		initAfisCandInfoList()
		initScopeCandInfoList()
		initFWeightCandInfoList()
	}

	private void initScores() {
		basic_score_1 = mergeFWeight(BASIC_SCORE_1, FW)
		basic_score_2 = mergeFWeight(BASIC_SCORE_2, FW)
		basic_score_3 = mergeFWeight(BASIC_SCORE_3, FW)
	}

	private void initCommonCandInfoList(){
		
		MAX_INDIVIDUAL_SCORES =
				[	[ MAX_SCORE, null, null, FW ] ] 

		ROT_BY_AXIS_INDIVIDUAL_SCORES = 
			[	[  1, eventId, reqIndexZero, MAX_SCORE,
					[	[ ROT_BY_AXIS_SCORE, FIN_1, A, FW ],
						[ ROT_BY_AXIS_SCORE, FIN_2, A, FW ],
						[ ROT_BY_AXIS_SCORE, FIN_3, A, FW ],
						[ ROT_BY_AXIS_SCORE, FIN_4, A, FW ],
						[ ROT_BY_AXIS_SCORE, FIN_5, A, FW ],
						[ ROT_BY_AXIS_SCORE, FIN_6, A, FW ],
						[ ROT_BY_AXIS_SCORE, FIN_7, A, FW ],
						[ ROT_BY_AXIS_SCORE, FIN_8, A, FW ],
						[ ROT_BY_AXIS_SCORE, FIN_9, A, FW ],
						[ ROT_BY_AXIS_SCORE, FIN_10, A, FW ] ] ] ]
		
		MAX_SCORE_CANDIDATE_1 =
			 [ [ 335, eventId, reqIndexZero, MAX_SCORE, MAX_INDIVIDUAL_SCORES ]]
		MAX_SCORE_CANDIDATE_SCOPE2_1 =
			 [ [ 1335, eventId, reqIndexZero, MAX_SCORE, MAX_INDIVIDUAL_SCORES ]]
		MAX_SCORE_CANDIDATE_SCOPE3_1 =
			 [ [ 2335, eventId, reqIndexZero, MAX_SCORE, MAX_INDIVIDUAL_SCORES ]]
	
		BASIC_SCORE_CANDIDATE_1 =
			[ [ 335, eventId, reqIndexZero, basic_score_1,
				[   [ BASIC_SCORE_1, null, null, FW ] ] ] ]
		
		BASIC_SCORE_CANDIDATE_2 =
			[ [ 335, eventId, reqIndexZero, basic_score_2,
				[   [ BASIC_SCORE_2, null, null, FW ] ] ] ]

		BASIC_SCORE_CANDIDATE_3 =
			[ [ 335, eventId, reqIndexZero, basic_score_3,
				[   [ BASIC_SCORE_3, null, null, FW ] ] ] ]


		F1_PREFILTER_CAND_INFO_LIST_1 = 
	         [ F1_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F1_PREFILTER_CAND_INFO_LIST_2 = 
	         [ F1_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F1_PREFILTER_CAND_INFO_LIST_3 = 
	         [ F1_EXT_ID + NUMBER_03, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
	}

	private void initGenderCandInfoList(){

		F2_USE_GENDER_CAND_INFO_LIST_1 =
			[ F2_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F2_USE_GENDER_CAND_INFO_LIST_2 =
			[ F2_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F2_USE_GENDER_CAND_INFO_LIST_3 =
			[ F2_EXT_ID + NUMBER_03, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]

		F3_GENDER_CAND_INFO_LIST_1 =
			 [ F3_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F3_GENDER_CAND_INFO_LIST_2 =
			 [ F3_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F3_GENDER_CAND_INFO_LIST_3 =
			 [ F3_EXT_ID + NUMBER_03, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]

	}

	private void initYobCandInfoList(){
		F4_USE_YOB_CAND_INFO_LIST_1 =
			 [ F4_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F4_USE_YOB_CAND_INFO_LIST_2 =
			 [ F4_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F4_USE_YOB_CAND_INFO_LIST_3 =
			 [ F4_EXT_ID + NUMBER_03, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
	
		F5_YOB_CAND_INFO_LIST_01 =
			 [ F5_EXT_ID + "01964", MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F5_YOB_CAND_INFO_LIST_02 =
			 [ F5_EXT_ID + "01969", MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F5_YOB_CAND_INFO_LIST_03 =
			 [ F5_EXT_ID + "01970", MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F5_YOB_CAND_INFO_LIST_04 =
			 [ F5_EXT_ID + "01973", MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F5_YOB_CAND_INFO_LIST_05 =
			 [ F5_EXT_ID + "01974", MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F5_YOB_CAND_INFO_LIST_06 =
			 [ F5_EXT_ID + "01984", MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F5_YOB_CAND_INFO_LIST_07 =
			 [ F5_EXT_ID + "01985", MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F5_YOB_CAND_INFO_LIST_08 =
			 [ F5_EXT_ID + "01988", MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F5_YOB_CAND_INFO_LIST_09 =
			 [ F5_EXT_ID + "01989", MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F5_YOB_CAND_INFO_LIST_10 =
			 [ F5_EXT_ID + "01994", MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F5_YOB_CAND_INFO_LIST_11 =
			 [ F5_EXT_ID + "99999", MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
	}

	private void initRaceCandInfoList(){
		F6_USE_RACE_CAND_INFO_LIST_1 =
			[ F6_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ] 
		F6_USE_RACE_CAND_INFO_LIST_2 =
			[ F6_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ] 
		F6_USE_RACE_CAND_INFO_LIST_3 =
			[ F6_EXT_ID + NUMBER_03, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ] 

		F7_RACE_CAND_INFO_LIST_1 =
			 [ F7_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F7_RACE_CAND_INFO_LIST_2 =
			 [ F7_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F7_RACE_CAND_INFO_LIST_3 =
			 [ F7_EXT_ID + NUMBER_03, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F7_RACE_CAND_INFO_LIST_4 =
			 [ F7_EXT_ID + NUMBER_04, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
	}

	private void initRegionCandInfoList(){
		F8_USE_REGION_CAND_INFO_LIST_1 =
			[ F8_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ] 
		F8_USE_REGION_CAND_INFO_LIST_2 =
			[ F8_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ] 
		F8_USE_REGION_CAND_INFO_LIST_3 =
			[ F8_EXT_ID + NUMBER_03, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ] 

		F9_REGION_CAND_INFO_LIST_1 =
			 [ F9_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F9_REGION_CAND_INFO_LIST_2 =
			 [ F9_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F9_REGION_CAND_INFO_LIST_3 =
			 [ F9_EXT_ID + NUMBER_03, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F9_REGION_CAND_INFO_LIST_4 =
			 [ F9_EXT_ID + NUMBER_04, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
	}

	private void initColdSearchCandInfoList(){
		F10_COLD_SEARCH_CAND_INFO_LIST_01 =
		 	 [ F10_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F10_COLD_SEARCH_CAND_INFO_LIST_02 =
		 	 [ F10_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F10_COLD_SEARCH_CAND_INFO_LIST_03 =
		 	 [ F10_EXT_ID + NUMBER_03, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F10_COLD_SEARCH_CAND_INFO_LIST_04 =
		 	 [ F10_EXT_ID + NUMBER_04, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F10_COLD_SEARCH_CAND_INFO_LIST_05 =
		 	 [ F10_EXT_ID + NUMBER_05, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F10_COLD_SEARCH_CAND_INFO_LIST_06 =
		 	 [ F10_EXT_ID + NUMBER_06, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F10_COLD_SEARCH_CAND_INFO_LIST_07 =
		 	 [ F10_EXT_ID + NUMBER_07, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F10_COLD_SEARCH_CAND_INFO_LIST_08 =
		 	 [ F10_EXT_ID + NUMBER_08, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F10_COLD_SEARCH_CAND_INFO_LIST_09 =
		 	 [ F10_EXT_ID + NUMBER_09, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F10_COLD_SEARCH_CAND_INFO_LIST_10 =
		 	 [ F10_EXT_ID + NUMBER_10, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
    
    }


	private void initConsolidateCandInfoList(){
		F11_CONSOLIDATE_CAND_INFO_LIST_1 = 
			[ F11_EXT_ID + NUMBER_01, basic_score_1, true, 
				[ [ 335, eventId, reqIndexZero, basic_score_1,
					[	[ BASIC_SCORE_1, null, null, FW ] ] ] ,
				  [ 1335, eventId, reqIndexZero, basic_score_1,
					[	[ BASIC_SCORE_1, null, null, FW ] ] ] ] ]
	}
	
	private void initLocCandInfoList(){
		for(int i = 1; i <= 3; i++){
			String num = "0000" + i
			F13_LOC_CAND_INFO_LIST_1.add([ F13_EXT_ID + num, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ])
		}
		
		for(int j = 1; j <= 255; j++){
			String num	
			if(j < 10){
				num = "0000" + j
			}else if(j< 100){
				num = "000" + j
			}else{
				num = "00" + j
			}
			F13_LOC_CAND_INFO_LIST_2.add([ F13_EXT_ID + num, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ])
		}

		for(int k = 1; k <= 10; k++){
			String num	
			if(k < 10){
				num = "0000" + k
			}else if(k< 100){
                num = "000" + k
            }else{
                num = "00" + k
			}	
			F13_LOC_CAND_INFO_LIST_3.add([ F13_EXT_ID + num, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ])
		}
	}
	
	private void initMinCandInfoList(){
		F14_MIN_CAND_INFO_LIST_1 = 
			[ F14_EXT_ID + NUMBER_02, basic_score_2, true, BASIC_SCORE_CANDIDATE_2 ]
		F14_MIN_CAND_INFO_LIST_2 = 
			[ F14_EXT_ID + NUMBER_03, basic_score_3, true, BASIC_SCORE_CANDIDATE_3 ]
		F14_MIN_CAND_INFO_LIST_3 = 
			[ F14_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
	}

	private void initDynCandInfoList(){
		F15_DYN_CAND_INFO_LIST_1 = 
			[ F15_EXT_ID + NUMBER_02, basic_score_2, true, BASIC_SCORE_CANDIDATE_2 ]
		F15_DYN_CAND_INFO_LIST_2 = 
			[ F15_EXT_ID + NUMBER_03, basic_score_3, true, BASIC_SCORE_CANDIDATE_3 ]
		F15_DYN_CAND_INFO_LIST_3 = 
			[ F15_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F15_DYN_CAND_INFO_LIST_4 = 
			[ F15_EXT_ID + NUMBER_02, basic_score_2, false, BASIC_SCORE_CANDIDATE_2 ]
		F15_DYN_CAND_INFO_LIST_5 = 
			[ F15_EXT_ID + NUMBER_03, basic_score_3, false, BASIC_SCORE_CANDIDATE_3 ]
	}

	private void initAfisCandInfoList(){
		F16_AFIS_CAND_INFO_LIST_1 = 
			 [ F16_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F16_AFIS_CAND_INFO_LIST_2 = 
			 [ F16_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F16_AFIS_CAND_INFO_LIST_3 = 
			 [ F16_EXT_ID + NUMBER_03, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
	}

	private void initScopeCandInfoList(){
		F17_SCOPE12_CAND_INFO_LIST_1 =
             [ F17_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F17_SCOPE12_CAND_INFO_LIST_2 =
             [ F17_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_SCOPE2_1 ]
		
		
		F18_SCOPE123_CAND_INFO_LIST_1 =
             [ F18_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F18_SCOPE123_CAND_INFO_LIST_2 =
             [ F18_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_SCOPE2_1 ]
		F18_SCOPE123_CAND_INFO_LIST_3 =
             [ F18_EXT_ID + NUMBER_03, MAX_SCORE, true, MAX_SCORE_CANDIDATE_SCOPE3_1 ]

	}

	private void initFWeightCandInfoList(){
		F19_FW_CAND_INFO_LIST_1 = 
			[ F19_EXT_ID + NUMBER_01, basic_score_2, true, BASIC_SCORE_CANDIDATE_2 ]
	
	}
	
	private int calcFusionScore_roll_slap() {
		return calcFusionScore_roll_slap(PC2_1_R_SCORE, FMP5_1_R_SCORE)
	}

	private int calcFusionScore_roll_slap(int rollScore, int slapScore) {
		rollScore = mergeFWeight(rollScore, FW)
		slapScore = mergeFWeight(slapScore, FW)
		int fScore = rollScore + slapScore
		return cutoffScore(fScore)
	}

	public List getCandList_UpdatePrefilter_1(){
        initCandInfoLists()
        return [
               F1_PREFILTER_CAND_INFO_LIST_1,
               F1_PREFILTER_CAND_INFO_LIST_3
               ]
    }

	public List getCandList_UpdatePrefilter_2(){
        initCandInfoLists()
        return [
               F1_PREFILTER_CAND_INFO_LIST_2,
               F1_PREFILTER_CAND_INFO_LIST_3
               ]
    }

	public List getCandList_UseGender_1(){
        initCandInfoLists()
        return [ 
				F2_USE_GENDER_CAND_INFO_LIST_1,
				F2_USE_GENDER_CAND_INFO_LIST_3
			   ]
	}

	public List getCandList_UseGender_2(){
        initCandInfoLists()
        return [ 
				F2_USE_GENDER_CAND_INFO_LIST_2,
				F2_USE_GENDER_CAND_INFO_LIST_3
			   ]
	}

	public List getCandList_UseGender_3(){
        initCandInfoLists()
        return [ 
				F2_USE_GENDER_CAND_INFO_LIST_1,
				F2_USE_GENDER_CAND_INFO_LIST_2,
				F2_USE_GENDER_CAND_INFO_LIST_3
			   ]
	}

	public List getCandList_Gender_1(){
        initCandInfoLists()
        return [ 
				F3_GENDER_CAND_INFO_LIST_1,
				F3_GENDER_CAND_INFO_LIST_3
			   ]
	}
	
	public List getCandList_Gender_2(){
        initCandInfoLists()
        return [
                F3_GENDER_CAND_INFO_LIST_2,
                F3_GENDER_CAND_INFO_LIST_3 
			   ]
	}
	
	public List getCandList_Gender_3(){
        initCandInfoLists()
        return [
				F3_GENDER_CAND_INFO_LIST_1,
				F3_GENDER_CAND_INFO_LIST_2,
                F3_GENDER_CAND_INFO_LIST_3 
			   ]
	}
	
	public List getCandList_UseYob_1(){
        initCandInfoLists()
        return [ 
				F4_USE_YOB_CAND_INFO_LIST_2
			   ]
	}

	public List getCandList_UseYob_2(){
        initCandInfoLists()
        return [ 
				F4_USE_YOB_CAND_INFO_LIST_3
			   ]
	}

	public List getCandList_UseYob_3(){
        initCandInfoLists()
        return [ 
				F4_USE_YOB_CAND_INFO_LIST_1,
				F4_USE_YOB_CAND_INFO_LIST_2,
				F4_USE_YOB_CAND_INFO_LIST_3
			   ]
	}

	public List getCandList_Yob_1(){
        initCandInfoLists()
        return [ 
				F5_YOB_CAND_INFO_LIST_01,
				F5_YOB_CAND_INFO_LIST_02,
				F5_YOB_CAND_INFO_LIST_03,
				F5_YOB_CAND_INFO_LIST_04,
				F5_YOB_CAND_INFO_LIST_05,
				F5_YOB_CAND_INFO_LIST_06,
				F5_YOB_CAND_INFO_LIST_07,
				F5_YOB_CAND_INFO_LIST_08,
				F5_YOB_CAND_INFO_LIST_09,
				F5_YOB_CAND_INFO_LIST_10,
				F5_YOB_CAND_INFO_LIST_11
			   ]
    }

	public List getCandList_Yob_2(){
        initCandInfoLists()
        return [
				F5_YOB_CAND_INFO_LIST_01,
				F5_YOB_CAND_INFO_LIST_05,
				F5_YOB_CAND_INFO_LIST_06,
				F5_YOB_CAND_INFO_LIST_10,
				F5_YOB_CAND_INFO_LIST_11
			   ]
    }

	public List getCandList_Yob_3(){
        initCandInfoLists()
        return [ 
				F5_YOB_CAND_INFO_LIST_03,
				F5_YOB_CAND_INFO_LIST_04,
				F5_YOB_CAND_INFO_LIST_05,
				F5_YOB_CAND_INFO_LIST_06,
				F5_YOB_CAND_INFO_LIST_07,
				F5_YOB_CAND_INFO_LIST_08,
				F5_YOB_CAND_INFO_LIST_11
			   ]
    }

	public List getCandList_Yob_4(){
        initCandInfoLists()
        return [ 
				F5_YOB_CAND_INFO_LIST_06,
				F5_YOB_CAND_INFO_LIST_07,
				F5_YOB_CAND_INFO_LIST_08,
				F5_YOB_CAND_INFO_LIST_09,
				F5_YOB_CAND_INFO_LIST_10,
				F5_YOB_CAND_INFO_LIST_11
			   ]
    }

	public List getCandList_UseRace_1(){
        initCandInfoLists()
        return [ 
				F6_USE_RACE_CAND_INFO_LIST_1,
				F6_USE_RACE_CAND_INFO_LIST_2,
				F6_USE_RACE_CAND_INFO_LIST_3
			   ]
	}

	public List getCandList_UseRace_2(){
        initCandInfoLists()
        return [ 
				F6_USE_RACE_CAND_INFO_LIST_1,
				F6_USE_RACE_CAND_INFO_LIST_3
			   ]
	}

	public List getCandList_UseRace_3(){
        initCandInfoLists()
        return [ 
				F6_USE_RACE_CAND_INFO_LIST_2,
				F6_USE_RACE_CAND_INFO_LIST_3
			   ]
	}

	public List getCandList_Race_1(){
        initCandInfoLists()
        return [ 
				F7_RACE_CAND_INFO_LIST_1,
				F7_RACE_CAND_INFO_LIST_4
			   ]
	}

	public List getCandList_Race_2(){
        initCandInfoLists()
        return [ 
				F7_RACE_CAND_INFO_LIST_1,
				F7_RACE_CAND_INFO_LIST_2,
				F7_RACE_CAND_INFO_LIST_3,
				F7_RACE_CAND_INFO_LIST_4
			   ]
	}

	public List getCandList_UseRegion_1(){
        initCandInfoLists()
        return [ 
				F8_USE_REGION_CAND_INFO_LIST_1,
				F8_USE_REGION_CAND_INFO_LIST_2,
				F8_USE_REGION_CAND_INFO_LIST_3
			   ]
	}

	public List getCandList_UseRegion_2(){
        initCandInfoLists()
        return [ 
				F8_USE_REGION_CAND_INFO_LIST_1,
				F8_USE_REGION_CAND_INFO_LIST_3
			   ]
	}

	public List getCandList_UseRegion_3(){
        initCandInfoLists()
        return [ 
				F8_USE_REGION_CAND_INFO_LIST_2,
				F8_USE_REGION_CAND_INFO_LIST_3
			   ]
	}
	
	public List getCandList_Region_1(){
        initCandInfoLists()
        return [ 
				F9_REGION_CAND_INFO_LIST_1,
				F9_REGION_CAND_INFO_LIST_4
			   ]
	}

	public List getCandList_Region_2(){
        initCandInfoLists()
        return [ 
				F9_REGION_CAND_INFO_LIST_1,
				F9_REGION_CAND_INFO_LIST_2,
				F9_REGION_CAND_INFO_LIST_3,
				F9_REGION_CAND_INFO_LIST_4
			   ]
	}

	public List getCandList_ColdSearch_1(){
		initCandInfoLists()
        return [	F10_COLD_SEARCH_CAND_INFO_LIST_01,
					F10_COLD_SEARCH_CAND_INFO_LIST_02,
					F10_COLD_SEARCH_CAND_INFO_LIST_03,
					F10_COLD_SEARCH_CAND_INFO_LIST_04,
					F10_COLD_SEARCH_CAND_INFO_LIST_05,
					F10_COLD_SEARCH_CAND_INFO_LIST_06,
					F10_COLD_SEARCH_CAND_INFO_LIST_07,
					F10_COLD_SEARCH_CAND_INFO_LIST_08,
					F10_COLD_SEARCH_CAND_INFO_LIST_09,
					F10_COLD_SEARCH_CAND_INFO_LIST_10
				]
    }

	public List getCandList_Consolidate_1(){
		initCandInfoLists()
        return [ F11_CONSOLIDATE_CAND_INFO_LIST_1 ]
    }

	public List getCandList_TargetDb_1(){
		initCandInfoLists()
        return [ F17_TARGET_DB_CAND_INFO_LIST_1 ]
    }

	public List getCandList_TargetDb_2(){
		initCandInfoLists()
        return [ F17_TARGET_DB_CAND_INFO_LIST_2 ]
    }
		
	public List getCandList_TargetDb_3(){
		initCandInfoLists()
        return [ F17_TARGET_DB_CAND_INFO_LIST_1,
				 F17_TARGET_DB_CAND_INFO_LIST_3 ]
    }

	public List getCandList_Loc_1(){
		initCandInfoLists()
		return F13_LOC_CAND_INFO_LIST_1
	}

	public List getCandList_Loc_2(){
		initCandInfoLists()
		return F13_LOC_CAND_INFO_LIST_2
	}
	
	public List getCandList_Loc_3(){
		initCandInfoLists()
		return F13_LOC_CAND_INFO_LIST_3
	}

	public List getCandList_Min_1(){
		initCandInfoLists()
        return [ F14_MIN_CAND_INFO_LIST_1,
				 F14_MIN_CAND_INFO_LIST_2,
				 F14_MIN_CAND_INFO_LIST_3 ]
    }

    public List getCandList_Min_2(){
		initCandInfoLists()
		return [ F14_MIN_CAND_INFO_LIST_1,
                 F14_MIN_CAND_INFO_LIST_3 ]
    }

    public List getCandList_Min_3(){
		initCandInfoLists()
        return [ F14_MIN_CAND_INFO_LIST_3 ]
	}

	public List getCandList_Dyn_1(){
		initCandInfoLists()
        return [ F15_DYN_CAND_INFO_LIST_1,
        		 F15_DYN_CAND_INFO_LIST_2,
				 F15_DYN_CAND_INFO_LIST_3 ]
    }

    public List getCandList_Dyn_2(){
		initCandInfoLists()
        return [ F15_DYN_CAND_INFO_LIST_1,
        		 F15_DYN_CAND_INFO_LIST_5,
				 F15_DYN_CAND_INFO_LIST_3 ]
    }

    public List getCandList_Dyn_3(){
		initCandInfoLists()
		return [ F15_DYN_CAND_INFO_LIST_4,
                 F15_DYN_CAND_INFO_LIST_5,
                 F15_DYN_CAND_INFO_LIST_3 ]
    }
	
	public List getCandList_afis_1() {
        initCandInfoLists()
        return [    F16_AFIS_CAND_INFO_LIST_1,
					F16_AFIS_CAND_INFO_LIST_2,
					F16_AFIS_CAND_INFO_LIST_3 ]
    }

	public List getCandList_scope12_1() {
		initCandInfoLists()
		return [	F17_SCOPE12_CAND_INFO_LIST_1 ]
	}

	public List getCandList_scope12_2() {
		initCandInfoLists()
		return [	F17_SCOPE12_CAND_INFO_LIST_2 ]
	}

	public List getCandList_scope12_3() {
		initCandInfoLists()
		return [	F17_SCOPE12_CAND_INFO_LIST_1,
					F17_SCOPE12_CAND_INFO_LIST_2 ]
	}
	
	public List getCandList_scope123_1() {
		initCandInfoLists()
		return [	F18_SCOPE123_CAND_INFO_LIST_1,
					F18_SCOPE123_CAND_INFO_LIST_2 ]
	}

	public List getCandList_fWeight_1_to_1_01(Integer FW) {
		this.FW = FW
		initCandInfoLists()
		return [ F19_FW_CAND_INFO_LIST_1 ]
	}

	private void setNullFwIfHighLevel(String level){
		if(level == "high") {
			this.FW = null
		}else{
			this.FW = null
		}
	}
}


