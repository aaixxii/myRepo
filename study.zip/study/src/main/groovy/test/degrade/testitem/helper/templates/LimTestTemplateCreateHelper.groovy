package test.degrade.testitem.helper.templates

import test.degrade.testitem.helper.*
import static test.common.constants.data.ImageDataList.*

class LimTestTemplateCreateHelper extends TestTemplateCreateHelper{

    LimTestTemplateCreateHelper(context){
		super(context)
    }

	public String getDefaultFileImage(){
		return imgXmlMaker.getTenprintFingerImgXml(TF_027_RS_NST)
	}

	public String getDefaultSearchImage(){
		return imgXmlMaker.getLatentFingerImgXml(LF_005_WSQ)
	}

	def getPatternFileImage(){
		return imgXmlMaker.getTenprintFingerImgXml(TF_025_RS_NST) 
	}

	def getPatternSearchImage(){
		return imgXmlMaker.getLatentFingerImgXml(LF_002_WSQ)
	}

	def getAdjacentPatternFileImage(){
		return imgXmlMaker.getTenprintFingerImgXml(TF_026_RS_NST) 
	}

	def getAdjacentPatternSearchImage_1(){
		return imgXmlMaker.getLatentFingerImgXml(LF_003_WSQ)
	}

	def getAdjacentPatternSearchImage_2(){
		return imgXmlMaker.getLatentFingerImgXml(LF_004_WSQ)
	}

	def getLFMLOptionFileImage(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_028_RS_NST)
    }

    def getLFMLOptionSearchImage(){
        return imgXmlMaker.getLatentFingerImgXml(LF_006_WSQ)
    }

	def getExternalIdFileImage_1(){
		return imgXmlMaker.getTenprintFingerImgXml(TF_038_RS_NST)
	}

	def getExternalIdFileImage_2(){
		return imgXmlMaker.getTenprintFingerImgXml(TF_039_RS_NST)
	}

	def getExternalIdSearchImage(){
		return imgXmlMaker.getLatentFingerImgXml(LF_015_WSQ)
	}
    def getFingerNoFileImage(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_008_RS_NST)
    }

    def getFingerNoSearchImage_1(){
        return imgXmlMaker.getLatentFingerImgXml(LF_016_WSQ)
    }

    def getFingerNoSearchImage_2(){
        return imgXmlMaker.getLatentFingerImgXml(LF_017_WSQ)
    }
    def getFingerNoSearchImage_3(){
        return imgXmlMaker.getLatentFingerImgXml(LF_018_WSQ)
    }
}
