package test.degrade.testitem.helper

import static test.common.constants.aim.AIMXmlAttribute.*

class LliConsolidationHelper extends ConsolidationHelper {

	private static final String F201_EXT_ID = "LLI_F201A"
	private static final String F202_EXT_ID = "LLI_F202A"
	private static final String F203_EXT_ID = "LLI_F203A"
	private static final String F204_EXT_ID = "LLI_F204A"
	private static final String F205_EXT_ID = "LLI_F205A"
	private static final String F_123_ABC_HIGH_EXT_ID = "LLI-123-ABC-High"
	private static final String F_ABC_123_HIGH_EXT_ID = "LLI-ABC-123-High"
	private static final String F_BBC_123_HIGH_EXT_ID = "LLI-BBC-123-High"
	private static final String F_123_ABC_LOW_EXT_ID = "LLI-123-ABC-Low"
	private static final String F_ABC_123_LOW_EXT_ID = "LLI-ABC-123-Low"
	private static final String F_BBC_123_LOW_EXT_ID = "LLI-BBC-123-Low"

	private static final int FMP5_SCORE = 3028
	private static final int FMP5_SCORE_A = 3059
	private static final int FMP5_SCORE_B = 3472
	private static final int FMP5_SCORE_C = FMP5_SCORE_B
	private static final int FMP5_SCORE_D = 2917
	private static final int FMP5_SCORE_A_NOTHING_B = 3799
	private static final int FMP5_SCORE_C_NOTHING_B = FMP5_SCORE_D
	private static final int FMP5_SCORE_D_NOTHING_B = 3480
	private static final int PC2_SCORE = 2194

	private Integer fmp5FW = 100
	private Integer pc2FW = 100
	private int fmp5ReqIndex = 0
	private int pc2ReqIndex = 1
	private int fmp5Score
	private int pc2Score
	private int fmp5Pc2Score

	private List F201A_CAND_INFO_LIST_BY_PC2 = []
	private List F202A_CAND_INFO_LIST_BY_FMP5 = []
	private List F203A_CAND_INFO_LIST_BY_BOTH = []
	private List F203A_CAND_INFO_LIST_BY_BOTH_2SCOPE = []
	private List F204A_CAND_INFO_LIST_BY_FMP5_A = []
	private List F204A_CAND_INFO_LIST_BY_FMP5_B = []
	private List F204A_CAND_INFO_LIST_BY_FMP5_C = []
	private List F204A_CAND_INFO_LIST_BY_FMP5_D = []
	private List F205A_CAND_INFO_LIST_BY_BOTH_A = []
	private List F205A_CAND_INFO_LIST_BY_FMP5_C = []
	private List F205A_CAND_INFO_LIST_BY_FMP5_D = []
	private List F_123_ABC_HIGH_CAND_INFO_LIST = []
	private List F_ABC_123_HIGH_CAND_INFO_LIST = []
	private List F_BBC_123_HIGH_CAND_INFO_LIST = []
	private List F_123_ABC_LOW_CAND_INFO_LIST = []
	private List F_ABC_123_LOW_CAND_INFO_LIST = []
	private List F_BBC_123_LOW_CAND_INFO_LIST = []

	LliConsolidationHelper(context){
		super(context)
		initCandInfoLists()
	}

	LliConsolidationHelper(context, String level){
		super(context)
		initCandInfoLists()
	}

	private void initCandInfoLists() {
		initScores()
		initFmp5CandInfoLists()
		initPc2CandInfoLists()
		initBothCandInfoLists()
	}

	private void initScores() {
		fmp5Score = mergeFWeight(FMP5_SCORE, fmp5FW)
		pc2Score = mergeFWeight(PC2_SCORE, pc2FW)
		fmp5Pc2Score = cutoffScore(pc2Score + fmp5Score)
	}


	private void initFmp5CandInfoLists() {
		F202A_CAND_INFO_LIST_BY_FMP5 = 
			[ F202_EXT_ID, fmp5Score, true, 
				[ [ 321, 1, fmp5ReqIndex, fmp5Score,
					[ [ FMP5_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ] ] 
			]
		F204A_CAND_INFO_LIST_BY_FMP5_A = 
			[ F204_EXT_ID, FMP5_SCORE_A, true, 
				[ [ 321, 1, fmp5ReqIndex, FMP5_SCORE_A,
					[ [ FMP5_SCORE_A, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ] ] 
			]
		F204A_CAND_INFO_LIST_BY_FMP5_B = 
			[ F204_EXT_ID, FMP5_SCORE_B, true, 
				[ [ 321, 1, fmp5ReqIndex, FMP5_SCORE_B,
					[ [ FMP5_SCORE_B, FIN_1, B, FMP5_LATENT, fmp5FW ] ] ] ] 
			]
		F204A_CAND_INFO_LIST_BY_FMP5_C = 
			[ F204_EXT_ID, FMP5_SCORE_C, true, 
				[ [ 321, 1, fmp5ReqIndex, FMP5_SCORE_C,
					[ [ FMP5_SCORE_C, FIN_1, C, FMP5_LATENT, fmp5FW ] ] ] ] 
			]
		F204A_CAND_INFO_LIST_BY_FMP5_D = 
			[ F204_EXT_ID, FMP5_SCORE_D, true, 
				[ [ 321, 1, fmp5ReqIndex, FMP5_SCORE_D,
					[ [ FMP5_SCORE_D, FIN_1, D, FMP5_LATENT, fmp5FW ] ] ] ] 
			]
		F205A_CAND_INFO_LIST_BY_FMP5_C = 
			[ F205_EXT_ID, FMP5_SCORE_C_NOTHING_B, true, 
				[ [ 321, 1, fmp5ReqIndex, FMP5_SCORE_C_NOTHING_B,
					[ [ FMP5_SCORE_C_NOTHING_B, FIN_1, C, FMP5_LATENT, fmp5FW ] ] ] ] 
			]
		F205A_CAND_INFO_LIST_BY_FMP5_D = 
			[ F205_EXT_ID, FMP5_SCORE_D_NOTHING_B, true, 
				[ [ 321, 1, fmp5ReqIndex, FMP5_SCORE_D_NOTHING_B,
					[ [ FMP5_SCORE_D_NOTHING_B, FIN_1, D, FMP5_LATENT, fmp5FW ] ] ] ] 
			]
		F_123_ABC_LOW_CAND_INFO_LIST = 
			[ F_123_ABC_LOW_EXT_ID, fmp5Score, true, 
				[ F202A_CAND_INFO_LIST_BY_FMP5[3][0],
				  [ 1321, 1, fmp5ReqIndex, fmp5Score,
					[ [ FMP5_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ] ]
			]
		F_ABC_123_LOW_CAND_INFO_LIST = 
			[ F_ABC_123_LOW_EXT_ID, fmp5Score, true, F_123_ABC_LOW_CAND_INFO_LIST[3] ] 
		F_BBC_123_LOW_CAND_INFO_LIST = 
			[ F_BBC_123_LOW_EXT_ID, fmp5Score, true, F_123_ABC_LOW_CAND_INFO_LIST[3] ] 
	}

	private void initPc2CandInfoLists() {
		F201A_CAND_INFO_LIST_BY_PC2 = 
			[ F201_EXT_ID, pc2Score, true, 
				[ [ 326, 1, pc2ReqIndex, pc2Score,
					[ [ PC2_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ] ]
			]
	}

	private void initBothCandInfoLists() {
		F203A_CAND_INFO_LIST_BY_BOTH = 
			[ F203_EXT_ID, fmp5Pc2Score, true, 
				[ [ 321, 1, fmp5ReqIndex, fmp5Score,
					[ [ FMP5_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ], 
				  [ 326, 1, pc2ReqIndex, pc2Score,
					[ [ PC2_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ] ]
			]
		F203A_CAND_INFO_LIST_BY_BOTH_2SCOPE = 
			[ F203_EXT_ID, fmp5Pc2Score, true, 
				[ F203A_CAND_INFO_LIST_BY_BOTH[3][0],
				  F203A_CAND_INFO_LIST_BY_BOTH[3][1],
				  [ 1321, 1, fmp5ReqIndex, fmp5Score,
					[ [ FMP5_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ], 
				  [ 1326, 1, pc2ReqIndex, pc2Score,
					[ [ PC2_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ] ]
			]
		F205A_CAND_INFO_LIST_BY_BOTH_A = 
			[ F205_EXT_ID, FMP5_SCORE_A_NOTHING_B + pc2Score, true, 
				[ [ 321, 1, fmp5ReqIndex, FMP5_SCORE_A_NOTHING_B,
					[ [ FMP5_SCORE_A_NOTHING_B, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ], 
				  [ 326, 1, pc2ReqIndex, pc2Score,
					[ [ PC2_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ] ]
			]
		F_123_ABC_HIGH_CAND_INFO_LIST = 
			[ F_123_ABC_HIGH_EXT_ID, fmp5Pc2Score, true, 
				[ F203A_CAND_INFO_LIST_BY_BOTH[3][0],
				  F203A_CAND_INFO_LIST_BY_BOTH[3][1],
				  [ 1321, 1, fmp5ReqIndex, fmp5Score,
					[ [ FMP5_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ], 
				  [ 1326, 1, pc2ReqIndex, pc2Score,
					[ [ PC2_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ] ]
			]
		F_ABC_123_HIGH_CAND_INFO_LIST = 
			[ F_ABC_123_HIGH_EXT_ID, fmp5Pc2Score, true, F_123_ABC_HIGH_CAND_INFO_LIST[3] ]
		F_BBC_123_HIGH_CAND_INFO_LIST = 
			[ F_BBC_123_HIGH_EXT_ID, fmp5Pc2Score, true, F_123_ABC_HIGH_CAND_INFO_LIST[3] ]
	}

	public List getCandList_inquirySet() {
		return [ F203A_CAND_INFO_LIST_BY_BOTH ]
	}

	public List getCandList_muMerge() {
		return [ F201A_CAND_INFO_LIST_BY_PC2,
				F202A_CAND_INFO_LIST_BY_FMP5,
				F203A_CAND_INFO_LIST_BY_BOTH ]
	}

	public List getCandList_scope() {
		return [ F203A_CAND_INFO_LIST_BY_BOTH_2SCOPE ]
	}

	public List getCandList_multiAxis_false() {
		return [ F204A_CAND_INFO_LIST_BY_FMP5_A,
				F204A_CAND_INFO_LIST_BY_FMP5_B,
				F204A_CAND_INFO_LIST_BY_FMP5_C,
				F204A_CAND_INFO_LIST_BY_FMP5_D ]
	}

	public List getCandList_multiAxis_false_withPc2() {
		return [ F205A_CAND_INFO_LIST_BY_BOTH_A,
				F205A_CAND_INFO_LIST_BY_FMP5_C,
				F205A_CAND_INFO_LIST_BY_FMP5_D ]
	}

	public List getCandList_multiAxis_true() {
		return [ F204A_CAND_INFO_LIST_BY_FMP5_B ]
	}

	public List getCandList_multiAxis_true_withPc2() {
		return [ F205A_CAND_INFO_LIST_BY_BOTH_A ]
	}

	public List getCandList_fWeight(Integer fmp5FW, Integer pc2FW) {
		this.fmp5FW = fmp5FW
		this.pc2FW = pc2FW
		initCandInfoLists()
		return [ F203A_CAND_INFO_LIST_BY_BOTH ]
	}

	public List getCandList_fWeight_multi(Integer fmp5FW, Integer pc2FW) {
		this.fmp5FW = fmp5FW
		this.pc2FW = pc2FW
		initCandInfoLists()
		return [ F201A_CAND_INFO_LIST_BY_PC2,
				F202A_CAND_INFO_LIST_BY_FMP5,
				F203A_CAND_INFO_LIST_BY_BOTH ]
	}

	public List getCandList_candSort() {
		return [ F_123_ABC_HIGH_CAND_INFO_LIST,
				F_ABC_123_HIGH_CAND_INFO_LIST,
				F_BBC_123_HIGH_CAND_INFO_LIST,
				F_123_ABC_LOW_CAND_INFO_LIST,
				F_ABC_123_LOW_CAND_INFO_LIST,
				F_BBC_123_LOW_CAND_INFO_LIST ]
	}
}

