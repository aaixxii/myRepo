package test.degrade.testitem.helper

import static test.common.constants.data.ImageDataList.*
import static test.common.constants.aim.AIMImgType.*
import static test.common.constants.aim.AIMBioPosition.*

class ExtractCMLHelper  extends TestTemplateCreateHelper{ 
	
	private def posImgPathMap
	private static final int IMAGE_WIDHT=512
	private static final int IMAGE_HEIGHT=512
	private def imageType
	private static final List EXT_ID_LIST = [ "EXT1", "EXT2", "EXT3" ]
	private static final List SHUFFLE_EXT_ID_LIST = [ "EXT1", "EXT2" ]

	//PositionList
	private static final List SORT_POS_LIST= [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 ]
	private static final List FILE_1_VS_1_PARAM_101_POS_LIST= [  3, 2,  -1, 4, 10, 6, 7, 8, 9, -1 ]
	private static final List FILE_1_VS_2_PARAM_101_POS_LIST= [ ]
	private static final List FILE_1_VS_3_PARAM_101_POS_LIST= [ ]
	private static final List FILE_1_VS_1_PARAM_111_POS_LIST= [  1, 10, -1, 4, -1,  6,  7,  8, -1, -1 ]
	private static final List FILE_1_VS_2_PARAM_111_POS_LIST= [  1,  5, -1, 4, -1,  6,  7,  8,  9, -1 ]
	private static final List FILE_1_VS_3_PARAM_111_POS_LIST= [  3,  5, -1, 4, -1,  6,  7,  8,  9, -1 ]
	private static final List FILE_2_VS_1_PARAM_201_POS_LIST= [ -1,  2,  3, 4, 10,  6,  7,  8,  9, -1 ]
	private static final List FILE_2_VS_2_PARAM_201_POS_LIST= [  1,  2,  3, 4,  5,  6,  7, -1,  9, -1 ]
	private static final List FILE_2_VS_3_PARAM_201_POS_LIST= [  1,  2, -1, 4, -1, -1,  7, -1,  8, -1 ]
	private static final List FILE_2_VS_1_PARAM_211_POS_LIST= [  1, -1,  3, 4, -1,  6,  7,  8, -1, -1 ]
	private static final List FILE_2_VS_2_PARAM_211_POS_LIST= [  1,  5,  3, 4, -1,  6,  7,  8,  9, -1 ]
	private static final List FILE_2_VS_3_PARAM_211_POS_LIST= [  1,  5,  3, 4, -1,  6,  7,  8,  9, -1 ]
	private static final List FILE_3_VS_1_PARAM_301_POS_LIST= [ ] 
	private static final List FILE_3_VS_2_PARAM_301_POS_LIST= [  1,  2,  3, 4, -1, -1,  7, -1,  9, 10 ]
	private static final List FILE_3_VS_3_PARAM_301_POS_LIST= [  1,  2, -1, 4, -1, -1,  7, -1,  8, -1 ]
	private static final List FILE_3_VS_1_PARAM_311_POS_LIST= [  1, -1,  3, 4, -1,  6, -1,  8, -1, 10 ]
	private static final List FILE_3_VS_2_PARAM_311_POS_LIST= [  1,  5,  3, 4, -1,  6,  7,  8,  9, 10 ]
	private static final List FILE_3_VS_3_PARAM_311_POS_LIST= [  1,  5,  3, 4, -1,  6,  7,  8,  9, 10 ]

	//ScoreList Image:STRAIGHT
	//SearchParameterId = 1XX
	private static final List FILE_1_VS_1_PARAM_100_SCORE_LIST= [ 9999, 9999, 0, 0, 2394, 3135, 0, 646, 7272, 0, 1668, 2745 ]
	private static final List FILE_1_VS_2_PARAM_100_SCORE_LIST= [ 9999, 9999, 0, 0, 1107, 2623, 0, 1170,  6709, 0,  1878, 2465 ]
	private static final List FILE_1_VS_3_PARAM_100_SCORE_LIST= [ 2976, 2976, 0, 138, -168, 0, 0, 16,  2744, 0,  -148, 394 ]
	private static final List FILE_1_VS_1_PARAM_101_SCORE_LIST= [ 2128, 2128, -186, 0, 0, 0, 0, 646, 0, 0, 1668, 0 ]
	private static final List FILE_1_VS_2_PARAM_101_SCORE_LIST= [ ]
	private static final List FILE_1_VS_3_PARAM_101_SCORE_LIST= [ ]
	private static final List FILE_1_VS_1_PARAM_110_SCORE_LIST= [ 9999, 9999, 0, 0, 6281, 5721, 0, 0, 8539, 9999, 1848, 2142 ]
	private static final List FILE_1_VS_2_PARAM_110_SCORE_LIST= [ 9999, 9999, 0, 0, 5413, 5262, 0, 0, 7675, 9999, 1863, 2119 ]
	private static final List FILE_1_VS_3_PARAM_110_SCORE_LIST= [ 9999, 9999, 1405, 0, 4046, 1134, 0, 1298, 3664, 0, -88, 0 ]
	private static final List FILE_1_VS_1_PARAM_111_SCORE_LIST= [ 9999, 9999, 0, 0, 0, 5721, 0, 0, 8539, 9999, 0, 0 ]
	private static final List FILE_1_VS_2_PARAM_111_SCORE_LIST= [ 9999, 9999, 0, 0, 0, 5262, 0, 0, 0, 9999, 1863, 0 ]
	private static final List FILE_1_VS_3_PARAM_111_SCORE_LIST= [ 2304, 2304, -128, 0, 0, 1134, 0, 1298, 0, 0, 0, 0 ]

	//SearchParameterId = 2XX
	private static final List FILE_2_VS_1_PARAM_200_SCORE_LIST= [ 6505, 6505, 0, 0, 2334, 0, 0, 2047, 0, 0, 2124, 0 ]
	private static final List FILE_2_VS_2_PARAM_200_SCORE_LIST= [ 6743, 6743, 0, 0, 2578, 0, 0, 2297, 0, 0, 1868, 0 ]
	private static final List FILE_2_VS_3_PARAM_200_SCORE_LIST= [ ]
	private static final List FILE_2_VS_1_PARAM_201_SCORE_LIST= [ 6505, 6505, 0, 0, 2334, 0, 0, 2047, 0, 0, 2124, 0 ]
	private static final List FILE_2_VS_2_PARAM_201_SCORE_LIST= [ 6743, 6743, 0, 0, 2578, 0, 0, 2297, 0, 0, 1868, 0 ]
	private static final List FILE_2_VS_3_PARAM_201_SCORE_LIST= [ 4213, 4213, 0, 138, 0, 0, 0, 0, 4275,   0, -200, 0 ]
	private static final List FILE_2_VS_1_PARAM_210_SCORE_LIST= [ 9999, 9999, 0, 0, 9999, 5591, 0, 0, 0, 0, 2136, 0 ]
	private static final List FILE_2_VS_2_PARAM_210_SCORE_LIST= [ 9999, 9999, 0, 0, 7410, 6158, 0, 0, 0, 0, 1606, 0 ]
	private static final List FILE_2_VS_3_PARAM_210_SCORE_LIST= [ 9386, 9386, 0, 0, 5936, 502,  0, 2948, 0, 0, 0, 0 ]
	private static final List FILE_2_VS_1_PARAM_211_SCORE_LIST= [ 9999, 9999, 0, 0, 9999, 5591, 0, 0, 0, 9999, 0, 0 ]
	private static final List FILE_2_VS_2_PARAM_211_SCORE_LIST= [ 9999, 9999, 0, 0, 7410, 6158, 0, 0, 0, 0, 1606, 0 ]
	private static final List FILE_2_VS_3_PARAM_211_SCORE_LIST= [ 9386, 9386, 0, 0, 5936, 502,  0, 2948, 0, 0, 0, 0 ]

	//SearchParameterId = 3XX
	private static final List FILE_3_VS_1_PARAM_300_SCORE_LIST= [ 9999, 9999, 3612, 878, 0, 4057, 0, 854, 0, 6230, 0, -136 ]
	private static final List FILE_3_VS_2_PARAM_300_SCORE_LIST= [ 9999, 9999, 3518, 1043, 0, 3578, 0, 1257, 0, 4956, 0, -126 ]
	private static final List FILE_3_VS_3_PARAM_300_SCORE_LIST= [ 9999, 9999, 9999, 1670, 0, 2564, 0, 63, 0, 0, 49, 1803 ]
	private static final List FILE_3_VS_1_PARAM_301_SCORE_LIST= [ ]
	private static final List FILE_3_VS_2_PARAM_301_SCORE_LIST= [ 4495, 4495, 0, 1043, 0, 3578, 0, 0, 0, 0, 0, -126 ]
	private static final List FILE_3_VS_3_PARAM_301_SCORE_LIST= [ 9999, 9999, 9999, 1670, 0, 2564, 0, 0, 0, 0, 0, 0,]
	private static final List FILE_3_VS_1_PARAM_310_SCORE_LIST= [ 5755, 5755, 0, 0, 2356, 707, 0, 0, 2920, -106, -64, -58 ]
	private static final List FILE_3_VS_2_PARAM_310_SCORE_LIST= [ 5679, 5679, 0, 0, 2242, 837, 0, 0, 2828, -106, -64, -58 ]
	private static final List FILE_3_VS_3_PARAM_310_SCORE_LIST= [ 9999, 9999, 888, 0, 5909, 8339, 0, 0, 5076, 9401, 2376, 0 ]
	private static final List FILE_3_VS_1_PARAM_311_SCORE_LIST= [ 2957, 2957, 0, 0, 2356, 707, 0, 0, 0, -106, 0, 0 ]
	private static final List FILE_3_VS_2_PARAM_311_SCORE_LIST= [ 2973, 2973, 0, 0, 2242, 837, 0, 0, 0, -106, 0, 0 ]
	private static final List FILE_3_VS_3_PARAM_311_SCORE_LIST= [ 9999, 9999, 0, 0, 5909, 8339, 0, 0, 0, 0, 2376, 0 ]

	//ScoreList Image:SHUFFLE
	//Use shuffle image SearchParameterId = 1XX 
	private static final List STRAIGHT_VS_STRAIGHT_PARAM_100_SCORE_LIST= [ 9999, 9999, 0, 0, 2394, 3135, 0, 646, 7272, 0, 1668, 2745 ]
	private static final List STRAIGHT_VS_SHUFFLE_PARAM_100_SCORE_LIST= [ ]
	private static final List SHUFFLE_VS_STRAIGHT_PARAM_100_SCORE_LIST= [ ]
	private static final List SHUFFLE_VS_SHUFFLE_PARAM_100_SCORE_LIST= [ ]
	private static final List STRAIGHT_VS_STRAIGHT_PARAM_101_SCORE_LIST= [ 2128, 2128, -186, 0, 0, 0, 0, 646, 0, 0, 1668, 0 ]
	private static final List STRAIGHT_VS_SHUFFLE_PARAM_101_SCORE_LIST=  [ 2128, 2128, -186, 0, 0, 0, 0, 646, 0, 0, 1668, 0 ]
	private static final List SHUFFLE_VS_STRAIGHT_PARAM_101_SCORE_LIST=  [ 2128, 2128, 0, 0, 0, -186, 0, 0, 1668, 0, 646, 0 ] 
	private static final List SHUFFLE_VS_SHUFFLE_PARAM_101_SCORE_LIST=   [ 2128, 2128, 0, 0, 0, -186, 0, 0, 1668, 0, 646, 0 ]

	private static final List STRAIGHT_VS_STRAIGHT_PARAM_110_SCORE_LIST= [ 9999, 9999, 0, 0, 6281, 5721, 0, 0, 8539, 9999, 1848, 2142 ]
	private static final List STRAIGHT_VS_SHUFFLE_PARAM_110_SCORE_LIST= [ ]
	private static final List SHUFFLE_VS_STRAIGHT_PARAM_110_SCORE_LIST= [ ]
	private static final List SHUFFLE_VS_SHUFFLE_PARAM_110_SCORE_LIST= [ ]
	private static final List STRAIGHT_VS_STRAIGHT_PARAM_111_SCORE_LIST= [ 9999, 9999, 0, 0, 0, 5721, 0, 0, 8539, 9999, 0, 0 ]
	private static final List STRAIGHT_VS_SHUFFLE_PARAM_111_SCORE_LIST= [ 9999, 9999, 0, 0, 0, 5721, 0, 0, 8539, 9999, 0, 0 ]
	private static final List SHUFFLE_VS_STRAIGHT_PARAM_111_SCORE_LIST= [ 9999, 9999, 0, 5721, 0, 0, 0, 9999, 0, 0, 0, 8539 ]
	private static final List SHUFFLE_VS_SHUFFLE_PARAM_111_SCORE_LIST= [ 9999, 9999, 0, 5721, 0, 0, 0, 9999, 0, 0, 0, 8539 ]

	private static final List STRAIGHT_VS_STRAIGHT_PARAM_101_POS_LIST= [ 3, 2, -1, 4, 10, 6, 7, 8, 9, -1 ]
	private static final List STRAIGHT_VS_SHUFFLE_PARAM_101_POS_LIST= [  2, 1, -1, 3, 9, 10, 6, 7, 8, -1 ]
	private static final List SHUFFLE_VS_STRAIGHT_PARAM_101_POS_LIST= [ -1, 4, 10, 3, 2, 8, 9, -1,  6, 7 ]
	private static final List SHUFFLE_VS_SHUFFLE_PARAM_101_POS_LIST=  [ -1, 3,  9, 2, 1, 7, 8, -1, 10, 6 ]

	private static final List STRAIGHT_VS_STRAIGHT_PARAM_111_POS_LIST= [ 1, 10, -1, 4, -1, 6, 7, 8, -1, -1 ]
	private static final List STRAIGHT_VS_SHUFFLE_PARAM_111_POS_LIST= [ 5, 9, -1, 3, -1, 10, 6, 7, -1, -1 ]
	private static final List SHUFFLE_VS_STRAIGHT_PARAM_111_POS_LIST= [ -1, 4, -1, 1, 10, 8, -1, -1, 6, 7 ]
	private static final List SHUFFLE_VS_SHUFFLE_PARAM_111_POS_LIST= [ -1, 3, -1, 5, 9, 7, -1, -1, 10, 6 ]

	//Use shuffle image SearchParameterId = 2XX 
	private static final List STRAIGHT_VS_STRAIGHT_PARAM_200_SCORE_LIST= [ 6743, 6743, 0, 0, 2578, 0, 0, 2297, 0, 0, 1868, 0 ]
	private static final List STRAIGHT_VS_SHUFFLE_PARAM_200_SCORE_LIST= [ ]
	private static final List SHUFFLE_VS_STRAIGHT_PARAM_200_SCORE_LIST= [ ]
	private static final List SHUFFLE_VS_SHUFFLE_PARAM_200_SCORE_LIST= [ ]
	private static final List STRAIGHT_VS_STRAIGHT_PARAM_201_SCORE_LIST= [ 6743, 6743, 0, 0, 2578, 0, 0, 2297, 0, 0, 1868, 0 ]
	private static final List STRAIGHT_VS_SHUFFLE_PARAM_201_SCORE_LIST= [ 6743, 6743, 0, 0, 2578, 0, 0, 2297, 0, 0, 1868, 0 ]
	private static final List SHUFFLE_VS_STRAIGHT_PARAM_201_SCORE_LIST= [ 6743, 6743, 2578, 0, 0, 0, 0, 0, 1868, 0, 2297, 0 ]
	private static final List SHUFFLE_VS_SHUFFLE_PARAM_201_SCORE_LIST= [ 6743, 6743, 2578, 0, 0, 0, 0, 0, 1868, 0, 2297, 0 ]

	private static final List STRAIGHT_VS_STRAIGHT_PARAM_210_SCORE_LIST= [ 9999, 9999, 0, 0, 7410, 6158, 0, 0, 0, 0, 1606, 0 ]
	private static final List STRAIGHT_VS_SHUFFLE_PARAM_210_SCORE_LIST= [ ]
	private static final List SHUFFLE_VS_STRAIGHT_PARAM_210_SCORE_LIST= [ ]
	private static final List SHUFFLE_VS_SHUFFLE_PARAM_210_SCORE_LIST= [ ]
	private static final List STRAIGHT_VS_STRAIGHT_PARAM_211_SCORE_LIST= [ 9999, 9999, 0, 0, 7410, 6158, 0, 0, 0, 0, 1606, 0 ]
	private static final List STRAIGHT_VS_SHUFFLE_PARAM_211_SCORE_LIST= [ 9999, 9999, 0, 0, 7410, 6158, 0, 0, 0, 0, 1606, 0 ]
	private static final List SHUFFLE_VS_STRAIGHT_PARAM_211_SCORE_LIST= [ 9999, 9999, 7410, 6158, 0, 0, 0, 0, 1606, 0, 0, 0 ]
	private static final List SHUFFLE_VS_SHUFFLE_PARAM_211_SCORE_LIST= [ 9999, 9999, 7410, 6158, 0, 0, 0, 0, 1606, 0, 0, 0 ]

	private static final List STRAIGHT_VS_STRAIGHT_PARAM_201_POS_LIST= [ 1, 2, 3, 4, 5, 6, 7, -1, 9, -1 ]
	private static final List STRAIGHT_VS_SHUFFLE_PARAM_201_POS_LIST= [ 5, 1, 2, 3, 4, 10, 6, -1, 8, -1 ]
	private static final List SHUFFLE_VS_STRAIGHT_PARAM_201_POS_LIST= [ 3, 4, 5, 1, 2, -1, 9, -1, 6,  7 ]
	private static final List SHUFFLE_VS_SHUFFLE_PARAM_201_POS_LIST=  [ 2, 3, 4, 5, 1, -1, 8, -1, 10, 6 ]

	private static final List STRAIGHT_VS_STRAIGHT_PARAM_211_POS_LIST= [ 1, 5, 3, 4, -1, 6, 7, 8, 9, -1 ]
	private static final List STRAIGHT_VS_SHUFFLE_PARAM_211_POS_LIST= [ 5, 4, 2, 3, -1, 10, 6, 7, 8, -1 ]
	private static final List SHUFFLE_VS_STRAIGHT_PARAM_211_POS_LIST= [ 3, 4, -1, 1, 5, 8, 9, -1, 6, 7 ]
	private static final List SHUFFLE_VS_SHUFFLE_PARAM_211_POS_LIST= [ 2, 3, -1, 5, 4, 7, 8, -1, 10, 6 ]

	//Use shuffle image SearchParameterId = 3XX 
	private static final List STRAIGHT_VS_STRAIGHT_PARAM_300_SCORE_LIST= [ 9999, 9999, 9999, 1670, 0, 2564, 0, 63 , 0, 0, 49, 1803 ]
	private static final List STRAIGHT_VS_SHUFFLE_PARAM_300_SCORE_LIST= [ ]
	private static final List SHUFFLE_VS_STRAIGHT_PARAM_300_SCORE_LIST= [ ]
	private static final List SHUFFLE_VS_SHUFFLE_PARAM_300_SCORE_LIST= [ ]
	private static final List STRAIGHT_VS_STRAIGHT_PARAM_301_SCORE_LIST= [ 9999, 9999, 9999, 1670, 0, 2564, 0, 0, 0, 0, 0, 0 ]
	private static final List STRAIGHT_VS_SHUFFLE_PARAM_301_SCORE_LIST= [ 9999, 9999, 9999, 1670, 0, 2564, 0, 0, 0, 0, 0, 0 ]
	private static final List SHUFFLE_VS_STRAIGHT_PARAM_301_SCORE_LIST= [ 9999, 9999, 0, 2564, 0, 9999, 1670, 0, 0, 0, 0, 0 ]
	private static final List SHUFFLE_VS_SHUFFLE_PARAM_301_SCORE_LIST=  [ 9999, 9999, 0, 2564, 0, 9999, 1670, 0, 0, 0, 0, 0 ]

	private static final List STRAIGHT_VS_STRAIGHT_PARAM_310_SCORE_LIST= [ 9999, 9999, 888, 0, 5909, 8339, 0, 0, 5076, 9401, 2376, 0 ]
	private static final List STRAIGHT_VS_SHUFFLE_PARAM_310_SCORE_LIST= [ ]
	private static final List SHUFFLE_VS_STRAIGHT_PARAM_310_SCORE_LIST= [ ]
	private static final List SHUFFLE_VS_SHUFFLE_PARAM_310_SCORE_LIST= [ ]
	private static final List STRAIGHT_VS_STRAIGHT_PARAM_311_SCORE_LIST= [ 9999, 9999, 0, 0, 5909, 8339, 0, 0, 0, 0, 2376, 0 ]
	private static final List STRAIGHT_VS_SHUFFLE_PARAM_311_SCORE_LIST= [ 9999, 9999, 0, 0, 5909, 8339, 0, 0, 0, 0, 2376, 0 ]
	private static final List SHUFFLE_VS_STRAIGHT_PARAM_311_SCORE_LIST= [ 9999, 9999, 5909, 8339, 0, 0, 0, 0, 2376, 0, 0, 0 ]
	private static final List SHUFFLE_VS_SHUFFLE_PARAM_311_SCORE_LIST= [ 9999, 9999, 5909, 8339, 0, 0, 0, 0, 2376, 0, 0, 0 ]

	private static final List STRAIGHT_VS_STRAIGHT_PARAM_301_POS_LIST= [  1, 2, -1, 4, -1, -1, 7, -1, 8, -1 ]
	private static final List STRAIGHT_VS_SHUFFLE_PARAM_301_POS_LIST=  [  5, 1, -1, 3, -1, -1, 6, -1, 7, -1 ]
	private static final List SHUFFLE_VS_STRAIGHT_PARAM_301_POS_LIST=  [ -1, 4, -1, 1,  2, -1, 8, -1, -1, 7 ]
	private static final List SHUFFLE_VS_SHUFFLE_PARAM_301_POS_LIST=   [ -1, 3, -1, 5,  1, -1, 7, -1, -1, 6 ]

	private static final List STRAIGHT_VS_STRAIGHT_PARAM_311_POS_LIST= [ 1, 5, 3, 4, -1, 6, 7, 8, 9, 10 ]
	private static final List STRAIGHT_VS_SHUFFLE_PARAM_311_POS_LIST= [ 5, 4, 2, 3, -1, 10, 6, 7, 8, 9 ]
	private static final List SHUFFLE_VS_STRAIGHT_PARAM_311_POS_LIST= [ 3, 4, -1, 1, 5, 8, 9, 10, 6, 7 ]
	private static final List SHUFFLE_VS_SHUFFLE_PARAM_311_POS_LIST= [ 2, 3, -1, 5, 4, 7, 8, 9, 10, 6 ]

	ExtractCMLHelper(def context){
		super(context)
	}
	
	def getKeyList(){
		return EXT_ID_LIST
	}

	def getShuffleKeyList(){
		return SHUFFLE_EXT_ID_LIST
	}

	def getSortPosList(){
		return SORT_POS_LIST
	}
		

	def getParamExpectResult(def serchParamId){
		return "get${serchParamId}ExpectResult"()
	}
	
	def getParamExpectResult(def serchParamId, def shuffle){
		if(shuffle == "true"){
			return "getShuffle${serchParamId}ExpectResult"()
		}else if(shuffle == "false"){
			return "getStraight${serchParamId}ExpectResult"()
		}
	}
	
	def getShuffle100ExpectResult(){
		return	[
					EXT1 : [ SHUFFLE_VS_STRAIGHT_PARAM_100_SCORE_LIST, SORT_POS_LIST ],
					EXT2 : [ SHUFFLE_VS_SHUFFLE_PARAM_100_SCORE_LIST, SORT_POS_LIST ],
				]
	}

	def getStraight100ExpectResult(){
		return	[
					EXT1 : [ STRAIGHT_VS_STRAIGHT_PARAM_100_SCORE_LIST, SORT_POS_LIST ],
					EXT2 : [ STRAIGHT_VS_SHUFFLE_PARAM_100_SCORE_LIST, SORT_POS_LIST ],
				]
	}

	def getShuffle101ExpectResult(){
		return	[
					EXT1 : [ SHUFFLE_VS_STRAIGHT_PARAM_101_SCORE_LIST, SHUFFLE_VS_STRAIGHT_PARAM_101_POS_LIST],
					EXT2 : [ SHUFFLE_VS_SHUFFLE_PARAM_101_SCORE_LIST, SHUFFLE_VS_SHUFFLE_PARAM_101_POS_LIST],
				]
	}

	def getStraight101ExpectResult(){
		return	[
					EXT1 : [ STRAIGHT_VS_STRAIGHT_PARAM_101_SCORE_LIST, STRAIGHT_VS_STRAIGHT_PARAM_101_POS_LIST ],
					EXT2 : [ STRAIGHT_VS_SHUFFLE_PARAM_101_SCORE_LIST, STRAIGHT_VS_SHUFFLE_PARAM_101_POS_LIST ],
				]
	}

	def getShuffle110ExpectResult(){
		return	[
					EXT1 : [ SHUFFLE_VS_STRAIGHT_PARAM_110_SCORE_LIST, SORT_POS_LIST ],
					EXT2 : [ SHUFFLE_VS_SHUFFLE_PARAM_110_SCORE_LIST, SORT_POS_LIST ],
				]
	}

	def getStraight110ExpectResult(){
		return	[
					EXT1 : [ STRAIGHT_VS_STRAIGHT_PARAM_110_SCORE_LIST, SORT_POS_LIST ],
					EXT2 : [ STRAIGHT_VS_SHUFFLE_PARAM_110_SCORE_LIST, SORT_POS_LIST ],
				]
	}

	def getShuffle111ExpectResult(){
		return	[
					EXT1 : [ SHUFFLE_VS_STRAIGHT_PARAM_111_SCORE_LIST, SHUFFLE_VS_STRAIGHT_PARAM_111_POS_LIST],
					EXT2 : [ SHUFFLE_VS_SHUFFLE_PARAM_111_SCORE_LIST, SHUFFLE_VS_SHUFFLE_PARAM_111_POS_LIST],
				]
	}

	def getStraight111ExpectResult(){
		return	[
					EXT1 : [ STRAIGHT_VS_STRAIGHT_PARAM_111_SCORE_LIST, STRAIGHT_VS_STRAIGHT_PARAM_111_POS_LIST ],
					EXT2 : [ STRAIGHT_VS_SHUFFLE_PARAM_111_SCORE_LIST, STRAIGHT_VS_SHUFFLE_PARAM_111_POS_LIST ],
				]
	}

	def getShuffle200ExpectResult(){
		return	[
					EXT1 : [ SHUFFLE_VS_STRAIGHT_PARAM_200_SCORE_LIST, SORT_POS_LIST ],
					EXT2 : [ SHUFFLE_VS_SHUFFLE_PARAM_200_SCORE_LIST, SORT_POS_LIST ],
				]
	}

	def getStraight200ExpectResult(){
		return	[
					EXT1 : [ STRAIGHT_VS_STRAIGHT_PARAM_200_SCORE_LIST, SORT_POS_LIST ],
					EXT2 : [ STRAIGHT_VS_SHUFFLE_PARAM_200_SCORE_LIST, SORT_POS_LIST ],
				]
	}

	def getShuffle201ExpectResult(){
		return	[
					EXT1 : [ SHUFFLE_VS_STRAIGHT_PARAM_201_SCORE_LIST, SHUFFLE_VS_STRAIGHT_PARAM_201_POS_LIST],
					EXT2 : [ SHUFFLE_VS_SHUFFLE_PARAM_201_SCORE_LIST, SHUFFLE_VS_SHUFFLE_PARAM_201_POS_LIST],
				]
	}

	def getStraight201ExpectResult(){
		return	[
					EXT1 : [ STRAIGHT_VS_STRAIGHT_PARAM_201_SCORE_LIST, STRAIGHT_VS_STRAIGHT_PARAM_201_POS_LIST ],
					EXT2 : [ STRAIGHT_VS_SHUFFLE_PARAM_201_SCORE_LIST, STRAIGHT_VS_SHUFFLE_PARAM_201_POS_LIST ],
				]
	}

	def getShuffle210ExpectResult(){
		return	[
					EXT1 : [ SHUFFLE_VS_STRAIGHT_PARAM_210_SCORE_LIST, SORT_POS_LIST ],
					EXT2 : [ SHUFFLE_VS_SHUFFLE_PARAM_210_SCORE_LIST, SORT_POS_LIST ],
				]
	}

	def getStraight210ExpectResult(){
		return	[
					EXT1 : [ STRAIGHT_VS_STRAIGHT_PARAM_210_SCORE_LIST, SORT_POS_LIST ],
					EXT2 : [ STRAIGHT_VS_SHUFFLE_PARAM_210_SCORE_LIST, SORT_POS_LIST ],
				]
	}

	def getShuffle211ExpectResult(){
		return	[
					EXT1 : [ SHUFFLE_VS_STRAIGHT_PARAM_211_SCORE_LIST, SHUFFLE_VS_STRAIGHT_PARAM_211_POS_LIST],
					EXT2 : [ SHUFFLE_VS_SHUFFLE_PARAM_211_SCORE_LIST, SHUFFLE_VS_SHUFFLE_PARAM_211_POS_LIST],
				]
	}

	def getStraight211ExpectResult(){
		return	[
					EXT1 : [ STRAIGHT_VS_STRAIGHT_PARAM_211_SCORE_LIST, STRAIGHT_VS_STRAIGHT_PARAM_211_POS_LIST ],
					EXT2 : [ STRAIGHT_VS_SHUFFLE_PARAM_211_SCORE_LIST, STRAIGHT_VS_SHUFFLE_PARAM_211_POS_LIST ],
				]
	}

	def getShuffle300ExpectResult(){
		return	[
					EXT1 : [ SHUFFLE_VS_STRAIGHT_PARAM_300_SCORE_LIST, SORT_POS_LIST ],
					EXT2 : [ SHUFFLE_VS_SHUFFLE_PARAM_300_SCORE_LIST, SORT_POS_LIST ],
				]
	}

	def getStraight300ExpectResult(){
		return	[
					EXT1 : [ STRAIGHT_VS_STRAIGHT_PARAM_300_SCORE_LIST, SORT_POS_LIST ],
					EXT2 : [ STRAIGHT_VS_SHUFFLE_PARAM_300_SCORE_LIST, SORT_POS_LIST ],
				]
	}

	def getShuffle301ExpectResult(){
		return	[
					EXT1 : [ SHUFFLE_VS_STRAIGHT_PARAM_301_SCORE_LIST, SHUFFLE_VS_STRAIGHT_PARAM_301_POS_LIST],
					EXT2 : [ SHUFFLE_VS_SHUFFLE_PARAM_301_SCORE_LIST, SHUFFLE_VS_SHUFFLE_PARAM_301_POS_LIST],
				]
	}

	def getStraight301ExpectResult(){
		return	[
					EXT1 : [ STRAIGHT_VS_STRAIGHT_PARAM_301_SCORE_LIST, STRAIGHT_VS_STRAIGHT_PARAM_301_POS_LIST ],
					EXT2 : [ STRAIGHT_VS_SHUFFLE_PARAM_301_SCORE_LIST, STRAIGHT_VS_SHUFFLE_PARAM_301_POS_LIST ],
				]
	}

	def getShuffle310ExpectResult(){
		return	[
					EXT1 : [ SHUFFLE_VS_STRAIGHT_PARAM_310_SCORE_LIST, SORT_POS_LIST ],
					EXT2 : [ SHUFFLE_VS_SHUFFLE_PARAM_310_SCORE_LIST, SORT_POS_LIST ],
				]
	}

	def getStraight310ExpectResult(){
		return	[
					EXT1 : [ STRAIGHT_VS_STRAIGHT_PARAM_310_SCORE_LIST, SORT_POS_LIST ],
					EXT2 : [ STRAIGHT_VS_SHUFFLE_PARAM_310_SCORE_LIST, SORT_POS_LIST ],
				]
	}

	def getShuffle311ExpectResult(){
		return	[
					EXT1 : [ SHUFFLE_VS_STRAIGHT_PARAM_311_SCORE_LIST, SHUFFLE_VS_STRAIGHT_PARAM_311_POS_LIST],
					EXT2 : [ SHUFFLE_VS_SHUFFLE_PARAM_311_SCORE_LIST, SHUFFLE_VS_SHUFFLE_PARAM_311_POS_LIST],
				]
	}

	def getStraight311ExpectResult(){
		return	[
					EXT1 : [ STRAIGHT_VS_STRAIGHT_PARAM_311_SCORE_LIST, STRAIGHT_VS_STRAIGHT_PARAM_311_POS_LIST ],
					EXT2 : [ STRAIGHT_VS_SHUFFLE_PARAM_311_SCORE_LIST, STRAIGHT_VS_SHUFFLE_PARAM_311_POS_LIST ],
				]
	}

	def get100ExpectResult(){
		return	[
					EXT1 : [ FILE_1_VS_1_PARAM_100_SCORE_LIST, SORT_POS_LIST ],
					EXT2 : [ FILE_1_VS_2_PARAM_100_SCORE_LIST, SORT_POS_LIST ],
					EXT3 : [ FILE_1_VS_3_PARAM_100_SCORE_LIST, SORT_POS_LIST ],
				]
	}

	def get101ExpectResult(){
		return	[
					EXT1 : [ FILE_1_VS_1_PARAM_101_SCORE_LIST, FILE_1_VS_1_PARAM_101_POS_LIST ],
					EXT2 : [ FILE_1_VS_2_PARAM_101_SCORE_LIST, FILE_1_VS_2_PARAM_101_POS_LIST ],
					EXT3 : [ FILE_1_VS_3_PARAM_101_SCORE_LIST, FILE_1_VS_3_PARAM_101_POS_LIST ],
				]
	}

	def get110ExpectResult(){
		return [
				 	EXT1 : [ FILE_1_VS_1_PARAM_110_SCORE_LIST, SORT_POS_LIST ],
				 	EXT2 : [ FILE_1_VS_2_PARAM_110_SCORE_LIST, SORT_POS_LIST ],
				 	EXT3 : [ FILE_1_VS_3_PARAM_110_SCORE_LIST, SORT_POS_LIST ],
			   ]
	}

	def get111ExpectResult(){
		return [
					EXT1 : [ FILE_1_VS_1_PARAM_111_SCORE_LIST, FILE_1_VS_1_PARAM_111_POS_LIST ],
				 	EXT2 : [ FILE_1_VS_2_PARAM_111_SCORE_LIST, FILE_1_VS_2_PARAM_111_POS_LIST ],
					EXT3 : [ FILE_1_VS_3_PARAM_111_SCORE_LIST, FILE_1_VS_3_PARAM_111_POS_LIST ],
			   ]
	}

	def get200ExpectResult(){
		return	[
					EXT1 : [ FILE_2_VS_1_PARAM_200_SCORE_LIST, SORT_POS_LIST ],
					EXT2 : [ FILE_2_VS_2_PARAM_200_SCORE_LIST, SORT_POS_LIST ],
					EXT3 : [ FILE_2_VS_3_PARAM_200_SCORE_LIST, SORT_POS_LIST ],
				]
	}

	def get201ExpectResult(){
		return	[
					EXT1 : [ FILE_2_VS_1_PARAM_201_SCORE_LIST, FILE_2_VS_1_PARAM_201_POS_LIST ],
					EXT2 : [ FILE_2_VS_2_PARAM_201_SCORE_LIST, FILE_2_VS_2_PARAM_201_POS_LIST ],
					EXT3 : [ FILE_2_VS_3_PARAM_201_SCORE_LIST, FILE_2_VS_3_PARAM_201_POS_LIST ],
				]
	}

	def get210ExpectResult(){
		return [
				 	EXT1 : [ FILE_2_VS_1_PARAM_210_SCORE_LIST, SORT_POS_LIST ],
				 	EXT2 : [ FILE_2_VS_2_PARAM_210_SCORE_LIST, SORT_POS_LIST ],
				 	EXT3 : [ FILE_2_VS_3_PARAM_210_SCORE_LIST, SORT_POS_LIST ],
			   ]
	}

	def get211ExpectResult(){
		return [
					EXT1 : [ FILE_2_VS_1_PARAM_211_SCORE_LIST, FILE_2_VS_1_PARAM_211_POS_LIST ],
				 	EXT2 : [ FILE_2_VS_2_PARAM_211_SCORE_LIST, FILE_2_VS_2_PARAM_211_POS_LIST ],
					EXT3 : [ FILE_2_VS_3_PARAM_211_SCORE_LIST, FILE_2_VS_3_PARAM_211_POS_LIST ],
			   ]
	}

	def get300ExpectResult(){
		return	[
					EXT1 : [ FILE_3_VS_1_PARAM_300_SCORE_LIST, SORT_POS_LIST ],
					EXT2 : [ FILE_3_VS_2_PARAM_300_SCORE_LIST, SORT_POS_LIST ],
					EXT3 : [ FILE_3_VS_3_PARAM_300_SCORE_LIST, SORT_POS_LIST ],
				]
	}

	def get301ExpectResult(){
		return	[
					EXT1 : [ FILE_3_VS_1_PARAM_301_SCORE_LIST, FILE_3_VS_1_PARAM_301_POS_LIST ],
					EXT2 : [ FILE_3_VS_2_PARAM_301_SCORE_LIST, FILE_3_VS_2_PARAM_301_POS_LIST ],
					EXT3 : [ FILE_3_VS_3_PARAM_301_SCORE_LIST, FILE_3_VS_3_PARAM_301_POS_LIST ],
				]
	}

	def get310ExpectResult(){
		return [
				 	EXT1 : [ FILE_3_VS_1_PARAM_310_SCORE_LIST, SORT_POS_LIST ],
				 	EXT2 : [ FILE_3_VS_2_PARAM_310_SCORE_LIST, SORT_POS_LIST ],
				 	EXT3 : [ FILE_3_VS_3_PARAM_310_SCORE_LIST, SORT_POS_LIST ],
			   ]
	}

	def get311ExpectResult(){
		return [
					EXT1 : [ FILE_3_VS_1_PARAM_311_SCORE_LIST, FILE_3_VS_1_PARAM_311_POS_LIST ],
				 	EXT2 : [ FILE_3_VS_2_PARAM_311_SCORE_LIST, FILE_3_VS_2_PARAM_311_POS_LIST ],
					EXT3 : [ FILE_3_VS_3_PARAM_311_SCORE_LIST, FILE_3_VS_3_PARAM_311_POS_LIST ],
			   ]
	}

	def getTIMRolledAndSlapChildFingerSearchImage(){
		initPosSearchImgPathMap()
        List posList = [ ROLLED_RIGHT_THUMB, ROLLED_RIGHT_INDEX, ROLLED_RIGHT_MIDDLE, ROLLED_RIGHT_RING, ROLLED_RIGHT_LITTLE,
                         ROLLED_LEFT_THUMB, ROLLED_LEFT_INDEX, ROLLED_LEFT_MIDDLE, ROLLED_LEFT_RING, ROLLED_LEFT_LITTLE,
                         SLAP_RIGHT_THUMB, SLAP_RIGHT_INDEX, SLAP_RIGHT_MIDDLE, SLAP_RIGHT_RING, SLAP_RIGHT_LITTLE,
                         SLAP_LEFT_THUMB, SLAP_LEFT_INDEX, SLAP_LEFT_MIDDLE, SLAP_LEFT_RING, SLAP_LEFT_LITTLE ]
        return createTenprintImg(posList)
    }

	def getTIMRolledAndSlapChildFingerFileImage(){
		initPosFileImgPathMap()
        List posList = [ ROLLED_RIGHT_THUMB, ROLLED_RIGHT_INDEX, ROLLED_RIGHT_MIDDLE, ROLLED_RIGHT_RING, ROLLED_RIGHT_LITTLE,
                         ROLLED_LEFT_THUMB, ROLLED_LEFT_INDEX, ROLLED_LEFT_MIDDLE, ROLLED_LEFT_RING, ROLLED_LEFT_LITTLE,
                         SLAP_RIGHT_THUMB, SLAP_RIGHT_INDEX, SLAP_RIGHT_MIDDLE, SLAP_RIGHT_RING, SLAP_RIGHT_LITTLE,
                         SLAP_LEFT_THUMB, SLAP_LEFT_INDEX, SLAP_LEFT_MIDDLE, SLAP_LEFT_RING, SLAP_LEFT_LITTLE ]
        return createTenprintImg(posList)
    }

	def getShuffleTIMRolledAndSlapChildFingerSearchImage(){
	initShufflePosSearchImgPathMap()
        List posList = [ ROLLED_RIGHT_THUMB, ROLLED_RIGHT_INDEX, ROLLED_RIGHT_MIDDLE, ROLLED_RIGHT_RING, ROLLED_RIGHT_LITTLE,
                         ROLLED_LEFT_THUMB, ROLLED_LEFT_INDEX, ROLLED_LEFT_MIDDLE, ROLLED_LEFT_RING, ROLLED_LEFT_LITTLE,
                         SLAP_RIGHT_THUMB, SLAP_RIGHT_INDEX, SLAP_RIGHT_MIDDLE, SLAP_RIGHT_RING, SLAP_RIGHT_LITTLE,
                         SLAP_LEFT_THUMB, SLAP_LEFT_INDEX, SLAP_LEFT_MIDDLE, SLAP_LEFT_RING, SLAP_LEFT_LITTLE ]
        return createTenprintImg(posList)
    }

	def getShuffleTIMRolledAndSlapChildFingerFileImage(){
		initShufflePosFileImgPathMap()
        List posList = [ ROLLED_RIGHT_THUMB, ROLLED_RIGHT_INDEX, ROLLED_RIGHT_MIDDLE, ROLLED_RIGHT_RING, ROLLED_RIGHT_LITTLE,
                         ROLLED_LEFT_THUMB, ROLLED_LEFT_INDEX, ROLLED_LEFT_MIDDLE, ROLLED_LEFT_RING, ROLLED_LEFT_LITTLE,
                         SLAP_RIGHT_THUMB, SLAP_RIGHT_INDEX, SLAP_RIGHT_MIDDLE, SLAP_RIGHT_RING, SLAP_RIGHT_LITTLE,
                         SLAP_LEFT_THUMB, SLAP_LEFT_INDEX, SLAP_LEFT_MIDDLE, SLAP_LEFT_RING, SLAP_LEFT_LITTLE ]
        return createTenprintImg(posList)
    }

	def getTIMRolledAndSlapFewFingerSearchImage(){
		initPosSearchImgPathMap();
        List posList = [ ROLLED_RIGHT_INDEX, ROLLED_LEFT_INDEX, SLAP_RIGHT_INDEX, SLAP_LEFT_INDEX ]
        return createTenprintImg(posList)
    }

	def getTIMRolledAndSlapFewFingerFileImage(){
		initPosFileImgPathMap()
        List posList = [ ROLLED_RIGHT_INDEX, ROLLED_LEFT_INDEX, SLAP_RIGHT_INDEX, SLAP_LEFT_INDEX ]
        return createTenprintImg(posList)
    }

	def createTenprintImg(List posList){
        StringBuilder sb = new StringBuilder()
        for(pos in posList){
            sb.append(imgXmlMaker.getAimSimpleImgXml(posImgPathMap.get(pos), pos, imageType, IMAGE_WIDHT, IMAGE_HEIGHT))
        }
        return sb.toString()
    }

	def initPosSearchImgPathMap() {
        this.posImgPathMap = new HashMap()
		this.imageType = TYPE_RAW
        posImgPathMap.put(ROLLED_RIGHT_THUMB, TF_125_RAW)
        posImgPathMap.put(ROLLED_RIGHT_INDEX, TF_126_RAW)
        posImgPathMap.put(ROLLED_RIGHT_MIDDLE, TF_127_RAW)
        posImgPathMap.put(ROLLED_RIGHT_RING, TF_128_RAW)
        posImgPathMap.put(ROLLED_RIGHT_LITTLE, TF_129_RAW)
        posImgPathMap.put(ROLLED_LEFT_THUMB, TF_130_RAW)
        posImgPathMap.put(ROLLED_LEFT_INDEX, TF_131_RAW)
        posImgPathMap.put(ROLLED_LEFT_MIDDLE, TF_132_RAW)
        posImgPathMap.put(ROLLED_LEFT_RING, TF_133_RAW)
        posImgPathMap.put(ROLLED_LEFT_LITTLE, TF_134_RAW)
        posImgPathMap.put(SLAP_RIGHT_THUMB, TF_135_RAW)
        posImgPathMap.put(SLAP_RIGHT_INDEX, TF_136_RAW)
        posImgPathMap.put(SLAP_RIGHT_MIDDLE, TF_137_RAW)
        posImgPathMap.put(SLAP_RIGHT_RING, TF_138_RAW)
        posImgPathMap.put(SLAP_RIGHT_LITTLE, TF_139_RAW)
        posImgPathMap.put(SLAP_LEFT_THUMB, TF_140_RAW)
        posImgPathMap.put(SLAP_LEFT_INDEX, TF_141_RAW)
        posImgPathMap.put(SLAP_LEFT_MIDDLE, TF_142_RAW)
        posImgPathMap.put(SLAP_LEFT_RING, TF_143_RAW)
        posImgPathMap.put(SLAP_LEFT_LITTLE, TF_144_RAW)
    }
	
	def initPosFileImgPathMap() {
        this.posImgPathMap = new HashMap()
		this.imageType = TYPE_RAW
        posImgPathMap.put(ROLLED_RIGHT_THUMB, TF_145_RAW)
        posImgPathMap.put(ROLLED_RIGHT_INDEX, TF_146_RAW)
        posImgPathMap.put(ROLLED_RIGHT_MIDDLE, TF_147_RAW)
        posImgPathMap.put(ROLLED_RIGHT_RING, TF_148_RAW)
        posImgPathMap.put(ROLLED_RIGHT_LITTLE, TF_149_RAW)
        posImgPathMap.put(ROLLED_LEFT_THUMB, TF_150_RAW)
        posImgPathMap.put(ROLLED_LEFT_INDEX, TF_151_RAW)
        posImgPathMap.put(ROLLED_LEFT_MIDDLE, TF_152_RAW)
        posImgPathMap.put(ROLLED_LEFT_RING, TF_153_RAW)
        posImgPathMap.put(ROLLED_LEFT_LITTLE, TF_154_RAW)
        posImgPathMap.put(SLAP_RIGHT_THUMB, TF_155_RAW)
        posImgPathMap.put(SLAP_RIGHT_INDEX, TF_156_RAW)
        posImgPathMap.put(SLAP_RIGHT_MIDDLE, TF_157_RAW)
        posImgPathMap.put(SLAP_RIGHT_RING, TF_158_RAW)
        posImgPathMap.put(SLAP_RIGHT_LITTLE, TF_159_RAW)
        posImgPathMap.put(SLAP_LEFT_THUMB, TF_160_RAW)
        posImgPathMap.put(SLAP_LEFT_INDEX, TF_161_RAW)
        posImgPathMap.put(SLAP_LEFT_MIDDLE, TF_162_RAW)
        posImgPathMap.put(SLAP_LEFT_RING, TF_163_RAW)
        posImgPathMap.put(SLAP_LEFT_LITTLE, TF_164_RAW)
    }

	def initShufflePosSearchImgPathMap() {
        this.posImgPathMap = new HashMap()
		this.imageType = TYPE_RAW
        posImgPathMap.put(ROLLED_RIGHT_RING, TF_125_RAW)
        posImgPathMap.put(ROLLED_RIGHT_LITTLE, TF_126_RAW)
        posImgPathMap.put(ROLLED_RIGHT_THUMB, TF_127_RAW)
        posImgPathMap.put(ROLLED_RIGHT_INDEX, TF_128_RAW)
        posImgPathMap.put(ROLLED_RIGHT_MIDDLE, TF_129_RAW)
        posImgPathMap.put(ROLLED_LEFT_RING, TF_130_RAW)
        posImgPathMap.put(ROLLED_LEFT_LITTLE, TF_131_RAW)
        posImgPathMap.put(ROLLED_LEFT_THUMB, TF_132_RAW)
        posImgPathMap.put(ROLLED_LEFT_INDEX, TF_133_RAW)
        posImgPathMap.put(ROLLED_LEFT_MIDDLE, TF_134_RAW)
        posImgPathMap.put(SLAP_RIGHT_RING, TF_135_RAW)
        posImgPathMap.put(SLAP_RIGHT_LITTLE, TF_136_RAW)
        posImgPathMap.put(SLAP_RIGHT_THUMB, TF_137_RAW)
        posImgPathMap.put(SLAP_RIGHT_INDEX, TF_138_RAW)
        posImgPathMap.put(SLAP_RIGHT_MIDDLE, TF_139_RAW)
		posImgPathMap.put(SLAP_LEFT_RING, TF_140_RAW)
        posImgPathMap.put(SLAP_LEFT_LITTLE, TF_141_RAW)
        posImgPathMap.put(SLAP_LEFT_THUMB, TF_142_RAW)
        posImgPathMap.put(SLAP_LEFT_INDEX, TF_143_RAW)
        posImgPathMap.put(SLAP_LEFT_MIDDLE, TF_144_RAW)
    }
	
	def initShufflePosFileImgPathMap() {
        this.posImgPathMap = new HashMap()
		this.imageType = TYPE_RAW
        posImgPathMap.put(ROLLED_RIGHT_LITTLE, TF_145_RAW)
        posImgPathMap.put(ROLLED_RIGHT_THUMB, TF_146_RAW)
        posImgPathMap.put(ROLLED_RIGHT_INDEX, TF_147_RAW)
        posImgPathMap.put(ROLLED_RIGHT_MIDDLE, TF_148_RAW)
        posImgPathMap.put(ROLLED_RIGHT_RING, TF_149_RAW)
        posImgPathMap.put(ROLLED_LEFT_LITTLE, TF_150_RAW)
        posImgPathMap.put(ROLLED_LEFT_THUMB, TF_151_RAW)
        posImgPathMap.put(ROLLED_LEFT_INDEX, TF_152_RAW)
        posImgPathMap.put(ROLLED_LEFT_MIDDLE, TF_153_RAW)
        posImgPathMap.put(ROLLED_LEFT_RING, TF_154_RAW)
        posImgPathMap.put(SLAP_RIGHT_LITTLE, TF_155_RAW)
        posImgPathMap.put(SLAP_RIGHT_THUMB, TF_156_RAW)
        posImgPathMap.put(SLAP_RIGHT_INDEX, TF_157_RAW)
        posImgPathMap.put(SLAP_RIGHT_MIDDLE, TF_158_RAW)
        posImgPathMap.put(SLAP_RIGHT_RING, TF_159_RAW)
        posImgPathMap.put(SLAP_LEFT_LITTLE, TF_160_RAW)
        posImgPathMap.put(SLAP_LEFT_THUMB, TF_161_RAW)
        posImgPathMap.put(SLAP_LEFT_INDEX, TF_162_RAW)
        posImgPathMap.put(SLAP_LEFT_MIDDLE, TF_163_RAW)
        posImgPathMap.put(SLAP_LEFT_RING, TF_164_RAW)
    }
	
	Object invokeMethod(String name,Object args){
		return "No Exist Methods"
	}	
}
