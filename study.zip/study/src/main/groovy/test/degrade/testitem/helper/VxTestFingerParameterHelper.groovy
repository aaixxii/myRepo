package test.degrade.testitem.helper

import test.degrade.util.SoapuiObject
import test.common.util.vp.VerifyProcess
import static test.common.constants.aim.AIMWord.*

class VxTestFingerParameterHelper{

	static final String EXTRACT = "/extract by CML:"
	static final String MATCH = "/pc2:"
	static final String COMMA_PUNCTUATION = ", "
	static final String SLASH_PUNCTUATION = " / "
	static final String DOUBLE_QUOTATION = "\""
	static final String PARAMETER = "parameter="
	static final String SEARCH_PARAMETER = "search-parameter="
	static final String FILE_PARAMETER   = "file-parameter="
	static final String IDENTIFY_PARAMETER = "identify-parameter="
	static final String FIRST_MATCH_PARAMETER = "first-match-parameter="
	static final String SECOND_MATCH_PARAMETER = "second-match-parameter="
	static final String ROTATION="rotation="
	static final String SPEED="speed="
	static final String DISTORTION="distortion="

	def soapuiObj
	def vp
	def timEngine

	def VxTestFingerParameterHelper(context){
		this.soapuiObj = new SoapuiObject(context)
		this.vp = new VerifyProcess(context)
		this.timEngine = soapuiObj.getGlobalTimEngine()
	}

	def makeResponseCmlParameter(boolean sIsImage, boolean fIsImage, def sType, def fType,
									def extRollEnroll, def extRollFinalize, def extSlapEnroll, def extSlapFinalize,
									def extRotation, def extSpeed, def extDistortion){
		String resParam = ""
		if(sIsImage){
			if(sType == ROLLED){
				resParam += EXTRACT +  PARAMETER + DOUBLE_QUOTATION +
							extRollEnroll + COMMA_PUNCTUATION + extRollFinalize + DOUBLE_QUOTATION
			}else if(sType == SLAP){
				resParam += EXTRACT + PARAMETER + DOUBLE_QUOTATION +
							extSlapEnroll + COMMA_PUNCTUATION + extSlapFinalize + DOUBLE_QUOTATION
			}else{
				//no return parameter
			}
		}
		
		if(fIsImage){
			if(fType == ROLLED){
				resParam += EXTRACT + PARAMETER + DOUBLE_QUOTATION +
							extRollEnroll + COMMA_PUNCTUATION + extRollFinalize + DOUBLE_QUOTATION
			}else if(fType == SLAP){
				resParam += EXTRACT + PARAMETER + DOUBLE_QUOTATION +
							extSlapEnroll + COMMA_PUNCTUATION + extSlapFinalize + DOUBLE_QUOTATION
			}else{
				//no return parameter
			}
		}
	
		resParam += MATCH +
					ROTATION + extRotation + COMMA_PUNCTUATION +
					SPEED + extSpeed + COMMA_PUNCTUATION + 
					DISTORTION + extDistortion				
	
		return resParam
	}
}
