package test.degrade.testitem.helper

import test.degrade.properties.GlobalProperties
import test.degrade.management.AbendProcessor
import static test.common.constants.aim.AIMWord.*

class RegistrationHelper {

	private static final int MAX_SCORE = 9999
	private static final int ZERO_SCORE = 0
	private List candInfoListRoll = [ "", MAX_SCORE ] // [ externalId, fusionScore ]
	private List candInfoListSlap = [ "", MAX_SCORE ]

	public RegistrationHelper(def context){
		initAssertionScores(context)
	}

	private void initAssertionScores(def context) {
        String timEngine = new GlobalProperties(context).getTimEngine().toUpperCase()
		if(timEngine == CML){
			initCmlAssertionScore()
		}else if (timEngine == CMLAF){
			initCmlafAssertionScore()
		}else{
			assert false, "Unkown TIM engine value '${timEngine}'."
		}
	}
	
	// TODO 
	// It's better to return not only externalId and score,
	// but also containerId, eventId and so on
	// if we have enough time to improve soapUI assertion groovy test step.
	public List getCandInfoRoll(String externalId){
		candInfoListRoll[0] = externalId
		println candInfoListRoll
		return candInfoListRoll
	}
	
	public List getCandInfoSlap(String externalId){
		candInfoListSlap[0] = externalId
		return candInfoListSlap
	}
	
	private void initCmlAssertionScore() {
		initCmlRollAssertionScore()
		initCmlSlapAssertionScore()
	}

	private initCmlRollAssertionScore() {
		addScore(candInfoListRoll, ZERO_SCORE, 1)
		addScore(candInfoListRoll, MAX_SCORE, 3)
		addScore(candInfoListRoll, ZERO_SCORE, 1)
		addScore(candInfoListRoll, MAX_SCORE, 3)
		addScore(candInfoListRoll, ZERO_SCORE, 2)
	}

	private initCmlSlapAssertionScore() {
		addScore(candInfoListSlap, MAX_SCORE, 2)
		addScore(candInfoListSlap, ZERO_SCORE, 1)
		addScore(candInfoListSlap, MAX_SCORE, 1)
		addScore(candInfoListSlap, ZERO_SCORE, 1)
		addScore(candInfoListSlap, MAX_SCORE, 3)
		addScore(candInfoListSlap, ZERO_SCORE, 2)
	}

	private void initCmlafAssertionScore() {
		addScore(candInfoListRoll, MAX_SCORE, 10)
		addScore(candInfoListSlap, MAX_SCORE, 10)
	}
	
	private void addScore(List scoreList, int score, int num) {
		for(i in 1..num){
			scoreList << score
		}
	}
}

