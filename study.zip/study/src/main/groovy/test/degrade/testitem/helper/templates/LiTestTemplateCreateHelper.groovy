package test.degrade.testitem.helper.templates

import test.degrade.testitem.helper.*
import static test.common.constants.data.ImageDataList.*

class LiTestTemplateCreateHelper extends TestTemplateCreateHelper{

    LiTestTemplateCreateHelper(context){
		super(context)
    }

	public String getDefaultFileImage(){
		return imgXmlMaker.getLatentFuncDefTenprintImgXml()
	}

	public String getDefaultSearchImage(){
		return imgXmlMaker.getLatentFingerImgXml(LF_001_WSQ)
	}

	def getPatternFileImage(){
		return imgXmlMaker.getTenprintFingerImgXml(TF_025_RS_NST) 
	}

	def getPatternSearchImage(){
		return imgXmlMaker.getLatentFingerImgXml(LF_002_WSQ)
	}

	def getAdjacentPatternFileImage(){
		return imgXmlMaker.getTenprintFingerImgXml(TF_026_RS_NST) 
	}

	def getAdjacentPatternSearchImage_1(){
		return imgXmlMaker.getLatentFingerImgXml(LF_003_WSQ)
	}

	def getAdjacentPatternSearchImage_2(){
		return imgXmlMaker.getLatentFingerImgXml(LF_004_WSQ)
	}

	def getExternalIdFileImage(){
		return imgXmlMaker.getLatentFuncFullScoreTenprintImgXml()
	}

	def getFingerNoFileImage(){
		return imgXmlMaker.getTenprintFingerImgXml(TF_008_RS_NST)
	}
	
	def getFingerNoSearchImage_1(){
		return imgXmlMaker.getLatentFingerImgXml(LF_016_WSQ)
	}

	def getFingerNoSearchImage_2(){
		return imgXmlMaker.getLatentFingerImgXml(LF_017_WSQ)
	}
	def getFingerNoSearchImage_3(){
		return imgXmlMaker.getLatentFingerImgXml(LF_018_WSQ)
	}
}
