package test.degrade.testitem.helper

import test.degrade.properties.*

class ReExtractHelper {
	
	String dataFilePathRoot
	String testCaseName
	private static final String REEXT_DIR = "degradeTest/Extract/reExtract/"
	private static final String CASE17_DIR = "${REEXT_DIR}part2/17/"

	public ReExtractHelper(def context){
		this.dataFilePathRoot = new GlobalProperties(context).getDataFilePath()
		this.testCaseName = "${context.testCase.name}"
	}

	public String getInputMinutia(String caseName){
		String fileExtention = "_reExtInput.xml"
		String filename = testCaseName + fileExtention
		return new File(dataFilePathRoot + caseName + filename).getText()
	}

	public String getCase17InputMinutia(){
		getInputMinutia(CASE17_DIR)
	}
}

