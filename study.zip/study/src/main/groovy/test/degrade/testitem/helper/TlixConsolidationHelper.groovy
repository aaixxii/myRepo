package test.degrade.testitem.helper

import static test.common.constants.aim.AIMXmlAttribute.*

class TlixConsolidationHelper extends ConsolidationHelper {

	private static final String F101_EXT_ID = "TLIX_F101A_PC2"
	private static final String F102_EXT_ID = "TLIX_F102A_FMP5"
	private static final String F103_EXT_ID = "TLIX_F103A_PC2_FMP5"
	private static final String F104_EXT_ID = "TLIX_F104A_FMP5"
	private static final String F105_EXT_ID = "TLIX_F105A_PC2_FMP5"
	private static final String F_123_ABC_HIGH_EXT_ID = "TLIX-123-ABC-High"
	private static final String F_ABC_123_HIGH_EXT_ID = "TLIX-ABC-123-High"
	private static final String F_BBC_123_HIGH_EXT_ID = "TLIX-BBC-123-High"
	private static final String F_123_ABC_LOW_EXT_ID = "TLIX-123-ABC-Low"
	private static final String F_ABC_123_LOW_EXT_ID = "TLIX-ABC-123-Low"
	private static final String F_BBC_123_LOW_EXT_ID = "TLIX-BBC-123-Low"
	private static final int PC2_ROLLED_1_SCORE = 547
	private static final int PC2_ROLLED_6_SCORE = 1742
	private static final int PC2_SLAP_1_SCORE = 1747
	private static final int PC2_SLAP_6_SCORE = PC2_SLAP_1_SCORE
	private static final int PC2_SLAP_10_SCORE = 3961
	private static final int FMP5_ROLLED_1_A_SCORE = 748
	private static final int FMP5_ROLLED_1_B_SCORE = 247
	private static final int FMP5_ROLLED_1_C_SCORE = 994
	private static final int FMP5_ROLLED_1_D_SCORE = FMP5_ROLLED_1_C_SCORE
	private static final int FMP5_ROLLED_1_D_SCORE_F105 = 634
	private static final int FMP5_ROLLED_1_SCORE = 739
	private static final int FMP5_ROLLED_1_SCORE_FIN_MERGE = 2016
	private static final int FMP5_ROLLED_2_SCORE = 1128
	private static final int FMP5_SLAP_1_SCORE = 2016
	private static final int FMP5_SLAP_1_SCORE_FIN_MERGE = 1128
	private static final int FMP5_SLAP_1_A_SCORE = 1928
	private static final int FMP5_SLAP_1_B_SCORE = 688
	private static final int FMP5_SLAP_1_C_SCORE = 2284
	private static final int FMP5_SLAP_1_D_SCORE = FMP5_SLAP_1_C_SCORE
	private static final int FMP5_SLAP_1_D_SCORE_F105 = 2130
	private static final int FMP5_SLAP_2_SCORE = 903
	private static final int FMP5_SLAP_5_SCORE = FMP5_SLAP_1_SCORE
	private Integer fmp5rFW = 100
	private Integer fmp5sFW = 100
	private Integer pc2rFW = 200
	private Integer pc2sFW = 200
	private Integer pc2FW = 200 / 100

	private List F101A_CAND_INFO_LIST_BY_PC2_R = []
	private List F101A_CAND_INFO_LIST_BY_PC2_S = []
	private List F101A_CAND_INFO_LIST_BY_PC2_RS = []
	private List F101A_CAND_INFO_LIST_BY_PC2_RS_16 = []
	private List F101A_CAND_INFO_LIST_BY_PC2_RS_2CANTMP = []
	private List F103A_CAND_INFO_LIST_BY_PC2_R = []
	private List F102A_CAND_INFO_LIST_BY_FMP5_R = []
	private List F102A_CAND_INFO_LIST_BY_FMP5_RS = []
	private List F102A_CAND_INFO_LIST_BY_FMP5_RS_125 = []
	private List F103A_CAND_INFO_LIST_BY_FMP5_R = []
	private List F103A_CAND_INFO_LIST_BY_FMP5_S = []
	private List F103A_CAND_INFO_LIST_BY_PC2_S_FMP5_R = []
	private List F103A_CAND_INFO_LIST_BY_PC2_S_FMP5_S = []
	private List F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS = []
	private List F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS_2SCOPE = []
	private List F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS_1256 = []
	private List F104A_CAND_INFO_LIST_BY_FMP5_R_AXIS_TRUE = []
	private List F104A_CAND_INFO_LIST_BY_FMP5_R_AXIS_FALSE = []
	private List F104A_CAND_INFO_LIST_BY_FMP5_S_AXIS_TRUE = []
	private List F104A_CAND_INFO_LIST_BY_FMP5_S_AXIS_FALSE = []
	private List F105A_CAND_INFO_LIST_BY_FMP5_RS_AXIS_TRUE = []
	private List F105A_CAND_INFO_LIST_BY_FMP5_RS_AXIS_FALSE = []
	private List F105A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS_AXIS_TRUE = []
	private List F105A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS_AXIS_FALSE = []
	private List F_123_ABC_HIGH_CAND_INFO_LIST = []
	private List F_ABC_123_HIGH_CAND_INFO_LIST = []
	private List F_BBC_123_HIGH_CAND_INFO_LIST = []
	private List F_123_ABC_LOW_CAND_INFO_LIST = []
	private List F_ABC_123_LOW_CAND_INFO_LIST = []
	private List F_BBC_123_LOW_CAND_INFO_LIST = []

	TlixConsolidationHelper(context){
		super(context)
		initCandInfoLists()
	}

	private void initCandInfoLists() {
		initFmp5CandInfoLists()
		initPc2CandInfoLists()
		initBothCandInfoLists()
	}

	private void initFmp5CandInfoLists() {
		int fmp5RS_score = calcFusionScore_fmp5RS()
		int fmp5R1S5_score = FMP5_ROLLED_1_SCORE_FIN_MERGE + FMP5_SLAP_5_SCORE
		int fmp5RS_multiAxis_score = FMP5_ROLLED_1_C_SCORE + FMP5_SLAP_1_C_SCORE

		F102A_CAND_INFO_LIST_BY_FMP5_R = 
			[ F102_EXT_ID, FMP5_ROLLED_1_SCORE, true, 
				[ [ 342, 1, 0, FMP5_ROLLED_1_SCORE,
					[ [ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, 100 ] ]
				] ]
			]
		F102A_CAND_INFO_LIST_BY_FMP5_RS = 
			[ F102_EXT_ID, fmp5RS_score, true, 
				[ [ 342, 1, 0, fmp5RS_score,
					[   [ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, fmp5rFW ],
						[ FMP5_SLAP_1_SCORE, FIN_1, A, FMP5_SLAP, fmp5sFW ] ]
				] ]
			]
		F102A_CAND_INFO_LIST_BY_FMP5_RS_125 = 
			[ F102_EXT_ID, fmp5R1S5_score, true, 
				[ [ 342, 1, 0, fmp5R1S5_score,
					[   [ FMP5_ROLLED_1_SCORE_FIN_MERGE, FIN_1, A, FMP5_ROLLED, 100 ],
						[ FMP5_ROLLED_2_SCORE, FIN_2, A, FMP5_ROLLED, 100 ],
						[ FMP5_SLAP_1_SCORE_FIN_MERGE, FIN_1, A, FMP5_SLAP, 100 ],
						[ FMP5_SLAP_2_SCORE, FIN_2, A, FMP5_SLAP, 100 ],
						[ FMP5_SLAP_5_SCORE, FIN_5, A, FMP5_SLAP, 100 ] ]
				] ]
			]
		F103A_CAND_INFO_LIST_BY_FMP5_R = 
			[ F103_EXT_ID, FMP5_ROLLED_1_SCORE, true, 
				[ [ 342, 1, 0, FMP5_ROLLED_1_SCORE,
					[ [ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, 100 ] ]
				] ]
			]
		F103A_CAND_INFO_LIST_BY_FMP5_S = 
			[ F103_EXT_ID, FMP5_SLAP_1_SCORE, true, 
				[ [ 342, 1, 0, FMP5_SLAP_1_SCORE,
					[ [ FMP5_SLAP_1_SCORE, FIN_1, A, FMP5_SLAP, 100 ] ]
				] ]
			]
		F104A_CAND_INFO_LIST_BY_FMP5_R_AXIS_TRUE =
			[ F104_EXT_ID, FMP5_ROLLED_1_C_SCORE, true, 
				[ [ 342, 1, 0, FMP5_ROLLED_1_C_SCORE,
					[ [ FMP5_ROLLED_1_C_SCORE, FIN_1, C, FMP5_ROLLED, 100 ] ]
				] ]
			]
		F104A_CAND_INFO_LIST_BY_FMP5_R_AXIS_FALSE =
			[ F104_EXT_ID, FMP5_ROLLED_1_C_SCORE, true, 
				[ [ 342, 1, 0, FMP5_ROLLED_1_C_SCORE,
					[ [ FMP5_ROLLED_1_A_SCORE, FIN_1, A, FMP5_ROLLED, 100 ],
					 [ FMP5_ROLLED_1_C_SCORE, FIN_1, C, FMP5_ROLLED, 100 ],
					 [ FMP5_ROLLED_1_D_SCORE, FIN_1, D, FMP5_ROLLED, 100 ] ]
				] ]
			]
		F104A_CAND_INFO_LIST_BY_FMP5_S_AXIS_TRUE =
			[ F104_EXT_ID, FMP5_SLAP_1_C_SCORE, true, 
				[ [ 342, 1, 0, FMP5_SLAP_1_C_SCORE,
					[ [ FMP5_SLAP_1_C_SCORE, FIN_1, C, FMP5_SLAP, 100 ] ]
				] ]
			]
		F104A_CAND_INFO_LIST_BY_FMP5_S_AXIS_FALSE =
			[ F104_EXT_ID, FMP5_SLAP_1_C_SCORE, true, 
				[ [ 342, 1, 0, FMP5_SLAP_1_C_SCORE,
					[ [ FMP5_SLAP_1_A_SCORE, FIN_1, A, FMP5_SLAP, 100 ],
					 [ FMP5_SLAP_1_C_SCORE, FIN_1, C, FMP5_SLAP, 100 ],
					 [ FMP5_SLAP_1_D_SCORE, FIN_1, D, FMP5_SLAP, 100 ] ]
				] ]
			]
		F105A_CAND_INFO_LIST_BY_FMP5_RS_AXIS_TRUE =
			[ F105_EXT_ID, fmp5RS_multiAxis_score, true, 
				[ [ 342, 1, 0, fmp5RS_multiAxis_score,
					[ [ FMP5_ROLLED_1_C_SCORE, FIN_1, C, FMP5_ROLLED, 100 ], 
					  [ FMP5_SLAP_1_C_SCORE, FIN_1, C, FMP5_SLAP, 100 ] ]
				] ]
			]
		F105A_CAND_INFO_LIST_BY_FMP5_RS_AXIS_FALSE =
			[ F105_EXT_ID, fmp5RS_multiAxis_score, true, 
				[ [ 342, 1, 0, fmp5RS_multiAxis_score,
					[ [ FMP5_ROLLED_1_A_SCORE, FIN_1, A, FMP5_ROLLED, 100 ], 
					  [ FMP5_ROLLED_1_B_SCORE, FIN_1, B, FMP5_ROLLED, 100 ], 
					  [ FMP5_ROLLED_1_C_SCORE, FIN_1, C, FMP5_ROLLED, 100 ], 
					  [ FMP5_ROLLED_1_D_SCORE_F105, FIN_1, D, FMP5_ROLLED, 100 ], 
					  [ FMP5_SLAP_1_A_SCORE, FIN_1, A, FMP5_SLAP, 100 ],
					  [ FMP5_SLAP_1_B_SCORE, FIN_1, B, FMP5_SLAP, 100 ],
					  [ FMP5_SLAP_1_C_SCORE, FIN_1, C, FMP5_SLAP, 100 ],
					  [ FMP5_SLAP_1_D_SCORE_F105, FIN_1, D, FMP5_SLAP, 100 ] ]
				] ]
			]
	}

	private void initPc2CandInfoLists() {
		int pc2RS_score = calcFusionScore_pc2RS()
		int pc2R6S6_score = PC2_ROLLED_6_SCORE + PC2_SLAP_6_SCORE
		F101A_CAND_INFO_LIST_BY_PC2_R = 
			[ F101_EXT_ID, PC2_ROLLED_1_SCORE * pc2FW, true, 
				[ [ 342, 1, 0, PC2_ROLLED_1_SCORE * pc2FW,
					[ [ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ] ]
				] ]
			]
		F101A_CAND_INFO_LIST_BY_PC2_S = 
			[ F101_EXT_ID, PC2_SLAP_1_SCORE * pc2FW, true, 
				[ [ 342, 1, 0, PC2_SLAP_1_SCORE * pc2FW,
					[ [ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, 200 ] ]
				] ]
			]
		F101A_CAND_INFO_LIST_BY_PC2_RS = 
			[ F101_EXT_ID, pc2RS_score, true, 
				[ [ 342, 1, 0, pc2RS_score,
					[ [ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, pc2rFW ], 
					  [ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, pc2sFW ] ]
				] ]
			]
		F101A_CAND_INFO_LIST_BY_PC2_RS_16 = 
			[ F101_EXT_ID, pc2R6S6_score * pc2FW, true, 
				[ [ 342, 1, 0, pc2R6S6_score * pc2FW,
					[ [ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ], 
					  [ PC2_ROLLED_6_SCORE, FIN_6, A, PC2_ROLLED, 200 ],
					  [ PC2_SLAP_6_SCORE, FIN_6, A, PC2_SLAP, 200 ] ]
				] ]
			]
		F101A_CAND_INFO_LIST_BY_PC2_RS_2CANTMP = 
			[ F101_EXT_ID, PC2_SLAP_10_SCORE * pc2FW, true, 
				[ 	[ 1342, 1, 0, PC2_SLAP_10_SCORE * pc2FW,
					[ [ PC2_SLAP_10_SCORE, FIN_10, A, PC2_SLAP, 200 ] ] ],
					[ 342, 1, 0, pc2R6S6_score * pc2FW,
					[ [ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ], 
					  [ PC2_ROLLED_6_SCORE, FIN_6, A, PC2_ROLLED, 200 ],
					  [ PC2_SLAP_6_SCORE, FIN_6, A, PC2_SLAP, 200 ] ] ],
 				]
			]
		F103A_CAND_INFO_LIST_BY_PC2_R = 
			[ F103_EXT_ID, PC2_ROLLED_1_SCORE * pc2FW, true, 
				[ [ 342, 1, 0, PC2_ROLLED_1_SCORE * pc2FW,
					[ [ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ] ]
				] ]
			]
		F_123_ABC_LOW_CAND_INFO_LIST = 
			[ F_123_ABC_LOW_EXT_ID, pc2RS_score, true, 
				[ 
					[ 342, 1, 0, pc2RS_score, F101A_CAND_INFO_LIST_BY_PC2_RS[3][0][4] ],
					[ 1342, 1, 0, pc2RS_score, F101A_CAND_INFO_LIST_BY_PC2_RS[3][0][4] ] 
				]
			]
		F_ABC_123_LOW_CAND_INFO_LIST = 
			[ F_ABC_123_LOW_EXT_ID, pc2RS_score, true, F_123_ABC_LOW_CAND_INFO_LIST[3] ] 
		F_BBC_123_LOW_CAND_INFO_LIST = 
			[ F_ABC_123_LOW_EXT_ID, pc2RS_score, true, F_123_ABC_LOW_CAND_INFO_LIST[3] ]
	}

	private void initBothCandInfoLists() {
		int pc2RS_fmp5RS_score = calcFusionScore_pcRS_fmp5RS()
		int pc2RS_fmp5RS_finMerge_score = getCompositScore(PC2_ROLLED_6_SCORE, PC2_SLAP_1_SCORE, FMP5_ROLLED_1_SCORE_FIN_MERGE, FMP5_SLAP_5_SCORE)
 		int pc2S_fmp5R_score = PC2_SLAP_1_SCORE * pc2FW + FMP5_ROLLED_1_SCORE
		int pc2S_fmp5S_score = PC2_SLAP_1_SCORE * pc2FW + FMP5_SLAP_1_SCORE
		int pc2RS_fmp5RS_multiAxis_score = PC2_ROLLED_1_SCORE * pc2FW + PC2_SLAP_1_SCORE * pc2FW + FMP5_ROLLED_1_C_SCORE + FMP5_SLAP_1_C_SCORE

		F103A_CAND_INFO_LIST_BY_PC2_S_FMP5_R = 
			[ F103_EXT_ID, pc2S_fmp5R_score, true, 
				[ [ 342, 1, 0, pc2S_fmp5R_score,
					[ [ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, 200 ],
					  [ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, 100 ] ]
				] ]
			]
		F103A_CAND_INFO_LIST_BY_PC2_S_FMP5_S = 
			[ F103_EXT_ID, pc2S_fmp5S_score, true, 
				[ [ 342, 1, 0, pc2S_fmp5S_score,
					[ [ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, 200 ],
					  [ FMP5_SLAP_1_SCORE, FIN_1, A, FMP5_SLAP, 100 ] ]
				] ]
			]
		F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS = 
			[ F103_EXT_ID, pc2RS_fmp5RS_score, true, 
				[ [ 342, 1, 0, pc2RS_fmp5RS_score,
					[ [ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, pc2rFW ],
					  [ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, pc2sFW ],
					  [ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, fmp5rFW ],
					  [ FMP5_SLAP_1_SCORE, FIN_1, A, FMP5_SLAP, fmp5sFW ] ]
				] ]
			]
		F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS_2SCOPE = 
			[ F103_EXT_ID, pc2RS_fmp5RS_score, true, 
				[ [ 342, 1, 0, pc2RS_fmp5RS_score,
					[ [ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ],
					  [ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, 200 ],
					  [ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, 100 ],
					  [ FMP5_SLAP_1_SCORE, FIN_1, A, FMP5_SLAP, 100 ] ] ],
				  [ 1342, 1, 0, pc2RS_fmp5RS_score, F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS[3][0][4] ],
 				]
			]
		F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS_1256 = 
			[ F103_EXT_ID, pc2RS_fmp5RS_finMerge_score, true, 
				[ [ 342, 1, 0, pc2RS_fmp5RS_finMerge_score,
					[ [ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ],
					  [ PC2_ROLLED_6_SCORE, FIN_6, A, PC2_ROLLED, 200 ],
					  [ PC2_SLAP_6_SCORE, FIN_6, A, PC2_SLAP, 200 ],
					  [ FMP5_ROLLED_1_SCORE_FIN_MERGE, FIN_1, A, FMP5_ROLLED, 100 ],
					  [ FMP5_ROLLED_2_SCORE, FIN_2, A, FMP5_ROLLED, 100 ],
					  [ FMP5_SLAP_1_SCORE_FIN_MERGE, FIN_1, A, FMP5_SLAP, 100 ],
					  [ FMP5_SLAP_2_SCORE, FIN_2, A, FMP5_SLAP, 100 ],
					  [ FMP5_SLAP_5_SCORE, FIN_5, A, FMP5_SLAP, 100 ] ]
				] ]
			]
		F105A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS_AXIS_TRUE =
			[ F105_EXT_ID, pc2RS_fmp5RS_multiAxis_score, true, 
				[ [ 342, 1, 0, pc2RS_fmp5RS_multiAxis_score,
					[ [ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ],
					  [ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, 200 ],
					  [ FMP5_ROLLED_1_C_SCORE, FIN_1, C, FMP5_ROLLED, 100 ], 
					  [ FMP5_SLAP_1_C_SCORE, FIN_1, C, FMP5_SLAP, 100 ] ]
				] ]
			]
		F105A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS_AXIS_FALSE =
			[ F105_EXT_ID, pc2RS_fmp5RS_multiAxis_score, true, 
				[ [ 342, 1, 0, pc2RS_fmp5RS_multiAxis_score,
					[ [ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ],
					  [ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, 200 ],
					  [ FMP5_ROLLED_1_A_SCORE, FIN_1, A, FMP5_ROLLED, 100 ], 
					  [ FMP5_ROLLED_1_B_SCORE, FIN_1, B, FMP5_ROLLED, 100 ], 
					  [ FMP5_ROLLED_1_C_SCORE, FIN_1, C, FMP5_ROLLED, 100 ], 
					  [ FMP5_ROLLED_1_D_SCORE_F105, FIN_1, D, FMP5_ROLLED, 100 ], 
					  [ FMP5_SLAP_1_A_SCORE, FIN_1, A, FMP5_SLAP, 100 ],
					  [ FMP5_SLAP_1_B_SCORE, FIN_1, B, FMP5_SLAP, 100 ],
					  [ FMP5_SLAP_1_C_SCORE, FIN_1, C, FMP5_SLAP, 100 ],
					  [ FMP5_SLAP_1_D_SCORE_F105, FIN_1, D, FMP5_SLAP, 100 ] ]
				] ]
			]
		F_123_ABC_HIGH_CAND_INFO_LIST = 
			[ F_123_ABC_HIGH_EXT_ID, pc2RS_fmp5RS_score, true, 
				[ 
					[ 342, 1, 0, pc2RS_fmp5RS_score, F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS[3][0][4] ],
					[ 1342, 1, 0, pc2RS_fmp5RS_score, F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS[3][0][4] ] 
				]
			]
		F_ABC_123_HIGH_CAND_INFO_LIST = 
			[ F_ABC_123_HIGH_EXT_ID, pc2RS_fmp5RS_score, true, F_123_ABC_HIGH_CAND_INFO_LIST[3] ]
		F_BBC_123_HIGH_CAND_INFO_LIST = 
			[ F_BBC_123_HIGH_EXT_ID, pc2RS_fmp5RS_score, true, F_123_ABC_HIGH_CAND_INFO_LIST[3] ]
	}

	private int calcFusionScore_pcRS_fmp5RS() {
		int pc2RScore = mergeFWeight(PC2_ROLLED_1_SCORE, pc2rFW)
		int pc2SScore = mergeFWeight(PC2_SLAP_1_SCORE, pc2sFW)
		int fmp5RScore = mergeFWeight(FMP5_ROLLED_1_SCORE, fmp5rFW)
		int fmp5SScore = mergeFWeight(FMP5_SLAP_1_SCORE, fmp5sFW)
		int fScore = pc2RScore + pc2SScore + fmp5RScore + fmp5SScore
		return cutoffScore(fScore)
	}

	private int calcFusionScore_pc2RS() {
		int pc2RScore = mergeFWeight(PC2_ROLLED_1_SCORE, pc2rFW)
		int pc2SScore = mergeFWeight(PC2_SLAP_1_SCORE, pc2sFW)
		int fScore = pc2RScore + pc2SScore
		return cutoffScore(fScore)
	}

	private int calcFusionScore_fmp5RS() {
		int fmp5RScore = mergeFWeight(FMP5_ROLLED_1_SCORE, fmp5rFW)
		int fmp5SScore = mergeFWeight(FMP5_SLAP_1_SCORE, fmp5sFW)
		int fScore = fmp5RScore + fmp5SScore
		return cutoffScore(fScore)
	}


	public List getCandList_ColdSearch1() {
		return [ F101A_CAND_INFO_LIST_BY_PC2_R, F103A_CAND_INFO_LIST_BY_PC2_R ]
	}

	public List getCandList_ColdSearch2() {
		return [ F103A_CAND_INFO_LIST_BY_PC2_S_FMP5_R, 
				F101A_CAND_INFO_LIST_BY_PC2_S,
				F102A_CAND_INFO_LIST_BY_FMP5_R ]
	}

	public List getCandList_ColdSearch3() {
		return [ F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS,
				F102A_CAND_INFO_LIST_BY_FMP5_RS,
				F101A_CAND_INFO_LIST_BY_PC2_RS ]
	}

	public List getCandList_inquirySet1() {
		return [ F103A_CAND_INFO_LIST_BY_PC2_R ]
	}

	public List getCandList_inquirySet2() {
		return [ F103A_CAND_INFO_LIST_BY_FMP5_S ]
	}

	public List getCandList_inquirySet3() {
		return [ F103A_CAND_INFO_LIST_BY_PC2_S_FMP5_S ]
	}

	public List getCandList_fingerMerge1() {
		return [ F101A_CAND_INFO_LIST_BY_PC2_RS_16 ]
	}

	public List getCandList_fingerMerge2() {
		return [ F102A_CAND_INFO_LIST_BY_FMP5_RS_125 ]
	}

	public List getCandList_fingerMerge3() {
		return [ F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS_1256 ]
	}

	public List getCandList_fingerMerge4() {
		return [ F101A_CAND_INFO_LIST_BY_PC2_RS_2CANTMP ]
	}

	public List getCandList_inquirySetMerge1() {
		return [ F101A_CAND_INFO_LIST_BY_PC2_RS ]
	}

	public List getCandList_inquirySetMerge2() {
		return [ F102A_CAND_INFO_LIST_BY_FMP5_RS ]
	}

	public List getCandList_inquirySetMerge3() {
		return [ F103A_CAND_INFO_LIST_BY_PC2_S_FMP5_R ]
	}

	public List getCandList_inquirySetMerge4() {
		return [ F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS ]
	}

	public List getCandList_muMerge() {
		return getCandList_ColdSearch3()
	}

	public List getCandList_scopeMerge() {
		return [ F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS_2SCOPE ]
	}

	public List getCandList_multiAxis_true_1() {
		return [ F104A_CAND_INFO_LIST_BY_FMP5_R_AXIS_TRUE ]
	}

	public List getCandList_multiAxis_true_2() {
		return [ F104A_CAND_INFO_LIST_BY_FMP5_S_AXIS_TRUE ]
	}

	public List getCandList_multiAxis_true_3() {
		return [ F105A_CAND_INFO_LIST_BY_FMP5_RS_AXIS_TRUE ]
	}

	public List getCandList_multiAxis_true_4() {
		return [ F105A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS_AXIS_TRUE ]
	}

	public List getCandList_multiAxis_false_1() {
		return [ F104A_CAND_INFO_LIST_BY_FMP5_R_AXIS_FALSE ]
	}

	public List getCandList_multiAxis_false_2() {
		return [ F104A_CAND_INFO_LIST_BY_FMP5_S_AXIS_FALSE ]
	}

	public List getCandList_multiAxis_false_3() {
		return [ F105A_CAND_INFO_LIST_BY_FMP5_RS_AXIS_FALSE ]
	}

	public List getCandList_multiAxis_false_4() {
		return [ F105A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS_AXIS_FALSE ]
	}

	public List getCandList_fWeight(Integer fmp5rFW, Integer fmp5sFW, Integer pc2rFW, Integer pc2sFW) {
		this.fmp5rFW = fmp5rFW
		this.fmp5sFW = fmp5sFW
		this.pc2rFW = pc2rFW
		this.pc2sFW = pc2sFW
		initCandInfoLists()
		return [ F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS ]
	}

	public List getCandList_fWeight_multi(Integer fmp5rFW, Integer fmp5sFW, Integer pc2rFW, Integer pc2sFW) {
		this.fmp5rFW = fmp5rFW
		this.fmp5sFW = fmp5sFW
		this.pc2rFW = pc2rFW
		this.pc2sFW = pc2sFW
		initCandInfoLists()
		return getCandList_ColdSearch3()
	}

	public List getCandList_candSort() {
		return [ F_123_ABC_HIGH_CAND_INFO_LIST,
				F_ABC_123_HIGH_CAND_INFO_LIST,
				F_BBC_123_HIGH_CAND_INFO_LIST,
				F_123_ABC_LOW_CAND_INFO_LIST,
				F_ABC_123_LOW_CAND_INFO_LIST,
				F_BBC_123_LOW_CAND_INFO_LIST ]
	}
 
        public int getCompositScore(Integer PC2_ROLLED_SCORE,
                                    Integer PC2_SLAP_SCORE,
                                    Integer FMP5_ROLLED_SCORE,
                                    Integer FMP5_SLAP_SCORE)
        {
            
            int compositeScore = 0

            int pc2FW_default = 200 
            int fmp5FW_default = 100 

            int pc2rFW_devided_100 = 0 
            int pc2sFW_devided_100 = 0 
            int fmp5rFW_devided_100 = 0 
            int fmp5sFW_devided_100 = 0 
            
            if(pc2rFW == null){
                pc2rFW_devided_100 = pc2FW_default / 100 
            }else{
                pc2rFW_devided_100 = pc2rFW / 100 
            }

            if(pc2sFW == null){
                pc2sFW_devided_100 = pc2FW_default / 100 
            }else{
                pc2sFW_devided_100 = pc2sFW / 100 
            }

            if(fmp5rFW == null){
                fmp5rFW_devided_100 = fmp5FW_default / 100 
            }else{
                fmp5rFW_devided_100 = fmp5rFW / 100 
            }


            if(fmp5rFW == null){
                fmp5sFW_devided_100 = fmp5FW_default / 100 
            }else{
                fmp5sFW_devided_100 = fmp5sFW / 100 
            }
            
            compositeScore = PC2_ROLLED_SCORE * pc2rFW_devided_100  + 
                             PC2_SLAP_SCORE * pc2sFW_devided_100 + 
                             FMP5_ROLLED_SCORE * fmp5rFW_devided_100 + 
                             FMP5_SLAP_SCORE * fmp5sFW_devided_100
            
            if( 9999 <= compositeScore ){
                return 9999
            }
            
            return compositeScore
        }

}

