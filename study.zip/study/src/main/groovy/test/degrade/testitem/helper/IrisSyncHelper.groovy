package test.degrade.testitem.helper

import test.degrade.management.AbendProcessor
import test.common.constants.aim.*
import test.degrade.testitem.holder.IrisExtractResultHolder
import static test.common.constants.data.ImageDataList.*

class IrisSyncHelper extends PayloadHelper {

    private static final String PROJECT_NAME = "Iris_IR_ID"

	private static final String EXT_ID_SCOPE_1 = "${PROJECT_NAME}-scope-1"
	private static final String EXT_ID_SCOPE_2 = "${PROJECT_NAME}-scope-2"

    private static final int IDB_SCOPE_1_CON_ID = 343
    private static final int IDB_SCOPE_2_CON_ID = 1343
    private static final int EVENT_1 = 1
    private static final int S_REQ_0 = 0
    private static final int POS_0 = 0
    private static final int POS_1 = 1
    private static final int POINT_POS_R = 60
    private static final int POINT_POS_L = 61

    private static final int MAX_SCORE = 9999
    private static final int ZERO_SCORE = 0

    private static String TRUE = "true"
    private static String FALSE = "false"

    private static int j2kRRScore
    private static int j2kRRScoreSmode1
    private static int j2kRLScore
    private static int j2kLRScore
    private static int j2kLLScore
    private static int j2kLLScoreSmode1
    private static int j2kFScore
    private static int j2kIRScore
    private static int j2kILScore
     
    private static int maxRRScore
    private static int maxRLScore
    private static int maxLRScore
    private static int maxLLScore
    private static int maxFScore
    private static int maxIRScore
    private static int maxILScore

    private IrisCommonHelper commonHelper
    private int targetContainerId
    private boolean isHit
    static boolean ommitSearchPayload
    static List scopeList
    static List searchContainerList

    IrisSyncHelper(context) {
        super(context)
        this.commonHelper = new IrisCommonHelper(context)
        this.targetContainerId = IDB_SCOPE_1_CON_ID
        this.isHit = true
        initAssertionScore(context)
    }

    protected void initPayloadMap() {
        payloadMap = new IrisPayloadMap()
        updateCommonOptVal("maxCandidates", "100")
        ommitSearchPayload = false
        scopeList = [ 1 ]
        searchContainerList = [ 343 ]
    }

    public String makePayload() {
        if(ommitSearchPayload) {
            return ""
        }
        StringBuilder sb = new StringBuilder()
        sb.append("<search-inputs-payload>\n")
        sb.append("<ns2:search-inputs-payload xmlns:ns2='urn:nec:aim'>\n")
        sb.append("<meta-info>\n")
        sb.append(makeMetaCommonXml())
        sb.append("</meta-info>\n")
        sb.append(makePrefilterOptXml())
        sb.append(makeIrisOptionsXml())
        sb.append("</ns2:search-inputs-payload>\n")
        sb.append("</search-inputs-payload>\n")
        return sb.toString()
    }

    public String getDefaultFileImgXml() {
        return commonHelper.getDefaultFileImgXml()
    }

    public String getDefaultSearchImgXml() {
        return commonHelper.getDefaultSearchImgXml()
    }

    public String getJ2kFileImgXml() {
        return getDefaultFileImgXml()
    }

    public String getJ2kSearchImgXml() {
        return getDefaultSearchImgXml()
    }

    public List getCandList_scope1(int id) {
        List candInfoList = []
		switch(id) {
            case 1:
				candInfoList.add( makeMaxScoreCand(EXT_ID_SCOPE_1) )
				break;
			case 2:
				candInfoList.add( makeMaxScoreCand(EXT_ID_SCOPE_1, FALSE) )
				break;
			default:
                abendTest(id)
		}
        return candInfoList
    }

    public List getCandList_scope2(int id) {
        List candInfoList = []
        targetContainerId = IDB_SCOPE_2_CON_ID
		switch(id) {
            case 1:
				candInfoList.add( makeMaxScoreCand(EXT_ID_SCOPE_2) )
				break;
			case 2:
				candInfoList.add( makeMaxScoreCand(EXT_ID_SCOPE_2, FALSE) )
				break;
			default:
                abendTest(id)
        }
        return candInfoList
    }

    public List getCandList_beforeUpdate1(int id) {
        List candInfoList = []
		switch(id) {
            case 1:
				candInfoList.add(makeMaxScoreCand(EXT_ID_SCOPE_1))
				break;
			case 2:
				candInfoList.add(makeMaxScoreCand(EXT_ID_SCOPE_1, FALSE))
				break;
			default:
                abendTest(id)
        }
        return candInfoList
    }

    public List getCandList_afterUpdate1(int id) {
        List candInfoList = []
		switch(id) {
            case 1:
				candInfoList.add( makeDefaultScoreCand(EXT_ID_SCOPE_1) )
				break;
			case 2:
				candInfoList.add( makeDefaultScoreCand(EXT_ID_SCOPE_1, FALSE) )
				break;
			default:
                abendTest(id)
        }
        return candInfoList
    }

    public List getCandList_beforeUpdate2(int id) {
        List candInfoList = []
        targetContainerId = IDB_SCOPE_2_CON_ID
		switch(id) {
            case 1:
				candInfoList.add(makeMaxScoreCand(EXT_ID_SCOPE_2))
				break;
			case 2:
				candInfoList.add(makeMaxScoreCand(EXT_ID_SCOPE_2, FALSE))
				break;
			default:
                abendTest(id)
        }

        return candInfoList
    }

    public List getCandList_afterUpdate2(int id) {
        List candInfoList = []
        targetContainerId = IDB_SCOPE_2_CON_ID
		switch(id) {
            case 1:
				candInfoList.add( makeDefaultScoreCand(EXT_ID_SCOPE_2) )
				break;
			case 2:
				candInfoList.add( makeDefaultScoreCand(EXT_ID_SCOPE_2, FALSE) )
				break;
			default:
                abendTest(id)
        }
        return candInfoList
    }

    public List makeDefaultScoreCand(String extId) {
		return makeCandInfo(extId, j2kFScore, j2kIRScore, j2kILScore, j2kRRScore, j2kRLScore, j2kLRScore, j2kLLScore, TRUE)
    }

    public List makeDefaultScoreCand(String extId, String isCrossMatch) {
		return makeCandInfo(extId, j2kFScore, j2kIRScore, j2kILScore, j2kRRScore, j2kRLScore, j2kLRScore, j2kLLScore, isCrossMatch)
    }

    private List makeMaxScoreCand(String extId) {
		return makeCandInfo(extId, getHighScore(getHighScore(maxRRScore, maxRLScore), getHighScore(maxLRScore, maxLLScore)),
							getHighScore(maxRRScore, maxRLScore), getHighScore(maxLRScore, maxLLScore),
							maxRRScore, maxRLScore, maxLRScore, maxLLScore, TRUE)
    }

    private List makeMaxScoreCand(String extId, String isCrossMatch) {
		return makeCandInfo(extId, getHighScore(getHighScore(maxRRScore, maxRLScore), getHighScore(maxLRScore, maxLLScore)),
							getHighScore(maxRRScore, maxRLScore), getHighScore(maxLRScore, maxLLScore),
							maxRRScore, maxRLScore, maxLRScore, maxLLScore, isCrossMatch)
    }

    private List makeCandInfo(
                String extId, int finalScore, int iScoreR, int iScoreL, 
                int rScoreRR, int rScoreRL, int rScoreLR, int rScoreLL, String isCrossMatch) {

		def candInfo = []
		if("x${isCrossMatch}" == "x${TRUE}"){
            candInfo =
			[ extId, finalScore, isHit,
				[ [ targetContainerId, EVENT_1, S_REQ_0, finalScore,
					[ [ iScoreR, POS_0, 
                        [ [ POS_0, rScoreRR ], [ POS_1, rScoreRL ] ] ],
					  [ iScoreL, POS_1, 
                        [ [ POS_0, rScoreLR ], [ POS_1, rScoreLL ] ] ] ] ] ] ]
		}else if("x${isCrossMatch}" == "x${FALSE}"){
            candInfo =
            [ extId, finalScore, isHit,
                [ [ targetContainerId, EVENT_1, S_REQ_0, finalScore,
                    [ [ iScoreR, POS_0,
                        [ [ POS_0, rScoreRR ] ] ],
                      [ iScoreL, POS_1,
                        [ [ POS_1, rScoreLL ] ] ] ] ] ] ]
        }else{
            new AbendProcessor(soapuiObj.getContext()).abendTest("Unexpected isCrossMatch value '${isCrossMatch}'.")
        }
        return candInfo
    }

    private void abendTest(int id){
        new AbendProcessor(soapuiObj.getContext()).abendTest("Unexpected id value '${id}'.")
    }

    private void initAssertionScore(context) {
        j2kRRScore = commonHelper.j2kRRScore
        j2kRRScoreSmode1 = commonHelper.j2kRRScoreSmode1
        j2kRLScore = commonHelper.j2kRLScore
        j2kLRScore = commonHelper.j2kLRScore
        j2kLLScore = commonHelper.j2kLLScore
        j2kLLScoreSmode1 = commonHelper.j2kLLScoreSmode1
        j2kFScore = commonHelper.j2kFScore
        j2kIRScore = commonHelper.j2kIRScore
        j2kILScore = commonHelper.j2kILScore

        maxRRScore = commonHelper.maxRRScore
        maxRLScore = commonHelper.maxRLScore
        maxLRScore = commonHelper.maxLRScore
        maxLLScore = commonHelper.maxLLScore
        maxFScore = commonHelper.maxFScore
        maxIRScore = commonHelper.maxIRScore
        maxILScore = commonHelper.maxILScore
    }

	private getHighScore(def score_1, def score_2){
		return [ score_1, score_2 ].max()
	}
}

