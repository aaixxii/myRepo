package test.degrade.testitem.helper

import test.degrade.util.SoapuiObject
import groovy.xml.StreamingMarkupBuilder
import common.xml.XMLObject

class ExtractXFunctionHelper{

	protected SoapuiObject soapuiObj
	def root = """<fe-types></fe-types>"""
	def XDBL = "xdbl"
	def LDBX = "ldbx"
	def LIX = "lix"
	def LLIX = "llix"
	def TLIX = "tlix"
	def ROLLED = "rolled"
	def SLAP = "slap"
	def PC2 = "pc2"
	def FMP5 = "fmp5"
	def FE_TYPE = "fe-type"
	def xml
	
	ExtractXFunctionHelper(context){
		this.soapuiObj = new SoapuiObject(context)
	}

	def createFeType(function){
		this.xml = new XmlSlurper().parseText(root)
	}
	
	def addXDBL(){
		addOneElement(XDBL)
	}
	
	def addLDBX(){
		addOneElement(LDBX)
	}
	
	def addLIX(){
		addOneElement(LIX)
	}
	
	def addLLIX(){
		addOneElement(LLIX)
	}
	
	def addTLIX(){
		addOneElement(TLIX)
	}
	
	def addRolled(element_1){
		addTwoElement(element_1, ROLLED)
	}
	
	def addSlap(element_1){
		addTwoElement(element_1, SLAP)
	}
	
	def addPc2(element_1,element_2){
		addThreeElement(element_1, element_2, PC2)
	}

	def addFmp5(element_1,element_2){
		addThreeElement(element_1, element_2, FMP5)
	}
	
	def addMultiFinger(element_1){
		xml.appendNode {
			"${element_1}"(){
				"${ROLLED}"()
				"${SLAP}"()
			}
		}
	}
	
	def addSingleFingerSingleMinutiaType(element_1, element_2, element_3, value){
		xml.appendNode {
			"${element_1}"(){
				"${element_2}"(){
					"${element_3}"("fe-type" : "${value}")
				}
			}
		}
	}


	def addSingleFingerMultiMinutiaType(element_1, element_2, value_1, value_2){
		xml.appendNode {
			"${element_1}"(){
				"${element_2}"(){
					"${PC2}"("fe-type" : "${value_1}")
					"${FMP5}"("fe-type" : "${value_2}")
				}
			}
		}
	}

	def addSingleFingerMultiMinutiaType(element_1, element_2, value_1 ){
        xml.appendNode {
            "${element_1}"(){
                "${element_2}"(){
                    "${PC2}"()
                    "${FMP5}"("fe-type" : "${value_1}")
                }
            }
        }
    }
	
	def addMultiFingerSingleMinutiaType(element_1, element_2, element_3, value_1, value_2){
		xml.appendNode {
			"${element_1}"(){
				"${ROLLED}"(){
					"${element_2}"("fe-type" : "${value_1}")
				}
				"${SLAP}"(){
					"${element_3}"("fe-type" : "${value_2}")
				}
			}
		}
	}


	def addMultiFingerMultiMinutiaType(element_1, value_1, value_2, value_3, value_4){
		xml.appendNode {
			"${element_1}"(){
				"${ROLLED}"(){
					"${PC2}"("fe-type" : "${value_1}")
					"${FMP5}"("fe-type" : "${value_2}")
				}
				"${SLAP}"(){
					"${PC2}"("fe-type" : "${value_3}")
					"${FMP5}"("fe-type" : "${value_4}")
				}
			}
		}
	}

	

	def addOneElement(element_1){
		xml.appendNode {
			"${element_1}"()
		}
	}
	
	def addTwoElement(element_1, element_2){
		xml.appendNode {
			"${element_1}"(){
				"${element_2}"()
			}
		}
	}
	
	def addThreeElement(element_1, element_2, element_3){
		xml.appendNode {
			"${element_1}"(){
				"${element_2}"(){
					"${element_3}"()
				}
			}
		}
	}

	def getXML(){
		def builder = new StreamingMarkupBuilder()
		def xmlString = builder.bind{
			mkp.yield xml
		}
       return xmlString
	}
}
