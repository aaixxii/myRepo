package test.degrade.testitem.factory

import test.degrade.testitem.helper.TestTemplateCreateHelper
import test.degrade.testitem.helper.templates.*
import test.degrade.testitem.helper.*

class TestTemplateCreateHelperFactory{

	static TestTemplateCreateHelper createHelperInstance(context, String functionType){
		switch(functionType){
			case "TI":
				return new TiTestTemplateCreateHelper(context)
			case "TIM":
				return new TimTestTemplateCreateHelper(context)
			case "LI":
				return new LiTestTemplateCreateHelper(context)
			case "LIS":
				return new LisTestTemplateCreateHelper(context)
			case "LIM":
				return new LimTestTemplateCreateHelper(context)
			case "LIX":
				return new LixTestTemplateCreateHelper(context)
			case "TLI":
				return new TliTestTemplateCreateHelper(context)
			case "TLIS":
				return new TlisTestTemplateCreateHelper(context)
			case "TLIM":
				return new TlimTestTemplateCreateHelper(context)
			case "TLIX":
				return new TlixTestTemplateCreateHelper(context)
			case "LLI":
				return new LliTestTemplateCreateHelper(context)
			case "LLIS":
				return new LlisTestTemplateCreateHelper(context)
			case "LLIM":
				return new LlimTestTemplateCreateHelper(context)
			case "LLIX":
				return new LlixTestTemplateCreateHelper(context)
			case "LIP":
				return new LipTestTemplateCreateHelper(context)
			case "TLIP":
				return new TlipTestTemplateCreateHelper(context)
			case "LLIP":
				return new LlipTestTemplateCreateHelper(context)
			case "FI":
				return new FiTestTemplateCreateHelper(context)
			case "II":
				return new IiTestTemplateCreateHelper(context)
			case "VX":
				return new VxTestTemplateCreateHelper(context)
		}
	}
}
