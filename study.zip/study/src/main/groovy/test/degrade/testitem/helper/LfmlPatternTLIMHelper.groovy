package test.degrade.testitem.helper

import static test.common.constants.aim.SearchLFMLParameter.*


class LfmlPatternTLIMHelper {
    
	private static final List S_AUTO_F_AUTO_F8_SL3_RAW_SCORE_LIST = [
        1584, 1007, 342, 736, 1526, 1747, 936, 0, 1661, 1219, 518, 1652, 843, 759, 520, 1244 ]
    private static final List S_MANUAL_F_AUTO_F8_SL3_RAW_SCORE_LIST = [
        563, 1007,  342, 736, 1526, 1747, 936, 0, 1661, 331, 518, 1652, 480, 0, 520, 1244 ]
    private static final List S_AUTO_F_MANUAL_F8_SL3_RAW_SCORE_LIST = [
        563, 675, 1584, 1064, 342, 736, 1526, 1747, 936, 0, 1661, 1219, 1113, 1187, 945, 1259 ]
    private static final List S_MANUAL_F_MANUAL_F8_SL3_RAW_SCORE_LIST = [
        0, 675, 563, 1064, 342, 736, 1526, 1747, 936, 0, 1661, 331, 1113, 1187, 945, 1259 ]
    private static final List S_AUTO_F_MANUAL_MULTI_AXIS_A_F8_SL3_RAW_SCORE_LIST = [
        1184, 1329, 1537, 1215, 893, 863, 1446, 2060, 961, 710, 1579, 938, 1918, 1531, 774, 1390 ]
    private static final List S_AUTO_F_MANUAL_MULTI_AXIS_B_F8_SL3_RAW_SCORE_LIST = [
        1349, 1329, 1537, 1215, 893, 863, 1446, 2060, 961, 710, 1579, 938, 1918, 1531, 774, 1390 ]
    private static final List S_AUTO_F_MANUAL_MULTI_AXIS_C_F8_SL3_RAW_SCORE_LIST = [
        1103, 1329, 1537, 1215, 893, 863, 1446, 2060, 961, 710, 1579, 938, 1918, 1531, 774, 1390 ]
    private static final List S_AUTO_F_MANUAL_MULTI_AXIS_D_F8_SL3_RAW_SCORE_LIST = [
        1150, 1329, 1537, 1215, 893, 863, 1446, 2060, 961, 710, 1579, 938, 1918, 1531, 774, 1390 ]
    private static final List S_MANUAL_F_MANUAL_MULTI_AXIS_A_F8_SL3_RAW_SCORE_LIST = [
        413, 1329, 523, 1215, 893, 863, 1446, 2060, 961, 710, 1579, 271, 1918, 1531, 774, 1390 ]
    private static final List S_MANUAL_F_MANUAL_MULTI_AXIS_B_F8_SL3_RAW_SCORE_LIST = [
        593, 1329, 523, 1215, 893, 863, 1446, 2060, 961, 710, 1579, 271, 1918, 1531, 774, 1390 ]

    private static final List S_AUTO_F_AUTO_F8_SL3_ROTATION_1_RAW_SCORE_LIST = [
        1561, 1087, 493, 859, 1556, 1747, 922, 423, 1700, 1046, 506, 1702, 730, 703, 520, 1244 ]
    private static final List S_AUTO_F_AUTO_F8_SL3_ROTATION_2_RAW_SCORE_LIST = [
        1584, 981, 429, 836, 1508, 1747, 936, 0, 1661, 1219, 518, 1702, 843, 740, 520, 1244 ]
    private static final List S_AUTO_F_MANUAL_F8_SL3_ROTATION_1_RAW_SCORE_LIST = [
        563, 675, 1561, 1064, 493, 859, 1556, 1747, 922, 423, 1700, 1046, 1120, 1187, 945, 1259 ]
    private static final List S_AUTO_F_MANUAL_F8_SL3_ROTATION_2_RAW_SCORE_LIST = [
        563, 675, 1584, 1064, 429, 836, 1508, 1747, 936, 0, 1661, 1219, 1131, 1187, 945, 1259 ]

    private static final String A = "A"
    private static final String B = "B"
    private static final String C = "C"
    private static final String D = "D"


    private List rawScoreList
    private List rawScoreSIndexList
    private List rawScoreFIndexList
    private int score = -1

    public void setup(boolean isSManual, boolean isFManual, int searchLevel) {
        if(isSManual && isFManual) {
            if(searchLevel == 3) {
                rawScoreList = S_MANUAL_F_MANUAL_F8_SL3_RAW_SCORE_LIST
                setupIndexListManual()
            }
        }else if(isSManual && !isFManual) {
            if(searchLevel == 3) {
                rawScoreList = S_MANUAL_F_AUTO_F8_SL3_RAW_SCORE_LIST
                setupIndexListAuto()
            }
        }else if(!isSManual && isFManual) {
            if(searchLevel == 3) {
                rawScoreList = S_AUTO_F_MANUAL_F8_SL3_RAW_SCORE_LIST
                setupIndexListManual()
            }
        }else if(!isSManual && !isFManual) {
            if(searchLevel == 3) {
                rawScoreList = S_AUTO_F_AUTO_F8_SL3_RAW_SCORE_LIST
                setupIndexListAuto()
            }
        }
    }

    public void setupMultiAxis(boolean isSManual, String axis) {
        if(isSManual) {
            if(axis == A) {
                rawScoreList = S_MANUAL_F_MANUAL_MULTI_AXIS_A_F8_SL3_RAW_SCORE_LIST
            }else if(axis == B) {
                rawScoreList = S_MANUAL_F_MANUAL_MULTI_AXIS_B_F8_SL3_RAW_SCORE_LIST
            }else{
                assert false, "Axis value of Properties test step must be A or B!! Actual '${axis}'."
            }
        }else{
            if(axis == A) {
                rawScoreList = S_AUTO_F_MANUAL_MULTI_AXIS_A_F8_SL3_RAW_SCORE_LIST
            }else if(axis == B) {
                rawScoreList = S_AUTO_F_MANUAL_MULTI_AXIS_B_F8_SL3_RAW_SCORE_LIST
            }else if(axis == C) {
                rawScoreList = S_AUTO_F_MANUAL_MULTI_AXIS_C_F8_SL3_RAW_SCORE_LIST
            }else if(axis == D) {
                rawScoreList = S_AUTO_F_MANUAL_MULTI_AXIS_D_F8_SL3_RAW_SCORE_LIST
            }
        }
        setupIndexListManual()
    }

    public void setupRotation(boolean isSManual, boolean isFManual, int rotationLimit) {
        if(isSManual && isFManual) {
            if(rotationLimit == 3) {
                rawScoreList = S_MANUAL_F_MANUAL_F8_SL3_RAW_SCORE_LIST
                setupIndexListManual()
            }
        }else if(isSManual && !isFManual) {
            if(rotationLimit == 3) {
                rawScoreList = S_MANUAL_F_AUTO_F8_SL3_RAW_SCORE_LIST
                setupIndexListAuto()
            }
        }else if(!isSManual && isFManual) {
            if(rotationLimit == 1) {
                rawScoreList = S_AUTO_F_MANUAL_F8_SL3_ROTATION_1_RAW_SCORE_LIST
            }else if(rotationLimit == 2) {
                rawScoreList = S_AUTO_F_MANUAL_F8_SL3_ROTATION_2_RAW_SCORE_LIST
            }
            setupIndexListManual()

        }else if(!isSManual && !isFManual) {
            if(rotationLimit == 1) {
                rawScoreList = S_AUTO_F_AUTO_F8_SL3_ROTATION_1_RAW_SCORE_LIST
            }else if(rotationLimit == 2) {
                rawScoreList = S_AUTO_F_AUTO_F8_SL3_ROTATION_2_RAW_SCORE_LIST
            }
            setupIndexListAuto()
        }
    }

    private void setupIndexListManual() {
        rawScoreFIndexList = TLIM_MANUAL_F8_SL3_SEARCH_INDEX_LIST
        rawScoreSIndexList = TLIM_MANUAL_F8_SL3_FILE_INDEX_LIST
    }

    private void setupIndexListAuto() {
        rawScoreFIndexList = TLIM_AUTO_F8_SL3_SEARCH_INDEX_LIST
        rawScoreSIndexList = TLIM_AUTO_F8_SL3_FILE_INDEX_LIST
    }

    public int getScore() {
        if(score != -1) {
            return score
        }

        score = 0
        for(rScore in rawScoreList) {
            score += rScore as int
        }
        score /= rawScoreList.size()
        return score
    }

    public List getRawScoreList() {
        return rawScoreList
    }

    public List getRawSearchIndexList() {
        return rawScoreSIndexList
    }

    public List getRawFileIndexList() {
        return rawScoreFIndexList
    }
}

