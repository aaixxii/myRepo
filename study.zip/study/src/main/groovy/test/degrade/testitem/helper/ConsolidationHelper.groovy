package test.degrade.testitem.helper

import test.degrade.assertion.xml.*
import test.degrade.util.SoapuiObject
import test.degrade.management.AbendProcessor

class ConsolidationHelper {

	protected static final String A = "A"
	protected static final String B = "B"
	protected static final String C = "C"
	protected static final String D = "D"
	protected static final int FIN_0 = 0
	protected static final int FIN_1 = 1
	protected static final int FIN_2 = 2
	protected static final int FIN_3 = 3
	protected static final int FIN_4 = 4
	protected static final int FIN_5 = 5
	protected static final int FIN_6 = 6
	protected static final int FIN_7 = 7
	protected static final int FIN_8 = 8
	protected static final int FIN_9 = 9
	protected static final int FIN_10 = 10
	protected SoapuiObject soapuiObj

	public ConsolidationHelper(def context){
		this.soapuiObj = new SoapuiObject(context)
	}

	protected int multiplyFw(int iScore, Integer fw){
		fw = arrangeFusionWeight(fw)
		int newScore = (int)(iScore * fw / 100)
		return cutoffScore(newScore)
	}

	protected int cutoffScore(int score){
		if(score > 9999) {
			return 9999
		}else{
			return score
		}
	}

	protected int calcFusionScore(Integer pc2rFW, Integer pc2sFW, Integer fmp5rFW, Integer fmp5sFW,
									Integer pc2Score, Integer fmp5Score){
		int fScore = mergeFWeight(pc2Score, pc2sFW) + mergeFWeight(fmp5Score, fmp5sFW)
		return cutoffScore(fScore)
	}

	protected int mergeFWeight(int score, Integer fw) {
		fw = arrangeFusionWeight(fw)
		score = (int)(score * fw / 100)
		return cutoffScore(score)
	}

	private int arrangeFusionWeight(Integer fw){
		if(fw == null) {
			return 100
		}else{
			return fw
		}
	}

	public int getTotalCandTmpSize(List candiList) {
		int sum = 0
		if(candiList == null || candiList.isEmpty() ){
			return sum
		}

		for(List can in candiList) {
			sum += can[3].size()
		}
		return sum
	}

	public int getTotalIndividualScoreSize(List candiList) {
		int sum = 0
		if(candiList == null || candiList.isEmpty() ){
			return sum
		}

		for(List can in candiList) {
			for(List canTmp in can[3]) {
				sum += canTmp[4].size()
			}
		}
		return sum
	}
}

