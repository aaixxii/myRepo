package test.degrade.testitem.helper

import static test.common.constants.aim.AIMXmlAttribute.*

class LlixConsolidationHelper extends ConsolidationHelper {

	private static final String F201_EXT_ID = "LLIX_F201A_PC2"
	private static final String F202_EXT_ID = "LLIX_F202A_FMP5"
	private static final String F203_EXT_ID = "LLIX_F203A_PC2_FMP5"
	private static final String F204_EXT_ID = "LLIX_F204A_PC2_FMP5"
	private static final String F205_EXT_ID = "LLIX_F205A_PC2_FMP5"
	private static final String F_123_ABC_HIGH_EXT_ID = "LLIX-123-ABC-High"
	private static final String F_ABC_123_HIGH_EXT_ID = "LLIX-ABC-123-High"
	private static final String F_BBC_123_HIGH_EXT_ID = "LLIX-BBC-123-High"
	private static final String F_123_ABC_LOW_EXT_ID = "LLIX-123-ABC-Low"
	private static final String F_ABC_123_LOW_EXT_ID = "LLIX-ABC-123-Low"
	private static final String F_BBC_123_LOW_EXT_ID = "LLIX-BBC-123-Low"
	private static final int PC2_1_SCORE = 2194
	private static final int FMP5_1_SCORE = 3028
	private static final int FMP5_1_A_SCORE = 3059
	private static final int FMP5_1_B_SCORE = 3472
	private static final int FMP5_1_C_SCORE = 3472
	private static final int FMP5_1_D_SCORE = 2917
	private static final int PC2_ROLLED_6_SCORE = 1703
	private Integer fmp5FW = 100
	private Integer pc2FW = 100

	private List F201A_CAND_INFO_LIST_BY_PC2 = []
	private List F202A_CAND_INFO_LIST_BY_FMP5 = []
	private List F203A_CAND_INFO_LIST_BY_PC2 = []
	private List F203A_CAND_INFO_LIST_BY_FMP5 = []
	private List F203A_CAND_INFO_LIST_BY_PC2_FMP5 = []
	private List F203A_CAND_INFO_LIST_BY_PC2_FMP5_2SCOPE = []
	private List F204A_CAND_INFO_LIST_BY_PC2_FMP5_MULTI_AXIS_TRUE = []
	private List F204A_CAND_INFO_LIST_BY_PC2_FMP5_MULTI_AXIS_FALSE = []
	private List F205A_CAND_INFO_LIST_BY_PC2_FMP5_MULTI_AXIS_TRUE = []
	private List F205A_CAND_INFO_LIST_BY_PC2_FMP5_MULTI_AXIS_FALSE = []
	private List F_123_ABC_HIGH_CAND_INFO_LIST = []
	private List F_ABC_123_HIGH_CAND_INFO_LIST = []
	private List F_BBC_123_HIGH_CAND_INFO_LIST = []
	private List F_123_ABC_LOW_CAND_INFO_LIST = []
	private List F_ABC_123_LOW_CAND_INFO_LIST = []
	private List F_BBC_123_LOW_CAND_INFO_LIST = []

	LlixConsolidationHelper(context){
		super(context)
		initCandInfoLists()
	}

	private void initCandInfoLists() {
		initFmp5CandInfoLists()
		initPc2CandInfoLists()
		initBothCandInfoLists()
	}

	private void initFmp5CandInfoLists() {
		int fmp5Score = mergeFWeight(FMP5_1_SCORE, fmp5FW)
		F202A_CAND_INFO_LIST_BY_FMP5 = 
			[ F202_EXT_ID, fmp5Score, true, 
				[ [ 342, 1, 0, fmp5Score,
					[ [ FMP5_1_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ]
				] ]
			]
		F203A_CAND_INFO_LIST_BY_FMP5 = 
			[ F203_EXT_ID, fmp5Score, true, 
				[ [ 342, 1, 0, fmp5Score,
					[ [ FMP5_1_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ]
				] ]
			]
		F204A_CAND_INFO_LIST_BY_PC2_FMP5_MULTI_AXIS_TRUE = 
			[ F204_EXT_ID, FMP5_1_B_SCORE, true, 
				[ [ 342, 1, 0, FMP5_1_B_SCORE,
					[ [ FMP5_1_B_SCORE, FIN_1, B, FMP5_LATENT, fmp5FW ] ]
				] ]
			]
		F204A_CAND_INFO_LIST_BY_PC2_FMP5_MULTI_AXIS_FALSE = 
			[ F204_EXT_ID, FMP5_1_B_SCORE, true, 
				[ [ 342, 1, 0, FMP5_1_B_SCORE,
					[ [ FMP5_1_A_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ],
					  [ FMP5_1_B_SCORE, FIN_1, B, FMP5_LATENT, fmp5FW ],
					  [ FMP5_1_C_SCORE, FIN_1, C, FMP5_LATENT, fmp5FW ],
					  [ FMP5_1_D_SCORE, FIN_1, D, FMP5_LATENT, fmp5FW ] ]
				] ]
			]
	}

	private void initPc2CandInfoLists() {
		int pc2Score = mergeFWeight(PC2_1_SCORE, pc2FW)
		F201A_CAND_INFO_LIST_BY_PC2 = 
			[ F201_EXT_ID, pc2Score, true, 
				[ [ 342, 1, 0, pc2Score,
					[ [ PC2_1_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ]
				] ]
			]
		F203A_CAND_INFO_LIST_BY_PC2 = 
			[ F203_EXT_ID, pc2Score, true, 
				[ [ 342, 1, 0, pc2Score,
					[ [ PC2_1_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ]
				] ]
			]
		F_123_ABC_LOW_CAND_INFO_LIST = 
			[ F_123_ABC_LOW_EXT_ID, pc2Score, true, 
				[ F203A_CAND_INFO_LIST_BY_PC2[3][0] ,
				  [ 1342, 1, 0, pc2Score,
					[ [ PC2_1_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ] 
				]
			]
		F_ABC_123_LOW_CAND_INFO_LIST = 
			[ F_ABC_123_LOW_EXT_ID, pc2Score, true, F_123_ABC_LOW_CAND_INFO_LIST[3] ]
		F_BBC_123_LOW_CAND_INFO_LIST = 
			[ F_BBC_123_LOW_EXT_ID, pc2Score, true, F_123_ABC_LOW_CAND_INFO_LIST[3] ]
	}

	private void initBothCandInfoLists() {
		int fmp5_pc2_score = calcFusionScore_fmp5_pc2()
		int fmp5_axis_pc2_score = PC2_1_SCORE + FMP5_1_C_SCORE
		F203A_CAND_INFO_LIST_BY_PC2_FMP5 = 
			[ F203_EXT_ID, fmp5_pc2_score, true, 
				[ [ 342, 1, 0, fmp5_pc2_score,
					[ [ PC2_1_SCORE, FIN_1, A, PC2_LATENT, pc2FW ],
					  [ FMP5_1_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ]
				] ]
			]
		F203A_CAND_INFO_LIST_BY_PC2_FMP5_2SCOPE = 
			[ F203_EXT_ID, fmp5_pc2_score, true, 
				[ [ 342, 1, 0, fmp5_pc2_score,
					[ [ PC2_1_SCORE, FIN_1, A, PC2_LATENT, pc2FW ],
					  [ FMP5_1_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 1342, 1, 0, fmp5_pc2_score, F203A_CAND_INFO_LIST_BY_PC2_FMP5[3][0][4] ],
				]
			]
		F205A_CAND_INFO_LIST_BY_PC2_FMP5_MULTI_AXIS_TRUE = 
			[ F205_EXT_ID, fmp5_axis_pc2_score, true, 
				[ [ 342, 1, 0, fmp5_axis_pc2_score,
					[ [ PC2_1_SCORE, FIN_1, A, PC2_LATENT, pc2FW ],
					  [ FMP5_1_C_SCORE, FIN_1, C, FMP5_LATENT, fmp5FW ] ] 
				] ]
			]
		F205A_CAND_INFO_LIST_BY_PC2_FMP5_MULTI_AXIS_FALSE = 
			[ F205_EXT_ID, fmp5_axis_pc2_score, true, 
				[ [ 342, 1, 0, fmp5_axis_pc2_score,
					[ [ PC2_1_SCORE, FIN_1, A, PC2_LATENT, pc2FW ],
					  [ FMP5_1_A_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ],
					  [ FMP5_1_C_SCORE, FIN_1, C, FMP5_LATENT, fmp5FW ],
					  [ FMP5_1_D_SCORE, FIN_1, D, FMP5_LATENT, fmp5FW ] ] 
				] ]
			]
		F_123_ABC_HIGH_CAND_INFO_LIST = 
			[ F_123_ABC_HIGH_EXT_ID, fmp5_pc2_score, true, F203A_CAND_INFO_LIST_BY_PC2_FMP5_2SCOPE[3] ]
		F_ABC_123_HIGH_CAND_INFO_LIST = 
			[ F_ABC_123_HIGH_EXT_ID, fmp5_pc2_score, true, F203A_CAND_INFO_LIST_BY_PC2_FMP5_2SCOPE[3] ]
		F_BBC_123_HIGH_CAND_INFO_LIST = 
			[ F_BBC_123_HIGH_EXT_ID, fmp5_pc2_score, true, F203A_CAND_INFO_LIST_BY_PC2_FMP5_2SCOPE[3] ]
	}

	private int calcFusionScore_fmp5_pc2() {
		int pc2Score = mergeFWeight(PC2_1_SCORE, pc2FW)
		int fmp5Score = mergeFWeight(FMP5_1_SCORE, fmp5FW)
		int fScore = pc2Score + fmp5Score
		return cutoffScore(fScore)
	}

	public List getCandList_coldSearch_pc2() {
		return [ F201A_CAND_INFO_LIST_BY_PC2, F203A_CAND_INFO_LIST_BY_PC2 ]
	}

	public List getCandList_coldSearch_fmp5() {
		return [ F202A_CAND_INFO_LIST_BY_FMP5, F203A_CAND_INFO_LIST_BY_FMP5 ]
	}

	public List getCandList_coldSearch_both() {
		return [ F203A_CAND_INFO_LIST_BY_PC2_FMP5, F201A_CAND_INFO_LIST_BY_PC2, F202A_CAND_INFO_LIST_BY_FMP5 ]
	}

	public List getCandList_inquirySet_pc2() {
		return [ F203A_CAND_INFO_LIST_BY_PC2 ]
	}

	public List getCandList_inquirySet_fmp5() {
		return [ F203A_CAND_INFO_LIST_BY_FMP5 ]
	}

	public List getCandList_inquirySet_both() {
		return [ F203A_CAND_INFO_LIST_BY_PC2_FMP5 ]
	}

	public List getCandList_muMerge() {
		return getCandList_coldSearch_both()
	}

	public List getCandList_scopeMerge() {
		return [ F203A_CAND_INFO_LIST_BY_PC2_FMP5_2SCOPE ]
	}

	public List getCandList_multiAxis_true_sameBC() {
		return [ F204A_CAND_INFO_LIST_BY_PC2_FMP5_MULTI_AXIS_TRUE ]
	}

	public List getCandList_multiAxis_true_B0() {
		return [ F205A_CAND_INFO_LIST_BY_PC2_FMP5_MULTI_AXIS_TRUE ]
	}

	public List getCandList_multiAxis_false_sameBC() {
		return [ F204A_CAND_INFO_LIST_BY_PC2_FMP5_MULTI_AXIS_FALSE ]
	}

	public List getCandList_multiAxis_false_B0() {
		return [ F205A_CAND_INFO_LIST_BY_PC2_FMP5_MULTI_AXIS_FALSE ]
	}

	public List getCandList_fWeight(Integer fmp5FW, Integer pc2FW) {
		this.fmp5FW = fmp5FW
		this.pc2FW = pc2FW
		initCandInfoLists()
		return [ F203A_CAND_INFO_LIST_BY_PC2_FMP5 ]
	}

	public List getCandList_fWeight_multi(Integer fmp5FW, Integer pc2FW) {
		this.fmp5FW = fmp5FW
		this.pc2FW = pc2FW
		initCandInfoLists()
		return getCandList_coldSearch_both()
	}

	public List getCandList_candSort() {
		return [ F_123_ABC_HIGH_CAND_INFO_LIST,
				F_ABC_123_HIGH_CAND_INFO_LIST,
				F_BBC_123_HIGH_CAND_INFO_LIST,
				F_123_ABC_LOW_CAND_INFO_LIST,
				F_ABC_123_LOW_CAND_INFO_LIST,
				F_BBC_123_LOW_CAND_INFO_LIST ]
	}
}

