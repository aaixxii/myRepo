package test.degrade.testitem.helper.templates

import test.degrade.testitem.helper.*
import static test.common.constants.data.ImageDataList.*

class IiTestTemplateCreateHelper extends TestTemplateCreateHelper{

	def IiTestTemplateCreateHelper(context){
		super(context)
	}

    def getDefaultFileImgXml() {
        return getJ2kFileImgXml()
    }

    def getDefaultSearchImgXml() {
        return getJ2kSearchImgXml()
    }

    def getJ2kFileImgXml() {
        StringBuilder sb = new StringBuilder()
        sb.append(imgXmlMaker.getIrisImgXml(I_001_R_F_001_J2K, 60, 2))
        sb.append(imgXmlMaker.getIrisImgXml(I_002_L_F_001_J2K, 61, 2))
        return sb.toString()
    }

    def getJ2kSearchImgXml() {
        StringBuilder sb = new StringBuilder()
        sb.append(imgXmlMaker.getIrisImgXml(I_003_R_S_001_J2K, 60, 2))
        sb.append(imgXmlMaker.getIrisImgXml(I_004_L_S_001_J2K, 61, 2))
        return sb.toString()
    }
	
    def getBothRightFileImgXml() {
        StringBuilder sb = new StringBuilder()
        sb.append(imgXmlMaker.getIrisImgXml(I_001_R_F_001_J2K, 60, 2))
        sb.append(imgXmlMaker.getIrisImgXml(I_001_R_F_001_J2K, 61, 2))
        return sb.toString()
    }

    def getBothRightSearchImgXml() {
        StringBuilder sb = new StringBuilder()
        sb.append(imgXmlMaker.getIrisImgXml(I_003_R_S_001_J2K, 60, 2))
        sb.append(imgXmlMaker.getIrisImgXml(I_003_R_S_001_J2K, 61, 2))
        return sb.toString()
    }

    def getBothLeftFileImgXml() {
        StringBuilder sb = new StringBuilder()
        sb.append(imgXmlMaker.getIrisImgXml(I_002_L_F_001_J2K, 60, 2))
        sb.append(imgXmlMaker.getIrisImgXml(I_002_L_F_001_J2K, 61, 2))
        return sb.toString()
    }

    def getBothLeftSearchImgXml() {
        StringBuilder sb = new StringBuilder()
        sb.append(imgXmlMaker.getIrisImgXml(I_004_L_S_001_J2K, 60, 2))
        sb.append(imgXmlMaker.getIrisImgXml(I_004_L_S_001_J2K, 61, 2))
        return sb.toString()
    }

    def getRightOnlyFileImgXml() {
        StringBuilder sb = new StringBuilder()
        sb.append(imgXmlMaker.getIrisImgXml(I_001_R_F_001_J2K, 60, 2))
        return sb.toString()
    }

    def getRightOnlySearchImgXml() {
        StringBuilder sb = new StringBuilder()
        sb.append(imgXmlMaker.getIrisImgXml(I_003_R_S_001_J2K, 60, 2))
        return sb.toString()
    }

    def getLeftOnlyFileImgXml() {
        StringBuilder sb = new StringBuilder()
        sb.append(imgXmlMaker.getIrisImgXml(I_002_L_F_001_J2K, 61, 2))
        return sb.toString()
    }

    def getLeftOnlySearchImgXml() {
        StringBuilder sb = new StringBuilder()
        sb.append(imgXmlMaker.getIrisImgXml(I_004_L_S_001_J2K, 61, 2))
        return sb.toString()
    }
}
