package test.degrade.testitem.helper.templates

import test.degrade.testitem.helper.*
import static test.common.constants.data.ImageDataList.*

class LlipTestTemplateCreateHelper extends TestTemplateCreateHelper{

    LlipTestTemplateCreateHelper(context){
		super(context)
    }

	public String getDefaultFileImage(){
		return imgXmlMaker.getLatentPalmImgXml(LP_004_WSQ)
	}

	public String getDefaultSearchImage(){
		return imgXmlMaker.getLatentPalmImgXml(LP_003_WSQ)
	}
}
