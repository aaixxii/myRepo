package test.degrade.testitem.helper

import common.util.Encoder
import test.common.constants.aim.*
import static test.common.constants.aim.AIMXmlAttribute.*

class LipByZoneOffHelper extends PalmHelper {
    private static final String FUNC = "LIP"

	private static final String PALM_OPT_EXT_ID = "${FUNC}_PalmOpt"
	
	private static final String GEN_M_EXT_ID = "${FUNC}_M"
	private static final String GEN_F_EXT_ID = "${FUNC}_F"
	private static final String GEN_U_EXT_ID = "${FUNC}_U"

	private static final String YOB_1970_EXT_ID = "${FUNC}_1970_0"
	private static final String YOB_1980_EXT_ID = "${FUNC}_1980_0"
	private static final String YOB_1990_EXT_ID = "${FUNC}_1990_0"

	private static final String YOB_1959_EXT_ID = "${FUNC}_1959_15"
	private static final String YOB_1969_EXT_ID = "${FUNC}_1969_0"
	private static final String YOB_1973_EXT_ID = "${FUNC}_1973_0"
	private static final String YOB_1974_EXT_ID = "${FUNC}_1974_0"
	private static final String YOB_1984_EXT_ID = "${FUNC}_1984_0"
	private static final String YOB_1985_EXT_ID = "${FUNC}_1985_0"
	private static final String YOB_1988_EXT_ID = "${FUNC}_1988_0"
	private static final String YOB_1989_EXT_ID = "${FUNC}_1989_0"
	private static final String YOB_1999_EXT_ID = "${FUNC}_1999_15"
	private static final String YOB_M1_EXT_ID = "${FUNC}_-1_0"
	
	private static final String PARTNO_0_EXT_ID = "${FUNC}_0"
	private static final String PARTNO_1_EXT_ID = "${FUNC}_1"
	private static final String PARTNO_2_EXT_ID = "${FUNC}_2"
	private static final String PARTNO_3_EXT_ID = "${FUNC}_3"
	private static final String PARTNO_4_EXT_ID = "${FUNC}_4"
	private static final String PARTNO_5_EXT_ID = "${FUNC}_5"
	private static final String PARTNO_6_EXT_ID = "${FUNC}_6"
	private static final String PARTNO_7_EXT_ID = "${FUNC}_7"
	private static final String PARTNO_8_EXT_ID = "${FUNC}_8"
	private static final String PARTNO_9_EXT_ID = "${FUNC}_9"
	private static final String PARTNO_A_EXT_ID = "${FUNC}_A"
	private static final String PARTNO_B_EXT_ID = "${FUNC}_B"
	private static final String PARTNO_C_EXT_ID = "${FUNC}_C"
	private static final String PARTNO_D_EXT_ID = "${FUNC}_D"
	private static final String PARTNO_E_EXT_ID = "${FUNC}_E"
	private static final String PARTNO_F_EXT_ID = "${FUNC}_F"
	private static final String PARTNO_G_EXT_ID = "${FUNC}_G"

	private static final String RACE_1_EXT_ID = "${FUNC}_1"
	private static final String RACE_2_EXT_ID = "${FUNC}_2"
	private static final String RACE_4_EXT_ID = "${FUNC}_4"
	private static final String RACE_8_EXT_ID = "${FUNC}_8"
	private static final String RACE_M1_EXT_ID = "${FUNC}_-1"
	
	private static final String REGION_1_EXT_ID = "${FUNC}_1"
	private static final String REGION_9_EXT_ID = "${FUNC}_9"
	private static final String REGION_F_EXT_ID = "${FUNC}_F"
	private static final String REGION_U_EXT_ID = "${FUNC}_U"
	
	private static final String SCOPE_1_EXT_ID = "${FUNC}_Scope1"
	private static final String SCOPE_2_EXT_ID = "${FUNC}_Scope2"
	private static final String SCOPE_3_EXT_ID = "${FUNC}_Scope3"
	
	private static final String FW_EXT_ID = "${FUNC}_FW"

	private static final String EXT_SORT_HIGH_AB_EXT_ID = "${FUNC}_highScore-AB"
	private static final String EXT_SORT_HIGH_BA_EXT_ID = "${FUNC}_highScore-BA"
	private static final String EXT_SORT_HIGH_1C_EXT_ID = "${FUNC}_highScore-1C"
	private static final String EXT_SORT_LOW_AB_EXT_ID = "${FUNC}_lowScore-AB"
	private static final String EXT_SORT_LOW_BA_EXT_ID = "${FUNC}_lowScore-BA"
	private static final String EXT_SORT_LOW_1C_EXT_ID = "${FUNC}_lowScore-1C"

	private static final String MULTIPART_SCORE_EXT_ID = "${FUNC}_MultiPartScore"

	private static final int PALM_OPT_BASE_SCORE_PC3R = 2841
	private static final int PALM_OPT_BASE_SCORE_PZIP = 2519
	private static final int PALM_OPT_ROTATION_1_SCORE_PC3R = PALM_OPT_BASE_SCORE_PC3R
	private static final int PALM_OPT_ROTATION_1_SCORE_PZIP = PALM_OPT_BASE_SCORE_PC3R
	private static final int PALM_OPT_ROTATION_2_SCORE_PC3R = 2768
	private static final int PALM_OPT_ROTATION_2_SCORE_PZIP = PALM_OPT_BASE_SCORE_PZIP
	private static final int PALM_OPT_SPEED_P_9_SCORE_PC3R = 1989
	private static final int PALM_OPT_DISTORTION_P_1_SCORE_PC3R = 2675
	private static final int PALM_OPT_DISTORTION_P_3_SCORE_PC3R = 2812
	private static final int PALM_OPT_DISTORTION_S_2_SCORE_PC3R = 2568
	private static final int PALM_OPT_DISTORTION_S_5_SCORE_PC3R = 2915

	private static final int FW_100_SCORE_PC3R = PALM_OPT_BASE_SCORE_PC3R
	private static final int FW_100_SCORE_PZIP = PALM_OPT_BASE_SCORE_PZIP

	private static final int EXT_SORT_HIGH_SCORE_PC3R = 9999
	private static final int EXT_SORT_HIGH_SCORE_PZIP = 9999
	private static final int EXT_SORT_LOW_SCORE_PC3R = PALM_OPT_BASE_SCORE_PC3R
	private static final int EXT_SORT_LOW_SCORE_PZIP = PALM_OPT_BASE_SCORE_PZIP

	private static final int SCOPE_1_BIN_ID = 5
	private static final int SCOPE_2_BIN_ID = SCOPE_1_BIN_ID + 1000
	private static final int SCOPE_3_BIN_ID = SCOPE_1_BIN_ID + 2000

	private Integer fw = 100
	private int reqIndex = 0
	
	private List GEN_M_CAND_INFO_LIST = []
	private List GEN_F_CAND_INFO_LIST = []
	private List GEN_U_CAND_INFO_LIST = []

	private List FW_100_CAND_INFO_LIST = []
	private List FW_120_CAND_INFO_LIST = []
	private List FW_NULL_CAND_INFO_LIST = []

	private List EXT_SORT_HIGH_AB_CAND_INFO_LIST = []
	private List EXT_SORT_HIGH_BA_CAND_INFO_LIST = []
	private List EXT_SORT_HIGH_1C_CAND_INFO_LIST = []
	private List EXT_SORT_LOW_AB_CAND_INFO_LIST = []
	private List EXT_SORT_LOW_BA_CAND_INFO_LIST = []
	private List EXT_SORT_LOW_1C_CAND_INFO_LIST = []

    private static final String PALM_OPT_SEARCH_TEMPLATE = "LP001_${FUNC}_PalmOption.bin"
    private static final String PALM_OPT_FILE_TEMPLATE = "TP001_PDB_PalmOption.bin"
	
    private String projectName
	
	LipByZoneOffHelper(context){
		super(context)
        this.projectName = soapuiObj.getTestProjectName()
		initCandInfoLists()
	}

	LipByZoneOffHelper(context, boolean isSkipInit){
		super(context)
        this.projectName = soapuiObj.getTestProjectName()
		
		if(isSkipInit){
		}else{
			initCandInfoLists()
		}
	}

	LipByZoneOffHelper(context, String level){
        super(context)
        this.projectName = soapuiObj.getTestProjectName()
		setNullFwIfHighLevel(level)
		initCandInfoLists()
	}

    public String getPalmOptSearchTemplateB64() {
        String path = "${soapuiObj.getGlobalDataFilePath()}/degradeTest/template/${soapuiObj.getGlobalTempDirName()}/${projectName}/${PALM_OPT_SEARCH_TEMPLATE}"
        return Encoder.binaryToB64(path)
    }

    public String getPalmOptFileTemplateB64() {
        String path = "${soapuiObj.getGlobalDataFilePath()}/degradeTest/template/${soapuiObj.getGlobalTempDirName()}/${projectName}/${PALM_OPT_FILE_TEMPLATE}"
        return Encoder.binaryToB64(path)
    }

	private void initCandInfoLists() {
		initGenderCandInfoList()
		initFusionWeightCandInfoList()
		initExternalIdCandInfoList()
	}

	private void initGenderCandInfoList(){
		GEN_M_CAND_INFO_LIST =
			[ GEN_M_EXT_ID, 9999, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, 9999,
					[ [ 9999, FIN_1, A, fw ] ] 
				] ]
			]
		
		GEN_F_CAND_INFO_LIST =
			[ GEN_F_EXT_ID, 9999, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, 9999,
					[ [ 9999, FIN_1, A, fw ] ] 
				] ]
			]
		
		GEN_U_CAND_INFO_LIST =
			[ GEN_U_EXT_ID, 9999, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, 9999,
					[ [ 9999, FIN_1, A, fw ] ] 
				] ]
			]
	}

	private void initFusionWeightCandInfoList(){
        int score = getCorrectAlgorithmObj(FW_100_SCORE_PC3R, FW_100_SCORE_PZIP)
        int fw120Score = score * 1.2
		FW_100_CAND_INFO_LIST =
			[ FW_EXT_ID, score, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, score,
					[ [ score, FIN_3, A , 100 ] ] 
				] ]
			]

		FW_120_CAND_INFO_LIST =
			[ FW_EXT_ID, fw120Score, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, fw120Score,
					[ [ score, FIN_3, A , 120 ] ] 
				] ]
			]

		FW_NULL_CAND_INFO_LIST =
			[ FW_EXT_ID, score, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, score,
					[ [ score, FIN_3, A , null ] ] 
				] ]
			]

	}

	private void initExternalIdCandInfoList(){
        int highScore = getCorrectAlgorithmObj(EXT_SORT_HIGH_SCORE_PC3R, EXT_SORT_HIGH_SCORE_PZIP)
        int lowScore = getCorrectAlgorithmObj(EXT_SORT_LOW_SCORE_PC3R, EXT_SORT_LOW_SCORE_PZIP)

		EXT_SORT_HIGH_AB_CAND_INFO_LIST =
			[ EXT_SORT_HIGH_AB_EXT_ID, highScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, highScore,
					[ [ highScore, FIN_3, A , fw ] ] 
				] ]
			]

		EXT_SORT_HIGH_BA_CAND_INFO_LIST =
			[ EXT_SORT_HIGH_BA_EXT_ID, highScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, highScore,
					[ [ highScore, FIN_3, A , fw ] ] 
				] ]
			]

		EXT_SORT_HIGH_1C_CAND_INFO_LIST =
			[ EXT_SORT_HIGH_1C_EXT_ID, highScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, highScore,
					[ [ highScore, FIN_3, A , fw ] ] 
				] ]
			]

		EXT_SORT_LOW_AB_CAND_INFO_LIST =
			[ EXT_SORT_LOW_AB_EXT_ID, lowScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, lowScore,
					[ [ lowScore, FIN_3, A , fw ] ] 
				] ]
			]

		EXT_SORT_LOW_BA_CAND_INFO_LIST =
			[ EXT_SORT_LOW_BA_EXT_ID, lowScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, lowScore,
					[ [ lowScore, FIN_3, A , fw ] ] 
				] ]
			]

		EXT_SORT_LOW_1C_CAND_INFO_LIST =
			[ EXT_SORT_LOW_1C_EXT_ID, lowScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, lowScore,
					[ [ lowScore, FIN_3, A , fw ] ] 
				] ]
			]
	}

	public List getCandList_PalmOpt_Default(){
        List extIdList = [ PALM_OPT_EXT_ID ]
        int score = getCorrectAlgorithmObj(PALM_OPT_BASE_SCORE_PC3R, PALM_OPT_BASE_SCORE_PZIP)
		return makeCandList(extIdList, score, SCOPE_1_BIN_ID, FIN_3)
	}

	public List getCandList_Rotation_1(){
		return getCandList_PalmOpt_Default()
	}

	public List getCandList_Rotation_2(){
        List extIdList = [ PALM_OPT_EXT_ID ]
        int score = getCorrectAlgorithmObj(PALM_OPT_ROTATION_2_SCORE_PC3R, PALM_OPT_ROTATION_2_SCORE_PZIP)
		return makeCandList(extIdList, score, SCOPE_1_BIN_ID, FIN_3)
	}

	public List getCandList_Rotation_4(){
		return getCandList_Rotation_2()
	}

	public List getCandList_SpeedP_6(){
		return getCandList_PalmOpt_Default()
	}

	public List getCandList_SpeedP_9(){
        List extIdList = [ PALM_OPT_EXT_ID ]
		return makeCandList(extIdList, PALM_OPT_SPEED_P_9_SCORE_PC3R, SCOPE_1_BIN_ID, FIN_3)
	}

	public List getCandList_SpeedS_5(){
		return getCandList_PalmOpt_Default()
	}

	public List getCandList_SpeedS_3(){
		return getCandList_PalmOpt_Default()
	}

	public List getCandList_DistortionP_1(){
        List extIdList = [ PALM_OPT_EXT_ID ]
		return makeCandList(extIdList, PALM_OPT_DISTORTION_P_1_SCORE_PC3R, SCOPE_1_BIN_ID, FIN_3)
	}

	public List getCandList_DistortionP_2(){
		return getCandList_PalmOpt_Default()
	}

	public List getCandList_DistortionP_3(){
        List extIdList = [ PALM_OPT_EXT_ID ]
		return makeCandList(extIdList, PALM_OPT_DISTORTION_P_3_SCORE_PC3R, SCOPE_1_BIN_ID, FIN_3)
	}

	public List getCandList_DistortionS_2(){
        List extIdList = [ PALM_OPT_EXT_ID ]
		return makeCandList(extIdList, PALM_OPT_DISTORTION_S_2_SCORE_PC3R, SCOPE_1_BIN_ID, FIN_3)
	}

	public List getCandList_DistortionS_4(){
		return getCandList_PalmOpt_Default()
	}

	public List getCandList_DistortionS_5(){
        List extIdList = [ PALM_OPT_EXT_ID ]
		return makeCandList(extIdList, PALM_OPT_DISTORTION_S_5_SCORE_PC3R, SCOPE_1_BIN_ID, FIN_3)
	}

	public List getCandList_Gender_M_Only(){
		return [ GEN_M_CAND_INFO_LIST ] 
	}

	public List getCandList_Gender_F_Only(){
		return [ GEN_F_CAND_INFO_LIST ] 
	}

	public List getCandList_Gender_M(){
		return [ GEN_M_CAND_INFO_LIST,  GEN_U_CAND_INFO_LIST ] 
	}

	public List getCandList_Gender_F(){
		return [ GEN_F_CAND_INFO_LIST, GEN_U_CAND_INFO_LIST ] 
	}
	
	public List getCandList_Gender_U(){
		return [ GEN_M_CAND_INFO_LIST, GEN_F_CAND_INFO_LIST, GEN_U_CAND_INFO_LIST ] 
	}

	public List getCandList_useYob_All(){
        List extIdList = [ YOB_1970_EXT_ID, YOB_1980_EXT_ID, YOB_1990_EXT_ID ]
        return makeMaxScoreCandList(extIdList)
	}

	public List getCandList_useYob_1980(){
        List extIdList = [ YOB_1980_EXT_ID ]
        return makeMaxScoreCandList(extIdList)
	}

	public List getCandList_useYob_1970(){
        List extIdList = [ YOB_1970_EXT_ID ]
        return makeMaxScoreCandList(extIdList)
	}

	public List getCandList_Yob_All(){
        List extIdList = [ YOB_1959_EXT_ID, YOB_1969_EXT_ID, YOB_1970_EXT_ID, YOB_1973_EXT_ID, YOB_1974_EXT_ID,
				           YOB_1984_EXT_ID, YOB_1985_EXT_ID, YOB_1988_EXT_ID, YOB_1989_EXT_ID, YOB_1999_EXT_ID, YOB_M1_EXT_ID ] 
        return makeMaxScoreCandList(extIdList)
	}

	public List getCandList_Yob_1(){
        List extIdList = [ YOB_1959_EXT_ID, YOB_1974_EXT_ID, YOB_1984_EXT_ID, YOB_1999_EXT_ID, YOB_M1_EXT_ID ] 
        return makeMaxScoreCandList(extIdList)
	}

	public List getCandList_Yob_2(){
        List extIdList = [ YOB_1970_EXT_ID, YOB_1973_EXT_ID, YOB_1974_EXT_ID, 
                           YOB_1984_EXT_ID, YOB_1985_EXT_ID, YOB_1988_EXT_ID, YOB_M1_EXT_ID ] 
        return makeMaxScoreCandList(extIdList)
	}

	public List getCandList_Yob_3(){
        List extIdList = [ YOB_1984_EXT_ID, YOB_1985_EXT_ID, YOB_1988_EXT_ID, 
                           YOB_1989_EXT_ID, YOB_1999_EXT_ID, YOB_M1_EXT_ID ] 
        return makeMaxScoreCandList(extIdList)
	}

    public List getCandList_usePartNo_All(){
        List candInfoList = []
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_1_EXT_ID ], SCOPE_1_BIN_ID, 1))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_2_EXT_ID ], SCOPE_1_BIN_ID, 2))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_3_EXT_ID ], SCOPE_1_BIN_ID, 3))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_4_EXT_ID ], SCOPE_1_BIN_ID, 4))
        return candInfoList
    }

    public List getCandList_usePartNo_1(){
        return makeMaxScoreCandList([ PARTNO_4_EXT_ID ], SCOPE_1_BIN_ID, 4)
    }

    public List getCandList_usePartNo_2(){
        return makeMaxScoreCandList([ PARTNO_1_EXT_ID ], SCOPE_1_BIN_ID, 1)
    }

    public List getCandList_PartNo_All(){
		return getCandList_usePartNo_All()
    }

    public List getCandList_PartNo_1(){
        return makeMaxScoreCandList([ PARTNO_1_EXT_ID ], SCOPE_1_BIN_ID, 1)
    }

    public List getCandList_PartNo_2(){
        return makeMaxScoreCandList([ PARTNO_2_EXT_ID ], SCOPE_1_BIN_ID, 2)
    }

    public List getCandList_PartNo_3(){
        return makeMaxScoreCandList([ PARTNO_3_EXT_ID ], SCOPE_1_BIN_ID, 3)
    }

    public List getCandList_PartNo_4(){
        return makeMaxScoreCandList([ PARTNO_4_EXT_ID ], SCOPE_1_BIN_ID, 4)
    }

    public List getCandList_PartNo_5(){
        List candInfoList = []
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_3_EXT_ID ], SCOPE_1_BIN_ID, 3))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_4_EXT_ID ], SCOPE_1_BIN_ID, 4))
        return candInfoList
    }

    public List getCandList_PartNo_6(){
        List candInfoList = []
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_1_EXT_ID ], SCOPE_1_BIN_ID, 1))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_4_EXT_ID ], SCOPE_1_BIN_ID, 4))
        return candInfoList
    }

    public List getCandList_PartNo_3Parts_All(){
        List candInfoList = []
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_1_EXT_ID ], SCOPE_1_BIN_ID, 1))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_2_EXT_ID ], SCOPE_1_BIN_ID, 2))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_3_EXT_ID ], SCOPE_1_BIN_ID, 3))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_4_EXT_ID ], SCOPE_1_BIN_ID, 4))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_B_EXT_ID ], SCOPE_1_BIN_ID, 11))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_C_EXT_ID ], SCOPE_1_BIN_ID, 12))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_D_EXT_ID ], SCOPE_1_BIN_ID, 13))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_E_EXT_ID ], SCOPE_1_BIN_ID, 14))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_F_EXT_ID ], SCOPE_1_BIN_ID, 15))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_G_EXT_ID ], SCOPE_1_BIN_ID, 16))
        return candInfoList
    }

    public List getCandList_PartNo_3Parts_1(){
        List candInfoList = []
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_1_EXT_ID ], SCOPE_1_BIN_ID, 1))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_B_EXT_ID ], SCOPE_1_BIN_ID, 11))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_C_EXT_ID ], SCOPE_1_BIN_ID, 12))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_D_EXT_ID ], SCOPE_1_BIN_ID, 13))
        return candInfoList
    }

    public List getCandList_PartNo_3Parts_2(){
        List candInfoList = []
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_3_EXT_ID ], SCOPE_1_BIN_ID, 3))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_E_EXT_ID ], SCOPE_1_BIN_ID, 14))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_F_EXT_ID ], SCOPE_1_BIN_ID, 15))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_G_EXT_ID ], SCOPE_1_BIN_ID, 16))
        return candInfoList
    }

    public List getCandList_PartNo_3Parts_3(){
        List candInfoList = []
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_4_EXT_ID ], SCOPE_1_BIN_ID, 4))
        return candInfoList
    }

    public List getCandList_PartNo_3Parts_4(){
        List candInfoList = []
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_1_EXT_ID ], SCOPE_1_BIN_ID, 1))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_B_EXT_ID ], SCOPE_1_BIN_ID, 11))
        return candInfoList
    }

    public List getCandList_PartNo_3Parts_5(){
        List candInfoList = []
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_3_EXT_ID ], SCOPE_1_BIN_ID, 3))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_F_EXT_ID ], SCOPE_1_BIN_ID, 15))
        return candInfoList
    }

    public List getCandList_PartNo_3Parts_6(){
        List candInfoList = []
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_1_EXT_ID ], SCOPE_1_BIN_ID, 1))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_4_EXT_ID ], SCOPE_1_BIN_ID, 4))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_B_EXT_ID ], SCOPE_1_BIN_ID, 11))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_C_EXT_ID ], SCOPE_1_BIN_ID, 12))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_D_EXT_ID ], SCOPE_1_BIN_ID, 13))
        return candInfoList
    }

    public List getCandList_PartNo_AllParts_All(){
        List candInfoList = []
        List extIdList = [ PARTNO_1_EXT_ID, PARTNO_2_EXT_ID, PARTNO_3_EXT_ID, PARTNO_4_EXT_ID, PARTNO_5_EXT_ID,
                           PARTNO_6_EXT_ID, PARTNO_7_EXT_ID, PARTNO_8_EXT_ID, PARTNO_9_EXT_ID, PARTNO_A_EXT_ID, 
                           PARTNO_B_EXT_ID, PARTNO_C_EXT_ID, PARTNO_D_EXT_ID, PARTNO_E_EXT_ID, PARTNO_F_EXT_ID, PARTNO_G_EXT_ID ]
        for(int i = 1; i <= extIdList.size(); i++) {
            candInfoList.addAll(makeMaxScoreCandList([ extIdList[i-1] ], SCOPE_1_BIN_ID, i))
        }
		return candInfoList
    }

    public List getCandList_PartNo_AllParts_1(){
        List candInfoList = []
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_1_EXT_ID ], SCOPE_1_BIN_ID, 1))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_5_EXT_ID ], SCOPE_1_BIN_ID, 5))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_6_EXT_ID ], SCOPE_1_BIN_ID, 6))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_9_EXT_ID ], SCOPE_1_BIN_ID, 9))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_B_EXT_ID ], SCOPE_1_BIN_ID, 11))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_C_EXT_ID ], SCOPE_1_BIN_ID, 12))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_D_EXT_ID ], SCOPE_1_BIN_ID, 13))
        return candInfoList
    }

    public List getCandList_PartNo_AllParts_2(){
        List candInfoList = []
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_3_EXT_ID ], SCOPE_1_BIN_ID, 3))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_7_EXT_ID ], SCOPE_1_BIN_ID, 7))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_8_EXT_ID ], SCOPE_1_BIN_ID, 8))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_A_EXT_ID ], SCOPE_1_BIN_ID, 10))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_E_EXT_ID ], SCOPE_1_BIN_ID, 14))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_F_EXT_ID ], SCOPE_1_BIN_ID, 15))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_G_EXT_ID ], SCOPE_1_BIN_ID, 16))
        return candInfoList
    }

    public List getCandList_PartNo_AllParts_3(){
        List candInfoList = []
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_4_EXT_ID ], SCOPE_1_BIN_ID, 4))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_A_EXT_ID ], SCOPE_1_BIN_ID, 10))
        return candInfoList
    }

    public List getCandList_PartNo_AllParts_4(){
        List candInfoList = []
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_1_EXT_ID ], SCOPE_1_BIN_ID, 1))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_5_EXT_ID ], SCOPE_1_BIN_ID, 5))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_9_EXT_ID ], SCOPE_1_BIN_ID, 9))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_B_EXT_ID ], SCOPE_1_BIN_ID, 11))
        return candInfoList
    }

    public List getCandList_PartNo_AllParts_5(){
        List candInfoList = []
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_3_EXT_ID ], SCOPE_1_BIN_ID, 3))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_7_EXT_ID ], SCOPE_1_BIN_ID, 7))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_A_EXT_ID ], SCOPE_1_BIN_ID, 10))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_F_EXT_ID ], SCOPE_1_BIN_ID, 15))
        return candInfoList
    }

    public List getCandList_PartNo_AllParts_6(){
        List candInfoList = []
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_1_EXT_ID ], SCOPE_1_BIN_ID, 1))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_4_EXT_ID ], SCOPE_1_BIN_ID, 4))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_5_EXT_ID ], SCOPE_1_BIN_ID, 5))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_6_EXT_ID ], SCOPE_1_BIN_ID, 6))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_9_EXT_ID ], SCOPE_1_BIN_ID, 9))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_A_EXT_ID ], SCOPE_1_BIN_ID, 10))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_B_EXT_ID ], SCOPE_1_BIN_ID, 11))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_C_EXT_ID ], SCOPE_1_BIN_ID, 12))
        candInfoList.addAll(makeMaxScoreCandList([ PARTNO_D_EXT_ID ], SCOPE_1_BIN_ID, 13))
        return candInfoList
    }

	public List getCandList_useRace_All(){
        List extIdList = [ RACE_1_EXT_ID, RACE_2_EXT_ID, RACE_4_EXT_ID ]
		return makeMaxScoreCandList(extIdList)
	}

	public List getCandList_useRace_1(){
        List extIdList = [ RACE_2_EXT_ID ]
		return makeMaxScoreCandList(extIdList)
	}

	public List getCandList_useRace_2(){
        List extIdList = [ RACE_1_EXT_ID ]
		return makeMaxScoreCandList(extIdList)
	}

	public List getCandList_Race_All(){
        List extIdList = [ RACE_1_EXT_ID, RACE_2_EXT_ID, RACE_M1_EXT_ID ]
		return makeMaxScoreCandList(extIdList)
	}

	public List getCandList_Race_1(){
        List extIdList = [ RACE_1_EXT_ID, RACE_M1_EXT_ID ]
		return makeMaxScoreCandList(extIdList)
	}

	public List getCandList_useRegion_All(){
        List extIdList = [ REGION_1_EXT_ID, REGION_9_EXT_ID, REGION_U_EXT_ID ]
		return makeMaxScoreCandList(extIdList)
	}

	public List getCandList_useRegion_1(){
        List extIdList = [ REGION_9_EXT_ID, REGION_U_EXT_ID ]
		return makeMaxScoreCandList(extIdList)
	}

	public List getCandList_useRegion_2(){
        List extIdList = [ REGION_1_EXT_ID, REGION_U_EXT_ID ]
		return makeMaxScoreCandList(extIdList)
	}

	public List getCandList_Region_All(){
        List extIdList = [ REGION_1_EXT_ID, REGION_9_EXT_ID, REGION_F_EXT_ID, REGION_U_EXT_ID ]
		return makeMaxScoreCandList(extIdList)
	}

	public List getCandList_Region_1(){
        List extIdList = [ REGION_1_EXT_ID, REGION_U_EXT_ID ]
		return makeMaxScoreCandList(extIdList)
	}

	public List getCandList_Region_2(){
        List extIdList = [ REGION_F_EXT_ID, REGION_U_EXT_ID ]
		return makeMaxScoreCandList(extIdList)
	}

	public List getCandList_Cold(){
        List extIdList = []
        for(i in 1..9) {
            extIdList << String.format("${FUNC}_Cold_%05d", i)
        }
		return makeMaxScoreCandList(extIdList)
	}

	public List getCandList_AfisScript(){
        List extIdList = []
        for(i in 1..9) {
            extIdList << String.format("${FUNC}_AFISSCRIPT_%05d", i)
        }
		return makeMaxScoreCandList(extIdList)
	}

	public List getCandList_Scope_1(){
		return makeMaxScoreCandList([ SCOPE_1_EXT_ID ])
	}

	public List getCandList_Scope_2(){
		return makeMaxScoreCandList([ SCOPE_2_EXT_ID ], SCOPE_2_BIN_ID)
	}

	public List getCandList_Scope_3(){
		return makeMaxScoreCandList([ SCOPE_3_EXT_ID ], SCOPE_3_BIN_ID)
	}

	public List getCandList_Scope_1_2(){
        List candInfoList = []
        candInfoList.addAll(getCandList_Scope_1())
        candInfoList.addAll(getCandList_Scope_2())
        return candInfoList
	}

	public List getCandList_Scope_2_3(){
        List candInfoList = []
        candInfoList.addAll(getCandList_Scope_2())
        candInfoList.addAll(getCandList_Scope_3())
        return candInfoList
	}

	public List getCandList_Scope_1_2_3(){
        List candInfoList = []
        candInfoList.addAll(getCandList_Scope_1())
        candInfoList.addAll(getCandList_Scope_2())
        candInfoList.addAll(getCandList_Scope_3())
        return candInfoList
	}

	public List getCandList_Fw_100(){
		return [ FW_100_CAND_INFO_LIST ]
	}

	public List getCandList_Fw_120(){
		return [ FW_120_CAND_INFO_LIST ]
	}

	public List getCandList_Fw_null(){
		return [ FW_NULL_CAND_INFO_LIST ]
	}

	public List getCandList_ExtIdSort(){
		return [ EXT_SORT_HIGH_AB_CAND_INFO_LIST, EXT_SORT_HIGH_BA_CAND_INFO_LIST, EXT_SORT_HIGH_1C_CAND_INFO_LIST,
	             EXT_SORT_LOW_AB_CAND_INFO_LIST,  EXT_SORT_LOW_BA_CAND_INFO_LIST,  EXT_SORT_LOW_1C_CAND_INFO_LIST ]
	}

	private void setNullFwIfHighLevel(String level){
		if(level == "High") {
			this.fw = null
		}
	}

    private List makeMaxScoreCandList(List extIdList) {
        return makeCandList(extIdList, 9999, SCOPE_1_BIN_ID, FIN_1)
    }

    private List makeMaxScoreCandList(List extIdList, int containerId) {
        return makeCandList(extIdList, 9999, containerId, FIN_1)
    }

    private List makeMaxScoreCandList(List extIdList, int containerId, int pos) {
        return makeCandList(extIdList, 9999, containerId, pos)
    }

    private List makeCandList(List extIdList, int score) {
        return makeCandList(extIdList, score, SCOPE_1_BIN_ID, FIN_1)
    }

    private List makeCandList(List extIdList, int score, int containerId, int pos) {
        List candList = []
        for(extId in extIdList) {
		    candList <<  makeCandInfo(extId, score, containerId, pos)
        }
        return candList
    }

	private List makeCandInfo(String extId, int score, int containerId, int pos) {
		return [ extId, score, true,
				[ [ containerId, 1, reqIndex, score,
					[ [ score, pos, A, fw ] ] 
				] ]
			]
    }

	private getCorrectAlgorithmObj(def pc3rObj, def pzipObj){
        if(isPc3r()) {
		    return pc3rObj
        }else{
		    return pzipObj
        }
	}

    private boolean isPc3r() {
        if(projectName == "${FUNC}_PC3R_BY_ZONE_OFF") {
		    return true
        }else if(projectName == "${FUNC}_PZIP_BY_ZONE_OFF") {
		    return false
        }else{
            assert false, "Project name must be ${FUNC}_PC3R_BY_ZONE_OFF or ${FUNC}_PZIP_BY_ZONE_OFF, actual '${projectName}'"
        }
    }
}
