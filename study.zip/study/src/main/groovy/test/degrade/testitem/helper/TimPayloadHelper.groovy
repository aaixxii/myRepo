package test.degrade.testitem.helper

import static test.common.constants.aim.AIMWord.*
import test.degrade.properties.GlobalProperties
import test.common.constants.aim.*

class TimPayloadHelper extends PayloadHelper {

	private String timEngine
    static boolean ommitSearchPayload

    TimPayloadHelper(context) {
        super(context)
		this.timEngine = new GlobalProperties(context).getTimEngine().toUpperCase()
        initPayloadMap()
    }

    protected void initPayloadMap() {
		if(timEngine == CML){
			payloadMap = new CmlPayloadMap()
		}else if(timEngine == CMLAF){
			payloadMap = new CmlafPayloadMap()
		}
        commonOptMap = new CommonOptMapNoCallbackUrl().getDefaultParamMap()
        ommitSearchPayload = false
    }
	
	public String makePayload(def dataSrcTestStep){
		updatePayloadVal(dataSrcTestStep)
		return makePayload()
	}

    public String makePayload() {
        if(ommitSearchPayload) {
            return ""
        }
        StringBuilder sb = new StringBuilder()
        sb.append("<search-inputs-payload>\n")
        sb.append("<ns2:search-inputs-payload xmlns:ns2='urn:nec:aim'>\n")
        sb.append("<meta-info>\n")
        sb.append(makeMetaCommonXml())
        sb.append("</meta-info>\n")
        sb.append(makeTimOptionXml())
        sb.append("</ns2:search-inputs-payload>\n")
        sb.append("</search-inputs-payload>\n")
        return sb.toString()
    }
	
	private String makeTimOptionXml(){
		StringBuilder sb = new StringBuilder()

		if(timEngine == CML){
        	sb.append(makeCmlOptionsXml())
        }else if(timEngine == CMLAF){
        	sb.append(makeCmlafOptionsXml())
        }
		return sb.toString()
	}

}

