package test.degrade.testitem.helper

import common.util.ListUtil
import common.sql.SqlExecutor
import test.degrade.util.SoapuiObject
import test.common.util.assertion.AssertUtil
import test.common.util.db.SqlExecutorFactory
import test.degrade.management.AbendProcessor
import test.degrade.evidence.EvidenceFileOutputor
import static test.common.constants.aim.AIMWord.*

class JobExecutionPlanHelper {

	private static final int ASSIGNED_TOTAL_SJ_MIN_MAX_DIFF_CNT = 100
	private static final int ASSIGNED_SJ_MAX_DIFF = 4
	private static final int ASSIGNED_SJ_MAX_DIFF_CNT = 10
	private static final float STD_DEVIATION_LIMIT = 0.3
	private Map muAssignedSegNumEachMuIdMap
	private Map muAssignedSegNumEachSegSetJobIdMap
	private Map muJobSummaryMap
	private boolean isMixTest = false
	private boolean isMuUpDownTest = false
	private int targetBinId
	private int pushedJobCnt
	SoapuiObject soapuiObj
	SqlExecutor sqlExecuter
	AssertUtil assertUtil
	EvidenceFileOutputor evidenceOutputor
	
	JobExecutionPlanHelper(context){
		this.soapuiObj = new SoapuiObject(context)
		this.sqlExecuter = new SqlExecutorFactory(context).create()
		this.assertUtil = new AssertUtil(context, "JobCreationPlan")
		this.evidenceOutputor = new EvidenceFileOutputor(context)
	}
	
	public void doAssertMuUpDown() {
		outputTitle("MU Up/Down")
		isMuUpDownTest = true
		doAssertTimR()
		doAssertTimS()
	}
	
	public void doAssertMix(){
		outputTitle("MIX")
		isMixTest = true
		pushedJobCnt = 40
		doAssertTimR()
		doAssertTimS()
		doAssertLix()
		doAssertTlix()
	}
	
	public void doAssertLip(){
		targetBinId = PDB_ID as int
		outputTitle("LIP")
		doAssert()
	}

	public void doAssertLix(){
		targetBinId = XDBL_ID as int
		outputTitle("LIX")
		doAssert()
	}

	public void doAssertTimR(){
		targetBinId = RDBTM_ID as int
		outputTitle("TIM_ROLLED")
		doAssert()
	}

	public void doAssertTimS(){
		targetBinId = SDBTM_ID as int
		outputTitle("TIM_SLAP")
		doAssert()
	}
	
	public void doAssertTlix(){
		targetBinId = LDBX_ID as int
		outputTitle("TLIX")
		doAssert()
	}
	
	private void outputTitle(String func){
		evidenceOutputor.fileAppendWithTimestamp("\n" + decorateTitle(func))
	}

	private void doAssert() {
		initMap()
		List muIdList = fetchMuIdList()
		List segIdList = fetchSegIdList()
		assertUnderSegSetJobs(muIdList, segIdList)
		assertSummaryEachMus(muIdList.size(), segIdList.size())
		assertSummaryEachSegSetJobs()
	}
	
	private void initMap() {
		muAssignedSegNumEachMuIdMap = new TreeMap()
		muAssignedSegNumEachSegSetJobIdMap = new TreeMap()
		muJobSummaryMap = new TreeMap()
	}

	private void assertSummaryEachMus(int muNum, int segNum) {
		double avgSegNumPerMu = (double)segNum / muNum
		StringBuilder sb = new StringBuilder("\n")
		sb.append(decorateTitle(" Assigned SegNum info each MUs") + "\n")
		sb.append("muid sum min max avg\n")
		List sumList = []
		double sumAvgDiff = 0.0
		for(muId in muAssignedSegNumEachMuIdMap.keySet()) {
			List assignedSegNumList = muAssignedSegNumEachMuIdMap.get(muId)
			int min = ListUtil.getMin(assignedSegNumList)
			int max = ListUtil.getMax(assignedSegNumList)
			int sum = ListUtil.getSumInt(assignedSegNumList)
			double avg = ListUtil.getAvg(assignedSegNumList)
			sumAvgDiff += Math.abs(avgSegNumPerMu - avg)
			sb.append("$muId $sum $min $max $avg\n")
			sumList << sum
		}
		int min = ListUtil.getMin(sumList)
		int max = ListUtil.getMax(sumList)
		int diff = max - min
		double stddDeviation = sumAvgDiff / muAssignedSegNumEachMuIdMap.size()
		sb.append("MaxDiff of total assigned segJob num is $diff in all MUs.\n")
		sb.append("Standard deviation $stddDeviation\n")
		evidenceOutputor.fileAppendWithTimestamp(sb.toString())
		if(!isMuUpDownTest){
			assertTrue(diff < ASSIGNED_TOTAL_SJ_MIN_MAX_DIFF_CNT, "maxDiff of total assigned segJob num in all MUs. (expect which is less than 100. actual $diff)")
			assertTrue(stddDeviation < STD_DEVIATION_LIMIT, "Standard deviation of assigned segmentJob num each MUs. (expect which is less than 0.1. actual $stddDeviation)")
		}
	}

	private void assertSummaryEachSegSetJobs() {
		StringBuilder sb = new StringBuilder("\n")
		sb.append(decorateTitle(" Assigned SegNum info each SegmentSetJobId") + "\n")
		sb.append( "segSetJobId sum min max avg diff(max, min)\n")
		Map diffCntMap = new TreeMap()
		for(segSetJobId in muAssignedSegNumEachSegSetJobIdMap.keySet()) {
			List assignedSegNumList = muAssignedSegNumEachSegSetJobIdMap.get(segSetJobId)
			int min = ListUtil.getMin(assignedSegNumList)
			int max = ListUtil.getMax(assignedSegNumList)
			int sum = ListUtil.getSumInt(assignedSegNumList)
			double avg = ListUtil.getAvg(assignedSegNumList)
			int diff = max - min
			sb.append("$segSetJobId $sum $min $max $avg $diff\n")
			Integer cnt = diffCntMap.get(diff)
			if(cnt == null) {
				cnt = 0
			}
			diffCntMap.put(diff, ++cnt)
		}
		evidenceOutputor.fileAppendWithTimestamp(sb.toString())
		evidenceOutputor.fileAppendWithTimestamp("diff count")
		for(key in diffCntMap.keySet()) {
			int val = diffCntMap.get(key)
			evidenceOutputor.fileAppendWithTimestamp("$key $val")
			assertTrue(key <= ASSIGNED_SJ_MAX_DIFF, "diff(max-min) of assigned segJob num in each MuJobs. (expect which is less than 4. actual $key)")
			if(key == ASSIGNED_SJ_MAX_DIFF) {
				assertTrue(val < ASSIGNED_SJ_MAX_DIFF_CNT, "count(diff(3)) of assigned segJob num in each MuJobs. (expect which is less than 100. actual $val)")
			}
		}
	}

	private void assertUnderSegSetJobs(List muIdList, List segIdList) {
		List recs = sqlExecuter.getSqlResult("""select segment_set_job_id 
			from segment_set_jobs ssj, segment_sets ss
			where ss.segment_set_id = ssj.segment_set_id
			and ss.bin_id = ${targetBinId} 
			order by 1""")
		if(isMixTest){
			assertEquals(recs.size(), pushedJobCnt, "SSJ record count")
		}else{
			int jobCnt = sqlExecuter.selectCountSql("select count(*) from job_queue")
			assertEquals(recs.size(), jobCnt, "SSJ record count")
		}
		for(rec in recs) {
			int segSetJobId = rec[0]
			assertUnderMuJobs(segSetJobId, muIdList, segIdList)
		}
	}

	private void assertUnderMuJobs(int segSetJobId, List muIdList, List segIdList) {
		String sql = "select mu_job_id, mu_id, target_segments from mu_jobs where segment_set_job_id = $segSetJobId order by 1, 2"
		List recs = sqlExecuter.getSqlResult(sql)
		List assignedSegIdList = []
		List assignedMuIdList = []
		int redundancy = sqlExecuter.getSqlResultOneRecord("select min_redundancy from bins where bin_id = ${targetBinId}")
		float segNumPerMu = segIdList.size() * redundancy / muIdList.size()
		for(rec in recs) {
			int muJobId = rec[0]
			int muId = rec[1]
			String targetSegIdVers = rec[2]
			String[] targetSegArry = targetSegIdVers.split(",")
			if(!isMuUpDownTest){
				assertTrue(targetSegArry.length < segNumPerMu, "Assigned SEG num per MU. expected less than $segNumPerMu. actual ${targetSegArry.length}. MuJobId=${muJobId}, muId=${muId}")
			}
			assignedMuIdList << muId
			for(segIdVer in targetSegArry) {
				int segId = segIdVer.split(":")[0] as int
				assignedSegIdList << segId
			}
			putMuAssigneSegNumByMuId(muId, targetSegArry.length)
			putMuAssigneSegNumBySegSetJobId(segSetJobId, targetSegArry.length)
		}
		Collections.sort(assignedMuIdList)
		if(!isMuUpDownTest){
			assertEqualsList(assignedMuIdList, muIdList, "Assigned MuId")
		}
		Collections.sort(assignedSegIdList)
		assertEqualsList(assignedSegIdList, segIdList, "Assigned SegmentId")
	}

	private putMuAssigneSegNumByMuId(int muId, int assignedSegNum) {
		List assignedSegNumList = muAssignedSegNumEachMuIdMap.get(muId)
		if(assignedSegNumList == null) {
			assignedSegNumList = new ArrayList()
		}
		assignedSegNumList << assignedSegNum
		muAssignedSegNumEachMuIdMap.put(muId, assignedSegNumList)
	}

	private putMuAssigneSegNumBySegSetJobId(int segSetJobId, int assignedSegNum) {
		List assignedSegNumList = muAssignedSegNumEachSegSetJobIdMap.get(segSetJobId)
		if(assignedSegNumList == null) {
			assignedSegNumList = new ArrayList()
		}
		assignedSegNumList << assignedSegNum
		muAssignedSegNumEachSegSetJobIdMap.put(segSetJobId, assignedSegNumList)
	}

	private List fetchSegIdList() {
		String sql = """select s.segment_id from segments s, segment_sets ss
				where s.segment_set_id = ss.segment_set_id
				and ss.bin_id = ${targetBinId} order by 1"""
		return makeListFromSqlResult(sql)
	}

	private List fetchMuIdList() {
		String sql = """select mu.mu_id from match_units mu, mu_eligible_bins meb 
			where mu.mu_id = meb.mu_id
			and mu.type = 0 
			and mu.state = 'WORKING'
			and meb.bin_id = (${targetBinId})
			order by 1"""
		return makeListFromSqlResult(sql)
	}

	private makeListFromSqlResult(String sql) {
		List list = []
		List recs = sqlExecuter.getSqlResult(sql)
		for(rec in recs) {
			list << rec[0]
		}
		return list
	}
		

	private void assertEqualsList(List actual, List expected, String name) {
		assertUtil.assertEqualsList(actual, expected, name)
	}

	private void assertEquals(def actual, def expected, String name) {
		assertUtil.assertEquals(actual, expected, name)
	}

	private void assertTrue(boolean isTrue, String name) {
		assertUtil.assertTrue(isTrue, name)
	}

	private String decorateTitle(String title) {
		StringBuilder sb = new StringBuilder()
		sb.append("------------------------------\n")
		sb.append(title)
		sb.append("\n")
		sb.append("------------------------------\n")
		return sb.toString()
	}
}

