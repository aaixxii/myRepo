package test.degrade.testitem.helper.templates

import test.degrade.testitem.helper.*
import static test.common.constants.data.ImageDataList.*

class FiTestTemplateCreateHelper extends TestTemplateCreateHelper{

	def FiTestTemplateCreateHelper(context){
		super(context)
	}

	def getDefaultFaceImgXml(){
		return imgXmlMaker.getFaceImgXml(F_001_JPG)
	}

	def getConsolidateFaceImgXml(){
		return imgXmlMaker.getFaceImgXml(F_002_JPG)
	}

	def getScoreFaceImgXml_1(){
		return imgXmlMaker.getFaceImgXml(F_003_JPG)
	}

	def getScoreFaceImgXml_2(){
		return imgXmlMaker.getFaceImgXml(F_004_JPG)
	}
}
