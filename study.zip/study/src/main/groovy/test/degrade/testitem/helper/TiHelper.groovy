package test.degrade.testitem.helper

import static test.common.constants.aim.AIMXmlAttribute.*

class TiHelper extends ConsolidationHelper {

	private static final String GEN_M_EXT_ID = "M"
	private static final String GEN_F_EXT_ID = "F"
	private static final String GEN_U_EXT_ID = "U"

	private static final String NUMBER_01 = "00001"
	private static final String NUMBER_02 = "00002"
	private static final String NUMBER_03 = "00003"
	private static final String NUMBER_04 = "00004"
	private static final String NUMBER_05 = "00005"
	private static final String NUMBER_06 = "00006"
	private static final String NUMBER_07 = "00007"
	private static final String NUMBER_08 = "00008"
	private static final String NUMBER_09 = "00009"

	private static final String F1_EXT_ID = "TI1-"
	private static final String F2_EXT_ID = "TI2-"
	private static final String F3_EXT_ID = "TI3-"
	private static final String F4_EXT_ID = "TI4-"
	private static final String F5_6_EXT_ID = "TI5and6-"
	private static final String F7_8_EXT_ID = "TI7and8-"
	private static final String F9_EXT_ID = "TI9-"
	private static final String F10_11_EXT_ID = "TI10and11-"
	private static final String F12_13_EXT_ID = "TI12and13-"
	private static final String F14_15_EXT_ID = "TI14and15-"
	private static final String F16_EXT_ID_1 = "TF005_RDBT_gender_M_yob_1960"
	private static final String F16_EXT_ID_2 = "TF005_RDBT_gender_M_yob_1970"
	private static final String F16_EXT_ID_3 = "TF005_RDBT_gender_M_yob_1980"
	private static final String F16_EXT_ID_4 = "TF005_RDBT_gender_F_yob_1960"
	private static final String F16_EXT_ID_5 = "TF005_RDBT_gender_F_yob_1970"
	private static final String F16_EXT_ID_6 = "TF005_RDBT_gender_F_yob_1980"
	private static final String F16_EXT_ID_7 = "TF005_RDBT_gender_U_yob_1960"
	private static final String F16_EXT_ID_8 = "TF005_RDBT_gender_U_yob_1970"
	private static final String F16_EXT_ID_9 = "TF005_RDBT_gender_U_yob_1980"
	private static final String F17_EXT_ID = "TI17-"
	private static final String F18_EXT_ID = "TI18-"
	private static final String F19_EXT_ID = "TI19-"
	private static final String F20_EXT_ID = "TI20-"
	private static final String F21_EXT_ID = "TI21-"
	private static final String F22_EXT_ID = "TI22-"
	private static final String F24_EXT_ID = "TI24-"
	private static final String F25_EXT_ID = "TI25-"
	private static final String F26_EXT_ID = "TI26-"
	private static final String F27_EXT_ID = "TI27-"
	private static final String F28_EXT_ID = "TI28-"
	private static final String F29_EXT_ID = "TI29-"
	private static final String F30_EXT_ID = "TI30-"
	private static final String F31_EXT_ID = "TI31-"
	private static final String F32_EXT_ID = "TI32-"
	private static final String F33_HIGH_EXT_ID = "TI33-highScore-"
	private static final String F33_LOW_EXT_ID = "TI33-lowScore-"
	private static final String F34_EXT_ID = "TI34-"
	private static final String F39_EXT_ID = "TI39-"

	private static final int MAX_SCORE = 9999
	private static final int ZERO_SCORE = 0
	private static final int ROT_BY_AXIS_SCORE = 6170
	private static final int BASIC_SCORE_1_1F = 1305
	private static final int BASIC_SCORE_1_2F = 252
	private static final int BASIC_SCORE_1_5F = 108
	private static final int BASIC_SCORE_1_6F = 119
	private static final int BASIC_SCORE_1_7F = 90
	private static final int BASIC_SCORE_1_8F = 178
	private static final int BASIC_SCORE_1_9F = 161
	private static final int BASIC_SCORE_1_10F = 189
	private static final int BASIC_SCORE_2_1F = 2175
	private static final int BASIC_SCORE_3_1F = 5
	private static final int BASIC_SCORE_4_1F = 5
	private static final int BASIC_SCORE_5_1F = 1505
	private static final int BASIC_SCORE_5_2F = 250
	private static final int BASIC_SCORE_5_5F = 106
	private static final int BASIC_SCORE_5_6F = 121
	private static final int BASIC_SCORE_5_7F = 94
	private static final int BASIC_SCORE_5_8F = 174
	private static final int BASIC_SCORE_5_9F = 154
	private static final int BASIC_SCORE_5_10F = 192
	private static final int BASIC_SCORE_6_1F = 3885
	private static final int BASIC_SCORE_6_6F = 121
	private static final int BASIC_SCORE_6_9F = 104
	private static final int BASIC_SCORE_7_1F = 1392
	private static final int BASIC_SCORE_7_2F = 18
	private static final int BASIC_SCORE_7_4F = 142
	private static final int BASIC_SCORE_7_6F = 175
	private static final int BASIC_SCORE_7_7F = 143
	private static final int BASIC_SCORE_7_8F = 72
	private static final int BASIC_SCORE_7_10F = 44
	private static final int BASIC_SCORE_8_1F = 2280
	private static final int BASIC_SCORE_8_6F = 175
	private static final int BASIC_SCORE_8_9F = 162

	private int basic_score_1_1F 
	private int basic_score_2_1F
	private int basic_score_3_1F
	private int basic_score_4_1F
	private int basic_score_5_1F
	private int basic_score_6_1F
	private int basic_score_7
	private int basic_score_7_1F
	private int basic_score_7_4F
	private int basic_score_8
	private int basic_score_8_1F
	private int basic_score_8_9F
	
	private Integer rollFW = 100
	private Integer slapFW = 100
	private int eventId = 1
	private int reqIndexZero = 0
	private int reqIndexOne = 1

	private int sortHighScore_1_10F
	private int sortLowScore_1F
	private int sortLowScore_2_10F

	private List GEN_M_CAND_INFO_LIST = []
	private List GEN_F_CAND_INFO_LIST = []
	private List GEN_U_CAND_INFO_LIST = []

	private List F1_CARD_QUALITY_CAND_INFO_LIST_1 = []
	private List F1_CARD_QUALITY_CAND_INFO_LIST_2 = []
	private List F1_CARD_QUALITY_CAND_INFO_LIST_3 = []
	
	private List F2_APP_PATTERN_THRESHOLD_CAND_INFO_LIST_1 = []
	
	private List F3_PATTERN_THRESHOLD_CAND_INFO_LIST_1 = []
	
	private List F25_APP_GENDER_CAND_INFO_LIST_1 = []
	private List F25_APP_GENDER_CAND_INFO_LIST_2 = []
	private List F25_APP_GENDER_CAND_INFO_LIST_3 = []
	private List F25_APP_GENDER_CAND_INFO_LIST_4 = []
	
	private List F4_GENDER_CAND_INFO_LIST_1 = []
	private List F4_GENDER_CAND_INFO_LIST_2 = []
	private List F4_GENDER_CAND_INFO_LIST_3 = []
	private List F4_GENDER_CAND_INFO_LIST_4 = []
	private List F4_GENDER_CAND_INFO_LIST_5 = []
	private List F4_GENDER_CAND_INFO_LIST_6 = []

	private List F27_YOB_THRESHOLD_CAND_INFO_LIST_01 = []
	private List F27_YOB_THRESHOLD_CAND_INFO_LIST_02 = []
	private List F27_YOB_THRESHOLD_CAND_INFO_LIST_03 = []
	private List F27_YOB_THRESHOLD_CAND_INFO_LIST_04 = []
	private List F27_YOB_THRESHOLD_CAND_INFO_LIST_05 = []
	private List F27_YOB_THRESHOLD_CAND_INFO_LIST_06 = []
	private List F27_YOB_THRESHOLD_CAND_INFO_LIST_07 = []
	private List F27_YOB_THRESHOLD_CAND_INFO_LIST_08 = []
	private List F27_YOB_THRESHOLD_CAND_INFO_LIST_09 = []
	private List F27_YOB_THRESHOLD_CAND_INFO_LIST_10 = []
	private List F27_YOB_THRESHOLD_CAND_INFO_LIST_11 = []
	private List F27_YOB_THRESHOLD_CAND_INFO_LIST_12 = []

	private List F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_01 = []
	private List F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_02 = []
	private List F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_03 = []
	private List F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_04 = []
	private List F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_05 = []
	private List F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_06 = []
	private List F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_07 = []
	private List F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_08 = []
	private List F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_09 = []
	private List F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_10 = []
	private List F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_11 = []
	private List F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_12 = []
	private List F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_13 = []
	private List F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_14 = []
	
	private List F7_8_FINGER_CAND_INFO_LIST_1 = []
	
	private List F9_FILTER_CAND_INFO_LIST_1 = []		
	private List F9_FILTER_CAND_INFO_LIST_2 = []		
	private List F9_FILTER_CAND_INFO_LIST_3 = []		
	private List F9_FILTER_CAND_INFO_LIST_4 = []		
	
	private List F10_11_SPEED_CAND_INFO_LIST_1 = []		
	
	private List F12_13_ROTATION_CAND_INFO_LIST_1 = []		

	private List F14_15_DISTORTION_CAND_INFO_LIST_1 = []		

	private List F16_COLD_SEARCH_CAND_INFO_LIST_1 = []		
	private List F16_COLD_SEARCH_CAND_INFO_LIST_2 = []	
	private List F16_COLD_SEARCH_CAND_INFO_LIST_3 = []	
	private List F16_COLD_SEARCH_CAND_INFO_LIST_4 = []	
	private List F16_COLD_SEARCH_CAND_INFO_LIST_5 = []	
	private List F16_COLD_SEARCH_CAND_INFO_LIST_6 = []	
	private List F16_COLD_SEARCH_CAND_INFO_LIST_7 = []	
	private List F16_COLD_SEARCH_CAND_INFO_LIST_8 = []	
	private List F16_COLD_SEARCH_CAND_INFO_LIST_9 = []	
	
	private List F34_ROT_BY_AXIS_CAND_INFO_LIST_1 = []

	private List F17_TARGET_DB_CAND_INFO_LIST_1 = []
	private List F17_TARGET_DB_CAND_INFO_LIST_2 = []
	private List F17_TARGET_DB_CAND_INFO_LIST_3 = []
	
	private List F18_CONSOLIDATE_CAND_INFO_LIST_1 = []
	private List F18_CONSOLIDATE_CAND_INFO_LIST_2 = []
	private List F18_CONSOLIDATE_CAND_INFO_LIST_3 = []
	
	private List F32_CONSOLIDATE_CAND_INFO_LIST_1 = []
	private List F32_CONSOLIDATE_CAND_INFO_LIST_2 = []
		
	private List F20_LOC_CAND_INFO_LIST_1 = []
	private List F20_LOC_CAND_INFO_LIST_2 = []
	
	private List F21_MIN_CAND_INFO_LIST_1 = []
	private List F21_MIN_CAND_INFO_LIST_2 = []
	private List F21_MIN_CAND_INFO_LIST_3 = []
	
	private List F22_DYN_CAND_INFO_LIST_1 = []
	private List F22_DYN_CAND_INFO_LIST_2 = []
	private List F22_DYN_CAND_INFO_LIST_3 = []
	private List F22_DYN_CAND_INFO_LIST_4 = []
	private List F22_DYN_CAND_INFO_LIST_5 = []
	private List F22_DYN_CAND_INFO_LIST_6 = []
	
	private List F24_LOST_CAND_INFO_LIST_1 = []
	private List F24_LOST_CAND_INFO_LIST_2 = []
	private List F24_LOST_CAND_INFO_LIST_3 = []
	
	private List F26_YOB_CAND_INFO_LIST_1 = []
	private List F26_YOB_CAND_INFO_LIST_2 = []
	private List F26_YOB_CAND_INFO_LIST_3 = []
	private List F26_YOB_CAND_INFO_LIST_4 = []

	private List F28_AFIS_CAND_INFO_LIST_1 = []
	private List F28_AFIS_CAND_INFO_LIST_2 = []
	private List F28_AFIS_CAND_INFO_LIST_3 = []
	private List F28_AFIS_CAND_INFO_LIST_4 = []
	
	private List F29_SCOPE12_CAND_INFO_LIST_1 = []
	private List F29_SCOPE12_CAND_INFO_LIST_2 = []
	private List F29_SCOPE12_CAND_INFO_LIST_3 = []
	private List F29_SCOPE12_CAND_INFO_LIST_4 = []
	private List F29_SCOPE12_CAND_INFO_LIST_5 = []
	private List F29_SCOPE12_CAND_INFO_LIST_6 = []
	private List F29_SCOPE12_CAND_INFO_LIST_7 = []
	private List F29_SCOPE12_CAND_INFO_LIST_8 = []

	private List F31_SCOPE123_CAND_INFO_LIST_1 = []
	private List F31_SCOPE123_CAND_INFO_LIST_2 = []
	private List F31_SCOPE123_CAND_INFO_LIST_3 = []
	private List F31_SCOPE123_CAND_INFO_LIST_4 = []
	private List F31_SCOPE123_CAND_INFO_LIST_5 = []
	private List F31_SCOPE123_CAND_INFO_LIST_6 = []
	private List F31_SCOPE123_CAND_INFO_LIST_7 = []
	private List F31_SCOPE123_CAND_INFO_LIST_8 = []
	
	private List F30_FW_CAND_INFO_LIST_1 = []
	private List F30_FW_CAND_INFO_LIST_2 = []
	private List F30_FW_CAND_INFO_LIST_3 = []
	private List F30_FW_CAND_INFO_LIST_4 = []
	private List F30_FW_CAND_INFO_LIST_5 = []
	private List F30_FW_CAND_INFO_LIST_6 = []
	private List F30_FW_CAND_INFO_LIST_7 = []
	private List F33_HIGH_A_CAND_INFO_LIST = []
	private List F33_HIGH_B_CAND_INFO_LIST = []
	private List F33_HIGH_C_CAND_INFO_LIST = []
	private List F33_LOW_A_CAND_INFO_LIST = []
	private List F33_LOW_B_CAND_INFO_LIST = []
	private List F33_LOW_C_CAND_INFO_LIST = []

	private List F1_PROTO_7_8_CAND_INFO_LIST_1 = []
	private List F1_PROTO_7_8_CAND_INFO_LIST_2 = []
	private List F1_PROTO_9_10_CAND_INFO_LIST_1 = []
	private List F1_PROTO_9_10_CAND_INFO_LIST_2 = []
	private List F1_PROTO_13_CAND_INFO_LIST_1 = []
	private List F2_DUPLICATION_2_CAND_INFO_LIST_1 = []
	private List F2_DUPLICATION_2_CAND_INFO_LIST_2 = []
	private List F2_DUPLICATION_2_CAND_INFO_LIST_3 = []
	private List F2_DUPLICATION_2_CAND_INFO_LIST_4 = []

	private List MAX_INDIVIDUAL_SCORES_ROLL = [] 
	private List MAX_INDIVIDUAL_SCORES_SLAP = []
	private List ROT_BY_AXIS_INDIVIDUAL_SCORES = []
	private	List MAX_SCORE_CANDIDATE_1 = []
	private	List MAX_SCORE_CANDIDATE_2 = []
	private	List MAX_SCORE_CANDIDATE_3 = []
	private	List MAX_SCORE_CANDIDATE_4 = []
	private	List MAX_SCORE_CANDIDATE_5 = []
	private	List MAX_SCORE_CANDIDATE_SCOPE2_1 = []
	private	List MAX_SCORE_CANDIDATE_SCOPE2_2 = []
	private	List MAX_SCORE_CANDIDATE_SCOPE2_3 = []
	private	List MAX_SCORE_CANDIDATE_SCOPE2_4 = []
	private	List MAX_SCORE_CANDIDATE_SCOPE2_5 = []
	private	List MAX_SCORE_CANDIDATE_SCOPE3_1 = []
	private	List MAX_SCORE_CANDIDATE_SCOPE3_2 = []
	private	List MAX_SCORE_CANDIDATE_SCOPE3_3 = []
	private	List MAX_SCORE_CANDIDATE_SCOPE3_4 = []
	private	List MAX_SCORE_CANDIDATE_SCOPE3_5 = []
	private List BASIC_SCORE_CANDIDATE_1 = []
	private List PATTERN_SCORE_CANDIDATE_1 = []

	private List AFIS_SCORE_CANDIDATE_1 = []
	private List AFIS_SCORE_CANDIDATE_2 = []
	private List AFIS_SCORE_CANDIDATE_3 = []

    private String level = "high"

	TiHelper(context){
		super(context)
		initCandInfoLists()
	}

	TiHelper(context, String level){
		super(context)
        this.level = level
		initCandInfoLists()
	}

	private void initCandInfoLists() {
		initScores()
		initCommonCandInfoList()
		initPatternCandInfoList()
		initGenderCandInfoList()
		initYobCandInfoList()
		initColdSearchCandInfoList()
		initTargetDbCandInfoList()
		initConsolidateCandInfoList()
		initLocCandInfoList()
		initMinCandInfoList()
		initDynCandInfoList()
		initLostCandInfoList()
		initAfisCandInfoList()
		initScopeCandInfoList()
		initFWeightCandInfoList()
		initSortCandInfoList()
		initProtoAndAfisCandList()
	}

	private void initScores() {
		basic_score_1_1F = mergeFWeight(BASIC_SCORE_1_1F, rollFW)
		basic_score_2_1F = mergeFWeight(BASIC_SCORE_2_1F, rollFW)
		basic_score_3_1F = mergeFWeight(BASIC_SCORE_3_1F, slapFW)
		basic_score_4_1F = mergeFWeight(BASIC_SCORE_4_1F, slapFW)
		basic_score_5_1F = mergeFWeight(BASIC_SCORE_5_1F, rollFW)
		basic_score_6_1F = mergeFWeight(BASIC_SCORE_6_1F, rollFW)
		basic_score_7_1F = mergeFWeight(BASIC_SCORE_7_1F, slapFW)
		basic_score_7_4F = mergeFWeight(BASIC_SCORE_7_4F, slapFW)
		basic_score_8_1F = mergeFWeight(BASIC_SCORE_8_1F, slapFW)
		basic_score_8_9F = mergeFWeight(BASIC_SCORE_8_9F, slapFW)
		basic_score_7 = cutoffScore(basic_score_7_1F + basic_score_7_4F)
        basic_score_8 = cutoffScore(basic_score_8_1F + basic_score_8_9F)

		
	}

	private void initCommonCandInfoList(){
		
		MAX_INDIVIDUAL_SCORES_ROLL =
				[	[ MAX_SCORE, FIN_1, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_2, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_3, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_4, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_5, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_6, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_7, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_8, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_9, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] 

		MAX_INDIVIDUAL_SCORES_SLAP =
				[	[ MAX_SCORE, FIN_1, PC2_SLAP, slapFW ],
					[ MAX_SCORE, FIN_2, PC2_SLAP, slapFW ],
					[ MAX_SCORE, FIN_3, PC2_SLAP, slapFW ],
					[ MAX_SCORE, FIN_4, PC2_SLAP, slapFW ],
					[ MAX_SCORE, FIN_5, PC2_SLAP, slapFW ],
					[ MAX_SCORE, FIN_6, PC2_SLAP, slapFW ],
					[ MAX_SCORE, FIN_7, PC2_SLAP, slapFW ],
					[ MAX_SCORE, FIN_8, PC2_SLAP, slapFW ],
					[ MAX_SCORE, FIN_9, PC2_SLAP, slapFW ],
					[ MAX_SCORE, FIN_10, PC2_SLAP, slapFW ] ]

		ROT_BY_AXIS_INDIVIDUAL_SCORES = 
			[	[  1, eventId, reqIndexZero, MAX_SCORE,
					[	[ ROT_BY_AXIS_SCORE, FIN_1, PC2_ROLLED, rollFW ],
						[ ROT_BY_AXIS_SCORE, FIN_2, PC2_ROLLED, rollFW ],
						[ ROT_BY_AXIS_SCORE, FIN_3, PC2_ROLLED, rollFW ],
						[ ROT_BY_AXIS_SCORE, FIN_4, PC2_ROLLED, rollFW ],
						[ ROT_BY_AXIS_SCORE, FIN_5, PC2_ROLLED, rollFW ],
						[ ROT_BY_AXIS_SCORE, FIN_6, PC2_ROLLED, rollFW ],
						[ ROT_BY_AXIS_SCORE, FIN_7, PC2_ROLLED, rollFW ],
						[ ROT_BY_AXIS_SCORE, FIN_8, PC2_ROLLED, rollFW ],
						[ ROT_BY_AXIS_SCORE, FIN_9, PC2_ROLLED, rollFW ],
						[ ROT_BY_AXIS_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ] ]
		
		MAX_SCORE_CANDIDATE_1 =
			 [ [ 1, eventId, reqIndexZero, MAX_SCORE, MAX_INDIVIDUAL_SCORES_ROLL ]]
		MAX_SCORE_CANDIDATE_2 =
			 [ [ 2, eventId, reqIndexZero, MAX_SCORE, MAX_INDIVIDUAL_SCORES_SLAP ]]
		MAX_SCORE_CANDIDATE_3 =
			 [ [ 1, eventId, reqIndexOne, MAX_SCORE, MAX_INDIVIDUAL_SCORES_ROLL ]]
		MAX_SCORE_CANDIDATE_4 =
			 [ [ 2, eventId, reqIndexOne, MAX_SCORE, MAX_INDIVIDUAL_SCORES_SLAP ]]
		MAX_SCORE_CANDIDATE_5 =
			 [ [ 2, eventId, reqIndexZero, MAX_SCORE, MAX_INDIVIDUAL_SCORES_ROLL ]]

		MAX_SCORE_CANDIDATE_SCOPE2_1 =
			 [ [ 1001, eventId, reqIndexZero, MAX_SCORE, MAX_INDIVIDUAL_SCORES_ROLL ]]
		MAX_SCORE_CANDIDATE_SCOPE2_2 =
			 [ [ 1002, eventId, reqIndexZero, MAX_SCORE, MAX_INDIVIDUAL_SCORES_SLAP ]]
		MAX_SCORE_CANDIDATE_SCOPE2_3 =
			 [ [ 1001, eventId, reqIndexOne, MAX_SCORE, MAX_INDIVIDUAL_SCORES_ROLL ]]
		MAX_SCORE_CANDIDATE_SCOPE2_4 =
			 [ [ 1002, eventId, reqIndexOne, MAX_SCORE, MAX_INDIVIDUAL_SCORES_SLAP ]]
		MAX_SCORE_CANDIDATE_SCOPE2_5 =
			 [ [ 1002, eventId, reqIndexZero, MAX_SCORE, MAX_INDIVIDUAL_SCORES_ROLL ]]

		MAX_SCORE_CANDIDATE_SCOPE3_1 =
			 [ [ 2001, eventId, reqIndexZero, MAX_SCORE, MAX_INDIVIDUAL_SCORES_ROLL ]]
		MAX_SCORE_CANDIDATE_SCOPE3_2 =
			 [ [ 2002, eventId, reqIndexZero, MAX_SCORE, MAX_INDIVIDUAL_SCORES_SLAP ]]
		MAX_SCORE_CANDIDATE_SCOPE3_3 =
			 [ [ 2001, eventId, reqIndexOne, MAX_SCORE, MAX_INDIVIDUAL_SCORES_ROLL ]]
		MAX_SCORE_CANDIDATE_SCOPE3_4 =
			 [ [ 2002, eventId, reqIndexOne, MAX_SCORE, MAX_INDIVIDUAL_SCORES_SLAP ]]
		MAX_SCORE_CANDIDATE_SCOPE3_5 =
			 [ [ 2002, eventId, reqIndexZero, MAX_SCORE, MAX_INDIVIDUAL_SCORES_ROLL ]]

		BASIC_SCORE_CANDIDATE_1 =
			 [ [ 1, eventId, reqIndexZero, 2402,
				[	[ BASIC_SCORE_1_1F, FIN_1, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_1_2F, FIN_2, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_1_5F, FIN_5, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_1_6F, FIN_6, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_1_7F, FIN_7, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_1_8F, FIN_8, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_1_9F, FIN_9, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_1_10F, FIN_10, PC2_ROLLED, rollFW ] ] ] ]

		F1_CARD_QUALITY_CAND_INFO_LIST_1 = 
	         [ F1_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F1_CARD_QUALITY_CAND_INFO_LIST_2 = 
	         [ F1_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F1_CARD_QUALITY_CAND_INFO_LIST_3 = 
	         [ F1_EXT_ID + NUMBER_03, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
	
		F34_ROT_BY_AXIS_CAND_INFO_LIST_1 = 
			 [ F34_EXT_ID + NUMBER_01, MAX_SCORE, true, ROT_BY_AXIS_INDIVIDUAL_SCORES ]

		F7_8_FINGER_CAND_INFO_LIST_1 =
			 [ F7_8_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]

		F9_FILTER_CAND_INFO_LIST_1 = 
		 	 [ F9_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F9_FILTER_CAND_INFO_LIST_2 = 
		 	 [ F9_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F9_FILTER_CAND_INFO_LIST_3 = 
		 	 [ F9_EXT_ID + NUMBER_03, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F9_FILTER_CAND_INFO_LIST_4 = 
		 	 [ F9_EXT_ID + NUMBER_04, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
	
		F10_11_SPEED_CAND_INFO_LIST_1 =
			 [ F10_11_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]

		F12_13_ROTATION_CAND_INFO_LIST_1 =
			 [ F12_13_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]

		F14_15_DISTORTION_CAND_INFO_LIST_1 =
			 [ F14_15_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1]	
	}

	private void initPatternCandInfoList(){
		PATTERN_SCORE_CANDIDATE_1 = 
			[ [ 1, eventId, reqIndexZero, MAX_SCORE, 
                [   [ MAX_SCORE, FIN_1, PC2_ROLLED, rollFW ],
                    [ 9186, FIN_2, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                    [ 3292, FIN_4, PC2_ROLLED, rollFW ],
                    [ 6997, FIN_5, PC2_ROLLED, rollFW ],
                    [ 5289, FIN_6, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                    [ 3238, FIN_9, PC2_ROLLED, rollFW ],
                    [ 5756, FIN_10, PC2_ROLLED, rollFW ] ] ] ]

		F2_APP_PATTERN_THRESHOLD_CAND_INFO_LIST_1 = 
			 [ F2_EXT_ID + NUMBER_01, MAX_SCORE, true, PATTERN_SCORE_CANDIDATE_1]
		F3_PATTERN_THRESHOLD_CAND_INFO_LIST_1 = 
			 [ F3_EXT_ID + NUMBER_01, MAX_SCORE, true, PATTERN_SCORE_CANDIDATE_1]
	}
	
	private void initGenderCandInfoList(){

		F25_APP_GENDER_CAND_INFO_LIST_1 =
			[ F25_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]

		F25_APP_GENDER_CAND_INFO_LIST_2 =
			[ F25_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_4 ]

		F25_APP_GENDER_CAND_INFO_LIST_3 =
			[ F25_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]

		F25_APP_GENDER_CAND_INFO_LIST_4 =
			[ F25_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_4 ]

		F4_GENDER_CAND_INFO_LIST_1 =
			 [ F4_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		
		F4_GENDER_CAND_INFO_LIST_2 =
			 [ F4_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_4 ]

		F4_GENDER_CAND_INFO_LIST_3 =
			 [ F4_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		
		F4_GENDER_CAND_INFO_LIST_4 =
			 [ F4_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_4 ]
	
		F4_GENDER_CAND_INFO_LIST_5 =
			 [ F4_EXT_ID + NUMBER_03, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		
		F4_GENDER_CAND_INFO_LIST_6 =
			 [ F4_EXT_ID + NUMBER_03, MAX_SCORE, true, MAX_SCORE_CANDIDATE_4 ]

	}

	private void initYobCandInfoList(){
		F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_01 =
			 [ F5_6_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		
		F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_02 =
			 [ F5_6_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_4 ]
		
		F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_03 =
			 [ F5_6_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		
		F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_04 =
			 [ F5_6_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_4 ]
		
		F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_05 =
			 [ F5_6_EXT_ID + NUMBER_03, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		
		F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_06 =
			 [ F5_6_EXT_ID + NUMBER_03, MAX_SCORE, true, MAX_SCORE_CANDIDATE_4 ]
		
		F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_07 =
			 [ F5_6_EXT_ID + NUMBER_04, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		
		F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_08 =
			 [ F5_6_EXT_ID + NUMBER_04, MAX_SCORE, true, MAX_SCORE_CANDIDATE_4 ]
		
		F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_09 =
			 [ F5_6_EXT_ID + NUMBER_05, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		
		F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_10 =
			 [ F5_6_EXT_ID + NUMBER_05, MAX_SCORE, true, MAX_SCORE_CANDIDATE_4 ]
		
		F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_11 =
			 [ F5_6_EXT_ID + NUMBER_06, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		
		F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_12 =
			 [ F5_6_EXT_ID + NUMBER_06, MAX_SCORE, true, MAX_SCORE_CANDIDATE_4 ]
		
		F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_13 =
			 [ F5_6_EXT_ID + NUMBER_07, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		
		F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_14 =
			 [ F5_6_EXT_ID + NUMBER_07, MAX_SCORE, true, MAX_SCORE_CANDIDATE_4 ]
	
		
		F26_YOB_CAND_INFO_LIST_1 =
			 [ F26_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		
		F26_YOB_CAND_INFO_LIST_2 =
			 [ F26_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_4 ]

		F26_YOB_CAND_INFO_LIST_3 =
			 [ F26_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		
		F26_YOB_CAND_INFO_LIST_4 =
			 [ F26_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_4 ]

	
		F27_YOB_THRESHOLD_CAND_INFO_LIST_01 =
			 [ F27_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		
		F27_YOB_THRESHOLD_CAND_INFO_LIST_02 =
			 [ F27_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_4 ]

		F27_YOB_THRESHOLD_CAND_INFO_LIST_03 =
			 [ F27_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		
		F27_YOB_THRESHOLD_CAND_INFO_LIST_04 =
			 [ F27_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_4 ]
	
		F27_YOB_THRESHOLD_CAND_INFO_LIST_05 =
			 [ F27_EXT_ID + NUMBER_03, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
	
		F27_YOB_THRESHOLD_CAND_INFO_LIST_06 =
			 [ F27_EXT_ID + NUMBER_03, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]

		F27_YOB_THRESHOLD_CAND_INFO_LIST_07 =
			 [ F27_EXT_ID + NUMBER_04, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		
		F27_YOB_THRESHOLD_CAND_INFO_LIST_08 =
			 [ F27_EXT_ID + NUMBER_04, MAX_SCORE, true, MAX_SCORE_CANDIDATE_4 ]

		F27_YOB_THRESHOLD_CAND_INFO_LIST_09 =
			 [ F27_EXT_ID + NUMBER_05, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		
		F27_YOB_THRESHOLD_CAND_INFO_LIST_10 =
			 [ F27_EXT_ID + NUMBER_05, MAX_SCORE, true, MAX_SCORE_CANDIDATE_4 ]
	
		F27_YOB_THRESHOLD_CAND_INFO_LIST_11 =
			 [ F27_EXT_ID + NUMBER_06, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
	
		F27_YOB_THRESHOLD_CAND_INFO_LIST_12 =
			 [ F27_EXT_ID + NUMBER_06, MAX_SCORE, true, MAX_SCORE_CANDIDATE_4 ]
	}

	private void initColdSearchCandInfoList(){
		F16_COLD_SEARCH_CAND_INFO_LIST_1 =
		 	 [ F16_EXT_ID_1 , MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F16_COLD_SEARCH_CAND_INFO_LIST_2 =
		 	 [ F16_EXT_ID_2 , MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F16_COLD_SEARCH_CAND_INFO_LIST_3 =
		 	 [ F16_EXT_ID_3 , MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F16_COLD_SEARCH_CAND_INFO_LIST_4 =
		 	 [ F16_EXT_ID_4 , MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F16_COLD_SEARCH_CAND_INFO_LIST_5 =
		 	 [ F16_EXT_ID_5 , MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F16_COLD_SEARCH_CAND_INFO_LIST_6 =
		 	 [ F16_EXT_ID_6 , MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F16_COLD_SEARCH_CAND_INFO_LIST_7 =
		 	 [ F16_EXT_ID_7 , MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F16_COLD_SEARCH_CAND_INFO_LIST_8 =
		 	 [ F16_EXT_ID_8 , MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F16_COLD_SEARCH_CAND_INFO_LIST_9 =
		 	 [ F16_EXT_ID_9 , MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
    }


	private void initTargetDbCandInfoList(){
		F17_TARGET_DB_CAND_INFO_LIST_1 =
			 [ F17_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]

        if(level == "high") {
		    F17_TARGET_DB_CAND_INFO_LIST_2 =
			    [ F17_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_2 ]
        }else{
		    F17_TARGET_DB_CAND_INFO_LIST_2 =
			    [ F17_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_5 ]
        }

		F17_TARGET_DB_CAND_INFO_LIST_3 =
			 [ F17_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_4 ]
	}

	private int F18_CONSOLIDATE_COMPOSITE_SCORE_6 = BASIC_SCORE_6_1F + BASIC_SCORE_6_6F + BASIC_SCORE_6_9F
	private int F18_CONSOLIDATE_FUSION_SCORE_6 = F18_CONSOLIDATE_COMPOSITE_SCORE_6
	private int F18_CONSOLIDATE_COMPOSITE_SCORE_5 = BASIC_SCORE_5_1F + BASIC_SCORE_5_2F + BASIC_SCORE_5_5F + BASIC_SCORE_5_6F + 
		BASIC_SCORE_5_7F + BASIC_SCORE_5_8F + BASIC_SCORE_5_9F + BASIC_SCORE_5_10F
	private int F18_CONSOLIDATE_COMPOSITE_SCORE_7 = BASIC_SCORE_7_1F + BASIC_SCORE_7_4F + BASIC_SCORE_7_7F
	private int F18_CONSOLIDATE_FUSION_SCORE_LIST_2 = F18_CONSOLIDATE_COMPOSITE_SCORE_7 + F18_CONSOLIDATE_COMPOSITE_SCORE_5
	private int F18_CONSOLIDATE_COMPOSITE_SCORE_8 = BASIC_SCORE_8_1F + BASIC_SCORE_8_6F + BASIC_SCORE_8_9F
	
	private void initConsolidateCandInfoList(){
		F18_CONSOLIDATE_CAND_INFO_LIST_1 = 
			[ F18_EXT_ID + NUMBER_01, F18_CONSOLIDATE_FUSION_SCORE_6, true, 
				[ [ 2, eventId, reqIndexZero, F18_CONSOLIDATE_COMPOSITE_SCORE_6,
                    [   [ BASIC_SCORE_6_1F, FIN_1, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
	                    [ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_6_6F, FIN_6, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_6_9F, FIN_9, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ], 
				  [ 1, eventId, reqIndexZero, F18_CONSOLIDATE_COMPOSITE_SCORE_5,
					[	[ BASIC_SCORE_5_1F, FIN_1, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_2F, FIN_2, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_5F, FIN_5, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_6F, FIN_6, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_7F, FIN_7, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_8F, FIN_8, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_9F, FIN_9, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_10F, FIN_10, PC2_ROLLED, rollFW ] ] ] ] 
			]

		F18_CONSOLIDATE_CAND_INFO_LIST_2 = 
			[ F18_EXT_ID + NUMBER_01, F18_CONSOLIDATE_FUSION_SCORE_LIST_2, true, 
				[ [ 1, eventId, reqIndexZero, F18_CONSOLIDATE_COMPOSITE_SCORE_5,
					[	[ BASIC_SCORE_5_1F, FIN_1, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_2F, FIN_2, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_5F, FIN_5, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_6F, FIN_6, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_7F, FIN_7, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_8F, FIN_8, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_9F, FIN_9, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_10F, FIN_10, PC2_ROLLED, rollFW ] ] ],
				  [ 1, eventId, reqIndexOne, F18_CONSOLIDATE_COMPOSITE_SCORE_7,
					[	[ BASIC_SCORE_7_1F, FIN_1, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_2, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_3, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_4F, FIN_4, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_5, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_6, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_7F, FIN_7, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_8, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_9, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_10, PC2_SLAP, slapFW ] ] ] 
						]
			]

		
		F18_CONSOLIDATE_CAND_INFO_LIST_3 = 
			[ F18_EXT_ID + NUMBER_01, 6552, true, 
				[ 
				  [ 2, eventId, reqIndexZero, F18_CONSOLIDATE_COMPOSITE_SCORE_6,
                    [   [ BASIC_SCORE_6_1F, FIN_1, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
	                    [ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_6_6F, FIN_6, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_6_9F, FIN_9, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ] ,
                        
				  [ 1, eventId, reqIndexZero, F18_CONSOLIDATE_COMPOSITE_SCORE_5,
					[	[ BASIC_SCORE_5_1F, FIN_1, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_2F, FIN_2, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_5F, FIN_5, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_6F, FIN_6, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_7F, FIN_7, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_8F, FIN_8, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_9F, FIN_9, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_10F, FIN_10, PC2_ROLLED, rollFW ] ] ],

				  [ 2, eventId, reqIndexOne, BASIC_SCORE_8_1F + BASIC_SCORE_8_9F,
					[	[ BASIC_SCORE_8_1F, FIN_1, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_2, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_3, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_4, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_5, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_6, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_7, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_8, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_8_9F, FIN_9, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_10, PC2_SLAP, slapFW ] ] ],
						
				  [ 1, eventId, reqIndexOne, F18_CONSOLIDATE_COMPOSITE_SCORE_7,
					[	[ BASIC_SCORE_7_1F, FIN_1, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_2, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_3, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_4F, FIN_4, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_5, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_6, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_7F, FIN_7, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_8, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_9, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_10, PC2_SLAP, slapFW ] ] ] 
			    ]
			]
		
		F32_CONSOLIDATE_CAND_INFO_LIST_1 = 
			[ F32_EXT_ID + NUMBER_01, F18_CONSOLIDATE_COMPOSITE_SCORE_6, true, 
				[ 
   			      [ 2, eventId, reqIndexZero, F18_CONSOLIDATE_COMPOSITE_SCORE_6,
                    [   [ BASIC_SCORE_6_1F, FIN_1, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
	                    [ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_6_6F, FIN_6, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_6_9F, FIN_9, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ]  ,
				  [ 1001, eventId, reqIndexZero, F18_CONSOLIDATE_COMPOSITE_SCORE_5,
					[	[ BASIC_SCORE_5_1F, FIN_1, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_2F, FIN_2, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_5F, FIN_5, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_6F, FIN_6, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_7F, FIN_7, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_8F, FIN_8, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_9F, FIN_9, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_10F, FIN_10, PC2_ROLLED, rollFW ] ] ] ,
				  [ 1, eventId, reqIndexZero, F18_CONSOLIDATE_COMPOSITE_SCORE_5,
					[	[ BASIC_SCORE_5_1F, FIN_1, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_2F, FIN_2, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_5F, FIN_5, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_6F, FIN_6, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_7F, FIN_7, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_8F, FIN_8, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_9F, FIN_9, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_10F, FIN_10, PC2_ROLLED, rollFW ] ] ]  ,
                   [ 1002, eventId, reqIndexZero, F18_CONSOLIDATE_COMPOSITE_SCORE_6,
                    [   [ BASIC_SCORE_6_1F, FIN_1, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
	                    [ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_6_6F, FIN_6, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_6_9F, FIN_9, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ] ]
			]
	
		F32_CONSOLIDATE_CAND_INFO_LIST_2 = 
			[ F32_EXT_ID + NUMBER_01, 6717, true, 
				[ 
				  [ 2, eventId, reqIndexZero, F18_CONSOLIDATE_COMPOSITE_SCORE_6,
                    [   [ BASIC_SCORE_6_1F, FIN_1, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
	                    [ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_6_6F, FIN_6, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_6_9F, FIN_9, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ]  ,

				  [ 1001, eventId, reqIndexZero, F18_CONSOLIDATE_COMPOSITE_SCORE_5,
                    [	[ BASIC_SCORE_5_1F, FIN_1, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_2F, FIN_2, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_5F, FIN_5, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_6F, FIN_6, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_7F, FIN_7, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_8F, FIN_8, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_9F, FIN_9, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_10F, FIN_10, PC2_ROLLED, rollFW ] ] ]  ,

				  [ 1, eventId, reqIndexZero, F18_CONSOLIDATE_COMPOSITE_SCORE_5,
                    [	[ BASIC_SCORE_5_1F, FIN_1, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_2F, FIN_2, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_5F, FIN_5, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_6F, FIN_6, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_7F, FIN_7, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_8F, FIN_8, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_9F, FIN_9, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_10F, FIN_10, PC2_ROLLED, rollFW ] ] ]  ,
				  [ 1002, eventId, reqIndexZero, F18_CONSOLIDATE_COMPOSITE_SCORE_6,
                    [   [ BASIC_SCORE_6_1F, FIN_1, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
	                    [ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_6_6F, FIN_6, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_6_9F, FIN_9, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ]  ,
				  [ 2, eventId, reqIndexOne, BASIC_SCORE_8_1F+BASIC_SCORE_8_6F+152,
					[	[ BASIC_SCORE_8_1F, FIN_1, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_2, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_3, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_4, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_5, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_8_6F, FIN_6, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_7, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_8, PC2_SLAP, slapFW ],
						[ 152, FIN_9, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_10, PC2_SLAP, slapFW ] ] ]  ,
				  [ 1001, eventId, reqIndexOne, 1917,
					[	[ BASIC_SCORE_7_1F, FIN_1, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_2F, FIN_2, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_3, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_4F, FIN_4, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_5, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_6F, FIN_6, PC2_SLAP, slapFW ],
						[ 74, FIN_7, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_8F, FIN_8, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_9, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_10F, FIN_10, PC2_SLAP, slapFW ] ] ]  ,
				 [ 1, eventId, reqIndexOne, 1917,
					[	[ BASIC_SCORE_7_1F, FIN_1, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_2F, FIN_2, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_3, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_4F, FIN_4, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_5, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_6F, FIN_6, PC2_SLAP, slapFW ],
						[ 74, FIN_7, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_8F, FIN_8, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_9, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_10F, FIN_10, PC2_SLAP, slapFW ] ] ]  ,
				  [ 1002, eventId, reqIndexOne, BASIC_SCORE_8_1F+BASIC_SCORE_8_6F+152,
					[	[ BASIC_SCORE_8_1F, FIN_1, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_2, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_3, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_4, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_5, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_8_6F, FIN_6, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_7, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_8, PC2_SLAP, slapFW ],
						[ 152, FIN_9, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_10, PC2_SLAP, slapFW ] ] ] ]
			]
	
	}
	
	private void initLocCandInfoList(){
	}
	
	private void initMinCandInfoList(){
		List MinScoreCandidate1 = 
			[ [ 1, eventId, reqIndexZero, 2705,
				[   [ 1608, FIN_1, PC2_ROLLED, rollFW ],
                    [ 252, FIN_2, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                    [ 108, FIN_5, PC2_ROLLED, rollFW ],
                    [ 119, FIN_6, PC2_ROLLED, rollFW ],
                    [ 90, FIN_7, PC2_ROLLED, rollFW ],
                    [ 178, FIN_8, PC2_ROLLED, rollFW ],
                    [ 161, FIN_9, PC2_ROLLED, rollFW ],
                    [ 189, FIN_10, PC2_ROLLED, rollFW ] ] ] ]
		
		List MinScoreCandidate2 = 
			[ [ 1, eventId, reqIndexZero, 2402,
				[   [ 1305, FIN_1, PC2_ROLLED, rollFW ],
                    [ 252, FIN_2, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                    [ 108, FIN_5, PC2_ROLLED, rollFW ],
                    [ 119, FIN_6, PC2_ROLLED, rollFW ],
                    [ 90, FIN_7, PC2_ROLLED, rollFW ],
                    [ 178, FIN_8, PC2_ROLLED, rollFW ],
                    [ 161, FIN_9, PC2_ROLLED, rollFW ],
                    [ 189, FIN_10, PC2_ROLLED, rollFW ] ] ] ]

		List MinScoreCandidate3 = 
			[ [ 1, eventId, reqIndexZero, MAX_SCORE,
				[   [ MAX_SCORE, FIN_1, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_6, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_9, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ] ]
		
		F21_MIN_CAND_INFO_LIST_1 = 
			[ F21_EXT_ID + NUMBER_01, 2705, true, MinScoreCandidate1 ]
		F21_MIN_CAND_INFO_LIST_2 = 
			[ F21_EXT_ID + NUMBER_02, 2402, true, MinScoreCandidate2 ]
		F21_MIN_CAND_INFO_LIST_3 = 
			[ F21_EXT_ID + NUMBER_03, MAX_SCORE, true, MinScoreCandidate3 ]
	}

	private void initDynCandInfoList(){
		List DynScoreCandidate1 = 
			[ [ 1, eventId, reqIndexZero, 2705,
				[   [ 1608, FIN_1, PC2_ROLLED, rollFW ],
                    [ 252, FIN_2, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                    [ 108, FIN_5, PC2_ROLLED, rollFW ],
                    [ 119, FIN_6, PC2_ROLLED, rollFW ],
                    [ 90, FIN_7, PC2_ROLLED, rollFW ],
                    [ 178, FIN_8, PC2_ROLLED, rollFW ],
                    [ 161, FIN_9, PC2_ROLLED, rollFW ],
                    [ 189, FIN_10, PC2_ROLLED, rollFW ] ] ] ]
		
		List DynScoreCandidate2 = 
			[ [ 1, eventId, reqIndexZero, 2402,
				[   [ 1305, FIN_1, PC2_ROLLED, rollFW ],
                    [ 252, FIN_2, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                    [ 108, FIN_5, PC2_ROLLED, rollFW ],
                    [ 119, FIN_6, PC2_ROLLED, rollFW ],
                    [ 90, FIN_7, PC2_ROLLED, rollFW ],
                    [ 178, FIN_8, PC2_ROLLED, rollFW ],
                    [ 161, FIN_9, PC2_ROLLED, rollFW ],
                    [ 189, FIN_10, PC2_ROLLED, rollFW ] ] ] ]
                    
		List DynScoreCandidate3 = 
			[ [ 1, eventId, reqIndexZero, MAX_SCORE,
				[   [ MAX_SCORE, FIN_1, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_6, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_9, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ] ]
		
		F22_DYN_CAND_INFO_LIST_1 = 
			[ F22_EXT_ID + NUMBER_01, 2705, true, DynScoreCandidate1 ]
		F22_DYN_CAND_INFO_LIST_2 = 
			[ F22_EXT_ID + NUMBER_02, 2402, true, DynScoreCandidate2 ]
		F22_DYN_CAND_INFO_LIST_3 = 
			[ F22_EXT_ID + NUMBER_03, MAX_SCORE, true, DynScoreCandidate3 ]
		F22_DYN_CAND_INFO_LIST_4 = 
			[ F22_EXT_ID + NUMBER_01, 2705, false, DynScoreCandidate1 ]
		F22_DYN_CAND_INFO_LIST_5 = 
			[ F22_EXT_ID + NUMBER_02, 2402, false, DynScoreCandidate2 ]
		F22_DYN_CAND_INFO_LIST_6 = 
			[ F22_EXT_ID + NUMBER_02, 2402, true, DynScoreCandidate2 ]
	}

	private void initLostCandInfoList(){
		List lostScoreCandidate1 = 
			 [ [ 1, eventId, reqIndexZero, MAX_SCORE,
				[	[ ZERO_SCORE, FIN_1, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_2, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_3, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_4, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_5, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_6, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_7, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_8, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_9, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ] ]
		
		List lostScoreCandidate2 = 
			 [ [ 1, eventId, reqIndexZero, MAX_SCORE,
				[	[ ZERO_SCORE, FIN_1, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_2, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_5, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_6, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_7, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_8, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_9, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ] ]	

		List lostScoreCandidate3 = 
			 [ [ 1, eventId, reqIndexZero, MAX_SCORE,
				[	[ ZERO_SCORE, FIN_1, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_2, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_5, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_6, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_7, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_8, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_9, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ] ]
		
		F24_LOST_CAND_INFO_LIST_1 = 
			[ F24_EXT_ID + NUMBER_01, MAX_SCORE, true, lostScoreCandidate1 ]
		F24_LOST_CAND_INFO_LIST_2 = 
			[ F24_EXT_ID + NUMBER_01, MAX_SCORE, true, lostScoreCandidate2 ]
		F24_LOST_CAND_INFO_LIST_3 = 
			[ F24_EXT_ID + NUMBER_01, MAX_SCORE, true, lostScoreCandidate3 ]
	}

	private void initAfisCandInfoList(){
		AFIS_SCORE_CANDIDATE_1 = 
			 [ [ 2, eventId, reqIndexZero, MAX_SCORE,
				[	[ MAX_SCORE, FIN_1, PC2_ROLLED, rollFW ],
					[ 7090, FIN_2, PC2_ROLLED, rollFW ],
					[ 4442, FIN_3, PC2_ROLLED, rollFW ],
					[ 5666, FIN_4, PC2_ROLLED, rollFW ],
					[ 5053, FIN_5, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_6, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_7, PC2_ROLLED, rollFW ],
					[ 6141, FIN_8, PC2_ROLLED, rollFW ],
					[ 5039, FIN_9, PC2_ROLLED, rollFW ],
					[ 7974, FIN_10, PC2_ROLLED, rollFW ] ] ] ]
	
		AFIS_SCORE_CANDIDATE_2 = 
			 [ [ 1, eventId, reqIndexZero, MAX_SCORE,
				[	[ MAX_SCORE, FIN_1, PC2_SLAP, slapFW ],
					[ 7706, FIN_2, PC2_SLAP, slapFW ],
					[ 3409, FIN_3, PC2_SLAP, slapFW ],
					[ 5795, FIN_4, PC2_SLAP, slapFW ],
					[ 4969, FIN_5, PC2_SLAP, slapFW ],
					[ MAX_SCORE, FIN_6, PC2_SLAP, slapFW ],
					[ MAX_SCORE, FIN_7, PC2_SLAP, slapFW ],
					[ 5978, FIN_8, PC2_SLAP, slapFW ],
					[ 5274, FIN_9, PC2_SLAP, slapFW ],
					[ 8028, FIN_10, PC2_SLAP, slapFW ] ] ] ]


		AFIS_SCORE_CANDIDATE_3 = 
			 [ [ 2, eventId, reqIndexOne, MAX_SCORE,
				[	[ MAX_SCORE, FIN_1, PC2_ROLLED, rollFW ],
					[ 7408, FIN_2, PC2_ROLLED, rollFW ],
					[ 4877, FIN_3, PC2_ROLLED, rollFW ],
					[ 5557, FIN_4, PC2_ROLLED, rollFW ],
					[ 6415, FIN_5, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_6, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_7, PC2_ROLLED, rollFW ],
					[ 6695, FIN_8, PC2_ROLLED, rollFW ],
					[ 5332, FIN_9, PC2_ROLLED, rollFW ],
					[ 9548, FIN_10, PC2_ROLLED, rollFW ] ] ] ]

		F28_AFIS_CAND_INFO_LIST_1 = 
			 [ F28_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F28_AFIS_CAND_INFO_LIST_2 = 
			 [ F28_EXT_ID + NUMBER_02, MAX_SCORE, true, AFIS_SCORE_CANDIDATE_1 ]
		F28_AFIS_CAND_INFO_LIST_3 = 
			 [ F28_EXT_ID + NUMBER_01, MAX_SCORE, true, AFIS_SCORE_CANDIDATE_2 ]
		F28_AFIS_CAND_INFO_LIST_4 = 
			 [ F28_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_2 ]
	}

	private void initScopeCandInfoList(){
		F29_SCOPE12_CAND_INFO_LIST_1 =
             [ F29_EXT_ID + NUMBER_03, MAX_SCORE, true, MAX_SCORE_CANDIDATE_SCOPE2_1 ]
		F29_SCOPE12_CAND_INFO_LIST_2 =
             [ F29_EXT_ID + NUMBER_04, MAX_SCORE, true, MAX_SCORE_CANDIDATE_SCOPE2_2 ]
		F29_SCOPE12_CAND_INFO_LIST_3 =
             [ F29_EXT_ID + NUMBER_04, MAX_SCORE, true, MAX_SCORE_CANDIDATE_SCOPE2_4 ]
		
		F29_SCOPE12_CAND_INFO_LIST_4 =
             [ F29_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F29_SCOPE12_CAND_INFO_LIST_5 =
             [ F29_EXT_ID + NUMBER_03, MAX_SCORE, true, MAX_SCORE_CANDIDATE_SCOPE2_1 ]
		
		F29_SCOPE12_CAND_INFO_LIST_6 =
             [ F29_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_2 ]
		F29_SCOPE12_CAND_INFO_LIST_7 =
             [ F29_EXT_ID + NUMBER_04, MAX_SCORE, true, MAX_SCORE_CANDIDATE_SCOPE2_2 ]
		F29_SCOPE12_CAND_INFO_LIST_8 =
             [ F29_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_4 ]
		
		F31_SCOPE123_CAND_INFO_LIST_1 =
             [ F31_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		F31_SCOPE123_CAND_INFO_LIST_2 =
             [ F31_EXT_ID + NUMBER_03, MAX_SCORE, true, MAX_SCORE_CANDIDATE_SCOPE2_1 ]
		
		F31_SCOPE123_CAND_INFO_LIST_3 =
             [ F31_EXT_ID + NUMBER_04, MAX_SCORE, true, MAX_SCORE_CANDIDATE_SCOPE2_2 ]
		F31_SCOPE123_CAND_INFO_LIST_4 =
             [ F31_EXT_ID + NUMBER_06, MAX_SCORE, true, MAX_SCORE_CANDIDATE_SCOPE3_2 ]
		
		F31_SCOPE123_CAND_INFO_LIST_5 =
             [ F31_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_4 ]
		F31_SCOPE123_CAND_INFO_LIST_6 =
             [ F31_EXT_ID + NUMBER_05, MAX_SCORE, true, MAX_SCORE_CANDIDATE_SCOPE3_1 ]
		F31_SCOPE123_CAND_INFO_LIST_7 =
             [ F31_EXT_ID + NUMBER_06, MAX_SCORE, true, MAX_SCORE_CANDIDATE_SCOPE3_4 ]

		F31_SCOPE123_CAND_INFO_LIST_8 =
             [ F31_EXT_ID + NUMBER_04, MAX_SCORE, true, MAX_SCORE_CANDIDATE_SCOPE2_4 ]
	}

	private void initFWeightCandInfoList(){
		F30_FW_CAND_INFO_LIST_1 = 
			[ F30_EXT_ID + NUMBER_01, 3112, true, 
				[ [ 1, eventId, reqIndexZero, 3112,
					[	[ BASIC_SCORE_5_1F, FIN_1, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_2F, FIN_2, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_5F, FIN_5, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_6F, FIN_6, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_7F, FIN_7, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_8F, FIN_8, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_9F, FIN_9, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_10F, FIN_10, PC2_ROLLED, rollFW ] ] ] ]
			]
	
		F30_FW_CAND_INFO_LIST_2 = 
			[ F30_EXT_ID + NUMBER_01, 5029, 
				[ [ 1, eventId, reqIndexZero, 3112,
                    [	[ BASIC_SCORE_5_1F, FIN_1, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_2F, FIN_2, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_5F, FIN_5, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_6F, FIN_6, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_7F, FIN_7, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_8F, FIN_8, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_9F, FIN_9, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_10F, FIN_10, PC2_ROLLED, rollFW ] ] ]  ,
				  [ 1, eventId, reqIndexOne, 1917,
					[	[ BASIC_SCORE_7_1F, FIN_1, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_2F, FIN_2, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_3, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_4F, FIN_4, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_5, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_6F, FIN_6, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_7F, FIN_7, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_8F, FIN_8, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_9, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_10F, FIN_10, PC2_SLAP, slapFW ] ] ] ]
			]

		F30_FW_CAND_INFO_LIST_3 = 
			[ F30_EXT_ID + NUMBER_01, 7238, true, 
				[ [ 1, eventId, reqIndexZero, 2596,
                    [   [ BASIC_SCORE_5_1F, FIN_1, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_5_2F, FIN_2, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_5_5F, FIN_5, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_5_6F, FIN_6, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_5_7F, FIN_7, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_5_8F, FIN_8, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_5_9F, FIN_9, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_5_10F, FIN_10, PC2_ROLLED, rollFW ] ] ]  ,
				  [ 2, eventId, reqIndexZero, 4110,
                    [   [ BASIC_SCORE_6_1F, FIN_1, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_6_6F, FIN_6, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_6_9F, FIN_9, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ]  ,
				  [ 1, eventId, reqIndexOne, 2297,
					[	[ BASIC_SCORE_7_1F, FIN_1, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_2F, FIN_2, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_3, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_4F, FIN_4, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_5, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_6F, FIN_6, PC2_SLAP, slapFW ],
						[ 74, FIN_7, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_8F, FIN_8, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_9, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_10F, FIN_10, PC2_SLAP, slapFW ] ] ]  ,
				  [ 2, eventId, reqIndexOne, 3128,
					[	[ BASIC_SCORE_8_1F, FIN_1, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_2, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_3, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_4, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_5, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_8_6F, FIN_6, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_7, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_8, PC2_SLAP, slapFW ],
						[ 152, FIN_9, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_10, PC2_SLAP, slapFW ] ] ] ]
			]
			
		F30_FW_CAND_INFO_LIST_4 = 
			[ F30_EXT_ID + NUMBER_01, 2596, true, 
				[ [ 1, eventId, reqIndexZero, 2596,
					[	[ BASIC_SCORE_5_1F, FIN_1, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_2F, FIN_2, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_5F, FIN_5, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_6F, FIN_6, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_7F, FIN_7, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_8F, FIN_8, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_9F, FIN_9, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_10F, FIN_10, PC2_ROLLED, rollFW ] ] ] ]
			]

		F30_FW_CAND_INFO_LIST_5 = 
			[ F30_EXT_ID + NUMBER_01, 4893, 
				[ [ 1, eventId, reqIndexZero, 2596,
                    [	[ BASIC_SCORE_5_1F, FIN_1, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_2F, FIN_2, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_5F, FIN_5, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_6F, FIN_6, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_7F, FIN_7, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_8F, FIN_8, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_9F, FIN_9, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_10F, FIN_10, PC2_ROLLED, rollFW ] ] ]  ,
				  [ 1, eventId, reqIndexOne, 1917,
					[	[ BASIC_SCORE_7_1F, FIN_1, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_2F, FIN_2, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_3, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_4F, FIN_4, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_5, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_6F, FIN_6, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_7F, FIN_7, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_8F, FIN_8, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_9, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_10F, FIN_10, PC2_SLAP, slapFW ] ] ] ]
			]

		F30_FW_CAND_INFO_LIST_6 = 
			[ F30_EXT_ID + NUMBER_01, 7238, true, 
				[ 
				  [ 2, eventId, reqIndexZero, 4110,
                    [   [ BASIC_SCORE_6_1F, FIN_1, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_6_6F, FIN_6, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_6_9F, FIN_9, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ]  ,
				[ 1, eventId, reqIndexZero, 2596,
                    [	[ BASIC_SCORE_5_1F, FIN_1, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_2F, FIN_2, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_5F, FIN_5, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_6F, FIN_6, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_7F, FIN_7, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_8F, FIN_8, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_9F, FIN_9, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_10F, FIN_10, PC2_ROLLED, rollFW ] ] ]  ,
				  [ 2, eventId, reqIndexOne, 3128,
					[	[ BASIC_SCORE_8_1F, FIN_1, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_2, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_3, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_4, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_5, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_8_6F, FIN_6, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_7, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_8, PC2_SLAP, slapFW ],
						[ 152, FIN_9, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_10, PC2_SLAP, slapFW ] ] ],
				  [ 1, eventId, reqIndexOne, 2297,
					[	[ BASIC_SCORE_7_1F, FIN_1, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_2F, FIN_2, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_3, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_4F, FIN_4, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_5, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_6F, FIN_6, PC2_SLAP, slapFW ],
						[ 74, FIN_7, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_8F, FIN_8, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_9, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_10F, FIN_10, PC2_SLAP, slapFW ] ] ] ]
			]
			
		F30_FW_CAND_INFO_LIST_7 = 
			[ F30_EXT_ID + NUMBER_01, 7607, true, 
				[ 
				  [ 2, eventId, reqIndexZero, 3697,
                    [   [ BASIC_SCORE_6_1F, FIN_1, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_6_6F, FIN_6, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_6_9F, FIN_9, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ]  ,
				[ 1, eventId, reqIndexZero, 2332,
                    [	[ BASIC_SCORE_5_1F, FIN_1, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_2F, FIN_2, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_5F, FIN_5, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_6F, FIN_6, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_7F, FIN_7, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_8F, FIN_8, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_9F, FIN_9, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_5_10F, FIN_10, PC2_ROLLED, rollFW ] ] ]  ,
				  [ 2, eventId, reqIndexOne, 3910,
					[	[ BASIC_SCORE_8_1F, FIN_1, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_2, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_3, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_4, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_5, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_8_6F, FIN_6, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_7, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_8, PC2_SLAP, slapFW ],
						[ 152, FIN_9, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_10, PC2_SLAP, slapFW ] ] ],
				  [ 1, eventId, reqIndexOne, 2875,
					[	[ BASIC_SCORE_7_1F, FIN_1, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_2F, FIN_2, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_3, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_4F, FIN_4, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_5, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_6F, FIN_6, PC2_SLAP, slapFW ],
						[ 74, FIN_7, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_8F, FIN_8, PC2_SLAP, slapFW ],
						[ ZERO_SCORE, FIN_9, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_7_10F, FIN_10, PC2_SLAP, slapFW ] ] ] ]
			]
			
	}
	
	private void initSortCandInfoList(){
		F33_HIGH_A_CAND_INFO_LIST = 
			[ F33_HIGH_EXT_ID + A, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
	
		F33_HIGH_B_CAND_INFO_LIST = 
			[ F33_HIGH_EXT_ID + B, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		
		F33_HIGH_C_CAND_INFO_LIST = 
			[ F33_HIGH_EXT_ID + C, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
		
		F33_LOW_A_CAND_INFO_LIST = 
			[ F33_LOW_EXT_ID + A, 2402, true, BASIC_SCORE_CANDIDATE_1 ]
	
		F33_LOW_B_CAND_INFO_LIST = 
			[ F33_LOW_EXT_ID + B, 2402, true, BASIC_SCORE_CANDIDATE_1 ]
		
		F33_LOW_C_CAND_INFO_LIST = 
			[ F33_LOW_EXT_ID + C, 2402, true, BASIC_SCORE_CANDIDATE_1 ]
	
	}

	private void initProtoAndAfisCandList(){
		F1_PROTO_7_8_CAND_INFO_LIST_1 =
			[ F25_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_2 ]

		F1_PROTO_7_8_CAND_INFO_LIST_2 =
			[ F25_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_2 ]

		F1_PROTO_9_10_CAND_INFO_LIST_1 =
			[ F25_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_2 ]

		F1_PROTO_9_10_CAND_INFO_LIST_2 =
			[ F25_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_SCOPE2_2 ]

		F1_PROTO_13_CAND_INFO_LIST_1 =
			[ F25_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_2 ]
		
		F2_DUPLICATION_2_CAND_INFO_LIST_1 =
			[ F17_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]

		F2_DUPLICATION_2_CAND_INFO_LIST_2 =
			[ F17_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_3 ]
		
		F2_DUPLICATION_2_CAND_INFO_LIST_3 =
			[ F17_EXT_ID + NUMBER_02, MAX_SCORE, true, AFIS_SCORE_CANDIDATE_1 ]
	
		F2_DUPLICATION_2_CAND_INFO_LIST_4 =
			[ F17_EXT_ID + NUMBER_02, MAX_SCORE, true, AFIS_SCORE_CANDIDATE_3 ]
	}

	private int calcFusionScore_roll_slap() {
		return calcFusionScore_roll_slap(PC2_1_R_SCORE, FMP5_1_R_SCORE)
	}

	private int calcFusionScore_roll_slap(int rollScore, int slapScore) {
		rollScore = mergeFWeight(rollScore, rollFW)
		slapScore = mergeFWeight(slapScore, slapFW)
		int fScore = rollScore + slapScore
		return cutoffScore(fScore)
	}

	public List getCandList_CardQuality_1(){
        initCandInfoLists()
        return [
               		F1_CARD_QUALITY_CAND_INFO_LIST_1,
               		F1_CARD_QUALITY_CAND_INFO_LIST_2,
               		F1_CARD_QUALITY_CAND_INFO_LIST_3
               ]
    }

	public List getCandList_CardQuality_2(){
        initCandInfoLists()
        return [
               		F1_CARD_QUALITY_CAND_INFO_LIST_1,
               		F1_CARD_QUALITY_CAND_INFO_LIST_3
               ]
    }

	public List getCandList_ApplyPattern_1(){
        initCandInfoLists()
        return [ 
					F2_APP_PATTERN_THRESHOLD_CAND_INFO_LIST_1
			   ]
	}

	public List getCandList_Pattern_1(){
        initCandInfoLists()
        return [ 
					F3_PATTERN_THRESHOLD_CAND_INFO_LIST_1
			   ]
	}

	public List getCandList_ApplyGender_1(){
        initCandInfoLists()
        return [ 
					F25_APP_GENDER_CAND_INFO_LIST_1,
					F25_APP_GENDER_CAND_INFO_LIST_2
			   ]
	}

	public List getCandList_ApplyGender_2(){
        initCandInfoLists()
        return [ 
					F25_APP_GENDER_CAND_INFO_LIST_3,
					F25_APP_GENDER_CAND_INFO_LIST_4
			   ]
	}

	public List getCandList_Gender_1(){
        initCandInfoLists()
        return [ 
					F4_GENDER_CAND_INFO_LIST_1,
					F4_GENDER_CAND_INFO_LIST_2,
					F4_GENDER_CAND_INFO_LIST_5,
					F4_GENDER_CAND_INFO_LIST_6
			   ]
	}
	
	public List getCandList_Gender_2(){
        initCandInfoLists()
        return [
					F4_GENDER_CAND_INFO_LIST_3,
                	F4_GENDER_CAND_INFO_LIST_4,
                	F4_GENDER_CAND_INFO_LIST_5,
               		F4_GENDER_CAND_INFO_LIST_6 
			   ]
	}
	
	public List getCandList_Gender_3(){
        initCandInfoLists()
        return [
					F4_GENDER_CAND_INFO_LIST_1,
					F4_GENDER_CAND_INFO_LIST_2,
					F4_GENDER_CAND_INFO_LIST_3,
                	F4_GENDER_CAND_INFO_LIST_4,
                	F4_GENDER_CAND_INFO_LIST_5,
                	F4_GENDER_CAND_INFO_LIST_6 
			   ]
	}
	
	public List getCandList_Yob_1(){
        initCandInfoLists()
        return [ 
					F26_YOB_CAND_INFO_LIST_1,
					F26_YOB_CAND_INFO_LIST_2
			   ]
	}

	public List getCandList_Yob_2(){
        initCandInfoLists()
        return [ 
					F26_YOB_CAND_INFO_LIST_3,
					F26_YOB_CAND_INFO_LIST_4
			   ]
	}

	public List getCandList_YobThreshold_1(){
        initCandInfoLists()
        return [ 
					F27_YOB_THRESHOLD_CAND_INFO_LIST_05,
					F27_YOB_THRESHOLD_CAND_INFO_LIST_06,
					F27_YOB_THRESHOLD_CAND_INFO_LIST_11,
					F27_YOB_THRESHOLD_CAND_INFO_LIST_12
			   ]
    }

	public List getCandList_YobThreshold_2(){
        initCandInfoLists()
        return [
					F27_YOB_THRESHOLD_CAND_INFO_LIST_03,
					F27_YOB_THRESHOLD_CAND_INFO_LIST_04,
					F27_YOB_THRESHOLD_CAND_INFO_LIST_05,
					F27_YOB_THRESHOLD_CAND_INFO_LIST_06,
					F27_YOB_THRESHOLD_CAND_INFO_LIST_07,
					F27_YOB_THRESHOLD_CAND_INFO_LIST_08,
					F27_YOB_THRESHOLD_CAND_INFO_LIST_11,
					F27_YOB_THRESHOLD_CAND_INFO_LIST_12
			   ]
    }

	public List getCandList_YobThreshold_3(){
        initCandInfoLists()
        return [ 
					F27_YOB_THRESHOLD_CAND_INFO_LIST_01,
					F27_YOB_THRESHOLD_CAND_INFO_LIST_02,
					F27_YOB_THRESHOLD_CAND_INFO_LIST_03,
	      		    F27_YOB_THRESHOLD_CAND_INFO_LIST_04,
					F27_YOB_THRESHOLD_CAND_INFO_LIST_05,
	       		    F27_YOB_THRESHOLD_CAND_INFO_LIST_06,
                	F27_YOB_THRESHOLD_CAND_INFO_LIST_07,
                	F27_YOB_THRESHOLD_CAND_INFO_LIST_08,
                	F27_YOB_THRESHOLD_CAND_INFO_LIST_09,
                	F27_YOB_THRESHOLD_CAND_INFO_LIST_10,
                	F27_YOB_THRESHOLD_CAND_INFO_LIST_11,
                	F27_YOB_THRESHOLD_CAND_INFO_LIST_12
			   ]
    }

	public List getCandList_ApplyYobThreshold_1(){
        initCandInfoLists()
        return [ 
					F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_01,
					F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_02,
					F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_03,
					F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_04,
					F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_05,
					F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_06,
					F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_13,
					F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_14
			   ]
    }

	public List getCandList_ApplyYobThreshold_2(){
        initCandInfoLists()
        return 	[ 
					F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_01,
					F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_02,
					F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_13,
					F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_14
				]
    }
	
	public List getCandList_ApplyYobThreshold_3(){
        initCandInfoLists()
        return [ 
					F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_01,
					F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_02,
					F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_03,
					F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_04,
					F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_05,
					F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_06,
					F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_07,
					F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_08,
					F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_09,
					F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_10,
					F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_13,
					F5_6_APP_YOB_THRESHOLD_CAND_INFO_LIST_14
			   ]
    }

	public List getCandList_Finger_1(){
		initCandInfoLists()
		return [ F7_8_FINGER_CAND_INFO_LIST_1 ]
	}

	public List getCandList_Filter_1(){
		initCandInfoLists()
		return [ F9_FILTER_CAND_INFO_LIST_1,
				 F9_FILTER_CAND_INFO_LIST_2,
				 F9_FILTER_CAND_INFO_LIST_3,
				 F9_FILTER_CAND_INFO_LIST_4 ]
	}

	public List getCandList_Filter_2(){
		initCandInfoLists()
		return [ F9_FILTER_CAND_INFO_LIST_3,
				 F9_FILTER_CAND_INFO_LIST_4 ]
	}

	public List getCandList_Filter_3(){
		initCandInfoLists()
		return [ F9_FILTER_CAND_INFO_LIST_2,
				 F9_FILTER_CAND_INFO_LIST_4 ]
	}

	public List getCandList_Filter_4(){
		initCandInfoLists()
		return [ F9_FILTER_CAND_INFO_LIST_4 ]
	}

	public List getCandList_Speed_1(){
		initCandInfoLists()
		return [ F10_11_SPEED_CAND_INFO_LIST_1 ]
	}

	public List getCandList_Rotation_1(){
		initCandInfoLists()
		return [ F12_13_ROTATION_CAND_INFO_LIST_1 ]
	}

	public List getCandList_Distortion_1(){
		initCandInfoLists()
		return [ F14_15_DISTORTION_CAND_INFO_LIST_1 ]
	}

	public List getCandList_ColdSearch_1(){
		initCandInfoLists()
        return [ F16_COLD_SEARCH_CAND_INFO_LIST_3,
				 F16_COLD_SEARCH_CAND_INFO_LIST_6,
				 F16_COLD_SEARCH_CAND_INFO_LIST_9 ]
    }
	
	public List getCandList_ColdSearch_2(){
		initCandInfoLists()
        return [	F16_COLD_SEARCH_CAND_INFO_LIST_1,
					F16_COLD_SEARCH_CAND_INFO_LIST_2,
					F16_COLD_SEARCH_CAND_INFO_LIST_3,
					F16_COLD_SEARCH_CAND_INFO_LIST_4,
					F16_COLD_SEARCH_CAND_INFO_LIST_5,
					F16_COLD_SEARCH_CAND_INFO_LIST_6,
					F16_COLD_SEARCH_CAND_INFO_LIST_7,
					F16_COLD_SEARCH_CAND_INFO_LIST_8,
					F16_COLD_SEARCH_CAND_INFO_LIST_9 ]
    }
	
	public List getCandList_RotationByAxis_1(){
		initCandInfoLists()
        return [ F34_ROT_BY_AXIS_CAND_INFO_LIST_1 ]
    }
	
	public List getCandList_TargetDb_1(){
		initCandInfoLists()
        return [ F17_TARGET_DB_CAND_INFO_LIST_1 ]
    }

	public List getCandList_TargetDb_2(){
		initCandInfoLists()
        return [ F17_TARGET_DB_CAND_INFO_LIST_2 ]
    }
		
	public List getCandList_TargetDb_3(){
		initCandInfoLists()
        return [ F17_TARGET_DB_CAND_INFO_LIST_1,
				 F17_TARGET_DB_CAND_INFO_LIST_3 ]
    }

	public List getCandList_Consolidate_1(){
		initCandInfoLists()
        return [ F18_CONSOLIDATE_CAND_INFO_LIST_1 ]
    }
	
	public List getCandList_Consolidate_2(){
		initCandInfoLists()
        return [ F18_CONSOLIDATE_CAND_INFO_LIST_2 ]
    }
	
	public List getCandList_Consolidate_3(){
		initCandInfoLists()
        return [ F18_CONSOLIDATE_CAND_INFO_LIST_3 ]
    }
	
	public List getCandList_ConsolidateScope_1(){
		initCandInfoLists()
        return [ F32_CONSOLIDATE_CAND_INFO_LIST_1 ]
    }
	
	public List getCandList_ConsolidateScope_2(){
		initCandInfoLists()
        return [ F32_CONSOLIDATE_CAND_INFO_LIST_2 ]
	}

	public List getCandList_Priority(){
		List candidate = [ F19_EXT_ID + NUMBER_01, MAX_SCORE, true, MAX_SCORE_CANDIDATE_1 ]
        return [ candidate ]
    }

	public List getCandList_Loc_1(){
		initCandInfoLists()
		
		List LocScoreCandidate = 
			[ [ 1, eventId, reqIndexZero, MAX_SCORE,
                 [   [ MAX_SCORE, FIN_1, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_6, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_9, PC2_ROLLED, rollFW ], ] ] ]
		
		for(int i = 1; i <= 5; i++){
			String num = "0000" + i
			print num
			F20_LOC_CAND_INFO_LIST_1.add([ F20_EXT_ID + num, MAX_SCORE, true, LocScoreCandidate ])
		}
		return F20_LOC_CAND_INFO_LIST_1
	}

	public List getCandList_Loc_2(){
		initCandInfoLists()
		
		List LocScoreCandidate = 
			[ [ 1, eventId, reqIndexZero, MAX_SCORE,
                 [   [ MAX_SCORE, FIN_1, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_6, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_9, PC2_ROLLED, rollFW ], ] ] ]
		
		for(int i = 1; i <= 255; i++){
			String num	
			if(i < 10){
				num = "0000" + i
			}else if(i< 100){
				num = "000" + i
			}else{
				num = "00" + i
			}
			F20_LOC_CAND_INFO_LIST_2.add([ F20_EXT_ID + num, MAX_SCORE, true, LocScoreCandidate ])
		}
		return F20_LOC_CAND_INFO_LIST_2
	}
	
	public List getCandList_Min_1(){
		initCandInfoLists()
        return [ F21_MIN_CAND_INFO_LIST_3,
        		F21_MIN_CAND_INFO_LIST_1,
				 F21_MIN_CAND_INFO_LIST_2
				  ]
    }

    public List getCandList_Min_2(){
		initCandInfoLists()
		return [ F21_MIN_CAND_INFO_LIST_3,
                 F21_MIN_CAND_INFO_LIST_1 ]
    }

    public List getCandList_Min_3(){
		initCandInfoLists()
        return [ F21_MIN_CAND_INFO_LIST_3 ]
	}

	public List getCandList_Dyn_1(){
		initCandInfoLists()
        return [ F22_DYN_CAND_INFO_LIST_3,
        		 F22_DYN_CAND_INFO_LIST_1,
				 F22_DYN_CAND_INFO_LIST_2
				  ]
    }

    public List getCandList_Dyn_2(){
		initCandInfoLists()
		return [ F22_DYN_CAND_INFO_LIST_3 ,
				F22_DYN_CAND_INFO_LIST_4,
                 F22_DYN_CAND_INFO_LIST_5
                 ]
    }

    public List getCandList_Dyn_3(){
		initCandInfoLists()
		return [ F22_DYN_CAND_INFO_LIST_3,
				F22_DYN_CAND_INFO_LIST_1,
                 F22_DYN_CAND_INFO_LIST_6
                  ]
    }
	
	public List getCandList_lost_1(){
		initCandInfoLists()
        return [ F24_LOST_CAND_INFO_LIST_1 ]
    }

	public List getCandList_lost_2(){
        initCandInfoLists()
		return [ F24_LOST_CAND_INFO_LIST_2 ]
    }

	public List getCandList_lost_3(){
		initCandInfoLists()
        return [ F24_LOST_CAND_INFO_LIST_3 ]
    }

	public List getCandList_afis_1() {
        initCandInfoLists()
        return [    F28_AFIS_CAND_INFO_LIST_1,
					F28_AFIS_CAND_INFO_LIST_2 ]
    }

	public List getCandList_afis_2() {
        initCandInfoLists()
        return [    F28_AFIS_CAND_INFO_LIST_3,
					F28_AFIS_CAND_INFO_LIST_4 ]
    }

	public List getCandList_scope12_1() {
		initCandInfoLists()
		return [	F29_SCOPE12_CAND_INFO_LIST_1 ]
	}

	public List getCandList_scope12_2() {
		initCandInfoLists()

        List candTmpList
        if(level == "high") {
		    candTmpList =
			    [ [ 1002, eventId, reqIndexZero, MAX_SCORE, MAX_INDIVIDUAL_SCORES_SLAP ]]
        }else{
		    candTmpList =
			    [ [ 1002, eventId, reqIndexZero, MAX_SCORE, MAX_INDIVIDUAL_SCORES_ROLL ]]
        }

		List candInfo = [ F29_EXT_ID + NUMBER_04, MAX_SCORE, true, candTmpList ]
		return [ candInfo ]
	}

	public List getCandList_scope12_3() {
		initCandInfoLists()
		return [	F29_SCOPE12_CAND_INFO_LIST_1,
					F29_SCOPE12_CAND_INFO_LIST_3 ]
	}

	public List getCandList_scope12_4() {
		initCandInfoLists()
		return [	F29_SCOPE12_CAND_INFO_LIST_4,
					F29_SCOPE12_CAND_INFO_LIST_5 ]
	}

	public List getCandList_scope12_5() {
		initCandInfoLists()
        if(level != "high") {
            F29_SCOPE12_CAND_INFO_LIST_6 =
                 [ F29_EXT_ID + NUMBER_02, MAX_SCORE, true, MAX_SCORE_CANDIDATE_5 ]
            F29_SCOPE12_CAND_INFO_LIST_7 =
                 [ F29_EXT_ID + NUMBER_04, MAX_SCORE, true, MAX_SCORE_CANDIDATE_SCOPE2_5 ]
        }

        return [ F29_SCOPE12_CAND_INFO_LIST_6, F29_SCOPE12_CAND_INFO_LIST_7 ]
	}
	
	public List getCandList_scope12_6() {
		initCandInfoLists()
		return [	F29_SCOPE12_CAND_INFO_LIST_1,
					F29_SCOPE12_CAND_INFO_LIST_3,
					F29_SCOPE12_CAND_INFO_LIST_4,
					F29_SCOPE12_CAND_INFO_LIST_8 ]
	}
	
	public List getCandList_scope12_7() {
		initCandInfoLists()
		return [	F29_SCOPE12_CAND_INFO_LIST_4 ]
	}
	
	public List getCandList_scope123_1() {
		initCandInfoLists()
		return [	F31_SCOPE123_CAND_INFO_LIST_1,
					F31_SCOPE123_CAND_INFO_LIST_2 ]
	}

	public List getCandList_scope123_2() {
		initCandInfoLists()
        if(level != "high") {
		    F31_SCOPE123_CAND_INFO_LIST_3 =
                [ F31_EXT_ID + NUMBER_04, MAX_SCORE, true, MAX_SCORE_CANDIDATE_SCOPE2_5 ]
		    F31_SCOPE123_CAND_INFO_LIST_4 =
                [ F31_EXT_ID + NUMBER_06, MAX_SCORE, true, MAX_SCORE_CANDIDATE_SCOPE3_5 ]
        }
		return [ F31_SCOPE123_CAND_INFO_LIST_3, F31_SCOPE123_CAND_INFO_LIST_4 ]
	}
	
	public List getCandList_scope123_3() {
		initCandInfoLists()
		return [	F31_SCOPE123_CAND_INFO_LIST_1,
					F31_SCOPE123_CAND_INFO_LIST_5,
					F31_SCOPE123_CAND_INFO_LIST_6,
					F31_SCOPE123_CAND_INFO_LIST_7 ]
	}
	public List getCandList_scope123_4() {
		initCandInfoLists()
		return [	F31_SCOPE123_CAND_INFO_LIST_1,
					F31_SCOPE123_CAND_INFO_LIST_2,
					F31_SCOPE123_CAND_INFO_LIST_5,
					F31_SCOPE123_CAND_INFO_LIST_6,
					F31_SCOPE123_CAND_INFO_LIST_7,
					F31_SCOPE123_CAND_INFO_LIST_8 ]
	}

	public List getCandList_fWeight_1_to_1(Integer rollFW, Integer slapFW) {
		this.rollFW = rollFW
		this.slapFW = slapFW
		initCandInfoLists()
		return [ F30_FW_CAND_INFO_LIST_1 ]
	}

	public List getCandList_fWeight_04_1_to_1(Integer rollFW, Integer slapFW) {
		this.rollFW = rollFW
		this.slapFW = slapFW
		initCandInfoLists()
		return [ F30_FW_CAND_INFO_LIST_4 ]
	}

	public List getCandList_fWeight_2_to_1(Integer rollFW, Integer slapFW) {
		this.rollFW = rollFW
		this.slapFW = slapFW
		initCandInfoLists()
		return [ F30_FW_CAND_INFO_LIST_2 ]
	}

	public List getCandList_fWeight_04_2_to_1(Integer rollFW, Integer slapFW) {
		this.rollFW = rollFW
		this.slapFW = slapFW
		initCandInfoLists()
		return [ F30_FW_CAND_INFO_LIST_5 ]
	}

	public List getCandList_fWeight_2_to_2(Integer rollFW, Integer slapFW) {
		this.rollFW = rollFW
		this.slapFW = slapFW
		initCandInfoLists()
		return [ F30_FW_CAND_INFO_LIST_3 ]
	}

	public List getCandList_fWeight_04_2_to_2(Integer rollFW, Integer slapFW) {
		this.rollFW = rollFW
		this.slapFW = slapFW
		initCandInfoLists()
		return [ F30_FW_CAND_INFO_LIST_6 ]
	}

	public List getCandList_fWeight_06_2_to_2(Integer rollFW, Integer slapFW) {
		this.rollFW = rollFW
		this.slapFW = slapFW
		initCandInfoLists()
		return [ F30_FW_CAND_INFO_LIST_7 ]
	}

	public List getCandList_candSort() {
		initCandInfoLists()
		return [ F33_HIGH_A_CAND_INFO_LIST, 
			     F33_HIGH_B_CAND_INFO_LIST,
				 F33_HIGH_C_CAND_INFO_LIST, 
				 F33_LOW_A_CAND_INFO_LIST, 
				 F33_LOW_B_CAND_INFO_LIST, 
				 F33_LOW_C_CAND_INFO_LIST ]
	}


	public List getCandList_protoBuff_SDBT_fingerSet1(){
        initCandInfoLists()
        return [
					F1_PROTO_7_8_CAND_INFO_LIST_1,
					F1_PROTO_7_8_CAND_INFO_LIST_2
			   ]
	}

	public List getCandList_protoBuff_SDBT_fingerSet2(){
        initCandInfoLists()
        return [
					F1_PROTO_9_10_CAND_INFO_LIST_1,
					F1_PROTO_9_10_CAND_INFO_LIST_2
			   ]
	}

	public List getCandList_protoBuff_SDBT_fingerSet3(){
        initCandInfoLists()
        return [
					F1_PROTO_13_CAND_INFO_LIST_1,
			   ]
	}

	public List getCandList_protoBuff_SDBT_fingerSet4(){
        initCandInfoLists()
        return [
					F1_PROTO_9_10_CAND_INFO_LIST_2
			   ]
	}

	public List getCandList_Duplication_TI_1(){
        initCandInfoLists()
        return [
    				F2_DUPLICATION_2_CAND_INFO_LIST_1,
					F2_DUPLICATION_2_CAND_INFO_LIST_2,
					F2_DUPLICATION_2_CAND_INFO_LIST_3,
					F2_DUPLICATION_2_CAND_INFO_LIST_4            
               ]
    }
}


