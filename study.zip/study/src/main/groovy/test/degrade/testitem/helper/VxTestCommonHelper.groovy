package test.degrade.testitem.helper

import test.degrade.util.SoapuiObject
import common.util.Convertor
import static test.common.constants.aim.AIMWord.*
import static test.common.constants.aim.AIMBioPosition.*
import static test.common.constants.data.ImageDataList.*
import static test.common.constants.aim.AIMImgType.*


class VxTestCommonHelper{

	static final String FINGER_ALGORITHM = "fingerAlgorithm"
	static final String INCORRECT_FINGER_ALGORITHM = "incorrectFingerAlgorithm"
	static final String STATUS_LIST_START = "<statusList>"
	static final String STATUS_LIST_END = "</statusList>"
	static final String CODE_START = "<code>"
	static final String CODE_END = "</code>"
	static final String DETAIL_START = "<detail>"
	static final String DETAIL_END = "</detail>"
	static final int 	DOES_NOT_EXIST_FINGER_MINUTIA_ERR_CODE = 164000017
	static final String DOES_NOT_EXIST_FINGER_MINUTIA_ERR_MSG = "Minutia of finger number(%s) does not exist."
	static final String RARGE_LIST = "rargeList"
	static final String SMALL_LIST = "smallList"
	static final String FILE_POS_LIST = "filePosList"
	static final String SEARCH_POS_LIST = "searchPosList"

	def soapuiObj
	Map posImgPathMap


	def VxTestCommonHelper(context){
		this.soapuiObj = new SoapuiObject(context)
		initPosImgPathMap()
	}

	def setFingerAlgorithmForProjectProp(){
		String currentEngine = soapuiObj.getGlobalTimEngine().toUpperCase()
		if(currentEngine == CML){
			//TODO temporary edit
			//soapuiObj.setProjectProperties(FINGER_ALGORITHM, CML)
			//soapuiObj.setProjectProperties(INCORRECT_FINGER_ALGORITHM, SATOM)
			soapuiObj.setProjectProperties(FINGER_ALGORITHM, SATOM)
			soapuiObj.setProjectProperties(INCORRECT_FINGER_ALGORITHM, CML)
		}else if(currentEngine == CMLAF){
			soapuiObj.setProjectProperties(FINGER_ALGORITHM, SATOM)
			soapuiObj.setProjectProperties(INCORRECT_FINGER_ALGORITHM, CML)
		}
	}

	def initPosImgPathMap() {
		this.posImgPathMap = new HashMap()
		String dataFilePathRoot = soapuiObj.getGlobalDataFilePath()
		posImgPathMap.put(ROLLED_RIGHT_THUMB, dataFilePathRoot + TF_043_WSQ)
		posImgPathMap.put(ROLLED_RIGHT_INDEX, dataFilePathRoot + TF_044_WSQ)
		posImgPathMap.put(ROLLED_RIGHT_MIDDLE, dataFilePathRoot + TF_045_WSQ)
		posImgPathMap.put(ROLLED_RIGHT_RING, dataFilePathRoot + TF_046_WSQ)
		posImgPathMap.put(ROLLED_RIGHT_LITTLE, dataFilePathRoot + TF_047_WSQ)
		posImgPathMap.put(ROLLED_LEFT_THUMB, dataFilePathRoot + TF_048_WSQ)
		posImgPathMap.put(ROLLED_LEFT_INDEX, dataFilePathRoot + TF_049_WSQ)
		posImgPathMap.put(ROLLED_LEFT_MIDDLE, dataFilePathRoot + TF_050_WSQ)
		posImgPathMap.put(ROLLED_LEFT_RING, dataFilePathRoot + TF_051_WSQ)
		posImgPathMap.put(ROLLED_LEFT_LITTLE, dataFilePathRoot + TF_052_WSQ)
		posImgPathMap.put(SLAP_RIGHT_THUMB, dataFilePathRoot + TF_043_WSQ)
		posImgPathMap.put(SLAP_RIGHT_INDEX, dataFilePathRoot + TF_044_WSQ)
		posImgPathMap.put(SLAP_RIGHT_MIDDLE, dataFilePathRoot + TF_045_WSQ)
		posImgPathMap.put(SLAP_RIGHT_RING, dataFilePathRoot + TF_046_WSQ)
		posImgPathMap.put(SLAP_RIGHT_LITTLE, dataFilePathRoot + TF_047_WSQ)
		posImgPathMap.put(SLAP_LEFT_THUMB, dataFilePathRoot + TF_048_WSQ)
		posImgPathMap.put(SLAP_LEFT_INDEX, dataFilePathRoot + TF_049_WSQ)
		posImgPathMap.put(SLAP_LEFT_MIDDLE, dataFilePathRoot + TF_050_WSQ)
		posImgPathMap.put(SLAP_LEFT_RING, dataFilePathRoot + TF_051_WSQ)
		posImgPathMap.put(SLAP_LEFT_LITTLE, dataFilePathRoot + TF_052_WSQ)
	}

	def initParamTestPosImgPathMap() {
		this.posImgPathMap = new HashMap()
		String dataFilePathRoot = soapuiObj.getGlobalDataFilePath()
		posImgPathMap.put(ROLLED_RIGHT_THUMB, dataFilePathRoot + LF_009_WSQ)
		posImgPathMap.put(ROLLED_RIGHT_INDEX, dataFilePathRoot + LF_009_WSQ)
		posImgPathMap.put(ROLLED_RIGHT_MIDDLE, dataFilePathRoot + LF_009_WSQ)
		posImgPathMap.put(ROLLED_RIGHT_RING, dataFilePathRoot + LF_009_WSQ)
		posImgPathMap.put(ROLLED_RIGHT_LITTLE, dataFilePathRoot + LF_009_WSQ)
		posImgPathMap.put(ROLLED_LEFT_THUMB, dataFilePathRoot + LF_009_WSQ)
		posImgPathMap.put(ROLLED_LEFT_INDEX, dataFilePathRoot + LF_009_WSQ)
		posImgPathMap.put(ROLLED_LEFT_MIDDLE, dataFilePathRoot + LF_009_WSQ)
		posImgPathMap.put(ROLLED_LEFT_RING, dataFilePathRoot + LF_009_WSQ)
		posImgPathMap.put(ROLLED_LEFT_LITTLE, dataFilePathRoot + LF_009_WSQ)
		posImgPathMap.put(SLAP_RIGHT_THUMB, dataFilePathRoot + LF_010_WSQ)
		posImgPathMap.put(SLAP_RIGHT_INDEX, dataFilePathRoot + LF_010_WSQ)
		posImgPathMap.put(SLAP_RIGHT_MIDDLE, dataFilePathRoot + LF_010_WSQ)
		posImgPathMap.put(SLAP_RIGHT_RING, dataFilePathRoot + LF_010_WSQ)
		posImgPathMap.put(SLAP_RIGHT_LITTLE, dataFilePathRoot + LF_010_WSQ)
		posImgPathMap.put(SLAP_LEFT_THUMB, dataFilePathRoot + LF_010_WSQ)
		posImgPathMap.put(SLAP_LEFT_INDEX, dataFilePathRoot + LF_010_WSQ)
		posImgPathMap.put(SLAP_LEFT_MIDDLE, dataFilePathRoot + LF_010_WSQ)
		posImgPathMap.put(SLAP_LEFT_RING, dataFilePathRoot + LF_010_WSQ)
		posImgPathMap.put(SLAP_LEFT_LITTLE, dataFilePathRoot + LF_010_WSQ)
	}

	def getDoesNotExistFingerMinutiaListList(List posList){
		List statusListList = []
		for(pos in posList){
			statusListList.add(getDoesNotExistFingerMinutia(pos))
		}
		return statusListList
	}

	def getDoesNotExistFingerMinutia(def pos){
		List statusList = []
		statusList.add(DOES_NOT_EXIST_FINGER_MINUTIA_ERR_CODE)
		statusList.add(String.format(DOES_NOT_EXIST_FINGER_MINUTIA_ERR_MSG, pos))
		return statusList
	}

	def getSamePosList(List searchPosList, List  filePosList){
		Map convPosListMap = convertPosList(searchPosList, filePosList)
		return getSameList(convPosListMap.get(SEARCH_POS_LIST), convPosListMap.get(FILE_POS_LIST))
	}

	def getDiffPosList(List searchPosList, List  filePosList){
		Map convPosListMap = convertPosList(searchPosList, filePosList)
		return getDiffList(convPosListMap.get(SEARCH_POS_LIST), convPosListMap.get(FILE_POS_LIST))
	}

	def convertPosList(List searchPosList, List filePosList){
		Map convPosListMap = new HashMap()
		List searchConvPosList = []
		List fileConvPosList = []

		for(pos in searchPosList){
			searchConvPosList.add(pos as int)
		}

		if(Integer.parseInt(searchPosList.max()) <= 10){
			for(pos in filePosList){
				fileConvPosList.add(new Convertor().convertSlapPosToRollPos(pos))
			}
		}else{
			for(pos in filePosList){
				fileConvPosList.add(new Convertor().convertRollPosToSlapPos(pos))
			}
		}

		convPosListMap.put(SEARCH_POS_LIST, searchConvPosList)
		convPosListMap.put(FILE_POS_LIST, fileConvPosList)
		return convPosListMap
	}

	def getDiffList(List listA, List listB){
		List diffList = []
		if(!listA.equals(listB)){
			Map listMap = getListMap(listA, listB)
			List rList = listMap.get(RARGE_LIST)
			List sList = listMap.get(SMALL_LIST)
			for (i in 0..rList.size() -1){
				if(sList.grep(rList[i]).size() == 0){
					diffList.add(rList[i]) 
				}
			}
		}
		return diffList
	}

	def getSameList(List listA, List listB){
		List sameList = []
		if(!listA.equals(listB)){
			Map listMap = getListMap(listA, listB)
			List rList = listMap.get(RARGE_LIST)
			List sList = listMap.get(SMALL_LIST)
			for (i in 0..rList.size() -1){
				if(sList.grep(rList[i]).size() != 0){
					sameList.add(rList[i]) 
				}
			}
		} else {
			sameList = listA
		}
		return sameList
	}

	def getListMap(List listA, List listB){
		Map listMap = new HashMap()
		if ( listA.size() < listB.size() ){
			listMap.put(RARGE_LIST, listB)
			listMap.put(SMALL_LIST, listA)
		} else {
			listMap.put(RARGE_LIST, listA)
			listMap.put(SMALL_LIST, listB)
		}
		return listMap
	}

}
