package test.degrade.testitem.helper.templates

import test.degrade.testitem.helper.*
import static test.common.constants.data.ImageDataList.*

class TlixTestTemplateCreateHelper extends TestTemplateCreateHelper{

    TlixTestTemplateCreateHelper(context){
		super(context)
    }

	public String getDefaultFileImage(){
		return imgXmlMaker.getLatentFingerImgXml(LF_001_WSQ)
	}

	public String getDefaultSearchImage(){
		return imgXmlMaker.getLatentFuncDefTenprintImgXml()
	}

	 def getPatternFileImage_1(){
        return imgXmlMaker.getLatentFingerImgXml(LF_007_WSQ)
    }

    def getPatternFileImage_2(){
        return imgXmlMaker.getLatentFingerImgXml(LF_008_WSQ)
    }

    def getPatternSearchImage(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_029_RS_NST)
    }

    def getLostFingerFileImage(){
        return imgXmlMaker.getLatentFingerImgXml(LF_016_WSQ)
    }

    def getLostFingerSearchImage_1(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_030_RS_NST)
    }
 
	def getLostFingerSearchImage_2(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_031_RS_NST)
    }

    def getLostFingerSearchImage_3(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_032_RS_NST)
    }

    def getExternalIdFileImage_1(){
        return imgXmlMaker.getLatentFingerImgXml(LF_009_WSQ)
    }

    def getExternalIdFileImage_2(){
        return imgXmlMaker.getLatentFingerImgXml(LF_010_WSQ)
    }

    def getExternalIdSearchImage(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_033_RS_NST)
    }

	def getSelectFingerFileImage_1(){
        return imgXmlMaker.getLatentFingerImgXml(LF_013_WSQ)
    }

    def getSelectFingerFileImage_2(){
        return imgXmlMaker.getLatentFingerImgXml(LF_014_WSQ)
    }

    def getSelectFingerSearchImage(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_008_RS_NST)
    }

    def getOptoinSearchImage(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_040_RS_NST)
    }
}
