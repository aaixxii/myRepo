package test.degrade.testitem.helper

import common.sql.SqlExecutor
import test.degrade.util.SoapuiObject
import test.common.util.assertion.AssertUtil
import test.common.util.db.SqlExecutorFactory
import test.degrade.management.AbendProcessor
import test.degrade.evidence.EvidenceFileOutputor
import static test.common.constants.aim.AIMWord.*

class UpdateHelper{

	private static final String DATA_SRC_NAME = "registKeys"
	private static Map extIdInfoMap
	SoapuiObject soapuiObj
	SqlExecutor sqlExecuter
	
	UpdateHelper(context){
		this.soapuiObj = new SoapuiObject(context)
		this.sqlExecuter = new SqlExecutorFactory(context).create()
	}

	public void assertDB_after(int expectedPbCnt) {
		String testPattnName = "After Update"
		assertPbCount(expectedPbCnt, testPattnName)
		assertPbRecVals(testPattnName, true)
		outputTrueEvidence(testPattnName)
	}

	public void assertDB_after_not_assert_length(int expectedPbCnt) {
		String testPattnName = "After Update"
		assertPbCount(expectedPbCnt, testPattnName)
		outputTrueEvidence(testPattnName)
	}

	public void assertDB_before(int expectedPbCnt) {
		extIdInfoMap = new HashMap()
		String testPattnName = "Before Update"
		assertPbCount(expectedPbCnt, testPattnName)
		assertPbRecVals(testPattnName, false)
		outputTrueEvidence(testPattnName)
	}

	private void outputTrueEvidence(String testPattnName) {
		def outputor = new EvidenceFileOutputor(soapuiObj.getContext())
		outputor.outputTrueMess("${testPattnName} --> Valid PERSON_BIO records")
	}

	private void assertPbRecVals(String testPattnName, boolean isAfter) {
		def expectedMap = createExpectedMap()
		String sql = "select biometrics_id, container_id, external_id, corrupted_flag, biometric_data_len from person_biometrics"
		def records = sqlExecuter.getSqlResult(sql)
		for(record in records) {
			assertEqualsPbVals(expectedMap, record, testPattnName, isAfter)
		}
	}

	private void assertEqualsPbVals(def expectedMap, def record, String testPattnName, boolean isAfter) {
		def assertUtil = new AssertUtil(soapuiObj.getContext(), testPattnName)
		def bioId = record[0] as Long
		def binId = record[1] as String
		def extId = record[2]
		def corruptedFlag = record[3]
		def dataLen = record[4]
		assertUtil.assertEquals(binId, expectedMap[extId], "external_id(binId=${binId})")
		assertUtil.assertEquals(corruptedFlag, 0, "corrupted_flag(binId=${binId}, extId=${extId})")
		if(isAfter) {
			assertDbBeforeUpdateComparing(extId, binId, bioId, dataLen, assertUtil)
		}else{
			String key = "${extId}_${binId}"
			extIdInfoMap.put(key ,  [bioId, dataLen])
		}
	}

	private void assertDbBeforeUpdateComparing(def extId, def binId, Long bioId, BigDecimal dataLen, def assertUtil){
		String key = "${extId}_${binId}"
		def actualList = extIdInfoMap[key]
		if(actualList == null) {
			new AbendProcessor(soapuiObj.getContext()).abendTest("After Update", "key='${key}'(extId,binId) is not mactch.")
			return
		}
		def beforeBioId = actualList[0]
		def beforeDataLen = actualList[1]
		assertUtil.assertTrue((beforeBioId < bioId), 
			"Comparing BIO_ID between after UPDATE and before.(after=${bioId}, before=${beforeBioId})")
		assertUtil.assertTrue((beforeDataLen != dataLen), 
			"Comparing BIO_DATA_LEN between after UPDATE and before.(after=${dataLen}, before=${beforeDataLen})")
	}

	private void assertPbCount(int expectedCnt, String testPattnName) {
		String sql = "select count(*) from person_biometrics"
		int actualCnt = sqlExecuter.getSqlResultOneRecord(sql)
		def assertUtil = new AssertUtil(soapuiObj.getContext(), testPattnName)
		assertUtil.assertEquals(actualCnt, expectedCnt, "PERSON_BIO record count")
	}

	private Map<String, String> createExpectedMap() {
		List<List> dataSrcValList = soapuiObj.createListFromDataSource(DATA_SRC_NAME)
		def expectedMap = new HashMap()
		for(dataSrcVal in dataSrcValList) {
			def binId = dataSrcVal[2]
			def extId = dataSrcVal[0]
			//expectedMap.put(binId, extId)
			expectedMap.put(extId, binId)
		}
		return expectedMap
	}

	public void _assertPbCount(int expectedCnt, String testPattnName) {
		String sql = "select count(*) from person_biometrics"
		int actualCnt = sqlExecuter.getSqlResultOneRecord(sql)
		def assertUtil = new AssertUtil(soapuiObj.getContext(), testPattnName)
		assertUtil.assertEquals(actualCnt, expectedCnt, "PERSON_BIO record count")
	}
}

