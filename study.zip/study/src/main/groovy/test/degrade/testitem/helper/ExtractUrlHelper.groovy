package test.degrade.testitem.helper

import test.degrade.util.SoapuiObject
import common.os.linux.LinuxCommander

class ExtractUrlHelper{

	protected SoapuiObject soapuiObj
	protected LinuxCommander linuxCommander
	def port 
	
	ExtractUrlHelper(context, port){
		this.soapuiObj = new SoapuiObject(context)
		this.linuxCommander = new LinuxCommander()
		this.port = port
	}

	def startFileServer(){
		String dataFilePath  = soapuiObj.getGlobalDataFilePath()
		String cmd =  "cd ${dataFilePath};python -m SimpleHTTPServer ${port}"
		String[] cmdList = [ "/bin/sh", "-c", cmd ]
		def process = Runtime.getRuntime().exec(cmdList)
	}

	def killFileServer(){
		String process
		if ( port == "" ){
			process =  "python -m SimpleHTTPServer"
		}else{
			process =  "python -m SimpleHTTPServer ${port}"
		}
		String cmd = "pkill -9 -f \"${process}\""
		println cmd
		linuxCommander.doShCommand(cmd)
	}	
}
