package test.degrade.testitem.helper.templates

import test.degrade.testitem.helper.*
import static test.common.constants.data.ImageDataList.*

class TiTestTemplateCreateHelper extends TestTemplateCreateHelper{

    TiTestTemplateCreateHelper(context){
		super(context)
    }

	def getTIDefaultImage(){
		return imgXmlMaker.getTenprintFingerImgXml(TF_001_RSP_NST)
	}

	def getTIColdSearchFileImage_1(){
		return imgXmlMaker.getTenprintFingerImgXml(TF_001_RSP_NST)
	}
	
	def getTIColdSearchFileImage_2(){
		return imgXmlMaker.getTenprintFingerImgXml(TF_002_RS_NST)
	}

	def getTIColdSearchFileImage_3(){
		return imgXmlMaker.getTenprintFingerImgXml(TF_003_RS_NST)
	}

	def getTIColdSearchFileImage_4(){
		return imgXmlMaker.getTenprintFingerImgXml(TF_004_RS_NST)
	}

	def getTIColdSearchFileImage_5(){
		return imgXmlMaker.getTenprintFingerImgXml(TF_005_RS_NST)
	}

	def getTIColdSearchSearchImage(){
		return imgXmlMaker.getTenprintFingerImgXml(TF_005_RS_NST)
	}

	def getTIScoreFileImage_1(){
		return imgXmlMaker.getTenprintFingerImgXml(TF_006_RS_NST)
	}

	def getTIScoreFileImage_2(){
		return imgXmlMaker.getTenprintFingerImgXml(TF_007_RS_NST)
	}

	def getTIScoreFileImage_3(){
		return imgXmlMaker.getTenprintFingerImgXml(TF_008_RS_NST)
	}

	def getTIScoreSearchImage(){
		return imgXmlMaker.getTenprintFingerImgXml(TF_008_RS_NST)
	}

	def getTILostFileImage(){
		return imgXmlMaker.getTenprintFingerImgXml(TF_001_RSP_NST)
	}

	def getTILostSearchImage_1(){
		return imgXmlMaker.getTenprintFingerImgXml(TF_009_R_NST)
	}

	def getTILostSearchImage_2(){
		return imgXmlMaker.getTenprintFingerImgXml(TF_010_R_NST)
	}

	def getTILostSearchImage_3(){
		return imgXmlMaker.getTenprintFingerImgXml(TF_011_R_NST)
	}
}

