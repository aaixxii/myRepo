package test.degrade.testitem.helper.templates

import test.degrade.testitem.helper.*
import static test.common.constants.data.ImageDataList.*
import static test.common.constants.aim.AIMImgType.*
import static test.common.constants.aim.AIMBioPosition.*

class TimTestTemplateCreateHelper extends TestTemplateCreateHelper{

	def posImgPathMap

    TimTestTemplateCreateHelper(context){
		super(context)
		this.posImgPathMap = new HashMap()
    }

	def getTIMDefaultImage(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_001_RSP_NST)
    }

    def getTIMColdSearchFileImage_1(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_001_RSP_NST)
    }

    def getTIMColdSearchFileImage_2(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_002_RS_NST)
    }

    def getTIMColdSearchFileImage_3(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_003_RS_NST)
   	}

    def getTIMColdSearchFileImage_4(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_004_RS_NST)
    }

    def getTIMColdSearchFileImage_5(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_005_RS_NST)
    }

	def getTIMColdSearchSearchImage(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_001_RSP_NST)
    }

	 def getTIMScoreFileImage_1(){
        return  imgXmlMaker.getTenprintFingerImgXml(TF_006_RS_NST)
    }

    def getTIMScoreFileImage_2(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_007_RS_NST)
    }

    def getTIMScoreFileImage_3(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_008_RS_NST)
    }

    def getTIMScoreSearchImage(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_008_RS_NST)
    }

    def getTIMFingerNumberFileImage(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_015_R_NST)
    }

    def getTIMFingerNumberSearchImage_1(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_015_R_NST)
    }

    def getTIMFingerNumberSearchImage_2(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_016_R_NST)
    }

    def getTIMFingerNumberSearchImage_3(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_017_R_NST)
    }

     def getTIMFingerNumberSearchImage_4(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_018_R_NST)
    }

    def getTIMFingerNumberSearchImage_5(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_019_R_NST)
    }

    def getTIMConsolidateFileImage(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_020_RS_NST)
    }

    def getTIMConsolidateSearchImage(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_021_RS_NST)
	}

	def getTIMLostFileImage_1(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_001_RSP_NST)
    }

	def getTIMLostFileImage_2(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_036_R_NST)
    }

    def getTIMLostSearchImage_1(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_009_R_NST)
    }

    def getTIMLostSearchImage_2(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_010_R_NST)
    }

    def getTIMLostSearchImage_3(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_011_R_NST)
    }

    def getTIMMateProbabilityFileImage(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_014_RS_NST)
    }

    def getTIMMateProbabilitySearchImage(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_035_RS_NST)
    }

    def getTIMFilterModeFileImage(){
        return imgXmlMaker.getTenprintFingerImgXml(TF_037_RS_NST)
    }

	def getTIMRolledWsqImage(){
		initPosImgPathMap01()
		List posList = [ ROLLED_RIGHT_THUMB, ROLLED_RIGHT_INDEX, ROLLED_RIGHT_MIDDLE, ROLLED_RIGHT_RING, ROLLED_RIGHT_LITTLE,
                         ROLLED_LEFT_THUMB, ROLLED_LEFT_INDEX, ROLLED_LEFT_MIDDLE, ROLLED_LEFT_RING, ROLLED_LEFT_LITTLE ]
		return createTenprintImg(posList)
	}

	def getTIMSlapWsqImage(){
		initPosImgPathMap02()
		List posList = [ SLAP_RIGHT_THUMB, SLAP_RIGHT_INDEX, SLAP_RIGHT_MIDDLE, SLAP_RIGHT_RING, SLAP_RIGHT_LITTLE,
                         SLAP_LEFT_THUMB, SLAP_LEFT_INDEX, SLAP_LEFT_MIDDLE, SLAP_LEFT_RING, SLAP_LEFT_LITTLE ]
		return createTenprintImg(posList)
	}

	def getTIMRolledAndSlapWsqImage(){
		initPosImgPathMap03()
        List posList = [ ROLLED_RIGHT_THUMB, ROLLED_RIGHT_INDEX, ROLLED_RIGHT_MIDDLE, ROLLED_RIGHT_RING, ROLLED_RIGHT_LITTLE,
                         ROLLED_LEFT_THUMB, ROLLED_LEFT_INDEX, ROLLED_LEFT_MIDDLE, ROLLED_LEFT_RING, ROLLED_LEFT_LITTLE,
                         SLAP_RIGHT_THUMB, SLAP_RIGHT_INDEX, SLAP_RIGHT_MIDDLE, SLAP_RIGHT_RING, SLAP_RIGHT_LITTLE,
                         SLAP_LEFT_THUMB, SLAP_LEFT_INDEX, SLAP_LEFT_MIDDLE, SLAP_LEFT_RING, SLAP_LEFT_LITTLE ]
        return createTenprintImg(posList)
    }

	

	def createTenprintImg(List posList){
        StringBuilder sb = new StringBuilder()
        for(pos in posList){
            sb.append(imgXmlMaker.getAimSimpleImgXml(posImgPathMap.get(pos), pos, TYPE_WSQ))
        }
        return sb.toString()
    }

	def initPosImgPathMap01() {
        this.posImgPathMap = new HashMap()
        posImgPathMap.put(ROLLED_RIGHT_THUMB, TF_053_WSQ)
        posImgPathMap.put(ROLLED_RIGHT_INDEX, TF_054_WSQ)
        posImgPathMap.put(ROLLED_RIGHT_MIDDLE, TF_055_WSQ)
        posImgPathMap.put(ROLLED_RIGHT_RING, TF_056_WSQ)
        posImgPathMap.put(ROLLED_RIGHT_LITTLE, TF_057_WSQ)
        posImgPathMap.put(ROLLED_LEFT_THUMB, TF_058_WSQ)
        posImgPathMap.put(ROLLED_LEFT_INDEX, TF_059_WSQ)
        posImgPathMap.put(ROLLED_LEFT_MIDDLE, TF_060_WSQ)
        posImgPathMap.put(ROLLED_LEFT_RING, TF_061_WSQ)
        posImgPathMap.put(ROLLED_LEFT_LITTLE, TF_062_WSQ)
    }

	def initPosImgPathMap02() {
        this.posImgPathMap = new HashMap()
        posImgPathMap.put(SLAP_RIGHT_THUMB, TF_063_WSQ)
        posImgPathMap.put(SLAP_RIGHT_INDEX, TF_064_WSQ)
        posImgPathMap.put(SLAP_RIGHT_MIDDLE, TF_065_WSQ)
        posImgPathMap.put(SLAP_RIGHT_RING, TF_066_WSQ)
        posImgPathMap.put(SLAP_RIGHT_LITTLE, TF_067_WSQ)
        posImgPathMap.put(SLAP_LEFT_THUMB, TF_068_WSQ)
        posImgPathMap.put(SLAP_LEFT_INDEX, TF_069_WSQ)
        posImgPathMap.put(SLAP_LEFT_MIDDLE, TF_070_WSQ)
        posImgPathMap.put(SLAP_LEFT_RING, TF_071_WSQ)
        posImgPathMap.put(SLAP_LEFT_LITTLE, TF_072_WSQ)
    }

	def initPosImgPathMap03() {
        this.posImgPathMap = new HashMap()
        posImgPathMap.put(ROLLED_RIGHT_THUMB, TF_075_WSQ)
        posImgPathMap.put(ROLLED_RIGHT_INDEX, TF_076_WSQ)
        posImgPathMap.put(ROLLED_RIGHT_MIDDLE, TF_077_WSQ)
        posImgPathMap.put(ROLLED_RIGHT_RING, TF_078_WSQ)
        posImgPathMap.put(ROLLED_RIGHT_LITTLE, TF_079_WSQ)
        posImgPathMap.put(ROLLED_LEFT_THUMB, TF_080_WSQ)
        posImgPathMap.put(ROLLED_LEFT_INDEX, TF_081_WSQ)
        posImgPathMap.put(ROLLED_LEFT_MIDDLE, TF_082_WSQ)
        posImgPathMap.put(ROLLED_LEFT_RING, TF_083_WSQ)
        posImgPathMap.put(ROLLED_LEFT_LITTLE, TF_084_WSQ)
        posImgPathMap.put(SLAP_RIGHT_THUMB, TF_075_WSQ)
        posImgPathMap.put(SLAP_RIGHT_INDEX, TF_076_WSQ)
        posImgPathMap.put(SLAP_RIGHT_MIDDLE, TF_077_WSQ)
        posImgPathMap.put(SLAP_RIGHT_RING, TF_078_WSQ)
        posImgPathMap.put(SLAP_RIGHT_LITTLE, TF_079_WSQ)
        posImgPathMap.put(SLAP_LEFT_THUMB, TF_080_WSQ)
        posImgPathMap.put(SLAP_LEFT_INDEX, TF_081_WSQ)
        posImgPathMap.put(SLAP_LEFT_MIDDLE, TF_082_WSQ)
        posImgPathMap.put(SLAP_LEFT_RING, TF_083_WSQ)
        posImgPathMap.put(SLAP_LEFT_LITTLE, TF_084_WSQ)
    }
	
}
