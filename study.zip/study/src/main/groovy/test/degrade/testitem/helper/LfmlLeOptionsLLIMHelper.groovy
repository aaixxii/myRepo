package test.degrade.testitem.helper

import static test.common.constants.aim.SearchLFMLParameter.*


class LfmlLeOptionsLLIMHelper {
    
	private static final List S_AUTO_F_AUTO_SL3_RAW_SCORE_LIST = [ 
        2560, 916, 1463, 3494, 809, 1608, 1737, 1773, 671, 2335, 2149, 1433, 1664, 868, 1567, 1235 ]
	private static final List S_AUTO_F_MANUAL_SL3_ALG_1_ROTAT_2_CORE_2_RAW_SCORE_LIST = [ 
        2331, 1612, 916, 1463, 3494, 809, 1608, 1737, 1773, 671, 1542, 1948, 2089, 335, 1434, 539]
	private static final List S_AUTO_F_MANUAL_SL3_RAW_SCORE_LIST = [ 
        898, 1612, 916, 1463, 3494, 809, 1608, 1737, 1773, 671, 1542, 1948, 2089, 335, 1434, 539]
	private static final List S_AUTO_F_MANUAL_MULTI_AXIS_A_SL3_RAW_SCORE_LIST = [ 
        1203, 1390, 1407, 1555, 1950, 1928, 2146, 1725, 2291, 804, 2598, 2398, 2237, 789, 2143, 580]
	private static final List S_AUTO_F_MANUAL_SL3_ALG_3_ROTAT_1_CORE_1_RAW_SCORE_LIST = [ 
        863, 1612, 916, 1463, 3494, 809, 1608, 1737, 1773, 671, 1542, 1948, 2089, 335, 1434, 539]
	private static final List S_AUTO_F_MANUAL_MULTI_AXIS_A_ALG_3_ROTAT_1_CORE_1_SL3_RAW_SCORE_LIST = [ 
        1765, 1390, 1407, 1555, 1950, 1928, 2146, 1725, 2291, 804, 2598, 2398, 2237, 789, 2143, 580]
    private static final List S_MANUAL_F_AUTO_SL3_ALG_3_ROTAT_1_CORE_1_RAW_SCORE_LIST = [
        1049, 1690, 1040, 1668, 3424, 794, 1533, 1796, 1806, 670, 1488, 2045, 2084, 334, 1410, 539]
	private static final List S_MANUAL_F_AUTO_MULTI_AXIS_A_ALG_3_ROTAT_1_CORE_1_SL3_RAW_SCORE_LIST = [ 
       	8326, 0, 0, 0, 69, 181, 57, 0, 0, 0, 0, 0, 0, 0, 0, 0 ]
	private static final List S_AUTO_F_MANUAL_SL3_ALG_1_ROTAT_3_CORE_1_RAW_SCORE_LIST = [ 
        0, 1612, 916, 1463, 3494, 809, 1608, 1737, 1773, 671, 1542, 1948, 2089, 335, 1434, 539]
	private static final List S_AUTO_F_MANUAL_MULTI_AXIS_A_ALG_1_ROTAT_3_CORE_1_SL3_RAW_SCORE_LIST = [ 
        1443, 1390, 1407, 1555, 1950, 1928, 2146, 1725, 2291, 804, 2598, 2398, 2237, 789, 2143, 580]
    private static final List S_MANUAL_F_AUTO_SL3_ALG_1_ROTAT_3_CORE_1_RAW_SCORE_LIST = [
        169, 1690, 1040, 1668, 3424, 794, 1533, 1796, 1806, 670, 1488, 2045, 2084, 334, 1410, 539]
	private static final List S_MANUAL_F_AUTO_MULTI_AXIS_A_ALG_1_ROTAT_3_CORE_1_SL3_RAW_SCORE_LIST = [ 
       	2306, 0, 0, 0, 69, 181, 57, 0, 0, 0, 0, 0, 0, 0, 0, 0 ]
	private static final List S_AUTO_F_MANUAL_SL3_ALG_1_ROTAT_1_CORE_4_RAW_SCORE_LIST = [ 
        2331, 1612, 916, 1463, 3494, 809, 1608, 1737, 1773, 671, 1542, 1948, 2089, 335, 1434, 539]
	private static final List S_AUTO_F_MANUAL_MULTI_AXIS_A_ALG_1_ROTAT_1_CORE_4_SL3_RAW_SCORE_LIST = [ 
        1453, 1390, 1407, 1555, 1950, 1928, 2146, 1725, 2291, 804, 2598, 2398, 2237, 789, 2143, 580]
    private static final List S_MANUAL_F_AUTO_SL3_ALG_1_ROTAT_1_CORE_4_RAW_SCORE_LIST = [
        1822, 1690, 1040, 1668, 3424, 794, 1533, 1796, 1806, 670, 1488, 2045, 2084, 334, 1410, 539]
	private static final List S_MANUAL_F_AUTO_MULTI_AXIS_A_ALG_1_ROTAT_1_CORE_4_SL3_RAW_SCORE_LIST = [ 
       	7932, 0, 0, 0, 69, 181, 57, 0, 0, 0, 0, 0, 0, 0, 0, 0 ]


    private List rawScoreList
    private List rawScoreSIndexList
    private List rawScoreFIndexList
    private int score = -1

    public void setupForLeOptions(boolean isLeMatching, boolean updateMpc, boolean isMutiAxis) {
        if(isLeMatching) {
            setupIndexListAutoManual()
            if(updateMpc) {
                rawScoreList = S_AUTO_F_MANUAL_SL3_ALG_1_ROTAT_2_CORE_2_RAW_SCORE_LIST
            }else{
				if(isMutiAxis){
                	rawScoreList = S_AUTO_F_MANUAL_MULTI_AXIS_A_SL3_RAW_SCORE_LIST
				}else{
                	rawScoreList = S_AUTO_F_MANUAL_SL3_RAW_SCORE_LIST
            	}
			}
        }else{
            setupIndexListAutoAuto()
            rawScoreList = S_AUTO_F_AUTO_SL3_RAW_SCORE_LIST
        }
    }

    public void setupForAlgorithm(boolean isSManual, boolean isFManual, boolean isMutiAxis, int algorithm) {
        if(!isSManual && isFManual) {
			setupIndexListAutoManual()
			if(isMutiAxis){
				if(algorithm == 1){
                	rawScoreList = S_AUTO_F_MANUAL_MULTI_AXIS_A_SL3_RAW_SCORE_LIST
				}else if(algorithm == 3){
                	rawScoreList = S_AUTO_F_MANUAL_MULTI_AXIS_A_ALG_3_ROTAT_1_CORE_1_SL3_RAW_SCORE_LIST
				}
			}else{
				if(algorithm == 1){
                	rawScoreList = S_AUTO_F_MANUAL_SL3_RAW_SCORE_LIST
				}else if(algorithm == 3){
                	rawScoreList = S_AUTO_F_MANUAL_SL3_ALG_3_ROTAT_1_CORE_1_RAW_SCORE_LIST
				}
			}
        }else if(isSManual && !isFManual){
			setupIndexListManualAuto()
			if(isMutiAxis){
				if(algorithm == 3){
                	rawScoreList = S_MANUAL_F_AUTO_MULTI_AXIS_A_ALG_3_ROTAT_1_CORE_1_SL3_RAW_SCORE_LIST
				}
			}else{
				if(algorithm == 3){
                	rawScoreList = S_MANUAL_F_AUTO_SL3_ALG_3_ROTAT_1_CORE_1_RAW_SCORE_LIST
				}
			}
		}
    }

    public void setupForRotationLimit(boolean isSManual, boolean isFManual, boolean isMutiAxis, int rotationLimit) {
        if(!isSManual && isFManual) {
			setupIndexListAutoManual()
			if(isMutiAxis){
				if(rotationLimit == 1){
                	rawScoreList = S_AUTO_F_MANUAL_MULTI_AXIS_A_SL3_RAW_SCORE_LIST
				}else if(rotationLimit == 3){
                	rawScoreList = S_AUTO_F_MANUAL_MULTI_AXIS_A_ALG_1_ROTAT_3_CORE_1_SL3_RAW_SCORE_LIST
				}
			}else{
				if(rotationLimit == 1){
                	rawScoreList = S_AUTO_F_MANUAL_SL3_RAW_SCORE_LIST
				}else if(rotationLimit == 3){
                	rawScoreList = S_AUTO_F_MANUAL_SL3_ALG_1_ROTAT_3_CORE_1_RAW_SCORE_LIST
				}
			}
        }else if(isSManual && !isFManual){
			setupIndexListManualAuto()
			if(isMutiAxis){
				if(rotationLimit == 3){
                	rawScoreList = S_MANUAL_F_AUTO_MULTI_AXIS_A_ALG_1_ROTAT_3_CORE_1_SL3_RAW_SCORE_LIST
				}
			}else{
				if(rotationLimit == 3){
                	rawScoreList = S_MANUAL_F_AUTO_SL3_ALG_1_ROTAT_3_CORE_1_RAW_SCORE_LIST
				}
			}
		}
    }

    public void setupForCorePosition(boolean isSManual, boolean isFManual, boolean isMutiAxis, int corePosition) {
        if(!isSManual && isFManual) {
			setupIndexListAutoManual()
			if(isMutiAxis){
				if(corePosition == 1){
                	rawScoreList = S_AUTO_F_MANUAL_MULTI_AXIS_A_SL3_RAW_SCORE_LIST
				}else if(corePosition == 2){
                	rawScoreList = S_AUTO_F_MANUAL_MULTI_AXIS_A_ALG_1_ROTAT_1_CORE_4_SL3_RAW_SCORE_LIST
				}
			}else{
				if(corePosition == 1){
                	rawScoreList = S_AUTO_F_MANUAL_SL3_RAW_SCORE_LIST
				}else if(corePosition == 2){
                	rawScoreList = S_AUTO_F_MANUAL_SL3_ALG_1_ROTAT_1_CORE_4_RAW_SCORE_LIST
				}
			}
        }else if(isSManual && !isFManual){
			setupIndexListManualAuto()
			if(isMutiAxis){
				if(corePosition == 2){
                	rawScoreList = S_MANUAL_F_AUTO_MULTI_AXIS_A_ALG_1_ROTAT_1_CORE_4_SL3_RAW_SCORE_LIST
				}
			}else{
				if(corePosition == 2){
                	rawScoreList = S_MANUAL_F_AUTO_SL3_ALG_1_ROTAT_1_CORE_4_RAW_SCORE_LIST
				}
			}
		}
    }

    private void setupIndexListAutoManual() {
        rawScoreFIndexList = S_AUTO_F_MANUAL_SL3_FILE_INDEX_LIST
        rawScoreSIndexList = S_AUTO_F_MANUAL_SL3_SEARCH_INDEX_LIST
    }

    private void setupIndexListManualAuto() {
        rawScoreFIndexList = S_MANUAL_F_AUTO_SL3_FILE_INDEX_LIST
        rawScoreSIndexList = S_MANUAL_F_AUTO_SL3_SEARCH_INDEX_LIST
    }

    private void setupIndexListAutoAuto() {
        rawScoreFIndexList = S_AUTO_F_AUTO_SL3_FILE_INDEX_LIST
        rawScoreSIndexList = S_AUTO_F_AUTO_SL3_SEARCH_INDEX_LIST
    }

    public int getScore() {
        if(score != -1) {
            return score
        }

        score = 0
        for(rScore in rawScoreList) {
            score += rScore as int
        }

		if(rawScoreList.size() != 0){
        	score /= rawScoreList.size()
		}
        return score
    }

    public List getRawScoreList() {
        return rawScoreList
    }

    public List getRawSearchIndexList() {
        return rawScoreSIndexList
    }

    public List getRawFileIndexList() {
        return rawScoreFIndexList
    }
}

