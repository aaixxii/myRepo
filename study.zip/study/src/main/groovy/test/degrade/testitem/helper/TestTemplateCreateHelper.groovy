package test.degrade.testitem.helper

import test.common.format.*
import test.degrade.properties.*
import test.degrade.evidence.*
import org.apache.commons.codec.binary.Base64
import jp.co.nec.nhm.soapui.util.NistReader
import static test.common.constants.aim.AIMWord.*
import static test.common.constants.data.ImageDataList.*

class TestTemplateCreateHelper{

	protected static final String TEMPLATES="templates/"
	protected static final String BIN=".bin"	
	protected String dataFilePathRoot
	protected NistReaderWrapper nistReaderWrapper
	protected EvidenceFileOutputor outputor
	protected TestImgXmlMaker imgXmlMaker
	protected GlobalProperties gp

    TestTemplateCreateHelper(context){
		this.gp =  new GlobalProperties(context)
        this.dataFilePathRoot = new GlobalProperties(context).getDataFilePath()
		this.nistReaderWrapper = new NistReaderWrapper(context)
		this.outputor = new EvidenceFileOutputor(context)
		this.imgXmlMaker = new TestImgXmlMaker(context)
    }

	def outputTemplate(String function, String modalIdentifierNumber, String templateKey, String testPattern, String binary){
		String dirPath 	= gp.getTimEngine().toUpperCase() + "_" + gp.getIrisEngine().toUpperCase() + 
							"/" + TEMPLATES + function
		String fileName = modalIdentifierNumber + "_" + templateKey + "_" + testPattern + BIN
		outputor.outputResultDataAsBinary(dirPath, fileName, binary)
	}	

    def outputTemplate(String function, String templateKey, String binary){
		String dirPath 	= gp.getTimEngine().toUpperCase() + "_" + gp.getIrisEngine().toUpperCase() + 
						"/" + TEMPLATES + function
        String fileName = templateKey + BIN
        outputor.outputResultDataAsBinary(dirPath, fileName, binary)
    }
}
