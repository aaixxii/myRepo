package test.degrade.testitem.helper

import test.degrade.assertion.xml.*
import test.degrade.management.AbendProcessor
import test.common.constants.aim.*
import test.degrade.testitem.holder.IrisExtractResultHolder
import test.degrade.properties.GlobalProperties
import common.util.Encoder
import static test.common.constants.data.ImageDataList.*
import static test.common.constants.aim.AIMXmlAttribute.*
import static test.common.constants.aim.AIMWord.*

class AfisScriptHelper extends PayloadHelper {

	private static final String EXT_ID_TR_FULL = "TR_Full"

    private static final int EVENT_1 = 1
    private static final int S_REQ_0 = 0
    private static final int POS_0 = 0
    private static final int POS_1 = 1
    private static final int FW_100 = 100
    private static final int FW_200 = 200

    private static final int MAX_SCORE = 9999
    private static final int ZERO_SCORE = 0
    private static final int LI_ROLL_SCORE = 739
    private static final int LI_SLAP_SCORE = 2016
    private static final int LIS_ROLL_SCORE = 554
    private static final int LIS_SLAP_SCORE = 1570
    private static final int LIM_ROLL_SCORE = 2604
    private static final int LIM_SLAP_SCORE = 2181
    private static final int LIX_SCORE = 5156
    private static final int LIP_SCORE = 2841

    private static final int LLI_SCORE = 1130
    private static final int LLIS_SCORE = 4417
    private static final int LLIM_SCORE = 1147
    private static final int LLIX_SCORE = 5547
    private static final int LLIP_SCORE = 5251

    private static final int II_R_R_SCORE = 7370
    private static final int II_R_L_SCORE = ZERO_SCORE
    private static final int II_L_R_SCORE = ZERO_SCORE
    private static final int II_L_L_SCORE = 7320
    private static final int II_F_SCORE = II_R_R_SCORE
    private static final int II_C_SCORE = II_F_SCORE
    private static final int II_I_R_SCORE = II_R_R_SCORE
    private static final int II_I_L_SCORE = II_L_L_SCORE

    private static final String TRUE = "true" 
    private static final String FALSE = "false"

    static List scopeList
    static List searchContainerList

    private String rdbtTmpl
    private String sdbtTmpl
    private String rdbtmTmpl
    private String sdbtmTmpl
    private String rdblTmpl
    private String sdblTmpl
    private String rdblsTmpl
    private String sdblsTmpl
    private String rdblmTmpl
    private String sdblmTmpl
    private String xdblTmpl
    private String pdbTmpl

    private String ldbTmpl
    private String ldbsTmpl
    private String ldbmTmpl
    private String ldbxTmpl
    private String pldbTmpl

    private String fdbTmpl
    private String idbTmpl

    private String tiRollTmpl
    private String tiSlapTmpl
    private String timRollTmpl
    private String timSlapTmpl
    private String liTmpl
    private String lisTmpl
    private String limTmpl
    private String lixTmpl
    private String lipTmpl

    private String lliTmpl
    private String llisTmpl
    private String llimTmpl
    private String llixTmpl
    private String llipTmpl

    private String fiTmpl
    private String iiTmpl
	
	private int timScoreRollFin1
	private int timScoreRollFin2
	private int timScoreRollFin3
	private int timScoreRollFin4
	private int timScoreRollFin5
	private int timScoreRollFin6
	private int timScoreRollFin7
	private int timScoreRollFin8
	private int timScoreRollFin9
	private int timScoreRollFin10

	private int timScoreSlapFin1
	private int timScoreSlapFin2
	private int timScoreSlapFin3
	private int timScoreSlapFin4
	private int timScoreSlapFin5
	private int timScoreSlapFin6
	private int timScoreSlapFin7
	private int timScoreSlapFin8
	private int timScoreSlapFin9
	private int timScoreSlapFin10


    AfisScriptHelper(context) {
        super(context)
        loadFileTmplPath()
        loadSearchTmplPath()
		initTimScore(context)
    }

    // Override
    protected void initPayloadMap() {
    }
	
	private void initTimScore(def context){
        String timEngine = new GlobalProperties(context).getTimEngine().toUpperCase()
		if(timEngine == CML){
			timScoreRollFin1 = MAX_SCORE
			timScoreRollFin2 = MAX_SCORE
            timScoreRollFin3 = ZERO_SCORE
            timScoreRollFin4 = MAX_SCORE
            timScoreRollFin5 = MAX_SCORE
            timScoreRollFin6 = MAX_SCORE
            timScoreRollFin7 = ZERO_SCORE
            timScoreRollFin8 = MAX_SCORE
            timScoreRollFin9 = ZERO_SCORE
            timScoreRollFin10 = ZERO_SCORE
			timScoreSlapFin1 = MAX_SCORE
			timScoreSlapFin2 = ZERO_SCORE
            timScoreSlapFin3 = MAX_SCORE
            timScoreSlapFin4 = MAX_SCORE
            timScoreSlapFin5 = ZERO_SCORE
            timScoreSlapFin6 = MAX_SCORE
            timScoreSlapFin7 = ZERO_SCORE
            timScoreSlapFin8 = MAX_SCORE
            timScoreSlapFin9 = MAX_SCORE
            timScoreSlapFin10 = ZERO_SCORE
		}else if(timEngine == CMLAF){
			timScoreRollFin1 = MAX_SCORE
			timScoreRollFin2 = MAX_SCORE
            timScoreRollFin3 = MAX_SCORE
            timScoreRollFin4 = MAX_SCORE
            timScoreRollFin5 = MAX_SCORE
            timScoreRollFin6 = MAX_SCORE
            timScoreRollFin7 = MAX_SCORE
            timScoreRollFin8 = MAX_SCORE
            timScoreRollFin9 = MAX_SCORE
            timScoreRollFin10 = MAX_SCORE
			timScoreSlapFin1 = MAX_SCORE
			timScoreSlapFin2 = MAX_SCORE
            timScoreSlapFin3 = MAX_SCORE
            timScoreSlapFin4 = MAX_SCORE
            timScoreSlapFin5 = MAX_SCORE
            timScoreSlapFin6 = MAX_SCORE
            timScoreSlapFin7 = MAX_SCORE
            timScoreSlapFin8 = MAX_SCORE
            timScoreSlapFin9 = MAX_SCORE
            timScoreSlapFin10 = MAX_SCORE
		}else{
			assert false, "Invalid TIM engine value '${timEngine}'."
		}
	}

    private void loadFileTmplPath() {
        String dataRootPath = soapuiObj.getGlobalDataFilePath()
        String tempDirName = soapuiObj.getGlobalTempDirName()
        this.rdbtTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/TI/TF001_RDBT_default.bin"
        this.sdbtTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/TI/TF001_SDBT_default.bin"
        this.rdbtmTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/TIM/TF001_RDBTM_default.bin"
        this.sdbtmTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/TIM/TF001_SDBTM_default.bin"
        this.rdblTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/LI/TF022-024_RDBL_1_default.bin"
        this.sdblTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/LI/TF022-024_SDBL_1_default.bin"
        this.rdblsTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/LIS/TF022-024_RDBLS_1_default.bin"
        this.sdblsTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/LIS/TF022-024_SDBLS_1_default.bin"
        this.rdblmTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/LIM/TF027_RDBLM_1_default.bin"
        this.sdblmTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/LIM/TF027_SDBLM_1_default.bin"
        this.xdblTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/LIX/TF022-024_XDBL_default.bin"
        this.pdbTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/LIP_PC3R/TP001_PDB_PalmOption.bin"

        this.ldbTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/LLI/LF009_LDB_default.bin"
        this.ldbsTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/LLIS/LF009_LDB_S_default.bin"
        this.ldbmTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/LLIM/LF009_LDBM_default.bin"
        this.ldbxTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/LLIX/LF009_LDBX_default.bin"
        this.pldbTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/LLIP_PC3R/LP004_PLDB_PalmOption.bin"

        this.fdbTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/FI_S17/F001_FDB_1_default.bin"
        this.idbTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/II/I001_002_IDB_default.bin"
    }

    private void loadSearchTmplPath() {
        String dataRootPath = soapuiObj.getGlobalDataFilePath()
        String tempDirName = soapuiObj.getGlobalTempDirName()
        this.tiRollTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/TI/TF001_TI_ROLLED_default.bin"
        this.tiSlapTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/TI/TF001_TI_SLAP_default.bin"
        this.timRollTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/TIM/TF001_TIM_ROLLED_default.bin"
        this.timSlapTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/TIM/TF001_TIM_SLAP_default.bin"
        this.liTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/LI/LF001_LI_default.bin"
        this.lisTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/LIS/LF001_LI_S_default.bin"
        this.limTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/LIM/LF005_LIM_default.bin"
        this.lixTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/LIX/LF001_LIX_default.bin"
        this.lipTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/LIP_PC3R/LP001_LIP_PalmOption.bin"
        this.llipTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/LLIP_PC3R/LP003_LLIP_PalmOption.bin"
        
        this.fiTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/FI/F001_FI_1_default.bin"
        this.iiTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/II/I003_004_II_default.bin"

        this.lliTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/LLI/LF010_LLI_default.bin"
        this.llisTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/LLIS/LF010_LLI_S_default.bin"
        this.llimTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/LLIM/LF010_LLIM_default.bin"
        this.llixTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/LLIX/LF010_LLIX_default.bin"
        this.llipTmpl = "${dataRootPath}/degradeTest/template/${tempDirName}/LLIP_PC3R/LP003_LLIP_PalmOption.bin"
    }

    public String makeTRFingerPalmDataXml() {
        StringBuilder sb = new StringBuilder()
        sb.append(makeTrTemplateXml(rdbtTmpl, AIMWord.RDBT, "Roll"))
        sb.append(makeTrTemplateXml(sdbtTmpl, AIMWord.SDBT, "Slap"))
        sb.append(makeTrTemplateXml(rdbtmTmpl, AIMWord.RDBTM, "Roll"))
        sb.append(makeTrTemplateXml(sdbtmTmpl, AIMWord.SDBTM, "Slap"))
        sb.append(makeTrTemplateXml(rdblTmpl, "RDBL_1", "Roll"))
        sb.append(makeTrTemplateXml(sdblTmpl, "SDBL_1", "Slap"))
        sb.append(makeTrTemplateXml(rdblsTmpl, "RDBLS_1", "Roll"))
        sb.append(makeTrTemplateXml(sdblsTmpl, "SDBLS_1", "Slap"))
        sb.append(makeTrTemplateXml(rdblmTmpl, "RDBLM_1", "Roll"))
        sb.append(makeTrTemplateXml(sdblmTmpl, "SDBLM_1", "Slap"))
        sb.append(makeTrTemplateXml(xdblTmpl, "XDBL", null))
        sb.append(makeTrTemplateXml(pdbTmpl, "PDB_1", null))
        return sb.toString()
    }

    public String makeFdbDataXml() {
        return makeTrTemplateXml(fdbTmpl, "FDB_1", null)
    }

    public String makeIdbDataXml() {
        return makeTrTemplateXml(idbTmpl, "IDB", null)
    }

    public String makeLdbDataXml() {
        return makeTrTemplateXml(ldbTmpl, "LR", null)
    }

    public String makePldbDataXml() {
        return makeTrTemplateXml(pldbTmpl, "LRP", null)
    }

    public String makeLdbxDataXml() {
        return makeTrTemplateXml(ldbxTmpl, "LRX", null)
    }

    public String makeInsertTenprintFaceIrisDataXml() {
        StringBuilder sb = new StringBuilder()
        sb.append(makeInsertTRDataXml())

        sb.append(makeInsertTemplateXml(ldbTmpl, AIMWord.LDB_ID as int))
        sb.append(makeInsertTemplateXml(ldbsTmpl, AIMWord.LDBS_ID as int))
        sb.append(makeInsertTemplateXml(ldbmTmpl, AIMWord.LDBM_ID as int))
        sb.append(makeInsertTemplateXml(ldbxTmpl, AIMWord.LDBX_ID as int))
        sb.append(makeInsertTemplateXml(pldbTmpl, AIMWord.PLDB_ID as int))

        sb.append(makeInsertTemplateXml(fdbTmpl, AIMWord.FDB_ID as int))
        sb.append(makeInsertIRDataXml())
        return sb.toString()
    }

    public String makeInsertTRDataXml() {
        StringBuilder sb = new StringBuilder()
        sb.append(makeInsertTemplateXml(rdbtTmpl, AIMWord.RDBT_ID as int))
        sb.append(makeInsertTemplateXml(sdbtTmpl, AIMWord.SDBT_ID as int))
        sb.append(makeInsertTemplateXml(rdbtmTmpl, AIMWord.RDBTM_ID as int))
        sb.append(makeInsertTemplateXml(sdbtmTmpl, AIMWord.SDBTM_ID as int))
        sb.append(makeInsertTemplateXml(rdblTmpl, AIMWord.RDBL_ID as int))
        sb.append(makeInsertTemplateXml(sdblTmpl, AIMWord.SDBL_ID as int))
        sb.append(makeInsertTemplateXml(rdblsTmpl, AIMWord.RDBLS_ID as int))
        sb.append(makeInsertTemplateXml(sdblsTmpl, AIMWord.SDBLS_ID as int))
        sb.append(makeInsertTemplateXml(rdblmTmpl, AIMWord.RDBLM_ID as int))
        sb.append(makeInsertTemplateXml(sdblmTmpl, AIMWord.SDBLM_ID as int))
        sb.append(makeInsertTemplateXml(xdblTmpl, AIMWord.XDBL_ID as int))
        sb.append(makeInsertTemplateXml(pdbTmpl, AIMWord.PDB_ID as int))
        return sb.toString()
    }

    public String makeInsertIRDataXml() {
        StringBuilder sb = new StringBuilder()
        sb.append(makeInsertTemplateXml(idbTmpl, AIMWord.IDB_ID as int))
        return sb.toString()
    }

    public String readSearchTmplateAsB64(int id) {
        switch(id) {
            case 1:
                return Encoder.binaryToB64(tiRollTmpl)
            case 2:
                return Encoder.binaryToB64(tiSlapTmpl)
            case 3:
                return Encoder.binaryToB64(timRollTmpl)
            case 4:
                return Encoder.binaryToB64(timSlapTmpl)
            case 5:
            case 6:
                return Encoder.binaryToB64(liTmpl)
            case 7:
            case 8:
                return Encoder.binaryToB64(lisTmpl)
            case 9:
            case 10:
                return Encoder.binaryToB64(limTmpl)
            case 11:
                return Encoder.binaryToB64(lixTmpl)
            case 12:
                return Encoder.binaryToB64(lipTmpl)
            default:
                abendTest(id)
        }
    }

    public String readSearchTmplateAsB64_all(int id) {
        if(id <= 12) {
            return readSearchTmplateAsB64(id)
        }

        switch(id) {
            case 13:
                return Encoder.binaryToB64(lliTmpl)
            case 14:
                return Encoder.binaryToB64(llisTmpl)
            case 15:
                return Encoder.binaryToB64(llimTmpl)
            case 16:
                return Encoder.binaryToB64(llixTmpl)
            case 17:
                return Encoder.binaryToB64(llipTmpl)
            case 18:
                return Encoder.binaryToB64(fiTmpl)
            case 19:
                return Encoder.binaryToB64(iiTmpl)
            case 20:
                return Encoder.binaryToB64(iiTmpl)
            default:
                abendTest(id)
        }
    }

    public int getExpectedReadCnt_TRFull(int id) {
        if(1 <= id && id <= 10) {
            return 1
        }else if(id == 11){
            return 20
        }else if(id == 12){
            return 1
        }else{
            abendTest(id)
        }
    }

    public int getExpectedReadCnt_InsertFull(int id) {
        if(id <= 12) {
            return getExpectedReadCnt_TRFull(id)
        }else if(13 <= id && id <= 20){
            return 1
        }else{
            abendTest()
        }
    }

    public int getExpectedMatchCnt_InsertFull(int id) {
        return getExpectedReadCnt_InsertFull(id)
    }

    public int getExpectedMatchCnt_TRFull(int id) {
        return getExpectedReadCnt_TRFull(id)
    }

    public List getCandList_IiKeyRef(String extId) {
		List candInfo = new IiHelper(soapuiObj.getContext()).makeMaxScoreCand(extId)
		return [ candInfo ]
	}

    public List getCandList_IiKeyRef(String extId, String isCrossMatch) {
		List candInfo = new IiHelper(soapuiObj.getContext()).makeMaxScoreCand(extId, isCrossMatch)
		return [ candInfo ]
	}

    public List getCandList_TRFull(int id) {
        switch(id) {
            case 1:
                return [ getTiCand(1) ]
            case 2:
                return [ getTiCand(2) ]
            case 3:
                return [ getTimRollCand(331) ]
            case 4:
                return [ getTimSlapCand(332) ]
            case 5:
                return [ getLiCand(LI_ROLL_SCORE, 3) ]
            case 6:
                return [ getLiCand(LI_SLAP_SCORE, 4) ]
            case 7:
                return [ getLisCand(LIS_ROLL_SCORE, 323) ]
            case 8:
                return [ getLisCand(LIS_SLAP_SCORE, 324) ]
            case 9:
                return [ getLimCand(LIM_ROLL_SCORE, 333) ]
            case 10:
                return [ getLimCand(LIM_SLAP_SCORE, 334) ]
            case 11:
                return [ getLixCand() ]
            case 12:
                return [ getLipCand() ]
            default:
                abendTest(id)
        }
    }

    public List getCandList_InsertFull(int id) {
        if(id <= 12) {
            return getCandList_TRFull(id)
        }

        switch(id) {
            case 13:
                return [ getLiCand(LLI_SCORE, 321) ]
            case 14:
                return [ getLlisCand(LLIS_SCORE, 326) ]
            case 15:
                return [ getLimCand(LLIM_SCORE, 336) ]
            case 16:
                return [ getLlixCand() ]
            case 17:
                return [ getLlipCand() ]
            case 18:
                return [ getFiCand() ]
            case 19:
                return [ getIiCand() ]
            case 20:
                return [ getIiCand(FALSE) ]
            default:
                abendTest(id)
        }
    }

    public XpathMapper getExpectedXpathMapper_TRFull(int id) {
        switch(id) {
            case 1:
            case 2:
            case 3:
            case 4:
                return new TiSearchXpathMapper(soapuiObj.getContext())
            case 5:
            case 6:
            case 7:
            case 8:
                return new FinSearchXpathMapper(soapuiObj.getContext())
            case 9:
            case 10:
                return new LfmlSearchXpathMapper()
            case 11:
                return new XsearchXpathMapper()
            case 12:
                return new PalmSearchXpathMapper()
            default:
                abendTest(id)
        }
    }
        
    public XpathMapper getExpectedXpathMapper_InsertFull(int id) {
        if(id <= 12) {
            return getExpectedXpathMapper_TRFull(id)
        }

        switch(id) {
            case 13:
                return new FinSearchXpathMapper(soapuiObj.getContext())
            case 14:
                return new FinSearchXpathMapper(soapuiObj.getContext())
            case 15:
                return new LfmlSearchXpathMapper()
            case 16:
                return new XsearchXpathMapper()
            case 17:
                return new PalmSearchXpathMapper()
            case 18:
                return new FaceSearchXpathMapper()
            case 19:
            case 20:
                return new IrisSearchXpathMapper()
            default:
                abendTest(id)
        }
    }

    private makeTrTemplateXml(String templPath, String key, String finSet) {
        StringBuilder sb = new StringBuilder()
        sb.append("<template>\n")
        sb.append("<key>${key}</key>\n")
        sb.append("<metadata>\n")
        if(finSet != null && !finSet.isEmpty()) {
            sb.append("<fingerSet>${finSet}</fingerSet>\n")
        }
        sb.append("</metadata>\n")
        sb.append("<binary>")
        sb.append(Encoder.binaryToB64(templPath))
        sb.append("</binary>\n")
        sb.append("</template>\n")
        return sb.toString()
    }
        
    private makeInsertTemplateXml(String templPath, int conId) {
        StringBuilder sb = new StringBuilder()
        sb.append("<reqs destinationContainer='${conId}'>\n")
        sb.append("<record>\n")
        sb.append("<binary>")
        sb.append(Encoder.binaryToB64(templPath))
        sb.append("</binary>\n")
        sb.append("</record>\n")
        sb.append("</reqs>\n")
        return sb.toString()
    }

    public String makePayload() {
        return ""
    }

    private void abendTest(int id){
        new AbendProcessor(soapuiObj.getContext()).abendTest("Unexpected id value '${id}'.")
    }

    private getTiCand(int conId) {
        return [ EXT_ID_TR_FULL, MAX_SCORE, true, getTiCandTmpl(conId) ]
    }

    private getTimRollCand(int conId) {
        return [ EXT_ID_TR_FULL, MAX_SCORE, true, getTimRollCandTmpl(conId) ]
    }

    private getTimSlapCand(int conId) {
        return [ EXT_ID_TR_FULL, MAX_SCORE, true, getTimSlapCandTmpl(conId) ]
    }

    private getLiCand(int score, int conId) {
        return [ EXT_ID_TR_FULL, score, true, getLiCandTmpl(score, conId) ]
    }

    private getLisCand(int score, int conId) {
        return [ EXT_ID_TR_FULL, score*2, true, getLisCandTmpl(score, conId) ]
    }

    private getLlisCand(int score, int conId) {
        return [ EXT_ID_TR_FULL, score, true, getLlisCandTmpl(score, conId) ]
    }

    private getLimCand(int score, int conId) {
        return [ EXT_ID_TR_FULL, score, true, getLimCandTmpl(score, conId) ]
    }

    private List getLiCandTmpl(int score, int conId) {
		return [ [ conId, EVENT_1, S_REQ_0, score,
                 [   [ score, FIN_1, A, FMP5_LATENT, FW_100 ], ] ] ]
    }

    private List getLisCandTmpl(int score, int conId) {
		return [ [ conId, EVENT_1, S_REQ_0, score*2,
                 [   [ score, FIN_1, A, PC2_LATENT, FW_200 ], ] ] ]
    }

    private List getLlisCandTmpl(int score, int conId) {
		return [ [ conId, EVENT_1, S_REQ_0, score,
                 [   [ score, FIN_1, A, PC2_LATENT, FW_100 ], ] ] ]
    }

    private List getLimCandTmpl(int score, int conId) {
		return [ [ conId, EVENT_1, S_REQ_0, score,
                 [   [ score, FIN_1, PC2_LATENT, FW_100 ], ] ] ]
    }

    private List getTiCandTmpl(int conId) {
		return [ [ conId, EVENT_1, S_REQ_0, MAX_SCORE,
                 [   [ MAX_SCORE, FIN_1, PC2_ROLLED, FW_100 ],
                     [ MAX_SCORE, FIN_2, PC2_ROLLED, FW_100 ],
                     [ MAX_SCORE, FIN_3, PC2_ROLLED, FW_100 ],
                     [ MAX_SCORE, FIN_4, PC2_ROLLED, FW_100 ],
                     [ MAX_SCORE, FIN_5, PC2_ROLLED, FW_100 ],
                     [ MAX_SCORE, FIN_6, PC2_ROLLED, FW_100 ],
                     [ MAX_SCORE, FIN_7, PC2_ROLLED, FW_100 ],
                     [ MAX_SCORE, FIN_8, PC2_ROLLED, FW_100 ],
                     [ MAX_SCORE, FIN_9, PC2_ROLLED, FW_100 ],
                     [ MAX_SCORE, FIN_10, PC2_ROLLED, FW_100 ], ] ] ]
    }

    private List getTimRollCandTmpl(int conId) {
		return [ [ conId, EVENT_1, S_REQ_0, MAX_SCORE,
                 [   [ timScoreRollFin1, FIN_1, PC2_ROLLED, FW_100 ],
                     [ timScoreRollFin2, FIN_2, PC2_ROLLED, FW_100 ],
                     [ timScoreRollFin3, FIN_3, PC2_ROLLED, FW_100 ],
                     [ timScoreRollFin4, FIN_4, PC2_ROLLED, FW_100 ],
                     [ timScoreRollFin5, FIN_5, PC2_ROLLED, FW_100 ],
                     [ timScoreRollFin6, FIN_6, PC2_ROLLED, FW_100 ],
                     [ timScoreRollFin7, FIN_7, PC2_ROLLED, FW_100 ],
                     [ timScoreRollFin8, FIN_8, PC2_ROLLED, FW_100 ],
                     [ timScoreRollFin9, FIN_9, PC2_ROLLED, FW_100 ],
                     [ timScoreRollFin10, FIN_10, PC2_ROLLED, FW_100 ], ] ] ]
    }

    private List getTimSlapCandTmpl(int conId) {
		return [ [ conId, EVENT_1, S_REQ_0, MAX_SCORE,
                 [   [ timScoreSlapFin1, FIN_1, PC2_ROLLED, FW_100 ],
                     [ timScoreSlapFin2, FIN_2, PC2_ROLLED, FW_100 ],
                     [ timScoreSlapFin3, FIN_3, PC2_ROLLED, FW_100 ],
                     [ timScoreSlapFin4, FIN_4, PC2_ROLLED, FW_100 ],
                     [ timScoreSlapFin5, FIN_5, PC2_ROLLED, FW_100 ],
                     [ timScoreSlapFin6, FIN_6, PC2_ROLLED, FW_100 ],
                     [ timScoreSlapFin7, FIN_7, PC2_ROLLED, FW_100 ],
                     [ timScoreSlapFin8, FIN_8, PC2_ROLLED, FW_100 ],
                     [ timScoreSlapFin9, FIN_9, PC2_ROLLED, FW_100 ],
                     [ timScoreSlapFin10, FIN_10, PC2_ROLLED, FW_100 ], ] ] ]
    }

    private List getLixCand() {
        return [ EXT_ID_TR_FULL, LIX_SCORE, true,
				[ [ 341, EVENT_1, S_REQ_0, LIX_SCORE,
					[ [ LIS_ROLL_SCORE, FIN_1, A , PC2_ROLLED, FW_200 ], 
					  [ LIS_SLAP_SCORE, FIN_1, A , PC2_SLAP, FW_200 ], 
					  [ LI_ROLL_SCORE, FIN_1, A , FMP5_ROLLED, FW_100 ], 
					  [ LI_SLAP_SCORE, FIN_1, A , FMP5_SLAP, FW_100 ] ] 
				] ]
            ]
    }

    private List getLlixCand() {
        return [ EXT_ID_TR_FULL, LLIX_SCORE, true,
				[ [ 342, EVENT_1, S_REQ_0, LLIX_SCORE,
					[ [ LLIS_SCORE, FIN_1, A , PC2_LATENT, FW_100 ], 
					  [ LLI_SCORE, FIN_1, A , FMP5_LATENT, FW_100 ] ] 
				] ]
            ]
    }

    private List getLipCand() {
        return [ EXT_ID_TR_FULL, LIP_SCORE, true,
				[ [ 5, EVENT_1, S_REQ_0, LIP_SCORE,
					[ [ LIP_SCORE, FIN_3 ] ]
				] ]
            ]
    }

    private List getLlipCand() {
        return [ EXT_ID_TR_FULL, LLIP_SCORE, true,
				[ [ 322, EVENT_1, S_REQ_0, LLIP_SCORE,
					[ [ LLIP_SCORE, POS_0 ] ]
				] ]
            ]
    }

    private List getFiCand() {
        return [ EXT_ID_TR_FULL, MAX_SCORE, true,
				[ [ 335, EVENT_1, S_REQ_0, MAX_SCORE,
					[ [ MAX_SCORE ] ]
				] ]
            ]
    }

    private List getIiCand() {
		return new IrisExtractHelper(
			soapuiObj.getContext()).makeDefaultScoreCand(EXT_ID_TR_FULL)
    }

    private List getIiCand( String isCrossMatch) {
		return new IrisExtractHelper(
			soapuiObj.getContext()).makeDefaultScoreCand(EXT_ID_TR_FULL, isCrossMatch)
    }
}

