package test.degrade.testitem.helper

import common.util.Encoder

class ExtractManualLFMLHelper {
	

	private static final String INPUT_MINUTIA_DBTYPE_RDBLM_TYPE_BT5  =  "<input-minutia dbType=\"RDBLM\" minutiaType=\"BT5\"> \n"
	private static final String INPUT_MINUTIA_TAIL  =  "</input-minutia> \n"
	private static final String INPUT_MINUTIA_DATA_HEAD  =  "<input-minutia-data pos='%s'> \n"
	private static final String INPUT_MINUTIA_DATA_TAIL  =  "</input-minutia-data> \n"
	private static final String MINUTIA_DATA_HEAD =  "<minutia-data>"
	private static final String MINUTIA_DATA_TAIL =  "</minutia-data> \n"
	
	private static final String MINUTIA_TYPE_BT5  =  "<minutia minutiaType=\"BT5\"> \n"
	private static final String MINUTIA_END =  "</minutia> \n"
	private static final String DATA_HEAD =  "<data>"
	private static final String DATA_TAIL =  "</data> \n"
	private static final String MARK_UP_HEAD =  "<mark-up> \n"
	private static final String MARK_UP_TAIL =  "</mark-up> \n"
	
	public ExtractManualLFMLHelper(){
	}

	public static String readTenprintBT5(HashMap bt5MinitiaPathMap){
		String head = INPUT_MINUTIA_DBTYPE_RDBLM_TYPE_BT5
		for(bt5MinitiaPath in bt5MinitiaPathMap){
			String b64 = Encoder.binaryToB64(bt5MinitiaPath.getValue())
			String impMinutiaData = String.format(INPUT_MINUTIA_DATA_HEAD, bt5MinitiaPath.getKey())
			head += impMinutiaData + MINUTIA_DATA_HEAD + b64 + MINUTIA_DATA_TAIL + INPUT_MINUTIA_DATA_TAIL
		}
		return head + INPUT_MINUTIA_TAIL
	}

	public static String readTenprintBT5(def pos, String bt5MinitiaPath){
		String head = INPUT_MINUTIA_DBTYPE_RDBLM_TYPE_BT5
		String b64 = Encoder.binaryToB64(bt5MinitiaPath)
		String impMinutiaData = String.format(INPUT_MINUTIA_DATA_HEAD, pos)
		head += impMinutiaData + MINUTIA_DATA_HEAD + b64 + MINUTIA_DATA_TAIL + INPUT_MINUTIA_DATA_TAIL
		return head + INPUT_MINUTIA_TAIL
	}

	public static String readLatentBT5(String bt5MinitiaPath){
		String b64 = Encoder.binaryToB64(bt5MinitiaPath)
		return MINUTIA_TYPE_BT5 +  DATA_HEAD + b64 + DATA_TAIL + MINUTIA_END
	}

	public static String readMarkUp(String markUpDataPath){
		String b64 = Encoder.binaryToB64(markUpDataPath)
		return MARK_UP_HEAD +  DATA_HEAD + b64 + DATA_TAIL + MARK_UP_TAIL
	}
}

