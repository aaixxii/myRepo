package test.degrade.testitem.helper

import static test.common.constants.aim.AIMXmlAttribute.*

class LimHelper extends ConsolidationHelper {

	private static final String DEF_EXT_ID = "default"
	private static final String LFML_EXT_ID = "LFMLOptions"
	
	private static final String GEN_M_EXT_ID = "M"
	private static final String GEN_F_EXT_ID = "F"
	private static final String GEN_U_EXT_ID = "U"

	private static final String YOB_1_EXT_ID = "1979_-1"
	private static final String YOB_2_EXT_ID = "1979_0"
	private static final String YOB_3_EXT_ID = "1979_1"
	private static final String YOB_4_EXT_ID = "1979_5"
	private static final String YOB_5_EXT_ID = "1979_9"
	private static final String YOB_6_EXT_ID = "1973_0"
	private static final String YOB_7_EXT_ID = "1974_0"
	private static final String YOB_8_EXT_ID = "1984_0"
	private static final String YOB_9_EXT_ID = "1985_0"
	private static final String YOB_10_EXT_ID = "1974_5"
	private static final String YOB_11_EXT_ID = "1984_5"
	private static final String YOB_12_EXT_ID = "-1_0"
	
	private static final String PATTERN_EXT_ID = "pattern"
	private static final String PATTERN_A_EXT_ID = "A"
	private static final String PATTERN_W_EXT_ID = "W"
	private static final String PATTERN_L_EXT_ID = "L"
	private static final String PATTERN_R_EXT_ID = "R"
	private static final String PATTERN_S_EXT_ID = "S"
	private static final String PATTERN_AW_EXT_ID = "AW"
	private static final String PATTERN_AL_EXT_ID = "AL"
	private static final String PATTERN_AR_EXT_ID = "AR"
	private static final String PATTERN_WL_EXT_ID = "WL"
	private static final String PATTERN_WR_EXT_ID = "WR"
	private static final String PATTERN_LR_EXT_ID = "LR"
	private static final String PATTERN_LRA_EXT_ID = "LRA"
	private static final String PATTERN_AWR_EXT_ID = "AWR"
	private static final String PATTERN_WLR_EXT_ID = "WLR"
	private static final String PATTERN_AWL_EXT_ID = "AWL"
	private static final String PATTERN_AWLR_EXT_ID = "AWLR"
	
	private static final String FIN_NO_EXT_ID = "fingerNo"
	private static final String FIN_NO_0_EXT_ID = "0"
	private static final String FIN_NO_1_EXT_ID = "1"
	private static final String FIN_NO_2_EXT_ID = "2"
	private static final String FIN_NO_3_EXT_ID = "3"
	private static final String FIN_NO_4_EXT_ID = "4"
	private static final String FIN_NO_5_EXT_ID = "5"
	private static final String FIN_NO_6_EXT_ID = "6"
	private static final String FIN_NO_7_EXT_ID = "7"
	private static final String FIN_NO_8_EXT_ID = "8"
	private static final String FIN_NO_9_EXT_ID = "9"
	private static final String FIN_NO_012_EXT_ID = "012"
	private static final String FIN_NO_234_EXT_ID = "234"
	private static final String FIN_NO_456_EXT_ID = "456"
	
	private static final String ADJ_EXT_ID = "adjacentPattern"
	
	private static final String RACE_1_EXT_ID = "1"
	private static final String RACE_2_EXT_ID = "2"
	private static final String RACE_4_EXT_ID = "4"
	private static final String RACE_8_EXT_ID = "8"
	private static final String RACE_M1_EXT_ID = "-1"
	
	private static final String REGION_1_EXT_ID = "1"
	private static final String REGION_9_EXT_ID = "9"
	private static final String REGION_F_EXT_ID = "F"
	private static final String REGION_U_EXT_ID = "U"
	
	private static final String COLD_1_EXT_ID = "M_1960"
	private static final String COLD_2_EXT_ID = "M_1970"
	private static final String COLD_3_EXT_ID = "M_1980"
	private static final String COLD_4_EXT_ID = "F_1960"
	private static final String COLD_5_EXT_ID = "F_1970"
	private static final String COLD_6_EXT_ID = "F_1980"
	private static final String COLD_7_EXT_ID = "U_1960"
	private static final String COLD_8_EXT_ID = "U_1970"
	private static final String COLD_9_EXT_ID = "U_1980"
	
	private static final String SCOPE_1_EXT_ID = "1"
	private static final String SCOPE_2_EXT_ID = "2"
	private static final String SCOPE_3_EXT_ID = "3"
	private static final String SCOPE_6_EXT_ID = "6"
	
	private static final String EXT_ID_TEST_A_EXT_ID = "A"
	private static final String EXT_ID_TEST_B_EXT_ID = "B"
	private static final String EXT_ID_TEST_C_EXT_ID = "C"
	private static final String EXT_ID_TEST_D_EXT_ID = "D"
	private static final String EXT_ID_TEST_E_EXT_ID = "E"
	private static final String EXT_ID_TEST_F_EXT_ID = "F"
	
	private static final String MULTI_AXIS_1_EXT_ID = "1"
	private static final String MULTI_AXIS_2_EXT_ID = "2"
	
	private static final int R_BASE_SCORE = 2604
	private static final int S_BASE_SCORE = 2181
	private static final int FULL_SCORE = 9999
	private static final int OPTION_SCORE_1 = 641
	private static final int OPTION_SCORE_2 = 1064
	private static final int OPTION_SCORE_3 = 1083
	private static final int OPTION_SCORE_4 = 1015
	private static final int ADJ_S_SCORE_1 = 3319
	private static final int ADJ_S_SCORE_2 = 5078
	private static final int MULTI_AXIS_1_A_SCORE = 9999
	private static final int MULTI_AXIS_1_B_SCORE = 5180
	private static final int MULTI_AXIS_1_C_SCORE = 4231
	private static final int MULTI_AXIS_1_D_SCORE = 9999
	private static final int MULTI_AXIS_2_A_SCORE = 2652
	private static final int MULTI_AXIS_2_B_SCORE = 2272
	private static final int MULTI_AXIS_2_C_SCORE = 2730
	private static final int MULTI_AXIS_2_D_SCORE = 9435
	private static final int EXT_ID_SCORE = 6598
    private static final int SEARCH_LEVEL_SCORE_1 = 2935
    private static final int SEARCH_LEVEL_SCORE_2 = 2898
    private static final int SEARCH_LEVEL_SCORE_3 = 2898
    private static final int ROTATION_LIMIT_SCORE_1 = 2930
    private static final int ROTATION_LIMIT_SCORE_2 = 2908
    private static final int ROTATION_LIMIT_SCORE_3 = 2908
    private static final int SPEED_LEVEL_SCORE_1 = 2909
    private static final int SPEED_LEVEL_SCORE_2 = 2890
    private static final int SPEED_LEVEL_SCORE_3 = 1436
    private static final int SPEED_LEVEL_SECOND_SCORE_1 = 2909
    private static final int SPEED_LEVEL_SECOND_SCORE_2 = 2894
    private static final int SPEED_LEVEL_SECOND_SCORE_3 = 2914
    private static final int DISTORTION_LEVEL_SCORE_1 = 2892
    private static final int DISTORTION_LEVEL_SCORE_2 = 2849
    private static final int DISTORTION_LEVEL_SCORE_3 = 2906
    private static final int DISTORTION_LEVEL_SECOND_SCORE_1 = 2965
    private static final int DISTORTION_LEVEL_SECOND_SCORE_2 = 2706
	
	private static final int SCOPE_1_BIN_ID_1 = 333
	private static final int SCOPE_2_BIN_ID_1 = SCOPE_1_BIN_ID_1 + 1000
	private static final int SCOPE_3_BIN_ID_1 = SCOPE_1_BIN_ID_1 + 2000
	private static final int SCOPE_6_BIN_ID_1 = SCOPE_1_BIN_ID_1 + 5000
	private static final int SCOPE_1_BIN_ID_2 = 334
	private static final int SCOPE_2_BIN_ID_2 = SCOPE_1_BIN_ID_2 + 1000
	private static final int SCOPE_3_BIN_ID_2 = SCOPE_1_BIN_ID_2 + 2000

	private int rfW200Score
	private int sfW200Score
	private Integer fW100 = 100
	private Integer fW200 = 200
	private Integer fmp5FW = 100
    private Integer pc2FW = 200
	private int reqIndex = 0

	private List DEF_R_CAND_INFO_LIST = []
	private List DEF_S_CAND_INFO_LIST = []
	private List DEF_RS_CAND_INFO_LIST = []
	private List DEF_RS_MULTI_SCOPE_CAND_INFO_LIST = []	

	private List OPTION_CAND_INFO_LIST_1 = []
	private List OPTION_CAND_INFO_LIST_2 = []
	private List OPTION_CAND_INFO_LIST_3 = []
	private List OPTION_CAND_INFO_LIST_4 = []
	
    private List SEARCH_LEVEL_SCORE_CAND_INFO_LIST_1 = []
    private List SEARCH_LEVEL_SCORE_CAND_INFO_LIST_2 = []
    private List SEARCH_LEVEL_SCORE_CAND_INFO_LIST_3 = []
    private List ROTATION_LIMIT_SCORE_CAND_INFO_LIST_1 = []
    private List ROTATION_LIMIT_SCORE_CAND_INFO_LIST_2 = []
    private List ROTATION_LIMIT_SCORE_CAND_INFO_LIST_3 = []
    private List SPEED_LEVEL_SCORE_CAND_INFO_LIST_1 = []
    private List SPEED_LEVEL_SCORE_CAND_INFO_LIST_2 = []
    private List SPEED_LEVEL_SCORE_CAND_INFO_LIST_3 = []
    private List SPEED_LEVEL_SECOND_SCORE_CAND_INFO_LIST_1 = []
    private List SPEED_LEVEL_SECOND_SCORE_CAND_INFO_LIST_2 = []
    private List SPEED_LEVEL_SECOND_SCORE_CAND_INFO_LIST_3 = []
    private List DISTORTION_LEVEL_SCORE_CAND_INFO_LIST_1 = []
    private List DISTORTION_LEVEL_SCORE_CAND_INFO_LIST_2 = []
    private List DISTORTION_LEVEL_SCORE_CAND_INFO_LIST_3 = []
    private List DISTORTION_LEVEL_SECOND_SCORE_CAND_INFO_LIST_1 = []
    private List DISTORTION_LEVEL_SECOND_SCORE_CAND_INFO_LIST_2 = []

	private List GEN_M_CAND_INFO_LIST = []
	private List GEN_F_CAND_INFO_LIST = []
	private List GEN_U_CAND_INFO_LIST = []

	private List YOB_1_CAND_INFO_LIST = []
	private List YOB_2_CAND_INFO_LIST = []
	private List YOB_3_CAND_INFO_LIST = []
	private List YOB_4_CAND_INFO_LIST = []
	private List YOB_5_CAND_INFO_LIST = []
	private List YOB_6_CAND_INFO_LIST = []
	private List YOB_7_CAND_INFO_LIST = []
	private List YOB_8_CAND_INFO_LIST = []
	private List YOB_9_CAND_INFO_LIST = []
	private List YOB_10_CAND_INFO_LIST = []
	private List YOB_11_CAND_INFO_LIST = []
	private List YOB_12_CAND_INFO_LIST = []
	
	private List PATTERN_CAND_INFO_LIST = []
	private List PATTERN_A_CAND_INFO_LIST = []
	private List PATTERN_W_CAND_INFO_LIST = []
	private List PATTERN_L_CAND_INFO_LIST = []
	private List PATTERN_R_CAND_INFO_LIST = []
	private List PATTERN_S_CAND_INFO_LIST = []
	private List PATTERN_AW_CAND_INFO_LIST = []
	private List PATTERN_AL_CAND_INFO_LIST = []
	private List PATTERN_AR_CAND_INFO_LIST = []
	private List PATTERN_WL_CAND_INFO_LIST = []
	private List PATTERN_WR_CAND_INFO_LIST = []
	private List PATTERN_LR_CAND_INFO_LIST = []
	private List PATTERN_LRA_CAND_INFO_LIST = []
	private List PATTERN_AWR_CAND_INFO_LIST = []
	private List PATTERN_WLR_CAND_INFO_LIST = []
	private List PATTERN_AWL_CAND_INFO_LIST = []
	private List PATTERN_AWLR_CAND_INFO_LIST = []
	
	private List FIN_NO_0_CAND_INFO_LIST = []
	private List FIN_NO_1_CAND_INFO_LIST = []
	private List FIN_NO_2_CAND_INFO_LIST = []
	private List FIN_NO_3_CAND_INFO_LIST = []
	private List FIN_NO_4_CAND_INFO_LIST = []
	private List FIN_NO_5_CAND_INFO_LIST = []
	private List FIN_NO_6_CAND_INFO_LIST = []
	private List FIN_NO_7_CAND_INFO_LIST = []
	private List FIN_NO_8_CAND_INFO_LIST = []
	private List FIN_NO_9_CAND_INFO_LIST = []
	private List FIN_NO_012_CAND_INFO_LIST = []
	private List FIN_NO_234_CAND_INFO_LIST = []
	private List FIN_NO_456_CAND_INFO_LIST = []
	
	private List ADJ_1_CAND_INFO_LIST = []
	private List ADJ_2_CAND_INFO_LIST = []
	private List ADJ_3_CAND_INFO_LIST = []
	
	private List RACE_1_CAND_INFO_LIST = []
	private List RACE_2_CAND_INFO_LIST = []
	private List RACE_4_CAND_INFO_LIST = []
	private List RACE_8_CAND_INFO_LIST = []
	private List RACE_M1_CAND_INFO_LIST = []
	
	private List REGION_1_CAND_INFO_LIST = []
	private List REGION_9_CAND_INFO_LIST = []
	private List REGION_F_CAND_INFO_LIST = []
	private List REGION_U_CAND_INFO_LIST = []
	
	private List COLD_1_CAND_INFO_LIST = []
	private List COLD_2_CAND_INFO_LIST = []
	private List COLD_3_CAND_INFO_LIST = []
	private List COLD_4_CAND_INFO_LIST = []
	private List COLD_5_CAND_INFO_LIST = []
	private List COLD_6_CAND_INFO_LIST = []
	private List COLD_7_CAND_INFO_LIST = []
	private List COLD_8_CAND_INFO_LIST = []
	private List COLD_9_CAND_INFO_LIST = []
	
	private List SCOPE_1_CAND_INFO_LIST = []
	private List SCOPE_2_CAND_INFO_LIST = []
	private List SCOPE_3_CAND_INFO_LIST = []
	private List SCOPE_1_R_CAND_INFO_LIST = []
	private List SCOPE_2_R_CAND_INFO_LIST = []
	private List SCOPE_3_R_CAND_INFO_LIST = []
	private List SCOPE_6_R_CAND_INFO_LIST = []
	private List SCOPE_1_S_CAND_INFO_LIST = []
	private List SCOPE_2_S_CAND_INFO_LIST = []
	private List SCOPE_3_S_CAND_INFO_LIST = []
	
	private List FW_100_CAND_INFO_LIST = []
	private List FW_120_CAND_INFO_LIST = []
	
	private List EXT_ID_TEST_A_CAND_INFO_LIST = []
	private List EXT_ID_TEST_B_CAND_INFO_LIST = []
	private List EXT_ID_TEST_C_CAND_INFO_LIST = []
	private List EXT_ID_TEST_D_CAND_INFO_LIST = []
	private List EXT_ID_TEST_E_CAND_INFO_LIST = []
	private List EXT_ID_TEST_F_CAND_INFO_LIST = []
	
	private List MULTI_AXIS_1_A_CAND_INFO_LIST = []
	private List MULTI_AXIS_1_B_CAND_INFO_LIST_1 = []
	private List MULTI_AXIS_1_B_CAND_INFO_LIST_2 = []
	private List MULTI_AXIS_1_C_CAND_INFO_LIST_1 = []
	private List MULTI_AXIS_1_C_CAND_INFO_LIST_2 = []
	private List MULTI_AXIS_1_D_CAND_INFO_LIST = []
	private List MULTI_AXIS_2_A_CAND_INFO_LIST = []
	private List MULTI_AXIS_2_B_CAND_INFO_LIST = []
	private List MULTI_AXIS_2_C_CAND_INFO_LIST = []
	private List MULTI_AXIS_2_D_CAND_INFO_LIST = []

	LimHelper(context){
		super(context)
		initCandInfoLists()
	}

	LimHelper(context, String level){
		super(context)
		setNullFwIfHighLevel(level)
		initCandInfoLists()
	}

	private void initCandInfoLists() {
		initScores()
		initDefaultCandInfoList()
		initGenderCandInfoList()
		initYobCandInfoList()
		initPatternCandInfoList()
		initFingerNoCandInfoList()
		initAdjacentCandInfoList()
		initRaceCandInfoList()
		initRegionCandInfoList()
		initColdCandInfoList()
		initScopeCandInfoList()
		initFusionWeightCandInfoList()
		initExternalIdCandInfoList()
		initMultiAxisCandInfoList()
		initOptionCandInfoList()
		initLfmlOptionCandInfoList()
	}

	private void initScores() {
		rfW200Score = mergeFWeight(R_BASE_SCORE, fW200)
		sfW200Score = mergeFWeight(S_BASE_SCORE, fW200)
	}

    private void initLfmlOptionCandInfoList(){
        SEARCH_LEVEL_SCORE_CAND_INFO_LIST_1 =
            [ LFML_EXT_ID, SEARCH_LEVEL_SCORE_1, true,
                [ [ SCOPE_1_BIN_ID_1, 1, reqIndex, SEARCH_LEVEL_SCORE_1,
                    [ [ SEARCH_LEVEL_SCORE_1, FIN_1,  PC2_LATENT, 100 ] ] ] ]
            ]

        SEARCH_LEVEL_SCORE_CAND_INFO_LIST_2 =
            [ LFML_EXT_ID, SEARCH_LEVEL_SCORE_2, true,
                [ [ SCOPE_1_BIN_ID_1, 1, reqIndex, SEARCH_LEVEL_SCORE_2,
                    [ [ SEARCH_LEVEL_SCORE_2, FIN_1,  PC2_LATENT, 100 ] ] ] ]
            ]

        SEARCH_LEVEL_SCORE_CAND_INFO_LIST_3 =
            [ LFML_EXT_ID, SEARCH_LEVEL_SCORE_3, true,
                [ [ SCOPE_1_BIN_ID_1, 1, reqIndex, SEARCH_LEVEL_SCORE_3,
                    [ [ SEARCH_LEVEL_SCORE_3, FIN_1,  PC2_LATENT, 100 ] ] ] ]
            ]

        ROTATION_LIMIT_SCORE_CAND_INFO_LIST_1 =
            [ LFML_EXT_ID, ROTATION_LIMIT_SCORE_1, true,
                [ [ SCOPE_1_BIN_ID_1, 1, reqIndex, ROTATION_LIMIT_SCORE_1,
                    [ [ ROTATION_LIMIT_SCORE_1, FIN_1,  PC2_LATENT, 100 ] ] ] ]
            ]

        ROTATION_LIMIT_SCORE_CAND_INFO_LIST_2 =
            [ LFML_EXT_ID, ROTATION_LIMIT_SCORE_2, true,
                [ [ SCOPE_1_BIN_ID_1, 1, reqIndex, ROTATION_LIMIT_SCORE_2,
                    [ [ ROTATION_LIMIT_SCORE_2, FIN_1,  PC2_LATENT, 100 ] ] ] ]
            ]

        ROTATION_LIMIT_SCORE_CAND_INFO_LIST_3 =
            [ LFML_EXT_ID, ROTATION_LIMIT_SCORE_3, true,
                [ [ SCOPE_1_BIN_ID_1, 1, reqIndex, ROTATION_LIMIT_SCORE_3,
                    [ [ ROTATION_LIMIT_SCORE_3, FIN_1,  PC2_LATENT, 100 ] ] ] ]
            ]

        SPEED_LEVEL_SCORE_CAND_INFO_LIST_1 =
            [ LFML_EXT_ID, SPEED_LEVEL_SCORE_1, true,
                [ [ SCOPE_1_BIN_ID_1, 1, reqIndex, SPEED_LEVEL_SCORE_1,
                    [ [ SPEED_LEVEL_SCORE_1, FIN_1,  PC2_LATENT, 100 ] ] ] ]
            ]

        SPEED_LEVEL_SCORE_CAND_INFO_LIST_2 =
            [ LFML_EXT_ID, SPEED_LEVEL_SCORE_2, true,
                [ [ SCOPE_1_BIN_ID_1, 1, reqIndex, SPEED_LEVEL_SCORE_2,
                    [ [ SPEED_LEVEL_SCORE_2, FIN_1,  PC2_LATENT, 100 ] ] ] ]
            ]

        SPEED_LEVEL_SCORE_CAND_INFO_LIST_3 =
            [ LFML_EXT_ID, SPEED_LEVEL_SCORE_3, true,
                [ [ SCOPE_1_BIN_ID_1, 1, reqIndex, SPEED_LEVEL_SCORE_3,
                    [ [ SPEED_LEVEL_SCORE_3, FIN_1,  PC2_LATENT, 100 ] ] ] ]
            ]

        SPEED_LEVEL_SECOND_SCORE_CAND_INFO_LIST_1 =
            [ LFML_EXT_ID, SPEED_LEVEL_SECOND_SCORE_1, true,
                [ [ SCOPE_1_BIN_ID_1, 1, reqIndex, SPEED_LEVEL_SECOND_SCORE_1,
                    [ [ SPEED_LEVEL_SECOND_SCORE_1, FIN_1,  PC2_LATENT, 100 ] ] ] ]
            ]

        SPEED_LEVEL_SECOND_SCORE_CAND_INFO_LIST_2 =
            [ LFML_EXT_ID, SPEED_LEVEL_SECOND_SCORE_2, true,
                [ [ SCOPE_1_BIN_ID_1, 1, reqIndex, SPEED_LEVEL_SECOND_SCORE_2,
                    [ [ SPEED_LEVEL_SECOND_SCORE_2, FIN_1,  PC2_LATENT, 100 ] ] ] ]
            ]

        SPEED_LEVEL_SECOND_SCORE_CAND_INFO_LIST_3 =
            [ LFML_EXT_ID, SPEED_LEVEL_SECOND_SCORE_3, true,
                [ [ SCOPE_1_BIN_ID_1, 1, reqIndex, SPEED_LEVEL_SECOND_SCORE_3,
                    [ [ SPEED_LEVEL_SECOND_SCORE_3, FIN_1,  PC2_LATENT, 100 ] ] ] ]
            ]

        DISTORTION_LEVEL_SCORE_CAND_INFO_LIST_1 =
            [ LFML_EXT_ID, DISTORTION_LEVEL_SCORE_1, true,
                [ [ SCOPE_1_BIN_ID_1, 1, reqIndex, DISTORTION_LEVEL_SCORE_1,
                    [ [ DISTORTION_LEVEL_SCORE_1, FIN_1,  PC2_LATENT, 100 ] ] ] ]
            ]

        DISTORTION_LEVEL_SCORE_CAND_INFO_LIST_2 =
            [ LFML_EXT_ID, DISTORTION_LEVEL_SCORE_2, true,
                [ [ SCOPE_1_BIN_ID_1, 1, reqIndex, DISTORTION_LEVEL_SCORE_2,
                    [ [ DISTORTION_LEVEL_SCORE_2, FIN_1,  PC2_LATENT, 100 ] ] ] ]
            ]

        DISTORTION_LEVEL_SCORE_CAND_INFO_LIST_3 =
            [ LFML_EXT_ID, DISTORTION_LEVEL_SCORE_3, true,
                [ [ SCOPE_1_BIN_ID_1, 1, reqIndex, DISTORTION_LEVEL_SCORE_3,
                    [ [ DISTORTION_LEVEL_SCORE_3, FIN_1,  PC2_LATENT, 100 ] ] ] ]
            ]

        DISTORTION_LEVEL_SECOND_SCORE_CAND_INFO_LIST_1 =
            [ LFML_EXT_ID, DISTORTION_LEVEL_SECOND_SCORE_1, true,
                [ [ SCOPE_1_BIN_ID_1, 1, reqIndex, DISTORTION_LEVEL_SECOND_SCORE_1,
                    [ [ DISTORTION_LEVEL_SECOND_SCORE_1, FIN_1,  PC2_LATENT, 100 ] ] ] ]
            ]

        DISTORTION_LEVEL_SECOND_SCORE_CAND_INFO_LIST_2 =
            [ LFML_EXT_ID, DISTORTION_LEVEL_SECOND_SCORE_2, true,
                [ [ SCOPE_1_BIN_ID_1, 1, reqIndex, DISTORTION_LEVEL_SECOND_SCORE_2,
                    [ [ DISTORTION_LEVEL_SECOND_SCORE_2, FIN_1,  PC2_LATENT, 100 ] ] ] ]
            ]

    }

	private void initDefaultCandInfoList(){
		DEF_R_CAND_INFO_LIST = 
			[ DEF_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]

		DEF_S_CAND_INFO_LIST = 
			[ DEF_EXT_ID, S_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_2, 1, reqIndex, S_BASE_SCORE,
					[ [ S_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]

		DEF_RS_CAND_INFO_LIST = 
			[ DEF_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ,
				 [ SCOPE_1_BIN_ID_2, 1, reqIndex, S_BASE_SCORE,
					[ [ S_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]

		DEF_RS_MULTI_SCOPE_CAND_INFO_LIST = 
			[ DEF_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ,
				 [ SCOPE_1_BIN_ID_2, 1, reqIndex, S_BASE_SCORE,
					[ [ S_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ,
				 [ SCOPE_2_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ,
				 [ SCOPE_2_BIN_ID_2, 1, reqIndex, S_BASE_SCORE,
					[ [ S_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]

	}

	private void initOptionCandInfoList(){
		OPTION_CAND_INFO_LIST_1 =
			[ DEF_EXT_ID, OPTION_SCORE_1, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, OPTION_SCORE_1,
					[ [ OPTION_SCORE_1, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
		
		OPTION_CAND_INFO_LIST_2 =
			[ DEF_EXT_ID, OPTION_SCORE_2, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, OPTION_SCORE_2,
					[ [ OPTION_SCORE_2, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
		
		OPTION_CAND_INFO_LIST_3 =
			[ DEF_EXT_ID, OPTION_SCORE_3, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, OPTION_SCORE_3,
					[ [ OPTION_SCORE_3, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]

		OPTION_CAND_INFO_LIST_4 =
			[ DEF_EXT_ID, OPTION_SCORE_4, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, OPTION_SCORE_4,
					[ [ OPTION_SCORE_4, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	}

	private void initGenderCandInfoList(){
		GEN_M_CAND_INFO_LIST =
			[ GEN_M_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
		
		GEN_F_CAND_INFO_LIST =
			[ GEN_F_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100] ] ] ]
			]
		
		GEN_U_CAND_INFO_LIST =
			[ GEN_U_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	}

	private void initYobCandInfoList(){
		YOB_1_CAND_INFO_LIST =
			[ YOB_1_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		YOB_2_CAND_INFO_LIST =
			[ YOB_2_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		YOB_3_CAND_INFO_LIST =
			[ YOB_3_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		YOB_4_CAND_INFO_LIST =
			[ YOB_4_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		YOB_5_CAND_INFO_LIST =
			[ YOB_5_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		YOB_6_CAND_INFO_LIST =
			[ YOB_6_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		YOB_7_CAND_INFO_LIST =
			[ YOB_7_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		YOB_8_CAND_INFO_LIST =
			[ YOB_8_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		YOB_9_CAND_INFO_LIST =
			[ YOB_9_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		YOB_10_CAND_INFO_LIST =
			[ YOB_10_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		YOB_11_CAND_INFO_LIST =
			[ YOB_11_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		YOB_12_CAND_INFO_LIST =
			[ YOB_12_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	}
	
	private void initPatternCandInfoList(){
		PATTERN_CAND_INFO_LIST =
			[ PATTERN_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_6,  PC2_LATENT, 100 ] ] ] ]
			]
	
		PATTERN_A_CAND_INFO_LIST =
			[ PATTERN_A_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]

		PATTERN_W_CAND_INFO_LIST =
			[ PATTERN_W_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		PATTERN_L_CAND_INFO_LIST =
			[ PATTERN_L_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		PATTERN_R_CAND_INFO_LIST =
			[ PATTERN_R_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]

		PATTERN_S_CAND_INFO_LIST =
			[ PATTERN_S_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		PATTERN_AW_CAND_INFO_LIST =
			[ PATTERN_AW_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		PATTERN_AL_CAND_INFO_LIST =
			[ PATTERN_AL_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		PATTERN_AR_CAND_INFO_LIST =
			[ PATTERN_AR_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		PATTERN_WL_CAND_INFO_LIST =
			[ PATTERN_WL_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]

		PATTERN_WR_CAND_INFO_LIST =
			[ PATTERN_WR_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]

		PATTERN_LR_CAND_INFO_LIST =
			[ PATTERN_LR_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		PATTERN_LRA_CAND_INFO_LIST =
			[ PATTERN_LRA_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		PATTERN_AWR_CAND_INFO_LIST =
			[ PATTERN_AWR_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		PATTERN_WLR_CAND_INFO_LIST =
			[ PATTERN_WLR_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		PATTERN_AWL_CAND_INFO_LIST =
			[ PATTERN_AWL_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
		
		PATTERN_AWLR_CAND_INFO_LIST =
			[ PATTERN_AWLR_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	}

	private void initFingerNoCandInfoList(){
		FIN_NO_0_CAND_INFO_LIST =
			[ FIN_NO_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		FIN_NO_1_CAND_INFO_LIST =
			[ FIN_NO_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_2,  PC2_LATENT, 100 ] ] ] ]
			]
	
		FIN_NO_2_CAND_INFO_LIST =
			[ FIN_NO_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_3,  PC2_LATENT, 100 ] ] ] ]
			]
	
		FIN_NO_3_CAND_INFO_LIST =
			[ FIN_NO_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_4,  PC2_LATENT, 100 ] ] ] ]
			]

		FIN_NO_4_CAND_INFO_LIST =
			[ FIN_NO_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_5,  PC2_LATENT, 100 ] ] ] ]
			]
	
		FIN_NO_5_CAND_INFO_LIST =
			[ FIN_NO_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_6,  PC2_LATENT, 100 ] ] ] ]
			]
	
		FIN_NO_6_CAND_INFO_LIST =
			[ FIN_NO_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_7,  PC2_LATENT, 100 ] ] ] ]
			]
	
		FIN_NO_7_CAND_INFO_LIST =
			[ FIN_NO_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_8,  PC2_LATENT, 100 ] ] ] ]
			]
	
		FIN_NO_8_CAND_INFO_LIST =
			[ FIN_NO_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_9,  PC2_LATENT, 100 ] ] ] ]
			]

		FIN_NO_9_CAND_INFO_LIST =
			[ FIN_NO_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_10,  PC2_LATENT, 100 ] ] ] ]
			]

		FIN_NO_012_CAND_INFO_LIST =
			[ FIN_NO_012_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		FIN_NO_234_CAND_INFO_LIST =
			[ FIN_NO_234_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		FIN_NO_456_CAND_INFO_LIST =
			[ FIN_NO_456_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
	}

	private void initAdjacentCandInfoList(){
		ADJ_1_CAND_INFO_LIST =
			[ ADJ_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ,
				  [ SCOPE_1_BIN_ID_2, 1, reqIndex, ADJ_S_SCORE_1,
					[ [ ADJ_S_SCORE_1, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		ADJ_2_CAND_INFO_LIST =
			[ ADJ_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_2,  PC2_LATENT, 100 ] ] ] ,
				  [ SCOPE_1_BIN_ID_2, 1, reqIndex, ADJ_S_SCORE_2,
					[ [ ADJ_S_SCORE_2, FIN_2,  PC2_LATENT, 100 ] ] ] ]
			]
	
		ADJ_3_CAND_INFO_LIST =
			[ ADJ_EXT_ID, ADJ_S_SCORE_2, true,
				[ [ SCOPE_1_BIN_ID_2, 1, reqIndex, ADJ_S_SCORE_2,
					[ [ ADJ_S_SCORE_2, FIN_2,  PC2_LATENT, 100 ] ] ] ]
			]
	}	

	private void initRaceCandInfoList(){
		RACE_1_CAND_INFO_LIST =
			[ RACE_1_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		RACE_2_CAND_INFO_LIST =
			[ RACE_2_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		RACE_4_CAND_INFO_LIST =
			[ RACE_4_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
		
		RACE_8_CAND_INFO_LIST =
			[ RACE_8_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]

		RACE_M1_CAND_INFO_LIST =
			[ RACE_M1_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	}
	
	private void initRegionCandInfoList(){
		REGION_1_CAND_INFO_LIST =
			[ REGION_1_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		REGION_9_CAND_INFO_LIST =
			[ REGION_9_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		REGION_F_CAND_INFO_LIST =
			[ REGION_F_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
		
		REGION_U_CAND_INFO_LIST =
			[ REGION_U_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	}
	
	private void initColdCandInfoList(){
		COLD_1_CAND_INFO_LIST =
			[ COLD_1_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ,
				 [ SCOPE_1_BIN_ID_2, 1, reqIndex, S_BASE_SCORE,
					[ [ S_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		COLD_2_CAND_INFO_LIST =
			[ COLD_2_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ,
				 [ SCOPE_1_BIN_ID_2, 1, reqIndex, S_BASE_SCORE,
					[ [ S_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		COLD_3_CAND_INFO_LIST =
			[ COLD_3_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ,
				 [ SCOPE_1_BIN_ID_2, 1, reqIndex, S_BASE_SCORE,
					[ [ S_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
		
		COLD_4_CAND_INFO_LIST =
			[ COLD_4_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ,
				 [ SCOPE_1_BIN_ID_2, 1, reqIndex, S_BASE_SCORE,
					[ [ S_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
		
		COLD_5_CAND_INFO_LIST =
			[ COLD_5_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ,
				 [ SCOPE_1_BIN_ID_2, 1, reqIndex, S_BASE_SCORE,
					[ [ S_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]

		COLD_6_CAND_INFO_LIST =
			[ COLD_6_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ],
				 [ SCOPE_1_BIN_ID_2, 1, reqIndex, S_BASE_SCORE,
					[ [ S_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]

		COLD_7_CAND_INFO_LIST =
			[ COLD_7_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ,
				 [ SCOPE_1_BIN_ID_2, 1, reqIndex, S_BASE_SCORE,
					[ [ S_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]

		COLD_8_CAND_INFO_LIST =
			[ COLD_8_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ,
				 [ SCOPE_1_BIN_ID_2, 1, reqIndex, S_BASE_SCORE,
					[ [ S_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]

		COLD_9_CAND_INFO_LIST =
			[ COLD_9_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ,
				 [ SCOPE_1_BIN_ID_2, 1, reqIndex, S_BASE_SCORE,
					[ [ S_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]

	}

	private void initScopeCandInfoList(){
		SCOPE_1_CAND_INFO_LIST =
			[ SCOPE_1_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ,
				 [ SCOPE_1_BIN_ID_2, 1, reqIndex, S_BASE_SCORE,
					[ [ S_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		SCOPE_2_CAND_INFO_LIST =
			[ SCOPE_2_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_2_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ,
				 [ SCOPE_2_BIN_ID_2, 1, reqIndex, S_BASE_SCORE,
					[ [ S_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		SCOPE_3_CAND_INFO_LIST =
			[ SCOPE_3_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_3_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ,
				 [ SCOPE_3_BIN_ID_2, 1, reqIndex, S_BASE_SCORE,
					[ [ S_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]

		SCOPE_1_R_CAND_INFO_LIST =
			[ SCOPE_1_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		SCOPE_2_R_CAND_INFO_LIST =
			[ SCOPE_2_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_2_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		SCOPE_3_R_CAND_INFO_LIST =
			[ SCOPE_3_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_3_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]

		SCOPE_6_R_CAND_INFO_LIST =
			[ SCOPE_6_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_6_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]

		SCOPE_1_S_CAND_INFO_LIST =
			[ SCOPE_1_EXT_ID, S_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_2, 1, reqIndex, S_BASE_SCORE,
					[ [ S_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		SCOPE_2_S_CAND_INFO_LIST =
			[ SCOPE_2_EXT_ID, S_BASE_SCORE, true,
				[ [ SCOPE_2_BIN_ID_2, 1, reqIndex, S_BASE_SCORE,
					[ [ S_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	
		SCOPE_3_S_CAND_INFO_LIST =
			[ SCOPE_3_EXT_ID, S_BASE_SCORE, true,
				[ [ SCOPE_3_BIN_ID_2, 1, reqIndex, S_BASE_SCORE,
					[ [ S_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	}

	private void initFusionWeightCandInfoList(){
		FW_100_CAND_INFO_LIST =
			[ SCOPE_1_EXT_ID, R_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, fW100 ] ] ] ,
				  [ SCOPE_1_BIN_ID_2, 1, reqIndex, S_BASE_SCORE,
					[ [ S_BASE_SCORE, FIN_1,  PC2_LATENT, fW100 ] ] ] ]
			]

		FW_120_CAND_INFO_LIST =
			[ SCOPE_1_EXT_ID, rfW200Score, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, rfW200Score,
					[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, fW200 ] ] ] ,
				  [ SCOPE_1_BIN_ID_2, 1, reqIndex, sfW200Score,
					[ [ S_BASE_SCORE, FIN_1,  PC2_LATENT, fW200 ] ] ] ]
			]
	}

	private void initExternalIdCandInfoList(){
		EXT_ID_TEST_A_CAND_INFO_LIST =
			[ EXT_ID_TEST_A_EXT_ID, EXT_ID_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, EXT_ID_SCORE,
					[ [ EXT_ID_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]

		EXT_ID_TEST_B_CAND_INFO_LIST =
			[ EXT_ID_TEST_B_EXT_ID, EXT_ID_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, EXT_ID_SCORE,
					[ [ EXT_ID_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]

		EXT_ID_TEST_C_CAND_INFO_LIST =
			[ EXT_ID_TEST_C_EXT_ID, EXT_ID_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, EXT_ID_SCORE,
					[ [ EXT_ID_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]

		EXT_ID_TEST_D_CAND_INFO_LIST =
			[ EXT_ID_TEST_D_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]

		EXT_ID_TEST_E_CAND_INFO_LIST =
			[ EXT_ID_TEST_E_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]

		EXT_ID_TEST_F_CAND_INFO_LIST =
			[ EXT_ID_TEST_F_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]
	}

	private void initMultiAxisCandInfoList(){
		MULTI_AXIS_1_A_CAND_INFO_LIST =
			[ MULTI_AXIS_1_EXT_ID, MULTI_AXIS_1_A_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, MULTI_AXIS_1_A_SCORE,
					[ [ MULTI_AXIS_1_A_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]

		MULTI_AXIS_1_B_CAND_INFO_LIST_1 =
			[ MULTI_AXIS_1_EXT_ID, MULTI_AXIS_1_B_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, MULTI_AXIS_1_B_SCORE,
					[ [ MULTI_AXIS_1_B_SCORE, FIN_1, B ] ] ] ]
			]

		MULTI_AXIS_1_B_CAND_INFO_LIST_2 =
			[ MULTI_AXIS_1_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_1, B ] ] ] ]
			]

		MULTI_AXIS_1_C_CAND_INFO_LIST_1 =
			[ MULTI_AXIS_1_EXT_ID, MULTI_AXIS_1_C_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, MULTI_AXIS_1_C_SCORE,
					[ [ MULTI_AXIS_1_C_SCORE, FIN_1, C ] ] ] ]
			]

		MULTI_AXIS_1_C_CAND_INFO_LIST_2 =
			[ MULTI_AXIS_1_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_1, C ] ] ] ]
			]

		MULTI_AXIS_1_D_CAND_INFO_LIST =
			[ MULTI_AXIS_1_EXT_ID, MULTI_AXIS_1_D_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, MULTI_AXIS_1_D_SCORE,
					[ [ MULTI_AXIS_1_D_SCORE, FIN_1, D ] ] ] ]
			]

		MULTI_AXIS_2_A_CAND_INFO_LIST =
			[ MULTI_AXIS_2_EXT_ID, MULTI_AXIS_2_A_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, MULTI_AXIS_2_A_SCORE,
					[ [ MULTI_AXIS_2_A_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ]
			]

		MULTI_AXIS_2_B_CAND_INFO_LIST =
			[ MULTI_AXIS_2_EXT_ID, MULTI_AXIS_2_B_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, MULTI_AXIS_2_B_SCORE,
					[ [ MULTI_AXIS_2_B_SCORE, FIN_1, B ] ] ] ]
			]

		MULTI_AXIS_2_C_CAND_INFO_LIST =
			[ MULTI_AXIS_2_EXT_ID, MULTI_AXIS_2_C_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, MULTI_AXIS_2_C_SCORE,
					[ [ MULTI_AXIS_2_C_SCORE, FIN_1, C ] ] ] ]
			]

		MULTI_AXIS_2_D_CAND_INFO_LIST =
			[ MULTI_AXIS_2_EXT_ID, MULTI_AXIS_2_D_SCORE, true,
				[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, MULTI_AXIS_2_D_SCORE,
					[ [ MULTI_AXIS_2_D_SCORE, FIN_2, D ] ] ] ]
			]
	}
	
    public List getCandList_Search_Level_1(){
        return [ SEARCH_LEVEL_SCORE_CAND_INFO_LIST_1 ]
    }

    public List getCandList_Search_Level_2(){
        return [ SEARCH_LEVEL_SCORE_CAND_INFO_LIST_2 ]
    }

    public List getCandList_Search_Level_3(){
        return [ SEARCH_LEVEL_SCORE_CAND_INFO_LIST_3 ]
    }

    public List getCandList_Rotation_Limit_1(){
        return [ ROTATION_LIMIT_SCORE_CAND_INFO_LIST_1 ]
    }

    public List getCandList_Rotation_Limit_2(){
        return [ ROTATION_LIMIT_SCORE_CAND_INFO_LIST_2 ]
    }

    public List getCandList_Rotation_Limit_3(){
        return [ ROTATION_LIMIT_SCORE_CAND_INFO_LIST_3 ]
    }

    public List getCandList_Speed_Level_1(){
        return [ SPEED_LEVEL_SCORE_CAND_INFO_LIST_1 ]
    }

    public List getCandList_Speed_Level_2(){
        return [ SPEED_LEVEL_SCORE_CAND_INFO_LIST_2 ]
    }

    public List getCandList_Speed_Level_3(){
        return [ SPEED_LEVEL_SCORE_CAND_INFO_LIST_3 ]
    }

    public List getCandList_Speed_Level_Second_1(){
        return [ SPEED_LEVEL_SECOND_SCORE_CAND_INFO_LIST_1 ]
    }

    public List getCandList_Speed_Level_Second_2(){
        return [ SPEED_LEVEL_SECOND_SCORE_CAND_INFO_LIST_2 ]
    }

    public List getCandList_Speed_Level_Second_3(){
        return [ SPEED_LEVEL_SECOND_SCORE_CAND_INFO_LIST_3 ]
    }

    public List getCandList_Distortion_Level_1(){
        return [ DISTORTION_LEVEL_SCORE_CAND_INFO_LIST_1 ]
    }

    public List getCandList_Distortion_Level_2(){
        return [ DISTORTION_LEVEL_SCORE_CAND_INFO_LIST_2 ]
    }

    public List getCandList_Distortion_Level_3(){
        return [ DISTORTION_LEVEL_SCORE_CAND_INFO_LIST_3 ]
    }

    public List getCandList_Distortion_Level_Second_1(){
        return [ DISTORTION_LEVEL_SECOND_SCORE_CAND_INFO_LIST_1 ]
    }

    public List getCandList_Distortion_Level_Second_2(){
        return [ DISTORTION_LEVEL_SECOND_SCORE_CAND_INFO_LIST_2 ]
    }

	public List getCandList_Default_R(){
		return [ DEF_R_CAND_INFO_LIST ] 
	}

	public List getCandList_Default_S(){
		return [ DEF_S_CAND_INFO_LIST ] 
	}

	public List getCandList_Default_RS(){
		return [ DEF_RS_CAND_INFO_LIST ] 
	}

	public List getCandList_Default_RS_multiScope(){
		return [ DEF_RS_MULTI_SCOPE_CAND_INFO_LIST ] 
	}

	public List getCandList_Option_1(){
		return [ OPTION_CAND_INFO_LIST_1 ] 
	}

	public List getCandList_Option_2(){
		return [ OPTION_CAND_INFO_LIST_2 ] 
	}

	public List getCandList_Option_3(){
		return [ OPTION_CAND_INFO_LIST_3 ] 
	}

	public List getCandList_Option_4(){
		return [ OPTION_CAND_INFO_LIST_4 ] 
	}

	public List getCandList_Gender_M_Only(){
		return [ GEN_M_CAND_INFO_LIST ] 
	}

	public List getCandList_Gender_M(){
		return [ GEN_M_CAND_INFO_LIST,  GEN_U_CAND_INFO_LIST ] 
	}

	public List getCandList_Gender_F(){
		return [ GEN_F_CAND_INFO_LIST, GEN_U_CAND_INFO_LIST ] 
	}
	
	public List getCandList_Gender_U(){
		return [ GEN_M_CAND_INFO_LIST, GEN_F_CAND_INFO_LIST, GEN_U_CAND_INFO_LIST ] 
	}

	public List getCandList_Yob_All(){
		return [ YOB_1_CAND_INFO_LIST, YOB_2_CAND_INFO_LIST, YOB_3_CAND_INFO_LIST,
				 YOB_4_CAND_INFO_LIST, YOB_5_CAND_INFO_LIST, YOB_6_CAND_INFO_LIST,
				 YOB_7_CAND_INFO_LIST, YOB_8_CAND_INFO_LIST, YOB_9_CAND_INFO_LIST,
				 YOB_10_CAND_INFO_LIST, YOB_11_CAND_INFO_LIST, YOB_12_CAND_INFO_LIST ] 
	}

	public List getCandList_Yob_10(){
		return [ YOB_1_CAND_INFO_LIST, YOB_2_CAND_INFO_LIST, YOB_3_CAND_INFO_LIST,
				 YOB_4_CAND_INFO_LIST, YOB_5_CAND_INFO_LIST, YOB_7_CAND_INFO_LIST,
				 YOB_8_CAND_INFO_LIST, YOB_10_CAND_INFO_LIST, YOB_11_CAND_INFO_LIST,
				 YOB_12_CAND_INFO_LIST ] 
	}

	public List getCandList_Yob_9(){
		return [ YOB_1_CAND_INFO_LIST, YOB_2_CAND_INFO_LIST, YOB_3_CAND_INFO_LIST,
				 YOB_4_CAND_INFO_LIST, YOB_5_CAND_INFO_LIST, YOB_8_CAND_INFO_LIST, 
				 YOB_9_CAND_INFO_LIST, YOB_11_CAND_INFO_LIST, YOB_12_CAND_INFO_LIST ] 
	}

	public List getCandList_Pattern(){
		return [ PATTERN_CAND_INFO_LIST ]
	}

	public List getCandList_Pattern_All(){
		return [ PATTERN_A_CAND_INFO_LIST, PATTERN_W_CAND_INFO_LIST, PATTERN_L_CAND_INFO_LIST,
				 PATTERN_R_CAND_INFO_LIST, PATTERN_S_CAND_INFO_LIST, PATTERN_AW_CAND_INFO_LIST,
				 PATTERN_AL_CAND_INFO_LIST, PATTERN_AR_CAND_INFO_LIST, PATTERN_WL_CAND_INFO_LIST,
				 PATTERN_WR_CAND_INFO_LIST, PATTERN_LR_CAND_INFO_LIST, PATTERN_LRA_CAND_INFO_LIST,
				 PATTERN_AWR_CAND_INFO_LIST, PATTERN_WLR_CAND_INFO_LIST, PATTERN_AWL_CAND_INFO_LIST,
				 PATTERN_AWLR_CAND_INFO_LIST ] 
	}

	public List getCandList_Pattern_13(){
		return [  PATTERN_L_CAND_INFO_LIST, PATTERN_R_CAND_INFO_LIST, PATTERN_S_CAND_INFO_LIST, 
				 PATTERN_AL_CAND_INFO_LIST, PATTERN_AR_CAND_INFO_LIST, PATTERN_WL_CAND_INFO_LIST,
				 PATTERN_WR_CAND_INFO_LIST, PATTERN_LR_CAND_INFO_LIST, PATTERN_LRA_CAND_INFO_LIST,
				 PATTERN_AWR_CAND_INFO_LIST, PATTERN_WLR_CAND_INFO_LIST, PATTERN_AWL_CAND_INFO_LIST,
				 PATTERN_AWLR_CAND_INFO_LIST ] 
	}

	public List getCandList_Pattern_9_Type_1(){
		return [ PATTERN_A_CAND_INFO_LIST, PATTERN_S_CAND_INFO_LIST, PATTERN_AW_CAND_INFO_LIST,
				 PATTERN_AL_CAND_INFO_LIST, PATTERN_AR_CAND_INFO_LIST,  PATTERN_LRA_CAND_INFO_LIST,
				 PATTERN_AWR_CAND_INFO_LIST ,PATTERN_AWL_CAND_INFO_LIST, PATTERN_AWLR_CAND_INFO_LIST ] 
	}

	public List getCandList_Pattern_9_Type_2(){
		return [ PATTERN_L_CAND_INFO_LIST,PATTERN_S_CAND_INFO_LIST, PATTERN_AL_CAND_INFO_LIST,
				 PATTERN_WL_CAND_INFO_LIST, PATTERN_LR_CAND_INFO_LIST, PATTERN_LRA_CAND_INFO_LIST,
				 PATTERN_WLR_CAND_INFO_LIST,PATTERN_AWL_CAND_INFO_LIST,PATTERN_AWLR_CAND_INFO_LIST ] 
	}

	public List getCandList_FingerNo_All(){
		return [ FIN_NO_0_CAND_INFO_LIST, FIN_NO_1_CAND_INFO_LIST, FIN_NO_2_CAND_INFO_LIST,
				 FIN_NO_3_CAND_INFO_LIST, FIN_NO_4_CAND_INFO_LIST, FIN_NO_5_CAND_INFO_LIST,
				 FIN_NO_6_CAND_INFO_LIST, FIN_NO_7_CAND_INFO_LIST, FIN_NO_8_CAND_INFO_LIST,
				 FIN_NO_9_CAND_INFO_LIST, FIN_NO_012_CAND_INFO_LIST, FIN_NO_234_CAND_INFO_LIST,
				 FIN_NO_456_CAND_INFO_LIST ] 
	}
	
	public List getCandList_FingerNo_1(){
		return [ FIN_NO_0_CAND_INFO_LIST ]
	}

	public List getCandList_FingerNo_2(){
		return [ FIN_NO_1_CAND_INFO_LIST ]
	}

	public List getCandList_FingerNo_6(){
		return [ FIN_NO_5_CAND_INFO_LIST ]
	}

	public List getCandList_FingerNo_9(){
		return [ FIN_NO_9_CAND_INFO_LIST ]
	}

	public List getCandList_FingerNo_123(){
		return [ FIN_NO_1_CAND_INFO_LIST, FIN_NO_2_CAND_INFO_LIST, FIN_NO_3_CAND_INFO_LIST,
				 FIN_NO_012_CAND_INFO_LIST, FIN_NO_234_CAND_INFO_LIST ]
	}

	public List getCandList_Adjacent_1(){
		return [ ADJ_1_CAND_INFO_LIST ]
	}

	public List getCandList_Adjacent_2(){
		return [ ADJ_2_CAND_INFO_LIST ]
	}

	public List getCandList_Adjacent_3(){
		return [ ADJ_3_CAND_INFO_LIST ]
	}

	public List getCandList_Race_All(){
		return [ RACE_1_CAND_INFO_LIST, RACE_2_CAND_INFO_LIST, RACE_4_CAND_INFO_LIST,
				 RACE_8_CAND_INFO_LIST, RACE_1_CAND_INFO_LIST ]
	}

	public List getCandList_Race_1(){
		return [ RACE_1_CAND_INFO_LIST, RACE_M1_CAND_INFO_LIST ]
	}

	public List getCandList_Race_4(){
		return [ RACE_4_CAND_INFO_LIST, RACE_M1_CAND_INFO_LIST ]
	}

	public List getCandList_Region_All(){
		return [ REGION_1_CAND_INFO_LIST, REGION_9_CAND_INFO_LIST, REGION_F_CAND_INFO_LIST,
				 REGION_U_CAND_INFO_LIST ]
	}

	public List getCandList_Region_1(){
		return [ REGION_1_CAND_INFO_LIST, REGION_U_CAND_INFO_LIST ]
	}

	public List getCandList_ColdSearch_All(){
		return [ COLD_1_CAND_INFO_LIST, COLD_2_CAND_INFO_LIST, COLD_3_CAND_INFO_LIST,
				 COLD_4_CAND_INFO_LIST, COLD_5_CAND_INFO_LIST, COLD_6_CAND_INFO_LIST,
				 COLD_7_CAND_INFO_LIST, COLD_8_CAND_INFO_LIST, COLD_9_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_1(){
		return [ SCOPE_1_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_2(){
		return [ SCOPE_2_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_3(){
		return [ SCOPE_3_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_1_R(){
		return [ SCOPE_1_R_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_2_R(){
		return [ SCOPE_2_R_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_3_R(){
		return [ SCOPE_3_R_CAND_INFO_LIST ]
	}
    
	public List getCandList_Scope_6_R(){
        return [ SCOPE_6_R_CAND_INFO_LIST ]
    }

	public List getCandList_Scope_1_S(){
		return [ SCOPE_1_S_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_2_S(){
		return [ SCOPE_2_S_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_3_S(){
		return [ SCOPE_3_S_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_1_2(){
		return [ SCOPE_1_CAND_INFO_LIST, SCOPE_2_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_1_2_R(){
		return [ SCOPE_1_R_CAND_INFO_LIST, SCOPE_2_R_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_1_2_S(){
		return [ SCOPE_1_S_CAND_INFO_LIST, SCOPE_2_S_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_1_3(){
		return [ SCOPE_1_CAND_INFO_LIST, SCOPE_3_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_2_3_S(){
		return [ SCOPE_2_S_CAND_INFO_LIST, SCOPE_3_S_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_1_2_3(){
		return [ SCOPE_1_CAND_INFO_LIST, SCOPE_2_CAND_INFO_LIST, SCOPE_3_CAND_INFO_LIST ]
	}

	public List getCandList_Fw_100(){
		return [ FW_100_CAND_INFO_LIST ]
	}

	public List getCandList_Fw_120(){
		return [ FW_120_CAND_INFO_LIST ]
	}

	public List getCandList_External_Id(){
		return [ EXT_ID_TEST_A_CAND_INFO_LIST, EXT_ID_TEST_B_CAND_INFO_LIST, EXT_ID_TEST_C_CAND_INFO_LIST,
				 EXT_ID_TEST_D_CAND_INFO_LIST, EXT_ID_TEST_E_CAND_INFO_LIST, EXT_ID_TEST_F_CAND_INFO_LIST ]
	}

	public List getCandList_MultiAxisF_1(){
		return [ MULTI_AXIS_1_A_CAND_INFO_LIST, MULTI_AXIS_1_B_CAND_INFO_LIST_1, MULTI_AXIS_1_C_CAND_INFO_LIST_1,
				 MULTI_AXIS_1_D_CAND_INFO_LIST ]
	}

	public List getCandList_MultiAxisF_2(){
		return [ MULTI_AXIS_1_A_CAND_INFO_LIST, MULTI_AXIS_1_B_CAND_INFO_LIST_2, MULTI_AXIS_1_C_CAND_INFO_LIST_2,
				 MULTI_AXIS_1_D_CAND_INFO_LIST ]
	}

	public List getCandList_MultiAxisF_3(){
		return [ MULTI_AXIS_1_A_CAND_INFO_LIST, MULTI_AXIS_1_B_CAND_INFO_LIST_2, MULTI_AXIS_1_C_CAND_INFO_LIST_2,
				 MULTI_AXIS_1_D_CAND_INFO_LIST, MULTI_AXIS_2_D_CAND_INFO_LIST ]
	}
	
	public List getCandList_MultiAxisT_1(){
		return [ MULTI_AXIS_1_A_CAND_INFO_LIST ]
	}

	public List getCandList_MultiAxisT_2(){
		return [ MULTI_AXIS_1_A_CAND_INFO_LIST, MULTI_AXIS_2_D_CAND_INFO_LIST ]
	}

	public List getLocList(int listSize){
		List resultList = []		

		for (i in 1..listSize){
			def str  = i as String
			def extId = str.padLeft(3,"0")
			DEF_RS_CAND_INFO_LIST = 
				[ extId, R_BASE_SCORE, true,
					[ [ SCOPE_1_BIN_ID_1, 1, reqIndex, R_BASE_SCORE,
						[ [ R_BASE_SCORE, FIN_1,  PC2_LATENT, 100 ] ] ] ] ,
				]
			resultList.add(DEF_RS_CAND_INFO_LIST)
		}
		return resultList 

	}


	private void setNullFwIfHighLevel(String level){
		if(level == "high") {
			this.fmp5FW = null
		}else{
			this.pc2FW = 200
		}
	}
}

