package test.degrade.testitem.helper.templates

import test.degrade.testitem.helper.*
import static test.common.constants.data.ImageDataList.*

class LipTestTemplateCreateHelper extends TestTemplateCreateHelper{

    LipTestTemplateCreateHelper(context){
		super(context)
    }

	public String getDefaultFileImage(){
		return imgXmlMaker.getTenprintPalmImgXml(TP_001_RSP_NST)
	}

	public String getDefaultSearchImage(){
		return imgXmlMaker.getLatentPalmImgXml(LP_001_WSQ)
	}

	public String getExternalIdFileImage(){
		return imgXmlMaker.getTenprintPalmImgXml(TP_003_RSP_NST)
	}

	public String getSelectPartsFileImage(){
		return imgXmlMaker.getPalmAllPartsImgXml()
	}
}
