package test.degrade.testitem.helper

import static test.common.constants.aim.AIMXmlAttribute.*
import static test.common.constants.aim.AIMWord.*
import test.degrade.properties.GlobalProperties
import test.degrade.management.AbendProcessor

class TimHelper extends ConsolidationHelper {

	private static final String GEN_M_EXT_ID = "M"
	private static final String GEN_F_EXT_ID = "F"
	private static final String GEN_U_EXT_ID = "U"

	private static final String NUMBER_01 = "00001"
	private static final String NUMBER_02 = "00002"
	private static final String NUMBER_03 = "00003"
	private static final String NUMBER_04 = "00004"
	private static final String NUMBER_05 = "00005"
	private static final String NUMBER_06 = "00006"
	private static final String NUMBER_07 = "00007"
	private static final String NUMBER_08 = "00008"
	private static final String NUMBER_09 = "00009"
	private static final String NUMBER_10 = "00010"
	private static final String NUMBER_11 = "00011"
	private static final String NUMBER_12 = "00012"

	private static final String F1_EXT_ID = "TIM1-"
	private static final String F2_EXT_ID = "TIM2-"
	private static final String F3_EXT_ID = "TIM3-"
	private static final String F4_EXT_ID = "TIM4-"
	private static final String F5_EXT_ID = "TIM5-"
	private static final String F6_EXT_ID = "TIM6-"
	private static final String F7_8_EXT_ID = "TIM7and8-"
	private static final String F9_EXT_ID = "TIM9-"
	private static final String F10_EXT_ID = "TIM10-"
	private static final String F11_EXT_ID = "TIM11-"
	private static final String F12_EXT_ID = "TIM12-"
	private static final String F13_EXT_ID = "TIM13-"
	private static final String F14_EXT_ID = "TIM14-"
	private static final String F15_EXT_ID = "TIM15-"
	private static final String F16_EXT_ID_01 = "TF001_RDBTM_gender_M_yob_1990"
	private static final String F16_EXT_ID_02 = "TF001_RDBTM_gender_M_yob_2000"
	private static final String F16_EXT_ID_03 = "TF001_RDBTM_gender_M_yob_-1"
	private static final String F16_EXT_ID_04 = "TF001_RDBTM_gender_F_yob_1990"
	private static final String F16_EXT_ID_05 = "TF001_RDBTM_gender_F_yob_2000"
	private static final String F16_EXT_ID_06 = "TF001_RDBTM_gender_F_yob_-1"
	private static final String F16_EXT_ID_07 = "TF001_RDBTM_gender_U_yob_1990"
	private static final String F16_EXT_ID_08 = "TF001_RDBTM_gender_U_yob_2000"
	private static final String F16_EXT_ID_09 = "TF001_RDBTM_gender_U_yob_-1"
	private static final String F16_EXT_ID_10 = "TF001_SDBTM_gender_M_yob_1990"
	private static final String F16_EXT_ID_11 = "TF001_SDBTM_gender_M_yob_2000"
	private static final String F16_EXT_ID_12 = "TF001_SDBTM_gender_M_yob_-1"
	private static final String F16_EXT_ID_13 = "TF001_SDBTM_gender_F_yob_1990"
	private static final String F16_EXT_ID_14 = "TF001_SDBTM_gender_F_yob_2000"
	private static final String F16_EXT_ID_15 = "TF001_SDBTM_gender_F_yob_-1"
	private static final String F16_EXT_ID_16 = "TF001_SDBTM_gender_U_yob_1990"
	private static final String F16_EXT_ID_17 = "TF001_SDBTM_gender_U_yob_2000"
	private static final String F16_EXT_ID_18 = "TF001_SDBTM_gender_U_yob_-1"
	private static final String F17_EXT_ID = "TIM17-"
	private static final String F18_EXT_ID = "TIM18-"
	private static final String F19_EXT_ID = "TIM19-"
	private static final String F20_EXT_ID = "TIM20-"
	private static final String F21_EXT_ID = "TIM21-"
	private static final String F22_EXT_ID = "TIM22-"
	private static final String F24_EXT_ID = "TIM24-"
	private static final String F25_EXT_ID = "TIM25-"
	private static final String F26_EXT_ID = "TIM26-"
	private static final String F27_EXT_ID = "TIM27-"
	private static final String F28_EXT_ID = "TIM28-"
	private static final String F29_EXT_ID = "TIM29-"
	private static final String F30_EXT_ID = "TIM30-"
	private static final String F31_EXT_ID = "TIM31-"
	private static final String F32_EXT_ID = "TIM32-"

	private static final String F33_EXT_ID = "TIM33-"
	private static final String F34_EXT_ID = "TIM34-"
	private static final String F35_EXT_ID = "TIM35-"
	private static final String F36_EXT_ID = "TIM36-"
	private static final String F37_EXT_ID = "TIM37-"
	private static final String F38_EXT_ID = "TIM38-"

	private static final String F39_EXT_ID = "TIM39-"
	private static final String F40_EXT_ID = "TIM40-"
	private static final String F41_EXT_ID = "TIM41-"
	private static final String F42_EXT_ID = "TIM42-"
	private static final String F43_EXT_ID = "TIM43-"
	private static final String F44_EXT_ID = "TIM44-"
	private static final String F45_EXT_ID = "TIM45-"
	private static final String F46_EXT_ID = "TIM46-"
	private static final String F47_EXT_ID = "TIM47-"
	private static final String F48_HIGH_EXT_ID = "TIM48-highScore-"
	private static final String F48_LOW_EXT_ID = "TIM48-lowScore-"
	private static final String F49_EXT_ID = "TIM49-"
	private static final String CML_EXT_ID = "CML-"
	
	private static final int MAX_SCORE = 9999
	private static final int ZERO_SCORE = 0
	private static int MAX_OR_ZERO_SCORE
	private static int ROT_BY_AXIS_SCORE
	private static int BASIC_CSCORE_1
	private static int BASIC_SCORE_1_1F
	private static int BASIC_SCORE_1_2F
	private static int BASIC_SCORE_1_3F
	private static int BASIC_SCORE_1_4F
	private static int BASIC_SCORE_1_5F
	private static int BASIC_SCORE_1_6F
	private static int BASIC_SCORE_1_7F
	private static int BASIC_SCORE_1_8F
	private static int BASIC_SCORE_1_9F
	private static int BASIC_SCORE_1_10F

	private static int BASIC_SCORE_2_1F
	private static int BASIC_SCORE_2_2F
	private static int BASIC_SCORE_2_3F
	private static int BASIC_SCORE_2_5F
	private static int BASIC_SCORE_2_6F
	private static int BASIC_SCORE_2_10F

	private static int BASIC_CSCORE_3
	private static int BASIC_SCORE_3_1F
	private static int BASIC_SCORE_3_2F
	private static int BASIC_SCORE_3_3F
	private static int BASIC_SCORE_3_4F
	private static int BASIC_SCORE_3_5F
	private static int BASIC_SCORE_3_6F
	private static int BASIC_SCORE_3_7F
	private static int BASIC_SCORE_3_8F
	private static int BASIC_SCORE_3_9F
	private static int BASIC_SCORE_3_10F

	private static int BASIC_CSCORE_4
	private static int BASIC_SCORE_4_1F
	private static int BASIC_SCORE_4_2F
	private static int BASIC_SCORE_4_3F
	private static int BASIC_SCORE_4_4F
	private static int BASIC_SCORE_4_5F
	private static int BASIC_SCORE_4_6F
	private static int BASIC_SCORE_4_7F
	private static int BASIC_SCORE_4_8F
	private static int BASIC_SCORE_4_9F
	private static int BASIC_SCORE_4_10F

	private static int BASIC_CSCORE_5
	private static int BASIC_SCORE_5_1F
	private static int BASIC_SCORE_5_2F
	private static int BASIC_SCORE_5_3F
	private static int BASIC_SCORE_5_4F
	private static int BASIC_SCORE_5_5F
	private static int BASIC_SCORE_5_6F
	private static int BASIC_SCORE_5_7F
	private static int BASIC_SCORE_5_8F
	private static int BASIC_SCORE_5_9F
	private static int BASIC_SCORE_5_10F
	
	private static int BASIC_CSCORE_6
	private static int BASIC_SCORE_6_1F
	private static int BASIC_SCORE_6_3F
	private static int BASIC_SCORE_6_5F
	private static int BASIC_SCORE_6_7F
	private static int BASIC_SCORE_6_9F
	private static int BASIC_SCORE_6_10F

	private static int BASIC_CSCORE_7
	private static int BASIC_SCORE_7_1F
	private static int BASIC_SCORE_7_2F
	private static int BASIC_SCORE_7_3F
	private static int BASIC_SCORE_7_5F
	private static int BASIC_SCORE_7_6F
	private static int BASIC_SCORE_7_7F
	private static int BASIC_SCORE_7_8F
	private static int BASIC_SCORE_7_9F
	private static int BASIC_SCORE_7_10F
	
	private static int BASIC_SCORE_8_1F
	private static int BASIC_SCORE_8_9F

	private static int BASIC_SCORE_9_1F
	private static int BASIC_SCORE_9_2F
	private static int BASIC_SCORE_9_3F
	private static int BASIC_SCORE_9_4F
	private static int BASIC_SCORE_9_5F
	private static int BASIC_SCORE_9_6F
	private static int BASIC_SCORE_9_7F
	private static int BASIC_SCORE_9_8F
	private static int BASIC_SCORE_9_9F
	private static int BASIC_SCORE_9_10F

	private static int BASIC_SCORE_10_1F
	private static int BASIC_SCORE_10_2F
	private static int BASIC_SCORE_10_3F
	private static int BASIC_SCORE_10_4F
	private static int BASIC_SCORE_10_5F
	private static int BASIC_SCORE_10_6F
	private static int BASIC_SCORE_10_7F
	private static int BASIC_SCORE_10_8F
	private static int BASIC_SCORE_10_9F
	private static int BASIC_SCORE_10_10F

	private static int BASIC_CSCORE_11
	private static int BASIC_SCORE_11_1F
	private static int BASIC_SCORE_11_6F
	private static int BASIC_SCORE_11_9F
	private static int BASIC_SCORE_11_10F

	private static final int ROTATION_CSCORE_1_R = 1167
	private static final int ROTATION_SCORE_1_R_1F = 1227
	private static final int ROTATION_SCORE_1_R_2F = 0
	private static final int ROTATION_SCORE_1_R_3F = -12
	private static final int ROTATION_SCORE_1_R_4F = -12
	private static final int ROTATION_SCORE_1_R_5F = 0
	private static final int ROTATION_SCORE_1_R_6F = -12
	private static final int ROTATION_SCORE_1_R_7F = 0
	private static final int ROTATION_SCORE_1_R_8F = -12
	private static final int ROTATION_SCORE_1_R_9F = -12
	private static final int ROTATION_SCORE_1_R_10F = 0

	private static final int ROTATION_CSCORE_1_S = 2526
	private static final int ROTATION_SCORE_1_S_1F = 2562
	private static final int ROTATION_SCORE_1_S_2F = 0
	private static final int ROTATION_SCORE_1_S_3F = -12
	private static final int ROTATION_SCORE_1_S_4F = 0
	private static final int ROTATION_SCORE_1_S_5F = 0
	private static final int ROTATION_SCORE_1_S_6F = -12
	private static final int ROTATION_SCORE_1_S_7F = 0
	private static final int ROTATION_SCORE_1_S_8F = 0
	private static final int ROTATION_SCORE_1_S_9F = -12
	private static final int ROTATION_SCORE_1_S_10F = 0

	private static final int ROTATION_CSCORE_2_R = 1228
	private static final int ROTATION_SCORE_2_R_1F = 1227
	private static final int ROTATION_SCORE_2_R_2F = 0
	private static final int ROTATION_SCORE_2_R_3F = 49
	private static final int ROTATION_SCORE_2_R_4F = -12
	private static final int ROTATION_SCORE_2_R_5F = 0
	private static final int ROTATION_SCORE_2_R_6F = -12
	private static final int ROTATION_SCORE_2_R_7F = 0
	private static final int ROTATION_SCORE_2_R_8F = -12
	private static final int ROTATION_SCORE_2_R_9F = -12
	private static final int ROTATION_SCORE_2_R_10F = 0

	private static final int CML_PARAMID1_CSCORE_1 = 1328
	private static final int CML_PARAMID1_SCORE_1_1F = 1277
	private static final int CML_PARAMID1_SCORE_1_2F = 0
	private static final int CML_PARAMID1_SCORE_1_3F = 99
	private static final int CML_PARAMID1_SCORE_1_4F = -12
	private static final int CML_PARAMID1_SCORE_1_5F = 0
	private static final int CML_PARAMID1_SCORE_1_6F = -12
	private static final int CML_PARAMID1_SCORE_1_7F = 0
	private static final int CML_PARAMID1_SCORE_1_8F = -12
	private static final int CML_PARAMID1_SCORE_1_9F = -12
	private static final int CML_PARAMID1_SCORE_1_10F = 0

	private static final int CML_PARAMID1_CSCORE_2 = 1228
	private static final int CML_PARAMID1_SCORE_2_1F = 1227
	private static final int CML_PARAMID1_SCORE_2_2F = 0
	private static final int CML_PARAMID1_SCORE_2_3F = 49
	private static final int CML_PARAMID1_SCORE_2_4F = -12
	private static final int CML_PARAMID1_SCORE_2_5F = 0
	private static final int CML_PARAMID1_SCORE_2_6F = -12
	private static final int CML_PARAMID1_SCORE_2_7F = 0
	private static final int CML_PARAMID1_SCORE_2_8F = -12
	private static final int CML_PARAMID1_SCORE_2_9F = -12
	private static final int CML_PARAMID1_SCORE_2_10F = 0

	private int basic_score_1
	private int basic_cscore_1
	private int basic_score_1_1F 
	private int basic_score_2
	private int basic_score_2_1F
	private int basic_score_2_2F
	private int basic_score_2_3F
	private int basic_score_2_5F
	private int basic_score_2_6F
	private int basic_score_2_10F
	private int basic_cscore_3
	private int basic_score_3_1F
	private int basic_cscore_4
	private int basic_score_4_1F
	private int basic_cscore_5
	private int basic_score_5_1F
	private int basic_score_6
	private int basic_score_6_1F
	private int basic_score_6_3F
	private int basic_score_6_5F
	private int basic_score_6_7F
	private int basic_score_6_9F
	private int basic_score_6_10F
	private int basic_score_7
	private int basic_score_7_1F
	private int basic_score_7_2F
	private int basic_score_7_3F
	private int basic_score_7_5F
	private int basic_score_7_6F
	private int basic_score_7_7F
	private int basic_score_7_8F
	private int basic_score_7_9F
	private int basic_score_7_10F
	private int basic_score_8
	private int basic_score_8_1F
	private int basic_score_8_9F
	private int basic_cscore_11
	
	private Integer rollFW = 100
	private Integer slapFW = 100
	private int eventId = 1
	private int reqIndexZero = 0
	private int reqIndexOne = 1

	private int sortHighScore_1_10F
	private int sortLowScore_1F
	private int sortLowScore_2_10F

	private List GEN_M_CAND_INFO_LIST = []
	private List GEN_F_CAND_INFO_LIST = []
	private List GEN_U_CAND_INFO_LIST = []

	private List F1_CARD_QUALITY_CAND_INFO_LIST_1 = []
	private List F1_CARD_QUALITY_CAND_INFO_LIST_2 = []
	private List F1_CARD_QUALITY_CAND_INFO_LIST_3 = []
	
	private List F2_APP_PATTERN_THRESHOLD_CAND_INFO_LIST_1 = []
	
	private List F3_PATTERN_THRESHOLD_CAND_INFO_LIST_1 = []
	
	private List F25_APP_GENDER_CAND_INFO_LIST_1 = []
	private List F25_APP_GENDER_CAND_INFO_LIST_2 = []
	private List F25_APP_GENDER_CAND_INFO_LIST_3 = []
	private List F25_APP_GENDER_CAND_INFO_LIST_4 = []
	private List F25_APP_GENDER_CAND_INFO_LIST_5 = []
	private List F25_APP_GENDER_CAND_INFO_LIST_6 = []
	
	private List F4_GENDER_CAND_INFO_LIST_1 = []
	private List F4_GENDER_CAND_INFO_LIST_2 = []
	private List F4_GENDER_CAND_INFO_LIST_3 = []
	private List F4_GENDER_CAND_INFO_LIST_4 = []
	private List F4_GENDER_CAND_INFO_LIST_5 = []
	private List F4_GENDER_CAND_INFO_LIST_6 = []

	private List F27_YOB_CAND_INFO_LIST_01 = []
	private List F27_YOB_CAND_INFO_LIST_02 = []
	private List F27_YOB_CAND_INFO_LIST_03 = []
	private List F27_YOB_CAND_INFO_LIST_04 = []
	private List F27_YOB_CAND_INFO_LIST_05 = []
	private List F27_YOB_CAND_INFO_LIST_06 = []
	private List F27_YOB_CAND_INFO_LIST_07 = []
	private List F27_YOB_CAND_INFO_LIST_08 = []
	private List F27_YOB_CAND_INFO_LIST_09 = []
	private List F27_YOB_CAND_INFO_LIST_10 = []
	private List F27_YOB_CAND_INFO_LIST_11 = []
	private List F27_YOB_CAND_INFO_LIST_12 = []
	private List F27_YOB_CAND_INFO_LIST_13 = []
	private List F27_YOB_CAND_INFO_LIST_14 = []
	private List F27_YOB_CAND_INFO_LIST_15 = []
	private List F27_YOB_CAND_INFO_LIST_16 = []
	private List F27_YOB_CAND_INFO_LIST_17 = []
	private List F27_YOB_CAND_INFO_LIST_18 = []
	private List F27_YOB_CAND_INFO_LIST_19 = []
	private List F27_YOB_CAND_INFO_LIST_20 = []
	private List F27_YOB_CAND_INFO_LIST_21 = []
	private List F27_YOB_CAND_INFO_LIST_22 = []
	private List F27_YOB_CAND_INFO_LIST_23 = []
	private List F27_YOB_CAND_INFO_LIST_24 = []

	private List F5_APP_YOB_THRESHOLD_CAND_INFO_LIST_01 = []
	private List F5_APP_YOB_THRESHOLD_CAND_INFO_LIST_02 = []
	private List F5_APP_YOB_THRESHOLD_CAND_INFO_LIST_03 = []
	private List F5_APP_YOB_THRESHOLD_CAND_INFO_LIST_04 = []
	private List F5_APP_YOB_THRESHOLD_CAND_INFO_LIST_05 = []
	private List F5_APP_YOB_THRESHOLD_CAND_INFO_LIST_06 = []
	private List F5_APP_YOB_THRESHOLD_CAND_INFO_LIST_07 = []
	private List F5_APP_YOB_THRESHOLD_CAND_INFO_LIST_08 = []
	private List F5_APP_YOB_THRESHOLD_CAND_INFO_LIST_09 = []
	private List F5_APP_YOB_THRESHOLD_CAND_INFO_LIST_10 = []

	private List F6_YOB_THRESHOLD_CAND_INFO_LIST_01 = []
	private List F6_YOB_THRESHOLD_CAND_INFO_LIST_02 = []
	private List F6_YOB_THRESHOLD_CAND_INFO_LIST_03 = []
	private List F6_YOB_THRESHOLD_CAND_INFO_LIST_04 = []
	private List F6_YOB_THRESHOLD_CAND_INFO_LIST_05 = []
	private List F6_YOB_THRESHOLD_CAND_INFO_LIST_06 = []
	private List F6_YOB_THRESHOLD_CAND_INFO_LIST_07 = []
	private List F6_YOB_THRESHOLD_CAND_INFO_LIST_08 = []
	private List F6_YOB_THRESHOLD_CAND_INFO_LIST_09 = []
	private List F6_YOB_THRESHOLD_CAND_INFO_LIST_10 = []
	private List F6_YOB_THRESHOLD_CAND_INFO_LIST_11 = []
	private List F6_YOB_THRESHOLD_CAND_INFO_LIST_12 = []
	private List F6_YOB_THRESHOLD_CAND_INFO_LIST_13 = []
	private List F6_YOB_THRESHOLD_CAND_INFO_LIST_14 = []
	private List F6_YOB_THRESHOLD_CAND_INFO_LIST_15 = []
	private List F6_YOB_THRESHOLD_CAND_INFO_LIST_16 = []
	private List F6_YOB_THRESHOLD_CAND_INFO_LIST_17 = []
	private List F6_YOB_THRESHOLD_CAND_INFO_LIST_18 = []
	private List F6_YOB_THRESHOLD_CAND_INFO_LIST_19 = []
	private List F6_YOB_THRESHOLD_CAND_INFO_LIST_20 = []
	
	private List F7_8_FINGER_CAND_INFO_LIST_1 = []
	
	private List F9_FILTER_CAND_INFO_LIST_1 = []		
	private List F9_FILTER_CAND_INFO_LIST_2 = []		
	private List F9_FILTER_CAND_INFO_LIST_3 = []		
	private List F9_FILTER_CAND_INFO_LIST_4 = []		
	private List F9_FILTER_CAND_INFO_LIST_5 = []		
	private List F9_FILTER_CAND_INFO_LIST_6 = []		
	private List F9_FILTER_CAND_INFO_LIST_7 = []		
	private List F9_FILTER_CAND_INFO_LIST_8 = []		
	
	private List F10_APP_SPEED_CAND_INFO_LIST_1 = []		
	private List F10_APP_SPEED_CAND_INFO_LIST_2 = []		
	private List F11_SPEED_CAND_INFO_LIST_1 = []		
	private List F11_SPEED_CAND_INFO_LIST_2 = []		
	
	private List F12_APP_ROTATION_CAND_INFO_LIST_1 = []		
	private List F13_ROTATION_CAND_INFO_LIST_1 = []		

	private List F14_APP_DISTORTION_CAND_INFO_LIST_1 = []		
	private List F15_DISTORTION_CAND_INFO_LIST_1 = []		

	private List F16_COLD_SEARCH_CAND_INFO_LIST_01 = []		
	private List F16_COLD_SEARCH_CAND_INFO_LIST_02 = []		
	private List F16_COLD_SEARCH_CAND_INFO_LIST_03 = []	
	private List F16_COLD_SEARCH_CAND_INFO_LIST_04 = []	
	private List F16_COLD_SEARCH_CAND_INFO_LIST_05 = []	
	private List F16_COLD_SEARCH_CAND_INFO_LIST_06 = []	
	private List F16_COLD_SEARCH_CAND_INFO_LIST_07 = []	
	private List F16_COLD_SEARCH_CAND_INFO_LIST_08 = []	
	private List F16_COLD_SEARCH_CAND_INFO_LIST_09 = []	
	private List F16_COLD_SEARCH_CAND_INFO_LIST_10 = []	
	private List F16_COLD_SEARCH_CAND_INFO_LIST_11 = []	
	private List F16_COLD_SEARCH_CAND_INFO_LIST_12 = []	
	private List F16_COLD_SEARCH_CAND_INFO_LIST_13 = []	
	private List F16_COLD_SEARCH_CAND_INFO_LIST_14 = []	
	private List F16_COLD_SEARCH_CAND_INFO_LIST_15 = []	
	private List F16_COLD_SEARCH_CAND_INFO_LIST_16 = []	
	private List F16_COLD_SEARCH_CAND_INFO_LIST_17 = []	
	private List F16_COLD_SEARCH_CAND_INFO_LIST_18 = []	
	
	private List F17_TARGET_DB_CAND_INFO_LIST_1 = []
	private List F17_TARGET_DB_CAND_INFO_LIST_2 = []
	private List F17_TARGET_DB_CAND_INFO_LIST_3 = []
	private List F17_TARGET_DB_CAND_INFO_LIST_4 = []
	
	private List F18_CONSOLIDATE_CAND_INFO_LIST_1 = []
	private List F18_CONSOLIDATE_CAND_INFO_LIST_2 = []
	private List F18_CONSOLIDATE_CAND_INFO_LIST_3 = []

	private List F19_PRIORITY_CAND_INFO_LIST_1 = []
	
	private List F32_CONSOLIDATE_CAND_INFO_LIST_1 = []
	private List F32_CONSOLIDATE_CAND_INFO_LIST_2 = []
		
	private List F20_LOC_CAND_INFO_LIST_1 = []
	private List F20_LOC_CAND_INFO_LIST_2 = []
	
	private List F21_MIN_CAND_INFO_LIST_1 = []
	private List F21_MIN_CAND_INFO_LIST_2 = []
	private List F21_MIN_CAND_INFO_LIST_3 = []
	private List F21_MIN_CAND_INFO_LIST_4 = []
	private List F21_MIN_CAND_INFO_LIST_5 = []
	
	private List F22_DYN_CAND_INFO_LIST_1 = []
	private List F22_DYN_CAND_INFO_LIST_2 = []
	private List F22_DYN_CAND_INFO_LIST_3 = []
	private List F22_DYN_CAND_INFO_LIST_4 = []
	private List F22_DYN_CAND_INFO_LIST_5 = []
	
	private List F24_LOST_CAND_INFO_LIST_1 = []
	private List F24_LOST_CAND_INFO_LIST_2 = []
	private List F24_LOST_CAND_INFO_LIST_3 = []
	
	private List F26_YOB_CAND_INFO_LIST_1 = []
	private List F26_YOB_CAND_INFO_LIST_2 = []
	private List F26_YOB_CAND_INFO_LIST_3 = []
	private List F26_YOB_CAND_INFO_LIST_4 = []

	private List F28_AFIS_CAND_INFO_LIST_1 = []
	private List F28_AFIS_CAND_INFO_LIST_2 = []
	private List F28_AFIS_CAND_INFO_LIST_3 = []
	private List F28_AFIS_CAND_INFO_LIST_4 = []
	private List F28_AFIS_CAND_INFO_LIST_5 = []
	private List F28_AFIS_CAND_INFO_LIST_6 = []
	
	private List F29_SCOPE12_CAND_INFO_LIST_1 = []
	private List F29_SCOPE12_CAND_INFO_LIST_2 = []
	private List F29_SCOPE12_CAND_INFO_LIST_3 = []
	private List F29_SCOPE12_CAND_INFO_LIST_4 = []
	private List F29_SCOPE12_CAND_INFO_LIST_5 = []
	private List F29_SCOPE12_CAND_INFO_LIST_6 = []
	private List F29_SCOPE12_CAND_INFO_LIST_7 = []
	private List F29_SCOPE12_CAND_INFO_LIST_8 = []

	private List F31_SCOPE123_CAND_INFO_LIST_1 = []
	private List F31_SCOPE123_CAND_INFO_LIST_2 = []
	private List F31_SCOPE123_CAND_INFO_LIST_3 = []
	private List F31_SCOPE123_CAND_INFO_LIST_4 = []
	private List F31_SCOPE123_CAND_INFO_LIST_5 = []
	private List F31_SCOPE123_CAND_INFO_LIST_6 = []
	private List F31_SCOPE123_CAND_INFO_LIST_7 = []
	private List F31_SCOPE123_CAND_INFO_LIST_8 = []
	
	private List F30_FW_CAND_INFO_LIST_1 = []
	private List F30_FW_CAND_INFO_LIST_2 = []
	private List F30_FW_CAND_INFO_LIST_3 = []
	private List F30_FW_CAND_INFO_LIST_4 = []
	private List F30_FW_CAND_INFO_LIST_5 = []

	private List F33_APP_CARD_CAND_INFO_LIST_1 = []
	private List F33_APP_CARD_CAND_INFO_LIST_2 = []
	private List F34_CARD_CAND_INFO_LIST_1 = []
	private List F34_CARD_CAND_INFO_LIST_2 = []
	private List F35_APP_MATE_CAND_INFO_LIST_1 = []
	private List F35_APP_MATE_CAND_INFO_LIST_2 = []
	private List F36_MATE_CAND_INFO_LIST_1 = []
	private List F36_MATE_CAND_INFO_LIST_2 = []
	private List F37_APP_FINAL_CAND_INFO_LIST_1 = []
	private List F38_FINAL_CAND_INFO_LIST_1 = []
	private List F38_FINAL_CAND_INFO_LIST_2 = []
	private List F38_FINAL_CAND_INFO_LIST_3 = []

	private List F39_SEARCH_MODE_CAND_INFO_LIST_1 = []
	private List F39_SEARCH_MODE_CAND_INFO_LIST_2 = []
	
	private List F40_FT_APP_MATCHABLE_CAND_INFO_LIST_1 = []
	private List F40_FT_APP_MATCHABLE_CAND_INFO_LIST_2 = []
	private List F41_FT_MATCHABLE_CAND_INFO_LIST_1 = []
	private List F42_FT_FINGER_CAND_INFO_LIST_1 = []
	private List F42_FT_FINGER_CAND_INFO_LIST_2 = []
	private List F42_FT_FINGER_CAND_INFO_LIST_3 = []
	private List F42_FT_FINGER_CAND_INFO_LIST_4 = []
	private List F42_FT_FINGER_CAND_INFO_LIST_5 = []
	private List F43_FT_PATTERN_CAND_INFO_LIST_1 = []
	private List F44_FT_CARD_CAND_INFO_LIST_1 = []
	private List F44_FT_CARD_CAND_INFO_LIST_2 = []
	private List F45_FT_MATE_CAND_INFO_LIST_1 = []
	private List F45_FT_MATE_CAND_INFO_LIST_2 = []
	private List F46_FT_FINAL_CAND_INFO_LIST_1 = []
	private List F46_FT_FINAL_CAND_INFO_LIST_2 = []
	private List F47_FT_SPEED_CAND_INFO_LIST_1 = []
	
	private List F48_HIGH_A_CAND_INFO_LIST = []
	private List F48_HIGH_B_CAND_INFO_LIST = []
	private List F48_HIGH_C_CAND_INFO_LIST = []
	private List F48_LOW_A_CAND_INFO_LIST = []
	private List F48_LOW_B_CAND_INFO_LIST = []
	private List F48_LOW_C_CAND_INFO_LIST = []

	private List CML_PARAMID_CAND_INFO_LIST_1 = []
	private List CML_PARAMID_CAND_INFO_LIST_2 = []
	private List CML_PARAMID_CAND_INFO_LIST_3 = []
	private List CML_PARAMID_CAND_INFO_LIST_4 = []

	private List CML_ROTATION_1_CAND_INFO_LIST = []
	private List CML_ROTATION_3_CAND_INFO_LIST = []

	private List F49_FT_APP_MATCHABLE_CAND_INFO_LIST_1 = []
	
	private List AGGREGATION_CAND_INFO_LIST_1 = []
	private List AGGREGATION_CAND_INFO_LIST_2 = []
	private List AGGREGATION_CAND_INFO_LIST_3 = []
	private List AGGREGATION_CAND_INFO_LIST_4 = []

	private List MAX_INDIVIDUAL_SCORES_ROLL_1 = [] 
	private List MAX_INDIVIDUAL_SCORES_ROLL_2 = [] 
	private List MAX_INDIVIDUAL_SCORES_SLAP = []
	private List ROT_BY_AXIS_INDIVIDUAL_SCORES = []
	private	List MAX_SCORE_CANDIDATE_1 = []
	private	List MAX_SCORE_CANDIDATE_2 = []
	private	List MAX_SCORE_CANDIDATE_3 = []
	private	List MAX_SCORE_CANDIDATE_4 = []
	private	List MAX_SCORE_CANDIDATE_5 = []
	private	List MAX_SCORE_CANDIDATE_SCOPE2_1 = []
	private	List MAX_SCORE_CANDIDATE_SCOPE2_2 = []
	private	List MAX_SCORE_CANDIDATE_SCOPE2_3 = []
	private	List MAX_SCORE_CANDIDATE_SCOPE2_4 = []
	private	List MAX_SCORE_CANDIDATE_SCOPE2_5 = []
	private	List MAX_SCORE_CANDIDATE_SCOPE3_1 = []
	private	List MAX_SCORE_CANDIDATE_SCOPE3_2 = []
	private	List MAX_SCORE_CANDIDATE_SCOPE3_3 = []
	private	List MAX_SCORE_CANDIDATE_SCOPE3_4 = []
	private	List MAX_SCORE_CANDIDATE_SCOPE3_5 = []
	private List BASIC_SCORE_CANDIDATE_1 = []
	private List BASIC_SCORE_CANDIDATE_2 = []
	private List PATTERN_SCORE_CANDIDATE_1 = []
	private List SPEED_SCORE_CANDIDATE_1 = []
	private List SPEED_SCORE_CANDIDATE_2 = []
	private List AGGREGATION_CANDIDATE_1 = []
	private List AGGREGATION_CANDIDATE_2 = []
	private List AGGREGATION_CANDIDATE_3 = []
	private List AGGREGATION_CANDIDATE_4 = []
	private	List EXT_SORT_CANDIDATE_1 = []
	private	List CML_PARAMID_SCORE_CANDIDATE_1 = []
	private	List CML_PARAMID_SCORE_CANDIDATE_2 = []
	private	List CML_PARAMID_SCORE_CANDIDATE_3 = []
	private	List CML_PARAMID_SCORE_CANDIDATE_4 = []
	private List EXT_SORT_INDIVIDUAL_SCORES = []

	private List basicIScoreList1
	private List basicIScoreList2
	private List basicIScoreList3
	private List basicIScoreList4
	private List basicIScoreList5
	
	private List rotation1IScoreListR
	private List rotation2IScoreListR
	private List rotation1IScoreListS

    private String level = "high"
    private TimPayloadHelper payloadHelper
	private String timEngine


	TimHelper(context){
		super(context)
        this.payloadHelper = new TimPayloadHelper(context)
		this.timEngine = new GlobalProperties(context).getTimEngine().toUpperCase()
		initCandInfoLists()
	}

	TimHelper(context, String level){
		this(context)
        this.level = level
	}

	private void initCandInfoLists() {
		initScores()
		initCommonCandInfoList()
		initPatternCandInfoList()
		initGenderCandInfoList()
		initYobCandInfoList()
		initColdSearchCandInfoList()
		initTargetDbCandInfoList()
		initConsolidateCandInfoList()
		initLocCandInfoList()
		initMinCandInfoList()
		initDynCandInfoList()
		initLostCandInfoList()
		initAfisCandInfoList()
		initScopeCandInfoList()
		initFWeightCandInfoList()
		initSortCandInfoList()
		initFingerThresholdCandInfoList()
		initParamIdCandInfoList()
	}

	private void initScores() {
		setBaseAsserionScore()
		basic_cscore_1 = mergeFWeight(BASIC_CSCORE_1, rollFW)
		basic_score_1 = basic_cscore_1
		basic_score_1_1F = mergeFWeight(BASIC_SCORE_1_1F, rollFW)
		basic_score_2_1F = mergeFWeight(BASIC_SCORE_2_1F, rollFW)
		basic_score_2_2F = mergeFWeight(BASIC_SCORE_2_2F, rollFW)
		basic_score_2_3F = mergeFWeight(BASIC_SCORE_2_3F, rollFW)
		basic_score_2_5F = mergeFWeight(BASIC_SCORE_2_5F, rollFW)
		basic_score_2_6F = mergeFWeight(BASIC_SCORE_2_6F, rollFW)
		basic_score_2_10F = mergeFWeight(BASIC_SCORE_2_10F, rollFW)
		
		basic_score_2 = cutoffScore(basic_score_2_1F + basic_score_2_2F + basic_score_2_3F + basic_score_2_5F + basic_score_2_6F + basic_score_2_10F)
		
		if(timEngine == CML) {
			basic_cscore_3 = mergeFWeight(BASIC_CSCORE_3, rollFW)
		} else {
			basic_cscore_3 = mergeFWeight(BASIC_CSCORE_3, rollFW)
		}
		
		basic_score_3_1F = mergeFWeight(BASIC_SCORE_3_1F, rollFW)
		basic_cscore_4 = mergeFWeight(BASIC_CSCORE_4, slapFW)
		basic_score_4_1F = mergeFWeight(BASIC_SCORE_4_1F, slapFW)
		basic_cscore_5 = mergeFWeight(BASIC_CSCORE_5, slapFW)
		basic_score_5_1F = mergeFWeight(BASIC_SCORE_5_1F, slapFW)

		basic_score_6_1F = mergeFWeight(BASIC_SCORE_6_1F, rollFW)
		basic_score_6_3F = mergeFWeight(BASIC_SCORE_6_3F, rollFW)
		basic_score_6_5F = mergeFWeight(BASIC_SCORE_6_5F, rollFW)
		basic_score_6_7F = mergeFWeight(BASIC_SCORE_6_7F, rollFW)
		basic_score_6_9F = mergeFWeight(BASIC_SCORE_6_9F, rollFW)
		basic_score_6_10F = mergeFWeight(BASIC_SCORE_6_10F, rollFW)

		basic_score_7_1F = mergeFWeight(BASIC_SCORE_7_1F, rollFW)
		basic_score_7_2F = mergeFWeight(BASIC_SCORE_7_2F, rollFW)
		basic_score_7_3F = mergeFWeight(BASIC_SCORE_7_3F, rollFW)
		basic_score_7_5F = mergeFWeight(BASIC_SCORE_7_5F, rollFW)
		basic_score_7_6F = mergeFWeight(BASIC_SCORE_7_6F, rollFW)
		basic_score_7_7F = mergeFWeight(BASIC_SCORE_7_7F, rollFW)
		basic_score_7_8F = mergeFWeight(BASIC_SCORE_7_8F, rollFW)
		basic_score_7_9F = mergeFWeight(BASIC_SCORE_7_9F, rollFW)
		basic_score_7_10F = mergeFWeight(BASIC_SCORE_7_10F, rollFW)

		basic_score_8_1F = mergeFWeight(BASIC_SCORE_8_1F, slapFW)
		basic_score_8_9F = mergeFWeight(BASIC_SCORE_8_9F, slapFW)
		
		if(timEngine == CML) {
			basic_score_6 = cutoffScore(basic_score_6_1F + basic_score_6_10F)
		} else {
			basic_score_6 = BASIC_CSCORE_6
		}

		if(timEngine == CML) {
			basic_score_7 = cutoffScore(basic_score_7_1F + basic_score_7_2F + basic_score_7_7F + basic_score_7_10F)
		} else {
			basic_score_7 = BASIC_CSCORE_7
		}
        basic_score_8 = cutoffScore(basic_score_8_1F + basic_score_8_9F)

		basic_cscore_11 = mergeFWeight(BASIC_CSCORE_11, rollFW)
	}

	private void initCommonCandInfoList(){
		
		MAX_INDIVIDUAL_SCORES_ROLL_1 =
				[	[ MAX_SCORE, FIN_1, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_2, PC2_ROLLED, rollFW ],
					[ MAX_OR_ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_4, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_5, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_6, PC2_ROLLED, rollFW ],
					[ MAX_OR_ZERO_SCORE, FIN_7, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_8, PC2_ROLLED, rollFW ],
					[ MAX_OR_ZERO_SCORE, FIN_9, PC2_ROLLED, rollFW ],
					[ MAX_OR_ZERO_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] 

		MAX_INDIVIDUAL_SCORES_SLAP =
				[	[ MAX_SCORE, FIN_1, PC2_SLAP, slapFW ],
					[ MAX_OR_ZERO_SCORE, FIN_2, PC2_SLAP, slapFW ],
					[ MAX_SCORE, FIN_3, PC2_SLAP, slapFW ],
					[ MAX_SCORE, FIN_4, PC2_SLAP, slapFW ],
					[ MAX_OR_ZERO_SCORE, FIN_5, PC2_SLAP, slapFW ],
					[ MAX_SCORE, FIN_6, PC2_SLAP, slapFW ],
					[ MAX_OR_ZERO_SCORE, FIN_7, PC2_SLAP, slapFW ],
					[ MAX_SCORE, FIN_8, PC2_SLAP, slapFW ],
					[ MAX_SCORE, FIN_9, PC2_SLAP, slapFW ],
					[ MAX_OR_ZERO_SCORE, FIN_10, PC2_SLAP, slapFW ] ]

		MAX_INDIVIDUAL_SCORES_ROLL_2 =
				[	[ MAX_SCORE, FIN_1, PC2_ROLLED, rollFW ],
					[ MAX_OR_ZERO_SCORE, FIN_2, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_3, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_4, PC2_ROLLED, rollFW ],
					[ MAX_OR_ZERO_SCORE, FIN_5, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_6, PC2_ROLLED, rollFW ],
					[ MAX_OR_ZERO_SCORE, FIN_7, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_8, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_9, PC2_ROLLED, rollFW ],
					[ MAX_OR_ZERO_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] 

		ROT_BY_AXIS_INDIVIDUAL_SCORES = 
			[	[  1, eventId, reqIndexZero, MAX_SCORE,
					[	[ ROT_BY_AXIS_SCORE, FIN_1, PC2_ROLLED, rollFW ],
						[ ROT_BY_AXIS_SCORE, FIN_2, PC2_ROLLED, rollFW ],
						[ ROT_BY_AXIS_SCORE, FIN_3, PC2_ROLLED, rollFW ],
						[ ROT_BY_AXIS_SCORE, FIN_4, PC2_ROLLED, rollFW ],
						[ ROT_BY_AXIS_SCORE, FIN_5, PC2_ROLLED, rollFW ],
						[ ROT_BY_AXIS_SCORE, FIN_6, PC2_ROLLED, rollFW ],
						[ ROT_BY_AXIS_SCORE, FIN_7, PC2_ROLLED, rollFW ],
						[ ROT_BY_AXIS_SCORE, FIN_8, PC2_ROLLED, rollFW ],
						[ ROT_BY_AXIS_SCORE, FIN_9, PC2_ROLLED, rollFW ],
						[ ROT_BY_AXIS_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ] ]
		
		MAX_SCORE_CANDIDATE_1 =
			  [ 331, eventId, reqIndexZero, MAX_SCORE, MAX_INDIVIDUAL_SCORES_ROLL_1 ]
		MAX_SCORE_CANDIDATE_2 =
			  [ 332, eventId, reqIndexZero, MAX_SCORE, MAX_INDIVIDUAL_SCORES_SLAP ]
		MAX_SCORE_CANDIDATE_3 =
			  [ 331, eventId, reqIndexOne, MAX_SCORE, MAX_INDIVIDUAL_SCORES_ROLL_1 ]
		MAX_SCORE_CANDIDATE_4 =
			  [ 332, eventId, reqIndexOne, MAX_SCORE, MAX_INDIVIDUAL_SCORES_SLAP ]
		MAX_SCORE_CANDIDATE_5 =
			  [ 332, eventId, reqIndexZero, MAX_SCORE, MAX_INDIVIDUAL_SCORES_ROLL_2 ]

		MAX_SCORE_CANDIDATE_SCOPE2_1 =
			  [ 1331, eventId, reqIndexZero, MAX_SCORE, MAX_INDIVIDUAL_SCORES_ROLL_1 ]
		MAX_SCORE_CANDIDATE_SCOPE2_2 =
			  [ 1332, eventId, reqIndexZero, MAX_SCORE, MAX_INDIVIDUAL_SCORES_SLAP ]
		MAX_SCORE_CANDIDATE_SCOPE2_3 =
			  [ 1331, eventId, reqIndexOne, MAX_SCORE, MAX_INDIVIDUAL_SCORES_ROLL_1 ]
		MAX_SCORE_CANDIDATE_SCOPE2_4 =
			  [ 1332, eventId, reqIndexOne, MAX_SCORE, MAX_INDIVIDUAL_SCORES_SLAP ]
		MAX_SCORE_CANDIDATE_SCOPE2_5 =
			  [ 1332, eventId, reqIndexZero, MAX_SCORE, MAX_INDIVIDUAL_SCORES_ROLL_2 ]

		MAX_SCORE_CANDIDATE_SCOPE3_1 =
			  [ 2331, eventId, reqIndexZero, MAX_SCORE, MAX_INDIVIDUAL_SCORES_ROLL_1 ]
		MAX_SCORE_CANDIDATE_SCOPE3_2 =
			  [ 2332, eventId, reqIndexZero, MAX_SCORE, MAX_INDIVIDUAL_SCORES_SLAP ]
		MAX_SCORE_CANDIDATE_SCOPE3_3 =
			  [ 2331, eventId, reqIndexOne, MAX_SCORE, MAX_INDIVIDUAL_SCORES_ROLL_1 ]
		MAX_SCORE_CANDIDATE_SCOPE3_4 =
			  [ 2332, eventId, reqIndexOne, MAX_SCORE, MAX_INDIVIDUAL_SCORES_SLAP ]
		MAX_SCORE_CANDIDATE_SCOPE3_5 =
			  [ 2332, eventId, reqIndexZero, MAX_SCORE, MAX_INDIVIDUAL_SCORES_ROLL_2 ]
	
		BASIC_SCORE_CANDIDATE_1 =
			  [ 331, eventId, reqIndexZero, BASIC_CSCORE_1, basicIScoreList1 ] 

		int BASIC_SCORE_CANDIDATE_2_COMPOSITE = BASIC_SCORE_2_1F + BASIC_SCORE_2_2F + BASIC_SCORE_2_3F + 
			BASIC_SCORE_2_5F + BASIC_SCORE_2_6F + BASIC_SCORE_2_10F
		BASIC_SCORE_CANDIDATE_2 =
			  [ 331, eventId, reqIndexZero, BASIC_SCORE_CANDIDATE_2_COMPOSITE,
				[	[ BASIC_SCORE_2_1F, FIN_1, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_2_2F, FIN_2, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_2_3F, FIN_3, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_2_5F, FIN_5, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_2_6F, FIN_6, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_7, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_8, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_9, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_2_10F, FIN_10, PC2_ROLLED, rollFW ] ] ] 

		SPEED_SCORE_CANDIDATE_1 =
				 [ 331, eventId, reqIndexZero, basic_score_6,
					[	[ BASIC_SCORE_6_1F, FIN_1, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_2, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_6_3F, FIN_3, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_6_5F, FIN_5, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_6, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_6_7F, FIN_7, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_8, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_6_9F, FIN_9, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_6_10F, FIN_10, PC2_ROLLED, rollFW ] ] ] 

		SPEED_SCORE_CANDIDATE_2 =
				 [ 331, eventId, reqIndexZero, basic_score_7,
					[	[ BASIC_SCORE_7_1F, FIN_1, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_7_2F, FIN_2, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_7_3F, FIN_3, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_7_5F, FIN_5, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_7_6F, FIN_6, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_7_7F, FIN_7, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_7_8F, FIN_8, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_7_9F, FIN_9, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_7_10F, FIN_10, PC2_ROLLED, rollFW ] ] ] 

		F1_CARD_QUALITY_CAND_INFO_LIST_1 = 
	         [ F1_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F1_CARD_QUALITY_CAND_INFO_LIST_2 = 
	         [ F1_EXT_ID + NUMBER_02, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F1_CARD_QUALITY_CAND_INFO_LIST_3 = 
	         [ F1_EXT_ID + NUMBER_03, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]

		F7_8_FINGER_CAND_INFO_LIST_1 =
			 [ F7_8_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]

		F9_FILTER_CAND_INFO_LIST_1 = 
		 	 [ F9_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F9_FILTER_CAND_INFO_LIST_2 = 
		 	 [ F9_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F9_FILTER_CAND_INFO_LIST_3 = 
		 	 [ F9_EXT_ID + NUMBER_02, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F9_FILTER_CAND_INFO_LIST_4 = 
		 	 [ F9_EXT_ID + NUMBER_02, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F9_FILTER_CAND_INFO_LIST_5 = 
		 	 [ F9_EXT_ID + NUMBER_03, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F9_FILTER_CAND_INFO_LIST_6 = 
		 	 [ F9_EXT_ID + NUMBER_03, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F9_FILTER_CAND_INFO_LIST_7 = 
		 	 [ F9_EXT_ID + NUMBER_04, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F9_FILTER_CAND_INFO_LIST_8 = 
		 	 [ F9_EXT_ID + NUMBER_04, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
	
		F10_APP_SPEED_CAND_INFO_LIST_1 =
			 [ F10_EXT_ID + NUMBER_01, basic_score_7, true, [ SPEED_SCORE_CANDIDATE_2 ] ]
			 
		F10_APP_SPEED_CAND_INFO_LIST_2 =
			 [ F10_EXT_ID + NUMBER_01, basic_score_1, true, [ BASIC_SCORE_CANDIDATE_1 ] ]

		F11_SPEED_CAND_INFO_LIST_1 =
			 [ F11_EXT_ID + NUMBER_01, basic_score_6, true, [ SPEED_SCORE_CANDIDATE_1 ] ]
		F11_SPEED_CAND_INFO_LIST_2 =
			 [ F11_EXT_ID + NUMBER_01, basic_score_1, true, [ BASIC_SCORE_CANDIDATE_1 ] ]

		F12_APP_ROTATION_CAND_INFO_LIST_1 =
			 [ F12_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1, MAX_SCORE_CANDIDATE_4  ] ] 

		F13_ROTATION_CAND_INFO_LIST_1 =
			 [ F13_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]

		F14_APP_DISTORTION_CAND_INFO_LIST_1 =
			 [ F14_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]	
		F15_DISTORTION_CAND_INFO_LIST_1 =
			 [ F15_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]

		F33_APP_CARD_CAND_INFO_LIST_1 = 
			 [ F33_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ] 
		F33_APP_CARD_CAND_INFO_LIST_2 = 
			 [ F33_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ] 

		F34_CARD_CAND_INFO_LIST_1 = 
			 [ F34_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ] 
		F34_CARD_CAND_INFO_LIST_2 = 
			 [ F34_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ] 

		F35_APP_MATE_CAND_INFO_LIST_1 = 
			 [ F35_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ] 
		F35_APP_MATE_CAND_INFO_LIST_2 = 
			 [ F35_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ] 

		F36_MATE_CAND_INFO_LIST_1 = 
			 [ F36_EXT_ID + NUMBER_01, MAX_SCORE, true,
				[ [ 331, eventId, reqIndexZero, MAX_SCORE,
                	[   [ MAX_SCORE, FIN_1, PC2_ROLLED, rollFW ],
                	    [ MAX_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                	    [ MAX_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                	    [ MAX_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                	    [ MAX_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                	    [ MAX_SCORE, FIN_6, PC2_ROLLED, rollFW ],
                	    [ MAX_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                	    [ MAX_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                	    [ MAX_SCORE, FIN_9, PC2_ROLLED, rollFW ],
                	    [ 7145, FIN_10, PC2_ROLLED, rollFW ] ] ] ] ]

		F36_MATE_CAND_INFO_LIST_2 = 
			 [ F36_EXT_ID + NUMBER_01, MAX_SCORE, true,
				[ [ 331, eventId, reqIndexZero, MAX_SCORE,
                	[   [ MAX_SCORE, FIN_1, PC2_ROLLED, rollFW ],
                	    [ MAX_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                	    [ MAX_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                	    [ MAX_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                	    [ MAX_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                	    [ MAX_SCORE, FIN_6, PC2_ROLLED, rollFW ],
                	    [ MAX_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                	    [ MAX_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                	    [ MAX_SCORE, FIN_9, PC2_ROLLED, rollFW ],
                	    [ ZERO_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ] ] ]

		F37_APP_FINAL_CAND_INFO_LIST_1 = 
			[ F37_EXT_ID + NUMBER_01, 1071, true,
				[ 
					[ 331, eventId, reqIndexZero, 466,
                    [   [ BASIC_SCORE_1_1F, FIN_1, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_6, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_9, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_10, PC2_ROLLED, rollFW ] ]
				],
					[ 331, eventId, reqIndexOne, basic_cscore_11,
                    [   [ BASIC_SCORE_11_1F, FIN_1, PC2_SLAP, rollFW ],
                        [ ZERO_SCORE, FIN_2, PC2_SLAP, rollFW ],
                        [ ZERO_SCORE, FIN_3, PC2_SLAP, rollFW ],
                        [ ZERO_SCORE, FIN_4, PC2_SLAP, rollFW ],
                        [ ZERO_SCORE, FIN_5, PC2_SLAP, rollFW ],
                        [ BASIC_SCORE_11_6F, FIN_6, PC2_SLAP, rollFW ],
                        [ ZERO_SCORE, FIN_7, PC2_SLAP, rollFW ],
                        [ ZERO_SCORE, FIN_8, PC2_SLAP, rollFW ],
                        [ BASIC_SCORE_11_9F, FIN_9, PC2_SLAP, rollFW ],
                        [ BASIC_SCORE_11_10F, FIN_10, PC2_SLAP, rollFW ] ]
				]
				]
			]

		F38_FINAL_CAND_INFO_LIST_1 = 
			 [ F38_EXT_ID + NUMBER_01, basic_score_2, false, [ BASIC_SCORE_CANDIDATE_2 ] ]
		F38_FINAL_CAND_INFO_LIST_2 = 
			 [ F38_EXT_ID + NUMBER_02, basic_score_1, false, [ BASIC_SCORE_CANDIDATE_1 ] ]
		F38_FINAL_CAND_INFO_LIST_3 = 
			 [ F38_EXT_ID + NUMBER_03, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ] 

		F39_SEARCH_MODE_CAND_INFO_LIST_1 = 
			 [ F39_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ] 
		F39_SEARCH_MODE_CAND_INFO_LIST_2 = 
			 [ F39_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ] 
			
		AGGREGATION_CANDIDATE_1 =
				 [ 331, 1, reqIndexZero, basic_score_7,
					[	[ BASIC_SCORE_7_1F, FIN_1, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_7_2F, FIN_2, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_7_3F, FIN_3, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_7_5F, FIN_5, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_7_6F, FIN_6, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_7_7F, FIN_7, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_7_8F, FIN_8, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_7_9F, FIN_9, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_7_10F, FIN_10, PC2_ROLLED, rollFW ] ] ] 

		AGGREGATION_CANDIDATE_2 =
				 [ 331, 2, reqIndexZero, basic_score_7,
					[	[ BASIC_SCORE_7_1F, FIN_1, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_7_2F, FIN_2, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_7_3F, FIN_3, PC2_ROLLED, rollFW ],
						[ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_7_5F, FIN_5, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_7_6F, FIN_6, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_7_7F, FIN_7, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_7_8F, FIN_8, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_7_9F, FIN_9, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_7_10F, FIN_10, PC2_ROLLED, rollFW ] ] ] 

		AGGREGATION_CANDIDATE_3 =
				 [ 331, 1, reqIndexZero, BASIC_CSCORE_1, basicIScoreList1 ]

		AGGREGATION_CANDIDATE_4 =
				 [ 331, 2, reqIndexZero, BASIC_CSCORE_1, basicIScoreList1 ]

		AGGREGATION_CAND_INFO_LIST_1 =
			 [ F10_EXT_ID + NUMBER_01, basic_score_7, true, [ AGGREGATION_CANDIDATE_1 ] ]

		AGGREGATION_CAND_INFO_LIST_2 =
			 [ F10_EXT_ID + NUMBER_01, basic_score_7, true, [ AGGREGATION_CANDIDATE_2 ] ]

		AGGREGATION_CAND_INFO_LIST_3 =
			 [ F10_EXT_ID + NUMBER_01, BASIC_CSCORE_1, true, [ AGGREGATION_CANDIDATE_3 ] ]

		AGGREGATION_CAND_INFO_LIST_4 =
			 [ F10_EXT_ID + NUMBER_01, BASIC_CSCORE_1, true, [ AGGREGATION_CANDIDATE_4 ] ]

		basicIScoreList1 = 
					[	[ BASIC_SCORE_1_1F, FIN_1, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_1_2F, FIN_2, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_1_3F, FIN_3, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_1_4F, FIN_4, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_1_5F, FIN_5, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_1_6F, FIN_6, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_1_7F, FIN_7, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_1_8F, FIN_8, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_1_9F, FIN_9, PC2_ROLLED, rollFW ],
						[ BASIC_SCORE_1_10F, FIN_10, PC2_ROLLED, rollFW ] ]
		basicIScoreList3 = 
                    [   [ BASIC_SCORE_3_1F, FIN_1, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_3_2F, FIN_2, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_3_3F, FIN_3, PC2_ROLLED, rollFW ],
	                    [ BASIC_SCORE_3_4F, FIN_4, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_3_5F, FIN_5, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_3_6F, FIN_6, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_3_7F, FIN_7, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_3_8F, FIN_8, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_3_9F, FIN_9, PC2_ROLLED, rollFW ],
                        [ BASIC_SCORE_3_10F, FIN_10, PC2_ROLLED, rollFW ] ]
		basicIScoreList4 = 
					[	[ BASIC_SCORE_4_1F, FIN_1, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_4_2F, FIN_2, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_4_3F, FIN_3, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_4_4F, FIN_4, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_4_5F, FIN_5, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_4_6F, FIN_6, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_4_7F, FIN_7, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_4_8F, FIN_8, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_4_9F, FIN_9, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_4_10F, FIN_10, PC2_SLAP, slapFW ] ]
		basicIScoreList5 = 
					[	[ BASIC_SCORE_5_1F, FIN_1, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_5_2F, FIN_2, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_5_3F, FIN_3, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_5_4F, FIN_4, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_5_5F, FIN_5, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_5_6F, FIN_6, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_5_7F, FIN_7, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_5_8F, FIN_8, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_5_9F, FIN_9, PC2_SLAP, slapFW ],
						[ BASIC_SCORE_5_10F, FIN_10, PC2_SLAP, slapFW ] ]
		rotation1IScoreListR = 
					[	[ ROTATION_SCORE_1_R_1F, FIN_1, PC2_ROLLED, rollFW ],
						[ ROTATION_SCORE_1_R_2F, FIN_2, PC2_ROLLED, rollFW ],
						[ ROTATION_SCORE_1_R_3F, FIN_3, PC2_ROLLED, rollFW ],
						[ ROTATION_SCORE_1_R_4F, FIN_4, PC2_ROLLED, rollFW ],
						[ ROTATION_SCORE_1_R_5F, FIN_5, PC2_ROLLED, rollFW ],
						[ ROTATION_SCORE_1_R_6F, FIN_6, PC2_ROLLED, rollFW ],
						[ ROTATION_SCORE_1_R_7F, FIN_7, PC2_ROLLED, rollFW ],
						[ ROTATION_SCORE_1_R_8F, FIN_8, PC2_ROLLED, rollFW ],
						[ ROTATION_SCORE_1_R_9F, FIN_9, PC2_ROLLED, rollFW ],
						[ ROTATION_SCORE_1_R_10F, FIN_10, PC2_ROLLED, rollFW ] ]
		rotation1IScoreListS = 
					[	[ ROTATION_SCORE_1_S_1F, FIN_1, PC2_SLAP, slapFW ],
						[ ROTATION_SCORE_1_S_2F, FIN_2, PC2_SLAP, slapFW ],
						[ ROTATION_SCORE_1_S_3F, FIN_3, PC2_SLAP, slapFW ],
						[ ROTATION_SCORE_1_S_4F, FIN_4, PC2_SLAP, slapFW ],
						[ ROTATION_SCORE_1_S_5F, FIN_5, PC2_SLAP, slapFW ],
						[ ROTATION_SCORE_1_S_6F, FIN_6, PC2_SLAP, slapFW ],
						[ ROTATION_SCORE_1_S_7F, FIN_7, PC2_SLAP, slapFW ],
						[ ROTATION_SCORE_1_S_8F, FIN_8, PC2_SLAP, slapFW ],
						[ ROTATION_SCORE_1_S_9F, FIN_9, PC2_SLAP, slapFW ],
						[ ROTATION_SCORE_1_S_10F, FIN_10, PC2_SLAP, slapFW ] ]
		rotation2IScoreListR = 
					[	[ ROTATION_SCORE_2_R_1F, FIN_1, PC2_ROLLED, rollFW ],
						[ ROTATION_SCORE_2_R_2F, FIN_2, PC2_ROLLED, rollFW ],
						[ ROTATION_SCORE_2_R_3F, FIN_3, PC2_ROLLED, rollFW ],
						[ ROTATION_SCORE_2_R_4F, FIN_4, PC2_ROLLED, rollFW ],
						[ ROTATION_SCORE_2_R_5F, FIN_5, PC2_ROLLED, rollFW ],
						[ ROTATION_SCORE_2_R_6F, FIN_6, PC2_ROLLED, rollFW ],
						[ ROTATION_SCORE_2_R_7F, FIN_7, PC2_ROLLED, rollFW ],
						[ ROTATION_SCORE_2_R_8F, FIN_8, PC2_ROLLED, rollFW ],
						[ ROTATION_SCORE_2_R_9F, FIN_9, PC2_ROLLED, rollFW ],
						[ ROTATION_SCORE_2_R_10F, FIN_10, PC2_ROLLED, rollFW ] ]

		CML_ROTATION_1_CAND_INFO_LIST =
			[ F12_EXT_ID + NUMBER_01, ROTATION_CSCORE_1_R + ROTATION_CSCORE_1_S, true, 
				[ [ 331, 1, reqIndexZero, ROTATION_CSCORE_1_R, rotation1IScoreListR ], 
				  [ 332, 1, reqIndexOne, ROTATION_CSCORE_1_S, rotation1IScoreListS ] ] 
			]
		CML_ROTATION_3_CAND_INFO_LIST =
			[ F12_EXT_ID + NUMBER_01, ROTATION_CSCORE_2_R + basic_cscore_5, true, 
				[ [ 331, 1, reqIndexZero, ROTATION_CSCORE_2_R, rotation2IScoreListR ], 
				  [ 332, 1, reqIndexOne, basic_cscore_5, basicIScoreList5 ] ] 
			]
	}

	private void initPatternCandInfoList(){
		PATTERN_SCORE_CANDIDATE_1 = 
			[ 331, eventId, reqIndexZero, MAX_SCORE,
              [   [ 5750, FIN_1, PC2_ROLLED, rollFW ],
                  [ 4389, FIN_2, PC2_ROLLED, rollFW ],
                  [ 9116, FIN_3, PC2_ROLLED, rollFW ],
                  [ 1774, FIN_4, PC2_ROLLED, rollFW ],
                  [ 3502, FIN_5, PC2_ROLLED, rollFW ],
                  [ 2673, FIN_6, PC2_ROLLED, rollFW ],
                  [ 6405, FIN_7, PC2_ROLLED, rollFW ],
                  [ 5476, FIN_8, PC2_ROLLED, rollFW ],
                  [ 1712, FIN_9, PC2_ROLLED, rollFW ],
                  [ 4724, FIN_10, PC2_ROLLED, rollFW ] ] ] 

		F2_APP_PATTERN_THRESHOLD_CAND_INFO_LIST_1 = 
			 [ F2_EXT_ID + NUMBER_01, MAX_SCORE, true, [ PATTERN_SCORE_CANDIDATE_1 ] ]
		F3_PATTERN_THRESHOLD_CAND_INFO_LIST_1 = 
			 [ F3_EXT_ID + NUMBER_01, MAX_SCORE, true, [ PATTERN_SCORE_CANDIDATE_1 ] ]
	}
	
	private void initGenderCandInfoList(){

		F25_APP_GENDER_CAND_INFO_LIST_1 =
			[ F25_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F25_APP_GENDER_CAND_INFO_LIST_2 =
			[ F25_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F25_APP_GENDER_CAND_INFO_LIST_3 =
			[ F25_EXT_ID + NUMBER_02, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F25_APP_GENDER_CAND_INFO_LIST_4 =
			[ F25_EXT_ID + NUMBER_02, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F25_APP_GENDER_CAND_INFO_LIST_5 =
			[ F25_EXT_ID + NUMBER_03, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F25_APP_GENDER_CAND_INFO_LIST_6 =
			[ F25_EXT_ID + NUMBER_03, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]

		F4_GENDER_CAND_INFO_LIST_1 =
			 [ F4_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F4_GENDER_CAND_INFO_LIST_2 =
			 [ F4_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F4_GENDER_CAND_INFO_LIST_3 =
			 [ F4_EXT_ID + NUMBER_02, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F4_GENDER_CAND_INFO_LIST_4 =
			 [ F4_EXT_ID + NUMBER_02, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F4_GENDER_CAND_INFO_LIST_5 =
			 [ F4_EXT_ID + NUMBER_03, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F4_GENDER_CAND_INFO_LIST_6 =
			 [ F4_EXT_ID + NUMBER_03, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]

	}

	private void initYobCandInfoList(){
		F5_APP_YOB_THRESHOLD_CAND_INFO_LIST_01 =
			 [ F5_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F5_APP_YOB_THRESHOLD_CAND_INFO_LIST_02 =
			 [ F5_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F5_APP_YOB_THRESHOLD_CAND_INFO_LIST_03 =
			 [ F5_EXT_ID + NUMBER_02, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F5_APP_YOB_THRESHOLD_CAND_INFO_LIST_04 =
			 [ F5_EXT_ID + NUMBER_02, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F5_APP_YOB_THRESHOLD_CAND_INFO_LIST_05 =
			 [ F5_EXT_ID + NUMBER_03, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F5_APP_YOB_THRESHOLD_CAND_INFO_LIST_06 =
			 [ F5_EXT_ID + NUMBER_03, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F5_APP_YOB_THRESHOLD_CAND_INFO_LIST_07 =
			 [ F5_EXT_ID + NUMBER_04, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F5_APP_YOB_THRESHOLD_CAND_INFO_LIST_08 =
			 [ F5_EXT_ID + NUMBER_04, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F5_APP_YOB_THRESHOLD_CAND_INFO_LIST_09 =
			 [ F5_EXT_ID + NUMBER_05, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F5_APP_YOB_THRESHOLD_CAND_INFO_LIST_10 =
			 [ F5_EXT_ID + NUMBER_05, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
	
		F6_YOB_THRESHOLD_CAND_INFO_LIST_01 = 
			 [ F6_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F6_YOB_THRESHOLD_CAND_INFO_LIST_02 =
			 [ F6_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F6_YOB_THRESHOLD_CAND_INFO_LIST_03 =
			 [ F6_EXT_ID + NUMBER_02, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F6_YOB_THRESHOLD_CAND_INFO_LIST_04 =
			 [ F6_EXT_ID + NUMBER_02, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F6_YOB_THRESHOLD_CAND_INFO_LIST_05 =
			 [ F6_EXT_ID + NUMBER_03, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F6_YOB_THRESHOLD_CAND_INFO_LIST_06 =
			 [ F6_EXT_ID + NUMBER_03, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F6_YOB_THRESHOLD_CAND_INFO_LIST_07 =
			 [ F6_EXT_ID + NUMBER_04, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F6_YOB_THRESHOLD_CAND_INFO_LIST_08 =
			 [ F6_EXT_ID + NUMBER_04, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F6_YOB_THRESHOLD_CAND_INFO_LIST_09 =
			 [ F6_EXT_ID + NUMBER_05, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F6_YOB_THRESHOLD_CAND_INFO_LIST_10 =
			 [ F6_EXT_ID + NUMBER_05, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F6_YOB_THRESHOLD_CAND_INFO_LIST_11 =
			 [ F6_EXT_ID + NUMBER_06, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F6_YOB_THRESHOLD_CAND_INFO_LIST_12 =
			 [ F6_EXT_ID + NUMBER_06, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F6_YOB_THRESHOLD_CAND_INFO_LIST_13 =
			 [ F6_EXT_ID + NUMBER_07, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F6_YOB_THRESHOLD_CAND_INFO_LIST_14 =
			 [ F6_EXT_ID + NUMBER_07, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F6_YOB_THRESHOLD_CAND_INFO_LIST_15 =
			 [ F6_EXT_ID + NUMBER_08, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F6_YOB_THRESHOLD_CAND_INFO_LIST_16 =
			 [ F6_EXT_ID + NUMBER_08, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F6_YOB_THRESHOLD_CAND_INFO_LIST_17 =
			 [ F6_EXT_ID + NUMBER_09, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F6_YOB_THRESHOLD_CAND_INFO_LIST_18 =
			 [ F6_EXT_ID + NUMBER_09, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F6_YOB_THRESHOLD_CAND_INFO_LIST_19 =
			 [ F6_EXT_ID + NUMBER_10, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F6_YOB_THRESHOLD_CAND_INFO_LIST_20 = 
			 [ F6_EXT_ID + NUMBER_10, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		
		F26_YOB_CAND_INFO_LIST_1 =
			 [ F26_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		
		F26_YOB_CAND_INFO_LIST_2 =
			 [ F26_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]

		F26_YOB_CAND_INFO_LIST_3 =
			 [ F26_EXT_ID + NUMBER_02, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		
		F26_YOB_CAND_INFO_LIST_4 =
			 [ F26_EXT_ID + NUMBER_02, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]

	
		F27_YOB_CAND_INFO_LIST_01 =
			 [ F27_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F27_YOB_CAND_INFO_LIST_02 =
			 [ F27_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F27_YOB_CAND_INFO_LIST_03 =
			 [ F27_EXT_ID + NUMBER_02, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F27_YOB_CAND_INFO_LIST_04 =
			 [ F27_EXT_ID + NUMBER_02, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F27_YOB_CAND_INFO_LIST_05 =
			 [ F27_EXT_ID + NUMBER_03, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F27_YOB_CAND_INFO_LIST_06 =
			 [ F27_EXT_ID + NUMBER_03, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F27_YOB_CAND_INFO_LIST_07 =
			 [ F27_EXT_ID + NUMBER_04, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F27_YOB_CAND_INFO_LIST_08 =
			 [ F27_EXT_ID + NUMBER_04, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F27_YOB_CAND_INFO_LIST_09 =
			 [ F27_EXT_ID + NUMBER_05, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F27_YOB_CAND_INFO_LIST_10 =
			 [ F27_EXT_ID + NUMBER_05, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F27_YOB_CAND_INFO_LIST_11 =
			 [ F27_EXT_ID + NUMBER_06, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F27_YOB_CAND_INFO_LIST_12 =
			 [ F27_EXT_ID + NUMBER_06, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F27_YOB_CAND_INFO_LIST_13 =
			 [ F27_EXT_ID + NUMBER_07, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F27_YOB_CAND_INFO_LIST_14 =
			 [ F27_EXT_ID + NUMBER_07, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F27_YOB_CAND_INFO_LIST_15 =
			 [ F27_EXT_ID + NUMBER_08, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F27_YOB_CAND_INFO_LIST_16 =
			 [ F27_EXT_ID + NUMBER_08, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F27_YOB_CAND_INFO_LIST_17 =
			 [ F27_EXT_ID + NUMBER_09, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F27_YOB_CAND_INFO_LIST_18 =
			 [ F27_EXT_ID + NUMBER_09, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F27_YOB_CAND_INFO_LIST_19 =
			 [ F27_EXT_ID + NUMBER_10, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F27_YOB_CAND_INFO_LIST_20 =
			 [ F27_EXT_ID + NUMBER_10, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F27_YOB_CAND_INFO_LIST_21 =
			 [ F27_EXT_ID + NUMBER_11, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F27_YOB_CAND_INFO_LIST_22 =
			 [ F27_EXT_ID + NUMBER_11, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F27_YOB_CAND_INFO_LIST_23 =
			 [ F27_EXT_ID + NUMBER_12, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F27_YOB_CAND_INFO_LIST_24 =
			 [ F27_EXT_ID + NUMBER_12, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
	}

	private void initColdSearchCandInfoList(){
		F16_COLD_SEARCH_CAND_INFO_LIST_01 =
		 	 [ F16_EXT_ID_01 , MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F16_COLD_SEARCH_CAND_INFO_LIST_02 =
		 	 [ F16_EXT_ID_02 , MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F16_COLD_SEARCH_CAND_INFO_LIST_03 =
		 	 [ F16_EXT_ID_03 , MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F16_COLD_SEARCH_CAND_INFO_LIST_04 =
		 	 [ F16_EXT_ID_04 , MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F16_COLD_SEARCH_CAND_INFO_LIST_05 =
		 	 [ F16_EXT_ID_05 , MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F16_COLD_SEARCH_CAND_INFO_LIST_06 =
		 	 [ F16_EXT_ID_06 , MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F16_COLD_SEARCH_CAND_INFO_LIST_07 =
		 	 [ F16_EXT_ID_07 , MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F16_COLD_SEARCH_CAND_INFO_LIST_08 =
		 	 [ F16_EXT_ID_08 , MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F16_COLD_SEARCH_CAND_INFO_LIST_09 =
		 	 [ F16_EXT_ID_09 , MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F16_COLD_SEARCH_CAND_INFO_LIST_10 =
		 	 [ F16_EXT_ID_10 , MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F16_COLD_SEARCH_CAND_INFO_LIST_11 =
		 	 [ F16_EXT_ID_11 , MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F16_COLD_SEARCH_CAND_INFO_LIST_12 =
		 	 [ F16_EXT_ID_12 , MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F16_COLD_SEARCH_CAND_INFO_LIST_13 =
		 	 [ F16_EXT_ID_13 , MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F16_COLD_SEARCH_CAND_INFO_LIST_14 =
		 	 [ F16_EXT_ID_14 , MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F16_COLD_SEARCH_CAND_INFO_LIST_15 =
		 	 [ F16_EXT_ID_15 , MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F16_COLD_SEARCH_CAND_INFO_LIST_16 =
		 	 [ F16_EXT_ID_16 , MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F16_COLD_SEARCH_CAND_INFO_LIST_17 =
		 	 [ F16_EXT_ID_17 , MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F16_COLD_SEARCH_CAND_INFO_LIST_18 =
		 	 [ F16_EXT_ID_18 , MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
    
    }


	private void initTargetDbCandInfoList(){
		F17_TARGET_DB_CAND_INFO_LIST_1 =
			 [ F17_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ] 
		F17_TARGET_DB_CAND_INFO_LIST_2 =
			 [ F17_EXT_ID + NUMBER_02, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_2 ] ]
		F17_TARGET_DB_CAND_INFO_LIST_3 =
			 [ F17_EXT_ID + NUMBER_02, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F17_TARGET_DB_CAND_INFO_LIST_4 =
			 [ F17_EXT_ID + NUMBER_02, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_SCOPE2_4 ] ]
	}

	private void initConsolidateCandInfoList(){

		F18_CONSOLIDATE_CAND_INFO_LIST_1 = 
			[ F18_EXT_ID + NUMBER_01, basic_cscore_3, true, 
				[ [ 332, eventId, reqIndexZero, basic_cscore_3, basicIScoreList3 ],
				  [ 331, eventId, reqIndexZero, basic_cscore_1, basicIScoreList1 ]
				   ]
			]
	
		F18_CONSOLIDATE_CAND_INFO_LIST_2 = 
			[ F18_EXT_ID + NUMBER_01, basic_cscore_1 + basic_cscore_4, true, 
				[ [ 331, eventId, reqIndexZero, basic_cscore_1, basicIScoreList1 ],
				  [ 331, eventId, reqIndexOne, basic_cscore_4, basicIScoreList4 ] ]
			]

		F18_CONSOLIDATE_CAND_INFO_LIST_3 = 
			[ F18_EXT_ID + NUMBER_01, basic_cscore_3 + basic_cscore_5, true, 
				[ [ 332, eventId, reqIndexZero, basic_cscore_3, basicIScoreList3 ],
				  [ 331, eventId, reqIndexZero, basic_cscore_1, basicIScoreList1 ],
				  [ 332, eventId, reqIndexOne, basic_cscore_5, basicIScoreList5 ],
				  [ 331, eventId, reqIndexOne, basic_cscore_4, basicIScoreList4 ] ]
			]

		F32_CONSOLIDATE_CAND_INFO_LIST_1 = 
			[ F32_EXT_ID + NUMBER_01, basic_cscore_3, true, 
				[ [ 331, eventId, reqIndexZero, basic_cscore_1, basicIScoreList1 ],
				  [ 1331, eventId, reqIndexZero, basic_cscore_1, basicIScoreList1 ],
				  [ 332, eventId, reqIndexZero, basic_cscore_3, basicIScoreList3 ],
                  [ 1332, eventId, reqIndexZero, basic_cscore_3, basicIScoreList3 ] ]
			]
	
		F32_CONSOLIDATE_CAND_INFO_LIST_2 = 
			[ F32_EXT_ID + NUMBER_01, basic_cscore_3 + basic_cscore_5, true, 
				[ [ 331, eventId, reqIndexZero, basic_cscore_1, basicIScoreList1 ],
				  [ 1331, eventId, reqIndexZero, basic_cscore_1, basicIScoreList1 ],
				  [ 332, eventId, reqIndexZero, basic_cscore_3, basicIScoreList3 ],
				  [ 1332, eventId, reqIndexZero, basic_cscore_3, basicIScoreList3 ],
				  [ 331, eventId, reqIndexOne, basic_cscore_4, basicIScoreList4 ],
				  [ 1331, eventId, reqIndexOne, basic_cscore_4, basicIScoreList4 ],
				  [ 332, eventId, reqIndexOne, basic_cscore_5, basicIScoreList5 ],
				  [ 1332, eventId, reqIndexOne, basic_cscore_5, basicIScoreList5 ] ]
			]
	
	}
	
	private void initLocCandInfoList(){
	}
	
	private void initMinCandInfoList(){
		List MinScoreCandidate1 = 
			[ [ 331, eventId, reqIndexZero, basic_score_1_1F,
				[   [ basic_score_1_1F, FIN_1, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_6, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_9, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ] ]
		
		List MinScoreCandidate2 = 
			[ [ 331, eventId, reqIndexZero, basic_score_2_1F,
				[   [ basic_score_2_1F, FIN_1, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_6, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_9, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ] ]

		List MinScoreCandidate3 = 
			[ [ 331, eventId, reqIndexZero, MAX_SCORE,
				[   [ MAX_SCORE, FIN_1, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_6, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_9, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ] ]
		
		F21_MIN_CAND_INFO_LIST_1 = 
			[ F21_EXT_ID + NUMBER_01, basic_score_2_1F, true, MinScoreCandidate2 ]
		F21_MIN_CAND_INFO_LIST_2 = 
			[ F21_EXT_ID + NUMBER_02, basic_score_1_1F, true, MinScoreCandidate1 ]
		F21_MIN_CAND_INFO_LIST_3 = 
			[ F21_EXT_ID + NUMBER_01, basic_cscore_1, true, 
				[ [ 331, eventId, reqIndexZero, BASIC_SCORE_1_1F, basicIScoreList1 ] ] ]
		F21_MIN_CAND_INFO_LIST_4 = 
			[ F21_EXT_ID + NUMBER_01, basic_cscore_3, true, 
				[ [ 331, eventId, reqIndexZero, basic_cscore_1, basicIScoreList1 ],
				  [ 332, eventId, reqIndexZero, basic_cscore_3, basicIScoreList3 ] ]
			]
		F21_MIN_CAND_INFO_LIST_5 = 
			[ F21_EXT_ID + NUMBER_01, basic_cscore_3, true, 
				[ [ 332, eventId, reqIndexZero, basic_cscore_3, basicIScoreList3 ] ]
			]
	}

	private void initDynCandInfoList(){
		List DynScoreCandidate1 = 
			[ [ 331, eventId, reqIndexZero, basic_cscore_1, basicIScoreList1 ] ]
		
		List DynScoreCandidate2 = 
			[ [ 331, eventId, reqIndexZero, basic_score_2_1F,
				[   [ basic_score_2_1F, FIN_1, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_6, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_9, PC2_ROLLED, rollFW ],
                    [ ZERO_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ] ]

		List DynScoreCandidate3 = 
			[ [ 331, eventId, reqIndexZero, MAX_SCORE,
				[   [ MAX_SCORE, FIN_1, PC2_ROLLED, rollFW ],
                    [ MAX_OR_ZERO_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                    [ MAX_OR_ZERO_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_6, PC2_ROLLED, rollFW ],
                    [ MAX_OR_ZERO_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                    [ MAX_SCORE, FIN_9, PC2_ROLLED, rollFW ],
                    [ MAX_OR_ZERO_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ] ]
		
		F22_DYN_CAND_INFO_LIST_1 = 
			[ F22_EXT_ID + NUMBER_01, basic_score_2_1F, true, DynScoreCandidate2 ]
		F22_DYN_CAND_INFO_LIST_2 = 
			[ F22_EXT_ID + NUMBER_01, basic_cscore_1, true, DynScoreCandidate1 ]
		F22_DYN_CAND_INFO_LIST_3 = 
			[ F22_EXT_ID + NUMBER_02, MAX_SCORE, true, DynScoreCandidate3 ]
		F22_DYN_CAND_INFO_LIST_4 = 
			[ F22_EXT_ID + NUMBER_01, basic_score_2_1F, false, DynScoreCandidate2 ]
		F22_DYN_CAND_INFO_LIST_5 = 
			[ F22_EXT_ID + NUMBER_01, basic_cscore_1, false, DynScoreCandidate1 ]
	}

	private void initLostCandInfoList(){
		List lostScoreCandidate1 = 
			  [ 331, eventId, reqIndexZero, MAX_SCORE,
				[	[ ZERO_SCORE, FIN_1, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_2, PC2_ROLLED, rollFW ],
					[ MAX_OR_ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_4, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_5, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_6, PC2_ROLLED, rollFW ],
					[ MAX_OR_ZERO_SCORE, FIN_7, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_8, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_9, PC2_ROLLED, rollFW ],
					[ MAX_OR_ZERO_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ] 
		
		List lostScoreCandidate2 = 
			  [ 331, eventId, reqIndexZero, MAX_SCORE,
				[	[ ZERO_SCORE, FIN_1, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_2, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_5, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_6, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_7, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_8, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_9, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ]	

		List lostScoreCandidate3 = 
			  [ 331, eventId, reqIndexZero, MAX_SCORE,
				[	[ ZERO_SCORE, FIN_1, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_2, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_5, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_6, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_7, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_8, PC2_ROLLED, rollFW ],
					[ ZERO_SCORE, FIN_9, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ] 
		
		F24_LOST_CAND_INFO_LIST_1 = 
			[ F24_EXT_ID + NUMBER_01, MAX_SCORE, true, [ lostScoreCandidate1 ] ]
		F24_LOST_CAND_INFO_LIST_2 = 
			[ F24_EXT_ID + NUMBER_01, MAX_SCORE, true, [ lostScoreCandidate2 ] ]
		F24_LOST_CAND_INFO_LIST_3 = 
			[ F24_EXT_ID + NUMBER_01, MAX_SCORE, true, [ lostScoreCandidate3 ] ]
	}

	private void initAfisCandInfoList(){
		List afisScoreCandidate_1 = 
			  [ 332, eventId, reqIndexZero, MAX_SCORE,
				[	[ BASIC_SCORE_9_1F, FIN_1, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_9_2F, FIN_2, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_9_3F, FIN_3, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_9_4F, FIN_4, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_9_5F, FIN_5, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_9_6F, FIN_6, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_9_7F, FIN_7, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_9_8F, FIN_8, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_9_9F, FIN_9, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_9_10F, FIN_10, PC2_ROLLED, rollFW ] ] ] 
	
		List afisScoreCandidate_2 = 
			  [ 331, eventId, reqIndexZero, MAX_SCORE,
				[	[ BASIC_SCORE_10_1F, FIN_1, PC2_SLAP, slapFW ],
					[ BASIC_SCORE_10_2F, FIN_2, PC2_SLAP, slapFW ],
					[ BASIC_SCORE_10_3F, FIN_3, PC2_SLAP, slapFW ],
					[ BASIC_SCORE_10_4F, FIN_4, PC2_SLAP, slapFW ],
					[ BASIC_SCORE_10_5F, FIN_5, PC2_SLAP, slapFW ],
					[ BASIC_SCORE_10_6F, FIN_6, PC2_SLAP, slapFW ],
					[ BASIC_SCORE_10_7F, FIN_7, PC2_SLAP, slapFW ],
					[ BASIC_SCORE_10_8F, FIN_8, PC2_SLAP, slapFW ],
					[ BASIC_SCORE_10_9F, FIN_9, PC2_SLAP, slapFW ],
					[ BASIC_SCORE_10_10F, FIN_10, PC2_SLAP, slapFW ] ] ] 

		List afisScoreCandidate_3 = 
			  [ 331, eventId, reqIndexZero, MAX_SCORE,
				[	[ BASIC_SCORE_10_1F, FIN_1, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_10_2F, FIN_2, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_10_3F, FIN_3, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_10_4F, FIN_4, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_10_5F, FIN_5, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_10_6F, FIN_6, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_10_7F, FIN_7, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_10_8F, FIN_8, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_10_9F, FIN_9, PC2_ROLLED, rollFW ],
					[ BASIC_SCORE_10_10F, FIN_10, PC2_ROLLED, rollFW ] ] ] 

		F28_AFIS_CAND_INFO_LIST_1 = 
			 [ F28_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F28_AFIS_CAND_INFO_LIST_2 = 
			 [ F28_EXT_ID + NUMBER_02, MAX_SCORE, true, [ afisScoreCandidate_1 ] ]
		F28_AFIS_CAND_INFO_LIST_3 = 
			 [ F28_EXT_ID + NUMBER_01, MAX_SCORE, true, [ afisScoreCandidate_2 ] ]
		F28_AFIS_CAND_INFO_LIST_4 = 
			 [ F28_EXT_ID + NUMBER_02, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_2 ] ]
		F28_AFIS_CAND_INFO_LIST_5 = 
			 [ F28_EXT_ID + NUMBER_01, MAX_SCORE, true, [ afisScoreCandidate_3 ] ]
		F28_AFIS_CAND_INFO_LIST_6 = 
			 [ F28_EXT_ID + NUMBER_02, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_5 ] ]
	}

	private void initScopeCandInfoList(){
		F29_SCOPE12_CAND_INFO_LIST_1 =
             [ F29_EXT_ID + NUMBER_03, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_SCOPE2_1 ] ]
		F29_SCOPE12_CAND_INFO_LIST_2 =
             [ F29_EXT_ID + NUMBER_04, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_SCOPE2_2 ] ]
		F29_SCOPE12_CAND_INFO_LIST_3 =
             [ F29_EXT_ID + NUMBER_04, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_SCOPE2_4 ] ]
		F29_SCOPE12_CAND_INFO_LIST_4 =
             [ F29_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F29_SCOPE12_CAND_INFO_LIST_5 =
             [ F29_EXT_ID + NUMBER_03, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_SCOPE2_1 ] ]
		
		F29_SCOPE12_CAND_INFO_LIST_6 =
             [ F29_EXT_ID + NUMBER_02, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_2 ] ]
		F29_SCOPE12_CAND_INFO_LIST_7 =
             [ F29_EXT_ID + NUMBER_04, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_SCOPE2_2 ] ]
		F29_SCOPE12_CAND_INFO_LIST_8 =
             [ F29_EXT_ID + NUMBER_02, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		
		F31_SCOPE123_CAND_INFO_LIST_1 =
             [ F31_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]
		F31_SCOPE123_CAND_INFO_LIST_2 =
             [ F31_EXT_ID + NUMBER_03, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_SCOPE2_1 ] ]
		
		F31_SCOPE123_CAND_INFO_LIST_3 =
             [ F31_EXT_ID + NUMBER_04, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_SCOPE2_2 ] ]
		F31_SCOPE123_CAND_INFO_LIST_4 =
             [ F31_EXT_ID + NUMBER_06, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_SCOPE3_2 ] ]
		
		F31_SCOPE123_CAND_INFO_LIST_5 =
             [ F31_EXT_ID + NUMBER_02, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ]
		F31_SCOPE123_CAND_INFO_LIST_6 =
             [ F31_EXT_ID + NUMBER_05, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_SCOPE3_1 ] ]
		F31_SCOPE123_CAND_INFO_LIST_7 =
             [ F31_EXT_ID + NUMBER_06, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_SCOPE3_4 ] ]

		F31_SCOPE123_CAND_INFO_LIST_8 =
             [ F31_EXT_ID + NUMBER_04, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_SCOPE2_4 ] ]
	}

	private void initFWeightCandInfoList(){
		F30_FW_CAND_INFO_LIST_1 = 
			[ F30_EXT_ID + NUMBER_01, basic_cscore_1, true, 
				[ [ 331, eventId, reqIndexZero, basic_cscore_1, basicIScoreList1 ] ]
			]
	
		F30_FW_CAND_INFO_LIST_2 = 
			[ F30_EXT_ID + NUMBER_01, basic_cscore_1 + basic_cscore_4, true, 
				[ [ 331, eventId, reqIndexZero, basic_cscore_1, basicIScoreList1 ],
				  [ 331, eventId, reqIndexOne, basic_cscore_4, basicIScoreList4 ] ]
			]

		F30_FW_CAND_INFO_LIST_3 = 
			[ F30_EXT_ID + NUMBER_01, basic_cscore_3 + basic_cscore_5, true, 
				[ [ 332, eventId, reqIndexZero, basic_cscore_3, basicIScoreList3 ],
				  [ 331, eventId, reqIndexZero, basic_cscore_1, basicIScoreList1 ],
				  [ 332, eventId, reqIndexOne, basic_cscore_5, basicIScoreList5 ],
				  [ 331, eventId, reqIndexOne, basic_cscore_4, basicIScoreList4 ] ]
			]
	
		F30_FW_CAND_INFO_LIST_4 = 
			[ F30_EXT_ID + NUMBER_01, basic_cscore_3 + basic_cscore_5, true, 
				[ [ 331, eventId, reqIndexZero, basic_cscore_1, basicIScoreList1 ],
				  [ 332, eventId, reqIndexZero, basic_cscore_3, basicIScoreList3 ],
				  [ 331, eventId, reqIndexOne, basic_cscore_4, basicIScoreList4 ],
				  [ 332, eventId, reqIndexOne, basic_cscore_5, basicIScoreList5 ] ]
			]
			
		F30_FW_CAND_INFO_LIST_5 = 
			[ F30_EXT_ID + NUMBER_01, basic_cscore_1, true, 
				[ [ 331, eventId, reqIndexZero, basic_cscore_1, basicIScoreList1 ]]
			]
	
	}
	
	private void initSortCandInfoList(){

		EXT_SORT_INDIVIDUAL_SCORES =
				[	[ MAX_SCORE, FIN_1, PC2_ROLLED, rollFW ],
					[ MAX_OR_ZERO_SCORE, FIN_2, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_3, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_4, PC2_ROLLED, rollFW ],
					[ MAX_OR_ZERO_SCORE, FIN_5, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_6, PC2_ROLLED, rollFW ],
					[ MAX_OR_ZERO_SCORE, FIN_7, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_8, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_9, PC2_ROLLED, rollFW ],
					[ MAX_OR_ZERO_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] 

		EXT_SORT_CANDIDATE_1 =
			  [ 331, eventId, reqIndexZero, MAX_SCORE, EXT_SORT_INDIVIDUAL_SCORES ]

		F48_HIGH_A_CAND_INFO_LIST = 
			[ F48_HIGH_EXT_ID + A, MAX_SCORE, true, [ EXT_SORT_CANDIDATE_1 ] ]
	
		F48_HIGH_B_CAND_INFO_LIST = 
			[ F48_HIGH_EXT_ID + B, MAX_SCORE, true, [ EXT_SORT_CANDIDATE_1 ] ]
		
		F48_HIGH_C_CAND_INFO_LIST = 
			[ F48_HIGH_EXT_ID + C, MAX_SCORE, true, [ EXT_SORT_CANDIDATE_1 ] ]
		
		F48_LOW_A_CAND_INFO_LIST = 
			[ F48_LOW_EXT_ID + A, BASIC_CSCORE_1, false, [ BASIC_SCORE_CANDIDATE_1 ] ]
	
		F48_LOW_B_CAND_INFO_LIST = 
			[ F48_LOW_EXT_ID + B, BASIC_CSCORE_1, false, [ BASIC_SCORE_CANDIDATE_1 ] ]
		
		F48_LOW_C_CAND_INFO_LIST = 
			[ F48_LOW_EXT_ID + C, BASIC_CSCORE_1, false, [ BASIC_SCORE_CANDIDATE_1 ] ]
	
	}

	private void initFingerThresholdCandInfoList(){
		F40_FT_APP_MATCHABLE_CAND_INFO_LIST_1 =
			[ F40_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_1 ] ]  
		F40_FT_APP_MATCHABLE_CAND_INFO_LIST_2 =
			[ F40_EXT_ID + NUMBER_01, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_4 ] ] 

		F41_FT_MATCHABLE_CAND_INFO_LIST_1 = []

		F42_FT_FINGER_CAND_INFO_LIST_1 =
			[ F42_EXT_ID + NUMBER_01, MAX_SCORE , true,
                [ [ 331, eventId, reqIndexZero, MAX_SCORE,
                    [   [ MAX_SCORE, FIN_1, PC2_ROLLED, rollFW ],
                        [ MAX_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                        [ MAX_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                        [ MAX_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                        [ MAX_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                        [ MAX_SCORE, FIN_6, PC2_ROLLED, rollFW ],
                        [ MAX_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                        [ MAX_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                        [ MAX_SCORE, FIN_9, PC2_ROLLED, rollFW ],
                        [ MAX_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ] ]
            ]

		F42_FT_FINGER_CAND_INFO_LIST_2 =
			[ F42_EXT_ID + NUMBER_01, MAX_SCORE , true,
                [ [ 331, eventId, reqIndexZero, MAX_SCORE,
                    [   [ ZERO_SCORE, FIN_1, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_6, PC2_ROLLED, rollFW ],
                        [ MAX_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                        [ MAX_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                        [ MAX_SCORE, FIN_9, PC2_ROLLED, rollFW ],
                        [ MAX_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ] ]
            ]

		F42_FT_FINGER_CAND_INFO_LIST_3 = 
			[ F42_EXT_ID + NUMBER_01, MAX_SCORE , true,
                [ [ 331, eventId, reqIndexZero, MAX_SCORE,
                    [   [ ZERO_SCORE, FIN_1, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_6, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                        [ MAX_SCORE, FIN_9, PC2_ROLLED, rollFW ],
                        [ MAX_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ] ]
            ]

		F42_FT_FINGER_CAND_INFO_LIST_4 =
			[ F42_EXT_ID + NUMBER_01, MAX_SCORE , true,
                [ [ 331, eventId, reqIndexZero, MAX_SCORE,
                    [   [ ZERO_SCORE, FIN_1, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_6, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_9, PC2_ROLLED, rollFW ],
                        [ MAX_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ] ]
            ]

		F42_FT_FINGER_CAND_INFO_LIST_5 =
			[ F42_EXT_ID + NUMBER_01, MAX_SCORE , true,
                [ [ 331, eventId, reqIndexZero, MAX_SCORE,
                    [   [ ZERO_SCORE, FIN_1, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                        [ ZERO_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                        [ MAX_SCORE, FIN_6, PC2_ROLLED, rollFW ],
                        [ MAX_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                        [ MAX_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                        [ MAX_SCORE, FIN_9, PC2_ROLLED, rollFW ],
                        [ MAX_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ] ]
            ]

		F43_FT_PATTERN_CAND_INFO_LIST_1 = 
			[ F43_EXT_ID + NUMBER_01, MAX_SCORE , true, [ PATTERN_SCORE_CANDIDATE_1 ] ] 
		
		F44_FT_CARD_CAND_INFO_LIST_1 = 
			[ F44_EXT_ID + NUMBER_01, MAX_SCORE , true, [ MAX_SCORE_CANDIDATE_1 ] ] 
		F44_FT_CARD_CAND_INFO_LIST_2 = 
			[ F44_EXT_ID + NUMBER_01, MAX_SCORE , true, [ MAX_SCORE_CANDIDATE_4 ] ] 
		
		F45_FT_MATE_CAND_INFO_LIST_1 = 
			[ F45_EXT_ID + NUMBER_01, MAX_SCORE , true, [ MAX_SCORE_CANDIDATE_1 ] ] 
		F45_FT_MATE_CAND_INFO_LIST_2 = 
			[ F45_EXT_ID + NUMBER_01, MAX_SCORE , true, [ MAX_SCORE_CANDIDATE_4 ] ] 
	
		F46_FT_FINAL_CAND_INFO_LIST_1 = 
			[ F46_EXT_ID + NUMBER_02, MAX_SCORE , true, [ MAX_SCORE_CANDIDATE_1 ] ] 

		F46_FT_FINAL_CAND_INFO_LIST_2 = 
			[ F46_EXT_ID + NUMBER_01, basic_score_1 , false,
				[ [ 331, eventId, reqIndexZero, basic_cscore_1,
					basicIScoreList1
				 ] ]
			]
			
		
		F47_FT_SPEED_CAND_INFO_LIST_1 = 
			[ F47_EXT_ID + NUMBER_01, basic_score_6, true, [ SPEED_SCORE_CANDIDATE_1 ] ] 

		F49_FT_APP_MATCHABLE_CAND_INFO_LIST_1 = 
			[ F49_EXT_ID + NUMBER_01, MAX_SCORE , true,
				[ [ 331, eventId, reqIndexZero, MAX_SCORE,
                    [   [ 9845, FIN_1, PC2_ROLLED, rollFW ],
                        [ 4753, FIN_2, PC2_ROLLED, rollFW ],
                        [ 1276, FIN_3, PC2_ROLLED, rollFW ],
                        [ 1961, FIN_4, PC2_ROLLED, rollFW ],
                        [ 4268, FIN_5, PC2_ROLLED, rollFW ],
                        [ 9697, FIN_6, PC2_ROLLED, rollFW ],
                        [ 4649, FIN_7, PC2_ROLLED, rollFW ],
                        [ 2313, FIN_8, PC2_ROLLED, rollFW ],
                        [ 2920, FIN_9, PC2_ROLLED, rollFW ],
                        [ 3763, FIN_10, PC2_ROLLED, rollFW ] ] ] ]
			]

	}

	private void initParamIdCandInfoList(){

		CML_PARAMID_SCORE_CANDIDATE_1 =
			  [ 331, eventId, reqIndexZero, MAX_SCORE, 
				[	[ MAX_SCORE, FIN_1, PC2_ROLLED, rollFW ],
					[ MAX_OR_ZERO_SCORE, FIN_2, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_3, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_4, PC2_ROLLED, rollFW ],
					[ MAX_OR_ZERO_SCORE, FIN_5, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_6, PC2_ROLLED, rollFW ],
					[ MAX_OR_ZERO_SCORE, FIN_7, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_8, PC2_ROLLED, rollFW ],
					[ MAX_SCORE, FIN_9, PC2_ROLLED, rollFW ],
					[ MAX_OR_ZERO_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ] 

		CML_PARAMID_SCORE_CANDIDATE_2 =
			  [ 331, eventId, reqIndexZero, CML_PARAMID1_CSCORE_1, 
				[	[ CML_PARAMID1_SCORE_1_1F, FIN_1, PC2_ROLLED, rollFW ],
					[ CML_PARAMID1_SCORE_1_2F, FIN_2, PC2_ROLLED, rollFW ],
					[ CML_PARAMID1_SCORE_1_3F, FIN_3, PC2_ROLLED, rollFW ],
					[ CML_PARAMID1_SCORE_1_4F, FIN_4, PC2_ROLLED, rollFW ],
					[ CML_PARAMID1_SCORE_1_5F, FIN_5, PC2_ROLLED, rollFW ],
					[ CML_PARAMID1_SCORE_1_6F, FIN_6, PC2_ROLLED, rollFW ],
					[ CML_PARAMID1_SCORE_1_7F, FIN_7, PC2_ROLLED, rollFW ],
					[ CML_PARAMID1_SCORE_1_8F, FIN_8, PC2_ROLLED, rollFW ],
					[ CML_PARAMID1_SCORE_1_9F, FIN_9, PC2_ROLLED, rollFW ],
					[ CML_PARAMID1_SCORE_1_10F, FIN_10, PC2_ROLLED, rollFW ] ] ] 

		CML_PARAMID_SCORE_CANDIDATE_3 =
			  [ 331, eventId, reqIndexZero, CML_PARAMID1_CSCORE_2, 
				[	[ CML_PARAMID1_SCORE_2_1F, FIN_1, PC2_ROLLED, rollFW ],
					[ CML_PARAMID1_SCORE_2_2F, FIN_2, PC2_ROLLED, rollFW ],
					[ CML_PARAMID1_SCORE_2_3F, FIN_3, PC2_ROLLED, rollFW ],
					[ CML_PARAMID1_SCORE_2_4F, FIN_4, PC2_ROLLED, rollFW ],
					[ CML_PARAMID1_SCORE_2_5F, FIN_5, PC2_ROLLED, rollFW ],
					[ CML_PARAMID1_SCORE_2_6F, FIN_6, PC2_ROLLED, rollFW ],
					[ CML_PARAMID1_SCORE_2_7F, FIN_7, PC2_ROLLED, rollFW ],
					[ CML_PARAMID1_SCORE_2_8F, FIN_8, PC2_ROLLED, rollFW ],
					[ CML_PARAMID1_SCORE_2_9F, FIN_9, PC2_ROLLED, rollFW ],
					[ CML_PARAMID1_SCORE_2_10F, FIN_10, PC2_ROLLED, rollFW ] ] ] 

		CML_PARAMID_CAND_INFO_LIST_1 = 
			[ CML_EXT_ID + NUMBER_01, MAX_SCORE, true, [ CML_PARAMID_SCORE_CANDIDATE_1 ] ]
		CML_PARAMID_CAND_INFO_LIST_2 = 
			[ CML_EXT_ID + NUMBER_02, CML_PARAMID1_CSCORE_1, true, [ CML_PARAMID_SCORE_CANDIDATE_2 ] ]
		CML_PARAMID_CAND_INFO_LIST_3 = 
			[ CML_EXT_ID + NUMBER_02, CML_PARAMID1_CSCORE_2, true, [ CML_PARAMID_SCORE_CANDIDATE_3 ] ]
		CML_PARAMID_CAND_INFO_LIST_4 = 
			[ CML_EXT_ID + NUMBER_02, basic_cscore_1, true, [ BASIC_SCORE_CANDIDATE_1 ] ]
	}

	private int calcFusionScore_roll_slap() {
		return calcFusionScore_roll_slap(PC2_1_R_SCORE, FMP5_1_R_SCORE)
	}

	private int calcFusionScore_roll_slap(int rollScore, int slapScore) {
		rollScore = mergeFWeight(rollScore, rollFW)
		slapScore = mergeFWeight(slapScore, slapFW)
		int fScore = rollScore + slapScore
		return cutoffScore(fScore)
	}

	public List getCandList_CardQuality_1(){
        initCandInfoLists()
        return [
               F1_CARD_QUALITY_CAND_INFO_LIST_1,
               F1_CARD_QUALITY_CAND_INFO_LIST_2,
               F1_CARD_QUALITY_CAND_INFO_LIST_3
               ]
    }

	public List getCandList_CardQuality_2(){
        initCandInfoLists()
        return [
               F1_CARD_QUALITY_CAND_INFO_LIST_1,
               F1_CARD_QUALITY_CAND_INFO_LIST_3
               ]
    }

	public List getCandList_ApplyPattern_1(){
        initCandInfoLists()
        return [ 
				F2_APP_PATTERN_THRESHOLD_CAND_INFO_LIST_1
			   ]
	}

	public List getCandList_Pattern_1(){
        initCandInfoLists()
        return [ 
				F3_PATTERN_THRESHOLD_CAND_INFO_LIST_1
			   ]
	}

	public List getCandList_ApplyGender_1(){
        initCandInfoLists()
        return [ 
				F25_APP_GENDER_CAND_INFO_LIST_1,
				F25_APP_GENDER_CAND_INFO_LIST_2,
				F25_APP_GENDER_CAND_INFO_LIST_5,
				F25_APP_GENDER_CAND_INFO_LIST_6
			   ]
	}

	public List getCandList_ApplyGender_2(){
        initCandInfoLists()
        return [ 
				F25_APP_GENDER_CAND_INFO_LIST_3,
				F25_APP_GENDER_CAND_INFO_LIST_4,
				F25_APP_GENDER_CAND_INFO_LIST_5,
				F25_APP_GENDER_CAND_INFO_LIST_6
			   ]
	}

	public List getCandList_Gender_1(){
        initCandInfoLists()
        return [ 
				F4_GENDER_CAND_INFO_LIST_1,
				F4_GENDER_CAND_INFO_LIST_2,
				F4_GENDER_CAND_INFO_LIST_5,
				F4_GENDER_CAND_INFO_LIST_6
			   ]
	}
	
	public List getCandList_Gender_2(){
        initCandInfoLists()
        return [
				F4_GENDER_CAND_INFO_LIST_3,
                F4_GENDER_CAND_INFO_LIST_4,
                F4_GENDER_CAND_INFO_LIST_5,
                F4_GENDER_CAND_INFO_LIST_6 
			   ]
	}
	
	public List getCandList_Gender_3(){
        initCandInfoLists()
        return [
				F4_GENDER_CAND_INFO_LIST_1,
				F4_GENDER_CAND_INFO_LIST_2,
				F4_GENDER_CAND_INFO_LIST_3,
                F4_GENDER_CAND_INFO_LIST_4,
                F4_GENDER_CAND_INFO_LIST_5,
                F4_GENDER_CAND_INFO_LIST_6 
			   ]
	}
	
	public List getCandList_ApplyYob_1(){
        initCandInfoLists()
        return [ 
				F26_YOB_CAND_INFO_LIST_1,
				F26_YOB_CAND_INFO_LIST_2
			   ]
	}

	public List getCandList_ApplyYob_2(){
        initCandInfoLists()
        return [ 
				F26_YOB_CAND_INFO_LIST_3,
				F26_YOB_CAND_INFO_LIST_4
			   ]
	}

	public List getCandList_Yob_1(){
        initCandInfoLists()
        return [ 
				F27_YOB_CAND_INFO_LIST_11,
				F27_YOB_CAND_INFO_LIST_12,
				F27_YOB_CAND_INFO_LIST_23,
				F27_YOB_CAND_INFO_LIST_24
			   ]
    }

	public List getCandList_Yob_2(){
        initCandInfoLists()
        return [
				F27_YOB_CAND_INFO_LIST_03,
				F27_YOB_CAND_INFO_LIST_04,
				F27_YOB_CAND_INFO_LIST_05,
				F27_YOB_CAND_INFO_LIST_06,
				F27_YOB_CAND_INFO_LIST_07,
				F27_YOB_CAND_INFO_LIST_08,
				F27_YOB_CAND_INFO_LIST_09,
				F27_YOB_CAND_INFO_LIST_10,
				F27_YOB_CAND_INFO_LIST_11,
				F27_YOB_CAND_INFO_LIST_12,
				F27_YOB_CAND_INFO_LIST_13,
				F27_YOB_CAND_INFO_LIST_14,
				F27_YOB_CAND_INFO_LIST_15,
				F27_YOB_CAND_INFO_LIST_16,
				F27_YOB_CAND_INFO_LIST_17,
				F27_YOB_CAND_INFO_LIST_18,
				F27_YOB_CAND_INFO_LIST_19,
				F27_YOB_CAND_INFO_LIST_20,
				F27_YOB_CAND_INFO_LIST_23,
				F27_YOB_CAND_INFO_LIST_24
			   ]
    }

	public List getCandList_Yob_3(){
        initCandInfoLists()
        return [ 
				F27_YOB_CAND_INFO_LIST_01,
				F27_YOB_CAND_INFO_LIST_02,
				F27_YOB_CAND_INFO_LIST_03,
				F27_YOB_CAND_INFO_LIST_04,
				F27_YOB_CAND_INFO_LIST_05,
				F27_YOB_CAND_INFO_LIST_06,
				F27_YOB_CAND_INFO_LIST_07,
				F27_YOB_CAND_INFO_LIST_08,
				F27_YOB_CAND_INFO_LIST_09,
				F27_YOB_CAND_INFO_LIST_10,
				F27_YOB_CAND_INFO_LIST_11,
				F27_YOB_CAND_INFO_LIST_12,
				F27_YOB_CAND_INFO_LIST_13,
				F27_YOB_CAND_INFO_LIST_14,
				F27_YOB_CAND_INFO_LIST_15,
				F27_YOB_CAND_INFO_LIST_16,
				F27_YOB_CAND_INFO_LIST_17,
				F27_YOB_CAND_INFO_LIST_18,
				F27_YOB_CAND_INFO_LIST_19,
				F27_YOB_CAND_INFO_LIST_20,
				F27_YOB_CAND_INFO_LIST_21,
				F27_YOB_CAND_INFO_LIST_22,
				F27_YOB_CAND_INFO_LIST_23,
				F27_YOB_CAND_INFO_LIST_24
			   ]
    }

	public List getCandList_ApplyYobThreshold_1(){
        initCandInfoLists()
        return [ 
				F5_APP_YOB_THRESHOLD_CAND_INFO_LIST_05,
				F5_APP_YOB_THRESHOLD_CAND_INFO_LIST_06,
			   ]
    }

	public List getCandList_ApplyYobThreshold_2(){
        initCandInfoLists()
        return [ 
				F5_APP_YOB_THRESHOLD_CAND_INFO_LIST_03,
				F5_APP_YOB_THRESHOLD_CAND_INFO_LIST_04,
				F5_APP_YOB_THRESHOLD_CAND_INFO_LIST_05,
				F5_APP_YOB_THRESHOLD_CAND_INFO_LIST_06,
				F5_APP_YOB_THRESHOLD_CAND_INFO_LIST_07,
				F5_APP_YOB_THRESHOLD_CAND_INFO_LIST_08
			   ]
    }
	
	public List getCandList_YobThreshold_1(){
        initCandInfoLists()
        return [ 
				F6_YOB_THRESHOLD_CAND_INFO_LIST_09,
				F6_YOB_THRESHOLD_CAND_INFO_LIST_10,
				F6_YOB_THRESHOLD_CAND_INFO_LIST_19,
				F6_YOB_THRESHOLD_CAND_INFO_LIST_20
			   ]
    }

	public List getCandList_YobThreshold_2(){
        initCandInfoLists()
        return [ 
				F6_YOB_THRESHOLD_CAND_INFO_LIST_07,
				F6_YOB_THRESHOLD_CAND_INFO_LIST_08,
				F6_YOB_THRESHOLD_CAND_INFO_LIST_09,
				F6_YOB_THRESHOLD_CAND_INFO_LIST_10,
				F6_YOB_THRESHOLD_CAND_INFO_LIST_11,
				F6_YOB_THRESHOLD_CAND_INFO_LIST_12,
				F6_YOB_THRESHOLD_CAND_INFO_LIST_19,
				F6_YOB_THRESHOLD_CAND_INFO_LIST_20
			   ]
    }

	public List getCandList_YobThreshold_3(){
        initCandInfoLists()
        return [ 
				F6_YOB_THRESHOLD_CAND_INFO_LIST_03,
				F6_YOB_THRESHOLD_CAND_INFO_LIST_04,
				F6_YOB_THRESHOLD_CAND_INFO_LIST_05,
				F6_YOB_THRESHOLD_CAND_INFO_LIST_06,
				F6_YOB_THRESHOLD_CAND_INFO_LIST_07,
				F6_YOB_THRESHOLD_CAND_INFO_LIST_08,
				F6_YOB_THRESHOLD_CAND_INFO_LIST_09,
				F6_YOB_THRESHOLD_CAND_INFO_LIST_10,
				F6_YOB_THRESHOLD_CAND_INFO_LIST_11,
				F6_YOB_THRESHOLD_CAND_INFO_LIST_12,
				F6_YOB_THRESHOLD_CAND_INFO_LIST_13,
				F6_YOB_THRESHOLD_CAND_INFO_LIST_14,
				F6_YOB_THRESHOLD_CAND_INFO_LIST_15,
				F6_YOB_THRESHOLD_CAND_INFO_LIST_16,
				F6_YOB_THRESHOLD_CAND_INFO_LIST_19,
				F6_YOB_THRESHOLD_CAND_INFO_LIST_20
			   ]
    }

	public List getCandList_Finger_1(){
		initCandInfoLists()
		return [ F7_8_FINGER_CAND_INFO_LIST_1 ]
	}

	public List getCandList_Filter_1(){
		initCandInfoLists()
		return [ F9_FILTER_CAND_INFO_LIST_1,
				 F9_FILTER_CAND_INFO_LIST_2,
				 F9_FILTER_CAND_INFO_LIST_3,
				 F9_FILTER_CAND_INFO_LIST_4,
				 F9_FILTER_CAND_INFO_LIST_5,
				 F9_FILTER_CAND_INFO_LIST_6,
				 F9_FILTER_CAND_INFO_LIST_7,
				 F9_FILTER_CAND_INFO_LIST_8 ]
	}

	public List getCandList_Filter_2(){
		initCandInfoLists()
		return [ F9_FILTER_CAND_INFO_LIST_5,
				 F9_FILTER_CAND_INFO_LIST_6,
				 F9_FILTER_CAND_INFO_LIST_7,
				 F9_FILTER_CAND_INFO_LIST_8 ]
	}

	public List getCandList_Filter_3(){
		initCandInfoLists()
		return [ F9_FILTER_CAND_INFO_LIST_3,
		         F9_FILTER_CAND_INFO_LIST_4,
		         F9_FILTER_CAND_INFO_LIST_7,
				 F9_FILTER_CAND_INFO_LIST_8 ]
	}

	public List getCandList_Filter_4(){
		initCandInfoLists()
		return [ F9_FILTER_CAND_INFO_LIST_7,
				 F9_FILTER_CAND_INFO_LIST_8 ]
	}

	public List getCandList_ApplySpeed_1(){
		initCandInfoLists()
		return [ F10_APP_SPEED_CAND_INFO_LIST_1 ]
	}
	
	public List getCandList_ApplySpeed_2(){
		initCandInfoLists()
		return [ F10_APP_SPEED_CAND_INFO_LIST_2 ]
	}
	
	public List getCandList_Speed_1(){
		initCandInfoLists()
		return [ F11_SPEED_CAND_INFO_LIST_1 ]
	}

	public List getCandList_Speed_2(){
		initCandInfoLists()
		return [ F11_SPEED_CAND_INFO_LIST_2 ]
	}

	public List getCandList_ApplyRotation_1(){
		initCandInfoLists()
		return [ F12_APP_ROTATION_CAND_INFO_LIST_1 ]
	}

	public List getCandList_Rotation_1(){
		initCandInfoLists()
		return [ F13_ROTATION_CAND_INFO_LIST_1 ]
	}

	public List getCandList_ApplyDistortion_1(){
		initCandInfoLists()
		return [ F14_APP_DISTORTION_CAND_INFO_LIST_1 ]
	}

	public List getCandList_Distortion_1(){
		initCandInfoLists()
		return [ F15_DISTORTION_CAND_INFO_LIST_1 ]
	}

	public List getCandList_ApplyCardScoreThreshold_1(){
        initCandInfoLists()
        return [ 
				F33_APP_CARD_CAND_INFO_LIST_1,
				F33_APP_CARD_CAND_INFO_LIST_2
    			]
	}

	public List getCandList_CardScoreThreshold_1(){
        initCandInfoLists()
        return [ 
				F34_CARD_CAND_INFO_LIST_1,
				F34_CARD_CAND_INFO_LIST_2
    			]
	}

	public List getCandList_ApplyMateProbability_1(){
        initCandInfoLists()
        return [ 
				F35_APP_MATE_CAND_INFO_LIST_1,
				F35_APP_MATE_CAND_INFO_LIST_2
    			]
	}

	public List getCandList_MateProbability_1(){
        initCandInfoLists()
        return [ 
				F36_MATE_CAND_INFO_LIST_1
    			]
	}

	public List getCandList_MateProbability_2(){
        initCandInfoLists()
        return [ 
				F36_MATE_CAND_INFO_LIST_2,
    			]
	}

	public List getCandList_ApplyFinalScore_1(){
        initCandInfoLists()
        return [ F37_APP_FINAL_CAND_INFO_LIST_1 ]
	}

	public List getCandList_FinalScore_1(){
        initCandInfoLists()
        return [ 
        		F38_FINAL_CAND_INFO_LIST_3,
				F38_FINAL_CAND_INFO_LIST_1
    			]
	}

	public List getCandList_FinalScore_2(){
        initCandInfoLists()
        return [ 
				F38_FINAL_CAND_INFO_LIST_3
    			]
	}

	public List getCandList_FinalScore_3(){
        initCandInfoLists()
        return [ 
				F38_FINAL_CAND_INFO_LIST_1,
				F38_FINAL_CAND_INFO_LIST_2,
				F38_FINAL_CAND_INFO_LIST_3
    			]
	}

	public List getCandList_SearchMode_1(){
        initCandInfoLists()
        return [ 
				F39_SEARCH_MODE_CAND_INFO_LIST_1,
				F39_SEARCH_MODE_CAND_INFO_LIST_2
    			]
	}

	public List getCandList_FT_ApplyMatchable_1(){
        initCandInfoLists()
        return [ F40_FT_APP_MATCHABLE_CAND_INFO_LIST_1,
				 F40_FT_APP_MATCHABLE_CAND_INFO_LIST_2
    ]
	}

	public List getCandList_FT_ApplyMatchable_MU_1(){
        initCandInfoLists()
        return [ F49_FT_APP_MATCHABLE_CAND_INFO_LIST_1
    ]
	}

	public List getCandList_FT_FingerNumber_1(){
        initCandInfoLists()
        return [ F42_FT_FINGER_CAND_INFO_LIST_1
    ]
	}

	public List getCandList_FT_FingerNumber_2(){
        initCandInfoLists()
        return [ F42_FT_FINGER_CAND_INFO_LIST_2
    ]
	}

	public List getCandList_FT_FingerNumber_3(){
        initCandInfoLists()
        return [ F42_FT_FINGER_CAND_INFO_LIST_3
    ]
	}

	public List getCandList_FT_FingerNumber_4(){
        initCandInfoLists()
        return [ F42_FT_FINGER_CAND_INFO_LIST_4
    ]
	}

	public List getCandList_FT_FingerNumber_5(){
        initCandInfoLists()
        return [ F42_FT_FINGER_CAND_INFO_LIST_5
    ]
	}

	public List getCandList_FT_PatternThreshold_1(){
        initCandInfoLists()
        return [ F43_FT_PATTERN_CAND_INFO_LIST_1
    ]
	}	
	
	public List getCandList_FT_CardScoreThreshold_1(){
        initCandInfoLists()
        return [ F44_FT_CARD_CAND_INFO_LIST_1,
				 F44_FT_CARD_CAND_INFO_LIST_2 ]
    }	
	
	public List getCandList_FT_MateProbability_1(){
        initCandInfoLists()
        return [ F45_FT_MATE_CAND_INFO_LIST_1,
				 F45_FT_MATE_CAND_INFO_LIST_2 ]
    }	
	
	public List getCandList_FT_FinalScore_1(){
        initCandInfoLists()
        return [ F46_FT_FINAL_CAND_INFO_LIST_1,
				 F46_FT_FINAL_CAND_INFO_LIST_2 ]
    }	
	
	public List getCandList_FT_FinalScore_2(){
        initCandInfoLists()
        return [ F46_FT_FINAL_CAND_INFO_LIST_1
				 ]
    }	
		
	public List getCandList_FT_Speed_1(){
        initCandInfoLists()
        return [ F47_FT_SPEED_CAND_INFO_LIST_1 ]
    }	

	public List getCandList_ColdSearch_1(){
		initCandInfoLists()
        return [	F16_COLD_SEARCH_CAND_INFO_LIST_01,
					F16_COLD_SEARCH_CAND_INFO_LIST_02,
					F16_COLD_SEARCH_CAND_INFO_LIST_03,
					F16_COLD_SEARCH_CAND_INFO_LIST_04,
					F16_COLD_SEARCH_CAND_INFO_LIST_05,
					F16_COLD_SEARCH_CAND_INFO_LIST_06,
					F16_COLD_SEARCH_CAND_INFO_LIST_07,
					F16_COLD_SEARCH_CAND_INFO_LIST_08,
					F16_COLD_SEARCH_CAND_INFO_LIST_09,
					F16_COLD_SEARCH_CAND_INFO_LIST_10,
					F16_COLD_SEARCH_CAND_INFO_LIST_11,
					F16_COLD_SEARCH_CAND_INFO_LIST_12,
					F16_COLD_SEARCH_CAND_INFO_LIST_13,
					F16_COLD_SEARCH_CAND_INFO_LIST_14,
					F16_COLD_SEARCH_CAND_INFO_LIST_15,
					F16_COLD_SEARCH_CAND_INFO_LIST_16,
					F16_COLD_SEARCH_CAND_INFO_LIST_17,
					F16_COLD_SEARCH_CAND_INFO_LIST_18
				]
    }
	
	public List getCandList_TargetDb_1(){
		initCandInfoLists()
        return [ F17_TARGET_DB_CAND_INFO_LIST_1 ]
    }

	public List getCandList_TargetDb_2(){
		initCandInfoLists()
        if(level == "low") {
            F17_TARGET_DB_CAND_INFO_LIST_2 =
                 [ F17_EXT_ID + NUMBER_02, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_5 ] ]
        }
        return [ F17_TARGET_DB_CAND_INFO_LIST_2 ]
    }
		
	public List getCandList_TargetDb_3(){
		initCandInfoLists()
        return [ F17_TARGET_DB_CAND_INFO_LIST_1,
				 F17_TARGET_DB_CAND_INFO_LIST_3 ]
    }

	public List getCandList_Consolidate_1(){
		initCandInfoLists()
        return [ F18_CONSOLIDATE_CAND_INFO_LIST_1 ]
    }

    public List getCandList_Priority() {
		List priorityCandTmp = 
			 [ 331, eventId, reqIndexZero, MAX_SCORE,
                 [   [ MAX_SCORE, FIN_1, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                     [ MAX_OR_ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_6, PC2_ROLLED, rollFW ],
                     [ MAX_OR_ZERO_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                     [ MAX_OR_ZERO_SCORE, FIN_9, PC2_ROLLED, rollFW ],   
                     [ MAX_OR_ZERO_SCORE, FIN_10, PC2_ROLLED, rollFW ] ] ] 
		
        List candTmpList = []
		for(int i = 0; i < 100; i++){
			candTmpList.add(priorityCandTmp)
		}

		F19_PRIORITY_CAND_INFO_LIST_1 = 
			[ F19_EXT_ID + NUMBER_01, MAX_SCORE, true, candTmpList ]

		return [ F19_PRIORITY_CAND_INFO_LIST_1 ]
    }
	
	public List getCandList_Consolidate_2(){
		initCandInfoLists()
        return [ F18_CONSOLIDATE_CAND_INFO_LIST_2 ]
    }
	
	public List getCandList_Consolidate_3(){
		initCandInfoLists()
        return [ F18_CONSOLIDATE_CAND_INFO_LIST_3 ]
    }

	public List getCandList_ConsolidateScope_1(){
		initCandInfoLists()
        return [ F32_CONSOLIDATE_CAND_INFO_LIST_1 ]
    }
	
	public List getCandList_ConsolidateScope_2(){
		initCandInfoLists()
        return [ F32_CONSOLIDATE_CAND_INFO_LIST_2 ]
	}

	public List getCandList_Loc_1(){
		initCandInfoLists()
		
		List LocScoreCandidate = 
			[ [ 331, eventId, reqIndexZero, MAX_SCORE,
                 [   [ MAX_SCORE, FIN_1, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                     [ MAX_OR_ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_6, PC2_ROLLED, rollFW ],
                     [ MAX_OR_ZERO_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                     [ MAX_OR_ZERO_SCORE, FIN_9, PC2_ROLLED, rollFW ],
                     [ MAX_OR_ZERO_SCORE, FIN_10, PC2_ROLLED, rollFW ], ] ] ]
		
		for(int i = 1; i <= 5; i++){
			String num = "0000" + i
			print num
			F20_LOC_CAND_INFO_LIST_1.add([ F20_EXT_ID + num, MAX_SCORE, true, LocScoreCandidate ])
		}
		return F20_LOC_CAND_INFO_LIST_1
	}

	public List getCandList_Loc_2(){
		initCandInfoLists()
		
		List LocScoreCandidate = 
			[ [ 331, eventId, reqIndexZero, MAX_SCORE,
                 [   [ MAX_SCORE, FIN_1, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                     [ MAX_OR_ZERO_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_6, PC2_ROLLED, rollFW ],
                     [ MAX_OR_ZERO_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                     [ MAX_OR_ZERO_SCORE, FIN_9, PC2_ROLLED, rollFW ],
                     [ MAX_OR_ZERO_SCORE, FIN_10, PC2_ROLLED, rollFW ], ] ] ]
		
		for(int i = 1; i <= 255; i++){
			String num	
			if(i < 10){
				num = "0000" + i
			}else if(i< 100){
				num = "000" + i
			}else{
				num = "00" + i
			}
			F20_LOC_CAND_INFO_LIST_2.add([ F20_EXT_ID + num, MAX_SCORE, true, LocScoreCandidate ])
		}
		return F20_LOC_CAND_INFO_LIST_2
	}
	
	public List getCandList_Loc_3(){
		initCandInfoLists()
		
		List LocScoreCandidate = 
			[ [ 331, eventId, reqIndexZero, MAX_SCORE,
                 [   [ MAX_SCORE, FIN_1, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_2, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_3, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_4, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_5, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_6, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_7, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_8, PC2_ROLLED, rollFW ],
                     [ MAX_SCORE, FIN_9, PC2_ROLLED, rollFW ], ] ] ]
		
		for(int i = 1; i <= 10; i++){
			String num
            if(i < 10){
                num = "0000" + i
            }else if(i< 100){
                num = "000" + i
            }
			F20_LOC_CAND_INFO_LIST_1.add([ F20_EXT_ID + num, MAX_SCORE, true, LocScoreCandidate ])
		}
		return F20_LOC_CAND_INFO_LIST_1
	}

	
	public List getCandList_Min_1(){
		initCandInfoLists()
        return [ F21_MIN_CAND_INFO_LIST_1,
				 F21_MIN_CAND_INFO_LIST_2,
				 F21_MIN_CAND_INFO_LIST_3 ]
    }

    public List getCandList_Min_2(){
		initCandInfoLists()
		return [ F21_MIN_CAND_INFO_LIST_1,
                 F21_MIN_CAND_INFO_LIST_3 ]
    }

    public List getCandList_Min_3(){
		initCandInfoLists()
        return [ F21_MIN_CAND_INFO_LIST_3 ]
	}

	public List getCandList_Dyn_1(){
        return [ F22_DYN_CAND_INFO_LIST_3,
				 F22_DYN_CAND_INFO_LIST_5 ]
    }

    public List getCandList_Dyn_2(){
		initCandInfoLists()
		return [ F22_DYN_CAND_INFO_LIST_2,
                 F22_DYN_CAND_INFO_LIST_3 ]
    }

    public List getCandList_Dyn_3(){
		initCandInfoLists()
		return [ F22_DYN_CAND_INFO_LIST_1,
                 F22_DYN_CAND_INFO_LIST_5,
                 F22_DYN_CAND_INFO_LIST_3 ]
    }
	
	public List getCandList_lost_1(){
		initCandInfoLists()
        return [ F24_LOST_CAND_INFO_LIST_1 ]
    }

	public List getCandList_lost_2(){
        initCandInfoLists()
		return [ F24_LOST_CAND_INFO_LIST_2 ]
    }

	public List getCandList_lost_3(){
		initCandInfoLists()
        return [ F24_LOST_CAND_INFO_LIST_3 ]
    }

	public List getCandList_afis_1() {
        initCandInfoLists()
        return [    F28_AFIS_CAND_INFO_LIST_1,
					F28_AFIS_CAND_INFO_LIST_2 ]
    }

	public List getCandList_afis_2() {
        initCandInfoLists()
        if(level == "low") {
        	return [    F28_AFIS_CAND_INFO_LIST_5,
						F28_AFIS_CAND_INFO_LIST_6 ]
        }else{
        	return [    F28_AFIS_CAND_INFO_LIST_3,
						F28_AFIS_CAND_INFO_LIST_4 ]
	    }
	}

	public List getCandList_scope12_1() {
		initCandInfoLists()
		return [	F29_SCOPE12_CAND_INFO_LIST_1 ]
	}

	public List getCandList_scope12_2() {
		initCandInfoLists()
        if(level == "low") {
            F29_SCOPE12_CAND_INFO_LIST_2 =
                 [ F29_EXT_ID + NUMBER_04, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_SCOPE2_5 ] ]
        }
            
		return [ F29_SCOPE12_CAND_INFO_LIST_2 ]
	}

	public List getCandList_scope12_3() {
		initCandInfoLists()
		return [	F29_SCOPE12_CAND_INFO_LIST_1,
					F29_SCOPE12_CAND_INFO_LIST_3 ]
	}

	public List getCandList_scope12_4() {
		initCandInfoLists()
		return [	F29_SCOPE12_CAND_INFO_LIST_4,
					F29_SCOPE12_CAND_INFO_LIST_5 ]
	}

	public List getCandList_scope12_5() {
		initCandInfoLists()
        if(level == "low") {
            F29_SCOPE12_CAND_INFO_LIST_6 =
                 [ F29_EXT_ID + NUMBER_02, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_5 ] ]
            F29_SCOPE12_CAND_INFO_LIST_7 =
                 [ F29_EXT_ID + NUMBER_04, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_SCOPE2_5 ] ]
        }
		return [	F29_SCOPE12_CAND_INFO_LIST_6,
					F29_SCOPE12_CAND_INFO_LIST_7 ]
	}
	
	public List getCandList_scope12_6() {
		initCandInfoLists()
		return [	F29_SCOPE12_CAND_INFO_LIST_1,
					F29_SCOPE12_CAND_INFO_LIST_3,
					F29_SCOPE12_CAND_INFO_LIST_4,
					F29_SCOPE12_CAND_INFO_LIST_8 ]
	}
	
	public List getCandList_scope12_7() {
		initCandInfoLists()
		return [	F29_SCOPE12_CAND_INFO_LIST_4 ]
	}
	
	public List getCandList_scope123_1() {
		initCandInfoLists()
		return [	F31_SCOPE123_CAND_INFO_LIST_1,
					F31_SCOPE123_CAND_INFO_LIST_2 ]
	}

	public List getCandList_scope123_2() {
		initCandInfoLists()
        if(level == "low") {
            F31_SCOPE123_CAND_INFO_LIST_3 =
                 [ F31_EXT_ID + NUMBER_04, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_SCOPE2_5 ] ]
            F31_SCOPE123_CAND_INFO_LIST_4 =
                 [ F31_EXT_ID + NUMBER_06, MAX_SCORE, true, [ MAX_SCORE_CANDIDATE_SCOPE3_5 ] ]
        }
		return [	F31_SCOPE123_CAND_INFO_LIST_3,
					F31_SCOPE123_CAND_INFO_LIST_4 ]
	}
	
	public List getCandList_scope123_3() {
		initCandInfoLists()
		return [	F31_SCOPE123_CAND_INFO_LIST_1,
					F31_SCOPE123_CAND_INFO_LIST_5,
					F31_SCOPE123_CAND_INFO_LIST_6,
					F31_SCOPE123_CAND_INFO_LIST_7 ]
	}
	public List getCandList_scope123_4() {
		initCandInfoLists()
		return [	F31_SCOPE123_CAND_INFO_LIST_1,
					F31_SCOPE123_CAND_INFO_LIST_2,
					F31_SCOPE123_CAND_INFO_LIST_5,
					F31_SCOPE123_CAND_INFO_LIST_6,
					F31_SCOPE123_CAND_INFO_LIST_7,
					F31_SCOPE123_CAND_INFO_LIST_8 ]
	}

	public List getCandList_fWeight_1_to_1_01(Integer rollFW, Integer slapFW) {
		this.rollFW = rollFW
		this.slapFW = slapFW
		initCandInfoLists()
		return [ F30_FW_CAND_INFO_LIST_1 ]
	}

	public List getCandList_fWeight_2_to_1(Integer rollFW, Integer slapFW) {
		this.rollFW = rollFW
		this.slapFW = slapFW
		initCandInfoLists()
		return [ F30_FW_CAND_INFO_LIST_2 ]
	}

	public List getCandList_fWeight_2_to_2_01(Integer rollFW, Integer slapFW) {
		this.rollFW = rollFW
		this.slapFW = slapFW
		initCandInfoLists()
		return [ F30_FW_CAND_INFO_LIST_3 ]
	}

	public List getCandList_fWeight_2_to_2_02(Integer rollFW, Integer slapFW) {
		this.rollFW = rollFW
		this.slapFW = slapFW
		initCandInfoLists()
		return [ F30_FW_CAND_INFO_LIST_4 ]
	}

	public List getCandList_fWeight_1_to_1_02() {
		initCandInfoLists()
		return [ F30_FW_CAND_INFO_LIST_5 ]
	}

	public List getCandList_candSort() {
		initCandInfoLists()
		return [ F48_HIGH_A_CAND_INFO_LIST, 
				F48_HIGH_B_CAND_INFO_LIST,
				F48_HIGH_C_CAND_INFO_LIST, 
				F48_LOW_A_CAND_INFO_LIST, 
				F48_LOW_B_CAND_INFO_LIST, 
				F48_LOW_C_CAND_INFO_LIST ]
	}


	public List getCandList_protBuff_TIM_scope(){
		initCandInfoLists()
        return [ F17_TARGET_DB_CAND_INFO_LIST_1,
				 F17_TARGET_DB_CAND_INFO_LIST_4 ]
    }

	public List getCandList_aggregation(){
		initCandInfoLists()
		if(timEngine == CML){
			return [ AGGREGATION_CAND_INFO_LIST_3,
					 AGGREGATION_CAND_INFO_LIST_4 ]
		}else if(timEngine == CMLAF){
			return [ AGGREGATION_CAND_INFO_LIST_1,
					 AGGREGATION_CAND_INFO_LIST_2 ]
		}
	}

	public List getCandList_applyParamId(int id){
		switch(id){
			case 1:
			case 3:
				return [ CML_PARAMID_CAND_INFO_LIST_1,
				 		 CML_PARAMID_CAND_INFO_LIST_2]
			case 2:
			case 4:
				return [ CML_PARAMID_CAND_INFO_LIST_1,
						 CML_PARAMID_CAND_INFO_LIST_3 ]
			default:
				abendTest(id)
		}
	}

	public List getCandList_paramId(int id){
		switch(id){
			case 1:
			case 5:
				return [ CML_PARAMID_CAND_INFO_LIST_1,
						 CML_PARAMID_CAND_INFO_LIST_3 ]
			case 2:
			case 3:
				return []
			case 4:
				return [ CML_PARAMID_CAND_INFO_LIST_1,
						 CML_PARAMID_CAND_INFO_LIST_2]
			default:
				abendTest(id)
		}
	}

    public List getCandList_MinScore(int id){
		switch(id){
			case 1:
				return [ F21_MIN_CAND_INFO_LIST_4 ]
			case 2:
				return [ F21_MIN_CAND_INFO_LIST_5 ]
			default:
				abendTest(id)
		}
	}

	public List getCandList_Cmlaf_MinScore(int id){
		switch(id){
			case 1:
			case 3:
				return [ CML_PARAMID_CAND_INFO_LIST_1 ]
			case 2:
			case 4:
				return [ CML_PARAMID_CAND_INFO_LIST_1,
						 CML_PARAMID_CAND_INFO_LIST_4 ]
			default:
				abendTest(id)
		}
	}

	public List getCandList_Dyn(int id){
		switch(id){
			case 1:
			case 3:
			case 6:
				return [ F22_DYN_CAND_INFO_LIST_3,
						 F22_DYN_CAND_INFO_LIST_2 ]
			case 2:
			case 4:
			case 5:
				return [ F22_DYN_CAND_INFO_LIST_3,
						 F22_DYN_CAND_INFO_LIST_5 ]
			default:
				abendTest(id)
		}

    }

	public List getCandList_ApplyRotation(int id){
		switch(id){
			case 1:
			case 3:
				return [ CML_ROTATION_3_CAND_INFO_LIST ]
			case 2:
				return [ CML_ROTATION_1_CAND_INFO_LIST ]
			default:
				abendTest(id)
		}
	}

	public List getCandList_rotation(int id){
		switch(id){
			case 1:
			case 2:
			case 6:
				return [ CML_ROTATION_1_CAND_INFO_LIST ]
			case 3:
			case 4:
			case 5:
				return [ CML_ROTATION_3_CAND_INFO_LIST ]
			default:
				abendTest(id)
		}
	}

	public void setBaseAsserionScore(){
		if(timEngine == CML){
			print("!!!!")
			setCmlBaseAssertionScore()
		}else if(timEngine == CMLAF){
			setCmlafBaseAssertionScore()
		}
	}

	private setCmlBaseAssertionScore() {
		MAX_OR_ZERO_SCORE = 0
		ROT_BY_AXIS_SCORE = 8688
		BASIC_CSCORE_1 = 1228
		BASIC_SCORE_1_1F = 1227
		BASIC_SCORE_1_2F = 0
		BASIC_SCORE_1_3F = 49
		BASIC_SCORE_1_4F = -12
		BASIC_SCORE_1_5F = ZERO_SCORE
		BASIC_SCORE_1_6F = -12
		BASIC_SCORE_1_7F = ZERO_SCORE
		BASIC_SCORE_1_8F = -12
		BASIC_SCORE_1_9F = -12
		BASIC_SCORE_1_10F = ZERO_SCORE

		BASIC_SCORE_2_1F = 353

		BASIC_CSCORE_3 = 3360
		BASIC_SCORE_3_1F = 3396
		BASIC_SCORE_3_2F = ZERO_SCORE
		BASIC_SCORE_3_3F = -12
		BASIC_SCORE_3_4F = ZERO_SCORE
		BASIC_SCORE_3_5F = ZERO_SCORE
		BASIC_SCORE_3_6F = -12
		BASIC_SCORE_3_7F = ZERO_SCORE
		BASIC_SCORE_3_8F = ZERO_SCORE
		BASIC_SCORE_3_9F = -12
		BASIC_SCORE_3_10F = ZERO_SCORE

		BASIC_CSCORE_4 = 767
		BASIC_SCORE_4_1F = 827
		BASIC_SCORE_4_2F = ZERO_SCORE
		BASIC_SCORE_4_3F = -12
		BASIC_SCORE_4_4F = ZERO_SCORE
		BASIC_SCORE_4_5F = -12
		BASIC_SCORE_4_6F = -12
		BASIC_SCORE_4_7F = ZERO_SCORE
		BASIC_SCORE_4_8F = -12
		BASIC_SCORE_4_9F = ZERO_SCORE
		BASIC_SCORE_4_10F = -12

		BASIC_CSCORE_5 = 2526
		BASIC_SCORE_5_1F = 2562
		BASIC_SCORE_5_2F = ZERO_SCORE
		BASIC_SCORE_5_3F = -12
		BASIC_SCORE_5_4F = ZERO_SCORE
		BASIC_SCORE_5_5F = ZERO_SCORE
		BASIC_SCORE_5_6F = -12
		BASIC_SCORE_5_7F = ZERO_SCORE
		BASIC_SCORE_5_8F = ZERO_SCORE
		BASIC_SCORE_5_9F = -12
		BASIC_SCORE_5_10F = ZERO_SCORE

		BASIC_SCORE_6_1F = 1503
		BASIC_SCORE_6_10F = 87

		BASIC_SCORE_7_1F = 1557
		BASIC_SCORE_7_2F = 13
		BASIC_SCORE_7_7F = 55
		BASIC_SCORE_7_10F = 181
		BASIC_SCORE_8_1F = 2219
		BASIC_SCORE_8_9F = 58

		BASIC_SCORE_9_1F = MAX_SCORE
		BASIC_SCORE_9_2F = ZERO_SCORE
		BASIC_SCORE_9_3F = 1670
		BASIC_SCORE_9_4F = ZERO_SCORE
		BASIC_SCORE_9_5F = MAX_SCORE
		BASIC_SCORE_9_6F = MAX_SCORE
		BASIC_SCORE_9_7F = ZERO_SCORE
		BASIC_SCORE_9_8F = 4661
		BASIC_SCORE_9_9F = 4007
		BASIC_SCORE_9_10F = ZERO_SCORE

		BASIC_SCORE_10_1F = MAX_SCORE
		BASIC_SCORE_10_2F = ZERO_SCORE
		BASIC_SCORE_10_3F = 1670
		BASIC_SCORE_10_4F = ZERO_SCORE
		BASIC_SCORE_10_5F = MAX_SCORE
		BASIC_SCORE_10_6F = MAX_SCORE
		BASIC_SCORE_10_7F = ZERO_SCORE
		BASIC_SCORE_10_8F = 4661
		BASIC_SCORE_10_9F = 4350
		BASIC_SCORE_10_10F = ZERO_SCORE
	}

	private setCmlafBaseAssertionScore() {
		MAX_OR_ZERO_SCORE = 9999
		ROT_BY_AXIS_SCORE = 8688
		BASIC_CSCORE_1 = 852
		BASIC_SCORE_1_1F = 466
		BASIC_SCORE_1_2F = 202
		BASIC_SCORE_1_3F = 31
		BASIC_SCORE_1_4F = ZERO_SCORE
		BASIC_SCORE_1_5F = 74
		BASIC_SCORE_1_6F = 36
		BASIC_SCORE_1_7F = ZERO_SCORE
		BASIC_SCORE_1_8F = ZERO_SCORE
		BASIC_SCORE_1_9F = ZERO_SCORE
		BASIC_SCORE_1_10F = 42

		basic_score_2 = 860
		BASIC_SCORE_2_1F = 475
		BASIC_SCORE_2_2F = 202
		BASIC_SCORE_2_3F = 31
		BASIC_SCORE_2_5F = 74
		BASIC_SCORE_2_6F = 36
		BASIC_SCORE_2_10F = 42

		BASIC_CSCORE_3 = 1307
		BASIC_SCORE_3_1F = 1271
		BASIC_SCORE_3_2F = ZERO_SCORE
		BASIC_SCORE_3_3F = ZERO_SCORE
		BASIC_SCORE_3_4F = ZERO_SCORE
		BASIC_SCORE_3_5F = ZERO_SCORE
		BASIC_SCORE_3_6F = 36
		BASIC_SCORE_3_7F = ZERO_SCORE
		BASIC_SCORE_3_8F = ZERO_SCORE
		BASIC_SCORE_3_9F = ZERO_SCORE
		BASIC_SCORE_3_10F = ZERO_SCORE

		BASIC_CSCORE_4 =680
		BASIC_SCORE_4_1F = 475
		BASIC_SCORE_4_2F = ZERO_SCORE
		BASIC_SCORE_4_3F = ZERO_SCORE
		BASIC_SCORE_4_4F = ZERO_SCORE
		BASIC_SCORE_4_5F = 74
		BASIC_SCORE_4_6F = 14
		BASIC_SCORE_4_7F = ZERO_SCORE
		BASIC_SCORE_4_8F = ZERO_SCORE
		BASIC_SCORE_4_9F = 67
		BASIC_SCORE_4_10F = 48

		BASIC_CSCORE_5 = 1266
		BASIC_SCORE_5_1F = 1170
		BASIC_SCORE_5_2F = ZERO_SCORE
		BASIC_SCORE_5_3F = ZERO_SCORE
		BASIC_SCORE_5_4F = ZERO_SCORE
		BASIC_SCORE_5_5F = ZERO_SCORE
		BASIC_SCORE_5_6F = 14
		BASIC_SCORE_5_7F = ZERO_SCORE
		BASIC_SCORE_5_8F = ZERO_SCORE
		BASIC_SCORE_5_9F = 81
		BASIC_SCORE_5_10F = ZERO_SCORE

		BASIC_CSCORE_6 = 1934
		BASIC_SCORE_6_1F = 1509
		BASIC_SCORE_6_3F = 33
		BASIC_SCORE_6_5F = 74
		BASIC_SCORE_6_7F = 53
		BASIC_SCORE_6_9F = 93
		BASIC_SCORE_6_10F = 171

		BASIC_CSCORE_7 = 2107
		BASIC_SCORE_7_1F = 1557
		BASIC_SCORE_7_2F = 13
		BASIC_SCORE_7_3F = 36
		BASIC_SCORE_7_5F = 74
		BASIC_SCORE_7_6F = 67
		BASIC_SCORE_7_7F = 55
		BASIC_SCORE_7_8F = 29
		BASIC_SCORE_7_9F = 93
		BASIC_SCORE_7_10F = 181
		
		BASIC_SCORE_8_1F = 2219
		BASIC_SCORE_8_9F = 58

		BASIC_SCORE_9_1F = MAX_SCORE
		BASIC_SCORE_9_2F = 4418
		BASIC_SCORE_9_3F = 1410
		BASIC_SCORE_9_4F = 1552
		BASIC_SCORE_9_5F = 4935
		BASIC_SCORE_9_6F = 9595
		BASIC_SCORE_9_7F = 4857
		BASIC_SCORE_9_8F = 1891
		BASIC_SCORE_9_9F = 2494
		BASIC_SCORE_9_10F = 3889

		BASIC_SCORE_10_1F = 9845
		BASIC_SCORE_10_2F = 4753
		BASIC_SCORE_10_3F = 1276
		BASIC_SCORE_10_4F = 1961
		BASIC_SCORE_10_5F = 4268
		BASIC_SCORE_10_6F = 9697
		BASIC_SCORE_10_7F = 4649
		BASIC_SCORE_10_8F = 2313
		BASIC_SCORE_10_9F = 2920
		BASIC_SCORE_10_10F = 3763
		
		BASIC_CSCORE_11 = 605
		BASIC_SCORE_11_1F = 475
		BASIC_SCORE_11_6F = 14
		BASIC_SCORE_11_9F = 67
		BASIC_SCORE_11_10F = 48

	}
	
	public int getYobThErrCode(){
		if(timEngine == CML){
			return 834101116
		}else if(timEngine == CMLAF){
			return 834101070
		}
	}

	public String getYobThErrMessg(int actYobTh){
		if(timEngine == CML){
			return "Invalid payload YOB THRESHOLD (${actYobTh})"
		}else if(timEngine == CMLAF){
			return "Invalid payload CMLAF TI YOB THRESHOLD (${actYobTh})"
		}
	}

	public String makePayload(def dataSrcTestStep){
		return payloadHelper.makePayload(dataSrcTestStep)
	}

    public String makePayload() {
		return payloadHelper.makePayload()
    }

    private void abendTest(int id){
        new AbendProcessor(soapuiObj.getContext()).abendTest("Unexpected id value '${id}'.")
    }

}
