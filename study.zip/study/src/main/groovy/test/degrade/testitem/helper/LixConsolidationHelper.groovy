package test.degrade.testitem.helper

import static test.common.constants.aim.AIMXmlAttribute.*

class LixConsolidationHelper extends ConsolidationHelper {

	private static final String F1A_EXT_ID = "LIX_F1A_PC2R"
	private static final String F2A_EXT_ID = "LIX_F2A_PC2S"
	private static final String F3A_EXT_ID = "LIX_F3A_FMP5R"
	private static final String F4A_EXT_ID = "LIX_F4A_FMP5S"
	private static final String F5A_EXT_ID = "LIX_F5A_PC2RS"
	private static final String F6A_EXT_ID = "LIX_F6A_FMP5RS"
	private static final String F7A_EXT_ID = "LIX_F7A_PC2R_FMP5R"
	private static final String F8A_EXT_ID = "LIX_F8A_PC2S_FMP5S"
	private static final String F9A_EXT_ID = "LIX_F9A_PC2S_FMP5R"
	private static final String F10A_EXT_ID = "LIX_F10A_PC2RS_FMP5RS"
	private static final String F11A_EXT_ID = "LIX_F11A_PC2RS_FMP5RS"
	private static final String F12A_EXT_ID = "LIX_F12A"
	private static final String F13A_EXT_ID = "LIX_F13A"
	private static final String F14A_EXT_ID = "LIX_F14A"
	private static final String F15A_EXT_ID = "LIX_F15A_PC2RS_FMP5RS"
	private static final String F_123_ABC_HIGH_EXT_ID = "LIX-123-ABC-High"
	private static final String F_ABC_123_HIGH_EXT_ID = "LIX-ABC-123-High"
	private static final String F_BBC_123_HIGH_EXT_ID = "LIX-BBC-123-High"
	private static final String F_123_ABC_LOW_EXT_ID = "LIX-123-ABC-Low"
	private static final String F_ABC_123_LOW_EXT_ID = "LIX-ABC-123-Low"
	private static final String F_BBC_123_LOW_EXT_ID = "LIX-BBC-123-Low"
	private static final int PC2_ROLLED_1_SCORE = 554
	private static final int PC2_ROLLED_6_SCORE = 1736
	private static final int PC2_SLAP_1_SCORE = 1570
	private static final int PC2_SLAP_6_SCORE = 1570 //PC2_SLAP_1_SCORE
	private static final int PC2_SLAP_10_SCORE = 570
	private static final int FMP5_ROLLED_1_A_F3_SCORE = 594
	private static final int FMP5_ROLLED_1_C_F3_SCORE = 798
	private static final int FMP5_ROLLED_1_D_F3_SCORE = FMP5_ROLLED_1_C_F3_SCORE
	private static final int FMP5_ROLLED_1_A_F6_SCORE = 748
	private static final int FMP5_ROLLED_1_B_F6_SCORE = 859
	private static final int FMP5_ROLLED_1_C_F6_SCORE = 812
	private static final int FMP5_ROLLED_1_D_F6_SCORE = 960
	private static final int FMP5_ROLLED_1_SCORE = 739
	private static final int FMP5_ROLLED_2_SCORE = 1128
	private static final int FMP5_SLAP_1_SCORE = 2016
	private static final int FMP5_SLAP_1_A_F4_SCORE = 1697
	private static final int FMP5_SLAP_1_C_F4_SCORE = 1849
	private static final int FMP5_SLAP_1_D_F4_SCORE = FMP5_SLAP_1_C_F4_SCORE
	private static final int FMP5_SLAP_1_A_F6_SCORE = 1928
	private static final int FMP5_SLAP_1_B_F6_SCORE = 1494
	private static final int FMP5_SLAP_1_C_F6_SCORE = 2284
	private static final int FMP5_SLAP_1_D_F6_SCORE = 1197
	private static final int FMP5_SLAP_2_SCORE = 903
	private static final int FMP5_SLAP_5_SCORE = FMP5_ROLLED_2_SCORE

	private Integer fmp5FW = 100/100
	private Integer pc2FW = 200/100

	private final List F1A_CAND_INFO_LIST_BY_PC2 = 
		[ F1A_EXT_ID, PC2_ROLLED_1_SCORE * pc2FW, true, 
			[ [ 341, 1, 0, PC2_ROLLED_1_SCORE * pc2FW,
				[ [ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ] ]
			] ]
		]
	private final List F2A_CAND_INFO_LIST_BY_PC2 = 
		[ F2A_EXT_ID, PC2_SLAP_1_SCORE * pc2FW, true, 
			[ [ 341, 1, 0, PC2_SLAP_1_SCORE * pc2FW,
				[ [ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, 200 ] ]
			] ]
		]
	private final List F5A_CAND_INFO_LIST_BY_PC2 = 
		[ F5A_EXT_ID, PC2_SLAP_1_SCORE * pc2FW, true, 
			[ [ 341, 1, 0, PC2_SLAP_1_SCORE * pc2FW,
				[ [ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ], 
				  [ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, 200 ] ]
			] ]
		]
	private final List F7A_CAND_INFO_LIST_BY_PC2 = 
		[ F7A_EXT_ID, PC2_ROLLED_1_SCORE * pc2FW, true, 
			[ [ 341, 1, 0, PC2_ROLLED_1_SCORE * pc2FW,
				[ [ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ] ]
			] ]
		]
	private final List F8A_CAND_INFO_LIST_BY_PC2 = 
		[ F8A_EXT_ID, PC2_SLAP_1_SCORE * pc2FW, true, 
			[ [ 341, 1, 0, PC2_SLAP_1_SCORE * pc2FW,
				[ [ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, 200 ] ]
			] ]
		]
	private final List F9A_CAND_INFO_LIST_BY_PC2 = 
		[ F9A_EXT_ID, PC2_SLAP_1_SCORE * pc2FW, true, 
			[ [ 341, 1, 0, PC2_SLAP_1_SCORE * pc2FW,
				[ [ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, 200 ] ]
			] ]
		]
	private final List F10A_CAND_INFO_LIST_BY_PC2 = 
		[ F10A_EXT_ID, PC2_SLAP_1_SCORE * pc2FW, true, 
			[ [ 341, 1, 0, PC2_SLAP_1_SCORE * pc2FW,
				[ [ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ], 
				  [ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, 200 ] ]
			] ]
		]
	private final List F11A_CAND_INFO_LIST_BY_PC2 = 
		[ F11A_EXT_ID, PC2_ROLLED_6_SCORE * pc2FW, true, 
			[ [ 341, 1, 0, PC2_ROLLED_6_SCORE * pc2FW,
				[ 
					[ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ], 
					[ PC2_ROLLED_6_SCORE, FIN_6, A, PC2_ROLLED, 200 ], 
					[ PC2_SLAP_6_SCORE, FIN_6, A, PC2_SLAP, 200 ],
				]
			] ]
		]
	private final List F12A_CAND_INFO_LIST_BY_PC2 = 
		[ F12A_EXT_ID, PC2_SLAP_1_SCORE * pc2FW, true, 
			[ [ 341, 2, 0, PC2_SLAP_1_SCORE * pc2FW,
				[ [ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ], 
				  [ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, 200 ] ] ],
			  [ 341, 4, 0, PC2_SLAP_1_SCORE * pc2FW,
				[ [ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ], 
				  [ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, 200 ] ] ],
			  [ 341, 1, 0, PC2_ROLLED_1_SCORE * pc2FW,
				[ [ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ], ] ],
			]
		]
	private final List F13A_CAND_INFO_LIST_BY_PC2 = 
		[ F13A_EXT_ID, PC2_SLAP_1_SCORE * pc2FW, true, 
			[ [ 1341, 1, 0, PC2_SLAP_1_SCORE * pc2FW,
				[ [ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ], 
				  [ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, 200 ] ] ],
			  [ 5341, 1, 0, PC2_SLAP_1_SCORE * pc2FW,
				[ [ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ], 
				  [ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, 200 ] ] ],
			  [ 341, 1, 0, PC2_ROLLED_1_SCORE * pc2FW,
				[ [ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ], ] ],
			]
		]



	private final List F3A_CAND_INFO_LIST_BY_FMP5 = 
		[ F3A_EXT_ID, FMP5_ROLLED_1_SCORE, true, 
			[ [ 341, 1, 0, FMP5_ROLLED_1_SCORE,
				[ [ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, 100 ] ]
			] ]
		]
	private final List F4A_CAND_INFO_LIST_BY_FMP5 = 
		[ F4A_EXT_ID, FMP5_SLAP_1_SCORE, true, 
			[ [ 341, 1, 0, FMP5_SLAP_1_SCORE,
				[ [ FMP5_SLAP_1_SCORE, FIN_1, A, FMP5_SLAP, 100 ] ]
			] ]
		]
	private static final List F6A_CAND_INFO_LIST_BY_FMP5 = 
		[ F6A_EXT_ID, FMP5_SLAP_1_SCORE, true, 
			[ [ 341, 1, 0, FMP5_SLAP_1_SCORE,
				[ [ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, 100 ], 
				  [ FMP5_SLAP_1_SCORE, FIN_1, A, FMP5_SLAP, 100 ] ]
			] ]
		]
	private final List F7A_CAND_INFO_LIST_BY_FMP5 = 
		[ F7A_EXT_ID, FMP5_ROLLED_1_SCORE, true, 
			[ [ 341, 1, 0, FMP5_ROLLED_1_SCORE,
				[ [ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, 100 ] ]
			] ]
		]
	private final List F8A_CAND_INFO_LIST_BY_FMP5 = 
		[ F8A_EXT_ID, FMP5_SLAP_1_SCORE, true, 
			[ [ 341, 1, 0, FMP5_SLAP_1_SCORE,
				[ [ FMP5_SLAP_1_SCORE, FIN_1, A, FMP5_SLAP, 100 ] ]
			] ]
		]
	private final List F9A_CAND_INFO_LIST_BY_FMP5 = 
		[ F9A_EXT_ID, FMP5_ROLLED_1_SCORE, true, 
			[ [ 341, 1, 0, FMP5_ROLLED_1_SCORE,
				[ [ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, 100 ] ]
			] ]
		]
	private static final List F10A_CAND_INFO_LIST_BY_FMP5 = 
		[ F10A_EXT_ID, FMP5_SLAP_1_SCORE, true, 
			[ [ 341, 1, 0, FMP5_SLAP_1_SCORE,
				[ [ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, 100 ], 
				  [ FMP5_SLAP_1_SCORE, FIN_1, A, FMP5_SLAP, 100 ] ]
			] ]
		]
	private final List F11A_CAND_INFO_LIST_BY_FMP5 = 
		[ F11A_EXT_ID, FMP5_SLAP_1_SCORE, true, 
			[ [ 341, 1, 0, FMP5_SLAP_1_SCORE,
				[ 
					[ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, 100 ], 
					[ FMP5_ROLLED_2_SCORE, FIN_2, A, FMP5_ROLLED, 100 ], 
					[ FMP5_SLAP_1_SCORE, FIN_1, A, FMP5_SLAP, 100 ],
					[ FMP5_SLAP_2_SCORE, FIN_2, A, FMP5_SLAP, 100 ],
					[ FMP5_SLAP_5_SCORE, FIN_5, A, FMP5_SLAP, 100 ],
				]
			] ]
		]
	private static final List F12A_CAND_INFO_LIST_BY_FMP5 = 
		[ F12A_EXT_ID, FMP5_SLAP_1_SCORE, true, 
			[ [ 341, 3, 0, FMP5_SLAP_1_SCORE,
				[ [ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, 100 ], 
				  [ FMP5_SLAP_1_SCORE, FIN_1, A, FMP5_SLAP, 100 ] ] ],
			  [ 341, 4, 0, FMP5_SLAP_1_SCORE,
				[ [ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, 100 ], 
				  [ FMP5_SLAP_1_SCORE, FIN_1, A, FMP5_SLAP, 100 ] ]
			] ]
		]
	private static final List F13A_CAND_INFO_LIST_BY_FMP5 = 
		[ F13A_EXT_ID, FMP5_SLAP_1_SCORE, true, 
			[ [ 2341, 1, 0, FMP5_SLAP_1_SCORE,
				[ [ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, 100 ], 
				  [ FMP5_SLAP_1_SCORE, FIN_1, A, FMP5_SLAP, 100 ] ] ],
			  [ 5341, 1, 0, FMP5_SLAP_1_SCORE,
				[ [ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, 100 ], 
				  [ FMP5_SLAP_1_SCORE, FIN_1, A, FMP5_SLAP, 100 ] ]
			] ]
		]


	private final List F1A_CAND_INFO_LIST_BY_BOTH = 
		[ F1A_EXT_ID, PC2_ROLLED_1_SCORE * pc2FW, true, 
			[ [ 341, 1, 0, PC2_ROLLED_1_SCORE * pc2FW,
				[ 
					[ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ] 
				]
			] ]
		]
	private final List F2A_CAND_INFO_LIST_BY_BOTH = 
		[ F2A_EXT_ID, PC2_SLAP_1_SCORE * pc2FW, true, 
			[ [ 341, 1, 0, PC2_SLAP_1_SCORE * pc2FW,
				[ 
					[ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, 200 ], 
				]
			] ]
		]
	private  final List F3A_CAND_INFO_LIST_BY_BOTH = 
		[ F3A_EXT_ID, FMP5_ROLLED_1_SCORE, true, 
			[ [ 341, 1, 0, FMP5_ROLLED_1_SCORE,
				[ 
					[ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, 100 ]
				]
			] ]
		]
	private static final List F4A_CAND_INFO_LIST_BY_BOTH = 
		[ F4A_EXT_ID, FMP5_SLAP_1_SCORE, true, 
			[ [ 341, 1, 0, FMP5_SLAP_1_SCORE,
				[ 
					[ FMP5_SLAP_1_SCORE, FIN_1, A, FMP5_SLAP, 100 ], 
				]
			] ]
		]
	private final List F5A_CAND_INFO_LIST_BY_BOTH = 
		[ F5A_EXT_ID, PC2_SLAP_1_SCORE * pc2FW, true, 
			[ [ 341, 1, 0, PC2_SLAP_1_SCORE * pc2FW,
				[ 
					[ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ], 
					[ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, 200 ] 
				]
			] ]
		]
	private static final List F6A_CAND_INFO_LIST_BY_BOTH = 
		[ F6A_EXT_ID, FMP5_SLAP_1_SCORE, true, 
			[ [ 341, 1, 0, FMP5_SLAP_1_SCORE,
				[ 
					[ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, 100 ], 
					[ FMP5_SLAP_1_SCORE, FIN_1, A, FMP5_SLAP, 100 ] 
				]
			] ]
		]
	private final List F7A_CAND_INFO_LIST_BY_BOTH = 
		[ F7A_EXT_ID, PC2_ROLLED_1_SCORE * pc2FW + FMP5_ROLLED_1_SCORE, true, 
			[ [ 341, 1, 0, PC2_ROLLED_1_SCORE * pc2FW + FMP5_ROLLED_1_SCORE,
				[ 
					[ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ], 
					[ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, 100 ] 
				]
			] ]
		]
	private final List F8A_CAND_INFO_LIST_BY_BOTH = 
		[ F8A_EXT_ID, PC2_SLAP_1_SCORE * pc2FW + FMP5_SLAP_1_SCORE, true, 
			[ [ 341, 1, 0, PC2_SLAP_1_SCORE * pc2FW + FMP5_SLAP_1_SCORE,
				[ 
					[ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, 200 ], 
					[ FMP5_SLAP_1_SCORE, FIN_1, A, FMP5_SLAP, 100 ] 
				]
			] ]
		]
	private final List F9A_CAND_INFO_LIST_BY_BOTH = 
		[ F9A_EXT_ID, PC2_SLAP_1_SCORE * pc2FW + FMP5_ROLLED_1_SCORE, true, 
			[ [ 341, 1, 0, PC2_SLAP_1_SCORE * pc2FW + FMP5_ROLLED_1_SCORE,
				[ 
					[ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, 200 ], 
					[ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, 100 ], 
				]
			] ]
		]
	private final List F10A_CAND_INFO_LIST_BY_BOTH = 
		[ F10A_EXT_ID, PC2_SLAP_1_SCORE * pc2FW + FMP5_SLAP_1_SCORE, true, 
			[ [ 341, 1, 0, PC2_SLAP_1_SCORE * pc2FW + FMP5_SLAP_1_SCORE,
				[ 
					[ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ], 
					[ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, 200 ], 
					[ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, 100 ], 
					[ FMP5_SLAP_1_SCORE, FIN_1, A, FMP5_SLAP, 100 ] 
				]
			] ]
		]
	private final List F11A_CAND_INFO_LIST_BY_BOTH = 
		[ F11A_EXT_ID, PC2_ROLLED_6_SCORE * pc2FW + FMP5_SLAP_1_SCORE, true, 
			[ [ 341, 1, 0, PC2_ROLLED_6_SCORE * pc2FW + FMP5_SLAP_1_SCORE,
				[ 
					[ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ], 
					[ PC2_ROLLED_6_SCORE, FIN_6, A, PC2_ROLLED, 200 ], 
					[ PC2_SLAP_6_SCORE, FIN_6, A, PC2_SLAP, 200 ],
					[ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, 100 ], 
					[ FMP5_ROLLED_2_SCORE, FIN_2, A, FMP5_ROLLED, 100 ], 
					[ FMP5_SLAP_1_SCORE, FIN_1, A, FMP5_SLAP, 100 ],
					[ FMP5_SLAP_2_SCORE, FIN_2, A, FMP5_SLAP, 100 ],
					[ FMP5_SLAP_5_SCORE, FIN_5, A, FMP5_SLAP, 100 ],
				]
			] ]
		]
	private final List F11A_CAND_INFO_LIST_BY_BOTH_2EVENT = 
		[ F11A_EXT_ID, PC2_ROLLED_6_SCORE * pc2FW + FMP5_SLAP_1_SCORE, true, 
			[	F11A_CAND_INFO_LIST_BY_BOTH[3][0],
			 	[ 341, 2, 0, PC2_SLAP_10_SCORE * pc2FW,
					[ [ PC2_SLAP_10_SCORE, FIN_10, A, PC2_SLAP, 200 ], ]
			 	]
			]
		]
	private final List F12A_CAND_INFO_LIST_BY_BOTH = 
		[ F12A_EXT_ID, PC2_SLAP_1_SCORE * pc2FW + FMP5_SLAP_1_SCORE, true, 
			[ 
				[ 341, 4, 0, PC2_SLAP_1_SCORE * pc2FW + FMP5_SLAP_1_SCORE,
					[ [ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ], 
				  		[ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, 200 ], 
						[ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, 100 ], 
				  		[ FMP5_SLAP_1_SCORE, FIN_1, A, FMP5_SLAP, 100 ], ] ],
				[ 341, 3, 0, FMP5_SLAP_1_SCORE,
					[ [ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, 100 ], 
				  		[ FMP5_SLAP_1_SCORE, FIN_1, A, FMP5_SLAP, 100 ], ] ],
				[ 341, 2, 0, PC2_SLAP_1_SCORE * pc2FW,
					[ [ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ], 
				  		[ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, 200 ], ] ],
				[ 341, 1, 0, PC2_ROLLED_1_SCORE * pc2FW,
					[ [ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ], ] ],
			 ]
		]
	private final List F13A_CAND_INFO_LIST_BY_BOTH = 
		[ F13A_EXT_ID, PC2_SLAP_1_SCORE * pc2FW + FMP5_SLAP_1_SCORE, true, 
			[ 
				[ 5341, 1, 0, PC2_SLAP_1_SCORE * pc2FW + FMP5_SLAP_1_SCORE,
					[ [ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ], 
				  		[ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, 200 ], 
						[ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, 100 ], 
				  		[ FMP5_SLAP_1_SCORE, FIN_1, A, FMP5_SLAP, 100 ], ] ],
				[ 2341, 1, 0, FMP5_SLAP_1_SCORE,
					[ [ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, 100 ], 
				  		[ FMP5_SLAP_1_SCORE, FIN_1, A, FMP5_SLAP, 100 ], ] ],
				[ 1341, 1, 0, PC2_SLAP_1_SCORE * pc2FW,
					[ [ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ], 
				  		[ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, 200 ], ] ],
				[ 341, 1, 0, PC2_ROLLED_1_SCORE * pc2FW,
					[ [ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ], ] ],
			 ]
		]
	private final List F14A_CAND_INFO_LIST_BY_BOTH = 
		[ F14A_EXT_ID, PC2_SLAP_1_SCORE * pc2FW, true, 
			[ 
				[ 1341, 3, 0, FMP5_SLAP_1_SCORE,
					[ [ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, 100 ], 
				  		[ FMP5_SLAP_1_SCORE, FIN_1, A, FMP5_SLAP, 100 ], ] ],
				[ 1341, 2, 0, PC2_SLAP_1_SCORE * pc2FW,
					[ [ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ], 
				  		[ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, 200 ], ] ],
				[ 341, 2, 0, PC2_SLAP_1_SCORE * pc2FW,
					[ [ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ], 
				  		[ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, 200 ], ] ],
				[ 341, 1, 0, PC2_ROLLED_1_SCORE * pc2FW,
					[ [ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ], ] ],
			 ]
		]



	private final List F3A_CAND_INFO_LIST_BY_FMP5_AXIS_TRUE = 
		[ F3A_EXT_ID, FMP5_ROLLED_1_C_F3_SCORE, true, 
			[ [ 341, 1, 0, FMP5_ROLLED_1_C_F3_SCORE,
				[ [ FMP5_ROLLED_1_C_F3_SCORE, FIN_1, C, FMP5_ROLLED, 100 ] ]
			] ]
		]
	private final List F4A_CAND_INFO_LIST_BY_FMP5_AXIS_TRUE = 
		[ F4A_EXT_ID, FMP5_SLAP_1_C_F4_SCORE, true, 
			[ [ 341, 1, 0, FMP5_SLAP_1_C_F4_SCORE,
				[ [ FMP5_SLAP_1_C_F4_SCORE, FIN_1, C, FMP5_SLAP, 100 ] ]
			] ]
		]
	private final List F6A_CAND_INFO_LIST_BY_FMP5_AXIS_TRUE = 
		[ F6A_EXT_ID, FMP5_SLAP_1_C_F6_SCORE, true, 
			[ [ 341, 1, 0, FMP5_SLAP_1_C_F6_SCORE,
				[ 
					[ FMP5_ROLLED_1_D_F6_SCORE, FIN_1, D, FMP5_ROLLED, 100 ],
					[ FMP5_SLAP_1_C_F6_SCORE, FIN_1, C, FMP5_SLAP, 100 ],
				]
			] ]
		]
	private final List F15A_CAND_INFO_LIST_BY_BOTH_AXIS_TRUE = 
		[ F15A_EXT_ID, PC2_SLAP_1_SCORE * pc2FW + FMP5_SLAP_1_C_F6_SCORE, true, 
			[ [ 341, 1, 0, PC2_SLAP_1_SCORE * pc2FW + FMP5_SLAP_1_C_F6_SCORE,
				[ 
					[ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ],
					[ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, 200 ],
					[ FMP5_ROLLED_1_D_F6_SCORE, FIN_1, D, FMP5_ROLLED, 100 ],
					[ FMP5_SLAP_1_C_F6_SCORE, FIN_1, C, FMP5_SLAP, 100 ],
				]
			] ]
		]

	private final List F3A_CAND_INFO_LIST_BY_FMP5_AXIS_FALSE = 
		[ F3A_EXT_ID, FMP5_ROLLED_1_C_F3_SCORE, true, 
			[ [ 341, 1, 0, FMP5_ROLLED_1_C_F3_SCORE,
				[ 
					[ FMP5_ROLLED_1_A_F3_SCORE, FIN_1, A, FMP5_ROLLED, 100 ],
					[ FMP5_ROLLED_1_C_F3_SCORE, FIN_1, C, FMP5_ROLLED, 100 ],
					[ FMP5_ROLLED_1_D_F3_SCORE, FIN_1, D, FMP5_ROLLED, 100 ],
				]
			] ]
		]
	private final List F4A_CAND_INFO_LIST_BY_FMP5_AXIS_FALSE = 
		[ F4A_EXT_ID, FMP5_SLAP_1_C_F4_SCORE, true, 
			[ [ 341, 1, 0, FMP5_SLAP_1_C_F4_SCORE,
				[ 
					[ FMP5_SLAP_1_A_F4_SCORE, FIN_1, A, FMP5_SLAP, 100 ], 
					[ FMP5_SLAP_1_C_F4_SCORE, FIN_1, C, FMP5_SLAP, 100 ], 
					[ FMP5_SLAP_1_D_F4_SCORE, FIN_1, D, FMP5_SLAP, 100 ], 
				]
			] ]
		]
	private final List F6A_CAND_INFO_LIST_BY_FMP5_AXIS_FALSE = 
		[ F6A_EXT_ID, FMP5_SLAP_1_C_F6_SCORE, true, 
			[ [ 341, 1, 0, FMP5_SLAP_1_C_F6_SCORE,
				[ 
					[ FMP5_ROLLED_1_A_F6_SCORE, FIN_1, A, FMP5_ROLLED, 100 ],
					[ FMP5_ROLLED_1_B_F6_SCORE, FIN_1, B, FMP5_ROLLED, 100 ],
					[ FMP5_ROLLED_1_C_F6_SCORE, FIN_1, C, FMP5_ROLLED, 100 ],
					[ FMP5_ROLLED_1_D_F6_SCORE, FIN_1, D, FMP5_ROLLED, 100 ],
					[ FMP5_SLAP_1_A_F6_SCORE, FIN_1, A, FMP5_SLAP, 100 ],
					[ FMP5_SLAP_1_B_F6_SCORE, FIN_1, B, FMP5_SLAP, 100 ],
					[ FMP5_SLAP_1_C_F6_SCORE, FIN_1, C, FMP5_SLAP, 100 ],
					[ FMP5_SLAP_1_D_F6_SCORE, FIN_1, D, FMP5_SLAP, 100 ],
				]
			] ]
		]

	private final List F15A_CAND_INFO_LIST_BY_BOTH_AXIS_FALSE = 
		[ F15A_EXT_ID, PC2_SLAP_1_SCORE * pc2FW + FMP5_SLAP_1_C_F6_SCORE, true, 
			[ [ 341, 1, 0, PC2_SLAP_1_SCORE * pc2FW + FMP5_SLAP_1_C_F6_SCORE,
				[ 
					[ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, 200 ],
					[ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, 200 ],
					[ FMP5_ROLLED_1_A_F6_SCORE, FIN_1, A, FMP5_ROLLED, 100 ],
					[ FMP5_ROLLED_1_B_F6_SCORE, FIN_1, B, FMP5_ROLLED, 100 ],
					[ FMP5_ROLLED_1_C_F6_SCORE, FIN_1, C, FMP5_ROLLED, 100 ],
					[ FMP5_ROLLED_1_D_F6_SCORE, FIN_1, D, FMP5_ROLLED, 100 ],
					[ FMP5_SLAP_1_A_F6_SCORE, FIN_1, A, FMP5_SLAP, 100 ],
					[ FMP5_SLAP_1_B_F6_SCORE, FIN_1, B, FMP5_SLAP, 100 ],
					[ FMP5_SLAP_1_C_F6_SCORE, FIN_1, C, FMP5_SLAP, 100 ],
					[ FMP5_SLAP_1_D_F6_SCORE, FIN_1, D, FMP5_SLAP, 100 ],
				]
			] ]
		]

	private final List F_123_ABC_HIGH_CAND_INFO_LIST = 
		[ F_123_ABC_HIGH_EXT_ID, PC2_SLAP_1_SCORE * pc2FW + FMP5_SLAP_1_SCORE, true, 
			[ 
				[ 341, 1, 0, PC2_SLAP_1_SCORE * pc2FW + FMP5_SLAP_1_SCORE, F10A_CAND_INFO_LIST_BY_BOTH[3][0][4] ],
				[ 1341, 1, 0, PC2_SLAP_1_SCORE * pc2FW + FMP5_SLAP_1_SCORE, F10A_CAND_INFO_LIST_BY_BOTH[3][0][4] ] 
			]
		]
	private final List F_ABC_123_HIGH_CAND_INFO_LIST = 
		[ F_ABC_123_HIGH_EXT_ID, PC2_SLAP_1_SCORE * pc2FW + FMP5_SLAP_1_SCORE, true, 
			[ 
				[ 341, 1, 0, PC2_SLAP_1_SCORE * pc2FW + FMP5_SLAP_1_SCORE, F10A_CAND_INFO_LIST_BY_BOTH[3][0][4] ],
				[ 1341, 1, 0, PC2_SLAP_1_SCORE * pc2FW + FMP5_SLAP_1_SCORE, F10A_CAND_INFO_LIST_BY_BOTH[3][0][4] ] 
			]
		]
	private final List F_BBC_123_HIGH_CAND_INFO_LIST = 
		[ F_BBC_123_HIGH_EXT_ID, PC2_SLAP_1_SCORE * pc2FW + FMP5_SLAP_1_SCORE, true, 
			[ 
				[ 341, 1, 0, PC2_SLAP_1_SCORE * pc2FW + FMP5_SLAP_1_SCORE, F10A_CAND_INFO_LIST_BY_BOTH[3][0][4] ],
				[ 1341, 1, 0, PC2_SLAP_1_SCORE * pc2FW + FMP5_SLAP_1_SCORE, F10A_CAND_INFO_LIST_BY_BOTH[3][0][4] ] 
			]
		]
	private final List F_123_ABC_LOW_CAND_INFO_LIST = 
		[ F_123_ABC_LOW_EXT_ID, PC2_ROLLED_1_SCORE * pc2FW, true, 
			[ 
				[ 341, 1, 0, PC2_ROLLED_1_SCORE * pc2FW, F1A_CAND_INFO_LIST_BY_BOTH[3][0][4] ],
				[ 1341, 1, 0, PC2_ROLLED_1_SCORE * pc2FW, F1A_CAND_INFO_LIST_BY_BOTH[3][0][4] ] 
			]
		]
	private final List F_ABC_123_LOW_CAND_INFO_LIST = 
		[ F_ABC_123_LOW_EXT_ID, PC2_ROLLED_1_SCORE * pc2FW, true, 
			[ 
				[ 341, 1, 0, PC2_ROLLED_1_SCORE * pc2FW, F1A_CAND_INFO_LIST_BY_BOTH[3][0][4] ],
				[ 1341, 1, 0, PC2_ROLLED_1_SCORE * pc2FW, F1A_CAND_INFO_LIST_BY_BOTH[3][0][4] ],  
			]
		]
	private final List F_BBC_123_LOW_CAND_INFO_LIST = 
		[ F_BBC_123_LOW_EXT_ID, PC2_ROLLED_1_SCORE * pc2FW, true, 
			[ 
				[ 341, 1, 0, PC2_ROLLED_1_SCORE * pc2FW, F1A_CAND_INFO_LIST_BY_BOTH[3][0][4] ],
				[ 1341, 1, 0, PC2_ROLLED_1_SCORE * pc2FW, F1A_CAND_INFO_LIST_BY_BOTH[3][0][4] ] 
			]
		]

	LixConsolidationHelper(context){
		super(context)
	}

	public List getPc2CandList_ColdSearch(){
		return [ F1A_CAND_INFO_LIST_BY_PC2,
			 F2A_CAND_INFO_LIST_BY_PC2,
			 F5A_CAND_INFO_LIST_BY_PC2,
			 F7A_CAND_INFO_LIST_BY_PC2,
			 F8A_CAND_INFO_LIST_BY_PC2,
			 F9A_CAND_INFO_LIST_BY_PC2,
			 F10A_CAND_INFO_LIST_BY_PC2 ]
	}

	public List getFmp5CandList_ColdSearch(){
		return [ F3A_CAND_INFO_LIST_BY_FMP5,
			 F4A_CAND_INFO_LIST_BY_FMP5,
			 F6A_CAND_INFO_LIST_BY_FMP5,
			 F7A_CAND_INFO_LIST_BY_FMP5,
			 F8A_CAND_INFO_LIST_BY_FMP5,
			 F9A_CAND_INFO_LIST_BY_FMP5,
			 F10A_CAND_INFO_LIST_BY_FMP5 ]
	}

	public List getPc2Fmp5CandList_ColdSearch(){
		return [ F1A_CAND_INFO_LIST_BY_BOTH,
			 F2A_CAND_INFO_LIST_BY_BOTH,
			 F3A_CAND_INFO_LIST_BY_BOTH,
			 F4A_CAND_INFO_LIST_BY_BOTH,
			 F5A_CAND_INFO_LIST_BY_BOTH,
			 F6A_CAND_INFO_LIST_BY_BOTH,
			 F7A_CAND_INFO_LIST_BY_BOTH,
			 F8A_CAND_INFO_LIST_BY_BOTH,
			 F9A_CAND_INFO_LIST_BY_BOTH,
			 F10A_CAND_INFO_LIST_BY_BOTH ]
	}

	public List getPc2CandList_inquirySet(){
		return [ F10A_CAND_INFO_LIST_BY_PC2 ]
	}

	public List getFmp5CandList_inquirySet(){
		return [ F10A_CAND_INFO_LIST_BY_FMP5 ]
	}

	public List getFmp5RollCandList_inquirySet(){
		return [ F9A_CAND_INFO_LIST_BY_FMP5 ]
	}

	public List getPc2Fmp5RollCandList_inquirySet(){
		return [ F10A_CAND_INFO_LIST_BY_BOTH ]
	}

	public List getPc2CandList_fingerMerge(){
		return [ F11A_CAND_INFO_LIST_BY_PC2 ]
	}

	public List getFmp5CandList_fingerMerge(){
		return [ F11A_CAND_INFO_LIST_BY_FMP5 ]
	}

	public List getPc2Fmp5CandList_fingerMerge(){
		return [ F11A_CAND_INFO_LIST_BY_BOTH ]
	}

	public List getPc2Fmp5CandList_fingerMerge2Event(){
		return [ F11A_CAND_INFO_LIST_BY_BOTH_2EVENT ]
	}

	public List getPc2CandList_inquirySetMerge(){
		return [ F5A_CAND_INFO_LIST_BY_PC2 ]
	}

	public List getFmp5CandList_inquirySetMerge(){
		return [ F6A_CAND_INFO_LIST_BY_FMP5 ]
	}

	public List getPc2Fmp5CandList_inquirySetMerge(){
		return [ F9A_CAND_INFO_LIST_BY_BOTH ]
	}

	public List getFmp5CandList_multiAxisTrue_S4F3(){
		return [ F3A_CAND_INFO_LIST_BY_FMP5_AXIS_TRUE ]
	}

	public List getFmp5CandList_multiAxisTrue_S4F4(){
		return [ F4A_CAND_INFO_LIST_BY_FMP5_AXIS_TRUE ]
	}

	public List getFmp5CandList_multiAxisTrue_S5F6(){
		return [ F6A_CAND_INFO_LIST_BY_FMP5_AXIS_TRUE ]
	}

	public List getPc2Fmp5CandList_multiAxisTrue_S5F15(){
		return [ F15A_CAND_INFO_LIST_BY_BOTH_AXIS_TRUE ]
	}

	public List getFmp5CandList_multiAxisFalse_S4F3(){
		return [ F3A_CAND_INFO_LIST_BY_FMP5_AXIS_FALSE ]
	}

	public List getFmp5CandList_multiAxisFalse_S4F4(){
		return [ F4A_CAND_INFO_LIST_BY_FMP5_AXIS_FALSE ]
	}

	public List getFmp5CandList_multiAxisFalse_S5F6(){
		return [ F6A_CAND_INFO_LIST_BY_FMP5_AXIS_FALSE ]
	}

	public List getPc2Fmp5CandList_multiAxisFalse_S5F15(){
		return [ F15A_CAND_INFO_LIST_BY_BOTH_AXIS_FALSE ]
	}

	public List getPc2CandList_eventMerge(){
		return [ F12A_CAND_INFO_LIST_BY_PC2 ]
	}

	public List getFmp5CandList_eventMerge(){
		return [ F12A_CAND_INFO_LIST_BY_FMP5 ]
	}

	public List getPc2Fmp5CandList_eventMerge(){
		return [ F12A_CAND_INFO_LIST_BY_BOTH ]
	}

	public List getPc2CandList_scopeMerge(){
		return [ F13A_CAND_INFO_LIST_BY_PC2 ]
	}

	public List getFmp5CandList_scopeMerge(){
		return [ F13A_CAND_INFO_LIST_BY_FMP5 ]
	}

	public List getPc2Fmp5CandList_scopeMerge(){
		return [ F13A_CAND_INFO_LIST_BY_BOTH ]
	}

	public List getPc2Fmp5CandList_scopeEventMerge(){
		return [ F14A_CAND_INFO_LIST_BY_BOTH ]
	}

	public List getPc2Fmp5CandList_candSort(){
		return [ F_123_ABC_HIGH_CAND_INFO_LIST,
				F_ABC_123_HIGH_CAND_INFO_LIST,
				F_BBC_123_HIGH_CAND_INFO_LIST,
				F_123_ABC_LOW_CAND_INFO_LIST,
				F_ABC_123_LOW_CAND_INFO_LIST,
				F_BBC_123_LOW_CAND_INFO_LIST ]
	}

	public List getPc2Fmp5CandList_fusionWeight(Integer pc2rFW, Integer pc2sFW, Integer fmp5rFW, Integer fmp5sFW){
		int fScore = calcFusionScore(pc2rFW, pc2sFW, fmp5rFW, fmp5sFW, PC2_SLAP_1_SCORE, FMP5_SLAP_1_SCORE)
		int cScore = fScore
		List candInfo = [ 
			[ F10A_EXT_ID, fScore, true, 
				[ [ 341, 1, 0, cScore,
					[ 
						[ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, pc2rFW ], 
						[ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, pc2sFW ], 
						[ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, fmp5rFW ], 
						[ FMP5_SLAP_1_SCORE, FIN_1, A, FMP5_SLAP, fmp5sFW ] ] ] ] ]
		]
		return candInfo
	}

	public List getPc2Fmp5CandList_fusionWeight_multi(Integer pc2rFW, Integer pc2sFW, Integer fmp5rFW, Integer fmp5sFW){
		int pc2Rolled1Score = multiplyFw(PC2_ROLLED_1_SCORE, pc2rFW)
		int pc2Slap1Score = multiplyFw(PC2_SLAP_1_SCORE, pc2sFW)
		int fmp5RolledScore = multiplyFw(FMP5_ROLLED_1_SCORE, fmp5rFW)
		int fmp5SlapScore = multiplyFw(FMP5_SLAP_1_SCORE, fmp5sFW)
		int fScorePc2SFmp5S = pc2Slap1Score + fmp5SlapScore
		int fScorePc2SFmp5R = pc2Slap1Score + fmp5RolledScore
		int fScorePc2RFmp5R = pc2Rolled1Score + fmp5RolledScore
		int fScoreFmp5R = fmp5RolledScore
		int fScoreFmp5S = fmp5SlapScore
		int fScorePc2R = pc2Rolled1Score
		int fScorePc2S = pc2Slap1Score
		List candInfo = [ 
			[ F10A_EXT_ID, fScorePc2SFmp5S, true, 
				[ [ 341, 1, 0, fScorePc2SFmp5S,
					[ 
						[ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, pc2rFW ], 
						[ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, pc2sFW ], 
						[ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, fmp5rFW ], 
						[ FMP5_SLAP_1_SCORE, FIN_1, A, FMP5_SLAP, fmp5sFW ] ] ] ] ],
			[ F8A_EXT_ID, fScorePc2SFmp5S, true, 
				[ [ 341, 1, 0, fScorePc2SFmp5S,
					[ 
						[ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, pc2sFW ], 
						[ FMP5_SLAP_1_SCORE, FIN_1, A, FMP5_SLAP, fmp5sFW ] ] ] ] ],
			[ F9A_EXT_ID, fScorePc2SFmp5R, true, 
				[ [ 341, 1, 0, fScorePc2SFmp5R,
					[ 
						[ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, pc2sFW ], 
						[ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, fmp5rFW ] ] ] ] ],
			[ F4A_EXT_ID, fScoreFmp5S, true, 
				[ [ 341, 1, 0, fScoreFmp5S,
					[ 
						[ FMP5_SLAP_1_SCORE, FIN_1, A, FMP5_SLAP, fmp5sFW ] ] ] ] ],
			[ F6A_EXT_ID, fScoreFmp5S, true, 
				[ [ 341, 1, 0, fScoreFmp5S,
					[ 
						[ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, fmp5rFW ], 
						[ FMP5_SLAP_1_SCORE, FIN_1, A, FMP5_SLAP, fmp5sFW ] ] ] ] ],
			[ F2A_EXT_ID, fScorePc2S, true, 
				[ [ 341, 1, 0, fScorePc2S,
					[ 
						[ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, pc2sFW ] ] ] ] ],
			[ F5A_EXT_ID, fScorePc2S, true, 
				[ [ 341, 1, 0, fScorePc2S,
					[ 
						[ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, pc2rFW ], 
						[ PC2_SLAP_1_SCORE, FIN_1, A, PC2_SLAP, pc2sFW ] ] ] ] ],
			[ F7A_EXT_ID, fScorePc2RFmp5R, true, 
				[ [ 341, 1, 0, fScorePc2RFmp5R,
					[ 
						[ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, pc2rFW ], 
						[ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, fmp5rFW ] ] ] ] ],
			[ F3A_EXT_ID, fScoreFmp5R, true, 
				[ [ 341, 1, 0, fScoreFmp5R,
					[ 
						[ FMP5_ROLLED_1_SCORE, FIN_1, A, FMP5_ROLLED, fmp5rFW ] ] ] ] ],
			[ F1A_EXT_ID, fScorePc2R, true, 
				[ [ 341, 1, 0, fScorePc2R,
					[ 
						[ PC2_ROLLED_1_SCORE, FIN_1, A, PC2_ROLLED, pc2rFW ] ] ] ] ],
		]
		return candInfo
	}

}

