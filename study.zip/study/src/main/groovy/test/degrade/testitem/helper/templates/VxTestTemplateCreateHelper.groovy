package test.degrade.testitem.helper.templates

import test.degrade.testitem.helper.*
import static test.common.constants.data.ImageDataList.*
import static test.common.constants.aim.AIMImgType.*
import static test.common.constants.aim.AIMBioPosition.*

class VxTestTemplateCreateHelper extends TestTemplateCreateHelper{

	def posImgPathMap


    VxTestTemplateCreateHelper(context){
		super(context)
		initPosImgPathMap()
    }

	public String getDefaultFileImage(){
		return getRolledTenprintImg() + getSlapTenprintImg()
	}

	public String getDefaultSearchImage(){
		return getRolledTenprintImg() + getSlapTenprintImg()
	}

	public String getThumbImage(){
		return getRolledThumbImg() + getSlapThumbImg()
	}

	public String getRightThumbImage(){
		return getRolledRightThumbImg() + getSlapRightThumbImg()
	}

	public String getLeftThumbImage(){
		return getRolledLeftThumbImg() + getSlapLeftThumbImg()
	}

	public String getIndexImage(){
		return getRolledIndexImg() + getSlapIndexImg()
	}

	public String tmpMethods(){
		List posList = [ ROLLED_RIGHT_THUMB, ROLLED_RIGHT_INDEX, ROLLED_RIGHT_MIDDLE, ROLLED_RIGHT_RING, ROLLED_RIGHT_LITTLE, 
						 ROLLED_LEFT_THUMB, ROLLED_LEFT_INDEX, ROLLED_LEFT_MIDDLE, ROLLED_LEFT_RING, ROLLED_LEFT_LITTLE,
						 SLAP_RIGHT_THUMB, SLAP_RIGHT_INDEX, SLAP_RIGHT_MIDDLE, SLAP_RIGHT_RING, SLAP_RIGHT_LITTLE, 
						 SLAP_LEFT_THUMB, SLAP_LEFT_INDEX, SLAP_LEFT_MIDDLE, SLAP_LEFT_RING, SLAP_LEFT_LITTLE ]
		return createTenprintImg(posList)
	}

	public String get_11_41_12_45_Image(){
		List posList = [ SLAP_RIGHT_THUMB, SLAP_RIGHT_MIDDLE, SLAP_LEFT_THUMB,  SLAP_LEFT_MIDDLE ]
		return createTenprintImg(posList)
	}

	public String get_41_42_46_47_Image(){
		List posList = [ SLAP_RIGHT_MIDDLE, SLAP_RIGHT_RING, SLAP_LEFT_RING, SLAP_LEFT_LITTLE ]
		return createTenprintImg(posList)
	}

	public String get_2_4_6_8_Image(){
		List posList = [ ROLLED_RIGHT_INDEX, ROLLED_RIGHT_RING, ROLLED_LEFT_THUMB,  ROLLED_LEFT_MIDDLE ] 
		return createTenprintImg(posList)
	}

	public String get_1_2_6_7_Image(){
		List posList = [ ROLLED_RIGHT_THUMB, ROLLED_RIGHT_INDEX, ROLLED_LEFT_THUMB, ROLLED_LEFT_INDEX ]
		return createTenprintImg(posList)
	}

	public String get_40_42_12_46_Image(){
		List posList = [ SLAP_RIGHT_INDEX, SLAP_RIGHT_RING, SLAP_LEFT_THUMB, SLAP_LEFT_RING]
		return createTenprintImg(posList)
	}

	public String get_11_40_12_44_Image(){
		List posList = [ SLAP_RIGHT_THUMB, SLAP_RIGHT_INDEX, SLAP_LEFT_THUMB, SLAP_LEFT_INDEX]
		return createTenprintImg(posList)
	}

	public String get_3_4_8_9_Image(){
		List posList = [ ROLLED_RIGHT_MIDDLE, ROLLED_RIGHT_RING, ROLLED_LEFT_MIDDLE, ROLLED_LEFT_RING ]
		return createTenprintImg(posList)
	}

	public String get_11_41_12_46_Image(){
		List posList = [ SLAP_RIGHT_THUMB, SLAP_RIGHT_MIDDLE, SLAP_LEFT_THUMB,  SLAP_LEFT_RING ]
		return createTenprintImg(posList)
	}

	public String get_1_6_Image(){
		StringBuilder sb = new StringBuilder()
		sb.append(imgXmlMaker.getAimSimpleImgXml(TF_053_WSQ, ROLLED_RIGHT_THUMB, TYPE_WSQ))
		sb.append(imgXmlMaker.getAimSimpleImgXml(TF_058_WSQ, ROLLED_LEFT_THUMB, TYPE_WSQ))
		return sb.toString()
	}

	def getRolledTenprintImg(){
		List posList = [ ROLLED_RIGHT_THUMB, ROLLED_RIGHT_INDEX, ROLLED_RIGHT_MIDDLE, ROLLED_RIGHT_RING, ROLLED_RIGHT_LITTLE, 
						 ROLLED_LEFT_THUMB, ROLLED_LEFT_INDEX, ROLLED_LEFT_MIDDLE, ROLLED_LEFT_RING, ROLLED_LEFT_LITTLE ]
		return createTenprintImg(posList)
	}

	def getSlapTenprintImg(){
		List posList = [ SLAP_RIGHT_THUMB, SLAP_RIGHT_INDEX, SLAP_RIGHT_MIDDLE, SLAP_RIGHT_RING, SLAP_RIGHT_LITTLE, 
						 SLAP_LEFT_THUMB, SLAP_LEFT_INDEX, SLAP_LEFT_MIDDLE, SLAP_LEFT_RING, SLAP_LEFT_LITTLE ]
		return createTenprintImg(posList)
	}


	def getRolledThumbImg(){
		List posList = [ ROLLED_RIGHT_THUMB,  ROLLED_LEFT_THUMB ]
		return createTenprintImg(posList)
	}

	def getSlapThumbImg(){
		List posList = [ SLAP_RIGHT_THUMB,  SLAP_LEFT_THUMB ]
		return createTenprintImg(posList)
	}

	def getRolledRightThumbImg(){
		List posList = [ ROLLED_RIGHT_THUMB ]
		return createTenprintImg(posList)
	}

	def getSlapRightThumbImg(){
		List posList = [ SLAP_RIGHT_THUMB ]
		return createTenprintImg(posList)
	}

	def getRolledLeftThumbImg(){
		List posList = [ ROLLED_LEFT_THUMB ]
		return createTenprintImg(posList)
	}

	def getSlapLeftThumbImg(){
		List posList = [ SLAP_LEFT_THUMB ]
		return createTenprintImg(posList)
	}

	def getRolledIndexImg(){
		List posList = [ ROLLED_RIGHT_INDEX,  ROLLED_LEFT_INDEX ]
		return createTenprintImg(posList)
	}

	def getSlapIndexImg(){
		List posList = [ SLAP_RIGHT_INDEX,  SLAP_LEFT_INDEX ]
		return createTenprintImg(posList)
	}

	def createTenprintImg(List posList){
		StringBuilder sb = new StringBuilder()
		for(pos in posList){
			sb.append(imgXmlMaker.getAimSimpleImgXml(posImgPathMap.get(pos), pos, TYPE_WSQ))
		}
		return sb.toString()
	}

	def initPosImgPathMap() {
        this.posImgPathMap = new HashMap()
        posImgPathMap.put(ROLLED_RIGHT_THUMB, TF_043_WSQ)
        posImgPathMap.put(ROLLED_RIGHT_INDEX, TF_044_WSQ)
        posImgPathMap.put(ROLLED_RIGHT_MIDDLE, TF_045_WSQ)
        posImgPathMap.put(ROLLED_RIGHT_RING, TF_046_WSQ)
        posImgPathMap.put(ROLLED_RIGHT_LITTLE, TF_047_WSQ)
        posImgPathMap.put(ROLLED_LEFT_THUMB, TF_048_WSQ)
        posImgPathMap.put(ROLLED_LEFT_INDEX, TF_049_WSQ)
        posImgPathMap.put(ROLLED_LEFT_MIDDLE, TF_050_WSQ)
        posImgPathMap.put(ROLLED_LEFT_RING, TF_051_WSQ)
        posImgPathMap.put(ROLLED_LEFT_LITTLE, TF_052_WSQ)
        posImgPathMap.put(SLAP_RIGHT_THUMB, TF_043_WSQ)
        posImgPathMap.put(SLAP_RIGHT_INDEX, TF_044_WSQ)
        posImgPathMap.put(SLAP_RIGHT_MIDDLE, TF_045_WSQ)
        posImgPathMap.put(SLAP_RIGHT_RING, TF_046_WSQ)
        posImgPathMap.put(SLAP_RIGHT_LITTLE, TF_047_WSQ)
        posImgPathMap.put(SLAP_LEFT_THUMB, TF_048_WSQ)
        posImgPathMap.put(SLAP_LEFT_INDEX, TF_049_WSQ)
        posImgPathMap.put(SLAP_LEFT_MIDDLE, TF_050_WSQ)
        posImgPathMap.put(SLAP_LEFT_RING, TF_051_WSQ)
        posImgPathMap.put(SLAP_LEFT_LITTLE, TF_052_WSQ)
    }

}
