package test.degrade.testitem.helper

import test.common.constants.aim.*
import static test.common.constants.aim.AIMXmlAttribute.*

abstract class PayloadHelper extends ConsolidationHelper {
	
    protected static PayloadMapIF payloadMap
    protected static Map commonOptMap
	
	PayloadHelper(context){
		super(context)
        if(commonOptMap == null) {
            commonOptMap = new CommonOptMapNoCallbackUrl().getDefaultParamMap()
        }
        if(payloadMap == null) {
            initPayloadMap()
        }
	}

    abstract public String makePayload() 
    abstract protected void initPayloadMap()

    public void resetSearchParam() {
        initPayloadMap()
    }

    public boolean isSearchOptKey(String key) {
        for(map in payloadMap.getAllMaps()) {
            if(map.containsKey(key)) {
                return true
            }
        }
        return false
    }

	public void updatePayloadVal(def dataSrcTestStep){
		for(name in dataSrcTestStep.getPropertyNames()) {
			if(isSearchOptKey(name)) {
				String val = dataSrcTestStep.getPropertyValue(name)
				if(val != null && !val.isEmpty() && val[0] == "\$"){
					val = soapuiObj.getContext().expand(val)
				}
				updatePayloadVal(name, val)
			}
		}
	}

    public void updatePayloadVal(String newKey, String newVal) {
        for(map in payloadMap.getAllMaps()) {
            for(key in map.keySet()) {
                if(key == newKey) {
                    map[key] = newVal
                    return
                }
            }
        }
        assert false, "Unkown search payload option '${newKey}'."
    }

    protected String makeMetaCommonXml() {
        return makePayloadXml("meta-common", payloadMap.getMetaCommonMap())
    }

    protected String makeMetaTenprintXml() {
        return makePayloadXml("meta-tenprint", payloadMap.getMetaTenprintMap())
    }

    protected String makeMetaLatentXml() {
        return makePayloadXml("meta-latent", payloadMap.getMetaLatentMap())
    }

    protected String makePalmOptionsXml() {
        return makePayloadXml("palm-options", payloadMap.getPalmOptMap())
    }

    protected String makeIrisOptionsXml() {
        return makePayloadXml("iris-options", payloadMap.getIrisOptMap())
    }

    protected String makeCmlOptionsXml() {
        return makePayloadXml("cml-options", payloadMap.getCmlOptMap())
    }

    protected String makeCmlafOptionsXml() {
        StringBuilder sb = new StringBuilder()
        sb.append(makePayloadXml("cmlaf-ti-options", payloadMap.getCmlafOptMap(), true))
        sb.append(makePayloadXml("matchable-fingers-thresholds", payloadMap.getMatchableFinThOptMap(), true))
		sb.append(makeFingerThresholdsOptXml(payloadMap.getFingerThresholdsOptMap()))
        sb.append("</matchable-fingers-thresholds>\n")
        sb.append("</cmlaf-ti-options>\n")
        return sb.toString()
    }

	protected String makeFingerThresholdsOptXml(Map<String, String> paramMap){
        StringBuilder sb = new StringBuilder()
		List finThParams = [ "fingerNumber",
							 "patternThreshold",
							 "cardScoreThreshold",
							 "mateProbabilityThreshold",
							 "finalScoreThreshold",
							 "speedLevel"
							]		

        for(key in paramMap.keySet()) {
            String[] val = paramMap[key].split(",")
			print(val)

			if(val[0] == ""){
				continue
			}

        	sb.append("<fingers-thresholds ")
			for(int i = 0; i < finThParams.size(); i++){
				String paramName = finThParams[i]
				String paramVal = null

				try{
					paramVal = val[i]
				}catch(ArrayIndexOutOfBoundsException e){
					//if last index value splited ',' is empty , keep null to avoid making xml attribute. 
				}

            	if(paramVal == null || paramVal == "") {
            	    continue
            	}
            	sb.append("${paramName}='${paramVal}' ")
			}
            sb.append("/>\n")
        }
        return sb.toString()
	}

    protected String makePrefilterOptXml() {
        StringBuilder sb = new StringBuilder()
        sb.append(makePayloadXml("prefilter-options", payloadMap.getPrefilterOptMap(), true))
        sb.append(makeUsePrefilterInfoXml())
        sb.append("</prefilter-options>\n")
        return sb.toString()
    }

    protected String makeUsePrefilterInfoXml() {
        return makePayloadXml("use-prefilter-info", payloadMap.getUsePrefilterInfoMap())
    }

    protected String makePayloadXml(String elementName, Map<String, String> paramMap) {
        makePayloadXml(elementName, paramMap, false)
    }

    protected String makePayloadXml(String elementName, Map<String, String> paramMap, boolean hasChild) {
        StringBuilder sb = new StringBuilder()
        sb.append("<${elementName} ")
        for(key in paramMap.keySet()) {
            String val = paramMap[key]
            if(val == null || val.isEmpty()) {
                continue
            }
            sb.append("${key}='${val}' ")
        }
        if(hasChild) {
            sb.append(">\n")
        } else {
            sb.append("/>\n")
        }
        return sb.toString()
    }

    private String makeSimpleXml(String name, String value) {
        if(value == null || value.isEmpty()) {
            return ""
        }else{
            return "<${name}>${value}</${name}>"
        }
    }

    public String makeCommonOptXml() {
        StringBuilder sb = new StringBuilder()
        for(key in commonOptMap.keySet()) {
            sb.append(makeSimpleXml(key, commonOptMap.get(key)))
            sb.append("\n")
        }
        return sb.toString()
    }

    public boolean isCommonOptKey(String key) {
        if(commonOptMap.containsKey(key)) {
            return true
        }
        return false
    }

    public String updateCommonOptVal(String newKey, String newVal) {
        for(key in commonOptMap.keySet()) {
            if(key == newKey) {
                commonOptMap[key] = newVal
                return
            }
        }
        assert false, "Unkown search payload option '${newKey}'."
    }

}
