package test.degrade.testitem.helper.option

import test.degrade.util.SoapuiObject

class FaceOptionCreateHelper extends TestOptionsCreateHelper{
	
	private static final String DATA_SRC_NAME = "DetectResult"
	SoapuiObject soapuiObj

	static final String FACE_INPUT_HEAD = "<face-input "
	static final String FACE_DETECTION_HEAD = "<detection "
	static final String FACE_DETECT_PARAMS_HEAD = "<params "
	static final String FACE_POINT_HEAD="<points "
	static final String FACE_POINT_END = "</points> \n"
	static final String FACE_NEGATIVE_DETECTION_PARAMS = "<negative-detection-params "

	static final String PROCESS_MODE = "processMode"
	static final String FACE_MAX_NUM = "faceMaxNum"
	static final String FACE_MODE = "mode"
	static final String FACE_SORTING_ORDER = "sortingOrder"
	static final String IMAGE_ANALYSIS = "imageAnalysis"
	static final String PARAMS_NUM = "num"
	static final String FACE_ALGORITHM = "algorithm"
	static final String RELIABILITY = "reliability"
	static final String EYE_MIN="eyeMin"
	static final String EYE_MAX="eyeMax"
	static final String EYE_ROTATION="eyeRotation"
	static final String SHRINK_FACTOR="shrinkFactor"
	static final String FACE_ROTATION="faceRotation"
	static final String MATCHING_SCORE_THRESHOLD="matchingScoreThreshold"
	static final String QUALITY_THRESHOLD="qualityThreshold"

	static final String RIGHT_EYE_CENTER ="<right-eye-center  "
	static final String LEFT_EYE_CENTER="<left-eye-center  "
	static final String RIGHT_EYE_INNER_CORNER="<right-eye-inner-corner  "
	static final String LEFT_EYE_INNER_CORNER="<left-eye-inner-corner  "
	static final String RIGHT_EYE_OUTER_CORNER="<right-eye-outer-corner  "
	static final String LEFT_EYE_OUTER_CORNER="<left-eye-outer-corner  "
	static final String CENTER_BELOW_NOSE="<center-below-nose  "
	static final String RIGHT_SIDE_NOSE="<right-side-nose  "
	static final String LEFT_SIDE_NOSE="<left-side-nose  "
	static final String RIGHT_CORNER_MOUTH="<right-corner-mouth  "
	static final String LEFT_CORNER_MOUTH="<left-corner-mouth  "
	static final String TOP_CENTER_UPPER_LIP="<top-center-upper-lip  "
	static final String BOTTOM_CENTER_UPPER_LIP="<bottom-center-upper-lip  "

	static final String X="x" 
	static final String Y="y" 

	FaceOptionCreateHelper(){}

	FaceOptionCreateHelper(context){
		this.soapuiObj = new SoapuiObject(context)
	}

	def cretateFaceInput(def processMode){
		return FACE_INPUT_HEAD + makeAttribute(PROCESS_MODE, processMode) + END_1
	}

	def createFaceDetection(def faceMaxNum, def mode, def sortingOrder){
		return FACE_DETECTION_HEAD + 
				makeAttribute(FACE_MAX_NUM, faceMaxNum) +
				makeAttribute(FACE_MODE, mode) +
				makeAttribute(FACE_SORTING_ORDER, sortingOrder) +
				END_1
	}

	def createFaceDetection(def faceMaxNum, def mode, def sortingOrder, def imageAnalysis){
		return FACE_DETECTION_HEAD + 
				makeAttribute(FACE_MAX_NUM, faceMaxNum) +
				makeAttribute(FACE_MODE, mode) +
				makeAttribute(FACE_SORTING_ORDER, sortingOrder) +
				makeAttribute(IMAGE_ANALYSIS, imageAnalysis) +
				END_1
	}

	def createFaceDetectParams(def num, def algorithm, def reliability, def eyeMin, 
							   def eyeMax, def eyeRotation, def shrinkFactor, def faceRotation){
		return FACE_DETECT_PARAMS_HEAD +
				makeAttribute(PARAMS_NUM, num) +
				makeAttribute(FACE_ALGORITHM, algorithm) +
				makeAttribute(RELIABILITY, reliability) +
				makeAttribute(EYE_MIN, eyeMin) +
				makeAttribute(EYE_MAX, eyeMax) +
				makeAttribute(EYE_ROTATION, eyeRotation) +
				makeAttribute(SHRINK_FACTOR, shrinkFactor) +
				makeAttribute(FACE_ROTATION, faceRotation) + 
				END_2
	}

	def cretateFacePoints(def num){
		return FACE_POINT_HEAD + 
				makeAttribute(PARAMS_NUM, num) +
				END_1
	}

	def createNegativeDetectionParams(def matchingScoreThreshold, def qualityThreshold){
		if(matchingScoreThreshold == "" || qualityThreshold == "") return ""
		return FACE_NEGATIVE_DETECTION_PARAMS +
				makeAttribute(MATCHING_SCORE_THRESHOLD, matchingScoreThreshold) +
				makeAttribute(QUALITY_THRESHOLD, qualityThreshold) +
				END_2
	}	

	def createFaceDetectPoint() {
		List<List> dataSrcValList = soapuiObj.createListFromDataSource(DATA_SRC_NAME)
		String points = ""
		for(dataSrcVal in dataSrcValList) {
			points += FACE_POINT_HEAD + makeAttribute(PARAMS_NUM, dataSrcVal[0]) + END_1 + 
							RIGHT_EYE_CENTER + makeAttribute(X, dataSrcVal[4]) + makeAttribute(Y, dataSrcVal[5]) + END_2 +
							LEFT_EYE_CENTER + makeAttribute(X, dataSrcVal[9]) + makeAttribute(Y, dataSrcVal[10]) + END_2 +
							RIGHT_EYE_INNER_CORNER + makeAttribute(X, dataSrcVal[5]) + makeAttribute(Y, dataSrcVal[6]) + END_2 +
							LEFT_EYE_INNER_CORNER + makeAttribute(X, dataSrcVal[11]) + makeAttribute(Y, dataSrcVal[12]) + END_2 +
							RIGHT_EYE_OUTER_CORNER + makeAttribute(X, dataSrcVal[7]) + makeAttribute(Y, dataSrcVal[8]) + END_2 +
							LEFT_EYE_OUTER_CORNER + makeAttribute(X, dataSrcVal[13]) + makeAttribute(Y, dataSrcVal[14]) + END_2 +
							CENTER_BELOW_NOSE + makeAttribute(X, dataSrcVal[15]) + makeAttribute(Y, dataSrcVal[16]) + END_2 +
							RIGHT_SIDE_NOSE + makeAttribute(X, dataSrcVal[17]) + makeAttribute(Y, dataSrcVal[18]) + END_2 +
							LEFT_SIDE_NOSE + makeAttribute(X, dataSrcVal[19]) + makeAttribute(Y, dataSrcVal[20]) + END_2 +
							RIGHT_CORNER_MOUTH + makeAttribute(X, dataSrcVal[21]) + makeAttribute(Y, dataSrcVal[22]) + END_2 +
							LEFT_CORNER_MOUTH + makeAttribute(X, dataSrcVal[23]) + makeAttribute(Y, dataSrcVal[24]) + END_2 +
							TOP_CENTER_UPPER_LIP + makeAttribute(X, dataSrcVal[25]) + makeAttribute(Y, dataSrcVal[26]) + END_2 +
							BOTTOM_CENTER_UPPER_LIP + makeAttribute(X, dataSrcVal[27]) + makeAttribute(Y, dataSrcVal[28]) + END_2 +
					FACE_POINT_END
		}
		return points
	}
}


