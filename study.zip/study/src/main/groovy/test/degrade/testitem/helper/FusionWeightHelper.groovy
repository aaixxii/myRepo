package test.degrade.testitem.helper

import common.sql.SqlExecutor
import test.common.util.db.SqlExecutorFactory
import test.degrade.util.SoapuiObject;
import test.degrade.properties.GlobalProperties

class FusionWeightHelper{

	static final String CREATE_AFIS_SCRIPT_SQL = "create_afis_scripts.sql"
	SoapuiObject soapuiObj
	GlobalProperties gProp
	
	FusionWeightHelper(context){
		this.soapuiObj = new SoapuiObject(context)
		this.gProp = new GlobalProperties(context)
	}
	
	public void updateDefaultAfisScript(){
		updateAfisScripts(CREATE_AFIS_SCRIPT_SQL)
	}

	public void updateAfisScripts(String scriptName) {
		def sqlExecuter = new SqlExecutorFactory(soapuiObj.getContext()).create()
		def sb = new StringBuilder()
		def dataFilePath = gProp.getDataFilePath()
		def verNum = gProp.getVerNum()
		def script = new File("${dataFilePath}/degradeTest/fusionWeight/aim_${verNum}/${scriptName}")
		script.eachLine{
			if(it.indexOf("prompt") == -1){
				if(it =~ /.+/){
					if(it.indexOf(";") != -1){
						sb = sb.append(it.replaceAll(/;/, "") + "\n")
						sqlExecuter.sqlExecute(sb.toString())
						sb = new StringBuilder("")
					}else{
						sb.append(it + "\n")
					}
				}
			}
		}
	}
}

