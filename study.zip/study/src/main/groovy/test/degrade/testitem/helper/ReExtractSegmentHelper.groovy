package test.degrade.testitem.helper

import common.os.linux.LinuxCommander
import common.util.Encoder;
import test.common.util.tool.ToolExecutor;
import test.degrade.evidence.EvidenceFileOutputor
import test.degrade.properties.GlobalProperties
import test.degrade.util.SoapuiObject
import test.duration.queue.ExtractJobInfoQueue;

class ReExtractSegmentHelper extends ExtractManualCropHelper {
	
	private static String TMP_DIR = "/tmp/edamame"
	private static Map<String, Integer> scoreMap
	private int totalScore
	private static ReExtractSegmentHelper instance
	
	public ReExtractSegmentHelper(def context){
		super(context)
		if(this.scoreMap == null){
			this.scoreMap = new HashMap<String, Integer>()
		}
	}

	public String getEdamamePc2B64(String fileName, int pos, int fusionNum){
		File pc2File = new File("${TMP_DIR}/${fileName}_finger0${pos-1}_fusion${fusionNum-1}.pc2")
		return Encoder.binaryToB64(pc2File)
	}
	
	public void doEdamame(String cmlafTemplatePath, String outputDirPath){
		ToolExecutor tool = new ToolExecutor(soapuiObj.getContext())
		tool.doEdamame(cmlafTemplatePath, outputDirPath)
	}
	
	private extractPc2FromCmlafTemplate(String fileName) {
		EvidenceFileOutputor outputer = new EvidenceFileOutputor(soapuiObj.getContext())
		String resultDataDirPath = outputer.getResultDataDirPath()
		String testCaseName = soapuiObj.getTestCaseName()
		String templatePath = "${resultDataDirPath}/${fileName}"
		new File(TMP_DIR).mkdir()
		doEdamame(templatePath, TMP_DIR)
	}
	
	public void saveScore(String key, String callbackXml){
		Node searchJobResult = new XmlParser().parseText(callbackXml)
		for(Node candidate in searchJobResult."candidate"){
			String externalId = candidate.externalId[0].text()
			for(Node indScore in candidate."candidate-template"[0]."individual-score"){
				totalScore += indScore.attribute("value") as int
			}
			scoreMap.put("${key}-${externalId}", totalScore)
		}
	}
	
	public List getScoreList(String searchKey){
		List scoreList = new ArrayList()
		for(def key : scoreMap.keySet()){
			if(key.indexOf(searchKey) == 0){
				scoreList << scoreMap.get(key)
			}
		}
		return scoreList
	}
	
	public void removeScore(String searchKey){
		Iterator iterator = scoreMap.keySet().iterator()
		while(iterator.hasNext()){
			String key = iterator.next()
			if(key.indexOf(searchKey) == 0){
				iterator.remove()
			}
		}
	}
	
	public void showScoreList(){
		for(def key : scoreMap.keySet()){
			println "$key : ${scoreMap.get(key)}"
		}
	}
}

