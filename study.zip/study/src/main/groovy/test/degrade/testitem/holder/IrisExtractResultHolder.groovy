package test.degrade.testitem.holder

import static test.common.constants.aim.AIMWord.*
import test.degrade.properties.GlobalProperties
import test.degrade.management.AbendProcessor

class IrisExtractResultHolder {
	
	private AbendProcessor abendProcessor
	private int expQuality_imgEnh_R_IDB
	private int expQuality_imgEnh_L_IDB
	private int expQuality_imgEnh_R_II
	private int expQuality_imgEnh_L_II
	private int expQuality_imgNoEnh_R_IDB
	private int expQuality_imgNoEnh_L_IDB
	private int expQuality_imgNoEnh_R_II
	private int expQuality_imgNoEnh_L_II
	private int expQuality_flexibleModel_R
	private int expQuality_flexibleModel_L
	private List expPupilPointList_imgEnh_R_IDB
	private List expPupilPointList_imgEnh_L_IDB
	private List expPupilPointList_imgEnh_R_II
	private List expPupilPointList_imgEnh_L_II
	private List expPupilPointList_imgNoEnh_R_IDB
	private List expPupilPointList_imgNoEnh_L_IDB
	private List expPupilPointList_imgNoEnh_R_II
	private List expPupilPointList_imgNoEnh_L_II
	private List expPupilPointList_flxBModel_false_R
	private List expPupilPointList_flxBModel_false_L
	private List expIrisPointList_imgEnh_R_IDB
	private List expIrisPointList_imgEnh_L_IDB
	private List expIrisPointList_imgEnh_R_II
	private List expIrisPointList_imgEnh_L_II
	private List expIrisPointList_imgNoEnh_R_IDB
	private List expIrisPointList_imgNoEnh_L_IDB
	private List expIrisPointList_imgNoEnh_R_II
	private List expIrisPointList_imgNoEnh_L_II
	private List expIrisPointList_flxBModel_false_R
	private List expIrisPointList_flxBModel_false_L
	private String engine
	
	public IrisExtractResultHolder() {}

	public IrisExtractResultHolder(def context) {
        this.engine = new GlobalProperties(context).getIrisEngine().toUpperCase()
		this.abendProcessor = new AbendProcessor(context)
		initAssertionQuality()
		initAssertionPupilPoints()
		initAssertionIrisPoints()
	}
	
	private initAssertionQuality() {
		if(engine == NIRIS){
			expQuality_imgEnh_R_IDB = 70
			expQuality_imgEnh_L_IDB = 65
			expQuality_imgEnh_R_II = 68
			expQuality_imgEnh_L_II = 66
			expQuality_imgNoEnh_R_IDB = expQuality_imgEnh_R_IDB
			expQuality_imgNoEnh_L_IDB = expQuality_imgEnh_L_IDB
			expQuality_imgNoEnh_R_II = expQuality_imgEnh_R_II
			expQuality_imgNoEnh_L_II = expQuality_imgEnh_L_II
			expQuality_flexibleModel_R = 68
			expQuality_flexibleModel_L = 66
		}else if(engine == VERIEYE){
			expQuality_imgEnh_R_IDB = 73
			expQuality_imgEnh_L_IDB = 72
			expQuality_imgEnh_R_II = 70
			expQuality_imgEnh_L_II = 67
			expQuality_imgNoEnh_R_IDB = expQuality_imgEnh_R_IDB
			expQuality_imgNoEnh_L_IDB = expQuality_imgEnh_L_IDB
			expQuality_imgNoEnh_R_II = expQuality_imgEnh_R_II
			expQuality_imgNoEnh_L_II = expQuality_imgEnh_L_II
			expQuality_flexibleModel_R = 70
			expQuality_flexibleModel_L = 67
		}else{
            abendTest("Engine '${engine}' is unexpected value!!")
		}
	}

	private initAssertionPupilPoints() {
		if(engine == NIRIS){
            expPupilPointList_imgEnh_R_IDB = [ [ 327, 247 ] ]
            expPupilPointList_imgEnh_L_IDB = [ [ 315, 241 ] ]
            expPupilPointList_imgEnh_R_II = [ [ 327, 242 ] ]
            expPupilPointList_imgEnh_L_II = [ [ 315, 242 ] ]
            expPupilPointList_imgNoEnh_R_IDB = [ [ 327, 247 ] ]
            expPupilPointList_imgNoEnh_L_IDB = [ [ 315, 241 ] ]
            expPupilPointList_imgNoEnh_R_II = [ [ 327, 242 ] ]
            expPupilPointList_imgNoEnh_L_II = [ [ 315, 242 ] ]
			expPupilPointList_flxBModel_false_R = [ [ 327, 242 ] ]
			expPupilPointList_flxBModel_false_L = [ [ 315, 242 ] ]
		}else if(engine == VERIEYE){
			expPupilPointList_imgEnh_R_IDB = [
				[388, 246], [386, 234], [382, 222], [376, 212], [370, 204], [360, 196],
				[350, 190], [338, 186], [326, 186], [314, 188], [302, 190], [292, 196],
				[282, 204], [276, 212], [270, 224], [266, 234], [266, 246], [266, 258],
				[270, 268], [276, 278], [284, 288], [292, 296], [304, 300], [314, 304],
				[326, 306], [338, 304], [350, 302], [360, 296], [368, 288], [376, 280],
				[382, 270], [386, 258],
			]
			expPupilPointList_imgEnh_L_IDB = [
				[370, 240], [368, 230], [366, 220], [360, 210], [354, 202], [346, 194],
				[336, 190], [326, 186], [314, 186], [304, 186], [294, 190], [284, 194],
				[276, 202], [268, 210], [264, 220], [260, 230], [258, 242], [260, 252],
				[262, 262], [268, 272], [274, 280], [284, 288], [292, 292], [304, 296],
				[314, 296], [324, 294], [336, 292], [344, 286], [352, 280], [360, 270],
				[364, 262], [368, 252],
			]
			expPupilPointList_imgEnh_R_II = [
				[382, 242], [380, 230], [378, 220], [372, 210], [366, 202], [356, 194],
				[346, 190], [336, 186], [324, 186], [314, 186], [304, 190], [294, 194],
				[286, 202], [278, 210], [274, 220], [270, 230], [270, 242], [270, 252],
				[274, 262], [280, 272], [286, 280], [294, 288], [304, 292], [314, 296],
				[326, 298], [336, 296], [348, 294], [356, 288], [366, 282], [372, 272],
				[378, 264], [380, 252],
			]
			expPupilPointList_imgEnh_L_II = [
				[372, 242], [370, 230], [368, 220], [362, 210], [356, 202], [346, 194],
				[336, 188], [326, 186], [314, 184], [304, 186], [292, 188], [282, 194],
				[274, 202], [268, 210], [262, 220], [258, 230], [258, 242], [258, 254],
				[262, 264], [266, 274], [274, 282], [282, 290], [292, 296], [304, 298],
				[314, 298], [326, 298], [336, 294], [346, 288], [354, 282], [362, 274],
				[366, 264], [370, 252],
			]
			expPupilPointList_imgNoEnh_R_IDB = expPupilPointList_imgEnh_R_IDB
			expPupilPointList_imgNoEnh_L_IDB = expPupilPointList_imgEnh_L_IDB
			expPupilPointList_imgNoEnh_R_II = expPupilPointList_imgEnh_R_II
			expPupilPointList_imgNoEnh_L_II = expPupilPointList_imgEnh_L_II

			expPupilPointList_flxBModel_false_R = [
                [ 382, 240 ], [ 380, 228 ], [ 378, 218 ], [ 372, 208 ], [ 366, 198 ], [ 356, 192 ], [ 346, 186 ],
                [ 336, 184 ], [ 324, 182 ], [ 312, 184 ], [ 302, 186 ], [ 292, 192 ], [ 282, 198 ], [ 276, 208 ],
                [ 270, 218 ], [ 268, 228 ], [ 266, 240 ], [ 268, 252 ], [ 270, 262 ], [ 276, 272 ], [ 282, 282 ],
                [ 292, 288 ], [ 302, 294 ], [ 312, 296 ], [ 324, 298 ], [ 336, 296 ], [ 346, 294 ], [ 356, 288 ],
                [ 366, 282 ], [ 372, 272 ], [ 378, 262 ], [ 380, 252 ],
            ]
			expPupilPointList_flxBModel_false_L = [
                [ 370, 240 ], [ 368, 228 ], [ 366, 218 ], [ 360, 208 ], [ 354, 198 ], [ 344, 192 ], [ 334, 186 ],
                [ 324, 184 ], [ 312, 182 ], [ 300, 184 ], [ 290, 186 ], [ 280, 192 ], [ 270, 198 ], [ 264, 208 ],
                [ 258, 218 ], [ 256, 228 ], [ 254, 240 ], [ 256, 252 ], [ 258, 262 ], [ 264, 272 ], [ 270, 282 ],
                [ 280, 288 ], [ 290, 294 ], [ 300, 296 ], [ 312, 298 ], [ 324, 296 ], [ 334, 294 ], [ 344, 288 ],
                [ 354, 282 ], [ 360, 272 ], [ 366, 262 ], [ 368, 252 ],
            ]
		}else{
            abendTest("Engine '${engine}' is unexpected value!!")
		}
	}

	private initAssertionIrisPoints() {
		if(engine == NIRIS){
            expIrisPointList_imgEnh_R_IDB = [ [ 321, 247 ] ]
            expIrisPointList_imgEnh_L_IDB = [ [ 320, 241 ] ]
            expIrisPointList_imgEnh_R_II = [ [ 320, 242 ] ]
            expIrisPointList_imgEnh_L_II = [ [ 319, 242 ] ]
            expIrisPointList_imgNoEnh_R_IDB = [ [ 321, 247 ] ]
            expIrisPointList_imgNoEnh_L_IDB = [ [ 320, 241 ] ]
            expIrisPointList_imgNoEnh_R_II = [ [ 320, 242 ] ]
            expIrisPointList_imgNoEnh_L_II = [ [ 319, 242 ] ]
            expIrisPointList_flxBModel_false_R = [ [ 320, 242 ] ]
            expIrisPointList_flxBModel_false_L = [ [ 319, 242 ] ]
		}else if(engine == VERIEYE){
			expIrisPointList_imgEnh_R_IDB = [
				[462, 246], [458, 220], [450, 196], [438, 172], [420, 152], [400, 134],
				[378, 122], [352, 112], [326, 110], [298, 110], [272, 118], [246, 130],
				[224, 146], [206, 166], [192, 190], [182, 218], [178, 246], [182, 274],
				[190, 302], [204, 326], [224, 348], [246, 364], [272, 376], [298, 384],
				[326, 386], [354, 382], [380, 374], [404, 360], [424, 342], [440, 322],
				[454, 298], [460, 272],
			]
			expIrisPointList_imgEnh_L_IDB = [
				[460, 240], [456, 212], [448, 186], [432, 162], [414, 142], [392, 124],
				[368, 112], [342, 106], [314, 104], [288, 106], [262, 116], [240, 128],
				[218, 146], [202, 166], [190, 190], [182, 214], [178, 242], [180, 268],
				[188, 294], [200, 318], [216, 338], [236, 356], [260, 370], [286, 378],
				[314, 382], [342, 380], [368, 372], [394, 360], [416, 342], [436, 322],
				[450, 296], [458, 268],
			]
			expIrisPointList_imgEnh_R_II = [
				[462, 242], [458, 216], [448, 192], [436, 168], [420, 148], [400, 130],
				[376, 118], [352, 108], [324, 104], [298, 106], [270, 112], [246, 124],
				[224, 142], [206, 162], [190, 186], [182, 212], [178, 240], [180, 270],
				[190, 296], [204, 322], [222, 344], [246, 360], [270, 374], [298, 382],
				[326, 384], [354, 380], [380, 372], [404, 358], [424, 340], [442, 318],
				[454, 294], [460, 270],
			]
			expIrisPointList_imgEnh_L_II = [
				[462, 242], [458, 212], [448, 186], [434, 162], [416, 140], [394, 122],
				[370, 110], [342, 102], [316, 100], [288, 102], [260, 110], [236, 124],
				[216, 142], [198, 164], [186, 188], [178, 216], [176, 242], [178, 270],
				[186, 296], [198, 320], [216, 342], [236, 358], [260, 372], [286, 382],
				[314, 384], [342, 382], [370, 374], [394, 362], [418, 344], [436, 322],
				[450, 298], [458, 270],
			]
            expIrisPointList_imgNoEnh_R_IDB = expIrisPointList_imgEnh_R_IDB
            expIrisPointList_imgNoEnh_L_IDB = expIrisPointList_imgEnh_L_IDB
            expIrisPointList_imgNoEnh_R_II = expIrisPointList_imgEnh_R_II
			expIrisPointList_imgNoEnh_L_II = [
				[462, 242], [458, 212], [448, 186], [434, 162], [416, 140], [394, 122],
				[370, 110], [342, 102], [316, 100], [288, 102], [260, 110], [236, 124],
				[216, 142], [198, 164], [186, 188], [178, 214], [176, 242], [178, 270],
				[186, 296], [198, 320], [216, 342], [236, 360], [260, 372], [286, 382],
				[314, 384], [342, 382], [370, 376], [394, 362], [418, 344], [436, 322],
				[450, 298], [458, 270],
			]
			expIrisPointList_flxBModel_false_R = [
				[464, 244], [462, 216], [454, 188], [440, 164], [422, 142], [400, 124],
				[376, 110], [348, 102], [320, 100], [292, 102], [264, 110], [240, 124],
				[218, 142], [200, 164], [186, 188], [178, 216], [176, 244], [178, 272],
				[186, 300], [200, 324], [218, 346], [240, 364], [264, 378], [292, 386],
				[320, 388], [348, 386], [376, 378], [400, 364], [422, 346], [440, 324],
				[454, 300], [462, 272],
			]
			expIrisPointList_flxBModel_false_L = [
				[464, 242], [462, 214], [452, 186], [440, 160], [422, 138], [400, 120],
				[374, 108], [346, 98], [318, 96], [290, 98], [262, 108], [236, 120],
				[214, 138], [196, 160], [184, 186], [174, 214], [172, 242], [174, 270],
				[184, 298], [196, 324], [214, 346], [236, 364], [262, 376], [290, 386],
				[318, 388], [346, 386], [374, 376], [400, 364], [422, 346], [440, 324],
				[452, 298], [462, 270],
			]

		}else{
            abendTest("Engine '${engine}' is unexpected value!!")
		}
	}

    private void abendTest(String messg){
        abendProcessor.abendTest(messg)
    }

    public int getExpQuality_imgEnh_R(boolean isDeInterlace, String key) {
        if(isDeInterlace) {
			if(key == IDB){
				return expQuality_imgEnh_R_IDB
			}else if(key == II){
				return expQuality_imgEnh_R_II
			}
        }else{
			if(key == IDB){
				return expQuality_imgNoEnh_R_IDB
			}else if(key == II){
				return expQuality_imgNoEnh_R_II
			}
        }
    }

    public int getExpQuality_imgEnh_L(boolean isDeInterlace, String key) {
        if(isDeInterlace) {
			if(key == IDB){
				return expQuality_imgEnh_L_IDB
			}else if(key == II){
				return expQuality_imgEnh_L_II
			}
        }else{
			if(key == IDB){
				return expQuality_imgNoEnh_L_IDB
			}else if(key == II){
				return expQuality_imgNoEnh_L_II
			}
        }
    }

    public List getExpPupilPoints_imgEnh_R(boolean isDeInterlace, String key) {
        if(isDeInterlace) {
			if(key == IDB){
				return expPupilPointList_imgEnh_R_IDB
			}else if(key == II){
				return expPupilPointList_imgEnh_R_II
			}
        }else{
			if(key == IDB){
				return expPupilPointList_imgNoEnh_R_IDB
			}else if(key == II){
				return expPupilPointList_imgNoEnh_R_II
			}
        }
    }

    public List getExpPupilPoints_imgEnh_L(boolean isDeInterlace, String key) {
        if(isDeInterlace) {
			if(key == IDB){
				return expPupilPointList_imgEnh_L_IDB
			}else if(key == II){
				return expPupilPointList_imgEnh_L_II
			}
        }else{
			if(key == IDB){
				return expPupilPointList_imgNoEnh_L_IDB
			}else if(key == II){
				return expPupilPointList_imgNoEnh_L_II
			}
        }
    }

    public List getExpIrisPoints_imgEnh_R(boolean isDeInterlace, String key) {
        if(isDeInterlace) {
			if(key == IDB){
				return expIrisPointList_imgEnh_R_IDB
			}else if(key == II){
				return expIrisPointList_imgEnh_R_II
			}
        }else{ 
			if(key == IDB){
				return expIrisPointList_imgNoEnh_R_IDB
			}else if(key == II){
				return expIrisPointList_imgNoEnh_R_II
			}
        }
    }

    public List getExpIrisPoints_L(boolean isDeInterlace, String key) {
        if(isDeInterlace) {
			if(key == IDB){
				return expIrisPointList_imgEnh_L_IDB
			}else if(key == II){
				return expIrisPointList_imgEnh_L_II
			}
        }else{ 
			if(key == IDB){
				return expIrisPointList_imgNoEnh_L_IDB
			}else if(key == II){
				return expIrisPointList_imgNoEnh_L_II
			}
        }
    }

    public int getExpQuality_flxBModel_true_R() {
        return expQuality_flexibleModel_R
    }

    public int getExpQuality_flxBModel_true_L() {
        return expQuality_flexibleModel_L
    }

	public List getExpPupilPoints_flxBModel_true_R() {
		return [
			[382, 242], [380, 230], [378, 220], [372, 210], [366, 202], [356, 194],
			[346, 190], [336, 186], [324, 186], [314, 186], [304, 190], [294, 194],
			[286, 202], [278, 210], [274, 220], [270, 230], [270, 242], [270, 252],
			[274, 262], [280, 272], [286, 280], [294, 288], [304, 292], [314, 296],
			[326, 298], [336, 296], [348, 294], [356, 288], [366, 282], [372, 272],
			[378, 264], [380, 252],
		]
	}

	public List getExpIrisPoints_flxBModel_true_R() {
		return [
			[462, 242], [458, 216], [448, 192], [436, 168], [420, 148], [400, 130],
			[376, 118], [352, 108], [324, 104], [298, 106], [270, 112], [246, 124],
			[224, 142], [206, 162], [190, 186], [182, 212], [178, 240], [180, 270],
			[190, 296], [204, 322], [222, 344], [246, 360], [270, 374], [298, 382],
			[326, 384], [354, 380], [380, 372], [404, 358], [424, 340], [442, 318],
			[454, 294], [460, 270],
		]
	}

	public List getExpPupilPoints_flxBModel_true_L() {
		return [
			[372, 242], [370, 230], [368, 220], [362, 210], [356, 202], [346, 194],
			[336, 188], [326, 186], [314, 184], [304, 186], [292, 188], [282, 194],
			[274, 202], [268, 210], [262, 220], [258, 230], [258, 242], [258, 254],
			[262, 264], [266, 274], [274, 282], [282, 290], [292, 296], [304, 298],
			[314, 298], [326, 298], [336, 294], [346, 288], [354, 282], [362, 274],
			[366, 264], [370, 252],
		]
	}

    public List getExpIrisPoints_flxBModel_true_L() {
		return [
			[462, 242], [458, 212], [448, 186], [434, 162], [416, 140], [394, 122],
			[370, 110], [342, 102], [316, 100], [288, 102], [260, 110], [236, 124],
			[216, 142], [198, 164], [186, 188], [178, 216], [176, 242], [178, 270],
			[186, 296], [198, 320], [216, 342], [236, 358], [260, 372], [286, 382],
			[314, 384], [342, 382], [370, 374], [394, 362], [418, 344], [436, 322],
			[450, 298], [458, 270],
		]
    }

    public int getExpQuality_flxBModel_false_R() {
        return getExpQuality_flxBModel_true_R()
    }

    public int getExpQuality_flxBModel_false_L() {
        return getExpQuality_flxBModel_true_L()
    }

    public List getExpPupilPoints_flxBModel_false_L() {
		return expPupilPointList_flxBModel_false_L
    }

    public List getExpIrisPoints_flxBModel_false_L() {
		return expIrisPointList_flxBModel_false_L
    }

    public List getExpPupilPoints_flxBModel_false_R() {
		return expPupilPointList_flxBModel_false_R
    }

    public List getExpIrisPoints_flxBModel_false_R() {
		return expIrisPointList_flxBModel_false_R
    }

    public int getExpQuality_minPup_R_1() {
        return 70
    }

    public int getExpQuality_minPup_L_1() {
        return 67
    }

    public List getExpPupilPoints_minPup_R_1() {
        return getExpPupilPoints_flxBModel_true_R()
    }

    public List getExpIrisPoints_minPup_R_1() {
        return getExpIrisPoints_flxBModel_true_R()
    }

    public List getExpPupilPoints_minPup_L_1() {
        return getExpPupilPoints_flxBModel_true_L()
    }

    public List getExpIrisPoints_minPup_L_1() {
        return getExpIrisPoints_flxBModel_true_L()
    }

    public int getExpQuality_minPup_R_2() {
        return 68
    }

    public int getExpQuality_minPup_L_2() {
        return 66
    }

	public List getExpPupilPoints_minPup_R_2() {
		return [
			[382, 242], [380, 232], [378, 220], [372, 210], [366, 202], [356, 196],
			[346, 190], [336, 186], [324, 186], [314, 186], [304, 190], [294, 196],
			[286, 202], [278, 210], [274, 220], [270, 230], [270, 242], [270, 252],
			[274, 262], [280, 272], [286, 280], [294, 288], [304, 292], [314, 296],
			[326, 298], [336, 296], [348, 294], [356, 288], [366, 282], [372, 272],
			[378, 264], [380, 252],
		]
	}

	public List getExpIrisPoints_minPup_R_2() {
		return [
			[462, 242], [458, 216], [448, 192], [436, 168], [420, 148], [400, 130],
			[376, 118], [352, 108], [324, 104], [298, 106], [270, 112], [246, 124],
			[224, 140], [206, 162], [190, 186], [182, 212], [178, 240], [180, 270],
			[190, 296], [204, 322], [222, 344], [246, 360], [270, 374], [298, 380],
			[326, 382], [354, 380], [380, 370], [404, 358], [424, 340], [442, 318],
			[454, 294], [460, 270],
		]
	}

	public List getExpPupilPoints_minPup_L_2() {
		return [
			[372, 242], [370, 230], [368, 220], [362, 210], [356, 200], [346, 194],
			[336, 188], [326, 186], [314, 184], [304, 186], [292, 188], [284, 194],
			[274, 202], [268, 210], [262, 220], [258, 230], [258, 242], [258, 254],
			[262, 264], [266, 274], [274, 282], [282, 290], [292, 296], [304, 298],
			[314, 298], [326, 298], [336, 294], [346, 288], [354, 282], [362, 272],
			[366, 264], [370, 252],
		]
	}

	public List getExpIrisPoints_minPup_L_2() {
		return [
			[462, 242], [458, 212], [448, 186], [434, 162], [416, 140], [394, 122],
			[370, 110], [342, 102], [316, 100], [288, 102], [262, 110], [236, 124],
			[216, 142], [198, 164], [186, 188], [178, 216], [176, 242], [178, 270],
			[186, 296], [198, 320], [216, 342], [236, 358], [260, 372], [286, 382],
			[314, 384], [342, 382], [370, 374], [394, 362], [418, 344], [436, 322],
			[450, 298], [458, 270],
		]
	}

    public int getExpQuality_maxPup_R_1() {
        return 68
    }

    public int getExpQuality_maxPup_L_1() {
        return 65
    }

	public List getExpPupilPoints_maxPup_R_1() {
		return [
			[382, 242], [380, 232], [378, 220], [372, 210], [366, 202], [356, 196],
			[346, 190], [336, 186], [324, 186], [314, 186], [304, 190], [294, 196],
			[286, 202], [278, 210], [274, 220], [270, 230], [270, 242], [270, 252],
			[274, 262], [280, 272], [286, 280], [294, 288], [304, 292], [314, 296],
			[326, 298], [336, 296], [348, 294], [356, 288], [366, 282], [372, 272],
			[378, 264], [380, 252],
		]
	}

	public List getExpIrisPoints_maxPup_R_1() {
		return [
			[462, 242], [458, 216], [448, 192], [436, 168], [420, 148], [400, 130],
			[376, 118], [352, 108], [324, 104], [298, 106], [270, 112], [246, 124],
			[224, 140], [206, 162], [190, 186], [182, 212], [178, 240], [180, 270],
			[190, 296], [204, 322], [222, 344], [246, 360], [270, 374], [298, 380],
			[326, 382], [354, 380], [380, 370], [404, 358], [424, 340], [442, 318],
			[454, 294], [460, 270],
		]
	}

	public List getExpPupilPoints_maxPup_L_1() {
		return [
			[372, 242], [370, 230], [368, 220], [362, 210], [356, 200], [346, 194],
			[336, 188], [326, 186], [314, 184], [304, 186], [292, 188], [284, 194],
			[274, 202], [268, 210], [262, 220], [258, 230], [258, 242], [258, 254],
			[262, 264], [266, 274], [274, 282], [282, 290], [292, 296], [304, 298],
			[314, 298], [326, 298], [336, 294], [346, 288], [354, 282], [362, 272],
			[366, 264], [370, 252],
		]
	}

	public List getExpIrisPoints_maxPup_L_1() {
		return [
			[462, 242], [458, 212], [448, 186], [434, 162], [416, 140], [394, 122],
			[370, 110], [342, 102], [316, 100], [288, 102], [262, 110], [236, 124],
			[216, 142], [198, 164], [186, 188], [178, 216], [176, 242], [178, 270],
			[186, 296], [198, 320], [216, 342], [236, 358], [260, 372], [286, 382],
			[314, 384], [342, 382], [370, 374], [394, 362], [418, 344], [436, 322],
			[450, 298], [458, 270],
		]
	}

    public int getExpQuality_maxPup_R_2() {
        return 70
    }

    public int getExpQuality_maxPup_L_2() {
        return 67
    }

	public List getExpPupilPoints_maxPup_R_2() {
		return [
			[382, 242], [380, 230], [378, 220], [372, 210], [366, 202], [356, 194],
			[346, 190], [336, 186], [324, 186], [314, 186], [304, 190], [294, 194],
			[286, 202], [278, 210], [274, 220], [270, 230], [270, 242], [270, 252],
			[274, 262], [280, 272], [286, 280], [294, 288], [304, 292], [314, 296],
			[326, 298], [336, 296], [348, 294], [356, 288], [366, 282], [372, 272],
			[378, 264], [380, 252],
		]
	}

	public List getExpIrisPoints_maxPup_R_2() {
		return [
			[462, 242], [458, 216], [448, 192], [436, 168], [420, 148], [400, 130],
			[376, 118], [352, 108], [324, 104], [298, 106], [270, 112], [246, 124],
			[224, 142], [206, 162], [190, 186], [182, 212], [178, 240], [180, 270],
			[190, 296], [204, 322], [222, 344], [246, 360], [270, 374], [298, 382],
			[326, 384], [354, 380], [380, 372], [404, 358], [424, 340], [442, 318],
			[454, 294], [460, 270],
		]
	}

	public List getExpPupilPoints_maxPup_L_2() {
		return [
			[372, 242], [370, 230], [368, 220], [362, 210], [356, 202], [346, 194],
			[336, 188], [326, 186], [314, 184], [304, 186], [292, 188], [282, 194],
			[274, 202], [268, 210], [262, 220], [258, 230], [258, 242], [258, 254],
			[262, 264], [266, 274], [274, 282], [282, 290], [292, 296], [304, 298],
			[314, 298], [326, 298], [336, 294], [346, 288], [354, 282], [362, 274],
			[366, 264], [370, 252],
		]
	}

	public List getExpIrisPoints_maxPup_L_2() {
		return [
			[462, 242], [458, 212], [448, 186], [434, 162], [416, 140], [394, 122],
			[370, 110], [342, 102], [316, 100], [288, 102], [260, 110], [236, 124],
			[216, 142], [198, 164], [186, 188], [178, 216], [176, 242], [178, 270],
			[186, 296], [198, 320], [216, 342], [236, 358], [260, 372], [286, 382],
			[314, 384], [342, 382], [370, 374], [394, 362], [418, 344], [436, 322],
			[450, 298], [458, 270],
		]
	}

    public int getExpQuality_minIris_R_1() {
        return 70
    }

    public int getExpQuality_minIris_L_1() {
        return 67
    }

	public List getExpPupilPoints_minIris_R_1() {
		return [
			[382, 242], [380, 230], [378, 220], [372, 210], [366, 202], [356, 194],
			[346, 190], [336, 186], [324, 186], [314, 186], [304, 190], [294, 194],
			[286, 202], [278, 210], [274, 220], [270, 230], [270, 242], [270, 252],
			[274, 262], [280, 272], [286, 280], [294, 288], [304, 292], [314, 296],
			[326, 298], [336, 296], [348, 294], [356, 288], [366, 282], [372, 272],
			[378, 264], [380, 252],
		]
	}

	public List getExpIrisPoints_minIris_R_1() {
		return [
			[462, 242], [458, 216], [448, 192], [436, 168], [420, 148], [400, 130],
			[376, 118], [352, 108], [324, 104], [298, 106], [270, 112], [246, 124],
			[224, 142], [206, 162], [190, 186], [182, 212], [178, 240], [180, 270],
			[190, 296], [204, 322], [222, 344], [246, 360], [270, 374], [298, 382],
			[326, 384], [354, 380], [380, 372], [404, 358], [424, 340], [442, 318],
			[454, 294], [460, 270],
		]
	}

	public List getExpPupilPoints_minIris_L_1() {
		return [
			[372, 242], [370, 230], [368, 220], [362, 210], [356, 202], [346, 194],
			[336, 188], [326, 186], [314, 184], [304, 186], [292, 188], [282, 194],
			[274, 202], [268, 210], [262, 220], [258, 230], [258, 242], [258, 254],
			[262, 264], [266, 274], [274, 282], [282, 290], [292, 296], [304, 298],
			[314, 298], [326, 298], [336, 294], [346, 288], [354, 282], [362, 274],
			[366, 264], [370, 252],
		]
	}

	public List getExpIrisPoints_minIris_L_1() {
		return [
			[462, 242], [458, 212], [448, 186], [434, 162], [416, 140], [394, 122],
			[370, 110], [342, 102], [316, 100], [288, 102], [260, 110], [236, 124],
			[216, 142], [198, 164], [186, 188], [178, 216], [176, 242], [178, 270],
			[186, 296], [198, 320], [216, 342], [236, 358], [260, 372], [286, 382],
			[314, 384], [342, 382], [370, 374], [394, 362], [418, 344], [436, 322],
			[450, 298], [458, 270],
		]
	}

    public int getExpQuality_minIris_R_2() {
        return getExpQuality_minIris_R_1()
    }

    public int getExpQuality_minIris_L_2() {
        return getExpQuality_minIris_L_1()
    }

	public List getExpPupilPoints_minIris_R_2() {
		return [
			[382, 242], [380, 230], [378, 220], [372, 210], [366, 202], [356, 194],
			[346, 190], [336, 186], [324, 186], [314, 186], [304, 190], [294, 194],
			[286, 202], [278, 210], [274, 220], [270, 230], [270, 242], [270, 252],
			[274, 262], [280, 272], [286, 280], [294, 288], [304, 292], [314, 296],
			[326, 298], [336, 296], [348, 294], [356, 288], [366, 282], [372, 272],
			[378, 264], [380, 252],
		]
	}

	public List getExpIrisPoints_minIris_R_2() {
		return [
			[462, 242], [458, 216], [448, 192], [436, 168], [420, 148], [400, 130],
			[376, 118], [352, 108], [324, 104], [298, 106], [270, 112], [246, 124],
			[224, 142], [206, 162], [190, 186], [182, 212], [178, 240], [180, 270],
			[190, 296], [204, 322], [222, 344], [246, 360], [270, 374], [298, 382],
			[326, 384], [354, 380], [380, 372], [404, 358], [424, 340], [442, 318],
			[454, 294], [460, 270],
		]
	}

	public List getExpPupilPoints_minIris_L_2() {
		return [
			[372, 242], [370, 230], [368, 220], [362, 210], [356, 200], [346, 194],
			[336, 188], [326, 186], [314, 184], [304, 186], [292, 188], [284, 194],
			[274, 202], [268, 210], [262, 220], [258, 230], [258, 242], [258, 254],
			[262, 264], [266, 274], [274, 282], [282, 290], [292, 296], [304, 298],
			[314, 298], [326, 298], [336, 294], [346, 288], [354, 282], [362, 272],
			[366, 264], [370, 252],
		]
	}

	public List getExpIrisPoints_minIris_L_2() {
		return [
			[462, 242], [458, 212], [448, 186], [434, 162], [416, 140], [394, 122],
			[370, 110], [342, 102], [316, 100], [288, 102], [262, 110], [236, 124],
			[216, 142], [198, 164], [186, 188], [178, 216], [176, 242], [178, 270],
			[186, 296], [198, 320], [216, 342], [236, 360], [260, 372], [286, 382],
			[314, 384], [342, 382], [370, 374], [394, 362], [418, 344], [436, 322],
			[450, 298], [458, 270],
		]
	}

    public int getExpQuality_maxIris_R_1() {
        return 70
    }

    public int getExpQuality_maxIris_L_1() {
        return 66
    }

	public List getExpPupilPoints_maxIris_R_1() {
		return [
			[382, 242], [380, 230], [378, 220], [372, 210], [366, 202], [356, 194],
			[346, 190], [336, 186], [324, 186], [314, 186], [304, 190], [294, 194],
			[286, 202], [278, 210], [274, 220], [270, 230], [270, 242], [270, 252],
			[274, 262], [280, 272], [286, 280], [294, 288], [304, 292], [314, 296],
			[326, 298], [336, 296], [348, 294], [356, 288], [366, 282], [372, 272],
			[378, 264], [380, 252],
		]
	}

	public List getExpIrisPoints_maxIris_R_1() {
		return [
			[462, 242], [458, 216], [448, 192], [436, 168], [420, 148], [400, 130],
			[376, 118], [352, 108], [324, 104], [298, 106], [270, 112], [246, 124],
			[224, 142], [206, 162], [190, 186], [182, 212], [178, 240], [180, 270],
			[190, 296], [204, 322], [222, 344], [246, 360], [270, 374], [298, 382],
			[326, 384], [354, 380], [380, 372], [404, 358], [424, 340], [442, 318],
			[454, 294], [460, 270],
		]
	}

	public List getExpPupilPoints_maxIris_L_1() {
		return [
			[372, 242], [370, 230], [368, 220], [362, 210], [356, 202], [346, 194],
			[336, 188], [326, 186], [314, 184], [304, 186], [292, 188], [282, 194],
			[274, 202], [268, 210], [262, 220], [258, 230], [258, 242], [258, 254],
			[262, 264], [266, 274], [274, 282], [282, 290], [292, 296], [304, 298],
			[314, 298], [326, 298], [336, 294], [346, 288], [354, 282], [362, 274],
			[366, 264], [370, 252],
		]
	}

	public List getExpIrisPoints_maxIris_L_1() {
		return [
			[462, 242], [458, 212], [448, 186], [434, 162], [416, 140], [394, 122],
			[370, 110], [342, 102], [316, 100], [288, 102], [260, 110], [236, 124],
			[216, 142], [198, 164], [186, 188], [178, 216], [176, 242], [178, 270],
			[186, 296], [198, 320], [216, 342], [236, 358], [260, 372], [286, 382],
			[314, 384], [342, 382], [370, 374], [394, 362], [418, 344], [436, 322],
			[450, 298], [458, 270],
		]
	}

    public int getExpQuality_maxIris_R_2() {
        return 70
    }

    public int getExpQuality_maxIris_L_2() {
        return 67
    }

	public List getExpPupilPoints_maxIris_R_2() {
		return [
			[382, 242], [380, 230], [378, 220], [372, 210], [366, 202], [356, 194],
			[346, 190], [336, 186], [324, 186], [314, 186], [304, 190], [294, 194],
			[286, 202], [278, 210], [274, 220], [270, 230], [270, 242], [270, 252],
			[274, 262], [280, 272], [286, 280], [294, 288], [304, 292], [314, 296],
			[326, 298], [336, 296], [348, 294], [356, 288], [366, 282], [372, 272],
			[378, 264], [380, 252],
		]
	}

	public List getExpIrisPoints_maxIris_R_2() {
		return [
			[462, 242], [458, 216], [448, 192], [436, 168], [420, 148], [400, 130],
			[376, 118], [352, 108], [324, 104], [298, 106], [270, 112], [246, 124],
			[224, 142], [206, 162], [190, 186], [182, 212], [178, 240], [180, 270],
			[190, 296], [204, 322], [222, 344], [246, 360], [270, 374], [298, 382],
			[326, 384], [354, 380], [380, 372], [404, 358], [424, 340], [442, 318],
			[454, 294], [460, 270],
		]
	}

	public List getExpPupilPoints_maxIris_L_2() {
		return [
			[372, 242], [370, 230], [368, 220], [362, 210], [356, 202], [346, 194],
			[336, 188], [326, 186], [314, 184], [304, 186], [292, 188], [282, 194],
			[274, 202], [268, 210], [262, 220], [258, 230], [258, 242], [258, 254],
			[262, 264], [266, 274], [274, 282], [282, 290], [292, 296], [304, 298],
			[314, 298], [326, 298], [336, 294], [346, 288], [354, 282], [362, 274],
			[366, 264], [370, 252],
		]
	}

	public List getExpIrisPoints_maxIris_L_2() {
		return [
			[462, 242], [458, 212], [448, 186], [434, 162], [416, 140], [394, 122],
			[370, 110], [342, 102], [316, 100], [288, 102], [260, 110], [236, 124],
			[216, 142], [198, 164], [186, 188], [178, 216], [176, 242], [178, 270],
			[186, 296], [198, 320], [216, 342], [236, 358], [260, 372], [286, 382],
			[314, 384], [342, 382], [370, 374], [394, 362], [418, 344], [436, 322],
			[450, 298], [458, 270],
		]
	}
}
