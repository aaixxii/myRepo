package test.degrade.testitem.helper.option


class TestOptionsCreateHelper {
	
	static final String EQUAL = "="
	static final String QUOTATION ="\""
	static final String SPACE =" "
	static final String END_1 = " > \n"
	static final String END_2 = " /> \n"
	static final String LINE_FEED_CODE = "\n"

	def makeAttribute(def key, def value){
		if (value == "") return " "
		return key + EQUAL + QUOTATION + value + QUOTATION + SPACE
	}
}
