package test.degrade.testitem.helper

import test.common.format.*
import test.degrade.properties.*
import test.degrade.evidence.*
import org.apache.commons.codec.binary.Base64
import jp.co.nec.nhm.soapui.util.NistReader
import jp.co.nec.nhm.soapui.util.FacePrintReader
import static test.common.constants.aim.AIMWord.*
import static test.common.constants.data.ImageDataList.*

class TestImgXmlMaker{

	private String dataFilePathRoot
	private NistReaderWrapper nistReaderWrapper

    TestImgXmlMaker(context){
        this.dataFilePathRoot = new GlobalProperties(context).getDataFilePath()
		this.nistReaderWrapper = new NistReaderWrapper(context)
    }

	def getTenprintFingerImgXml(String dataPath){
		return nistReaderWrapper.getNistFingerImgXml(dataFilePathRoot + dataPath)
	}
	
	def getTenprintPalmImgXml(String dataPath){
		return nistReaderWrapper.getNistPalmImgXml(dataFilePathRoot + dataPath)
	}

	def getFaceImgXml(String dataPath){
		return new FacePrintReader().getBase64XML(dataFilePathRoot + dataPath)
	}
	
	def getLatentFingerImgXml(String dataPath){
		def file = new File(dataFilePathRoot + dataPath)
		def b64 = new Base64()
		String b64String = new String(b64.encode(file.readBytes()))
		StringBuilder latentB64 = new StringBuilder("<image pos='0' type='1'><data>")
		latentB64.append(b64String)
		latentB64.append("</data></image>")
		return latentB64
	}

	def getLatentPalmImgXml(String dataPath){
		def file = new File(dataFilePathRoot + dataPath)
		def b64 = new Base64()
		String b64String = new String(b64.encode(file.readBytes()))
		StringBuilder latentB64 = new StringBuilder("<image pos='20' type='1'><data>")
		latentB64.append(b64String)
		latentB64.append("</data></image>")
		return latentB64
	}

	def getLatentFuncDefTenprintImgXml(){
		String images = nistReaderWrapper.getNistFingerImgXml(dataFilePathRoot +  TF_022_RS_NST)
		def formatter = new AimXmlFormatter()
		images = formatter.deleteImageXml(images, 11)
		images = formatter.deleteImageXml(images, 1)

		def file = new File(dataFilePathRoot + TF_023_BMP)
		def b64_Roll = new Base64()
		String b64String_Roll = new String(b64_Roll.encode(file.readBytes()))
		images += "<image pos='1' type='4'><data>"
		images += b64String_Roll
		images += "</data></image>"

		def file2 = new File(dataFilePathRoot + TF_024_BMP)
		def b64_Slap = new Base64()
		String b64String_Slap = new String(b64_Slap.encode(file2.readBytes()))
		images += "<image pos='11' type='4'><data>"
		images += b64String_Slap
		images += "</data></image>"
		return images
	}

	def getLatentFuncFullScoreTenprintImgXml(){
		String images = nistReaderWrapper.getNistFingerImgXml(dataFilePathRoot +  TF_022_RS_NST)
		def formatter = new AimXmlFormatter()
		images = formatter.deleteImageXml(images, 11)
		images = formatter.deleteImageXml(images, 1)

		def file = new File(dataFilePathRoot + LF_001_WSQ)
		def b64_Roll = new Base64()
		String b64String_Roll = new String(b64_Roll.encode(file.readBytes()))
		images += "<image pos='1' type='1'><data>"
		images += b64String_Roll
		images += "</data></image>"

		def file2 = new File(dataFilePathRoot + LF_001_WSQ)
		def b64_Slap = new Base64()
		String b64String_Slap = new String(b64_Slap.encode(file2.readBytes()))
		images += "<image pos='11' type='1'><data>"
		images += b64String_Slap
		images += "</data></image>"
		return images
	}

	def getPalmTwoPartsImgXml(){
		def file = new File(dataFilePathRoot + LP_002_WSQ)
		def b64 = new Base64()
		String b64String = new String(b64.encode(file.readBytes()))
		StringBuilder sb = new StringBuilder()
		for(i in 21..24){
			sb.append("<image pos='${i}' type='1'><data>")
			sb.append(b64String)
			sb.append("</data></image>")
		}
		return sb.toString()
	}

	def getPalmThreePartsImgXml(){
		def file = new File(dataFilePathRoot + LP_002_WSQ)
		def b64 = new Base64()
		String b64String = new String(b64.encode(file.readBytes()))
		StringBuilder latentB64 = new StringBuilder()
		for(i in 1..4){
			if(i == 1){
				latentB64.append("<image pos='22' type='1' vert-scale='500' horiz-scale='500' dpi='500' width='2500' height='4000'><data>")
				latentB64.append(b64String)
				latentB64.append("</data></image>")
			}else if(i == 2){
				latentB64.append("<image pos='23' type='1' vert-scale='500' horiz-scale='500' dpi='500' width='2500' height='4000'><data>")
				latentB64.append(b64String)
				latentB64.append("</data></image>")
			}else if(i == 3){
				latentB64.append("<image pos='31' type='1' vert-scale='500' horiz-scale='500' dpi='500' width='2500' height='4000'><data>")
				latentB64.append(b64String)
				latentB64.append("</data></image>")
			}else if(i == 4){
				latentB64.append("<image pos='35' type='1' vert-scale='500' horiz-scale='500' dpi='500' width='2500' height='4000'><data>")
				latentB64.append(b64String)
				latentB64.append("</data></image>")
			}
		}
		return latentB64
	}

	def getPalmAllPartsImgXml(){
		def file = new File(dataFilePathRoot + LP_001_WSQ)
		def b64 = new Base64()
		String b64String = new String(b64.encode(file.readBytes()))
		StringBuilder latentB64 = new StringBuilder()
		for(i in 21..36){
			latentB64.append("<image pos='${i}' type='1' vert-scale='500' horiz-scale='500' dpi='500' width='2500' height='4000'><data>")
			latentB64.append(b64String)
			latentB64.append("</data></image>")
		}
		return latentB64
	}

    def getIrisImgXml(String dataPath, int pos, int imgType) {
		def file = new File(dataFilePathRoot + dataPath)
		def b64 = new Base64()
		String b64String = new String(b64.encode(file.readBytes()))
		StringBuilder imageXml = new StringBuilder("<image pos='${pos}' type='${imgType}'><data>")
		imageXml.append(b64String)
		imageXml.append("</data></image>")
		return imageXml
    }

    def getAimSimpleImgXml(String dataPath, def pos, def imgType) {
		def file = new File(dataFilePathRoot + dataPath)
		def b64 = new Base64()
		String b64String = new String(b64.encode(file.readBytes()))
		StringBuilder imageXml = new StringBuilder("<image pos='${pos}' type='${imgType}'><data>")
		imageXml.append(b64String)
		imageXml.append("</data></image>")
		return imageXml
    }

    def getAimSimpleImgXml(String dataPath, def pos, def imgType, def width, def height) {
		def file = new File(dataFilePathRoot + dataPath)
		def b64 = new Base64()
		String b64String = new String(b64.encode(file.readBytes()))
		StringBuilder imageXml = new StringBuilder("<image pos='${pos}' type='${imgType}' width='${width}' height='${height}'><data>")
		imageXml.append(b64String)
		imageXml.append("</data></image>")
		return imageXml
    }

    def getAimSimpleImgXmlSetFullPath(String dataPath, def pos, def imgType ) {
		def file = new File(dataPath)
		def b64 = new Base64()
		String b64String = new String(b64.encode(file.readBytes()))
		StringBuilder imageXml = new StringBuilder("<image pos='${pos}' type='${imgType}' ><data>")
		imageXml.append(b64String)
		imageXml.append("</data></image>")
		return imageXml
    }

    def getAimSimpleImgXmlSetFullPath(String dataPath, def pos, def imgType, def width, def height) {
		def file = new File(dataPath)
		def b64 = new Base64()
		String b64String = new String(b64.encode(file.readBytes()))
		StringBuilder imageXml = new StringBuilder("<image pos='${pos}' type='${imgType}' width='${width}' height='${height}'><data>")
		imageXml.append(b64String)
		imageXml.append("</data></image>")
		return imageXml
    }
}

