package test.degrade.testitem.helper

import static test.common.constants.aim.AIMXmlAttribute.*

class LliHelper extends ConsolidationHelper {

	private static final String OPTION_EXT_ID = "option"
	
	private static final String GEN_M_EXT_ID = "M"
	private static final String GEN_F_EXT_ID = "F"
	private static final String GEN_U_EXT_ID = "U"

	private static final String YOB_1_EXT_ID = "1979_-1"
	private static final String YOB_2_EXT_ID = "1979_0"
	private static final String YOB_3_EXT_ID = "1979_1"
	private static final String YOB_4_EXT_ID = "1979_5"
	private static final String YOB_5_EXT_ID = "1979_9"
	private static final String YOB_6_EXT_ID = "1973_0"
	private static final String YOB_7_EXT_ID = "1974_0"
	private static final String YOB_8_EXT_ID = "1984_0"
	private static final String YOB_9_EXT_ID = "1985_0"
	private static final String YOB_10_EXT_ID = "1974_5"
	private static final String YOB_11_EXT_ID = "1984_5"
	private static final String YOB_12_EXT_ID = "-1_0"
	
	private static final String PATTERN_A_EXT_ID = "A"
	private static final String PATTERN_W_EXT_ID = "W"
	private static final String PATTERN_L_EXT_ID = "L"
	private static final String PATTERN_R_EXT_ID = "R"
	private static final String PATTERN_S_EXT_ID = "S"
	private static final String PATTERN_AW_EXT_ID = "AW"
	private static final String PATTERN_AL_EXT_ID = "AL"
	private static final String PATTERN_AR_EXT_ID = "AR"
	private static final String PATTERN_WL_EXT_ID = "WL"
	private static final String PATTERN_WR_EXT_ID = "WR"
	private static final String PATTERN_LR_EXT_ID = "LR"
	private static final String PATTERN_LRA_EXT_ID = "LRA"
	private static final String PATTERN_AWR_EXT_ID = "AWR"
	private static final String PATTERN_WLR_EXT_ID = "WLR"
	private static final String PATTERN_AWL_EXT_ID = "AWL"
	private static final String PATTERN_AWLR_EXT_ID = "AWLR"
	
	private static final String FIN_NO_0_EXT_ID = "0"
	private static final String FIN_NO_1_EXT_ID = "1"
	private static final String FIN_NO_2_EXT_ID = "2"
	private static final String FIN_NO_3_EXT_ID = "3"
	private static final String FIN_NO_4_EXT_ID = "4"
	private static final String FIN_NO_5_EXT_ID = "5"
	private static final String FIN_NO_6_EXT_ID = "6"
	private static final String FIN_NO_7_EXT_ID = "7"
	private static final String FIN_NO_8_EXT_ID = "8"
	private static final String FIN_NO_9_EXT_ID = "9"
	private static final String FIN_NO_012_EXT_ID = "012"
	private static final String FIN_NO_234_EXT_ID = "234"
	private static final String FIN_NO_456_EXT_ID = "456"
	
	private static final String ADJ_1_EXT_ID = "P_W_R_AST"
	private static final String ADJ_2_EXT_ID = "P_L_R_W"
	private static final String ADJ_3_EXT_ID = "P_R_R_A"
	
	private static final String RACE_1_EXT_ID = "1"
	private static final String RACE_2_EXT_ID = "2"
	private static final String RACE_4_EXT_ID = "4"
	private static final String RACE_8_EXT_ID = "8"
	private static final String RACE_M1_EXT_ID = "-1"
	
	private static final String REGION_1_EXT_ID = "1"
	private static final String REGION_9_EXT_ID = "9"
	private static final String REGION_F_EXT_ID = "F"
	private static final String REGION_U_EXT_ID = "U"
	
	private static final String COLD_1_EXT_ID = "M_1960"
	private static final String COLD_2_EXT_ID = "M_1970"
	private static final String COLD_3_EXT_ID = "M_1980"
	private static final String COLD_4_EXT_ID = "F_1960"
	private static final String COLD_5_EXT_ID = "F_1970"
	private static final String COLD_6_EXT_ID = "F_1980"
	private static final String COLD_7_EXT_ID = "U_1960"
	private static final String COLD_8_EXT_ID = "U_1970"
	private static final String COLD_9_EXT_ID = "U_1980"
	
	private static final String SCOPE_1_EXT_ID = "1"
	private static final String SCOPE_2_EXT_ID = "2"
	private static final String SCOPE_3_EXT_ID = "3"
	
	private static final String EXT_ID_TEST_A_EXT_ID = "A"
	private static final String EXT_ID_TEST_B_EXT_ID = "B"
	private static final String EXT_ID_TEST_C_EXT_ID = "C"
	private static final String EXT_ID_TEST_D_EXT_ID = "D"
	private static final String EXT_ID_TEST_E_EXT_ID = "E"
	private static final String EXT_ID_TEST_F_EXT_ID = "F"
	
	private static final String MULTI_AXIS_1_EXT_ID = "Multi_1"
	private static final String MULTI_AXIS_2_EXT_ID = "Multi_2"
	
	private static final int BASE_SCORE = 1130
	private static final int FULL_SCORE = 9999
	private static final int OPTION_SCORE_1 = 3011
	private static final int OPTION_SCORE_2 = 689
	private static final int MULTI_AXIS_1_A_SCORE = 2757
	private static final int MULTI_AXIS_1_B_SCORE = 2398
	private static final int MULTI_AXIS_1_C_SCORE = 1391
	private static final int MULTI_AXIS_1_D_SCORE = 2829
	private static final int MULTI_AXIS_2_A_SCORE = 2652
	private static final int MULTI_AXIS_2_B_SCORE = 2272
	private static final int MULTI_AXIS_2_C_SCORE = 2730
	private static final int MULTI_AXIS_2_D_SCORE = 1548
	
	private static final int SCOPE_1_BIN_ID = 321
	private static final int SCOPE_2_BIN_ID = SCOPE_1_BIN_ID + 1000
	private static final int SCOPE_3_BIN_ID = SCOPE_1_BIN_ID + 2000

	private int fW120Score
	private Integer fW100 = 100
	private Integer fW120 = 120
	private Integer fmp5FW = 100
    private Integer pc2FW = 200
	private int reqIndex = 0
	
	private List OPTION_CAND_INFO_LIST_1 = []
	private List OPTION_CAND_INFO_LIST_2 = []
	private List OPTION_CAND_INFO_LIST_3 = []
	
	private List GEN_M_CAND_INFO_LIST = []
	private List GEN_F_CAND_INFO_LIST = []
	private List GEN_U_CAND_INFO_LIST = []

	private List YOB_1_CAND_INFO_LIST = []
	private List YOB_2_CAND_INFO_LIST = []
	private List YOB_3_CAND_INFO_LIST = []
	private List YOB_4_CAND_INFO_LIST = []
	private List YOB_5_CAND_INFO_LIST = []
	private List YOB_6_CAND_INFO_LIST = []
	private List YOB_7_CAND_INFO_LIST = []
	private List YOB_8_CAND_INFO_LIST = []
	private List YOB_9_CAND_INFO_LIST = []
	private List YOB_10_CAND_INFO_LIST = []
	private List YOB_11_CAND_INFO_LIST = []
	private List YOB_12_CAND_INFO_LIST = []
	
	private List PATTERN_A_CAND_INFO_LIST = []
	private List PATTERN_W_CAND_INFO_LIST = []
	private List PATTERN_L_CAND_INFO_LIST = []
	private List PATTERN_R_CAND_INFO_LIST = []
	private List PATTERN_S_CAND_INFO_LIST = []
	private List PATTERN_AW_CAND_INFO_LIST = []
	private List PATTERN_AL_CAND_INFO_LIST = []
	private List PATTERN_AR_CAND_INFO_LIST = []
	private List PATTERN_WL_CAND_INFO_LIST = []
	private List PATTERN_WR_CAND_INFO_LIST = []
	private List PATTERN_LR_CAND_INFO_LIST = []
	private List PATTERN_LRA_CAND_INFO_LIST = []
	private List PATTERN_AWR_CAND_INFO_LIST = []
	private List PATTERN_WLR_CAND_INFO_LIST = []
	private List PATTERN_AWL_CAND_INFO_LIST = []
	private List PATTERN_AWLR_CAND_INFO_LIST = []
	
	private List FIN_NO_0_CAND_INFO_LIST = []
	private List FIN_NO_1_CAND_INFO_LIST = []
	private List FIN_NO_2_CAND_INFO_LIST = []
	private List FIN_NO_3_CAND_INFO_LIST = []
	private List FIN_NO_4_CAND_INFO_LIST = []
	private List FIN_NO_5_CAND_INFO_LIST = []
	private List FIN_NO_6_CAND_INFO_LIST = []
	private List FIN_NO_7_CAND_INFO_LIST = []
	private List FIN_NO_8_CAND_INFO_LIST = []
	private List FIN_NO_9_CAND_INFO_LIST = []
	private List FIN_NO_012_CAND_INFO_LIST = []
	private List FIN_NO_234_CAND_INFO_LIST = []
	private List FIN_NO_456_CAND_INFO_LIST = []
	
	private List ADJ_1_CAND_INFO_LIST = []
	private List ADJ_2_CAND_INFO_LIST = []
	private List ADJ_3_CAND_INFO_LIST = []
	
	private List RACE_1_CAND_INFO_LIST = []
	private List RACE_2_CAND_INFO_LIST = []
	private List RACE_4_CAND_INFO_LIST = []
	private List RACE_8_CAND_INFO_LIST = []
	private List RACE_M1_CAND_INFO_LIST = []
	
	private List REGION_1_CAND_INFO_LIST = []
	private List REGION_9_CAND_INFO_LIST = []
	private List REGION_F_CAND_INFO_LIST = []
	private List REGION_U_CAND_INFO_LIST = []
	
	private List COLD_1_CAND_INFO_LIST = []
	private List COLD_2_CAND_INFO_LIST = []
	private List COLD_3_CAND_INFO_LIST = []
	private List COLD_4_CAND_INFO_LIST = []
	private List COLD_5_CAND_INFO_LIST = []
	private List COLD_6_CAND_INFO_LIST = []
	private List COLD_7_CAND_INFO_LIST = []
	private List COLD_8_CAND_INFO_LIST = []
	private List COLD_9_CAND_INFO_LIST = []
	
	private List SCOPE_1_CAND_INFO_LIST = []
	private List SCOPE_2_CAND_INFO_LIST = []
	private List SCOPE_3_CAND_INFO_LIST = []
	
	private List FW_100_CAND_INFO_LIST = []
	private List FW_120_CAND_INFO_LIST = []
	
	private List EXT_ID_TEST_A_CAND_INFO_LIST = []
	private List EXT_ID_TEST_B_CAND_INFO_LIST = []
	private List EXT_ID_TEST_C_CAND_INFO_LIST = []
	private List EXT_ID_TEST_D_CAND_INFO_LIST = []
	private List EXT_ID_TEST_E_CAND_INFO_LIST = []
	private List EXT_ID_TEST_F_CAND_INFO_LIST = []
	
	private List MULTI_AXIS_1_A_CAND_INFO_LIST = []
	private List MULTI_AXIS_1_B_CAND_INFO_LIST = []
	private List MULTI_AXIS_1_C_CAND_INFO_LIST_1 = []
	private List MULTI_AXIS_1_C_CAND_INFO_LIST_2 = []
	private List MULTI_AXIS_1_D_CAND_INFO_LIST = []
	private List MULTI_AXIS_2_A_CAND_INFO_LIST = []
	private List MULTI_AXIS_2_B_CAND_INFO_LIST = []
	private List MULTI_AXIS_2_C_CAND_INFO_LIST = []
	private List MULTI_AXIS_2_D_CAND_INFO_LIST = []
	
	LliHelper(context){
		super(context)
		initCandInfoLists()
	}

	LliHelper(context, String level){
		super(context)
		setNullFwIfHighLevel(level)
		initCandInfoLists()
	}

	private void initCandInfoLists() {
		initScores()
		initGenderCandInfoList()
		initYobCandInfoList()
		initPatternCandInfoList()
		initFingerNoCandInfoList()
		initAdjacentCandInfoList()
		initRaceCandInfoList()
		initRegionCandInfoList()
		initColdCandInfoList()
		initScopeCandInfoList()
		initFusionWeightCandInfoList()
		initExternalIdCandInfoList()
		initMultiAxisCandInfoList()
		initOptionCandInfoList()
	}

	private void initScores() {
		fW120Score = mergeFWeight(BASE_SCORE, fW120)
	}

	private void initOptionCandInfoList(){
		OPTION_CAND_INFO_LIST_1 =
			[ OPTION_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
		
		OPTION_CAND_INFO_LIST_2 =
			[ OPTION_EXT_ID, OPTION_SCORE_1, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, OPTION_SCORE_1,
					[ [ OPTION_SCORE_1, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
		
		OPTION_CAND_INFO_LIST_3 =
			[ OPTION_EXT_ID, OPTION_SCORE_2, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, OPTION_SCORE_2,
					[ [ OPTION_SCORE_2, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	}

	private void initGenderCandInfoList(){
		GEN_M_CAND_INFO_LIST =
			[ GEN_M_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
		
		GEN_F_CAND_INFO_LIST =
			[ GEN_F_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
		
		GEN_U_CAND_INFO_LIST =
			[ GEN_U_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	}

	private void initYobCandInfoList(){
		YOB_1_CAND_INFO_LIST =
			[ YOB_1_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		YOB_2_CAND_INFO_LIST =
			[ YOB_2_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		YOB_3_CAND_INFO_LIST =
			[ YOB_3_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		YOB_4_CAND_INFO_LIST =
			[ YOB_4_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		YOB_5_CAND_INFO_LIST =
			[ YOB_5_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		YOB_6_CAND_INFO_LIST =
			[ YOB_6_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		YOB_7_CAND_INFO_LIST =
			[ YOB_7_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		YOB_8_CAND_INFO_LIST =
			[ YOB_8_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		YOB_9_CAND_INFO_LIST =
			[ YOB_9_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		YOB_10_CAND_INFO_LIST =
			[ YOB_10_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		YOB_11_CAND_INFO_LIST =
			[ YOB_11_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		YOB_12_CAND_INFO_LIST =
			[ YOB_12_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	}
	
	private void initPatternCandInfoList(){
		PATTERN_A_CAND_INFO_LIST =
			[ PATTERN_A_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		PATTERN_W_CAND_INFO_LIST =
			[ PATTERN_W_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		PATTERN_L_CAND_INFO_LIST =
			[ PATTERN_L_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		PATTERN_R_CAND_INFO_LIST =
			[ PATTERN_R_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]

		PATTERN_S_CAND_INFO_LIST =
			[ PATTERN_S_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		PATTERN_AW_CAND_INFO_LIST =
			[ PATTERN_AW_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		PATTERN_AL_CAND_INFO_LIST =
			[ PATTERN_AL_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		PATTERN_AR_CAND_INFO_LIST =
			[ PATTERN_AR_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		PATTERN_WL_CAND_INFO_LIST =
			[ PATTERN_WL_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]

		PATTERN_WR_CAND_INFO_LIST =
			[ PATTERN_WR_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]

		PATTERN_LR_CAND_INFO_LIST =
			[ PATTERN_LR_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		PATTERN_LRA_CAND_INFO_LIST =
			[ PATTERN_LRA_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		PATTERN_AWR_CAND_INFO_LIST =
			[ PATTERN_AWR_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		PATTERN_WLR_CAND_INFO_LIST =
			[ PATTERN_WLR_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		PATTERN_AWL_CAND_INFO_LIST =
			[ PATTERN_AWL_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
		
		PATTERN_AWLR_CAND_INFO_LIST =
			[ PATTERN_AWLR_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	}

	private void initFingerNoCandInfoList(){
		FIN_NO_0_CAND_INFO_LIST =
			[ FIN_NO_0_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		FIN_NO_1_CAND_INFO_LIST =
			[ FIN_NO_1_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		FIN_NO_2_CAND_INFO_LIST =
			[ FIN_NO_2_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		FIN_NO_3_CAND_INFO_LIST =
			[ FIN_NO_3_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]

		FIN_NO_4_CAND_INFO_LIST =
			[ FIN_NO_4_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		FIN_NO_5_CAND_INFO_LIST =
			[ FIN_NO_5_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		FIN_NO_6_CAND_INFO_LIST =
			[ FIN_NO_6_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		FIN_NO_7_CAND_INFO_LIST =
			[ FIN_NO_7_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		FIN_NO_8_CAND_INFO_LIST =
			[ FIN_NO_8_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]

		FIN_NO_9_CAND_INFO_LIST =
			[ FIN_NO_9_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]

		FIN_NO_012_CAND_INFO_LIST =
			[ FIN_NO_012_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		FIN_NO_234_CAND_INFO_LIST =
			[ FIN_NO_234_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		FIN_NO_456_CAND_INFO_LIST =
			[ FIN_NO_456_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
	}

	private void initAdjacentCandInfoList(){
		ADJ_1_CAND_INFO_LIST =
			[ ADJ_1_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		ADJ_2_CAND_INFO_LIST =
			[ ADJ_2_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		ADJ_3_CAND_INFO_LIST =
			[ ADJ_3_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	}	

	private void initRaceCandInfoList(){
		RACE_1_CAND_INFO_LIST =
			[ RACE_1_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		RACE_2_CAND_INFO_LIST =
			[ RACE_2_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		RACE_4_CAND_INFO_LIST =
			[ RACE_4_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
		
		RACE_8_CAND_INFO_LIST =
			[ RACE_8_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]

		RACE_M1_CAND_INFO_LIST =
			[ RACE_M1_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	}
	
	private void initRegionCandInfoList(){
		REGION_1_CAND_INFO_LIST =
			[ REGION_1_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		REGION_9_CAND_INFO_LIST =
			[ REGION_9_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		REGION_F_CAND_INFO_LIST =
			[ REGION_F_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
		
		REGION_U_CAND_INFO_LIST =
			[ REGION_U_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	}
	
	private void initColdCandInfoList(){
		COLD_1_CAND_INFO_LIST =
			[ COLD_1_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		COLD_2_CAND_INFO_LIST =
			[ COLD_2_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		COLD_3_CAND_INFO_LIST =
			[ COLD_3_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
		
		COLD_4_CAND_INFO_LIST =
			[ COLD_4_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
		
		COLD_5_CAND_INFO_LIST =
			[ COLD_5_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]

		COLD_6_CAND_INFO_LIST =
			[ COLD_6_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]

		COLD_7_CAND_INFO_LIST =
			[ COLD_7_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]

		COLD_8_CAND_INFO_LIST =
			[ COLD_8_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]

		COLD_9_CAND_INFO_LIST =
			[ COLD_9_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]

	}

	private void initScopeCandInfoList(){
		SCOPE_1_CAND_INFO_LIST =
			[ SCOPE_1_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		SCOPE_2_CAND_INFO_LIST =
			[ SCOPE_2_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_2_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	
		SCOPE_3_CAND_INFO_LIST =
			[ SCOPE_3_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_3_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	}

	private void initFusionWeightCandInfoList(){
		FW_100_CAND_INFO_LIST =
			[ SCOPE_1_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, fW100 ] ] ] ]
			]

		FW_120_CAND_INFO_LIST =
			[ SCOPE_1_EXT_ID, fW120Score, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, fW120Score,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, fW120 ] ] ] ]
			]
	}

	private void initExternalIdCandInfoList(){
		EXT_ID_TEST_A_CAND_INFO_LIST =
			[ EXT_ID_TEST_A_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]

		EXT_ID_TEST_B_CAND_INFO_LIST =
			[ EXT_ID_TEST_B_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]

		EXT_ID_TEST_C_CAND_INFO_LIST =
			[ EXT_ID_TEST_C_EXT_ID, BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, BASE_SCORE,
					[ [ BASE_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]

		EXT_ID_TEST_D_CAND_INFO_LIST =
			[ EXT_ID_TEST_D_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]

		EXT_ID_TEST_E_CAND_INFO_LIST =
			[ EXT_ID_TEST_E_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]

		EXT_ID_TEST_F_CAND_INFO_LIST =
			[ EXT_ID_TEST_F_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]
	}

	private void initMultiAxisCandInfoList(){
		MULTI_AXIS_1_A_CAND_INFO_LIST =
			[ MULTI_AXIS_1_EXT_ID, MULTI_AXIS_1_A_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, MULTI_AXIS_1_A_SCORE,
					[ [ MULTI_AXIS_1_A_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]

		MULTI_AXIS_1_B_CAND_INFO_LIST =
			[ MULTI_AXIS_1_EXT_ID, MULTI_AXIS_1_B_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, MULTI_AXIS_1_B_SCORE,
					[ [ MULTI_AXIS_1_B_SCORE, FIN_1, B, FMP5_LATENT, 100 ] ] ] ]
			]

		MULTI_AXIS_1_C_CAND_INFO_LIST_1 =
			[ MULTI_AXIS_1_EXT_ID, MULTI_AXIS_1_C_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, MULTI_AXIS_1_C_SCORE,
					[ [ MULTI_AXIS_1_C_SCORE, FIN_1, C, FMP5_LATENT, 100 ] ] ] ]
			]

		MULTI_AXIS_1_C_CAND_INFO_LIST_2 =
			[ MULTI_AXIS_1_EXT_ID, MULTI_AXIS_1_D_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, MULTI_AXIS_1_D_SCORE,
					[ [ MULTI_AXIS_1_D_SCORE, FIN_1, C, FMP5_LATENT, 100 ] ] ] ]
			]

		MULTI_AXIS_1_D_CAND_INFO_LIST =
			[ MULTI_AXIS_1_EXT_ID, MULTI_AXIS_1_D_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, MULTI_AXIS_1_D_SCORE,
					[ [ MULTI_AXIS_1_D_SCORE, FIN_1, D, FMP5_LATENT, 100 ] ] ] ]
			]

		MULTI_AXIS_2_A_CAND_INFO_LIST =
			[ MULTI_AXIS_2_EXT_ID, MULTI_AXIS_2_A_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, MULTI_AXIS_2_A_SCORE,
					[ [ MULTI_AXIS_2_A_SCORE, FIN_1, A, FMP5_LATENT, 100 ] ] ] ]
			]

		MULTI_AXIS_2_B_CAND_INFO_LIST =
			[ MULTI_AXIS_2_EXT_ID, MULTI_AXIS_2_B_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, MULTI_AXIS_2_B_SCORE,
					[ [ MULTI_AXIS_2_B_SCORE, FIN_1, B, FMP5_LATENT, 100 ] ] ] ]
			]

		MULTI_AXIS_2_C_CAND_INFO_LIST =
			[ MULTI_AXIS_2_EXT_ID, MULTI_AXIS_2_C_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, MULTI_AXIS_2_C_SCORE,
					[ [ MULTI_AXIS_2_C_SCORE, FIN_1, C, FMP5_LATENT, 100 ] ] ] ]
			]

		MULTI_AXIS_2_D_CAND_INFO_LIST =
			[ MULTI_AXIS_2_EXT_ID, MULTI_AXIS_2_D_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, MULTI_AXIS_2_D_SCORE,
					[ [ MULTI_AXIS_2_D_SCORE, FIN_1, D, FMP5_LATENT, 100 ] ] ] ]
			]
	}
	
	public List getCandList_Option_1(){
		return [ OPTION_CAND_INFO_LIST_1 ] 
	}

	public List getCandList_Option_2(){
		return [ OPTION_CAND_INFO_LIST_2 ] 
	}

	public List getCandList_Option_3(){
		return [ OPTION_CAND_INFO_LIST_3 ] 
	}

	public List getCandList_Gender_M_Only(){
		return [ GEN_M_CAND_INFO_LIST ] 
	}

	public List getCandList_Gender_M(){
		return [ GEN_M_CAND_INFO_LIST,  GEN_U_CAND_INFO_LIST ] 
	}

	public List getCandList_Gender_F(){
		return [ GEN_F_CAND_INFO_LIST, GEN_U_CAND_INFO_LIST ] 
	}
	
	public List getCandList_Gender_U(){
		return [ GEN_M_CAND_INFO_LIST, GEN_F_CAND_INFO_LIST, GEN_U_CAND_INFO_LIST ] 
	}

	public List getCandList_Yob_All(){
		return [ YOB_1_CAND_INFO_LIST, YOB_2_CAND_INFO_LIST, YOB_3_CAND_INFO_LIST,
				 YOB_4_CAND_INFO_LIST, YOB_5_CAND_INFO_LIST, YOB_6_CAND_INFO_LIST,
				 YOB_7_CAND_INFO_LIST, YOB_8_CAND_INFO_LIST, YOB_9_CAND_INFO_LIST,
				 YOB_10_CAND_INFO_LIST, YOB_11_CAND_INFO_LIST, YOB_12_CAND_INFO_LIST ] 
	}

	public List getCandList_Yob_10(){
		return [ YOB_1_CAND_INFO_LIST, YOB_2_CAND_INFO_LIST, YOB_3_CAND_INFO_LIST,
				 YOB_4_CAND_INFO_LIST, YOB_5_CAND_INFO_LIST, YOB_7_CAND_INFO_LIST,
				 YOB_8_CAND_INFO_LIST, YOB_10_CAND_INFO_LIST, YOB_11_CAND_INFO_LIST,
				 YOB_12_CAND_INFO_LIST ] 
	}

	public List getCandList_Yob_9(){
		return [ YOB_1_CAND_INFO_LIST, YOB_2_CAND_INFO_LIST, YOB_3_CAND_INFO_LIST,
				 YOB_4_CAND_INFO_LIST, YOB_5_CAND_INFO_LIST, YOB_8_CAND_INFO_LIST, 
				 YOB_9_CAND_INFO_LIST, YOB_11_CAND_INFO_LIST, YOB_12_CAND_INFO_LIST ] 
	}

	public List getCandList_Pattern_All(){
		return [ PATTERN_A_CAND_INFO_LIST, PATTERN_W_CAND_INFO_LIST, PATTERN_L_CAND_INFO_LIST,
				 PATTERN_R_CAND_INFO_LIST, PATTERN_S_CAND_INFO_LIST, PATTERN_AW_CAND_INFO_LIST,
				 PATTERN_AL_CAND_INFO_LIST, PATTERN_AR_CAND_INFO_LIST, PATTERN_WL_CAND_INFO_LIST,
				 PATTERN_WR_CAND_INFO_LIST, PATTERN_LR_CAND_INFO_LIST, PATTERN_LRA_CAND_INFO_LIST,
				 PATTERN_AWR_CAND_INFO_LIST, PATTERN_WLR_CAND_INFO_LIST, PATTERN_AWL_CAND_INFO_LIST,
				 PATTERN_AWLR_CAND_INFO_LIST ] 
	}

	public List getCandList_Pattern_13(){
		return [  PATTERN_L_CAND_INFO_LIST, PATTERN_R_CAND_INFO_LIST, PATTERN_S_CAND_INFO_LIST, 
				 PATTERN_AL_CAND_INFO_LIST, PATTERN_AR_CAND_INFO_LIST, PATTERN_WL_CAND_INFO_LIST,
				 PATTERN_WR_CAND_INFO_LIST, PATTERN_LR_CAND_INFO_LIST, PATTERN_LRA_CAND_INFO_LIST,
				 PATTERN_AWR_CAND_INFO_LIST, PATTERN_WLR_CAND_INFO_LIST, PATTERN_AWL_CAND_INFO_LIST,
				 PATTERN_AWLR_CAND_INFO_LIST ] 
	}

	public List getCandList_Pattern_9_Type_1(){
		return [ PATTERN_A_CAND_INFO_LIST, PATTERN_S_CAND_INFO_LIST, PATTERN_AW_CAND_INFO_LIST,
				 PATTERN_AL_CAND_INFO_LIST, PATTERN_AR_CAND_INFO_LIST,  PATTERN_LRA_CAND_INFO_LIST,
				 PATTERN_AWR_CAND_INFO_LIST ,PATTERN_AWL_CAND_INFO_LIST, PATTERN_AWLR_CAND_INFO_LIST ] 
	}

	public List getCandList_Pattern_9_Type_2(){
		return [ PATTERN_L_CAND_INFO_LIST,PATTERN_S_CAND_INFO_LIST, PATTERN_AL_CAND_INFO_LIST,
				 PATTERN_WL_CAND_INFO_LIST, PATTERN_LR_CAND_INFO_LIST, PATTERN_LRA_CAND_INFO_LIST,
				 PATTERN_WLR_CAND_INFO_LIST,PATTERN_AWL_CAND_INFO_LIST,PATTERN_AWLR_CAND_INFO_LIST ] 
	}

	public List getCandList_FingerNo_All(){
		return [ FIN_NO_0_CAND_INFO_LIST, FIN_NO_1_CAND_INFO_LIST, FIN_NO_2_CAND_INFO_LIST,
				 FIN_NO_3_CAND_INFO_LIST, FIN_NO_4_CAND_INFO_LIST, FIN_NO_5_CAND_INFO_LIST,
				 FIN_NO_6_CAND_INFO_LIST, FIN_NO_7_CAND_INFO_LIST, FIN_NO_8_CAND_INFO_LIST,
				 FIN_NO_9_CAND_INFO_LIST, FIN_NO_012_CAND_INFO_LIST, FIN_NO_234_CAND_INFO_LIST,
				 FIN_NO_456_CAND_INFO_LIST ] 
	}
	
	public List getCandList_FingerNo_1(){
		return [ FIN_NO_1_CAND_INFO_LIST, FIN_NO_012_CAND_INFO_LIST ]
	}

	public List getCandList_FingerNo_9(){
		return [ FIN_NO_9_CAND_INFO_LIST ]
	}

	public List getCandList_FingerNo_123(){
		return [ FIN_NO_1_CAND_INFO_LIST, FIN_NO_2_CAND_INFO_LIST, FIN_NO_3_CAND_INFO_LIST,
				 FIN_NO_012_CAND_INFO_LIST, FIN_NO_234_CAND_INFO_LIST ]
	}

	public List getCandList_Adjacent_All(){
		return [ ADJ_1_CAND_INFO_LIST, ADJ_2_CAND_INFO_LIST, ADJ_3_CAND_INFO_LIST ]
	}

	public List getCandList_Adjacent_1(){
		return [ ADJ_2_CAND_INFO_LIST ]
	}

	public List getCandList_Adjacent_2(){
		return [ ADJ_1_CAND_INFO_LIST, ADJ_2_CAND_INFO_LIST ]
	}

	public List getCandList_Race_All(){
		return [ RACE_1_CAND_INFO_LIST, RACE_2_CAND_INFO_LIST, RACE_4_CAND_INFO_LIST,
				 RACE_8_CAND_INFO_LIST, RACE_1_CAND_INFO_LIST ]
	}

	public List getCandList_Race_2(){
		return [ RACE_2_CAND_INFO_LIST, RACE_M1_CAND_INFO_LIST ]
	}

	public List getCandList_Race_4(){
		return [ RACE_4_CAND_INFO_LIST, RACE_M1_CAND_INFO_LIST ]
	}

	public List getCandList_Region_All(){
		return [ REGION_1_CAND_INFO_LIST, REGION_9_CAND_INFO_LIST, REGION_F_CAND_INFO_LIST,
				 REGION_U_CAND_INFO_LIST ]
	}

	public List getCandList_Region_1(){
		return [ REGION_1_CAND_INFO_LIST, REGION_U_CAND_INFO_LIST ]
	}

	public List getCandList_ColdSearch_All(){
		return [ COLD_1_CAND_INFO_LIST, COLD_2_CAND_INFO_LIST, COLD_3_CAND_INFO_LIST,
				 COLD_4_CAND_INFO_LIST, COLD_5_CAND_INFO_LIST, COLD_6_CAND_INFO_LIST,
				 COLD_7_CAND_INFO_LIST, COLD_8_CAND_INFO_LIST, COLD_9_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_1(){
		return [ SCOPE_1_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_2(){
		return [ SCOPE_2_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_3(){
		return [ SCOPE_3_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_1_2(){
		return [ SCOPE_1_CAND_INFO_LIST, SCOPE_2_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_1_3(){
		return [ SCOPE_1_CAND_INFO_LIST, SCOPE_3_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_1_2_3(){
		return [ SCOPE_1_CAND_INFO_LIST, SCOPE_2_CAND_INFO_LIST, SCOPE_3_CAND_INFO_LIST ]
	}

	public List getCandList_Fw_100(){
		return [ FW_100_CAND_INFO_LIST ]
	}

	public List getCandList_Fw_120(){
		return [ FW_120_CAND_INFO_LIST ]
	}

	public List getCandList_External_Id(){
		return [ EXT_ID_TEST_A_CAND_INFO_LIST, EXT_ID_TEST_B_CAND_INFO_LIST, EXT_ID_TEST_C_CAND_INFO_LIST,
				 EXT_ID_TEST_D_CAND_INFO_LIST, EXT_ID_TEST_E_CAND_INFO_LIST, EXT_ID_TEST_F_CAND_INFO_LIST ]
	}

	public List getCandList_MultiAxis_1(){
		return [ MULTI_AXIS_1_A_CAND_INFO_LIST, MULTI_AXIS_1_B_CAND_INFO_LIST, MULTI_AXIS_1_C_CAND_INFO_LIST_1,
				 MULTI_AXIS_1_D_CAND_INFO_LIST ]
	}

	public List getCandList_MultiAxis_2(){
		return [ MULTI_AXIS_1_A_CAND_INFO_LIST, MULTI_AXIS_1_B_CAND_INFO_LIST, MULTI_AXIS_1_C_CAND_INFO_LIST_2,
				 MULTI_AXIS_1_D_CAND_INFO_LIST ]
	}

	public List getCandList_MultiAxis_3(){
		return [ MULTI_AXIS_1_A_CAND_INFO_LIST, MULTI_AXIS_1_B_CAND_INFO_LIST, MULTI_AXIS_1_C_CAND_INFO_LIST_1,
				 MULTI_AXIS_1_D_CAND_INFO_LIST, MULTI_AXIS_2_A_CAND_INFO_LIST, MULTI_AXIS_2_B_CAND_INFO_LIST,
				 MULTI_AXIS_2_C_CAND_INFO_LIST, MULTI_AXIS_2_D_CAND_INFO_LIST ]
	}
	
	public List getCandList_MultiAxis_1_D(){
		return [ MULTI_AXIS_1_D_CAND_INFO_LIST ]
	}

	public List getCandList_MultiAxis_1_C_2(){
		return [ MULTI_AXIS_1_C_CAND_INFO_LIST_2 ]
	}
	
	public List getCandList_MultiAxis_1_D_2_C(){
		return [ MULTI_AXIS_1_D_CAND_INFO_LIST, MULTI_AXIS_2_C_CAND_INFO_LIST ]
	}

	private void setNullFwIfHighLevel(String level){
		if(level == "high") {
			this.fmp5FW = null
		}else{
			this.pc2FW = 200
		}
	}
}

