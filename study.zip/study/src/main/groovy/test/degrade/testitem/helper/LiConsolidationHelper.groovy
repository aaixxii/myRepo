package test.degrade.testitem.helper

import static test.common.constants.aim.AIMXmlAttribute.*

class LiConsolidationHelper extends ConsolidationHelper {

	private static final String F1_EXT_ID = "LI_F1A"
	private static final String F2_EXT_ID = "LI_F2A"
	private static final String F3_EXT_ID = "LI_F3A"
	private static final String F4_EXT_ID = "LI_F4A"
	private static final String F5_EXT_ID = "LI_F5A"
	private static final String F6_EXT_ID = "LI_F6A"
	private static final String F7_EXT_ID = "LI_F7A"
	private static final String F8_EXT_ID = "LI_F8A"
	private static final String F9_EXT_ID = "LI_F9A"
	private static final String F10_EXT_ID = "LI_F10A"
	private static final String F11_EXT_ID = "LI_F11A_PC2RS_FMP5RS"
	private static final String F12_EXT_ID = "LI_F12A"
	private static final String F13_EXT_ID = "LI_F13A"
	private static final String F14_EXT_ID = "LI_F14A"
	private static final String F15_EXT_ID = "LI_F15A"
	private static final String F_ABC_123_HIGH_EXT_ID = "LI-ABC-123-High"
	private static final String F_BBC_123_HIGH_EXT_ID = "LI-BBC-123-High"
	private static final String F_0BBC_123_HIGH_EXT_ID = "LI-0BBC-123-High"
	private static final String F_ABC_123_LOW_EXT_ID = "LI-ABC-123-Low"
	private static final String F_BBC_123_LOW_EXT_ID = "LI-BBC-123-Low"
	private static final String F_0BBC_123_LOW_EXT_ID = "LI-0BBC-123-Low"
	private static final int PC2_1_R_SCORE = 839
	private static final int PC2_1_S_SCORE = 1823
	private static final int PC2_6_R_SCORE = PC2_1_R_SCORE
	private static final int PC2_6_S_SCORE = PC2_1_S_SCORE
	private static final int PC2_10_S_SCORE = PC2_1_S_SCORE
	private static final int FMP5_1_R_SCORE = 739
	private static final int FMP5_1_A_R_SCORE = 748
	private static final int FMP5_1_C_R_SCORE = 994
	private static final int FMP5_1_D_R_SCORE = FMP5_1_C_R_SCORE
	private static final int FMP5_1_A_R_SCORE_F6 = 2107
	private static final int FMP5_1_B_R_SCORE_F6 = 2050
	private static final int FMP5_1_C_R_SCORE_F6 = 1922
	private static final int FMP5_1_D_R_SCORE_F6 = 1534
	private static final int FMP5_1_A_S_SCORE = 1928
	private static final int FMP5_1_C_S_SCORE = 2284
	private static final int FMP5_1_D_S_SCORE = FMP5_1_C_S_SCORE
	private static final int FMP5_1_A_S_SCORE_F6 = 987
	private static final int FMP5_1_B_S_SCORE_F6 = 629
	private static final int FMP5_1_C_S_SCORE_F6 = 794
	private static final int FMP5_1_D_S_SCORE_F6 = 661
	private static final int FMP5_1_A_R_SCORE_F15 = FMP5_1_A_S_SCORE_F6
	private static final int FMP5_1_B_R_SCORE_F15 = FMP5_1_B_S_SCORE_F6
	private static final int FMP5_1_C_R_SCORE_F15 = FMP5_1_C_S_SCORE_F6
	private static final int FMP5_1_D_R_SCORE_F15 = FMP5_1_D_S_SCORE_F6
	private static final int FMP5_1_A_S_SCORE_F15 = FMP5_1_A_R_SCORE_F6
	private static final int FMP5_1_B_S_SCORE_F15 = FMP5_1_B_R_SCORE_F6
	private static final int FMP5_1_C_S_SCORE_F15 = FMP5_1_C_R_SCORE_F6
	private static final int FMP5_1_D_S_SCORE_F15 = FMP5_1_D_R_SCORE_F6
	private static final int FMP5_1_R_SCORE_HIGH = 2016
	private static final int FMP5_2_R_SCORE = FMP5_1_R_SCORE
	private static final int FMP5_1_S_SCORE = FMP5_1_R_SCORE_HIGH
	private static final int FMP5_1_S_SCORE_2 = FMP5_1_R_SCORE
	private static final int FMP5_1_S_SCORE_LOW = 1938
	private static final int FMP5_2_S_SCORE = FMP5_1_S_SCORE
	private static final int FMP5_5_S_SCORE = FMP5_1_S_SCORE

	private Integer fmp5FW = 100
	private Integer pc2FW = 200
	private int fmp5ReqIndex = 0
	private int pc2ReqIndex = 0
	private int fmp5Score_R1F
	private int fmp5Score_R1F_High
	private int fmp5Score_R2F
	private int fmp5Score_S1F
	private int fmp5Score_S1F_2
	private int fmp5Score_S1F_Low
	private int fmp5Score_S2F
	private int fmp5Score_S5F
	private int pc2Score_R1F
	private int pc2Score_R6F
	private int pc2Score_S6F
	private int pc2Score_S1F
	private	int pc2Score_S10F
	private int fmp5_pc2_score_R1F_R1F
	private int fmp5_pc2_score_S1F_R1F
	private int fmp5_pc2_score_R1F_S1F
	private int fmp5_pc2_score_S1F_S1F
	private int fmp5_pc2_score_S1F_S1F_Low

	private List F1A_CAND_INFO_LIST_BY_PC2 = []
	private List F2A_CAND_INFO_LIST_BY_PC2 = []
	private List F3A_CAND_INFO_LIST_BY_FMP5 = []
	private List F3A_CAND_INFO_LIST_BY_FMP5_AXIS_A = []
	private List F3A_CAND_INFO_LIST_BY_FMP5_AXIS_C = []
	private List F3A_CAND_INFO_LIST_BY_FMP5_AXIS_D = []
	private List F4A_CAND_INFO_LIST_BY_FMP5 = []
	private List F4A_CAND_INFO_LIST_BY_FMP5_AXIS_A = []
	private List F4A_CAND_INFO_LIST_BY_FMP5_AXIS_C = []
	private List F4A_CAND_INFO_LIST_BY_FMP5_AXIS_D = []
	private List F5A_CAND_INFO_LIST_BY_PC2 = []
	private List F6A_CAND_INFO_LIST_BY_FMP5 = []
	private List F6A_CAND_INFO_LIST_BY_FMP5_AXIS_A = []
	private List F6A_CAND_INFO_LIST_BY_FMP5_AXIS_B = []
	private List F6A_CAND_INFO_LIST_BY_FMP5_AXIS_C = []
	private List F6A_CAND_INFO_LIST_BY_FMP5_AXIS_D = []
	private List F7A_CAND_INFO_LIST_BY_BOTH = []
	private List F8A_CAND_INFO_LIST_BY_BOTH = []
	private List F9A_CAND_INFO_LIST_BY_BOTH = []
	private List F10A_CAND_INFO_LIST_BY_BOTH = []
	private List F11A_CAND_INFO_LIST_BY_PC2 = []
	private List F11A_CAND_INFO_LIST_BY_PC2_6F = []
	private List F11A_CAND_INFO_LIST_BY_FMP5 = []
	private List F11A_CAND_INFO_LIST_BY_FMP5_2F = []
	private List F11A_CAND_INFO_LIST_BY_FMP5_5F = []
	private List F11A_CAND_INFO_LIST_BY_BOTH = []
	private List F11A_CAND_INFO_LIST_BY_BOTH_10F = []
	private List F12A_CAND_INFO_LIST_BY_PC2 = []
	private List F12A_CAND_INFO_LIST_BY_FMP5 = []
	private List F12A_CAND_INFO_LIST_BY_BOTH = []
	private List F13A_CAND_INFO_LIST_BY_PC2 = []
	private List F13A_CAND_INFO_LIST_BY_FMP5 = []
	private List F13A_CAND_INFO_LIST_BY_BOTH = []
	private List F14A_CAND_INFO_LIST_BY_BOTH = []
	private List F15A_CAND_INFO_LIST_BY_BOTH_AXIS_A = []
	private List F15A_CAND_INFO_LIST_BY_FMP5_AXIS_B = []
	private List F15A_CAND_INFO_LIST_BY_FMP5_AXIS_C = []
	private List F15A_CAND_INFO_LIST_BY_FMP5_AXIS_D = []

	private List F_ABC_123_HIGH_CAND_INFO_LIST = []
	private List F_BBC_123_HIGH_CAND_INFO_LIST = []
	private List F_0BBC_123_HIGH_CAND_INFO_LIST = []
	private List F_ABC_123_LOW_CAND_INFO_LIST = []
	private List F_BBC_123_LOW_CAND_INFO_LIST = []
	private List F_0BBC_123_LOW_CAND_INFO_LIST = []

	LiConsolidationHelper(context){
		super(context)
		initCandInfoLists()
	}

	LiConsolidationHelper(context, String level){
		super(context)
		initCandInfoLists()
	}

	private void initCandInfoLists() {
		initScores()
		initFmp5CandInfoLists()
		initPc2CandInfoLists()
		initBothCandInfoLists()
	}

	private void initScores() {
		fmp5Score_R1F = mergeFWeight(FMP5_1_R_SCORE, fmp5FW)
		fmp5Score_R2F = mergeFWeight(FMP5_2_R_SCORE, fmp5FW)
		fmp5Score_S1F = mergeFWeight(FMP5_1_S_SCORE, fmp5FW)
		fmp5Score_S2F = mergeFWeight(FMP5_2_S_SCORE, fmp5FW)
		fmp5Score_S5F = mergeFWeight(FMP5_5_S_SCORE, fmp5FW)
		fmp5Score_R1F_High = fmp5Score_S1F
		fmp5Score_S1F_2 = fmp5Score_R1F
		fmp5Score_S1F_Low = mergeFWeight(FMP5_1_S_SCORE_LOW, fmp5FW)
		pc2Score_R1F = mergeFWeight(PC2_1_R_SCORE, pc2FW)
		pc2Score_R6F = mergeFWeight(PC2_6_R_SCORE, pc2FW)
		pc2Score_S1F = mergeFWeight(PC2_1_S_SCORE, pc2FW)
		pc2Score_S6F = mergeFWeight(PC2_6_S_SCORE, pc2FW)
		pc2Score_S10F = mergeFWeight(PC2_10_S_SCORE, pc2FW)
		fmp5_pc2_score_R1F_R1F = cutoffScore(mergeFWeight(FMP5_1_R_SCORE, fmp5FW) + mergeFWeight(PC2_1_R_SCORE, pc2FW))
		fmp5_pc2_score_S1F_R1F = cutoffScore(mergeFWeight(FMP5_1_S_SCORE, fmp5FW) + mergeFWeight(PC2_1_R_SCORE, pc2FW))
		fmp5_pc2_score_R1F_S1F = cutoffScore(mergeFWeight(FMP5_1_R_SCORE, fmp5FW) + mergeFWeight(PC2_1_S_SCORE, pc2FW))
		fmp5_pc2_score_S1F_S1F = cutoffScore(mergeFWeight(FMP5_1_S_SCORE, fmp5FW) + mergeFWeight(PC2_1_S_SCORE, pc2FW))
		fmp5_pc2_score_S1F_S1F_Low = cutoffScore(fmp5Score_S1F_Low + mergeFWeight(PC2_1_S_SCORE, pc2FW))
	}


	private void initFmp5CandInfoLists() {
		F3A_CAND_INFO_LIST_BY_FMP5 = 
			[ F3_EXT_ID, fmp5Score_R1F, true, 
				[ [ 3, 1, fmp5ReqIndex, fmp5Score_R1F,
					[ [ FMP5_1_R_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ] ]
			]
		F3A_CAND_INFO_LIST_BY_FMP5_AXIS_A = 
			[ F3_EXT_ID, FMP5_1_A_R_SCORE, true, 
				[ [ 3, 1, fmp5ReqIndex, FMP5_1_A_R_SCORE,
					[ [ FMP5_1_A_R_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ] ]
			]
		F3A_CAND_INFO_LIST_BY_FMP5_AXIS_C = 
			[ F3_EXT_ID, FMP5_1_C_R_SCORE, true, 
				[ [ 3, 1, fmp5ReqIndex, FMP5_1_C_R_SCORE,
					[ [ FMP5_1_C_R_SCORE, FIN_1, C, FMP5_LATENT, fmp5FW ] ] ] ]
			]
		F3A_CAND_INFO_LIST_BY_FMP5_AXIS_D = 
			[ F3_EXT_ID, FMP5_1_D_R_SCORE, true, 
				[ [ 3, 1, fmp5ReqIndex, FMP5_1_D_R_SCORE,
					[ [ FMP5_1_D_R_SCORE, FIN_1, D, FMP5_LATENT, fmp5FW ] ] ] ]
			]
		F4A_CAND_INFO_LIST_BY_FMP5 = 
			[ F4_EXT_ID, fmp5Score_S1F, true, 
				[ [ 4, 1, fmp5ReqIndex, fmp5Score_S1F,
					[ [ FMP5_1_S_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ] ]
			]
		F4A_CAND_INFO_LIST_BY_FMP5_AXIS_A = 
			[ F4_EXT_ID, FMP5_1_A_S_SCORE, true, 
				[ [ 4, 1, fmp5ReqIndex, FMP5_1_A_S_SCORE,
					[ [ FMP5_1_A_S_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ] ]
			]
		F4A_CAND_INFO_LIST_BY_FMP5_AXIS_C = 
			[ F4_EXT_ID, FMP5_1_C_S_SCORE, true, 
				[ [ 4, 1, fmp5ReqIndex, FMP5_1_C_S_SCORE,
					[ [ FMP5_1_C_S_SCORE, FIN_1, C, FMP5_LATENT, fmp5FW ] ] ] ]
			]
		F4A_CAND_INFO_LIST_BY_FMP5_AXIS_D = 
			[ F4_EXT_ID, FMP5_1_D_S_SCORE, true, 
				[ [ 4, 1, fmp5ReqIndex, FMP5_1_D_S_SCORE,
					[ [ FMP5_1_D_S_SCORE, FIN_1, D, FMP5_LATENT, fmp5FW ] ] ] ]
			]
		F6A_CAND_INFO_LIST_BY_FMP5 = 
			[ F6_EXT_ID, fmp5Score_R1F_High, true, 
				[ [ 3, 1, fmp5ReqIndex, fmp5Score_R1F_High,
					[ [ FMP5_1_R_SCORE_HIGH, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 4, 1, fmp5ReqIndex, fmp5Score_S1F_2,
					[ [ FMP5_1_S_SCORE_2, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ] ]
			]
		F6A_CAND_INFO_LIST_BY_FMP5_AXIS_A = 
			[ F6_EXT_ID, FMP5_1_A_R_SCORE_F6, true, 
				[ [ 3, 1, fmp5ReqIndex, FMP5_1_A_R_SCORE_F6,
					[ [ FMP5_1_A_R_SCORE_F6, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 4, 1, fmp5ReqIndex, FMP5_1_A_S_SCORE_F6,
					[ [ FMP5_1_A_S_SCORE_F6, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ] ]
			]
		F6A_CAND_INFO_LIST_BY_FMP5_AXIS_B = 
			[ F6_EXT_ID, FMP5_1_B_R_SCORE_F6, true, 
				[ [ 3, 1, fmp5ReqIndex, FMP5_1_B_R_SCORE_F6,
					[ [ FMP5_1_B_R_SCORE_F6, FIN_1, B, FMP5_LATENT, fmp5FW ] ] ],
				  [ 4, 1, fmp5ReqIndex, FMP5_1_B_S_SCORE_F6,
					[ [ FMP5_1_B_S_SCORE_F6, FIN_1, B, FMP5_LATENT, fmp5FW ] ] ] ]
			]
		F6A_CAND_INFO_LIST_BY_FMP5_AXIS_C = 
			[ F6_EXT_ID, FMP5_1_C_R_SCORE_F6, true, 
				[ [ 3, 1, fmp5ReqIndex, FMP5_1_C_R_SCORE_F6,
					[ [ FMP5_1_C_R_SCORE_F6, FIN_1, C, FMP5_LATENT, fmp5FW ] ] ],
				  [ 4, 1, fmp5ReqIndex, FMP5_1_C_S_SCORE_F6,
					[ [ FMP5_1_C_S_SCORE_F6, FIN_1, C, FMP5_LATENT, fmp5FW ] ] ] ]
			]
		F6A_CAND_INFO_LIST_BY_FMP5_AXIS_D = 
			[ F6_EXT_ID, FMP5_1_D_R_SCORE_F6, true, 
				[ [ 3, 1, fmp5ReqIndex, FMP5_1_D_R_SCORE_F6,
					[ [ FMP5_1_D_R_SCORE_F6, FIN_1, D, FMP5_LATENT, fmp5FW ] ] ],
				  [ 4, 1, fmp5ReqIndex, FMP5_1_D_S_SCORE_F6,
					[ [ FMP5_1_D_S_SCORE_F6, FIN_1, D, FMP5_LATENT, fmp5FW ] ] ] ]
			]
		F11A_CAND_INFO_LIST_BY_FMP5 = 
			[ F11_EXT_ID, fmp5Score_S1F, true, 
				[ [ 3, 1, fmp5ReqIndex, fmp5Score_R1F,
					[ [ FMP5_1_R_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 4, 1, fmp5ReqIndex, fmp5Score_S1F,
					[ [ FMP5_1_S_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ] ]
			]
		F11A_CAND_INFO_LIST_BY_FMP5_2F = 
			[ F11_EXT_ID, fmp5Score_S2F, true, 
				[ [ 3, 1, fmp5ReqIndex, fmp5Score_R2F,
					[ [ FMP5_2_R_SCORE, FIN_2, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 4, 1, fmp5ReqIndex, fmp5Score_S2F,
					[ [ FMP5_2_S_SCORE, FIN_2, A, FMP5_LATENT, fmp5FW ] ] ] ]
			]
		F11A_CAND_INFO_LIST_BY_FMP5_5F = 
			[ F11_EXT_ID, fmp5Score_S5F, true, 
				[ [ 4, 1, fmp5ReqIndex, fmp5Score_S5F,
					[ [ FMP5_5_S_SCORE, FIN_5, A, FMP5_LATENT, fmp5FW ] ] ] ]
			]
		F12A_CAND_INFO_LIST_BY_FMP5 = 
			[ F12_EXT_ID, fmp5Score_S1F, true, 
				[ [ 3, 3, fmp5ReqIndex, fmp5Score_R1F,
					[ [ FMP5_1_R_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 4, 3, fmp5ReqIndex, fmp5Score_S1F,
					[ [ FMP5_1_S_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 3, 4, fmp5ReqIndex, fmp5Score_R1F,
					[ [ FMP5_1_R_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 4, 4, fmp5ReqIndex, fmp5Score_S1F,
					[ [ FMP5_1_S_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ] ]
			]
		F13A_CAND_INFO_LIST_BY_FMP5 = 
			[ F13_EXT_ID, fmp5Score_S1F, true, 
				[ [ 2003, 1, fmp5ReqIndex, fmp5Score_R1F,
					[ [ FMP5_1_R_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 2004, 1, fmp5ReqIndex, fmp5Score_S1F,
					[ [ FMP5_1_S_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 5003, 1, fmp5ReqIndex, fmp5Score_R1F,
					[ [ FMP5_1_R_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 5004, 1, fmp5ReqIndex, fmp5Score_S1F,
					[ [ FMP5_1_S_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ] ]
			]
		F15A_CAND_INFO_LIST_BY_FMP5_AXIS_B = 
			[ F15_EXT_ID, FMP5_1_B_S_SCORE_F15, true, 
				[ [ 3, 1, fmp5ReqIndex, FMP5_1_B_R_SCORE_F15,
					[ [ FMP5_1_B_R_SCORE_F15, FIN_1, B, FMP5_LATENT, fmp5FW ] ] ],
				  [ 4, 1, fmp5ReqIndex, FMP5_1_B_S_SCORE_F15,
					[ [ FMP5_1_B_S_SCORE_F15, FIN_1, B, FMP5_LATENT, fmp5FW ] ] ] ]
			]
		F15A_CAND_INFO_LIST_BY_FMP5_AXIS_C = 
			[ F15_EXT_ID, FMP5_1_C_S_SCORE_F15, true, 
				[ [ 3, 1, fmp5ReqIndex, FMP5_1_C_R_SCORE_F15,
					[ [ FMP5_1_C_R_SCORE_F15, FIN_1, C, FMP5_LATENT, fmp5FW ] ] ],
				  [ 4, 1, fmp5ReqIndex, FMP5_1_C_S_SCORE_F15,
					[ [ FMP5_1_C_S_SCORE_F15, FIN_1, C, FMP5_LATENT, fmp5FW ] ] ] ]
			]
		F15A_CAND_INFO_LIST_BY_FMP5_AXIS_D = 
			[ F15_EXT_ID, FMP5_1_D_S_SCORE_F15, true, 
				[ [ 3, 1, fmp5ReqIndex, FMP5_1_D_R_SCORE_F15,
					[ [ FMP5_1_D_R_SCORE_F15, FIN_1, D, FMP5_LATENT, fmp5FW ] ] ],
				  [ 4, 1, fmp5ReqIndex, FMP5_1_D_S_SCORE_F15,
					[ [ FMP5_1_D_S_SCORE_F15, FIN_1, D, FMP5_LATENT, fmp5FW ] ] ] ]
			]
	}

	private void initPc2CandInfoLists() {
		F1A_CAND_INFO_LIST_BY_PC2 = 
			[ F1_EXT_ID, pc2Score_R1F, true, 
				[ [ 323, 1, pc2ReqIndex, pc2Score_R1F,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ] ]
			]
		F2A_CAND_INFO_LIST_BY_PC2 = 
			[ F2_EXT_ID, pc2Score_S1F, true, 
				[ [ 324, 1, pc2ReqIndex, pc2Score_S1F,
					[ [ PC2_1_S_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ] ]
			]
		F5A_CAND_INFO_LIST_BY_PC2 = 
			[ F5_EXT_ID, pc2Score_S1F, true, 
				[ [ 323, 1, pc2ReqIndex, pc2Score_R1F,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ],
				  [ 324, 1, pc2ReqIndex, pc2Score_S1F,
					[ [ PC2_1_S_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ], ]
			]
		F11A_CAND_INFO_LIST_BY_PC2 = 
			[ F11_EXT_ID, pc2Score_R1F, true, 
				[ [ 323, 1, pc2ReqIndex, pc2Score_R1F,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ] ]
			]
		F11A_CAND_INFO_LIST_BY_PC2_6F = 
			[ F11_EXT_ID, pc2Score_S6F, true, 
				[ [ 323, 1, pc2ReqIndex, pc2Score_R6F,
					[ [ PC2_6_R_SCORE, FIN_6, A, PC2_LATENT, pc2FW ] ] ],
				  [ 324, 1, pc2ReqIndex, pc2Score_S6F,
					[ [ PC2_6_S_SCORE, FIN_6, A, PC2_LATENT, pc2FW ] ] ], ]
			]
		F12A_CAND_INFO_LIST_BY_PC2 = 
			[ F12_EXT_ID, pc2Score_S1F, true, 
				[ [ 323, 1, pc2ReqIndex, pc2Score_R1F,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ],
				  [ 323, 2, pc2ReqIndex, pc2Score_R1F,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ],
				  [ 324, 2, pc2ReqIndex, pc2Score_S6F,
					[ [ PC2_1_S_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ],
				  [ 323, 4, pc2ReqIndex, pc2Score_R1F,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ],
				  [ 324, 4, pc2ReqIndex, pc2Score_S6F,
					[ [ PC2_1_S_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ] ]
			]
		F13A_CAND_INFO_LIST_BY_PC2 = 
			[ F13_EXT_ID, pc2Score_S1F, true, 
				[ [ 323, 1, pc2ReqIndex, pc2Score_R1F,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ],
				  [ 1323, 1, pc2ReqIndex, pc2Score_R1F,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ],
				  [ 1324, 1, pc2ReqIndex, pc2Score_S6F,
					[ [ PC2_1_S_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ],
				  [ 5323, 1, pc2ReqIndex, pc2Score_R1F,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ],
				  [ 5324, 1, pc2ReqIndex, pc2Score_S6F,
					[ [ PC2_1_S_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ] ]
			]
	}

	private void initBothCandInfoLists() {
		F7A_CAND_INFO_LIST_BY_BOTH = 
			[ F7_EXT_ID, fmp5_pc2_score_R1F_R1F, true, 
				[ [ 3, 1, fmp5ReqIndex, fmp5Score_R1F,
					[ [ FMP5_1_R_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ], 
				  [ 323, 1, pc2ReqIndex, pc2Score_R1F,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ] ]
			]
		F8A_CAND_INFO_LIST_BY_BOTH = 
			[ F8_EXT_ID, fmp5_pc2_score_S1F_S1F, true, 
				[ [ 4, 1, fmp5ReqIndex, fmp5Score_S1F,
					[ [ FMP5_1_S_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ], 
				  [ 324, 1, pc2ReqIndex, pc2Score_S1F,
					[ [ PC2_1_S_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ] ]
			]
		F9A_CAND_INFO_LIST_BY_BOTH = 
			[ F9_EXT_ID, fmp5_pc2_score_R1F_S1F, true, 
				[ [ 3, 1, fmp5ReqIndex, fmp5Score_R1F,
					[ [ FMP5_1_R_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ], 
				  [ 324, 1, pc2ReqIndex, pc2Score_S1F,
					[ [ PC2_1_S_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ] ]
			]
		F10A_CAND_INFO_LIST_BY_BOTH = 
			[ F10_EXT_ID, fmp5_pc2_score_S1F_S1F, true, 
				[ [ 3, 1, fmp5ReqIndex, fmp5Score_R1F,
					[ [ FMP5_1_R_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 4, 1, fmp5ReqIndex, fmp5Score_S1F,
					[ [ FMP5_1_S_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 323, 1, pc2ReqIndex, pc2Score_R1F,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ],
				  [ 324, 1, pc2ReqIndex, pc2Score_S1F,
					[ [ PC2_1_S_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ] ]
			]
		F11A_CAND_INFO_LIST_BY_BOTH = 
			[ F11_EXT_ID, fmp5_pc2_score_S1F_R1F, true, 
				[ F11A_CAND_INFO_LIST_BY_FMP5[3][0],
				  F11A_CAND_INFO_LIST_BY_FMP5[3][1],
				  F11A_CAND_INFO_LIST_BY_PC2[3][0] ] 
			]
		F11A_CAND_INFO_LIST_BY_BOTH_10F = 
			[ F11_EXT_ID, pc2Score_S10F, true, 
				[ [ 324, 2, pc2ReqIndex, pc2Score_S10F,
					[ [ PC2_10_S_SCORE, FIN_10, A, PC2_LATENT, pc2FW ] ] ] ]
			]
		F12A_CAND_INFO_LIST_BY_BOTH = 
			[ F12_EXT_ID, fmp5_pc2_score_S1F_S1F, true, 
				[ [ 3, 3, fmp5ReqIndex, fmp5Score_R1F,
					[ [ FMP5_1_R_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 4, 3, fmp5ReqIndex, fmp5Score_S1F,
					[ [ FMP5_1_S_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 3, 4, fmp5ReqIndex, fmp5Score_R1F,
					[ [ FMP5_1_R_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 4, 4, fmp5ReqIndex, fmp5Score_S1F,
					[ [ FMP5_1_S_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 323, 1, pc2ReqIndex, pc2Score_R1F,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ],
				  [ 323, 2, pc2ReqIndex, pc2Score_R1F,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ],
				  [ 324, 2, pc2ReqIndex, pc2Score_S1F,
					[ [ PC2_1_S_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ],
				  [ 323, 4, pc2ReqIndex, pc2Score_R1F,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ],
				  [ 324, 4, pc2ReqIndex, pc2Score_S1F,
					[ [ PC2_1_S_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ] ]
			]
		F13A_CAND_INFO_LIST_BY_BOTH = 
			[ F13_EXT_ID, fmp5_pc2_score_S1F_S1F, true, 
				[ [ 2003, 1, fmp5ReqIndex, fmp5Score_R1F,
					[ [ FMP5_1_R_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 2004, 1, fmp5ReqIndex, fmp5Score_S1F,
					[ [ FMP5_1_S_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 5003, 1, fmp5ReqIndex, fmp5Score_R1F,
					[ [ FMP5_1_R_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 5004, 1, fmp5ReqIndex, fmp5Score_S1F,
					[ [ FMP5_1_S_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 323, 1, pc2ReqIndex, pc2Score_R1F,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ],
				  [ 1323, 1, pc2ReqIndex, pc2Score_R1F,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ],
				  [ 1324, 1, pc2ReqIndex, pc2Score_S1F,
					[ [ PC2_1_S_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ],
				  [ 5323, 1, pc2ReqIndex, pc2Score_R1F,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ],
				  [ 5324, 1, pc2ReqIndex, pc2Score_S1F,
					[ [ PC2_1_S_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ] ]
			]
		F14A_CAND_INFO_LIST_BY_BOTH = 
			[ F14_EXT_ID, fmp5_pc2_score_S1F_S1F, true, 
				[ [ 1003, 3, fmp5ReqIndex, fmp5Score_R1F,
					[ [ FMP5_1_R_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 1004, 3, fmp5ReqIndex, fmp5Score_S1F,
					[ [ FMP5_1_S_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 323, 1, pc2ReqIndex, pc2Score_R1F,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ],
				  [ 323, 2, pc2ReqIndex, pc2Score_R1F,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ],
				  [ 324, 2, pc2ReqIndex, pc2Score_S1F,
					[ [ PC2_1_S_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ],
				  [ 1323, 2, pc2ReqIndex, pc2Score_R1F,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ],
				  [ 1324, 2, pc2ReqIndex, pc2Score_S1F,
					[ [ PC2_1_S_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ] ]
			]
		F15A_CAND_INFO_LIST_BY_BOTH_AXIS_A = 
			[ F15_EXT_ID, pc2Score_S1F + FMP5_1_A_S_SCORE_F15, true, 
				[ [ 3, 1, fmp5ReqIndex, FMP5_1_A_R_SCORE_F15,
					[ [ FMP5_1_A_R_SCORE_F15, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 4, 1, fmp5ReqIndex, FMP5_1_A_S_SCORE_F15,
					[ [ FMP5_1_A_S_SCORE_F15, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 323, 1, pc2ReqIndex, pc2Score_R1F,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ],
				  [ 324, 1, pc2ReqIndex, pc2Score_S1F,
					[ [ PC2_1_S_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ] ]
			]
		F_ABC_123_HIGH_CAND_INFO_LIST = 
			[ F_ABC_123_HIGH_EXT_ID, fmp5_pc2_score_S1F_S1F, true, 
				[ [ 3, 1, fmp5ReqIndex, fmp5Score_R1F,
					[ [ FMP5_1_R_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 4, 1, fmp5ReqIndex, fmp5Score_S1F,
					[ [ FMP5_1_S_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 323, 1, pc2ReqIndex, pc2Score_R1F,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ],
				  [ 324, 1, pc2ReqIndex, pc2Score_S1F,
					[ [ PC2_1_S_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ],
				  [ 1003, 1, fmp5ReqIndex, fmp5Score_R1F,
					[ [ FMP5_1_R_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 1004, 1, fmp5ReqIndex, fmp5Score_S1F,
					[ [ FMP5_1_S_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 1323, 1, pc2ReqIndex, pc2Score_R1F,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ],
				  [ 1324, 1, pc2ReqIndex, pc2Score_S1F,
					[ [ PC2_1_S_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ] ]
			]
		F_BBC_123_HIGH_CAND_INFO_LIST = 
			[ F_BBC_123_HIGH_EXT_ID, fmp5_pc2_score_S1F_S1F, true, F_ABC_123_HIGH_CAND_INFO_LIST[3] ]
		F_0BBC_123_HIGH_CAND_INFO_LIST = 
			[ F_0BBC_123_HIGH_EXT_ID, fmp5_pc2_score_S1F_S1F, true, F_ABC_123_HIGH_CAND_INFO_LIST[3] ]
		F_ABC_123_LOW_CAND_INFO_LIST = 
			[ F_ABC_123_LOW_EXT_ID, fmp5_pc2_score_S1F_S1F_Low, true, 
				[ [ 3, 1, fmp5ReqIndex, fmp5Score_R1F,
					[ [ FMP5_1_R_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 4, 1, fmp5ReqIndex, fmp5Score_S1F_Low,
					[ [ FMP5_1_S_SCORE_LOW, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 323, 1, pc2ReqIndex, pc2Score_R1F,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ],
				  [ 324, 1, pc2ReqIndex, pc2Score_S1F,
					[ [ PC2_1_S_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ],
				  [ 1003, 1, fmp5ReqIndex, fmp5Score_R1F,
					[ [ FMP5_1_R_SCORE, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 1004, 1, fmp5ReqIndex, fmp5Score_S1F_Low,
					[ [ FMP5_1_S_SCORE_LOW, FIN_1, A, FMP5_LATENT, fmp5FW ] ] ],
				  [ 1323, 1, pc2ReqIndex, pc2Score_R1F,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ],
				  [ 1324, 1, pc2ReqIndex, pc2Score_S1F,
					[ [ PC2_1_S_SCORE, FIN_1, A, PC2_LATENT, pc2FW ] ] ] ]
			]
		F_BBC_123_LOW_CAND_INFO_LIST = 
			[ F_BBC_123_LOW_EXT_ID, fmp5_pc2_score_S1F_S1F_Low, true, F_ABC_123_LOW_CAND_INFO_LIST[3] ]
		F_0BBC_123_LOW_CAND_INFO_LIST = 
			[ F_0BBC_123_LOW_EXT_ID, fmp5_pc2_score_S1F_S1F_Low, true, F_ABC_123_LOW_CAND_INFO_LIST[3] ]
	}

	private int calcFusionScore_fmp5_pc2() {
		return calcFusionScore_fmp5_pc2(PC2_1_R_SCORE, FMP5_1_R_SCORE)
	}

	private int calcFusionScore_fmp5_pc2(int pc2Score, int fmp5Score) {
		pc2Score = mergeFWeight(pc2Score, pc2FW)
		fmp5Score = mergeFWeight(fmp5Score, fmp5FW)
		int fScore = pc2Score + fmp5Score
		return cutoffScore(fScore)
	}

	public List getCandList_fingerMerge_pc2() {
		return [ F11A_CAND_INFO_LIST_BY_PC2_6F, F11A_CAND_INFO_LIST_BY_PC2 ]
	}

	public List getCandList_fingerMerge_fmp5() {
		return  [ F11A_CAND_INFO_LIST_BY_FMP5,
				F11A_CAND_INFO_LIST_BY_FMP5_2F,
				F11A_CAND_INFO_LIST_BY_FMP5_5F ]
	}

	public List getCandList_fingerMerge_both() {
		pc2ReqIndex = 1
		initCandInfoLists()
		return  [ F11A_CAND_INFO_LIST_BY_BOTH,
				F11A_CAND_INFO_LIST_BY_PC2_6F,
				F11A_CAND_INFO_LIST_BY_FMP5_2F,
				F11A_CAND_INFO_LIST_BY_FMP5_5F ]
	}

	public List getCandList_fingerMerge_both_2event() {
		pc2ReqIndex = 1
		initCandInfoLists()
		return  [ F11A_CAND_INFO_LIST_BY_BOTH_10F,
				F11A_CAND_INFO_LIST_BY_BOTH,
				F11A_CAND_INFO_LIST_BY_PC2_6F,
				F11A_CAND_INFO_LIST_BY_FMP5_2F,
				F11A_CAND_INFO_LIST_BY_FMP5_5F ]
	}

	public List getCandList_inquirySet1() {
		return [ F5A_CAND_INFO_LIST_BY_PC2 ]
	}

	public List getCandList_inquirySet2() {
		return [ F6A_CAND_INFO_LIST_BY_FMP5 ]
	}

	public List getCandList_inquirySet3() {
		pc2ReqIndex = 1
		initCandInfoLists()
		return [ F9A_CAND_INFO_LIST_BY_BOTH ]
	}

	public List getCandList_inquirySet4() {
		pc2ReqIndex = 1
		initCandInfoLists()
		return [ F10A_CAND_INFO_LIST_BY_BOTH ]
	}

	public List getCandList_muMerge() {
		pc2ReqIndex = 1
		initCandInfoLists()
		return [ F1A_CAND_INFO_LIST_BY_PC2,
				F2A_CAND_INFO_LIST_BY_PC2,
				F3A_CAND_INFO_LIST_BY_FMP5,
				F4A_CAND_INFO_LIST_BY_FMP5,
				F5A_CAND_INFO_LIST_BY_PC2,
				F6A_CAND_INFO_LIST_BY_FMP5,
				F7A_CAND_INFO_LIST_BY_BOTH,
				F8A_CAND_INFO_LIST_BY_BOTH,
				F9A_CAND_INFO_LIST_BY_BOTH,
				F10A_CAND_INFO_LIST_BY_BOTH ]
	}

	public List getCandList_eventMerge_pc2() {
		return [ F12A_CAND_INFO_LIST_BY_PC2 ]
	}

	public List getCandList_eventMerge_fmp5() {
		return [ F12A_CAND_INFO_LIST_BY_FMP5 ]
	}

	public List getCandList_eventMerge_both() {
		pc2ReqIndex = 1
		initCandInfoLists()
		return [ F12A_CAND_INFO_LIST_BY_BOTH ]
	}

	public List getCandList_scopeMerge_pc2() {
		return [ F13A_CAND_INFO_LIST_BY_PC2 ]
	}

	public List getCandList_scopeMerge_fmp5() {
		return [ F13A_CAND_INFO_LIST_BY_FMP5 ]
	}

	public List getCandList_scopeMerge_both() {
		pc2ReqIndex = 1
		initCandInfoLists()
		return [ F13A_CAND_INFO_LIST_BY_BOTH ]
	}

	public List getCandList_scopeEventMerge_both() {
		pc2ReqIndex = 1
		initCandInfoLists()
		return [ F14A_CAND_INFO_LIST_BY_BOTH ]
	}

	public List getCandList_multiAxis_false_1() {
		return [ F3A_CAND_INFO_LIST_BY_FMP5_AXIS_A,
				F3A_CAND_INFO_LIST_BY_FMP5_AXIS_C,
				F3A_CAND_INFO_LIST_BY_FMP5_AXIS_D ]
	}

	public List getCandList_multiAxis_false_2() {
		return [ F4A_CAND_INFO_LIST_BY_FMP5_AXIS_A,
				F4A_CAND_INFO_LIST_BY_FMP5_AXIS_C,
				F4A_CAND_INFO_LIST_BY_FMP5_AXIS_D ]
	}

	public List getCandList_multiAxis_false_3() {
		return [ F6A_CAND_INFO_LIST_BY_FMP5_AXIS_A,
				F6A_CAND_INFO_LIST_BY_FMP5_AXIS_B,
				F6A_CAND_INFO_LIST_BY_FMP5_AXIS_C,
				F6A_CAND_INFO_LIST_BY_FMP5_AXIS_D ]
	}

	public List getCandList_multiAxis_false_4() {
		pc2ReqIndex = 1
		initCandInfoLists()
		return [ F15A_CAND_INFO_LIST_BY_BOTH_AXIS_A,
				F15A_CAND_INFO_LIST_BY_FMP5_AXIS_B,
				F15A_CAND_INFO_LIST_BY_FMP5_AXIS_C,
				F15A_CAND_INFO_LIST_BY_FMP5_AXIS_D ]
	}

	public List getCandList_multiAxis_true_1() {
		return [ F3A_CAND_INFO_LIST_BY_FMP5_AXIS_C ]
	}

	public List getCandList_multiAxis_true_2() {
		return [ F4A_CAND_INFO_LIST_BY_FMP5_AXIS_C ]
	}

	public List getCandList_multiAxis_true_3() {
		return [ F6A_CAND_INFO_LIST_BY_FMP5_AXIS_A ]
	}

	public List getCandList_multiAxis_true_4() {
		pc2ReqIndex = 1
		initCandInfoLists()
		return [ F15A_CAND_INFO_LIST_BY_BOTH_AXIS_A ]
	}

	public List getCandList_fWeight(Integer pc2FW, Integer fmp5FW) {
		this.pc2FW = pc2FW
		this.fmp5FW = fmp5FW
		pc2ReqIndex = 1
		initCandInfoLists()
		return [ F10A_CAND_INFO_LIST_BY_BOTH ]
	}

	public List getCandList_fWeight_multi(Integer pc2FW, Integer fmp5FW) {
		this.pc2FW = pc2FW
		this.fmp5FW = fmp5FW
		pc2ReqIndex = 1
		initCandInfoLists()
		return [ F1A_CAND_INFO_LIST_BY_PC2,
				F2A_CAND_INFO_LIST_BY_PC2,
				F3A_CAND_INFO_LIST_BY_FMP5,
				F4A_CAND_INFO_LIST_BY_FMP5,
				F5A_CAND_INFO_LIST_BY_PC2,
				F6A_CAND_INFO_LIST_BY_FMP5,
				F7A_CAND_INFO_LIST_BY_BOTH,
				F8A_CAND_INFO_LIST_BY_BOTH,
				F9A_CAND_INFO_LIST_BY_BOTH,
				F10A_CAND_INFO_LIST_BY_BOTH ]
	}

	public List getCandList_candSort() {
		pc2ReqIndex = 1
		initCandInfoLists()
		return [ F_ABC_123_HIGH_CAND_INFO_LIST,
				F_BBC_123_HIGH_CAND_INFO_LIST,
				F_0BBC_123_HIGH_CAND_INFO_LIST,
				F_ABC_123_LOW_CAND_INFO_LIST,
				F_BBC_123_LOW_CAND_INFO_LIST,
				F_0BBC_123_LOW_CAND_INFO_LIST ]
	}
}

