package test.degrade.testitem.helper

import test.common.util.tool.ToolExecutor;
import test.degrade.util.SoapuiObject;
import common.util.Encoder;
import test.degrade.constants.soapui.*
import test.degrade.evidence.EvidenceFileOutputor;
import test.degrade.evidence.*

class MultiFeTemplateHelper{

	protected SoapuiObject soapuiObj
	def dirName
	def fileName
	
	
	MultiFeTemplateHelper(context){
		this.soapuiObj = new SoapuiObject(context)
		this.dirName = soapuiObj.getEvidenceDataDirName() + "/"
		this.fileName = dirName  + soapuiObj.getTestCaseName() + ".b64"
	}

	MultiFeTemplateHelper(context, key){
		this.soapuiObj = new SoapuiObject(context)
		this.dirName = soapuiObj.getEvidenceDataDirName() + "/" + key + "/"
		this.fileName = dirName  + soapuiObj.getTestCaseName() + ".b64"
	}	

	public List doBunkai(String templatePath, String outputDirPath){
		ToolExecutor tool = new ToolExecutor(soapuiObj.getContext())
		return tool.doBunkai(templatePath, outputDirPath)
	}

	public List doBunkai_X(String templatePath, String outputDirPath){
		ToolExecutor tool = new ToolExecutor(soapuiObj.getContext())
		return tool.doBunkai_X(templatePath, outputDirPath)
	}

	public String getDevideTemplate(String format, String type){
		File tempFile = new File("${dirName}/${format}_${type}.dbl")
		if (tempFile.exists()){
			return Encoder.binaryToB64(tempFile)
		}else{
			return ""
		}
	}
	
	public String getDevideTemplate(String type){
		String fileNameRoot = soapuiObj.getTestCaseName()
		File tempFile = new File("${dirName}/${fileNameRoot}_${type}.dbl")
		if (tempFile.exists()){
			return Encoder.binaryToB64(tempFile)
		}else{
			return ""
		}
	}
	
	public String getDevideXTemplate(String filePath){
		File tempFile = new File(filePath)
		return Encoder.binaryToB64(tempFile)
	}
	
	def outputData(response){
		makeOutputDir()
		writeData(response)
	}

	def outputData(filePath, b64){
		def evidenceOutputor = new EvidenceFileOutputor(soapuiObj.getContext())	
		evidenceOutputor.outputResultDataAsBinary(filePath, b64)    
	}
	
	def makeOutputDir(){
		new File(dirName).mkdirs()
	}
	
	def writeData(response){
		new File(fileName).write(response)
	}
}

