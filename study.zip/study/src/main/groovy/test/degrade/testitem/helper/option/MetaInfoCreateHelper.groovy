package test.degrade.testitem.helper.option


class MetaInfoCreateHelper extends TestOptionsCreateHelper {
	

	static final String META_INFO_HEAD = "<meta-info> "
	static final String META_INFO_END = "</meta-info>"
	static final String META_COMMON_HEAD = "<meta-common "

	static final String GENDER = "gender"
	static final String YOB = "yob"
	static final String YOB_RANGE = "yobRange"
	static final String RACE = "race"
	static final String REGION = "region"

	def createMetaCommon(def gender, def yob, def yobRange, def race, def region){
		return META_INFO_HEAD + LINE_FEED_CODE +
				META_COMMON_HEAD + 
				makeAttribute(GENDER, gender) +
				makeAttribute(YOB, yob) +
				makeAttribute(YOB_RANGE, yobRange) +
				makeAttribute(RACE, race) +
				makeAttribute(REGION, region) +
				END_2 +
				META_INFO_END + LINE_FEED_CODE
	}

}
