package test.degrade.testitem.helper

import static test.common.constants.aim.SearchLFMLParameter.*
import static test.common.constants.aim.AIMWord.*

class LfmlPatternTestHelper {
    
	private static final List LIM_S_AUTO_F_AUTO_F8_SL3_NO_MARKUP_RAW_SCORE_LIST = [ 
		1584, 1007,  342,  736, 1526, 1747,  936,    0, 1661, 1219,  518, 1652,  843,  759,  520, 1244]
	private static final List LIM_S_AUTO_F_AUTO_F8_SL3_USE_MARKUP_RAW_SCORE_LIST = [ 
		 685, 1079,    0,  932,  683, 1023,    0,  324, 1133,  338,  749, 1539,   59,  600,  433,  113]	
	private static final List LIM_S_AUTO_F_MANUAL_F8_SL3_USE_MARKUP_RAW_SCORE_LIST = [ 
		 715, 1079,    0,  932,  683, 1023,    0,  324, 1133,  232,  749, 1539,  139,  429,  433,  113]

	private static final List LIM_S_MANUAL_F_AUTO_F8_SL3_USE_MARKUP_RAW_SCORE_LIST = [ 
		 563,  675,  685, 1095,    0,  932,  683, 1023,    0,  324, 1133,  338, 1113, 1187,  945, 1259 ]     
	private static final List LIM_S_MANUAL_F_MANUAL_F8_SL3_USE_MARKUP_RAW_SCORE_LIST = [ 
		   0,  675,  715, 1095,    0,  932,  683, 1023,    0,  324, 1133,  232, 1113, 1187,  945, 1259 ]     

    private static final List LLIM_S_AUTO_F_AUTO_SL3_NO_MARK_UP_RAW_SCORE_LIST = [
        2560,  916, 1463, 3494,  809, 1608, 1737, 1773,  671, 2335, 2149, 1433, 1664,  868, 1567, 1239 ]
    private static final List LLIM_S_AUTO_F_AUTO_SL3_F_USE_MARK_UP_RAW_SCORE_LIST = [
        1858,  528, 1070,  222, 1271, 1437,  634, 1186,   53,  795,  916,  467, 1539,  525,  577,  841 ]
    private static final List LLIM_S_AUTO_F_AUTO_SL3_S_USE_MARK_UP_RAW_SCORE_LIST = [
        1853,  545, 1136,  222, 1289, 1409,  646, 1133,   58,  796,  895,  473, 1513,  572,  564,  825 ]
    private static final List LLIM_S_AUTO_F_AUTO_SL3_S_F_USE_MARK_UP_RAW_SCORE_LIST = [
         800,  256,  353,  245,  590,  287,  405,   21,  458,    0,   19,  283,  964,  436,  357,  101 ]
    private static final List LLIM_S_AUTO_F_MANUAL_SL3_F_USE_MARK_UP_RAW_SCORE_LIST = [
         898, 1612,  916, 1463, 3494,  809, 1608, 1737, 1773,  671, 1542, 1948, 2089,  335, 1434,  539 ]
    private static final List LLIM_S_AUTO_F_MANUAL_SL3_S_USE_MARK_UP_RAW_SCORE_LIST = [
           0,  544,  545, 1136,  222, 1261, 1409,  646, 1133,   64,  520,  484,  238,  181,  366,  143 ]
    private static final List LLIM_S_AUTO_F_MANUAL_SL3_S_F_USE_MARK_UP_RAW_SCORE_LIST = [
           0,  275,  256,  353,  245,  616,  287,  405,  266,  458,  278,  358,  169,   93,  356,  220 ]

    private static final List LLIM_S_MANUAL_F_AUTO_SL3_F_USE_MARK_UP_RAW_SCORE_LIST = [
           0,  284,  161,  301,  600,  309,  168,  692,  564,  289,  265,  109,  855,  129,  316,  295 ]
    private static final List LLIM_S_MANUAL_F_AUTO_SL3_S_USE_MARK_UP_RAW_SCORE_LIST = [
         998, 1630,  545, 1136,  222, 1289, 1409,  646, 1133,   58,  875, 1206, 2177,  422,  754,  348 ]
    private static final List LLIM_S_MANUAL_F_AUTO_SL3_S_F_USE_MARK_UP_RAW_SCORE_LIST = [
           0,  550,  256,  353,  245,  590,  287,  405,   21,  458,    0,   71,  350,  109,  247,  361 ]
    private static final List LLIM_S_MANUAL_F_MANUAL_SL3_F_USE_MARK_UP_RAW_SCORE_LIST = [
        5702,  660,  169,  301,  600,  285,  168,  692,  564,  674, 4269,  201, 5657,  492, 5253,  940 ]
    private static final List LLIM_S_MANUAL_F_MANUAL_SL3_S_USE_MARK_UP_RAW_SCORE_LIST = [
        5702, 1853,  740, 1136,  222, 1261, 1409,  646, 1133, 3431,  919,  972, 5165, 1561,  604, 1757 ]
    private static final List LLIM_S_MANUAL_F_MANUAL_SL3_S_F_USE_MARK_UP_RAW_SCORE_LIST = [
        5702,  800,  410,  353,  245,  616,  287,  405,  266,  674,  919,  201, 5165,  492,  604,  940 ]

    private static final List TLIM_S_AUTO_F_AUTO_F8_SL3_NO_MARK_UP_RAW_SCORE_LIST = [
		1584, 1007,  342,  736, 1526, 1747,  936,    0, 1661, 1219,  518, 1652,  843,  759,  520, 1244 ]
    private static final List TLIM_S_AUTO_F_AUTO_F8_SL3_USE_MARK_UP_RAW_SCORE_LIST = [
		 685, 1079,    0,  932,  683, 1023,    0,  324, 1133,  338,  749, 1539,   59,  600,  433,  113 ]
    private static final List TLIM_S_AUTO_F_MANUAL_F8_SL3_USE_MARK_UP_RAW_SCORE_LIST = [
		 563,  675,  685, 1095,    0,  932,  683, 1023,    0,  324, 1133,  338, 1113, 1187,  945, 1259 ]     

    private static final List TLIM_S_MANUAL_F_AUTO_F8_SL3_USE_MARK_UP_RAW_SCORE_LIST = [
		 715, 1079,    0,  932,  683, 1023,    0,  324, 1133,  232,  749, 1539,  139,  429,  433,  113 ]
    private static final List TLIM_S_MANUAL_F_MANUAL_F8_SL3_USE_MARK_UP_RAW_SCORE_LIST = [
		   0,  675,  715, 1095,    0,  932,  683, 1023,    0,  324, 1133,  232, 1113, 1187,  945, 1259 ]     


    private List rawScoreList
    private List rawScoreSIndexList
    private List rawScoreFIndexList
    private int score = -1


    public void setup(String function,  boolean isSManual, boolean isFManual, boolean isMarkUp) {
		if(function == LIM){
        	if(!isSManual && !isFManual) {
            	setupLIMIndexListAutoAuto()
            	if(isMarkUp){
                    rawScoreList = LIM_S_AUTO_F_AUTO_F8_SL3_USE_MARKUP_RAW_SCORE_LIST
            	}else{
                    rawScoreList = LIM_S_AUTO_F_AUTO_F8_SL3_NO_MARKUP_RAW_SCORE_LIST
            	}
        	}else if(!isSManual && isFManual){
            	setupLIMIndexListAutoAuto()
            	if(isMarkUp){
                   	rawScoreList = LIM_S_AUTO_F_MANUAL_F8_SL3_USE_MARKUP_RAW_SCORE_LIST
            	}
        	}else if(isSManual && !isFManual){
				setupLIMIndexListManualManual()
				if(isMarkUp){
                    rawScoreList = LIM_S_MANUAL_F_AUTO_F8_SL3_USE_MARKUP_RAW_SCORE_LIST
                }
			}else if(isSManual && isFManual){
				setupLIMIndexListManualManual()
                if(isMarkUp){
                    rawScoreList = LIM_S_MANUAL_F_MANUAL_F8_SL3_USE_MARKUP_RAW_SCORE_LIST
                }
			}
    	}else if(function == TLIM){
        	if(!isSManual && !isFManual) {
            	setupTLIMIndexListAuto()
            	if(isMarkUp){
                    rawScoreList = TLIM_S_AUTO_F_AUTO_F8_SL3_USE_MARK_UP_RAW_SCORE_LIST
            	}else{
                    rawScoreList = TLIM_S_AUTO_F_AUTO_F8_SL3_NO_MARK_UP_RAW_SCORE_LIST
            	}
        	}else if(isSManual && !isFManual){
            	setupTLIMIndexListAuto()
            	if(isMarkUp){
                   	rawScoreList = TLIM_S_MANUAL_F_AUTO_F8_SL3_USE_MARK_UP_RAW_SCORE_LIST
            	}
        	}else if(!isSManual && isFManual){
				 setupTLIMIndexListManual()
                if(isMarkUp){
                    rawScoreList = TLIM_S_AUTO_F_MANUAL_F8_SL3_USE_MARK_UP_RAW_SCORE_LIST
                }
        	}else if(isSManual && isFManual){
				 setupTLIMIndexListManual()
                if(isMarkUp){
                    rawScoreList = TLIM_S_MANUAL_F_MANUAL_F8_SL3_USE_MARK_UP_RAW_SCORE_LIST
                }
			}
		}
	}
	
    public void setup(String function,  boolean isSManual, boolean isFManual, boolean isSMarkUp, boolean isFMarkUp) {
        if(function == LLIM){
            if(!isSManual && !isFManual) {
                setupLLIMIndexListAutoAuto()
                if(!isSMarkUp && isFMarkUp){
                    rawScoreList = LLIM_S_AUTO_F_AUTO_SL3_F_USE_MARK_UP_RAW_SCORE_LIST
                }else if(isSMarkUp && !isFMarkUp){
                    rawScoreList = LLIM_S_AUTO_F_AUTO_SL3_S_USE_MARK_UP_RAW_SCORE_LIST
                }else if(!isSMarkUp && !isFMarkUp){
                    rawScoreList = LLIM_S_AUTO_F_AUTO_SL3_NO_MARK_UP_RAW_SCORE_LIST
				}else if(isSMarkUp && isFMarkUp){
                    rawScoreList = LLIM_S_AUTO_F_AUTO_SL3_S_F_USE_MARK_UP_RAW_SCORE_LIST
				}
            }else if(!isSManual && isFManual){
                setupLLIMIndexListAutoManual()
                if(!isSMarkUp && isFMarkUp){
                    rawScoreList = LLIM_S_AUTO_F_MANUAL_SL3_F_USE_MARK_UP_RAW_SCORE_LIST
                }else if(isSMarkUp && !isFMarkUp){
                    rawScoreList = LLIM_S_AUTO_F_MANUAL_SL3_S_USE_MARK_UP_RAW_SCORE_LIST
				}else if(isSMarkUp && isFMarkUp){
                    rawScoreList = LLIM_S_AUTO_F_MANUAL_SL3_S_F_USE_MARK_UP_RAW_SCORE_LIST
                }
            }else if(isSManual && !isFManual){
                setupLLIMIndexListManualAuto()
                if(!isSMarkUp && isFMarkUp){
                    rawScoreList = LLIM_S_MANUAL_F_AUTO_SL3_F_USE_MARK_UP_RAW_SCORE_LIST
                }else if(isSMarkUp && !isFMarkUp){
                    rawScoreList = LLIM_S_MANUAL_F_AUTO_SL3_S_USE_MARK_UP_RAW_SCORE_LIST
				}else if(isSMarkUp && isFMarkUp){
                    rawScoreList = LLIM_S_MANUAL_F_AUTO_SL3_S_F_USE_MARK_UP_RAW_SCORE_LIST
                }
            }else if(isSManual && isFManual){
                setupLLIMIndexListManualManual()
                if(!isSMarkUp && isFMarkUp){
                    rawScoreList = LLIM_S_MANUAL_F_MANUAL_SL3_F_USE_MARK_UP_RAW_SCORE_LIST
                }else if(isSMarkUp && !isFMarkUp){
                    rawScoreList = LLIM_S_MANUAL_F_MANUAL_SL3_S_USE_MARK_UP_RAW_SCORE_LIST
				}else if(isSMarkUp && isFMarkUp){
                    rawScoreList = LLIM_S_MANUAL_F_MANUAL_SL3_S_F_USE_MARK_UP_RAW_SCORE_LIST
                }
            }
        }
    }

    private void setupLLIMIndexListAutoAuto() {
        rawScoreFIndexList = S_AUTO_F_AUTO_SL3_FILE_INDEX_LIST
        rawScoreSIndexList = S_AUTO_F_AUTO_SL3_SEARCH_INDEX_LIST
    }

    private void setupLLIMIndexListAutoManual() {
        rawScoreFIndexList = S_AUTO_F_MANUAL_SL3_FILE_INDEX_LIST
        rawScoreSIndexList = S_AUTO_F_MANUAL_SL3_SEARCH_INDEX_LIST
    }

    private void setupLLIMIndexListManualAuto() {
        rawScoreFIndexList = S_MANUAL_F_AUTO_SL3_FILE_INDEX_LIST
        rawScoreSIndexList = S_MANUAL_F_AUTO_SL3_SEARCH_INDEX_LIST
    }

    private void setupLLIMIndexListManualManual() {
        rawScoreFIndexList = S_MANUAL_F_MANUAL_SL3_FILE_INDEX_LIST
        rawScoreSIndexList = S_MANUAL_F_MANUAL_SL3_SEARCH_INDEX_LIST
    }

    private void setupLIMIndexListAutoAuto() {
        rawScoreFIndexList = LIM_AUTO_F8_SL3_FILE_INDEX_LIST
        rawScoreSIndexList = LIM_AUTO_F8_SL3_SEARCH_INDEX_LIST
    }

    private void setupLIMIndexListManualManual() {
        rawScoreFIndexList = LIM_MANUAL_F8_SL3_FILE_INDEX_LIST
        rawScoreSIndexList = LIM_MANUAL_F8_SL3_SEARCH_INDEX_LIST
    }

    private void setupTLIMIndexListAuto() {
        rawScoreFIndexList = TLIM_AUTO_F8_SL3_SEARCH_INDEX_LIST
        rawScoreSIndexList = TLIM_AUTO_F8_SL3_FILE_INDEX_LIST
    }

    private void setupTLIMIndexListManual() {
        rawScoreFIndexList = TLIM_MANUAL_F8_SL3_SEARCH_INDEX_LIST
        rawScoreSIndexList = TLIM_MANUAL_F8_SL3_FILE_INDEX_LIST
    }

    public int getScore() {
        if(score != -1) {
            return score
        }

        score = 0
        for(rScore in rawScoreList) {
            score += rScore as int
        }

		if(rawScoreList.size() != 0){
        	score /= rawScoreList.size()
		}
        return score
    }

    public List getRawScoreList() {
        return rawScoreList
    }

    public List getRawSearchIndexList() {
        return rawScoreSIndexList
    }

    public List getRawFileIndexList() {
        return rawScoreFIndexList
    }
}

