package test.degrade.testitem.helper

import jp.co.nec.nhm.soapui.util.FacePrintReader
import test.degrade.properties.*

class FaceTestHelper{

	private static final String DEFAULT_FACE_IMAGE="/degradeTest/Face/FI/FI.jpg"
	private String dataFilePathRoot

	def FaceTestHelper(context){
		this.dataFilePathRoot = new GlobalProperties(context).getDataFilePath()
	}

	def getBase64Xml(String imageFilePath){
		return  new FacePrintReader().getBase64XML(imageFilePath)
	}

	def getDefaultFaceImgXml(){
		return getBase64Xml( dataFilePathRoot + DEFAULT_FACE_IMAGE )
	}
}
