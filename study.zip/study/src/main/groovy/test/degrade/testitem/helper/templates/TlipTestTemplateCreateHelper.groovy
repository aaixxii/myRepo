package test.degrade.testitem.helper.templates

import test.degrade.testitem.helper.*
import static test.common.constants.data.ImageDataList.*

class TlipTestTemplateCreateHelper extends TestTemplateCreateHelper{

    TlipTestTemplateCreateHelper(context){
		super(context)
    }

	public String getDefaultFileImage(){
		return imgXmlMaker.getLatentPalmImgXml(LP_002_WSQ)
	}

	public String getDefaultSearchImage(){
		return imgXmlMaker.getTenprintPalmImgXml(TP_002_RSP_NST)
	}
	
	public String getTwoPartsSearchImage(){
		return imgXmlMaker.getPalmTwoPartsImgXml()
	}
	
	public String getThreePartsSearchImage(){
		return imgXmlMaker.getPalmThreePartsImgXml()
	}
	
	public String getExtarnalIdFileImage(){
		return imgXmlMaker.getLatentPalmImgXml(LP_005_WSQ)
	}

	public String getMultiplePartsFileImage(){
		return imgXmlMaker.getLatentPalmImgXml(LP_006_WSQ)
	}
	
	public String getMultiplePartsSearchImage_1(){
		return imgXmlMaker.getTenprintPalmImgXml(TP_004_RSP_NST)
	}
	
	public String getMultiplePartsSearchImage_2(){
		return imgXmlMaker.getTenprintPalmImgXml(TP_005_RSP_NST)
	}
}
