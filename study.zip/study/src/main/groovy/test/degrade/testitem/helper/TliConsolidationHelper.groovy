package test.degrade.testitem.helper

import test.degrade.util.SoapuiObject
import test.common.runner.TestCaseExecutor
import test.common.util.assertion.AssertUtil
import static test.degrade.constants.soapui.SoapuiDefines.*
import static test.common.constants.aim.AIMXmlAttribute.*
import com.eviware.soapui.model.testsuite.TestRunner.Status

class TliConsolidationHelper extends ConsolidationHelper {

	private static final String INSERT_TEST_CASE_NAME = "insert"
	private static final String FILE_TEMPLATE_PATH = "fileTemplatePath"
	private static final String SEARCH_TEMPLATE_PATH = "searchTemplatePath"
	private static final String EXTERNAL_ID = "externalId"
	private static final String BIN_ID = "binId"
	private static final String KEY = "key"
	private static final String CONMA = ","
	
	private static final String F101_EXT_ID = "TLI_F101A_LDBS"
	private static final String F102_EXT_ID = "TLI_F102A_LDB"
	private static final String F103_EXT_ID = "TLI_F103A_LDB_LDBS"
	private static final String F104_EXT_ID = "TLI_F104A_LDB"
	private static final String F105_EXT_ID = "TLI_F105A_LDB_LDBS"
	private static final String F106_EXT_ID = "TLI_F106A_LDB"
	private static final String F107_EXT_ID = "TLI_F107A_LDB_LDBS"
	private static final String F108_EXT_ID = "TLI_F108A_LDB_LDBS"
	private static final String F_123_ABC_HIGH_EXT_ID = "TLI-123-ABC-High"
	private static final String F_ABC_123_HIGH_EXT_ID = "TLI-ABC-123-High"
	private static final String F_BBC_123_HIGH_EXT_ID = "TLI-BBC-123-High"
	private static final String F_123_ABC_LOW_EXT_ID = "TLI-123-ABC-Low"
	private static final String F_ABC_123_LOW_EXT_ID = "TLI-ABC-123-Low"
	private static final String F_BBC_123_LOW_EXT_ID = "TLI-BBC-123-Low"
	private static final int PC2_1_R_SCORE = 919
	private static final int PC2_6_R_SCORE = PC2_1_R_SCORE
	private static final int PC2_1_S_SCORE = 2118
	private static final int PC2_6_S_SCORE = 2118
	private static final int FMP5_1_R_SCORE = 739
	private static final int FMP5_1_R_SCORE_A = 748
	private static final int FMP5_1_R_SCORE_B = 1225
	private static final int FMP5_1_R_SCORE_C_SAME_B = FMP5_1_R_SCORE_B
	private static final int FMP5_1_R_SCORE_D = 639
	private static final int FMP5_2_R_SCORE = FMP5_1_R_SCORE
	private static final int FMP5_1_R_SCORE_A_S106 = 717
	private static final int FMP5_1_R_SCORE_B_S106 = 448
	private static final int FMP5_1_R_SCORE_C_S106 = 496
	private static final int FMP5_1_R_SCORE_D_S106 = 495
	private static final int FMP5_1_S_SCORE = 2016
	private static final int FMP5_1_S_SCORE_A = 1851
	private static final int FMP5_1_S_SCORE_B = -1
	private static final int FMP5_1_S_SCORE_C = 1312
	private static final int FMP5_1_S_SCORE_D = 1215
	private static final int FMP5_1_S_SCORE_A_S106 = 1851
	private static final int FMP5_1_S_SCORE_B_S106 = 1362
	private static final int FMP5_1_S_SCORE_C_S106 = 1000
	private static final int FMP5_1_S_SCORE_D_S106 = 558
	private static final int FMP5_2_S_SCORE = FMP5_1_S_SCORE
	private static final int FMP5_5_S_SCORE = 2450
	private static final int FMP5_1_R_SCORE_S106 = FMP5_1_S_SCORE
	private static final int FMP5_1_S_SCORE_S106 = FMP5_1_R_SCORE
	private static final int FMP5_1_R_SCORE_A_S116 = 1469
	private static final int FMP5_1_S_SCORE_B_S116 = 1790
	private static final int FMP5_1_R_SCORE_B_S117 = 2130
	private static final int FMP5_1_S_SCORE_B_S117 = 1005

	private Integer fmp5rFW = 100
	private Integer fmp5sFW = 100
	private Integer pc2rFW = 200
	private Integer pc2sFW = 200
	private int fmp5ReqIndex_R = 0
	private int fmp5ReqIndex_S = 1
	private int pc2ReqIndex_R = 2
	private int pc2ReqIndex_S = 3
	private int fmp5Score_R1
	private int fmp5Score_R1_S106
	private int fmp5Score_R2
	private int fmp5Score_R5
	private int fmp5Score_S1
	private int fmp5Score_S1_S106
	private int fmp5Score_S2
	private int fmp5Score_S5
	private int fmp5Score_R1_S1
	private int fmp5Score_R1_S1_S106
	private int fmp5Score_R2_S2
	private int pc2Score_R1
	private int pc2Score_R6
	private int pc2Score_S1
	private int pc2Score_S6
	private int pc2Score_R1_S1
	private int pc2Score_R6_S6
	private int pc2S1_fmp5R1_score
	private int pc2R1_fmp5R1S1_score
	private int pc2R1S1_fmp5R1S1_score

	private List F101A_CAND_INFO_LIST_BY_PC2_R = []
	private List F101A_CAND_INFO_LIST_BY_PC2_RS = []
	private List F101A_CAND_INFO_LIST_BY_PC2_R6S6 = []
	private List F102A_CAND_INFO_LIST_BY_FMP5_RS = []
	private List F102A_CAND_INFO_LIST_BY_FMP5_RS_S106 = []
	private List F102A_CAND_INFO_LIST_BY_FMP5_R2S2 = []
	private List F102A_CAND_INFO_LIST_BY_FMP5_S5 = []
	private List F103A_CAND_INFO_LIST_BY_PC2_R6S6 = []
	private List F103A_CAND_INFO_LIST_BY_PC2_R6S6_2SCOPE = []
	private List F103A_CAND_INFO_LIST_BY_FMP5_R2S2 = []
	private List F103A_CAND_INFO_LIST_BY_FMP5_S5 = []
	private List F103A_CAND_INFO_LIST_BY_PC2_R_FMP5_RS = []
	private List F103A_CAND_INFO_LIST_BY_PC2_R_FMP5_RS_2SCOPE = []
	private List F103A_CAND_INFO_LIST_BY_PC2_R_FMP5_R = []
	private List F103A_CAND_INFO_LIST_BY_PC2_S_FMP5_R = []
	private List F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS = []
	private List F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS_2SCOPE = []
	private List F104A_CAND_INFO_LIST_BY_FMP5_R_MULTI_AXIS_A = []
	private List F104A_CAND_INFO_LIST_BY_FMP5_R_MULTI_AXIS_B = []
	private List F104A_CAND_INFO_LIST_BY_FMP5_R_MULTI_AXIS_C = []
	private List F104A_CAND_INFO_LIST_BY_FMP5_R_MULTI_AXIS_D = []
	private List F105A_CAND_INFO_LIST_BY_FMP5_RS_MULTI_AXIS_A = []
	private List F105A_CAND_INFO_LIST_BY_FMP5_RS_MULTI_AXIS_B = []
	private List F105A_CAND_INFO_LIST_BY_FMP5_RS_MULTI_AXIS_C = []
	private List F105A_CAND_INFO_LIST_BY_FMP5_RS_MULTI_AXIS_D = []
	private List F105A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS_MULTI_AXIS_A = []
	private List F106A_CAND_INFO_LIST_BY_FMP5_R_MULTI_AXIS_A = []
	private List F106A_CAND_INFO_LIST_BY_FMP5_S_MULTI_AXIS_A = []
	private List F106A_CAND_INFO_LIST_BY_FMP5_R_MULTI_AXIS_C = []
	private List F106A_CAND_INFO_LIST_BY_FMP5_S_MULTI_AXIS_C = []
	private List F106A_CAND_INFO_LIST_BY_FMP5_R_MULTI_AXIS_D = []
	private List F106A_CAND_INFO_LIST_BY_FMP5_S_MULTI_AXIS_D = []
	private List F107A_CAND_INFO_LIST_BY_FMP5_S_MULTI_AXIS_B = []
	private List F107A_CAND_INFO_LIST_BY_PC2_RS_FMP5_R_MULTI_AXIS_A = []
	private List F108A_CAND_INFO_LIST_BY_PC2_RS = []
	private List F108A_CAND_INFO_LIST_BY_FMP5_RS_MULTI_AXIS_B = []

	private List F_123_ABC_HIGH_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS = []
	private List F_ABC_123_HIGH_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS = []
	private List F_BBC_123_HIGH_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS = []
	private List F_123_ABC_LOW_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS = []
	private List F_ABC_123_LOW_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS = []
	private List F_BBC_123_LOW_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS = []

    private String level

	TliConsolidationHelper(context){
		super(context)
		initCandInfoLists()
	}

	TliConsolidationHelper(context, String level){
		super(context)
        this.level = level
		initCandInfoLists()
	}

	private void initCandInfoLists() {
		initScores()
		initFmp5CandInfoLists()
		initPc2CandInfoLists()
		initBothCandInfoLists()
	}

	private void initScores() {
		pc2Score_R1 = mergeFWeight(PC2_1_R_SCORE, pc2rFW)
		pc2Score_R6 = pc2Score_R1
		pc2Score_S1 = mergeFWeight(PC2_1_S_SCORE, pc2sFW)
		pc2Score_S6 = pc2Score_S1
		pc2Score_R1_S1 = cutoffScore(pc2Score_R1 + pc2Score_S1)
		pc2Score_R6_S6 = pc2Score_R1_S1
		fmp5Score_R1 = mergeFWeight(FMP5_1_R_SCORE, fmp5rFW)
		fmp5Score_R2 = fmp5Score_R1
		fmp5Score_S1 = mergeFWeight(FMP5_1_S_SCORE, fmp5sFW)
		fmp5Score_S2 = fmp5Score_S1
		fmp5Score_S5 = mergeFWeight(FMP5_5_S_SCORE, fmp5sFW)
		fmp5Score_R1_S106 = fmp5Score_S1
		fmp5Score_S1_S106 = fmp5Score_R1
		fmp5Score_R1_S1 = cutoffScore(fmp5Score_R1 + fmp5Score_S1)
		fmp5Score_R1_S1_S106 = cutoffScore(fmp5Score_R1_S106 + fmp5Score_S1_S106)
		fmp5Score_R2_S2 = fmp5Score_R1_S1
		pc2R1_fmp5R1S1_score = cutoffScore(pc2Score_R1 + fmp5Score_R1 + fmp5Score_S1)
		pc2S1_fmp5R1_score = cutoffScore(pc2Score_S1 + fmp5Score_R1)
		pc2R1S1_fmp5R1S1_score = cutoffScore(pc2Score_R1 + pc2Score_S1 + fmp5Score_R1 + fmp5Score_S1)
	}


	private void initFmp5CandInfoLists() {
		F102A_CAND_INFO_LIST_BY_FMP5_RS = 
			[ F102_EXT_ID, fmp5Score_R1_S1, true, 
				[ [ 321, 1, fmp5ReqIndex_R, fmp5Score_R1,
					[ [ FMP5_1_R_SCORE, FIN_1, A, FMP5_ROLLED, fmp5rFW ] ] ], 
				  [ 321, 1, fmp5ReqIndex_S, fmp5Score_S1,
					[ [ FMP5_1_S_SCORE, FIN_1, A, FMP5_SLAP, fmp5sFW ] ] ] ]
			]
		F102A_CAND_INFO_LIST_BY_FMP5_RS_S106 = 
			[ F102_EXT_ID, fmp5Score_R1_S1_S106, true, 
				[ [ 321, 1, fmp5ReqIndex_R, fmp5Score_R1_S106,
					[ [ FMP5_1_R_SCORE_S106, FIN_1, A, FMP5_ROLLED, fmp5rFW ] ] ], 
				  [ 321, 1, fmp5ReqIndex_S, fmp5Score_S1_S106,
					[ [ FMP5_1_S_SCORE_S106, FIN_1, A, FMP5_SLAP, fmp5sFW ] ] ] ]
			]
		F102A_CAND_INFO_LIST_BY_FMP5_R2S2 = 
			[ F102_EXT_ID, fmp5Score_R2_S2, true, 
				[ [ 321, 1, fmp5ReqIndex_R, fmp5Score_R2,
					[ [ FMP5_2_R_SCORE, FIN_2, A, FMP5_ROLLED, fmp5rFW ] ] ], 
				  [ 321, 1, fmp5ReqIndex_S, fmp5Score_S2,
					[ [ FMP5_2_S_SCORE, FIN_2, A, FMP5_SLAP, fmp5sFW ] ] ] ]
			]
		F102A_CAND_INFO_LIST_BY_FMP5_S5 = 
			[ F102_EXT_ID, fmp5Score_S5, true, 
				[ [ 321, 1, fmp5ReqIndex_S, fmp5Score_S5,
					[ [ FMP5_5_S_SCORE, FIN_5, A, FMP5_SLAP, fmp5sFW ] ] ] ]
			]
		F103A_CAND_INFO_LIST_BY_FMP5_R2S2 = 
			[ F103_EXT_ID, fmp5Score_R2_S2, true, F102A_CAND_INFO_LIST_BY_FMP5_R2S2[3] ]
		F103A_CAND_INFO_LIST_BY_FMP5_S5 = 
			[ F103_EXT_ID, fmp5Score_S5, true, F102A_CAND_INFO_LIST_BY_FMP5_S5[3] ]
		F104A_CAND_INFO_LIST_BY_FMP5_R_MULTI_AXIS_A = 
			[ F104_EXT_ID, FMP5_1_R_SCORE_A, true, 
				[ [ 321, 1, fmp5ReqIndex_R, FMP5_1_R_SCORE_A,
					[ [ FMP5_1_R_SCORE_A, FIN_1, A, FMP5_ROLLED, fmp5rFW ] ] ] ] 
			]
		F104A_CAND_INFO_LIST_BY_FMP5_R_MULTI_AXIS_B = 
			[ F104_EXT_ID, FMP5_1_R_SCORE_B, true, 
				[ [ 321, 1, fmp5ReqIndex_R, FMP5_1_R_SCORE_B,
					[ [ FMP5_1_R_SCORE_B, FIN_1, B, FMP5_ROLLED, fmp5rFW ] ] ] ]
			]
		F104A_CAND_INFO_LIST_BY_FMP5_R_MULTI_AXIS_C = 
			[ F104_EXT_ID, FMP5_1_R_SCORE_C_SAME_B, true, 
				[ [ 321, 1, fmp5ReqIndex_R, FMP5_1_R_SCORE_C_SAME_B,
					[ [ FMP5_1_R_SCORE_C_SAME_B, FIN_1, C, FMP5_ROLLED, fmp5rFW ] ] ] ]
			]
		F104A_CAND_INFO_LIST_BY_FMP5_R_MULTI_AXIS_D = 
			[ F104_EXT_ID, FMP5_1_R_SCORE_D, true, 
				[ [ 321, 1, fmp5ReqIndex_R, FMP5_1_R_SCORE_D,
					[ [ FMP5_1_R_SCORE_D, FIN_1, D, FMP5_ROLLED, fmp5rFW ] ] ] ]
			]
		F105A_CAND_INFO_LIST_BY_FMP5_RS_MULTI_AXIS_A = 
			[ F105_EXT_ID, FMP5_1_R_SCORE_A_S106 + FMP5_1_S_SCORE_A_S106, true, 
				[ [ 321, 1, fmp5ReqIndex_R, FMP5_1_R_SCORE_A_S106,
					[ [ FMP5_1_R_SCORE_A_S106, FIN_1, A, FMP5_ROLLED, fmp5rFW ] ] ],
				  [ 321, 1, fmp5ReqIndex_S, FMP5_1_S_SCORE_A_S106,
					[ [ FMP5_1_S_SCORE_A_S106, FIN_1, A, FMP5_SLAP, fmp5sFW ] ] ] ]
			]
		F105A_CAND_INFO_LIST_BY_FMP5_RS_MULTI_AXIS_B = 
			[ F105_EXT_ID, FMP5_1_R_SCORE_B_S106 + FMP5_1_S_SCORE_B_S106, true, 
				[ [ 321, 1, fmp5ReqIndex_R, FMP5_1_R_SCORE_B_S106,
					[ [ FMP5_1_R_SCORE_B_S106, FIN_1, B, FMP5_ROLLED, fmp5rFW ] ] ],
				  [ 321, 1, fmp5ReqIndex_S, FMP5_1_S_SCORE_B_S106,
					[ [ FMP5_1_S_SCORE_B_S106, FIN_1, B, FMP5_SLAP, fmp5sFW ] ] ] ]
			]
		F105A_CAND_INFO_LIST_BY_FMP5_RS_MULTI_AXIS_C = 
			[ F105_EXT_ID, FMP5_1_R_SCORE_C_S106 + FMP5_1_S_SCORE_C_S106, true, 
				[ [ 321, 1, fmp5ReqIndex_R, FMP5_1_R_SCORE_C_S106,
					[ [ FMP5_1_R_SCORE_C_S106, FIN_1, C, FMP5_ROLLED, fmp5rFW ] ] ],
				  [ 321, 1, fmp5ReqIndex_S, FMP5_1_S_SCORE_C_S106,
					[ [ FMP5_1_S_SCORE_C_S106, FIN_1, C, FMP5_SLAP, fmp5sFW ] ] ] ]
			]
		F105A_CAND_INFO_LIST_BY_FMP5_RS_MULTI_AXIS_D = 
			[ F105_EXT_ID, FMP5_1_R_SCORE_D_S106 + FMP5_1_S_SCORE_D_S106, true, 
				[ [ 321, 1, fmp5ReqIndex_R, FMP5_1_R_SCORE_D_S106,
					[ [ FMP5_1_R_SCORE_D_S106, FIN_1, D, FMP5_ROLLED, fmp5rFW ] ] ],
				  [ 321, 1, fmp5ReqIndex_S, FMP5_1_S_SCORE_D_S106,
					[ [ FMP5_1_S_SCORE_D_S106, FIN_1, D, FMP5_SLAP, fmp5sFW ] ] ] ]
			]
		F106A_CAND_INFO_LIST_BY_FMP5_R_MULTI_AXIS_A = 
			[ F106_EXT_ID, FMP5_1_S_SCORE_A, true, 
				[ [ 321, 1, fmp5ReqIndex_S, FMP5_1_S_SCORE_A,
					[ [ FMP5_1_S_SCORE_A, FIN_1, A, FMP5_ROLLED, fmp5sFW ] ] ] ] // Template is Slap but inquirySet is Roll.
			]
		F106A_CAND_INFO_LIST_BY_FMP5_S_MULTI_AXIS_A = 
			[ F106_EXT_ID, FMP5_1_S_SCORE_A, true, 
				[ [ 321, 1, fmp5ReqIndex_S, FMP5_1_S_SCORE_A,
					[ [ FMP5_1_S_SCORE_A, FIN_1, A, FMP5_SLAP, fmp5sFW ] ] ] ]
			]
		F106A_CAND_INFO_LIST_BY_FMP5_R_MULTI_AXIS_C = 
			[ F106_EXT_ID, FMP5_1_S_SCORE_C, true, 
				[ [ 321, 1, fmp5ReqIndex_S, FMP5_1_S_SCORE_C,
					[ [ FMP5_1_S_SCORE_C, FIN_1, C, FMP5_ROLLED, fmp5sFW ] ] ] ] // Template is Slap but inquirySet is Roll
			]
		F106A_CAND_INFO_LIST_BY_FMP5_S_MULTI_AXIS_C = 
			[ F106_EXT_ID, FMP5_1_S_SCORE_C, true, 
				[ [ 321, 1, fmp5ReqIndex_S, FMP5_1_S_SCORE_C,
					[ [ FMP5_1_S_SCORE_C, FIN_1, C, FMP5_SLAP, fmp5sFW ] ] ] ]
			]
		F106A_CAND_INFO_LIST_BY_FMP5_R_MULTI_AXIS_D = 
			[ F106_EXT_ID, FMP5_1_S_SCORE_D, true, 
				[ [ 321, 1, fmp5ReqIndex_S, FMP5_1_S_SCORE_D,
					[ [ FMP5_1_S_SCORE_D, FIN_1, D, FMP5_ROLLED, fmp5sFW ] ] ] ] // Template is Slap but inquirySet is Roll
			]
		F106A_CAND_INFO_LIST_BY_FMP5_S_MULTI_AXIS_D = 
			[ F106_EXT_ID, FMP5_1_S_SCORE_D, true, 
				[ [ 321, 1, fmp5ReqIndex_S, FMP5_1_S_SCORE_D,
					[ [ FMP5_1_S_SCORE_D, FIN_1, D, FMP5_SLAP, fmp5sFW ] ] ] ]
			]
		F107A_CAND_INFO_LIST_BY_FMP5_S_MULTI_AXIS_B = 
			[ F107_EXT_ID, FMP5_1_S_SCORE_B_S116, true, 
				[ [ 321, 1, fmp5ReqIndex_S, FMP5_1_S_SCORE_B_S116,
					[ [ FMP5_1_S_SCORE_B_S116, FIN_1, B, FMP5_SLAP, fmp5sFW ] ] ] ]
			]
		F108A_CAND_INFO_LIST_BY_FMP5_RS_MULTI_AXIS_B = 
			[ F108_EXT_ID, FMP5_1_R_SCORE_B_S117 + FMP5_1_S_SCORE_B_S117, true, 
				[ [ 321, 1, fmp5ReqIndex_R, FMP5_1_R_SCORE_B_S117,
					[ [ FMP5_1_R_SCORE_B_S117, FIN_1, B, FMP5_ROLLED, fmp5rFW ] ] ],
				  [ 321, 1, fmp5ReqIndex_S, FMP5_1_S_SCORE_B_S117,
					[ [ FMP5_1_S_SCORE_B_S117, FIN_1, B, FMP5_SLAP, fmp5sFW ] ] ] ]
			]
	}

	private void initPc2CandInfoLists() {
		F101A_CAND_INFO_LIST_BY_PC2_R =
			[ F101_EXT_ID, pc2Score_R1, true, 
				[ [ 326, 1, pc2ReqIndex_R, pc2Score_R1,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_ROLLED, pc2rFW ] ] ] ]
			]
		F101A_CAND_INFO_LIST_BY_PC2_RS =
			[ F101_EXT_ID, pc2Score_R1_S1, true, 
				[ [ 326, 1, pc2ReqIndex_R, pc2Score_R1,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_ROLLED, pc2rFW ] ] ],
				  [ 326, 1, pc2ReqIndex_S, pc2Score_S1,
					[ [ PC2_1_S_SCORE, FIN_1, A, PC2_SLAP, pc2sFW ] ] ], ]
			]
		F101A_CAND_INFO_LIST_BY_PC2_R6S6 =
			[ F101_EXT_ID, pc2Score_R6_S6, true, 
				[ [ 326, 1, pc2ReqIndex_R, pc2Score_R6,
					[ [ PC2_6_R_SCORE, FIN_6, A, PC2_ROLLED, pc2rFW ] ] ],
				  [ 326, 1, pc2ReqIndex_S, pc2Score_S6,
					[ [ PC2_6_S_SCORE, FIN_6, A, PC2_SLAP, pc2sFW ] ] ], ]
			]
		F103A_CAND_INFO_LIST_BY_PC2_R6S6 =
			[ F103_EXT_ID, pc2Score_R6_S6, true, F101A_CAND_INFO_LIST_BY_PC2_R6S6[3] ]
		F103A_CAND_INFO_LIST_BY_PC2_R6S6_2SCOPE =
			[ F103_EXT_ID, pc2Score_R6_S6, true, 
				[ F101A_CAND_INFO_LIST_BY_PC2_R6S6[3][0],
				  F101A_CAND_INFO_LIST_BY_PC2_R6S6[3][1],
				  [ 1326, 1, pc2ReqIndex_R, pc2Score_R6,
					[ [ PC2_1_R_SCORE, FIN_6, A, PC2_ROLLED, pc2rFW ] ] ],
				  [ 1326, 1, pc2ReqIndex_S, pc2Score_S6,
					[ [ PC2_6_S_SCORE, FIN_6, A, PC2_SLAP, pc2sFW ] ] ], ]
 			]
		F108A_CAND_INFO_LIST_BY_PC2_RS =
			[ F108_EXT_ID, pc2Score_R1_S1, true, 
				[ [ 326, 1, pc2ReqIndex_R, pc2Score_R1,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_ROLLED, pc2rFW ] ] ],
				  [ 326, 1, pc2ReqIndex_S, pc2Score_S1,
					[ [ PC2_1_S_SCORE, FIN_1, A, PC2_SLAP, pc2sFW ] ] ], ]
			]
	}

	private void initBothCandInfoLists() {
		F103A_CAND_INFO_LIST_BY_PC2_R_FMP5_R =
			[ F103_EXT_ID, pc2S1_fmp5R1_score, true, 
				[ [ 321, 1, fmp5ReqIndex_R, fmp5Score_R1,
					[ [ FMP5_1_R_SCORE, FIN_1, A, FMP5_ROLLED, fmp5rFW ] ] ],
				  [ 326, 1, pc2ReqIndex_S, pc2Score_S1,
					[ [ PC2_1_S_SCORE, FIN_1, A, PC2_ROLLED, pc2sFW ] ] ] ] // Template is Slap but inquirySet is Roll.
			]
		F103A_CAND_INFO_LIST_BY_PC2_S_FMP5_R =
			[ F103_EXT_ID, pc2S1_fmp5R1_score, true, 
				[ [ 321, 1, fmp5ReqIndex_R, fmp5Score_R1,
					[ [ FMP5_1_R_SCORE, FIN_1, A, FMP5_ROLLED, fmp5rFW ] ] ],
				  [ 326, 1, pc2ReqIndex_S, pc2Score_S1,
					[ [ PC2_1_S_SCORE, FIN_1, A, PC2_SLAP, pc2sFW ] ] ] ]
			]
		F103A_CAND_INFO_LIST_BY_PC2_R_FMP5_RS =
			[ F103_EXT_ID, pc2R1_fmp5R1S1_score, true, 
				[ [ 321, 1, fmp5ReqIndex_R, fmp5Score_R1,
					[ [ FMP5_1_R_SCORE, FIN_1, A, FMP5_ROLLED, fmp5rFW ] ] ], 
				  [ 321, 1, fmp5ReqIndex_S, fmp5Score_S1,
					[ [ FMP5_1_S_SCORE, FIN_1, A, FMP5_SLAP, fmp5sFW ] ] ],
				  [ 326, 1, pc2ReqIndex_R, pc2Score_R1,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_ROLLED, pc2rFW ] ] ] ]
			]
		F103A_CAND_INFO_LIST_BY_PC2_R_FMP5_RS_2SCOPE =
			[ F103_EXT_ID, pc2R1_fmp5R1S1_score, true, 
				[ F103A_CAND_INFO_LIST_BY_PC2_R_FMP5_RS[3][0],
				  F103A_CAND_INFO_LIST_BY_PC2_R_FMP5_RS[3][1],
				  F103A_CAND_INFO_LIST_BY_PC2_R_FMP5_RS[3][2],
				  [ 1326, 1, pc2ReqIndex_R, pc2Score_R1,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_ROLLED, pc2rFW ] ] ] ]
			]
		F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS =
			[ F103_EXT_ID, pc2R1S1_fmp5R1S1_score, true, 
				[ [ 321, 1, fmp5ReqIndex_R, fmp5Score_R1,
					[ [ FMP5_1_R_SCORE, FIN_1, A, FMP5_ROLLED, fmp5rFW ] ] ], 
				  [ 321, 1, fmp5ReqIndex_S, fmp5Score_S1,
					[ [ FMP5_1_S_SCORE, FIN_1, A, FMP5_SLAP, fmp5sFW ] ] ],
				  [ 326, 1, pc2ReqIndex_R, pc2Score_R1,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_ROLLED, pc2rFW ] ] ],
				  [ 326, 1, pc2ReqIndex_S, pc2Score_S1,
					[ [ PC2_1_S_SCORE, FIN_1, A, PC2_SLAP, pc2sFW ] ] ] ]
			]
		F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS_2SCOPE =
			[ F103_EXT_ID, pc2R1S1_fmp5R1S1_score, true, 
				[ F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS[3][0],
				  F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS[3][1],
				  F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS[3][2],
				  F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS[3][3],
				  [ 1321, 1, fmp5ReqIndex_R, fmp5Score_R1,
					[ [ FMP5_1_R_SCORE, FIN_1, A, FMP5_ROLLED, fmp5rFW ] ] ], 
				  [ 1321, 1, fmp5ReqIndex_S, fmp5Score_S1,
					[ [ FMP5_1_S_SCORE, FIN_1, A, FMP5_SLAP, fmp5sFW ] ] ],
				  [ 1326, 1, pc2ReqIndex_R, pc2Score_R1,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_ROLLED, pc2rFW ] ] ],
				  [ 1326, 1, pc2ReqIndex_S, pc2Score_S1,
					[ [ PC2_1_S_SCORE, FIN_1, A, PC2_SLAP, pc2sFW ] ] ] ]
			]
		F105A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS_MULTI_AXIS_A = 
			[ F105_EXT_ID, FMP5_1_R_SCORE_A_S106 + FMP5_1_S_SCORE_A_S106 + pc2Score_R1 + pc2Score_S1, true, 
				[ F105A_CAND_INFO_LIST_BY_FMP5_RS_MULTI_AXIS_A[3][0], 
				  F105A_CAND_INFO_LIST_BY_FMP5_RS_MULTI_AXIS_A[3][1],
				  [ 326, 1, pc2ReqIndex_R, pc2Score_R1,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_ROLLED, pc2rFW ] ] ],
				  [ 326, 1, pc2ReqIndex_S, pc2Score_S1,
					[ [ PC2_1_S_SCORE, FIN_1, A, PC2_SLAP, pc2sFW ] ] ] ]
			]
		F107A_CAND_INFO_LIST_BY_PC2_RS_FMP5_R_MULTI_AXIS_A = 
			[ F107_EXT_ID, FMP5_1_R_SCORE_A_S116 + pc2Score_R1 + pc2Score_S1, true, 
				[ [ 321, 1, fmp5ReqIndex_R, FMP5_1_R_SCORE_A_S116,
					[ [ FMP5_1_R_SCORE_A_S116, FIN_1, A, FMP5_ROLLED, fmp5rFW ] ] ],
				  [ 326, 1, pc2ReqIndex_R, pc2Score_R1,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_ROLLED, pc2rFW ] ] ],
				  [ 326, 1, pc2ReqIndex_S, pc2Score_S1,
					[ [ PC2_1_S_SCORE, FIN_1, A, PC2_SLAP, pc2sFW ] ] ] ]
			]
		F_123_ABC_HIGH_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS =
			[ F_123_ABC_HIGH_EXT_ID, pc2R1S1_fmp5R1S1_score, true, F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS_2SCOPE[3] ]
		F_ABC_123_HIGH_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS =
			[ F_ABC_123_HIGH_EXT_ID, pc2R1S1_fmp5R1S1_score, true, F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS_2SCOPE[3] ]
		F_BBC_123_HIGH_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS =
			[ F_BBC_123_HIGH_EXT_ID, pc2R1S1_fmp5R1S1_score, true, F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS_2SCOPE[3] ]
		F_123_ABC_LOW_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS =
			[ F_123_ABC_LOW_EXT_ID, FMP5_1_R_SCORE_A_S106 + FMP5_1_S_SCORE_A_S106 + pc2Score_R1 + pc2Score_S1, true,
				[ F105A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS_MULTI_AXIS_A[3][0],
				  F105A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS_MULTI_AXIS_A[3][1],
				  F105A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS_MULTI_AXIS_A[3][2],
				  F105A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS_MULTI_AXIS_A[3][3],
				  [ 1321, 1, fmp5ReqIndex_R, FMP5_1_R_SCORE_A_S106,
					[ [ FMP5_1_R_SCORE_A_S106, FIN_1, A, FMP5_ROLLED, fmp5rFW ] ] ],
				  [ 1321, 1, fmp5ReqIndex_S, FMP5_1_S_SCORE_A_S106,
					[ [ FMP5_1_S_SCORE_A_S106, FIN_1, A, FMP5_SLAP, fmp5sFW ] ] ],
				  [ 1326, 1, pc2ReqIndex_R, pc2Score_R1,
					[ [ PC2_1_R_SCORE, FIN_1, A, PC2_ROLLED, pc2rFW ] ] ],
				  [ 1326, 1, pc2ReqIndex_S, pc2Score_S1,
					[ [ PC2_1_S_SCORE, FIN_1, A, PC2_SLAP, pc2sFW ] ] ] ]
			]
		F_ABC_123_LOW_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS =
			[ F_ABC_123_LOW_EXT_ID, FMP5_1_R_SCORE_A_S106 + FMP5_1_S_SCORE_A_S106 + pc2Score_R1 + pc2Score_S1, true,
				 F_123_ABC_LOW_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS[3] ]
		F_BBC_123_LOW_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS =
			[ F_ABC_123_LOW_EXT_ID, FMP5_1_R_SCORE_A_S106 + FMP5_1_S_SCORE_A_S106 + pc2Score_R1 + pc2Score_S1, true,
				 F_123_ABC_LOW_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS[3] ]
	}

	public void callInsert(String dataSrcName) {
		String filePath = getDataSrcValue(dataSrcName, FILE_TEMPLATE_PATH)
		String extId = getDataSrcValue(dataSrcName, EXTERNAL_ID)
		String binId = getDataSrcValue(dataSrcName, BIN_ID)
		setProperties(filePath, extId, binId)
		execInsertTestCase()
	}

	public void callInserts(String dataSrcName) {
		String filePathes = getDataSrcValue(dataSrcName, FILE_TEMPLATE_PATH)
		String extIds = getDataSrcValue(dataSrcName, EXTERNAL_ID)
		String binIds = getDataSrcValue(dataSrcName, BIN_ID)
		String[] filePathArry = filePathes.split(CONMA)
		String[] extIdArry = extIds.split(CONMA)
		String[] binIdArry = binIds.split(CONMA)
		for(i in 0..filePathArry.length-1){
			setProperties(filePathArry[i], extIdArry[i], binIdArry[i])
			execInsertTestCase()
		}
	}

	private void setProperties(String filePath, String extId, String binId) {
		soapuiObj.setPropertiesOtherTestSuite(COMMON_TEST_SUITE_NAME, INSERT_TEST_CASE_NAME, FILE_TEMPLATE_PATH, filePath)
		soapuiObj.setPropertiesOtherTestSuite(COMMON_TEST_SUITE_NAME, INSERT_TEST_CASE_NAME, EXTERNAL_ID, extId)
		soapuiObj.setPropertiesOtherTestSuite(COMMON_TEST_SUITE_NAME, INSERT_TEST_CASE_NAME, BIN_ID, binId)
	}

	private void execInsertTestCase() {
		def testCase = soapuiObj.getTestCaseInOtherSuite(COMMON_TEST_SUITE_NAME, INSERT_TEST_CASE_NAME)
		def executor = new TestCaseExecutor(testCase)
		def assertor = new AssertUtil(soapuiObj.getContext(), soapuiObj.getContext().testCase.name)
		def result = executor.runTestCase()
		assertor.assertEquals(result.status, Status.FINISHED, "insert result status")
	}
		
	public String mkFusionWeightElement(String value) {
		if (value.isEmpty()) {
			return ""
		}else{
			return "<fusionWeight>${value}</fusionWeight>"
		}
	}

	private String getDataSrcValue(String dataSrcName, String key) {
		return soapuiObj.getContext().expand("\${${dataSrcName}#${key}}")
	}

	public List getCandList_fingerMerge_pc2() {
		return [ F101A_CAND_INFO_LIST_BY_PC2_R, F101A_CAND_INFO_LIST_BY_PC2_R6S6 ]
	}

	public List getCandList_fingerMerge_fmp5() {
		return [ F102A_CAND_INFO_LIST_BY_FMP5_RS,
				F102A_CAND_INFO_LIST_BY_FMP5_R2S2,
				F102A_CAND_INFO_LIST_BY_FMP5_S5 ]
	}

	public List getCandList_fingerMerge_both() {
		return [ F103A_CAND_INFO_LIST_BY_PC2_R_FMP5_RS,
				F103A_CAND_INFO_LIST_BY_FMP5_R2S2,
				F103A_CAND_INFO_LIST_BY_FMP5_S5,
				F103A_CAND_INFO_LIST_BY_PC2_R6S6 ]
	}

	public List getCandList_fingerMerge_both_2scope() {
		return [ F103A_CAND_INFO_LIST_BY_PC2_R_FMP5_RS_2SCOPE,
				F103A_CAND_INFO_LIST_BY_FMP5_R2S2,
				F103A_CAND_INFO_LIST_BY_FMP5_S5,
				F103A_CAND_INFO_LIST_BY_PC2_R6S6_2SCOPE ]
	}

	public List getCandList_inquirySet1() {
		pc2ReqIndex_R = 0
		pc2ReqIndex_S = 1
		initCandInfoLists()
		return [ F101A_CAND_INFO_LIST_BY_PC2_RS ]
	}

	public List getCandList_inquirySet2() {
		fmp5ReqIndex_R = 0
		fmp5ReqIndex_S = 1
		initCandInfoLists()
		return [ F102A_CAND_INFO_LIST_BY_FMP5_RS_S106 ]
	}

	public List getCandList_inquirySet3() {
		fmp5ReqIndex_R = 0
		pc2ReqIndex_S = 1
		initCandInfoLists()
        if(level == "high") {
		    return [ F103A_CAND_INFO_LIST_BY_PC2_S_FMP5_R ]
        }else{
		    return [ F103A_CAND_INFO_LIST_BY_PC2_R_FMP5_R ]
        }
	}

	public List getCandList_inquirySet4() {
		return [ F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS ]
	}

	public List getCandList_muMerge() {
		return [ F101A_CAND_INFO_LIST_BY_PC2_RS,
				F102A_CAND_INFO_LIST_BY_FMP5_RS,
				F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS ]
	}

	public List getCandList_scope() {
		return [ F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS_2SCOPE ]
	}

	public List getCandList_multiAxis_false_1() {
		return [ F104A_CAND_INFO_LIST_BY_FMP5_R_MULTI_AXIS_A,
				F104A_CAND_INFO_LIST_BY_FMP5_R_MULTI_AXIS_B,
				F104A_CAND_INFO_LIST_BY_FMP5_R_MULTI_AXIS_C,
				F104A_CAND_INFO_LIST_BY_FMP5_R_MULTI_AXIS_D ]
	}

	public List getCandList_multiAxis_false_2() {
		fmp5ReqIndex_S = 0
		initCandInfoLists()
        if(level == "high") {
            return [ F106A_CAND_INFO_LIST_BY_FMP5_S_MULTI_AXIS_A,
                    F106A_CAND_INFO_LIST_BY_FMP5_S_MULTI_AXIS_C,
                    F106A_CAND_INFO_LIST_BY_FMP5_S_MULTI_AXIS_D ]
        } else {
            return [ F106A_CAND_INFO_LIST_BY_FMP5_R_MULTI_AXIS_A,
                    F106A_CAND_INFO_LIST_BY_FMP5_R_MULTI_AXIS_C,
                    F106A_CAND_INFO_LIST_BY_FMP5_R_MULTI_AXIS_D ]
        }
	}

	public List getCandList_multiAxis_false_3() {
		return [ F105A_CAND_INFO_LIST_BY_FMP5_RS_MULTI_AXIS_A,
				F105A_CAND_INFO_LIST_BY_FMP5_RS_MULTI_AXIS_B,
				F105A_CAND_INFO_LIST_BY_FMP5_RS_MULTI_AXIS_C,
				F105A_CAND_INFO_LIST_BY_FMP5_RS_MULTI_AXIS_D ]
	}

	public List getCandList_multiAxis_false_4() {
		return [ F105A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS_MULTI_AXIS_A,
				F105A_CAND_INFO_LIST_BY_FMP5_RS_MULTI_AXIS_B,
				F105A_CAND_INFO_LIST_BY_FMP5_RS_MULTI_AXIS_C,
				F105A_CAND_INFO_LIST_BY_FMP5_RS_MULTI_AXIS_D ]
	}

	public List getCandList_multiAxis_true_1() {
		return [ F104A_CAND_INFO_LIST_BY_FMP5_R_MULTI_AXIS_B ]
	}

	public List getCandList_multiAxis_true_2() {
		fmp5ReqIndex_S = 0
		initCandInfoLists()
        if(level == "high") {
		    return [ F106A_CAND_INFO_LIST_BY_FMP5_S_MULTI_AXIS_A ]
        }else{
		    return [ F106A_CAND_INFO_LIST_BY_FMP5_R_MULTI_AXIS_A ]
        }
	}

	public List getCandList_multiAxis_true_3() {
		return [ F105A_CAND_INFO_LIST_BY_FMP5_RS_MULTI_AXIS_A ]
	}

	public List getCandList_multiAxis_true_4() {
		return [ F105A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS_MULTI_AXIS_A ]
	}

	public List getCandList_multiAxis_true_5() {
		return [ F107A_CAND_INFO_LIST_BY_PC2_RS_FMP5_R_MULTI_AXIS_A,
				F107A_CAND_INFO_LIST_BY_FMP5_S_MULTI_AXIS_B ]
	}

	public List getCandList_multiAxis_true_6() {
		return [ F108A_CAND_INFO_LIST_BY_PC2_RS,
				F108A_CAND_INFO_LIST_BY_FMP5_RS_MULTI_AXIS_B ]
	}

	public List getCandList_fWeight(Integer fmp5rFW, Integer fmp5sFW, Integer pc2rFW, Integer pc2sFW) {
		this.fmp5rFW = fmp5rFW
		this.fmp5sFW = fmp5sFW
		this.pc2rFW = pc2rFW
		this.pc2sFW = pc2sFW
		initCandInfoLists()
		return [ F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS ]
	}

	public List getCandList_fWeight_multi(Integer fmp5rFW, Integer fmp5sFW, Integer pc2rFW, Integer pc2sFW) {
		this.fmp5rFW = fmp5rFW
		this.fmp5sFW = fmp5sFW
		this.pc2rFW = pc2rFW
		this.pc2sFW = pc2sFW
		initCandInfoLists()
		return [ F101A_CAND_INFO_LIST_BY_PC2_RS,
				F102A_CAND_INFO_LIST_BY_FMP5_RS,
				F103A_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS ]
	}

	public List getCandList_candSort() {
		return [ F_123_ABC_HIGH_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS,
				F_ABC_123_HIGH_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS,
				F_BBC_123_HIGH_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS,
				F_123_ABC_LOW_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS,
				F_ABC_123_LOW_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS,
				F_BBC_123_LOW_CAND_INFO_LIST_BY_PC2_RS_FMP5_RS ]
	}
}

