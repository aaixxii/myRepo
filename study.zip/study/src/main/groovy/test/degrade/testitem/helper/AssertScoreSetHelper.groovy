package test.degrade.testitem.helper

import common.xml.*
import common.util.*
import test.common.xml.*
import test.common.message.*
import test.degrade.util.*
import test.degrade.management.*


class AssertScoreSetHelper extends XMLAssert {
	final static String AIM_NAMESPACE_PREFIX="ns2"
	final static String AIM_NAMESPACE_URI="urn:nec:aim"
	String VALUE = "value"
	String POSITION = "position"
	String AXIS = "axis"
	def		soapuiObject
	def		aimXmlObject
	
	AssertScoreSetHelper(xml, context){
		super(xml)
        registerNamespace(AIM_NAMESPACE_PREFIX, AIM_NAMESPACE_URI)
        this.aimXmlObject = new AimXmlObject(xml)
        this.soapuiObject = new SoapuiObject(context)	
	}

	def setAssertIndividualScore(binIdList){
		def assertIndividualScoreMap = getAssertIndividualScoreMap()
		setIndividualScore(assertIndividualScoreMap, binIdList)
	}

	def setAssertCompositScoreForLIX(int pc2_Rolled_value, int pc2_Slap_value, int fmp5_Rolled_value, int fmp5_Slap_value,int pc2_FusionWeght, int fmp5_FusionWeight){
		int pc2Score 	= getMax(pc2_Rolled_value * pc2_FusionWeght/100 ,pc2_Slap_value * pc2_FusionWeght/100)
		int fmp5Score 	= getMax(fmp5_Rolled_value * fmp5_FusionWeight/100,fmp5_Slap_value * fmp5_FusionWeight/100)
		if (pc2Score + fmp5Score > 9999 ){
			setPropCompositeScore(9999)
		}else{
			setPropCompositeScore(pc2Score + fmp5Score)
		}
	}
	
	def setAssertCompositScoreForLLIX(int pc2_Latent_value, int fmp5_Latent_value, int pc2_FusionWeght, int fmp5_FusionWeight){
		if (pc2_Latent_value + fmp5_Latent_value > 9999 ){
			setPropCompositeScore(9999)
		}else{
			setPropCompositeScore(pc2_Latent_value + fmp5_Latent_value)
		}
	}

	def setAssertCompositScoreForTLIX(int pc2_Rolled_value, int pc2_Slap_value, int fmp5_Rolled_value, int fmp5_Slap_value, int pc2_FusionWeght, int fmp5_FusionWeight){
		int pc2Score 	= pc2_Rolled_value  * pc2_FusionWeght/100 + pc2_Slap_value * pc2_FusionWeght/100
		int fmp5Score 	= fmp5_Rolled_value + fmp5_Slap_value
		if (pc2Score +  fmp5Score  > 9999 ){
			setPropCompositeScore(9999)
		}else{
			setPropCompositeScore(fmp5Score + pc2Score)
		}
	}
	
	def getMax(score1, score2){
		if ( score1 > score2 ){
			return score1
		}else if ( score1 <= score2){
			return score2
		}
	}

	def getAssertIndividualScoreMap(){
		Map assertIndividualScoreMap = new HashMap()
		for (candidateTmp in aimXmlObject.getCandidates()."candidate-template"){
			String binid = candidateTmp."containerId".text()
			for (individualScore in candidateTmp."individual-score"){
				def individualList = []
				individualList = [individualScore.@"${VALUE}", individualScore.@"${POSITION}", individualScore.@"${AXIS}" ]
				assertIndividualScoreMap.put(binid, individualList)
			}
		}
		return assertIndividualScoreMap
	}	

	def setIndividualScore(assertScoreMap, binIdList){
		String keyRoot
		List assertScoreList
		for ( binId in binIdList ){
			switch (binId){
			case "3":
				keyRoot = "Fmp5_Rolled_"
				break
			case "4":
				keyRoot = "Fmp5_Slap_"
				break
			case "323":
				keyRoot = "Pc2_Rolled_"
				break
			case "324":
				keyRoot = "Pc2_Slap_"
				break
			case "321":
				keyRoot = "Fmp5_Latent_"
				break
			case "326":
				keyRoot = "Pc2_Latent_"
				break
			}
			setPropIndividualScore(keyRoot, assertScoreMap[binId])
		}
	}

	def setPropIndividualScore(String keyRoot, List assertScoreList){
		soapuiObject.setProperties(keyRoot + "${VALUE}" ,assertScoreList[0] as String)
		soapuiObject.setProperties(keyRoot + "${POSITION}" ,assertScoreList[1] as String)
		soapuiObject.setProperties(keyRoot + "${AXIS}" ,assertScoreList[2] as String)
	}

	def setPropCompositeScore(def compositScore){
		String key = "compositScore"
        soapuiObject.setProperties(key , compositScore as String)
    }
}
