package test.degrade.testitem.helper.option


class PrefilterOptionsCreateHelper extends TestOptionsCreateHelper {
	
	static final String PREFILTER_OPTIONS_HEAD = "<prefilter-options "
	static final String USE_PREFILTER_INFO_HEAD = "<use-prefilter-info "
	static final String PREFILTER_OPTIONS_END = "</prefilter-options>"
	static final String UPDATE_PREFILTER = "updatePrefilter"
	static final String YOB_METHOD = "yobMethod"
	static final String USE_YOB_F_RANGE = "useYobFRange"
	static final String USE_GEN = "useGender"
	static final String USE_RACE = "useRace"
	static final String USE_YOB = "useYob"
	static final String USE_REGION = "useRegion"

	def createPrefilterOptions(def updatePrefilter, def yobMethod, def useYobFRange){
		return PREFILTER_OPTIONS_HEAD + 
				makeAttribute(UPDATE_PREFILTER, updatePrefilter) +
				makeAttribute(YOB_METHOD, yobMethod) +
				makeAttribute(USE_YOB_F_RANGE, useYobFRange) +
				END_2
	}

	def createPrefilterOptions(def updatePrefilter, def yobMethod, def useYobFRange,
							   def useGender, def useRace, def useYob, def useRegion){
		return PREFILTER_OPTIONS_HEAD + 
				makeAttribute(UPDATE_PREFILTER, updatePrefilter) +
				makeAttribute(YOB_METHOD, yobMethod) +
				makeAttribute(USE_YOB_F_RANGE, useYobFRange) +
				END_1 + LINE_FEED_CODE +
				createUsePrefilterInfo(useGender, useRace, useYob, useRegion) + LINE_FEED_CODE + 
				PREFILTER_OPTIONS_END
	}

	def createUsePrefilterInfo(def useGender, def useRace, def useYob, def useRegion){
		return USE_PREFILTER_INFO_HEAD + 
				makeAttribute(USE_GEN, useGender) +
				makeAttribute(USE_RACE, useRace) +
				makeAttribute(USE_YOB, useYob) +
				makeAttribute(USE_REGION, useRegion) +
				END_2
	}
}
