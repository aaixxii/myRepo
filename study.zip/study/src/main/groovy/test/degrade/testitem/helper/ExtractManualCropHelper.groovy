package test.degrade.testitem.helper

import common.util.TextFormatter;

import test.degrade.util.SoapuiObject
import test.common.format.*
import test.common.format.extraction.payload.factory.CropInfoFactory;
import test.common.format.extraction.payload.impl.CropInfo
import test.common.format.extraction.payload.impl.CropPoints;

class ExtractManualCropHelper {
	
	private static final String CROP_INFO_PRE = "<crop-info>"
	private static final String CROP_POINTS_PRE = "<crop-points>"
	private static final String CROP_POINTS_SUF = "</crop-points>"
	private static final String CENTER_PRE = "<center"
	private static final String POINTS_PRE = "<points"
	
	protected SoapuiObject soapuiObj
	private int angleBase = 0
	
	public ExtractManualCropHelper(def context){
		this.soapuiObj = new SoapuiObject(context)
	}

	public String insertSegInfos(String imageXml, int pos) {
		if(pos <= 10){
			imageXml = insertSegInfoRoll(imageXml, pos, pos)
		}else if(pos == 11){
			imageXml = insertSegInfo4411(imageXml, pos, 1)
		}else if(pos == 12){
			imageXml = insertSegInfo4411(imageXml, pos, 6)
		}else if(pos == 13){
			for(i in 2..5)
				imageXml = insertSegInfo(imageXml, pos, i)
		}else if(pos == 14){
			for(i in 7..10)
				imageXml = insertSegInfo(imageXml, pos, i)
		}else if(pos == 15){
			imageXml = insertSegInfo(imageXml, pos, 1)
			imageXml = insertSegInfo(imageXml, pos, 6)
		}else if(pos >= 40){
			imageXml = insertSegInfoSegmented(imageXml, pos)
		}
		return imageXml
	}
	
	public String insertSegInfos1000dpi(String imageXml, int pos) {
		if(pos <= 10){
			imageXml = insertSegInfoRoll(imageXml, pos, pos)
		}else if(pos == 11){
			imageXml = insertSegInfo442_1000dpi(imageXml, pos, 1)
		}else if(pos == 12){
			imageXml = insertSegInfo442_1000dpi(imageXml, pos, 6)
		}else if(pos == 13){
			for(i in 2..5)
				imageXml = insertSegInfo442_1000dpi(imageXml, pos, i)
		}else if(pos == 14){
			for(i in 7..10)
				imageXml = insertSegInfo442_1000dpi(imageXml, pos, i)
		}else if(pos == 15){
			imageXml = insertSegInfo442_1000dpi(imageXml, pos, 1)
			imageXml = insertSegInfo442_1000dpi(imageXml, pos, 6)
		}else if(pos >= 40){
			imageXml = insertSegInfoSegmented(imageXml, pos)
		}
		return imageXml
	}
	
	public String insertSegInfosFromTestSuiteProperty(String imageXml, int pos) {
		if(pos <= 10){
			imageXml = insertSegInfoRoll(imageXml, pos, pos)
		}else if(pos == 11){
			imageXml = insertSegInfo4411FromTestSuiteProperty(imageXml, pos, 1)
		}else if(pos == 12){
			imageXml = insertSegInfo4411FromTestSuiteProperty(imageXml, pos, 6)
		}else if(pos == 13){
			for(i in 2..5)
				imageXml = insertSegInfoFromTestSuiteProperty(imageXml, pos, i)
		}else if(pos == 14){
			for(i in 7..10)
				imageXml = insertSegInfoFromTestSuiteProperty(imageXml, pos, i)
		}else if(pos == 15){
			imageXml = insertSegInfoFromTestSuiteProperty(imageXml, pos, 1)
			imageXml = insertSegInfoFromTestSuiteProperty(imageXml, pos, 6)
		}else if(pos >= 40){
			imageXml = insertSegInfoSegmented(imageXml, pos)
		}
		return imageXml
	}
	
	// 4-4-2
	public String insertSegInfo(String imageXml, int pos, int segPos){
		String xAKey = "442_pos${segPos}_xA"
		String yAKey = "442_pos${segPos}_yA"
		String xBKey = "442_pos${segPos}_xB"
		String yBKey = "442_pos${segPos}_yB"
		String xCKey = "442_pos${segPos}_xC"
		String yCKey = "442_pos${segPos}_yC"
		String xDKey = "442_pos${segPos}_xD"
		String yDKey = "442_pos${segPos}_yD"
		return insertSegInfoFromProjectProperty(imageXml, pos, segPos, 
			xAKey, yAKey, xBKey, yBKey, xCKey, yCKey, xDKey, yDKey)
	}

	public String insertSegInfoFromTestSuiteProperty(String imageXml, int pos, int segPos){
		String xAKey = "442_pos${segPos}_xA"
		String yAKey = "442_pos${segPos}_yA"
		String xBKey = "442_pos${segPos}_xB"
		String yBKey = "442_pos${segPos}_yB"
		String xCKey = "442_pos${segPos}_xC"
		String yCKey = "442_pos${segPos}_yC"
		String xDKey = "442_pos${segPos}_xD"
		String yDKey = "442_pos${segPos}_yD"
		return insertSegInfoFromTestSuiteProperty(imageXml, pos, segPos, 
			xAKey, yAKey, xBKey, yBKey, xCKey, yCKey, xDKey, yDKey)
	}

	public String insertSegInfo4411(String imageXml, int pos, int segPos){
		String xAKey = "4411_pos${segPos}_xA"
		String yAKey = "4411_pos${segPos}_yA"
		String xBKey = "4411_pos${segPos}_xB"
		String yBKey = "4411_pos${segPos}_yB"
		String xCKey = "4411_pos${segPos}_xC"
		String yCKey = "4411_pos${segPos}_yC"
		String xDKey = "4411_pos${segPos}_xD"
		String yDKey = "4411_pos${segPos}_yD"
		return insertSegInfoFromProjectProperty(imageXml, pos, segPos, 
			xAKey, yAKey, xBKey, yBKey, xCKey, yCKey, xDKey, yDKey)
	}
	
	public String insertSegInfo4411FromTestSuiteProperty(String imageXml, int pos, int segPos){
		String xAKey = "4411_pos${segPos}_xA"
		String yAKey = "4411_pos${segPos}_yA"
		String xBKey = "4411_pos${segPos}_xB"
		String yBKey = "4411_pos${segPos}_yB"
		String xCKey = "4411_pos${segPos}_xC"
		String yCKey = "4411_pos${segPos}_yC"
		String xDKey = "4411_pos${segPos}_xD"
		String yDKey = "4411_pos${segPos}_yD"
		return insertSegInfoFromTestSuiteProperty(imageXml, pos, segPos, 
			xAKey, yAKey, xBKey, yBKey, xCKey, yCKey, xDKey, yDKey)
	}
	
	public String insertSegInfoSegmented(String imageXml, int pos){
		int segPos = ImagePositionConvertor.convertFromNistPos(pos)
		return insertSegInfoRoll(imageXml, pos, segPos)
	}
	
	public String insertSegInfoRoll(String imageXml, int pos, int segPos){
		int xA = 10
		int yA = 10
		int xB = 500
		int yB = 10
		int xC = 500
		int yC = 500
		int xD = 10
		int yD = 500
		int xCenter = (xA + xC) / 2
		int yCenter = (yB + yC) / 2
		return AimXmlFormatter.insertSegInfo(imageXml, pos, segPos, false,
					xCenter, yCenter, (float)(angleBase * Math.PI),
					xA, yA, xB, yB, xC, yC, xD, yD)
	}
	
	public String insertSegInfo442_1000dpi(String imageXml, int pos, int segPos){
		String xAKey = "442_pos${segPos}_xA_1000dpi"
		String yAKey = "442_pos${segPos}_yA_1000dpi"
		String xBKey = "442_pos${segPos}_xB_1000dpi"
		String yBKey = "442_pos${segPos}_yB_1000dpi"
		String xCKey = "442_pos${segPos}_xC_1000dpi"
		String yCKey = "442_pos${segPos}_yC_1000dpi"
		String xDKey = "442_pos${segPos}_xD_1000dpi"
		String yDKey = "442_pos${segPos}_yD_1000dpi"
		return insertSegInfoFromProjectProperty(imageXml, pos, segPos, 
			xAKey, yAKey, xBKey, yBKey, xCKey, yCKey, xDKey, yDKey)
	}
	
	private insertSegInfoFromProjectProperty(String imageXml, int pos, int segPos, 
		String xAKey, String yAKey, String xBKey, String yBKey, 
		String xCKey, String yCKey, String xDKey, String yDKey) {
		
		int xA = soapuiObj.getProjectProperty(xAKey) as int
		int yA = soapuiObj.getProjectProperty(yAKey) as int
		int xB = soapuiObj.getProjectProperty(xBKey) as int
		int yB = soapuiObj.getProjectProperty(yBKey) as int
		int xC = soapuiObj.getProjectProperty(xCKey) as int
		int yC = soapuiObj.getProjectProperty(yCKey) as int
		int xD = soapuiObj.getProjectProperty(xDKey) as int
		int yD = soapuiObj.getProjectProperty(yDKey) as int
		int xCenter = (xA + xC) / 2
		int yCenter = (yB + yC) / 2
		return AimXmlFormatter.insertSegInfo(imageXml, pos, segPos, false,
		xCenter, yCenter, (float)(angleBase * Math.PI),
		xA, yA, xB, yB, xC, yC, xD, yD)
	}
	
	public insertSegInfoFromTestSuiteProperty(String imageXml, int pos, int segPos, 
		String xAKey, String yAKey, String xBKey, String yBKey, 
		String xCKey, String yCKey, String xDKey, String yDKey) {
		int xA = soapuiObj.getTestSuiteProperty(xAKey) as int
		int yA = soapuiObj.getTestSuiteProperty(yAKey) as int
		int xB = soapuiObj.getTestSuiteProperty(xBKey) as int
		int yB = soapuiObj.getTestSuiteProperty(yBKey) as int
		int xC = soapuiObj.getTestSuiteProperty(xCKey) as int
		int yC = soapuiObj.getTestSuiteProperty(yCKey) as int
		int xD = soapuiObj.getTestSuiteProperty(xDKey) as int
		int yD = soapuiObj.getTestSuiteProperty(yDKey) as int
		int xCenter = (xA + xC) / 2
		int yCenter = (yB + yC) / 2
		return AimXmlFormatter.insertSegInfo(imageXml, pos, segPos, false,
		xCenter, yCenter, (float)(angleBase * Math.PI),
		xA, yA, xB, yB, xC, yC, xD, yD)
	}
	
	public String deleteAngle(String imagesXml, int segPos){
		String cropPoints = "<crop-points>"
		String angle = "angle="
		String segInfo = "<seg-info pos='${segPos}'"
		int segInfoIndex = imagesXml.indexOf(segInfo)
		int beforeAngleIndex = imagesXml.indexOf(angle, segInfoIndex+1)
		int cropPointsIndex = imagesXml.indexOf(cropPoints, segInfoIndex+1)
		String imageXml1st = imagesXml.substring(0, beforeAngleIndex) + "/>"
		String imageXml2nd = imagesXml.substring(cropPointsIndex)
		return imageXml1st + imageXml2nd
	}
	
	public String replace2DummyPoint(String imagesXml, int segPos){
		String segInfo = "<seg-info pos='${segPos}'"
		int segInfoIndex = imagesXml.indexOf(segInfo)
		int preCropPointsLastIndex = imagesXml.indexOf(POINTS_PRE, segInfoIndex+1)
		int sufCropPointsStartIndex = imagesXml.indexOf(CROP_POINTS_SUF, segInfoIndex+1)
		String imageXml1st = imagesXml.substring(0, preCropPointsLastIndex)
		String imageXml2nd = imagesXml.substring(sufCropPointsStartIndex)
		return imageXml1st + "<points X='0' Y='0' />" + "<points X='512' Y='512' />" + imageXml2nd
	}
	
	public String deleteCenter(String imagesXml, int segPos){
		String segInfo = "<seg-info pos='${segPos}'"
		return TextFormatter.deleteStr(imagesXml, segInfo, CENTER_PRE, CROP_POINTS_PRE)
	}
	
	public String deltePointBD(String imagesXml, int segPos){
		String segInfo = "<seg-info pos='${segPos}'"
		int segInfoIndex = imagesXml.indexOf(segInfo)
		int index = imagesXml.indexOf(POINTS_PRE, segInfoIndex+1)
		index = imagesXml.indexOf(POINTS_PRE, index+1)
		String imageXml1st = imagesXml.substring(0, index)
		index = imagesXml.indexOf(POINTS_PRE, index+1) // 3rd points
		String imageXml2nd = imagesXml.substring(index)
		imagesXml =  imageXml1st + imageXml2nd
		
		segInfoIndex = imagesXml.indexOf(segInfo)
		index = imagesXml.indexOf(POINTS_PRE, segInfoIndex+1)
		index = imagesXml.indexOf(POINTS_PRE, index+1)
		index = imagesXml.indexOf(POINTS_PRE, index+1)
		imageXml1st = imagesXml.substring(0, index)
		index = imagesXml.indexOf(CROP_POINTS_SUF, index+1)
		imageXml2nd = imagesXml.substring(index)
		imagesXml =  imageXml1st + imageXml2nd
		return imagesXml
	}
	
	public Map<Integer, CropInfo> createCropInfoMap(String imagesXml){
		Map<Integer, CropInfo> cropInfoMap = new HashMap<Integer, CropInfo>()
		Node root = new XmlParser().parseText("<root>" + imagesXml + "</root>")
		for(Node imageNode in root.image){
			int pos = imageNode.attribute("pos") as int
			putCropInfos(pos, imageNode, cropInfoMap)
		}
		return cropInfoMap
	}

	private void putCropInfos(int pos, Node imageNode, Map<Integer, CropInfo> cropInfoMap) {
		for(Node segInfo in imageNode."seg-info"){
			int segPos = segInfo.attribute("pos") as int
			if(isSlapPos(pos)){
				segPos = ImagePositionConvertor.convertToSlapNistPos(segPos)
			}
			Node cropInfoNode = segInfo."crop-info"[0]
			CropInfo cropInfo = CropInfoFactory.createFromInput(cropInfoNode)
			cropInfoMap.put(segPos, cropInfo)
		}
	}

	private boolean isSlapPos(int pos){
		if(11 <= pos && pos <= 15){
			return true
		}else if(40 <= pos && pos <= 47){
			return true
		}else{
			return false
		}
	}


	/*
	 * start izumi edit
	 */
	
	public String insertSegInfos(String imageXml, int pos, String segInfo){
		imageXml = insertSegInfoRoll(imageXml, pos, pos, segInfo)
		return imageXml
	}		
	
	public String insertSegInfoRoll(String imageXml, int pos, int segPos, String segInfo){
		return AimXmlFormatter.insertSegInfo(imageXml, pos, segPos, false, segInfo)
	}
	
	public String insertSegInfoslap(String imageXml, int pos , segInfo){
		if(pos == 13){
			int j = 0
			for(i in 2..5){
				imageXml = insertSegInfoRoll(imageXml, pos , i, segInfo[j])
				j = j + 1
			}
		}else if(pos == 14){
			int j= 0
			for(i in 7..10){
				imageXml = insertSegInfoRoll(imageXml, pos, i, segInfo[j])
				j = j + 1
			}
		}
		return imageXml
	}
	
	/*
	 *  end izumi edit
	 */
	


}

