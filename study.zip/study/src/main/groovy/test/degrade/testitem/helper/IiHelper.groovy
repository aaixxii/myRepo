package test.degrade.testitem.helper

import test.degrade.management.AbendProcessor
import test.common.constants.aim.*
import test.degrade.testitem.holder.IrisExtractResultHolder
import static test.common.constants.data.ImageDataList.*
import static test.common.constants.aim.AIMWord.*

class IiHelper extends PayloadHelper {

    private static final String PROJECT_NAME = "Iris_II"

	private static final String EXT_ID_GENDER_M = "${PROJECT_NAME}-M"
	private static final String EXT_ID_GENDER_F = "${PROJECT_NAME}-F"
	private static final String EXT_ID_GENDER_U = "${PROJECT_NAME}-U"

	private static final String EXT_ID_YOB_2000 = "${PROJECT_NAME}-2000"
	private static final String EXT_ID_YOB_2010 = "${PROJECT_NAME}-2010"
	private static final String EXT_ID_YOB_UKNOWN = "${PROJECT_NAME}--1"

	private static final String EXT_ID_YOB_1969_3 = "${PROJECT_NAME}-1969-3"
	private static final String EXT_ID_YOB_1970_0 = "${PROJECT_NAME}-1970-0"
	private static final String EXT_ID_YOB_1973_0 = "${PROJECT_NAME}-1973-0"
	private static final String EXT_ID_YOB_1973_1 = "${PROJECT_NAME}-1973-1"
	private static final String EXT_ID_YOB_1974_0 = "${PROJECT_NAME}-1974-0"
	private static final String EXT_ID_YOB_1978_1 = "${PROJECT_NAME}-1978-1"
	private static final String EXT_ID_YOB_1979_0 = "${PROJECT_NAME}-1979-0"
	private static final String EXT_ID_YOB_1984_0 = "${PROJECT_NAME}-1984-0"
	private static final String EXT_ID_YOB_1985_0 = "${PROJECT_NAME}-1985-0"
	private static final String EXT_ID_YOB_1985_1 = "${PROJECT_NAME}-1985-1"
	private static final String EXT_ID_YOB_1988_0 = "${PROJECT_NAME}-1988-0"
	private static final String EXT_ID_YOB_1989_3 = "${PROJECT_NAME}-1989-3"

	private static final String EXT_ID_RACE_WHITE = "${PROJECT_NAME}-1"
	private static final String EXT_ID_RACE_BLACK = "${PROJECT_NAME}-2"
	private static final String EXT_ID_RACE_AMERICAN_INDIAN = "${PROJECT_NAME}-4"
	private static final String EXT_ID_RACE_ASIAN = "${PROJECT_NAME}-8"
	private static final String EXT_ID_RACE_UNKNOWN = "${PROJECT_NAME}--1"

	private static final String EXT_ID_REGION_1 = "${PROJECT_NAME}-1"
	private static final String EXT_ID_REGION_2 = "${PROJECT_NAME}-2"
	private static final String EXT_ID_REGION_3 = "${PROJECT_NAME}-3"
	private static final String EXT_ID_REGION_4 = "${PROJECT_NAME}-4"
	private static final String EXT_ID_REGION_5 = "${PROJECT_NAME}-5"
	private static final String EXT_ID_REGION_6 = "${PROJECT_NAME}-6"
	private static final String EXT_ID_REGION_7 = "${PROJECT_NAME}-7"
	private static final String EXT_ID_REGION_8 = "${PROJECT_NAME}-8"
	private static final String EXT_ID_REGION_9 = "${PROJECT_NAME}-9"
	private static final String EXT_ID_REGION_A = "${PROJECT_NAME}-A"
	private static final String EXT_ID_REGION_B = "${PROJECT_NAME}-B"
	private static final String EXT_ID_REGION_C = "${PROJECT_NAME}-C"
	private static final String EXT_ID_REGION_D = "${PROJECT_NAME}-D"
	private static final String EXT_ID_REGION_E = "${PROJECT_NAME}-E"
	private static final String EXT_ID_REGION_F = "${PROJECT_NAME}-F"
	private static final String EXT_ID_REGION_U = "${PROJECT_NAME}-U"

	private static final String EXT_ID_PRIORITY = "${PROJECT_NAME}-priority"

	private static final String EXT_ID_MIN_SCORE_LOW = "${PROJECT_NAME}-minScore-1"
	private static final String EXT_ID_MIN_SCORE_HIGH = "${PROJECT_NAME}-minScore-2"

	private static final String EXT_ID_DYN_TH_LOW = "${PROJECT_NAME}-dynTh-1"
	private static final String EXT_ID_DYN_TH_HIGH = "${PROJECT_NAME}-dynTh-2"

	private static final String EXT_ID_SEARCH_MODE = "${PROJECT_NAME}-searchMode"

	private static final String EXT_ID_ROTATION = "${PROJECT_NAME}-rotationLimit"

	private static final String EXT_ID_AFIS_SCRIPT_LOW = "${PROJECT_NAME}-afisScript-1"
	private static final String EXT_ID_AFIS_SCRIPT_HIGH = "${PROJECT_NAME}-afisScript-2"

	private static final String EXT_ID_SCOPE_1 = "${PROJECT_NAME}-scope-1"
	private static final String EXT_ID_SCOPE_2 = "${PROJECT_NAME}-scope-2"
	private static final String EXT_ID_SCOPE_3 = "${PROJECT_NAME}-scope-3"

	private static final String EXT_ID_CROSS_MATCH_RL = "${PROJECT_NAME}-crossMatch-RL"
	private static final String EXT_ID_CROSS_MATCH_R = "${PROJECT_NAME}-crossMatch-R"
	private static final String EXT_ID_CROSS_MATCH_L = "${PROJECT_NAME}-crossMatch-L"

    private static final int IDB_SCOPE_1_CON_ID = 343
    private static final int IDB_SCOPE_2_CON_ID = 1343
    private static final int IDB_SCOPE_3_CON_ID = 2343
    private static final int EVENT_1 = 1
    private static final int S_REQ_0 = 0
    private static final int POS_0 = 0
    private static final int POS_1 = 1
    private static final int POINT_POS_R = 60
    private static final int POINT_POS_L = 61

    private static final int MAX_SCORE = 9999
    private static final int ZERO_SCORE = 0

	private static String TRUE = "true"
	private static String FALSE = "false"

    private static int j2kRRScore
    private static int j2kRRScoreSmode1
    private static int j2kRRScoreSmode3
    private static int j2kRRScoreRotation0
    private static int j2kRLScore
    private static int j2kLRScore
    private static int j2kLLScore
    private static int j2kLLScoreSmode1
    private static int j2kLLScoreSmode3
    private static int j2kLLScoreRotation0
    private static int j2kFScore
    private static int j2kIRScore
    private static int j2kILScore
     
    private static int pngRRScore
    private static int pngRLScore
    private static int pngLRScore
    private static int pngLLScore
    private static int pngFScore
    private static int pngIRScore
    private static int pngILScore
    private static int pngRRScoreSmode1
    private static int pngRRScoreSmode3
    private static int pngLLScoreSmode1
    private static int pngLLScoreSmode3

    private static int maxRRScore
    private static int maxRLScore
    private static int maxLRScore
    private static int maxLLScore
    private static int maxFScore
    private static int maxIRScore
    private static int maxILScore

    private IrisCommonHelper commonHelper
    private int targetContainerId
    private boolean isHit
    static boolean ommitSearchPayload
    static List scopeList
    static List searchContainerList

    IiHelper(context) {
        super(context)
        this.commonHelper = new IrisCommonHelper(context)
        this.targetContainerId = IDB_SCOPE_1_CON_ID
        this.isHit = true
        initAssertionScore()
    }

    protected void initPayloadMap() {
        payloadMap = new IrisPayloadMap()
        commonOptMap = new CommonOptMapNoCallbackUrl().getDefaultParamMap()
        updateCommonOptVal("maxCandidates", "100")
        ommitSearchPayload = false
        scopeList = [ 1 ]
        searchContainerList = [ 343 ]
    }

    public String makePayload() {
        if(ommitSearchPayload) {
            return ""
        }
        StringBuilder sb = new StringBuilder()
        sb.append("<search-inputs-payload>\n")
        sb.append("<ns2:search-inputs-payload xmlns:ns2='urn:nec:aim'>\n")
        sb.append("<meta-info>\n")
        sb.append(makeMetaCommonXml())
        sb.append("</meta-info>\n")
        sb.append(makePrefilterOptXml())
        sb.append(makeIrisOptionsXml())
        sb.append("</ns2:search-inputs-payload>\n")
        sb.append("</search-inputs-payload>\n")
        return sb.toString()
    }

    public String makeAfisGroupIdXml() {
        StringBuilder sb = new StringBuilder()
        for(id in scopeList) {
            sb.append("<afis_group_Id>${id}</afis_group_Id>\n")
        }
        return sb.toString()
    }

    public String makeSearchContainerXml() {
        StringBuilder sb = new StringBuilder()
        for(id in searchContainerList) {
            sb.append("<searchContainer>${id}</searchContainer>\n")
        }
        return sb.toString()
    }

    public String getDefaultFileImgXml() {
        return commonHelper.getDefaultFileImgXml()
    }

    public String getDefaultSearchImgXml() {
        return commonHelper.getDefaultSearchImgXml()
    }

    public String getJ2kFileImgXml() {
        return getDefaultFileImgXml()
    }

    public String getJ2kSearchImgXml() {
        return getDefaultSearchImgXml()
    }

    public List getCandList_updatePrefilter(int id) {
        List candInfoList = []
        switch(id) {
            case 1:
            case 3:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_F) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_U) )
                break
            case 2:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_M) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_U) )
                break
            case 4:
            case 6:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_F, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_U, FALSE) )
                break
            case 5:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_M, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_U, FALSE) )
                break
            default:
                abendTest()
        }
        return candInfoList
    }

    public List getCandList_useGender(int id) {
        List candInfoList = []
        switch(id) {
            case 1:
            case 2:
            case 5:
            case 6:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_M) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_F) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_U) )
                break
            case 3:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_M) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_U) )
                break
            case 4:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_F) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_U) )
                break
            case 7:
            case 8:
            case 11:
            case 12:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_M, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_F, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_U, FALSE) )
                break
            case 9:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_M, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_U, FALSE) )
                break
            case 10:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_F, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_U, FALSE) )
                break
            default:
                abendTest(id)
        }
        return candInfoList
    }

    public List getCandList_gender(int id) {
        List candInfoList = []
        switch(id) {
            case 1:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_M) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_U) )
                break
            case 2:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_F) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_U) )
                break
            case 3:
            case 4:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_M) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_F) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_U) )
                break
            case 5:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_M, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_U, FALSE) )
                break
            case 6:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_F, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_U, FALSE) )
                break
            case 7:
            case 8:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_M, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_F, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_U, FALSE) )
                break
            default:
                abendTest(id)
        }
        return candInfoList
    }

    public List getCandList_useYob(int id) {
        List candInfoList = []
        switch(id) {
            case 1:
            case 2:
            case 5:
            case 6:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_2000) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_2010) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_UKNOWN) )
                break
            case 3:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_2000) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_UKNOWN) )
                break
            case 4:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_2010) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_UKNOWN) )
                break
            case 7:
            case 8:
            case 11:
            case 12:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_2000, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_2010, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_UKNOWN, FALSE) )
                break
            case 9:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_2000, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_UKNOWN, FALSE) )
                break
            case 10:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_2010, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_UKNOWN, FALSE) )
                break
            default:
                abendTest(id)
        }
        return candInfoList
    }

    public List getCandList_yob(int id) {
        List candInfoList = []
        switch(id) {
            case 1:
            case 3:
            case 6:
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1969_3) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1970_0) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1973_0) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1973_1) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1974_0) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1978_1) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1979_0) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1984_0) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1985_0) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1985_1) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1988_0) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1989_3) )
                break
            case 2:
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1973_1) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1974_0) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1978_1) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1979_0) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1984_0) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1985_1) )
                break
            case 4:
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1970_0) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1973_0) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1973_1) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1974_0) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1978_1) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1979_0) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1984_0) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1985_0) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1985_1) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1988_0) )
                break
            case 5:
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1979_0) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1984_0) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1985_0) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1985_1) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1988_0) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1989_3) )
                break
            case 9:
            case 11:
            case 14:
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1969_3, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1970_0, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1973_0, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1973_1, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1974_0, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1978_1, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1979_0, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1984_0, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1985_0, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1985_1, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1988_0, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1989_3, FALSE) )
                break
            case 10:
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1973_1, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1974_0, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1978_1, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1979_0, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1984_0, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1985_1, FALSE) )
                break
            case 12:
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1970_0, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1973_0, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1973_1, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1974_0, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1978_1, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1979_0, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1984_0, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1985_0, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1985_1, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1988_0, FALSE) )
                break
            case 13:
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1979_0, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1984_0, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1985_0, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1985_1, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1988_0, FALSE) )
                candInfoList.add( makeMaxScoreCand(EXT_ID_YOB_1989_3, FALSE) )
                break
        }
        return candInfoList
    }

    public List getCandList_useRace(int id) {
        List candInfoList = []
        switch(id) {
            case 1:
            case 2:
            case 5:
            case 6:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_RACE_WHITE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_RACE_ASIAN) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_RACE_UNKNOWN) )
                break
            case 3:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_RACE_WHITE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_RACE_UNKNOWN) )
                break
            case 4:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_RACE_ASIAN) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_RACE_UNKNOWN) )
                break
            case 7:
            case 8:
            case 11:
            case 12:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_RACE_WHITE, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_RACE_ASIAN, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_RACE_UNKNOWN, FALSE) )
                break
            case 9:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_RACE_WHITE, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_RACE_UNKNOWN, FALSE) )
                break
            case 10:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_RACE_ASIAN, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_RACE_UNKNOWN, FALSE) )
                break
            default:
                abendTest(id)
        }
        return candInfoList
    }

    public List getCandList_race(int id) {
        List candInfoList = []
        switch(id) {
            case 1:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_RACE_WHITE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_RACE_UNKNOWN) )
                break
            case 2:
            case 3:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_RACE_WHITE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_RACE_BLACK) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_RACE_AMERICAN_INDIAN) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_RACE_ASIAN) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_RACE_UNKNOWN) )
                break
            case 4:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_RACE_WHITE, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_RACE_UNKNOWN, FALSE) )
                break
            case 5:
            case 6:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_RACE_WHITE, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_RACE_BLACK, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_RACE_AMERICAN_INDIAN, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_RACE_ASIAN, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_RACE_UNKNOWN, FALSE) )
                break
            default:
                abendTest(id)
        }
        return candInfoList
    }

    public List getCandList_useRegion(int id) {
        List candInfoList = []
        switch(id) {
            case 1:
            case 2:
            case 5:
            case 6:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_1) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_9) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_A) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_F) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_U) )
                break
            case 3:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_1) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_U) )
                break
            case 4:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_F) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_U) )
				break;
            case 7:
            case 8:
            case 11:
            case 12:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_1, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_9, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_A, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_F, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_U, FALSE) )
                break
            case 9:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_1, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_U, FALSE) )
                break
            case 10:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_F, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_U, FALSE) )
                break
            default:
                abendTest(id)
        }
        return candInfoList
    }

    public List getCandList_region(int id) {
        List candInfoList = []
        switch(id) {
            case 1:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_1) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_U) )
                break
            case 2:
            case 3:
            case 4:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_1) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_2) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_3) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_4) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_5) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_6) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_7) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_8) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_9) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_A) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_B) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_C) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_D) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_E) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_F) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_U) )
                break
            case 5:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_1, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_U, FALSE) )
                break
            case 6:
            case 7:
            case 8:
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_1, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_2, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_3, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_4, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_5, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_6, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_7, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_8, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_9, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_A, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_B, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_C, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_D, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_E, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_F, FALSE) )
		        candInfoList.add( makeMaxScoreCand(EXT_ID_REGION_U, FALSE) )
                break
            default:
                abendTest(id)
        }
        return candInfoList
    }

    public List getCandList_cold(int id) {
        List candInfoList = []
        switch(id) {
            case 1:
				candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_M) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_F) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_U) )
				break;
			case 2:
				candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_M, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_F, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_GENDER_U, FALSE) )
				break;
			default:
				abendTest(id)
		}
        return candInfoList
    }

    public List getCandList_priority(int id) {
        List candInfoList = []
        switch(id) {
            case 1:
				candInfoList.add( makeMaxScoreCand(EXT_ID_PRIORITY) )
				break;
			case 2:
				candInfoList.add( makeMaxScoreCand(EXT_ID_PRIORITY, FALSE) )
				break;
			default:
				abendTest(id)
		}
        return candInfoList
    }

    public List getCandList_loc(int id, int loc) {
        List candInfoList = []
        switch(id) {
            case 1:
            case 2:
            case 3:
        		for(i in 1..loc){
        		    String extId = String.format("${PROJECT_NAME}-LOC-%05d", i)
        	    	candInfoList.add(makeMaxScoreCand(extId))
        		}
				break;
            case 4:
            case 5:
            case 6:
        		for(i in 1..loc){
        		    String extId = String.format("${PROJECT_NAME}-LOC-%05d", i)
        	    	candInfoList.add(makeMaxScoreCand(extId, FALSE))
        		}
				break;
			default:
				abendTest(id)
		}
        return candInfoList
    }

    public List getCandList_minScore(int id) {
        List candInfoList = []
        switch(id) {
            case 1:
            case 3:
		        candInfoList.add( makeDefaultSSCandInfo(EXT_ID_MIN_SCORE_HIGH) )
		        candInfoList.add( makeDefaultScoreCand(EXT_ID_MIN_SCORE_LOW) )
                break
            case 2:
            case 4:
		        candInfoList.add( makeDefaultSSCandInfo(EXT_ID_MIN_SCORE_HIGH) )
                break
            case 5:
            case 7:
		        candInfoList.add( makeDefaultSSCandInfo(EXT_ID_MIN_SCORE_HIGH, FALSE) )
		        candInfoList.add( makeDefaultScoreCand(EXT_ID_MIN_SCORE_LOW, FALSE) )
                break
            case 6:
            case 8:
		        candInfoList.add( makeDefaultSSCandInfo(EXT_ID_MIN_SCORE_HIGH, FALSE) )
                break
            default:
                abendTest(id)
        }
        return candInfoList
    }

    public List getCandList_dynTh(int id) {
        List candInfoList = []
        switch(id) {
            case 1:
            case 3:
            case 4:
            case 6:
		        candInfoList.add( makeDefaultSSCandInfo(EXT_ID_DYN_TH_HIGH) )
		        candInfoList.add( makeDefaultScoreCand(EXT_ID_DYN_TH_LOW) )
                break
            case 2:
            case 5:
		        candInfoList.add( makeDefaultSSCandInfo(EXT_ID_DYN_TH_HIGH) )
                isHit = false
		        candInfoList.add( makeDefaultScoreCand(EXT_ID_DYN_TH_LOW) )
                break
            case 7:
            case 9:
            case 10:
            case 12:
		        candInfoList.add( makeDefaultSSCandInfo(EXT_ID_DYN_TH_HIGH, FALSE) )
		        candInfoList.add( makeDefaultScoreCand(EXT_ID_DYN_TH_LOW, FALSE) )
                break
            case 8:
            case 11:
		        candInfoList.add( makeDefaultSSCandInfo(EXT_ID_DYN_TH_HIGH, FALSE) )
                isHit = false
		        candInfoList.add( makeDefaultScoreCand(EXT_ID_DYN_TH_LOW, FALSE) )
                break
            default:
                abendTest(id)
        }
        return candInfoList
    }

    public List getCandList_searchMode(int id) {
        List candInfoList = []
        switch(id) {
            case 1:
		        candInfoList.add(
                    makeCandInfo(EXT_ID_SEARCH_MODE, 
						Math.max(pngRRScoreSmode1, pngLLScoreSmode1), 
						pngRRScoreSmode1, pngLLScoreSmode1, 
						pngRRScoreSmode1, ZERO_SCORE,
						ZERO_SCORE, pngLLScoreSmode1))
                break
            case 2:
            case 4:
		        candInfoList.add(makeDefaultPngScoreCand(EXT_ID_SEARCH_MODE) )
                break
            case 3:
		        candInfoList.add(
                    makeCandInfo(EXT_ID_SEARCH_MODE, 
						Math.max(pngRRScoreSmode3, pngLLScoreSmode3), 
						pngRRScoreSmode3, pngLLScoreSmode3, 
						pngRRScoreSmode3, ZERO_SCORE, 
						ZERO_SCORE, pngLLScoreSmode3))
                break
            case 5:
		        candInfoList.add(
                    makeCandInfo(EXT_ID_SEARCH_MODE, 
						Math.max(pngRRScoreSmode1, pngLLScoreSmode1), 
						pngRRScoreSmode1, pngLLScoreSmode1, 
						pngRRScoreSmode1, ZERO_SCORE,
						ZERO_SCORE, pngLLScoreSmode1, FALSE))
                break
            case 6:
            case 8:
		        candInfoList.add(makeDefaultPngScoreCand(EXT_ID_SEARCH_MODE, FALSE) )
                break
            case 7:
		        candInfoList.add(
                    makeCandInfo(EXT_ID_SEARCH_MODE, 
						Math.max(pngRRScoreSmode3, pngLLScoreSmode3), 
						pngRRScoreSmode3, pngLLScoreSmode3, 
						pngRRScoreSmode3, ZERO_SCORE, 
						ZERO_SCORE, pngLLScoreSmode3, FALSE))
                break
            default:
                abendTest(id)
        }
        return candInfoList
    }

    public List getCandList_rotationLimit(int id) {
        List candInfoList = []
        switch(id) {
            case 1:
            case 3:
            case 4:
            case 5:
		        candInfoList.add( makeDefaultScoreCand(EXT_ID_ROTATION) )
                break
            case 2:
                if(commonHelper.getEngine() == NIRIS) {
					candInfoList.add( makeCandInfo(
						EXT_ID_ROTATION, Math.max(j2kRRScoreRotation0, j2kLLScoreRotation0), 
						j2kRRScoreRotation0, j2kLLScoreRotation0, 
						j2kRRScoreRotation0, ZERO_SCORE, ZERO_SCORE, j2kLLScoreRotation0))
                }else if(commonHelper.getEngine() == VERIEYE) {
                    // No candidate
                }else{
                    abendTest(id)
                }
                break
            case 6:
            case 8:
            case 9:
            case 10:
		        candInfoList.add( makeDefaultScoreCand(EXT_ID_ROTATION, FALSE) )
                break
            case 7:
                if(commonHelper.getEngine() == NIRIS) {
					candInfoList.add( makeCandInfo(
						EXT_ID_ROTATION, Math.max(j2kRRScoreRotation0, j2kLLScoreRotation0), 
						j2kRRScoreRotation0, j2kLLScoreRotation0, 
						j2kRRScoreRotation0, ZERO_SCORE, ZERO_SCORE, j2kLLScoreRotation0, FALSE))
                }else if(commonHelper.getEngine() == VERIEYE) {
                    // No candidate
                }else{
                    abendTest(id)
                }
                break
            default:
                abendTest(id)
        }
        return candInfoList
    }

    public List getCandList_afisScript(int id) {
        List candInfoList = []
        switch(id) {
            case 1:
        		candInfoList.add( makeDefaultSSCandInfo(EXT_ID_AFIS_SCRIPT_HIGH) )
        		candInfoList.add( makeDefaultScoreCand(EXT_ID_AFIS_SCRIPT_LOW) )
				break;
            case 2:
        		candInfoList.add( makeDefaultSSCandInfo(EXT_ID_AFIS_SCRIPT_HIGH, FALSE) )
        		candInfoList.add( makeDefaultScoreCand(EXT_ID_AFIS_SCRIPT_LOW, FALSE) )
				break;
            default:
                abendTest(id)
		}			
        return candInfoList
    }

    public List getCandList_scope(int id) {
        List candInfoList = []
        switch(id) {
            case 1:
                targetContainerId = IDB_SCOPE_2_CON_ID
		        candInfoList.add( makeMaxScoreCand(EXT_ID_SCOPE_2) )
                break
            case 2:
                targetContainerId = IDB_SCOPE_1_CON_ID
		        candInfoList.add( makeMaxScoreCand(EXT_ID_SCOPE_1) )
                targetContainerId = IDB_SCOPE_2_CON_ID
		        candInfoList.add( makeMaxScoreCand(EXT_ID_SCOPE_2) )
                break
            case 3:
                targetContainerId = IDB_SCOPE_1_CON_ID
		        candInfoList.add( makeMaxScoreCand(EXT_ID_SCOPE_1) )
                break
            case 4:
                targetContainerId = IDB_SCOPE_2_CON_ID
		        candInfoList.add( makeMaxScoreCand(EXT_ID_SCOPE_2, FALSE) )
                break
            case 5:
                targetContainerId = IDB_SCOPE_1_CON_ID
		        candInfoList.add( makeMaxScoreCand(EXT_ID_SCOPE_1, FALSE) )
                targetContainerId = IDB_SCOPE_2_CON_ID
		        candInfoList.add( makeMaxScoreCand(EXT_ID_SCOPE_2, FALSE) )
                break
            case 6:
                targetContainerId = IDB_SCOPE_1_CON_ID
		        candInfoList.add( makeMaxScoreCand(EXT_ID_SCOPE_1, FALSE) )
                break
            default:
                abendTest(id)
        }
        return candInfoList
    }

    public List getCandList_scope_123(int id) {
        List candInfoList = []
        switch(id) {
            case 1:
        		targetContainerId = IDB_SCOPE_1_CON_ID
				candInfoList.add( makeMaxScoreCand(EXT_ID_SCOPE_1) )
        		targetContainerId = IDB_SCOPE_2_CON_ID
				candInfoList.add( makeMaxScoreCand(EXT_ID_SCOPE_2) )
        		targetContainerId = IDB_SCOPE_3_CON_ID
				candInfoList.add( makeMaxScoreCand(EXT_ID_SCOPE_3) )
				break;
			case 2:
        		targetContainerId = IDB_SCOPE_1_CON_ID
				candInfoList.add( makeMaxScoreCand(EXT_ID_SCOPE_1, FALSE) )
        		targetContainerId = IDB_SCOPE_2_CON_ID
				candInfoList.add( makeMaxScoreCand(EXT_ID_SCOPE_2, FALSE) )
        		targetContainerId = IDB_SCOPE_3_CON_ID
				candInfoList.add( makeMaxScoreCand(EXT_ID_SCOPE_3, FALSE) )
				break;
            default:
                abendTest(id)
        }
        return candInfoList
    }

    public List getCandList_crossMatch(int id) {
        List candInfoList = []

        List candInfo_RL_RL = makeDefaultScoreCand(EXT_ID_CROSS_MATCH_RL)
        List candInfo_RL_RL_2 = makeDefaultScoreCand(EXT_ID_CROSS_MATCH_RL, FALSE )

        List candInfo_RL_R = 
			[ EXT_ID_CROSS_MATCH_R, j2kRRScore, isHit,
				[ [ targetContainerId, EVENT_1, S_REQ_0, j2kRRScore,
					[ [ j2kIRScore, POS_0, 
                        [ [ POS_0, j2kRRScore ] ] ],
					  [ j2kLRScore, POS_1, 
                        [ [ POS_0, j2kLRScore ] ] ] ] ] ] ]

        List candInfo_RL_L = 
			[ EXT_ID_CROSS_MATCH_L, j2kLLScore, isHit,
				[ [ targetContainerId, EVENT_1, S_REQ_0, j2kLLScore,
					[ [ j2kRLScore, POS_0, 
                        [ [ POS_1, j2kRLScore ] ] ],
					  [ j2kILScore, POS_1, 
                        [ [ POS_1, j2kLLScore ] ] ] ] ] ] ]

        List candInfo_R_RL = 
			[ EXT_ID_CROSS_MATCH_RL, j2kRRScore, isHit,
				[ [ targetContainerId, EVENT_1, S_REQ_0, j2kRRScore,
					[ [ j2kRRScore, POS_0, 
                        [ [ POS_0, j2kRRScore ], [ POS_1, j2kRLScore ] ] ] ] ] ] ] 

        List candInfo_R_RL_2 = 
			[ EXT_ID_CROSS_MATCH_RL, j2kRRScore, isHit,
				[ [ targetContainerId, EVENT_1, S_REQ_0, j2kRRScore,
					[ [ j2kRRScore, POS_0, 
                        [ [ POS_0, j2kRRScore ] ] ] ] ] ] ] 

        List candInfo_R_R = 
			[ EXT_ID_CROSS_MATCH_R, j2kRRScore, isHit,
				[ [ targetContainerId, EVENT_1, S_REQ_0, j2kRRScore,
					[ [ j2kRRScore, POS_0, 
                        [ [ POS_0, j2kRRScore ] ] ] ] ] ] ]

        List candInfo_R_L = []

        List candInfo_L_RL = 
			[ EXT_ID_CROSS_MATCH_RL, j2kLLScore, isHit,
				[ [ targetContainerId, EVENT_1, S_REQ_0, j2kLLScore,
					[ [ j2kLLScore, POS_1, 
                        [ [ POS_0, j2kLRScore ], [ POS_1, j2kLLScore ] ] ] ] ] ] ] 

        List candInfo_L_RL_2 = 
			[ EXT_ID_CROSS_MATCH_RL, j2kLLScore, isHit,
				[ [ targetContainerId, EVENT_1, S_REQ_0, j2kLLScore,
					[ [ j2kLLScore, POS_1, 
                        [ [ POS_1, j2kLLScore ] ] ] ] ] ] ] 

        List candInfo_L_R = []

        List candInfo_L_L = 
			[ EXT_ID_CROSS_MATCH_L, j2kLLScore, isHit,
				[ [ targetContainerId, EVENT_1, S_REQ_0, j2kLLScore,
					[ [ j2kLLScore, POS_1, 
                        [ [ POS_1, j2kLLScore ] ] ] ] ] ] ]

        switch(id) {
            case 1:
		        candInfoList.add(candInfo_RL_RL)
		        candInfoList.add(candInfo_RL_R)
		        candInfoList.add(candInfo_RL_L)
                break
            case 2:
		        candInfoList.add(candInfo_R_RL)
		        candInfoList.add(candInfo_R_R)
                break
            case 3:
		        candInfoList.add(candInfo_L_RL)
		        candInfoList.add(candInfo_L_L)
                break
            case 4:
		        candInfoList.add(candInfo_RL_RL_2)
		        candInfoList.add(candInfo_R_R)
		        candInfoList.add(candInfo_L_L)
                break
            case 5:
		        candInfoList.add(candInfo_R_RL_2)
		        candInfoList.add(candInfo_R_R)
                break
            case 6:
		        candInfoList.add(candInfo_L_RL_2)
		        candInfoList.add(candInfo_L_L)
                break
            default:
                abendTest(id)
        }
        return candInfoList
    }

    public List getCandList_crossMatch2(int id) {
        List candInfoList = []

        List candInfo_R_R = 
			[ EXT_ID_CROSS_MATCH_R, j2kRRScore, isHit,
				[ [ targetContainerId, EVENT_1, S_REQ_0, j2kRRScore,
					[ [ j2kRRScore, POS_0, 
                        [ [ POS_0, j2kRRScore ] ] ] ] ] ] ]

        List candInfo_R_L = 
			[ EXT_ID_CROSS_MATCH_L, j2kRRScore, isHit,
				[ [ targetContainerId, EVENT_1, S_REQ_0, j2kRRScore,
					[ [ j2kRRScore, POS_0, 
                        [ [ POS_1, j2kRRScore ] ] ] ] ] ] ]

        List candInfo_L_L = 
			[ EXT_ID_CROSS_MATCH_L, j2kRRScore, isHit,
				[ [ targetContainerId, EVENT_1, S_REQ_0, j2kRRScore,
					[ [ j2kRRScore, POS_1, 
                        [ [ POS_1, j2kRRScore ] ] ] ] ] ] ]

        List candInfo_L_R = 
			[ EXT_ID_CROSS_MATCH_R, j2kRRScore, isHit,
				[ [ targetContainerId, EVENT_1, S_REQ_0, j2kRRScore,
					[ [ j2kRRScore, POS_1, 
                        [ [ POS_0, j2kRRScore ] ] ] ] ] ] ]


        switch(id) {
            case 1:
		        candInfoList.add(candInfo_R_R)
		        candInfoList.add(candInfo_R_L)
                break
            case 2:
		        candInfoList.add(candInfo_L_R)
		        candInfoList.add(candInfo_L_L)
                break
            case 3:
		        candInfoList.add(candInfo_R_R)
                break
            case 4:
		        candInfoList.add(candInfo_L_L)
                break
            default:
                abendTest(id)
        }
        return candInfoList
    }

    public List makeDefaultScoreCand(String extId) {
		return makeCandInfo(extId, j2kFScore, j2kIRScore, j2kILScore, j2kRRScore, j2kRLScore, j2kLRScore, j2kLLScore, TRUE)
    }

    public List makeDefaultScoreCand(String extId, String isCrossMatch) {
		return makeCandInfo(extId, j2kFScore, j2kIRScore, j2kILScore, j2kRRScore, j2kRLScore, j2kLRScore, j2kLLScore, isCrossMatch)
    }

    public List makeDefaultPngScoreCand(String extId) {
		return makeCandInfo(extId, pngFScore, pngIRScore, pngILScore, pngRRScore, pngRLScore, pngLRScore, pngLLScore, TRUE)
    }

    public List makeDefaultPngScoreCand(String extId, String isCrossMatch) {
		return makeCandInfo(extId, pngFScore, pngIRScore, pngILScore, pngRRScore, pngRLScore, pngLRScore, pngLLScore, isCrossMatch)
    }

    private List makeMaxScoreCand(String extId) {
		return makeCandInfo(extId, getHighScore(getHighScore(maxRRScore, maxRLScore), getHighScore(maxLRScore, maxLLScore)),
							getHighScore(maxRRScore, maxRLScore), getHighScore(maxLRScore, maxLLScore),
							maxRRScore, maxRLScore, maxLRScore, maxLLScore, TRUE)
    }

    private List makeMaxScoreCand(String extId, String isCrossMatch) {
		return makeCandInfo(extId, getHighScore(getHighScore(maxRRScore, maxRLScore), getHighScore(maxLRScore, maxLLScore)),
							getHighScore(maxRRScore, maxRLScore), getHighScore(maxLRScore, maxLLScore),
							maxRRScore, maxRLScore, maxLRScore, maxLLScore, isCrossMatch)
    }

    private List makeCandInfo( String extId, int finalScore, int iScoreR, int iScoreL, 
								int rScoreRR, int rScoreRL, int rScoreLR, int rScoreLL) {
		return makeCandInfo(extId, finalScore, iScoreR, iScoreL,
                rScoreRR, rScoreRL, rScoreLR, rScoreLL, TRUE)
	}

    private List makeCandInfo(
                String extId, int finalScore, int iScoreR, int iScoreL, 
                int rScoreRR, int rScoreRL, int rScoreLR, int rScoreLL, String isCrossMatch) {

		def candInfo = []
		if("x${isCrossMatch}" == "x${TRUE}"){
			candInfo =
			[ extId, finalScore, isHit,
				[ [ targetContainerId, EVENT_1, S_REQ_0, finalScore,
					[ [ iScoreR, POS_0, 
                        [ [ POS_0, rScoreRR ], [ POS_1, rScoreRL ] ] ],
					  [ iScoreL, POS_1, 
                        [ [ POS_0, rScoreLR ], [ POS_1, rScoreLL ] ] ] ] ] ] ]
		}else if("x${isCrossMatch}" == "x${FALSE}"){
			candInfo =
			[ extId, finalScore, isHit,
				[ [ targetContainerId, EVENT_1, S_REQ_0, finalScore,
					[ [ iScoreR, POS_0, 
                        [ [ POS_0, rScoreRR ] ] ],
					  [ iScoreL, POS_1, 
                        [ [ POS_1, rScoreLL ] ] ] ] ] ] ]
		}else{
        	new AbendProcessor(soapuiObj.getContext()).abendTest("Unexpected isCrossMatch value '${isCrossMatch}'.")
		}
        return candInfo
    }

    private void abendTest(int id){
        new AbendProcessor(soapuiObj.getContext()).abendTest("Unexpected id value '${id}'.")
    }

    private void initAssertionScore() {
        j2kRRScore = commonHelper.j2kRRScore
        j2kRRScoreSmode1 = commonHelper.j2kRRScoreSmode1
        j2kRRScoreSmode3 = commonHelper.j2kRRScoreSmode3
        j2kRRScoreRotation0 = commonHelper.j2kRRScore
        j2kRLScore = commonHelper.j2kRLScore
        j2kLRScore = commonHelper.j2kLRScore
        j2kLLScore = commonHelper.j2kLLScore
        j2kLLScoreSmode1 = commonHelper.j2kLLScoreSmode1
        j2kLLScoreSmode3 = commonHelper.j2kLLScoreSmode3
        j2kLLScoreRotation0 = 3763
        j2kFScore = commonHelper.j2kFScore
        j2kIRScore = commonHelper.j2kIRScore
        j2kILScore = commonHelper.j2kILScore

        pngRRScore = commonHelper.pngRRScore
        pngRLScore = commonHelper.pngRLScore
        pngLRScore = commonHelper.pngLRScore
        pngLLScore = commonHelper.pngLLScore
        pngFScore = commonHelper.pngFScore
        pngIRScore = commonHelper.pngIRScore
        pngILScore = commonHelper.pngILScore

        pngRRScoreSmode1 = commonHelper.pngRRScoreSmode1
        pngRRScoreSmode3 = commonHelper.pngRRScoreSmode3
        pngLLScoreSmode1 = commonHelper.pngLLScoreSmode1
        pngLLScoreSmode3 = commonHelper.pngLLScoreSmode3

        maxRRScore = commonHelper.maxRRScore
        maxRLScore = commonHelper.maxRLScore
        maxLRScore = commonHelper.maxLRScore
        maxLLScore = commonHelper.maxLLScore
        maxFScore = commonHelper.maxFScore
        maxIRScore = commonHelper.maxIRScore
        maxILScore = commonHelper.maxILScore
    }
	
	public int getDefaultFScore() {
		return j2kFScore
	}

	public int getMaxFScore() {
		return getHighScore(getHighScore(maxRRScore, maxRLScore), getHighScore(maxLRScore, maxLLScore))
	}

    public List makeDefaultSSCandInfo(String extId) {
        return makeMaxScoreCand(extId)
    }

    public List makeDefaultSSCandInfo(String extId, isCrossMatch) {
        return makeMaxScoreCand(extId, isCrossMatch)
    }

	private getHighScore(def score_1, def score_2){
		return [ score_1, score_2 ].max()
	}

}

