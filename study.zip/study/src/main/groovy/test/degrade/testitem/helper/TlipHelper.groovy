package test.degrade.testitem.helper

import common.util.Encoder
import test.common.constants.aim.*
import static test.common.constants.aim.AIMXmlAttribute.*

class TlipHelper extends PalmHelper {
    private static final String FUNC = "TLIP"

	private static final String PALM_OPT_EXT_ID = "${FUNC}_PalmOpt"
	
	private static final String GEN_M_EXT_ID = "${FUNC}_M"
	private static final String GEN_F_EXT_ID = "${FUNC}_F"
	private static final String GEN_U_EXT_ID = "${FUNC}_U"

	private static final String YOB_1_EXT_ID = "${FUNC}_1979_-1"
	private static final String YOB_2_EXT_ID = "${FUNC}_1979_0"
	private static final String YOB_3_EXT_ID = "${FUNC}_1979_1"
	private static final String YOB_4_EXT_ID = "${FUNC}_1979_5"
	private static final String YOB_5_EXT_ID = "${FUNC}_1979_9"
	private static final String YOB_6_EXT_ID = "${FUNC}_1973_0"
	private static final String YOB_7_EXT_ID = "${FUNC}_1974_0"
	private static final String YOB_8_EXT_ID = "${FUNC}_1984_0"
	private static final String YOB_9_EXT_ID = "${FUNC}_1985_0"
	private static final String YOB_10_EXT_ID = "${FUNC}_1974_5"
	private static final String YOB_11_EXT_ID = "${FUNC}_1984_5"
	private static final String YOB_12_EXT_ID = "${FUNC}_-1_0"
	
	private static final String PARTNO_0_EXT_ID = "${FUNC}_0"
	private static final String PARTNO_1_EXT_ID = "${FUNC}_1"
	private static final String PARTNO_2_EXT_ID = "${FUNC}_2"
	private static final String PARTNO_3_EXT_ID = "${FUNC}_3"
	private static final String PARTNO_4_EXT_ID = "${FUNC}_4"
	private static final String PARTNO_5_EXT_ID = "${FUNC}_5"
	private static final String PARTNO_6_EXT_ID = "${FUNC}_6"
	private static final String PARTNO_7_EXT_ID = "${FUNC}_7"
	private static final String PARTNO_8_EXT_ID = "${FUNC}_8"
	private static final String PARTNO_9_EXT_ID = "${FUNC}_9"
	private static final String PARTNO_A_EXT_ID = "${FUNC}_A"
	private static final String PARTNO_B_EXT_ID = "${FUNC}_B"
	private static final String PARTNO_C_EXT_ID = "${FUNC}_C"
	private static final String PARTNO_D_EXT_ID = "${FUNC}_D"
	private static final String PARTNO_E_EXT_ID = "${FUNC}_E"
	private static final String PARTNO_F_EXT_ID = "${FUNC}_F"
	private static final String PARTNO_G_EXT_ID = "${FUNC}_G"
	private static final String PARTNO_234_EXT_ID = "${FUNC}_234"
	private static final String PARTNO_134_EXT_ID = "${FUNC}_134"
	private static final String PARTNO_124_EXT_ID = "${FUNC}_124"
	private static final String PARTNO_123_EXT_ID = "${FUNC}_123"
	private static final String PARTNO_BCD_EXT_ID = "${FUNC}_BCD"
	private static final String PARTNO_EFG_EXT_ID = "${FUNC}_EFG"

	private static final String RACE_1_EXT_ID = "${FUNC}_1"
	private static final String RACE_2_EXT_ID = "${FUNC}_2"
	private static final String RACE_4_EXT_ID = "${FUNC}_4"
	private static final String RACE_8_EXT_ID = "${FUNC}_8"
	private static final String RACE_M1_EXT_ID = "${FUNC}_-1"
	
	private static final String REGION_1_EXT_ID = "${FUNC}_1"
	private static final String REGION_9_EXT_ID = "${FUNC}_9"
	private static final String REGION_F_EXT_ID = "${FUNC}_F"
	private static final String REGION_U_EXT_ID = "${FUNC}_U"
	
	private static final String COLD_1_EXT_ID = "${FUNC}_COLD"
	
	private static final String LOSTPART_RF_EXT_ID = "${FUNC}_RFull"
	private static final String LOSTPART_RW_EXT_ID = "${FUNC}_RWriter"
	private static final String LOSTPART_LF_EXT_ID = "${FUNC}_LFull"
	private static final String LOSTPART_LW_EXT_ID = "${FUNC}_LWriter"

	private static final String AFISSCRIPT_1_EXT_ID = "${FUNC}_1"
	private static final String AFISSCRIPT_2_EXT_ID = "${FUNC}_2"
	private static final String AFISSCRIPT_3_EXT_ID = "${FUNC}_3"

	private static final String SCOPE_1_EXT_ID = "${FUNC}_Scope1"
	private static final String SCOPE_2_EXT_ID = "${FUNC}_Scope2"
	private static final String SCOPE_3_EXT_ID = "${FUNC}_Scope3"
	
	private static final String FW_EXT_ID = "${FUNC}_FW"

	private static final String EXT_SORT_HIGH_AB_EXT_ID = "${FUNC}_highScore-!AB"
	private static final String EXT_SORT_HIGH_BA_EXT_ID = "${FUNC}_highScore-BA"
	private static final String EXT_SORT_HIGH_1C_EXT_ID = "${FUNC}_highScore-1C"
	private static final String EXT_SORT_LOW_AB_EXT_ID = "${FUNC}_lowScore-!AB"
	private static final String EXT_SORT_LOW_BA_EXT_ID = "${FUNC}_lowScore-BA"
	private static final String EXT_SORT_LOW_1C_EXT_ID = "${FUNC}_lowScore-1C"

	private static final String MULTIPART_SCORE_EXT_ID = "${FUNC}_MultiPartScore"

	private static final int PALM_OPT_BASE_SCORE_PC3R = 6774
	private static final int PALM_OPT_BASE_SCORE_PZIP = 1184
	private static final int PALM_OPT_ROTATION_1_SCORE = 292
	private static final int PALM_OPT_ROTATION_2_SCORE = 412
	private static final int PALM_OPT_ROTATION_4_SCORE = 457
	private static final int PALM_OPT_SPEED_P_9_SCORE = 6490
	private static final int PALM_OPT_SPEED_S_5_SCORE = 6771
	private static final int PALM_OPT_DISTORTION_P_1_SCORE = 6760
	private static final int PALM_OPT_DISTORTION_P_3_SCORE = 7150
	private static final int PALM_OPT_DISTORTION_S_2_SCORE = 6087
	private static final int PALM_OPT_DISTORTION_S_5_SCORE = 6825

	private static final int PARTNO_SCORE_PC3R = 6449
	private static final int PARTNO_SCORE_PZIP = 347

	private static final int LOSTPART_SCORE_RF = 9999
	private static final int LOSTPART_SCORE_RW = 8015 // Unkown score due to there are no hit case.
	private static final int LOSTPART_SCORE_LF_PC3R = 8015
	private static final int LOSTPART_SCORE_LF_PZIP = 9999
	private static final int LOSTPART_SCORE_LW_PC3R = PALM_OPT_BASE_SCORE_PC3R
	private static final int LOSTPART_SCORE_LW_PZIP = 9999

	private static final int FW_100_SCORE_PC3R = 982
	private static final int FW_100_SCORE_PZIP = 1184

	private static final int EXT_SORT_HIGH_SCORE_PC3R = FW_100_SCORE_PC3R
	private static final int EXT_SORT_HIGH_SCORE_PZIP = FW_100_SCORE_PZIP
	private static final int EXT_SORT_LOW_SCORE_PC3R = 570
	private static final int EXT_SORT_LOW_SCORE_PZIP = 496

	private static final int SCOPE_1_BIN_ID = 322
	private static final int SCOPE_2_BIN_ID = SCOPE_1_BIN_ID + 1000
	private static final int SCOPE_3_BIN_ID = SCOPE_1_BIN_ID + 2000

	private Integer fw = 100
	private int reqIndex = 0
	
	private List GEN_M_CAND_INFO_LIST = []
	private List GEN_F_CAND_INFO_LIST = []
	private List GEN_U_CAND_INFO_LIST = []

	private List YOB_1_CAND_INFO_LIST = []
	private List YOB_2_CAND_INFO_LIST = []
	private List YOB_3_CAND_INFO_LIST = []
	private List YOB_4_CAND_INFO_LIST = []
	private List YOB_5_CAND_INFO_LIST = []
	private List YOB_6_CAND_INFO_LIST = []
	private List YOB_7_CAND_INFO_LIST = []
	private List YOB_8_CAND_INFO_LIST = []
	private List YOB_9_CAND_INFO_LIST = []
	private List YOB_10_CAND_INFO_LIST = []
	private List YOB_11_CAND_INFO_LIST = []
	private List YOB_12_CAND_INFO_LIST = []
	
	private List PARTNO_1_1_CAND_INFO_LIST = []
	private List PARTNO_1_2_CAND_INFO_LIST = []
	private List PARTNO_234_CAND_INFO_LIST = []
	private List PARTNO_2_CAND_INFO_LIST = []
	private List PARTNO_134_CAND_INFO_LIST = []
	private List PARTNO_3_CAND_INFO_LIST = []
	private List PARTNO_124_CAND_INFO_LIST = []
	private List PARTNO_4_CAND_INFO_LIST = []
	private List PARTNO_123_CAND_INFO_LIST = []
	
	private List LOSTPART_RF_CAND_INFO_LIST = []
	private List LOSTPART_RW_CAND_INFO_LIST = []
	private List LOSTPART_LF_CAND_INFO_LIST = []
	private List LOSTPART_LW_CAND_INFO_LIST = []

	private List FW_100_CAND_INFO_LIST = []
	private List FW_150_CAND_INFO_LIST = []
	private List FW_NULL_CAND_INFO_LIST = []

	private List EXT_SORT_HIGH_AB_CAND_INFO_LIST = []
	private List EXT_SORT_HIGH_BA_CAND_INFO_LIST = []
	private List EXT_SORT_HIGH_1C_CAND_INFO_LIST = []
	private List EXT_SORT_LOW_AB_CAND_INFO_LIST = []
	private List EXT_SORT_LOW_BA_CAND_INFO_LIST = []
	private List EXT_SORT_LOW_1C_CAND_INFO_LIST = []

    private static final String ROTATION_TLIP_TEMPLATE_PC3R = "TP999_TLIP_Rotation.bin"
    private static final String PALM_OPT_TLIP_TEMPLATE_PC3R = "TP006_TLIP_PalmOption.bin"
    private static final String PALM_OPT_TLIP_TEMPLATE_PZIP = "TP002_TLIP_PalmOption.bin"
    private static final String ROTATION_PLDB_TEMPLATE_PC3R = "LP999_PLDB_Rotation.bin"
    private static final String PALM_OPT_PLDB_TEMPLATE_PC3R = "LP007_PLDB_PalmOption.bin"
    private static final String PALM_OPT_PLDB_TEMPLATE_PZIP = "LP002_PLDB_PalmOption.bin"
	
    private static final Integer DEFAULT_MIN_SCORE = 50
    static Integer minScore = DEFAULT_MIN_SCORE
    private static final int MIN_SCORE_SCORE_AT_MULTIPART_TEST_PC3R = 5957
    private static final int MIN_SCORE_SCORE_AT_MULTIPART_TEST_PZIP = 6678

    private String projectName
	
	TlipHelper(context){
		super(context)
        this.projectName = soapuiObj.getTestProjectName()
		initCandInfoLists()
	}

	TlipHelper(context, String level){
        super(context)
        this.projectName = soapuiObj.getTestProjectName()
		setNullFwIfHighLevel(level)
		initCandInfoLists()
	}

    public void resetSearchParam() {
        initPayloadMap()
        minScore = DEFAULT_MIN_SCORE
    }

    public String makeMinScoreXml() {
        if(minScore == null) {
            return ""
        }else{
            return "<minScore>${minScore}</minScore>"
        }
    }

    public void setupMinScoreScoreAtMultiPart() {
        this.minScore = getCorrectAlgorithmObj(
                MIN_SCORE_SCORE_AT_MULTIPART_TEST_PC3R, MIN_SCORE_SCORE_AT_MULTIPART_TEST_PZIP)
    }

    public String getRotationTlipTemplateB64() {
        String templateName = getCorrectAlgorithmObj(ROTATION_TLIP_TEMPLATE_PC3R, PALM_OPT_TLIP_TEMPLATE_PZIP)
        String path = "${soapuiObj.getGlobalDataFilePath()}/degradeTest/template/${soapuiObj.getGlobalTempDirName()}/${projectName}/${templateName}"
        return Encoder.binaryToB64(path)
    }

    public String getRotationPldbTemplateB64() {
        String templateName = getCorrectAlgorithmObj(ROTATION_PLDB_TEMPLATE_PC3R, PALM_OPT_PLDB_TEMPLATE_PZIP)
        String path = "${soapuiObj.getGlobalDataFilePath()}/degradeTest/template/${soapuiObj.getGlobalTempDirName()}/${projectName}/${templateName}"
        return Encoder.binaryToB64(path)
    }

    public String getPalmOptTlipTemplateB64() {
        String templateName = getCorrectAlgorithmObj(PALM_OPT_TLIP_TEMPLATE_PC3R, PALM_OPT_TLIP_TEMPLATE_PZIP)
        String path = "${soapuiObj.getGlobalDataFilePath()}/degradeTest/template/${soapuiObj.getGlobalTempDirName()}/${projectName}/${templateName}"
        return Encoder.binaryToB64(path)
    }

    public String getPalmOptPldbTemplateB64() {
        String templateName = getCorrectAlgorithmObj(PALM_OPT_PLDB_TEMPLATE_PC3R, PALM_OPT_PLDB_TEMPLATE_PZIP)
        String path = "${soapuiObj.getGlobalDataFilePath()}/degradeTest/template/${soapuiObj.getGlobalTempDirName()}/${projectName}/${templateName}"
        return Encoder.binaryToB64(path)
    }

	private void initCandInfoLists() {
		initGenderCandInfoList()
		initYobCandInfoList()
        initLostPartCandInfoList()
		initFusionWeightCandInfoList()
		initExternalIdCandInfoList()
	}

	private void initGenderCandInfoList(){
		GEN_M_CAND_INFO_LIST =
			[ GEN_M_EXT_ID, 9999, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, 9999,
					[ [ 9999, FIN_1, A, fw ] ] 
				] ]
			]
		
		GEN_F_CAND_INFO_LIST =
			[ GEN_F_EXT_ID, 9999, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, 9999,
					[ [ 9999, FIN_1, A, fw ] ] 
				] ]
			]
		
		GEN_U_CAND_INFO_LIST =
			[ GEN_U_EXT_ID, 9999, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, 9999,
					[ [ 9999, FIN_1, A, fw ] ] 
				] ]
			]
	}

	private void initYobCandInfoList(){
		YOB_1_CAND_INFO_LIST =
			[ YOB_1_EXT_ID, 9999, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, 9999,
					[ [ 9999, FIN_1, A, fw ] ] 
				] ]
			]
	
		YOB_2_CAND_INFO_LIST =
			[ YOB_2_EXT_ID, 9999, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, 9999,
					[ [ 9999, FIN_1, A, fw ] ] 
				] ]
			]
	
		YOB_3_CAND_INFO_LIST =
			[ YOB_3_EXT_ID, 9999, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, 9999,
					[ [ 9999, FIN_1, A, fw ] ] 
				] ]
			]
	
		YOB_4_CAND_INFO_LIST =
			[ YOB_4_EXT_ID, 9999, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, 9999,
					[ [ 9999, FIN_1, A, fw ] ] 
				] ]
			]
	
		YOB_5_CAND_INFO_LIST =
			[ YOB_5_EXT_ID, 9999, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, 9999,
					[ [ 9999, FIN_1, A, fw ] ] 
				] ]
			]
	
		YOB_6_CAND_INFO_LIST =
			[ YOB_6_EXT_ID, 9999, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, 9999,
					[ [ 9999, FIN_1, A, fw ] ] 
				] ]
			]
	
		YOB_7_CAND_INFO_LIST =
			[ YOB_7_EXT_ID, 9999, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, 9999,
					[ [ 9999, FIN_1, A, fw ] ] 
				] ]
			]
	
		YOB_8_CAND_INFO_LIST =
			[ YOB_8_EXT_ID, 9999, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, 9999,
					[ [ 9999, FIN_1, A, fw ] ] 
				] ]
			]
	
		YOB_9_CAND_INFO_LIST =
			[ YOB_9_EXT_ID, 9999, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, 9999,
					[ [ 9999, FIN_1, A, fw ] ] 
				] ]
			]
	
		YOB_10_CAND_INFO_LIST =
			[ YOB_10_EXT_ID, 9999, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, 9999,
					[ [ 9999, FIN_1, A, fw ] ] 
				] ]
			]
	
		YOB_11_CAND_INFO_LIST =
			[ YOB_11_EXT_ID, 9999, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, 9999,
					[ [ 9999, FIN_1, A, fw ] ] 
				] ]
			]
	
		YOB_12_CAND_INFO_LIST =
			[ YOB_12_EXT_ID, 9999, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, 9999,
					[ [ 9999, FIN_1, A, fw ] ] 
				] ]
			]
	}
	
	private void initLostPartCandInfoList(){
        int score
		LOSTPART_RF_CAND_INFO_LIST =
			[ LOSTPART_RF_EXT_ID, LOSTPART_SCORE_RF, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, LOSTPART_SCORE_RF,
					[ [ LOSTPART_SCORE_RF, FIN_1, A, fw ] ] 
				] ]
			]

		LOSTPART_RW_CAND_INFO_LIST =
			[ LOSTPART_RW_EXT_ID, LOSTPART_SCORE_RW, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, LOSTPART_SCORE_RW,
					[ [ LOSTPART_SCORE_RW, FIN_2, A, fw ] ] 
				] ]
			]

        score = getCorrectAlgorithmObj(LOSTPART_SCORE_LF_PC3R, LOSTPART_SCORE_LF_PZIP)
		LOSTPART_LF_CAND_INFO_LIST =
			[ LOSTPART_LF_EXT_ID, score, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, score,
					[ [ score, FIN_3, A, fw ] ] 
				] ]
			]

        score = getCorrectAlgorithmObj(LOSTPART_SCORE_LW_PC3R, LOSTPART_SCORE_LW_PZIP)
		LOSTPART_LW_CAND_INFO_LIST =
			[ LOSTPART_LW_EXT_ID, score, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, score,
					[ [ score, FIN_4, A, fw ] ] 
				] ]
			]
    }

	private void initFusionWeightCandInfoList(){
        int score = getCorrectAlgorithmObj(FW_100_SCORE_PC3R, FW_100_SCORE_PZIP)
        int fw150Score = score * 1.5
		FW_100_CAND_INFO_LIST =
			[ FW_EXT_ID, score, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, score,
					[ [ score, FIN_2, A , 100 ] ] 
				] ]
			]

		FW_150_CAND_INFO_LIST =
			[ FW_EXT_ID, fw150Score, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, fw150Score,
					[ [ score, FIN_2, A , 150 ] ] 
				] ]
			]

		FW_NULL_CAND_INFO_LIST =
			[ FW_EXT_ID, score, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, score,
					[ [ score, FIN_2, A , null ] ] 
				] ]
			]

	}

	private void initExternalIdCandInfoList(){
        int highScore = getCorrectAlgorithmObj(EXT_SORT_HIGH_SCORE_PC3R, EXT_SORT_HIGH_SCORE_PZIP)
        int lowScore = getCorrectAlgorithmObj(EXT_SORT_LOW_SCORE_PC3R, EXT_SORT_LOW_SCORE_PZIP)
        Boolean lowHitFalag = getCorrectAlgorithmObj(true, null)

		EXT_SORT_HIGH_AB_CAND_INFO_LIST =
			[ EXT_SORT_HIGH_AB_EXT_ID, highScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, highScore,
					[ [ highScore, FIN_2, A , fw ] ] 
				] ]
			]

		EXT_SORT_HIGH_BA_CAND_INFO_LIST =
			[ EXT_SORT_HIGH_BA_EXT_ID, highScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, highScore,
					[ [ highScore, FIN_2, A , fw ] ] 
				] ]
			]

		EXT_SORT_HIGH_1C_CAND_INFO_LIST =
			[ EXT_SORT_HIGH_1C_EXT_ID, highScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, highScore,
					[ [ highScore, FIN_2, A , fw ] ] 
				] ]
			]

		EXT_SORT_LOW_AB_CAND_INFO_LIST =
			[ EXT_SORT_LOW_AB_EXT_ID, lowScore, lowHitFalag,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, lowScore,
					[ [ lowScore, FIN_2, A , fw ] ] 
				] ]
			]

		EXT_SORT_LOW_BA_CAND_INFO_LIST =
			[ EXT_SORT_LOW_BA_EXT_ID, lowScore, lowHitFalag,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, lowScore,
					[ [ lowScore, FIN_2, A , fw ] ] 
				] ]
			]

		EXT_SORT_LOW_1C_CAND_INFO_LIST =
			[ EXT_SORT_LOW_1C_EXT_ID, lowScore, lowHitFalag,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, lowScore,
					[ [ lowScore, FIN_2, A , fw ] ] 
				] ]
			]
	}

	public List getCandList_Rotation_1(){
        return makeRotaionCandList(PALM_OPT_ROTATION_1_SCORE)
	}

	public List getCandList_Rotation_2(){
        return makeRotaionCandList(PALM_OPT_ROTATION_2_SCORE)
	}

	public List getCandList_Rotation_3(){
        return makeRotaionCandList(PALM_OPT_ROTATION_4_SCORE)
	}

    private List makeRotaionCandList(int pc3rScore) {
        List extIdList = [ PALM_OPT_EXT_ID ]
        int score = getCorrectAlgorithmObj(pc3rScore, PALM_OPT_BASE_SCORE_PZIP)
        int pos = getCorrectAlgorithmObj(4, 2)
		return makeCandList(extIdList, score, pos)
    }

	public List getCandList_SpeedP_1(){
        List extIdList = [ PALM_OPT_EXT_ID ]
		return makeCandList(extIdList, PALM_OPT_SPEED_P_9_SCORE, 4)
	}

	public List getCandList_PalmOpt_Default(){
        List extIdList = [ PALM_OPT_EXT_ID ]
		return makeCandList(extIdList, PALM_OPT_BASE_SCORE_PC3R, 4)
	}

	public List getCandList_SpeedP_2(){
        List extIdList = [ PALM_OPT_EXT_ID ]
		return getCandList_PalmOpt_Default()
	}

	public List getCandList_SpeedS_1(){
        List extIdList = [ PALM_OPT_EXT_ID ]
		return makeCandList(extIdList, PALM_OPT_SPEED_S_5_SCORE, 4)
	}

	public List getCandList_SpeedS_2(){
        List extIdList = [ PALM_OPT_EXT_ID ]
		return getCandList_PalmOpt_Default()
	}

	public List getCandList_DistortionP_1(){
        List extIdList = [ PALM_OPT_EXT_ID ]
		return makeCandList(extIdList, PALM_OPT_DISTORTION_P_1_SCORE, 4)
	}

	public List getCandList_DistortionP_2(){
        List extIdList = [ PALM_OPT_EXT_ID ]
		return makeCandList(extIdList, PALM_OPT_DISTORTION_P_3_SCORE, 4)
	}

	public List getCandList_DistortionS_1(){
        List extIdList = [ PALM_OPT_EXT_ID ]
		return makeCandList(extIdList, PALM_OPT_DISTORTION_S_2_SCORE, 4)
	}

	public List getCandList_DistortionS_2(){
        List extIdList = [ PALM_OPT_EXT_ID ]
		return makeCandList(extIdList, PALM_OPT_DISTORTION_S_5_SCORE, 4)
	}

	public List getCandList_Gender_M_Only(){
		return [ GEN_M_CAND_INFO_LIST ] 
	}

	public List getCandList_Gender_F_Only(){
		return [ GEN_F_CAND_INFO_LIST ] 
	}

	public List getCandList_Gender_M(){
		return [ GEN_M_CAND_INFO_LIST,  GEN_U_CAND_INFO_LIST ] 
	}

	public List getCandList_Gender_F(){
		return [ GEN_F_CAND_INFO_LIST, GEN_U_CAND_INFO_LIST ] 
	}
	
	public List getCandList_Gender_U(){
		return [ GEN_M_CAND_INFO_LIST, GEN_F_CAND_INFO_LIST, GEN_U_CAND_INFO_LIST ] 
	}

	public List getCandList_Yob_All(){
		return [ YOB_1_CAND_INFO_LIST, YOB_2_CAND_INFO_LIST, YOB_3_CAND_INFO_LIST,
				 YOB_4_CAND_INFO_LIST, YOB_5_CAND_INFO_LIST, YOB_6_CAND_INFO_LIST,
				 YOB_7_CAND_INFO_LIST, YOB_8_CAND_INFO_LIST, YOB_9_CAND_INFO_LIST,
				 YOB_10_CAND_INFO_LIST, YOB_11_CAND_INFO_LIST, YOB_12_CAND_INFO_LIST ] 
	}

	public List getCandList_Yob_10(){
		return [ YOB_1_CAND_INFO_LIST, YOB_2_CAND_INFO_LIST, YOB_3_CAND_INFO_LIST,
				 YOB_4_CAND_INFO_LIST, YOB_5_CAND_INFO_LIST, YOB_7_CAND_INFO_LIST,
				 YOB_8_CAND_INFO_LIST, YOB_10_CAND_INFO_LIST, YOB_11_CAND_INFO_LIST,
				 YOB_12_CAND_INFO_LIST ] 
	}

	public List getCandList_Yob_9(){
		return [ YOB_1_CAND_INFO_LIST, YOB_2_CAND_INFO_LIST, YOB_3_CAND_INFO_LIST,
				 YOB_4_CAND_INFO_LIST, YOB_5_CAND_INFO_LIST, YOB_8_CAND_INFO_LIST, 
				 YOB_9_CAND_INFO_LIST, YOB_11_CAND_INFO_LIST, YOB_12_CAND_INFO_LIST ] 
	}

	public List getCandList_Yob_2(){
		return [ YOB_1_CAND_INFO_LIST, YOB_12_CAND_INFO_LIST ] 
	}

    public List getCandList_PartNo_2Parts_All(){
        List extIdList = [ PARTNO_1_EXT_ID, PARTNO_234_EXT_ID, PARTNO_2_EXT_ID,
	                        PARTNO_134_EXT_ID, PARTNO_3_EXT_ID, PARTNO_124_EXT_ID,
	                        PARTNO_4_EXT_ID, PARTNO_123_EXT_ID ]
        return makePartNoCandList(extIdList, 1, 4)
    }

    public List getCandList_PartNo_2Parts_16(){
        List candList = []
        List extIdList1 = [ PARTNO_1_EXT_ID, PARTNO_134_EXT_ID, PARTNO_124_EXT_ID, PARTNO_123_EXT_ID ]
        List extIdList2 = [ PARTNO_2_EXT_ID, PARTNO_234_EXT_ID, PARTNO_124_EXT_ID, PARTNO_123_EXT_ID ]
        List extIdList3 = [ PARTNO_3_EXT_ID, PARTNO_134_EXT_ID, PARTNO_234_EXT_ID, PARTNO_123_EXT_ID ]
        List extIdList4 = [ PARTNO_4_EXT_ID, PARTNO_134_EXT_ID, PARTNO_124_EXT_ID, PARTNO_234_EXT_ID ]
        candList.addAll(makePartNoCandList(extIdList1, 1))
        candList.addAll(makePartNoCandList(extIdList2, 2))
        candList.addAll(makePartNoCandList(extIdList3, 3))
        candList.addAll(makePartNoCandList(extIdList4, 4))
        return candList
    }

    public List getCandList_PartNo_3Parts(){
        List candList = []
        List extIdList1 = [ PARTNO_1_EXT_ID, PARTNO_134_EXT_ID, PARTNO_124_EXT_ID, PARTNO_123_EXT_ID,
                            PARTNO_0_EXT_ID, PARTNO_9_EXT_ID, PARTNO_BCD_EXT_ID ]
        List extIdList2 = [ PARTNO_2_EXT_ID, PARTNO_234_EXT_ID, PARTNO_124_EXT_ID, PARTNO_123_EXT_ID, PARTNO_0_EXT_ID, PARTNO_9_EXT_ID ]
        List extIdList3 = [ PARTNO_3_EXT_ID, PARTNO_134_EXT_ID, PARTNO_234_EXT_ID, PARTNO_123_EXT_ID, PARTNO_0_EXT_ID, PARTNO_EFG_EXT_ID ]
        List extIdList4 = [ PARTNO_4_EXT_ID, PARTNO_134_EXT_ID, PARTNO_124_EXT_ID, PARTNO_234_EXT_ID, PARTNO_0_EXT_ID ]
        candList.addAll(makePartNoCandList(extIdList1, 1))
        candList.addAll(makePartNoCandList(extIdList2, 2))
        candList.addAll(makePartNoCandList(extIdList3, 3))
        candList.addAll(makePartNoCandList(extIdList4, 4))
        return candList
    }

    public List getCandList_PartNo_3Parts_UpperLower(){
        List candList = []
        List extIdList2 = [ PARTNO_2_EXT_ID ]
        List extIdList3 = [ PARTNO_3_EXT_ID, PARTNO_E_EXT_ID, PARTNO_F_EXT_ID, PARTNO_G_EXT_ID ]
        List extIdList11 = [ PARTNO_1_EXT_ID, PARTNO_B_EXT_ID ]
        List extIdList15 = [ PARTNO_3_EXT_ID, PARTNO_F_EXT_ID ]
        candList.addAll(makePartNoCandList(extIdList2, 2))
        candList.addAll(makePartNoCandList(extIdList3, 3))
        candList.addAll(makePartNoCandList(extIdList11, 11))
        candList.addAll(makePartNoCandList(extIdList15, 15))
        return candList
    }

    public List getCandList_PartNo_All(){
        List candList = []
        List extIdList1 = [ PARTNO_0_EXT_ID, PARTNO_1_EXT_ID, PARTNO_5_EXT_ID, PARTNO_6_EXT_ID, 
                            PARTNO_9_EXT_ID, PARTNO_B_EXT_ID, PARTNO_C_EXT_ID, PARTNO_D_EXT_ID ]
        List extIdList2 = [ PARTNO_0_EXT_ID, PARTNO_2_EXT_ID, PARTNO_9_EXT_ID ]
        List extIdList3 = [ PARTNO_0_EXT_ID, PARTNO_3_EXT_ID, PARTNO_7_EXT_ID, PARTNO_8_EXT_ID, 
                            PARTNO_A_EXT_ID, PARTNO_E_EXT_ID, PARTNO_F_EXT_ID, PARTNO_G_EXT_ID ]
        List extIdList4 = [ PARTNO_0_EXT_ID, PARTNO_4_EXT_ID, PARTNO_A_EXT_ID ]
        List extIdList11 = [ PARTNO_0_EXT_ID, PARTNO_1_EXT_ID, PARTNO_5_EXT_ID, PARTNO_9_EXT_ID, PARTNO_B_EXT_ID ]
        List extIdList15 = [ PARTNO_0_EXT_ID, PARTNO_3_EXT_ID, PARTNO_7_EXT_ID, PARTNO_A_EXT_ID, PARTNO_F_EXT_ID ]
        candList.addAll(makePartNoCandList(extIdList1, 1))
        candList.addAll(makePartNoCandList(extIdList2, 2))
        candList.addAll(makePartNoCandList(extIdList3, 3))
        candList.addAll(makePartNoCandList(extIdList4, 4))
        candList.addAll(makePartNoCandList(extIdList11, 11))
        candList.addAll(makePartNoCandList(extIdList15, 15))
        return candList
    }

	public List getCandList_Race_All(){
        List extIdList = [ RACE_1_EXT_ID, RACE_2_EXT_ID, RACE_4_EXT_ID, RACE_8_EXT_ID, RACE_M1_EXT_ID ]
		return makeMaxScoreCandList(extIdList, 1)
	}

	public List getCandList_Race_2(){
        List extIdList = [ RACE_1_EXT_ID, RACE_M1_EXT_ID ]
		return makeMaxScoreCandList(extIdList, 1)
	}

	public List getCandList_Race_3(){
        List extIdList = [ RACE_2_EXT_ID, RACE_M1_EXT_ID ]
		return makeMaxScoreCandList(extIdList, 1)
	}

	public List getCandList_Region_All(){
        List extIdList = [ REGION_1_EXT_ID, REGION_9_EXT_ID, REGION_F_EXT_ID, REGION_U_EXT_ID ]
		return makeMaxScoreCandList(extIdList, 1)
	}

	public List getCandList_Region_1(){
        List extIdList = [ REGION_1_EXT_ID, REGION_U_EXT_ID ]
		return makeMaxScoreCandList(extIdList, 1)
	}

	public List getCandList_Region_F(){
        List extIdList = [ REGION_F_EXT_ID, REGION_U_EXT_ID ]
		return makeMaxScoreCandList(extIdList, 1)
	}

	public List getCandList_Cold(){
        List candTmpList = []
        for(i in 0..99) {
            candTmpList << makeCandTemplate(9999, 1)
        }
		return [ [ COLD_1_EXT_ID, 9999, true,  candTmpList  ] ]
	}

	public List getCandList_LostPart_RW(){
		return [ LOSTPART_RF_CAND_INFO_LIST, LOSTPART_LF_CAND_INFO_LIST, LOSTPART_LW_CAND_INFO_LIST ]
	}

	public List getCandList_LostPart_RFW(){
		return [ LOSTPART_LF_CAND_INFO_LIST, LOSTPART_LW_CAND_INFO_LIST ]
	}

	public List getCandList_LostPart_RFW_LF(){
		return [ LOSTPART_LW_CAND_INFO_LIST ]
	}

	public List getCandList_LostPart_All(){
		return getCandList_LostPart_RW()
	}

	public List getCandList_AfisScript(){
        List extIdList = [ AFISSCRIPT_1_EXT_ID, AFISSCRIPT_2_EXT_ID, AFISSCRIPT_3_EXT_ID ]
		return makeMaxScoreCandList(extIdList, 1)
	}

	public List getCandList_Scope_1(){
		return makeMaxScoreCandList([ SCOPE_1_EXT_ID ], 1)
	}

	public List getCandList_Scope_2(){
		return makeMaxScoreCandList([ SCOPE_2_EXT_ID ], SCOPE_2_BIN_ID, 1)
	}

	public List getCandList_Scope_3(){
		return makeMaxScoreCandList([ SCOPE_3_EXT_ID ], SCOPE_3_BIN_ID, 1)
	}

	public List getCandList_Scope_1_2(){
        List candInfoList = []
        candInfoList.addAll(getCandList_Scope_1())
        candInfoList.addAll(getCandList_Scope_2())
        return candInfoList
	}

	public List getCandList_Scope_1_3(){
        List candInfoList = []
        candInfoList.addAll(getCandList_Scope_1())
        candInfoList.addAll(getCandList_Scope_3())
        return candInfoList
	}

	public List getCandList_Scope_1_2_3(){
        List candInfoList = []
        candInfoList.addAll(getCandList_Scope_1())
        candInfoList.addAll(getCandList_Scope_2())
        candInfoList.addAll(getCandList_Scope_3())
        return candInfoList
	}

	public List getCandList_Fw_100(){
		return [ FW_100_CAND_INFO_LIST ]
	}

	public List getCandList_Fw_150(){
		return [ FW_150_CAND_INFO_LIST ]
	}

	public List getCandList_Fw_null(){
		return [ FW_NULL_CAND_INFO_LIST ]
	}

	public List getCandList_ExtIdSort(){
		return [ EXT_SORT_HIGH_AB_CAND_INFO_LIST, EXT_SORT_HIGH_BA_CAND_INFO_LIST, EXT_SORT_HIGH_1C_CAND_INFO_LIST,
	             EXT_SORT_LOW_AB_CAND_INFO_LIST,  EXT_SORT_LOW_BA_CAND_INFO_LIST,  EXT_SORT_LOW_1C_CAND_INFO_LIST ]
	}

    public List getCandList_multiPartScore_1(){
        List candList = []
        List extIdList = [ MULTIPART_SCORE_EXT_ID ]
        candList.addAll(makeMaxScoreCandList(extIdList, 1))
        candList.addAll(makeMaxScoreCandList(extIdList, 3))
        return candList
    }

    public List getCandList_multiPartScore_2(){
        List extIdList = [ MULTIPART_SCORE_EXT_ID ]
        return makeMaxScoreCandList(extIdList, 1)
    }

	private void setNullFwIfHighLevel(String level){
		if(level == "High") {
			this.fw = null
		}
	}

	private int getMax(int score_1, int score_2){
		if ( score_1 < score_2){
			return score_2
		} else {
			return score_1
		}
	}

    private List makePartNoCandList(List extIdList, int pos) {
        return makePartNoCandList(extIdList, pos, pos)
    }

    private List makePartNoCandList(List extIdList, int startPos, int endPos) {
        if(projectName == "${FUNC}_PC3R") {
            return makeCandList(extIdList, PARTNO_SCORE_PC3R, SCOPE_1_BIN_ID, startPos, endPos)
        }else if(projectName == "${FUNC}_PZIP") {
            List candList = makeCandList(extIdList, PARTNO_SCORE_PZIP, SCOPE_1_BIN_ID, startPos, endPos)
            for(candInfo in candList) {
                candInfo[2] = null
            }
            return candList
        }else{
            assert false, "Project name must be ${FUNC}_PC3R or ${FUNC}_PZIP, actual '${projectName}'"
        }
    }

    private List makeMaxScoreCandList(List extIdList, int pos) {
        return makeCandList(extIdList, 9999, SCOPE_1_BIN_ID, pos, pos)
    }

    private List makeMaxScoreCandList(List extIdList, int containerId, int pos) {
        return makeCandList(extIdList, 9999, containerId, pos, pos)
    }

    private List makeCandList(List extIdList, int score, int pos) {
        return makeCandList(extIdList, score, SCOPE_1_BIN_ID, pos, pos)
    }

    private List makeCandList(List extIdList, int score, int containerId, int startPos, int endPos) {
        List candList = []
        for(extId in extIdList) {
            for(i in startPos..endPos) {
		        candList <<  makeCandInfo(extId, score, containerId, i)
            }
        }
        return candList
    }

	private List makeCandInfo(String extId, int score, int containerId, def pos) {
		return [ extId, score, true,
				[ [ containerId, 1, reqIndex, score,
					[ [ score, pos, A, fw ] ] 
				] ]
			]
    }

    private List makeCandTemplate(int score, int pos) {
        return [ SCOPE_1_BIN_ID, 1, reqIndex, score, [ [ score, pos, A, fw ] ] ]
    }

	private getCorrectAlgorithmObj(def pc3rScore, def pzipScore){
        if(isPc3r()) {
		    return pc3rScore
        }else{
		    return pzipScore
        }
	}

    private boolean isPc3r() {
        if(projectName == "${FUNC}_PC3R") {
		    return true
        }else if(projectName == "${FUNC}_PZIP") {
		    return false
        }else{
            assert false, "Project name must be ${FUNC}_PC3R or ${FUNC}_PZIP, actual '${projectName}'"
        }
    }
}
