package test.degrade.testitem.helper

import test.degrade.management.AbendProcessor
import static test.common.constants.data.ImageDataList.*
import test.degrade.testitem.holder.IrisExtractResultHolder

class IrisExtractHelper extends ConsolidationHelper {

    private static final String PROJECT_NAME = "Iris_extract"

	private static final String EXT_ID_01__03 = "${PROJECT_NAME}--03_fmt39_40"
	private static final String EXT_ID_02__01_02 = "${PROJECT_NAME}--01-02"
	private static final String EXT_ID_03__01 = "${PROJECT_NAME}--01"
	private static final String EXT_ID_03__02_11 = "${PROJECT_NAME}--02-11"
	private static final String EXT_ID_03__17_URL = "${PROJECT_NAME}--17_url"
	private static final String EXT_ID_04__01_02_04 = "${PROJECT_NAME}--01-02_04"

	private static final String EXT_ID_05__01_02_GENDER_M = "${PROJECT_NAME}--01_02_gender-M"
	private static final String EXT_ID_05__01_02_GENDER_F = "${PROJECT_NAME}--01_02_gender-F"
	private static final String EXT_ID_05__01_02_GENDER_U = "${PROJECT_NAME}--01_02_gender-U"

	private static final String EXT_ID_05__03_04_YOB_2000 = "${PROJECT_NAME}--03_04_yob-2000"
	private static final String EXT_ID_05__03_04_YOB_2010 = "${PROJECT_NAME}--03_04_yob-2010"
	private static final String EXT_ID_05__03_04_YOB_M1 = "${PROJECT_NAME}--03_04_yob--1"

	private static final String EXT_ID_05__05_YOBRANGE_1989 = "${PROJECT_NAME}--05_yobRange-1989"
	private static final String EXT_ID_05__05_YOBRANGE_1990 = "${PROJECT_NAME}--05_yobRange-1990"
	private static final String EXT_ID_05__05_YOBRANGE_2010 = "${PROJECT_NAME}--05_yobRange-2010"
	private static final String EXT_ID_05__05_YOBRANGE_2011 = "${PROJECT_NAME}--05_yobRange-2011"
	private static final String EXT_ID_05__05_YOBRANGE_M1 = "${PROJECT_NAME}--05_yobRange--1"

	private static final String EXT_ID_05__07_08_RACE_WHITE = "${PROJECT_NAME}--07_08_race-1"
	private static final String EXT_ID_05__07_08_RACE_BLACK = "${PROJECT_NAME}--07_08_race-2"
	private static final String EXT_ID_05__07_08_RACE_AMERICA_INDIAN = "${PROJECT_NAME}--07_08_race-4"
	private static final String EXT_ID_05__07_08_RACE_ASIAN = "${PROJECT_NAME}--07_08_race-8"
	private static final String EXT_ID_05__07_08_RACE_UNKOWN = "${PROJECT_NAME}--07_08_race--1"

	private static final String EXT_ID_05__09_10_REGION_1 = "${PROJECT_NAME}--09_10_region-1"
	private static final String EXT_ID_05__09_10_REGION_9 = "${PROJECT_NAME}--09_10_region-9"
	private static final String EXT_ID_05__09_10_REGION_A = "${PROJECT_NAME}--09_10_region-A"
	private static final String EXT_ID_05__09_10_REGION_F = "${PROJECT_NAME}--09_10_region-F"
	private static final String EXT_ID_05__09_10_REGION_U = "${PROJECT_NAME}--09_10_region-U"

	private static final String EXT_ID_06__01_07_PREFILTER_1969_3 = "${PROJECT_NAME}--01-07-1969-3"
	private static final String EXT_ID_06__01_07_PREFILTER_1970_0 = "${PROJECT_NAME}--01-07-1970-0"
	private static final String EXT_ID_06__01_07_PREFILTER_1973_0 = "${PROJECT_NAME}--01-07-1973-0"
	private static final String EXT_ID_06__01_07_PREFILTER_1973_1 = "${PROJECT_NAME}--01-07-1973-1"
	private static final String EXT_ID_06__01_07_PREFILTER_1974_0 = "${PROJECT_NAME}--01-07-1974-0"
	private static final String EXT_ID_06__01_07_PREFILTER_1978_1 = "${PROJECT_NAME}--01-07-1978-1"
	private static final String EXT_ID_06__01_07_PREFILTER_1979_0 = "${PROJECT_NAME}--01-07-1979-0"
	private static final String EXT_ID_06__01_07_PREFILTER_1984_0 = "${PROJECT_NAME}--01-07-1984-0"
	private static final String EXT_ID_06__01_07_PREFILTER_1985_0 = "${PROJECT_NAME}--01-07-1985-0"
	private static final String EXT_ID_06__01_07_PREFILTER_1985_1 = "${PROJECT_NAME}--01-07-1985-1"
	private static final String EXT_ID_06__01_07_PREFILTER_1988_0 = "${PROJECT_NAME}--01-07-1988-0"
	private static final String EXT_ID_06__01_07_PREFILTER_1989_3 = "${PROJECT_NAME}--01-07-1989-3"

	private static final String EXT_ID_07__01_04 = "${PROJECT_NAME}--01-04"
	private static final String EXT_ID_08__01_04 = "${PROJECT_NAME}--01-04"
	private static final String EXT_ID_09__01 = "${PROJECT_NAME}--01"

    private static final int FDB_CON_ID = 343
    private static final int EVENT_1 = 1
    private static final int S_REQ_0 = 0
    private static final int POS_0 = 0
    private static final int POS_1 = 1
    private static final int POINT_POS_R = 60
    private static final int POINT_POS_L = 61

    private static final int MAX_SCORE = 9999
    private static final int ZERO_SCORE = 0

    private static String TRUE = "true"
    private static String FALSE = "false"

    private static int j2kRRScore
    private static int j2kRRScoreNoDeInterlace
    private static int j2kRLScore
    private static int j2kLRScore
    private static int j2kLLScore
    private static int j2kLLScoreNoDeInterlace
    private static int j2kFScore
    private static int j2kIRScore
    private static int j2kILScore
     
    private static int jpgRRScore
    private static int jpgRLScore
    private static int jpgLRScore
    private static int jpgLLScore
    private static int jpgFScore
    private static int jpgIRScore
    private static int jpgILScore

    private static int bmpRRScore
    private static int bmpRLScore
    private static int bmpLRScore
    private static int bmpLLScore
    private static int bmpFScore
    private static int bmpIRScore
    private static int bmpILScore

    private static int pngRRScore
    private static int pngRLScore
    private static int pngLRScore
    private static int pngLLScore
    private static int pngFScore
    private static int pngIRScore
    private static int pngILScore

    private static int wsqRRScore
    private static int wsqRLScore
    private static int wsqLRScore
    private static int wsqLLScore
    private static int wsqFScore
    private static int wsqIRScore
    private static int wsqILScore

    private static int rawRRScore
    private static int rawRLScore
    private static int rawLRScore
    private static int rawLLScore
    private static int rawFScore
    private static int rawIRScore
    private static int rawILScore

    private static int maxRRScore
    private static int maxRLScore
    private static int maxLRScore
    private static int maxLLScore
    private static int maxFScore
    private static int maxIRScore
    private static int maxILScore

    private IrisCommonHelper commonHelper
	private IrisExtractResultHolder resultHolder

    IrisExtractHelper(context) {
        super(context)
        this.commonHelper = new IrisCommonHelper(context)
		this.resultHolder = new IrisExtractResultHolder(context)
        initAssertionScore(context)
    }

    public String getDefaultFileImgXml() {
        return commonHelper.getDefaultFileImgXml()
    }

    public String getDefaultSearchImgXml() {
        return commonHelper.getDefaultSearchImgXml()
    }

    public String getJ2kFileImgXml() {
        return getDefaultFileImgXml()
    }

    public String getJ2kSearchImgXml() {
        return getDefaultSearchImgXml()
    }

    public String getJ2kFileImgXmlWithSize() {
        return getJ2kFileImgXml().replaceAll("><data>", " width='${commonHelper.IMG_WIDTH}' height='${commonHelper.IMG_HEIGHT}'><data>")
    }

    public String getJ2kSearchImgXmlWithSize() {
        return getJ2kSearchImgXml().replaceAll("><data>", " width='${commonHelper.IMG_WIDTH}' height='${commonHelper.IMG_HEIGHT}'><data>")
    }

    public String getJpgFileImgXml() {
        return commonHelper.getJpgFileImgXml()
    }

    public String getJpgSearchImgXml() {
        return commonHelper.getJpgSearchImgXml()
    }

    public String getJpgFileImgXmlWithSize() {
        return getJpgFileImgXml().replaceAll("><data>", " width='${commonHelper.IMG_WIDTH}' height='${commonHelper.IMG_HEIGHT}'><data>")
    }

    public String getJpgSearchImgXmlWithSize() {
        return getJpgSearchImgXml().replaceAll("><data>", " width='${commonHelper.IMG_WIDTH}' height='${commonHelper.IMG_HEIGHT}'><data>")
    }

    public String getBmpFileImgXml() {
        return commonHelper.getBmpFileImgXml()
    }

    public String getBmpSearchImgXml() {
        return commonHelper.getBmpSearchImgXml()
    }

    public String getBmpFileImgXmlWithSize() {
        return getBmpFileImgXml().replaceAll("><data>", " width='${commonHelper.IMG_WIDTH}' height='${commonHelper.IMG_HEIGHT}'><data>")
    }

    public String getBmpSearchImgXmlWithSize() {
        return getBmpSearchImgXml().replaceAll("><data>", " width='${commonHelper.IMG_WIDTH}' height='${commonHelper.IMG_HEIGHT}'><data>")
    }

    public String getPngFileImgXml() {
        return commonHelper.getPngFileImgXml()
    }

    public String getPngSearchImgXml() {
        return commonHelper.getPngSearchImgXml()
    }

    public String getPngFileImgXmlWithSize() {
        return getPngFileImgXml().replaceAll("><data>", " width='${commonHelper.IMG_WIDTH}' height='${commonHelper.IMG_HEIGHT}'><data>")
    }

    public String getPngSearchImgXmlWithSize() {
        return getPngSearchImgXml().replaceAll("><data>", " width='${commonHelper.IMG_WIDTH}' height='${commonHelper.IMG_HEIGHT}'><data>")
    }

    public String getWsqFileImgXml() {
        return commonHelper.getWsqFileImgXml()
    }

    public String getWsqSearchImgXml() {
        return commonHelper.getWsqSearchImgXml()
    }

    public String getWsqFileImgXmlWithSize() {
        return getWsqFileImgXml().replaceAll("><data>", " width='${commonHelper.IMG_WIDTH}' height='${commonHelper.IMG_HEIGHT}'><data>")
    }

    public String getWsqSearchImgXmlWithSize() {
        return getWsqSearchImgXml().replaceAll("><data>", " width='${commonHelper.IMG_WIDTH}' height='${commonHelper.IMG_HEIGHT}'><data>")
    }

    public String getRawFileImgXml() {
        return commonHelper.getRawFileImgXml()
    }

    public String getRawSearchImgXml() {
        return commonHelper.getRawSearchImgXml()
    }

    public String getRawFileImgXmlWithoutSize() {
        return getRawFileImgXml().replaceAll("width='${commonHelper.IMG_WIDTH}' height='${commonHelper.IMG_HEIGHT}'", "")
    }

    public String getRawSearchImgXmlWithoutSize() {
        return getRawSearchImgXml().replaceAll("width='${commonHelper.IMG_WIDTH}' height='${commonHelper.IMG_HEIGHT}'", "")
    }

    public String getImgXmlRL() {
        return getDefaultFileImgXml()
    }

    public String getImgXmlLR() {
        StringBuilder sb = new StringBuilder()
        sb.append(commonHelper.getIrisImgXml(I_002_L_F_001_J2K, 61, 2))
        sb.append(commonHelper.getIrisImgXml(I_001_R_F_001_J2K, 60, 2))
        return sb.toString()
    }

    public String getImgXmlLRL() {
        StringBuilder sb = new StringBuilder()
        sb.append(commonHelper.getIrisImgXml(I_002_L_F_001_J2K, 61, 2))
        sb.append(commonHelper.getIrisImgXml(I_001_R_F_001_J2K, 60, 2))
        sb.append(commonHelper.getIrisImgXml(I_002_L_F_001_J2K, 61, 2))
        return sb.toString()
    }

    public String getImgXmlRR() {
        StringBuilder sb = new StringBuilder()
        sb.append(commonHelper.getIrisImgXml(I_001_R_F_001_J2K, 60, 2))
        sb.append(commonHelper.getIrisImgXml(I_002_L_F_001_J2K, 60, 2))
        return sb.toString()
    }

    public String getImgXmlRFace() {
        StringBuilder sb = new StringBuilder()
        sb.append(commonHelper.getIrisImgXml(I_001_R_F_001_J2K, 60, 2))
        sb.append(commonHelper.getIrisImgXml(I_002_L_F_001_J2K, 50, 2))
        return sb.toString()
    }

    public String getSearchImgXmlRL() {
        return commonHelper.getDefaultSearchImgXml()
    }

    public String getSearchImgXmlLR() {
        StringBuilder sb = new StringBuilder()
        sb.append(commonHelper.getIrisImgXml(I_004_L_S_001_J2K, 61, 2))
        sb.append(commonHelper.getIrisImgXml(I_003_R_S_001_J2K, 60, 2))
        return sb.toString()
    }

    public String getFileImgXmlRL() {
        return commonHelper.getDefaultFileImgXml()
    }

    public String getFileImgXmlLR() {
        StringBuilder sb = new StringBuilder()
        sb.append(commonHelper.getIrisImgXml(I_002_L_F_001_J2K, 61, 2))
        sb.append(commonHelper.getIrisImgXml(I_001_R_F_001_J2K, 60, 2))
        return sb.toString()
    }

    public String getFileImgXmlR() {
        StringBuilder sb = new StringBuilder()
        sb.append(commonHelper.getIrisImgXml(I_001_R_F_001_J2K, 60, 2))
        return sb.toString()
    }

    public String getFileImgXmlL() {
        StringBuilder sb = new StringBuilder()
        sb.append(commonHelper.getIrisImgXml(I_002_L_F_001_J2K, 61, 2))
        return sb.toString()
    }

    public String getSearchImgXmlR() {
        StringBuilder sb = new StringBuilder()
        sb.append(commonHelper.getIrisImgXml(I_003_R_S_001_J2K, 60, 2))
        return sb.toString()
    }

    public String getSearchImgXmlL() {
        StringBuilder sb = new StringBuilder()
        sb.append(commonHelper.getIrisImgXml(I_004_L_S_001_J2K, 61, 2))
        return sb.toString()
    }

	public String getFileImgXmlLL() {
		StringBuilder sb = new StringBuilder()
		sb.append(commonHelper.getIrisImgXml(I_002_L_F_001_J2K, 60, 2))
		sb.append(commonHelper.getIrisImgXml(I_002_L_F_001_J2K, 61, 2))
		return sb.toString()
	}

    public String getImgXmlNoPos() {
        return getDefaultFileImgXml().replace("pos='60'", "").replace("pos='61'", "")
    }

    public String getImgXmlNoType() {
        return getDefaultFileImgXml().replaceAll("type='2'", "")
    }

    public String getImgXmlNoData() {
        return """<image pos='60' type='2'></image>
                  <image pos='61' type='2'></image>"""
    }

    public String getImgXmlEmptyData() {
        return """<image pos='60' type='2'><data></data></image>
                  <image pos='61' type='2'><data></data></image>"""
    }

    public String getImgXmlEmptyUrl() {
        return """<image pos='60' type='2'><url></url></image>
                  <image pos='61' type='2'><url></url></image>"""
    }

    public String getJ2kSearchUrlXml() {
        String fSrvRootUrl = soapuiObj.getGlobalFileServerRootUrl()
        String fSrvRootDataPath = soapuiObj.getGlobalFileServerRootDataPath()
		String imgUrlR = "${fSrvRootUrl}${fSrvRootDataPath}/${I_003_R_S_001_J2K}"
		String imgUrlL = "${fSrvRootUrl}${fSrvRootDataPath}/${I_004_L_S_001_J2K}"
		StringBuilder imageXml = new StringBuilder()
		imageXml.append("<image pos='60' type='2'><url>")
		imageXml.append(imgUrlR)
		imageXml.append("</url></image>")
		imageXml.append("<image pos='61' type='2'><url>")
		imageXml.append(imgUrlL)
		imageXml.append("</url></image>")
		return imageXml.toString()
    }

    public List getCandList_fmtId(int id) {
		List candInfo = []
        switch(id){
            case 1:
				candInfo = makeMaxScoreCand(EXT_ID_01__03)
                break
            case 2:
				candInfo = makeMaxScoreCand(EXT_ID_01__03, FALSE)
                break
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return [ candInfo ]
    }

    public List getCandList_imgPos(int id) {
		List candInfo = []
        switch(id){
            case 1:
            case 2:
				candInfo = makeCandInfo(EXT_ID_02__01_02, j2kFScore, j2kIRScore, j2kILScore, 
               		j2kRRScore, j2kRLScore, j2kLRScore, j2kLLScore, TRUE)
                break
            case 3:
            case 4:
				candInfo = makeCandInfo(EXT_ID_02__01_02, j2kFScore, j2kIRScore, j2kILScore, 
               		j2kRRScore, j2kRLScore, j2kLRScore, j2kLLScore, FALSE)
                break
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return [ candInfo ]
    }

    public List getCandList_imgType_j2k(int id) {
		List candInfo = []
        switch(id){
            case 1:
				candInfo = makeCandInfo(EXT_ID_03__02_11, j2kFScore, j2kIRScore, j2kILScore, 
                	j2kRRScore, j2kRLScore, j2kLRScore, j2kLLScore, TRUE)
                break
            case 6:
				candInfo = makeCandInfo(EXT_ID_03__02_11, j2kFScore, j2kIRScore, j2kILScore, 
                	j2kRRScore, j2kRLScore, j2kLRScore, j2kLLScore, FALSE)
                break
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return [ candInfo ]
    }

    public List getCandList_imgType_jpg(int id) {
		List candInfo = []
        switch(id){
            case 2:
				candInfo = makeCandInfo(EXT_ID_03__02_11, jpgFScore, jpgIRScore, jpgILScore, 
                	jpgRRScore, jpgRLScore, jpgLRScore, jpgLLScore, TRUE)
                break
            case 7:
				candInfo = makeCandInfo(EXT_ID_03__02_11, jpgFScore, jpgIRScore, jpgILScore, 
                	jpgRRScore, jpgRLScore, jpgLRScore, jpgLLScore, FALSE)
                break
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return [ candInfo ]
    }

    public List getCandList_imgType_bmp(int id) {
		List candInfo = []
        switch(id){
            case 3:
				candInfo = makeCandInfo(EXT_ID_03__02_11, bmpFScore, bmpIRScore, bmpILScore, 
                	bmpRRScore, bmpRLScore, bmpLRScore, bmpLLScore, TRUE)
                break
            case 8:
				candInfo = makeCandInfo(EXT_ID_03__02_11, bmpFScore, bmpIRScore, bmpILScore, 
                	bmpRRScore, bmpRLScore, bmpLRScore, bmpLLScore, FALSE)
                break
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return [ candInfo ]
    }

    public List getCandList_imgType_png(int id) {
		List candInfo = []
        switch(id){
            case 4:
				candInfo = makeCandInfo(EXT_ID_03__02_11, pngFScore, pngIRScore, pngILScore, 
                	pngRRScore, pngRLScore, pngLRScore, pngLLScore, TRUE)
                break
            case 9:
				candInfo = makeCandInfo(EXT_ID_03__02_11, pngFScore, pngIRScore, pngILScore, 
                	pngRRScore, pngRLScore, pngLRScore, pngLLScore, FALSE)
                break
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return [ candInfo ]
    }

    public List getCandList_imgType_wsq(int id) {
		List candInfo = []
        switch(id){
            case 5:
				candInfo = makeCandInfo(EXT_ID_03__02_11, wsqFScore, wsqIRScore, wsqILScore, 
                	wsqRRScore, wsqRLScore, wsqLRScore, wsqLLScore, TRUE)
                break
            case 10:
				candInfo = makeCandInfo(EXT_ID_03__02_11, wsqFScore, wsqIRScore, wsqILScore, 
                	wsqRRScore, wsqRLScore, wsqLRScore, wsqLLScore, FALSE)
                break
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return [ candInfo ]
    }

    public List getCandList_imgType_raw(int id) {
		List candInfo = []
        switch(id){
            case 1:
				candInfo = makeCandInfo(EXT_ID_03__01, rawFScore, rawIRScore, rawILScore, 
               		rawRRScore, rawRLScore, rawLRScore, rawLLScore, TRUE)
                break
            case 2:
				candInfo = makeCandInfo(EXT_ID_03__01, rawFScore, rawIRScore, rawILScore, 
               		rawRRScore, rawRLScore, rawLRScore, rawLLScore, FALSE)
                break
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return [ candInfo ]
    }

    public List getCandList_imgType_url(int id) {
		List candInfo = []
        switch(id){
            case 1:
				candInfo = makeCandInfo(EXT_ID_03__17_URL, j2kFScore, j2kIRScore, j2kILScore, 
                	j2kRRScore, j2kRLScore, j2kLRScore, j2kLLScore, TRUE)
                break
            case 2:
				candInfo = makeCandInfo(EXT_ID_03__17_URL, j2kFScore, j2kIRScore, j2kILScore, 
                	j2kRRScore, j2kRLScore, j2kLRScore, j2kLLScore, FALSE)
                break
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return [ candInfo ]
    }

    public List getCandList_imgEnh(int id) {
		List candInfo
        switch(id){
            case 1:
				candInfo = makeDefaultScoreCand(EXT_ID_04__01_02_04)
                break
            case 2:
            case 3:
				int fScore = Math.max(j2kRRScoreNoDeInterlace, j2kLLScoreNoDeInterlace)
				candInfo =  makeCandInfo(EXT_ID_04__01_02_04, 
					fScore, j2kRRScoreNoDeInterlace, j2kLLScoreNoDeInterlace,
					j2kRRScoreNoDeInterlace, ZERO_SCORE,
					ZERO_SCORE, j2kLLScoreNoDeInterlace, TRUE)
                break
            case 4:
				candInfo = makeDefaultScoreCand(EXT_ID_04__01_02_04, FALSE)
                break
            case 5:
            case 6:
				int fScore = Math.max(j2kRRScoreNoDeInterlace, j2kLLScoreNoDeInterlace)
				candInfo =  makeCandInfo(EXT_ID_04__01_02_04, 
					fScore, j2kRRScoreNoDeInterlace, j2kLLScoreNoDeInterlace,
					j2kRRScoreNoDeInterlace, ZERO_SCORE,
					ZERO_SCORE, j2kLLScoreNoDeInterlace, FALSE)
                break
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return [ candInfo ]
    }

    public List getCandList_gender_M(int id) {
        List candInfoList = []
        switch(id){
            case 1:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__01_02_GENDER_M) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__01_02_GENDER_U) )
				break;
			case 2:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__01_02_GENDER_M, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__01_02_GENDER_U, FALSE) )
				break;
            default:
                assert false, "Unexpected id value '${id}'."
        }
			
        return candInfoList
    }

    public List getCandList_gender_F(int id) {
        List candInfoList = []
        switch(id){
            case 1:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__01_02_GENDER_F) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__01_02_GENDER_U) )
				break;
            case 2:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__01_02_GENDER_F, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__01_02_GENDER_U, FALSE) )
				break;
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return candInfoList
    }

    public List getCandList_gender_U(int id) {
        List candInfoList = []
        switch(id){
            case 1:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__01_02_GENDER_M) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__01_02_GENDER_F) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__01_02_GENDER_U) )
				break;
            case 2:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__01_02_GENDER_M, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__01_02_GENDER_F, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__01_02_GENDER_U, FALSE) )
				break;
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return candInfoList
    }

    public List getCandList_yob_2000(int id) {
        List candInfoList = []
        switch(id){
            case 1:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__03_04_YOB_2000) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__03_04_YOB_M1) )
				break;
            case 2:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__03_04_YOB_2000, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__03_04_YOB_M1, FALSE) )
				break;
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return candInfoList
    }

    public List getCandList_yob_2010(int id) {
        List candInfoList = []
        switch(id){
            case 1:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__03_04_YOB_2010) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__03_04_YOB_M1) )
				break;
            case 2:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__03_04_YOB_2010, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__03_04_YOB_M1, FALSE) )
				break;
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return candInfoList
    }

    public List getCandList_yob_M1(int id) {
        List candInfoList = []
        switch(id){
            case 1:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__03_04_YOB_2000) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__03_04_YOB_2010) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__03_04_YOB_M1) )
				break;
            case 2:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__03_04_YOB_2000, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__03_04_YOB_2010, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__03_04_YOB_M1, FALSE) )
				break;
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return candInfoList
    }

    public List getCandList_yobRange(int id) {
        List candInfoList = []
        switch(id){
            case 1:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__05_YOBRANGE_1990) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__05_YOBRANGE_2010) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__05_YOBRANGE_M1) )
				break;
            case 2:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__05_YOBRANGE_1990, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__05_YOBRANGE_2010, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__05_YOBRANGE_M1, FALSE) )
				break;
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return candInfoList
    }

    public List getCandList_race_white(int id) {
        List candInfoList = []
        switch(id){
            case 1:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__07_08_RACE_WHITE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__07_08_RACE_UNKOWN) )
				break;
            case 2:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__07_08_RACE_WHITE, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__07_08_RACE_UNKOWN, FALSE) )
				break;
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return candInfoList
    }

    public List getCandList_race_black(int id) {
        List candInfoList = []
        switch(id){
            case 1:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__07_08_RACE_BLACK) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__07_08_RACE_UNKOWN) )
				break;
            case 2:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__07_08_RACE_BLACK, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__07_08_RACE_UNKOWN, FALSE) )
				break;
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return candInfoList
    }

    public List getCandList_race_american_idian(int id) {
        List candInfoList = []
        switch(id){
            case 1:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__07_08_RACE_AMERICA_INDIAN) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__07_08_RACE_UNKOWN) )
				break;
            case 2:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__07_08_RACE_AMERICA_INDIAN, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__07_08_RACE_UNKOWN, FALSE) )
				break;
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return candInfoList
    }

    public List getCandList_race_asian(int id) {
        List candInfoList = []
        switch(id){
            case 1:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__07_08_RACE_ASIAN) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__07_08_RACE_UNKOWN) )
				break;
            case 2:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__07_08_RACE_ASIAN, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__07_08_RACE_UNKOWN, FALSE) )
				break;
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return candInfoList
    }

    public List getCandList_race_unknown(int id) {
        List candInfoList = []
        switch(id){
            case 1:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__07_08_RACE_WHITE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__07_08_RACE_BLACK) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__07_08_RACE_AMERICA_INDIAN) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__07_08_RACE_ASIAN) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__07_08_RACE_UNKOWN) )
				break;
            case 2:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__07_08_RACE_WHITE, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__07_08_RACE_BLACK, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__07_08_RACE_AMERICA_INDIAN, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__07_08_RACE_ASIAN, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__07_08_RACE_UNKOWN, FALSE) )
				break;
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return candInfoList
    }

    public List getCandList_region_1(int id) {
        List candInfoList = []
        switch(id){
            case 1:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__09_10_REGION_1) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__09_10_REGION_U) )
				break;
            case 2:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__09_10_REGION_1, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__09_10_REGION_U, FALSE) )
				break;
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return candInfoList
    }

    public List getCandList_region_9(int id) {
        List candInfoList = []
        switch(id){
            case 1:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__09_10_REGION_9) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__09_10_REGION_U) )
				break;
            case 2:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__09_10_REGION_9, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__09_10_REGION_U, FALSE) )
				break;
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return candInfoList
    }

    public List getCandList_region_A(int id) {
        List candInfoList = []
        switch(id){
            case 1:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__09_10_REGION_A) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__09_10_REGION_U) )
				break;
            case 2:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__09_10_REGION_A, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__09_10_REGION_U, FALSE) )
				break;
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return candInfoList
    }

    public List getCandList_region_F(int id) {
        List candInfoList = []
        switch(id){
            case 1:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__09_10_REGION_F) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__09_10_REGION_U) )
				break;
            case 2:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__09_10_REGION_F, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__09_10_REGION_U, FALSE) )
				break;
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return candInfoList
    }

    public List getCandList_region_U(int id) {
        List candInfoList = []
        switch(id){
            case 1:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__09_10_REGION_1) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__09_10_REGION_9) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__09_10_REGION_A) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__09_10_REGION_F) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__09_10_REGION_U) )
				break;
            case 2:
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__09_10_REGION_1, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__09_10_REGION_9, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__09_10_REGION_A, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__09_10_REGION_F, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_05__09_10_REGION_U, FALSE) )
				break;
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return candInfoList
    }

    public List getCandList_prefilter_1(int id) {
        List candInfoList = []
        switch(id){
            case 1:
            case 3:
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1969_3) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1970_0) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1973_0) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1973_1) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1974_0) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1978_1) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1979_0) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1984_0) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1985_0) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1985_1) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1988_0) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1989_3) )
				break;
            case 8:
            case 10:
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1969_3, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1970_0, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1973_0, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1973_1, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1974_0, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1978_1, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1979_0, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1984_0, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1985_0, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1985_1, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1988_0, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1989_3, FALSE) )
				break;
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return candInfoList
    }

    public List getCandList_prefilter_2(int id) {
        List candInfoList = []
        switch(id){
            case 2:
            case 6:
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1973_1) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1974_0) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1978_1) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1979_0) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1984_0) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1985_1) )
				break;
            case 9:
            case 13:
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1973_1, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1974_0, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1978_1, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1979_0, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1984_0, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1985_1, FALSE) )
				break;
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return candInfoList
    }

    public List getCandList_prefilter_3(int id) {
        List candInfoList = []
        switch(id){
            case 4:
            case 7:
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1970_0) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1973_0) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1973_1) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1974_0) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1978_1) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1979_0) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1984_0) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1985_0) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1985_1) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1988_0) )
				break;
            case 11:
            case 14:
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1970_0, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1973_0, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1973_1, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1974_0, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1978_1, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1979_0, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1984_0, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1985_0, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1985_1, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1988_0, FALSE) )
				break;
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return candInfoList
    }

    public List getCandList_prefilter_4(int id) {
        List candInfoList = []
        switch(id){
            case 5:
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1979_0) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1984_0) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1985_0) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1985_1) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1988_0) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1989_3) )
				break;
            case 12:
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1979_0, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1984_0, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1985_0, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1985_1, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1988_0, FALSE) )
				candInfoList.add( makeMaxScoreCand(EXT_ID_06__01_07_PREFILTER_1989_3, FALSE) )
				break;
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return candInfoList
    }

    public List getCandList_ext_output_RL(int id) {
	 	List candInfo = []
        switch(id){
            case 1:
				candInfo = makeMaxScoreCand(EXT_ID_08__01_04)
				break;
            case 2:
				candInfo = makeMaxScoreCand(EXT_ID_08__01_04, FALSE)
				break;
            default:
                assert false, "Unexpected id value '${id}'."
        }
	
        return [ candInfo ]
    }

    public List getCandList_ext_output_LR(int id) {
        return getCandList_ext_output_RL(id)
    }

    public List getCandList_ext_output_R() {
		List candInfo = 
           	[ EXT_ID_08__01_04, maxRRScore, true,
				[ [ FDB_CON_ID, EVENT_1, S_REQ_0, maxRRScore,
					[ [ maxRRScore, POS_0, 
                       	[ [ POS_0, maxRRScore ] ] ] ] ] ] ]
		return [ candInfo ]
    }

    public List getCandList_ext_output_L() {
		List candInfo = 
            [ EXT_ID_08__01_04, maxLLScore, true,
				[ [ FDB_CON_ID, EVENT_1, S_REQ_0, maxLLScore,
					[ [ maxLLScore, POS_1, 
                        [ [ POS_1, maxLLScore ] ] ] ] ] ] ]
        return [ candInfo ]
    }

    public List getCandList_extMode(int id) {
		int scoreR
		int scoreL
		List candInfo = []
        switch(id){
            case 1:
				scoreR = 3964
				scoreL = 3581
				candInfo =  makeCandInfo(EXT_ID_07__01_04, scoreR, scoreR, scoreL, scoreR, ZERO_SCORE, ZERO_SCORE, scoreL, TRUE)
                break
            case 2:
            case 3:
            case 4:
				scoreR = 3840
				scoreL = 3763
				candInfo =  makeCandInfo(EXT_ID_07__01_04, scoreR, scoreR, scoreL, scoreR, ZERO_SCORE, ZERO_SCORE, scoreL, TRUE)
                break
            case 5:
				scoreR = 3964
				scoreL = 3581
				candInfo =  makeCandInfo(EXT_ID_07__01_04, scoreR, scoreR, scoreL, scoreR, ZERO_SCORE, ZERO_SCORE, scoreL, FALSE)
                break
            case 6:
            case 7:
            case 8:
				scoreR = 3840
				scoreL = 3763
				candInfo =  makeCandInfo(EXT_ID_07__01_04, scoreR, scoreR, scoreL, scoreR, ZERO_SCORE, ZERO_SCORE, scoreL, FALSE)
                break
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return [ candInfo ]
    }

    public List getCandList_coreEngine(int id) {
		List candInfo = []
        switch(id){
            case 1:
				candInfo = makeMaxScoreCand(EXT_ID_09__01)
                break
            case 2:
				candInfo = makeMaxScoreCand(EXT_ID_09__01, FALSE)
                break
            default:
                assert false, "Unexpected id value '${id}'."
        }
        return [ candInfo ]
    }

    public List makeDefaultScoreCand(String extId) {
		return makeCandInfo(extId, j2kFScore, j2kIRScore, j2kILScore, j2kRRScore, j2kRLScore, j2kLRScore, j2kLLScore, TRUE)
    }

    public List makeDefaultScoreCand(String extId, String isCrossMatch) {
		return makeCandInfo(extId, j2kFScore, j2kIRScore, j2kILScore, j2kRRScore, j2kRLScore, j2kLRScore, j2kLLScore, isCrossMatch)
    }

    private List makeMaxScoreCand(String extId) {
		return makeCandInfo(extId, getHighScore(getHighScore(maxRRScore, maxRLScore), getHighScore(maxLRScore, maxLLScore)),
							getHighScore(maxRRScore, maxRLScore), getHighScore(maxLRScore, maxLLScore),
							maxRRScore, maxRLScore, maxLRScore, maxLLScore, TRUE)
    }

    private List makeMaxScoreCand(String extId, String isCrossMatch) {
		return makeCandInfo(extId, getHighScore(getHighScore(maxRRScore, maxRLScore), getHighScore(maxLRScore, maxLLScore)),
							getHighScore(maxRRScore, maxRLScore), getHighScore(maxLRScore, maxLLScore),
							maxRRScore, maxRLScore, maxLRScore, maxLLScore, isCrossMatch)
    }

    private List makeCandInfo(
                String extId, int finalScore, int iScoreR, int iScoreL, 
                int rScoreRR, int rScoreRL, int rScoreLR, int rScoreLL, String isCrossMatch) {
		def candInfo = []
		if("x${isCrossMatch}" == "x${TRUE}"){
			candInfo = 
			[ extId, finalScore, true,
				[ [ FDB_CON_ID, EVENT_1, S_REQ_0, finalScore,
					[ [ iScoreR, POS_0, 
                        [ [ POS_0, rScoreRR ], [ POS_1, rScoreRL ] ] ],
					  [ iScoreL, POS_1, 
                        [ [ POS_0, rScoreLR ], [ POS_1, rScoreLL ] ] ] ] ] ] ]
		}else if("x${isCrossMatch}" == "x${FALSE}"){
			candInfo = 
			[ extId, finalScore, true,
				[ [ FDB_CON_ID, EVENT_1, S_REQ_0, finalScore,
					[ [ iScoreR, POS_0, 
                        [ [ POS_0, rScoreRR ] ] ],
					  [ iScoreL, POS_1, 
                        [ [ POS_1, rScoreLL ] ] ] ] ] ] ]
		}else{
            new AbendProcessor(soapuiObj.getContext()).abendTest("Unexpected isCrossMatch value '${isCrossMatch}'.")
        }

        return candInfo
    }

    public int getExpQuality_imgEnh(boolean isDeInterlace, int pointPos, String key) {
		if(pointPos == POINT_POS_R) {
			return resultHolder.getExpQuality_imgEnh_R(isDeInterlace, key)
		}else if(pointPos == POINT_POS_L) {
			return resultHolder.getExpQuality_imgEnh_L(isDeInterlace, key)
		}else{
			assert false, "Unexpected position value '${pointPos}'."
		}
    }

    public List getExpPupilPoints_imgEnh(boolean isDeInterlace, int pointPos, String key) {
		if(pointPos == POINT_POS_R) {
			return resultHolder.getExpPupilPoints_imgEnh_R(isDeInterlace, key)
		}else if(pointPos == POINT_POS_L) {
			return resultHolder.getExpPupilPoints_imgEnh_L(isDeInterlace, key)
		}else{
			assert false, "Unexpected position value '${pointPos}'."
		}
    }

    public List getExpIrisPoints_imgEnh(boolean isDeInterlace, int pointPos, String key) {
		if(pointPos == POINT_POS_R) {
			return resultHolder.getExpIrisPoints_imgEnh_R(isDeInterlace, key)
		}else if(pointPos == POINT_POS_L) {
			return resultHolder.getExpIrisPoints_L(isDeInterlace, key)
		}else{
			assert false, "Unexpected position value '${pointPos}'."
		}
    }

    public int getExpQuality_flxBModel(int id, int pointPos) {
        switch(id){
            case 1:
            case 3:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpQuality_flxBModel_true_R()
                }else{
                    return resultHolder.getExpQuality_flxBModel_true_L()
                }
                break
            case 2:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpQuality_flxBModel_false_R()
                }else{
                    return resultHolder.getExpQuality_flxBModel_false_L()
                }
                break
            default:
                assert false, "Unexpected id value '${id}'."
        }
    }

    public List getExpPupilPoints_flxBModel(int id, int pointPos) {
        switch(id){
            case 1:
            case 3:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpPupilPoints_flxBModel_true_R()
                }else{
                    return resultHolder.getExpPupilPoints_flxBModel_true_L()
                }
                break
            case 2:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpPupilPoints_flxBModel_false_R()
                }else{
                    return resultHolder.getExpPupilPoints_flxBModel_false_L()
                }
                break
            default:
                assert false, "Unexpected id value '${id}'."
        }
    }

    public List getExpIrisPoints_flxBModel(int id, int pointPos) {
        switch(id){
            case 1:
            case 3:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpIrisPoints_flxBModel_true_R()
                }else{
                    return resultHolder.getExpIrisPoints_flxBModel_true_L()
                }
                break
            case 2:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpIrisPoints_flxBModel_false_R()
                }else{
                    return resultHolder.getExpIrisPoints_flxBModel_false_L()
                }
                break
            default:
                assert false, "Unexpected id value '${id}'."
        }
    }

    public int getExpQuality_minPup(int id, int pointPos) {
        switch(id){
            case 1:
            case 3:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpQuality_minPup_R_1()
                }else{
                    return resultHolder.getExpQuality_minPup_L_1()
                }
                break
            case 2:
            case 4:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpQuality_minPup_R_2()
                }else{
                    return resultHolder.getExpQuality_minPup_L_2()
                }
                break
            default:
                assert false, "Unexpected id value '${id}'."
        }
    }

    public List getExpPupilPoints_minPup(int id, int pointPos) {
        switch(id){
            case 1:
            case 3:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpPupilPoints_minPup_R_1()
                }else{
                    return resultHolder.getExpPupilPoints_minPup_L_1()
                }
                break
            case 2:
            case 4:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpPupilPoints_minPup_R_2()
                }else{
                    return resultHolder.getExpPupilPoints_minPup_L_2()
                }
                break
            default:
                assert false, "Unexpected id value '${id}'."
        }
    }

    public List getExpIrisPoints_minPup(int id, int pointPos) {
        switch(id){
            case 1:
            case 3:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpIrisPoints_minPup_R_1()
                }else{
                    return resultHolder.getExpIrisPoints_minPup_L_1()
                }
                break
            case 2:
            case 4:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpIrisPoints_minPup_R_2()
                }else{
                    return resultHolder.getExpIrisPoints_minPup_L_2()
                }
                break
            default:
                assert false, "Unexpected id value '${id}'."
        }
    }

    public int getExpQuality_maxPup(int id, int pointPos) {
        switch(id){
            case 1:
            case 3:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpQuality_maxPup_R_1()
                }else{
                    return resultHolder.getExpQuality_maxPup_L_1()
                }
                break
            case 2:
            case 4:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpQuality_maxPup_R_2()
                }else{
                    return resultHolder.getExpQuality_maxPup_L_2()
                }
                break
            default:
                assert false, "Unexpected id value '${id}'."
        }
    }

    public List getExpPupilPoints_maxPup(int id, int pointPos) {
        switch(id){
            case 1:
            case 3:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpPupilPoints_maxPup_R_1()
                }else{
                    return resultHolder.getExpPupilPoints_maxPup_L_1()
                }
                break
            case 2:
            case 4:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpPupilPoints_maxPup_R_2()
                }else{
                    return resultHolder.getExpPupilPoints_maxPup_L_2()
                }
                break
            default:
                assert false, "Unexpected id value '${id}'."
        }
    }

    public List getExpIrisPoints_maxPup(int id, int pointPos) {
        switch(id){
            case 1:
            case 3:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpIrisPoints_maxPup_R_1()
                }else{
                    return resultHolder.getExpIrisPoints_maxPup_L_1()
                }
                break
            case 2:
            case 4:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpIrisPoints_maxPup_R_2()
                }else{
                    return resultHolder.getExpIrisPoints_maxPup_L_2()
                }
                break
            default:
                assert false, "Unexpected id value '${id}'."
        }
    }

    public int getExpQuality_minIris(int id, int pointPos) {
        switch(id){
            case 1:
            case 3:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpQuality_minIris_R_1()
                }else{
                    return resultHolder.getExpQuality_minIris_L_1()
                }
                break
            case 2:
            case 4:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpQuality_minIris_R_2()
                }else{
                    return resultHolder.getExpQuality_minIris_L_2()
                }
                break
            default:
                assert false, "Unexpected id value '${id}'."
        }
    }

    public List getExpPupilPoints_minIris(int id, int pointPos) {
        switch(id){
            case 1:
            case 3:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpPupilPoints_minIris_R_1()
                }else{
                    return resultHolder.getExpPupilPoints_minIris_L_1()
                }
                break
            case 2:
            case 4:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpPupilPoints_minIris_R_2()
                }else{
                    return resultHolder.getExpPupilPoints_minIris_L_2()
                }
                break
            default:
                assert false, "Unexpected id value '${id}'."
        }
    }

    public List getExpIrisPoints_minIris(int id, int pointPos) {
        switch(id){
            case 1:
            case 3:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpIrisPoints_minIris_R_1()
                }else{
                    return resultHolder.getExpIrisPoints_minIris_L_1()
                }
                break
            case 2:
            case 4:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpIrisPoints_minIris_R_2()
                }else{
                    return resultHolder.getExpIrisPoints_minIris_L_2()
                }
                break
            default:
                assert false, "Unexpected id value '${id}'."
        }
    }

    public int getExpQuality_maxIris(int id, int pointPos) {
        switch(id){
            case 1:
            case 3:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpQuality_maxIris_R_1()
                }else{
                    return resultHolder.getExpQuality_maxIris_L_1()
                }
                break
            case 2:
            case 4:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpQuality_maxIris_R_2()
                }else{
                    return resultHolder.getExpQuality_maxIris_L_2()
                }
                break
            default:
                assert false, "Unexpected id value '${id}'."
        }
    }

    public List getExpPupilPoints_maxIris(int id, int pointPos) {
        switch(id){
            case 1:
            case 3:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpPupilPoints_maxIris_R_1()
                }else{
                    return resultHolder.getExpPupilPoints_maxIris_L_1()
                }
                break
            case 2:
            case 4:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpPupilPoints_maxIris_R_2()
                }else{
                    return resultHolder.getExpPupilPoints_maxIris_L_2()
                }
                break
            default:
                assert false, "Unexpected id value '${id}'."
        }
    }

    public List getExpIrisPoints_maxIris(int id, int pointPos) {
        switch(id){
            case 1:
            case 3:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpIrisPoints_maxIris_R_1()
                }else{
                    return resultHolder.getExpIrisPoints_maxIris_L_1()
                }
                break
            case 2:
            case 4:
                if(pointPos == POINT_POS_R) {
                    return resultHolder.getExpIrisPoints_maxIris_R_2()
                }else{
                    return resultHolder.getExpIrisPoints_maxIris_L_2()
                }
                break
            default:
                assert false, "Unexpected id value '${id}'."
        }
    }

    public int getExpQuality_outputPayload(int pointPos) {
		return getExpQuality_flxBModel(2, pointPos)
    }

    public List getExpPupilPoints_outputPayload(int pointPos) {
		return getExpPupilPoints_flxBModel(2, pointPos)
    }

    public List getExpIrisPoints_outputPayload(int pointPos) {
		return getExpIrisPoints_flxBModel(2, pointPos)
	}

    private void initAssertionScore(context) {
        j2kRRScore = commonHelper.j2kRRScore
        j2kRLScore = commonHelper.j2kRLScore
        j2kLRScore = commonHelper.j2kLRScore
        j2kLLScore = commonHelper.j2kLLScore
        j2kFScore = commonHelper.j2kFScore
        j2kIRScore = commonHelper.j2kIRScore
        j2kILScore = commonHelper.j2kILScore
        j2kRRScoreNoDeInterlace = commonHelper.j2kRRScoreNoDeInterlace
        j2kLLScoreNoDeInterlace = commonHelper.j2kLLScoreNoDeInterlace
     
        jpgRRScore = commonHelper.jpgRRScore
        jpgRLScore = commonHelper.jpgRLScore
        jpgLRScore = commonHelper.jpgLRScore
        jpgLLScore = commonHelper.jpgLLScore
        jpgFScore = commonHelper.jpgFScore
        jpgIRScore = commonHelper.jpgIRScore
        jpgILScore = commonHelper.jpgILScore

        bmpRRScore = commonHelper.bmpRRScore
        bmpRLScore = commonHelper.bmpRLScore
        bmpLRScore = commonHelper.bmpLRScore
        bmpLLScore = commonHelper.bmpLLScore
        bmpFScore = commonHelper.bmpFScore
        bmpIRScore = commonHelper.bmpIRScore
        bmpILScore = commonHelper.bmpILScore

        pngRRScore = commonHelper.pngRRScore
        pngRLScore = commonHelper.pngRLScore
        pngLRScore = commonHelper.pngLRScore
        pngLLScore = commonHelper.pngLLScore
        pngFScore = commonHelper.pngFScore
        pngIRScore = commonHelper.pngIRScore
        pngILScore = commonHelper.pngILScore

        wsqRRScore = commonHelper.wsqRRScore
        wsqRLScore = commonHelper.wsqRLScore
        wsqLRScore = commonHelper.wsqLRScore
        wsqLLScore = commonHelper.wsqLLScore
        wsqFScore = commonHelper.wsqFScore
        wsqIRScore = commonHelper.wsqIRScore
        wsqILScore = commonHelper.wsqILScore

        rawRRScore = commonHelper.rawRRScore
        rawRLScore = commonHelper.rawRLScore
        rawLRScore = commonHelper.rawLRScore
        rawLLScore = commonHelper.rawLLScore
        rawFScore = commonHelper.rawFScore
        rawIRScore = commonHelper.rawIRScore
        rawILScore = commonHelper.rawILScore

        maxRRScore = commonHelper.maxRRScore
        maxRLScore = commonHelper.maxRLScore
        maxLRScore = commonHelper.maxLRScore
        maxLLScore = commonHelper.maxLLScore
        maxFScore = commonHelper.maxFScore
        maxIRScore = commonHelper.maxIRScore
        maxILScore = commonHelper.maxILScore
    }

	private getHighScore(def score_1, def score_2){
		return [ score_1, score_2 ].max()
	}

}

