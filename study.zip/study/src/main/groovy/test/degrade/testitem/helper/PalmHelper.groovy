package test.degrade.testitem.helper

import test.common.constants.aim.*
import static test.common.constants.aim.AIMXmlAttribute.*

class PalmHelper extends PayloadHelper {
	
	PalmHelper(context){
		super(context)
	}

    protected void initPayloadMap() {
        payloadMap = new PalmPayloadMap()
    }

    public String makePayload() {
        StringBuilder sb = new StringBuilder()
        sb.append("<search-inputs-payload>\n")
        sb.append("<ns2:search-inputs-payload xmlns:ns2='urn:nec:aim'>\n")
        sb.append("<meta-info>\n")
        sb.append(makeMetaCommonXml())
        sb.append(makeMetaTenprintXml())
        sb.append(makeMetaLatentXml())
        sb.append("</meta-info>\n")
        sb.append(makePrefilterOptXml())
        sb.append(makePalmOptionsXml())
        sb.append("</ns2:search-inputs-payload>\n")
        sb.append("</search-inputs-payload>\n")
        return sb.toString()
    }

}
