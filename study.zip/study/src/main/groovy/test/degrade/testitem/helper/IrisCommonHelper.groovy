package test.degrade.testitem.helper

import static test.common.constants.data.ImageDataList.*
import static test.common.constants.aim.AIMWord.*
import test.degrade.management.AbendProcessor
import test.degrade.properties.GlobalProperties

class IrisCommonHelper extends TestImgXmlMaker {

    private static final int ZERO_SCORE = 0
    private static final int AIM_MAX_SCORE = 9999
    private static final int IMG_WIDTH = 640
    private static final int IMG_HEIGHT = 480

    private static int j2kRRScore
    private static int j2kRRScoreSmode1
    private static int j2kRRScoreSmode3
    private static int j2kRRScoreNoDeInterlace
    private static int j2kRLScore
    private static int j2kLRScore
    private static int j2kLLScore
    private static int j2kLLScoreSmode1
    private static int j2kLLScoreSmode3
    private static int j2kLLScoreNoDeInterlace
    private static int j2kFScore
    private static int j2kIRScore
    private static int j2kILScore
     
    private static int jpgRRScore
    private static int jpgRLScore
    private static int jpgLRScore
    private static int jpgLLScore
    private static int jpgFScore
    private static int jpgIRScore
    private static int jpgILScore

    private static int bmpRRScore
    private static int bmpRLScore
    private static int bmpLRScore
    private static int bmpLLScore
    private static int bmpFScore
    private static int bmpIRScore
    private static int bmpILScore

    private static int pngRRScore
    private static int pngRLScore
    private static int pngLRScore
    private static int pngLLScore
    private static int pngFScore
    private static int pngIRScore
    private static int pngILScore
    private static int pngRRScoreSmode1
    private static int pngRRScoreSmode3
    private static int pngLLScoreSmode1
    private static int pngLLScoreSmode3

    private static int wsqRRScore
    private static int wsqRLScore
    private static int wsqLRScore
    private static int wsqLLScore
    private static int wsqFScore
    private static int wsqIRScore
    private static int wsqILScore

    private static int rawRRScore
    private static int rawRLScore
    private static int rawLRScore
    private static int rawLLScore
    private static int rawFScore
    private static int rawIRScore
    private static int rawILScore

    private static int maxRRScore
    private static int maxRLScore
    private static int maxLRScore
    private static int maxLLScore
    private static int maxFScore
    private static int maxIRScore
    private static int maxILScore

    private AbendProcessor abendProcessor
    private String engine
    
    IrisCommonHelper(context) {
        super(context)
        this.abendProcessor = new AbendProcessor(context)
        this.engine = new GlobalProperties(context).getIrisEngine().toUpperCase()
        initAssertionScore()
    }

    public String getDefaultFileImgXml() {
        return getJ2kFileImgXml()
    }

    public String getDefaultSearchImgXml() {
        return getJ2kSearchImgXml()
    }

    public String getJ2kFileImgXml() {
        StringBuilder sb = new StringBuilder()
        sb.append(getIrisImgXml(I_001_R_F_001_J2K, 60, 2))
        sb.append(getIrisImgXml(I_002_L_F_001_J2K, 61, 2))
        return sb.toString()
    }

    public String getJ2kSearchImgXml() {
        StringBuilder sb = new StringBuilder()
        sb.append(getIrisImgXml(I_003_R_S_001_J2K, 60, 2))
        sb.append(getIrisImgXml(I_004_L_S_001_J2K, 61, 2))
        return sb.toString()
    }

    public String getJpgFileImgXml() {
        StringBuilder sb = new StringBuilder()
        sb.append(getIrisImgXml(I_005_R_F_001_JPG, 60, 3))
        sb.append(getIrisImgXml(I_006_L_F_001_JPG, 61, 3))
        return sb.toString()
    }

    public String getJpgSearchImgXml() {
        StringBuilder sb = new StringBuilder()
        sb.append(getIrisImgXml(I_007_R_S_001_JPG, 60, 3))
        sb.append(getIrisImgXml(I_008_L_S_001_JPG, 61, 3))
        return sb.toString()
    }

    public String getBmpFileImgXml() {
        StringBuilder sb = new StringBuilder()
        sb.append(getIrisImgXml(I_009_R_F_001_BMP, 60, 4))
        sb.append(getIrisImgXml(I_010_L_F_001_BMP, 61, 4))
        return sb.toString()
    }

    public String getBmpSearchImgXml() {
        StringBuilder sb = new StringBuilder()
        sb.append(getIrisImgXml(I_011_R_S_001_BMP, 60, 4))
        sb.append(getIrisImgXml(I_012_L_S_001_BMP, 61, 4))
        return sb.toString()
    }

    public String getPngFileImgXml() {
        StringBuilder sb = new StringBuilder()
        sb.append(getIrisImgXml(I_013_R_F_001_PNG, 60, 5))
        sb.append(getIrisImgXml(I_014_L_F_001_PNG, 61, 5))
        return sb.toString()
    }

    public String getPngSearchImgXml() {
        StringBuilder sb = new StringBuilder()
        sb.append(getIrisImgXml(I_015_R_S_001_PNG, 60, 5))
        sb.append(getIrisImgXml(I_016_L_S_001_PNG, 61, 5))
        return sb.toString()
    }

    public String getWsqFileImgXml() {
        StringBuilder sb = new StringBuilder()
        sb.append(getIrisImgXml(I_017_R_F_001_WSQ, 60, 1))
        sb.append(getIrisImgXml(I_018_L_F_001_WSQ, 61, 1))
        return sb.toString()
    }

    public String getWsqSearchImgXml() {
        StringBuilder sb = new StringBuilder()
        sb.append(getIrisImgXml(I_019_R_S_001_WSQ, 60, 1))
        sb.append(getIrisImgXml(I_020_L_S_001_WSQ, 61, 1))
        return sb.toString()
    }

    public String getRawFileImgXml() {
        StringBuilder sb = new StringBuilder()
        sb.append(getIrisImgXml(I_021_R_F_001_RAW, 60, 0).replaceAll("><data>", " width='${IMG_WIDTH}' height='${IMG_HEIGHT}'><data>"))
        sb.append(getIrisImgXml(I_022_L_F_001_RAW, 61, 0).replaceAll("><data>", " width='${IMG_WIDTH}' height='${IMG_HEIGHT}'><data>"))
        return sb.toString()
    }

    public String getRawSearchImgXml() {
        StringBuilder sb = new StringBuilder()
        sb.append(getIrisImgXml(I_023_R_S_001_RAW, 60, 0).replaceAll("><data>", " width='${IMG_WIDTH}' height='${IMG_HEIGHT}'><data>"))
        sb.append(getIrisImgXml(I_024_L_S_001_RAW, 61, 0).replaceAll("><data>", " width='${IMG_WIDTH}' height='${IMG_HEIGHT}'><data>"))
        return sb.toString()
    }

    private void abendTest(String messg){
        abendProcessor.abendTest(messg)
    }

    private void initAssertionScore() {
        if(engine == NIRIS) {
            initNirisAssertionScore()
        }else if(engine == VERIEYE) {
            initVerieyeAssertionScore()
        }else{
            abendTest("Engine '${engine}' is unexpected value!!")
        }
		initAssertionFusionScore()
    }

    private void initNirisAssertionScore() {
        initNirisJ2kAssertionScore()
        initNirisJpgAssertionScore()
        initNirisBmpAssertionScore()
        initNirisPngAssertionScore()
        initNirisWsqAssertionScore()
        initNirisRawAssertionScore()
		initNirisMaxAssertionScore()
    }

    private void initVerieyeAssertionScore() {
        initVerieyeJ2kAssertionScore()
        initVerieyeJpgAssertionScore()
        initVerieyeBmpAssertionScore()
        initVerieyePngAssertionScore()
        initVerieyeWsqAssertionScore()
        initVerieyeRawAssertionScore()
		initVerieyeMaxAssertionScore()
    }
	
	private void initAssertionFusionScore() {
        j2kFScore = Math.max(j2kRRScore, j2kLLScore)
        jpgFScore = Math.max(jpgRRScore, jpgLLScore)
        bmpFScore = Math.max(bmpRRScore, bmpLLScore)
        pngFScore = Math.max(pngRRScore, pngLLScore)
        wsqFScore = Math.max(wsqRRScore, wsqLLScore)
        rawFScore = Math.max(rawRRScore, rawLLScore)
	}

    private void initNirisJ2kAssertionScore() {
        j2kRRScore = 3840
        j2kRRScoreSmode1 = 3724
        j2kRRScoreSmode3 = j2kRRScore
		j2kRRScoreNoDeInterlace = j2kRRScore
        j2kRLScore = ZERO_SCORE
        j2kLRScore = ZERO_SCORE
        j2kLLScore = 3763
        j2kLLScoreSmode1 = 3524
        j2kLLScoreSmode3 = j2kLLScore
		j2kLLScoreNoDeInterlace = j2kLLScore
        j2kIRScore = j2kRRScore
        j2kILScore = j2kLLScore
    }

    private void initVerieyeJ2kAssertionScore() {
        j2kRRScore = 7420
        j2kRRScoreSmode1 = 7300
        j2kRRScoreSmode3 = j2kRRScore
		j2kRRScoreNoDeInterlace = 7230
        j2kRLScore = ZERO_SCORE
        j2kLRScore = ZERO_SCORE
        j2kLLScore = 7430
        j2kLLScoreSmode1 = 7320
        j2kLLScoreSmode3 = j2kLLScore
		j2kLLScoreNoDeInterlace = 7410
        j2kIRScore = j2kRRScore
        j2kILScore = j2kLLScore
    }

    private void initNirisJpgAssertionScore() {
        jpgRRScore = 3773
        jpgRLScore = ZERO_SCORE
        jpgLRScore = ZERO_SCORE
        jpgLLScore = 3670
        jpgIRScore = jpgRRScore
        jpgILScore = jpgLLScore
    }

    private void initVerieyeJpgAssertionScore() {
        jpgRRScore = 7190
        jpgRLScore = ZERO_SCORE
        jpgLRScore = ZERO_SCORE
        jpgLLScore = 7250
        jpgIRScore = jpgRRScore
        jpgILScore = jpgLLScore
    }

    private void initNirisBmpAssertionScore() {
        bmpRRScore = 3840
        bmpRLScore = ZERO_SCORE
        bmpLRScore = ZERO_SCORE
        bmpLLScore = 3763
        bmpIRScore = bmpRRScore
        bmpILScore = bmpLLScore
    }

    private void initVerieyeBmpAssertionScore() {
        bmpRRScore = 7160
        bmpRLScore = ZERO_SCORE
        bmpLRScore = ZERO_SCORE
        bmpLLScore = 7430
        bmpIRScore = bmpRRScore
        bmpILScore = bmpLLScore
    }

    private void initNirisPngAssertionScore() {
        pngRRScore = 3867
        pngRLScore = ZERO_SCORE
        pngLRScore = ZERO_SCORE
        pngLLScore = 3760
        pngIRScore = pngRRScore
        pngILScore = pngLLScore
        pngRRScoreSmode1 = 3817
        pngRRScoreSmode3 = 3867
        pngLLScoreSmode1 = 3586
        pngLLScoreSmode3 = 3760
    }

    private void initVerieyePngAssertionScore() {
        pngRRScore = 7140
        pngRLScore = ZERO_SCORE
        pngLRScore = ZERO_SCORE
        pngLLScore = 7530
        pngIRScore = pngRRScore
        pngILScore = pngLLScore
        pngRRScoreSmode1 = 7030
        pngRRScoreSmode3 = 7140
        pngLLScoreSmode1 = 7410
        pngLLScoreSmode3 = 7530
    }

    private void initNirisWsqAssertionScore() {
        wsqRRScore = 3808
        wsqRLScore = ZERO_SCORE
        wsqLRScore = ZERO_SCORE
        wsqLLScore = 3695
        wsqIRScore = wsqRRScore
        wsqILScore = wsqLLScore
    }

    private void initVerieyeWsqAssertionScore() {
        wsqRRScore = 7290
        wsqRLScore = ZERO_SCORE
        wsqLRScore = ZERO_SCORE
        wsqLLScore = 7350
        wsqIRScore = wsqRRScore
        wsqILScore = wsqLLScore
    }

    private void initNirisRawAssertionScore() {
        rawRRScore = 3840
        rawRLScore = ZERO_SCORE
        rawLRScore = ZERO_SCORE
        rawLLScore = 3763
        rawIRScore = rawRRScore
        rawILScore = rawLLScore
    }

    private void initVerieyeRawAssertionScore() {
        rawRRScore = 7160
        rawRLScore = ZERO_SCORE
        rawLRScore = ZERO_SCORE
        rawLLScore = 7430
        rawIRScore = rawRRScore
        rawILScore = rawLLScore
    }

    private void initNirisMaxAssertionScore() {
        maxRRScore = 7171
        maxRLScore = ZERO_SCORE
        maxLRScore = ZERO_SCORE
        maxLLScore = 7101
        maxIRScore = maxRRScore
        maxILScore = maxLLScore
    }

    private void initVerieyeMaxAssertionScore() {
        maxRRScore = AIM_MAX_SCORE
        maxRLScore = ZERO_SCORE
        maxLRScore = ZERO_SCORE
        maxLLScore = AIM_MAX_SCORE
        maxIRScore = maxRRScore
        maxILScore = maxLLScore
    }

    public String getEngine() {
        return engine
    }
}

