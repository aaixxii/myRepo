package test.degrade.testitem.helper

import static test.common.constants.aim.AIMXmlAttribute.*

class TlisHelper extends ConsolidationHelper {

	private static final String DEF_EXT_ID = "default"
	private static final String OPTION_EXT_ID = "option"
	
	private static final String GEN_M_EXT_ID = "M"
	private static final String GEN_F_EXT_ID = "F"
	private static final String GEN_U_EXT_ID = "U"

	private static final String YOB_1_EXT_ID = "1979_-1"
	private static final String YOB_2_EXT_ID = "1979_0"
	private static final String YOB_3_EXT_ID = "1979_1"
	private static final String YOB_4_EXT_ID = "1979_5"
	private static final String YOB_5_EXT_ID = "1979_9"
	private static final String YOB_6_EXT_ID = "1973_0"
	private static final String YOB_7_EXT_ID = "1974_0"
	private static final String YOB_8_EXT_ID = "1984_0"
	private static final String YOB_9_EXT_ID = "1985_0"
	private static final String YOB_10_EXT_ID = "1974_5"
	private static final String YOB_11_EXT_ID = "1984_5"
	private static final String YOB_12_EXT_ID = "-1_0"

	private static final String PATTERN_EXT_ID = "pattern"
	private static final String PATTERN_A_EXT_ID = "A"
	private static final String PATTERN_W_EXT_ID = "W"
	private static final String PATTERN_L_EXT_ID = "L"
	private static final String PATTERN_R_EXT_ID = "R"
	private static final String PATTERN_S_EXT_ID = "S"
	private static final String PATTERN_AW_EXT_ID = "AW"
	private static final String PATTERN_AL_EXT_ID = "AL"
	private static final String PATTERN_AR_EXT_ID = "AR"
	private static final String PATTERN_WL_EXT_ID = "WL"
	private static final String PATTERN_WR_EXT_ID = "WR"
	private static final String PATTERN_LR_EXT_ID = "LR"
	private static final String PATTERN_LRA_EXT_ID = "LRA"
	private static final String PATTERN_AWR_EXT_ID = "AWR"
	private static final String PATTERN_WLR_EXT_ID = "WLR"
	private static final String PATTERN_AWL_EXT_ID = "AWL"
	private static final String PATTERN_AWLR_EXT_ID = "AWLR"
	private static final String PATTERN_A_P_WW_EXT_ID = "A_P_WW"

	private static final String FIN_NO_EXT_ID = "fingerNo"
	private static final String FIN_NO_0_EXT_ID = "0"
	private static final String FIN_NO_1_EXT_ID = "1"
	private static final String FIN_NO_2_EXT_ID = "2"
	private static final String FIN_NO_3_EXT_ID = "3"
	private static final String FIN_NO_4_EXT_ID = "4"
	private static final String FIN_NO_5_EXT_ID = "5"
	private static final String FIN_NO_6_EXT_ID = "6"
	private static final String FIN_NO_7_EXT_ID = "7"
	private static final String FIN_NO_8_EXT_ID = "8"
	private static final String FIN_NO_9_EXT_ID = "9"
	private static final String FIN_NO_012_EXT_ID = "012"
	private static final String FIN_NO_234_EXT_ID = "234"
	private static final String FIN_NO_456_EXT_ID = "456"
	private static final String FIN_NO_0_EXT_ID_1 = "F_1_0"
	private static final String FIN_NO_123456789_EXT_ID_1 = "F_1_123456789"
	private static final String FIN_NO_0123456789_EXT_ID_1 = "F_1_0123456789"
	private static final String FIN_NO_5_EXT_ID_2 = "F_2_5"
	private static final String FIN_NO_012346789_EXT_ID_2 = "F_2_012346789"
	private static final String FIN_NO_0123456789_EXT_ID_2 = "F_2_0123456789"
	
	private static final String ADJ_EXT_ID = "adjacentPattern"
	
	private static final String RACE_1_EXT_ID = "1"
	private static final String RACE_2_EXT_ID = "2"
	private static final String RACE_4_EXT_ID = "4"
	private static final String RACE_8_EXT_ID = "8"
	private static final String RACE_M1_EXT_ID = "-1"
	
	private static final String REGION_1_EXT_ID = "1"
	private static final String REGION_9_EXT_ID = "9"
	private static final String REGION_F_EXT_ID = "F"
	private static final String REGION_U_EXT_ID = "U"
	
	private static final String COLD_1_EXT_ID = "M_1960"
	private static final String COLD_2_EXT_ID = "M_1970"
	private static final String COLD_3_EXT_ID = "M_1980"
	private static final String COLD_4_EXT_ID = "F_1960"
	private static final String COLD_5_EXT_ID = "F_1970"
	private static final String COLD_6_EXT_ID = "F_1980"
	private static final String COLD_7_EXT_ID = "U_1960"
	private static final String COLD_8_EXT_ID = "U_1970"
	private static final String COLD_9_EXT_ID = "U_1980"
	
	private static final String SCOPE_1_EXT_ID = "1"
	private static final String SCOPE_2_EXT_ID = "2"
	private static final String SCOPE_3_EXT_ID = "3"
	
	private static final String EXT_ID_TEST_A_EXT_ID = "A"
	private static final String EXT_ID_TEST_B_EXT_ID = "B"
	private static final String EXT_ID_TEST_C_EXT_ID = "C"
	private static final String EXT_ID_TEST_D_EXT_ID = "D"
	private static final String EXT_ID_TEST_E_EXT_ID = "E"
	private static final String EXT_ID_TEST_F_EXT_ID = "F"
	
	private static final String MULTI_AXIS_1_EXT_ID = "Multi_1"
	private static final String MULTI_AXIS_2_EXT_ID = "Multi_2"
	
	private static final int R_FMP5_BASE_SCORE = 739
	private static final int S_FMP5_BASE_SCORE = 2016
	private static final int R_PC2_BASE_SCORE = 554
	private static final int S_PC2_BASE_SCORE = 1570
	private static final int FULL_SCORE = 9999
	private static final int S_PC2_ADJ_SCORE_1 = 9528
	private static final int S_FMP5_ADJ_SCORE_1 = 9114

	private static final int R_PC2_OPTION_SCORE_1 = 3918
	private static final int R_PC2_OPTION_SCORE_2 = 3803
	private static final int R_PC2_OPTION_SCORE_3 = 3867
	private static final int R_PC2_OPTION_SCORE_4 = 3380
	private static final int R_PC2_OPTION_SCORE_5 = 3415

	private static final int R_PC2_OPTION_SCORE_6 = 822
	private static final int R_PC2_OPTION_SCORE_7 = 758
	private static final int R_PC2_OPTION_SCORE_8 = 810

	private static final int R_PC2_OPTION_SCORE_9 = 3951

	private static final int S_PC2_OPTION_SCORE_1 = 6262
	private static final int S_PC2_OPTION_SCORE_2 = 6539
	private static final int S_PC2_OPTION_SCORE_3 = 6105
	private static final int S_PC2_OPTION_SCORE_4 = 6712
	private static final int S_PC2_OPTION_SCORE_5 = 6526
	private static final int S_PC2_OPTION_SCORE_6 = 7176

	private static final int S_PC2_OPTION_SCORE_7 = 1757
	private static final int S_PC2_OPTION_SCORE_8 = 1588

	private static final int ROTATION_BY_AXIS_SCORE_1 = 8158
	private static final int MULTI_AXIS_1_A_SCORE = 9999
	private static final int MULTI_AXIS_1_B_SCORE = 5180
	private static final int MULTI_AXIS_1_C_SCORE = 4231
	private static final int MULTI_AXIS_1_D_SCORE = 9999

	private static final int MULTI_AXIS_2_A_SCORE = 9999
	private static final int MULTI_AXIS_2_B_SCORE = 9999
	private static final int MULTI_AXIS_2_C_SCORE = 9999
	private static final int MULTI_AXIS_2_D_SCORE = 9999
	private static final int MULTI_AXIS_3_D_SCORE = 9435
	private static final int EXT_ID_SCORE_LOW = 4900
	private static final int DUST_SCORE_1 = 127
	
	private static final int SCOPE_1_BIN_ID = 326
	private static final int SCOPE_2_BIN_ID = SCOPE_1_BIN_ID + 1000
	private static final int SCOPE_3_BIN_ID = SCOPE_1_BIN_ID + 2000

	private int fmp5_pc2_score
	private int rfWScore
	private int sfWScore
	private int rfW120Score
	private int sfW120Score
	private int rfW90Score
	private int sfW90Score
	private Integer fW100 = 100
	private Integer fW120 = 120
	private Integer fmp5FW = 100
    private Integer pc2FW = 200
	private int reqIndex = 0
	
    private List R_DEF_CAND_INFO_LIST = []
    private List S_DEF_CAND_INFO_LIST = []
    private List S_DEF_INQ_R_CAND_INFO_LIST = []
    private List RS_DEF_CAND_INFO_LIST = []
    private List DEF_FMP5_CAND_INFO_LIST = []
    private List DEF_RS_MULTI_SCOPE_CAND_INFO_LIST = []

	private List LE_OPTION_CAND_INFO_LIST_1 = []
	private List LE_OPTION_CAND_INFO_LIST_2 = []
	private List LE_OPTION_CAND_INFO_LIST_3 = []
	private List LE_OPTION_CAND_INFO_LIST_4 = []
	private List PC2_OPTION_CAND_INFO_LIST_1 = []
	private List PC2_OPTION_CAND_INFO_LIST_2 = []
	private List PC2_OPTION_CAND_INFO_LIST_3 = []
	private List PC2_OPTION_CAND_INFO_LIST_4 = []
	private List PC2_OPTION_CAND_INFO_LIST_5 = []
	private List PC2_OPTION_CAND_INFO_LIST_6 = []
	private List PC2_OPTION_CAND_INFO_LIST_7 = []
	private List PC2_OPTION_CAND_INFO_LIST_8 = []
	
	private List ROTATION_BY_AXIS_CAND_INFO_LIST = []
	
	private List R_GEN_M_CAND_INFO_LIST = []
	private List R_GEN_F_CAND_INFO_LIST = []
	private List R_GEN_U_CAND_INFO_LIST = []
	private List S_GEN_M_CAND_INFO_LIST = []
	private List S_GEN_F_CAND_INFO_LIST = []
	private List S_GEN_U_CAND_INFO_LIST = []

	private List YOB_1_CAND_INFO_LIST = []
	private List YOB_2_CAND_INFO_LIST = []
	private List YOB_3_CAND_INFO_LIST = []
	private List YOB_4_CAND_INFO_LIST = []
	private List YOB_5_CAND_INFO_LIST = []
	private List YOB_6_CAND_INFO_LIST = []
	private List YOB_7_CAND_INFO_LIST = []
	private List YOB_8_CAND_INFO_LIST = []
	private List YOB_9_CAND_INFO_LIST = []
	private List YOB_10_CAND_INFO_LIST = []
	private List YOB_11_CAND_INFO_LIST = []
	private List YOB_12_CAND_INFO_LIST = []
	
	private List PATTERN_CAND_INFO_LIST = []
	private List R_PATTERN_CAND_INFO_LIST = []
	private List PATTERN_A_CAND_INFO_LIST = []
	private List PATTERN_W_CAND_INFO_LIST = []
	private List PATTERN_L_CAND_INFO_LIST = []
	private List PATTERN_R_CAND_INFO_LIST = []
	private List PATTERN_S_CAND_INFO_LIST = []
	private List PATTERN_AW_CAND_INFO_LIST = []
	private List PATTERN_AL_CAND_INFO_LIST = []
	private List PATTERN_AR_CAND_INFO_LIST = []
	private List PATTERN_WL_CAND_INFO_LIST = []
	private List PATTERN_WR_CAND_INFO_LIST = []
	private List PATTERN_LR_CAND_INFO_LIST = []
	private List PATTERN_LRA_CAND_INFO_LIST = []
	private List PATTERN_AWR_CAND_INFO_LIST = []
	private List PATTERN_WLR_CAND_INFO_LIST = []
	private List PATTERN_AWL_CAND_INFO_LIST = []
	private List PATTERN_AWLR_CAND_INFO_LIST = []
	private List PATTERN_A_P_WW_CAND_INFO_LIST =  []
	
	private List FIN_NO_0_CAND_INFO_LIST = []
	private List FIN_NO_1_CAND_INFO_LIST = []
	private List FIN_NO_2_CAND_INFO_LIST = []
	private List FIN_NO_3_CAND_INFO_LIST = []
	private List FIN_NO_4_CAND_INFO_LIST = []
	private List FIN_NO_5_CAND_INFO_LIST = []
	private List FIN_NO_6_CAND_INFO_LIST = []
	private List FIN_NO_7_CAND_INFO_LIST = []
	private List FIN_NO_8_CAND_INFO_LIST = []
	private List FIN_NO_9_CAND_INFO_LIST = []
	private List FIN_NO_012_CAND_INFO_LIST = []
	private List FIN_NO_234_CAND_INFO_LIST = []
	private List FIN_NO_456_CAND_INFO_LIST = []
	private List R_FIN_NO_0_CAND_INFO_LIST_1 = []
	private List R_FIN_NO_123456789_CAND_INFO_LIST_1 = []
	private List R_FIN_NO_0123456789_CAND_INFO_LIST_1 = []
	private List R_FIN_NO_5_CAND_INFO_LIST_2 = []
	private List R_FIN_NO_012346789_CAND_INFO_LIST_2 = []
	private List R_FIN_NO_0123456789_CAND_INFO_LIST_2 = []
	private List S_FIN_NO_0_CAND_INFO_LIST_1 = []
	private List S_FIN_NO_123456789_CAND_INFO_LIST_1 = []
	private List S_FIN_NO_0123456789_CAND_INFO_LIST_1 = []
	private List S_FIN_NO_5_CAND_INFO_LIST_2 = []
	private List S_FIN_NO_012346789_CAND_INFO_LIST_2 = []
	private List S_FIN_NO_0123456789_CAND_INFO_LIST_2 = []
	private List S_FIN_NO_0_INQ_R_CAND_INFO_LIST_1 = []
	private List S_FIN_NO_123456789_INQ_R_CAND_INFO_LIST_1 = []
	private List S_FIN_NO_0123456789_INQ_R_CAND_INFO_LIST_1 = []
	private List S_FIN_NO_5_INQ_R_CAND_INFO_LIST_2 = []
	private List S_FIN_NO_012346789_INQ_R_CAND_INFO_LIST_2 = []
	private List S_FIN_NO_0123456789_INQ_R_CAND_INFO_LIST_2 = []

	private List FIN_NO_0_CAND_INFO_LIST_3 = []
	private List FIN_NO_123456789_CAND_INFO_LIST_3 = []
	private List FIN_NO_0123456789_CAND_INFO_LIST_3 = []
	private List FIN_NO_5_CAND_INFO_LIST_4 = []
	private List FIN_NO_012346789_CAND_INFO_LIST_4 = []
	private List FIN_NO_0123456789_CAND_INFO_LIST_4 = []
	
	private List LOSS_FIN_NO_0_CAND_INFO_LIST = []
	private List LOSS_FIN_NO_1_CAND_INFO_LIST = []
	private List LOSS_FIN_NO_2_CAND_INFO_LIST = []
	private List LOSS_FIN_NO_3_CAND_INFO_LIST = []
	private List LOSS_FIN_NO_4_CAND_INFO_LIST = []
	private List LOSS_FIN_NO_5_CAND_INFO_LIST = []
	private List LOSS_FIN_NO_6_CAND_INFO_LIST = []
	private List LOSS_FIN_NO_7_CAND_INFO_LIST = []
	private List LOSS_FIN_NO_8_CAND_INFO_LIST = []
	private List LOSS_FIN_NO_9_CAND_INFO_LIST = []

	private List ADJ_1_CAND_INFO_LIST = []
	private List ADJ_2_CAND_INFO_LIST = []
	private List ADJ_3_CAND_INFO_LIST = []
	
	private List RACE_1_CAND_INFO_LIST = []
	private List RACE_2_CAND_INFO_LIST = []
	private List RACE_4_CAND_INFO_LIST = []
	private List RACE_8_CAND_INFO_LIST = []
	private List RACE_M1_CAND_INFO_LIST = []
	
	private List REGION_1_CAND_INFO_LIST = []
	private List REGION_9_CAND_INFO_LIST = []
	private List REGION_F_CAND_INFO_LIST = []
	private List REGION_U_CAND_INFO_LIST = []
	
	private List COLD_1_CAND_INFO_LIST = []
	private List COLD_2_CAND_INFO_LIST = []
	private List COLD_3_CAND_INFO_LIST = []
	private List COLD_4_CAND_INFO_LIST = []
	private List COLD_5_CAND_INFO_LIST = []
	private List COLD_6_CAND_INFO_LIST = []
	private List COLD_7_CAND_INFO_LIST = []
	private List COLD_8_CAND_INFO_LIST = []
	private List COLD_9_CAND_INFO_LIST = []
	
	private List R_SCOPE_1_CAND_INFO_LIST = []
	private List R_SCOPE_2_CAND_INFO_LIST = []
	private List R_SCOPE_3_CAND_INFO_LIST = []

	private List S_SCOPE_1_CAND_INFO_LIST = []
	private List S_SCOPE_2_CAND_INFO_LIST = []
	private List S_SCOPE_3_CAND_INFO_LIST = []
	private List S_SCOPE_1_INQ_R_CAND_INFO_LIST = []
	private List S_SCOPE_2_INQ_R_CAND_INFO_LIST = []
	private List S_SCOPE_3_INQ_R_CAND_INFO_LIST = []

	private List RS_SCOPE_1_CAND_INFO_LIST = []
	private List RS_SCOPE_2_CAND_INFO_LIST = []
	private List RS_SCOPE_3_CAND_INFO_LIST = []
	
	private List FW_NULL_CAND_INFO_LIST = []
	private List FW_NULL_LOW_API_CAND_INFO_LIST = []
	private List FW_100_CAND_INFO_LIST = []
	private List FW_90_CAND_INFO_LIST = []
	private List FW_120_CAND_INFO_LIST = []
	private List FW_R120S100_CAND_INFO_LIST = []
	private List FW_R100S120_CAND_INFO_LIST = []
	
	private List DYN_CAND_INFO_LIST = []

	private List EXT_ID_TEST_A_CAND_INFO_LIST = []
	private List EXT_ID_TEST_B_CAND_INFO_LIST = []
	private List EXT_ID_TEST_C_CAND_INFO_LIST = []
	private List EXT_ID_TEST_D_CAND_INFO_LIST = []
	private List EXT_ID_TEST_E_CAND_INFO_LIST = []
	private List EXT_ID_TEST_F_CAND_INFO_LIST = []
	
	private List MULTI_AXIS_1_A_CAND_INFO_LIST = []
	private List MULTI_AXIS_1_B_CAND_INFO_LIST = []
	private List MULTI_AXIS_1_C_CAND_INFO_LIST_1 = []
	private List MULTI_AXIS_1_C_CAND_INFO_LIST_2 = []
	private List MULTI_AXIS_1_D_CAND_INFO_LIST = []
	private List MULTI_AXIS_2_A_CAND_INFO_LIST = []
	private List MULTI_AXIS_2_B_CAND_INFO_LIST = []
	private List MULTI_AXIS_2_C_CAND_INFO_LIST = []
	private List MULTI_AXIS_2_D_CAND_INFO_LIST = []
	private List MULTI_AXIS_3_D_CAND_INFO_LIST = []
	
	TlisHelper(context){
		super(context)
		initCandInfoLists()
	}

	TlisHelper(context, String level){
		super(context)
	//	//setNullFwIfHighLevel(level)
		initCandInfoLists()
	}

	private void initCandInfoLists() {
		initScores()
		initDefaultCandInfoList()
		initGenderCandInfoList()
		initYobCandInfoList()
		initPatternCandInfoList()
		initFingerNoCandInfoList()
		initAdjacentCandInfoList()
		initRaceCandInfoList()
		initRegionCandInfoList()
		initColdCandInfoList()
		initScopeCandInfoList()
		initFusionWeightCandInfoList()
		initExternalIdCandInfoList()
		initMultiAxisCandInfoList()
		initLeOptionCandInfoList()
		initPc2OptionCandInfoList()
		initRotationByAxisCandInfoList()
		initDynCandInfoList()
		initLossFinCandInfoList()
	}

	private void initScores() {
		rfWScore = mergeFWeight(R_PC2_BASE_SCORE, pc2FW)
		sfWScore = mergeFWeight(S_PC2_BASE_SCORE, pc2FW)
		rfW120Score = mergeFWeight(R_PC2_BASE_SCORE, 120)
		sfW120Score = mergeFWeight(S_PC2_BASE_SCORE, 120)
		rfW90Score = mergeFWeight(R_PC2_BASE_SCORE, 90)
		sfW90Score = mergeFWeight(S_PC2_BASE_SCORE, 90)
	}

	private void initDefaultCandInfoList(){
        		R_DEF_CAND_INFO_LIST =
            		[ DEF_EXT_ID, rfWScore, true,
						[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
							[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ], 
						] ]
					]

				S_DEF_CAND_INFO_LIST =
					[ DEF_EXT_ID, sfWScore, true,
						[ [ SCOPE_1_BIN_ID, 1, reqIndex, sfWScore,
							[ [ S_PC2_BASE_SCORE, FIN_1, A, PC2_SLAP , pc2FW ] ] 
						] ]
					]

				S_DEF_INQ_R_CAND_INFO_LIST =
					[ DEF_EXT_ID, sfWScore, true,
						[ [ SCOPE_1_BIN_ID, 1, reqIndex, sfWScore,
							[ [ S_PC2_BASE_SCORE, FIN_1, A, PC2_ROLLED , pc2FW ] ] 
						] ]
					]

				RS_DEF_CAND_INFO_LIST =
					[ DEF_EXT_ID, rfWScore + sfWScore, true,
						[ [ SCOPE_1_BIN_ID, 1, 0, rfWScore,
							[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ],
						] ],
						 [ SCOPE_1_BIN_ID, 1, 1, sfWScore,
							[ [ S_PC2_BASE_SCORE, FIN_1, A , PC2_SLAP, pc2FW ], 
						] ] ],
					]

				DEF_RS_MULTI_SCOPE_CAND_INFO_LIST =
					[ DEF_EXT_ID, rfWScore + sfWScore, true,
						[ [ SCOPE_1_BIN_ID, 1, 0, rfWScore,
							[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ],
						] ],
						 [ SCOPE_1_BIN_ID, 1, 1, sfWScore,
							[ [ S_PC2_BASE_SCORE, FIN_1, A , PC2_SLAP, pc2FW ], 
						] ],
						 [ SCOPE_2_BIN_ID, 1, 0, rfWScore,
							[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ],
						] ],
						 [ SCOPE_2_BIN_ID, 1, 1, sfWScore,
							[ [ S_PC2_BASE_SCORE, FIN_1, A , PC2_SLAP, pc2FW ], 
						] ] ],
					]

			}

	private void initLeOptionCandInfoList(){}

	private void initPc2OptionCandInfoList(){

		PC2_OPTION_CAND_INFO_LIST_1 =
            [ DEF_EXT_ID, calcFusionScore_fmp5_pc2(R_PC2_OPTION_SCORE_1, rfWScore, S_PC2_OPTION_SCORE_1, sfWScore), true,
				[ [ SCOPE_1_BIN_ID, 1, 0, mergeFWeight(R_PC2_OPTION_SCORE_1, pc2FW),
					[ [ R_PC2_OPTION_SCORE_1, FIN_1, A , PC2_ROLLED, pc2FW ], 
				] ],
				[ SCOPE_1_BIN_ID, 1, 1, mergeFWeight(S_PC2_OPTION_SCORE_1, pc2FW),
					[  [ S_PC2_OPTION_SCORE_1, FIN_1, A , PC2_SLAP, pc2FW ], 
				] ] ]
			]

		PC2_OPTION_CAND_INFO_LIST_2 =
            [ DEF_EXT_ID, calcFusionScore_fmp5_pc2(R_PC2_OPTION_SCORE_1, rfWScore, S_PC2_OPTION_SCORE_3, sfWScore), true,
				[ [ SCOPE_1_BIN_ID, 1, 0, mergeFWeight(R_PC2_OPTION_SCORE_1, pc2FW),
					[ [ R_PC2_OPTION_SCORE_1, FIN_1, A , PC2_ROLLED, pc2FW ], 
				] ],
				[ SCOPE_1_BIN_ID, 1, 1, mergeFWeight(S_PC2_OPTION_SCORE_3, pc2FW),
					[  [ S_PC2_OPTION_SCORE_3, FIN_1, A , PC2_SLAP, pc2FW ], 
				] ] ]
			]

		PC2_OPTION_CAND_INFO_LIST_3 =
            [ DEF_EXT_ID, calcFusionScore_fmp5_pc2(R_PC2_OPTION_SCORE_2, rfWScore, S_PC2_OPTION_SCORE_2, sfWScore), true,
				[ [ SCOPE_1_BIN_ID, 1, 0, mergeFWeight(R_PC2_OPTION_SCORE_2, pc2FW),
					[ [ R_PC2_OPTION_SCORE_2, FIN_1, A , PC2_ROLLED, pc2FW ], 
				] ],
				[ SCOPE_1_BIN_ID, 1, 1, mergeFWeight(S_PC2_OPTION_SCORE_2, pc2FW),
					[  [ S_PC2_OPTION_SCORE_2, FIN_1, A , PC2_SLAP, pc2FW ], 
				] ] ]
			]

		PC2_OPTION_CAND_INFO_LIST_4 =
            [ DEF_EXT_ID, calcFusionScore_fmp5_pc2(R_PC2_OPTION_SCORE_3, rfWScore, S_PC2_OPTION_SCORE_4, sfWScore), true,
				[ [ SCOPE_1_BIN_ID, 1, 0, mergeFWeight(R_PC2_OPTION_SCORE_3, pc2FW),
					[ [ R_PC2_OPTION_SCORE_3, FIN_1, A , PC2_ROLLED, pc2FW ], 
				] ],
				[ SCOPE_1_BIN_ID, 1, 1, mergeFWeight(S_PC2_OPTION_SCORE_4, pc2FW),
					[  [ S_PC2_OPTION_SCORE_4, FIN_1, A , PC2_SLAP, pc2FW ], 
				] ] ]
			]

		PC2_OPTION_CAND_INFO_LIST_5 =
            [ DEF_EXT_ID, calcFusionScore_fmp5_pc2(R_PC2_OPTION_SCORE_9, rfWScore, S_PC2_OPTION_SCORE_5, sfWScore), true,
				[ [ SCOPE_1_BIN_ID, 1, 0, mergeFWeight(R_PC2_OPTION_SCORE_9, pc2FW),
					[ [ R_PC2_OPTION_SCORE_9, FIN_1, A , PC2_ROLLED, pc2FW ], 
				] ],
				[ SCOPE_1_BIN_ID, 1, 1, mergeFWeight(S_PC2_OPTION_SCORE_5, pc2FW),
					[  [ S_PC2_OPTION_SCORE_5, FIN_1, A , PC2_SLAP, pc2FW ], 
				] ] ]
			]

		PC2_OPTION_CAND_INFO_LIST_6 =
            [ DEF_EXT_ID, calcFusionScore_fmp5_pc2(R_PC2_OPTION_SCORE_4, rfWScore, S_PC2_OPTION_SCORE_6, sfWScore), true,
				[ [ SCOPE_1_BIN_ID, 1, 0, mergeFWeight(R_PC2_OPTION_SCORE_4, pc2FW),
					[ [ R_PC2_OPTION_SCORE_4, FIN_1, A , PC2_ROLLED, pc2FW ], 
				] ],
				[ SCOPE_1_BIN_ID, 1, 1, mergeFWeight(S_PC2_OPTION_SCORE_6, pc2FW),
					[  [ S_PC2_OPTION_SCORE_6, FIN_1, A , PC2_SLAP, pc2FW ], 
				] ] ]
			]

		PC2_OPTION_CAND_INFO_LIST_7 =
            [ DEF_EXT_ID, calcFusionScore_fmp5_pc2(R_PC2_OPTION_SCORE_5, rfWScore, S_PC2_OPTION_SCORE_1, sfWScore), true,
				[ [ SCOPE_1_BIN_ID, 1, 0, mergeFWeight(R_PC2_OPTION_SCORE_5, pc2FW),
					[ [ R_PC2_OPTION_SCORE_5, FIN_1, A , PC2_ROLLED, pc2FW ], 
				] ],
				[ SCOPE_1_BIN_ID, 1, 1, mergeFWeight(S_PC2_OPTION_SCORE_1, pc2FW),
					[  [ S_PC2_OPTION_SCORE_1, FIN_1, A , PC2_SLAP, pc2FW ], 
				] ] ]
			]

	}

	private void initRotationByAxisCandInfoList(){
		ROTATION_BY_AXIS_CAND_INFO_LIST =
            		[ DEF_EXT_ID, mergeFWeight(ROTATION_BY_AXIS_SCORE_1, pc2FW), true,
						[ [ SCOPE_1_BIN_ID, 1, reqIndex, mergeFWeight(ROTATION_BY_AXIS_SCORE_1, pc2FW),
							[ [ ROTATION_BY_AXIS_SCORE_1, FIN_1, A , PC2_ROLLED, pc2FW ] ], 
						] ]
					]
		
	}
		
	private void initGenderCandInfoList(){
		R_GEN_M_CAND_INFO_LIST =
			[ GEN_M_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ]
				] ]
			]
		
		R_GEN_F_CAND_INFO_LIST =
			[ GEN_F_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]

		R_GEN_U_CAND_INFO_LIST =
			[ GEN_U_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]

		S_GEN_M_CAND_INFO_LIST =
			[ GEN_M_EXT_ID, sfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, sfWScore,
					[ [ S_PC2_BASE_SCORE, FIN_1, A , PC2_SLAP, pc2FW ] ]
				] ]
			]
		
		S_GEN_F_CAND_INFO_LIST =
			[ GEN_F_EXT_ID, sfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, sfWScore,
					[ [ S_PC2_BASE_SCORE, FIN_1, A , PC2_SLAP, pc2FW ] ] 
				] ]
			]

		S_GEN_U_CAND_INFO_LIST =
			[ GEN_U_EXT_ID, sfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, sfWScore,
					[ [ S_PC2_BASE_SCORE, FIN_1, A , PC2_SLAP, pc2FW ] ] 
				] ]
			]

	}

	private void initYobCandInfoList(){
		YOB_1_CAND_INFO_LIST =
			[ YOB_1_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		YOB_2_CAND_INFO_LIST =
			[ YOB_2_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		YOB_3_CAND_INFO_LIST =
			[ YOB_3_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		YOB_4_CAND_INFO_LIST =
			[ YOB_4_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		YOB_5_CAND_INFO_LIST =
			[ YOB_5_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		YOB_6_CAND_INFO_LIST =
			[ YOB_6_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		YOB_7_CAND_INFO_LIST =
			[ YOB_7_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		YOB_8_CAND_INFO_LIST =
			[ YOB_8_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		YOB_9_CAND_INFO_LIST =
			[ YOB_9_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		YOB_10_CAND_INFO_LIST =
			[ YOB_10_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		YOB_11_CAND_INFO_LIST =
			[ YOB_11_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		YOB_12_CAND_INFO_LIST =
			[ YOB_12_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	}
	
	private void initPatternCandInfoList(){
		PATTERN_CAND_INFO_LIST =
			[ PATTERN_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_3, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]

		R_PATTERN_CAND_INFO_LIST =
			[ PATTERN_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_3, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]

		PATTERN_A_CAND_INFO_LIST =
			[ PATTERN_A_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_3, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		PATTERN_W_CAND_INFO_LIST =
			[ PATTERN_W_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_3, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		PATTERN_L_CAND_INFO_LIST =
			[ PATTERN_L_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_3, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		PATTERN_R_CAND_INFO_LIST =
			[ PATTERN_R_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_3, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]

		PATTERN_S_CAND_INFO_LIST =
			[ PATTERN_S_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_3, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		PATTERN_AW_CAND_INFO_LIST =
			[ PATTERN_AW_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_3, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		PATTERN_AL_CAND_INFO_LIST =
			[ PATTERN_AL_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_3, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		PATTERN_AR_CAND_INFO_LIST =
			[ PATTERN_AR_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_3, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		PATTERN_WL_CAND_INFO_LIST =
			[ PATTERN_WL_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_3, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]

		PATTERN_WR_CAND_INFO_LIST =
			[ PATTERN_WR_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_3, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]

		PATTERN_LR_CAND_INFO_LIST =
			[ PATTERN_LR_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_3, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		PATTERN_LRA_CAND_INFO_LIST =
			[ PATTERN_LRA_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_3, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		PATTERN_AWR_CAND_INFO_LIST =
			[ PATTERN_AWR_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_3, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		PATTERN_WLR_CAND_INFO_LIST =
			[ PATTERN_WLR_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_3, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		PATTERN_AWL_CAND_INFO_LIST =
			[ PATTERN_AWL_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_3, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
		
		PATTERN_AWLR_CAND_INFO_LIST =
			[ PATTERN_AWLR_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_3, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]

		PATTERN_A_P_WW_CAND_INFO_LIST =
			[ PATTERN_A_P_WW_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_6, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	}

	private void initFingerNoCandInfoList(){
		FIN_NO_0_CAND_INFO_LIST =
			[ FIN_NO_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		FIN_NO_1_CAND_INFO_LIST =
			[ FIN_NO_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ R_PC2_BASE_SCORE, FIN_2, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		FIN_NO_2_CAND_INFO_LIST =
			[ FIN_NO_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ R_PC2_BASE_SCORE, FIN_3, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		FIN_NO_3_CAND_INFO_LIST =
			[ FIN_NO_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ R_PC2_BASE_SCORE, FIN_4, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]

		FIN_NO_4_CAND_INFO_LIST =
			[ FIN_NO_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ R_PC2_BASE_SCORE, FIN_5, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		FIN_NO_5_CAND_INFO_LIST =
			[ FIN_NO_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ R_PC2_BASE_SCORE, FIN_6, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		FIN_NO_6_CAND_INFO_LIST =
			[ FIN_NO_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ R_PC2_BASE_SCORE, FIN_7, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		FIN_NO_7_CAND_INFO_LIST =
			[ FIN_NO_EXT_ID, FULL_SCORE , true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ R_PC2_BASE_SCORE, FIN_8, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		FIN_NO_8_CAND_INFO_LIST =
			[ FIN_NO_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ R_PC2_BASE_SCORE, FIN_9, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]

		FIN_NO_9_CAND_INFO_LIST =
			[ FIN_NO_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ R_PC2_BASE_SCORE, FIN_10, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		R_FIN_NO_0_CAND_INFO_LIST_1 =
			[ FIN_NO_0_EXT_ID_1, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		R_FIN_NO_123456789_CAND_INFO_LIST_1 =
			[ FIN_NO_123456789_EXT_ID_1, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		R_FIN_NO_0123456789_CAND_INFO_LIST_1 =
			[ FIN_NO_0123456789_EXT_ID_1, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		R_FIN_NO_5_CAND_INFO_LIST_2 =
			[ FIN_NO_5_EXT_ID_2, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_6, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		R_FIN_NO_012346789_CAND_INFO_LIST_2 =
			[ FIN_NO_012346789_EXT_ID_2, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_6, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		R_FIN_NO_0123456789_CAND_INFO_LIST_2 =
			[ FIN_NO_0123456789_EXT_ID_2, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_6, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]

		S_FIN_NO_0_CAND_INFO_LIST_1 =
			[ FIN_NO_0_EXT_ID_1, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_1, A , PC2_SLAP, pc2FW ] ] 
				] ]
			]
	
		S_FIN_NO_0_INQ_R_CAND_INFO_LIST_1 =
			[ FIN_NO_0_EXT_ID_1, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		S_FIN_NO_123456789_CAND_INFO_LIST_1 =
			[ FIN_NO_123456789_EXT_ID_1, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_1, A , PC2_SLAP, pc2FW ] ] 
				] ]
			]
	
		S_FIN_NO_123456789_INQ_R_CAND_INFO_LIST_1 =
			[ FIN_NO_123456789_EXT_ID_1, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		S_FIN_NO_0123456789_CAND_INFO_LIST_1 =
			[ FIN_NO_0123456789_EXT_ID_1, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_1, A , PC2_SLAP, pc2FW ] ] 
				] ]
			]
	
		S_FIN_NO_0123456789_INQ_R_CAND_INFO_LIST_1 =
			[ FIN_NO_0123456789_EXT_ID_1, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		S_FIN_NO_5_CAND_INFO_LIST_2 =
			[ FIN_NO_5_EXT_ID_2, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_6, A , PC2_SLAP, pc2FW ] ] 
				] ]
			]
	
		S_FIN_NO_5_INQ_R_CAND_INFO_LIST_2 =
			[ FIN_NO_5_EXT_ID_2, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_6, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		S_FIN_NO_012346789_CAND_INFO_LIST_2 =
			[ FIN_NO_012346789_EXT_ID_2, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_6, A , PC2_SLAP, pc2FW ] ] 
				] ]
			]
	
		S_FIN_NO_012346789_INQ_R_CAND_INFO_LIST_2 =
			[ FIN_NO_012346789_EXT_ID_2, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_6, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		S_FIN_NO_0123456789_CAND_INFO_LIST_2 =
			[ FIN_NO_0123456789_EXT_ID_2, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_6, A , PC2_SLAP, pc2FW ] ] 
				] ]
			]

		S_FIN_NO_0123456789_INQ_R_CAND_INFO_LIST_2 =
			[ FIN_NO_0123456789_EXT_ID_2, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_6, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]

	}

	private void initLossFinCandInfoList(){
		LOSS_FIN_NO_0_CAND_INFO_LIST =
			[ FIN_NO_0_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		LOSS_FIN_NO_1_CAND_INFO_LIST =
			[ FIN_NO_1_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_2, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		LOSS_FIN_NO_2_CAND_INFO_LIST =
			[ FIN_NO_2_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_3, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		LOSS_FIN_NO_3_CAND_INFO_LIST =
			[ FIN_NO_3_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_4, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]

		LOSS_FIN_NO_4_CAND_INFO_LIST =
			[ FIN_NO_4_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_5, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		LOSS_FIN_NO_5_CAND_INFO_LIST =
			[ FIN_NO_5_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_6, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		LOSS_FIN_NO_6_CAND_INFO_LIST =
			[ FIN_NO_6_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_7, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		LOSS_FIN_NO_7_CAND_INFO_LIST =
			[ FIN_NO_7_EXT_ID, FULL_SCORE , true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_8, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		LOSS_FIN_NO_8_CAND_INFO_LIST =
			[ FIN_NO_8_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_9, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]

		LOSS_FIN_NO_9_CAND_INFO_LIST =
			[ FIN_NO_9_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_10, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
	}

	private void initAdjacentCandInfoList(){
		ADJ_1_CAND_INFO_LIST =
			[ ADJ_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		ADJ_2_CAND_INFO_LIST =
			[ ADJ_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		ADJ_3_CAND_INFO_LIST =
			[ ADJ_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	}	

	private void initRaceCandInfoList(){
		RACE_1_CAND_INFO_LIST =
			[ RACE_1_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		RACE_2_CAND_INFO_LIST =
			[ RACE_2_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		RACE_4_CAND_INFO_LIST =
			[ RACE_4_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
		
		RACE_8_CAND_INFO_LIST =
			[ RACE_8_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]

		RACE_M1_CAND_INFO_LIST =
			[ RACE_M1_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	}
	
	private void initRegionCandInfoList(){
		REGION_1_CAND_INFO_LIST =
			[ REGION_1_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		REGION_9_CAND_INFO_LIST =
			[ REGION_9_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		REGION_F_CAND_INFO_LIST =
			[ REGION_F_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
		
		REGION_U_CAND_INFO_LIST =
			[ REGION_U_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	}
	
	private void initColdCandInfoList(){
		COLD_1_CAND_INFO_LIST =
			[ COLD_1_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		COLD_2_CAND_INFO_LIST =
			[ COLD_2_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		COLD_3_CAND_INFO_LIST =
			[ COLD_3_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
		
		COLD_4_CAND_INFO_LIST =
			[ COLD_4_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
		
		COLD_5_CAND_INFO_LIST =
			[ COLD_5_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]

		COLD_6_CAND_INFO_LIST =
			[ COLD_6_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]

		COLD_7_CAND_INFO_LIST =
			[ COLD_7_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]

		COLD_8_CAND_INFO_LIST =
			[ COLD_8_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]

		COLD_9_CAND_INFO_LIST =
			[ COLD_9_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]

	}

	private void initScopeCandInfoList(){
		R_SCOPE_1_CAND_INFO_LIST =
			[ SCOPE_1_EXT_ID, rfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		S_SCOPE_1_CAND_INFO_LIST =
			[ SCOPE_1_EXT_ID, sfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, sfWScore,
					[ [ S_PC2_BASE_SCORE, FIN_1, A , PC2_SLAP, pc2FW ] ] 
				] ]
			]

		S_SCOPE_1_INQ_R_CAND_INFO_LIST =
			[ SCOPE_1_EXT_ID, sfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, sfWScore,
					[ [ S_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]

		RS_SCOPE_1_CAND_INFO_LIST =
            [ SCOPE_1_EXT_ID, rfWScore + sfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, 0, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ],
				] ],
				 [ SCOPE_1_BIN_ID, 1, 1, sfWScore,
					[ [ S_PC2_BASE_SCORE, FIN_1, A , PC2_SLAP, pc2FW ], 
				] ] ],
            ]

		R_SCOPE_2_CAND_INFO_LIST =
			[ SCOPE_2_EXT_ID, rfWScore, true,
				[ [ SCOPE_2_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		S_SCOPE_2_CAND_INFO_LIST =
			[ SCOPE_2_EXT_ID, sfWScore, true,
				[ [ SCOPE_2_BIN_ID, 1, reqIndex, sfWScore,
					[ [ S_PC2_BASE_SCORE, FIN_1, A , PC2_SLAP, pc2FW ] ] 
				] ]
			]

		S_SCOPE_2_INQ_R_CAND_INFO_LIST =
			[ SCOPE_2_EXT_ID, sfWScore, true,
				[ [ SCOPE_2_BIN_ID, 1, reqIndex, sfWScore,
					[ [ S_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]

		RS_SCOPE_2_CAND_INFO_LIST =
            [ SCOPE_2_EXT_ID, rfWScore + sfWScore, true,
				[ [ SCOPE_2_BIN_ID, 1, 0, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ],
				] ],
				 [ SCOPE_2_BIN_ID, 1, 1, sfWScore,
					[ [ S_PC2_BASE_SCORE, FIN_1, A , PC2_SLAP, pc2FW ], 
				] ] ],
            ]

		R_SCOPE_3_CAND_INFO_LIST =
			[ SCOPE_3_EXT_ID, rfWScore, true,
				[ [ SCOPE_3_BIN_ID, 1, reqIndex, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]
	
		S_SCOPE_3_CAND_INFO_LIST =
			[ SCOPE_3_EXT_ID, sfWScore, true,
				[ [ SCOPE_3_BIN_ID, 1, reqIndex, sfWScore,
					[ [ S_PC2_BASE_SCORE, FIN_1, A , PC2_SLAP, pc2FW ] ] 
				] ]
			]

		S_SCOPE_3_INQ_R_CAND_INFO_LIST =
			[ SCOPE_3_EXT_ID, sfWScore, true,
				[ [ SCOPE_3_BIN_ID, 1, reqIndex, sfWScore,
					[ [ S_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] 
				] ]
			]

		RS_SCOPE_3_CAND_INFO_LIST =
            [ SCOPE_3_EXT_ID, rfWScore + sfWScore, true,
				[ [ SCOPE_3_BIN_ID, 1, 0, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ],
				] ],
				 [ SCOPE_3_BIN_ID, 1, 1, sfWScore,
					[ [ S_PC2_BASE_SCORE, FIN_1, A , PC2_SLAP, pc2FW ], 
				] ] ],
            ]

	}

	private void initFusionWeightCandInfoList(){
		FW_NULL_CAND_INFO_LIST =
            [ SCOPE_1_EXT_ID, R_PC2_BASE_SCORE + S_PC2_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, 0, R_PC2_BASE_SCORE,
					[ [ R_PC2_BASE_SCORE, FIN_1, A ],
				] ],
				 [ SCOPE_1_BIN_ID, 1, 1, S_PC2_BASE_SCORE,
					[ [ S_PC2_BASE_SCORE, FIN_1, A ], 
				] ] ],
            ]

		FW_NULL_LOW_API_CAND_INFO_LIST =
            [ SCOPE_1_EXT_ID, rfWScore + sfWScore, true,
				[ [ SCOPE_1_BIN_ID, 1, 0, rfWScore,
					[ [ R_PC2_BASE_SCORE, FIN_1, A, PC2_ROLLED, pc2FW ],
				] ],
				 [ SCOPE_1_BIN_ID, 1, 1, sfWScore,
					[ [ S_PC2_BASE_SCORE, FIN_1, A, PC2_SLAP, pc2FW ], 
				] ] ],
            ]

		FW_100_CAND_INFO_LIST =
            [ SCOPE_1_EXT_ID, R_PC2_BASE_SCORE + S_PC2_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, 0, R_PC2_BASE_SCORE,
					[ [ R_PC2_BASE_SCORE, FIN_1, A, PC2_ROLLED, 100],
				] ],
				 [ SCOPE_1_BIN_ID, 1, 1, S_PC2_BASE_SCORE,
					[ [ S_PC2_BASE_SCORE, FIN_1, A, PC2_SLAP, 100], 
				] ] ],
            ]

		FW_90_CAND_INFO_LIST =
			[ SCOPE_1_EXT_ID, rfW90Score + sfW90Score, true,
				[ [ SCOPE_1_BIN_ID, 1, 0, rfW90Score,
					[ [ R_PC2_BASE_SCORE, FIN_1, A, PC2_ROLLED, 90],
				] ],
				 [ SCOPE_1_BIN_ID, 1, 1, sfW90Score,
					[ [ S_PC2_BASE_SCORE, FIN_1, A, PC2_SLAP, 90], 
				] ] ],
			]

		FW_R100S120_CAND_INFO_LIST =
			[ SCOPE_1_EXT_ID, R_PC2_BASE_SCORE + sfW120Score, true,
				[ [ SCOPE_1_BIN_ID, 1, 0, R_PC2_BASE_SCORE,
					[ [ R_PC2_BASE_SCORE, FIN_1, A, PC2_ROLLED, 100],
				] ],
				 [ SCOPE_1_BIN_ID, 1, 1, sfW120Score,
					[ [ S_PC2_BASE_SCORE, FIN_1, A, PC2_SLAP, 120], 
				] ] ],
			]

		FW_R120S100_CAND_INFO_LIST =
			[ SCOPE_1_EXT_ID, rfW120Score + S_PC2_BASE_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, 0, rfW120Score,
					[ [ R_PC2_BASE_SCORE, FIN_1, A, PC2_ROLLED, 120],
				] ],
				 [ SCOPE_1_BIN_ID, 1, 1, S_PC2_BASE_SCORE,
					[ [ S_PC2_BASE_SCORE, FIN_1, A, PC2_SLAP, 100], 
				] ] ],
			]

	}

	private void initExternalIdCandInfoList(){
		EXT_ID_TEST_A_CAND_INFO_LIST =
			[ EXT_ID_TEST_A_EXT_ID, EXT_ID_SCORE_LOW, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, EXT_ID_SCORE_LOW,
					[ [ EXT_ID_SCORE_LOW, FIN_3, A , PC2_ROLLED, 100 ] ] 
				] ]
			]

		EXT_ID_TEST_B_CAND_INFO_LIST =
			[ EXT_ID_TEST_B_EXT_ID, EXT_ID_SCORE_LOW, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, EXT_ID_SCORE_LOW,
					[ [ EXT_ID_SCORE_LOW, FIN_3, A, PC2_ROLLED, 100 ] ] 
				] ]
			]

		EXT_ID_TEST_C_CAND_INFO_LIST =
			[ EXT_ID_TEST_C_EXT_ID, EXT_ID_SCORE_LOW, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, EXT_ID_SCORE_LOW,
					[ [ EXT_ID_SCORE_LOW, FIN_3, A, PC2_ROLLED, 100 ] ] 
				] ]
			]

		EXT_ID_TEST_D_CAND_INFO_LIST =
			[ EXT_ID_TEST_D_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_3, A, PC2_ROLLED , 100 ] ] 
				] ]
			]

		EXT_ID_TEST_E_CAND_INFO_LIST =
			[ EXT_ID_TEST_E_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_3, A, PC2_ROLLED ,100 ] ] 
				] ]
			]

		EXT_ID_TEST_F_CAND_INFO_LIST =
			[ EXT_ID_TEST_F_EXT_ID, FULL_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
					[ [ FULL_SCORE, FIN_3, A, PC2_ROLLED ,100 ] ] 
				] ]
			]
	
	}

	private void initMultiAxisCandInfoList(){
		MULTI_AXIS_1_A_CAND_INFO_LIST =
			[ DEF_EXT_ID, MULTI_AXIS_1_A_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, MULTI_AXIS_1_A_SCORE,
					[ [ MULTI_AXIS_1_A_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] ] ]
			]

		MULTI_AXIS_1_B_CAND_INFO_LIST =
			[ DEF_EXT_ID, MULTI_AXIS_1_B_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, MULTI_AXIS_1_B_SCORE,
					[ [ MULTI_AXIS_1_B_SCORE, FIN_1, B ] ] ] ]
			]

		MULTI_AXIS_1_C_CAND_INFO_LIST_1 =
			[ DEF_EXT_ID, MULTI_AXIS_1_C_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, MULTI_AXIS_1_C_SCORE,
					[ [ MULTI_AXIS_1_C_SCORE, FIN_1, C ] ] ] ]
			]

		MULTI_AXIS_1_C_CAND_INFO_LIST_2 =
			[ DEF_EXT_ID, MULTI_AXIS_1_D_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, MULTI_AXIS_1_D_SCORE,
					[ [ MULTI_AXIS_1_D_SCORE, FIN_1, C ] ] ] ]
			]

		MULTI_AXIS_1_D_CAND_INFO_LIST =
			[ DEF_EXT_ID, MULTI_AXIS_1_D_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, MULTI_AXIS_1_D_SCORE,
					[ [ MULTI_AXIS_1_D_SCORE, FIN_1, D ] ] ] ]
			]

		MULTI_AXIS_2_A_CAND_INFO_LIST =
			[ DEF_EXT_ID, MULTI_AXIS_2_A_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, MULTI_AXIS_2_A_SCORE,
					[ [ MULTI_AXIS_2_A_SCORE, FIN_1, A , PC2_ROLLED, pc2FW ] ] ] ]
			]

		MULTI_AXIS_2_B_CAND_INFO_LIST =
			[ DEF_EXT_ID, MULTI_AXIS_2_B_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, MULTI_AXIS_2_B_SCORE,
					[ [ MULTI_AXIS_2_B_SCORE, FIN_1, B ] ] ] ]
			]

		MULTI_AXIS_2_C_CAND_INFO_LIST =
			[ DEF_EXT_ID, MULTI_AXIS_2_C_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, MULTI_AXIS_2_C_SCORE,
					[ [ MULTI_AXIS_2_C_SCORE, FIN_1, C ] ] ] ]
			]

		MULTI_AXIS_2_D_CAND_INFO_LIST =
			[ DEF_EXT_ID, MULTI_AXIS_2_D_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, MULTI_AXIS_2_D_SCORE,
					[ [ MULTI_AXIS_2_D_SCORE, FIN_1, D ] ] ] ]
			]

		MULTI_AXIS_3_D_CAND_INFO_LIST =
			[ DEF_EXT_ID, MULTI_AXIS_3_D_SCORE, true,
				[ [ SCOPE_1_BIN_ID, 1, reqIndex, MULTI_AXIS_3_D_SCORE,
					[ [ MULTI_AXIS_3_D_SCORE, FIN_2, D ] ] ] ]
			]
	}

    private void initDynCandInfoList(){}

	public List getCandList_Default_R(){
        return [ R_DEF_CAND_INFO_LIST ]
    }

    public List getCandList_Default_S(){
        return [ S_DEF_CAND_INFO_LIST ]
    }

    public List getCandList_Default_S_Inq_R(){
        return [ S_DEF_INQ_R_CAND_INFO_LIST ]
    }

    public List getCandList_Default_RS(){
        return [ RS_DEF_CAND_INFO_LIST ]
    }

    public List getCandList_Default_Fmp5(){
        return [ DEF_FMP5_CAND_INFO_LIST]
    }

    public List getCandList_Default_RS_multiScope(){
        return [ DEF_RS_MULTI_SCOPE_CAND_INFO_LIST ]
    }
	
	public List getCandList_LeOption_1(){
		return [ LE_OPTION_CAND_INFO_LIST_1 ] 
	}

	public List getCandList_LeOption_2(){
		return [ LE_OPTION_CAND_INFO_LIST_2 ] 
	}

	public List getCandList_LeOption_3(){
		return [ LE_OPTION_CAND_INFO_LIST_3 ] 
	}

	public List getCandList_LeOption_4(){
		return [ LE_OPTION_CAND_INFO_LIST_4 ] 
	}

	public List getCandList_Pc2Option_1(){
		return [ PC2_OPTION_CAND_INFO_LIST_1 ] 
	}

	public List getCandList_Pc2Option_2(){
		return [ PC2_OPTION_CAND_INFO_LIST_2 ] 
	}

	public List getCandList_Pc2Option_3(){
		return [ PC2_OPTION_CAND_INFO_LIST_3 ] 
	}

	public List getCandList_Pc2Option_4(){
		return [ PC2_OPTION_CAND_INFO_LIST_4 ] 
	}

	public List getCandList_Pc2Option_5(){
		return [ PC2_OPTION_CAND_INFO_LIST_5 ] 
	}

	public List getCandList_Pc2Option_6(){
		return [ PC2_OPTION_CAND_INFO_LIST_6 ] 
	}

	public List getCandList_Pc2Option_7(){
		return [ PC2_OPTION_CAND_INFO_LIST_7 ] 
	}

	public List getCandList_Pc2Option_8(){
		return [ PC2_OPTION_CAND_INFO_LIST_8 ] 
	}

	public List getCandList_RotationByAxis(){
		return [ ROTATION_BY_AXIS_CAND_INFO_LIST ] 
	}

	public List getCandList_Gender_M_Only(){
		return [ R_GEN_M_CAND_INFO_LIST ] 
	}

	public List getCandList_Gender_F_Only(){
		return [ R_GEN_F_CAND_INFO_LIST ] 
	}

	public List getCandList_Gender_M(){
		return [ R_GEN_M_CAND_INFO_LIST,  R_GEN_U_CAND_INFO_LIST ] 
	}

	public List getCandList_Gender_F(){
		return [ R_GEN_F_CAND_INFO_LIST, R_GEN_U_CAND_INFO_LIST ] 
	}
	
	public List getCandList_Gender_U_R(){
		return [ R_GEN_M_CAND_INFO_LIST, R_GEN_F_CAND_INFO_LIST, R_GEN_U_CAND_INFO_LIST ] 
	}

	public List getCandList_Gender_U_S(){
		return [ S_GEN_M_CAND_INFO_LIST, S_GEN_F_CAND_INFO_LIST, S_GEN_U_CAND_INFO_LIST ] 
	}

	public List getCandList_Yob_All(){
		return [ YOB_1_CAND_INFO_LIST, YOB_2_CAND_INFO_LIST, YOB_3_CAND_INFO_LIST,
				 YOB_4_CAND_INFO_LIST, YOB_5_CAND_INFO_LIST, YOB_6_CAND_INFO_LIST,
				 YOB_7_CAND_INFO_LIST, YOB_8_CAND_INFO_LIST, YOB_9_CAND_INFO_LIST,
				 YOB_10_CAND_INFO_LIST, YOB_11_CAND_INFO_LIST, YOB_12_CAND_INFO_LIST ] 
	}

	public List getCandList_Yob_10(){
		return [ YOB_1_CAND_INFO_LIST, YOB_2_CAND_INFO_LIST, YOB_3_CAND_INFO_LIST,
				 YOB_4_CAND_INFO_LIST, YOB_5_CAND_INFO_LIST, YOB_7_CAND_INFO_LIST,
				 YOB_8_CAND_INFO_LIST, YOB_10_CAND_INFO_LIST, YOB_11_CAND_INFO_LIST,
				 YOB_12_CAND_INFO_LIST ] 
	}

	public List getCandList_Yob_9(){
		return [ YOB_1_CAND_INFO_LIST, YOB_2_CAND_INFO_LIST, YOB_3_CAND_INFO_LIST,
				 YOB_4_CAND_INFO_LIST, YOB_5_CAND_INFO_LIST, YOB_8_CAND_INFO_LIST, 
				 YOB_9_CAND_INFO_LIST, YOB_11_CAND_INFO_LIST, YOB_12_CAND_INFO_LIST ] 
	}

	public List getCandList_Yob_2(){
		return [ YOB_1_CAND_INFO_LIST, YOB_12_CAND_INFO_LIST ] 
	}

    public List getCandList_Pattern(){
        return [ PATTERN_CAND_INFO_LIST ]
    }

    public List getCandList_R_Pattern(){
        return [ R_PATTERN_CAND_INFO_LIST ]
    }

    public List getCandList_Pattern_All(){
        return [ PATTERN_A_CAND_INFO_LIST, PATTERN_W_CAND_INFO_LIST, PATTERN_L_CAND_INFO_LIST,
                 PATTERN_R_CAND_INFO_LIST, PATTERN_S_CAND_INFO_LIST, PATTERN_AW_CAND_INFO_LIST,
                 PATTERN_AL_CAND_INFO_LIST, PATTERN_AR_CAND_INFO_LIST, PATTERN_WL_CAND_INFO_LIST,
                 PATTERN_WR_CAND_INFO_LIST, PATTERN_LR_CAND_INFO_LIST, PATTERN_LRA_CAND_INFO_LIST,
                 PATTERN_AWR_CAND_INFO_LIST, PATTERN_WLR_CAND_INFO_LIST, PATTERN_AWL_CAND_INFO_LIST,
                 PATTERN_AWLR_CAND_INFO_LIST , PATTERN_A_P_WW_CAND_INFO_LIST]
    }

    public List getCandList_Pattern_14_1(){
        return [ PATTERN_A_CAND_INFO_LIST, PATTERN_W_CAND_INFO_LIST, PATTERN_S_CAND_INFO_LIST,
                 PATTERN_AW_CAND_INFO_LIST,  PATTERN_AL_CAND_INFO_LIST, PATTERN_AR_CAND_INFO_LIST,
                 PATTERN_WL_CAND_INFO_LIST,  PATTERN_WR_CAND_INFO_LIST, PATTERN_LRA_CAND_INFO_LIST,
                 PATTERN_AWR_CAND_INFO_LIST, PATTERN_WLR_CAND_INFO_LIST, PATTERN_AWL_CAND_INFO_LIST,
                 PATTERN_AWLR_CAND_INFO_LIST , PATTERN_A_P_WW_CAND_INFO_LIST]
    }

    public List getCandList_Pattern_13_1(){
        return [ PATTERN_R_CAND_INFO_LIST, PATTERN_S_CAND_INFO_LIST, PATTERN_W_CAND_INFO_LIST,
                 PATTERN_AW_CAND_INFO_LIST , PATTERN_AR_CAND_INFO_LIST, PATTERN_WL_CAND_INFO_LIST,
                 PATTERN_WR_CAND_INFO_LIST, PATTERN_LR_CAND_INFO_LIST, PATTERN_LRA_CAND_INFO_LIST,
                 PATTERN_AWR_CAND_INFO_LIST, PATTERN_WLR_CAND_INFO_LIST, PATTERN_AWL_CAND_INFO_LIST,
                 PATTERN_AWLR_CAND_INFO_LIST ]
    }

    public List getCandList_Pattern_13_2(){
        return [ PATTERN_A_CAND_INFO_LIST, PATTERN_R_CAND_INFO_LIST, PATTERN_S_CAND_INFO_LIST,
                 PATTERN_AW_CAND_INFO_LIST, PATTERN_AL_CAND_INFO_LIST, PATTERN_AR_CAND_INFO_LIST,
                 PATTERN_WR_CAND_INFO_LIST, PATTERN_LR_CAND_INFO_LIST, PATTERN_LRA_CAND_INFO_LIST,
                 PATTERN_AWR_CAND_INFO_LIST, PATTERN_WLR_CAND_INFO_LIST, PATTERN_AWL_CAND_INFO_LIST,
                 PATTERN_AWLR_CAND_INFO_LIST  ]
    }

    public List getCandList_Pattern_13_3(){
        return [ PATTERN_W_CAND_INFO_LIST,  PATTERN_R_CAND_INFO_LIST, PATTERN_S_CAND_INFO_LIST,
                 PATTERN_AW_CAND_INFO_LIST,PATTERN_AR_CAND_INFO_LIST, PATTERN_WL_CAND_INFO_LIST,
                 PATTERN_WR_CAND_INFO_LIST, PATTERN_LR_CAND_INFO_LIST, PATTERN_LRA_CAND_INFO_LIST,
                 PATTERN_AWR_CAND_INFO_LIST, PATTERN_WLR_CAND_INFO_LIST, PATTERN_AWL_CAND_INFO_LIST,
                 PATTERN_AWLR_CAND_INFO_LIST ]
    }

    public List getCandList_Pattern_10_1(){
        return [ PATTERN_A_CAND_INFO_LIST, PATTERN_S_CAND_INFO_LIST, PATTERN_AW_CAND_INFO_LIST,
                 PATTERN_AL_CAND_INFO_LIST, PATTERN_AR_CAND_INFO_LIST,  PATTERN_LRA_CAND_INFO_LIST,
                 PATTERN_AWR_CAND_INFO_LIST ,PATTERN_AWL_CAND_INFO_LIST, PATTERN_AWLR_CAND_INFO_LIST,
                 PATTERN_A_P_WW_CAND_INFO_LIST ]
    }

    public List getCandList_Pattern_9_1(){
        return [ PATTERN_A_CAND_INFO_LIST, PATTERN_S_CAND_INFO_LIST, PATTERN_AW_CAND_INFO_LIST,
                 PATTERN_AL_CAND_INFO_LIST, PATTERN_AR_CAND_INFO_LIST,  PATTERN_LRA_CAND_INFO_LIST,
                 PATTERN_AWR_CAND_INFO_LIST ,PATTERN_AWL_CAND_INFO_LIST, PATTERN_AWLR_CAND_INFO_LIST ]
    }

    public List getCandList_Pattern_9_2(){
        return [ PATTERN_L_CAND_INFO_LIST ,PATTERN_S_CAND_INFO_LIST, PATTERN_AL_CAND_INFO_LIST,
                 PATTERN_WL_CAND_INFO_LIST, PATTERN_LR_CAND_INFO_LIST, PATTERN_LRA_CAND_INFO_LIST,
                 PATTERN_WLR_CAND_INFO_LIST, PATTERN_AWL_CAND_INFO_LIST, PATTERN_AWLR_CAND_INFO_LIST ]
    }

	public List _getCandList_FingerNo_All(){
		return [ FIN_NO_0_CAND_INFO_LIST, FIN_NO_1_CAND_INFO_LIST, FIN_NO_2_CAND_INFO_LIST,
				 FIN_NO_3_CAND_INFO_LIST, FIN_NO_4_CAND_INFO_LIST, FIN_NO_5_CAND_INFO_LIST,
				 FIN_NO_6_CAND_INFO_LIST, FIN_NO_7_CAND_INFO_LIST, FIN_NO_8_CAND_INFO_LIST,
				 FIN_NO_9_CAND_INFO_LIST, FIN_NO_012_CAND_INFO_LIST, FIN_NO_234_CAND_INFO_LIST,
				 FIN_NO_456_CAND_INFO_LIST ] 
	}
	
	public List getCandList_R_FingerNo_All(){
		return [R_FIN_NO_0_CAND_INFO_LIST_1, R_FIN_NO_123456789_CAND_INFO_LIST_1, R_FIN_NO_0123456789_CAND_INFO_LIST_1,
				R_FIN_NO_5_CAND_INFO_LIST_2, R_FIN_NO_012346789_CAND_INFO_LIST_2, R_FIN_NO_0123456789_CAND_INFO_LIST_2 ]
	}

	public List getCandList_R_FingerNo_Use_Filter(){
		return [R_FIN_NO_0_CAND_INFO_LIST_1, R_FIN_NO_0123456789_CAND_INFO_LIST_1,
				R_FIN_NO_5_CAND_INFO_LIST_2, R_FIN_NO_0123456789_CAND_INFO_LIST_2 ]
	}

	public List getCandList_S_FingerNo_All(){
		return [S_FIN_NO_0_CAND_INFO_LIST_1, S_FIN_NO_123456789_CAND_INFO_LIST_1, S_FIN_NO_0123456789_CAND_INFO_LIST_1,
				S_FIN_NO_5_CAND_INFO_LIST_2, S_FIN_NO_012346789_CAND_INFO_LIST_2, S_FIN_NO_0123456789_CAND_INFO_LIST_2 ]
	}

	public List getCandList_S_FingerNo_All_Inq_R(){
		return [S_FIN_NO_0_INQ_R_CAND_INFO_LIST_1, S_FIN_NO_123456789_INQ_R_CAND_INFO_LIST_1, S_FIN_NO_0123456789_INQ_R_CAND_INFO_LIST_1,
				S_FIN_NO_5_INQ_R_CAND_INFO_LIST_2, S_FIN_NO_012346789_INQ_R_CAND_INFO_LIST_2, S_FIN_NO_0123456789_INQ_R_CAND_INFO_LIST_2 ]
	}

	public List getCandList_S_FingerNo_Use_Filter(){
		return [S_FIN_NO_0_CAND_INFO_LIST_1, S_FIN_NO_0123456789_CAND_INFO_LIST_1,
				S_FIN_NO_5_CAND_INFO_LIST_2, S_FIN_NO_0123456789_CAND_INFO_LIST_2 ]
	}

	public List getCandList_S_FingerNo_Use_Filter_Inq_R(){
		return [S_FIN_NO_0_INQ_R_CAND_INFO_LIST_1, S_FIN_NO_0123456789_INQ_R_CAND_INFO_LIST_1,
				S_FIN_NO_5_INQ_R_CAND_INFO_LIST_2, S_FIN_NO_0123456789_INQ_R_CAND_INFO_LIST_2 ]
	}

	public List getCandList_FingerNo_1(){
		return [ FIN_NO_0_CAND_INFO_LIST]
	}	

	public List getCandList_FingerNo_2(){
		return [ FIN_NO_1_CAND_INFO_LIST]
	}	

	public List getCandList_FingerNo_5(){
		return [ FIN_NO_4_CAND_INFO_LIST]
	}	

	public List getCandList_FingerNo_6(){
		return [ FIN_NO_5_CAND_INFO_LIST]
	}	

	public List getCandList_FingerNo_10(){
		return [ FIN_NO_9_CAND_INFO_LIST ]
	}

	public List getCandList_FingerNo_123(){
		return [ FIN_NO_1_CAND_INFO_LIST, FIN_NO_2_CAND_INFO_LIST, FIN_NO_3_CAND_INFO_LIST,
				 FIN_NO_012_CAND_INFO_LIST, FIN_NO_234_CAND_INFO_LIST ]
	}

	public List getCandList_FingerNo_01234(){
		return [ FIN_NO_0_CAND_INFO_LIST, FIN_NO_1_CAND_INFO_LIST, FIN_NO_2_CAND_INFO_LIST, 
				 FIN_NO_3_CAND_INFO_LIST, FIN_NO_4_CAND_INFO_LIST,FIN_NO_012_CAND_INFO_LIST, 
				 FIN_NO_234_CAND_INFO_LIST, FIN_NO_456_CAND_INFO_LIST ]
	}

	public List getCandList_Loss_FingerNo_123456789(){
		return [ LOSS_FIN_NO_1_CAND_INFO_LIST, LOSS_FIN_NO_2_CAND_INFO_LIST, LOSS_FIN_NO_3_CAND_INFO_LIST,
				 LOSS_FIN_NO_4_CAND_INFO_LIST, LOSS_FIN_NO_5_CAND_INFO_LIST, LOSS_FIN_NO_6_CAND_INFO_LIST,
				 LOSS_FIN_NO_7_CAND_INFO_LIST, LOSS_FIN_NO_8_CAND_INFO_LIST, LOSS_FIN_NO_9_CAND_INFO_LIST ] 
	}

	public List getCandList_Loss_FingerNo_56789(){
		return [ LOSS_FIN_NO_5_CAND_INFO_LIST, LOSS_FIN_NO_6_CAND_INFO_LIST, LOSS_FIN_NO_7_CAND_INFO_LIST,
				 LOSS_FIN_NO_8_CAND_INFO_LIST, LOSS_FIN_NO_9_CAND_INFO_LIST ] 
	}

	public List getCandList_Loss_FingerNo_9(){
		return [ LOSS_FIN_NO_9_CAND_INFO_LIST ]
	}

	public List getCandList_Adjacent_All(){
		return [ ADJ_1_CAND_INFO_LIST, ADJ_2_CAND_INFO_LIST, ADJ_3_CAND_INFO_LIST ]
	}

	public List getCandList_Adjacent_1(){
		return [ ADJ_1_CAND_INFO_LIST ]
	}

	public List getCandList_Adjacent_2(){
		return [ ADJ_2_CAND_INFO_LIST ]
	}

	public List getCandList_Adjacent_3(){
		return [ ADJ_3_CAND_INFO_LIST ]
	}

	public List getCandList_Adjacent_2_3(){
		return [ ADJ_2_CAND_INFO_LIST, ADJ_3_CAND_INFO_LIST ]
	}

	public List getCandList_Race_All(){
		return [ RACE_1_CAND_INFO_LIST, RACE_2_CAND_INFO_LIST, RACE_4_CAND_INFO_LIST,
				 RACE_8_CAND_INFO_LIST, RACE_1_CAND_INFO_LIST ]
	}

	public List getCandList_Race_1(){
		return [ RACE_1_CAND_INFO_LIST, RACE_M1_CAND_INFO_LIST ]
	}

	public List getCandList_Race_2(){
		return [ RACE_2_CAND_INFO_LIST, RACE_M1_CAND_INFO_LIST ]
	}

	public List getCandList_Race_4(){
		return [ RACE_4_CAND_INFO_LIST, RACE_M1_CAND_INFO_LIST ]
	}

	public List getCandList_Region_All(){
		return [ REGION_1_CAND_INFO_LIST, REGION_9_CAND_INFO_LIST, REGION_F_CAND_INFO_LIST,
				 REGION_U_CAND_INFO_LIST ]
	}

	public List getCandList_Region_1(){
		return [ REGION_1_CAND_INFO_LIST, REGION_U_CAND_INFO_LIST ]
	}

	public List getCandList_Region_9(){
		return [ REGION_9_CAND_INFO_LIST, REGION_U_CAND_INFO_LIST ]
	}

	public List getCandList_Region_F(){
		return [ REGION_F_CAND_INFO_LIST, REGION_U_CAND_INFO_LIST ]
	}

	public List getCandList_ColdSearch_All(){
		return [ COLD_1_CAND_INFO_LIST, COLD_2_CAND_INFO_LIST, COLD_3_CAND_INFO_LIST,
				 COLD_4_CAND_INFO_LIST, COLD_5_CAND_INFO_LIST, COLD_6_CAND_INFO_LIST,
				 COLD_7_CAND_INFO_LIST, COLD_8_CAND_INFO_LIST, COLD_9_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_1_R(){
		return [ R_SCOPE_1_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_2_R(){
		return [ R_SCOPE_2_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_3_R(){
		return [ R_SCOPE_3_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_1_S(){
		return [ S_SCOPE_1_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_2_S(){
		return [ S_SCOPE_2_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_2_S_Inq_R(){
		return [ S_SCOPE_2_INQ_R_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_3_S(){
		return [ S_SCOPE_3_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_1_RS(){
		return [ RS_SCOPE_1_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_2_RS(){
		return [ RS_SCOPE_2_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_3_RS(){
		return [ RS_SCOPE_3_CAND_INFO_LIST ]
	}

	public List getCandList_Scope_1_2_R(){
		return [ R_SCOPE_1_CAND_INFO_LIST, R_SCOPE_2_CAND_INFO_LIST ] 
	}

	public List getCandList_Scope_1_2_S(){
		return [ S_SCOPE_1_CAND_INFO_LIST, S_SCOPE_2_CAND_INFO_LIST ] 
	}

	public List getCandList_Scope_1_2_S_Inq_R(){
		return [ S_SCOPE_1_INQ_R_CAND_INFO_LIST, S_SCOPE_2_INQ_R_CAND_INFO_LIST ] 
	}

	public List getCandList_Scope_1_2_RS(){
		return [ RS_SCOPE_1_CAND_INFO_LIST, RS_SCOPE_2_CAND_INFO_LIST ] 
	}

	public List getCandList_Scope_2_3_S(){
		return [ S_SCOPE_2_CAND_INFO_LIST, S_SCOPE_3_CAND_INFO_LIST ] 
	}

	public List getCandList_Scope_2_3_S_Inq_R(){
		return [ S_SCOPE_2_INQ_R_CAND_INFO_LIST, S_SCOPE_3_INQ_R_CAND_INFO_LIST ] 
	}

	public List getCandList_Scope_1_3_RS(){
		return [ RS_SCOPE_1_CAND_INFO_LIST, RS_SCOPE_3_CAND_INFO_LIST ] 
	}

	public List getCandList_Scope_1_2_3_RS(){
		return [ RS_SCOPE_1_CAND_INFO_LIST, RS_SCOPE_2_CAND_INFO_LIST, RS_SCOPE_3_CAND_INFO_LIST ] 
	}

	public List getCandList_Fw_Null(){
		return [ FW_NULL_CAND_INFO_LIST ]
	}

	public List getCandList_Fw_Null_LowApi(){
		return [ FW_NULL_LOW_API_CAND_INFO_LIST ]
	}

	public List getCandList_Fw_100(){
		return [ FW_100_CAND_INFO_LIST ]
	}

	public List getCandList_Fw_90(){
		return [ FW_90_CAND_INFO_LIST ]
	}
	
	public List getCandList_Fw_R100S120(){
		return [ FW_R100S120_CAND_INFO_LIST ]
	}

	public List getCandList_Fw_R120S100(){
		return [ FW_R120S100_CAND_INFO_LIST ]
	}

	public List getCandList_External_Id(){
		return [  EXT_ID_TEST_D_CAND_INFO_LIST, EXT_ID_TEST_E_CAND_INFO_LIST, EXT_ID_TEST_F_CAND_INFO_LIST,
					EXT_ID_TEST_A_CAND_INFO_LIST, EXT_ID_TEST_B_CAND_INFO_LIST, EXT_ID_TEST_C_CAND_INFO_LIST,
				 ]
	}

	public List getCandList_MultiAxis_1(){
		return [ MULTI_AXIS_1_A_CAND_INFO_LIST, MULTI_AXIS_1_B_CAND_INFO_LIST, MULTI_AXIS_1_C_CAND_INFO_LIST_1,
				 MULTI_AXIS_1_D_CAND_INFO_LIST ]
	}

	public List getCandList_MultiAxis_2(){
		return [ MULTI_AXIS_2_A_CAND_INFO_LIST, MULTI_AXIS_2_B_CAND_INFO_LIST, MULTI_AXIS_2_C_CAND_INFO_LIST,
				 MULTI_AXIS_2_D_CAND_INFO_LIST ]
	}

	public List getCandList_MultiAxis_3(){
        List resultList = []
		List axisList = [ "A", "B", "C", "D"]

		for ( i in 1..10){
        	for (axis in axisList){
           		List candInfoList =
                	[ DEF_EXT_ID, FULL_SCORE, true,
                    	[ [ SCOPE_1_BIN_ID, 1, reqIndex, FULL_SCORE,
                        	[ [ FULL_SCORE, i, axis ] ] ] ] ,
                	]
            resultList.add(candInfoList)
        	}
		}
        return resultList
	}

	public List getCandList_MultiAxis_1_A(){
		return [ MULTI_AXIS_1_A_CAND_INFO_LIST ]
	}
	
	public List getCandList_MultiAxis_1_D(){
		return [ MULTI_AXIS_1_D_CAND_INFO_LIST ]
	}

	public List getCandList_MultiAxis_1_A_3_D(){
		return [ MULTI_AXIS_1_A_CAND_INFO_LIST, MULTI_AXIS_3_D_CAND_INFO_LIST ]
	}

	public List getCandList_Dyn(){
		return [ DYN_CAND_INFO_LIST ]
	}

	private void setNullFwIfHighLevel(String level){
		if(level == "High") {
			this.fmp5FW = null
		}else{
			this.pc2FW = 200
		}
	}

	private int calcFusionScore_fmp5_pc2() {
        return calcFusionScore_fmp5_pc2(R_PC2_BASE_SCORE, R_FMP5_BASE_SCORE, S_PC2_BASE_SCORE, S_FMP5_BASE_SCORE)
    }
	
	private int calcFusionScore_fmp5_pc2 (Integer basePc2Score, Integer baseFmp5Score) {
        int pc2Score = mergeFWeight(basePc2Score, pc2FW)
        int fmp5Score = mergeFWeight(baseFmp5Score, fmp5FW)
        int fScore = pc2Score + fmp5Score
        return cutoffScore(fScore)
    }

	private int calcFusionScore_fmp5_pc2 (Integer baseRPc2Score, Integer baseRFmp5Score, Integer baseSPc2Score, Integer baseSFmp5Score) {
        int pc2Score = mergeFWeight(getMax(baseRPc2Score,baseSPc2Score), pc2FW)
        int fmp5Score = mergeFWeight(getMax(baseRFmp5Score, baseSFmp5Score), fmp5FW)
        int fScore = pc2Score + fmp5Score
        return cutoffScore(fScore)
    }

	private int getMax(int score_1, int score_2){
		if ( score_1 < score_2){
			return score_2
		} else {
			return score_1
		}
	}

}

