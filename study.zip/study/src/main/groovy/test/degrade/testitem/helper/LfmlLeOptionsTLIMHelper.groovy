package test.degrade.testitem.helper

import static test.common.constants.aim.SearchLFMLParameter.*


class LfmlLeOptionsTLIMHelper {
    
	private static final List S_AUTO_F_AUTO_F8_SL3_RAW_SCORE_LIST = [ 
       1584, 1007, 342,  736, 1526, 1747, 936, 0, 1661, 1219, 518, 1652, 843,  759,  520, 1244 ]
	private static final List S_AUTO_F_MANUAL_F8_SL3_RAW_SCORE_LIST = [
        563, 675, 1584, 1064, 342,  736, 1526, 1747, 936, 0, 1661, 1219, 1113, 1187,  945, 1259 ]
	private static final List S_AUTO_F_MANUAL_MULTI_AXIS_A_F8_SL3_RAW_SCORE_LIST = [
       1184, 1329, 1537, 1215, 893, 863, 1446, 2060, 961, 710, 1579, 938, 1918, 1531, 774, 1390 ]

	private static final List S_AUTO_F_MANUAL_F8_SL3_ALG_3_ROTAT_3_CORE_3_RAW_SCORE_LIST = [
        0, 675, 1584, 1064, 342,  736, 1526, 1747, 936, 0, 1661, 1219, 1113, 1187,  945, 1259 ]

	private static final List S_AUTO_F_MANUAL_F8_SL3_ALG_1_RAW_SCORE_LIST = S_AUTO_F_MANUAL_F8_SL3_RAW_SCORE_LIST
	private static final List S_AUTO_F_MANUAL_F8_SL3_ALG_3_RAW_SCORE_LIST = [
        937, 675, 1584, 1064, 342, 736, 1526, 1747, 936, 0, 1661, 1219, 1113, 1187, 945, 1259 ]
	private static final List S_AUTO_F_MANUAL_MULTI_AXIS_A_F8_SL3_ALG_1_RAW_SCORE_LIST = 
        S_AUTO_F_MANUAL_MULTI_AXIS_A_F8_SL3_RAW_SCORE_LIST
	private static final List S_AUTO_F_MANUAL_MULTI_AXIS_A_F8_SL3_ALG_3_RAW_SCORE_LIST = [
        1109, 1329, 1537, 1215, 893, 863, 1446, 2060, 961, 710, 1579, 938, 1918, 1531, 774, 1390 ]

	private static final List S_AUTO_F_MANUAL_F8_SL3_TOLERANCE_1_RAW_SCORE_LIST = 
        S_AUTO_F_MANUAL_F8_SL3_RAW_SCORE_LIST
	private static final List S_AUTO_F_MANUAL_F8_SL3_TOLERANCE_2_RAW_SCORE_LIST = [
        1902, 675, 1584, 1064, 342, 736, 1526, 1747, 936, 0, 1661, 1219, 1113, 1187, 945, 1259 ]
	private static final List S_AUTO_F_MANUAL_MULTI_AXIS_F8_SL3_TOLERANCE_1_RAW_SCORE_LIST = 
        S_AUTO_F_MANUAL_MULTI_AXIS_A_F8_SL3_RAW_SCORE_LIST
	private static final List S_AUTO_F_MANUAL_MULTI_AXIS_F8_SL3_TOLERANCE_2_RAW_SCORE_LIST = [
        1255, 1329, 1537, 1215, 893, 863, 1446, 2060, 961, 710, 1579, 938, 1918, 1531, 774, 1390 ]

    private List rawScoreList
    private List rawScoreSIndexList
    private List rawScoreFIndexList
    private int score = -1

    public void setupForLeOptions(boolean isLeMatching, boolean updateMpc) {
        if(isLeMatching) {
            setupIndexListManual()
            if(updateMpc) {
                rawScoreList = S_AUTO_F_MANUAL_F8_SL3_ALG_3_ROTAT_3_CORE_3_RAW_SCORE_LIST
            }else{
                rawScoreList = S_AUTO_F_MANUAL_F8_SL3_RAW_SCORE_LIST
            }
        }else{
            setupIndexListAuto()
            rawScoreList = S_AUTO_F_AUTO_F8_SL3_RAW_SCORE_LIST
        }
    }

    public void setupForLeOptionsMultiAxis(boolean updateMpc) {
        setupIndexListManual()
        if(updateMpc) {
            // No test case
        }else{
            rawScoreList = S_AUTO_F_MANUAL_MULTI_AXIS_A_F8_SL3_RAW_SCORE_LIST
        }
    }

    public void setupForApplyLeOpt(boolean applyLeOpt, boolean isMultiAxis) {
        if(applyLeOpt) {
            if(isMultiAxis) {
                // No test case
            }else{
                rawScoreList = S_AUTO_F_MANUAL_F8_SL3_ALG_3_ROTAT_3_CORE_3_RAW_SCORE_LIST
            }
        }else{
            if(isMultiAxis) {
                rawScoreList = S_AUTO_F_MANUAL_MULTI_AXIS_A_F8_SL3_RAW_SCORE_LIST
            }else{
                rawScoreList = S_AUTO_F_MANUAL_F8_SL3_RAW_SCORE_LIST
            }
        }
        setupIndexListManual()
    }

    public void setupForAlgorithm(int algorithm, boolean isMultiAxis) {
        if(isMultiAxis) {
            if(algorithm == 1) {
                rawScoreList = S_AUTO_F_MANUAL_MULTI_AXIS_A_F8_SL3_ALG_1_RAW_SCORE_LIST
            }else if(algorithm == 3) {
                rawScoreList = S_AUTO_F_MANUAL_MULTI_AXIS_A_F8_SL3_ALG_3_RAW_SCORE_LIST
            }
        }else{
            if(algorithm == 1) {
                rawScoreList = S_AUTO_F_MANUAL_F8_SL3_ALG_1_RAW_SCORE_LIST
            }else if(algorithm == 3) {
                rawScoreList = S_AUTO_F_MANUAL_F8_SL3_ALG_3_RAW_SCORE_LIST
            }
        }
        setupIndexListManual()
    }

    public void setupLeTolerance(int tolerance, isMultiAxis) {
        if(isMultiAxis) {
            if(tolerance == 1) {
                rawScoreList = S_AUTO_F_MANUAL_MULTI_AXIS_F8_SL3_TOLERANCE_1_RAW_SCORE_LIST
            }else if(tolerance == 2) {
                rawScoreList = S_AUTO_F_MANUAL_MULTI_AXIS_F8_SL3_TOLERANCE_2_RAW_SCORE_LIST
            }
        }else{
            if(tolerance == 1) {
                rawScoreList = S_AUTO_F_MANUAL_F8_SL3_TOLERANCE_1_RAW_SCORE_LIST
            }else if(tolerance == 2) {
                rawScoreList = S_AUTO_F_MANUAL_F8_SL3_TOLERANCE_2_RAW_SCORE_LIST
            }
        }
        setupIndexListManual()
    }

    private void setupIndexListManual() {
        rawScoreFIndexList = TLIM_MANUAL_F8_SL3_SEARCH_INDEX_LIST
        rawScoreSIndexList = TLIM_MANUAL_F8_SL3_FILE_INDEX_LIST
    }

    private void setupIndexListAuto() {
        rawScoreFIndexList = TLIM_AUTO_F8_SL3_SEARCH_INDEX_LIST
        rawScoreSIndexList = TLIM_AUTO_F8_SL3_FILE_INDEX_LIST
    }

    public int getScore() {
        if(score != -1) {
            return score
        }

        score = 0
        for(rScore in rawScoreList) {
            score += rScore as int
        }
        score /= rawScoreList.size()
        return score
    }

    public List getRawScoreList() {
        return rawScoreList
    }

    public List getRawSearchIndexList() {
        return rawScoreSIndexList
    }

    public List getRawFileIndexList() {
        return rawScoreFIndexList
    }
}

