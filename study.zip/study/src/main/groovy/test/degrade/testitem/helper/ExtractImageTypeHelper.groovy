package test.degrade.testitem.helper

import test.degrade.properties.GlobalProperties
import test.degrade.management.AbendProcessor
import static test.common.constants.aim.AIMWord.*
import static test.common.constants.aim.AIMXmlAttribute.*

class ExtractImageTypeHelper {

	private static final int MAX_SCORE = 9999
	private static final int ZERO_SCORE = 0

    private static final List I_SCORE_VAL_LIST_CMLAF = [ 
			MAX_SCORE, MAX_SCORE, MAX_SCORE, MAX_SCORE, MAX_SCORE,
			MAX_SCORE, MAX_SCORE, MAX_SCORE, MAX_SCORE, MAX_SCORE ]
	
    private static final List I_SCORE_VAL_LIST_CML_1 = [ 
			MAX_SCORE, MAX_SCORE, ZERO_SCORE, MAX_SCORE, MAX_SCORE,
			MAX_SCORE, ZERO_SCORE, MAX_SCORE, ZERO_SCORE, ZERO_SCORE ]
	
    private static final List I_SCORE_VAL_LIST_CML_2 = [ 
			ZERO_SCORE, MAX_SCORE, ZERO_SCORE, MAX_SCORE, MAX_SCORE,
			MAX_SCORE, ZERO_SCORE, MAX_SCORE, MAX_SCORE, ZERO_SCORE ]

    private static final List I_SCORE_VAL_LIST_CML_3 = [ 
			MAX_SCORE, MAX_SCORE, ZERO_SCORE, MAX_SCORE, MAX_SCORE,
			MAX_SCORE, ZERO_SCORE, ZERO_SCORE, MAX_SCORE, ZERO_SCORE ]

	private List iScoreValListList_common1 = []
	private List iScoreValListList_common2 = []
	private List iScoreValListList_common3 = []
	private List iScoreValListList_necGray = []

	public ExtractImageTypeHelper(def context){
		initAssertionScores(context)
	}

	private void initAssertionScores(def context) {
        String timEngine = new GlobalProperties(context).getTimEngine().toUpperCase()
		if(timEngine == CML){
			initCmlAssertionScore()
		}else if (timEngine == CMLAF){
			initCmlafAssertionScore()
		}else{
			assert false, "Unkown TIM engine value '${timEngine}'."
		}
	}
	
	private void initCmlAssertionScore() {
		iScoreValListList_common1 = [
			I_SCORE_VAL_LIST_CML_1, I_SCORE_VAL_LIST_CML_1, I_SCORE_VAL_LIST_CML_1, 
			I_SCORE_VAL_LIST_CML_2, I_SCORE_VAL_LIST_CML_1, I_SCORE_VAL_LIST_CML_1 ]
	
		iScoreValListList_common2 = [
			I_SCORE_VAL_LIST_CML_1, I_SCORE_VAL_LIST_CML_3, I_SCORE_VAL_LIST_CML_3, 
			I_SCORE_VAL_LIST_CML_3, I_SCORE_VAL_LIST_CML_1, I_SCORE_VAL_LIST_CML_1 ]

		iScoreValListList_common3 = [
			I_SCORE_VAL_LIST_CML_2, I_SCORE_VAL_LIST_CML_3, I_SCORE_VAL_LIST_CML_3, 
			I_SCORE_VAL_LIST_CML_3, I_SCORE_VAL_LIST_CML_2, I_SCORE_VAL_LIST_CML_2 ]

		iScoreValListList_necGray << cloneListVals(I_SCORE_VAL_LIST_CMLAF)
		iScoreValListList_necGray[0][2] = ZERO_SCORE
		iScoreValListList_necGray[0][4] = ZERO_SCORE
		iScoreValListList_necGray[0][8] = ZERO_SCORE
		iScoreValListList_necGray[0][9] = ZERO_SCORE
	}

	private void initCmlafAssertionScore() {
		for(i in 1..6){
			iScoreValListList_common1 << I_SCORE_VAL_LIST_CMLAF
			iScoreValListList_common2 << I_SCORE_VAL_LIST_CMLAF
			iScoreValListList_common3 << I_SCORE_VAL_LIST_CMLAF
		}
		iScoreValListList_necGray << cloneListVals(I_SCORE_VAL_LIST_CMLAF)
		iScoreValListList_necGray[0][4] = ZERO_SCORE
		iScoreValListList_necGray[0][9] = ZERO_SCORE
	}
	
	private List cloneListVals(List list){
		return new ArrayList(list)
	}
	
	// TODO 
	// It's better to return not only individual-score,
	// but also containerId, eventId, externalId and so on
	// if we have enough time to improve soapUI assertion groovy test step.
	public List getExpIScoreInfoList(int id){
		switch(id){
			case 1:
			case 2:
			case 5:
				return mkExpIScoreInfoList(iScoreValListList_common1)
				break
			case 3:
			case 4:
				return mkExpIScoreInfoList(iScoreValListList_common2)
				break
			case 6:
				return mkExpIScoreInfoList(iScoreValListList_common3)
				break
		}
	}

	public List getExpIScoreInfoList_necGray(){
		return mkExpIScoreInfoList(iScoreValListList_necGray)[0]
	}
	
	private List mkExpIScoreInfoList(List iScoreValListList){
		List expIScoreInfoListList = []
		for(List iScoreValList in iScoreValListList)	{
			List expIScoreInfoList = []
			for(i in 1..iScoreValList.size()){
				List iScoreInfo = []
				iScoreInfo << iScoreValList[i-1]
				iScoreInfo << i
				iScoreInfo << PC2_ROLLED
				iScoreInfo << 100
            	expIScoreInfoList << iScoreInfo
			}
			expIScoreInfoListList << expIScoreInfoList
		}
		return expIScoreInfoListList
	}
}

