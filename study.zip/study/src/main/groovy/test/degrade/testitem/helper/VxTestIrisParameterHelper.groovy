package test.degrade.testitem.helper

import test.degrade.util.SoapuiObject
import test.common.util.vp.VerifyProcess
import static test.common.constants.aim.AIMWord.*

class VxTestIrisParameterHelper{

	static final String EXTRACT = "/extract"
	static final String MATCH = "/match"
	static final String BY_VERIEYE = " by VeriEye:"
	static final String BY_NIRIS = " by NIRIS:"
	static final String COMMA_PUNCTUATION = ", "
	static final String SLASH_PUNCTUATION = "/"
	static final String MODE = "mode="
	static final String TOLERANCE = "tolerance="
	static final String CONVERTED_TOLERANCE = "converted-tolerance="
	static final String DEINTERLACE = "deinterlace="
	static final String FLEXIBLE_BOUNDARY_MODEL = "flexible-boundary-model="
	static final String MIN_PUPIL_RADIUS = "min-pupil-radius="
	static final String MAX_PUPIL_RADIUS = "max-pupil-radius="
	static final String MIN_IRIS_RADIUS = "min-iris-radius="
	static final String MAX_IRIS_RADIUS = "max-iris-radius=" 

	def soapuiObj
	def vp
	def irisEngine

	def VxTestIrisParameterHelper(context){
		this.soapuiObj = new SoapuiObject(context)
		this.vp = new VerifyProcess(context)
		this.irisEngine = soapuiObj.getGlobalIrisEngine()
	}

	def getIrisParameter(){
		Node root = vp.parseCurrentParam()
		if(irisEngine == NIRIS){
			String extMode = root.verification.iris.NIRIS."extract-mode".text()
			String matchMode = root.verification.iris.NIRIS.match.mode.text()
			String tolerance = root.verification.iris.NIRIS.match.tolerance.text()
			String convTolerance =  getConvTolerance(tolerance).toString()
			return makeResponseNirisParameter(extMode, matchMode, tolerance, convTolerance)
		}else if(irisEngine == VERIEYE){
			String deinterlace = root.verification.iris.VeriEye.extract.deinterlace.text()
			String flexibleBoundaryModel = root.verification.iris.VeriEye.extract."flexible-boundary-model".text()
			String minPupilRadius = root.verification.iris.VeriEye.extract."min-pupil-radius".text()
			String maxPupilRadius = root.verification.iris.VeriEye.extract."max-pupil-radius".text()
			String minIrisRadius = root.verification.iris.VeriEye.extract."min-iris-radius".text()
			String maxIrisRadius = root.verification.iris.VeriEye.extract."max-iris-radius".text()
			String matchMode = root.verification.iris.VeriEye.match.mode.text()
			String tolerance = root.verification.iris.VeriEye.match.tolerance.text()
			return makeResponseVerieyeParameter(deinterlace, flexibleBoundaryModel, minPupilRadius,
												maxPupilRadius, minIrisRadius, maxIrisRadius,
												matchMode, tolerance)
		}
	}

	def getConvTolerance(def tolerance){
		Integer intTolerance = Integer.parseInt(tolerance)
		Integer convTolerance
		if(intTolerance%2 == 0){
			convTolerance = intTolerance/2
		}else if(intTolerance%2 == 1){
			convTolerance =  intTolerance/2 + 0.5
		}
		return convTolerance
	}

	def makeResponseNirisParameter(def extMode, def matchMode, def tolerance, def convTolerance){
		String resParam = EXTRACT + BY_NIRIS + MODE + extMode +
							MATCH + BY_NIRIS + MODE + matchMode + COMMA_PUNCTUATION + 
							TOLERANCE + tolerance + COMMA_PUNCTUATION +
							CONVERTED_TOLERANCE + convTolerance 
		return resParam
	}

	def makeResponseVerieyeParameter(def deinterlace, def flexibleBoundaryModel, def minPupilRadius,
									 def maxPupilRadius, def minIrisRadius, def maxIrisRadius,
									 def matchMode, def tolerance){
		String resParam = EXTRACT + BY_VERIEYE +  DEINTERLACE + deinterlace + COMMA_PUNCTUATION + 
							FLEXIBLE_BOUNDARY_MODEL + flexibleBoundaryModel + COMMA_PUNCTUATION + 
							MIN_PUPIL_RADIUS + minPupilRadius + COMMA_PUNCTUATION +
							MAX_PUPIL_RADIUS + maxPupilRadius + COMMA_PUNCTUATION +
							MIN_IRIS_RADIUS + minIrisRadius + COMMA_PUNCTUATION +
							MAX_IRIS_RADIUS + maxIrisRadius +
							MATCH + BY_VERIEYE + MODE + matchMode + COMMA_PUNCTUATION +
							TOLERANCE + tolerance
		return resParam
	}

}
