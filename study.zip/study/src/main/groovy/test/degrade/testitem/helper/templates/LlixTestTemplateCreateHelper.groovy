package test.degrade.testitem.helper.templates

import test.degrade.testitem.helper.*
import static test.common.constants.data.ImageDataList.*

class LlixTestTemplateCreateHelper extends TestTemplateCreateHelper{


    LlixTestTemplateCreateHelper(context){
    	super(context)
	}

	public String getDefaultFileImage(){
		return imgXmlMaker.getLatentFingerImgXml(LF_009_WSQ)
	}

	public String getDefaultSearchImage(){
		return imgXmlMaker.getLatentFingerImgXml(LF_010_WSQ)
	}
}
