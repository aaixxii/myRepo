package test.degrade.assertion.xml

class XsearchXpathMapper extends AbstractSearchXpathMapper {
		
	public XsearchXpathMapper(){}

	public XsearchXpathMapper(context){
		super(context)
	}

	protected String makeIScoreCondition(List iScore, int index){
		def iScoreVal = iScore[0]
		def iScoreFinNum = iScore[1]
		def iScoreAxis = iScore[2]
		def iScoreInqSet = iScore[3]
		def iScoreFWeight = iScore[4]
		def iScoreFWeightCondition 
		if(iScoreFWeight == null){
			iScoreFWeightCondition = "not(@fusionWeight)"
		} else {
			iScoreFWeightCondition = "@fusionWeight='${iScoreFWeight}'"
		}
		return """
						and individual-score[${index}][
							@axis='${iScoreAxis}' 
							and @position='${iScoreFinNum}' 
							and @value='${iScoreVal}' 
							and @inquirySet='${iScoreInqSet}' 
							and ${iScoreFWeightCondition} 
							and not(@seach-position)
						]\n"""
	}
}

