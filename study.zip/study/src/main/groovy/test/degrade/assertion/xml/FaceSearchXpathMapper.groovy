package test.degrade.assertion.xml

class FaceSearchXpathMapper extends AbstractSearchXpathMapper {
	
	public FaceSearchXpathMapper(){}

	public FaceSearchXpathMapper(context){
		super(context)
	}

	protected String makeIScoreCondition(List iScore, int index){
		def iScoreVal = iScore[0]
		def iScoreFinNum = iScore[1]
		def iScoreAxis = iScore[2]
		def iScoreFWeight = iScore[3]
		def iScoreFWeightCondition 
		if(iScoreFWeight == null){
			iScoreFWeightCondition = "not(@fusionWeight)"
		} else {
			iScoreFWeightCondition = "@fusionWeight='${iScoreFWeight}'"
		}
		return """
						and individual-score[${index}][
							not(@axis)
							and not(@fingerNumber)
							and @value='${iScoreVal}' 
							and not(@inquirySet)
							and ${iScoreFWeightCondition} 
						]\n"""
	}
}

