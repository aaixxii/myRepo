package test.degrade.assertion.xml

import test.common.constants.aim.*

class AimExceptionXpathMapper extends XpathMapper{

	private static final String AIM_FAULT = "ns2:" + AIMXmlElement.AIM_FAULT
	private static final String SOAP_FAULT = "soap:Fault"
	private static final String SOAP_FAULT_PATH = "/soap:Envelope/soap:Body/${SOAP_FAULT}"
	private static final String AIM_FAULT_PATH = "${SOAP_FAULT_PATH}/detail/${AIM_FAULT}"

	def createAIMFaultCountXpathMap(){
		def xpathValueMap = [ "count(//${AIM_FAULT})": "1" ]
		return xpathValueMap
	}

	def createAIMFaultStateXpathMap(String errMessg){
		def xpathValueMap = [ "${AIM_FAULT_PATH}/state": "ERROR" ]
		return xpathValueMap
	}

	def createAIMFaultCodeXpathMap(String code){
		def xpathValueMap = [ "${AIM_FAULT_PATH}/code": "${code}" ]
		return xpathValueMap
	}

	def createAIMFaultDescriptionXpathMap(String errMessg){
		def xpathValueMap = [ "${AIM_FAULT_PATH}/description": "${errMessg}" ]
		return xpathValueMap
	}

	def createFaultStringXpathMap(String errMessg){
		def xpathValueMap = [ "${SOAP_FAULT_PATH}/faultstring": "${errMessg}" ]
		return xpathValueMap
	}

	def createPidFaultValueXpathMap(String errCode, String errMessg){
		def xpathValueMap = [ "//${AIM_FAULT}/code": "${errCode}",
			"//${AIM_FAULT}/message": "${errMessg}" ]
		return xpathValueMap
	}

	def createErrXpathMap(errMessg, errCode){
		def xpathValueMap = [ 
            "${SOAP_FAULT_PATH}/faultstring":"${errMessg}",
            "${AIM_FAULT_PATH}/state":"ERROR",
            "${AIM_FAULT_PATH}/code":"${errCode}",
            "${AIM_FAULT_PATH}/description":"${errMessg}",
		]
		return xpathValueMap
	}

	def createStartWithAIMFaultDescriptionXpathMap(String errMessg, String flag){
		def xpathValueMap = [ """starts-with(//faultstring, "${errMessg}")""": "${flag}" ]
		return xpathValueMap
	}

	def createStartWithFaultStringXpathMap(String errMessg, String flag){
		def xpathValueMap = [ """starts-with(//description, "${errMessg}")""": "${flag}" ]
		return xpathValueMap
	}
}
