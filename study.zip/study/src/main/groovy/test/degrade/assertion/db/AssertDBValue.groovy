package test.degrade.assertion.db

import common.sql.*
import test.common.message.*
import test.degrade.util.*
import test.degrade.management.*
import test.degrade.properties.*

class AssertDBValue{
	def selectExtIdEventIdBase = "select external_Id, event_id from person_biometrics"
	def selectCountBase = "select count(*) as count from person_biometrics"
	def sqlExecutor
	def soapuiObject
	def testPatternName

	AssertDBValue(context, testPatternName){
		def globalProperties = new GlobalProperties(context)
		def ip = globalProperties.getDBIP()
		def port = globalProperties.getDBPort()
		def sid = globalProperties.getDBSID()
		def user = globalProperties.getDBUser()
		def pass = globalProperties.getDBPass()
		this.sqlExecutor = new SqlExecutor(ip, port, sid, user, pass)
		this.soapuiObject = new SoapuiObject(context)
		this.testPatternName = testPatternName
	}

	def assertRecordCnt(wherePhraseOfSql, expectedCount){
		String sql = "${selectCountBase} ${wherePhraseOfSql}"
		def records = sqlExecutor.getSqlResult(sql)

		for (record in records){
			if( !assertValue(record.count, expectedCount) ){
				def errMessg = mkErrMessg(expectedCount, record.count)
				def abendProcessor = new AbendProcessor(soapuiObject.getContext())
				abendProcessor.abendTest(testPatternName, errMessg)
			}
		}
	}

	def assertExtIdAndEventId(wherePhraseOfSql, expectedExternalId, expectedEventId){
		String sql = "${selectExtIdEventIdBase} ${wherePhraseOfSql}"
		def records = sqlExecutor.getSqlResult(sql)

		for (record in records){
			assertExtIdAndEventIdValue(record, expectedExternalId, expectedEventId)
		}
	}

	def assertExtIdAndEventIdValue(record, expectedExtId, expectedEventId){
		if( !assertValue(record.external_Id, expectedExtId) ){
			def errMessg = mkErrMessg(expectedExtId, expectedEventId, record.external_Id, record.event_id)
			def abendProcessor = new AbendProcessor(soapuiObject.getContext())
			abendProcessor.abendTest(testPatternName, errMessg)
		}
	}

	def assertValue(expected, actual){
		return (expected == actual) ? true : false
	}
			
	def mkErrMessg(expectedExtId, expectedEventId, actualExtId, actualEventId){
		return new MessageCreator().mkDBErrMessg(expectedExtId, expectedEventId, actualExtId, actualEventId)
	}

	def mkErrMessg(expectedCount, actualCount){
		return new MessageCreator().mkDBErrMessg(expectedCount, actualCount)
	}
}
