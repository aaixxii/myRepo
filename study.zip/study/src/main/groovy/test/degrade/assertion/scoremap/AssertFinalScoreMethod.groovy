package test.degrade.assertion.scoremap;

import java.awt.List;
import java.util.ArrayList;

public class AssertFinalScoreMethod {
	
	
	static final String Content_SearchMode_1 = "SearchMode = 1, hit score is correct."
	static final String Content_SearchMode_2 = "SearchMode = 2, hit score is correct."
	static final String Content_SearchMode_3 = "SearchMode = 3, hit score is correct."
	
	
	
	def getScoreList(caseNo){
		
		def scoreList = []
		
		switch(caseNo){
			case 0:
			scoreList =[ 
				 [[5101,5101,5100, Content_SearchMode_1],		[3513,3513,3512,Content_SearchMode_2], 		[5101,5101,5100,Content_SearchMode_3]] //fin1
				,[[6110,6110,6109, Content_SearchMode_1], 		[3883,3883,3881,Content_SearchMode_2], 		[6110,6110,6109,Content_SearchMode_3]] //fin2
				,[[807,807,807, Content_SearchMode_1], 			[44,44,44,Content_SearchMode_2], 			[807,807,807,Content_SearchMode_3]]	   //fin3
				,[[2711,2711,2710, Content_SearchMode_1], 		[971,971,969,Content_SearchMode_2], 		[2711,2711,2710,Content_SearchMode_3]] //fin4
				,[[919,919,918, Content_SearchMode_1], 			[56,56,54,Content_SearchMode_2], 			[919,919,918,Content_SearchMode_3]]    //fin5
				,[[1771,1771,1770, Content_SearchMode_1],		[668,668,666,Content_SearchMode_2], 		[1771,1771,1770,Content_SearchMode_3]] //fin6
				,[[940,940,940, Content_SearchMode_1], 			[220,220,220,Content_SearchMode_2], 		[940,940,940,Content_SearchMode_3]]    //fin7
				,[[2919,2919,2918, Content_SearchMode_1], 		[683,683,681,Content_SearchMode_2], 		[2919,2919,2918,Content_SearchMode_3]] //fin8
				,[[1274,1274,1274, Content_SearchMode_1], 		[610,610,610,Content_SearchMode_2], 		[1274,1274,1274,Content_SearchMode_3]] //fin9
				,[[1,1,10, Content_SearchMode_1], 				[0,0,0,Content_SearchMode_2], 				[1,1,10,Content_SearchMode_3]]
				,[[1726,1726,0,807,918, Content_SearchMode_1], 	[100,100,0,44,54,Content_SearchMode_2], 	[1726,1726,0,807,918,Content_SearchMode_3]]  //fin3,5
				,[[2214,2214,0,940,1274, Content_SearchMode_1], [830,830,0,220,610,Content_SearchMode_2], 	[2214,2214,0,940,1274,Content_SearchMode_3]] //fin7,9
				]
			
			break
			
			
			case 1:
			scoreList =[
				 [[5101,5101,5100, Content_SearchMode_1],		[3513,3513,3512,Content_SearchMode_2], 		[5101,5101,5100,Content_SearchMode_3]] //fin1
				,[[6110,6110,6109, Content_SearchMode_1], 		[3883,3883,3881,Content_SearchMode_2], 		[6110,6110,6109,Content_SearchMode_3]] //fin2
				,[[807,807,807, Content_SearchMode_1], 			[44,44,44,Content_SearchMode_2], 			[807,807,807,Content_SearchMode_3]]	   //fin3
				,[[2711,2711,2710, Content_SearchMode_1], 		[971,971,969,Content_SearchMode_2], 		[2711,2711,2710,Content_SearchMode_3]] //fin4
				,[[919,919,918, Content_SearchMode_1], 			[56,56,54,Content_SearchMode_2], 			[919,919,918,Content_SearchMode_3]]    //fin5
				,[[1771,1771,1770, Content_SearchMode_1],		[668,668,666,Content_SearchMode_2], 		[1771,1771,1770,Content_SearchMode_3]] //fin6
				,[[940,940,940, Content_SearchMode_1], 			[220,220,220,Content_SearchMode_2], 		[940,940,940,Content_SearchMode_3]]    //fin7
				,[[2919,2919,2918, Content_SearchMode_1], 		[683,683,681,Content_SearchMode_2], 		[2919,2919,2918,Content_SearchMode_3]] //fin8
				,[[1274,1274,1274, Content_SearchMode_1], 		[610,610,610,Content_SearchMode_2], 		[1274,1274,1274,Content_SearchMode_3]] //fin9
				,[[1,1,10, Content_SearchMode_1], 				[0,0,0,Content_SearchMode_2], 				[1,1,10,Content_SearchMode_3]]
				,[[863,863,0,807,918, Content_SearchMode_1], 	[51,51,0,44,54,Content_SearchMode_2], 		[863,863,0,807,918,Content_SearchMode_3]]  //fin3,5
				,[[1107,1107,0,940,1274, Content_SearchMode_1], [415,415,0,220,610,Content_SearchMode_2], 	[1107,1107,0,940,1274,Content_SearchMode_3]] //fin7,9
				]
			break
			
			case 2:
			scoreList =[
				 [[9999,9999,5100, Content_SearchMode_1], 		[9999,9999,3512,Content_SearchMode_2], 		[9999,9999,5100,Content_SearchMode_3]]
				,[[9999,9999,6109, Content_SearchMode_1], 		[9999,9999,3881,Content_SearchMode_2], 		[9999,9999,6109,Content_SearchMode_3]]
				,[[8070,8070,807, Content_SearchMode_1], 		[440,440,44,Content_SearchMode_2], 			[8070,8070,807,Content_SearchMode_3]]
				,[[9999,9999,2710, Content_SearchMode_1], 		[9692,9692,969,Content_SearchMode_2], 		[9999,9999,2710,Content_SearchMode_3]]
				,[[9186,9186,918, Content_SearchMode_1], 		[542,542,54,Content_SearchMode_2], 			[9186,9186,918,Content_SearchMode_3]]
				,[[9999,9999,1770, Content_SearchMode_1], 		[6662,6662,666,Content_SearchMode_2], 		[9999,9999,1770,Content_SearchMode_3]]
				,[[9400,9400,940, Content_SearchMode_1], 		[2200,2200,220,Content_SearchMode_2], 		[9400,9400,940,Content_SearchMode_3]]
				,[[9999,9999,2918, Content_SearchMode_1], 		[6812,6812,681,Content_SearchMode_2], 		[9999,9999,2918,Content_SearchMode_3]]
				,[[9999,9999,1274, Content_SearchMode_1], 		[6100,6100,610,Content_SearchMode_2], 		[9999,9999,1274,Content_SearchMode_3]]
				,[[1,1,10, Content_SearchMode_1], 				[0,0,0,Content_SearchMode_2], 				[1,1,10,Content_SearchMode_3]]
				,[[8628,8628,0,807,918, Content_SearchMode_1], 	[492,492,0,44,54,Content_SearchMode_2], 	[8628,8628,0,807,918,Content_SearchMode_3]]
				,[[9999,9999,0,940,1274, Content_SearchMode_1], [4150,4150,0,220,610,Content_SearchMode_2], [9999,9999,0,940,1274,Content_SearchMode_3]]
				]
			break
			
			case 3:
			scoreList =[
				 [[6688,6688,5100, Content_SearchMode_1], 		[3661,3661,3512,Content_SearchMode_2], 		[6688,6688,5100,Content_SearchMode_3]]
				,[[8338,8338,6109, Content_SearchMode_1], 		[3917,3917,3881,Content_SearchMode_2], 		[8338,8338,6109,Content_SearchMode_3]]
				,[[2586,2586,807, Content_SearchMode_1], 		[107,107,44,Content_SearchMode_2], 			[2586,2586,807,Content_SearchMode_3]]
				,[[4451,4451,2710, Content_SearchMode_1], 		[2266,2266,969,Content_SearchMode_2], 		[4451,4451,2710,Content_SearchMode_3]]
				,[[2695,2695,918, Content_SearchMode_1], 		[132,132,54,Content_SearchMode_2], 			[2695,2695,918,Content_SearchMode_3]]
				,[[3244,3244,1770, Content_SearchMode_1], 		[1726,1726,666,Content_SearchMode_2], 		[3244,3244,1770,Content_SearchMode_3]]
				,[[2632,2632,940, Content_SearchMode_1], 		[491,491,220,Content_SearchMode_2], 		[2632,2632,940,Content_SearchMode_3]]
				,[[5155,5155,2918, Content_SearchMode_1], 		[1756,1756,681,Content_SearchMode_2], 		[5155,5155,2918,Content_SearchMode_3]]
				,[[2775,2775,1274, Content_SearchMode_1], 		[1614,1614,610,Content_SearchMode_2], 		[2775,2775,1274,Content_SearchMode_3]]
				,["No hit."]
				,[[5281,5281,0,807,918, Content_SearchMode_1], 	[239,239,0,44,54,Content_SearchMode_2], 	[5281,5281,0,807,918,Content_SearchMode_3]]
				,[[5407,5407,0,940,1274, Content_SearchMode_1], [2105,2105,0,220,610,Content_SearchMode_2], [5407,5407,0,940,1274,Content_SearchMode_3]]
				]
			break
			
			case 4:
			scoreList =[
				 [[9999,9999,5100, Content_SearchMode_1], 		[5211,5211,3512,Content_SearchMode_2], 		[9999,9999,5100,Content_SearchMode_3]]
				,[[9999,9999,6109, Content_SearchMode_1], 		[5884,5884,3881,Content_SearchMode_2], 		[9999,9999,6109,Content_SearchMode_3]]
				,[[3575,3575,807, Content_SearchMode_1], 		[18,18,44,Content_SearchMode_2], 			[3575,3575,807,Content_SearchMode_3]]
				,[[9999,9999,2710, Content_SearchMode_1], 		[778,778,969,Content_SearchMode_2], 		[9999,9999,2710,Content_SearchMode_3]]
				,[[4224,4224,918, Content_SearchMode_1], 		[23,23,54,Content_SearchMode_2], 			[4224,4224,918,Content_SearchMode_3]]
				,[[7548,7548,1770, Content_SearchMode_1], 		[397,397,666,Content_SearchMode_2], 		[7548,7548,1770,Content_SearchMode_3]]
				,[[3849,3849,940, Content_SearchMode_1], 		[94,94,220,Content_SearchMode_2], 			[3849,3849,940,Content_SearchMode_3]]
				,[[9999,9999,2918, Content_SearchMode_1], 		[411,411,681,Content_SearchMode_2], 		[9999,9999,2918,Content_SearchMode_3]]
				,[[4699,4699,1274, Content_SearchMode_1], 		[346,346,610,Content_SearchMode_2], 		[4699,4699,1274,Content_SearchMode_3]]
				,["No hit."]
				,[[7799,7799,0,807,918, Content_SearchMode_1], 	[41,41,0,44,54,Content_SearchMode_2], 		[7799,7799,0,807,918,Content_SearchMode_3]]
				,[[8548,8548,0,940,1274, Content_SearchMode_1], [440,440,0,220,610,Content_SearchMode_2],	 [8548,8548,0,940,1274,Content_SearchMode_3]]
				]
			break
			
			case 5:
			scoreList =[
				 [[5100,5100,5100, Content_SearchMode_1], 		[3512,3512,3512,Content_SearchMode_2], 		[5100,5100,5100,Content_SearchMode_3]]
				,[[6109,6109,6109, Content_SearchMode_1], 		[3881,3881,3881,Content_SearchMode_2], 		[6109,6109,6109,Content_SearchMode_3]]
				,[[807,807,807, Content_SearchMode_1],	 		[44,44,44,Content_SearchMode_2], 			[807,807,807,Content_SearchMode_3]]
				,[[2710,2710,2710, Content_SearchMode_1], 		[969,969,969,Content_SearchMode_2], 		[2710,2710,2710,Content_SearchMode_3]]
				,[[918,918,918, Content_SearchMode_1], 			[54,54,54,Content_SearchMode_2], 			[918,918,918,Content_SearchMode_3]]
				,[[1770,1770,1770, Content_SearchMode_1], 		[666,666,666,Content_SearchMode_2], 		[1770,1770,1770,Content_SearchMode_3]]
				,[[940,940,940, Content_SearchMode_1], 			[220,220,220,Content_SearchMode_2], 		[940,940,940,Content_SearchMode_3]]
				,[[2918,2918,2918, Content_SearchMode_1], 		[681,681,681,Content_SearchMode_2], 		[2918,2918,2918,Content_SearchMode_3]]
				,[[1274,1274,1274, Content_SearchMode_1], 		[610,610,610,Content_SearchMode_2], 		[1274,1274,1274,Content_SearchMode_3]]
				,["No hit."]
				,[[1725,1725,0,807,918, Content_SearchMode_1], 	[98,98,0,44,54,Content_SearchMode_2], 		[1725,1725,0,807,918,Content_SearchMode_3]]
				,[[2214,2214,0,940,1274, Content_SearchMode_1], [830,830,0,220,610,Content_SearchMode_2],	[2214,2214,0,940,1274,Content_SearchMode_3]]
				]
			break
			
			case 6:
			scoreList =[
				 [[5100,5100,5100, Content_SearchMode_1], 		[3512,3512,3512,Content_SearchMode_2], 		[5100,5100,5100,Content_SearchMode_3]]
				,[[6109,6109,6109, Content_SearchMode_1], 		[3881,3881,3881,Content_SearchMode_2], 		[6109,6109,6109,Content_SearchMode_3]]
				,[[807,807,807, Content_SearchMode_1],	 		[44,44,44,Content_SearchMode_2], 			[807,807,807,Content_SearchMode_3]]
				,[[2710,2710,2710, Content_SearchMode_1], 		[969,969,969,Content_SearchMode_2], 		[2710,2710,2710,Content_SearchMode_3]]
				,[[918,918,918, Content_SearchMode_1], 			[54,54,54,Content_SearchMode_2], 			[918,918,918,Content_SearchMode_3]]
				,[[1770,1770,1770, Content_SearchMode_1], 		[666,666,666,Content_SearchMode_2], 		[1770,1770,1770,Content_SearchMode_3]]
				,[[940,940,940, Content_SearchMode_1], 			[220,220,220,Content_SearchMode_2], 		[940,940,940,Content_SearchMode_3]]
				,[[2918,2918,2918, Content_SearchMode_1], 		[681,681,681,Content_SearchMode_2], 		[2918,2918,2918,Content_SearchMode_3]]
				,[[1274,1274,1274, Content_SearchMode_1], 		[610,610,610,Content_SearchMode_2], 		[1274,1274,1274,Content_SearchMode_3]]
				,["No hit."]
				,[[862,862,0,807,918, Content_SearchMode_1], 	[49,49,0,44,54,Content_SearchMode_2], 		[862,862,0,807,918,Content_SearchMode_3]]
				,[[1107,1107,0,940,1274, Content_SearchMode_1], [415,415,0,220,610,Content_SearchMode_2],	[1107,1107,0,940,1274,Content_SearchMode_3]]
				]
			break
			
			case 7:
			scoreList =[
				 [[9999,9999,5100, Content_SearchMode_1], 		[9999,9999,3512,Content_SearchMode_2], 		[9999,9999,5100,Content_SearchMode_3]]
				,[[9999,9999,6109, Content_SearchMode_1], 		[9999,9999,3881,Content_SearchMode_2], 		[9999,9999,6109,Content_SearchMode_3]]
				,[[8070,8070,807, Content_SearchMode_1], 		[440,440,44,Content_SearchMode_2], 			[8070,8070,807,Content_SearchMode_3]]
				,[[9999,9999,2710, Content_SearchMode_1], 		[9690,9690,969,Content_SearchMode_2], 		[9999,9999,2710,Content_SearchMode_3]]
				,[[9185,9185,918, Content_SearchMode_1], 		[540,540,54,Content_SearchMode_2], 			[9185,9185,918,Content_SearchMode_3]]
				,[[9999,9999,1770, Content_SearchMode_1], 		[6660,6660,666,Content_SearchMode_2], 		[9999,9999,1770,Content_SearchMode_3]]
				,[[9400,9400,940, Content_SearchMode_1], 		[2200,2200,220,Content_SearchMode_2], 		[9400,9400,940,Content_SearchMode_3]]
				,[[9999,9999,2918, Content_SearchMode_1], 		[6810,6810,681,Content_SearchMode_2], 		[9999,9999,2918,Content_SearchMode_3]]
				,[[9999,9999,1274, Content_SearchMode_1], 		[6100,6100,610,Content_SearchMode_2], 		[9999,9999,1274,Content_SearchMode_3]]
				,["No hit."]
				,[[8627,8627,0,807,918, Content_SearchMode_1], 	[490,490,0,44,54,Content_SearchMode_2], 	[8627,8627,0,807,918,Content_SearchMode_3]]
				,[[9999,9999,0,940,1274, Content_SearchMode_1], [4150,4150,0,220,610,Content_SearchMode_2], [9999,9999,0,940,1274,Content_SearchMode_3]]
				]
			break
			
			default :
			break
		}

	}
	
}

