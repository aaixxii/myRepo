package test.degrade.assertion.dedicated.dogmantis

import test.common.message.MessageCreator
import test.degrade.management.AbendProcessor
import test.degrade.util.*

class CorrespondQrMintuiaCombAssertor {
	private static final String CORRESPOND_QR_MINUTIA = "correspond_QR_Minutia_"
	private static final String EXTENTION_TI = ".ti"
	private static final String EXTENTION_RDBT = ".rdbt"
	private static final String FULL = "FULL"
	private static final String DBQA = "DBQA"
	private static final String LEFT_ALL = "LEFT_ALL"
	private static final String RIGHT_ALL = "RIGHT_ALL"
	private static final String EXPECTED_FUSION_SCORE = "9999"
	private static final String EXPECTED_COMPOSITE_SCORE = "9999"
	private static final String EXPECTED_HIT_FLAG = "true"
	private static final String EXPECTED_FUSION_WEIGHT = "100"
	private static final String EXPECTED_CONTAINER_ID = "1"
	private static final String EXPECTED_EVENT_ID = "1"
	private static final String EXPECTED_SEARCH_REQUEST_INDEX = "0"
	private static final String EXPECTED_AXIS = "A"
	private Map<String, String> masterIndividualScoreMap
	private Map<String, String> expectedIndividualScoreMap
	private String extention
	private boolean isExtentionExist = false;
	private SoapuiObject soapuiObject
	int expectedCandidateSize = 45
	Map<String, Integer> expectedExtIdAppearingCntMap = new HashMap<String, Integer>()
	Map<String, Integer> actualExtIdAppearingCntMap = new HashMap<String, Integer>()

	public CorrespondQrMintuiaCombAssertor(def context) {
		this.soapuiObject = new SoapuiObject(context)
	}
		
	public void assertCandidates(String searchTemplateName, String candiateXml){
		initializeIScoreMap()
		arrangeIScoreBySearchData(searchTemplateName)
		assertCandidateIScore(searchTemplateName, candiateXml)
		assertExtIdAppearingCnt()
	}

	private void assertExtIdAppearingCnt() {
		for(key in expectedExtIdAppearingCntMap.keySet()){
			int expected = expectedExtIdAppearingCntMap.get(key)
			int actual = actualExtIdAppearingCntMap.get(key)
			assertEquals(actual, expected, "externalId '$key' appearing count")
		}
	}
	
	private void assertCandidateSize(String searchTemplateName, int actualCandidateSize) {
		if(searchTemplateName.indexOf(LEFT_ALL) != -1 || 
			searchTemplateName.indexOf(RIGHT_ALL) != -1)
		{
			expectedCandidateSize -= 2
		}
		assertEquals(actualCandidateSize, expectedCandidateSize, "candidate size (search data $searchTemplateName)")
		expectedCandidateSize = 45
	}
		
	private void initializeIScoreMap(){
		masterIndividualScoreMap = createAllMaxScoreMap()
		expectedIndividualScoreMap = createAllMaxScoreMap()
	}

	private assertCandidateIScore(String searchTemplateName, String candiateXml) {
		def parser = new XmlParser().parseText(candiateXml)
		assertCandidateSize(searchTemplateName, parser.candidate.size())
		for(can in parser.candidate){
			cloneMasterMapValues(masterIndividualScoreMap, expectedIndividualScoreMap)
			arrangeIScoreByFileData(can)
			putExtIdAppearingCnt(can)
			assertCanFScore(can)
			assertCanTemp(can)
		}
	}

	private void assertCanFScore(Node can) {
		String fusionScore = can."fusion-score".text()
		assertEquals(fusionScore, EXPECTED_FUSION_SCORE, "fusionScore")
	}

	private void putExtIdAppearingCnt(Node can) {
		String externalId = can.externalId.text()
		int cnt = actualExtIdAppearingCntMap.get(externalId)
		cnt++
		actualExtIdAppearingCntMap.put(externalId, cnt)
	}

	private assertCanTemp(Node can) {
		String externalId = can.externalId.text()
		for(canT in can."candidate-template"){
			String containerId = canT.containerId.text()
			String eventId = canT.eventId.text()
			String searchRequestIndex = canT.searchRequestIndex.text()
			String fusionWeight = canT.fusionWeight.text()
			String compositeScore = canT."composite-score".text()
			assertEquals(containerId, EXPECTED_CONTAINER_ID, "containerId")
			assertEquals(eventId, EXPECTED_EVENT_ID, "eventId")
			assertEquals(searchRequestIndex, EXPECTED_SEARCH_REQUEST_INDEX, "searchRequestIndex")
			assertEquals(compositeScore, EXPECTED_COMPOSITE_SCORE, "compositeScore")
			assertIScore(canT, externalId)
		}
	}

	private assertIScore(Node canT, String externalId) {
		for(iScore in canT."individual-score"){
			String finNum = iScore.attribute("fingerNumber")
			String value = iScore.attribute("value")
			String axis = iScore.attribute("axis")
			String fusionWeight = iScore.attribute("fusionWeight")
			assertEquals(value, expectedIndividualScoreMap.get(finNum), "individual-score (candidate $externalId pos=$finNum)")
			assertEquals(axis, EXPECTED_AXIS, "axis (candidate $externalId pos=$finNum)")
			assertEquals(fusionWeight, EXPECTED_FUSION_WEIGHT, "fusionWeight")
		}
	}

	private arrangeIScoreByFileData(Node can) {
		extention = EXTENTION_RDBT
		isExtentionExist = true
		String externalId = can.externalId.text()
		if((externalId.indexOf(FULL) == -1) && (externalId.indexOf(DBQA) == -1)){
			arrangeExpectedIndividualScoreMap(externalId)
		}
	}

	private arrangeExpectedIScoreMap1Fin(String externalId) {
		String posStr
		int start = externalId.lastIndexOf("_")
		if(isExtentionExist){
			int end = externalId.lastIndexOf(extention)
			posStr = externalId.substring(start+1, end)
		}else{
			posStr = externalId.substring(start+1)
		}
		int pos = Integer.parseInt(posStr).intValue()
		putScore0(pos, pos)
	}

	private arrangeIScoreBySearchData(String searchTemplateName) {
		extention = EXTENTION_TI
		isExtentionExist = false
		int start = searchTemplateName.indexOf("_")
		int end = searchTemplateName.lastIndexOf(extention)
		String searchType = searchTemplateName.substring(start+1, end)
		if(searchType != FULL){
			arrangeExpectedIndividualScoreMap(searchType)
			cloneMasterMapValues(expectedIndividualScoreMap, masterIndividualScoreMap)
		}
	}
	
	private void cloneMasterMapValues(Map<String, String> fromMap, Map<String, String>toMap){
		for(key in fromMap.keySet()){
			toMap.put(key, fromMap.get(key))
		}
	}

	private arrangeExpectedIndividualScoreMap(String dataName) {
		if(dataName.indexOf(LEFT_ALL) != -1){
			putScore0(6, 10)
		}else if(dataName.indexOf(RIGHT_ALL) != -1){
			putScore0(1, 5)
		}else{
			arrangeExpectedIScoreMap1Fin(dataName)
		}
	}

	private putScore0(int startPos, int endPos) {
		for(i in startPos..endPos){
			expectedIndividualScoreMap.put(i as String, "0")
		}
	}
	
	private Map<String, String> createAllMaxScoreMap(){
		Map<String, String> map = new HashMap<String, String>()
		for(i in 1..10){
			map.put(i as String, "9999")
		}
		return map
	}
	
	private void assertEquals(actual, expected, String testPropName) {
		if(actual != expected) {
			abendTest(testPropName, expected, actual)
		}
	}
	
	private void assertNotEquals(actual, expected, String testPropName) {
		if(actual == expected) {
			abendTest(testPropName, "not equal values", "same")
		}
	}

	private void abendTest(def testPropName, def expectedMessg, def actualValue) {
		String errMessg = mkErrMessg(testPropName, expectedMessg, actualValue)
		AbendProcessor abendProcessor = new AbendProcessor(soapuiObject.getContext())
		abendProcessor.abendTest("correspond QR-Minutia", errMessg)
	}
	
	private String mkErrMessg(name, expected, actual){
		return new MessageCreator().mkValueErrMessg(name, expected, actual)
	}

}
