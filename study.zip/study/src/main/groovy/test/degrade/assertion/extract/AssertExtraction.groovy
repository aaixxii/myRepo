package test.degrade.assertion.extract

import test.common.format.extraction.payload.abst.*
import test.common.format.extraction.payload.impl.CropInfo;
import test.common.format.extraction.payload.impl.CropPoints;
import test.common.format.extraction.payload.impl.PalmOutput
import test.degrade.assertion.xml.*
import test.degrade.management.*
import test.degrade.evidence.*
import test.common.message.*
import test.common.util.mu.MatchUnit
import test.degrade.util.*
import common.util.*

class AssertExtraction {
	SoapuiObject soapuiObject
	OutputPayloadAbstract outputPayload
	EvidenceFileOutputor evidenceFileOutputor
	String testName
	private static final int MAX_LIMIT_NFIQ = 5
	private static final int MIN_LIMIT_NFIQ = 1
	private static final int ALL_MANUAL = 0
	private static final int CONTAIN_ROLL_AUTO = 1
	private static final int CONTAIN_SLAP_AUTO = 2
	private int segmentMode = 0

    AssertExtraction(context, String testName){
		this.soapuiObject = new SoapuiObject(context)
		this.evidenceFileOutputor = new EvidenceFileOutputor(context)
		this.testName = testName
	}

    AssertExtraction(OutputPayloadAbstract outputPayload, context) {
        this.outputPayload = outputPayload
		this.soapuiObject = new SoapuiObject(context)
    }

    AssertExtraction(OutputPayloadAbstract outputPayload, context, String testName) {
        this.outputPayload = outputPayload
		this.soapuiObject = new SoapuiObject(context)
		this.testName = testName
    }
	
	public void assertManualAndRollAutoCropPoints(Map<Integer, CropInfo> inputCropInfoMap){
		segmentMode = CONTAIN_ROLL_AUTO
		assertManualCropPoints(inputCropInfoMap)
	}
	
	public void assertManualAndSlapAutoCropPoints(Map<Integer, CropInfo> inputCropInfoMap){
		segmentMode = CONTAIN_SLAP_AUTO
		assertManualCropPoints(inputCropInfoMap)
	}
	
	public void assertManualCropPoints(Map<Integer, CropInfo> inputCropInfoMap){
		for(FingerOutputAbstract finOut in outputPayload.getFingerOutputList()){
			Integer pos = finOut.getPos() as Integer
			CropInfo input = inputCropInfoMap.get(pos)
			if(containAutoSegmentaion()){
				assertSegInfoIsNull(input, pos)
				continue
			}
			CropInfo output = finOut.getCropInifo()
			assertCropCenterPoints(pos, input, output)
			assertCrop4Points(pos, input, output)
		}
	}
	
	private boolean containAutoSegmentaion(){
		if(segmentMode == ALL_MANUAL){
			return false
		}else{
			return true
		}
	}
	
	private void assertSegInfoIsNull(CropInfo input, int pos){
		if(segmentMode == CONTAIN_ROLL_AUTO && pos <= 10){
			assertEquals(input, null, "Roll input seg-info")
		}else if(segmentMode == CONTAIN_SLAP_AUTO && 11 <= pos){
			assertEquals(input, null, "Slap input seg-info")
		}
	}

	private assertCrop4Points(int pos, CropInfo input, CropInfo output) {
		List<CropPoints> crop4PointsIn = input.getCropPoints()
		List<CropPoints> crop4PointsOut = output.getCropPoints()
		assertEquals(crop4PointsIn.size(), 4, "pos=${pos} : input crop 4 point list size")
		assertEquals(crop4PointsOut.size(), 4, "pos=${pos} : output crop 4 point list size")
		for(int i = 0; i < crop4PointsIn.size(); i++){
			assertCropPoints(crop4PointsIn.get(i), crop4PointsOut.get(i), "pos=${pos} : ${i}/4")
		}
	}

	private assertCropCenterPoints(int pos, CropInfo input, CropInfo output) {
		CropPoints centerIn = input.getCenter()
		CropPoints centerOut = output.getCenter()
		assertCropPoints(centerIn, centerOut, "pos=${pos} : center")
	}

	private assertCropPoints(CropPoints input, CropPoints output, String position) {
		assertEquals(input.getX(), output.getX(), "${position} X point")
		assertEquals(input.getY(), output.getY(), "${position} Y point")
	}
	
	public void assertNfiq() {
		for(FingerOutputAbstract fingerOutput in outputPayload.getFingerOutputList()) {
			int nfiq = fingerOutput.getNfiqQuality() as int
			if(nfiq < MIN_LIMIT_NFIQ || MAX_LIMIT_NFIQ < nfiq ) {
				abendTest("NFIQ", "between ${MIN_LIMIT_NFIQ} and ${MAX_LIMIT_NFIQ}", nfiq)
			}
		}
		outputEvidence(testName, "all values are between ${MIN_LIMIT_NFIQ} and ${MAX_LIMIT_NFIQ}")
	}
				
	public void assertFisType(String expectedFisType) {
		for(FingerOutputAbstract fingerOutput in outputPayload.getFingerOutputList()) {
			assertFisTypeOfMinData(fingerOutput.getMinutiaDataList(), expectedFisType)
			assertFisTypeOfFisData(fingerOutput.getFisDataList(), expectedFisType)
		}
		outputEvidence(testName, "FE_TYPE is ${expectedFisType}")
	}
	
	public void assertFisTypes(ArrayList expectedFisTypeList) {
        assertFisTypes(expectedFisTypeList, expectedFisTypeList)
	}

	public void assertFisTypes(List expFisTypeInMinDataList, List expFisTypeInFisDataList) {
		def fingerOutputList = outputPayload.getFingerOutputList()
		for( i in 0..fingerOutputList.size() -1 ) {
			assertFisTypeOfMinDataList(fingerOutputList[i].getMinutiaDataList(), expFisTypeInMinDataList, i)
			assertFisTypeOfFisDataList(fingerOutputList[i].getFisDataList(), expFisTypeInFisDataList, i)
		}
		outputEvidence(testName, "FE_TYPE is ${expFisTypeInMinDataList}")
	}

	public void assertMinutiaData(String expectedDbType,String expectedFormat, String expectedMinutiaType) {
		for(FingerOutputAbstract fingerOutput in outputPayload.getFingerOutputList()) {
			assertDbTypeOfMinData(fingerOutput.getMinutiaDataList(), expectedDbType)
			assertFormatOfMinData(fingerOutput.getMinutiaDataList(), expectedFormat)
			assertMinutiaTypeOfMinData(fingerOutput.getMinutiaDataList(), expectedMinutiaType)
		}
		outputEvidence(testName, "MinutiaData is correct")
	}

	public void assertMinutiaData(List<String> expectedDbTypeList, List<String> expectedFormatList, List<String> expectedMinutiaTypeList) {
		for(FingerOutputAbstract fingerOutput in outputPayload.getFingerOutputList()) {
			assertDbTypeOfMinData(fingerOutput.getMinutiaDataList(), expectedDbTypeList)
			assertFormatOfMinData(fingerOutput.getMinutiaDataList(), expectedFormatList)
			assertMinutiaTypeOfMinData(fingerOutput.getMinutiaDataList(), expectedMinutiaTypeList)
		}
		outputEvidence(testName, "MinutiaData is correct")
	}

	public void assertFisType(List<String> expectedFisTypeList) {
		assertEquals(outputPayload.getFingerOutputList().size(), expectedFisTypeList.size(), "finger-output size")
		for(i in 0..expectedFisTypeList.size()-1) {
			FingerOutputAbstract fingerOutput = outputPayload.getFingerOutputList()[i]
			assertFisTypeOfMinData(fingerOutput.getMinutiaDataList(), expectedFisTypeList[i])
			assertFisTypeOfFisData(fingerOutput.getFisDataList(), expectedFisTypeList[i])
		}
		outputEvidence(testName, "FE_TYPE is ${expectedFisTypeList}")
	}

	public void assertWhiteBlackLevel(String whiteBlackLevel, String expectedTestDataDir) {
		assertEquals(outputPayload.getFingerOutputList().size(), 20, "finger-output size")
		for(FingerOutputAbstract fingerOutput in outputPayload.getFingerOutputList()) {
			assertCroppedImageDiff("white_black_level", whiteBlackLevel, fingerOutput, expectedTestDataDir)
		}
		outputEvidence(testName, "cropped-images are same to last test.")
	}

	public void assertWhiteBlackLevel(List<String> whiteBlackLevelList, String expectedTestDataDir) {
		assertEquals(outputPayload.getFingerOutputList().size(), whiteBlackLevelList.size(), "finger-output size")
		for(i in 0..whiteBlackLevelList.size()-1) {
			FingerOutputAbstract fingerOutput = outputPayload.getFingerOutputList()[i]
			assertCroppedImageDiff("white_black_level", whiteBlackLevelList[i], fingerOutput, expectedTestDataDir)
		}
		outputEvidence(testName, "cropped-images are same to last test.")
	}

	public void assertWhiteBlackLevelNoReturnCroppedImg() {
		assertEquals(outputPayload.getFingerOutputList().size(), 20, "finger-output size")
		for(FingerOutputAbstract fingerOutput in outputPayload.getFingerOutputList()) {
			assertEquals(fingerOutput.getCroppedImage(), "", testName)
		}
		outputEvidence(testName, "cropped-images are same to last test.")
	}

	public void assertCroppedImage(String expectedTestDataDir) {
		for(FingerOutputAbstract fingerOutput in outputPayload.getFingerOutputList()) {
			assertCroppedImageExists(fingerOutput.getCroppedImage())
			assertCroppedImageDiff("croppedImage", "_true", fingerOutput, 
						"${expectedTestDataDir}/${soapuiObject.getContext().testCase.name}")
		}
	}

	public void assertNoReturnCroppedImageWsq4Bit() {
		for(FingerOutputAbstract fingerOutput in outputPayload.getFingerOutputList()) {
			assertEquals(fingerOutput.getCroppedImage(), "", testName)
		}
	}

	public void assertCroppedImageWsq4Bit(String expectedTestDataDir) {
		for(FingerOutputAbstract fingerOutput in outputPayload.getFingerOutputList()) {
			assertCroppedImageExists(fingerOutput.getCroppedImage())
			assertCroppedImageDiff("wsq_", "4bit", fingerOutput, 
						"${expectedTestDataDir}/${soapuiObject.getContext().testCase.name}")
		}
	}

	public void assertCroppedImageIsEmpty(String expectedTestDataDir) {
		for(FingerOutputAbstract fingerOutput in outputPayload.getFingerOutputList()) {
			_assertCroppedImageIsEmpty(fingerOutput.getCroppedImage())
		}
	}

	private void assertCroppedImageExists(String croppedImage) {
		if(croppedImage == null || croppedImage == "") {
			abendTest("CroppedImage", "has some data", "null or empty")
		}
	}
		
	private void _assertCroppedImageIsEmpty(String croppedImage) {
		if(croppedImage != null && croppedImage != "") {
			abendTest("CroppedImage", "null or empty", "has some data")
		}
	}
		
	public void assert10SlapSegmentationImage() {
		final int expectedElementSize = 10
		List<FingerOutputAbstract> fingerOutputList = outputPayload.getFingerOutputList()
		List<Integer> expectedPosList = [ 11, 40, 41, 42, 43, 12, 44, 45, 46, 47 ]
		assertEquals(fingerOutputList.size(), expectedElementSize, "finger-output element size")
		for(i in 0..9) {
			assertEquals(expectedPosList[i], fingerOutputList[i].getPos() as int, "finger-output pos value")
		}
		outputEvidence(testName, "There are 10 slap finger-output elements.")
	}
	
	public void assert10RollSegmentationImage() {
		final int expectedElementSize = 10
		List<FingerOutputAbstract> fingerOutputList = outputPayload.getFingerOutputList()
		List<Integer> expectedPosList = [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 ]
		assertEquals(fingerOutputList.size(), expectedElementSize, "finger-output element size")
		for(i in 0..9) {
			assertEquals(expectedPosList[i], fingerOutputList[i].getPos() as int, "finger-output pos value")
		}
		outputEvidence(testName, "There are 10 roll finger-output elements.")
	}


	public void assertSlapSegmentationImage(List<Integer> expectedPosList) {
		final int expectedElementSize = expectedPosList.size()
		List<FingerOutputAbstract> fingerOutputList = outputPayload.getFingerOutputList()
		assertEquals(fingerOutputList.size(), expectedElementSize, "finger-output element size")
		for(i in 0..expectedPosList.size()-1) {
			assertEquals(expectedPosList[i], fingerOutputList[i].getPos() as int, "finger-output pos value")
		}
		outputEvidence(testName, "There are correct finger-output elements.")
	}

	public void assert10Roll10SlapSegmentationImage() {
		final int expectedElementSize = 20
		List<FingerOutputAbstract> fingerOutputList = outputPayload.getFingerOutputList()
		assertEquals(fingerOutputList.size(), expectedElementSize, "finger-output element size")
		List<Integer> expectedPosList = generateRollAndSlapFullPosList()
		for(i in 0..19) {
			assertEquals(expectedPosList[i], fingerOutputList[i].getPos() as int, "finger-output pos value")
		}
		outputEvidence(testName, "There are 20 finger-output elements.")
	}

	public void assertRollSlapSegmentationImage(List<String> expectedPosList) {
		List<FingerOutputAbstract> fingerOutputList = outputPayload.getFingerOutputList()
		assertEquals(fingerOutputList.size(), expectedPosList.size(), "finger-output element size")
		for(i in 0..expectedPosList.size()-1) {
			assertEquals(fingerOutputList[i].getPos(), expectedPosList[i], "finger-output pos value")
		}
		outputEvidence(testName, "There are expected finger-output elements.")
	}

	private List<Integer> generateRollAndSlapFullPosList() {
		List<Integer> posList = []
		addPos(posList, 1, 11)
		addPos(posList, 40, 43)
		posList << 12
		addPos(posList, 44, 47)
		return posList
	}

	private void addPos(List<Integer> posList,  start, int end) {
		for(i in start..end) {
			posList << i
		}
	}
		
	public void assertExtractErrMessgApproximate(String extractJobResultXml, String expectedStartMessg) {
		def parser = new XmlParser().parseText(extractJobResultXml)
		assertEquals(parser.error.size(), 1, "error element size")
		String actualMessg = parser.error.text()
		assertEquals(actualMessg.indexOf(expectedStartMessg), 0, "errorMessage start index")
	}

	private void assertCroppedImageDiff(String labelName, String labelVal, FingerOutputAbstract fingerOutput, String expectedTestDataDir ) {
		String pos = fingerOutput.getPos()
		String wsqDataB64 = fingerOutput.getCroppedImage()
		EvidenceFileOutputor evidenceOutputor = new EvidenceFileOutputor(soapuiObject.getContext())
		File expectedTestData = new File(
			"${expectedTestDataDir}/${soapuiObject.getTestProjectName()}_${labelName}${labelVal}_pos${pos}.wsq")
		assertEquals(Encoder.binaryToB64(expectedTestData), wsqDataB64, "cropped-image")
	}
	
	public void assertLowResImageExistence(Map expectedExistenceMap){
		assertFingerOutputElementSizeOver0()
		for(FingerOutputAbstract fingerOutput in outputPayload.getFingerOutputList()) {
			String pos = fingerOutput.getPos()
			String lowResImageB64 = fingerOutput.getLowResImage()
			assertEquals(UString.hasValue(lowResImageB64), expectedExistenceMap.get(pos), "has low-res-image pos=$pos")
		}
	}

        public String assertCroppedImageExistence(Map expectedExistenceMap){
                for(FingerOutputAbstract fingerOutput in outputPayload.getFingerOutputList()) {
                        String pos = fingerOutput.getPos()
                        String cropImageB64 = fingerOutput.getCroppedImage()
                        assertEquals(UString.hasValue(cropImageB64), expectedExistenceMap.get(pos), "has cropeed-image pos=$pos")
                }
        }

	private assertFingerOutputElementSizeOver0() {
		assertSizeIsNotZero(outputPayload.getFingerOutputList().size(), "finger-output element")
	}
	
	private assertPalmOutputElementSizeOver0() {
		assertSizeIsNotZero(outputPayload.getPalmOutputList().size(), "palm-output element")
	}
	
	private assertSizeIsNotZero(int size, String name){
		if(size == 0){
			abendTest("$name size", "over 0", "0")
		}
	}
	
	public void assertPalmLowResImageExistence(Map expectedExistenceMap){
		assertPalmOutputElementSizeOver0()
		for(PalmOutput palmOutput in outputPayload.getPalmOutputList()) {
			String pos = palmOutput.getPos()
			String lowResImageB64 = palmOutput.getLowResImage()
			assertEquals(UString.hasValue(lowResImageB64), expectedExistenceMap.get(pos), "has low-res-image pos=$pos")
		}
	}
	
	public void assertImageSize(Map expectedImageSizeMap){
		assertFingerOutputElementSizeOver0()
		boolean isExistence = false
		for(FingerOutputAbstract fingerOutput in outputPayload.getFingerOutputList()) {
			String pos = fingerOutput.getPos()
			String lowResImageB64 = fingerOutput.getLowResImage()
			isExistence = UString.hasValue(lowResImageB64)
			if(isExistence){
				convertAndAssertImageSize(lowResImageB64, expectedImageSizeMap, pos)
			}
		}
	}

	public void assertNoLowResImageSize(Map expectedImageSizeMap){
		assertFingerOutputElementSizeOver0()
		boolean isExistence = false
		for(FingerOutputAbstract fingerOutput in outputPayload.getFingerOutputList()) {
			String pos = fingerOutput.getPos()
			String lowResImageB64 = fingerOutput.getLowResImage()
			isExistence = UString.hasValue(lowResImageB64)
			if(isExistence){
				convertAndAssertNoLowResImageSize(lowResImageB64, expectedImageSizeMap, pos)
			}
		}
	}

	public void assertPalmImageSize(Map expectedImageSizeMap){
		assertPalmOutputElementSizeOver0()
		boolean isExistence = false
		for(PalmOutput palmOutput in outputPayload.getPalmOutputList()) {
			String pos = palmOutput.getPos()
			String lowResImageB64 = palmOutput.getLowResImage()
			isExistence = UString.hasValue(lowResImageB64)
			if(isExistence){
				convertAndAssertImageSize(lowResImageB64, expectedImageSizeMap, pos)
			}
		}
	}

	private convertAndAssertNoLowResImageSize(String lowResImageB64, Map expectedImageSizeMap, String pos) {
		byte[] b = Encoder.stringToBinary(lowResImageB64)
		int height = convertHexTo10(b[20], b[21])
		int width = convertHexTo10(b[22], b[23])
		int expectedHeight = expectedImageSizeMap.get(pos)[1]
		int expectedWidth = expectedImageSizeMap.get(pos)[0]
		assertEquals(width, expectedWidth, "low-res-image width pos=$pos")
		assertEquals(height, expectedHeight, "low-res-image height pos=$pos")
	}
	
	private convertAndAssertImageSize(String lowResImageB64, Map expectedImageSizeMap, String pos) {
		byte[] b = Encoder.stringToBinary(lowResImageB64)
		int height = convertHexTo10(b[8], b[9])
		int width = convertHexTo10(b[10], b[11])
		int expectedHeight = expectedImageSizeMap.get(pos)[1]
		int expectedWidth = expectedImageSizeMap.get(pos)[0]
		assertEquals(width, expectedWidth, "low-res-image width pos=$pos")
		assertEquals(height, expectedHeight, "low-res-image height pos=$pos")
	}
	
	private int convertHexTo10(byte one, byte two){
		String hexVal = String.format("%02x%02x", one, two)
		return Integer.decode("0x${hexVal}")
	}
	

	public void outputWsqData(String labelName, String labelVal) {
		for(FingerOutputAbstract fingerOutput in outputPayload.getFingerOutputList()) {
			String pos = fingerOutput.getPos()
			String wsqDataB64 = fingerOutput.getCroppedImage()
			outputWsqAsBinary(wsqDataB64, labelName, labelVal, pos)
		}
	}
	
	private outputWsqAsBinary(String wsqDataB64, String labelName, String labelVal, String pos) {
		EvidenceFileOutputor evidenceOutputor = new EvidenceFileOutputor(soapuiObject.getContext())
		evidenceOutputor.outputResultData(
			soapuiObject.getTestProjectName() + "_${labelName}${labelVal}_pos${pos}.wsq", 
			Encoder.stringToBinary(wsqDataB64))
	}


	public void outputLowResImageAsWsq(String labelName, String labelVal) {
		for(FingerOutputAbstract fingerOutput in outputPayload.getFingerOutputList()) {
			String pos = fingerOutput.getPos()
			String wsqDataB64 = fingerOutput.getLowResImage()
			if(wsqDataB64 == null || wsqDataB64.isEmpty()){
				continue
			}else{
				convertAndOutputAsBinary(wsqDataB64, labelName, labelVal, pos)
			}
		}
	}

	public void outputPalmLowResImageAsWsq(String labelName, String labelVal) {
		for(PalmOutput palmOutput in outputPayload.getPalmOutputList()) {
			String pos = palmOutput.getPos()
			String wsqDataB64 = palmOutput.getLowResImage()
			if(wsqDataB64 == null || wsqDataB64.isEmpty()){
				continue
			}else{
				convertAndOutputAsBinary(wsqDataB64, labelName, labelVal, pos)
			}
		}
	}
	
	public assertDumpRawDataDiff(String subDir){
		MatchUnit mu = new MatchUnit(soapuiObject.getContext())
		EvidenceDirCreator eviDirCreator = new EvidenceDirCreator(soapuiObject.getContext(), subDir)
		eviDirCreator.mkdir()
		eviDirCreator.cleanUnderDir()
		mu.scpCropRawData(eviDirCreator.getPath())
		File expectedDataDir = soapuiObject.getExpectedEvidenceDataDir(subDir)
		assertMuDumpRawsDataDiff(expectedDataDir, eviDirCreator.getDir())
	}
	
	public assertDumpRawDataDiffAfterAim40(String subDir){
		MatchUnit mu = new MatchUnit(soapuiObject.getContext())
		EvidenceDirCreator eviDirCreator = new EvidenceDirCreator(soapuiObject.getContext(), subDir)
		eviDirCreator.mkdir()
		eviDirCreator.cleanUnderDir()
		mu.scpCropRawDataAfterAim40(eviDirCreator.getPath())
		File expectedDataDir = soapuiObject.getExpectedEvidenceDataDir(subDir)
		assertMuDumpRawsDataDiff(expectedDataDir, eviDirCreator.getDir())
	}
	
	public assertTemplateDiff(String fileName, def binary){
		EvidenceDirCreator eviDirCreator = new EvidenceDirCreator(soapuiObject.getContext())
		eviDirCreator.mkdir()
		EvidenceFileOutputor evidenceOutputor = new EvidenceFileOutputor(soapuiObject.getContext())
		evidenceOutputor.outputResultDataAsBinary(fileName, binary)
		File expectedDataDir = soapuiObject.getExpectedEvidenceDataDir()
		File expFile =  new File(expectedDataDir.toString() + "/" + fileName)
		File actFile =  new File(eviDirCreator.getDir().toString() + "/" + fileName)
		assertEquals(expFile.getText(), actFile.getText(), expFile.getPath(), expFile.getPath())
	}

	public assertTemplateDiff(Map fileMap){
		EvidenceDirCreator eviDirCreator = new EvidenceDirCreator(soapuiObject.getContext())
		eviDirCreator.mkdir()
		eviDirCreator.cleanUnderDir()
		EvidenceFileOutputor evidenceOutputor = new EvidenceFileOutputor(soapuiObject.getContext())
		for( i in fileMap){
			evidenceOutputor.outputResultDataAsBinary(i.getKey(), i.getValue())
		}
		File expectedDataDir = soapuiObject.getExpectedEvidenceDataDir()
		assertMuDumpRawsDataDiff(expectedDataDir, eviDirCreator.getDir())
	}

	public assertTemplateDiffExist(encryptedTemplate, templateAssertFlag){
		if ( encryptedTemplate == "true" && templateAssertFlag == "true" ){
			EvidenceDirCreator eviDirCreator = new EvidenceDirCreator(soapuiObject.getContext())
			File expectedDataDir = soapuiObject.getExpectedEvidenceDataDir()
			assertMuDumpRawsDataDiffExist(expectedDataDir, eviDirCreator.getDir())
		}
    }
	
	public void assertCroppedImgDiffAfterAim40(String labelName, int expectedFinOutputSize) {
		assertEquals(outputPayload.getFingerOutputList().size(), expectedFinOutputSize, "finger-output size")
		File testCaseResultDataDir = soapuiObject.getExpectedEvidenceDataDir()
		String projectName = soapuiObject.getTestProjectName()
		for(FingerOutputAbstract fingerOutput in outputPayload.getFingerOutputList()) {
			String pos = fingerOutput.getPos()
			File expectedWsqFile = new File(
				testCaseResultDataDir.getPath() + "/" + soapuiObject.getTestProjectName() + "_"	+ "${labelName}_pos${pos}.wsq")
			assertEquals(fingerOutput.getCroppedImage(), Encoder.binaryToB64(expectedWsqFile), testName)
		}
		outputEvidence(testName, "cropped-images are same to last test.")
	}

	public void assertCroppedImgDiffAfterAim40(String labelName) {
		assertCroppedImgDiffAfterAim40(labelName, 20)
	}

	public void assertImageAnalysisElement(String callbackXml, String imageAnalysisFrag){
		String imageAnalysis = "image-analysis"
		if (imageAnalysisFrag == "true" && !callbackXml.contains(imageAnalysis)){
			abendTest( imageAnalysis, "exist", "no exist")
		}else if (imageAnalysisFrag == "false" && callbackXml.contains(imageAnalysis)){
			abendTest( imageAnalysis, "no exist", "exist")
		}
		outputEvidence(testName, "ImageAnalysis is correct operation" )
	}

	private assertMuDumpRawsDataDiff(File expectedDataDir, File actualDataDir) {
		Map expectedDataMap = createDataMap(expectedDataDir)
		Map actualDataMap = createDataMap(actualDataDir)
		assertEquals(actualDataMap.size(), expectedDataMap.size(), testName)
		assertMuDumpRawDataDiff(expectedDataMap, actualDataMap)
	}

	private assertMuDumpRawDataDiff(Map expectedDataMap, Map actualDataMap) {
		for(key in expectedDataMap.keySet()){
			File expectedData= expectedDataMap.get(key)
			File actualData= actualDataMap.get(key)
			assertEquals(actualData.getText(), expectedData.getText(), actualData.getPath(), expectedData.getPath())
		}
	}

	private assertMuDumpRawsDataDiffExist(File expectedDataDir, File actualDataDir) {
		Map expectedDataMap = _createDataMap(expectedDataDir)
		Map actualDataMap = _createDataMap(actualDataDir)
		assertEquals(actualDataMap.size(), expectedDataMap.size(), testName)
		assertMuDumpRawDataDiffExist(expectedDataMap, actualDataMap)
	}

	private assertMuDumpRawDataDiffExist(Map expectedDataMap, Map actualDataMap) {
		for(key in expectedDataMap.keySet()){
			File expectedData= expectedDataMap.get(key)
			File actualData= actualDataMap.get(key)
			assertNotEquals(actualData.getText(), expectedData.getText(), actualData.getPath(), expectedData.getPath())
		}
	}


	private Map createDataMap(File dataDir) {
		Map dataMap = new HashMap()
		dataDir.eachFile{
			String dataPath = it as String
			String dataName = new File(dataPath).getName()
			int underScore = dataName.indexOf("_")
			String dataNameWithoutJobId = dataName.substring(underScore)
			dataMap.put(dataNameWithoutJobId, new File(dataPath))
		}
		return dataMap
	}
	
	private Map _createDataMap(File dataDir) {
		Map dataMap = new HashMap()
		dataDir.eachFile{
			String dataPath = it as String
			String dataName = new File(dataPath).getName()
			//int underScore = dataName.indexOf("_")
			//String dataNameWithoutJobId = dataName.substring(underScore)
			dataMap.put(dataName, new File(dataPath))
		}
		return dataMap
	}


	private convertAndOutputAsBinary(String wsqDataB64, String labelName, String labelVal, String pos) {
		EvidenceFileOutputor evidenceOutputor = new EvidenceFileOutputor(soapuiObject.getContext())
		def wsqData = Encoder.stringToBinary(wsqDataB64)
		evidenceOutputor.setOtherFile("${labelName}${labelVal}_pos${pos}.wsq")
		evidenceOutputor.outputOtherFile(wsqData)
	}

	private void assertFisTypeOfMinData(List<MinutiaDataAbstract> minutiaDataList, String expectedFisType) {
		for(MinutiaDataAbstract minutiaData in minutiaDataList) {
			assertEquals(minutiaData.getFisType(), expectedFisType, "FIS_TYPE")
		}
	}
	
	private void assertFisTypeOfMinDataList(List<MinutiaDataAbstract> minutiaDataList, List<String> expectedFisTypeList, int finIndex) {
        assertEquals(minutiaDataList.size(), expectedFisTypeList.size(), "FisType in MinutiaData list size")
		for( i in 0..minutiaDataList.size() -1) {
			assertEquals(minutiaDataList[i].getFisType(), expectedFisTypeList[i], "FIS_TYPE fingerIndex=${finIndex} minDataIndex=${i}")
		}
	}
	
	private void assertDbTypeOfMinData(List<MinutiaDataAbstract> minutiaDataList, String expectedDbType) {
		for(MinutiaDataAbstract minutiaData in minutiaDataList) {
			assertEquals(minutiaData.getDbType(), expectedDbType, "DB_TYPE")
		}
	}
	
	private void assertDbTypeOfMinData(List<MinutiaDataAbstract> minutiaDataList, List<String> expectedDbTypeList) {
		for(int i = 0; i < minutiaDataList.size(); i++) {
			assertEquals(minutiaDataList[i].getDbType(), expectedDbTypeList[i], "DB_TYPE")
		}
	}

	private void assertFormatOfMinData(List<MinutiaDataAbstract> minutiaDataList, String expectedFormat) {
		for(MinutiaDataAbstract minutiaData in minutiaDataList) {
			assertEquals(minutiaData.getFormat(), expectedFormat, "FORMAT")
		}
	}
	
	private void assertFormatOfMinData(List<MinutiaDataAbstract> minutiaDataList, List<String> expectedFormatList) {
		for(int i = 0; i < minutiaDataList.size(); i++) {
			assertEquals(minutiaDataList[i].getFormat(), expectedFormatList[i], "FORMAT")
		}
	}

	private void assertMinutiaTypeOfMinData(List<MinutiaDataAbstract> minutiaDataList, String expectedMinutiaType) {
		for(MinutiaDataAbstract minutiaData in minutiaDataList) {
			assertEquals(minutiaData.getMinutiaType(), expectedMinutiaType, "MINUTIA_TYPE")
		}
	}

	private void assertMinutiaTypeOfMinData(List<MinutiaDataAbstract> minutiaDataList, List<String> expectedMinutiaTypeList) {
		for(int i = 0; i < minutiaDataList.size(); i++) {
			assertEquals(minutiaDataList[i].getMinutiaType(), expectedMinutiaTypeList[i], "MINUTIA_TYPE")
		}
	}

	private void assertFisTypeOfFisData(List<FisDataAbstract> fisDataList, String expectedFisType) {
		for(FisDataAbstract fisData in fisDataList) {
			assertEquals(fisData.getFisType(), expectedFisType, "FIS_TYPE")
		}
	}
				
	private void assertFisTypeOfFisDataList(List<FisDataAbstract> fisDataList, List<String> expectedFisTypeList, int finIndex) {
        assertEquals(fisDataList.size(), expectedFisTypeList.size(), "FisType in FisData list size")
		for( i in 0..fisDataList.size() -1) {
			assertEquals(fisDataList[i].getFisType(), expectedFisTypeList[i], "FIS_TYPE fingerIndex=${finIndex} fisDataIndex=${i}")
		}
	}

	String outputEvidence(testName, content){
		EvidenceFileOutputor evidenceFileOutputor = new EvidenceFileOutputor(soapuiObject.getContext())
		evidenceFileOutputor.outputTrueMess("${testName} --> ${content}")
	}

	public void assertXsdSchema(String testName) {
		AssertAimXsdSchema assertAimXsd = new AssertAimXsdSchema(
						outputPayload.getOutputPayloadXmlString(), testName, soapuiObject.getContext())
		assertAimXsd.assertAimXsd()
	}

	public void assertExtractXsdSchema(String testName) {
		AssertAimXsdSchema assertAimXsd = new AssertAimXsdSchema(
						outputPayload.getOutputPayloadXmlString(), testName, soapuiObject.getContext())
		assertAimXsd.assertExtractXsdSchema()
	}

	protected void assertEquals(actual, expected, String testPropName) {
		if(actual != expected) {
			abendTest(testPropName, expected, actual)
		}
	}

	protected void assertEquals(actual, expected, String actualKey, String expectedKey) {
		if(actual != expected) {
			abendTest(expectedKey, actualKey)
		}
	}

	protected void assertNotEquals(actual, expected, String testPropName) {
		if(actual == expected) {
			abendTest("not diffrent",testPropName, expected, actual)
		}
	}

	protected void assertNotEquals(actual, expected, String actualKey, String expectedKey) {
		if(actual == expected) {
			abendTest("not diffrent",expectedKey, actualKey)
		}
	}

	private void abendTest(def testPropName, def expectedMessg, def actualValue) {
		String errMessg = mkErrMessg(testPropName, expectedMessg, actualValue)
		AbendProcessor abendProcessor = new AbendProcessor(soapuiObject.getContext())
		abendProcessor.abendTest(testName, errMessg)
	}
	
	private void abendTest(def expectedMessg, def actualValue) {
		String errMessg = mkDiffErrMessg(expectedMessg, actualValue)
		AbendProcessor abendProcessor = new AbendProcessor(soapuiObject.getContext())
		abendProcessor.abendTest(testName, errMessg)
	}
	
	private String mkErrMessg(name, expected, actual){
		return new MessageCreator().mkValueErrMessg(name, expected, actual)
	}

	private String mkDiffErrMessg(expected, actual){
		return new MessageCreator().mkDiffErrMessg(expected, actual)
	}
}
