package test.degrade.assertion.xml

import test.common.format.extraction.payload.impl.*
import test.degrade.assertion.xml.*
import test.degrade.util.*

class AssertAimXsdSchema{

	int extInfoMode = 0
	boolean isSkipExtractXsdAssertion = false
	String callbackXml
	String testName
	SoapuiObject soapuiObject

	AssertAimXsdSchema() {}

	AssertAimXsdSchema(String callbackXml, String testName, context, int extInfoMode) {
		this(callbackXml, testName, context)
		this.extInfoMode = extInfoMode
	} 

	AssertAimXsdSchema(String callbackXml, String testName, context) {
		this.callbackXml = callbackXml
		this.testName = testName
		this.soapuiObject = new SoapuiObject(context)
	} 

	public void assertAimXsd() {
		assertClientApiXsdSchema()
		if(extInfoMode != 1) {
			assertExtractXsdSchema()
		}
	}

	public void assertClientApiXsdSchema(){
		def assertAimXml = new AssertAimXml(soapuiObject.getContext(), testName, callbackXml)
		assertAimXml.assertXsdSchem()
	}
	
	public void assertExtractXsdSchema(){
		if(isSkipExtractXsdAssertion){
			return
		}
		def assertAimXml = new AssertAimXml(soapuiObject.getContext(), testName, OutputPayloadImpl.parseExtOutputsXmlWithNs(callbackXml))
		assertAimXml.assertExtractionXsdSchem()
	}
}

