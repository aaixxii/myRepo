package test.degrade.assertion.exception

import common.xml.*
import common.util.*
import common.callback.*
import test.common.xml.*
import test.common.constants.aim.*
import test.degrade.util.*
import test.degrade.evidence.*
import test.degrade.properties.*
import test.degrade.management.*
import test.degrade.assertion.xml.*

class AssertSoapException extends AssertExceptionCase {

	def AssertSoapException(xmlString, context){
		super(xmlString, context)
	}

	def assertSearchExceptionOccurrence(testPatternName, expectedMessg){
		def faultResult = checkFaultElementSize()
		if(faultResult.result == false){
			abendTest(testPatternName)
		}
		outputEvidenceFile(getAIMFaultDescription())
	}

	def checkFaultElementSize(){
		if(!isExistsFaultElement()){
			def waitCallbacker = new WaitCallbacker(globalProperties.getCallbackPort())
			waitCallbacker.waitCallback()
			return new ResultMapper(false, 0)
		}
		return new ResultMapper(true, 1)
	}

	def boolean isExistsFaultElement(){
		Map expectedXpathMap = getExpctedFaultElementCountXpathMap()
		return isEqualXpathMap(xmlString, expectedXpathMap)
	}
		
	def Map getExpctedFaultElementCountXpathMap(){
		SoapExceptionXpathMapper exceptionXpathMapper = new SoapExceptionXpathMapper()
		return exceptionXpathMapper.createFaultElementCountXpathMap()
	}

	// Over ride 
    def getAIMFaultDescription(){
        return XMLUtil.getElementValue("//faultstring", xmlString)
    }

}

