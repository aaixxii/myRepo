package test.degrade.assertion.extract

import test.common.format.extraction.payload.abst.*

class AssertLatentExtraction extends AssertExtraction {

    AssertLatentExtraction(context, String testName){
		super(context, testName)
	}

    AssertLatentExtraction(OutputPayloadAbstract outputPayload, context) {
		super(outputPayload, context)
    }

    AssertLatentExtraction(OutputPayloadAbstract outputPayload, context, String testName) {
		super(outputPayload, context, testName)
    }

	public void assertLatentFingerOutput() {
        final int expectedElementSize = 1
        List<FingerOutputAbstract> fingerOutputList = outputPayload.getFingerOutputList()
        assertEquals(fingerOutputList.size(), expectedElementSize, "finger-output element size")
		assertEquals(fingerOutputList[0].getPos(), null, "finger-output attribute pos")
		outputEvidence(testName, "There is 1 slap finger-output elements and no pos attribute")
    }
		
}
