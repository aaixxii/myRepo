package main.groovy.test.degrade.assertion.xml

class CheckIdXpathMapper {
	CheckIdXpathMapper(){
	}


	def createCheckResultsXpathMap(externalId,externalIdCount,expectedCount){
		def xpathValueMap = [
					"count(//ns3:check-results[ @externalId='${externalId}']":"${expectedCount}",
					"count(//ns3:check-results)":"${externalIdCount}"
				]
		return xpathValueMap
	}

	def createCheckResultsXpathMap(externalId, externalIdCount, eventIdCount, expectedCount ){
		def xpathValueMap = [
					"count(//ns3:check-results[ @externalId='${externalId}']":"${expectedCount}",
					"count(//ns3:check-results)":"${externalIdCount}",
					"count(//check-result)": "${eventIdCount}"
				]
		return xpathValueMap
	}

	def createCheckResultsXpathMap(externalId, externalIdCount, eventIdCount,containerIdCount,expectedCount){
		def xpathValueMap = [
					"count(//ns3:check-results[ @externalId='${externalId}'])":"${expectedCount}",
					"count(//ns3:check-results)":"${externalIdCount}",
					"count(//check-result)":"${eventIdCount}",
					"count(//container-result)":"${containerIdCount}"
				]
		return xpathValueMap
	}




	def createCheckResultXpathMap(eventId,
	containerIdList, validList, corruptedList,
	existCount){

		def checkResultXpath

		if(containerIdList.size == 1){
			checkResultXpath = createCheckResultXpath(eventId,
					containerIdList[0], validList[0], corruptedList[0])
		}else if(containerIdList.size == 2){
			checkResultXpath = createCheckResultXpath(eventId,
					containerIdList[0], validList[0], corruptedList[0],
					containerIdList[1], validList[1], corruptedList[1])
		}else if(containerIdList.size == 3){
			checkResultXpath = createCheckResultXpath(eventId,
					containerIdList[0], validList[0], corruptedList[0],
					containerIdList[1], validList[1], corruptedList[1],
					containerIdList[2], validList[2], corruptedList[2])
		}else if(containerIdList.size == 4){
			checkResultXpath = createCheckResultXpath(eventId,
					containerIdList[0], validList[0], corruptedList[0],
					containerIdList[1], validList[1], corruptedList[1],
					containerIdList[2], validList[2], corruptedList[2],
					containerIdList[3], validList[3], corruptedList[3])
		}else if(containerIdList.size == 5){
			checkResultXpath = createCheckResultXpath(eventId,
					containerIdList[0], validList[0], corruptedList[0],
					containerIdList[1], validList[1], corruptedList[1],
					containerIdList[2], validList[2], corruptedList[2],
					containerIdList[3], validList[3], corruptedList[3],
					containerIdList[4], validList[4], corruptedList[4])
		}else if(containerIdList.size == 10){
			checkResultXpath = createCheckResultXpath(eventId,
					containerIdList[0], validList[0], corruptedList[0],
					containerIdList[1], validList[1], corruptedList[1],
					containerIdList[2], validList[2], corruptedList[2],
					containerIdList[3], validList[3], corruptedList[3],
					containerIdList[4], validList[4], corruptedList[4],
					containerIdList[5], validList[5], corruptedList[5],
					containerIdList[6], validList[6], corruptedList[6],
					containerIdList[7], validList[7], corruptedList[7],
					containerIdList[8], validList[8], corruptedList[8],
					containerIdList[9], validList[9], corruptedList[9])
		}

		def xpathValueMap = [
					"${checkResultXpath}": "${existCount}"]

		return xpathValueMap
	}


	/*
	 * create 1bins
	 */

	def createCheckResultXpath(eventId,
	containerId1, valid1, invalid1){

		return """count(//check-result[
				@eventId='${eventId}'
					and container-result[1][ @containerId='${containerId1}' and @num-of-valid='${valid1}' and @num-of-corrupted='${invalid1}']
				])"""
	}

	/*
	 * create 2bins
	 */

	def createCheckResultXpath(eventId,
	containerId1, valid1, invalid1,
	containerId2, valid2, invalid2){

		return """count(//check-result[
				@eventId='${eventId}'
					and container-result[1][ @containerId='${containerId1}' and @num-of-valid='${valid1}' and @num-of-corrupted='${invalid1}']
					and container-result[2][ @containerId='${containerId2}' and @num-of-valid='${valid2}' and @num-of-corrupted='${invalid2}']
				])"""
	}

	/*
	 * create 3bins
	 */


	def createCheckResultXpath(eventId,
	containerId1, valid1, invalid1,
	containerId2, valid2, invalid2,
	containerId3, valid3, invalid3){

		return """count(//check-result[
				@eventId='${eventId}'
					and container-result[1][ @containerId='${containerId1}' and @num-of-valid='${valid1}' and @num-of-corrupted='${invalid1}']
					and container-result[2][ @containerId='${containerId2}' and @num-of-valid='${valid2}' and @num-of-corrupted='${invalid2}']
					and container-result[3][ @containerId='${containerId3}' and @num-of-valid='${valid3}' and @num-of-corrupted='${invalid3}']
				])"""
	}

	/*
	 * create 4bins
	 */


	def createCheckResultXpath(eventId,
	containerId1, valid1, invalid1,
	containerId2, valid2, invalid2,
	containerId3, valid3, invalid3,
	containerId4, valid4, invalid4){

		return """count(//check-result[
				@eventId='${eventId}'
					and container-result[1][ @containerId='${containerId1}' and @num-of-valid='${valid1}' and @num-of-corrupted='${invalid1}']
					and container-result[2][ @containerId='${containerId2}' and @num-of-valid='${valid2}' and @num-of-corrupted='${invalid2}']
					and container-result[3][ @containerId='${containerId3}' and @num-of-valid='${valid3}' and @num-of-corrupted='${invalid3}']
					and container-result[4][ @containerId='${containerId4}' and @num-of-valid='${valid4}' and @num-of-corrupted='${invalid4}']
				])"""
	}


	/*
	 * create 5bins
	 */


	def createCheckResultXpath(eventId,
	containerId1, valid1, invalid1,
	containerId2, valid2, invalid2,
	containerId3, valid3, invalid3,
	containerId4, valid4, invalid4,
	containerId5, valid5, invalid5){

		return """count(//check-result[
				@eventId='${eventId}'
					and container-result[1][ @containerId='${containerId1}' and @num-of-valid='${valid1}' and @num-of-corrupted='${invalid1}']
					and container-result[2][ @containerId='${containerId2}' and @num-of-valid='${valid2}' and @num-of-corrupted='${invalid2}']
					and container-result[3][ @containerId='${containerId3}' and @num-of-valid='${valid3}' and @num-of-corrupted='${invalid3}']
					and container-result[4][ @containerId='${containerId4}' and @num-of-valid='${valid4}' and @num-of-corrupted='${invalid4}']
					and container-result[5][ @containerId='${containerId5}' and @num-of-valid='${valid5}' and @num-of-corrupted='${invalid5}']
				])"""
	}

	/*
	 * create 10bins
	 */


	def createCheckResultXpath(eventId,
	containerId1, valid1, invalid1,
	containerId2, valid2, invalid2,
	containerId3, valid3, invalid3,
	containerId4, valid4, invalid4,
	containerId5, valid5, invalid5,
	containerId6, valid6, invalid6,
	containerId7, valid7, invalid7,
	containerId8, valid8, invalid8,
	containerId9, valid9, invalid9,
	containerId10, valid10, invalid10){

		return """count(//check-result[
				@eventId='${eventId}'
					and container-result[1][ @containerId='${containerId1}' and @num-of-valid='${valid1}' and @num-of-corrupted='${invalid1}']
					and container-result[2][ @containerId='${containerId2}' and @num-of-valid='${valid2}' and @num-of-corrupted='${invalid2}']
					and container-result[3][ @containerId='${containerId3}' and @num-of-valid='${valid3}' and @num-of-corrupted='${invalid3}']
					and container-result[4][ @containerId='${containerId4}' and @num-of-valid='${valid4}' and @num-of-corrupted='${invalid4}']
					and container-result[5][ @containerId='${containerId5}' and @num-of-valid='${valid5}' and @num-of-corrupted='${invalid5}']
					and container-result[6][ @containerId='${containerId6}' and @num-of-valid='${valid6}' and @num-of-corrupted='${invalid6}']
					and container-result[7][ @containerId='${containerId7}' and @num-of-valid='${valid7}' and @num-of-corrupted='${invalid7}']
					and container-result[8][ @containerId='${containerId8}' and @num-of-valid='${valid8}' and @num-of-corrupted='${invalid8}']
					and container-result[9][ @containerId='${containerId9}' and @num-of-valid='${valid9}' and @num-of-corrupted='${invalid9}']
					and container-result[10][ @containerId='${containerId10}' and @num-of-valid='${valid10}' and @num-of-corrupted='${invalid10}']
				])"""
	}
}

