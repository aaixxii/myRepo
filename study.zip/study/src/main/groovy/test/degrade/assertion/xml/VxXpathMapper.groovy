package test.degrade.assertion.xml

class VxXpathMapper extends XpathMapper {
	
	VxXpathMapper(){}

	def createVerifyFingersResultXpathMap(externalId, fusionScore, compositeScore, positionList, scores, modal) {
		String individualScoreXmlParts = createIndividualScoreXmlParts(positionList, scores)
        String resultXpath =  """count(//candidateResultList[
                                        externalId='${externalId}'
                                        and fusionScore='${fusionScore}'
                                        and modalScoreList[
                                                compositeScore='${compositeScore}'
												${individualScoreXmlParts}
                                                and modal='${modal}'
                                                ]
                                        ])"""
		def xpathValueMap = ["${resultXpath}": "1"]
		return xpathValueMap
	}


	def String createIndividualScoreXmlParts(List positionList, List scoreList) {
		StringBuilder sb = new StringBuilder()
		for(int i = 0; i < positionList.size(); i++){
			sb.append("""
				and individualScoreList[${i+1}][
					position='${positionList[i]}'
					and score='${scoreList[i]}'
				]""")
		}
		return sb.toString()
	}

	def createVerifyFingersResultXpathMap(externalId, fusionScore, compositeScore, searchPositionList, filePositionList, individualScoreList, crossMatchScoreList, modal) {
		String individualScoreXmlParts = createIndividualScoreXmlParts(searchPositionList, filePositionList, individualScoreList, crossMatchScoreList)
        String resultXpath =  """count(//candidateResultList[
                                        externalId='${externalId}'
                                        and fusionScore='${fusionScore}'
                                        and modalScoreList[
                                                compositeScore='${compositeScore}'
												${individualScoreXmlParts}
                                                and modal='${modal}'
                                                ]
                                        ])"""
		def xpathValueMap = ["${resultXpath}": "1"]
		return xpathValueMap
	}


	def String createIndividualScoreXmlParts(List positionList, List filePositionList, List scoreList, List crossMatchScoreList) {
		StringBuilder sb = new StringBuilder()
		for(int i = 0; i < positionList.size(); i++){
			sb.append("""
				and individualScoreList[${i+1}][
					position='${positionList[i]}'
					and score='${scoreList[i]}'
					and fingerInquiryResult[1][""")

			for(int j = 0; j < filePositionList.size(); j++){
				if( ! j.equals(0) ){
					 sb.append("""
						and """)
				}
				sb.append("""
						crossMatchingResultList[${j+1}][
							filePosition='${filePositionList[j]}'
							and score='${crossMatchScoreList[i][j]}'
						]""")
			}

			sb.append("""
					]
				]""")
		}
		return sb.toString()
	}
}

