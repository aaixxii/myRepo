package test.degrade.assertion.xml

import common.xml.*
import common.util.*
import test.degrade.util.*
import test.degrade.properties.*

class AssertXmlDiff{
		def globalProperties
		SoapuiObject soapuiObject
		def id = null

	AssertXmlDiff(context){
		this.globalProperties = new GlobalProperties(context)
		this.soapuiObject = new SoapuiObject(context)
	}

	AssertXmlDiff(context, id ){
		this.globalProperties = new GlobalProperties(context)
		this.soapuiObject = new SoapuiObject(context)
		this.id = id
	}

	def execAssertion(expectedDiffSize){
		def diffs = getXmlDiffResults()
		if(diffs.size() > expectedDiffSize){
			return false
		}
		return checkDiffKey(diffs)
	}

	def isEqualOrUnderXmlDiffCnt(String actualXml, String expectedXml, int expectedDiffSize){
		def diffs = getXmlDiffResults(actualXml, expectedXml)
		if(diffs.size() > expectedDiffSize){
			return false
		}
		return checkDiffKey(diffs)
	}

	def execAssertWithoutKeyedBinary(expectedDiffSize){
		def diffs = getXmlDiffWithoutKeyedBinaryResults()
		if(diffs.size() > expectedDiffSize){
			return false
		}
		return checkDiffKey(diffs)
	}

	def checkDiffKey(diffs){
		def expectedKey = "jobId"
		for(diff in diffs){
			def nodeDetail = diff.getControlNodeDetail()
			def node = nodeDetail.getNode()
			if(node.getNodeName() != expectedKey){
				return false
			}
		}
		return true
	}
		
	def getDiffResult(){
		def diffs = getXmlDiffResults()
		def diffContent = "xml diff error. "
		def expectedKey = "jobId"
		def i = 1
		for(diff in diffs){
			if(i >= 2){
				diffContent += ",\n               "
			}
			def nodeDetail = diff.getControlNodeDetail()
			def node = nodeDetail.getNode()
			if(node == null){
				diffContent += "Node is null"
				i++
			}else if(node.getNodeName() != expectedKey){
				def key = node.getNodeName()
				def val = node.getNodeValue()
				def path = nodeDetail.getXpathLocation()
				println val.getClass()
				if(val == null){
					val = "NULL"
				}else if(50 < val.length()){
					val = "<LARGE_STRING>"
				}
				diffContent += "key=${key}, value=${val}, path=${path}"
				i++
			}
		}
		return diffContent
	}
	
	def getXmlDiffResults(){
		def expectedXml = getExpectedXmlFile()
		def actualXml = getActualXmlFile()	
		return new XMLDiff().diff(actualXml.getText('UTF-8'), expectedXml.getText('UTF-8'))
//		return new XMLDiff().diff(expectedXml.getText('UTF-8'), actualXml.getText('UTF-8'))
	}

	def getXmlDiffResults(String actualXml, String expectedXml){
		return new XMLDiff().diff(expectedXml, actualXml)
	}

	def getXmlDiffWithoutKeyedBinaryResults(){
		def expectedXml = trimKeyedBinary(getExpectedXmlFile()).replaceAll("> +<", "><")
		def actualXml   = trimKeyedBinary(getActualXmlFile()).replaceAll("> +<", "><")

		return new XMLDiff().diff(expectedXml, actualXml)
	}

	def getExpectedXmlFile(){
		if(id == null){
			return soapuiObject.getLatestEvidenceXmlFile()
		}else{
			return soapuiObject.getLatestEvidenceXmlFile(id)
		}

	}

	def trimKeyedBinary(file){
		return new TextFormatter().trimString(file, "<keyed-binary>", "</keyed-binary>")
	}

	def getActualXmlFile(){
		if(id == null){
			return soapuiObject.getEvidenceXmlFile()
		}else{
			return soapuiObject.getEvidenceXmlFile(id)
		}
	}
}

