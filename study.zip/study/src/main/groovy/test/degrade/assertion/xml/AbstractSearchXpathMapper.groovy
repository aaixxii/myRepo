package test.degrade.assertion.xml

import static test.common.constants.aim.AIMWord.*

abstract class AbstractSearchXpathMapper extends XpathMapper {
	
	public AbstractSearchXpathMapper(){}

	public AbstractSearchXpathMapper(context){
		super(context)
	}

	public Map createCandXpathMap(List candInfo){
		StringBuilder sb = new StringBuilder()
		def extId = candInfo[0]
		def fScore = candInfo[1]
		def isHit = candInfo[2]
		def candTmpList = candInfo[3]
		def hitCondition
		if(isHit) {
			hitCondition = "@hit='true'"
		} else {
			hitCondition = "@hit='false'"
		}
		sb.append( """
				count(//candidate[
					externalId='${extId}'
					and ${hitCondition}
					and fusion-score='${fScore}'""")
		sb.append(makeCandTmpListCondition(candTmpList))
		sb.append("""
				])""")
		def expectedCondition = sb.toString()
		println expectedCondition
		return [ "${expectedCondition}":"1", ]
	}

	private String makeCandTmpListCondition(List candTmpList) {
		StringBuilder sb = new StringBuilder()
		int i = 1
		for(candTmp in candTmpList){
			sb.append(makeCandTmpCondition(candTmp, i))
			i++
		}
		return sb.toString()
	}
	
	private String makeCandTmpCondition(candTmp, int index){
		StringBuilder sb = new StringBuilder()
		def contId = candTmp[0]
		def eventId = candTmp[1]
		def sReqIndex = candTmp[2]
		def cScore = candTmp[3]
		def iScoreList = candTmp[4]
		sb.append("""
					and candidate-template[
						containerId='${contId}'
						and eventId='${eventId}'
						and searchRequestIndex='${sReqIndex}'
						and not(fusionWeight)
						and composite-score='${cScore}'""")
		def i = 1
		if(isCmlTim(contId)){
			for (iScore in iScoreList){
				sb.append(makeCmlIScoreCondition(iScore, i))
				i++
			}
		}else{
			for (iScore in iScoreList){
				sb.append(makeIScoreCondition(iScore, i))
				i++
			}
		}
		sb.append("					]")
		return sb.toString()
	}
		
	protected String makeCmlIScoreCondition(List iScore, int index){
		//Override only TIM function
	}

	protected abstract String makeIScoreCondition(List iScore, int index)
}

