package test.degrade.assertion.sync

import static test.degrade.constants.soapui.SoapuiDefines.*
import test.degrade.assertion.AssertCountChecker
import test.common.message.MessageCreator
import test.common.message.ConvertErrorMessageCreator
import test.degrade.assertion.exception.AssertExceptionCase


import test.degrade.evidence.*
import test.degrade.util.SoapuiObject

class AimSyncResponseAssertor{
    private static final String SYNC = "sync"
    private static final int CONVERTOR_ERR_CODE = 814000313
    int testId
    int expErrCode
    String expErrMessg
    String titleForEvidenceFile
    String testSuiteName
    String testCaseName
    String testStepName
    SoapuiObject soapuiObj
    boolean looseAssertionMode = false

    public AimSyncResponseAssertor(context) {
        this.soapuiObj = new SoapuiObject(context)
        this.testSuiteName = COMMON_TEST_SUITE_NAME
    }

    public void assertMultiScopeIdFaultResponse() {
        expErrMessg = new ConvertErrorMessageCreator().createNumberOfAfisGroupIdErrMessg()
        assertConvertErrResponse()
    }

    public void assertInvalidRegistKeyFaultResponse(String input) {
        expErrMessg = new ConvertErrorMessageCreator().createInvalidRegistKeyErrMessg(input)
        assertConvertErrResponse()
    }

    public void assertNonExitConIdFaultResponse(def input) {
        expErrMessg = new ConvertErrorMessageCreator().createCouldNotGetValueErrMessg(input as String)
        assertConvertErrResponse()
    }

    public void assertNonExistKeyFaultResponse(def input) {
        expErrMessg = new ConvertErrorMessageCreator().createCouldNotGetValueErrMessg(input as String)
        assertConvertErrResponse()
    }

    public void assertDuplicateConIdsFaultResponse() {
        expErrMessg = new ConvertErrorMessageCreator().createDuplicateConIdsErrMessg()
        assertConvertErrResponse()
    }

    public void assertRefKeyInSyncFaultResponse() {
        expErrMessg = new ConvertErrorMessageCreator().createInvalidRefKeyWithConIdErrMessg()
        assertConvertErrResponse()
    }

    public void assertSyncConIdFaultResponse(int inputCId) {
        expErrMessg = new MessageCreator().mkSyncNonExistContainerIdMessg(inputCId as String)
        expErrCode = 814001911
        assertFaultResponse()
    }

    public void assertDuplicateSyncKeyFaultResponse() {
        expErrMessg = new MessageCreator().mkSyncKeyDuplicateErrMessg()
        expErrCode = 814001015
        assertFaultResponse()
    }

    public void assertConvertErrResponse() {
        expErrCode = CONVERTOR_ERR_CODE
        assertFaultResponse()
    }

    public void assertFaultResponse() {
        def testCase = soapuiObj.getTestCaseInOtherSuite(testSuiteName, testCaseName)
        def testStep = testCase.getTestStepByName(testStepName)
		//getAssertableContentAsXml() is not support SoapUI 4.5.1
		//String responseXml = testStep.getAssertableContentAsXml()
		String responseXml = testStep.getAssertableContent()
        outputXml(responseXml)
        assertSoapResponse(responseXml)
        new AssertCountChecker(soapuiObj.getContext()).addAssertCount()
    }

    private void assertSoapResponse(String responseXml){
        def assertExceptionCase = new AssertExceptionCase(responseXml, soapuiObj.getContext())
        assertExceptionCase.looseAssertionMode = this.looseAssertionMode
        assertExceptionCase.setAssertType(SYNC)
        assertExceptionCase.setTestPatternName(titleForEvidenceFile)
        assertExceptionCase.assertExceptionOccurrence(expErrMessg, expErrCode)
    }

    private void outputXml(String responseXml){
        def xmlOutputor = new EvidenceXmlOutputor(soapuiObj.getContext(), testId)
        xmlOutputor.outputXml(responseXml)
    }
}

