package test.degrade.assertion.xml

import common.xml.*
import common.util.*
import test.common.xml.*
import test.common.message.*
import test.degrade.util.*
import test.degrade.management.*

class AssertAimXmlValue extends XMLAssert {
    def static String AIM_NAMESPACE2_PREFIX="ns2" 
    def static String AIM_NAMESPACE3_PREFIX="ns3" 
    def static String AIM_NAMESPACE_URI="urn:nec:aim"
	def aimXmlObject 
	def soapuiObject

    AssertAimXmlValue(String xml) {
        super(xml)
        registerNamespace(AIM_NAMESPACE2_PREFIX, AIM_NAMESPACE_URI)
        registerNamespace(AIM_NAMESPACE3_PREFIX, AIM_NAMESPACE_URI)
    }

    AssertAimXmlValue(String xml, context) {
        super(xml)
        registerNamespace(AIM_NAMESPACE2_PREFIX, AIM_NAMESPACE_URI)
        registerNamespace(AIM_NAMESPACE3_PREFIX, AIM_NAMESPACE_URI)
		aimXmlObject = new AimXmlObject(xml)
		soapuiObject = new SoapuiObject(context)
    }

	def assertCandidateTmpSize(testPatternName, expected){
		
		def assertCanTmpSizeResult = getAssertCandidateTmpSizeResult(expected)
		if(assertCanTmpSizeResult.result == false){
			def errMessg = mkErrMessg("candidate-template size", expected, assertCanTmpSizeResult.value)
			def abendProcessor = new AbendProcessor(soapuiObject.getContext())
			abendProcessor.abendTest(testPatternName, errMessg)
		}
	}

	def getAssertCandidateTmpSizeResult(expected){

		def candidates = aimXmlObject.getCandidates()

		for(candidate in candidates){
			def canTmpSize = candidate."candidate-template".size()
			if(expected != canTmpSize){
				return new ResultMapper(false, canTmpSize)
			}
		}
		return new ResultMapper(true, expected)
	}

	def assertCandidateOrder(testPatternName){
		def errMessg = "Invalid of candidate's order. candidate is not ordered by fusion-score, externalId"
		def candidates = aimXmlObject.getCandidates()
		def candidateSize = aimXmlObject.getCandidateSize()

		if (candidateSize <= 1){
			return true
		}

		if(checkCandidateOrder(candidates, candidateSize) == false){
				def abendProcessor = new AbendProcessor(soapuiObject.getContext())
				abendProcessor.abendTest(testPatternName, errMessg)
		}
		return true
	}

	def checkCandidateOrder(candidateList, candidateSize){

		for(i in 0..candidateSize-2){
			def fScore1 = candidateList[i]."fusion-score".text() as int
			def extId1  = candidateList[i]."externalId".text()
			def fScore2 = candidateList[i+1]."fusion-score".text() as int
			def extId2  = candidateList[i+1]."externalId".text()

			if(fScore1 > fScore2){
				// do nothing
			}else if(fScore1 == fScore2){
				if(extId1.compareTo(extId2) > 0){	 
					return false
				}
			}else{
				return false	 
			}
		}
		return true
	}

	def mkErrMessg(name, expected, actual){
		return new MessageCreator().mkValueErrMessg(name, expected, actual)
	}
}
