package test.degrade.assertion.xml

import test.common.message.*
import test.common.xml.*
import test.degrade.management.*
import test.degrade.util.*

import common.util.*
import common.xml.*

class AssertAimInvalidResponseXmlValue extends AssertAimXmlValue {
	def static String SOAP_NAMESPACE_PREFIX="soap"
	def static String SOAP_NAMESPACE_URI="http://schemas.xmlsoap.org/soap/envelope/"
	def static String AIM_NAMESPACE_PREFIX="ns2"
	def static String AIM_NAMESPACE_URI="http://ws.mm.aim.nec.co.jp/"

	AssertAimInvalidResponseXmlValue(String xml) {
		super(xml)
		registerNamespace(SOAP_NAMESPACE_PREFIX, SOAP_NAMESPACE_URI)
		registerNamespace(AIM_NAMESPACE_PREFIX, AIM_NAMESPACE_URI)
	}

	AssertAimInvalidResponseXmlValue(String xml, context) {
		super(xml, context)
		registerNamespace(SOAP_NAMESPACE_PREFIX, SOAP_NAMESPACE_URI)
		registerNamespace(AIM_NAMESPACE_PREFIX, AIM_NAMESPACE_URI)
		aimXmlObject = new AimXmlObject(xml)
		soapuiObject = new SoapuiObject(context)
	}
}
