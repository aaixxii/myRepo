package test.degrade.assertion.xml

import test.common.constants.aim.*

class SoapExceptionXpathMapper extends XpathMapper{

	final String FAULT_CODE = "faultcode"
	final String FAULT_STRING = "faultstring"

	def createFaultElementCountXpathMap(){
		def xpathValueMap = [ "count(//${FAULT_CODE})": "1", "count(//${FAULT_STRING})": "1" ]
		return xpathValueMap
	}

	def createFaultValuesXpathMap(String errCode, String errMessg){
		def xpathValueMap = [ "//${FAULT_CODE}": "${errCode}",
							  "//${FAULT_STRING}": "${errMessg}" ]
		return xpathValueMap
	}
}
