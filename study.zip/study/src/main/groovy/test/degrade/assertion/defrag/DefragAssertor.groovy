package test.degrade.assertion.defrag

import test.common.util.assertion.AssertUtil
import test.degrade.properties.GlobalProperties
import test.common.entity.SegmentEntity
import test.degrade.evidence.*
import test.degrade.management.*
import test.common.message.*
import test.degrade.util.*
import test.common.util.db.*
import common.util.*
import common.sql.*

class DefragAssertor {
	private static final String SEG_VER_CHECK_SQL = """
				select
                    s.segment_id,
                    msr.mu_id,
                    s.version as seg_version,
                    msr.segment_version as mu_seg_ver,
                    msr.segment_queued_version as mu_queued_ver
                from 
					segments s, mu_seg_reports msr, match_units mu
                where 
					s.segment_id = msr.segment_id
					and mu.mu_id = msr.mu_id
					and mu.state = 'WORKING'
					and mu.type in (0, 2)
                order by 1, 2"""

	private static final String SEG_SIZE_CHECK_SQL = """
				select 
					s.segment_id, 
					ss.bin_id, 
					s.BINARY_LENGTH_COMPACTED, 
					s.BINARY_LENGTH_UNCOMPACTED, 
					ss.MAX_SEGMENT_SIZE 
				from 
					segments s, 
					segment_sets ss 
				where 
					s.segment_set_id = ss.segment_set_id 
					and (
						s.BINARY_LENGTH_UNCOMPACTED > ss.MAX_SEGMENT_SIZE 
						or s.BINARY_LENGTH_COMPACTED > s.BINARY_LENGTH_UNCOMPACTED
					) order by 2, 1"""

	SoapuiObject soapuiObject
	SqlExecutor sqlExecutor
	GlobalProperties globalProperties
	AssertUtil assertUtil
	String testName

    DefragAssertor(context, String testName){
		this.soapuiObject = new SoapuiObject(context)
		this.sqlExecutor = new SqlExecutorFactory(soapuiObject.getContext()).create()
		this.globalProperties = new GlobalProperties(context)
		this.assertUtil = new AssertUtil(context, testName)
		this.testName = testName
	}

	public void doAssert() {
		assertMuSegVer()
		assertSegSize()
	}

	public void assertMuSegVer() {
		def recs = sqlExecutor.getSqlResult(SEG_VER_CHECK_SQL)
		if(recs.size() == 0){
			abendTest("There are no WORKING MU and DM")
		}

		for(rec in recs){
			def segId = rec.segment_id
			def muId = rec.mu_id
			def segVer = rec.seg_version
			def muSegVer = rec.mu_seg_ver
			def muSegQVer = rec.mu_queued_ver
			assertSegVerEqual(segId, muId, segVer, muSegVer, "MU_SEG_VERSION")
			assertSegVerEqual(segId, muId, segVer, muSegQVer, "MU_SEG_QUEUED_VERSION")
		}
		outputTrueEvidence("All Seg ver equals MU Seg ver.")
	}

	public void assertSegSize() {
		def recs = sqlExecutor.getSqlResult(SEG_SIZE_CHECK_SQL)
		if(recs.size() == 0){
			outputTrueEvidence("Segment size in DB is correct.")
			return
		}

		StringBuilder sb = new StringBuilder()
		sb.append("Invalid record. BINARY_LENGTH_UNCOMPACTED > MAX_SEGMENT_SIZE or BINARY_LENGTH_COMPACTED > BINARY_LENGTH_UNCOMPACTED\n")

		for(rec in recs){
			def segId = rec.segment_id
			def binId = rec.bin_id
			def compactedSize = rec.BINARY_LENGTH_COMPACTED
			def unCompactedSize = rec.BINARY_LENGTH_UNCOMPACTED
			def maxSegSize = rec.MAX_SEGMENT_SIZE
			sb.append(" segId=$segId binId=$binId compactedSize=$compactedSize unCompactedSize=$unCompactedSize maxSegSize=$maxSegSize\n")
		}
		abendTest(sb.toString())
	}

				
	private void assertSegVerEqual(def segId, def muId, def segVer, def muSegVer, def muSegType) {
		if(segVer != muSegVer){
			String errMessg = "Segment version is different : SEGID=${segId}, MU=${muId}, SEG_VER=${segVer}, ${muSegType}=${muSegVer}"
			abendTest(errMessg)
		}
	}

	private abendTest(String errMessg) {
		AbendProcessor abendProcessor = new AbendProcessor(soapuiObject.getContext())
		abendProcessor.abendTest(testName, errMessg)
	}

	private void outputTrueEvidence(String messg){
		def outputor = new EvidenceFileOutputor(soapuiObject.getContext())
		outputor.outputTrueMess(messg) 
	}

	public void assertOmmitBinId() {
		List<SegmentEntity> actualSegEntityList = makeSegmentEntityList()
		List<SegmentEntity> expectedSegEnttityList = getAfterDefragSegEintityList()
		assertUtil.assertEquals(actualSegEntityList.size(), expectedSegEnttityList.size(), "segment record count")
		assertSegRecVals(actualSegEntityList, expectedSegEnttityList)
		outputTrueEvidence("${testName} : All segment records are same with result of AIM-4.0.1.")
	}

	public void assertBinId4() {
		List<SegmentEntity> actualSegEntityList = makeSegmentEntityList()
		List<SegmentEntity> beforeDefragSegEnttityList = getBeforeDefragSegEintityList()
		List<SegmentEntity> afterDefragSegEnttityList = getAfterDefragSegEintityList()
		List<SegmentEntity> expectedSegEnttityList = mergeEntityList(4, beforeDefragSegEnttityList, afterDefragSegEnttityList)
		assertUtil.assertEquals(actualSegEntityList.size(), expectedSegEnttityList.size(), "segment record count")
		assertSegRecVals(actualSegEntityList, expectedSegEnttityList)
		outputTrueEvidence("${testName} : segment records on BIN_ID=4 are same with result of AIM-4.0.1.")
	}

	private List<SegmentEntity> mergeEntityList(int mergedBinId, List<SegmentEntity> segEntityListA, List<SegmentEntity> segEntityListB) {
		List<SegmentEntity> mergedSegEntityList = new ArrayList<SegmentEntity>()
		boolean alreadyMerged = false
		for(SegmentEntity segEntityA in segEntityListA) {
			int binIdA = segEntityA.getBinId() as int
			if(binIdA == mergedBinId) {
				if(alreadyMerged) {
					continue
				}
				for(SegmentEntity segEntityB in segEntityListB) {
					int binIdB = segEntityB.getBinId() as int
					if(binIdB == mergedBinId) {
						mergedSegEntityList.add(segEntityB)
					}
				}
				alreadyMerged = true
			} else {
				mergedSegEntityList.add(segEntityA)
			}
		}
		return mergedSegEntityList
	}

	private void assertSegRecVals(List<SegmentEntity> actual, List<SegmentEntity> expected) {
		for(i in 0..actual.size()-1) {
			assertUtil.assertEquals(actual[i].getBinId(), expected[i].getBinId(), "BIN_ID")
			assertUtil.assertEquals(actual[i].getSegId(), expected[i].getSegId(), "SEGMENT_ID")
			assertUtil.assertEquals(actual[i].getSegSetId(), expected[i].getSegSetId(), "SEGMENT_SET_ID")
			assertUtil.assertEquals(actual[i].getBioIdStart(), expected[i].getBioIdStart(), "BIO_ID_START")
			assertUtil.assertEquals(actual[i].getBioIdEnd(), expected[i].getBioIdEnd(), "BIO_ID_END")
			assertUtil.assertEquals(actual[i].getLengthCompacted(), expected[i].getLengthCompacted(), "BINARY_LENGTH_COMPACTED")
			assertUtil.assertEquals(actual[i].getRecCnt(), expected[i].getRecCnt(), "RECORD_COUNT")
			assertUtil.assertEquals(actual[i].getVersion(), expected[i].getVersion(), "VERSION")
			assertUtil.assertEquals(actual[i].getRevision(), expected[i].getRevision(), "REVISION")
			assertUtil.assertEquals(actual[i].getLengthUnCompacted(), expected[i].getLengthUnCompacted(), "BINARY_LENGTH_UNCOMPACTED")
		}
	}

	private List<SegmentEntity> getBeforeDefragSegEintityList() {
		String dataFilePath = globalProperties.getDataFilePath()
		String expectedSegRecInfoFilePath = "${dataFilePath}/degradeTest/Defrag/db_info/segment_info_before_defrag.txt"
		File expectedSegRecInfoFile = new File(expectedSegRecInfoFilePath)
		return getExpectedSegEntityList(expectedSegRecInfoFile)
	}

	private List<SegmentEntity> getAfterDefragSegEintityList() {
		String dataFilePath = globalProperties.getDataFilePath()
		String expectedSegRecInfoFilePath = "${dataFilePath}/degradeTest/Defrag/db_info/segment_info_after_defrag.txt"
		File expectedSegRecInfoFile = new File(expectedSegRecInfoFilePath)
		return getExpectedSegEntityList(expectedSegRecInfoFile)
	}

	private List<SegmentEntity> getExpectedSegEntityList(File expectedSegRecInfoFile) {
		List<SegmentEntity> segEntityList = new ArrayList<SegmentEntity>()
		expectedSegRecInfoFile.eachLine{
			String[] segInfoArry = it.split(",")
			def segEntity = new SegmentEntity()
			segEntity.setBinId(segInfoArry[0])
            segEntity.setSegId(segInfoArry[1])
			segEntity.setSegSetId(segInfoArry[2])
			segEntity.setBioIdStart(segInfoArry[3])
			segEntity.setBioIdEnd(segInfoArry[4])
			segEntity.setLengthCompacted(segInfoArry[5])
			segEntity.setRecCnt(segInfoArry[6])
			segEntity.setVersion(segInfoArry[7])
			segEntity.setRevision(segInfoArry[8])
			segEntity.setLengthUnCompacted(segInfoArry[9])
			segEntityList.add(segEntity)
		}
		return segEntityList
	}

    private List<SegmentEntity> makeSegmentEntityList(){
        String sql = """
			select ss.bin_id, s.* 
				from segments s, segment_sets ss 
				where s.segment_set_id = ss.segment_set_id 
				order by ss.bin_id, s.segment_id"""

		List<SegmentEntity> segEntityList = new ArrayList<SegmentEntity>()
        for(rec in sqlExecutor.getSqlResult(sql)){
			def segEntity = new SegmentEntity()
			segEntity.setBinId(rec.BIN_ID as String)
            segEntity.setSegId(rec.SEGMENT_ID as String)
			segEntity.setSegSetId(rec.SEGMENT_SET_ID as String)
			segEntity.setBioIdStart(rec.BIO_ID_START as String)
			segEntity.setBioIdEnd(rec.BIO_ID_END as String)
			segEntity.setLengthCompacted(rec.BINARY_LENGTH_COMPACTED as String)
			segEntity.setRecCnt(rec.RECORD_COUNT as String)
			segEntity.setVersion(rec.VERSION as String)
			segEntity.setRevision(rec.REVISION as String)
			segEntity.setLengthUnCompacted(rec.BINARY_LENGTH_UNCOMPACTED as String)
			segEntityList.add(segEntity)
        }

		return segEntityList
    }
}

