package test.degrade.assertion.extract

import test.common.format.extraction.payload.abst.*

class AssertLfmlLatentExtraction extends AssertLatentExtraction {

    AssertLfmlLatentExtraction(context, String testName){
		super(context, testName)
	}

    AssertLfmlLatentExtraction(OutputPayloadAbstract outputPayload, context) {
		super(outputPayload, context)
    }

    AssertLfmlLatentExtraction(OutputPayloadAbstract outputPayload, context, String testName) {
		super(outputPayload, context, testName)
    }
	
}
