package test.degrade.assertion.xml

import common.xml.*
import test.degrade.util.*
import test.degrade.management.*
import test.degrade.constants.soapui.*

class AssertAimXml{
	def soapuiObject
	def testPatternName
	def targetXml
	def id

	AssertAimXml(context, testPatternName, targetXml){
		this.soapuiObject = new SoapuiObject(context)
		this.testPatternName = testPatternName
		this.targetXml = targetXml
	}

	AssertAimXml(context, testPatternName, targetXml, id){
		this.soapuiObject = new SoapuiObject(context)
		this.testPatternName = testPatternName
		this.targetXml = targetXml
		this.id = id
	}

	def assertTargetXml(){
		assertXsdSchem()
		assertXmlDiff()
	}

	def assertXsdSchem(){
		def xsdSchem = new File(SoapuiDefines.CLIENTAIP_XSD)
		def xmlValidator = new XMLValidator(targetXml, xsdSchem)
		if(! xmlValidator.isXMLValid()){
			new AbendProcessor(soapuiObject.getContext()).abendTest(testPatternName, xmlValidator)
		}
	}

	def assertExtractionXsdSchem(){
		def xsdSchem = new File(SoapuiDefines.EXTRACTION_PAYLOAD_XSD)
		def xmlValidator = new XMLValidator(targetXml, xsdSchem)
		if(! xmlValidator.isXMLValid()){
			new AbendProcessor(soapuiObject.getContext()).abendTest(testPatternName, xmlValidator)
		}
	}

	def assertExistError(){
		Node root = new XmlParser().parseText(targetXml)
		def actErrorSize = root.error.size()
		if(actErrorSize != 0 ){
			new AbendProcessor(soapuiObject.getContext()).abendTest(testPatternName, "exist Error!!")
		}
	}

	////////////////////////////////////////////////////
	// disabled because candidate sequense is random
	////////////////////////////////////////////////////
	def assertXmlDiff(){
		return
		def assertXmlDiff = new AssertXmlDiff(soapuiObject.getContext(), id)
		if(! assertXmlDiff.execAssertion(1)){
			def errMess = assertXmlDiff.getDiffResult()
			def abendProcessor = new AbendProcessor(soapuiObject.getContext())
			abendProcessor.abendTest(testPatternName, errMess)
		}
	}

	def assertXmlDiff(String actualXml, String expectedXml){
		def assertXmlDiff = new AssertXmlDiff(soapuiObject.getContext())
		if(! assertXmlDiff.execAssertion(1)){
			def errMess = assertXmlDiff.getDiffResult()
			def abendProcessor = new AbendProcessor(soapuiObject.getContext())
			abendProcessor.abendTest(testPatternName, errMess)
		}
	}

	def assertExtractResultXmlDiff(){
		def assertXmlDiff = new AssertXmlDiff(soapuiObject.getContext(), id)
		if(! assertXmlDiff.execAssertWithoutKeyedBinary(0)){
			def errMess = assertXmlDiff.getDiffResult()
			def abendProcessor = new AbendProcessor(soapuiObject.getContext())
			abendProcessor.abendTest(testPatternName, errMess)
		}
	}

	def assertXmlDiffVX(){
		return
	}

	def assertVxXsdSchem(){
		return
	}
}

