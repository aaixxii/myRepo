package test.degrade.assertion.xml

class IrisSearchXpathMapper extends AbstractSearchXpathMapper {
	
	public IrisSearchXpathMapper(){}

	public IrisSearchXpathMapper(context){
		super(context)
	}

	protected String makeIScoreCondition(List iScore, int index){
        StringBuilder sb = new StringBuilder()
		def iScoreVal = iScore[0]
		def iScorePos = iScore[1]
		def rowScoreList = iScore[2]

		sb.append("""
						and individual-score[${index}][
							@position='${iScorePos}' 
							and @value='${iScoreVal}' 
							and not(@search-position)
							and not(@axis)
							and not(@inquirySet)
							and not(@fusionWeight)""")
        sb.append(makeRowScoreListCondition(rowScoreList))
        sb.append("      ]\n")
        return sb.toString()
	}

    private String makeRowScoreListCondition(List rowScoreList) {
        StringBuilder sb = new StringBuilder()
        sb.append("""
                            and search-outputs-payload[
                                raw-scores[""")
        int i = 1
        for(rowScore in rowScoreList) {
            def filePos = rowScore[0]
            def score = rowScore[1]
            if(i >= 2) {
                sb.append("         and ")
            }
            sb.append("""
                                    iris-score[${i}][
                                        @filePosition='${filePos}'
                                        and @score='${score}'
                                    ]\n""")
            i++
        }

        sb.append("""
                                ]
                            ]\n""")

        return sb.toString()
    }
}

