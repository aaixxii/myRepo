package test.degrade.assertion.xml

class FinSearchXpathMapper extends AbstractSearchXpathMapper {


	public FinSearchXpathMapper(){}

	public FinSearchXpathMapper(context){
		super(context)
	}
	
	protected String makeIScoreCondition(List iScore, int index){
		def iScoreVal = iScore[0]
		def iScoreFinNum = iScore[1]
		def iScoreAxis = iScore[2]
		def iScoreInqSet = iScore[3]
		def iScoreFWeight = iScore[4]

		def iScoreFWeightCondition = makeAttributeCondition("fusionWeight", iScoreFWeight)
		def iScoreInqSetCondition = makeAttributeCondition("inquirySet", iScoreInqSet)

		return """
						and individual-score[${index}][
							@axis='${iScoreAxis}' 
							and not(@search-position)
							and @position='${iScoreFinNum}' 
							and @value='${iScoreVal}' 
							and ${iScoreInqSetCondition}
							and ${iScoreFWeightCondition} 
						]\n"""
	}

	protected String makeCmlIScoreCondition(List iScore, int index){
		def iScoreVal = iScore[0]
		def iScoreFinNum = iScore[1]
		def iScoreAxis = iScore[2]
		def iScoreInqSet = iScore[3]
		def iScoreFWeight = iScore[4]
		def iScoreSFinNum
		if(iScore.size() == 5){
			iScoreSFinNum = iScore[1]
		}else if(iScore.size() == 6){
			iScoreSFinNum = iScore[5]
		}

		def iScoreFWeightCondition = makeAttributeCondition("fusionWeight", iScoreFWeight)
		def iScoreInqSetCondition = makeAttributeCondition("inquirySet", iScoreInqSet)

		return """
						and individual-score[${index}][
							@axis='${iScoreAxis}'
							and @search-position='${iScoreSFinNum}'
							and @position='${iScoreFinNum}' 
							and @value='${iScoreVal}' 
							and ${iScoreInqSetCondition}
							and ${iScoreFWeightCondition} 
						]\n"""
	}

    private String makeAttributeCondition(String key, def value) {
        if(value == null) {
            return "not(@${key})"
        }else{
            return "@${key}='${value}'"
        }
    }
}

