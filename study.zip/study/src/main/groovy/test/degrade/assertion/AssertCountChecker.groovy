package test.degrade.assertion

import test.degrade.util.*
import test.degrade.evidence.*

class AssertCountChecker{
	def actualCount
	def expectedCount
	def soapuiObject
	
	AssertCountChecker(context){
		this.soapuiObject = new SoapuiObject(context)
        this.actualCount = soapuiObject.getActualAssertCount()
		this.expectedCount = soapuiObject.getExpectedAssertCount()
	}

	def outputAssertCountResult(){
		def evidenceOutputor =  new EvidenceFileOutputor(soapuiObject.getContext())
		def messg = mkMessg()
		if(getAessertionResult()){
			evidenceOutputor.outputTrueMess(messg)
			evidenceOutputor.outputIndent()
		}else{
			evidenceOutputor.outputFalseMess(messg)
			evidenceOutputor.outputIndent()
		}
	}

	def getAessertionResult(){
		return (actualCount == expectedCount) ? true : false
	}

	def mkMessg(){
		return "checkCount/correctCount = ${actualCount}/${expectedCount}"
	}

	def addAssertCount(){
		actualCount++
		soapuiObject.setActualAssertCount(actualCount)
	}
}
