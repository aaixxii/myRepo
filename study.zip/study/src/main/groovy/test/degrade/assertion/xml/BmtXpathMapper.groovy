package test.degrade.assertion.xml

class BmtXpathMapper extends XpathMapper {

    BmtXpathMapper(){}

    def createResultXpathMap(
				String hitFlag, String externalId, def fusionScore, 
				def compositeScore, def containerId, def eventId, 
				def searchRequestIndex, String inquirySet,
				List valueList, List fingerNumberList, 
				List axis, List rawScoreList, List searchIndexList, List fileIndexList) {

        String individualScoreXmlParts = createIndividualScoreXmlParts(inquirySet, valueList, fingerNumberList, axis, rawScoreList, searchIndexList, fileIndexList)
        String resultXpath = """count(//candidate[
                                    @hit='${hitFlag}'
                                    and externalId='${externalId}'
                                    and fusion-score='${fusionScore}'
                                    and candidate-template[
                                        containerId='${containerId}'
                                        and eventId='${eventId}'
                                        and searchRequestIndex='${searchRequestIndex}'
                                        and not(fusionWeight)
										and composite-score='${compositeScore}'
                                    	     ${individualScoreXmlParts}
                                    ]])"""
		def xpathValueMap = ["${resultXpath}": "1"]
    	return xpathValueMap

	}

    def _createResultXpathMap(
				String hitFlag, String externalId, String fusionScore, 
				String compositeScore, String containerId, String eventId, 
				String searchRequestIndex, 
				List valueList, List fingerNumberList, 
				List axis, List rawScoreList, List searchIndexList, List fileIndexList) {

        String individualScoreXmlParts = createIndividualScoreXmlParts(valueList, fingerNumberList, axis, rawScoreList, searchIndexList, fileIndexList)
        String resultXpath = """count(//candidate[
                                    @hit='${hitFlag}'
                                    and externalId='${externalId}'
                                    and fusion-score='${fusionScore}'
                                    and candidate-template[
                                        containerId='${containerId}'
                                        and eventId='${eventId}'
                                        and searchRequestIndex='${searchRequestIndex}'
                                        and not(fusionWeight)
										and composite-score='${compositeScore}'
                                    	     ${individualScoreXmlParts}
                                    ]])"""
		def xpathValueMap = ["${resultXpath}": "1"]
    	return xpathValueMap

	}

    def createResultXpathMap(
				String externalId, String fusionScore, 
				String compositeScore, String containerId, String eventId, 
				String searchRequestIndex, String InquirySet,
				List valueList, List fingerNumberList, 
				List axis, List rawScoreList, List searchIndexList, List fileIndexList) {

        String individualScoreXmlParts = createIndividualScoreXmlParts(InquirySet, valueList, fingerNumberList, axis, rawScoreList, searchIndexList, fileIndexList)
        String resultXpath = """count(//candidate[
                                    externalId='${externalId}'
                                    and fusion-score='${fusionScore}'
                                    and candidate-template[
                                        containerId='${containerId}'
                                        and eventId='${eventId}'
                                        and searchRequestIndex='${searchRequestIndex}'
                                        and not(fusionWeight)
										and composite-score='${compositeScore}'
                                    	     ${individualScoreXmlParts}
                                    ]])"""
		def xpathValueMap = ["${resultXpath}": "1"]
    	return xpathValueMap
	}

    def _createResultXpathMap(
				String externalId, String fusionScore, 
				String compositeScore, String containerId, String eventId, 
				String searchRequestIndex, 
				List valueList, List fingerNumberList, 
				List axis, List rawScoreList, List searchIndexList, List fileIndexList) {

        String individualScoreXmlParts = createIndividualScoreXmlParts(valueList, fingerNumberList, axis, rawScoreList, searchIndexList, fileIndexList)
        String resultXpath = """count(//candidate[
                                    externalId='${externalId}'
                                    and fusion-score='${fusionScore}'
                                    and candidate-template[
                                        containerId='${containerId}'
                                        and eventId='${eventId}'
                                        and searchRequestIndex='${searchRequestIndex}'
                                        and not(fusionWeight)
										and composite-score='${compositeScore}'
                                    	     ${individualScoreXmlParts}
                                    ]])"""
		def xpathValueMap = ["${resultXpath}": "1"]
    	return xpathValueMap
	}

	def createIndividualScoreXmlParts(
				String inquirySet, List valueList, List fingerNumberList, 
				List axis, List rawScoreList, List searchIndexList, List fileIndexList) {

		String fusionWeight = "100"
		String rawScoreXmlParts = createRawScoreXmlParts(rawScoreList, searchIndexList, fileIndexList) 
		
		StringBuilder sb = new StringBuilder()
        for(int i = 0; i < fingerNumberList.size(); i++){
            sb.append(""" 
					and individual-score[${i+1}][
                    @value='${valueList[i]}'
                    and @position='${fingerNumberList[i]}'
                    and not(@search-position)
					and not(axis)
					and @inquirySet = '${inquirySet}'
					and @fusionWeight = '${fusionWeight}'
					and search-outputs-payload[
						raw-scores[
							${rawScoreXmlParts}
						]
					]
                ]""")
        }
    	return sb.toString()
	}

	def _createIndividualScoreXmlParts(
				List valueList, List fingerNumberList, 
				List axis, List rawScoreList, List searchIndexList, List fileIndexList) {

		String rawScoreXmlParts = createRawScoreXmlParts(rawScoreList, searchIndexList, fileIndexList) 
		
		StringBuilder sb = new StringBuilder()
        for(int i = 0; i < fingerNumberList.size(); i++){
            sb.append(""" 
					and individual-score[${i+1}][
                    @value='${valueList[i]}'
                    and @fingerNumber='${fingerNumberList[i]}'
                    and @axis='${axis[i]}'
					and search-outputs-payload[
						raw-scores[
							${rawScoreXmlParts}
						]
					]
                ]""")
        }
    	return sb.toString()
	}
	
	def createRawScoreXmlParts(List rawScoreList, List searchIndexList, List fileIndexList) {
	StringBuilder sb = new StringBuilder()
					
		for(int i = 0; i < rawScoreList.size(); i++){
            sb.append("""
                raw-score[${i+1}][
                    @value='${rawScoreList[i]}'
                    and @searchIndex='${searchIndexList[i]}'
                    and @fileIndex='${fileIndexList[i]}'
                ]""")
			
			if( i < rawScoreList.size()-1){
				sb.append("""
					and
				""")
			}
        }
		return sb.toString()
	}
}

