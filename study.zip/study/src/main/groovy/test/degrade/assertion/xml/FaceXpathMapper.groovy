package test.degrade.assertion.xml

class FaceXpathMapper extends XpathMapper{
	
	FaceXpathMapper(){}

	def createCandidateWithFusionWeightXpathMap(hitFlag, externalId, fusionScore, candidateTemplateCount,
									containerId, eventId, searchRequestIndex, fusionWeight, compositeScore,
								 	individualScoreValue, existCount ){
		String candidateXpath = createCanidateWithFwXpath(
								hitFlag, externalId, fusionScore, candidateTemplateCount,
								containerId, eventId, searchRequestIndex, fusionWeight, compositeScore,
							 	individualScoreValue)

		String candidateTmpXpath = createCandidateTmpXpath(hitFlag, externalId, fusionScore)

		String individualScoreXpath = createIndividualScoreWithFwXpath(
								 hitFlag, externalId, fusionScore, candidateTemplateCount,
								 containerId, eventId, searchRequestIndex, fusionWeight, compositeScore )

		def xpathValueMap = [ 
			"${candidateXpath}": "${existCount}",
			"${candidateTmpXpath}": "${candidateTemplateCount}",
			"${individualScoreXpath}": "${existCount}",
		]
		return xpathValueMap
	}

        def createCandidateWithNotFusionWeightXpathMap(hitFlag, externalId, fusionScore, candidateTemplateCount,
                                                                        containerId, eventId, searchRequestIndex,  compositeScore,
                                                                        individualScoreValue, existCount ){

                String candidateXpath = createCanidateWithNotFwXpath(
                                                                hitFlag, externalId, fusionScore, candidateTemplateCount,
                                                                containerId, eventId, searchRequestIndex,  compositeScore,
                                                                individualScoreValue)

                String candidateTmpXpath = createCandidateTmpXpath(hitFlag, externalId, fusionScore)

                String individualScoreXpath = createIndividualScoreXpath(
                                                                 hitFlag, externalId, fusionScore, candidateTemplateCount,
                                                                 containerId, eventId, searchRequestIndex, compositeScore )

                def xpathValueMap = [
                        "${candidateXpath}": "${existCount}",
                        "${candidateTmpXpath}": "${candidateTemplateCount}",
                        "${individualScoreXpath}": "${existCount}",
                ]
                return xpathValueMap
        }

	def String createCanidateWithFwXpath(hitFlag, externalId, fusionScore, candidateTemplateCount, containerId,
								 eventId, searchRequestIndex, fusionWeight, compositeScore, individualScoreValue ){
		
		String hitFlagStr = createHitFlagAttribute(hitFlag)
		return """count(//candidate[
				externalId='${externalId}'
				and ${hitFlagStr}
				and fusion-score='${fusionScore}'
				and candidate-template[
						containerId='${containerId}'
						and eventId='${eventId}'
						and searchRequestIndex='${searchRequestIndex}'
						and composite-score='${compositeScore}'
						and individual-score[
							@value='${individualScoreValue}'
							and @fusionWeight='${fusionWeight}'
						]
					]
				])"""
	}

        def String createCanidateWithNotFwXpath(hitFlag, externalId, fusionScore, candidateTemplateCount, containerId,
                                                                 eventId, searchRequestIndex, compositeScore, individualScoreValue ){

                String hitFlagStr = createHitFlagAttribute(hitFlag)
                return """count(//candidate[
                                externalId='${externalId}'
                                and ${hitFlagStr}
                                and fusion-score='${fusionScore}'
                                and candidate-template[
                                                containerId='${containerId}'
                                                and eventId='${eventId}'
                                                and searchRequestIndex='${searchRequestIndex}'
                                                and composite-score='${compositeScore}'
                                                and individual-score[
													@value='${individualScoreValue}'
													and not(@fusionWeight)	
												]
                                        ]
                                ])"""
        }

	def String createCandidateTmpXpath(hitFlag, externalId, fusionScore){

		String hitFlagStr = createHitFlagAttribute(hitFlag)
		return """count(//candidate[externalId='${externalId}'
									and ${hitFlagStr}
									and fusion-score='${fusionScore}'
								]/candidate-template)"""
	}

	def String createHitFlagAttribute(String hitFlag){
		if(hitFlag != null){
			return "@hit='${hitFlag}'"
		}else{
			return "not(@hit)"
		}
	}

	def String createIndividualScoreXpath(hitFlag, externalId, fusionScore, candidateTemplateCount,
									 containerId, eventId, searchRequestIndex, compositeScore ){
		
		String hitFlagStr = createHitFlagAttribute(hitFlag)
		return """count(//candidate[
				externalId='${externalId}'
				and ${hitFlagStr}
				and fusion-score='${fusionScore}'
					]/candidate-template[
						containerId='${containerId}'
						and eventId='${eventId}'
						and searchRequestIndex='${searchRequestIndex}'
						and not(fusionWeight)
						and composite-score='${compositeScore}'
					]/individual-score)"""
	}

	def String createIndividualScoreWithFwXpath(hitFlag, externalId, fusionScore, candidateTemplateCount,
									 containerId, eventId, searchRequestIndex, fusionWeight, compositeScore ){

		String hitFlagStr = createHitFlagAttribute(hitFlag)
		return """count(//candidate[
				externalId='${externalId}'
				and ${hitFlagStr}
				and fusion-score='${fusionScore}'
					]/candidate-template[
						containerId='${containerId}'
						and eventId='${eventId}'
						and searchRequestIndex='${searchRequestIndex}'
						and composite-score='${compositeScore}'
					]/individual-score)"""
	}

	def createExtractResultFingerOutputXpath(position, expectedCount){
		def xpathValueMap = [ 
			"count(//finger-output[@pos='${position}'])": "${expectedCount}",
		]
		return xpathValueMap
	}

	def createExtractResultFaceOutputSizeXpath(expectedCount){
		def xpathValueMap = [ 
			"count(//face-output)": "${expectedCount}",
		]
		return xpathValueMap
	}
}

