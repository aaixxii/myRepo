package test.degrade.assertion.extract

import test.common.format.extraction.payload.abst.*
import test.common.format.extraction.payload.impl.PalmOutput
import test.common.format.extraction.payload.impl.QcOutPutMode1
import test.common.format.extraction.payload.impl.QcOutPutMode2
import test.degrade.assertion.xml.*
import test.degrade.management.*
import test.degrade.evidence.*
import test.common.message.*
import test.common.util.mu.MatchUnit
import test.degrade.util.*
import common.util.*

class AssertQcExtraction {
	def log
	def qcOutput
	def extractionOutputPayload
	String expectQcStatus
	String expectQcTotal
	List expectRolledSequenceList
	List expectSlapSequenceList
	List expectRollStatusList
	List expectSlapStatusList
	int expectQcItemSize
	HashMap expectDataMap
    HashMap expectStatusMap
	String qcMode



	def AssertQcExtraction (def qcOutput,String expectQcTotal, List expectRollStatusList, List expectSlapStatusList){
				this.qcMode = "1"
                this.qcOutput = qcOutput
                this.expectQcTotal = expectQcTotal
                this.expectRollStatusList = expectRollStatusList
                this.expectSlapStatusList = expectSlapStatusList
	}

	def AssertQcExtraction (def qcOutput,String expectQcStatus, List expectRolledSequenceList, List expectSlapSequenceList, int expectQcItemSize, HashMap expectDataMap, HashMap expectStatusMap){
		this.qcMode = "2"
		this.qcOutput = qcOutput
		this.expectQcStatus = expectQcStatus
		this.expectRolledSequenceList = expectRolledSequenceList
		this.expectSlapSequenceList = expectSlapSequenceList
		this.expectQcItemSize = expectQcItemSize
		this.expectDataMap = expectDataMap
		this.expectStatusMap = expectStatusMap
	}

	def AssertQcExtraction (def extractionOutputPayload){
		this.extractionOutputPayload = extractionOutputPayload
	}

	def assertMain(){
		assertMain(qcMode)
	}
	
	def assertMain(String qcMode){
		if(qcMode == "1"){
			HashMap<String, String>  expectrMap = createQcRollStatusMap()
			HashMap<String, String>  expectsMap = createQcSlapStatusMap()
			asseertQcTotal()
			assertQcRollStatus(expectrMap)
			assertQcSlapStatus(expectsMap)
		}
		if(qcMode == "2"){
			asseertQcItemSize()
			asseertQcStatus()
			assertRolledSequenceList()
			assertSlapSequenceList()
			assetQcItemDataValue()
			assetQcItemeStatusValue()
		}
	}

	def asseertQcStatus (){
		assertEquals(expectQcStatus, qcOutput.@status,"qcOutput_status")
	}

	def asseertQcTotal (){
		assertEquals(expectQcTotal, qcOutput.@total,"qcOutput_total")
	}

	def asseertQcItemSize (){
		assertEquals(expectQcItemSize, qcOutput.history.itemList.size(),"qcOutput_size")
	}

	def assertRolledSequenceList (){
		List actualRolledSequence = qcOutput.seq.@rolledFingers as List
		assertEquals(expectRolledSequenceList, actualRolledSequence, "RolledSequence")
	}

	def assertSlapSequenceList (){
		List actualSlapSequence = qcOutput.seq.@slapFingers as List
		assertEquals(expectSlapSequenceList, actualSlapSequence, "SlapSequence")
	}

	def assetQcItemDataValue(){
		for(i in 0 .. qcOutput.history.itemList.size()-1){
			int num = i as int
			String actualAct = qcOutput.history.itemList[num].getActivity()
			if(expectDataMap.containsKey(actualAct)){
				assertEquals(expectDataMap.get(actualAct) ,qcOutput.history.itemList[num].@data, "$actualAct data")
			}else{
				assert false
			}
		}
	}

	def assetQcItemeStatusValue(){
		for(i in 0 .. qcOutput.history.itemList.size()-1){
			int num = i as int
			String actualAct = qcOutput.history.itemList[num].getActivity()
			if(expectStatusMap.containsKey(actualAct)){
				assertEquals(expectStatusMap.get(actualAct) ,qcOutput.history.itemList[num].@status, "$actualAct status")
			}else{
				assert false
			}
		}
	}

	def assertQcRollStatus(HashMap<String, String>  expectrMap){
		for(i in 0 .. 9){
			assertEquals(expectrMap.get(i as String)  ,qcOutput.rollStatusList[i].finger.@status, "QcRoll_status")
		}
	}

	def assertQcSlapStatus(HashMap<String, String>  expectsMap){
			assertEquals(expectsMap.get("11")  ,qcOutput.slapStatusList[0].finger.@status, "QcSlap_status")
			assertEquals(expectsMap.get("40")  ,qcOutput.slapStatusList[1].finger.@status, "QcSlap_status")
			assertEquals(expectsMap.get("41")  ,qcOutput.slapStatusList[2].finger.@status, "QcSlap_status")
			assertEquals(expectsMap.get("42")  ,qcOutput.slapStatusList[3].finger.@status, "QcSlap_status")
			assertEquals(expectsMap.get("43")  ,qcOutput.slapStatusList[4].finger.@status, "QcSlap_status")
			assertEquals(expectsMap.get("12")  ,qcOutput.slapStatusList[5].finger.@status, "QcSlap_status")
			assertEquals(expectsMap.get("44")  ,qcOutput.slapStatusList[6].finger.@status, "QcSlap_status")
			assertEquals(expectsMap.get("45")  ,qcOutput.slapStatusList[7].finger.@status, "QcSlap_status")
			assertEquals(expectsMap.get("46")  ,qcOutput.slapStatusList[8].finger.@status, "QcSlap_status")
			assertEquals(expectsMap.get("47")  ,qcOutput.slapStatusList[9].finger.@status, "QcSlap_status")
	}

	def createQcRollStatusMap(){
		HashMap<String, String>  expectQcRMap = new HashMap<String, String>()
		for(i in 0 .. expectRollStatusList.size()-1){
			expectQcRMap.put(i as String, expectRollStatusList.get(i))
		}
		return expectQcRMap	
	}

	def createQcSlapStatusMap(){
		HashMap<String, String>  expectQcSMap = new HashMap<String, String>()
		expectQcSMap.put("11", expectSlapStatusList.get(0))
		expectQcSMap.put("40", expectSlapStatusList.get(1))
		expectQcSMap.put("41", expectSlapStatusList.get(2))
		expectQcSMap.put("42", expectSlapStatusList.get(3))
		expectQcSMap.put("43", expectSlapStatusList.get(4))
		expectQcSMap.put("12", expectSlapStatusList.get(5))
		expectQcSMap.put("44", expectSlapStatusList.get(6))
		expectQcSMap.put("45", expectSlapStatusList.get(7))
		expectQcSMap.put("46", expectSlapStatusList.get(8))
		expectQcSMap.put("47", expectSlapStatusList.get(9))
		return expectQcSMap	
	}

	def assertStatusIsOmmit(){
		def root = new  XmlParser().parseText(extractionOutputPayload)
		def status = root."extraction-outputs-payload"[0]."tenprint-output"."qc-output".@status[0]
		def exp = "-1"
		assertEquals(exp, status, "qc-output status")
	}

	def assertEquals(def expected, def actual, String propertyName){
    		assert expected == actual, "$propertyName is not $expected. actual $actual"
    	}
}
