package test.degrade.assertion.xml

import static test.common.constants.aim.AIMXmlAttribute.*

//Called only from ScoringMethod-soapui-project.xml(TimEngine Only CMLAF)
//Do not call it from others!
class TimScoringMethodXpathMapper extends XpathMapper {
	
	TimScoringMethodXpathMapper(){}

	
	TimScoringMethodXpathMapper(context){
		super(context)
	}

    // Override
	def createCandidateXpathMap(hitFlag, externalId, fusionScore, candidateTemplateCount,
									containerId, eventId, searchRequestIndex, compositeScore,
									iScoreAxis, iScorePos, iScoreVal, existCount ){

	    def candXpath =  createCandidateXpath(hitFlag, externalId, fusionScore, candidateTemplateCount,
									containerId, eventId, searchRequestIndex, compositeScore,
									iScoreAxis, iScorePos, iScoreVal )

        return [ "${candXpath}": "${existCount}" ]
    }

    // Override
	def createCandidateXpath(hitFlag, externalId, fusionScore, candidateTemplateCount,
							containerId, eventId, searchRequestIndex, compositeScore,
							individualScoreAxis, individualScoreFingerNumber,
						 	individualScoreValue ){

        if(hitFlag == null) {
            hitFlag = false
        }

        return """count(//candidate[
                externalId='${externalId}'
                and @hit='${hitFlag}'
                and fusion-score='${fusionScore}'
                and candidate-template[
                        containerId='${containerId}'
                        and eventId='${eventId}'
                        and searchRequestIndex='${searchRequestIndex}'
                        and not(fusionWeight)
                        and composite-score='${compositeScore}'
                        and individual-score[ 
                            not(@axis)
                            and not(@search-position)
                            and @position='${individualScoreFingerNumber}' 
                            and @value='${individualScoreValue}' 
                            and @inquirySet='PC2_Rolled'
                            and @fusionWeight='100'
                        ]
                    ]
                ])""" 
	}

}

