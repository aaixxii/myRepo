package test.degrade.assertion.xml

class TiSearchXpathMapper extends AbstractSearchXpathMapper {
	
	public TiSearchXpathMapper(){}

	public TiSearchXpathMapper(context){
		super(context)
	}

	protected String makeIScoreCondition(List iScore, int index){
		def iScoreVal = iScore[0]
		def iScorePos = iScore[1]
		def iScoreInqSet = iScore[2]
		def iScoreFw = iScore[3]

		return """
						and individual-score[${index}][
							not(@axis)
							and not(@search-position)
							and @position='${iScorePos}' 
							and @value='${iScoreVal}' 
							and @inquirySet='${iScoreInqSet}' 
			                and @fusionWeight='${iScoreFw}'
						]\n"""
	}

	protected String makeCmlIScoreCondition(List iScore, int index){
		def	iScoreVal = iScore[0]
		def	iScorePos = iScore[1]
		def	iScoreInqSet = iScore[2]
		def	iScoreFw = iScore[3]
		def iScoreSPos
		if(iScore.size() == 4){
			iScoreSPos = iScore[1]
		}else if(iScore.size() == 5){
			iScoreSPos = iScore[4]
		}

		return """
						and individual-score[${index}][
							not(@axis)
							and @search-position='${iScoreSPos}'
							and @position='${iScorePos}' 
							and @value='${iScoreVal}' 
							and @inquirySet='${iScoreInqSet}' 
			                and @fusionWeight='${iScoreFw}'
						]\n"""
	}
}

