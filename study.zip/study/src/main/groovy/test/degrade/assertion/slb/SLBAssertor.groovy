package test.degrade.assertion.slb

import test.degrade.evidence.*
import test.degrade.management.*
import test.degrade.util.*
import test.degrade.properties.*
import test.common.util.db.*
import test.common.message.*
import common.os.linux.*
import common.util.*
import common.sql.*

class SLBAssertor {
	private static final String SELECT_MU_SEG_SQL = """
				select 
					ms.mu_id, 
					ms.segment_id 
				from 
					mu_segments ms, match_units mu 
				where 
					ms.mu_id = mu.mu_id and mu.type = 0
                order by 1"""
	private static final String SELECT_DM_SEG_SQL = """
				select 
					ms.mu_id, 
					ms.segment_id 
				from 
					mu_segments ms, match_units mu 
				where 
					ms.mu_id = mu.mu_id and mu.type = 2
                order by 1"""
	GlobalProperties globalProperties
	SoapuiObject soapuiObject
	SqlExecutor sqlExecutor
	SegmentLoadBalance segmentLoadBalance
	String mmIp
	String mmUser
	String mmPass
	String mmHome
	String sshShell
	String testName


    SLBAssertor(context, String testName){
		this.globalProperties = new GlobalProperties(context)
		this.soapuiObject = new SoapuiObject(context)
		this.sqlExecutor = new SqlExecutorFactory(soapuiObject.getContext()).create()
		this.segmentLoadBalance = new SegmentLoadBalance(context)
		this.testName = testName
		this.mmIp = globalProperties.getMmIp()
		this.mmUser = globalProperties.getMmUser()
		this.mmPass = globalProperties.getMmPass()
		this.mmHome = globalProperties.getMmHome()
 		String shellDir = globalProperties.getSubtoolDir()
		this.sshShell = "${shellDir}/common_tools/exec_ssh_cmd_automatically_input_pass.sh"
	}


	public void doAssertion() {
		//assertSegSize()
		//assertWorkingMus()
	}

	public void assertSegCount(expSegCount) {
		def recs = sqlExecutor.getSqlResult(SELECT_MU_SEG_SQL)
		if(recs.size() != expSegCount){
			abendTest("segement count",expSegCount, recs.size())
		}
		outputEvidence(testName, "segment count is correct")
	}

	public void assertDmSegCount(expSegCount) {
		def recs = sqlExecutor.getSqlResult(SELECT_DM_SEG_SQL)
		if(recs.size() != expSegCount){
			abendTest("segement count",expSegCount, recs.size())
		}
		outputEvidence(testName, "segment count is correct")
	}

	public void assertWorkingDms(expCount) {
    	def actCount = segmentLoadBalance.getAllWorkingDmId()
    	if(actCount.size() != expCount){
			abendTest("MatchUnit count",expCount, actCount.size())
		}
		outputEvidence(testName, "Working MatchUnit count is correct")
	}

	public void assertNoWorkingDms(expCount) {
		def actCount = segmentLoadBalance.getNoWorkingDmId()
		if(actCount.size() != expCount){
			abendTest("MatchUnit count",expCount, actCount.size())
		}
		outputEvidence(testName, "Not Working MatchUnit count is correct")
	}

	public void assertWorkingMus(expCount) {
		def actCount = segmentLoadBalance.getAllWorkingMuId()
		if(actCount.size() != expCount){
			abendTest("MatchUnit count",expCount, actCount.size())
		}
		outputEvidence(testName, "Working MatchUnit count is correct")
	}

	public void assertNoWorkingMus(expCount) {
		def actCount = segmentLoadBalance.getNoWorkingMuId()
		if(actCount.size() != expCount){
			abendTest("MatchUnit count",expCount, actCount.size())
		}
		outputEvidence(testName, "Not Working MatchUnit count is correct")
	}

	public void assertHasSegment() {
		def workMus = segmentLoadBalance.getAllWorkingMuId()
		for(workMu in workMus){
			List<Object> muSegList= segmentLoadBalance.gethasSegments(workMu.mu_id)
			if(muSegList.isEmpty()){
				abendTest("MU_ID ${workMu.mu_id} is not has segment!")
			}
		}
		outputEvidence(testName, "All workingMu has segment")
	}

	def assertSLBlogExist() {
		String cmd = "test -e ${mmHome}/server/default/log/slb.log; echo \$?"
		def act = executeMmShell(cmd)
		String exp = 0 as String
		println act[2]
		if(act[2] != exp){
			abendTest("slb.log is not exist!!!")
		}
		outputEvidence(testName, "slb.log is exist")
	}
	
	def executeMmShell(String command) {
		List args = [ mmUser, mmIp, command, mmPass ]
		return new LinuxCommander().doShWithArgs(sshShell, args)
    }

    protected void assertEquals(actual, expected, String testPropName) {
        if(actual != expected) {
            abendTest(testPropName, expected, actual)
		}
    }

    protected void assertEquals(actual, expected, String actualKey, String expectedKey) {
        if(actual != expected) {
            abendTest(expectedKey, actualKey)
        }
    }

	private abendTest(String errMessg) {
		AbendProcessor abendProcessor = new AbendProcessor(soapuiObject.getContext())
		abendProcessor.abendTest(testName, errMessg)
	}

    private void abendTest(def testPropName, def expectedMessg, def actualValue) {
        String errMessg = mkErrMessg(testPropName, expectedMessg, actualValue)
        AbendProcessor abendProcessor = new AbendProcessor(soapuiObject.getContext())
        abendProcessor.abendTest(testName, errMessg)
    }

    private void abendTest(def expectedMessg, def actualValue) {
        String errMessg = mkDiffErrMessg(expectedMessg, actualValue)
        AbendProcessor abendProcessor = new AbendProcessor(soapuiObject.getContext())
        abendProcessor.abendTest(testName, errMessg)
    }

	String outputEvidence(testName, content){
        EvidenceFileOutputor evidenceFileOutputor = new EvidenceFileOutputor(soapuiObject.getContext())
        evidenceFileOutputor.outputTrueMess("${testName} --> ${content}")
    }

    private String mkErrMessg(name, expected, actual){
        return new MessageCreator().mkValueErrMessg(name, expected, actual)
    }

    private String mkDiffErrMessg(expected, actual){
        return new MessageCreator().mkDiffErrMessg(expected, actual)
    }
}
