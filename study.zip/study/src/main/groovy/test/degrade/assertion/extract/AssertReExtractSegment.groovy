package test.degrade.assertion.extract

import test.common.format.ImagePositionConvertor;
import test.degrade.assertion.common.CommonAssertor;
import test.degrade.testitem.helper.ReExtractSegmentHelper

class AssertReExtractSegment extends AssertReExtraction {
	
	private static final String TIM_ROLLED = "TIM_ROLLED"
	private static final String TIM_SLAP = "TIM_SLAP"
	private ReExtractSegmentHelper helper
	private static boolean isRollTest = true
	private static String key = "TIM_ROLLED"
	private int expectedTotalMatchingSize = 4
	private boolean isResetScore = true

    AssertReExtractSegment(context, String testName){
		super(context, testName)
		helper = new ReExtractSegmentHelper(context)
	}
	
	public void assertReExtRoll(String fileName, String extOutputXml){
		isRollTest = true
		key = TIM_ROLLED
		assertReExt(fileName, extOutputXml)
	}
	
	public void assertReExtSlap(String fileName, String extOutputXml){
		isRollTest = false
		key = TIM_SLAP
		assertReExt(fileName, extOutputXml)
	}
	
	private void assertReExt(String fileName, String extOutputXml){
		assertEqualsPc2Min(fileName, extOutputXml)
		List scoreList = helper.getScoreList(key)
		assertEquals(scoreList.size(),expectedTotalMatchingSize, "${key} total matching size")
		for(int i = 0; i < scoreList.size()-1; i++){
			for(int k = i+1; k < scoreList.size(); k++){
				assertNotEquals(scoreList[i], scoreList[k], "${key} score")
			}
		}
		if(isResetScore){
			helper.removeScore(key)
		}
	}

	private assertEqualsPc2Min(String fileName, String extOutputXml) {
		helper.extractPc2FromCmlafTemplate(fileName)
		Node root = new XmlParser().parseText(extOutputXml)
		Node extOutputPayload = root."extraction-outputs-payload"[0]
		Node tenprintOutput = extOutputPayload."tenprint-output"[0]
		for(Node fingerOutput in tenprintOutput."finger-output"){
			int pos = fingerOutput.attribute("pos") as int
			if(isRollTest){
				if(pos > 10){
					continue
				}
			}else{
				if(pos <= 10){
					continue
				}
				pos = ImagePositionConvertor.convertFromNistPos(pos)
			}
			String payloadPc2Min1 = fingerOutput."minutia-data"[0]."binary"[0].text()
			String payloadPc2Min2 = fingerOutput."minutia-data"[1]."binary"[0].text()
			String edamamePc2Min1 = helper.getEdamamePc2B64(fileName, pos, 1)
			String edamamePc2Min2 = helper.getEdamamePc2B64(fileName, pos, 2)
			CommonAssertor assertor = new CommonAssertor(soapuiObject.getContext(), testName)
			assertor.assertEquals(payloadPc2Min1, edamamePc2Min1, "pos=$pos : PC2 minutia fusion 1")
			assertor.assertEquals(payloadPc2Min2, edamamePc2Min2, "pos=$pos : PC2 minutia fusion 2")
		}
	}
	
	public void setIsResetScore(boolean isResetScore){
		this.isResetScore = isResetScore
	}

}
