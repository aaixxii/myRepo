package test.degrade.assertion.search

import test.degrade.evidence.*
import test.degrade.util.SoapuiObject
import test.degrade.management.AbendProcessor
import test.degrade.assertion.AssertCountChecker
import test.degrade.assertion.xml.AssertAimXml
import test.degrade.assertion.xml.AssertAimXmlValue
import test.degrade.assertion.xml.XpathMapper

class AimSearchResultAssertor {

    private SoapuiObject soapuiObj
    String titleForEvidence
    String successMessgForEvidence
    int expReadCnt
    int expMatchCnt
    int expCandCnt
    int expCandTmpCnt
    int expIScoreCnt
    int expErrCnt
    int expErrCode
    String expErrMessg
    List expCandList
    String callbackXml
    int id = 0
    XpathMapper xpathMapper

    public AimSearchResultAssertor(context) {
        this.soapuiObj = new SoapuiObject(context)
    }

    public void doAssert(){
        outputXml()
        assertXsdSchema()
        assertXmlValue()
        outputEvidence()
        addAssertCount()
    }

    private void outputXml(){
        def xmlOutputor
        if(id != 0) {
            xmlOutputor = new EvidenceXmlOutputor(soapuiObj.getContext(), id)
        }else{
            xmlOutputor = new EvidenceXmlOutputor(soapuiObj.getContext(), titleForEvidence)
        }
        xmlOutputor.outputXml(callbackXml)
    }

    private void assertXsdSchema(){
        def assertAimXml = new AssertAimXml(soapuiObj.getContext(), titleForEvidence, callbackXml, titleForEvidence)
        assertAimXml.assertXsdSchem()
    }

    private void outputEvidence(){
        def evidenceFileOutputor = new EvidenceFileOutputor(soapuiObj.getContext())
        if(expErrCnt == 0){        
			if(id != 0) {
				evidenceFileOutputor.outputTrueMess("${id} : ${titleForEvidence} --> ${successMessgForEvidence}")
			}else{
				evidenceFileOutputor.outputTrueMess("${titleForEvidence} --> ${successMessgForEvidence}")
			}
        }else{
            evidenceFileOutputor.outputTrueMess("${titleForEvidence} --> ${expErrMessg}")
        }  
    }

    private void addAssertCount(){
        new AssertCountChecker(soapuiObj.getContext()).addAssertCount()
    }

    private void assertXmlValue(){
        assertStatistics()
        if(expErrCnt == 0){        
            assertCandidate()
        }else{
            assertErrorCase()
        }  
    }

    private void assertStatistics(){
        def xpathValueMap = xpathMapper.createStatisitcsXpathMap(expReadCnt, expMatchCnt, expCandCnt, expCandTmpCnt, expIScoreCnt, expErrCnt)
        def xmlchecker = new AssertAimXmlValue(callbackXml)
        def xmlAssertResult = xmlchecker.assertXMLLoose(xpathValueMap)
        assertResultTrue(xmlAssertResult)
    }

    private void assertCandidate(){
        assertCandidateOrder()
        assertCandidateVal()
    }

    private void assertCandidateOrder(){
        def xmlchecker = new AssertAimXmlValue(callbackXml, soapuiObj.getContext())
        xmlchecker.assertCandidateOrder(titleForEvidence)
    }

    private void assertCandidateVal() {
        def xmlchecker = new AssertAimXmlValue(callbackXml, soapuiObj.getContext())
        for(expCand in expCandList){
            def xpathValueMap = xpathMapper.createCandXpathMap(expCand)
            def xmlAssertResult = xmlchecker.assertXMLLoose(xpathValueMap)
            assertResultTrue(xmlAssertResult)
       }
    }

    private assertResultTrue(def xmlAssertResult) {
        if(!xmlAssertResult.result){
            if(id != 0) {
                titleForEvidence = "$id : $titleForEvidence"
            }
            new AbendProcessor(soapuiObj.getContext()).abendTest(titleForEvidence, xmlAssertResult)
        }
    }

    private void assertErrorCase(){
        def xmlchecker = new AssertAimXmlValue(callbackXml, soapuiObj.getContext())
        def xpathValueMap = xpathMapper.createErrCaseXpathMap(expErrMessg, expErrCode)
        def xmlAssertResult = xmlchecker.assertXMLLoose(xpathValueMap)
        assertResultTrue(xmlAssertResult)
    }
}
