package test.degrade.assertion.exception

import test.common.constants.aim.*
import test.common.xml.*
import test.degrade.assertion.xml.*
import test.degrade.evidence.*
import test.degrade.management.*
import test.degrade.properties.*
import test.degrade.util.*
import test.common.util.assertion.AssertUtil

import common.callback.*
import common.util.*
import common.xml.*

class AssertExceptionCase{

	def globalProperties
	def soapuiObject
	def xmlString
	def assertType
	def testPatternName
    def looseAssertionMode = false

	def AssertExceptionCase(xmlString, context){
		this.xmlString = xmlString
		globalProperties = new GlobalProperties(context)
		soapuiObject = new SoapuiObject(context)
	}

	def assertExceptionOccurrence(testPatternName, assertType, expectedMessg, expectedCode){
		this.assertType = assertType
		this.testPatternName = testPatternName
		assertExceptionOccurrence(expectedMessg, expectedCode)
	}

	def assertExceptionOccurrence(expectedMessg, expectedCode){
		assertAIMFaultElementSize()
		assertFaultString(expectedMessg)
		assertAIMFaultState()
		assertAIMFaultCode(expectedCode as String)
		assertAIMFaultDescription(expectedMessg)
		outputEvidenceFile(getAIMFaultDescription())
	}

	private assertAIMFaultState() {
		def faultResult = checkAIMFaultState()
		if(faultResult.result == false){
			abendTest("Invalid AIMFault state. expected 'ERROR' but actual '${getAIMFaultState()}'")
		}
	}

	private assertAIMFaultCode(expectedCode) {
		def faultResult = checkAIMFaultCode(expectedCode)
		if(faultResult.result == false){
			abendTest("Invalid AIMFault code. expected '${expectedCode}' but actual '${getAIMFaultCode()}'")
		}
	}

	private assertAIMFaultDescription(expectedMessg) {
		def faultResult = checkAIMFaultDescription(expectedMessg)
		if(faultResult.result == false){
			abendTest("Invalid AIMFault description message. expected '${expectedMessg}' but actual '${getAIMFaultDescription()}'")
		}
	}

	private assertFaultString(expectedMessg) {
		def faultResult = checkAIMFaultDescription(expectedMessg)
		if(faultResult.result == false){
			abendTest("Invalid faultstring message. expected '$expectedMessg' but actual '${getFaultString()}'")
		}
	}

	private assertWildFlyFaultString(expectedMessg) {
        String faultstring = getFaultString()
        def assertor = new AssertUtil(soapuiObject.getContext(), testPatternName)
        assertor.assertEquals(expectedMessg, faultstring, "faultstring")
		outputEvidenceFile(faultstring)
	}

	private assertAIMFaultElementSize() {
		def faultResult = checkFaultElementSize(assertType)
		if(faultResult.result == false){
			abendTest()
		}
	}

	def assertExceptionNotOccurence(testPatternName, assertType, expectedMessg){
		this.testPatternName = testPatternName
		assertExceptionNotOccurence(assertType, expectedMessg)
	}

	def assertExceptionNotOccurence(assertType, expectedMessg){
		def faultResult = checkFaultElementSize(assertType)
		if(faultResult.result == true){
			abendTest()
		}
		outputEvidenceFile("getBinary successed")
	}

	def checkFaultElementSize(assertType){
		if(!isExistsAIMFaultElement()){
			if(assertType == "search"){
				def waitCallbacker = new WaitCallbacker(globalProperties.getCallbackPort())
				waitCallbacker.waitCallback()
			}
			return new ResultMapper(false, 0)
		}
		return new ResultMapper(true, 1)
	}

	def boolean isExistsAIMFaultElement(){
		Map expectedXpathMap = new AimExceptionXpathMapper().createAIMFaultCountXpathMap()
		return isEqualXpathMap(xmlString, expectedXpathMap)
	}

	def boolean isEqualXpathMap(String actualXmlString, Map expectedXpathMap){
		AssertAimInvalidResponseXmlValue xmlChecker = new AssertAimInvalidResponseXmlValue(actualXmlString)
		XMLAssertResult xmlAssertResult = xmlChecker.assertXMLLoose(expectedXpathMap)
		return xmlAssertResult.result
	}

	def checkAIMFaultState(){
		Map expectedXpathMap = new AimExceptionXpathMapper().createAIMFaultStateXpathMap()
		return checkXmlValue(expectedXpathMap)
	}

	def checkAIMFaultCode(String expectedCode){
		Map expectedXpathMap = new AimExceptionXpathMapper().createAIMFaultCodeXpathMap(expectedCode)
		return checkXmlValue(expectedXpathMap)
	}

	def checkAIMFaultDescription(String expectedMessg){
		Map expectedXpathMap = createAIMFaultDescXpathMap(expectedMessg)
		return checkXmlValue(expectedXpathMap)
	}

	def checkFaultString(String expectedMessg){
		Map expectedXpathMap = createFaultStringXpathMap(expectedMessg)
		return checkXmlValue(expectedXpathMap)
	}

	private checkXmlValue(Map expectedXpathMap) {
		if(isEqualXpathMap(xmlString, expectedXpathMap)){
			return new ResultMapper(true, 1)
		}else{
			return new ResultMapper(false, 0)
		}
	}

	def createAIMFaultDescXpathMap(String expectedMessg){
		if(expectedMessg == MMMessenger.JAVA_SQL_EXCEPTION || looseAssertionMode){
			return new AimExceptionXpathMapper().createStartWithAIMFaultDescriptionXpathMap(expectedMessg, "true")
		}else{
			return new AimExceptionXpathMapper().createAIMFaultDescriptionXpathMap(expectedMessg)
		}
	}

	def createFaultStringXpathMap(String expectedMessg){
		if(expectedMessg == MMMessenger.JAVA_SQL_EXCEPTION || looseAssertionMode){
			return new AimExceptionXpathMapper().createStartWithFaultStringXpathMap(expectedMessg, "true")
		}else{
			return new AimExceptionXpathMapper().createAIMFaultDescriptionXpathMap(expectedMessg)
		}
	}

	def getFaultString(){
		return XMLUtil.getElementValue("//faultstring", xmlString)
	}

	def getAIMFaultState(){
		return XMLUtil.getElementValue("//" + AIMXmlElement.AIM_FAULT + "/state", xmlString)
	}

	def getAIMFaultCode(){
		return XMLUtil.getElementValue("//" + AIMXmlElement.AIM_FAULT + "/code", xmlString)
	}

	def getAIMFaultDescription(){
		return XMLUtil.getElementValue("//" + AIMXmlElement.AIM_FAULT + "/description", xmlString)
	}

	def abendTest(){
		def abendProcessor = new AbendProcessor(soapuiObject.getContext())
		abendProcessor.abendTest(testPatternName, "job was finished normally. (expected to error.)")
	}

	def abendTest(message){
		def abendProcessor = new AbendProcessor(soapuiObject.getContext())
		abendProcessor.abendTest(testPatternName, message)
	}

	def outputEvidenceFile(messg){
		def evidenceFileOutputor = new EvidenceFileOutputor(soapuiObject.getContext())
		evidenceFileOutputor.outputTrueMess("${testPatternName} --> ${messg}")
	}
}

