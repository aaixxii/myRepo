package test.degrade.assertion.extract

import test.degrade.evidence.*
import test.degrade.util.SoapuiObject
import test.degrade.management.AbendProcessor
import test.degrade.assertion.AssertCountChecker
import test.degrade.assertion.xml.*

class AimExtractResultAssertor {

    private SoapuiObject soapuiObj
    String titleForEvidence
    String successMessgForEvidence
    int expErrCnt
    int expErrCode
    String expErrMessg
    String callbackXml
    XpathMapper xpathMapper
    boolean isCallbackAssertion = true
    int id = 0

    public AimExtractResultAssertor(context) {
        this.soapuiObj = new SoapuiObject(context)
        this.xpathMapper = new XpathMapper()
    }

    public void doAssert(){
        outputXml()
        assertXsdSchema()
        assertXmlValue()
        outputEvidence()
        addAssertCount()
    }

    private void outputXml(){
        def xmlOutputor
        if(id != 0) {
            xmlOutputor = new EvidenceXmlOutputor(soapuiObj.getContext(), id)
        }else{
            xmlOutputor = new EvidenceXmlOutputor(soapuiObj.getContext(), titleForEvidence)
        }
        xmlOutputor.outputXml(callbackXml)
    }

    private void assertXsdSchema(){
        if(!isCallbackAssertion) {
            println "This assertion is against extract response values. Skip xsd assertion..."
            return
        }
        def assertAimXml = new AssertAimXml(soapuiObj.getContext(), titleForEvidence, callbackXml, titleForEvidence)
        assertAimXml.assertXsdSchem()
    }

    private void outputEvidence(){
        def evidenceFileOutputor = new EvidenceFileOutputor(soapuiObj.getContext())
        evidenceFileOutputor.outputTrueMess("${titleForEvidence} --> ${successMessgForEvidence}")
    }

    private void addAssertCount(){
        new AssertCountChecker(soapuiObj.getContext()).addAssertCount()
    }

    private void assertXmlValue(){
        if(expErrCnt == 0){        
            //assertSuccess() // In future function
        }else{
            assertErrorCase()
        }  
    }

    private assertResultTrue(def xmlAssertResult) {
        if(!xmlAssertResult.result){
            new AbendProcessor(soapuiObj.getContext()).abendTest(titleForEvidence, xmlAssertResult)
        }
    }

    private void assertErrorCase(){
        def xmlchecker
        def xpathValueMap
        if(isCallbackAssertion) {
            xpathValueMap = xpathMapper.createErrCaseXpathMap(expErrMessg, expErrCode)
            xmlchecker = new AssertAimXmlValue(callbackXml, soapuiObj.getContext())
        }else{
            xpathValueMap = new AimExceptionXpathMapper().createErrXpathMap(expErrMessg, expErrCode)
            xmlchecker = new AssertAimInvalidResponseXmlValue(callbackXml, soapuiObj.getContext())
        }
        def xmlAssertResult = xmlchecker.assertXMLLoose(xpathValueMap)
        assertResultTrue(xmlAssertResult)
    }
}
