package test.degrade.assertion.xml

class LfmlSearchXpathMapper extends AbstractSearchXpathMapper {
	
	public LfmlSearchXpathMapper(){}

	public LfmlSearchXpathMapper(context){
		super(context)
	}

	protected String makeIScoreCondition(List iScore, int index){
		def iScoreVal = iScore[0]
		def iScorePos = iScore[1]
		def iScoreInqSet = iScore[2]
		def iScoreFw = iScore[3]

		return """
						and individual-score[${index}][
							not(@axis)
							and not(@search-position)
							and @position='${iScorePos}' 
							and @value='${iScoreVal}' 
							and @inquirySet='${iScoreInqSet}' 
			                and @fusionWeight='${iScoreFw}'
						]\n"""
	}
}

