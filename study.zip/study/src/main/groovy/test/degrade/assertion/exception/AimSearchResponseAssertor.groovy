package test.degrade.assertion.exception

import static test.degrade.constants.soapui.SoapuiDefines.*
import test.degrade.assertion.AssertCountChecker
import test.common.message.MessageCreator
import test.common.message.ConvertErrorMessageCreator


import test.degrade.evidence.*
import test.degrade.util.SoapuiObject

class AimSearchResponseAssertor{
    private static final String SEARCH = "search"
    private static final int CONVERTOR_ERR_CODE = 814000313
    int testId
    int expErrCode
    String expErrMessg
    String titleForEvidenceFile
    String searchTestSuiteName
    String searchTestCaseName
    String searchTestStepName
    SoapuiObject soapuiObj
    boolean looseAssertionMode = false

    public AimSearchResponseAssertor(context) {
        this.soapuiObj = new SoapuiObject(context)
        this.searchTestSuiteName = COMMON_TEST_SUITE_NAME
    }

    public void assertGenderFaultResponse(String propVal) {
        expErrMessg = new MessageCreator().mkInvalidGenderMessg(propVal)
        assertConvertErrResponse()
    }

    public void assertRaceFaultResponse(String propVal) {
        expErrMessg = new MessageCreator().mkInvalidRaceMessg(propVal)
        assertConvertErrResponse()
    }

    public void assertRegionFaultResponse(String propVal) {
        expErrMessg = new MessageCreator().mkInvalidRegionMessg(propVal)
        assertConvertErrResponse()
    }

    public void assertTimRotationLimitFaultResponse(String propVal) {
        expErrMessg = new ConvertErrorMessageCreator().createTimRotationErrMessg(propVal)
        assertConvertErrResponse()
    }

    public void assertRotationLimitFaultResponse(String propVal) {
        expErrMessg = new MessageCreator().mkInvalidRotationLimitMessg(propVal)
        assertConvertErrResponse()
    }

    public void assertSpeedLevelFaultResponse(String propVal) {
        expErrMessg = new ConvertErrorMessageCreator().getSpeedLevelErrMessg(propVal)
        assertConvertErrResponse()
    }

    public void assertDistortionLevelFaultResponse(String propVal) {
        expErrMessg = new ConvertErrorMessageCreator().getDistortionLevelErrMessg(propVal)
        assertConvertErrResponse()
    }

    public void assertSelectPartsFaultResponse(String propVal) {
        expErrMessg = new ConvertErrorMessageCreator().createInvalidSelectPartsErrMessg(propVal)
        assertConvertErrResponse()
    }

    public void assertPatternThFaultResponse(String propVal) {
        expErrMessg = new ConvertErrorMessageCreator().createFilterModeErrMessg(propVal)
        assertConvertErrResponse()
    }

    public void assertFilterModeFaultResponse(String propVal) {
        expErrMessg = new ConvertErrorMessageCreator().createFilterModeErrMessg(propVal)
        assertConvertErrResponse()
    }

    public void assertTooManyFingerThFaultResponse(String propVal) {
        expErrMessg = new ConvertErrorMessageCreator().createTooManyFingerThErrMessg()
        assertConvertErrResponse()
    }

    public void assertFinSelectionModeFaultResponse(String propVal) {
        expErrMessg = new ConvertErrorMessageCreator().createFinSelectionModeErrMessg(propVal)
        assertConvertErrResponse()
    }

    public void assertNoPatternThFaultResponse() {
        expErrMessg = new ConvertErrorMessageCreator().getLostAttributeErrMesseg("patternThreshold", "fingers-thresholds")
        assertConvertErrResponse()
    }

    public void assertNoCardScoreThFaultResponse() {
        expErrMessg = new ConvertErrorMessageCreator().getLostAttributeErrMesseg("cardScoreThreshold", "fingers-thresholds")
        assertConvertErrResponse()
    }

    public void assertNoMateProbabilityThFaultResponse() {
        expErrMessg = new ConvertErrorMessageCreator().getLostAttributeErrMesseg("mateProbabilityThreshold", "fingers-thresholds")
        assertConvertErrResponse()
    }

    public void assertNoFinalScoreThFaultResponse() {
        expErrMessg = new ConvertErrorMessageCreator().getLostAttributeErrMesseg("finalScoreThreshold", "fingers-thresholds")
        assertConvertErrResponse()
    }

    public void assertNoSpeedLevelFaultResponse() {
        expErrMessg = new ConvertErrorMessageCreator().getLostAttributeErrMesseg("speedLevel", "fingers-thresholds")
        assertConvertErrResponse()
    }

    public void assertIrisSearchModeFaultResponse(String propVal) {
        expErrMessg = new ConvertErrorMessageCreator().getIrisSearchModeErrMessg(propVal)
        assertConvertErrResponse()
    }

    public void assertInvalidSearchKeyFaultResponse() {
        expErrMessg = new ConvertErrorMessageCreator().createInvalidKeyErrMessg()
        assertConvertErrResponse()
    }

    public void assertInvalidSearchConIdFaultResponse() {
        expErrMessg = new ConvertErrorMessageCreator().createInvalidConIdErrMessg()
        assertConvertErrResponse()
    }

    public void assertTooManyFusionJobFaultResponse() {
        expErrMessg = new ConvertErrorMessageCreator().createNumberOfSearchRequestErrMessg()
        assertConvertErrResponse()
    }

    public void assertDuplicateConIdsFaultResponse() {
        expErrMessg = new ConvertErrorMessageCreator().createDuplicateConIdsErrMessg()
        assertConvertErrResponse()
    }

    public void assertMaxCandidatesFaultResponse() {
        expErrMessg = new MessageCreator().mkOutOfRangeMaxCandMessg()
        expErrCode = 814001107
        assertFaultResponse()
    }

    public void assertMinScoreFaultResponse() {
        expErrMessg = new MessageCreator().mkOutOfRangeMinScoreMessg()
        expErrCode = 814001108
        assertFaultResponse()
    }

    public void assertDynFaultResponse() {
        expErrMessg = new MessageCreator().mkOutOfRangeDynMessg()
        expErrCode = 814001109
        assertFaultResponse()
    }

    public void assertDynPPFaultResponse() {
        expErrMessg = new MessageCreator().mkOutOfRangeDTPMessg()
        expErrCode = 814001110
        assertFaultResponse()
    }

    public void assertPriorityFaultResponse() {
        expErrMessg = new MessageCreator().mkOutOfRangePriorityMessg()
        expErrCode = 814001106
        assertFaultResponse()
    }

    public void assertContainerIdFaultResponse(int inputCId) {
        expErrMessg = new MessageCreator().mkNonExistContainerIdMessg(inputCId as String)
        expErrCode = 814001902
        assertFaultResponse()
    }

    public void assertSearchKeyDuplicateFaultResponse() {
        expErrMessg = new MessageCreator().mkSearchKeyDuplicateErrMessg()
        expErrCode = 814001121
        assertFaultResponse()
    }

    public void assertInvaliSearchRefKeyFaultResponse() {
        expErrMessg = new MessageCreator().mkCannotFetchTemplateErrMessg()
        expErrCode = 814001103
        assertFaultResponse()
    }

    public void assertDuplicateSearchScopeFaultResponse() {
        expErrMessg = new MessageCreator().mkDuplicateSearchScopeErrMessg()
        expErrCode = 814001120
        assertFaultResponse()
    }

    public void assertDuplicateSearchTargetFinTypeFaultResponse() {
        expErrMessg = new MessageCreator().mkDuplicateSearchTargetFinTypeErrMessg()
        expErrCode = 814001112
        assertFaultResponse()
    }

    public void assertInvalidCombSearchFileParamFaultResponse(String funcName, String templateFmtName, String sFinPrint, String fFinPrint) {
        expErrMessg = new MessageCreator().mkInvalidCombSearchFileParamErrMessg(funcName, templateFmtName, sFinPrint, fFinPrint)
        expErrCode = 814001119
        assertFaultResponse()
    }

    public void assertConvertErrResponse() {
        expErrCode = CONVERTOR_ERR_CODE
        assertFaultResponse()
    }

    public void assertFaultResponse() {
        def testCase = soapuiObj.getTestCaseInOtherSuite(searchTestSuiteName, searchTestCaseName)
        def testStep = testCase.getTestStepByName(searchTestStepName)
		//getAssertableContentAsXml() is not support SoapUI 4.5.1
		//String responseXml = testStep.getAssertableContentAsXml()
		String responseXml = testStep.getAssertableContent()
        outputXml(responseXml)
        assertSoapResponse(responseXml)
        new AssertCountChecker(soapuiObj.getContext()).addAssertCount()
    }

    public void assertWildFlyFaultString(String expectedMessg, String responseXml){
        def assertExceptionCase = new AssertExceptionCase(responseXml, soapuiObj.getContext())
        assertExceptionCase.assertWildFlyFaultString(expectedMessg)
        new AssertCountChecker(soapuiObj.getContext()).addAssertCount()
    }

    private void assertSoapResponse(String responseXml){
        def assertExceptionCase = new AssertExceptionCase(responseXml, soapuiObj.getContext())
        assertExceptionCase.looseAssertionMode = this.looseAssertionMode
        assertExceptionCase.setAssertType(SEARCH)
        assertExceptionCase.setTestPatternName(titleForEvidenceFile)
        assertExceptionCase.assertExceptionOccurrence(expErrMessg, expErrCode)
    }

    private void outputXml(String responseXml){
        def xmlOutputor
        if(testId != null) {
            xmlOutputor = new EvidenceXmlOutputor(soapuiObj.getContext(), testId)
        }else{
            xmlOutputor = new EvidenceXmlOutputor(soapuiObj.getContext())
        }
        xmlOutputor.outputXml(responseXml)
    }
}

