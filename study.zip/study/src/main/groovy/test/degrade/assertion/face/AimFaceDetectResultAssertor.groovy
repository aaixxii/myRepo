package test.degrade.assertion.face

import test.degrade.evidence.*
import test.degrade.util.SoapuiObject
import test.degrade.management.AbendProcessor
import test.degrade.assertion.AssertCountChecker
import test.degrade.assertion.xml.*

class AimFaceDetectResultAssertor {

    private SoapuiObject soapuiObj
    String titleForEvidence
    String successMessgForEvidence
    int expErrCnt
    int expErrCode
    String expErrMessg
    String callbackXml
    XpathMapper xpathMapper
    boolean isCallbackAssertion = true
    def  id = 0
	List keyList
	int exptectedKeyedBinaryCnt
	int exptectedTotalKeyedBinaryCnt
	int expectedFaceOutputCnt
	int expectedFaceDetectionCnt

    public AimFaceDetectResultAssertor(context) {
		this.soapuiObj = new SoapuiObject(context)
        this.xpathMapper = new XpathMapper()
    }

    public void doAssert(){
        outputXml()
        assertXsdSchema()
        assertXmlValue()
		assertXmlDiff()
        outputEvidence()
        addAssertCount()
    }

    private void outputXml(){
        def xmlOutputor
        if(id != 0) {
            xmlOutputor = new EvidenceXmlOutputor(soapuiObj.getContext(), id)
        }else{
            xmlOutputor = new EvidenceXmlOutputor(soapuiObj.getContext(), titleForEvidence)
        }
        xmlOutputor.outputXml(callbackXml)
    }

    private void assertXsdSchema(){
        if(!isCallbackAssertion) {
            println "This assertion is against extract response values. Skip xsd assertion..."
            return
        }
        def assertAimXml = new AssertAimXml(soapuiObj.getContext(), titleForEvidence, callbackXml, titleForEvidence)
        assertAimXml.assertXsdSchem()
    }

    private void outputEvidence(){
        def evidenceFileOutputor = new EvidenceFileOutputor(soapuiObj.getContext())
        evidenceFileOutputor.outputTrueMess("${titleForEvidence} --> ${successMessgForEvidence}")
    }

    private void addAssertCount(){
        new AssertCountChecker(soapuiObj.getContext()).addAssertCount()
    }

    private void assertXmlValue(){
        if(expErrCnt == 0){        
            assertSuccess()
        }else{
            assertErrorCase()
        }  
    }

    private assertResultTrue(def xmlAssertResult) {
        if(!xmlAssertResult.result){
            new AbendProcessor(soapuiObj.getContext()).abendTest(titleForEvidence, xmlAssertResult)
        }
    }

	private void assertSuccess(){
		def xmlchecker = new AssertAimXmlValue(callbackXml, soapuiObj.getContext())	
		def xpathMapper = new FaceXpathMapper()
		def xpathValueMap
		def xmlAssertResult
		for(key in keyList){
			xpathValueMap = xpathMapper.createCallbackExtractResultKeyedBinaryXpath(key, exptectedKeyedBinaryCnt)
			xmlAssertResult = xmlchecker.assertXMLLoose(xpathValueMap)
			if(xmlAssertResult.result == false){
				new AbendProcessor(soapuiObj.getContext()).abendTest(titleForEvidence, xmlAssertResult)
			}
		}

		xpathValueMap = xpathMapper.createExtractResultFaceOutputSizeXpath(expectedFaceOutputCnt)
		xmlAssertResult = xmlchecker.assertXMLLoose(xpathValueMap)
		if(xmlAssertResult.result == false){
			new AbendProcessor(soapuiObj.getContext()).abendTest(titleForEvidence, xmlAssertResult)
		}
		
		xpathValueMap = xpathMapper.createExtractResultKeyedBinarySizeXpath(exptectedTotalKeyedBinaryCnt)
		xmlAssertResult = xmlchecker.assertXMLLoose(xpathValueMap)
		if(xmlAssertResult.result == false){
			new AbendProcessor(soapuiObj.getContext()).abendTest(titleForEvidence, xmlAssertResult)
		}	
		
		xpathValueMap = xpathMapper.createFaceDetectionPointsSizeXpath(expectedFaceDetectionCnt)
		xmlAssertResult = xmlchecker.assertXMLLoose(xpathValueMap)
		if(xmlAssertResult.result == false){
			new AbendProcessor(soapuiObj.getContext()).abendTest(titleForEvidence, xmlAssertResult)
		}	
	}

    private void assertErrorCase(){
        def xmlchecker
        def xpathValueMap
        if(isCallbackAssertion) {
            xpathValueMap = xpathMapper.createErrCaseXpathMap(expErrMessg, expErrCode)
            xmlchecker = new AssertAimXmlValue(callbackXml, soapuiObj.getContext())
        }else{
            xpathValueMap = new AimExceptionXpathMapper().createErrXpathMap(expErrMessg, expErrCode)
            xmlchecker = new AssertAimInvalidResponseXmlValue(callbackXml, soapuiObj.getContext())
        }
        def xmlAssertResult = xmlchecker.assertXMLLoose(xpathValueMap)
        assertResultTrue(xmlAssertResult)
    }

	private void assertXmlDiff(){
		def assertAimXml = new AssertAimXml(soapuiObj.getContext(), titleForEvidence, callbackXml, id)
		assertAimXml.assertExtractResultXmlDiff()
	}
}
