package test.degrade.assertion.common

import test.common.message.*
import test.degrade.util.*
import test.degrade.management.*

class CommonAssertor {
	SoapuiObject soapuiObject
	String testName

    CommonAssertor(context, String testName){
		this.soapuiObject = new SoapuiObject(context)
		this.testName = testName
	}

	private String mkErrMessg(name, expected, actual){
		return new MessageCreator().mkValueErrMessg(name, expected, actual)
	}

	public void assertEquals(def expected, def actual, String testPropName) {
		if(actual != expected) {
			abendTest(testPropName, expected, actual)
		}
	}
	
	public void assertNotEquals(def expected, def actual, String testPropName) {
		if(actual == expected) {
			abendTest(testPropName, "not equals $expected", actual)
		}
	}


	public void assertSmaller(def expected, def actual, String testPropName) {
		if(actual > expected) {
			abendTest(testPropName, "smaller than $expected", actual)
		}
	}

	private void abendTest(def testPropName, def expectedValue, def actualValue) {
		String errMessg = mkErrMessg(testPropName, expectedValue, actualValue)
		AbendProcessor abendProcessor = new AbendProcessor(soapuiObject.getContext())
		abendProcessor.abendTest(testName, errMessg)
	}
}
