package test.degrade.assertion.xml

class PalmSearchXpathMapper extends AbstractSearchXpathMapper {
	
	public PalmSearchXpathMapper(){}

	public PalmSearchXpathMapper(context){
		super(context)
	}

	protected String makeIScoreCondition(List iScore, int index){
		def iScoreVal = iScore[0]
		def iScorePos = iScore[1]

		return """
						and individual-score[${index}][
							@position='${iScorePos}' 
							and @value='${iScoreVal}' 
							and not(@axis)
							and not(@search-position)
							and not(@inquirySet)
							and not(@fusionWeight)
						]\n"""
	}
}

