package test.degrade.assertion.log.mu

import test.common.util.mu.*
import test.common.util.db.*
import test.common.message.*
import test.common.constants.aim.*
import test.degrade.util.*
import test.degrade.management.*


class AssertMuLogValue extends AIMWord{

	MatchUnit mu
	def soapuiObject 
	def final String FINGER_SELECTION_MODE	= "fingerSelectionMode"
	def final String QR						= "QR"
	def final String SEARCH_MODE			= "searchMode"
	def final String ALGORITHM				= "algorithm"
	def final String ROTATION_LIMIT			= "rotationLimit"
	def final String DISTORTION_LEVEL		= "distortionLevel"
	def final String CORE_POSITION			= "corePosition"
	def final String SPEED_LEVEL			= "speedLevel"
	def final String SEARCH_LEVEL			= "searchLevel"
	def final String SPEED_LEVEL_PRIMARY 		= "speedLevelPrimary"
	def final String SPEED_LEVEL_SECONDARY 		= "speedLevelSecondary"
	def final String ROTATION_LIMIT_PRIMARY		= "rotationLimitPrimary"
	def final String ROTATION_LIMIT_SECONDARY	= "rotationLimitSecondary"
	def final String DISTORTION_LEVEL_PRIMARY	= "distortionLevelPrimary"
	def final String DISTORTION_LEVEL_SECONDARY	= "distortionLevelSecondary"
	def final String LMT_OF_MIN					= "limitOfMin"	
	def final String FE_TYPE					= "feType"
	def final String EHN_TYPE					= "ehnType"
	def final String NIRIS_EXT_MODE 			= "NirisExtractionMode"
	def final String RDBLM_EXT_PARAM_FILE		= "RDBLMExtParamFile"
	def final String LDBM_EXT_PARAM_FILE		= "LDBMExtParamFile"
	def final String LIM_EXT_PARAM_FILE			= "LIMExtParamFile"
	def final String LLIM_EXT_PARAM_FILE		= "LLIMExtParamFile"
	def final String TLIM_EXT_PARAM_FILE		= "TLIMExtParamFile"
	def logValueList
	def segNum

	AssertMuLogValue(context){
		this.mu = new MatchUnit(context)
		this.soapuiObject = new SoapuiObject(context)
	}

	def assertParameterInMuLog(testPatterns, expectedValues, function, parameter){
		scpMatcherLogsToCurrentDir()
		logValueList = getParameterValueInMuLog(function, parameter)
		assertParamAppearingCntMultipleSegNum(expectedValues.size(), function, parameter)
		assertParameterValue(testPatterns, expectedValues, function, parameter)
	}
	
	def assertLFMLParameterInMuLog(testPatterns, expectedValues, function, parameter, expectedCnt){
		assertLFMLParameterInMuLog(expectedValues, function, parameter, expectedCnt)
	}

	def assertLFMLParameterInMuLog(expectedValues, function, parameter, expectedCnt){
		scpMatcherLogsToCurrentDir()
		logValueList = getParameterValueInMuLog(function, parameter)
		assertParamAppearingCnt(expectedCnt, function, parameter)
		assertParameterValue(null, expectedValues, function, parameter)
	}

	def assertLFMLExtParamInMuLog(List expectedValues, function, parameter){
		scpExtractorLogsToCurrentDir()
		logValueList = getParameterValueInMuLog(function, parameter)
		assertParamAppearingCnt(expectedValues.size(), function, parameter)
		assertParameterValue(expectedValues, function, parameter)
	}

	def assertIrisParameterInMuLog(expectedValues, function, parameter){
		scpMatcherLogsToCurrentDir()
		logValueList = getParameterValueInMuLog(function, parameter)
		assertParamAppearingCntMultipleSegNum(expectedValues.size(), function, parameter)
		assertParameterValue(null, expectedValues, function, parameter)
	}
	
	def assertNIrisExtParamInMuLog(List expectedValues, function, parameter){
		scpExtractorLogsToCurrentDir()
		logValueList = getParameterValueInMuLog(function, parameter)
		assertParamAppearingCnt(expectedValues.size(), function, parameter)
		assertParameterValue(expectedValues, function, parameter)
	}
	
	def assertExtractorParameterInMuLog(testPatterns, expectedValues, function, parameter, expectedValueCount){
		scpExtractorLogsToCurrentDir()
		logValueList = getParameterValueInMuLog(function, parameter)
		assertParamAppearingCntMultipleSegNum(expectedValueCount, function, parameter)
		assertExtractParameterValue(testPatterns, expectedValues, function, parameter)
	}

	def assertCmlafExtLimOfMinParamInMuLog(testPatterns, expectedValues, function, parameter, expectedValueCount){
		scpExtractorLogsToCurrentDir()
		logValueList = getParameterValueInMuLog(function, parameter)
		assertParamAppearingCntMultipleSegNum(expectedValueCount, function, parameter)
		assertCmlafExtLmtOfMinParamVal(testPatterns, expectedValues, function, parameter)
	}

	def assertExtractorCmlafEnhParameterInMuLog(testPatternName, expectedValueFusion1, expectedValueFusion2 ){
		scpExtractorLogsToCurrentDir()
		int extractorSize = mu.getExtractorSize() as int
		assertExtractorCmlafEnhParameter(extractorSize, "ROLL", 0, expectedValueFusion1)
		assertExtractorCmlafEnhParameter(extractorSize, "ROLL", 1, expectedValueFusion2)
		assertExtractorCmlafEnhParameter(extractorSize, "SLAP", 0, expectedValueFusion1)
		assertExtractorCmlafEnhParameter(extractorSize, "SLAP", 1, expectedValueFusion2)
	}

	def assertExtractorCmlafMultiEnhParameterInMuLog(enhType1, enhType2) {
		scpExtractorLogsToCurrentDir()
		int extractorSize = mu.getExtractorSize() as int
		assertExtractorCmlafSpecEnhParameter(extractorSize, "ROLL", 1, enhType1)
		assertExtractorCmlafSpecEnhParameter(extractorSize, "SLAP", 1, enhType1)
		assertExtractorCmlafSpecEnhParameter(extractorSize, "ROLL", 2, enhType2)
		assertExtractorCmlafSpecEnhParameter(extractorSize, "SLAP", 2, enhType2)
	}

	def assertExtractorCmlafSpecEnhParameter(int extractorSize, String fingerType, int fusionId, String enhType) {
		List logValuesList = mu.getExtractOptionSpecEhnTypeFromMuLog(extractorSize, fingerType, fusionId, enhType)
		int listSize = logValuesList.size()
		assertEquals("enh-type: ${enhType} fingerType:${fingerType} extractorSize:${extractorSize} fusionId:${fusionId} appearing count:${listSize}", 10, logValuesList.size())
		assertLogValues(logValuesList, enhType, fusionId)
	}

	def assertExtractorCmlafEnhParameter(int extractorSize, String fingerType, int fusionId, String expectedEnhVal) {
		List logValuesList = mu.getExtractOptionEhnTypeFromMuLog(extractorSize, fingerType, fusionId)
		assertEquals("parameter $expectedEnhVal fusion${fusionId} appearing count", 10, logValuesList.size())
		assertLogValues(logValuesList, expectedEnhVal, fusionId)
	}

	def void assertLogValues(List logValuesList, String expectedEnhVal, int fusionId) {
		for(i in 0..9) {
			List logValList = logValuesList[i].split()
			assertEquals("finger number", i, logValList[0] as int)
			assertEquals("fusion id", fusionId, logValList[1] as int)
			assertEquals("ehnancement value", expectedEnhVal, logValList[2])
		}
	}


	def void scpMatcherLogsToCurrentDir() {
		mu.scpMatcherLogsToHere()
	}
	
	def void scpExtractorLogsToCurrentDir(){
		mu.scpExtractorLogsToHere()
	}

	def assertParamAppearingCntMultipleSegNum(expected, function, parameter){
		segNum = getSegmentNum(function, parameter)
		expected *= segNum
		def actual = logValueList.size()
		assertEquals("${parameter} appearing count", expected, actual)
	}
	
	def assertParamAppearingCnt(expected, function, parameter){
		def actual = logValueList.size()
		assertEquals("${parameter} appearing count", expected, actual)
	}

	def assertEquals(String messg, expected, actual) {
		if(actual != expected){
			def errMessg = mkErrMessg(messg, expected, actual)
			abendTest(errMessg)
		}
	}

	def assertParameterValue(testPatterns, expectedValues, function, parameter){
		def start = 0
		def end   = segNum
		for(int i = 0; i < expectedValues.size(); i++){
			for(int k = start; k < end; k++){
				def value = expectedValues[i]
				if(parameter == "rotationLimitPrimary" || parameter == "rotationLimitSecondary") {
					if(expectedValues[i] == "1") value="10"
					else if(expectedValues[i] == "2") value="21"
					else if(expectedValues[i] == "3") value="43"
					else if(expectedValues[i] == "4") value="128"
					else value = expectedValues[i]
				}
				assertEquals(parameter, value, logValueList[k])
			}
			start += segNum
			end   += segNum
		}
	}

	def assertCmlafExtLmtOfMinParamVal(testPatterns, expectedValues, function, parameter){
		int logValIndex = 0
		for(expectedVal in expectedValues){
			int	loopCnt = 20
			
			for(int i = 0; i < loopCnt; i++){
				assertEquals(parameter, expectedVal, logValueList[logValIndex])
				logValIndex++
			}
		}
	}

	def assertExtractParameterValue(testPatterns, expectedValues, function, parameter){
		def flag = 1
		def start = 0
		def end = 0
		if(expectedValues[0] == "0"){
			flag = 0	
		}

		if(flag == 0){
			end = 4
		}else{
			end = 20
		}

		for(int i = 0; i < expectedValues.size(); i++){
			for(int k = start; k < end; k++){
				def value = expectedValues[i]
				assertEquals(parameter, value, logValueList[k])
			}

			if(flag == 0){
   				start += 4
				flag = 1
	        }else{
            	start += 20
        	}

			end   += 20
		}
	}

	
	def assertParameterValue(expectedValues, function, parameter){
		for(int i = 0; i < expectedValues.size(); i++){
			assertEquals(parameter, expectedValues[i], logValueList[i])
		}
	}

	
	def getParameterValueInMuLog(function, parameter){
		switch (function){
		case TI		: return getFmatchParamValues(parameter)
		case TIM	: return getCmlafParamValues(parameter)
		case LI		: return getLatentLEParamValues(parameter)
		case LLI	: return getLatentLEParamValues(parameter)
		case TLI	: return getTLILEParamValues(parameter)
		case LIS	: return getLatentPC2ParamValues(parameter)
		case LLIS	: return getLatentPC2ParamValues(parameter)
		case TLIS	: return getLatentPC2ParamValues(parameter)
		case LIM	: return getLfmlParamValues(parameter)
		case TLIM	: return getLfmlParamValues(parameter)
		case LLIM	: return getLfmlParamValues(parameter)
		case LIP	: 
		case TLIP	: 
		case LLIP	: return getPalmParamValues(parameter)
		case EXTRACT: return getExtractParamValues(parameter)
		case II    	: return getIrisParamValues(parameter)
		}
	}

	def getSegmentNum(function, parameter){
		switch (function){
		case TI		: if(parameter == FINGER_SELECTION_MODE){ return 1 }
					  else{ return getSegmentNumFromDB(RDBT_ID) }
		case TIM	: return getSegmentNumFromDB(RDBTM_ID, SDBTM_ID)
		case LI		: return getSegmentNumFromDB(RDBL_ID, SDBL_ID)
		case LIM	: return getSegmentNumFromDB(RDBLM_ID)
		case TLIM	: return getSegmentNumFromDB(LDBM_ID)
		case LLIM	: return getSegmentNumFromDB(LDBM_ID)
		case TLI	: return getSegmentNumFromDB(LDB_ID)
		case LLI	: return getSegmentNumFromDB(LDB_ID)
		case LIS	: return getSegmentNumFromDB(RDBLS_ID, SDBLS_ID)
		case LLIS	: return getSegmentNumFromDB(LDBS_ID)
		case TLIS	: return getSegmentNumFromDB(LDBS_ID)
		case LIP	: return getSegmentNumFromDB(PDB_ID)
		case TLIP	: 
		case LLIP	: return getSegmentNumFromDB(PLDB_ID)
		case II	    : return getSegmentNumFromDB(IDB_ID)
		case EXTRACT: return 1
		default		: assert false, "Input parameter '${function}' is unknown type"
		}
	}

	def getSegmentNumFromDB(binId){
		def sqlExecutor = new SqlExecutorFactory(soapuiObject.getContext()).create()
		def sql = """select count(*) from segments s where s.container_id = ${binId}"""
		return sqlExecutor.selectCountSql(sql)
	}

	def getSegmentNumFromDB(binId1, binId2){
		def sqlExecutor = new SqlExecutorFactory(soapuiObject.getContext()).create()
		def sql = """select count(*) from segments s where s.container_id in (${binId1}, ${binId2})"""
		return sqlExecutor.selectCountSql(sql)
	}
		
	// FMatch
	def getFmatchParamValues(parameter){
		def matcherSize = mu.getMatcherSize()
		switch (parameter){
		case FINGER_SELECTION_MODE 	: return mu.getFmatchSelectedFingersFromMuLog(matcherSize)
		case QR					 	: return mu.getFmatchQRFromMuLog(matcherSize)
		case SPEED_LEVEL			: return mu.getFmatchSpeedLevelFromMuLog(matcherSize)
		case ROTATION_LIMIT			: return mu.getFmatchRotationLimitFromMuLog(matcherSize)
		case DISTORTION_LEVEL		: return mu.getFmatchDistortionLevelFromMuLog(matcherSize)
		default 					: assert false, "Input parameter '${parameter}' is unknown type"
		}
	}

	// CMLaF
	def getCmlafParamValues(parameter){
		def matcherSize = mu.getMatcherSize()
		switch (parameter){
		case SEARCH_MODE 		: return mu.getCmlafSearchModeFromMuLog(matcherSize)
		case ROTATION_LIMIT 	: return mu.getCmlafRotationLimitFromMuLog(matcherSize)
		case DISTORTION_LEVEL	: return mu.getCmlafDistortionLevelFromMuLog(matcherSize)
		default 				: assert false, "Input parameter '${parameter}' is unknown type"
		}
	}

	def getPalmParamValues(parameter){
		def matcherSize = mu.getMatcherSize()
		switch (parameter){
		case ROTATION_LIMIT 			: return mu.getPalmRotationLimitFromMuLog(matcherSize)
		case SPEED_LEVEL_PRIMARY  		: return mu.getPalmSpeedLevelPrimaryFromMuLog(matcherSize)
		case SPEED_LEVEL_SECONDARY  	: return mu.getPalmSpeedLevelSecondaryFromMuLog(matcherSize)
		case DISTORTION_LEVEL_PRIMARY  	: return mu.getPalmDistortionLevelPriomaryFromMuLog(matcherSize)
		case DISTORTION_LEVEL_SECONDARY : return mu.getPalmDistortionLevelSecondaryFromMuLog(matcherSize)
		default 						: assert false, "Input parameter '${parameter}' is unknown type"
		}
	}

	def getLatentPC2ParamValues(parameter){
		def matcherSize = mu.getMatcherSize()
		switch (parameter){
		case ROTATION_LIMIT : return mu.getLatentPC2RotationLimitFromMuLog(matcherSize)
		case SPEED_LEVEL : return mu.getLatentPC2SpeedLevelFromMuLog(matcherSize)
		case DISTORTION_LEVEL : return mu.getLatentPC2DistortionLevelFromMuLog(matcherSize)
		default : assert false, "Input parameter '${parameter}' is unknown type"
		}
	}

	def getTLILEParamValues(parameter){
		def matcherSize = mu.getMatcherSize()
		switch (parameter){
		case ALGORITHM 		: return mu.getTLILEAlgorithmFromMuLog(matcherSize)
		case ROTATION_LIMIT : return mu.getTLILERotationLimitFromMuLog(matcherSize)
		case CORE_POSITION 	: return mu.getTLILECorePositionFromMuLog(matcherSize)
		default 			: assert false, "Input parameter '${parameter}' is unknown type"
		}
	}
	def getLatentLEParamValues(parameter){
		def matcherSize = mu.getMatcherSize()
		switch (parameter){
		case ALGORITHM 		: return mu.getLatentLEAlgorithmFromMuLog(matcherSize)
		case ROTATION_LIMIT : return mu.getLatentLERotationLimitFromMuLog(matcherSize)
		case CORE_POSITION 	: return mu.getLatentLECorePositionFromMuLog(matcherSize)
		default 			: assert false, "Input parameter '${parameter}' is unknown type"
		}
	}

	def getLfmlParamValues(parameter){
		def matcherSize = mu.getMatcherSize()
		switch (parameter){
	        case SEARCH_LEVEL               : return mu.getLatentLFMLSearchLevelFromMuLog(matcherSize)
	       	case SPEED_LEVEL_PRIMARY        : return mu.getLatentLFMLSpeedLevelPrimaryFromMuLog(matcherSize)
	        case SPEED_LEVEL_SECONDARY      : return mu.getLatentLFMLSpeedLevelSecondaryFromMuLog(matcherSize)
	        case ROTATION_LIMIT_PRIMARY 	: return mu.getLatentLFMLRotationLimitPrimaryFromMuLog(matcherSize)
	        case ROTATION_LIMIT_SECONDARY	: return mu.getLatentLFMLRotationLimitSecondaryFromMuLog(matcherSize)
	        case DISTORTION_LEVEL_PRIMARY   : return mu.getLatentLFMLDistortionLevelPrimaryFromMuLog(matcherSize)
	        case DISTORTION_LEVEL_SECONDARY : return mu.getLatentLFMLDistortionLevelSecondaryFromMuLog(matcherSize)
			default					  		: assert false, "Input parameter '${parameter}' is unknown type"
		}
	}
	
	def getExtractParamValues(parameter){
		def extractorSize = mu.getExtractorSize()
		switch(parameter){
			case FE_TYPE					: return mu.getExtractOptionFeTypeFromMuLog(extractorSize)
			case EHN_TYPE					: return mu.getExtractOptionEhnTypeFromMuLog(extractorSize)
			case LMT_OF_MIN					: return mu.getExtractOptionLmtOfMinFromMuLog(extractorSize)
			case RDBLM_EXT_PARAM_FILE		: return mu.getRDBLMExtFileFromMuLog()
			case LDBM_EXT_PARAM_FILE		: return mu.getLDBMMExtFileFromMuLog()
			case LIM_EXT_PARAM_FILE			: return mu.getLIMExtFileFromMuLog()
			case LLIM_EXT_PARAM_FILE		: return mu.getLLIMExtFileFromMuLog()
			case TLIM_EXT_PARAM_FILE		: return mu.getTLIMExtFileFromMuLog()
			default							: assert false, "Input parameter '${parameter}' is unknown type"
		}
	}
	
	def getIrisParamValues(parameter){
		switch (parameter){
		    case ROTATION_LIMIT : return mu.getIrisRotationLimitFromMuLog()
		    case NIRIS_EXT_MODE : return mu.getNirisExtModeFromMuLog()
		    default 			: assert false, "Input parameter '${parameter}' is unknown type"
		}
	}


	def abendTest(message){
		def abendProcessor = new AbendProcessor(soapuiObject.getContext())
		abendProcessor.abendTest(message)
	}

	def abendTest(testPatternName, message){
		def abendProcessor = new AbendProcessor(soapuiObject.getContext())
		abendProcessor.abendTest(testPatternName, message)
	}

	def mkErrMessg(parameter, expected, actual){
		return new MessageCreator().mkValueErrMessg(parameter, expected, actual)
	} 
}



