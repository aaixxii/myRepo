package test.degrade.assertion.extract

import test.common.format.extraction.payload.abst.*
import test.common.format.extraction.payload.impl.MinutiaDataCmlaf;
import test.common.format.extraction.payload.impl.PalmOutput;
import test.degrade.assertion.xml.*
import test.degrade.management.*
import test.degrade.evidence.*
import test.common.message.*
import test.degrade.util.*
import common.util.*

class AssertReExtraction {
	SoapuiObject soapuiObject
	String testName
	static final String RDBTM_DB_TYPE = "RDBTM"
	static final String TIM_FORMAT = "TIM"
	static final String RDBTM_FORMAT = "RDBTM"
	static final String CMLAF_FIS_TYPE = "TYPE_CMLaF"
	static final int MIN_QUALITY_VAL = 0
	int expectedFisDataListSize = 0
	String expectedMinutiaType = "PC2"
	String expectedFisType = "TYPE_E"
	
	Map expectedPrimaryPatternMap = [ "S":true, "W":true, "R":true, "L":true, "A":true ] // TODO
	Map expectedReferencePatternMap = [ "S":true, "W":true, "R":true, "L":true, "A":true, " ":true ] // TODO
	Map expectedFusionMinLimitCntMap = [ "1":30, "2":63 ]
	
	/****
	 * possible updating each by test case assertion
	 */
	List<String> expectedMinDataFormatList = [ TIM_FORMAT, TIM_FORMAT ]
	List<String> expectedFusionIdList = [ "1", "2"] 
	List<String> expectedPosList = [ "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" ]

    AssertReExtraction(context, String testName){
		this.soapuiObject = new SoapuiObject(context)
		this.testName = testName
	}
	
	public void assertPC2Basic(OutputPayloadAbstract outputPayload){
		expectedFisDataListSize = 0
		assertBasic(outputPayload)
	}
	
	public void assertFisBasic(OutputPayloadAbstract outputPayload){
		expectedFisDataListSize = 2
		assertBasic(outputPayload)
	}
	
	public void assertBasic(OutputPayloadAbstract outputPayload){
		List<FingerOutputAbstract> fingerOutputList= outputPayload.getFingerOutputList()
		assertEquals(fingerOutputList.size(),  expectedPosList.size(), "finger-output-element size")
		for(i in 0..fingerOutputList.size()-1){
			assertFingerOutputBasic(fingerOutputList[i], expectedPosList[i])
		}
	}

	private void assertFingerOutputBasic(FingerOutputAbstract fingerOutput, String expectedPos) {
		assertPrimaryPattern(fingerOutput.getPatternPrimary())
		assertReferencePattern(fingerOutput.getPatternReference())
		assertEquals(fingerOutput.getPos(), expectedPos, "pos value")
		assertScopeIncludeEqual(fingerOutput.getQuality() as int, MIN_QUALITY_VAL, 100, "quality value")
		assertMinutiaDataListBasic(fingerOutput)
		assertFisDataListBasic(fingerOutput)
	}

	private assertFisDataListBasic(FingerOutputAbstract fingerOutput) {
		List<FisDataAbstract> fisDataList = fingerOutput.getFisDataList()
		assertEquals(fisDataList.size(), expectedFisDataListSize, "fis-data element size")
		for(i in 0..fisDataList.size()-1){
			// TODO
		}
	}

	private assertMinutiaDataListBasic(FingerOutputAbstract fingerOutput) {
		List<MinutiaDataAbstract> minutiaDataList = fingerOutput.getMinutiaDataList()
		assertEquals(minutiaDataList.size(), expectedFusionIdList.size(), "minutia-data element size")
		for(i in 0..minutiaDataList.size()-1){
			assertMinutiaDataBasic(minutiaDataList[i], expectedMinDataFormatList[i], expectedFusionIdList[i])
		}
	}

	private assertMinutiaDataBasic(MinutiaDataAbstract minutiaData, String expectedMinDataFormat, String expectedFusionId) {
		assertEquals(minutiaData.getDbType(), RDBTM_DB_TYPE, "dbType")
		assertEquals(minutiaData.getFisType(), CMLAF_FIS_TYPE, "minutia-data@fisType")
		assertEquals(minutiaData.getFormat(), expectedMinDataFormat, "minutia-data@format")
		String fusionId = ((MinutiaDataCmlaf)minutiaData).getFusionId()
		assertEquals(fusionId, expectedFusionId, "minutia-data@fusionId")
		assertScopeIncludeEqual(minutiaData.getMinutiaCount() as int, 1, expectedFusionMinLimitCntMap.get(fusionId), "minutia-data@minutiaCount")
		assertEquals(minutiaData.getMinutiaType(), expectedMinutiaType, "minutia-data@minutiaType")
	}
	
	private void assertPrimaryPattern(String pattern){
		assertPattern(pattern, expectedPrimaryPatternMap, "primaryPattern")
	}
	
	private void assertReferencePattern(String pattern){
		assertPattern(pattern, expectedReferencePatternMap, "referencePattern")
	}
	
	private void assertPattern(String pattern, Map correctPatternMap, String patternLevel){
		boolean isPatternCorrect = correctPatternMap.get(pattern)
		if(!(isPatternCorrect)){
			String expectedPattnVals = createExpectedPattenValues(correctPatternMap)
			abendTest(patternLevel, expectedPattnVals, pattern)
		}
	}

	private String createExpectedPattenValues(Map correctPatternMap) {
		StringBuilder sb = new StringBuilder()
		for(key in correctPatternMap.keySet()){
			sb.append("'${key}' or ")
		}
		return sb.toString()
	}

	public void assertFisDiff(OutputPayloadAbstract outputPayloadIn, OutputPayloadAbstract outputPayloadOut) {
		List<FingerOutputAbstract> fingerOutputListIn = outputPayloadIn.getFingerOutputList()
		List<FingerOutputAbstract> fingerOutputListOut = outputPayloadOut.getFingerOutputList()
		assertEquals(fingerOutputListIn.size(), fingerOutputListOut.size(), "finger-output element size")
		for(i in 0..fingerOutputListIn.size()-1) {
			assertEachFisValDiff(fingerOutputListIn, fingerOutputListOut, i)
		}
	}

	private void assertEachFisValDiff(List<FingerOutputAbstract> fingerOutputListIn,
						 List<FingerOutputAbstract> fingerOutputListOut, int index) {
		List<FisDataAbstract> fisDataListIn = fingerOutputListIn[index].getFisDataList()
		List<FisDataAbstract> fisDataListOut = fingerOutputListOut[index].getFisDataList()
		FisDataAbstract fisDataIn = fisDataListIn[fisDataListIn.size()-1]
		for(FisDataAbstract fisDataOut in fisDataListOut) {
			assertFisCoreDiff(fisDataIn.getFisCore(), fisDataOut.getFisCore())
			assertFisQualityDiff(fisDataIn.getFisQuality(), fisDataOut.getFisQuality())
			//assertFisMinutiaNoDiff(fisDataIn.getFisMinutiaNo(), fisDataOut.getFisMinutiaNo())
			assertEquals(fisDataOut.getMinutiaData(), fisDataIn.getMinutiaData(), "minutia-data")
			assertEquals(fisDataOut.getZone(), fisDataIn.getZone(), "zone")
			assertEquals(fisDataOut.getSkeleton(), fisDataIn.getSkeleton(), "skeleton")
		}
	}

	private void assertFisCoreDiff(FisCoreAbstract fisCoreIn, FisCoreAbstract fisCoreOut) {
		assertEquals(fisCoreOut.getActivityBit(), fisCoreIn.getActivityBit(), "fis-core A")
		assertEquals(fisCoreOut.getFlactionCode(), fisCoreIn.getFlactionCode(), "fis-core CC")
//		assertEquals(fisCoreOut.getAxisAngle(), fisCoreIn.getAxisAngle(), "fis-core D")
		assertEquals(fisCoreOut.getMinutiaCoordinate(), fisCoreIn.getMinutiaCoordinate(), "fis-core F")
//		assertEquals(fisCoreOut.getQualityOfTheAxisDirection(), fisCoreIn.getQualityOfTheAxisDirection(), "fis-core QD")
//		assertEquals(fisCoreOut.getQualityOfTheCorePosition(), fisCoreIn.getQualityOfTheCorePosition(), "fis-core QP")
//		assertEquals(fisCoreOut.getQualityOfTheCorePositionAndDirection(), fisCoreIn.getQualityOfTheCorePositionAndDirection(), "fis-core QQ")
//		assertEquals(fisCoreOut.getCorePositionHorizontal(), fisCoreIn.getCorePositionHorizontal(), "fis-core X")
//		assertEquals(fisCoreOut.getCorePositionVertical(), fisCoreIn.getCorePositionVertical(), "fis-core Y")
	}
		
	private void assertFisQualityDiff(FisQualityAbstract fisQualityIn, FisQualityAbstract fisQualityOut) {
//		assertEquals(fisQualityOut.getZoneQualityValue(), fisQualityIn.getZoneQualityValue(), "fis-quality S")
//		assertEquals(fisQualityOut.getQualityOfAZone(), fisQualityIn.getQualityOfAZone(), "fis-quality VA")
//		assertEquals(fisQualityOut.getQualityOfBZone(), fisQualityIn.getQualityOfBZone(), "fis-quality VB")
		assertEquals(fisQualityOut.getQualityOfCZone(), fisQualityIn.getQualityOfCZone(), "fis-quality VC")
	}
	private void assertFisMinutiaNoDiff(FisMinutiaNoAbstract fisMinutiaNoIn, FisMinutiaNoAbstract fisMinutiaNoOut) {
		assertEquals(fisMinutiaNoOut.getDeletedNumberOfFeaturePoints(), fisMinutiaNoIn.getDeletedNumberOfFeaturePoints(), "fis-minutia-no DB")
		assertEquals(fisMinutiaNoOut.getFeaturePoints(), fisMinutiaNoIn.getFeaturePoints(), "fis-minutia-no MB")
	}

	public void assertSkeletonDiff(OutputPayloadAbstract outputPayloadIn, OutputPayloadAbstract outputPayloadOut) {
		List<FingerOutputAbstract> fingerOutputListIn = outputPayloadIn.getFingerOutputList()
		List<FingerOutputAbstract> fingerOutputListOut = outputPayloadOut.getFingerOutputList()
		assertEquals(fingerOutputListIn.size(), fingerOutputListOut.size(), "finger-output element size")
		for(i in 0..fingerOutputListIn.size()-1) {
			_assertSkeletonDiff(fingerOutputListIn, fingerOutputListOut, i)
		}
	}

	private void _assertSkeletonDiff(List<FingerOutputAbstract> fingerOutputListIn,
						 List<FingerOutputAbstract> fingerOutputListOut, int index) {
		List<FisDataAbstract> fisDataListIn = fingerOutputListIn[index].getFisDataList()
		List<FisDataAbstract> fisDataListOut = fingerOutputListOut[index].getFisDataList()
		String skeletonIn = fisDataListIn[fisDataListIn.size()-1].getSkeleton()
		for(FisDataAbstract fisData in fisDataListOut) {
			String skeletonOut = fisData.getSkeleton()
			assertEquals(skeletonIn, skeletonOut, "skeleton value")
		}
	}

	public void assertMinutiaDataDiff(OutputPayloadAbstract outputPayloadIn, OutputPayloadAbstract outputPayloadOut) {
		List<FingerOutputAbstract> fingerOutputListIn = outputPayloadIn.getFingerOutputList()
		List<FingerOutputAbstract> fingerOutputListOut = outputPayloadOut.getFingerOutputList()
		assertEquals(fingerOutputListIn.size(), fingerOutputListOut.size(), "finger-output element size")
		for(i in 0..fingerOutputListIn.size()-1) {
			_assertMinutiaDataDiff(fingerOutputListIn, fingerOutputListOut, i)
		}
	}

	private void _assertMinutiaDataDiff(List<FingerOutputAbstract> fingerOutputListIn,
						 List<FingerOutputAbstract> fingerOutputListOut, int index) {
		List<FisDataAbstract> fisDataListIn = fingerOutputListIn[index].getFisDataList()
		List<FisDataAbstract> fisDataListOut = fingerOutputListOut[index].getFisDataList()
		String minutiaDataIn = fisDataListIn[fisDataListIn.size()-1].getMinutiaData()
		for(FisDataAbstract fisData in fisDataListOut) {
			String minutiaDataOut = fisData.getMinutiaData()
			assertEquals(minutiaDataIn, minutiaDataOut, "minutia-data value")
		}
	}

	public void assertZoneDiff(OutputPayloadAbstract outputPayloadIn, OutputPayloadAbstract outputPayloadOut) {
		List<FingerOutputAbstract> fingerOutputListIn = outputPayloadIn.getFingerOutputList()
		List<FingerOutputAbstract> fingerOutputListOut = outputPayloadOut.getFingerOutputList()
		assertEquals(fingerOutputListIn.size(), fingerOutputListOut.size(), "finger-output element size")
		for(i in 0..fingerOutputListIn.size()-1) {
			_assertMinutiaDataDiff(fingerOutputListIn, fingerOutputListOut, i)
		}
	}

	private void _assertZoneDiff(List<FingerOutputAbstract> fingerOutputListIn,
						 List<FingerOutputAbstract> fingerOutputListOut, int index) {
		List<FisDataAbstract> fisDataListIn = fingerOutputListIn[index].getFisDataList()
		List<FisDataAbstract> fisDataListOut = fingerOutputListOut[index].getFisDataList()
		String zeonIn = fisDataListIn[fisDataListIn.size()-1].getZone()
		for(FisDataAbstract fisData in fisDataListOut) {
			String zoneOut = fisData.getZone()
			assertEquals(zoneIn, zoneOut, "zone value")
		}
	}

	public void assertSkeletonIsEmpty(OutputPayloadAbstract outputPayload, int fingerNum) {
		List<FingerOutputAbstract> fingerOutputList = outputPayload.getFingerOutputList()
		assertEquals(fingerOutputList.size(), fingerNum, "finger-output element size")
		for(FingerOutputAbstract fingerOutput in outputPayload.getFingerOutputList()) {
			assertSkeletonListEmpty(fingerOutput)
		}
	}

	private void assertSkeletonListEmpty(FingerOutputAbstract fingerOutput) {
		for(FisDataAbstract fisData in fingerOutput.getFisDataList()) {
			String skeleton = fisData.getSkeleton()
			if(skeleton != null && !skeleton.isEmpty()){
				abendTest("skeleton", "null or empty", skeleton)
			}
		}
	}
				
	public void assertSkeletonCaseOfNormalExtract(OutputPayloadAbstract outputPayload, int fingerNum) {
		List<FingerOutputAbstract> fingerOutputList = outputPayload.getFingerOutputList()
		assertEquals(fingerOutputList.size(), fingerNum, "finger-output element size")
		for(FingerOutputAbstract fingerOutput in outputPayload.getFingerOutputList()) {
			assertSkeletonIsDiffEachFusion(fingerOutput.getFisDataList())
		}
	}

	private void assertSkeletonIsDiffEachFusion(List<FisDataAbstract> fisDataList) {
		String skeletonF1 = fisDataList[0].getSkeleton()
		String skeletonF2 = fisDataList[1].getSkeleton()
		assertNotEquals(skeletonF1, skeletonF2, testName)
	}
		
	public void assertMinutiaDataCaseOfNormalExtract(OutputPayloadAbstract outputPayload, int fingerNum) {
		List<FingerOutputAbstract> fingerOutputList = outputPayload.getFingerOutputList()
		assertEquals(fingerOutputList.size(), fingerNum, "finger-output element size")
		for(FingerOutputAbstract fingerOutput in fingerOutputList) {
			assertMinutiaDataDiffEachFusion(fingerOutput.getFisDataList())
		}
	}

	private void assertMinutiaDataDiffEachFusion(List<FisDataAbstract> fisDataList) {
		String minutiaDataF1 = fisDataList[0].getMinutiaData()
		String minutiaDataF2 = fisDataList[1].getMinutiaData()
		assertNotEquals(minutiaDataF1, minutiaDataF2, testName)
	}
		
	public void assertZoneCaseOfNormalExtract(OutputPayloadAbstract outputPayload, int fingerNum) {
		List<FingerOutputAbstract> fingerOutputList = outputPayload.getFingerOutputList()
		assertEquals(fingerOutputList.size(), fingerNum, "finger-output element size")
		for(FingerOutputAbstract fingerOutput in fingerOutputList) {
			assertZoneDiffEachFusion(fingerOutput.getFisDataList())
		}
	}

	private void assertZoneDiffEachFusion(List<FisDataAbstract> fisDataList) {
		String zoneF1 = fisDataList[0].getZone()
		String zoneF2 = fisDataList[1].getZone()
		assertNotEquals(zoneF1, zoneF2, testName)
	}

	public void assertDbTypeFinger20(OutputPayloadAbstract outputPayload, String expectedDbType, expectedFormat) {
		List<FingerOutputAbstract> fingerOutputList = outputPayload.getFingerOutputList()
		assertEquals(fingerOutputList.size(), 20, "finger-output element size")
		assertRollSlapPos(fingerOutputList)
		for(i in 0..19) {
			assertMinutiaDataAttribute(fingerOutputList[i].getMinutiaDataList(), expectedDbType, expectedFormat, 1)
		}
	}

	public void assertDbTypeFinger20ARZ(OutputPayloadAbstract outputPayload, String expectedDbType, expectedFormat) {
		List<FingerOutputAbstract> fingerOutputList = outputPayload.getFingerOutputList()
		assertEquals(fingerOutputList.size(), 20, "finger-output element size")
		assertRollSlapPos(fingerOutputList)
		for(i in 0..19) {
			assertMinutiaDataAttributeARZ(fingerOutputList[i].getMinutiaDataList(), expectedDbType, expectedFormat, 1)
		}
	}
	
	public void assertDbTypeFinger20ARZ(OutputPayloadAbstract outputPayload, String expectedDbType, expectedFormat, int expectedMinutiaDataSize) {
		List<FingerOutputAbstract> fingerOutputList = outputPayload.getFingerOutputList()
		assertEquals(fingerOutputList.size(), 20, "finger-output element size")
		assertRollSlapPos(fingerOutputList)
		for(i in 0..19) {
			assertMinutiaDataAttributeARZ(fingerOutputList[i].getMinutiaDataList(), expectedDbType, expectedFormat, expectedMinutiaDataSize)
		}
	}
	
	public void assertDbTypeFinger20Greece(OutputPayloadAbstract outputPayload, String expectedDbType, expectedFormat, int expectedMinutiaDataSize) {
		List<FingerOutputAbstract> fingerOutputList = outputPayload.getFingerOutputList()
		assertEquals(fingerOutputList.size(), 20, "finger-output element size")
		assertRollSlapPos(fingerOutputList)
		for(i in 0..19) {
			assertMinutiaDataAttributeGreese(fingerOutputList[i].getMinutiaDataList(), expectedDbType, expectedFormat, expectedMinutiaDataSize)
		}
	}

	public void assertDbTypePalm4ARZ(OutputPayloadAbstract outputPayload, expectedMinCount, expectedMinType) {
		List<PalmOutput> palmOutputList = outputPayload.getPalmOutputList()
		assertEquals(palmOutputList.size(), 4, "palm-output element size")
		assertPalmPos(palmOutputList)
		for(i in 0..3) {
			assertMinutiaDataAttributePalmARZ(palmOutputList[i].getMinutiaDataList(), expectedMinCount, expectedMinType, 1)
		}
	}
	
	public void assertDbTypeRdblm20(OutputPayloadAbstract outputPayload, String expectedDbType, expectedFormat) {
		List<FingerOutputAbstract> fingerOutputList = outputPayload.getFingerOutputList()
		assertEquals(fingerOutputList.size(), 20, "finger-output element size")
		assertRollSlapPos(fingerOutputList)
		for(i in 0..19) {
			assertMinutiaDataAttribute(fingerOutputList[i].getMinutiaDataList(), expectedDbType, expectedFormat, 2)
		}
	}
	
	public void assertDbTypeRdblm20(OutputPayloadAbstract outputPayload, String expectedDbType, expectedFormat, int minutiaCount) {
		List<FingerOutputAbstract> fingerOutputList = outputPayload.getFingerOutputList()
		assertEquals(fingerOutputList.size(), 20, "finger-output element size")
		assertRollSlapPos(fingerOutputList)
		for(i in 0..19) {
			assertMinutiaDataAttributeGreese(fingerOutputList[i].getMinutiaDataList(), expectedDbType, expectedFormat, 8)
		}
	}
	
	public void assertDbTypeLatentLfml1(OutputPayloadAbstract outputPayload, String expectedDbType, expectedFormat) {
		List<FingerOutputAbstract> fingerOutputList = outputPayload.getFingerOutputList()
		assertEquals(fingerOutputList.size(), 1, "finger-output element size")
		//assertEquals(fingerOutputList[0].getPos() as int, 1, "pos number")
		assertMinutiaDataAttribute(fingerOutputList[0].getMinutiaDataList(), expectedDbType, expectedFormat, 7)
	}

	public void assertDbTypeLatentLfml1ARZ(OutputPayloadAbstract outputPayload, String expectedDbType, expectedFormat) {
		List<FingerOutputAbstract> fingerOutputList = outputPayload.getFingerOutputList()
		assertEquals(fingerOutputList.size(), 1, "finger-output element size")
		//assertEquals(fingerOutputList[0].getPos() as int, 1, "pos number")
		assertMinutiaDataAttributeARZ(fingerOutputList[0].getMinutiaDataList(), expectedDbType, expectedFormat, 16)
	}

	public void assertDbTypeLatentLfmlGreece(OutputPayloadAbstract outputPayload, String expectedDbType, expectedFormat) {
		List<FingerOutputAbstract> fingerOutputList = outputPayload.getFingerOutputList()
		assertEquals(fingerOutputList.size(), 1, "finger-output element size")
		//assertEquals(fingerOutputList[0].getPos() as int, 1, "pos number")
		assertMinutiaDataAttributeGreese(fingerOutputList[0].getMinutiaDataList(), expectedDbType, expectedFormat, 16)
	}
	
	public void assertDbTypeTimRolled10(OutputPayloadAbstract outputPayload) {
		List<FingerOutputAbstract> fingerOutputList = outputPayload.getFingerOutputList()
		assertEquals(fingerOutputList.size(), 10, "finger-output element size")
		for(i in 0..9) {
			assertEquals(fingerOutputList[i].getPos() as int, i+1, "pos Number")
			assertMinutiaDataAttributeCmlaf(fingerOutputList[i].getMinutiaDataList(), RDBTM_DB_TYPE, TIM_FORMAT)
		}
	}
		
	public void assertDbTypeRdbtm10(OutputPayloadAbstract outputPayload) {
		List<FingerOutputAbstract> fingerOutputList = outputPayload.getFingerOutputList()
		assertEquals(fingerOutputList.size(), 10, "finger-output element size")
		for(i in 0..9) {
			assertEquals(fingerOutputList[i].getPos() as int, i+1, "pos Number")
			assertMinutiaDataAttributeCmlaf(fingerOutputList[i].getMinutiaDataList(), RDBTM_DB_TYPE, RDBTM_FORMAT)
		}
	}
		
	public void assertDbTypeTimSlap10(OutputPayloadAbstract outputPayload) {
		List<FingerOutputAbstract> fingerOutputList = outputPayload.getFingerOutputList()
		assertEquals(fingerOutputList.size(), 10, "finger-output element size")
		assertSlapPos(fingerOutputList)
		assertDbTypeAndFormatSearch(fingerOutputList, RDBTM_DB_TYPE, TIM_FORMAT)
	}

	public void assertDbTypeSdbtm10(OutputPayloadAbstract outputPayload) {
		List<FingerOutputAbstract> fingerOutputList = outputPayload.getFingerOutputList()
		assertEquals(fingerOutputList.size(), 10, "finger-output element size")
		assertSlapPos(fingerOutputList)
		assertDbTypeAndFormatSearch(fingerOutputList, RDBTM_DB_TYPE, RDBTM_FORMAT)
	}

	private assertDbTypeAndFormatSearch(List<FingerOutputAbstract> fingerOutputList, String expectedDbType, String expectedFormat) {
		for(i in 0..9) {
			assertMinutiaDataAttributeCmlaf(fingerOutputList[i].getMinutiaDataList(), expectedDbType, expectedFormat)
		}
	}

	private assertSlapPos(List<FingerOutputAbstract> fingerOutputList) {
		String posNumber = "pos Number"
		for(index in 0..9) {
			if(index == 0) {
				assertEquals(fingerOutputList[index].getPos() as int, 11, posNumber)
			}else if(index == 5) {
				assertEquals(fingerOutputList[index].getPos() as int, 12, posNumber)
			}else if(index < 5) {
				assertEquals(fingerOutputList[index].getPos() as int, index+39, posNumber)
			}else if(5 < index) {
				assertEquals(fingerOutputList[index].getPos() as int, index+38, posNumber)
			}
		}
	}
		
	private assertRollSlapPos(List<FingerOutputAbstract> fingerOutputList) {
		String posNumber = "pos Number"
		for(i in 0..19) {
			if(i < 10) {
				assertEquals(fingerOutputList[i].getPos() as int, i+1, posNumber)
			}else if(i == 10) {
				assertEquals(fingerOutputList[i].getPos() as int, 11, posNumber)
			}else if(i == 15) {
				assertEquals(fingerOutputList[i].getPos() as int, 12, posNumber)
			}else if(i < 15) {
				assertEquals(fingerOutputList[i].getPos() as int, i+29, posNumber)
			}else if(15 < i) {
				assertEquals(fingerOutputList[i].getPos() as int, i+28, posNumber)
			}
		}
	}
		
	private assertPalmPos(List<PalmOutput> palmOutputList) {
		String posNumber = "pos Number"
		for(i in 0..3) {
			assertEquals(palmOutputList[i].getPos() as int, i+21, posNumber)
		}
	}
	private void assertMinutiaDataAttributeCmlaf(List<MinutiaDataAbstract> minutiaDataList, String expectedDbType, String expectedFormat) {
		assertEquals(minutiaDataList.size(), 2, "minutia-data element size")
		for(i in 0..1) {
			assertEquals(minutiaDataList[i].getDbType(), expectedDbType, "dbType") 
			assertEquals(minutiaDataList[i].getFormat(), expectedFormat, "format") 
			assertEquals(minutiaDataList[i].getFusionId() as int, i+1, "fusionId")
		}
	}

	private void assertMinutiaDataAttribute(
			List<MinutiaDataAbstract> minutiaDataList, String expectedDbType, String expectedFormat, int minutiaDataListSize) {
		assertEquals(minutiaDataList.size(), minutiaDataListSize, "minutia-data element size")
		for(MinutiaDataAbstract minutiaData in minutiaDataList) {
			assertEquals(minutiaData.getDbType(), expectedDbType, "dbType") 
			assertEquals(minutiaData.getFormat(), expectedFormat, "format") 
		}
	}

	private void assertMinutiaDataAttributeARZ(
			List<MinutiaDataAbstract> minutiaDataList, String expectedDbType, String expectedFormat, int minutiaDataListSize) {
		assertEquals(minutiaDataList.size(), minutiaDataListSize, "minutia-data element size")
		for(MinutiaDataAbstract minutiaData in minutiaDataList) {
			assertEquals(minutiaData.getDbType(), expectedDbType, "dbType")
			assertEquals(minutiaData.getFisType(), expectedFisType, "minutia-data@fisType")
			assertEquals(minutiaData.getFormat(), expectedFormat, "minutia-data@format")
			assertEquals(minutiaData.getMinutiaType(), expectedMinutiaType, "minutia-data@minutiaType")
		}
	}


	private void assertMinutiaDataAttributeGreese(
			List<MinutiaDataAbstract> minutiaDataList, String expectedDbType, String expectedFormat, int minutiaDataListSize) {
		assertEquals(minutiaDataList.size(), minutiaDataListSize, "minutia-data element size")
		int index = 0
		for(MinutiaDataAbstract minutiaData in minutiaDataList) {
			assertEquals(minutiaData.getDbType(), expectedDbType, "dbType")
			assertEquals(minutiaData.getFisType(), expectedFisType, "minutia-data@fisType")
			assertEquals(minutiaData.getFormat(), expectedFormat, "minutia-data@format")
			if(index == 0){
				expectedMinutiaType = "BT5"
				assertEquals(minutiaData.getMinutiaType(), expectedMinutiaType, "minutia-data@minutiaType")
			}else{
				expectedMinutiaType = "PC2"
				assertEquals(minutiaData.getMinutiaType(), expectedMinutiaType, "minutia-data@minutiaType")
			}
			index++
		}
	}

	private void assertMinutiaDataAttribute20Greese(
			List<MinutiaDataAbstract> minutiaDataList, String expectedDbType, String expectedFormat, int minutiaDataListSize) {
		assertEquals(minutiaDataList.size(), minutiaDataListSize, "minutia-data element size")
		int index = 1
		for(MinutiaDataAbstract minutiaData in minutiaDataList) {
			assertEquals(minutiaData.getDbType(), expectedDbType, "dbType")
			assertEquals(minutiaData.getFisType(), expectedFisType, "minutia-data@fisType")
			assertEquals(minutiaData.getFormat(), expectedFormat, "minutia-data@format")
			if(index%2 == 0){
				expectedMinutiaType = "PC2"
				assertEquals(minutiaData.getMinutiaType(), expectedMinutiaType, "minutia-data@minutiaType")
			}else{
				expectedMinutiaType = "BT5"
				assertEquals(minutiaData.getMinutiaType(), expectedMinutiaType, "minutia-data@minutiaType")
			}
			index++
		}
	}
	
	private void assertMinutiaDataAttributePalmARZ(
			List<MinutiaDataAbstract> minutiaDataList, expectedMinCount, String expectedMinType, int minutiaDataListSize) {
		assertEquals(minutiaDataList.size(), minutiaDataListSize, "minutia-data element size")
		int cnt = 0
		for(MinutiaDataAbstract minutiaData in minutiaDataList) {
			assertEquals(minutiaData.getMinutiaCount(), expectedMinCount[cnt], "minutia-data@minutiaCount")
			assertEquals(minutiaData.getMinutiaType(), expectedMinType, "minutia-data@minutiaType")
			cnt++
		}
	}
	String mkErrMessg(name, expected, actual){
		return new MessageCreator().mkValueErrMessg(name, expected, actual)
	}

	String outputEvidence(testName, content){
		EvidenceFileOutputor evidenceFileOutputor = new EvidenceFileOutputor(soapuiObject.getContext())
		evidenceFileOutputor.outputTrueMess("${testName} --> ${content}")
	}

	public void assertXsdSchema(String testName) {
		AssertAimXsdSchema assertAimXsd = new AssertAimXsdSchema(
						outputPayload.getOutputPayloadXmlString(), testName, soapuiObject.getContext())
		assertAimXsd.assertAimXsd()
	}

	protected void assertEquals(actual, expected, String testPropName) {
		if(actual != expected) {
			abendTest(testPropName, expected, actual)
		}
	}
	
	private void assertScopeIncludeEqual(actual, expectedMin, expectedMax, String testPropName){
		if(!( (expectedMin <= actual) && (actual <= expectedMax) )){
			abendTest(testPropName, "between ${expectedMin} and ${expectedMax}", actual)
		}
	}
	
	protected void assertNotEquals(actual, expected, String testPropName) {
		if(actual == expected) {
			abendTest(testPropName, "not equal values", "same values")
		}
	}

	private void abendTest(def testPropName, def expectedMessg, def actualValue) {
		String errMessg = mkErrMessg(testPropName, expectedMessg, actualValue)
		AbendProcessor abendProcessor = new AbendProcessor(soapuiObject.getContext())
		abendProcessor.abendTest(testName, errMessg)
	}
}
