package test.degrade.assertion.xml

import test.degrade.properties.GlobalProperties
import static test.common.constants.aim.AIMXmlAttribute.*
import static test.common.constants.aim.AIMWord.*
import test.degrade.management.AbendProcessor
import test.degrade.util.SoapuiObject

class XpathMapper{
	
	static final String FINGER_CNT_1 = "1"
	static final String FINGER_CNT_10 = "10"
	GlobalProperties globalProperties

	XpathMapper(){}
	
	XpathMapper(context){
		this.globalProperties = new GlobalProperties(context)
	}

	def createStatisticsRoughXpathMap(readCount, matchCount, errCount){
		def xpathValueMap = [ 
			"statistics/readCount": "${readCount}",
			"statistics/matchCount": "${matchCount}",
			"count(//error)": "${errCount}"
		]
		return xpathValueMap
	}

	def createStatisitcsXpathMap(readCount, matchCount, candidateCount, errCount){
		def xpathValueMap = [ 
			"statistics/readCount": "${readCount}",
			"statistics/matchCount": "${matchCount}",
			"count(//candidate)": "${candidateCount}",
			"count(//error)": "${errCount}"
		]
		return xpathValueMap
	}

	def createStatisitcsXpathMap(readCount, matchCount, candidateCount, candidateTmpCount, individualScoreCount, errCount){
        if(errCount as int == 0) {
            return [ 
                "statistics/readCount": "${readCount}",
                "statistics/matchCount": "${matchCount}",
                "count(//candidate)": "${candidateCount}",
                "count(//candidate-template)": "${candidateTmpCount}",
                "count(//individual-score)": "${individualScoreCount}",
                "count(//error)": "${errCount}"
            ]
        } else {
            return [ 
                "count(//statistics)": "0",
                "count(//candidate)": "${candidateCount}",
                "count(//candidate-template)": "${candidateTmpCount}",
                "count(//individual-score)": "${individualScoreCount}",
                "count(//error)": "${errCount}"
            ]
        }
	}
 	def creatVerifyResponseXpathMap(candidateResultListCount, modalScoreListCount, individualScoreListCount){
                def xpathValueMap = [
                        "count(//candidateResultList)": "${candidateResultListCount}",
                        "count(//modalScoreList)": "${modalScoreListCount}",
                        "count(//individualScoreList)": "${individualScoreListCount}",
                ]
                return xpathValueMap
        }

 	def creatVerifyResponseXpathMap(candidateResultListCount, modalScoreListCount, individualScoreListCount, crossMatchingResultListCount){
                def xpathValueMap = [
                        "count(//candidateResultList)": "${candidateResultListCount}",
                        "count(//modalScoreList)": "${modalScoreListCount}",
                        "count(//individualScoreList)": "${individualScoreListCount}",
                        "count(//crossMatchingResultList)": "${crossMatchingResultListCount}",
                ]
                return xpathValueMap
        }

 	def creatVerifyStatusListCountXpathMap(statusListCount){
		def xpathValueMap = [
			"count(//statusList)": "${statusListCount}",
		]
		return xpathValueMap
	}
	/*********************************************************
	/	Palm without fusionWeight
	/********************************************************/
	def createCandidateXpathMap(hitFlag, externalId, fusionScore, candidateTemplateCount,
									containerId, eventId, searchRequestIndex, compositeScore,
									iScoreAxis, iScorePos, iScoreVal, existCount ){

		def candidateXpath = createPalmCanidateXpath(
								hitFlag, externalId, fusionScore, candidateTemplateCount,
								containerId, eventId, searchRequestIndex, compositeScore,
								iScoreAxis, iScorePos, iScoreVal)

		def xpathValueMap = [ "${candidateXpath}": "${existCount}" ]
		return xpathValueMap
	}


	/*********************************************************
	/	LFML
	/********************************************************/
	def createLfmlCandidateXpathMap(hitFlag, externalId, fusionScore, candidateTemplateCount,
									containerId, eventId, searchRequestIndex, compositeScore,
									iScorePos, iScoreVal, inquirySet, iScoreFw, existCount ){

	    def candidateXpath = createLfmlCanidateXpath(hitFlag, externalId, fusionScore, candidateTemplateCount,
									containerId, eventId, searchRequestIndex, compositeScore,
									iScorePos, iScoreVal, inquirySet, iScoreFw)

		return [ "${candidateXpath}": "${existCount}" ]
    }

	/*********************************************************
	/	1 finger no specified fusionWeight
	/********************************************************/
	def createCandidateXpathMap(hitFlag, externalId, fusionScore, candidateTemplateCount,
									containerId, eventId, searchRequestIndex, compositeScore,
									iScoreAxis, iScorePos, iScoreVal, inquirySet, existCount ){

	    return  createCandidateXpathMap(hitFlag, externalId, fusionScore, candidateTemplateCount,
									containerId, eventId, searchRequestIndex, 100, compositeScore,
									iScoreAxis, iScorePos, iScoreVal, inquirySet, existCount )
    }

	/*********************************************************
	/	1 finger specified fusionWeight
	/********************************************************/
	def createCandidateXpathMap(hitFlag, externalId, fusionScore, candidateTemplateCount,
									containerId, eventId, searchRequestIndex, fusionWeight, compositeScore,
									iScoreAxis, iScorePos, iScoreVal, inquirySet, existCount ){

		def candidateXpath = createCanidateWithFwXpath(
								hitFlag, externalId, fusionScore, candidateTemplateCount,
								containerId, eventId, searchRequestIndex, fusionWeight, compositeScore,
								iScoreAxis, iScorePos, iScoreVal, inquirySet)

		def xpathValueMap = [ "${candidateXpath}": "${existCount}" ]
		return xpathValueMap
	}

	/*********************************************************
	/	10 finger no setting fusionWeight, inquirySet
	/********************************************************/
	def createCandidateXpathMap(hitFlag, externalId, fusionScore, candidateTemplateCount,
									containerId, eventId, searchRequestIndex, compositeScore,
									iScoreAxis1, iScorePos1, iScoreVal1, iScoreAxis2, iScorePos2, iScoreVal2,
									iScoreAxis3, iScorePos3, iScoreVal3, iScoreAxis4, iScorePos4, iScoreVal4,
									iScoreAxis5, iScorePos5, iScoreVal5, iScoreAxis6, iScorePos6, iScoreVal6,
									iScoreAxis7, iScorePos7, iScoreVal7, iScoreAxis8, iScorePos8, iScoreVal8,
									iScoreAxis9, iScorePos9, iScoreVal9, iScoreAxis10, iScorePos10, iScoreVal10,
									existCount ){

	    return createCandidateXpathMap(hitFlag, externalId, fusionScore, candidateTemplateCount,
									containerId, eventId, searchRequestIndex, 100, compositeScore, PC2_ROLLED,
									iScoreAxis1, iScorePos1, iScoreVal1, iScoreAxis2, iScorePos2, iScoreVal2,
									iScoreAxis3, iScorePos3, iScoreVal3, iScoreAxis4, iScorePos4, iScoreVal4,
									iScoreAxis5, iScorePos5, iScoreVal5, iScoreAxis6, iScorePos6, iScoreVal6,
									iScoreAxis7, iScorePos7, iScoreVal7, iScoreAxis8, iScorePos8, iScoreVal8,
									iScoreAxis9, iScorePos9, iScoreVal9, iScoreAxis10, iScorePos10, iScoreVal10,
									existCount )
	}

	/*********************************************************
	/	10 finger no setting inquirySet
	/********************************************************/
	def createCandidateXpathMap(hitFlag, externalId, fusionScore, candidateTemplateCount,
									containerId, eventId, searchRequestIndex, fusionWeight, compositeScore, 
									iScoreAxis1, iScorePos1, iScoreVal1, iScoreAxis2, iScorePos2, iScoreVal2,
									iScoreAxis3, iScorePos3, iScoreVal3, iScoreAxis4, iScorePos4, iScoreVal4,
									iScoreAxis5, iScorePos5, iScoreVal5, iScoreAxis6, iScorePos6, iScoreVal6,
									iScoreAxis7, iScorePos7, iScoreVal7, iScoreAxis8, iScorePos8, iScoreVal8,
									iScoreAxis9, iScorePos9, iScoreVal9, iScoreAxis10, iScorePos10, iScoreVal10,
									existCount ){

	    return createCandidateXpathMap(hitFlag, externalId, fusionScore, candidateTemplateCount,
									containerId, eventId, searchRequestIndex, fusionWeight, compositeScore, PC2_ROLLED,
									iScoreAxis1, iScorePos1, iScoreVal1, iScoreAxis2, iScorePos2, iScoreVal2,
									iScoreAxis3, iScorePos3, iScoreVal3, iScoreAxis4, iScorePos4, iScoreVal4,
									iScoreAxis5, iScorePos5, iScoreVal5, iScoreAxis6, iScorePos6, iScoreVal6,
									iScoreAxis7, iScorePos7, iScoreVal7, iScoreAxis8, iScorePos8, iScoreVal8,
									iScoreAxis9, iScorePos9, iScoreVal9, iScoreAxis10, iScorePos10, iScoreVal10,
									existCount )
    }


	/*********************************************************
	/	10 finger specified inquirySet and fusionWeight
	/********************************************************/
	def createCandidateXpathMap(hitFlag, externalId, fusionScore, candidateTemplateCount,
									containerId, eventId, searchRequestIndex, fusionWeight, compositeScore, inquirySet,
									iScoreAxis1, iScorePos1, iScoreVal1, iScoreAxis2, iScorePos2, iScoreVal2,
									iScoreAxis3, iScorePos3, iScoreVal3, iScoreAxis4, iScorePos4, iScoreVal4,
									iScoreAxis5, iScorePos5, iScoreVal5, iScoreAxis6, iScorePos6, iScoreVal6,
									iScoreAxis7, iScorePos7, iScoreVal7, iScoreAxis8, iScorePos8, iScoreVal8,
									iScoreAxis9, iScorePos9, iScoreVal9, iScoreAxis10, iScorePos10, iScoreVal10,
									existCount ){


		def candidateXpath = createCanidateWithFwXpathTI(
								hitFlag, externalId, fusionScore, candidateTemplateCount,
								containerId, eventId, searchRequestIndex, compositeScore, inquirySet, fusionWeight,
								iScoreAxis1, iScorePos1, iScoreVal1, iScoreAxis2, iScorePos2, iScoreVal2,
								iScoreAxis3, iScorePos3, iScoreVal3, iScoreAxis4, iScorePos4, iScoreVal4,
								iScoreAxis5, iScorePos5, iScoreVal5, iScoreAxis6, iScorePos6, iScoreVal6,
								iScoreAxis7, iScorePos7, iScoreVal7, iScoreAxis8, iScorePos8, iScoreVal8,
								iScoreAxis9, iScorePos9, iScoreVal9, iScoreAxis10, iScorePos10, iScoreVal10
						 )

		def xpathValueMap = [ "${candidateXpath}": "${existCount}" ]
		return xpathValueMap
	}

	/*********************************************************
	/	10 finger specified inquirySet and fusionWeight
	/********************************************************/
	def createCandidateXpathMap(hitFlag, externalId, fusionScore, candidateTemplateCount,
									containerId, eventId, searchRequestIndex, fusionWeight, compositeScore, inquirySet,
									iScoreAxis1, iScoreSPos1, iScorePos1, iScoreVal1, iScoreAxis2, iScoreSPos2, iScorePos2, iScoreVal2,
									iScoreAxis3, iScoreSPos3, iScorePos3, iScoreVal3, iScoreAxis4, iScoreSPos4, iScorePos4, iScoreVal4,
									iScoreAxis5, iScoreSPos5, iScorePos5, iScoreVal5, iScoreAxis6, iScoreSPos6, iScorePos6, iScoreVal6,
									iScoreAxis7, iScoreSPos7, iScorePos7, iScoreVal7, iScoreAxis8, iScoreSPos8, iScorePos8, iScoreVal8,
									iScoreAxis9, iScoreSPos9, iScorePos9, iScoreVal9, iScoreAxis10, iScoreSPos10, iScorePos10, iScoreVal10,
									existCount ){

		def candidateXpath = createCanidateWithFwXpathTI(
								hitFlag, externalId, fusionScore, candidateTemplateCount,
								containerId, eventId, searchRequestIndex, compositeScore, inquirySet, fusionWeight,
								iScoreAxis1, iScoreSPos1, iScorePos1, iScoreVal1, iScoreAxis2, iScoreSPos2, iScorePos2, iScoreVal2,
								iScoreAxis3, iScoreSPos3, iScorePos3, iScoreVal3, iScoreAxis4, iScoreSPos4, iScorePos4, iScoreVal4,
								iScoreAxis5, iScoreSPos5, iScorePos5, iScoreVal5, iScoreAxis6, iScoreSPos6, iScorePos6, iScoreVal6,
								iScoreAxis7, iScoreSPos7, iScorePos7, iScoreVal7, iScoreAxis8, iScoreSPos8, iScorePos8, iScoreVal8,
								iScoreAxis9, iScoreSPos9, iScorePos9, iScoreVal9, iScoreAxis10, iScoreSPos10, iScorePos10, iScoreVal10
						 )

		def xpathValueMap = [ "${candidateXpath}": "${existCount}" ]
		return xpathValueMap
	}

	def createErrCaseXpathMap(errMessg){
		def xpathValueMap = [ 
			"error": "${errMessg}"
		]
		return xpathValueMap
	}

	def createErrCaseXpathMap(errMessg, errCode){
		def xpathValueMap = [ 
            "error/@message":"${errMessg}",
			"error/@code":"${errCode}",
		]
		return xpathValueMap
	}


	/*********************************************************
	/	10 finger with fusionWeight, without IndividualScore
	/********************************************************/
	def createCandidateXpathRoughMap(hitFlag, externalId, fusionScore, candidateTemplateCount, containerId1, 
									containerId2, eventId, searchRequestIndex, fusionWeight, compositeScore,
									individualScoreAxis1, individualScoreFingerNumber1, 
									individualScoreAxis2, individualScoreFingerNumber2,
									individualScoreAxis3, individualScoreFingerNumber3, 
									individualScoreAxis4, individualScoreFingerNumber4, 
									individualScoreAxis5, individualScoreFingerNumber5, 
									individualScoreAxis6, individualScoreFingerNumber6, 
									individualScoreAxis7, individualScoreFingerNumber7, 
									individualScoreAxis8, individualScoreFingerNumber8, 
									individualScoreAxis9, individualScoreFingerNumber9, 
									individualScoreAxis10, individualScoreFingerNumber10, existCount ){

		def candidateXpath = createCanidateWithFwRoughXpathTI(
								hitFlag, externalId, fusionScore, candidateTemplateCount, containerId1, 
								containerId2, eventId, searchRequestIndex, fusionWeight, compositeScore,
								individualScoreAxis1, individualScoreFingerNumber1, 
								individualScoreAxis2, individualScoreFingerNumber2, 
								individualScoreAxis3, individualScoreFingerNumber3, 
								individualScoreAxis4, individualScoreFingerNumber4, 
								individualScoreAxis5, individualScoreFingerNumber5, 
								individualScoreAxis6, individualScoreFingerNumber6, 
								individualScoreAxis7, individualScoreFingerNumber7, 
								individualScoreAxis8, individualScoreFingerNumber8, 
								individualScoreAxis9, individualScoreFingerNumber9, 
								individualScoreAxis10, individualScoreFingerNumber10 
						 )

		def xpathValueMap = [ "${candidateXpath}": "${existCount}" ]
		return xpathValueMap
	}


	/*****************************************************************
	/		LFML
	/*****************************************************************/
	private String createLfmlCanidateXpath(hitFlag, externalId, fusionScore, candidateTemplateCount,
							containerId, eventId, searchRequestIndex, compositeScore,
							iScorePos, iScoreVal, inquirySet, iScoreFw) {

		if(hitFlag == null){
            hitFlag = "false"
        }

        return """count(//candidate[
                externalId='${externalId}'
                and @hit='${hitFlag}'
                and fusion-score='${fusionScore}'
                and candidate-template[
                        containerId='${containerId}'
                        and eventId='${eventId}'
                        and searchRequestIndex='${searchRequestIndex}'
                        and not(fusionWeight)
                        and composite-score='${compositeScore}'
                        and individual-score[ 
                            not(@axis)
                            and not(@search-position)
                            and @inquirySet='${inquirySet}'
                            and @fusionWeight='${iScoreFw}'
                            and @position='${iScorePos}' 
                            and @value='${iScoreVal}' 
                        ]
                    ]
                ])"""
	}

	/*****************************************************************
	/		candidate XpathMapper  ( 1 finger )
	/*****************************************************************/
	private String createPalmCanidateXpath(hitFlag, externalId, fusionScore, candidateTemplateCount,
							containerId, eventId, searchRequestIndex, compositeScore,
							individualScoreAxis, individualScoreFingerNumber,
						 	individualScoreValue ){

		if(hitFlag == null){
            hitFlag = "false"
        }

        return """count(//candidate[
                externalId='${externalId}'
                and @hit='${hitFlag}'
                and fusion-score='${fusionScore}'
                and candidate-template[
                        containerId='${containerId}'
                        and eventId='${eventId}'
                        and searchRequestIndex='${searchRequestIndex}'
                        and not(fusionWeight)
                        and composite-score='${compositeScore}'
                        and individual-score[ 
                            not(@axis)
                            and not(@search-position)
                            and not(@inquirySet)
                            and not(@fusionWeight) 
                            and @position='${individualScoreFingerNumber}' 
                            and @value='${individualScoreValue}' 
                        ]
                    ]
                ])"""
	}


	private String createCanidateWithFwXpath(hitFlag, externalId, fusionScore, candidateTemplateCount,
							containerId, eventId, searchRequestIndex, fusionWeight, compositeScore,
							iScoreAxis, iScorePos, iScoreVal, inqSet ){

        def axisCondition
        def fWeightCondition
        def inqSetCondition

		if(hitFlag == null){
            hitFlag = false
        }

        if(iScoreAxis == null) {
            axisCondition = "not(@axis)"
        }else{
            axisCondition = "@axis='${iScoreAxis}'"
        }

        if(inqSet == null) {
            fWeightCondition = "not(@fusionWeight)"
            inqSetCondition = "not(@inquirySet)"
        }else{
            fWeightCondition = "@fusionWeight='${fusionWeight}'"
            inqSetCondition = "@inquirySet='${inqSet}'"
        }

        return """count(//candidate[
                externalId='${externalId}'
                and @hit='${hitFlag}'
                and fusion-score='${fusionScore}'
                and candidate-template[
                        containerId='${containerId}'
                        and eventId='${eventId}'
                        and searchRequestIndex='${searchRequestIndex}'
                        and not(fusionWeight)
                        and composite-score='${compositeScore}'
                        and individual-score[
                                @position='${iScorePos}'
                                and @value='${iScoreVal}'
                                and ${axisCondition}
                                and ${fWeightCondition}
                                and ${inqSetCondition}
								and not(@search-position)
                        ]
                    ]
                ])"""
	}


	/*****************************************************************
	/		candidate XpathMapper  ( 10 finger )
	/*****************************************************************/
	private String createCanidateWithFwXpathTI(hitFlag, externalId, fusionScore, candidateTemplateCount,
							containerId, eventId, searchRequestIndex, compositeScore, inqSet, fw,
							iScoreAxis1, pos1, iScoreVal1, iScoreAxis2, pos2, iScoreVal2,
							iScoreAxis3, pos3, iScoreVal3, iScoreAxis4, pos4, iScoreVal4,
							iScoreAxis5, pos5, iScoreVal5, iScoreAxis6, pos6, iScoreVal6,
							iScoreAxis7, pos7, iScoreVal7, iScoreAxis8, pos8, iScoreVal8,
							iScoreAxis9, pos9, iScoreVal9, iScoreAxis10, pos10, iScoreVal10) {
		if(hitFlag == null){
            hitFlag = false
        }
        StringBuilder sb = new StringBuilder()
        sb.append( """count(//candidate[
        	    		externalId='${externalId}'
							and @hit='${hitFlag}'
							and fusion-score='${fusionScore}'
							and candidate-template[
							containerId='${containerId}'
							and eventId='${eventId}'
							and searchRequestIndex='${searchRequestIndex}'
							and not(fusionWeight)
							and composite-score='${compositeScore}' """)
		if(isCmlTim(containerId)){
			sb.append("""
					and individual-score[1][ not(@axis) and @search-position='${pos1}' and @position='${pos1}' and @value='${iScoreVal1}' 
						and @fusionWeight='100' and @inquirySet='${inqSet}' ]
					and individual-score[2][ not(@axis) and @search-position='${pos2}' and @position='${pos2}' and @value='${iScoreVal2}' 
						and @fusionWeight='100' and @inquirySet='${inqSet}' ]
					and individual-score[3][ not(@axis) and @search-position='${pos3}' and @position='${pos3}' and @value='${iScoreVal3}' 
						and @fusionWeight='100' and @inquirySet='${inqSet}' ]
					and individual-score[4][ not(@axis) and @search-position='${pos4}' and @position='${pos4}' and @value='${iScoreVal4}' 
						and @fusionWeight='100' and @inquirySet='${inqSet}' ]
					and individual-score[5][ not(@axis) and @search-position='${pos5}' and @position='${pos5}' and @value='${iScoreVal5}' 
						and @fusionWeight='100' and @inquirySet='${inqSet}' ]
					and individual-score[6][ not(@axis) and @search-position='${pos6}' and @position='${pos6}' and @value='${iScoreVal6}' 
						and @fusionWeight='100' and @inquirySet='${inqSet}' ]
					and individual-score[7][ not(@axis) and @search-position='${pos7}' and @position='${pos7}' and @value='${iScoreVal7}' 
						and @fusionWeight='100' and @inquirySet='${inqSet}' ]
					and individual-score[8][ not(@axis) and @search-position='${pos8}' and @position='${pos8}' and @value='${iScoreVal8}' 
						and @fusionWeight='100' and @inquirySet='${inqSet}' ]
					and individual-score[9][ not(@axis) and @search-position='${pos9}' and @position='${pos9}' and @value='${iScoreVal9}' 
						and @fusionWeight='100' and @inquirySet='${inqSet}' ]
					and individual-score[10][ not(@axis) and @search-position='${pos10}' and @position='${pos10}' and @value='${iScoreVal10}' 
						and @fusionWeight='100' and @inquirySet='${inqSet}' ]
                	]
            	])""")
		}else{
			sb.append("""
					and individual-score[1][ not(@axis) and not(@search-position) and @position='${pos1}' and @value='${iScoreVal1}' 
						and @fusionWeight='100' and @inquirySet='${inqSet}' ]
					and individual-score[2][ not(@axis) and not(@search-position) and @position='${pos2}' and @value='${iScoreVal2}' 
						and @fusionWeight='100' and @inquirySet='${inqSet}' ]
					and individual-score[3][ not(@axis) and not(@search-position) and @position='${pos3}' and @value='${iScoreVal3}' 
						and @fusionWeight='100' and @inquirySet='${inqSet}' ]
					and individual-score[4][ not(@axis) and not(@search-position) and @position='${pos4}' and @value='${iScoreVal4}' 
						and @fusionWeight='100' and @inquirySet='${inqSet}' ]
					and individual-score[5][ not(@axis) and not(@search-position) and @position='${pos5}' and @value='${iScoreVal5}' 
						and @fusionWeight='100' and @inquirySet='${inqSet}' ]
					and individual-score[6][ not(@axis) and not(@search-position) and @position='${pos6}' and @value='${iScoreVal6}' 
						and @fusionWeight='100' and @inquirySet='${inqSet}' ]
					and individual-score[7][ not(@axis) and not(@search-position) and @position='${pos7}' and @value='${iScoreVal7}' 
						and @fusionWeight='100' and @inquirySet='${inqSet}' ]
					and individual-score[8][ not(@axis) and not(@search-position) and @position='${pos8}' and @value='${iScoreVal8}' 
						and @fusionWeight='100' and @inquirySet='${inqSet}' ]
					and individual-score[9][ not(@axis) and not(@search-position) and @position='${pos9}' and @value='${iScoreVal9}' 
						and @fusionWeight='100' and @inquirySet='${inqSet}' ]
					and individual-score[10][ not(@axis) and not(@search-position) and @position='${pos10}' and @value='${iScoreVal10}' 
						and @fusionWeight='100' and @inquirySet='${inqSet}' ]
                	]
            	])""")
		}
		return sb.toString()
	}

	/*****************************************************************
	/		candidate XpathMapper  ( 10 finger search-position set)
	/*****************************************************************/
	private String createCanidateWithFwXpathTI(hitFlag, externalId, fusionScore, candidateTemplateCount,
							containerId, eventId, searchRequestIndex, compositeScore, inqSet, fw,
							iScoreAxis1, spos1, pos1, iScoreVal1, iScoreAxis2, spos2, pos2, iScoreVal2,
							iScoreAxis3, spos3, pos3, iScoreVal3, iScoreAxis4, spos4, pos4, iScoreVal4,
							iScoreAxis5, spos5, pos5, iScoreVal5, iScoreAxis6, spos6, pos6, iScoreVal6,
							iScoreAxis7, spos7, pos7, iScoreVal7, iScoreAxis8, spos8, pos8, iScoreVal8,
							iScoreAxis9, spos9, pos9, iScoreVal9, iScoreAxis10, spos10, pos10, iScoreVal10) {

		if(hitFlag == null){
            hitFlag = false
        }

        return """count(//candidate[
            externalId='${externalId}'
            and @hit='${hitFlag}'
            and fusion-score='${fusionScore}'
            and candidate-template[
                containerId='${containerId}'
                and eventId='${eventId}'
                and searchRequestIndex='${searchRequestIndex}'
                and not(fusionWeight)
                and composite-score='${compositeScore}'
                and individual-score[1][ not(@axis) and @search-position='${spos1}' and @position='${pos1}' and @value='${iScoreVal1}' 
                      and @fusionWeight='100' and @inquirySet='${inqSet}' ]
                and individual-score[2][ not(@axis) and @search-position='${spos2}' and @position='${pos2}' and @value='${iScoreVal2}' 
                      and @fusionWeight='100' and @inquirySet='${inqSet}' ]
                and individual-score[3][ not(@axis) and @search-position='${spos3}' and @position='${pos3}' and @value='${iScoreVal3}' 
                      and @fusionWeight='100' and @inquirySet='${inqSet}' ]
                and individual-score[4][ not(@axis) and @search-position='${spos4}' and @position='${pos4}' and @value='${iScoreVal4}' 
                      and @fusionWeight='100' and @inquirySet='${inqSet}' ]
                and individual-score[5][ not(@axis) and @search-position='${spos5}' and @position='${pos5}' and @value='${iScoreVal5}' 
                      and @fusionWeight='100' and @inquirySet='${inqSet}' ]
                and individual-score[6][ not(@axis) and @search-position='${spos6}' and @position='${pos6}' and @value='${iScoreVal6}' 
                      and @fusionWeight='100' and @inquirySet='${inqSet}' ]
                and individual-score[7][ not(@axis) and @search-position='${spos7}' and @position='${pos7}' and @value='${iScoreVal7}' 
                      and @fusionWeight='100' and @inquirySet='${inqSet}' ]
                and individual-score[8][ not(@axis) and @search-position='${spos8}' and @position='${pos8}' and @value='${iScoreVal8}' 
                      and @fusionWeight='100' and @inquirySet='${inqSet}' ]
                and individual-score[9][ not(@axis) and @search-position='${spos9}' and @position='${pos9}' and @value='${iScoreVal9}' 
                      and @fusionWeight='100' and @inquirySet='${inqSet}' ]
                and individual-score[10][ not(@axis) and @search-position='${spos10}' and @position='${pos10}' and @value='${iScoreVal10}' 
                      and @fusionWeight='100' and @inquirySet='${inqSet}' ]
                ]
            ])"""
	}

	def createCanidateWithFwRoughXpathTI(hitFlag, externalId, fusionScore, candidateTemplateCount,
							containerId1, containerId2, eventId, searchRequestIndex, fusionWeight, compositeScore,
							individualScoreAxis1, individualScoreFingerNumber1, 
							individualScoreAxis2, individualScoreFingerNumber2, 
							individualScoreAxis3, individualScoreFingerNumber3, 
							individualScoreAxis4, individualScoreFingerNumber4, 
							individualScoreAxis5, individualScoreFingerNumber5, 
							individualScoreAxis6, individualScoreFingerNumber6, 
							individualScoreAxis7, individualScoreFingerNumber7, 
							individualScoreAxis8, individualScoreFingerNumber8, 
							individualScoreAxis9, individualScoreFingerNumber9, 
							individualScoreAxis10, individualScoreFingerNumber10 
						) {

		///////////////////
		// 10 finger 
		// hitFlag Y
		// fusionWeight Y
		///////////////////

		if(hitFlag != null){
			return """count(//candidate[
					externalId='${externalId}'
					and @hit='${hitFlag}'
					and fusion-score='${fusionScore}'
					and candidate-template[
							(containerId='${containerId1}' or containerId='${containerId2}')
							and eventId='${eventId}'
							and searchRequestIndex='${searchRequestIndex}'
							and not(fusionWeight)
							and composite-score='${compositeScore}'
							and individual-score[1][ @axis='${individualScoreAxis1}' and @fingerNumber='${individualScoreFingerNumber1}' and @fusionWeight='${fusionWeight}' ] 
							and individual-score[2][ @axis='${individualScoreAxis2}' and @fingerNumber='${individualScoreFingerNumber2}' and @fusionWeight='${fusionWeight}' ] 
							and individual-score[3][ @axis='${individualScoreAxis3}' and @fingerNumber='${individualScoreFingerNumber3}' and @fusionWeight='${fusionWeight}' ] 
							and individual-score[4][ @axis='${individualScoreAxis4}' and @fingerNumber='${individualScoreFingerNumber4}' and @fusionWeight='${fusionWeight}' ]
							and individual-score[5][ @axis='${individualScoreAxis5}' and @fingerNumber='${individualScoreFingerNumber5}' and @fusionWeight='${fusionWeight}' ] 
							and individual-score[6][ @axis='${individualScoreAxis6}' and @fingerNumber='${individualScoreFingerNumber6}' and @fusionWeight='${fusionWeight}' ] 
							and individual-score[7][ @axis='${individualScoreAxis7}' and @fingerNumber='${individualScoreFingerNumber7}' and @fusionWeight='${fusionWeight}' ] 
							and individual-score[8][ @axis='${individualScoreAxis8}' and @fingerNumber='${individualScoreFingerNumber8}' and @fusionWeight='${fusionWeight}' ] 
							and individual-score[9][ @axis='${individualScoreAxis9}' and @fingerNumber='${individualScoreFingerNumber9}' and @fusionWeight='${fusionWeight}' ] 
							and individual-score[10][ @axis='${individualScoreAxis10}' and @fingerNumber='${individualScoreFingerNumber10}' and @fusionWeight='${fusionWeight}' ]
						]
					])"""

		///////////////////
		// 10 finger 
		// hitFlag N
		// fusionWeight Y
		///////////////////

		}else{
			return """count(//candidate[
					externalId='${externalId}'
					and not(@hit)
					and fusion-score='${fusionScore}'
					and candidate-template[
							(containerId='${containerId1}' or containerId='${containerId2}')
							and eventId='${eventId}'
							and searchRequestIndex='${searchRequestIndex}'
							and not(fusionWeight)
							and composite-score='${compositeScore}'
							and individual-score[1][ @axis='${individualScoreAxis1}' and @fingerNumber='${individualScoreFingerNumber1}' and @fusionWeight='${fusionWeight}' ]
							and individual-score[2][ @axis='${individualScoreAxis2}' and @fingerNumber='${individualScoreFingerNumber2}' and @fusionWeight='${fusionWeight}' ]
							and individual-score[3][ @axis='${individualScoreAxis3}' and @fingerNumber='${individualScoreFingerNumber3}' and @fusionWeight='${fusionWeight}' ]
							and individual-score[4][ @axis='${individualScoreAxis4}' and @fingerNumber='${individualScoreFingerNumber4}' and @fusionWeight='${fusionWeight}' ]
							and individual-score[5][ @axis='${individualScoreAxis5}' and @fingerNumber='${individualScoreFingerNumber5}' and @fusionWeight='${fusionWeight}' ]
							and individual-score[6][ @axis='${individualScoreAxis6}' and @fingerNumber='${individualScoreFingerNumber6}' and @fusionWeight='${fusionWeight}' ]
							and individual-score[7][ @axis='${individualScoreAxis7}' and @fingerNumber='${individualScoreFingerNumber7}' and @fusionWeight='${fusionWeight}' ]
							and individual-score[8][ @axis='${individualScoreAxis8}' and @fingerNumber='${individualScoreFingerNumber8}' and @fusionWeight='${fusionWeight}' ]
							and individual-score[9][ @axis='${individualScoreAxis9}' and @fingerNumber='${individualScoreFingerNumber9}' and @fusionWeight='${fusionWeight}' ]
							and individual-score[10][ @axis='${individualScoreAxis10}' and @fingerNumber='${individualScoreFingerNumber10}' and @fusionWeight='${fusionWeight}' ]
						]
					])"""
		}
	}

	def createExtractResultFingerOutputXpath(position, expectedCount){
		def xpathValueMap = [ 
			"count(//finger-output[@pos='${position}'])": "${expectedCount}",
		]
		return xpathValueMap
	}

	def createExtractResultFingerOutputSizeXpath(expectedCount){
		def xpathValueMap = [ 
			"count(//finger-output)": "${expectedCount}",
		]
		return xpathValueMap
	}

	def createGetExtractResultKeyedBinaryXpath(key, expectedCount){
		def xpathValueMap = [ 
			"count(return/keyed-binary[key='${key}'])": "${expectedCount}",
		]
		return xpathValueMap
	}

	def createCallbackExtractResultKeyedBinaryXpath(key, expectedCount){
		def xpathValueMap = [ 
			"count(keyed-binary[key='${key}'])": "${expectedCount}",
		]
		return xpathValueMap
	}

	def createExtractResultKeyedBinarySizeXpath(expectedCount){
		def xpathValueMap = [ 
			"count(//keyed-binary)": "${expectedCount}",
		]
		return xpathValueMap
	}

	def createExtractResultFaceOutputSizeXpath(expectedCount){
		def xpathValueMap = [ 
			"count(//face-output)": "${expectedCount}",
		]
		return xpathValueMap
	}

	def createFaceDetectionPointsSizeXpath(expectedCount){
		def xpathValueMap = [ 
			"count(//points)": "${expectedCount}",
		]
		return xpathValueMap
	}

	def createInputCropPointXpath(pos, index, xy){
		return "//seg-info[@pos='${pos}']/crop-info/crop-points/points[${index}]/@${xy}"
	}

	def createOutputCropPointXpathMap(pos, expectedCount){
		def xpathValueMap = [ 
			"count(//finger-output[@pos='${pos}'])": "${expectedCount}"
		]
		return xpathValueMap
	}

	def createOutputCropPointXpathMap(pos, index, xy, value, expectedCount){
		def xpathValueMap = [ 
			"count(//finger-output[@pos='${pos}']/crop-info/crop_points/points[${index}][@${xy}='${value}'])": "${expectedCount}"
		]
		return xpathValueMap
	}

	def createOutputCropCenterPointXpathMap(pos, xy, value, expectedCount){
		def xpathValueMap = [ 
			"count(//finger-output[@pos='${pos}']/crop-info/center[@${xy}='${value}'])": "${expectedCount}"
		]
		return xpathValueMap
	}

	// for after AIM-3.0
	def createVXFaultXpathMap(errCode, errMessg){
		def xpathValueMap = [ 
			"//code": "${errCode}",
			"//faultstring": "${errMessg}"
		]

		return xpathValueMap
	}

	// for AIM-VX ver 3.0.3
	def _createVXFaultXpathMap(errCode, errMessg){
		def xpathValueMap = [ 
			"//code": "${errCode}",
			"//messageObj/detail": "${errMessg}"
		]

		return xpathValueMap
	}

        /*****************************************************************
        /               verify result XpathMapper  (  finger )
        /*****************************************************************/
        def createVerifyFiveFingersResultXpathMap(externalId, fusionScore, compositeScore, positions, scores, modal) {
                def resultXpath =  """count(//candidateResultList[
                                        externalId='${externalId}'
                                        and fusionScore='${fusionScore}'
                                        and modalScoreList[
                                                compositeScore='${compositeScore}'
                                                and individualScoreList[1][
                                                        position='${positions[0]}'
                                                        and score='${scores[0]}'
                                                        ]
                                                and individualScoreList[2][
                                                        position='${positions[1]}'
                                                        and score='${scores[1]}'
                                                        ]
                                                and individualScoreList[3][
                                                        position='${positions[2]}'
                                                        and score='${scores[2]}'
                                                        ]
                                                and individualScoreList[4][
                                                        position='${positions[3]}'
                                                        and score='${scores[3]}'
                                                        ]
                                                and individualScoreList[5][
                                                        position='${positions[4]}'
                                                        and score='${scores[4]}'
                                                        ]
                                                and modal='${modal}'
                                                ]
                                        ])"""
                def xpathValueMap = ["${resultXpath}": "1"]
                return xpathValueMap
        }

        /*****************************************************************
        /               verify result XpathMapper  ( 10 finger )
        /*****************************************************************/

        def createVerifyTenFingersResultXpathMap(externalId, fusionScore, compositeScore, positions, scores, modal) {
                def resultXpath =  """count(//candidateResultList[
                                        externalId='${externalId}'
                                        and fusionScore='${fusionScore}'
                                        and modalScoreList[
                                                compositeScore='${compositeScore}'
                                                and individualScoreList[1][
                                                        position='${positions[0]}'
                                                        and score='${scores[0]}'
                                                        ]
                                                and individualScoreList[2][
                                                        position='${positions[1]}'
                                                        and score='${scores[1]}'
                                                        ]
                                                and individualScoreList[3][
                                                        position='${positions[2]}'
                                                        and score='${scores[2]}'
                                                        ]
                                                and individualScoreList[4][
                                                        position='${positions[3]}'
                                                        and score='${scores[3]}'
                                                        ]
                                                and individualScoreList[5][
                                                        position='${positions[4]}'
                                                        and score='${scores[4]}'
                                                        ]
                                                and individualScoreList[6][
                                                        position='${positions[5]}'
                                                        and score='${scores[5]}'
                                                        ]
                                                and individualScoreList[7][
                                                        position='${positions[6]}'
                                                        and score='${scores[6]}'
                                                        ]
                                                and individualScoreList[8][
                                                        position='${positions[7]}'
                                                        and score='${scores[7]}'
                                                        ]
                                                and individualScoreList[9][
                                                        position='${positions[8]}'
                                                        and score='${scores[8]}'
                                                        ]
                                                and individualScoreList[10][
                                                        position='${positions[9]}'
                                                        and score='${scores[9]}'
                                                        ]
                                                and modal='${modal}'
                                                ]
                                        ])"""
                def xpathValueMap = ["${resultXpath}": "1"]
                return xpathValueMap

        }

        /*****************************************************************
        /               verify result XpathMapper  ( 2 finger )
        /*****************************************************************/

        def createVerifyResultXpathMap(externalId, fusionScore, compositeScore, position1, score1, position2, score2, modal) {
                def resultXpath =  """count(//candidateResultList[
                                        externalId='${externalId}'
                                        and fusionScore='${fusionScore}'
                                        and modalScoreList[
                                                compositeScore='${compositeScore}'
                                                and individualScoreList[1][
                                                        position='${position1}'
                                                        and score='${score1}'
                                                        ]
                                                and individualScoreList[2][
                                                        position='${position2}'
                                                        and score='${score2}'
                                                        ]
                                                and modal='${modal}'
                                                ]
                                        ])"""
                def xpathValueMap = ["${resultXpath}": "1"]
                return xpathValueMap

        }

        /*****************************************************************
        /               verify result XpathMapper  ( 1 finger )
        /*****************************************************************/
	def createVerifyResultXpathMap(externalId, fusionScore, compositeScore, position1, score1, modal) {
                def resultXpath =  """count(//candidateResultList[
                                        externalId='${externalId}'
                                        and fusionScore='${fusionScore}'
                                        and modalScoreList[
                                                compositeScore='${compositeScore}'
                                                and individualScoreList[
                                                        position='${position1}'
                                                        and score='${score1}'
                                                        ]
                                                and modal='${modal}'
                                                ]
                                        ])"""
                def xpathValueMap = ["${resultXpath}": "1"]
                return xpathValueMap

        }

        /*****************************************************************
        /               verify result XpathMapper  ( Search/hit = 2/1 )
        /*****************************************************************/
	def createVerifyResultOnlyOneMatchXpathMap(externalId, fusionScore, compositeScore, position1, score1, modal, code, msg) {
                def resultXpath =  """count(//candidateResultList[
                                        externalId='${externalId}'
                                        and fusionScore='${fusionScore}'
                                        and modalScoreList[
                                                compositeScore='${compositeScore}'
                                                and individualScoreList[
                                                        position='${position1}'
                                                        and score='${score1}'
                                                        ]
                                                and modal='${modal}'
                                                ]
                                        ])"""
                def xpathValueMap = [
			"${resultXpath}": "1",
			"//code": "${code}",
			"//messageObj/detail": "${msg}"
		]
                
		return xpathValueMap

        }

        /*****************************************************************
        /               verify result XpathMapper  ( both eyes )
        /*****************************************************************/

        def createVerifyResultXpathMap(externalId, fusionScore, compositeScore, position1, score1, irisInquiryResultList1,
										position2, score2, irisInquiryResultList2, modal) {
				StringBuilder sb = new StringBuilder()
                sb.append("""count(//candidateResultList[
                                        externalId='${externalId}'
                                        and fusionScore='${fusionScore}'
                                        and modalScoreList[
                                                compositeScore='${compositeScore}'
                                                and individualScoreList[1][
                                                        position='${position1}'
                                                        and score='${score1}' """)
				sb.append(makeIrisInquiryResult(irisInquiryResultList1))
				sb.append("""	]
                                                and individualScoreList[2][
                                                        position='${position2}'
                                                        and score='${score2}'""")
				sb.append(makeIrisInquiryResult(irisInquiryResultList2))
				sb.append("""							]
                                                and modal='${modal}'
                                                ]
                                        ])""")
				def str = sb.toString()
                def xpathValueMap = [ "${str}" : "1"]
                return xpathValueMap

        }

        /*****************************************************************
        /               verify result XpathMapper  ( single eyes )
        /*****************************************************************/

        def createVerifyResultXpathMap(externalId, fusionScore, compositeScore, position1, score1, irisInquiryResultList1, modal) {
				StringBuilder sb = new StringBuilder()
                sb.append("""count(//candidateResultList[
                                        externalId='${externalId}'
                                        and fusionScore='${fusionScore}'
                                        and modalScoreList[
                                                compositeScore='${compositeScore}'
                                                and individualScoreList[1][
                                                        position='${position1}'
                                                        and score='${score1}' """)
				sb.append(makeIrisInquiryResult(irisInquiryResultList1))
				sb.append("""							]
                                                and modal='${modal}'
                                                ]
                                        ])""")
				def str = sb.toString()
                def xpathValueMap = [ "${str}" : "1"]
                return xpathValueMap

        }

	def creatVerifyStatusListXpathMap(List statusListList) {
		StringBuilder sb = new StringBuilder()
		sb.append("""count(//candidateResultList[""")
		sb.append(makeStatusList(statusListList))
		sb.append(""" ])""")
				def str = sb.toString()
                def xpathValueMap = [ "${str}" : "1"]
                return xpathValueMap
	}

	private String makeStatusList(List statusListList){
        StringBuilder sb = new StringBuilder()
		int i = 1
		for(statusList in statusListList){
			def code = statusList[0]
			def detail = statusList[1]
            if(i >= 2) {
                sb.append("         and ")
            }
        	sb.append("""
							statusList[
								code='${code}'
								and detail='${detail}'
							]""")
			i++
		}
		return sb.toString()
	}

    private String makeIrisInquiryResult(List rowScoreList) {
        StringBuilder sb = new StringBuilder()
        sb.append("""
                            and irisInquiryResult[""")
        int i = 1
        for(rowScore in rowScoreList) {
            def filePos = rowScore[0]
            def score = rowScore[1]
            if(i >= 2) {
                sb.append("         and ")
            }
            sb.append("""
                                    crossMatchingResultList[${i}][
                                        filePosition='${filePos}'
                                        and score='${score}'
                                    ]\n""")
            i++
        }

        sb.append("""
                            ]\n""")

        return sb.toString()
    }

	protected isCmlTim(def containerId){
		return	String.valueOf(containerId).contains(RDBTM_ID) && globalProperties.getTimEngine() == CML ||
             	String.valueOf(containerId).contains(SDBTM_ID) && globalProperties.getTimEngine() == CML
	}
	

}

