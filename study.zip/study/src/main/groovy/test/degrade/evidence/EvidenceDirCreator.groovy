package test.degrade.evidence

import test.degrade.util.*
import test.degrade.constants.soapui.*

class EvidenceDirCreator{
	SoapuiObject soapuiObject
	File dir
	
	EvidenceDirCreator(context, String subDirName){
		this.soapuiObject = new SoapuiObject(context)
		this.dir = new File(soapuiObject.getEvidenceDataDirName() + "/" + subDirName)
	}

	EvidenceDirCreator(context){
		this.soapuiObject = new SoapuiObject(context)
		this.dir = new File(soapuiObject.getEvidenceDataDirName())
	}

	public void mkdir() {
		dir.mkdirs()
	}

	public String getPath() {
		return dir.getPath()
	}
	
	public void cleanUnderDir(){
		dir.eachFile{
			new File(it as String).delete()
		}
	}
}

