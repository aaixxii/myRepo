package test.degrade.evidence

import degrade.util.*

class TestTitleOutputor{
	static final String SOAPUI_TEST_SUMMARY = "soapUITestSummary"
	def context
	def soapuiObject
	def file
	def date
	
	TestTitleOutputor(context){
		def outputRootDir = context.expand( '${outPutPath}' )
		def soapUITestSummaryDir = new File("${outputRootDir}/${SOAPUI_TEST_SUMMARY}")
		soapUITestSummaryDir.mkdirs()
		this.context = context
		this.soapuiObject = new SoapuiObject(context)
		this.file = new File("${outputRootDir}/${SOAPUI_TEST_SUMMARY}/" + soapuiObject.getTestProjectName() + ".txt")
		this.date = new Date().format("yyyy/MM/dd HH:mm:ss")
	}

	def outputTestCaseTitle(){
		def testName = context.expand( '${Properties#testcase_name}' )
		file.append("        ----${testName}---- ${date}\n")
	}

	def outputTestProjectTitle(){
		def testName = soapuiObject.getTestProjectName()
		file.append("        ==================================================\n")
		file.append("         ${testName}  ${date}\n")
		file.append("        ==================================================\n")
	}
}

