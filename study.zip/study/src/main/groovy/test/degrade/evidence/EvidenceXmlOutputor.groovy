package test.degrade.evidence

import test.degrade.util.*

class EvidenceXmlOutputor{
	def dirName
	def fileName

	EvidenceXmlOutputor(context){
		def soapuiObject = new SoapuiObject(context)
		this.dirName  = soapuiObject.getEvidenceXmlDirName()
		this.fileName = dirName + "/" + soapuiObject.getTestCaseName() + ".xml"
	}

	EvidenceXmlOutputor(context, id){
		def soapuiObject = new SoapuiObject(context)
		this.dirName  = soapuiObject.getEvidenceXmlDirName()
		this.fileName = dirName + "/" + soapuiObject.getTestCaseName() + "_${id}.xml"
	}

	def outputXml(xml){
		makeOutputDir()
		writeXml(xml)
	}	

	def makeOutputDir(){
		new File(dirName).mkdirs()
	}

	def writeXml(xml){
		new File(fileName).write(xml)
	}
}

