package test.degrade.evidence

import common.xml.*
import common.util.*
import common.util.time.*
import test.degrade.util.*
import test.degrade.constants.soapui.*

class EvidenceFileOutputor{
	def context
	SoapuiObject soapuiObject
	def file
	def date
	def otherFile
	
	EvidenceFileOutputor(context){
		def outputRootDir = context.expand( '${outPutPath}' ) + "/" + SoapuiDefines.SOAPUI_TEST_SUMMARY
		def soapUITestSummaryDir = new File(outputRootDir)
		soapUITestSummaryDir.mkdirs()
		this.context = context
		this.soapuiObject = new SoapuiObject(context)
		this.file = new File("${outputRootDir}/" + soapuiObject.getTestProjectName() + ".txt")
		this.date = new Date().format("yyyy/MM/dd HH:mm:ss,SSS")
		this.otherFile = new File("${outputRootDir}/" + soapuiObject.getTestProjectName() + "_other")
	}
	
	public File getResultDataRootDir(){
		String resultDataDirPath = soapuiObject.getContext().expand('${outPutPath}') + "/" + SoapuiDefines.RESULT_DATA
		return new File(resultDataDirPath)
	}
	
	public String getResultDataRootDirPath(){
        return  soapuiObject.getContext().expand('${outPutPath}') + "/" + SoapuiDefines.RESULT_DATA
    }
	
	public File getResultDataDir(){
		String resultDataDirPath = getResultDataDirPath()
		return new File(resultDataDirPath)
	}

	private String getResultDataDirPath() {
		return soapuiObject.getEvidenceDirName(SoapuiDefines.RESULT_DATA)
	}

	public void outputResultDataAsBinary(String fileName, def data){
		def binary = Encoder.stringToBinary(data)
		outputResultData(fileName, binary)
	}

	public void outputResultDataAsBinary(String dirPath, String fileName, def data){
		def binary = Encoder.stringToBinary(data)
		outputResultData(dirPath, fileName, binary)
    }
	
	public void outputResultData(String fileName, def data){
		mkResultDataDir()
		File resultDataFile = new File(getResultDataDirPath() + "/" + fileName)
		resultDataFile.write("")
		resultDataFile.append(data)	
	}

	public void outputResultData(String dirPath, String fileName, def data){
        String outputDirPath  = getResultDataRootDirPath() + "/" + dirPath
        new File(outputDirPath).mkdirs()
        File resultDataFile = new File( outputDirPath + "/"  + fileName)
        resultDataFile.write("")
        resultDataFile.append(data)
    }

	private void mkResultDataDir(){
		File resultDataDir = getResultDataDir()
		resultDataDir.mkdirs()
	}

	def outputTestCaseTitle(){
		def testName = soapuiObject.getTestCaseName()
		file.append("${date}         ----${testName}---- \n")
	}

	def outputTestCaseTitleUseProperties(){
		def testName = context.expand( '${Properties#testcase_name}' )
		file.append("${date}         ----${testName}---- \n")
	}

	def outputTestProjectTitle(){
		def testName = soapuiObject.getTestProjectName()
		file.append("        ==================================================\n")
		file.append("         ${testName}  ${date}\n")
		file.append("        ==================================================\n")
	}
	
	def outputTestProjectTitle(String startOrEnd){
		def testName = soapuiObject.getTestProjectName()
		file.append("        ==================================================\n")
		file.append("         ${testName} ${startOrEnd}  ${date}\n")
		file.append("        ==================================================\n")
	}
	
	def outputTestProjectTitleStart(){
		outputTestProjectTitle("Start")
	}
	
	def outputTestProjectTitleEnd(){
		outputTestProjectTitle("End")
	}
	
	def outputFalseMess(message){
		message = SoapuiDefines.FALSE + " [ ${message} ]"
		fileAppendWithTimestamp(message)
	}

	def outputTrueMess(message){
		message = SoapuiDefines.TRUE + " [ ${message} ]"
		fileAppendWithTimestamp(message)
	}

	def outputSkipMess(message){
		message = SoapuiDefines.SKIP + " [ ${message} ]"
		fileAppendWithTimestamp(message)
	}

	def outputIndent(){
		file.append("\n")
	}

	def fileAppendWithTimestamp(String messg){
		def dateStr = TimeManager.getCurrentTimeStr()
		file.append("${dateStr} ${messg} \n")
	}

	def setOtherFile(def id) {
		def outputRootDir = soapuiObject.getEvidenceDataDirName()
		File resultDataDir = new File(outputRootDir)
		resultDataDir.mkdirs()
		this.otherFile = new File("${outputRootDir}/" + soapuiObject.getTestProjectName() + "_${id}")
	}

	def outputOtherFile(def data) {
		otherFile.write("")
		otherFile.append(data)
	}
}

