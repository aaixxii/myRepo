package degradeTest.file.io

import degradeTest.*
import degradeTest.soapui.*
import degradeTest.define.soapui.*
import degradeTest.soapui.util.*

class EvidenceXmlInputor{
	def soapuiObject
	//def dirName = "degradeTest/" + Defines.RESULT_XML
	def dirName
	def fileName
/*
	EvidenceXmlInputor(context){
		def globalProperties = new GlobalProperties(context)
		this.soapuiObject = new SoapuiObject(context)
		this.dirName = globalProperties.getDataFilePath() + "/${dirName}/" + 
						globalProperties.getVerNum() + "/" + soapuiObject.getTestProjectName()
		this.fileName = this.dirName + "/" + soapuiObject.getTestCaseName() + ".xml"
	}
*/
	EvidenceXmlInputor(context, rootDir){
		def globalProperties = new GlobalProperties(context)
		this.soapuiObject = new SoapuiObject(context)
		this.dirName = "${rootDir}/" + globalProperties.getVerNum() + "/" + soapuiObject.getTestProjectName()
		this.fileName = this.dirName + "/" + soapuiObject.getTestCaseName() + ".xml"
	}

	EvidenceXmlInputor(context, rootDir, id){
		def globalProperties = new GlobalProperties(context)
		this.soapuiObject = new SoapuiObject(context)
		this.dirName = "${rootDir}/" + globalProperties.getVerNum() + "/" + soapuiObject.getTestProjectName()
		this.fileName = this.dirName + "/" + soapuiObject.getTestCaseName() + "_${id}.xml"
	}

	def getXmlFile(){
		return new File(fileName)
	}	
}

