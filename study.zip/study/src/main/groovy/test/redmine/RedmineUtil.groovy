package test.redmine

class RedmineUtil {

	String baseInsertPayload = "<reqs destinationContainer=\"%s\"> \n <record>\n <binary>\${readTemplate#result}</binary> \n</record> \n</reqs>\n"
	List insertBinIdList = [ 1, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
						4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 
						323, 323, 323, 323, 323, 323, 323, 323, 323, 323, 
						324, 324, 324, 324, 324, 324, 324, 324, 324, 324, 324 ]
	String baseDeletePayload = "<containerIds>%s</containerIds>\n"
	List deleteBinIdList = [ 1, 2, 3, 4, 323, 324 ]

	def redmine14831_getInsertPayload(){
		Collections.shuffle(insertBinIdList)
		String insertPayload = ""
		for(binId in insertBinIdList){
			insertPayload += String.format(baseInsertPayload, binId)
		}
		return insertPayload;
	}

	def redmine14831_getDeletePayload(){
		Collections.shuffle(deleteBinIdList)
		String deletePayload = ""
		for(binId in deleteBinIdList){
			deletePayload += String.format(baseDeletePayload, binId)
		}
		return deletePayload;
	}


}
