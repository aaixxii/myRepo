package test.performance.logger

import common.queue.SingletonMapQueue
import common.sql.*
import test.performance.queue.*
import test.common.properties.ProjectProperties;
import test.common.util.db.*
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobResult;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryResultStatisticsAMR;


import test.degrade.util.SoapuiObject


class ResponseTimeLogger {
	private static SoapuiObject soapuiObj
	private static final String SLASH = "/"
	private static final String DB_IP = "DBIP"
	private static final String DB_PORT = "DBPort"
	private static final String DB_SID = "DBSID"
	private static final String DB_USER = "DBUser"
	private static final String DB_PASS = "DBPass"
	private static final String OUTPUT_DIR = "outputDir"
	private logBuff = new StringBuilder()
	private logBuffAppendix = new StringBuilder()
    private Date clientStartTs
    private Date clientEndTs
    private Date submissionTs = new Date()
    private Date assignedTs = new Date()
    private Date resultTs = new Date()
	
	public ResponseTimeLogger(context){
		this.soapuiObj = new SoapuiObject(context)
	}
	
	/**********************
	 * output infomation
	 *
	 * TEMPLATE_PATH, CLIENT_TAT, JobId, TLJ_SUBMISSION_TS, TLJ_START_TS, TLJ_END_TS, \
	 * TLJ_TAT, TLJ_RESPONSE, MJ_MAX_RESPONSE, MJ_START_DELAY, MJ_END_DELAY, READ, MATCH, AMR
	 * MU_JOB_ID, MJ_START_TS, MJ_END_TS, MJ_TAT
	 * .
	 * .
	 *
	 * ********************/
	public void output(String jobId, long elapsedMs){
		appendClientElapseTime(jobId, elapsedMs)
		appendTljElpasedTime(jobId)
		appendMjMinMaxElpasedTime(jobId)
		appendAmr(jobId)
        logBuff.append(logBuffAppendix.toString())
        logBuff.append("\n")
		appendSjElpasedTime(jobId)
		flushLog()
	}
		
	private void flushLog(){
		String logDirPath = soapuiObj.getProjectProperty(OUTPUT_DIR)
		File logFile = new File("${logDirPath}/soapui_elapsed_time.txt")
		logFile.append(logBuff.toString())
		logFile.append("\n")
	}
		
	private void appendClientElapseTime(String jobId, long elapsedMs){
		SingletonMapQueue queue = SingletonMapQueue.getInstance()
		String templatePath = queue.dequeue("${jobId}-templatePath")
		logBuff.append("${templatePath}, ${elapsedMs}, ")

        this.clientStartTs = queue.dequeue(jobId)
        this.clientEndTs = queue.dequeue("${jobId}-end")
        logBuffAppendix.append("${clientStartTs.getTime()}, ${clientEndTs.getTime()}, ")
	}
		
	private void appendTljElpasedTime(String jobId) {
		def jdbcTemplate = new JdbcTemplateFactory(soapuiObj.getContext()).create()
		String sql = """
			select
				submission_ts,
				assigned_ts,
				result_ts
			from
				job_queue
			where
				job_id = ${jobId}
			"""
		List<Map<String, Object>> recs = jdbcTemplate.queryForList(sql)
        def rec = recs[0]
        submissionTs.setTime(rec.get("submission_ts") as long)
        assignedTs.setTime(rec.get("assigned_ts") as long)
        resultTs.setTime(rec.get("result_ts") as long)
        def submissionTsStr = submissionTs.format("yyyy/MM/dd HH:mm:ss.SSS")
        def assignedTsStr = assignedTs.format("yyyy/MM/dd HH:mm:ss.SSS")
        def resultTsStr = resultTs.format("yyyy/MM/dd HH:mm:ss.SSS")
        def tat = resultTs.getTime() - submissionTs.getTime()
        def response = resultTs.getTime() - assignedTs.getTime()
        logBuff.append("${jobId}, ${submissionTsStr}, ${assignedTsStr}, ${resultTsStr}, ${tat}, ${response}, ")
        logBuffAppendix.append("${submissionTs.getTime()}, ${assignedTs.getTime()}, ${resultTs.getTime()}, ")
	}
		
	private void appendMjMinMaxElpasedTime(String jobId) {
		def jdbcTemplate = new JdbcTemplateFactory(soapuiObj.getContext()).create()
		def sql = """
                select 
                    min(cj.assigned_ts) as min_assigned_ts,
                    max(cj.assigned_ts) as max_assigned_ts,
                    min(cj.result_ts) as min_result_ts,
                    max(cj.result_ts) as max_result_ts
                from
                    job_queue jq,
                    fusion_jobs fj,
                    container_jobs cj
                where
                    jq.job_id = fj.job_id and
                    fj.fusion_job_id = cj.fusion_job_id and
                    jq.job_id = $jobId
			"""
		List<Map<String, Object>> recs = jdbcTemplate.queryForList(sql)
		for(rec in recs){
            def minAssignedTs = new Date()
            def maxAssignedTs = new Date()
            def minResultTs = new Date()
            def maxResultTs = new Date()
            minAssignedTs.setTime(rec.get("min_assigned_ts") as long)
            maxAssignedTs.setTime(rec.get("max_assigned_ts") as long)
            minResultTs.setTime(rec.get("min_result_ts") as long)
            maxResultTs.setTime(rec.get("max_result_ts") as long)

            def maxTat = maxResultTs.getTime() - minAssignedTs.getTime()
            def startDelay = maxAssignedTs.getTime() - minAssignedTs.getTime()
            def endDelay = maxResultTs.getTime() - minResultTs.getTime()
            logBuff.append("${maxTat}, ${startDelay}, ${endDelay}, ")
            logBuffAppendix.append("${minAssignedTs.getTime()}, ${maxAssignedTs.getTime()}, ${minResultTs.getTime()}, ${maxResultTs.getTime()}, ")
            logBuffAppendix.append("${submissionTs.getTime() - clientStartTs.getTime()}, ")
            logBuffAppendix.append("${maxAssignedTs.getTime() - submissionTs.getTime()}, ")
            logBuffAppendix.append("${maxAssignedTs.getTime() - assignedTs.getTime()}, ")
            logBuffAppendix.append("${resultTs.getTime() - maxResultTs.getTime()}, ")
            logBuffAppendix.append("${clientEndTs.getTime() - resultTs.getTime()}, ")
		}
	}
		
	private void appendAmr(String jobId) {
		def sqlExecutor = getSqlExecutorInstance()
        def sql = "SELECT result from job_queue where job_id = $jobId"
        def recs = sqlExecutor.getSqlResult(sql)
        for(rec in recs){
            PBInquiryJobResult res = PBInquiryJobResult.parseFrom(rec[0].getBinaryStream())
            PBInquiryResultStatisticsAMR amr = res.getStatistics().getAmr()
            long readCnt = amr.getReadCount()
            long matchCnt = amr.getMatchCount()
            double amrPercent = (double)(matchCnt / readCnt) * 100
            logBuff.append("$readCnt, $matchCnt, $amrPercent, ")

        }
	}
		
	private void appendSjElpasedTime(String jobId) {
		def jdbcTemplate = new JdbcTemplateFactory(soapuiObj.getContext()).create()
		def sql = """
                select 
                    cj.container_job_id,
                    cj.assigned_ts as assigned_ts,
                    cj.result_ts as result_ts
                from
                    job_queue jq,
                    fusion_jobs fj,
                    container_jobs cj
                where
                    jq.job_id = fj.job_id and
                    fj.fusion_job_id = cj.fusion_job_id and
                    jq.job_id = $jobId
                order by 
                    cj.container_job_id
			"""
		List<Map<String, Object>> recs = jdbcTemplate.queryForList(sql)
		for(rec in recs){
            def cjId = rec.get("container_job_id")
            assignedTs.setTime(rec.get("assigned_ts") as long)
            resultTs.setTime(rec.get("result_ts") as long)
            def assignedTsStr = assignedTs.format("yyyy/MM/dd HH:mm:ss.SSS")
            def resultTsStr = resultTs.format("yyyy/MM/dd HH:mm:ss.SSS")
            def tat = resultTs.getTime() - assignedTs.getTime()
            logBuff.append("${cjId}, ${assignedTsStr}, ${resultTsStr}, ${tat}\n")   
		}
	}
		
	private getSqlExecutorInstance() {
		String dbIp = soapuiObj.getProjectProperty(DB_IP)
		String dbPort = soapuiObj.getProjectProperty(DB_PORT)
		String dbSid = soapuiObj.getProjectProperty(DB_SID)
		String dbUser = soapuiObj.getProjectProperty(DB_USER)
		String dbPass = soapuiObj.getProjectProperty(DB_PASS)
		return new SqlExecutorFactory().create(dbIp, dbPort, dbSid, dbUser, dbPass)
	}
}
