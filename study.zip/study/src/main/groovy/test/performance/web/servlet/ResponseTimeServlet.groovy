package test.performance.web.servlet

import common.queue.SingletonMapQueue
import common.util.time.TimeManager;

import javax.servlet.*
import javax.servlet.http.*
import test.degrade.util.SoapuiObject
import test.performance.logger.ResponseTimeLogger;


class ResponseTimeServlet extends HttpServlet {
	private static SoapuiObject soapuiObj
	private static final String SLASH = "/"
	private static int acceptCallbackCnt = 0
	
	public ResponseTimeServlet(){}
	
	public ResponseTimeServlet(context){
		this.soapuiObj = new SoapuiObject(context)
	}

	def void doPost(HttpServletRequest req, HttpServletResponse res) {
try{
		Date endDate = new Date()
		res.getWriter().close()
		String jobId = parseJobId(req.getRequestURI())
		long elapsedMs = calcElapsedMs(jobId, endDate)
		outputLog(jobId, elapsedMs)
		acceptCallbackCnt++
}catch (Exception e){
    println e.toString()
    println e.getStackTrace().toString().replaceAll(",", "\n")
}
	}
	
	synchronized private void outputLog(String jobId, long elapsedMs){
		ResponseTimeLogger logger = new ResponseTimeLogger(soapuiObj.getContext())
		logger.output(jobId, elapsedMs)
	}
	
	public void waitCallback(int waitCnt){
		while (acceptCallbackCnt < waitCnt) {
			sleep 1000
		}
		acceptCallbackCnt = 0
	}

	private long calcElapsedMs(String jobId, Date endDate) {
		SingletonMapQueue queue = SingletonMapQueue.getInstance()
		Date startDate = queue.peek(jobId)
        queue.enqueue("${jobId}-end", endDate)
		TimeManager timeMgr = new TimeManager()
		long elapsedMs = timeMgr.calcDiffMSec(startDate, endDate)
		return elapsedMs
	}

	private String parseJobId(String requestUri){
		int index = requestUri.lastIndexOf(SLASH)
		return requestUri.substring(index+1)
	}

	def void doGet(HttpServletRequest req, HttpServletResponse res) {
		doPost(req, res)
	}
}
