package test.performance.web.servlet

import java.util.concurrent.atomic.AtomicInteger;

import common.queue.SingletonMapQueue
import test.common.runner.TestCaseExecutor
import test.degrade.util.SoapuiObject;
import test.performance.queue.StopWatcher

import javax.naming.LimitExceededException;
import javax.servlet.*
import javax.servlet.http.*


class KeepJobIdTemplatePathServlet extends HttpServlet {
	private static final String SLASH = "/"
	private static final String SEARCH = "search"
	private static AtomicInteger queuedCnt = new AtomicInteger(0)
	private static AtomicInteger acceptCnt = new AtomicInteger(0)
	private static boolean is1by1
	private static int limitJobCnt
    private log
	private SoapuiObject soapuiObj
	
	public KeepJobIdTemplatePathServlet(){}

	public KeepJobIdTemplatePathServlet(log){
        this.log = log
    }
	
	public KeepJobIdTemplatePathServlet(def context, boolean is1by1, int limitJobCnt, def log){
		this.soapuiObj = new SoapuiObject(context)
		this.is1by1 = is1by1
		this.limitJobCnt = limitJobCnt
        this.log = log
    }
	
	def void doPost(HttpServletRequest req, HttpServletResponse res) {
		Date endDate = new Date()
		res.getWriter().close()
		String jobId = parseJobId(req.getRequestURI())
		checkPoint(jobId, endDate)
		queuedCnt.incrementAndGet()
		if(!is1by1 && acceptCnt.incrementAndGet() <= limitJobCnt){
			synchronized (acceptCnt) {
				callSearchTestCase()
			}
		}
	}
	
	private void callSearchTestCase(){
		def timTestCase = soapuiObj.getTestCaseInSameSuite(SEARCH)
		TestCaseExecutor testCaseExecutor = new TestCaseExecutor(timTestCase)
		testCaseExecutor.runTestCase()
	}
	
	private void checkPoint(String jobId, Date date) {
		SingletonMapQueue queue = SingletonMapQueue.getInstance()
		String templatePath = null
        while (templatePath == null){
		    templatePath = queue.peek(jobId)
            if(templatePath == null){
                log.info("Couldn't get search template path of jobId=${jobId} from queue. Maybe callback was returned too fast. retry again after 1sec.")
                sleep 1000
            }
        }
        log.info "Accepted callback. jobId=$jobId dataPath=$templatePath"
        def sw = StopWatcher.getInstance()
        sw.checkPoint("${templatePath}:end", date)
	}

	private String parseJobId(String requestUri){
		int index = requestUri.lastIndexOf(SLASH)
		return requestUri.substring(index+1)
	}

	def void doGet(HttpServletRequest req, HttpServletResponse res) {
		doPost(req, res)
	}
	
	public static int getQueuedCnt() {
		return queuedCnt.get()
	}

	public static void decreaseQueuedCnt() {
		queuedCnt.decrementAndGet()
	}
}
