package test.performance.helper

class PerfLIXHelper{

	PerfLIXHelper(context){}

	def getFingerSet(fingerPattern){
		if (fingerPattern == 0){
			return getRightFinger()
		}else if (fingerPattern == 1){
			return getLeftFinger()
		}else if (fingerPattern == 2){
			int flag = getRandomNum(2)
			if ( flag == 0 ){
				return getRightFinger()
			}else if ( flag == 1){
				return getLeftFinger()
			}
		}
	}
	
	def getRightFinger(){
		return "01234"
	}

	def getLeftFinger(){
		return "56789"
	}
		
	
	def getRandomNum(int num){
		def rnd = new Random()
		return rnd.nextInt(num)
	}

}
