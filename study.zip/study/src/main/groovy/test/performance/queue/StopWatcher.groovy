package test.performance.queue

import common.util.time.*

public class StopWatcher {

	private static StopWatcher instance = new StopWatcher()
	private Map<String, Date> dateMap

	private StopWatcher() {
		this.dateMap = new HashMap<String, Date>()
	}

	public static synchronized StopWatcher getInstance() {
		return instance
	}

	public synchronized void checkPoint(String key, Date date) {
		dateMap.put(key, date)
	}

	public void checkPoint(String key) {
		dateMap.put(key, new Date())
	}

	public Date getPoint(String key) {
		return dateMap.get(key)
	}

	public calcElapsedTime(String startKey, String endKey){
		Date start = getPoint(startKey)
		Date end = getPoint(endKey)
		return new TimeManager().calcDiffMSec(start, end)
	}
}

