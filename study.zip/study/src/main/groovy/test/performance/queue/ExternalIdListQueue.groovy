package test.performance.queue

public class ExternalIdListQueue {

	private static ExternalIdListQueue instance
	private Map<Integer, Map<String, String>> binIdAndExternalIdListMap

	private ExternalIdListQueue() {
		this.binIdAndExternalIdListMap = new HashMap<Integer, Map<String, String>>()
	}

	public static synchronized ExternalIdListQueue getInstance() {
		if (instance == null) {
			instance = new ExternalIdListQueue()
		}
		return instance
	}

	public void enqueue(Integer id, Map<String, String> externalIdList) {
		binIdAndExternalIdListMap.put(id, externalIdList)
	}

	public Map<String, String> dequeue(Integer id) {
		return binIdAndExternalIdListMap.get(id)
	}
}

