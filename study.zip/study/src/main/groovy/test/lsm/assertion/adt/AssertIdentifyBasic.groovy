package test.lsm.assertion.adt

import com.nec.everest.proto.protobuf.BusinessMessage.E_REQUESET_TYPE;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBRequest;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBResponse;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBResponseAttribute;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBDataBlock;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBProcessMetrics;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBProcessInfo;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBDataGroup;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBDataElement;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBCandidateList;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBCandidate;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBScore;

public class AssertIdentifyBasic {
	def identifyResult
	def testfile
	long batchJobId
	int topLevelJobNum

	public AssertIdentifyBasic(identifyResult, batchJobId, topLevelJobNum) {
            //    this.testfile = new File("/home/m-uno/adt-b4-testfile.log");
		this.identifyResult = identifyResult;
		this.batchJobId = batchJobId;
		this.topLevelJobNum = topLevelJobNum;
	}
	public void assertIdentifyBasic() {
		//BatchJobID
		assertBatchJobId(identifyResult, batchJobId);
	//	testfile.append(" BASIC: assertBatchJobId completes!\n");
		//Type
		assertBatchType(identifyResult);
	//	testfile.append(" BASIC: assertBatchType completes!\n");
		//JobCount
		assertJobCount(identifyResult, topLevelJobNum);
	//	testfile.append(" BASIC: assertJobCount completes!\n");
		//BusinessMessage
		for(int i = 0; i < topLevelJobNum; i++) {
			CPBBusinessMessage businessMessage = 
				CPBBusinessMessage.parseFrom(identifyResult.getBusinessMessage(i));
			assertBusinessMessage(businessMessage, i);
		}
	//	testfile.append(" BASIC: assertBusinessMessage completes!\n");
	}
	private void assertBatchJobId(identifyResult, batchJobId) {
		if(identifyResult.getBatchJobId() != batchJobId) {
			assert false, "batchJobId is $batchJobId";
		}
	}
	private void assertBatchType(identifyResult) {
		String batchType = identifyResult.getType().name();
		if(batchType != "IDENTIFY") {
			assert false, "batchType is not IDENTIFY. ($batchType)";
		}
	}
	private void assertJobCount(identifyResult, topLevelJobNum) {
		int jobCount = identifyResult.getBusinessMessageCount();
		if(jobCount != topLevelJobNum) {
			assert false, "the number of Identify job is wrong, expected $topLevelJobNum jobs";
		}
	}
//BusinessMessage	
	private void assertBusinessMessage(businessMessage, messageIndex) {
		// Request
		CPBRequest request = businessMessage.getRequest();
		assertRequest(request, messageIndex);
	//	testfile.append("  BASIC: assertRequest completes!\n");
		// Response
		CPBResponse response = businessMessage.getResponse();
		assertResponse(response, messageIndex);
	//	testfile.append("  BASIC: assertResponse completes!\n");
		// DataBlock
		CPBDataBlock dataBlock = businessMessage.getDataBlock();
		assertDataBlock(dataBlock, messageIndex);
	//	testfile.append("  BASIC: assertDataBlock completes!\n");
	}

  //Request
	private void assertRequest(request, messageIndex) {
		// RequestId
		assertRequestId(request, messageIndex);
		// RequestType
		assertRequestType(request);
	}
	private void assertRequestId(request, messageIndex) {
		if(!isErrorCase(identifyResult, messageIndex)) {
			String requestId = request.getRequestId();
			int requestIdSize = requestId.length();
			if(requestIdSize != 36) {
				assert false, "requestId must be 36 bytes ($requestIdSize)";
			}
		}
	}
	private void assertRequestType(request) {
		if(request.getRequestType() != E_REQUESET_TYPE.IDENTIFY_REFID_DEFAULT && 
			request.getRequestType() != E_REQUESET_TYPE.IDENTIFY_REFURL_DEFAULT) {
			assert false, "requestType is not IDENTIFY_REFID_DEFAULT ($requestType)";
		}
	}
  //Response
	private void assertResponse(response, messageIndex) {
		// Status
		assertStatus(response, messageIndex);	
	//	testfile.append("   BASIC: assertStatus completes!\n");
		// Resendable
		assertResendable(response, messageIndex);
	//	testfile.append("   BASIC: assertResedable completes!\n");
		// ErrorMessage
		//assertErrorMessage(response);
		// ResponseAttributes
		assertResponseAttribute(response);
	//	testfile.append("   BASIC: assertResponseAttribute completes!\n");
	}
	private void assertStatus(response, messageIndex) {
		String status = response.getStatus();
		if(!isErrorCase(identifyResult, messageIndex)) {
	//		testfile.append("  This is not error case, expecting status is 0\n");
			if(status != "0") {
				assert false, "jobStatus is not SUCCESS. ($status)";
			}
		}
	}
	private void assertResendable(response, messageIndex) {
		String resendable = response.getResendable();
		if(isErrorCase(identifyResult, messageIndex)) {
			if(resendable != "Y" && resendable != "N") {
				assert false, "resendable must be either Y or N, but was $resendable";
			}
		}
	}
	private void assertErrorMessage(response) {
		String errMessage = response.getErrorMessage();
		if(errMessage != "" || !(errMessage.isEmpty()) || errMessage != " ") {
			assert false, "job is succeeded, but an error message. ($errMessage)";
		}
	}
	private void assertResponseAttribute(response) {
		for(int i = 0; i < response.getResponseAttributesCount(); i++) {
			CPBResponseAttribute attribute = response.getResponseAttributes(i);
			// AttributeName
			assertAttributeName(attribute);
			// AttributeValue
			assertAttributeValue(attribute);
		}
	}
	private void assertAttributeName(attribute) {
		String attributeName = attribute.getAttributeName();
		if(attributeName  != "createdTimestamp") {
			assert false, "attributeName must be createTimestamp, but $attributeName";
		}
	}
	private void assertAttributeValue(attribute) {
		String attributeValue = attribute.getAttributeValue();
		if(attributeValue.length() < 13 ) {
			assert false, "attributeValue is too small ($attributeValue)";
		}
	}
  //DataBlock
	private void assertDataBlock(dataBlock, messageIndex) {
		// Candidates
		CPBCandidateList candidateList = dataBlock.getCandidateList();
		assertMore(candidateList);
		for(int i = 0; i < candidateList.getCandidatesCount(); i++) {
			CPBCandidate candidate = candidateList.getCandidates(i);
			assertCandidate(candidate, messageIndex);
		}
		// ProcessMetrics
		CPBProcessMetrics processMetrics = dataBlock.getProcessMetric();
		for(int i = 0; i < processMetrics.getProcessMetricCount(); i++) {
			CPBProcessInfo processInfo = processMetrics.getProcessMetric(i);
			assertProcessName(processInfo);
			assertStartTime(processInfo);
			assertEndTime(processInfo);
		}
	}
	private void assertMore(candidateList) {
		String more = candidateList.getMore().toString();
		if(more != "true" && more != "false") {
			assert false, "more must be true or false ($more)";
		}
	}
	private void assertCandidate(candidate, messageIndex) {
		assertEnrollmentId(candidate, messageIndex);
		for(int i = 0; i < candidate.getScoreCount(); i++) {
			CPBScore score = candidate.getScore(i);
			assertModalityType(score);
			assertModalitySubType(score);
			assertScore(score);
		}
	}
	private void assertEnrollmentId(candidate, messageIndex) {
		String enrollmentId = candidate.getEnrollmentId();
		if(!isErrorCase(identifyResult, messageIndex)) {
			if(enrollmentId.length() != 36) {
				assert false, "enrollment must be 36 bytes";
			}
		}
	}
	private void assertModalityType(score){
		String modalityType = score.getModalityType().name();
		if(modalityType != "FINGER" && modalityType != "IRIS" && modalityType != "FACE") {
			assert false, "modalityType must be either FINGER or IRIS or FACE, but $modalityType";
		}
	}
	private void assertModalitySubType(score) {
		String modalitySubType = score.getModalitySubType();
		if(score.getModalityType().name() != "FACE") {
			if(modalitySubType == null) {
				assert false, "modalitySubType is null";
			}
		}
	}
	private void assertScore(score) {
		int scoreValue = score.getValue() as int;
		if(scoreValue < -1 || scoreValue > 9999 ) {
			assert false, "score must be between -1 and 9999, but ($scoreValue)";
		}
	}
	private void assertProcessName(processInfo) {
		String processName = processInfo.getProcessName();
                if(processName != "match") {
                        assert false, "processName must be MATCH, but $processName";
                }
	}
	private void assertStartTime(processInfo) {
		String startTime = processInfo.getStartTime();
                if(startTime.length() < 13 ) {
                        assert false, "startTime is too small ($startTime)";
                }
	}
	private void assertEndTime(processInfo) {
		String endTime = processInfo.getEndTime();
                if(endTime.length() < 13 ) {
                        assert false, "endTime is too small ($endTime)";
                }

	}
	private boolean isErrorCase(identifyResult, messageIndex) {
		CPBBusinessMessage businessMessage =
                                CPBBusinessMessage.parseFrom(identifyResult.getBusinessMessage(messageIndex));
		CPBResponse response = businessMessage.getResponse();
		String status = response.getStatus();
		if(status.length() > 2) {
			return true;
		}
		return false;
	}
}
