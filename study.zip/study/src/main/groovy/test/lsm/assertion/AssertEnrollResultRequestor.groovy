package test.lsm.assertion

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.nec.lsm.accenture.constants.ModalityDataGroupName;
import jp.co.nec.lsm.proto.accenture.BusinessMessageProto.CPBBusinessMessage;
import jp.co.nec.lsm.proto.accenture.BusinessMessageProto.CPBDataBlock;
import jp.co.nec.lsm.proto.accenture.BusinessMessageProto.CPBModalityDataElement;
import jp.co.nec.lsm.proto.accenture.BusinessMessageProto.CPBModalityDataGroup;
import jp.co.nec.lsm.proto.accenture.BusinessMessageProto.CPBResponse;
import jp.co.nec.lsm.proto.accenture.BusinessMessageProto.CPBResponseAttribute;
import jp.co.nec.lsm.proto.accenture.BusinessMessageProto.E_MODALITY_TYPE;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tm.protocolbuffer.enroll.EnrollResultRequestProto.EnrollResultRequest;

import com.google.protobuf.ByteString;

public class AssertEnrollResultRequestor {
	public static final String SUCCESS = "0";

	public void assertResultRequest(EnrollResultRequest resultRequest){
		assertBatchJobId(resultRequest);
		assertBatchType(resultRequest);
		assertBusinessMessageList(resultRequest);
	}

	private void assertBusinessMessageList(EnrollResultRequest resultRequest) {
		List<ByteString> businessMessageByteStringList = resultRequest.getBusinessMessageList();
		for(ByteString businessMessageByteString : businessMessageByteStringList){
			try {
				CPBBusinessMessage businessMessage = CPBBusinessMessage.parseFrom(businessMessageByteString);
				assertBusinessMessage(businessMessage);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void assertBusinessMessage(CPBBusinessMessage businessMessage) {
		assertResponse(businessMessage);
		assertDataBlock(businessMessage);
	}

	private void assertDataBlock(CPBBusinessMessage businessMessage) {
		CPBDataBlock dataBlock = businessMessage.getDataBlock();
		assertModalityDataGroupList(dataBlock);
	}

	private void assertModalityDataGroupList(CPBDataBlock dataBlock) {
		List<CPBModalityDataGroup> modalityDataGroupList = dataBlock.getModalityDataGroupList();
		Map<String, List<CPBModalityDataElement>> modalityDataGroupMapList = 
			createModalityDataGroupMapList(modalityDataGroupList);
		for(ModalityDataGroupName modalityGroupName : ModalityDataGroupName.values()){
			List<CPBModalityDataElement> modalityDataElementList = modalityDataGroupMapList.get(modalityGroupName.getName());
			assertDataElementList(modalityDataElementList);
		}
	}

	private void assertDataElementList(
			List<CPBModalityDataElement> modalityDataElementList) {
		for(CPBModalityDataElement modalityElement : modalityDataElementList){
			assertmodalityElement(modalityElement);
			assertAttempt(modalityElement);
		}
	}

	private void assertAttempt(CPBModalityDataElement modalityElement) {
		int attempt = Integer.parseInt(modalityElement.getAttempt());
		assert attempt > -2;
	}

	//TODO
	private void assertmodalityElement(CPBModalityDataElement modalityElement) {
		E_MODALITY_TYPE modalitype = modalityElement.getModalityType();
		String modalitySubType = modalityElement.getModalitySubType();
		int score = Integer.parseInt(modalityElement.getValue());
		assert score > -2;
	}

	private Map<String, List<CPBModalityDataElement>> createModalityDataGroupMapList(
			List<CPBModalityDataGroup> modalityDataGroupList) {
		Map<String, List<CPBModalityDataElement>> modalityDataGroupMapList = 
			new HashMap<String, List<CPBModalityDataElement>>();
		for(CPBModalityDataGroup modalityDataGroup : modalityDataGroupList){
			String groupName = modalityDataGroup.getGroupName();
			List<CPBModalityDataElement> modalityDataElementList = modalityDataGroup.getModalityDataElementList();
			modalityDataGroupMapList.put(groupName, modalityDataElementList);
		}
		return modalityDataGroupMapList;
	}

	private void assertResponse(CPBBusinessMessage businessMessage) {
		CPBResponse response = businessMessage.getResponse();
		assertStatus(response);
		assertResponseAttributeList(response);
	}

	private void assertResponseAttributeList(CPBResponse response) {
		List<CPBResponseAttribute> responseAtributeList = response.getResponseAttributesList();
		Map<String, String> responseAttrbuteMap = createMapResponseAttributeList(responseAtributeList);
	}

	private Map<String, String> createMapResponseAttributeList(
			List<CPBResponseAttribute> responseAtributeList) {
		Map<String, String> responseAttrbuteMap = new HashMap<String, String>()			;
		for(CPBResponseAttribute responseAttrribute : responseAtributeList){
			String key = responseAttrribute.getAttributeName();
			String value = responseAttrribute.getAttributeValue();
			responseAttrbuteMap.put(key, value);
		}
		return responseAttrbuteMap;
	}

	private void assertErrMessage(CPBResponse response) {
		String errMessage = response.getErrorMessage();
		if(errMessage != null || !(errMessage.isEmpty())){
			assert false, "JobStatus is not Success. but errMessage is empty";
		}
	}

	private void assertStatus(CPBResponse response) {
		String status = response.getStatus();
		if(status != SUCCESS){
			println "jobStatus is not Success. actual $status"
			assertErrMessage(response);
		}
	}

	private void assertBatchJobId(EnrollResultRequest resultRequest) {
		long batchJobId = resultRequest.getBatchJobId();
		if(batchJobId <= 0){
			assert false, "batchJobId is $batchJobId";
		}
	}

	private void assertBatchType(EnrollResultRequest resultRequest) {
		BatchType type = resultRequest.getType();
		if(type == null){
			assert false, "batchType is null";
		}

		if(type != BatchType.ENROLL){
			assert false, "batchType is not " + BatchType.ENROLL + ". actual $type";
		}
	}
}

