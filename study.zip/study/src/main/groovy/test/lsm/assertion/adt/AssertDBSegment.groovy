package test.lsm.assertion.adt


public class AssertDBSegment {

	public void assertDB(before_pb,after_pb,before_sg,after_sg,before_svd, after_svd,beforeReg_svd, afterReg_svd){

		assertReferenceId(after_pb)
		assertSegVersion(after_sg, before_sg)
		assertSegRecordCount(after_sg, before_sg)
		assertSegLength(after_sg, before_sg, before_pb)
		assertSvdSegId(after_svd, after_sg)
		assertSvdVersion(after_svd, after_sg)
		assertSvdBioIdStart(after_svd, before_pb)
		assertSvdBioIdEnd(after_svd)
		assertSvdRecordCount(after_svd)
		assertSvdChangeType(after_svd)
		assertSvdReferenceId(after_svd, before_pb)
		assertSvdRecordCountUpdate(afterReg_svd, beforeReg_svd)
		}


		private void assertReferenceId(after_pb){
			if(after_pb.refId != null){
				assert false, "referenceId is not Deleted!!";
			}
		}
		
		private void assertSegVersion(after_sg, before_sg){
			if(after_sg.ver != (before_sg.ver + 1)){
				assert false, "Version = $before_sg.ver + 1 actual $after_sg.ver";
			}
		}
		
		private void assertSegRecordCount(after_sg, before_sg){
			if(after_sg.recCount != before_sg.recCount - 1){
				assert false, "RecordCount = $before_sg.recCount - 1 . actual $after_sg.recCount";
			}
		}
		
		private void assertSegLength(after_sg, before_sg, before_pb){
			if(after_sg.binaryLenCompacted != before_sg.binaryLenCompacted - before_pb.biometricDataLen){
				assert false, "BinaryLength is not Correct";
			}
		}

		private void assertSvdSegId(after_svd, after_sg){		
			if(after_svd.segId != after_sg.segId){
				assert false, "segId"
			}
		}
		
		private void assertSvdVersion(after_svd, after_sg){
			if(after_svd.ver != after_sg.ver){
				assert false, "version"
			}
		}
		
		private void assertSvdBioIdStart(after_svd, before_pb){
			if(after_svd.bioIdStart != before_pb.bioId){
				assert false, "bioId"
			}
		}
		
		private void assertSvdBioIdEnd(after_svd){
			if(after_svd.bioIdEnd != null){
				assert false, "bioEnd"
			}
		}
		
		private void assertSvdRecordCount(after_svd){
			if(after_svd.recCount != 0){
				assert false, "recCount"
			}
		}
		
		private void assertSvdChangeType(after_svd){
			if(after_svd.changeType != "1"){
				assert false, "changeType"
			}
		}
		
		private void assertSvdReferenceId(after_svd, before_pb){
			if(after_svd.refId != before_pb.refId){
				assert false, "refId"
			}
		}

		private void assertSvdRecordCountUpdate(afterReg_svd, beforeReg_svd){
			if(afterReg_svd.recCount != beforeReg_svd.recCount - 1){
				assert false, "SVD recCount"
			}
		}

}	
