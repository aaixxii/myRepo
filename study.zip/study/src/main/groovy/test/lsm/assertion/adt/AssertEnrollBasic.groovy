package test.lsm.assertion.adt

import com.nec.everest.proto.protobuf.BusinessMessage.E_REQUESET_TYPE;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBRequest;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBResponse;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBResponseAttribute;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBDataBlock;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBProcessMetrics;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBProcessInfo;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBDataGroup;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBDataElement;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBModalityDataGroup
import com.nec.everest.proto.protobuf.BusinessMessage.CPBModalityDataElement

public class AssertEnrollBasic {
	def file
        def enrollResult
        long batchJobId
        int topLevelJobNum

        public AssertEnrollBasic(enrollResult, batchJobId, topLevelJobNum) {
                this.enrollResult = enrollResult;
                this.batchJobId = batchJobId;
                this.topLevelJobNum = topLevelJobNum;
//                this.file = new File("/home/m-uno/adt-b4-testfile.log");
        }

	public void assertEnrollBasic() {
		//BatchJobID
		assertBatchJobId(enrollResult, batchJobId);
		//Type
		assertBatchType(enrollResult);
		//JobCount
		assertJobCount(enrollResult, topLevelJobNum);
		//BusinessMessage
		for(int i = 0; i < topLevelJobNum; i++) {
			CPBBusinessMessage businessMessage = 
				CPBBusinessMessage.parseFrom(enrollResult.getBusinessMessage(i));
			assertBusinessMessage(businessMessage, i);
		}
	}

	private void assertBatchJobId(enrollResult, batchJobId) {
		if(enrollResult.getBatchJobId() != batchJobId) {
			assert false, "batchJobId is $batchJobId";
		}
	}
	private void assertBatchType(enrollResult) {
		String batchType = enrollResult.getType().name();
		if(batchType != "ENROLL") {
			assert false, "batchType is not ENROLL. ($batchType)";
		}
	}
	private void assertJobCount(enrollResult, topLevelJobNum) {
		int jobCount = enrollResult.getBusinessMessageCount();
		if(jobCount != topLevelJobNum) {
			assert false, "Enroll job is not = 1, expected $topLevelJobNum";
		}
	}
//BusinessMessage	
	private void assertBusinessMessage(businessMessage, messageIndex) {
		// Request
		CPBRequest request = businessMessage.getRequest();
		assertRequest(request, messageIndex);
		// Response
		CPBResponse response = businessMessage.getResponse();
		assertResponse(response, messageIndex);
		// DataBlock
		CPBDataBlock dataBlock = businessMessage.getDataBlock();
		assertDataBlock(dataBlock, messageIndex);
	}

  //Request
	private void assertRequest(request, messageIndex) {
		// RequestId
		assertRequestId(request, messageIndex);
		// RequestType
		assertRequestType(request);
		// EnrollmentId
		assertEnrollmentId(request, messageIndex);
	}
	private void assertRequestId(request, messageIndex) {
		String requestId = request.getRequestId();
		int requestIdSize = requestId.length();
		if(requestIdSize != 36) {
			assert false, "requestId must be 36 bytes ($requestIdSize)";
		}
	}
	private void assertRequestType(request) {
		if(request.getRequestType() != E_REQUESET_TYPE.INSERT) {
			assert false, "requestType is not INSERT ($requestType)";
		}
	}
	private void assertEnrollmentId(request, messageIndex) {
		String enrollmentId = request.getEnrollmentId()
//		file.append("EnrollmentID: $enrollmentId\n");
		if(!isErrorCase(enrollResult, messageIndex)) {
			if(enrollmentId.length() != 36) {
				assert false, "enrollmentId must be 36 bytes";
			}
		}
	}
  //Response
	private void assertResponse(response, messageIndex) {
		// Status
		assertStatus(response, messageIndex);	
		// Resendable
		assertResendable(response, messageIndex);
		// ErrorMessage
		assertErrorMessage(response, messageIndex);
		// ResponseAttributes
		assertResponseAttribute(response);
	}
	private void assertStatus(response, messageIndex) {
		if(!isErrorCase(enrollResult, messageIndex)) {
			String status = response.getStatus();
			if(status != "0") {
				assert false, "jobStatus is not SUCCESS. ($status)";
			}
		}
	}
	private void assertResendable(response, messageIndex) {
		if(isErrorCase(enrollResult, messageIndex)) {
			String resendable = response.getResendable();
			if(resendable != "N" && resendable != "Y") {
				assert false, "resendable must be either Y or N. but was $resendable";
			}
		}
	}
	private void assertErrorMessage(response, messageIndex) {
		String errMessage = response.getErrorMessage();
		if(!isErrorCase(enrollResult, messageIndex)) {
			if(errMessage.length() > 1) {
				assert false, "job is suceeded, error message should be null. ($errMessage)";
			}
		}
	}
	private void assertResponseAttribute(response) {
		for(int i = 0; i < response.getResponseAttributesCount(); i++) {
			CPBResponseAttribute attribute = response.getResponseAttributes(i);
			// AttributeName
			assertAttributeName(attribute);
			// AttributeValue
			assertAttributeValue(attribute);
		}
	}
	private void assertAttributeName(attribute) {
		String attributeName = attribute.getAttributeName();
		if(attributeName  != "createdTimestamp") {
			assert false, "attributeName must be createTimestamp, but $attributeName";
		}
	}
	private void assertAttributeValue(attribute) {
		String attributeValue = attribute.getAttributeValue();
		if(attributeValue.length() < 13 ) {
			assert false, "attributeValue is too small ($attributeValue)";
		}
	}
  //DataBlock
	private void assertDataBlock(dataBlock, messageIndex) {
		// ProcessMetric
		CPBProcessMetrics processMetrics = dataBlock.getProcessMetric();
		assertProcessMetric(processMetrics, messageIndex);
		// DataGroup
		for(int i = 0; i < dataBlock.getDataGroupCount(); i++) {
			CPBDataGroup dataGroup = dataBlock.getDataGroup(i);
			assertDataGroupName(dataGroup);
			assertDataElement(dataGroup);
		}
		// ModalityDataGroup
		for(int i = 0; i < dataBlock.getModalityDataGroupCount(); i++) {
			CPBModalityDataGroup modDataGroup = dataBlock.getModalityDataGroup(i);
			assertModalityGroupName(modDataGroup);
			assertModalityElement(modDataGroup);
		}
	}
	private void assertProcessMetric(processMetrics, messageIndex) {
		for(int i = 0; i < processMetrics.getProcessMetricCount(); i++) {
			CPBProcessInfo processInfo = processMetrics.getProcessMetric(i);
			assertProcessName(processInfo, messageIndex);
			assertProcessStart(processInfo, messageIndex);
			assertProcessEnd(processInfo, messageIndex);
		}
	}
	private void assertProcessName(processInfo, messageIndex){
		String processName = processInfo.getProcessName();
	//	file.append("${messageIndex}th job's ${processName}\n");
		if(processName != "segmentation" && processName != "templateGeneration") {
			assert false, "processName must be either segmentation or templateGenration, but $processName";
		}
	}
	private void assertProcessStart(processInfo, messageIndex) {
		String processName = processInfo.getProcessName();
		String startTime = processInfo.getStartTime();
	//	file.append("${messageIndex}th job's ${processName} start time: $startTime\n");
		if(startTime.length() < 13 ) {
			assert false, "startTime is too small ($startTime)";
		}
	}
	private void assertProcessEnd(processInfo, messageIndex) {
		String processName = processInfo.getProcessName();
		String endTime = processInfo.getEndTime();
	//	file.append("${messageIndex}th job's ${processName} end time: $endTime\n");
		if(endTime.length() < 13 ) {
			assert false, "endTime is too small ($endTime)";
		}
	}

	private void assertDataGroupName(dataGroup) {
		String groupName = dataGroup.getGroupName();
		if(groupName != "rightIrisVector" && groupName != "leftIrisVector" && groupName != "templateAlgorithm" && 
                   groupName != "FTE" && groupName != "templateAlgorithm" && groupName != "fingerImageEnlargement" && groupName != "impostorPossibility") {
			assert false, "dataGroupName is wrong, but $groupName";
		}
	}
	private void assertDataElement(dataGroup) {
		for(int i = 0; i < dataGroup.getDataElementCount(); i++) {
			CPBDataElement element = dataGroup.getDataElement(i);
			assertElementName(element);
			assertElementValue(element);
		}
	}
	private void assertElementName(element) {
		String elementName = element.getElementName();
		if(elementName == null) {
			assert false, "elementName is null";
		}
	}
	private void assertElementValue(element) {
		String elementValue = element.getElementValue();
		if(elementValue == null) {
			assert false, "elementValue is null";
		}
	}
	private void assertModalityGroupName(modDataGroup) {
		String modGroupName = modDataGroup.getGroupName();
		if(modGroupName != "qualityScore" && modGroupName != "attempts") {
			assert false, "modalityGroupName must be qualityScore, but $modGroupName";
		}
	}
	private void assertModalityElement(modDataGroup) {
		for(int i = 0; i < modDataGroup.getModalityDataElementCount(); i++) {
			CPBModalityDataElement modDataElement = modDataGroup.getModalityDataElement(i);
			assertModalityType(modDataElement);
			assertModalitySubType(modDataElement);
			assertModalityValue(modDataElement);
			assertModalityAttempt(modDataElement);
		}
	}
	private void assertModalityType(modDataElement) {
		String modalityType = modDataElement.getModalityType().name();
		if(modalityType != "FINGER" && modalityType != "IRIS" && modalityType != "FACE") {
			assert false, "modalityType must be either FINGER or IRIS or FACE, but  $modalityType";
		}
	}
	private void assertModalitySubType(modDataElement) {
		String modalitySubType = modDataElement.getModalitySubType();
		if(modDataElement.getModalityType().name() != "FACE") {
			if(modalitySubType == null) {
				assert false, "modalitySubType is null";
			}
		}
	}
	private void assertModalityValue(modDataElement) {
		if(modDataElement.getValue() == null) {
			assert false, "modalityValud is null";
		}
	}
	private void assertModalityAttempt(modDataElement) {
		if(modDataElement.getAttempt() == null) {
			assert false, "modalityAttempt is null";
		}
	}
	private boolean isErrorCase(enrollResult, messageIndex) {
                CPBBusinessMessage businessMessage =
                                CPBBusinessMessage.parseFrom(enrollResult.getBusinessMessage(messageIndex));
                CPBResponse response = businessMessage.getResponse();
                String status = response.getStatus();
                if(status != "0") return true;
                return false;
        }
}
