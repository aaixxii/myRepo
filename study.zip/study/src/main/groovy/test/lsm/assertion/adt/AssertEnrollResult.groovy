package test.lsm.assertion.adt

import com.nec.everest.proto.protobuf.BusinessMessage.E_REQUESET_TYPE;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBRequest;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBResponse;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBResponseAttribute;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBDataBlock;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBProcessMetrics;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBProcessInfo;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBDataGroup;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBDataElement;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBModalityDataGroup
import com.nec.everest.proto.protobuf.BusinessMessage.CPBModalityDataElement

public class AssertEnrollResult {
	def file
	def enrollResult
	long batchJobId
	int batchJobTime
	int jobNum
	boolean checkErr

	public AssertEnrollResult(enrollResult, batchJobId, batchJobTime, jobNum, checkErr, file) {
		this.enrollResult = enrollResult;
		this.batchJobId = batchJobId;
		this.batchJobTime = batchJobTime;
		this.jobNum = jobNum;
		this.checkErr = checkErr;
		this.file = new File("$file");
	}
	public void assertEnrollResult() {
		def basicAssertion = new AssertEnrollBasic(enrollResult, batchJobId, jobNum);
		basicAssertion.assertEnrollBasic();
		if(checkErr) {
			assertErrorCase();
		}
		file.append("  TRUE[ENROLL] ($batchJobId)\n");
	}
	private void assertErrorCase() {
		CPBBusinessMessage businessMessage = 
				CPBBusinessMessage.parseFrom(enrollResult.getBusinessMessage(19));
		CPBResponse response = businessMessage.getResponse();
		if(batchJobTime == "3") {
			assertNoImage(response);
		}
		if(batchJobTime == "6") {
			assertDecompressFailure(response);
		}
		if(batchJobTime == "8") {
			assertTemplGenFailure(response);
		}
		if(batchJobTime == "11") {
			assertDuplication(response);
		}
		if(batchJobTime == "14") {
			assertOverLength(response);
		}
	}
	private void assertNoImage(response) {
		String status = "834011208";
		String errMsg = " Read error loading TAR file. ( No exists image files.).";
		if(response.getStatus() != status) {
			file.append("@@FLASE[$batchJobId]: Wrong status is found in RESPONSE, $status was expected.");
			assert false, "Wrong status is found in RESPONSE, $status was expected.";
		}
		if(response.getErrorMessage() != errMsg) {
			file.append("@@FLASE[$batchJobId]: Wrong error message, $errMsg was expected.");
			assert false, "Wrong error message, $errMsg was expected.";
		}
	}
	private void assertDecompressFailure(response) {
		String status = "834011207";
		String errMsg = " Failed to decompresses a image to a raw image";
		if(response.getStatus() != status) {
			file.append("@@FLASE[$batchJobId]: Wrong status is found in RESPONSE, $status was expected.");
			assert false, "Wrong status is found in RESPONSE, $status was expected.";
		}
		if(response.getErrorMessage() != errMsg) {
			file.append("@@FLASE[$batchJobId]: Wrong error message, $errMsg was expected.");
			assert false, "Wrong error message, $errMsg was expected.";
		}
	}
	private void assertTemplGenFailure(response) {
		String status = "834011206";
		String errMsg = "Template generation fail. (FTE in all modality)";
		if(response.getStatus() != status) {
			file.append("@@FLASE[$batchJobId]: Wrong status is found in RESPONSE, $status was expected.");
			assert false, "Wrong status is found in RESPONSE, $status was expected.";
		}
		if(response.getErrorMessage() != errMsg) {
			file.append("@@FLASE[$batchJobId]: Wrong error message, $errMsg was expected.");
			assert false, "Wrong error message, $errMsg was expected.";
		}
	}
	private void assertDuplication(response) {
		String status = "854051200";
		String errMsg = "Enroll Job ( Failed because of reference id duplication).";
		if(response.getStatus() != status) {
			file.append("@@FLASE[$batchJobId]: Wrong status is found in RESPONSE, $status was expected.");
			assert false, "Wrong status is found in RESPONSE, $status was expected.";
		}
		if(response.getErrorMessage() != errMsg) {
			file.append("@@FLASE[$batchJobId]: Wrong error message, $errMsg was expected.");
			assert false, "Wrong error message, $errMsg was expected.";
		}
	}
	private void assertOverLength(response) {
		String status = "854041101";
		String errMsg = "Enroll Job ( Reference Id:B14-i0011000000000000000000000000000error length:41 is incorrect. ) ";
		if(response.getStatus() != status) {
			file.append("@@FLASE[$batchJobId]: Wrong status is found in RESPONSE, $status was expected.");
			assert false, "Wrong status is found in RESPONSE, $status was expected.";
		}
		if(response.getErrorMessage() != errMsg) {
			file.append("@@FLASE[$batchJobId]: Wrong error message, $errMsg was expected.");
			assert false, "Wrong error message, $errMsg was expected.";
		}
	}
}
