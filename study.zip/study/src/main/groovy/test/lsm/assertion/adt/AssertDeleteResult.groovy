package test.lsm.assertion.adt

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;

import com.google.protobuf.ByteString;


public class AssertDeleteResult {

	public static final String SUCCESS = "0";

	public void assertResultSuccess(deleteResultMap){
		assertBatchJobId(deleteResultMap)
		assertBatchType(deleteResultMap)
		assertJobCount(deleteResultMap)
		assertRequestId(deleteResultMap)
		assertRequestType(deleteResultMap)
		assertEnrollmentId(deleteResultMap)
		assertStatus(deleteResultMap)
		assertErrorMessage(deleteResultMap)
		assertProcessMetricCount(deleteResultMap)
		assertProcessName(deleteResultMap)
		assertProcessStart(deleteResultMap)
		assertProcessEnd(deleteResultMap)
	}


	public void assertResultError(deleteResultMap, pErrCode){
		assertBatchJobId(deleteResultMap)
		assertBatchType(deleteResultMap)
		assertJobCount(deleteResultMap)
		assertRequestId(deleteResultMap)
		assertRequestType(deleteResultMap)
		assertEnrollmentId(deleteResultMap)
		assertStatusError(deleteResultMap, pErrCode)
	}
	
	public void assertResultErrorType(deleteResultMap, pErrCode){
		assertBatchJobId(deleteResultMap)
                assertBatchType(deleteResultMap)
                assertJobCount(deleteResultMap)
                assertRequestId(deleteResultMap)
                assertEnrollmentId(deleteResultMap)
                assertStatusError(deleteResultMap, pErrCode)
	}


//BatchJobId
		private void assertBatchJobId(deleteResultMap){
			long batchJobId = deleteResultMap."batchJobId";
            		if(batchJobId <= 0){
                    		assert false, "batchJobId is $batchJobId";
            		}		
	    	}
//BatchType
		private void assertBatchType(deleteResultMap){
            		String type = deleteResultMap."type";
            		if(type == null){
                    		assert false, "batchType is null";
            		}
            		if(type != "DELETE"){
                    		assert false, "batchType is not DELETE. actual $type";
            		}
		}
//jobCount,must be 1
		private void assertJobCount(deleteResultMap){
            		int jobCount = deleteResultMap."jobCount";
            		if(jobCount != 1){
                    		assert false, "Delete job not = 1 actual $jobCount";
            		}
		}

//requestId
		private void assertRequestId(deleteResultMap){
			String requestId = deleteResultMap."requestId_0";
			if(requestId == null){
				assert false, "requestId is null";
			}
		}
//requestType
		private void assertRequestType(deleteResultMap){
			String requestType = deleteResultMap."requestType_0";
			if(requestType == null){
				assert false, "requestType is null";
			}
			if(requestType != "DELETE"){
				assert false, "requestType is not DELETE. actual $requestType ";
			}
		}
//enrollmentId
		private void assertEnrollmentId(deleteResultMap){
			String enrollmentId = deleteResultMap."enrollmentId_0";
			if(enrollmentId == null){
				assert false, "enrollmentId is null";
			}
		}
//status
		private void assertStatus(deleteResultMap){
			String status = deleteResultMap."status_0";
			if(status != "0"){
				assert false, "jobStatus is not Success. actual $status";
			}
		}
//errorMessage
		private void assertErrorMessage(deleteResultMap){
			String errMessage = deleteResultMap."errMsg_0";
			if(errMessage != "" || !(errMessage.isEmpty() || errMessage != " ")){
				assert false, "JobStatus is Success. but errMessage is not empty";
			}
		}	
//processMetricCount,must be 1
		private void assertProcessMetricCount(deleteResultMap){
			int processMetricCount = deleteResultMap."processMetricCount_0";
			if(processMetricCount != 1){
				assert false, "processMetricCount not = 1 actual $processMetricCount";
			}
		}
//processName
		private void assertProcessName(deleteResultMap){
			String processName = deleteResultMap."processName_0-0";
			if(processName != "deletion"){
				assert false, "attributeName not = deletion actual $processName";
			}
		}
//processStart
		private void assertProcessStart(deleteResultMap){
			String processStart = deleteResultMap."processStart_0-0";
			if(processStart == null || (processStart.isEmpty())){
				assert false, "processStart is empty";
			}
		}
//processEnd
		private void assertProcessEnd(deleteResultMap){
			String processEnd = deleteResultMap."processEnd_0-0";
			if(processEnd == null || (processEnd.isEmpty())){
				assert false, "processEnd is empty";
			}
		}

//////////////ERROR//////////////////////
//Status0
		private void assertStatusError(deleteResultMap,pErrCode){
			String status = deleteResultMap."status_0";
			if(status == "0"){
				assert false, "jobStatus is Error. actual $Status";
			}
			if(status != null){
				assert status == pErrCode , "Status = $status"
			}else{
				assert false, "status is null ;_;"

			}
		}

}

