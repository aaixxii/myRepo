package test.lsm.assertion.adt

import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBResponse;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBDataBlock;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBCandidateList;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBCandidate;

public class AssertIdentifyResult {
	def file
	def identifyResult
	def First_prm_ccs
	def Second_prm_ccs
	def Third_prm_ccs
	def First_prm_ecs 
	long batchJobId
	int batchJobTime
	int jobNum
	def testfile

	public AssertIdentifyResult(identifyResult, batchJobId, batchJobTime, jobNum, file) {
		this.identifyResult = identifyResult;
		this.batchJobId = batchJobId;
		this.batchJobTime = batchJobTime;
		this.jobNum = jobNum;
		this.file = new File("$file");
	}
	public void assertIdentifyResult() {
		def basicAssertion = new AssertIdentifyBasic(identifyResult, batchJobId, jobNum);
		basicAssertion.assertIdentifyBasic();
		constructList();
		noda_sans_assertion();
		noda_sans_error_assertion()
		file.append("  TRUE [IDENTIFY]($batchJobId)\n");
	}

	private void noda_sans_assertion() {
		assertFirst();
		assertSecond();
		assertThird();
	}
	private assertFirst() {
		CPBBusinessMessage businessMessage =
                                CPBBusinessMessage.parseFrom(identifyResult.getBusinessMessage(0));
		
		CPBDataBlock dataBlock = businessMessage.getDataBlock();
		CPBCandidateList candidateList = dataBlock.getCandidateList();
		assertNoc(candidateList, First_prm_ccs);
		assertMore(candidateList, First_prm_ccs);
		assertNoHit(candidateList, First_prm_ccs);
	}
	private assertSecond() {
		CPBBusinessMessage businessMessage =
                                CPBBusinessMessage.parseFrom(identifyResult.getBusinessMessage(48));
		CPBDataBlock dataBlock = businessMessage.getDataBlock();
		CPBCandidateList candidateList = dataBlock.getCandidateList();
		assertNoc(candidateList, Second_prm_ccs);
		assertMore(candidateList, Second_prm_ccs);
		assertNoHit(candidateList, Second_prm_ccs);
	}
	private assertThird() {
		CPBBusinessMessage businessMessage =
                                CPBBusinessMessage.parseFrom(identifyResult.getBusinessMessage(49));
		CPBDataBlock dataBlock = businessMessage.getDataBlock();
		CPBCandidateList candidateList = dataBlock.getCandidateList();
		assertNoc(candidateList, Third_prm_ccs);
		assertMore(candidateList, Third_prm_ccs);
		assertNoHit(candidateList, Third_prm_ccs);
	}
	private assertNoc(candidateList, list) {
		int noc = candidateList.getCandidatesCount();
		int expectedNoc = list[batchJobTime - 1][0];
		if(noc != expectedNoc) {
			for(int i = 0; i < noc; i++ ) {
				CPBCandidate candidate = candidateList.getCandidates(i);
			}
			assert false, "number of candidate was $noc, but expected $expectedNoc";
		}
	}
	private assertMore(candidateList, list) {
		boolean more = candidateList.getMore();
		boolean expectedMore = list[batchJobTime - 1][1];
		if(more != expectedMore) {
			assert false, "moreFlag is supposed to be $expectedMore, but $more";
		}
	}
	private assertNoHit(candidateList, list) {
		for(int i = 2; i <= 4; i++) {
			if(list[batchJobTime - 1][i] != null) {
				String candidateId = list[batchJobTime - 1][i];
				for(int j = 0; j < candidateList.getCandidatesCount(); j++) {
					CPBCandidate candidate = candidateList.getCandidates(j);
					String enrollmentId = candidate.getEnrollmentId().substring(0,8);
					if(candidateId == enrollmentId) {
						assert false, "$candidateId is not supposed to be hit";
					}
				}
			}
		}
	}
	private void noda_sans_error_assertion() {
		//[isError, jobIndex, errCode, errMsg, print]
		if(First_prm_ecs[batchJobTime - 1][0]) {
			int messageIndex = First_prm_ecs[batchJobTime - 1][1];
			CPBBusinessMessage businessMessage =
                                 CPBBusinessMessage.parseFrom(identifyResult.getBusinessMessage(messageIndex - 1));
                 	CPBResponse response = businessMessage.getResponse();
			String status = response.getStatus();
			String errCode = First_prm_ecs[batchJobTime - 1][2];
			if(status != errCode) {
				assert false, "error code must be $errCode, but $status";
			}
			String errorMessage = response.getErrorMessage();
			String errMesg = First_prm_ecs[batchJobTime - 1][3];
			if(errorMessage != errMesg) {
				assert false, "error message must be $errMesg, but $errorMessage";
			}
		}
	}

	private void constructList() {
		First_prm_ccs = [
		[1,false,null,null,null],
		[1,true,null,null,null],
		[3,false,null,null,null],
		[4,false,null,null,null],
		[5,false,null,null,null],
		[5,true,null,null,null],
		[7,false,null,null,null],
		[8,false,null,null,null],
		[9,false,null,null,null],
		[10,false,null,null,null],
		[10,true,null,null,null],
		[12,false,null,null,null],
		[13,false,null,null,null],
		[10,true,null,null,null],
		[15,false,null,null,null],
		[16,false,null,null,null],
		[17,false,null,null,null],
		[18,false,null,null,null],
		[18,false,"B18-i001",null,null],
		[19,false,"B18-i001",null,null],
		[1,true,"B18-i001",null,null],
		[21,false,"B18-i001",null,null],
		[22,false,"B18-i001",null,null],
		[0,false,"B18-i001",null,null],
		[24,false,"B18-i001",null,null],
		[25,false,"B18-i001",null,null],
		[5,true,"B18-i001",null,null],
		[10,true,"B01-i001","B18-i001",null],
		[27,false,"B01-i001","B18-i001",null],
		[28,false,"B01-i001","B18-i001",null]];

		Second_prm_ccs = [
		[1,false,null,null,null],
		[1,true,null,null,null],
		[3,false,null,null,null],
		[4,false,null,null,null],
		[5,false,null,null,null],
		[5,true,null,null,null],
		[7,false,null,null,null],
		[8,false,null,null,null],
		[9,false,null,null,null],
		[10,false,null,null,null],
		[10,true,null,null,null],
		[12,false,null,null,null],
		[13,false,null,null,null],
		[10,true,null,null,null],
		[15,false,null,null,null],
		[16,false,null,null,null],
		[17,false,null,null,null],
		[18,false,null,null,null],
		[18,false,"B18-i051",null,null],
		[19,false,"B18-i051",null,null],
		[1,true,"B18-i051",null,null],
		[21,false,"B18-i051",null,null],
		[22,false,"B18-i051",null,null],
		[0,false,"B18-i051",null,null],
		[24,false,"B18-i051",null,null],
		[25,false,"B18-i051",null,null],
		[5,true,"B18-i051",null,null],
		[10,true,"B18-i051",null,null],
		[28,false,"B18-i051",null,null],
		[29,false,"B18-i051",null,null]];

		Third_prm_ccs = [
		[1,false,null,null,null],
		[1,true,null,null,null],
		[3,false,null,null,null],
		[4,false,null,null,null],
		[5,false,null,null,null],
		[5,true,null,null,null],
		[7,false,null,null,null],
		[8,false,null,null,null],
		[9,false,null,null,null],
		[10,false,null,null,null],
		[10,true,null,null,null],
		[12,false,null,null,null],
		[13,false,null,null,null],
		[10,true,null,null,null],
		[15,false,null,null,null],
		[16,false,null,null,null],
		[17,false,null,null,null],
		[18,false,null,null,null],
		[18,false,"B18-i100",null,null],
		[19,false,"B18-i100",null,null],
		[1,true,"B18-i100",null,null],
		[21,false,"B18-i100",null,null],
		[22,false,"B18-i100",null,null],
		[0,false,"B18-i100",null,null],
		[24,false,"B18-i100",null,null],
		[25,false,"B18-i100",null,null],
		[5,true,"B18-i100",null,null],
		[10,true,"B18-i100",null,null],
		[28,false,"B18-i100",null,null],
		[29,false,"B18-i100",null,null]];
		
		First_prm_ecs = [
		[false,0,null,null,false], //B01
		[false,0,null,null,false], //B02
		[true,20,844060301,"Identify Job ( template Not Found )",true], //B03
		[true,10,844060301,"Identify Job ( template Not Found )",true], //B04
	//	[true,30,834011206,"Template generation fail. (FTE in all modality)",false], //B05
		[false,0,null,null,false], //B05
		[true,20,844060301,"Identify Job ( template Not Found )",true], //B06
		[false,10,null,null,true], //B07
		[true,20,844060301,"Identify Job ( template Not Found )",true], //B08
		[true,30,834031103,"Imagefile has incosistency with MD5CheckSum. actual=[74a6de42c6153d38a2ed875931880ec1] parameter=[80b0e4f003ad071d685bd49b61c9e725]",false], //B09 new
	//	[true,30,834011103,"Invalid PAYLOAD (Imagefile has incosistency with MD5CheckSum)",false], //B09 new
	//	[true,30,834011207," Failed to decompresses a image to a raw image",false], //B09 old
		[true,10,844040100,"Identify Job ( max results = 0 is incorrect. )",true], //B10
		[true,20,844060301,"Identify Job ( template Not Found )",true], //B11
	//	[true,30,834011206,"Template generation fail. (FTE in all modality)",false], //B12
		[false,0,null,null,false], //B12
	//	[true,30,844040100,"Identify Job ( Request Id :requestId-test-test 's length is :19 not enough 36 Byte )",false], //B13 old
		[true,30,844040100,"Identify Job ( Request Id :requestId-test-test 's length is :19 not correct. )",false], //B13 new
		[true,20,844060301,"Identify Job ( template Not Found )",true], //B14
		[true,10,844040100,"Identify Job (  Reference Id :22222000000000000000000000000000073008 's length is :38 not enough 36 Byte ) ",true], //B15
		[false,20,854011101,null,true], //B16
		[false,20,854011101,null,true], //B17
		[true,10,844040100,"Identify Job ( TargetFPIR is not exist.. )",true], //B18
		[false,0,null,null,false], //B19
		[false,0,null,null,false], //B20
		[false,0,null,null,false], //B21
		[false,0,null,null,false], //B22
		[false,0,null,null,false], //B23
		[true,1,844060301,"Identify Job ( template Not Found )",true], //B24
		[false,0,null,null,false], //B25
		[false,0,null,null,false], //B26
		[false,0,null,null,false], //B27
		[false,0,null,null,false], //B28
		[false,0,null,null,false], //B29
		[false,0,null,null,false]]; //B30
	}
}
