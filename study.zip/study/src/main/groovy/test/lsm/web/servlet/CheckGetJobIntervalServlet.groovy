package test.lsm.web.servlet

import javax.servlet.*
import javax.servlet.http.*

import test.degrade.util.*


class CheckGetJobIntervalServlet extends HttpServlet {
	static final String FUNCTION_TYPE = "FunctionType"
	static final String IDENTIFY = "identify"
	static final String IDENTIFY_GETJOB_ACCEPT_COUNT = "identifyGetJobAcceptCount"
	static final String ENROLL = "enroll"
	static final String ENROLL_GETJOB_ACCEPT_COUNT = "enrollGetJobAcceptCount"
	static final int ONE_MSEC = 1000
	int correctIdentifyInterval = 0
	int correctEnrollInterval = 0
	Date identifyGetJobLastTimestamp = null
	Date enrollGetJobLastTimestamp = null
	SoapuiObject soapuiObject = null

	CheckGetJobIntervalServlet(context, correctIdentifyInterval, correctEnrollInterval){
		this.correctIdentifyInterval = correctIdentifyInterval
		this.correctEnrollInterval = correctEnrollInterval
		this.soapuiObject = new SoapuiObject(context)
	}
		
	def void doPost(HttpServletRequest req, HttpServletResponse res) {
		try {
			assertion(req)
			res.setStatus(200, "recieve")
			res.setContentType("text/plain")
		}catch (Throwable e){
println "@@@@@@@@@@@@@@@@@@"
println e
println "@@@@@@@@@@@@@@@@@@"
			res.sendError(400, "receive error")
			res.setContentType("text/plain")
			throw new Exception()
		}
	}

	def void doGet(HttpServletRequest req, HttpServletResponse res) {
		doPost(req, res)
	}

	def void assertion(HttpServletRequest req){
		String jobType = req.getParameter(FUNCTION_TYPE)
		boolean isCorrect

		if(jobType == ENROLL){
			print "[ ENROLL ]   : "
			isCorrect = isCorrectInterval(enrollGetJobLastTimestamp, correctEnrollInterval)
			enrollGetJobLastTimestamp = new Date()
			addAcceptCount(ENROLL_GETJOB_ACCEPT_COUNT)
		}else if(jobType == IDENTIFY){
			print "[ IDENTIFY ] : "
			isCorrect = isCorrectInterval(identifyGetJobLastTimestamp, correctIdentifyInterval)
			identifyGetJobLastTimestamp = new Date()
			addAcceptCount(IDENTIFY_GETJOB_ACCEPT_COUNT)
		}
		if(!isCorrect){
			throw new Exception()
		}
	}

	def boolean isCorrectInterval(Date lastTimestamp, int correctInterval){
		if(lastTimestamp == null){
			println "This is first get job request. set timestamp."
			return true
		}else{
			Date now = new Date()
			int elaps = (now.time - lastTimestamp.time) 
			println "Now [${now}] : last [${lastTimestamp}] --> diffrence [${elaps}]"
			return isDiffWithnLimit(elaps, correctInterval)
		}	
	}

	def boolean isDiffWithnLimit(int actualInterval, int expectedInterval){
		println "actual [${actualInterval}] : expected [${expectedInterval}] diffrence must be within 1000 msec."
		if( actualInterval < (expectedInterval + ONE_MSEC) 
			&& (expectedInterval - ONE_MSEC) < actualInterval){
			return true
		}else{
			return false
		}
	}

	def addAcceptCount(String key){
		int count = soapuiObject.getProperties(key) as int
		count++
		soapuiObject.setProperties(key, count as String)
	}
}
