package test.lsm.web.servlet

import javax.servlet.*
import javax.servlet.http.*

import test.common.properties.*
import test.lsm.performance.job.*


class JobPushServlet extends HttpServlet {
	static final String BJ_COUNT = "BatchJobCount"
	static final String TLJ_COUNT = "JobCount"
	static final String TURN_ARROUND_TIME = "TurnAroundTime"
	static final String POST_URL = "PostURL"
	static final String FUNCTION_TYPE = "FunctionType"
	static final String IDENTIFY = "identify"
	static final String ENROLL = "enroll"
	IdentifyJobManagerInterface identifyJobManager
	EnrollJobManagerForMorita enrollJobManager
	int pushJobInterval

	JobPushServlet(context, boolean isById){
		ProjectProperties projectProperties = new ProjectProperties(context)
		this.pushJobInterval = Integer.parseInt(projectProperties.getProperty("INTERVAL_PUSH_JOB_MSEC"))
		this.enrollJobManager = new EnrollJobManagerForMorita(context)
		if(isById){
			this.identifyJobManager = new IdentifyJobManager(context)
		}else{
			this.identifyJobManager = new IdentifyJobByURLManager(context)
		}
	}
		
	def void doPost(HttpServletRequest req, HttpServletResponse res) {
		try {
			pushJob(req)
			res.setStatus(200, "recieve")
			res.setContentType("text/plain")
		}catch (Exception e){
println "@@@@@@@@@@@@@@@@@@"
e.printStackTrace()
println e
println "@@@@@@@@@@@@@@@@@@"
			res.sendError(400, "receive error")
			res.setContentType("text/plain")
		}
	}

	def void doGet(HttpServletRequest req, HttpServletResponse res) {
		doPost(req, res)
	}

	def void pushJob(HttpServletRequest req){
		String postUrl = req.getParameter(POST_URL)
		String tljCount = req.getParameter(TLJ_COUNT)
		String jobType = req.getParameter(FUNCTION_TYPE)

		if(jobType == ENROLL){
			println "Request Enroll batch jobs from TMe. sleep $pushJobInterval msec"
			sleep pushJobInterval
			pushEnrllJob(postUrl, tljCount)
			println "Pushed Enroll jobs !! Uhyo----!! "
		}else if(jobType == IDENTIFY){
			println "Request Identify batch jobs from TMi. sleep $pushJobInterval msec"
			sleep pushJobInterval
			pushIdentifyJob(postUrl, tljCount)
			println "Pushed Identify jobs !! Uhyo----!! "
		}
	}

	def void pushEnrllJob(String postUrl, String tljCount){
		enrollJobManager.setPostUrl(postUrl)
		enrollJobManager.setTljCount(tljCount as int)
		enrollJobManager.pushJob()
	}

	def void pushIdentifyJob(String postUrl, String tljCount){
		identifyJobManager.setPostUrl(postUrl)
		identifyJobManager.setTljCount(tljCount as int)
		identifyJobManager.pushJob()
	}
}
