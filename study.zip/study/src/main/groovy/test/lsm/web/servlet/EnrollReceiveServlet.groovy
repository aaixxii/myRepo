package test.lsm.web.servlet

import javax.servlet.*
import javax.servlet.http.*

import jp.co.nec.lsm.test.duration.assertion.*
import jp.co.nec.lsm.tm.protocolbuffer.enroll.EnrollResultRequestProto.EnrollResultRequest
import jp.co.nec.lsm.assertion.response.display.EnrollResultRequestPrinter

import test.common.properties.*


class EnrollReceiveServlet extends HttpServlet {

	EnrollResultRequestPrinter enrollResultPrinter = new EnrollResultRequestPrinter()
	EnrollResultRequestDurationAssertion enrollResultAssertor = new EnrollResultRequestDurationAssertion()
	boolean dosePrintResult
	boolean doseAssert

	EnrollReceiveServlet(context){
		ProjectProperties projectProperties = new ProjectProperties(context)
		this.dosePrintResult = Boolean.parseBoolean(projectProperties.getProperty("PRINT_ENROLL_RESULT"))
		this.doseAssert = Boolean.parseBoolean(projectProperties.getProperty("DO_ENROLL_ASSERTION"))
	}

	def void doGet(HttpServletRequest req, HttpServletResponse res) {
		doPost(req, res)
	}

	def void doPost(HttpServletRequest req, HttpServletResponse res) {
		def enrollResult = null
		try {
			enrollResult = deserialize(req.getInputStream())
		}catch (Exception e){
			println "@@@@ " + e
			res.sendError(400, "receive error")
		}

		processResult(enrollResult)
	}

	def deserialize(requestInputStream) {
		return EnrollResultRequest.parseFrom(requestInputStream)
	}

	def synchronized processResult(enrollResult){
		printEnrollResult(enrollResult)
		assertEnrollResult(enrollResult)
	}

	def printEnrollResult(enrollResult){
		if(dosePrintResult){
			enrollResultPrinter.print(enrollResult)
		}
	}

	def assertEnrollResult(enrollResult) {
		if(doseAssert){
			enrollResultAssertor.assertResultRequest(enrollResult)
		}
	}
}
