package test.lsm.web.servlet

import javax.servlet.*
import javax.servlet.http.*

import jp.co.nec.lsm.test.duration.assertion.*
import jp.co.nec.lsm.tm.protocolbuffer.identify.IdentifyResultRequestProto.IdentifyResultRequest
import jp.co.nec.lsm.assertion.response.display.IdentifyResultRequestPrinter

import test.common.properties.*


class IdentifyReceiveServlet extends HttpServlet {

	IdentifyResultRequestPrinter identifyResultPrinter = new IdentifyResultRequestPrinter()
	IdentifyResultRequestDurationAssertion identifyResultAssertor = new IdentifyResultRequestDurationAssertion()
	boolean dosePrintResult
	boolean doseAssert
	boolean checkOnlyJobSuccess = false

	IdentifyReceiveServlet(context){
		ProjectProperties projectProperties = new ProjectProperties(context)
		this.dosePrintResult = Boolean.parseBoolean(projectProperties.getProperty("PRINT_IDENTIFY_RESULT"))
		this.doseAssert = Boolean.parseBoolean(projectProperties.getProperty("DO_IDENTIFY_ASSERTION"))
		this.checkOnlyJobSuccess = Boolean.parseBoolean(projectProperties.getProperty("CHECK_ONLY_JOB_SUCCESS"))
	}


	def void doGet(HttpServletRequest req, HttpServletResponse res) {
		doPost(req, res)
	}

	def void doPost(HttpServletRequest req, HttpServletResponse res) {
		def identifyResult = null
		try {
			identifyResult = deserialize(req.getInputStream())
		}catch (Exception e){
			res.sendError(400, "receive error")
		}
		processResult(identifyResult)

	}

	def synchronized processResult(identifyResult){
		printResult(identifyResult)
		assertIdentifyResult(identifyResult)
	}
		
	def deserialize(requestInputStream) {
		return IdentifyResultRequest.parseFrom(requestInputStream)
	}

	def printResult(identifyResult){
		if(dosePrintResult){
			identifyResultPrinter.print(identifyResult)
		}
	}

	def assertIdentifyResult(identifyResult) {
		if(!doseAssert){
			return
		}
		if(checkOnlyJobSuccess){
			identifyResultAssertor.assertResultRequestSuccess(identifyResult)
		}else{
			identifyResultAssertor.assertResultRequest(identifyResult)
		}
	}
}
