package test.lsm.dump

import jp.co.nec.lsm.accenture.request.factory.*

import test.common.util.db.*

class DeleteBusinessMessageDumper{

	String dumpFileName = "deleteBusinessMessg"

    def void dumpJobBySql(String ip, String port, String sid, String user, String pass, String sql, String dirPath){
        def sqlExecutor = new SqlExecutorFactory().create(ip, port, sid, user, pass)
        def ArrayList dataList = sqlExecutor.getSqlResult(sql)
        for(int i = 0; i < dataList.size(); i++){
			dumpJob("${dirPath}/${dumpFileName}_${i+1}.bin", dataList.get(i).reference_id) 
        }
    }

	def dumpJob(String filePath, String referenceId){
		def businessMessage = CPBBusinessMessageFactory.createForDelete(referenceId)
		File dumpFile = new File(filePath)
		dumpFile.write("")
		dumpFile.append(businessMessage.toByteArray())
	}
}

