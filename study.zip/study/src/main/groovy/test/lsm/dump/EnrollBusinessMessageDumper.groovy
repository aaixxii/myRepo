package test.lsm.dump

import jp.co.nec.lsm.accenture.request.factory.*

import test.common.util.db.*

class EnrollBusinessMessageDumper{
	String dumpFileName = "enrollBusinessMessg"

    def void dumpJobBySql(String ip, String port, String sid, String user, String pass, String sql, String dirPath){
        def sqlExecutor = new SqlExecutorFactory().create(ip, port, sid, user, pass)
        def ArrayList dataList = sqlExecutor.getSqlResult(sql)
        for(int i = 0; i < dataList.size(); i++){
			dumpJob("${dirPath}/${dumpFileName}_${i+1}.bin", 
						dataList.get(i).reference_id, 
						dataList.get(i).reference_url, 
						dataList.get(i).check_sum as String
			) 
        }
    }

	def dumpJob(String filePath, String referenceId, String referenceUrl, String checkSum){
		def businessMessage = CPBBusinessMessageFactory.createForEnroll(referenceId, referenceUrl, checkSum)
		File dumpFile = new File(filePath)
		dumpFile.write("")
		dumpFile.append(businessMessage.toByteArray())
	}
}

