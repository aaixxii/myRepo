package test.lsm.dump

import jp.co.nec.lsm.accenture.request.factory.*

import test.common.util.db.*

class IdentifyBusinessMessageDumper{

	String dumpFileName = "identifyBusinessMessg"


    def void dumpJobBySql(String ip, String port, String sid, String user, String pass, String sql, 
							String loc, String fpir, String dirPath){
        def sqlExecutor = new SqlExecutorFactory().create(ip, port, sid, user, pass)
        def ArrayList dataList = sqlExecutor.getSqlResult(sql)
        for(int i = 0; i < dataList.size(); i++){
			dumpJob("${dirPath}/${dumpFileName}_${i+1}.bin", dataList.get(i).reference_id, loc, fpir) 
        }
    }

    def void dumpJobBySql(String ip, String port, String sid, String user, String pass, String sql, 
							String loc, String fpir, String dirPath, int loopCnt){
        def sqlExecutor = new SqlExecutorFactory().create(ip, port, sid, user, pass)
        def ArrayList dataList = sqlExecutor.getSqlResult(sql)
		def num = 1
		for(int k = 0; k < loopCnt; k++){
        		for(int i = 0; i < dataList.size(); i++){
				dumpJob("${dirPath}/${dumpFileName}_${num}.bin", dataList.get(i).reference_id, loc, fpir) 
				num++
			}
        	}
    }

    def void dumpJobBySqlWithoutId(String ip, String port, String sid, String user, String pass, String sql, 
							String loc, String fpir, String dirPath){
        def sqlExecutor = new SqlExecutorFactory().create(ip, port, sid, user, pass)
        def ArrayList dataList = sqlExecutor.getSqlResult(sql)
        for(int i = 0; i < dataList.size(); i++){
			dumpJobWithoutEnrollmentId("${dirPath}/${dumpFileName}_${i+1}.bin", loc, fpir) 
        }
    }

	def dumpJob(String filePath, String referenceId, String loc, String fpir){
		def businessMessage = CPBBusinessMessageFactory.createForIdentifyById(referenceId, loc as int, fpir as int)
		File dumpFile = new File(filePath)
		dumpFile.write("")
		dumpFile.append(businessMessage.toByteArray())
	}
	def dumpJobWithoutEnrollmentId(String filePath, String loc, String fpir){
		def businessMessage = CPBBusinessMessageFactory.createForIdentifyByIdWithoutEnrollmentId(loc as int, fpir as int)
		File dumpFile = new File(filePath)
		dumpFile.write("")
		dumpFile.append(businessMessage.toByteArray())
	}
}
