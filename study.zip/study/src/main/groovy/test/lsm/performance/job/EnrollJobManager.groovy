package test.lsm.performance.job

import test.common.properties.*
import test.lsm.runner.*
import common.sql.*

class EnrollJobManager{
	static final String DATA_DB_IP = "192.168.0.5"
    static final String DATA_DB_PORT = "1521"
    static final String DATA_DB_SID = "AIMDB"
    static final String DATA_DB_USER = "LSMJOB"
    static final String DATA_DB_PASS = "LSMJOB"
	static final String DATA_LIST_2ND = "data_list_perf"
	static final String DATA_ID = "data_id"
	// this is analize param for test
	static final String ORIGINAL_SQL = "select * from ${DATA_LIST_2ND} where ${DATA_ID} = 148460" 
	String postUrl
	String loopType
	boolean useUuid
	boolean originalFlag // this is analize param for test
	long batchJobId
	int limitBjSize
	int pushedBjSize
	int limitJobCnt
	int nextPushMinId
	int totalPushJobCnt
	int tljCount
	SqlExecutor sqlExecutor

	EnrollJobManager(context){
		getProjectProperty(context)
		this.sqlExecutor = new SqlExecutor(DATA_DB_IP, DATA_DB_PORT, DATA_DB_SID, DATA_DB_USER, DATA_DB_PASS)
		this.limitJobCnt = getLimitJobCount()
		this.nextPushMinId = 0
		this.totalPushJobCnt = 0
		this.batchJobId = 10000
		this.pushedBjSize = 0
	}

	def getProjectProperty(context){
		ProjectProperties projectProperties = new ProjectProperties(context)
		this.loopType = projectProperties.getProperty("LOOP_TYPE")
		this.limitBjSize = Integer.parseInt(projectProperties.getProperty("JOB_LOOP_SIZE_ENROLL"))
		this.useUuid = new Boolean(projectProperties.getProperty("USE_UUID_ENROLL_REF_ID"))
		this.originalFlag = new Boolean(projectProperties.getProperty("ORIGINAL_FLAG"))
	}

	def int getLimitJobCount(){
		String sql = "select count(*) from $DATA_LIST_2ND"
		return sqlExecutor.selectCountSql(sql)
	}

	def synchronized void pushJob() {
		if(pushedBjSize >= limitBjSize){
			println "already posted number of $limitBjSize BJs."
			return
		}
		def jobPusher = createJobPusher()
		String sql = createJobInfoSql()
		println "Enroll : $sql"
		postBatchJob(jobPusher, sql)
		addCountAfterJobPush()
	}

	def addCountAfterJobPush(){
		batchJobId++
		totalPushJobCnt += tljCount
		pushedBjSize++
	}
		

	def createJobPusher(){
		return new EnrollJobPusher2nd()
	}

	def createJobInfoSql(){
		if(originalFlag){
			return ORIGINAL_SQL
		}

		initialIds()
		def startId = 0
		if(loopType == "SAME"){
			// do nothing
		}else{
			startId = nextPushMinId
		}
		def endId = getEndId(startId)
		nextPushMinId = endId + 1
		return createSelectRefIdSql(startId, endId)
	}

	def initialIds(){
		def remainJobCnt = limitJobCnt - totalPushJobCnt
		if(remainJobCnt < tljCount){
			nextPushMinId = 0
			totalPushJobCnt = 0
		}
	}

	def getEndId(startId){
		def endId = startId + tljCount - 1
		while(true){
			String sql = createSelectCountSql(startId, endId)
			def recordCount = sqlExecutor.selectCountSql(sql)
			if(recordCount == tljCount){
				return endId
			}else{
				sql = createSelectMinIdSql(endId)
				def remainCount = tljCount - recordCount
				def nextMinDataId = sqlExecutor.getSqlResultOneRecord(sql)
				endId = nextMinDataId + remainCount -1
			}
		}
	}
	
	def createSelectCountSql(startId, endId){
		return "select count(*) from $DATA_LIST_2ND where $DATA_ID between $startId and $endId"
	}
	
	def createSelectMinIdSql(endId){
		return "select min($DATA_ID) from $DATA_LIST_2ND where $DATA_ID > $endId"
	}
	
	def createSelectRefIdSql(startId, endId){
		return "select * from $DATA_LIST_2ND where $DATA_ID between $startId and $endId"
	}
	
	def postBatchJob(jobPusher, sql){
		if(useUuid){
			jobPusher.setDataListUseUUID(DATA_DB_IP, DATA_DB_PORT, DATA_DB_SID, DATA_DB_USER, DATA_DB_PASS, sql)
		}else{
			jobPusher.setDataList(DATA_DB_IP, DATA_DB_PORT, DATA_DB_SID, DATA_DB_USER, DATA_DB_PASS, sql)
		}
		jobPusher.pushJob(postUrl, batchJobId)
	}

	def void setTljCount(int tljCount){
		this.tljCount = tljCount
	}

	def void setPostUrl(String url){
		this.postUrl = url
	}
}


