package test.lsm.performance.job

import test.common.properties.*
import test.lsm.runner.*
import common.sql.*

interface IdentifyJobManagerInterface{

	def getProjectProperty(context)
	def int getLimitJobCount()
	def void pushJob() 
	def addCountAfterJobPush()
	def createJobPusher()
	def createJobInfoSql()
	def initialIds()
	def getEndId(startId)
	def createSelectCountSql(startId, endId)
	def createSelectMinIdSql(endId)
	def createSelectRefIdSql(startId, endId)
	def postBatchJob(jobPusher, sql)
	def void setTljCount(int tljCount)
	def void setPostUrl(String url)
}


