package test.lsm.performance.job

import test.common.properties.*
import test.lsm.runner.*
import common.sql.*

class IdentifyJobByURLManager implements IdentifyJobManagerInterface {
	String postUrl
	String loc
	String fpir
	String loopType
	String bisonDbIp = "192.168.22.1"
	String bisonDbPort = "1521"
	String bisonDbSid = "AIMDB"
	String bisonDbUser = "LSMJOB"
	String bisonDbPass = "LSMJOB"
	static final String TABLE_NAME = "data_list_2nd"
	static final String DATA_ID = "data_id"
	static final String COLMUN = "*"
	long batchJobId
	int limitBjSize
	int pushedBjSize
	int limitJobCnt
	int nextPushMinId
	int totalPushJobCnt
	int tljCount
	SqlExecutor sqlExecutor

	IdentifyJobByURLManager(context){
		getProjectProperty(context)
		this.sqlExecutor = new SqlExecutor(bisonDbIp, bisonDbPort, bisonDbSid, bisonDbUser, bisonDbPass)
		this.limitJobCnt = getLimitJobCount()
		this.nextPushMinId = 0
		this.totalPushJobCnt = 0
		this.batchJobId = 1
		this.pushedBjSize = 0
	}

	def getProjectProperty(context){
		ProjectProperties projectProperties = new ProjectProperties(context)
		this.loc = projectProperties.getProperty("LOC")
		this.fpir = projectProperties.getProperty("FPIR")
		this.loopType = projectProperties.getProperty("LOOP_TYPE")
		this.limitBjSize = Integer.parseInt(projectProperties.getProperty("JOB_LOOP_SIZE_IDENTIFY"))
	}

	def int getLimitJobCount(){
		String sql = "select count(*) from $TABLE_NAME where data_type = 52"
		return sqlExecutor.selectCountSql(sql)
	}

	def void pushJob() {
		if(pushedBjSize >= limitBjSize){
			println "already posted number of $limitBjSize BJs."
			return
		}
		def jobPusher = createJobPusher()
		String sql = createJobInfoSql()
		postBatchJob(jobPusher, sql)
		addCountAfterJobPush()
	}

	def addCountAfterJobPush(){
		batchJobId++
		totalPushJobCnt += tljCount
		pushedBjSize++
	}
		

	def createJobPusher(){
		return new IdentifyJobPusher2nd()
	}

	def createJobInfoSql(){
		initialIds()
		def startId = 0
		if(loopType == "SAME"){
			// do nothing
		}else{
			startId = nextPushMinId
		}
		def endId = getEndId(startId)
		nextPushMinId = endId + 1
		return createSelectRefIdSql(startId, endId)
	}

	def initialIds(){
		def remainJobCnt = limitJobCnt - totalPushJobCnt
		if(remainJobCnt < tljCount){
			nextPushMinId = 0
			totalPushJobCnt = 0
		}
	}

	def getEndId(startId){
		def endId = startId + tljCount - 1
		while(true){
			String sql = createSelectCountSql(startId, endId)
			def recordCount = sqlExecutor.selectCountSql(sql)
			if(recordCount == tljCount){
				return endId
			}else{
				sql = createSelectMinIdSql(endId)
				def remainCount = tljCount - recordCount
				def nextMinDataId = sqlExecutor.getSqlResultOneRecord(sql)
				endId = nextMinDataId + remainCount -1
			}
		}
	}
	
	def createSelectCountSql(startId, endId){
		return "select count(*) from $TABLE_NAME where $DATA_ID between $startId and $endId"
	}
	
	def createSelectMinIdSql(endId){
		return "select min($DATA_ID) from $TABLE_NAME where $DATA_ID > $endId"
	}
	
	def createSelectRefIdSql(startId, endId){
		return "select $COLMUN from $TABLE_NAME where $DATA_ID between $startId and $endId"
	}
	
	def postBatchJob(jobPusher, sql){
		jobPusher.setDataList(bisonDbIp, bisonDbPort, bisonDbSid, bisonDbUser, bisonDbPass, sql, loc, fpir)
		jobPusher.pushJobByUrl(postUrl, batchJobId)
	}

	def void setTljCount(int tljCount){
		this.tljCount = tljCount
	}

	def void setPostUrl(String url){
		this.postUrl = url
	}
}


