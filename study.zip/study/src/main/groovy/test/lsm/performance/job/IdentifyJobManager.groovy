package test.lsm.performance.job

import test.common.properties.*
import test.lsm.runner.*
import common.sql.*

class IdentifyJobManager implements IdentifyJobManagerInterface{
	String postUrl
	String loc
	String fpir
	String loopType
	String bisonDbIp
	String bisonDbPort
	String bisonDbSid
	String bisonDbUser
	String bisonDbPass
	static final String PERSON_BIO_TAB = "person_biometrics"
	static final String PERSON_BIO_ID_COLMN = "biometrics_id"
	static final String REFERENCE_ID = "reference_id"
	long batchJobId
	int limitBjSize
	int pushedBjSize
	int limitJobCnt
	int nextPushMinId
	int totalPushJobCnt
	int tljCount
	SqlExecutor sqlExecutor

	IdentifyJobManager(context){
		getProjectProperty(context)
		this.sqlExecutor = new SqlExecutor(bisonDbIp, bisonDbPort, bisonDbSid, bisonDbUser, bisonDbPass)
		this.limitJobCnt = getLimitJobCount()
		this.nextPushMinId = 0
		this.totalPushJobCnt = 0
		this.batchJobId = 1
		this.pushedBjSize = 0
	}

	def getProjectProperty(context){
		ProjectProperties projectProperties = new ProjectProperties(context)
		this.loc = projectProperties.getProperty("LOC")
		this.fpir = projectProperties.getProperty("FPIR")
		this.loopType = projectProperties.getProperty("LOOP_TYPE")
		this.limitBjSize = Integer.parseInt(projectProperties.getProperty("JOB_LOOP_SIZE_IDENTIFY"))
		this.bisonDbIp = projectProperties.getProperty("DB_IP")
		this.bisonDbPort = projectProperties.getProperty("DB_PORT")
		this.bisonDbSid = projectProperties.getProperty("DB_SID")
		this.bisonDbUser = projectProperties.getProperty("DB_USER")
		this.bisonDbPass = projectProperties.getProperty("DB_PASS")
	}

	def int getLimitJobCount(){
		String sql = "select count(*) from $PERSON_BIO_TAB"
		return sqlExecutor.selectCountSql(sql)
	}

	def synchronized void pushJob() {
		if(pushedBjSize >= limitBjSize){
			println "already posted number of $limitBjSize BJs."
			return
		}
		def jobPusher = createJobPusher()
		println new Date().format("yyyy/MM/dd HH:mm:ss") + " create SQL"
		String sql = createJobInfoSql()
		println new Date().format("yyyy/MM/dd HH:mm:ss") + " post BJ"
		postBatchJob(jobPusher, sql)
		println new Date().format("yyyy/MM/dd HH:mm:ss") + " addCount"
		addCountAfterJobPush()
	}

	def addCountAfterJobPush(){
		batchJobId++
		totalPushJobCnt += tljCount
		pushedBjSize++
	}
		

	def createJobPusher(){
		return new IdentifyJobPusher2nd()
	}

	def createJobInfoSql(){
		initialIds()
		def startId = 0
		if(loopType == "SAME"){
			return "select $REFERENCE_ID from $PERSON_BIO_TAB where rownum <= $tljCount"
		}else{
			startId = nextPushMinId
		}
		def endId = getEndId(startId)
		nextPushMinId = endId + 1
		return createSelectRefIdSql(startId, endId)
	}

	def initialIds(){
		def remainJobCnt = limitJobCnt - totalPushJobCnt
		if(remainJobCnt < tljCount){
			nextPushMinId = 0
			totalPushJobCnt = 0
		}
	}

	def getEndId(startId){
		def endId = startId + tljCount - 1
		while(true){
			String sql = createSelectCountSql(startId, endId)
			def recordCount = sqlExecutor.selectCountSql(sql)
			if(recordCount == tljCount){
				return endId
			}else{
				sql = createSelectMinIdSql(endId)
				def remainCount = tljCount - recordCount
				def nextMinDataId = sqlExecutor.getSqlResultOneRecord(sql)
				endId = nextMinDataId + remainCount -1
			}
		}
	}
	
	def createSelectCountSql(startId, endId){
		return "select count(*) from $PERSON_BIO_TAB where $PERSON_BIO_ID_COLMN between $startId and $endId"
	}
	
	def createSelectMinIdSql(endId){
		return "select min($PERSON_BIO_ID_COLMN) from $PERSON_BIO_TAB where $PERSON_BIO_ID_COLMN > $endId"
	}
	
	def createSelectRefIdSql(startId, endId){
		return "select $REFERENCE_ID from $PERSON_BIO_TAB where $PERSON_BIO_ID_COLMN between $startId and $endId"
	}
	
	def postBatchJob(jobPusher, sql){
		println new Date().format("yyyy/MM/dd HH:mm:ss") + " setDataList"
		jobPusher.setDataList(bisonDbIp, bisonDbPort, bisonDbSid, bisonDbUser, bisonDbPass, sql, loc, fpir)
		println new Date().format("yyyy/MM/dd HH:mm:ss") + " pushJob"
		jobPusher.pushJob(postUrl, batchJobId)
	}

	def void setTljCount(int tljCount){
		this.tljCount = tljCount
	}

	def void setPostUrl(String url){
		this.postUrl = url
	}
}


