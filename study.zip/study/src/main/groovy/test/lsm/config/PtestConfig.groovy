package test.lsm.config

class PtestConfig{
	def static getConnectoinUrl(ip, port, sid) {
		return "jdbc:oracle:thin:@${ip}:${port}/${sid}"
    }
}
		
