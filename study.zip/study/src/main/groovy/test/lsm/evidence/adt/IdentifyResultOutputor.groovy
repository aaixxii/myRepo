package test.lsm.evidence.adt

import com.nec.everest.proto.protobuf.BusinessMessage.E_REQUESET_TYPE;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBRequest;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBResponse;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBResponseAttribute;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBDataBlock;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBProcessMetrics;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBProcessInfo;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBCandidateList;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBCandidate;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBScore;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBDataGroup;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBDataElement;

public class IdentifyResultOutputor {
	def identifyResult
	def file
	def date

	IdentifyResultOutputor(identifyResult, file) {
		this.identifyResult = identifyResult;
		this.file = new File("$file");
		this.date = new Date().format("yyyy/MM/dd HH:mm:ss");
	}
	def writeIdentifyResult() {
		writeTimeStamp();
		writeSplitor();
		writeBatchJobId();
		writeBatchType();
		writeSplitor();
		writeBusinessMessage();
	}

	def writeTimeStamp() {
		file.append("Identify batch job result received at ${date}\n");	
	}

	def writeSplitor() {
		file.append("=============================================================================\n");
	}

	def writeBatchJobId() {
		String batchJobId = identifyResult.getBatchJobId();
		file.append("BatchJobID: $batchJobId\t");
	}

	def writeBatchType() {
		String batchType = identifyResult.getType().name();
		file.append("BatchType: $batchType\n");
	}

	def writeBusinessMessage() {
		for(int i = 0; i < identifyResult.getBusinessMessageCount(); i++) {
			CPBBusinessMessage businessMessage =
                                CPBBusinessMessage.parseFrom(identifyResult.getBusinessMessage(i));
			writeRequest(businessMessage);
			writeResponse(businessMessage);
			writeDataBlock(businessMessage);
			file.append("-----------------------------------------------------------------------------\n");
		}
	}

	def writeRequest(businessMessage) {
		CPBRequest request = businessMessage.getRequest();
		writeRequestId(request);
		writeRequestType(request);
	}
	def writeRequestId(request) {
		String requestId = request.getRequestId();
		file.append("RequestId: $requestId\t");
	}
	def writeRequestType(request) {
		String requestId = request.getRequestType();
		file.append("RequestType: $requestId\n");
	}
	
	def writeResponse(businessMessage) {
		CPBResponse response = businessMessage.getResponse();
		writeStatus(response);	
		writeResendable(response);
		writeErrorMessage(response);
		writeResponseAttribute(response);
	}
	def writeStatus(response) {
		String status = response.getStatus();
		file.append("Status: $status\n");
	}
	def writeResendable(response) {
		String resendable = response.getResendable();
		file.append("Resendable: $resendable\n");
	}
	def writeErrorMessage(response) {
		String errMessage = response.getErrorMessage();
		file.append("ErrorMessage: $errMessage\n");
	}
	def writeResponseAttribute(response) {
		for(int i = 0; i < response.getResponseAttributesCount(); i++) {
			CPBResponseAttribute attribute = response.getResponseAttributes(i);
			writeAttributeName(attribute);
			writeAttributeValue(attribute);
		}
	}
	def writeAttributeName(attribute) {
		String attributeName = attribute.getAttributeName();
		file.append("AttributeName: $attributeName\t");
	}
	def writeAttributeValue(attribute) {
		String attributeValue = attribute.getAttributeValue();
		file.append("AttributeValue: $attributeValue\n");
	}
	
	def writeDataBlock(businessMessage) {
		CPBDataBlock dataBlock = businessMessage.getDataBlock();
		CPBCandidateList candidateList = dataBlock.getCandidateList();
		writeMore(candidateList);
		for(int i = 0; i < candidateList.getCandidatesCount(); i++) {
			CPBCandidate candidate = candidateList.getCandidates(i);
			writeCandidate(candidate);
		}
		CPBProcessMetrics processMetrics = dataBlock.getProcessMetric();
		for(int i = 0; i < processMetrics.getProcessMetricCount(); i++) {
			CPBProcessInfo processInfo = processMetrics.getProcessMetric(i);
			writeProcessName(processInfo);
			writeProcessStart(processInfo);
			writeProcessEnd(processInfo);
		}
		for(int i = 0; i < dataBlock.getDataGroupCount(); i++) {
			CPBDataGroup dataGroup = dataBlock.getDataGroup(i);
			writeGroupName(dataGroup);
			for(int j = 0; j < dataGroup.getDataElementCount(); j++) {
				CPBDataElement dataElement = dataGroup.getDataElement(j);
				writeDataElement(dataElement);
			}
		}
	}
	def writeGroupName(dataGroup) {
		String groupName = dataGroup.getGroupName();
		file.append("GroupName: $groupName\n");
	}
	def writeDataElement(dataElement) {
		String elementName = dataElement.getElementName();
		String elementValue = dataElement.getElementValue();
		file.append("ElementName: $elementName\t");
		file.append("ElementValue: $elementValue\n");
	}
	def writeMore(candidateList) {
		String more = candidateList.getMore().toString();
		file.append("More: $more\n");
	}
	def writeCandidate(candidate) {
		writeEnrollmentId(candidate);
		for(int i = 0; i < candidate.getScoreCount(); i++) {
			CPBScore score = candidate.getScore(i);
			writeModalityType(score);
			writeModalitySubType(score);
			writeScore(score); 
		}
		writeScaledScore(candidate);
	}
	def writeEnrollmentId(candidate) {
		String enrollmentId = candidate.getEnrollmentId();
		file.append("EnrollmentID: $enrollmentId\n");
	}
	def writeModalityType(score) {
		String modalityType = score.getModalityType().name();
		file.append("ModalityType: $modalityType\t");
	}
	def writeModalitySubType(score) {
		String modalitySubType = score.getModalitySubType();
		file.append("ModalitySubType: $modalitySubType\t");
	}
	def writeScore(score) {
		String scoreValue = score.getValue();
		file.append("Score: $scoreValue\n");
	}
	def writeScaledScore(candidate) {
		int scaledScore = candidate.getScaledScore();
		file.append("ScaledScore: $scaledScore\n");
	}
	def writeProcessName(processInfo){
		String processName = processInfo.getProcessName();
		file.append("ProcessName: $processName\t");
	}
	def writeProcessStart(processInfo) {
		String startTime = processInfo.getStartTime();
		file.append("ProcessStart: $startTime\t");
	}
	def writeProcessEnd(processInfo) {
		String endTime = processInfo.getEndTime();
		file.append("ProcessEnd: $endTime\n");
	}
}
