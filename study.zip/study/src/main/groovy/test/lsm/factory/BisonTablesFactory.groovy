package test.lsm.factory

import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage
import jp.co.nec.lsm.accenture.request.factory.*

import test.common.util.db.*
import test.lsm.db.entity.*

class BisonTablesFactory {


	def  createPersonBio(String ip, String port, String sid, String user, String pass, String refId){
		PersonBiometricsEntity pb = new PersonBiometricsEntity();
		def sqlExecutor = new SqlExecutorFactory().create(ip, port, sid, user, pass)
		def sql = ("select * from PERSON_BIOMETRICS where REFERENCE_ID=  $refId")

		def dataList =  sqlExecutor.getSqlResult(sql)
                for(data in dataList){
			pb.bioId = data.biometrics_id;
			pb.refId = data.reference_id;
			pb.biometricDataLen = data.biometric_data_len;
		}
	return pb;
}
	
	def createSegment(String ip, String port, String sid, String user, String pass, String bioId){
		SegmentsEntity sg = new SegmentsEntity();
		def sqlExecutor = new SqlExecutorFactory().create(ip, port, sid, user, pass)
		def sql = ("select * from SEGMENTS where BIO_ID_START <= $bioId and BIO_ID_END >= $bioId")
		
		def dataList =  sqlExecutor.getSqlResult(sql)
		for(data in dataList){
			sg.segId = data.segment_id;
			sg.bioIdStart = data.bio_id_start;
			sg.bioIdEnd = data.bio_id_end;
			sg.binaryLenCompacted = data.binary_length_compacted;
			sg.recCount = data.record_count;
			sg.ver = data.version;
			sg.generation = data.generation;
			sg.binaryLenUncompacted = data.binary_length_uncompacted;
		}
	return sg;
}
	
	def createSegVerDetail(String ip, String port, String sid, String user, String pass, String bioId){
		SegmentVersionDetailEntity svd = new SegmentVersionDetailEntity();
		def sqlExecutor = new SqlExecutorFactory().create(ip, port, sid, user, pass)
		def sql = ("select * from SEGMENT_VERSION_DETAIL where BIO_ID_START <= $bioId and BIO_ID_END >= $bioId" )
		
		def dataList =  sqlExecutor.getSqlResult(sql)
		for(data in dataList){
			svd.segId = data.segment_id
			svd.ver = data.version
			svd.bioIdStart = data.bio_id_start
			svd.bioIdEnd = data.bio_id_end
			svd.recCount = data.record_count
			svd.changeType = data.change_type
			svd.refId = data.reference_id
		}
		return svd;
	}
	
	def createSegVerDetail(String ip, String port, String sid, String user, String pass, String segId, String ver){
		SegmentVersionDetailEntity svd = new SegmentVersionDetailEntity();
		def sqlExecutor = new SqlExecutorFactory().create(ip, port, sid, user, pass)
		def sql = ("select * from SEGMENT_VERSION_DETAIL where SEGMENT_ID =  $segId and VERSION = $ver ")
                def dataList =  sqlExecutor.getSqlResult(sql)
                for(data in dataList){
                        svd.segId = data.segment_id
                        svd.ver = data.version
                        svd.bioIdStart = data.bio_id_start
                        svd.bioIdEnd = data.bio_id_end
                        svd.recCount = data.record_count
                        svd.changeType = data.change_type
                        svd.refId = data.reference_id
                }
		return svd;
	}

	def createSvdRegVersion(String ip, String port, String sid, String user, String pass, String bioId){
		SegmentVersionDetailEntity svd = new SegmentVersionDetailEntity();
		def sqlExecutor = new SqlExecutorFactory().create(ip,port,sid,user,pass)
		def sql = ("select * from SEGMENT_VERSION_DETAIL where BIO_ID_START <= $bioId and BIO_ID_END >= $bioId")
		def dataList = sqlExecutor.getSqlResult(sql)
		for(data in dataList){
			svd.segId = data.segment_id
                        svd.ver = data.version
                        svd.bioIdStart = data.bio_id_start
                        svd.bioIdEnd = data.bio_id_end
                        svd.recCount = data.record_count
                        svd.changeType = data.change_type
                        svd.refId = data.reference_id
		}
		return svd;
	}
	

    def getDataList(String ip, String port, String sid, String user, String pass, String sql ){
        def sqlExecutor = new SqlExecutorFactory().create(ip, port, sid, user, pass)
        return sqlExecutor.getSqlResult(sql)
	}

}


