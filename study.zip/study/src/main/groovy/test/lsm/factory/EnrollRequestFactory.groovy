package test.lsm.factory

import jp.co.nec.lsm.tme.protocolbuffer.EnrollRequestProto.EnrollRequest;
import jp.co.nec.lsm.tme.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.transformer.mock.factory.enrl.*;
import jp.co.nec.lsm.proto.common.CommonProto.Gender;

import test.common.util.db.*

class EnrollRequestFactory{

	def EnrollRequest create(long batchJobId, ArrayList dataList){
		println("TLJ size : " + dataList.size());	// debug
		EnrollRequest.Builder enrollRequestBuilder = EnrollRequest.newBuilder();
		enrollRequestBuilder.setBatchJobId(batchJobId);
		enrollRequestBuilder.setType(BatchType.ENROLL);
		addEnrollJobs(enrollRequestBuilder, dataList)
		return enrollRequestBuilder.build();
	}

	def EnrollRequest createRefIdUuid(batchJobId, ArrayList dataList){
		println("TLJ size : " + dataList.size());	// debug
		EnrollRequest.Builder enrollRequestBuilder = EnrollRequest.newBuilder();
		enrollRequestBuilder.setBatchJobId(batchJobId);
		enrollRequestBuilder.setType(BatchType.ENROLL);
		addEnrollJobsRefIdUuid(enrollRequestBuilder, dataList)
		return enrollRequestBuilder.build();
	}

	def void addEnrollJobs(EnrollRequest.Builder enrollRequestBuilder, ArrayList dataList){
		Gender[] genders = [ Gender.Male, Gender.Female, Gender.Unknown ];
		for(data in dataList){
			def number = data.data_id as int
			def gender = genders[number%3]
			def yob = generateYob(number)
			def region = number % 100
			new EnrollJobFactory().create(
					 enrollRequestBuilder, data.reference_id, data.reference_id, data.reference_url,
					 new ExtractInputPayloadFactory().create(gender, yob, region)
			);
		}
	}

	def void addEnrollJobsRefIdUuid(EnrollRequest.Builder enrollRequestBuilder, ArrayList dataList){
		Gender[] genders = [ Gender.Male, Gender.Female, Gender.Unknown ];
		for(data in dataList){
			def reference_id = UUID.randomUUID() as String
			def number = data.data_id as int
			def gender = genders[number%3]
			def yob = generateYob(number)
			def region = number % 100
			new EnrollJobFactory().create(
					 enrollRequestBuilder, reference_id, reference_id, data.reference_url,
					 new ExtractInputPayloadFactory().create(gender, yob, region)
			);
		}
	}
	
	def int generateYob(int number){
		return number % 111 + 1900
	}
}
		

