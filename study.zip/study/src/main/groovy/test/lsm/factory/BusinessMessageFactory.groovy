package test.lsm.factory

import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage
import com.nec.everest.proto.protobuf.BusinessMessage.E_REQUESET_TYPE
import jp.co.nec.lsm.accenture.request.factory.*

import test.common.util.db.*

class BusinessMessageFactory {

    def List<CPBBusinessMessage> createListOfIdentifyById(String ip, String port, String sid, String user, String pass, String sql, 
															String loc, String fpir){
        def dataList = getDataList(ip, port, sid, user, pass, sql)
		def List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>()
        for(data in dataList){
			businessMessageList.add(
				 createIdentifyById(data.reference_id, loc, fpir))
        }
		return businessMessageList
    }

    def List<CPBBusinessMessage> createListOfIdentifyByUrl(String ip, String port, String sid, String user, String pass, String sql, 
															String loc, String fpir){
        def dataList = getDataList(ip, port, sid, user, pass, sql)
		def List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>()
        for(data in dataList){
			businessMessageList.add(
				 createIdentifyByUrl(data.reference_url, data.check_sum, loc, fpir))
        }
		return businessMessageList
    }

    def List<CPBBusinessMessage> createListOfIdentifyById(String ip, String port, String sid, String user, String pass, String sql, 
															String loc, String fpir, String requestId){
        def dataList = getDataList(ip, port, sid, user, pass, sql)
		def List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>()
        for(data in dataList){
			businessMessageList.add(
				 createIdentifyById(data.reference_id, loc, fpir, requestId))
        }
		return businessMessageList
    }
    def List<CPBBusinessMessage> createListOfIdentifyByUrl(String ip, String port, String sid, String user, String pass, String sql, 
												String loc, String fpir, String requestId, E_REQUESET_TYPE requestType){
        def dataList = getDataList(ip, port, sid, user, pass, sql)
		def List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>()
        for(data in dataList){
			businessMessageList.add(
				 createIdentifyByUrl(data.reference_url, data.check_sum, loc, fpir, requestId, requestType))
        }
		return businessMessageList
    }
    def List<CPBBusinessMessage> createListOfIdentifyByIdWithoutFpir(String ip, String port, String sid, String user, String pass, String sql, 
															String loc){
        def dataList = getDataList(ip, port, sid, user, pass, sql)
		def List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>()
        for(data in dataList){
			businessMessageList.add(
				 createIdentifyByIdWithoutFpir(data.reference_id, loc))
        }
		return businessMessageList
    }

    def getDataList(String ip, String port, String sid, String user, String pass, String sql ){
        def sqlExecutor = new SqlExecutorFactory().create(ip, port, sid, user, pass)
        return sqlExecutor.getSqlResult(sql)
	}

	def createIdentifyById(String referenceId, String loc, String fpir){
		return CPBBusinessMessageFactory.createForIdentifyById(referenceId, loc as int, fpir as int)
	}

	def createIdentifyByUrl(String referenceUrl, String checkSum, String loc, String fpir){
		return CPBBusinessMessageFactory.createForIdentifyByUrl(referenceUrl, checkSum, loc as int, fpir as int)
	}
	def createIdentifyById(String referenceId, String loc, String fpir, requestId){
		return CPBBusinessMessageFactory.createForIdentifyById(referenceId, loc as int, fpir as int, requestId)
	}
	def createIdentifyByUrl(String referenceUrl, String checkSum, String loc, String fpir, requestId, requestType){
		return CPBBusinessMessageFactory.createForIdentifyByUrl(referenceUrl, checkSum, loc as int, fpir as int, requestId, requestType)
	}
	def createIdentifyByIdWithoutFpir(String referenceId, String loc){
		return CPBBusinessMessageFactory.createForIdentifyByIdWithoutFpir(referenceId, loc as int)
	}
}

