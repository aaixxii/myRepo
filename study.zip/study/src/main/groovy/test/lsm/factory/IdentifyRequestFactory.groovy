package test.lsm.factory

import jp.co.nec.lsm.tmi.protocolbuffer.IdentifyRequestProto.IdentifyRequest
import jp.co.nec.lsm.tmi.protocolbuffer.IdentifyRequestProto.IdentifyRequest.Type
import jp.co.nec.lsm.tmi.protocolbuffer.IdentifyRequestProto.IdentifyRequest.SearchJobs
import jp.co.nec.lsm.transformer.mock.factory.inq.SearchJobFactory


class IdentifyRequestFactory{

	def IdentifyRequest create(long batchJobId, int maxCandidates, int fpir, ArrayList dataList){
		IdentifyRequest.Builder identifyRequestBuilder = IdentifyRequest.newBuilder();
		identifyRequestBuilder.setBatchJobId(batchJobId)
		identifyRequestBuilder.setType(Type.identify)
		identifyRequestBuilder.setSearchJobs(addSearchJobs(maxCandidates, fpir, dataList))
		return identifyRequestBuilder.build()
	}

	def IdentifyRequest create(long batchJobId, int maxCandidates, int fpir, ArrayList dataList, int loopCnt){
		IdentifyRequest.Builder identifyRequestBuilder = IdentifyRequest.newBuilder();
		identifyRequestBuilder.setBatchJobId(batchJobId)
		identifyRequestBuilder.setType(Type.identify)
		identifyRequestBuilder.setSearchJobs(addSearchJobs(maxCandidates, fpir, dataList, loopCnt))
		return identifyRequestBuilder.build()
	}

	def addSearchJobs(int maxCandidates, int fpir, ArrayList dataList){
		def SearchJobs.Builder searchJobsBuilder = SearchJobs.newBuilder()
		for(data in dataList){
			new SearchJobFactory().create(searchJobsBuilder, data.reference_id, data.reference_id, "", maxCandidates, fpir);
		}
		return searchJobsBuilder.build()
	}

	def addSearchJobs(int maxCandidates, int fpir, ArrayList dataList, int loopCnt){
		def SearchJobs.Builder searchJobsBuilder = SearchJobs.newBuilder()
		for(i in 1..loopCnt){
			for(data in dataList){
				new SearchJobFactory().create(searchJobsBuilder, data.reference_id, data.reference_id, "", maxCandidates, fpir);
			}
		}
		return searchJobsBuilder.build()
	}
}
		

