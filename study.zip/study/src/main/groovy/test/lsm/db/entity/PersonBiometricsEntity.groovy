package test.lsm.db.entity

public class PersonBiometricsEntity {
	String bioId
	String refId
	int biometricDataLen

}
