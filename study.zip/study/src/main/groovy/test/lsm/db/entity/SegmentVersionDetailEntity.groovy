package test.lsm.db.entity


public class SegmentVersionDetailEntity {
	String segId
    	int ver
	String bioIdStart
	String bioIdEnd
    	int recCount
    	String changeType
    	String refId
}
