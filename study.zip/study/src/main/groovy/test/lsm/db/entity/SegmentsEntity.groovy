package test.lsm.db.entity


public class SegmentsEntity {	
	String segId
	String bioIdStart
	String bioIdEnd
	int binaryLenCompacted
    	int recCount
    	int ver
    	String generation
    	int binaryLenUncompacted
}
