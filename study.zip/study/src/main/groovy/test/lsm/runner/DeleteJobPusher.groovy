package test.lsm.runner

import jp.co.nec.lsm.util.HttpRequestSender
import jp.co.nec.lsm.tm.request.factory.DeleteRequestFactory
import jp.co.nec.lsm.tm.protocolbuffer.deletion.DeleteRequestProto.DeleteRequest
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType

import com.nec.everest.proto.protobuf.BusinessMessage.E_REQUESET_TYPE

import test.common.util.db.*

class DeleteJobPusher {

    List<String> enrollmentIdList = new ArrayList<String>()

	def void setDataList(String ip, String port, String sid, String user, String pass, String sql){
		def sqlExecutor = new SqlExecutorFactory().create(ip, port, sid, user, pass)
		def dataList = sqlExecutor.getSqlResult(sql)
		for(data in dataList){
       		     	enrollmentIdList.add(data.reference_id)
		}
		createData(enrollmentIdList)
	}

	def createDeleteRequest(long batchJobId){
		return new DeleteRequestFactory().create(batchJobId, enrollmentIdList)
	}

	def createDeleteRequestSpecifiedAllParam(long batchJobId, BatchType batchType, String requestId, E_REQUESET_TYPE requestType){
		return new DeleteRequestFactory().createSpecifiedAllParam(batchJobId, enrollmentIdList, batchType, requestId, requestType)
	}

	def pushJob(String url, long batchJobId){
		def deleteRequest = createDeleteRequest(batchJobId)
		return HttpRequestSender.send(url, deleteRequest.toByteArray())
	}

	def pushJobSpecifiedAllParam(String url, long batchJobId, BatchType batchType, String requestId, E_REQUESET_TYPE requestType){
		def deleteRequest = createDeleteRequestSpecifiedAllParam(batchJobId, batchType, requestId, requestType)
		return HttpRequestSender.send(url, deleteRequest.toByteArray())
	}

	def createData(enrollmentIdList){
		return enrollmentIdList
	}
}
