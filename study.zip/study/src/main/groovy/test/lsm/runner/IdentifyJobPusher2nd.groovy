package test.lsm.runner

import jp.co.nec.lsm.util.HttpRequestSender
import jp.co.nec.lsm.tm.request.factory.IdentifyRequestFactory
import jp.co.nec.lsm.tm.protocolbuffer.identify.IdentifyRequestProto.IdentifyRequest
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType
import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage
import com.nec.everest.proto.protobuf.BusinessMessage.E_REQUESET_TYPE

import test.common.util.db.*

class IdentifyJobPusher2nd{

    String refId = "referenceId"
    String loc = "loc"
    String fpir = "fpir"
	String filePath = "filePath"
	String checkSum = "checkSum"

    ArrayList<HashMap> dataMapList = new ArrayList<HashMap>()

	def void setDataList(String ip, String port, String sid, String user, String pass, String sql, String loc, String fpir){
    	dataMapList = new ArrayList<HashMap>()
		def sqlExecutor = new SqlExecutorFactory().create(ip, port, sid, user, pass)
		def dataList = sqlExecutor.getSqlResult(sql)
		for(data in dataList){
			def dataMap = new HashMap()
            dataMap[this.refId] = data.reference_id
			setImageInfo(dataMap, data)
            dataMap[this.loc] = loc
            dataMap[this.fpir] = fpir
            dataMapList.add(dataMap)
        }
	}

	def void setDataListWithoutEnrollmentId(String ip, String port, String sid, String user, String pass, String sql, String loc, String fpir){
		def sqlExecutor = new SqlExecutorFactory().create(ip, port, sid, user, pass)
		def dataList = sqlExecutor.getSqlResult(sql)
		for(data in dataList){
			def dataMap = new HashMap()
			setImageInfo(dataMap, data)
            dataMap[this.loc] = loc
            dataMap[this.fpir] = fpir
            dataMapList.add(dataMap)
        }
	}

	def void setDataListWithoutFPIR(String ip, String port, String sid, String user, String pass, String sql, String loc){
		def sqlExecutor = new SqlExecutorFactory().create(ip, port, sid, user, pass)
		def dataList = sqlExecutor.getSqlResult(sql)
		for(data in dataList){
			def dataMap = new HashMap()
            dataMap[this.refId] = data.reference_id
			setImageInfo(dataMap, data)
            dataMap[this.loc] = loc
            dataMapList.add(dataMap)
        }
	}

	def void setDataListWithoutMaxResults(String ip, String port, String sid, String user, String pass, String sql, String fpir){
		def sqlExecutor = new SqlExecutorFactory().create(ip, port, sid, user, pass)
		def dataList = sqlExecutor.getSqlResult(sql)
		for(data in dataList){
			def dataMap = new HashMap()
            dataMap[this.refId] = data.reference_id
			setImageInfo(dataMap, data)
            dataMap[this.fpir] = fpir
            dataMapList.add(dataMap)
        }
	}

	def void setImageInfo(dataMap, data){
			try{
            	dataMap[this.filePath] = data.reference_url
            	dataMap[this.checkSum] = data.check_sum
			}catch(Exception e){
				//println "WARN : reference_url or check_sum is nothing"
			}
	}

	def void setDataList(String ip, String port, String sid, String user, String pass, String sql, String loc, String fpir, int loopCnt){
		def sqlExecutor = new SqlExecutorFactory().create(ip, port, sid, user, pass)
		def dataList = sqlExecutor.getSqlResult(sql)
		for(int i = 0 ; i < loopCnt; i++){
			for(data in dataList){
				def dataMap = new HashMap()
				dataMap[this.refId] = data.reference_id
				setImageInfo(dataMap, data)
				dataMap[this.loc] = loc
				dataMap[this.fpir] = fpir
				dataMapList.add(dataMap)
			}
		}
	}


	def createIdentifyRequest(long batchJobId){
		return new IdentifyRequestFactory().create(batchJobId, dataMapList)
	}

	def createIdentifyRequestSpecifiedAllParam(long batchJobId, BatchType batchType, String requestId, E_REQUESET_TYPE requestType){
		return new IdentifyRequestFactory().createSpecifiedAllParam(batchJobId, dataMapList, batchType, requestId, requestType)
	}

	def createIdentifyRequestSpecifiedTypeAndRequestId(long batchJobId, BatchType type, String requestId){
		return new IdentifyRequestFactory().create(batchJobId, dataMapList, type, requestId)
	}

	def createIdentifyRequestWithoutEnrollmentId(long batchJobId){
		return new IdentifyRequestFactory().createWithoutEnrollmentId(batchJobId, dataMapList)
	}


	def createIdentifyRequestWithoutFPIR(long batchJobId){
		return new IdentifyRequestFactory().createWithoutFpir(batchJobId, dataMapList)
	}

	def createIdentifyRequestWithoutMaxResults(long batchJobId){
		return new IdentifyRequestFactory().createWithoutMaxResults(batchJobId, dataMapList)
	}

	def createIdentifyByUrlRequest(long batchJobId){
		return new IdentifyRequestFactory().createByUrl(batchJobId, dataMapList)
	}

        def createIdentifyByUrlRequestWithEnrollmentId(long batchJobId){
                return new IdentifyRequestFactory().createByUrlWithEnrollmentId(batchJobId, dataMapList)
        }


	def createIdentifyByUrlRequestSpecifiedAllParam(long batchJobId, BatchType batchType, String requestId, E_REQUESET_TYPE requestType){
		return new IdentifyRequestFactory().createByUrlSpecifiedAllParam(batchJobId, dataMapList, batchType, requestId, requestType)
	}

	def createIdentifyByUrlRequestSpecifiedAllParamExeptCheckSum(
			long batchJobId, BatchType batchType, String requestId, E_REQUESET_TYPE requestType){
		return new IdentifyRequestFactory().
			createByUrlSpecifiedAllParamWithoutCheckSum(batchJobId, dataMapList, batchType, requestId, requestType)
	}

	def createIdentifyRequestUsedByBusinessMessgList(int batchJobId, List<CPBBusinessMessage> businessMessgList){
		return new IdentifyRequestFactory().createUsedByBusinessMessgList(batchJobId, businessMessgList)
	}

	def pushJob(String url, long batchJobId){
		def identifyRequest = createIdentifyRequest(batchJobId)
		return HttpRequestSender.send(url, identifyRequest.toByteArray())
	}

	def pushJobUsedByBusinessMessgList(String url, int batchJobId, List<CPBBusinessMessage> businessMessgList){
		def identifyRequest = createIdentifyRequestUsedByBusinessMessgList(batchJobId, businessMessgList)
		return HttpRequestSender.send(url, identifyRequest.toByteArray())
	}

	def pushJob(String url, long batchJobId, BatchType type, String requestId){
		def identifyRequest = createIdentifyRequestSpecifiedTypeAndRequestId(batchJobId, type, requestId)
		return HttpRequestSender.send(url, identifyRequest.toByteArray())
	}

	def pushJobSpecifiedAllParam(String url, long batchJobId, BatchType batchType, String requestId, E_REQUESET_TYPE requestType){
		def identifyRequest = createIdentifyRequestSpecifiedAllParam(batchJobId, batchType, requestId, requestType)
		return HttpRequestSender.send(url, identifyRequest.toByteArray())
	}

	def pushJobByUrl(String url, long batchJobId){
		def identifyRequest = createIdentifyByUrlRequest(batchJobId)
		return HttpRequestSender.send(url, identifyRequest.toByteArray())
	}

        def pushJobByUrlWithEnrollmentId(String url, long batchJobId){
                def identifyRequest = createIdentifyByUrlRequestWithEnrollmentId(batchJobId)
                return HttpRequestSender.send(url, identifyRequest.toByteArray())
        }


	def pushJobByUrlSpecifiedAllParam(String url, long batchJobId, BatchType batchType, String requestId, E_REQUESET_TYPE requestType){
		def identifyRequest = createIdentifyByUrlRequestSpecifiedAllParam(batchJobId, batchType, requestId, requestType)
		return HttpRequestSender.send(url, identifyRequest.toByteArray())
	}

	def pushJobByUrlSpecifiedAllParamExeptCheckSum(String url, long batchJobId, BatchType batchType, String requestId, E_REQUESET_TYPE requestType){
		def identifyRequest = createIdentifyByUrlRequestSpecifiedAllParamExeptCheckSum(batchJobId, batchType, requestId, requestType)
		return HttpRequestSender.send(url, identifyRequest.toByteArray())
	}


	def pushJobWithoutEnrollmentId(String url, long batchJobId){
		def identifyRequest = createIdentifyRequestWithoutEnrollmentId(batchJobId)
		return HttpRequestSender.send(url, identifyRequest.toByteArray())
	}

	def pushJobWithoutFPIR(String url, long batchJobId){
		def identifyRequest = createIdentifyRequestWithoutFPIR(batchJobId)
		return HttpRequestSender.send(url, identifyRequest.toByteArray())
	}

	def pushJobWithoutMaxResults(String url, long batchJobId){
		def identifyRequest = createIdentifyRequestWithoutMaxResults(batchJobId)
		return HttpRequestSender.send(url, identifyRequest.toByteArray())
	}

	def pushJobFromDumpFile(String url, long batchJobId, String DumpFilePath){
		def file = new File(filePath)
		def serializedObj = file.getText()
		def identifyRequest = IdentifyRequest.parseFrom(serializedObj.getBytes())
		return HttpRequestSender.send(url, identifyRequest.toByteArray())
	}
}
