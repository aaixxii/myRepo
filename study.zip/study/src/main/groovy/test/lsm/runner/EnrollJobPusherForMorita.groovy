package test.lsm.runner

import jp.co.nec.lsm.tm.protocolbuffer.enroll.EnrollRequestProto.EnrollRequest;
import jp.co.nec.lsm.util.HttpRequestSender
import jp.co.nec.lsm.tm.request.factory.EnrollRequestFactory

import test.common.util.db.*

class EnrollJobPusherForMorita{

	String refId = "referenceId"
	String filePath = "filePath"
	String checkSum = "checkSum"
	ArrayList<HashMap> dataMapList = new ArrayList<HashMap>()

	def void setDataList(String ip, String port, String sid, String user, String pass, String sql){
		def sqlExecutor = new SqlExecutorFactory().create(ip, port, sid, user, pass)
		def ArrayList dataList = sqlExecutor.getSqlResult(sql)
		dataMapList = new ArrayList<HashMap>()
		for(data in dataList){
			def dataMap = new HashMap()
			dataMap[refId] = data.reference_id
			dataMap[filePath] = data.reference_url
			dataMap[checkSum] = data.check_sum
			dataMapList.add(dataMap)
		}
	}

	def createEnrollRequest(long batchJobId){
		return new EnrollRequestFactory().createBestQualityIrisFace(batchJobId, dataMapList)
	}

	def pushJob(String url, long batchJobId){
		EnrollRequest enrollRequest = createEnrollRequest(batchJobId)
		return HttpRequestSender.send(url, enrollRequest.toByteArray())
	}
}
