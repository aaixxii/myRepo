package test.lsm.runner

import jp.co.nec.lsm.transformer.mock.util.HttpRequestSender

import test.common.util.db.*
import test.lsm.factory.*

class EnrollJobPusher{

	ArrayList dataList

	def void setDataList(String ip, String port, String sid, String user, String pass, String sql){
		def sqlExecutor = new SqlExecutorFactory().create(ip, port, sid, user, pass)
		this.dataList = sqlExecutor.getSqlResult(sql)
	}

	def pushJob(String url, long batchJobId){
		def enrollRequest = new EnrollRequestFactory().create(batchJobId, dataList)
		return HttpRequestSender.send(url, enrollRequest.toByteArray())
	}

	def pushJobRefIdUuid(url, batchJobId){
		def enrollRequest = new EnrollRequestFactory().createRefIdUuid(batchJobId, dataList)
		return HttpRequestSender.send(url, enrollRequest.toByteArray())
	}
}
