package test.lsm.runner

import jp.co.nec.lsm.transformer.mock.util.HttpRequestSender

import test.common.util.db.*
import test.lsm.factory.*

class IdentifyJobPusher{

	ArrayList dataList

	def void setDataList(String ip, String port, String sid, String user, String pass, String sql){
		def sqlExecutor = new SqlExecutorFactory().create(ip, port, sid, user, pass)
		this.dataList = sqlExecutor.getSqlResult(sql)
	}

	def pushJob(String url, long batchJobId, int maxCandidates, int fpir){
		def identifyRequest = new IdentifyRequestFactory().create(batchJobId, maxCandidates, fpir, dataList)
		return HttpRequestSender.send(url, identifyRequest.toByteArray())
	}

	def pushJob(String url, long batchJobId, int maxCandidates, int fpir, int loopCnt){
		def identifyRequest = new IdentifyRequestFactory().create(batchJobId, maxCandidates, fpir, dataList, loopCnt)
		return HttpRequestSender.send(url, identifyRequest.toByteArray())
	}
}
