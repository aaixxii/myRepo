package test.lsm.runner

import jp.co.nec.lsm.transformer.mock.util.HttpRequestSender
import jp.co.nec.lsm.tm.request.factory.IdentifyRequestFactory
import jp.co.nec.lsm.tm.protocolbuffer.identify.IdentifyRequestProto.IdentifyRequest
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType
import com.acc.proto.protobuf.BusinessMessage.E_REQUESET_TYPE

import test.common.util.db.*

class IdentifyErrJobPusher extends IdentifyJobPusher2nd {

	def pushJobByUrlSpecifiedAllParamExeptMaxResults(
			String url, long batchJobId, BatchType batchType, String requestId, E_REQUESET_TYPE requestType){
		def identifyRequest = createIdentifyByUrlRequestSpecifiedAllParamExeptMaxResults(batchJobId, batchType, requestId, requestType)
		return HttpRequestSender.send(url, identifyRequest.toByteArray())
	}

	def pushJobByUrlSpecifiedAllParamExeptFPIR(
			String url, long batchJobId, BatchType batchType, String requestId, E_REQUESET_TYPE requestType){
		def identifyRequest = createIdentifyByUrlRequestSpecifiedAllParamExeptFPIR(batchJobId, batchType, requestId, requestType)
		return HttpRequestSender.send(url, identifyRequest.toByteArray())
	}

	def createIdentifyByUrlRequestSpecifiedAllParamExeptMaxResults(
			long batchJobId, BatchType batchType, String requestId, E_REQUESET_TYPE requestType){
		return new IdentifyRequestFactory().createByUrlSpecifiedAllParamWithoutMaxResults(
			batchJobId, dataMapList, batchType, requestId, requestType)
	}

	def createIdentifyByUrlRequestSpecifiedAllParamExeptFPIR(
			long batchJobId, BatchType batchType, String requestId, E_REQUESET_TYPE requestType){
		return new IdentifyRequestFactory().createByUrlSpecifiedAllParamWithoutFpir(
			batchJobId, dataMapList, batchType, requestId, requestType)
	}
}
