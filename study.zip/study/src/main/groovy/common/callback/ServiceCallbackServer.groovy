package common.callback

import java.net.ServerSocket
import java.net.Socket

class ServiceCallbackServer {
    def callbackPort
    def callbackMethod
    def serverSocket
    def socket
    def serverThread

    ServiceCallbackServer(callbackPort, callbackMethod) {
        this.callbackPort = callbackPort
        this.callbackMethod = callbackMethod
    }

    def start() {
        def readSocket = {
            socket, callbackMethod ->
            def reader
            def writer
            try {
                reader = new BufferedReader(new InputStreamReader(socket.getInputStream()))
                writer = new PrintWriter(socket.getOutputStream(), true)
                writer.println "HTTP/1.1 200 OK\r\n"

                String line
                StringBuffer sb = new StringBuffer()
                while ( (line = reader.readLine()) != null ) {	
                    sb.append(line)
                }
                String payload = sb.toString()

                callbackMethod(payload)

            } finally {
                if(reader != null) {
                    reader.close()
                }
                if(writer != null) {
                    writer.close()
                }
            }

        }

        this.serverThread = Thread.start{
            try {
                serverSocket = new ServerSocket(callbackPort)
                while(true) {
                    try {
                        socket = serverSocket.accept()
                        readSocket(socket, callbackMethod)

                    } finally {
                        if(socket != null) {
                            socket.close()
                        }
                    }
                }
            } catch (Exception e) {
                // FIXME
                e.printStackTrace()
            } finally {
                if(serverSocket != null) {
                    serverSocket.close()
                }
            }
        }

    }

    def stop() {
        if(serverSocket != null) {
            this.serverSocket.close()
        }

        if(socket != null) {
            this.socket.close()
        }

        this.serverThread.stop()
    }
}
