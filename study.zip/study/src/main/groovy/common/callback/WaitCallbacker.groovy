package common.callback

import jp.co.nec.nhm.soapui.util.HttpMessageReceiver
import org.apache.log4j.Logger

class WaitCallbacker{

	private static final Logger log = Logger.getInstance("WaitCallbacker")
	private static final int LOG_MAX_LEN = 300
	int callbackPort

	WaitCallbacker(){}
	
	WaitCallbacker(port){
		this.callbackPort = port as int
	}

	def waitCallback(){
		HttpMessageReceiver receiver = new HttpMessageReceiver(callbackPort)
		return receiver.receiveMessage()
	}
	
	public String waitCallbackXml(context){
		this.callbackPort = Integer.valueOf(context.expand('${callbackPort}'))
		HttpMessageReceiver receiver = new HttpMessageReceiver(callbackPort)
		String payload = receiver.receiveMessage()
		int index = payload.indexOf("<?xml version=")
		if(payload.length() < LOG_MAX_LEN){
			log.info(payload)
		}else{
			log.info(payload.substring(0, LOG_MAX_LEN))
		}
		
		String xmlString = payload.substring(index)
		return xmlString
	}
	
	public String waitCallbackXml(){
		HttpMessageReceiver receiver = new HttpMessageReceiver(callbackPort)
		String payload = receiver.receiveMessage()
		int index = payload.indexOf("<?xml version=")
		if(payload.length() < LOG_MAX_LEN){
			log.info(payload)
		}else{
			log.info(payload.substring(0, LOG_MAX_LEN))
		}
		
		String xmlString = payload.substring(index)
		return xmlString
	}

	private String waitCallbackMock(){
		String xmlStr = """
<ns2:search-job-result xmlns:ns2="urn:nec:aim" jobId="19351">
  <statistics>
    <readCount>1</readCount>
    <matchCount>1</matchCount>
  </statistics>
  <candidate hit="true">
    <externalId>reExtraction-multi_059-RDBTM</externalId>
    <fusion-score>9999</fusion-score>
    <candidate-template>
      <containerId>331</containerId>
      <eventId>1</eventId>
      <searchRequestIndex>0</searchRequestIndex>
      <fusionWeight>100</fusionWeight>
      <composite-score>9999</composite-score>
      <individual-score value="8833" fingerNumber="1" axis="A"/>
      <individual-score value="6567" fingerNumber="2" axis="A"/>
      <individual-score value="1271" fingerNumber="3" axis="A"/>
      <individual-score value="5143" fingerNumber="4" axis="A"/>
      <individual-score value="1532" fingerNumber="5" axis="A"/>
      <individual-score value="2795" fingerNumber="6" axis="A"/>
      <individual-score value="3245" fingerNumber="7" axis="A"/>
      <individual-score value="3353" fingerNumber="8" axis="A"/>
      <individual-score value="1307" fingerNumber="9" axis="A"/>
      <individual-score value="1055" fingerNumber="10" axis="A"/>
    </candidate-template>
  </candidate>
  <missAnalysis>
    <miss-analysis-enrolled-mate-ids/>
  </missAnalysis>
</ns2:search-job-result>
"""
		return xmlStr
	}
}
