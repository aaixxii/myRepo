package common.callback

import org.mortbay.jetty.Server

class ServiceCallbackJettyServer {
    def callbackPort
    def callbackMethod
    def server
    def serverThread

    ServiceCallbackJettyServer(callbackPort, callbackMethod) {
        this.callbackPort = callbackPort

        // FIXME set callbackMethod to servlet
        this.callbackMethod = callbackMethod
    }

    def start() {
        this.serverThread = Thread.start{
            server = new Server(callbackPort)
            server.start()
        }
    }

    def stop() {
        if(server != null) {
            server.stop()
        }

        if(serverThread != null) {
            this.serverThread.stop()
        }
    }
}
