package common.xml

class ConfigLoader {
    def static load(String path) {
        return _parse(path)
    }

    def static load(File configFile) {
        return _parse(configFile)
    }

    def static _parse(String path) { 
        def config = _parse(new File(path))
        return config             
    }

    def static _parse(File configFile) {
        def config = new ConfigSlurper().parse(configFile.toURL())
        return config
    }

}
