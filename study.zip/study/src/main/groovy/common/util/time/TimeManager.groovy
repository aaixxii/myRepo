package common.util.time

class TimeManager{
	def date

	def TimeManager(){
		this.date = new Date()
	}

	def addMinute(time, addMinute){
		use( [org.codehaus.groovy.runtime.TimeCategory] ){
			def now = new Date("2010/1/1 $time")
	 		return (now + addMinute.minute).format("HH:mm:ss")
		}
	}

	def getWeek(){
		def weekday=["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
		return weekday[new Date().day]
	}

	def Long calcDiffMSec(Date date) {
		return date.getTime() - this.date.getTime()
	}

	def Long calcDiffMSec(Date start, Date end) {
		return end.getTime() - start.getTime()
	}

	def static String getCurrentTimeStr() {
		return new Date().format("yyyy/MM/dd HH:mm:ss.SSS")
	}
}

