package common.util


class ConvertNistPos { 

	private ConvertNistPos(){}

	public static def convertNistRollPosToNistSlapPos(String nistImage){
		nistImage = nistImage.replace("pos=\'1\'", "pos=\'11\'")
		nistImage = nistImage.replace("pos=\'2\'", "pos=\'40\'")
		nistImage = nistImage.replace("pos=\'3\'", "pos=\'41\'")
		nistImage = nistImage.replace("pos=\'4\'", "pos=\'42\'")
		nistImage = nistImage.replace("pos=\'5\'", "pos=\'43\'")
		nistImage = nistImage.replace("pos=\'6\'", "pos=\'12\'")
		nistImage = nistImage.replace("pos=\'7\'", "pos=\'44\'")
		nistImage = nistImage.replace("pos=\'8\'", "pos=\'45\'")
		nistImage = nistImage.replace("pos=\'9\'", "pos=\'46\'")
		nistImage = nistImage.replace("pos=\'10\'", "pos=\'47\'")
		return nistImage
	}
}
