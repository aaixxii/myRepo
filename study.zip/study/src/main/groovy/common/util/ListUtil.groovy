package common.util

class ListUtil {

	public static void sortPrimitiveList(List list) {
		Collections.sort(list)
	}

	public static def getMax(List list) {
		sortPrimitiveList(list)
		return list[list.size()-1]
	}

	public static def getMin(List list) {
		sortPrimitiveList(list)
		return list[0]
	}

	public static double getSumDouble(List list) {
		double sum = 0.0
		for(val in list) {
			sum += val
		}
		return sum
	}

	public static int getSumInt(List list) {
		int sum = 0
		for(val in list) {
			sum += val
		}
		return sum
	}

	public static double getAvg(List list) {
		double sum = getSumDouble(list)
		return sum / list.size()
	}
}
