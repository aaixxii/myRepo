package common.util.http

import java.io.BufferedInputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;

import org.slf4j.Logger
import org.slf4j.LoggerFactory

class HttpRequestSender {
	
	private final static Logger log = LoggerFactory.getLogger(HttpRequestSender.class)
	private static final int SO_TIMEOUT = 60000
	
	public static HttpResponse send(String endpointURL, String reqStr) throws IOException {
		send(endpointURL, reqStr.getBytes())	
	}
	
	public static HttpResponse send(String endpointURL, byte[] serializedObject) throws IOException {
		HttpEntity entity = convertHttpEntity(serializedObject);
		HttpPost httpPost = new HttpPost(endpointURL);
		httpPost.setEntity(entity);
		DefaultHttpClient httpClient = new DefaultHttpClient();
		HttpParams params = httpClient.getParams();
		//HttpConnectionParams.setConnectionTimeout(params, 30000);
		HttpConnectionParams.setSoTimeout(params, SO_TIMEOUT);
		HttpResponse res = httpClient.execute(httpPost);
		httpClient.getConnectionManager().shutdown()
		return res
	}

	public static HttpEntity convertHttpEntity(byte[] serializedObject) {
		return new ByteArrayEntity(serializedObject);
	}

	public static void requestGetMessg(String path) throws IOException {
		URL url = new URL(path);
		HttpURLConnection http = (HttpURLConnection) url.openConnection();
		http.setRequestMethod("GET");
		http.connect();
		BufferedInputStream bis = new BufferedInputStream(http.getInputStream());
		bis.close();
	}
}

