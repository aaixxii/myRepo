package common.util

class FilePathListMaker {

    def static makeFileLists(dir, splitNum) {
        def list = []
        dir.eachFileRecurse{
            if(it.isFile()){
                    list << it
            }
        }
        return list.split(splitNum)
    }
}
