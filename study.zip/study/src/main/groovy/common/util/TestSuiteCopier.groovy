package common.util

class TestSuiteCopier {
	static String suiteName
	static final String END_TAG = "</con:testSuite>"

	public void copyTestSuite(String fromProjectPath, String toProjectPath, List<String> suiteNameList){
		String fromProject   = new File(fromProjectPath).getText()
		String toProject   = new File(toProjectPath).getText()
		
		Integer endIndex  = toProject.lastIndexOf(END_TAG)
		String  HEAD  = toProject.substring(0, endIndex + END_TAG.length())
		String  TAIL =  toProject.substring(endIndex + END_TAG.length())
		
		String copyString = ""		
		for (suiteName in suiteNameList){
			String startTag = "<con:testSuite name=\"${suiteName}\""
			Integer copyStartIndex = fromProject.indexOf(startTag)
			String tmp = fromProject.substring(copyStartIndex)
			Integer copyEndIndex = tmp.indexOf(END_TAG)
			copyString += tmp.substring(0, copyEndIndex + END_TAG.length())
		}
		String writeString = HEAD + copyString + TAIL
		new File(toProjectPath).write(writeString)
	}
}
