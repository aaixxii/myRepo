package common.util

import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

public class XmlPrinter {

	private final static int LINE_WIDTH = 65;
	private final static int INDENT = 2;

	public static String printer(String xml) {

		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance()
			DocumentBuilder db = dbf.newDocumentBuilder()
			InputSource is = new InputSource(new StringReader(xml))
			Document doc = db.parse(is)
			OutputFormat format = new OutputFormat(doc)
			format.setLineWidth(LINE_WIDTH)
			format.setOmitXMLDeclaration(false);
			format.setIndenting(true)
			format.setIndent(INDENT)
			Writer out = new StringWriter()
			XMLSerializer serializer = new XMLSerializer(out, format)
			serializer.serialize(doc)
			return out.toString()
		} catch (Exception e) {
			println "Error during XML printing... $e"
			throw new RuntimeException(e)
		}
	}

}

