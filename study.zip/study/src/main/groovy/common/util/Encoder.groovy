package common.util

import org.apache.commons.codec.binary.Base64

class Encoder{
	Encoder(){}
	
	public static String binaryToB64(byte[] bytes){
		def b64 = new Base64()
		return new String(b64.encode(bytes))
	}

	public static String binaryToB64(File file){
        return binaryToB64(file.readBytes())
	}

	public static String binaryToB64(String filePath){
		File file = new File(filePath)
		return binaryToB64(file)
	}

	public static stringToBinary(String str) {
		def b64 = new Base64()
		return b64.decode(str.getBytes())
	}
}
