package common.util

import common.os.linux.*

class TextFormatter{

	TextFormatter(){}

	def trimString(String str, String trimStr){
		def strList = new LinuxCommander().doShCommand("echo ${str} | sed 's/${trimStr}//g'")
		return chStrFromStrList(strList)
	}

	def trimString(File file, String trimStr){
		def strList = new LinuxCommander().doShCommand("sed 's/${trimStr}//g' ${file}")
		return chStrFromStrList(strList)
	}

	def trimString(File file, String startTrimStr, String endTrimStr){
		def str    = file.getText('UTF-8')
		def start  = str.indexOf(startTrimStr)
		def end    = str.lastIndexOf(endTrimStr)

		if(start == -1 || end == -1){
			return str
		}

		def tmp1   = str.substring(0, start)
		def tmp2   = str.substring(end+endTrimStr.size())
		return tmp1+tmp2
	}

	public static String trimString(String str, String headTrimStr, String nextStrOfTrimStr) {
		int headEnd = str.indexOf(headTrimStr)
		String headStr = str.substring(0, headEnd)
		int tailStart = str.indexOf(nextStrOfTrimStr)
		String tailStr = str.substring(tailStart)
		return headStr + tailStr
	}

	public static String deleteStr(String str, String startStr, String deleteStrHead, String nextStrOfDeleteStr) {
		String tailStr = ""
		int startIndex = str.indexOf(startStr)
		int headIndex = str.indexOf(deleteStrHead, startIndex+1)
		int tailIndex = str.indexOf(nextStrOfDeleteStr, startIndex+1)
		String headStr = str.substring(0, headIndex)
		if(tailIndex != -1){
			tailStr = str.substring(tailIndex)
		}
		return headStr + tailStr
	}

	public static String trimString(String str, int headRemoveIndex, int tailRemoveIndex) {
		String headStr = str.substring(0, headRemoveIndex)
		String tailStr = str.substring(tailRemoveIndex)
		return headStr + tailStr
	}

	def chStrFromStrList(strList){
		def resultStr = ""
		for(record in strList){
			resultStr += record
			resultStr += "\n"
		}
		return resultStr
	}
}
