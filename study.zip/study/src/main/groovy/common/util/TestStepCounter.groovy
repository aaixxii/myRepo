package common.util

class TestStepCounter{
	static String projectFileDir
	private static final String TYPE_CATEGORY = "type-category"
	private static final String BASIC = "Basic"
	private static final String EXTRACTION = "Extraction"
	private static final String FACE = "Face"
	private static final String IRIS = "Iris"
	private static final String NON_AUTO = "NonAuto"
	private static final String OST = "OST"
	private static final String SM = "SM"
	private static final String VX = "VX"
	private static final String VX_NON_AUTO = "VX-NonAuto"
	private static final String TOTAL = "Total"
	private static final String COUNT_TAG = "</con:testStep>"
	private static final List TYPE_LIST = [ BASIC, EXTRACTION, FACE, IRIS, NON_AUTO, OST, SM, VX, VX_NON_AUTO ]

	def TestStepCounter(String projectFileDirRoot, String aimVersion){
		this.projectFileDir = projectFileDirRoot + aimVersion + "/" + TYPE_CATEGORY + "/"
	}

	public int getTestStepCount(String projectFilePath ){
		File projectFile =  new File(projectFilePath)
		return projectFile.getText().count(COUNT_TAG)
	}

	public List getFileListInDirectory(String dir){
		List fileNameList = []
		File[] fileList = new File(dir).listFiles()
		if(fileList != null && fileList.size() != 0){
			for(file in fileList){
				if(file.getName().contains(".xml")){
					fileNameList << file.getName()
				}
			}
		}
		return fileNameList
	}

	public calculateTestStepCount(){
		Integer totalTestStepCount = 0
		Map<String,Integer> typeTestStepCountMap = new HashMap<String,Integer>()
		for (type in TYPE_LIST){
			Integer typeTestStepCount = 0
			List fileNameList = getFileListInDirectory(projectFileDir + type)
			for ( fileName in fileNameList ){
				int testStepCount = getTestStepCount(projectFileDir + type + "/" + fileName)
				typeTestStepCount += testStepCount
			}
			totalTestStepCount += typeTestStepCount
			typeTestStepCountMap.put(type,typeTestStepCount)
		}
		typeTestStepCountMap.put(TOTAL, totalTestStepCount)
		return typeTestStepCountMap
	}

	public fileOutPutTestStepCount(String fileName){
		new File(projectFileDir + fileName).write(sortTestStepCount(calculateTestStepCount()))
	}
	
	public fileOutPutTestStepCount(){
		String fileName = "testStepCount.txt"
		fileOutPutTestStepCount(fileName)
	}

	public consoleOutPutTestStepCount(){
		println sortTestStepCount(calculateTestStepCount())
	}

	public sortTestStepCount(Map<String,Integer> typeTestStepCountMap){
		String outputCharacter = "[ "
		for (type in TYPE_LIST){
			String value =  typeTestStepCountMap.get(type)
			if(value != null){
				outputCharacter += "${type}:${value}"
			}
			outputCharacter += ", "
		}
		outputCharacter += "${TOTAL}:" + typeTestStepCountMap.get(TOTAL)
		return outputCharacter += " ]"
	}
}
