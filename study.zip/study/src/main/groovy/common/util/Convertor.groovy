package common.util


class Convertor { 

	private Convertor(){}

	public static def toZeroIfNull(def obj){
		if (obj == null){
            return 0
        }else{
            return obj
        }
	}

	public static def replaceValIfNull(def obj, def replaceVal){
		if (obj == null){
            return replaceVal
        }else{
            return obj
        }
	}
	
	public static def replaceValIfNullOrEmpty(def obj, def replaceVal){
		if (obj == null || obj.isEmpty()){
            return replaceVal
        }else{
            return obj
        }
	}

	public static def convertRollPosToSlapPos(def rollPos){
        rollPos = rollPos as int
        int slapPos = 0
        if( rollPos == 1) {
            slapPos = 11
        } else if( rollPos == 6) {
            slapPos = 12
        } else if( 2 <= rollPos && rollPos <= 5 ) {
            slapPos = 38 + rollPos
        } else if( 7 <= rollPos && rollPos <= 10) {
            slapPos = 37 + rollPos
        } else {
			slapPos = rollPos
		}
        return slapPos
    }

	public static def convertSlapPosToRollPos(def slapPos){
        slapPos = slapPos as int
        int rollPos = 0
        if( slapPos == 11) {
            rollPos = 1
        } else if( slapPos == 12) {
            rollPos = 6
        } else if( 40 <= slapPos && slapPos <= 43 ) {
            rollPos = slapPos - 38
        } else if( 44 <= slapPos && slapPos <= 47) {
            rollPos = slapPos - 37
        } else{
			rollPos = slapPos
		}
        return rollPos
    }
    public static def toOneIfEmpty(def obj){
        if (obj == ""){
            return 1
        }else{
            return obj
        }
    }

}
