package common.util

class UString {
	public static boolean hasValue(String str){
		if(str == null || str.isEmpty()){
			return false
		}else{
			return true
		}
	}
}
