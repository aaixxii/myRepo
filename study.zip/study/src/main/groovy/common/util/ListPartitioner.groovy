package common.util

class ListPartitioner {

    def static partition(list, size) {
        def result = []
        def max = list.size() - 1
        def regions = (0..max).step(size)

        regions.each { start ->
            end =  Math.min(start + size - 1, max)
            result << list[start..end]
        }

        return result
    }

}
