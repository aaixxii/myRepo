package common.util

class MapController {

	public static void batchPut(Map map, int start, int end, def val){
		for(i in start..end){
			map.put(i, val)
		}
	}
	
	public static void batchPutAsConvKeyString(Map map, int start, int end, def val){
		for(i in start..end){
			map.put(i as String, val)
		}
	}
}
