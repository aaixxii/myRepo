package common.util

class ResultMapper{
	boolean result
	def value

	def ResultMapper(boolean result, value){
		this.result = result
		this.value = value
	}
}
