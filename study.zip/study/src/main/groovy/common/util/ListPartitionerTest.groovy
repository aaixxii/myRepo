package common.util
import groovy.util.GroovyTestCase

class ListPartitionerTest extends GroovyTestCase {

    def testPartition() {
        def list = [1,2,3,4,5,6,]
        def resultList = ListPartitioner.partition(list, 2)
        println list
        assert true
    }

}
