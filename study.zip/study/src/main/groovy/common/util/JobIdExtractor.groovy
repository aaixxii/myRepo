package common.util

class JobIdExtractor {

    static def extractJobIdFromSearchResponse(searchPayloadResponse) {
        def xml = _extractXML(searchPayloadResponse)
        def xmlRoot = _parseXML(xml)
	def jobId = xmlRoot.attribute("jobId")
	jobId = jobId as long
        return jobId
    }

    static def _extractXML(payloadResponse) {
        int xmlIndex = payloadResponse.indexOf("<?xml version=")
        String xmlString = payloadResponse.substring(xmlIndex)
        return xmlString
    }

    static def _parseXML(xml) {
        def xmlRoot = new XmlParser().parseText(xml)
        return xmlRoot
    }

}
