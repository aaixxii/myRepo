package common.web.server

import org.mortbay.jetty.servlet.*
import javax.servlet.*
import javax.servlet.http.*
import org.mortbay.jetty.*
import org.mortbay.thread.BoundedThreadPool

class SimpleHttpServer {
	def port
	def server
	def serverThread
	def Map<String, Servlet> servletMap

	public SimpleHttpServer(int port, Map<String, Servlet> pathToServletMap) {
		this.port = port
		this.servletMap = pathToServletMap;        
    }

	def start() {
		this.serverThread = Thread.start{
			server = setupServer(port)
			server.start()
		}
	}

	def stop() {
		if(server != null) {
			server.stop()
		}

		if(serverThread != null) {
			this.serverThread.stop()
		}
	}


	def setupServer(port) {
		def server = new Server(port)
		BoundedThreadPool pool = new BoundedThreadPool();
		pool.setMinThreads(700);
		pool.setMaxThreads(700);
		server.setThreadPool(pool);
		def contextRoot = new Context(server, "/");
		registerAllServlets(contextRoot);
		server.setHandler(contextRoot);
		return server;
	}

	def registerAllServlets(context) {
	
		for(Map.Entry<String, String> e : this.servletMap.entrySet()) {
			String path = e.getKey()
			Servlet servlet = e.getValue()
			registerServlet(context, path, servlet)
		}
	}

	def registerServlet(contextRoot, path, servlet ) {
		def servletHolder = createServletHolder(servlet);
		contextRoot.addServlet(servletHolder, path); 
	}

	def createServletHolder(servlet) {
		def servletHolder = new ServletHolder(servlet);
		servletHolder.setInitParameter("bufferSize", Integer.toString(1024*6,10));
		return servletHolder
	}
}

