package common.web.servlet

import javax.servlet.*
import javax.servlet.http.*



class SimpleServlet extends HttpServlet {

	def void doPost(HttpServletRequest req, HttpServletResponse res) {
		try {
			res.setStatus(200)
			res.setContentType("text/plain")
		}catch (Throwable e){
			res.sendError(400, "receive error")
			res.setContentType("text/plain")
		}
	}

	def void doGet(HttpServletRequest req, HttpServletResponse res) {
		doPost(req, res)
	}
}
