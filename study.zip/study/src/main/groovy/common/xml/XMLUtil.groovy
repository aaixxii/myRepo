package common.xml

import javax.xml.xpath.XPath
import javax.xml.xpath.XPathFactory
import javax.xml.parsers.DocumentBuilderFactory

class XMLUtil {

    def static parseXML(String xml) {
        def factory = DocumentBuilderFactory.newInstance()
        factory.setNamespaceAware(true);
        def builder = factory.newDocumentBuilder()
        def doc =  builder.parse(new ByteArrayInputStream(xml.bytes)).documentElement
        if(doc == null) {
            throw new Exception("oops document isn't created")
        }
        return doc
    }

	def static String getElementValue(String path, String xmlString){
		def document = getXmlDocument(xmlString)
		def XPathFactory factory = XPathFactory.newInstance();
		XPath xpath = factory.newXPath();
		return xpath.evaluate(path, document)
	}

	def static getXmlDocument(String xmlString){
		def builder = DocumentBuilderFactory.newInstance().newDocumentBuilder()
		def inputStream = new ByteArrayInputStream(xmlString.bytes)
		return builder.parse(inputStream)
	}
}
