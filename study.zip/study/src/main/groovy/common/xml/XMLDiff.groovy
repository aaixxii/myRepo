package common.xml

import org.custommonkey.xmlunit.XMLUnit
import org.custommonkey.xmlunit.Diff
import org.custommonkey.xmlunit.DetailedDiff
import org.custommonkey.xmlunit.Difference

class XMLDiff {

    def static diff(String expectedXML, String actualXML) {
        DetailedDiff detailedDiff = new DetailedDiff(new Diff(expectedXML, actualXML));
		return detailedDiff.allDifferences
/*
        List<Difference> differences = detailedDiff.allDifferences

        def differenceMap = [:]
        for (difference in differences) {
            def nodeDetail = difference.getControlNodeDetail()
            def node = nodeDetail.getNode()
            differenceMap[node.getNodeName()] = node.getNodeValue()
        }
        return differenceMap
*/
    }
}
