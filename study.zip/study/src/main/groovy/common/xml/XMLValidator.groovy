package common.xml

import org.custommonkey.xmlunit.Validator
import org.custommonkey.xmlunit.XMLUnit

class XMLValidator {
    String xml
    Validator mValidator

    XMLValidator(String xml, File schemaFile) {
        this.xml = xml
        mValidator = _createValidator(xml, schemaFile)
    }

    def _createValidator(xml, schemaFile) {
        Validator validator = new Validator(xml)
        validator.useXMLSchema(true)
        validator.setJAXP12SchemaSource(schemaFile)
        return validator
    }

    def isXMLValid() {
        return mValidator.isValid()
    }

    def String getError() {
        return mValidator.toString()
    }
}
