package common.xml

class XMLAssertResultReporter {

    def reportAssert(List<XMLAssertResult> results) {
        results.each { result ->
            message = "Actual value:" + ${result}.actualValue +  " Expected Value:" + ${result}.expectedValue + " Xpath:" + ${result}.xpath
            assert result.result, message
        }
    }

    def reportPrint(List<XMLAssertResult> results ) {

        results.each { result ->
            println result.result
            println result.actualValue
            println result.expectedValue
            println result.xpath
        }
    }

}
