package common.xml

class XMLObject{
	def xmlRoot

	def XMLObject(xmlString){
		this.xmlRoot = new XmlParser().parseText(xmlString)
	}
}
	
