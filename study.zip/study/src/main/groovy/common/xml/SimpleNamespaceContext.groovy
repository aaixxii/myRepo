package common.xml
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import javax.xml.XMLConstants;
import javax.xml.namespace.NamespaceContext;

class SimpleNamespaceContext implements NamespaceContext {
    Map<String,String> prefixToUri = new HashMap<String,String>()
    Map<String,String> uriToPrefix = new HashMap<String,String>()

    def void addMapping(String prefix, String uri) {
        prefixToUri.put(prefix,uri)
        uriToPrefix.put(uri,prefix)
    }

    def SimpleNamespaceContext() {
        addMapping(XMLConstants.XML_NS_PREFIX, XMLConstants.XML_NS_URI)
        addMapping(XMLConstants.XMLNS_ATTRIBUTE, XMLConstants.XMLNS_ATTRIBUTE_NS_URI)
    }

    def String getNamespaceURI(String prefix) {
        if (prefix == null) {
            throw new IllegalArgumentException()
        }

        String result = prefixToUri.get(prefix)
        return result!=null? result : XMLConstants.NULL_NS_URI;
    }

    def String getPrefix(String namespaceURI) {
        if (namespaceURI==null) {
            throw new IllegalArgumentException()
        }
        String result= uriToPrefix.get(namespaceURI)
        return result!=null? result : null;
    }

    def Iterator getPrefixes(String namespaceURI) {
        String prefix = getPrefix(namespaceURI)
        List<String> al = new ArrayList<String>()
        if ( prefix != null) {
            al.add(prefix)
        }
        return al.iterator()
    }
}
