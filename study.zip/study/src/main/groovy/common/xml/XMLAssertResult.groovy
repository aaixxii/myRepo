package common.xml

class XMLAssertResult {
    String xpath
    String expectedValue
    String actualValue
    boolean result

    XMLAssertResult(xpath, expectedValue, actualValue, result) {
        this.xpath = xpath
        this.expectedValue= expectedValue
        this.actualValue = actualValue
        this.result = result
    }

}
