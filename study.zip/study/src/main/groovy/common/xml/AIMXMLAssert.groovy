package common.xml

class AIMXMLAssert extends XMLAssert {
    def static String AIM_NAMESPACE_PREFIX="ns2" 
    def static String AIM_NAMESPACE_URI="urn:nec:aim"

    AIMXMLAssert(String xml) {
        super(xml)
        registerNamespace(AIM_NAMESPACE_PREFIX, AIM_NAMESPACE_URI)
    }

}
