package common.xml

import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.xpath.*

class XMLAssert {
    def doc
    def namespaceMap = [:]
   
    XMLAssert(String xml) {
        this.doc = XMLUtil.parseXML(xml)
    }

    def registerNamespace(String prefix, String namespaceURI) {
        namespaceMap[prefix] = namespaceURI 
    }

    def registerNamespacesTo(xpathEvaluator) {
        SimpleNamespaceContext namespaceContext =new SimpleNamespaceContext()
        for(namespace in namespaceMap) {
            namespaceContext.addMapping(namespace.key, namespace.value);
        }
        xpathEvaluator.setNamespaceContext(namespaceContext);
    }

    def List<XMLAssertResult> assertXML(xpathValueMap) {
        def results = []
        for (xpathValue in xpathValueMap) {
            def xpath = xpathValue.key
            def expectedValue = xpathValue.value
            def result = assertXPath(xpath, expectedValue)
            results.add(result)
        }
        return results
    }
    def assertValueExists(xpaths) {
        for (xpath in xpaths) {
            assertXPathValueExists(xpath)
        }
    }

    def assertXPathValueExists(String xpath) {
        def xpathEvaluator = XPathFactory.newInstance().newXPath()
        registerNamespacesTo(xpathEvaluator)
        def actual = xpathEvaluator.evaluate(xpath, this.doc, XPathConstants.STRING);
        if(actual == null) {
            return new XMLAssertResult(xpath, actual, false)
        }
        if(actual == "") {
            return new XMLAssertResult(xpath, actual, false)
        }
        return new XMLAssertResult(xpath, actual, true)
    }

    def assertXMLLoose(xpathValueMap) {
            def xmlAssertResult
        for (xpathValue in xpathValueMap) {
            def xpath = xpathValue.key
            def expectedValue = xpathValue.value
            xmlAssertResult = assertXPathLoose(xpath, expectedValue)
			if(xmlAssertResult.result == false){
				return xmlAssertResult
			}
        }
		return xmlAssertResult
    }


    def assertXPath(xpath, expected) {
        def nodeType = detectNodeType(xpath, expected)
        def xpathEvaluator = XPathFactory.newInstance().newXPath()
        registerNamespacesTo(xpathEvaluator)
        def actual = xpathEvaluator.evaluate(xpath, this.doc, nodeType);
        if(actual == null) {
            throw new Exception("actual value for ${xpath} is null.")
        }
        if(actual == "") {
            throw new Exception("actual value for ${xpath} is empty.")
        }
        def result = doAssert(xpath, expected, actual)
        return result
    }

    def assertXPathLoose(xpath, expected) {
        def nodeType = detectNodeType(xpath, expected)
        def xpathEvaluator = XPathFactory.newInstance().newXPath()
        registerNamespacesTo(xpathEvaluator)
        def actual = xpathEvaluator.evaluate(xpath, this.doc, nodeType);
        return doAssert(xpath, expected, actual)
    }

    def doAssert(xpath, expected, actual) {
        println "===================================="
        println "Expected is '${expected}'"
        println "Actual   is '${actual}' (at ${xpath})"

        def result = (expected == actual) ? true : false
        return new XMLAssertResult(xpath, expected, actual, result)
    }

    def detectNodeType(xpath, expected) {
        if(expected instanceof String) {
            return XPathConstants.STRING

        } else if(expected instanceof GString) {
            return XPathConstants.STRING

        } else if (expected instanceof Number) {
            // if expected is number, we treat it as string for tests
            return XPathConstants.STRING
        } else if (expected instanceof Boolean) {
            return XPathConstants.BOOLEAN
        } else {
            def classDef
            if(expected != null) {
                classDef = expected.getClass()
            }
            throw new Exception("expected value '${expected}' for ${xpath} must be String, Number or Boolean. Class type is ${classDef}")
        }
    }

}
