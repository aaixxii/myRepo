package common.sql

import groovy.sql.Sql
import java.sql.*
import test.lsm.config.*

class SqlExecutor {
	static final String COMMIT = "commit"
	def db

	SqlExecutor(ip, port, sid, user, pass){
		def connectionUrl = PtestConfig.getConnectoinUrl(ip, port, sid)
        println "Connecting to  ${connectionUrl}. ${user} ${pass}"
		JdbcDriverRegistor.regist()
        this.db = Sql.newInstance(connectionUrl, user, pass, "oracle.jdbc.driver.OracleDriver")
	}

    def getSqlResult(sql) {
		return db.rows(sql) // return List<GroovyRowResult>
		/*
			for(record in recordList){
				def val = record.get(COLMN_NAME)
			}
		*/
	}

    def getSqlResultOneRecord(sql) {
		def result
		def records = getSqlResult(sql)
		for(record in records){
			record.each{ 
				result = it.value
			}
		}
		return result
	}

    def selectCountSql(sql) {
		def num
		db.eachRow(sql, { num = it."count(*)" as int } )
		return num
	}

	def sqlExecute(sql){
		db.execute(sql)
	}

	def commit(){
		db.execute(COMMIT)
	}

	def getPreparedStatement(String sql){
		return db.connection.prepareStatement(sql)
	}

	def insertBlobFile(String sql, String filePath, int index){
		PreparedStatement ps = getPreparedStatement(sql)
		File file = new File(filePath);
		FileInputStream fInstream = new FileInputStream(file);
		ps.setBinaryStream(index, fInstream, (int)file.length()) 
		ps.executeUpdate() 
		ps.close();
	}
}


