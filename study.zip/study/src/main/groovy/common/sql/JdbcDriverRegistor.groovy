package common.sql

class JdbcDriverRegistor {
	static final String ORACLE_DRIVER = "oracle.jdbc.driver.OracleDriver"

	public static void regist() {
		try{
			com.eviware.soapui.support.GroovyUtils.registerJdbcDriver(ORACLE_DRIVER)
		}catch(MissingMethodException e){
			println "Error is occured while registing JdbcDriver. This SoapUI version may be 3.x..."
		}
	}
}


