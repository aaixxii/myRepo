package common.checker
import groovy.sql.Sql
import java.sql.SQLException
import test.lsm.config.*
import common.sql.*

class DBConnectionChecker {
    def db

    DBConnectionChecker(ip, port, sid, dbuser, dbpass) {
        def connectionUrl = PtestConfig.getConnectoinUrl(ip, port, sid)
        println "Connecting to  ${connectionUrl}. ${dbuser} ${dbpass}"
		JdbcDriverRegistor.regist()
        this.db = Sql.newInstance(connectionUrl, dbuser, dbpass, "oracle.jdbc.driver.OracleDriver")
    }

	def checkDBConnection(){
		def records;
		try{
			records = db.rows("select systimestamp from dual");
		}catch(Exception e){
			println (e.printStackTrace());
		}

		if (records.size() > 0){
			return true
		}else{
			return false
		}
	}
}
