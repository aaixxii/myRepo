package common.checker

import groovy.sql.Sql
import java.sql.SQLException
import test.lsm.config.*
import common.sql.*
import test.degrade.properties.*

class JobCompletionChecker {
    def db
    def timeout = -1
    def waitTime = 0
    def static SLEEP_INTERVAL = 10000
    def sqlForCountNotDoneJobs
    def static SLEEP_TIME_UNTIL_JOB_SUBMITTED = 10000 
	def static final String MY_CLASS_NAME = "JobCompletionChecker"

    JobCompletionChecker(context) {
		def globalProperties = new GlobalProperties(context)
		def ip = globalProperties.getDBIP()
		def port = globalProperties.getDBPort()
		def sid = globalProperties.getDBSID()
		def user = globalProperties.getDBUser()
		def pass = globalProperties.getDBPass()
        def connectionUrl = PtestConfig.getConnectoinUrl(ip, port, sid)
        printWithFormatting "Connecting to  ${connectionUrl}. ${user} ${pass}"
		JdbcDriverRegistor.regist()
        this.db = Sql.newInstance(connectionUrl, user, pass, "oracle.jdbc.driver.OracleDriver")
	}

    JobCompletionChecker(ip, port, sid, user, pass, timeout) {
        def connectionUrl = PtestConfig.getConnectoinUrl(ip, port, sid)
        printWithFormatting "Connecting to  ${connectionUrl}. ${user} ${pass}"
		JdbcDriverRegistor.regist()
        this.db = Sql.newInstance(connectionUrl, user, pass, "oracle.jdbc.driver.OracleDriver")
        this.timeout = timeout
    }

    def doesReachedTestTimeout() {
		if(timeout < 0) {
			return false
		}

        if(this.waitTime >= this.timeout){
            printWithFormatting "Reached timeout" + this.waitTime
            return true
        } else {
            return false 
        }
    }

    def areAllJobsDone(sqlForCountNotDoneJobs) {
        printWithFormatting "Executing ${sqlForCountNotDoneJobs}"
        def not_done_job_nums
        this.db.eachRow(sqlForCountNotDoneJobs, { not_done_job_nums = it.not_done_job_nums } )
        not_done_job_nums = not_done_job_nums as int
        printWithFormatting "Processing jobs count : ${not_done_job_nums}"

        if(not_done_job_nums == 0){
            return true 
        } else {
            return false
        }
    }

    def waitTopLevelJobsDone() {
        printWithFormatting "Start waiting top level jobs done"
        waitCompletion("select count(*) as not_done_job_nums from job_queue where job_state in (0, 1)")
    }

    def waitFeJobsDone() {
        printWithFormatting "Start waiting fe jobs done"
        waitCompletion("select count(*) as not_done_job_nums from fe_job_queue where job_state in (0, 1)")
    }

    def waitIdentifyBatchJobsDone() {
        printWithFormatting "Start waiting top level jobs done"
        waitCompletion("select count(*) as not_done_job_nums from identify_batch_job_queue where batchjob_status != 4")
    }

    def waitEnrollBatchJobsDone() {
        printWithFormatting "Start waiting top level jobs done"
        waitCompletion("select count(*) as not_done_job_nums from enroll_batch_job_queue where batchjob_status != 5")
    }

    def waitCompletion(String sqlForCountNotDoneJobs) {

		this.waitTime += SLEEP_TIME_UNTIL_JOB_SUBMITTED
        sleep(SLEEP_TIME_UNTIL_JOB_SUBMITTED)

        try{
            while(true){
                if(areAllJobsDone(sqlForCountNotDoneJobs)) { 
                    printWithFormatting "Breaking Loop. All jobs done"
                    break
                } else if(doesReachedTestTimeout() ) {
                    printWithFormatting "Breaking Loop. Reached timeout"
                    break
                } else {
                    this.waitTime += SLEEP_INTERVAL
                    sleep (SLEEP_INTERVAL) 
                }
            }
          
        } catch( SQLException sqle ){
            // FIXME
            sqle.printStackTrace()

        } finally {
            if(db != null) {
                db.close()
            }
        }
    }

	def printWithFormatting(String messg) {
		println "[ ${MY_CLASS_NAME} ] : ${messg}"
	}

}
