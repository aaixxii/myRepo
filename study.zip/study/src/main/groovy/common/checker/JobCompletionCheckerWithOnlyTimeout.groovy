package common.checker
import groovy.sql.Sql
import java.sql.SQLException

class JobCompletionChecker {
    def db
    def timeout
    def waitTime = 0
    def static SLEEP_INTERVAL = 20000
    def sqlForCountNotDoneJobs
    def static SLEEP_TIME_UNTIL_JOB_SUBMITTED = 10000 

    JobCompletionChecker(ip, port, sid, dbuser, dbpass, timeout) {
        println "Connecting to  jdbc:oracle:thin:@${ip}:${port}:${sid}. ${dbuser} ${dbpass}"

        db = Sql.newInstance(
            "jdbc:oracle:thin:@${ip}:${port}:${sid}",
            dbuser,
            dbpass,
            "oracle.jdbc.driver.OracleDriver"
        )
        this.timeout = timeout
    }

    def doesReachedTestTimeout() {
        if(this.waitTime >= this.timeout){
            println "Reached timeout" + this.waitTime
            return true
        } else {
            return false 
        }
    }

    def areAllJobsDone(sqlForCountNotDoneJobs) {
        println "Executing ${sqlForCountNotDoneJobs}"
        def not_done_job_nums
        this.db.eachRow(sqlForCountNotDoneJobs, { not_done_job_nums = it.not_done_job_nums } )
        not_done_job_nums = not_done_job_nums as int
        println "Not done jobs count: ${not_done_job_nums}"

        if(not_done_job_nums == 0){
            return true 
        } else {
            return false
        }
    }

    def waitTopLevelJobsDone() {
        println "Start waiting top level jobs donw"
        waitCompletion("select count(*) as not_done_job_nums from job_queue where job_state in (0, 1)")
    }

    def waitFeJobsDone() {

        println "Start waiting fe jobs donw"
        waitCompletion("select count(*) as not_done_job_nums from fe_job_queue where job_state in (0, 1)")
    }

    def waitUntilTimeout() {
        println "Start waiting timeout"
        sleep(SLEEP_TIME_UNTIL_JOB_SUBMITTED)
        while(true){
            if(doesReachedTestTimeout()){
                println "Breaking Loop. Reached timeout"
                break
             } else {
                 this.waitTime += SLEEP_INTERVAL
                 sleep(SLEEP_INTERVAL)
             }
         }
    }
        

    def waitCompletion(String sqlForCountNotDoneJobs) {
        sleep(SLEEP_TIME_UNTIL_JOB_SUBMITTED)
        try{
            while(true){
                if(areAllJobsDone(sqlForCountNotDoneJobs)) { 
                    println "Breaking Loop. All jobs done"
                    break
                } else {
                    sleep(SLEEP_INTERVAL)
                } 

                if(doesReachedTestTimeout() ) {
                    println "Breaking Loop. Reached timeout"
                    break
                } else {
                    this.waitTime += SLEEP_INTERVAL
                    sleep (SLEEP_INTERVAL) 
                }
            }
          
        } catch( SQLException sqle ){
            // FIXME
            sqle.printStackTrace()

        } finally {
            if(db != null) {
                db.close()
            }
        }
    }

}
