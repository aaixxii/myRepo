package common.os.linux

class LinuxCommander{

	def LinuxCommander(){}

	def doCommand(cmd){
		return cmd.execute().text
	}

	def doCommand(cmd1, cmd2){
		return (cmd1.execute() | cmd2.execute()).text
	}

	def List doShCommand(cmd){
		def String[] cmdList = [ "/bin/sh", "-c", cmd ]
		def process = Runtime.getRuntime().exec(cmdList)
		def reader  = process.getInputStream().newReader('UTF-8')
		def result = []
		reader.eachLine{
			result << it as String
		}
		return result
	}

	def List doSh(shell){
		def String[] cmdList = [ "/bin/sh", shell ]
		def process = Runtime.getRuntime().exec(cmdList)
		def reader  = process.getInputStream().newReader('UTF-8')
		def result = []
		reader.eachLine{
			result << it as String
		}
		return result
	}

	def getCpuCoreNum(){
		def cmd1 = "grep processor /proc/cpuinfo"
		def cmd2 = "wc -l"
		return doCommand(cmd1, cmd2) 
	}

	def List doShWithArg(shell, arg){
		def String[] cmdArray = [ "/bin/sh", shell, arg ]
		def process = Runtime.getRuntime().exec(cmdArray)
		def reader  = process.getInputStream().newReader('UTF-8')
		def result = []
		reader.eachLine{
			result << it as String
		}
		return result
	}

	def List doShWithArgs(shell, List args){
		def List cmdList = [ "/bin/sh", shell ]
		for (arg in args){
			cmdList << arg
		}
		def String[] cmdArray = cmdList.toArray()
		def process = Runtime.getRuntime().exec(cmdArray)
		def reader  = process.getInputStream().newReader('UTF-8')
		def result = []
		reader.eachLine{
			result << it as String
		}
		return result
	}

	def String doShWithArgs_returnLast(shell, List args){
		def List cmdList = [ "/bin/sh", shell ]
		for (arg in args){
			cmdList << arg
		}
		def String[] cmdArray = cmdList.toArray()
		def process = Runtime.getRuntime().exec(cmdArray)
		def reader  = process.getInputStream().newReader('UTF-8')
		def results = []
		reader.eachLine{
			results << it.toString()
		}
		return results[results.size() -1]
	}

	def List sudoNetstat(port, output){
		String cmd = "netstat -nap | grep ${port} > ${output}"
        return sudoShCommand(cmd)
	}	

	def List sudoShCommand(cmd){
		def String[] cmdList = [ "sudo", "/bin/sh", "-c", cmd ]
		def process = Runtime.getRuntime().exec(cmdList)
		def reader  = process.getInputStream().newReader('UTF-8')
		def result = []
		reader.eachLine{
			result << it as String
		}
		return result
	}
}
