package common.queue

class SingletonMapQueue {

	private static SingletonMapQueue instance
	private Map mapQueue

	private SingletonMapQueue() {
		this.mapQueue = Collections.synchronizedMap( new HashMap() )
	}

	public static synchronized SingletonMapQueue getInstance() {
		if (instance == null) {
			instance = new SingletonMapQueue()
		}
		return instance
	}

	public void enqueue(def key, def value) {
		mapQueue.put(key, value)
	}

	public def dequeue(def key) {
		def value = mapQueue.get(key)
		mapQueue.remove(key)
		return value
	}

	public def peek(def key) {
		def value = mapQueue.get(key)
		return value
	}

	public def keySet() {
		return mapQueue.keySet()
	}

    public void clearAll() {
		mapQueue = Collections.synchronizedMap( new HashMap() )
    }
}
