package common.queue

class SingletonListQueue {

	private static SingletonListQueue instance
	private List listQueue

	private SingletonListQueue() {
		this.listQueue = Collections.synchronizedList( new ArrayList() )
	}

	public static synchronized SingletonListQueue getInstance() {
		if (instance == null) {
			instance = new SingletonListQueue()
		}
		return instance
	}

	public void enqueue(def value) {
		listQueue.add(value)
	}

	public def dequeue() {
		return listQueue.remove(0)
	}

	public def _dequeue() {
		def value = listQueue.get(0)
		if(listQueue.size() <= 1){
			listQueue.remove(0)
		}
		return value
	}

	public def dequeue(def key) {
		return listQueue.remove(key)
	}

	public def peek(def key) {
		def value = listQueue.get(key)
		return value
	}

    public void clearAll() {
		listQueue = Collections.synchronizedList( new ArrayList() )
    }
	
	public int size(){
		return listQueue.size()
	}
}
