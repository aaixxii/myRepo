package jp.co.nec.aim.mm.jms;

import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.TextMessage;
import javax.naming.InitialContext;

import jp.co.nec.aim.mm.constants.JNDIConstants;
import jp.co.nec.aim.mm.spring.jms.AsynchHTTPJMSMessage;
import mockit.Mock;
import mockit.MockUp;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.broker.BrokerService;
import org.apache.activemq.command.ActiveMQQueue;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.jms.connection.SingleConnectionFactory;
import org.springframework.jms.listener.DefaultMessageListenerContainer;

public class JmsSenderTest {

	private ConnectionFactory jmsFactory;
	private Queue queueDestination;

	private AsynchHTTPJMSMessage receivedMsg;
	private String msg;
	private boolean isNotReceived = true;
	private int rerunLimit = 50;

	static BrokerService broker = new BrokerService();

	@BeforeClass
	public static void startService() throws Exception {
		broker.setBrokerName("one");
		broker.setPersistent(false);
		broker.start();
	}

	@AfterClass
	public static void stopService() throws Exception {
		broker.stop();
	}

	@Before
	public void setUp() throws Exception {
		isNotReceived = true;
	}

	@After
	public void tearDown() throws Exception {		
	}

	/**
	 * setMockMethod
	 */
	public void setJMSMockMethod(final String jndiQueueName) {
		new MockUp<InitialContext>() {
			@Mock
			public Object lookup(String jndiName) {
				if (jndiName.equals(JNDIConstants.JmsFactory)) {
					return jmsFactory;
				} else if (jndiName.equals(jndiQueueName)) {
					return queueDestination;
				}
				return null;
			}
		};
	}

	/**
	 * startServiceAndListener
	 * 
	 * @throws Exception
	 */
	private DefaultMessageListenerContainer startServiceAndListenerObj(
			String queueName) throws Exception {

		jmsFactory = new ActiveMQConnectionFactory(
				"vm://localhost?broker.persistent=false");
		queueDestination = new ActiveMQQueue(queueName);
		final SingleConnectionFactory singleConnectionFactory1 = new SingleConnectionFactory(
				jmsFactory);

		DefaultMessageListenerContainer listener = new DefaultMessageListenerContainer();
		listener.setConnectionFactory(singleConnectionFactory1);
		listener.setDestination(queueDestination);

		listener.setMessageListener(new MessageListener() {
			public void onMessage(Message message) {
				if (message instanceof ObjectMessage) {
					ObjectMessage objMsg = (ObjectMessage) message;
					try {
						receivedMsg = (AsynchHTTPJMSMessage) objMsg.getObject();
					} catch (JMSException e) {
					}
				}
				isNotReceived = false;
			}
		});
		listener.afterPropertiesSet();
		listener.start();
		Thread.sleep(1000);
		return listener;
	}

	/**
	 * startServiceAndListener
	 * 
	 * @throws Exception
	 */
	private DefaultMessageListenerContainer startServiceAndListener(
			String queueName) throws Exception {

		jmsFactory = new ActiveMQConnectionFactory(
				"vm://localhost?broker.persistent=false");
		queueDestination = new ActiveMQQueue(queueName);
		final SingleConnectionFactory singleConnectionFactory1 = new SingleConnectionFactory(
				jmsFactory);

		DefaultMessageListenerContainer listener = new DefaultMessageListenerContainer();
		listener.setConnectionFactory(singleConnectionFactory1);
		listener.setDestination(queueDestination);

		listener.setMessageListener(new MessageListener() {
			public void onMessage(Message message) {
				if (message instanceof TextMessage) {
					TextMessage objMsg = (TextMessage) message;
					try {
						msg = objMsg.getText();
					} catch (JMSException e) {
					}
				}
				isNotReceived = false;
			}
		});
		listener.afterPropertiesSet();
		listener.start();
		Thread.sleep(1000);
		return listener;
	}

	/**
	 * ASYNCH_QUEUE
	 */
	@Ignore
	@Test
	public void testOnMessage() throws Exception {
		setJMSMockMethod(JNDIConstants.ASYNCH_QUEUE);
		DefaultMessageListenerContainer listener = null;
		try {
			listener = startServiceAndListenerObj("AimAsynchHttpQueue");
			Thread thread = new Thread(new Runnable() {
				@Override
				public void run() {
					String msg1 = "ABCD";
					JmsSender.getInstance().sendToAsynchQueue(
							NotifierEnum.Aggregator, "127.0.0.1",
							msg1.getBytes(), false);
				}
			});

			thread.start();
			thread.join();
			String msg2 = "ABCD";
			assertResult("127.0.0.1", msg2.getBytes());
		} finally {
			if (listener != null) {
				listener.stop();
				listener.destroy();
			}
		}
	}

	/**
	 * INQUIRY_JOB_PLANNER_QUEUE
	 */
	@Ignore
	@Test
	public void testOnMessageINQUIRY_JOB_PLANNER_QUEUE() throws Exception {
		setJMSMockMethod(JNDIConstants.INQUIRY_JOB_PLANNER_QUEUE);
		DefaultMessageListenerContainer listener = null;
		try {
			listener = startServiceAndListener("IdentifyPlannerQueue");
			Thread thread = new Thread(new Runnable() {
				@Override
				public void run() {
					JmsSender.getInstance().sendToInquiryJobPlanner(
							NotifierEnum.Aggregator,
							"send Msg to IdentifyPlanner");
				}
			});

			thread.start();
			thread.join();
			assertResult("send Msg to IdentifyPlanner");
		} finally {
			if (listener != null) {
				listener.stop();
				listener.destroy();
			}
		}
	}

	/**
	 * asserts
	 */
	private void assertResult(String url, byte[] contexts) {
		waitRecieve();

		if (receivedMsg == null) {
			Assert.fail();
		}

		Assert.assertEquals(url, receivedMsg.getURL());
		for (int idx = 0; idx < contexts.length; idx++) {
			Assert.assertEquals(contexts[idx], receivedMsg.getBody()[idx]);
		}

	}

	/**
	 * asserts
	 */
	private void assertResult(String strmsg) {
		waitRecieve();

		if (msg == null) {
			Assert.fail();
		}
		Assert.assertTrue(msg.contains(strmsg));

	}

	public void waitRecieve() {
		int run = 0;
		while (isNotReceived && run++ <= rerunLimit) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		if (run > rerunLimit) {
			Assert.fail();
		}
	}
}
