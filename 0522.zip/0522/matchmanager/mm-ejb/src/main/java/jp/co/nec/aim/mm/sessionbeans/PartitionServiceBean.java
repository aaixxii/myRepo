package jp.co.nec.aim.mm.sessionbeans;


import java.util.concurrent.atomic.AtomicInteger;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

import jp.co.nec.aim.mm.dao.PartitionDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.dao.SystemInitDao;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class PartitionServiceBean {    
    private static Logger logger = LoggerFactory.getLogger(PartitionServiceBean.class);  
    
    @PersistenceContext(unitName = "aim-db")
    private EntityManager manager;
    
    @Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;	
    
	private JdbcTemplate jdbcTemplate;	
    private  AtomicInteger prePno = new AtomicInteger(7);

    private PartitionDao partitionDao;
    private SystemInitDao systemInitDao;
    
    public PartitionServiceBean() {     
    }
    
    @PostConstruct
    public void init() {
    	partitionDao = new PartitionDao(dataSource);
    	systemInitDao = new SystemInitDao(manager);
    	
	}  
    
    public void updatePartitionCount(Integer newNo) {
        if (newNo.intValue() - prePno.get() > 0) {
            doAddPartitionNo(newNo.intValue());
        } else {
            doReducePartitionNo(newNo);
        }
    }
    
    private void doAddPartitionNo(long newNo) {
    	long prePno = systemInitDao.getSegChangeLogSaveDays();
        long diff = newNo - prePno;
        long firstAddEpoch = System.currentTimeMillis() + diff * 24 * 60 *60 * 1000;
        long x = firstAddEpoch % prePno;
        long y = firstAddEpoch % newNo;
        long adjust = (x - y + newNo) % newNo;       
        int j = 0;
        for (long i = prePno + 1l; i <= newNo; i++) {
            long tmpEpoch = System.currentTimeMillis() + (diff + j) * 24 * 60 *60 * 1000;
            long newHashValue = caculateNewHashValue(i, tmpEpoch, adjust);
            partitionDao.createPartition(newHashValue);
            j++;
        }
        prePno = newNo;
    }
    
    private void doReducePartitionNo(int newNo) {
        int diff = prePno.get() - newNo;
        long firstAddEpoch = System.currentTimeMillis() + diff * 24 * 60 *60 * 1000;
        long x = firstAddEpoch % prePno.get();
        long y = firstAddEpoch % newNo;
        long adjust = (x - y + newNo) % newNo;       
        int j = 0;
        for (int i = newNo + 1; i <= prePno.get(); i--) {
            long tmpEpoch = System.currentTimeMillis() + (diff - j) * 24 * 60 *60 * 1000;
            long newHashValue = caculateNewHashValue(i, tmpEpoch, adjust);
            partitionDao.deletePartition(newHashValue);
            j++;
        }
        prePno = new AtomicInteger(newNo);
    }
    
    private long caculateNewHashValue(long newNo, long epoch, long adjust) {  
        long newHashValue = (epoch + adjust) % newNo;
        return newHashValue;
    }
    
}
