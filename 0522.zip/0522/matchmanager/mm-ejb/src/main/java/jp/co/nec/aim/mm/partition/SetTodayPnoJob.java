package jp.co.nec.aim.mm.partition;

import javax.sql.DataSource;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.PersistJobDataAfterExecution;

import jp.co.nec.aim.mm.dao.PartitionDao;

@DisallowConcurrentExecution
@PersistJobDataAfterExecution
public class SetTodayPnoJob implements Job {	
	 private PartitionDao partitionDao;
	 
	 public SetTodayPnoJob(DataSource dataSource) {		
		 partitionDao = new PartitionDao(dataSource);
	 }

	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
		long value = PartitionUtil.getInstance().caculateTodayHash();
		partitionDao.setTodayPno(value);		
	}
}
