package jp.co.nec.aim.mm.receiver;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.EJB;
import javax.ejb.MessageDriven;

import jp.co.nec.aim.mm.constants.Constants;
import jp.co.nec.aim.mm.constants.JNDIConstants;
import jp.co.nec.aim.mm.identify.planner.IdentifyPlanManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * listening and receive jms in IdnentiyPlanerQueue
 * 
 * @author xiazp
 * 
 */
@MessageDriven(name = "IdentifyPlannerEventRecever", activationConfig = {
		@ActivationConfigProperty(propertyName = "destinationLookup", propertyValue = JNDIConstants.INQUIRY_JOB_PLANNER_QUEUE),
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
		@ActivationConfigProperty(propertyName = "maxSessions", propertyValue = Constants.PLAN_MAX_SESSION) })
public class IdentifyPlannerEventRecever extends AbstractEventReceiver {
	private static Logger logger = LoggerFactory
			.getLogger(IdentifyPlannerEventRecever.class);
	@EJB
	IdentifyPlanManager planManager;

	@Override
	protected void dispatchEvent() {
		try {
			planManager.doMakePlanProcess();
		} catch (Exception e) {
			logger.error("Exception when do MakePlanProcess.", e);
		}
	}
}
