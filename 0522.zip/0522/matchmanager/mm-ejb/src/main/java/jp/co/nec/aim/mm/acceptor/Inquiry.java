package jp.co.nec.aim.mm.acceptor;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.protobuf.InvalidProtocolBufferException;

import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequest;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyRequest;
import jp.co.nec.aim.mm.aggregator.Aggregator;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.JobState;
import jp.co.nec.aim.mm.dao.CommitDao;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.FunctionDao;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.entities.FunctionTypeEntity;
import jp.co.nec.aim.mm.entities.JobQueueEntity;
import jp.co.nec.aim.mm.exception.ArgumentException;
import jp.co.nec.aim.mm.exception.DataBaseException;
import jp.co.nec.aim.mm.exception.ExceptionHelper;
import jp.co.nec.aim.mm.exception.ProtobufException;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.jms.NotifierEnum;
import jp.co.nec.aim.mm.procedure.BatchJobInfoProcedures;
//import jp.co.nec.aim.mm.license.LicenseManager;
import jp.co.nec.aim.mm.sessionbeans.pojo.InquiryJobHandler;
import jp.co.nec.aim.mm.util.CollectionsUtil;

/**
 * Inquiry Main Work flow <br>
 * Create top level job, fusion job and container jobs <br>
 * If created successfully, send JMS event to Planner <br>
 * 
 * @author liuyq
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class Inquiry {
	/** log instance **/
	private static Logger log = LoggerFactory.getLogger(Inquiry.class);
	private static String SQL = "select ft.top_level_job_timeouts from function_types ft, fusion_jobs fj "
			+ "where ft.function_id=fj.function_id and fj.fusion_job_id in (:ids) order by ft.top_level_job_timeouts";

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;
	//private LicenseManager licenseManager;
	private NamedParameterJdbcTemplate jdbcTemplate;
	private DateDao dateDao;
	private FunctionDao functionDao;
	private ExceptionHelper exception;
	private InquiryJobDao jobDao;
	private InquiryJobHandler jobHandler;
	private BatchJobInfoProcedures batchJobInfoProcedures;
	@EJB
	private Aggregator aggregator;
	private CommitDao commitDao;

	/**
	 * Inquiry default constructor
	 */
	public Inquiry() {
	}

	@PostConstruct
	public void init() {
		this.jdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
		this.functionDao = new FunctionDao(manager);
		this.dateDao = new DateDao(dataSource);
		this.exception = new ExceptionHelper(dateDao);
		this.jobDao = new InquiryJobDao(manager, dataSource);
		this.commitDao = new CommitDao(dataSource);
		this.jobHandler = new InquiryJobHandler(manager, dataSource, aggregator);
		batchJobInfoProcedures = new BatchJobInfoProcedures(dataSource);
	//	this.licenseManager = LicenseManager.getInstance();
	}

	/**
	 * Search function after validation.
	 * 
	 * 1st validation: commonOptions 2nd validation: license
	 * 
	 * @param inquiryRequests
	 *            InquiryRequest list
	 * @param options
	 *            CommonOptions instance
	 * @return top level job id
	 */
	public long inquiry(List<AimInquiryRequest> inquiryRequests,
			CommonOptions options) {
		
		
		// inquiryRequests is null or empty
		// throw AimRuntimeException
		if (CollectionsUtil.isEmpty(inquiryRequests)) {
			AimError argErr = AimError.REQUST_ERROR;
			throw new ArgumentException(argErr.getErrorCode(), argErr.getMessage(), String.valueOf(System.currentTimeMillis()), argErr.getUidCode());
		}
		
		// Loop each inquiry request and check license
		for (final AimInquiryRequest ir : inquiryRequests) {
			//checkLicense(ir);
		}

		// create top level job
		JobQueueEntity job = createTopLevelJob(options);		
		IdentifyRequest.Builder iqyReq = inquiryRequests.get(0).getRequest();
		PBBusinessMessage pbMsg = null;
		try {
			pbMsg = PBBusinessMessage.parseFrom(iqyReq.getBusinessMessage(0));
		} catch (InvalidProtocolBufferException e1) {
			AimError pfErr = AimError.PROTOBUF_ERROR;
			String errMsg = String.format(pfErr.getMessage(), e1.getCause().getMessage());
			throw new ProtobufException(pfErr.getErrorCode(), errMsg, String.valueOf(System.currentTimeMillis()), pfErr.getUidCode());
		}
		try {	
		    String refId = pbMsg.getRequest().hasEnrollmentId() ? pbMsg.getRequest().getEnrollmentId() : null;
		    batchJobInfoProcedures.createNewBatchJobInfo(iqyReq.getBatchJobId(), pbMsg.getRequest().getRequestId(), refId, iqyReq.getType().name(), job.getJobId());
		    commitDao.commit();
			log.info("success insert batch job info to DB.");
		} catch (SQLException e) {
		    Throwable cause = e.getCause();		   
            Throwable lastCause = null;
            while (cause != null) {
                cause = cause.getCause();
                if (cause != null) {
                    lastCause = cause;
                }
            }
		   String errMsg = lastCause.getMessage();		    
			AimError dbErr = AimError.INQ_DB;
			errMsg = StringUtils.isNoneEmpty(errMsg) ? errMsg : String.format(dbErr.getMessage(), e.getCause().getMessage());
			dbErr.setMessage(errMsg);
			throw new DataBaseException(dbErr.getErrorCode(), errMsg, String.valueOf(System.currentTimeMillis()), dbErr.getUidCode());
		} 

		// create fusion job and container job
		callCreateContainerJob(inquiryRequests, job);

		// at last send event to planer
		final String message = String.format("%s,%s,%s,added", job.getJobId(),
				StringUtils.EMPTY, StringUtils.EMPTY);

		JmsSender.getInstance().sendToInquiryJobPlanner(NotifierEnum.Inquiry,
				message);

		return job.getJobId();
	}

	/**
	 * callCreateContainerJob
	 * 
	 * @param inquiryRequests
	 *            InquiryRequest list
	 * @param job
	 *            JobQueueEntity instance
	 */
	void callCreateContainerJob(List<AimInquiryRequest> inquiryRequests,
			JobQueueEntity job) {
		// list of empty fusion job id
		// empty fusion job means this job does not owns
		// any segments to execute
		final Set<Long> emptyFusionJobs = Sets.newHashSet();
		// list of fusion Job id
		final List<Long> fusionJobIds = Lists.newArrayList();
		// job queue remain job
		final AtomicInteger remainJob = new AtomicInteger(0);

		int index = 1; // search request index
		// add generated fusion job id to list
		for (final AimInquiryRequest ir : inquiryRequests) {
			fusionJobIds.add(createContainerJob(job, ir, index++,
					emptyFusionJobs, remainJob));
		}

		// emptyFusionJob list is empty means all the
		// container job id owns segments tasks to execute
		// so go to inquiry normal work flow(timtOuts and remain job is require)
		if (emptyFusionJobs.isEmpty()) {
			// without any abnormal, set the remain job and timeouts
			setRemainJobToTopLevelJob(remainJob.get(), job);
			setTimtoutsToTopLevelJob(job, fusionJobIds);
		} else {
			if (emptyFusionJobs.size() == fusionJobIds.size()) {
				log.warn("All fusion jobs of JOB_ID=" + job.getJobId()
						+ " are empty."
						+ " Checking if immediate aggregation is necessary...");
				// commit is necessary due to aggregation is
				// in another transaction
				commitDao.commit();
				// check the inquiry job is necessary to aggregate
				jobHandler.checkJob(job.getJobId());
			} else {
				// without any abnormal, set the remain job and timeouts
				setRemainJobToTopLevelJob(remainJob.get(), job);
				setTimtoutsToTopLevelJob(job, fusionJobIds);
			}
		}
	}
	
	private long createContainerJob(JobQueueEntity job, AimInquiryRequest request,
			int index, Set<Long> emptyFusionJobs, AtomicInteger remainJob) {
		// function name must be given
		if (request.getFunctionName() == null) {
			AimError argErr = AimError.INQ_FUNCTION_TYPE;
			throw new ArgumentException(argErr.getErrorCode(), argErr.getMessage(), String.valueOf(System.currentTimeMillis()), argErr.getUidCode());
		}

		// inquiry ContainerId is empty, throw
		if (CollectionsUtil.isEmpty(request.getContainerId())) {
			AimError cidErr = AimError.INQ_CANNOT_FIND_CID;
			throw new ArgumentException(cidErr.getErrorCode(), cidErr.getMessage(), String.valueOf(System.currentTimeMillis()), cidErr.getUidCode());
		}

		FunctionTypeEntity fte = functionDao.getFunctionByName(request
				.getFunctionName());
		if (fte == null) {
			AimError argErr = AimError.INQ_FUNCTION_TYPE;
			throw new ArgumentException(argErr.getErrorCode(), argErr.getMessage(), String.valueOf(System.currentTimeMillis()), argErr.getUidCode());
		}

		return jobDao.callCreateContainerJob(job.getJobId(), index, fte,
				request.getContainerId(), request, emptyFusionJobs, remainJob,
				exception);
	}

	/**
	 * Set Remain container Job To TopLevelJob
	 * 
	 * @param remainJob
	 *            container remain job
	 * @param job
	 *            JobQueueEntity instance
	 */
	private void setRemainJobToTopLevelJob(int remainJob, JobQueueEntity job) {
		job.setRemainJobs(remainJob);
		manager.merge(job);
		manager.flush();
	}

	/**
	 * setTimtoutsToTopLevelJob
	 * 
	 * @param job
	 *            JobQueueEntity instance
	 * @param fusionJobIds
	 *            list of fusionJobId
	 */
	private void setTimtoutsToTopLevelJob(JobQueueEntity job,
			List<Long> fusionJobIds) {
		if (job == null) {
			log.warn("job is null");
			return;
		}

		if (CollectionsUtil.isEmpty(fusionJobIds)) {
			log.warn("List<Long> fusionJobIds is null or emtpy");
			return;
		}

		Map<String, Object> map = Maps.newHashMap();
		map.put("ids", fusionJobIds);
		// timeoutsList is sorted by timeouts value
		List<Integer> timeoutsList = jdbcTemplate.queryForList(SQL, map,
				Integer.class);
		if (CollectionsUtil.isEmpty(timeoutsList)) {
			log.warn("size of timeoutsList is zero, it's strange!");
			return;
		}
		if (CollectionsUtil.getFirst(timeoutsList).intValue() < 0) {
			// FUNCTION_TYPES.TIMEOUTS contains -1.
			job.setTimeouts(-1);
		} else {
			// Set Max value in timeoutsList
			job.setTimeouts(CollectionsUtil.getLast(timeoutsList));
		}
		manager.merge(job);
	}	

	/**
	 * Create TopLevelJob instance and persist into database
	 * 
	 * @param options
	 *            CommonOptions instance
	 * @return JobQueueEntity instance
	 */
	private JobQueueEntity createTopLevelJob(final CommonOptions options) {	
		final JobQueueEntity job = new JobQueueEntity();		
		job.setMaxCandidates(options.getMaxCandidates()); // maxCandidates
		job.setJobState(JobState.QUEUED); // state queue
		job.setSubmissionTS(dateDao.getCurrentTimeMS()); 
		job.setFailureCount(0); // not null default set 0
		job.setFamilyId(1); // not null FamilyId		
		job.setTimeouts(-1); // not null Timeouts
		job.setRemainJobs(0); // not null RemainJobs
		manager.persist(job);
		manager.flush();
		log.info("Created new top-level job: {} successfully", job.getJobId());
		return job;
	}

	@SuppressWarnings("unused")
	private JobQueueEntity createTopLevelJob(final PBBusinessMessage pbMes) {
		// set priority, maxCandidates, minScore
		// dynThreshPercentagePoint, dynThreshHitThreshold
		// setInquiryOptions(options);

		final JobQueueEntity job = new JobQueueEntity();
		PBRequest idRequest = pbMes.getRequest();
	
		job.setMaxCandidates(idRequest.getMaxResults()); // maxCandidates
		job.setJobState(JobState.QUEUED); // state queue
		job.setSubmissionTS(dateDao.getCurrentTimeMS()); 															
		// from web service or servLet	

		job.setFailureCount(0); // not null default set 0		
		job.setTimeouts(-1); // not null Timeouts
		job.setRemainJobs(0); // not null RemainJobs
		manager.persist(job);
		manager.flush();
		log.info("Created new top-level job: {} successfully", job.getJobId());
		return job;
	}
	
	/**
	 * check the license with InquiryRequest instance
	 * 
	 * @param ir
	 *            InquiryRequest instance
	 */
//	private void checkLicense(AimInquiryRequest ir) {
//		Date now = dateDao.getDatabaseDate();
//		String functionName = ir.getFunctionName();
//		licenseManager.check(functionName, now);
//	}


}
