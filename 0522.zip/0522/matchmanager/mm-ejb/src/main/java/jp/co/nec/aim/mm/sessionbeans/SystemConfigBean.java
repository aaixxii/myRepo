package jp.co.nec.aim.mm.sessionbeans;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.dao.SystemConfigDao;

/**
 * @author xiazp
 */
@Stateless
public class SystemConfigBean {

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;
	
	private SystemConfigDao systemConfigDao;
	
	

	public SystemConfigBean() {
		// must provide no-arg ctor for EJB container
	}
	
	

	@PostConstruct
	public void init() {		
	    systemConfigDao = new SystemConfigDao(manager);
	}
	
	/** 
	 * @param prop
	 * @return
	 */
	public long getMMPropertyLong(MMConfigProperty prop) {
	    return systemConfigDao.getMMPropertyLong(prop);
	}
}
