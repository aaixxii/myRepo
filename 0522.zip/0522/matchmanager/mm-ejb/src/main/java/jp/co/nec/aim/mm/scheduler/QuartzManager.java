package jp.co.nec.aim.mm.scheduler;

import java.util.Date;
import java.util.Properties;

import javax.persistence.EntityManager;

import jp.co.nec.aim.mm.constants.SchedulerEnum;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.partition.SetTodayPnoJob;

import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.DateBuilder;
import org.quartz.DateBuilder.IntervalUnit;
import org.quartz.Job;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.TriggerKey;
import org.quartz.impl.StdSchedulerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author jinxl
 * 
 */
public class QuartzManager {

	private static final Logger log = LoggerFactory
			.getLogger(QuartzManager.class);

	private Scheduler sched;

	private SystemConfigDao configDao;

	static QuartzManager INSTANCE;

	/**
	 * QuartzManager
	 * 
	 * @param manager
	 */
	private QuartzManager(EntityManager manager) {
		this.configDao = new SystemConfigDao(manager);
		try {
			initQuartzConfig();
			initSchedulerEnum();
			init();
		} catch (Exception e) {
			log.error("Exception occored when QuartzManager's constructor.", e);
			throw new AimRuntimeException(
					"Exception occored when QuartzManager's constructor.", e);
		}

	}

	/**
	 * getInstance: get Instance.
	 * 
	 * @param manager
	 * @return
	 */
	public synchronized static QuartzManager getInstance(EntityManager manager) {
		if (INSTANCE == null) {
			INSTANCE = new QuartzManager(manager);
		}
		return INSTANCE;
	}

	/**
	 * reScheduler: assign a new time and place for an Scheduler;
	 * 
	 * @param schedulerEnum
	 */
	public void reScheduler(SchedulerEnum schedulerEnum) {
		if (log.isDebugEnabled()) {
			log.debug("reScheduler start...");
		}
		if (schedulerEnum == null) {
			throw new IllegalArgumentException("schedulerEnum is null");
		}

		log.info("reScheduler event occurred, begin to reScheduler..");

		addScheduler(schedulerEnum.getClazz(), schedulerEnum.getJobkey(),
				schedulerEnum.getTriggerKey(),
				schedulerEnum.getIntervalInMillis(),
				schedulerEnum.getDelayMillis());

		if (log.isDebugEnabled()) {
			log.debug("reScheduler end...");
		}
	}

	/**
	 * addScheduler: add SchedulerEnum's Scheduler to sched
	 * 
	 * @param schedulerEnum
	 */
	private void addScheduler(SchedulerEnum schedulerEnum) {
		if (log.isDebugEnabled()) {
			log.debug("addScheduler start...");
		}
		if (schedulerEnum == null) {
			throw new IllegalArgumentException("schedulerEnum is null");
		}
		addScheduler(schedulerEnum.getClazz(), schedulerEnum.getJobkey(),
				schedulerEnum.getTriggerKey(),
				schedulerEnum.getIntervalInMillis(),
				schedulerEnum.getDelayMillis());

		if (log.isDebugEnabled()) {
			log.debug("addScheduler end...");
		}
		startPartitionJob();
	}

	/**
	 * startScheduler: start sched
	 */
	public synchronized void startScheduler() {
		if (log.isDebugEnabled()) {
			log.debug("startScheduler start...");
		}
		try {
			start();
		} catch (AimRuntimeException e) {
			log.error("Exception occored when startScheduler.", e);
			throw new AimRuntimeException(
					"Exception occored when startScheduler.", e);
		}
		if (log.isDebugEnabled()) {
			log.debug("startScheduler end...");
		}
	}

	/**
	 * shutdownScheduler: shut down all Scheduler
	 */
	public void shutdownScheduler() {
		if (log.isDebugEnabled()) {
			log.debug("shutdownScheduler start...");
		}
		try {
			shutdown();
		} catch (AimRuntimeException e) {
			log.error("Exception occored when shutdownScheduler.");
			throw new AimRuntimeException(
					"Exception occored when shutdownScheduler.", e);
		}
		if (log.isDebugEnabled()) {
			log.debug("shutdownScheduler end...");
		}
	}

	/**
	 * init: add all Scheduler to sched
	 */
	private void init() {
		if (log.isDebugEnabled()) {
			log.debug("init start...");
		}
		for (SchedulerEnum schedulerEnum : SchedulerEnum.values()) {
			addScheduler(schedulerEnum);
		}
		if (log.isDebugEnabled()) {
			log.debug("init end...");
		}
	}

	/**
	 * initSchedulerEnum : initialize SchedulerEnum's parameter
	 */
	private void initSchedulerEnum() {
		for (SchedulerEnum schedulerEnum : SchedulerEnum.values()) {
			if (schedulerEnum.getIntervalProperty() == null) {
				continue;
			}
			long intervalInMillis = configDao.getMMPropertyLong(schedulerEnum
					.getIntervalProperty());
			long timeoutInMillis = configDao.getMMPropertyLong(schedulerEnum
					.getLimitProperty());
			schedulerEnum.setIntervalInMillis(intervalInMillis);
			schedulerEnum.setTimeoutInMillis(timeoutInMillis);
		}
	}

	/**
	 * addScheduler
	 * 
	 * @param clazz
	 * @param jobkey
	 * @param triggerkey
	 * @param intervalInMillis
	 * @param delayMillis
	 */
	private void addScheduler(Class<? extends Job> clazz, JobKey jobkey,
			TriggerKey triggerkey, long intervalInMillis, int delayMillis) {
		/* clazz is null */
		if (clazz == null) {
			throw new IllegalArgumentException("clazz is null");
		}

		/* jobkey is null */
		if (jobkey == null) {
			throw new IllegalArgumentException("jobkey is null");
		}

		/* triggerkey is null */
		if (triggerkey == null) {
			throw new IllegalArgumentException("triggerkey is null");
		}
		/* sched is null */
		if (sched == null) {
			throw new AimRuntimeException("first call start is necessary..");
		}

		try {
			if (log.isDebugEnabled()) {
				log.debug("define the job and tie it to our {} class...",
						clazz.getSimpleName());
			}
			/* intervalInMillis is less than zero */
			if (intervalInMillis < 0) {
				if (sched.checkExists(jobkey)) {
					sched.deleteJob(jobkey);
				}
				log.warn(clazz.getSimpleName()
						+ " Repeat interval must be >= 0");
				return;
			}
			JobDetail job = JobBuilder.newJob(clazz).withIdentity(jobkey)
					.build();
			if (log.isDebugEnabled()) {
				log.debug(
						"Trigger the job to run now, and then every {} milliseconds...",
						intervalInMillis);
			}
			Date runTime = DateBuilder.futureDate(delayMillis,
					IntervalUnit.MILLISECOND);

			Trigger trigger = TriggerBuilder
					.newTrigger()
					.withIdentity(triggerkey)
					.startAt(runTime)
					.withSchedule(
							SimpleScheduleBuilder
									.simpleSchedule()
									.withIntervalInMilliseconds(
											intervalInMillis).repeatForever())
					.build();

			if (sched.checkExists(jobkey)) {
				log.info(
						"rescheduleJob:{}, intervalInMillis: {}, delayMillis: {}..",
						clazz.getSimpleName(), intervalInMillis, delayMillis);
				sched.rescheduleJob(trigger.getKey(), trigger);
			} else {
				log.info(
						"scheduleJob:{}, intervalInMillis: {}, delayMillis: {}..",
						clazz.getSimpleName(), intervalInMillis, delayMillis);
				sched.scheduleJob(job, trigger);
			}
		} catch (SchedulerException e) {
			throw new AimRuntimeException("shutdownScheduler", e);
		}
	}

	/**
	 * start
	 * 
	 * @throws SchedulerException
	 */
	private void start() throws AimRuntimeException {

		try {
			if (sched == null) {
				throw new AimRuntimeException("sched is null");
			}

			sched.start();

		} catch (SchedulerException e) {
			log.error("The Scheduler can not start.");
			throw new AimRuntimeException("shutdownScheduler", e);
		}
	}

	/**
	 * shutdown
	 * 
	 * @throws SchedulerException
	 */
	private void shutdown() throws AimRuntimeException {
		try {

			if (sched == null) {
				throw new AimRuntimeException("sched is null");
			}

			/* Wait for Executing Jobs to Finish */
			sched.shutdown(false);
			sched = null;

		} catch (SchedulerException e) {
			log.error("The Scheduler can not shut down", e);
			throw new AimRuntimeException("shutdownScheduler", e);
		}
	}

	/**
	 * initQuartzConfig
	 * 
	 * @throws SchedulerException
	 */
	private void initQuartzConfig() throws AimRuntimeException {
		try {
			Properties p = new Properties();
			p.setProperty("org.quartz.scheduler.instanceName",
					"QuartzScheduler");
			p.setProperty("org.quartz.scheduler.instanceId", "1");
			p.setProperty("org.quartz.threadPool.threadCount", "12");
			p.setProperty("org.quartz.threadPool.makeThreadsDaemons", "true");
			p.setProperty("org.quartz.jobStore.class",
					"org.quartz.simpl.RAMJobStore");
			StdSchedulerFactory schedFact = new org.quartz.impl.StdSchedulerFactory(
					p);
			sched = schedFact.getScheduler();
		} catch (SchedulerException e) {
			log.error("Error loading property data", e);
			throw new AimRuntimeException("shutdownScheduler", e);
		}
	}
	
	private void startPartitionJob() {
		 JobKey addPNoKey = new JobKey("SetTodayPno", "addPno");
		  JobDetail setTodayPnoJob = JobBuilder.newJob(SetTodayPnoJob.class).
	                withIdentity(addPNoKey)
	                .build();
	      CronTrigger croTrigger = (CronTrigger) TriggerBuilder.newTrigger()
	                .withIdentity("addPnoTrigger", "addPnoTriggerGroup")
	                .startNow()
	                .withSchedule(CronScheduleBuilder.cronSchedule("0 0 1 * * ?"))
	                .build();
	      //ToDo add clear job
	      try {
			sched.scheduleJob(setTodayPnoJob, croTrigger);
			log.info("Partition job started!");
		} catch (SchedulerException e) {			
			e.printStackTrace();
		}
		
	}
}
