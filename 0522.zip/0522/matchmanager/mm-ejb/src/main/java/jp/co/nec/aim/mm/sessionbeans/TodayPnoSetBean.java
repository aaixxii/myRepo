package jp.co.nec.aim.mm.sessionbeans;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

import jp.co.nec.aim.mm.util.StopWatch;

/**
 * Stateless Bean to call garbage_segment_change_log()
 * 
 * @author jinxl
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class TodayPnoSetBean {
	private static final Logger log = LoggerFactory
			.getLogger(TodayPnoSetBean.class);

	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;
	
	private JdbcTemplate jdbcTemplate;
	
	@PostConstruct
    public void init() {
	    
	}

	public void execute() {
		if (log.isDebugEnabled()) {
			log.debug("Start gSegChangeLogPartitiion task.");
		}
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		try {
		    //ToDo			
			
			if (log.isDebugEnabled()) {
				log.debug("Finish garbage SEGMENT_CHANGE_LOG.");
			}
		} finally {
			stopWatch.stop();
		}
	}
	
	

}