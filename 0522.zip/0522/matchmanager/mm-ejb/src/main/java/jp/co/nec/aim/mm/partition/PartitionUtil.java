package jp.co.nec.aim.mm.partition;

import javax.persistence.EntityManager;

import jp.co.nec.aim.mm.constants.JNDIConstants;
import jp.co.nec.aim.mm.dao.SystemInitDao;
import jp.co.nec.aim.mm.util.JndiLookup;

public class PartitionUtil {
	
	 private SystemInitDao systemInitDao;
	
	private static final PartitionUtil INSTANCE = new PartitionUtil();
	
	public static PartitionUtil getInstance() {
		return INSTANCE;
	}
	
	private PartitionUtil() {
		EntityManager entityManager = JndiLookup.lookUp(JNDIConstants.EntityManagerName, EntityManager.class);				
		systemInitDao = new SystemInitDao(entityManager);		
	}	
	
	public  long caculateTodayHash() {
		Long saveDays = systemInitDao.getSegChangeLogSaveDays();
		return System.currentTimeMillis() % (saveDays.longValue() + 2);
	}
	
	public long caculateAdjust(long unixTime, long oldN, long newN) {
		long x = unixTime % oldN;
		long y = unixTime % newN;
		long adjust = (x - y + newN) % newN;
		return adjust;		
	}
}
