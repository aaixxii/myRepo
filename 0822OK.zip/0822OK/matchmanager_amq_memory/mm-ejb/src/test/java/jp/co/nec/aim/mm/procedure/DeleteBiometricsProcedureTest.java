package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import jp.co.nec.aim.mm.segment.sync.SegSyncInfos;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class DeleteBiometricsProcedureTest {
	@Resource
	private DataSource dataSource;

	@Resource
	private JdbcTemplate jdbcTemplate;

	private DeleteBiometricsProcedure deleteBiometricsProcedure;

	@Before
	public void setUp() throws Exception {
		deleteBiometricsProcedure = new DeleteBiometricsProcedure(dataSource);
		jdbcTemplate.update("delete from PERSON_BIOMETRICS");
		jdbcTemplate.update("delete from SEGMENTS");
		jdbcTemplate.update("delete from SEGMENT_CHANGE_LOG");
		jdbcTemplate.update("commit");
	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.update("delete from PERSON_BIOMETRICS");
		jdbcTemplate.update("delete from SEGMENTS");
		jdbcTemplate.update("delete from SEGMENT_CHANGE_LOG");
		jdbcTemplate.update("commit");
	}

	@Test
	public void testExecuteArgsNotNull() throws SQLException {
		jdbcTemplate
				.update("insert into PERSON_BIOMETRICS(BIOMETRICS_ID,EXTERNAL_ID,REGISTED_TS,CORRUPTED_FLAG,CONTAINER_ID)values(1,'1',123,0,1)");
		jdbcTemplate
				.update("insert into SEGMENTS(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH,RECORD_COUNT,VERSION,REVISION)values(1,1,1,1,83,1,1,1)");
		jdbcTemplate.execute("commit");
		Integer containerId =1;		
		deleteBiometricsProcedure.setpNo(1l);
		deleteBiometricsProcedure.setExternalId("1");
		//List<String> tempList = containerIds.stream().map(p -> String.valueOf(p)).collect(Collectors.toList());
		deleteBiometricsProcedure.setContainerId(containerId);
		 List<SegSyncInfos> syncMap = new ArrayList<>();
		deleteBiometricsProcedure.executeDeletion(syncMap);
		List<Map<String, Object>> listPer = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Assert.assertEquals(0, listPer.size());
		List<Map<String, Object>> listSegChangeLog = jdbcTemplate
				.queryForList("select * from SEGMENT_CHANGE_LOG");
		Assert.assertEquals(1, listSegChangeLog.size());
		Map<String, Object> mapSegChangeLog = listSegChangeLog.get(0);
		Assert.assertEquals(2,
				Integer.parseInt(mapSegChangeLog.get("CHANGE_TYPE").toString()));
		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from SEGMENTS");
		Assert.assertEquals(1, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(0);
		Assert.assertEquals(2,
				Integer.parseInt(mapSeg.get("VERSION").toString()));
	}

	@Test
	public void testExecuteContainerIdsIsNull() throws SQLException {
		jdbcTemplate
				.update("insert into PERSON_BIOMETRICS(BIOMETRICS_ID,EXTERNAL_ID,REGISTED_TS,CORRUPTED_FLAG,CONTAINER_ID)values(1,'1',123,0,1)");
		jdbcTemplate
				.update("insert into SEGMENTS(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH,RECORD_COUNT,VERSION,REVISION)values(1,1,1,1,1,83,1,1)");
		jdbcTemplate.execute("commit");
		deleteBiometricsProcedure.setpNo(1l);
		deleteBiometricsProcedure.setExternalId("1");
		deleteBiometricsProcedure.setContainerId(1);

		 List<SegSyncInfos> syncMap = new ArrayList<>();
		Integer result = deleteBiometricsProcedure.executeDeletion(syncMap);
		List<Map<String, Object>> listPer = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Assert.assertEquals(0, listPer.size());
		List<Map<String, Object>> listSegChangeLog = jdbcTemplate
				.queryForList("select * from SEGMENT_CHANGE_LOG");
		Assert.assertEquals(1, listSegChangeLog.size());
		Map<String, Object> mapSegChangeLog = listSegChangeLog.get(0);
		Assert.assertEquals(2,
				Integer.parseInt(mapSegChangeLog.get("CHANGE_TYPE").toString()));
		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from SEGMENTS");
		Assert.assertEquals(1, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(0);
		Assert.assertEquals(2,
				Integer.parseInt(mapSeg.get("VERSION").toString()));
	}

	@Test
	public void testExecuteEventIdIsNull() throws SQLException {
		jdbcTemplate
				.update("insert into PERSON_BIOMETRICS(BIOMETRICS_ID,EXTERNAL_ID,REGISTED_TS,CORRUPTED_FLAG,CONTAINER_ID)values(1,'1',123,0,1)");
		jdbcTemplate
				.update("insert into SEGMENTS(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH,RECORD_COUNT,VERSION,REVISION)values(1,1,1,1,83,1,1,1)");		jdbcTemplate.execute("commit");
		deleteBiometricsProcedure.setpNo(1l);
		deleteBiometricsProcedure.setExternalId("1");
		deleteBiometricsProcedure.setContainerId(1);
		 List<SegSyncInfos> syncMap = new ArrayList<>();
		deleteBiometricsProcedure.executeDeletion(syncMap);

		List<Map<String, Object>> listPer = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Assert.assertEquals(0, listPer.size());
		List<Map<String, Object>> listSegChangeLog = jdbcTemplate
				.queryForList("select * from SEGMENT_CHANGE_LOG");
		Assert.assertEquals(1, listSegChangeLog.size());
		Map<String, Object> mapSegChangeLog = listSegChangeLog.get(0);
		Assert.assertEquals(2,
				Integer.parseInt(mapSegChangeLog.get("CHANGE_TYPE").toString()));
		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from SEGMENTS");
		Assert.assertEquals(1, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(0);
		Assert.assertEquals(2,
				Integer.parseInt(mapSeg.get("VERSION").toString()));
	}

	@Test
	public void testExecuteEventIdIsContainerIdsBothNull() throws SQLException {
		jdbcTemplate
				.update("insert into PERSON_BIOMETRICS(BIOMETRICS_ID,EXTERNAL_ID,REGISTED_TS,CORRUPTED_FLAG,CONTAINER_ID)values(1,'1',123,0,1)");
		jdbcTemplate
				.update("insert into SEGMENTS(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH,RECORD_COUNT,VERSION,REVISION)values(1,1,1,1,83,1,1,1)");
		jdbcTemplate.execute("commit");
		deleteBiometricsProcedure.setpNo(1l);
		deleteBiometricsProcedure.setExternalId("1");
		deleteBiometricsProcedure.setContainerId(1);
		 List<SegSyncInfos> syncMap = new ArrayList<>();
		deleteBiometricsProcedure.executeDeletion(syncMap);
		List<Map<String, Object>> listPer = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Assert.assertEquals(0, listPer.size());
		List<Map<String, Object>> listSegChangeLog = jdbcTemplate
				.queryForList("select * from SEGMENT_CHANGE_LOG");
		Assert.assertEquals(1, listSegChangeLog.size());
		Map<String, Object> mapSegChangeLog = listSegChangeLog.get(0);
		Assert.assertEquals(2,
				Integer.parseInt(mapSegChangeLog.get("CHANGE_TYPE").toString()));
		List<Map<String, Object>> listSeg = jdbcTemplate
				.queryForList("select * from SEGMENTS");
		Assert.assertEquals(1, listSeg.size());
		Map<String, Object> mapSeg = listSeg.get(0);
		Assert.assertEquals(2,
				Integer.parseInt(mapSeg.get("VERSION").toString()));
	}

}
