package jp.co.nec.aim.mm.sessionbeans.pojo;

import java.io.Serializable;
import java.util.Arrays;

public class UidAimAmqResponse implements Serializable {

	private static final long serialVersionUID = 2263150006317593060L;
	String requestId;
	String requestType;
	String xmlResult;
	byte[] diagnostics;

	public UidAimAmqResponse(String requestId, String reqType, String xmlResult, byte[] diagnostics) {
		this.requestId = requestId;
		this.requestType = reqType;
		this.xmlResult = xmlResult;
		this.diagnostics = diagnostics;
	}

	public UidAimAmqResponse() {

	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getXmlResult() {
		return xmlResult;
	}

	public void setXmlResult(String xmlResult) {
		this.xmlResult = xmlResult;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public byte[] getDiagnostics() {
		return diagnostics;
	}

	public void setDiagnostics(byte[] diagnostics) {
		this.diagnostics = diagnostics;
	}

	@Override
	public String toString() {
		return Arrays.asList(requestId, requestType, requestId, new String(diagnostics)).toString();
	}

	@Override
	public int hashCode() {
		return this.requestId.hashCode() + this.requestType.hashCode() + this.xmlResult.hashCode()
				+ this.diagnostics.hashCode();
	}
}
