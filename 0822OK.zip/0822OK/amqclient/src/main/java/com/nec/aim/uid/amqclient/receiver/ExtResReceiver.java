package com.nec.aim.uid.amqclient.receiver;

import java.io.IOException;

import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.support.AmqpMessageHeaderAccessor;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import com.rabbitmq.client.Channel;

@Component
@RabbitListener(queues ="extResQueue", ackMode = "MANUAL")
public class ExtResReceiver {
	
	   @RabbitHandler
	    public void handle(@Payload String message, AmqpMessageHeaderAccessor messageHeaderAccessor, Channel channel) throws IOException {
	        System.out.println("My Recevied ext response message by string method"  + message);
	        try{	
	            channel.basicAck(messageHeaderAccessor.getDeliveryTag(),false);
	        }catch (Exception e){	  
	           // new DirectExchange("");
	            channel.basicNack(messageHeaderAccessor.getDeliveryTag(),false,true);
	        }
//	        String reqeustId = XmlUtil.getRequestId(message);
//	        CallbackWriter cw = new CallbackWriter( reqeustId, message);
//	        Thread th = new Thread(cw);
//	        th.start();
	    }
	   
	    @RabbitHandler
	    public void handle(@Payload byte[] bytes,AmqpMessageHeaderAccessor messageHeaderAccessor, Channel channel) throws IOException {
	    	String result = new String(bytes);
	    	System.out.print("received data =" + result);
	    	   
	        channel.basicAck(messageHeaderAccessor.getDeliveryTag(),true);
	    }	   

//	   @RabbitListener(queues ="extResQueue", ackMode = "MANUAL")
//	    public void handle(@Payload byte[] bytes,AmqpMessageHeaderAccessor messageHeaderAccessor, Channel channel) throws IOException {
//		   System.out.println("My Recevied message size " + bytes.length);	
//	       // System.out.println("My Recevied message " + new String(bytes, StandardCharsets.UTF_8));	  
//	        channel.basicAck(messageHeaderAccessor.getDeliveryTag(),true);
//	    }
}

