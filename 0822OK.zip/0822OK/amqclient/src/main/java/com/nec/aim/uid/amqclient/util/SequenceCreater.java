package com.nec.aim.uid.amqclient.util;

import java.util.concurrent.atomic.AtomicLong;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.configuration.reloading.FileChangedReloadingStrategy;

/**
 * @author xia
 *
 */
public class SequenceCreater {		
	private static String sequecFilePath;
	private static PropertiesConfiguration propsConfig;	;
	private static AtomicLong lastReqeustId;
	private static AtomicLong lastEnrollmentId;
	//private static NumberFormat format; 
	
	private static final SequenceCreater Instance = new SequenceCreater();
	
	public SequenceCreater getInstance() {
		return Instance;	}
	
	
	SequenceCreater() {
		try {
			load();
		} catch (ConfigurationException e) {
			
			e.printStackTrace();
		}
	}
	
	public static void load() throws ConfigurationException {
		sequecFilePath = "src/main/resources/uid.sequece.properties";			
		propsConfig = new PropertiesConfiguration();
		propsConfig.setEncoding("UTF-8");		
		propsConfig.load(sequecFilePath);
		propsConfig.setAutoSave(true);
		propsConfig.setReloadingStrategy(new FileChangedReloadingStrategy());		
		long requestId = propsConfig.getLong("requestId");
		lastReqeustId = new AtomicLong(requestId);
		long enrollmentId = propsConfig.getLong("referenceId");
		lastEnrollmentId = new AtomicLong(enrollmentId);
	}

	
	public static String getNextRequestIdSequece() {
		String requestId = "REQ_" + String.format("%032d", lastReqeustId.incrementAndGet());
		return requestId;
	}
	
	public static String getNextRefIdSequece() {
		String enrollId = "REF_" + String.format("%032d", lastEnrollmentId.incrementAndGet());
		return enrollId;
	}
	
	public static void saveValues() {
		try {
			PropertiesConfiguration properties = new PropertiesConfiguration(sequecFilePath);
			properties.setProperty("requestId", String.valueOf(lastReqeustId.get()));
			properties.setProperty("referenceId", String.valueOf(lastEnrollmentId.incrementAndGet()));
			properties.save();
			properties = null;
		} catch (ConfigurationException e) {
			System.out.println(e.getMessage());
		}
	}
	
	
}
