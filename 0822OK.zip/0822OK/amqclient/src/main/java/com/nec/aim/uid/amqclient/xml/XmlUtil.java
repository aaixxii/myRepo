
package com.nec.aim.uid.amqclient.xml;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

import com.nec.aim.uid.amqclient.exception.XmlException;


public class XmlUtil {
	private static final String REQUEST_ID = "requestId";
	private static final String REF_ID = "referenceId";
	private static final String URL = "referenceUrl";

	public boolean isThisCmd(String xml, String elementName) {
		// elementName is Quality or Insert or Identify or Delete
		SAXReader reader = new SAXReader();
		Document document = null;
		try {
			document = reader.read(new ByteArrayInputStream(xml.getBytes("UTF-8")));
		} catch (DocumentException | UnsupportedEncodingException e) {
			throw new XmlException(e.getMessage(), e.getCause());
		}
		Element rootElement = document.getRootElement();
		Element element = rootElement.element(elementName);
		String cmd = element.getName();
		if (cmd.equals(elementName)) {
			return true;
		} else {
			return false;
		}
	}
	
	@SuppressWarnings("rawtypes")
	public static String getXmlCmd(String xml) {
		SAXReader reader = new SAXReader();
		Document document = null;
		try {
			document = reader.read(new ByteArrayInputStream(xml.getBytes("UTF-8")));
		} catch (DocumentException | UnsupportedEncodingException e) {
			throw new XmlException(e.getMessage(), e.getCause());
		}		
		Element rootElement = document.getRootElement();
		//String xpathExpression = "child::node()";
		//List<Element> nods = rootElement.selectNodes(xpathExpression);
		List node = rootElement.elements();
		 Element first =(Element) node.get(0);
		 return first.getName();
	}

	// for Request and Respose
	public static String getRequestId(String xml) {
		SAXReader reader = new SAXReader();
		Document document = null;
		try {
			document = reader.read(new ByteArrayInputStream(xml.getBytes("UTF-8")));
		} catch (DocumentException | UnsupportedEncodingException e) {
			throw new XmlException(e.getMessage(), e.getCause());
		}
		Element rootElement = document.getRootElement();
		String responseResult = rootElement.attributeValue(REQUEST_ID);
		return responseResult;
	}

	public static String getRefId(String xml, String elementName) {
		// elementName is Insert or Identify or Quality or Delete
		// elementName is quality-payload or insert-payload or identify-payload
		SAXReader reader = new SAXReader();
		Document document = null;
		try {
			document = reader.read(new ByteArrayInputStream(xml.getBytes("UTF-8")));
		} catch (DocumentException | UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		Element rootElement = document.getRootElement();
		Element element = rootElement.element(elementName);
		String refId = element.attributeValue(REF_ID);
		return refId;
	}
	
	public static String getIdentifyAtribute(String xml, String atributeName) {
		SAXReader reader = new SAXReader();
		Document document = null;
		try {
			document = reader.read(new ByteArrayInputStream(xml.getBytes("UTF-8")));
		} catch (DocumentException | UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		Element rootElement = document.getRootElement();
		Element element = rootElement.element("Identify");
		String attributeValue  = element.attributeValue(atributeName);
		return attributeValue;
		
	}

	public static String getUrl(String xml, String elementName) {
		// elementName is Insert or Identify or
		// elementName is quality-payload or insert-payload or identify-payload
		SAXReader reader = new SAXReader();
		Document document = null;
		try {
			document = reader.read(new ByteArrayInputStream(xml.getBytes("UTF-8")));
		} catch (DocumentException | UnsupportedEncodingException e) {
			throw new XmlException(e.getMessage(), e.getCause());
		}
		Element rootElement = document.getRootElement();
		Element element = rootElement.element(elementName);
		String url = element.attributeValue(URL);
		return url;
	}	
	
	public static String dom4jCreateXml(String requestId , String success, String failureReason) throws IOException {
		 Document document = DocumentHelper.createDocument();
		 Element root = document.addElement("Response")
				 .addAttribute("requestId", requestId)
				 .addAttribute("timeStamp", String.valueOf(System.currentTimeMillis()));
		 root.addElement("Return").addAttribute("value", success).addAttribute("failureReason", failureReason);
		 OutputFormat format = OutputFormat.createPrettyPrint();
		 StringWriter sw = new StringWriter();
        XMLWriter writer  = new XMLWriter(sw, format);        
        writer.write(document);
        String resuslt = sw.toString();		 
		return resuslt;		
	}
	
	public static UidAimAmqResponse buildFaildXmlReespose(String requestId, String failureReason) throws IOException  {
		UidAimAmqResponse response = new UidAimAmqResponse();
		String xmlRes = dom4jCreateFaildResXml(requestId, failureReason);	
		response.setRequestId(requestId);
		response.setXmlResult(xmlRes);
		return response;
	}
	
	public static byte[] buildgiagnostics(int count) throws IOException {		
		 Element diagnostics = DocumentHelper.createElement("Diagnostics");
		for (int i = 0; i < count; i++) {
			 Element diagnostic = DocumentHelper.createElement("Diagnostic");
			 diagnostic.addAttribute("attempt", String.valueOf(i + 1));
			 String subType = null;
			 String type = null;
			 switch (i % 4) {
				case 0:
					subType = "finger";
					type = "finger";
				break;
				case 1:
					subType = "face";
					type = "face";
				break;	
				case 2:
					subType = "iris";
					type = "iris";
				break;
				case 3:
					subType = "voice";
					type = "voice";
				break;
				 default:
			}
			 
			 diagnostic.addAttribute("subtype", subType)				
			 .addAttribute("type", type);
			 diagnostics.add(diagnostic);
		}
		OutputFormat format = OutputFormat.createPrettyPrint();
		StringWriter sw = new StringWriter();
		XMLWriter writer = new XMLWriter(sw, format);
		writer.write(diagnostics);
		String resuslt = sw.toString();
		return resuslt.getBytes();
	}
	
	
	public static String dom4jCreateFaildResXml(String requestId , String failureReason) throws IOException {
		 Document document = DocumentHelper.createDocument();
		 Element root = document.addElement( "Response")
				 .addAttribute("requestId", requestId)
				 .addAttribute("timeStamp", String.valueOf(System.currentTimeMillis()));
		 root.addElement("Return").addAttribute("value", String.valueOf("2")).addAttribute("failureReason", failureReason);
		 OutputFormat format = OutputFormat.createPrettyPrint();
		 StringWriter sw = new StringWriter();
       XMLWriter writer  = new XMLWriter(sw, format);        
       writer.write(document);
       String resuslt = sw.toString();		 
		return resuslt;		
	}
	
	public static String buildExtractPayload(String refId, String url) throws IOException {
		 Document document = DocumentHelper.createDocument();
		 document.addElement( "quality-payload")
				 .addAttribute("referenceId", refId)
				 .addAttribute("referenceUrl", url);
		 OutputFormat format = OutputFormat.createPrettyPrint();
		 StringWriter sw = new StringWriter();
        XMLWriter writer  = new XMLWriter(sw, format);        
        writer.write(document);
        String resuslt = sw.toString();		 
		return resuslt;
	}
	
	public static String buildInquiryRequest(String requeustid, String refId, String url) throws IOException {
		 Document document = DocumentHelper.createDocument();
		 Element root = document.addElement("Request");
		 root.addElement("Identify")
				 .addAttribute("referenceId", refId)
				 .addAttribute("referenceUrl", url)
				 .addAttribute("maxResults", "10")
				 .addAttribute("targetFPIR", "1")
				 .addAttribute("targetModalityFPIR", "1")
				 .addAttribute("dedupModalityInstance", "1")
				 .addAttribute("missingBiometric", "1")
				 .addAttribute("fullsearch", "false");	
		 root.addAttribute("timeStamp", String.valueOf(System.currentTimeMillis()))
		     .addAttribute("version", "1")
		     .addAttribute("requestId", requeustid);		 
		 
		 OutputFormat format = OutputFormat.createPrettyPrint();
		 StringWriter sw = new StringWriter();
        XMLWriter writer  = new XMLWriter(sw, format);        
        writer.write(document);
        String resuslt = sw.toString();		 
		return resuslt;		
	}
	
	public static String buildDeleteRequest(String requeustid,String refId) throws IOException {
		 Document document = DocumentHelper.createDocument();
		 Element root = document.addElement("Request");
		 root.addElement("Delete")
				 .addAttribute("referenceId", refId);		
		 root.addAttribute("timeStamp", String.valueOf(System.currentTimeMillis()))
		     .addAttribute("version", "1")
		     .addAttribute("requestId", requeustid);	
		 OutputFormat format = OutputFormat.createPrettyPrint();
		 StringWriter sw = new StringWriter();
        XMLWriter writer  = new XMLWriter(sw, format);        
        writer.write(document);
        String resuslt = sw.toString();		 
		return resuslt;		
		
	}
}
