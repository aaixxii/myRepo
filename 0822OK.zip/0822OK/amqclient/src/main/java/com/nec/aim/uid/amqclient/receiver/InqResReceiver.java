package com.nec.aim.uid.amqclient.receiver;

import java.io.IOException;

import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.support.AmqpMessageHeaderAccessor;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.nec.aim.uid.amqclient.util.AmqObjectUtil;
import com.rabbitmq.client.Channel;

import jp.co.nec.aim.mm.sessionbeans.pojo.UidAimAmqResponse;

@Service
@RabbitListener(queues ="inqResQueue", ackMode = "MANUAL")
public class InqResReceiver {
	
	   @RabbitHandler
	    public void handle(@Payload String message, AmqpMessageHeaderAccessor messageHeaderAccessor, Channel channel) throws IOException {
	        System.out.println("My Recevied inq respose message by string method"  + message);
	        try{	
	            channel.basicAck(messageHeaderAccessor.getDeliveryTag(),false);
	        }catch (Exception e){	  
	            new DirectExchange("");
	            channel.basicNack(messageHeaderAccessor.getDeliveryTag(),false,true);
	        }
//	        String reqeustId = XmlUtil.getRequestId(message);
//	        CallbackWriter cw = new CallbackWriter( reqeustId, message);
//	        Thread th = new Thread(cw);
//	        th.start();
	    }

	    @RabbitHandler
	    public void handle(@Payload byte[] bytes,AmqpMessageHeaderAccessor messageHeaderAccessor, Channel channel) throws IOException {
	    	System.out.print("received data size=" + bytes.length);
	    	try {
				UidAimAmqResponse amqResult = AmqObjectUtil.deserializeAmqResults(bytes);
				System.out.print(amqResult.toString());
			} catch (ClassNotFoundException e) {				
				e.printStackTrace();
			}
	        channel.basicAck(messageHeaderAccessor.getDeliveryTag(),true);
	    }
}
