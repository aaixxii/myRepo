package com.nec.aim.uid.amqclient.interf;
import org.springframework.amqp.rabbit.core.RabbitTemplate.ConfirmCallback;

public interface SendMessageService extends ConfirmCallback {
	public void sendMessage(Object message);

}
