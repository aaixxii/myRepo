package com.nec.aim.uid.amqclient.result;

import java.io.File;
import java.net.URL;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.aim.uid.amqclient.util.FileUtil;


public class CallbackWriter implements Runnable {		
	private String requestId;
	private String data;
	private static Logger logger = LoggerFactory.getLogger(CallbackWriter.class);

	public CallbackWriter(String requestId, String data) {
		this.requestId = requestId;
		this.data = data;
	}

	public void writeResultToFile() {
		 URL url = Thread.currentThread().getContextClassLoader().getResource("jobresults");
		 String path = url.getPath() + File.separator + requestId; 
		 logger.info("Success path= {}", path);
		 FileUtil.saveStringToFile(data, path);
		 logger.info("Success save data to file, requestId= {}", requestId);
	}
	
	@Override
	public void run() {
		writeResultToFile();
	}
}
