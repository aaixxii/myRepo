package com.nec.aim.uid.amqclient;

import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EnableRabbit
//@EnableTransactionManagement
@ComponentScan(basePackages ="com.nec.aim.uid.amqclient")
public class AmqApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmqApplication.class, args);
	}

}
