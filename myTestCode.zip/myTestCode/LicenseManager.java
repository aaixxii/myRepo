package com.nec.biomatcher.core.framework.license;

import java.util.concurrent.atomic.AtomicBoolean;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.common.parameter.exception.BioParameterServiceException;
import com.nec.biomatcher.core.framework.license.exception.InvalidLicenseException;
import com.nec.biomatcher.core.framework.license.floating.FloatingLicenseManager;
import com.nec.biomatcher.core.framework.license.local.LocalLicenseManager;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;



public class LicenseManager  implements InitializingBean, DisposableBean{
	
	public static final LicenseManager INSTANCE = new LicenseManager();
	private static final  AtomicBoolean IS_FLOATING_LICENSE = new AtomicBoolean(false);
	
	private static final Logger logger = Logger.getLogger(LicenseManager.class);
	
	LicenseManager() {
		init();
	}
	
	private BioParameterService bioParameterService;
	
	public LicenseManager getInstance() {
		return INSTANCE;
	}
	

	
	public void init() {
		Lmx MEGHA_LMX = new Lmx();
		MEGHA_LMX.init();
		try {
			String floatingServerURL = bioParameterService.getParameterValue("FLOATING_SERVER_URL", "DEFAULT");
			String licenseXmlFilePath = System.getProperty("jboss.server.config.dir");
			if (StringUtils.isBlank(licenseXmlFilePath) && !StringUtils.isBlank(floatingServerURL)) {
				MEGHA_LMX.SetOption(arg0, arg1);
				MEGHA_LMX.setOption(LmxSettings.LMX_OPT_AUTOMATIC_HEARTBEAT_ATTEMPTS, -1);
				MEGHA_LMX.setOption(LmxSettings.LMX_OPT_AUTOMATIC_HEARTBEAT_INTERVAL, 30);
				IS_FLOATING_LICENSE.set(true);
				
			} else if (StringUtils.isBlank(licenseXmlFilePath) && !StringUtils.isBlank(licenseXmlFilePath)){
				LocalLicenseManager.initLocalLicenseManager(lmx, licenseXmlFilePath);
				IS_FLOATING_LICENSE.set(false);
			}
		} catch (BioParameterServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}	
	
	public static void checkFeatureLicense(String featureId) throws InvalidLicenseException {
		
		if (IS_FLOATING_LICENSE.get() == true) {
			 FloatingLicenseManager.getInstance().checkFeature(featureId);
		} else {
			LocalLicenseManager.checkFeatureLicense(featureId);
		}
	}
	
	
	@Override
	public void afterPropertiesSet() throws Exception {
		bioParameterService = SpringServiceManager.getBean("bioParameterService");
		
	}

	@Override
	public void destroy() throws Exception {
		// TODO Auto-generated method stub
		
	}

}
