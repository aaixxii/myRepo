package com.nec.biomatcher.core.framework.license.floating;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xformation.lmx.Lmx;
import com.xformation.lmx.Lmx.HeartbeatCheckoutFailureCallback;
import com.xformation.lmx.Lmx.HeartbeatConnectionLostCallback;
import com.xformation.lmx.Lmx.HeartbeatExitCallback;
import com.xformation.lmx.Lmx.HeartbeatRetryFailureCallback;
import com.xformation.lmx.LmxException;
import com.xformation.lmx.LmxStatus;

/*
 * FloatLicenseHandler is called after failed in license server heartbeat.<br/>
 * @author xiazp
 * 
 */
public class FloatLicenseHandler {
	private static Logger logger = LoggerFactory.getLogger(FloatLicenseHandler.class);
	private static final FloatLicenseHandler INSTANCE = new FloatLicenseHandler();
	private Lmx lmx;

	public static FloatLicenseHandler getInstance() {
		return INSTANCE;
	}

	public void initHeatbeatHandler(Lmx mmLmx) {
		try {
			mmLmx.setHeartbeatConnectionLostCallback(handlerConnectionLostConsumer());
			mmLmx.setHeartbeatRetryFailureCallback(handlerRetryFailureConsumer());
			mmLmx.setHeartbeatCheckoutFailureCallback(handlerCheckoutFailureConsumer());
			// mmLmx.setHeartbeatExitCallback(handlerheartbeatExitConsumer());
			this.lmx = mmLmx;
		} catch (LmxException e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unused")
	private HeartbeatExitCallback handlerheartbeatExitConsumer() {
		return new HeartbeatExitCallback() {
			@Override
			public void accept() {
				FloatingLicenseManager.getInstance().clearLicenseInfoMap();
				try {
					lmx.checkin("afis", Lmx.LMX_ALL_LICENSES);
				} catch (LmxException e) {
					logger.error(e.getMessage(), e);

				} finally {
					lmx.free();
				}
			}
		};
	}

	private HeartbeatCheckoutFailureCallback handlerCheckoutFailureConsumer() {
		return new HeartbeatCheckoutFailureCallback() {
			@Override
			public void accept(String featureName, Integer usedCount, LmxStatus status) {
				logger.warn("HeartbeatCheckoutFailured. featureName:{}, status:{}", featureName, status.name());
				FloatingLicenseManager.getInstance().clearLicenseInfoMap();
				try {
					lmx.checkin(featureName, usedCount);
					logger.warn(status.name());
				} catch (LmxException e) {
					logger.error(e.getMessage(), e);
				}

			}

		};
	}

	private HeartbeatConnectionLostCallback handlerConnectionLostConsumer() {
		return new HeartbeatConnectionLostCallback() {
			@Override
			public void accept(String host, Integer port, Integer failedHeartbeats) {
				logger.warn("Heartbeat connection is lost. host:{}, port:{}", host, port);
				FloatingLicenseManager.getInstance().clearLicenseInfoMap();
				try {
					lmx.checkin("afis", 1);
				} catch (LmxException e) {
					logger.error(e.getMessage(), e);
				}
			}
		};

	}

	private HeartbeatRetryFailureCallback handlerRetryFailureConsumer() {
		return new HeartbeatRetryFailureCallback() {
			@Override
			public void accept(String featureName, Integer usedCount) {
				logger.warn("HeartbeatRetryFailure. feature:{}", featureName);
				FloatingLicenseManager.getInstance().clearLicenseInfoMap();
				try {
					lmx.checkin(featureName, usedCount);
				} catch (LmxException e) {
					logger.error(e.getMessage(), e);
				}
			}
		};
	}
}
