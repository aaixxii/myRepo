package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ESochiExample {
    /**
     * E_SOCHI
     */
    protected String orderByClause;

    /**
     * E_SOCHI
     */
    protected boolean distinct;

    /**
     * E_SOCHI
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public ESochiExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * E_SOCHI null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_JIANIsNull() {
            addCriterion("LN_JIAN is null");
            return (Criteria) this;
        }

        public Criteria andLN_JIANIsNotNull() {
            addCriterion("LN_JIAN is not null");
            return (Criteria) this;
        }

        public Criteria andLN_JIANEqualTo(String value) {
            addCriterion("LN_JIAN =", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANNotEqualTo(String value) {
            addCriterion("LN_JIAN <>", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANGreaterThan(String value) {
            addCriterion("LN_JIAN >", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANGreaterThanOrEqualTo(String value) {
            addCriterion("LN_JIAN >=", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANLessThan(String value) {
            addCriterion("LN_JIAN <", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANLessThanOrEqualTo(String value) {
            addCriterion("LN_JIAN <=", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANLike(String value) {
            addCriterion("LN_JIAN like", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANNotLike(String value) {
            addCriterion("LN_JIAN not like", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANIn(List<String> values) {
            addCriterion("LN_JIAN in", values, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANNotIn(List<String> values) {
            addCriterion("LN_JIAN not in", values, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANBetween(String value1, String value2) {
            addCriterion("LN_JIAN between", value1, value2, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANNotBetween(String value1, String value2) {
            addCriterion("LN_JIAN not between", value1, value2, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU01IsNull() {
            addCriterion("SOCHI_NAIYOU01 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU01IsNotNull() {
            addCriterion("SOCHI_NAIYOU01 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU01EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU01 =", value, "SOCHI_NAIYOU01");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU01NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU01 <>", value, "SOCHI_NAIYOU01");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU01GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU01 >", value, "SOCHI_NAIYOU01");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU01GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU01 >=", value, "SOCHI_NAIYOU01");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU01LessThan(String value) {
            addCriterion("SOCHI_NAIYOU01 <", value, "SOCHI_NAIYOU01");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU01LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU01 <=", value, "SOCHI_NAIYOU01");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU01Like(String value) {
            addCriterion("SOCHI_NAIYOU01 like", value, "SOCHI_NAIYOU01");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU01NotLike(String value) {
            addCriterion("SOCHI_NAIYOU01 not like", value, "SOCHI_NAIYOU01");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU01In(List<String> values) {
            addCriterion("SOCHI_NAIYOU01 in", values, "SOCHI_NAIYOU01");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU01NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU01 not in", values, "SOCHI_NAIYOU01");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU01Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU01 between", value1, value2, "SOCHI_NAIYOU01");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU01NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU01 not between", value1, value2, "SOCHI_NAIYOU01");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU02IsNull() {
            addCriterion("SOCHI_NAIYOU02 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU02IsNotNull() {
            addCriterion("SOCHI_NAIYOU02 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU02EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU02 =", value, "SOCHI_NAIYOU02");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU02NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU02 <>", value, "SOCHI_NAIYOU02");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU02GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU02 >", value, "SOCHI_NAIYOU02");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU02GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU02 >=", value, "SOCHI_NAIYOU02");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU02LessThan(String value) {
            addCriterion("SOCHI_NAIYOU02 <", value, "SOCHI_NAIYOU02");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU02LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU02 <=", value, "SOCHI_NAIYOU02");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU02Like(String value) {
            addCriterion("SOCHI_NAIYOU02 like", value, "SOCHI_NAIYOU02");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU02NotLike(String value) {
            addCriterion("SOCHI_NAIYOU02 not like", value, "SOCHI_NAIYOU02");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU02In(List<String> values) {
            addCriterion("SOCHI_NAIYOU02 in", values, "SOCHI_NAIYOU02");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU02NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU02 not in", values, "SOCHI_NAIYOU02");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU02Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU02 between", value1, value2, "SOCHI_NAIYOU02");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU02NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU02 not between", value1, value2, "SOCHI_NAIYOU02");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU03IsNull() {
            addCriterion("SOCHI_NAIYOU03 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU03IsNotNull() {
            addCriterion("SOCHI_NAIYOU03 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU03EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU03 =", value, "SOCHI_NAIYOU03");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU03NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU03 <>", value, "SOCHI_NAIYOU03");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU03GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU03 >", value, "SOCHI_NAIYOU03");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU03GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU03 >=", value, "SOCHI_NAIYOU03");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU03LessThan(String value) {
            addCriterion("SOCHI_NAIYOU03 <", value, "SOCHI_NAIYOU03");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU03LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU03 <=", value, "SOCHI_NAIYOU03");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU03Like(String value) {
            addCriterion("SOCHI_NAIYOU03 like", value, "SOCHI_NAIYOU03");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU03NotLike(String value) {
            addCriterion("SOCHI_NAIYOU03 not like", value, "SOCHI_NAIYOU03");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU03In(List<String> values) {
            addCriterion("SOCHI_NAIYOU03 in", values, "SOCHI_NAIYOU03");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU03NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU03 not in", values, "SOCHI_NAIYOU03");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU03Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU03 between", value1, value2, "SOCHI_NAIYOU03");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU03NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU03 not between", value1, value2, "SOCHI_NAIYOU03");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU04IsNull() {
            addCriterion("SOCHI_NAIYOU04 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU04IsNotNull() {
            addCriterion("SOCHI_NAIYOU04 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU04EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU04 =", value, "SOCHI_NAIYOU04");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU04NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU04 <>", value, "SOCHI_NAIYOU04");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU04GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU04 >", value, "SOCHI_NAIYOU04");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU04GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU04 >=", value, "SOCHI_NAIYOU04");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU04LessThan(String value) {
            addCriterion("SOCHI_NAIYOU04 <", value, "SOCHI_NAIYOU04");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU04LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU04 <=", value, "SOCHI_NAIYOU04");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU04Like(String value) {
            addCriterion("SOCHI_NAIYOU04 like", value, "SOCHI_NAIYOU04");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU04NotLike(String value) {
            addCriterion("SOCHI_NAIYOU04 not like", value, "SOCHI_NAIYOU04");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU04In(List<String> values) {
            addCriterion("SOCHI_NAIYOU04 in", values, "SOCHI_NAIYOU04");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU04NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU04 not in", values, "SOCHI_NAIYOU04");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU04Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU04 between", value1, value2, "SOCHI_NAIYOU04");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU04NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU04 not between", value1, value2, "SOCHI_NAIYOU04");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU05IsNull() {
            addCriterion("SOCHI_NAIYOU05 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU05IsNotNull() {
            addCriterion("SOCHI_NAIYOU05 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU05EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU05 =", value, "SOCHI_NAIYOU05");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU05NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU05 <>", value, "SOCHI_NAIYOU05");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU05GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU05 >", value, "SOCHI_NAIYOU05");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU05GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU05 >=", value, "SOCHI_NAIYOU05");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU05LessThan(String value) {
            addCriterion("SOCHI_NAIYOU05 <", value, "SOCHI_NAIYOU05");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU05LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU05 <=", value, "SOCHI_NAIYOU05");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU05Like(String value) {
            addCriterion("SOCHI_NAIYOU05 like", value, "SOCHI_NAIYOU05");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU05NotLike(String value) {
            addCriterion("SOCHI_NAIYOU05 not like", value, "SOCHI_NAIYOU05");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU05In(List<String> values) {
            addCriterion("SOCHI_NAIYOU05 in", values, "SOCHI_NAIYOU05");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU05NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU05 not in", values, "SOCHI_NAIYOU05");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU05Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU05 between", value1, value2, "SOCHI_NAIYOU05");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU05NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU05 not between", value1, value2, "SOCHI_NAIYOU05");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU06IsNull() {
            addCriterion("SOCHI_NAIYOU06 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU06IsNotNull() {
            addCriterion("SOCHI_NAIYOU06 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU06EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU06 =", value, "SOCHI_NAIYOU06");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU06NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU06 <>", value, "SOCHI_NAIYOU06");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU06GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU06 >", value, "SOCHI_NAIYOU06");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU06GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU06 >=", value, "SOCHI_NAIYOU06");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU06LessThan(String value) {
            addCriterion("SOCHI_NAIYOU06 <", value, "SOCHI_NAIYOU06");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU06LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU06 <=", value, "SOCHI_NAIYOU06");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU06Like(String value) {
            addCriterion("SOCHI_NAIYOU06 like", value, "SOCHI_NAIYOU06");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU06NotLike(String value) {
            addCriterion("SOCHI_NAIYOU06 not like", value, "SOCHI_NAIYOU06");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU06In(List<String> values) {
            addCriterion("SOCHI_NAIYOU06 in", values, "SOCHI_NAIYOU06");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU06NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU06 not in", values, "SOCHI_NAIYOU06");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU06Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU06 between", value1, value2, "SOCHI_NAIYOU06");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU06NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU06 not between", value1, value2, "SOCHI_NAIYOU06");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU07IsNull() {
            addCriterion("SOCHI_NAIYOU07 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU07IsNotNull() {
            addCriterion("SOCHI_NAIYOU07 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU07EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU07 =", value, "SOCHI_NAIYOU07");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU07NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU07 <>", value, "SOCHI_NAIYOU07");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU07GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU07 >", value, "SOCHI_NAIYOU07");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU07GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU07 >=", value, "SOCHI_NAIYOU07");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU07LessThan(String value) {
            addCriterion("SOCHI_NAIYOU07 <", value, "SOCHI_NAIYOU07");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU07LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU07 <=", value, "SOCHI_NAIYOU07");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU07Like(String value) {
            addCriterion("SOCHI_NAIYOU07 like", value, "SOCHI_NAIYOU07");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU07NotLike(String value) {
            addCriterion("SOCHI_NAIYOU07 not like", value, "SOCHI_NAIYOU07");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU07In(List<String> values) {
            addCriterion("SOCHI_NAIYOU07 in", values, "SOCHI_NAIYOU07");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU07NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU07 not in", values, "SOCHI_NAIYOU07");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU07Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU07 between", value1, value2, "SOCHI_NAIYOU07");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU07NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU07 not between", value1, value2, "SOCHI_NAIYOU07");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU08IsNull() {
            addCriterion("SOCHI_NAIYOU08 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU08IsNotNull() {
            addCriterion("SOCHI_NAIYOU08 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU08EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU08 =", value, "SOCHI_NAIYOU08");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU08NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU08 <>", value, "SOCHI_NAIYOU08");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU08GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU08 >", value, "SOCHI_NAIYOU08");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU08GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU08 >=", value, "SOCHI_NAIYOU08");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU08LessThan(String value) {
            addCriterion("SOCHI_NAIYOU08 <", value, "SOCHI_NAIYOU08");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU08LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU08 <=", value, "SOCHI_NAIYOU08");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU08Like(String value) {
            addCriterion("SOCHI_NAIYOU08 like", value, "SOCHI_NAIYOU08");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU08NotLike(String value) {
            addCriterion("SOCHI_NAIYOU08 not like", value, "SOCHI_NAIYOU08");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU08In(List<String> values) {
            addCriterion("SOCHI_NAIYOU08 in", values, "SOCHI_NAIYOU08");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU08NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU08 not in", values, "SOCHI_NAIYOU08");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU08Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU08 between", value1, value2, "SOCHI_NAIYOU08");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU08NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU08 not between", value1, value2, "SOCHI_NAIYOU08");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU09IsNull() {
            addCriterion("SOCHI_NAIYOU09 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU09IsNotNull() {
            addCriterion("SOCHI_NAIYOU09 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU09EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU09 =", value, "SOCHI_NAIYOU09");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU09NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU09 <>", value, "SOCHI_NAIYOU09");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU09GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU09 >", value, "SOCHI_NAIYOU09");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU09GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU09 >=", value, "SOCHI_NAIYOU09");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU09LessThan(String value) {
            addCriterion("SOCHI_NAIYOU09 <", value, "SOCHI_NAIYOU09");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU09LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU09 <=", value, "SOCHI_NAIYOU09");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU09Like(String value) {
            addCriterion("SOCHI_NAIYOU09 like", value, "SOCHI_NAIYOU09");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU09NotLike(String value) {
            addCriterion("SOCHI_NAIYOU09 not like", value, "SOCHI_NAIYOU09");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU09In(List<String> values) {
            addCriterion("SOCHI_NAIYOU09 in", values, "SOCHI_NAIYOU09");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU09NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU09 not in", values, "SOCHI_NAIYOU09");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU09Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU09 between", value1, value2, "SOCHI_NAIYOU09");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU09NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU09 not between", value1, value2, "SOCHI_NAIYOU09");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU10IsNull() {
            addCriterion("SOCHI_NAIYOU10 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU10IsNotNull() {
            addCriterion("SOCHI_NAIYOU10 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU10EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU10 =", value, "SOCHI_NAIYOU10");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU10NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU10 <>", value, "SOCHI_NAIYOU10");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU10GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU10 >", value, "SOCHI_NAIYOU10");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU10GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU10 >=", value, "SOCHI_NAIYOU10");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU10LessThan(String value) {
            addCriterion("SOCHI_NAIYOU10 <", value, "SOCHI_NAIYOU10");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU10LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU10 <=", value, "SOCHI_NAIYOU10");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU10Like(String value) {
            addCriterion("SOCHI_NAIYOU10 like", value, "SOCHI_NAIYOU10");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU10NotLike(String value) {
            addCriterion("SOCHI_NAIYOU10 not like", value, "SOCHI_NAIYOU10");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU10In(List<String> values) {
            addCriterion("SOCHI_NAIYOU10 in", values, "SOCHI_NAIYOU10");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU10NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU10 not in", values, "SOCHI_NAIYOU10");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU10Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU10 between", value1, value2, "SOCHI_NAIYOU10");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU10NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU10 not between", value1, value2, "SOCHI_NAIYOU10");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU11IsNull() {
            addCriterion("SOCHI_NAIYOU11 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU11IsNotNull() {
            addCriterion("SOCHI_NAIYOU11 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU11EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU11 =", value, "SOCHI_NAIYOU11");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU11NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU11 <>", value, "SOCHI_NAIYOU11");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU11GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU11 >", value, "SOCHI_NAIYOU11");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU11GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU11 >=", value, "SOCHI_NAIYOU11");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU11LessThan(String value) {
            addCriterion("SOCHI_NAIYOU11 <", value, "SOCHI_NAIYOU11");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU11LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU11 <=", value, "SOCHI_NAIYOU11");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU11Like(String value) {
            addCriterion("SOCHI_NAIYOU11 like", value, "SOCHI_NAIYOU11");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU11NotLike(String value) {
            addCriterion("SOCHI_NAIYOU11 not like", value, "SOCHI_NAIYOU11");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU11In(List<String> values) {
            addCriterion("SOCHI_NAIYOU11 in", values, "SOCHI_NAIYOU11");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU11NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU11 not in", values, "SOCHI_NAIYOU11");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU11Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU11 between", value1, value2, "SOCHI_NAIYOU11");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU11NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU11 not between", value1, value2, "SOCHI_NAIYOU11");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU12IsNull() {
            addCriterion("SOCHI_NAIYOU12 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU12IsNotNull() {
            addCriterion("SOCHI_NAIYOU12 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU12EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU12 =", value, "SOCHI_NAIYOU12");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU12NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU12 <>", value, "SOCHI_NAIYOU12");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU12GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU12 >", value, "SOCHI_NAIYOU12");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU12GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU12 >=", value, "SOCHI_NAIYOU12");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU12LessThan(String value) {
            addCriterion("SOCHI_NAIYOU12 <", value, "SOCHI_NAIYOU12");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU12LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU12 <=", value, "SOCHI_NAIYOU12");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU12Like(String value) {
            addCriterion("SOCHI_NAIYOU12 like", value, "SOCHI_NAIYOU12");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU12NotLike(String value) {
            addCriterion("SOCHI_NAIYOU12 not like", value, "SOCHI_NAIYOU12");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU12In(List<String> values) {
            addCriterion("SOCHI_NAIYOU12 in", values, "SOCHI_NAIYOU12");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU12NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU12 not in", values, "SOCHI_NAIYOU12");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU12Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU12 between", value1, value2, "SOCHI_NAIYOU12");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU12NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU12 not between", value1, value2, "SOCHI_NAIYOU12");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU13IsNull() {
            addCriterion("SOCHI_NAIYOU13 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU13IsNotNull() {
            addCriterion("SOCHI_NAIYOU13 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU13EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU13 =", value, "SOCHI_NAIYOU13");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU13NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU13 <>", value, "SOCHI_NAIYOU13");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU13GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU13 >", value, "SOCHI_NAIYOU13");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU13GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU13 >=", value, "SOCHI_NAIYOU13");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU13LessThan(String value) {
            addCriterion("SOCHI_NAIYOU13 <", value, "SOCHI_NAIYOU13");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU13LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU13 <=", value, "SOCHI_NAIYOU13");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU13Like(String value) {
            addCriterion("SOCHI_NAIYOU13 like", value, "SOCHI_NAIYOU13");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU13NotLike(String value) {
            addCriterion("SOCHI_NAIYOU13 not like", value, "SOCHI_NAIYOU13");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU13In(List<String> values) {
            addCriterion("SOCHI_NAIYOU13 in", values, "SOCHI_NAIYOU13");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU13NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU13 not in", values, "SOCHI_NAIYOU13");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU13Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU13 between", value1, value2, "SOCHI_NAIYOU13");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU13NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU13 not between", value1, value2, "SOCHI_NAIYOU13");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU14IsNull() {
            addCriterion("SOCHI_NAIYOU14 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU14IsNotNull() {
            addCriterion("SOCHI_NAIYOU14 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU14EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU14 =", value, "SOCHI_NAIYOU14");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU14NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU14 <>", value, "SOCHI_NAIYOU14");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU14GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU14 >", value, "SOCHI_NAIYOU14");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU14GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU14 >=", value, "SOCHI_NAIYOU14");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU14LessThan(String value) {
            addCriterion("SOCHI_NAIYOU14 <", value, "SOCHI_NAIYOU14");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU14LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU14 <=", value, "SOCHI_NAIYOU14");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU14Like(String value) {
            addCriterion("SOCHI_NAIYOU14 like", value, "SOCHI_NAIYOU14");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU14NotLike(String value) {
            addCriterion("SOCHI_NAIYOU14 not like", value, "SOCHI_NAIYOU14");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU14In(List<String> values) {
            addCriterion("SOCHI_NAIYOU14 in", values, "SOCHI_NAIYOU14");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU14NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU14 not in", values, "SOCHI_NAIYOU14");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU14Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU14 between", value1, value2, "SOCHI_NAIYOU14");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU14NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU14 not between", value1, value2, "SOCHI_NAIYOU14");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU15IsNull() {
            addCriterion("SOCHI_NAIYOU15 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU15IsNotNull() {
            addCriterion("SOCHI_NAIYOU15 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU15EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU15 =", value, "SOCHI_NAIYOU15");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU15NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU15 <>", value, "SOCHI_NAIYOU15");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU15GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU15 >", value, "SOCHI_NAIYOU15");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU15GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU15 >=", value, "SOCHI_NAIYOU15");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU15LessThan(String value) {
            addCriterion("SOCHI_NAIYOU15 <", value, "SOCHI_NAIYOU15");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU15LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU15 <=", value, "SOCHI_NAIYOU15");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU15Like(String value) {
            addCriterion("SOCHI_NAIYOU15 like", value, "SOCHI_NAIYOU15");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU15NotLike(String value) {
            addCriterion("SOCHI_NAIYOU15 not like", value, "SOCHI_NAIYOU15");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU15In(List<String> values) {
            addCriterion("SOCHI_NAIYOU15 in", values, "SOCHI_NAIYOU15");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU15NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU15 not in", values, "SOCHI_NAIYOU15");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU15Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU15 between", value1, value2, "SOCHI_NAIYOU15");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU15NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU15 not between", value1, value2, "SOCHI_NAIYOU15");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU16IsNull() {
            addCriterion("SOCHI_NAIYOU16 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU16IsNotNull() {
            addCriterion("SOCHI_NAIYOU16 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU16EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU16 =", value, "SOCHI_NAIYOU16");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU16NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU16 <>", value, "SOCHI_NAIYOU16");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU16GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU16 >", value, "SOCHI_NAIYOU16");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU16GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU16 >=", value, "SOCHI_NAIYOU16");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU16LessThan(String value) {
            addCriterion("SOCHI_NAIYOU16 <", value, "SOCHI_NAIYOU16");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU16LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU16 <=", value, "SOCHI_NAIYOU16");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU16Like(String value) {
            addCriterion("SOCHI_NAIYOU16 like", value, "SOCHI_NAIYOU16");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU16NotLike(String value) {
            addCriterion("SOCHI_NAIYOU16 not like", value, "SOCHI_NAIYOU16");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU16In(List<String> values) {
            addCriterion("SOCHI_NAIYOU16 in", values, "SOCHI_NAIYOU16");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU16NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU16 not in", values, "SOCHI_NAIYOU16");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU16Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU16 between", value1, value2, "SOCHI_NAIYOU16");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU16NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU16 not between", value1, value2, "SOCHI_NAIYOU16");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU17IsNull() {
            addCriterion("SOCHI_NAIYOU17 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU17IsNotNull() {
            addCriterion("SOCHI_NAIYOU17 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU17EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU17 =", value, "SOCHI_NAIYOU17");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU17NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU17 <>", value, "SOCHI_NAIYOU17");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU17GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU17 >", value, "SOCHI_NAIYOU17");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU17GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU17 >=", value, "SOCHI_NAIYOU17");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU17LessThan(String value) {
            addCriterion("SOCHI_NAIYOU17 <", value, "SOCHI_NAIYOU17");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU17LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU17 <=", value, "SOCHI_NAIYOU17");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU17Like(String value) {
            addCriterion("SOCHI_NAIYOU17 like", value, "SOCHI_NAIYOU17");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU17NotLike(String value) {
            addCriterion("SOCHI_NAIYOU17 not like", value, "SOCHI_NAIYOU17");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU17In(List<String> values) {
            addCriterion("SOCHI_NAIYOU17 in", values, "SOCHI_NAIYOU17");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU17NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU17 not in", values, "SOCHI_NAIYOU17");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU17Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU17 between", value1, value2, "SOCHI_NAIYOU17");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU17NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU17 not between", value1, value2, "SOCHI_NAIYOU17");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU18IsNull() {
            addCriterion("SOCHI_NAIYOU18 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU18IsNotNull() {
            addCriterion("SOCHI_NAIYOU18 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU18EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU18 =", value, "SOCHI_NAIYOU18");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU18NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU18 <>", value, "SOCHI_NAIYOU18");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU18GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU18 >", value, "SOCHI_NAIYOU18");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU18GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU18 >=", value, "SOCHI_NAIYOU18");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU18LessThan(String value) {
            addCriterion("SOCHI_NAIYOU18 <", value, "SOCHI_NAIYOU18");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU18LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU18 <=", value, "SOCHI_NAIYOU18");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU18Like(String value) {
            addCriterion("SOCHI_NAIYOU18 like", value, "SOCHI_NAIYOU18");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU18NotLike(String value) {
            addCriterion("SOCHI_NAIYOU18 not like", value, "SOCHI_NAIYOU18");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU18In(List<String> values) {
            addCriterion("SOCHI_NAIYOU18 in", values, "SOCHI_NAIYOU18");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU18NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU18 not in", values, "SOCHI_NAIYOU18");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU18Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU18 between", value1, value2, "SOCHI_NAIYOU18");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU18NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU18 not between", value1, value2, "SOCHI_NAIYOU18");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU19IsNull() {
            addCriterion("SOCHI_NAIYOU19 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU19IsNotNull() {
            addCriterion("SOCHI_NAIYOU19 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU19EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU19 =", value, "SOCHI_NAIYOU19");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU19NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU19 <>", value, "SOCHI_NAIYOU19");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU19GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU19 >", value, "SOCHI_NAIYOU19");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU19GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU19 >=", value, "SOCHI_NAIYOU19");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU19LessThan(String value) {
            addCriterion("SOCHI_NAIYOU19 <", value, "SOCHI_NAIYOU19");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU19LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU19 <=", value, "SOCHI_NAIYOU19");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU19Like(String value) {
            addCriterion("SOCHI_NAIYOU19 like", value, "SOCHI_NAIYOU19");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU19NotLike(String value) {
            addCriterion("SOCHI_NAIYOU19 not like", value, "SOCHI_NAIYOU19");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU19In(List<String> values) {
            addCriterion("SOCHI_NAIYOU19 in", values, "SOCHI_NAIYOU19");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU19NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU19 not in", values, "SOCHI_NAIYOU19");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU19Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU19 between", value1, value2, "SOCHI_NAIYOU19");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU19NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU19 not between", value1, value2, "SOCHI_NAIYOU19");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU20IsNull() {
            addCriterion("SOCHI_NAIYOU20 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU20IsNotNull() {
            addCriterion("SOCHI_NAIYOU20 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU20EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU20 =", value, "SOCHI_NAIYOU20");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU20NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU20 <>", value, "SOCHI_NAIYOU20");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU20GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU20 >", value, "SOCHI_NAIYOU20");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU20GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU20 >=", value, "SOCHI_NAIYOU20");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU20LessThan(String value) {
            addCriterion("SOCHI_NAIYOU20 <", value, "SOCHI_NAIYOU20");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU20LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU20 <=", value, "SOCHI_NAIYOU20");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU20Like(String value) {
            addCriterion("SOCHI_NAIYOU20 like", value, "SOCHI_NAIYOU20");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU20NotLike(String value) {
            addCriterion("SOCHI_NAIYOU20 not like", value, "SOCHI_NAIYOU20");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU20In(List<String> values) {
            addCriterion("SOCHI_NAIYOU20 in", values, "SOCHI_NAIYOU20");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU20NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU20 not in", values, "SOCHI_NAIYOU20");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU20Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU20 between", value1, value2, "SOCHI_NAIYOU20");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU20NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU20 not between", value1, value2, "SOCHI_NAIYOU20");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU21IsNull() {
            addCriterion("SOCHI_NAIYOU21 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU21IsNotNull() {
            addCriterion("SOCHI_NAIYOU21 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU21EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU21 =", value, "SOCHI_NAIYOU21");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU21NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU21 <>", value, "SOCHI_NAIYOU21");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU21GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU21 >", value, "SOCHI_NAIYOU21");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU21GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU21 >=", value, "SOCHI_NAIYOU21");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU21LessThan(String value) {
            addCriterion("SOCHI_NAIYOU21 <", value, "SOCHI_NAIYOU21");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU21LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU21 <=", value, "SOCHI_NAIYOU21");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU21Like(String value) {
            addCriterion("SOCHI_NAIYOU21 like", value, "SOCHI_NAIYOU21");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU21NotLike(String value) {
            addCriterion("SOCHI_NAIYOU21 not like", value, "SOCHI_NAIYOU21");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU21In(List<String> values) {
            addCriterion("SOCHI_NAIYOU21 in", values, "SOCHI_NAIYOU21");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU21NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU21 not in", values, "SOCHI_NAIYOU21");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU21Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU21 between", value1, value2, "SOCHI_NAIYOU21");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU21NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU21 not between", value1, value2, "SOCHI_NAIYOU21");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU22IsNull() {
            addCriterion("SOCHI_NAIYOU22 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU22IsNotNull() {
            addCriterion("SOCHI_NAIYOU22 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU22EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU22 =", value, "SOCHI_NAIYOU22");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU22NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU22 <>", value, "SOCHI_NAIYOU22");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU22GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU22 >", value, "SOCHI_NAIYOU22");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU22GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU22 >=", value, "SOCHI_NAIYOU22");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU22LessThan(String value) {
            addCriterion("SOCHI_NAIYOU22 <", value, "SOCHI_NAIYOU22");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU22LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU22 <=", value, "SOCHI_NAIYOU22");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU22Like(String value) {
            addCriterion("SOCHI_NAIYOU22 like", value, "SOCHI_NAIYOU22");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU22NotLike(String value) {
            addCriterion("SOCHI_NAIYOU22 not like", value, "SOCHI_NAIYOU22");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU22In(List<String> values) {
            addCriterion("SOCHI_NAIYOU22 in", values, "SOCHI_NAIYOU22");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU22NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU22 not in", values, "SOCHI_NAIYOU22");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU22Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU22 between", value1, value2, "SOCHI_NAIYOU22");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU22NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU22 not between", value1, value2, "SOCHI_NAIYOU22");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU23IsNull() {
            addCriterion("SOCHI_NAIYOU23 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU23IsNotNull() {
            addCriterion("SOCHI_NAIYOU23 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU23EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU23 =", value, "SOCHI_NAIYOU23");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU23NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU23 <>", value, "SOCHI_NAIYOU23");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU23GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU23 >", value, "SOCHI_NAIYOU23");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU23GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU23 >=", value, "SOCHI_NAIYOU23");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU23LessThan(String value) {
            addCriterion("SOCHI_NAIYOU23 <", value, "SOCHI_NAIYOU23");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU23LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU23 <=", value, "SOCHI_NAIYOU23");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU23Like(String value) {
            addCriterion("SOCHI_NAIYOU23 like", value, "SOCHI_NAIYOU23");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU23NotLike(String value) {
            addCriterion("SOCHI_NAIYOU23 not like", value, "SOCHI_NAIYOU23");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU23In(List<String> values) {
            addCriterion("SOCHI_NAIYOU23 in", values, "SOCHI_NAIYOU23");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU23NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU23 not in", values, "SOCHI_NAIYOU23");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU23Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU23 between", value1, value2, "SOCHI_NAIYOU23");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU23NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU23 not between", value1, value2, "SOCHI_NAIYOU23");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU24IsNull() {
            addCriterion("SOCHI_NAIYOU24 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU24IsNotNull() {
            addCriterion("SOCHI_NAIYOU24 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU24EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU24 =", value, "SOCHI_NAIYOU24");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU24NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU24 <>", value, "SOCHI_NAIYOU24");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU24GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU24 >", value, "SOCHI_NAIYOU24");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU24GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU24 >=", value, "SOCHI_NAIYOU24");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU24LessThan(String value) {
            addCriterion("SOCHI_NAIYOU24 <", value, "SOCHI_NAIYOU24");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU24LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU24 <=", value, "SOCHI_NAIYOU24");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU24Like(String value) {
            addCriterion("SOCHI_NAIYOU24 like", value, "SOCHI_NAIYOU24");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU24NotLike(String value) {
            addCriterion("SOCHI_NAIYOU24 not like", value, "SOCHI_NAIYOU24");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU24In(List<String> values) {
            addCriterion("SOCHI_NAIYOU24 in", values, "SOCHI_NAIYOU24");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU24NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU24 not in", values, "SOCHI_NAIYOU24");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU24Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU24 between", value1, value2, "SOCHI_NAIYOU24");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU24NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU24 not between", value1, value2, "SOCHI_NAIYOU24");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU25IsNull() {
            addCriterion("SOCHI_NAIYOU25 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU25IsNotNull() {
            addCriterion("SOCHI_NAIYOU25 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU25EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU25 =", value, "SOCHI_NAIYOU25");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU25NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU25 <>", value, "SOCHI_NAIYOU25");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU25GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU25 >", value, "SOCHI_NAIYOU25");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU25GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU25 >=", value, "SOCHI_NAIYOU25");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU25LessThan(String value) {
            addCriterion("SOCHI_NAIYOU25 <", value, "SOCHI_NAIYOU25");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU25LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU25 <=", value, "SOCHI_NAIYOU25");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU25Like(String value) {
            addCriterion("SOCHI_NAIYOU25 like", value, "SOCHI_NAIYOU25");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU25NotLike(String value) {
            addCriterion("SOCHI_NAIYOU25 not like", value, "SOCHI_NAIYOU25");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU25In(List<String> values) {
            addCriterion("SOCHI_NAIYOU25 in", values, "SOCHI_NAIYOU25");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU25NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU25 not in", values, "SOCHI_NAIYOU25");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU25Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU25 between", value1, value2, "SOCHI_NAIYOU25");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU25NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU25 not between", value1, value2, "SOCHI_NAIYOU25");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU26IsNull() {
            addCriterion("SOCHI_NAIYOU26 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU26IsNotNull() {
            addCriterion("SOCHI_NAIYOU26 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU26EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU26 =", value, "SOCHI_NAIYOU26");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU26NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU26 <>", value, "SOCHI_NAIYOU26");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU26GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU26 >", value, "SOCHI_NAIYOU26");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU26GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU26 >=", value, "SOCHI_NAIYOU26");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU26LessThan(String value) {
            addCriterion("SOCHI_NAIYOU26 <", value, "SOCHI_NAIYOU26");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU26LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU26 <=", value, "SOCHI_NAIYOU26");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU26Like(String value) {
            addCriterion("SOCHI_NAIYOU26 like", value, "SOCHI_NAIYOU26");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU26NotLike(String value) {
            addCriterion("SOCHI_NAIYOU26 not like", value, "SOCHI_NAIYOU26");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU26In(List<String> values) {
            addCriterion("SOCHI_NAIYOU26 in", values, "SOCHI_NAIYOU26");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU26NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU26 not in", values, "SOCHI_NAIYOU26");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU26Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU26 between", value1, value2, "SOCHI_NAIYOU26");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU26NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU26 not between", value1, value2, "SOCHI_NAIYOU26");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU27IsNull() {
            addCriterion("SOCHI_NAIYOU27 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU27IsNotNull() {
            addCriterion("SOCHI_NAIYOU27 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU27EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU27 =", value, "SOCHI_NAIYOU27");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU27NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU27 <>", value, "SOCHI_NAIYOU27");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU27GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU27 >", value, "SOCHI_NAIYOU27");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU27GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU27 >=", value, "SOCHI_NAIYOU27");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU27LessThan(String value) {
            addCriterion("SOCHI_NAIYOU27 <", value, "SOCHI_NAIYOU27");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU27LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU27 <=", value, "SOCHI_NAIYOU27");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU27Like(String value) {
            addCriterion("SOCHI_NAIYOU27 like", value, "SOCHI_NAIYOU27");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU27NotLike(String value) {
            addCriterion("SOCHI_NAIYOU27 not like", value, "SOCHI_NAIYOU27");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU27In(List<String> values) {
            addCriterion("SOCHI_NAIYOU27 in", values, "SOCHI_NAIYOU27");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU27NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU27 not in", values, "SOCHI_NAIYOU27");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU27Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU27 between", value1, value2, "SOCHI_NAIYOU27");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU27NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU27 not between", value1, value2, "SOCHI_NAIYOU27");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU28IsNull() {
            addCriterion("SOCHI_NAIYOU28 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU28IsNotNull() {
            addCriterion("SOCHI_NAIYOU28 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU28EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU28 =", value, "SOCHI_NAIYOU28");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU28NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU28 <>", value, "SOCHI_NAIYOU28");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU28GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU28 >", value, "SOCHI_NAIYOU28");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU28GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU28 >=", value, "SOCHI_NAIYOU28");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU28LessThan(String value) {
            addCriterion("SOCHI_NAIYOU28 <", value, "SOCHI_NAIYOU28");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU28LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU28 <=", value, "SOCHI_NAIYOU28");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU28Like(String value) {
            addCriterion("SOCHI_NAIYOU28 like", value, "SOCHI_NAIYOU28");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU28NotLike(String value) {
            addCriterion("SOCHI_NAIYOU28 not like", value, "SOCHI_NAIYOU28");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU28In(List<String> values) {
            addCriterion("SOCHI_NAIYOU28 in", values, "SOCHI_NAIYOU28");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU28NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU28 not in", values, "SOCHI_NAIYOU28");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU28Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU28 between", value1, value2, "SOCHI_NAIYOU28");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU28NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU28 not between", value1, value2, "SOCHI_NAIYOU28");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU29IsNull() {
            addCriterion("SOCHI_NAIYOU29 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU29IsNotNull() {
            addCriterion("SOCHI_NAIYOU29 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU29EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU29 =", value, "SOCHI_NAIYOU29");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU29NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU29 <>", value, "SOCHI_NAIYOU29");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU29GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU29 >", value, "SOCHI_NAIYOU29");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU29GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU29 >=", value, "SOCHI_NAIYOU29");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU29LessThan(String value) {
            addCriterion("SOCHI_NAIYOU29 <", value, "SOCHI_NAIYOU29");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU29LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU29 <=", value, "SOCHI_NAIYOU29");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU29Like(String value) {
            addCriterion("SOCHI_NAIYOU29 like", value, "SOCHI_NAIYOU29");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU29NotLike(String value) {
            addCriterion("SOCHI_NAIYOU29 not like", value, "SOCHI_NAIYOU29");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU29In(List<String> values) {
            addCriterion("SOCHI_NAIYOU29 in", values, "SOCHI_NAIYOU29");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU29NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU29 not in", values, "SOCHI_NAIYOU29");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU29Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU29 between", value1, value2, "SOCHI_NAIYOU29");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU29NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU29 not between", value1, value2, "SOCHI_NAIYOU29");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU30IsNull() {
            addCriterion("SOCHI_NAIYOU30 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU30IsNotNull() {
            addCriterion("SOCHI_NAIYOU30 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU30EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU30 =", value, "SOCHI_NAIYOU30");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU30NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU30 <>", value, "SOCHI_NAIYOU30");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU30GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU30 >", value, "SOCHI_NAIYOU30");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU30GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU30 >=", value, "SOCHI_NAIYOU30");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU30LessThan(String value) {
            addCriterion("SOCHI_NAIYOU30 <", value, "SOCHI_NAIYOU30");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU30LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU30 <=", value, "SOCHI_NAIYOU30");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU30Like(String value) {
            addCriterion("SOCHI_NAIYOU30 like", value, "SOCHI_NAIYOU30");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU30NotLike(String value) {
            addCriterion("SOCHI_NAIYOU30 not like", value, "SOCHI_NAIYOU30");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU30In(List<String> values) {
            addCriterion("SOCHI_NAIYOU30 in", values, "SOCHI_NAIYOU30");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU30NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU30 not in", values, "SOCHI_NAIYOU30");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU30Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU30 between", value1, value2, "SOCHI_NAIYOU30");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU30NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU30 not between", value1, value2, "SOCHI_NAIYOU30");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU31IsNull() {
            addCriterion("SOCHI_NAIYOU31 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU31IsNotNull() {
            addCriterion("SOCHI_NAIYOU31 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU31EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU31 =", value, "SOCHI_NAIYOU31");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU31NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU31 <>", value, "SOCHI_NAIYOU31");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU31GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU31 >", value, "SOCHI_NAIYOU31");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU31GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU31 >=", value, "SOCHI_NAIYOU31");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU31LessThan(String value) {
            addCriterion("SOCHI_NAIYOU31 <", value, "SOCHI_NAIYOU31");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU31LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU31 <=", value, "SOCHI_NAIYOU31");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU31Like(String value) {
            addCriterion("SOCHI_NAIYOU31 like", value, "SOCHI_NAIYOU31");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU31NotLike(String value) {
            addCriterion("SOCHI_NAIYOU31 not like", value, "SOCHI_NAIYOU31");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU31In(List<String> values) {
            addCriterion("SOCHI_NAIYOU31 in", values, "SOCHI_NAIYOU31");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU31NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU31 not in", values, "SOCHI_NAIYOU31");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU31Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU31 between", value1, value2, "SOCHI_NAIYOU31");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU31NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU31 not between", value1, value2, "SOCHI_NAIYOU31");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU32IsNull() {
            addCriterion("SOCHI_NAIYOU32 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU32IsNotNull() {
            addCriterion("SOCHI_NAIYOU32 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU32EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU32 =", value, "SOCHI_NAIYOU32");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU32NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU32 <>", value, "SOCHI_NAIYOU32");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU32GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU32 >", value, "SOCHI_NAIYOU32");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU32GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU32 >=", value, "SOCHI_NAIYOU32");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU32LessThan(String value) {
            addCriterion("SOCHI_NAIYOU32 <", value, "SOCHI_NAIYOU32");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU32LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU32 <=", value, "SOCHI_NAIYOU32");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU32Like(String value) {
            addCriterion("SOCHI_NAIYOU32 like", value, "SOCHI_NAIYOU32");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU32NotLike(String value) {
            addCriterion("SOCHI_NAIYOU32 not like", value, "SOCHI_NAIYOU32");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU32In(List<String> values) {
            addCriterion("SOCHI_NAIYOU32 in", values, "SOCHI_NAIYOU32");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU32NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU32 not in", values, "SOCHI_NAIYOU32");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU32Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU32 between", value1, value2, "SOCHI_NAIYOU32");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU32NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU32 not between", value1, value2, "SOCHI_NAIYOU32");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU33IsNull() {
            addCriterion("SOCHI_NAIYOU33 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU33IsNotNull() {
            addCriterion("SOCHI_NAIYOU33 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU33EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU33 =", value, "SOCHI_NAIYOU33");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU33NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU33 <>", value, "SOCHI_NAIYOU33");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU33GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU33 >", value, "SOCHI_NAIYOU33");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU33GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU33 >=", value, "SOCHI_NAIYOU33");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU33LessThan(String value) {
            addCriterion("SOCHI_NAIYOU33 <", value, "SOCHI_NAIYOU33");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU33LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU33 <=", value, "SOCHI_NAIYOU33");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU33Like(String value) {
            addCriterion("SOCHI_NAIYOU33 like", value, "SOCHI_NAIYOU33");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU33NotLike(String value) {
            addCriterion("SOCHI_NAIYOU33 not like", value, "SOCHI_NAIYOU33");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU33In(List<String> values) {
            addCriterion("SOCHI_NAIYOU33 in", values, "SOCHI_NAIYOU33");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU33NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU33 not in", values, "SOCHI_NAIYOU33");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU33Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU33 between", value1, value2, "SOCHI_NAIYOU33");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU33NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU33 not between", value1, value2, "SOCHI_NAIYOU33");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU34IsNull() {
            addCriterion("SOCHI_NAIYOU34 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU34IsNotNull() {
            addCriterion("SOCHI_NAIYOU34 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU34EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU34 =", value, "SOCHI_NAIYOU34");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU34NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU34 <>", value, "SOCHI_NAIYOU34");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU34GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU34 >", value, "SOCHI_NAIYOU34");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU34GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU34 >=", value, "SOCHI_NAIYOU34");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU34LessThan(String value) {
            addCriterion("SOCHI_NAIYOU34 <", value, "SOCHI_NAIYOU34");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU34LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU34 <=", value, "SOCHI_NAIYOU34");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU34Like(String value) {
            addCriterion("SOCHI_NAIYOU34 like", value, "SOCHI_NAIYOU34");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU34NotLike(String value) {
            addCriterion("SOCHI_NAIYOU34 not like", value, "SOCHI_NAIYOU34");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU34In(List<String> values) {
            addCriterion("SOCHI_NAIYOU34 in", values, "SOCHI_NAIYOU34");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU34NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU34 not in", values, "SOCHI_NAIYOU34");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU34Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU34 between", value1, value2, "SOCHI_NAIYOU34");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU34NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU34 not between", value1, value2, "SOCHI_NAIYOU34");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU35IsNull() {
            addCriterion("SOCHI_NAIYOU35 is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU35IsNotNull() {
            addCriterion("SOCHI_NAIYOU35 is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU35EqualTo(String value) {
            addCriterion("SOCHI_NAIYOU35 =", value, "SOCHI_NAIYOU35");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU35NotEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU35 <>", value, "SOCHI_NAIYOU35");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU35GreaterThan(String value) {
            addCriterion("SOCHI_NAIYOU35 >", value, "SOCHI_NAIYOU35");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU35GreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU35 >=", value, "SOCHI_NAIYOU35");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU35LessThan(String value) {
            addCriterion("SOCHI_NAIYOU35 <", value, "SOCHI_NAIYOU35");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU35LessThanOrEqualTo(String value) {
            addCriterion("SOCHI_NAIYOU35 <=", value, "SOCHI_NAIYOU35");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU35Like(String value) {
            addCriterion("SOCHI_NAIYOU35 like", value, "SOCHI_NAIYOU35");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU35NotLike(String value) {
            addCriterion("SOCHI_NAIYOU35 not like", value, "SOCHI_NAIYOU35");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU35In(List<String> values) {
            addCriterion("SOCHI_NAIYOU35 in", values, "SOCHI_NAIYOU35");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU35NotIn(List<String> values) {
            addCriterion("SOCHI_NAIYOU35 not in", values, "SOCHI_NAIYOU35");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU35Between(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU35 between", value1, value2, "SOCHI_NAIYOU35");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU35NotBetween(String value1, String value2) {
            addCriterion("SOCHI_NAIYOU35 not between", value1, value2, "SOCHI_NAIYOU35");
            return (Criteria) this;
        }

        public Criteria andKEKKA01IsNull() {
            addCriterion("KEKKA01 is null");
            return (Criteria) this;
        }

        public Criteria andKEKKA01IsNotNull() {
            addCriterion("KEKKA01 is not null");
            return (Criteria) this;
        }

        public Criteria andKEKKA01EqualTo(String value) {
            addCriterion("KEKKA01 =", value, "KEKKA01");
            return (Criteria) this;
        }

        public Criteria andKEKKA01NotEqualTo(String value) {
            addCriterion("KEKKA01 <>", value, "KEKKA01");
            return (Criteria) this;
        }

        public Criteria andKEKKA01GreaterThan(String value) {
            addCriterion("KEKKA01 >", value, "KEKKA01");
            return (Criteria) this;
        }

        public Criteria andKEKKA01GreaterThanOrEqualTo(String value) {
            addCriterion("KEKKA01 >=", value, "KEKKA01");
            return (Criteria) this;
        }

        public Criteria andKEKKA01LessThan(String value) {
            addCriterion("KEKKA01 <", value, "KEKKA01");
            return (Criteria) this;
        }

        public Criteria andKEKKA01LessThanOrEqualTo(String value) {
            addCriterion("KEKKA01 <=", value, "KEKKA01");
            return (Criteria) this;
        }

        public Criteria andKEKKA01Like(String value) {
            addCriterion("KEKKA01 like", value, "KEKKA01");
            return (Criteria) this;
        }

        public Criteria andKEKKA01NotLike(String value) {
            addCriterion("KEKKA01 not like", value, "KEKKA01");
            return (Criteria) this;
        }

        public Criteria andKEKKA01In(List<String> values) {
            addCriterion("KEKKA01 in", values, "KEKKA01");
            return (Criteria) this;
        }

        public Criteria andKEKKA01NotIn(List<String> values) {
            addCriterion("KEKKA01 not in", values, "KEKKA01");
            return (Criteria) this;
        }

        public Criteria andKEKKA01Between(String value1, String value2) {
            addCriterion("KEKKA01 between", value1, value2, "KEKKA01");
            return (Criteria) this;
        }

        public Criteria andKEKKA01NotBetween(String value1, String value2) {
            addCriterion("KEKKA01 not between", value1, value2, "KEKKA01");
            return (Criteria) this;
        }

        public Criteria andKEKKA02IsNull() {
            addCriterion("KEKKA02 is null");
            return (Criteria) this;
        }

        public Criteria andKEKKA02IsNotNull() {
            addCriterion("KEKKA02 is not null");
            return (Criteria) this;
        }

        public Criteria andKEKKA02EqualTo(String value) {
            addCriterion("KEKKA02 =", value, "KEKKA02");
            return (Criteria) this;
        }

        public Criteria andKEKKA02NotEqualTo(String value) {
            addCriterion("KEKKA02 <>", value, "KEKKA02");
            return (Criteria) this;
        }

        public Criteria andKEKKA02GreaterThan(String value) {
            addCriterion("KEKKA02 >", value, "KEKKA02");
            return (Criteria) this;
        }

        public Criteria andKEKKA02GreaterThanOrEqualTo(String value) {
            addCriterion("KEKKA02 >=", value, "KEKKA02");
            return (Criteria) this;
        }

        public Criteria andKEKKA02LessThan(String value) {
            addCriterion("KEKKA02 <", value, "KEKKA02");
            return (Criteria) this;
        }

        public Criteria andKEKKA02LessThanOrEqualTo(String value) {
            addCriterion("KEKKA02 <=", value, "KEKKA02");
            return (Criteria) this;
        }

        public Criteria andKEKKA02Like(String value) {
            addCriterion("KEKKA02 like", value, "KEKKA02");
            return (Criteria) this;
        }

        public Criteria andKEKKA02NotLike(String value) {
            addCriterion("KEKKA02 not like", value, "KEKKA02");
            return (Criteria) this;
        }

        public Criteria andKEKKA02In(List<String> values) {
            addCriterion("KEKKA02 in", values, "KEKKA02");
            return (Criteria) this;
        }

        public Criteria andKEKKA02NotIn(List<String> values) {
            addCriterion("KEKKA02 not in", values, "KEKKA02");
            return (Criteria) this;
        }

        public Criteria andKEKKA02Between(String value1, String value2) {
            addCriterion("KEKKA02 between", value1, value2, "KEKKA02");
            return (Criteria) this;
        }

        public Criteria andKEKKA02NotBetween(String value1, String value2) {
            addCriterion("KEKKA02 not between", value1, value2, "KEKKA02");
            return (Criteria) this;
        }

        public Criteria andKEKKA03IsNull() {
            addCriterion("KEKKA03 is null");
            return (Criteria) this;
        }

        public Criteria andKEKKA03IsNotNull() {
            addCriterion("KEKKA03 is not null");
            return (Criteria) this;
        }

        public Criteria andKEKKA03EqualTo(String value) {
            addCriterion("KEKKA03 =", value, "KEKKA03");
            return (Criteria) this;
        }

        public Criteria andKEKKA03NotEqualTo(String value) {
            addCriterion("KEKKA03 <>", value, "KEKKA03");
            return (Criteria) this;
        }

        public Criteria andKEKKA03GreaterThan(String value) {
            addCriterion("KEKKA03 >", value, "KEKKA03");
            return (Criteria) this;
        }

        public Criteria andKEKKA03GreaterThanOrEqualTo(String value) {
            addCriterion("KEKKA03 >=", value, "KEKKA03");
            return (Criteria) this;
        }

        public Criteria andKEKKA03LessThan(String value) {
            addCriterion("KEKKA03 <", value, "KEKKA03");
            return (Criteria) this;
        }

        public Criteria andKEKKA03LessThanOrEqualTo(String value) {
            addCriterion("KEKKA03 <=", value, "KEKKA03");
            return (Criteria) this;
        }

        public Criteria andKEKKA03Like(String value) {
            addCriterion("KEKKA03 like", value, "KEKKA03");
            return (Criteria) this;
        }

        public Criteria andKEKKA03NotLike(String value) {
            addCriterion("KEKKA03 not like", value, "KEKKA03");
            return (Criteria) this;
        }

        public Criteria andKEKKA03In(List<String> values) {
            addCriterion("KEKKA03 in", values, "KEKKA03");
            return (Criteria) this;
        }

        public Criteria andKEKKA03NotIn(List<String> values) {
            addCriterion("KEKKA03 not in", values, "KEKKA03");
            return (Criteria) this;
        }

        public Criteria andKEKKA03Between(String value1, String value2) {
            addCriterion("KEKKA03 between", value1, value2, "KEKKA03");
            return (Criteria) this;
        }

        public Criteria andKEKKA03NotBetween(String value1, String value2) {
            addCriterion("KEKKA03 not between", value1, value2, "KEKKA03");
            return (Criteria) this;
        }

        public Criteria andKEKKA04IsNull() {
            addCriterion("KEKKA04 is null");
            return (Criteria) this;
        }

        public Criteria andKEKKA04IsNotNull() {
            addCriterion("KEKKA04 is not null");
            return (Criteria) this;
        }

        public Criteria andKEKKA04EqualTo(String value) {
            addCriterion("KEKKA04 =", value, "KEKKA04");
            return (Criteria) this;
        }

        public Criteria andKEKKA04NotEqualTo(String value) {
            addCriterion("KEKKA04 <>", value, "KEKKA04");
            return (Criteria) this;
        }

        public Criteria andKEKKA04GreaterThan(String value) {
            addCriterion("KEKKA04 >", value, "KEKKA04");
            return (Criteria) this;
        }

        public Criteria andKEKKA04GreaterThanOrEqualTo(String value) {
            addCriterion("KEKKA04 >=", value, "KEKKA04");
            return (Criteria) this;
        }

        public Criteria andKEKKA04LessThan(String value) {
            addCriterion("KEKKA04 <", value, "KEKKA04");
            return (Criteria) this;
        }

        public Criteria andKEKKA04LessThanOrEqualTo(String value) {
            addCriterion("KEKKA04 <=", value, "KEKKA04");
            return (Criteria) this;
        }

        public Criteria andKEKKA04Like(String value) {
            addCriterion("KEKKA04 like", value, "KEKKA04");
            return (Criteria) this;
        }

        public Criteria andKEKKA04NotLike(String value) {
            addCriterion("KEKKA04 not like", value, "KEKKA04");
            return (Criteria) this;
        }

        public Criteria andKEKKA04In(List<String> values) {
            addCriterion("KEKKA04 in", values, "KEKKA04");
            return (Criteria) this;
        }

        public Criteria andKEKKA04NotIn(List<String> values) {
            addCriterion("KEKKA04 not in", values, "KEKKA04");
            return (Criteria) this;
        }

        public Criteria andKEKKA04Between(String value1, String value2) {
            addCriterion("KEKKA04 between", value1, value2, "KEKKA04");
            return (Criteria) this;
        }

        public Criteria andKEKKA04NotBetween(String value1, String value2) {
            addCriterion("KEKKA04 not between", value1, value2, "KEKKA04");
            return (Criteria) this;
        }

        public Criteria andKEKKA05IsNull() {
            addCriterion("KEKKA05 is null");
            return (Criteria) this;
        }

        public Criteria andKEKKA05IsNotNull() {
            addCriterion("KEKKA05 is not null");
            return (Criteria) this;
        }

        public Criteria andKEKKA05EqualTo(String value) {
            addCriterion("KEKKA05 =", value, "KEKKA05");
            return (Criteria) this;
        }

        public Criteria andKEKKA05NotEqualTo(String value) {
            addCriterion("KEKKA05 <>", value, "KEKKA05");
            return (Criteria) this;
        }

        public Criteria andKEKKA05GreaterThan(String value) {
            addCriterion("KEKKA05 >", value, "KEKKA05");
            return (Criteria) this;
        }

        public Criteria andKEKKA05GreaterThanOrEqualTo(String value) {
            addCriterion("KEKKA05 >=", value, "KEKKA05");
            return (Criteria) this;
        }

        public Criteria andKEKKA05LessThan(String value) {
            addCriterion("KEKKA05 <", value, "KEKKA05");
            return (Criteria) this;
        }

        public Criteria andKEKKA05LessThanOrEqualTo(String value) {
            addCriterion("KEKKA05 <=", value, "KEKKA05");
            return (Criteria) this;
        }

        public Criteria andKEKKA05Like(String value) {
            addCriterion("KEKKA05 like", value, "KEKKA05");
            return (Criteria) this;
        }

        public Criteria andKEKKA05NotLike(String value) {
            addCriterion("KEKKA05 not like", value, "KEKKA05");
            return (Criteria) this;
        }

        public Criteria andKEKKA05In(List<String> values) {
            addCriterion("KEKKA05 in", values, "KEKKA05");
            return (Criteria) this;
        }

        public Criteria andKEKKA05NotIn(List<String> values) {
            addCriterion("KEKKA05 not in", values, "KEKKA05");
            return (Criteria) this;
        }

        public Criteria andKEKKA05Between(String value1, String value2) {
            addCriterion("KEKKA05 between", value1, value2, "KEKKA05");
            return (Criteria) this;
        }

        public Criteria andKEKKA05NotBetween(String value1, String value2) {
            addCriterion("KEKKA05 not between", value1, value2, "KEKKA05");
            return (Criteria) this;
        }

        public Criteria andKEKKA06IsNull() {
            addCriterion("KEKKA06 is null");
            return (Criteria) this;
        }

        public Criteria andKEKKA06IsNotNull() {
            addCriterion("KEKKA06 is not null");
            return (Criteria) this;
        }

        public Criteria andKEKKA06EqualTo(String value) {
            addCriterion("KEKKA06 =", value, "KEKKA06");
            return (Criteria) this;
        }

        public Criteria andKEKKA06NotEqualTo(String value) {
            addCriterion("KEKKA06 <>", value, "KEKKA06");
            return (Criteria) this;
        }

        public Criteria andKEKKA06GreaterThan(String value) {
            addCriterion("KEKKA06 >", value, "KEKKA06");
            return (Criteria) this;
        }

        public Criteria andKEKKA06GreaterThanOrEqualTo(String value) {
            addCriterion("KEKKA06 >=", value, "KEKKA06");
            return (Criteria) this;
        }

        public Criteria andKEKKA06LessThan(String value) {
            addCriterion("KEKKA06 <", value, "KEKKA06");
            return (Criteria) this;
        }

        public Criteria andKEKKA06LessThanOrEqualTo(String value) {
            addCriterion("KEKKA06 <=", value, "KEKKA06");
            return (Criteria) this;
        }

        public Criteria andKEKKA06Like(String value) {
            addCriterion("KEKKA06 like", value, "KEKKA06");
            return (Criteria) this;
        }

        public Criteria andKEKKA06NotLike(String value) {
            addCriterion("KEKKA06 not like", value, "KEKKA06");
            return (Criteria) this;
        }

        public Criteria andKEKKA06In(List<String> values) {
            addCriterion("KEKKA06 in", values, "KEKKA06");
            return (Criteria) this;
        }

        public Criteria andKEKKA06NotIn(List<String> values) {
            addCriterion("KEKKA06 not in", values, "KEKKA06");
            return (Criteria) this;
        }

        public Criteria andKEKKA06Between(String value1, String value2) {
            addCriterion("KEKKA06 between", value1, value2, "KEKKA06");
            return (Criteria) this;
        }

        public Criteria andKEKKA06NotBetween(String value1, String value2) {
            addCriterion("KEKKA06 not between", value1, value2, "KEKKA06");
            return (Criteria) this;
        }

        public Criteria andKEKKA07IsNull() {
            addCriterion("KEKKA07 is null");
            return (Criteria) this;
        }

        public Criteria andKEKKA07IsNotNull() {
            addCriterion("KEKKA07 is not null");
            return (Criteria) this;
        }

        public Criteria andKEKKA07EqualTo(String value) {
            addCriterion("KEKKA07 =", value, "KEKKA07");
            return (Criteria) this;
        }

        public Criteria andKEKKA07NotEqualTo(String value) {
            addCriterion("KEKKA07 <>", value, "KEKKA07");
            return (Criteria) this;
        }

        public Criteria andKEKKA07GreaterThan(String value) {
            addCriterion("KEKKA07 >", value, "KEKKA07");
            return (Criteria) this;
        }

        public Criteria andKEKKA07GreaterThanOrEqualTo(String value) {
            addCriterion("KEKKA07 >=", value, "KEKKA07");
            return (Criteria) this;
        }

        public Criteria andKEKKA07LessThan(String value) {
            addCriterion("KEKKA07 <", value, "KEKKA07");
            return (Criteria) this;
        }

        public Criteria andKEKKA07LessThanOrEqualTo(String value) {
            addCriterion("KEKKA07 <=", value, "KEKKA07");
            return (Criteria) this;
        }

        public Criteria andKEKKA07Like(String value) {
            addCriterion("KEKKA07 like", value, "KEKKA07");
            return (Criteria) this;
        }

        public Criteria andKEKKA07NotLike(String value) {
            addCriterion("KEKKA07 not like", value, "KEKKA07");
            return (Criteria) this;
        }

        public Criteria andKEKKA07In(List<String> values) {
            addCriterion("KEKKA07 in", values, "KEKKA07");
            return (Criteria) this;
        }

        public Criteria andKEKKA07NotIn(List<String> values) {
            addCriterion("KEKKA07 not in", values, "KEKKA07");
            return (Criteria) this;
        }

        public Criteria andKEKKA07Between(String value1, String value2) {
            addCriterion("KEKKA07 between", value1, value2, "KEKKA07");
            return (Criteria) this;
        }

        public Criteria andKEKKA07NotBetween(String value1, String value2) {
            addCriterion("KEKKA07 not between", value1, value2, "KEKKA07");
            return (Criteria) this;
        }

        public Criteria andKEKKA08IsNull() {
            addCriterion("KEKKA08 is null");
            return (Criteria) this;
        }

        public Criteria andKEKKA08IsNotNull() {
            addCriterion("KEKKA08 is not null");
            return (Criteria) this;
        }

        public Criteria andKEKKA08EqualTo(String value) {
            addCriterion("KEKKA08 =", value, "KEKKA08");
            return (Criteria) this;
        }

        public Criteria andKEKKA08NotEqualTo(String value) {
            addCriterion("KEKKA08 <>", value, "KEKKA08");
            return (Criteria) this;
        }

        public Criteria andKEKKA08GreaterThan(String value) {
            addCriterion("KEKKA08 >", value, "KEKKA08");
            return (Criteria) this;
        }

        public Criteria andKEKKA08GreaterThanOrEqualTo(String value) {
            addCriterion("KEKKA08 >=", value, "KEKKA08");
            return (Criteria) this;
        }

        public Criteria andKEKKA08LessThan(String value) {
            addCriterion("KEKKA08 <", value, "KEKKA08");
            return (Criteria) this;
        }

        public Criteria andKEKKA08LessThanOrEqualTo(String value) {
            addCriterion("KEKKA08 <=", value, "KEKKA08");
            return (Criteria) this;
        }

        public Criteria andKEKKA08Like(String value) {
            addCriterion("KEKKA08 like", value, "KEKKA08");
            return (Criteria) this;
        }

        public Criteria andKEKKA08NotLike(String value) {
            addCriterion("KEKKA08 not like", value, "KEKKA08");
            return (Criteria) this;
        }

        public Criteria andKEKKA08In(List<String> values) {
            addCriterion("KEKKA08 in", values, "KEKKA08");
            return (Criteria) this;
        }

        public Criteria andKEKKA08NotIn(List<String> values) {
            addCriterion("KEKKA08 not in", values, "KEKKA08");
            return (Criteria) this;
        }

        public Criteria andKEKKA08Between(String value1, String value2) {
            addCriterion("KEKKA08 between", value1, value2, "KEKKA08");
            return (Criteria) this;
        }

        public Criteria andKEKKA08NotBetween(String value1, String value2) {
            addCriterion("KEKKA08 not between", value1, value2, "KEKKA08");
            return (Criteria) this;
        }

        public Criteria andKEKKA09IsNull() {
            addCriterion("KEKKA09 is null");
            return (Criteria) this;
        }

        public Criteria andKEKKA09IsNotNull() {
            addCriterion("KEKKA09 is not null");
            return (Criteria) this;
        }

        public Criteria andKEKKA09EqualTo(String value) {
            addCriterion("KEKKA09 =", value, "KEKKA09");
            return (Criteria) this;
        }

        public Criteria andKEKKA09NotEqualTo(String value) {
            addCriterion("KEKKA09 <>", value, "KEKKA09");
            return (Criteria) this;
        }

        public Criteria andKEKKA09GreaterThan(String value) {
            addCriterion("KEKKA09 >", value, "KEKKA09");
            return (Criteria) this;
        }

        public Criteria andKEKKA09GreaterThanOrEqualTo(String value) {
            addCriterion("KEKKA09 >=", value, "KEKKA09");
            return (Criteria) this;
        }

        public Criteria andKEKKA09LessThan(String value) {
            addCriterion("KEKKA09 <", value, "KEKKA09");
            return (Criteria) this;
        }

        public Criteria andKEKKA09LessThanOrEqualTo(String value) {
            addCriterion("KEKKA09 <=", value, "KEKKA09");
            return (Criteria) this;
        }

        public Criteria andKEKKA09Like(String value) {
            addCriterion("KEKKA09 like", value, "KEKKA09");
            return (Criteria) this;
        }

        public Criteria andKEKKA09NotLike(String value) {
            addCriterion("KEKKA09 not like", value, "KEKKA09");
            return (Criteria) this;
        }

        public Criteria andKEKKA09In(List<String> values) {
            addCriterion("KEKKA09 in", values, "KEKKA09");
            return (Criteria) this;
        }

        public Criteria andKEKKA09NotIn(List<String> values) {
            addCriterion("KEKKA09 not in", values, "KEKKA09");
            return (Criteria) this;
        }

        public Criteria andKEKKA09Between(String value1, String value2) {
            addCriterion("KEKKA09 between", value1, value2, "KEKKA09");
            return (Criteria) this;
        }

        public Criteria andKEKKA09NotBetween(String value1, String value2) {
            addCriterion("KEKKA09 not between", value1, value2, "KEKKA09");
            return (Criteria) this;
        }

        public Criteria andKEKKA10IsNull() {
            addCriterion("KEKKA10 is null");
            return (Criteria) this;
        }

        public Criteria andKEKKA10IsNotNull() {
            addCriterion("KEKKA10 is not null");
            return (Criteria) this;
        }

        public Criteria andKEKKA10EqualTo(String value) {
            addCriterion("KEKKA10 =", value, "KEKKA10");
            return (Criteria) this;
        }

        public Criteria andKEKKA10NotEqualTo(String value) {
            addCriterion("KEKKA10 <>", value, "KEKKA10");
            return (Criteria) this;
        }

        public Criteria andKEKKA10GreaterThan(String value) {
            addCriterion("KEKKA10 >", value, "KEKKA10");
            return (Criteria) this;
        }

        public Criteria andKEKKA10GreaterThanOrEqualTo(String value) {
            addCriterion("KEKKA10 >=", value, "KEKKA10");
            return (Criteria) this;
        }

        public Criteria andKEKKA10LessThan(String value) {
            addCriterion("KEKKA10 <", value, "KEKKA10");
            return (Criteria) this;
        }

        public Criteria andKEKKA10LessThanOrEqualTo(String value) {
            addCriterion("KEKKA10 <=", value, "KEKKA10");
            return (Criteria) this;
        }

        public Criteria andKEKKA10Like(String value) {
            addCriterion("KEKKA10 like", value, "KEKKA10");
            return (Criteria) this;
        }

        public Criteria andKEKKA10NotLike(String value) {
            addCriterion("KEKKA10 not like", value, "KEKKA10");
            return (Criteria) this;
        }

        public Criteria andKEKKA10In(List<String> values) {
            addCriterion("KEKKA10 in", values, "KEKKA10");
            return (Criteria) this;
        }

        public Criteria andKEKKA10NotIn(List<String> values) {
            addCriterion("KEKKA10 not in", values, "KEKKA10");
            return (Criteria) this;
        }

        public Criteria andKEKKA10Between(String value1, String value2) {
            addCriterion("KEKKA10 between", value1, value2, "KEKKA10");
            return (Criteria) this;
        }

        public Criteria andKEKKA10NotBetween(String value1, String value2) {
            addCriterion("KEKKA10 not between", value1, value2, "KEKKA10");
            return (Criteria) this;
        }

        public Criteria andTIME01IsNull() {
            addCriterion("TIME01 is null");
            return (Criteria) this;
        }

        public Criteria andTIME01IsNotNull() {
            addCriterion("TIME01 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME01EqualTo(String value) {
            addCriterion("TIME01 =", value, "TIME01");
            return (Criteria) this;
        }

        public Criteria andTIME01NotEqualTo(String value) {
            addCriterion("TIME01 <>", value, "TIME01");
            return (Criteria) this;
        }

        public Criteria andTIME01GreaterThan(String value) {
            addCriterion("TIME01 >", value, "TIME01");
            return (Criteria) this;
        }

        public Criteria andTIME01GreaterThanOrEqualTo(String value) {
            addCriterion("TIME01 >=", value, "TIME01");
            return (Criteria) this;
        }

        public Criteria andTIME01LessThan(String value) {
            addCriterion("TIME01 <", value, "TIME01");
            return (Criteria) this;
        }

        public Criteria andTIME01LessThanOrEqualTo(String value) {
            addCriterion("TIME01 <=", value, "TIME01");
            return (Criteria) this;
        }

        public Criteria andTIME01Like(String value) {
            addCriterion("TIME01 like", value, "TIME01");
            return (Criteria) this;
        }

        public Criteria andTIME01NotLike(String value) {
            addCriterion("TIME01 not like", value, "TIME01");
            return (Criteria) this;
        }

        public Criteria andTIME01In(List<String> values) {
            addCriterion("TIME01 in", values, "TIME01");
            return (Criteria) this;
        }

        public Criteria andTIME01NotIn(List<String> values) {
            addCriterion("TIME01 not in", values, "TIME01");
            return (Criteria) this;
        }

        public Criteria andTIME01Between(String value1, String value2) {
            addCriterion("TIME01 between", value1, value2, "TIME01");
            return (Criteria) this;
        }

        public Criteria andTIME01NotBetween(String value1, String value2) {
            addCriterion("TIME01 not between", value1, value2, "TIME01");
            return (Criteria) this;
        }

        public Criteria andTIME02IsNull() {
            addCriterion("TIME02 is null");
            return (Criteria) this;
        }

        public Criteria andTIME02IsNotNull() {
            addCriterion("TIME02 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME02EqualTo(String value) {
            addCriterion("TIME02 =", value, "TIME02");
            return (Criteria) this;
        }

        public Criteria andTIME02NotEqualTo(String value) {
            addCriterion("TIME02 <>", value, "TIME02");
            return (Criteria) this;
        }

        public Criteria andTIME02GreaterThan(String value) {
            addCriterion("TIME02 >", value, "TIME02");
            return (Criteria) this;
        }

        public Criteria andTIME02GreaterThanOrEqualTo(String value) {
            addCriterion("TIME02 >=", value, "TIME02");
            return (Criteria) this;
        }

        public Criteria andTIME02LessThan(String value) {
            addCriterion("TIME02 <", value, "TIME02");
            return (Criteria) this;
        }

        public Criteria andTIME02LessThanOrEqualTo(String value) {
            addCriterion("TIME02 <=", value, "TIME02");
            return (Criteria) this;
        }

        public Criteria andTIME02Like(String value) {
            addCriterion("TIME02 like", value, "TIME02");
            return (Criteria) this;
        }

        public Criteria andTIME02NotLike(String value) {
            addCriterion("TIME02 not like", value, "TIME02");
            return (Criteria) this;
        }

        public Criteria andTIME02In(List<String> values) {
            addCriterion("TIME02 in", values, "TIME02");
            return (Criteria) this;
        }

        public Criteria andTIME02NotIn(List<String> values) {
            addCriterion("TIME02 not in", values, "TIME02");
            return (Criteria) this;
        }

        public Criteria andTIME02Between(String value1, String value2) {
            addCriterion("TIME02 between", value1, value2, "TIME02");
            return (Criteria) this;
        }

        public Criteria andTIME02NotBetween(String value1, String value2) {
            addCriterion("TIME02 not between", value1, value2, "TIME02");
            return (Criteria) this;
        }

        public Criteria andTIME03IsNull() {
            addCriterion("TIME03 is null");
            return (Criteria) this;
        }

        public Criteria andTIME03IsNotNull() {
            addCriterion("TIME03 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME03EqualTo(String value) {
            addCriterion("TIME03 =", value, "TIME03");
            return (Criteria) this;
        }

        public Criteria andTIME03NotEqualTo(String value) {
            addCriterion("TIME03 <>", value, "TIME03");
            return (Criteria) this;
        }

        public Criteria andTIME03GreaterThan(String value) {
            addCriterion("TIME03 >", value, "TIME03");
            return (Criteria) this;
        }

        public Criteria andTIME03GreaterThanOrEqualTo(String value) {
            addCriterion("TIME03 >=", value, "TIME03");
            return (Criteria) this;
        }

        public Criteria andTIME03LessThan(String value) {
            addCriterion("TIME03 <", value, "TIME03");
            return (Criteria) this;
        }

        public Criteria andTIME03LessThanOrEqualTo(String value) {
            addCriterion("TIME03 <=", value, "TIME03");
            return (Criteria) this;
        }

        public Criteria andTIME03Like(String value) {
            addCriterion("TIME03 like", value, "TIME03");
            return (Criteria) this;
        }

        public Criteria andTIME03NotLike(String value) {
            addCriterion("TIME03 not like", value, "TIME03");
            return (Criteria) this;
        }

        public Criteria andTIME03In(List<String> values) {
            addCriterion("TIME03 in", values, "TIME03");
            return (Criteria) this;
        }

        public Criteria andTIME03NotIn(List<String> values) {
            addCriterion("TIME03 not in", values, "TIME03");
            return (Criteria) this;
        }

        public Criteria andTIME03Between(String value1, String value2) {
            addCriterion("TIME03 between", value1, value2, "TIME03");
            return (Criteria) this;
        }

        public Criteria andTIME03NotBetween(String value1, String value2) {
            addCriterion("TIME03 not between", value1, value2, "TIME03");
            return (Criteria) this;
        }

        public Criteria andTIME04IsNull() {
            addCriterion("TIME04 is null");
            return (Criteria) this;
        }

        public Criteria andTIME04IsNotNull() {
            addCriterion("TIME04 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME04EqualTo(String value) {
            addCriterion("TIME04 =", value, "TIME04");
            return (Criteria) this;
        }

        public Criteria andTIME04NotEqualTo(String value) {
            addCriterion("TIME04 <>", value, "TIME04");
            return (Criteria) this;
        }

        public Criteria andTIME04GreaterThan(String value) {
            addCriterion("TIME04 >", value, "TIME04");
            return (Criteria) this;
        }

        public Criteria andTIME04GreaterThanOrEqualTo(String value) {
            addCriterion("TIME04 >=", value, "TIME04");
            return (Criteria) this;
        }

        public Criteria andTIME04LessThan(String value) {
            addCriterion("TIME04 <", value, "TIME04");
            return (Criteria) this;
        }

        public Criteria andTIME04LessThanOrEqualTo(String value) {
            addCriterion("TIME04 <=", value, "TIME04");
            return (Criteria) this;
        }

        public Criteria andTIME04Like(String value) {
            addCriterion("TIME04 like", value, "TIME04");
            return (Criteria) this;
        }

        public Criteria andTIME04NotLike(String value) {
            addCriterion("TIME04 not like", value, "TIME04");
            return (Criteria) this;
        }

        public Criteria andTIME04In(List<String> values) {
            addCriterion("TIME04 in", values, "TIME04");
            return (Criteria) this;
        }

        public Criteria andTIME04NotIn(List<String> values) {
            addCriterion("TIME04 not in", values, "TIME04");
            return (Criteria) this;
        }

        public Criteria andTIME04Between(String value1, String value2) {
            addCriterion("TIME04 between", value1, value2, "TIME04");
            return (Criteria) this;
        }

        public Criteria andTIME04NotBetween(String value1, String value2) {
            addCriterion("TIME04 not between", value1, value2, "TIME04");
            return (Criteria) this;
        }

        public Criteria andTIME05IsNull() {
            addCriterion("TIME05 is null");
            return (Criteria) this;
        }

        public Criteria andTIME05IsNotNull() {
            addCriterion("TIME05 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME05EqualTo(String value) {
            addCriterion("TIME05 =", value, "TIME05");
            return (Criteria) this;
        }

        public Criteria andTIME05NotEqualTo(String value) {
            addCriterion("TIME05 <>", value, "TIME05");
            return (Criteria) this;
        }

        public Criteria andTIME05GreaterThan(String value) {
            addCriterion("TIME05 >", value, "TIME05");
            return (Criteria) this;
        }

        public Criteria andTIME05GreaterThanOrEqualTo(String value) {
            addCriterion("TIME05 >=", value, "TIME05");
            return (Criteria) this;
        }

        public Criteria andTIME05LessThan(String value) {
            addCriterion("TIME05 <", value, "TIME05");
            return (Criteria) this;
        }

        public Criteria andTIME05LessThanOrEqualTo(String value) {
            addCriterion("TIME05 <=", value, "TIME05");
            return (Criteria) this;
        }

        public Criteria andTIME05Like(String value) {
            addCriterion("TIME05 like", value, "TIME05");
            return (Criteria) this;
        }

        public Criteria andTIME05NotLike(String value) {
            addCriterion("TIME05 not like", value, "TIME05");
            return (Criteria) this;
        }

        public Criteria andTIME05In(List<String> values) {
            addCriterion("TIME05 in", values, "TIME05");
            return (Criteria) this;
        }

        public Criteria andTIME05NotIn(List<String> values) {
            addCriterion("TIME05 not in", values, "TIME05");
            return (Criteria) this;
        }

        public Criteria andTIME05Between(String value1, String value2) {
            addCriterion("TIME05 between", value1, value2, "TIME05");
            return (Criteria) this;
        }

        public Criteria andTIME05NotBetween(String value1, String value2) {
            addCriterion("TIME05 not between", value1, value2, "TIME05");
            return (Criteria) this;
        }

        public Criteria andTIME06IsNull() {
            addCriterion("TIME06 is null");
            return (Criteria) this;
        }

        public Criteria andTIME06IsNotNull() {
            addCriterion("TIME06 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME06EqualTo(String value) {
            addCriterion("TIME06 =", value, "TIME06");
            return (Criteria) this;
        }

        public Criteria andTIME06NotEqualTo(String value) {
            addCriterion("TIME06 <>", value, "TIME06");
            return (Criteria) this;
        }

        public Criteria andTIME06GreaterThan(String value) {
            addCriterion("TIME06 >", value, "TIME06");
            return (Criteria) this;
        }

        public Criteria andTIME06GreaterThanOrEqualTo(String value) {
            addCriterion("TIME06 >=", value, "TIME06");
            return (Criteria) this;
        }

        public Criteria andTIME06LessThan(String value) {
            addCriterion("TIME06 <", value, "TIME06");
            return (Criteria) this;
        }

        public Criteria andTIME06LessThanOrEqualTo(String value) {
            addCriterion("TIME06 <=", value, "TIME06");
            return (Criteria) this;
        }

        public Criteria andTIME06Like(String value) {
            addCriterion("TIME06 like", value, "TIME06");
            return (Criteria) this;
        }

        public Criteria andTIME06NotLike(String value) {
            addCriterion("TIME06 not like", value, "TIME06");
            return (Criteria) this;
        }

        public Criteria andTIME06In(List<String> values) {
            addCriterion("TIME06 in", values, "TIME06");
            return (Criteria) this;
        }

        public Criteria andTIME06NotIn(List<String> values) {
            addCriterion("TIME06 not in", values, "TIME06");
            return (Criteria) this;
        }

        public Criteria andTIME06Between(String value1, String value2) {
            addCriterion("TIME06 between", value1, value2, "TIME06");
            return (Criteria) this;
        }

        public Criteria andTIME06NotBetween(String value1, String value2) {
            addCriterion("TIME06 not between", value1, value2, "TIME06");
            return (Criteria) this;
        }

        public Criteria andTIME07IsNull() {
            addCriterion("TIME07 is null");
            return (Criteria) this;
        }

        public Criteria andTIME07IsNotNull() {
            addCriterion("TIME07 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME07EqualTo(String value) {
            addCriterion("TIME07 =", value, "TIME07");
            return (Criteria) this;
        }

        public Criteria andTIME07NotEqualTo(String value) {
            addCriterion("TIME07 <>", value, "TIME07");
            return (Criteria) this;
        }

        public Criteria andTIME07GreaterThan(String value) {
            addCriterion("TIME07 >", value, "TIME07");
            return (Criteria) this;
        }

        public Criteria andTIME07GreaterThanOrEqualTo(String value) {
            addCriterion("TIME07 >=", value, "TIME07");
            return (Criteria) this;
        }

        public Criteria andTIME07LessThan(String value) {
            addCriterion("TIME07 <", value, "TIME07");
            return (Criteria) this;
        }

        public Criteria andTIME07LessThanOrEqualTo(String value) {
            addCriterion("TIME07 <=", value, "TIME07");
            return (Criteria) this;
        }

        public Criteria andTIME07Like(String value) {
            addCriterion("TIME07 like", value, "TIME07");
            return (Criteria) this;
        }

        public Criteria andTIME07NotLike(String value) {
            addCriterion("TIME07 not like", value, "TIME07");
            return (Criteria) this;
        }

        public Criteria andTIME07In(List<String> values) {
            addCriterion("TIME07 in", values, "TIME07");
            return (Criteria) this;
        }

        public Criteria andTIME07NotIn(List<String> values) {
            addCriterion("TIME07 not in", values, "TIME07");
            return (Criteria) this;
        }

        public Criteria andTIME07Between(String value1, String value2) {
            addCriterion("TIME07 between", value1, value2, "TIME07");
            return (Criteria) this;
        }

        public Criteria andTIME07NotBetween(String value1, String value2) {
            addCriterion("TIME07 not between", value1, value2, "TIME07");
            return (Criteria) this;
        }

        public Criteria andTIME08IsNull() {
            addCriterion("TIME08 is null");
            return (Criteria) this;
        }

        public Criteria andTIME08IsNotNull() {
            addCriterion("TIME08 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME08EqualTo(String value) {
            addCriterion("TIME08 =", value, "TIME08");
            return (Criteria) this;
        }

        public Criteria andTIME08NotEqualTo(String value) {
            addCriterion("TIME08 <>", value, "TIME08");
            return (Criteria) this;
        }

        public Criteria andTIME08GreaterThan(String value) {
            addCriterion("TIME08 >", value, "TIME08");
            return (Criteria) this;
        }

        public Criteria andTIME08GreaterThanOrEqualTo(String value) {
            addCriterion("TIME08 >=", value, "TIME08");
            return (Criteria) this;
        }

        public Criteria andTIME08LessThan(String value) {
            addCriterion("TIME08 <", value, "TIME08");
            return (Criteria) this;
        }

        public Criteria andTIME08LessThanOrEqualTo(String value) {
            addCriterion("TIME08 <=", value, "TIME08");
            return (Criteria) this;
        }

        public Criteria andTIME08Like(String value) {
            addCriterion("TIME08 like", value, "TIME08");
            return (Criteria) this;
        }

        public Criteria andTIME08NotLike(String value) {
            addCriterion("TIME08 not like", value, "TIME08");
            return (Criteria) this;
        }

        public Criteria andTIME08In(List<String> values) {
            addCriterion("TIME08 in", values, "TIME08");
            return (Criteria) this;
        }

        public Criteria andTIME08NotIn(List<String> values) {
            addCriterion("TIME08 not in", values, "TIME08");
            return (Criteria) this;
        }

        public Criteria andTIME08Between(String value1, String value2) {
            addCriterion("TIME08 between", value1, value2, "TIME08");
            return (Criteria) this;
        }

        public Criteria andTIME08NotBetween(String value1, String value2) {
            addCriterion("TIME08 not between", value1, value2, "TIME08");
            return (Criteria) this;
        }

        public Criteria andTIME09IsNull() {
            addCriterion("TIME09 is null");
            return (Criteria) this;
        }

        public Criteria andTIME09IsNotNull() {
            addCriterion("TIME09 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME09EqualTo(String value) {
            addCriterion("TIME09 =", value, "TIME09");
            return (Criteria) this;
        }

        public Criteria andTIME09NotEqualTo(String value) {
            addCriterion("TIME09 <>", value, "TIME09");
            return (Criteria) this;
        }

        public Criteria andTIME09GreaterThan(String value) {
            addCriterion("TIME09 >", value, "TIME09");
            return (Criteria) this;
        }

        public Criteria andTIME09GreaterThanOrEqualTo(String value) {
            addCriterion("TIME09 >=", value, "TIME09");
            return (Criteria) this;
        }

        public Criteria andTIME09LessThan(String value) {
            addCriterion("TIME09 <", value, "TIME09");
            return (Criteria) this;
        }

        public Criteria andTIME09LessThanOrEqualTo(String value) {
            addCriterion("TIME09 <=", value, "TIME09");
            return (Criteria) this;
        }

        public Criteria andTIME09Like(String value) {
            addCriterion("TIME09 like", value, "TIME09");
            return (Criteria) this;
        }

        public Criteria andTIME09NotLike(String value) {
            addCriterion("TIME09 not like", value, "TIME09");
            return (Criteria) this;
        }

        public Criteria andTIME09In(List<String> values) {
            addCriterion("TIME09 in", values, "TIME09");
            return (Criteria) this;
        }

        public Criteria andTIME09NotIn(List<String> values) {
            addCriterion("TIME09 not in", values, "TIME09");
            return (Criteria) this;
        }

        public Criteria andTIME09Between(String value1, String value2) {
            addCriterion("TIME09 between", value1, value2, "TIME09");
            return (Criteria) this;
        }

        public Criteria andTIME09NotBetween(String value1, String value2) {
            addCriterion("TIME09 not between", value1, value2, "TIME09");
            return (Criteria) this;
        }

        public Criteria andTIME10IsNull() {
            addCriterion("TIME10 is null");
            return (Criteria) this;
        }

        public Criteria andTIME10IsNotNull() {
            addCriterion("TIME10 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME10EqualTo(String value) {
            addCriterion("TIME10 =", value, "TIME10");
            return (Criteria) this;
        }

        public Criteria andTIME10NotEqualTo(String value) {
            addCriterion("TIME10 <>", value, "TIME10");
            return (Criteria) this;
        }

        public Criteria andTIME10GreaterThan(String value) {
            addCriterion("TIME10 >", value, "TIME10");
            return (Criteria) this;
        }

        public Criteria andTIME10GreaterThanOrEqualTo(String value) {
            addCriterion("TIME10 >=", value, "TIME10");
            return (Criteria) this;
        }

        public Criteria andTIME10LessThan(String value) {
            addCriterion("TIME10 <", value, "TIME10");
            return (Criteria) this;
        }

        public Criteria andTIME10LessThanOrEqualTo(String value) {
            addCriterion("TIME10 <=", value, "TIME10");
            return (Criteria) this;
        }

        public Criteria andTIME10Like(String value) {
            addCriterion("TIME10 like", value, "TIME10");
            return (Criteria) this;
        }

        public Criteria andTIME10NotLike(String value) {
            addCriterion("TIME10 not like", value, "TIME10");
            return (Criteria) this;
        }

        public Criteria andTIME10In(List<String> values) {
            addCriterion("TIME10 in", values, "TIME10");
            return (Criteria) this;
        }

        public Criteria andTIME10NotIn(List<String> values) {
            addCriterion("TIME10 not in", values, "TIME10");
            return (Criteria) this;
        }

        public Criteria andTIME10Between(String value1, String value2) {
            addCriterion("TIME10 between", value1, value2, "TIME10");
            return (Criteria) this;
        }

        public Criteria andTIME10NotBetween(String value1, String value2) {
            addCriterion("TIME10 not between", value1, value2, "TIME10");
            return (Criteria) this;
        }

        public Criteria andTIME11IsNull() {
            addCriterion("TIME11 is null");
            return (Criteria) this;
        }

        public Criteria andTIME11IsNotNull() {
            addCriterion("TIME11 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME11EqualTo(String value) {
            addCriterion("TIME11 =", value, "TIME11");
            return (Criteria) this;
        }

        public Criteria andTIME11NotEqualTo(String value) {
            addCriterion("TIME11 <>", value, "TIME11");
            return (Criteria) this;
        }

        public Criteria andTIME11GreaterThan(String value) {
            addCriterion("TIME11 >", value, "TIME11");
            return (Criteria) this;
        }

        public Criteria andTIME11GreaterThanOrEqualTo(String value) {
            addCriterion("TIME11 >=", value, "TIME11");
            return (Criteria) this;
        }

        public Criteria andTIME11LessThan(String value) {
            addCriterion("TIME11 <", value, "TIME11");
            return (Criteria) this;
        }

        public Criteria andTIME11LessThanOrEqualTo(String value) {
            addCriterion("TIME11 <=", value, "TIME11");
            return (Criteria) this;
        }

        public Criteria andTIME11Like(String value) {
            addCriterion("TIME11 like", value, "TIME11");
            return (Criteria) this;
        }

        public Criteria andTIME11NotLike(String value) {
            addCriterion("TIME11 not like", value, "TIME11");
            return (Criteria) this;
        }

        public Criteria andTIME11In(List<String> values) {
            addCriterion("TIME11 in", values, "TIME11");
            return (Criteria) this;
        }

        public Criteria andTIME11NotIn(List<String> values) {
            addCriterion("TIME11 not in", values, "TIME11");
            return (Criteria) this;
        }

        public Criteria andTIME11Between(String value1, String value2) {
            addCriterion("TIME11 between", value1, value2, "TIME11");
            return (Criteria) this;
        }

        public Criteria andTIME11NotBetween(String value1, String value2) {
            addCriterion("TIME11 not between", value1, value2, "TIME11");
            return (Criteria) this;
        }

        public Criteria andTIME12IsNull() {
            addCriterion("TIME12 is null");
            return (Criteria) this;
        }

        public Criteria andTIME12IsNotNull() {
            addCriterion("TIME12 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME12EqualTo(String value) {
            addCriterion("TIME12 =", value, "TIME12");
            return (Criteria) this;
        }

        public Criteria andTIME12NotEqualTo(String value) {
            addCriterion("TIME12 <>", value, "TIME12");
            return (Criteria) this;
        }

        public Criteria andTIME12GreaterThan(String value) {
            addCriterion("TIME12 >", value, "TIME12");
            return (Criteria) this;
        }

        public Criteria andTIME12GreaterThanOrEqualTo(String value) {
            addCriterion("TIME12 >=", value, "TIME12");
            return (Criteria) this;
        }

        public Criteria andTIME12LessThan(String value) {
            addCriterion("TIME12 <", value, "TIME12");
            return (Criteria) this;
        }

        public Criteria andTIME12LessThanOrEqualTo(String value) {
            addCriterion("TIME12 <=", value, "TIME12");
            return (Criteria) this;
        }

        public Criteria andTIME12Like(String value) {
            addCriterion("TIME12 like", value, "TIME12");
            return (Criteria) this;
        }

        public Criteria andTIME12NotLike(String value) {
            addCriterion("TIME12 not like", value, "TIME12");
            return (Criteria) this;
        }

        public Criteria andTIME12In(List<String> values) {
            addCriterion("TIME12 in", values, "TIME12");
            return (Criteria) this;
        }

        public Criteria andTIME12NotIn(List<String> values) {
            addCriterion("TIME12 not in", values, "TIME12");
            return (Criteria) this;
        }

        public Criteria andTIME12Between(String value1, String value2) {
            addCriterion("TIME12 between", value1, value2, "TIME12");
            return (Criteria) this;
        }

        public Criteria andTIME12NotBetween(String value1, String value2) {
            addCriterion("TIME12 not between", value1, value2, "TIME12");
            return (Criteria) this;
        }

        public Criteria andTIME13IsNull() {
            addCriterion("TIME13 is null");
            return (Criteria) this;
        }

        public Criteria andTIME13IsNotNull() {
            addCriterion("TIME13 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME13EqualTo(String value) {
            addCriterion("TIME13 =", value, "TIME13");
            return (Criteria) this;
        }

        public Criteria andTIME13NotEqualTo(String value) {
            addCriterion("TIME13 <>", value, "TIME13");
            return (Criteria) this;
        }

        public Criteria andTIME13GreaterThan(String value) {
            addCriterion("TIME13 >", value, "TIME13");
            return (Criteria) this;
        }

        public Criteria andTIME13GreaterThanOrEqualTo(String value) {
            addCriterion("TIME13 >=", value, "TIME13");
            return (Criteria) this;
        }

        public Criteria andTIME13LessThan(String value) {
            addCriterion("TIME13 <", value, "TIME13");
            return (Criteria) this;
        }

        public Criteria andTIME13LessThanOrEqualTo(String value) {
            addCriterion("TIME13 <=", value, "TIME13");
            return (Criteria) this;
        }

        public Criteria andTIME13Like(String value) {
            addCriterion("TIME13 like", value, "TIME13");
            return (Criteria) this;
        }

        public Criteria andTIME13NotLike(String value) {
            addCriterion("TIME13 not like", value, "TIME13");
            return (Criteria) this;
        }

        public Criteria andTIME13In(List<String> values) {
            addCriterion("TIME13 in", values, "TIME13");
            return (Criteria) this;
        }

        public Criteria andTIME13NotIn(List<String> values) {
            addCriterion("TIME13 not in", values, "TIME13");
            return (Criteria) this;
        }

        public Criteria andTIME13Between(String value1, String value2) {
            addCriterion("TIME13 between", value1, value2, "TIME13");
            return (Criteria) this;
        }

        public Criteria andTIME13NotBetween(String value1, String value2) {
            addCriterion("TIME13 not between", value1, value2, "TIME13");
            return (Criteria) this;
        }

        public Criteria andTIME14IsNull() {
            addCriterion("TIME14 is null");
            return (Criteria) this;
        }

        public Criteria andTIME14IsNotNull() {
            addCriterion("TIME14 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME14EqualTo(String value) {
            addCriterion("TIME14 =", value, "TIME14");
            return (Criteria) this;
        }

        public Criteria andTIME14NotEqualTo(String value) {
            addCriterion("TIME14 <>", value, "TIME14");
            return (Criteria) this;
        }

        public Criteria andTIME14GreaterThan(String value) {
            addCriterion("TIME14 >", value, "TIME14");
            return (Criteria) this;
        }

        public Criteria andTIME14GreaterThanOrEqualTo(String value) {
            addCriterion("TIME14 >=", value, "TIME14");
            return (Criteria) this;
        }

        public Criteria andTIME14LessThan(String value) {
            addCriterion("TIME14 <", value, "TIME14");
            return (Criteria) this;
        }

        public Criteria andTIME14LessThanOrEqualTo(String value) {
            addCriterion("TIME14 <=", value, "TIME14");
            return (Criteria) this;
        }

        public Criteria andTIME14Like(String value) {
            addCriterion("TIME14 like", value, "TIME14");
            return (Criteria) this;
        }

        public Criteria andTIME14NotLike(String value) {
            addCriterion("TIME14 not like", value, "TIME14");
            return (Criteria) this;
        }

        public Criteria andTIME14In(List<String> values) {
            addCriterion("TIME14 in", values, "TIME14");
            return (Criteria) this;
        }

        public Criteria andTIME14NotIn(List<String> values) {
            addCriterion("TIME14 not in", values, "TIME14");
            return (Criteria) this;
        }

        public Criteria andTIME14Between(String value1, String value2) {
            addCriterion("TIME14 between", value1, value2, "TIME14");
            return (Criteria) this;
        }

        public Criteria andTIME14NotBetween(String value1, String value2) {
            addCriterion("TIME14 not between", value1, value2, "TIME14");
            return (Criteria) this;
        }

        public Criteria andTIME15IsNull() {
            addCriterion("TIME15 is null");
            return (Criteria) this;
        }

        public Criteria andTIME15IsNotNull() {
            addCriterion("TIME15 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME15EqualTo(String value) {
            addCriterion("TIME15 =", value, "TIME15");
            return (Criteria) this;
        }

        public Criteria andTIME15NotEqualTo(String value) {
            addCriterion("TIME15 <>", value, "TIME15");
            return (Criteria) this;
        }

        public Criteria andTIME15GreaterThan(String value) {
            addCriterion("TIME15 >", value, "TIME15");
            return (Criteria) this;
        }

        public Criteria andTIME15GreaterThanOrEqualTo(String value) {
            addCriterion("TIME15 >=", value, "TIME15");
            return (Criteria) this;
        }

        public Criteria andTIME15LessThan(String value) {
            addCriterion("TIME15 <", value, "TIME15");
            return (Criteria) this;
        }

        public Criteria andTIME15LessThanOrEqualTo(String value) {
            addCriterion("TIME15 <=", value, "TIME15");
            return (Criteria) this;
        }

        public Criteria andTIME15Like(String value) {
            addCriterion("TIME15 like", value, "TIME15");
            return (Criteria) this;
        }

        public Criteria andTIME15NotLike(String value) {
            addCriterion("TIME15 not like", value, "TIME15");
            return (Criteria) this;
        }

        public Criteria andTIME15In(List<String> values) {
            addCriterion("TIME15 in", values, "TIME15");
            return (Criteria) this;
        }

        public Criteria andTIME15NotIn(List<String> values) {
            addCriterion("TIME15 not in", values, "TIME15");
            return (Criteria) this;
        }

        public Criteria andTIME15Between(String value1, String value2) {
            addCriterion("TIME15 between", value1, value2, "TIME15");
            return (Criteria) this;
        }

        public Criteria andTIME15NotBetween(String value1, String value2) {
            addCriterion("TIME15 not between", value1, value2, "TIME15");
            return (Criteria) this;
        }

        public Criteria andTIME16IsNull() {
            addCriterion("TIME16 is null");
            return (Criteria) this;
        }

        public Criteria andTIME16IsNotNull() {
            addCriterion("TIME16 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME16EqualTo(String value) {
            addCriterion("TIME16 =", value, "TIME16");
            return (Criteria) this;
        }

        public Criteria andTIME16NotEqualTo(String value) {
            addCriterion("TIME16 <>", value, "TIME16");
            return (Criteria) this;
        }

        public Criteria andTIME16GreaterThan(String value) {
            addCriterion("TIME16 >", value, "TIME16");
            return (Criteria) this;
        }

        public Criteria andTIME16GreaterThanOrEqualTo(String value) {
            addCriterion("TIME16 >=", value, "TIME16");
            return (Criteria) this;
        }

        public Criteria andTIME16LessThan(String value) {
            addCriterion("TIME16 <", value, "TIME16");
            return (Criteria) this;
        }

        public Criteria andTIME16LessThanOrEqualTo(String value) {
            addCriterion("TIME16 <=", value, "TIME16");
            return (Criteria) this;
        }

        public Criteria andTIME16Like(String value) {
            addCriterion("TIME16 like", value, "TIME16");
            return (Criteria) this;
        }

        public Criteria andTIME16NotLike(String value) {
            addCriterion("TIME16 not like", value, "TIME16");
            return (Criteria) this;
        }

        public Criteria andTIME16In(List<String> values) {
            addCriterion("TIME16 in", values, "TIME16");
            return (Criteria) this;
        }

        public Criteria andTIME16NotIn(List<String> values) {
            addCriterion("TIME16 not in", values, "TIME16");
            return (Criteria) this;
        }

        public Criteria andTIME16Between(String value1, String value2) {
            addCriterion("TIME16 between", value1, value2, "TIME16");
            return (Criteria) this;
        }

        public Criteria andTIME16NotBetween(String value1, String value2) {
            addCriterion("TIME16 not between", value1, value2, "TIME16");
            return (Criteria) this;
        }

        public Criteria andTIME17IsNull() {
            addCriterion("TIME17 is null");
            return (Criteria) this;
        }

        public Criteria andTIME17IsNotNull() {
            addCriterion("TIME17 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME17EqualTo(String value) {
            addCriterion("TIME17 =", value, "TIME17");
            return (Criteria) this;
        }

        public Criteria andTIME17NotEqualTo(String value) {
            addCriterion("TIME17 <>", value, "TIME17");
            return (Criteria) this;
        }

        public Criteria andTIME17GreaterThan(String value) {
            addCriterion("TIME17 >", value, "TIME17");
            return (Criteria) this;
        }

        public Criteria andTIME17GreaterThanOrEqualTo(String value) {
            addCriterion("TIME17 >=", value, "TIME17");
            return (Criteria) this;
        }

        public Criteria andTIME17LessThan(String value) {
            addCriterion("TIME17 <", value, "TIME17");
            return (Criteria) this;
        }

        public Criteria andTIME17LessThanOrEqualTo(String value) {
            addCriterion("TIME17 <=", value, "TIME17");
            return (Criteria) this;
        }

        public Criteria andTIME17Like(String value) {
            addCriterion("TIME17 like", value, "TIME17");
            return (Criteria) this;
        }

        public Criteria andTIME17NotLike(String value) {
            addCriterion("TIME17 not like", value, "TIME17");
            return (Criteria) this;
        }

        public Criteria andTIME17In(List<String> values) {
            addCriterion("TIME17 in", values, "TIME17");
            return (Criteria) this;
        }

        public Criteria andTIME17NotIn(List<String> values) {
            addCriterion("TIME17 not in", values, "TIME17");
            return (Criteria) this;
        }

        public Criteria andTIME17Between(String value1, String value2) {
            addCriterion("TIME17 between", value1, value2, "TIME17");
            return (Criteria) this;
        }

        public Criteria andTIME17NotBetween(String value1, String value2) {
            addCriterion("TIME17 not between", value1, value2, "TIME17");
            return (Criteria) this;
        }

        public Criteria andTIME18IsNull() {
            addCriterion("TIME18 is null");
            return (Criteria) this;
        }

        public Criteria andTIME18IsNotNull() {
            addCriterion("TIME18 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME18EqualTo(String value) {
            addCriterion("TIME18 =", value, "TIME18");
            return (Criteria) this;
        }

        public Criteria andTIME18NotEqualTo(String value) {
            addCriterion("TIME18 <>", value, "TIME18");
            return (Criteria) this;
        }

        public Criteria andTIME18GreaterThan(String value) {
            addCriterion("TIME18 >", value, "TIME18");
            return (Criteria) this;
        }

        public Criteria andTIME18GreaterThanOrEqualTo(String value) {
            addCriterion("TIME18 >=", value, "TIME18");
            return (Criteria) this;
        }

        public Criteria andTIME18LessThan(String value) {
            addCriterion("TIME18 <", value, "TIME18");
            return (Criteria) this;
        }

        public Criteria andTIME18LessThanOrEqualTo(String value) {
            addCriterion("TIME18 <=", value, "TIME18");
            return (Criteria) this;
        }

        public Criteria andTIME18Like(String value) {
            addCriterion("TIME18 like", value, "TIME18");
            return (Criteria) this;
        }

        public Criteria andTIME18NotLike(String value) {
            addCriterion("TIME18 not like", value, "TIME18");
            return (Criteria) this;
        }

        public Criteria andTIME18In(List<String> values) {
            addCriterion("TIME18 in", values, "TIME18");
            return (Criteria) this;
        }

        public Criteria andTIME18NotIn(List<String> values) {
            addCriterion("TIME18 not in", values, "TIME18");
            return (Criteria) this;
        }

        public Criteria andTIME18Between(String value1, String value2) {
            addCriterion("TIME18 between", value1, value2, "TIME18");
            return (Criteria) this;
        }

        public Criteria andTIME18NotBetween(String value1, String value2) {
            addCriterion("TIME18 not between", value1, value2, "TIME18");
            return (Criteria) this;
        }

        public Criteria andTIME19IsNull() {
            addCriterion("TIME19 is null");
            return (Criteria) this;
        }

        public Criteria andTIME19IsNotNull() {
            addCriterion("TIME19 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME19EqualTo(String value) {
            addCriterion("TIME19 =", value, "TIME19");
            return (Criteria) this;
        }

        public Criteria andTIME19NotEqualTo(String value) {
            addCriterion("TIME19 <>", value, "TIME19");
            return (Criteria) this;
        }

        public Criteria andTIME19GreaterThan(String value) {
            addCriterion("TIME19 >", value, "TIME19");
            return (Criteria) this;
        }

        public Criteria andTIME19GreaterThanOrEqualTo(String value) {
            addCriterion("TIME19 >=", value, "TIME19");
            return (Criteria) this;
        }

        public Criteria andTIME19LessThan(String value) {
            addCriterion("TIME19 <", value, "TIME19");
            return (Criteria) this;
        }

        public Criteria andTIME19LessThanOrEqualTo(String value) {
            addCriterion("TIME19 <=", value, "TIME19");
            return (Criteria) this;
        }

        public Criteria andTIME19Like(String value) {
            addCriterion("TIME19 like", value, "TIME19");
            return (Criteria) this;
        }

        public Criteria andTIME19NotLike(String value) {
            addCriterion("TIME19 not like", value, "TIME19");
            return (Criteria) this;
        }

        public Criteria andTIME19In(List<String> values) {
            addCriterion("TIME19 in", values, "TIME19");
            return (Criteria) this;
        }

        public Criteria andTIME19NotIn(List<String> values) {
            addCriterion("TIME19 not in", values, "TIME19");
            return (Criteria) this;
        }

        public Criteria andTIME19Between(String value1, String value2) {
            addCriterion("TIME19 between", value1, value2, "TIME19");
            return (Criteria) this;
        }

        public Criteria andTIME19NotBetween(String value1, String value2) {
            addCriterion("TIME19 not between", value1, value2, "TIME19");
            return (Criteria) this;
        }

        public Criteria andTIME20IsNull() {
            addCriterion("TIME20 is null");
            return (Criteria) this;
        }

        public Criteria andTIME20IsNotNull() {
            addCriterion("TIME20 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME20EqualTo(String value) {
            addCriterion("TIME20 =", value, "TIME20");
            return (Criteria) this;
        }

        public Criteria andTIME20NotEqualTo(String value) {
            addCriterion("TIME20 <>", value, "TIME20");
            return (Criteria) this;
        }

        public Criteria andTIME20GreaterThan(String value) {
            addCriterion("TIME20 >", value, "TIME20");
            return (Criteria) this;
        }

        public Criteria andTIME20GreaterThanOrEqualTo(String value) {
            addCriterion("TIME20 >=", value, "TIME20");
            return (Criteria) this;
        }

        public Criteria andTIME20LessThan(String value) {
            addCriterion("TIME20 <", value, "TIME20");
            return (Criteria) this;
        }

        public Criteria andTIME20LessThanOrEqualTo(String value) {
            addCriterion("TIME20 <=", value, "TIME20");
            return (Criteria) this;
        }

        public Criteria andTIME20Like(String value) {
            addCriterion("TIME20 like", value, "TIME20");
            return (Criteria) this;
        }

        public Criteria andTIME20NotLike(String value) {
            addCriterion("TIME20 not like", value, "TIME20");
            return (Criteria) this;
        }

        public Criteria andTIME20In(List<String> values) {
            addCriterion("TIME20 in", values, "TIME20");
            return (Criteria) this;
        }

        public Criteria andTIME20NotIn(List<String> values) {
            addCriterion("TIME20 not in", values, "TIME20");
            return (Criteria) this;
        }

        public Criteria andTIME20Between(String value1, String value2) {
            addCriterion("TIME20 between", value1, value2, "TIME20");
            return (Criteria) this;
        }

        public Criteria andTIME20NotBetween(String value1, String value2) {
            addCriterion("TIME20 not between", value1, value2, "TIME20");
            return (Criteria) this;
        }

        public Criteria andTIME21IsNull() {
            addCriterion("TIME21 is null");
            return (Criteria) this;
        }

        public Criteria andTIME21IsNotNull() {
            addCriterion("TIME21 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME21EqualTo(String value) {
            addCriterion("TIME21 =", value, "TIME21");
            return (Criteria) this;
        }

        public Criteria andTIME21NotEqualTo(String value) {
            addCriterion("TIME21 <>", value, "TIME21");
            return (Criteria) this;
        }

        public Criteria andTIME21GreaterThan(String value) {
            addCriterion("TIME21 >", value, "TIME21");
            return (Criteria) this;
        }

        public Criteria andTIME21GreaterThanOrEqualTo(String value) {
            addCriterion("TIME21 >=", value, "TIME21");
            return (Criteria) this;
        }

        public Criteria andTIME21LessThan(String value) {
            addCriterion("TIME21 <", value, "TIME21");
            return (Criteria) this;
        }

        public Criteria andTIME21LessThanOrEqualTo(String value) {
            addCriterion("TIME21 <=", value, "TIME21");
            return (Criteria) this;
        }

        public Criteria andTIME21Like(String value) {
            addCriterion("TIME21 like", value, "TIME21");
            return (Criteria) this;
        }

        public Criteria andTIME21NotLike(String value) {
            addCriterion("TIME21 not like", value, "TIME21");
            return (Criteria) this;
        }

        public Criteria andTIME21In(List<String> values) {
            addCriterion("TIME21 in", values, "TIME21");
            return (Criteria) this;
        }

        public Criteria andTIME21NotIn(List<String> values) {
            addCriterion("TIME21 not in", values, "TIME21");
            return (Criteria) this;
        }

        public Criteria andTIME21Between(String value1, String value2) {
            addCriterion("TIME21 between", value1, value2, "TIME21");
            return (Criteria) this;
        }

        public Criteria andTIME21NotBetween(String value1, String value2) {
            addCriterion("TIME21 not between", value1, value2, "TIME21");
            return (Criteria) this;
        }

        public Criteria andTIME22IsNull() {
            addCriterion("TIME22 is null");
            return (Criteria) this;
        }

        public Criteria andTIME22IsNotNull() {
            addCriterion("TIME22 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME22EqualTo(String value) {
            addCriterion("TIME22 =", value, "TIME22");
            return (Criteria) this;
        }

        public Criteria andTIME22NotEqualTo(String value) {
            addCriterion("TIME22 <>", value, "TIME22");
            return (Criteria) this;
        }

        public Criteria andTIME22GreaterThan(String value) {
            addCriterion("TIME22 >", value, "TIME22");
            return (Criteria) this;
        }

        public Criteria andTIME22GreaterThanOrEqualTo(String value) {
            addCriterion("TIME22 >=", value, "TIME22");
            return (Criteria) this;
        }

        public Criteria andTIME22LessThan(String value) {
            addCriterion("TIME22 <", value, "TIME22");
            return (Criteria) this;
        }

        public Criteria andTIME22LessThanOrEqualTo(String value) {
            addCriterion("TIME22 <=", value, "TIME22");
            return (Criteria) this;
        }

        public Criteria andTIME22Like(String value) {
            addCriterion("TIME22 like", value, "TIME22");
            return (Criteria) this;
        }

        public Criteria andTIME22NotLike(String value) {
            addCriterion("TIME22 not like", value, "TIME22");
            return (Criteria) this;
        }

        public Criteria andTIME22In(List<String> values) {
            addCriterion("TIME22 in", values, "TIME22");
            return (Criteria) this;
        }

        public Criteria andTIME22NotIn(List<String> values) {
            addCriterion("TIME22 not in", values, "TIME22");
            return (Criteria) this;
        }

        public Criteria andTIME22Between(String value1, String value2) {
            addCriterion("TIME22 between", value1, value2, "TIME22");
            return (Criteria) this;
        }

        public Criteria andTIME22NotBetween(String value1, String value2) {
            addCriterion("TIME22 not between", value1, value2, "TIME22");
            return (Criteria) this;
        }

        public Criteria andTIME23IsNull() {
            addCriterion("TIME23 is null");
            return (Criteria) this;
        }

        public Criteria andTIME23IsNotNull() {
            addCriterion("TIME23 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME23EqualTo(String value) {
            addCriterion("TIME23 =", value, "TIME23");
            return (Criteria) this;
        }

        public Criteria andTIME23NotEqualTo(String value) {
            addCriterion("TIME23 <>", value, "TIME23");
            return (Criteria) this;
        }

        public Criteria andTIME23GreaterThan(String value) {
            addCriterion("TIME23 >", value, "TIME23");
            return (Criteria) this;
        }

        public Criteria andTIME23GreaterThanOrEqualTo(String value) {
            addCriterion("TIME23 >=", value, "TIME23");
            return (Criteria) this;
        }

        public Criteria andTIME23LessThan(String value) {
            addCriterion("TIME23 <", value, "TIME23");
            return (Criteria) this;
        }

        public Criteria andTIME23LessThanOrEqualTo(String value) {
            addCriterion("TIME23 <=", value, "TIME23");
            return (Criteria) this;
        }

        public Criteria andTIME23Like(String value) {
            addCriterion("TIME23 like", value, "TIME23");
            return (Criteria) this;
        }

        public Criteria andTIME23NotLike(String value) {
            addCriterion("TIME23 not like", value, "TIME23");
            return (Criteria) this;
        }

        public Criteria andTIME23In(List<String> values) {
            addCriterion("TIME23 in", values, "TIME23");
            return (Criteria) this;
        }

        public Criteria andTIME23NotIn(List<String> values) {
            addCriterion("TIME23 not in", values, "TIME23");
            return (Criteria) this;
        }

        public Criteria andTIME23Between(String value1, String value2) {
            addCriterion("TIME23 between", value1, value2, "TIME23");
            return (Criteria) this;
        }

        public Criteria andTIME23NotBetween(String value1, String value2) {
            addCriterion("TIME23 not between", value1, value2, "TIME23");
            return (Criteria) this;
        }

        public Criteria andTIME24IsNull() {
            addCriterion("TIME24 is null");
            return (Criteria) this;
        }

        public Criteria andTIME24IsNotNull() {
            addCriterion("TIME24 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME24EqualTo(String value) {
            addCriterion("TIME24 =", value, "TIME24");
            return (Criteria) this;
        }

        public Criteria andTIME24NotEqualTo(String value) {
            addCriterion("TIME24 <>", value, "TIME24");
            return (Criteria) this;
        }

        public Criteria andTIME24GreaterThan(String value) {
            addCriterion("TIME24 >", value, "TIME24");
            return (Criteria) this;
        }

        public Criteria andTIME24GreaterThanOrEqualTo(String value) {
            addCriterion("TIME24 >=", value, "TIME24");
            return (Criteria) this;
        }

        public Criteria andTIME24LessThan(String value) {
            addCriterion("TIME24 <", value, "TIME24");
            return (Criteria) this;
        }

        public Criteria andTIME24LessThanOrEqualTo(String value) {
            addCriterion("TIME24 <=", value, "TIME24");
            return (Criteria) this;
        }

        public Criteria andTIME24Like(String value) {
            addCriterion("TIME24 like", value, "TIME24");
            return (Criteria) this;
        }

        public Criteria andTIME24NotLike(String value) {
            addCriterion("TIME24 not like", value, "TIME24");
            return (Criteria) this;
        }

        public Criteria andTIME24In(List<String> values) {
            addCriterion("TIME24 in", values, "TIME24");
            return (Criteria) this;
        }

        public Criteria andTIME24NotIn(List<String> values) {
            addCriterion("TIME24 not in", values, "TIME24");
            return (Criteria) this;
        }

        public Criteria andTIME24Between(String value1, String value2) {
            addCriterion("TIME24 between", value1, value2, "TIME24");
            return (Criteria) this;
        }

        public Criteria andTIME24NotBetween(String value1, String value2) {
            addCriterion("TIME24 not between", value1, value2, "TIME24");
            return (Criteria) this;
        }

        public Criteria andTIME25IsNull() {
            addCriterion("TIME25 is null");
            return (Criteria) this;
        }

        public Criteria andTIME25IsNotNull() {
            addCriterion("TIME25 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME25EqualTo(String value) {
            addCriterion("TIME25 =", value, "TIME25");
            return (Criteria) this;
        }

        public Criteria andTIME25NotEqualTo(String value) {
            addCriterion("TIME25 <>", value, "TIME25");
            return (Criteria) this;
        }

        public Criteria andTIME25GreaterThan(String value) {
            addCriterion("TIME25 >", value, "TIME25");
            return (Criteria) this;
        }

        public Criteria andTIME25GreaterThanOrEqualTo(String value) {
            addCriterion("TIME25 >=", value, "TIME25");
            return (Criteria) this;
        }

        public Criteria andTIME25LessThan(String value) {
            addCriterion("TIME25 <", value, "TIME25");
            return (Criteria) this;
        }

        public Criteria andTIME25LessThanOrEqualTo(String value) {
            addCriterion("TIME25 <=", value, "TIME25");
            return (Criteria) this;
        }

        public Criteria andTIME25Like(String value) {
            addCriterion("TIME25 like", value, "TIME25");
            return (Criteria) this;
        }

        public Criteria andTIME25NotLike(String value) {
            addCriterion("TIME25 not like", value, "TIME25");
            return (Criteria) this;
        }

        public Criteria andTIME25In(List<String> values) {
            addCriterion("TIME25 in", values, "TIME25");
            return (Criteria) this;
        }

        public Criteria andTIME25NotIn(List<String> values) {
            addCriterion("TIME25 not in", values, "TIME25");
            return (Criteria) this;
        }

        public Criteria andTIME25Between(String value1, String value2) {
            addCriterion("TIME25 between", value1, value2, "TIME25");
            return (Criteria) this;
        }

        public Criteria andTIME25NotBetween(String value1, String value2) {
            addCriterion("TIME25 not between", value1, value2, "TIME25");
            return (Criteria) this;
        }

        public Criteria andTIME26IsNull() {
            addCriterion("TIME26 is null");
            return (Criteria) this;
        }

        public Criteria andTIME26IsNotNull() {
            addCriterion("TIME26 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME26EqualTo(String value) {
            addCriterion("TIME26 =", value, "TIME26");
            return (Criteria) this;
        }

        public Criteria andTIME26NotEqualTo(String value) {
            addCriterion("TIME26 <>", value, "TIME26");
            return (Criteria) this;
        }

        public Criteria andTIME26GreaterThan(String value) {
            addCriterion("TIME26 >", value, "TIME26");
            return (Criteria) this;
        }

        public Criteria andTIME26GreaterThanOrEqualTo(String value) {
            addCriterion("TIME26 >=", value, "TIME26");
            return (Criteria) this;
        }

        public Criteria andTIME26LessThan(String value) {
            addCriterion("TIME26 <", value, "TIME26");
            return (Criteria) this;
        }

        public Criteria andTIME26LessThanOrEqualTo(String value) {
            addCriterion("TIME26 <=", value, "TIME26");
            return (Criteria) this;
        }

        public Criteria andTIME26Like(String value) {
            addCriterion("TIME26 like", value, "TIME26");
            return (Criteria) this;
        }

        public Criteria andTIME26NotLike(String value) {
            addCriterion("TIME26 not like", value, "TIME26");
            return (Criteria) this;
        }

        public Criteria andTIME26In(List<String> values) {
            addCriterion("TIME26 in", values, "TIME26");
            return (Criteria) this;
        }

        public Criteria andTIME26NotIn(List<String> values) {
            addCriterion("TIME26 not in", values, "TIME26");
            return (Criteria) this;
        }

        public Criteria andTIME26Between(String value1, String value2) {
            addCriterion("TIME26 between", value1, value2, "TIME26");
            return (Criteria) this;
        }

        public Criteria andTIME26NotBetween(String value1, String value2) {
            addCriterion("TIME26 not between", value1, value2, "TIME26");
            return (Criteria) this;
        }

        public Criteria andTIME27IsNull() {
            addCriterion("TIME27 is null");
            return (Criteria) this;
        }

        public Criteria andTIME27IsNotNull() {
            addCriterion("TIME27 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME27EqualTo(String value) {
            addCriterion("TIME27 =", value, "TIME27");
            return (Criteria) this;
        }

        public Criteria andTIME27NotEqualTo(String value) {
            addCriterion("TIME27 <>", value, "TIME27");
            return (Criteria) this;
        }

        public Criteria andTIME27GreaterThan(String value) {
            addCriterion("TIME27 >", value, "TIME27");
            return (Criteria) this;
        }

        public Criteria andTIME27GreaterThanOrEqualTo(String value) {
            addCriterion("TIME27 >=", value, "TIME27");
            return (Criteria) this;
        }

        public Criteria andTIME27LessThan(String value) {
            addCriterion("TIME27 <", value, "TIME27");
            return (Criteria) this;
        }

        public Criteria andTIME27LessThanOrEqualTo(String value) {
            addCriterion("TIME27 <=", value, "TIME27");
            return (Criteria) this;
        }

        public Criteria andTIME27Like(String value) {
            addCriterion("TIME27 like", value, "TIME27");
            return (Criteria) this;
        }

        public Criteria andTIME27NotLike(String value) {
            addCriterion("TIME27 not like", value, "TIME27");
            return (Criteria) this;
        }

        public Criteria andTIME27In(List<String> values) {
            addCriterion("TIME27 in", values, "TIME27");
            return (Criteria) this;
        }

        public Criteria andTIME27NotIn(List<String> values) {
            addCriterion("TIME27 not in", values, "TIME27");
            return (Criteria) this;
        }

        public Criteria andTIME27Between(String value1, String value2) {
            addCriterion("TIME27 between", value1, value2, "TIME27");
            return (Criteria) this;
        }

        public Criteria andTIME27NotBetween(String value1, String value2) {
            addCriterion("TIME27 not between", value1, value2, "TIME27");
            return (Criteria) this;
        }

        public Criteria andTIME28IsNull() {
            addCriterion("TIME28 is null");
            return (Criteria) this;
        }

        public Criteria andTIME28IsNotNull() {
            addCriterion("TIME28 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME28EqualTo(String value) {
            addCriterion("TIME28 =", value, "TIME28");
            return (Criteria) this;
        }

        public Criteria andTIME28NotEqualTo(String value) {
            addCriterion("TIME28 <>", value, "TIME28");
            return (Criteria) this;
        }

        public Criteria andTIME28GreaterThan(String value) {
            addCriterion("TIME28 >", value, "TIME28");
            return (Criteria) this;
        }

        public Criteria andTIME28GreaterThanOrEqualTo(String value) {
            addCriterion("TIME28 >=", value, "TIME28");
            return (Criteria) this;
        }

        public Criteria andTIME28LessThan(String value) {
            addCriterion("TIME28 <", value, "TIME28");
            return (Criteria) this;
        }

        public Criteria andTIME28LessThanOrEqualTo(String value) {
            addCriterion("TIME28 <=", value, "TIME28");
            return (Criteria) this;
        }

        public Criteria andTIME28Like(String value) {
            addCriterion("TIME28 like", value, "TIME28");
            return (Criteria) this;
        }

        public Criteria andTIME28NotLike(String value) {
            addCriterion("TIME28 not like", value, "TIME28");
            return (Criteria) this;
        }

        public Criteria andTIME28In(List<String> values) {
            addCriterion("TIME28 in", values, "TIME28");
            return (Criteria) this;
        }

        public Criteria andTIME28NotIn(List<String> values) {
            addCriterion("TIME28 not in", values, "TIME28");
            return (Criteria) this;
        }

        public Criteria andTIME28Between(String value1, String value2) {
            addCriterion("TIME28 between", value1, value2, "TIME28");
            return (Criteria) this;
        }

        public Criteria andTIME28NotBetween(String value1, String value2) {
            addCriterion("TIME28 not between", value1, value2, "TIME28");
            return (Criteria) this;
        }

        public Criteria andTIME29IsNull() {
            addCriterion("TIME29 is null");
            return (Criteria) this;
        }

        public Criteria andTIME29IsNotNull() {
            addCriterion("TIME29 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME29EqualTo(String value) {
            addCriterion("TIME29 =", value, "TIME29");
            return (Criteria) this;
        }

        public Criteria andTIME29NotEqualTo(String value) {
            addCriterion("TIME29 <>", value, "TIME29");
            return (Criteria) this;
        }

        public Criteria andTIME29GreaterThan(String value) {
            addCriterion("TIME29 >", value, "TIME29");
            return (Criteria) this;
        }

        public Criteria andTIME29GreaterThanOrEqualTo(String value) {
            addCriterion("TIME29 >=", value, "TIME29");
            return (Criteria) this;
        }

        public Criteria andTIME29LessThan(String value) {
            addCriterion("TIME29 <", value, "TIME29");
            return (Criteria) this;
        }

        public Criteria andTIME29LessThanOrEqualTo(String value) {
            addCriterion("TIME29 <=", value, "TIME29");
            return (Criteria) this;
        }

        public Criteria andTIME29Like(String value) {
            addCriterion("TIME29 like", value, "TIME29");
            return (Criteria) this;
        }

        public Criteria andTIME29NotLike(String value) {
            addCriterion("TIME29 not like", value, "TIME29");
            return (Criteria) this;
        }

        public Criteria andTIME29In(List<String> values) {
            addCriterion("TIME29 in", values, "TIME29");
            return (Criteria) this;
        }

        public Criteria andTIME29NotIn(List<String> values) {
            addCriterion("TIME29 not in", values, "TIME29");
            return (Criteria) this;
        }

        public Criteria andTIME29Between(String value1, String value2) {
            addCriterion("TIME29 between", value1, value2, "TIME29");
            return (Criteria) this;
        }

        public Criteria andTIME29NotBetween(String value1, String value2) {
            addCriterion("TIME29 not between", value1, value2, "TIME29");
            return (Criteria) this;
        }

        public Criteria andTIME30IsNull() {
            addCriterion("TIME30 is null");
            return (Criteria) this;
        }

        public Criteria andTIME30IsNotNull() {
            addCriterion("TIME30 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME30EqualTo(String value) {
            addCriterion("TIME30 =", value, "TIME30");
            return (Criteria) this;
        }

        public Criteria andTIME30NotEqualTo(String value) {
            addCriterion("TIME30 <>", value, "TIME30");
            return (Criteria) this;
        }

        public Criteria andTIME30GreaterThan(String value) {
            addCriterion("TIME30 >", value, "TIME30");
            return (Criteria) this;
        }

        public Criteria andTIME30GreaterThanOrEqualTo(String value) {
            addCriterion("TIME30 >=", value, "TIME30");
            return (Criteria) this;
        }

        public Criteria andTIME30LessThan(String value) {
            addCriterion("TIME30 <", value, "TIME30");
            return (Criteria) this;
        }

        public Criteria andTIME30LessThanOrEqualTo(String value) {
            addCriterion("TIME30 <=", value, "TIME30");
            return (Criteria) this;
        }

        public Criteria andTIME30Like(String value) {
            addCriterion("TIME30 like", value, "TIME30");
            return (Criteria) this;
        }

        public Criteria andTIME30NotLike(String value) {
            addCriterion("TIME30 not like", value, "TIME30");
            return (Criteria) this;
        }

        public Criteria andTIME30In(List<String> values) {
            addCriterion("TIME30 in", values, "TIME30");
            return (Criteria) this;
        }

        public Criteria andTIME30NotIn(List<String> values) {
            addCriterion("TIME30 not in", values, "TIME30");
            return (Criteria) this;
        }

        public Criteria andTIME30Between(String value1, String value2) {
            addCriterion("TIME30 between", value1, value2, "TIME30");
            return (Criteria) this;
        }

        public Criteria andTIME30NotBetween(String value1, String value2) {
            addCriterion("TIME30 not between", value1, value2, "TIME30");
            return (Criteria) this;
        }

        public Criteria andTIME31IsNull() {
            addCriterion("TIME31 is null");
            return (Criteria) this;
        }

        public Criteria andTIME31IsNotNull() {
            addCriterion("TIME31 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME31EqualTo(String value) {
            addCriterion("TIME31 =", value, "TIME31");
            return (Criteria) this;
        }

        public Criteria andTIME31NotEqualTo(String value) {
            addCriterion("TIME31 <>", value, "TIME31");
            return (Criteria) this;
        }

        public Criteria andTIME31GreaterThan(String value) {
            addCriterion("TIME31 >", value, "TIME31");
            return (Criteria) this;
        }

        public Criteria andTIME31GreaterThanOrEqualTo(String value) {
            addCriterion("TIME31 >=", value, "TIME31");
            return (Criteria) this;
        }

        public Criteria andTIME31LessThan(String value) {
            addCriterion("TIME31 <", value, "TIME31");
            return (Criteria) this;
        }

        public Criteria andTIME31LessThanOrEqualTo(String value) {
            addCriterion("TIME31 <=", value, "TIME31");
            return (Criteria) this;
        }

        public Criteria andTIME31Like(String value) {
            addCriterion("TIME31 like", value, "TIME31");
            return (Criteria) this;
        }

        public Criteria andTIME31NotLike(String value) {
            addCriterion("TIME31 not like", value, "TIME31");
            return (Criteria) this;
        }

        public Criteria andTIME31In(List<String> values) {
            addCriterion("TIME31 in", values, "TIME31");
            return (Criteria) this;
        }

        public Criteria andTIME31NotIn(List<String> values) {
            addCriterion("TIME31 not in", values, "TIME31");
            return (Criteria) this;
        }

        public Criteria andTIME31Between(String value1, String value2) {
            addCriterion("TIME31 between", value1, value2, "TIME31");
            return (Criteria) this;
        }

        public Criteria andTIME31NotBetween(String value1, String value2) {
            addCriterion("TIME31 not between", value1, value2, "TIME31");
            return (Criteria) this;
        }

        public Criteria andTIME32IsNull() {
            addCriterion("TIME32 is null");
            return (Criteria) this;
        }

        public Criteria andTIME32IsNotNull() {
            addCriterion("TIME32 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME32EqualTo(String value) {
            addCriterion("TIME32 =", value, "TIME32");
            return (Criteria) this;
        }

        public Criteria andTIME32NotEqualTo(String value) {
            addCriterion("TIME32 <>", value, "TIME32");
            return (Criteria) this;
        }

        public Criteria andTIME32GreaterThan(String value) {
            addCriterion("TIME32 >", value, "TIME32");
            return (Criteria) this;
        }

        public Criteria andTIME32GreaterThanOrEqualTo(String value) {
            addCriterion("TIME32 >=", value, "TIME32");
            return (Criteria) this;
        }

        public Criteria andTIME32LessThan(String value) {
            addCriterion("TIME32 <", value, "TIME32");
            return (Criteria) this;
        }

        public Criteria andTIME32LessThanOrEqualTo(String value) {
            addCriterion("TIME32 <=", value, "TIME32");
            return (Criteria) this;
        }

        public Criteria andTIME32Like(String value) {
            addCriterion("TIME32 like", value, "TIME32");
            return (Criteria) this;
        }

        public Criteria andTIME32NotLike(String value) {
            addCriterion("TIME32 not like", value, "TIME32");
            return (Criteria) this;
        }

        public Criteria andTIME32In(List<String> values) {
            addCriterion("TIME32 in", values, "TIME32");
            return (Criteria) this;
        }

        public Criteria andTIME32NotIn(List<String> values) {
            addCriterion("TIME32 not in", values, "TIME32");
            return (Criteria) this;
        }

        public Criteria andTIME32Between(String value1, String value2) {
            addCriterion("TIME32 between", value1, value2, "TIME32");
            return (Criteria) this;
        }

        public Criteria andTIME32NotBetween(String value1, String value2) {
            addCriterion("TIME32 not between", value1, value2, "TIME32");
            return (Criteria) this;
        }

        public Criteria andTIME33IsNull() {
            addCriterion("TIME33 is null");
            return (Criteria) this;
        }

        public Criteria andTIME33IsNotNull() {
            addCriterion("TIME33 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME33EqualTo(String value) {
            addCriterion("TIME33 =", value, "TIME33");
            return (Criteria) this;
        }

        public Criteria andTIME33NotEqualTo(String value) {
            addCriterion("TIME33 <>", value, "TIME33");
            return (Criteria) this;
        }

        public Criteria andTIME33GreaterThan(String value) {
            addCriterion("TIME33 >", value, "TIME33");
            return (Criteria) this;
        }

        public Criteria andTIME33GreaterThanOrEqualTo(String value) {
            addCriterion("TIME33 >=", value, "TIME33");
            return (Criteria) this;
        }

        public Criteria andTIME33LessThan(String value) {
            addCriterion("TIME33 <", value, "TIME33");
            return (Criteria) this;
        }

        public Criteria andTIME33LessThanOrEqualTo(String value) {
            addCriterion("TIME33 <=", value, "TIME33");
            return (Criteria) this;
        }

        public Criteria andTIME33Like(String value) {
            addCriterion("TIME33 like", value, "TIME33");
            return (Criteria) this;
        }

        public Criteria andTIME33NotLike(String value) {
            addCriterion("TIME33 not like", value, "TIME33");
            return (Criteria) this;
        }

        public Criteria andTIME33In(List<String> values) {
            addCriterion("TIME33 in", values, "TIME33");
            return (Criteria) this;
        }

        public Criteria andTIME33NotIn(List<String> values) {
            addCriterion("TIME33 not in", values, "TIME33");
            return (Criteria) this;
        }

        public Criteria andTIME33Between(String value1, String value2) {
            addCriterion("TIME33 between", value1, value2, "TIME33");
            return (Criteria) this;
        }

        public Criteria andTIME33NotBetween(String value1, String value2) {
            addCriterion("TIME33 not between", value1, value2, "TIME33");
            return (Criteria) this;
        }

        public Criteria andTIME34IsNull() {
            addCriterion("TIME34 is null");
            return (Criteria) this;
        }

        public Criteria andTIME34IsNotNull() {
            addCriterion("TIME34 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME34EqualTo(String value) {
            addCriterion("TIME34 =", value, "TIME34");
            return (Criteria) this;
        }

        public Criteria andTIME34NotEqualTo(String value) {
            addCriterion("TIME34 <>", value, "TIME34");
            return (Criteria) this;
        }

        public Criteria andTIME34GreaterThan(String value) {
            addCriterion("TIME34 >", value, "TIME34");
            return (Criteria) this;
        }

        public Criteria andTIME34GreaterThanOrEqualTo(String value) {
            addCriterion("TIME34 >=", value, "TIME34");
            return (Criteria) this;
        }

        public Criteria andTIME34LessThan(String value) {
            addCriterion("TIME34 <", value, "TIME34");
            return (Criteria) this;
        }

        public Criteria andTIME34LessThanOrEqualTo(String value) {
            addCriterion("TIME34 <=", value, "TIME34");
            return (Criteria) this;
        }

        public Criteria andTIME34Like(String value) {
            addCriterion("TIME34 like", value, "TIME34");
            return (Criteria) this;
        }

        public Criteria andTIME34NotLike(String value) {
            addCriterion("TIME34 not like", value, "TIME34");
            return (Criteria) this;
        }

        public Criteria andTIME34In(List<String> values) {
            addCriterion("TIME34 in", values, "TIME34");
            return (Criteria) this;
        }

        public Criteria andTIME34NotIn(List<String> values) {
            addCriterion("TIME34 not in", values, "TIME34");
            return (Criteria) this;
        }

        public Criteria andTIME34Between(String value1, String value2) {
            addCriterion("TIME34 between", value1, value2, "TIME34");
            return (Criteria) this;
        }

        public Criteria andTIME34NotBetween(String value1, String value2) {
            addCriterion("TIME34 not between", value1, value2, "TIME34");
            return (Criteria) this;
        }

        public Criteria andTIME35IsNull() {
            addCriterion("TIME35 is null");
            return (Criteria) this;
        }

        public Criteria andTIME35IsNotNull() {
            addCriterion("TIME35 is not null");
            return (Criteria) this;
        }

        public Criteria andTIME35EqualTo(String value) {
            addCriterion("TIME35 =", value, "TIME35");
            return (Criteria) this;
        }

        public Criteria andTIME35NotEqualTo(String value) {
            addCriterion("TIME35 <>", value, "TIME35");
            return (Criteria) this;
        }

        public Criteria andTIME35GreaterThan(String value) {
            addCriterion("TIME35 >", value, "TIME35");
            return (Criteria) this;
        }

        public Criteria andTIME35GreaterThanOrEqualTo(String value) {
            addCriterion("TIME35 >=", value, "TIME35");
            return (Criteria) this;
        }

        public Criteria andTIME35LessThan(String value) {
            addCriterion("TIME35 <", value, "TIME35");
            return (Criteria) this;
        }

        public Criteria andTIME35LessThanOrEqualTo(String value) {
            addCriterion("TIME35 <=", value, "TIME35");
            return (Criteria) this;
        }

        public Criteria andTIME35Like(String value) {
            addCriterion("TIME35 like", value, "TIME35");
            return (Criteria) this;
        }

        public Criteria andTIME35NotLike(String value) {
            addCriterion("TIME35 not like", value, "TIME35");
            return (Criteria) this;
        }

        public Criteria andTIME35In(List<String> values) {
            addCriterion("TIME35 in", values, "TIME35");
            return (Criteria) this;
        }

        public Criteria andTIME35NotIn(List<String> values) {
            addCriterion("TIME35 not in", values, "TIME35");
            return (Criteria) this;
        }

        public Criteria andTIME35Between(String value1, String value2) {
            addCriterion("TIME35 between", value1, value2, "TIME35");
            return (Criteria) this;
        }

        public Criteria andTIME35NotBetween(String value1, String value2) {
            addCriterion("TIME35 not between", value1, value2, "TIME35");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andLN_JIANLikeInsensitive(String value) {
            addCriterion("upper(LN_JIAN) like", value.toUpperCase(), "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU01LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU01) like", value.toUpperCase(), "SOCHI_NAIYOU01");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU02LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU02) like", value.toUpperCase(), "SOCHI_NAIYOU02");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU03LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU03) like", value.toUpperCase(), "SOCHI_NAIYOU03");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU04LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU04) like", value.toUpperCase(), "SOCHI_NAIYOU04");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU05LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU05) like", value.toUpperCase(), "SOCHI_NAIYOU05");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU06LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU06) like", value.toUpperCase(), "SOCHI_NAIYOU06");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU07LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU07) like", value.toUpperCase(), "SOCHI_NAIYOU07");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU08LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU08) like", value.toUpperCase(), "SOCHI_NAIYOU08");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU09LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU09) like", value.toUpperCase(), "SOCHI_NAIYOU09");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU10LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU10) like", value.toUpperCase(), "SOCHI_NAIYOU10");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU11LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU11) like", value.toUpperCase(), "SOCHI_NAIYOU11");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU12LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU12) like", value.toUpperCase(), "SOCHI_NAIYOU12");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU13LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU13) like", value.toUpperCase(), "SOCHI_NAIYOU13");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU14LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU14) like", value.toUpperCase(), "SOCHI_NAIYOU14");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU15LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU15) like", value.toUpperCase(), "SOCHI_NAIYOU15");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU16LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU16) like", value.toUpperCase(), "SOCHI_NAIYOU16");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU17LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU17) like", value.toUpperCase(), "SOCHI_NAIYOU17");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU18LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU18) like", value.toUpperCase(), "SOCHI_NAIYOU18");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU19LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU19) like", value.toUpperCase(), "SOCHI_NAIYOU19");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU20LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU20) like", value.toUpperCase(), "SOCHI_NAIYOU20");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU21LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU21) like", value.toUpperCase(), "SOCHI_NAIYOU21");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU22LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU22) like", value.toUpperCase(), "SOCHI_NAIYOU22");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU23LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU23) like", value.toUpperCase(), "SOCHI_NAIYOU23");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU24LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU24) like", value.toUpperCase(), "SOCHI_NAIYOU24");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU25LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU25) like", value.toUpperCase(), "SOCHI_NAIYOU25");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU26LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU26) like", value.toUpperCase(), "SOCHI_NAIYOU26");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU27LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU27) like", value.toUpperCase(), "SOCHI_NAIYOU27");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU28LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU28) like", value.toUpperCase(), "SOCHI_NAIYOU28");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU29LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU29) like", value.toUpperCase(), "SOCHI_NAIYOU29");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU30LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU30) like", value.toUpperCase(), "SOCHI_NAIYOU30");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU31LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU31) like", value.toUpperCase(), "SOCHI_NAIYOU31");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU32LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU32) like", value.toUpperCase(), "SOCHI_NAIYOU32");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU33LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU33) like", value.toUpperCase(), "SOCHI_NAIYOU33");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU34LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU34) like", value.toUpperCase(), "SOCHI_NAIYOU34");
            return (Criteria) this;
        }

        public Criteria andSOCHI_NAIYOU35LikeInsensitive(String value) {
            addCriterion("upper(SOCHI_NAIYOU35) like", value.toUpperCase(), "SOCHI_NAIYOU35");
            return (Criteria) this;
        }

        public Criteria andKEKKA01LikeInsensitive(String value) {
            addCriterion("upper(KEKKA01) like", value.toUpperCase(), "KEKKA01");
            return (Criteria) this;
        }

        public Criteria andKEKKA02LikeInsensitive(String value) {
            addCriterion("upper(KEKKA02) like", value.toUpperCase(), "KEKKA02");
            return (Criteria) this;
        }

        public Criteria andKEKKA03LikeInsensitive(String value) {
            addCriterion("upper(KEKKA03) like", value.toUpperCase(), "KEKKA03");
            return (Criteria) this;
        }

        public Criteria andKEKKA04LikeInsensitive(String value) {
            addCriterion("upper(KEKKA04) like", value.toUpperCase(), "KEKKA04");
            return (Criteria) this;
        }

        public Criteria andKEKKA05LikeInsensitive(String value) {
            addCriterion("upper(KEKKA05) like", value.toUpperCase(), "KEKKA05");
            return (Criteria) this;
        }

        public Criteria andKEKKA06LikeInsensitive(String value) {
            addCriterion("upper(KEKKA06) like", value.toUpperCase(), "KEKKA06");
            return (Criteria) this;
        }

        public Criteria andKEKKA07LikeInsensitive(String value) {
            addCriterion("upper(KEKKA07) like", value.toUpperCase(), "KEKKA07");
            return (Criteria) this;
        }

        public Criteria andKEKKA08LikeInsensitive(String value) {
            addCriterion("upper(KEKKA08) like", value.toUpperCase(), "KEKKA08");
            return (Criteria) this;
        }

        public Criteria andKEKKA09LikeInsensitive(String value) {
            addCriterion("upper(KEKKA09) like", value.toUpperCase(), "KEKKA09");
            return (Criteria) this;
        }

        public Criteria andKEKKA10LikeInsensitive(String value) {
            addCriterion("upper(KEKKA10) like", value.toUpperCase(), "KEKKA10");
            return (Criteria) this;
        }

        public Criteria andTIME01LikeInsensitive(String value) {
            addCriterion("upper(TIME01) like", value.toUpperCase(), "TIME01");
            return (Criteria) this;
        }

        public Criteria andTIME02LikeInsensitive(String value) {
            addCriterion("upper(TIME02) like", value.toUpperCase(), "TIME02");
            return (Criteria) this;
        }

        public Criteria andTIME03LikeInsensitive(String value) {
            addCriterion("upper(TIME03) like", value.toUpperCase(), "TIME03");
            return (Criteria) this;
        }

        public Criteria andTIME04LikeInsensitive(String value) {
            addCriterion("upper(TIME04) like", value.toUpperCase(), "TIME04");
            return (Criteria) this;
        }

        public Criteria andTIME05LikeInsensitive(String value) {
            addCriterion("upper(TIME05) like", value.toUpperCase(), "TIME05");
            return (Criteria) this;
        }

        public Criteria andTIME06LikeInsensitive(String value) {
            addCriterion("upper(TIME06) like", value.toUpperCase(), "TIME06");
            return (Criteria) this;
        }

        public Criteria andTIME07LikeInsensitive(String value) {
            addCriterion("upper(TIME07) like", value.toUpperCase(), "TIME07");
            return (Criteria) this;
        }

        public Criteria andTIME08LikeInsensitive(String value) {
            addCriterion("upper(TIME08) like", value.toUpperCase(), "TIME08");
            return (Criteria) this;
        }

        public Criteria andTIME09LikeInsensitive(String value) {
            addCriterion("upper(TIME09) like", value.toUpperCase(), "TIME09");
            return (Criteria) this;
        }

        public Criteria andTIME10LikeInsensitive(String value) {
            addCriterion("upper(TIME10) like", value.toUpperCase(), "TIME10");
            return (Criteria) this;
        }

        public Criteria andTIME11LikeInsensitive(String value) {
            addCriterion("upper(TIME11) like", value.toUpperCase(), "TIME11");
            return (Criteria) this;
        }

        public Criteria andTIME12LikeInsensitive(String value) {
            addCriterion("upper(TIME12) like", value.toUpperCase(), "TIME12");
            return (Criteria) this;
        }

        public Criteria andTIME13LikeInsensitive(String value) {
            addCriterion("upper(TIME13) like", value.toUpperCase(), "TIME13");
            return (Criteria) this;
        }

        public Criteria andTIME14LikeInsensitive(String value) {
            addCriterion("upper(TIME14) like", value.toUpperCase(), "TIME14");
            return (Criteria) this;
        }

        public Criteria andTIME15LikeInsensitive(String value) {
            addCriterion("upper(TIME15) like", value.toUpperCase(), "TIME15");
            return (Criteria) this;
        }

        public Criteria andTIME16LikeInsensitive(String value) {
            addCriterion("upper(TIME16) like", value.toUpperCase(), "TIME16");
            return (Criteria) this;
        }

        public Criteria andTIME17LikeInsensitive(String value) {
            addCriterion("upper(TIME17) like", value.toUpperCase(), "TIME17");
            return (Criteria) this;
        }

        public Criteria andTIME18LikeInsensitive(String value) {
            addCriterion("upper(TIME18) like", value.toUpperCase(), "TIME18");
            return (Criteria) this;
        }

        public Criteria andTIME19LikeInsensitive(String value) {
            addCriterion("upper(TIME19) like", value.toUpperCase(), "TIME19");
            return (Criteria) this;
        }

        public Criteria andTIME20LikeInsensitive(String value) {
            addCriterion("upper(TIME20) like", value.toUpperCase(), "TIME20");
            return (Criteria) this;
        }

        public Criteria andTIME21LikeInsensitive(String value) {
            addCriterion("upper(TIME21) like", value.toUpperCase(), "TIME21");
            return (Criteria) this;
        }

        public Criteria andTIME22LikeInsensitive(String value) {
            addCriterion("upper(TIME22) like", value.toUpperCase(), "TIME22");
            return (Criteria) this;
        }

        public Criteria andTIME23LikeInsensitive(String value) {
            addCriterion("upper(TIME23) like", value.toUpperCase(), "TIME23");
            return (Criteria) this;
        }

        public Criteria andTIME24LikeInsensitive(String value) {
            addCriterion("upper(TIME24) like", value.toUpperCase(), "TIME24");
            return (Criteria) this;
        }

        public Criteria andTIME25LikeInsensitive(String value) {
            addCriterion("upper(TIME25) like", value.toUpperCase(), "TIME25");
            return (Criteria) this;
        }

        public Criteria andTIME26LikeInsensitive(String value) {
            addCriterion("upper(TIME26) like", value.toUpperCase(), "TIME26");
            return (Criteria) this;
        }

        public Criteria andTIME27LikeInsensitive(String value) {
            addCriterion("upper(TIME27) like", value.toUpperCase(), "TIME27");
            return (Criteria) this;
        }

        public Criteria andTIME28LikeInsensitive(String value) {
            addCriterion("upper(TIME28) like", value.toUpperCase(), "TIME28");
            return (Criteria) this;
        }

        public Criteria andTIME29LikeInsensitive(String value) {
            addCriterion("upper(TIME29) like", value.toUpperCase(), "TIME29");
            return (Criteria) this;
        }

        public Criteria andTIME30LikeInsensitive(String value) {
            addCriterion("upper(TIME30) like", value.toUpperCase(), "TIME30");
            return (Criteria) this;
        }

        public Criteria andTIME31LikeInsensitive(String value) {
            addCriterion("upper(TIME31) like", value.toUpperCase(), "TIME31");
            return (Criteria) this;
        }

        public Criteria andTIME32LikeInsensitive(String value) {
            addCriterion("upper(TIME32) like", value.toUpperCase(), "TIME32");
            return (Criteria) this;
        }

        public Criteria andTIME33LikeInsensitive(String value) {
            addCriterion("upper(TIME33) like", value.toUpperCase(), "TIME33");
            return (Criteria) this;
        }

        public Criteria andTIME34LikeInsensitive(String value) {
            addCriterion("upper(TIME34) like", value.toUpperCase(), "TIME34");
            return (Criteria) this;
        }

        public Criteria andTIME35LikeInsensitive(String value) {
            addCriterion("upper(TIME35) like", value.toUpperCase(), "TIME35");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * E_SOCHI
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * E_SOCHI null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}