package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HKeibiStsRdDtlRhtbl1Example {
    /**
     * H_KEIBI_STS_RD_DTL_RHTBL1
     */
    protected String orderByClause;

    /**
     * H_KEIBI_STS_RD_DTL_RHTBL1
     */
    protected boolean distinct;

    /**
     * H_KEIBI_STS_RD_DTL_RHTBL1
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public HKeibiStsRdDtlRhtbl1Example() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * H_KEIBI_STS_RD_DTL_RHTBL1 null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_KEIBI_STS_DTL_READ1IsNull() {
            addCriterion("LN_KEIBI_STS_DTL_READ1 is null");
            return (Criteria) this;
        }

        public Criteria andLN_KEIBI_STS_DTL_READ1IsNotNull() {
            addCriterion("LN_KEIBI_STS_DTL_READ1 is not null");
            return (Criteria) this;
        }

        public Criteria andLN_KEIBI_STS_DTL_READ1EqualTo(String value) {
            addCriterion("LN_KEIBI_STS_DTL_READ1 =", value, "LN_KEIBI_STS_DTL_READ1");
            return (Criteria) this;
        }

        public Criteria andLN_KEIBI_STS_DTL_READ1NotEqualTo(String value) {
            addCriterion("LN_KEIBI_STS_DTL_READ1 <>", value, "LN_KEIBI_STS_DTL_READ1");
            return (Criteria) this;
        }

        public Criteria andLN_KEIBI_STS_DTL_READ1GreaterThan(String value) {
            addCriterion("LN_KEIBI_STS_DTL_READ1 >", value, "LN_KEIBI_STS_DTL_READ1");
            return (Criteria) this;
        }

        public Criteria andLN_KEIBI_STS_DTL_READ1GreaterThanOrEqualTo(String value) {
            addCriterion("LN_KEIBI_STS_DTL_READ1 >=", value, "LN_KEIBI_STS_DTL_READ1");
            return (Criteria) this;
        }

        public Criteria andLN_KEIBI_STS_DTL_READ1LessThan(String value) {
            addCriterion("LN_KEIBI_STS_DTL_READ1 <", value, "LN_KEIBI_STS_DTL_READ1");
            return (Criteria) this;
        }

        public Criteria andLN_KEIBI_STS_DTL_READ1LessThanOrEqualTo(String value) {
            addCriterion("LN_KEIBI_STS_DTL_READ1 <=", value, "LN_KEIBI_STS_DTL_READ1");
            return (Criteria) this;
        }

        public Criteria andLN_KEIBI_STS_DTL_READ1Like(String value) {
            addCriterion("LN_KEIBI_STS_DTL_READ1 like", value, "LN_KEIBI_STS_DTL_READ1");
            return (Criteria) this;
        }

        public Criteria andLN_KEIBI_STS_DTL_READ1NotLike(String value) {
            addCriterion("LN_KEIBI_STS_DTL_READ1 not like", value, "LN_KEIBI_STS_DTL_READ1");
            return (Criteria) this;
        }

        public Criteria andLN_KEIBI_STS_DTL_READ1In(List<String> values) {
            addCriterion("LN_KEIBI_STS_DTL_READ1 in", values, "LN_KEIBI_STS_DTL_READ1");
            return (Criteria) this;
        }

        public Criteria andLN_KEIBI_STS_DTL_READ1NotIn(List<String> values) {
            addCriterion("LN_KEIBI_STS_DTL_READ1 not in", values, "LN_KEIBI_STS_DTL_READ1");
            return (Criteria) this;
        }

        public Criteria andLN_KEIBI_STS_DTL_READ1Between(String value1, String value2) {
            addCriterion("LN_KEIBI_STS_DTL_READ1 between", value1, value2, "LN_KEIBI_STS_DTL_READ1");
            return (Criteria) this;
        }

        public Criteria andLN_KEIBI_STS_DTL_READ1NotBetween(String value1, String value2) {
            addCriterion("LN_KEIBI_STS_DTL_READ1 not between", value1, value2, "LN_KEIBI_STS_DTL_READ1");
            return (Criteria) this;
        }

        public Criteria andLN_RD_KB_STSIsNull() {
            addCriterion("LN_RD_KB_STS is null");
            return (Criteria) this;
        }

        public Criteria andLN_RD_KB_STSIsNotNull() {
            addCriterion("LN_RD_KB_STS is not null");
            return (Criteria) this;
        }

        public Criteria andLN_RD_KB_STSEqualTo(String value) {
            addCriterion("LN_RD_KB_STS =", value, "LN_RD_KB_STS");
            return (Criteria) this;
        }

        public Criteria andLN_RD_KB_STSNotEqualTo(String value) {
            addCriterion("LN_RD_KB_STS <>", value, "LN_RD_KB_STS");
            return (Criteria) this;
        }

        public Criteria andLN_RD_KB_STSGreaterThan(String value) {
            addCriterion("LN_RD_KB_STS >", value, "LN_RD_KB_STS");
            return (Criteria) this;
        }

        public Criteria andLN_RD_KB_STSGreaterThanOrEqualTo(String value) {
            addCriterion("LN_RD_KB_STS >=", value, "LN_RD_KB_STS");
            return (Criteria) this;
        }

        public Criteria andLN_RD_KB_STSLessThan(String value) {
            addCriterion("LN_RD_KB_STS <", value, "LN_RD_KB_STS");
            return (Criteria) this;
        }

        public Criteria andLN_RD_KB_STSLessThanOrEqualTo(String value) {
            addCriterion("LN_RD_KB_STS <=", value, "LN_RD_KB_STS");
            return (Criteria) this;
        }

        public Criteria andLN_RD_KB_STSLike(String value) {
            addCriterion("LN_RD_KB_STS like", value, "LN_RD_KB_STS");
            return (Criteria) this;
        }

        public Criteria andLN_RD_KB_STSNotLike(String value) {
            addCriterion("LN_RD_KB_STS not like", value, "LN_RD_KB_STS");
            return (Criteria) this;
        }

        public Criteria andLN_RD_KB_STSIn(List<String> values) {
            addCriterion("LN_RD_KB_STS in", values, "LN_RD_KB_STS");
            return (Criteria) this;
        }

        public Criteria andLN_RD_KB_STSNotIn(List<String> values) {
            addCriterion("LN_RD_KB_STS not in", values, "LN_RD_KB_STS");
            return (Criteria) this;
        }

        public Criteria andLN_RD_KB_STSBetween(String value1, String value2) {
            addCriterion("LN_RD_KB_STS between", value1, value2, "LN_RD_KB_STS");
            return (Criteria) this;
        }

        public Criteria andLN_RD_KB_STSNotBetween(String value1, String value2) {
            addCriterion("LN_RD_KB_STS not between", value1, value2, "LN_RD_KB_STS");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDRIsNull() {
            addCriterion("SUB_ADDR is null");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDRIsNotNull() {
            addCriterion("SUB_ADDR is not null");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDREqualTo(String value) {
            addCriterion("SUB_ADDR =", value, "SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDRNotEqualTo(String value) {
            addCriterion("SUB_ADDR <>", value, "SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDRGreaterThan(String value) {
            addCriterion("SUB_ADDR >", value, "SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDRGreaterThanOrEqualTo(String value) {
            addCriterion("SUB_ADDR >=", value, "SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDRLessThan(String value) {
            addCriterion("SUB_ADDR <", value, "SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDRLessThanOrEqualTo(String value) {
            addCriterion("SUB_ADDR <=", value, "SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDRLike(String value) {
            addCriterion("SUB_ADDR like", value, "SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDRNotLike(String value) {
            addCriterion("SUB_ADDR not like", value, "SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDRIn(List<String> values) {
            addCriterion("SUB_ADDR in", values, "SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDRNotIn(List<String> values) {
            addCriterion("SUB_ADDR not in", values, "SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDRBetween(String value1, String value2) {
            addCriterion("SUB_ADDR between", value1, value2, "SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDRNotBetween(String value1, String value2) {
            addCriterion("SUB_ADDR not between", value1, value2, "SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andN0_STSIsNull() {
            addCriterion("N0_STS is null");
            return (Criteria) this;
        }

        public Criteria andN0_STSIsNotNull() {
            addCriterion("N0_STS is not null");
            return (Criteria) this;
        }

        public Criteria andN0_STSEqualTo(String value) {
            addCriterion("N0_STS =", value, "n0_STS");
            return (Criteria) this;
        }

        public Criteria andN0_STSNotEqualTo(String value) {
            addCriterion("N0_STS <>", value, "n0_STS");
            return (Criteria) this;
        }

        public Criteria andN0_STSGreaterThan(String value) {
            addCriterion("N0_STS >", value, "n0_STS");
            return (Criteria) this;
        }

        public Criteria andN0_STSGreaterThanOrEqualTo(String value) {
            addCriterion("N0_STS >=", value, "n0_STS");
            return (Criteria) this;
        }

        public Criteria andN0_STSLessThan(String value) {
            addCriterion("N0_STS <", value, "n0_STS");
            return (Criteria) this;
        }

        public Criteria andN0_STSLessThanOrEqualTo(String value) {
            addCriterion("N0_STS <=", value, "n0_STS");
            return (Criteria) this;
        }

        public Criteria andN0_STSLike(String value) {
            addCriterion("N0_STS like", value, "n0_STS");
            return (Criteria) this;
        }

        public Criteria andN0_STSNotLike(String value) {
            addCriterion("N0_STS not like", value, "n0_STS");
            return (Criteria) this;
        }

        public Criteria andN0_STSIn(List<String> values) {
            addCriterion("N0_STS in", values, "n0_STS");
            return (Criteria) this;
        }

        public Criteria andN0_STSNotIn(List<String> values) {
            addCriterion("N0_STS not in", values, "n0_STS");
            return (Criteria) this;
        }

        public Criteria andN0_STSBetween(String value1, String value2) {
            addCriterion("N0_STS between", value1, value2, "n0_STS");
            return (Criteria) this;
        }

        public Criteria andN0_STSNotBetween(String value1, String value2) {
            addCriterion("N0_STS not between", value1, value2, "n0_STS");
            return (Criteria) this;
        }

        public Criteria andKN_STSIsNull() {
            addCriterion("KN_STS is null");
            return (Criteria) this;
        }

        public Criteria andKN_STSIsNotNull() {
            addCriterion("KN_STS is not null");
            return (Criteria) this;
        }

        public Criteria andKN_STSEqualTo(String value) {
            addCriterion("KN_STS =", value, "KN_STS");
            return (Criteria) this;
        }

        public Criteria andKN_STSNotEqualTo(String value) {
            addCriterion("KN_STS <>", value, "KN_STS");
            return (Criteria) this;
        }

        public Criteria andKN_STSGreaterThan(String value) {
            addCriterion("KN_STS >", value, "KN_STS");
            return (Criteria) this;
        }

        public Criteria andKN_STSGreaterThanOrEqualTo(String value) {
            addCriterion("KN_STS >=", value, "KN_STS");
            return (Criteria) this;
        }

        public Criteria andKN_STSLessThan(String value) {
            addCriterion("KN_STS <", value, "KN_STS");
            return (Criteria) this;
        }

        public Criteria andKN_STSLessThanOrEqualTo(String value) {
            addCriterion("KN_STS <=", value, "KN_STS");
            return (Criteria) this;
        }

        public Criteria andKN_STSLike(String value) {
            addCriterion("KN_STS like", value, "KN_STS");
            return (Criteria) this;
        }

        public Criteria andKN_STSNotLike(String value) {
            addCriterion("KN_STS not like", value, "KN_STS");
            return (Criteria) this;
        }

        public Criteria andKN_STSIn(List<String> values) {
            addCriterion("KN_STS in", values, "KN_STS");
            return (Criteria) this;
        }

        public Criteria andKN_STSNotIn(List<String> values) {
            addCriterion("KN_STS not in", values, "KN_STS");
            return (Criteria) this;
        }

        public Criteria andKN_STSBetween(String value1, String value2) {
            addCriterion("KN_STS between", value1, value2, "KN_STS");
            return (Criteria) this;
        }

        public Criteria andKN_STSNotBetween(String value1, String value2) {
            addCriterion("KN_STS not between", value1, value2, "KN_STS");
            return (Criteria) this;
        }

        public Criteria andDN0_STSIsNull() {
            addCriterion("DN0_STS is null");
            return (Criteria) this;
        }

        public Criteria andDN0_STSIsNotNull() {
            addCriterion("DN0_STS is not null");
            return (Criteria) this;
        }

        public Criteria andDN0_STSEqualTo(String value) {
            addCriterion("DN0_STS =", value, "DN0_STS");
            return (Criteria) this;
        }

        public Criteria andDN0_STSNotEqualTo(String value) {
            addCriterion("DN0_STS <>", value, "DN0_STS");
            return (Criteria) this;
        }

        public Criteria andDN0_STSGreaterThan(String value) {
            addCriterion("DN0_STS >", value, "DN0_STS");
            return (Criteria) this;
        }

        public Criteria andDN0_STSGreaterThanOrEqualTo(String value) {
            addCriterion("DN0_STS >=", value, "DN0_STS");
            return (Criteria) this;
        }

        public Criteria andDN0_STSLessThan(String value) {
            addCriterion("DN0_STS <", value, "DN0_STS");
            return (Criteria) this;
        }

        public Criteria andDN0_STSLessThanOrEqualTo(String value) {
            addCriterion("DN0_STS <=", value, "DN0_STS");
            return (Criteria) this;
        }

        public Criteria andDN0_STSLike(String value) {
            addCriterion("DN0_STS like", value, "DN0_STS");
            return (Criteria) this;
        }

        public Criteria andDN0_STSNotLike(String value) {
            addCriterion("DN0_STS not like", value, "DN0_STS");
            return (Criteria) this;
        }

        public Criteria andDN0_STSIn(List<String> values) {
            addCriterion("DN0_STS in", values, "DN0_STS");
            return (Criteria) this;
        }

        public Criteria andDN0_STSNotIn(List<String> values) {
            addCriterion("DN0_STS not in", values, "DN0_STS");
            return (Criteria) this;
        }

        public Criteria andDN0_STSBetween(String value1, String value2) {
            addCriterion("DN0_STS between", value1, value2, "DN0_STS");
            return (Criteria) this;
        }

        public Criteria andDN0_STSNotBetween(String value1, String value2) {
            addCriterion("DN0_STS not between", value1, value2, "DN0_STS");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andLN_KEIBI_STS_DTL_READ1LikeInsensitive(String value) {
            addCriterion("upper(LN_KEIBI_STS_DTL_READ1) like", value.toUpperCase(), "LN_KEIBI_STS_DTL_READ1");
            return (Criteria) this;
        }

        public Criteria andLN_RD_KB_STSLikeInsensitive(String value) {
            addCriterion("upper(LN_RD_KB_STS) like", value.toUpperCase(), "LN_RD_KB_STS");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDRLikeInsensitive(String value) {
            addCriterion("upper(SUB_ADDR) like", value.toUpperCase(), "SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andN0_STSLikeInsensitive(String value) {
            addCriterion("upper(N0_STS) like", value.toUpperCase(), "n0_STS");
            return (Criteria) this;
        }

        public Criteria andKN_STSLikeInsensitive(String value) {
            addCriterion("upper(KN_STS) like", value.toUpperCase(), "KN_STS");
            return (Criteria) this;
        }

        public Criteria andDN0_STSLikeInsensitive(String value) {
            addCriterion("upper(DN0_STS) like", value.toUpperCase(), "DN0_STS");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * H_KEIBI_STS_RD_DTL_RHTBL1
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * H_KEIBI_STS_RD_DTL_RHTBL1 null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}