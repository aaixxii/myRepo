package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class EV6Rakuf extends EV6RakufKey implements Serializable {
    /**
     * 住所コード
     */
    private String ADDR_CD;

    /**
     * 出動区分
     */
    private String SYUTUDOU_KBN;

    /**
     * 応援設定マーク
     */
    private String OUEN_MARK;

    /**
     * 落着席番
     */
    private String RAKU_SEKI;

    /**
     * 落着監視員社員番号
     */
    private String RAKU_OPERATOR_NUM;

    /**
     * 落着監視員名
     */
    private String RAKU_NM;

    /**
     * 落着日付
     */
    private String RAKU_TS;

    /**
     * 入館時間
     */
    private String NYUKAN_TM;

    /**
     * 退館時間
     */
    private String TAIKAN_TM;

    /**
     * 終了時間
     */
    private String END_TM;

    /**
     * 終了予定日時
     */
    private String END_YOTEI_TS;

    /**
     * 警察通報時間
     */
    private String POLICE_CALL_TM;

    /**
     * 警察到着時間
     */
    private String POLICE_ARRIV_TM;

    /**
     * 消防通報時間
     */
    private String FIRE_CALL_TM;

    /**
     * 消防到着時間
     */
    private String FIRE_ARRIV_TM;

    /**
     * 警察_理由コード
     */
    private String POLICE_REASON_CD;

    /**
     * 警察_通報理由
     */
    private String POLICE_CALL_REASON;

    /**
     * 警察_通報先区分
     */
    private String POLICE_CALL_KBN;

    /**
     * 警察_真報／誤報
     */
    private String POLICE_SINPO;

    /**
     * 警察_退館時間
     */
    private String POLICE_TAIKAN_TM;

    /**
     * 消防_理由コード
     */
    private String FIRE_REASON_CD;

    /**
     * 消防_通報理由
     */
    private String FIRE_CALL_REASON;

    /**
     * 消防_通報先区分
     */
    private String FIRE_CALL_KBN;

    /**
     * 消防_真報／誤報
     */
    private String FIRE_SINPO;

    /**
     * 消防_退館時間
     */
    private String FIRE_TAIKAN_TM;

    /**
     * SGS原因コード
     */
    private String SGS_GENIN_CD;

    /**
     * 原因詳細内容
     */
    private String GEN_DTL_NAIYOU;

    /**
     * 原因内容１
     */
    private String GEN_NAIYOU_1;

    /**
     * 原因内容２
     */
    private String GEN_NAIYOU_2;

    /**
     * 事案分類コード
     */
    private String JIANBNRCD;

    /**
     * 警報分類コード
     */
    private String KEIHOBNRCD;

    /**
     * 原因分類コード
     */
    private String GENBNRCD;

    /**
     * ＮＥＴ原因コード
     */
    private String NET_GEN_CD;

    /**
     * ＮＥＴ原因内容
     */
    private String NET_GEN_NAIYOU;

    /**
     * 警備情報
     */
    private String KEIBI_INF;

    /**
     * 落着更新日付
     */
    private String RAKU_UPDATE_TS;

    /**
     * 事業所コード
     */
    private String JIGYO_CD;

    /**
     * 事業所名
     */
    private String JIGYO_NM;

    /**
     * 事態コード
     */
    private String JITAI_CD;

    /**
     * 警報日付
     */
    private String KEIHOU_DATE;

    /**
     * 退館区分
     */
    private String TAIKAN_KBN;

    /**
     * LN_事案情報論理番号
     */
    private String LN_JIAN;

    /**
     * 指示時間
     */
    private String SIJI_TM;

    /**
     * 直行時間
     */
    private String CHOKKOU_TM;

    /**
     * 現着時間
     */
    private String GENCHAKU_TM;

    /**
     * 最終更新日時
     */
    private Date LASTUPD_TS;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * E_V6_RAKUF
     */
    private static final long serialVersionUID = 1L;

    /**
     * 住所コード
     * @return ADDR_CD 住所コード
     */
    public String getADDR_CD() {
        return ADDR_CD;
    }

    /**
     * 住所コード
     * @param ADDR_CD 住所コード
     */
    public void setADDR_CD(String ADDR_CD) {
        this.ADDR_CD = ADDR_CD == null ? null : ADDR_CD.trim();
    }

    /**
     * 出動区分
     * @return SYUTUDOU_KBN 出動区分
     */
    public String getSYUTUDOU_KBN() {
        return SYUTUDOU_KBN;
    }

    /**
     * 出動区分
     * @param SYUTUDOU_KBN 出動区分
     */
    public void setSYUTUDOU_KBN(String SYUTUDOU_KBN) {
        this.SYUTUDOU_KBN = SYUTUDOU_KBN == null ? null : SYUTUDOU_KBN.trim();
    }

    /**
     * 応援設定マーク
     * @return OUEN_MARK 応援設定マーク
     */
    public String getOUEN_MARK() {
        return OUEN_MARK;
    }

    /**
     * 応援設定マーク
     * @param OUEN_MARK 応援設定マーク
     */
    public void setOUEN_MARK(String OUEN_MARK) {
        this.OUEN_MARK = OUEN_MARK == null ? null : OUEN_MARK.trim();
    }

    /**
     * 落着席番
     * @return RAKU_SEKI 落着席番
     */
    public String getRAKU_SEKI() {
        return RAKU_SEKI;
    }

    /**
     * 落着席番
     * @param RAKU_SEKI 落着席番
     */
    public void setRAKU_SEKI(String RAKU_SEKI) {
        this.RAKU_SEKI = RAKU_SEKI == null ? null : RAKU_SEKI.trim();
    }

    /**
     * 落着監視員社員番号
     * @return RAKU_OPERATOR_NUM 落着監視員社員番号
     */
    public String getRAKU_OPERATOR_NUM() {
        return RAKU_OPERATOR_NUM;
    }

    /**
     * 落着監視員社員番号
     * @param RAKU_OPERATOR_NUM 落着監視員社員番号
     */
    public void setRAKU_OPERATOR_NUM(String RAKU_OPERATOR_NUM) {
        this.RAKU_OPERATOR_NUM = RAKU_OPERATOR_NUM == null ? null : RAKU_OPERATOR_NUM.trim();
    }

    /**
     * 落着監視員名
     * @return RAKU_NM 落着監視員名
     */
    public String getRAKU_NM() {
        return RAKU_NM;
    }

    /**
     * 落着監視員名
     * @param RAKU_NM 落着監視員名
     */
    public void setRAKU_NM(String RAKU_NM) {
        this.RAKU_NM = RAKU_NM == null ? null : RAKU_NM.trim();
    }

    /**
     * 落着日付
     * @return RAKU_TS 落着日付
     */
    public String getRAKU_TS() {
        return RAKU_TS;
    }

    /**
     * 落着日付
     * @param RAKU_TS 落着日付
     */
    public void setRAKU_TS(String RAKU_TS) {
        this.RAKU_TS = RAKU_TS == null ? null : RAKU_TS.trim();
    }

    /**
     * 入館時間
     * @return NYUKAN_TM 入館時間
     */
    public String getNYUKAN_TM() {
        return NYUKAN_TM;
    }

    /**
     * 入館時間
     * @param NYUKAN_TM 入館時間
     */
    public void setNYUKAN_TM(String NYUKAN_TM) {
        this.NYUKAN_TM = NYUKAN_TM == null ? null : NYUKAN_TM.trim();
    }

    /**
     * 退館時間
     * @return TAIKAN_TM 退館時間
     */
    public String getTAIKAN_TM() {
        return TAIKAN_TM;
    }

    /**
     * 退館時間
     * @param TAIKAN_TM 退館時間
     */
    public void setTAIKAN_TM(String TAIKAN_TM) {
        this.TAIKAN_TM = TAIKAN_TM == null ? null : TAIKAN_TM.trim();
    }

    /**
     * 終了時間
     * @return END_TM 終了時間
     */
    public String getEND_TM() {
        return END_TM;
    }

    /**
     * 終了時間
     * @param END_TM 終了時間
     */
    public void setEND_TM(String END_TM) {
        this.END_TM = END_TM == null ? null : END_TM.trim();
    }

    /**
     * 終了予定日時
     * @return END_YOTEI_TS 終了予定日時
     */
    public String getEND_YOTEI_TS() {
        return END_YOTEI_TS;
    }

    /**
     * 終了予定日時
     * @param END_YOTEI_TS 終了予定日時
     */
    public void setEND_YOTEI_TS(String END_YOTEI_TS) {
        this.END_YOTEI_TS = END_YOTEI_TS == null ? null : END_YOTEI_TS.trim();
    }

    /**
     * 警察通報時間
     * @return POLICE_CALL_TM 警察通報時間
     */
    public String getPOLICE_CALL_TM() {
        return POLICE_CALL_TM;
    }

    /**
     * 警察通報時間
     * @param POLICE_CALL_TM 警察通報時間
     */
    public void setPOLICE_CALL_TM(String POLICE_CALL_TM) {
        this.POLICE_CALL_TM = POLICE_CALL_TM == null ? null : POLICE_CALL_TM.trim();
    }

    /**
     * 警察到着時間
     * @return POLICE_ARRIV_TM 警察到着時間
     */
    public String getPOLICE_ARRIV_TM() {
        return POLICE_ARRIV_TM;
    }

    /**
     * 警察到着時間
     * @param POLICE_ARRIV_TM 警察到着時間
     */
    public void setPOLICE_ARRIV_TM(String POLICE_ARRIV_TM) {
        this.POLICE_ARRIV_TM = POLICE_ARRIV_TM == null ? null : POLICE_ARRIV_TM.trim();
    }

    /**
     * 消防通報時間
     * @return FIRE_CALL_TM 消防通報時間
     */
    public String getFIRE_CALL_TM() {
        return FIRE_CALL_TM;
    }

    /**
     * 消防通報時間
     * @param FIRE_CALL_TM 消防通報時間
     */
    public void setFIRE_CALL_TM(String FIRE_CALL_TM) {
        this.FIRE_CALL_TM = FIRE_CALL_TM == null ? null : FIRE_CALL_TM.trim();
    }

    /**
     * 消防到着時間
     * @return FIRE_ARRIV_TM 消防到着時間
     */
    public String getFIRE_ARRIV_TM() {
        return FIRE_ARRIV_TM;
    }

    /**
     * 消防到着時間
     * @param FIRE_ARRIV_TM 消防到着時間
     */
    public void setFIRE_ARRIV_TM(String FIRE_ARRIV_TM) {
        this.FIRE_ARRIV_TM = FIRE_ARRIV_TM == null ? null : FIRE_ARRIV_TM.trim();
    }

    /**
     * 警察_理由コード
     * @return POLICE_REASON_CD 警察_理由コード
     */
    public String getPOLICE_REASON_CD() {
        return POLICE_REASON_CD;
    }

    /**
     * 警察_理由コード
     * @param POLICE_REASON_CD 警察_理由コード
     */
    public void setPOLICE_REASON_CD(String POLICE_REASON_CD) {
        this.POLICE_REASON_CD = POLICE_REASON_CD == null ? null : POLICE_REASON_CD.trim();
    }

    /**
     * 警察_通報理由
     * @return POLICE_CALL_REASON 警察_通報理由
     */
    public String getPOLICE_CALL_REASON() {
        return POLICE_CALL_REASON;
    }

    /**
     * 警察_通報理由
     * @param POLICE_CALL_REASON 警察_通報理由
     */
    public void setPOLICE_CALL_REASON(String POLICE_CALL_REASON) {
        this.POLICE_CALL_REASON = POLICE_CALL_REASON == null ? null : POLICE_CALL_REASON.trim();
    }

    /**
     * 警察_通報先区分
     * @return POLICE_CALL_KBN 警察_通報先区分
     */
    public String getPOLICE_CALL_KBN() {
        return POLICE_CALL_KBN;
    }

    /**
     * 警察_通報先区分
     * @param POLICE_CALL_KBN 警察_通報先区分
     */
    public void setPOLICE_CALL_KBN(String POLICE_CALL_KBN) {
        this.POLICE_CALL_KBN = POLICE_CALL_KBN == null ? null : POLICE_CALL_KBN.trim();
    }

    /**
     * 警察_真報／誤報
     * @return POLICE_SINPO 警察_真報／誤報
     */
    public String getPOLICE_SINPO() {
        return POLICE_SINPO;
    }

    /**
     * 警察_真報／誤報
     * @param POLICE_SINPO 警察_真報／誤報
     */
    public void setPOLICE_SINPO(String POLICE_SINPO) {
        this.POLICE_SINPO = POLICE_SINPO == null ? null : POLICE_SINPO.trim();
    }

    /**
     * 警察_退館時間
     * @return POLICE_TAIKAN_TM 警察_退館時間
     */
    public String getPOLICE_TAIKAN_TM() {
        return POLICE_TAIKAN_TM;
    }

    /**
     * 警察_退館時間
     * @param POLICE_TAIKAN_TM 警察_退館時間
     */
    public void setPOLICE_TAIKAN_TM(String POLICE_TAIKAN_TM) {
        this.POLICE_TAIKAN_TM = POLICE_TAIKAN_TM == null ? null : POLICE_TAIKAN_TM.trim();
    }

    /**
     * 消防_理由コード
     * @return FIRE_REASON_CD 消防_理由コード
     */
    public String getFIRE_REASON_CD() {
        return FIRE_REASON_CD;
    }

    /**
     * 消防_理由コード
     * @param FIRE_REASON_CD 消防_理由コード
     */
    public void setFIRE_REASON_CD(String FIRE_REASON_CD) {
        this.FIRE_REASON_CD = FIRE_REASON_CD == null ? null : FIRE_REASON_CD.trim();
    }

    /**
     * 消防_通報理由
     * @return FIRE_CALL_REASON 消防_通報理由
     */
    public String getFIRE_CALL_REASON() {
        return FIRE_CALL_REASON;
    }

    /**
     * 消防_通報理由
     * @param FIRE_CALL_REASON 消防_通報理由
     */
    public void setFIRE_CALL_REASON(String FIRE_CALL_REASON) {
        this.FIRE_CALL_REASON = FIRE_CALL_REASON == null ? null : FIRE_CALL_REASON.trim();
    }

    /**
     * 消防_通報先区分
     * @return FIRE_CALL_KBN 消防_通報先区分
     */
    public String getFIRE_CALL_KBN() {
        return FIRE_CALL_KBN;
    }

    /**
     * 消防_通報先区分
     * @param FIRE_CALL_KBN 消防_通報先区分
     */
    public void setFIRE_CALL_KBN(String FIRE_CALL_KBN) {
        this.FIRE_CALL_KBN = FIRE_CALL_KBN == null ? null : FIRE_CALL_KBN.trim();
    }

    /**
     * 消防_真報／誤報
     * @return FIRE_SINPO 消防_真報／誤報
     */
    public String getFIRE_SINPO() {
        return FIRE_SINPO;
    }

    /**
     * 消防_真報／誤報
     * @param FIRE_SINPO 消防_真報／誤報
     */
    public void setFIRE_SINPO(String FIRE_SINPO) {
        this.FIRE_SINPO = FIRE_SINPO == null ? null : FIRE_SINPO.trim();
    }

    /**
     * 消防_退館時間
     * @return FIRE_TAIKAN_TM 消防_退館時間
     */
    public String getFIRE_TAIKAN_TM() {
        return FIRE_TAIKAN_TM;
    }

    /**
     * 消防_退館時間
     * @param FIRE_TAIKAN_TM 消防_退館時間
     */
    public void setFIRE_TAIKAN_TM(String FIRE_TAIKAN_TM) {
        this.FIRE_TAIKAN_TM = FIRE_TAIKAN_TM == null ? null : FIRE_TAIKAN_TM.trim();
    }

    /**
     * SGS原因コード
     * @return SGS_GENIN_CD SGS原因コード
     */
    public String getSGS_GENIN_CD() {
        return SGS_GENIN_CD;
    }

    /**
     * SGS原因コード
     * @param SGS_GENIN_CD SGS原因コード
     */
    public void setSGS_GENIN_CD(String SGS_GENIN_CD) {
        this.SGS_GENIN_CD = SGS_GENIN_CD == null ? null : SGS_GENIN_CD.trim();
    }

    /**
     * 原因詳細内容
     * @return GEN_DTL_NAIYOU 原因詳細内容
     */
    public String getGEN_DTL_NAIYOU() {
        return GEN_DTL_NAIYOU;
    }

    /**
     * 原因詳細内容
     * @param GEN_DTL_NAIYOU 原因詳細内容
     */
    public void setGEN_DTL_NAIYOU(String GEN_DTL_NAIYOU) {
        this.GEN_DTL_NAIYOU = GEN_DTL_NAIYOU == null ? null : GEN_DTL_NAIYOU.trim();
    }

    /**
     * 原因内容１
     * @return GEN_NAIYOU_1 原因内容１
     */
    public String getGEN_NAIYOU_1() {
        return GEN_NAIYOU_1;
    }

    /**
     * 原因内容１
     * @param GEN_NAIYOU_1 原因内容１
     */
    public void setGEN_NAIYOU_1(String GEN_NAIYOU_1) {
        this.GEN_NAIYOU_1 = GEN_NAIYOU_1 == null ? null : GEN_NAIYOU_1.trim();
    }

    /**
     * 原因内容２
     * @return GEN_NAIYOU_2 原因内容２
     */
    public String getGEN_NAIYOU_2() {
        return GEN_NAIYOU_2;
    }

    /**
     * 原因内容２
     * @param GEN_NAIYOU_2 原因内容２
     */
    public void setGEN_NAIYOU_2(String GEN_NAIYOU_2) {
        this.GEN_NAIYOU_2 = GEN_NAIYOU_2 == null ? null : GEN_NAIYOU_2.trim();
    }

    /**
     * 事案分類コード
     * @return JIANBNRCD 事案分類コード
     */
    public String getJIANBNRCD() {
        return JIANBNRCD;
    }

    /**
     * 事案分類コード
     * @param JIANBNRCD 事案分類コード
     */
    public void setJIANBNRCD(String JIANBNRCD) {
        this.JIANBNRCD = JIANBNRCD == null ? null : JIANBNRCD.trim();
    }

    /**
     * 警報分類コード
     * @return KEIHOBNRCD 警報分類コード
     */
    public String getKEIHOBNRCD() {
        return KEIHOBNRCD;
    }

    /**
     * 警報分類コード
     * @param KEIHOBNRCD 警報分類コード
     */
    public void setKEIHOBNRCD(String KEIHOBNRCD) {
        this.KEIHOBNRCD = KEIHOBNRCD == null ? null : KEIHOBNRCD.trim();
    }

    /**
     * 原因分類コード
     * @return GENBNRCD 原因分類コード
     */
    public String getGENBNRCD() {
        return GENBNRCD;
    }

    /**
     * 原因分類コード
     * @param GENBNRCD 原因分類コード
     */
    public void setGENBNRCD(String GENBNRCD) {
        this.GENBNRCD = GENBNRCD == null ? null : GENBNRCD.trim();
    }

    /**
     * ＮＥＴ原因コード
     * @return NET_GEN_CD ＮＥＴ原因コード
     */
    public String getNET_GEN_CD() {
        return NET_GEN_CD;
    }

    /**
     * ＮＥＴ原因コード
     * @param NET_GEN_CD ＮＥＴ原因コード
     */
    public void setNET_GEN_CD(String NET_GEN_CD) {
        this.NET_GEN_CD = NET_GEN_CD == null ? null : NET_GEN_CD.trim();
    }

    /**
     * ＮＥＴ原因内容
     * @return NET_GEN_NAIYOU ＮＥＴ原因内容
     */
    public String getNET_GEN_NAIYOU() {
        return NET_GEN_NAIYOU;
    }

    /**
     * ＮＥＴ原因内容
     * @param NET_GEN_NAIYOU ＮＥＴ原因内容
     */
    public void setNET_GEN_NAIYOU(String NET_GEN_NAIYOU) {
        this.NET_GEN_NAIYOU = NET_GEN_NAIYOU == null ? null : NET_GEN_NAIYOU.trim();
    }

    /**
     * 警備情報
     * @return KEIBI_INF 警備情報
     */
    public String getKEIBI_INF() {
        return KEIBI_INF;
    }

    /**
     * 警備情報
     * @param KEIBI_INF 警備情報
     */
    public void setKEIBI_INF(String KEIBI_INF) {
        this.KEIBI_INF = KEIBI_INF == null ? null : KEIBI_INF.trim();
    }

    /**
     * 落着更新日付
     * @return RAKU_UPDATE_TS 落着更新日付
     */
    public String getRAKU_UPDATE_TS() {
        return RAKU_UPDATE_TS;
    }

    /**
     * 落着更新日付
     * @param RAKU_UPDATE_TS 落着更新日付
     */
    public void setRAKU_UPDATE_TS(String RAKU_UPDATE_TS) {
        this.RAKU_UPDATE_TS = RAKU_UPDATE_TS == null ? null : RAKU_UPDATE_TS.trim();
    }

    /**
     * 事業所コード
     * @return JIGYO_CD 事業所コード
     */
    public String getJIGYO_CD() {
        return JIGYO_CD;
    }

    /**
     * 事業所コード
     * @param JIGYO_CD 事業所コード
     */
    public void setJIGYO_CD(String JIGYO_CD) {
        this.JIGYO_CD = JIGYO_CD == null ? null : JIGYO_CD.trim();
    }

    /**
     * 事業所名
     * @return JIGYO_NM 事業所名
     */
    public String getJIGYO_NM() {
        return JIGYO_NM;
    }

    /**
     * 事業所名
     * @param JIGYO_NM 事業所名
     */
    public void setJIGYO_NM(String JIGYO_NM) {
        this.JIGYO_NM = JIGYO_NM == null ? null : JIGYO_NM.trim();
    }

    /**
     * 事態コード
     * @return JITAI_CD 事態コード
     */
    public String getJITAI_CD() {
        return JITAI_CD;
    }

    /**
     * 事態コード
     * @param JITAI_CD 事態コード
     */
    public void setJITAI_CD(String JITAI_CD) {
        this.JITAI_CD = JITAI_CD == null ? null : JITAI_CD.trim();
    }

    /**
     * 警報日付
     * @return KEIHOU_DATE 警報日付
     */
    public String getKEIHOU_DATE() {
        return KEIHOU_DATE;
    }

    /**
     * 警報日付
     * @param KEIHOU_DATE 警報日付
     */
    public void setKEIHOU_DATE(String KEIHOU_DATE) {
        this.KEIHOU_DATE = KEIHOU_DATE == null ? null : KEIHOU_DATE.trim();
    }

    /**
     * 退館区分
     * @return TAIKAN_KBN 退館区分
     */
    public String getTAIKAN_KBN() {
        return TAIKAN_KBN;
    }

    /**
     * 退館区分
     * @param TAIKAN_KBN 退館区分
     */
    public void setTAIKAN_KBN(String TAIKAN_KBN) {
        this.TAIKAN_KBN = TAIKAN_KBN == null ? null : TAIKAN_KBN.trim();
    }

    /**
     * LN_事案情報論理番号
     * @return LN_JIAN LN_事案情報論理番号
     */
    public String getLN_JIAN() {
        return LN_JIAN;
    }

    /**
     * LN_事案情報論理番号
     * @param LN_JIAN LN_事案情報論理番号
     */
    public void setLN_JIAN(String LN_JIAN) {
        this.LN_JIAN = LN_JIAN == null ? null : LN_JIAN.trim();
    }

    /**
     * 指示時間
     * @return SIJI_TM 指示時間
     */
    public String getSIJI_TM() {
        return SIJI_TM;
    }

    /**
     * 指示時間
     * @param SIJI_TM 指示時間
     */
    public void setSIJI_TM(String SIJI_TM) {
        this.SIJI_TM = SIJI_TM == null ? null : SIJI_TM.trim();
    }

    /**
     * 直行時間
     * @return CHOKKOU_TM 直行時間
     */
    public String getCHOKKOU_TM() {
        return CHOKKOU_TM;
    }

    /**
     * 直行時間
     * @param CHOKKOU_TM 直行時間
     */
    public void setCHOKKOU_TM(String CHOKKOU_TM) {
        this.CHOKKOU_TM = CHOKKOU_TM == null ? null : CHOKKOU_TM.trim();
    }

    /**
     * 現着時間
     * @return GENCHAKU_TM 現着時間
     */
    public String getGENCHAKU_TM() {
        return GENCHAKU_TM;
    }

    /**
     * 現着時間
     * @param GENCHAKU_TM 現着時間
     */
    public void setGENCHAKU_TM(String GENCHAKU_TM) {
        this.GENCHAKU_TM = GENCHAKU_TM == null ? null : GENCHAKU_TM.trim();
    }

    /**
     * 最終更新日時
     * @return LASTUPD_TS 最終更新日時
     */
    public Date getLASTUPD_TS() {
        return LASTUPD_TS;
    }

    /**
     * 最終更新日時
     * @param LASTUPD_TS 最終更新日時
     */
    public void setLASTUPD_TS(Date LASTUPD_TS) {
        this.LASTUPD_TS = LASTUPD_TS;
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}