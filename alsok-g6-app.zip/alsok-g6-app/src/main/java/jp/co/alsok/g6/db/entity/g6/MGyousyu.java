package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class MGyousyu implements Serializable {
    /**
     * 業種ID
     */
    private String GYOUSYU_ID;

    /**
     * 業種名
     */
    private String NM;

    /**
     * M_GYOUSYU
     */
    private static final long serialVersionUID = 1L;

    /**
     * 業種ID
     * @return GYOUSYU_ID 業種ID
     */
    public String getGYOUSYU_ID() {
        return GYOUSYU_ID;
    }

    /**
     * 業種ID
     * @param GYOUSYU_ID 業種ID
     */
    public void setGYOUSYU_ID(String GYOUSYU_ID) {
        this.GYOUSYU_ID = GYOUSYU_ID == null ? null : GYOUSYU_ID.trim();
    }

    /**
     * 業種名
     * @return NM 業種名
     */
    public String getNM() {
        return NM;
    }

    /**
     * 業種名
     * @param NM 業種名
     */
    public void setNM(String NM) {
        this.NM = NM == null ? null : NM.trim();
    }
}