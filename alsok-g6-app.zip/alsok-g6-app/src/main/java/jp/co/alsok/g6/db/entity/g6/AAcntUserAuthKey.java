package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class AAcntUserAuthKey implements Serializable {
    /**
     * LN_利用者アカウント共通論理番号
     */
    private String LN_ACNT_USER_COMMON;

    /**
     * LN_利用者アカウント権限ID
     */
    private String LN_USER_ACNT_AUTH_ID;

    /**
     * パス情報
     */
    private String PATH_INF;

    /**
     * A_ACNT_USER_AUTH
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_利用者アカウント共通論理番号
     * @return LN_ACNT_USER_COMMON LN_利用者アカウント共通論理番号
     */
    public String getLN_ACNT_USER_COMMON() {
        return LN_ACNT_USER_COMMON;
    }

    /**
     * LN_利用者アカウント共通論理番号
     * @param LN_ACNT_USER_COMMON LN_利用者アカウント共通論理番号
     */
    public void setLN_ACNT_USER_COMMON(String LN_ACNT_USER_COMMON) {
        this.LN_ACNT_USER_COMMON = LN_ACNT_USER_COMMON == null ? null : LN_ACNT_USER_COMMON.trim();
    }

    /**
     * LN_利用者アカウント権限ID
     * @return LN_USER_ACNT_AUTH_ID LN_利用者アカウント権限ID
     */
    public String getLN_USER_ACNT_AUTH_ID() {
        return LN_USER_ACNT_AUTH_ID;
    }

    /**
     * LN_利用者アカウント権限ID
     * @param LN_USER_ACNT_AUTH_ID LN_利用者アカウント権限ID
     */
    public void setLN_USER_ACNT_AUTH_ID(String LN_USER_ACNT_AUTH_ID) {
        this.LN_USER_ACNT_AUTH_ID = LN_USER_ACNT_AUTH_ID == null ? null : LN_USER_ACNT_AUTH_ID.trim();
    }

    /**
     * パス情報
     * @return PATH_INF パス情報
     */
    public String getPATH_INF() {
        return PATH_INF;
    }

    /**
     * パス情報
     * @param PATH_INF パス情報
     */
    public void setPATH_INF(String PATH_INF) {
        this.PATH_INF = PATH_INF == null ? null : PATH_INF.trim();
    }
}