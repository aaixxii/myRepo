package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CQueMlTrigExample {
    /**
     * C_QUE_ML_TRIG
     */
    protected String orderByClause;

    /**
     * C_QUE_ML_TRIG
     */
    protected boolean distinct;

    /**
     * C_QUE_ML_TRIG
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public CQueMlTrigExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * C_QUE_ML_TRIG null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_ML_TRIGIsNull() {
            addCriterion("LN_ML_TRIG is null");
            return (Criteria) this;
        }

        public Criteria andLN_ML_TRIGIsNotNull() {
            addCriterion("LN_ML_TRIG is not null");
            return (Criteria) this;
        }

        public Criteria andLN_ML_TRIGEqualTo(String value) {
            addCriterion("LN_ML_TRIG =", value, "LN_ML_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_ML_TRIGNotEqualTo(String value) {
            addCriterion("LN_ML_TRIG <>", value, "LN_ML_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_ML_TRIGGreaterThan(String value) {
            addCriterion("LN_ML_TRIG >", value, "LN_ML_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_ML_TRIGGreaterThanOrEqualTo(String value) {
            addCriterion("LN_ML_TRIG >=", value, "LN_ML_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_ML_TRIGLessThan(String value) {
            addCriterion("LN_ML_TRIG <", value, "LN_ML_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_ML_TRIGLessThanOrEqualTo(String value) {
            addCriterion("LN_ML_TRIG <=", value, "LN_ML_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_ML_TRIGLike(String value) {
            addCriterion("LN_ML_TRIG like", value, "LN_ML_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_ML_TRIGNotLike(String value) {
            addCriterion("LN_ML_TRIG not like", value, "LN_ML_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_ML_TRIGIn(List<String> values) {
            addCriterion("LN_ML_TRIG in", values, "LN_ML_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_ML_TRIGNotIn(List<String> values) {
            addCriterion("LN_ML_TRIG not in", values, "LN_ML_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_ML_TRIGBetween(String value1, String value2) {
            addCriterion("LN_ML_TRIG between", value1, value2, "LN_ML_TRIG");
            return (Criteria) this;
        }

        public Criteria andLN_ML_TRIGNotBetween(String value1, String value2) {
            addCriterion("LN_ML_TRIG not between", value1, value2, "LN_ML_TRIG");
            return (Criteria) this;
        }

        public Criteria andKINDIsNull() {
            addCriterion("KIND is null");
            return (Criteria) this;
        }

        public Criteria andKINDIsNotNull() {
            addCriterion("KIND is not null");
            return (Criteria) this;
        }

        public Criteria andKINDEqualTo(String value) {
            addCriterion("KIND =", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDNotEqualTo(String value) {
            addCriterion("KIND <>", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDGreaterThan(String value) {
            addCriterion("KIND >", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDGreaterThanOrEqualTo(String value) {
            addCriterion("KIND >=", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDLessThan(String value) {
            addCriterion("KIND <", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDLessThanOrEqualTo(String value) {
            addCriterion("KIND <=", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDLike(String value) {
            addCriterion("KIND like", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDNotLike(String value) {
            addCriterion("KIND not like", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDIn(List<String> values) {
            addCriterion("KIND in", values, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDNotIn(List<String> values) {
            addCriterion("KIND not in", values, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDBetween(String value1, String value2) {
            addCriterion("KIND between", value1, value2, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDNotBetween(String value1, String value2) {
            addCriterion("KIND not between", value1, value2, "KIND");
            return (Criteria) this;
        }

        public Criteria andSTSIsNull() {
            addCriterion("STS is null");
            return (Criteria) this;
        }

        public Criteria andSTSIsNotNull() {
            addCriterion("STS is not null");
            return (Criteria) this;
        }

        public Criteria andSTSEqualTo(String value) {
            addCriterion("STS =", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSNotEqualTo(String value) {
            addCriterion("STS <>", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSGreaterThan(String value) {
            addCriterion("STS >", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSGreaterThanOrEqualTo(String value) {
            addCriterion("STS >=", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSLessThan(String value) {
            addCriterion("STS <", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSLessThanOrEqualTo(String value) {
            addCriterion("STS <=", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSLike(String value) {
            addCriterion("STS like", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSNotLike(String value) {
            addCriterion("STS not like", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSIn(List<String> values) {
            addCriterion("STS in", values, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSNotIn(List<String> values) {
            addCriterion("STS not in", values, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSBetween(String value1, String value2) {
            addCriterion("STS between", value1, value2, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSNotBetween(String value1, String value2) {
            addCriterion("STS not between", value1, value2, "STS");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFIsNull() {
            addCriterion("LN_KB_INF is null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFIsNotNull() {
            addCriterion("LN_KB_INF is not null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFEqualTo(String value) {
            addCriterion("LN_KB_INF =", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFNotEqualTo(String value) {
            addCriterion("LN_KB_INF <>", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFGreaterThan(String value) {
            addCriterion("LN_KB_INF >", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFGreaterThanOrEqualTo(String value) {
            addCriterion("LN_KB_INF >=", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFLessThan(String value) {
            addCriterion("LN_KB_INF <", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFLessThanOrEqualTo(String value) {
            addCriterion("LN_KB_INF <=", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFLike(String value) {
            addCriterion("LN_KB_INF like", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFNotLike(String value) {
            addCriterion("LN_KB_INF not like", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFIn(List<String> values) {
            addCriterion("LN_KB_INF in", values, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFNotIn(List<String> values) {
            addCriterion("LN_KB_INF not in", values, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFBetween(String value1, String value2) {
            addCriterion("LN_KB_INF between", value1, value2, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFNotBetween(String value1, String value2) {
            addCriterion("LN_KB_INF not between", value1, value2, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICEIsNull() {
            addCriterion("LN_NOTICE is null");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICEIsNotNull() {
            addCriterion("LN_NOTICE is not null");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICEEqualTo(String value) {
            addCriterion("LN_NOTICE =", value, "LN_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICENotEqualTo(String value) {
            addCriterion("LN_NOTICE <>", value, "LN_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICEGreaterThan(String value) {
            addCriterion("LN_NOTICE >", value, "LN_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICEGreaterThanOrEqualTo(String value) {
            addCriterion("LN_NOTICE >=", value, "LN_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICELessThan(String value) {
            addCriterion("LN_NOTICE <", value, "LN_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICELessThanOrEqualTo(String value) {
            addCriterion("LN_NOTICE <=", value, "LN_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICELike(String value) {
            addCriterion("LN_NOTICE like", value, "LN_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICENotLike(String value) {
            addCriterion("LN_NOTICE not like", value, "LN_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICEIn(List<String> values) {
            addCriterion("LN_NOTICE in", values, "LN_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICENotIn(List<String> values) {
            addCriterion("LN_NOTICE not in", values, "LN_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICEBetween(String value1, String value2) {
            addCriterion("LN_NOTICE between", value1, value2, "LN_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICENotBetween(String value1, String value2) {
            addCriterion("LN_NOTICE not between", value1, value2, "LN_NOTICE");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSIsNull() {
            addCriterion("SEND_ABL_TS is null");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSIsNotNull() {
            addCriterion("SEND_ABL_TS is not null");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSEqualTo(Date value) {
            addCriterion("SEND_ABL_TS =", value, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSNotEqualTo(Date value) {
            addCriterion("SEND_ABL_TS <>", value, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSGreaterThan(Date value) {
            addCriterion("SEND_ABL_TS >", value, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("SEND_ABL_TS >=", value, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSLessThan(Date value) {
            addCriterion("SEND_ABL_TS <", value, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSLessThanOrEqualTo(Date value) {
            addCriterion("SEND_ABL_TS <=", value, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSIn(List<Date> values) {
            addCriterion("SEND_ABL_TS in", values, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSNotIn(List<Date> values) {
            addCriterion("SEND_ABL_TS not in", values, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSBetween(Date value1, Date value2) {
            addCriterion("SEND_ABL_TS between", value1, value2, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andSEND_ABL_TSNotBetween(Date value1, Date value2) {
            addCriterion("SEND_ABL_TS not between", value1, value2, "SEND_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUIsNull() {
            addCriterion("LN_KB_CHIKU is null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUIsNotNull() {
            addCriterion("LN_KB_CHIKU is not null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUEqualTo(String value) {
            addCriterion("LN_KB_CHIKU =", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUNotEqualTo(String value) {
            addCriterion("LN_KB_CHIKU <>", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUGreaterThan(String value) {
            addCriterion("LN_KB_CHIKU >", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUGreaterThanOrEqualTo(String value) {
            addCriterion("LN_KB_CHIKU >=", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKULessThan(String value) {
            addCriterion("LN_KB_CHIKU <", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKULessThanOrEqualTo(String value) {
            addCriterion("LN_KB_CHIKU <=", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKULike(String value) {
            addCriterion("LN_KB_CHIKU like", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUNotLike(String value) {
            addCriterion("LN_KB_CHIKU not like", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUIn(List<String> values) {
            addCriterion("LN_KB_CHIKU in", values, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUNotIn(List<String> values) {
            addCriterion("LN_KB_CHIKU not in", values, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUBetween(String value1, String value2) {
            addCriterion("LN_KB_CHIKU between", value1, value2, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUNotBetween(String value1, String value2) {
            addCriterion("LN_KB_CHIKU not between", value1, value2, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGIsNull() {
            addCriterion("LN_TENANT_MNG is null");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGIsNotNull() {
            addCriterion("LN_TENANT_MNG is not null");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGEqualTo(String value) {
            addCriterion("LN_TENANT_MNG =", value, "LN_TENANT_MNG");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGNotEqualTo(String value) {
            addCriterion("LN_TENANT_MNG <>", value, "LN_TENANT_MNG");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGGreaterThan(String value) {
            addCriterion("LN_TENANT_MNG >", value, "LN_TENANT_MNG");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGGreaterThanOrEqualTo(String value) {
            addCriterion("LN_TENANT_MNG >=", value, "LN_TENANT_MNG");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGLessThan(String value) {
            addCriterion("LN_TENANT_MNG <", value, "LN_TENANT_MNG");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGLessThanOrEqualTo(String value) {
            addCriterion("LN_TENANT_MNG <=", value, "LN_TENANT_MNG");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGLike(String value) {
            addCriterion("LN_TENANT_MNG like", value, "LN_TENANT_MNG");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGNotLike(String value) {
            addCriterion("LN_TENANT_MNG not like", value, "LN_TENANT_MNG");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGIn(List<String> values) {
            addCriterion("LN_TENANT_MNG in", values, "LN_TENANT_MNG");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGNotIn(List<String> values) {
            addCriterion("LN_TENANT_MNG not in", values, "LN_TENANT_MNG");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGBetween(String value1, String value2) {
            addCriterion("LN_TENANT_MNG between", value1, value2, "LN_TENANT_MNG");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGNotBetween(String value1, String value2) {
            addCriterion("LN_TENANT_MNG not between", value1, value2, "LN_TENANT_MNG");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDIsNull() {
            addCriterion("ALSOK_NOTICE_SEND_SVC_KIND is null");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDIsNotNull() {
            addCriterion("ALSOK_NOTICE_SEND_SVC_KIND is not null");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDEqualTo(String value) {
            addCriterion("ALSOK_NOTICE_SEND_SVC_KIND =", value, "ALSOK_NOTICE_SEND_SVC_KIND");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDNotEqualTo(String value) {
            addCriterion("ALSOK_NOTICE_SEND_SVC_KIND <>", value, "ALSOK_NOTICE_SEND_SVC_KIND");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDGreaterThan(String value) {
            addCriterion("ALSOK_NOTICE_SEND_SVC_KIND >", value, "ALSOK_NOTICE_SEND_SVC_KIND");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDGreaterThanOrEqualTo(String value) {
            addCriterion("ALSOK_NOTICE_SEND_SVC_KIND >=", value, "ALSOK_NOTICE_SEND_SVC_KIND");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDLessThan(String value) {
            addCriterion("ALSOK_NOTICE_SEND_SVC_KIND <", value, "ALSOK_NOTICE_SEND_SVC_KIND");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDLessThanOrEqualTo(String value) {
            addCriterion("ALSOK_NOTICE_SEND_SVC_KIND <=", value, "ALSOK_NOTICE_SEND_SVC_KIND");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDLike(String value) {
            addCriterion("ALSOK_NOTICE_SEND_SVC_KIND like", value, "ALSOK_NOTICE_SEND_SVC_KIND");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDNotLike(String value) {
            addCriterion("ALSOK_NOTICE_SEND_SVC_KIND not like", value, "ALSOK_NOTICE_SEND_SVC_KIND");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDIn(List<String> values) {
            addCriterion("ALSOK_NOTICE_SEND_SVC_KIND in", values, "ALSOK_NOTICE_SEND_SVC_KIND");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDNotIn(List<String> values) {
            addCriterion("ALSOK_NOTICE_SEND_SVC_KIND not in", values, "ALSOK_NOTICE_SEND_SVC_KIND");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDBetween(String value1, String value2) {
            addCriterion("ALSOK_NOTICE_SEND_SVC_KIND between", value1, value2, "ALSOK_NOTICE_SEND_SVC_KIND");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDNotBetween(String value1, String value2) {
            addCriterion("ALSOK_NOTICE_SEND_SVC_KIND not between", value1, value2, "ALSOK_NOTICE_SEND_SVC_KIND");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONIsNull() {
            addCriterion("LN_ACNT_USER_COMMON is null");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONIsNotNull() {
            addCriterion("LN_ACNT_USER_COMMON is not null");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONEqualTo(String value) {
            addCriterion("LN_ACNT_USER_COMMON =", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONNotEqualTo(String value) {
            addCriterion("LN_ACNT_USER_COMMON <>", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONGreaterThan(String value) {
            addCriterion("LN_ACNT_USER_COMMON >", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONGreaterThanOrEqualTo(String value) {
            addCriterion("LN_ACNT_USER_COMMON >=", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONLessThan(String value) {
            addCriterion("LN_ACNT_USER_COMMON <", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONLessThanOrEqualTo(String value) {
            addCriterion("LN_ACNT_USER_COMMON <=", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONLike(String value) {
            addCriterion("LN_ACNT_USER_COMMON like", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONNotLike(String value) {
            addCriterion("LN_ACNT_USER_COMMON not like", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONIn(List<String> values) {
            addCriterion("LN_ACNT_USER_COMMON in", values, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONNotIn(List<String> values) {
            addCriterion("LN_ACNT_USER_COMMON not in", values, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONBetween(String value1, String value2) {
            addCriterion("LN_ACNT_USER_COMMON between", value1, value2, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONNotBetween(String value1, String value2) {
            addCriterion("LN_ACNT_USER_COMMON not between", value1, value2, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TOIsNull() {
            addCriterion("FILE_NM_TO is null");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TOIsNotNull() {
            addCriterion("FILE_NM_TO is not null");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TOEqualTo(String value) {
            addCriterion("FILE_NM_TO =", value, "FILE_NM_TO");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TONotEqualTo(String value) {
            addCriterion("FILE_NM_TO <>", value, "FILE_NM_TO");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TOGreaterThan(String value) {
            addCriterion("FILE_NM_TO >", value, "FILE_NM_TO");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TOGreaterThanOrEqualTo(String value) {
            addCriterion("FILE_NM_TO >=", value, "FILE_NM_TO");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TOLessThan(String value) {
            addCriterion("FILE_NM_TO <", value, "FILE_NM_TO");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TOLessThanOrEqualTo(String value) {
            addCriterion("FILE_NM_TO <=", value, "FILE_NM_TO");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TOLike(String value) {
            addCriterion("FILE_NM_TO like", value, "FILE_NM_TO");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TONotLike(String value) {
            addCriterion("FILE_NM_TO not like", value, "FILE_NM_TO");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TOIn(List<String> values) {
            addCriterion("FILE_NM_TO in", values, "FILE_NM_TO");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TONotIn(List<String> values) {
            addCriterion("FILE_NM_TO not in", values, "FILE_NM_TO");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TOBetween(String value1, String value2) {
            addCriterion("FILE_NM_TO between", value1, value2, "FILE_NM_TO");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TONotBetween(String value1, String value2) {
            addCriterion("FILE_NM_TO not between", value1, value2, "FILE_NM_TO");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TOIsNull() {
            addCriterion("GET_KIND_TO is null");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TOIsNotNull() {
            addCriterion("GET_KIND_TO is not null");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TOEqualTo(String value) {
            addCriterion("GET_KIND_TO =", value, "GET_KIND_TO");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TONotEqualTo(String value) {
            addCriterion("GET_KIND_TO <>", value, "GET_KIND_TO");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TOGreaterThan(String value) {
            addCriterion("GET_KIND_TO >", value, "GET_KIND_TO");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TOGreaterThanOrEqualTo(String value) {
            addCriterion("GET_KIND_TO >=", value, "GET_KIND_TO");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TOLessThan(String value) {
            addCriterion("GET_KIND_TO <", value, "GET_KIND_TO");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TOLessThanOrEqualTo(String value) {
            addCriterion("GET_KIND_TO <=", value, "GET_KIND_TO");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TOLike(String value) {
            addCriterion("GET_KIND_TO like", value, "GET_KIND_TO");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TONotLike(String value) {
            addCriterion("GET_KIND_TO not like", value, "GET_KIND_TO");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TOIn(List<String> values) {
            addCriterion("GET_KIND_TO in", values, "GET_KIND_TO");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TONotIn(List<String> values) {
            addCriterion("GET_KIND_TO not in", values, "GET_KIND_TO");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TOBetween(String value1, String value2) {
            addCriterion("GET_KIND_TO between", value1, value2, "GET_KIND_TO");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TONotBetween(String value1, String value2) {
            addCriterion("GET_KIND_TO not between", value1, value2, "GET_KIND_TO");
            return (Criteria) this;
        }

        public Criteria andITEM1IsNull() {
            addCriterion("ITEM1 is null");
            return (Criteria) this;
        }

        public Criteria andITEM1IsNotNull() {
            addCriterion("ITEM1 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM1EqualTo(String value) {
            addCriterion("ITEM1 =", value, "ITEM1");
            return (Criteria) this;
        }

        public Criteria andITEM1NotEqualTo(String value) {
            addCriterion("ITEM1 <>", value, "ITEM1");
            return (Criteria) this;
        }

        public Criteria andITEM1GreaterThan(String value) {
            addCriterion("ITEM1 >", value, "ITEM1");
            return (Criteria) this;
        }

        public Criteria andITEM1GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM1 >=", value, "ITEM1");
            return (Criteria) this;
        }

        public Criteria andITEM1LessThan(String value) {
            addCriterion("ITEM1 <", value, "ITEM1");
            return (Criteria) this;
        }

        public Criteria andITEM1LessThanOrEqualTo(String value) {
            addCriterion("ITEM1 <=", value, "ITEM1");
            return (Criteria) this;
        }

        public Criteria andITEM1Like(String value) {
            addCriterion("ITEM1 like", value, "ITEM1");
            return (Criteria) this;
        }

        public Criteria andITEM1NotLike(String value) {
            addCriterion("ITEM1 not like", value, "ITEM1");
            return (Criteria) this;
        }

        public Criteria andITEM1In(List<String> values) {
            addCriterion("ITEM1 in", values, "ITEM1");
            return (Criteria) this;
        }

        public Criteria andITEM1NotIn(List<String> values) {
            addCriterion("ITEM1 not in", values, "ITEM1");
            return (Criteria) this;
        }

        public Criteria andITEM1Between(String value1, String value2) {
            addCriterion("ITEM1 between", value1, value2, "ITEM1");
            return (Criteria) this;
        }

        public Criteria andITEM1NotBetween(String value1, String value2) {
            addCriterion("ITEM1 not between", value1, value2, "ITEM1");
            return (Criteria) this;
        }

        public Criteria andITEM2IsNull() {
            addCriterion("ITEM2 is null");
            return (Criteria) this;
        }

        public Criteria andITEM2IsNotNull() {
            addCriterion("ITEM2 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM2EqualTo(String value) {
            addCriterion("ITEM2 =", value, "ITEM2");
            return (Criteria) this;
        }

        public Criteria andITEM2NotEqualTo(String value) {
            addCriterion("ITEM2 <>", value, "ITEM2");
            return (Criteria) this;
        }

        public Criteria andITEM2GreaterThan(String value) {
            addCriterion("ITEM2 >", value, "ITEM2");
            return (Criteria) this;
        }

        public Criteria andITEM2GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM2 >=", value, "ITEM2");
            return (Criteria) this;
        }

        public Criteria andITEM2LessThan(String value) {
            addCriterion("ITEM2 <", value, "ITEM2");
            return (Criteria) this;
        }

        public Criteria andITEM2LessThanOrEqualTo(String value) {
            addCriterion("ITEM2 <=", value, "ITEM2");
            return (Criteria) this;
        }

        public Criteria andITEM2Like(String value) {
            addCriterion("ITEM2 like", value, "ITEM2");
            return (Criteria) this;
        }

        public Criteria andITEM2NotLike(String value) {
            addCriterion("ITEM2 not like", value, "ITEM2");
            return (Criteria) this;
        }

        public Criteria andITEM2In(List<String> values) {
            addCriterion("ITEM2 in", values, "ITEM2");
            return (Criteria) this;
        }

        public Criteria andITEM2NotIn(List<String> values) {
            addCriterion("ITEM2 not in", values, "ITEM2");
            return (Criteria) this;
        }

        public Criteria andITEM2Between(String value1, String value2) {
            addCriterion("ITEM2 between", value1, value2, "ITEM2");
            return (Criteria) this;
        }

        public Criteria andITEM2NotBetween(String value1, String value2) {
            addCriterion("ITEM2 not between", value1, value2, "ITEM2");
            return (Criteria) this;
        }

        public Criteria andITEM3IsNull() {
            addCriterion("ITEM3 is null");
            return (Criteria) this;
        }

        public Criteria andITEM3IsNotNull() {
            addCriterion("ITEM3 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM3EqualTo(String value) {
            addCriterion("ITEM3 =", value, "ITEM3");
            return (Criteria) this;
        }

        public Criteria andITEM3NotEqualTo(String value) {
            addCriterion("ITEM3 <>", value, "ITEM3");
            return (Criteria) this;
        }

        public Criteria andITEM3GreaterThan(String value) {
            addCriterion("ITEM3 >", value, "ITEM3");
            return (Criteria) this;
        }

        public Criteria andITEM3GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM3 >=", value, "ITEM3");
            return (Criteria) this;
        }

        public Criteria andITEM3LessThan(String value) {
            addCriterion("ITEM3 <", value, "ITEM3");
            return (Criteria) this;
        }

        public Criteria andITEM3LessThanOrEqualTo(String value) {
            addCriterion("ITEM3 <=", value, "ITEM3");
            return (Criteria) this;
        }

        public Criteria andITEM3Like(String value) {
            addCriterion("ITEM3 like", value, "ITEM3");
            return (Criteria) this;
        }

        public Criteria andITEM3NotLike(String value) {
            addCriterion("ITEM3 not like", value, "ITEM3");
            return (Criteria) this;
        }

        public Criteria andITEM3In(List<String> values) {
            addCriterion("ITEM3 in", values, "ITEM3");
            return (Criteria) this;
        }

        public Criteria andITEM3NotIn(List<String> values) {
            addCriterion("ITEM3 not in", values, "ITEM3");
            return (Criteria) this;
        }

        public Criteria andITEM3Between(String value1, String value2) {
            addCriterion("ITEM3 between", value1, value2, "ITEM3");
            return (Criteria) this;
        }

        public Criteria andITEM3NotBetween(String value1, String value2) {
            addCriterion("ITEM3 not between", value1, value2, "ITEM3");
            return (Criteria) this;
        }

        public Criteria andITEM4IsNull() {
            addCriterion("ITEM4 is null");
            return (Criteria) this;
        }

        public Criteria andITEM4IsNotNull() {
            addCriterion("ITEM4 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM4EqualTo(String value) {
            addCriterion("ITEM4 =", value, "ITEM4");
            return (Criteria) this;
        }

        public Criteria andITEM4NotEqualTo(String value) {
            addCriterion("ITEM4 <>", value, "ITEM4");
            return (Criteria) this;
        }

        public Criteria andITEM4GreaterThan(String value) {
            addCriterion("ITEM4 >", value, "ITEM4");
            return (Criteria) this;
        }

        public Criteria andITEM4GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM4 >=", value, "ITEM4");
            return (Criteria) this;
        }

        public Criteria andITEM4LessThan(String value) {
            addCriterion("ITEM4 <", value, "ITEM4");
            return (Criteria) this;
        }

        public Criteria andITEM4LessThanOrEqualTo(String value) {
            addCriterion("ITEM4 <=", value, "ITEM4");
            return (Criteria) this;
        }

        public Criteria andITEM4Like(String value) {
            addCriterion("ITEM4 like", value, "ITEM4");
            return (Criteria) this;
        }

        public Criteria andITEM4NotLike(String value) {
            addCriterion("ITEM4 not like", value, "ITEM4");
            return (Criteria) this;
        }

        public Criteria andITEM4In(List<String> values) {
            addCriterion("ITEM4 in", values, "ITEM4");
            return (Criteria) this;
        }

        public Criteria andITEM4NotIn(List<String> values) {
            addCriterion("ITEM4 not in", values, "ITEM4");
            return (Criteria) this;
        }

        public Criteria andITEM4Between(String value1, String value2) {
            addCriterion("ITEM4 between", value1, value2, "ITEM4");
            return (Criteria) this;
        }

        public Criteria andITEM4NotBetween(String value1, String value2) {
            addCriterion("ITEM4 not between", value1, value2, "ITEM4");
            return (Criteria) this;
        }

        public Criteria andITEM5IsNull() {
            addCriterion("ITEM5 is null");
            return (Criteria) this;
        }

        public Criteria andITEM5IsNotNull() {
            addCriterion("ITEM5 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM5EqualTo(String value) {
            addCriterion("ITEM5 =", value, "ITEM5");
            return (Criteria) this;
        }

        public Criteria andITEM5NotEqualTo(String value) {
            addCriterion("ITEM5 <>", value, "ITEM5");
            return (Criteria) this;
        }

        public Criteria andITEM5GreaterThan(String value) {
            addCriterion("ITEM5 >", value, "ITEM5");
            return (Criteria) this;
        }

        public Criteria andITEM5GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM5 >=", value, "ITEM5");
            return (Criteria) this;
        }

        public Criteria andITEM5LessThan(String value) {
            addCriterion("ITEM5 <", value, "ITEM5");
            return (Criteria) this;
        }

        public Criteria andITEM5LessThanOrEqualTo(String value) {
            addCriterion("ITEM5 <=", value, "ITEM5");
            return (Criteria) this;
        }

        public Criteria andITEM5Like(String value) {
            addCriterion("ITEM5 like", value, "ITEM5");
            return (Criteria) this;
        }

        public Criteria andITEM5NotLike(String value) {
            addCriterion("ITEM5 not like", value, "ITEM5");
            return (Criteria) this;
        }

        public Criteria andITEM5In(List<String> values) {
            addCriterion("ITEM5 in", values, "ITEM5");
            return (Criteria) this;
        }

        public Criteria andITEM5NotIn(List<String> values) {
            addCriterion("ITEM5 not in", values, "ITEM5");
            return (Criteria) this;
        }

        public Criteria andITEM5Between(String value1, String value2) {
            addCriterion("ITEM5 between", value1, value2, "ITEM5");
            return (Criteria) this;
        }

        public Criteria andITEM5NotBetween(String value1, String value2) {
            addCriterion("ITEM5 not between", value1, value2, "ITEM5");
            return (Criteria) this;
        }

        public Criteria andITEM6IsNull() {
            addCriterion("ITEM6 is null");
            return (Criteria) this;
        }

        public Criteria andITEM6IsNotNull() {
            addCriterion("ITEM6 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM6EqualTo(String value) {
            addCriterion("ITEM6 =", value, "ITEM6");
            return (Criteria) this;
        }

        public Criteria andITEM6NotEqualTo(String value) {
            addCriterion("ITEM6 <>", value, "ITEM6");
            return (Criteria) this;
        }

        public Criteria andITEM6GreaterThan(String value) {
            addCriterion("ITEM6 >", value, "ITEM6");
            return (Criteria) this;
        }

        public Criteria andITEM6GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM6 >=", value, "ITEM6");
            return (Criteria) this;
        }

        public Criteria andITEM6LessThan(String value) {
            addCriterion("ITEM6 <", value, "ITEM6");
            return (Criteria) this;
        }

        public Criteria andITEM6LessThanOrEqualTo(String value) {
            addCriterion("ITEM6 <=", value, "ITEM6");
            return (Criteria) this;
        }

        public Criteria andITEM6Like(String value) {
            addCriterion("ITEM6 like", value, "ITEM6");
            return (Criteria) this;
        }

        public Criteria andITEM6NotLike(String value) {
            addCriterion("ITEM6 not like", value, "ITEM6");
            return (Criteria) this;
        }

        public Criteria andITEM6In(List<String> values) {
            addCriterion("ITEM6 in", values, "ITEM6");
            return (Criteria) this;
        }

        public Criteria andITEM6NotIn(List<String> values) {
            addCriterion("ITEM6 not in", values, "ITEM6");
            return (Criteria) this;
        }

        public Criteria andITEM6Between(String value1, String value2) {
            addCriterion("ITEM6 between", value1, value2, "ITEM6");
            return (Criteria) this;
        }

        public Criteria andITEM6NotBetween(String value1, String value2) {
            addCriterion("ITEM6 not between", value1, value2, "ITEM6");
            return (Criteria) this;
        }

        public Criteria andITEM7IsNull() {
            addCriterion("ITEM7 is null");
            return (Criteria) this;
        }

        public Criteria andITEM7IsNotNull() {
            addCriterion("ITEM7 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM7EqualTo(String value) {
            addCriterion("ITEM7 =", value, "ITEM7");
            return (Criteria) this;
        }

        public Criteria andITEM7NotEqualTo(String value) {
            addCriterion("ITEM7 <>", value, "ITEM7");
            return (Criteria) this;
        }

        public Criteria andITEM7GreaterThan(String value) {
            addCriterion("ITEM7 >", value, "ITEM7");
            return (Criteria) this;
        }

        public Criteria andITEM7GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM7 >=", value, "ITEM7");
            return (Criteria) this;
        }

        public Criteria andITEM7LessThan(String value) {
            addCriterion("ITEM7 <", value, "ITEM7");
            return (Criteria) this;
        }

        public Criteria andITEM7LessThanOrEqualTo(String value) {
            addCriterion("ITEM7 <=", value, "ITEM7");
            return (Criteria) this;
        }

        public Criteria andITEM7Like(String value) {
            addCriterion("ITEM7 like", value, "ITEM7");
            return (Criteria) this;
        }

        public Criteria andITEM7NotLike(String value) {
            addCriterion("ITEM7 not like", value, "ITEM7");
            return (Criteria) this;
        }

        public Criteria andITEM7In(List<String> values) {
            addCriterion("ITEM7 in", values, "ITEM7");
            return (Criteria) this;
        }

        public Criteria andITEM7NotIn(List<String> values) {
            addCriterion("ITEM7 not in", values, "ITEM7");
            return (Criteria) this;
        }

        public Criteria andITEM7Between(String value1, String value2) {
            addCriterion("ITEM7 between", value1, value2, "ITEM7");
            return (Criteria) this;
        }

        public Criteria andITEM7NotBetween(String value1, String value2) {
            addCriterion("ITEM7 not between", value1, value2, "ITEM7");
            return (Criteria) this;
        }

        public Criteria andITEM8IsNull() {
            addCriterion("ITEM8 is null");
            return (Criteria) this;
        }

        public Criteria andITEM8IsNotNull() {
            addCriterion("ITEM8 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM8EqualTo(String value) {
            addCriterion("ITEM8 =", value, "ITEM8");
            return (Criteria) this;
        }

        public Criteria andITEM8NotEqualTo(String value) {
            addCriterion("ITEM8 <>", value, "ITEM8");
            return (Criteria) this;
        }

        public Criteria andITEM8GreaterThan(String value) {
            addCriterion("ITEM8 >", value, "ITEM8");
            return (Criteria) this;
        }

        public Criteria andITEM8GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM8 >=", value, "ITEM8");
            return (Criteria) this;
        }

        public Criteria andITEM8LessThan(String value) {
            addCriterion("ITEM8 <", value, "ITEM8");
            return (Criteria) this;
        }

        public Criteria andITEM8LessThanOrEqualTo(String value) {
            addCriterion("ITEM8 <=", value, "ITEM8");
            return (Criteria) this;
        }

        public Criteria andITEM8Like(String value) {
            addCriterion("ITEM8 like", value, "ITEM8");
            return (Criteria) this;
        }

        public Criteria andITEM8NotLike(String value) {
            addCriterion("ITEM8 not like", value, "ITEM8");
            return (Criteria) this;
        }

        public Criteria andITEM8In(List<String> values) {
            addCriterion("ITEM8 in", values, "ITEM8");
            return (Criteria) this;
        }

        public Criteria andITEM8NotIn(List<String> values) {
            addCriterion("ITEM8 not in", values, "ITEM8");
            return (Criteria) this;
        }

        public Criteria andITEM8Between(String value1, String value2) {
            addCriterion("ITEM8 between", value1, value2, "ITEM8");
            return (Criteria) this;
        }

        public Criteria andITEM8NotBetween(String value1, String value2) {
            addCriterion("ITEM8 not between", value1, value2, "ITEM8");
            return (Criteria) this;
        }

        public Criteria andITEM9IsNull() {
            addCriterion("ITEM9 is null");
            return (Criteria) this;
        }

        public Criteria andITEM9IsNotNull() {
            addCriterion("ITEM9 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM9EqualTo(String value) {
            addCriterion("ITEM9 =", value, "ITEM9");
            return (Criteria) this;
        }

        public Criteria andITEM9NotEqualTo(String value) {
            addCriterion("ITEM9 <>", value, "ITEM9");
            return (Criteria) this;
        }

        public Criteria andITEM9GreaterThan(String value) {
            addCriterion("ITEM9 >", value, "ITEM9");
            return (Criteria) this;
        }

        public Criteria andITEM9GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM9 >=", value, "ITEM9");
            return (Criteria) this;
        }

        public Criteria andITEM9LessThan(String value) {
            addCriterion("ITEM9 <", value, "ITEM9");
            return (Criteria) this;
        }

        public Criteria andITEM9LessThanOrEqualTo(String value) {
            addCriterion("ITEM9 <=", value, "ITEM9");
            return (Criteria) this;
        }

        public Criteria andITEM9Like(String value) {
            addCriterion("ITEM9 like", value, "ITEM9");
            return (Criteria) this;
        }

        public Criteria andITEM9NotLike(String value) {
            addCriterion("ITEM9 not like", value, "ITEM9");
            return (Criteria) this;
        }

        public Criteria andITEM9In(List<String> values) {
            addCriterion("ITEM9 in", values, "ITEM9");
            return (Criteria) this;
        }

        public Criteria andITEM9NotIn(List<String> values) {
            addCriterion("ITEM9 not in", values, "ITEM9");
            return (Criteria) this;
        }

        public Criteria andITEM9Between(String value1, String value2) {
            addCriterion("ITEM9 between", value1, value2, "ITEM9");
            return (Criteria) this;
        }

        public Criteria andITEM9NotBetween(String value1, String value2) {
            addCriterion("ITEM9 not between", value1, value2, "ITEM9");
            return (Criteria) this;
        }

        public Criteria andITEM10IsNull() {
            addCriterion("ITEM10 is null");
            return (Criteria) this;
        }

        public Criteria andITEM10IsNotNull() {
            addCriterion("ITEM10 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM10EqualTo(String value) {
            addCriterion("ITEM10 =", value, "ITEM10");
            return (Criteria) this;
        }

        public Criteria andITEM10NotEqualTo(String value) {
            addCriterion("ITEM10 <>", value, "ITEM10");
            return (Criteria) this;
        }

        public Criteria andITEM10GreaterThan(String value) {
            addCriterion("ITEM10 >", value, "ITEM10");
            return (Criteria) this;
        }

        public Criteria andITEM10GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM10 >=", value, "ITEM10");
            return (Criteria) this;
        }

        public Criteria andITEM10LessThan(String value) {
            addCriterion("ITEM10 <", value, "ITEM10");
            return (Criteria) this;
        }

        public Criteria andITEM10LessThanOrEqualTo(String value) {
            addCriterion("ITEM10 <=", value, "ITEM10");
            return (Criteria) this;
        }

        public Criteria andITEM10Like(String value) {
            addCriterion("ITEM10 like", value, "ITEM10");
            return (Criteria) this;
        }

        public Criteria andITEM10NotLike(String value) {
            addCriterion("ITEM10 not like", value, "ITEM10");
            return (Criteria) this;
        }

        public Criteria andITEM10In(List<String> values) {
            addCriterion("ITEM10 in", values, "ITEM10");
            return (Criteria) this;
        }

        public Criteria andITEM10NotIn(List<String> values) {
            addCriterion("ITEM10 not in", values, "ITEM10");
            return (Criteria) this;
        }

        public Criteria andITEM10Between(String value1, String value2) {
            addCriterion("ITEM10 between", value1, value2, "ITEM10");
            return (Criteria) this;
        }

        public Criteria andITEM10NotBetween(String value1, String value2) {
            addCriterion("ITEM10 not between", value1, value2, "ITEM10");
            return (Criteria) this;
        }

        public Criteria andITEM11IsNull() {
            addCriterion("ITEM11 is null");
            return (Criteria) this;
        }

        public Criteria andITEM11IsNotNull() {
            addCriterion("ITEM11 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM11EqualTo(String value) {
            addCriterion("ITEM11 =", value, "ITEM11");
            return (Criteria) this;
        }

        public Criteria andITEM11NotEqualTo(String value) {
            addCriterion("ITEM11 <>", value, "ITEM11");
            return (Criteria) this;
        }

        public Criteria andITEM11GreaterThan(String value) {
            addCriterion("ITEM11 >", value, "ITEM11");
            return (Criteria) this;
        }

        public Criteria andITEM11GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM11 >=", value, "ITEM11");
            return (Criteria) this;
        }

        public Criteria andITEM11LessThan(String value) {
            addCriterion("ITEM11 <", value, "ITEM11");
            return (Criteria) this;
        }

        public Criteria andITEM11LessThanOrEqualTo(String value) {
            addCriterion("ITEM11 <=", value, "ITEM11");
            return (Criteria) this;
        }

        public Criteria andITEM11Like(String value) {
            addCriterion("ITEM11 like", value, "ITEM11");
            return (Criteria) this;
        }

        public Criteria andITEM11NotLike(String value) {
            addCriterion("ITEM11 not like", value, "ITEM11");
            return (Criteria) this;
        }

        public Criteria andITEM11In(List<String> values) {
            addCriterion("ITEM11 in", values, "ITEM11");
            return (Criteria) this;
        }

        public Criteria andITEM11NotIn(List<String> values) {
            addCriterion("ITEM11 not in", values, "ITEM11");
            return (Criteria) this;
        }

        public Criteria andITEM11Between(String value1, String value2) {
            addCriterion("ITEM11 between", value1, value2, "ITEM11");
            return (Criteria) this;
        }

        public Criteria andITEM11NotBetween(String value1, String value2) {
            addCriterion("ITEM11 not between", value1, value2, "ITEM11");
            return (Criteria) this;
        }

        public Criteria andITEM12IsNull() {
            addCriterion("ITEM12 is null");
            return (Criteria) this;
        }

        public Criteria andITEM12IsNotNull() {
            addCriterion("ITEM12 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM12EqualTo(String value) {
            addCriterion("ITEM12 =", value, "ITEM12");
            return (Criteria) this;
        }

        public Criteria andITEM12NotEqualTo(String value) {
            addCriterion("ITEM12 <>", value, "ITEM12");
            return (Criteria) this;
        }

        public Criteria andITEM12GreaterThan(String value) {
            addCriterion("ITEM12 >", value, "ITEM12");
            return (Criteria) this;
        }

        public Criteria andITEM12GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM12 >=", value, "ITEM12");
            return (Criteria) this;
        }

        public Criteria andITEM12LessThan(String value) {
            addCriterion("ITEM12 <", value, "ITEM12");
            return (Criteria) this;
        }

        public Criteria andITEM12LessThanOrEqualTo(String value) {
            addCriterion("ITEM12 <=", value, "ITEM12");
            return (Criteria) this;
        }

        public Criteria andITEM12Like(String value) {
            addCriterion("ITEM12 like", value, "ITEM12");
            return (Criteria) this;
        }

        public Criteria andITEM12NotLike(String value) {
            addCriterion("ITEM12 not like", value, "ITEM12");
            return (Criteria) this;
        }

        public Criteria andITEM12In(List<String> values) {
            addCriterion("ITEM12 in", values, "ITEM12");
            return (Criteria) this;
        }

        public Criteria andITEM12NotIn(List<String> values) {
            addCriterion("ITEM12 not in", values, "ITEM12");
            return (Criteria) this;
        }

        public Criteria andITEM12Between(String value1, String value2) {
            addCriterion("ITEM12 between", value1, value2, "ITEM12");
            return (Criteria) this;
        }

        public Criteria andITEM12NotBetween(String value1, String value2) {
            addCriterion("ITEM12 not between", value1, value2, "ITEM12");
            return (Criteria) this;
        }

        public Criteria andITEM13IsNull() {
            addCriterion("ITEM13 is null");
            return (Criteria) this;
        }

        public Criteria andITEM13IsNotNull() {
            addCriterion("ITEM13 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM13EqualTo(String value) {
            addCriterion("ITEM13 =", value, "ITEM13");
            return (Criteria) this;
        }

        public Criteria andITEM13NotEqualTo(String value) {
            addCriterion("ITEM13 <>", value, "ITEM13");
            return (Criteria) this;
        }

        public Criteria andITEM13GreaterThan(String value) {
            addCriterion("ITEM13 >", value, "ITEM13");
            return (Criteria) this;
        }

        public Criteria andITEM13GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM13 >=", value, "ITEM13");
            return (Criteria) this;
        }

        public Criteria andITEM13LessThan(String value) {
            addCriterion("ITEM13 <", value, "ITEM13");
            return (Criteria) this;
        }

        public Criteria andITEM13LessThanOrEqualTo(String value) {
            addCriterion("ITEM13 <=", value, "ITEM13");
            return (Criteria) this;
        }

        public Criteria andITEM13Like(String value) {
            addCriterion("ITEM13 like", value, "ITEM13");
            return (Criteria) this;
        }

        public Criteria andITEM13NotLike(String value) {
            addCriterion("ITEM13 not like", value, "ITEM13");
            return (Criteria) this;
        }

        public Criteria andITEM13In(List<String> values) {
            addCriterion("ITEM13 in", values, "ITEM13");
            return (Criteria) this;
        }

        public Criteria andITEM13NotIn(List<String> values) {
            addCriterion("ITEM13 not in", values, "ITEM13");
            return (Criteria) this;
        }

        public Criteria andITEM13Between(String value1, String value2) {
            addCriterion("ITEM13 between", value1, value2, "ITEM13");
            return (Criteria) this;
        }

        public Criteria andITEM13NotBetween(String value1, String value2) {
            addCriterion("ITEM13 not between", value1, value2, "ITEM13");
            return (Criteria) this;
        }

        public Criteria andITEM14IsNull() {
            addCriterion("ITEM14 is null");
            return (Criteria) this;
        }

        public Criteria andITEM14IsNotNull() {
            addCriterion("ITEM14 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM14EqualTo(String value) {
            addCriterion("ITEM14 =", value, "ITEM14");
            return (Criteria) this;
        }

        public Criteria andITEM14NotEqualTo(String value) {
            addCriterion("ITEM14 <>", value, "ITEM14");
            return (Criteria) this;
        }

        public Criteria andITEM14GreaterThan(String value) {
            addCriterion("ITEM14 >", value, "ITEM14");
            return (Criteria) this;
        }

        public Criteria andITEM14GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM14 >=", value, "ITEM14");
            return (Criteria) this;
        }

        public Criteria andITEM14LessThan(String value) {
            addCriterion("ITEM14 <", value, "ITEM14");
            return (Criteria) this;
        }

        public Criteria andITEM14LessThanOrEqualTo(String value) {
            addCriterion("ITEM14 <=", value, "ITEM14");
            return (Criteria) this;
        }

        public Criteria andITEM14Like(String value) {
            addCriterion("ITEM14 like", value, "ITEM14");
            return (Criteria) this;
        }

        public Criteria andITEM14NotLike(String value) {
            addCriterion("ITEM14 not like", value, "ITEM14");
            return (Criteria) this;
        }

        public Criteria andITEM14In(List<String> values) {
            addCriterion("ITEM14 in", values, "ITEM14");
            return (Criteria) this;
        }

        public Criteria andITEM14NotIn(List<String> values) {
            addCriterion("ITEM14 not in", values, "ITEM14");
            return (Criteria) this;
        }

        public Criteria andITEM14Between(String value1, String value2) {
            addCriterion("ITEM14 between", value1, value2, "ITEM14");
            return (Criteria) this;
        }

        public Criteria andITEM14NotBetween(String value1, String value2) {
            addCriterion("ITEM14 not between", value1, value2, "ITEM14");
            return (Criteria) this;
        }

        public Criteria andITEM15IsNull() {
            addCriterion("ITEM15 is null");
            return (Criteria) this;
        }

        public Criteria andITEM15IsNotNull() {
            addCriterion("ITEM15 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM15EqualTo(String value) {
            addCriterion("ITEM15 =", value, "ITEM15");
            return (Criteria) this;
        }

        public Criteria andITEM15NotEqualTo(String value) {
            addCriterion("ITEM15 <>", value, "ITEM15");
            return (Criteria) this;
        }

        public Criteria andITEM15GreaterThan(String value) {
            addCriterion("ITEM15 >", value, "ITEM15");
            return (Criteria) this;
        }

        public Criteria andITEM15GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM15 >=", value, "ITEM15");
            return (Criteria) this;
        }

        public Criteria andITEM15LessThan(String value) {
            addCriterion("ITEM15 <", value, "ITEM15");
            return (Criteria) this;
        }

        public Criteria andITEM15LessThanOrEqualTo(String value) {
            addCriterion("ITEM15 <=", value, "ITEM15");
            return (Criteria) this;
        }

        public Criteria andITEM15Like(String value) {
            addCriterion("ITEM15 like", value, "ITEM15");
            return (Criteria) this;
        }

        public Criteria andITEM15NotLike(String value) {
            addCriterion("ITEM15 not like", value, "ITEM15");
            return (Criteria) this;
        }

        public Criteria andITEM15In(List<String> values) {
            addCriterion("ITEM15 in", values, "ITEM15");
            return (Criteria) this;
        }

        public Criteria andITEM15NotIn(List<String> values) {
            addCriterion("ITEM15 not in", values, "ITEM15");
            return (Criteria) this;
        }

        public Criteria andITEM15Between(String value1, String value2) {
            addCriterion("ITEM15 between", value1, value2, "ITEM15");
            return (Criteria) this;
        }

        public Criteria andITEM15NotBetween(String value1, String value2) {
            addCriterion("ITEM15 not between", value1, value2, "ITEM15");
            return (Criteria) this;
        }

        public Criteria andITEM16IsNull() {
            addCriterion("ITEM16 is null");
            return (Criteria) this;
        }

        public Criteria andITEM16IsNotNull() {
            addCriterion("ITEM16 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM16EqualTo(String value) {
            addCriterion("ITEM16 =", value, "ITEM16");
            return (Criteria) this;
        }

        public Criteria andITEM16NotEqualTo(String value) {
            addCriterion("ITEM16 <>", value, "ITEM16");
            return (Criteria) this;
        }

        public Criteria andITEM16GreaterThan(String value) {
            addCriterion("ITEM16 >", value, "ITEM16");
            return (Criteria) this;
        }

        public Criteria andITEM16GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM16 >=", value, "ITEM16");
            return (Criteria) this;
        }

        public Criteria andITEM16LessThan(String value) {
            addCriterion("ITEM16 <", value, "ITEM16");
            return (Criteria) this;
        }

        public Criteria andITEM16LessThanOrEqualTo(String value) {
            addCriterion("ITEM16 <=", value, "ITEM16");
            return (Criteria) this;
        }

        public Criteria andITEM16Like(String value) {
            addCriterion("ITEM16 like", value, "ITEM16");
            return (Criteria) this;
        }

        public Criteria andITEM16NotLike(String value) {
            addCriterion("ITEM16 not like", value, "ITEM16");
            return (Criteria) this;
        }

        public Criteria andITEM16In(List<String> values) {
            addCriterion("ITEM16 in", values, "ITEM16");
            return (Criteria) this;
        }

        public Criteria andITEM16NotIn(List<String> values) {
            addCriterion("ITEM16 not in", values, "ITEM16");
            return (Criteria) this;
        }

        public Criteria andITEM16Between(String value1, String value2) {
            addCriterion("ITEM16 between", value1, value2, "ITEM16");
            return (Criteria) this;
        }

        public Criteria andITEM16NotBetween(String value1, String value2) {
            addCriterion("ITEM16 not between", value1, value2, "ITEM16");
            return (Criteria) this;
        }

        public Criteria andITEM17IsNull() {
            addCriterion("ITEM17 is null");
            return (Criteria) this;
        }

        public Criteria andITEM17IsNotNull() {
            addCriterion("ITEM17 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM17EqualTo(String value) {
            addCriterion("ITEM17 =", value, "ITEM17");
            return (Criteria) this;
        }

        public Criteria andITEM17NotEqualTo(String value) {
            addCriterion("ITEM17 <>", value, "ITEM17");
            return (Criteria) this;
        }

        public Criteria andITEM17GreaterThan(String value) {
            addCriterion("ITEM17 >", value, "ITEM17");
            return (Criteria) this;
        }

        public Criteria andITEM17GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM17 >=", value, "ITEM17");
            return (Criteria) this;
        }

        public Criteria andITEM17LessThan(String value) {
            addCriterion("ITEM17 <", value, "ITEM17");
            return (Criteria) this;
        }

        public Criteria andITEM17LessThanOrEqualTo(String value) {
            addCriterion("ITEM17 <=", value, "ITEM17");
            return (Criteria) this;
        }

        public Criteria andITEM17Like(String value) {
            addCriterion("ITEM17 like", value, "ITEM17");
            return (Criteria) this;
        }

        public Criteria andITEM17NotLike(String value) {
            addCriterion("ITEM17 not like", value, "ITEM17");
            return (Criteria) this;
        }

        public Criteria andITEM17In(List<String> values) {
            addCriterion("ITEM17 in", values, "ITEM17");
            return (Criteria) this;
        }

        public Criteria andITEM17NotIn(List<String> values) {
            addCriterion("ITEM17 not in", values, "ITEM17");
            return (Criteria) this;
        }

        public Criteria andITEM17Between(String value1, String value2) {
            addCriterion("ITEM17 between", value1, value2, "ITEM17");
            return (Criteria) this;
        }

        public Criteria andITEM17NotBetween(String value1, String value2) {
            addCriterion("ITEM17 not between", value1, value2, "ITEM17");
            return (Criteria) this;
        }

        public Criteria andITEM18IsNull() {
            addCriterion("ITEM18 is null");
            return (Criteria) this;
        }

        public Criteria andITEM18IsNotNull() {
            addCriterion("ITEM18 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM18EqualTo(String value) {
            addCriterion("ITEM18 =", value, "ITEM18");
            return (Criteria) this;
        }

        public Criteria andITEM18NotEqualTo(String value) {
            addCriterion("ITEM18 <>", value, "ITEM18");
            return (Criteria) this;
        }

        public Criteria andITEM18GreaterThan(String value) {
            addCriterion("ITEM18 >", value, "ITEM18");
            return (Criteria) this;
        }

        public Criteria andITEM18GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM18 >=", value, "ITEM18");
            return (Criteria) this;
        }

        public Criteria andITEM18LessThan(String value) {
            addCriterion("ITEM18 <", value, "ITEM18");
            return (Criteria) this;
        }

        public Criteria andITEM18LessThanOrEqualTo(String value) {
            addCriterion("ITEM18 <=", value, "ITEM18");
            return (Criteria) this;
        }

        public Criteria andITEM18Like(String value) {
            addCriterion("ITEM18 like", value, "ITEM18");
            return (Criteria) this;
        }

        public Criteria andITEM18NotLike(String value) {
            addCriterion("ITEM18 not like", value, "ITEM18");
            return (Criteria) this;
        }

        public Criteria andITEM18In(List<String> values) {
            addCriterion("ITEM18 in", values, "ITEM18");
            return (Criteria) this;
        }

        public Criteria andITEM18NotIn(List<String> values) {
            addCriterion("ITEM18 not in", values, "ITEM18");
            return (Criteria) this;
        }

        public Criteria andITEM18Between(String value1, String value2) {
            addCriterion("ITEM18 between", value1, value2, "ITEM18");
            return (Criteria) this;
        }

        public Criteria andITEM18NotBetween(String value1, String value2) {
            addCriterion("ITEM18 not between", value1, value2, "ITEM18");
            return (Criteria) this;
        }

        public Criteria andITEM19IsNull() {
            addCriterion("ITEM19 is null");
            return (Criteria) this;
        }

        public Criteria andITEM19IsNotNull() {
            addCriterion("ITEM19 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM19EqualTo(String value) {
            addCriterion("ITEM19 =", value, "ITEM19");
            return (Criteria) this;
        }

        public Criteria andITEM19NotEqualTo(String value) {
            addCriterion("ITEM19 <>", value, "ITEM19");
            return (Criteria) this;
        }

        public Criteria andITEM19GreaterThan(String value) {
            addCriterion("ITEM19 >", value, "ITEM19");
            return (Criteria) this;
        }

        public Criteria andITEM19GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM19 >=", value, "ITEM19");
            return (Criteria) this;
        }

        public Criteria andITEM19LessThan(String value) {
            addCriterion("ITEM19 <", value, "ITEM19");
            return (Criteria) this;
        }

        public Criteria andITEM19LessThanOrEqualTo(String value) {
            addCriterion("ITEM19 <=", value, "ITEM19");
            return (Criteria) this;
        }

        public Criteria andITEM19Like(String value) {
            addCriterion("ITEM19 like", value, "ITEM19");
            return (Criteria) this;
        }

        public Criteria andITEM19NotLike(String value) {
            addCriterion("ITEM19 not like", value, "ITEM19");
            return (Criteria) this;
        }

        public Criteria andITEM19In(List<String> values) {
            addCriterion("ITEM19 in", values, "ITEM19");
            return (Criteria) this;
        }

        public Criteria andITEM19NotIn(List<String> values) {
            addCriterion("ITEM19 not in", values, "ITEM19");
            return (Criteria) this;
        }

        public Criteria andITEM19Between(String value1, String value2) {
            addCriterion("ITEM19 between", value1, value2, "ITEM19");
            return (Criteria) this;
        }

        public Criteria andITEM19NotBetween(String value1, String value2) {
            addCriterion("ITEM19 not between", value1, value2, "ITEM19");
            return (Criteria) this;
        }

        public Criteria andITEM20IsNull() {
            addCriterion("ITEM20 is null");
            return (Criteria) this;
        }

        public Criteria andITEM20IsNotNull() {
            addCriterion("ITEM20 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM20EqualTo(String value) {
            addCriterion("ITEM20 =", value, "ITEM20");
            return (Criteria) this;
        }

        public Criteria andITEM20NotEqualTo(String value) {
            addCriterion("ITEM20 <>", value, "ITEM20");
            return (Criteria) this;
        }

        public Criteria andITEM20GreaterThan(String value) {
            addCriterion("ITEM20 >", value, "ITEM20");
            return (Criteria) this;
        }

        public Criteria andITEM20GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM20 >=", value, "ITEM20");
            return (Criteria) this;
        }

        public Criteria andITEM20LessThan(String value) {
            addCriterion("ITEM20 <", value, "ITEM20");
            return (Criteria) this;
        }

        public Criteria andITEM20LessThanOrEqualTo(String value) {
            addCriterion("ITEM20 <=", value, "ITEM20");
            return (Criteria) this;
        }

        public Criteria andITEM20Like(String value) {
            addCriterion("ITEM20 like", value, "ITEM20");
            return (Criteria) this;
        }

        public Criteria andITEM20NotLike(String value) {
            addCriterion("ITEM20 not like", value, "ITEM20");
            return (Criteria) this;
        }

        public Criteria andITEM20In(List<String> values) {
            addCriterion("ITEM20 in", values, "ITEM20");
            return (Criteria) this;
        }

        public Criteria andITEM20NotIn(List<String> values) {
            addCriterion("ITEM20 not in", values, "ITEM20");
            return (Criteria) this;
        }

        public Criteria andITEM20Between(String value1, String value2) {
            addCriterion("ITEM20 between", value1, value2, "ITEM20");
            return (Criteria) this;
        }

        public Criteria andITEM20NotBetween(String value1, String value2) {
            addCriterion("ITEM20 not between", value1, value2, "ITEM20");
            return (Criteria) this;
        }

        public Criteria andITEM21IsNull() {
            addCriterion("ITEM21 is null");
            return (Criteria) this;
        }

        public Criteria andITEM21IsNotNull() {
            addCriterion("ITEM21 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM21EqualTo(String value) {
            addCriterion("ITEM21 =", value, "ITEM21");
            return (Criteria) this;
        }

        public Criteria andITEM21NotEqualTo(String value) {
            addCriterion("ITEM21 <>", value, "ITEM21");
            return (Criteria) this;
        }

        public Criteria andITEM21GreaterThan(String value) {
            addCriterion("ITEM21 >", value, "ITEM21");
            return (Criteria) this;
        }

        public Criteria andITEM21GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM21 >=", value, "ITEM21");
            return (Criteria) this;
        }

        public Criteria andITEM21LessThan(String value) {
            addCriterion("ITEM21 <", value, "ITEM21");
            return (Criteria) this;
        }

        public Criteria andITEM21LessThanOrEqualTo(String value) {
            addCriterion("ITEM21 <=", value, "ITEM21");
            return (Criteria) this;
        }

        public Criteria andITEM21Like(String value) {
            addCriterion("ITEM21 like", value, "ITEM21");
            return (Criteria) this;
        }

        public Criteria andITEM21NotLike(String value) {
            addCriterion("ITEM21 not like", value, "ITEM21");
            return (Criteria) this;
        }

        public Criteria andITEM21In(List<String> values) {
            addCriterion("ITEM21 in", values, "ITEM21");
            return (Criteria) this;
        }

        public Criteria andITEM21NotIn(List<String> values) {
            addCriterion("ITEM21 not in", values, "ITEM21");
            return (Criteria) this;
        }

        public Criteria andITEM21Between(String value1, String value2) {
            addCriterion("ITEM21 between", value1, value2, "ITEM21");
            return (Criteria) this;
        }

        public Criteria andITEM21NotBetween(String value1, String value2) {
            addCriterion("ITEM21 not between", value1, value2, "ITEM21");
            return (Criteria) this;
        }

        public Criteria andITEM22IsNull() {
            addCriterion("ITEM22 is null");
            return (Criteria) this;
        }

        public Criteria andITEM22IsNotNull() {
            addCriterion("ITEM22 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM22EqualTo(String value) {
            addCriterion("ITEM22 =", value, "ITEM22");
            return (Criteria) this;
        }

        public Criteria andITEM22NotEqualTo(String value) {
            addCriterion("ITEM22 <>", value, "ITEM22");
            return (Criteria) this;
        }

        public Criteria andITEM22GreaterThan(String value) {
            addCriterion("ITEM22 >", value, "ITEM22");
            return (Criteria) this;
        }

        public Criteria andITEM22GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM22 >=", value, "ITEM22");
            return (Criteria) this;
        }

        public Criteria andITEM22LessThan(String value) {
            addCriterion("ITEM22 <", value, "ITEM22");
            return (Criteria) this;
        }

        public Criteria andITEM22LessThanOrEqualTo(String value) {
            addCriterion("ITEM22 <=", value, "ITEM22");
            return (Criteria) this;
        }

        public Criteria andITEM22Like(String value) {
            addCriterion("ITEM22 like", value, "ITEM22");
            return (Criteria) this;
        }

        public Criteria andITEM22NotLike(String value) {
            addCriterion("ITEM22 not like", value, "ITEM22");
            return (Criteria) this;
        }

        public Criteria andITEM22In(List<String> values) {
            addCriterion("ITEM22 in", values, "ITEM22");
            return (Criteria) this;
        }

        public Criteria andITEM22NotIn(List<String> values) {
            addCriterion("ITEM22 not in", values, "ITEM22");
            return (Criteria) this;
        }

        public Criteria andITEM22Between(String value1, String value2) {
            addCriterion("ITEM22 between", value1, value2, "ITEM22");
            return (Criteria) this;
        }

        public Criteria andITEM22NotBetween(String value1, String value2) {
            addCriterion("ITEM22 not between", value1, value2, "ITEM22");
            return (Criteria) this;
        }

        public Criteria andITEM23IsNull() {
            addCriterion("ITEM23 is null");
            return (Criteria) this;
        }

        public Criteria andITEM23IsNotNull() {
            addCriterion("ITEM23 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM23EqualTo(String value) {
            addCriterion("ITEM23 =", value, "ITEM23");
            return (Criteria) this;
        }

        public Criteria andITEM23NotEqualTo(String value) {
            addCriterion("ITEM23 <>", value, "ITEM23");
            return (Criteria) this;
        }

        public Criteria andITEM23GreaterThan(String value) {
            addCriterion("ITEM23 >", value, "ITEM23");
            return (Criteria) this;
        }

        public Criteria andITEM23GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM23 >=", value, "ITEM23");
            return (Criteria) this;
        }

        public Criteria andITEM23LessThan(String value) {
            addCriterion("ITEM23 <", value, "ITEM23");
            return (Criteria) this;
        }

        public Criteria andITEM23LessThanOrEqualTo(String value) {
            addCriterion("ITEM23 <=", value, "ITEM23");
            return (Criteria) this;
        }

        public Criteria andITEM23Like(String value) {
            addCriterion("ITEM23 like", value, "ITEM23");
            return (Criteria) this;
        }

        public Criteria andITEM23NotLike(String value) {
            addCriterion("ITEM23 not like", value, "ITEM23");
            return (Criteria) this;
        }

        public Criteria andITEM23In(List<String> values) {
            addCriterion("ITEM23 in", values, "ITEM23");
            return (Criteria) this;
        }

        public Criteria andITEM23NotIn(List<String> values) {
            addCriterion("ITEM23 not in", values, "ITEM23");
            return (Criteria) this;
        }

        public Criteria andITEM23Between(String value1, String value2) {
            addCriterion("ITEM23 between", value1, value2, "ITEM23");
            return (Criteria) this;
        }

        public Criteria andITEM23NotBetween(String value1, String value2) {
            addCriterion("ITEM23 not between", value1, value2, "ITEM23");
            return (Criteria) this;
        }

        public Criteria andITEM24IsNull() {
            addCriterion("ITEM24 is null");
            return (Criteria) this;
        }

        public Criteria andITEM24IsNotNull() {
            addCriterion("ITEM24 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM24EqualTo(String value) {
            addCriterion("ITEM24 =", value, "ITEM24");
            return (Criteria) this;
        }

        public Criteria andITEM24NotEqualTo(String value) {
            addCriterion("ITEM24 <>", value, "ITEM24");
            return (Criteria) this;
        }

        public Criteria andITEM24GreaterThan(String value) {
            addCriterion("ITEM24 >", value, "ITEM24");
            return (Criteria) this;
        }

        public Criteria andITEM24GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM24 >=", value, "ITEM24");
            return (Criteria) this;
        }

        public Criteria andITEM24LessThan(String value) {
            addCriterion("ITEM24 <", value, "ITEM24");
            return (Criteria) this;
        }

        public Criteria andITEM24LessThanOrEqualTo(String value) {
            addCriterion("ITEM24 <=", value, "ITEM24");
            return (Criteria) this;
        }

        public Criteria andITEM24Like(String value) {
            addCriterion("ITEM24 like", value, "ITEM24");
            return (Criteria) this;
        }

        public Criteria andITEM24NotLike(String value) {
            addCriterion("ITEM24 not like", value, "ITEM24");
            return (Criteria) this;
        }

        public Criteria andITEM24In(List<String> values) {
            addCriterion("ITEM24 in", values, "ITEM24");
            return (Criteria) this;
        }

        public Criteria andITEM24NotIn(List<String> values) {
            addCriterion("ITEM24 not in", values, "ITEM24");
            return (Criteria) this;
        }

        public Criteria andITEM24Between(String value1, String value2) {
            addCriterion("ITEM24 between", value1, value2, "ITEM24");
            return (Criteria) this;
        }

        public Criteria andITEM24NotBetween(String value1, String value2) {
            addCriterion("ITEM24 not between", value1, value2, "ITEM24");
            return (Criteria) this;
        }

        public Criteria andITEM25IsNull() {
            addCriterion("ITEM25 is null");
            return (Criteria) this;
        }

        public Criteria andITEM25IsNotNull() {
            addCriterion("ITEM25 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM25EqualTo(String value) {
            addCriterion("ITEM25 =", value, "ITEM25");
            return (Criteria) this;
        }

        public Criteria andITEM25NotEqualTo(String value) {
            addCriterion("ITEM25 <>", value, "ITEM25");
            return (Criteria) this;
        }

        public Criteria andITEM25GreaterThan(String value) {
            addCriterion("ITEM25 >", value, "ITEM25");
            return (Criteria) this;
        }

        public Criteria andITEM25GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM25 >=", value, "ITEM25");
            return (Criteria) this;
        }

        public Criteria andITEM25LessThan(String value) {
            addCriterion("ITEM25 <", value, "ITEM25");
            return (Criteria) this;
        }

        public Criteria andITEM25LessThanOrEqualTo(String value) {
            addCriterion("ITEM25 <=", value, "ITEM25");
            return (Criteria) this;
        }

        public Criteria andITEM25Like(String value) {
            addCriterion("ITEM25 like", value, "ITEM25");
            return (Criteria) this;
        }

        public Criteria andITEM25NotLike(String value) {
            addCriterion("ITEM25 not like", value, "ITEM25");
            return (Criteria) this;
        }

        public Criteria andITEM25In(List<String> values) {
            addCriterion("ITEM25 in", values, "ITEM25");
            return (Criteria) this;
        }

        public Criteria andITEM25NotIn(List<String> values) {
            addCriterion("ITEM25 not in", values, "ITEM25");
            return (Criteria) this;
        }

        public Criteria andITEM25Between(String value1, String value2) {
            addCriterion("ITEM25 between", value1, value2, "ITEM25");
            return (Criteria) this;
        }

        public Criteria andITEM25NotBetween(String value1, String value2) {
            addCriterion("ITEM25 not between", value1, value2, "ITEM25");
            return (Criteria) this;
        }

        public Criteria andITEM26IsNull() {
            addCriterion("ITEM26 is null");
            return (Criteria) this;
        }

        public Criteria andITEM26IsNotNull() {
            addCriterion("ITEM26 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM26EqualTo(String value) {
            addCriterion("ITEM26 =", value, "ITEM26");
            return (Criteria) this;
        }

        public Criteria andITEM26NotEqualTo(String value) {
            addCriterion("ITEM26 <>", value, "ITEM26");
            return (Criteria) this;
        }

        public Criteria andITEM26GreaterThan(String value) {
            addCriterion("ITEM26 >", value, "ITEM26");
            return (Criteria) this;
        }

        public Criteria andITEM26GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM26 >=", value, "ITEM26");
            return (Criteria) this;
        }

        public Criteria andITEM26LessThan(String value) {
            addCriterion("ITEM26 <", value, "ITEM26");
            return (Criteria) this;
        }

        public Criteria andITEM26LessThanOrEqualTo(String value) {
            addCriterion("ITEM26 <=", value, "ITEM26");
            return (Criteria) this;
        }

        public Criteria andITEM26Like(String value) {
            addCriterion("ITEM26 like", value, "ITEM26");
            return (Criteria) this;
        }

        public Criteria andITEM26NotLike(String value) {
            addCriterion("ITEM26 not like", value, "ITEM26");
            return (Criteria) this;
        }

        public Criteria andITEM26In(List<String> values) {
            addCriterion("ITEM26 in", values, "ITEM26");
            return (Criteria) this;
        }

        public Criteria andITEM26NotIn(List<String> values) {
            addCriterion("ITEM26 not in", values, "ITEM26");
            return (Criteria) this;
        }

        public Criteria andITEM26Between(String value1, String value2) {
            addCriterion("ITEM26 between", value1, value2, "ITEM26");
            return (Criteria) this;
        }

        public Criteria andITEM26NotBetween(String value1, String value2) {
            addCriterion("ITEM26 not between", value1, value2, "ITEM26");
            return (Criteria) this;
        }

        public Criteria andITEM27IsNull() {
            addCriterion("ITEM27 is null");
            return (Criteria) this;
        }

        public Criteria andITEM27IsNotNull() {
            addCriterion("ITEM27 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM27EqualTo(String value) {
            addCriterion("ITEM27 =", value, "ITEM27");
            return (Criteria) this;
        }

        public Criteria andITEM27NotEqualTo(String value) {
            addCriterion("ITEM27 <>", value, "ITEM27");
            return (Criteria) this;
        }

        public Criteria andITEM27GreaterThan(String value) {
            addCriterion("ITEM27 >", value, "ITEM27");
            return (Criteria) this;
        }

        public Criteria andITEM27GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM27 >=", value, "ITEM27");
            return (Criteria) this;
        }

        public Criteria andITEM27LessThan(String value) {
            addCriterion("ITEM27 <", value, "ITEM27");
            return (Criteria) this;
        }

        public Criteria andITEM27LessThanOrEqualTo(String value) {
            addCriterion("ITEM27 <=", value, "ITEM27");
            return (Criteria) this;
        }

        public Criteria andITEM27Like(String value) {
            addCriterion("ITEM27 like", value, "ITEM27");
            return (Criteria) this;
        }

        public Criteria andITEM27NotLike(String value) {
            addCriterion("ITEM27 not like", value, "ITEM27");
            return (Criteria) this;
        }

        public Criteria andITEM27In(List<String> values) {
            addCriterion("ITEM27 in", values, "ITEM27");
            return (Criteria) this;
        }

        public Criteria andITEM27NotIn(List<String> values) {
            addCriterion("ITEM27 not in", values, "ITEM27");
            return (Criteria) this;
        }

        public Criteria andITEM27Between(String value1, String value2) {
            addCriterion("ITEM27 between", value1, value2, "ITEM27");
            return (Criteria) this;
        }

        public Criteria andITEM27NotBetween(String value1, String value2) {
            addCriterion("ITEM27 not between", value1, value2, "ITEM27");
            return (Criteria) this;
        }

        public Criteria andITEM28IsNull() {
            addCriterion("ITEM28 is null");
            return (Criteria) this;
        }

        public Criteria andITEM28IsNotNull() {
            addCriterion("ITEM28 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM28EqualTo(String value) {
            addCriterion("ITEM28 =", value, "ITEM28");
            return (Criteria) this;
        }

        public Criteria andITEM28NotEqualTo(String value) {
            addCriterion("ITEM28 <>", value, "ITEM28");
            return (Criteria) this;
        }

        public Criteria andITEM28GreaterThan(String value) {
            addCriterion("ITEM28 >", value, "ITEM28");
            return (Criteria) this;
        }

        public Criteria andITEM28GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM28 >=", value, "ITEM28");
            return (Criteria) this;
        }

        public Criteria andITEM28LessThan(String value) {
            addCriterion("ITEM28 <", value, "ITEM28");
            return (Criteria) this;
        }

        public Criteria andITEM28LessThanOrEqualTo(String value) {
            addCriterion("ITEM28 <=", value, "ITEM28");
            return (Criteria) this;
        }

        public Criteria andITEM28Like(String value) {
            addCriterion("ITEM28 like", value, "ITEM28");
            return (Criteria) this;
        }

        public Criteria andITEM28NotLike(String value) {
            addCriterion("ITEM28 not like", value, "ITEM28");
            return (Criteria) this;
        }

        public Criteria andITEM28In(List<String> values) {
            addCriterion("ITEM28 in", values, "ITEM28");
            return (Criteria) this;
        }

        public Criteria andITEM28NotIn(List<String> values) {
            addCriterion("ITEM28 not in", values, "ITEM28");
            return (Criteria) this;
        }

        public Criteria andITEM28Between(String value1, String value2) {
            addCriterion("ITEM28 between", value1, value2, "ITEM28");
            return (Criteria) this;
        }

        public Criteria andITEM28NotBetween(String value1, String value2) {
            addCriterion("ITEM28 not between", value1, value2, "ITEM28");
            return (Criteria) this;
        }

        public Criteria andITEM29IsNull() {
            addCriterion("ITEM29 is null");
            return (Criteria) this;
        }

        public Criteria andITEM29IsNotNull() {
            addCriterion("ITEM29 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM29EqualTo(String value) {
            addCriterion("ITEM29 =", value, "ITEM29");
            return (Criteria) this;
        }

        public Criteria andITEM29NotEqualTo(String value) {
            addCriterion("ITEM29 <>", value, "ITEM29");
            return (Criteria) this;
        }

        public Criteria andITEM29GreaterThan(String value) {
            addCriterion("ITEM29 >", value, "ITEM29");
            return (Criteria) this;
        }

        public Criteria andITEM29GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM29 >=", value, "ITEM29");
            return (Criteria) this;
        }

        public Criteria andITEM29LessThan(String value) {
            addCriterion("ITEM29 <", value, "ITEM29");
            return (Criteria) this;
        }

        public Criteria andITEM29LessThanOrEqualTo(String value) {
            addCriterion("ITEM29 <=", value, "ITEM29");
            return (Criteria) this;
        }

        public Criteria andITEM29Like(String value) {
            addCriterion("ITEM29 like", value, "ITEM29");
            return (Criteria) this;
        }

        public Criteria andITEM29NotLike(String value) {
            addCriterion("ITEM29 not like", value, "ITEM29");
            return (Criteria) this;
        }

        public Criteria andITEM29In(List<String> values) {
            addCriterion("ITEM29 in", values, "ITEM29");
            return (Criteria) this;
        }

        public Criteria andITEM29NotIn(List<String> values) {
            addCriterion("ITEM29 not in", values, "ITEM29");
            return (Criteria) this;
        }

        public Criteria andITEM29Between(String value1, String value2) {
            addCriterion("ITEM29 between", value1, value2, "ITEM29");
            return (Criteria) this;
        }

        public Criteria andITEM29NotBetween(String value1, String value2) {
            addCriterion("ITEM29 not between", value1, value2, "ITEM29");
            return (Criteria) this;
        }

        public Criteria andITEM30IsNull() {
            addCriterion("ITEM30 is null");
            return (Criteria) this;
        }

        public Criteria andITEM30IsNotNull() {
            addCriterion("ITEM30 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM30EqualTo(String value) {
            addCriterion("ITEM30 =", value, "ITEM30");
            return (Criteria) this;
        }

        public Criteria andITEM30NotEqualTo(String value) {
            addCriterion("ITEM30 <>", value, "ITEM30");
            return (Criteria) this;
        }

        public Criteria andITEM30GreaterThan(String value) {
            addCriterion("ITEM30 >", value, "ITEM30");
            return (Criteria) this;
        }

        public Criteria andITEM30GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM30 >=", value, "ITEM30");
            return (Criteria) this;
        }

        public Criteria andITEM30LessThan(String value) {
            addCriterion("ITEM30 <", value, "ITEM30");
            return (Criteria) this;
        }

        public Criteria andITEM30LessThanOrEqualTo(String value) {
            addCriterion("ITEM30 <=", value, "ITEM30");
            return (Criteria) this;
        }

        public Criteria andITEM30Like(String value) {
            addCriterion("ITEM30 like", value, "ITEM30");
            return (Criteria) this;
        }

        public Criteria andITEM30NotLike(String value) {
            addCriterion("ITEM30 not like", value, "ITEM30");
            return (Criteria) this;
        }

        public Criteria andITEM30In(List<String> values) {
            addCriterion("ITEM30 in", values, "ITEM30");
            return (Criteria) this;
        }

        public Criteria andITEM30NotIn(List<String> values) {
            addCriterion("ITEM30 not in", values, "ITEM30");
            return (Criteria) this;
        }

        public Criteria andITEM30Between(String value1, String value2) {
            addCriterion("ITEM30 between", value1, value2, "ITEM30");
            return (Criteria) this;
        }

        public Criteria andITEM30NotBetween(String value1, String value2) {
            addCriterion("ITEM30 not between", value1, value2, "ITEM30");
            return (Criteria) this;
        }

        public Criteria andITEM31IsNull() {
            addCriterion("ITEM31 is null");
            return (Criteria) this;
        }

        public Criteria andITEM31IsNotNull() {
            addCriterion("ITEM31 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM31EqualTo(String value) {
            addCriterion("ITEM31 =", value, "ITEM31");
            return (Criteria) this;
        }

        public Criteria andITEM31NotEqualTo(String value) {
            addCriterion("ITEM31 <>", value, "ITEM31");
            return (Criteria) this;
        }

        public Criteria andITEM31GreaterThan(String value) {
            addCriterion("ITEM31 >", value, "ITEM31");
            return (Criteria) this;
        }

        public Criteria andITEM31GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM31 >=", value, "ITEM31");
            return (Criteria) this;
        }

        public Criteria andITEM31LessThan(String value) {
            addCriterion("ITEM31 <", value, "ITEM31");
            return (Criteria) this;
        }

        public Criteria andITEM31LessThanOrEqualTo(String value) {
            addCriterion("ITEM31 <=", value, "ITEM31");
            return (Criteria) this;
        }

        public Criteria andITEM31Like(String value) {
            addCriterion("ITEM31 like", value, "ITEM31");
            return (Criteria) this;
        }

        public Criteria andITEM31NotLike(String value) {
            addCriterion("ITEM31 not like", value, "ITEM31");
            return (Criteria) this;
        }

        public Criteria andITEM31In(List<String> values) {
            addCriterion("ITEM31 in", values, "ITEM31");
            return (Criteria) this;
        }

        public Criteria andITEM31NotIn(List<String> values) {
            addCriterion("ITEM31 not in", values, "ITEM31");
            return (Criteria) this;
        }

        public Criteria andITEM31Between(String value1, String value2) {
            addCriterion("ITEM31 between", value1, value2, "ITEM31");
            return (Criteria) this;
        }

        public Criteria andITEM31NotBetween(String value1, String value2) {
            addCriterion("ITEM31 not between", value1, value2, "ITEM31");
            return (Criteria) this;
        }

        public Criteria andITEM32IsNull() {
            addCriterion("ITEM32 is null");
            return (Criteria) this;
        }

        public Criteria andITEM32IsNotNull() {
            addCriterion("ITEM32 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM32EqualTo(String value) {
            addCriterion("ITEM32 =", value, "ITEM32");
            return (Criteria) this;
        }

        public Criteria andITEM32NotEqualTo(String value) {
            addCriterion("ITEM32 <>", value, "ITEM32");
            return (Criteria) this;
        }

        public Criteria andITEM32GreaterThan(String value) {
            addCriterion("ITEM32 >", value, "ITEM32");
            return (Criteria) this;
        }

        public Criteria andITEM32GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM32 >=", value, "ITEM32");
            return (Criteria) this;
        }

        public Criteria andITEM32LessThan(String value) {
            addCriterion("ITEM32 <", value, "ITEM32");
            return (Criteria) this;
        }

        public Criteria andITEM32LessThanOrEqualTo(String value) {
            addCriterion("ITEM32 <=", value, "ITEM32");
            return (Criteria) this;
        }

        public Criteria andITEM32Like(String value) {
            addCriterion("ITEM32 like", value, "ITEM32");
            return (Criteria) this;
        }

        public Criteria andITEM32NotLike(String value) {
            addCriterion("ITEM32 not like", value, "ITEM32");
            return (Criteria) this;
        }

        public Criteria andITEM32In(List<String> values) {
            addCriterion("ITEM32 in", values, "ITEM32");
            return (Criteria) this;
        }

        public Criteria andITEM32NotIn(List<String> values) {
            addCriterion("ITEM32 not in", values, "ITEM32");
            return (Criteria) this;
        }

        public Criteria andITEM32Between(String value1, String value2) {
            addCriterion("ITEM32 between", value1, value2, "ITEM32");
            return (Criteria) this;
        }

        public Criteria andITEM32NotBetween(String value1, String value2) {
            addCriterion("ITEM32 not between", value1, value2, "ITEM32");
            return (Criteria) this;
        }

        public Criteria andITEM33IsNull() {
            addCriterion("ITEM33 is null");
            return (Criteria) this;
        }

        public Criteria andITEM33IsNotNull() {
            addCriterion("ITEM33 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM33EqualTo(String value) {
            addCriterion("ITEM33 =", value, "ITEM33");
            return (Criteria) this;
        }

        public Criteria andITEM33NotEqualTo(String value) {
            addCriterion("ITEM33 <>", value, "ITEM33");
            return (Criteria) this;
        }

        public Criteria andITEM33GreaterThan(String value) {
            addCriterion("ITEM33 >", value, "ITEM33");
            return (Criteria) this;
        }

        public Criteria andITEM33GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM33 >=", value, "ITEM33");
            return (Criteria) this;
        }

        public Criteria andITEM33LessThan(String value) {
            addCriterion("ITEM33 <", value, "ITEM33");
            return (Criteria) this;
        }

        public Criteria andITEM33LessThanOrEqualTo(String value) {
            addCriterion("ITEM33 <=", value, "ITEM33");
            return (Criteria) this;
        }

        public Criteria andITEM33Like(String value) {
            addCriterion("ITEM33 like", value, "ITEM33");
            return (Criteria) this;
        }

        public Criteria andITEM33NotLike(String value) {
            addCriterion("ITEM33 not like", value, "ITEM33");
            return (Criteria) this;
        }

        public Criteria andITEM33In(List<String> values) {
            addCriterion("ITEM33 in", values, "ITEM33");
            return (Criteria) this;
        }

        public Criteria andITEM33NotIn(List<String> values) {
            addCriterion("ITEM33 not in", values, "ITEM33");
            return (Criteria) this;
        }

        public Criteria andITEM33Between(String value1, String value2) {
            addCriterion("ITEM33 between", value1, value2, "ITEM33");
            return (Criteria) this;
        }

        public Criteria andITEM33NotBetween(String value1, String value2) {
            addCriterion("ITEM33 not between", value1, value2, "ITEM33");
            return (Criteria) this;
        }

        public Criteria andITEM34IsNull() {
            addCriterion("ITEM34 is null");
            return (Criteria) this;
        }

        public Criteria andITEM34IsNotNull() {
            addCriterion("ITEM34 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM34EqualTo(String value) {
            addCriterion("ITEM34 =", value, "ITEM34");
            return (Criteria) this;
        }

        public Criteria andITEM34NotEqualTo(String value) {
            addCriterion("ITEM34 <>", value, "ITEM34");
            return (Criteria) this;
        }

        public Criteria andITEM34GreaterThan(String value) {
            addCriterion("ITEM34 >", value, "ITEM34");
            return (Criteria) this;
        }

        public Criteria andITEM34GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM34 >=", value, "ITEM34");
            return (Criteria) this;
        }

        public Criteria andITEM34LessThan(String value) {
            addCriterion("ITEM34 <", value, "ITEM34");
            return (Criteria) this;
        }

        public Criteria andITEM34LessThanOrEqualTo(String value) {
            addCriterion("ITEM34 <=", value, "ITEM34");
            return (Criteria) this;
        }

        public Criteria andITEM34Like(String value) {
            addCriterion("ITEM34 like", value, "ITEM34");
            return (Criteria) this;
        }

        public Criteria andITEM34NotLike(String value) {
            addCriterion("ITEM34 not like", value, "ITEM34");
            return (Criteria) this;
        }

        public Criteria andITEM34In(List<String> values) {
            addCriterion("ITEM34 in", values, "ITEM34");
            return (Criteria) this;
        }

        public Criteria andITEM34NotIn(List<String> values) {
            addCriterion("ITEM34 not in", values, "ITEM34");
            return (Criteria) this;
        }

        public Criteria andITEM34Between(String value1, String value2) {
            addCriterion("ITEM34 between", value1, value2, "ITEM34");
            return (Criteria) this;
        }

        public Criteria andITEM34NotBetween(String value1, String value2) {
            addCriterion("ITEM34 not between", value1, value2, "ITEM34");
            return (Criteria) this;
        }

        public Criteria andITEM35IsNull() {
            addCriterion("ITEM35 is null");
            return (Criteria) this;
        }

        public Criteria andITEM35IsNotNull() {
            addCriterion("ITEM35 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM35EqualTo(String value) {
            addCriterion("ITEM35 =", value, "ITEM35");
            return (Criteria) this;
        }

        public Criteria andITEM35NotEqualTo(String value) {
            addCriterion("ITEM35 <>", value, "ITEM35");
            return (Criteria) this;
        }

        public Criteria andITEM35GreaterThan(String value) {
            addCriterion("ITEM35 >", value, "ITEM35");
            return (Criteria) this;
        }

        public Criteria andITEM35GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM35 >=", value, "ITEM35");
            return (Criteria) this;
        }

        public Criteria andITEM35LessThan(String value) {
            addCriterion("ITEM35 <", value, "ITEM35");
            return (Criteria) this;
        }

        public Criteria andITEM35LessThanOrEqualTo(String value) {
            addCriterion("ITEM35 <=", value, "ITEM35");
            return (Criteria) this;
        }

        public Criteria andITEM35Like(String value) {
            addCriterion("ITEM35 like", value, "ITEM35");
            return (Criteria) this;
        }

        public Criteria andITEM35NotLike(String value) {
            addCriterion("ITEM35 not like", value, "ITEM35");
            return (Criteria) this;
        }

        public Criteria andITEM35In(List<String> values) {
            addCriterion("ITEM35 in", values, "ITEM35");
            return (Criteria) this;
        }

        public Criteria andITEM35NotIn(List<String> values) {
            addCriterion("ITEM35 not in", values, "ITEM35");
            return (Criteria) this;
        }

        public Criteria andITEM35Between(String value1, String value2) {
            addCriterion("ITEM35 between", value1, value2, "ITEM35");
            return (Criteria) this;
        }

        public Criteria andITEM35NotBetween(String value1, String value2) {
            addCriterion("ITEM35 not between", value1, value2, "ITEM35");
            return (Criteria) this;
        }

        public Criteria andITEM36IsNull() {
            addCriterion("ITEM36 is null");
            return (Criteria) this;
        }

        public Criteria andITEM36IsNotNull() {
            addCriterion("ITEM36 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM36EqualTo(String value) {
            addCriterion("ITEM36 =", value, "ITEM36");
            return (Criteria) this;
        }

        public Criteria andITEM36NotEqualTo(String value) {
            addCriterion("ITEM36 <>", value, "ITEM36");
            return (Criteria) this;
        }

        public Criteria andITEM36GreaterThan(String value) {
            addCriterion("ITEM36 >", value, "ITEM36");
            return (Criteria) this;
        }

        public Criteria andITEM36GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM36 >=", value, "ITEM36");
            return (Criteria) this;
        }

        public Criteria andITEM36LessThan(String value) {
            addCriterion("ITEM36 <", value, "ITEM36");
            return (Criteria) this;
        }

        public Criteria andITEM36LessThanOrEqualTo(String value) {
            addCriterion("ITEM36 <=", value, "ITEM36");
            return (Criteria) this;
        }

        public Criteria andITEM36Like(String value) {
            addCriterion("ITEM36 like", value, "ITEM36");
            return (Criteria) this;
        }

        public Criteria andITEM36NotLike(String value) {
            addCriterion("ITEM36 not like", value, "ITEM36");
            return (Criteria) this;
        }

        public Criteria andITEM36In(List<String> values) {
            addCriterion("ITEM36 in", values, "ITEM36");
            return (Criteria) this;
        }

        public Criteria andITEM36NotIn(List<String> values) {
            addCriterion("ITEM36 not in", values, "ITEM36");
            return (Criteria) this;
        }

        public Criteria andITEM36Between(String value1, String value2) {
            addCriterion("ITEM36 between", value1, value2, "ITEM36");
            return (Criteria) this;
        }

        public Criteria andITEM36NotBetween(String value1, String value2) {
            addCriterion("ITEM36 not between", value1, value2, "ITEM36");
            return (Criteria) this;
        }

        public Criteria andITEM37IsNull() {
            addCriterion("ITEM37 is null");
            return (Criteria) this;
        }

        public Criteria andITEM37IsNotNull() {
            addCriterion("ITEM37 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM37EqualTo(String value) {
            addCriterion("ITEM37 =", value, "ITEM37");
            return (Criteria) this;
        }

        public Criteria andITEM37NotEqualTo(String value) {
            addCriterion("ITEM37 <>", value, "ITEM37");
            return (Criteria) this;
        }

        public Criteria andITEM37GreaterThan(String value) {
            addCriterion("ITEM37 >", value, "ITEM37");
            return (Criteria) this;
        }

        public Criteria andITEM37GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM37 >=", value, "ITEM37");
            return (Criteria) this;
        }

        public Criteria andITEM37LessThan(String value) {
            addCriterion("ITEM37 <", value, "ITEM37");
            return (Criteria) this;
        }

        public Criteria andITEM37LessThanOrEqualTo(String value) {
            addCriterion("ITEM37 <=", value, "ITEM37");
            return (Criteria) this;
        }

        public Criteria andITEM37Like(String value) {
            addCriterion("ITEM37 like", value, "ITEM37");
            return (Criteria) this;
        }

        public Criteria andITEM37NotLike(String value) {
            addCriterion("ITEM37 not like", value, "ITEM37");
            return (Criteria) this;
        }

        public Criteria andITEM37In(List<String> values) {
            addCriterion("ITEM37 in", values, "ITEM37");
            return (Criteria) this;
        }

        public Criteria andITEM37NotIn(List<String> values) {
            addCriterion("ITEM37 not in", values, "ITEM37");
            return (Criteria) this;
        }

        public Criteria andITEM37Between(String value1, String value2) {
            addCriterion("ITEM37 between", value1, value2, "ITEM37");
            return (Criteria) this;
        }

        public Criteria andITEM37NotBetween(String value1, String value2) {
            addCriterion("ITEM37 not between", value1, value2, "ITEM37");
            return (Criteria) this;
        }

        public Criteria andITEM38IsNull() {
            addCriterion("ITEM38 is null");
            return (Criteria) this;
        }

        public Criteria andITEM38IsNotNull() {
            addCriterion("ITEM38 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM38EqualTo(String value) {
            addCriterion("ITEM38 =", value, "ITEM38");
            return (Criteria) this;
        }

        public Criteria andITEM38NotEqualTo(String value) {
            addCriterion("ITEM38 <>", value, "ITEM38");
            return (Criteria) this;
        }

        public Criteria andITEM38GreaterThan(String value) {
            addCriterion("ITEM38 >", value, "ITEM38");
            return (Criteria) this;
        }

        public Criteria andITEM38GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM38 >=", value, "ITEM38");
            return (Criteria) this;
        }

        public Criteria andITEM38LessThan(String value) {
            addCriterion("ITEM38 <", value, "ITEM38");
            return (Criteria) this;
        }

        public Criteria andITEM38LessThanOrEqualTo(String value) {
            addCriterion("ITEM38 <=", value, "ITEM38");
            return (Criteria) this;
        }

        public Criteria andITEM38Like(String value) {
            addCriterion("ITEM38 like", value, "ITEM38");
            return (Criteria) this;
        }

        public Criteria andITEM38NotLike(String value) {
            addCriterion("ITEM38 not like", value, "ITEM38");
            return (Criteria) this;
        }

        public Criteria andITEM38In(List<String> values) {
            addCriterion("ITEM38 in", values, "ITEM38");
            return (Criteria) this;
        }

        public Criteria andITEM38NotIn(List<String> values) {
            addCriterion("ITEM38 not in", values, "ITEM38");
            return (Criteria) this;
        }

        public Criteria andITEM38Between(String value1, String value2) {
            addCriterion("ITEM38 between", value1, value2, "ITEM38");
            return (Criteria) this;
        }

        public Criteria andITEM38NotBetween(String value1, String value2) {
            addCriterion("ITEM38 not between", value1, value2, "ITEM38");
            return (Criteria) this;
        }

        public Criteria andITEM39IsNull() {
            addCriterion("ITEM39 is null");
            return (Criteria) this;
        }

        public Criteria andITEM39IsNotNull() {
            addCriterion("ITEM39 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM39EqualTo(String value) {
            addCriterion("ITEM39 =", value, "ITEM39");
            return (Criteria) this;
        }

        public Criteria andITEM39NotEqualTo(String value) {
            addCriterion("ITEM39 <>", value, "ITEM39");
            return (Criteria) this;
        }

        public Criteria andITEM39GreaterThan(String value) {
            addCriterion("ITEM39 >", value, "ITEM39");
            return (Criteria) this;
        }

        public Criteria andITEM39GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM39 >=", value, "ITEM39");
            return (Criteria) this;
        }

        public Criteria andITEM39LessThan(String value) {
            addCriterion("ITEM39 <", value, "ITEM39");
            return (Criteria) this;
        }

        public Criteria andITEM39LessThanOrEqualTo(String value) {
            addCriterion("ITEM39 <=", value, "ITEM39");
            return (Criteria) this;
        }

        public Criteria andITEM39Like(String value) {
            addCriterion("ITEM39 like", value, "ITEM39");
            return (Criteria) this;
        }

        public Criteria andITEM39NotLike(String value) {
            addCriterion("ITEM39 not like", value, "ITEM39");
            return (Criteria) this;
        }

        public Criteria andITEM39In(List<String> values) {
            addCriterion("ITEM39 in", values, "ITEM39");
            return (Criteria) this;
        }

        public Criteria andITEM39NotIn(List<String> values) {
            addCriterion("ITEM39 not in", values, "ITEM39");
            return (Criteria) this;
        }

        public Criteria andITEM39Between(String value1, String value2) {
            addCriterion("ITEM39 between", value1, value2, "ITEM39");
            return (Criteria) this;
        }

        public Criteria andITEM39NotBetween(String value1, String value2) {
            addCriterion("ITEM39 not between", value1, value2, "ITEM39");
            return (Criteria) this;
        }

        public Criteria andITEM40IsNull() {
            addCriterion("ITEM40 is null");
            return (Criteria) this;
        }

        public Criteria andITEM40IsNotNull() {
            addCriterion("ITEM40 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM40EqualTo(String value) {
            addCriterion("ITEM40 =", value, "ITEM40");
            return (Criteria) this;
        }

        public Criteria andITEM40NotEqualTo(String value) {
            addCriterion("ITEM40 <>", value, "ITEM40");
            return (Criteria) this;
        }

        public Criteria andITEM40GreaterThan(String value) {
            addCriterion("ITEM40 >", value, "ITEM40");
            return (Criteria) this;
        }

        public Criteria andITEM40GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM40 >=", value, "ITEM40");
            return (Criteria) this;
        }

        public Criteria andITEM40LessThan(String value) {
            addCriterion("ITEM40 <", value, "ITEM40");
            return (Criteria) this;
        }

        public Criteria andITEM40LessThanOrEqualTo(String value) {
            addCriterion("ITEM40 <=", value, "ITEM40");
            return (Criteria) this;
        }

        public Criteria andITEM40Like(String value) {
            addCriterion("ITEM40 like", value, "ITEM40");
            return (Criteria) this;
        }

        public Criteria andITEM40NotLike(String value) {
            addCriterion("ITEM40 not like", value, "ITEM40");
            return (Criteria) this;
        }

        public Criteria andITEM40In(List<String> values) {
            addCriterion("ITEM40 in", values, "ITEM40");
            return (Criteria) this;
        }

        public Criteria andITEM40NotIn(List<String> values) {
            addCriterion("ITEM40 not in", values, "ITEM40");
            return (Criteria) this;
        }

        public Criteria andITEM40Between(String value1, String value2) {
            addCriterion("ITEM40 between", value1, value2, "ITEM40");
            return (Criteria) this;
        }

        public Criteria andITEM40NotBetween(String value1, String value2) {
            addCriterion("ITEM40 not between", value1, value2, "ITEM40");
            return (Criteria) this;
        }

        public Criteria andITEM41IsNull() {
            addCriterion("ITEM41 is null");
            return (Criteria) this;
        }

        public Criteria andITEM41IsNotNull() {
            addCriterion("ITEM41 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM41EqualTo(String value) {
            addCriterion("ITEM41 =", value, "ITEM41");
            return (Criteria) this;
        }

        public Criteria andITEM41NotEqualTo(String value) {
            addCriterion("ITEM41 <>", value, "ITEM41");
            return (Criteria) this;
        }

        public Criteria andITEM41GreaterThan(String value) {
            addCriterion("ITEM41 >", value, "ITEM41");
            return (Criteria) this;
        }

        public Criteria andITEM41GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM41 >=", value, "ITEM41");
            return (Criteria) this;
        }

        public Criteria andITEM41LessThan(String value) {
            addCriterion("ITEM41 <", value, "ITEM41");
            return (Criteria) this;
        }

        public Criteria andITEM41LessThanOrEqualTo(String value) {
            addCriterion("ITEM41 <=", value, "ITEM41");
            return (Criteria) this;
        }

        public Criteria andITEM41Like(String value) {
            addCriterion("ITEM41 like", value, "ITEM41");
            return (Criteria) this;
        }

        public Criteria andITEM41NotLike(String value) {
            addCriterion("ITEM41 not like", value, "ITEM41");
            return (Criteria) this;
        }

        public Criteria andITEM41In(List<String> values) {
            addCriterion("ITEM41 in", values, "ITEM41");
            return (Criteria) this;
        }

        public Criteria andITEM41NotIn(List<String> values) {
            addCriterion("ITEM41 not in", values, "ITEM41");
            return (Criteria) this;
        }

        public Criteria andITEM41Between(String value1, String value2) {
            addCriterion("ITEM41 between", value1, value2, "ITEM41");
            return (Criteria) this;
        }

        public Criteria andITEM41NotBetween(String value1, String value2) {
            addCriterion("ITEM41 not between", value1, value2, "ITEM41");
            return (Criteria) this;
        }

        public Criteria andITEM42IsNull() {
            addCriterion("ITEM42 is null");
            return (Criteria) this;
        }

        public Criteria andITEM42IsNotNull() {
            addCriterion("ITEM42 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM42EqualTo(String value) {
            addCriterion("ITEM42 =", value, "ITEM42");
            return (Criteria) this;
        }

        public Criteria andITEM42NotEqualTo(String value) {
            addCriterion("ITEM42 <>", value, "ITEM42");
            return (Criteria) this;
        }

        public Criteria andITEM42GreaterThan(String value) {
            addCriterion("ITEM42 >", value, "ITEM42");
            return (Criteria) this;
        }

        public Criteria andITEM42GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM42 >=", value, "ITEM42");
            return (Criteria) this;
        }

        public Criteria andITEM42LessThan(String value) {
            addCriterion("ITEM42 <", value, "ITEM42");
            return (Criteria) this;
        }

        public Criteria andITEM42LessThanOrEqualTo(String value) {
            addCriterion("ITEM42 <=", value, "ITEM42");
            return (Criteria) this;
        }

        public Criteria andITEM42Like(String value) {
            addCriterion("ITEM42 like", value, "ITEM42");
            return (Criteria) this;
        }

        public Criteria andITEM42NotLike(String value) {
            addCriterion("ITEM42 not like", value, "ITEM42");
            return (Criteria) this;
        }

        public Criteria andITEM42In(List<String> values) {
            addCriterion("ITEM42 in", values, "ITEM42");
            return (Criteria) this;
        }

        public Criteria andITEM42NotIn(List<String> values) {
            addCriterion("ITEM42 not in", values, "ITEM42");
            return (Criteria) this;
        }

        public Criteria andITEM42Between(String value1, String value2) {
            addCriterion("ITEM42 between", value1, value2, "ITEM42");
            return (Criteria) this;
        }

        public Criteria andITEM42NotBetween(String value1, String value2) {
            addCriterion("ITEM42 not between", value1, value2, "ITEM42");
            return (Criteria) this;
        }

        public Criteria andITEM43IsNull() {
            addCriterion("ITEM43 is null");
            return (Criteria) this;
        }

        public Criteria andITEM43IsNotNull() {
            addCriterion("ITEM43 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM43EqualTo(String value) {
            addCriterion("ITEM43 =", value, "ITEM43");
            return (Criteria) this;
        }

        public Criteria andITEM43NotEqualTo(String value) {
            addCriterion("ITEM43 <>", value, "ITEM43");
            return (Criteria) this;
        }

        public Criteria andITEM43GreaterThan(String value) {
            addCriterion("ITEM43 >", value, "ITEM43");
            return (Criteria) this;
        }

        public Criteria andITEM43GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM43 >=", value, "ITEM43");
            return (Criteria) this;
        }

        public Criteria andITEM43LessThan(String value) {
            addCriterion("ITEM43 <", value, "ITEM43");
            return (Criteria) this;
        }

        public Criteria andITEM43LessThanOrEqualTo(String value) {
            addCriterion("ITEM43 <=", value, "ITEM43");
            return (Criteria) this;
        }

        public Criteria andITEM43Like(String value) {
            addCriterion("ITEM43 like", value, "ITEM43");
            return (Criteria) this;
        }

        public Criteria andITEM43NotLike(String value) {
            addCriterion("ITEM43 not like", value, "ITEM43");
            return (Criteria) this;
        }

        public Criteria andITEM43In(List<String> values) {
            addCriterion("ITEM43 in", values, "ITEM43");
            return (Criteria) this;
        }

        public Criteria andITEM43NotIn(List<String> values) {
            addCriterion("ITEM43 not in", values, "ITEM43");
            return (Criteria) this;
        }

        public Criteria andITEM43Between(String value1, String value2) {
            addCriterion("ITEM43 between", value1, value2, "ITEM43");
            return (Criteria) this;
        }

        public Criteria andITEM43NotBetween(String value1, String value2) {
            addCriterion("ITEM43 not between", value1, value2, "ITEM43");
            return (Criteria) this;
        }

        public Criteria andITEM44IsNull() {
            addCriterion("ITEM44 is null");
            return (Criteria) this;
        }

        public Criteria andITEM44IsNotNull() {
            addCriterion("ITEM44 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM44EqualTo(String value) {
            addCriterion("ITEM44 =", value, "ITEM44");
            return (Criteria) this;
        }

        public Criteria andITEM44NotEqualTo(String value) {
            addCriterion("ITEM44 <>", value, "ITEM44");
            return (Criteria) this;
        }

        public Criteria andITEM44GreaterThan(String value) {
            addCriterion("ITEM44 >", value, "ITEM44");
            return (Criteria) this;
        }

        public Criteria andITEM44GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM44 >=", value, "ITEM44");
            return (Criteria) this;
        }

        public Criteria andITEM44LessThan(String value) {
            addCriterion("ITEM44 <", value, "ITEM44");
            return (Criteria) this;
        }

        public Criteria andITEM44LessThanOrEqualTo(String value) {
            addCriterion("ITEM44 <=", value, "ITEM44");
            return (Criteria) this;
        }

        public Criteria andITEM44Like(String value) {
            addCriterion("ITEM44 like", value, "ITEM44");
            return (Criteria) this;
        }

        public Criteria andITEM44NotLike(String value) {
            addCriterion("ITEM44 not like", value, "ITEM44");
            return (Criteria) this;
        }

        public Criteria andITEM44In(List<String> values) {
            addCriterion("ITEM44 in", values, "ITEM44");
            return (Criteria) this;
        }

        public Criteria andITEM44NotIn(List<String> values) {
            addCriterion("ITEM44 not in", values, "ITEM44");
            return (Criteria) this;
        }

        public Criteria andITEM44Between(String value1, String value2) {
            addCriterion("ITEM44 between", value1, value2, "ITEM44");
            return (Criteria) this;
        }

        public Criteria andITEM44NotBetween(String value1, String value2) {
            addCriterion("ITEM44 not between", value1, value2, "ITEM44");
            return (Criteria) this;
        }

        public Criteria andITEM45IsNull() {
            addCriterion("ITEM45 is null");
            return (Criteria) this;
        }

        public Criteria andITEM45IsNotNull() {
            addCriterion("ITEM45 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM45EqualTo(String value) {
            addCriterion("ITEM45 =", value, "ITEM45");
            return (Criteria) this;
        }

        public Criteria andITEM45NotEqualTo(String value) {
            addCriterion("ITEM45 <>", value, "ITEM45");
            return (Criteria) this;
        }

        public Criteria andITEM45GreaterThan(String value) {
            addCriterion("ITEM45 >", value, "ITEM45");
            return (Criteria) this;
        }

        public Criteria andITEM45GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM45 >=", value, "ITEM45");
            return (Criteria) this;
        }

        public Criteria andITEM45LessThan(String value) {
            addCriterion("ITEM45 <", value, "ITEM45");
            return (Criteria) this;
        }

        public Criteria andITEM45LessThanOrEqualTo(String value) {
            addCriterion("ITEM45 <=", value, "ITEM45");
            return (Criteria) this;
        }

        public Criteria andITEM45Like(String value) {
            addCriterion("ITEM45 like", value, "ITEM45");
            return (Criteria) this;
        }

        public Criteria andITEM45NotLike(String value) {
            addCriterion("ITEM45 not like", value, "ITEM45");
            return (Criteria) this;
        }

        public Criteria andITEM45In(List<String> values) {
            addCriterion("ITEM45 in", values, "ITEM45");
            return (Criteria) this;
        }

        public Criteria andITEM45NotIn(List<String> values) {
            addCriterion("ITEM45 not in", values, "ITEM45");
            return (Criteria) this;
        }

        public Criteria andITEM45Between(String value1, String value2) {
            addCriterion("ITEM45 between", value1, value2, "ITEM45");
            return (Criteria) this;
        }

        public Criteria andITEM45NotBetween(String value1, String value2) {
            addCriterion("ITEM45 not between", value1, value2, "ITEM45");
            return (Criteria) this;
        }

        public Criteria andITEM46IsNull() {
            addCriterion("ITEM46 is null");
            return (Criteria) this;
        }

        public Criteria andITEM46IsNotNull() {
            addCriterion("ITEM46 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM46EqualTo(String value) {
            addCriterion("ITEM46 =", value, "ITEM46");
            return (Criteria) this;
        }

        public Criteria andITEM46NotEqualTo(String value) {
            addCriterion("ITEM46 <>", value, "ITEM46");
            return (Criteria) this;
        }

        public Criteria andITEM46GreaterThan(String value) {
            addCriterion("ITEM46 >", value, "ITEM46");
            return (Criteria) this;
        }

        public Criteria andITEM46GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM46 >=", value, "ITEM46");
            return (Criteria) this;
        }

        public Criteria andITEM46LessThan(String value) {
            addCriterion("ITEM46 <", value, "ITEM46");
            return (Criteria) this;
        }

        public Criteria andITEM46LessThanOrEqualTo(String value) {
            addCriterion("ITEM46 <=", value, "ITEM46");
            return (Criteria) this;
        }

        public Criteria andITEM46Like(String value) {
            addCriterion("ITEM46 like", value, "ITEM46");
            return (Criteria) this;
        }

        public Criteria andITEM46NotLike(String value) {
            addCriterion("ITEM46 not like", value, "ITEM46");
            return (Criteria) this;
        }

        public Criteria andITEM46In(List<String> values) {
            addCriterion("ITEM46 in", values, "ITEM46");
            return (Criteria) this;
        }

        public Criteria andITEM46NotIn(List<String> values) {
            addCriterion("ITEM46 not in", values, "ITEM46");
            return (Criteria) this;
        }

        public Criteria andITEM46Between(String value1, String value2) {
            addCriterion("ITEM46 between", value1, value2, "ITEM46");
            return (Criteria) this;
        }

        public Criteria andITEM46NotBetween(String value1, String value2) {
            addCriterion("ITEM46 not between", value1, value2, "ITEM46");
            return (Criteria) this;
        }

        public Criteria andITEM47IsNull() {
            addCriterion("ITEM47 is null");
            return (Criteria) this;
        }

        public Criteria andITEM47IsNotNull() {
            addCriterion("ITEM47 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM47EqualTo(String value) {
            addCriterion("ITEM47 =", value, "ITEM47");
            return (Criteria) this;
        }

        public Criteria andITEM47NotEqualTo(String value) {
            addCriterion("ITEM47 <>", value, "ITEM47");
            return (Criteria) this;
        }

        public Criteria andITEM47GreaterThan(String value) {
            addCriterion("ITEM47 >", value, "ITEM47");
            return (Criteria) this;
        }

        public Criteria andITEM47GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM47 >=", value, "ITEM47");
            return (Criteria) this;
        }

        public Criteria andITEM47LessThan(String value) {
            addCriterion("ITEM47 <", value, "ITEM47");
            return (Criteria) this;
        }

        public Criteria andITEM47LessThanOrEqualTo(String value) {
            addCriterion("ITEM47 <=", value, "ITEM47");
            return (Criteria) this;
        }

        public Criteria andITEM47Like(String value) {
            addCriterion("ITEM47 like", value, "ITEM47");
            return (Criteria) this;
        }

        public Criteria andITEM47NotLike(String value) {
            addCriterion("ITEM47 not like", value, "ITEM47");
            return (Criteria) this;
        }

        public Criteria andITEM47In(List<String> values) {
            addCriterion("ITEM47 in", values, "ITEM47");
            return (Criteria) this;
        }

        public Criteria andITEM47NotIn(List<String> values) {
            addCriterion("ITEM47 not in", values, "ITEM47");
            return (Criteria) this;
        }

        public Criteria andITEM47Between(String value1, String value2) {
            addCriterion("ITEM47 between", value1, value2, "ITEM47");
            return (Criteria) this;
        }

        public Criteria andITEM47NotBetween(String value1, String value2) {
            addCriterion("ITEM47 not between", value1, value2, "ITEM47");
            return (Criteria) this;
        }

        public Criteria andITEM48IsNull() {
            addCriterion("ITEM48 is null");
            return (Criteria) this;
        }

        public Criteria andITEM48IsNotNull() {
            addCriterion("ITEM48 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM48EqualTo(String value) {
            addCriterion("ITEM48 =", value, "ITEM48");
            return (Criteria) this;
        }

        public Criteria andITEM48NotEqualTo(String value) {
            addCriterion("ITEM48 <>", value, "ITEM48");
            return (Criteria) this;
        }

        public Criteria andITEM48GreaterThan(String value) {
            addCriterion("ITEM48 >", value, "ITEM48");
            return (Criteria) this;
        }

        public Criteria andITEM48GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM48 >=", value, "ITEM48");
            return (Criteria) this;
        }

        public Criteria andITEM48LessThan(String value) {
            addCriterion("ITEM48 <", value, "ITEM48");
            return (Criteria) this;
        }

        public Criteria andITEM48LessThanOrEqualTo(String value) {
            addCriterion("ITEM48 <=", value, "ITEM48");
            return (Criteria) this;
        }

        public Criteria andITEM48Like(String value) {
            addCriterion("ITEM48 like", value, "ITEM48");
            return (Criteria) this;
        }

        public Criteria andITEM48NotLike(String value) {
            addCriterion("ITEM48 not like", value, "ITEM48");
            return (Criteria) this;
        }

        public Criteria andITEM48In(List<String> values) {
            addCriterion("ITEM48 in", values, "ITEM48");
            return (Criteria) this;
        }

        public Criteria andITEM48NotIn(List<String> values) {
            addCriterion("ITEM48 not in", values, "ITEM48");
            return (Criteria) this;
        }

        public Criteria andITEM48Between(String value1, String value2) {
            addCriterion("ITEM48 between", value1, value2, "ITEM48");
            return (Criteria) this;
        }

        public Criteria andITEM48NotBetween(String value1, String value2) {
            addCriterion("ITEM48 not between", value1, value2, "ITEM48");
            return (Criteria) this;
        }

        public Criteria andITEM49IsNull() {
            addCriterion("ITEM49 is null");
            return (Criteria) this;
        }

        public Criteria andITEM49IsNotNull() {
            addCriterion("ITEM49 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM49EqualTo(String value) {
            addCriterion("ITEM49 =", value, "ITEM49");
            return (Criteria) this;
        }

        public Criteria andITEM49NotEqualTo(String value) {
            addCriterion("ITEM49 <>", value, "ITEM49");
            return (Criteria) this;
        }

        public Criteria andITEM49GreaterThan(String value) {
            addCriterion("ITEM49 >", value, "ITEM49");
            return (Criteria) this;
        }

        public Criteria andITEM49GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM49 >=", value, "ITEM49");
            return (Criteria) this;
        }

        public Criteria andITEM49LessThan(String value) {
            addCriterion("ITEM49 <", value, "ITEM49");
            return (Criteria) this;
        }

        public Criteria andITEM49LessThanOrEqualTo(String value) {
            addCriterion("ITEM49 <=", value, "ITEM49");
            return (Criteria) this;
        }

        public Criteria andITEM49Like(String value) {
            addCriterion("ITEM49 like", value, "ITEM49");
            return (Criteria) this;
        }

        public Criteria andITEM49NotLike(String value) {
            addCriterion("ITEM49 not like", value, "ITEM49");
            return (Criteria) this;
        }

        public Criteria andITEM49In(List<String> values) {
            addCriterion("ITEM49 in", values, "ITEM49");
            return (Criteria) this;
        }

        public Criteria andITEM49NotIn(List<String> values) {
            addCriterion("ITEM49 not in", values, "ITEM49");
            return (Criteria) this;
        }

        public Criteria andITEM49Between(String value1, String value2) {
            addCriterion("ITEM49 between", value1, value2, "ITEM49");
            return (Criteria) this;
        }

        public Criteria andITEM49NotBetween(String value1, String value2) {
            addCriterion("ITEM49 not between", value1, value2, "ITEM49");
            return (Criteria) this;
        }

        public Criteria andITEM50IsNull() {
            addCriterion("ITEM50 is null");
            return (Criteria) this;
        }

        public Criteria andITEM50IsNotNull() {
            addCriterion("ITEM50 is not null");
            return (Criteria) this;
        }

        public Criteria andITEM50EqualTo(String value) {
            addCriterion("ITEM50 =", value, "ITEM50");
            return (Criteria) this;
        }

        public Criteria andITEM50NotEqualTo(String value) {
            addCriterion("ITEM50 <>", value, "ITEM50");
            return (Criteria) this;
        }

        public Criteria andITEM50GreaterThan(String value) {
            addCriterion("ITEM50 >", value, "ITEM50");
            return (Criteria) this;
        }

        public Criteria andITEM50GreaterThanOrEqualTo(String value) {
            addCriterion("ITEM50 >=", value, "ITEM50");
            return (Criteria) this;
        }

        public Criteria andITEM50LessThan(String value) {
            addCriterion("ITEM50 <", value, "ITEM50");
            return (Criteria) this;
        }

        public Criteria andITEM50LessThanOrEqualTo(String value) {
            addCriterion("ITEM50 <=", value, "ITEM50");
            return (Criteria) this;
        }

        public Criteria andITEM50Like(String value) {
            addCriterion("ITEM50 like", value, "ITEM50");
            return (Criteria) this;
        }

        public Criteria andITEM50NotLike(String value) {
            addCriterion("ITEM50 not like", value, "ITEM50");
            return (Criteria) this;
        }

        public Criteria andITEM50In(List<String> values) {
            addCriterion("ITEM50 in", values, "ITEM50");
            return (Criteria) this;
        }

        public Criteria andITEM50NotIn(List<String> values) {
            addCriterion("ITEM50 not in", values, "ITEM50");
            return (Criteria) this;
        }

        public Criteria andITEM50Between(String value1, String value2) {
            addCriterion("ITEM50 between", value1, value2, "ITEM50");
            return (Criteria) this;
        }

        public Criteria andITEM50NotBetween(String value1, String value2) {
            addCriterion("ITEM50 not between", value1, value2, "ITEM50");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andLN_ML_TRIGLikeInsensitive(String value) {
            addCriterion("upper(LN_ML_TRIG) like", value.toUpperCase(), "LN_ML_TRIG");
            return (Criteria) this;
        }

        public Criteria andKINDLikeInsensitive(String value) {
            addCriterion("upper(KIND) like", value.toUpperCase(), "KIND");
            return (Criteria) this;
        }

        public Criteria andSTSLikeInsensitive(String value) {
            addCriterion("upper(STS) like", value.toUpperCase(), "STS");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFLikeInsensitive(String value) {
            addCriterion("upper(LN_KB_INF) like", value.toUpperCase(), "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_NOTICELikeInsensitive(String value) {
            addCriterion("upper(LN_NOTICE) like", value.toUpperCase(), "LN_NOTICE");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKULikeInsensitive(String value) {
            addCriterion("upper(LN_KB_CHIKU) like", value.toUpperCase(), "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_TENANT_MNGLikeInsensitive(String value) {
            addCriterion("upper(LN_TENANT_MNG) like", value.toUpperCase(), "LN_TENANT_MNG");
            return (Criteria) this;
        }

        public Criteria andALSOK_NOTICE_SEND_SVC_KINDLikeInsensitive(String value) {
            addCriterion("upper(ALSOK_NOTICE_SEND_SVC_KIND) like", value.toUpperCase(), "ALSOK_NOTICE_SEND_SVC_KIND");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONLikeInsensitive(String value) {
            addCriterion("upper(LN_ACNT_USER_COMMON) like", value.toUpperCase(), "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andFILE_NM_TOLikeInsensitive(String value) {
            addCriterion("upper(FILE_NM_TO) like", value.toUpperCase(), "FILE_NM_TO");
            return (Criteria) this;
        }

        public Criteria andGET_KIND_TOLikeInsensitive(String value) {
            addCriterion("upper(GET_KIND_TO) like", value.toUpperCase(), "GET_KIND_TO");
            return (Criteria) this;
        }

        public Criteria andITEM1LikeInsensitive(String value) {
            addCriterion("upper(ITEM1) like", value.toUpperCase(), "ITEM1");
            return (Criteria) this;
        }

        public Criteria andITEM2LikeInsensitive(String value) {
            addCriterion("upper(ITEM2) like", value.toUpperCase(), "ITEM2");
            return (Criteria) this;
        }

        public Criteria andITEM3LikeInsensitive(String value) {
            addCriterion("upper(ITEM3) like", value.toUpperCase(), "ITEM3");
            return (Criteria) this;
        }

        public Criteria andITEM4LikeInsensitive(String value) {
            addCriterion("upper(ITEM4) like", value.toUpperCase(), "ITEM4");
            return (Criteria) this;
        }

        public Criteria andITEM5LikeInsensitive(String value) {
            addCriterion("upper(ITEM5) like", value.toUpperCase(), "ITEM5");
            return (Criteria) this;
        }

        public Criteria andITEM6LikeInsensitive(String value) {
            addCriterion("upper(ITEM6) like", value.toUpperCase(), "ITEM6");
            return (Criteria) this;
        }

        public Criteria andITEM7LikeInsensitive(String value) {
            addCriterion("upper(ITEM7) like", value.toUpperCase(), "ITEM7");
            return (Criteria) this;
        }

        public Criteria andITEM8LikeInsensitive(String value) {
            addCriterion("upper(ITEM8) like", value.toUpperCase(), "ITEM8");
            return (Criteria) this;
        }

        public Criteria andITEM9LikeInsensitive(String value) {
            addCriterion("upper(ITEM9) like", value.toUpperCase(), "ITEM9");
            return (Criteria) this;
        }

        public Criteria andITEM10LikeInsensitive(String value) {
            addCriterion("upper(ITEM10) like", value.toUpperCase(), "ITEM10");
            return (Criteria) this;
        }

        public Criteria andITEM11LikeInsensitive(String value) {
            addCriterion("upper(ITEM11) like", value.toUpperCase(), "ITEM11");
            return (Criteria) this;
        }

        public Criteria andITEM12LikeInsensitive(String value) {
            addCriterion("upper(ITEM12) like", value.toUpperCase(), "ITEM12");
            return (Criteria) this;
        }

        public Criteria andITEM13LikeInsensitive(String value) {
            addCriterion("upper(ITEM13) like", value.toUpperCase(), "ITEM13");
            return (Criteria) this;
        }

        public Criteria andITEM14LikeInsensitive(String value) {
            addCriterion("upper(ITEM14) like", value.toUpperCase(), "ITEM14");
            return (Criteria) this;
        }

        public Criteria andITEM15LikeInsensitive(String value) {
            addCriterion("upper(ITEM15) like", value.toUpperCase(), "ITEM15");
            return (Criteria) this;
        }

        public Criteria andITEM16LikeInsensitive(String value) {
            addCriterion("upper(ITEM16) like", value.toUpperCase(), "ITEM16");
            return (Criteria) this;
        }

        public Criteria andITEM17LikeInsensitive(String value) {
            addCriterion("upper(ITEM17) like", value.toUpperCase(), "ITEM17");
            return (Criteria) this;
        }

        public Criteria andITEM18LikeInsensitive(String value) {
            addCriterion("upper(ITEM18) like", value.toUpperCase(), "ITEM18");
            return (Criteria) this;
        }

        public Criteria andITEM19LikeInsensitive(String value) {
            addCriterion("upper(ITEM19) like", value.toUpperCase(), "ITEM19");
            return (Criteria) this;
        }

        public Criteria andITEM20LikeInsensitive(String value) {
            addCriterion("upper(ITEM20) like", value.toUpperCase(), "ITEM20");
            return (Criteria) this;
        }

        public Criteria andITEM21LikeInsensitive(String value) {
            addCriterion("upper(ITEM21) like", value.toUpperCase(), "ITEM21");
            return (Criteria) this;
        }

        public Criteria andITEM22LikeInsensitive(String value) {
            addCriterion("upper(ITEM22) like", value.toUpperCase(), "ITEM22");
            return (Criteria) this;
        }

        public Criteria andITEM23LikeInsensitive(String value) {
            addCriterion("upper(ITEM23) like", value.toUpperCase(), "ITEM23");
            return (Criteria) this;
        }

        public Criteria andITEM24LikeInsensitive(String value) {
            addCriterion("upper(ITEM24) like", value.toUpperCase(), "ITEM24");
            return (Criteria) this;
        }

        public Criteria andITEM25LikeInsensitive(String value) {
            addCriterion("upper(ITEM25) like", value.toUpperCase(), "ITEM25");
            return (Criteria) this;
        }

        public Criteria andITEM26LikeInsensitive(String value) {
            addCriterion("upper(ITEM26) like", value.toUpperCase(), "ITEM26");
            return (Criteria) this;
        }

        public Criteria andITEM27LikeInsensitive(String value) {
            addCriterion("upper(ITEM27) like", value.toUpperCase(), "ITEM27");
            return (Criteria) this;
        }

        public Criteria andITEM28LikeInsensitive(String value) {
            addCriterion("upper(ITEM28) like", value.toUpperCase(), "ITEM28");
            return (Criteria) this;
        }

        public Criteria andITEM29LikeInsensitive(String value) {
            addCriterion("upper(ITEM29) like", value.toUpperCase(), "ITEM29");
            return (Criteria) this;
        }

        public Criteria andITEM30LikeInsensitive(String value) {
            addCriterion("upper(ITEM30) like", value.toUpperCase(), "ITEM30");
            return (Criteria) this;
        }

        public Criteria andITEM31LikeInsensitive(String value) {
            addCriterion("upper(ITEM31) like", value.toUpperCase(), "ITEM31");
            return (Criteria) this;
        }

        public Criteria andITEM32LikeInsensitive(String value) {
            addCriterion("upper(ITEM32) like", value.toUpperCase(), "ITEM32");
            return (Criteria) this;
        }

        public Criteria andITEM33LikeInsensitive(String value) {
            addCriterion("upper(ITEM33) like", value.toUpperCase(), "ITEM33");
            return (Criteria) this;
        }

        public Criteria andITEM34LikeInsensitive(String value) {
            addCriterion("upper(ITEM34) like", value.toUpperCase(), "ITEM34");
            return (Criteria) this;
        }

        public Criteria andITEM35LikeInsensitive(String value) {
            addCriterion("upper(ITEM35) like", value.toUpperCase(), "ITEM35");
            return (Criteria) this;
        }

        public Criteria andITEM36LikeInsensitive(String value) {
            addCriterion("upper(ITEM36) like", value.toUpperCase(), "ITEM36");
            return (Criteria) this;
        }

        public Criteria andITEM37LikeInsensitive(String value) {
            addCriterion("upper(ITEM37) like", value.toUpperCase(), "ITEM37");
            return (Criteria) this;
        }

        public Criteria andITEM38LikeInsensitive(String value) {
            addCriterion("upper(ITEM38) like", value.toUpperCase(), "ITEM38");
            return (Criteria) this;
        }

        public Criteria andITEM39LikeInsensitive(String value) {
            addCriterion("upper(ITEM39) like", value.toUpperCase(), "ITEM39");
            return (Criteria) this;
        }

        public Criteria andITEM40LikeInsensitive(String value) {
            addCriterion("upper(ITEM40) like", value.toUpperCase(), "ITEM40");
            return (Criteria) this;
        }

        public Criteria andITEM41LikeInsensitive(String value) {
            addCriterion("upper(ITEM41) like", value.toUpperCase(), "ITEM41");
            return (Criteria) this;
        }

        public Criteria andITEM42LikeInsensitive(String value) {
            addCriterion("upper(ITEM42) like", value.toUpperCase(), "ITEM42");
            return (Criteria) this;
        }

        public Criteria andITEM43LikeInsensitive(String value) {
            addCriterion("upper(ITEM43) like", value.toUpperCase(), "ITEM43");
            return (Criteria) this;
        }

        public Criteria andITEM44LikeInsensitive(String value) {
            addCriterion("upper(ITEM44) like", value.toUpperCase(), "ITEM44");
            return (Criteria) this;
        }

        public Criteria andITEM45LikeInsensitive(String value) {
            addCriterion("upper(ITEM45) like", value.toUpperCase(), "ITEM45");
            return (Criteria) this;
        }

        public Criteria andITEM46LikeInsensitive(String value) {
            addCriterion("upper(ITEM46) like", value.toUpperCase(), "ITEM46");
            return (Criteria) this;
        }

        public Criteria andITEM47LikeInsensitive(String value) {
            addCriterion("upper(ITEM47) like", value.toUpperCase(), "ITEM47");
            return (Criteria) this;
        }

        public Criteria andITEM48LikeInsensitive(String value) {
            addCriterion("upper(ITEM48) like", value.toUpperCase(), "ITEM48");
            return (Criteria) this;
        }

        public Criteria andITEM49LikeInsensitive(String value) {
            addCriterion("upper(ITEM49) like", value.toUpperCase(), "ITEM49");
            return (Criteria) this;
        }

        public Criteria andITEM50LikeInsensitive(String value) {
            addCriterion("upper(ITEM50) like", value.toUpperCase(), "ITEM50");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * C_QUE_ML_TRIG
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * C_QUE_ML_TRIG null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}