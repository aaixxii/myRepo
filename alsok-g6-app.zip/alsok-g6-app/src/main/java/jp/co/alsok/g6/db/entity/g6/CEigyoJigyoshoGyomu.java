package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class CEigyoJigyoshoGyomu extends CEigyoJigyoshoGyomuKey implements Serializable {
    /**
     * 事業所業務コード
     */
    private String JIGYOSHO_GYOMU_CD;

    /**
     * 事業所業務名称
     */
    private String JIGYOSHO_GYOMU_NM;

    /**
     * 予備項目01
     */
    private String YOBI_KOMOKU_01;

    /**
     * 予備項目02
     */
    private String YOBI_KOMOKU_02;

    /**
     * 予備項目03
     */
    private String YOBI_KOMOKU_03;

    /**
     * 予備項目04
     */
    private String YOBI_KOMOKU_04;

    /**
     * 予備項目05
     */
    private String YOBI_KOMOKU_05;

    /**
     * 予備項目06
     */
    private String YOBI_KOMOKU_06;

    /**
     * 予備項目07
     */
    private String YOBI_KOMOKU_07;

    /**
     * 予備項目08
     */
    private String YOBI_KOMOKU_08;

    /**
     * 予備項目09
     */
    private String YOBI_KOMOKU_09;

    /**
     * 予備項目10
     */
    private String YOBI_KOMOKU_10;

    /**
     * 登録タイムスタンプ
     */
    private Date REGST_TMSTMP;

    /**
     * 登録者会社コード
     */
    private String REGSTR_CO_CD;

    /**
     * 登録者組織コード
     */
    private String REGSTR_SOSHIKI_CD;

    /**
     * 登録者社員番号
     */
    private String REGSTR_EMP_NO;

    /**
     * 登録画面ＩＤ
     */
    private String REGST_GAMEN_ID;

    /**
     * 登録プログラムＩＤ
     */
    private String REGST_PGM_ID;

    /**
     * 更新タイムスタンプ
     */
    private Date UPD_TMSTMP;

    /**
     * 更新者会社コード
     */
    private String UPDTR_CO_CD;

    /**
     * 更新者組織コード
     */
    private String UPDTR_SOSHIKI_CD;

    /**
     * 更新者社員番号
     */
    private String UPDTR_EMP_NO;

    /**
     * 更新画面ＩＤ
     */
    private String UPD_GAMEN_ID;

    /**
     * 更新プログラムＩＤ
     */
    private String UPD_PGM_ID;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * C_EIGYO_JIGYOSHO_GYOMU
     */
    private static final long serialVersionUID = 1L;

    /**
     * 事業所業務コード
     * @return JIGYOSHO_GYOMU_CD 事業所業務コード
     */
    public String getJIGYOSHO_GYOMU_CD() {
        return JIGYOSHO_GYOMU_CD;
    }

    /**
     * 事業所業務コード
     * @param JIGYOSHO_GYOMU_CD 事業所業務コード
     */
    public void setJIGYOSHO_GYOMU_CD(String JIGYOSHO_GYOMU_CD) {
        this.JIGYOSHO_GYOMU_CD = JIGYOSHO_GYOMU_CD == null ? null : JIGYOSHO_GYOMU_CD.trim();
    }

    /**
     * 事業所業務名称
     * @return JIGYOSHO_GYOMU_NM 事業所業務名称
     */
    public String getJIGYOSHO_GYOMU_NM() {
        return JIGYOSHO_GYOMU_NM;
    }

    /**
     * 事業所業務名称
     * @param JIGYOSHO_GYOMU_NM 事業所業務名称
     */
    public void setJIGYOSHO_GYOMU_NM(String JIGYOSHO_GYOMU_NM) {
        this.JIGYOSHO_GYOMU_NM = JIGYOSHO_GYOMU_NM == null ? null : JIGYOSHO_GYOMU_NM.trim();
    }

    /**
     * 予備項目01
     * @return YOBI_KOMOKU_01 予備項目01
     */
    public String getYOBI_KOMOKU_01() {
        return YOBI_KOMOKU_01;
    }

    /**
     * 予備項目01
     * @param YOBI_KOMOKU_01 予備項目01
     */
    public void setYOBI_KOMOKU_01(String YOBI_KOMOKU_01) {
        this.YOBI_KOMOKU_01 = YOBI_KOMOKU_01 == null ? null : YOBI_KOMOKU_01.trim();
    }

    /**
     * 予備項目02
     * @return YOBI_KOMOKU_02 予備項目02
     */
    public String getYOBI_KOMOKU_02() {
        return YOBI_KOMOKU_02;
    }

    /**
     * 予備項目02
     * @param YOBI_KOMOKU_02 予備項目02
     */
    public void setYOBI_KOMOKU_02(String YOBI_KOMOKU_02) {
        this.YOBI_KOMOKU_02 = YOBI_KOMOKU_02 == null ? null : YOBI_KOMOKU_02.trim();
    }

    /**
     * 予備項目03
     * @return YOBI_KOMOKU_03 予備項目03
     */
    public String getYOBI_KOMOKU_03() {
        return YOBI_KOMOKU_03;
    }

    /**
     * 予備項目03
     * @param YOBI_KOMOKU_03 予備項目03
     */
    public void setYOBI_KOMOKU_03(String YOBI_KOMOKU_03) {
        this.YOBI_KOMOKU_03 = YOBI_KOMOKU_03 == null ? null : YOBI_KOMOKU_03.trim();
    }

    /**
     * 予備項目04
     * @return YOBI_KOMOKU_04 予備項目04
     */
    public String getYOBI_KOMOKU_04() {
        return YOBI_KOMOKU_04;
    }

    /**
     * 予備項目04
     * @param YOBI_KOMOKU_04 予備項目04
     */
    public void setYOBI_KOMOKU_04(String YOBI_KOMOKU_04) {
        this.YOBI_KOMOKU_04 = YOBI_KOMOKU_04 == null ? null : YOBI_KOMOKU_04.trim();
    }

    /**
     * 予備項目05
     * @return YOBI_KOMOKU_05 予備項目05
     */
    public String getYOBI_KOMOKU_05() {
        return YOBI_KOMOKU_05;
    }

    /**
     * 予備項目05
     * @param YOBI_KOMOKU_05 予備項目05
     */
    public void setYOBI_KOMOKU_05(String YOBI_KOMOKU_05) {
        this.YOBI_KOMOKU_05 = YOBI_KOMOKU_05 == null ? null : YOBI_KOMOKU_05.trim();
    }

    /**
     * 予備項目06
     * @return YOBI_KOMOKU_06 予備項目06
     */
    public String getYOBI_KOMOKU_06() {
        return YOBI_KOMOKU_06;
    }

    /**
     * 予備項目06
     * @param YOBI_KOMOKU_06 予備項目06
     */
    public void setYOBI_KOMOKU_06(String YOBI_KOMOKU_06) {
        this.YOBI_KOMOKU_06 = YOBI_KOMOKU_06 == null ? null : YOBI_KOMOKU_06.trim();
    }

    /**
     * 予備項目07
     * @return YOBI_KOMOKU_07 予備項目07
     */
    public String getYOBI_KOMOKU_07() {
        return YOBI_KOMOKU_07;
    }

    /**
     * 予備項目07
     * @param YOBI_KOMOKU_07 予備項目07
     */
    public void setYOBI_KOMOKU_07(String YOBI_KOMOKU_07) {
        this.YOBI_KOMOKU_07 = YOBI_KOMOKU_07 == null ? null : YOBI_KOMOKU_07.trim();
    }

    /**
     * 予備項目08
     * @return YOBI_KOMOKU_08 予備項目08
     */
    public String getYOBI_KOMOKU_08() {
        return YOBI_KOMOKU_08;
    }

    /**
     * 予備項目08
     * @param YOBI_KOMOKU_08 予備項目08
     */
    public void setYOBI_KOMOKU_08(String YOBI_KOMOKU_08) {
        this.YOBI_KOMOKU_08 = YOBI_KOMOKU_08 == null ? null : YOBI_KOMOKU_08.trim();
    }

    /**
     * 予備項目09
     * @return YOBI_KOMOKU_09 予備項目09
     */
    public String getYOBI_KOMOKU_09() {
        return YOBI_KOMOKU_09;
    }

    /**
     * 予備項目09
     * @param YOBI_KOMOKU_09 予備項目09
     */
    public void setYOBI_KOMOKU_09(String YOBI_KOMOKU_09) {
        this.YOBI_KOMOKU_09 = YOBI_KOMOKU_09 == null ? null : YOBI_KOMOKU_09.trim();
    }

    /**
     * 予備項目10
     * @return YOBI_KOMOKU_10 予備項目10
     */
    public String getYOBI_KOMOKU_10() {
        return YOBI_KOMOKU_10;
    }

    /**
     * 予備項目10
     * @param YOBI_KOMOKU_10 予備項目10
     */
    public void setYOBI_KOMOKU_10(String YOBI_KOMOKU_10) {
        this.YOBI_KOMOKU_10 = YOBI_KOMOKU_10 == null ? null : YOBI_KOMOKU_10.trim();
    }

    /**
     * 登録タイムスタンプ
     * @return REGST_TMSTMP 登録タイムスタンプ
     */
    public Date getREGST_TMSTMP() {
        return REGST_TMSTMP;
    }

    /**
     * 登録タイムスタンプ
     * @param REGST_TMSTMP 登録タイムスタンプ
     */
    public void setREGST_TMSTMP(Date REGST_TMSTMP) {
        this.REGST_TMSTMP = REGST_TMSTMP;
    }

    /**
     * 登録者会社コード
     * @return REGSTR_CO_CD 登録者会社コード
     */
    public String getREGSTR_CO_CD() {
        return REGSTR_CO_CD;
    }

    /**
     * 登録者会社コード
     * @param REGSTR_CO_CD 登録者会社コード
     */
    public void setREGSTR_CO_CD(String REGSTR_CO_CD) {
        this.REGSTR_CO_CD = REGSTR_CO_CD == null ? null : REGSTR_CO_CD.trim();
    }

    /**
     * 登録者組織コード
     * @return REGSTR_SOSHIKI_CD 登録者組織コード
     */
    public String getREGSTR_SOSHIKI_CD() {
        return REGSTR_SOSHIKI_CD;
    }

    /**
     * 登録者組織コード
     * @param REGSTR_SOSHIKI_CD 登録者組織コード
     */
    public void setREGSTR_SOSHIKI_CD(String REGSTR_SOSHIKI_CD) {
        this.REGSTR_SOSHIKI_CD = REGSTR_SOSHIKI_CD == null ? null : REGSTR_SOSHIKI_CD.trim();
    }

    /**
     * 登録者社員番号
     * @return REGSTR_EMP_NO 登録者社員番号
     */
    public String getREGSTR_EMP_NO() {
        return REGSTR_EMP_NO;
    }

    /**
     * 登録者社員番号
     * @param REGSTR_EMP_NO 登録者社員番号
     */
    public void setREGSTR_EMP_NO(String REGSTR_EMP_NO) {
        this.REGSTR_EMP_NO = REGSTR_EMP_NO == null ? null : REGSTR_EMP_NO.trim();
    }

    /**
     * 登録画面ＩＤ
     * @return REGST_GAMEN_ID 登録画面ＩＤ
     */
    public String getREGST_GAMEN_ID() {
        return REGST_GAMEN_ID;
    }

    /**
     * 登録画面ＩＤ
     * @param REGST_GAMEN_ID 登録画面ＩＤ
     */
    public void setREGST_GAMEN_ID(String REGST_GAMEN_ID) {
        this.REGST_GAMEN_ID = REGST_GAMEN_ID == null ? null : REGST_GAMEN_ID.trim();
    }

    /**
     * 登録プログラムＩＤ
     * @return REGST_PGM_ID 登録プログラムＩＤ
     */
    public String getREGST_PGM_ID() {
        return REGST_PGM_ID;
    }

    /**
     * 登録プログラムＩＤ
     * @param REGST_PGM_ID 登録プログラムＩＤ
     */
    public void setREGST_PGM_ID(String REGST_PGM_ID) {
        this.REGST_PGM_ID = REGST_PGM_ID == null ? null : REGST_PGM_ID.trim();
    }

    /**
     * 更新タイムスタンプ
     * @return UPD_TMSTMP 更新タイムスタンプ
     */
    public Date getUPD_TMSTMP() {
        return UPD_TMSTMP;
    }

    /**
     * 更新タイムスタンプ
     * @param UPD_TMSTMP 更新タイムスタンプ
     */
    public void setUPD_TMSTMP(Date UPD_TMSTMP) {
        this.UPD_TMSTMP = UPD_TMSTMP;
    }

    /**
     * 更新者会社コード
     * @return UPDTR_CO_CD 更新者会社コード
     */
    public String getUPDTR_CO_CD() {
        return UPDTR_CO_CD;
    }

    /**
     * 更新者会社コード
     * @param UPDTR_CO_CD 更新者会社コード
     */
    public void setUPDTR_CO_CD(String UPDTR_CO_CD) {
        this.UPDTR_CO_CD = UPDTR_CO_CD == null ? null : UPDTR_CO_CD.trim();
    }

    /**
     * 更新者組織コード
     * @return UPDTR_SOSHIKI_CD 更新者組織コード
     */
    public String getUPDTR_SOSHIKI_CD() {
        return UPDTR_SOSHIKI_CD;
    }

    /**
     * 更新者組織コード
     * @param UPDTR_SOSHIKI_CD 更新者組織コード
     */
    public void setUPDTR_SOSHIKI_CD(String UPDTR_SOSHIKI_CD) {
        this.UPDTR_SOSHIKI_CD = UPDTR_SOSHIKI_CD == null ? null : UPDTR_SOSHIKI_CD.trim();
    }

    /**
     * 更新者社員番号
     * @return UPDTR_EMP_NO 更新者社員番号
     */
    public String getUPDTR_EMP_NO() {
        return UPDTR_EMP_NO;
    }

    /**
     * 更新者社員番号
     * @param UPDTR_EMP_NO 更新者社員番号
     */
    public void setUPDTR_EMP_NO(String UPDTR_EMP_NO) {
        this.UPDTR_EMP_NO = UPDTR_EMP_NO == null ? null : UPDTR_EMP_NO.trim();
    }

    /**
     * 更新画面ＩＤ
     * @return UPD_GAMEN_ID 更新画面ＩＤ
     */
    public String getUPD_GAMEN_ID() {
        return UPD_GAMEN_ID;
    }

    /**
     * 更新画面ＩＤ
     * @param UPD_GAMEN_ID 更新画面ＩＤ
     */
    public void setUPD_GAMEN_ID(String UPD_GAMEN_ID) {
        this.UPD_GAMEN_ID = UPD_GAMEN_ID == null ? null : UPD_GAMEN_ID.trim();
    }

    /**
     * 更新プログラムＩＤ
     * @return UPD_PGM_ID 更新プログラムＩＤ
     */
    public String getUPD_PGM_ID() {
        return UPD_PGM_ID;
    }

    /**
     * 更新プログラムＩＤ
     * @param UPD_PGM_ID 更新プログラムＩＤ
     */
    public void setUPD_PGM_ID(String UPD_PGM_ID) {
        this.UPD_PGM_ID = UPD_PGM_ID == null ? null : UPD_PGM_ID.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}