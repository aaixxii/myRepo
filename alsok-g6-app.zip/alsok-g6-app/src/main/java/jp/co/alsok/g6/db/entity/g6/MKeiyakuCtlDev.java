package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class MKeiyakuCtlDev implements Serializable {
    /**
     * 機器種別ID
     */
    private String DEV_KIND_ID;

    /**
     * 制御装置名称
     */
    private String CTL_DEV_NM;

    /**
     * 契約種別２（CD）
     */
    private String KEIYAKU_KIND2_NM;

    /**
     * 契約種別２（名称）
     */
    private String KEIYAKU_KIND2_CD;

    /**
     * M_KEIYAKU_CTL_DEV
     */
    private static final long serialVersionUID = 1L;

    /**
     * 機器種別ID
     * @return DEV_KIND_ID 機器種別ID
     */
    public String getDEV_KIND_ID() {
        return DEV_KIND_ID;
    }

    /**
     * 機器種別ID
     * @param DEV_KIND_ID 機器種別ID
     */
    public void setDEV_KIND_ID(String DEV_KIND_ID) {
        this.DEV_KIND_ID = DEV_KIND_ID == null ? null : DEV_KIND_ID.trim();
    }

    /**
     * 制御装置名称
     * @return CTL_DEV_NM 制御装置名称
     */
    public String getCTL_DEV_NM() {
        return CTL_DEV_NM;
    }

    /**
     * 制御装置名称
     * @param CTL_DEV_NM 制御装置名称
     */
    public void setCTL_DEV_NM(String CTL_DEV_NM) {
        this.CTL_DEV_NM = CTL_DEV_NM == null ? null : CTL_DEV_NM.trim();
    }

    /**
     * 契約種別２（CD）
     * @return KEIYAKU_KIND2_NM 契約種別２（CD）
     */
    public String getKEIYAKU_KIND2_NM() {
        return KEIYAKU_KIND2_NM;
    }

    /**
     * 契約種別２（CD）
     * @param KEIYAKU_KIND2_NM 契約種別２（CD）
     */
    public void setKEIYAKU_KIND2_NM(String KEIYAKU_KIND2_NM) {
        this.KEIYAKU_KIND2_NM = KEIYAKU_KIND2_NM == null ? null : KEIYAKU_KIND2_NM.trim();
    }

    /**
     * 契約種別２（名称）
     * @return KEIYAKU_KIND2_CD 契約種別２（名称）
     */
    public String getKEIYAKU_KIND2_CD() {
        return KEIYAKU_KIND2_CD;
    }

    /**
     * 契約種別２（名称）
     * @param KEIYAKU_KIND2_CD 契約種別２（名称）
     */
    public void setKEIYAKU_KIND2_CD(String KEIYAKU_KIND2_CD) {
        this.KEIYAKU_KIND2_CD = KEIYAKU_KIND2_CD == null ? null : KEIYAKU_KIND2_CD.trim();
    }
}