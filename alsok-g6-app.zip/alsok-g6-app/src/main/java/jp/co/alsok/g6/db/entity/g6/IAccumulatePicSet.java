package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class IAccumulatePicSet implements Serializable {
    /**
     * LN_蓄積画像設定論理番号
     */
    private String LN_ACCUMULATE_PIC_SET;

    /**
     * LN_警備先地区論理番号
     */
    private String LN_KB_CHIKU;

    /**
     * LN_設置機器論理番号
     */
    private String LN_DEV;

    /**
     * 画質区分
     */
    private String IMAGE_QUALITY_KBN;

    /**
     * 音声蓄積フラグ
     */
    private String VOICE_ACCUMULATE_FLG;

    /**
     * 削除条件区分
     */
    private String DEL_TERMS_KBN;

    /**
     * 保持期間
     */
    private Byte RETENTION_PERIOD;

    /**
     * 保持容量
     */
    private Byte RETENTION_CAPACITY;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * I_ACCUMULATE_PIC_SET
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_蓄積画像設定論理番号
     * @return LN_ACCUMULATE_PIC_SET LN_蓄積画像設定論理番号
     */
    public String getLN_ACCUMULATE_PIC_SET() {
        return LN_ACCUMULATE_PIC_SET;
    }

    /**
     * LN_蓄積画像設定論理番号
     * @param LN_ACCUMULATE_PIC_SET LN_蓄積画像設定論理番号
     */
    public void setLN_ACCUMULATE_PIC_SET(String LN_ACCUMULATE_PIC_SET) {
        this.LN_ACCUMULATE_PIC_SET = LN_ACCUMULATE_PIC_SET == null ? null : LN_ACCUMULATE_PIC_SET.trim();
    }

    /**
     * LN_警備先地区論理番号
     * @return LN_KB_CHIKU LN_警備先地区論理番号
     */
    public String getLN_KB_CHIKU() {
        return LN_KB_CHIKU;
    }

    /**
     * LN_警備先地区論理番号
     * @param LN_KB_CHIKU LN_警備先地区論理番号
     */
    public void setLN_KB_CHIKU(String LN_KB_CHIKU) {
        this.LN_KB_CHIKU = LN_KB_CHIKU == null ? null : LN_KB_CHIKU.trim();
    }

    /**
     * LN_設置機器論理番号
     * @return LN_DEV LN_設置機器論理番号
     */
    public String getLN_DEV() {
        return LN_DEV;
    }

    /**
     * LN_設置機器論理番号
     * @param LN_DEV LN_設置機器論理番号
     */
    public void setLN_DEV(String LN_DEV) {
        this.LN_DEV = LN_DEV == null ? null : LN_DEV.trim();
    }

    /**
     * 画質区分
     * @return IMAGE_QUALITY_KBN 画質区分
     */
    public String getIMAGE_QUALITY_KBN() {
        return IMAGE_QUALITY_KBN;
    }

    /**
     * 画質区分
     * @param IMAGE_QUALITY_KBN 画質区分
     */
    public void setIMAGE_QUALITY_KBN(String IMAGE_QUALITY_KBN) {
        this.IMAGE_QUALITY_KBN = IMAGE_QUALITY_KBN == null ? null : IMAGE_QUALITY_KBN.trim();
    }

    /**
     * 音声蓄積フラグ
     * @return VOICE_ACCUMULATE_FLG 音声蓄積フラグ
     */
    public String getVOICE_ACCUMULATE_FLG() {
        return VOICE_ACCUMULATE_FLG;
    }

    /**
     * 音声蓄積フラグ
     * @param VOICE_ACCUMULATE_FLG 音声蓄積フラグ
     */
    public void setVOICE_ACCUMULATE_FLG(String VOICE_ACCUMULATE_FLG) {
        this.VOICE_ACCUMULATE_FLG = VOICE_ACCUMULATE_FLG == null ? null : VOICE_ACCUMULATE_FLG.trim();
    }

    /**
     * 削除条件区分
     * @return DEL_TERMS_KBN 削除条件区分
     */
    public String getDEL_TERMS_KBN() {
        return DEL_TERMS_KBN;
    }

    /**
     * 削除条件区分
     * @param DEL_TERMS_KBN 削除条件区分
     */
    public void setDEL_TERMS_KBN(String DEL_TERMS_KBN) {
        this.DEL_TERMS_KBN = DEL_TERMS_KBN == null ? null : DEL_TERMS_KBN.trim();
    }

    /**
     * 保持期間
     * @return RETENTION_PERIOD 保持期間
     */
    public Byte getRETENTION_PERIOD() {
        return RETENTION_PERIOD;
    }

    /**
     * 保持期間
     * @param RETENTION_PERIOD 保持期間
     */
    public void setRETENTION_PERIOD(Byte RETENTION_PERIOD) {
        this.RETENTION_PERIOD = RETENTION_PERIOD;
    }

    /**
     * 保持容量
     * @return RETENTION_CAPACITY 保持容量
     */
    public Byte getRETENTION_CAPACITY() {
        return RETENTION_CAPACITY;
    }

    /**
     * 保持容量
     * @param RETENTION_CAPACITY 保持容量
     */
    public void setRETENTION_CAPACITY(Byte RETENTION_CAPACITY) {
        this.RETENTION_CAPACITY = RETENTION_CAPACITY;
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}