package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class HLogAlsokUserOperation implements Serializable {
    /**
     * LN_ALSOK操作履歴論理番号
     */
    private String LN_ALSOK_USER_OPERATION;

    /**
     * 警備先名称
     */
    private String KEIBI_NM;

    /**
     * お客様番号２
     */
    private String CUSTOMER_NUM2;

    /**
     * 警備先地区名称（SD_個別名称）
     */
    private String SD_KOBETU_NM;

    /**
     * 氏名（社員名／ユーザー氏名）
     */
    private String USER_NM;

    /**
     * 操作画面ID
     */
    private String DISP_ID;

    /**
     * 操作内容コード
     */
    private String ALSOK_OPERATION_NAIYOU_CD;

    /**
     * 内容
     */
    private String ALSOK_OPERATION_NAIYOU;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * H_LOG_ALSOK_USER_OPERATION
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_ALSOK操作履歴論理番号
     * @return LN_ALSOK_USER_OPERATION LN_ALSOK操作履歴論理番号
     */
    public String getLN_ALSOK_USER_OPERATION() {
        return LN_ALSOK_USER_OPERATION;
    }

    /**
     * LN_ALSOK操作履歴論理番号
     * @param LN_ALSOK_USER_OPERATION LN_ALSOK操作履歴論理番号
     */
    public void setLN_ALSOK_USER_OPERATION(String LN_ALSOK_USER_OPERATION) {
        this.LN_ALSOK_USER_OPERATION = LN_ALSOK_USER_OPERATION == null ? null : LN_ALSOK_USER_OPERATION.trim();
    }

    /**
     * 警備先名称
     * @return KEIBI_NM 警備先名称
     */
    public String getKEIBI_NM() {
        return KEIBI_NM;
    }

    /**
     * 警備先名称
     * @param KEIBI_NM 警備先名称
     */
    public void setKEIBI_NM(String KEIBI_NM) {
        this.KEIBI_NM = KEIBI_NM == null ? null : KEIBI_NM.trim();
    }

    /**
     * お客様番号２
     * @return CUSTOMER_NUM2 お客様番号２
     */
    public String getCUSTOMER_NUM2() {
        return CUSTOMER_NUM2;
    }

    /**
     * お客様番号２
     * @param CUSTOMER_NUM2 お客様番号２
     */
    public void setCUSTOMER_NUM2(String CUSTOMER_NUM2) {
        this.CUSTOMER_NUM2 = CUSTOMER_NUM2 == null ? null : CUSTOMER_NUM2.trim();
    }

    /**
     * 警備先地区名称（SD_個別名称）
     * @return SD_KOBETU_NM 警備先地区名称（SD_個別名称）
     */
    public String getSD_KOBETU_NM() {
        return SD_KOBETU_NM;
    }

    /**
     * 警備先地区名称（SD_個別名称）
     * @param SD_KOBETU_NM 警備先地区名称（SD_個別名称）
     */
    public void setSD_KOBETU_NM(String SD_KOBETU_NM) {
        this.SD_KOBETU_NM = SD_KOBETU_NM == null ? null : SD_KOBETU_NM.trim();
    }

    /**
     * 氏名（社員名／ユーザー氏名）
     * @return USER_NM 氏名（社員名／ユーザー氏名）
     */
    public String getUSER_NM() {
        return USER_NM;
    }

    /**
     * 氏名（社員名／ユーザー氏名）
     * @param USER_NM 氏名（社員名／ユーザー氏名）
     */
    public void setUSER_NM(String USER_NM) {
        this.USER_NM = USER_NM == null ? null : USER_NM.trim();
    }

    /**
     * 操作画面ID
     * @return DISP_ID 操作画面ID
     */
    public String getDISP_ID() {
        return DISP_ID;
    }

    /**
     * 操作画面ID
     * @param DISP_ID 操作画面ID
     */
    public void setDISP_ID(String DISP_ID) {
        this.DISP_ID = DISP_ID == null ? null : DISP_ID.trim();
    }

    /**
     * 操作内容コード
     * @return ALSOK_OPERATION_NAIYOU_CD 操作内容コード
     */
    public String getALSOK_OPERATION_NAIYOU_CD() {
        return ALSOK_OPERATION_NAIYOU_CD;
    }

    /**
     * 操作内容コード
     * @param ALSOK_OPERATION_NAIYOU_CD 操作内容コード
     */
    public void setALSOK_OPERATION_NAIYOU_CD(String ALSOK_OPERATION_NAIYOU_CD) {
        this.ALSOK_OPERATION_NAIYOU_CD = ALSOK_OPERATION_NAIYOU_CD == null ? null : ALSOK_OPERATION_NAIYOU_CD.trim();
    }

    /**
     * 内容
     * @return ALSOK_OPERATION_NAIYOU 内容
     */
    public String getALSOK_OPERATION_NAIYOU() {
        return ALSOK_OPERATION_NAIYOU;
    }

    /**
     * 内容
     * @param ALSOK_OPERATION_NAIYOU 内容
     */
    public void setALSOK_OPERATION_NAIYOU(String ALSOK_OPERATION_NAIYOU) {
        this.ALSOK_OPERATION_NAIYOU = ALSOK_OPERATION_NAIYOU == null ? null : ALSOK_OPERATION_NAIYOU.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}