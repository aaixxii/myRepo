package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class MKbServiceTeikyoMst implements Serializable {
    /**
     * LN_警備サービス提供種別マスター論理番号
     */
    private String LN_KB_SERVICE_TEIKYO_MST;

    /**
     * サービス名
     */
    private String SERVICE_NM;

    /**
     * WEBオプション設定フラグ
     */
    private String WEB_SET_FLG;

    /**
     * 削除フラグ
     */
    private String DEL_FLG;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * M_KB_SERVICE_TEIKYO_MST
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_警備サービス提供種別マスター論理番号
     * @return LN_KB_SERVICE_TEIKYO_MST LN_警備サービス提供種別マスター論理番号
     */
    public String getLN_KB_SERVICE_TEIKYO_MST() {
        return LN_KB_SERVICE_TEIKYO_MST;
    }

    /**
     * LN_警備サービス提供種別マスター論理番号
     * @param LN_KB_SERVICE_TEIKYO_MST LN_警備サービス提供種別マスター論理番号
     */
    public void setLN_KB_SERVICE_TEIKYO_MST(String LN_KB_SERVICE_TEIKYO_MST) {
        this.LN_KB_SERVICE_TEIKYO_MST = LN_KB_SERVICE_TEIKYO_MST == null ? null : LN_KB_SERVICE_TEIKYO_MST.trim();
    }

    /**
     * サービス名
     * @return SERVICE_NM サービス名
     */
    public String getSERVICE_NM() {
        return SERVICE_NM;
    }

    /**
     * サービス名
     * @param SERVICE_NM サービス名
     */
    public void setSERVICE_NM(String SERVICE_NM) {
        this.SERVICE_NM = SERVICE_NM == null ? null : SERVICE_NM.trim();
    }

    /**
     * WEBオプション設定フラグ
     * @return WEB_SET_FLG WEBオプション設定フラグ
     */
    public String getWEB_SET_FLG() {
        return WEB_SET_FLG;
    }

    /**
     * WEBオプション設定フラグ
     * @param WEB_SET_FLG WEBオプション設定フラグ
     */
    public void setWEB_SET_FLG(String WEB_SET_FLG) {
        this.WEB_SET_FLG = WEB_SET_FLG == null ? null : WEB_SET_FLG.trim();
    }

    /**
     * 削除フラグ
     * @return DEL_FLG 削除フラグ
     */
    public String getDEL_FLG() {
        return DEL_FLG;
    }

    /**
     * 削除フラグ
     * @param DEL_FLG 削除フラグ
     */
    public void setDEL_FLG(String DEL_FLG) {
        this.DEL_FLG = DEL_FLG == null ? null : DEL_FLG.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}