package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class MMlKind extends MMlKindKey implements Serializable {
    /**
     * メール種別
     */
    private String ML_KIND;

    /**
     * 警報名称コード
     */
    private String KEIHO_NAME_CD;

    /**
     * M_ML_KIND
     */
    private static final long serialVersionUID = 1L;

    /**
     * メール種別
     * @return ML_KIND メール種別
     */
    public String getML_KIND() {
        return ML_KIND;
    }

    /**
     * メール種別
     * @param ML_KIND メール種別
     */
    public void setML_KIND(String ML_KIND) {
        this.ML_KIND = ML_KIND == null ? null : ML_KIND.trim();
    }

    /**
     * 警報名称コード
     * @return KEIHO_NAME_CD 警報名称コード
     */
    public String getKEIHO_NAME_CD() {
        return KEIHO_NAME_CD;
    }

    /**
     * 警報名称コード
     * @param KEIHO_NAME_CD 警報名称コード
     */
    public void setKEIHO_NAME_CD(String KEIHO_NAME_CD) {
        this.KEIHO_NAME_CD = KEIHO_NAME_CD == null ? null : KEIHO_NAME_CD.trim();
    }
}