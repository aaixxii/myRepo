package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EKbInfExample {
    /**
     * E_KB_INF
     */
    protected String orderByClause;

    /**
     * E_KB_INF
     */
    protected boolean distinct;

    /**
     * E_KB_INF
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public EKbInfExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * E_KB_INF null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_KB_INFIsNull() {
            addCriterion("LN_KB_INF is null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFIsNotNull() {
            addCriterion("LN_KB_INF is not null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFEqualTo(String value) {
            addCriterion("LN_KB_INF =", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFNotEqualTo(String value) {
            addCriterion("LN_KB_INF <>", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFGreaterThan(String value) {
            addCriterion("LN_KB_INF >", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFGreaterThanOrEqualTo(String value) {
            addCriterion("LN_KB_INF >=", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFLessThan(String value) {
            addCriterion("LN_KB_INF <", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFLessThanOrEqualTo(String value) {
            addCriterion("LN_KB_INF <=", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFLike(String value) {
            addCriterion("LN_KB_INF like", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFNotLike(String value) {
            addCriterion("LN_KB_INF not like", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFIn(List<String> values) {
            addCriterion("LN_KB_INF in", values, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFNotIn(List<String> values) {
            addCriterion("LN_KB_INF not in", values, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFBetween(String value1, String value2) {
            addCriterion("LN_KB_INF between", value1, value2, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFNotBetween(String value1, String value2) {
            addCriterion("LN_KB_INF not between", value1, value2, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUIsNull() {
            addCriterion("LN_KB_CHIKU is null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUIsNotNull() {
            addCriterion("LN_KB_CHIKU is not null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUEqualTo(String value) {
            addCriterion("LN_KB_CHIKU =", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUNotEqualTo(String value) {
            addCriterion("LN_KB_CHIKU <>", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUGreaterThan(String value) {
            addCriterion("LN_KB_CHIKU >", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUGreaterThanOrEqualTo(String value) {
            addCriterion("LN_KB_CHIKU >=", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKULessThan(String value) {
            addCriterion("LN_KB_CHIKU <", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKULessThanOrEqualTo(String value) {
            addCriterion("LN_KB_CHIKU <=", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKULike(String value) {
            addCriterion("LN_KB_CHIKU like", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUNotLike(String value) {
            addCriterion("LN_KB_CHIKU not like", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUIn(List<String> values) {
            addCriterion("LN_KB_CHIKU in", values, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUNotIn(List<String> values) {
            addCriterion("LN_KB_CHIKU not in", values, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUBetween(String value1, String value2) {
            addCriterion("LN_KB_CHIKU between", value1, value2, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUNotBetween(String value1, String value2) {
            addCriterion("LN_KB_CHIKU not between", value1, value2, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andSIG_RCV_TSIsNull() {
            addCriterion("SIG_RCV_TS is null");
            return (Criteria) this;
        }

        public Criteria andSIG_RCV_TSIsNotNull() {
            addCriterion("SIG_RCV_TS is not null");
            return (Criteria) this;
        }

        public Criteria andSIG_RCV_TSEqualTo(Date value) {
            addCriterion("SIG_RCV_TS =", value, "SIG_RCV_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_RCV_TSNotEqualTo(Date value) {
            addCriterion("SIG_RCV_TS <>", value, "SIG_RCV_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_RCV_TSGreaterThan(Date value) {
            addCriterion("SIG_RCV_TS >", value, "SIG_RCV_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_RCV_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("SIG_RCV_TS >=", value, "SIG_RCV_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_RCV_TSLessThan(Date value) {
            addCriterion("SIG_RCV_TS <", value, "SIG_RCV_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_RCV_TSLessThanOrEqualTo(Date value) {
            addCriterion("SIG_RCV_TS <=", value, "SIG_RCV_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_RCV_TSIn(List<Date> values) {
            addCriterion("SIG_RCV_TS in", values, "SIG_RCV_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_RCV_TSNotIn(List<Date> values) {
            addCriterion("SIG_RCV_TS not in", values, "SIG_RCV_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_RCV_TSBetween(Date value1, Date value2) {
            addCriterion("SIG_RCV_TS between", value1, value2, "SIG_RCV_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_RCV_TSNotBetween(Date value1, Date value2) {
            addCriterion("SIG_RCV_TS not between", value1, value2, "SIG_RCV_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSIsNull() {
            addCriterion("SIG_HASSEI_TS is null");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSIsNotNull() {
            addCriterion("SIG_HASSEI_TS is not null");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSEqualTo(Date value) {
            addCriterion("SIG_HASSEI_TS =", value, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSNotEqualTo(Date value) {
            addCriterion("SIG_HASSEI_TS <>", value, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSGreaterThan(Date value) {
            addCriterion("SIG_HASSEI_TS >", value, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("SIG_HASSEI_TS >=", value, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSLessThan(Date value) {
            addCriterion("SIG_HASSEI_TS <", value, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSLessThanOrEqualTo(Date value) {
            addCriterion("SIG_HASSEI_TS <=", value, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSIn(List<Date> values) {
            addCriterion("SIG_HASSEI_TS in", values, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSNotIn(List<Date> values) {
            addCriterion("SIG_HASSEI_TS not in", values, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSBetween(Date value1, Date value2) {
            addCriterion("SIG_HASSEI_TS between", value1, value2, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSNotBetween(Date value1, Date value2) {
            addCriterion("SIG_HASSEI_TS not between", value1, value2, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_TSIsNull() {
            addCriterion("GW_RCV_TS is null");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_TSIsNotNull() {
            addCriterion("GW_RCV_TS is not null");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_TSEqualTo(String value) {
            addCriterion("GW_RCV_TS =", value, "GW_RCV_TS");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_TSNotEqualTo(String value) {
            addCriterion("GW_RCV_TS <>", value, "GW_RCV_TS");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_TSGreaterThan(String value) {
            addCriterion("GW_RCV_TS >", value, "GW_RCV_TS");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_TSGreaterThanOrEqualTo(String value) {
            addCriterion("GW_RCV_TS >=", value, "GW_RCV_TS");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_TSLessThan(String value) {
            addCriterion("GW_RCV_TS <", value, "GW_RCV_TS");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_TSLessThanOrEqualTo(String value) {
            addCriterion("GW_RCV_TS <=", value, "GW_RCV_TS");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_TSLike(String value) {
            addCriterion("GW_RCV_TS like", value, "GW_RCV_TS");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_TSNotLike(String value) {
            addCriterion("GW_RCV_TS not like", value, "GW_RCV_TS");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_TSIn(List<String> values) {
            addCriterion("GW_RCV_TS in", values, "GW_RCV_TS");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_TSNotIn(List<String> values) {
            addCriterion("GW_RCV_TS not in", values, "GW_RCV_TS");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_TSBetween(String value1, String value2) {
            addCriterion("GW_RCV_TS between", value1, value2, "GW_RCV_TS");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_TSNotBetween(String value1, String value2) {
            addCriterion("GW_RCV_TS not between", value1, value2, "GW_RCV_TS");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_IP_ADDRIsNull() {
            addCriterion("GW_RCV_IP_ADDR is null");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_IP_ADDRIsNotNull() {
            addCriterion("GW_RCV_IP_ADDR is not null");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_IP_ADDREqualTo(String value) {
            addCriterion("GW_RCV_IP_ADDR =", value, "GW_RCV_IP_ADDR");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_IP_ADDRNotEqualTo(String value) {
            addCriterion("GW_RCV_IP_ADDR <>", value, "GW_RCV_IP_ADDR");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_IP_ADDRGreaterThan(String value) {
            addCriterion("GW_RCV_IP_ADDR >", value, "GW_RCV_IP_ADDR");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_IP_ADDRGreaterThanOrEqualTo(String value) {
            addCriterion("GW_RCV_IP_ADDR >=", value, "GW_RCV_IP_ADDR");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_IP_ADDRLessThan(String value) {
            addCriterion("GW_RCV_IP_ADDR <", value, "GW_RCV_IP_ADDR");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_IP_ADDRLessThanOrEqualTo(String value) {
            addCriterion("GW_RCV_IP_ADDR <=", value, "GW_RCV_IP_ADDR");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_IP_ADDRLike(String value) {
            addCriterion("GW_RCV_IP_ADDR like", value, "GW_RCV_IP_ADDR");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_IP_ADDRNotLike(String value) {
            addCriterion("GW_RCV_IP_ADDR not like", value, "GW_RCV_IP_ADDR");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_IP_ADDRIn(List<String> values) {
            addCriterion("GW_RCV_IP_ADDR in", values, "GW_RCV_IP_ADDR");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_IP_ADDRNotIn(List<String> values) {
            addCriterion("GW_RCV_IP_ADDR not in", values, "GW_RCV_IP_ADDR");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_IP_ADDRBetween(String value1, String value2) {
            addCriterion("GW_RCV_IP_ADDR between", value1, value2, "GW_RCV_IP_ADDR");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_IP_ADDRNotBetween(String value1, String value2) {
            addCriterion("GW_RCV_IP_ADDR not between", value1, value2, "GW_RCV_IP_ADDR");
            return (Criteria) this;
        }

        public Criteria andGW_HOST_NMIsNull() {
            addCriterion("GW_HOST_NM is null");
            return (Criteria) this;
        }

        public Criteria andGW_HOST_NMIsNotNull() {
            addCriterion("GW_HOST_NM is not null");
            return (Criteria) this;
        }

        public Criteria andGW_HOST_NMEqualTo(String value) {
            addCriterion("GW_HOST_NM =", value, "GW_HOST_NM");
            return (Criteria) this;
        }

        public Criteria andGW_HOST_NMNotEqualTo(String value) {
            addCriterion("GW_HOST_NM <>", value, "GW_HOST_NM");
            return (Criteria) this;
        }

        public Criteria andGW_HOST_NMGreaterThan(String value) {
            addCriterion("GW_HOST_NM >", value, "GW_HOST_NM");
            return (Criteria) this;
        }

        public Criteria andGW_HOST_NMGreaterThanOrEqualTo(String value) {
            addCriterion("GW_HOST_NM >=", value, "GW_HOST_NM");
            return (Criteria) this;
        }

        public Criteria andGW_HOST_NMLessThan(String value) {
            addCriterion("GW_HOST_NM <", value, "GW_HOST_NM");
            return (Criteria) this;
        }

        public Criteria andGW_HOST_NMLessThanOrEqualTo(String value) {
            addCriterion("GW_HOST_NM <=", value, "GW_HOST_NM");
            return (Criteria) this;
        }

        public Criteria andGW_HOST_NMLike(String value) {
            addCriterion("GW_HOST_NM like", value, "GW_HOST_NM");
            return (Criteria) this;
        }

        public Criteria andGW_HOST_NMNotLike(String value) {
            addCriterion("GW_HOST_NM not like", value, "GW_HOST_NM");
            return (Criteria) this;
        }

        public Criteria andGW_HOST_NMIn(List<String> values) {
            addCriterion("GW_HOST_NM in", values, "GW_HOST_NM");
            return (Criteria) this;
        }

        public Criteria andGW_HOST_NMNotIn(List<String> values) {
            addCriterion("GW_HOST_NM not in", values, "GW_HOST_NM");
            return (Criteria) this;
        }

        public Criteria andGW_HOST_NMBetween(String value1, String value2) {
            addCriterion("GW_HOST_NM between", value1, value2, "GW_HOST_NM");
            return (Criteria) this;
        }

        public Criteria andGW_HOST_NMNotBetween(String value1, String value2) {
            addCriterion("GW_HOST_NM not between", value1, value2, "GW_HOST_NM");
            return (Criteria) this;
        }

        public Criteria andGW_IP_KINDIsNull() {
            addCriterion("GW_IP_KIND is null");
            return (Criteria) this;
        }

        public Criteria andGW_IP_KINDIsNotNull() {
            addCriterion("GW_IP_KIND is not null");
            return (Criteria) this;
        }

        public Criteria andGW_IP_KINDEqualTo(String value) {
            addCriterion("GW_IP_KIND =", value, "GW_IP_KIND");
            return (Criteria) this;
        }

        public Criteria andGW_IP_KINDNotEqualTo(String value) {
            addCriterion("GW_IP_KIND <>", value, "GW_IP_KIND");
            return (Criteria) this;
        }

        public Criteria andGW_IP_KINDGreaterThan(String value) {
            addCriterion("GW_IP_KIND >", value, "GW_IP_KIND");
            return (Criteria) this;
        }

        public Criteria andGW_IP_KINDGreaterThanOrEqualTo(String value) {
            addCriterion("GW_IP_KIND >=", value, "GW_IP_KIND");
            return (Criteria) this;
        }

        public Criteria andGW_IP_KINDLessThan(String value) {
            addCriterion("GW_IP_KIND <", value, "GW_IP_KIND");
            return (Criteria) this;
        }

        public Criteria andGW_IP_KINDLessThanOrEqualTo(String value) {
            addCriterion("GW_IP_KIND <=", value, "GW_IP_KIND");
            return (Criteria) this;
        }

        public Criteria andGW_IP_KINDLike(String value) {
            addCriterion("GW_IP_KIND like", value, "GW_IP_KIND");
            return (Criteria) this;
        }

        public Criteria andGW_IP_KINDNotLike(String value) {
            addCriterion("GW_IP_KIND not like", value, "GW_IP_KIND");
            return (Criteria) this;
        }

        public Criteria andGW_IP_KINDIn(List<String> values) {
            addCriterion("GW_IP_KIND in", values, "GW_IP_KIND");
            return (Criteria) this;
        }

        public Criteria andGW_IP_KINDNotIn(List<String> values) {
            addCriterion("GW_IP_KIND not in", values, "GW_IP_KIND");
            return (Criteria) this;
        }

        public Criteria andGW_IP_KINDBetween(String value1, String value2) {
            addCriterion("GW_IP_KIND between", value1, value2, "GW_IP_KIND");
            return (Criteria) this;
        }

        public Criteria andGW_IP_KINDNotBetween(String value1, String value2) {
            addCriterion("GW_IP_KIND not between", value1, value2, "GW_IP_KIND");
            return (Criteria) this;
        }

        public Criteria andCMD_VER_9IsNull() {
            addCriterion("CMD_VER_9 is null");
            return (Criteria) this;
        }

        public Criteria andCMD_VER_9IsNotNull() {
            addCriterion("CMD_VER_9 is not null");
            return (Criteria) this;
        }

        public Criteria andCMD_VER_9EqualTo(String value) {
            addCriterion("CMD_VER_9 =", value, "CMD_VER_9");
            return (Criteria) this;
        }

        public Criteria andCMD_VER_9NotEqualTo(String value) {
            addCriterion("CMD_VER_9 <>", value, "CMD_VER_9");
            return (Criteria) this;
        }

        public Criteria andCMD_VER_9GreaterThan(String value) {
            addCriterion("CMD_VER_9 >", value, "CMD_VER_9");
            return (Criteria) this;
        }

        public Criteria andCMD_VER_9GreaterThanOrEqualTo(String value) {
            addCriterion("CMD_VER_9 >=", value, "CMD_VER_9");
            return (Criteria) this;
        }

        public Criteria andCMD_VER_9LessThan(String value) {
            addCriterion("CMD_VER_9 <", value, "CMD_VER_9");
            return (Criteria) this;
        }

        public Criteria andCMD_VER_9LessThanOrEqualTo(String value) {
            addCriterion("CMD_VER_9 <=", value, "CMD_VER_9");
            return (Criteria) this;
        }

        public Criteria andCMD_VER_9Like(String value) {
            addCriterion("CMD_VER_9 like", value, "CMD_VER_9");
            return (Criteria) this;
        }

        public Criteria andCMD_VER_9NotLike(String value) {
            addCriterion("CMD_VER_9 not like", value, "CMD_VER_9");
            return (Criteria) this;
        }

        public Criteria andCMD_VER_9In(List<String> values) {
            addCriterion("CMD_VER_9 in", values, "CMD_VER_9");
            return (Criteria) this;
        }

        public Criteria andCMD_VER_9NotIn(List<String> values) {
            addCriterion("CMD_VER_9 not in", values, "CMD_VER_9");
            return (Criteria) this;
        }

        public Criteria andCMD_VER_9Between(String value1, String value2) {
            addCriterion("CMD_VER_9 between", value1, value2, "CMD_VER_9");
            return (Criteria) this;
        }

        public Criteria andCMD_VER_9NotBetween(String value1, String value2) {
            addCriterion("CMD_VER_9 not between", value1, value2, "CMD_VER_9");
            return (Criteria) this;
        }

        public Criteria andTR_NUM_9IsNull() {
            addCriterion("TR_NUM_9 is null");
            return (Criteria) this;
        }

        public Criteria andTR_NUM_9IsNotNull() {
            addCriterion("TR_NUM_9 is not null");
            return (Criteria) this;
        }

        public Criteria andTR_NUM_9EqualTo(String value) {
            addCriterion("TR_NUM_9 =", value, "TR_NUM_9");
            return (Criteria) this;
        }

        public Criteria andTR_NUM_9NotEqualTo(String value) {
            addCriterion("TR_NUM_9 <>", value, "TR_NUM_9");
            return (Criteria) this;
        }

        public Criteria andTR_NUM_9GreaterThan(String value) {
            addCriterion("TR_NUM_9 >", value, "TR_NUM_9");
            return (Criteria) this;
        }

        public Criteria andTR_NUM_9GreaterThanOrEqualTo(String value) {
            addCriterion("TR_NUM_9 >=", value, "TR_NUM_9");
            return (Criteria) this;
        }

        public Criteria andTR_NUM_9LessThan(String value) {
            addCriterion("TR_NUM_9 <", value, "TR_NUM_9");
            return (Criteria) this;
        }

        public Criteria andTR_NUM_9LessThanOrEqualTo(String value) {
            addCriterion("TR_NUM_9 <=", value, "TR_NUM_9");
            return (Criteria) this;
        }

        public Criteria andTR_NUM_9Like(String value) {
            addCriterion("TR_NUM_9 like", value, "TR_NUM_9");
            return (Criteria) this;
        }

        public Criteria andTR_NUM_9NotLike(String value) {
            addCriterion("TR_NUM_9 not like", value, "TR_NUM_9");
            return (Criteria) this;
        }

        public Criteria andTR_NUM_9In(List<String> values) {
            addCriterion("TR_NUM_9 in", values, "TR_NUM_9");
            return (Criteria) this;
        }

        public Criteria andTR_NUM_9NotIn(List<String> values) {
            addCriterion("TR_NUM_9 not in", values, "TR_NUM_9");
            return (Criteria) this;
        }

        public Criteria andTR_NUM_9Between(String value1, String value2) {
            addCriterion("TR_NUM_9 between", value1, value2, "TR_NUM_9");
            return (Criteria) this;
        }

        public Criteria andTR_NUM_9NotBetween(String value1, String value2) {
            addCriterion("TR_NUM_9 not between", value1, value2, "TR_NUM_9");
            return (Criteria) this;
        }

        public Criteria andGENERATION_TS_9IsNull() {
            addCriterion("GENERATION_TS_9 is null");
            return (Criteria) this;
        }

        public Criteria andGENERATION_TS_9IsNotNull() {
            addCriterion("GENERATION_TS_9 is not null");
            return (Criteria) this;
        }

        public Criteria andGENERATION_TS_9EqualTo(String value) {
            addCriterion("GENERATION_TS_9 =", value, "GENERATION_TS_9");
            return (Criteria) this;
        }

        public Criteria andGENERATION_TS_9NotEqualTo(String value) {
            addCriterion("GENERATION_TS_9 <>", value, "GENERATION_TS_9");
            return (Criteria) this;
        }

        public Criteria andGENERATION_TS_9GreaterThan(String value) {
            addCriterion("GENERATION_TS_9 >", value, "GENERATION_TS_9");
            return (Criteria) this;
        }

        public Criteria andGENERATION_TS_9GreaterThanOrEqualTo(String value) {
            addCriterion("GENERATION_TS_9 >=", value, "GENERATION_TS_9");
            return (Criteria) this;
        }

        public Criteria andGENERATION_TS_9LessThan(String value) {
            addCriterion("GENERATION_TS_9 <", value, "GENERATION_TS_9");
            return (Criteria) this;
        }

        public Criteria andGENERATION_TS_9LessThanOrEqualTo(String value) {
            addCriterion("GENERATION_TS_9 <=", value, "GENERATION_TS_9");
            return (Criteria) this;
        }

        public Criteria andGENERATION_TS_9Like(String value) {
            addCriterion("GENERATION_TS_9 like", value, "GENERATION_TS_9");
            return (Criteria) this;
        }

        public Criteria andGENERATION_TS_9NotLike(String value) {
            addCriterion("GENERATION_TS_9 not like", value, "GENERATION_TS_9");
            return (Criteria) this;
        }

        public Criteria andGENERATION_TS_9In(List<String> values) {
            addCriterion("GENERATION_TS_9 in", values, "GENERATION_TS_9");
            return (Criteria) this;
        }

        public Criteria andGENERATION_TS_9NotIn(List<String> values) {
            addCriterion("GENERATION_TS_9 not in", values, "GENERATION_TS_9");
            return (Criteria) this;
        }

        public Criteria andGENERATION_TS_9Between(String value1, String value2) {
            addCriterion("GENERATION_TS_9 between", value1, value2, "GENERATION_TS_9");
            return (Criteria) this;
        }

        public Criteria andGENERATION_TS_9NotBetween(String value1, String value2) {
            addCriterion("GENERATION_TS_9 not between", value1, value2, "GENERATION_TS_9");
            return (Criteria) this;
        }

        public Criteria andTRANSMITTER_9_IDIsNull() {
            addCriterion("TRANSMITTER_9_ID is null");
            return (Criteria) this;
        }

        public Criteria andTRANSMITTER_9_IDIsNotNull() {
            addCriterion("TRANSMITTER_9_ID is not null");
            return (Criteria) this;
        }

        public Criteria andTRANSMITTER_9_IDEqualTo(String value) {
            addCriterion("TRANSMITTER_9_ID =", value, "TRANSMITTER_9_ID");
            return (Criteria) this;
        }

        public Criteria andTRANSMITTER_9_IDNotEqualTo(String value) {
            addCriterion("TRANSMITTER_9_ID <>", value, "TRANSMITTER_9_ID");
            return (Criteria) this;
        }

        public Criteria andTRANSMITTER_9_IDGreaterThan(String value) {
            addCriterion("TRANSMITTER_9_ID >", value, "TRANSMITTER_9_ID");
            return (Criteria) this;
        }

        public Criteria andTRANSMITTER_9_IDGreaterThanOrEqualTo(String value) {
            addCriterion("TRANSMITTER_9_ID >=", value, "TRANSMITTER_9_ID");
            return (Criteria) this;
        }

        public Criteria andTRANSMITTER_9_IDLessThan(String value) {
            addCriterion("TRANSMITTER_9_ID <", value, "TRANSMITTER_9_ID");
            return (Criteria) this;
        }

        public Criteria andTRANSMITTER_9_IDLessThanOrEqualTo(String value) {
            addCriterion("TRANSMITTER_9_ID <=", value, "TRANSMITTER_9_ID");
            return (Criteria) this;
        }

        public Criteria andTRANSMITTER_9_IDLike(String value) {
            addCriterion("TRANSMITTER_9_ID like", value, "TRANSMITTER_9_ID");
            return (Criteria) this;
        }

        public Criteria andTRANSMITTER_9_IDNotLike(String value) {
            addCriterion("TRANSMITTER_9_ID not like", value, "TRANSMITTER_9_ID");
            return (Criteria) this;
        }

        public Criteria andTRANSMITTER_9_IDIn(List<String> values) {
            addCriterion("TRANSMITTER_9_ID in", values, "TRANSMITTER_9_ID");
            return (Criteria) this;
        }

        public Criteria andTRANSMITTER_9_IDNotIn(List<String> values) {
            addCriterion("TRANSMITTER_9_ID not in", values, "TRANSMITTER_9_ID");
            return (Criteria) this;
        }

        public Criteria andTRANSMITTER_9_IDBetween(String value1, String value2) {
            addCriterion("TRANSMITTER_9_ID between", value1, value2, "TRANSMITTER_9_ID");
            return (Criteria) this;
        }

        public Criteria andTRANSMITTER_9_IDNotBetween(String value1, String value2) {
            addCriterion("TRANSMITTER_9_ID not between", value1, value2, "TRANSMITTER_9_ID");
            return (Criteria) this;
        }

        public Criteria andDENKEI_9IsNull() {
            addCriterion("DENKEI_9 is null");
            return (Criteria) this;
        }

        public Criteria andDENKEI_9IsNotNull() {
            addCriterion("DENKEI_9 is not null");
            return (Criteria) this;
        }

        public Criteria andDENKEI_9EqualTo(String value) {
            addCriterion("DENKEI_9 =", value, "DENKEI_9");
            return (Criteria) this;
        }

        public Criteria andDENKEI_9NotEqualTo(String value) {
            addCriterion("DENKEI_9 <>", value, "DENKEI_9");
            return (Criteria) this;
        }

        public Criteria andDENKEI_9GreaterThan(String value) {
            addCriterion("DENKEI_9 >", value, "DENKEI_9");
            return (Criteria) this;
        }

        public Criteria andDENKEI_9GreaterThanOrEqualTo(String value) {
            addCriterion("DENKEI_9 >=", value, "DENKEI_9");
            return (Criteria) this;
        }

        public Criteria andDENKEI_9LessThan(String value) {
            addCriterion("DENKEI_9 <", value, "DENKEI_9");
            return (Criteria) this;
        }

        public Criteria andDENKEI_9LessThanOrEqualTo(String value) {
            addCriterion("DENKEI_9 <=", value, "DENKEI_9");
            return (Criteria) this;
        }

        public Criteria andDENKEI_9Like(String value) {
            addCriterion("DENKEI_9 like", value, "DENKEI_9");
            return (Criteria) this;
        }

        public Criteria andDENKEI_9NotLike(String value) {
            addCriterion("DENKEI_9 not like", value, "DENKEI_9");
            return (Criteria) this;
        }

        public Criteria andDENKEI_9In(List<String> values) {
            addCriterion("DENKEI_9 in", values, "DENKEI_9");
            return (Criteria) this;
        }

        public Criteria andDENKEI_9NotIn(List<String> values) {
            addCriterion("DENKEI_9 not in", values, "DENKEI_9");
            return (Criteria) this;
        }

        public Criteria andDENKEI_9Between(String value1, String value2) {
            addCriterion("DENKEI_9 between", value1, value2, "DENKEI_9");
            return (Criteria) this;
        }

        public Criteria andDENKEI_9NotBetween(String value1, String value2) {
            addCriterion("DENKEI_9 not between", value1, value2, "DENKEI_9");
            return (Criteria) this;
        }

        public Criteria andGOUKI_9IsNull() {
            addCriterion("GOUKI_9 is null");
            return (Criteria) this;
        }

        public Criteria andGOUKI_9IsNotNull() {
            addCriterion("GOUKI_9 is not null");
            return (Criteria) this;
        }

        public Criteria andGOUKI_9EqualTo(String value) {
            addCriterion("GOUKI_9 =", value, "GOUKI_9");
            return (Criteria) this;
        }

        public Criteria andGOUKI_9NotEqualTo(String value) {
            addCriterion("GOUKI_9 <>", value, "GOUKI_9");
            return (Criteria) this;
        }

        public Criteria andGOUKI_9GreaterThan(String value) {
            addCriterion("GOUKI_9 >", value, "GOUKI_9");
            return (Criteria) this;
        }

        public Criteria andGOUKI_9GreaterThanOrEqualTo(String value) {
            addCriterion("GOUKI_9 >=", value, "GOUKI_9");
            return (Criteria) this;
        }

        public Criteria andGOUKI_9LessThan(String value) {
            addCriterion("GOUKI_9 <", value, "GOUKI_9");
            return (Criteria) this;
        }

        public Criteria andGOUKI_9LessThanOrEqualTo(String value) {
            addCriterion("GOUKI_9 <=", value, "GOUKI_9");
            return (Criteria) this;
        }

        public Criteria andGOUKI_9Like(String value) {
            addCriterion("GOUKI_9 like", value, "GOUKI_9");
            return (Criteria) this;
        }

        public Criteria andGOUKI_9NotLike(String value) {
            addCriterion("GOUKI_9 not like", value, "GOUKI_9");
            return (Criteria) this;
        }

        public Criteria andGOUKI_9In(List<String> values) {
            addCriterion("GOUKI_9 in", values, "GOUKI_9");
            return (Criteria) this;
        }

        public Criteria andGOUKI_9NotIn(List<String> values) {
            addCriterion("GOUKI_9 not in", values, "GOUKI_9");
            return (Criteria) this;
        }

        public Criteria andGOUKI_9Between(String value1, String value2) {
            addCriterion("GOUKI_9 between", value1, value2, "GOUKI_9");
            return (Criteria) this;
        }

        public Criteria andGOUKI_9NotBetween(String value1, String value2) {
            addCriterion("GOUKI_9 not between", value1, value2, "GOUKI_9");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDR_9IsNull() {
            addCriterion("SUB_ADDR_9 is null");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDR_9IsNotNull() {
            addCriterion("SUB_ADDR_9 is not null");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDR_9EqualTo(String value) {
            addCriterion("SUB_ADDR_9 =", value, "SUB_ADDR_9");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDR_9NotEqualTo(String value) {
            addCriterion("SUB_ADDR_9 <>", value, "SUB_ADDR_9");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDR_9GreaterThan(String value) {
            addCriterion("SUB_ADDR_9 >", value, "SUB_ADDR_9");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDR_9GreaterThanOrEqualTo(String value) {
            addCriterion("SUB_ADDR_9 >=", value, "SUB_ADDR_9");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDR_9LessThan(String value) {
            addCriterion("SUB_ADDR_9 <", value, "SUB_ADDR_9");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDR_9LessThanOrEqualTo(String value) {
            addCriterion("SUB_ADDR_9 <=", value, "SUB_ADDR_9");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDR_9Like(String value) {
            addCriterion("SUB_ADDR_9 like", value, "SUB_ADDR_9");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDR_9NotLike(String value) {
            addCriterion("SUB_ADDR_9 not like", value, "SUB_ADDR_9");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDR_9In(List<String> values) {
            addCriterion("SUB_ADDR_9 in", values, "SUB_ADDR_9");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDR_9NotIn(List<String> values) {
            addCriterion("SUB_ADDR_9 not in", values, "SUB_ADDR_9");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDR_9Between(String value1, String value2) {
            addCriterion("SUB_ADDR_9 between", value1, value2, "SUB_ADDR_9");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDR_9NotBetween(String value1, String value2) {
            addCriterion("SUB_ADDR_9 not between", value1, value2, "SUB_ADDR_9");
            return (Criteria) this;
        }

        public Criteria andLINE_KIND_9IsNull() {
            addCriterion("LINE_KIND_9 is null");
            return (Criteria) this;
        }

        public Criteria andLINE_KIND_9IsNotNull() {
            addCriterion("LINE_KIND_9 is not null");
            return (Criteria) this;
        }

        public Criteria andLINE_KIND_9EqualTo(String value) {
            addCriterion("LINE_KIND_9 =", value, "LINE_KIND_9");
            return (Criteria) this;
        }

        public Criteria andLINE_KIND_9NotEqualTo(String value) {
            addCriterion("LINE_KIND_9 <>", value, "LINE_KIND_9");
            return (Criteria) this;
        }

        public Criteria andLINE_KIND_9GreaterThan(String value) {
            addCriterion("LINE_KIND_9 >", value, "LINE_KIND_9");
            return (Criteria) this;
        }

        public Criteria andLINE_KIND_9GreaterThanOrEqualTo(String value) {
            addCriterion("LINE_KIND_9 >=", value, "LINE_KIND_9");
            return (Criteria) this;
        }

        public Criteria andLINE_KIND_9LessThan(String value) {
            addCriterion("LINE_KIND_9 <", value, "LINE_KIND_9");
            return (Criteria) this;
        }

        public Criteria andLINE_KIND_9LessThanOrEqualTo(String value) {
            addCriterion("LINE_KIND_9 <=", value, "LINE_KIND_9");
            return (Criteria) this;
        }

        public Criteria andLINE_KIND_9Like(String value) {
            addCriterion("LINE_KIND_9 like", value, "LINE_KIND_9");
            return (Criteria) this;
        }

        public Criteria andLINE_KIND_9NotLike(String value) {
            addCriterion("LINE_KIND_9 not like", value, "LINE_KIND_9");
            return (Criteria) this;
        }

        public Criteria andLINE_KIND_9In(List<String> values) {
            addCriterion("LINE_KIND_9 in", values, "LINE_KIND_9");
            return (Criteria) this;
        }

        public Criteria andLINE_KIND_9NotIn(List<String> values) {
            addCriterion("LINE_KIND_9 not in", values, "LINE_KIND_9");
            return (Criteria) this;
        }

        public Criteria andLINE_KIND_9Between(String value1, String value2) {
            addCriterion("LINE_KIND_9 between", value1, value2, "LINE_KIND_9");
            return (Criteria) this;
        }

        public Criteria andLINE_KIND_9NotBetween(String value1, String value2) {
            addCriterion("LINE_KIND_9 not between", value1, value2, "LINE_KIND_9");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUM_9IsNull() {
            addCriterion("CMD_SEQ_NUM_9 is null");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUM_9IsNotNull() {
            addCriterion("CMD_SEQ_NUM_9 is not null");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUM_9EqualTo(String value) {
            addCriterion("CMD_SEQ_NUM_9 =", value, "CMD_SEQ_NUM_9");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUM_9NotEqualTo(String value) {
            addCriterion("CMD_SEQ_NUM_9 <>", value, "CMD_SEQ_NUM_9");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUM_9GreaterThan(String value) {
            addCriterion("CMD_SEQ_NUM_9 >", value, "CMD_SEQ_NUM_9");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUM_9GreaterThanOrEqualTo(String value) {
            addCriterion("CMD_SEQ_NUM_9 >=", value, "CMD_SEQ_NUM_9");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUM_9LessThan(String value) {
            addCriterion("CMD_SEQ_NUM_9 <", value, "CMD_SEQ_NUM_9");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUM_9LessThanOrEqualTo(String value) {
            addCriterion("CMD_SEQ_NUM_9 <=", value, "CMD_SEQ_NUM_9");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUM_9Like(String value) {
            addCriterion("CMD_SEQ_NUM_9 like", value, "CMD_SEQ_NUM_9");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUM_9NotLike(String value) {
            addCriterion("CMD_SEQ_NUM_9 not like", value, "CMD_SEQ_NUM_9");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUM_9In(List<String> values) {
            addCriterion("CMD_SEQ_NUM_9 in", values, "CMD_SEQ_NUM_9");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUM_9NotIn(List<String> values) {
            addCriterion("CMD_SEQ_NUM_9 not in", values, "CMD_SEQ_NUM_9");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUM_9Between(String value1, String value2) {
            addCriterion("CMD_SEQ_NUM_9 between", value1, value2, "CMD_SEQ_NUM_9");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUM_9NotBetween(String value1, String value2) {
            addCriterion("CMD_SEQ_NUM_9 not between", value1, value2, "CMD_SEQ_NUM_9");
            return (Criteria) this;
        }

        public Criteria andK_INDEX_NUMIsNull() {
            addCriterion("K_INDEX_NUM is null");
            return (Criteria) this;
        }

        public Criteria andK_INDEX_NUMIsNotNull() {
            addCriterion("K_INDEX_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andK_INDEX_NUMEqualTo(String value) {
            addCriterion("K_INDEX_NUM =", value, "k_INDEX_NUM");
            return (Criteria) this;
        }

        public Criteria andK_INDEX_NUMNotEqualTo(String value) {
            addCriterion("K_INDEX_NUM <>", value, "k_INDEX_NUM");
            return (Criteria) this;
        }

        public Criteria andK_INDEX_NUMGreaterThan(String value) {
            addCriterion("K_INDEX_NUM >", value, "k_INDEX_NUM");
            return (Criteria) this;
        }

        public Criteria andK_INDEX_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("K_INDEX_NUM >=", value, "k_INDEX_NUM");
            return (Criteria) this;
        }

        public Criteria andK_INDEX_NUMLessThan(String value) {
            addCriterion("K_INDEX_NUM <", value, "k_INDEX_NUM");
            return (Criteria) this;
        }

        public Criteria andK_INDEX_NUMLessThanOrEqualTo(String value) {
            addCriterion("K_INDEX_NUM <=", value, "k_INDEX_NUM");
            return (Criteria) this;
        }

        public Criteria andK_INDEX_NUMLike(String value) {
            addCriterion("K_INDEX_NUM like", value, "k_INDEX_NUM");
            return (Criteria) this;
        }

        public Criteria andK_INDEX_NUMNotLike(String value) {
            addCriterion("K_INDEX_NUM not like", value, "k_INDEX_NUM");
            return (Criteria) this;
        }

        public Criteria andK_INDEX_NUMIn(List<String> values) {
            addCriterion("K_INDEX_NUM in", values, "k_INDEX_NUM");
            return (Criteria) this;
        }

        public Criteria andK_INDEX_NUMNotIn(List<String> values) {
            addCriterion("K_INDEX_NUM not in", values, "k_INDEX_NUM");
            return (Criteria) this;
        }

        public Criteria andK_INDEX_NUMBetween(String value1, String value2) {
            addCriterion("K_INDEX_NUM between", value1, value2, "k_INDEX_NUM");
            return (Criteria) this;
        }

        public Criteria andK_INDEX_NUMNotBetween(String value1, String value2) {
            addCriterion("K_INDEX_NUM not between", value1, value2, "k_INDEX_NUM");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPEIsNull() {
            addCriterion("MODEL_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPEIsNotNull() {
            addCriterion("MODEL_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPEEqualTo(String value) {
            addCriterion("MODEL_TYPE =", value, "MODEL_TYPE");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPENotEqualTo(String value) {
            addCriterion("MODEL_TYPE <>", value, "MODEL_TYPE");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPEGreaterThan(String value) {
            addCriterion("MODEL_TYPE >", value, "MODEL_TYPE");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPEGreaterThanOrEqualTo(String value) {
            addCriterion("MODEL_TYPE >=", value, "MODEL_TYPE");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPELessThan(String value) {
            addCriterion("MODEL_TYPE <", value, "MODEL_TYPE");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPELessThanOrEqualTo(String value) {
            addCriterion("MODEL_TYPE <=", value, "MODEL_TYPE");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPELike(String value) {
            addCriterion("MODEL_TYPE like", value, "MODEL_TYPE");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPENotLike(String value) {
            addCriterion("MODEL_TYPE not like", value, "MODEL_TYPE");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPEIn(List<String> values) {
            addCriterion("MODEL_TYPE in", values, "MODEL_TYPE");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPENotIn(List<String> values) {
            addCriterion("MODEL_TYPE not in", values, "MODEL_TYPE");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPEBetween(String value1, String value2) {
            addCriterion("MODEL_TYPE between", value1, value2, "MODEL_TYPE");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPENotBetween(String value1, String value2) {
            addCriterion("MODEL_TYPE not between", value1, value2, "MODEL_TYPE");
            return (Criteria) this;
        }

        public Criteria andVER_FWIsNull() {
            addCriterion("VER_FW is null");
            return (Criteria) this;
        }

        public Criteria andVER_FWIsNotNull() {
            addCriterion("VER_FW is not null");
            return (Criteria) this;
        }

        public Criteria andVER_FWEqualTo(String value) {
            addCriterion("VER_FW =", value, "VER_FW");
            return (Criteria) this;
        }

        public Criteria andVER_FWNotEqualTo(String value) {
            addCriterion("VER_FW <>", value, "VER_FW");
            return (Criteria) this;
        }

        public Criteria andVER_FWGreaterThan(String value) {
            addCriterion("VER_FW >", value, "VER_FW");
            return (Criteria) this;
        }

        public Criteria andVER_FWGreaterThanOrEqualTo(String value) {
            addCriterion("VER_FW >=", value, "VER_FW");
            return (Criteria) this;
        }

        public Criteria andVER_FWLessThan(String value) {
            addCriterion("VER_FW <", value, "VER_FW");
            return (Criteria) this;
        }

        public Criteria andVER_FWLessThanOrEqualTo(String value) {
            addCriterion("VER_FW <=", value, "VER_FW");
            return (Criteria) this;
        }

        public Criteria andVER_FWLike(String value) {
            addCriterion("VER_FW like", value, "VER_FW");
            return (Criteria) this;
        }

        public Criteria andVER_FWNotLike(String value) {
            addCriterion("VER_FW not like", value, "VER_FW");
            return (Criteria) this;
        }

        public Criteria andVER_FWIn(List<String> values) {
            addCriterion("VER_FW in", values, "VER_FW");
            return (Criteria) this;
        }

        public Criteria andVER_FWNotIn(List<String> values) {
            addCriterion("VER_FW not in", values, "VER_FW");
            return (Criteria) this;
        }

        public Criteria andVER_FWBetween(String value1, String value2) {
            addCriterion("VER_FW between", value1, value2, "VER_FW");
            return (Criteria) this;
        }

        public Criteria andVER_FWNotBetween(String value1, String value2) {
            addCriterion("VER_FW not between", value1, value2, "VER_FW");
            return (Criteria) this;
        }

        public Criteria andC0_MODEIsNull() {
            addCriterion("C0_MODE is null");
            return (Criteria) this;
        }

        public Criteria andC0_MODEIsNotNull() {
            addCriterion("C0_MODE is not null");
            return (Criteria) this;
        }

        public Criteria andC0_MODEEqualTo(String value) {
            addCriterion("C0_MODE =", value, "c0_MODE");
            return (Criteria) this;
        }

        public Criteria andC0_MODENotEqualTo(String value) {
            addCriterion("C0_MODE <>", value, "c0_MODE");
            return (Criteria) this;
        }

        public Criteria andC0_MODEGreaterThan(String value) {
            addCriterion("C0_MODE >", value, "c0_MODE");
            return (Criteria) this;
        }

        public Criteria andC0_MODEGreaterThanOrEqualTo(String value) {
            addCriterion("C0_MODE >=", value, "c0_MODE");
            return (Criteria) this;
        }

        public Criteria andC0_MODELessThan(String value) {
            addCriterion("C0_MODE <", value, "c0_MODE");
            return (Criteria) this;
        }

        public Criteria andC0_MODELessThanOrEqualTo(String value) {
            addCriterion("C0_MODE <=", value, "c0_MODE");
            return (Criteria) this;
        }

        public Criteria andC0_MODELike(String value) {
            addCriterion("C0_MODE like", value, "c0_MODE");
            return (Criteria) this;
        }

        public Criteria andC0_MODENotLike(String value) {
            addCriterion("C0_MODE not like", value, "c0_MODE");
            return (Criteria) this;
        }

        public Criteria andC0_MODEIn(List<String> values) {
            addCriterion("C0_MODE in", values, "c0_MODE");
            return (Criteria) this;
        }

        public Criteria andC0_MODENotIn(List<String> values) {
            addCriterion("C0_MODE not in", values, "c0_MODE");
            return (Criteria) this;
        }

        public Criteria andC0_MODEBetween(String value1, String value2) {
            addCriterion("C0_MODE between", value1, value2, "c0_MODE");
            return (Criteria) this;
        }

        public Criteria andC0_MODENotBetween(String value1, String value2) {
            addCriterion("C0_MODE not between", value1, value2, "c0_MODE");
            return (Criteria) this;
        }

        public Criteria andN0_STS_MAIN_FLGIsNull() {
            addCriterion("N0_STS_MAIN_FLG is null");
            return (Criteria) this;
        }

        public Criteria andN0_STS_MAIN_FLGIsNotNull() {
            addCriterion("N0_STS_MAIN_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andN0_STS_MAIN_FLGEqualTo(String value) {
            addCriterion("N0_STS_MAIN_FLG =", value, "n0_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andN0_STS_MAIN_FLGNotEqualTo(String value) {
            addCriterion("N0_STS_MAIN_FLG <>", value, "n0_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andN0_STS_MAIN_FLGGreaterThan(String value) {
            addCriterion("N0_STS_MAIN_FLG >", value, "n0_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andN0_STS_MAIN_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("N0_STS_MAIN_FLG >=", value, "n0_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andN0_STS_MAIN_FLGLessThan(String value) {
            addCriterion("N0_STS_MAIN_FLG <", value, "n0_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andN0_STS_MAIN_FLGLessThanOrEqualTo(String value) {
            addCriterion("N0_STS_MAIN_FLG <=", value, "n0_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andN0_STS_MAIN_FLGLike(String value) {
            addCriterion("N0_STS_MAIN_FLG like", value, "n0_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andN0_STS_MAIN_FLGNotLike(String value) {
            addCriterion("N0_STS_MAIN_FLG not like", value, "n0_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andN0_STS_MAIN_FLGIn(List<String> values) {
            addCriterion("N0_STS_MAIN_FLG in", values, "n0_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andN0_STS_MAIN_FLGNotIn(List<String> values) {
            addCriterion("N0_STS_MAIN_FLG not in", values, "n0_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andN0_STS_MAIN_FLGBetween(String value1, String value2) {
            addCriterion("N0_STS_MAIN_FLG between", value1, value2, "n0_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andN0_STS_MAIN_FLGNotBetween(String value1, String value2) {
            addCriterion("N0_STS_MAIN_FLG not between", value1, value2, "n0_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_MAIN_FLGIsNull() {
            addCriterion("DN0_STS_MAIN_FLG is null");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_MAIN_FLGIsNotNull() {
            addCriterion("DN0_STS_MAIN_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_MAIN_FLGEqualTo(String value) {
            addCriterion("DN0_STS_MAIN_FLG =", value, "DN0_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_MAIN_FLGNotEqualTo(String value) {
            addCriterion("DN0_STS_MAIN_FLG <>", value, "DN0_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_MAIN_FLGGreaterThan(String value) {
            addCriterion("DN0_STS_MAIN_FLG >", value, "DN0_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_MAIN_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("DN0_STS_MAIN_FLG >=", value, "DN0_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_MAIN_FLGLessThan(String value) {
            addCriterion("DN0_STS_MAIN_FLG <", value, "DN0_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_MAIN_FLGLessThanOrEqualTo(String value) {
            addCriterion("DN0_STS_MAIN_FLG <=", value, "DN0_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_MAIN_FLGLike(String value) {
            addCriterion("DN0_STS_MAIN_FLG like", value, "DN0_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_MAIN_FLGNotLike(String value) {
            addCriterion("DN0_STS_MAIN_FLG not like", value, "DN0_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_MAIN_FLGIn(List<String> values) {
            addCriterion("DN0_STS_MAIN_FLG in", values, "DN0_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_MAIN_FLGNotIn(List<String> values) {
            addCriterion("DN0_STS_MAIN_FLG not in", values, "DN0_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_MAIN_FLGBetween(String value1, String value2) {
            addCriterion("DN0_STS_MAIN_FLG between", value1, value2, "DN0_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_MAIN_FLGNotBetween(String value1, String value2) {
            addCriterion("DN0_STS_MAIN_FLG not between", value1, value2, "DN0_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andKN_STS_MAIN_FLGIsNull() {
            addCriterion("KN_STS_MAIN_FLG is null");
            return (Criteria) this;
        }

        public Criteria andKN_STS_MAIN_FLGIsNotNull() {
            addCriterion("KN_STS_MAIN_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andKN_STS_MAIN_FLGEqualTo(String value) {
            addCriterion("KN_STS_MAIN_FLG =", value, "KN_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andKN_STS_MAIN_FLGNotEqualTo(String value) {
            addCriterion("KN_STS_MAIN_FLG <>", value, "KN_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andKN_STS_MAIN_FLGGreaterThan(String value) {
            addCriterion("KN_STS_MAIN_FLG >", value, "KN_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andKN_STS_MAIN_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("KN_STS_MAIN_FLG >=", value, "KN_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andKN_STS_MAIN_FLGLessThan(String value) {
            addCriterion("KN_STS_MAIN_FLG <", value, "KN_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andKN_STS_MAIN_FLGLessThanOrEqualTo(String value) {
            addCriterion("KN_STS_MAIN_FLG <=", value, "KN_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andKN_STS_MAIN_FLGLike(String value) {
            addCriterion("KN_STS_MAIN_FLG like", value, "KN_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andKN_STS_MAIN_FLGNotLike(String value) {
            addCriterion("KN_STS_MAIN_FLG not like", value, "KN_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andKN_STS_MAIN_FLGIn(List<String> values) {
            addCriterion("KN_STS_MAIN_FLG in", values, "KN_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andKN_STS_MAIN_FLGNotIn(List<String> values) {
            addCriterion("KN_STS_MAIN_FLG not in", values, "KN_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andKN_STS_MAIN_FLGBetween(String value1, String value2) {
            addCriterion("KN_STS_MAIN_FLG between", value1, value2, "KN_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andKN_STS_MAIN_FLGNotBetween(String value1, String value2) {
            addCriterion("KN_STS_MAIN_FLG not between", value1, value2, "KN_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andN0_STS_SUB_ADDR_FLGIsNull() {
            addCriterion("N0_STS_SUB_ADDR_FLG is null");
            return (Criteria) this;
        }

        public Criteria andN0_STS_SUB_ADDR_FLGIsNotNull() {
            addCriterion("N0_STS_SUB_ADDR_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andN0_STS_SUB_ADDR_FLGEqualTo(String value) {
            addCriterion("N0_STS_SUB_ADDR_FLG =", value, "n0_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andN0_STS_SUB_ADDR_FLGNotEqualTo(String value) {
            addCriterion("N0_STS_SUB_ADDR_FLG <>", value, "n0_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andN0_STS_SUB_ADDR_FLGGreaterThan(String value) {
            addCriterion("N0_STS_SUB_ADDR_FLG >", value, "n0_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andN0_STS_SUB_ADDR_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("N0_STS_SUB_ADDR_FLG >=", value, "n0_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andN0_STS_SUB_ADDR_FLGLessThan(String value) {
            addCriterion("N0_STS_SUB_ADDR_FLG <", value, "n0_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andN0_STS_SUB_ADDR_FLGLessThanOrEqualTo(String value) {
            addCriterion("N0_STS_SUB_ADDR_FLG <=", value, "n0_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andN0_STS_SUB_ADDR_FLGLike(String value) {
            addCriterion("N0_STS_SUB_ADDR_FLG like", value, "n0_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andN0_STS_SUB_ADDR_FLGNotLike(String value) {
            addCriterion("N0_STS_SUB_ADDR_FLG not like", value, "n0_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andN0_STS_SUB_ADDR_FLGIn(List<String> values) {
            addCriterion("N0_STS_SUB_ADDR_FLG in", values, "n0_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andN0_STS_SUB_ADDR_FLGNotIn(List<String> values) {
            addCriterion("N0_STS_SUB_ADDR_FLG not in", values, "n0_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andN0_STS_SUB_ADDR_FLGBetween(String value1, String value2) {
            addCriterion("N0_STS_SUB_ADDR_FLG between", value1, value2, "n0_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andN0_STS_SUB_ADDR_FLGNotBetween(String value1, String value2) {
            addCriterion("N0_STS_SUB_ADDR_FLG not between", value1, value2, "n0_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_SUB_ADDR_FLGIsNull() {
            addCriterion("DN0_STS_SUB_ADDR_FLG is null");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_SUB_ADDR_FLGIsNotNull() {
            addCriterion("DN0_STS_SUB_ADDR_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_SUB_ADDR_FLGEqualTo(String value) {
            addCriterion("DN0_STS_SUB_ADDR_FLG =", value, "DN0_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_SUB_ADDR_FLGNotEqualTo(String value) {
            addCriterion("DN0_STS_SUB_ADDR_FLG <>", value, "DN0_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_SUB_ADDR_FLGGreaterThan(String value) {
            addCriterion("DN0_STS_SUB_ADDR_FLG >", value, "DN0_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_SUB_ADDR_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("DN0_STS_SUB_ADDR_FLG >=", value, "DN0_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_SUB_ADDR_FLGLessThan(String value) {
            addCriterion("DN0_STS_SUB_ADDR_FLG <", value, "DN0_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_SUB_ADDR_FLGLessThanOrEqualTo(String value) {
            addCriterion("DN0_STS_SUB_ADDR_FLG <=", value, "DN0_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_SUB_ADDR_FLGLike(String value) {
            addCriterion("DN0_STS_SUB_ADDR_FLG like", value, "DN0_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_SUB_ADDR_FLGNotLike(String value) {
            addCriterion("DN0_STS_SUB_ADDR_FLG not like", value, "DN0_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_SUB_ADDR_FLGIn(List<String> values) {
            addCriterion("DN0_STS_SUB_ADDR_FLG in", values, "DN0_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_SUB_ADDR_FLGNotIn(List<String> values) {
            addCriterion("DN0_STS_SUB_ADDR_FLG not in", values, "DN0_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_SUB_ADDR_FLGBetween(String value1, String value2) {
            addCriterion("DN0_STS_SUB_ADDR_FLG between", value1, value2, "DN0_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_SUB_ADDR_FLGNotBetween(String value1, String value2) {
            addCriterion("DN0_STS_SUB_ADDR_FLG not between", value1, value2, "DN0_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andKN_STS_SUB_ADDR_FLGIsNull() {
            addCriterion("KN_STS_SUB_ADDR_FLG is null");
            return (Criteria) this;
        }

        public Criteria andKN_STS_SUB_ADDR_FLGIsNotNull() {
            addCriterion("KN_STS_SUB_ADDR_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andKN_STS_SUB_ADDR_FLGEqualTo(String value) {
            addCriterion("KN_STS_SUB_ADDR_FLG =", value, "KN_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andKN_STS_SUB_ADDR_FLGNotEqualTo(String value) {
            addCriterion("KN_STS_SUB_ADDR_FLG <>", value, "KN_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andKN_STS_SUB_ADDR_FLGGreaterThan(String value) {
            addCriterion("KN_STS_SUB_ADDR_FLG >", value, "KN_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andKN_STS_SUB_ADDR_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("KN_STS_SUB_ADDR_FLG >=", value, "KN_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andKN_STS_SUB_ADDR_FLGLessThan(String value) {
            addCriterion("KN_STS_SUB_ADDR_FLG <", value, "KN_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andKN_STS_SUB_ADDR_FLGLessThanOrEqualTo(String value) {
            addCriterion("KN_STS_SUB_ADDR_FLG <=", value, "KN_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andKN_STS_SUB_ADDR_FLGLike(String value) {
            addCriterion("KN_STS_SUB_ADDR_FLG like", value, "KN_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andKN_STS_SUB_ADDR_FLGNotLike(String value) {
            addCriterion("KN_STS_SUB_ADDR_FLG not like", value, "KN_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andKN_STS_SUB_ADDR_FLGIn(List<String> values) {
            addCriterion("KN_STS_SUB_ADDR_FLG in", values, "KN_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andKN_STS_SUB_ADDR_FLGNotIn(List<String> values) {
            addCriterion("KN_STS_SUB_ADDR_FLG not in", values, "KN_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andKN_STS_SUB_ADDR_FLGBetween(String value1, String value2) {
            addCriterion("KN_STS_SUB_ADDR_FLG between", value1, value2, "KN_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andKN_STS_SUB_ADDR_FLGNotBetween(String value1, String value2) {
            addCriterion("KN_STS_SUB_ADDR_FLG not between", value1, value2, "KN_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMIsNull() {
            addCriterion("DEV_NUM is null");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMIsNotNull() {
            addCriterion("DEV_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMEqualTo(String value) {
            addCriterion("DEV_NUM =", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMNotEqualTo(String value) {
            addCriterion("DEV_NUM <>", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMGreaterThan(String value) {
            addCriterion("DEV_NUM >", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("DEV_NUM >=", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMLessThan(String value) {
            addCriterion("DEV_NUM <", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMLessThanOrEqualTo(String value) {
            addCriterion("DEV_NUM <=", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMLike(String value) {
            addCriterion("DEV_NUM like", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMNotLike(String value) {
            addCriterion("DEV_NUM not like", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMIn(List<String> values) {
            addCriterion("DEV_NUM in", values, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMNotIn(List<String> values) {
            addCriterion("DEV_NUM not in", values, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMBetween(String value1, String value2) {
            addCriterion("DEV_NUM between", value1, value2, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMNotBetween(String value1, String value2) {
            addCriterion("DEV_NUM not between", value1, value2, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMIsNull() {
            addCriterion("DEV_NM is null");
            return (Criteria) this;
        }

        public Criteria andDEV_NMIsNotNull() {
            addCriterion("DEV_NM is not null");
            return (Criteria) this;
        }

        public Criteria andDEV_NMEqualTo(String value) {
            addCriterion("DEV_NM =", value, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMNotEqualTo(String value) {
            addCriterion("DEV_NM <>", value, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMGreaterThan(String value) {
            addCriterion("DEV_NM >", value, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMGreaterThanOrEqualTo(String value) {
            addCriterion("DEV_NM >=", value, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMLessThan(String value) {
            addCriterion("DEV_NM <", value, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMLessThanOrEqualTo(String value) {
            addCriterion("DEV_NM <=", value, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMLike(String value) {
            addCriterion("DEV_NM like", value, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMNotLike(String value) {
            addCriterion("DEV_NM not like", value, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMIn(List<String> values) {
            addCriterion("DEV_NM in", values, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMNotIn(List<String> values) {
            addCriterion("DEV_NM not in", values, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMBetween(String value1, String value2) {
            addCriterion("DEV_NM between", value1, value2, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMNotBetween(String value1, String value2) {
            addCriterion("DEV_NM not between", value1, value2, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andRM_KINDIsNull() {
            addCriterion("RM_KIND is null");
            return (Criteria) this;
        }

        public Criteria andRM_KINDIsNotNull() {
            addCriterion("RM_KIND is not null");
            return (Criteria) this;
        }

        public Criteria andRM_KINDEqualTo(String value) {
            addCriterion("RM_KIND =", value, "RM_KIND");
            return (Criteria) this;
        }

        public Criteria andRM_KINDNotEqualTo(String value) {
            addCriterion("RM_KIND <>", value, "RM_KIND");
            return (Criteria) this;
        }

        public Criteria andRM_KINDGreaterThan(String value) {
            addCriterion("RM_KIND >", value, "RM_KIND");
            return (Criteria) this;
        }

        public Criteria andRM_KINDGreaterThanOrEqualTo(String value) {
            addCriterion("RM_KIND >=", value, "RM_KIND");
            return (Criteria) this;
        }

        public Criteria andRM_KINDLessThan(String value) {
            addCriterion("RM_KIND <", value, "RM_KIND");
            return (Criteria) this;
        }

        public Criteria andRM_KINDLessThanOrEqualTo(String value) {
            addCriterion("RM_KIND <=", value, "RM_KIND");
            return (Criteria) this;
        }

        public Criteria andRM_KINDLike(String value) {
            addCriterion("RM_KIND like", value, "RM_KIND");
            return (Criteria) this;
        }

        public Criteria andRM_KINDNotLike(String value) {
            addCriterion("RM_KIND not like", value, "RM_KIND");
            return (Criteria) this;
        }

        public Criteria andRM_KINDIn(List<String> values) {
            addCriterion("RM_KIND in", values, "RM_KIND");
            return (Criteria) this;
        }

        public Criteria andRM_KINDNotIn(List<String> values) {
            addCriterion("RM_KIND not in", values, "RM_KIND");
            return (Criteria) this;
        }

        public Criteria andRM_KINDBetween(String value1, String value2) {
            addCriterion("RM_KIND between", value1, value2, "RM_KIND");
            return (Criteria) this;
        }

        public Criteria andRM_KINDNotBetween(String value1, String value2) {
            addCriterion("RM_KIND not between", value1, value2, "RM_KIND");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1IsNull() {
            addCriterion("SIG_KIND_1 is null");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1IsNotNull() {
            addCriterion("SIG_KIND_1 is not null");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1EqualTo(String value) {
            addCriterion("SIG_KIND_1 =", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1NotEqualTo(String value) {
            addCriterion("SIG_KIND_1 <>", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1GreaterThan(String value) {
            addCriterion("SIG_KIND_1 >", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1GreaterThanOrEqualTo(String value) {
            addCriterion("SIG_KIND_1 >=", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1LessThan(String value) {
            addCriterion("SIG_KIND_1 <", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1LessThanOrEqualTo(String value) {
            addCriterion("SIG_KIND_1 <=", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1Like(String value) {
            addCriterion("SIG_KIND_1 like", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1NotLike(String value) {
            addCriterion("SIG_KIND_1 not like", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1In(List<String> values) {
            addCriterion("SIG_KIND_1 in", values, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1NotIn(List<String> values) {
            addCriterion("SIG_KIND_1 not in", values, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1Between(String value1, String value2) {
            addCriterion("SIG_KIND_1 between", value1, value2, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1NotBetween(String value1, String value2) {
            addCriterion("SIG_KIND_1 not between", value1, value2, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2IsNull() {
            addCriterion("SIG_KIND_2 is null");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2IsNotNull() {
            addCriterion("SIG_KIND_2 is not null");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2EqualTo(String value) {
            addCriterion("SIG_KIND_2 =", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2NotEqualTo(String value) {
            addCriterion("SIG_KIND_2 <>", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2GreaterThan(String value) {
            addCriterion("SIG_KIND_2 >", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2GreaterThanOrEqualTo(String value) {
            addCriterion("SIG_KIND_2 >=", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2LessThan(String value) {
            addCriterion("SIG_KIND_2 <", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2LessThanOrEqualTo(String value) {
            addCriterion("SIG_KIND_2 <=", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2Like(String value) {
            addCriterion("SIG_KIND_2 like", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2NotLike(String value) {
            addCriterion("SIG_KIND_2 not like", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2In(List<String> values) {
            addCriterion("SIG_KIND_2 in", values, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2NotIn(List<String> values) {
            addCriterion("SIG_KIND_2 not in", values, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2Between(String value1, String value2) {
            addCriterion("SIG_KIND_2 between", value1, value2, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2NotBetween(String value1, String value2) {
            addCriterion("SIG_KIND_2 not between", value1, value2, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_CODEIsNull() {
            addCriterion("SIG_CODE is null");
            return (Criteria) this;
        }

        public Criteria andSIG_CODEIsNotNull() {
            addCriterion("SIG_CODE is not null");
            return (Criteria) this;
        }

        public Criteria andSIG_CODEEqualTo(String value) {
            addCriterion("SIG_CODE =", value, "SIG_CODE");
            return (Criteria) this;
        }

        public Criteria andSIG_CODENotEqualTo(String value) {
            addCriterion("SIG_CODE <>", value, "SIG_CODE");
            return (Criteria) this;
        }

        public Criteria andSIG_CODEGreaterThan(String value) {
            addCriterion("SIG_CODE >", value, "SIG_CODE");
            return (Criteria) this;
        }

        public Criteria andSIG_CODEGreaterThanOrEqualTo(String value) {
            addCriterion("SIG_CODE >=", value, "SIG_CODE");
            return (Criteria) this;
        }

        public Criteria andSIG_CODELessThan(String value) {
            addCriterion("SIG_CODE <", value, "SIG_CODE");
            return (Criteria) this;
        }

        public Criteria andSIG_CODELessThanOrEqualTo(String value) {
            addCriterion("SIG_CODE <=", value, "SIG_CODE");
            return (Criteria) this;
        }

        public Criteria andSIG_CODELike(String value) {
            addCriterion("SIG_CODE like", value, "SIG_CODE");
            return (Criteria) this;
        }

        public Criteria andSIG_CODENotLike(String value) {
            addCriterion("SIG_CODE not like", value, "SIG_CODE");
            return (Criteria) this;
        }

        public Criteria andSIG_CODEIn(List<String> values) {
            addCriterion("SIG_CODE in", values, "SIG_CODE");
            return (Criteria) this;
        }

        public Criteria andSIG_CODENotIn(List<String> values) {
            addCriterion("SIG_CODE not in", values, "SIG_CODE");
            return (Criteria) this;
        }

        public Criteria andSIG_CODEBetween(String value1, String value2) {
            addCriterion("SIG_CODE between", value1, value2, "SIG_CODE");
            return (Criteria) this;
        }

        public Criteria andSIG_CODENotBetween(String value1, String value2) {
            addCriterion("SIG_CODE not between", value1, value2, "SIG_CODE");
            return (Criteria) this;
        }

        public Criteria andCARD_FRMT_IDIsNull() {
            addCriterion("CARD_FRMT_ID is null");
            return (Criteria) this;
        }

        public Criteria andCARD_FRMT_IDIsNotNull() {
            addCriterion("CARD_FRMT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andCARD_FRMT_IDEqualTo(String value) {
            addCriterion("CARD_FRMT_ID =", value, "CARD_FRMT_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_FRMT_IDNotEqualTo(String value) {
            addCriterion("CARD_FRMT_ID <>", value, "CARD_FRMT_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_FRMT_IDGreaterThan(String value) {
            addCriterion("CARD_FRMT_ID >", value, "CARD_FRMT_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_FRMT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("CARD_FRMT_ID >=", value, "CARD_FRMT_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_FRMT_IDLessThan(String value) {
            addCriterion("CARD_FRMT_ID <", value, "CARD_FRMT_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_FRMT_IDLessThanOrEqualTo(String value) {
            addCriterion("CARD_FRMT_ID <=", value, "CARD_FRMT_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_FRMT_IDLike(String value) {
            addCriterion("CARD_FRMT_ID like", value, "CARD_FRMT_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_FRMT_IDNotLike(String value) {
            addCriterion("CARD_FRMT_ID not like", value, "CARD_FRMT_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_FRMT_IDIn(List<String> values) {
            addCriterion("CARD_FRMT_ID in", values, "CARD_FRMT_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_FRMT_IDNotIn(List<String> values) {
            addCriterion("CARD_FRMT_ID not in", values, "CARD_FRMT_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_FRMT_IDBetween(String value1, String value2) {
            addCriterion("CARD_FRMT_ID between", value1, value2, "CARD_FRMT_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_FRMT_IDNotBetween(String value1, String value2) {
            addCriterion("CARD_FRMT_ID not between", value1, value2, "CARD_FRMT_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_KOTEI_IDIsNull() {
            addCriterion("CARD_KOTEI_ID is null");
            return (Criteria) this;
        }

        public Criteria andCARD_KOTEI_IDIsNotNull() {
            addCriterion("CARD_KOTEI_ID is not null");
            return (Criteria) this;
        }

        public Criteria andCARD_KOTEI_IDEqualTo(String value) {
            addCriterion("CARD_KOTEI_ID =", value, "CARD_KOTEI_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_KOTEI_IDNotEqualTo(String value) {
            addCriterion("CARD_KOTEI_ID <>", value, "CARD_KOTEI_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_KOTEI_IDGreaterThan(String value) {
            addCriterion("CARD_KOTEI_ID >", value, "CARD_KOTEI_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_KOTEI_IDGreaterThanOrEqualTo(String value) {
            addCriterion("CARD_KOTEI_ID >=", value, "CARD_KOTEI_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_KOTEI_IDLessThan(String value) {
            addCriterion("CARD_KOTEI_ID <", value, "CARD_KOTEI_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_KOTEI_IDLessThanOrEqualTo(String value) {
            addCriterion("CARD_KOTEI_ID <=", value, "CARD_KOTEI_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_KOTEI_IDLike(String value) {
            addCriterion("CARD_KOTEI_ID like", value, "CARD_KOTEI_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_KOTEI_IDNotLike(String value) {
            addCriterion("CARD_KOTEI_ID not like", value, "CARD_KOTEI_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_KOTEI_IDIn(List<String> values) {
            addCriterion("CARD_KOTEI_ID in", values, "CARD_KOTEI_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_KOTEI_IDNotIn(List<String> values) {
            addCriterion("CARD_KOTEI_ID not in", values, "CARD_KOTEI_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_KOTEI_IDBetween(String value1, String value2) {
            addCriterion("CARD_KOTEI_ID between", value1, value2, "CARD_KOTEI_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_KOTEI_IDNotBetween(String value1, String value2) {
            addCriterion("CARD_KOTEI_ID not between", value1, value2, "CARD_KOTEI_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_KAHEN_IDIsNull() {
            addCriterion("CARD_KAHEN_ID is null");
            return (Criteria) this;
        }

        public Criteria andCARD_KAHEN_IDIsNotNull() {
            addCriterion("CARD_KAHEN_ID is not null");
            return (Criteria) this;
        }

        public Criteria andCARD_KAHEN_IDEqualTo(String value) {
            addCriterion("CARD_KAHEN_ID =", value, "CARD_KAHEN_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_KAHEN_IDNotEqualTo(String value) {
            addCriterion("CARD_KAHEN_ID <>", value, "CARD_KAHEN_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_KAHEN_IDGreaterThan(String value) {
            addCriterion("CARD_KAHEN_ID >", value, "CARD_KAHEN_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_KAHEN_IDGreaterThanOrEqualTo(String value) {
            addCriterion("CARD_KAHEN_ID >=", value, "CARD_KAHEN_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_KAHEN_IDLessThan(String value) {
            addCriterion("CARD_KAHEN_ID <", value, "CARD_KAHEN_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_KAHEN_IDLessThanOrEqualTo(String value) {
            addCriterion("CARD_KAHEN_ID <=", value, "CARD_KAHEN_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_KAHEN_IDLike(String value) {
            addCriterion("CARD_KAHEN_ID like", value, "CARD_KAHEN_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_KAHEN_IDNotLike(String value) {
            addCriterion("CARD_KAHEN_ID not like", value, "CARD_KAHEN_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_KAHEN_IDIn(List<String> values) {
            addCriterion("CARD_KAHEN_ID in", values, "CARD_KAHEN_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_KAHEN_IDNotIn(List<String> values) {
            addCriterion("CARD_KAHEN_ID not in", values, "CARD_KAHEN_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_KAHEN_IDBetween(String value1, String value2) {
            addCriterion("CARD_KAHEN_ID between", value1, value2, "CARD_KAHEN_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_KAHEN_IDNotBetween(String value1, String value2) {
            addCriterion("CARD_KAHEN_ID not between", value1, value2, "CARD_KAHEN_ID");
            return (Criteria) this;
        }

        public Criteria andVIDEO_LINK_FLGIsNull() {
            addCriterion("VIDEO_LINK_FLG is null");
            return (Criteria) this;
        }

        public Criteria andVIDEO_LINK_FLGIsNotNull() {
            addCriterion("VIDEO_LINK_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andVIDEO_LINK_FLGEqualTo(String value) {
            addCriterion("VIDEO_LINK_FLG =", value, "VIDEO_LINK_FLG");
            return (Criteria) this;
        }

        public Criteria andVIDEO_LINK_FLGNotEqualTo(String value) {
            addCriterion("VIDEO_LINK_FLG <>", value, "VIDEO_LINK_FLG");
            return (Criteria) this;
        }

        public Criteria andVIDEO_LINK_FLGGreaterThan(String value) {
            addCriterion("VIDEO_LINK_FLG >", value, "VIDEO_LINK_FLG");
            return (Criteria) this;
        }

        public Criteria andVIDEO_LINK_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("VIDEO_LINK_FLG >=", value, "VIDEO_LINK_FLG");
            return (Criteria) this;
        }

        public Criteria andVIDEO_LINK_FLGLessThan(String value) {
            addCriterion("VIDEO_LINK_FLG <", value, "VIDEO_LINK_FLG");
            return (Criteria) this;
        }

        public Criteria andVIDEO_LINK_FLGLessThanOrEqualTo(String value) {
            addCriterion("VIDEO_LINK_FLG <=", value, "VIDEO_LINK_FLG");
            return (Criteria) this;
        }

        public Criteria andVIDEO_LINK_FLGLike(String value) {
            addCriterion("VIDEO_LINK_FLG like", value, "VIDEO_LINK_FLG");
            return (Criteria) this;
        }

        public Criteria andVIDEO_LINK_FLGNotLike(String value) {
            addCriterion("VIDEO_LINK_FLG not like", value, "VIDEO_LINK_FLG");
            return (Criteria) this;
        }

        public Criteria andVIDEO_LINK_FLGIn(List<String> values) {
            addCriterion("VIDEO_LINK_FLG in", values, "VIDEO_LINK_FLG");
            return (Criteria) this;
        }

        public Criteria andVIDEO_LINK_FLGNotIn(List<String> values) {
            addCriterion("VIDEO_LINK_FLG not in", values, "VIDEO_LINK_FLG");
            return (Criteria) this;
        }

        public Criteria andVIDEO_LINK_FLGBetween(String value1, String value2) {
            addCriterion("VIDEO_LINK_FLG between", value1, value2, "VIDEO_LINK_FLG");
            return (Criteria) this;
        }

        public Criteria andVIDEO_LINK_FLGNotBetween(String value1, String value2) {
            addCriterion("VIDEO_LINK_FLG not between", value1, value2, "VIDEO_LINK_FLG");
            return (Criteria) this;
        }

        public Criteria andVIDEO_DEV_NUMIsNull() {
            addCriterion("VIDEO_DEV_NUM is null");
            return (Criteria) this;
        }

        public Criteria andVIDEO_DEV_NUMIsNotNull() {
            addCriterion("VIDEO_DEV_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andVIDEO_DEV_NUMEqualTo(String value) {
            addCriterion("VIDEO_DEV_NUM =", value, "VIDEO_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andVIDEO_DEV_NUMNotEqualTo(String value) {
            addCriterion("VIDEO_DEV_NUM <>", value, "VIDEO_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andVIDEO_DEV_NUMGreaterThan(String value) {
            addCriterion("VIDEO_DEV_NUM >", value, "VIDEO_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andVIDEO_DEV_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("VIDEO_DEV_NUM >=", value, "VIDEO_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andVIDEO_DEV_NUMLessThan(String value) {
            addCriterion("VIDEO_DEV_NUM <", value, "VIDEO_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andVIDEO_DEV_NUMLessThanOrEqualTo(String value) {
            addCriterion("VIDEO_DEV_NUM <=", value, "VIDEO_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andVIDEO_DEV_NUMLike(String value) {
            addCriterion("VIDEO_DEV_NUM like", value, "VIDEO_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andVIDEO_DEV_NUMNotLike(String value) {
            addCriterion("VIDEO_DEV_NUM not like", value, "VIDEO_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andVIDEO_DEV_NUMIn(List<String> values) {
            addCriterion("VIDEO_DEV_NUM in", values, "VIDEO_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andVIDEO_DEV_NUMNotIn(List<String> values) {
            addCriterion("VIDEO_DEV_NUM not in", values, "VIDEO_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andVIDEO_DEV_NUMBetween(String value1, String value2) {
            addCriterion("VIDEO_DEV_NUM between", value1, value2, "VIDEO_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andVIDEO_DEV_NUMNotBetween(String value1, String value2) {
            addCriterion("VIDEO_DEV_NUM not between", value1, value2, "VIDEO_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andCAMERA_NOIsNull() {
            addCriterion("CAMERA_NO is null");
            return (Criteria) this;
        }

        public Criteria andCAMERA_NOIsNotNull() {
            addCriterion("CAMERA_NO is not null");
            return (Criteria) this;
        }

        public Criteria andCAMERA_NOEqualTo(String value) {
            addCriterion("CAMERA_NO =", value, "CAMERA_NO");
            return (Criteria) this;
        }

        public Criteria andCAMERA_NONotEqualTo(String value) {
            addCriterion("CAMERA_NO <>", value, "CAMERA_NO");
            return (Criteria) this;
        }

        public Criteria andCAMERA_NOGreaterThan(String value) {
            addCriterion("CAMERA_NO >", value, "CAMERA_NO");
            return (Criteria) this;
        }

        public Criteria andCAMERA_NOGreaterThanOrEqualTo(String value) {
            addCriterion("CAMERA_NO >=", value, "CAMERA_NO");
            return (Criteria) this;
        }

        public Criteria andCAMERA_NOLessThan(String value) {
            addCriterion("CAMERA_NO <", value, "CAMERA_NO");
            return (Criteria) this;
        }

        public Criteria andCAMERA_NOLessThanOrEqualTo(String value) {
            addCriterion("CAMERA_NO <=", value, "CAMERA_NO");
            return (Criteria) this;
        }

        public Criteria andCAMERA_NOLike(String value) {
            addCriterion("CAMERA_NO like", value, "CAMERA_NO");
            return (Criteria) this;
        }

        public Criteria andCAMERA_NONotLike(String value) {
            addCriterion("CAMERA_NO not like", value, "CAMERA_NO");
            return (Criteria) this;
        }

        public Criteria andCAMERA_NOIn(List<String> values) {
            addCriterion("CAMERA_NO in", values, "CAMERA_NO");
            return (Criteria) this;
        }

        public Criteria andCAMERA_NONotIn(List<String> values) {
            addCriterion("CAMERA_NO not in", values, "CAMERA_NO");
            return (Criteria) this;
        }

        public Criteria andCAMERA_NOBetween(String value1, String value2) {
            addCriterion("CAMERA_NO between", value1, value2, "CAMERA_NO");
            return (Criteria) this;
        }

        public Criteria andCAMERA_NONotBetween(String value1, String value2) {
            addCriterion("CAMERA_NO not between", value1, value2, "CAMERA_NO");
            return (Criteria) this;
        }

        public Criteria andVIDEO_FILE_NAMEIsNull() {
            addCriterion("VIDEO_FILE_NAME is null");
            return (Criteria) this;
        }

        public Criteria andVIDEO_FILE_NAMEIsNotNull() {
            addCriterion("VIDEO_FILE_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andVIDEO_FILE_NAMEEqualTo(String value) {
            addCriterion("VIDEO_FILE_NAME =", value, "VIDEO_FILE_NAME");
            return (Criteria) this;
        }

        public Criteria andVIDEO_FILE_NAMENotEqualTo(String value) {
            addCriterion("VIDEO_FILE_NAME <>", value, "VIDEO_FILE_NAME");
            return (Criteria) this;
        }

        public Criteria andVIDEO_FILE_NAMEGreaterThan(String value) {
            addCriterion("VIDEO_FILE_NAME >", value, "VIDEO_FILE_NAME");
            return (Criteria) this;
        }

        public Criteria andVIDEO_FILE_NAMEGreaterThanOrEqualTo(String value) {
            addCriterion("VIDEO_FILE_NAME >=", value, "VIDEO_FILE_NAME");
            return (Criteria) this;
        }

        public Criteria andVIDEO_FILE_NAMELessThan(String value) {
            addCriterion("VIDEO_FILE_NAME <", value, "VIDEO_FILE_NAME");
            return (Criteria) this;
        }

        public Criteria andVIDEO_FILE_NAMELessThanOrEqualTo(String value) {
            addCriterion("VIDEO_FILE_NAME <=", value, "VIDEO_FILE_NAME");
            return (Criteria) this;
        }

        public Criteria andVIDEO_FILE_NAMELike(String value) {
            addCriterion("VIDEO_FILE_NAME like", value, "VIDEO_FILE_NAME");
            return (Criteria) this;
        }

        public Criteria andVIDEO_FILE_NAMENotLike(String value) {
            addCriterion("VIDEO_FILE_NAME not like", value, "VIDEO_FILE_NAME");
            return (Criteria) this;
        }

        public Criteria andVIDEO_FILE_NAMEIn(List<String> values) {
            addCriterion("VIDEO_FILE_NAME in", values, "VIDEO_FILE_NAME");
            return (Criteria) this;
        }

        public Criteria andVIDEO_FILE_NAMENotIn(List<String> values) {
            addCriterion("VIDEO_FILE_NAME not in", values, "VIDEO_FILE_NAME");
            return (Criteria) this;
        }

        public Criteria andVIDEO_FILE_NAMEBetween(String value1, String value2) {
            addCriterion("VIDEO_FILE_NAME between", value1, value2, "VIDEO_FILE_NAME");
            return (Criteria) this;
        }

        public Criteria andVIDEO_FILE_NAMENotBetween(String value1, String value2) {
            addCriterion("VIDEO_FILE_NAME not between", value1, value2, "VIDEO_FILE_NAME");
            return (Criteria) this;
        }

        public Criteria andFRAME_RATEIsNull() {
            addCriterion("FRAME_RATE is null");
            return (Criteria) this;
        }

        public Criteria andFRAME_RATEIsNotNull() {
            addCriterion("FRAME_RATE is not null");
            return (Criteria) this;
        }

        public Criteria andFRAME_RATEEqualTo(String value) {
            addCriterion("FRAME_RATE =", value, "FRAME_RATE");
            return (Criteria) this;
        }

        public Criteria andFRAME_RATENotEqualTo(String value) {
            addCriterion("FRAME_RATE <>", value, "FRAME_RATE");
            return (Criteria) this;
        }

        public Criteria andFRAME_RATEGreaterThan(String value) {
            addCriterion("FRAME_RATE >", value, "FRAME_RATE");
            return (Criteria) this;
        }

        public Criteria andFRAME_RATEGreaterThanOrEqualTo(String value) {
            addCriterion("FRAME_RATE >=", value, "FRAME_RATE");
            return (Criteria) this;
        }

        public Criteria andFRAME_RATELessThan(String value) {
            addCriterion("FRAME_RATE <", value, "FRAME_RATE");
            return (Criteria) this;
        }

        public Criteria andFRAME_RATELessThanOrEqualTo(String value) {
            addCriterion("FRAME_RATE <=", value, "FRAME_RATE");
            return (Criteria) this;
        }

        public Criteria andFRAME_RATELike(String value) {
            addCriterion("FRAME_RATE like", value, "FRAME_RATE");
            return (Criteria) this;
        }

        public Criteria andFRAME_RATENotLike(String value) {
            addCriterion("FRAME_RATE not like", value, "FRAME_RATE");
            return (Criteria) this;
        }

        public Criteria andFRAME_RATEIn(List<String> values) {
            addCriterion("FRAME_RATE in", values, "FRAME_RATE");
            return (Criteria) this;
        }

        public Criteria andFRAME_RATENotIn(List<String> values) {
            addCriterion("FRAME_RATE not in", values, "FRAME_RATE");
            return (Criteria) this;
        }

        public Criteria andFRAME_RATEBetween(String value1, String value2) {
            addCriterion("FRAME_RATE between", value1, value2, "FRAME_RATE");
            return (Criteria) this;
        }

        public Criteria andFRAME_RATENotBetween(String value1, String value2) {
            addCriterion("FRAME_RATE not between", value1, value2, "FRAME_RATE");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_TIMEIsNull() {
            addCriterion("VIDEO_RECORD_TIME is null");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_TIMEIsNotNull() {
            addCriterion("VIDEO_RECORD_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_TIMEEqualTo(String value) {
            addCriterion("VIDEO_RECORD_TIME =", value, "VIDEO_RECORD_TIME");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_TIMENotEqualTo(String value) {
            addCriterion("VIDEO_RECORD_TIME <>", value, "VIDEO_RECORD_TIME");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_TIMEGreaterThan(String value) {
            addCriterion("VIDEO_RECORD_TIME >", value, "VIDEO_RECORD_TIME");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_TIMEGreaterThanOrEqualTo(String value) {
            addCriterion("VIDEO_RECORD_TIME >=", value, "VIDEO_RECORD_TIME");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_TIMELessThan(String value) {
            addCriterion("VIDEO_RECORD_TIME <", value, "VIDEO_RECORD_TIME");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_TIMELessThanOrEqualTo(String value) {
            addCriterion("VIDEO_RECORD_TIME <=", value, "VIDEO_RECORD_TIME");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_TIMELike(String value) {
            addCriterion("VIDEO_RECORD_TIME like", value, "VIDEO_RECORD_TIME");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_TIMENotLike(String value) {
            addCriterion("VIDEO_RECORD_TIME not like", value, "VIDEO_RECORD_TIME");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_TIMEIn(List<String> values) {
            addCriterion("VIDEO_RECORD_TIME in", values, "VIDEO_RECORD_TIME");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_TIMENotIn(List<String> values) {
            addCriterion("VIDEO_RECORD_TIME not in", values, "VIDEO_RECORD_TIME");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_TIMEBetween(String value1, String value2) {
            addCriterion("VIDEO_RECORD_TIME between", value1, value2, "VIDEO_RECORD_TIME");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_TIMENotBetween(String value1, String value2) {
            addCriterion("VIDEO_RECORD_TIME not between", value1, value2, "VIDEO_RECORD_TIME");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_COUNTIsNull() {
            addCriterion("VIDEO_RECORD_COUNT is null");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_COUNTIsNotNull() {
            addCriterion("VIDEO_RECORD_COUNT is not null");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_COUNTEqualTo(String value) {
            addCriterion("VIDEO_RECORD_COUNT =", value, "VIDEO_RECORD_COUNT");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_COUNTNotEqualTo(String value) {
            addCriterion("VIDEO_RECORD_COUNT <>", value, "VIDEO_RECORD_COUNT");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_COUNTGreaterThan(String value) {
            addCriterion("VIDEO_RECORD_COUNT >", value, "VIDEO_RECORD_COUNT");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_COUNTGreaterThanOrEqualTo(String value) {
            addCriterion("VIDEO_RECORD_COUNT >=", value, "VIDEO_RECORD_COUNT");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_COUNTLessThan(String value) {
            addCriterion("VIDEO_RECORD_COUNT <", value, "VIDEO_RECORD_COUNT");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_COUNTLessThanOrEqualTo(String value) {
            addCriterion("VIDEO_RECORD_COUNT <=", value, "VIDEO_RECORD_COUNT");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_COUNTLike(String value) {
            addCriterion("VIDEO_RECORD_COUNT like", value, "VIDEO_RECORD_COUNT");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_COUNTNotLike(String value) {
            addCriterion("VIDEO_RECORD_COUNT not like", value, "VIDEO_RECORD_COUNT");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_COUNTIn(List<String> values) {
            addCriterion("VIDEO_RECORD_COUNT in", values, "VIDEO_RECORD_COUNT");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_COUNTNotIn(List<String> values) {
            addCriterion("VIDEO_RECORD_COUNT not in", values, "VIDEO_RECORD_COUNT");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_COUNTBetween(String value1, String value2) {
            addCriterion("VIDEO_RECORD_COUNT between", value1, value2, "VIDEO_RECORD_COUNT");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_COUNTNotBetween(String value1, String value2) {
            addCriterion("VIDEO_RECORD_COUNT not between", value1, value2, "VIDEO_RECORD_COUNT");
            return (Criteria) this;
        }

        public Criteria andIMAGE_START_TIMEIsNull() {
            addCriterion("IMAGE_START_TIME is null");
            return (Criteria) this;
        }

        public Criteria andIMAGE_START_TIMEIsNotNull() {
            addCriterion("IMAGE_START_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andIMAGE_START_TIMEEqualTo(String value) {
            addCriterion("IMAGE_START_TIME =", value, "IMAGE_START_TIME");
            return (Criteria) this;
        }

        public Criteria andIMAGE_START_TIMENotEqualTo(String value) {
            addCriterion("IMAGE_START_TIME <>", value, "IMAGE_START_TIME");
            return (Criteria) this;
        }

        public Criteria andIMAGE_START_TIMEGreaterThan(String value) {
            addCriterion("IMAGE_START_TIME >", value, "IMAGE_START_TIME");
            return (Criteria) this;
        }

        public Criteria andIMAGE_START_TIMEGreaterThanOrEqualTo(String value) {
            addCriterion("IMAGE_START_TIME >=", value, "IMAGE_START_TIME");
            return (Criteria) this;
        }

        public Criteria andIMAGE_START_TIMELessThan(String value) {
            addCriterion("IMAGE_START_TIME <", value, "IMAGE_START_TIME");
            return (Criteria) this;
        }

        public Criteria andIMAGE_START_TIMELessThanOrEqualTo(String value) {
            addCriterion("IMAGE_START_TIME <=", value, "IMAGE_START_TIME");
            return (Criteria) this;
        }

        public Criteria andIMAGE_START_TIMELike(String value) {
            addCriterion("IMAGE_START_TIME like", value, "IMAGE_START_TIME");
            return (Criteria) this;
        }

        public Criteria andIMAGE_START_TIMENotLike(String value) {
            addCriterion("IMAGE_START_TIME not like", value, "IMAGE_START_TIME");
            return (Criteria) this;
        }

        public Criteria andIMAGE_START_TIMEIn(List<String> values) {
            addCriterion("IMAGE_START_TIME in", values, "IMAGE_START_TIME");
            return (Criteria) this;
        }

        public Criteria andIMAGE_START_TIMENotIn(List<String> values) {
            addCriterion("IMAGE_START_TIME not in", values, "IMAGE_START_TIME");
            return (Criteria) this;
        }

        public Criteria andIMAGE_START_TIMEBetween(String value1, String value2) {
            addCriterion("IMAGE_START_TIME between", value1, value2, "IMAGE_START_TIME");
            return (Criteria) this;
        }

        public Criteria andIMAGE_START_TIMENotBetween(String value1, String value2) {
            addCriterion("IMAGE_START_TIME not between", value1, value2, "IMAGE_START_TIME");
            return (Criteria) this;
        }

        public Criteria andIMAGE_COUNTIsNull() {
            addCriterion("IMAGE_COUNT is null");
            return (Criteria) this;
        }

        public Criteria andIMAGE_COUNTIsNotNull() {
            addCriterion("IMAGE_COUNT is not null");
            return (Criteria) this;
        }

        public Criteria andIMAGE_COUNTEqualTo(String value) {
            addCriterion("IMAGE_COUNT =", value, "IMAGE_COUNT");
            return (Criteria) this;
        }

        public Criteria andIMAGE_COUNTNotEqualTo(String value) {
            addCriterion("IMAGE_COUNT <>", value, "IMAGE_COUNT");
            return (Criteria) this;
        }

        public Criteria andIMAGE_COUNTGreaterThan(String value) {
            addCriterion("IMAGE_COUNT >", value, "IMAGE_COUNT");
            return (Criteria) this;
        }

        public Criteria andIMAGE_COUNTGreaterThanOrEqualTo(String value) {
            addCriterion("IMAGE_COUNT >=", value, "IMAGE_COUNT");
            return (Criteria) this;
        }

        public Criteria andIMAGE_COUNTLessThan(String value) {
            addCriterion("IMAGE_COUNT <", value, "IMAGE_COUNT");
            return (Criteria) this;
        }

        public Criteria andIMAGE_COUNTLessThanOrEqualTo(String value) {
            addCriterion("IMAGE_COUNT <=", value, "IMAGE_COUNT");
            return (Criteria) this;
        }

        public Criteria andIMAGE_COUNTLike(String value) {
            addCriterion("IMAGE_COUNT like", value, "IMAGE_COUNT");
            return (Criteria) this;
        }

        public Criteria andIMAGE_COUNTNotLike(String value) {
            addCriterion("IMAGE_COUNT not like", value, "IMAGE_COUNT");
            return (Criteria) this;
        }

        public Criteria andIMAGE_COUNTIn(List<String> values) {
            addCriterion("IMAGE_COUNT in", values, "IMAGE_COUNT");
            return (Criteria) this;
        }

        public Criteria andIMAGE_COUNTNotIn(List<String> values) {
            addCriterion("IMAGE_COUNT not in", values, "IMAGE_COUNT");
            return (Criteria) this;
        }

        public Criteria andIMAGE_COUNTBetween(String value1, String value2) {
            addCriterion("IMAGE_COUNT between", value1, value2, "IMAGE_COUNT");
            return (Criteria) this;
        }

        public Criteria andIMAGE_COUNTNotBetween(String value1, String value2) {
            addCriterion("IMAGE_COUNT not between", value1, value2, "IMAGE_COUNT");
            return (Criteria) this;
        }

        public Criteria andMIC_INTERPHONE_LINK_FLGIsNull() {
            addCriterion("MIC_INTERPHONE_LINK_FLG is null");
            return (Criteria) this;
        }

        public Criteria andMIC_INTERPHONE_LINK_FLGIsNotNull() {
            addCriterion("MIC_INTERPHONE_LINK_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andMIC_INTERPHONE_LINK_FLGEqualTo(String value) {
            addCriterion("MIC_INTERPHONE_LINK_FLG =", value, "MIC_INTERPHONE_LINK_FLG");
            return (Criteria) this;
        }

        public Criteria andMIC_INTERPHONE_LINK_FLGNotEqualTo(String value) {
            addCriterion("MIC_INTERPHONE_LINK_FLG <>", value, "MIC_INTERPHONE_LINK_FLG");
            return (Criteria) this;
        }

        public Criteria andMIC_INTERPHONE_LINK_FLGGreaterThan(String value) {
            addCriterion("MIC_INTERPHONE_LINK_FLG >", value, "MIC_INTERPHONE_LINK_FLG");
            return (Criteria) this;
        }

        public Criteria andMIC_INTERPHONE_LINK_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("MIC_INTERPHONE_LINK_FLG >=", value, "MIC_INTERPHONE_LINK_FLG");
            return (Criteria) this;
        }

        public Criteria andMIC_INTERPHONE_LINK_FLGLessThan(String value) {
            addCriterion("MIC_INTERPHONE_LINK_FLG <", value, "MIC_INTERPHONE_LINK_FLG");
            return (Criteria) this;
        }

        public Criteria andMIC_INTERPHONE_LINK_FLGLessThanOrEqualTo(String value) {
            addCriterion("MIC_INTERPHONE_LINK_FLG <=", value, "MIC_INTERPHONE_LINK_FLG");
            return (Criteria) this;
        }

        public Criteria andMIC_INTERPHONE_LINK_FLGLike(String value) {
            addCriterion("MIC_INTERPHONE_LINK_FLG like", value, "MIC_INTERPHONE_LINK_FLG");
            return (Criteria) this;
        }

        public Criteria andMIC_INTERPHONE_LINK_FLGNotLike(String value) {
            addCriterion("MIC_INTERPHONE_LINK_FLG not like", value, "MIC_INTERPHONE_LINK_FLG");
            return (Criteria) this;
        }

        public Criteria andMIC_INTERPHONE_LINK_FLGIn(List<String> values) {
            addCriterion("MIC_INTERPHONE_LINK_FLG in", values, "MIC_INTERPHONE_LINK_FLG");
            return (Criteria) this;
        }

        public Criteria andMIC_INTERPHONE_LINK_FLGNotIn(List<String> values) {
            addCriterion("MIC_INTERPHONE_LINK_FLG not in", values, "MIC_INTERPHONE_LINK_FLG");
            return (Criteria) this;
        }

        public Criteria andMIC_INTERPHONE_LINK_FLGBetween(String value1, String value2) {
            addCriterion("MIC_INTERPHONE_LINK_FLG between", value1, value2, "MIC_INTERPHONE_LINK_FLG");
            return (Criteria) this;
        }

        public Criteria andMIC_INTERPHONE_LINK_FLGNotBetween(String value1, String value2) {
            addCriterion("MIC_INTERPHONE_LINK_FLG not between", value1, value2, "MIC_INTERPHONE_LINK_FLG");
            return (Criteria) this;
        }

        public Criteria andVOICE_DEV_NUMIsNull() {
            addCriterion("VOICE_DEV_NUM is null");
            return (Criteria) this;
        }

        public Criteria andVOICE_DEV_NUMIsNotNull() {
            addCriterion("VOICE_DEV_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andVOICE_DEV_NUMEqualTo(String value) {
            addCriterion("VOICE_DEV_NUM =", value, "VOICE_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andVOICE_DEV_NUMNotEqualTo(String value) {
            addCriterion("VOICE_DEV_NUM <>", value, "VOICE_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andVOICE_DEV_NUMGreaterThan(String value) {
            addCriterion("VOICE_DEV_NUM >", value, "VOICE_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andVOICE_DEV_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("VOICE_DEV_NUM >=", value, "VOICE_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andVOICE_DEV_NUMLessThan(String value) {
            addCriterion("VOICE_DEV_NUM <", value, "VOICE_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andVOICE_DEV_NUMLessThanOrEqualTo(String value) {
            addCriterion("VOICE_DEV_NUM <=", value, "VOICE_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andVOICE_DEV_NUMLike(String value) {
            addCriterion("VOICE_DEV_NUM like", value, "VOICE_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andVOICE_DEV_NUMNotLike(String value) {
            addCriterion("VOICE_DEV_NUM not like", value, "VOICE_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andVOICE_DEV_NUMIn(List<String> values) {
            addCriterion("VOICE_DEV_NUM in", values, "VOICE_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andVOICE_DEV_NUMNotIn(List<String> values) {
            addCriterion("VOICE_DEV_NUM not in", values, "VOICE_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andVOICE_DEV_NUMBetween(String value1, String value2) {
            addCriterion("VOICE_DEV_NUM between", value1, value2, "VOICE_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andVOICE_DEV_NUMNotBetween(String value1, String value2) {
            addCriterion("VOICE_DEV_NUM not between", value1, value2, "VOICE_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andINTERPHONE_NOIsNull() {
            addCriterion("INTERPHONE_NO is null");
            return (Criteria) this;
        }

        public Criteria andINTERPHONE_NOIsNotNull() {
            addCriterion("INTERPHONE_NO is not null");
            return (Criteria) this;
        }

        public Criteria andINTERPHONE_NOEqualTo(String value) {
            addCriterion("INTERPHONE_NO =", value, "INTERPHONE_NO");
            return (Criteria) this;
        }

        public Criteria andINTERPHONE_NONotEqualTo(String value) {
            addCriterion("INTERPHONE_NO <>", value, "INTERPHONE_NO");
            return (Criteria) this;
        }

        public Criteria andINTERPHONE_NOGreaterThan(String value) {
            addCriterion("INTERPHONE_NO >", value, "INTERPHONE_NO");
            return (Criteria) this;
        }

        public Criteria andINTERPHONE_NOGreaterThanOrEqualTo(String value) {
            addCriterion("INTERPHONE_NO >=", value, "INTERPHONE_NO");
            return (Criteria) this;
        }

        public Criteria andINTERPHONE_NOLessThan(String value) {
            addCriterion("INTERPHONE_NO <", value, "INTERPHONE_NO");
            return (Criteria) this;
        }

        public Criteria andINTERPHONE_NOLessThanOrEqualTo(String value) {
            addCriterion("INTERPHONE_NO <=", value, "INTERPHONE_NO");
            return (Criteria) this;
        }

        public Criteria andINTERPHONE_NOLike(String value) {
            addCriterion("INTERPHONE_NO like", value, "INTERPHONE_NO");
            return (Criteria) this;
        }

        public Criteria andINTERPHONE_NONotLike(String value) {
            addCriterion("INTERPHONE_NO not like", value, "INTERPHONE_NO");
            return (Criteria) this;
        }

        public Criteria andINTERPHONE_NOIn(List<String> values) {
            addCriterion("INTERPHONE_NO in", values, "INTERPHONE_NO");
            return (Criteria) this;
        }

        public Criteria andINTERPHONE_NONotIn(List<String> values) {
            addCriterion("INTERPHONE_NO not in", values, "INTERPHONE_NO");
            return (Criteria) this;
        }

        public Criteria andINTERPHONE_NOBetween(String value1, String value2) {
            addCriterion("INTERPHONE_NO between", value1, value2, "INTERPHONE_NO");
            return (Criteria) this;
        }

        public Criteria andINTERPHONE_NONotBetween(String value1, String value2) {
            addCriterion("INTERPHONE_NO not between", value1, value2, "INTERPHONE_NO");
            return (Criteria) this;
        }

        public Criteria andMIC_NOIsNull() {
            addCriterion("MIC_NO is null");
            return (Criteria) this;
        }

        public Criteria andMIC_NOIsNotNull() {
            addCriterion("MIC_NO is not null");
            return (Criteria) this;
        }

        public Criteria andMIC_NOEqualTo(String value) {
            addCriterion("MIC_NO =", value, "MIC_NO");
            return (Criteria) this;
        }

        public Criteria andMIC_NONotEqualTo(String value) {
            addCriterion("MIC_NO <>", value, "MIC_NO");
            return (Criteria) this;
        }

        public Criteria andMIC_NOGreaterThan(String value) {
            addCriterion("MIC_NO >", value, "MIC_NO");
            return (Criteria) this;
        }

        public Criteria andMIC_NOGreaterThanOrEqualTo(String value) {
            addCriterion("MIC_NO >=", value, "MIC_NO");
            return (Criteria) this;
        }

        public Criteria andMIC_NOLessThan(String value) {
            addCriterion("MIC_NO <", value, "MIC_NO");
            return (Criteria) this;
        }

        public Criteria andMIC_NOLessThanOrEqualTo(String value) {
            addCriterion("MIC_NO <=", value, "MIC_NO");
            return (Criteria) this;
        }

        public Criteria andMIC_NOLike(String value) {
            addCriterion("MIC_NO like", value, "MIC_NO");
            return (Criteria) this;
        }

        public Criteria andMIC_NONotLike(String value) {
            addCriterion("MIC_NO not like", value, "MIC_NO");
            return (Criteria) this;
        }

        public Criteria andMIC_NOIn(List<String> values) {
            addCriterion("MIC_NO in", values, "MIC_NO");
            return (Criteria) this;
        }

        public Criteria andMIC_NONotIn(List<String> values) {
            addCriterion("MIC_NO not in", values, "MIC_NO");
            return (Criteria) this;
        }

        public Criteria andMIC_NOBetween(String value1, String value2) {
            addCriterion("MIC_NO between", value1, value2, "MIC_NO");
            return (Criteria) this;
        }

        public Criteria andMIC_NONotBetween(String value1, String value2) {
            addCriterion("MIC_NO not between", value1, value2, "MIC_NO");
            return (Criteria) this;
        }

        public Criteria andSPEAKER_NOIsNull() {
            addCriterion("SPEAKER_NO is null");
            return (Criteria) this;
        }

        public Criteria andSPEAKER_NOIsNotNull() {
            addCriterion("SPEAKER_NO is not null");
            return (Criteria) this;
        }

        public Criteria andSPEAKER_NOEqualTo(String value) {
            addCriterion("SPEAKER_NO =", value, "SPEAKER_NO");
            return (Criteria) this;
        }

        public Criteria andSPEAKER_NONotEqualTo(String value) {
            addCriterion("SPEAKER_NO <>", value, "SPEAKER_NO");
            return (Criteria) this;
        }

        public Criteria andSPEAKER_NOGreaterThan(String value) {
            addCriterion("SPEAKER_NO >", value, "SPEAKER_NO");
            return (Criteria) this;
        }

        public Criteria andSPEAKER_NOGreaterThanOrEqualTo(String value) {
            addCriterion("SPEAKER_NO >=", value, "SPEAKER_NO");
            return (Criteria) this;
        }

        public Criteria andSPEAKER_NOLessThan(String value) {
            addCriterion("SPEAKER_NO <", value, "SPEAKER_NO");
            return (Criteria) this;
        }

        public Criteria andSPEAKER_NOLessThanOrEqualTo(String value) {
            addCriterion("SPEAKER_NO <=", value, "SPEAKER_NO");
            return (Criteria) this;
        }

        public Criteria andSPEAKER_NOLike(String value) {
            addCriterion("SPEAKER_NO like", value, "SPEAKER_NO");
            return (Criteria) this;
        }

        public Criteria andSPEAKER_NONotLike(String value) {
            addCriterion("SPEAKER_NO not like", value, "SPEAKER_NO");
            return (Criteria) this;
        }

        public Criteria andSPEAKER_NOIn(List<String> values) {
            addCriterion("SPEAKER_NO in", values, "SPEAKER_NO");
            return (Criteria) this;
        }

        public Criteria andSPEAKER_NONotIn(List<String> values) {
            addCriterion("SPEAKER_NO not in", values, "SPEAKER_NO");
            return (Criteria) this;
        }

        public Criteria andSPEAKER_NOBetween(String value1, String value2) {
            addCriterion("SPEAKER_NO between", value1, value2, "SPEAKER_NO");
            return (Criteria) this;
        }

        public Criteria andSPEAKER_NONotBetween(String value1, String value2) {
            addCriterion("SPEAKER_NO not between", value1, value2, "SPEAKER_NO");
            return (Criteria) this;
        }

        public Criteria andVOICE_FILE_NAMEIsNull() {
            addCriterion("VOICE_FILE_NAME is null");
            return (Criteria) this;
        }

        public Criteria andVOICE_FILE_NAMEIsNotNull() {
            addCriterion("VOICE_FILE_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andVOICE_FILE_NAMEEqualTo(String value) {
            addCriterion("VOICE_FILE_NAME =", value, "VOICE_FILE_NAME");
            return (Criteria) this;
        }

        public Criteria andVOICE_FILE_NAMENotEqualTo(String value) {
            addCriterion("VOICE_FILE_NAME <>", value, "VOICE_FILE_NAME");
            return (Criteria) this;
        }

        public Criteria andVOICE_FILE_NAMEGreaterThan(String value) {
            addCriterion("VOICE_FILE_NAME >", value, "VOICE_FILE_NAME");
            return (Criteria) this;
        }

        public Criteria andVOICE_FILE_NAMEGreaterThanOrEqualTo(String value) {
            addCriterion("VOICE_FILE_NAME >=", value, "VOICE_FILE_NAME");
            return (Criteria) this;
        }

        public Criteria andVOICE_FILE_NAMELessThan(String value) {
            addCriterion("VOICE_FILE_NAME <", value, "VOICE_FILE_NAME");
            return (Criteria) this;
        }

        public Criteria andVOICE_FILE_NAMELessThanOrEqualTo(String value) {
            addCriterion("VOICE_FILE_NAME <=", value, "VOICE_FILE_NAME");
            return (Criteria) this;
        }

        public Criteria andVOICE_FILE_NAMELike(String value) {
            addCriterion("VOICE_FILE_NAME like", value, "VOICE_FILE_NAME");
            return (Criteria) this;
        }

        public Criteria andVOICE_FILE_NAMENotLike(String value) {
            addCriterion("VOICE_FILE_NAME not like", value, "VOICE_FILE_NAME");
            return (Criteria) this;
        }

        public Criteria andVOICE_FILE_NAMEIn(List<String> values) {
            addCriterion("VOICE_FILE_NAME in", values, "VOICE_FILE_NAME");
            return (Criteria) this;
        }

        public Criteria andVOICE_FILE_NAMENotIn(List<String> values) {
            addCriterion("VOICE_FILE_NAME not in", values, "VOICE_FILE_NAME");
            return (Criteria) this;
        }

        public Criteria andVOICE_FILE_NAMEBetween(String value1, String value2) {
            addCriterion("VOICE_FILE_NAME between", value1, value2, "VOICE_FILE_NAME");
            return (Criteria) this;
        }

        public Criteria andVOICE_FILE_NAMENotBetween(String value1, String value2) {
            addCriterion("VOICE_FILE_NAME not between", value1, value2, "VOICE_FILE_NAME");
            return (Criteria) this;
        }

        public Criteria andVOICE_RECORD_TIMEIsNull() {
            addCriterion("VOICE_RECORD_TIME is null");
            return (Criteria) this;
        }

        public Criteria andVOICE_RECORD_TIMEIsNotNull() {
            addCriterion("VOICE_RECORD_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andVOICE_RECORD_TIMEEqualTo(String value) {
            addCriterion("VOICE_RECORD_TIME =", value, "VOICE_RECORD_TIME");
            return (Criteria) this;
        }

        public Criteria andVOICE_RECORD_TIMENotEqualTo(String value) {
            addCriterion("VOICE_RECORD_TIME <>", value, "VOICE_RECORD_TIME");
            return (Criteria) this;
        }

        public Criteria andVOICE_RECORD_TIMEGreaterThan(String value) {
            addCriterion("VOICE_RECORD_TIME >", value, "VOICE_RECORD_TIME");
            return (Criteria) this;
        }

        public Criteria andVOICE_RECORD_TIMEGreaterThanOrEqualTo(String value) {
            addCriterion("VOICE_RECORD_TIME >=", value, "VOICE_RECORD_TIME");
            return (Criteria) this;
        }

        public Criteria andVOICE_RECORD_TIMELessThan(String value) {
            addCriterion("VOICE_RECORD_TIME <", value, "VOICE_RECORD_TIME");
            return (Criteria) this;
        }

        public Criteria andVOICE_RECORD_TIMELessThanOrEqualTo(String value) {
            addCriterion("VOICE_RECORD_TIME <=", value, "VOICE_RECORD_TIME");
            return (Criteria) this;
        }

        public Criteria andVOICE_RECORD_TIMELike(String value) {
            addCriterion("VOICE_RECORD_TIME like", value, "VOICE_RECORD_TIME");
            return (Criteria) this;
        }

        public Criteria andVOICE_RECORD_TIMENotLike(String value) {
            addCriterion("VOICE_RECORD_TIME not like", value, "VOICE_RECORD_TIME");
            return (Criteria) this;
        }

        public Criteria andVOICE_RECORD_TIMEIn(List<String> values) {
            addCriterion("VOICE_RECORD_TIME in", values, "VOICE_RECORD_TIME");
            return (Criteria) this;
        }

        public Criteria andVOICE_RECORD_TIMENotIn(List<String> values) {
            addCriterion("VOICE_RECORD_TIME not in", values, "VOICE_RECORD_TIME");
            return (Criteria) this;
        }

        public Criteria andVOICE_RECORD_TIMEBetween(String value1, String value2) {
            addCriterion("VOICE_RECORD_TIME between", value1, value2, "VOICE_RECORD_TIME");
            return (Criteria) this;
        }

        public Criteria andVOICE_RECORD_TIMENotBetween(String value1, String value2) {
            addCriterion("VOICE_RECORD_TIME not between", value1, value2, "VOICE_RECORD_TIME");
            return (Criteria) this;
        }

        public Criteria andGC_SEND_FLGIsNull() {
            addCriterion("GC_SEND_FLG is null");
            return (Criteria) this;
        }

        public Criteria andGC_SEND_FLGIsNotNull() {
            addCriterion("GC_SEND_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andGC_SEND_FLGEqualTo(String value) {
            addCriterion("GC_SEND_FLG =", value, "GC_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_SEND_FLGNotEqualTo(String value) {
            addCriterion("GC_SEND_FLG <>", value, "GC_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_SEND_FLGGreaterThan(String value) {
            addCriterion("GC_SEND_FLG >", value, "GC_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_SEND_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("GC_SEND_FLG >=", value, "GC_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_SEND_FLGLessThan(String value) {
            addCriterion("GC_SEND_FLG <", value, "GC_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_SEND_FLGLessThanOrEqualTo(String value) {
            addCriterion("GC_SEND_FLG <=", value, "GC_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_SEND_FLGLike(String value) {
            addCriterion("GC_SEND_FLG like", value, "GC_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_SEND_FLGNotLike(String value) {
            addCriterion("GC_SEND_FLG not like", value, "GC_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_SEND_FLGIn(List<String> values) {
            addCriterion("GC_SEND_FLG in", values, "GC_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_SEND_FLGNotIn(List<String> values) {
            addCriterion("GC_SEND_FLG not in", values, "GC_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_SEND_FLGBetween(String value1, String value2) {
            addCriterion("GC_SEND_FLG between", value1, value2, "GC_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_SEND_FLGNotBetween(String value1, String value2) {
            addCriterion("GC_SEND_FLG not between", value1, value2, "GC_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andSIG_NMIsNull() {
            addCriterion("SIG_NM is null");
            return (Criteria) this;
        }

        public Criteria andSIG_NMIsNotNull() {
            addCriterion("SIG_NM is not null");
            return (Criteria) this;
        }

        public Criteria andSIG_NMEqualTo(String value) {
            addCriterion("SIG_NM =", value, "SIG_NM");
            return (Criteria) this;
        }

        public Criteria andSIG_NMNotEqualTo(String value) {
            addCriterion("SIG_NM <>", value, "SIG_NM");
            return (Criteria) this;
        }

        public Criteria andSIG_NMGreaterThan(String value) {
            addCriterion("SIG_NM >", value, "SIG_NM");
            return (Criteria) this;
        }

        public Criteria andSIG_NMGreaterThanOrEqualTo(String value) {
            addCriterion("SIG_NM >=", value, "SIG_NM");
            return (Criteria) this;
        }

        public Criteria andSIG_NMLessThan(String value) {
            addCriterion("SIG_NM <", value, "SIG_NM");
            return (Criteria) this;
        }

        public Criteria andSIG_NMLessThanOrEqualTo(String value) {
            addCriterion("SIG_NM <=", value, "SIG_NM");
            return (Criteria) this;
        }

        public Criteria andSIG_NMLike(String value) {
            addCriterion("SIG_NM like", value, "SIG_NM");
            return (Criteria) this;
        }

        public Criteria andSIG_NMNotLike(String value) {
            addCriterion("SIG_NM not like", value, "SIG_NM");
            return (Criteria) this;
        }

        public Criteria andSIG_NMIn(List<String> values) {
            addCriterion("SIG_NM in", values, "SIG_NM");
            return (Criteria) this;
        }

        public Criteria andSIG_NMNotIn(List<String> values) {
            addCriterion("SIG_NM not in", values, "SIG_NM");
            return (Criteria) this;
        }

        public Criteria andSIG_NMBetween(String value1, String value2) {
            addCriterion("SIG_NM between", value1, value2, "SIG_NM");
            return (Criteria) this;
        }

        public Criteria andSIG_NMNotBetween(String value1, String value2) {
            addCriterion("SIG_NM not between", value1, value2, "SIG_NM");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_KB_SIGIsNull() {
            addCriterion("LN_QUE_KB_SIG is null");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_KB_SIGIsNotNull() {
            addCriterion("LN_QUE_KB_SIG is not null");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_KB_SIGEqualTo(String value) {
            addCriterion("LN_QUE_KB_SIG =", value, "LN_QUE_KB_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_KB_SIGNotEqualTo(String value) {
            addCriterion("LN_QUE_KB_SIG <>", value, "LN_QUE_KB_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_KB_SIGGreaterThan(String value) {
            addCriterion("LN_QUE_KB_SIG >", value, "LN_QUE_KB_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_KB_SIGGreaterThanOrEqualTo(String value) {
            addCriterion("LN_QUE_KB_SIG >=", value, "LN_QUE_KB_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_KB_SIGLessThan(String value) {
            addCriterion("LN_QUE_KB_SIG <", value, "LN_QUE_KB_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_KB_SIGLessThanOrEqualTo(String value) {
            addCriterion("LN_QUE_KB_SIG <=", value, "LN_QUE_KB_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_KB_SIGLike(String value) {
            addCriterion("LN_QUE_KB_SIG like", value, "LN_QUE_KB_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_KB_SIGNotLike(String value) {
            addCriterion("LN_QUE_KB_SIG not like", value, "LN_QUE_KB_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_KB_SIGIn(List<String> values) {
            addCriterion("LN_QUE_KB_SIG in", values, "LN_QUE_KB_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_KB_SIGNotIn(List<String> values) {
            addCriterion("LN_QUE_KB_SIG not in", values, "LN_QUE_KB_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_KB_SIGBetween(String value1, String value2) {
            addCriterion("LN_QUE_KB_SIG between", value1, value2, "LN_QUE_KB_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_KB_SIGNotBetween(String value1, String value2) {
            addCriterion("LN_QUE_KB_SIG not between", value1, value2, "LN_QUE_KB_SIG");
            return (Criteria) this;
        }

        public Criteria andRM_FLGIsNull() {
            addCriterion("RM_FLG is null");
            return (Criteria) this;
        }

        public Criteria andRM_FLGIsNotNull() {
            addCriterion("RM_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andRM_FLGEqualTo(String value) {
            addCriterion("RM_FLG =", value, "RM_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_FLGNotEqualTo(String value) {
            addCriterion("RM_FLG <>", value, "RM_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_FLGGreaterThan(String value) {
            addCriterion("RM_FLG >", value, "RM_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("RM_FLG >=", value, "RM_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_FLGLessThan(String value) {
            addCriterion("RM_FLG <", value, "RM_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_FLGLessThanOrEqualTo(String value) {
            addCriterion("RM_FLG <=", value, "RM_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_FLGLike(String value) {
            addCriterion("RM_FLG like", value, "RM_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_FLGNotLike(String value) {
            addCriterion("RM_FLG not like", value, "RM_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_FLGIn(List<String> values) {
            addCriterion("RM_FLG in", values, "RM_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_FLGNotIn(List<String> values) {
            addCriterion("RM_FLG not in", values, "RM_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_FLGBetween(String value1, String value2) {
            addCriterion("RM_FLG between", value1, value2, "RM_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_FLGNotBetween(String value1, String value2) {
            addCriterion("RM_FLG not between", value1, value2, "RM_FLG");
            return (Criteria) this;
        }

        public Criteria andEXCEPT_SIG_FLGIsNull() {
            addCriterion("EXCEPT_SIG_FLG is null");
            return (Criteria) this;
        }

        public Criteria andEXCEPT_SIG_FLGIsNotNull() {
            addCriterion("EXCEPT_SIG_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andEXCEPT_SIG_FLGEqualTo(String value) {
            addCriterion("EXCEPT_SIG_FLG =", value, "EXCEPT_SIG_FLG");
            return (Criteria) this;
        }

        public Criteria andEXCEPT_SIG_FLGNotEqualTo(String value) {
            addCriterion("EXCEPT_SIG_FLG <>", value, "EXCEPT_SIG_FLG");
            return (Criteria) this;
        }

        public Criteria andEXCEPT_SIG_FLGGreaterThan(String value) {
            addCriterion("EXCEPT_SIG_FLG >", value, "EXCEPT_SIG_FLG");
            return (Criteria) this;
        }

        public Criteria andEXCEPT_SIG_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("EXCEPT_SIG_FLG >=", value, "EXCEPT_SIG_FLG");
            return (Criteria) this;
        }

        public Criteria andEXCEPT_SIG_FLGLessThan(String value) {
            addCriterion("EXCEPT_SIG_FLG <", value, "EXCEPT_SIG_FLG");
            return (Criteria) this;
        }

        public Criteria andEXCEPT_SIG_FLGLessThanOrEqualTo(String value) {
            addCriterion("EXCEPT_SIG_FLG <=", value, "EXCEPT_SIG_FLG");
            return (Criteria) this;
        }

        public Criteria andEXCEPT_SIG_FLGLike(String value) {
            addCriterion("EXCEPT_SIG_FLG like", value, "EXCEPT_SIG_FLG");
            return (Criteria) this;
        }

        public Criteria andEXCEPT_SIG_FLGNotLike(String value) {
            addCriterion("EXCEPT_SIG_FLG not like", value, "EXCEPT_SIG_FLG");
            return (Criteria) this;
        }

        public Criteria andEXCEPT_SIG_FLGIn(List<String> values) {
            addCriterion("EXCEPT_SIG_FLG in", values, "EXCEPT_SIG_FLG");
            return (Criteria) this;
        }

        public Criteria andEXCEPT_SIG_FLGNotIn(List<String> values) {
            addCriterion("EXCEPT_SIG_FLG not in", values, "EXCEPT_SIG_FLG");
            return (Criteria) this;
        }

        public Criteria andEXCEPT_SIG_FLGBetween(String value1, String value2) {
            addCriterion("EXCEPT_SIG_FLG between", value1, value2, "EXCEPT_SIG_FLG");
            return (Criteria) this;
        }

        public Criteria andEXCEPT_SIG_FLGNotBetween(String value1, String value2) {
            addCriterion("EXCEPT_SIG_FLG not between", value1, value2, "EXCEPT_SIG_FLG");
            return (Criteria) this;
        }

        public Criteria andIMG_NUMIsNull() {
            addCriterion("IMG_NUM is null");
            return (Criteria) this;
        }

        public Criteria andIMG_NUMIsNotNull() {
            addCriterion("IMG_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andIMG_NUMEqualTo(String value) {
            addCriterion("IMG_NUM =", value, "IMG_NUM");
            return (Criteria) this;
        }

        public Criteria andIMG_NUMNotEqualTo(String value) {
            addCriterion("IMG_NUM <>", value, "IMG_NUM");
            return (Criteria) this;
        }

        public Criteria andIMG_NUMGreaterThan(String value) {
            addCriterion("IMG_NUM >", value, "IMG_NUM");
            return (Criteria) this;
        }

        public Criteria andIMG_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("IMG_NUM >=", value, "IMG_NUM");
            return (Criteria) this;
        }

        public Criteria andIMG_NUMLessThan(String value) {
            addCriterion("IMG_NUM <", value, "IMG_NUM");
            return (Criteria) this;
        }

        public Criteria andIMG_NUMLessThanOrEqualTo(String value) {
            addCriterion("IMG_NUM <=", value, "IMG_NUM");
            return (Criteria) this;
        }

        public Criteria andIMG_NUMLike(String value) {
            addCriterion("IMG_NUM like", value, "IMG_NUM");
            return (Criteria) this;
        }

        public Criteria andIMG_NUMNotLike(String value) {
            addCriterion("IMG_NUM not like", value, "IMG_NUM");
            return (Criteria) this;
        }

        public Criteria andIMG_NUMIn(List<String> values) {
            addCriterion("IMG_NUM in", values, "IMG_NUM");
            return (Criteria) this;
        }

        public Criteria andIMG_NUMNotIn(List<String> values) {
            addCriterion("IMG_NUM not in", values, "IMG_NUM");
            return (Criteria) this;
        }

        public Criteria andIMG_NUMBetween(String value1, String value2) {
            addCriterion("IMG_NUM between", value1, value2, "IMG_NUM");
            return (Criteria) this;
        }

        public Criteria andIMG_NUMNotBetween(String value1, String value2) {
            addCriterion("IMG_NUM not between", value1, value2, "IMG_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_PIsNull() {
            addCriterion("LN_IMG_NUM_P is null");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_PIsNotNull() {
            addCriterion("LN_IMG_NUM_P is not null");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_PEqualTo(String value) {
            addCriterion("LN_IMG_NUM_P =", value, "LN_IMG_NUM_P");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_PNotEqualTo(String value) {
            addCriterion("LN_IMG_NUM_P <>", value, "LN_IMG_NUM_P");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_PGreaterThan(String value) {
            addCriterion("LN_IMG_NUM_P >", value, "LN_IMG_NUM_P");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_PGreaterThanOrEqualTo(String value) {
            addCriterion("LN_IMG_NUM_P >=", value, "LN_IMG_NUM_P");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_PLessThan(String value) {
            addCriterion("LN_IMG_NUM_P <", value, "LN_IMG_NUM_P");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_PLessThanOrEqualTo(String value) {
            addCriterion("LN_IMG_NUM_P <=", value, "LN_IMG_NUM_P");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_PLike(String value) {
            addCriterion("LN_IMG_NUM_P like", value, "LN_IMG_NUM_P");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_PNotLike(String value) {
            addCriterion("LN_IMG_NUM_P not like", value, "LN_IMG_NUM_P");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_PIn(List<String> values) {
            addCriterion("LN_IMG_NUM_P in", values, "LN_IMG_NUM_P");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_PNotIn(List<String> values) {
            addCriterion("LN_IMG_NUM_P not in", values, "LN_IMG_NUM_P");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_PBetween(String value1, String value2) {
            addCriterion("LN_IMG_NUM_P between", value1, value2, "LN_IMG_NUM_P");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_PNotBetween(String value1, String value2) {
            addCriterion("LN_IMG_NUM_P not between", value1, value2, "LN_IMG_NUM_P");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_VIsNull() {
            addCriterion("LN_IMG_NUM_V is null");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_VIsNotNull() {
            addCriterion("LN_IMG_NUM_V is not null");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_VEqualTo(String value) {
            addCriterion("LN_IMG_NUM_V =", value, "LN_IMG_NUM_V");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_VNotEqualTo(String value) {
            addCriterion("LN_IMG_NUM_V <>", value, "LN_IMG_NUM_V");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_VGreaterThan(String value) {
            addCriterion("LN_IMG_NUM_V >", value, "LN_IMG_NUM_V");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_VGreaterThanOrEqualTo(String value) {
            addCriterion("LN_IMG_NUM_V >=", value, "LN_IMG_NUM_V");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_VLessThan(String value) {
            addCriterion("LN_IMG_NUM_V <", value, "LN_IMG_NUM_V");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_VLessThanOrEqualTo(String value) {
            addCriterion("LN_IMG_NUM_V <=", value, "LN_IMG_NUM_V");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_VLike(String value) {
            addCriterion("LN_IMG_NUM_V like", value, "LN_IMG_NUM_V");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_VNotLike(String value) {
            addCriterion("LN_IMG_NUM_V not like", value, "LN_IMG_NUM_V");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_VIn(List<String> values) {
            addCriterion("LN_IMG_NUM_V in", values, "LN_IMG_NUM_V");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_VNotIn(List<String> values) {
            addCriterion("LN_IMG_NUM_V not in", values, "LN_IMG_NUM_V");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_VBetween(String value1, String value2) {
            addCriterion("LN_IMG_NUM_V between", value1, value2, "LN_IMG_NUM_V");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_VNotBetween(String value1, String value2) {
            addCriterion("LN_IMG_NUM_V not between", value1, value2, "LN_IMG_NUM_V");
            return (Criteria) this;
        }

        public Criteria andIMG_GET_STSIsNull() {
            addCriterion("IMG_GET_STS is null");
            return (Criteria) this;
        }

        public Criteria andIMG_GET_STSIsNotNull() {
            addCriterion("IMG_GET_STS is not null");
            return (Criteria) this;
        }

        public Criteria andIMG_GET_STSEqualTo(String value) {
            addCriterion("IMG_GET_STS =", value, "IMG_GET_STS");
            return (Criteria) this;
        }

        public Criteria andIMG_GET_STSNotEqualTo(String value) {
            addCriterion("IMG_GET_STS <>", value, "IMG_GET_STS");
            return (Criteria) this;
        }

        public Criteria andIMG_GET_STSGreaterThan(String value) {
            addCriterion("IMG_GET_STS >", value, "IMG_GET_STS");
            return (Criteria) this;
        }

        public Criteria andIMG_GET_STSGreaterThanOrEqualTo(String value) {
            addCriterion("IMG_GET_STS >=", value, "IMG_GET_STS");
            return (Criteria) this;
        }

        public Criteria andIMG_GET_STSLessThan(String value) {
            addCriterion("IMG_GET_STS <", value, "IMG_GET_STS");
            return (Criteria) this;
        }

        public Criteria andIMG_GET_STSLessThanOrEqualTo(String value) {
            addCriterion("IMG_GET_STS <=", value, "IMG_GET_STS");
            return (Criteria) this;
        }

        public Criteria andIMG_GET_STSLike(String value) {
            addCriterion("IMG_GET_STS like", value, "IMG_GET_STS");
            return (Criteria) this;
        }

        public Criteria andIMG_GET_STSNotLike(String value) {
            addCriterion("IMG_GET_STS not like", value, "IMG_GET_STS");
            return (Criteria) this;
        }

        public Criteria andIMG_GET_STSIn(List<String> values) {
            addCriterion("IMG_GET_STS in", values, "IMG_GET_STS");
            return (Criteria) this;
        }

        public Criteria andIMG_GET_STSNotIn(List<String> values) {
            addCriterion("IMG_GET_STS not in", values, "IMG_GET_STS");
            return (Criteria) this;
        }

        public Criteria andIMG_GET_STSBetween(String value1, String value2) {
            addCriterion("IMG_GET_STS between", value1, value2, "IMG_GET_STS");
            return (Criteria) this;
        }

        public Criteria andIMG_GET_STSNotBetween(String value1, String value2) {
            addCriterion("IMG_GET_STS not between", value1, value2, "IMG_GET_STS");
            return (Criteria) this;
        }

        public Criteria andOUT_REPORT_HYOJI_FLGIsNull() {
            addCriterion("OUT_REPORT_HYOJI_FLG is null");
            return (Criteria) this;
        }

        public Criteria andOUT_REPORT_HYOJI_FLGIsNotNull() {
            addCriterion("OUT_REPORT_HYOJI_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andOUT_REPORT_HYOJI_FLGEqualTo(String value) {
            addCriterion("OUT_REPORT_HYOJI_FLG =", value, "OUT_REPORT_HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andOUT_REPORT_HYOJI_FLGNotEqualTo(String value) {
            addCriterion("OUT_REPORT_HYOJI_FLG <>", value, "OUT_REPORT_HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andOUT_REPORT_HYOJI_FLGGreaterThan(String value) {
            addCriterion("OUT_REPORT_HYOJI_FLG >", value, "OUT_REPORT_HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andOUT_REPORT_HYOJI_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("OUT_REPORT_HYOJI_FLG >=", value, "OUT_REPORT_HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andOUT_REPORT_HYOJI_FLGLessThan(String value) {
            addCriterion("OUT_REPORT_HYOJI_FLG <", value, "OUT_REPORT_HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andOUT_REPORT_HYOJI_FLGLessThanOrEqualTo(String value) {
            addCriterion("OUT_REPORT_HYOJI_FLG <=", value, "OUT_REPORT_HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andOUT_REPORT_HYOJI_FLGLike(String value) {
            addCriterion("OUT_REPORT_HYOJI_FLG like", value, "OUT_REPORT_HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andOUT_REPORT_HYOJI_FLGNotLike(String value) {
            addCriterion("OUT_REPORT_HYOJI_FLG not like", value, "OUT_REPORT_HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andOUT_REPORT_HYOJI_FLGIn(List<String> values) {
            addCriterion("OUT_REPORT_HYOJI_FLG in", values, "OUT_REPORT_HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andOUT_REPORT_HYOJI_FLGNotIn(List<String> values) {
            addCriterion("OUT_REPORT_HYOJI_FLG not in", values, "OUT_REPORT_HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andOUT_REPORT_HYOJI_FLGBetween(String value1, String value2) {
            addCriterion("OUT_REPORT_HYOJI_FLG between", value1, value2, "OUT_REPORT_HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andOUT_REPORT_HYOJI_FLGNotBetween(String value1, String value2) {
            addCriterion("OUT_REPORT_HYOJI_FLG not between", value1, value2, "OUT_REPORT_HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGIsNull() {
            addCriterion("SINPO_FLG is null");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGIsNotNull() {
            addCriterion("SINPO_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGEqualTo(String value) {
            addCriterion("SINPO_FLG =", value, "SINPO_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGNotEqualTo(String value) {
            addCriterion("SINPO_FLG <>", value, "SINPO_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGGreaterThan(String value) {
            addCriterion("SINPO_FLG >", value, "SINPO_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("SINPO_FLG >=", value, "SINPO_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGLessThan(String value) {
            addCriterion("SINPO_FLG <", value, "SINPO_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGLessThanOrEqualTo(String value) {
            addCriterion("SINPO_FLG <=", value, "SINPO_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGLike(String value) {
            addCriterion("SINPO_FLG like", value, "SINPO_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGNotLike(String value) {
            addCriterion("SINPO_FLG not like", value, "SINPO_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGIn(List<String> values) {
            addCriterion("SINPO_FLG in", values, "SINPO_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGNotIn(List<String> values) {
            addCriterion("SINPO_FLG not in", values, "SINPO_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGBetween(String value1, String value2) {
            addCriterion("SINPO_FLG between", value1, value2, "SINPO_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGNotBetween(String value1, String value2) {
            addCriterion("SINPO_FLG not between", value1, value2, "SINPO_FLG");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFLikeInsensitive(String value) {
            addCriterion("upper(LN_KB_INF) like", value.toUpperCase(), "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKULikeInsensitive(String value) {
            addCriterion("upper(LN_KB_CHIKU) like", value.toUpperCase(), "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_TSLikeInsensitive(String value) {
            addCriterion("upper(GW_RCV_TS) like", value.toUpperCase(), "GW_RCV_TS");
            return (Criteria) this;
        }

        public Criteria andGW_RCV_IP_ADDRLikeInsensitive(String value) {
            addCriterion("upper(GW_RCV_IP_ADDR) like", value.toUpperCase(), "GW_RCV_IP_ADDR");
            return (Criteria) this;
        }

        public Criteria andGW_HOST_NMLikeInsensitive(String value) {
            addCriterion("upper(GW_HOST_NM) like", value.toUpperCase(), "GW_HOST_NM");
            return (Criteria) this;
        }

        public Criteria andGW_IP_KINDLikeInsensitive(String value) {
            addCriterion("upper(GW_IP_KIND) like", value.toUpperCase(), "GW_IP_KIND");
            return (Criteria) this;
        }

        public Criteria andCMD_VER_9LikeInsensitive(String value) {
            addCriterion("upper(CMD_VER_9) like", value.toUpperCase(), "CMD_VER_9");
            return (Criteria) this;
        }

        public Criteria andTR_NUM_9LikeInsensitive(String value) {
            addCriterion("upper(TR_NUM_9) like", value.toUpperCase(), "TR_NUM_9");
            return (Criteria) this;
        }

        public Criteria andGENERATION_TS_9LikeInsensitive(String value) {
            addCriterion("upper(GENERATION_TS_9) like", value.toUpperCase(), "GENERATION_TS_9");
            return (Criteria) this;
        }

        public Criteria andTRANSMITTER_9_IDLikeInsensitive(String value) {
            addCriterion("upper(TRANSMITTER_9_ID) like", value.toUpperCase(), "TRANSMITTER_9_ID");
            return (Criteria) this;
        }

        public Criteria andDENKEI_9LikeInsensitive(String value) {
            addCriterion("upper(DENKEI_9) like", value.toUpperCase(), "DENKEI_9");
            return (Criteria) this;
        }

        public Criteria andGOUKI_9LikeInsensitive(String value) {
            addCriterion("upper(GOUKI_9) like", value.toUpperCase(), "GOUKI_9");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDR_9LikeInsensitive(String value) {
            addCriterion("upper(SUB_ADDR_9) like", value.toUpperCase(), "SUB_ADDR_9");
            return (Criteria) this;
        }

        public Criteria andLINE_KIND_9LikeInsensitive(String value) {
            addCriterion("upper(LINE_KIND_9) like", value.toUpperCase(), "LINE_KIND_9");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUM_9LikeInsensitive(String value) {
            addCriterion("upper(CMD_SEQ_NUM_9) like", value.toUpperCase(), "CMD_SEQ_NUM_9");
            return (Criteria) this;
        }

        public Criteria andK_INDEX_NUMLikeInsensitive(String value) {
            addCriterion("upper(K_INDEX_NUM) like", value.toUpperCase(), "k_INDEX_NUM");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPELikeInsensitive(String value) {
            addCriterion("upper(MODEL_TYPE) like", value.toUpperCase(), "MODEL_TYPE");
            return (Criteria) this;
        }

        public Criteria andVER_FWLikeInsensitive(String value) {
            addCriterion("upper(VER_FW) like", value.toUpperCase(), "VER_FW");
            return (Criteria) this;
        }

        public Criteria andC0_MODELikeInsensitive(String value) {
            addCriterion("upper(C0_MODE) like", value.toUpperCase(), "c0_MODE");
            return (Criteria) this;
        }

        public Criteria andN0_STS_MAIN_FLGLikeInsensitive(String value) {
            addCriterion("upper(N0_STS_MAIN_FLG) like", value.toUpperCase(), "n0_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_MAIN_FLGLikeInsensitive(String value) {
            addCriterion("upper(DN0_STS_MAIN_FLG) like", value.toUpperCase(), "DN0_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andKN_STS_MAIN_FLGLikeInsensitive(String value) {
            addCriterion("upper(KN_STS_MAIN_FLG) like", value.toUpperCase(), "KN_STS_MAIN_FLG");
            return (Criteria) this;
        }

        public Criteria andN0_STS_SUB_ADDR_FLGLikeInsensitive(String value) {
            addCriterion("upper(N0_STS_SUB_ADDR_FLG) like", value.toUpperCase(), "n0_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andDN0_STS_SUB_ADDR_FLGLikeInsensitive(String value) {
            addCriterion("upper(DN0_STS_SUB_ADDR_FLG) like", value.toUpperCase(), "DN0_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andKN_STS_SUB_ADDR_FLGLikeInsensitive(String value) {
            addCriterion("upper(KN_STS_SUB_ADDR_FLG) like", value.toUpperCase(), "KN_STS_SUB_ADDR_FLG");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMLikeInsensitive(String value) {
            addCriterion("upper(DEV_NUM) like", value.toUpperCase(), "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMLikeInsensitive(String value) {
            addCriterion("upper(DEV_NM) like", value.toUpperCase(), "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andRM_KINDLikeInsensitive(String value) {
            addCriterion("upper(RM_KIND) like", value.toUpperCase(), "RM_KIND");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1LikeInsensitive(String value) {
            addCriterion("upper(SIG_KIND_1) like", value.toUpperCase(), "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2LikeInsensitive(String value) {
            addCriterion("upper(SIG_KIND_2) like", value.toUpperCase(), "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_CODELikeInsensitive(String value) {
            addCriterion("upper(SIG_CODE) like", value.toUpperCase(), "SIG_CODE");
            return (Criteria) this;
        }

        public Criteria andCARD_FRMT_IDLikeInsensitive(String value) {
            addCriterion("upper(CARD_FRMT_ID) like", value.toUpperCase(), "CARD_FRMT_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_KOTEI_IDLikeInsensitive(String value) {
            addCriterion("upper(CARD_KOTEI_ID) like", value.toUpperCase(), "CARD_KOTEI_ID");
            return (Criteria) this;
        }

        public Criteria andCARD_KAHEN_IDLikeInsensitive(String value) {
            addCriterion("upper(CARD_KAHEN_ID) like", value.toUpperCase(), "CARD_KAHEN_ID");
            return (Criteria) this;
        }

        public Criteria andVIDEO_LINK_FLGLikeInsensitive(String value) {
            addCriterion("upper(VIDEO_LINK_FLG) like", value.toUpperCase(), "VIDEO_LINK_FLG");
            return (Criteria) this;
        }

        public Criteria andVIDEO_DEV_NUMLikeInsensitive(String value) {
            addCriterion("upper(VIDEO_DEV_NUM) like", value.toUpperCase(), "VIDEO_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andCAMERA_NOLikeInsensitive(String value) {
            addCriterion("upper(CAMERA_NO) like", value.toUpperCase(), "CAMERA_NO");
            return (Criteria) this;
        }

        public Criteria andVIDEO_FILE_NAMELikeInsensitive(String value) {
            addCriterion("upper(VIDEO_FILE_NAME) like", value.toUpperCase(), "VIDEO_FILE_NAME");
            return (Criteria) this;
        }

        public Criteria andFRAME_RATELikeInsensitive(String value) {
            addCriterion("upper(FRAME_RATE) like", value.toUpperCase(), "FRAME_RATE");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_TIMELikeInsensitive(String value) {
            addCriterion("upper(VIDEO_RECORD_TIME) like", value.toUpperCase(), "VIDEO_RECORD_TIME");
            return (Criteria) this;
        }

        public Criteria andVIDEO_RECORD_COUNTLikeInsensitive(String value) {
            addCriterion("upper(VIDEO_RECORD_COUNT) like", value.toUpperCase(), "VIDEO_RECORD_COUNT");
            return (Criteria) this;
        }

        public Criteria andIMAGE_START_TIMELikeInsensitive(String value) {
            addCriterion("upper(IMAGE_START_TIME) like", value.toUpperCase(), "IMAGE_START_TIME");
            return (Criteria) this;
        }

        public Criteria andIMAGE_COUNTLikeInsensitive(String value) {
            addCriterion("upper(IMAGE_COUNT) like", value.toUpperCase(), "IMAGE_COUNT");
            return (Criteria) this;
        }

        public Criteria andMIC_INTERPHONE_LINK_FLGLikeInsensitive(String value) {
            addCriterion("upper(MIC_INTERPHONE_LINK_FLG) like", value.toUpperCase(), "MIC_INTERPHONE_LINK_FLG");
            return (Criteria) this;
        }

        public Criteria andVOICE_DEV_NUMLikeInsensitive(String value) {
            addCriterion("upper(VOICE_DEV_NUM) like", value.toUpperCase(), "VOICE_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andINTERPHONE_NOLikeInsensitive(String value) {
            addCriterion("upper(INTERPHONE_NO) like", value.toUpperCase(), "INTERPHONE_NO");
            return (Criteria) this;
        }

        public Criteria andMIC_NOLikeInsensitive(String value) {
            addCriterion("upper(MIC_NO) like", value.toUpperCase(), "MIC_NO");
            return (Criteria) this;
        }

        public Criteria andSPEAKER_NOLikeInsensitive(String value) {
            addCriterion("upper(SPEAKER_NO) like", value.toUpperCase(), "SPEAKER_NO");
            return (Criteria) this;
        }

        public Criteria andVOICE_FILE_NAMELikeInsensitive(String value) {
            addCriterion("upper(VOICE_FILE_NAME) like", value.toUpperCase(), "VOICE_FILE_NAME");
            return (Criteria) this;
        }

        public Criteria andVOICE_RECORD_TIMELikeInsensitive(String value) {
            addCriterion("upper(VOICE_RECORD_TIME) like", value.toUpperCase(), "VOICE_RECORD_TIME");
            return (Criteria) this;
        }

        public Criteria andGC_SEND_FLGLikeInsensitive(String value) {
            addCriterion("upper(GC_SEND_FLG) like", value.toUpperCase(), "GC_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andSIG_NMLikeInsensitive(String value) {
            addCriterion("upper(SIG_NM) like", value.toUpperCase(), "SIG_NM");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_KB_SIGLikeInsensitive(String value) {
            addCriterion("upper(LN_QUE_KB_SIG) like", value.toUpperCase(), "LN_QUE_KB_SIG");
            return (Criteria) this;
        }

        public Criteria andRM_FLGLikeInsensitive(String value) {
            addCriterion("upper(RM_FLG) like", value.toUpperCase(), "RM_FLG");
            return (Criteria) this;
        }

        public Criteria andEXCEPT_SIG_FLGLikeInsensitive(String value) {
            addCriterion("upper(EXCEPT_SIG_FLG) like", value.toUpperCase(), "EXCEPT_SIG_FLG");
            return (Criteria) this;
        }

        public Criteria andIMG_NUMLikeInsensitive(String value) {
            addCriterion("upper(IMG_NUM) like", value.toUpperCase(), "IMG_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_PLikeInsensitive(String value) {
            addCriterion("upper(LN_IMG_NUM_P) like", value.toUpperCase(), "LN_IMG_NUM_P");
            return (Criteria) this;
        }

        public Criteria andLN_IMG_NUM_VLikeInsensitive(String value) {
            addCriterion("upper(LN_IMG_NUM_V) like", value.toUpperCase(), "LN_IMG_NUM_V");
            return (Criteria) this;
        }

        public Criteria andIMG_GET_STSLikeInsensitive(String value) {
            addCriterion("upper(IMG_GET_STS) like", value.toUpperCase(), "IMG_GET_STS");
            return (Criteria) this;
        }

        public Criteria andOUT_REPORT_HYOJI_FLGLikeInsensitive(String value) {
            addCriterion("upper(OUT_REPORT_HYOJI_FLG) like", value.toUpperCase(), "OUT_REPORT_HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLGLikeInsensitive(String value) {
            addCriterion("upper(SINPO_FLG) like", value.toUpperCase(), "SINPO_FLG");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * E_KB_INF
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * E_KB_INF null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}