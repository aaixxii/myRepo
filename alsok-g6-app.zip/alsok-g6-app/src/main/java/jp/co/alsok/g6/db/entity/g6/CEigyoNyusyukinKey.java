package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class CEigyoNyusyukinKey implements Serializable {
    /**
     * 送信識別キー
     */
    private String SOSHIN_SHKBTS_KEY;

    /**
     * 送信識別連番
     */
    private String SOSHIN_SHKBTS_SN;

    /**
     * 明細連番
     */
    private String SOSHIN_SHKBTS_MEISAI_SN;

    /**
     * C_EIGYO_NYUSYUKIN
     */
    private static final long serialVersionUID = 1L;

    /**
     * 送信識別キー
     * @return SOSHIN_SHKBTS_KEY 送信識別キー
     */
    public String getSOSHIN_SHKBTS_KEY() {
        return SOSHIN_SHKBTS_KEY;
    }

    /**
     * 送信識別キー
     * @param SOSHIN_SHKBTS_KEY 送信識別キー
     */
    public void setSOSHIN_SHKBTS_KEY(String SOSHIN_SHKBTS_KEY) {
        this.SOSHIN_SHKBTS_KEY = SOSHIN_SHKBTS_KEY == null ? null : SOSHIN_SHKBTS_KEY.trim();
    }

    /**
     * 送信識別連番
     * @return SOSHIN_SHKBTS_SN 送信識別連番
     */
    public String getSOSHIN_SHKBTS_SN() {
        return SOSHIN_SHKBTS_SN;
    }

    /**
     * 送信識別連番
     * @param SOSHIN_SHKBTS_SN 送信識別連番
     */
    public void setSOSHIN_SHKBTS_SN(String SOSHIN_SHKBTS_SN) {
        this.SOSHIN_SHKBTS_SN = SOSHIN_SHKBTS_SN == null ? null : SOSHIN_SHKBTS_SN.trim();
    }

    /**
     * 明細連番
     * @return SOSHIN_SHKBTS_MEISAI_SN 明細連番
     */
    public String getSOSHIN_SHKBTS_MEISAI_SN() {
        return SOSHIN_SHKBTS_MEISAI_SN;
    }

    /**
     * 明細連番
     * @param SOSHIN_SHKBTS_MEISAI_SN 明細連番
     */
    public void setSOSHIN_SHKBTS_MEISAI_SN(String SOSHIN_SHKBTS_MEISAI_SN) {
        this.SOSHIN_SHKBTS_MEISAI_SN = SOSHIN_SHKBTS_MEISAI_SN == null ? null : SOSHIN_SHKBTS_MEISAI_SN.trim();
    }
}