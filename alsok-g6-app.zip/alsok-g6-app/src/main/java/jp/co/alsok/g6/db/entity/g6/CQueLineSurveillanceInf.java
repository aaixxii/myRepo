package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class CQueLineSurveillanceInf implements Serializable {
    /**
     * LN_回線監視情報要求キュー論理番号
     */
    private String LN_QUE_LINE_SURVEILLANCE_INF;

    /**
     * 送信機ID
     */
    private String TRANSMITTER_ID;

    /**
     * 発信元ホスト名
     */
    private String HOST_NM;

    /**
     * エンキュー日時
     */
    private Date ENQ_TS;

    /**
     * デキュー日時
     */
    private Date DEQ_TS;

    /**
     * 状態
     */
    private String STS;

    /**
     * センターエラー詳細
     */
    private String CENTER_ERR_DTL;

    /**
     * RMSVコマンド通知結果
     */
    private String RM_RESULT;

    /**
     * RMSVコマンド通知エラーコード
     */
    private String RM_ERR_CD;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * C_QUE_LINE_SURVEILLANCE_INF
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_回線監視情報要求キュー論理番号
     * @return LN_QUE_LINE_SURVEILLANCE_INF LN_回線監視情報要求キュー論理番号
     */
    public String getLN_QUE_LINE_SURVEILLANCE_INF() {
        return LN_QUE_LINE_SURVEILLANCE_INF;
    }

    /**
     * LN_回線監視情報要求キュー論理番号
     * @param LN_QUE_LINE_SURVEILLANCE_INF LN_回線監視情報要求キュー論理番号
     */
    public void setLN_QUE_LINE_SURVEILLANCE_INF(String LN_QUE_LINE_SURVEILLANCE_INF) {
        this.LN_QUE_LINE_SURVEILLANCE_INF = LN_QUE_LINE_SURVEILLANCE_INF == null ? null : LN_QUE_LINE_SURVEILLANCE_INF.trim();
    }

    /**
     * 送信機ID
     * @return TRANSMITTER_ID 送信機ID
     */
    public String getTRANSMITTER_ID() {
        return TRANSMITTER_ID;
    }

    /**
     * 送信機ID
     * @param TRANSMITTER_ID 送信機ID
     */
    public void setTRANSMITTER_ID(String TRANSMITTER_ID) {
        this.TRANSMITTER_ID = TRANSMITTER_ID == null ? null : TRANSMITTER_ID.trim();
    }

    /**
     * 発信元ホスト名
     * @return HOST_NM 発信元ホスト名
     */
    public String getHOST_NM() {
        return HOST_NM;
    }

    /**
     * 発信元ホスト名
     * @param HOST_NM 発信元ホスト名
     */
    public void setHOST_NM(String HOST_NM) {
        this.HOST_NM = HOST_NM == null ? null : HOST_NM.trim();
    }

    /**
     * エンキュー日時
     * @return ENQ_TS エンキュー日時
     */
    public Date getENQ_TS() {
        return ENQ_TS;
    }

    /**
     * エンキュー日時
     * @param ENQ_TS エンキュー日時
     */
    public void setENQ_TS(Date ENQ_TS) {
        this.ENQ_TS = ENQ_TS;
    }

    /**
     * デキュー日時
     * @return DEQ_TS デキュー日時
     */
    public Date getDEQ_TS() {
        return DEQ_TS;
    }

    /**
     * デキュー日時
     * @param DEQ_TS デキュー日時
     */
    public void setDEQ_TS(Date DEQ_TS) {
        this.DEQ_TS = DEQ_TS;
    }

    /**
     * 状態
     * @return STS 状態
     */
    public String getSTS() {
        return STS;
    }

    /**
     * 状態
     * @param STS 状態
     */
    public void setSTS(String STS) {
        this.STS = STS == null ? null : STS.trim();
    }

    /**
     * センターエラー詳細
     * @return CENTER_ERR_DTL センターエラー詳細
     */
    public String getCENTER_ERR_DTL() {
        return CENTER_ERR_DTL;
    }

    /**
     * センターエラー詳細
     * @param CENTER_ERR_DTL センターエラー詳細
     */
    public void setCENTER_ERR_DTL(String CENTER_ERR_DTL) {
        this.CENTER_ERR_DTL = CENTER_ERR_DTL == null ? null : CENTER_ERR_DTL.trim();
    }

    /**
     * RMSVコマンド通知結果
     * @return RM_RESULT RMSVコマンド通知結果
     */
    public String getRM_RESULT() {
        return RM_RESULT;
    }

    /**
     * RMSVコマンド通知結果
     * @param RM_RESULT RMSVコマンド通知結果
     */
    public void setRM_RESULT(String RM_RESULT) {
        this.RM_RESULT = RM_RESULT == null ? null : RM_RESULT.trim();
    }

    /**
     * RMSVコマンド通知エラーコード
     * @return RM_ERR_CD RMSVコマンド通知エラーコード
     */
    public String getRM_ERR_CD() {
        return RM_ERR_CD;
    }

    /**
     * RMSVコマンド通知エラーコード
     * @param RM_ERR_CD RMSVコマンド通知エラーコード
     */
    public void setRM_ERR_CD(String RM_ERR_CD) {
        this.RM_ERR_CD = RM_ERR_CD == null ? null : RM_ERR_CD.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}