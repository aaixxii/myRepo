package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HInoutLogExample {
    /**
     * H_INOUT_LOG
     */
    protected String orderByClause;

    /**
     * H_INOUT_LOG
     */
    protected boolean distinct;

    /**
     * H_INOUT_LOG
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public HInoutLogExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * H_INOUT_LOG null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_INOUT_LOGIsNull() {
            addCriterion("LN_INOUT_LOG is null");
            return (Criteria) this;
        }

        public Criteria andLN_INOUT_LOGIsNotNull() {
            addCriterion("LN_INOUT_LOG is not null");
            return (Criteria) this;
        }

        public Criteria andLN_INOUT_LOGEqualTo(String value) {
            addCriterion("LN_INOUT_LOG =", value, "LN_INOUT_LOG");
            return (Criteria) this;
        }

        public Criteria andLN_INOUT_LOGNotEqualTo(String value) {
            addCriterion("LN_INOUT_LOG <>", value, "LN_INOUT_LOG");
            return (Criteria) this;
        }

        public Criteria andLN_INOUT_LOGGreaterThan(String value) {
            addCriterion("LN_INOUT_LOG >", value, "LN_INOUT_LOG");
            return (Criteria) this;
        }

        public Criteria andLN_INOUT_LOGGreaterThanOrEqualTo(String value) {
            addCriterion("LN_INOUT_LOG >=", value, "LN_INOUT_LOG");
            return (Criteria) this;
        }

        public Criteria andLN_INOUT_LOGLessThan(String value) {
            addCriterion("LN_INOUT_LOG <", value, "LN_INOUT_LOG");
            return (Criteria) this;
        }

        public Criteria andLN_INOUT_LOGLessThanOrEqualTo(String value) {
            addCriterion("LN_INOUT_LOG <=", value, "LN_INOUT_LOG");
            return (Criteria) this;
        }

        public Criteria andLN_INOUT_LOGLike(String value) {
            addCriterion("LN_INOUT_LOG like", value, "LN_INOUT_LOG");
            return (Criteria) this;
        }

        public Criteria andLN_INOUT_LOGNotLike(String value) {
            addCriterion("LN_INOUT_LOG not like", value, "LN_INOUT_LOG");
            return (Criteria) this;
        }

        public Criteria andLN_INOUT_LOGIn(List<String> values) {
            addCriterion("LN_INOUT_LOG in", values, "LN_INOUT_LOG");
            return (Criteria) this;
        }

        public Criteria andLN_INOUT_LOGNotIn(List<String> values) {
            addCriterion("LN_INOUT_LOG not in", values, "LN_INOUT_LOG");
            return (Criteria) this;
        }

        public Criteria andLN_INOUT_LOGBetween(String value1, String value2) {
            addCriterion("LN_INOUT_LOG between", value1, value2, "LN_INOUT_LOG");
            return (Criteria) this;
        }

        public Criteria andLN_INOUT_LOGNotBetween(String value1, String value2) {
            addCriterion("LN_INOUT_LOG not between", value1, value2, "LN_INOUT_LOG");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSIsNull() {
            addCriterion("HASSEI_TS is null");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSIsNotNull() {
            addCriterion("HASSEI_TS is not null");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSEqualTo(Date value) {
            addCriterion("HASSEI_TS =", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSNotEqualTo(Date value) {
            addCriterion("HASSEI_TS <>", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSGreaterThan(Date value) {
            addCriterion("HASSEI_TS >", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("HASSEI_TS >=", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSLessThan(Date value) {
            addCriterion("HASSEI_TS <", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSLessThanOrEqualTo(Date value) {
            addCriterion("HASSEI_TS <=", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSIn(List<Date> values) {
            addCriterion("HASSEI_TS in", values, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSNotIn(List<Date> values) {
            addCriterion("HASSEI_TS not in", values, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSBetween(Date value1, Date value2) {
            addCriterion("HASSEI_TS between", value1, value2, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSNotBetween(Date value1, Date value2) {
            addCriterion("HASSEI_TS not between", value1, value2, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMIsNull() {
            addCriterion("KEIBI_NM is null");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMIsNotNull() {
            addCriterion("KEIBI_NM is not null");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMEqualTo(String value) {
            addCriterion("KEIBI_NM =", value, "KEIBI_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMNotEqualTo(String value) {
            addCriterion("KEIBI_NM <>", value, "KEIBI_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMGreaterThan(String value) {
            addCriterion("KEIBI_NM >", value, "KEIBI_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMGreaterThanOrEqualTo(String value) {
            addCriterion("KEIBI_NM >=", value, "KEIBI_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMLessThan(String value) {
            addCriterion("KEIBI_NM <", value, "KEIBI_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMLessThanOrEqualTo(String value) {
            addCriterion("KEIBI_NM <=", value, "KEIBI_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMLike(String value) {
            addCriterion("KEIBI_NM like", value, "KEIBI_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMNotLike(String value) {
            addCriterion("KEIBI_NM not like", value, "KEIBI_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMIn(List<String> values) {
            addCriterion("KEIBI_NM in", values, "KEIBI_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMNotIn(List<String> values) {
            addCriterion("KEIBI_NM not in", values, "KEIBI_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMBetween(String value1, String value2) {
            addCriterion("KEIBI_NM between", value1, value2, "KEIBI_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMNotBetween(String value1, String value2) {
            addCriterion("KEIBI_NM not between", value1, value2, "KEIBI_NM");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMIsNull() {
            addCriterion("SD_KOBETU_NM is null");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMIsNotNull() {
            addCriterion("SD_KOBETU_NM is not null");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMEqualTo(String value) {
            addCriterion("SD_KOBETU_NM =", value, "SD_KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMNotEqualTo(String value) {
            addCriterion("SD_KOBETU_NM <>", value, "SD_KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMGreaterThan(String value) {
            addCriterion("SD_KOBETU_NM >", value, "SD_KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMGreaterThanOrEqualTo(String value) {
            addCriterion("SD_KOBETU_NM >=", value, "SD_KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMLessThan(String value) {
            addCriterion("SD_KOBETU_NM <", value, "SD_KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMLessThanOrEqualTo(String value) {
            addCriterion("SD_KOBETU_NM <=", value, "SD_KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMLike(String value) {
            addCriterion("SD_KOBETU_NM like", value, "SD_KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMNotLike(String value) {
            addCriterion("SD_KOBETU_NM not like", value, "SD_KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMIn(List<String> values) {
            addCriterion("SD_KOBETU_NM in", values, "SD_KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMNotIn(List<String> values) {
            addCriterion("SD_KOBETU_NM not in", values, "SD_KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMBetween(String value1, String value2) {
            addCriterion("SD_KOBETU_NM between", value1, value2, "SD_KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMNotBetween(String value1, String value2) {
            addCriterion("SD_KOBETU_NM not between", value1, value2, "SD_KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andROOM_NMIsNull() {
            addCriterion("ROOM_NM is null");
            return (Criteria) this;
        }

        public Criteria andROOM_NMIsNotNull() {
            addCriterion("ROOM_NM is not null");
            return (Criteria) this;
        }

        public Criteria andROOM_NMEqualTo(String value) {
            addCriterion("ROOM_NM =", value, "ROOM_NM");
            return (Criteria) this;
        }

        public Criteria andROOM_NMNotEqualTo(String value) {
            addCriterion("ROOM_NM <>", value, "ROOM_NM");
            return (Criteria) this;
        }

        public Criteria andROOM_NMGreaterThan(String value) {
            addCriterion("ROOM_NM >", value, "ROOM_NM");
            return (Criteria) this;
        }

        public Criteria andROOM_NMGreaterThanOrEqualTo(String value) {
            addCriterion("ROOM_NM >=", value, "ROOM_NM");
            return (Criteria) this;
        }

        public Criteria andROOM_NMLessThan(String value) {
            addCriterion("ROOM_NM <", value, "ROOM_NM");
            return (Criteria) this;
        }

        public Criteria andROOM_NMLessThanOrEqualTo(String value) {
            addCriterion("ROOM_NM <=", value, "ROOM_NM");
            return (Criteria) this;
        }

        public Criteria andROOM_NMLike(String value) {
            addCriterion("ROOM_NM like", value, "ROOM_NM");
            return (Criteria) this;
        }

        public Criteria andROOM_NMNotLike(String value) {
            addCriterion("ROOM_NM not like", value, "ROOM_NM");
            return (Criteria) this;
        }

        public Criteria andROOM_NMIn(List<String> values) {
            addCriterion("ROOM_NM in", values, "ROOM_NM");
            return (Criteria) this;
        }

        public Criteria andROOM_NMNotIn(List<String> values) {
            addCriterion("ROOM_NM not in", values, "ROOM_NM");
            return (Criteria) this;
        }

        public Criteria andROOM_NMBetween(String value1, String value2) {
            addCriterion("ROOM_NM between", value1, value2, "ROOM_NM");
            return (Criteria) this;
        }

        public Criteria andROOM_NMNotBetween(String value1, String value2) {
            addCriterion("ROOM_NM not between", value1, value2, "ROOM_NM");
            return (Criteria) this;
        }

        public Criteria andPRE_ROOM_NMIsNull() {
            addCriterion("PRE_ROOM_NM is null");
            return (Criteria) this;
        }

        public Criteria andPRE_ROOM_NMIsNotNull() {
            addCriterion("PRE_ROOM_NM is not null");
            return (Criteria) this;
        }

        public Criteria andPRE_ROOM_NMEqualTo(String value) {
            addCriterion("PRE_ROOM_NM =", value, "PRE_ROOM_NM");
            return (Criteria) this;
        }

        public Criteria andPRE_ROOM_NMNotEqualTo(String value) {
            addCriterion("PRE_ROOM_NM <>", value, "PRE_ROOM_NM");
            return (Criteria) this;
        }

        public Criteria andPRE_ROOM_NMGreaterThan(String value) {
            addCriterion("PRE_ROOM_NM >", value, "PRE_ROOM_NM");
            return (Criteria) this;
        }

        public Criteria andPRE_ROOM_NMGreaterThanOrEqualTo(String value) {
            addCriterion("PRE_ROOM_NM >=", value, "PRE_ROOM_NM");
            return (Criteria) this;
        }

        public Criteria andPRE_ROOM_NMLessThan(String value) {
            addCriterion("PRE_ROOM_NM <", value, "PRE_ROOM_NM");
            return (Criteria) this;
        }

        public Criteria andPRE_ROOM_NMLessThanOrEqualTo(String value) {
            addCriterion("PRE_ROOM_NM <=", value, "PRE_ROOM_NM");
            return (Criteria) this;
        }

        public Criteria andPRE_ROOM_NMLike(String value) {
            addCriterion("PRE_ROOM_NM like", value, "PRE_ROOM_NM");
            return (Criteria) this;
        }

        public Criteria andPRE_ROOM_NMNotLike(String value) {
            addCriterion("PRE_ROOM_NM not like", value, "PRE_ROOM_NM");
            return (Criteria) this;
        }

        public Criteria andPRE_ROOM_NMIn(List<String> values) {
            addCriterion("PRE_ROOM_NM in", values, "PRE_ROOM_NM");
            return (Criteria) this;
        }

        public Criteria andPRE_ROOM_NMNotIn(List<String> values) {
            addCriterion("PRE_ROOM_NM not in", values, "PRE_ROOM_NM");
            return (Criteria) this;
        }

        public Criteria andPRE_ROOM_NMBetween(String value1, String value2) {
            addCriterion("PRE_ROOM_NM between", value1, value2, "PRE_ROOM_NM");
            return (Criteria) this;
        }

        public Criteria andPRE_ROOM_NMNotBetween(String value1, String value2) {
            addCriterion("PRE_ROOM_NM not between", value1, value2, "PRE_ROOM_NM");
            return (Criteria) this;
        }

        public Criteria andKOKUIN_NUMIsNull() {
            addCriterion("KOKUIN_NUM is null");
            return (Criteria) this;
        }

        public Criteria andKOKUIN_NUMIsNotNull() {
            addCriterion("KOKUIN_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andKOKUIN_NUMEqualTo(String value) {
            addCriterion("KOKUIN_NUM =", value, "KOKUIN_NUM");
            return (Criteria) this;
        }

        public Criteria andKOKUIN_NUMNotEqualTo(String value) {
            addCriterion("KOKUIN_NUM <>", value, "KOKUIN_NUM");
            return (Criteria) this;
        }

        public Criteria andKOKUIN_NUMGreaterThan(String value) {
            addCriterion("KOKUIN_NUM >", value, "KOKUIN_NUM");
            return (Criteria) this;
        }

        public Criteria andKOKUIN_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("KOKUIN_NUM >=", value, "KOKUIN_NUM");
            return (Criteria) this;
        }

        public Criteria andKOKUIN_NUMLessThan(String value) {
            addCriterion("KOKUIN_NUM <", value, "KOKUIN_NUM");
            return (Criteria) this;
        }

        public Criteria andKOKUIN_NUMLessThanOrEqualTo(String value) {
            addCriterion("KOKUIN_NUM <=", value, "KOKUIN_NUM");
            return (Criteria) this;
        }

        public Criteria andKOKUIN_NUMLike(String value) {
            addCriterion("KOKUIN_NUM like", value, "KOKUIN_NUM");
            return (Criteria) this;
        }

        public Criteria andKOKUIN_NUMNotLike(String value) {
            addCriterion("KOKUIN_NUM not like", value, "KOKUIN_NUM");
            return (Criteria) this;
        }

        public Criteria andKOKUIN_NUMIn(List<String> values) {
            addCriterion("KOKUIN_NUM in", values, "KOKUIN_NUM");
            return (Criteria) this;
        }

        public Criteria andKOKUIN_NUMNotIn(List<String> values) {
            addCriterion("KOKUIN_NUM not in", values, "KOKUIN_NUM");
            return (Criteria) this;
        }

        public Criteria andKOKUIN_NUMBetween(String value1, String value2) {
            addCriterion("KOKUIN_NUM between", value1, value2, "KOKUIN_NUM");
            return (Criteria) this;
        }

        public Criteria andKOKUIN_NUMNotBetween(String value1, String value2) {
            addCriterion("KOKUIN_NUM not between", value1, value2, "KOKUIN_NUM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMIsNull() {
            addCriterion("USER_NM is null");
            return (Criteria) this;
        }

        public Criteria andUSER_NMIsNotNull() {
            addCriterion("USER_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUSER_NMEqualTo(String value) {
            addCriterion("USER_NM =", value, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMNotEqualTo(String value) {
            addCriterion("USER_NM <>", value, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMGreaterThan(String value) {
            addCriterion("USER_NM >", value, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMGreaterThanOrEqualTo(String value) {
            addCriterion("USER_NM >=", value, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMLessThan(String value) {
            addCriterion("USER_NM <", value, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMLessThanOrEqualTo(String value) {
            addCriterion("USER_NM <=", value, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMLike(String value) {
            addCriterion("USER_NM like", value, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMNotLike(String value) {
            addCriterion("USER_NM not like", value, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMIn(List<String> values) {
            addCriterion("USER_NM in", values, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMNotIn(List<String> values) {
            addCriterion("USER_NM not in", values, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMBetween(String value1, String value2) {
            addCriterion("USER_NM between", value1, value2, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMNotBetween(String value1, String value2) {
            addCriterion("USER_NM not between", value1, value2, "USER_NM");
            return (Criteria) this;
        }

        public Criteria andDEPA_NMIsNull() {
            addCriterion("DEPA_NM is null");
            return (Criteria) this;
        }

        public Criteria andDEPA_NMIsNotNull() {
            addCriterion("DEPA_NM is not null");
            return (Criteria) this;
        }

        public Criteria andDEPA_NMEqualTo(String value) {
            addCriterion("DEPA_NM =", value, "DEPA_NM");
            return (Criteria) this;
        }

        public Criteria andDEPA_NMNotEqualTo(String value) {
            addCriterion("DEPA_NM <>", value, "DEPA_NM");
            return (Criteria) this;
        }

        public Criteria andDEPA_NMGreaterThan(String value) {
            addCriterion("DEPA_NM >", value, "DEPA_NM");
            return (Criteria) this;
        }

        public Criteria andDEPA_NMGreaterThanOrEqualTo(String value) {
            addCriterion("DEPA_NM >=", value, "DEPA_NM");
            return (Criteria) this;
        }

        public Criteria andDEPA_NMLessThan(String value) {
            addCriterion("DEPA_NM <", value, "DEPA_NM");
            return (Criteria) this;
        }

        public Criteria andDEPA_NMLessThanOrEqualTo(String value) {
            addCriterion("DEPA_NM <=", value, "DEPA_NM");
            return (Criteria) this;
        }

        public Criteria andDEPA_NMLike(String value) {
            addCriterion("DEPA_NM like", value, "DEPA_NM");
            return (Criteria) this;
        }

        public Criteria andDEPA_NMNotLike(String value) {
            addCriterion("DEPA_NM not like", value, "DEPA_NM");
            return (Criteria) this;
        }

        public Criteria andDEPA_NMIn(List<String> values) {
            addCriterion("DEPA_NM in", values, "DEPA_NM");
            return (Criteria) this;
        }

        public Criteria andDEPA_NMNotIn(List<String> values) {
            addCriterion("DEPA_NM not in", values, "DEPA_NM");
            return (Criteria) this;
        }

        public Criteria andDEPA_NMBetween(String value1, String value2) {
            addCriterion("DEPA_NM between", value1, value2, "DEPA_NM");
            return (Criteria) this;
        }

        public Criteria andDEPA_NMNotBetween(String value1, String value2) {
            addCriterion("DEPA_NM not between", value1, value2, "DEPA_NM");
            return (Criteria) this;
        }

        public Criteria andPOSI_NMIsNull() {
            addCriterion("POSI_NM is null");
            return (Criteria) this;
        }

        public Criteria andPOSI_NMIsNotNull() {
            addCriterion("POSI_NM is not null");
            return (Criteria) this;
        }

        public Criteria andPOSI_NMEqualTo(String value) {
            addCriterion("POSI_NM =", value, "POSI_NM");
            return (Criteria) this;
        }

        public Criteria andPOSI_NMNotEqualTo(String value) {
            addCriterion("POSI_NM <>", value, "POSI_NM");
            return (Criteria) this;
        }

        public Criteria andPOSI_NMGreaterThan(String value) {
            addCriterion("POSI_NM >", value, "POSI_NM");
            return (Criteria) this;
        }

        public Criteria andPOSI_NMGreaterThanOrEqualTo(String value) {
            addCriterion("POSI_NM >=", value, "POSI_NM");
            return (Criteria) this;
        }

        public Criteria andPOSI_NMLessThan(String value) {
            addCriterion("POSI_NM <", value, "POSI_NM");
            return (Criteria) this;
        }

        public Criteria andPOSI_NMLessThanOrEqualTo(String value) {
            addCriterion("POSI_NM <=", value, "POSI_NM");
            return (Criteria) this;
        }

        public Criteria andPOSI_NMLike(String value) {
            addCriterion("POSI_NM like", value, "POSI_NM");
            return (Criteria) this;
        }

        public Criteria andPOSI_NMNotLike(String value) {
            addCriterion("POSI_NM not like", value, "POSI_NM");
            return (Criteria) this;
        }

        public Criteria andPOSI_NMIn(List<String> values) {
            addCriterion("POSI_NM in", values, "POSI_NM");
            return (Criteria) this;
        }

        public Criteria andPOSI_NMNotIn(List<String> values) {
            addCriterion("POSI_NM not in", values, "POSI_NM");
            return (Criteria) this;
        }

        public Criteria andPOSI_NMBetween(String value1, String value2) {
            addCriterion("POSI_NM between", value1, value2, "POSI_NM");
            return (Criteria) this;
        }

        public Criteria andPOSI_NMNotBetween(String value1, String value2) {
            addCriterion("POSI_NM not between", value1, value2, "POSI_NM");
            return (Criteria) this;
        }

        public Criteria andGAZO_USE_FLGIsNull() {
            addCriterion("GAZO_USE_FLG is null");
            return (Criteria) this;
        }

        public Criteria andGAZO_USE_FLGIsNotNull() {
            addCriterion("GAZO_USE_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andGAZO_USE_FLGEqualTo(String value) {
            addCriterion("GAZO_USE_FLG =", value, "GAZO_USE_FLG");
            return (Criteria) this;
        }

        public Criteria andGAZO_USE_FLGNotEqualTo(String value) {
            addCriterion("GAZO_USE_FLG <>", value, "GAZO_USE_FLG");
            return (Criteria) this;
        }

        public Criteria andGAZO_USE_FLGGreaterThan(String value) {
            addCriterion("GAZO_USE_FLG >", value, "GAZO_USE_FLG");
            return (Criteria) this;
        }

        public Criteria andGAZO_USE_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("GAZO_USE_FLG >=", value, "GAZO_USE_FLG");
            return (Criteria) this;
        }

        public Criteria andGAZO_USE_FLGLessThan(String value) {
            addCriterion("GAZO_USE_FLG <", value, "GAZO_USE_FLG");
            return (Criteria) this;
        }

        public Criteria andGAZO_USE_FLGLessThanOrEqualTo(String value) {
            addCriterion("GAZO_USE_FLG <=", value, "GAZO_USE_FLG");
            return (Criteria) this;
        }

        public Criteria andGAZO_USE_FLGLike(String value) {
            addCriterion("GAZO_USE_FLG like", value, "GAZO_USE_FLG");
            return (Criteria) this;
        }

        public Criteria andGAZO_USE_FLGNotLike(String value) {
            addCriterion("GAZO_USE_FLG not like", value, "GAZO_USE_FLG");
            return (Criteria) this;
        }

        public Criteria andGAZO_USE_FLGIn(List<String> values) {
            addCriterion("GAZO_USE_FLG in", values, "GAZO_USE_FLG");
            return (Criteria) this;
        }

        public Criteria andGAZO_USE_FLGNotIn(List<String> values) {
            addCriterion("GAZO_USE_FLG not in", values, "GAZO_USE_FLG");
            return (Criteria) this;
        }

        public Criteria andGAZO_USE_FLGBetween(String value1, String value2) {
            addCriterion("GAZO_USE_FLG between", value1, value2, "GAZO_USE_FLG");
            return (Criteria) this;
        }

        public Criteria andGAZO_USE_FLGNotBetween(String value1, String value2) {
            addCriterion("GAZO_USE_FLG not between", value1, value2, "GAZO_USE_FLG");
            return (Criteria) this;
        }

        public Criteria andGAZO_FILE_PATHIsNull() {
            addCriterion("GAZO_FILE_PATH is null");
            return (Criteria) this;
        }

        public Criteria andGAZO_FILE_PATHIsNotNull() {
            addCriterion("GAZO_FILE_PATH is not null");
            return (Criteria) this;
        }

        public Criteria andGAZO_FILE_PATHEqualTo(String value) {
            addCriterion("GAZO_FILE_PATH =", value, "GAZO_FILE_PATH");
            return (Criteria) this;
        }

        public Criteria andGAZO_FILE_PATHNotEqualTo(String value) {
            addCriterion("GAZO_FILE_PATH <>", value, "GAZO_FILE_PATH");
            return (Criteria) this;
        }

        public Criteria andGAZO_FILE_PATHGreaterThan(String value) {
            addCriterion("GAZO_FILE_PATH >", value, "GAZO_FILE_PATH");
            return (Criteria) this;
        }

        public Criteria andGAZO_FILE_PATHGreaterThanOrEqualTo(String value) {
            addCriterion("GAZO_FILE_PATH >=", value, "GAZO_FILE_PATH");
            return (Criteria) this;
        }

        public Criteria andGAZO_FILE_PATHLessThan(String value) {
            addCriterion("GAZO_FILE_PATH <", value, "GAZO_FILE_PATH");
            return (Criteria) this;
        }

        public Criteria andGAZO_FILE_PATHLessThanOrEqualTo(String value) {
            addCriterion("GAZO_FILE_PATH <=", value, "GAZO_FILE_PATH");
            return (Criteria) this;
        }

        public Criteria andGAZO_FILE_PATHLike(String value) {
            addCriterion("GAZO_FILE_PATH like", value, "GAZO_FILE_PATH");
            return (Criteria) this;
        }

        public Criteria andGAZO_FILE_PATHNotLike(String value) {
            addCriterion("GAZO_FILE_PATH not like", value, "GAZO_FILE_PATH");
            return (Criteria) this;
        }

        public Criteria andGAZO_FILE_PATHIn(List<String> values) {
            addCriterion("GAZO_FILE_PATH in", values, "GAZO_FILE_PATH");
            return (Criteria) this;
        }

        public Criteria andGAZO_FILE_PATHNotIn(List<String> values) {
            addCriterion("GAZO_FILE_PATH not in", values, "GAZO_FILE_PATH");
            return (Criteria) this;
        }

        public Criteria andGAZO_FILE_PATHBetween(String value1, String value2) {
            addCriterion("GAZO_FILE_PATH between", value1, value2, "GAZO_FILE_PATH");
            return (Criteria) this;
        }

        public Criteria andGAZO_FILE_PATHNotBetween(String value1, String value2) {
            addCriterion("GAZO_FILE_PATH not between", value1, value2, "GAZO_FILE_PATH");
            return (Criteria) this;
        }

        public Criteria andHIST_KINDIsNull() {
            addCriterion("HIST_KIND is null");
            return (Criteria) this;
        }

        public Criteria andHIST_KINDIsNotNull() {
            addCriterion("HIST_KIND is not null");
            return (Criteria) this;
        }

        public Criteria andHIST_KINDEqualTo(String value) {
            addCriterion("HIST_KIND =", value, "HIST_KIND");
            return (Criteria) this;
        }

        public Criteria andHIST_KINDNotEqualTo(String value) {
            addCriterion("HIST_KIND <>", value, "HIST_KIND");
            return (Criteria) this;
        }

        public Criteria andHIST_KINDGreaterThan(String value) {
            addCriterion("HIST_KIND >", value, "HIST_KIND");
            return (Criteria) this;
        }

        public Criteria andHIST_KINDGreaterThanOrEqualTo(String value) {
            addCriterion("HIST_KIND >=", value, "HIST_KIND");
            return (Criteria) this;
        }

        public Criteria andHIST_KINDLessThan(String value) {
            addCriterion("HIST_KIND <", value, "HIST_KIND");
            return (Criteria) this;
        }

        public Criteria andHIST_KINDLessThanOrEqualTo(String value) {
            addCriterion("HIST_KIND <=", value, "HIST_KIND");
            return (Criteria) this;
        }

        public Criteria andHIST_KINDLike(String value) {
            addCriterion("HIST_KIND like", value, "HIST_KIND");
            return (Criteria) this;
        }

        public Criteria andHIST_KINDNotLike(String value) {
            addCriterion("HIST_KIND not like", value, "HIST_KIND");
            return (Criteria) this;
        }

        public Criteria andHIST_KINDIn(List<String> values) {
            addCriterion("HIST_KIND in", values, "HIST_KIND");
            return (Criteria) this;
        }

        public Criteria andHIST_KINDNotIn(List<String> values) {
            addCriterion("HIST_KIND not in", values, "HIST_KIND");
            return (Criteria) this;
        }

        public Criteria andHIST_KINDBetween(String value1, String value2) {
            addCriterion("HIST_KIND between", value1, value2, "HIST_KIND");
            return (Criteria) this;
        }

        public Criteria andHIST_KINDNotBetween(String value1, String value2) {
            addCriterion("HIST_KIND not between", value1, value2, "HIST_KIND");
            return (Criteria) this;
        }

        public Criteria andHIST_NMIsNull() {
            addCriterion("HIST_NM is null");
            return (Criteria) this;
        }

        public Criteria andHIST_NMIsNotNull() {
            addCriterion("HIST_NM is not null");
            return (Criteria) this;
        }

        public Criteria andHIST_NMEqualTo(String value) {
            addCriterion("HIST_NM =", value, "HIST_NM");
            return (Criteria) this;
        }

        public Criteria andHIST_NMNotEqualTo(String value) {
            addCriterion("HIST_NM <>", value, "HIST_NM");
            return (Criteria) this;
        }

        public Criteria andHIST_NMGreaterThan(String value) {
            addCriterion("HIST_NM >", value, "HIST_NM");
            return (Criteria) this;
        }

        public Criteria andHIST_NMGreaterThanOrEqualTo(String value) {
            addCriterion("HIST_NM >=", value, "HIST_NM");
            return (Criteria) this;
        }

        public Criteria andHIST_NMLessThan(String value) {
            addCriterion("HIST_NM <", value, "HIST_NM");
            return (Criteria) this;
        }

        public Criteria andHIST_NMLessThanOrEqualTo(String value) {
            addCriterion("HIST_NM <=", value, "HIST_NM");
            return (Criteria) this;
        }

        public Criteria andHIST_NMLike(String value) {
            addCriterion("HIST_NM like", value, "HIST_NM");
            return (Criteria) this;
        }

        public Criteria andHIST_NMNotLike(String value) {
            addCriterion("HIST_NM not like", value, "HIST_NM");
            return (Criteria) this;
        }

        public Criteria andHIST_NMIn(List<String> values) {
            addCriterion("HIST_NM in", values, "HIST_NM");
            return (Criteria) this;
        }

        public Criteria andHIST_NMNotIn(List<String> values) {
            addCriterion("HIST_NM not in", values, "HIST_NM");
            return (Criteria) this;
        }

        public Criteria andHIST_NMBetween(String value1, String value2) {
            addCriterion("HIST_NM between", value1, value2, "HIST_NM");
            return (Criteria) this;
        }

        public Criteria andHIST_NMNotBetween(String value1, String value2) {
            addCriterion("HIST_NM not between", value1, value2, "HIST_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andLN_INOUT_LOGLikeInsensitive(String value) {
            addCriterion("upper(LN_INOUT_LOG) like", value.toUpperCase(), "LN_INOUT_LOG");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NMLikeInsensitive(String value) {
            addCriterion("upper(KEIBI_NM) like", value.toUpperCase(), "KEIBI_NM");
            return (Criteria) this;
        }

        public Criteria andSD_KOBETU_NMLikeInsensitive(String value) {
            addCriterion("upper(SD_KOBETU_NM) like", value.toUpperCase(), "SD_KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andROOM_NMLikeInsensitive(String value) {
            addCriterion("upper(ROOM_NM) like", value.toUpperCase(), "ROOM_NM");
            return (Criteria) this;
        }

        public Criteria andPRE_ROOM_NMLikeInsensitive(String value) {
            addCriterion("upper(PRE_ROOM_NM) like", value.toUpperCase(), "PRE_ROOM_NM");
            return (Criteria) this;
        }

        public Criteria andKOKUIN_NUMLikeInsensitive(String value) {
            addCriterion("upper(KOKUIN_NUM) like", value.toUpperCase(), "KOKUIN_NUM");
            return (Criteria) this;
        }

        public Criteria andUSER_NMLikeInsensitive(String value) {
            addCriterion("upper(USER_NM) like", value.toUpperCase(), "USER_NM");
            return (Criteria) this;
        }

        public Criteria andDEPA_NMLikeInsensitive(String value) {
            addCriterion("upper(DEPA_NM) like", value.toUpperCase(), "DEPA_NM");
            return (Criteria) this;
        }

        public Criteria andPOSI_NMLikeInsensitive(String value) {
            addCriterion("upper(POSI_NM) like", value.toUpperCase(), "POSI_NM");
            return (Criteria) this;
        }

        public Criteria andGAZO_USE_FLGLikeInsensitive(String value) {
            addCriterion("upper(GAZO_USE_FLG) like", value.toUpperCase(), "GAZO_USE_FLG");
            return (Criteria) this;
        }

        public Criteria andGAZO_FILE_PATHLikeInsensitive(String value) {
            addCriterion("upper(GAZO_FILE_PATH) like", value.toUpperCase(), "GAZO_FILE_PATH");
            return (Criteria) this;
        }

        public Criteria andHIST_KINDLikeInsensitive(String value) {
            addCriterion("upper(HIST_KIND) like", value.toUpperCase(), "HIST_KIND");
            return (Criteria) this;
        }

        public Criteria andHIST_NMLikeInsensitive(String value) {
            addCriterion("upper(HIST_NM) like", value.toUpperCase(), "HIST_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * H_INOUT_LOG
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * H_INOUT_LOG null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}