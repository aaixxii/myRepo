package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class CDataPhysicalDeleteDtl extends CDataPhysicalDeleteDtlKey implements Serializable {
    /**
     * 削除対象DBスキーマ
     */
    private String DELETE_TARGET_SCHEMA;

    /**
     * 削除対象テーブル名
     */
    private String DELETE_TARGET_TABLE_NM;

    /**
     * 削除順番
     */
    private String DELETE_TARGET_ORDER;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * 削除条件
     */
    private String DELETE_TAERMS;

    /**
     * C_DATA_PHYSICAL_DELETE_DTL
     */
    private static final long serialVersionUID = 1L;

    /**
     * 削除対象DBスキーマ
     * @return DELETE_TARGET_SCHEMA 削除対象DBスキーマ
     */
    public String getDELETE_TARGET_SCHEMA() {
        return DELETE_TARGET_SCHEMA;
    }

    /**
     * 削除対象DBスキーマ
     * @param DELETE_TARGET_SCHEMA 削除対象DBスキーマ
     */
    public void setDELETE_TARGET_SCHEMA(String DELETE_TARGET_SCHEMA) {
        this.DELETE_TARGET_SCHEMA = DELETE_TARGET_SCHEMA == null ? null : DELETE_TARGET_SCHEMA.trim();
    }

    /**
     * 削除対象テーブル名
     * @return DELETE_TARGET_TABLE_NM 削除対象テーブル名
     */
    public String getDELETE_TARGET_TABLE_NM() {
        return DELETE_TARGET_TABLE_NM;
    }

    /**
     * 削除対象テーブル名
     * @param DELETE_TARGET_TABLE_NM 削除対象テーブル名
     */
    public void setDELETE_TARGET_TABLE_NM(String DELETE_TARGET_TABLE_NM) {
        this.DELETE_TARGET_TABLE_NM = DELETE_TARGET_TABLE_NM == null ? null : DELETE_TARGET_TABLE_NM.trim();
    }

    /**
     * 削除順番
     * @return DELETE_TARGET_ORDER 削除順番
     */
    public String getDELETE_TARGET_ORDER() {
        return DELETE_TARGET_ORDER;
    }

    /**
     * 削除順番
     * @param DELETE_TARGET_ORDER 削除順番
     */
    public void setDELETE_TARGET_ORDER(String DELETE_TARGET_ORDER) {
        this.DELETE_TARGET_ORDER = DELETE_TARGET_ORDER == null ? null : DELETE_TARGET_ORDER.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }

    /**
     * 削除条件
     * @return DELETE_TAERMS 削除条件
     */
    public String getDELETE_TAERMS() {
        return DELETE_TAERMS;
    }

    /**
     * 削除条件
     * @param DELETE_TAERMS 削除条件
     */
    public void setDELETE_TAERMS(String DELETE_TAERMS) {
        this.DELETE_TAERMS = DELETE_TAERMS == null ? null : DELETE_TAERMS.trim();
    }
}