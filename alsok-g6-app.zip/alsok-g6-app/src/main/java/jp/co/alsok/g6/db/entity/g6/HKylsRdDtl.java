package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class HKylsRdDtl implements Serializable {
    /**
     * LN_キーレス設定読出要求履歴論理番号
     */
    private String LN_KYLS_RD_DTL;

    /**
     * LN_キーレス設定読出要求履歴
     */
    private String LN_KYLS_RD;

    /**
     * フォーマットID
     */
    private String KYLS_FM;

    /**
     * カード固定ID
     */
    private String KYLS_CF;

    /**
     * カード可変ID
     */
    private String KYLS_CV;

    /**
     * 暗証番号
     */
    private String KYLS_CD;

    /**
     * 使用開始日
     */
    private String STRT_TM;

    /**
     * 使用停止日
     */
    private String STOP_TM;

    /**
     * 警備地区番号
     */
    private String KYLS_SA;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * H_KYLS_RD_DTL
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_キーレス設定読出要求履歴論理番号
     * @return LN_KYLS_RD_DTL LN_キーレス設定読出要求履歴論理番号
     */
    public String getLN_KYLS_RD_DTL() {
        return LN_KYLS_RD_DTL;
    }

    /**
     * LN_キーレス設定読出要求履歴論理番号
     * @param LN_KYLS_RD_DTL LN_キーレス設定読出要求履歴論理番号
     */
    public void setLN_KYLS_RD_DTL(String LN_KYLS_RD_DTL) {
        this.LN_KYLS_RD_DTL = LN_KYLS_RD_DTL == null ? null : LN_KYLS_RD_DTL.trim();
    }

    /**
     * LN_キーレス設定読出要求履歴
     * @return LN_KYLS_RD LN_キーレス設定読出要求履歴
     */
    public String getLN_KYLS_RD() {
        return LN_KYLS_RD;
    }

    /**
     * LN_キーレス設定読出要求履歴
     * @param LN_KYLS_RD LN_キーレス設定読出要求履歴
     */
    public void setLN_KYLS_RD(String LN_KYLS_RD) {
        this.LN_KYLS_RD = LN_KYLS_RD == null ? null : LN_KYLS_RD.trim();
    }

    /**
     * フォーマットID
     * @return KYLS_FM フォーマットID
     */
    public String getKYLS_FM() {
        return KYLS_FM;
    }

    /**
     * フォーマットID
     * @param KYLS_FM フォーマットID
     */
    public void setKYLS_FM(String KYLS_FM) {
        this.KYLS_FM = KYLS_FM == null ? null : KYLS_FM.trim();
    }

    /**
     * カード固定ID
     * @return KYLS_CF カード固定ID
     */
    public String getKYLS_CF() {
        return KYLS_CF;
    }

    /**
     * カード固定ID
     * @param KYLS_CF カード固定ID
     */
    public void setKYLS_CF(String KYLS_CF) {
        this.KYLS_CF = KYLS_CF == null ? null : KYLS_CF.trim();
    }

    /**
     * カード可変ID
     * @return KYLS_CV カード可変ID
     */
    public String getKYLS_CV() {
        return KYLS_CV;
    }

    /**
     * カード可変ID
     * @param KYLS_CV カード可変ID
     */
    public void setKYLS_CV(String KYLS_CV) {
        this.KYLS_CV = KYLS_CV == null ? null : KYLS_CV.trim();
    }

    /**
     * 暗証番号
     * @return KYLS_CD 暗証番号
     */
    public String getKYLS_CD() {
        return KYLS_CD;
    }

    /**
     * 暗証番号
     * @param KYLS_CD 暗証番号
     */
    public void setKYLS_CD(String KYLS_CD) {
        this.KYLS_CD = KYLS_CD == null ? null : KYLS_CD.trim();
    }

    /**
     * 使用開始日
     * @return STRT_TM 使用開始日
     */
    public String getSTRT_TM() {
        return STRT_TM;
    }

    /**
     * 使用開始日
     * @param STRT_TM 使用開始日
     */
    public void setSTRT_TM(String STRT_TM) {
        this.STRT_TM = STRT_TM == null ? null : STRT_TM.trim();
    }

    /**
     * 使用停止日
     * @return STOP_TM 使用停止日
     */
    public String getSTOP_TM() {
        return STOP_TM;
    }

    /**
     * 使用停止日
     * @param STOP_TM 使用停止日
     */
    public void setSTOP_TM(String STOP_TM) {
        this.STOP_TM = STOP_TM == null ? null : STOP_TM.trim();
    }

    /**
     * 警備地区番号
     * @return KYLS_SA 警備地区番号
     */
    public String getKYLS_SA() {
        return KYLS_SA;
    }

    /**
     * 警備地区番号
     * @param KYLS_SA 警備地区番号
     */
    public void setKYLS_SA(String KYLS_SA) {
        this.KYLS_SA = KYLS_SA == null ? null : KYLS_SA.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}