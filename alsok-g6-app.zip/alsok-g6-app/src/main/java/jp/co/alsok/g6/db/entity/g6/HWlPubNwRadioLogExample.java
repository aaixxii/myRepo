package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HWlPubNwRadioLogExample {
    /**
     * H_WL_PUB_NW_RADIO_LOG
     */
    protected String orderByClause;

    /**
     * H_WL_PUB_NW_RADIO_LOG
     */
    protected boolean distinct;

    /**
     * H_WL_PUB_NW_RADIO_LOG
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public HWlPubNwRadioLogExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * H_WL_PUB_NW_RADIO_LOG null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_CTL_DEVIsNull() {
            addCriterion("LN_CTL_DEV is null");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_DEVIsNotNull() {
            addCriterion("LN_CTL_DEV is not null");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_DEVEqualTo(String value) {
            addCriterion("LN_CTL_DEV =", value, "LN_CTL_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_DEVNotEqualTo(String value) {
            addCriterion("LN_CTL_DEV <>", value, "LN_CTL_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_DEVGreaterThan(String value) {
            addCriterion("LN_CTL_DEV >", value, "LN_CTL_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_DEVGreaterThanOrEqualTo(String value) {
            addCriterion("LN_CTL_DEV >=", value, "LN_CTL_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_DEVLessThan(String value) {
            addCriterion("LN_CTL_DEV <", value, "LN_CTL_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_DEVLessThanOrEqualTo(String value) {
            addCriterion("LN_CTL_DEV <=", value, "LN_CTL_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_DEVLike(String value) {
            addCriterion("LN_CTL_DEV like", value, "LN_CTL_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_DEVNotLike(String value) {
            addCriterion("LN_CTL_DEV not like", value, "LN_CTL_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_DEVIn(List<String> values) {
            addCriterion("LN_CTL_DEV in", values, "LN_CTL_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_DEVNotIn(List<String> values) {
            addCriterion("LN_CTL_DEV not in", values, "LN_CTL_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_DEVBetween(String value1, String value2) {
            addCriterion("LN_CTL_DEV between", value1, value2, "LN_CTL_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_DEVNotBetween(String value1, String value2) {
            addCriterion("LN_CTL_DEV not between", value1, value2, "LN_CTL_DEV");
            return (Criteria) this;
        }

        public Criteria andGEN_MNG_NUMIsNull() {
            addCriterion("GEN_MNG_NUM is null");
            return (Criteria) this;
        }

        public Criteria andGEN_MNG_NUMIsNotNull() {
            addCriterion("GEN_MNG_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andGEN_MNG_NUMEqualTo(String value) {
            addCriterion("GEN_MNG_NUM =", value, "GEN_MNG_NUM");
            return (Criteria) this;
        }

        public Criteria andGEN_MNG_NUMNotEqualTo(String value) {
            addCriterion("GEN_MNG_NUM <>", value, "GEN_MNG_NUM");
            return (Criteria) this;
        }

        public Criteria andGEN_MNG_NUMGreaterThan(String value) {
            addCriterion("GEN_MNG_NUM >", value, "GEN_MNG_NUM");
            return (Criteria) this;
        }

        public Criteria andGEN_MNG_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("GEN_MNG_NUM >=", value, "GEN_MNG_NUM");
            return (Criteria) this;
        }

        public Criteria andGEN_MNG_NUMLessThan(String value) {
            addCriterion("GEN_MNG_NUM <", value, "GEN_MNG_NUM");
            return (Criteria) this;
        }

        public Criteria andGEN_MNG_NUMLessThanOrEqualTo(String value) {
            addCriterion("GEN_MNG_NUM <=", value, "GEN_MNG_NUM");
            return (Criteria) this;
        }

        public Criteria andGEN_MNG_NUMLike(String value) {
            addCriterion("GEN_MNG_NUM like", value, "GEN_MNG_NUM");
            return (Criteria) this;
        }

        public Criteria andGEN_MNG_NUMNotLike(String value) {
            addCriterion("GEN_MNG_NUM not like", value, "GEN_MNG_NUM");
            return (Criteria) this;
        }

        public Criteria andGEN_MNG_NUMIn(List<String> values) {
            addCriterion("GEN_MNG_NUM in", values, "GEN_MNG_NUM");
            return (Criteria) this;
        }

        public Criteria andGEN_MNG_NUMNotIn(List<String> values) {
            addCriterion("GEN_MNG_NUM not in", values, "GEN_MNG_NUM");
            return (Criteria) this;
        }

        public Criteria andGEN_MNG_NUMBetween(String value1, String value2) {
            addCriterion("GEN_MNG_NUM between", value1, value2, "GEN_MNG_NUM");
            return (Criteria) this;
        }

        public Criteria andGEN_MNG_NUMNotBetween(String value1, String value2) {
            addCriterion("GEN_MNG_NUM not between", value1, value2, "GEN_MNG_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMIsNull() {
            addCriterion("ORDER_NUM is null");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMIsNotNull() {
            addCriterion("ORDER_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMEqualTo(String value) {
            addCriterion("ORDER_NUM =", value, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMNotEqualTo(String value) {
            addCriterion("ORDER_NUM <>", value, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMGreaterThan(String value) {
            addCriterion("ORDER_NUM >", value, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("ORDER_NUM >=", value, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMLessThan(String value) {
            addCriterion("ORDER_NUM <", value, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMLessThanOrEqualTo(String value) {
            addCriterion("ORDER_NUM <=", value, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMLike(String value) {
            addCriterion("ORDER_NUM like", value, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMNotLike(String value) {
            addCriterion("ORDER_NUM not like", value, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMIn(List<String> values) {
            addCriterion("ORDER_NUM in", values, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMNotIn(List<String> values) {
            addCriterion("ORDER_NUM not in", values, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMBetween(String value1, String value2) {
            addCriterion("ORDER_NUM between", value1, value2, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMNotBetween(String value1, String value2) {
            addCriterion("ORDER_NUM not between", value1, value2, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andFILE_KINDIsNull() {
            addCriterion("FILE_KIND is null");
            return (Criteria) this;
        }

        public Criteria andFILE_KINDIsNotNull() {
            addCriterion("FILE_KIND is not null");
            return (Criteria) this;
        }

        public Criteria andFILE_KINDEqualTo(String value) {
            addCriterion("FILE_KIND =", value, "FILE_KIND");
            return (Criteria) this;
        }

        public Criteria andFILE_KINDNotEqualTo(String value) {
            addCriterion("FILE_KIND <>", value, "FILE_KIND");
            return (Criteria) this;
        }

        public Criteria andFILE_KINDGreaterThan(String value) {
            addCriterion("FILE_KIND >", value, "FILE_KIND");
            return (Criteria) this;
        }

        public Criteria andFILE_KINDGreaterThanOrEqualTo(String value) {
            addCriterion("FILE_KIND >=", value, "FILE_KIND");
            return (Criteria) this;
        }

        public Criteria andFILE_KINDLessThan(String value) {
            addCriterion("FILE_KIND <", value, "FILE_KIND");
            return (Criteria) this;
        }

        public Criteria andFILE_KINDLessThanOrEqualTo(String value) {
            addCriterion("FILE_KIND <=", value, "FILE_KIND");
            return (Criteria) this;
        }

        public Criteria andFILE_KINDLike(String value) {
            addCriterion("FILE_KIND like", value, "FILE_KIND");
            return (Criteria) this;
        }

        public Criteria andFILE_KINDNotLike(String value) {
            addCriterion("FILE_KIND not like", value, "FILE_KIND");
            return (Criteria) this;
        }

        public Criteria andFILE_KINDIn(List<String> values) {
            addCriterion("FILE_KIND in", values, "FILE_KIND");
            return (Criteria) this;
        }

        public Criteria andFILE_KINDNotIn(List<String> values) {
            addCriterion("FILE_KIND not in", values, "FILE_KIND");
            return (Criteria) this;
        }

        public Criteria andFILE_KINDBetween(String value1, String value2) {
            addCriterion("FILE_KIND between", value1, value2, "FILE_KIND");
            return (Criteria) this;
        }

        public Criteria andFILE_KINDNotBetween(String value1, String value2) {
            addCriterion("FILE_KIND not between", value1, value2, "FILE_KIND");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_DEVLikeInsensitive(String value) {
            addCriterion("upper(LN_CTL_DEV) like", value.toUpperCase(), "LN_CTL_DEV");
            return (Criteria) this;
        }

        public Criteria andGEN_MNG_NUMLikeInsensitive(String value) {
            addCriterion("upper(GEN_MNG_NUM) like", value.toUpperCase(), "GEN_MNG_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMLikeInsensitive(String value) {
            addCriterion("upper(ORDER_NUM) like", value.toUpperCase(), "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andFILE_KINDLikeInsensitive(String value) {
            addCriterion("upper(FILE_KIND) like", value.toUpperCase(), "FILE_KIND");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * H_WL_PUB_NW_RADIO_LOG
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * H_WL_PUB_NW_RADIO_LOG null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}