package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HCtlReasonHtblExample {
    /**
     * H_CTL_REASON_HTBL
     */
    protected String orderByClause;

    /**
     * H_CTL_REASON_HTBL
     */
    protected boolean distinct;

    /**
     * H_CTL_REASON_HTBL
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public HCtlReasonHtblExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * H_CTL_REASON_HTBL null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_CTL_REASONIsNull() {
            addCriterion("LN_CTL_REASON is null");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_REASONIsNotNull() {
            addCriterion("LN_CTL_REASON is not null");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_REASONEqualTo(String value) {
            addCriterion("LN_CTL_REASON =", value, "LN_CTL_REASON");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_REASONNotEqualTo(String value) {
            addCriterion("LN_CTL_REASON <>", value, "LN_CTL_REASON");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_REASONGreaterThan(String value) {
            addCriterion("LN_CTL_REASON >", value, "LN_CTL_REASON");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_REASONGreaterThanOrEqualTo(String value) {
            addCriterion("LN_CTL_REASON >=", value, "LN_CTL_REASON");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_REASONLessThan(String value) {
            addCriterion("LN_CTL_REASON <", value, "LN_CTL_REASON");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_REASONLessThanOrEqualTo(String value) {
            addCriterion("LN_CTL_REASON <=", value, "LN_CTL_REASON");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_REASONLike(String value) {
            addCriterion("LN_CTL_REASON like", value, "LN_CTL_REASON");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_REASONNotLike(String value) {
            addCriterion("LN_CTL_REASON not like", value, "LN_CTL_REASON");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_REASONIn(List<String> values) {
            addCriterion("LN_CTL_REASON in", values, "LN_CTL_REASON");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_REASONNotIn(List<String> values) {
            addCriterion("LN_CTL_REASON not in", values, "LN_CTL_REASON");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_REASONBetween(String value1, String value2) {
            addCriterion("LN_CTL_REASON between", value1, value2, "LN_CTL_REASON");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_REASONNotBetween(String value1, String value2) {
            addCriterion("LN_CTL_REASON not between", value1, value2, "LN_CTL_REASON");
            return (Criteria) this;
        }

        public Criteria andCTRL_TIMEIsNull() {
            addCriterion("CTRL_TIME is null");
            return (Criteria) this;
        }

        public Criteria andCTRL_TIMEIsNotNull() {
            addCriterion("CTRL_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andCTRL_TIMEEqualTo(Date value) {
            addCriterion("CTRL_TIME =", value, "CTRL_TIME");
            return (Criteria) this;
        }

        public Criteria andCTRL_TIMENotEqualTo(Date value) {
            addCriterion("CTRL_TIME <>", value, "CTRL_TIME");
            return (Criteria) this;
        }

        public Criteria andCTRL_TIMEGreaterThan(Date value) {
            addCriterion("CTRL_TIME >", value, "CTRL_TIME");
            return (Criteria) this;
        }

        public Criteria andCTRL_TIMEGreaterThanOrEqualTo(Date value) {
            addCriterion("CTRL_TIME >=", value, "CTRL_TIME");
            return (Criteria) this;
        }

        public Criteria andCTRL_TIMELessThan(Date value) {
            addCriterion("CTRL_TIME <", value, "CTRL_TIME");
            return (Criteria) this;
        }

        public Criteria andCTRL_TIMELessThanOrEqualTo(Date value) {
            addCriterion("CTRL_TIME <=", value, "CTRL_TIME");
            return (Criteria) this;
        }

        public Criteria andCTRL_TIMEIn(List<Date> values) {
            addCriterion("CTRL_TIME in", values, "CTRL_TIME");
            return (Criteria) this;
        }

        public Criteria andCTRL_TIMENotIn(List<Date> values) {
            addCriterion("CTRL_TIME not in", values, "CTRL_TIME");
            return (Criteria) this;
        }

        public Criteria andCTRL_TIMEBetween(Date value1, Date value2) {
            addCriterion("CTRL_TIME between", value1, value2, "CTRL_TIME");
            return (Criteria) this;
        }

        public Criteria andCTRL_TIMENotBetween(Date value1, Date value2) {
            addCriterion("CTRL_TIME not between", value1, value2, "CTRL_TIME");
            return (Criteria) this;
        }

        public Criteria andDENKEIIsNull() {
            addCriterion("DENKEI is null");
            return (Criteria) this;
        }

        public Criteria andDENKEIIsNotNull() {
            addCriterion("DENKEI is not null");
            return (Criteria) this;
        }

        public Criteria andDENKEIEqualTo(String value) {
            addCriterion("DENKEI =", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEINotEqualTo(String value) {
            addCriterion("DENKEI <>", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEIGreaterThan(String value) {
            addCriterion("DENKEI >", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEIGreaterThanOrEqualTo(String value) {
            addCriterion("DENKEI >=", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEILessThan(String value) {
            addCriterion("DENKEI <", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEILessThanOrEqualTo(String value) {
            addCriterion("DENKEI <=", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEILike(String value) {
            addCriterion("DENKEI like", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEINotLike(String value) {
            addCriterion("DENKEI not like", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEIIn(List<String> values) {
            addCriterion("DENKEI in", values, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEINotIn(List<String> values) {
            addCriterion("DENKEI not in", values, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEIBetween(String value1, String value2) {
            addCriterion("DENKEI between", value1, value2, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEINotBetween(String value1, String value2) {
            addCriterion("DENKEI not between", value1, value2, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andCHIKUIsNull() {
            addCriterion("CHIKU is null");
            return (Criteria) this;
        }

        public Criteria andCHIKUIsNotNull() {
            addCriterion("CHIKU is not null");
            return (Criteria) this;
        }

        public Criteria andCHIKUEqualTo(String value) {
            addCriterion("CHIKU =", value, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKUNotEqualTo(String value) {
            addCriterion("CHIKU <>", value, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKUGreaterThan(String value) {
            addCriterion("CHIKU >", value, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKUGreaterThanOrEqualTo(String value) {
            addCriterion("CHIKU >=", value, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKULessThan(String value) {
            addCriterion("CHIKU <", value, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKULessThanOrEqualTo(String value) {
            addCriterion("CHIKU <=", value, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKULike(String value) {
            addCriterion("CHIKU like", value, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKUNotLike(String value) {
            addCriterion("CHIKU not like", value, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKUIn(List<String> values) {
            addCriterion("CHIKU in", values, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKUNotIn(List<String> values) {
            addCriterion("CHIKU not in", values, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKUBetween(String value1, String value2) {
            addCriterion("CHIKU between", value1, value2, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKUNotBetween(String value1, String value2) {
            addCriterion("CHIKU not between", value1, value2, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMIsNull() {
            addCriterion("DEV_NUM is null");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMIsNotNull() {
            addCriterion("DEV_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMEqualTo(String value) {
            addCriterion("DEV_NUM =", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMNotEqualTo(String value) {
            addCriterion("DEV_NUM <>", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMGreaterThan(String value) {
            addCriterion("DEV_NUM >", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("DEV_NUM >=", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMLessThan(String value) {
            addCriterion("DEV_NUM <", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMLessThanOrEqualTo(String value) {
            addCriterion("DEV_NUM <=", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMLike(String value) {
            addCriterion("DEV_NUM like", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMNotLike(String value) {
            addCriterion("DEV_NUM not like", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMIn(List<String> values) {
            addCriterion("DEV_NUM in", values, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMNotIn(List<String> values) {
            addCriterion("DEV_NUM not in", values, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMBetween(String value1, String value2) {
            addCriterion("DEV_NUM between", value1, value2, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMNotBetween(String value1, String value2) {
            addCriterion("DEV_NUM not between", value1, value2, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andCTRL_CMD_IDIsNull() {
            addCriterion("CTRL_CMD_ID is null");
            return (Criteria) this;
        }

        public Criteria andCTRL_CMD_IDIsNotNull() {
            addCriterion("CTRL_CMD_ID is not null");
            return (Criteria) this;
        }

        public Criteria andCTRL_CMD_IDEqualTo(String value) {
            addCriterion("CTRL_CMD_ID =", value, "CTRL_CMD_ID");
            return (Criteria) this;
        }

        public Criteria andCTRL_CMD_IDNotEqualTo(String value) {
            addCriterion("CTRL_CMD_ID <>", value, "CTRL_CMD_ID");
            return (Criteria) this;
        }

        public Criteria andCTRL_CMD_IDGreaterThan(String value) {
            addCriterion("CTRL_CMD_ID >", value, "CTRL_CMD_ID");
            return (Criteria) this;
        }

        public Criteria andCTRL_CMD_IDGreaterThanOrEqualTo(String value) {
            addCriterion("CTRL_CMD_ID >=", value, "CTRL_CMD_ID");
            return (Criteria) this;
        }

        public Criteria andCTRL_CMD_IDLessThan(String value) {
            addCriterion("CTRL_CMD_ID <", value, "CTRL_CMD_ID");
            return (Criteria) this;
        }

        public Criteria andCTRL_CMD_IDLessThanOrEqualTo(String value) {
            addCriterion("CTRL_CMD_ID <=", value, "CTRL_CMD_ID");
            return (Criteria) this;
        }

        public Criteria andCTRL_CMD_IDLike(String value) {
            addCriterion("CTRL_CMD_ID like", value, "CTRL_CMD_ID");
            return (Criteria) this;
        }

        public Criteria andCTRL_CMD_IDNotLike(String value) {
            addCriterion("CTRL_CMD_ID not like", value, "CTRL_CMD_ID");
            return (Criteria) this;
        }

        public Criteria andCTRL_CMD_IDIn(List<String> values) {
            addCriterion("CTRL_CMD_ID in", values, "CTRL_CMD_ID");
            return (Criteria) this;
        }

        public Criteria andCTRL_CMD_IDNotIn(List<String> values) {
            addCriterion("CTRL_CMD_ID not in", values, "CTRL_CMD_ID");
            return (Criteria) this;
        }

        public Criteria andCTRL_CMD_IDBetween(String value1, String value2) {
            addCriterion("CTRL_CMD_ID between", value1, value2, "CTRL_CMD_ID");
            return (Criteria) this;
        }

        public Criteria andCTRL_CMD_IDNotBetween(String value1, String value2) {
            addCriterion("CTRL_CMD_ID not between", value1, value2, "CTRL_CMD_ID");
            return (Criteria) this;
        }

        public Criteria andREASONIsNull() {
            addCriterion("REASON is null");
            return (Criteria) this;
        }

        public Criteria andREASONIsNotNull() {
            addCriterion("REASON is not null");
            return (Criteria) this;
        }

        public Criteria andREASONEqualTo(String value) {
            addCriterion("REASON =", value, "REASON");
            return (Criteria) this;
        }

        public Criteria andREASONNotEqualTo(String value) {
            addCriterion("REASON <>", value, "REASON");
            return (Criteria) this;
        }

        public Criteria andREASONGreaterThan(String value) {
            addCriterion("REASON >", value, "REASON");
            return (Criteria) this;
        }

        public Criteria andREASONGreaterThanOrEqualTo(String value) {
            addCriterion("REASON >=", value, "REASON");
            return (Criteria) this;
        }

        public Criteria andREASONLessThan(String value) {
            addCriterion("REASON <", value, "REASON");
            return (Criteria) this;
        }

        public Criteria andREASONLessThanOrEqualTo(String value) {
            addCriterion("REASON <=", value, "REASON");
            return (Criteria) this;
        }

        public Criteria andREASONLike(String value) {
            addCriterion("REASON like", value, "REASON");
            return (Criteria) this;
        }

        public Criteria andREASONNotLike(String value) {
            addCriterion("REASON not like", value, "REASON");
            return (Criteria) this;
        }

        public Criteria andREASONIn(List<String> values) {
            addCriterion("REASON in", values, "REASON");
            return (Criteria) this;
        }

        public Criteria andREASONNotIn(List<String> values) {
            addCriterion("REASON not in", values, "REASON");
            return (Criteria) this;
        }

        public Criteria andREASONBetween(String value1, String value2) {
            addCriterion("REASON between", value1, value2, "REASON");
            return (Criteria) this;
        }

        public Criteria andREASONNotBetween(String value1, String value2) {
            addCriterion("REASON not between", value1, value2, "REASON");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_REASONLikeInsensitive(String value) {
            addCriterion("upper(LN_CTL_REASON) like", value.toUpperCase(), "LN_CTL_REASON");
            return (Criteria) this;
        }

        public Criteria andDENKEILikeInsensitive(String value) {
            addCriterion("upper(DENKEI) like", value.toUpperCase(), "DENKEI");
            return (Criteria) this;
        }

        public Criteria andCHIKULikeInsensitive(String value) {
            addCriterion("upper(CHIKU) like", value.toUpperCase(), "CHIKU");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMLikeInsensitive(String value) {
            addCriterion("upper(DEV_NUM) like", value.toUpperCase(), "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andCTRL_CMD_IDLikeInsensitive(String value) {
            addCriterion("upper(CTRL_CMD_ID) like", value.toUpperCase(), "CTRL_CMD_ID");
            return (Criteria) this;
        }

        public Criteria andREASONLikeInsensitive(String value) {
            addCriterion("upper(REASON) like", value.toUpperCase(), "REASON");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * H_CTL_REASON_HTBL
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * H_CTL_REASON_HTBL null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}