package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class EGenin implements Serializable {
    /**
     * LN_原因マスター論理番号
     */
    private String LN_GENIN;

    /**
     * 原因ID
     */
    private String GENIN_ID;

    /**
     * 原因内容
     */
    private String GENIN_NAIYOU;

    /**
     * 事案表示有無
     */
    private String HYOUJI_UMU;

    /**
     * 新規登録者ＩＤ
     */
    private String ID_INSERT;

    /**
     * SGS原因コード
     */
    private String SGS_NET_GENIN_CD;

    /**
     * CL表示フラグ
     */
    private String CL_DISP_FLG;

    /**
     * 削除フラグ
     */
    private String DEL_FLG;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * E_GENIN
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_原因マスター論理番号
     * @return LN_GENIN LN_原因マスター論理番号
     */
    public String getLN_GENIN() {
        return LN_GENIN;
    }

    /**
     * LN_原因マスター論理番号
     * @param LN_GENIN LN_原因マスター論理番号
     */
    public void setLN_GENIN(String LN_GENIN) {
        this.LN_GENIN = LN_GENIN == null ? null : LN_GENIN.trim();
    }

    /**
     * 原因ID
     * @return GENIN_ID 原因ID
     */
    public String getGENIN_ID() {
        return GENIN_ID;
    }

    /**
     * 原因ID
     * @param GENIN_ID 原因ID
     */
    public void setGENIN_ID(String GENIN_ID) {
        this.GENIN_ID = GENIN_ID == null ? null : GENIN_ID.trim();
    }

    /**
     * 原因内容
     * @return GENIN_NAIYOU 原因内容
     */
    public String getGENIN_NAIYOU() {
        return GENIN_NAIYOU;
    }

    /**
     * 原因内容
     * @param GENIN_NAIYOU 原因内容
     */
    public void setGENIN_NAIYOU(String GENIN_NAIYOU) {
        this.GENIN_NAIYOU = GENIN_NAIYOU == null ? null : GENIN_NAIYOU.trim();
    }

    /**
     * 事案表示有無
     * @return HYOUJI_UMU 事案表示有無
     */
    public String getHYOUJI_UMU() {
        return HYOUJI_UMU;
    }

    /**
     * 事案表示有無
     * @param HYOUJI_UMU 事案表示有無
     */
    public void setHYOUJI_UMU(String HYOUJI_UMU) {
        this.HYOUJI_UMU = HYOUJI_UMU == null ? null : HYOUJI_UMU.trim();
    }

    /**
     * 新規登録者ＩＤ
     * @return ID_INSERT 新規登録者ＩＤ
     */
    public String getID_INSERT() {
        return ID_INSERT;
    }

    /**
     * 新規登録者ＩＤ
     * @param ID_INSERT 新規登録者ＩＤ
     */
    public void setID_INSERT(String ID_INSERT) {
        this.ID_INSERT = ID_INSERT == null ? null : ID_INSERT.trim();
    }

    /**
     * SGS原因コード
     * @return SGS_NET_GENIN_CD SGS原因コード
     */
    public String getSGS_NET_GENIN_CD() {
        return SGS_NET_GENIN_CD;
    }

    /**
     * SGS原因コード
     * @param SGS_NET_GENIN_CD SGS原因コード
     */
    public void setSGS_NET_GENIN_CD(String SGS_NET_GENIN_CD) {
        this.SGS_NET_GENIN_CD = SGS_NET_GENIN_CD == null ? null : SGS_NET_GENIN_CD.trim();
    }

    /**
     * CL表示フラグ
     * @return CL_DISP_FLG CL表示フラグ
     */
    public String getCL_DISP_FLG() {
        return CL_DISP_FLG;
    }

    /**
     * CL表示フラグ
     * @param CL_DISP_FLG CL表示フラグ
     */
    public void setCL_DISP_FLG(String CL_DISP_FLG) {
        this.CL_DISP_FLG = CL_DISP_FLG == null ? null : CL_DISP_FLG.trim();
    }

    /**
     * 削除フラグ
     * @return DEL_FLG 削除フラグ
     */
    public String getDEL_FLG() {
        return DEL_FLG;
    }

    /**
     * 削除フラグ
     * @param DEL_FLG 削除フラグ
     */
    public void setDEL_FLG(String DEL_FLG) {
        this.DEL_FLG = DEL_FLG == null ? null : DEL_FLG.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}