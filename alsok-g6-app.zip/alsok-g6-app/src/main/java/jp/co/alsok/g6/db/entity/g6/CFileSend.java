package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class CFileSend implements Serializable {
    /**
     * LN_ファイル送信論理番号
     */
    private String LN_FILE_SEND;

    /**
     * LN_制御装置論理番号
     */
    private String LN_CTL_DEV;

    /**
     * コマンドシーケンス番号
     */
    private String CMD_SEQ_NUM;

    /**
     * LN_FWリストバージョン論理番号
     */
    private String LN_FW_LIST_VER;

    /**
     * 更新指定日時
     */
    private String FILE_UPDATE_TS;

    /**
     * デキュー可能日時
     */
    private Date DEQ_ABL_TS;

    /**
     * 削除フラグ
     */
    private String DEL_FLG;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * C_FILE_SEND
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_ファイル送信論理番号
     * @return LN_FILE_SEND LN_ファイル送信論理番号
     */
    public String getLN_FILE_SEND() {
        return LN_FILE_SEND;
    }

    /**
     * LN_ファイル送信論理番号
     * @param LN_FILE_SEND LN_ファイル送信論理番号
     */
    public void setLN_FILE_SEND(String LN_FILE_SEND) {
        this.LN_FILE_SEND = LN_FILE_SEND == null ? null : LN_FILE_SEND.trim();
    }

    /**
     * LN_制御装置論理番号
     * @return LN_CTL_DEV LN_制御装置論理番号
     */
    public String getLN_CTL_DEV() {
        return LN_CTL_DEV;
    }

    /**
     * LN_制御装置論理番号
     * @param LN_CTL_DEV LN_制御装置論理番号
     */
    public void setLN_CTL_DEV(String LN_CTL_DEV) {
        this.LN_CTL_DEV = LN_CTL_DEV == null ? null : LN_CTL_DEV.trim();
    }

    /**
     * コマンドシーケンス番号
     * @return CMD_SEQ_NUM コマンドシーケンス番号
     */
    public String getCMD_SEQ_NUM() {
        return CMD_SEQ_NUM;
    }

    /**
     * コマンドシーケンス番号
     * @param CMD_SEQ_NUM コマンドシーケンス番号
     */
    public void setCMD_SEQ_NUM(String CMD_SEQ_NUM) {
        this.CMD_SEQ_NUM = CMD_SEQ_NUM == null ? null : CMD_SEQ_NUM.trim();
    }

    /**
     * LN_FWリストバージョン論理番号
     * @return LN_FW_LIST_VER LN_FWリストバージョン論理番号
     */
    public String getLN_FW_LIST_VER() {
        return LN_FW_LIST_VER;
    }

    /**
     * LN_FWリストバージョン論理番号
     * @param LN_FW_LIST_VER LN_FWリストバージョン論理番号
     */
    public void setLN_FW_LIST_VER(String LN_FW_LIST_VER) {
        this.LN_FW_LIST_VER = LN_FW_LIST_VER == null ? null : LN_FW_LIST_VER.trim();
    }

    /**
     * 更新指定日時
     * @return FILE_UPDATE_TS 更新指定日時
     */
    public String getFILE_UPDATE_TS() {
        return FILE_UPDATE_TS;
    }

    /**
     * 更新指定日時
     * @param FILE_UPDATE_TS 更新指定日時
     */
    public void setFILE_UPDATE_TS(String FILE_UPDATE_TS) {
        this.FILE_UPDATE_TS = FILE_UPDATE_TS == null ? null : FILE_UPDATE_TS.trim();
    }

    /**
     * デキュー可能日時
     * @return DEQ_ABL_TS デキュー可能日時
     */
    public Date getDEQ_ABL_TS() {
        return DEQ_ABL_TS;
    }

    /**
     * デキュー可能日時
     * @param DEQ_ABL_TS デキュー可能日時
     */
    public void setDEQ_ABL_TS(Date DEQ_ABL_TS) {
        this.DEQ_ABL_TS = DEQ_ABL_TS;
    }

    /**
     * 削除フラグ
     * @return DEL_FLG 削除フラグ
     */
    public String getDEL_FLG() {
        return DEL_FLG;
    }

    /**
     * 削除フラグ
     * @param DEL_FLG 削除フラグ
     */
    public void setDEL_FLG(String DEL_FLG) {
        this.DEL_FLG = DEL_FLG == null ? null : DEL_FLG.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}