package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HEventInfoExample {
    /**
     * H_EVENT_INFO
     */
    protected String orderByClause;

    /**
     * H_EVENT_INFO
     */
    protected boolean distinct;

    /**
     * H_EVENT_INFO
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public HEventInfoExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * H_EVENT_INFO null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_EVENT_INFO_HSTIsNull() {
            addCriterion("LN_EVENT_INFO_HST is null");
            return (Criteria) this;
        }

        public Criteria andLN_EVENT_INFO_HSTIsNotNull() {
            addCriterion("LN_EVENT_INFO_HST is not null");
            return (Criteria) this;
        }

        public Criteria andLN_EVENT_INFO_HSTEqualTo(String value) {
            addCriterion("LN_EVENT_INFO_HST =", value, "LN_EVENT_INFO_HST");
            return (Criteria) this;
        }

        public Criteria andLN_EVENT_INFO_HSTNotEqualTo(String value) {
            addCriterion("LN_EVENT_INFO_HST <>", value, "LN_EVENT_INFO_HST");
            return (Criteria) this;
        }

        public Criteria andLN_EVENT_INFO_HSTGreaterThan(String value) {
            addCriterion("LN_EVENT_INFO_HST >", value, "LN_EVENT_INFO_HST");
            return (Criteria) this;
        }

        public Criteria andLN_EVENT_INFO_HSTGreaterThanOrEqualTo(String value) {
            addCriterion("LN_EVENT_INFO_HST >=", value, "LN_EVENT_INFO_HST");
            return (Criteria) this;
        }

        public Criteria andLN_EVENT_INFO_HSTLessThan(String value) {
            addCriterion("LN_EVENT_INFO_HST <", value, "LN_EVENT_INFO_HST");
            return (Criteria) this;
        }

        public Criteria andLN_EVENT_INFO_HSTLessThanOrEqualTo(String value) {
            addCriterion("LN_EVENT_INFO_HST <=", value, "LN_EVENT_INFO_HST");
            return (Criteria) this;
        }

        public Criteria andLN_EVENT_INFO_HSTLike(String value) {
            addCriterion("LN_EVENT_INFO_HST like", value, "LN_EVENT_INFO_HST");
            return (Criteria) this;
        }

        public Criteria andLN_EVENT_INFO_HSTNotLike(String value) {
            addCriterion("LN_EVENT_INFO_HST not like", value, "LN_EVENT_INFO_HST");
            return (Criteria) this;
        }

        public Criteria andLN_EVENT_INFO_HSTIn(List<String> values) {
            addCriterion("LN_EVENT_INFO_HST in", values, "LN_EVENT_INFO_HST");
            return (Criteria) this;
        }

        public Criteria andLN_EVENT_INFO_HSTNotIn(List<String> values) {
            addCriterion("LN_EVENT_INFO_HST not in", values, "LN_EVENT_INFO_HST");
            return (Criteria) this;
        }

        public Criteria andLN_EVENT_INFO_HSTBetween(String value1, String value2) {
            addCriterion("LN_EVENT_INFO_HST between", value1, value2, "LN_EVENT_INFO_HST");
            return (Criteria) this;
        }

        public Criteria andLN_EVENT_INFO_HSTNotBetween(String value1, String value2) {
            addCriterion("LN_EVENT_INFO_HST not between", value1, value2, "LN_EVENT_INFO_HST");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSIsNull() {
            addCriterion("HASSEI_TS is null");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSIsNotNull() {
            addCriterion("HASSEI_TS is not null");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSEqualTo(String value) {
            addCriterion("HASSEI_TS =", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSNotEqualTo(String value) {
            addCriterion("HASSEI_TS <>", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSGreaterThan(String value) {
            addCriterion("HASSEI_TS >", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSGreaterThanOrEqualTo(String value) {
            addCriterion("HASSEI_TS >=", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSLessThan(String value) {
            addCriterion("HASSEI_TS <", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSLessThanOrEqualTo(String value) {
            addCriterion("HASSEI_TS <=", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSLike(String value) {
            addCriterion("HASSEI_TS like", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSNotLike(String value) {
            addCriterion("HASSEI_TS not like", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSIn(List<String> values) {
            addCriterion("HASSEI_TS in", values, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSNotIn(List<String> values) {
            addCriterion("HASSEI_TS not in", values, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSBetween(String value1, String value2) {
            addCriterion("HASSEI_TS between", value1, value2, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSNotBetween(String value1, String value2) {
            addCriterion("HASSEI_TS not between", value1, value2, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NMIsNull() {
            addCriterion("CHIKU_NM is null");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NMIsNotNull() {
            addCriterion("CHIKU_NM is not null");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NMEqualTo(String value) {
            addCriterion("CHIKU_NM =", value, "CHIKU_NM");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NMNotEqualTo(String value) {
            addCriterion("CHIKU_NM <>", value, "CHIKU_NM");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NMGreaterThan(String value) {
            addCriterion("CHIKU_NM >", value, "CHIKU_NM");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NMGreaterThanOrEqualTo(String value) {
            addCriterion("CHIKU_NM >=", value, "CHIKU_NM");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NMLessThan(String value) {
            addCriterion("CHIKU_NM <", value, "CHIKU_NM");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NMLessThanOrEqualTo(String value) {
            addCriterion("CHIKU_NM <=", value, "CHIKU_NM");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NMLike(String value) {
            addCriterion("CHIKU_NM like", value, "CHIKU_NM");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NMNotLike(String value) {
            addCriterion("CHIKU_NM not like", value, "CHIKU_NM");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NMIn(List<String> values) {
            addCriterion("CHIKU_NM in", values, "CHIKU_NM");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NMNotIn(List<String> values) {
            addCriterion("CHIKU_NM not in", values, "CHIKU_NM");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NMBetween(String value1, String value2) {
            addCriterion("CHIKU_NM between", value1, value2, "CHIKU_NM");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NMNotBetween(String value1, String value2) {
            addCriterion("CHIKU_NM not between", value1, value2, "CHIKU_NM");
            return (Criteria) this;
        }

        public Criteria andKENCHI_NAIYOUIsNull() {
            addCriterion("KENCHI_NAIYOU is null");
            return (Criteria) this;
        }

        public Criteria andKENCHI_NAIYOUIsNotNull() {
            addCriterion("KENCHI_NAIYOU is not null");
            return (Criteria) this;
        }

        public Criteria andKENCHI_NAIYOUEqualTo(String value) {
            addCriterion("KENCHI_NAIYOU =", value, "KENCHI_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andKENCHI_NAIYOUNotEqualTo(String value) {
            addCriterion("KENCHI_NAIYOU <>", value, "KENCHI_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andKENCHI_NAIYOUGreaterThan(String value) {
            addCriterion("KENCHI_NAIYOU >", value, "KENCHI_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andKENCHI_NAIYOUGreaterThanOrEqualTo(String value) {
            addCriterion("KENCHI_NAIYOU >=", value, "KENCHI_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andKENCHI_NAIYOULessThan(String value) {
            addCriterion("KENCHI_NAIYOU <", value, "KENCHI_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andKENCHI_NAIYOULessThanOrEqualTo(String value) {
            addCriterion("KENCHI_NAIYOU <=", value, "KENCHI_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andKENCHI_NAIYOULike(String value) {
            addCriterion("KENCHI_NAIYOU like", value, "KENCHI_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andKENCHI_NAIYOUNotLike(String value) {
            addCriterion("KENCHI_NAIYOU not like", value, "KENCHI_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andKENCHI_NAIYOUIn(List<String> values) {
            addCriterion("KENCHI_NAIYOU in", values, "KENCHI_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andKENCHI_NAIYOUNotIn(List<String> values) {
            addCriterion("KENCHI_NAIYOU not in", values, "KENCHI_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andKENCHI_NAIYOUBetween(String value1, String value2) {
            addCriterion("KENCHI_NAIYOU between", value1, value2, "KENCHI_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andKENCHI_NAIYOUNotBetween(String value1, String value2) {
            addCriterion("KENCHI_NAIYOU not between", value1, value2, "KENCHI_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andKB_STSIsNull() {
            addCriterion("KB_STS is null");
            return (Criteria) this;
        }

        public Criteria andKB_STSIsNotNull() {
            addCriterion("KB_STS is not null");
            return (Criteria) this;
        }

        public Criteria andKB_STSEqualTo(String value) {
            addCriterion("KB_STS =", value, "KB_STS");
            return (Criteria) this;
        }

        public Criteria andKB_STSNotEqualTo(String value) {
            addCriterion("KB_STS <>", value, "KB_STS");
            return (Criteria) this;
        }

        public Criteria andKB_STSGreaterThan(String value) {
            addCriterion("KB_STS >", value, "KB_STS");
            return (Criteria) this;
        }

        public Criteria andKB_STSGreaterThanOrEqualTo(String value) {
            addCriterion("KB_STS >=", value, "KB_STS");
            return (Criteria) this;
        }

        public Criteria andKB_STSLessThan(String value) {
            addCriterion("KB_STS <", value, "KB_STS");
            return (Criteria) this;
        }

        public Criteria andKB_STSLessThanOrEqualTo(String value) {
            addCriterion("KB_STS <=", value, "KB_STS");
            return (Criteria) this;
        }

        public Criteria andKB_STSLike(String value) {
            addCriterion("KB_STS like", value, "KB_STS");
            return (Criteria) this;
        }

        public Criteria andKB_STSNotLike(String value) {
            addCriterion("KB_STS not like", value, "KB_STS");
            return (Criteria) this;
        }

        public Criteria andKB_STSIn(List<String> values) {
            addCriterion("KB_STS in", values, "KB_STS");
            return (Criteria) this;
        }

        public Criteria andKB_STSNotIn(List<String> values) {
            addCriterion("KB_STS not in", values, "KB_STS");
            return (Criteria) this;
        }

        public Criteria andKB_STSBetween(String value1, String value2) {
            addCriterion("KB_STS between", value1, value2, "KB_STS");
            return (Criteria) this;
        }

        public Criteria andKB_STSNotBetween(String value1, String value2) {
            addCriterion("KB_STS not between", value1, value2, "KB_STS");
            return (Criteria) this;
        }

        public Criteria andVIDE_LK_FLGIsNull() {
            addCriterion("VIDE_LK_FLG is null");
            return (Criteria) this;
        }

        public Criteria andVIDE_LK_FLGIsNotNull() {
            addCriterion("VIDE_LK_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andVIDE_LK_FLGEqualTo(String value) {
            addCriterion("VIDE_LK_FLG =", value, "VIDE_LK_FLG");
            return (Criteria) this;
        }

        public Criteria andVIDE_LK_FLGNotEqualTo(String value) {
            addCriterion("VIDE_LK_FLG <>", value, "VIDE_LK_FLG");
            return (Criteria) this;
        }

        public Criteria andVIDE_LK_FLGGreaterThan(String value) {
            addCriterion("VIDE_LK_FLG >", value, "VIDE_LK_FLG");
            return (Criteria) this;
        }

        public Criteria andVIDE_LK_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("VIDE_LK_FLG >=", value, "VIDE_LK_FLG");
            return (Criteria) this;
        }

        public Criteria andVIDE_LK_FLGLessThan(String value) {
            addCriterion("VIDE_LK_FLG <", value, "VIDE_LK_FLG");
            return (Criteria) this;
        }

        public Criteria andVIDE_LK_FLGLessThanOrEqualTo(String value) {
            addCriterion("VIDE_LK_FLG <=", value, "VIDE_LK_FLG");
            return (Criteria) this;
        }

        public Criteria andVIDE_LK_FLGLike(String value) {
            addCriterion("VIDE_LK_FLG like", value, "VIDE_LK_FLG");
            return (Criteria) this;
        }

        public Criteria andVIDE_LK_FLGNotLike(String value) {
            addCriterion("VIDE_LK_FLG not like", value, "VIDE_LK_FLG");
            return (Criteria) this;
        }

        public Criteria andVIDE_LK_FLGIn(List<String> values) {
            addCriterion("VIDE_LK_FLG in", values, "VIDE_LK_FLG");
            return (Criteria) this;
        }

        public Criteria andVIDE_LK_FLGNotIn(List<String> values) {
            addCriterion("VIDE_LK_FLG not in", values, "VIDE_LK_FLG");
            return (Criteria) this;
        }

        public Criteria andVIDE_LK_FLGBetween(String value1, String value2) {
            addCriterion("VIDE_LK_FLG between", value1, value2, "VIDE_LK_FLG");
            return (Criteria) this;
        }

        public Criteria andVIDE_LK_FLGNotBetween(String value1, String value2) {
            addCriterion("VIDE_LK_FLG not between", value1, value2, "VIDE_LK_FLG");
            return (Criteria) this;
        }

        public Criteria andVFILE_INFOIsNull() {
            addCriterion("VFILE_INFO is null");
            return (Criteria) this;
        }

        public Criteria andVFILE_INFOIsNotNull() {
            addCriterion("VFILE_INFO is not null");
            return (Criteria) this;
        }

        public Criteria andVFILE_INFOEqualTo(String value) {
            addCriterion("VFILE_INFO =", value, "VFILE_INFO");
            return (Criteria) this;
        }

        public Criteria andVFILE_INFONotEqualTo(String value) {
            addCriterion("VFILE_INFO <>", value, "VFILE_INFO");
            return (Criteria) this;
        }

        public Criteria andVFILE_INFOGreaterThan(String value) {
            addCriterion("VFILE_INFO >", value, "VFILE_INFO");
            return (Criteria) this;
        }

        public Criteria andVFILE_INFOGreaterThanOrEqualTo(String value) {
            addCriterion("VFILE_INFO >=", value, "VFILE_INFO");
            return (Criteria) this;
        }

        public Criteria andVFILE_INFOLessThan(String value) {
            addCriterion("VFILE_INFO <", value, "VFILE_INFO");
            return (Criteria) this;
        }

        public Criteria andVFILE_INFOLessThanOrEqualTo(String value) {
            addCriterion("VFILE_INFO <=", value, "VFILE_INFO");
            return (Criteria) this;
        }

        public Criteria andVFILE_INFOLike(String value) {
            addCriterion("VFILE_INFO like", value, "VFILE_INFO");
            return (Criteria) this;
        }

        public Criteria andVFILE_INFONotLike(String value) {
            addCriterion("VFILE_INFO not like", value, "VFILE_INFO");
            return (Criteria) this;
        }

        public Criteria andVFILE_INFOIn(List<String> values) {
            addCriterion("VFILE_INFO in", values, "VFILE_INFO");
            return (Criteria) this;
        }

        public Criteria andVFILE_INFONotIn(List<String> values) {
            addCriterion("VFILE_INFO not in", values, "VFILE_INFO");
            return (Criteria) this;
        }

        public Criteria andVFILE_INFOBetween(String value1, String value2) {
            addCriterion("VFILE_INFO between", value1, value2, "VFILE_INFO");
            return (Criteria) this;
        }

        public Criteria andVFILE_INFONotBetween(String value1, String value2) {
            addCriterion("VFILE_INFO not between", value1, value2, "VFILE_INFO");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andLN_EVENT_INFO_HSTLikeInsensitive(String value) {
            addCriterion("upper(LN_EVENT_INFO_HST) like", value.toUpperCase(), "LN_EVENT_INFO_HST");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSLikeInsensitive(String value) {
            addCriterion("upper(HASSEI_TS) like", value.toUpperCase(), "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andCHIKU_NMLikeInsensitive(String value) {
            addCriterion("upper(CHIKU_NM) like", value.toUpperCase(), "CHIKU_NM");
            return (Criteria) this;
        }

        public Criteria andKENCHI_NAIYOULikeInsensitive(String value) {
            addCriterion("upper(KENCHI_NAIYOU) like", value.toUpperCase(), "KENCHI_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andKB_STSLikeInsensitive(String value) {
            addCriterion("upper(KB_STS) like", value.toUpperCase(), "KB_STS");
            return (Criteria) this;
        }

        public Criteria andVIDE_LK_FLGLikeInsensitive(String value) {
            addCriterion("upper(VIDE_LK_FLG) like", value.toUpperCase(), "VIDE_LK_FLG");
            return (Criteria) this;
        }

        public Criteria andVFILE_INFOLikeInsensitive(String value) {
            addCriterion("upper(VFILE_INFO) like", value.toUpperCase(), "VFILE_INFO");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * H_EVENT_INFO
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * H_EVENT_INFO null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}