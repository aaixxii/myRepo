package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class HUpdRcvFileVer implements Serializable {
    /**
     * LN_更新ファイル確認読出履歴論理番号
     */
    private String LN_UPD_RCV_FILE_VER;

    /**
     * LN_設置機器論理番号
     */
    private String LN_DEV;

    /**
     * 電計番号
     */
    private String DENKEI;

    /**
     * 装置番号
     */
    private String DEV_NUM;

    /**
     * トランザクション番号
     */
    private String TR_NUM;

    /**
     * コマンドシーケンス番号
     */
    private String CMD_SEQ_NUM;

    /**
     * 型式
     */
    private String MODEL_TYPE;

    /**
     * FWファイル名
     */
    private String FW_FILE_NM;

    /**
     * SDファイル名
     */
    private String SD_FILE_NM;

    /**
     * 暗証番号ファイル名
     */
    private String PIN_FILE_NM;

    /**
     * 更新指定日時
     */
    private String UPD_SET_TS;

    /**
     * 更新者フラグ
     */
    private String UPDATE_FLG;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * H_UPD_RCV_FILE_VER
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_更新ファイル確認読出履歴論理番号
     * @return LN_UPD_RCV_FILE_VER LN_更新ファイル確認読出履歴論理番号
     */
    public String getLN_UPD_RCV_FILE_VER() {
        return LN_UPD_RCV_FILE_VER;
    }

    /**
     * LN_更新ファイル確認読出履歴論理番号
     * @param LN_UPD_RCV_FILE_VER LN_更新ファイル確認読出履歴論理番号
     */
    public void setLN_UPD_RCV_FILE_VER(String LN_UPD_RCV_FILE_VER) {
        this.LN_UPD_RCV_FILE_VER = LN_UPD_RCV_FILE_VER == null ? null : LN_UPD_RCV_FILE_VER.trim();
    }

    /**
     * LN_設置機器論理番号
     * @return LN_DEV LN_設置機器論理番号
     */
    public String getLN_DEV() {
        return LN_DEV;
    }

    /**
     * LN_設置機器論理番号
     * @param LN_DEV LN_設置機器論理番号
     */
    public void setLN_DEV(String LN_DEV) {
        this.LN_DEV = LN_DEV == null ? null : LN_DEV.trim();
    }

    /**
     * 電計番号
     * @return DENKEI 電計番号
     */
    public String getDENKEI() {
        return DENKEI;
    }

    /**
     * 電計番号
     * @param DENKEI 電計番号
     */
    public void setDENKEI(String DENKEI) {
        this.DENKEI = DENKEI == null ? null : DENKEI.trim();
    }

    /**
     * 装置番号
     * @return DEV_NUM 装置番号
     */
    public String getDEV_NUM() {
        return DEV_NUM;
    }

    /**
     * 装置番号
     * @param DEV_NUM 装置番号
     */
    public void setDEV_NUM(String DEV_NUM) {
        this.DEV_NUM = DEV_NUM == null ? null : DEV_NUM.trim();
    }

    /**
     * トランザクション番号
     * @return TR_NUM トランザクション番号
     */
    public String getTR_NUM() {
        return TR_NUM;
    }

    /**
     * トランザクション番号
     * @param TR_NUM トランザクション番号
     */
    public void setTR_NUM(String TR_NUM) {
        this.TR_NUM = TR_NUM == null ? null : TR_NUM.trim();
    }

    /**
     * コマンドシーケンス番号
     * @return CMD_SEQ_NUM コマンドシーケンス番号
     */
    public String getCMD_SEQ_NUM() {
        return CMD_SEQ_NUM;
    }

    /**
     * コマンドシーケンス番号
     * @param CMD_SEQ_NUM コマンドシーケンス番号
     */
    public void setCMD_SEQ_NUM(String CMD_SEQ_NUM) {
        this.CMD_SEQ_NUM = CMD_SEQ_NUM == null ? null : CMD_SEQ_NUM.trim();
    }

    /**
     * 型式
     * @return MODEL_TYPE 型式
     */
    public String getMODEL_TYPE() {
        return MODEL_TYPE;
    }

    /**
     * 型式
     * @param MODEL_TYPE 型式
     */
    public void setMODEL_TYPE(String MODEL_TYPE) {
        this.MODEL_TYPE = MODEL_TYPE == null ? null : MODEL_TYPE.trim();
    }

    /**
     * FWファイル名
     * @return FW_FILE_NM FWファイル名
     */
    public String getFW_FILE_NM() {
        return FW_FILE_NM;
    }

    /**
     * FWファイル名
     * @param FW_FILE_NM FWファイル名
     */
    public void setFW_FILE_NM(String FW_FILE_NM) {
        this.FW_FILE_NM = FW_FILE_NM == null ? null : FW_FILE_NM.trim();
    }

    /**
     * SDファイル名
     * @return SD_FILE_NM SDファイル名
     */
    public String getSD_FILE_NM() {
        return SD_FILE_NM;
    }

    /**
     * SDファイル名
     * @param SD_FILE_NM SDファイル名
     */
    public void setSD_FILE_NM(String SD_FILE_NM) {
        this.SD_FILE_NM = SD_FILE_NM == null ? null : SD_FILE_NM.trim();
    }

    /**
     * 暗証番号ファイル名
     * @return PIN_FILE_NM 暗証番号ファイル名
     */
    public String getPIN_FILE_NM() {
        return PIN_FILE_NM;
    }

    /**
     * 暗証番号ファイル名
     * @param PIN_FILE_NM 暗証番号ファイル名
     */
    public void setPIN_FILE_NM(String PIN_FILE_NM) {
        this.PIN_FILE_NM = PIN_FILE_NM == null ? null : PIN_FILE_NM.trim();
    }

    /**
     * 更新指定日時
     * @return UPD_SET_TS 更新指定日時
     */
    public String getUPD_SET_TS() {
        return UPD_SET_TS;
    }

    /**
     * 更新指定日時
     * @param UPD_SET_TS 更新指定日時
     */
    public void setUPD_SET_TS(String UPD_SET_TS) {
        this.UPD_SET_TS = UPD_SET_TS == null ? null : UPD_SET_TS.trim();
    }

    /**
     * 更新者フラグ
     * @return UPDATE_FLG 更新者フラグ
     */
    public String getUPDATE_FLG() {
        return UPDATE_FLG;
    }

    /**
     * 更新者フラグ
     * @param UPDATE_FLG 更新者フラグ
     */
    public void setUPDATE_FLG(String UPDATE_FLG) {
        this.UPDATE_FLG = UPDATE_FLG == null ? null : UPDATE_FLG.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}