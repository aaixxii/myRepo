package jp.co.alsok.g6.db.entity.com;

import java.io.Serializable;
import java.util.Date;

public class KAlsokAuthMst implements Serializable {
    /**
     * ALSOKアカウント権限ID
     */
    private String ALSOK_ACNT_AUTH_ID;

    /**
     * ALSOKアカウント権限名称
     */
    private String ALSOK_ACNT_AUTH_NM;

    /**
     * アカウント区分
     */
    private String ACNT_KBN;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * K_ALSOK_AUTH_MST
     */
    private static final long serialVersionUID = 1L;

    /**
     * ALSOKアカウント権限ID
     * @return ALSOK_ACNT_AUTH_ID ALSOKアカウント権限ID
     */
    public String getALSOK_ACNT_AUTH_ID() {
        return ALSOK_ACNT_AUTH_ID;
    }

    /**
     * ALSOKアカウント権限ID
     * @param ALSOK_ACNT_AUTH_ID ALSOKアカウント権限ID
     */
    public void setALSOK_ACNT_AUTH_ID(String ALSOK_ACNT_AUTH_ID) {
        this.ALSOK_ACNT_AUTH_ID = ALSOK_ACNT_AUTH_ID == null ? null : ALSOK_ACNT_AUTH_ID.trim();
    }

    /**
     * ALSOKアカウント権限名称
     * @return ALSOK_ACNT_AUTH_NM ALSOKアカウント権限名称
     */
    public String getALSOK_ACNT_AUTH_NM() {
        return ALSOK_ACNT_AUTH_NM;
    }

    /**
     * ALSOKアカウント権限名称
     * @param ALSOK_ACNT_AUTH_NM ALSOKアカウント権限名称
     */
    public void setALSOK_ACNT_AUTH_NM(String ALSOK_ACNT_AUTH_NM) {
        this.ALSOK_ACNT_AUTH_NM = ALSOK_ACNT_AUTH_NM == null ? null : ALSOK_ACNT_AUTH_NM.trim();
    }

    /**
     * アカウント区分
     * @return ACNT_KBN アカウント区分
     */
    public String getACNT_KBN() {
        return ACNT_KBN;
    }

    /**
     * アカウント区分
     * @param ACNT_KBN アカウント区分
     */
    public void setACNT_KBN(String ACNT_KBN) {
        this.ACNT_KBN = ACNT_KBN == null ? null : ACNT_KBN.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}