package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EV6JianjfFullExample {
    /**
     * E_V6_JIANJF_FULL
     */
    protected String orderByClause;

    /**
     * E_V6_JIANJF_FULL
     */
    protected boolean distinct;

    /**
     * E_V6_JIANJF_FULL
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public EV6JianjfFullExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * E_V6_JIANJF_FULL null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andGC_NUMIsNull() {
            addCriterion("GC_NUM is null");
            return (Criteria) this;
        }

        public Criteria andGC_NUMIsNotNull() {
            addCriterion("GC_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andGC_NUMEqualTo(String value) {
            addCriterion("GC_NUM =", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMNotEqualTo(String value) {
            addCriterion("GC_NUM <>", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMGreaterThan(String value) {
            addCriterion("GC_NUM >", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("GC_NUM >=", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMLessThan(String value) {
            addCriterion("GC_NUM <", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMLessThanOrEqualTo(String value) {
            addCriterion("GC_NUM <=", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMLike(String value) {
            addCriterion("GC_NUM like", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMNotLike(String value) {
            addCriterion("GC_NUM not like", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMIn(List<String> values) {
            addCriterion("GC_NUM in", values, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMNotIn(List<String> values) {
            addCriterion("GC_NUM not in", values, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMBetween(String value1, String value2) {
            addCriterion("GC_NUM between", value1, value2, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMNotBetween(String value1, String value2) {
            addCriterion("GC_NUM not between", value1, value2, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_SGSIsNull() {
            addCriterion("LN_SGS is null");
            return (Criteria) this;
        }

        public Criteria andLN_SGSIsNotNull() {
            addCriterion("LN_SGS is not null");
            return (Criteria) this;
        }

        public Criteria andLN_SGSEqualTo(String value) {
            addCriterion("LN_SGS =", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSNotEqualTo(String value) {
            addCriterion("LN_SGS <>", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSGreaterThan(String value) {
            addCriterion("LN_SGS >", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSGreaterThanOrEqualTo(String value) {
            addCriterion("LN_SGS >=", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSLessThan(String value) {
            addCriterion("LN_SGS <", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSLessThanOrEqualTo(String value) {
            addCriterion("LN_SGS <=", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSLike(String value) {
            addCriterion("LN_SGS like", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSNotLike(String value) {
            addCriterion("LN_SGS not like", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSIn(List<String> values) {
            addCriterion("LN_SGS in", values, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSNotIn(List<String> values) {
            addCriterion("LN_SGS not in", values, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSBetween(String value1, String value2) {
            addCriterion("LN_SGS between", value1, value2, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSNotBetween(String value1, String value2) {
            addCriterion("LN_SGS not between", value1, value2, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andGOUKIIsNull() {
            addCriterion("GOUKI is null");
            return (Criteria) this;
        }

        public Criteria andGOUKIIsNotNull() {
            addCriterion("GOUKI is not null");
            return (Criteria) this;
        }

        public Criteria andGOUKIEqualTo(String value) {
            addCriterion("GOUKI =", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKINotEqualTo(String value) {
            addCriterion("GOUKI <>", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKIGreaterThan(String value) {
            addCriterion("GOUKI >", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKIGreaterThanOrEqualTo(String value) {
            addCriterion("GOUKI >=", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKILessThan(String value) {
            addCriterion("GOUKI <", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKILessThanOrEqualTo(String value) {
            addCriterion("GOUKI <=", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKILike(String value) {
            addCriterion("GOUKI like", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKINotLike(String value) {
            addCriterion("GOUKI not like", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKIIn(List<String> values) {
            addCriterion("GOUKI in", values, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKINotIn(List<String> values) {
            addCriterion("GOUKI not in", values, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKIBetween(String value1, String value2) {
            addCriterion("GOUKI between", value1, value2, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKINotBetween(String value1, String value2) {
            addCriterion("GOUKI not between", value1, value2, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andDENKEIIsNull() {
            addCriterion("DENKEI is null");
            return (Criteria) this;
        }

        public Criteria andDENKEIIsNotNull() {
            addCriterion("DENKEI is not null");
            return (Criteria) this;
        }

        public Criteria andDENKEIEqualTo(String value) {
            addCriterion("DENKEI =", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEINotEqualTo(String value) {
            addCriterion("DENKEI <>", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEIGreaterThan(String value) {
            addCriterion("DENKEI >", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEIGreaterThanOrEqualTo(String value) {
            addCriterion("DENKEI >=", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEILessThan(String value) {
            addCriterion("DENKEI <", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEILessThanOrEqualTo(String value) {
            addCriterion("DENKEI <=", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEILike(String value) {
            addCriterion("DENKEI like", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEINotLike(String value) {
            addCriterion("DENKEI not like", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEIIn(List<String> values) {
            addCriterion("DENKEI in", values, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEINotIn(List<String> values) {
            addCriterion("DENKEI not in", values, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEIBetween(String value1, String value2) {
            addCriterion("DENKEI between", value1, value2, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEINotBetween(String value1, String value2) {
            addCriterion("DENKEI not between", value1, value2, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andSUBADDRIsNull() {
            addCriterion("SUBADDR is null");
            return (Criteria) this;
        }

        public Criteria andSUBADDRIsNotNull() {
            addCriterion("SUBADDR is not null");
            return (Criteria) this;
        }

        public Criteria andSUBADDREqualTo(String value) {
            addCriterion("SUBADDR =", value, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRNotEqualTo(String value) {
            addCriterion("SUBADDR <>", value, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRGreaterThan(String value) {
            addCriterion("SUBADDR >", value, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRGreaterThanOrEqualTo(String value) {
            addCriterion("SUBADDR >=", value, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRLessThan(String value) {
            addCriterion("SUBADDR <", value, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRLessThanOrEqualTo(String value) {
            addCriterion("SUBADDR <=", value, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRLike(String value) {
            addCriterion("SUBADDR like", value, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRNotLike(String value) {
            addCriterion("SUBADDR not like", value, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRIn(List<String> values) {
            addCriterion("SUBADDR in", values, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRNotIn(List<String> values) {
            addCriterion("SUBADDR not in", values, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRBetween(String value1, String value2) {
            addCriterion("SUBADDR between", value1, value2, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRNotBetween(String value1, String value2) {
            addCriterion("SUBADDR not between", value1, value2, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDIsNull() {
            addCriterion("KEIYAKU_ID is null");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDIsNotNull() {
            addCriterion("KEIYAKU_ID is not null");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDEqualTo(String value) {
            addCriterion("KEIYAKU_ID =", value, "KEIYAKU_ID");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDNotEqualTo(String value) {
            addCriterion("KEIYAKU_ID <>", value, "KEIYAKU_ID");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDGreaterThan(String value) {
            addCriterion("KEIYAKU_ID >", value, "KEIYAKU_ID");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDGreaterThanOrEqualTo(String value) {
            addCriterion("KEIYAKU_ID >=", value, "KEIYAKU_ID");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDLessThan(String value) {
            addCriterion("KEIYAKU_ID <", value, "KEIYAKU_ID");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDLessThanOrEqualTo(String value) {
            addCriterion("KEIYAKU_ID <=", value, "KEIYAKU_ID");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDLike(String value) {
            addCriterion("KEIYAKU_ID like", value, "KEIYAKU_ID");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDNotLike(String value) {
            addCriterion("KEIYAKU_ID not like", value, "KEIYAKU_ID");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDIn(List<String> values) {
            addCriterion("KEIYAKU_ID in", values, "KEIYAKU_ID");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDNotIn(List<String> values) {
            addCriterion("KEIYAKU_ID not in", values, "KEIYAKU_ID");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDBetween(String value1, String value2) {
            addCriterion("KEIYAKU_ID between", value1, value2, "KEIYAKU_ID");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDNotBetween(String value1, String value2) {
            addCriterion("KEIYAKU_ID not between", value1, value2, "KEIYAKU_ID");
            return (Criteria) this;
        }

        public Criteria andHASSEI_IDIsNull() {
            addCriterion("HASSEI_ID is null");
            return (Criteria) this;
        }

        public Criteria andHASSEI_IDIsNotNull() {
            addCriterion("HASSEI_ID is not null");
            return (Criteria) this;
        }

        public Criteria andHASSEI_IDEqualTo(String value) {
            addCriterion("HASSEI_ID =", value, "HASSEI_ID");
            return (Criteria) this;
        }

        public Criteria andHASSEI_IDNotEqualTo(String value) {
            addCriterion("HASSEI_ID <>", value, "HASSEI_ID");
            return (Criteria) this;
        }

        public Criteria andHASSEI_IDGreaterThan(String value) {
            addCriterion("HASSEI_ID >", value, "HASSEI_ID");
            return (Criteria) this;
        }

        public Criteria andHASSEI_IDGreaterThanOrEqualTo(String value) {
            addCriterion("HASSEI_ID >=", value, "HASSEI_ID");
            return (Criteria) this;
        }

        public Criteria andHASSEI_IDLessThan(String value) {
            addCriterion("HASSEI_ID <", value, "HASSEI_ID");
            return (Criteria) this;
        }

        public Criteria andHASSEI_IDLessThanOrEqualTo(String value) {
            addCriterion("HASSEI_ID <=", value, "HASSEI_ID");
            return (Criteria) this;
        }

        public Criteria andHASSEI_IDLike(String value) {
            addCriterion("HASSEI_ID like", value, "HASSEI_ID");
            return (Criteria) this;
        }

        public Criteria andHASSEI_IDNotLike(String value) {
            addCriterion("HASSEI_ID not like", value, "HASSEI_ID");
            return (Criteria) this;
        }

        public Criteria andHASSEI_IDIn(List<String> values) {
            addCriterion("HASSEI_ID in", values, "HASSEI_ID");
            return (Criteria) this;
        }

        public Criteria andHASSEI_IDNotIn(List<String> values) {
            addCriterion("HASSEI_ID not in", values, "HASSEI_ID");
            return (Criteria) this;
        }

        public Criteria andHASSEI_IDBetween(String value1, String value2) {
            addCriterion("HASSEI_ID between", value1, value2, "HASSEI_ID");
            return (Criteria) this;
        }

        public Criteria andHASSEI_IDNotBetween(String value1, String value2) {
            addCriterion("HASSEI_ID not between", value1, value2, "HASSEI_ID");
            return (Criteria) this;
        }

        public Criteria andCOURSE_NUMIsNull() {
            addCriterion("COURSE_NUM is null");
            return (Criteria) this;
        }

        public Criteria andCOURSE_NUMIsNotNull() {
            addCriterion("COURSE_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andCOURSE_NUMEqualTo(String value) {
            addCriterion("COURSE_NUM =", value, "COURSE_NUM");
            return (Criteria) this;
        }

        public Criteria andCOURSE_NUMNotEqualTo(String value) {
            addCriterion("COURSE_NUM <>", value, "COURSE_NUM");
            return (Criteria) this;
        }

        public Criteria andCOURSE_NUMGreaterThan(String value) {
            addCriterion("COURSE_NUM >", value, "COURSE_NUM");
            return (Criteria) this;
        }

        public Criteria andCOURSE_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("COURSE_NUM >=", value, "COURSE_NUM");
            return (Criteria) this;
        }

        public Criteria andCOURSE_NUMLessThan(String value) {
            addCriterion("COURSE_NUM <", value, "COURSE_NUM");
            return (Criteria) this;
        }

        public Criteria andCOURSE_NUMLessThanOrEqualTo(String value) {
            addCriterion("COURSE_NUM <=", value, "COURSE_NUM");
            return (Criteria) this;
        }

        public Criteria andCOURSE_NUMLike(String value) {
            addCriterion("COURSE_NUM like", value, "COURSE_NUM");
            return (Criteria) this;
        }

        public Criteria andCOURSE_NUMNotLike(String value) {
            addCriterion("COURSE_NUM not like", value, "COURSE_NUM");
            return (Criteria) this;
        }

        public Criteria andCOURSE_NUMIn(List<String> values) {
            addCriterion("COURSE_NUM in", values, "COURSE_NUM");
            return (Criteria) this;
        }

        public Criteria andCOURSE_NUMNotIn(List<String> values) {
            addCriterion("COURSE_NUM not in", values, "COURSE_NUM");
            return (Criteria) this;
        }

        public Criteria andCOURSE_NUMBetween(String value1, String value2) {
            addCriterion("COURSE_NUM between", value1, value2, "COURSE_NUM");
            return (Criteria) this;
        }

        public Criteria andCOURSE_NUMNotBetween(String value1, String value2) {
            addCriterion("COURSE_NUM not between", value1, value2, "COURSE_NUM");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_1IsNull() {
            addCriterion("KEIBI_NM_1 is null");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_1IsNotNull() {
            addCriterion("KEIBI_NM_1 is not null");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_1EqualTo(String value) {
            addCriterion("KEIBI_NM_1 =", value, "KEIBI_NM_1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_1NotEqualTo(String value) {
            addCriterion("KEIBI_NM_1 <>", value, "KEIBI_NM_1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_1GreaterThan(String value) {
            addCriterion("KEIBI_NM_1 >", value, "KEIBI_NM_1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_1GreaterThanOrEqualTo(String value) {
            addCriterion("KEIBI_NM_1 >=", value, "KEIBI_NM_1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_1LessThan(String value) {
            addCriterion("KEIBI_NM_1 <", value, "KEIBI_NM_1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_1LessThanOrEqualTo(String value) {
            addCriterion("KEIBI_NM_1 <=", value, "KEIBI_NM_1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_1Like(String value) {
            addCriterion("KEIBI_NM_1 like", value, "KEIBI_NM_1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_1NotLike(String value) {
            addCriterion("KEIBI_NM_1 not like", value, "KEIBI_NM_1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_1In(List<String> values) {
            addCriterion("KEIBI_NM_1 in", values, "KEIBI_NM_1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_1NotIn(List<String> values) {
            addCriterion("KEIBI_NM_1 not in", values, "KEIBI_NM_1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_1Between(String value1, String value2) {
            addCriterion("KEIBI_NM_1 between", value1, value2, "KEIBI_NM_1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_1NotBetween(String value1, String value2) {
            addCriterion("KEIBI_NM_1 not between", value1, value2, "KEIBI_NM_1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_2IsNull() {
            addCriterion("KEIBI_NM_2 is null");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_2IsNotNull() {
            addCriterion("KEIBI_NM_2 is not null");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_2EqualTo(String value) {
            addCriterion("KEIBI_NM_2 =", value, "KEIBI_NM_2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_2NotEqualTo(String value) {
            addCriterion("KEIBI_NM_2 <>", value, "KEIBI_NM_2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_2GreaterThan(String value) {
            addCriterion("KEIBI_NM_2 >", value, "KEIBI_NM_2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_2GreaterThanOrEqualTo(String value) {
            addCriterion("KEIBI_NM_2 >=", value, "KEIBI_NM_2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_2LessThan(String value) {
            addCriterion("KEIBI_NM_2 <", value, "KEIBI_NM_2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_2LessThanOrEqualTo(String value) {
            addCriterion("KEIBI_NM_2 <=", value, "KEIBI_NM_2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_2Like(String value) {
            addCriterion("KEIBI_NM_2 like", value, "KEIBI_NM_2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_2NotLike(String value) {
            addCriterion("KEIBI_NM_2 not like", value, "KEIBI_NM_2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_2In(List<String> values) {
            addCriterion("KEIBI_NM_2 in", values, "KEIBI_NM_2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_2NotIn(List<String> values) {
            addCriterion("KEIBI_NM_2 not in", values, "KEIBI_NM_2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_2Between(String value1, String value2) {
            addCriterion("KEIBI_NM_2 between", value1, value2, "KEIBI_NM_2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_2NotBetween(String value1, String value2) {
            addCriterion("KEIBI_NM_2 not between", value1, value2, "KEIBI_NM_2");
            return (Criteria) this;
        }

        public Criteria andABBR_NMIsNull() {
            addCriterion("ABBR_NM is null");
            return (Criteria) this;
        }

        public Criteria andABBR_NMIsNotNull() {
            addCriterion("ABBR_NM is not null");
            return (Criteria) this;
        }

        public Criteria andABBR_NMEqualTo(String value) {
            addCriterion("ABBR_NM =", value, "ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andABBR_NMNotEqualTo(String value) {
            addCriterion("ABBR_NM <>", value, "ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andABBR_NMGreaterThan(String value) {
            addCriterion("ABBR_NM >", value, "ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andABBR_NMGreaterThanOrEqualTo(String value) {
            addCriterion("ABBR_NM >=", value, "ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andABBR_NMLessThan(String value) {
            addCriterion("ABBR_NM <", value, "ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andABBR_NMLessThanOrEqualTo(String value) {
            addCriterion("ABBR_NM <=", value, "ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andABBR_NMLike(String value) {
            addCriterion("ABBR_NM like", value, "ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andABBR_NMNotLike(String value) {
            addCriterion("ABBR_NM not like", value, "ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andABBR_NMIn(List<String> values) {
            addCriterion("ABBR_NM in", values, "ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andABBR_NMNotIn(List<String> values) {
            addCriterion("ABBR_NM not in", values, "ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andABBR_NMBetween(String value1, String value2) {
            addCriterion("ABBR_NM between", value1, value2, "ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andABBR_NMNotBetween(String value1, String value2) {
            addCriterion("ABBR_NM not between", value1, value2, "ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andADDR_CDIsNull() {
            addCriterion("ADDR_CD is null");
            return (Criteria) this;
        }

        public Criteria andADDR_CDIsNotNull() {
            addCriterion("ADDR_CD is not null");
            return (Criteria) this;
        }

        public Criteria andADDR_CDEqualTo(String value) {
            addCriterion("ADDR_CD =", value, "ADDR_CD");
            return (Criteria) this;
        }

        public Criteria andADDR_CDNotEqualTo(String value) {
            addCriterion("ADDR_CD <>", value, "ADDR_CD");
            return (Criteria) this;
        }

        public Criteria andADDR_CDGreaterThan(String value) {
            addCriterion("ADDR_CD >", value, "ADDR_CD");
            return (Criteria) this;
        }

        public Criteria andADDR_CDGreaterThanOrEqualTo(String value) {
            addCriterion("ADDR_CD >=", value, "ADDR_CD");
            return (Criteria) this;
        }

        public Criteria andADDR_CDLessThan(String value) {
            addCriterion("ADDR_CD <", value, "ADDR_CD");
            return (Criteria) this;
        }

        public Criteria andADDR_CDLessThanOrEqualTo(String value) {
            addCriterion("ADDR_CD <=", value, "ADDR_CD");
            return (Criteria) this;
        }

        public Criteria andADDR_CDLike(String value) {
            addCriterion("ADDR_CD like", value, "ADDR_CD");
            return (Criteria) this;
        }

        public Criteria andADDR_CDNotLike(String value) {
            addCriterion("ADDR_CD not like", value, "ADDR_CD");
            return (Criteria) this;
        }

        public Criteria andADDR_CDIn(List<String> values) {
            addCriterion("ADDR_CD in", values, "ADDR_CD");
            return (Criteria) this;
        }

        public Criteria andADDR_CDNotIn(List<String> values) {
            addCriterion("ADDR_CD not in", values, "ADDR_CD");
            return (Criteria) this;
        }

        public Criteria andADDR_CDBetween(String value1, String value2) {
            addCriterion("ADDR_CD between", value1, value2, "ADDR_CD");
            return (Criteria) this;
        }

        public Criteria andADDR_CDNotBetween(String value1, String value2) {
            addCriterion("ADDR_CD not between", value1, value2, "ADDR_CD");
            return (Criteria) this;
        }

        public Criteria andKEISATUIsNull() {
            addCriterion("KEISATU is null");
            return (Criteria) this;
        }

        public Criteria andKEISATUIsNotNull() {
            addCriterion("KEISATU is not null");
            return (Criteria) this;
        }

        public Criteria andKEISATUEqualTo(String value) {
            addCriterion("KEISATU =", value, "KEISATU");
            return (Criteria) this;
        }

        public Criteria andKEISATUNotEqualTo(String value) {
            addCriterion("KEISATU <>", value, "KEISATU");
            return (Criteria) this;
        }

        public Criteria andKEISATUGreaterThan(String value) {
            addCriterion("KEISATU >", value, "KEISATU");
            return (Criteria) this;
        }

        public Criteria andKEISATUGreaterThanOrEqualTo(String value) {
            addCriterion("KEISATU >=", value, "KEISATU");
            return (Criteria) this;
        }

        public Criteria andKEISATULessThan(String value) {
            addCriterion("KEISATU <", value, "KEISATU");
            return (Criteria) this;
        }

        public Criteria andKEISATULessThanOrEqualTo(String value) {
            addCriterion("KEISATU <=", value, "KEISATU");
            return (Criteria) this;
        }

        public Criteria andKEISATULike(String value) {
            addCriterion("KEISATU like", value, "KEISATU");
            return (Criteria) this;
        }

        public Criteria andKEISATUNotLike(String value) {
            addCriterion("KEISATU not like", value, "KEISATU");
            return (Criteria) this;
        }

        public Criteria andKEISATUIn(List<String> values) {
            addCriterion("KEISATU in", values, "KEISATU");
            return (Criteria) this;
        }

        public Criteria andKEISATUNotIn(List<String> values) {
            addCriterion("KEISATU not in", values, "KEISATU");
            return (Criteria) this;
        }

        public Criteria andKEISATUBetween(String value1, String value2) {
            addCriterion("KEISATU between", value1, value2, "KEISATU");
            return (Criteria) this;
        }

        public Criteria andKEISATUNotBetween(String value1, String value2) {
            addCriterion("KEISATU not between", value1, value2, "KEISATU");
            return (Criteria) this;
        }

        public Criteria andSYOUBOU_FLGIsNull() {
            addCriterion("SYOUBOU_FLG is null");
            return (Criteria) this;
        }

        public Criteria andSYOUBOU_FLGIsNotNull() {
            addCriterion("SYOUBOU_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andSYOUBOU_FLGEqualTo(String value) {
            addCriterion("SYOUBOU_FLG =", value, "SYOUBOU_FLG");
            return (Criteria) this;
        }

        public Criteria andSYOUBOU_FLGNotEqualTo(String value) {
            addCriterion("SYOUBOU_FLG <>", value, "SYOUBOU_FLG");
            return (Criteria) this;
        }

        public Criteria andSYOUBOU_FLGGreaterThan(String value) {
            addCriterion("SYOUBOU_FLG >", value, "SYOUBOU_FLG");
            return (Criteria) this;
        }

        public Criteria andSYOUBOU_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("SYOUBOU_FLG >=", value, "SYOUBOU_FLG");
            return (Criteria) this;
        }

        public Criteria andSYOUBOU_FLGLessThan(String value) {
            addCriterion("SYOUBOU_FLG <", value, "SYOUBOU_FLG");
            return (Criteria) this;
        }

        public Criteria andSYOUBOU_FLGLessThanOrEqualTo(String value) {
            addCriterion("SYOUBOU_FLG <=", value, "SYOUBOU_FLG");
            return (Criteria) this;
        }

        public Criteria andSYOUBOU_FLGLike(String value) {
            addCriterion("SYOUBOU_FLG like", value, "SYOUBOU_FLG");
            return (Criteria) this;
        }

        public Criteria andSYOUBOU_FLGNotLike(String value) {
            addCriterion("SYOUBOU_FLG not like", value, "SYOUBOU_FLG");
            return (Criteria) this;
        }

        public Criteria andSYOUBOU_FLGIn(List<String> values) {
            addCriterion("SYOUBOU_FLG in", values, "SYOUBOU_FLG");
            return (Criteria) this;
        }

        public Criteria andSYOUBOU_FLGNotIn(List<String> values) {
            addCriterion("SYOUBOU_FLG not in", values, "SYOUBOU_FLG");
            return (Criteria) this;
        }

        public Criteria andSYOUBOU_FLGBetween(String value1, String value2) {
            addCriterion("SYOUBOU_FLG between", value1, value2, "SYOUBOU_FLG");
            return (Criteria) this;
        }

        public Criteria andSYOUBOU_FLGNotBetween(String value1, String value2) {
            addCriterion("SYOUBOU_FLG not between", value1, value2, "SYOUBOU_FLG");
            return (Criteria) this;
        }

        public Criteria andSOK_KBIsNull() {
            addCriterion("SOK_KB is null");
            return (Criteria) this;
        }

        public Criteria andSOK_KBIsNotNull() {
            addCriterion("SOK_KB is not null");
            return (Criteria) this;
        }

        public Criteria andSOK_KBEqualTo(String value) {
            addCriterion("SOK_KB =", value, "SOK_KB");
            return (Criteria) this;
        }

        public Criteria andSOK_KBNotEqualTo(String value) {
            addCriterion("SOK_KB <>", value, "SOK_KB");
            return (Criteria) this;
        }

        public Criteria andSOK_KBGreaterThan(String value) {
            addCriterion("SOK_KB >", value, "SOK_KB");
            return (Criteria) this;
        }

        public Criteria andSOK_KBGreaterThanOrEqualTo(String value) {
            addCriterion("SOK_KB >=", value, "SOK_KB");
            return (Criteria) this;
        }

        public Criteria andSOK_KBLessThan(String value) {
            addCriterion("SOK_KB <", value, "SOK_KB");
            return (Criteria) this;
        }

        public Criteria andSOK_KBLessThanOrEqualTo(String value) {
            addCriterion("SOK_KB <=", value, "SOK_KB");
            return (Criteria) this;
        }

        public Criteria andSOK_KBLike(String value) {
            addCriterion("SOK_KB like", value, "SOK_KB");
            return (Criteria) this;
        }

        public Criteria andSOK_KBNotLike(String value) {
            addCriterion("SOK_KB not like", value, "SOK_KB");
            return (Criteria) this;
        }

        public Criteria andSOK_KBIn(List<String> values) {
            addCriterion("SOK_KB in", values, "SOK_KB");
            return (Criteria) this;
        }

        public Criteria andSOK_KBNotIn(List<String> values) {
            addCriterion("SOK_KB not in", values, "SOK_KB");
            return (Criteria) this;
        }

        public Criteria andSOK_KBBetween(String value1, String value2) {
            addCriterion("SOK_KB between", value1, value2, "SOK_KB");
            return (Criteria) this;
        }

        public Criteria andSOK_KBNotBetween(String value1, String value2) {
            addCriterion("SOK_KB not between", value1, value2, "SOK_KB");
            return (Criteria) this;
        }

        public Criteria andSYUKKIN_KBNIsNull() {
            addCriterion("SYUKKIN_KBN is null");
            return (Criteria) this;
        }

        public Criteria andSYUKKIN_KBNIsNotNull() {
            addCriterion("SYUKKIN_KBN is not null");
            return (Criteria) this;
        }

        public Criteria andSYUKKIN_KBNEqualTo(String value) {
            addCriterion("SYUKKIN_KBN =", value, "SYUKKIN_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUKKIN_KBNNotEqualTo(String value) {
            addCriterion("SYUKKIN_KBN <>", value, "SYUKKIN_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUKKIN_KBNGreaterThan(String value) {
            addCriterion("SYUKKIN_KBN >", value, "SYUKKIN_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUKKIN_KBNGreaterThanOrEqualTo(String value) {
            addCriterion("SYUKKIN_KBN >=", value, "SYUKKIN_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUKKIN_KBNLessThan(String value) {
            addCriterion("SYUKKIN_KBN <", value, "SYUKKIN_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUKKIN_KBNLessThanOrEqualTo(String value) {
            addCriterion("SYUKKIN_KBN <=", value, "SYUKKIN_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUKKIN_KBNLike(String value) {
            addCriterion("SYUKKIN_KBN like", value, "SYUKKIN_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUKKIN_KBNNotLike(String value) {
            addCriterion("SYUKKIN_KBN not like", value, "SYUKKIN_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUKKIN_KBNIn(List<String> values) {
            addCriterion("SYUKKIN_KBN in", values, "SYUKKIN_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUKKIN_KBNNotIn(List<String> values) {
            addCriterion("SYUKKIN_KBN not in", values, "SYUKKIN_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUKKIN_KBNBetween(String value1, String value2) {
            addCriterion("SYUKKIN_KBN between", value1, value2, "SYUKKIN_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUKKIN_KBNNotBetween(String value1, String value2) {
            addCriterion("SYUKKIN_KBN not between", value1, value2, "SYUKKIN_KBN");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKIsNull() {
            addCriterion("OUEN_MARK is null");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKIsNotNull() {
            addCriterion("OUEN_MARK is not null");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKEqualTo(String value) {
            addCriterion("OUEN_MARK =", value, "OUEN_MARK");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKNotEqualTo(String value) {
            addCriterion("OUEN_MARK <>", value, "OUEN_MARK");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKGreaterThan(String value) {
            addCriterion("OUEN_MARK >", value, "OUEN_MARK");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKGreaterThanOrEqualTo(String value) {
            addCriterion("OUEN_MARK >=", value, "OUEN_MARK");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKLessThan(String value) {
            addCriterion("OUEN_MARK <", value, "OUEN_MARK");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKLessThanOrEqualTo(String value) {
            addCriterion("OUEN_MARK <=", value, "OUEN_MARK");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKLike(String value) {
            addCriterion("OUEN_MARK like", value, "OUEN_MARK");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKNotLike(String value) {
            addCriterion("OUEN_MARK not like", value, "OUEN_MARK");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKIn(List<String> values) {
            addCriterion("OUEN_MARK in", values, "OUEN_MARK");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKNotIn(List<String> values) {
            addCriterion("OUEN_MARK not in", values, "OUEN_MARK");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKBetween(String value1, String value2) {
            addCriterion("OUEN_MARK between", value1, value2, "OUEN_MARK");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKNotBetween(String value1, String value2) {
            addCriterion("OUEN_MARK not between", value1, value2, "OUEN_MARK");
            return (Criteria) this;
        }

        public Criteria andUKE_SEKIIsNull() {
            addCriterion("UKE_SEKI is null");
            return (Criteria) this;
        }

        public Criteria andUKE_SEKIIsNotNull() {
            addCriterion("UKE_SEKI is not null");
            return (Criteria) this;
        }

        public Criteria andUKE_SEKIEqualTo(String value) {
            addCriterion("UKE_SEKI =", value, "UKE_SEKI");
            return (Criteria) this;
        }

        public Criteria andUKE_SEKINotEqualTo(String value) {
            addCriterion("UKE_SEKI <>", value, "UKE_SEKI");
            return (Criteria) this;
        }

        public Criteria andUKE_SEKIGreaterThan(String value) {
            addCriterion("UKE_SEKI >", value, "UKE_SEKI");
            return (Criteria) this;
        }

        public Criteria andUKE_SEKIGreaterThanOrEqualTo(String value) {
            addCriterion("UKE_SEKI >=", value, "UKE_SEKI");
            return (Criteria) this;
        }

        public Criteria andUKE_SEKILessThan(String value) {
            addCriterion("UKE_SEKI <", value, "UKE_SEKI");
            return (Criteria) this;
        }

        public Criteria andUKE_SEKILessThanOrEqualTo(String value) {
            addCriterion("UKE_SEKI <=", value, "UKE_SEKI");
            return (Criteria) this;
        }

        public Criteria andUKE_SEKILike(String value) {
            addCriterion("UKE_SEKI like", value, "UKE_SEKI");
            return (Criteria) this;
        }

        public Criteria andUKE_SEKINotLike(String value) {
            addCriterion("UKE_SEKI not like", value, "UKE_SEKI");
            return (Criteria) this;
        }

        public Criteria andUKE_SEKIIn(List<String> values) {
            addCriterion("UKE_SEKI in", values, "UKE_SEKI");
            return (Criteria) this;
        }

        public Criteria andUKE_SEKINotIn(List<String> values) {
            addCriterion("UKE_SEKI not in", values, "UKE_SEKI");
            return (Criteria) this;
        }

        public Criteria andUKE_SEKIBetween(String value1, String value2) {
            addCriterion("UKE_SEKI between", value1, value2, "UKE_SEKI");
            return (Criteria) this;
        }

        public Criteria andUKE_SEKINotBetween(String value1, String value2) {
            addCriterion("UKE_SEKI not between", value1, value2, "UKE_SEKI");
            return (Criteria) this;
        }

        public Criteria andTANTOU_SEKIIsNull() {
            addCriterion("TANTOU_SEKI is null");
            return (Criteria) this;
        }

        public Criteria andTANTOU_SEKIIsNotNull() {
            addCriterion("TANTOU_SEKI is not null");
            return (Criteria) this;
        }

        public Criteria andTANTOU_SEKIEqualTo(String value) {
            addCriterion("TANTOU_SEKI =", value, "TANTOU_SEKI");
            return (Criteria) this;
        }

        public Criteria andTANTOU_SEKINotEqualTo(String value) {
            addCriterion("TANTOU_SEKI <>", value, "TANTOU_SEKI");
            return (Criteria) this;
        }

        public Criteria andTANTOU_SEKIGreaterThan(String value) {
            addCriterion("TANTOU_SEKI >", value, "TANTOU_SEKI");
            return (Criteria) this;
        }

        public Criteria andTANTOU_SEKIGreaterThanOrEqualTo(String value) {
            addCriterion("TANTOU_SEKI >=", value, "TANTOU_SEKI");
            return (Criteria) this;
        }

        public Criteria andTANTOU_SEKILessThan(String value) {
            addCriterion("TANTOU_SEKI <", value, "TANTOU_SEKI");
            return (Criteria) this;
        }

        public Criteria andTANTOU_SEKILessThanOrEqualTo(String value) {
            addCriterion("TANTOU_SEKI <=", value, "TANTOU_SEKI");
            return (Criteria) this;
        }

        public Criteria andTANTOU_SEKILike(String value) {
            addCriterion("TANTOU_SEKI like", value, "TANTOU_SEKI");
            return (Criteria) this;
        }

        public Criteria andTANTOU_SEKINotLike(String value) {
            addCriterion("TANTOU_SEKI not like", value, "TANTOU_SEKI");
            return (Criteria) this;
        }

        public Criteria andTANTOU_SEKIIn(List<String> values) {
            addCriterion("TANTOU_SEKI in", values, "TANTOU_SEKI");
            return (Criteria) this;
        }

        public Criteria andTANTOU_SEKINotIn(List<String> values) {
            addCriterion("TANTOU_SEKI not in", values, "TANTOU_SEKI");
            return (Criteria) this;
        }

        public Criteria andTANTOU_SEKIBetween(String value1, String value2) {
            addCriterion("TANTOU_SEKI between", value1, value2, "TANTOU_SEKI");
            return (Criteria) this;
        }

        public Criteria andTANTOU_SEKINotBetween(String value1, String value2) {
            addCriterion("TANTOU_SEKI not between", value1, value2, "TANTOU_SEKI");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDIsNull() {
            addCriterion("JITAI_CD is null");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDIsNotNull() {
            addCriterion("JITAI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDEqualTo(String value) {
            addCriterion("JITAI_CD =", value, "JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDNotEqualTo(String value) {
            addCriterion("JITAI_CD <>", value, "JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDGreaterThan(String value) {
            addCriterion("JITAI_CD >", value, "JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("JITAI_CD >=", value, "JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDLessThan(String value) {
            addCriterion("JITAI_CD <", value, "JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDLessThanOrEqualTo(String value) {
            addCriterion("JITAI_CD <=", value, "JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDLike(String value) {
            addCriterion("JITAI_CD like", value, "JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDNotLike(String value) {
            addCriterion("JITAI_CD not like", value, "JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDIn(List<String> values) {
            addCriterion("JITAI_CD in", values, "JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDNotIn(List<String> values) {
            addCriterion("JITAI_CD not in", values, "JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDBetween(String value1, String value2) {
            addCriterion("JITAI_CD between", value1, value2, "JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDNotBetween(String value1, String value2) {
            addCriterion("JITAI_CD not between", value1, value2, "JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSIsNull() {
            addCriterion("HASSEI_TS is null");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSIsNotNull() {
            addCriterion("HASSEI_TS is not null");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSEqualTo(String value) {
            addCriterion("HASSEI_TS =", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSNotEqualTo(String value) {
            addCriterion("HASSEI_TS <>", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSGreaterThan(String value) {
            addCriterion("HASSEI_TS >", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSGreaterThanOrEqualTo(String value) {
            addCriterion("HASSEI_TS >=", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSLessThan(String value) {
            addCriterion("HASSEI_TS <", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSLessThanOrEqualTo(String value) {
            addCriterion("HASSEI_TS <=", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSLike(String value) {
            addCriterion("HASSEI_TS like", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSNotLike(String value) {
            addCriterion("HASSEI_TS not like", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSIn(List<String> values) {
            addCriterion("HASSEI_TS in", values, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSNotIn(List<String> values) {
            addCriterion("HASSEI_TS not in", values, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSBetween(String value1, String value2) {
            addCriterion("HASSEI_TS between", value1, value2, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSNotBetween(String value1, String value2) {
            addCriterion("HASSEI_TS not between", value1, value2, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_CNTIsNull() {
            addCriterion("KEIHOU_CNT is null");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_CNTIsNotNull() {
            addCriterion("KEIHOU_CNT is not null");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_CNTEqualTo(String value) {
            addCriterion("KEIHOU_CNT =", value, "KEIHOU_CNT");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_CNTNotEqualTo(String value) {
            addCriterion("KEIHOU_CNT <>", value, "KEIHOU_CNT");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_CNTGreaterThan(String value) {
            addCriterion("KEIHOU_CNT >", value, "KEIHOU_CNT");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_CNTGreaterThanOrEqualTo(String value) {
            addCriterion("KEIHOU_CNT >=", value, "KEIHOU_CNT");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_CNTLessThan(String value) {
            addCriterion("KEIHOU_CNT <", value, "KEIHOU_CNT");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_CNTLessThanOrEqualTo(String value) {
            addCriterion("KEIHOU_CNT <=", value, "KEIHOU_CNT");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_CNTLike(String value) {
            addCriterion("KEIHOU_CNT like", value, "KEIHOU_CNT");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_CNTNotLike(String value) {
            addCriterion("KEIHOU_CNT not like", value, "KEIHOU_CNT");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_CNTIn(List<String> values) {
            addCriterion("KEIHOU_CNT in", values, "KEIHOU_CNT");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_CNTNotIn(List<String> values) {
            addCriterion("KEIHOU_CNT not in", values, "KEIHOU_CNT");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_CNTBetween(String value1, String value2) {
            addCriterion("KEIHOU_CNT between", value1, value2, "KEIHOU_CNT");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_CNTNotBetween(String value1, String value2) {
            addCriterion("KEIHOU_CNT not between", value1, value2, "KEIHOU_CNT");
            return (Criteria) this;
        }

        public Criteria andTS_1IsNull() {
            addCriterion("TS_1 is null");
            return (Criteria) this;
        }

        public Criteria andTS_1IsNotNull() {
            addCriterion("TS_1 is not null");
            return (Criteria) this;
        }

        public Criteria andTS_1EqualTo(String value) {
            addCriterion("TS_1 =", value, "TS_1");
            return (Criteria) this;
        }

        public Criteria andTS_1NotEqualTo(String value) {
            addCriterion("TS_1 <>", value, "TS_1");
            return (Criteria) this;
        }

        public Criteria andTS_1GreaterThan(String value) {
            addCriterion("TS_1 >", value, "TS_1");
            return (Criteria) this;
        }

        public Criteria andTS_1GreaterThanOrEqualTo(String value) {
            addCriterion("TS_1 >=", value, "TS_1");
            return (Criteria) this;
        }

        public Criteria andTS_1LessThan(String value) {
            addCriterion("TS_1 <", value, "TS_1");
            return (Criteria) this;
        }

        public Criteria andTS_1LessThanOrEqualTo(String value) {
            addCriterion("TS_1 <=", value, "TS_1");
            return (Criteria) this;
        }

        public Criteria andTS_1Like(String value) {
            addCriterion("TS_1 like", value, "TS_1");
            return (Criteria) this;
        }

        public Criteria andTS_1NotLike(String value) {
            addCriterion("TS_1 not like", value, "TS_1");
            return (Criteria) this;
        }

        public Criteria andTS_1In(List<String> values) {
            addCriterion("TS_1 in", values, "TS_1");
            return (Criteria) this;
        }

        public Criteria andTS_1NotIn(List<String> values) {
            addCriterion("TS_1 not in", values, "TS_1");
            return (Criteria) this;
        }

        public Criteria andTS_1Between(String value1, String value2) {
            addCriterion("TS_1 between", value1, value2, "TS_1");
            return (Criteria) this;
        }

        public Criteria andTS_1NotBetween(String value1, String value2) {
            addCriterion("TS_1 not between", value1, value2, "TS_1");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_1IsNull() {
            addCriterion("HASSEI_TS_1 is null");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_1IsNotNull() {
            addCriterion("HASSEI_TS_1 is not null");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_1EqualTo(String value) {
            addCriterion("HASSEI_TS_1 =", value, "HASSEI_TS_1");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_1NotEqualTo(String value) {
            addCriterion("HASSEI_TS_1 <>", value, "HASSEI_TS_1");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_1GreaterThan(String value) {
            addCriterion("HASSEI_TS_1 >", value, "HASSEI_TS_1");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_1GreaterThanOrEqualTo(String value) {
            addCriterion("HASSEI_TS_1 >=", value, "HASSEI_TS_1");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_1LessThan(String value) {
            addCriterion("HASSEI_TS_1 <", value, "HASSEI_TS_1");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_1LessThanOrEqualTo(String value) {
            addCriterion("HASSEI_TS_1 <=", value, "HASSEI_TS_1");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_1Like(String value) {
            addCriterion("HASSEI_TS_1 like", value, "HASSEI_TS_1");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_1NotLike(String value) {
            addCriterion("HASSEI_TS_1 not like", value, "HASSEI_TS_1");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_1In(List<String> values) {
            addCriterion("HASSEI_TS_1 in", values, "HASSEI_TS_1");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_1NotIn(List<String> values) {
            addCriterion("HASSEI_TS_1 not in", values, "HASSEI_TS_1");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_1Between(String value1, String value2) {
            addCriterion("HASSEI_TS_1 between", value1, value2, "HASSEI_TS_1");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_1NotBetween(String value1, String value2) {
            addCriterion("HASSEI_TS_1 not between", value1, value2, "HASSEI_TS_1");
            return (Criteria) this;
        }

        public Criteria andSYANAI_1_CDIsNull() {
            addCriterion("SYANAI_1_CD is null");
            return (Criteria) this;
        }

        public Criteria andSYANAI_1_CDIsNotNull() {
            addCriterion("SYANAI_1_CD is not null");
            return (Criteria) this;
        }

        public Criteria andSYANAI_1_CDEqualTo(String value) {
            addCriterion("SYANAI_1_CD =", value, "SYANAI_1_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_1_CDNotEqualTo(String value) {
            addCriterion("SYANAI_1_CD <>", value, "SYANAI_1_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_1_CDGreaterThan(String value) {
            addCriterion("SYANAI_1_CD >", value, "SYANAI_1_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_1_CDGreaterThanOrEqualTo(String value) {
            addCriterion("SYANAI_1_CD >=", value, "SYANAI_1_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_1_CDLessThan(String value) {
            addCriterion("SYANAI_1_CD <", value, "SYANAI_1_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_1_CDLessThanOrEqualTo(String value) {
            addCriterion("SYANAI_1_CD <=", value, "SYANAI_1_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_1_CDLike(String value) {
            addCriterion("SYANAI_1_CD like", value, "SYANAI_1_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_1_CDNotLike(String value) {
            addCriterion("SYANAI_1_CD not like", value, "SYANAI_1_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_1_CDIn(List<String> values) {
            addCriterion("SYANAI_1_CD in", values, "SYANAI_1_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_1_CDNotIn(List<String> values) {
            addCriterion("SYANAI_1_CD not in", values, "SYANAI_1_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_1_CDBetween(String value1, String value2) {
            addCriterion("SYANAI_1_CD between", value1, value2, "SYANAI_1_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_1_CDNotBetween(String value1, String value2) {
            addCriterion("SYANAI_1_CD not between", value1, value2, "SYANAI_1_CD");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_1IsNull() {
            addCriterion("KEIBI_SIG_1 is null");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_1IsNotNull() {
            addCriterion("KEIBI_SIG_1 is not null");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_1EqualTo(String value) {
            addCriterion("KEIBI_SIG_1 =", value, "KEIBI_SIG_1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_1NotEqualTo(String value) {
            addCriterion("KEIBI_SIG_1 <>", value, "KEIBI_SIG_1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_1GreaterThan(String value) {
            addCriterion("KEIBI_SIG_1 >", value, "KEIBI_SIG_1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_1GreaterThanOrEqualTo(String value) {
            addCriterion("KEIBI_SIG_1 >=", value, "KEIBI_SIG_1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_1LessThan(String value) {
            addCriterion("KEIBI_SIG_1 <", value, "KEIBI_SIG_1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_1LessThanOrEqualTo(String value) {
            addCriterion("KEIBI_SIG_1 <=", value, "KEIBI_SIG_1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_1Like(String value) {
            addCriterion("KEIBI_SIG_1 like", value, "KEIBI_SIG_1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_1NotLike(String value) {
            addCriterion("KEIBI_SIG_1 not like", value, "KEIBI_SIG_1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_1In(List<String> values) {
            addCriterion("KEIBI_SIG_1 in", values, "KEIBI_SIG_1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_1NotIn(List<String> values) {
            addCriterion("KEIBI_SIG_1 not in", values, "KEIBI_SIG_1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_1Between(String value1, String value2) {
            addCriterion("KEIBI_SIG_1 between", value1, value2, "KEIBI_SIG_1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_1NotBetween(String value1, String value2) {
            addCriterion("KEIBI_SIG_1 not between", value1, value2, "KEIBI_SIG_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1IsNull() {
            addCriterion("SIG_KIND_1 is null");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1IsNotNull() {
            addCriterion("SIG_KIND_1 is not null");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1EqualTo(String value) {
            addCriterion("SIG_KIND_1 =", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1NotEqualTo(String value) {
            addCriterion("SIG_KIND_1 <>", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1GreaterThan(String value) {
            addCriterion("SIG_KIND_1 >", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1GreaterThanOrEqualTo(String value) {
            addCriterion("SIG_KIND_1 >=", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1LessThan(String value) {
            addCriterion("SIG_KIND_1 <", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1LessThanOrEqualTo(String value) {
            addCriterion("SIG_KIND_1 <=", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1Like(String value) {
            addCriterion("SIG_KIND_1 like", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1NotLike(String value) {
            addCriterion("SIG_KIND_1 not like", value, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1In(List<String> values) {
            addCriterion("SIG_KIND_1 in", values, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1NotIn(List<String> values) {
            addCriterion("SIG_KIND_1 not in", values, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1Between(String value1, String value2) {
            addCriterion("SIG_KIND_1 between", value1, value2, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1NotBetween(String value1, String value2) {
            addCriterion("SIG_KIND_1 not between", value1, value2, "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_1IsNull() {
            addCriterion("KEIHOU_MARK_1 is null");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_1IsNotNull() {
            addCriterion("KEIHOU_MARK_1 is not null");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_1EqualTo(String value) {
            addCriterion("KEIHOU_MARK_1 =", value, "KEIHOU_MARK_1");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_1NotEqualTo(String value) {
            addCriterion("KEIHOU_MARK_1 <>", value, "KEIHOU_MARK_1");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_1GreaterThan(String value) {
            addCriterion("KEIHOU_MARK_1 >", value, "KEIHOU_MARK_1");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_1GreaterThanOrEqualTo(String value) {
            addCriterion("KEIHOU_MARK_1 >=", value, "KEIHOU_MARK_1");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_1LessThan(String value) {
            addCriterion("KEIHOU_MARK_1 <", value, "KEIHOU_MARK_1");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_1LessThanOrEqualTo(String value) {
            addCriterion("KEIHOU_MARK_1 <=", value, "KEIHOU_MARK_1");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_1Like(String value) {
            addCriterion("KEIHOU_MARK_1 like", value, "KEIHOU_MARK_1");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_1NotLike(String value) {
            addCriterion("KEIHOU_MARK_1 not like", value, "KEIHOU_MARK_1");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_1In(List<String> values) {
            addCriterion("KEIHOU_MARK_1 in", values, "KEIHOU_MARK_1");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_1NotIn(List<String> values) {
            addCriterion("KEIHOU_MARK_1 not in", values, "KEIHOU_MARK_1");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_1Between(String value1, String value2) {
            addCriterion("KEIHOU_MARK_1 between", value1, value2, "KEIHOU_MARK_1");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_1NotBetween(String value1, String value2) {
            addCriterion("KEIHOU_MARK_1 not between", value1, value2, "KEIHOU_MARK_1");
            return (Criteria) this;
        }

        public Criteria andTS_2IsNull() {
            addCriterion("TS_2 is null");
            return (Criteria) this;
        }

        public Criteria andTS_2IsNotNull() {
            addCriterion("TS_2 is not null");
            return (Criteria) this;
        }

        public Criteria andTS_2EqualTo(String value) {
            addCriterion("TS_2 =", value, "TS_2");
            return (Criteria) this;
        }

        public Criteria andTS_2NotEqualTo(String value) {
            addCriterion("TS_2 <>", value, "TS_2");
            return (Criteria) this;
        }

        public Criteria andTS_2GreaterThan(String value) {
            addCriterion("TS_2 >", value, "TS_2");
            return (Criteria) this;
        }

        public Criteria andTS_2GreaterThanOrEqualTo(String value) {
            addCriterion("TS_2 >=", value, "TS_2");
            return (Criteria) this;
        }

        public Criteria andTS_2LessThan(String value) {
            addCriterion("TS_2 <", value, "TS_2");
            return (Criteria) this;
        }

        public Criteria andTS_2LessThanOrEqualTo(String value) {
            addCriterion("TS_2 <=", value, "TS_2");
            return (Criteria) this;
        }

        public Criteria andTS_2Like(String value) {
            addCriterion("TS_2 like", value, "TS_2");
            return (Criteria) this;
        }

        public Criteria andTS_2NotLike(String value) {
            addCriterion("TS_2 not like", value, "TS_2");
            return (Criteria) this;
        }

        public Criteria andTS_2In(List<String> values) {
            addCriterion("TS_2 in", values, "TS_2");
            return (Criteria) this;
        }

        public Criteria andTS_2NotIn(List<String> values) {
            addCriterion("TS_2 not in", values, "TS_2");
            return (Criteria) this;
        }

        public Criteria andTS_2Between(String value1, String value2) {
            addCriterion("TS_2 between", value1, value2, "TS_2");
            return (Criteria) this;
        }

        public Criteria andTS_2NotBetween(String value1, String value2) {
            addCriterion("TS_2 not between", value1, value2, "TS_2");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_2IsNull() {
            addCriterion("HASSEI_TS_2 is null");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_2IsNotNull() {
            addCriterion("HASSEI_TS_2 is not null");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_2EqualTo(String value) {
            addCriterion("HASSEI_TS_2 =", value, "HASSEI_TS_2");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_2NotEqualTo(String value) {
            addCriterion("HASSEI_TS_2 <>", value, "HASSEI_TS_2");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_2GreaterThan(String value) {
            addCriterion("HASSEI_TS_2 >", value, "HASSEI_TS_2");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_2GreaterThanOrEqualTo(String value) {
            addCriterion("HASSEI_TS_2 >=", value, "HASSEI_TS_2");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_2LessThan(String value) {
            addCriterion("HASSEI_TS_2 <", value, "HASSEI_TS_2");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_2LessThanOrEqualTo(String value) {
            addCriterion("HASSEI_TS_2 <=", value, "HASSEI_TS_2");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_2Like(String value) {
            addCriterion("HASSEI_TS_2 like", value, "HASSEI_TS_2");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_2NotLike(String value) {
            addCriterion("HASSEI_TS_2 not like", value, "HASSEI_TS_2");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_2In(List<String> values) {
            addCriterion("HASSEI_TS_2 in", values, "HASSEI_TS_2");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_2NotIn(List<String> values) {
            addCriterion("HASSEI_TS_2 not in", values, "HASSEI_TS_2");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_2Between(String value1, String value2) {
            addCriterion("HASSEI_TS_2 between", value1, value2, "HASSEI_TS_2");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_2NotBetween(String value1, String value2) {
            addCriterion("HASSEI_TS_2 not between", value1, value2, "HASSEI_TS_2");
            return (Criteria) this;
        }

        public Criteria andSYANAI_2_CDIsNull() {
            addCriterion("SYANAI_2_CD is null");
            return (Criteria) this;
        }

        public Criteria andSYANAI_2_CDIsNotNull() {
            addCriterion("SYANAI_2_CD is not null");
            return (Criteria) this;
        }

        public Criteria andSYANAI_2_CDEqualTo(String value) {
            addCriterion("SYANAI_2_CD =", value, "SYANAI_2_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_2_CDNotEqualTo(String value) {
            addCriterion("SYANAI_2_CD <>", value, "SYANAI_2_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_2_CDGreaterThan(String value) {
            addCriterion("SYANAI_2_CD >", value, "SYANAI_2_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_2_CDGreaterThanOrEqualTo(String value) {
            addCriterion("SYANAI_2_CD >=", value, "SYANAI_2_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_2_CDLessThan(String value) {
            addCriterion("SYANAI_2_CD <", value, "SYANAI_2_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_2_CDLessThanOrEqualTo(String value) {
            addCriterion("SYANAI_2_CD <=", value, "SYANAI_2_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_2_CDLike(String value) {
            addCriterion("SYANAI_2_CD like", value, "SYANAI_2_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_2_CDNotLike(String value) {
            addCriterion("SYANAI_2_CD not like", value, "SYANAI_2_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_2_CDIn(List<String> values) {
            addCriterion("SYANAI_2_CD in", values, "SYANAI_2_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_2_CDNotIn(List<String> values) {
            addCriterion("SYANAI_2_CD not in", values, "SYANAI_2_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_2_CDBetween(String value1, String value2) {
            addCriterion("SYANAI_2_CD between", value1, value2, "SYANAI_2_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_2_CDNotBetween(String value1, String value2) {
            addCriterion("SYANAI_2_CD not between", value1, value2, "SYANAI_2_CD");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_2IsNull() {
            addCriterion("KEIBI_SIG_2 is null");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_2IsNotNull() {
            addCriterion("KEIBI_SIG_2 is not null");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_2EqualTo(String value) {
            addCriterion("KEIBI_SIG_2 =", value, "KEIBI_SIG_2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_2NotEqualTo(String value) {
            addCriterion("KEIBI_SIG_2 <>", value, "KEIBI_SIG_2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_2GreaterThan(String value) {
            addCriterion("KEIBI_SIG_2 >", value, "KEIBI_SIG_2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_2GreaterThanOrEqualTo(String value) {
            addCriterion("KEIBI_SIG_2 >=", value, "KEIBI_SIG_2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_2LessThan(String value) {
            addCriterion("KEIBI_SIG_2 <", value, "KEIBI_SIG_2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_2LessThanOrEqualTo(String value) {
            addCriterion("KEIBI_SIG_2 <=", value, "KEIBI_SIG_2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_2Like(String value) {
            addCriterion("KEIBI_SIG_2 like", value, "KEIBI_SIG_2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_2NotLike(String value) {
            addCriterion("KEIBI_SIG_2 not like", value, "KEIBI_SIG_2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_2In(List<String> values) {
            addCriterion("KEIBI_SIG_2 in", values, "KEIBI_SIG_2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_2NotIn(List<String> values) {
            addCriterion("KEIBI_SIG_2 not in", values, "KEIBI_SIG_2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_2Between(String value1, String value2) {
            addCriterion("KEIBI_SIG_2 between", value1, value2, "KEIBI_SIG_2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_2NotBetween(String value1, String value2) {
            addCriterion("KEIBI_SIG_2 not between", value1, value2, "KEIBI_SIG_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2IsNull() {
            addCriterion("SIG_KIND_2 is null");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2IsNotNull() {
            addCriterion("SIG_KIND_2 is not null");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2EqualTo(String value) {
            addCriterion("SIG_KIND_2 =", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2NotEqualTo(String value) {
            addCriterion("SIG_KIND_2 <>", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2GreaterThan(String value) {
            addCriterion("SIG_KIND_2 >", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2GreaterThanOrEqualTo(String value) {
            addCriterion("SIG_KIND_2 >=", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2LessThan(String value) {
            addCriterion("SIG_KIND_2 <", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2LessThanOrEqualTo(String value) {
            addCriterion("SIG_KIND_2 <=", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2Like(String value) {
            addCriterion("SIG_KIND_2 like", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2NotLike(String value) {
            addCriterion("SIG_KIND_2 not like", value, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2In(List<String> values) {
            addCriterion("SIG_KIND_2 in", values, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2NotIn(List<String> values) {
            addCriterion("SIG_KIND_2 not in", values, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2Between(String value1, String value2) {
            addCriterion("SIG_KIND_2 between", value1, value2, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2NotBetween(String value1, String value2) {
            addCriterion("SIG_KIND_2 not between", value1, value2, "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_2IsNull() {
            addCriterion("KEIHOU_MARK_2 is null");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_2IsNotNull() {
            addCriterion("KEIHOU_MARK_2 is not null");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_2EqualTo(String value) {
            addCriterion("KEIHOU_MARK_2 =", value, "KEIHOU_MARK_2");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_2NotEqualTo(String value) {
            addCriterion("KEIHOU_MARK_2 <>", value, "KEIHOU_MARK_2");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_2GreaterThan(String value) {
            addCriterion("KEIHOU_MARK_2 >", value, "KEIHOU_MARK_2");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_2GreaterThanOrEqualTo(String value) {
            addCriterion("KEIHOU_MARK_2 >=", value, "KEIHOU_MARK_2");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_2LessThan(String value) {
            addCriterion("KEIHOU_MARK_2 <", value, "KEIHOU_MARK_2");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_2LessThanOrEqualTo(String value) {
            addCriterion("KEIHOU_MARK_2 <=", value, "KEIHOU_MARK_2");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_2Like(String value) {
            addCriterion("KEIHOU_MARK_2 like", value, "KEIHOU_MARK_2");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_2NotLike(String value) {
            addCriterion("KEIHOU_MARK_2 not like", value, "KEIHOU_MARK_2");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_2In(List<String> values) {
            addCriterion("KEIHOU_MARK_2 in", values, "KEIHOU_MARK_2");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_2NotIn(List<String> values) {
            addCriterion("KEIHOU_MARK_2 not in", values, "KEIHOU_MARK_2");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_2Between(String value1, String value2) {
            addCriterion("KEIHOU_MARK_2 between", value1, value2, "KEIHOU_MARK_2");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_2NotBetween(String value1, String value2) {
            addCriterion("KEIHOU_MARK_2 not between", value1, value2, "KEIHOU_MARK_2");
            return (Criteria) this;
        }

        public Criteria andTS_3IsNull() {
            addCriterion("TS_3 is null");
            return (Criteria) this;
        }

        public Criteria andTS_3IsNotNull() {
            addCriterion("TS_3 is not null");
            return (Criteria) this;
        }

        public Criteria andTS_3EqualTo(String value) {
            addCriterion("TS_3 =", value, "TS_3");
            return (Criteria) this;
        }

        public Criteria andTS_3NotEqualTo(String value) {
            addCriterion("TS_3 <>", value, "TS_3");
            return (Criteria) this;
        }

        public Criteria andTS_3GreaterThan(String value) {
            addCriterion("TS_3 >", value, "TS_3");
            return (Criteria) this;
        }

        public Criteria andTS_3GreaterThanOrEqualTo(String value) {
            addCriterion("TS_3 >=", value, "TS_3");
            return (Criteria) this;
        }

        public Criteria andTS_3LessThan(String value) {
            addCriterion("TS_3 <", value, "TS_3");
            return (Criteria) this;
        }

        public Criteria andTS_3LessThanOrEqualTo(String value) {
            addCriterion("TS_3 <=", value, "TS_3");
            return (Criteria) this;
        }

        public Criteria andTS_3Like(String value) {
            addCriterion("TS_3 like", value, "TS_3");
            return (Criteria) this;
        }

        public Criteria andTS_3NotLike(String value) {
            addCriterion("TS_3 not like", value, "TS_3");
            return (Criteria) this;
        }

        public Criteria andTS_3In(List<String> values) {
            addCriterion("TS_3 in", values, "TS_3");
            return (Criteria) this;
        }

        public Criteria andTS_3NotIn(List<String> values) {
            addCriterion("TS_3 not in", values, "TS_3");
            return (Criteria) this;
        }

        public Criteria andTS_3Between(String value1, String value2) {
            addCriterion("TS_3 between", value1, value2, "TS_3");
            return (Criteria) this;
        }

        public Criteria andTS_3NotBetween(String value1, String value2) {
            addCriterion("TS_3 not between", value1, value2, "TS_3");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_3IsNull() {
            addCriterion("HASSEI_TS_3 is null");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_3IsNotNull() {
            addCriterion("HASSEI_TS_3 is not null");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_3EqualTo(String value) {
            addCriterion("HASSEI_TS_3 =", value, "HASSEI_TS_3");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_3NotEqualTo(String value) {
            addCriterion("HASSEI_TS_3 <>", value, "HASSEI_TS_3");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_3GreaterThan(String value) {
            addCriterion("HASSEI_TS_3 >", value, "HASSEI_TS_3");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_3GreaterThanOrEqualTo(String value) {
            addCriterion("HASSEI_TS_3 >=", value, "HASSEI_TS_3");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_3LessThan(String value) {
            addCriterion("HASSEI_TS_3 <", value, "HASSEI_TS_3");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_3LessThanOrEqualTo(String value) {
            addCriterion("HASSEI_TS_3 <=", value, "HASSEI_TS_3");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_3Like(String value) {
            addCriterion("HASSEI_TS_3 like", value, "HASSEI_TS_3");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_3NotLike(String value) {
            addCriterion("HASSEI_TS_3 not like", value, "HASSEI_TS_3");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_3In(List<String> values) {
            addCriterion("HASSEI_TS_3 in", values, "HASSEI_TS_3");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_3NotIn(List<String> values) {
            addCriterion("HASSEI_TS_3 not in", values, "HASSEI_TS_3");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_3Between(String value1, String value2) {
            addCriterion("HASSEI_TS_3 between", value1, value2, "HASSEI_TS_3");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_3NotBetween(String value1, String value2) {
            addCriterion("HASSEI_TS_3 not between", value1, value2, "HASSEI_TS_3");
            return (Criteria) this;
        }

        public Criteria andSYANAI_3_CDIsNull() {
            addCriterion("SYANAI_3_CD is null");
            return (Criteria) this;
        }

        public Criteria andSYANAI_3_CDIsNotNull() {
            addCriterion("SYANAI_3_CD is not null");
            return (Criteria) this;
        }

        public Criteria andSYANAI_3_CDEqualTo(String value) {
            addCriterion("SYANAI_3_CD =", value, "SYANAI_3_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_3_CDNotEqualTo(String value) {
            addCriterion("SYANAI_3_CD <>", value, "SYANAI_3_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_3_CDGreaterThan(String value) {
            addCriterion("SYANAI_3_CD >", value, "SYANAI_3_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_3_CDGreaterThanOrEqualTo(String value) {
            addCriterion("SYANAI_3_CD >=", value, "SYANAI_3_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_3_CDLessThan(String value) {
            addCriterion("SYANAI_3_CD <", value, "SYANAI_3_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_3_CDLessThanOrEqualTo(String value) {
            addCriterion("SYANAI_3_CD <=", value, "SYANAI_3_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_3_CDLike(String value) {
            addCriterion("SYANAI_3_CD like", value, "SYANAI_3_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_3_CDNotLike(String value) {
            addCriterion("SYANAI_3_CD not like", value, "SYANAI_3_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_3_CDIn(List<String> values) {
            addCriterion("SYANAI_3_CD in", values, "SYANAI_3_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_3_CDNotIn(List<String> values) {
            addCriterion("SYANAI_3_CD not in", values, "SYANAI_3_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_3_CDBetween(String value1, String value2) {
            addCriterion("SYANAI_3_CD between", value1, value2, "SYANAI_3_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_3_CDNotBetween(String value1, String value2) {
            addCriterion("SYANAI_3_CD not between", value1, value2, "SYANAI_3_CD");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_3IsNull() {
            addCriterion("KEIBI_SIG_3 is null");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_3IsNotNull() {
            addCriterion("KEIBI_SIG_3 is not null");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_3EqualTo(String value) {
            addCriterion("KEIBI_SIG_3 =", value, "KEIBI_SIG_3");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_3NotEqualTo(String value) {
            addCriterion("KEIBI_SIG_3 <>", value, "KEIBI_SIG_3");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_3GreaterThan(String value) {
            addCriterion("KEIBI_SIG_3 >", value, "KEIBI_SIG_3");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_3GreaterThanOrEqualTo(String value) {
            addCriterion("KEIBI_SIG_3 >=", value, "KEIBI_SIG_3");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_3LessThan(String value) {
            addCriterion("KEIBI_SIG_3 <", value, "KEIBI_SIG_3");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_3LessThanOrEqualTo(String value) {
            addCriterion("KEIBI_SIG_3 <=", value, "KEIBI_SIG_3");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_3Like(String value) {
            addCriterion("KEIBI_SIG_3 like", value, "KEIBI_SIG_3");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_3NotLike(String value) {
            addCriterion("KEIBI_SIG_3 not like", value, "KEIBI_SIG_3");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_3In(List<String> values) {
            addCriterion("KEIBI_SIG_3 in", values, "KEIBI_SIG_3");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_3NotIn(List<String> values) {
            addCriterion("KEIBI_SIG_3 not in", values, "KEIBI_SIG_3");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_3Between(String value1, String value2) {
            addCriterion("KEIBI_SIG_3 between", value1, value2, "KEIBI_SIG_3");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_3NotBetween(String value1, String value2) {
            addCriterion("KEIBI_SIG_3 not between", value1, value2, "KEIBI_SIG_3");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_3IsNull() {
            addCriterion("SIG_KIND_3 is null");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_3IsNotNull() {
            addCriterion("SIG_KIND_3 is not null");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_3EqualTo(String value) {
            addCriterion("SIG_KIND_3 =", value, "SIG_KIND_3");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_3NotEqualTo(String value) {
            addCriterion("SIG_KIND_3 <>", value, "SIG_KIND_3");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_3GreaterThan(String value) {
            addCriterion("SIG_KIND_3 >", value, "SIG_KIND_3");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_3GreaterThanOrEqualTo(String value) {
            addCriterion("SIG_KIND_3 >=", value, "SIG_KIND_3");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_3LessThan(String value) {
            addCriterion("SIG_KIND_3 <", value, "SIG_KIND_3");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_3LessThanOrEqualTo(String value) {
            addCriterion("SIG_KIND_3 <=", value, "SIG_KIND_3");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_3Like(String value) {
            addCriterion("SIG_KIND_3 like", value, "SIG_KIND_3");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_3NotLike(String value) {
            addCriterion("SIG_KIND_3 not like", value, "SIG_KIND_3");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_3In(List<String> values) {
            addCriterion("SIG_KIND_3 in", values, "SIG_KIND_3");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_3NotIn(List<String> values) {
            addCriterion("SIG_KIND_3 not in", values, "SIG_KIND_3");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_3Between(String value1, String value2) {
            addCriterion("SIG_KIND_3 between", value1, value2, "SIG_KIND_3");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_3NotBetween(String value1, String value2) {
            addCriterion("SIG_KIND_3 not between", value1, value2, "SIG_KIND_3");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_3IsNull() {
            addCriterion("KEIHOU_MARK_3 is null");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_3IsNotNull() {
            addCriterion("KEIHOU_MARK_3 is not null");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_3EqualTo(String value) {
            addCriterion("KEIHOU_MARK_3 =", value, "KEIHOU_MARK_3");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_3NotEqualTo(String value) {
            addCriterion("KEIHOU_MARK_3 <>", value, "KEIHOU_MARK_3");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_3GreaterThan(String value) {
            addCriterion("KEIHOU_MARK_3 >", value, "KEIHOU_MARK_3");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_3GreaterThanOrEqualTo(String value) {
            addCriterion("KEIHOU_MARK_3 >=", value, "KEIHOU_MARK_3");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_3LessThan(String value) {
            addCriterion("KEIHOU_MARK_3 <", value, "KEIHOU_MARK_3");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_3LessThanOrEqualTo(String value) {
            addCriterion("KEIHOU_MARK_3 <=", value, "KEIHOU_MARK_3");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_3Like(String value) {
            addCriterion("KEIHOU_MARK_3 like", value, "KEIHOU_MARK_3");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_3NotLike(String value) {
            addCriterion("KEIHOU_MARK_3 not like", value, "KEIHOU_MARK_3");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_3In(List<String> values) {
            addCriterion("KEIHOU_MARK_3 in", values, "KEIHOU_MARK_3");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_3NotIn(List<String> values) {
            addCriterion("KEIHOU_MARK_3 not in", values, "KEIHOU_MARK_3");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_3Between(String value1, String value2) {
            addCriterion("KEIHOU_MARK_3 between", value1, value2, "KEIHOU_MARK_3");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_3NotBetween(String value1, String value2) {
            addCriterion("KEIHOU_MARK_3 not between", value1, value2, "KEIHOU_MARK_3");
            return (Criteria) this;
        }

        public Criteria andTS_4IsNull() {
            addCriterion("TS_4 is null");
            return (Criteria) this;
        }

        public Criteria andTS_4IsNotNull() {
            addCriterion("TS_4 is not null");
            return (Criteria) this;
        }

        public Criteria andTS_4EqualTo(String value) {
            addCriterion("TS_4 =", value, "TS_4");
            return (Criteria) this;
        }

        public Criteria andTS_4NotEqualTo(String value) {
            addCriterion("TS_4 <>", value, "TS_4");
            return (Criteria) this;
        }

        public Criteria andTS_4GreaterThan(String value) {
            addCriterion("TS_4 >", value, "TS_4");
            return (Criteria) this;
        }

        public Criteria andTS_4GreaterThanOrEqualTo(String value) {
            addCriterion("TS_4 >=", value, "TS_4");
            return (Criteria) this;
        }

        public Criteria andTS_4LessThan(String value) {
            addCriterion("TS_4 <", value, "TS_4");
            return (Criteria) this;
        }

        public Criteria andTS_4LessThanOrEqualTo(String value) {
            addCriterion("TS_4 <=", value, "TS_4");
            return (Criteria) this;
        }

        public Criteria andTS_4Like(String value) {
            addCriterion("TS_4 like", value, "TS_4");
            return (Criteria) this;
        }

        public Criteria andTS_4NotLike(String value) {
            addCriterion("TS_4 not like", value, "TS_4");
            return (Criteria) this;
        }

        public Criteria andTS_4In(List<String> values) {
            addCriterion("TS_4 in", values, "TS_4");
            return (Criteria) this;
        }

        public Criteria andTS_4NotIn(List<String> values) {
            addCriterion("TS_4 not in", values, "TS_4");
            return (Criteria) this;
        }

        public Criteria andTS_4Between(String value1, String value2) {
            addCriterion("TS_4 between", value1, value2, "TS_4");
            return (Criteria) this;
        }

        public Criteria andTS_4NotBetween(String value1, String value2) {
            addCriterion("TS_4 not between", value1, value2, "TS_4");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_4IsNull() {
            addCriterion("HASSEI_TS_4 is null");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_4IsNotNull() {
            addCriterion("HASSEI_TS_4 is not null");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_4EqualTo(String value) {
            addCriterion("HASSEI_TS_4 =", value, "HASSEI_TS_4");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_4NotEqualTo(String value) {
            addCriterion("HASSEI_TS_4 <>", value, "HASSEI_TS_4");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_4GreaterThan(String value) {
            addCriterion("HASSEI_TS_4 >", value, "HASSEI_TS_4");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_4GreaterThanOrEqualTo(String value) {
            addCriterion("HASSEI_TS_4 >=", value, "HASSEI_TS_4");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_4LessThan(String value) {
            addCriterion("HASSEI_TS_4 <", value, "HASSEI_TS_4");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_4LessThanOrEqualTo(String value) {
            addCriterion("HASSEI_TS_4 <=", value, "HASSEI_TS_4");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_4Like(String value) {
            addCriterion("HASSEI_TS_4 like", value, "HASSEI_TS_4");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_4NotLike(String value) {
            addCriterion("HASSEI_TS_4 not like", value, "HASSEI_TS_4");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_4In(List<String> values) {
            addCriterion("HASSEI_TS_4 in", values, "HASSEI_TS_4");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_4NotIn(List<String> values) {
            addCriterion("HASSEI_TS_4 not in", values, "HASSEI_TS_4");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_4Between(String value1, String value2) {
            addCriterion("HASSEI_TS_4 between", value1, value2, "HASSEI_TS_4");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_4NotBetween(String value1, String value2) {
            addCriterion("HASSEI_TS_4 not between", value1, value2, "HASSEI_TS_4");
            return (Criteria) this;
        }

        public Criteria andSYANAI_4_CDIsNull() {
            addCriterion("SYANAI_4_CD is null");
            return (Criteria) this;
        }

        public Criteria andSYANAI_4_CDIsNotNull() {
            addCriterion("SYANAI_4_CD is not null");
            return (Criteria) this;
        }

        public Criteria andSYANAI_4_CDEqualTo(String value) {
            addCriterion("SYANAI_4_CD =", value, "SYANAI_4_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_4_CDNotEqualTo(String value) {
            addCriterion("SYANAI_4_CD <>", value, "SYANAI_4_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_4_CDGreaterThan(String value) {
            addCriterion("SYANAI_4_CD >", value, "SYANAI_4_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_4_CDGreaterThanOrEqualTo(String value) {
            addCriterion("SYANAI_4_CD >=", value, "SYANAI_4_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_4_CDLessThan(String value) {
            addCriterion("SYANAI_4_CD <", value, "SYANAI_4_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_4_CDLessThanOrEqualTo(String value) {
            addCriterion("SYANAI_4_CD <=", value, "SYANAI_4_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_4_CDLike(String value) {
            addCriterion("SYANAI_4_CD like", value, "SYANAI_4_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_4_CDNotLike(String value) {
            addCriterion("SYANAI_4_CD not like", value, "SYANAI_4_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_4_CDIn(List<String> values) {
            addCriterion("SYANAI_4_CD in", values, "SYANAI_4_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_4_CDNotIn(List<String> values) {
            addCriterion("SYANAI_4_CD not in", values, "SYANAI_4_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_4_CDBetween(String value1, String value2) {
            addCriterion("SYANAI_4_CD between", value1, value2, "SYANAI_4_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_4_CDNotBetween(String value1, String value2) {
            addCriterion("SYANAI_4_CD not between", value1, value2, "SYANAI_4_CD");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_4IsNull() {
            addCriterion("KEIBI_SIG_4 is null");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_4IsNotNull() {
            addCriterion("KEIBI_SIG_4 is not null");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_4EqualTo(String value) {
            addCriterion("KEIBI_SIG_4 =", value, "KEIBI_SIG_4");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_4NotEqualTo(String value) {
            addCriterion("KEIBI_SIG_4 <>", value, "KEIBI_SIG_4");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_4GreaterThan(String value) {
            addCriterion("KEIBI_SIG_4 >", value, "KEIBI_SIG_4");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_4GreaterThanOrEqualTo(String value) {
            addCriterion("KEIBI_SIG_4 >=", value, "KEIBI_SIG_4");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_4LessThan(String value) {
            addCriterion("KEIBI_SIG_4 <", value, "KEIBI_SIG_4");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_4LessThanOrEqualTo(String value) {
            addCriterion("KEIBI_SIG_4 <=", value, "KEIBI_SIG_4");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_4Like(String value) {
            addCriterion("KEIBI_SIG_4 like", value, "KEIBI_SIG_4");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_4NotLike(String value) {
            addCriterion("KEIBI_SIG_4 not like", value, "KEIBI_SIG_4");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_4In(List<String> values) {
            addCriterion("KEIBI_SIG_4 in", values, "KEIBI_SIG_4");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_4NotIn(List<String> values) {
            addCriterion("KEIBI_SIG_4 not in", values, "KEIBI_SIG_4");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_4Between(String value1, String value2) {
            addCriterion("KEIBI_SIG_4 between", value1, value2, "KEIBI_SIG_4");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_4NotBetween(String value1, String value2) {
            addCriterion("KEIBI_SIG_4 not between", value1, value2, "KEIBI_SIG_4");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_4IsNull() {
            addCriterion("SIG_KIND_4 is null");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_4IsNotNull() {
            addCriterion("SIG_KIND_4 is not null");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_4EqualTo(String value) {
            addCriterion("SIG_KIND_4 =", value, "SIG_KIND_4");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_4NotEqualTo(String value) {
            addCriterion("SIG_KIND_4 <>", value, "SIG_KIND_4");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_4GreaterThan(String value) {
            addCriterion("SIG_KIND_4 >", value, "SIG_KIND_4");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_4GreaterThanOrEqualTo(String value) {
            addCriterion("SIG_KIND_4 >=", value, "SIG_KIND_4");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_4LessThan(String value) {
            addCriterion("SIG_KIND_4 <", value, "SIG_KIND_4");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_4LessThanOrEqualTo(String value) {
            addCriterion("SIG_KIND_4 <=", value, "SIG_KIND_4");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_4Like(String value) {
            addCriterion("SIG_KIND_4 like", value, "SIG_KIND_4");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_4NotLike(String value) {
            addCriterion("SIG_KIND_4 not like", value, "SIG_KIND_4");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_4In(List<String> values) {
            addCriterion("SIG_KIND_4 in", values, "SIG_KIND_4");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_4NotIn(List<String> values) {
            addCriterion("SIG_KIND_4 not in", values, "SIG_KIND_4");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_4Between(String value1, String value2) {
            addCriterion("SIG_KIND_4 between", value1, value2, "SIG_KIND_4");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_4NotBetween(String value1, String value2) {
            addCriterion("SIG_KIND_4 not between", value1, value2, "SIG_KIND_4");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_4IsNull() {
            addCriterion("KEIHOU_MARK_4 is null");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_4IsNotNull() {
            addCriterion("KEIHOU_MARK_4 is not null");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_4EqualTo(String value) {
            addCriterion("KEIHOU_MARK_4 =", value, "KEIHOU_MARK_4");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_4NotEqualTo(String value) {
            addCriterion("KEIHOU_MARK_4 <>", value, "KEIHOU_MARK_4");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_4GreaterThan(String value) {
            addCriterion("KEIHOU_MARK_4 >", value, "KEIHOU_MARK_4");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_4GreaterThanOrEqualTo(String value) {
            addCriterion("KEIHOU_MARK_4 >=", value, "KEIHOU_MARK_4");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_4LessThan(String value) {
            addCriterion("KEIHOU_MARK_4 <", value, "KEIHOU_MARK_4");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_4LessThanOrEqualTo(String value) {
            addCriterion("KEIHOU_MARK_4 <=", value, "KEIHOU_MARK_4");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_4Like(String value) {
            addCriterion("KEIHOU_MARK_4 like", value, "KEIHOU_MARK_4");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_4NotLike(String value) {
            addCriterion("KEIHOU_MARK_4 not like", value, "KEIHOU_MARK_4");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_4In(List<String> values) {
            addCriterion("KEIHOU_MARK_4 in", values, "KEIHOU_MARK_4");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_4NotIn(List<String> values) {
            addCriterion("KEIHOU_MARK_4 not in", values, "KEIHOU_MARK_4");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_4Between(String value1, String value2) {
            addCriterion("KEIHOU_MARK_4 between", value1, value2, "KEIHOU_MARK_4");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_4NotBetween(String value1, String value2) {
            addCriterion("KEIHOU_MARK_4 not between", value1, value2, "KEIHOU_MARK_4");
            return (Criteria) this;
        }

        public Criteria andTS_5IsNull() {
            addCriterion("TS_5 is null");
            return (Criteria) this;
        }

        public Criteria andTS_5IsNotNull() {
            addCriterion("TS_5 is not null");
            return (Criteria) this;
        }

        public Criteria andTS_5EqualTo(String value) {
            addCriterion("TS_5 =", value, "TS_5");
            return (Criteria) this;
        }

        public Criteria andTS_5NotEqualTo(String value) {
            addCriterion("TS_5 <>", value, "TS_5");
            return (Criteria) this;
        }

        public Criteria andTS_5GreaterThan(String value) {
            addCriterion("TS_5 >", value, "TS_5");
            return (Criteria) this;
        }

        public Criteria andTS_5GreaterThanOrEqualTo(String value) {
            addCriterion("TS_5 >=", value, "TS_5");
            return (Criteria) this;
        }

        public Criteria andTS_5LessThan(String value) {
            addCriterion("TS_5 <", value, "TS_5");
            return (Criteria) this;
        }

        public Criteria andTS_5LessThanOrEqualTo(String value) {
            addCriterion("TS_5 <=", value, "TS_5");
            return (Criteria) this;
        }

        public Criteria andTS_5Like(String value) {
            addCriterion("TS_5 like", value, "TS_5");
            return (Criteria) this;
        }

        public Criteria andTS_5NotLike(String value) {
            addCriterion("TS_5 not like", value, "TS_5");
            return (Criteria) this;
        }

        public Criteria andTS_5In(List<String> values) {
            addCriterion("TS_5 in", values, "TS_5");
            return (Criteria) this;
        }

        public Criteria andTS_5NotIn(List<String> values) {
            addCriterion("TS_5 not in", values, "TS_5");
            return (Criteria) this;
        }

        public Criteria andTS_5Between(String value1, String value2) {
            addCriterion("TS_5 between", value1, value2, "TS_5");
            return (Criteria) this;
        }

        public Criteria andTS_5NotBetween(String value1, String value2) {
            addCriterion("TS_5 not between", value1, value2, "TS_5");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_5IsNull() {
            addCriterion("HASSEI_TS_5 is null");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_5IsNotNull() {
            addCriterion("HASSEI_TS_5 is not null");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_5EqualTo(String value) {
            addCriterion("HASSEI_TS_5 =", value, "HASSEI_TS_5");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_5NotEqualTo(String value) {
            addCriterion("HASSEI_TS_5 <>", value, "HASSEI_TS_5");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_5GreaterThan(String value) {
            addCriterion("HASSEI_TS_5 >", value, "HASSEI_TS_5");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_5GreaterThanOrEqualTo(String value) {
            addCriterion("HASSEI_TS_5 >=", value, "HASSEI_TS_5");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_5LessThan(String value) {
            addCriterion("HASSEI_TS_5 <", value, "HASSEI_TS_5");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_5LessThanOrEqualTo(String value) {
            addCriterion("HASSEI_TS_5 <=", value, "HASSEI_TS_5");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_5Like(String value) {
            addCriterion("HASSEI_TS_5 like", value, "HASSEI_TS_5");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_5NotLike(String value) {
            addCriterion("HASSEI_TS_5 not like", value, "HASSEI_TS_5");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_5In(List<String> values) {
            addCriterion("HASSEI_TS_5 in", values, "HASSEI_TS_5");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_5NotIn(List<String> values) {
            addCriterion("HASSEI_TS_5 not in", values, "HASSEI_TS_5");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_5Between(String value1, String value2) {
            addCriterion("HASSEI_TS_5 between", value1, value2, "HASSEI_TS_5");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_5NotBetween(String value1, String value2) {
            addCriterion("HASSEI_TS_5 not between", value1, value2, "HASSEI_TS_5");
            return (Criteria) this;
        }

        public Criteria andSYANAI_5_CDIsNull() {
            addCriterion("SYANAI_5_CD is null");
            return (Criteria) this;
        }

        public Criteria andSYANAI_5_CDIsNotNull() {
            addCriterion("SYANAI_5_CD is not null");
            return (Criteria) this;
        }

        public Criteria andSYANAI_5_CDEqualTo(String value) {
            addCriterion("SYANAI_5_CD =", value, "SYANAI_5_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_5_CDNotEqualTo(String value) {
            addCriterion("SYANAI_5_CD <>", value, "SYANAI_5_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_5_CDGreaterThan(String value) {
            addCriterion("SYANAI_5_CD >", value, "SYANAI_5_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_5_CDGreaterThanOrEqualTo(String value) {
            addCriterion("SYANAI_5_CD >=", value, "SYANAI_5_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_5_CDLessThan(String value) {
            addCriterion("SYANAI_5_CD <", value, "SYANAI_5_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_5_CDLessThanOrEqualTo(String value) {
            addCriterion("SYANAI_5_CD <=", value, "SYANAI_5_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_5_CDLike(String value) {
            addCriterion("SYANAI_5_CD like", value, "SYANAI_5_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_5_CDNotLike(String value) {
            addCriterion("SYANAI_5_CD not like", value, "SYANAI_5_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_5_CDIn(List<String> values) {
            addCriterion("SYANAI_5_CD in", values, "SYANAI_5_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_5_CDNotIn(List<String> values) {
            addCriterion("SYANAI_5_CD not in", values, "SYANAI_5_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_5_CDBetween(String value1, String value2) {
            addCriterion("SYANAI_5_CD between", value1, value2, "SYANAI_5_CD");
            return (Criteria) this;
        }

        public Criteria andSYANAI_5_CDNotBetween(String value1, String value2) {
            addCriterion("SYANAI_5_CD not between", value1, value2, "SYANAI_5_CD");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_5IsNull() {
            addCriterion("KEIBI_SIG_5 is null");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_5IsNotNull() {
            addCriterion("KEIBI_SIG_5 is not null");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_5EqualTo(String value) {
            addCriterion("KEIBI_SIG_5 =", value, "KEIBI_SIG_5");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_5NotEqualTo(String value) {
            addCriterion("KEIBI_SIG_5 <>", value, "KEIBI_SIG_5");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_5GreaterThan(String value) {
            addCriterion("KEIBI_SIG_5 >", value, "KEIBI_SIG_5");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_5GreaterThanOrEqualTo(String value) {
            addCriterion("KEIBI_SIG_5 >=", value, "KEIBI_SIG_5");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_5LessThan(String value) {
            addCriterion("KEIBI_SIG_5 <", value, "KEIBI_SIG_5");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_5LessThanOrEqualTo(String value) {
            addCriterion("KEIBI_SIG_5 <=", value, "KEIBI_SIG_5");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_5Like(String value) {
            addCriterion("KEIBI_SIG_5 like", value, "KEIBI_SIG_5");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_5NotLike(String value) {
            addCriterion("KEIBI_SIG_5 not like", value, "KEIBI_SIG_5");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_5In(List<String> values) {
            addCriterion("KEIBI_SIG_5 in", values, "KEIBI_SIG_5");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_5NotIn(List<String> values) {
            addCriterion("KEIBI_SIG_5 not in", values, "KEIBI_SIG_5");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_5Between(String value1, String value2) {
            addCriterion("KEIBI_SIG_5 between", value1, value2, "KEIBI_SIG_5");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_5NotBetween(String value1, String value2) {
            addCriterion("KEIBI_SIG_5 not between", value1, value2, "KEIBI_SIG_5");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_5IsNull() {
            addCriterion("SIG_KIND_5 is null");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_5IsNotNull() {
            addCriterion("SIG_KIND_5 is not null");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_5EqualTo(String value) {
            addCriterion("SIG_KIND_5 =", value, "SIG_KIND_5");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_5NotEqualTo(String value) {
            addCriterion("SIG_KIND_5 <>", value, "SIG_KIND_5");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_5GreaterThan(String value) {
            addCriterion("SIG_KIND_5 >", value, "SIG_KIND_5");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_5GreaterThanOrEqualTo(String value) {
            addCriterion("SIG_KIND_5 >=", value, "SIG_KIND_5");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_5LessThan(String value) {
            addCriterion("SIG_KIND_5 <", value, "SIG_KIND_5");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_5LessThanOrEqualTo(String value) {
            addCriterion("SIG_KIND_5 <=", value, "SIG_KIND_5");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_5Like(String value) {
            addCriterion("SIG_KIND_5 like", value, "SIG_KIND_5");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_5NotLike(String value) {
            addCriterion("SIG_KIND_5 not like", value, "SIG_KIND_5");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_5In(List<String> values) {
            addCriterion("SIG_KIND_5 in", values, "SIG_KIND_5");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_5NotIn(List<String> values) {
            addCriterion("SIG_KIND_5 not in", values, "SIG_KIND_5");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_5Between(String value1, String value2) {
            addCriterion("SIG_KIND_5 between", value1, value2, "SIG_KIND_5");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_5NotBetween(String value1, String value2) {
            addCriterion("SIG_KIND_5 not between", value1, value2, "SIG_KIND_5");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_5IsNull() {
            addCriterion("KEIHOU_MARK_5 is null");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_5IsNotNull() {
            addCriterion("KEIHOU_MARK_5 is not null");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_5EqualTo(String value) {
            addCriterion("KEIHOU_MARK_5 =", value, "KEIHOU_MARK_5");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_5NotEqualTo(String value) {
            addCriterion("KEIHOU_MARK_5 <>", value, "KEIHOU_MARK_5");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_5GreaterThan(String value) {
            addCriterion("KEIHOU_MARK_5 >", value, "KEIHOU_MARK_5");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_5GreaterThanOrEqualTo(String value) {
            addCriterion("KEIHOU_MARK_5 >=", value, "KEIHOU_MARK_5");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_5LessThan(String value) {
            addCriterion("KEIHOU_MARK_5 <", value, "KEIHOU_MARK_5");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_5LessThanOrEqualTo(String value) {
            addCriterion("KEIHOU_MARK_5 <=", value, "KEIHOU_MARK_5");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_5Like(String value) {
            addCriterion("KEIHOU_MARK_5 like", value, "KEIHOU_MARK_5");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_5NotLike(String value) {
            addCriterion("KEIHOU_MARK_5 not like", value, "KEIHOU_MARK_5");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_5In(List<String> values) {
            addCriterion("KEIHOU_MARK_5 in", values, "KEIHOU_MARK_5");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_5NotIn(List<String> values) {
            addCriterion("KEIHOU_MARK_5 not in", values, "KEIHOU_MARK_5");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_5Between(String value1, String value2) {
            addCriterion("KEIHOU_MARK_5 between", value1, value2, "KEIHOU_MARK_5");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_5NotBetween(String value1, String value2) {
            addCriterion("KEIHOU_MARK_5 not between", value1, value2, "KEIHOU_MARK_5");
            return (Criteria) this;
        }

        public Criteria andSIG_IDIsNull() {
            addCriterion("SIG_ID is null");
            return (Criteria) this;
        }

        public Criteria andSIG_IDIsNotNull() {
            addCriterion("SIG_ID is not null");
            return (Criteria) this;
        }

        public Criteria andSIG_IDEqualTo(String value) {
            addCriterion("SIG_ID =", value, "SIG_ID");
            return (Criteria) this;
        }

        public Criteria andSIG_IDNotEqualTo(String value) {
            addCriterion("SIG_ID <>", value, "SIG_ID");
            return (Criteria) this;
        }

        public Criteria andSIG_IDGreaterThan(String value) {
            addCriterion("SIG_ID >", value, "SIG_ID");
            return (Criteria) this;
        }

        public Criteria andSIG_IDGreaterThanOrEqualTo(String value) {
            addCriterion("SIG_ID >=", value, "SIG_ID");
            return (Criteria) this;
        }

        public Criteria andSIG_IDLessThan(String value) {
            addCriterion("SIG_ID <", value, "SIG_ID");
            return (Criteria) this;
        }

        public Criteria andSIG_IDLessThanOrEqualTo(String value) {
            addCriterion("SIG_ID <=", value, "SIG_ID");
            return (Criteria) this;
        }

        public Criteria andSIG_IDLike(String value) {
            addCriterion("SIG_ID like", value, "SIG_ID");
            return (Criteria) this;
        }

        public Criteria andSIG_IDNotLike(String value) {
            addCriterion("SIG_ID not like", value, "SIG_ID");
            return (Criteria) this;
        }

        public Criteria andSIG_IDIn(List<String> values) {
            addCriterion("SIG_ID in", values, "SIG_ID");
            return (Criteria) this;
        }

        public Criteria andSIG_IDNotIn(List<String> values) {
            addCriterion("SIG_ID not in", values, "SIG_ID");
            return (Criteria) this;
        }

        public Criteria andSIG_IDBetween(String value1, String value2) {
            addCriterion("SIG_ID between", value1, value2, "SIG_ID");
            return (Criteria) this;
        }

        public Criteria andSIG_IDNotBetween(String value1, String value2) {
            addCriterion("SIG_ID not between", value1, value2, "SIG_ID");
            return (Criteria) this;
        }

        public Criteria andDATA_IDIsNull() {
            addCriterion("DATA_ID is null");
            return (Criteria) this;
        }

        public Criteria andDATA_IDIsNotNull() {
            addCriterion("DATA_ID is not null");
            return (Criteria) this;
        }

        public Criteria andDATA_IDEqualTo(String value) {
            addCriterion("DATA_ID =", value, "DATA_ID");
            return (Criteria) this;
        }

        public Criteria andDATA_IDNotEqualTo(String value) {
            addCriterion("DATA_ID <>", value, "DATA_ID");
            return (Criteria) this;
        }

        public Criteria andDATA_IDGreaterThan(String value) {
            addCriterion("DATA_ID >", value, "DATA_ID");
            return (Criteria) this;
        }

        public Criteria andDATA_IDGreaterThanOrEqualTo(String value) {
            addCriterion("DATA_ID >=", value, "DATA_ID");
            return (Criteria) this;
        }

        public Criteria andDATA_IDLessThan(String value) {
            addCriterion("DATA_ID <", value, "DATA_ID");
            return (Criteria) this;
        }

        public Criteria andDATA_IDLessThanOrEqualTo(String value) {
            addCriterion("DATA_ID <=", value, "DATA_ID");
            return (Criteria) this;
        }

        public Criteria andDATA_IDLike(String value) {
            addCriterion("DATA_ID like", value, "DATA_ID");
            return (Criteria) this;
        }

        public Criteria andDATA_IDNotLike(String value) {
            addCriterion("DATA_ID not like", value, "DATA_ID");
            return (Criteria) this;
        }

        public Criteria andDATA_IDIn(List<String> values) {
            addCriterion("DATA_ID in", values, "DATA_ID");
            return (Criteria) this;
        }

        public Criteria andDATA_IDNotIn(List<String> values) {
            addCriterion("DATA_ID not in", values, "DATA_ID");
            return (Criteria) this;
        }

        public Criteria andDATA_IDBetween(String value1, String value2) {
            addCriterion("DATA_ID between", value1, value2, "DATA_ID");
            return (Criteria) this;
        }

        public Criteria andDATA_IDNotBetween(String value1, String value2) {
            addCriterion("DATA_ID not between", value1, value2, "DATA_ID");
            return (Criteria) this;
        }

        public Criteria andMULTI_SIG_INFIsNull() {
            addCriterion("MULTI_SIG_INF is null");
            return (Criteria) this;
        }

        public Criteria andMULTI_SIG_INFIsNotNull() {
            addCriterion("MULTI_SIG_INF is not null");
            return (Criteria) this;
        }

        public Criteria andMULTI_SIG_INFEqualTo(String value) {
            addCriterion("MULTI_SIG_INF =", value, "MULTI_SIG_INF");
            return (Criteria) this;
        }

        public Criteria andMULTI_SIG_INFNotEqualTo(String value) {
            addCriterion("MULTI_SIG_INF <>", value, "MULTI_SIG_INF");
            return (Criteria) this;
        }

        public Criteria andMULTI_SIG_INFGreaterThan(String value) {
            addCriterion("MULTI_SIG_INF >", value, "MULTI_SIG_INF");
            return (Criteria) this;
        }

        public Criteria andMULTI_SIG_INFGreaterThanOrEqualTo(String value) {
            addCriterion("MULTI_SIG_INF >=", value, "MULTI_SIG_INF");
            return (Criteria) this;
        }

        public Criteria andMULTI_SIG_INFLessThan(String value) {
            addCriterion("MULTI_SIG_INF <", value, "MULTI_SIG_INF");
            return (Criteria) this;
        }

        public Criteria andMULTI_SIG_INFLessThanOrEqualTo(String value) {
            addCriterion("MULTI_SIG_INF <=", value, "MULTI_SIG_INF");
            return (Criteria) this;
        }

        public Criteria andMULTI_SIG_INFLike(String value) {
            addCriterion("MULTI_SIG_INF like", value, "MULTI_SIG_INF");
            return (Criteria) this;
        }

        public Criteria andMULTI_SIG_INFNotLike(String value) {
            addCriterion("MULTI_SIG_INF not like", value, "MULTI_SIG_INF");
            return (Criteria) this;
        }

        public Criteria andMULTI_SIG_INFIn(List<String> values) {
            addCriterion("MULTI_SIG_INF in", values, "MULTI_SIG_INF");
            return (Criteria) this;
        }

        public Criteria andMULTI_SIG_INFNotIn(List<String> values) {
            addCriterion("MULTI_SIG_INF not in", values, "MULTI_SIG_INF");
            return (Criteria) this;
        }

        public Criteria andMULTI_SIG_INFBetween(String value1, String value2) {
            addCriterion("MULTI_SIG_INF between", value1, value2, "MULTI_SIG_INF");
            return (Criteria) this;
        }

        public Criteria andMULTI_SIG_INFNotBetween(String value1, String value2) {
            addCriterion("MULTI_SIG_INF not between", value1, value2, "MULTI_SIG_INF");
            return (Criteria) this;
        }

        public Criteria andNET_KEIBI_INFIsNull() {
            addCriterion("NET_KEIBI_INF is null");
            return (Criteria) this;
        }

        public Criteria andNET_KEIBI_INFIsNotNull() {
            addCriterion("NET_KEIBI_INF is not null");
            return (Criteria) this;
        }

        public Criteria andNET_KEIBI_INFEqualTo(String value) {
            addCriterion("NET_KEIBI_INF =", value, "NET_KEIBI_INF");
            return (Criteria) this;
        }

        public Criteria andNET_KEIBI_INFNotEqualTo(String value) {
            addCriterion("NET_KEIBI_INF <>", value, "NET_KEIBI_INF");
            return (Criteria) this;
        }

        public Criteria andNET_KEIBI_INFGreaterThan(String value) {
            addCriterion("NET_KEIBI_INF >", value, "NET_KEIBI_INF");
            return (Criteria) this;
        }

        public Criteria andNET_KEIBI_INFGreaterThanOrEqualTo(String value) {
            addCriterion("NET_KEIBI_INF >=", value, "NET_KEIBI_INF");
            return (Criteria) this;
        }

        public Criteria andNET_KEIBI_INFLessThan(String value) {
            addCriterion("NET_KEIBI_INF <", value, "NET_KEIBI_INF");
            return (Criteria) this;
        }

        public Criteria andNET_KEIBI_INFLessThanOrEqualTo(String value) {
            addCriterion("NET_KEIBI_INF <=", value, "NET_KEIBI_INF");
            return (Criteria) this;
        }

        public Criteria andNET_KEIBI_INFLike(String value) {
            addCriterion("NET_KEIBI_INF like", value, "NET_KEIBI_INF");
            return (Criteria) this;
        }

        public Criteria andNET_KEIBI_INFNotLike(String value) {
            addCriterion("NET_KEIBI_INF not like", value, "NET_KEIBI_INF");
            return (Criteria) this;
        }

        public Criteria andNET_KEIBI_INFIn(List<String> values) {
            addCriterion("NET_KEIBI_INF in", values, "NET_KEIBI_INF");
            return (Criteria) this;
        }

        public Criteria andNET_KEIBI_INFNotIn(List<String> values) {
            addCriterion("NET_KEIBI_INF not in", values, "NET_KEIBI_INF");
            return (Criteria) this;
        }

        public Criteria andNET_KEIBI_INFBetween(String value1, String value2) {
            addCriterion("NET_KEIBI_INF between", value1, value2, "NET_KEIBI_INF");
            return (Criteria) this;
        }

        public Criteria andNET_KEIBI_INFNotBetween(String value1, String value2) {
            addCriterion("NET_KEIBI_INF not between", value1, value2, "NET_KEIBI_INF");
            return (Criteria) this;
        }

        public Criteria andGAM_KUBUN_CDIsNull() {
            addCriterion("GAM_KUBUN_CD is null");
            return (Criteria) this;
        }

        public Criteria andGAM_KUBUN_CDIsNotNull() {
            addCriterion("GAM_KUBUN_CD is not null");
            return (Criteria) this;
        }

        public Criteria andGAM_KUBUN_CDEqualTo(String value) {
            addCriterion("GAM_KUBUN_CD =", value, "GAM_KUBUN_CD");
            return (Criteria) this;
        }

        public Criteria andGAM_KUBUN_CDNotEqualTo(String value) {
            addCriterion("GAM_KUBUN_CD <>", value, "GAM_KUBUN_CD");
            return (Criteria) this;
        }

        public Criteria andGAM_KUBUN_CDGreaterThan(String value) {
            addCriterion("GAM_KUBUN_CD >", value, "GAM_KUBUN_CD");
            return (Criteria) this;
        }

        public Criteria andGAM_KUBUN_CDGreaterThanOrEqualTo(String value) {
            addCriterion("GAM_KUBUN_CD >=", value, "GAM_KUBUN_CD");
            return (Criteria) this;
        }

        public Criteria andGAM_KUBUN_CDLessThan(String value) {
            addCriterion("GAM_KUBUN_CD <", value, "GAM_KUBUN_CD");
            return (Criteria) this;
        }

        public Criteria andGAM_KUBUN_CDLessThanOrEqualTo(String value) {
            addCriterion("GAM_KUBUN_CD <=", value, "GAM_KUBUN_CD");
            return (Criteria) this;
        }

        public Criteria andGAM_KUBUN_CDLike(String value) {
            addCriterion("GAM_KUBUN_CD like", value, "GAM_KUBUN_CD");
            return (Criteria) this;
        }

        public Criteria andGAM_KUBUN_CDNotLike(String value) {
            addCriterion("GAM_KUBUN_CD not like", value, "GAM_KUBUN_CD");
            return (Criteria) this;
        }

        public Criteria andGAM_KUBUN_CDIn(List<String> values) {
            addCriterion("GAM_KUBUN_CD in", values, "GAM_KUBUN_CD");
            return (Criteria) this;
        }

        public Criteria andGAM_KUBUN_CDNotIn(List<String> values) {
            addCriterion("GAM_KUBUN_CD not in", values, "GAM_KUBUN_CD");
            return (Criteria) this;
        }

        public Criteria andGAM_KUBUN_CDBetween(String value1, String value2) {
            addCriterion("GAM_KUBUN_CD between", value1, value2, "GAM_KUBUN_CD");
            return (Criteria) this;
        }

        public Criteria andGAM_KUBUN_CDNotBetween(String value1, String value2) {
            addCriterion("GAM_KUBUN_CD not between", value1, value2, "GAM_KUBUN_CD");
            return (Criteria) this;
        }

        public Criteria andKOKYAKU_CDIsNull() {
            addCriterion("KOKYAKU_CD is null");
            return (Criteria) this;
        }

        public Criteria andKOKYAKU_CDIsNotNull() {
            addCriterion("KOKYAKU_CD is not null");
            return (Criteria) this;
        }

        public Criteria andKOKYAKU_CDEqualTo(String value) {
            addCriterion("KOKYAKU_CD =", value, "KOKYAKU_CD");
            return (Criteria) this;
        }

        public Criteria andKOKYAKU_CDNotEqualTo(String value) {
            addCriterion("KOKYAKU_CD <>", value, "KOKYAKU_CD");
            return (Criteria) this;
        }

        public Criteria andKOKYAKU_CDGreaterThan(String value) {
            addCriterion("KOKYAKU_CD >", value, "KOKYAKU_CD");
            return (Criteria) this;
        }

        public Criteria andKOKYAKU_CDGreaterThanOrEqualTo(String value) {
            addCriterion("KOKYAKU_CD >=", value, "KOKYAKU_CD");
            return (Criteria) this;
        }

        public Criteria andKOKYAKU_CDLessThan(String value) {
            addCriterion("KOKYAKU_CD <", value, "KOKYAKU_CD");
            return (Criteria) this;
        }

        public Criteria andKOKYAKU_CDLessThanOrEqualTo(String value) {
            addCriterion("KOKYAKU_CD <=", value, "KOKYAKU_CD");
            return (Criteria) this;
        }

        public Criteria andKOKYAKU_CDLike(String value) {
            addCriterion("KOKYAKU_CD like", value, "KOKYAKU_CD");
            return (Criteria) this;
        }

        public Criteria andKOKYAKU_CDNotLike(String value) {
            addCriterion("KOKYAKU_CD not like", value, "KOKYAKU_CD");
            return (Criteria) this;
        }

        public Criteria andKOKYAKU_CDIn(List<String> values) {
            addCriterion("KOKYAKU_CD in", values, "KOKYAKU_CD");
            return (Criteria) this;
        }

        public Criteria andKOKYAKU_CDNotIn(List<String> values) {
            addCriterion("KOKYAKU_CD not in", values, "KOKYAKU_CD");
            return (Criteria) this;
        }

        public Criteria andKOKYAKU_CDBetween(String value1, String value2) {
            addCriterion("KOKYAKU_CD between", value1, value2, "KOKYAKU_CD");
            return (Criteria) this;
        }

        public Criteria andKOKYAKU_CDNotBetween(String value1, String value2) {
            addCriterion("KOKYAKU_CD not between", value1, value2, "KOKYAKU_CD");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDIsNull() {
            addCriterion("HOSOKU_CD is null");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDIsNotNull() {
            addCriterion("HOSOKU_CD is not null");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDEqualTo(String value) {
            addCriterion("HOSOKU_CD =", value, "HOSOKU_CD");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDNotEqualTo(String value) {
            addCriterion("HOSOKU_CD <>", value, "HOSOKU_CD");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDGreaterThan(String value) {
            addCriterion("HOSOKU_CD >", value, "HOSOKU_CD");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDGreaterThanOrEqualTo(String value) {
            addCriterion("HOSOKU_CD >=", value, "HOSOKU_CD");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDLessThan(String value) {
            addCriterion("HOSOKU_CD <", value, "HOSOKU_CD");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDLessThanOrEqualTo(String value) {
            addCriterion("HOSOKU_CD <=", value, "HOSOKU_CD");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDLike(String value) {
            addCriterion("HOSOKU_CD like", value, "HOSOKU_CD");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDNotLike(String value) {
            addCriterion("HOSOKU_CD not like", value, "HOSOKU_CD");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDIn(List<String> values) {
            addCriterion("HOSOKU_CD in", values, "HOSOKU_CD");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDNotIn(List<String> values) {
            addCriterion("HOSOKU_CD not in", values, "HOSOKU_CD");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDBetween(String value1, String value2) {
            addCriterion("HOSOKU_CD between", value1, value2, "HOSOKU_CD");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDNotBetween(String value1, String value2) {
            addCriterion("HOSOKU_CD not between", value1, value2, "HOSOKU_CD");
            return (Criteria) this;
        }

        public Criteria andHASSEI_CNTIsNull() {
            addCriterion("HASSEI_CNT is null");
            return (Criteria) this;
        }

        public Criteria andHASSEI_CNTIsNotNull() {
            addCriterion("HASSEI_CNT is not null");
            return (Criteria) this;
        }

        public Criteria andHASSEI_CNTEqualTo(String value) {
            addCriterion("HASSEI_CNT =", value, "HASSEI_CNT");
            return (Criteria) this;
        }

        public Criteria andHASSEI_CNTNotEqualTo(String value) {
            addCriterion("HASSEI_CNT <>", value, "HASSEI_CNT");
            return (Criteria) this;
        }

        public Criteria andHASSEI_CNTGreaterThan(String value) {
            addCriterion("HASSEI_CNT >", value, "HASSEI_CNT");
            return (Criteria) this;
        }

        public Criteria andHASSEI_CNTGreaterThanOrEqualTo(String value) {
            addCriterion("HASSEI_CNT >=", value, "HASSEI_CNT");
            return (Criteria) this;
        }

        public Criteria andHASSEI_CNTLessThan(String value) {
            addCriterion("HASSEI_CNT <", value, "HASSEI_CNT");
            return (Criteria) this;
        }

        public Criteria andHASSEI_CNTLessThanOrEqualTo(String value) {
            addCriterion("HASSEI_CNT <=", value, "HASSEI_CNT");
            return (Criteria) this;
        }

        public Criteria andHASSEI_CNTLike(String value) {
            addCriterion("HASSEI_CNT like", value, "HASSEI_CNT");
            return (Criteria) this;
        }

        public Criteria andHASSEI_CNTNotLike(String value) {
            addCriterion("HASSEI_CNT not like", value, "HASSEI_CNT");
            return (Criteria) this;
        }

        public Criteria andHASSEI_CNTIn(List<String> values) {
            addCriterion("HASSEI_CNT in", values, "HASSEI_CNT");
            return (Criteria) this;
        }

        public Criteria andHASSEI_CNTNotIn(List<String> values) {
            addCriterion("HASSEI_CNT not in", values, "HASSEI_CNT");
            return (Criteria) this;
        }

        public Criteria andHASSEI_CNTBetween(String value1, String value2) {
            addCriterion("HASSEI_CNT between", value1, value2, "HASSEI_CNT");
            return (Criteria) this;
        }

        public Criteria andHASSEI_CNTNotBetween(String value1, String value2) {
            addCriterion("HASSEI_CNT not between", value1, value2, "HASSEI_CNT");
            return (Criteria) this;
        }

        public Criteria andLAST_CNTIsNull() {
            addCriterion("LAST_CNT is null");
            return (Criteria) this;
        }

        public Criteria andLAST_CNTIsNotNull() {
            addCriterion("LAST_CNT is not null");
            return (Criteria) this;
        }

        public Criteria andLAST_CNTEqualTo(String value) {
            addCriterion("LAST_CNT =", value, "LAST_CNT");
            return (Criteria) this;
        }

        public Criteria andLAST_CNTNotEqualTo(String value) {
            addCriterion("LAST_CNT <>", value, "LAST_CNT");
            return (Criteria) this;
        }

        public Criteria andLAST_CNTGreaterThan(String value) {
            addCriterion("LAST_CNT >", value, "LAST_CNT");
            return (Criteria) this;
        }

        public Criteria andLAST_CNTGreaterThanOrEqualTo(String value) {
            addCriterion("LAST_CNT >=", value, "LAST_CNT");
            return (Criteria) this;
        }

        public Criteria andLAST_CNTLessThan(String value) {
            addCriterion("LAST_CNT <", value, "LAST_CNT");
            return (Criteria) this;
        }

        public Criteria andLAST_CNTLessThanOrEqualTo(String value) {
            addCriterion("LAST_CNT <=", value, "LAST_CNT");
            return (Criteria) this;
        }

        public Criteria andLAST_CNTLike(String value) {
            addCriterion("LAST_CNT like", value, "LAST_CNT");
            return (Criteria) this;
        }

        public Criteria andLAST_CNTNotLike(String value) {
            addCriterion("LAST_CNT not like", value, "LAST_CNT");
            return (Criteria) this;
        }

        public Criteria andLAST_CNTIn(List<String> values) {
            addCriterion("LAST_CNT in", values, "LAST_CNT");
            return (Criteria) this;
        }

        public Criteria andLAST_CNTNotIn(List<String> values) {
            addCriterion("LAST_CNT not in", values, "LAST_CNT");
            return (Criteria) this;
        }

        public Criteria andLAST_CNTBetween(String value1, String value2) {
            addCriterion("LAST_CNT between", value1, value2, "LAST_CNT");
            return (Criteria) this;
        }

        public Criteria andLAST_CNTNotBetween(String value1, String value2) {
            addCriterion("LAST_CNT not between", value1, value2, "LAST_CNT");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMIsNull() {
            addCriterion("SIJI_TM is null");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMIsNotNull() {
            addCriterion("SIJI_TM is not null");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMEqualTo(String value) {
            addCriterion("SIJI_TM =", value, "SIJI_TM");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMNotEqualTo(String value) {
            addCriterion("SIJI_TM <>", value, "SIJI_TM");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMGreaterThan(String value) {
            addCriterion("SIJI_TM >", value, "SIJI_TM");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMGreaterThanOrEqualTo(String value) {
            addCriterion("SIJI_TM >=", value, "SIJI_TM");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMLessThan(String value) {
            addCriterion("SIJI_TM <", value, "SIJI_TM");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMLessThanOrEqualTo(String value) {
            addCriterion("SIJI_TM <=", value, "SIJI_TM");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMLike(String value) {
            addCriterion("SIJI_TM like", value, "SIJI_TM");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMNotLike(String value) {
            addCriterion("SIJI_TM not like", value, "SIJI_TM");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMIn(List<String> values) {
            addCriterion("SIJI_TM in", values, "SIJI_TM");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMNotIn(List<String> values) {
            addCriterion("SIJI_TM not in", values, "SIJI_TM");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMBetween(String value1, String value2) {
            addCriterion("SIJI_TM between", value1, value2, "SIJI_TM");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMNotBetween(String value1, String value2) {
            addCriterion("SIJI_TM not between", value1, value2, "SIJI_TM");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMIsNull() {
            addCriterion("CHOKKOU_TM is null");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMIsNotNull() {
            addCriterion("CHOKKOU_TM is not null");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMEqualTo(String value) {
            addCriterion("CHOKKOU_TM =", value, "CHOKKOU_TM");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMNotEqualTo(String value) {
            addCriterion("CHOKKOU_TM <>", value, "CHOKKOU_TM");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMGreaterThan(String value) {
            addCriterion("CHOKKOU_TM >", value, "CHOKKOU_TM");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMGreaterThanOrEqualTo(String value) {
            addCriterion("CHOKKOU_TM >=", value, "CHOKKOU_TM");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMLessThan(String value) {
            addCriterion("CHOKKOU_TM <", value, "CHOKKOU_TM");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMLessThanOrEqualTo(String value) {
            addCriterion("CHOKKOU_TM <=", value, "CHOKKOU_TM");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMLike(String value) {
            addCriterion("CHOKKOU_TM like", value, "CHOKKOU_TM");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMNotLike(String value) {
            addCriterion("CHOKKOU_TM not like", value, "CHOKKOU_TM");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMIn(List<String> values) {
            addCriterion("CHOKKOU_TM in", values, "CHOKKOU_TM");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMNotIn(List<String> values) {
            addCriterion("CHOKKOU_TM not in", values, "CHOKKOU_TM");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMBetween(String value1, String value2) {
            addCriterion("CHOKKOU_TM between", value1, value2, "CHOKKOU_TM");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMNotBetween(String value1, String value2) {
            addCriterion("CHOKKOU_TM not between", value1, value2, "CHOKKOU_TM");
            return (Criteria) this;
        }

        public Criteria andSYOYOU_TMIsNull() {
            addCriterion("SYOYOU_TM is null");
            return (Criteria) this;
        }

        public Criteria andSYOYOU_TMIsNotNull() {
            addCriterion("SYOYOU_TM is not null");
            return (Criteria) this;
        }

        public Criteria andSYOYOU_TMEqualTo(String value) {
            addCriterion("SYOYOU_TM =", value, "SYOYOU_TM");
            return (Criteria) this;
        }

        public Criteria andSYOYOU_TMNotEqualTo(String value) {
            addCriterion("SYOYOU_TM <>", value, "SYOYOU_TM");
            return (Criteria) this;
        }

        public Criteria andSYOYOU_TMGreaterThan(String value) {
            addCriterion("SYOYOU_TM >", value, "SYOYOU_TM");
            return (Criteria) this;
        }

        public Criteria andSYOYOU_TMGreaterThanOrEqualTo(String value) {
            addCriterion("SYOYOU_TM >=", value, "SYOYOU_TM");
            return (Criteria) this;
        }

        public Criteria andSYOYOU_TMLessThan(String value) {
            addCriterion("SYOYOU_TM <", value, "SYOYOU_TM");
            return (Criteria) this;
        }

        public Criteria andSYOYOU_TMLessThanOrEqualTo(String value) {
            addCriterion("SYOYOU_TM <=", value, "SYOYOU_TM");
            return (Criteria) this;
        }

        public Criteria andSYOYOU_TMLike(String value) {
            addCriterion("SYOYOU_TM like", value, "SYOYOU_TM");
            return (Criteria) this;
        }

        public Criteria andSYOYOU_TMNotLike(String value) {
            addCriterion("SYOYOU_TM not like", value, "SYOYOU_TM");
            return (Criteria) this;
        }

        public Criteria andSYOYOU_TMIn(List<String> values) {
            addCriterion("SYOYOU_TM in", values, "SYOYOU_TM");
            return (Criteria) this;
        }

        public Criteria andSYOYOU_TMNotIn(List<String> values) {
            addCriterion("SYOYOU_TM not in", values, "SYOYOU_TM");
            return (Criteria) this;
        }

        public Criteria andSYOYOU_TMBetween(String value1, String value2) {
            addCriterion("SYOYOU_TM between", value1, value2, "SYOYOU_TM");
            return (Criteria) this;
        }

        public Criteria andSYOYOU_TMNotBetween(String value1, String value2) {
            addCriterion("SYOYOU_TM not between", value1, value2, "SYOYOU_TM");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMIsNull() {
            addCriterion("GENCHAKU_TM is null");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMIsNotNull() {
            addCriterion("GENCHAKU_TM is not null");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMEqualTo(String value) {
            addCriterion("GENCHAKU_TM =", value, "GENCHAKU_TM");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMNotEqualTo(String value) {
            addCriterion("GENCHAKU_TM <>", value, "GENCHAKU_TM");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMGreaterThan(String value) {
            addCriterion("GENCHAKU_TM >", value, "GENCHAKU_TM");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMGreaterThanOrEqualTo(String value) {
            addCriterion("GENCHAKU_TM >=", value, "GENCHAKU_TM");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMLessThan(String value) {
            addCriterion("GENCHAKU_TM <", value, "GENCHAKU_TM");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMLessThanOrEqualTo(String value) {
            addCriterion("GENCHAKU_TM <=", value, "GENCHAKU_TM");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMLike(String value) {
            addCriterion("GENCHAKU_TM like", value, "GENCHAKU_TM");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMNotLike(String value) {
            addCriterion("GENCHAKU_TM not like", value, "GENCHAKU_TM");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMIn(List<String> values) {
            addCriterion("GENCHAKU_TM in", values, "GENCHAKU_TM");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMNotIn(List<String> values) {
            addCriterion("GENCHAKU_TM not in", values, "GENCHAKU_TM");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMBetween(String value1, String value2) {
            addCriterion("GENCHAKU_TM between", value1, value2, "GENCHAKU_TM");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMNotBetween(String value1, String value2) {
            addCriterion("GENCHAKU_TM not between", value1, value2, "GENCHAKU_TM");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMIsNull() {
            addCriterion("NYUKAN_TM is null");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMIsNotNull() {
            addCriterion("NYUKAN_TM is not null");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMEqualTo(String value) {
            addCriterion("NYUKAN_TM =", value, "NYUKAN_TM");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMNotEqualTo(String value) {
            addCriterion("NYUKAN_TM <>", value, "NYUKAN_TM");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMGreaterThan(String value) {
            addCriterion("NYUKAN_TM >", value, "NYUKAN_TM");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMGreaterThanOrEqualTo(String value) {
            addCriterion("NYUKAN_TM >=", value, "NYUKAN_TM");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMLessThan(String value) {
            addCriterion("NYUKAN_TM <", value, "NYUKAN_TM");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMLessThanOrEqualTo(String value) {
            addCriterion("NYUKAN_TM <=", value, "NYUKAN_TM");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMLike(String value) {
            addCriterion("NYUKAN_TM like", value, "NYUKAN_TM");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMNotLike(String value) {
            addCriterion("NYUKAN_TM not like", value, "NYUKAN_TM");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMIn(List<String> values) {
            addCriterion("NYUKAN_TM in", values, "NYUKAN_TM");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMNotIn(List<String> values) {
            addCriterion("NYUKAN_TM not in", values, "NYUKAN_TM");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMBetween(String value1, String value2) {
            addCriterion("NYUKAN_TM between", value1, value2, "NYUKAN_TM");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMNotBetween(String value1, String value2) {
            addCriterion("NYUKAN_TM not between", value1, value2, "NYUKAN_TM");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMIsNull() {
            addCriterion("TAIKAN_TM is null");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMIsNotNull() {
            addCriterion("TAIKAN_TM is not null");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMEqualTo(String value) {
            addCriterion("TAIKAN_TM =", value, "TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMNotEqualTo(String value) {
            addCriterion("TAIKAN_TM <>", value, "TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMGreaterThan(String value) {
            addCriterion("TAIKAN_TM >", value, "TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMGreaterThanOrEqualTo(String value) {
            addCriterion("TAIKAN_TM >=", value, "TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMLessThan(String value) {
            addCriterion("TAIKAN_TM <", value, "TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMLessThanOrEqualTo(String value) {
            addCriterion("TAIKAN_TM <=", value, "TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMLike(String value) {
            addCriterion("TAIKAN_TM like", value, "TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMNotLike(String value) {
            addCriterion("TAIKAN_TM not like", value, "TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMIn(List<String> values) {
            addCriterion("TAIKAN_TM in", values, "TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMNotIn(List<String> values) {
            addCriterion("TAIKAN_TM not in", values, "TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMBetween(String value1, String value2) {
            addCriterion("TAIKAN_TM between", value1, value2, "TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMNotBetween(String value1, String value2) {
            addCriterion("TAIKAN_TM not between", value1, value2, "TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andEND_TMIsNull() {
            addCriterion("END_TM is null");
            return (Criteria) this;
        }

        public Criteria andEND_TMIsNotNull() {
            addCriterion("END_TM is not null");
            return (Criteria) this;
        }

        public Criteria andEND_TMEqualTo(String value) {
            addCriterion("END_TM =", value, "END_TM");
            return (Criteria) this;
        }

        public Criteria andEND_TMNotEqualTo(String value) {
            addCriterion("END_TM <>", value, "END_TM");
            return (Criteria) this;
        }

        public Criteria andEND_TMGreaterThan(String value) {
            addCriterion("END_TM >", value, "END_TM");
            return (Criteria) this;
        }

        public Criteria andEND_TMGreaterThanOrEqualTo(String value) {
            addCriterion("END_TM >=", value, "END_TM");
            return (Criteria) this;
        }

        public Criteria andEND_TMLessThan(String value) {
            addCriterion("END_TM <", value, "END_TM");
            return (Criteria) this;
        }

        public Criteria andEND_TMLessThanOrEqualTo(String value) {
            addCriterion("END_TM <=", value, "END_TM");
            return (Criteria) this;
        }

        public Criteria andEND_TMLike(String value) {
            addCriterion("END_TM like", value, "END_TM");
            return (Criteria) this;
        }

        public Criteria andEND_TMNotLike(String value) {
            addCriterion("END_TM not like", value, "END_TM");
            return (Criteria) this;
        }

        public Criteria andEND_TMIn(List<String> values) {
            addCriterion("END_TM in", values, "END_TM");
            return (Criteria) this;
        }

        public Criteria andEND_TMNotIn(List<String> values) {
            addCriterion("END_TM not in", values, "END_TM");
            return (Criteria) this;
        }

        public Criteria andEND_TMBetween(String value1, String value2) {
            addCriterion("END_TM between", value1, value2, "END_TM");
            return (Criteria) this;
        }

        public Criteria andEND_TMNotBetween(String value1, String value2) {
            addCriterion("END_TM not between", value1, value2, "END_TM");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSIsNull() {
            addCriterion("END_YOTEI_TS is null");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSIsNotNull() {
            addCriterion("END_YOTEI_TS is not null");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSEqualTo(String value) {
            addCriterion("END_YOTEI_TS =", value, "END_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSNotEqualTo(String value) {
            addCriterion("END_YOTEI_TS <>", value, "END_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSGreaterThan(String value) {
            addCriterion("END_YOTEI_TS >", value, "END_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSGreaterThanOrEqualTo(String value) {
            addCriterion("END_YOTEI_TS >=", value, "END_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSLessThan(String value) {
            addCriterion("END_YOTEI_TS <", value, "END_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSLessThanOrEqualTo(String value) {
            addCriterion("END_YOTEI_TS <=", value, "END_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSLike(String value) {
            addCriterion("END_YOTEI_TS like", value, "END_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSNotLike(String value) {
            addCriterion("END_YOTEI_TS not like", value, "END_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSIn(List<String> values) {
            addCriterion("END_YOTEI_TS in", values, "END_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSNotIn(List<String> values) {
            addCriterion("END_YOTEI_TS not in", values, "END_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSBetween(String value1, String value2) {
            addCriterion("END_YOTEI_TS between", value1, value2, "END_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSNotBetween(String value1, String value2) {
            addCriterion("END_YOTEI_TS not between", value1, value2, "END_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMIsNull() {
            addCriterion("POLICE_CALL_TM is null");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMIsNotNull() {
            addCriterion("POLICE_CALL_TM is not null");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMEqualTo(String value) {
            addCriterion("POLICE_CALL_TM =", value, "POLICE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMNotEqualTo(String value) {
            addCriterion("POLICE_CALL_TM <>", value, "POLICE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMGreaterThan(String value) {
            addCriterion("POLICE_CALL_TM >", value, "POLICE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMGreaterThanOrEqualTo(String value) {
            addCriterion("POLICE_CALL_TM >=", value, "POLICE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMLessThan(String value) {
            addCriterion("POLICE_CALL_TM <", value, "POLICE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMLessThanOrEqualTo(String value) {
            addCriterion("POLICE_CALL_TM <=", value, "POLICE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMLike(String value) {
            addCriterion("POLICE_CALL_TM like", value, "POLICE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMNotLike(String value) {
            addCriterion("POLICE_CALL_TM not like", value, "POLICE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMIn(List<String> values) {
            addCriterion("POLICE_CALL_TM in", values, "POLICE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMNotIn(List<String> values) {
            addCriterion("POLICE_CALL_TM not in", values, "POLICE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMBetween(String value1, String value2) {
            addCriterion("POLICE_CALL_TM between", value1, value2, "POLICE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMNotBetween(String value1, String value2) {
            addCriterion("POLICE_CALL_TM not between", value1, value2, "POLICE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMIsNull() {
            addCriterion("POLICE_ARRIV_TM is null");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMIsNotNull() {
            addCriterion("POLICE_ARRIV_TM is not null");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMEqualTo(String value) {
            addCriterion("POLICE_ARRIV_TM =", value, "POLICE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMNotEqualTo(String value) {
            addCriterion("POLICE_ARRIV_TM <>", value, "POLICE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMGreaterThan(String value) {
            addCriterion("POLICE_ARRIV_TM >", value, "POLICE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMGreaterThanOrEqualTo(String value) {
            addCriterion("POLICE_ARRIV_TM >=", value, "POLICE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMLessThan(String value) {
            addCriterion("POLICE_ARRIV_TM <", value, "POLICE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMLessThanOrEqualTo(String value) {
            addCriterion("POLICE_ARRIV_TM <=", value, "POLICE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMLike(String value) {
            addCriterion("POLICE_ARRIV_TM like", value, "POLICE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMNotLike(String value) {
            addCriterion("POLICE_ARRIV_TM not like", value, "POLICE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMIn(List<String> values) {
            addCriterion("POLICE_ARRIV_TM in", values, "POLICE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMNotIn(List<String> values) {
            addCriterion("POLICE_ARRIV_TM not in", values, "POLICE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMBetween(String value1, String value2) {
            addCriterion("POLICE_ARRIV_TM between", value1, value2, "POLICE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMNotBetween(String value1, String value2) {
            addCriterion("POLICE_ARRIV_TM not between", value1, value2, "POLICE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMIsNull() {
            addCriterion("FIRE_CALL_TM is null");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMIsNotNull() {
            addCriterion("FIRE_CALL_TM is not null");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMEqualTo(String value) {
            addCriterion("FIRE_CALL_TM =", value, "FIRE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMNotEqualTo(String value) {
            addCriterion("FIRE_CALL_TM <>", value, "FIRE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMGreaterThan(String value) {
            addCriterion("FIRE_CALL_TM >", value, "FIRE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMGreaterThanOrEqualTo(String value) {
            addCriterion("FIRE_CALL_TM >=", value, "FIRE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMLessThan(String value) {
            addCriterion("FIRE_CALL_TM <", value, "FIRE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMLessThanOrEqualTo(String value) {
            addCriterion("FIRE_CALL_TM <=", value, "FIRE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMLike(String value) {
            addCriterion("FIRE_CALL_TM like", value, "FIRE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMNotLike(String value) {
            addCriterion("FIRE_CALL_TM not like", value, "FIRE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMIn(List<String> values) {
            addCriterion("FIRE_CALL_TM in", values, "FIRE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMNotIn(List<String> values) {
            addCriterion("FIRE_CALL_TM not in", values, "FIRE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMBetween(String value1, String value2) {
            addCriterion("FIRE_CALL_TM between", value1, value2, "FIRE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMNotBetween(String value1, String value2) {
            addCriterion("FIRE_CALL_TM not between", value1, value2, "FIRE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMIsNull() {
            addCriterion("FIRE_ARRIV_TM is null");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMIsNotNull() {
            addCriterion("FIRE_ARRIV_TM is not null");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMEqualTo(String value) {
            addCriterion("FIRE_ARRIV_TM =", value, "FIRE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMNotEqualTo(String value) {
            addCriterion("FIRE_ARRIV_TM <>", value, "FIRE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMGreaterThan(String value) {
            addCriterion("FIRE_ARRIV_TM >", value, "FIRE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMGreaterThanOrEqualTo(String value) {
            addCriterion("FIRE_ARRIV_TM >=", value, "FIRE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMLessThan(String value) {
            addCriterion("FIRE_ARRIV_TM <", value, "FIRE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMLessThanOrEqualTo(String value) {
            addCriterion("FIRE_ARRIV_TM <=", value, "FIRE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMLike(String value) {
            addCriterion("FIRE_ARRIV_TM like", value, "FIRE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMNotLike(String value) {
            addCriterion("FIRE_ARRIV_TM not like", value, "FIRE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMIn(List<String> values) {
            addCriterion("FIRE_ARRIV_TM in", values, "FIRE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMNotIn(List<String> values) {
            addCriterion("FIRE_ARRIV_TM not in", values, "FIRE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMBetween(String value1, String value2) {
            addCriterion("FIRE_ARRIV_TM between", value1, value2, "FIRE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMNotBetween(String value1, String value2) {
            addCriterion("FIRE_ARRIV_TM not between", value1, value2, "FIRE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDIsNull() {
            addCriterion("POLICE_REASON_CD is null");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDIsNotNull() {
            addCriterion("POLICE_REASON_CD is not null");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDEqualTo(String value) {
            addCriterion("POLICE_REASON_CD =", value, "POLICE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDNotEqualTo(String value) {
            addCriterion("POLICE_REASON_CD <>", value, "POLICE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDGreaterThan(String value) {
            addCriterion("POLICE_REASON_CD >", value, "POLICE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDGreaterThanOrEqualTo(String value) {
            addCriterion("POLICE_REASON_CD >=", value, "POLICE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDLessThan(String value) {
            addCriterion("POLICE_REASON_CD <", value, "POLICE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDLessThanOrEqualTo(String value) {
            addCriterion("POLICE_REASON_CD <=", value, "POLICE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDLike(String value) {
            addCriterion("POLICE_REASON_CD like", value, "POLICE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDNotLike(String value) {
            addCriterion("POLICE_REASON_CD not like", value, "POLICE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDIn(List<String> values) {
            addCriterion("POLICE_REASON_CD in", values, "POLICE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDNotIn(List<String> values) {
            addCriterion("POLICE_REASON_CD not in", values, "POLICE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDBetween(String value1, String value2) {
            addCriterion("POLICE_REASON_CD between", value1, value2, "POLICE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDNotBetween(String value1, String value2) {
            addCriterion("POLICE_REASON_CD not between", value1, value2, "POLICE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONIsNull() {
            addCriterion("POLICE_CALL_REASON is null");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONIsNotNull() {
            addCriterion("POLICE_CALL_REASON is not null");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONEqualTo(String value) {
            addCriterion("POLICE_CALL_REASON =", value, "POLICE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONNotEqualTo(String value) {
            addCriterion("POLICE_CALL_REASON <>", value, "POLICE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONGreaterThan(String value) {
            addCriterion("POLICE_CALL_REASON >", value, "POLICE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONGreaterThanOrEqualTo(String value) {
            addCriterion("POLICE_CALL_REASON >=", value, "POLICE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONLessThan(String value) {
            addCriterion("POLICE_CALL_REASON <", value, "POLICE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONLessThanOrEqualTo(String value) {
            addCriterion("POLICE_CALL_REASON <=", value, "POLICE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONLike(String value) {
            addCriterion("POLICE_CALL_REASON like", value, "POLICE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONNotLike(String value) {
            addCriterion("POLICE_CALL_REASON not like", value, "POLICE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONIn(List<String> values) {
            addCriterion("POLICE_CALL_REASON in", values, "POLICE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONNotIn(List<String> values) {
            addCriterion("POLICE_CALL_REASON not in", values, "POLICE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONBetween(String value1, String value2) {
            addCriterion("POLICE_CALL_REASON between", value1, value2, "POLICE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONNotBetween(String value1, String value2) {
            addCriterion("POLICE_CALL_REASON not between", value1, value2, "POLICE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNIsNull() {
            addCriterion("POLICE_CALL_KBN is null");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNIsNotNull() {
            addCriterion("POLICE_CALL_KBN is not null");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNEqualTo(String value) {
            addCriterion("POLICE_CALL_KBN =", value, "POLICE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNNotEqualTo(String value) {
            addCriterion("POLICE_CALL_KBN <>", value, "POLICE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNGreaterThan(String value) {
            addCriterion("POLICE_CALL_KBN >", value, "POLICE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNGreaterThanOrEqualTo(String value) {
            addCriterion("POLICE_CALL_KBN >=", value, "POLICE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNLessThan(String value) {
            addCriterion("POLICE_CALL_KBN <", value, "POLICE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNLessThanOrEqualTo(String value) {
            addCriterion("POLICE_CALL_KBN <=", value, "POLICE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNLike(String value) {
            addCriterion("POLICE_CALL_KBN like", value, "POLICE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNNotLike(String value) {
            addCriterion("POLICE_CALL_KBN not like", value, "POLICE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNIn(List<String> values) {
            addCriterion("POLICE_CALL_KBN in", values, "POLICE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNNotIn(List<String> values) {
            addCriterion("POLICE_CALL_KBN not in", values, "POLICE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNBetween(String value1, String value2) {
            addCriterion("POLICE_CALL_KBN between", value1, value2, "POLICE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNNotBetween(String value1, String value2) {
            addCriterion("POLICE_CALL_KBN not between", value1, value2, "POLICE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPOIsNull() {
            addCriterion("POLICE_SINPO is null");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPOIsNotNull() {
            addCriterion("POLICE_SINPO is not null");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPOEqualTo(String value) {
            addCriterion("POLICE_SINPO =", value, "POLICE_SINPO");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPONotEqualTo(String value) {
            addCriterion("POLICE_SINPO <>", value, "POLICE_SINPO");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPOGreaterThan(String value) {
            addCriterion("POLICE_SINPO >", value, "POLICE_SINPO");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPOGreaterThanOrEqualTo(String value) {
            addCriterion("POLICE_SINPO >=", value, "POLICE_SINPO");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPOLessThan(String value) {
            addCriterion("POLICE_SINPO <", value, "POLICE_SINPO");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPOLessThanOrEqualTo(String value) {
            addCriterion("POLICE_SINPO <=", value, "POLICE_SINPO");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPOLike(String value) {
            addCriterion("POLICE_SINPO like", value, "POLICE_SINPO");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPONotLike(String value) {
            addCriterion("POLICE_SINPO not like", value, "POLICE_SINPO");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPOIn(List<String> values) {
            addCriterion("POLICE_SINPO in", values, "POLICE_SINPO");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPONotIn(List<String> values) {
            addCriterion("POLICE_SINPO not in", values, "POLICE_SINPO");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPOBetween(String value1, String value2) {
            addCriterion("POLICE_SINPO between", value1, value2, "POLICE_SINPO");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPONotBetween(String value1, String value2) {
            addCriterion("POLICE_SINPO not between", value1, value2, "POLICE_SINPO");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMIsNull() {
            addCriterion("POLICE_TAIKAN_TM is null");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMIsNotNull() {
            addCriterion("POLICE_TAIKAN_TM is not null");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMEqualTo(String value) {
            addCriterion("POLICE_TAIKAN_TM =", value, "POLICE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMNotEqualTo(String value) {
            addCriterion("POLICE_TAIKAN_TM <>", value, "POLICE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMGreaterThan(String value) {
            addCriterion("POLICE_TAIKAN_TM >", value, "POLICE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMGreaterThanOrEqualTo(String value) {
            addCriterion("POLICE_TAIKAN_TM >=", value, "POLICE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMLessThan(String value) {
            addCriterion("POLICE_TAIKAN_TM <", value, "POLICE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMLessThanOrEqualTo(String value) {
            addCriterion("POLICE_TAIKAN_TM <=", value, "POLICE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMLike(String value) {
            addCriterion("POLICE_TAIKAN_TM like", value, "POLICE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMNotLike(String value) {
            addCriterion("POLICE_TAIKAN_TM not like", value, "POLICE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMIn(List<String> values) {
            addCriterion("POLICE_TAIKAN_TM in", values, "POLICE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMNotIn(List<String> values) {
            addCriterion("POLICE_TAIKAN_TM not in", values, "POLICE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMBetween(String value1, String value2) {
            addCriterion("POLICE_TAIKAN_TM between", value1, value2, "POLICE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMNotBetween(String value1, String value2) {
            addCriterion("POLICE_TAIKAN_TM not between", value1, value2, "POLICE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDIsNull() {
            addCriterion("FIRE_REASON_CD is null");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDIsNotNull() {
            addCriterion("FIRE_REASON_CD is not null");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDEqualTo(String value) {
            addCriterion("FIRE_REASON_CD =", value, "FIRE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDNotEqualTo(String value) {
            addCriterion("FIRE_REASON_CD <>", value, "FIRE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDGreaterThan(String value) {
            addCriterion("FIRE_REASON_CD >", value, "FIRE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDGreaterThanOrEqualTo(String value) {
            addCriterion("FIRE_REASON_CD >=", value, "FIRE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDLessThan(String value) {
            addCriterion("FIRE_REASON_CD <", value, "FIRE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDLessThanOrEqualTo(String value) {
            addCriterion("FIRE_REASON_CD <=", value, "FIRE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDLike(String value) {
            addCriterion("FIRE_REASON_CD like", value, "FIRE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDNotLike(String value) {
            addCriterion("FIRE_REASON_CD not like", value, "FIRE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDIn(List<String> values) {
            addCriterion("FIRE_REASON_CD in", values, "FIRE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDNotIn(List<String> values) {
            addCriterion("FIRE_REASON_CD not in", values, "FIRE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDBetween(String value1, String value2) {
            addCriterion("FIRE_REASON_CD between", value1, value2, "FIRE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDNotBetween(String value1, String value2) {
            addCriterion("FIRE_REASON_CD not between", value1, value2, "FIRE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONIsNull() {
            addCriterion("FIRE_CALL_REASON is null");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONIsNotNull() {
            addCriterion("FIRE_CALL_REASON is not null");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONEqualTo(String value) {
            addCriterion("FIRE_CALL_REASON =", value, "FIRE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONNotEqualTo(String value) {
            addCriterion("FIRE_CALL_REASON <>", value, "FIRE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONGreaterThan(String value) {
            addCriterion("FIRE_CALL_REASON >", value, "FIRE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONGreaterThanOrEqualTo(String value) {
            addCriterion("FIRE_CALL_REASON >=", value, "FIRE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONLessThan(String value) {
            addCriterion("FIRE_CALL_REASON <", value, "FIRE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONLessThanOrEqualTo(String value) {
            addCriterion("FIRE_CALL_REASON <=", value, "FIRE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONLike(String value) {
            addCriterion("FIRE_CALL_REASON like", value, "FIRE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONNotLike(String value) {
            addCriterion("FIRE_CALL_REASON not like", value, "FIRE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONIn(List<String> values) {
            addCriterion("FIRE_CALL_REASON in", values, "FIRE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONNotIn(List<String> values) {
            addCriterion("FIRE_CALL_REASON not in", values, "FIRE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONBetween(String value1, String value2) {
            addCriterion("FIRE_CALL_REASON between", value1, value2, "FIRE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONNotBetween(String value1, String value2) {
            addCriterion("FIRE_CALL_REASON not between", value1, value2, "FIRE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNIsNull() {
            addCriterion("FIRE_CALL_KBN is null");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNIsNotNull() {
            addCriterion("FIRE_CALL_KBN is not null");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNEqualTo(String value) {
            addCriterion("FIRE_CALL_KBN =", value, "FIRE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNNotEqualTo(String value) {
            addCriterion("FIRE_CALL_KBN <>", value, "FIRE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNGreaterThan(String value) {
            addCriterion("FIRE_CALL_KBN >", value, "FIRE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNGreaterThanOrEqualTo(String value) {
            addCriterion("FIRE_CALL_KBN >=", value, "FIRE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNLessThan(String value) {
            addCriterion("FIRE_CALL_KBN <", value, "FIRE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNLessThanOrEqualTo(String value) {
            addCriterion("FIRE_CALL_KBN <=", value, "FIRE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNLike(String value) {
            addCriterion("FIRE_CALL_KBN like", value, "FIRE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNNotLike(String value) {
            addCriterion("FIRE_CALL_KBN not like", value, "FIRE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNIn(List<String> values) {
            addCriterion("FIRE_CALL_KBN in", values, "FIRE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNNotIn(List<String> values) {
            addCriterion("FIRE_CALL_KBN not in", values, "FIRE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNBetween(String value1, String value2) {
            addCriterion("FIRE_CALL_KBN between", value1, value2, "FIRE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNNotBetween(String value1, String value2) {
            addCriterion("FIRE_CALL_KBN not between", value1, value2, "FIRE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPOIsNull() {
            addCriterion("FIRE_SINPO is null");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPOIsNotNull() {
            addCriterion("FIRE_SINPO is not null");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPOEqualTo(String value) {
            addCriterion("FIRE_SINPO =", value, "FIRE_SINPO");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPONotEqualTo(String value) {
            addCriterion("FIRE_SINPO <>", value, "FIRE_SINPO");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPOGreaterThan(String value) {
            addCriterion("FIRE_SINPO >", value, "FIRE_SINPO");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPOGreaterThanOrEqualTo(String value) {
            addCriterion("FIRE_SINPO >=", value, "FIRE_SINPO");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPOLessThan(String value) {
            addCriterion("FIRE_SINPO <", value, "FIRE_SINPO");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPOLessThanOrEqualTo(String value) {
            addCriterion("FIRE_SINPO <=", value, "FIRE_SINPO");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPOLike(String value) {
            addCriterion("FIRE_SINPO like", value, "FIRE_SINPO");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPONotLike(String value) {
            addCriterion("FIRE_SINPO not like", value, "FIRE_SINPO");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPOIn(List<String> values) {
            addCriterion("FIRE_SINPO in", values, "FIRE_SINPO");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPONotIn(List<String> values) {
            addCriterion("FIRE_SINPO not in", values, "FIRE_SINPO");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPOBetween(String value1, String value2) {
            addCriterion("FIRE_SINPO between", value1, value2, "FIRE_SINPO");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPONotBetween(String value1, String value2) {
            addCriterion("FIRE_SINPO not between", value1, value2, "FIRE_SINPO");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMIsNull() {
            addCriterion("FIRE_TAIKAN_TM is null");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMIsNotNull() {
            addCriterion("FIRE_TAIKAN_TM is not null");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMEqualTo(String value) {
            addCriterion("FIRE_TAIKAN_TM =", value, "FIRE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMNotEqualTo(String value) {
            addCriterion("FIRE_TAIKAN_TM <>", value, "FIRE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMGreaterThan(String value) {
            addCriterion("FIRE_TAIKAN_TM >", value, "FIRE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMGreaterThanOrEqualTo(String value) {
            addCriterion("FIRE_TAIKAN_TM >=", value, "FIRE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMLessThan(String value) {
            addCriterion("FIRE_TAIKAN_TM <", value, "FIRE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMLessThanOrEqualTo(String value) {
            addCriterion("FIRE_TAIKAN_TM <=", value, "FIRE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMLike(String value) {
            addCriterion("FIRE_TAIKAN_TM like", value, "FIRE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMNotLike(String value) {
            addCriterion("FIRE_TAIKAN_TM not like", value, "FIRE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMIn(List<String> values) {
            addCriterion("FIRE_TAIKAN_TM in", values, "FIRE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMNotIn(List<String> values) {
            addCriterion("FIRE_TAIKAN_TM not in", values, "FIRE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMBetween(String value1, String value2) {
            addCriterion("FIRE_TAIKAN_TM between", value1, value2, "FIRE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMNotBetween(String value1, String value2) {
            addCriterion("FIRE_TAIKAN_TM not between", value1, value2, "FIRE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDIsNull() {
            addCriterion("SGS_GENIN_CD is null");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDIsNotNull() {
            addCriterion("SGS_GENIN_CD is not null");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDEqualTo(String value) {
            addCriterion("SGS_GENIN_CD =", value, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDNotEqualTo(String value) {
            addCriterion("SGS_GENIN_CD <>", value, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDGreaterThan(String value) {
            addCriterion("SGS_GENIN_CD >", value, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDGreaterThanOrEqualTo(String value) {
            addCriterion("SGS_GENIN_CD >=", value, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDLessThan(String value) {
            addCriterion("SGS_GENIN_CD <", value, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDLessThanOrEqualTo(String value) {
            addCriterion("SGS_GENIN_CD <=", value, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDLike(String value) {
            addCriterion("SGS_GENIN_CD like", value, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDNotLike(String value) {
            addCriterion("SGS_GENIN_CD not like", value, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDIn(List<String> values) {
            addCriterion("SGS_GENIN_CD in", values, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDNotIn(List<String> values) {
            addCriterion("SGS_GENIN_CD not in", values, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDBetween(String value1, String value2) {
            addCriterion("SGS_GENIN_CD between", value1, value2, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDNotBetween(String value1, String value2) {
            addCriterion("SGS_GENIN_CD not between", value1, value2, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOUIsNull() {
            addCriterion("GEN_DTL_NAIYOU is null");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOUIsNotNull() {
            addCriterion("GEN_DTL_NAIYOU is not null");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOUEqualTo(String value) {
            addCriterion("GEN_DTL_NAIYOU =", value, "GEN_DTL_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOUNotEqualTo(String value) {
            addCriterion("GEN_DTL_NAIYOU <>", value, "GEN_DTL_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOUGreaterThan(String value) {
            addCriterion("GEN_DTL_NAIYOU >", value, "GEN_DTL_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOUGreaterThanOrEqualTo(String value) {
            addCriterion("GEN_DTL_NAIYOU >=", value, "GEN_DTL_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOULessThan(String value) {
            addCriterion("GEN_DTL_NAIYOU <", value, "GEN_DTL_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOULessThanOrEqualTo(String value) {
            addCriterion("GEN_DTL_NAIYOU <=", value, "GEN_DTL_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOULike(String value) {
            addCriterion("GEN_DTL_NAIYOU like", value, "GEN_DTL_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOUNotLike(String value) {
            addCriterion("GEN_DTL_NAIYOU not like", value, "GEN_DTL_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOUIn(List<String> values) {
            addCriterion("GEN_DTL_NAIYOU in", values, "GEN_DTL_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOUNotIn(List<String> values) {
            addCriterion("GEN_DTL_NAIYOU not in", values, "GEN_DTL_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOUBetween(String value1, String value2) {
            addCriterion("GEN_DTL_NAIYOU between", value1, value2, "GEN_DTL_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOUNotBetween(String value1, String value2) {
            addCriterion("GEN_DTL_NAIYOU not between", value1, value2, "GEN_DTL_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1IsNull() {
            addCriterion("GEN_NAIYOU_1 is null");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1IsNotNull() {
            addCriterion("GEN_NAIYOU_1 is not null");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1EqualTo(String value) {
            addCriterion("GEN_NAIYOU_1 =", value, "GEN_NAIYOU_1");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1NotEqualTo(String value) {
            addCriterion("GEN_NAIYOU_1 <>", value, "GEN_NAIYOU_1");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1GreaterThan(String value) {
            addCriterion("GEN_NAIYOU_1 >", value, "GEN_NAIYOU_1");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1GreaterThanOrEqualTo(String value) {
            addCriterion("GEN_NAIYOU_1 >=", value, "GEN_NAIYOU_1");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1LessThan(String value) {
            addCriterion("GEN_NAIYOU_1 <", value, "GEN_NAIYOU_1");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1LessThanOrEqualTo(String value) {
            addCriterion("GEN_NAIYOU_1 <=", value, "GEN_NAIYOU_1");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1Like(String value) {
            addCriterion("GEN_NAIYOU_1 like", value, "GEN_NAIYOU_1");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1NotLike(String value) {
            addCriterion("GEN_NAIYOU_1 not like", value, "GEN_NAIYOU_1");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1In(List<String> values) {
            addCriterion("GEN_NAIYOU_1 in", values, "GEN_NAIYOU_1");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1NotIn(List<String> values) {
            addCriterion("GEN_NAIYOU_1 not in", values, "GEN_NAIYOU_1");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1Between(String value1, String value2) {
            addCriterion("GEN_NAIYOU_1 between", value1, value2, "GEN_NAIYOU_1");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1NotBetween(String value1, String value2) {
            addCriterion("GEN_NAIYOU_1 not between", value1, value2, "GEN_NAIYOU_1");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2IsNull() {
            addCriterion("GEN_NAIYOU_2 is null");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2IsNotNull() {
            addCriterion("GEN_NAIYOU_2 is not null");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2EqualTo(String value) {
            addCriterion("GEN_NAIYOU_2 =", value, "GEN_NAIYOU_2");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2NotEqualTo(String value) {
            addCriterion("GEN_NAIYOU_2 <>", value, "GEN_NAIYOU_2");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2GreaterThan(String value) {
            addCriterion("GEN_NAIYOU_2 >", value, "GEN_NAIYOU_2");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2GreaterThanOrEqualTo(String value) {
            addCriterion("GEN_NAIYOU_2 >=", value, "GEN_NAIYOU_2");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2LessThan(String value) {
            addCriterion("GEN_NAIYOU_2 <", value, "GEN_NAIYOU_2");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2LessThanOrEqualTo(String value) {
            addCriterion("GEN_NAIYOU_2 <=", value, "GEN_NAIYOU_2");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2Like(String value) {
            addCriterion("GEN_NAIYOU_2 like", value, "GEN_NAIYOU_2");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2NotLike(String value) {
            addCriterion("GEN_NAIYOU_2 not like", value, "GEN_NAIYOU_2");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2In(List<String> values) {
            addCriterion("GEN_NAIYOU_2 in", values, "GEN_NAIYOU_2");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2NotIn(List<String> values) {
            addCriterion("GEN_NAIYOU_2 not in", values, "GEN_NAIYOU_2");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2Between(String value1, String value2) {
            addCriterion("GEN_NAIYOU_2 between", value1, value2, "GEN_NAIYOU_2");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2NotBetween(String value1, String value2) {
            addCriterion("GEN_NAIYOU_2 not between", value1, value2, "GEN_NAIYOU_2");
            return (Criteria) this;
        }

        public Criteria andJIANBNR_CDIsNull() {
            addCriterion("JIANBNR_CD is null");
            return (Criteria) this;
        }

        public Criteria andJIANBNR_CDIsNotNull() {
            addCriterion("JIANBNR_CD is not null");
            return (Criteria) this;
        }

        public Criteria andJIANBNR_CDEqualTo(String value) {
            addCriterion("JIANBNR_CD =", value, "JIANBNR_CD");
            return (Criteria) this;
        }

        public Criteria andJIANBNR_CDNotEqualTo(String value) {
            addCriterion("JIANBNR_CD <>", value, "JIANBNR_CD");
            return (Criteria) this;
        }

        public Criteria andJIANBNR_CDGreaterThan(String value) {
            addCriterion("JIANBNR_CD >", value, "JIANBNR_CD");
            return (Criteria) this;
        }

        public Criteria andJIANBNR_CDGreaterThanOrEqualTo(String value) {
            addCriterion("JIANBNR_CD >=", value, "JIANBNR_CD");
            return (Criteria) this;
        }

        public Criteria andJIANBNR_CDLessThan(String value) {
            addCriterion("JIANBNR_CD <", value, "JIANBNR_CD");
            return (Criteria) this;
        }

        public Criteria andJIANBNR_CDLessThanOrEqualTo(String value) {
            addCriterion("JIANBNR_CD <=", value, "JIANBNR_CD");
            return (Criteria) this;
        }

        public Criteria andJIANBNR_CDLike(String value) {
            addCriterion("JIANBNR_CD like", value, "JIANBNR_CD");
            return (Criteria) this;
        }

        public Criteria andJIANBNR_CDNotLike(String value) {
            addCriterion("JIANBNR_CD not like", value, "JIANBNR_CD");
            return (Criteria) this;
        }

        public Criteria andJIANBNR_CDIn(List<String> values) {
            addCriterion("JIANBNR_CD in", values, "JIANBNR_CD");
            return (Criteria) this;
        }

        public Criteria andJIANBNR_CDNotIn(List<String> values) {
            addCriterion("JIANBNR_CD not in", values, "JIANBNR_CD");
            return (Criteria) this;
        }

        public Criteria andJIANBNR_CDBetween(String value1, String value2) {
            addCriterion("JIANBNR_CD between", value1, value2, "JIANBNR_CD");
            return (Criteria) this;
        }

        public Criteria andJIANBNR_CDNotBetween(String value1, String value2) {
            addCriterion("JIANBNR_CD not between", value1, value2, "JIANBNR_CD");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNR_CDIsNull() {
            addCriterion("KEIHOBNR_CD is null");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNR_CDIsNotNull() {
            addCriterion("KEIHOBNR_CD is not null");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNR_CDEqualTo(String value) {
            addCriterion("KEIHOBNR_CD =", value, "KEIHOBNR_CD");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNR_CDNotEqualTo(String value) {
            addCriterion("KEIHOBNR_CD <>", value, "KEIHOBNR_CD");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNR_CDGreaterThan(String value) {
            addCriterion("KEIHOBNR_CD >", value, "KEIHOBNR_CD");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNR_CDGreaterThanOrEqualTo(String value) {
            addCriterion("KEIHOBNR_CD >=", value, "KEIHOBNR_CD");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNR_CDLessThan(String value) {
            addCriterion("KEIHOBNR_CD <", value, "KEIHOBNR_CD");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNR_CDLessThanOrEqualTo(String value) {
            addCriterion("KEIHOBNR_CD <=", value, "KEIHOBNR_CD");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNR_CDLike(String value) {
            addCriterion("KEIHOBNR_CD like", value, "KEIHOBNR_CD");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNR_CDNotLike(String value) {
            addCriterion("KEIHOBNR_CD not like", value, "KEIHOBNR_CD");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNR_CDIn(List<String> values) {
            addCriterion("KEIHOBNR_CD in", values, "KEIHOBNR_CD");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNR_CDNotIn(List<String> values) {
            addCriterion("KEIHOBNR_CD not in", values, "KEIHOBNR_CD");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNR_CDBetween(String value1, String value2) {
            addCriterion("KEIHOBNR_CD between", value1, value2, "KEIHOBNR_CD");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNR_CDNotBetween(String value1, String value2) {
            addCriterion("KEIHOBNR_CD not between", value1, value2, "KEIHOBNR_CD");
            return (Criteria) this;
        }

        public Criteria andGENBNR_CDIsNull() {
            addCriterion("GENBNR_CD is null");
            return (Criteria) this;
        }

        public Criteria andGENBNR_CDIsNotNull() {
            addCriterion("GENBNR_CD is not null");
            return (Criteria) this;
        }

        public Criteria andGENBNR_CDEqualTo(String value) {
            addCriterion("GENBNR_CD =", value, "GENBNR_CD");
            return (Criteria) this;
        }

        public Criteria andGENBNR_CDNotEqualTo(String value) {
            addCriterion("GENBNR_CD <>", value, "GENBNR_CD");
            return (Criteria) this;
        }

        public Criteria andGENBNR_CDGreaterThan(String value) {
            addCriterion("GENBNR_CD >", value, "GENBNR_CD");
            return (Criteria) this;
        }

        public Criteria andGENBNR_CDGreaterThanOrEqualTo(String value) {
            addCriterion("GENBNR_CD >=", value, "GENBNR_CD");
            return (Criteria) this;
        }

        public Criteria andGENBNR_CDLessThan(String value) {
            addCriterion("GENBNR_CD <", value, "GENBNR_CD");
            return (Criteria) this;
        }

        public Criteria andGENBNR_CDLessThanOrEqualTo(String value) {
            addCriterion("GENBNR_CD <=", value, "GENBNR_CD");
            return (Criteria) this;
        }

        public Criteria andGENBNR_CDLike(String value) {
            addCriterion("GENBNR_CD like", value, "GENBNR_CD");
            return (Criteria) this;
        }

        public Criteria andGENBNR_CDNotLike(String value) {
            addCriterion("GENBNR_CD not like", value, "GENBNR_CD");
            return (Criteria) this;
        }

        public Criteria andGENBNR_CDIn(List<String> values) {
            addCriterion("GENBNR_CD in", values, "GENBNR_CD");
            return (Criteria) this;
        }

        public Criteria andGENBNR_CDNotIn(List<String> values) {
            addCriterion("GENBNR_CD not in", values, "GENBNR_CD");
            return (Criteria) this;
        }

        public Criteria andGENBNR_CDBetween(String value1, String value2) {
            addCriterion("GENBNR_CD between", value1, value2, "GENBNR_CD");
            return (Criteria) this;
        }

        public Criteria andGENBNR_CDNotBetween(String value1, String value2) {
            addCriterion("GENBNR_CD not between", value1, value2, "GENBNR_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDIsNull() {
            addCriterion("NET_GEN_CD is null");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDIsNotNull() {
            addCriterion("NET_GEN_CD is not null");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDEqualTo(String value) {
            addCriterion("NET_GEN_CD =", value, "NET_GEN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDNotEqualTo(String value) {
            addCriterion("NET_GEN_CD <>", value, "NET_GEN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDGreaterThan(String value) {
            addCriterion("NET_GEN_CD >", value, "NET_GEN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDGreaterThanOrEqualTo(String value) {
            addCriterion("NET_GEN_CD >=", value, "NET_GEN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDLessThan(String value) {
            addCriterion("NET_GEN_CD <", value, "NET_GEN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDLessThanOrEqualTo(String value) {
            addCriterion("NET_GEN_CD <=", value, "NET_GEN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDLike(String value) {
            addCriterion("NET_GEN_CD like", value, "NET_GEN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDNotLike(String value) {
            addCriterion("NET_GEN_CD not like", value, "NET_GEN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDIn(List<String> values) {
            addCriterion("NET_GEN_CD in", values, "NET_GEN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDNotIn(List<String> values) {
            addCriterion("NET_GEN_CD not in", values, "NET_GEN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDBetween(String value1, String value2) {
            addCriterion("NET_GEN_CD between", value1, value2, "NET_GEN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDNotBetween(String value1, String value2) {
            addCriterion("NET_GEN_CD not between", value1, value2, "NET_GEN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOUIsNull() {
            addCriterion("NET_GEN_NAIYOU is null");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOUIsNotNull() {
            addCriterion("NET_GEN_NAIYOU is not null");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOUEqualTo(String value) {
            addCriterion("NET_GEN_NAIYOU =", value, "NET_GEN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOUNotEqualTo(String value) {
            addCriterion("NET_GEN_NAIYOU <>", value, "NET_GEN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOUGreaterThan(String value) {
            addCriterion("NET_GEN_NAIYOU >", value, "NET_GEN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOUGreaterThanOrEqualTo(String value) {
            addCriterion("NET_GEN_NAIYOU >=", value, "NET_GEN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOULessThan(String value) {
            addCriterion("NET_GEN_NAIYOU <", value, "NET_GEN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOULessThanOrEqualTo(String value) {
            addCriterion("NET_GEN_NAIYOU <=", value, "NET_GEN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOULike(String value) {
            addCriterion("NET_GEN_NAIYOU like", value, "NET_GEN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOUNotLike(String value) {
            addCriterion("NET_GEN_NAIYOU not like", value, "NET_GEN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOUIn(List<String> values) {
            addCriterion("NET_GEN_NAIYOU in", values, "NET_GEN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOUNotIn(List<String> values) {
            addCriterion("NET_GEN_NAIYOU not in", values, "NET_GEN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOUBetween(String value1, String value2) {
            addCriterion("NET_GEN_NAIYOU between", value1, value2, "NET_GEN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOUNotBetween(String value1, String value2) {
            addCriterion("NET_GEN_NAIYOU not between", value1, value2, "NET_GEN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andSENSOR_CDIsNull() {
            addCriterion("SENSOR_CD is null");
            return (Criteria) this;
        }

        public Criteria andSENSOR_CDIsNotNull() {
            addCriterion("SENSOR_CD is not null");
            return (Criteria) this;
        }

        public Criteria andSENSOR_CDEqualTo(String value) {
            addCriterion("SENSOR_CD =", value, "SENSOR_CD");
            return (Criteria) this;
        }

        public Criteria andSENSOR_CDNotEqualTo(String value) {
            addCriterion("SENSOR_CD <>", value, "SENSOR_CD");
            return (Criteria) this;
        }

        public Criteria andSENSOR_CDGreaterThan(String value) {
            addCriterion("SENSOR_CD >", value, "SENSOR_CD");
            return (Criteria) this;
        }

        public Criteria andSENSOR_CDGreaterThanOrEqualTo(String value) {
            addCriterion("SENSOR_CD >=", value, "SENSOR_CD");
            return (Criteria) this;
        }

        public Criteria andSENSOR_CDLessThan(String value) {
            addCriterion("SENSOR_CD <", value, "SENSOR_CD");
            return (Criteria) this;
        }

        public Criteria andSENSOR_CDLessThanOrEqualTo(String value) {
            addCriterion("SENSOR_CD <=", value, "SENSOR_CD");
            return (Criteria) this;
        }

        public Criteria andSENSOR_CDLike(String value) {
            addCriterion("SENSOR_CD like", value, "SENSOR_CD");
            return (Criteria) this;
        }

        public Criteria andSENSOR_CDNotLike(String value) {
            addCriterion("SENSOR_CD not like", value, "SENSOR_CD");
            return (Criteria) this;
        }

        public Criteria andSENSOR_CDIn(List<String> values) {
            addCriterion("SENSOR_CD in", values, "SENSOR_CD");
            return (Criteria) this;
        }

        public Criteria andSENSOR_CDNotIn(List<String> values) {
            addCriterion("SENSOR_CD not in", values, "SENSOR_CD");
            return (Criteria) this;
        }

        public Criteria andSENSOR_CDBetween(String value1, String value2) {
            addCriterion("SENSOR_CD between", value1, value2, "SENSOR_CD");
            return (Criteria) this;
        }

        public Criteria andSENSOR_CDNotBetween(String value1, String value2) {
            addCriterion("SENSOR_CD not between", value1, value2, "SENSOR_CD");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOUIsNull() {
            addCriterion("TIMER_CHOKKOU is null");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOUIsNotNull() {
            addCriterion("TIMER_CHOKKOU is not null");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOUEqualTo(String value) {
            addCriterion("TIMER_CHOKKOU =", value, "TIMER_CHOKKOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOUNotEqualTo(String value) {
            addCriterion("TIMER_CHOKKOU <>", value, "TIMER_CHOKKOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOUGreaterThan(String value) {
            addCriterion("TIMER_CHOKKOU >", value, "TIMER_CHOKKOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOUGreaterThanOrEqualTo(String value) {
            addCriterion("TIMER_CHOKKOU >=", value, "TIMER_CHOKKOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOULessThan(String value) {
            addCriterion("TIMER_CHOKKOU <", value, "TIMER_CHOKKOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOULessThanOrEqualTo(String value) {
            addCriterion("TIMER_CHOKKOU <=", value, "TIMER_CHOKKOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOULike(String value) {
            addCriterion("TIMER_CHOKKOU like", value, "TIMER_CHOKKOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOUNotLike(String value) {
            addCriterion("TIMER_CHOKKOU not like", value, "TIMER_CHOKKOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOUIn(List<String> values) {
            addCriterion("TIMER_CHOKKOU in", values, "TIMER_CHOKKOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOUNotIn(List<String> values) {
            addCriterion("TIMER_CHOKKOU not in", values, "TIMER_CHOKKOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOUBetween(String value1, String value2) {
            addCriterion("TIMER_CHOKKOU between", value1, value2, "TIMER_CHOKKOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOUNotBetween(String value1, String value2) {
            addCriterion("TIMER_CHOKKOU not between", value1, value2, "TIMER_CHOKKOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKUIsNull() {
            addCriterion("TIMER_GENCHAKU is null");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKUIsNotNull() {
            addCriterion("TIMER_GENCHAKU is not null");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKUEqualTo(String value) {
            addCriterion("TIMER_GENCHAKU =", value, "TIMER_GENCHAKU");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKUNotEqualTo(String value) {
            addCriterion("TIMER_GENCHAKU <>", value, "TIMER_GENCHAKU");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKUGreaterThan(String value) {
            addCriterion("TIMER_GENCHAKU >", value, "TIMER_GENCHAKU");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKUGreaterThanOrEqualTo(String value) {
            addCriterion("TIMER_GENCHAKU >=", value, "TIMER_GENCHAKU");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKULessThan(String value) {
            addCriterion("TIMER_GENCHAKU <", value, "TIMER_GENCHAKU");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKULessThanOrEqualTo(String value) {
            addCriterion("TIMER_GENCHAKU <=", value, "TIMER_GENCHAKU");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKULike(String value) {
            addCriterion("TIMER_GENCHAKU like", value, "TIMER_GENCHAKU");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKUNotLike(String value) {
            addCriterion("TIMER_GENCHAKU not like", value, "TIMER_GENCHAKU");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKUIn(List<String> values) {
            addCriterion("TIMER_GENCHAKU in", values, "TIMER_GENCHAKU");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKUNotIn(List<String> values) {
            addCriterion("TIMER_GENCHAKU not in", values, "TIMER_GENCHAKU");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKUBetween(String value1, String value2) {
            addCriterion("TIMER_GENCHAKU between", value1, value2, "TIMER_GENCHAKU");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKUNotBetween(String value1, String value2) {
            addCriterion("TIMER_GENCHAKU not between", value1, value2, "TIMER_GENCHAKU");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYOYOUIsNull() {
            addCriterion("TIMER_SYOYOU is null");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYOYOUIsNotNull() {
            addCriterion("TIMER_SYOYOU is not null");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYOYOUEqualTo(String value) {
            addCriterion("TIMER_SYOYOU =", value, "TIMER_SYOYOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYOYOUNotEqualTo(String value) {
            addCriterion("TIMER_SYOYOU <>", value, "TIMER_SYOYOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYOYOUGreaterThan(String value) {
            addCriterion("TIMER_SYOYOU >", value, "TIMER_SYOYOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYOYOUGreaterThanOrEqualTo(String value) {
            addCriterion("TIMER_SYOYOU >=", value, "TIMER_SYOYOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYOYOULessThan(String value) {
            addCriterion("TIMER_SYOYOU <", value, "TIMER_SYOYOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYOYOULessThanOrEqualTo(String value) {
            addCriterion("TIMER_SYOYOU <=", value, "TIMER_SYOYOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYOYOULike(String value) {
            addCriterion("TIMER_SYOYOU like", value, "TIMER_SYOYOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYOYOUNotLike(String value) {
            addCriterion("TIMER_SYOYOU not like", value, "TIMER_SYOYOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYOYOUIn(List<String> values) {
            addCriterion("TIMER_SYOYOU in", values, "TIMER_SYOYOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYOYOUNotIn(List<String> values) {
            addCriterion("TIMER_SYOYOU not in", values, "TIMER_SYOYOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYOYOUBetween(String value1, String value2) {
            addCriterion("TIMER_SYOYOU between", value1, value2, "TIMER_SYOYOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYOYOUNotBetween(String value1, String value2) {
            addCriterion("TIMER_SYOYOU not between", value1, value2, "TIMER_SYOYOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKANIsNull() {
            addCriterion("TIMER_NYUUKAN is null");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKANIsNotNull() {
            addCriterion("TIMER_NYUUKAN is not null");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKANEqualTo(String value) {
            addCriterion("TIMER_NYUUKAN =", value, "TIMER_NYUUKAN");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKANNotEqualTo(String value) {
            addCriterion("TIMER_NYUUKAN <>", value, "TIMER_NYUUKAN");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKANGreaterThan(String value) {
            addCriterion("TIMER_NYUUKAN >", value, "TIMER_NYUUKAN");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKANGreaterThanOrEqualTo(String value) {
            addCriterion("TIMER_NYUUKAN >=", value, "TIMER_NYUUKAN");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKANLessThan(String value) {
            addCriterion("TIMER_NYUUKAN <", value, "TIMER_NYUUKAN");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKANLessThanOrEqualTo(String value) {
            addCriterion("TIMER_NYUUKAN <=", value, "TIMER_NYUUKAN");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKANLike(String value) {
            addCriterion("TIMER_NYUUKAN like", value, "TIMER_NYUUKAN");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKANNotLike(String value) {
            addCriterion("TIMER_NYUUKAN not like", value, "TIMER_NYUUKAN");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKANIn(List<String> values) {
            addCriterion("TIMER_NYUUKAN in", values, "TIMER_NYUUKAN");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKANNotIn(List<String> values) {
            addCriterion("TIMER_NYUUKAN not in", values, "TIMER_NYUUKAN");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKANBetween(String value1, String value2) {
            addCriterion("TIMER_NYUUKAN between", value1, value2, "TIMER_NYUUKAN");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKANNotBetween(String value1, String value2) {
            addCriterion("TIMER_NYUUKAN not between", value1, value2, "TIMER_NYUUKAN");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKANIsNull() {
            addCriterion("TIMER_TAIKAN is null");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKANIsNotNull() {
            addCriterion("TIMER_TAIKAN is not null");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKANEqualTo(String value) {
            addCriterion("TIMER_TAIKAN =", value, "TIMER_TAIKAN");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKANNotEqualTo(String value) {
            addCriterion("TIMER_TAIKAN <>", value, "TIMER_TAIKAN");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKANGreaterThan(String value) {
            addCriterion("TIMER_TAIKAN >", value, "TIMER_TAIKAN");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKANGreaterThanOrEqualTo(String value) {
            addCriterion("TIMER_TAIKAN >=", value, "TIMER_TAIKAN");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKANLessThan(String value) {
            addCriterion("TIMER_TAIKAN <", value, "TIMER_TAIKAN");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKANLessThanOrEqualTo(String value) {
            addCriterion("TIMER_TAIKAN <=", value, "TIMER_TAIKAN");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKANLike(String value) {
            addCriterion("TIMER_TAIKAN like", value, "TIMER_TAIKAN");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKANNotLike(String value) {
            addCriterion("TIMER_TAIKAN not like", value, "TIMER_TAIKAN");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKANIn(List<String> values) {
            addCriterion("TIMER_TAIKAN in", values, "TIMER_TAIKAN");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKANNotIn(List<String> values) {
            addCriterion("TIMER_TAIKAN not in", values, "TIMER_TAIKAN");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKANBetween(String value1, String value2) {
            addCriterion("TIMER_TAIKAN between", value1, value2, "TIMER_TAIKAN");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKANNotBetween(String value1, String value2) {
            addCriterion("TIMER_TAIKAN not between", value1, value2, "TIMER_TAIKAN");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYUURYOUIsNull() {
            addCriterion("TIMER_SYUURYOU is null");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYUURYOUIsNotNull() {
            addCriterion("TIMER_SYUURYOU is not null");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYUURYOUEqualTo(String value) {
            addCriterion("TIMER_SYUURYOU =", value, "TIMER_SYUURYOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYUURYOUNotEqualTo(String value) {
            addCriterion("TIMER_SYUURYOU <>", value, "TIMER_SYUURYOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYUURYOUGreaterThan(String value) {
            addCriterion("TIMER_SYUURYOU >", value, "TIMER_SYUURYOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYUURYOUGreaterThanOrEqualTo(String value) {
            addCriterion("TIMER_SYUURYOU >=", value, "TIMER_SYUURYOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYUURYOULessThan(String value) {
            addCriterion("TIMER_SYUURYOU <", value, "TIMER_SYUURYOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYUURYOULessThanOrEqualTo(String value) {
            addCriterion("TIMER_SYUURYOU <=", value, "TIMER_SYUURYOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYUURYOULike(String value) {
            addCriterion("TIMER_SYUURYOU like", value, "TIMER_SYUURYOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYUURYOUNotLike(String value) {
            addCriterion("TIMER_SYUURYOU not like", value, "TIMER_SYUURYOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYUURYOUIn(List<String> values) {
            addCriterion("TIMER_SYUURYOU in", values, "TIMER_SYUURYOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYUURYOUNotIn(List<String> values) {
            addCriterion("TIMER_SYUURYOU not in", values, "TIMER_SYUURYOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYUURYOUBetween(String value1, String value2) {
            addCriterion("TIMER_SYUURYOU between", value1, value2, "TIMER_SYUURYOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYUURYOUNotBetween(String value1, String value2) {
            addCriterion("TIMER_SYUURYOU not between", value1, value2, "TIMER_SYUURYOU");
            return (Criteria) this;
        }

        public Criteria andTIME_OVERIsNull() {
            addCriterion("TIME_OVER is null");
            return (Criteria) this;
        }

        public Criteria andTIME_OVERIsNotNull() {
            addCriterion("TIME_OVER is not null");
            return (Criteria) this;
        }

        public Criteria andTIME_OVEREqualTo(String value) {
            addCriterion("TIME_OVER =", value, "TIME_OVER");
            return (Criteria) this;
        }

        public Criteria andTIME_OVERNotEqualTo(String value) {
            addCriterion("TIME_OVER <>", value, "TIME_OVER");
            return (Criteria) this;
        }

        public Criteria andTIME_OVERGreaterThan(String value) {
            addCriterion("TIME_OVER >", value, "TIME_OVER");
            return (Criteria) this;
        }

        public Criteria andTIME_OVERGreaterThanOrEqualTo(String value) {
            addCriterion("TIME_OVER >=", value, "TIME_OVER");
            return (Criteria) this;
        }

        public Criteria andTIME_OVERLessThan(String value) {
            addCriterion("TIME_OVER <", value, "TIME_OVER");
            return (Criteria) this;
        }

        public Criteria andTIME_OVERLessThanOrEqualTo(String value) {
            addCriterion("TIME_OVER <=", value, "TIME_OVER");
            return (Criteria) this;
        }

        public Criteria andTIME_OVERLike(String value) {
            addCriterion("TIME_OVER like", value, "TIME_OVER");
            return (Criteria) this;
        }

        public Criteria andTIME_OVERNotLike(String value) {
            addCriterion("TIME_OVER not like", value, "TIME_OVER");
            return (Criteria) this;
        }

        public Criteria andTIME_OVERIn(List<String> values) {
            addCriterion("TIME_OVER in", values, "TIME_OVER");
            return (Criteria) this;
        }

        public Criteria andTIME_OVERNotIn(List<String> values) {
            addCriterion("TIME_OVER not in", values, "TIME_OVER");
            return (Criteria) this;
        }

        public Criteria andTIME_OVERBetween(String value1, String value2) {
            addCriterion("TIME_OVER between", value1, value2, "TIME_OVER");
            return (Criteria) this;
        }

        public Criteria andTIME_OVERNotBetween(String value1, String value2) {
            addCriterion("TIME_OVER not between", value1, value2, "TIME_OVER");
            return (Criteria) this;
        }

        public Criteria andTIMER_NO_CANCEL_TSIsNull() {
            addCriterion("TIMER_NO_CANCEL_TS is null");
            return (Criteria) this;
        }

        public Criteria andTIMER_NO_CANCEL_TSIsNotNull() {
            addCriterion("TIMER_NO_CANCEL_TS is not null");
            return (Criteria) this;
        }

        public Criteria andTIMER_NO_CANCEL_TSEqualTo(String value) {
            addCriterion("TIMER_NO_CANCEL_TS =", value, "TIMER_NO_CANCEL_TS");
            return (Criteria) this;
        }

        public Criteria andTIMER_NO_CANCEL_TSNotEqualTo(String value) {
            addCriterion("TIMER_NO_CANCEL_TS <>", value, "TIMER_NO_CANCEL_TS");
            return (Criteria) this;
        }

        public Criteria andTIMER_NO_CANCEL_TSGreaterThan(String value) {
            addCriterion("TIMER_NO_CANCEL_TS >", value, "TIMER_NO_CANCEL_TS");
            return (Criteria) this;
        }

        public Criteria andTIMER_NO_CANCEL_TSGreaterThanOrEqualTo(String value) {
            addCriterion("TIMER_NO_CANCEL_TS >=", value, "TIMER_NO_CANCEL_TS");
            return (Criteria) this;
        }

        public Criteria andTIMER_NO_CANCEL_TSLessThan(String value) {
            addCriterion("TIMER_NO_CANCEL_TS <", value, "TIMER_NO_CANCEL_TS");
            return (Criteria) this;
        }

        public Criteria andTIMER_NO_CANCEL_TSLessThanOrEqualTo(String value) {
            addCriterion("TIMER_NO_CANCEL_TS <=", value, "TIMER_NO_CANCEL_TS");
            return (Criteria) this;
        }

        public Criteria andTIMER_NO_CANCEL_TSLike(String value) {
            addCriterion("TIMER_NO_CANCEL_TS like", value, "TIMER_NO_CANCEL_TS");
            return (Criteria) this;
        }

        public Criteria andTIMER_NO_CANCEL_TSNotLike(String value) {
            addCriterion("TIMER_NO_CANCEL_TS not like", value, "TIMER_NO_CANCEL_TS");
            return (Criteria) this;
        }

        public Criteria andTIMER_NO_CANCEL_TSIn(List<String> values) {
            addCriterion("TIMER_NO_CANCEL_TS in", values, "TIMER_NO_CANCEL_TS");
            return (Criteria) this;
        }

        public Criteria andTIMER_NO_CANCEL_TSNotIn(List<String> values) {
            addCriterion("TIMER_NO_CANCEL_TS not in", values, "TIMER_NO_CANCEL_TS");
            return (Criteria) this;
        }

        public Criteria andTIMER_NO_CANCEL_TSBetween(String value1, String value2) {
            addCriterion("TIMER_NO_CANCEL_TS between", value1, value2, "TIMER_NO_CANCEL_TS");
            return (Criteria) this;
        }

        public Criteria andTIMER_NO_CANCEL_TSNotBetween(String value1, String value2) {
            addCriterion("TIMER_NO_CANCEL_TS not between", value1, value2, "TIMER_NO_CANCEL_TS");
            return (Criteria) this;
        }

        public Criteria andE_MEMOIsNull() {
            addCriterion("E_MEMO is null");
            return (Criteria) this;
        }

        public Criteria andE_MEMOIsNotNull() {
            addCriterion("E_MEMO is not null");
            return (Criteria) this;
        }

        public Criteria andE_MEMOEqualTo(String value) {
            addCriterion("E_MEMO =", value, "e_MEMO");
            return (Criteria) this;
        }

        public Criteria andE_MEMONotEqualTo(String value) {
            addCriterion("E_MEMO <>", value, "e_MEMO");
            return (Criteria) this;
        }

        public Criteria andE_MEMOGreaterThan(String value) {
            addCriterion("E_MEMO >", value, "e_MEMO");
            return (Criteria) this;
        }

        public Criteria andE_MEMOGreaterThanOrEqualTo(String value) {
            addCriterion("E_MEMO >=", value, "e_MEMO");
            return (Criteria) this;
        }

        public Criteria andE_MEMOLessThan(String value) {
            addCriterion("E_MEMO <", value, "e_MEMO");
            return (Criteria) this;
        }

        public Criteria andE_MEMOLessThanOrEqualTo(String value) {
            addCriterion("E_MEMO <=", value, "e_MEMO");
            return (Criteria) this;
        }

        public Criteria andE_MEMOLike(String value) {
            addCriterion("E_MEMO like", value, "e_MEMO");
            return (Criteria) this;
        }

        public Criteria andE_MEMONotLike(String value) {
            addCriterion("E_MEMO not like", value, "e_MEMO");
            return (Criteria) this;
        }

        public Criteria andE_MEMOIn(List<String> values) {
            addCriterion("E_MEMO in", values, "e_MEMO");
            return (Criteria) this;
        }

        public Criteria andE_MEMONotIn(List<String> values) {
            addCriterion("E_MEMO not in", values, "e_MEMO");
            return (Criteria) this;
        }

        public Criteria andE_MEMOBetween(String value1, String value2) {
            addCriterion("E_MEMO between", value1, value2, "e_MEMO");
            return (Criteria) this;
        }

        public Criteria andE_MEMONotBetween(String value1, String value2) {
            addCriterion("E_MEMO not between", value1, value2, "e_MEMO");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDIsNull() {
            addCriterion("JIGYO_CD is null");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDIsNotNull() {
            addCriterion("JIGYO_CD is not null");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDEqualTo(String value) {
            addCriterion("JIGYO_CD =", value, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDNotEqualTo(String value) {
            addCriterion("JIGYO_CD <>", value, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDGreaterThan(String value) {
            addCriterion("JIGYO_CD >", value, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDGreaterThanOrEqualTo(String value) {
            addCriterion("JIGYO_CD >=", value, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDLessThan(String value) {
            addCriterion("JIGYO_CD <", value, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDLessThanOrEqualTo(String value) {
            addCriterion("JIGYO_CD <=", value, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDLike(String value) {
            addCriterion("JIGYO_CD like", value, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDNotLike(String value) {
            addCriterion("JIGYO_CD not like", value, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDIn(List<String> values) {
            addCriterion("JIGYO_CD in", values, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDNotIn(List<String> values) {
            addCriterion("JIGYO_CD not in", values, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDBetween(String value1, String value2) {
            addCriterion("JIGYO_CD between", value1, value2, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDNotBetween(String value1, String value2) {
            addCriterion("JIGYO_CD not between", value1, value2, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andN0_TIMEIsNull() {
            addCriterion("N0_TIME is null");
            return (Criteria) this;
        }

        public Criteria andN0_TIMEIsNotNull() {
            addCriterion("N0_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andN0_TIMEEqualTo(String value) {
            addCriterion("N0_TIME =", value, "n0_TIME");
            return (Criteria) this;
        }

        public Criteria andN0_TIMENotEqualTo(String value) {
            addCriterion("N0_TIME <>", value, "n0_TIME");
            return (Criteria) this;
        }

        public Criteria andN0_TIMEGreaterThan(String value) {
            addCriterion("N0_TIME >", value, "n0_TIME");
            return (Criteria) this;
        }

        public Criteria andN0_TIMEGreaterThanOrEqualTo(String value) {
            addCriterion("N0_TIME >=", value, "n0_TIME");
            return (Criteria) this;
        }

        public Criteria andN0_TIMELessThan(String value) {
            addCriterion("N0_TIME <", value, "n0_TIME");
            return (Criteria) this;
        }

        public Criteria andN0_TIMELessThanOrEqualTo(String value) {
            addCriterion("N0_TIME <=", value, "n0_TIME");
            return (Criteria) this;
        }

        public Criteria andN0_TIMELike(String value) {
            addCriterion("N0_TIME like", value, "n0_TIME");
            return (Criteria) this;
        }

        public Criteria andN0_TIMENotLike(String value) {
            addCriterion("N0_TIME not like", value, "n0_TIME");
            return (Criteria) this;
        }

        public Criteria andN0_TIMEIn(List<String> values) {
            addCriterion("N0_TIME in", values, "n0_TIME");
            return (Criteria) this;
        }

        public Criteria andN0_TIMENotIn(List<String> values) {
            addCriterion("N0_TIME not in", values, "n0_TIME");
            return (Criteria) this;
        }

        public Criteria andN0_TIMEBetween(String value1, String value2) {
            addCriterion("N0_TIME between", value1, value2, "n0_TIME");
            return (Criteria) this;
        }

        public Criteria andN0_TIMENotBetween(String value1, String value2) {
            addCriterion("N0_TIME not between", value1, value2, "n0_TIME");
            return (Criteria) this;
        }

        public Criteria andRE_WARN_FLGIsNull() {
            addCriterion("RE_WARN_FLG is null");
            return (Criteria) this;
        }

        public Criteria andRE_WARN_FLGIsNotNull() {
            addCriterion("RE_WARN_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andRE_WARN_FLGEqualTo(String value) {
            addCriterion("RE_WARN_FLG =", value, "RE_WARN_FLG");
            return (Criteria) this;
        }

        public Criteria andRE_WARN_FLGNotEqualTo(String value) {
            addCriterion("RE_WARN_FLG <>", value, "RE_WARN_FLG");
            return (Criteria) this;
        }

        public Criteria andRE_WARN_FLGGreaterThan(String value) {
            addCriterion("RE_WARN_FLG >", value, "RE_WARN_FLG");
            return (Criteria) this;
        }

        public Criteria andRE_WARN_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("RE_WARN_FLG >=", value, "RE_WARN_FLG");
            return (Criteria) this;
        }

        public Criteria andRE_WARN_FLGLessThan(String value) {
            addCriterion("RE_WARN_FLG <", value, "RE_WARN_FLG");
            return (Criteria) this;
        }

        public Criteria andRE_WARN_FLGLessThanOrEqualTo(String value) {
            addCriterion("RE_WARN_FLG <=", value, "RE_WARN_FLG");
            return (Criteria) this;
        }

        public Criteria andRE_WARN_FLGLike(String value) {
            addCriterion("RE_WARN_FLG like", value, "RE_WARN_FLG");
            return (Criteria) this;
        }

        public Criteria andRE_WARN_FLGNotLike(String value) {
            addCriterion("RE_WARN_FLG not like", value, "RE_WARN_FLG");
            return (Criteria) this;
        }

        public Criteria andRE_WARN_FLGIn(List<String> values) {
            addCriterion("RE_WARN_FLG in", values, "RE_WARN_FLG");
            return (Criteria) this;
        }

        public Criteria andRE_WARN_FLGNotIn(List<String> values) {
            addCriterion("RE_WARN_FLG not in", values, "RE_WARN_FLG");
            return (Criteria) this;
        }

        public Criteria andRE_WARN_FLGBetween(String value1, String value2) {
            addCriterion("RE_WARN_FLG between", value1, value2, "RE_WARN_FLG");
            return (Criteria) this;
        }

        public Criteria andRE_WARN_FLGNotBetween(String value1, String value2) {
            addCriterion("RE_WARN_FLG not between", value1, value2, "RE_WARN_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGIsNull() {
            addCriterion("BUZZ_FLG is null");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGIsNotNull() {
            addCriterion("BUZZ_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGEqualTo(String value) {
            addCriterion("BUZZ_FLG =", value, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGNotEqualTo(String value) {
            addCriterion("BUZZ_FLG <>", value, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGGreaterThan(String value) {
            addCriterion("BUZZ_FLG >", value, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("BUZZ_FLG >=", value, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGLessThan(String value) {
            addCriterion("BUZZ_FLG <", value, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGLessThanOrEqualTo(String value) {
            addCriterion("BUZZ_FLG <=", value, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGLike(String value) {
            addCriterion("BUZZ_FLG like", value, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGNotLike(String value) {
            addCriterion("BUZZ_FLG not like", value, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGIn(List<String> values) {
            addCriterion("BUZZ_FLG in", values, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGNotIn(List<String> values) {
            addCriterion("BUZZ_FLG not in", values, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGBetween(String value1, String value2) {
            addCriterion("BUZZ_FLG between", value1, value2, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGNotBetween(String value1, String value2) {
            addCriterion("BUZZ_FLG not between", value1, value2, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andRESERVE_WARN_FLGIsNull() {
            addCriterion("RESERVE_WARN_FLG is null");
            return (Criteria) this;
        }

        public Criteria andRESERVE_WARN_FLGIsNotNull() {
            addCriterion("RESERVE_WARN_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andRESERVE_WARN_FLGEqualTo(String value) {
            addCriterion("RESERVE_WARN_FLG =", value, "RESERVE_WARN_FLG");
            return (Criteria) this;
        }

        public Criteria andRESERVE_WARN_FLGNotEqualTo(String value) {
            addCriterion("RESERVE_WARN_FLG <>", value, "RESERVE_WARN_FLG");
            return (Criteria) this;
        }

        public Criteria andRESERVE_WARN_FLGGreaterThan(String value) {
            addCriterion("RESERVE_WARN_FLG >", value, "RESERVE_WARN_FLG");
            return (Criteria) this;
        }

        public Criteria andRESERVE_WARN_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("RESERVE_WARN_FLG >=", value, "RESERVE_WARN_FLG");
            return (Criteria) this;
        }

        public Criteria andRESERVE_WARN_FLGLessThan(String value) {
            addCriterion("RESERVE_WARN_FLG <", value, "RESERVE_WARN_FLG");
            return (Criteria) this;
        }

        public Criteria andRESERVE_WARN_FLGLessThanOrEqualTo(String value) {
            addCriterion("RESERVE_WARN_FLG <=", value, "RESERVE_WARN_FLG");
            return (Criteria) this;
        }

        public Criteria andRESERVE_WARN_FLGLike(String value) {
            addCriterion("RESERVE_WARN_FLG like", value, "RESERVE_WARN_FLG");
            return (Criteria) this;
        }

        public Criteria andRESERVE_WARN_FLGNotLike(String value) {
            addCriterion("RESERVE_WARN_FLG not like", value, "RESERVE_WARN_FLG");
            return (Criteria) this;
        }

        public Criteria andRESERVE_WARN_FLGIn(List<String> values) {
            addCriterion("RESERVE_WARN_FLG in", values, "RESERVE_WARN_FLG");
            return (Criteria) this;
        }

        public Criteria andRESERVE_WARN_FLGNotIn(List<String> values) {
            addCriterion("RESERVE_WARN_FLG not in", values, "RESERVE_WARN_FLG");
            return (Criteria) this;
        }

        public Criteria andRESERVE_WARN_FLGBetween(String value1, String value2) {
            addCriterion("RESERVE_WARN_FLG between", value1, value2, "RESERVE_WARN_FLG");
            return (Criteria) this;
        }

        public Criteria andRESERVE_WARN_FLGNotBetween(String value1, String value2) {
            addCriterion("RESERVE_WARN_FLG not between", value1, value2, "RESERVE_WARN_FLG");
            return (Criteria) this;
        }

        public Criteria andMESSAGE_COUNTIsNull() {
            addCriterion("MESSAGE_COUNT is null");
            return (Criteria) this;
        }

        public Criteria andMESSAGE_COUNTIsNotNull() {
            addCriterion("MESSAGE_COUNT is not null");
            return (Criteria) this;
        }

        public Criteria andMESSAGE_COUNTEqualTo(String value) {
            addCriterion("MESSAGE_COUNT =", value, "MESSAGE_COUNT");
            return (Criteria) this;
        }

        public Criteria andMESSAGE_COUNTNotEqualTo(String value) {
            addCriterion("MESSAGE_COUNT <>", value, "MESSAGE_COUNT");
            return (Criteria) this;
        }

        public Criteria andMESSAGE_COUNTGreaterThan(String value) {
            addCriterion("MESSAGE_COUNT >", value, "MESSAGE_COUNT");
            return (Criteria) this;
        }

        public Criteria andMESSAGE_COUNTGreaterThanOrEqualTo(String value) {
            addCriterion("MESSAGE_COUNT >=", value, "MESSAGE_COUNT");
            return (Criteria) this;
        }

        public Criteria andMESSAGE_COUNTLessThan(String value) {
            addCriterion("MESSAGE_COUNT <", value, "MESSAGE_COUNT");
            return (Criteria) this;
        }

        public Criteria andMESSAGE_COUNTLessThanOrEqualTo(String value) {
            addCriterion("MESSAGE_COUNT <=", value, "MESSAGE_COUNT");
            return (Criteria) this;
        }

        public Criteria andMESSAGE_COUNTLike(String value) {
            addCriterion("MESSAGE_COUNT like", value, "MESSAGE_COUNT");
            return (Criteria) this;
        }

        public Criteria andMESSAGE_COUNTNotLike(String value) {
            addCriterion("MESSAGE_COUNT not like", value, "MESSAGE_COUNT");
            return (Criteria) this;
        }

        public Criteria andMESSAGE_COUNTIn(List<String> values) {
            addCriterion("MESSAGE_COUNT in", values, "MESSAGE_COUNT");
            return (Criteria) this;
        }

        public Criteria andMESSAGE_COUNTNotIn(List<String> values) {
            addCriterion("MESSAGE_COUNT not in", values, "MESSAGE_COUNT");
            return (Criteria) this;
        }

        public Criteria andMESSAGE_COUNTBetween(String value1, String value2) {
            addCriterion("MESSAGE_COUNT between", value1, value2, "MESSAGE_COUNT");
            return (Criteria) this;
        }

        public Criteria andMESSAGE_COUNTNotBetween(String value1, String value2) {
            addCriterion("MESSAGE_COUNT not between", value1, value2, "MESSAGE_COUNT");
            return (Criteria) this;
        }

        public Criteria andNO_MEASURE_CNTIsNull() {
            addCriterion("NO_MEASURE_CNT is null");
            return (Criteria) this;
        }

        public Criteria andNO_MEASURE_CNTIsNotNull() {
            addCriterion("NO_MEASURE_CNT is not null");
            return (Criteria) this;
        }

        public Criteria andNO_MEASURE_CNTEqualTo(String value) {
            addCriterion("NO_MEASURE_CNT =", value, "NO_MEASURE_CNT");
            return (Criteria) this;
        }

        public Criteria andNO_MEASURE_CNTNotEqualTo(String value) {
            addCriterion("NO_MEASURE_CNT <>", value, "NO_MEASURE_CNT");
            return (Criteria) this;
        }

        public Criteria andNO_MEASURE_CNTGreaterThan(String value) {
            addCriterion("NO_MEASURE_CNT >", value, "NO_MEASURE_CNT");
            return (Criteria) this;
        }

        public Criteria andNO_MEASURE_CNTGreaterThanOrEqualTo(String value) {
            addCriterion("NO_MEASURE_CNT >=", value, "NO_MEASURE_CNT");
            return (Criteria) this;
        }

        public Criteria andNO_MEASURE_CNTLessThan(String value) {
            addCriterion("NO_MEASURE_CNT <", value, "NO_MEASURE_CNT");
            return (Criteria) this;
        }

        public Criteria andNO_MEASURE_CNTLessThanOrEqualTo(String value) {
            addCriterion("NO_MEASURE_CNT <=", value, "NO_MEASURE_CNT");
            return (Criteria) this;
        }

        public Criteria andNO_MEASURE_CNTLike(String value) {
            addCriterion("NO_MEASURE_CNT like", value, "NO_MEASURE_CNT");
            return (Criteria) this;
        }

        public Criteria andNO_MEASURE_CNTNotLike(String value) {
            addCriterion("NO_MEASURE_CNT not like", value, "NO_MEASURE_CNT");
            return (Criteria) this;
        }

        public Criteria andNO_MEASURE_CNTIn(List<String> values) {
            addCriterion("NO_MEASURE_CNT in", values, "NO_MEASURE_CNT");
            return (Criteria) this;
        }

        public Criteria andNO_MEASURE_CNTNotIn(List<String> values) {
            addCriterion("NO_MEASURE_CNT not in", values, "NO_MEASURE_CNT");
            return (Criteria) this;
        }

        public Criteria andNO_MEASURE_CNTBetween(String value1, String value2) {
            addCriterion("NO_MEASURE_CNT between", value1, value2, "NO_MEASURE_CNT");
            return (Criteria) this;
        }

        public Criteria andNO_MEASURE_CNTNotBetween(String value1, String value2) {
            addCriterion("NO_MEASURE_CNT not between", value1, value2, "NO_MEASURE_CNT");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNIsNull() {
            addCriterion("TAIKAN_KBN is null");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNIsNotNull() {
            addCriterion("TAIKAN_KBN is not null");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNEqualTo(String value) {
            addCriterion("TAIKAN_KBN =", value, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNNotEqualTo(String value) {
            addCriterion("TAIKAN_KBN <>", value, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNGreaterThan(String value) {
            addCriterion("TAIKAN_KBN >", value, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNGreaterThanOrEqualTo(String value) {
            addCriterion("TAIKAN_KBN >=", value, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNLessThan(String value) {
            addCriterion("TAIKAN_KBN <", value, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNLessThanOrEqualTo(String value) {
            addCriterion("TAIKAN_KBN <=", value, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNLike(String value) {
            addCriterion("TAIKAN_KBN like", value, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNNotLike(String value) {
            addCriterion("TAIKAN_KBN not like", value, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNIn(List<String> values) {
            addCriterion("TAIKAN_KBN in", values, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNNotIn(List<String> values) {
            addCriterion("TAIKAN_KBN not in", values, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNBetween(String value1, String value2) {
            addCriterion("TAIKAN_KBN between", value1, value2, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNNotBetween(String value1, String value2) {
            addCriterion("TAIKAN_KBN not between", value1, value2, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andJIAN_KINDIsNull() {
            addCriterion("JIAN_KIND is null");
            return (Criteria) this;
        }

        public Criteria andJIAN_KINDIsNotNull() {
            addCriterion("JIAN_KIND is not null");
            return (Criteria) this;
        }

        public Criteria andJIAN_KINDEqualTo(String value) {
            addCriterion("JIAN_KIND =", value, "JIAN_KIND");
            return (Criteria) this;
        }

        public Criteria andJIAN_KINDNotEqualTo(String value) {
            addCriterion("JIAN_KIND <>", value, "JIAN_KIND");
            return (Criteria) this;
        }

        public Criteria andJIAN_KINDGreaterThan(String value) {
            addCriterion("JIAN_KIND >", value, "JIAN_KIND");
            return (Criteria) this;
        }

        public Criteria andJIAN_KINDGreaterThanOrEqualTo(String value) {
            addCriterion("JIAN_KIND >=", value, "JIAN_KIND");
            return (Criteria) this;
        }

        public Criteria andJIAN_KINDLessThan(String value) {
            addCriterion("JIAN_KIND <", value, "JIAN_KIND");
            return (Criteria) this;
        }

        public Criteria andJIAN_KINDLessThanOrEqualTo(String value) {
            addCriterion("JIAN_KIND <=", value, "JIAN_KIND");
            return (Criteria) this;
        }

        public Criteria andJIAN_KINDLike(String value) {
            addCriterion("JIAN_KIND like", value, "JIAN_KIND");
            return (Criteria) this;
        }

        public Criteria andJIAN_KINDNotLike(String value) {
            addCriterion("JIAN_KIND not like", value, "JIAN_KIND");
            return (Criteria) this;
        }

        public Criteria andJIAN_KINDIn(List<String> values) {
            addCriterion("JIAN_KIND in", values, "JIAN_KIND");
            return (Criteria) this;
        }

        public Criteria andJIAN_KINDNotIn(List<String> values) {
            addCriterion("JIAN_KIND not in", values, "JIAN_KIND");
            return (Criteria) this;
        }

        public Criteria andJIAN_KINDBetween(String value1, String value2) {
            addCriterion("JIAN_KIND between", value1, value2, "JIAN_KIND");
            return (Criteria) this;
        }

        public Criteria andJIAN_KINDNotBetween(String value1, String value2) {
            addCriterion("JIAN_KIND not between", value1, value2, "JIAN_KIND");
            return (Criteria) this;
        }

        public Criteria andTAIOU_YOUHI_FLGIsNull() {
            addCriterion("TAIOU_YOUHI_FLG is null");
            return (Criteria) this;
        }

        public Criteria andTAIOU_YOUHI_FLGIsNotNull() {
            addCriterion("TAIOU_YOUHI_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andTAIOU_YOUHI_FLGEqualTo(String value) {
            addCriterion("TAIOU_YOUHI_FLG =", value, "TAIOU_YOUHI_FLG");
            return (Criteria) this;
        }

        public Criteria andTAIOU_YOUHI_FLGNotEqualTo(String value) {
            addCriterion("TAIOU_YOUHI_FLG <>", value, "TAIOU_YOUHI_FLG");
            return (Criteria) this;
        }

        public Criteria andTAIOU_YOUHI_FLGGreaterThan(String value) {
            addCriterion("TAIOU_YOUHI_FLG >", value, "TAIOU_YOUHI_FLG");
            return (Criteria) this;
        }

        public Criteria andTAIOU_YOUHI_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("TAIOU_YOUHI_FLG >=", value, "TAIOU_YOUHI_FLG");
            return (Criteria) this;
        }

        public Criteria andTAIOU_YOUHI_FLGLessThan(String value) {
            addCriterion("TAIOU_YOUHI_FLG <", value, "TAIOU_YOUHI_FLG");
            return (Criteria) this;
        }

        public Criteria andTAIOU_YOUHI_FLGLessThanOrEqualTo(String value) {
            addCriterion("TAIOU_YOUHI_FLG <=", value, "TAIOU_YOUHI_FLG");
            return (Criteria) this;
        }

        public Criteria andTAIOU_YOUHI_FLGLike(String value) {
            addCriterion("TAIOU_YOUHI_FLG like", value, "TAIOU_YOUHI_FLG");
            return (Criteria) this;
        }

        public Criteria andTAIOU_YOUHI_FLGNotLike(String value) {
            addCriterion("TAIOU_YOUHI_FLG not like", value, "TAIOU_YOUHI_FLG");
            return (Criteria) this;
        }

        public Criteria andTAIOU_YOUHI_FLGIn(List<String> values) {
            addCriterion("TAIOU_YOUHI_FLG in", values, "TAIOU_YOUHI_FLG");
            return (Criteria) this;
        }

        public Criteria andTAIOU_YOUHI_FLGNotIn(List<String> values) {
            addCriterion("TAIOU_YOUHI_FLG not in", values, "TAIOU_YOUHI_FLG");
            return (Criteria) this;
        }

        public Criteria andTAIOU_YOUHI_FLGBetween(String value1, String value2) {
            addCriterion("TAIOU_YOUHI_FLG between", value1, value2, "TAIOU_YOUHI_FLG");
            return (Criteria) this;
        }

        public Criteria andTAIOU_YOUHI_FLGNotBetween(String value1, String value2) {
            addCriterion("TAIOU_YOUHI_FLG not between", value1, value2, "TAIOU_YOUHI_FLG");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMER_ENT_TMIsNull() {
            addCriterion("JITAI_TIMER_ENT_TM is null");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMER_ENT_TMIsNotNull() {
            addCriterion("JITAI_TIMER_ENT_TM is not null");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMER_ENT_TMEqualTo(String value) {
            addCriterion("JITAI_TIMER_ENT_TM =", value, "JITAI_TIMER_ENT_TM");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMER_ENT_TMNotEqualTo(String value) {
            addCriterion("JITAI_TIMER_ENT_TM <>", value, "JITAI_TIMER_ENT_TM");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMER_ENT_TMGreaterThan(String value) {
            addCriterion("JITAI_TIMER_ENT_TM >", value, "JITAI_TIMER_ENT_TM");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMER_ENT_TMGreaterThanOrEqualTo(String value) {
            addCriterion("JITAI_TIMER_ENT_TM >=", value, "JITAI_TIMER_ENT_TM");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMER_ENT_TMLessThan(String value) {
            addCriterion("JITAI_TIMER_ENT_TM <", value, "JITAI_TIMER_ENT_TM");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMER_ENT_TMLessThanOrEqualTo(String value) {
            addCriterion("JITAI_TIMER_ENT_TM <=", value, "JITAI_TIMER_ENT_TM");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMER_ENT_TMLike(String value) {
            addCriterion("JITAI_TIMER_ENT_TM like", value, "JITAI_TIMER_ENT_TM");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMER_ENT_TMNotLike(String value) {
            addCriterion("JITAI_TIMER_ENT_TM not like", value, "JITAI_TIMER_ENT_TM");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMER_ENT_TMIn(List<String> values) {
            addCriterion("JITAI_TIMER_ENT_TM in", values, "JITAI_TIMER_ENT_TM");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMER_ENT_TMNotIn(List<String> values) {
            addCriterion("JITAI_TIMER_ENT_TM not in", values, "JITAI_TIMER_ENT_TM");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMER_ENT_TMBetween(String value1, String value2) {
            addCriterion("JITAI_TIMER_ENT_TM between", value1, value2, "JITAI_TIMER_ENT_TM");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMER_ENT_TMNotBetween(String value1, String value2) {
            addCriterion("JITAI_TIMER_ENT_TM not between", value1, value2, "JITAI_TIMER_ENT_TM");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMEOUT_TMIsNull() {
            addCriterion("JITAI_TIMEOUT_TM is null");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMEOUT_TMIsNotNull() {
            addCriterion("JITAI_TIMEOUT_TM is not null");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMEOUT_TMEqualTo(String value) {
            addCriterion("JITAI_TIMEOUT_TM =", value, "JITAI_TIMEOUT_TM");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMEOUT_TMNotEqualTo(String value) {
            addCriterion("JITAI_TIMEOUT_TM <>", value, "JITAI_TIMEOUT_TM");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMEOUT_TMGreaterThan(String value) {
            addCriterion("JITAI_TIMEOUT_TM >", value, "JITAI_TIMEOUT_TM");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMEOUT_TMGreaterThanOrEqualTo(String value) {
            addCriterion("JITAI_TIMEOUT_TM >=", value, "JITAI_TIMEOUT_TM");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMEOUT_TMLessThan(String value) {
            addCriterion("JITAI_TIMEOUT_TM <", value, "JITAI_TIMEOUT_TM");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMEOUT_TMLessThanOrEqualTo(String value) {
            addCriterion("JITAI_TIMEOUT_TM <=", value, "JITAI_TIMEOUT_TM");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMEOUT_TMLike(String value) {
            addCriterion("JITAI_TIMEOUT_TM like", value, "JITAI_TIMEOUT_TM");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMEOUT_TMNotLike(String value) {
            addCriterion("JITAI_TIMEOUT_TM not like", value, "JITAI_TIMEOUT_TM");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMEOUT_TMIn(List<String> values) {
            addCriterion("JITAI_TIMEOUT_TM in", values, "JITAI_TIMEOUT_TM");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMEOUT_TMNotIn(List<String> values) {
            addCriterion("JITAI_TIMEOUT_TM not in", values, "JITAI_TIMEOUT_TM");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMEOUT_TMBetween(String value1, String value2) {
            addCriterion("JITAI_TIMEOUT_TM between", value1, value2, "JITAI_TIMEOUT_TM");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMEOUT_TMNotBetween(String value1, String value2) {
            addCriterion("JITAI_TIMEOUT_TM not between", value1, value2, "JITAI_TIMEOUT_TM");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOU_TOIsNull() {
            addCriterion("TIMER_CHOKKOU_TO is null");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOU_TOIsNotNull() {
            addCriterion("TIMER_CHOKKOU_TO is not null");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOU_TOEqualTo(String value) {
            addCriterion("TIMER_CHOKKOU_TO =", value, "TIMER_CHOKKOU_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOU_TONotEqualTo(String value) {
            addCriterion("TIMER_CHOKKOU_TO <>", value, "TIMER_CHOKKOU_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOU_TOGreaterThan(String value) {
            addCriterion("TIMER_CHOKKOU_TO >", value, "TIMER_CHOKKOU_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOU_TOGreaterThanOrEqualTo(String value) {
            addCriterion("TIMER_CHOKKOU_TO >=", value, "TIMER_CHOKKOU_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOU_TOLessThan(String value) {
            addCriterion("TIMER_CHOKKOU_TO <", value, "TIMER_CHOKKOU_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOU_TOLessThanOrEqualTo(String value) {
            addCriterion("TIMER_CHOKKOU_TO <=", value, "TIMER_CHOKKOU_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOU_TOLike(String value) {
            addCriterion("TIMER_CHOKKOU_TO like", value, "TIMER_CHOKKOU_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOU_TONotLike(String value) {
            addCriterion("TIMER_CHOKKOU_TO not like", value, "TIMER_CHOKKOU_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOU_TOIn(List<String> values) {
            addCriterion("TIMER_CHOKKOU_TO in", values, "TIMER_CHOKKOU_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOU_TONotIn(List<String> values) {
            addCriterion("TIMER_CHOKKOU_TO not in", values, "TIMER_CHOKKOU_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOU_TOBetween(String value1, String value2) {
            addCriterion("TIMER_CHOKKOU_TO between", value1, value2, "TIMER_CHOKKOU_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOU_TONotBetween(String value1, String value2) {
            addCriterion("TIMER_CHOKKOU_TO not between", value1, value2, "TIMER_CHOKKOU_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKU_TOIsNull() {
            addCriterion("TIMER_GENCHAKU_TO is null");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKU_TOIsNotNull() {
            addCriterion("TIMER_GENCHAKU_TO is not null");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKU_TOEqualTo(String value) {
            addCriterion("TIMER_GENCHAKU_TO =", value, "TIMER_GENCHAKU_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKU_TONotEqualTo(String value) {
            addCriterion("TIMER_GENCHAKU_TO <>", value, "TIMER_GENCHAKU_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKU_TOGreaterThan(String value) {
            addCriterion("TIMER_GENCHAKU_TO >", value, "TIMER_GENCHAKU_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKU_TOGreaterThanOrEqualTo(String value) {
            addCriterion("TIMER_GENCHAKU_TO >=", value, "TIMER_GENCHAKU_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKU_TOLessThan(String value) {
            addCriterion("TIMER_GENCHAKU_TO <", value, "TIMER_GENCHAKU_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKU_TOLessThanOrEqualTo(String value) {
            addCriterion("TIMER_GENCHAKU_TO <=", value, "TIMER_GENCHAKU_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKU_TOLike(String value) {
            addCriterion("TIMER_GENCHAKU_TO like", value, "TIMER_GENCHAKU_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKU_TONotLike(String value) {
            addCriterion("TIMER_GENCHAKU_TO not like", value, "TIMER_GENCHAKU_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKU_TOIn(List<String> values) {
            addCriterion("TIMER_GENCHAKU_TO in", values, "TIMER_GENCHAKU_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKU_TONotIn(List<String> values) {
            addCriterion("TIMER_GENCHAKU_TO not in", values, "TIMER_GENCHAKU_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKU_TOBetween(String value1, String value2) {
            addCriterion("TIMER_GENCHAKU_TO between", value1, value2, "TIMER_GENCHAKU_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKU_TONotBetween(String value1, String value2) {
            addCriterion("TIMER_GENCHAKU_TO not between", value1, value2, "TIMER_GENCHAKU_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKAN_TOIsNull() {
            addCriterion("TIMER_NYUUKAN_TO is null");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKAN_TOIsNotNull() {
            addCriterion("TIMER_NYUUKAN_TO is not null");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKAN_TOEqualTo(String value) {
            addCriterion("TIMER_NYUUKAN_TO =", value, "TIMER_NYUUKAN_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKAN_TONotEqualTo(String value) {
            addCriterion("TIMER_NYUUKAN_TO <>", value, "TIMER_NYUUKAN_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKAN_TOGreaterThan(String value) {
            addCriterion("TIMER_NYUUKAN_TO >", value, "TIMER_NYUUKAN_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKAN_TOGreaterThanOrEqualTo(String value) {
            addCriterion("TIMER_NYUUKAN_TO >=", value, "TIMER_NYUUKAN_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKAN_TOLessThan(String value) {
            addCriterion("TIMER_NYUUKAN_TO <", value, "TIMER_NYUUKAN_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKAN_TOLessThanOrEqualTo(String value) {
            addCriterion("TIMER_NYUUKAN_TO <=", value, "TIMER_NYUUKAN_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKAN_TOLike(String value) {
            addCriterion("TIMER_NYUUKAN_TO like", value, "TIMER_NYUUKAN_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKAN_TONotLike(String value) {
            addCriterion("TIMER_NYUUKAN_TO not like", value, "TIMER_NYUUKAN_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKAN_TOIn(List<String> values) {
            addCriterion("TIMER_NYUUKAN_TO in", values, "TIMER_NYUUKAN_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKAN_TONotIn(List<String> values) {
            addCriterion("TIMER_NYUUKAN_TO not in", values, "TIMER_NYUUKAN_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKAN_TOBetween(String value1, String value2) {
            addCriterion("TIMER_NYUUKAN_TO between", value1, value2, "TIMER_NYUUKAN_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKAN_TONotBetween(String value1, String value2) {
            addCriterion("TIMER_NYUUKAN_TO not between", value1, value2, "TIMER_NYUUKAN_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKAN_TOIsNull() {
            addCriterion("TIMER_TAIKAN_TO is null");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKAN_TOIsNotNull() {
            addCriterion("TIMER_TAIKAN_TO is not null");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKAN_TOEqualTo(String value) {
            addCriterion("TIMER_TAIKAN_TO =", value, "TIMER_TAIKAN_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKAN_TONotEqualTo(String value) {
            addCriterion("TIMER_TAIKAN_TO <>", value, "TIMER_TAIKAN_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKAN_TOGreaterThan(String value) {
            addCriterion("TIMER_TAIKAN_TO >", value, "TIMER_TAIKAN_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKAN_TOGreaterThanOrEqualTo(String value) {
            addCriterion("TIMER_TAIKAN_TO >=", value, "TIMER_TAIKAN_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKAN_TOLessThan(String value) {
            addCriterion("TIMER_TAIKAN_TO <", value, "TIMER_TAIKAN_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKAN_TOLessThanOrEqualTo(String value) {
            addCriterion("TIMER_TAIKAN_TO <=", value, "TIMER_TAIKAN_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKAN_TOLike(String value) {
            addCriterion("TIMER_TAIKAN_TO like", value, "TIMER_TAIKAN_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKAN_TONotLike(String value) {
            addCriterion("TIMER_TAIKAN_TO not like", value, "TIMER_TAIKAN_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKAN_TOIn(List<String> values) {
            addCriterion("TIMER_TAIKAN_TO in", values, "TIMER_TAIKAN_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKAN_TONotIn(List<String> values) {
            addCriterion("TIMER_TAIKAN_TO not in", values, "TIMER_TAIKAN_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKAN_TOBetween(String value1, String value2) {
            addCriterion("TIMER_TAIKAN_TO between", value1, value2, "TIMER_TAIKAN_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKAN_TONotBetween(String value1, String value2) {
            addCriterion("TIMER_TAIKAN_TO not between", value1, value2, "TIMER_TAIKAN_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_END_TOIsNull() {
            addCriterion("TIMER_END_TO is null");
            return (Criteria) this;
        }

        public Criteria andTIMER_END_TOIsNotNull() {
            addCriterion("TIMER_END_TO is not null");
            return (Criteria) this;
        }

        public Criteria andTIMER_END_TOEqualTo(String value) {
            addCriterion("TIMER_END_TO =", value, "TIMER_END_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_END_TONotEqualTo(String value) {
            addCriterion("TIMER_END_TO <>", value, "TIMER_END_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_END_TOGreaterThan(String value) {
            addCriterion("TIMER_END_TO >", value, "TIMER_END_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_END_TOGreaterThanOrEqualTo(String value) {
            addCriterion("TIMER_END_TO >=", value, "TIMER_END_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_END_TOLessThan(String value) {
            addCriterion("TIMER_END_TO <", value, "TIMER_END_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_END_TOLessThanOrEqualTo(String value) {
            addCriterion("TIMER_END_TO <=", value, "TIMER_END_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_END_TOLike(String value) {
            addCriterion("TIMER_END_TO like", value, "TIMER_END_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_END_TONotLike(String value) {
            addCriterion("TIMER_END_TO not like", value, "TIMER_END_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_END_TOIn(List<String> values) {
            addCriterion("TIMER_END_TO in", values, "TIMER_END_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_END_TONotIn(List<String> values) {
            addCriterion("TIMER_END_TO not in", values, "TIMER_END_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_END_TOBetween(String value1, String value2) {
            addCriterion("TIMER_END_TO between", value1, value2, "TIMER_END_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_END_TONotBetween(String value1, String value2) {
            addCriterion("TIMER_END_TO not between", value1, value2, "TIMER_END_TO");
            return (Criteria) this;
        }

        public Criteria andSIG_PRIORITYIsNull() {
            addCriterion("SIG_PRIORITY is null");
            return (Criteria) this;
        }

        public Criteria andSIG_PRIORITYIsNotNull() {
            addCriterion("SIG_PRIORITY is not null");
            return (Criteria) this;
        }

        public Criteria andSIG_PRIORITYEqualTo(String value) {
            addCriterion("SIG_PRIORITY =", value, "SIG_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andSIG_PRIORITYNotEqualTo(String value) {
            addCriterion("SIG_PRIORITY <>", value, "SIG_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andSIG_PRIORITYGreaterThan(String value) {
            addCriterion("SIG_PRIORITY >", value, "SIG_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andSIG_PRIORITYGreaterThanOrEqualTo(String value) {
            addCriterion("SIG_PRIORITY >=", value, "SIG_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andSIG_PRIORITYLessThan(String value) {
            addCriterion("SIG_PRIORITY <", value, "SIG_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andSIG_PRIORITYLessThanOrEqualTo(String value) {
            addCriterion("SIG_PRIORITY <=", value, "SIG_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andSIG_PRIORITYLike(String value) {
            addCriterion("SIG_PRIORITY like", value, "SIG_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andSIG_PRIORITYNotLike(String value) {
            addCriterion("SIG_PRIORITY not like", value, "SIG_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andSIG_PRIORITYIn(List<String> values) {
            addCriterion("SIG_PRIORITY in", values, "SIG_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andSIG_PRIORITYNotIn(List<String> values) {
            addCriterion("SIG_PRIORITY not in", values, "SIG_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andSIG_PRIORITYBetween(String value1, String value2) {
            addCriterion("SIG_PRIORITY between", value1, value2, "SIG_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andSIG_PRIORITYNotBetween(String value1, String value2) {
            addCriterion("SIG_PRIORITY not between", value1, value2, "SIG_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andSIG_1_RCV_TIMEIsNull() {
            addCriterion("SIG_1_RCV_TIME is null");
            return (Criteria) this;
        }

        public Criteria andSIG_1_RCV_TIMEIsNotNull() {
            addCriterion("SIG_1_RCV_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andSIG_1_RCV_TIMEEqualTo(String value) {
            addCriterion("SIG_1_RCV_TIME =", value, "SIG_1_RCV_TIME");
            return (Criteria) this;
        }

        public Criteria andSIG_1_RCV_TIMENotEqualTo(String value) {
            addCriterion("SIG_1_RCV_TIME <>", value, "SIG_1_RCV_TIME");
            return (Criteria) this;
        }

        public Criteria andSIG_1_RCV_TIMEGreaterThan(String value) {
            addCriterion("SIG_1_RCV_TIME >", value, "SIG_1_RCV_TIME");
            return (Criteria) this;
        }

        public Criteria andSIG_1_RCV_TIMEGreaterThanOrEqualTo(String value) {
            addCriterion("SIG_1_RCV_TIME >=", value, "SIG_1_RCV_TIME");
            return (Criteria) this;
        }

        public Criteria andSIG_1_RCV_TIMELessThan(String value) {
            addCriterion("SIG_1_RCV_TIME <", value, "SIG_1_RCV_TIME");
            return (Criteria) this;
        }

        public Criteria andSIG_1_RCV_TIMELessThanOrEqualTo(String value) {
            addCriterion("SIG_1_RCV_TIME <=", value, "SIG_1_RCV_TIME");
            return (Criteria) this;
        }

        public Criteria andSIG_1_RCV_TIMELike(String value) {
            addCriterion("SIG_1_RCV_TIME like", value, "SIG_1_RCV_TIME");
            return (Criteria) this;
        }

        public Criteria andSIG_1_RCV_TIMENotLike(String value) {
            addCriterion("SIG_1_RCV_TIME not like", value, "SIG_1_RCV_TIME");
            return (Criteria) this;
        }

        public Criteria andSIG_1_RCV_TIMEIn(List<String> values) {
            addCriterion("SIG_1_RCV_TIME in", values, "SIG_1_RCV_TIME");
            return (Criteria) this;
        }

        public Criteria andSIG_1_RCV_TIMENotIn(List<String> values) {
            addCriterion("SIG_1_RCV_TIME not in", values, "SIG_1_RCV_TIME");
            return (Criteria) this;
        }

        public Criteria andSIG_1_RCV_TIMEBetween(String value1, String value2) {
            addCriterion("SIG_1_RCV_TIME between", value1, value2, "SIG_1_RCV_TIME");
            return (Criteria) this;
        }

        public Criteria andSIG_1_RCV_TIMENotBetween(String value1, String value2) {
            addCriterion("SIG_1_RCV_TIME not between", value1, value2, "SIG_1_RCV_TIME");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNG_MARKIsNull() {
            addCriterion("SOCHI_CNG_MARK is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNG_MARKIsNotNull() {
            addCriterion("SOCHI_CNG_MARK is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNG_MARKEqualTo(String value) {
            addCriterion("SOCHI_CNG_MARK =", value, "SOCHI_CNG_MARK");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNG_MARKNotEqualTo(String value) {
            addCriterion("SOCHI_CNG_MARK <>", value, "SOCHI_CNG_MARK");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNG_MARKGreaterThan(String value) {
            addCriterion("SOCHI_CNG_MARK >", value, "SOCHI_CNG_MARK");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNG_MARKGreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_CNG_MARK >=", value, "SOCHI_CNG_MARK");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNG_MARKLessThan(String value) {
            addCriterion("SOCHI_CNG_MARK <", value, "SOCHI_CNG_MARK");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNG_MARKLessThanOrEqualTo(String value) {
            addCriterion("SOCHI_CNG_MARK <=", value, "SOCHI_CNG_MARK");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNG_MARKLike(String value) {
            addCriterion("SOCHI_CNG_MARK like", value, "SOCHI_CNG_MARK");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNG_MARKNotLike(String value) {
            addCriterion("SOCHI_CNG_MARK not like", value, "SOCHI_CNG_MARK");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNG_MARKIn(List<String> values) {
            addCriterion("SOCHI_CNG_MARK in", values, "SOCHI_CNG_MARK");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNG_MARKNotIn(List<String> values) {
            addCriterion("SOCHI_CNG_MARK not in", values, "SOCHI_CNG_MARK");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNG_MARKBetween(String value1, String value2) {
            addCriterion("SOCHI_CNG_MARK between", value1, value2, "SOCHI_CNG_MARK");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNG_MARKNotBetween(String value1, String value2) {
            addCriterion("SOCHI_CNG_MARK not between", value1, value2, "SOCHI_CNG_MARK");
            return (Criteria) this;
        }

        public Criteria andSUB_KASI_FLGIsNull() {
            addCriterion("SUB_KASI_FLG is null");
            return (Criteria) this;
        }

        public Criteria andSUB_KASI_FLGIsNotNull() {
            addCriterion("SUB_KASI_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andSUB_KASI_FLGEqualTo(String value) {
            addCriterion("SUB_KASI_FLG =", value, "SUB_KASI_FLG");
            return (Criteria) this;
        }

        public Criteria andSUB_KASI_FLGNotEqualTo(String value) {
            addCriterion("SUB_KASI_FLG <>", value, "SUB_KASI_FLG");
            return (Criteria) this;
        }

        public Criteria andSUB_KASI_FLGGreaterThan(String value) {
            addCriterion("SUB_KASI_FLG >", value, "SUB_KASI_FLG");
            return (Criteria) this;
        }

        public Criteria andSUB_KASI_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("SUB_KASI_FLG >=", value, "SUB_KASI_FLG");
            return (Criteria) this;
        }

        public Criteria andSUB_KASI_FLGLessThan(String value) {
            addCriterion("SUB_KASI_FLG <", value, "SUB_KASI_FLG");
            return (Criteria) this;
        }

        public Criteria andSUB_KASI_FLGLessThanOrEqualTo(String value) {
            addCriterion("SUB_KASI_FLG <=", value, "SUB_KASI_FLG");
            return (Criteria) this;
        }

        public Criteria andSUB_KASI_FLGLike(String value) {
            addCriterion("SUB_KASI_FLG like", value, "SUB_KASI_FLG");
            return (Criteria) this;
        }

        public Criteria andSUB_KASI_FLGNotLike(String value) {
            addCriterion("SUB_KASI_FLG not like", value, "SUB_KASI_FLG");
            return (Criteria) this;
        }

        public Criteria andSUB_KASI_FLGIn(List<String> values) {
            addCriterion("SUB_KASI_FLG in", values, "SUB_KASI_FLG");
            return (Criteria) this;
        }

        public Criteria andSUB_KASI_FLGNotIn(List<String> values) {
            addCriterion("SUB_KASI_FLG not in", values, "SUB_KASI_FLG");
            return (Criteria) this;
        }

        public Criteria andSUB_KASI_FLGBetween(String value1, String value2) {
            addCriterion("SUB_KASI_FLG between", value1, value2, "SUB_KASI_FLG");
            return (Criteria) this;
        }

        public Criteria andSUB_KASI_FLGNotBetween(String value1, String value2) {
            addCriterion("SUB_KASI_FLG not between", value1, value2, "SUB_KASI_FLG");
            return (Criteria) this;
        }

        public Criteria andRAK_FLGIsNull() {
            addCriterion("RAK_FLG is null");
            return (Criteria) this;
        }

        public Criteria andRAK_FLGIsNotNull() {
            addCriterion("RAK_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andRAK_FLGEqualTo(String value) {
            addCriterion("RAK_FLG =", value, "RAK_FLG");
            return (Criteria) this;
        }

        public Criteria andRAK_FLGNotEqualTo(String value) {
            addCriterion("RAK_FLG <>", value, "RAK_FLG");
            return (Criteria) this;
        }

        public Criteria andRAK_FLGGreaterThan(String value) {
            addCriterion("RAK_FLG >", value, "RAK_FLG");
            return (Criteria) this;
        }

        public Criteria andRAK_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("RAK_FLG >=", value, "RAK_FLG");
            return (Criteria) this;
        }

        public Criteria andRAK_FLGLessThan(String value) {
            addCriterion("RAK_FLG <", value, "RAK_FLG");
            return (Criteria) this;
        }

        public Criteria andRAK_FLGLessThanOrEqualTo(String value) {
            addCriterion("RAK_FLG <=", value, "RAK_FLG");
            return (Criteria) this;
        }

        public Criteria andRAK_FLGLike(String value) {
            addCriterion("RAK_FLG like", value, "RAK_FLG");
            return (Criteria) this;
        }

        public Criteria andRAK_FLGNotLike(String value) {
            addCriterion("RAK_FLG not like", value, "RAK_FLG");
            return (Criteria) this;
        }

        public Criteria andRAK_FLGIn(List<String> values) {
            addCriterion("RAK_FLG in", values, "RAK_FLG");
            return (Criteria) this;
        }

        public Criteria andRAK_FLGNotIn(List<String> values) {
            addCriterion("RAK_FLG not in", values, "RAK_FLG");
            return (Criteria) this;
        }

        public Criteria andRAK_FLGBetween(String value1, String value2) {
            addCriterion("RAK_FLG between", value1, value2, "RAK_FLG");
            return (Criteria) this;
        }

        public Criteria andRAK_FLGNotBetween(String value1, String value2) {
            addCriterion("RAK_FLG not between", value1, value2, "RAK_FLG");
            return (Criteria) this;
        }

        public Criteria andCANCEL_NTY_FLGIsNull() {
            addCriterion("CANCEL_NTY_FLG is null");
            return (Criteria) this;
        }

        public Criteria andCANCEL_NTY_FLGIsNotNull() {
            addCriterion("CANCEL_NTY_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andCANCEL_NTY_FLGEqualTo(String value) {
            addCriterion("CANCEL_NTY_FLG =", value, "CANCEL_NTY_FLG");
            return (Criteria) this;
        }

        public Criteria andCANCEL_NTY_FLGNotEqualTo(String value) {
            addCriterion("CANCEL_NTY_FLG <>", value, "CANCEL_NTY_FLG");
            return (Criteria) this;
        }

        public Criteria andCANCEL_NTY_FLGGreaterThan(String value) {
            addCriterion("CANCEL_NTY_FLG >", value, "CANCEL_NTY_FLG");
            return (Criteria) this;
        }

        public Criteria andCANCEL_NTY_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("CANCEL_NTY_FLG >=", value, "CANCEL_NTY_FLG");
            return (Criteria) this;
        }

        public Criteria andCANCEL_NTY_FLGLessThan(String value) {
            addCriterion("CANCEL_NTY_FLG <", value, "CANCEL_NTY_FLG");
            return (Criteria) this;
        }

        public Criteria andCANCEL_NTY_FLGLessThanOrEqualTo(String value) {
            addCriterion("CANCEL_NTY_FLG <=", value, "CANCEL_NTY_FLG");
            return (Criteria) this;
        }

        public Criteria andCANCEL_NTY_FLGLike(String value) {
            addCriterion("CANCEL_NTY_FLG like", value, "CANCEL_NTY_FLG");
            return (Criteria) this;
        }

        public Criteria andCANCEL_NTY_FLGNotLike(String value) {
            addCriterion("CANCEL_NTY_FLG not like", value, "CANCEL_NTY_FLG");
            return (Criteria) this;
        }

        public Criteria andCANCEL_NTY_FLGIn(List<String> values) {
            addCriterion("CANCEL_NTY_FLG in", values, "CANCEL_NTY_FLG");
            return (Criteria) this;
        }

        public Criteria andCANCEL_NTY_FLGNotIn(List<String> values) {
            addCriterion("CANCEL_NTY_FLG not in", values, "CANCEL_NTY_FLG");
            return (Criteria) this;
        }

        public Criteria andCANCEL_NTY_FLGBetween(String value1, String value2) {
            addCriterion("CANCEL_NTY_FLG between", value1, value2, "CANCEL_NTY_FLG");
            return (Criteria) this;
        }

        public Criteria andCANCEL_NTY_FLGNotBetween(String value1, String value2) {
            addCriterion("CANCEL_NTY_FLG not between", value1, value2, "CANCEL_NTY_FLG");
            return (Criteria) this;
        }

        public Criteria andHONNIN_FLGIsNull() {
            addCriterion("HONNIN_FLG is null");
            return (Criteria) this;
        }

        public Criteria andHONNIN_FLGIsNotNull() {
            addCriterion("HONNIN_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andHONNIN_FLGEqualTo(String value) {
            addCriterion("HONNIN_FLG =", value, "HONNIN_FLG");
            return (Criteria) this;
        }

        public Criteria andHONNIN_FLGNotEqualTo(String value) {
            addCriterion("HONNIN_FLG <>", value, "HONNIN_FLG");
            return (Criteria) this;
        }

        public Criteria andHONNIN_FLGGreaterThan(String value) {
            addCriterion("HONNIN_FLG >", value, "HONNIN_FLG");
            return (Criteria) this;
        }

        public Criteria andHONNIN_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("HONNIN_FLG >=", value, "HONNIN_FLG");
            return (Criteria) this;
        }

        public Criteria andHONNIN_FLGLessThan(String value) {
            addCriterion("HONNIN_FLG <", value, "HONNIN_FLG");
            return (Criteria) this;
        }

        public Criteria andHONNIN_FLGLessThanOrEqualTo(String value) {
            addCriterion("HONNIN_FLG <=", value, "HONNIN_FLG");
            return (Criteria) this;
        }

        public Criteria andHONNIN_FLGLike(String value) {
            addCriterion("HONNIN_FLG like", value, "HONNIN_FLG");
            return (Criteria) this;
        }

        public Criteria andHONNIN_FLGNotLike(String value) {
            addCriterion("HONNIN_FLG not like", value, "HONNIN_FLG");
            return (Criteria) this;
        }

        public Criteria andHONNIN_FLGIn(List<String> values) {
            addCriterion("HONNIN_FLG in", values, "HONNIN_FLG");
            return (Criteria) this;
        }

        public Criteria andHONNIN_FLGNotIn(List<String> values) {
            addCriterion("HONNIN_FLG not in", values, "HONNIN_FLG");
            return (Criteria) this;
        }

        public Criteria andHONNIN_FLGBetween(String value1, String value2) {
            addCriterion("HONNIN_FLG between", value1, value2, "HONNIN_FLG");
            return (Criteria) this;
        }

        public Criteria andHONNIN_FLGNotBetween(String value1, String value2) {
            addCriterion("HONNIN_FLG not between", value1, value2, "HONNIN_FLG");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSIsNull() {
            addCriterion("LASTUPD_TS is null");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSIsNotNull() {
            addCriterion("LASTUPD_TS is not null");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSEqualTo(Date value) {
            addCriterion("LASTUPD_TS =", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSNotEqualTo(Date value) {
            addCriterion("LASTUPD_TS <>", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSGreaterThan(Date value) {
            addCriterion("LASTUPD_TS >", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("LASTUPD_TS >=", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSLessThan(Date value) {
            addCriterion("LASTUPD_TS <", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSLessThanOrEqualTo(Date value) {
            addCriterion("LASTUPD_TS <=", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSIn(List<Date> values) {
            addCriterion("LASTUPD_TS in", values, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSNotIn(List<Date> values) {
            addCriterion("LASTUPD_TS not in", values, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSBetween(Date value1, Date value2) {
            addCriterion("LASTUPD_TS between", value1, value2, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSNotBetween(Date value1, Date value2) {
            addCriterion("LASTUPD_TS not between", value1, value2, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andGC_NUMLikeInsensitive(String value) {
            addCriterion("upper(GC_NUM) like", value.toUpperCase(), "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_SGSLikeInsensitive(String value) {
            addCriterion("upper(LN_SGS) like", value.toUpperCase(), "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andGOUKILikeInsensitive(String value) {
            addCriterion("upper(GOUKI) like", value.toUpperCase(), "GOUKI");
            return (Criteria) this;
        }

        public Criteria andDENKEILikeInsensitive(String value) {
            addCriterion("upper(DENKEI) like", value.toUpperCase(), "DENKEI");
            return (Criteria) this;
        }

        public Criteria andSUBADDRLikeInsensitive(String value) {
            addCriterion("upper(SUBADDR) like", value.toUpperCase(), "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDLikeInsensitive(String value) {
            addCriterion("upper(KEIYAKU_ID) like", value.toUpperCase(), "KEIYAKU_ID");
            return (Criteria) this;
        }

        public Criteria andHASSEI_IDLikeInsensitive(String value) {
            addCriterion("upper(HASSEI_ID) like", value.toUpperCase(), "HASSEI_ID");
            return (Criteria) this;
        }

        public Criteria andCOURSE_NUMLikeInsensitive(String value) {
            addCriterion("upper(COURSE_NUM) like", value.toUpperCase(), "COURSE_NUM");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_1LikeInsensitive(String value) {
            addCriterion("upper(KEIBI_NM_1) like", value.toUpperCase(), "KEIBI_NM_1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM_2LikeInsensitive(String value) {
            addCriterion("upper(KEIBI_NM_2) like", value.toUpperCase(), "KEIBI_NM_2");
            return (Criteria) this;
        }

        public Criteria andABBR_NMLikeInsensitive(String value) {
            addCriterion("upper(ABBR_NM) like", value.toUpperCase(), "ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andADDR_CDLikeInsensitive(String value) {
            addCriterion("upper(ADDR_CD) like", value.toUpperCase(), "ADDR_CD");
            return (Criteria) this;
        }

        public Criteria andKEISATULikeInsensitive(String value) {
            addCriterion("upper(KEISATU) like", value.toUpperCase(), "KEISATU");
            return (Criteria) this;
        }

        public Criteria andSYOUBOU_FLGLikeInsensitive(String value) {
            addCriterion("upper(SYOUBOU_FLG) like", value.toUpperCase(), "SYOUBOU_FLG");
            return (Criteria) this;
        }

        public Criteria andSOK_KBLikeInsensitive(String value) {
            addCriterion("upper(SOK_KB) like", value.toUpperCase(), "SOK_KB");
            return (Criteria) this;
        }

        public Criteria andSYUKKIN_KBNLikeInsensitive(String value) {
            addCriterion("upper(SYUKKIN_KBN) like", value.toUpperCase(), "SYUKKIN_KBN");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKLikeInsensitive(String value) {
            addCriterion("upper(OUEN_MARK) like", value.toUpperCase(), "OUEN_MARK");
            return (Criteria) this;
        }

        public Criteria andUKE_SEKILikeInsensitive(String value) {
            addCriterion("upper(UKE_SEKI) like", value.toUpperCase(), "UKE_SEKI");
            return (Criteria) this;
        }

        public Criteria andTANTOU_SEKILikeInsensitive(String value) {
            addCriterion("upper(TANTOU_SEKI) like", value.toUpperCase(), "TANTOU_SEKI");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDLikeInsensitive(String value) {
            addCriterion("upper(JITAI_CD) like", value.toUpperCase(), "JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSLikeInsensitive(String value) {
            addCriterion("upper(HASSEI_TS) like", value.toUpperCase(), "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_CNTLikeInsensitive(String value) {
            addCriterion("upper(KEIHOU_CNT) like", value.toUpperCase(), "KEIHOU_CNT");
            return (Criteria) this;
        }

        public Criteria andTS_1LikeInsensitive(String value) {
            addCriterion("upper(TS_1) like", value.toUpperCase(), "TS_1");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_1LikeInsensitive(String value) {
            addCriterion("upper(HASSEI_TS_1) like", value.toUpperCase(), "HASSEI_TS_1");
            return (Criteria) this;
        }

        public Criteria andSYANAI_1_CDLikeInsensitive(String value) {
            addCriterion("upper(SYANAI_1_CD) like", value.toUpperCase(), "SYANAI_1_CD");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_1LikeInsensitive(String value) {
            addCriterion("upper(KEIBI_SIG_1) like", value.toUpperCase(), "KEIBI_SIG_1");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_1LikeInsensitive(String value) {
            addCriterion("upper(SIG_KIND_1) like", value.toUpperCase(), "SIG_KIND_1");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_1LikeInsensitive(String value) {
            addCriterion("upper(KEIHOU_MARK_1) like", value.toUpperCase(), "KEIHOU_MARK_1");
            return (Criteria) this;
        }

        public Criteria andTS_2LikeInsensitive(String value) {
            addCriterion("upper(TS_2) like", value.toUpperCase(), "TS_2");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_2LikeInsensitive(String value) {
            addCriterion("upper(HASSEI_TS_2) like", value.toUpperCase(), "HASSEI_TS_2");
            return (Criteria) this;
        }

        public Criteria andSYANAI_2_CDLikeInsensitive(String value) {
            addCriterion("upper(SYANAI_2_CD) like", value.toUpperCase(), "SYANAI_2_CD");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_2LikeInsensitive(String value) {
            addCriterion("upper(KEIBI_SIG_2) like", value.toUpperCase(), "KEIBI_SIG_2");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_2LikeInsensitive(String value) {
            addCriterion("upper(SIG_KIND_2) like", value.toUpperCase(), "SIG_KIND_2");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_2LikeInsensitive(String value) {
            addCriterion("upper(KEIHOU_MARK_2) like", value.toUpperCase(), "KEIHOU_MARK_2");
            return (Criteria) this;
        }

        public Criteria andTS_3LikeInsensitive(String value) {
            addCriterion("upper(TS_3) like", value.toUpperCase(), "TS_3");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_3LikeInsensitive(String value) {
            addCriterion("upper(HASSEI_TS_3) like", value.toUpperCase(), "HASSEI_TS_3");
            return (Criteria) this;
        }

        public Criteria andSYANAI_3_CDLikeInsensitive(String value) {
            addCriterion("upper(SYANAI_3_CD) like", value.toUpperCase(), "SYANAI_3_CD");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_3LikeInsensitive(String value) {
            addCriterion("upper(KEIBI_SIG_3) like", value.toUpperCase(), "KEIBI_SIG_3");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_3LikeInsensitive(String value) {
            addCriterion("upper(SIG_KIND_3) like", value.toUpperCase(), "SIG_KIND_3");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_3LikeInsensitive(String value) {
            addCriterion("upper(KEIHOU_MARK_3) like", value.toUpperCase(), "KEIHOU_MARK_3");
            return (Criteria) this;
        }

        public Criteria andTS_4LikeInsensitive(String value) {
            addCriterion("upper(TS_4) like", value.toUpperCase(), "TS_4");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_4LikeInsensitive(String value) {
            addCriterion("upper(HASSEI_TS_4) like", value.toUpperCase(), "HASSEI_TS_4");
            return (Criteria) this;
        }

        public Criteria andSYANAI_4_CDLikeInsensitive(String value) {
            addCriterion("upper(SYANAI_4_CD) like", value.toUpperCase(), "SYANAI_4_CD");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_4LikeInsensitive(String value) {
            addCriterion("upper(KEIBI_SIG_4) like", value.toUpperCase(), "KEIBI_SIG_4");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_4LikeInsensitive(String value) {
            addCriterion("upper(SIG_KIND_4) like", value.toUpperCase(), "SIG_KIND_4");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_4LikeInsensitive(String value) {
            addCriterion("upper(KEIHOU_MARK_4) like", value.toUpperCase(), "KEIHOU_MARK_4");
            return (Criteria) this;
        }

        public Criteria andTS_5LikeInsensitive(String value) {
            addCriterion("upper(TS_5) like", value.toUpperCase(), "TS_5");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TS_5LikeInsensitive(String value) {
            addCriterion("upper(HASSEI_TS_5) like", value.toUpperCase(), "HASSEI_TS_5");
            return (Criteria) this;
        }

        public Criteria andSYANAI_5_CDLikeInsensitive(String value) {
            addCriterion("upper(SYANAI_5_CD) like", value.toUpperCase(), "SYANAI_5_CD");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SIG_5LikeInsensitive(String value) {
            addCriterion("upper(KEIBI_SIG_5) like", value.toUpperCase(), "KEIBI_SIG_5");
            return (Criteria) this;
        }

        public Criteria andSIG_KIND_5LikeInsensitive(String value) {
            addCriterion("upper(SIG_KIND_5) like", value.toUpperCase(), "SIG_KIND_5");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_MARK_5LikeInsensitive(String value) {
            addCriterion("upper(KEIHOU_MARK_5) like", value.toUpperCase(), "KEIHOU_MARK_5");
            return (Criteria) this;
        }

        public Criteria andSIG_IDLikeInsensitive(String value) {
            addCriterion("upper(SIG_ID) like", value.toUpperCase(), "SIG_ID");
            return (Criteria) this;
        }

        public Criteria andDATA_IDLikeInsensitive(String value) {
            addCriterion("upper(DATA_ID) like", value.toUpperCase(), "DATA_ID");
            return (Criteria) this;
        }

        public Criteria andMULTI_SIG_INFLikeInsensitive(String value) {
            addCriterion("upper(MULTI_SIG_INF) like", value.toUpperCase(), "MULTI_SIG_INF");
            return (Criteria) this;
        }

        public Criteria andNET_KEIBI_INFLikeInsensitive(String value) {
            addCriterion("upper(NET_KEIBI_INF) like", value.toUpperCase(), "NET_KEIBI_INF");
            return (Criteria) this;
        }

        public Criteria andGAM_KUBUN_CDLikeInsensitive(String value) {
            addCriterion("upper(GAM_KUBUN_CD) like", value.toUpperCase(), "GAM_KUBUN_CD");
            return (Criteria) this;
        }

        public Criteria andKOKYAKU_CDLikeInsensitive(String value) {
            addCriterion("upper(KOKYAKU_CD) like", value.toUpperCase(), "KOKYAKU_CD");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDLikeInsensitive(String value) {
            addCriterion("upper(HOSOKU_CD) like", value.toUpperCase(), "HOSOKU_CD");
            return (Criteria) this;
        }

        public Criteria andHASSEI_CNTLikeInsensitive(String value) {
            addCriterion("upper(HASSEI_CNT) like", value.toUpperCase(), "HASSEI_CNT");
            return (Criteria) this;
        }

        public Criteria andLAST_CNTLikeInsensitive(String value) {
            addCriterion("upper(LAST_CNT) like", value.toUpperCase(), "LAST_CNT");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMLikeInsensitive(String value) {
            addCriterion("upper(SIJI_TM) like", value.toUpperCase(), "SIJI_TM");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMLikeInsensitive(String value) {
            addCriterion("upper(CHOKKOU_TM) like", value.toUpperCase(), "CHOKKOU_TM");
            return (Criteria) this;
        }

        public Criteria andSYOYOU_TMLikeInsensitive(String value) {
            addCriterion("upper(SYOYOU_TM) like", value.toUpperCase(), "SYOYOU_TM");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMLikeInsensitive(String value) {
            addCriterion("upper(GENCHAKU_TM) like", value.toUpperCase(), "GENCHAKU_TM");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMLikeInsensitive(String value) {
            addCriterion("upper(NYUKAN_TM) like", value.toUpperCase(), "NYUKAN_TM");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMLikeInsensitive(String value) {
            addCriterion("upper(TAIKAN_TM) like", value.toUpperCase(), "TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andEND_TMLikeInsensitive(String value) {
            addCriterion("upper(END_TM) like", value.toUpperCase(), "END_TM");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSLikeInsensitive(String value) {
            addCriterion("upper(END_YOTEI_TS) like", value.toUpperCase(), "END_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMLikeInsensitive(String value) {
            addCriterion("upper(POLICE_CALL_TM) like", value.toUpperCase(), "POLICE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMLikeInsensitive(String value) {
            addCriterion("upper(POLICE_ARRIV_TM) like", value.toUpperCase(), "POLICE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMLikeInsensitive(String value) {
            addCriterion("upper(FIRE_CALL_TM) like", value.toUpperCase(), "FIRE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMLikeInsensitive(String value) {
            addCriterion("upper(FIRE_ARRIV_TM) like", value.toUpperCase(), "FIRE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDLikeInsensitive(String value) {
            addCriterion("upper(POLICE_REASON_CD) like", value.toUpperCase(), "POLICE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONLikeInsensitive(String value) {
            addCriterion("upper(POLICE_CALL_REASON) like", value.toUpperCase(), "POLICE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNLikeInsensitive(String value) {
            addCriterion("upper(POLICE_CALL_KBN) like", value.toUpperCase(), "POLICE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPOLikeInsensitive(String value) {
            addCriterion("upper(POLICE_SINPO) like", value.toUpperCase(), "POLICE_SINPO");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMLikeInsensitive(String value) {
            addCriterion("upper(POLICE_TAIKAN_TM) like", value.toUpperCase(), "POLICE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDLikeInsensitive(String value) {
            addCriterion("upper(FIRE_REASON_CD) like", value.toUpperCase(), "FIRE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONLikeInsensitive(String value) {
            addCriterion("upper(FIRE_CALL_REASON) like", value.toUpperCase(), "FIRE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNLikeInsensitive(String value) {
            addCriterion("upper(FIRE_CALL_KBN) like", value.toUpperCase(), "FIRE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPOLikeInsensitive(String value) {
            addCriterion("upper(FIRE_SINPO) like", value.toUpperCase(), "FIRE_SINPO");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMLikeInsensitive(String value) {
            addCriterion("upper(FIRE_TAIKAN_TM) like", value.toUpperCase(), "FIRE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDLikeInsensitive(String value) {
            addCriterion("upper(SGS_GENIN_CD) like", value.toUpperCase(), "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOULikeInsensitive(String value) {
            addCriterion("upper(GEN_DTL_NAIYOU) like", value.toUpperCase(), "GEN_DTL_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1LikeInsensitive(String value) {
            addCriterion("upper(GEN_NAIYOU_1) like", value.toUpperCase(), "GEN_NAIYOU_1");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2LikeInsensitive(String value) {
            addCriterion("upper(GEN_NAIYOU_2) like", value.toUpperCase(), "GEN_NAIYOU_2");
            return (Criteria) this;
        }

        public Criteria andJIANBNR_CDLikeInsensitive(String value) {
            addCriterion("upper(JIANBNR_CD) like", value.toUpperCase(), "JIANBNR_CD");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNR_CDLikeInsensitive(String value) {
            addCriterion("upper(KEIHOBNR_CD) like", value.toUpperCase(), "KEIHOBNR_CD");
            return (Criteria) this;
        }

        public Criteria andGENBNR_CDLikeInsensitive(String value) {
            addCriterion("upper(GENBNR_CD) like", value.toUpperCase(), "GENBNR_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDLikeInsensitive(String value) {
            addCriterion("upper(NET_GEN_CD) like", value.toUpperCase(), "NET_GEN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOULikeInsensitive(String value) {
            addCriterion("upper(NET_GEN_NAIYOU) like", value.toUpperCase(), "NET_GEN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andSENSOR_CDLikeInsensitive(String value) {
            addCriterion("upper(SENSOR_CD) like", value.toUpperCase(), "SENSOR_CD");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOULikeInsensitive(String value) {
            addCriterion("upper(TIMER_CHOKKOU) like", value.toUpperCase(), "TIMER_CHOKKOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKULikeInsensitive(String value) {
            addCriterion("upper(TIMER_GENCHAKU) like", value.toUpperCase(), "TIMER_GENCHAKU");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYOYOULikeInsensitive(String value) {
            addCriterion("upper(TIMER_SYOYOU) like", value.toUpperCase(), "TIMER_SYOYOU");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKANLikeInsensitive(String value) {
            addCriterion("upper(TIMER_NYUUKAN) like", value.toUpperCase(), "TIMER_NYUUKAN");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKANLikeInsensitive(String value) {
            addCriterion("upper(TIMER_TAIKAN) like", value.toUpperCase(), "TIMER_TAIKAN");
            return (Criteria) this;
        }

        public Criteria andTIMER_SYUURYOULikeInsensitive(String value) {
            addCriterion("upper(TIMER_SYUURYOU) like", value.toUpperCase(), "TIMER_SYUURYOU");
            return (Criteria) this;
        }

        public Criteria andTIME_OVERLikeInsensitive(String value) {
            addCriterion("upper(TIME_OVER) like", value.toUpperCase(), "TIME_OVER");
            return (Criteria) this;
        }

        public Criteria andTIMER_NO_CANCEL_TSLikeInsensitive(String value) {
            addCriterion("upper(TIMER_NO_CANCEL_TS) like", value.toUpperCase(), "TIMER_NO_CANCEL_TS");
            return (Criteria) this;
        }

        public Criteria andE_MEMOLikeInsensitive(String value) {
            addCriterion("upper(E_MEMO) like", value.toUpperCase(), "e_MEMO");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDLikeInsensitive(String value) {
            addCriterion("upper(JIGYO_CD) like", value.toUpperCase(), "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andN0_TIMELikeInsensitive(String value) {
            addCriterion("upper(N0_TIME) like", value.toUpperCase(), "n0_TIME");
            return (Criteria) this;
        }

        public Criteria andRE_WARN_FLGLikeInsensitive(String value) {
            addCriterion("upper(RE_WARN_FLG) like", value.toUpperCase(), "RE_WARN_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGLikeInsensitive(String value) {
            addCriterion("upper(BUZZ_FLG) like", value.toUpperCase(), "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andRESERVE_WARN_FLGLikeInsensitive(String value) {
            addCriterion("upper(RESERVE_WARN_FLG) like", value.toUpperCase(), "RESERVE_WARN_FLG");
            return (Criteria) this;
        }

        public Criteria andMESSAGE_COUNTLikeInsensitive(String value) {
            addCriterion("upper(MESSAGE_COUNT) like", value.toUpperCase(), "MESSAGE_COUNT");
            return (Criteria) this;
        }

        public Criteria andNO_MEASURE_CNTLikeInsensitive(String value) {
            addCriterion("upper(NO_MEASURE_CNT) like", value.toUpperCase(), "NO_MEASURE_CNT");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNLikeInsensitive(String value) {
            addCriterion("upper(TAIKAN_KBN) like", value.toUpperCase(), "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andJIAN_KINDLikeInsensitive(String value) {
            addCriterion("upper(JIAN_KIND) like", value.toUpperCase(), "JIAN_KIND");
            return (Criteria) this;
        }

        public Criteria andTAIOU_YOUHI_FLGLikeInsensitive(String value) {
            addCriterion("upper(TAIOU_YOUHI_FLG) like", value.toUpperCase(), "TAIOU_YOUHI_FLG");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMER_ENT_TMLikeInsensitive(String value) {
            addCriterion("upper(JITAI_TIMER_ENT_TM) like", value.toUpperCase(), "JITAI_TIMER_ENT_TM");
            return (Criteria) this;
        }

        public Criteria andJITAI_TIMEOUT_TMLikeInsensitive(String value) {
            addCriterion("upper(JITAI_TIMEOUT_TM) like", value.toUpperCase(), "JITAI_TIMEOUT_TM");
            return (Criteria) this;
        }

        public Criteria andTIMER_CHOKKOU_TOLikeInsensitive(String value) {
            addCriterion("upper(TIMER_CHOKKOU_TO) like", value.toUpperCase(), "TIMER_CHOKKOU_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_GENCHAKU_TOLikeInsensitive(String value) {
            addCriterion("upper(TIMER_GENCHAKU_TO) like", value.toUpperCase(), "TIMER_GENCHAKU_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_NYUUKAN_TOLikeInsensitive(String value) {
            addCriterion("upper(TIMER_NYUUKAN_TO) like", value.toUpperCase(), "TIMER_NYUUKAN_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_TAIKAN_TOLikeInsensitive(String value) {
            addCriterion("upper(TIMER_TAIKAN_TO) like", value.toUpperCase(), "TIMER_TAIKAN_TO");
            return (Criteria) this;
        }

        public Criteria andTIMER_END_TOLikeInsensitive(String value) {
            addCriterion("upper(TIMER_END_TO) like", value.toUpperCase(), "TIMER_END_TO");
            return (Criteria) this;
        }

        public Criteria andSIG_PRIORITYLikeInsensitive(String value) {
            addCriterion("upper(SIG_PRIORITY) like", value.toUpperCase(), "SIG_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andSIG_1_RCV_TIMELikeInsensitive(String value) {
            addCriterion("upper(SIG_1_RCV_TIME) like", value.toUpperCase(), "SIG_1_RCV_TIME");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNG_MARKLikeInsensitive(String value) {
            addCriterion("upper(SOCHI_CNG_MARK) like", value.toUpperCase(), "SOCHI_CNG_MARK");
            return (Criteria) this;
        }

        public Criteria andSUB_KASI_FLGLikeInsensitive(String value) {
            addCriterion("upper(SUB_KASI_FLG) like", value.toUpperCase(), "SUB_KASI_FLG");
            return (Criteria) this;
        }

        public Criteria andRAK_FLGLikeInsensitive(String value) {
            addCriterion("upper(RAK_FLG) like", value.toUpperCase(), "RAK_FLG");
            return (Criteria) this;
        }

        public Criteria andCANCEL_NTY_FLGLikeInsensitive(String value) {
            addCriterion("upper(CANCEL_NTY_FLG) like", value.toUpperCase(), "CANCEL_NTY_FLG");
            return (Criteria) this;
        }

        public Criteria andHONNIN_FLGLikeInsensitive(String value) {
            addCriterion("upper(HONNIN_FLG) like", value.toUpperCase(), "HONNIN_FLG");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * E_V6_JIANJF_FULL
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * E_V6_JIANJF_FULL null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}