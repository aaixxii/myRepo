package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class CCtrlMaster implements Serializable {
    /**
     * 送信機ID
     */
    private String TRANS_ID;

    /**
     * LN_制御装置論理番号
     */
    private String LN_CTL_DEV;

    /**
     * 個別定時監視間隔状態
     */
    private String KOBETSU_TEIJI_INT_STS;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * C_CTRL_MASTER
     */
    private static final long serialVersionUID = 1L;

    /**
     * 送信機ID
     * @return TRANS_ID 送信機ID
     */
    public String getTRANS_ID() {
        return TRANS_ID;
    }

    /**
     * 送信機ID
     * @param TRANS_ID 送信機ID
     */
    public void setTRANS_ID(String TRANS_ID) {
        this.TRANS_ID = TRANS_ID == null ? null : TRANS_ID.trim();
    }

    /**
     * LN_制御装置論理番号
     * @return LN_CTL_DEV LN_制御装置論理番号
     */
    public String getLN_CTL_DEV() {
        return LN_CTL_DEV;
    }

    /**
     * LN_制御装置論理番号
     * @param LN_CTL_DEV LN_制御装置論理番号
     */
    public void setLN_CTL_DEV(String LN_CTL_DEV) {
        this.LN_CTL_DEV = LN_CTL_DEV == null ? null : LN_CTL_DEV.trim();
    }

    /**
     * 個別定時監視間隔状態
     * @return KOBETSU_TEIJI_INT_STS 個別定時監視間隔状態
     */
    public String getKOBETSU_TEIJI_INT_STS() {
        return KOBETSU_TEIJI_INT_STS;
    }

    /**
     * 個別定時監視間隔状態
     * @param KOBETSU_TEIJI_INT_STS 個別定時監視間隔状態
     */
    public void setKOBETSU_TEIJI_INT_STS(String KOBETSU_TEIJI_INT_STS) {
        this.KOBETSU_TEIJI_INT_STS = KOBETSU_TEIJI_INT_STS == null ? null : KOBETSU_TEIJI_INT_STS.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}