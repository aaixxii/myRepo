package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class EKbNotice implements Serializable {
    /**
     * LN_警備お知らせ論理番号
     */
    private String LN_KB_NOTICE;

    /**
     * LN_警備情報論理番号
     */
    private String LN_KB_INF;

    /**
     * LN_入居管理論理番号
     */
    private String LN_TENANT_MNG;

    /**
     * タイトル
     */
    private String TITLE;

    /**
     * 連絡者名称
     */
    private String SENDER_NM;

    /**
     * 送信予定日時
     */
    private Date SEND_TS;

    /**
     * LN_警備先地区論理番号
     */
    private String LN_KB_CHIKU;

    /**
     * 操作者
     */
    private String OPERATION_USER;

    /**
     * リモート種別
     */
    private String RM_KIND;

    /**
     * 信号種別1
     */
    private String SIG_KIND_1;

    /**
     * 信号種別2
     */
    private String SIG_KIND_2;

    /**
     * 信号名称
     */
    private String SIG_NM;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * 本文
     */
    private String BODY;

    /**
     * E_KB_NOTICE
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_警備お知らせ論理番号
     * @return LN_KB_NOTICE LN_警備お知らせ論理番号
     */
    public String getLN_KB_NOTICE() {
        return LN_KB_NOTICE;
    }

    /**
     * LN_警備お知らせ論理番号
     * @param LN_KB_NOTICE LN_警備お知らせ論理番号
     */
    public void setLN_KB_NOTICE(String LN_KB_NOTICE) {
        this.LN_KB_NOTICE = LN_KB_NOTICE == null ? null : LN_KB_NOTICE.trim();
    }

    /**
     * LN_警備情報論理番号
     * @return LN_KB_INF LN_警備情報論理番号
     */
    public String getLN_KB_INF() {
        return LN_KB_INF;
    }

    /**
     * LN_警備情報論理番号
     * @param LN_KB_INF LN_警備情報論理番号
     */
    public void setLN_KB_INF(String LN_KB_INF) {
        this.LN_KB_INF = LN_KB_INF == null ? null : LN_KB_INF.trim();
    }

    /**
     * LN_入居管理論理番号
     * @return LN_TENANT_MNG LN_入居管理論理番号
     */
    public String getLN_TENANT_MNG() {
        return LN_TENANT_MNG;
    }

    /**
     * LN_入居管理論理番号
     * @param LN_TENANT_MNG LN_入居管理論理番号
     */
    public void setLN_TENANT_MNG(String LN_TENANT_MNG) {
        this.LN_TENANT_MNG = LN_TENANT_MNG == null ? null : LN_TENANT_MNG.trim();
    }

    /**
     * タイトル
     * @return TITLE タイトル
     */
    public String getTITLE() {
        return TITLE;
    }

    /**
     * タイトル
     * @param TITLE タイトル
     */
    public void setTITLE(String TITLE) {
        this.TITLE = TITLE == null ? null : TITLE.trim();
    }

    /**
     * 連絡者名称
     * @return SENDER_NM 連絡者名称
     */
    public String getSENDER_NM() {
        return SENDER_NM;
    }

    /**
     * 連絡者名称
     * @param SENDER_NM 連絡者名称
     */
    public void setSENDER_NM(String SENDER_NM) {
        this.SENDER_NM = SENDER_NM == null ? null : SENDER_NM.trim();
    }

    /**
     * 送信予定日時
     * @return SEND_TS 送信予定日時
     */
    public Date getSEND_TS() {
        return SEND_TS;
    }

    /**
     * 送信予定日時
     * @param SEND_TS 送信予定日時
     */
    public void setSEND_TS(Date SEND_TS) {
        this.SEND_TS = SEND_TS;
    }

    /**
     * LN_警備先地区論理番号
     * @return LN_KB_CHIKU LN_警備先地区論理番号
     */
    public String getLN_KB_CHIKU() {
        return LN_KB_CHIKU;
    }

    /**
     * LN_警備先地区論理番号
     * @param LN_KB_CHIKU LN_警備先地区論理番号
     */
    public void setLN_KB_CHIKU(String LN_KB_CHIKU) {
        this.LN_KB_CHIKU = LN_KB_CHIKU == null ? null : LN_KB_CHIKU.trim();
    }

    /**
     * 操作者
     * @return OPERATION_USER 操作者
     */
    public String getOPERATION_USER() {
        return OPERATION_USER;
    }

    /**
     * 操作者
     * @param OPERATION_USER 操作者
     */
    public void setOPERATION_USER(String OPERATION_USER) {
        this.OPERATION_USER = OPERATION_USER == null ? null : OPERATION_USER.trim();
    }

    /**
     * リモート種別
     * @return RM_KIND リモート種別
     */
    public String getRM_KIND() {
        return RM_KIND;
    }

    /**
     * リモート種別
     * @param RM_KIND リモート種別
     */
    public void setRM_KIND(String RM_KIND) {
        this.RM_KIND = RM_KIND == null ? null : RM_KIND.trim();
    }

    /**
     * 信号種別1
     * @return SIG_KIND_1 信号種別1
     */
    public String getSIG_KIND_1() {
        return SIG_KIND_1;
    }

    /**
     * 信号種別1
     * @param SIG_KIND_1 信号種別1
     */
    public void setSIG_KIND_1(String SIG_KIND_1) {
        this.SIG_KIND_1 = SIG_KIND_1 == null ? null : SIG_KIND_1.trim();
    }

    /**
     * 信号種別2
     * @return SIG_KIND_2 信号種別2
     */
    public String getSIG_KIND_2() {
        return SIG_KIND_2;
    }

    /**
     * 信号種別2
     * @param SIG_KIND_2 信号種別2
     */
    public void setSIG_KIND_2(String SIG_KIND_2) {
        this.SIG_KIND_2 = SIG_KIND_2 == null ? null : SIG_KIND_2.trim();
    }

    /**
     * 信号名称
     * @return SIG_NM 信号名称
     */
    public String getSIG_NM() {
        return SIG_NM;
    }

    /**
     * 信号名称
     * @param SIG_NM 信号名称
     */
    public void setSIG_NM(String SIG_NM) {
        this.SIG_NM = SIG_NM == null ? null : SIG_NM.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }

    /**
     * 本文
     * @return BODY 本文
     */
    public String getBODY() {
        return BODY;
    }

    /**
     * 本文
     * @param BODY 本文
     */
    public void setBODY(String BODY) {
        this.BODY = BODY == null ? null : BODY.trim();
    }
}