package jp.co.alsok.g6.db.entity.com;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class KAutoRmtChkSearchExample {
    /**
     * K_AUTO_RMT_CHK_SEARCH
     */
    protected String orderByClause;

    /**
     * K_AUTO_RMT_CHK_SEARCH
     */
    protected boolean distinct;

    /**
     * K_AUTO_RMT_CHK_SEARCH
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public KAutoRmtChkSearchExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * K_AUTO_RMT_CHK_SEARCH null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andJIGYOU_CDIsNull() {
            addCriterion("JIGYOU_CD is null");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_CDIsNotNull() {
            addCriterion("JIGYOU_CD is not null");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_CDEqualTo(String value) {
            addCriterion("JIGYOU_CD =", value, "JIGYOU_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_CDNotEqualTo(String value) {
            addCriterion("JIGYOU_CD <>", value, "JIGYOU_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_CDGreaterThan(String value) {
            addCriterion("JIGYOU_CD >", value, "JIGYOU_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_CDGreaterThanOrEqualTo(String value) {
            addCriterion("JIGYOU_CD >=", value, "JIGYOU_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_CDLessThan(String value) {
            addCriterion("JIGYOU_CD <", value, "JIGYOU_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_CDLessThanOrEqualTo(String value) {
            addCriterion("JIGYOU_CD <=", value, "JIGYOU_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_CDLike(String value) {
            addCriterion("JIGYOU_CD like", value, "JIGYOU_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_CDNotLike(String value) {
            addCriterion("JIGYOU_CD not like", value, "JIGYOU_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_CDIn(List<String> values) {
            addCriterion("JIGYOU_CD in", values, "JIGYOU_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_CDNotIn(List<String> values) {
            addCriterion("JIGYOU_CD not in", values, "JIGYOU_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_CDBetween(String value1, String value2) {
            addCriterion("JIGYOU_CD between", value1, value2, "JIGYOU_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_CDNotBetween(String value1, String value2) {
            addCriterion("JIGYOU_CD not between", value1, value2, "JIGYOU_CD");
            return (Criteria) this;
        }

        public Criteria andSEARCH_SERIESEIsNull() {
            addCriterion("SEARCH_SERIESE is null");
            return (Criteria) this;
        }

        public Criteria andSEARCH_SERIESEIsNotNull() {
            addCriterion("SEARCH_SERIESE is not null");
            return (Criteria) this;
        }

        public Criteria andSEARCH_SERIESEEqualTo(String value) {
            addCriterion("SEARCH_SERIESE =", value, "SEARCH_SERIESE");
            return (Criteria) this;
        }

        public Criteria andSEARCH_SERIESENotEqualTo(String value) {
            addCriterion("SEARCH_SERIESE <>", value, "SEARCH_SERIESE");
            return (Criteria) this;
        }

        public Criteria andSEARCH_SERIESEGreaterThan(String value) {
            addCriterion("SEARCH_SERIESE >", value, "SEARCH_SERIESE");
            return (Criteria) this;
        }

        public Criteria andSEARCH_SERIESEGreaterThanOrEqualTo(String value) {
            addCriterion("SEARCH_SERIESE >=", value, "SEARCH_SERIESE");
            return (Criteria) this;
        }

        public Criteria andSEARCH_SERIESELessThan(String value) {
            addCriterion("SEARCH_SERIESE <", value, "SEARCH_SERIESE");
            return (Criteria) this;
        }

        public Criteria andSEARCH_SERIESELessThanOrEqualTo(String value) {
            addCriterion("SEARCH_SERIESE <=", value, "SEARCH_SERIESE");
            return (Criteria) this;
        }

        public Criteria andSEARCH_SERIESELike(String value) {
            addCriterion("SEARCH_SERIESE like", value, "SEARCH_SERIESE");
            return (Criteria) this;
        }

        public Criteria andSEARCH_SERIESENotLike(String value) {
            addCriterion("SEARCH_SERIESE not like", value, "SEARCH_SERIESE");
            return (Criteria) this;
        }

        public Criteria andSEARCH_SERIESEIn(List<String> values) {
            addCriterion("SEARCH_SERIESE in", values, "SEARCH_SERIESE");
            return (Criteria) this;
        }

        public Criteria andSEARCH_SERIESENotIn(List<String> values) {
            addCriterion("SEARCH_SERIESE not in", values, "SEARCH_SERIESE");
            return (Criteria) this;
        }

        public Criteria andSEARCH_SERIESEBetween(String value1, String value2) {
            addCriterion("SEARCH_SERIESE between", value1, value2, "SEARCH_SERIESE");
            return (Criteria) this;
        }

        public Criteria andSEARCH_SERIESENotBetween(String value1, String value2) {
            addCriterion("SEARCH_SERIESE not between", value1, value2, "SEARCH_SERIESE");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_FLGIsNull() {
            addCriterion("SEARCH_REACTION_FLG is null");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_FLGIsNotNull() {
            addCriterion("SEARCH_REACTION_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_FLGEqualTo(String value) {
            addCriterion("SEARCH_REACTION_FLG =", value, "SEARCH_REACTION_FLG");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_FLGNotEqualTo(String value) {
            addCriterion("SEARCH_REACTION_FLG <>", value, "SEARCH_REACTION_FLG");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_FLGGreaterThan(String value) {
            addCriterion("SEARCH_REACTION_FLG >", value, "SEARCH_REACTION_FLG");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("SEARCH_REACTION_FLG >=", value, "SEARCH_REACTION_FLG");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_FLGLessThan(String value) {
            addCriterion("SEARCH_REACTION_FLG <", value, "SEARCH_REACTION_FLG");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_FLGLessThanOrEqualTo(String value) {
            addCriterion("SEARCH_REACTION_FLG <=", value, "SEARCH_REACTION_FLG");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_FLGLike(String value) {
            addCriterion("SEARCH_REACTION_FLG like", value, "SEARCH_REACTION_FLG");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_FLGNotLike(String value) {
            addCriterion("SEARCH_REACTION_FLG not like", value, "SEARCH_REACTION_FLG");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_FLGIn(List<String> values) {
            addCriterion("SEARCH_REACTION_FLG in", values, "SEARCH_REACTION_FLG");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_FLGNotIn(List<String> values) {
            addCriterion("SEARCH_REACTION_FLG not in", values, "SEARCH_REACTION_FLG");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_FLGBetween(String value1, String value2) {
            addCriterion("SEARCH_REACTION_FLG between", value1, value2, "SEARCH_REACTION_FLG");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_FLGNotBetween(String value1, String value2) {
            addCriterion("SEARCH_REACTION_FLG not between", value1, value2, "SEARCH_REACTION_FLG");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_DAYIsNull() {
            addCriterion("SEARCH_REACTION_DAY is null");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_DAYIsNotNull() {
            addCriterion("SEARCH_REACTION_DAY is not null");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_DAYEqualTo(String value) {
            addCriterion("SEARCH_REACTION_DAY =", value, "SEARCH_REACTION_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_DAYNotEqualTo(String value) {
            addCriterion("SEARCH_REACTION_DAY <>", value, "SEARCH_REACTION_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_DAYGreaterThan(String value) {
            addCriterion("SEARCH_REACTION_DAY >", value, "SEARCH_REACTION_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_DAYGreaterThanOrEqualTo(String value) {
            addCriterion("SEARCH_REACTION_DAY >=", value, "SEARCH_REACTION_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_DAYLessThan(String value) {
            addCriterion("SEARCH_REACTION_DAY <", value, "SEARCH_REACTION_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_DAYLessThanOrEqualTo(String value) {
            addCriterion("SEARCH_REACTION_DAY <=", value, "SEARCH_REACTION_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_DAYLike(String value) {
            addCriterion("SEARCH_REACTION_DAY like", value, "SEARCH_REACTION_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_DAYNotLike(String value) {
            addCriterion("SEARCH_REACTION_DAY not like", value, "SEARCH_REACTION_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_DAYIn(List<String> values) {
            addCriterion("SEARCH_REACTION_DAY in", values, "SEARCH_REACTION_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_DAYNotIn(List<String> values) {
            addCriterion("SEARCH_REACTION_DAY not in", values, "SEARCH_REACTION_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_DAYBetween(String value1, String value2) {
            addCriterion("SEARCH_REACTION_DAY between", value1, value2, "SEARCH_REACTION_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_DAYNotBetween(String value1, String value2) {
            addCriterion("SEARCH_REACTION_DAY not between", value1, value2, "SEARCH_REACTION_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_YEARIsNull() {
            addCriterion("SEARCH_DATE_FROM_YEAR is null");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_YEARIsNotNull() {
            addCriterion("SEARCH_DATE_FROM_YEAR is not null");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_YEAREqualTo(String value) {
            addCriterion("SEARCH_DATE_FROM_YEAR =", value, "SEARCH_DATE_FROM_YEAR");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_YEARNotEqualTo(String value) {
            addCriterion("SEARCH_DATE_FROM_YEAR <>", value, "SEARCH_DATE_FROM_YEAR");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_YEARGreaterThan(String value) {
            addCriterion("SEARCH_DATE_FROM_YEAR >", value, "SEARCH_DATE_FROM_YEAR");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_YEARGreaterThanOrEqualTo(String value) {
            addCriterion("SEARCH_DATE_FROM_YEAR >=", value, "SEARCH_DATE_FROM_YEAR");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_YEARLessThan(String value) {
            addCriterion("SEARCH_DATE_FROM_YEAR <", value, "SEARCH_DATE_FROM_YEAR");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_YEARLessThanOrEqualTo(String value) {
            addCriterion("SEARCH_DATE_FROM_YEAR <=", value, "SEARCH_DATE_FROM_YEAR");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_YEARLike(String value) {
            addCriterion("SEARCH_DATE_FROM_YEAR like", value, "SEARCH_DATE_FROM_YEAR");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_YEARNotLike(String value) {
            addCriterion("SEARCH_DATE_FROM_YEAR not like", value, "SEARCH_DATE_FROM_YEAR");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_YEARIn(List<String> values) {
            addCriterion("SEARCH_DATE_FROM_YEAR in", values, "SEARCH_DATE_FROM_YEAR");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_YEARNotIn(List<String> values) {
            addCriterion("SEARCH_DATE_FROM_YEAR not in", values, "SEARCH_DATE_FROM_YEAR");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_YEARBetween(String value1, String value2) {
            addCriterion("SEARCH_DATE_FROM_YEAR between", value1, value2, "SEARCH_DATE_FROM_YEAR");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_YEARNotBetween(String value1, String value2) {
            addCriterion("SEARCH_DATE_FROM_YEAR not between", value1, value2, "SEARCH_DATE_FROM_YEAR");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_MONTHIsNull() {
            addCriterion("SEARCH_DATE_FROM_MONTH is null");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_MONTHIsNotNull() {
            addCriterion("SEARCH_DATE_FROM_MONTH is not null");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_MONTHEqualTo(String value) {
            addCriterion("SEARCH_DATE_FROM_MONTH =", value, "SEARCH_DATE_FROM_MONTH");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_MONTHNotEqualTo(String value) {
            addCriterion("SEARCH_DATE_FROM_MONTH <>", value, "SEARCH_DATE_FROM_MONTH");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_MONTHGreaterThan(String value) {
            addCriterion("SEARCH_DATE_FROM_MONTH >", value, "SEARCH_DATE_FROM_MONTH");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_MONTHGreaterThanOrEqualTo(String value) {
            addCriterion("SEARCH_DATE_FROM_MONTH >=", value, "SEARCH_DATE_FROM_MONTH");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_MONTHLessThan(String value) {
            addCriterion("SEARCH_DATE_FROM_MONTH <", value, "SEARCH_DATE_FROM_MONTH");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_MONTHLessThanOrEqualTo(String value) {
            addCriterion("SEARCH_DATE_FROM_MONTH <=", value, "SEARCH_DATE_FROM_MONTH");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_MONTHLike(String value) {
            addCriterion("SEARCH_DATE_FROM_MONTH like", value, "SEARCH_DATE_FROM_MONTH");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_MONTHNotLike(String value) {
            addCriterion("SEARCH_DATE_FROM_MONTH not like", value, "SEARCH_DATE_FROM_MONTH");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_MONTHIn(List<String> values) {
            addCriterion("SEARCH_DATE_FROM_MONTH in", values, "SEARCH_DATE_FROM_MONTH");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_MONTHNotIn(List<String> values) {
            addCriterion("SEARCH_DATE_FROM_MONTH not in", values, "SEARCH_DATE_FROM_MONTH");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_MONTHBetween(String value1, String value2) {
            addCriterion("SEARCH_DATE_FROM_MONTH between", value1, value2, "SEARCH_DATE_FROM_MONTH");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_MONTHNotBetween(String value1, String value2) {
            addCriterion("SEARCH_DATE_FROM_MONTH not between", value1, value2, "SEARCH_DATE_FROM_MONTH");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_DAYIsNull() {
            addCriterion("SEARCH_DATE_FROM_DAY is null");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_DAYIsNotNull() {
            addCriterion("SEARCH_DATE_FROM_DAY is not null");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_DAYEqualTo(String value) {
            addCriterion("SEARCH_DATE_FROM_DAY =", value, "SEARCH_DATE_FROM_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_DAYNotEqualTo(String value) {
            addCriterion("SEARCH_DATE_FROM_DAY <>", value, "SEARCH_DATE_FROM_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_DAYGreaterThan(String value) {
            addCriterion("SEARCH_DATE_FROM_DAY >", value, "SEARCH_DATE_FROM_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_DAYGreaterThanOrEqualTo(String value) {
            addCriterion("SEARCH_DATE_FROM_DAY >=", value, "SEARCH_DATE_FROM_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_DAYLessThan(String value) {
            addCriterion("SEARCH_DATE_FROM_DAY <", value, "SEARCH_DATE_FROM_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_DAYLessThanOrEqualTo(String value) {
            addCriterion("SEARCH_DATE_FROM_DAY <=", value, "SEARCH_DATE_FROM_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_DAYLike(String value) {
            addCriterion("SEARCH_DATE_FROM_DAY like", value, "SEARCH_DATE_FROM_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_DAYNotLike(String value) {
            addCriterion("SEARCH_DATE_FROM_DAY not like", value, "SEARCH_DATE_FROM_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_DAYIn(List<String> values) {
            addCriterion("SEARCH_DATE_FROM_DAY in", values, "SEARCH_DATE_FROM_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_DAYNotIn(List<String> values) {
            addCriterion("SEARCH_DATE_FROM_DAY not in", values, "SEARCH_DATE_FROM_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_DAYBetween(String value1, String value2) {
            addCriterion("SEARCH_DATE_FROM_DAY between", value1, value2, "SEARCH_DATE_FROM_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_DAYNotBetween(String value1, String value2) {
            addCriterion("SEARCH_DATE_FROM_DAY not between", value1, value2, "SEARCH_DATE_FROM_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_YEARIsNull() {
            addCriterion("SEARCH_DATE_TO_YEAR is null");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_YEARIsNotNull() {
            addCriterion("SEARCH_DATE_TO_YEAR is not null");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_YEAREqualTo(String value) {
            addCriterion("SEARCH_DATE_TO_YEAR =", value, "SEARCH_DATE_TO_YEAR");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_YEARNotEqualTo(String value) {
            addCriterion("SEARCH_DATE_TO_YEAR <>", value, "SEARCH_DATE_TO_YEAR");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_YEARGreaterThan(String value) {
            addCriterion("SEARCH_DATE_TO_YEAR >", value, "SEARCH_DATE_TO_YEAR");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_YEARGreaterThanOrEqualTo(String value) {
            addCriterion("SEARCH_DATE_TO_YEAR >=", value, "SEARCH_DATE_TO_YEAR");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_YEARLessThan(String value) {
            addCriterion("SEARCH_DATE_TO_YEAR <", value, "SEARCH_DATE_TO_YEAR");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_YEARLessThanOrEqualTo(String value) {
            addCriterion("SEARCH_DATE_TO_YEAR <=", value, "SEARCH_DATE_TO_YEAR");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_YEARLike(String value) {
            addCriterion("SEARCH_DATE_TO_YEAR like", value, "SEARCH_DATE_TO_YEAR");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_YEARNotLike(String value) {
            addCriterion("SEARCH_DATE_TO_YEAR not like", value, "SEARCH_DATE_TO_YEAR");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_YEARIn(List<String> values) {
            addCriterion("SEARCH_DATE_TO_YEAR in", values, "SEARCH_DATE_TO_YEAR");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_YEARNotIn(List<String> values) {
            addCriterion("SEARCH_DATE_TO_YEAR not in", values, "SEARCH_DATE_TO_YEAR");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_YEARBetween(String value1, String value2) {
            addCriterion("SEARCH_DATE_TO_YEAR between", value1, value2, "SEARCH_DATE_TO_YEAR");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_YEARNotBetween(String value1, String value2) {
            addCriterion("SEARCH_DATE_TO_YEAR not between", value1, value2, "SEARCH_DATE_TO_YEAR");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_MONTHIsNull() {
            addCriterion("SEARCH_DATE_TO_MONTH is null");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_MONTHIsNotNull() {
            addCriterion("SEARCH_DATE_TO_MONTH is not null");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_MONTHEqualTo(String value) {
            addCriterion("SEARCH_DATE_TO_MONTH =", value, "SEARCH_DATE_TO_MONTH");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_MONTHNotEqualTo(String value) {
            addCriterion("SEARCH_DATE_TO_MONTH <>", value, "SEARCH_DATE_TO_MONTH");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_MONTHGreaterThan(String value) {
            addCriterion("SEARCH_DATE_TO_MONTH >", value, "SEARCH_DATE_TO_MONTH");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_MONTHGreaterThanOrEqualTo(String value) {
            addCriterion("SEARCH_DATE_TO_MONTH >=", value, "SEARCH_DATE_TO_MONTH");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_MONTHLessThan(String value) {
            addCriterion("SEARCH_DATE_TO_MONTH <", value, "SEARCH_DATE_TO_MONTH");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_MONTHLessThanOrEqualTo(String value) {
            addCriterion("SEARCH_DATE_TO_MONTH <=", value, "SEARCH_DATE_TO_MONTH");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_MONTHLike(String value) {
            addCriterion("SEARCH_DATE_TO_MONTH like", value, "SEARCH_DATE_TO_MONTH");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_MONTHNotLike(String value) {
            addCriterion("SEARCH_DATE_TO_MONTH not like", value, "SEARCH_DATE_TO_MONTH");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_MONTHIn(List<String> values) {
            addCriterion("SEARCH_DATE_TO_MONTH in", values, "SEARCH_DATE_TO_MONTH");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_MONTHNotIn(List<String> values) {
            addCriterion("SEARCH_DATE_TO_MONTH not in", values, "SEARCH_DATE_TO_MONTH");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_MONTHBetween(String value1, String value2) {
            addCriterion("SEARCH_DATE_TO_MONTH between", value1, value2, "SEARCH_DATE_TO_MONTH");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_MONTHNotBetween(String value1, String value2) {
            addCriterion("SEARCH_DATE_TO_MONTH not between", value1, value2, "SEARCH_DATE_TO_MONTH");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_DAYIsNull() {
            addCriterion("SEARCH_DATE_TO_DAY is null");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_DAYIsNotNull() {
            addCriterion("SEARCH_DATE_TO_DAY is not null");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_DAYEqualTo(String value) {
            addCriterion("SEARCH_DATE_TO_DAY =", value, "SEARCH_DATE_TO_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_DAYNotEqualTo(String value) {
            addCriterion("SEARCH_DATE_TO_DAY <>", value, "SEARCH_DATE_TO_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_DAYGreaterThan(String value) {
            addCriterion("SEARCH_DATE_TO_DAY >", value, "SEARCH_DATE_TO_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_DAYGreaterThanOrEqualTo(String value) {
            addCriterion("SEARCH_DATE_TO_DAY >=", value, "SEARCH_DATE_TO_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_DAYLessThan(String value) {
            addCriterion("SEARCH_DATE_TO_DAY <", value, "SEARCH_DATE_TO_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_DAYLessThanOrEqualTo(String value) {
            addCriterion("SEARCH_DATE_TO_DAY <=", value, "SEARCH_DATE_TO_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_DAYLike(String value) {
            addCriterion("SEARCH_DATE_TO_DAY like", value, "SEARCH_DATE_TO_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_DAYNotLike(String value) {
            addCriterion("SEARCH_DATE_TO_DAY not like", value, "SEARCH_DATE_TO_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_DAYIn(List<String> values) {
            addCriterion("SEARCH_DATE_TO_DAY in", values, "SEARCH_DATE_TO_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_DAYNotIn(List<String> values) {
            addCriterion("SEARCH_DATE_TO_DAY not in", values, "SEARCH_DATE_TO_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_DAYBetween(String value1, String value2) {
            addCriterion("SEARCH_DATE_TO_DAY between", value1, value2, "SEARCH_DATE_TO_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_DAYNotBetween(String value1, String value2) {
            addCriterion("SEARCH_DATE_TO_DAY not between", value1, value2, "SEARCH_DATE_TO_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_RESERVE_FLGIsNull() {
            addCriterion("SEARCH_RESERVE_FLG is null");
            return (Criteria) this;
        }

        public Criteria andSEARCH_RESERVE_FLGIsNotNull() {
            addCriterion("SEARCH_RESERVE_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andSEARCH_RESERVE_FLGEqualTo(String value) {
            addCriterion("SEARCH_RESERVE_FLG =", value, "SEARCH_RESERVE_FLG");
            return (Criteria) this;
        }

        public Criteria andSEARCH_RESERVE_FLGNotEqualTo(String value) {
            addCriterion("SEARCH_RESERVE_FLG <>", value, "SEARCH_RESERVE_FLG");
            return (Criteria) this;
        }

        public Criteria andSEARCH_RESERVE_FLGGreaterThan(String value) {
            addCriterion("SEARCH_RESERVE_FLG >", value, "SEARCH_RESERVE_FLG");
            return (Criteria) this;
        }

        public Criteria andSEARCH_RESERVE_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("SEARCH_RESERVE_FLG >=", value, "SEARCH_RESERVE_FLG");
            return (Criteria) this;
        }

        public Criteria andSEARCH_RESERVE_FLGLessThan(String value) {
            addCriterion("SEARCH_RESERVE_FLG <", value, "SEARCH_RESERVE_FLG");
            return (Criteria) this;
        }

        public Criteria andSEARCH_RESERVE_FLGLessThanOrEqualTo(String value) {
            addCriterion("SEARCH_RESERVE_FLG <=", value, "SEARCH_RESERVE_FLG");
            return (Criteria) this;
        }

        public Criteria andSEARCH_RESERVE_FLGLike(String value) {
            addCriterion("SEARCH_RESERVE_FLG like", value, "SEARCH_RESERVE_FLG");
            return (Criteria) this;
        }

        public Criteria andSEARCH_RESERVE_FLGNotLike(String value) {
            addCriterion("SEARCH_RESERVE_FLG not like", value, "SEARCH_RESERVE_FLG");
            return (Criteria) this;
        }

        public Criteria andSEARCH_RESERVE_FLGIn(List<String> values) {
            addCriterion("SEARCH_RESERVE_FLG in", values, "SEARCH_RESERVE_FLG");
            return (Criteria) this;
        }

        public Criteria andSEARCH_RESERVE_FLGNotIn(List<String> values) {
            addCriterion("SEARCH_RESERVE_FLG not in", values, "SEARCH_RESERVE_FLG");
            return (Criteria) this;
        }

        public Criteria andSEARCH_RESERVE_FLGBetween(String value1, String value2) {
            addCriterion("SEARCH_RESERVE_FLG between", value1, value2, "SEARCH_RESERVE_FLG");
            return (Criteria) this;
        }

        public Criteria andSEARCH_RESERVE_FLGNotBetween(String value1, String value2) {
            addCriterion("SEARCH_RESERVE_FLG not between", value1, value2, "SEARCH_RESERVE_FLG");
            return (Criteria) this;
        }

        public Criteria andSEARCH_KEIBI_MODELIsNull() {
            addCriterion("SEARCH_KEIBI_MODEL is null");
            return (Criteria) this;
        }

        public Criteria andSEARCH_KEIBI_MODELIsNotNull() {
            addCriterion("SEARCH_KEIBI_MODEL is not null");
            return (Criteria) this;
        }

        public Criteria andSEARCH_KEIBI_MODELEqualTo(String value) {
            addCriterion("SEARCH_KEIBI_MODEL =", value, "SEARCH_KEIBI_MODEL");
            return (Criteria) this;
        }

        public Criteria andSEARCH_KEIBI_MODELNotEqualTo(String value) {
            addCriterion("SEARCH_KEIBI_MODEL <>", value, "SEARCH_KEIBI_MODEL");
            return (Criteria) this;
        }

        public Criteria andSEARCH_KEIBI_MODELGreaterThan(String value) {
            addCriterion("SEARCH_KEIBI_MODEL >", value, "SEARCH_KEIBI_MODEL");
            return (Criteria) this;
        }

        public Criteria andSEARCH_KEIBI_MODELGreaterThanOrEqualTo(String value) {
            addCriterion("SEARCH_KEIBI_MODEL >=", value, "SEARCH_KEIBI_MODEL");
            return (Criteria) this;
        }

        public Criteria andSEARCH_KEIBI_MODELLessThan(String value) {
            addCriterion("SEARCH_KEIBI_MODEL <", value, "SEARCH_KEIBI_MODEL");
            return (Criteria) this;
        }

        public Criteria andSEARCH_KEIBI_MODELLessThanOrEqualTo(String value) {
            addCriterion("SEARCH_KEIBI_MODEL <=", value, "SEARCH_KEIBI_MODEL");
            return (Criteria) this;
        }

        public Criteria andSEARCH_KEIBI_MODELLike(String value) {
            addCriterion("SEARCH_KEIBI_MODEL like", value, "SEARCH_KEIBI_MODEL");
            return (Criteria) this;
        }

        public Criteria andSEARCH_KEIBI_MODELNotLike(String value) {
            addCriterion("SEARCH_KEIBI_MODEL not like", value, "SEARCH_KEIBI_MODEL");
            return (Criteria) this;
        }

        public Criteria andSEARCH_KEIBI_MODELIn(List<String> values) {
            addCriterion("SEARCH_KEIBI_MODEL in", values, "SEARCH_KEIBI_MODEL");
            return (Criteria) this;
        }

        public Criteria andSEARCH_KEIBI_MODELNotIn(List<String> values) {
            addCriterion("SEARCH_KEIBI_MODEL not in", values, "SEARCH_KEIBI_MODEL");
            return (Criteria) this;
        }

        public Criteria andSEARCH_KEIBI_MODELBetween(String value1, String value2) {
            addCriterion("SEARCH_KEIBI_MODEL between", value1, value2, "SEARCH_KEIBI_MODEL");
            return (Criteria) this;
        }

        public Criteria andSEARCH_KEIBI_MODELNotBetween(String value1, String value2) {
            addCriterion("SEARCH_KEIBI_MODEL not between", value1, value2, "SEARCH_KEIBI_MODEL");
            return (Criteria) this;
        }

        public Criteria andSEARCH_TIME_MODELIsNull() {
            addCriterion("SEARCH_TIME_MODEL is null");
            return (Criteria) this;
        }

        public Criteria andSEARCH_TIME_MODELIsNotNull() {
            addCriterion("SEARCH_TIME_MODEL is not null");
            return (Criteria) this;
        }

        public Criteria andSEARCH_TIME_MODELEqualTo(String value) {
            addCriterion("SEARCH_TIME_MODEL =", value, "SEARCH_TIME_MODEL");
            return (Criteria) this;
        }

        public Criteria andSEARCH_TIME_MODELNotEqualTo(String value) {
            addCriterion("SEARCH_TIME_MODEL <>", value, "SEARCH_TIME_MODEL");
            return (Criteria) this;
        }

        public Criteria andSEARCH_TIME_MODELGreaterThan(String value) {
            addCriterion("SEARCH_TIME_MODEL >", value, "SEARCH_TIME_MODEL");
            return (Criteria) this;
        }

        public Criteria andSEARCH_TIME_MODELGreaterThanOrEqualTo(String value) {
            addCriterion("SEARCH_TIME_MODEL >=", value, "SEARCH_TIME_MODEL");
            return (Criteria) this;
        }

        public Criteria andSEARCH_TIME_MODELLessThan(String value) {
            addCriterion("SEARCH_TIME_MODEL <", value, "SEARCH_TIME_MODEL");
            return (Criteria) this;
        }

        public Criteria andSEARCH_TIME_MODELLessThanOrEqualTo(String value) {
            addCriterion("SEARCH_TIME_MODEL <=", value, "SEARCH_TIME_MODEL");
            return (Criteria) this;
        }

        public Criteria andSEARCH_TIME_MODELLike(String value) {
            addCriterion("SEARCH_TIME_MODEL like", value, "SEARCH_TIME_MODEL");
            return (Criteria) this;
        }

        public Criteria andSEARCH_TIME_MODELNotLike(String value) {
            addCriterion("SEARCH_TIME_MODEL not like", value, "SEARCH_TIME_MODEL");
            return (Criteria) this;
        }

        public Criteria andSEARCH_TIME_MODELIn(List<String> values) {
            addCriterion("SEARCH_TIME_MODEL in", values, "SEARCH_TIME_MODEL");
            return (Criteria) this;
        }

        public Criteria andSEARCH_TIME_MODELNotIn(List<String> values) {
            addCriterion("SEARCH_TIME_MODEL not in", values, "SEARCH_TIME_MODEL");
            return (Criteria) this;
        }

        public Criteria andSEARCH_TIME_MODELBetween(String value1, String value2) {
            addCriterion("SEARCH_TIME_MODEL between", value1, value2, "SEARCH_TIME_MODEL");
            return (Criteria) this;
        }

        public Criteria andSEARCH_TIME_MODELNotBetween(String value1, String value2) {
            addCriterion("SEARCH_TIME_MODEL not between", value1, value2, "SEARCH_TIME_MODEL");
            return (Criteria) this;
        }

        public Criteria andSELECT_SEARCHIsNull() {
            addCriterion("SELECT_SEARCH is null");
            return (Criteria) this;
        }

        public Criteria andSELECT_SEARCHIsNotNull() {
            addCriterion("SELECT_SEARCH is not null");
            return (Criteria) this;
        }

        public Criteria andSELECT_SEARCHEqualTo(String value) {
            addCriterion("SELECT_SEARCH =", value, "SELECT_SEARCH");
            return (Criteria) this;
        }

        public Criteria andSELECT_SEARCHNotEqualTo(String value) {
            addCriterion("SELECT_SEARCH <>", value, "SELECT_SEARCH");
            return (Criteria) this;
        }

        public Criteria andSELECT_SEARCHGreaterThan(String value) {
            addCriterion("SELECT_SEARCH >", value, "SELECT_SEARCH");
            return (Criteria) this;
        }

        public Criteria andSELECT_SEARCHGreaterThanOrEqualTo(String value) {
            addCriterion("SELECT_SEARCH >=", value, "SELECT_SEARCH");
            return (Criteria) this;
        }

        public Criteria andSELECT_SEARCHLessThan(String value) {
            addCriterion("SELECT_SEARCH <", value, "SELECT_SEARCH");
            return (Criteria) this;
        }

        public Criteria andSELECT_SEARCHLessThanOrEqualTo(String value) {
            addCriterion("SELECT_SEARCH <=", value, "SELECT_SEARCH");
            return (Criteria) this;
        }

        public Criteria andSELECT_SEARCHLike(String value) {
            addCriterion("SELECT_SEARCH like", value, "SELECT_SEARCH");
            return (Criteria) this;
        }

        public Criteria andSELECT_SEARCHNotLike(String value) {
            addCriterion("SELECT_SEARCH not like", value, "SELECT_SEARCH");
            return (Criteria) this;
        }

        public Criteria andSELECT_SEARCHIn(List<String> values) {
            addCriterion("SELECT_SEARCH in", values, "SELECT_SEARCH");
            return (Criteria) this;
        }

        public Criteria andSELECT_SEARCHNotIn(List<String> values) {
            addCriterion("SELECT_SEARCH not in", values, "SELECT_SEARCH");
            return (Criteria) this;
        }

        public Criteria andSELECT_SEARCHBetween(String value1, String value2) {
            addCriterion("SELECT_SEARCH between", value1, value2, "SELECT_SEARCH");
            return (Criteria) this;
        }

        public Criteria andSELECT_SEARCHNotBetween(String value1, String value2) {
            addCriterion("SELECT_SEARCH not between", value1, value2, "SELECT_SEARCH");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SEARCH_FLGIsNull() {
            addCriterion("KEIBI_SEARCH_FLG is null");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SEARCH_FLGIsNotNull() {
            addCriterion("KEIBI_SEARCH_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SEARCH_FLGEqualTo(String value) {
            addCriterion("KEIBI_SEARCH_FLG =", value, "KEIBI_SEARCH_FLG");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SEARCH_FLGNotEqualTo(String value) {
            addCriterion("KEIBI_SEARCH_FLG <>", value, "KEIBI_SEARCH_FLG");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SEARCH_FLGGreaterThan(String value) {
            addCriterion("KEIBI_SEARCH_FLG >", value, "KEIBI_SEARCH_FLG");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SEARCH_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("KEIBI_SEARCH_FLG >=", value, "KEIBI_SEARCH_FLG");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SEARCH_FLGLessThan(String value) {
            addCriterion("KEIBI_SEARCH_FLG <", value, "KEIBI_SEARCH_FLG");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SEARCH_FLGLessThanOrEqualTo(String value) {
            addCriterion("KEIBI_SEARCH_FLG <=", value, "KEIBI_SEARCH_FLG");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SEARCH_FLGLike(String value) {
            addCriterion("KEIBI_SEARCH_FLG like", value, "KEIBI_SEARCH_FLG");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SEARCH_FLGNotLike(String value) {
            addCriterion("KEIBI_SEARCH_FLG not like", value, "KEIBI_SEARCH_FLG");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SEARCH_FLGIn(List<String> values) {
            addCriterion("KEIBI_SEARCH_FLG in", values, "KEIBI_SEARCH_FLG");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SEARCH_FLGNotIn(List<String> values) {
            addCriterion("KEIBI_SEARCH_FLG not in", values, "KEIBI_SEARCH_FLG");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SEARCH_FLGBetween(String value1, String value2) {
            addCriterion("KEIBI_SEARCH_FLG between", value1, value2, "KEIBI_SEARCH_FLG");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SEARCH_FLGNotBetween(String value1, String value2) {
            addCriterion("KEIBI_SEARCH_FLG not between", value1, value2, "KEIBI_SEARCH_FLG");
            return (Criteria) this;
        }

        public Criteria andTIME_SEARCH_FLGIsNull() {
            addCriterion("TIME_SEARCH_FLG is null");
            return (Criteria) this;
        }

        public Criteria andTIME_SEARCH_FLGIsNotNull() {
            addCriterion("TIME_SEARCH_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andTIME_SEARCH_FLGEqualTo(String value) {
            addCriterion("TIME_SEARCH_FLG =", value, "TIME_SEARCH_FLG");
            return (Criteria) this;
        }

        public Criteria andTIME_SEARCH_FLGNotEqualTo(String value) {
            addCriterion("TIME_SEARCH_FLG <>", value, "TIME_SEARCH_FLG");
            return (Criteria) this;
        }

        public Criteria andTIME_SEARCH_FLGGreaterThan(String value) {
            addCriterion("TIME_SEARCH_FLG >", value, "TIME_SEARCH_FLG");
            return (Criteria) this;
        }

        public Criteria andTIME_SEARCH_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("TIME_SEARCH_FLG >=", value, "TIME_SEARCH_FLG");
            return (Criteria) this;
        }

        public Criteria andTIME_SEARCH_FLGLessThan(String value) {
            addCriterion("TIME_SEARCH_FLG <", value, "TIME_SEARCH_FLG");
            return (Criteria) this;
        }

        public Criteria andTIME_SEARCH_FLGLessThanOrEqualTo(String value) {
            addCriterion("TIME_SEARCH_FLG <=", value, "TIME_SEARCH_FLG");
            return (Criteria) this;
        }

        public Criteria andTIME_SEARCH_FLGLike(String value) {
            addCriterion("TIME_SEARCH_FLG like", value, "TIME_SEARCH_FLG");
            return (Criteria) this;
        }

        public Criteria andTIME_SEARCH_FLGNotLike(String value) {
            addCriterion("TIME_SEARCH_FLG not like", value, "TIME_SEARCH_FLG");
            return (Criteria) this;
        }

        public Criteria andTIME_SEARCH_FLGIn(List<String> values) {
            addCriterion("TIME_SEARCH_FLG in", values, "TIME_SEARCH_FLG");
            return (Criteria) this;
        }

        public Criteria andTIME_SEARCH_FLGNotIn(List<String> values) {
            addCriterion("TIME_SEARCH_FLG not in", values, "TIME_SEARCH_FLG");
            return (Criteria) this;
        }

        public Criteria andTIME_SEARCH_FLGBetween(String value1, String value2) {
            addCriterion("TIME_SEARCH_FLG between", value1, value2, "TIME_SEARCH_FLG");
            return (Criteria) this;
        }

        public Criteria andTIME_SEARCH_FLGNotBetween(String value1, String value2) {
            addCriterion("TIME_SEARCH_FLG not between", value1, value2, "TIME_SEARCH_FLG");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_CDLikeInsensitive(String value) {
            addCriterion("upper(JIGYOU_CD) like", value.toUpperCase(), "JIGYOU_CD");
            return (Criteria) this;
        }

        public Criteria andSEARCH_SERIESELikeInsensitive(String value) {
            addCriterion("upper(SEARCH_SERIESE) like", value.toUpperCase(), "SEARCH_SERIESE");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_FLGLikeInsensitive(String value) {
            addCriterion("upper(SEARCH_REACTION_FLG) like", value.toUpperCase(), "SEARCH_REACTION_FLG");
            return (Criteria) this;
        }

        public Criteria andSEARCH_REACTION_DAYLikeInsensitive(String value) {
            addCriterion("upper(SEARCH_REACTION_DAY) like", value.toUpperCase(), "SEARCH_REACTION_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_YEARLikeInsensitive(String value) {
            addCriterion("upper(SEARCH_DATE_FROM_YEAR) like", value.toUpperCase(), "SEARCH_DATE_FROM_YEAR");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_MONTHLikeInsensitive(String value) {
            addCriterion("upper(SEARCH_DATE_FROM_MONTH) like", value.toUpperCase(), "SEARCH_DATE_FROM_MONTH");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_FROM_DAYLikeInsensitive(String value) {
            addCriterion("upper(SEARCH_DATE_FROM_DAY) like", value.toUpperCase(), "SEARCH_DATE_FROM_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_YEARLikeInsensitive(String value) {
            addCriterion("upper(SEARCH_DATE_TO_YEAR) like", value.toUpperCase(), "SEARCH_DATE_TO_YEAR");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_MONTHLikeInsensitive(String value) {
            addCriterion("upper(SEARCH_DATE_TO_MONTH) like", value.toUpperCase(), "SEARCH_DATE_TO_MONTH");
            return (Criteria) this;
        }

        public Criteria andSEARCH_DATE_TO_DAYLikeInsensitive(String value) {
            addCriterion("upper(SEARCH_DATE_TO_DAY) like", value.toUpperCase(), "SEARCH_DATE_TO_DAY");
            return (Criteria) this;
        }

        public Criteria andSEARCH_RESERVE_FLGLikeInsensitive(String value) {
            addCriterion("upper(SEARCH_RESERVE_FLG) like", value.toUpperCase(), "SEARCH_RESERVE_FLG");
            return (Criteria) this;
        }

        public Criteria andSEARCH_KEIBI_MODELLikeInsensitive(String value) {
            addCriterion("upper(SEARCH_KEIBI_MODEL) like", value.toUpperCase(), "SEARCH_KEIBI_MODEL");
            return (Criteria) this;
        }

        public Criteria andSEARCH_TIME_MODELLikeInsensitive(String value) {
            addCriterion("upper(SEARCH_TIME_MODEL) like", value.toUpperCase(), "SEARCH_TIME_MODEL");
            return (Criteria) this;
        }

        public Criteria andSELECT_SEARCHLikeInsensitive(String value) {
            addCriterion("upper(SELECT_SEARCH) like", value.toUpperCase(), "SELECT_SEARCH");
            return (Criteria) this;
        }

        public Criteria andKEIBI_SEARCH_FLGLikeInsensitive(String value) {
            addCriterion("upper(KEIBI_SEARCH_FLG) like", value.toUpperCase(), "KEIBI_SEARCH_FLG");
            return (Criteria) this;
        }

        public Criteria andTIME_SEARCH_FLGLikeInsensitive(String value) {
            addCriterion("upper(TIME_SEARCH_FLG) like", value.toUpperCase(), "TIME_SEARCH_FLG");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * K_AUTO_RMT_CHK_SEARCH
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * K_AUTO_RMT_CHK_SEARCH null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}