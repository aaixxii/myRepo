package jp.co.alsok.g6.db.entity.com;

import java.io.Serializable;
import java.util.Date;

public class KJigyou implements Serializable {
    /**
     * 事業所コード
     */
    private String JIGYOU_CD;

    /**
     * 事業所名称
     */
    private String JIGYOU_NM;

    /**
     * 事業所種別
     */
    private String JIGYOU_KIND;

    /**
     * 上位事業所コード
     */
    private String UPPER_JIGYOU_CD;

    /**
     * GCコード
     */
    private String GC_CD;

    /**
     * 事業所電話番号
     */
    private String JIGYOU_TEL_NUM;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * K_JIGYOU
     */
    private static final long serialVersionUID = 1L;

    /**
     * 事業所コード
     * @return JIGYOU_CD 事業所コード
     */
    public String getJIGYOU_CD() {
        return JIGYOU_CD;
    }

    /**
     * 事業所コード
     * @param JIGYOU_CD 事業所コード
     */
    public void setJIGYOU_CD(String JIGYOU_CD) {
        this.JIGYOU_CD = JIGYOU_CD == null ? null : JIGYOU_CD.trim();
    }

    /**
     * 事業所名称
     * @return JIGYOU_NM 事業所名称
     */
    public String getJIGYOU_NM() {
        return JIGYOU_NM;
    }

    /**
     * 事業所名称
     * @param JIGYOU_NM 事業所名称
     */
    public void setJIGYOU_NM(String JIGYOU_NM) {
        this.JIGYOU_NM = JIGYOU_NM == null ? null : JIGYOU_NM.trim();
    }

    /**
     * 事業所種別
     * @return JIGYOU_KIND 事業所種別
     */
    public String getJIGYOU_KIND() {
        return JIGYOU_KIND;
    }

    /**
     * 事業所種別
     * @param JIGYOU_KIND 事業所種別
     */
    public void setJIGYOU_KIND(String JIGYOU_KIND) {
        this.JIGYOU_KIND = JIGYOU_KIND == null ? null : JIGYOU_KIND.trim();
    }

    /**
     * 上位事業所コード
     * @return UPPER_JIGYOU_CD 上位事業所コード
     */
    public String getUPPER_JIGYOU_CD() {
        return UPPER_JIGYOU_CD;
    }

    /**
     * 上位事業所コード
     * @param UPPER_JIGYOU_CD 上位事業所コード
     */
    public void setUPPER_JIGYOU_CD(String UPPER_JIGYOU_CD) {
        this.UPPER_JIGYOU_CD = UPPER_JIGYOU_CD == null ? null : UPPER_JIGYOU_CD.trim();
    }

    /**
     * GCコード
     * @return GC_CD GCコード
     */
    public String getGC_CD() {
        return GC_CD;
    }

    /**
     * GCコード
     * @param GC_CD GCコード
     */
    public void setGC_CD(String GC_CD) {
        this.GC_CD = GC_CD == null ? null : GC_CD.trim();
    }

    /**
     * 事業所電話番号
     * @return JIGYOU_TEL_NUM 事業所電話番号
     */
    public String getJIGYOU_TEL_NUM() {
        return JIGYOU_TEL_NUM;
    }

    /**
     * 事業所電話番号
     * @param JIGYOU_TEL_NUM 事業所電話番号
     */
    public void setJIGYOU_TEL_NUM(String JIGYOU_TEL_NUM) {
        this.JIGYOU_TEL_NUM = JIGYOU_TEL_NUM == null ? null : JIGYOU_TEL_NUM.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}