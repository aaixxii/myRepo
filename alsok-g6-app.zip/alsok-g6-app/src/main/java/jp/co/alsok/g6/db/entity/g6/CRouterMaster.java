package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class CRouterMaster implements Serializable {
    /**
     * LN_ルーターマスター論理番号
     */
    private String LN_ROUTER_MASTER;

    /**
     * ルータホスト名
     */
    private String ROUTER_NM;

    /**
     * 有線無線判別フラグ
     */
    private String WR_FLG;

    /**
     * IPアドレス
     */
    private String IP_ADDR;

    /**
     * 断線監視フラグ
     */
    private String DANSEN_FLG;

    /**
     * 正常時断線監視間隔
     */
    private String CONN_DAN_INT;

    /**
     * 断線時断線監視間隔
     */
    private String DCONN_DAN_INT;

    /**
     * 最大リトライ回数
     */
    private String MAX_RETRY_CNT;

    /**
     * リトライ間隔
     */
    private String RETRY_INTERVAL;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * C_ROUTER_MASTER
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_ルーターマスター論理番号
     * @return LN_ROUTER_MASTER LN_ルーターマスター論理番号
     */
    public String getLN_ROUTER_MASTER() {
        return LN_ROUTER_MASTER;
    }

    /**
     * LN_ルーターマスター論理番号
     * @param LN_ROUTER_MASTER LN_ルーターマスター論理番号
     */
    public void setLN_ROUTER_MASTER(String LN_ROUTER_MASTER) {
        this.LN_ROUTER_MASTER = LN_ROUTER_MASTER == null ? null : LN_ROUTER_MASTER.trim();
    }

    /**
     * ルータホスト名
     * @return ROUTER_NM ルータホスト名
     */
    public String getROUTER_NM() {
        return ROUTER_NM;
    }

    /**
     * ルータホスト名
     * @param ROUTER_NM ルータホスト名
     */
    public void setROUTER_NM(String ROUTER_NM) {
        this.ROUTER_NM = ROUTER_NM == null ? null : ROUTER_NM.trim();
    }

    /**
     * 有線無線判別フラグ
     * @return WR_FLG 有線無線判別フラグ
     */
    public String getWR_FLG() {
        return WR_FLG;
    }

    /**
     * 有線無線判別フラグ
     * @param WR_FLG 有線無線判別フラグ
     */
    public void setWR_FLG(String WR_FLG) {
        this.WR_FLG = WR_FLG == null ? null : WR_FLG.trim();
    }

    /**
     * IPアドレス
     * @return IP_ADDR IPアドレス
     */
    public String getIP_ADDR() {
        return IP_ADDR;
    }

    /**
     * IPアドレス
     * @param IP_ADDR IPアドレス
     */
    public void setIP_ADDR(String IP_ADDR) {
        this.IP_ADDR = IP_ADDR == null ? null : IP_ADDR.trim();
    }

    /**
     * 断線監視フラグ
     * @return DANSEN_FLG 断線監視フラグ
     */
    public String getDANSEN_FLG() {
        return DANSEN_FLG;
    }

    /**
     * 断線監視フラグ
     * @param DANSEN_FLG 断線監視フラグ
     */
    public void setDANSEN_FLG(String DANSEN_FLG) {
        this.DANSEN_FLG = DANSEN_FLG == null ? null : DANSEN_FLG.trim();
    }

    /**
     * 正常時断線監視間隔
     * @return CONN_DAN_INT 正常時断線監視間隔
     */
    public String getCONN_DAN_INT() {
        return CONN_DAN_INT;
    }

    /**
     * 正常時断線監視間隔
     * @param CONN_DAN_INT 正常時断線監視間隔
     */
    public void setCONN_DAN_INT(String CONN_DAN_INT) {
        this.CONN_DAN_INT = CONN_DAN_INT == null ? null : CONN_DAN_INT.trim();
    }

    /**
     * 断線時断線監視間隔
     * @return DCONN_DAN_INT 断線時断線監視間隔
     */
    public String getDCONN_DAN_INT() {
        return DCONN_DAN_INT;
    }

    /**
     * 断線時断線監視間隔
     * @param DCONN_DAN_INT 断線時断線監視間隔
     */
    public void setDCONN_DAN_INT(String DCONN_DAN_INT) {
        this.DCONN_DAN_INT = DCONN_DAN_INT == null ? null : DCONN_DAN_INT.trim();
    }

    /**
     * 最大リトライ回数
     * @return MAX_RETRY_CNT 最大リトライ回数
     */
    public String getMAX_RETRY_CNT() {
        return MAX_RETRY_CNT;
    }

    /**
     * 最大リトライ回数
     * @param MAX_RETRY_CNT 最大リトライ回数
     */
    public void setMAX_RETRY_CNT(String MAX_RETRY_CNT) {
        this.MAX_RETRY_CNT = MAX_RETRY_CNT == null ? null : MAX_RETRY_CNT.trim();
    }

    /**
     * リトライ間隔
     * @return RETRY_INTERVAL リトライ間隔
     */
    public String getRETRY_INTERVAL() {
        return RETRY_INTERVAL;
    }

    /**
     * リトライ間隔
     * @param RETRY_INTERVAL リトライ間隔
     */
    public void setRETRY_INTERVAL(String RETRY_INTERVAL) {
        this.RETRY_INTERVAL = RETRY_INTERVAL == null ? null : RETRY_INTERVAL.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}