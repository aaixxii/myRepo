package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class CQueCtrlSig implements Serializable {
    /**
     * LN_制御信号キュー論理番号
     */
    private String LN_QUE_CTRL_SIG;

    /**
     * 発信元ホスト名
     */
    private String HOST_NM;

    /**
     * 電計番号
     */
    private String DENKEI;

    /**
     * 号機番号
     */
    private String GOUKI;

    /**
     * シリアル番号
     */
    private String SERIAL_NUM;

    /**
     * 通信先装置番号
     */
    private String CONN_DEV_NUM;

    /**
     * 装置番号
     */
    private String DEV_NUM;

    /**
     * サブアドレス
     */
    private String SUB_ADDR;

    /**
     * 優先度
     */
    private String PRIORITY;

    /**
     * コマンドシーケンス番号
     */
    private String CMD_SEQ_NUM;

    /**
     * 処理通番
     */
    private String PROCESS_NUM;

    /**
     * コマンドコード
     */
    private String CMD_CD;

    /**
     * 実行コマンド
     */
    private String EXEC_CMD;

    /**
     * ディレクトリ名
     */
    private String DIR_NM;

    /**
     * エンキュー日時
     */
    private Date ENQ_TS;

    /**
     * デキュー可能日時
     */
    private Date DEQ_ABL_TS;

    /**
     * デキュー日時
     */
    private Date DEQ_TS;

    /**
     * 状態
     */
    private String STS;

    /**
     * センタエラー詳細
     */
    private String CENTER_ERR_DTL;

    /**
     * RMSVコマンド通知結果
     */
    private String RM_RESULT;

    /**
     * RMSVコマンド通知エラーコード
     */
    private String RM_ERR_CD;

    /**
     * 制御装置コマンドエラーコード
     */
    private String CTL_RESULT_CD;

    /**
     * 制御装置コマンド実行結果
     */
    private String CTL_CMD_RSLT;

    /**
     * 制御タイムアウト時刻
     */
    private Date CMD_TIMEOUT_TM;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * C_QUE_CTRL_SIG
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_制御信号キュー論理番号
     * @return LN_QUE_CTRL_SIG LN_制御信号キュー論理番号
     */
    public String getLN_QUE_CTRL_SIG() {
        return LN_QUE_CTRL_SIG;
    }

    /**
     * LN_制御信号キュー論理番号
     * @param LN_QUE_CTRL_SIG LN_制御信号キュー論理番号
     */
    public void setLN_QUE_CTRL_SIG(String LN_QUE_CTRL_SIG) {
        this.LN_QUE_CTRL_SIG = LN_QUE_CTRL_SIG == null ? null : LN_QUE_CTRL_SIG.trim();
    }

    /**
     * 発信元ホスト名
     * @return HOST_NM 発信元ホスト名
     */
    public String getHOST_NM() {
        return HOST_NM;
    }

    /**
     * 発信元ホスト名
     * @param HOST_NM 発信元ホスト名
     */
    public void setHOST_NM(String HOST_NM) {
        this.HOST_NM = HOST_NM == null ? null : HOST_NM.trim();
    }

    /**
     * 電計番号
     * @return DENKEI 電計番号
     */
    public String getDENKEI() {
        return DENKEI;
    }

    /**
     * 電計番号
     * @param DENKEI 電計番号
     */
    public void setDENKEI(String DENKEI) {
        this.DENKEI = DENKEI == null ? null : DENKEI.trim();
    }

    /**
     * 号機番号
     * @return GOUKI 号機番号
     */
    public String getGOUKI() {
        return GOUKI;
    }

    /**
     * 号機番号
     * @param GOUKI 号機番号
     */
    public void setGOUKI(String GOUKI) {
        this.GOUKI = GOUKI == null ? null : GOUKI.trim();
    }

    /**
     * シリアル番号
     * @return SERIAL_NUM シリアル番号
     */
    public String getSERIAL_NUM() {
        return SERIAL_NUM;
    }

    /**
     * シリアル番号
     * @param SERIAL_NUM シリアル番号
     */
    public void setSERIAL_NUM(String SERIAL_NUM) {
        this.SERIAL_NUM = SERIAL_NUM == null ? null : SERIAL_NUM.trim();
    }

    /**
     * 通信先装置番号
     * @return CONN_DEV_NUM 通信先装置番号
     */
    public String getCONN_DEV_NUM() {
        return CONN_DEV_NUM;
    }

    /**
     * 通信先装置番号
     * @param CONN_DEV_NUM 通信先装置番号
     */
    public void setCONN_DEV_NUM(String CONN_DEV_NUM) {
        this.CONN_DEV_NUM = CONN_DEV_NUM == null ? null : CONN_DEV_NUM.trim();
    }

    /**
     * 装置番号
     * @return DEV_NUM 装置番号
     */
    public String getDEV_NUM() {
        return DEV_NUM;
    }

    /**
     * 装置番号
     * @param DEV_NUM 装置番号
     */
    public void setDEV_NUM(String DEV_NUM) {
        this.DEV_NUM = DEV_NUM == null ? null : DEV_NUM.trim();
    }

    /**
     * サブアドレス
     * @return SUB_ADDR サブアドレス
     */
    public String getSUB_ADDR() {
        return SUB_ADDR;
    }

    /**
     * サブアドレス
     * @param SUB_ADDR サブアドレス
     */
    public void setSUB_ADDR(String SUB_ADDR) {
        this.SUB_ADDR = SUB_ADDR == null ? null : SUB_ADDR.trim();
    }

    /**
     * 優先度
     * @return PRIORITY 優先度
     */
    public String getPRIORITY() {
        return PRIORITY;
    }

    /**
     * 優先度
     * @param PRIORITY 優先度
     */
    public void setPRIORITY(String PRIORITY) {
        this.PRIORITY = PRIORITY == null ? null : PRIORITY.trim();
    }

    /**
     * コマンドシーケンス番号
     * @return CMD_SEQ_NUM コマンドシーケンス番号
     */
    public String getCMD_SEQ_NUM() {
        return CMD_SEQ_NUM;
    }

    /**
     * コマンドシーケンス番号
     * @param CMD_SEQ_NUM コマンドシーケンス番号
     */
    public void setCMD_SEQ_NUM(String CMD_SEQ_NUM) {
        this.CMD_SEQ_NUM = CMD_SEQ_NUM == null ? null : CMD_SEQ_NUM.trim();
    }

    /**
     * 処理通番
     * @return PROCESS_NUM 処理通番
     */
    public String getPROCESS_NUM() {
        return PROCESS_NUM;
    }

    /**
     * 処理通番
     * @param PROCESS_NUM 処理通番
     */
    public void setPROCESS_NUM(String PROCESS_NUM) {
        this.PROCESS_NUM = PROCESS_NUM == null ? null : PROCESS_NUM.trim();
    }

    /**
     * コマンドコード
     * @return CMD_CD コマンドコード
     */
    public String getCMD_CD() {
        return CMD_CD;
    }

    /**
     * コマンドコード
     * @param CMD_CD コマンドコード
     */
    public void setCMD_CD(String CMD_CD) {
        this.CMD_CD = CMD_CD == null ? null : CMD_CD.trim();
    }

    /**
     * 実行コマンド
     * @return EXEC_CMD 実行コマンド
     */
    public String getEXEC_CMD() {
        return EXEC_CMD;
    }

    /**
     * 実行コマンド
     * @param EXEC_CMD 実行コマンド
     */
    public void setEXEC_CMD(String EXEC_CMD) {
        this.EXEC_CMD = EXEC_CMD == null ? null : EXEC_CMD.trim();
    }

    /**
     * ディレクトリ名
     * @return DIR_NM ディレクトリ名
     */
    public String getDIR_NM() {
        return DIR_NM;
    }

    /**
     * ディレクトリ名
     * @param DIR_NM ディレクトリ名
     */
    public void setDIR_NM(String DIR_NM) {
        this.DIR_NM = DIR_NM == null ? null : DIR_NM.trim();
    }

    /**
     * エンキュー日時
     * @return ENQ_TS エンキュー日時
     */
    public Date getENQ_TS() {
        return ENQ_TS;
    }

    /**
     * エンキュー日時
     * @param ENQ_TS エンキュー日時
     */
    public void setENQ_TS(Date ENQ_TS) {
        this.ENQ_TS = ENQ_TS;
    }

    /**
     * デキュー可能日時
     * @return DEQ_ABL_TS デキュー可能日時
     */
    public Date getDEQ_ABL_TS() {
        return DEQ_ABL_TS;
    }

    /**
     * デキュー可能日時
     * @param DEQ_ABL_TS デキュー可能日時
     */
    public void setDEQ_ABL_TS(Date DEQ_ABL_TS) {
        this.DEQ_ABL_TS = DEQ_ABL_TS;
    }

    /**
     * デキュー日時
     * @return DEQ_TS デキュー日時
     */
    public Date getDEQ_TS() {
        return DEQ_TS;
    }

    /**
     * デキュー日時
     * @param DEQ_TS デキュー日時
     */
    public void setDEQ_TS(Date DEQ_TS) {
        this.DEQ_TS = DEQ_TS;
    }

    /**
     * 状態
     * @return STS 状態
     */
    public String getSTS() {
        return STS;
    }

    /**
     * 状態
     * @param STS 状態
     */
    public void setSTS(String STS) {
        this.STS = STS == null ? null : STS.trim();
    }

    /**
     * センタエラー詳細
     * @return CENTER_ERR_DTL センタエラー詳細
     */
    public String getCENTER_ERR_DTL() {
        return CENTER_ERR_DTL;
    }

    /**
     * センタエラー詳細
     * @param CENTER_ERR_DTL センタエラー詳細
     */
    public void setCENTER_ERR_DTL(String CENTER_ERR_DTL) {
        this.CENTER_ERR_DTL = CENTER_ERR_DTL == null ? null : CENTER_ERR_DTL.trim();
    }

    /**
     * RMSVコマンド通知結果
     * @return RM_RESULT RMSVコマンド通知結果
     */
    public String getRM_RESULT() {
        return RM_RESULT;
    }

    /**
     * RMSVコマンド通知結果
     * @param RM_RESULT RMSVコマンド通知結果
     */
    public void setRM_RESULT(String RM_RESULT) {
        this.RM_RESULT = RM_RESULT == null ? null : RM_RESULT.trim();
    }

    /**
     * RMSVコマンド通知エラーコード
     * @return RM_ERR_CD RMSVコマンド通知エラーコード
     */
    public String getRM_ERR_CD() {
        return RM_ERR_CD;
    }

    /**
     * RMSVコマンド通知エラーコード
     * @param RM_ERR_CD RMSVコマンド通知エラーコード
     */
    public void setRM_ERR_CD(String RM_ERR_CD) {
        this.RM_ERR_CD = RM_ERR_CD == null ? null : RM_ERR_CD.trim();
    }

    /**
     * 制御装置コマンドエラーコード
     * @return CTL_RESULT_CD 制御装置コマンドエラーコード
     */
    public String getCTL_RESULT_CD() {
        return CTL_RESULT_CD;
    }

    /**
     * 制御装置コマンドエラーコード
     * @param CTL_RESULT_CD 制御装置コマンドエラーコード
     */
    public void setCTL_RESULT_CD(String CTL_RESULT_CD) {
        this.CTL_RESULT_CD = CTL_RESULT_CD == null ? null : CTL_RESULT_CD.trim();
    }

    /**
     * 制御装置コマンド実行結果
     * @return CTL_CMD_RSLT 制御装置コマンド実行結果
     */
    public String getCTL_CMD_RSLT() {
        return CTL_CMD_RSLT;
    }

    /**
     * 制御装置コマンド実行結果
     * @param CTL_CMD_RSLT 制御装置コマンド実行結果
     */
    public void setCTL_CMD_RSLT(String CTL_CMD_RSLT) {
        this.CTL_CMD_RSLT = CTL_CMD_RSLT == null ? null : CTL_CMD_RSLT.trim();
    }

    /**
     * 制御タイムアウト時刻
     * @return CMD_TIMEOUT_TM 制御タイムアウト時刻
     */
    public Date getCMD_TIMEOUT_TM() {
        return CMD_TIMEOUT_TM;
    }

    /**
     * 制御タイムアウト時刻
     * @param CMD_TIMEOUT_TM 制御タイムアウト時刻
     */
    public void setCMD_TIMEOUT_TM(Date CMD_TIMEOUT_TM) {
        this.CMD_TIMEOUT_TM = CMD_TIMEOUT_TM;
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}