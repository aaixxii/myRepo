package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EJianDevKbStblExample {
    /**
     * E_JIAN_DEV_KB_STBL
     */
    protected String orderByClause;

    /**
     * E_JIAN_DEV_KB_STBL
     */
    protected boolean distinct;

    /**
     * E_JIAN_DEV_KB_STBL
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public EJianDevKbStblExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * E_JIAN_DEV_KB_STBL null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_JIANIsNull() {
            addCriterion("LN_JIAN is null");
            return (Criteria) this;
        }

        public Criteria andLN_JIANIsNotNull() {
            addCriterion("LN_JIAN is not null");
            return (Criteria) this;
        }

        public Criteria andLN_JIANEqualTo(String value) {
            addCriterion("LN_JIAN =", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANNotEqualTo(String value) {
            addCriterion("LN_JIAN <>", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANGreaterThan(String value) {
            addCriterion("LN_JIAN >", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANGreaterThanOrEqualTo(String value) {
            addCriterion("LN_JIAN >=", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANLessThan(String value) {
            addCriterion("LN_JIAN <", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANLessThanOrEqualTo(String value) {
            addCriterion("LN_JIAN <=", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANLike(String value) {
            addCriterion("LN_JIAN like", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANNotLike(String value) {
            addCriterion("LN_JIAN not like", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANIn(List<String> values) {
            addCriterion("LN_JIAN in", values, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANNotIn(List<String> values) {
            addCriterion("LN_JIAN not in", values, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANBetween(String value1, String value2) {
            addCriterion("LN_JIAN between", value1, value2, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANNotBetween(String value1, String value2) {
            addCriterion("LN_JIAN not between", value1, value2, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_DEVIsNull() {
            addCriterion("LN_DEV is null");
            return (Criteria) this;
        }

        public Criteria andLN_DEVIsNotNull() {
            addCriterion("LN_DEV is not null");
            return (Criteria) this;
        }

        public Criteria andLN_DEVEqualTo(String value) {
            addCriterion("LN_DEV =", value, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVNotEqualTo(String value) {
            addCriterion("LN_DEV <>", value, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVGreaterThan(String value) {
            addCriterion("LN_DEV >", value, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVGreaterThanOrEqualTo(String value) {
            addCriterion("LN_DEV >=", value, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVLessThan(String value) {
            addCriterion("LN_DEV <", value, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVLessThanOrEqualTo(String value) {
            addCriterion("LN_DEV <=", value, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVLike(String value) {
            addCriterion("LN_DEV like", value, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVNotLike(String value) {
            addCriterion("LN_DEV not like", value, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVIn(List<String> values) {
            addCriterion("LN_DEV in", values, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVNotIn(List<String> values) {
            addCriterion("LN_DEV not in", values, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVBetween(String value1, String value2) {
            addCriterion("LN_DEV between", value1, value2, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVNotBetween(String value1, String value2) {
            addCriterion("LN_DEV not between", value1, value2, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUHANIsNull() {
            addCriterion("KEIHO_BOUHAN is null");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUHANIsNotNull() {
            addCriterion("KEIHO_BOUHAN is not null");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUHANEqualTo(String value) {
            addCriterion("KEIHO_BOUHAN =", value, "KEIHO_BOUHAN");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUHANNotEqualTo(String value) {
            addCriterion("KEIHO_BOUHAN <>", value, "KEIHO_BOUHAN");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUHANGreaterThan(String value) {
            addCriterion("KEIHO_BOUHAN >", value, "KEIHO_BOUHAN");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUHANGreaterThanOrEqualTo(String value) {
            addCriterion("KEIHO_BOUHAN >=", value, "KEIHO_BOUHAN");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUHANLessThan(String value) {
            addCriterion("KEIHO_BOUHAN <", value, "KEIHO_BOUHAN");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUHANLessThanOrEqualTo(String value) {
            addCriterion("KEIHO_BOUHAN <=", value, "KEIHO_BOUHAN");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUHANLike(String value) {
            addCriterion("KEIHO_BOUHAN like", value, "KEIHO_BOUHAN");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUHANNotLike(String value) {
            addCriterion("KEIHO_BOUHAN not like", value, "KEIHO_BOUHAN");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUHANIn(List<String> values) {
            addCriterion("KEIHO_BOUHAN in", values, "KEIHO_BOUHAN");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUHANNotIn(List<String> values) {
            addCriterion("KEIHO_BOUHAN not in", values, "KEIHO_BOUHAN");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUHANBetween(String value1, String value2) {
            addCriterion("KEIHO_BOUHAN between", value1, value2, "KEIHO_BOUHAN");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUHANNotBetween(String value1, String value2) {
            addCriterion("KEIHO_BOUHAN not between", value1, value2, "KEIHO_BOUHAN");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HIJYOIsNull() {
            addCriterion("KEIHO_HIJYO is null");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HIJYOIsNotNull() {
            addCriterion("KEIHO_HIJYO is not null");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HIJYOEqualTo(String value) {
            addCriterion("KEIHO_HIJYO =", value, "KEIHO_HIJYO");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HIJYONotEqualTo(String value) {
            addCriterion("KEIHO_HIJYO <>", value, "KEIHO_HIJYO");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HIJYOGreaterThan(String value) {
            addCriterion("KEIHO_HIJYO >", value, "KEIHO_HIJYO");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HIJYOGreaterThanOrEqualTo(String value) {
            addCriterion("KEIHO_HIJYO >=", value, "KEIHO_HIJYO");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HIJYOLessThan(String value) {
            addCriterion("KEIHO_HIJYO <", value, "KEIHO_HIJYO");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HIJYOLessThanOrEqualTo(String value) {
            addCriterion("KEIHO_HIJYO <=", value, "KEIHO_HIJYO");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HIJYOLike(String value) {
            addCriterion("KEIHO_HIJYO like", value, "KEIHO_HIJYO");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HIJYONotLike(String value) {
            addCriterion("KEIHO_HIJYO not like", value, "KEIHO_HIJYO");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HIJYOIn(List<String> values) {
            addCriterion("KEIHO_HIJYO in", values, "KEIHO_HIJYO");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HIJYONotIn(List<String> values) {
            addCriterion("KEIHO_HIJYO not in", values, "KEIHO_HIJYO");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HIJYOBetween(String value1, String value2) {
            addCriterion("KEIHO_HIJYO between", value1, value2, "KEIHO_HIJYO");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HIJYONotBetween(String value1, String value2) {
            addCriterion("KEIHO_HIJYO not between", value1, value2, "KEIHO_HIJYO");
            return (Criteria) this;
        }

        public Criteria andKEIHO_SETUBIIsNull() {
            addCriterion("KEIHO_SETUBI is null");
            return (Criteria) this;
        }

        public Criteria andKEIHO_SETUBIIsNotNull() {
            addCriterion("KEIHO_SETUBI is not null");
            return (Criteria) this;
        }

        public Criteria andKEIHO_SETUBIEqualTo(String value) {
            addCriterion("KEIHO_SETUBI =", value, "KEIHO_SETUBI");
            return (Criteria) this;
        }

        public Criteria andKEIHO_SETUBINotEqualTo(String value) {
            addCriterion("KEIHO_SETUBI <>", value, "KEIHO_SETUBI");
            return (Criteria) this;
        }

        public Criteria andKEIHO_SETUBIGreaterThan(String value) {
            addCriterion("KEIHO_SETUBI >", value, "KEIHO_SETUBI");
            return (Criteria) this;
        }

        public Criteria andKEIHO_SETUBIGreaterThanOrEqualTo(String value) {
            addCriterion("KEIHO_SETUBI >=", value, "KEIHO_SETUBI");
            return (Criteria) this;
        }

        public Criteria andKEIHO_SETUBILessThan(String value) {
            addCriterion("KEIHO_SETUBI <", value, "KEIHO_SETUBI");
            return (Criteria) this;
        }

        public Criteria andKEIHO_SETUBILessThanOrEqualTo(String value) {
            addCriterion("KEIHO_SETUBI <=", value, "KEIHO_SETUBI");
            return (Criteria) this;
        }

        public Criteria andKEIHO_SETUBILike(String value) {
            addCriterion("KEIHO_SETUBI like", value, "KEIHO_SETUBI");
            return (Criteria) this;
        }

        public Criteria andKEIHO_SETUBINotLike(String value) {
            addCriterion("KEIHO_SETUBI not like", value, "KEIHO_SETUBI");
            return (Criteria) this;
        }

        public Criteria andKEIHO_SETUBIIn(List<String> values) {
            addCriterion("KEIHO_SETUBI in", values, "KEIHO_SETUBI");
            return (Criteria) this;
        }

        public Criteria andKEIHO_SETUBINotIn(List<String> values) {
            addCriterion("KEIHO_SETUBI not in", values, "KEIHO_SETUBI");
            return (Criteria) this;
        }

        public Criteria andKEIHO_SETUBIBetween(String value1, String value2) {
            addCriterion("KEIHO_SETUBI between", value1, value2, "KEIHO_SETUBI");
            return (Criteria) this;
        }

        public Criteria andKEIHO_SETUBINotBetween(String value1, String value2) {
            addCriterion("KEIHO_SETUBI not between", value1, value2, "KEIHO_SETUBI");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUSAIIsNull() {
            addCriterion("KEIHO_BOUSAI is null");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUSAIIsNotNull() {
            addCriterion("KEIHO_BOUSAI is not null");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUSAIEqualTo(String value) {
            addCriterion("KEIHO_BOUSAI =", value, "KEIHO_BOUSAI");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUSAINotEqualTo(String value) {
            addCriterion("KEIHO_BOUSAI <>", value, "KEIHO_BOUSAI");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUSAIGreaterThan(String value) {
            addCriterion("KEIHO_BOUSAI >", value, "KEIHO_BOUSAI");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUSAIGreaterThanOrEqualTo(String value) {
            addCriterion("KEIHO_BOUSAI >=", value, "KEIHO_BOUSAI");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUSAILessThan(String value) {
            addCriterion("KEIHO_BOUSAI <", value, "KEIHO_BOUSAI");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUSAILessThanOrEqualTo(String value) {
            addCriterion("KEIHO_BOUSAI <=", value, "KEIHO_BOUSAI");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUSAILike(String value) {
            addCriterion("KEIHO_BOUSAI like", value, "KEIHO_BOUSAI");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUSAINotLike(String value) {
            addCriterion("KEIHO_BOUSAI not like", value, "KEIHO_BOUSAI");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUSAIIn(List<String> values) {
            addCriterion("KEIHO_BOUSAI in", values, "KEIHO_BOUSAI");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUSAINotIn(List<String> values) {
            addCriterion("KEIHO_BOUSAI not in", values, "KEIHO_BOUSAI");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUSAIBetween(String value1, String value2) {
            addCriterion("KEIHO_BOUSAI between", value1, value2, "KEIHO_BOUSAI");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUSAINotBetween(String value1, String value2) {
            addCriterion("KEIHO_BOUSAI not between", value1, value2, "KEIHO_BOUSAI");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HOGOIsNull() {
            addCriterion("KEIHO_HOGO is null");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HOGOIsNotNull() {
            addCriterion("KEIHO_HOGO is not null");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HOGOEqualTo(String value) {
            addCriterion("KEIHO_HOGO =", value, "KEIHO_HOGO");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HOGONotEqualTo(String value) {
            addCriterion("KEIHO_HOGO <>", value, "KEIHO_HOGO");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HOGOGreaterThan(String value) {
            addCriterion("KEIHO_HOGO >", value, "KEIHO_HOGO");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HOGOGreaterThanOrEqualTo(String value) {
            addCriterion("KEIHO_HOGO >=", value, "KEIHO_HOGO");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HOGOLessThan(String value) {
            addCriterion("KEIHO_HOGO <", value, "KEIHO_HOGO");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HOGOLessThanOrEqualTo(String value) {
            addCriterion("KEIHO_HOGO <=", value, "KEIHO_HOGO");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HOGOLike(String value) {
            addCriterion("KEIHO_HOGO like", value, "KEIHO_HOGO");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HOGONotLike(String value) {
            addCriterion("KEIHO_HOGO not like", value, "KEIHO_HOGO");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HOGOIn(List<String> values) {
            addCriterion("KEIHO_HOGO in", values, "KEIHO_HOGO");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HOGONotIn(List<String> values) {
            addCriterion("KEIHO_HOGO not in", values, "KEIHO_HOGO");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HOGOBetween(String value1, String value2) {
            addCriterion("KEIHO_HOGO between", value1, value2, "KEIHO_HOGO");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HOGONotBetween(String value1, String value2) {
            addCriterion("KEIHO_HOGO not between", value1, value2, "KEIHO_HOGO");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SEIJYOIsNull() {
            addCriterion("KOSYO_SEIJYO is null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SEIJYOIsNotNull() {
            addCriterion("KOSYO_SEIJYO is not null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SEIJYOEqualTo(String value) {
            addCriterion("KOSYO_SEIJYO =", value, "KOSYO_SEIJYO");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SEIJYONotEqualTo(String value) {
            addCriterion("KOSYO_SEIJYO <>", value, "KOSYO_SEIJYO");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SEIJYOGreaterThan(String value) {
            addCriterion("KOSYO_SEIJYO >", value, "KOSYO_SEIJYO");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SEIJYOGreaterThanOrEqualTo(String value) {
            addCriterion("KOSYO_SEIJYO >=", value, "KOSYO_SEIJYO");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SEIJYOLessThan(String value) {
            addCriterion("KOSYO_SEIJYO <", value, "KOSYO_SEIJYO");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SEIJYOLessThanOrEqualTo(String value) {
            addCriterion("KOSYO_SEIJYO <=", value, "KOSYO_SEIJYO");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SEIJYOLike(String value) {
            addCriterion("KOSYO_SEIJYO like", value, "KOSYO_SEIJYO");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SEIJYONotLike(String value) {
            addCriterion("KOSYO_SEIJYO not like", value, "KOSYO_SEIJYO");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SEIJYOIn(List<String> values) {
            addCriterion("KOSYO_SEIJYO in", values, "KOSYO_SEIJYO");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SEIJYONotIn(List<String> values) {
            addCriterion("KOSYO_SEIJYO not in", values, "KOSYO_SEIJYO");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SEIJYOBetween(String value1, String value2) {
            addCriterion("KOSYO_SEIJYO between", value1, value2, "KOSYO_SEIJYO");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SEIJYONotBetween(String value1, String value2) {
            addCriterion("KOSYO_SEIJYO not between", value1, value2, "KOSYO_SEIJYO");
            return (Criteria) this;
        }

        public Criteria andKOSYO_IJYOIsNull() {
            addCriterion("KOSYO_IJYO is null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_IJYOIsNotNull() {
            addCriterion("KOSYO_IJYO is not null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_IJYOEqualTo(String value) {
            addCriterion("KOSYO_IJYO =", value, "KOSYO_IJYO");
            return (Criteria) this;
        }

        public Criteria andKOSYO_IJYONotEqualTo(String value) {
            addCriterion("KOSYO_IJYO <>", value, "KOSYO_IJYO");
            return (Criteria) this;
        }

        public Criteria andKOSYO_IJYOGreaterThan(String value) {
            addCriterion("KOSYO_IJYO >", value, "KOSYO_IJYO");
            return (Criteria) this;
        }

        public Criteria andKOSYO_IJYOGreaterThanOrEqualTo(String value) {
            addCriterion("KOSYO_IJYO >=", value, "KOSYO_IJYO");
            return (Criteria) this;
        }

        public Criteria andKOSYO_IJYOLessThan(String value) {
            addCriterion("KOSYO_IJYO <", value, "KOSYO_IJYO");
            return (Criteria) this;
        }

        public Criteria andKOSYO_IJYOLessThanOrEqualTo(String value) {
            addCriterion("KOSYO_IJYO <=", value, "KOSYO_IJYO");
            return (Criteria) this;
        }

        public Criteria andKOSYO_IJYOLike(String value) {
            addCriterion("KOSYO_IJYO like", value, "KOSYO_IJYO");
            return (Criteria) this;
        }

        public Criteria andKOSYO_IJYONotLike(String value) {
            addCriterion("KOSYO_IJYO not like", value, "KOSYO_IJYO");
            return (Criteria) this;
        }

        public Criteria andKOSYO_IJYOIn(List<String> values) {
            addCriterion("KOSYO_IJYO in", values, "KOSYO_IJYO");
            return (Criteria) this;
        }

        public Criteria andKOSYO_IJYONotIn(List<String> values) {
            addCriterion("KOSYO_IJYO not in", values, "KOSYO_IJYO");
            return (Criteria) this;
        }

        public Criteria andKOSYO_IJYOBetween(String value1, String value2) {
            addCriterion("KOSYO_IJYO between", value1, value2, "KOSYO_IJYO");
            return (Criteria) this;
        }

        public Criteria andKOSYO_IJYONotBetween(String value1, String value2) {
            addCriterion("KOSYO_IJYO not between", value1, value2, "KOSYO_IJYO");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SENSIsNull() {
            addCriterion("KOSYO_SENS is null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SENSIsNotNull() {
            addCriterion("KOSYO_SENS is not null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SENSEqualTo(String value) {
            addCriterion("KOSYO_SENS =", value, "KOSYO_SENS");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SENSNotEqualTo(String value) {
            addCriterion("KOSYO_SENS <>", value, "KOSYO_SENS");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SENSGreaterThan(String value) {
            addCriterion("KOSYO_SENS >", value, "KOSYO_SENS");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SENSGreaterThanOrEqualTo(String value) {
            addCriterion("KOSYO_SENS >=", value, "KOSYO_SENS");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SENSLessThan(String value) {
            addCriterion("KOSYO_SENS <", value, "KOSYO_SENS");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SENSLessThanOrEqualTo(String value) {
            addCriterion("KOSYO_SENS <=", value, "KOSYO_SENS");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SENSLike(String value) {
            addCriterion("KOSYO_SENS like", value, "KOSYO_SENS");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SENSNotLike(String value) {
            addCriterion("KOSYO_SENS not like", value, "KOSYO_SENS");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SENSIn(List<String> values) {
            addCriterion("KOSYO_SENS in", values, "KOSYO_SENS");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SENSNotIn(List<String> values) {
            addCriterion("KOSYO_SENS not in", values, "KOSYO_SENS");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SENSBetween(String value1, String value2) {
            addCriterion("KOSYO_SENS between", value1, value2, "KOSYO_SENS");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SENSNotBetween(String value1, String value2) {
            addCriterion("KOSYO_SENS not between", value1, value2, "KOSYO_SENS");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIKIIsNull() {
            addCriterion("KOSYO_KIKI is null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIKIIsNotNull() {
            addCriterion("KOSYO_KIKI is not null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIKIEqualTo(String value) {
            addCriterion("KOSYO_KIKI =", value, "KOSYO_KIKI");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIKINotEqualTo(String value) {
            addCriterion("KOSYO_KIKI <>", value, "KOSYO_KIKI");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIKIGreaterThan(String value) {
            addCriterion("KOSYO_KIKI >", value, "KOSYO_KIKI");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIKIGreaterThanOrEqualTo(String value) {
            addCriterion("KOSYO_KIKI >=", value, "KOSYO_KIKI");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIKILessThan(String value) {
            addCriterion("KOSYO_KIKI <", value, "KOSYO_KIKI");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIKILessThanOrEqualTo(String value) {
            addCriterion("KOSYO_KIKI <=", value, "KOSYO_KIKI");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIKILike(String value) {
            addCriterion("KOSYO_KIKI like", value, "KOSYO_KIKI");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIKINotLike(String value) {
            addCriterion("KOSYO_KIKI not like", value, "KOSYO_KIKI");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIKIIn(List<String> values) {
            addCriterion("KOSYO_KIKI in", values, "KOSYO_KIKI");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIKINotIn(List<String> values) {
            addCriterion("KOSYO_KIKI not in", values, "KOSYO_KIKI");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIKIBetween(String value1, String value2) {
            addCriterion("KOSYO_KIKI between", value1, value2, "KOSYO_KIKI");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIKINotBetween(String value1, String value2) {
            addCriterion("KOSYO_KIKI not between", value1, value2, "KOSYO_KIKI");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DANSENIsNull() {
            addCriterion("KOSYO_DANSEN is null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DANSENIsNotNull() {
            addCriterion("KOSYO_DANSEN is not null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DANSENEqualTo(String value) {
            addCriterion("KOSYO_DANSEN =", value, "KOSYO_DANSEN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DANSENNotEqualTo(String value) {
            addCriterion("KOSYO_DANSEN <>", value, "KOSYO_DANSEN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DANSENGreaterThan(String value) {
            addCriterion("KOSYO_DANSEN >", value, "KOSYO_DANSEN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DANSENGreaterThanOrEqualTo(String value) {
            addCriterion("KOSYO_DANSEN >=", value, "KOSYO_DANSEN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DANSENLessThan(String value) {
            addCriterion("KOSYO_DANSEN <", value, "KOSYO_DANSEN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DANSENLessThanOrEqualTo(String value) {
            addCriterion("KOSYO_DANSEN <=", value, "KOSYO_DANSEN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DANSENLike(String value) {
            addCriterion("KOSYO_DANSEN like", value, "KOSYO_DANSEN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DANSENNotLike(String value) {
            addCriterion("KOSYO_DANSEN not like", value, "KOSYO_DANSEN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DANSENIn(List<String> values) {
            addCriterion("KOSYO_DANSEN in", values, "KOSYO_DANSEN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DANSENNotIn(List<String> values) {
            addCriterion("KOSYO_DANSEN not in", values, "KOSYO_DANSEN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DANSENBetween(String value1, String value2) {
            addCriterion("KOSYO_DANSEN between", value1, value2, "KOSYO_DANSEN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DANSENNotBetween(String value1, String value2) {
            addCriterion("KOSYO_DANSEN not between", value1, value2, "KOSYO_DANSEN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATTIsNull() {
            addCriterion("KOSYO_BATT is null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATTIsNotNull() {
            addCriterion("KOSYO_BATT is not null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATTEqualTo(String value) {
            addCriterion("KOSYO_BATT =", value, "KOSYO_BATT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATTNotEqualTo(String value) {
            addCriterion("KOSYO_BATT <>", value, "KOSYO_BATT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATTGreaterThan(String value) {
            addCriterion("KOSYO_BATT >", value, "KOSYO_BATT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATTGreaterThanOrEqualTo(String value) {
            addCriterion("KOSYO_BATT >=", value, "KOSYO_BATT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATTLessThan(String value) {
            addCriterion("KOSYO_BATT <", value, "KOSYO_BATT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATTLessThanOrEqualTo(String value) {
            addCriterion("KOSYO_BATT <=", value, "KOSYO_BATT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATTLike(String value) {
            addCriterion("KOSYO_BATT like", value, "KOSYO_BATT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATTNotLike(String value) {
            addCriterion("KOSYO_BATT not like", value, "KOSYO_BATT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATTIn(List<String> values) {
            addCriterion("KOSYO_BATT in", values, "KOSYO_BATT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATTNotIn(List<String> values) {
            addCriterion("KOSYO_BATT not in", values, "KOSYO_BATT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATTBetween(String value1, String value2) {
            addCriterion("KOSYO_BATT between", value1, value2, "KOSYO_BATT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATTNotBetween(String value1, String value2) {
            addCriterion("KOSYO_BATT not between", value1, value2, "KOSYO_BATT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_DWNIsNull() {
            addCriterion("KOSYO_PW_DWN is null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_DWNIsNotNull() {
            addCriterion("KOSYO_PW_DWN is not null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_DWNEqualTo(String value) {
            addCriterion("KOSYO_PW_DWN =", value, "KOSYO_PW_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_DWNNotEqualTo(String value) {
            addCriterion("KOSYO_PW_DWN <>", value, "KOSYO_PW_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_DWNGreaterThan(String value) {
            addCriterion("KOSYO_PW_DWN >", value, "KOSYO_PW_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_DWNGreaterThanOrEqualTo(String value) {
            addCriterion("KOSYO_PW_DWN >=", value, "KOSYO_PW_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_DWNLessThan(String value) {
            addCriterion("KOSYO_PW_DWN <", value, "KOSYO_PW_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_DWNLessThanOrEqualTo(String value) {
            addCriterion("KOSYO_PW_DWN <=", value, "KOSYO_PW_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_DWNLike(String value) {
            addCriterion("KOSYO_PW_DWN like", value, "KOSYO_PW_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_DWNNotLike(String value) {
            addCriterion("KOSYO_PW_DWN not like", value, "KOSYO_PW_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_DWNIn(List<String> values) {
            addCriterion("KOSYO_PW_DWN in", values, "KOSYO_PW_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_DWNNotIn(List<String> values) {
            addCriterion("KOSYO_PW_DWN not in", values, "KOSYO_PW_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_DWNBetween(String value1, String value2) {
            addCriterion("KOSYO_PW_DWN between", value1, value2, "KOSYO_PW_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_DWNNotBetween(String value1, String value2) {
            addCriterion("KOSYO_PW_DWN not between", value1, value2, "KOSYO_PW_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KAFUKAIsNull() {
            addCriterion("KOSYO_KAFUKA is null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KAFUKAIsNotNull() {
            addCriterion("KOSYO_KAFUKA is not null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KAFUKAEqualTo(String value) {
            addCriterion("KOSYO_KAFUKA =", value, "KOSYO_KAFUKA");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KAFUKANotEqualTo(String value) {
            addCriterion("KOSYO_KAFUKA <>", value, "KOSYO_KAFUKA");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KAFUKAGreaterThan(String value) {
            addCriterion("KOSYO_KAFUKA >", value, "KOSYO_KAFUKA");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KAFUKAGreaterThanOrEqualTo(String value) {
            addCriterion("KOSYO_KAFUKA >=", value, "KOSYO_KAFUKA");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KAFUKALessThan(String value) {
            addCriterion("KOSYO_KAFUKA <", value, "KOSYO_KAFUKA");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KAFUKALessThanOrEqualTo(String value) {
            addCriterion("KOSYO_KAFUKA <=", value, "KOSYO_KAFUKA");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KAFUKALike(String value) {
            addCriterion("KOSYO_KAFUKA like", value, "KOSYO_KAFUKA");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KAFUKANotLike(String value) {
            addCriterion("KOSYO_KAFUKA not like", value, "KOSYO_KAFUKA");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KAFUKAIn(List<String> values) {
            addCriterion("KOSYO_KAFUKA in", values, "KOSYO_KAFUKA");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KAFUKANotIn(List<String> values) {
            addCriterion("KOSYO_KAFUKA not in", values, "KOSYO_KAFUKA");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KAFUKABetween(String value1, String value2) {
            addCriterion("KOSYO_KAFUKA between", value1, value2, "KOSYO_KAFUKA");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KAFUKANotBetween(String value1, String value2) {
            addCriterion("KOSYO_KAFUKA not between", value1, value2, "KOSYO_KAFUKA");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATT_DWNIsNull() {
            addCriterion("KOSYO_BATT_DWN is null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATT_DWNIsNotNull() {
            addCriterion("KOSYO_BATT_DWN is not null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATT_DWNEqualTo(String value) {
            addCriterion("KOSYO_BATT_DWN =", value, "KOSYO_BATT_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATT_DWNNotEqualTo(String value) {
            addCriterion("KOSYO_BATT_DWN <>", value, "KOSYO_BATT_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATT_DWNGreaterThan(String value) {
            addCriterion("KOSYO_BATT_DWN >", value, "KOSYO_BATT_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATT_DWNGreaterThanOrEqualTo(String value) {
            addCriterion("KOSYO_BATT_DWN >=", value, "KOSYO_BATT_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATT_DWNLessThan(String value) {
            addCriterion("KOSYO_BATT_DWN <", value, "KOSYO_BATT_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATT_DWNLessThanOrEqualTo(String value) {
            addCriterion("KOSYO_BATT_DWN <=", value, "KOSYO_BATT_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATT_DWNLike(String value) {
            addCriterion("KOSYO_BATT_DWN like", value, "KOSYO_BATT_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATT_DWNNotLike(String value) {
            addCriterion("KOSYO_BATT_DWN not like", value, "KOSYO_BATT_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATT_DWNIn(List<String> values) {
            addCriterion("KOSYO_BATT_DWN in", values, "KOSYO_BATT_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATT_DWNNotIn(List<String> values) {
            addCriterion("KOSYO_BATT_DWN not in", values, "KOSYO_BATT_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATT_DWNBetween(String value1, String value2) {
            addCriterion("KOSYO_BATT_DWN between", value1, value2, "KOSYO_BATT_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATT_DWNNotBetween(String value1, String value2) {
            addCriterion("KOSYO_BATT_DWN not between", value1, value2, "KOSYO_BATT_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_HYUZUIsNull() {
            addCriterion("KOSYO_HYUZU is null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_HYUZUIsNotNull() {
            addCriterion("KOSYO_HYUZU is not null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_HYUZUEqualTo(String value) {
            addCriterion("KOSYO_HYUZU =", value, "KOSYO_HYUZU");
            return (Criteria) this;
        }

        public Criteria andKOSYO_HYUZUNotEqualTo(String value) {
            addCriterion("KOSYO_HYUZU <>", value, "KOSYO_HYUZU");
            return (Criteria) this;
        }

        public Criteria andKOSYO_HYUZUGreaterThan(String value) {
            addCriterion("KOSYO_HYUZU >", value, "KOSYO_HYUZU");
            return (Criteria) this;
        }

        public Criteria andKOSYO_HYUZUGreaterThanOrEqualTo(String value) {
            addCriterion("KOSYO_HYUZU >=", value, "KOSYO_HYUZU");
            return (Criteria) this;
        }

        public Criteria andKOSYO_HYUZULessThan(String value) {
            addCriterion("KOSYO_HYUZU <", value, "KOSYO_HYUZU");
            return (Criteria) this;
        }

        public Criteria andKOSYO_HYUZULessThanOrEqualTo(String value) {
            addCriterion("KOSYO_HYUZU <=", value, "KOSYO_HYUZU");
            return (Criteria) this;
        }

        public Criteria andKOSYO_HYUZULike(String value) {
            addCriterion("KOSYO_HYUZU like", value, "KOSYO_HYUZU");
            return (Criteria) this;
        }

        public Criteria andKOSYO_HYUZUNotLike(String value) {
            addCriterion("KOSYO_HYUZU not like", value, "KOSYO_HYUZU");
            return (Criteria) this;
        }

        public Criteria andKOSYO_HYUZUIn(List<String> values) {
            addCriterion("KOSYO_HYUZU in", values, "KOSYO_HYUZU");
            return (Criteria) this;
        }

        public Criteria andKOSYO_HYUZUNotIn(List<String> values) {
            addCriterion("KOSYO_HYUZU not in", values, "KOSYO_HYUZU");
            return (Criteria) this;
        }

        public Criteria andKOSYO_HYUZUBetween(String value1, String value2) {
            addCriterion("KOSYO_HYUZU between", value1, value2, "KOSYO_HYUZU");
            return (Criteria) this;
        }

        public Criteria andKOSYO_HYUZUNotBetween(String value1, String value2) {
            addCriterion("KOSYO_HYUZU not between", value1, value2, "KOSYO_HYUZU");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_BATTIsNull() {
            addCriterion("KOSYO_CON_BATT is null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_BATTIsNotNull() {
            addCriterion("KOSYO_CON_BATT is not null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_BATTEqualTo(String value) {
            addCriterion("KOSYO_CON_BATT =", value, "KOSYO_CON_BATT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_BATTNotEqualTo(String value) {
            addCriterion("KOSYO_CON_BATT <>", value, "KOSYO_CON_BATT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_BATTGreaterThan(String value) {
            addCriterion("KOSYO_CON_BATT >", value, "KOSYO_CON_BATT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_BATTGreaterThanOrEqualTo(String value) {
            addCriterion("KOSYO_CON_BATT >=", value, "KOSYO_CON_BATT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_BATTLessThan(String value) {
            addCriterion("KOSYO_CON_BATT <", value, "KOSYO_CON_BATT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_BATTLessThanOrEqualTo(String value) {
            addCriterion("KOSYO_CON_BATT <=", value, "KOSYO_CON_BATT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_BATTLike(String value) {
            addCriterion("KOSYO_CON_BATT like", value, "KOSYO_CON_BATT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_BATTNotLike(String value) {
            addCriterion("KOSYO_CON_BATT not like", value, "KOSYO_CON_BATT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_BATTIn(List<String> values) {
            addCriterion("KOSYO_CON_BATT in", values, "KOSYO_CON_BATT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_BATTNotIn(List<String> values) {
            addCriterion("KOSYO_CON_BATT not in", values, "KOSYO_CON_BATT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_BATTBetween(String value1, String value2) {
            addCriterion("KOSYO_CON_BATT between", value1, value2, "KOSYO_CON_BATT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_BATTNotBetween(String value1, String value2) {
            addCriterion("KOSYO_CON_BATT not between", value1, value2, "KOSYO_CON_BATT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_SHNTIsNull() {
            addCriterion("KOSYO_LP_SHNT is null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_SHNTIsNotNull() {
            addCriterion("KOSYO_LP_SHNT is not null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_SHNTEqualTo(String value) {
            addCriterion("KOSYO_LP_SHNT =", value, "KOSYO_LP_SHNT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_SHNTNotEqualTo(String value) {
            addCriterion("KOSYO_LP_SHNT <>", value, "KOSYO_LP_SHNT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_SHNTGreaterThan(String value) {
            addCriterion("KOSYO_LP_SHNT >", value, "KOSYO_LP_SHNT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_SHNTGreaterThanOrEqualTo(String value) {
            addCriterion("KOSYO_LP_SHNT >=", value, "KOSYO_LP_SHNT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_SHNTLessThan(String value) {
            addCriterion("KOSYO_LP_SHNT <", value, "KOSYO_LP_SHNT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_SHNTLessThanOrEqualTo(String value) {
            addCriterion("KOSYO_LP_SHNT <=", value, "KOSYO_LP_SHNT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_SHNTLike(String value) {
            addCriterion("KOSYO_LP_SHNT like", value, "KOSYO_LP_SHNT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_SHNTNotLike(String value) {
            addCriterion("KOSYO_LP_SHNT not like", value, "KOSYO_LP_SHNT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_SHNTIn(List<String> values) {
            addCriterion("KOSYO_LP_SHNT in", values, "KOSYO_LP_SHNT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_SHNTNotIn(List<String> values) {
            addCriterion("KOSYO_LP_SHNT not in", values, "KOSYO_LP_SHNT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_SHNTBetween(String value1, String value2) {
            addCriterion("KOSYO_LP_SHNT between", value1, value2, "KOSYO_LP_SHNT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_SHNTNotBetween(String value1, String value2) {
            addCriterion("KOSYO_LP_SHNT not between", value1, value2, "KOSYO_LP_SHNT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_OVER_VIsNull() {
            addCriterion("KOSYO_LP_OVER_V is null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_OVER_VIsNotNull() {
            addCriterion("KOSYO_LP_OVER_V is not null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_OVER_VEqualTo(String value) {
            addCriterion("KOSYO_LP_OVER_V =", value, "KOSYO_LP_OVER_V");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_OVER_VNotEqualTo(String value) {
            addCriterion("KOSYO_LP_OVER_V <>", value, "KOSYO_LP_OVER_V");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_OVER_VGreaterThan(String value) {
            addCriterion("KOSYO_LP_OVER_V >", value, "KOSYO_LP_OVER_V");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_OVER_VGreaterThanOrEqualTo(String value) {
            addCriterion("KOSYO_LP_OVER_V >=", value, "KOSYO_LP_OVER_V");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_OVER_VLessThan(String value) {
            addCriterion("KOSYO_LP_OVER_V <", value, "KOSYO_LP_OVER_V");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_OVER_VLessThanOrEqualTo(String value) {
            addCriterion("KOSYO_LP_OVER_V <=", value, "KOSYO_LP_OVER_V");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_OVER_VLike(String value) {
            addCriterion("KOSYO_LP_OVER_V like", value, "KOSYO_LP_OVER_V");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_OVER_VNotLike(String value) {
            addCriterion("KOSYO_LP_OVER_V not like", value, "KOSYO_LP_OVER_V");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_OVER_VIn(List<String> values) {
            addCriterion("KOSYO_LP_OVER_V in", values, "KOSYO_LP_OVER_V");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_OVER_VNotIn(List<String> values) {
            addCriterion("KOSYO_LP_OVER_V not in", values, "KOSYO_LP_OVER_V");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_OVER_VBetween(String value1, String value2) {
            addCriterion("KOSYO_LP_OVER_V between", value1, value2, "KOSYO_LP_OVER_V");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_OVER_VNotBetween(String value1, String value2) {
            addCriterion("KOSYO_LP_OVER_V not between", value1, value2, "KOSYO_LP_OVER_V");
            return (Criteria) this;
        }

        public Criteria andKOSYO_INP_BATT_DWNIsNull() {
            addCriterion("KOSYO_INP_BATT_DWN is null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_INP_BATT_DWNIsNotNull() {
            addCriterion("KOSYO_INP_BATT_DWN is not null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_INP_BATT_DWNEqualTo(String value) {
            addCriterion("KOSYO_INP_BATT_DWN =", value, "KOSYO_INP_BATT_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_INP_BATT_DWNNotEqualTo(String value) {
            addCriterion("KOSYO_INP_BATT_DWN <>", value, "KOSYO_INP_BATT_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_INP_BATT_DWNGreaterThan(String value) {
            addCriterion("KOSYO_INP_BATT_DWN >", value, "KOSYO_INP_BATT_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_INP_BATT_DWNGreaterThanOrEqualTo(String value) {
            addCriterion("KOSYO_INP_BATT_DWN >=", value, "KOSYO_INP_BATT_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_INP_BATT_DWNLessThan(String value) {
            addCriterion("KOSYO_INP_BATT_DWN <", value, "KOSYO_INP_BATT_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_INP_BATT_DWNLessThanOrEqualTo(String value) {
            addCriterion("KOSYO_INP_BATT_DWN <=", value, "KOSYO_INP_BATT_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_INP_BATT_DWNLike(String value) {
            addCriterion("KOSYO_INP_BATT_DWN like", value, "KOSYO_INP_BATT_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_INP_BATT_DWNNotLike(String value) {
            addCriterion("KOSYO_INP_BATT_DWN not like", value, "KOSYO_INP_BATT_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_INP_BATT_DWNIn(List<String> values) {
            addCriterion("KOSYO_INP_BATT_DWN in", values, "KOSYO_INP_BATT_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_INP_BATT_DWNNotIn(List<String> values) {
            addCriterion("KOSYO_INP_BATT_DWN not in", values, "KOSYO_INP_BATT_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_INP_BATT_DWNBetween(String value1, String value2) {
            addCriterion("KOSYO_INP_BATT_DWN between", value1, value2, "KOSYO_INP_BATT_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_INP_BATT_DWNNotBetween(String value1, String value2) {
            addCriterion("KOSYO_INP_BATT_DWN not between", value1, value2, "KOSYO_INP_BATT_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_NGIsNull() {
            addCriterion("KOSYO_CON_NG is null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_NGIsNotNull() {
            addCriterion("KOSYO_CON_NG is not null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_NGEqualTo(String value) {
            addCriterion("KOSYO_CON_NG =", value, "KOSYO_CON_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_NGNotEqualTo(String value) {
            addCriterion("KOSYO_CON_NG <>", value, "KOSYO_CON_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_NGGreaterThan(String value) {
            addCriterion("KOSYO_CON_NG >", value, "KOSYO_CON_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_NGGreaterThanOrEqualTo(String value) {
            addCriterion("KOSYO_CON_NG >=", value, "KOSYO_CON_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_NGLessThan(String value) {
            addCriterion("KOSYO_CON_NG <", value, "KOSYO_CON_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_NGLessThanOrEqualTo(String value) {
            addCriterion("KOSYO_CON_NG <=", value, "KOSYO_CON_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_NGLike(String value) {
            addCriterion("KOSYO_CON_NG like", value, "KOSYO_CON_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_NGNotLike(String value) {
            addCriterion("KOSYO_CON_NG not like", value, "KOSYO_CON_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_NGIn(List<String> values) {
            addCriterion("KOSYO_CON_NG in", values, "KOSYO_CON_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_NGNotIn(List<String> values) {
            addCriterion("KOSYO_CON_NG not in", values, "KOSYO_CON_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_NGBetween(String value1, String value2) {
            addCriterion("KOSYO_CON_NG between", value1, value2, "KOSYO_CON_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_NGNotBetween(String value1, String value2) {
            addCriterion("KOSYO_CON_NG not between", value1, value2, "KOSYO_CON_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_EMV_NGIsNull() {
            addCriterion("KOSYO_EMV_NG is null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_EMV_NGIsNotNull() {
            addCriterion("KOSYO_EMV_NG is not null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_EMV_NGEqualTo(String value) {
            addCriterion("KOSYO_EMV_NG =", value, "KOSYO_EMV_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_EMV_NGNotEqualTo(String value) {
            addCriterion("KOSYO_EMV_NG <>", value, "KOSYO_EMV_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_EMV_NGGreaterThan(String value) {
            addCriterion("KOSYO_EMV_NG >", value, "KOSYO_EMV_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_EMV_NGGreaterThanOrEqualTo(String value) {
            addCriterion("KOSYO_EMV_NG >=", value, "KOSYO_EMV_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_EMV_NGLessThan(String value) {
            addCriterion("KOSYO_EMV_NG <", value, "KOSYO_EMV_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_EMV_NGLessThanOrEqualTo(String value) {
            addCriterion("KOSYO_EMV_NG <=", value, "KOSYO_EMV_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_EMV_NGLike(String value) {
            addCriterion("KOSYO_EMV_NG like", value, "KOSYO_EMV_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_EMV_NGNotLike(String value) {
            addCriterion("KOSYO_EMV_NG not like", value, "KOSYO_EMV_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_EMV_NGIn(List<String> values) {
            addCriterion("KOSYO_EMV_NG in", values, "KOSYO_EMV_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_EMV_NGNotIn(List<String> values) {
            addCriterion("KOSYO_EMV_NG not in", values, "KOSYO_EMV_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_EMV_NGBetween(String value1, String value2) {
            addCriterion("KOSYO_EMV_NG between", value1, value2, "KOSYO_EMV_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_EMV_NGNotBetween(String value1, String value2) {
            addCriterion("KOSYO_EMV_NG not between", value1, value2, "KOSYO_EMV_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ITI_NGIsNull() {
            addCriterion("KOSYO_ITI_NG is null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ITI_NGIsNotNull() {
            addCriterion("KOSYO_ITI_NG is not null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ITI_NGEqualTo(String value) {
            addCriterion("KOSYO_ITI_NG =", value, "KOSYO_ITI_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ITI_NGNotEqualTo(String value) {
            addCriterion("KOSYO_ITI_NG <>", value, "KOSYO_ITI_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ITI_NGGreaterThan(String value) {
            addCriterion("KOSYO_ITI_NG >", value, "KOSYO_ITI_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ITI_NGGreaterThanOrEqualTo(String value) {
            addCriterion("KOSYO_ITI_NG >=", value, "KOSYO_ITI_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ITI_NGLessThan(String value) {
            addCriterion("KOSYO_ITI_NG <", value, "KOSYO_ITI_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ITI_NGLessThanOrEqualTo(String value) {
            addCriterion("KOSYO_ITI_NG <=", value, "KOSYO_ITI_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ITI_NGLike(String value) {
            addCriterion("KOSYO_ITI_NG like", value, "KOSYO_ITI_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ITI_NGNotLike(String value) {
            addCriterion("KOSYO_ITI_NG not like", value, "KOSYO_ITI_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ITI_NGIn(List<String> values) {
            addCriterion("KOSYO_ITI_NG in", values, "KOSYO_ITI_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ITI_NGNotIn(List<String> values) {
            addCriterion("KOSYO_ITI_NG not in", values, "KOSYO_ITI_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ITI_NGBetween(String value1, String value2) {
            addCriterion("KOSYO_ITI_NG between", value1, value2, "KOSYO_ITI_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ITI_NGNotBetween(String value1, String value2) {
            addCriterion("KOSYO_ITI_NG not between", value1, value2, "KOSYO_ITI_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SJYO_NGIsNull() {
            addCriterion("KOSYO_SJYO_NG is null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SJYO_NGIsNotNull() {
            addCriterion("KOSYO_SJYO_NG is not null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SJYO_NGEqualTo(String value) {
            addCriterion("KOSYO_SJYO_NG =", value, "KOSYO_SJYO_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SJYO_NGNotEqualTo(String value) {
            addCriterion("KOSYO_SJYO_NG <>", value, "KOSYO_SJYO_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SJYO_NGGreaterThan(String value) {
            addCriterion("KOSYO_SJYO_NG >", value, "KOSYO_SJYO_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SJYO_NGGreaterThanOrEqualTo(String value) {
            addCriterion("KOSYO_SJYO_NG >=", value, "KOSYO_SJYO_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SJYO_NGLessThan(String value) {
            addCriterion("KOSYO_SJYO_NG <", value, "KOSYO_SJYO_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SJYO_NGLessThanOrEqualTo(String value) {
            addCriterion("KOSYO_SJYO_NG <=", value, "KOSYO_SJYO_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SJYO_NGLike(String value) {
            addCriterion("KOSYO_SJYO_NG like", value, "KOSYO_SJYO_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SJYO_NGNotLike(String value) {
            addCriterion("KOSYO_SJYO_NG not like", value, "KOSYO_SJYO_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SJYO_NGIn(List<String> values) {
            addCriterion("KOSYO_SJYO_NG in", values, "KOSYO_SJYO_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SJYO_NGNotIn(List<String> values) {
            addCriterion("KOSYO_SJYO_NG not in", values, "KOSYO_SJYO_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SJYO_NGBetween(String value1, String value2) {
            addCriterion("KOSYO_SJYO_NG between", value1, value2, "KOSYO_SJYO_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SJYO_NGNotBetween(String value1, String value2) {
            addCriterion("KOSYO_SJYO_NG not between", value1, value2, "KOSYO_SJYO_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIJYO_NGIsNull() {
            addCriterion("KOSYO_KIJYO_NG is null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIJYO_NGIsNotNull() {
            addCriterion("KOSYO_KIJYO_NG is not null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIJYO_NGEqualTo(String value) {
            addCriterion("KOSYO_KIJYO_NG =", value, "KOSYO_KIJYO_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIJYO_NGNotEqualTo(String value) {
            addCriterion("KOSYO_KIJYO_NG <>", value, "KOSYO_KIJYO_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIJYO_NGGreaterThan(String value) {
            addCriterion("KOSYO_KIJYO_NG >", value, "KOSYO_KIJYO_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIJYO_NGGreaterThanOrEqualTo(String value) {
            addCriterion("KOSYO_KIJYO_NG >=", value, "KOSYO_KIJYO_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIJYO_NGLessThan(String value) {
            addCriterion("KOSYO_KIJYO_NG <", value, "KOSYO_KIJYO_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIJYO_NGLessThanOrEqualTo(String value) {
            addCriterion("KOSYO_KIJYO_NG <=", value, "KOSYO_KIJYO_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIJYO_NGLike(String value) {
            addCriterion("KOSYO_KIJYO_NG like", value, "KOSYO_KIJYO_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIJYO_NGNotLike(String value) {
            addCriterion("KOSYO_KIJYO_NG not like", value, "KOSYO_KIJYO_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIJYO_NGIn(List<String> values) {
            addCriterion("KOSYO_KIJYO_NG in", values, "KOSYO_KIJYO_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIJYO_NGNotIn(List<String> values) {
            addCriterion("KOSYO_KIJYO_NG not in", values, "KOSYO_KIJYO_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIJYO_NGBetween(String value1, String value2) {
            addCriterion("KOSYO_KIJYO_NG between", value1, value2, "KOSYO_KIJYO_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIJYO_NGNotBetween(String value1, String value2) {
            addCriterion("KOSYO_KIJYO_NG not between", value1, value2, "KOSYO_KIJYO_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DOOR_NGIsNull() {
            addCriterion("KOSYO_DOOR_NG is null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DOOR_NGIsNotNull() {
            addCriterion("KOSYO_DOOR_NG is not null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DOOR_NGEqualTo(String value) {
            addCriterion("KOSYO_DOOR_NG =", value, "KOSYO_DOOR_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DOOR_NGNotEqualTo(String value) {
            addCriterion("KOSYO_DOOR_NG <>", value, "KOSYO_DOOR_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DOOR_NGGreaterThan(String value) {
            addCriterion("KOSYO_DOOR_NG >", value, "KOSYO_DOOR_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DOOR_NGGreaterThanOrEqualTo(String value) {
            addCriterion("KOSYO_DOOR_NG >=", value, "KOSYO_DOOR_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DOOR_NGLessThan(String value) {
            addCriterion("KOSYO_DOOR_NG <", value, "KOSYO_DOOR_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DOOR_NGLessThanOrEqualTo(String value) {
            addCriterion("KOSYO_DOOR_NG <=", value, "KOSYO_DOOR_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DOOR_NGLike(String value) {
            addCriterion("KOSYO_DOOR_NG like", value, "KOSYO_DOOR_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DOOR_NGNotLike(String value) {
            addCriterion("KOSYO_DOOR_NG not like", value, "KOSYO_DOOR_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DOOR_NGIn(List<String> values) {
            addCriterion("KOSYO_DOOR_NG in", values, "KOSYO_DOOR_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DOOR_NGNotIn(List<String> values) {
            addCriterion("KOSYO_DOOR_NG not in", values, "KOSYO_DOOR_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DOOR_NGBetween(String value1, String value2) {
            addCriterion("KOSYO_DOOR_NG between", value1, value2, "KOSYO_DOOR_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DOOR_NGNotBetween(String value1, String value2) {
            addCriterion("KOSYO_DOOR_NG not between", value1, value2, "KOSYO_DOOR_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_FALL_NGIsNull() {
            addCriterion("KOSYO_FALL_NG is null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_FALL_NGIsNotNull() {
            addCriterion("KOSYO_FALL_NG is not null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_FALL_NGEqualTo(String value) {
            addCriterion("KOSYO_FALL_NG =", value, "KOSYO_FALL_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_FALL_NGNotEqualTo(String value) {
            addCriterion("KOSYO_FALL_NG <>", value, "KOSYO_FALL_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_FALL_NGGreaterThan(String value) {
            addCriterion("KOSYO_FALL_NG >", value, "KOSYO_FALL_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_FALL_NGGreaterThanOrEqualTo(String value) {
            addCriterion("KOSYO_FALL_NG >=", value, "KOSYO_FALL_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_FALL_NGLessThan(String value) {
            addCriterion("KOSYO_FALL_NG <", value, "KOSYO_FALL_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_FALL_NGLessThanOrEqualTo(String value) {
            addCriterion("KOSYO_FALL_NG <=", value, "KOSYO_FALL_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_FALL_NGLike(String value) {
            addCriterion("KOSYO_FALL_NG like", value, "KOSYO_FALL_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_FALL_NGNotLike(String value) {
            addCriterion("KOSYO_FALL_NG not like", value, "KOSYO_FALL_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_FALL_NGIn(List<String> values) {
            addCriterion("KOSYO_FALL_NG in", values, "KOSYO_FALL_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_FALL_NGNotIn(List<String> values) {
            addCriterion("KOSYO_FALL_NG not in", values, "KOSYO_FALL_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_FALL_NGBetween(String value1, String value2) {
            addCriterion("KOSYO_FALL_NG between", value1, value2, "KOSYO_FALL_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_FALL_NGNotBetween(String value1, String value2) {
            addCriterion("KOSYO_FALL_NG not between", value1, value2, "KOSYO_FALL_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_TNPAIsNull() {
            addCriterion("KOSYO_TNPA is null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_TNPAIsNotNull() {
            addCriterion("KOSYO_TNPA is not null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_TNPAEqualTo(String value) {
            addCriterion("KOSYO_TNPA =", value, "KOSYO_TNPA");
            return (Criteria) this;
        }

        public Criteria andKOSYO_TNPANotEqualTo(String value) {
            addCriterion("KOSYO_TNPA <>", value, "KOSYO_TNPA");
            return (Criteria) this;
        }

        public Criteria andKOSYO_TNPAGreaterThan(String value) {
            addCriterion("KOSYO_TNPA >", value, "KOSYO_TNPA");
            return (Criteria) this;
        }

        public Criteria andKOSYO_TNPAGreaterThanOrEqualTo(String value) {
            addCriterion("KOSYO_TNPA >=", value, "KOSYO_TNPA");
            return (Criteria) this;
        }

        public Criteria andKOSYO_TNPALessThan(String value) {
            addCriterion("KOSYO_TNPA <", value, "KOSYO_TNPA");
            return (Criteria) this;
        }

        public Criteria andKOSYO_TNPALessThanOrEqualTo(String value) {
            addCriterion("KOSYO_TNPA <=", value, "KOSYO_TNPA");
            return (Criteria) this;
        }

        public Criteria andKOSYO_TNPALike(String value) {
            addCriterion("KOSYO_TNPA like", value, "KOSYO_TNPA");
            return (Criteria) this;
        }

        public Criteria andKOSYO_TNPANotLike(String value) {
            addCriterion("KOSYO_TNPA not like", value, "KOSYO_TNPA");
            return (Criteria) this;
        }

        public Criteria andKOSYO_TNPAIn(List<String> values) {
            addCriterion("KOSYO_TNPA in", values, "KOSYO_TNPA");
            return (Criteria) this;
        }

        public Criteria andKOSYO_TNPANotIn(List<String> values) {
            addCriterion("KOSYO_TNPA not in", values, "KOSYO_TNPA");
            return (Criteria) this;
        }

        public Criteria andKOSYO_TNPABetween(String value1, String value2) {
            addCriterion("KOSYO_TNPA between", value1, value2, "KOSYO_TNPA");
            return (Criteria) this;
        }

        public Criteria andKOSYO_TNPANotBetween(String value1, String value2) {
            addCriterion("KOSYO_TNPA not between", value1, value2, "KOSYO_TNPA");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ADDR_DUPIsNull() {
            addCriterion("KOSYO_ADDR_DUP is null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ADDR_DUPIsNotNull() {
            addCriterion("KOSYO_ADDR_DUP is not null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ADDR_DUPEqualTo(String value) {
            addCriterion("KOSYO_ADDR_DUP =", value, "KOSYO_ADDR_DUP");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ADDR_DUPNotEqualTo(String value) {
            addCriterion("KOSYO_ADDR_DUP <>", value, "KOSYO_ADDR_DUP");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ADDR_DUPGreaterThan(String value) {
            addCriterion("KOSYO_ADDR_DUP >", value, "KOSYO_ADDR_DUP");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ADDR_DUPGreaterThanOrEqualTo(String value) {
            addCriterion("KOSYO_ADDR_DUP >=", value, "KOSYO_ADDR_DUP");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ADDR_DUPLessThan(String value) {
            addCriterion("KOSYO_ADDR_DUP <", value, "KOSYO_ADDR_DUP");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ADDR_DUPLessThanOrEqualTo(String value) {
            addCriterion("KOSYO_ADDR_DUP <=", value, "KOSYO_ADDR_DUP");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ADDR_DUPLike(String value) {
            addCriterion("KOSYO_ADDR_DUP like", value, "KOSYO_ADDR_DUP");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ADDR_DUPNotLike(String value) {
            addCriterion("KOSYO_ADDR_DUP not like", value, "KOSYO_ADDR_DUP");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ADDR_DUPIn(List<String> values) {
            addCriterion("KOSYO_ADDR_DUP in", values, "KOSYO_ADDR_DUP");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ADDR_DUPNotIn(List<String> values) {
            addCriterion("KOSYO_ADDR_DUP not in", values, "KOSYO_ADDR_DUP");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ADDR_DUPBetween(String value1, String value2) {
            addCriterion("KOSYO_ADDR_DUP between", value1, value2, "KOSYO_ADDR_DUP");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ADDR_DUPNotBetween(String value1, String value2) {
            addCriterion("KOSYO_ADDR_DUP not between", value1, value2, "KOSYO_ADDR_DUP");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LED_OLDIsNull() {
            addCriterion("KOSYO_LED_OLD is null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LED_OLDIsNotNull() {
            addCriterion("KOSYO_LED_OLD is not null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LED_OLDEqualTo(String value) {
            addCriterion("KOSYO_LED_OLD =", value, "KOSYO_LED_OLD");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LED_OLDNotEqualTo(String value) {
            addCriterion("KOSYO_LED_OLD <>", value, "KOSYO_LED_OLD");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LED_OLDGreaterThan(String value) {
            addCriterion("KOSYO_LED_OLD >", value, "KOSYO_LED_OLD");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LED_OLDGreaterThanOrEqualTo(String value) {
            addCriterion("KOSYO_LED_OLD >=", value, "KOSYO_LED_OLD");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LED_OLDLessThan(String value) {
            addCriterion("KOSYO_LED_OLD <", value, "KOSYO_LED_OLD");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LED_OLDLessThanOrEqualTo(String value) {
            addCriterion("KOSYO_LED_OLD <=", value, "KOSYO_LED_OLD");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LED_OLDLike(String value) {
            addCriterion("KOSYO_LED_OLD like", value, "KOSYO_LED_OLD");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LED_OLDNotLike(String value) {
            addCriterion("KOSYO_LED_OLD not like", value, "KOSYO_LED_OLD");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LED_OLDIn(List<String> values) {
            addCriterion("KOSYO_LED_OLD in", values, "KOSYO_LED_OLD");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LED_OLDNotIn(List<String> values) {
            addCriterion("KOSYO_LED_OLD not in", values, "KOSYO_LED_OLD");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LED_OLDBetween(String value1, String value2) {
            addCriterion("KOSYO_LED_OLD between", value1, value2, "KOSYO_LED_OLD");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LED_OLDNotBetween(String value1, String value2) {
            addCriterion("KOSYO_LED_OLD not between", value1, value2, "KOSYO_LED_OLD");
            return (Criteria) this;
        }

        public Criteria andKOSYOBOGAIIsNull() {
            addCriterion("KOSYOBOGAI is null");
            return (Criteria) this;
        }

        public Criteria andKOSYOBOGAIIsNotNull() {
            addCriterion("KOSYOBOGAI is not null");
            return (Criteria) this;
        }

        public Criteria andKOSYOBOGAIEqualTo(String value) {
            addCriterion("KOSYOBOGAI =", value, "KOSYOBOGAI");
            return (Criteria) this;
        }

        public Criteria andKOSYOBOGAINotEqualTo(String value) {
            addCriterion("KOSYOBOGAI <>", value, "KOSYOBOGAI");
            return (Criteria) this;
        }

        public Criteria andKOSYOBOGAIGreaterThan(String value) {
            addCriterion("KOSYOBOGAI >", value, "KOSYOBOGAI");
            return (Criteria) this;
        }

        public Criteria andKOSYOBOGAIGreaterThanOrEqualTo(String value) {
            addCriterion("KOSYOBOGAI >=", value, "KOSYOBOGAI");
            return (Criteria) this;
        }

        public Criteria andKOSYOBOGAILessThan(String value) {
            addCriterion("KOSYOBOGAI <", value, "KOSYOBOGAI");
            return (Criteria) this;
        }

        public Criteria andKOSYOBOGAILessThanOrEqualTo(String value) {
            addCriterion("KOSYOBOGAI <=", value, "KOSYOBOGAI");
            return (Criteria) this;
        }

        public Criteria andKOSYOBOGAILike(String value) {
            addCriterion("KOSYOBOGAI like", value, "KOSYOBOGAI");
            return (Criteria) this;
        }

        public Criteria andKOSYOBOGAINotLike(String value) {
            addCriterion("KOSYOBOGAI not like", value, "KOSYOBOGAI");
            return (Criteria) this;
        }

        public Criteria andKOSYOBOGAIIn(List<String> values) {
            addCriterion("KOSYOBOGAI in", values, "KOSYOBOGAI");
            return (Criteria) this;
        }

        public Criteria andKOSYOBOGAINotIn(List<String> values) {
            addCriterion("KOSYOBOGAI not in", values, "KOSYOBOGAI");
            return (Criteria) this;
        }

        public Criteria andKOSYOBOGAIBetween(String value1, String value2) {
            addCriterion("KOSYOBOGAI between", value1, value2, "KOSYOBOGAI");
            return (Criteria) this;
        }

        public Criteria andKOSYOBOGAINotBetween(String value1, String value2) {
            addCriterion("KOSYOBOGAI not between", value1, value2, "KOSYOBOGAI");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KOJIAKEIsNull() {
            addCriterion("KOSYO_KOJIAKE is null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KOJIAKEIsNotNull() {
            addCriterion("KOSYO_KOJIAKE is not null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KOJIAKEEqualTo(String value) {
            addCriterion("KOSYO_KOJIAKE =", value, "KOSYO_KOJIAKE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KOJIAKENotEqualTo(String value) {
            addCriterion("KOSYO_KOJIAKE <>", value, "KOSYO_KOJIAKE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KOJIAKEGreaterThan(String value) {
            addCriterion("KOSYO_KOJIAKE >", value, "KOSYO_KOJIAKE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KOJIAKEGreaterThanOrEqualTo(String value) {
            addCriterion("KOSYO_KOJIAKE >=", value, "KOSYO_KOJIAKE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KOJIAKELessThan(String value) {
            addCriterion("KOSYO_KOJIAKE <", value, "KOSYO_KOJIAKE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KOJIAKELessThanOrEqualTo(String value) {
            addCriterion("KOSYO_KOJIAKE <=", value, "KOSYO_KOJIAKE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KOJIAKELike(String value) {
            addCriterion("KOSYO_KOJIAKE like", value, "KOSYO_KOJIAKE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KOJIAKENotLike(String value) {
            addCriterion("KOSYO_KOJIAKE not like", value, "KOSYO_KOJIAKE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KOJIAKEIn(List<String> values) {
            addCriterion("KOSYO_KOJIAKE in", values, "KOSYO_KOJIAKE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KOJIAKENotIn(List<String> values) {
            addCriterion("KOSYO_KOJIAKE not in", values, "KOSYO_KOJIAKE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KOJIAKEBetween(String value1, String value2) {
            addCriterion("KOSYO_KOJIAKE between", value1, value2, "KOSYO_KOJIAKE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KOJIAKENotBetween(String value1, String value2) {
            addCriterion("KOSYO_KOJIAKE not between", value1, value2, "KOSYO_KOJIAKE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_INPIsNull() {
            addCriterion("KOSYO_PW_INP is null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_INPIsNotNull() {
            addCriterion("KOSYO_PW_INP is not null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_INPEqualTo(String value) {
            addCriterion("KOSYO_PW_INP =", value, "KOSYO_PW_INP");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_INPNotEqualTo(String value) {
            addCriterion("KOSYO_PW_INP <>", value, "KOSYO_PW_INP");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_INPGreaterThan(String value) {
            addCriterion("KOSYO_PW_INP >", value, "KOSYO_PW_INP");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_INPGreaterThanOrEqualTo(String value) {
            addCriterion("KOSYO_PW_INP >=", value, "KOSYO_PW_INP");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_INPLessThan(String value) {
            addCriterion("KOSYO_PW_INP <", value, "KOSYO_PW_INP");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_INPLessThanOrEqualTo(String value) {
            addCriterion("KOSYO_PW_INP <=", value, "KOSYO_PW_INP");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_INPLike(String value) {
            addCriterion("KOSYO_PW_INP like", value, "KOSYO_PW_INP");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_INPNotLike(String value) {
            addCriterion("KOSYO_PW_INP not like", value, "KOSYO_PW_INP");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_INPIn(List<String> values) {
            addCriterion("KOSYO_PW_INP in", values, "KOSYO_PW_INP");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_INPNotIn(List<String> values) {
            addCriterion("KOSYO_PW_INP not in", values, "KOSYO_PW_INP");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_INPBetween(String value1, String value2) {
            addCriterion("KOSYO_PW_INP between", value1, value2, "KOSYO_PW_INP");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_INPNotBetween(String value1, String value2) {
            addCriterion("KOSYO_PW_INP not between", value1, value2, "KOSYO_PW_INP");
            return (Criteria) this;
        }

        public Criteria andKOSYO_MAIN_LINEIsNull() {
            addCriterion("KOSYO_MAIN_LINE is null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_MAIN_LINEIsNotNull() {
            addCriterion("KOSYO_MAIN_LINE is not null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_MAIN_LINEEqualTo(String value) {
            addCriterion("KOSYO_MAIN_LINE =", value, "KOSYO_MAIN_LINE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_MAIN_LINENotEqualTo(String value) {
            addCriterion("KOSYO_MAIN_LINE <>", value, "KOSYO_MAIN_LINE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_MAIN_LINEGreaterThan(String value) {
            addCriterion("KOSYO_MAIN_LINE >", value, "KOSYO_MAIN_LINE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_MAIN_LINEGreaterThanOrEqualTo(String value) {
            addCriterion("KOSYO_MAIN_LINE >=", value, "KOSYO_MAIN_LINE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_MAIN_LINELessThan(String value) {
            addCriterion("KOSYO_MAIN_LINE <", value, "KOSYO_MAIN_LINE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_MAIN_LINELessThanOrEqualTo(String value) {
            addCriterion("KOSYO_MAIN_LINE <=", value, "KOSYO_MAIN_LINE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_MAIN_LINELike(String value) {
            addCriterion("KOSYO_MAIN_LINE like", value, "KOSYO_MAIN_LINE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_MAIN_LINENotLike(String value) {
            addCriterion("KOSYO_MAIN_LINE not like", value, "KOSYO_MAIN_LINE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_MAIN_LINEIn(List<String> values) {
            addCriterion("KOSYO_MAIN_LINE in", values, "KOSYO_MAIN_LINE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_MAIN_LINENotIn(List<String> values) {
            addCriterion("KOSYO_MAIN_LINE not in", values, "KOSYO_MAIN_LINE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_MAIN_LINEBetween(String value1, String value2) {
            addCriterion("KOSYO_MAIN_LINE between", value1, value2, "KOSYO_MAIN_LINE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_MAIN_LINENotBetween(String value1, String value2) {
            addCriterion("KOSYO_MAIN_LINE not between", value1, value2, "KOSYO_MAIN_LINE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BACKUP_LINEIsNull() {
            addCriterion("KOSYO_BACKUP_LINE is null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BACKUP_LINEIsNotNull() {
            addCriterion("KOSYO_BACKUP_LINE is not null");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BACKUP_LINEEqualTo(String value) {
            addCriterion("KOSYO_BACKUP_LINE =", value, "KOSYO_BACKUP_LINE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BACKUP_LINENotEqualTo(String value) {
            addCriterion("KOSYO_BACKUP_LINE <>", value, "KOSYO_BACKUP_LINE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BACKUP_LINEGreaterThan(String value) {
            addCriterion("KOSYO_BACKUP_LINE >", value, "KOSYO_BACKUP_LINE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BACKUP_LINEGreaterThanOrEqualTo(String value) {
            addCriterion("KOSYO_BACKUP_LINE >=", value, "KOSYO_BACKUP_LINE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BACKUP_LINELessThan(String value) {
            addCriterion("KOSYO_BACKUP_LINE <", value, "KOSYO_BACKUP_LINE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BACKUP_LINELessThanOrEqualTo(String value) {
            addCriterion("KOSYO_BACKUP_LINE <=", value, "KOSYO_BACKUP_LINE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BACKUP_LINELike(String value) {
            addCriterion("KOSYO_BACKUP_LINE like", value, "KOSYO_BACKUP_LINE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BACKUP_LINENotLike(String value) {
            addCriterion("KOSYO_BACKUP_LINE not like", value, "KOSYO_BACKUP_LINE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BACKUP_LINEIn(List<String> values) {
            addCriterion("KOSYO_BACKUP_LINE in", values, "KOSYO_BACKUP_LINE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BACKUP_LINENotIn(List<String> values) {
            addCriterion("KOSYO_BACKUP_LINE not in", values, "KOSYO_BACKUP_LINE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BACKUP_LINEBetween(String value1, String value2) {
            addCriterion("KOSYO_BACKUP_LINE between", value1, value2, "KOSYO_BACKUP_LINE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BACKUP_LINENotBetween(String value1, String value2) {
            addCriterion("KOSYO_BACKUP_LINE not between", value1, value2, "KOSYO_BACKUP_LINE");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andLN_JIANLikeInsensitive(String value) {
            addCriterion("upper(LN_JIAN) like", value.toUpperCase(), "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_DEVLikeInsensitive(String value) {
            addCriterion("upper(LN_DEV) like", value.toUpperCase(), "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUHANLikeInsensitive(String value) {
            addCriterion("upper(KEIHO_BOUHAN) like", value.toUpperCase(), "KEIHO_BOUHAN");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HIJYOLikeInsensitive(String value) {
            addCriterion("upper(KEIHO_HIJYO) like", value.toUpperCase(), "KEIHO_HIJYO");
            return (Criteria) this;
        }

        public Criteria andKEIHO_SETUBILikeInsensitive(String value) {
            addCriterion("upper(KEIHO_SETUBI) like", value.toUpperCase(), "KEIHO_SETUBI");
            return (Criteria) this;
        }

        public Criteria andKEIHO_BOUSAILikeInsensitive(String value) {
            addCriterion("upper(KEIHO_BOUSAI) like", value.toUpperCase(), "KEIHO_BOUSAI");
            return (Criteria) this;
        }

        public Criteria andKEIHO_HOGOLikeInsensitive(String value) {
            addCriterion("upper(KEIHO_HOGO) like", value.toUpperCase(), "KEIHO_HOGO");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SEIJYOLikeInsensitive(String value) {
            addCriterion("upper(KOSYO_SEIJYO) like", value.toUpperCase(), "KOSYO_SEIJYO");
            return (Criteria) this;
        }

        public Criteria andKOSYO_IJYOLikeInsensitive(String value) {
            addCriterion("upper(KOSYO_IJYO) like", value.toUpperCase(), "KOSYO_IJYO");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SENSLikeInsensitive(String value) {
            addCriterion("upper(KOSYO_SENS) like", value.toUpperCase(), "KOSYO_SENS");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIKILikeInsensitive(String value) {
            addCriterion("upper(KOSYO_KIKI) like", value.toUpperCase(), "KOSYO_KIKI");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DANSENLikeInsensitive(String value) {
            addCriterion("upper(KOSYO_DANSEN) like", value.toUpperCase(), "KOSYO_DANSEN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATTLikeInsensitive(String value) {
            addCriterion("upper(KOSYO_BATT) like", value.toUpperCase(), "KOSYO_BATT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_DWNLikeInsensitive(String value) {
            addCriterion("upper(KOSYO_PW_DWN) like", value.toUpperCase(), "KOSYO_PW_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KAFUKALikeInsensitive(String value) {
            addCriterion("upper(KOSYO_KAFUKA) like", value.toUpperCase(), "KOSYO_KAFUKA");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BATT_DWNLikeInsensitive(String value) {
            addCriterion("upper(KOSYO_BATT_DWN) like", value.toUpperCase(), "KOSYO_BATT_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_HYUZULikeInsensitive(String value) {
            addCriterion("upper(KOSYO_HYUZU) like", value.toUpperCase(), "KOSYO_HYUZU");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_BATTLikeInsensitive(String value) {
            addCriterion("upper(KOSYO_CON_BATT) like", value.toUpperCase(), "KOSYO_CON_BATT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_SHNTLikeInsensitive(String value) {
            addCriterion("upper(KOSYO_LP_SHNT) like", value.toUpperCase(), "KOSYO_LP_SHNT");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LP_OVER_VLikeInsensitive(String value) {
            addCriterion("upper(KOSYO_LP_OVER_V) like", value.toUpperCase(), "KOSYO_LP_OVER_V");
            return (Criteria) this;
        }

        public Criteria andKOSYO_INP_BATT_DWNLikeInsensitive(String value) {
            addCriterion("upper(KOSYO_INP_BATT_DWN) like", value.toUpperCase(), "KOSYO_INP_BATT_DWN");
            return (Criteria) this;
        }

        public Criteria andKOSYO_CON_NGLikeInsensitive(String value) {
            addCriterion("upper(KOSYO_CON_NG) like", value.toUpperCase(), "KOSYO_CON_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_EMV_NGLikeInsensitive(String value) {
            addCriterion("upper(KOSYO_EMV_NG) like", value.toUpperCase(), "KOSYO_EMV_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ITI_NGLikeInsensitive(String value) {
            addCriterion("upper(KOSYO_ITI_NG) like", value.toUpperCase(), "KOSYO_ITI_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_SJYO_NGLikeInsensitive(String value) {
            addCriterion("upper(KOSYO_SJYO_NG) like", value.toUpperCase(), "KOSYO_SJYO_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KIJYO_NGLikeInsensitive(String value) {
            addCriterion("upper(KOSYO_KIJYO_NG) like", value.toUpperCase(), "KOSYO_KIJYO_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_DOOR_NGLikeInsensitive(String value) {
            addCriterion("upper(KOSYO_DOOR_NG) like", value.toUpperCase(), "KOSYO_DOOR_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_FALL_NGLikeInsensitive(String value) {
            addCriterion("upper(KOSYO_FALL_NG) like", value.toUpperCase(), "KOSYO_FALL_NG");
            return (Criteria) this;
        }

        public Criteria andKOSYO_TNPALikeInsensitive(String value) {
            addCriterion("upper(KOSYO_TNPA) like", value.toUpperCase(), "KOSYO_TNPA");
            return (Criteria) this;
        }

        public Criteria andKOSYO_ADDR_DUPLikeInsensitive(String value) {
            addCriterion("upper(KOSYO_ADDR_DUP) like", value.toUpperCase(), "KOSYO_ADDR_DUP");
            return (Criteria) this;
        }

        public Criteria andKOSYO_LED_OLDLikeInsensitive(String value) {
            addCriterion("upper(KOSYO_LED_OLD) like", value.toUpperCase(), "KOSYO_LED_OLD");
            return (Criteria) this;
        }

        public Criteria andKOSYOBOGAILikeInsensitive(String value) {
            addCriterion("upper(KOSYOBOGAI) like", value.toUpperCase(), "KOSYOBOGAI");
            return (Criteria) this;
        }

        public Criteria andKOSYO_KOJIAKELikeInsensitive(String value) {
            addCriterion("upper(KOSYO_KOJIAKE) like", value.toUpperCase(), "KOSYO_KOJIAKE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_PW_INPLikeInsensitive(String value) {
            addCriterion("upper(KOSYO_PW_INP) like", value.toUpperCase(), "KOSYO_PW_INP");
            return (Criteria) this;
        }

        public Criteria andKOSYO_MAIN_LINELikeInsensitive(String value) {
            addCriterion("upper(KOSYO_MAIN_LINE) like", value.toUpperCase(), "KOSYO_MAIN_LINE");
            return (Criteria) this;
        }

        public Criteria andKOSYO_BACKUP_LINELikeInsensitive(String value) {
            addCriterion("upper(KOSYO_BACKUP_LINE) like", value.toUpperCase(), "KOSYO_BACKUP_LINE");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * E_JIAN_DEV_KB_STBL
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * E_JIAN_DEV_KB_STBL null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}