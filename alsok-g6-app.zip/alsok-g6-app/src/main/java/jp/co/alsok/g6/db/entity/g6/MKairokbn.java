package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class MKairokbn implements Serializable {
    /**
     * ID回路区分
     */
    private String ID_KAIRO_KBN;

    /**
     * 回路区分
     */
    private String KAIRO_KBN;

    /**
     * M_KAIROKBN
     */
    private static final long serialVersionUID = 1L;

    /**
     * ID回路区分
     * @return ID_KAIRO_KBN ID回路区分
     */
    public String getID_KAIRO_KBN() {
        return ID_KAIRO_KBN;
    }

    /**
     * ID回路区分
     * @param ID_KAIRO_KBN ID回路区分
     */
    public void setID_KAIRO_KBN(String ID_KAIRO_KBN) {
        this.ID_KAIRO_KBN = ID_KAIRO_KBN == null ? null : ID_KAIRO_KBN.trim();
    }

    /**
     * 回路区分
     * @return KAIRO_KBN 回路区分
     */
    public String getKAIRO_KBN() {
        return KAIRO_KBN;
    }

    /**
     * 回路区分
     * @param KAIRO_KBN 回路区分
     */
    public void setKAIRO_KBN(String KAIRO_KBN) {
        this.KAIRO_KBN = KAIRO_KBN == null ? null : KAIRO_KBN.trim();
    }
}