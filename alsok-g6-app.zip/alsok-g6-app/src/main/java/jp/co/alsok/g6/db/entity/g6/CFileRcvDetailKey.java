package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class CFileRcvDetailKey implements Serializable {
    /**
     * LN_ファイル受信論理番号
     */
    private String LN_FILE_RCV;

    /**
     * 処理通番
     */
    private String PROCESS_NUM;

    /**
     * C_FILE_RCV_DETAIL
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_ファイル受信論理番号
     * @return LN_FILE_RCV LN_ファイル受信論理番号
     */
    public String getLN_FILE_RCV() {
        return LN_FILE_RCV;
    }

    /**
     * LN_ファイル受信論理番号
     * @param LN_FILE_RCV LN_ファイル受信論理番号
     */
    public void setLN_FILE_RCV(String LN_FILE_RCV) {
        this.LN_FILE_RCV = LN_FILE_RCV == null ? null : LN_FILE_RCV.trim();
    }

    /**
     * 処理通番
     * @return PROCESS_NUM 処理通番
     */
    public String getPROCESS_NUM() {
        return PROCESS_NUM;
    }

    /**
     * 処理通番
     * @param PROCESS_NUM 処理通番
     */
    public void setPROCESS_NUM(String PROCESS_NUM) {
        this.PROCESS_NUM = PROCESS_NUM == null ? null : PROCESS_NUM.trim();
    }
}