package jp.co.alsok.g6.db.entity.com;

import java.io.Serializable;

public class KAreaMstKey implements Serializable {
    /**
     * エリアコード
     */
    private String AREA_CD;

    /**
     * GCコード
     */
    private String GC_CD;

    /**
     * K_AREA_MST
     */
    private static final long serialVersionUID = 1L;

    /**
     * エリアコード
     * @return AREA_CD エリアコード
     */
    public String getAREA_CD() {
        return AREA_CD;
    }

    /**
     * エリアコード
     * @param AREA_CD エリアコード
     */
    public void setAREA_CD(String AREA_CD) {
        this.AREA_CD = AREA_CD == null ? null : AREA_CD.trim();
    }

    /**
     * GCコード
     * @return GC_CD GCコード
     */
    public String getGC_CD() {
        return GC_CD;
    }

    /**
     * GCコード
     * @param GC_CD GCコード
     */
    public void setGC_CD(String GC_CD) {
        this.GC_CD = GC_CD == null ? null : GC_CD.trim();
    }
}