package jp.co.alsok.g6.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import jp.co.alsok.g6.zwu.interceptor.DoubleloginCheckInterceptor;

@EnableWebMvc
@Configuration
@ComponentScan
public class WuWebConfig implements WebMvcConfigurer {

	@Bean
	public DoubleloginCheckInterceptor doubleloginCheckInterceptor() {
		return new DoubleloginCheckInterceptor();
	}
	
	@Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(doubleloginCheckInterceptor()).addPathPatterns("/**").excludePathPatterns("/login/**");
    }
	
}
