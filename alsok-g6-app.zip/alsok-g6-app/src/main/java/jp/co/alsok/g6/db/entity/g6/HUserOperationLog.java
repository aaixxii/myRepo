package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class HUserOperationLog implements Serializable {
    /**
     * LN_利用者操作履歴論理番号
     */
    private String LN_LOG_USER_OPERATION;

    /**
     * 警備先名称
     */
    private String KEIBI_NM;

    /**
     * 警備先地区名称（SD_個別名称）
     */
    private String SD_KOBETU_NM;

    /**
     * 氏名（社員名／ユーザー氏名）
     */
    private String USER_NM;

    /**
     * 操作者種別
     */
    private String USER_KIND;

    /**
     * 操作画面ID
     */
    private String DISP_ID;

    /**
     * 操作内容コード
     */
    private String USER_OPERATION_NAIYOU_CD;

    /**
     * 内容
     */
    private String USER_OPERATION_NAIYOU;

    /**
     * 利用者ロール名
     */
    private String USER_ROLE_NM;

    /**
     * 備考
     */
    private String BIKOU;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * H_USER_OPERATION_LOG
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_利用者操作履歴論理番号
     * @return LN_LOG_USER_OPERATION LN_利用者操作履歴論理番号
     */
    public String getLN_LOG_USER_OPERATION() {
        return LN_LOG_USER_OPERATION;
    }

    /**
     * LN_利用者操作履歴論理番号
     * @param LN_LOG_USER_OPERATION LN_利用者操作履歴論理番号
     */
    public void setLN_LOG_USER_OPERATION(String LN_LOG_USER_OPERATION) {
        this.LN_LOG_USER_OPERATION = LN_LOG_USER_OPERATION == null ? null : LN_LOG_USER_OPERATION.trim();
    }

    /**
     * 警備先名称
     * @return KEIBI_NM 警備先名称
     */
    public String getKEIBI_NM() {
        return KEIBI_NM;
    }

    /**
     * 警備先名称
     * @param KEIBI_NM 警備先名称
     */
    public void setKEIBI_NM(String KEIBI_NM) {
        this.KEIBI_NM = KEIBI_NM == null ? null : KEIBI_NM.trim();
    }

    /**
     * 警備先地区名称（SD_個別名称）
     * @return SD_KOBETU_NM 警備先地区名称（SD_個別名称）
     */
    public String getSD_KOBETU_NM() {
        return SD_KOBETU_NM;
    }

    /**
     * 警備先地区名称（SD_個別名称）
     * @param SD_KOBETU_NM 警備先地区名称（SD_個別名称）
     */
    public void setSD_KOBETU_NM(String SD_KOBETU_NM) {
        this.SD_KOBETU_NM = SD_KOBETU_NM == null ? null : SD_KOBETU_NM.trim();
    }

    /**
     * 氏名（社員名／ユーザー氏名）
     * @return USER_NM 氏名（社員名／ユーザー氏名）
     */
    public String getUSER_NM() {
        return USER_NM;
    }

    /**
     * 氏名（社員名／ユーザー氏名）
     * @param USER_NM 氏名（社員名／ユーザー氏名）
     */
    public void setUSER_NM(String USER_NM) {
        this.USER_NM = USER_NM == null ? null : USER_NM.trim();
    }

    /**
     * 操作者種別
     * @return USER_KIND 操作者種別
     */
    public String getUSER_KIND() {
        return USER_KIND;
    }

    /**
     * 操作者種別
     * @param USER_KIND 操作者種別
     */
    public void setUSER_KIND(String USER_KIND) {
        this.USER_KIND = USER_KIND == null ? null : USER_KIND.trim();
    }

    /**
     * 操作画面ID
     * @return DISP_ID 操作画面ID
     */
    public String getDISP_ID() {
        return DISP_ID;
    }

    /**
     * 操作画面ID
     * @param DISP_ID 操作画面ID
     */
    public void setDISP_ID(String DISP_ID) {
        this.DISP_ID = DISP_ID == null ? null : DISP_ID.trim();
    }

    /**
     * 操作内容コード
     * @return USER_OPERATION_NAIYOU_CD 操作内容コード
     */
    public String getUSER_OPERATION_NAIYOU_CD() {
        return USER_OPERATION_NAIYOU_CD;
    }

    /**
     * 操作内容コード
     * @param USER_OPERATION_NAIYOU_CD 操作内容コード
     */
    public void setUSER_OPERATION_NAIYOU_CD(String USER_OPERATION_NAIYOU_CD) {
        this.USER_OPERATION_NAIYOU_CD = USER_OPERATION_NAIYOU_CD == null ? null : USER_OPERATION_NAIYOU_CD.trim();
    }

    /**
     * 内容
     * @return USER_OPERATION_NAIYOU 内容
     */
    public String getUSER_OPERATION_NAIYOU() {
        return USER_OPERATION_NAIYOU;
    }

    /**
     * 内容
     * @param USER_OPERATION_NAIYOU 内容
     */
    public void setUSER_OPERATION_NAIYOU(String USER_OPERATION_NAIYOU) {
        this.USER_OPERATION_NAIYOU = USER_OPERATION_NAIYOU == null ? null : USER_OPERATION_NAIYOU.trim();
    }

    /**
     * 利用者ロール名
     * @return USER_ROLE_NM 利用者ロール名
     */
    public String getUSER_ROLE_NM() {
        return USER_ROLE_NM;
    }

    /**
     * 利用者ロール名
     * @param USER_ROLE_NM 利用者ロール名
     */
    public void setUSER_ROLE_NM(String USER_ROLE_NM) {
        this.USER_ROLE_NM = USER_ROLE_NM == null ? null : USER_ROLE_NM.trim();
    }

    /**
     * 備考
     * @return BIKOU 備考
     */
    public String getBIKOU() {
        return BIKOU;
    }

    /**
     * 備考
     * @param BIKOU 備考
     */
    public void setBIKOU(String BIKOU) {
        this.BIKOU = BIKOU == null ? null : BIKOU.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}