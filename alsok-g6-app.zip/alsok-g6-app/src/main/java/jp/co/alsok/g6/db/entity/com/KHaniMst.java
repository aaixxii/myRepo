package jp.co.alsok.g6.db.entity.com;

import java.io.Serializable;
import java.util.Date;

public class KHaniMst implements Serializable {
    /**
     * LN_範囲論理番号
     */
    private String LN_HANI;

    /**
     * 範囲
     */
    private String ID_HANI;

    /**
     * 範囲名称
     */
    private String HANI_NM;

    /**
     * GCコード
     */
    private String GC_CD;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * K_HANI_MST
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_範囲論理番号
     * @return LN_HANI LN_範囲論理番号
     */
    public String getLN_HANI() {
        return LN_HANI;
    }

    /**
     * LN_範囲論理番号
     * @param LN_HANI LN_範囲論理番号
     */
    public void setLN_HANI(String LN_HANI) {
        this.LN_HANI = LN_HANI == null ? null : LN_HANI.trim();
    }

    /**
     * 範囲
     * @return ID_HANI 範囲
     */
    public String getID_HANI() {
        return ID_HANI;
    }

    /**
     * 範囲
     * @param ID_HANI 範囲
     */
    public void setID_HANI(String ID_HANI) {
        this.ID_HANI = ID_HANI == null ? null : ID_HANI.trim();
    }

    /**
     * 範囲名称
     * @return HANI_NM 範囲名称
     */
    public String getHANI_NM() {
        return HANI_NM;
    }

    /**
     * 範囲名称
     * @param HANI_NM 範囲名称
     */
    public void setHANI_NM(String HANI_NM) {
        this.HANI_NM = HANI_NM == null ? null : HANI_NM.trim();
    }

    /**
     * GCコード
     * @return GC_CD GCコード
     */
    public String getGC_CD() {
        return GC_CD;
    }

    /**
     * GCコード
     * @param GC_CD GCコード
     */
    public void setGC_CD(String GC_CD) {
        this.GC_CD = GC_CD == null ? null : GC_CD.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}