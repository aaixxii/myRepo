package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HRmckCmpDtl2Example {
    /**
     * H_RMCK_CMP_DTL2
     */
    protected String orderByClause;

    /**
     * H_RMCK_CMP_DTL2
     */
    protected boolean distinct;

    /**
     * H_RMCK_CMP_DTL2
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public HRmckCmpDtl2Example() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * H_RMCK_CMP_DTL2 null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_RMCK_CMP_DTL2IsNull() {
            addCriterion("LN_RMCK_CMP_DTL2 is null");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMP_DTL2IsNotNull() {
            addCriterion("LN_RMCK_CMP_DTL2 is not null");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMP_DTL2EqualTo(String value) {
            addCriterion("LN_RMCK_CMP_DTL2 =", value, "LN_RMCK_CMP_DTL2");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMP_DTL2NotEqualTo(String value) {
            addCriterion("LN_RMCK_CMP_DTL2 <>", value, "LN_RMCK_CMP_DTL2");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMP_DTL2GreaterThan(String value) {
            addCriterion("LN_RMCK_CMP_DTL2 >", value, "LN_RMCK_CMP_DTL2");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMP_DTL2GreaterThanOrEqualTo(String value) {
            addCriterion("LN_RMCK_CMP_DTL2 >=", value, "LN_RMCK_CMP_DTL2");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMP_DTL2LessThan(String value) {
            addCriterion("LN_RMCK_CMP_DTL2 <", value, "LN_RMCK_CMP_DTL2");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMP_DTL2LessThanOrEqualTo(String value) {
            addCriterion("LN_RMCK_CMP_DTL2 <=", value, "LN_RMCK_CMP_DTL2");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMP_DTL2Like(String value) {
            addCriterion("LN_RMCK_CMP_DTL2 like", value, "LN_RMCK_CMP_DTL2");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMP_DTL2NotLike(String value) {
            addCriterion("LN_RMCK_CMP_DTL2 not like", value, "LN_RMCK_CMP_DTL2");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMP_DTL2In(List<String> values) {
            addCriterion("LN_RMCK_CMP_DTL2 in", values, "LN_RMCK_CMP_DTL2");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMP_DTL2NotIn(List<String> values) {
            addCriterion("LN_RMCK_CMP_DTL2 not in", values, "LN_RMCK_CMP_DTL2");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMP_DTL2Between(String value1, String value2) {
            addCriterion("LN_RMCK_CMP_DTL2 between", value1, value2, "LN_RMCK_CMP_DTL2");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMP_DTL2NotBetween(String value1, String value2) {
            addCriterion("LN_RMCK_CMP_DTL2 not between", value1, value2, "LN_RMCK_CMP_DTL2");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMPIsNull() {
            addCriterion("LN_RMCK_CMP is null");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMPIsNotNull() {
            addCriterion("LN_RMCK_CMP is not null");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMPEqualTo(String value) {
            addCriterion("LN_RMCK_CMP =", value, "LN_RMCK_CMP");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMPNotEqualTo(String value) {
            addCriterion("LN_RMCK_CMP <>", value, "LN_RMCK_CMP");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMPGreaterThan(String value) {
            addCriterion("LN_RMCK_CMP >", value, "LN_RMCK_CMP");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMPGreaterThanOrEqualTo(String value) {
            addCriterion("LN_RMCK_CMP >=", value, "LN_RMCK_CMP");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMPLessThan(String value) {
            addCriterion("LN_RMCK_CMP <", value, "LN_RMCK_CMP");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMPLessThanOrEqualTo(String value) {
            addCriterion("LN_RMCK_CMP <=", value, "LN_RMCK_CMP");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMPLike(String value) {
            addCriterion("LN_RMCK_CMP like", value, "LN_RMCK_CMP");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMPNotLike(String value) {
            addCriterion("LN_RMCK_CMP not like", value, "LN_RMCK_CMP");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMPIn(List<String> values) {
            addCriterion("LN_RMCK_CMP in", values, "LN_RMCK_CMP");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMPNotIn(List<String> values) {
            addCriterion("LN_RMCK_CMP not in", values, "LN_RMCK_CMP");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMPBetween(String value1, String value2) {
            addCriterion("LN_RMCK_CMP between", value1, value2, "LN_RMCK_CMP");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMPNotBetween(String value1, String value2) {
            addCriterion("LN_RMCK_CMP not between", value1, value2, "LN_RMCK_CMP");
            return (Criteria) this;
        }

        public Criteria andCAMR_NOIsNull() {
            addCriterion("CAMR_NO is null");
            return (Criteria) this;
        }

        public Criteria andCAMR_NOIsNotNull() {
            addCriterion("CAMR_NO is not null");
            return (Criteria) this;
        }

        public Criteria andCAMR_NOEqualTo(String value) {
            addCriterion("CAMR_NO =", value, "CAMR_NO");
            return (Criteria) this;
        }

        public Criteria andCAMR_NONotEqualTo(String value) {
            addCriterion("CAMR_NO <>", value, "CAMR_NO");
            return (Criteria) this;
        }

        public Criteria andCAMR_NOGreaterThan(String value) {
            addCriterion("CAMR_NO >", value, "CAMR_NO");
            return (Criteria) this;
        }

        public Criteria andCAMR_NOGreaterThanOrEqualTo(String value) {
            addCriterion("CAMR_NO >=", value, "CAMR_NO");
            return (Criteria) this;
        }

        public Criteria andCAMR_NOLessThan(String value) {
            addCriterion("CAMR_NO <", value, "CAMR_NO");
            return (Criteria) this;
        }

        public Criteria andCAMR_NOLessThanOrEqualTo(String value) {
            addCriterion("CAMR_NO <=", value, "CAMR_NO");
            return (Criteria) this;
        }

        public Criteria andCAMR_NOLike(String value) {
            addCriterion("CAMR_NO like", value, "CAMR_NO");
            return (Criteria) this;
        }

        public Criteria andCAMR_NONotLike(String value) {
            addCriterion("CAMR_NO not like", value, "CAMR_NO");
            return (Criteria) this;
        }

        public Criteria andCAMR_NOIn(List<String> values) {
            addCriterion("CAMR_NO in", values, "CAMR_NO");
            return (Criteria) this;
        }

        public Criteria andCAMR_NONotIn(List<String> values) {
            addCriterion("CAMR_NO not in", values, "CAMR_NO");
            return (Criteria) this;
        }

        public Criteria andCAMR_NOBetween(String value1, String value2) {
            addCriterion("CAMR_NO between", value1, value2, "CAMR_NO");
            return (Criteria) this;
        }

        public Criteria andCAMR_NONotBetween(String value1, String value2) {
            addCriterion("CAMR_NO not between", value1, value2, "CAMR_NO");
            return (Criteria) this;
        }

        public Criteria andWLUP_STIsNull() {
            addCriterion("WLUP_ST is null");
            return (Criteria) this;
        }

        public Criteria andWLUP_STIsNotNull() {
            addCriterion("WLUP_ST is not null");
            return (Criteria) this;
        }

        public Criteria andWLUP_STEqualTo(String value) {
            addCriterion("WLUP_ST =", value, "WLUP_ST");
            return (Criteria) this;
        }

        public Criteria andWLUP_STNotEqualTo(String value) {
            addCriterion("WLUP_ST <>", value, "WLUP_ST");
            return (Criteria) this;
        }

        public Criteria andWLUP_STGreaterThan(String value) {
            addCriterion("WLUP_ST >", value, "WLUP_ST");
            return (Criteria) this;
        }

        public Criteria andWLUP_STGreaterThanOrEqualTo(String value) {
            addCriterion("WLUP_ST >=", value, "WLUP_ST");
            return (Criteria) this;
        }

        public Criteria andWLUP_STLessThan(String value) {
            addCriterion("WLUP_ST <", value, "WLUP_ST");
            return (Criteria) this;
        }

        public Criteria andWLUP_STLessThanOrEqualTo(String value) {
            addCriterion("WLUP_ST <=", value, "WLUP_ST");
            return (Criteria) this;
        }

        public Criteria andWLUP_STLike(String value) {
            addCriterion("WLUP_ST like", value, "WLUP_ST");
            return (Criteria) this;
        }

        public Criteria andWLUP_STNotLike(String value) {
            addCriterion("WLUP_ST not like", value, "WLUP_ST");
            return (Criteria) this;
        }

        public Criteria andWLUP_STIn(List<String> values) {
            addCriterion("WLUP_ST in", values, "WLUP_ST");
            return (Criteria) this;
        }

        public Criteria andWLUP_STNotIn(List<String> values) {
            addCriterion("WLUP_ST not in", values, "WLUP_ST");
            return (Criteria) this;
        }

        public Criteria andWLUP_STBetween(String value1, String value2) {
            addCriterion("WLUP_ST between", value1, value2, "WLUP_ST");
            return (Criteria) this;
        }

        public Criteria andWLUP_STNotBetween(String value1, String value2) {
            addCriterion("WLUP_ST not between", value1, value2, "WLUP_ST");
            return (Criteria) this;
        }

        public Criteria andBLUP_STIsNull() {
            addCriterion("BLUP_ST is null");
            return (Criteria) this;
        }

        public Criteria andBLUP_STIsNotNull() {
            addCriterion("BLUP_ST is not null");
            return (Criteria) this;
        }

        public Criteria andBLUP_STEqualTo(String value) {
            addCriterion("BLUP_ST =", value, "BLUP_ST");
            return (Criteria) this;
        }

        public Criteria andBLUP_STNotEqualTo(String value) {
            addCriterion("BLUP_ST <>", value, "BLUP_ST");
            return (Criteria) this;
        }

        public Criteria andBLUP_STGreaterThan(String value) {
            addCriterion("BLUP_ST >", value, "BLUP_ST");
            return (Criteria) this;
        }

        public Criteria andBLUP_STGreaterThanOrEqualTo(String value) {
            addCriterion("BLUP_ST >=", value, "BLUP_ST");
            return (Criteria) this;
        }

        public Criteria andBLUP_STLessThan(String value) {
            addCriterion("BLUP_ST <", value, "BLUP_ST");
            return (Criteria) this;
        }

        public Criteria andBLUP_STLessThanOrEqualTo(String value) {
            addCriterion("BLUP_ST <=", value, "BLUP_ST");
            return (Criteria) this;
        }

        public Criteria andBLUP_STLike(String value) {
            addCriterion("BLUP_ST like", value, "BLUP_ST");
            return (Criteria) this;
        }

        public Criteria andBLUP_STNotLike(String value) {
            addCriterion("BLUP_ST not like", value, "BLUP_ST");
            return (Criteria) this;
        }

        public Criteria andBLUP_STIn(List<String> values) {
            addCriterion("BLUP_ST in", values, "BLUP_ST");
            return (Criteria) this;
        }

        public Criteria andBLUP_STNotIn(List<String> values) {
            addCriterion("BLUP_ST not in", values, "BLUP_ST");
            return (Criteria) this;
        }

        public Criteria andBLUP_STBetween(String value1, String value2) {
            addCriterion("BLUP_ST between", value1, value2, "BLUP_ST");
            return (Criteria) this;
        }

        public Criteria andBLUP_STNotBetween(String value1, String value2) {
            addCriterion("BLUP_ST not between", value1, value2, "BLUP_ST");
            return (Criteria) this;
        }

        public Criteria andLIST_NOIsNull() {
            addCriterion("LIST_NO is null");
            return (Criteria) this;
        }

        public Criteria andLIST_NOIsNotNull() {
            addCriterion("LIST_NO is not null");
            return (Criteria) this;
        }

        public Criteria andLIST_NOEqualTo(String value) {
            addCriterion("LIST_NO =", value, "LIST_NO");
            return (Criteria) this;
        }

        public Criteria andLIST_NONotEqualTo(String value) {
            addCriterion("LIST_NO <>", value, "LIST_NO");
            return (Criteria) this;
        }

        public Criteria andLIST_NOGreaterThan(String value) {
            addCriterion("LIST_NO >", value, "LIST_NO");
            return (Criteria) this;
        }

        public Criteria andLIST_NOGreaterThanOrEqualTo(String value) {
            addCriterion("LIST_NO >=", value, "LIST_NO");
            return (Criteria) this;
        }

        public Criteria andLIST_NOLessThan(String value) {
            addCriterion("LIST_NO <", value, "LIST_NO");
            return (Criteria) this;
        }

        public Criteria andLIST_NOLessThanOrEqualTo(String value) {
            addCriterion("LIST_NO <=", value, "LIST_NO");
            return (Criteria) this;
        }

        public Criteria andLIST_NOLike(String value) {
            addCriterion("LIST_NO like", value, "LIST_NO");
            return (Criteria) this;
        }

        public Criteria andLIST_NONotLike(String value) {
            addCriterion("LIST_NO not like", value, "LIST_NO");
            return (Criteria) this;
        }

        public Criteria andLIST_NOIn(List<String> values) {
            addCriterion("LIST_NO in", values, "LIST_NO");
            return (Criteria) this;
        }

        public Criteria andLIST_NONotIn(List<String> values) {
            addCriterion("LIST_NO not in", values, "LIST_NO");
            return (Criteria) this;
        }

        public Criteria andLIST_NOBetween(String value1, String value2) {
            addCriterion("LIST_NO between", value1, value2, "LIST_NO");
            return (Criteria) this;
        }

        public Criteria andLIST_NONotBetween(String value1, String value2) {
            addCriterion("LIST_NO not between", value1, value2, "LIST_NO");
            return (Criteria) this;
        }

        public Criteria andCAMERAS1_STIsNull() {
            addCriterion("CAMERAS1_ST is null");
            return (Criteria) this;
        }

        public Criteria andCAMERAS1_STIsNotNull() {
            addCriterion("CAMERAS1_ST is not null");
            return (Criteria) this;
        }

        public Criteria andCAMERAS1_STEqualTo(String value) {
            addCriterion("CAMERAS1_ST =", value, "CAMERAS1_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS1_STNotEqualTo(String value) {
            addCriterion("CAMERAS1_ST <>", value, "CAMERAS1_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS1_STGreaterThan(String value) {
            addCriterion("CAMERAS1_ST >", value, "CAMERAS1_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS1_STGreaterThanOrEqualTo(String value) {
            addCriterion("CAMERAS1_ST >=", value, "CAMERAS1_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS1_STLessThan(String value) {
            addCriterion("CAMERAS1_ST <", value, "CAMERAS1_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS1_STLessThanOrEqualTo(String value) {
            addCriterion("CAMERAS1_ST <=", value, "CAMERAS1_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS1_STLike(String value) {
            addCriterion("CAMERAS1_ST like", value, "CAMERAS1_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS1_STNotLike(String value) {
            addCriterion("CAMERAS1_ST not like", value, "CAMERAS1_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS1_STIn(List<String> values) {
            addCriterion("CAMERAS1_ST in", values, "CAMERAS1_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS1_STNotIn(List<String> values) {
            addCriterion("CAMERAS1_ST not in", values, "CAMERAS1_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS1_STBetween(String value1, String value2) {
            addCriterion("CAMERAS1_ST between", value1, value2, "CAMERAS1_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS1_STNotBetween(String value1, String value2) {
            addCriterion("CAMERAS1_ST not between", value1, value2, "CAMERAS1_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS2_STIsNull() {
            addCriterion("CAMERAS2_ST is null");
            return (Criteria) this;
        }

        public Criteria andCAMERAS2_STIsNotNull() {
            addCriterion("CAMERAS2_ST is not null");
            return (Criteria) this;
        }

        public Criteria andCAMERAS2_STEqualTo(String value) {
            addCriterion("CAMERAS2_ST =", value, "CAMERAS2_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS2_STNotEqualTo(String value) {
            addCriterion("CAMERAS2_ST <>", value, "CAMERAS2_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS2_STGreaterThan(String value) {
            addCriterion("CAMERAS2_ST >", value, "CAMERAS2_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS2_STGreaterThanOrEqualTo(String value) {
            addCriterion("CAMERAS2_ST >=", value, "CAMERAS2_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS2_STLessThan(String value) {
            addCriterion("CAMERAS2_ST <", value, "CAMERAS2_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS2_STLessThanOrEqualTo(String value) {
            addCriterion("CAMERAS2_ST <=", value, "CAMERAS2_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS2_STLike(String value) {
            addCriterion("CAMERAS2_ST like", value, "CAMERAS2_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS2_STNotLike(String value) {
            addCriterion("CAMERAS2_ST not like", value, "CAMERAS2_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS2_STIn(List<String> values) {
            addCriterion("CAMERAS2_ST in", values, "CAMERAS2_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS2_STNotIn(List<String> values) {
            addCriterion("CAMERAS2_ST not in", values, "CAMERAS2_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS2_STBetween(String value1, String value2) {
            addCriterion("CAMERAS2_ST between", value1, value2, "CAMERAS2_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS2_STNotBetween(String value1, String value2) {
            addCriterion("CAMERAS2_ST not between", value1, value2, "CAMERAS2_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS3_STIsNull() {
            addCriterion("CAMERAS3_ST is null");
            return (Criteria) this;
        }

        public Criteria andCAMERAS3_STIsNotNull() {
            addCriterion("CAMERAS3_ST is not null");
            return (Criteria) this;
        }

        public Criteria andCAMERAS3_STEqualTo(String value) {
            addCriterion("CAMERAS3_ST =", value, "CAMERAS3_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS3_STNotEqualTo(String value) {
            addCriterion("CAMERAS3_ST <>", value, "CAMERAS3_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS3_STGreaterThan(String value) {
            addCriterion("CAMERAS3_ST >", value, "CAMERAS3_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS3_STGreaterThanOrEqualTo(String value) {
            addCriterion("CAMERAS3_ST >=", value, "CAMERAS3_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS3_STLessThan(String value) {
            addCriterion("CAMERAS3_ST <", value, "CAMERAS3_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS3_STLessThanOrEqualTo(String value) {
            addCriterion("CAMERAS3_ST <=", value, "CAMERAS3_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS3_STLike(String value) {
            addCriterion("CAMERAS3_ST like", value, "CAMERAS3_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS3_STNotLike(String value) {
            addCriterion("CAMERAS3_ST not like", value, "CAMERAS3_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS3_STIn(List<String> values) {
            addCriterion("CAMERAS3_ST in", values, "CAMERAS3_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS3_STNotIn(List<String> values) {
            addCriterion("CAMERAS3_ST not in", values, "CAMERAS3_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS3_STBetween(String value1, String value2) {
            addCriterion("CAMERAS3_ST between", value1, value2, "CAMERAS3_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS3_STNotBetween(String value1, String value2) {
            addCriterion("CAMERAS3_ST not between", value1, value2, "CAMERAS3_ST");
            return (Criteria) this;
        }

        public Criteria andVFILENMIsNull() {
            addCriterion("VFILENM is null");
            return (Criteria) this;
        }

        public Criteria andVFILENMIsNotNull() {
            addCriterion("VFILENM is not null");
            return (Criteria) this;
        }

        public Criteria andVFILENMEqualTo(String value) {
            addCriterion("VFILENM =", value, "VFILENM");
            return (Criteria) this;
        }

        public Criteria andVFILENMNotEqualTo(String value) {
            addCriterion("VFILENM <>", value, "VFILENM");
            return (Criteria) this;
        }

        public Criteria andVFILENMGreaterThan(String value) {
            addCriterion("VFILENM >", value, "VFILENM");
            return (Criteria) this;
        }

        public Criteria andVFILENMGreaterThanOrEqualTo(String value) {
            addCriterion("VFILENM >=", value, "VFILENM");
            return (Criteria) this;
        }

        public Criteria andVFILENMLessThan(String value) {
            addCriterion("VFILENM <", value, "VFILENM");
            return (Criteria) this;
        }

        public Criteria andVFILENMLessThanOrEqualTo(String value) {
            addCriterion("VFILENM <=", value, "VFILENM");
            return (Criteria) this;
        }

        public Criteria andVFILENMLike(String value) {
            addCriterion("VFILENM like", value, "VFILENM");
            return (Criteria) this;
        }

        public Criteria andVFILENMNotLike(String value) {
            addCriterion("VFILENM not like", value, "VFILENM");
            return (Criteria) this;
        }

        public Criteria andVFILENMIn(List<String> values) {
            addCriterion("VFILENM in", values, "VFILENM");
            return (Criteria) this;
        }

        public Criteria andVFILENMNotIn(List<String> values) {
            addCriterion("VFILENM not in", values, "VFILENM");
            return (Criteria) this;
        }

        public Criteria andVFILENMBetween(String value1, String value2) {
            addCriterion("VFILENM between", value1, value2, "VFILENM");
            return (Criteria) this;
        }

        public Criteria andVFILENMNotBetween(String value1, String value2) {
            addCriterion("VFILENM not between", value1, value2, "VFILENM");
            return (Criteria) this;
        }

        public Criteria andFL_RATEIsNull() {
            addCriterion("FL_RATE is null");
            return (Criteria) this;
        }

        public Criteria andFL_RATEIsNotNull() {
            addCriterion("FL_RATE is not null");
            return (Criteria) this;
        }

        public Criteria andFL_RATEEqualTo(String value) {
            addCriterion("FL_RATE =", value, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATENotEqualTo(String value) {
            addCriterion("FL_RATE <>", value, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATEGreaterThan(String value) {
            addCriterion("FL_RATE >", value, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATEGreaterThanOrEqualTo(String value) {
            addCriterion("FL_RATE >=", value, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATELessThan(String value) {
            addCriterion("FL_RATE <", value, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATELessThanOrEqualTo(String value) {
            addCriterion("FL_RATE <=", value, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATELike(String value) {
            addCriterion("FL_RATE like", value, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATENotLike(String value) {
            addCriterion("FL_RATE not like", value, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATEIn(List<String> values) {
            addCriterion("FL_RATE in", values, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATENotIn(List<String> values) {
            addCriterion("FL_RATE not in", values, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATEBetween(String value1, String value2) {
            addCriterion("FL_RATE between", value1, value2, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATENotBetween(String value1, String value2) {
            addCriterion("FL_RATE not between", value1, value2, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andVR_TIMEIsNull() {
            addCriterion("VR_TIME is null");
            return (Criteria) this;
        }

        public Criteria andVR_TIMEIsNotNull() {
            addCriterion("VR_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andVR_TIMEEqualTo(String value) {
            addCriterion("VR_TIME =", value, "VR_TIME");
            return (Criteria) this;
        }

        public Criteria andVR_TIMENotEqualTo(String value) {
            addCriterion("VR_TIME <>", value, "VR_TIME");
            return (Criteria) this;
        }

        public Criteria andVR_TIMEGreaterThan(String value) {
            addCriterion("VR_TIME >", value, "VR_TIME");
            return (Criteria) this;
        }

        public Criteria andVR_TIMEGreaterThanOrEqualTo(String value) {
            addCriterion("VR_TIME >=", value, "VR_TIME");
            return (Criteria) this;
        }

        public Criteria andVR_TIMELessThan(String value) {
            addCriterion("VR_TIME <", value, "VR_TIME");
            return (Criteria) this;
        }

        public Criteria andVR_TIMELessThanOrEqualTo(String value) {
            addCriterion("VR_TIME <=", value, "VR_TIME");
            return (Criteria) this;
        }

        public Criteria andVR_TIMELike(String value) {
            addCriterion("VR_TIME like", value, "VR_TIME");
            return (Criteria) this;
        }

        public Criteria andVR_TIMENotLike(String value) {
            addCriterion("VR_TIME not like", value, "VR_TIME");
            return (Criteria) this;
        }

        public Criteria andVR_TIMEIn(List<String> values) {
            addCriterion("VR_TIME in", values, "VR_TIME");
            return (Criteria) this;
        }

        public Criteria andVR_TIMENotIn(List<String> values) {
            addCriterion("VR_TIME not in", values, "VR_TIME");
            return (Criteria) this;
        }

        public Criteria andVR_TIMEBetween(String value1, String value2) {
            addCriterion("VR_TIME between", value1, value2, "VR_TIME");
            return (Criteria) this;
        }

        public Criteria andVR_TIMENotBetween(String value1, String value2) {
            addCriterion("VR_TIME not between", value1, value2, "VR_TIME");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTIsNull() {
            addCriterion("VR_ACNT is null");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTIsNotNull() {
            addCriterion("VR_ACNT is not null");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTEqualTo(String value) {
            addCriterion("VR_ACNT =", value, "VR_ACNT");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTNotEqualTo(String value) {
            addCriterion("VR_ACNT <>", value, "VR_ACNT");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTGreaterThan(String value) {
            addCriterion("VR_ACNT >", value, "VR_ACNT");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTGreaterThanOrEqualTo(String value) {
            addCriterion("VR_ACNT >=", value, "VR_ACNT");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTLessThan(String value) {
            addCriterion("VR_ACNT <", value, "VR_ACNT");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTLessThanOrEqualTo(String value) {
            addCriterion("VR_ACNT <=", value, "VR_ACNT");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTLike(String value) {
            addCriterion("VR_ACNT like", value, "VR_ACNT");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTNotLike(String value) {
            addCriterion("VR_ACNT not like", value, "VR_ACNT");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTIn(List<String> values) {
            addCriterion("VR_ACNT in", values, "VR_ACNT");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTNotIn(List<String> values) {
            addCriterion("VR_ACNT not in", values, "VR_ACNT");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTBetween(String value1, String value2) {
            addCriterion("VR_ACNT between", value1, value2, "VR_ACNT");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTNotBetween(String value1, String value2) {
            addCriterion("VR_ACNT not between", value1, value2, "VR_ACNT");
            return (Criteria) this;
        }

        public Criteria andVR_STRTIsNull() {
            addCriterion("VR_STRT is null");
            return (Criteria) this;
        }

        public Criteria andVR_STRTIsNotNull() {
            addCriterion("VR_STRT is not null");
            return (Criteria) this;
        }

        public Criteria andVR_STRTEqualTo(String value) {
            addCriterion("VR_STRT =", value, "VR_STRT");
            return (Criteria) this;
        }

        public Criteria andVR_STRTNotEqualTo(String value) {
            addCriterion("VR_STRT <>", value, "VR_STRT");
            return (Criteria) this;
        }

        public Criteria andVR_STRTGreaterThan(String value) {
            addCriterion("VR_STRT >", value, "VR_STRT");
            return (Criteria) this;
        }

        public Criteria andVR_STRTGreaterThanOrEqualTo(String value) {
            addCriterion("VR_STRT >=", value, "VR_STRT");
            return (Criteria) this;
        }

        public Criteria andVR_STRTLessThan(String value) {
            addCriterion("VR_STRT <", value, "VR_STRT");
            return (Criteria) this;
        }

        public Criteria andVR_STRTLessThanOrEqualTo(String value) {
            addCriterion("VR_STRT <=", value, "VR_STRT");
            return (Criteria) this;
        }

        public Criteria andVR_STRTLike(String value) {
            addCriterion("VR_STRT like", value, "VR_STRT");
            return (Criteria) this;
        }

        public Criteria andVR_STRTNotLike(String value) {
            addCriterion("VR_STRT not like", value, "VR_STRT");
            return (Criteria) this;
        }

        public Criteria andVR_STRTIn(List<String> values) {
            addCriterion("VR_STRT in", values, "VR_STRT");
            return (Criteria) this;
        }

        public Criteria andVR_STRTNotIn(List<String> values) {
            addCriterion("VR_STRT not in", values, "VR_STRT");
            return (Criteria) this;
        }

        public Criteria andVR_STRTBetween(String value1, String value2) {
            addCriterion("VR_STRT between", value1, value2, "VR_STRT");
            return (Criteria) this;
        }

        public Criteria andVR_STRTNotBetween(String value1, String value2) {
            addCriterion("VR_STRT not between", value1, value2, "VR_STRT");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTIsNull() {
            addCriterion("VFCOUNT is null");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTIsNotNull() {
            addCriterion("VFCOUNT is not null");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTEqualTo(String value) {
            addCriterion("VFCOUNT =", value, "VFCOUNT");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTNotEqualTo(String value) {
            addCriterion("VFCOUNT <>", value, "VFCOUNT");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTGreaterThan(String value) {
            addCriterion("VFCOUNT >", value, "VFCOUNT");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTGreaterThanOrEqualTo(String value) {
            addCriterion("VFCOUNT >=", value, "VFCOUNT");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTLessThan(String value) {
            addCriterion("VFCOUNT <", value, "VFCOUNT");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTLessThanOrEqualTo(String value) {
            addCriterion("VFCOUNT <=", value, "VFCOUNT");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTLike(String value) {
            addCriterion("VFCOUNT like", value, "VFCOUNT");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTNotLike(String value) {
            addCriterion("VFCOUNT not like", value, "VFCOUNT");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTIn(List<String> values) {
            addCriterion("VFCOUNT in", values, "VFCOUNT");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTNotIn(List<String> values) {
            addCriterion("VFCOUNT not in", values, "VFCOUNT");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTBetween(String value1, String value2) {
            addCriterion("VFCOUNT between", value1, value2, "VFCOUNT");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTNotBetween(String value1, String value2) {
            addCriterion("VFCOUNT not between", value1, value2, "VFCOUNT");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKIsNull() {
            addCriterion("MCSP_LK is null");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKIsNotNull() {
            addCriterion("MCSP_LK is not null");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKEqualTo(String value) {
            addCriterion("MCSP_LK =", value, "MCSP_LK");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKNotEqualTo(String value) {
            addCriterion("MCSP_LK <>", value, "MCSP_LK");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKGreaterThan(String value) {
            addCriterion("MCSP_LK >", value, "MCSP_LK");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKGreaterThanOrEqualTo(String value) {
            addCriterion("MCSP_LK >=", value, "MCSP_LK");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKLessThan(String value) {
            addCriterion("MCSP_LK <", value, "MCSP_LK");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKLessThanOrEqualTo(String value) {
            addCriterion("MCSP_LK <=", value, "MCSP_LK");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKLike(String value) {
            addCriterion("MCSP_LK like", value, "MCSP_LK");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKNotLike(String value) {
            addCriterion("MCSP_LK not like", value, "MCSP_LK");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKIn(List<String> values) {
            addCriterion("MCSP_LK in", values, "MCSP_LK");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKNotIn(List<String> values) {
            addCriterion("MCSP_LK not in", values, "MCSP_LK");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKBetween(String value1, String value2) {
            addCriterion("MCSP_LK between", value1, value2, "MCSP_LK");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKNotBetween(String value1, String value2) {
            addCriterion("MCSP_LK not between", value1, value2, "MCSP_LK");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMP_DTL2LikeInsensitive(String value) {
            addCriterion("upper(LN_RMCK_CMP_DTL2) like", value.toUpperCase(), "LN_RMCK_CMP_DTL2");
            return (Criteria) this;
        }

        public Criteria andLN_RMCK_CMPLikeInsensitive(String value) {
            addCriterion("upper(LN_RMCK_CMP) like", value.toUpperCase(), "LN_RMCK_CMP");
            return (Criteria) this;
        }

        public Criteria andCAMR_NOLikeInsensitive(String value) {
            addCriterion("upper(CAMR_NO) like", value.toUpperCase(), "CAMR_NO");
            return (Criteria) this;
        }

        public Criteria andWLUP_STLikeInsensitive(String value) {
            addCriterion("upper(WLUP_ST) like", value.toUpperCase(), "WLUP_ST");
            return (Criteria) this;
        }

        public Criteria andBLUP_STLikeInsensitive(String value) {
            addCriterion("upper(BLUP_ST) like", value.toUpperCase(), "BLUP_ST");
            return (Criteria) this;
        }

        public Criteria andLIST_NOLikeInsensitive(String value) {
            addCriterion("upper(LIST_NO) like", value.toUpperCase(), "LIST_NO");
            return (Criteria) this;
        }

        public Criteria andCAMERAS1_STLikeInsensitive(String value) {
            addCriterion("upper(CAMERAS1_ST) like", value.toUpperCase(), "CAMERAS1_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS2_STLikeInsensitive(String value) {
            addCriterion("upper(CAMERAS2_ST) like", value.toUpperCase(), "CAMERAS2_ST");
            return (Criteria) this;
        }

        public Criteria andCAMERAS3_STLikeInsensitive(String value) {
            addCriterion("upper(CAMERAS3_ST) like", value.toUpperCase(), "CAMERAS3_ST");
            return (Criteria) this;
        }

        public Criteria andVFILENMLikeInsensitive(String value) {
            addCriterion("upper(VFILENM) like", value.toUpperCase(), "VFILENM");
            return (Criteria) this;
        }

        public Criteria andFL_RATELikeInsensitive(String value) {
            addCriterion("upper(FL_RATE) like", value.toUpperCase(), "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andVR_TIMELikeInsensitive(String value) {
            addCriterion("upper(VR_TIME) like", value.toUpperCase(), "VR_TIME");
            return (Criteria) this;
        }

        public Criteria andVR_ACNTLikeInsensitive(String value) {
            addCriterion("upper(VR_ACNT) like", value.toUpperCase(), "VR_ACNT");
            return (Criteria) this;
        }

        public Criteria andVR_STRTLikeInsensitive(String value) {
            addCriterion("upper(VR_STRT) like", value.toUpperCase(), "VR_STRT");
            return (Criteria) this;
        }

        public Criteria andVFCOUNTLikeInsensitive(String value) {
            addCriterion("upper(VFCOUNT) like", value.toUpperCase(), "VFCOUNT");
            return (Criteria) this;
        }

        public Criteria andMCSP_LKLikeInsensitive(String value) {
            addCriterion("upper(MCSP_LK) like", value.toUpperCase(), "MCSP_LK");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * H_RMCK_CMP_DTL2
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * H_RMCK_CMP_DTL2 null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}