package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.List;

public class MCdExample {
    /**
     * M_CD
     */
    protected String orderByClause;

    /**
     * M_CD
     */
    protected boolean distinct;

    /**
     * M_CD
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public MCdExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * M_CD null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andCD_IDIsNull() {
            addCriterion("CD_ID is null");
            return (Criteria) this;
        }

        public Criteria andCD_IDIsNotNull() {
            addCriterion("CD_ID is not null");
            return (Criteria) this;
        }

        public Criteria andCD_IDEqualTo(String value) {
            addCriterion("CD_ID =", value, "CD_ID");
            return (Criteria) this;
        }

        public Criteria andCD_IDNotEqualTo(String value) {
            addCriterion("CD_ID <>", value, "CD_ID");
            return (Criteria) this;
        }

        public Criteria andCD_IDGreaterThan(String value) {
            addCriterion("CD_ID >", value, "CD_ID");
            return (Criteria) this;
        }

        public Criteria andCD_IDGreaterThanOrEqualTo(String value) {
            addCriterion("CD_ID >=", value, "CD_ID");
            return (Criteria) this;
        }

        public Criteria andCD_IDLessThan(String value) {
            addCriterion("CD_ID <", value, "CD_ID");
            return (Criteria) this;
        }

        public Criteria andCD_IDLessThanOrEqualTo(String value) {
            addCriterion("CD_ID <=", value, "CD_ID");
            return (Criteria) this;
        }

        public Criteria andCD_IDLike(String value) {
            addCriterion("CD_ID like", value, "CD_ID");
            return (Criteria) this;
        }

        public Criteria andCD_IDNotLike(String value) {
            addCriterion("CD_ID not like", value, "CD_ID");
            return (Criteria) this;
        }

        public Criteria andCD_IDIn(List<String> values) {
            addCriterion("CD_ID in", values, "CD_ID");
            return (Criteria) this;
        }

        public Criteria andCD_IDNotIn(List<String> values) {
            addCriterion("CD_ID not in", values, "CD_ID");
            return (Criteria) this;
        }

        public Criteria andCD_IDBetween(String value1, String value2) {
            addCriterion("CD_ID between", value1, value2, "CD_ID");
            return (Criteria) this;
        }

        public Criteria andCD_IDNotBetween(String value1, String value2) {
            addCriterion("CD_ID not between", value1, value2, "CD_ID");
            return (Criteria) this;
        }

        public Criteria andCD_VALUEIsNull() {
            addCriterion("CD_VALUE is null");
            return (Criteria) this;
        }

        public Criteria andCD_VALUEIsNotNull() {
            addCriterion("CD_VALUE is not null");
            return (Criteria) this;
        }

        public Criteria andCD_VALUEEqualTo(String value) {
            addCriterion("CD_VALUE =", value, "CD_VALUE");
            return (Criteria) this;
        }

        public Criteria andCD_VALUENotEqualTo(String value) {
            addCriterion("CD_VALUE <>", value, "CD_VALUE");
            return (Criteria) this;
        }

        public Criteria andCD_VALUEGreaterThan(String value) {
            addCriterion("CD_VALUE >", value, "CD_VALUE");
            return (Criteria) this;
        }

        public Criteria andCD_VALUEGreaterThanOrEqualTo(String value) {
            addCriterion("CD_VALUE >=", value, "CD_VALUE");
            return (Criteria) this;
        }

        public Criteria andCD_VALUELessThan(String value) {
            addCriterion("CD_VALUE <", value, "CD_VALUE");
            return (Criteria) this;
        }

        public Criteria andCD_VALUELessThanOrEqualTo(String value) {
            addCriterion("CD_VALUE <=", value, "CD_VALUE");
            return (Criteria) this;
        }

        public Criteria andCD_VALUELike(String value) {
            addCriterion("CD_VALUE like", value, "CD_VALUE");
            return (Criteria) this;
        }

        public Criteria andCD_VALUENotLike(String value) {
            addCriterion("CD_VALUE not like", value, "CD_VALUE");
            return (Criteria) this;
        }

        public Criteria andCD_VALUEIn(List<String> values) {
            addCriterion("CD_VALUE in", values, "CD_VALUE");
            return (Criteria) this;
        }

        public Criteria andCD_VALUENotIn(List<String> values) {
            addCriterion("CD_VALUE not in", values, "CD_VALUE");
            return (Criteria) this;
        }

        public Criteria andCD_VALUEBetween(String value1, String value2) {
            addCriterion("CD_VALUE between", value1, value2, "CD_VALUE");
            return (Criteria) this;
        }

        public Criteria andCD_VALUENotBetween(String value1, String value2) {
            addCriterion("CD_VALUE not between", value1, value2, "CD_VALUE");
            return (Criteria) this;
        }

        public Criteria andCD_NMIsNull() {
            addCriterion("CD_NM is null");
            return (Criteria) this;
        }

        public Criteria andCD_NMIsNotNull() {
            addCriterion("CD_NM is not null");
            return (Criteria) this;
        }

        public Criteria andCD_NMEqualTo(String value) {
            addCriterion("CD_NM =", value, "CD_NM");
            return (Criteria) this;
        }

        public Criteria andCD_NMNotEqualTo(String value) {
            addCriterion("CD_NM <>", value, "CD_NM");
            return (Criteria) this;
        }

        public Criteria andCD_NMGreaterThan(String value) {
            addCriterion("CD_NM >", value, "CD_NM");
            return (Criteria) this;
        }

        public Criteria andCD_NMGreaterThanOrEqualTo(String value) {
            addCriterion("CD_NM >=", value, "CD_NM");
            return (Criteria) this;
        }

        public Criteria andCD_NMLessThan(String value) {
            addCriterion("CD_NM <", value, "CD_NM");
            return (Criteria) this;
        }

        public Criteria andCD_NMLessThanOrEqualTo(String value) {
            addCriterion("CD_NM <=", value, "CD_NM");
            return (Criteria) this;
        }

        public Criteria andCD_NMLike(String value) {
            addCriterion("CD_NM like", value, "CD_NM");
            return (Criteria) this;
        }

        public Criteria andCD_NMNotLike(String value) {
            addCriterion("CD_NM not like", value, "CD_NM");
            return (Criteria) this;
        }

        public Criteria andCD_NMIn(List<String> values) {
            addCriterion("CD_NM in", values, "CD_NM");
            return (Criteria) this;
        }

        public Criteria andCD_NMNotIn(List<String> values) {
            addCriterion("CD_NM not in", values, "CD_NM");
            return (Criteria) this;
        }

        public Criteria andCD_NMBetween(String value1, String value2) {
            addCriterion("CD_NM between", value1, value2, "CD_NM");
            return (Criteria) this;
        }

        public Criteria andCD_NMNotBetween(String value1, String value2) {
            addCriterion("CD_NM not between", value1, value2, "CD_NM");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_JPIsNull() {
            addCriterion("DESCRIPTION_JP is null");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_JPIsNotNull() {
            addCriterion("DESCRIPTION_JP is not null");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_JPEqualTo(String value) {
            addCriterion("DESCRIPTION_JP =", value, "DESCRIPTION_JP");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_JPNotEqualTo(String value) {
            addCriterion("DESCRIPTION_JP <>", value, "DESCRIPTION_JP");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_JPGreaterThan(String value) {
            addCriterion("DESCRIPTION_JP >", value, "DESCRIPTION_JP");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_JPGreaterThanOrEqualTo(String value) {
            addCriterion("DESCRIPTION_JP >=", value, "DESCRIPTION_JP");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_JPLessThan(String value) {
            addCriterion("DESCRIPTION_JP <", value, "DESCRIPTION_JP");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_JPLessThanOrEqualTo(String value) {
            addCriterion("DESCRIPTION_JP <=", value, "DESCRIPTION_JP");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_JPLike(String value) {
            addCriterion("DESCRIPTION_JP like", value, "DESCRIPTION_JP");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_JPNotLike(String value) {
            addCriterion("DESCRIPTION_JP not like", value, "DESCRIPTION_JP");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_JPIn(List<String> values) {
            addCriterion("DESCRIPTION_JP in", values, "DESCRIPTION_JP");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_JPNotIn(List<String> values) {
            addCriterion("DESCRIPTION_JP not in", values, "DESCRIPTION_JP");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_JPBetween(String value1, String value2) {
            addCriterion("DESCRIPTION_JP between", value1, value2, "DESCRIPTION_JP");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_JPNotBetween(String value1, String value2) {
            addCriterion("DESCRIPTION_JP not between", value1, value2, "DESCRIPTION_JP");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ENIsNull() {
            addCriterion("DESCRIPTION_EN is null");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ENIsNotNull() {
            addCriterion("DESCRIPTION_EN is not null");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ENEqualTo(String value) {
            addCriterion("DESCRIPTION_EN =", value, "DESCRIPTION_EN");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ENNotEqualTo(String value) {
            addCriterion("DESCRIPTION_EN <>", value, "DESCRIPTION_EN");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ENGreaterThan(String value) {
            addCriterion("DESCRIPTION_EN >", value, "DESCRIPTION_EN");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ENGreaterThanOrEqualTo(String value) {
            addCriterion("DESCRIPTION_EN >=", value, "DESCRIPTION_EN");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ENLessThan(String value) {
            addCriterion("DESCRIPTION_EN <", value, "DESCRIPTION_EN");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ENLessThanOrEqualTo(String value) {
            addCriterion("DESCRIPTION_EN <=", value, "DESCRIPTION_EN");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ENLike(String value) {
            addCriterion("DESCRIPTION_EN like", value, "DESCRIPTION_EN");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ENNotLike(String value) {
            addCriterion("DESCRIPTION_EN not like", value, "DESCRIPTION_EN");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ENIn(List<String> values) {
            addCriterion("DESCRIPTION_EN in", values, "DESCRIPTION_EN");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ENNotIn(List<String> values) {
            addCriterion("DESCRIPTION_EN not in", values, "DESCRIPTION_EN");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ENBetween(String value1, String value2) {
            addCriterion("DESCRIPTION_EN between", value1, value2, "DESCRIPTION_EN");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ENNotBetween(String value1, String value2) {
            addCriterion("DESCRIPTION_EN not between", value1, value2, "DESCRIPTION_EN");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ZHIsNull() {
            addCriterion("DESCRIPTION_ZH is null");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ZHIsNotNull() {
            addCriterion("DESCRIPTION_ZH is not null");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ZHEqualTo(String value) {
            addCriterion("DESCRIPTION_ZH =", value, "DESCRIPTION_ZH");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ZHNotEqualTo(String value) {
            addCriterion("DESCRIPTION_ZH <>", value, "DESCRIPTION_ZH");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ZHGreaterThan(String value) {
            addCriterion("DESCRIPTION_ZH >", value, "DESCRIPTION_ZH");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ZHGreaterThanOrEqualTo(String value) {
            addCriterion("DESCRIPTION_ZH >=", value, "DESCRIPTION_ZH");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ZHLessThan(String value) {
            addCriterion("DESCRIPTION_ZH <", value, "DESCRIPTION_ZH");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ZHLessThanOrEqualTo(String value) {
            addCriterion("DESCRIPTION_ZH <=", value, "DESCRIPTION_ZH");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ZHLike(String value) {
            addCriterion("DESCRIPTION_ZH like", value, "DESCRIPTION_ZH");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ZHNotLike(String value) {
            addCriterion("DESCRIPTION_ZH not like", value, "DESCRIPTION_ZH");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ZHIn(List<String> values) {
            addCriterion("DESCRIPTION_ZH in", values, "DESCRIPTION_ZH");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ZHNotIn(List<String> values) {
            addCriterion("DESCRIPTION_ZH not in", values, "DESCRIPTION_ZH");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ZHBetween(String value1, String value2) {
            addCriterion("DESCRIPTION_ZH between", value1, value2, "DESCRIPTION_ZH");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ZHNotBetween(String value1, String value2) {
            addCriterion("DESCRIPTION_ZH not between", value1, value2, "DESCRIPTION_ZH");
            return (Criteria) this;
        }

        public Criteria andBIKOUIsNull() {
            addCriterion("BIKOU is null");
            return (Criteria) this;
        }

        public Criteria andBIKOUIsNotNull() {
            addCriterion("BIKOU is not null");
            return (Criteria) this;
        }

        public Criteria andBIKOUEqualTo(String value) {
            addCriterion("BIKOU =", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUNotEqualTo(String value) {
            addCriterion("BIKOU <>", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUGreaterThan(String value) {
            addCriterion("BIKOU >", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUGreaterThanOrEqualTo(String value) {
            addCriterion("BIKOU >=", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOULessThan(String value) {
            addCriterion("BIKOU <", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOULessThanOrEqualTo(String value) {
            addCriterion("BIKOU <=", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOULike(String value) {
            addCriterion("BIKOU like", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUNotLike(String value) {
            addCriterion("BIKOU not like", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUIn(List<String> values) {
            addCriterion("BIKOU in", values, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUNotIn(List<String> values) {
            addCriterion("BIKOU not in", values, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUBetween(String value1, String value2) {
            addCriterion("BIKOU between", value1, value2, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUNotBetween(String value1, String value2) {
            addCriterion("BIKOU not between", value1, value2, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andCD_IDLikeInsensitive(String value) {
            addCriterion("upper(CD_ID) like", value.toUpperCase(), "CD_ID");
            return (Criteria) this;
        }

        public Criteria andCD_VALUELikeInsensitive(String value) {
            addCriterion("upper(CD_VALUE) like", value.toUpperCase(), "CD_VALUE");
            return (Criteria) this;
        }

        public Criteria andCD_NMLikeInsensitive(String value) {
            addCriterion("upper(CD_NM) like", value.toUpperCase(), "CD_NM");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_JPLikeInsensitive(String value) {
            addCriterion("upper(DESCRIPTION_JP) like", value.toUpperCase(), "DESCRIPTION_JP");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ENLikeInsensitive(String value) {
            addCriterion("upper(DESCRIPTION_EN) like", value.toUpperCase(), "DESCRIPTION_EN");
            return (Criteria) this;
        }

        public Criteria andDESCRIPTION_ZHLikeInsensitive(String value) {
            addCriterion("upper(DESCRIPTION_ZH) like", value.toUpperCase(), "DESCRIPTION_ZH");
            return (Criteria) this;
        }

        public Criteria andBIKOULikeInsensitive(String value) {
            addCriterion("upper(BIKOU) like", value.toUpperCase(), "BIKOU");
            return (Criteria) this;
        }
    }

    /**
     * M_CD
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * M_CD null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}