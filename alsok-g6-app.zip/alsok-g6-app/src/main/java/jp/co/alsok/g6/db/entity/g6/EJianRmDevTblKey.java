package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class EJianRmDevTblKey implements Serializable {
    /**
     * LN_事案情報論理番号
     */
    private String LN_JIAN;

    /**
     * 装置番号
     */
    private String DEV_NUM;

    /**
     * E_JIAN_RM_DEV_TBL
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_事案情報論理番号
     * @return LN_JIAN LN_事案情報論理番号
     */
    public String getLN_JIAN() {
        return LN_JIAN;
    }

    /**
     * LN_事案情報論理番号
     * @param LN_JIAN LN_事案情報論理番号
     */
    public void setLN_JIAN(String LN_JIAN) {
        this.LN_JIAN = LN_JIAN == null ? null : LN_JIAN.trim();
    }

    /**
     * 装置番号
     * @return DEV_NUM 装置番号
     */
    public String getDEV_NUM() {
        return DEV_NUM;
    }

    /**
     * 装置番号
     * @param DEV_NUM 装置番号
     */
    public void setDEV_NUM(String DEV_NUM) {
        this.DEV_NUM = DEV_NUM == null ? null : DEV_NUM.trim();
    }
}