package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EJianOccurrenceExample {
    /**
     * E_JIAN_OCCURRENCE
     */
    protected String orderByClause;

    /**
     * E_JIAN_OCCURRENCE
     */
    protected boolean distinct;

    /**
     * E_JIAN_OCCURRENCE
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public EJianOccurrenceExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * E_JIAN_OCCURRENCE null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_JIANIsNull() {
            addCriterion("LN_JIAN is null");
            return (Criteria) this;
        }

        public Criteria andLN_JIANIsNotNull() {
            addCriterion("LN_JIAN is not null");
            return (Criteria) this;
        }

        public Criteria andLN_JIANEqualTo(String value) {
            addCriterion("LN_JIAN =", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANNotEqualTo(String value) {
            addCriterion("LN_JIAN <>", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANGreaterThan(String value) {
            addCriterion("LN_JIAN >", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANGreaterThanOrEqualTo(String value) {
            addCriterion("LN_JIAN >=", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANLessThan(String value) {
            addCriterion("LN_JIAN <", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANLessThanOrEqualTo(String value) {
            addCriterion("LN_JIAN <=", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANLike(String value) {
            addCriterion("LN_JIAN like", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANNotLike(String value) {
            addCriterion("LN_JIAN not like", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANIn(List<String> values) {
            addCriterion("LN_JIAN in", values, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANNotIn(List<String> values) {
            addCriterion("LN_JIAN not in", values, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANBetween(String value1, String value2) {
            addCriterion("LN_JIAN between", value1, value2, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANNotBetween(String value1, String value2) {
            addCriterion("LN_JIAN not between", value1, value2, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM1IsNull() {
            addCriterion("CUSTOMER_NUM1 is null");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM1IsNotNull() {
            addCriterion("CUSTOMER_NUM1 is not null");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM1EqualTo(String value) {
            addCriterion("CUSTOMER_NUM1 =", value, "CUSTOMER_NUM1");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM1NotEqualTo(String value) {
            addCriterion("CUSTOMER_NUM1 <>", value, "CUSTOMER_NUM1");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM1GreaterThan(String value) {
            addCriterion("CUSTOMER_NUM1 >", value, "CUSTOMER_NUM1");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM1GreaterThanOrEqualTo(String value) {
            addCriterion("CUSTOMER_NUM1 >=", value, "CUSTOMER_NUM1");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM1LessThan(String value) {
            addCriterion("CUSTOMER_NUM1 <", value, "CUSTOMER_NUM1");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM1LessThanOrEqualTo(String value) {
            addCriterion("CUSTOMER_NUM1 <=", value, "CUSTOMER_NUM1");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM1Like(String value) {
            addCriterion("CUSTOMER_NUM1 like", value, "CUSTOMER_NUM1");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM1NotLike(String value) {
            addCriterion("CUSTOMER_NUM1 not like", value, "CUSTOMER_NUM1");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM1In(List<String> values) {
            addCriterion("CUSTOMER_NUM1 in", values, "CUSTOMER_NUM1");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM1NotIn(List<String> values) {
            addCriterion("CUSTOMER_NUM1 not in", values, "CUSTOMER_NUM1");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM1Between(String value1, String value2) {
            addCriterion("CUSTOMER_NUM1 between", value1, value2, "CUSTOMER_NUM1");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM1NotBetween(String value1, String value2) {
            addCriterion("CUSTOMER_NUM1 not between", value1, value2, "CUSTOMER_NUM1");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM2IsNull() {
            addCriterion("CUSTOMER_NUM2 is null");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM2IsNotNull() {
            addCriterion("CUSTOMER_NUM2 is not null");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM2EqualTo(String value) {
            addCriterion("CUSTOMER_NUM2 =", value, "CUSTOMER_NUM2");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM2NotEqualTo(String value) {
            addCriterion("CUSTOMER_NUM2 <>", value, "CUSTOMER_NUM2");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM2GreaterThan(String value) {
            addCriterion("CUSTOMER_NUM2 >", value, "CUSTOMER_NUM2");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM2GreaterThanOrEqualTo(String value) {
            addCriterion("CUSTOMER_NUM2 >=", value, "CUSTOMER_NUM2");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM2LessThan(String value) {
            addCriterion("CUSTOMER_NUM2 <", value, "CUSTOMER_NUM2");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM2LessThanOrEqualTo(String value) {
            addCriterion("CUSTOMER_NUM2 <=", value, "CUSTOMER_NUM2");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM2Like(String value) {
            addCriterion("CUSTOMER_NUM2 like", value, "CUSTOMER_NUM2");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM2NotLike(String value) {
            addCriterion("CUSTOMER_NUM2 not like", value, "CUSTOMER_NUM2");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM2In(List<String> values) {
            addCriterion("CUSTOMER_NUM2 in", values, "CUSTOMER_NUM2");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM2NotIn(List<String> values) {
            addCriterion("CUSTOMER_NUM2 not in", values, "CUSTOMER_NUM2");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM2Between(String value1, String value2) {
            addCriterion("CUSTOMER_NUM2 between", value1, value2, "CUSTOMER_NUM2");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM2NotBetween(String value1, String value2) {
            addCriterion("CUSTOMER_NUM2 not between", value1, value2, "CUSTOMER_NUM2");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM3IsNull() {
            addCriterion("CUSTOMER_NUM3 is null");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM3IsNotNull() {
            addCriterion("CUSTOMER_NUM3 is not null");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM3EqualTo(String value) {
            addCriterion("CUSTOMER_NUM3 =", value, "CUSTOMER_NUM3");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM3NotEqualTo(String value) {
            addCriterion("CUSTOMER_NUM3 <>", value, "CUSTOMER_NUM3");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM3GreaterThan(String value) {
            addCriterion("CUSTOMER_NUM3 >", value, "CUSTOMER_NUM3");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM3GreaterThanOrEqualTo(String value) {
            addCriterion("CUSTOMER_NUM3 >=", value, "CUSTOMER_NUM3");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM3LessThan(String value) {
            addCriterion("CUSTOMER_NUM3 <", value, "CUSTOMER_NUM3");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM3LessThanOrEqualTo(String value) {
            addCriterion("CUSTOMER_NUM3 <=", value, "CUSTOMER_NUM3");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM3Like(String value) {
            addCriterion("CUSTOMER_NUM3 like", value, "CUSTOMER_NUM3");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM3NotLike(String value) {
            addCriterion("CUSTOMER_NUM3 not like", value, "CUSTOMER_NUM3");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM3In(List<String> values) {
            addCriterion("CUSTOMER_NUM3 in", values, "CUSTOMER_NUM3");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM3NotIn(List<String> values) {
            addCriterion("CUSTOMER_NUM3 not in", values, "CUSTOMER_NUM3");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM3Between(String value1, String value2) {
            addCriterion("CUSTOMER_NUM3 between", value1, value2, "CUSTOMER_NUM3");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM3NotBetween(String value1, String value2) {
            addCriterion("CUSTOMER_NUM3 not between", value1, value2, "CUSTOMER_NUM3");
            return (Criteria) this;
        }

        public Criteria andCHIKUIsNull() {
            addCriterion("CHIKU is null");
            return (Criteria) this;
        }

        public Criteria andCHIKUIsNotNull() {
            addCriterion("CHIKU is not null");
            return (Criteria) this;
        }

        public Criteria andCHIKUEqualTo(String value) {
            addCriterion("CHIKU =", value, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKUNotEqualTo(String value) {
            addCriterion("CHIKU <>", value, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKUGreaterThan(String value) {
            addCriterion("CHIKU >", value, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKUGreaterThanOrEqualTo(String value) {
            addCriterion("CHIKU >=", value, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKULessThan(String value) {
            addCriterion("CHIKU <", value, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKULessThanOrEqualTo(String value) {
            addCriterion("CHIKU <=", value, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKULike(String value) {
            addCriterion("CHIKU like", value, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKUNotLike(String value) {
            addCriterion("CHIKU not like", value, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKUIn(List<String> values) {
            addCriterion("CHIKU in", values, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKUNotIn(List<String> values) {
            addCriterion("CHIKU not in", values, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKUBetween(String value1, String value2) {
            addCriterion("CHIKU between", value1, value2, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKUNotBetween(String value1, String value2) {
            addCriterion("CHIKU not between", value1, value2, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andGOUKIIsNull() {
            addCriterion("GOUKI is null");
            return (Criteria) this;
        }

        public Criteria andGOUKIIsNotNull() {
            addCriterion("GOUKI is not null");
            return (Criteria) this;
        }

        public Criteria andGOUKIEqualTo(String value) {
            addCriterion("GOUKI =", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKINotEqualTo(String value) {
            addCriterion("GOUKI <>", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKIGreaterThan(String value) {
            addCriterion("GOUKI >", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKIGreaterThanOrEqualTo(String value) {
            addCriterion("GOUKI >=", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKILessThan(String value) {
            addCriterion("GOUKI <", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKILessThanOrEqualTo(String value) {
            addCriterion("GOUKI <=", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKILike(String value) {
            addCriterion("GOUKI like", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKINotLike(String value) {
            addCriterion("GOUKI not like", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKIIn(List<String> values) {
            addCriterion("GOUKI in", values, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKINotIn(List<String> values) {
            addCriterion("GOUKI not in", values, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKIBetween(String value1, String value2) {
            addCriterion("GOUKI between", value1, value2, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKINotBetween(String value1, String value2) {
            addCriterion("GOUKI not between", value1, value2, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andSUBADDRIsNull() {
            addCriterion("SUBADDR is null");
            return (Criteria) this;
        }

        public Criteria andSUBADDRIsNotNull() {
            addCriterion("SUBADDR is not null");
            return (Criteria) this;
        }

        public Criteria andSUBADDREqualTo(String value) {
            addCriterion("SUBADDR =", value, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRNotEqualTo(String value) {
            addCriterion("SUBADDR <>", value, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRGreaterThan(String value) {
            addCriterion("SUBADDR >", value, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRGreaterThanOrEqualTo(String value) {
            addCriterion("SUBADDR >=", value, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRLessThan(String value) {
            addCriterion("SUBADDR <", value, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRLessThanOrEqualTo(String value) {
            addCriterion("SUBADDR <=", value, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRLike(String value) {
            addCriterion("SUBADDR like", value, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRNotLike(String value) {
            addCriterion("SUBADDR not like", value, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRIn(List<String> values) {
            addCriterion("SUBADDR in", values, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRNotIn(List<String> values) {
            addCriterion("SUBADDR not in", values, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRBetween(String value1, String value2) {
            addCriterion("SUBADDR between", value1, value2, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRNotBetween(String value1, String value2) {
            addCriterion("SUBADDR not between", value1, value2, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG1IsNull() {
            addCriterion("SINPO_FLG1 is null");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG1IsNotNull() {
            addCriterion("SINPO_FLG1 is not null");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG1EqualTo(String value) {
            addCriterion("SINPO_FLG1 =", value, "SINPO_FLG1");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG1NotEqualTo(String value) {
            addCriterion("SINPO_FLG1 <>", value, "SINPO_FLG1");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG1GreaterThan(String value) {
            addCriterion("SINPO_FLG1 >", value, "SINPO_FLG1");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG1GreaterThanOrEqualTo(String value) {
            addCriterion("SINPO_FLG1 >=", value, "SINPO_FLG1");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG1LessThan(String value) {
            addCriterion("SINPO_FLG1 <", value, "SINPO_FLG1");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG1LessThanOrEqualTo(String value) {
            addCriterion("SINPO_FLG1 <=", value, "SINPO_FLG1");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG1Like(String value) {
            addCriterion("SINPO_FLG1 like", value, "SINPO_FLG1");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG1NotLike(String value) {
            addCriterion("SINPO_FLG1 not like", value, "SINPO_FLG1");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG1In(List<String> values) {
            addCriterion("SINPO_FLG1 in", values, "SINPO_FLG1");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG1NotIn(List<String> values) {
            addCriterion("SINPO_FLG1 not in", values, "SINPO_FLG1");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG1Between(String value1, String value2) {
            addCriterion("SINPO_FLG1 between", value1, value2, "SINPO_FLG1");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG1NotBetween(String value1, String value2) {
            addCriterion("SINPO_FLG1 not between", value1, value2, "SINPO_FLG1");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG2IsNull() {
            addCriterion("SINPO_FLG2 is null");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG2IsNotNull() {
            addCriterion("SINPO_FLG2 is not null");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG2EqualTo(String value) {
            addCriterion("SINPO_FLG2 =", value, "SINPO_FLG2");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG2NotEqualTo(String value) {
            addCriterion("SINPO_FLG2 <>", value, "SINPO_FLG2");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG2GreaterThan(String value) {
            addCriterion("SINPO_FLG2 >", value, "SINPO_FLG2");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG2GreaterThanOrEqualTo(String value) {
            addCriterion("SINPO_FLG2 >=", value, "SINPO_FLG2");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG2LessThan(String value) {
            addCriterion("SINPO_FLG2 <", value, "SINPO_FLG2");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG2LessThanOrEqualTo(String value) {
            addCriterion("SINPO_FLG2 <=", value, "SINPO_FLG2");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG2Like(String value) {
            addCriterion("SINPO_FLG2 like", value, "SINPO_FLG2");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG2NotLike(String value) {
            addCriterion("SINPO_FLG2 not like", value, "SINPO_FLG2");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG2In(List<String> values) {
            addCriterion("SINPO_FLG2 in", values, "SINPO_FLG2");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG2NotIn(List<String> values) {
            addCriterion("SINPO_FLG2 not in", values, "SINPO_FLG2");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG2Between(String value1, String value2) {
            addCriterion("SINPO_FLG2 between", value1, value2, "SINPO_FLG2");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG2NotBetween(String value1, String value2) {
            addCriterion("SINPO_FLG2 not between", value1, value2, "SINPO_FLG2");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG3IsNull() {
            addCriterion("SINPO_FLG3 is null");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG3IsNotNull() {
            addCriterion("SINPO_FLG3 is not null");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG3EqualTo(String value) {
            addCriterion("SINPO_FLG3 =", value, "SINPO_FLG3");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG3NotEqualTo(String value) {
            addCriterion("SINPO_FLG3 <>", value, "SINPO_FLG3");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG3GreaterThan(String value) {
            addCriterion("SINPO_FLG3 >", value, "SINPO_FLG3");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG3GreaterThanOrEqualTo(String value) {
            addCriterion("SINPO_FLG3 >=", value, "SINPO_FLG3");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG3LessThan(String value) {
            addCriterion("SINPO_FLG3 <", value, "SINPO_FLG3");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG3LessThanOrEqualTo(String value) {
            addCriterion("SINPO_FLG3 <=", value, "SINPO_FLG3");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG3Like(String value) {
            addCriterion("SINPO_FLG3 like", value, "SINPO_FLG3");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG3NotLike(String value) {
            addCriterion("SINPO_FLG3 not like", value, "SINPO_FLG3");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG3In(List<String> values) {
            addCriterion("SINPO_FLG3 in", values, "SINPO_FLG3");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG3NotIn(List<String> values) {
            addCriterion("SINPO_FLG3 not in", values, "SINPO_FLG3");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG3Between(String value1, String value2) {
            addCriterion("SINPO_FLG3 between", value1, value2, "SINPO_FLG3");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG3NotBetween(String value1, String value2) {
            addCriterion("SINPO_FLG3 not between", value1, value2, "SINPO_FLG3");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG4IsNull() {
            addCriterion("SINPO_FLG4 is null");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG4IsNotNull() {
            addCriterion("SINPO_FLG4 is not null");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG4EqualTo(String value) {
            addCriterion("SINPO_FLG4 =", value, "SINPO_FLG4");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG4NotEqualTo(String value) {
            addCriterion("SINPO_FLG4 <>", value, "SINPO_FLG4");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG4GreaterThan(String value) {
            addCriterion("SINPO_FLG4 >", value, "SINPO_FLG4");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG4GreaterThanOrEqualTo(String value) {
            addCriterion("SINPO_FLG4 >=", value, "SINPO_FLG4");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG4LessThan(String value) {
            addCriterion("SINPO_FLG4 <", value, "SINPO_FLG4");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG4LessThanOrEqualTo(String value) {
            addCriterion("SINPO_FLG4 <=", value, "SINPO_FLG4");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG4Like(String value) {
            addCriterion("SINPO_FLG4 like", value, "SINPO_FLG4");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG4NotLike(String value) {
            addCriterion("SINPO_FLG4 not like", value, "SINPO_FLG4");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG4In(List<String> values) {
            addCriterion("SINPO_FLG4 in", values, "SINPO_FLG4");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG4NotIn(List<String> values) {
            addCriterion("SINPO_FLG4 not in", values, "SINPO_FLG4");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG4Between(String value1, String value2) {
            addCriterion("SINPO_FLG4 between", value1, value2, "SINPO_FLG4");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG4NotBetween(String value1, String value2) {
            addCriterion("SINPO_FLG4 not between", value1, value2, "SINPO_FLG4");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_FLGIsNull() {
            addCriterion("IMPORTANT_FLG is null");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_FLGIsNotNull() {
            addCriterion("IMPORTANT_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_FLGEqualTo(String value) {
            addCriterion("IMPORTANT_FLG =", value, "IMPORTANT_FLG");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_FLGNotEqualTo(String value) {
            addCriterion("IMPORTANT_FLG <>", value, "IMPORTANT_FLG");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_FLGGreaterThan(String value) {
            addCriterion("IMPORTANT_FLG >", value, "IMPORTANT_FLG");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("IMPORTANT_FLG >=", value, "IMPORTANT_FLG");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_FLGLessThan(String value) {
            addCriterion("IMPORTANT_FLG <", value, "IMPORTANT_FLG");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_FLGLessThanOrEqualTo(String value) {
            addCriterion("IMPORTANT_FLG <=", value, "IMPORTANT_FLG");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_FLGLike(String value) {
            addCriterion("IMPORTANT_FLG like", value, "IMPORTANT_FLG");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_FLGNotLike(String value) {
            addCriterion("IMPORTANT_FLG not like", value, "IMPORTANT_FLG");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_FLGIn(List<String> values) {
            addCriterion("IMPORTANT_FLG in", values, "IMPORTANT_FLG");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_FLGNotIn(List<String> values) {
            addCriterion("IMPORTANT_FLG not in", values, "IMPORTANT_FLG");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_FLGBetween(String value1, String value2) {
            addCriterion("IMPORTANT_FLG between", value1, value2, "IMPORTANT_FLG");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_FLGNotBetween(String value1, String value2) {
            addCriterion("IMPORTANT_FLG not between", value1, value2, "IMPORTANT_FLG");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_NMIsNull() {
            addCriterion("KEIYAKU_NM is null");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_NMIsNotNull() {
            addCriterion("KEIYAKU_NM is not null");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_NMEqualTo(String value) {
            addCriterion("KEIYAKU_NM =", value, "KEIYAKU_NM");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_NMNotEqualTo(String value) {
            addCriterion("KEIYAKU_NM <>", value, "KEIYAKU_NM");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_NMGreaterThan(String value) {
            addCriterion("KEIYAKU_NM >", value, "KEIYAKU_NM");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_NMGreaterThanOrEqualTo(String value) {
            addCriterion("KEIYAKU_NM >=", value, "KEIYAKU_NM");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_NMLessThan(String value) {
            addCriterion("KEIYAKU_NM <", value, "KEIYAKU_NM");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_NMLessThanOrEqualTo(String value) {
            addCriterion("KEIYAKU_NM <=", value, "KEIYAKU_NM");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_NMLike(String value) {
            addCriterion("KEIYAKU_NM like", value, "KEIYAKU_NM");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_NMNotLike(String value) {
            addCriterion("KEIYAKU_NM not like", value, "KEIYAKU_NM");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_NMIn(List<String> values) {
            addCriterion("KEIYAKU_NM in", values, "KEIYAKU_NM");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_NMNotIn(List<String> values) {
            addCriterion("KEIYAKU_NM not in", values, "KEIYAKU_NM");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_NMBetween(String value1, String value2) {
            addCriterion("KEIYAKU_NM between", value1, value2, "KEIYAKU_NM");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_NMNotBetween(String value1, String value2) {
            addCriterion("KEIYAKU_NM not between", value1, value2, "KEIYAKU_NM");
            return (Criteria) this;
        }

        public Criteria andGC_IDIsNull() {
            addCriterion("GC_ID is null");
            return (Criteria) this;
        }

        public Criteria andGC_IDIsNotNull() {
            addCriterion("GC_ID is not null");
            return (Criteria) this;
        }

        public Criteria andGC_IDEqualTo(String value) {
            addCriterion("GC_ID =", value, "GC_ID");
            return (Criteria) this;
        }

        public Criteria andGC_IDNotEqualTo(String value) {
            addCriterion("GC_ID <>", value, "GC_ID");
            return (Criteria) this;
        }

        public Criteria andGC_IDGreaterThan(String value) {
            addCriterion("GC_ID >", value, "GC_ID");
            return (Criteria) this;
        }

        public Criteria andGC_IDGreaterThanOrEqualTo(String value) {
            addCriterion("GC_ID >=", value, "GC_ID");
            return (Criteria) this;
        }

        public Criteria andGC_IDLessThan(String value) {
            addCriterion("GC_ID <", value, "GC_ID");
            return (Criteria) this;
        }

        public Criteria andGC_IDLessThanOrEqualTo(String value) {
            addCriterion("GC_ID <=", value, "GC_ID");
            return (Criteria) this;
        }

        public Criteria andGC_IDLike(String value) {
            addCriterion("GC_ID like", value, "GC_ID");
            return (Criteria) this;
        }

        public Criteria andGC_IDNotLike(String value) {
            addCriterion("GC_ID not like", value, "GC_ID");
            return (Criteria) this;
        }

        public Criteria andGC_IDIn(List<String> values) {
            addCriterion("GC_ID in", values, "GC_ID");
            return (Criteria) this;
        }

        public Criteria andGC_IDNotIn(List<String> values) {
            addCriterion("GC_ID not in", values, "GC_ID");
            return (Criteria) this;
        }

        public Criteria andGC_IDBetween(String value1, String value2) {
            addCriterion("GC_ID between", value1, value2, "GC_ID");
            return (Criteria) this;
        }

        public Criteria andGC_IDNotBetween(String value1, String value2) {
            addCriterion("GC_ID not between", value1, value2, "GC_ID");
            return (Criteria) this;
        }

        public Criteria andAREA_IDIsNull() {
            addCriterion("AREA_ID is null");
            return (Criteria) this;
        }

        public Criteria andAREA_IDIsNotNull() {
            addCriterion("AREA_ID is not null");
            return (Criteria) this;
        }

        public Criteria andAREA_IDEqualTo(String value) {
            addCriterion("AREA_ID =", value, "AREA_ID");
            return (Criteria) this;
        }

        public Criteria andAREA_IDNotEqualTo(String value) {
            addCriterion("AREA_ID <>", value, "AREA_ID");
            return (Criteria) this;
        }

        public Criteria andAREA_IDGreaterThan(String value) {
            addCriterion("AREA_ID >", value, "AREA_ID");
            return (Criteria) this;
        }

        public Criteria andAREA_IDGreaterThanOrEqualTo(String value) {
            addCriterion("AREA_ID >=", value, "AREA_ID");
            return (Criteria) this;
        }

        public Criteria andAREA_IDLessThan(String value) {
            addCriterion("AREA_ID <", value, "AREA_ID");
            return (Criteria) this;
        }

        public Criteria andAREA_IDLessThanOrEqualTo(String value) {
            addCriterion("AREA_ID <=", value, "AREA_ID");
            return (Criteria) this;
        }

        public Criteria andAREA_IDLike(String value) {
            addCriterion("AREA_ID like", value, "AREA_ID");
            return (Criteria) this;
        }

        public Criteria andAREA_IDNotLike(String value) {
            addCriterion("AREA_ID not like", value, "AREA_ID");
            return (Criteria) this;
        }

        public Criteria andAREA_IDIn(List<String> values) {
            addCriterion("AREA_ID in", values, "AREA_ID");
            return (Criteria) this;
        }

        public Criteria andAREA_IDNotIn(List<String> values) {
            addCriterion("AREA_ID not in", values, "AREA_ID");
            return (Criteria) this;
        }

        public Criteria andAREA_IDBetween(String value1, String value2) {
            addCriterion("AREA_ID between", value1, value2, "AREA_ID");
            return (Criteria) this;
        }

        public Criteria andAREA_IDNotBetween(String value1, String value2) {
            addCriterion("AREA_ID not between", value1, value2, "AREA_ID");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM1IsNull() {
            addCriterion("KEIBI_NM1 is null");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM1IsNotNull() {
            addCriterion("KEIBI_NM1 is not null");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM1EqualTo(String value) {
            addCriterion("KEIBI_NM1 =", value, "KEIBI_NM1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM1NotEqualTo(String value) {
            addCriterion("KEIBI_NM1 <>", value, "KEIBI_NM1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM1GreaterThan(String value) {
            addCriterion("KEIBI_NM1 >", value, "KEIBI_NM1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM1GreaterThanOrEqualTo(String value) {
            addCriterion("KEIBI_NM1 >=", value, "KEIBI_NM1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM1LessThan(String value) {
            addCriterion("KEIBI_NM1 <", value, "KEIBI_NM1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM1LessThanOrEqualTo(String value) {
            addCriterion("KEIBI_NM1 <=", value, "KEIBI_NM1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM1Like(String value) {
            addCriterion("KEIBI_NM1 like", value, "KEIBI_NM1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM1NotLike(String value) {
            addCriterion("KEIBI_NM1 not like", value, "KEIBI_NM1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM1In(List<String> values) {
            addCriterion("KEIBI_NM1 in", values, "KEIBI_NM1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM1NotIn(List<String> values) {
            addCriterion("KEIBI_NM1 not in", values, "KEIBI_NM1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM1Between(String value1, String value2) {
            addCriterion("KEIBI_NM1 between", value1, value2, "KEIBI_NM1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM1NotBetween(String value1, String value2) {
            addCriterion("KEIBI_NM1 not between", value1, value2, "KEIBI_NM1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM2IsNull() {
            addCriterion("KEIBI_NM2 is null");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM2IsNotNull() {
            addCriterion("KEIBI_NM2 is not null");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM2EqualTo(String value) {
            addCriterion("KEIBI_NM2 =", value, "KEIBI_NM2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM2NotEqualTo(String value) {
            addCriterion("KEIBI_NM2 <>", value, "KEIBI_NM2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM2GreaterThan(String value) {
            addCriterion("KEIBI_NM2 >", value, "KEIBI_NM2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM2GreaterThanOrEqualTo(String value) {
            addCriterion("KEIBI_NM2 >=", value, "KEIBI_NM2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM2LessThan(String value) {
            addCriterion("KEIBI_NM2 <", value, "KEIBI_NM2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM2LessThanOrEqualTo(String value) {
            addCriterion("KEIBI_NM2 <=", value, "KEIBI_NM2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM2Like(String value) {
            addCriterion("KEIBI_NM2 like", value, "KEIBI_NM2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM2NotLike(String value) {
            addCriterion("KEIBI_NM2 not like", value, "KEIBI_NM2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM2In(List<String> values) {
            addCriterion("KEIBI_NM2 in", values, "KEIBI_NM2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM2NotIn(List<String> values) {
            addCriterion("KEIBI_NM2 not in", values, "KEIBI_NM2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM2Between(String value1, String value2) {
            addCriterion("KEIBI_NM2 between", value1, value2, "KEIBI_NM2");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM2NotBetween(String value1, String value2) {
            addCriterion("KEIBI_NM2 not between", value1, value2, "KEIBI_NM2");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBR_NMIsNull() {
            addCriterion("KEIBISAKI_ABBR_NM is null");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBR_NMIsNotNull() {
            addCriterion("KEIBISAKI_ABBR_NM is not null");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBR_NMEqualTo(String value) {
            addCriterion("KEIBISAKI_ABBR_NM =", value, "KEIBISAKI_ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBR_NMNotEqualTo(String value) {
            addCriterion("KEIBISAKI_ABBR_NM <>", value, "KEIBISAKI_ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBR_NMGreaterThan(String value) {
            addCriterion("KEIBISAKI_ABBR_NM >", value, "KEIBISAKI_ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBR_NMGreaterThanOrEqualTo(String value) {
            addCriterion("KEIBISAKI_ABBR_NM >=", value, "KEIBISAKI_ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBR_NMLessThan(String value) {
            addCriterion("KEIBISAKI_ABBR_NM <", value, "KEIBISAKI_ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBR_NMLessThanOrEqualTo(String value) {
            addCriterion("KEIBISAKI_ABBR_NM <=", value, "KEIBISAKI_ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBR_NMLike(String value) {
            addCriterion("KEIBISAKI_ABBR_NM like", value, "KEIBISAKI_ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBR_NMNotLike(String value) {
            addCriterion("KEIBISAKI_ABBR_NM not like", value, "KEIBISAKI_ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBR_NMIn(List<String> values) {
            addCriterion("KEIBISAKI_ABBR_NM in", values, "KEIBISAKI_ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBR_NMNotIn(List<String> values) {
            addCriterion("KEIBISAKI_ABBR_NM not in", values, "KEIBISAKI_ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBR_NMBetween(String value1, String value2) {
            addCriterion("KEIBISAKI_ABBR_NM between", value1, value2, "KEIBISAKI_ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBR_NMNotBetween(String value1, String value2) {
            addCriterion("KEIBISAKI_ABBR_NM not between", value1, value2, "KEIBISAKI_ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMIsNull() {
            addCriterion("POST_NUM is null");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMIsNotNull() {
            addCriterion("POST_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMEqualTo(String value) {
            addCriterion("POST_NUM =", value, "POST_NUM");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMNotEqualTo(String value) {
            addCriterion("POST_NUM <>", value, "POST_NUM");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMGreaterThan(String value) {
            addCriterion("POST_NUM >", value, "POST_NUM");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("POST_NUM >=", value, "POST_NUM");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMLessThan(String value) {
            addCriterion("POST_NUM <", value, "POST_NUM");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMLessThanOrEqualTo(String value) {
            addCriterion("POST_NUM <=", value, "POST_NUM");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMLike(String value) {
            addCriterion("POST_NUM like", value, "POST_NUM");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMNotLike(String value) {
            addCriterion("POST_NUM not like", value, "POST_NUM");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMIn(List<String> values) {
            addCriterion("POST_NUM in", values, "POST_NUM");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMNotIn(List<String> values) {
            addCriterion("POST_NUM not in", values, "POST_NUM");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMBetween(String value1, String value2) {
            addCriterion("POST_NUM between", value1, value2, "POST_NUM");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMNotBetween(String value1, String value2) {
            addCriterion("POST_NUM not between", value1, value2, "POST_NUM");
            return (Criteria) this;
        }

        public Criteria andADDR_CD1_IDIsNull() {
            addCriterion("ADDR_CD1_ID is null");
            return (Criteria) this;
        }

        public Criteria andADDR_CD1_IDIsNotNull() {
            addCriterion("ADDR_CD1_ID is not null");
            return (Criteria) this;
        }

        public Criteria andADDR_CD1_IDEqualTo(String value) {
            addCriterion("ADDR_CD1_ID =", value, "ADDR_CD1_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD1_IDNotEqualTo(String value) {
            addCriterion("ADDR_CD1_ID <>", value, "ADDR_CD1_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD1_IDGreaterThan(String value) {
            addCriterion("ADDR_CD1_ID >", value, "ADDR_CD1_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD1_IDGreaterThanOrEqualTo(String value) {
            addCriterion("ADDR_CD1_ID >=", value, "ADDR_CD1_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD1_IDLessThan(String value) {
            addCriterion("ADDR_CD1_ID <", value, "ADDR_CD1_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD1_IDLessThanOrEqualTo(String value) {
            addCriterion("ADDR_CD1_ID <=", value, "ADDR_CD1_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD1_IDLike(String value) {
            addCriterion("ADDR_CD1_ID like", value, "ADDR_CD1_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD1_IDNotLike(String value) {
            addCriterion("ADDR_CD1_ID not like", value, "ADDR_CD1_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD1_IDIn(List<String> values) {
            addCriterion("ADDR_CD1_ID in", values, "ADDR_CD1_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD1_IDNotIn(List<String> values) {
            addCriterion("ADDR_CD1_ID not in", values, "ADDR_CD1_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD1_IDBetween(String value1, String value2) {
            addCriterion("ADDR_CD1_ID between", value1, value2, "ADDR_CD1_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD1_IDNotBetween(String value1, String value2) {
            addCriterion("ADDR_CD1_ID not between", value1, value2, "ADDR_CD1_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDIsNull() {
            addCriterion("ADDR_CD2_ID is null");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDIsNotNull() {
            addCriterion("ADDR_CD2_ID is not null");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDEqualTo(String value) {
            addCriterion("ADDR_CD2_ID =", value, "ADDR_CD2_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDNotEqualTo(String value) {
            addCriterion("ADDR_CD2_ID <>", value, "ADDR_CD2_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDGreaterThan(String value) {
            addCriterion("ADDR_CD2_ID >", value, "ADDR_CD2_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDGreaterThanOrEqualTo(String value) {
            addCriterion("ADDR_CD2_ID >=", value, "ADDR_CD2_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDLessThan(String value) {
            addCriterion("ADDR_CD2_ID <", value, "ADDR_CD2_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDLessThanOrEqualTo(String value) {
            addCriterion("ADDR_CD2_ID <=", value, "ADDR_CD2_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDLike(String value) {
            addCriterion("ADDR_CD2_ID like", value, "ADDR_CD2_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDNotLike(String value) {
            addCriterion("ADDR_CD2_ID not like", value, "ADDR_CD2_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDIn(List<String> values) {
            addCriterion("ADDR_CD2_ID in", values, "ADDR_CD2_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDNotIn(List<String> values) {
            addCriterion("ADDR_CD2_ID not in", values, "ADDR_CD2_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDBetween(String value1, String value2) {
            addCriterion("ADDR_CD2_ID between", value1, value2, "ADDR_CD2_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDNotBetween(String value1, String value2) {
            addCriterion("ADDR_CD2_ID not between", value1, value2, "ADDR_CD2_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDIsNull() {
            addCriterion("ADDR_CD3_ID is null");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDIsNotNull() {
            addCriterion("ADDR_CD3_ID is not null");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDEqualTo(String value) {
            addCriterion("ADDR_CD3_ID =", value, "ADDR_CD3_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDNotEqualTo(String value) {
            addCriterion("ADDR_CD3_ID <>", value, "ADDR_CD3_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDGreaterThan(String value) {
            addCriterion("ADDR_CD3_ID >", value, "ADDR_CD3_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDGreaterThanOrEqualTo(String value) {
            addCriterion("ADDR_CD3_ID >=", value, "ADDR_CD3_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDLessThan(String value) {
            addCriterion("ADDR_CD3_ID <", value, "ADDR_CD3_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDLessThanOrEqualTo(String value) {
            addCriterion("ADDR_CD3_ID <=", value, "ADDR_CD3_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDLike(String value) {
            addCriterion("ADDR_CD3_ID like", value, "ADDR_CD3_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDNotLike(String value) {
            addCriterion("ADDR_CD3_ID not like", value, "ADDR_CD3_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDIn(List<String> values) {
            addCriterion("ADDR_CD3_ID in", values, "ADDR_CD3_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDNotIn(List<String> values) {
            addCriterion("ADDR_CD3_ID not in", values, "ADDR_CD3_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDBetween(String value1, String value2) {
            addCriterion("ADDR_CD3_ID between", value1, value2, "ADDR_CD3_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDNotBetween(String value1, String value2) {
            addCriterion("ADDR_CD3_ID not between", value1, value2, "ADDR_CD3_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDIsNull() {
            addCriterion("ADDR_CD4_ID is null");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDIsNotNull() {
            addCriterion("ADDR_CD4_ID is not null");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDEqualTo(String value) {
            addCriterion("ADDR_CD4_ID =", value, "ADDR_CD4_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDNotEqualTo(String value) {
            addCriterion("ADDR_CD4_ID <>", value, "ADDR_CD4_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDGreaterThan(String value) {
            addCriterion("ADDR_CD4_ID >", value, "ADDR_CD4_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDGreaterThanOrEqualTo(String value) {
            addCriterion("ADDR_CD4_ID >=", value, "ADDR_CD4_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDLessThan(String value) {
            addCriterion("ADDR_CD4_ID <", value, "ADDR_CD4_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDLessThanOrEqualTo(String value) {
            addCriterion("ADDR_CD4_ID <=", value, "ADDR_CD4_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDLike(String value) {
            addCriterion("ADDR_CD4_ID like", value, "ADDR_CD4_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDNotLike(String value) {
            addCriterion("ADDR_CD4_ID not like", value, "ADDR_CD4_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDIn(List<String> values) {
            addCriterion("ADDR_CD4_ID in", values, "ADDR_CD4_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDNotIn(List<String> values) {
            addCriterion("ADDR_CD4_ID not in", values, "ADDR_CD4_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDBetween(String value1, String value2) {
            addCriterion("ADDR_CD4_ID between", value1, value2, "ADDR_CD4_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDNotBetween(String value1, String value2) {
            addCriterion("ADDR_CD4_ID not between", value1, value2, "ADDR_CD4_ID");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT1IsNull() {
            addCriterion("ADDRESS_OPT1 is null");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT1IsNotNull() {
            addCriterion("ADDRESS_OPT1 is not null");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT1EqualTo(String value) {
            addCriterion("ADDRESS_OPT1 =", value, "ADDRESS_OPT1");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT1NotEqualTo(String value) {
            addCriterion("ADDRESS_OPT1 <>", value, "ADDRESS_OPT1");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT1GreaterThan(String value) {
            addCriterion("ADDRESS_OPT1 >", value, "ADDRESS_OPT1");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT1GreaterThanOrEqualTo(String value) {
            addCriterion("ADDRESS_OPT1 >=", value, "ADDRESS_OPT1");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT1LessThan(String value) {
            addCriterion("ADDRESS_OPT1 <", value, "ADDRESS_OPT1");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT1LessThanOrEqualTo(String value) {
            addCriterion("ADDRESS_OPT1 <=", value, "ADDRESS_OPT1");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT1Like(String value) {
            addCriterion("ADDRESS_OPT1 like", value, "ADDRESS_OPT1");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT1NotLike(String value) {
            addCriterion("ADDRESS_OPT1 not like", value, "ADDRESS_OPT1");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT1In(List<String> values) {
            addCriterion("ADDRESS_OPT1 in", values, "ADDRESS_OPT1");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT1NotIn(List<String> values) {
            addCriterion("ADDRESS_OPT1 not in", values, "ADDRESS_OPT1");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT1Between(String value1, String value2) {
            addCriterion("ADDRESS_OPT1 between", value1, value2, "ADDRESS_OPT1");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT1NotBetween(String value1, String value2) {
            addCriterion("ADDRESS_OPT1 not between", value1, value2, "ADDRESS_OPT1");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT2IsNull() {
            addCriterion("ADDRESS_OPT2 is null");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT2IsNotNull() {
            addCriterion("ADDRESS_OPT2 is not null");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT2EqualTo(String value) {
            addCriterion("ADDRESS_OPT2 =", value, "ADDRESS_OPT2");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT2NotEqualTo(String value) {
            addCriterion("ADDRESS_OPT2 <>", value, "ADDRESS_OPT2");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT2GreaterThan(String value) {
            addCriterion("ADDRESS_OPT2 >", value, "ADDRESS_OPT2");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT2GreaterThanOrEqualTo(String value) {
            addCriterion("ADDRESS_OPT2 >=", value, "ADDRESS_OPT2");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT2LessThan(String value) {
            addCriterion("ADDRESS_OPT2 <", value, "ADDRESS_OPT2");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT2LessThanOrEqualTo(String value) {
            addCriterion("ADDRESS_OPT2 <=", value, "ADDRESS_OPT2");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT2Like(String value) {
            addCriterion("ADDRESS_OPT2 like", value, "ADDRESS_OPT2");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT2NotLike(String value) {
            addCriterion("ADDRESS_OPT2 not like", value, "ADDRESS_OPT2");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT2In(List<String> values) {
            addCriterion("ADDRESS_OPT2 in", values, "ADDRESS_OPT2");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT2NotIn(List<String> values) {
            addCriterion("ADDRESS_OPT2 not in", values, "ADDRESS_OPT2");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT2Between(String value1, String value2) {
            addCriterion("ADDRESS_OPT2 between", value1, value2, "ADDRESS_OPT2");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT2NotBetween(String value1, String value2) {
            addCriterion("ADDRESS_OPT2 not between", value1, value2, "ADDRESS_OPT2");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND1IsNull() {
            addCriterion("KEIYAKU_KIND1 is null");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND1IsNotNull() {
            addCriterion("KEIYAKU_KIND1 is not null");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND1EqualTo(String value) {
            addCriterion("KEIYAKU_KIND1 =", value, "KEIYAKU_KIND1");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND1NotEqualTo(String value) {
            addCriterion("KEIYAKU_KIND1 <>", value, "KEIYAKU_KIND1");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND1GreaterThan(String value) {
            addCriterion("KEIYAKU_KIND1 >", value, "KEIYAKU_KIND1");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND1GreaterThanOrEqualTo(String value) {
            addCriterion("KEIYAKU_KIND1 >=", value, "KEIYAKU_KIND1");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND1LessThan(String value) {
            addCriterion("KEIYAKU_KIND1 <", value, "KEIYAKU_KIND1");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND1LessThanOrEqualTo(String value) {
            addCriterion("KEIYAKU_KIND1 <=", value, "KEIYAKU_KIND1");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND1Like(String value) {
            addCriterion("KEIYAKU_KIND1 like", value, "KEIYAKU_KIND1");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND1NotLike(String value) {
            addCriterion("KEIYAKU_KIND1 not like", value, "KEIYAKU_KIND1");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND1In(List<String> values) {
            addCriterion("KEIYAKU_KIND1 in", values, "KEIYAKU_KIND1");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND1NotIn(List<String> values) {
            addCriterion("KEIYAKU_KIND1 not in", values, "KEIYAKU_KIND1");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND1Between(String value1, String value2) {
            addCriterion("KEIYAKU_KIND1 between", value1, value2, "KEIYAKU_KIND1");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND1NotBetween(String value1, String value2) {
            addCriterion("KEIYAKU_KIND1 not between", value1, value2, "KEIYAKU_KIND1");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND2IsNull() {
            addCriterion("KEIYAKU_KIND2 is null");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND2IsNotNull() {
            addCriterion("KEIYAKU_KIND2 is not null");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND2EqualTo(String value) {
            addCriterion("KEIYAKU_KIND2 =", value, "KEIYAKU_KIND2");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND2NotEqualTo(String value) {
            addCriterion("KEIYAKU_KIND2 <>", value, "KEIYAKU_KIND2");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND2GreaterThan(String value) {
            addCriterion("KEIYAKU_KIND2 >", value, "KEIYAKU_KIND2");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND2GreaterThanOrEqualTo(String value) {
            addCriterion("KEIYAKU_KIND2 >=", value, "KEIYAKU_KIND2");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND2LessThan(String value) {
            addCriterion("KEIYAKU_KIND2 <", value, "KEIYAKU_KIND2");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND2LessThanOrEqualTo(String value) {
            addCriterion("KEIYAKU_KIND2 <=", value, "KEIYAKU_KIND2");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND2Like(String value) {
            addCriterion("KEIYAKU_KIND2 like", value, "KEIYAKU_KIND2");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND2NotLike(String value) {
            addCriterion("KEIYAKU_KIND2 not like", value, "KEIYAKU_KIND2");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND2In(List<String> values) {
            addCriterion("KEIYAKU_KIND2 in", values, "KEIYAKU_KIND2");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND2NotIn(List<String> values) {
            addCriterion("KEIYAKU_KIND2 not in", values, "KEIYAKU_KIND2");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND2Between(String value1, String value2) {
            addCriterion("KEIYAKU_KIND2 between", value1, value2, "KEIYAKU_KIND2");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND2NotBetween(String value1, String value2) {
            addCriterion("KEIYAKU_KIND2 not between", value1, value2, "KEIYAKU_KIND2");
            return (Criteria) this;
        }

        public Criteria andSTART_YOTEI_DATEIsNull() {
            addCriterion("START_YOTEI_DATE is null");
            return (Criteria) this;
        }

        public Criteria andSTART_YOTEI_DATEIsNotNull() {
            addCriterion("START_YOTEI_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andSTART_YOTEI_DATEEqualTo(Date value) {
            addCriterion("START_YOTEI_DATE =", value, "START_YOTEI_DATE");
            return (Criteria) this;
        }

        public Criteria andSTART_YOTEI_DATENotEqualTo(Date value) {
            addCriterion("START_YOTEI_DATE <>", value, "START_YOTEI_DATE");
            return (Criteria) this;
        }

        public Criteria andSTART_YOTEI_DATEGreaterThan(Date value) {
            addCriterion("START_YOTEI_DATE >", value, "START_YOTEI_DATE");
            return (Criteria) this;
        }

        public Criteria andSTART_YOTEI_DATEGreaterThanOrEqualTo(Date value) {
            addCriterion("START_YOTEI_DATE >=", value, "START_YOTEI_DATE");
            return (Criteria) this;
        }

        public Criteria andSTART_YOTEI_DATELessThan(Date value) {
            addCriterion("START_YOTEI_DATE <", value, "START_YOTEI_DATE");
            return (Criteria) this;
        }

        public Criteria andSTART_YOTEI_DATELessThanOrEqualTo(Date value) {
            addCriterion("START_YOTEI_DATE <=", value, "START_YOTEI_DATE");
            return (Criteria) this;
        }

        public Criteria andSTART_YOTEI_DATEIn(List<Date> values) {
            addCriterion("START_YOTEI_DATE in", values, "START_YOTEI_DATE");
            return (Criteria) this;
        }

        public Criteria andSTART_YOTEI_DATENotIn(List<Date> values) {
            addCriterion("START_YOTEI_DATE not in", values, "START_YOTEI_DATE");
            return (Criteria) this;
        }

        public Criteria andSTART_YOTEI_DATEBetween(Date value1, Date value2) {
            addCriterion("START_YOTEI_DATE between", value1, value2, "START_YOTEI_DATE");
            return (Criteria) this;
        }

        public Criteria andSTART_YOTEI_DATENotBetween(Date value1, Date value2) {
            addCriterion("START_YOTEI_DATE not between", value1, value2, "START_YOTEI_DATE");
            return (Criteria) this;
        }

        public Criteria andKOBETU_NMIsNull() {
            addCriterion("KOBETU_NM is null");
            return (Criteria) this;
        }

        public Criteria andKOBETU_NMIsNotNull() {
            addCriterion("KOBETU_NM is not null");
            return (Criteria) this;
        }

        public Criteria andKOBETU_NMEqualTo(String value) {
            addCriterion("KOBETU_NM =", value, "KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andKOBETU_NMNotEqualTo(String value) {
            addCriterion("KOBETU_NM <>", value, "KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andKOBETU_NMGreaterThan(String value) {
            addCriterion("KOBETU_NM >", value, "KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andKOBETU_NMGreaterThanOrEqualTo(String value) {
            addCriterion("KOBETU_NM >=", value, "KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andKOBETU_NMLessThan(String value) {
            addCriterion("KOBETU_NM <", value, "KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andKOBETU_NMLessThanOrEqualTo(String value) {
            addCriterion("KOBETU_NM <=", value, "KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andKOBETU_NMLike(String value) {
            addCriterion("KOBETU_NM like", value, "KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andKOBETU_NMNotLike(String value) {
            addCriterion("KOBETU_NM not like", value, "KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andKOBETU_NMIn(List<String> values) {
            addCriterion("KOBETU_NM in", values, "KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andKOBETU_NMNotIn(List<String> values) {
            addCriterion("KOBETU_NM not in", values, "KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andKOBETU_NMBetween(String value1, String value2) {
            addCriterion("KOBETU_NM between", value1, value2, "KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andKOBETU_NMNotBetween(String value1, String value2) {
            addCriterion("KOBETU_NM not between", value1, value2, "KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDIsNull() {
            addCriterion("GYOUMU_CD is null");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDIsNotNull() {
            addCriterion("GYOUMU_CD is not null");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDEqualTo(String value) {
            addCriterion("GYOUMU_CD =", value, "GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDNotEqualTo(String value) {
            addCriterion("GYOUMU_CD <>", value, "GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDGreaterThan(String value) {
            addCriterion("GYOUMU_CD >", value, "GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDGreaterThanOrEqualTo(String value) {
            addCriterion("GYOUMU_CD >=", value, "GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDLessThan(String value) {
            addCriterion("GYOUMU_CD <", value, "GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDLessThanOrEqualTo(String value) {
            addCriterion("GYOUMU_CD <=", value, "GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDLike(String value) {
            addCriterion("GYOUMU_CD like", value, "GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDNotLike(String value) {
            addCriterion("GYOUMU_CD not like", value, "GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDIn(List<String> values) {
            addCriterion("GYOUMU_CD in", values, "GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDNotIn(List<String> values) {
            addCriterion("GYOUMU_CD not in", values, "GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDBetween(String value1, String value2) {
            addCriterion("GYOUMU_CD between", value1, value2, "GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDNotBetween(String value1, String value2) {
            addCriterion("GYOUMU_CD not between", value1, value2, "GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDIsNull() {
            addCriterion("HOSOKU_CD is null");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDIsNotNull() {
            addCriterion("HOSOKU_CD is not null");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDEqualTo(String value) {
            addCriterion("HOSOKU_CD =", value, "HOSOKU_CD");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDNotEqualTo(String value) {
            addCriterion("HOSOKU_CD <>", value, "HOSOKU_CD");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDGreaterThan(String value) {
            addCriterion("HOSOKU_CD >", value, "HOSOKU_CD");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDGreaterThanOrEqualTo(String value) {
            addCriterion("HOSOKU_CD >=", value, "HOSOKU_CD");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDLessThan(String value) {
            addCriterion("HOSOKU_CD <", value, "HOSOKU_CD");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDLessThanOrEqualTo(String value) {
            addCriterion("HOSOKU_CD <=", value, "HOSOKU_CD");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDLike(String value) {
            addCriterion("HOSOKU_CD like", value, "HOSOKU_CD");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDNotLike(String value) {
            addCriterion("HOSOKU_CD not like", value, "HOSOKU_CD");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDIn(List<String> values) {
            addCriterion("HOSOKU_CD in", values, "HOSOKU_CD");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDNotIn(List<String> values) {
            addCriterion("HOSOKU_CD not in", values, "HOSOKU_CD");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDBetween(String value1, String value2) {
            addCriterion("HOSOKU_CD between", value1, value2, "HOSOKU_CD");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDNotBetween(String value1, String value2) {
            addCriterion("HOSOKU_CD not between", value1, value2, "HOSOKU_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSI_IDIsNull() {
            addCriterion("JIGYO_JISSI_ID is null");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSI_IDIsNotNull() {
            addCriterion("JIGYO_JISSI_ID is not null");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSI_IDEqualTo(String value) {
            addCriterion("JIGYO_JISSI_ID =", value, "JIGYO_JISSI_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSI_IDNotEqualTo(String value) {
            addCriterion("JIGYO_JISSI_ID <>", value, "JIGYO_JISSI_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSI_IDGreaterThan(String value) {
            addCriterion("JIGYO_JISSI_ID >", value, "JIGYO_JISSI_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSI_IDGreaterThanOrEqualTo(String value) {
            addCriterion("JIGYO_JISSI_ID >=", value, "JIGYO_JISSI_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSI_IDLessThan(String value) {
            addCriterion("JIGYO_JISSI_ID <", value, "JIGYO_JISSI_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSI_IDLessThanOrEqualTo(String value) {
            addCriterion("JIGYO_JISSI_ID <=", value, "JIGYO_JISSI_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSI_IDLike(String value) {
            addCriterion("JIGYO_JISSI_ID like", value, "JIGYO_JISSI_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSI_IDNotLike(String value) {
            addCriterion("JIGYO_JISSI_ID not like", value, "JIGYO_JISSI_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSI_IDIn(List<String> values) {
            addCriterion("JIGYO_JISSI_ID in", values, "JIGYO_JISSI_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSI_IDNotIn(List<String> values) {
            addCriterion("JIGYO_JISSI_ID not in", values, "JIGYO_JISSI_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSI_IDBetween(String value1, String value2) {
            addCriterion("JIGYO_JISSI_ID between", value1, value2, "JIGYO_JISSI_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSI_IDNotBetween(String value1, String value2) {
            addCriterion("JIGYO_JISSI_ID not between", value1, value2, "JIGYO_JISSI_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JYUTYU_IDIsNull() {
            addCriterion("JIGYO_JYUTYU_ID is null");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JYUTYU_IDIsNotNull() {
            addCriterion("JIGYO_JYUTYU_ID is not null");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JYUTYU_IDEqualTo(String value) {
            addCriterion("JIGYO_JYUTYU_ID =", value, "JIGYO_JYUTYU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JYUTYU_IDNotEqualTo(String value) {
            addCriterion("JIGYO_JYUTYU_ID <>", value, "JIGYO_JYUTYU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JYUTYU_IDGreaterThan(String value) {
            addCriterion("JIGYO_JYUTYU_ID >", value, "JIGYO_JYUTYU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JYUTYU_IDGreaterThanOrEqualTo(String value) {
            addCriterion("JIGYO_JYUTYU_ID >=", value, "JIGYO_JYUTYU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JYUTYU_IDLessThan(String value) {
            addCriterion("JIGYO_JYUTYU_ID <", value, "JIGYO_JYUTYU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JYUTYU_IDLessThanOrEqualTo(String value) {
            addCriterion("JIGYO_JYUTYU_ID <=", value, "JIGYO_JYUTYU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JYUTYU_IDLike(String value) {
            addCriterion("JIGYO_JYUTYU_ID like", value, "JIGYO_JYUTYU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JYUTYU_IDNotLike(String value) {
            addCriterion("JIGYO_JYUTYU_ID not like", value, "JIGYO_JYUTYU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JYUTYU_IDIn(List<String> values) {
            addCriterion("JIGYO_JYUTYU_ID in", values, "JIGYO_JYUTYU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JYUTYU_IDNotIn(List<String> values) {
            addCriterion("JIGYO_JYUTYU_ID not in", values, "JIGYO_JYUTYU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JYUTYU_IDBetween(String value1, String value2) {
            addCriterion("JIGYO_JYUTYU_ID between", value1, value2, "JIGYO_JYUTYU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JYUTYU_IDNotBetween(String value1, String value2) {
            addCriterion("JIGYO_JYUTYU_ID not between", value1, value2, "JIGYO_JYUTYU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSEKI_IDIsNull() {
            addCriterion("JIGYO_JISSEKI_ID is null");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSEKI_IDIsNotNull() {
            addCriterion("JIGYO_JISSEKI_ID is not null");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSEKI_IDEqualTo(String value) {
            addCriterion("JIGYO_JISSEKI_ID =", value, "JIGYO_JISSEKI_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSEKI_IDNotEqualTo(String value) {
            addCriterion("JIGYO_JISSEKI_ID <>", value, "JIGYO_JISSEKI_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSEKI_IDGreaterThan(String value) {
            addCriterion("JIGYO_JISSEKI_ID >", value, "JIGYO_JISSEKI_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSEKI_IDGreaterThanOrEqualTo(String value) {
            addCriterion("JIGYO_JISSEKI_ID >=", value, "JIGYO_JISSEKI_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSEKI_IDLessThan(String value) {
            addCriterion("JIGYO_JISSEKI_ID <", value, "JIGYO_JISSEKI_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSEKI_IDLessThanOrEqualTo(String value) {
            addCriterion("JIGYO_JISSEKI_ID <=", value, "JIGYO_JISSEKI_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSEKI_IDLike(String value) {
            addCriterion("JIGYO_JISSEKI_ID like", value, "JIGYO_JISSEKI_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSEKI_IDNotLike(String value) {
            addCriterion("JIGYO_JISSEKI_ID not like", value, "JIGYO_JISSEKI_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSEKI_IDIn(List<String> values) {
            addCriterion("JIGYO_JISSEKI_ID in", values, "JIGYO_JISSEKI_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSEKI_IDNotIn(List<String> values) {
            addCriterion("JIGYO_JISSEKI_ID not in", values, "JIGYO_JISSEKI_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSEKI_IDBetween(String value1, String value2) {
            addCriterion("JIGYO_JISSEKI_ID between", value1, value2, "JIGYO_JISSEKI_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSEKI_IDNotBetween(String value1, String value2) {
            addCriterion("JIGYO_JISSEKI_ID not between", value1, value2, "JIGYO_JISSEKI_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEIKYU_IDIsNull() {
            addCriterion("JIGYO_SEIKYU_ID is null");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEIKYU_IDIsNotNull() {
            addCriterion("JIGYO_SEIKYU_ID is not null");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEIKYU_IDEqualTo(String value) {
            addCriterion("JIGYO_SEIKYU_ID =", value, "JIGYO_SEIKYU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEIKYU_IDNotEqualTo(String value) {
            addCriterion("JIGYO_SEIKYU_ID <>", value, "JIGYO_SEIKYU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEIKYU_IDGreaterThan(String value) {
            addCriterion("JIGYO_SEIKYU_ID >", value, "JIGYO_SEIKYU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEIKYU_IDGreaterThanOrEqualTo(String value) {
            addCriterion("JIGYO_SEIKYU_ID >=", value, "JIGYO_SEIKYU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEIKYU_IDLessThan(String value) {
            addCriterion("JIGYO_SEIKYU_ID <", value, "JIGYO_SEIKYU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEIKYU_IDLessThanOrEqualTo(String value) {
            addCriterion("JIGYO_SEIKYU_ID <=", value, "JIGYO_SEIKYU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEIKYU_IDLike(String value) {
            addCriterion("JIGYO_SEIKYU_ID like", value, "JIGYO_SEIKYU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEIKYU_IDNotLike(String value) {
            addCriterion("JIGYO_SEIKYU_ID not like", value, "JIGYO_SEIKYU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEIKYU_IDIn(List<String> values) {
            addCriterion("JIGYO_SEIKYU_ID in", values, "JIGYO_SEIKYU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEIKYU_IDNotIn(List<String> values) {
            addCriterion("JIGYO_SEIKYU_ID not in", values, "JIGYO_SEIKYU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEIKYU_IDBetween(String value1, String value2) {
            addCriterion("JIGYO_SEIKYU_ID between", value1, value2, "JIGYO_SEIKYU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEIKYU_IDNotBetween(String value1, String value2) {
            addCriterion("JIGYO_SEIKYU_ID not between", value1, value2, "JIGYO_SEIKYU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_TOIAWASE_IDIsNull() {
            addCriterion("JIGYO_TOIAWASE_ID is null");
            return (Criteria) this;
        }

        public Criteria andJIGYO_TOIAWASE_IDIsNotNull() {
            addCriterion("JIGYO_TOIAWASE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andJIGYO_TOIAWASE_IDEqualTo(String value) {
            addCriterion("JIGYO_TOIAWASE_ID =", value, "JIGYO_TOIAWASE_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_TOIAWASE_IDNotEqualTo(String value) {
            addCriterion("JIGYO_TOIAWASE_ID <>", value, "JIGYO_TOIAWASE_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_TOIAWASE_IDGreaterThan(String value) {
            addCriterion("JIGYO_TOIAWASE_ID >", value, "JIGYO_TOIAWASE_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_TOIAWASE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("JIGYO_TOIAWASE_ID >=", value, "JIGYO_TOIAWASE_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_TOIAWASE_IDLessThan(String value) {
            addCriterion("JIGYO_TOIAWASE_ID <", value, "JIGYO_TOIAWASE_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_TOIAWASE_IDLessThanOrEqualTo(String value) {
            addCriterion("JIGYO_TOIAWASE_ID <=", value, "JIGYO_TOIAWASE_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_TOIAWASE_IDLike(String value) {
            addCriterion("JIGYO_TOIAWASE_ID like", value, "JIGYO_TOIAWASE_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_TOIAWASE_IDNotLike(String value) {
            addCriterion("JIGYO_TOIAWASE_ID not like", value, "JIGYO_TOIAWASE_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_TOIAWASE_IDIn(List<String> values) {
            addCriterion("JIGYO_TOIAWASE_ID in", values, "JIGYO_TOIAWASE_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_TOIAWASE_IDNotIn(List<String> values) {
            addCriterion("JIGYO_TOIAWASE_ID not in", values, "JIGYO_TOIAWASE_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_TOIAWASE_IDBetween(String value1, String value2) {
            addCriterion("JIGYO_TOIAWASE_ID between", value1, value2, "JIGYO_TOIAWASE_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_TOIAWASE_IDNotBetween(String value1, String value2) {
            addCriterion("JIGYO_TOIAWASE_ID not between", value1, value2, "JIGYO_TOIAWASE_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_EIGYOU_IDIsNull() {
            addCriterion("JIGYO_EIGYOU_ID is null");
            return (Criteria) this;
        }

        public Criteria andJIGYO_EIGYOU_IDIsNotNull() {
            addCriterion("JIGYO_EIGYOU_ID is not null");
            return (Criteria) this;
        }

        public Criteria andJIGYO_EIGYOU_IDEqualTo(String value) {
            addCriterion("JIGYO_EIGYOU_ID =", value, "JIGYO_EIGYOU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_EIGYOU_IDNotEqualTo(String value) {
            addCriterion("JIGYO_EIGYOU_ID <>", value, "JIGYO_EIGYOU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_EIGYOU_IDGreaterThan(String value) {
            addCriterion("JIGYO_EIGYOU_ID >", value, "JIGYO_EIGYOU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_EIGYOU_IDGreaterThanOrEqualTo(String value) {
            addCriterion("JIGYO_EIGYOU_ID >=", value, "JIGYO_EIGYOU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_EIGYOU_IDLessThan(String value) {
            addCriterion("JIGYO_EIGYOU_ID <", value, "JIGYO_EIGYOU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_EIGYOU_IDLessThanOrEqualTo(String value) {
            addCriterion("JIGYO_EIGYOU_ID <=", value, "JIGYO_EIGYOU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_EIGYOU_IDLike(String value) {
            addCriterion("JIGYO_EIGYOU_ID like", value, "JIGYO_EIGYOU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_EIGYOU_IDNotLike(String value) {
            addCriterion("JIGYO_EIGYOU_ID not like", value, "JIGYO_EIGYOU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_EIGYOU_IDIn(List<String> values) {
            addCriterion("JIGYO_EIGYOU_ID in", values, "JIGYO_EIGYOU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_EIGYOU_IDNotIn(List<String> values) {
            addCriterion("JIGYO_EIGYOU_ID not in", values, "JIGYO_EIGYOU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_EIGYOU_IDBetween(String value1, String value2) {
            addCriterion("JIGYO_EIGYOU_ID between", value1, value2, "JIGYO_EIGYOU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_EIGYOU_IDNotBetween(String value1, String value2) {
            addCriterion("JIGYO_EIGYOU_ID not between", value1, value2, "JIGYO_EIGYOU_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andLN_JIANLikeInsensitive(String value) {
            addCriterion("upper(LN_JIAN) like", value.toUpperCase(), "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM1LikeInsensitive(String value) {
            addCriterion("upper(CUSTOMER_NUM1) like", value.toUpperCase(), "CUSTOMER_NUM1");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM2LikeInsensitive(String value) {
            addCriterion("upper(CUSTOMER_NUM2) like", value.toUpperCase(), "CUSTOMER_NUM2");
            return (Criteria) this;
        }

        public Criteria andCUSTOMER_NUM3LikeInsensitive(String value) {
            addCriterion("upper(CUSTOMER_NUM3) like", value.toUpperCase(), "CUSTOMER_NUM3");
            return (Criteria) this;
        }

        public Criteria andCHIKULikeInsensitive(String value) {
            addCriterion("upper(CHIKU) like", value.toUpperCase(), "CHIKU");
            return (Criteria) this;
        }

        public Criteria andGOUKILikeInsensitive(String value) {
            addCriterion("upper(GOUKI) like", value.toUpperCase(), "GOUKI");
            return (Criteria) this;
        }

        public Criteria andSUBADDRLikeInsensitive(String value) {
            addCriterion("upper(SUBADDR) like", value.toUpperCase(), "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG1LikeInsensitive(String value) {
            addCriterion("upper(SINPO_FLG1) like", value.toUpperCase(), "SINPO_FLG1");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG2LikeInsensitive(String value) {
            addCriterion("upper(SINPO_FLG2) like", value.toUpperCase(), "SINPO_FLG2");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG3LikeInsensitive(String value) {
            addCriterion("upper(SINPO_FLG3) like", value.toUpperCase(), "SINPO_FLG3");
            return (Criteria) this;
        }

        public Criteria andSINPO_FLG4LikeInsensitive(String value) {
            addCriterion("upper(SINPO_FLG4) like", value.toUpperCase(), "SINPO_FLG4");
            return (Criteria) this;
        }

        public Criteria andIMPORTANT_FLGLikeInsensitive(String value) {
            addCriterion("upper(IMPORTANT_FLG) like", value.toUpperCase(), "IMPORTANT_FLG");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_NMLikeInsensitive(String value) {
            addCriterion("upper(KEIYAKU_NM) like", value.toUpperCase(), "KEIYAKU_NM");
            return (Criteria) this;
        }

        public Criteria andGC_IDLikeInsensitive(String value) {
            addCriterion("upper(GC_ID) like", value.toUpperCase(), "GC_ID");
            return (Criteria) this;
        }

        public Criteria andAREA_IDLikeInsensitive(String value) {
            addCriterion("upper(AREA_ID) like", value.toUpperCase(), "AREA_ID");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM1LikeInsensitive(String value) {
            addCriterion("upper(KEIBI_NM1) like", value.toUpperCase(), "KEIBI_NM1");
            return (Criteria) this;
        }

        public Criteria andKEIBI_NM2LikeInsensitive(String value) {
            addCriterion("upper(KEIBI_NM2) like", value.toUpperCase(), "KEIBI_NM2");
            return (Criteria) this;
        }

        public Criteria andKEIBISAKI_ABBR_NMLikeInsensitive(String value) {
            addCriterion("upper(KEIBISAKI_ABBR_NM) like", value.toUpperCase(), "KEIBISAKI_ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andPOST_NUMLikeInsensitive(String value) {
            addCriterion("upper(POST_NUM) like", value.toUpperCase(), "POST_NUM");
            return (Criteria) this;
        }

        public Criteria andADDR_CD1_IDLikeInsensitive(String value) {
            addCriterion("upper(ADDR_CD1_ID) like", value.toUpperCase(), "ADDR_CD1_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD2_IDLikeInsensitive(String value) {
            addCriterion("upper(ADDR_CD2_ID) like", value.toUpperCase(), "ADDR_CD2_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD3_IDLikeInsensitive(String value) {
            addCriterion("upper(ADDR_CD3_ID) like", value.toUpperCase(), "ADDR_CD3_ID");
            return (Criteria) this;
        }

        public Criteria andADDR_CD4_IDLikeInsensitive(String value) {
            addCriterion("upper(ADDR_CD4_ID) like", value.toUpperCase(), "ADDR_CD4_ID");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT1LikeInsensitive(String value) {
            addCriterion("upper(ADDRESS_OPT1) like", value.toUpperCase(), "ADDRESS_OPT1");
            return (Criteria) this;
        }

        public Criteria andADDRESS_OPT2LikeInsensitive(String value) {
            addCriterion("upper(ADDRESS_OPT2) like", value.toUpperCase(), "ADDRESS_OPT2");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND1LikeInsensitive(String value) {
            addCriterion("upper(KEIYAKU_KIND1) like", value.toUpperCase(), "KEIYAKU_KIND1");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_KIND2LikeInsensitive(String value) {
            addCriterion("upper(KEIYAKU_KIND2) like", value.toUpperCase(), "KEIYAKU_KIND2");
            return (Criteria) this;
        }

        public Criteria andKOBETU_NMLikeInsensitive(String value) {
            addCriterion("upper(KOBETU_NM) like", value.toUpperCase(), "KOBETU_NM");
            return (Criteria) this;
        }

        public Criteria andGYOUMU_CDLikeInsensitive(String value) {
            addCriterion("upper(GYOUMU_CD) like", value.toUpperCase(), "GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_CDLikeInsensitive(String value) {
            addCriterion("upper(HOSOKU_CD) like", value.toUpperCase(), "HOSOKU_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSI_IDLikeInsensitive(String value) {
            addCriterion("upper(JIGYO_JISSI_ID) like", value.toUpperCase(), "JIGYO_JISSI_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JYUTYU_IDLikeInsensitive(String value) {
            addCriterion("upper(JIGYO_JYUTYU_ID) like", value.toUpperCase(), "JIGYO_JYUTYU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_JISSEKI_IDLikeInsensitive(String value) {
            addCriterion("upper(JIGYO_JISSEKI_ID) like", value.toUpperCase(), "JIGYO_JISSEKI_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_SEIKYU_IDLikeInsensitive(String value) {
            addCriterion("upper(JIGYO_SEIKYU_ID) like", value.toUpperCase(), "JIGYO_SEIKYU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_TOIAWASE_IDLikeInsensitive(String value) {
            addCriterion("upper(JIGYO_TOIAWASE_ID) like", value.toUpperCase(), "JIGYO_TOIAWASE_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYO_EIGYOU_IDLikeInsensitive(String value) {
            addCriterion("upper(JIGYO_EIGYOU_ID) like", value.toUpperCase(), "JIGYO_EIGYOU_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * E_JIAN_OCCURRENCE
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * E_JIAN_OCCURRENCE null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}