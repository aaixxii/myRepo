package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class HEventInfo implements Serializable {
    /**
     * LN_イベント管理情報履歴論理番号
     */
    private String LN_EVENT_INFO_HST;

    /**
     * 発生日時
     */
    private String HASSEI_TS;

    /**
     * 地区名称
     */
    private String CHIKU_NM;

    /**
     * 検知内容
     */
    private String KENCHI_NAIYOU;

    /**
     * 警備状態
     */
    private String KB_STS;

    /**
     * 画像利用フラグ
     */
    private String VIDE_LK_FLG;

    /**
     * イベント画像ファイル情報
     */
    private String VFILE_INFO;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * H_EVENT_INFO
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_イベント管理情報履歴論理番号
     * @return LN_EVENT_INFO_HST LN_イベント管理情報履歴論理番号
     */
    public String getLN_EVENT_INFO_HST() {
        return LN_EVENT_INFO_HST;
    }

    /**
     * LN_イベント管理情報履歴論理番号
     * @param LN_EVENT_INFO_HST LN_イベント管理情報履歴論理番号
     */
    public void setLN_EVENT_INFO_HST(String LN_EVENT_INFO_HST) {
        this.LN_EVENT_INFO_HST = LN_EVENT_INFO_HST == null ? null : LN_EVENT_INFO_HST.trim();
    }

    /**
     * 発生日時
     * @return HASSEI_TS 発生日時
     */
    public String getHASSEI_TS() {
        return HASSEI_TS;
    }

    /**
     * 発生日時
     * @param HASSEI_TS 発生日時
     */
    public void setHASSEI_TS(String HASSEI_TS) {
        this.HASSEI_TS = HASSEI_TS == null ? null : HASSEI_TS.trim();
    }

    /**
     * 地区名称
     * @return CHIKU_NM 地区名称
     */
    public String getCHIKU_NM() {
        return CHIKU_NM;
    }

    /**
     * 地区名称
     * @param CHIKU_NM 地区名称
     */
    public void setCHIKU_NM(String CHIKU_NM) {
        this.CHIKU_NM = CHIKU_NM == null ? null : CHIKU_NM.trim();
    }

    /**
     * 検知内容
     * @return KENCHI_NAIYOU 検知内容
     */
    public String getKENCHI_NAIYOU() {
        return KENCHI_NAIYOU;
    }

    /**
     * 検知内容
     * @param KENCHI_NAIYOU 検知内容
     */
    public void setKENCHI_NAIYOU(String KENCHI_NAIYOU) {
        this.KENCHI_NAIYOU = KENCHI_NAIYOU == null ? null : KENCHI_NAIYOU.trim();
    }

    /**
     * 警備状態
     * @return KB_STS 警備状態
     */
    public String getKB_STS() {
        return KB_STS;
    }

    /**
     * 警備状態
     * @param KB_STS 警備状態
     */
    public void setKB_STS(String KB_STS) {
        this.KB_STS = KB_STS == null ? null : KB_STS.trim();
    }

    /**
     * 画像利用フラグ
     * @return VIDE_LK_FLG 画像利用フラグ
     */
    public String getVIDE_LK_FLG() {
        return VIDE_LK_FLG;
    }

    /**
     * 画像利用フラグ
     * @param VIDE_LK_FLG 画像利用フラグ
     */
    public void setVIDE_LK_FLG(String VIDE_LK_FLG) {
        this.VIDE_LK_FLG = VIDE_LK_FLG == null ? null : VIDE_LK_FLG.trim();
    }

    /**
     * イベント画像ファイル情報
     * @return VFILE_INFO イベント画像ファイル情報
     */
    public String getVFILE_INFO() {
        return VFILE_INFO;
    }

    /**
     * イベント画像ファイル情報
     * @param VFILE_INFO イベント画像ファイル情報
     */
    public void setVFILE_INFO(String VFILE_INFO) {
        this.VFILE_INFO = VFILE_INFO == null ? null : VFILE_INFO.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}