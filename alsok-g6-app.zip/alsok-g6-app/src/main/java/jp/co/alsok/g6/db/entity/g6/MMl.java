package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class MMl implements Serializable {
    /**
     * 種別
     */
    private String KIND;

    /**
     * 優先度
     */
    private String PRIORITY;

    /**
     * 最大リトライ回数
     */
    private String MAX_RETRY_NUM;

    /**
     * リトライ間隔
     */
    private Integer RETRY_INT;

    /**
     * 送信可能開始時間
     */
    private Date SEND_ABL_FROM_TM;

    /**
     * 送信可能終了時間
     */
    private Date SEND_ABL_TO_TM;

    /**
     * 差出人メールアドレス
     */
    private String ML_ADDR_FROM;

    /**
     * M_ML
     */
    private static final long serialVersionUID = 1L;

    /**
     * 種別
     * @return KIND 種別
     */
    public String getKIND() {
        return KIND;
    }

    /**
     * 種別
     * @param KIND 種別
     */
    public void setKIND(String KIND) {
        this.KIND = KIND == null ? null : KIND.trim();
    }

    /**
     * 優先度
     * @return PRIORITY 優先度
     */
    public String getPRIORITY() {
        return PRIORITY;
    }

    /**
     * 優先度
     * @param PRIORITY 優先度
     */
    public void setPRIORITY(String PRIORITY) {
        this.PRIORITY = PRIORITY == null ? null : PRIORITY.trim();
    }

    /**
     * 最大リトライ回数
     * @return MAX_RETRY_NUM 最大リトライ回数
     */
    public String getMAX_RETRY_NUM() {
        return MAX_RETRY_NUM;
    }

    /**
     * 最大リトライ回数
     * @param MAX_RETRY_NUM 最大リトライ回数
     */
    public void setMAX_RETRY_NUM(String MAX_RETRY_NUM) {
        this.MAX_RETRY_NUM = MAX_RETRY_NUM == null ? null : MAX_RETRY_NUM.trim();
    }

    /**
     * リトライ間隔
     * @return RETRY_INT リトライ間隔
     */
    public Integer getRETRY_INT() {
        return RETRY_INT;
    }

    /**
     * リトライ間隔
     * @param RETRY_INT リトライ間隔
     */
    public void setRETRY_INT(Integer RETRY_INT) {
        this.RETRY_INT = RETRY_INT;
    }

    /**
     * 送信可能開始時間
     * @return SEND_ABL_FROM_TM 送信可能開始時間
     */
    public Date getSEND_ABL_FROM_TM() {
        return SEND_ABL_FROM_TM;
    }

    /**
     * 送信可能開始時間
     * @param SEND_ABL_FROM_TM 送信可能開始時間
     */
    public void setSEND_ABL_FROM_TM(Date SEND_ABL_FROM_TM) {
        this.SEND_ABL_FROM_TM = SEND_ABL_FROM_TM;
    }

    /**
     * 送信可能終了時間
     * @return SEND_ABL_TO_TM 送信可能終了時間
     */
    public Date getSEND_ABL_TO_TM() {
        return SEND_ABL_TO_TM;
    }

    /**
     * 送信可能終了時間
     * @param SEND_ABL_TO_TM 送信可能終了時間
     */
    public void setSEND_ABL_TO_TM(Date SEND_ABL_TO_TM) {
        this.SEND_ABL_TO_TM = SEND_ABL_TO_TM;
    }

    /**
     * 差出人メールアドレス
     * @return ML_ADDR_FROM 差出人メールアドレス
     */
    public String getML_ADDR_FROM() {
        return ML_ADDR_FROM;
    }

    /**
     * 差出人メールアドレス
     * @param ML_ADDR_FROM 差出人メールアドレス
     */
    public void setML_ADDR_FROM(String ML_ADDR_FROM) {
        this.ML_ADDR_FROM = ML_ADDR_FROM == null ? null : ML_ADDR_FROM.trim();
    }
}