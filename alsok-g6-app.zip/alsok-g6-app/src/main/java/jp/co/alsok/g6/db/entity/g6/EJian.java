package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class EJian implements Serializable {
    /**
     * LN_事案論理番号
     */
    private String LN_JIAN;

    /**
     * LN_事態論理番号
     */
    private String LN_JITAI;

    /**
     * LN_警備先地区論理番号
     */
    private String LN_KB_CHIKU;

    /**
     * ブザー鳴動フラグ
     */
    private String BUZZ_FLG;

    /**
     * 事案優先順位
     */
    private String PRIORITY;

    /**
     * 事案発生元フラグ
     */
    private String JIAN_CAUSE_FLG;

    /**
     * 事案表示先フラグ
     */
    private String JIAN_HYOJI_FLG;

    /**
     * 事案担当先フラグ
     */
    private String JIAN_TANTO_FLG;

    /**
     * タイムアウト日時
     */
    private Date TIMEOUT_TS;

    /**
     * 未判断事案発生日時
     */
    private Date PRE_JIAN_HASSEI_TS;

    /**
     * 事案発生日時
     */
    private Date JIAN_HASSEI_TS;

    /**
     * 最新信号(ID_警備情報論理番号)
     */
    private String LN_LAST_SIG;

    /**
     * 最新入退館信号(ID_警備情報論理番号)
     */
    private String LN_LAST_NF_SIG;

    /**
     * GC送信済みフラグ
     */
    private String GC_SENT_FLG;

    /**
     * ＧＣ要請日時
     */
    private Date GC_SENT_TS;

    /**
     * 事案作成者ＩＤ
     */
    private String LN_JIAN_MAKE_USER;

    /**
     * 事案作成者名
     */
    private String JIAN_MAKE_USER_NM;

    /**
     * 事案落着者ID
     */
    private String LN_JIAN_END_USER_ID;

    /**
     * 事案落着者名
     */
    private String JIAN_END_USER_NM;

    /**
     * LN_画面登録区分論理番号
     */
    private String LN_TOROKU_KIND_NUM;

    /**
     * 画面登録区分コード
     */
    private String TOROKU_KIND_CD;

    /**
     * 画面登録種別
     */
    private String TOROKU_KIND;

    /**
     * 発生日時
     */
    private Date HASSEI_TS;

    /**
     * 原因日時
     */
    private Date GENIN_TS;

    /**
     * 終了日時
     */
    private Date END_TS;

    /**
     * 原因論理番号(未使用)
     */
    private String LN_GENIN;

    /**
     * 次期警備原因内容
     */
    private String KEIBI_GENIN_NAIYOU;

    /**
     * 初期事案表示端末種別
     */
    private String FIRST_JIAN_HYOUJI_DEV_KIND;

    /**
     * 事案操作権保持端末種別
     */
    private String JIAN_OPE_AUTH_DEV_KIND;

    /**
     * リミットタイマ延長（秒）
     */
    private String LIMIT_EXT_SS;

    /**
     * リミットタイマ延長最大値(秒)
     */
    private String LIMIT_EXT_MAX_SS;

    /**
     * 最終更新日時
     */
    private Date LASTUPD_TS;

    /**
     * 真報判断実施フラグ
     */
    private String SINPO_JISSI_FLG;

    /**
     * 事案復旧フラグ
     */
    private String JIAN_FUKKYU_FLG;

    /**
     * 次期警備原因ID
     */
    private String GENIN_ID;

    /**
     * 真報理由フラグ
     */
    private String SINPO_REASON_FLG;

    /**
     * 落着フラグ
     */
    private String RAKUCHAKU_FLG;

    /**
     * インタホン状態
     */
    private String INTP_STS;

    /**
     * SGS原因コード(新画像)
     */
    private String SGS_GENIN_CD;

    /**
     * NET原因コード(新画像)
     */
    private String NET_GENIN_CD;

    /**
     * LN_第一警報論理番号
     */
    private String LN_KB_INF1;

    /**
     * LN_第二警報論理番号
     */
    private String LN_KB_INF2;

    /**
     * LN_第三警報論理番号
     */
    private String LN_KB_INF3;

    /**
     * LN_情報提供第一論理番号
     */
    private String LN_KB_INF_CUST1;

    /**
     * LN_リモメン第一警報論理番号
     */
    private String LN_KB_INF1_RM;

    /**
     * LN_リモメン第二警報論理番号
     */
    private String LN_KB_INF2_RM;

    /**
     * LN_リモメン第三警報論理番号
     */
    private String LN_KB_INF3_RM;

    /**
     * リモメン最新信号
     */
    private String LN_LAST_SIG_RM;

    /**
     * RM警報予告フラグ
     */
    private String RM_BUZZ_NOTICE_FLG;

    /**
     * RM警報送信フラグ
     */
    private String RM_SIG_SEND_FLG;

    /**
     * ライブビューワ起動
     */
    private String LIVE_VIEWER_FLG;

    /**
     * RM表示レコード有フラグ
     */
    private String RM_DISP_FLG;

    /**
     * 真報判断起動フラグ
     */
    private String SINPO_KIDOU_FLG;

    /**
     * 事業所_ID
     */
    private String JIGYOU_ID;

    /**
     * オペレータ_ID
     */
    private String OPERATOR_ID;

    /**
     * LN_ファイル送信論理番号
     */
    private String LN_FILE_SEND;

    /**
     * 処理通番
     */
    private String PROCESS_NUM;

    /**
     * キーレス権限ステータス
     */
    private String KYLESS_ST;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * E_JIAN
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_事案論理番号
     * @return LN_JIAN LN_事案論理番号
     */
    public String getLN_JIAN() {
        return LN_JIAN;
    }

    /**
     * LN_事案論理番号
     * @param LN_JIAN LN_事案論理番号
     */
    public void setLN_JIAN(String LN_JIAN) {
        this.LN_JIAN = LN_JIAN == null ? null : LN_JIAN.trim();
    }

    /**
     * LN_事態論理番号
     * @return LN_JITAI LN_事態論理番号
     */
    public String getLN_JITAI() {
        return LN_JITAI;
    }

    /**
     * LN_事態論理番号
     * @param LN_JITAI LN_事態論理番号
     */
    public void setLN_JITAI(String LN_JITAI) {
        this.LN_JITAI = LN_JITAI == null ? null : LN_JITAI.trim();
    }

    /**
     * LN_警備先地区論理番号
     * @return LN_KB_CHIKU LN_警備先地区論理番号
     */
    public String getLN_KB_CHIKU() {
        return LN_KB_CHIKU;
    }

    /**
     * LN_警備先地区論理番号
     * @param LN_KB_CHIKU LN_警備先地区論理番号
     */
    public void setLN_KB_CHIKU(String LN_KB_CHIKU) {
        this.LN_KB_CHIKU = LN_KB_CHIKU == null ? null : LN_KB_CHIKU.trim();
    }

    /**
     * ブザー鳴動フラグ
     * @return BUZZ_FLG ブザー鳴動フラグ
     */
    public String getBUZZ_FLG() {
        return BUZZ_FLG;
    }

    /**
     * ブザー鳴動フラグ
     * @param BUZZ_FLG ブザー鳴動フラグ
     */
    public void setBUZZ_FLG(String BUZZ_FLG) {
        this.BUZZ_FLG = BUZZ_FLG == null ? null : BUZZ_FLG.trim();
    }

    /**
     * 事案優先順位
     * @return PRIORITY 事案優先順位
     */
    public String getPRIORITY() {
        return PRIORITY;
    }

    /**
     * 事案優先順位
     * @param PRIORITY 事案優先順位
     */
    public void setPRIORITY(String PRIORITY) {
        this.PRIORITY = PRIORITY == null ? null : PRIORITY.trim();
    }

    /**
     * 事案発生元フラグ
     * @return JIAN_CAUSE_FLG 事案発生元フラグ
     */
    public String getJIAN_CAUSE_FLG() {
        return JIAN_CAUSE_FLG;
    }

    /**
     * 事案発生元フラグ
     * @param JIAN_CAUSE_FLG 事案発生元フラグ
     */
    public void setJIAN_CAUSE_FLG(String JIAN_CAUSE_FLG) {
        this.JIAN_CAUSE_FLG = JIAN_CAUSE_FLG == null ? null : JIAN_CAUSE_FLG.trim();
    }

    /**
     * 事案表示先フラグ
     * @return JIAN_HYOJI_FLG 事案表示先フラグ
     */
    public String getJIAN_HYOJI_FLG() {
        return JIAN_HYOJI_FLG;
    }

    /**
     * 事案表示先フラグ
     * @param JIAN_HYOJI_FLG 事案表示先フラグ
     */
    public void setJIAN_HYOJI_FLG(String JIAN_HYOJI_FLG) {
        this.JIAN_HYOJI_FLG = JIAN_HYOJI_FLG == null ? null : JIAN_HYOJI_FLG.trim();
    }

    /**
     * 事案担当先フラグ
     * @return JIAN_TANTO_FLG 事案担当先フラグ
     */
    public String getJIAN_TANTO_FLG() {
        return JIAN_TANTO_FLG;
    }

    /**
     * 事案担当先フラグ
     * @param JIAN_TANTO_FLG 事案担当先フラグ
     */
    public void setJIAN_TANTO_FLG(String JIAN_TANTO_FLG) {
        this.JIAN_TANTO_FLG = JIAN_TANTO_FLG == null ? null : JIAN_TANTO_FLG.trim();
    }

    /**
     * タイムアウト日時
     * @return TIMEOUT_TS タイムアウト日時
     */
    public Date getTIMEOUT_TS() {
        return TIMEOUT_TS;
    }

    /**
     * タイムアウト日時
     * @param TIMEOUT_TS タイムアウト日時
     */
    public void setTIMEOUT_TS(Date TIMEOUT_TS) {
        this.TIMEOUT_TS = TIMEOUT_TS;
    }

    /**
     * 未判断事案発生日時
     * @return PRE_JIAN_HASSEI_TS 未判断事案発生日時
     */
    public Date getPRE_JIAN_HASSEI_TS() {
        return PRE_JIAN_HASSEI_TS;
    }

    /**
     * 未判断事案発生日時
     * @param PRE_JIAN_HASSEI_TS 未判断事案発生日時
     */
    public void setPRE_JIAN_HASSEI_TS(Date PRE_JIAN_HASSEI_TS) {
        this.PRE_JIAN_HASSEI_TS = PRE_JIAN_HASSEI_TS;
    }

    /**
     * 事案発生日時
     * @return JIAN_HASSEI_TS 事案発生日時
     */
    public Date getJIAN_HASSEI_TS() {
        return JIAN_HASSEI_TS;
    }

    /**
     * 事案発生日時
     * @param JIAN_HASSEI_TS 事案発生日時
     */
    public void setJIAN_HASSEI_TS(Date JIAN_HASSEI_TS) {
        this.JIAN_HASSEI_TS = JIAN_HASSEI_TS;
    }

    /**
     * 最新信号(ID_警備情報論理番号)
     * @return LN_LAST_SIG 最新信号(ID_警備情報論理番号)
     */
    public String getLN_LAST_SIG() {
        return LN_LAST_SIG;
    }

    /**
     * 最新信号(ID_警備情報論理番号)
     * @param LN_LAST_SIG 最新信号(ID_警備情報論理番号)
     */
    public void setLN_LAST_SIG(String LN_LAST_SIG) {
        this.LN_LAST_SIG = LN_LAST_SIG == null ? null : LN_LAST_SIG.trim();
    }

    /**
     * 最新入退館信号(ID_警備情報論理番号)
     * @return LN_LAST_NF_SIG 最新入退館信号(ID_警備情報論理番号)
     */
    public String getLN_LAST_NF_SIG() {
        return LN_LAST_NF_SIG;
    }

    /**
     * 最新入退館信号(ID_警備情報論理番号)
     * @param LN_LAST_NF_SIG 最新入退館信号(ID_警備情報論理番号)
     */
    public void setLN_LAST_NF_SIG(String LN_LAST_NF_SIG) {
        this.LN_LAST_NF_SIG = LN_LAST_NF_SIG == null ? null : LN_LAST_NF_SIG.trim();
    }

    /**
     * GC送信済みフラグ
     * @return GC_SENT_FLG GC送信済みフラグ
     */
    public String getGC_SENT_FLG() {
        return GC_SENT_FLG;
    }

    /**
     * GC送信済みフラグ
     * @param GC_SENT_FLG GC送信済みフラグ
     */
    public void setGC_SENT_FLG(String GC_SENT_FLG) {
        this.GC_SENT_FLG = GC_SENT_FLG == null ? null : GC_SENT_FLG.trim();
    }

    /**
     * ＧＣ要請日時
     * @return GC_SENT_TS ＧＣ要請日時
     */
    public Date getGC_SENT_TS() {
        return GC_SENT_TS;
    }

    /**
     * ＧＣ要請日時
     * @param GC_SENT_TS ＧＣ要請日時
     */
    public void setGC_SENT_TS(Date GC_SENT_TS) {
        this.GC_SENT_TS = GC_SENT_TS;
    }

    /**
     * 事案作成者ＩＤ
     * @return LN_JIAN_MAKE_USER 事案作成者ＩＤ
     */
    public String getLN_JIAN_MAKE_USER() {
        return LN_JIAN_MAKE_USER;
    }

    /**
     * 事案作成者ＩＤ
     * @param LN_JIAN_MAKE_USER 事案作成者ＩＤ
     */
    public void setLN_JIAN_MAKE_USER(String LN_JIAN_MAKE_USER) {
        this.LN_JIAN_MAKE_USER = LN_JIAN_MAKE_USER == null ? null : LN_JIAN_MAKE_USER.trim();
    }

    /**
     * 事案作成者名
     * @return JIAN_MAKE_USER_NM 事案作成者名
     */
    public String getJIAN_MAKE_USER_NM() {
        return JIAN_MAKE_USER_NM;
    }

    /**
     * 事案作成者名
     * @param JIAN_MAKE_USER_NM 事案作成者名
     */
    public void setJIAN_MAKE_USER_NM(String JIAN_MAKE_USER_NM) {
        this.JIAN_MAKE_USER_NM = JIAN_MAKE_USER_NM == null ? null : JIAN_MAKE_USER_NM.trim();
    }

    /**
     * 事案落着者ID
     * @return LN_JIAN_END_USER_ID 事案落着者ID
     */
    public String getLN_JIAN_END_USER_ID() {
        return LN_JIAN_END_USER_ID;
    }

    /**
     * 事案落着者ID
     * @param LN_JIAN_END_USER_ID 事案落着者ID
     */
    public void setLN_JIAN_END_USER_ID(String LN_JIAN_END_USER_ID) {
        this.LN_JIAN_END_USER_ID = LN_JIAN_END_USER_ID == null ? null : LN_JIAN_END_USER_ID.trim();
    }

    /**
     * 事案落着者名
     * @return JIAN_END_USER_NM 事案落着者名
     */
    public String getJIAN_END_USER_NM() {
        return JIAN_END_USER_NM;
    }

    /**
     * 事案落着者名
     * @param JIAN_END_USER_NM 事案落着者名
     */
    public void setJIAN_END_USER_NM(String JIAN_END_USER_NM) {
        this.JIAN_END_USER_NM = JIAN_END_USER_NM == null ? null : JIAN_END_USER_NM.trim();
    }

    /**
     * LN_画面登録区分論理番号
     * @return LN_TOROKU_KIND_NUM LN_画面登録区分論理番号
     */
    public String getLN_TOROKU_KIND_NUM() {
        return LN_TOROKU_KIND_NUM;
    }

    /**
     * LN_画面登録区分論理番号
     * @param LN_TOROKU_KIND_NUM LN_画面登録区分論理番号
     */
    public void setLN_TOROKU_KIND_NUM(String LN_TOROKU_KIND_NUM) {
        this.LN_TOROKU_KIND_NUM = LN_TOROKU_KIND_NUM == null ? null : LN_TOROKU_KIND_NUM.trim();
    }

    /**
     * 画面登録区分コード
     * @return TOROKU_KIND_CD 画面登録区分コード
     */
    public String getTOROKU_KIND_CD() {
        return TOROKU_KIND_CD;
    }

    /**
     * 画面登録区分コード
     * @param TOROKU_KIND_CD 画面登録区分コード
     */
    public void setTOROKU_KIND_CD(String TOROKU_KIND_CD) {
        this.TOROKU_KIND_CD = TOROKU_KIND_CD == null ? null : TOROKU_KIND_CD.trim();
    }

    /**
     * 画面登録種別
     * @return TOROKU_KIND 画面登録種別
     */
    public String getTOROKU_KIND() {
        return TOROKU_KIND;
    }

    /**
     * 画面登録種別
     * @param TOROKU_KIND 画面登録種別
     */
    public void setTOROKU_KIND(String TOROKU_KIND) {
        this.TOROKU_KIND = TOROKU_KIND == null ? null : TOROKU_KIND.trim();
    }

    /**
     * 発生日時
     * @return HASSEI_TS 発生日時
     */
    public Date getHASSEI_TS() {
        return HASSEI_TS;
    }

    /**
     * 発生日時
     * @param HASSEI_TS 発生日時
     */
    public void setHASSEI_TS(Date HASSEI_TS) {
        this.HASSEI_TS = HASSEI_TS;
    }

    /**
     * 原因日時
     * @return GENIN_TS 原因日時
     */
    public Date getGENIN_TS() {
        return GENIN_TS;
    }

    /**
     * 原因日時
     * @param GENIN_TS 原因日時
     */
    public void setGENIN_TS(Date GENIN_TS) {
        this.GENIN_TS = GENIN_TS;
    }

    /**
     * 終了日時
     * @return END_TS 終了日時
     */
    public Date getEND_TS() {
        return END_TS;
    }

    /**
     * 終了日時
     * @param END_TS 終了日時
     */
    public void setEND_TS(Date END_TS) {
        this.END_TS = END_TS;
    }

    /**
     * 原因論理番号(未使用)
     * @return LN_GENIN 原因論理番号(未使用)
     */
    public String getLN_GENIN() {
        return LN_GENIN;
    }

    /**
     * 原因論理番号(未使用)
     * @param LN_GENIN 原因論理番号(未使用)
     */
    public void setLN_GENIN(String LN_GENIN) {
        this.LN_GENIN = LN_GENIN == null ? null : LN_GENIN.trim();
    }

    /**
     * 次期警備原因内容
     * @return KEIBI_GENIN_NAIYOU 次期警備原因内容
     */
    public String getKEIBI_GENIN_NAIYOU() {
        return KEIBI_GENIN_NAIYOU;
    }

    /**
     * 次期警備原因内容
     * @param KEIBI_GENIN_NAIYOU 次期警備原因内容
     */
    public void setKEIBI_GENIN_NAIYOU(String KEIBI_GENIN_NAIYOU) {
        this.KEIBI_GENIN_NAIYOU = KEIBI_GENIN_NAIYOU == null ? null : KEIBI_GENIN_NAIYOU.trim();
    }

    /**
     * 初期事案表示端末種別
     * @return FIRST_JIAN_HYOUJI_DEV_KIND 初期事案表示端末種別
     */
    public String getFIRST_JIAN_HYOUJI_DEV_KIND() {
        return FIRST_JIAN_HYOUJI_DEV_KIND;
    }

    /**
     * 初期事案表示端末種別
     * @param FIRST_JIAN_HYOUJI_DEV_KIND 初期事案表示端末種別
     */
    public void setFIRST_JIAN_HYOUJI_DEV_KIND(String FIRST_JIAN_HYOUJI_DEV_KIND) {
        this.FIRST_JIAN_HYOUJI_DEV_KIND = FIRST_JIAN_HYOUJI_DEV_KIND == null ? null : FIRST_JIAN_HYOUJI_DEV_KIND.trim();
    }

    /**
     * 事案操作権保持端末種別
     * @return JIAN_OPE_AUTH_DEV_KIND 事案操作権保持端末種別
     */
    public String getJIAN_OPE_AUTH_DEV_KIND() {
        return JIAN_OPE_AUTH_DEV_KIND;
    }

    /**
     * 事案操作権保持端末種別
     * @param JIAN_OPE_AUTH_DEV_KIND 事案操作権保持端末種別
     */
    public void setJIAN_OPE_AUTH_DEV_KIND(String JIAN_OPE_AUTH_DEV_KIND) {
        this.JIAN_OPE_AUTH_DEV_KIND = JIAN_OPE_AUTH_DEV_KIND == null ? null : JIAN_OPE_AUTH_DEV_KIND.trim();
    }

    /**
     * リミットタイマ延長（秒）
     * @return LIMIT_EXT_SS リミットタイマ延長（秒）
     */
    public String getLIMIT_EXT_SS() {
        return LIMIT_EXT_SS;
    }

    /**
     * リミットタイマ延長（秒）
     * @param LIMIT_EXT_SS リミットタイマ延長（秒）
     */
    public void setLIMIT_EXT_SS(String LIMIT_EXT_SS) {
        this.LIMIT_EXT_SS = LIMIT_EXT_SS == null ? null : LIMIT_EXT_SS.trim();
    }

    /**
     * リミットタイマ延長最大値(秒)
     * @return LIMIT_EXT_MAX_SS リミットタイマ延長最大値(秒)
     */
    public String getLIMIT_EXT_MAX_SS() {
        return LIMIT_EXT_MAX_SS;
    }

    /**
     * リミットタイマ延長最大値(秒)
     * @param LIMIT_EXT_MAX_SS リミットタイマ延長最大値(秒)
     */
    public void setLIMIT_EXT_MAX_SS(String LIMIT_EXT_MAX_SS) {
        this.LIMIT_EXT_MAX_SS = LIMIT_EXT_MAX_SS == null ? null : LIMIT_EXT_MAX_SS.trim();
    }

    /**
     * 最終更新日時
     * @return LASTUPD_TS 最終更新日時
     */
    public Date getLASTUPD_TS() {
        return LASTUPD_TS;
    }

    /**
     * 最終更新日時
     * @param LASTUPD_TS 最終更新日時
     */
    public void setLASTUPD_TS(Date LASTUPD_TS) {
        this.LASTUPD_TS = LASTUPD_TS;
    }

    /**
     * 真報判断実施フラグ
     * @return SINPO_JISSI_FLG 真報判断実施フラグ
     */
    public String getSINPO_JISSI_FLG() {
        return SINPO_JISSI_FLG;
    }

    /**
     * 真報判断実施フラグ
     * @param SINPO_JISSI_FLG 真報判断実施フラグ
     */
    public void setSINPO_JISSI_FLG(String SINPO_JISSI_FLG) {
        this.SINPO_JISSI_FLG = SINPO_JISSI_FLG == null ? null : SINPO_JISSI_FLG.trim();
    }

    /**
     * 事案復旧フラグ
     * @return JIAN_FUKKYU_FLG 事案復旧フラグ
     */
    public String getJIAN_FUKKYU_FLG() {
        return JIAN_FUKKYU_FLG;
    }

    /**
     * 事案復旧フラグ
     * @param JIAN_FUKKYU_FLG 事案復旧フラグ
     */
    public void setJIAN_FUKKYU_FLG(String JIAN_FUKKYU_FLG) {
        this.JIAN_FUKKYU_FLG = JIAN_FUKKYU_FLG == null ? null : JIAN_FUKKYU_FLG.trim();
    }

    /**
     * 次期警備原因ID
     * @return GENIN_ID 次期警備原因ID
     */
    public String getGENIN_ID() {
        return GENIN_ID;
    }

    /**
     * 次期警備原因ID
     * @param GENIN_ID 次期警備原因ID
     */
    public void setGENIN_ID(String GENIN_ID) {
        this.GENIN_ID = GENIN_ID == null ? null : GENIN_ID.trim();
    }

    /**
     * 真報理由フラグ
     * @return SINPO_REASON_FLG 真報理由フラグ
     */
    public String getSINPO_REASON_FLG() {
        return SINPO_REASON_FLG;
    }

    /**
     * 真報理由フラグ
     * @param SINPO_REASON_FLG 真報理由フラグ
     */
    public void setSINPO_REASON_FLG(String SINPO_REASON_FLG) {
        this.SINPO_REASON_FLG = SINPO_REASON_FLG == null ? null : SINPO_REASON_FLG.trim();
    }

    /**
     * 落着フラグ
     * @return RAKUCHAKU_FLG 落着フラグ
     */
    public String getRAKUCHAKU_FLG() {
        return RAKUCHAKU_FLG;
    }

    /**
     * 落着フラグ
     * @param RAKUCHAKU_FLG 落着フラグ
     */
    public void setRAKUCHAKU_FLG(String RAKUCHAKU_FLG) {
        this.RAKUCHAKU_FLG = RAKUCHAKU_FLG == null ? null : RAKUCHAKU_FLG.trim();
    }

    /**
     * インタホン状態
     * @return INTP_STS インタホン状態
     */
    public String getINTP_STS() {
        return INTP_STS;
    }

    /**
     * インタホン状態
     * @param INTP_STS インタホン状態
     */
    public void setINTP_STS(String INTP_STS) {
        this.INTP_STS = INTP_STS == null ? null : INTP_STS.trim();
    }

    /**
     * SGS原因コード(新画像)
     * @return SGS_GENIN_CD SGS原因コード(新画像)
     */
    public String getSGS_GENIN_CD() {
        return SGS_GENIN_CD;
    }

    /**
     * SGS原因コード(新画像)
     * @param SGS_GENIN_CD SGS原因コード(新画像)
     */
    public void setSGS_GENIN_CD(String SGS_GENIN_CD) {
        this.SGS_GENIN_CD = SGS_GENIN_CD == null ? null : SGS_GENIN_CD.trim();
    }

    /**
     * NET原因コード(新画像)
     * @return NET_GENIN_CD NET原因コード(新画像)
     */
    public String getNET_GENIN_CD() {
        return NET_GENIN_CD;
    }

    /**
     * NET原因コード(新画像)
     * @param NET_GENIN_CD NET原因コード(新画像)
     */
    public void setNET_GENIN_CD(String NET_GENIN_CD) {
        this.NET_GENIN_CD = NET_GENIN_CD == null ? null : NET_GENIN_CD.trim();
    }

    /**
     * LN_第一警報論理番号
     * @return LN_KB_INF1 LN_第一警報論理番号
     */
    public String getLN_KB_INF1() {
        return LN_KB_INF1;
    }

    /**
     * LN_第一警報論理番号
     * @param LN_KB_INF1 LN_第一警報論理番号
     */
    public void setLN_KB_INF1(String LN_KB_INF1) {
        this.LN_KB_INF1 = LN_KB_INF1 == null ? null : LN_KB_INF1.trim();
    }

    /**
     * LN_第二警報論理番号
     * @return LN_KB_INF2 LN_第二警報論理番号
     */
    public String getLN_KB_INF2() {
        return LN_KB_INF2;
    }

    /**
     * LN_第二警報論理番号
     * @param LN_KB_INF2 LN_第二警報論理番号
     */
    public void setLN_KB_INF2(String LN_KB_INF2) {
        this.LN_KB_INF2 = LN_KB_INF2 == null ? null : LN_KB_INF2.trim();
    }

    /**
     * LN_第三警報論理番号
     * @return LN_KB_INF3 LN_第三警報論理番号
     */
    public String getLN_KB_INF3() {
        return LN_KB_INF3;
    }

    /**
     * LN_第三警報論理番号
     * @param LN_KB_INF3 LN_第三警報論理番号
     */
    public void setLN_KB_INF3(String LN_KB_INF3) {
        this.LN_KB_INF3 = LN_KB_INF3 == null ? null : LN_KB_INF3.trim();
    }

    /**
     * LN_情報提供第一論理番号
     * @return LN_KB_INF_CUST1 LN_情報提供第一論理番号
     */
    public String getLN_KB_INF_CUST1() {
        return LN_KB_INF_CUST1;
    }

    /**
     * LN_情報提供第一論理番号
     * @param LN_KB_INF_CUST1 LN_情報提供第一論理番号
     */
    public void setLN_KB_INF_CUST1(String LN_KB_INF_CUST1) {
        this.LN_KB_INF_CUST1 = LN_KB_INF_CUST1 == null ? null : LN_KB_INF_CUST1.trim();
    }

    /**
     * LN_リモメン第一警報論理番号
     * @return LN_KB_INF1_RM LN_リモメン第一警報論理番号
     */
    public String getLN_KB_INF1_RM() {
        return LN_KB_INF1_RM;
    }

    /**
     * LN_リモメン第一警報論理番号
     * @param LN_KB_INF1_RM LN_リモメン第一警報論理番号
     */
    public void setLN_KB_INF1_RM(String LN_KB_INF1_RM) {
        this.LN_KB_INF1_RM = LN_KB_INF1_RM == null ? null : LN_KB_INF1_RM.trim();
    }

    /**
     * LN_リモメン第二警報論理番号
     * @return LN_KB_INF2_RM LN_リモメン第二警報論理番号
     */
    public String getLN_KB_INF2_RM() {
        return LN_KB_INF2_RM;
    }

    /**
     * LN_リモメン第二警報論理番号
     * @param LN_KB_INF2_RM LN_リモメン第二警報論理番号
     */
    public void setLN_KB_INF2_RM(String LN_KB_INF2_RM) {
        this.LN_KB_INF2_RM = LN_KB_INF2_RM == null ? null : LN_KB_INF2_RM.trim();
    }

    /**
     * LN_リモメン第三警報論理番号
     * @return LN_KB_INF3_RM LN_リモメン第三警報論理番号
     */
    public String getLN_KB_INF3_RM() {
        return LN_KB_INF3_RM;
    }

    /**
     * LN_リモメン第三警報論理番号
     * @param LN_KB_INF3_RM LN_リモメン第三警報論理番号
     */
    public void setLN_KB_INF3_RM(String LN_KB_INF3_RM) {
        this.LN_KB_INF3_RM = LN_KB_INF3_RM == null ? null : LN_KB_INF3_RM.trim();
    }

    /**
     * リモメン最新信号
     * @return LN_LAST_SIG_RM リモメン最新信号
     */
    public String getLN_LAST_SIG_RM() {
        return LN_LAST_SIG_RM;
    }

    /**
     * リモメン最新信号
     * @param LN_LAST_SIG_RM リモメン最新信号
     */
    public void setLN_LAST_SIG_RM(String LN_LAST_SIG_RM) {
        this.LN_LAST_SIG_RM = LN_LAST_SIG_RM == null ? null : LN_LAST_SIG_RM.trim();
    }

    /**
     * RM警報予告フラグ
     * @return RM_BUZZ_NOTICE_FLG RM警報予告フラグ
     */
    public String getRM_BUZZ_NOTICE_FLG() {
        return RM_BUZZ_NOTICE_FLG;
    }

    /**
     * RM警報予告フラグ
     * @param RM_BUZZ_NOTICE_FLG RM警報予告フラグ
     */
    public void setRM_BUZZ_NOTICE_FLG(String RM_BUZZ_NOTICE_FLG) {
        this.RM_BUZZ_NOTICE_FLG = RM_BUZZ_NOTICE_FLG == null ? null : RM_BUZZ_NOTICE_FLG.trim();
    }

    /**
     * RM警報送信フラグ
     * @return RM_SIG_SEND_FLG RM警報送信フラグ
     */
    public String getRM_SIG_SEND_FLG() {
        return RM_SIG_SEND_FLG;
    }

    /**
     * RM警報送信フラグ
     * @param RM_SIG_SEND_FLG RM警報送信フラグ
     */
    public void setRM_SIG_SEND_FLG(String RM_SIG_SEND_FLG) {
        this.RM_SIG_SEND_FLG = RM_SIG_SEND_FLG == null ? null : RM_SIG_SEND_FLG.trim();
    }

    /**
     * ライブビューワ起動
     * @return LIVE_VIEWER_FLG ライブビューワ起動
     */
    public String getLIVE_VIEWER_FLG() {
        return LIVE_VIEWER_FLG;
    }

    /**
     * ライブビューワ起動
     * @param LIVE_VIEWER_FLG ライブビューワ起動
     */
    public void setLIVE_VIEWER_FLG(String LIVE_VIEWER_FLG) {
        this.LIVE_VIEWER_FLG = LIVE_VIEWER_FLG == null ? null : LIVE_VIEWER_FLG.trim();
    }

    /**
     * RM表示レコード有フラグ
     * @return RM_DISP_FLG RM表示レコード有フラグ
     */
    public String getRM_DISP_FLG() {
        return RM_DISP_FLG;
    }

    /**
     * RM表示レコード有フラグ
     * @param RM_DISP_FLG RM表示レコード有フラグ
     */
    public void setRM_DISP_FLG(String RM_DISP_FLG) {
        this.RM_DISP_FLG = RM_DISP_FLG == null ? null : RM_DISP_FLG.trim();
    }

    /**
     * 真報判断起動フラグ
     * @return SINPO_KIDOU_FLG 真報判断起動フラグ
     */
    public String getSINPO_KIDOU_FLG() {
        return SINPO_KIDOU_FLG;
    }

    /**
     * 真報判断起動フラグ
     * @param SINPO_KIDOU_FLG 真報判断起動フラグ
     */
    public void setSINPO_KIDOU_FLG(String SINPO_KIDOU_FLG) {
        this.SINPO_KIDOU_FLG = SINPO_KIDOU_FLG == null ? null : SINPO_KIDOU_FLG.trim();
    }

    /**
     * 事業所_ID
     * @return JIGYOU_ID 事業所_ID
     */
    public String getJIGYOU_ID() {
        return JIGYOU_ID;
    }

    /**
     * 事業所_ID
     * @param JIGYOU_ID 事業所_ID
     */
    public void setJIGYOU_ID(String JIGYOU_ID) {
        this.JIGYOU_ID = JIGYOU_ID == null ? null : JIGYOU_ID.trim();
    }

    /**
     * オペレータ_ID
     * @return OPERATOR_ID オペレータ_ID
     */
    public String getOPERATOR_ID() {
        return OPERATOR_ID;
    }

    /**
     * オペレータ_ID
     * @param OPERATOR_ID オペレータ_ID
     */
    public void setOPERATOR_ID(String OPERATOR_ID) {
        this.OPERATOR_ID = OPERATOR_ID == null ? null : OPERATOR_ID.trim();
    }

    /**
     * LN_ファイル送信論理番号
     * @return LN_FILE_SEND LN_ファイル送信論理番号
     */
    public String getLN_FILE_SEND() {
        return LN_FILE_SEND;
    }

    /**
     * LN_ファイル送信論理番号
     * @param LN_FILE_SEND LN_ファイル送信論理番号
     */
    public void setLN_FILE_SEND(String LN_FILE_SEND) {
        this.LN_FILE_SEND = LN_FILE_SEND == null ? null : LN_FILE_SEND.trim();
    }

    /**
     * 処理通番
     * @return PROCESS_NUM 処理通番
     */
    public String getPROCESS_NUM() {
        return PROCESS_NUM;
    }

    /**
     * 処理通番
     * @param PROCESS_NUM 処理通番
     */
    public void setPROCESS_NUM(String PROCESS_NUM) {
        this.PROCESS_NUM = PROCESS_NUM == null ? null : PROCESS_NUM.trim();
    }

    /**
     * キーレス権限ステータス
     * @return KYLESS_ST キーレス権限ステータス
     */
    public String getKYLESS_ST() {
        return KYLESS_ST;
    }

    /**
     * キーレス権限ステータス
     * @param KYLESS_ST キーレス権限ステータス
     */
    public void setKYLESS_ST(String KYLESS_ST) {
        this.KYLESS_ST = KYLESS_ST == null ? null : KYLESS_ST.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}