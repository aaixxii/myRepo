package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class MFxMlKey implements Serializable {
    /**
     * 種別
     */
    private String KIND;

    /**
     * 選択言語種別
     */
    private String SELECT_LANG;

    /**
     * M_FX_ML
     */
    private static final long serialVersionUID = 1L;

    /**
     * 種別
     * @return KIND 種別
     */
    public String getKIND() {
        return KIND;
    }

    /**
     * 種別
     * @param KIND 種別
     */
    public void setKIND(String KIND) {
        this.KIND = KIND == null ? null : KIND.trim();
    }

    /**
     * 選択言語種別
     * @return SELECT_LANG 選択言語種別
     */
    public String getSELECT_LANG() {
        return SELECT_LANG;
    }

    /**
     * 選択言語種別
     * @param SELECT_LANG 選択言語種別
     */
    public void setSELECT_LANG(String SELECT_LANG) {
        this.SELECT_LANG = SELECT_LANG == null ? null : SELECT_LANG.trim();
    }
}