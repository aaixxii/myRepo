package jp.co.alsok.g6.db.entity.com;

import java.io.Serializable;
import java.util.Date;

public class KSessionInfo implements Serializable {
    /**
     * セッションID
     */
    private String SESSION_ID;

    /**
     * 登録日時
     */
    private Date CREATE_DATE;

    /**
     * 最終アクセス日時
     */
    private Date LAST_ACCESS_DATE;

    /**
     * IPアドレス
     */
    private String IP_ADDRESS;

    /**
     * 出発地点
     */
    private String DEPARTURE_POINT;

    /**
     * 到着地点
     */
    private String ARRIVAL_POINT;

    /**
     * セッションデータ
     */
    private byte[] SESSION_DATA;

    /**
     * K_SESSION_INFO
     */
    private static final long serialVersionUID = 1L;

    /**
     * セッションID
     * @return SESSION_ID セッションID
     */
    public String getSESSION_ID() {
        return SESSION_ID;
    }

    /**
     * セッションID
     * @param SESSION_ID セッションID
     */
    public void setSESSION_ID(String SESSION_ID) {
        this.SESSION_ID = SESSION_ID == null ? null : SESSION_ID.trim();
    }

    /**
     * 登録日時
     * @return CREATE_DATE 登録日時
     */
    public Date getCREATE_DATE() {
        return CREATE_DATE;
    }

    /**
     * 登録日時
     * @param CREATE_DATE 登録日時
     */
    public void setCREATE_DATE(Date CREATE_DATE) {
        this.CREATE_DATE = CREATE_DATE;
    }

    /**
     * 最終アクセス日時
     * @return LAST_ACCESS_DATE 最終アクセス日時
     */
    public Date getLAST_ACCESS_DATE() {
        return LAST_ACCESS_DATE;
    }

    /**
     * 最終アクセス日時
     * @param LAST_ACCESS_DATE 最終アクセス日時
     */
    public void setLAST_ACCESS_DATE(Date LAST_ACCESS_DATE) {
        this.LAST_ACCESS_DATE = LAST_ACCESS_DATE;
    }

    /**
     * IPアドレス
     * @return IP_ADDRESS IPアドレス
     */
    public String getIP_ADDRESS() {
        return IP_ADDRESS;
    }

    /**
     * IPアドレス
     * @param IP_ADDRESS IPアドレス
     */
    public void setIP_ADDRESS(String IP_ADDRESS) {
        this.IP_ADDRESS = IP_ADDRESS == null ? null : IP_ADDRESS.trim();
    }

    /**
     * 出発地点
     * @return DEPARTURE_POINT 出発地点
     */
    public String getDEPARTURE_POINT() {
        return DEPARTURE_POINT;
    }

    /**
     * 出発地点
     * @param DEPARTURE_POINT 出発地点
     */
    public void setDEPARTURE_POINT(String DEPARTURE_POINT) {
        this.DEPARTURE_POINT = DEPARTURE_POINT == null ? null : DEPARTURE_POINT.trim();
    }

    /**
     * 到着地点
     * @return ARRIVAL_POINT 到着地点
     */
    public String getARRIVAL_POINT() {
        return ARRIVAL_POINT;
    }

    /**
     * 到着地点
     * @param ARRIVAL_POINT 到着地点
     */
    public void setARRIVAL_POINT(String ARRIVAL_POINT) {
        this.ARRIVAL_POINT = ARRIVAL_POINT == null ? null : ARRIVAL_POINT.trim();
    }

    /**
     * セッションデータ
     * @return SESSION_DATA セッションデータ
     */
    public byte[] getSESSION_DATA() {
        return SESSION_DATA;
    }

    /**
     * セッションデータ
     * @param SESSION_DATA セッションデータ
     */
    public void setSESSION_DATA(byte[] SESSION_DATA) {
        this.SESSION_DATA = SESSION_DATA;
    }
}