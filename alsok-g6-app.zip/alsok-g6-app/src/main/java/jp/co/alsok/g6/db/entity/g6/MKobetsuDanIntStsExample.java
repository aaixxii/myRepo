package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.List;

public class MKobetsuDanIntStsExample {
    /**
     * M_KOBETSU_DAN_INT_STS
     */
    protected String orderByClause;

    /**
     * M_KOBETSU_DAN_INT_STS
     */
    protected boolean distinct;

    /**
     * M_KOBETSU_DAN_INT_STS
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public MKobetsuDanIntStsExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * M_KOBETSU_DAN_INT_STS null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andKOBETSU_DAN_INT_STSIsNull() {
            addCriterion("KOBETSU_DAN_INT_STS is null");
            return (Criteria) this;
        }

        public Criteria andKOBETSU_DAN_INT_STSIsNotNull() {
            addCriterion("KOBETSU_DAN_INT_STS is not null");
            return (Criteria) this;
        }

        public Criteria andKOBETSU_DAN_INT_STSEqualTo(String value) {
            addCriterion("KOBETSU_DAN_INT_STS =", value, "KOBETSU_DAN_INT_STS");
            return (Criteria) this;
        }

        public Criteria andKOBETSU_DAN_INT_STSNotEqualTo(String value) {
            addCriterion("KOBETSU_DAN_INT_STS <>", value, "KOBETSU_DAN_INT_STS");
            return (Criteria) this;
        }

        public Criteria andKOBETSU_DAN_INT_STSGreaterThan(String value) {
            addCriterion("KOBETSU_DAN_INT_STS >", value, "KOBETSU_DAN_INT_STS");
            return (Criteria) this;
        }

        public Criteria andKOBETSU_DAN_INT_STSGreaterThanOrEqualTo(String value) {
            addCriterion("KOBETSU_DAN_INT_STS >=", value, "KOBETSU_DAN_INT_STS");
            return (Criteria) this;
        }

        public Criteria andKOBETSU_DAN_INT_STSLessThan(String value) {
            addCriterion("KOBETSU_DAN_INT_STS <", value, "KOBETSU_DAN_INT_STS");
            return (Criteria) this;
        }

        public Criteria andKOBETSU_DAN_INT_STSLessThanOrEqualTo(String value) {
            addCriterion("KOBETSU_DAN_INT_STS <=", value, "KOBETSU_DAN_INT_STS");
            return (Criteria) this;
        }

        public Criteria andKOBETSU_DAN_INT_STSLike(String value) {
            addCriterion("KOBETSU_DAN_INT_STS like", value, "KOBETSU_DAN_INT_STS");
            return (Criteria) this;
        }

        public Criteria andKOBETSU_DAN_INT_STSNotLike(String value) {
            addCriterion("KOBETSU_DAN_INT_STS not like", value, "KOBETSU_DAN_INT_STS");
            return (Criteria) this;
        }

        public Criteria andKOBETSU_DAN_INT_STSIn(List<String> values) {
            addCriterion("KOBETSU_DAN_INT_STS in", values, "KOBETSU_DAN_INT_STS");
            return (Criteria) this;
        }

        public Criteria andKOBETSU_DAN_INT_STSNotIn(List<String> values) {
            addCriterion("KOBETSU_DAN_INT_STS not in", values, "KOBETSU_DAN_INT_STS");
            return (Criteria) this;
        }

        public Criteria andKOBETSU_DAN_INT_STSBetween(String value1, String value2) {
            addCriterion("KOBETSU_DAN_INT_STS between", value1, value2, "KOBETSU_DAN_INT_STS");
            return (Criteria) this;
        }

        public Criteria andKOBETSU_DAN_INT_STSNotBetween(String value1, String value2) {
            addCriterion("KOBETSU_DAN_INT_STS not between", value1, value2, "KOBETSU_DAN_INT_STS");
            return (Criteria) this;
        }

        public Criteria andDISP_NMIsNull() {
            addCriterion("DISP_NM is null");
            return (Criteria) this;
        }

        public Criteria andDISP_NMIsNotNull() {
            addCriterion("DISP_NM is not null");
            return (Criteria) this;
        }

        public Criteria andDISP_NMEqualTo(String value) {
            addCriterion("DISP_NM =", value, "DISP_NM");
            return (Criteria) this;
        }

        public Criteria andDISP_NMNotEqualTo(String value) {
            addCriterion("DISP_NM <>", value, "DISP_NM");
            return (Criteria) this;
        }

        public Criteria andDISP_NMGreaterThan(String value) {
            addCriterion("DISP_NM >", value, "DISP_NM");
            return (Criteria) this;
        }

        public Criteria andDISP_NMGreaterThanOrEqualTo(String value) {
            addCriterion("DISP_NM >=", value, "DISP_NM");
            return (Criteria) this;
        }

        public Criteria andDISP_NMLessThan(String value) {
            addCriterion("DISP_NM <", value, "DISP_NM");
            return (Criteria) this;
        }

        public Criteria andDISP_NMLessThanOrEqualTo(String value) {
            addCriterion("DISP_NM <=", value, "DISP_NM");
            return (Criteria) this;
        }

        public Criteria andDISP_NMLike(String value) {
            addCriterion("DISP_NM like", value, "DISP_NM");
            return (Criteria) this;
        }

        public Criteria andDISP_NMNotLike(String value) {
            addCriterion("DISP_NM not like", value, "DISP_NM");
            return (Criteria) this;
        }

        public Criteria andDISP_NMIn(List<String> values) {
            addCriterion("DISP_NM in", values, "DISP_NM");
            return (Criteria) this;
        }

        public Criteria andDISP_NMNotIn(List<String> values) {
            addCriterion("DISP_NM not in", values, "DISP_NM");
            return (Criteria) this;
        }

        public Criteria andDISP_NMBetween(String value1, String value2) {
            addCriterion("DISP_NM between", value1, value2, "DISP_NM");
            return (Criteria) this;
        }

        public Criteria andDISP_NMNotBetween(String value1, String value2) {
            addCriterion("DISP_NM not between", value1, value2, "DISP_NM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMIsNull() {
            addCriterion("ORDER_NUM is null");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMIsNotNull() {
            addCriterion("ORDER_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMEqualTo(String value) {
            addCriterion("ORDER_NUM =", value, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMNotEqualTo(String value) {
            addCriterion("ORDER_NUM <>", value, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMGreaterThan(String value) {
            addCriterion("ORDER_NUM >", value, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("ORDER_NUM >=", value, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMLessThan(String value) {
            addCriterion("ORDER_NUM <", value, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMLessThanOrEqualTo(String value) {
            addCriterion("ORDER_NUM <=", value, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMLike(String value) {
            addCriterion("ORDER_NUM like", value, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMNotLike(String value) {
            addCriterion("ORDER_NUM not like", value, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMIn(List<String> values) {
            addCriterion("ORDER_NUM in", values, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMNotIn(List<String> values) {
            addCriterion("ORDER_NUM not in", values, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMBetween(String value1, String value2) {
            addCriterion("ORDER_NUM between", value1, value2, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMNotBetween(String value1, String value2) {
            addCriterion("ORDER_NUM not between", value1, value2, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andCONN_DAN_INTIsNull() {
            addCriterion("CONN_DAN_INT is null");
            return (Criteria) this;
        }

        public Criteria andCONN_DAN_INTIsNotNull() {
            addCriterion("CONN_DAN_INT is not null");
            return (Criteria) this;
        }

        public Criteria andCONN_DAN_INTEqualTo(String value) {
            addCriterion("CONN_DAN_INT =", value, "CONN_DAN_INT");
            return (Criteria) this;
        }

        public Criteria andCONN_DAN_INTNotEqualTo(String value) {
            addCriterion("CONN_DAN_INT <>", value, "CONN_DAN_INT");
            return (Criteria) this;
        }

        public Criteria andCONN_DAN_INTGreaterThan(String value) {
            addCriterion("CONN_DAN_INT >", value, "CONN_DAN_INT");
            return (Criteria) this;
        }

        public Criteria andCONN_DAN_INTGreaterThanOrEqualTo(String value) {
            addCriterion("CONN_DAN_INT >=", value, "CONN_DAN_INT");
            return (Criteria) this;
        }

        public Criteria andCONN_DAN_INTLessThan(String value) {
            addCriterion("CONN_DAN_INT <", value, "CONN_DAN_INT");
            return (Criteria) this;
        }

        public Criteria andCONN_DAN_INTLessThanOrEqualTo(String value) {
            addCriterion("CONN_DAN_INT <=", value, "CONN_DAN_INT");
            return (Criteria) this;
        }

        public Criteria andCONN_DAN_INTLike(String value) {
            addCriterion("CONN_DAN_INT like", value, "CONN_DAN_INT");
            return (Criteria) this;
        }

        public Criteria andCONN_DAN_INTNotLike(String value) {
            addCriterion("CONN_DAN_INT not like", value, "CONN_DAN_INT");
            return (Criteria) this;
        }

        public Criteria andCONN_DAN_INTIn(List<String> values) {
            addCriterion("CONN_DAN_INT in", values, "CONN_DAN_INT");
            return (Criteria) this;
        }

        public Criteria andCONN_DAN_INTNotIn(List<String> values) {
            addCriterion("CONN_DAN_INT not in", values, "CONN_DAN_INT");
            return (Criteria) this;
        }

        public Criteria andCONN_DAN_INTBetween(String value1, String value2) {
            addCriterion("CONN_DAN_INT between", value1, value2, "CONN_DAN_INT");
            return (Criteria) this;
        }

        public Criteria andCONN_DAN_INTNotBetween(String value1, String value2) {
            addCriterion("CONN_DAN_INT not between", value1, value2, "CONN_DAN_INT");
            return (Criteria) this;
        }

        public Criteria andDCONN_DAN_INTIsNull() {
            addCriterion("DCONN_DAN_INT is null");
            return (Criteria) this;
        }

        public Criteria andDCONN_DAN_INTIsNotNull() {
            addCriterion("DCONN_DAN_INT is not null");
            return (Criteria) this;
        }

        public Criteria andDCONN_DAN_INTEqualTo(String value) {
            addCriterion("DCONN_DAN_INT =", value, "DCONN_DAN_INT");
            return (Criteria) this;
        }

        public Criteria andDCONN_DAN_INTNotEqualTo(String value) {
            addCriterion("DCONN_DAN_INT <>", value, "DCONN_DAN_INT");
            return (Criteria) this;
        }

        public Criteria andDCONN_DAN_INTGreaterThan(String value) {
            addCriterion("DCONN_DAN_INT >", value, "DCONN_DAN_INT");
            return (Criteria) this;
        }

        public Criteria andDCONN_DAN_INTGreaterThanOrEqualTo(String value) {
            addCriterion("DCONN_DAN_INT >=", value, "DCONN_DAN_INT");
            return (Criteria) this;
        }

        public Criteria andDCONN_DAN_INTLessThan(String value) {
            addCriterion("DCONN_DAN_INT <", value, "DCONN_DAN_INT");
            return (Criteria) this;
        }

        public Criteria andDCONN_DAN_INTLessThanOrEqualTo(String value) {
            addCriterion("DCONN_DAN_INT <=", value, "DCONN_DAN_INT");
            return (Criteria) this;
        }

        public Criteria andDCONN_DAN_INTLike(String value) {
            addCriterion("DCONN_DAN_INT like", value, "DCONN_DAN_INT");
            return (Criteria) this;
        }

        public Criteria andDCONN_DAN_INTNotLike(String value) {
            addCriterion("DCONN_DAN_INT not like", value, "DCONN_DAN_INT");
            return (Criteria) this;
        }

        public Criteria andDCONN_DAN_INTIn(List<String> values) {
            addCriterion("DCONN_DAN_INT in", values, "DCONN_DAN_INT");
            return (Criteria) this;
        }

        public Criteria andDCONN_DAN_INTNotIn(List<String> values) {
            addCriterion("DCONN_DAN_INT not in", values, "DCONN_DAN_INT");
            return (Criteria) this;
        }

        public Criteria andDCONN_DAN_INTBetween(String value1, String value2) {
            addCriterion("DCONN_DAN_INT between", value1, value2, "DCONN_DAN_INT");
            return (Criteria) this;
        }

        public Criteria andDCONN_DAN_INTNotBetween(String value1, String value2) {
            addCriterion("DCONN_DAN_INT not between", value1, value2, "DCONN_DAN_INT");
            return (Criteria) this;
        }

        public Criteria andDAN_CHK_STS_FLGIsNull() {
            addCriterion("DAN_CHK_STS_FLG is null");
            return (Criteria) this;
        }

        public Criteria andDAN_CHK_STS_FLGIsNotNull() {
            addCriterion("DAN_CHK_STS_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andDAN_CHK_STS_FLGEqualTo(String value) {
            addCriterion("DAN_CHK_STS_FLG =", value, "DAN_CHK_STS_FLG");
            return (Criteria) this;
        }

        public Criteria andDAN_CHK_STS_FLGNotEqualTo(String value) {
            addCriterion("DAN_CHK_STS_FLG <>", value, "DAN_CHK_STS_FLG");
            return (Criteria) this;
        }

        public Criteria andDAN_CHK_STS_FLGGreaterThan(String value) {
            addCriterion("DAN_CHK_STS_FLG >", value, "DAN_CHK_STS_FLG");
            return (Criteria) this;
        }

        public Criteria andDAN_CHK_STS_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("DAN_CHK_STS_FLG >=", value, "DAN_CHK_STS_FLG");
            return (Criteria) this;
        }

        public Criteria andDAN_CHK_STS_FLGLessThan(String value) {
            addCriterion("DAN_CHK_STS_FLG <", value, "DAN_CHK_STS_FLG");
            return (Criteria) this;
        }

        public Criteria andDAN_CHK_STS_FLGLessThanOrEqualTo(String value) {
            addCriterion("DAN_CHK_STS_FLG <=", value, "DAN_CHK_STS_FLG");
            return (Criteria) this;
        }

        public Criteria andDAN_CHK_STS_FLGLike(String value) {
            addCriterion("DAN_CHK_STS_FLG like", value, "DAN_CHK_STS_FLG");
            return (Criteria) this;
        }

        public Criteria andDAN_CHK_STS_FLGNotLike(String value) {
            addCriterion("DAN_CHK_STS_FLG not like", value, "DAN_CHK_STS_FLG");
            return (Criteria) this;
        }

        public Criteria andDAN_CHK_STS_FLGIn(List<String> values) {
            addCriterion("DAN_CHK_STS_FLG in", values, "DAN_CHK_STS_FLG");
            return (Criteria) this;
        }

        public Criteria andDAN_CHK_STS_FLGNotIn(List<String> values) {
            addCriterion("DAN_CHK_STS_FLG not in", values, "DAN_CHK_STS_FLG");
            return (Criteria) this;
        }

        public Criteria andDAN_CHK_STS_FLGBetween(String value1, String value2) {
            addCriterion("DAN_CHK_STS_FLG between", value1, value2, "DAN_CHK_STS_FLG");
            return (Criteria) this;
        }

        public Criteria andDAN_CHK_STS_FLGNotBetween(String value1, String value2) {
            addCriterion("DAN_CHK_STS_FLG not between", value1, value2, "DAN_CHK_STS_FLG");
            return (Criteria) this;
        }

        public Criteria andIP_FLGIsNull() {
            addCriterion("IP_FLG is null");
            return (Criteria) this;
        }

        public Criteria andIP_FLGIsNotNull() {
            addCriterion("IP_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andIP_FLGEqualTo(String value) {
            addCriterion("IP_FLG =", value, "IP_FLG");
            return (Criteria) this;
        }

        public Criteria andIP_FLGNotEqualTo(String value) {
            addCriterion("IP_FLG <>", value, "IP_FLG");
            return (Criteria) this;
        }

        public Criteria andIP_FLGGreaterThan(String value) {
            addCriterion("IP_FLG >", value, "IP_FLG");
            return (Criteria) this;
        }

        public Criteria andIP_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("IP_FLG >=", value, "IP_FLG");
            return (Criteria) this;
        }

        public Criteria andIP_FLGLessThan(String value) {
            addCriterion("IP_FLG <", value, "IP_FLG");
            return (Criteria) this;
        }

        public Criteria andIP_FLGLessThanOrEqualTo(String value) {
            addCriterion("IP_FLG <=", value, "IP_FLG");
            return (Criteria) this;
        }

        public Criteria andIP_FLGLike(String value) {
            addCriterion("IP_FLG like", value, "IP_FLG");
            return (Criteria) this;
        }

        public Criteria andIP_FLGNotLike(String value) {
            addCriterion("IP_FLG not like", value, "IP_FLG");
            return (Criteria) this;
        }

        public Criteria andIP_FLGIn(List<String> values) {
            addCriterion("IP_FLG in", values, "IP_FLG");
            return (Criteria) this;
        }

        public Criteria andIP_FLGNotIn(List<String> values) {
            addCriterion("IP_FLG not in", values, "IP_FLG");
            return (Criteria) this;
        }

        public Criteria andIP_FLGBetween(String value1, String value2) {
            addCriterion("IP_FLG between", value1, value2, "IP_FLG");
            return (Criteria) this;
        }

        public Criteria andIP_FLGNotBetween(String value1, String value2) {
            addCriterion("IP_FLG not between", value1, value2, "IP_FLG");
            return (Criteria) this;
        }

        public Criteria andWL_FLGIsNull() {
            addCriterion("WL_FLG is null");
            return (Criteria) this;
        }

        public Criteria andWL_FLGIsNotNull() {
            addCriterion("WL_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andWL_FLGEqualTo(String value) {
            addCriterion("WL_FLG =", value, "WL_FLG");
            return (Criteria) this;
        }

        public Criteria andWL_FLGNotEqualTo(String value) {
            addCriterion("WL_FLG <>", value, "WL_FLG");
            return (Criteria) this;
        }

        public Criteria andWL_FLGGreaterThan(String value) {
            addCriterion("WL_FLG >", value, "WL_FLG");
            return (Criteria) this;
        }

        public Criteria andWL_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("WL_FLG >=", value, "WL_FLG");
            return (Criteria) this;
        }

        public Criteria andWL_FLGLessThan(String value) {
            addCriterion("WL_FLG <", value, "WL_FLG");
            return (Criteria) this;
        }

        public Criteria andWL_FLGLessThanOrEqualTo(String value) {
            addCriterion("WL_FLG <=", value, "WL_FLG");
            return (Criteria) this;
        }

        public Criteria andWL_FLGLike(String value) {
            addCriterion("WL_FLG like", value, "WL_FLG");
            return (Criteria) this;
        }

        public Criteria andWL_FLGNotLike(String value) {
            addCriterion("WL_FLG not like", value, "WL_FLG");
            return (Criteria) this;
        }

        public Criteria andWL_FLGIn(List<String> values) {
            addCriterion("WL_FLG in", values, "WL_FLG");
            return (Criteria) this;
        }

        public Criteria andWL_FLGNotIn(List<String> values) {
            addCriterion("WL_FLG not in", values, "WL_FLG");
            return (Criteria) this;
        }

        public Criteria andWL_FLGBetween(String value1, String value2) {
            addCriterion("WL_FLG between", value1, value2, "WL_FLG");
            return (Criteria) this;
        }

        public Criteria andWL_FLGNotBetween(String value1, String value2) {
            addCriterion("WL_FLG not between", value1, value2, "WL_FLG");
            return (Criteria) this;
        }

        public Criteria andANALOG_FLGIsNull() {
            addCriterion("ANALOG_FLG is null");
            return (Criteria) this;
        }

        public Criteria andANALOG_FLGIsNotNull() {
            addCriterion("ANALOG_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andANALOG_FLGEqualTo(String value) {
            addCriterion("ANALOG_FLG =", value, "ANALOG_FLG");
            return (Criteria) this;
        }

        public Criteria andANALOG_FLGNotEqualTo(String value) {
            addCriterion("ANALOG_FLG <>", value, "ANALOG_FLG");
            return (Criteria) this;
        }

        public Criteria andANALOG_FLGGreaterThan(String value) {
            addCriterion("ANALOG_FLG >", value, "ANALOG_FLG");
            return (Criteria) this;
        }

        public Criteria andANALOG_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("ANALOG_FLG >=", value, "ANALOG_FLG");
            return (Criteria) this;
        }

        public Criteria andANALOG_FLGLessThan(String value) {
            addCriterion("ANALOG_FLG <", value, "ANALOG_FLG");
            return (Criteria) this;
        }

        public Criteria andANALOG_FLGLessThanOrEqualTo(String value) {
            addCriterion("ANALOG_FLG <=", value, "ANALOG_FLG");
            return (Criteria) this;
        }

        public Criteria andANALOG_FLGLike(String value) {
            addCriterion("ANALOG_FLG like", value, "ANALOG_FLG");
            return (Criteria) this;
        }

        public Criteria andANALOG_FLGNotLike(String value) {
            addCriterion("ANALOG_FLG not like", value, "ANALOG_FLG");
            return (Criteria) this;
        }

        public Criteria andANALOG_FLGIn(List<String> values) {
            addCriterion("ANALOG_FLG in", values, "ANALOG_FLG");
            return (Criteria) this;
        }

        public Criteria andANALOG_FLGNotIn(List<String> values) {
            addCriterion("ANALOG_FLG not in", values, "ANALOG_FLG");
            return (Criteria) this;
        }

        public Criteria andANALOG_FLGBetween(String value1, String value2) {
            addCriterion("ANALOG_FLG between", value1, value2, "ANALOG_FLG");
            return (Criteria) this;
        }

        public Criteria andANALOG_FLGNotBetween(String value1, String value2) {
            addCriterion("ANALOG_FLG not between", value1, value2, "ANALOG_FLG");
            return (Criteria) this;
        }

        public Criteria andKOBETSU_DAN_INT_STSLikeInsensitive(String value) {
            addCriterion("upper(KOBETSU_DAN_INT_STS) like", value.toUpperCase(), "KOBETSU_DAN_INT_STS");
            return (Criteria) this;
        }

        public Criteria andDISP_NMLikeInsensitive(String value) {
            addCriterion("upper(DISP_NM) like", value.toUpperCase(), "DISP_NM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMLikeInsensitive(String value) {
            addCriterion("upper(ORDER_NUM) like", value.toUpperCase(), "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andCONN_DAN_INTLikeInsensitive(String value) {
            addCriterion("upper(CONN_DAN_INT) like", value.toUpperCase(), "CONN_DAN_INT");
            return (Criteria) this;
        }

        public Criteria andDCONN_DAN_INTLikeInsensitive(String value) {
            addCriterion("upper(DCONN_DAN_INT) like", value.toUpperCase(), "DCONN_DAN_INT");
            return (Criteria) this;
        }

        public Criteria andDAN_CHK_STS_FLGLikeInsensitive(String value) {
            addCriterion("upper(DAN_CHK_STS_FLG) like", value.toUpperCase(), "DAN_CHK_STS_FLG");
            return (Criteria) this;
        }

        public Criteria andIP_FLGLikeInsensitive(String value) {
            addCriterion("upper(IP_FLG) like", value.toUpperCase(), "IP_FLG");
            return (Criteria) this;
        }

        public Criteria andWL_FLGLikeInsensitive(String value) {
            addCriterion("upper(WL_FLG) like", value.toUpperCase(), "WL_FLG");
            return (Criteria) this;
        }

        public Criteria andANALOG_FLGLikeInsensitive(String value) {
            addCriterion("upper(ANALOG_FLG) like", value.toUpperCase(), "ANALOG_FLG");
            return (Criteria) this;
        }
    }

    /**
     * M_KOBETSU_DAN_INT_STS
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * M_KOBETSU_DAN_INT_STS null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}