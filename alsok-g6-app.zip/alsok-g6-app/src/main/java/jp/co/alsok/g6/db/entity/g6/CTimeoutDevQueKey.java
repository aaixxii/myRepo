package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class CTimeoutDevQueKey implements Serializable {
    /**
     * LN_タイムアウト制御キュー論理番号
     */
    private String LN_TIMEOUT_DEV_QUE;

    /**
     * LN_タイムアウト管理マスター論理番号
     */
    private String LN_TIMEOUT_MNG;

    /**
     * C_TIMEOUT_DEV_QUE
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_タイムアウト制御キュー論理番号
     * @return LN_TIMEOUT_DEV_QUE LN_タイムアウト制御キュー論理番号
     */
    public String getLN_TIMEOUT_DEV_QUE() {
        return LN_TIMEOUT_DEV_QUE;
    }

    /**
     * LN_タイムアウト制御キュー論理番号
     * @param LN_TIMEOUT_DEV_QUE LN_タイムアウト制御キュー論理番号
     */
    public void setLN_TIMEOUT_DEV_QUE(String LN_TIMEOUT_DEV_QUE) {
        this.LN_TIMEOUT_DEV_QUE = LN_TIMEOUT_DEV_QUE == null ? null : LN_TIMEOUT_DEV_QUE.trim();
    }

    /**
     * LN_タイムアウト管理マスター論理番号
     * @return LN_TIMEOUT_MNG LN_タイムアウト管理マスター論理番号
     */
    public String getLN_TIMEOUT_MNG() {
        return LN_TIMEOUT_MNG;
    }

    /**
     * LN_タイムアウト管理マスター論理番号
     * @param LN_TIMEOUT_MNG LN_タイムアウト管理マスター論理番号
     */
    public void setLN_TIMEOUT_MNG(String LN_TIMEOUT_MNG) {
        this.LN_TIMEOUT_MNG = LN_TIMEOUT_MNG == null ? null : LN_TIMEOUT_MNG.trim();
    }
}