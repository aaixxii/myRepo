package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

@SuppressWarnings("serial")
public class MHelpMessage implements Serializable {
    /**
     * メッセージID
     */
    private String MESSAGE_ID;

    /**
     * サイト区分
     */
    private String SITE_KBN;

    /**
     * 内容_日本語
     */
    private String MSG_NAIYOU_JP;

    /**
     * 内容_英語
     */
    private String MSG_NAIYOU_EN;

    /**
     * 内容_中国語
     */
    private String MSG_NAIYOU_ZH;

    /**
     * 備考
     */
    private String BIKOU;

	public String getMESSAGE_ID() {
		return MESSAGE_ID;
	}

	public void setMESSAGE_ID(String mESSAGE_ID) {
		MESSAGE_ID = mESSAGE_ID;
	}

	public String getSITE_KBN() {
		return SITE_KBN;
	}

	public void setSITE_KBN(String sITE_KBN) {
		SITE_KBN = sITE_KBN;
	}

	public String getMSG_NAIYOU_JP() {
		return MSG_NAIYOU_JP;
	}

	public void setMSG_NAIYOU_JP(String mSG_NAIYOU_JP) {
		MSG_NAIYOU_JP = mSG_NAIYOU_JP;
	}

	public String getMSG_NAIYOU_EN() {
		return MSG_NAIYOU_EN;
	}

	public void setMSG_NAIYOU_EN(String mSG_NAIYOU_EN) {
		MSG_NAIYOU_EN = mSG_NAIYOU_EN;
	}

	public String getMSG_NAIYOU_ZH() {
		return MSG_NAIYOU_ZH;
	}

	public void setMSG_NAIYOU_ZH(String mSG_NAIYOU_ZH) {
		MSG_NAIYOU_ZH = mSG_NAIYOU_ZH;
	}

	public String getBIKOU() {
		return BIKOU;
	}

	public void setBIKOU(String bIKOU) {
		BIKOU = bIKOU;
	}

}