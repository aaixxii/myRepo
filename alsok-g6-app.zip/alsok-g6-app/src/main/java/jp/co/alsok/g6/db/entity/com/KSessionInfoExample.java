package jp.co.alsok.g6.db.entity.com;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class KSessionInfoExample {
    /**
     * K_SESSION_INFO
     */
    protected String orderByClause;

    /**
     * K_SESSION_INFO
     */
    protected boolean distinct;

    /**
     * K_SESSION_INFO
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public KSessionInfoExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * K_SESSION_INFO null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andSESSION_IDIsNull() {
            addCriterion("SESSION_ID is null");
            return (Criteria) this;
        }

        public Criteria andSESSION_IDIsNotNull() {
            addCriterion("SESSION_ID is not null");
            return (Criteria) this;
        }

        public Criteria andSESSION_IDEqualTo(String value) {
            addCriterion("SESSION_ID =", value, "SESSION_ID");
            return (Criteria) this;
        }

        public Criteria andSESSION_IDNotEqualTo(String value) {
            addCriterion("SESSION_ID <>", value, "SESSION_ID");
            return (Criteria) this;
        }

        public Criteria andSESSION_IDGreaterThan(String value) {
            addCriterion("SESSION_ID >", value, "SESSION_ID");
            return (Criteria) this;
        }

        public Criteria andSESSION_IDGreaterThanOrEqualTo(String value) {
            addCriterion("SESSION_ID >=", value, "SESSION_ID");
            return (Criteria) this;
        }

        public Criteria andSESSION_IDLessThan(String value) {
            addCriterion("SESSION_ID <", value, "SESSION_ID");
            return (Criteria) this;
        }

        public Criteria andSESSION_IDLessThanOrEqualTo(String value) {
            addCriterion("SESSION_ID <=", value, "SESSION_ID");
            return (Criteria) this;
        }

        public Criteria andSESSION_IDLike(String value) {
            addCriterion("SESSION_ID like", value, "SESSION_ID");
            return (Criteria) this;
        }

        public Criteria andSESSION_IDNotLike(String value) {
            addCriterion("SESSION_ID not like", value, "SESSION_ID");
            return (Criteria) this;
        }

        public Criteria andSESSION_IDIn(List<String> values) {
            addCriterion("SESSION_ID in", values, "SESSION_ID");
            return (Criteria) this;
        }

        public Criteria andSESSION_IDNotIn(List<String> values) {
            addCriterion("SESSION_ID not in", values, "SESSION_ID");
            return (Criteria) this;
        }

        public Criteria andSESSION_IDBetween(String value1, String value2) {
            addCriterion("SESSION_ID between", value1, value2, "SESSION_ID");
            return (Criteria) this;
        }

        public Criteria andSESSION_IDNotBetween(String value1, String value2) {
            addCriterion("SESSION_ID not between", value1, value2, "SESSION_ID");
            return (Criteria) this;
        }

        public Criteria andCREATE_DATEIsNull() {
            addCriterion("CREATE_DATE is null");
            return (Criteria) this;
        }

        public Criteria andCREATE_DATEIsNotNull() {
            addCriterion("CREATE_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andCREATE_DATEEqualTo(Date value) {
            addCriterion("CREATE_DATE =", value, "CREATE_DATE");
            return (Criteria) this;
        }

        public Criteria andCREATE_DATENotEqualTo(Date value) {
            addCriterion("CREATE_DATE <>", value, "CREATE_DATE");
            return (Criteria) this;
        }

        public Criteria andCREATE_DATEGreaterThan(Date value) {
            addCriterion("CREATE_DATE >", value, "CREATE_DATE");
            return (Criteria) this;
        }

        public Criteria andCREATE_DATEGreaterThanOrEqualTo(Date value) {
            addCriterion("CREATE_DATE >=", value, "CREATE_DATE");
            return (Criteria) this;
        }

        public Criteria andCREATE_DATELessThan(Date value) {
            addCriterion("CREATE_DATE <", value, "CREATE_DATE");
            return (Criteria) this;
        }

        public Criteria andCREATE_DATELessThanOrEqualTo(Date value) {
            addCriterion("CREATE_DATE <=", value, "CREATE_DATE");
            return (Criteria) this;
        }

        public Criteria andCREATE_DATEIn(List<Date> values) {
            addCriterion("CREATE_DATE in", values, "CREATE_DATE");
            return (Criteria) this;
        }

        public Criteria andCREATE_DATENotIn(List<Date> values) {
            addCriterion("CREATE_DATE not in", values, "CREATE_DATE");
            return (Criteria) this;
        }

        public Criteria andCREATE_DATEBetween(Date value1, Date value2) {
            addCriterion("CREATE_DATE between", value1, value2, "CREATE_DATE");
            return (Criteria) this;
        }

        public Criteria andCREATE_DATENotBetween(Date value1, Date value2) {
            addCriterion("CREATE_DATE not between", value1, value2, "CREATE_DATE");
            return (Criteria) this;
        }

        public Criteria andLAST_ACCESS_DATEIsNull() {
            addCriterion("LAST_ACCESS_DATE is null");
            return (Criteria) this;
        }

        public Criteria andLAST_ACCESS_DATEIsNotNull() {
            addCriterion("LAST_ACCESS_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andLAST_ACCESS_DATEEqualTo(Date value) {
            addCriterion("LAST_ACCESS_DATE =", value, "LAST_ACCESS_DATE");
            return (Criteria) this;
        }

        public Criteria andLAST_ACCESS_DATENotEqualTo(Date value) {
            addCriterion("LAST_ACCESS_DATE <>", value, "LAST_ACCESS_DATE");
            return (Criteria) this;
        }

        public Criteria andLAST_ACCESS_DATEGreaterThan(Date value) {
            addCriterion("LAST_ACCESS_DATE >", value, "LAST_ACCESS_DATE");
            return (Criteria) this;
        }

        public Criteria andLAST_ACCESS_DATEGreaterThanOrEqualTo(Date value) {
            addCriterion("LAST_ACCESS_DATE >=", value, "LAST_ACCESS_DATE");
            return (Criteria) this;
        }

        public Criteria andLAST_ACCESS_DATELessThan(Date value) {
            addCriterion("LAST_ACCESS_DATE <", value, "LAST_ACCESS_DATE");
            return (Criteria) this;
        }

        public Criteria andLAST_ACCESS_DATELessThanOrEqualTo(Date value) {
            addCriterion("LAST_ACCESS_DATE <=", value, "LAST_ACCESS_DATE");
            return (Criteria) this;
        }

        public Criteria andLAST_ACCESS_DATEIn(List<Date> values) {
            addCriterion("LAST_ACCESS_DATE in", values, "LAST_ACCESS_DATE");
            return (Criteria) this;
        }

        public Criteria andLAST_ACCESS_DATENotIn(List<Date> values) {
            addCriterion("LAST_ACCESS_DATE not in", values, "LAST_ACCESS_DATE");
            return (Criteria) this;
        }

        public Criteria andLAST_ACCESS_DATEBetween(Date value1, Date value2) {
            addCriterion("LAST_ACCESS_DATE between", value1, value2, "LAST_ACCESS_DATE");
            return (Criteria) this;
        }

        public Criteria andLAST_ACCESS_DATENotBetween(Date value1, Date value2) {
            addCriterion("LAST_ACCESS_DATE not between", value1, value2, "LAST_ACCESS_DATE");
            return (Criteria) this;
        }

        public Criteria andIP_ADDRESSIsNull() {
            addCriterion("IP_ADDRESS is null");
            return (Criteria) this;
        }

        public Criteria andIP_ADDRESSIsNotNull() {
            addCriterion("IP_ADDRESS is not null");
            return (Criteria) this;
        }

        public Criteria andIP_ADDRESSEqualTo(String value) {
            addCriterion("IP_ADDRESS =", value, "IP_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andIP_ADDRESSNotEqualTo(String value) {
            addCriterion("IP_ADDRESS <>", value, "IP_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andIP_ADDRESSGreaterThan(String value) {
            addCriterion("IP_ADDRESS >", value, "IP_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andIP_ADDRESSGreaterThanOrEqualTo(String value) {
            addCriterion("IP_ADDRESS >=", value, "IP_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andIP_ADDRESSLessThan(String value) {
            addCriterion("IP_ADDRESS <", value, "IP_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andIP_ADDRESSLessThanOrEqualTo(String value) {
            addCriterion("IP_ADDRESS <=", value, "IP_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andIP_ADDRESSLike(String value) {
            addCriterion("IP_ADDRESS like", value, "IP_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andIP_ADDRESSNotLike(String value) {
            addCriterion("IP_ADDRESS not like", value, "IP_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andIP_ADDRESSIn(List<String> values) {
            addCriterion("IP_ADDRESS in", values, "IP_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andIP_ADDRESSNotIn(List<String> values) {
            addCriterion("IP_ADDRESS not in", values, "IP_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andIP_ADDRESSBetween(String value1, String value2) {
            addCriterion("IP_ADDRESS between", value1, value2, "IP_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andIP_ADDRESSNotBetween(String value1, String value2) {
            addCriterion("IP_ADDRESS not between", value1, value2, "IP_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andDEPARTURE_POINTIsNull() {
            addCriterion("DEPARTURE_POINT is null");
            return (Criteria) this;
        }

        public Criteria andDEPARTURE_POINTIsNotNull() {
            addCriterion("DEPARTURE_POINT is not null");
            return (Criteria) this;
        }

        public Criteria andDEPARTURE_POINTEqualTo(String value) {
            addCriterion("DEPARTURE_POINT =", value, "DEPARTURE_POINT");
            return (Criteria) this;
        }

        public Criteria andDEPARTURE_POINTNotEqualTo(String value) {
            addCriterion("DEPARTURE_POINT <>", value, "DEPARTURE_POINT");
            return (Criteria) this;
        }

        public Criteria andDEPARTURE_POINTGreaterThan(String value) {
            addCriterion("DEPARTURE_POINT >", value, "DEPARTURE_POINT");
            return (Criteria) this;
        }

        public Criteria andDEPARTURE_POINTGreaterThanOrEqualTo(String value) {
            addCriterion("DEPARTURE_POINT >=", value, "DEPARTURE_POINT");
            return (Criteria) this;
        }

        public Criteria andDEPARTURE_POINTLessThan(String value) {
            addCriterion("DEPARTURE_POINT <", value, "DEPARTURE_POINT");
            return (Criteria) this;
        }

        public Criteria andDEPARTURE_POINTLessThanOrEqualTo(String value) {
            addCriterion("DEPARTURE_POINT <=", value, "DEPARTURE_POINT");
            return (Criteria) this;
        }

        public Criteria andDEPARTURE_POINTLike(String value) {
            addCriterion("DEPARTURE_POINT like", value, "DEPARTURE_POINT");
            return (Criteria) this;
        }

        public Criteria andDEPARTURE_POINTNotLike(String value) {
            addCriterion("DEPARTURE_POINT not like", value, "DEPARTURE_POINT");
            return (Criteria) this;
        }

        public Criteria andDEPARTURE_POINTIn(List<String> values) {
            addCriterion("DEPARTURE_POINT in", values, "DEPARTURE_POINT");
            return (Criteria) this;
        }

        public Criteria andDEPARTURE_POINTNotIn(List<String> values) {
            addCriterion("DEPARTURE_POINT not in", values, "DEPARTURE_POINT");
            return (Criteria) this;
        }

        public Criteria andDEPARTURE_POINTBetween(String value1, String value2) {
            addCriterion("DEPARTURE_POINT between", value1, value2, "DEPARTURE_POINT");
            return (Criteria) this;
        }

        public Criteria andDEPARTURE_POINTNotBetween(String value1, String value2) {
            addCriterion("DEPARTURE_POINT not between", value1, value2, "DEPARTURE_POINT");
            return (Criteria) this;
        }

        public Criteria andARRIVAL_POINTIsNull() {
            addCriterion("ARRIVAL_POINT is null");
            return (Criteria) this;
        }

        public Criteria andARRIVAL_POINTIsNotNull() {
            addCriterion("ARRIVAL_POINT is not null");
            return (Criteria) this;
        }

        public Criteria andARRIVAL_POINTEqualTo(String value) {
            addCriterion("ARRIVAL_POINT =", value, "ARRIVAL_POINT");
            return (Criteria) this;
        }

        public Criteria andARRIVAL_POINTNotEqualTo(String value) {
            addCriterion("ARRIVAL_POINT <>", value, "ARRIVAL_POINT");
            return (Criteria) this;
        }

        public Criteria andARRIVAL_POINTGreaterThan(String value) {
            addCriterion("ARRIVAL_POINT >", value, "ARRIVAL_POINT");
            return (Criteria) this;
        }

        public Criteria andARRIVAL_POINTGreaterThanOrEqualTo(String value) {
            addCriterion("ARRIVAL_POINT >=", value, "ARRIVAL_POINT");
            return (Criteria) this;
        }

        public Criteria andARRIVAL_POINTLessThan(String value) {
            addCriterion("ARRIVAL_POINT <", value, "ARRIVAL_POINT");
            return (Criteria) this;
        }

        public Criteria andARRIVAL_POINTLessThanOrEqualTo(String value) {
            addCriterion("ARRIVAL_POINT <=", value, "ARRIVAL_POINT");
            return (Criteria) this;
        }

        public Criteria andARRIVAL_POINTLike(String value) {
            addCriterion("ARRIVAL_POINT like", value, "ARRIVAL_POINT");
            return (Criteria) this;
        }

        public Criteria andARRIVAL_POINTNotLike(String value) {
            addCriterion("ARRIVAL_POINT not like", value, "ARRIVAL_POINT");
            return (Criteria) this;
        }

        public Criteria andARRIVAL_POINTIn(List<String> values) {
            addCriterion("ARRIVAL_POINT in", values, "ARRIVAL_POINT");
            return (Criteria) this;
        }

        public Criteria andARRIVAL_POINTNotIn(List<String> values) {
            addCriterion("ARRIVAL_POINT not in", values, "ARRIVAL_POINT");
            return (Criteria) this;
        }

        public Criteria andARRIVAL_POINTBetween(String value1, String value2) {
            addCriterion("ARRIVAL_POINT between", value1, value2, "ARRIVAL_POINT");
            return (Criteria) this;
        }

        public Criteria andARRIVAL_POINTNotBetween(String value1, String value2) {
            addCriterion("ARRIVAL_POINT not between", value1, value2, "ARRIVAL_POINT");
            return (Criteria) this;
        }

        public Criteria andSESSION_IDLikeInsensitive(String value) {
            addCriterion("upper(SESSION_ID) like", value.toUpperCase(), "SESSION_ID");
            return (Criteria) this;
        }

        public Criteria andIP_ADDRESSLikeInsensitive(String value) {
            addCriterion("upper(IP_ADDRESS) like", value.toUpperCase(), "IP_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andDEPARTURE_POINTLikeInsensitive(String value) {
            addCriterion("upper(DEPARTURE_POINT) like", value.toUpperCase(), "DEPARTURE_POINT");
            return (Criteria) this;
        }

        public Criteria andARRIVAL_POINTLikeInsensitive(String value) {
            addCriterion("upper(ARRIVAL_POINT) like", value.toUpperCase(), "ARRIVAL_POINT");
            return (Criteria) this;
        }
    }

    /**
     * K_SESSION_INFO
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * K_SESSION_INFO null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}