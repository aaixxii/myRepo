package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class AUserRole implements Serializable {
    /**
     * LN_利用者ロール論理番号
     */
    private String LN_USER_ROLE;

    /**
     * 利用者ロール名
     */
    private String USER_ROLE_NM;

    /**
     * 変更可否フラグ
     */
    private String CHG_FLG;

    /**
     * パス情報
     */
    private String PATH_INF;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * A_USER_ROLE
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_利用者ロール論理番号
     * @return LN_USER_ROLE LN_利用者ロール論理番号
     */
    public String getLN_USER_ROLE() {
        return LN_USER_ROLE;
    }

    /**
     * LN_利用者ロール論理番号
     * @param LN_USER_ROLE LN_利用者ロール論理番号
     */
    public void setLN_USER_ROLE(String LN_USER_ROLE) {
        this.LN_USER_ROLE = LN_USER_ROLE == null ? null : LN_USER_ROLE.trim();
    }

    /**
     * 利用者ロール名
     * @return USER_ROLE_NM 利用者ロール名
     */
    public String getUSER_ROLE_NM() {
        return USER_ROLE_NM;
    }

    /**
     * 利用者ロール名
     * @param USER_ROLE_NM 利用者ロール名
     */
    public void setUSER_ROLE_NM(String USER_ROLE_NM) {
        this.USER_ROLE_NM = USER_ROLE_NM == null ? null : USER_ROLE_NM.trim();
    }

    /**
     * 変更可否フラグ
     * @return CHG_FLG 変更可否フラグ
     */
    public String getCHG_FLG() {
        return CHG_FLG;
    }

    /**
     * 変更可否フラグ
     * @param CHG_FLG 変更可否フラグ
     */
    public void setCHG_FLG(String CHG_FLG) {
        this.CHG_FLG = CHG_FLG == null ? null : CHG_FLG.trim();
    }

    /**
     * パス情報
     * @return PATH_INF パス情報
     */
    public String getPATH_INF() {
        return PATH_INF;
    }

    /**
     * パス情報
     * @param PATH_INF パス情報
     */
    public void setPATH_INF(String PATH_INF) {
        this.PATH_INF = PATH_INF == null ? null : PATH_INF.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}