package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CEigyoNyusyukinExample {
    /**
     * C_EIGYO_NYUSYUKIN
     */
    protected String orderByClause;

    /**
     * C_EIGYO_NYUSYUKIN
     */
    protected boolean distinct;

    /**
     * C_EIGYO_NYUSYUKIN
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public CEigyoNyusyukinExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * C_EIGYO_NYUSYUKIN null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andSOSHIN_SHKBTS_KEYIsNull() {
            addCriterion("SOSHIN_SHKBTS_KEY is null");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_KEYIsNotNull() {
            addCriterion("SOSHIN_SHKBTS_KEY is not null");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_KEYEqualTo(String value) {
            addCriterion("SOSHIN_SHKBTS_KEY =", value, "SOSHIN_SHKBTS_KEY");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_KEYNotEqualTo(String value) {
            addCriterion("SOSHIN_SHKBTS_KEY <>", value, "SOSHIN_SHKBTS_KEY");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_KEYGreaterThan(String value) {
            addCriterion("SOSHIN_SHKBTS_KEY >", value, "SOSHIN_SHKBTS_KEY");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_KEYGreaterThanOrEqualTo(String value) {
            addCriterion("SOSHIN_SHKBTS_KEY >=", value, "SOSHIN_SHKBTS_KEY");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_KEYLessThan(String value) {
            addCriterion("SOSHIN_SHKBTS_KEY <", value, "SOSHIN_SHKBTS_KEY");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_KEYLessThanOrEqualTo(String value) {
            addCriterion("SOSHIN_SHKBTS_KEY <=", value, "SOSHIN_SHKBTS_KEY");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_KEYLike(String value) {
            addCriterion("SOSHIN_SHKBTS_KEY like", value, "SOSHIN_SHKBTS_KEY");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_KEYNotLike(String value) {
            addCriterion("SOSHIN_SHKBTS_KEY not like", value, "SOSHIN_SHKBTS_KEY");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_KEYIn(List<String> values) {
            addCriterion("SOSHIN_SHKBTS_KEY in", values, "SOSHIN_SHKBTS_KEY");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_KEYNotIn(List<String> values) {
            addCriterion("SOSHIN_SHKBTS_KEY not in", values, "SOSHIN_SHKBTS_KEY");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_KEYBetween(String value1, String value2) {
            addCriterion("SOSHIN_SHKBTS_KEY between", value1, value2, "SOSHIN_SHKBTS_KEY");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_KEYNotBetween(String value1, String value2) {
            addCriterion("SOSHIN_SHKBTS_KEY not between", value1, value2, "SOSHIN_SHKBTS_KEY");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_SNIsNull() {
            addCriterion("SOSHIN_SHKBTS_SN is null");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_SNIsNotNull() {
            addCriterion("SOSHIN_SHKBTS_SN is not null");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_SNEqualTo(String value) {
            addCriterion("SOSHIN_SHKBTS_SN =", value, "SOSHIN_SHKBTS_SN");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_SNNotEqualTo(String value) {
            addCriterion("SOSHIN_SHKBTS_SN <>", value, "SOSHIN_SHKBTS_SN");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_SNGreaterThan(String value) {
            addCriterion("SOSHIN_SHKBTS_SN >", value, "SOSHIN_SHKBTS_SN");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_SNGreaterThanOrEqualTo(String value) {
            addCriterion("SOSHIN_SHKBTS_SN >=", value, "SOSHIN_SHKBTS_SN");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_SNLessThan(String value) {
            addCriterion("SOSHIN_SHKBTS_SN <", value, "SOSHIN_SHKBTS_SN");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_SNLessThanOrEqualTo(String value) {
            addCriterion("SOSHIN_SHKBTS_SN <=", value, "SOSHIN_SHKBTS_SN");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_SNLike(String value) {
            addCriterion("SOSHIN_SHKBTS_SN like", value, "SOSHIN_SHKBTS_SN");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_SNNotLike(String value) {
            addCriterion("SOSHIN_SHKBTS_SN not like", value, "SOSHIN_SHKBTS_SN");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_SNIn(List<String> values) {
            addCriterion("SOSHIN_SHKBTS_SN in", values, "SOSHIN_SHKBTS_SN");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_SNNotIn(List<String> values) {
            addCriterion("SOSHIN_SHKBTS_SN not in", values, "SOSHIN_SHKBTS_SN");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_SNBetween(String value1, String value2) {
            addCriterion("SOSHIN_SHKBTS_SN between", value1, value2, "SOSHIN_SHKBTS_SN");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_SNNotBetween(String value1, String value2) {
            addCriterion("SOSHIN_SHKBTS_SN not between", value1, value2, "SOSHIN_SHKBTS_SN");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_MEISAI_SNIsNull() {
            addCriterion("SOSHIN_SHKBTS_MEISAI_SN is null");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_MEISAI_SNIsNotNull() {
            addCriterion("SOSHIN_SHKBTS_MEISAI_SN is not null");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_MEISAI_SNEqualTo(String value) {
            addCriterion("SOSHIN_SHKBTS_MEISAI_SN =", value, "SOSHIN_SHKBTS_MEISAI_SN");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_MEISAI_SNNotEqualTo(String value) {
            addCriterion("SOSHIN_SHKBTS_MEISAI_SN <>", value, "SOSHIN_SHKBTS_MEISAI_SN");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_MEISAI_SNGreaterThan(String value) {
            addCriterion("SOSHIN_SHKBTS_MEISAI_SN >", value, "SOSHIN_SHKBTS_MEISAI_SN");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_MEISAI_SNGreaterThanOrEqualTo(String value) {
            addCriterion("SOSHIN_SHKBTS_MEISAI_SN >=", value, "SOSHIN_SHKBTS_MEISAI_SN");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_MEISAI_SNLessThan(String value) {
            addCriterion("SOSHIN_SHKBTS_MEISAI_SN <", value, "SOSHIN_SHKBTS_MEISAI_SN");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_MEISAI_SNLessThanOrEqualTo(String value) {
            addCriterion("SOSHIN_SHKBTS_MEISAI_SN <=", value, "SOSHIN_SHKBTS_MEISAI_SN");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_MEISAI_SNLike(String value) {
            addCriterion("SOSHIN_SHKBTS_MEISAI_SN like", value, "SOSHIN_SHKBTS_MEISAI_SN");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_MEISAI_SNNotLike(String value) {
            addCriterion("SOSHIN_SHKBTS_MEISAI_SN not like", value, "SOSHIN_SHKBTS_MEISAI_SN");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_MEISAI_SNIn(List<String> values) {
            addCriterion("SOSHIN_SHKBTS_MEISAI_SN in", values, "SOSHIN_SHKBTS_MEISAI_SN");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_MEISAI_SNNotIn(List<String> values) {
            addCriterion("SOSHIN_SHKBTS_MEISAI_SN not in", values, "SOSHIN_SHKBTS_MEISAI_SN");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_MEISAI_SNBetween(String value1, String value2) {
            addCriterion("SOSHIN_SHKBTS_MEISAI_SN between", value1, value2, "SOSHIN_SHKBTS_MEISAI_SN");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_MEISAI_SNNotBetween(String value1, String value2) {
            addCriterion("SOSHIN_SHKBTS_MEISAI_SN not between", value1, value2, "SOSHIN_SHKBTS_MEISAI_SN");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_NOIsNull() {
            addCriterion("NYUSHUKKINKI_NO is null");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_NOIsNotNull() {
            addCriterion("NYUSHUKKINKI_NO is not null");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_NOEqualTo(String value) {
            addCriterion("NYUSHUKKINKI_NO =", value, "NYUSHUKKINKI_NO");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_NONotEqualTo(String value) {
            addCriterion("NYUSHUKKINKI_NO <>", value, "NYUSHUKKINKI_NO");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_NOGreaterThan(String value) {
            addCriterion("NYUSHUKKINKI_NO >", value, "NYUSHUKKINKI_NO");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_NOGreaterThanOrEqualTo(String value) {
            addCriterion("NYUSHUKKINKI_NO >=", value, "NYUSHUKKINKI_NO");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_NOLessThan(String value) {
            addCriterion("NYUSHUKKINKI_NO <", value, "NYUSHUKKINKI_NO");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_NOLessThanOrEqualTo(String value) {
            addCriterion("NYUSHUKKINKI_NO <=", value, "NYUSHUKKINKI_NO");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_NOLike(String value) {
            addCriterion("NYUSHUKKINKI_NO like", value, "NYUSHUKKINKI_NO");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_NONotLike(String value) {
            addCriterion("NYUSHUKKINKI_NO not like", value, "NYUSHUKKINKI_NO");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_NOIn(List<String> values) {
            addCriterion("NYUSHUKKINKI_NO in", values, "NYUSHUKKINKI_NO");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_NONotIn(List<String> values) {
            addCriterion("NYUSHUKKINKI_NO not in", values, "NYUSHUKKINKI_NO");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_NOBetween(String value1, String value2) {
            addCriterion("NYUSHUKKINKI_NO between", value1, value2, "NYUSHUKKINKI_NO");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_NONotBetween(String value1, String value2) {
            addCriterion("NYUSHUKKINKI_NO not between", value1, value2, "NYUSHUKKINKI_NO");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHUBETSUIsNull() {
            addCriterion("NYUSHUKKINKI_SHUBETSU is null");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHUBETSUIsNotNull() {
            addCriterion("NYUSHUKKINKI_SHUBETSU is not null");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHUBETSUEqualTo(String value) {
            addCriterion("NYUSHUKKINKI_SHUBETSU =", value, "NYUSHUKKINKI_SHUBETSU");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHUBETSUNotEqualTo(String value) {
            addCriterion("NYUSHUKKINKI_SHUBETSU <>", value, "NYUSHUKKINKI_SHUBETSU");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHUBETSUGreaterThan(String value) {
            addCriterion("NYUSHUKKINKI_SHUBETSU >", value, "NYUSHUKKINKI_SHUBETSU");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHUBETSUGreaterThanOrEqualTo(String value) {
            addCriterion("NYUSHUKKINKI_SHUBETSU >=", value, "NYUSHUKKINKI_SHUBETSU");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHUBETSULessThan(String value) {
            addCriterion("NYUSHUKKINKI_SHUBETSU <", value, "NYUSHUKKINKI_SHUBETSU");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHUBETSULessThanOrEqualTo(String value) {
            addCriterion("NYUSHUKKINKI_SHUBETSU <=", value, "NYUSHUKKINKI_SHUBETSU");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHUBETSULike(String value) {
            addCriterion("NYUSHUKKINKI_SHUBETSU like", value, "NYUSHUKKINKI_SHUBETSU");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHUBETSUNotLike(String value) {
            addCriterion("NYUSHUKKINKI_SHUBETSU not like", value, "NYUSHUKKINKI_SHUBETSU");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHUBETSUIn(List<String> values) {
            addCriterion("NYUSHUKKINKI_SHUBETSU in", values, "NYUSHUKKINKI_SHUBETSU");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHUBETSUNotIn(List<String> values) {
            addCriterion("NYUSHUKKINKI_SHUBETSU not in", values, "NYUSHUKKINKI_SHUBETSU");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHUBETSUBetween(String value1, String value2) {
            addCriterion("NYUSHUKKINKI_SHUBETSU between", value1, value2, "NYUSHUKKINKI_SHUBETSU");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHUBETSUNotBetween(String value1, String value2) {
            addCriterion("NYUSHUKKINKI_SHUBETSU not between", value1, value2, "NYUSHUKKINKI_SHUBETSU");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHURUIIsNull() {
            addCriterion("NYUSHUKKINKI_SHURUI is null");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHURUIIsNotNull() {
            addCriterion("NYUSHUKKINKI_SHURUI is not null");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHURUIEqualTo(String value) {
            addCriterion("NYUSHUKKINKI_SHURUI =", value, "NYUSHUKKINKI_SHURUI");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHURUINotEqualTo(String value) {
            addCriterion("NYUSHUKKINKI_SHURUI <>", value, "NYUSHUKKINKI_SHURUI");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHURUIGreaterThan(String value) {
            addCriterion("NYUSHUKKINKI_SHURUI >", value, "NYUSHUKKINKI_SHURUI");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHURUIGreaterThanOrEqualTo(String value) {
            addCriterion("NYUSHUKKINKI_SHURUI >=", value, "NYUSHUKKINKI_SHURUI");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHURUILessThan(String value) {
            addCriterion("NYUSHUKKINKI_SHURUI <", value, "NYUSHUKKINKI_SHURUI");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHURUILessThanOrEqualTo(String value) {
            addCriterion("NYUSHUKKINKI_SHURUI <=", value, "NYUSHUKKINKI_SHURUI");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHURUILike(String value) {
            addCriterion("NYUSHUKKINKI_SHURUI like", value, "NYUSHUKKINKI_SHURUI");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHURUINotLike(String value) {
            addCriterion("NYUSHUKKINKI_SHURUI not like", value, "NYUSHUKKINKI_SHURUI");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHURUIIn(List<String> values) {
            addCriterion("NYUSHUKKINKI_SHURUI in", values, "NYUSHUKKINKI_SHURUI");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHURUINotIn(List<String> values) {
            addCriterion("NYUSHUKKINKI_SHURUI not in", values, "NYUSHUKKINKI_SHURUI");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHURUIBetween(String value1, String value2) {
            addCriterion("NYUSHUKKINKI_SHURUI between", value1, value2, "NYUSHUKKINKI_SHURUI");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHURUINotBetween(String value1, String value2) {
            addCriterion("NYUSHUKKINKI_SHURUI not between", value1, value2, "NYUSHUKKINKI_SHURUI");
            return (Criteria) this;
        }

        public Criteria andCHUKO_NYUSHUKKINKI_NOIsNull() {
            addCriterion("CHUKO_NYUSHUKKINKI_NO is null");
            return (Criteria) this;
        }

        public Criteria andCHUKO_NYUSHUKKINKI_NOIsNotNull() {
            addCriterion("CHUKO_NYUSHUKKINKI_NO is not null");
            return (Criteria) this;
        }

        public Criteria andCHUKO_NYUSHUKKINKI_NOEqualTo(String value) {
            addCriterion("CHUKO_NYUSHUKKINKI_NO =", value, "CHUKO_NYUSHUKKINKI_NO");
            return (Criteria) this;
        }

        public Criteria andCHUKO_NYUSHUKKINKI_NONotEqualTo(String value) {
            addCriterion("CHUKO_NYUSHUKKINKI_NO <>", value, "CHUKO_NYUSHUKKINKI_NO");
            return (Criteria) this;
        }

        public Criteria andCHUKO_NYUSHUKKINKI_NOGreaterThan(String value) {
            addCriterion("CHUKO_NYUSHUKKINKI_NO >", value, "CHUKO_NYUSHUKKINKI_NO");
            return (Criteria) this;
        }

        public Criteria andCHUKO_NYUSHUKKINKI_NOGreaterThanOrEqualTo(String value) {
            addCriterion("CHUKO_NYUSHUKKINKI_NO >=", value, "CHUKO_NYUSHUKKINKI_NO");
            return (Criteria) this;
        }

        public Criteria andCHUKO_NYUSHUKKINKI_NOLessThan(String value) {
            addCriterion("CHUKO_NYUSHUKKINKI_NO <", value, "CHUKO_NYUSHUKKINKI_NO");
            return (Criteria) this;
        }

        public Criteria andCHUKO_NYUSHUKKINKI_NOLessThanOrEqualTo(String value) {
            addCriterion("CHUKO_NYUSHUKKINKI_NO <=", value, "CHUKO_NYUSHUKKINKI_NO");
            return (Criteria) this;
        }

        public Criteria andCHUKO_NYUSHUKKINKI_NOLike(String value) {
            addCriterion("CHUKO_NYUSHUKKINKI_NO like", value, "CHUKO_NYUSHUKKINKI_NO");
            return (Criteria) this;
        }

        public Criteria andCHUKO_NYUSHUKKINKI_NONotLike(String value) {
            addCriterion("CHUKO_NYUSHUKKINKI_NO not like", value, "CHUKO_NYUSHUKKINKI_NO");
            return (Criteria) this;
        }

        public Criteria andCHUKO_NYUSHUKKINKI_NOIn(List<String> values) {
            addCriterion("CHUKO_NYUSHUKKINKI_NO in", values, "CHUKO_NYUSHUKKINKI_NO");
            return (Criteria) this;
        }

        public Criteria andCHUKO_NYUSHUKKINKI_NONotIn(List<String> values) {
            addCriterion("CHUKO_NYUSHUKKINKI_NO not in", values, "CHUKO_NYUSHUKKINKI_NO");
            return (Criteria) this;
        }

        public Criteria andCHUKO_NYUSHUKKINKI_NOBetween(String value1, String value2) {
            addCriterion("CHUKO_NYUSHUKKINKI_NO between", value1, value2, "CHUKO_NYUSHUKKINKI_NO");
            return (Criteria) this;
        }

        public Criteria andCHUKO_NYUSHUKKINKI_NONotBetween(String value1, String value2) {
            addCriterion("CHUKO_NYUSHUKKINKI_NO not between", value1, value2, "CHUKO_NYUSHUKKINKI_NO");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_PRINTIsNull() {
            addCriterion("NYSHKKNK_SHD_SHM_PRINT is null");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_PRINTIsNotNull() {
            addCriterion("NYSHKKNK_SHD_SHM_PRINT is not null");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_PRINTEqualTo(String value) {
            addCriterion("NYSHKKNK_SHD_SHM_PRINT =", value, "NYSHKKNK_SHD_SHM_PRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_PRINTNotEqualTo(String value) {
            addCriterion("NYSHKKNK_SHD_SHM_PRINT <>", value, "NYSHKKNK_SHD_SHM_PRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_PRINTGreaterThan(String value) {
            addCriterion("NYSHKKNK_SHD_SHM_PRINT >", value, "NYSHKKNK_SHD_SHM_PRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_PRINTGreaterThanOrEqualTo(String value) {
            addCriterion("NYSHKKNK_SHD_SHM_PRINT >=", value, "NYSHKKNK_SHD_SHM_PRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_PRINTLessThan(String value) {
            addCriterion("NYSHKKNK_SHD_SHM_PRINT <", value, "NYSHKKNK_SHD_SHM_PRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_PRINTLessThanOrEqualTo(String value) {
            addCriterion("NYSHKKNK_SHD_SHM_PRINT <=", value, "NYSHKKNK_SHD_SHM_PRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_PRINTLike(String value) {
            addCriterion("NYSHKKNK_SHD_SHM_PRINT like", value, "NYSHKKNK_SHD_SHM_PRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_PRINTNotLike(String value) {
            addCriterion("NYSHKKNK_SHD_SHM_PRINT not like", value, "NYSHKKNK_SHD_SHM_PRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_PRINTIn(List<String> values) {
            addCriterion("NYSHKKNK_SHD_SHM_PRINT in", values, "NYSHKKNK_SHD_SHM_PRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_PRINTNotIn(List<String> values) {
            addCriterion("NYSHKKNK_SHD_SHM_PRINT not in", values, "NYSHKKNK_SHD_SHM_PRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_PRINTBetween(String value1, String value2) {
            addCriterion("NYSHKKNK_SHD_SHM_PRINT between", value1, value2, "NYSHKKNK_SHD_SHM_PRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_PRINTNotBetween(String value1, String value2) {
            addCriterion("NYSHKKNK_SHD_SHM_PRINT not between", value1, value2, "NYSHKKNK_SHD_SHM_PRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_REPRINTIsNull() {
            addCriterion("NYSHKKNK_SHD_SHM_REPRINT is null");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_REPRINTIsNotNull() {
            addCriterion("NYSHKKNK_SHD_SHM_REPRINT is not null");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_REPRINTEqualTo(String value) {
            addCriterion("NYSHKKNK_SHD_SHM_REPRINT =", value, "NYSHKKNK_SHD_SHM_REPRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_REPRINTNotEqualTo(String value) {
            addCriterion("NYSHKKNK_SHD_SHM_REPRINT <>", value, "NYSHKKNK_SHD_SHM_REPRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_REPRINTGreaterThan(String value) {
            addCriterion("NYSHKKNK_SHD_SHM_REPRINT >", value, "NYSHKKNK_SHD_SHM_REPRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_REPRINTGreaterThanOrEqualTo(String value) {
            addCriterion("NYSHKKNK_SHD_SHM_REPRINT >=", value, "NYSHKKNK_SHD_SHM_REPRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_REPRINTLessThan(String value) {
            addCriterion("NYSHKKNK_SHD_SHM_REPRINT <", value, "NYSHKKNK_SHD_SHM_REPRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_REPRINTLessThanOrEqualTo(String value) {
            addCriterion("NYSHKKNK_SHD_SHM_REPRINT <=", value, "NYSHKKNK_SHD_SHM_REPRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_REPRINTLike(String value) {
            addCriterion("NYSHKKNK_SHD_SHM_REPRINT like", value, "NYSHKKNK_SHD_SHM_REPRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_REPRINTNotLike(String value) {
            addCriterion("NYSHKKNK_SHD_SHM_REPRINT not like", value, "NYSHKKNK_SHD_SHM_REPRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_REPRINTIn(List<String> values) {
            addCriterion("NYSHKKNK_SHD_SHM_REPRINT in", values, "NYSHKKNK_SHD_SHM_REPRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_REPRINTNotIn(List<String> values) {
            addCriterion("NYSHKKNK_SHD_SHM_REPRINT not in", values, "NYSHKKNK_SHD_SHM_REPRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_REPRINTBetween(String value1, String value2) {
            addCriterion("NYSHKKNK_SHD_SHM_REPRINT between", value1, value2, "NYSHKKNK_SHD_SHM_REPRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_REPRINTNotBetween(String value1, String value2) {
            addCriterion("NYSHKKNK_SHD_SHM_REPRINT not between", value1, value2, "NYSHKKNK_SHD_SHM_REPRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHMIsNull() {
            addCriterion("NYSHKKNK_JD_SHM is null");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHMIsNotNull() {
            addCriterion("NYSHKKNK_JD_SHM is not null");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHMEqualTo(String value) {
            addCriterion("NYSHKKNK_JD_SHM =", value, "NYSHKKNK_JD_SHM");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHMNotEqualTo(String value) {
            addCriterion("NYSHKKNK_JD_SHM <>", value, "NYSHKKNK_JD_SHM");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHMGreaterThan(String value) {
            addCriterion("NYSHKKNK_JD_SHM >", value, "NYSHKKNK_JD_SHM");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHMGreaterThanOrEqualTo(String value) {
            addCriterion("NYSHKKNK_JD_SHM >=", value, "NYSHKKNK_JD_SHM");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHMLessThan(String value) {
            addCriterion("NYSHKKNK_JD_SHM <", value, "NYSHKKNK_JD_SHM");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHMLessThanOrEqualTo(String value) {
            addCriterion("NYSHKKNK_JD_SHM <=", value, "NYSHKKNK_JD_SHM");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHMLike(String value) {
            addCriterion("NYSHKKNK_JD_SHM like", value, "NYSHKKNK_JD_SHM");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHMNotLike(String value) {
            addCriterion("NYSHKKNK_JD_SHM not like", value, "NYSHKKNK_JD_SHM");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHMIn(List<String> values) {
            addCriterion("NYSHKKNK_JD_SHM in", values, "NYSHKKNK_JD_SHM");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHMNotIn(List<String> values) {
            addCriterion("NYSHKKNK_JD_SHM not in", values, "NYSHKKNK_JD_SHM");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHMBetween(String value1, String value2) {
            addCriterion("NYSHKKNK_JD_SHM between", value1, value2, "NYSHKKNK_JD_SHM");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHMNotBetween(String value1, String value2) {
            addCriterion("NYSHKKNK_JD_SHM not between", value1, value2, "NYSHKKNK_JD_SHM");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_JIDO_SHIME_TMIsNull() {
            addCriterion("NYUSHUKKINKI_JIDO_SHIME_TM is null");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_JIDO_SHIME_TMIsNotNull() {
            addCriterion("NYUSHUKKINKI_JIDO_SHIME_TM is not null");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_JIDO_SHIME_TMEqualTo(String value) {
            addCriterion("NYUSHUKKINKI_JIDO_SHIME_TM =", value, "NYUSHUKKINKI_JIDO_SHIME_TM");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_JIDO_SHIME_TMNotEqualTo(String value) {
            addCriterion("NYUSHUKKINKI_JIDO_SHIME_TM <>", value, "NYUSHUKKINKI_JIDO_SHIME_TM");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_JIDO_SHIME_TMGreaterThan(String value) {
            addCriterion("NYUSHUKKINKI_JIDO_SHIME_TM >", value, "NYUSHUKKINKI_JIDO_SHIME_TM");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_JIDO_SHIME_TMGreaterThanOrEqualTo(String value) {
            addCriterion("NYUSHUKKINKI_JIDO_SHIME_TM >=", value, "NYUSHUKKINKI_JIDO_SHIME_TM");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_JIDO_SHIME_TMLessThan(String value) {
            addCriterion("NYUSHUKKINKI_JIDO_SHIME_TM <", value, "NYUSHUKKINKI_JIDO_SHIME_TM");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_JIDO_SHIME_TMLessThanOrEqualTo(String value) {
            addCriterion("NYUSHUKKINKI_JIDO_SHIME_TM <=", value, "NYUSHUKKINKI_JIDO_SHIME_TM");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_JIDO_SHIME_TMLike(String value) {
            addCriterion("NYUSHUKKINKI_JIDO_SHIME_TM like", value, "NYUSHUKKINKI_JIDO_SHIME_TM");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_JIDO_SHIME_TMNotLike(String value) {
            addCriterion("NYUSHUKKINKI_JIDO_SHIME_TM not like", value, "NYUSHUKKINKI_JIDO_SHIME_TM");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_JIDO_SHIME_TMIn(List<String> values) {
            addCriterion("NYUSHUKKINKI_JIDO_SHIME_TM in", values, "NYUSHUKKINKI_JIDO_SHIME_TM");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_JIDO_SHIME_TMNotIn(List<String> values) {
            addCriterion("NYUSHUKKINKI_JIDO_SHIME_TM not in", values, "NYUSHUKKINKI_JIDO_SHIME_TM");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_JIDO_SHIME_TMBetween(String value1, String value2) {
            addCriterion("NYUSHUKKINKI_JIDO_SHIME_TM between", value1, value2, "NYUSHUKKINKI_JIDO_SHIME_TM");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_JIDO_SHIME_TMNotBetween(String value1, String value2) {
            addCriterion("NYUSHUKKINKI_JIDO_SHIME_TM not between", value1, value2, "NYUSHUKKINKI_JIDO_SHIME_TM");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHM_PRINTIsNull() {
            addCriterion("NYSHKKNK_JD_SHM_PRINT is null");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHM_PRINTIsNotNull() {
            addCriterion("NYSHKKNK_JD_SHM_PRINT is not null");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHM_PRINTEqualTo(String value) {
            addCriterion("NYSHKKNK_JD_SHM_PRINT =", value, "NYSHKKNK_JD_SHM_PRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHM_PRINTNotEqualTo(String value) {
            addCriterion("NYSHKKNK_JD_SHM_PRINT <>", value, "NYSHKKNK_JD_SHM_PRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHM_PRINTGreaterThan(String value) {
            addCriterion("NYSHKKNK_JD_SHM_PRINT >", value, "NYSHKKNK_JD_SHM_PRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHM_PRINTGreaterThanOrEqualTo(String value) {
            addCriterion("NYSHKKNK_JD_SHM_PRINT >=", value, "NYSHKKNK_JD_SHM_PRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHM_PRINTLessThan(String value) {
            addCriterion("NYSHKKNK_JD_SHM_PRINT <", value, "NYSHKKNK_JD_SHM_PRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHM_PRINTLessThanOrEqualTo(String value) {
            addCriterion("NYSHKKNK_JD_SHM_PRINT <=", value, "NYSHKKNK_JD_SHM_PRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHM_PRINTLike(String value) {
            addCriterion("NYSHKKNK_JD_SHM_PRINT like", value, "NYSHKKNK_JD_SHM_PRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHM_PRINTNotLike(String value) {
            addCriterion("NYSHKKNK_JD_SHM_PRINT not like", value, "NYSHKKNK_JD_SHM_PRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHM_PRINTIn(List<String> values) {
            addCriterion("NYSHKKNK_JD_SHM_PRINT in", values, "NYSHKKNK_JD_SHM_PRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHM_PRINTNotIn(List<String> values) {
            addCriterion("NYSHKKNK_JD_SHM_PRINT not in", values, "NYSHKKNK_JD_SHM_PRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHM_PRINTBetween(String value1, String value2) {
            addCriterion("NYSHKKNK_JD_SHM_PRINT between", value1, value2, "NYSHKKNK_JD_SHM_PRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHM_PRINTNotBetween(String value1, String value2) {
            addCriterion("NYSHKKNK_JD_SHM_PRINT not between", value1, value2, "NYSHKKNK_JD_SHM_PRINT");
            return (Criteria) this;
        }

        public Criteria andNSKKNK_SM_REGI_BTIsNull() {
            addCriterion("NSKKNK_SM_REGI_BT is null");
            return (Criteria) this;
        }

        public Criteria andNSKKNK_SM_REGI_BTIsNotNull() {
            addCriterion("NSKKNK_SM_REGI_BT is not null");
            return (Criteria) this;
        }

        public Criteria andNSKKNK_SM_REGI_BTEqualTo(String value) {
            addCriterion("NSKKNK_SM_REGI_BT =", value, "NSKKNK_SM_REGI_BT");
            return (Criteria) this;
        }

        public Criteria andNSKKNK_SM_REGI_BTNotEqualTo(String value) {
            addCriterion("NSKKNK_SM_REGI_BT <>", value, "NSKKNK_SM_REGI_BT");
            return (Criteria) this;
        }

        public Criteria andNSKKNK_SM_REGI_BTGreaterThan(String value) {
            addCriterion("NSKKNK_SM_REGI_BT >", value, "NSKKNK_SM_REGI_BT");
            return (Criteria) this;
        }

        public Criteria andNSKKNK_SM_REGI_BTGreaterThanOrEqualTo(String value) {
            addCriterion("NSKKNK_SM_REGI_BT >=", value, "NSKKNK_SM_REGI_BT");
            return (Criteria) this;
        }

        public Criteria andNSKKNK_SM_REGI_BTLessThan(String value) {
            addCriterion("NSKKNK_SM_REGI_BT <", value, "NSKKNK_SM_REGI_BT");
            return (Criteria) this;
        }

        public Criteria andNSKKNK_SM_REGI_BTLessThanOrEqualTo(String value) {
            addCriterion("NSKKNK_SM_REGI_BT <=", value, "NSKKNK_SM_REGI_BT");
            return (Criteria) this;
        }

        public Criteria andNSKKNK_SM_REGI_BTLike(String value) {
            addCriterion("NSKKNK_SM_REGI_BT like", value, "NSKKNK_SM_REGI_BT");
            return (Criteria) this;
        }

        public Criteria andNSKKNK_SM_REGI_BTNotLike(String value) {
            addCriterion("NSKKNK_SM_REGI_BT not like", value, "NSKKNK_SM_REGI_BT");
            return (Criteria) this;
        }

        public Criteria andNSKKNK_SM_REGI_BTIn(List<String> values) {
            addCriterion("NSKKNK_SM_REGI_BT in", values, "NSKKNK_SM_REGI_BT");
            return (Criteria) this;
        }

        public Criteria andNSKKNK_SM_REGI_BTNotIn(List<String> values) {
            addCriterion("NSKKNK_SM_REGI_BT not in", values, "NSKKNK_SM_REGI_BT");
            return (Criteria) this;
        }

        public Criteria andNSKKNK_SM_REGI_BTBetween(String value1, String value2) {
            addCriterion("NSKKNK_SM_REGI_BT between", value1, value2, "NSKKNK_SM_REGI_BT");
            return (Criteria) this;
        }

        public Criteria andNSKKNK_SM_REGI_BTNotBetween(String value1, String value2) {
            addCriterion("NSKKNK_SM_REGI_BT not between", value1, value2, "NSKKNK_SM_REGI_BT");
            return (Criteria) this;
        }

        public Criteria andKAISEN_SHUBETSUIsNull() {
            addCriterion("KAISEN_SHUBETSU is null");
            return (Criteria) this;
        }

        public Criteria andKAISEN_SHUBETSUIsNotNull() {
            addCriterion("KAISEN_SHUBETSU is not null");
            return (Criteria) this;
        }

        public Criteria andKAISEN_SHUBETSUEqualTo(String value) {
            addCriterion("KAISEN_SHUBETSU =", value, "KAISEN_SHUBETSU");
            return (Criteria) this;
        }

        public Criteria andKAISEN_SHUBETSUNotEqualTo(String value) {
            addCriterion("KAISEN_SHUBETSU <>", value, "KAISEN_SHUBETSU");
            return (Criteria) this;
        }

        public Criteria andKAISEN_SHUBETSUGreaterThan(String value) {
            addCriterion("KAISEN_SHUBETSU >", value, "KAISEN_SHUBETSU");
            return (Criteria) this;
        }

        public Criteria andKAISEN_SHUBETSUGreaterThanOrEqualTo(String value) {
            addCriterion("KAISEN_SHUBETSU >=", value, "KAISEN_SHUBETSU");
            return (Criteria) this;
        }

        public Criteria andKAISEN_SHUBETSULessThan(String value) {
            addCriterion("KAISEN_SHUBETSU <", value, "KAISEN_SHUBETSU");
            return (Criteria) this;
        }

        public Criteria andKAISEN_SHUBETSULessThanOrEqualTo(String value) {
            addCriterion("KAISEN_SHUBETSU <=", value, "KAISEN_SHUBETSU");
            return (Criteria) this;
        }

        public Criteria andKAISEN_SHUBETSULike(String value) {
            addCriterion("KAISEN_SHUBETSU like", value, "KAISEN_SHUBETSU");
            return (Criteria) this;
        }

        public Criteria andKAISEN_SHUBETSUNotLike(String value) {
            addCriterion("KAISEN_SHUBETSU not like", value, "KAISEN_SHUBETSU");
            return (Criteria) this;
        }

        public Criteria andKAISEN_SHUBETSUIn(List<String> values) {
            addCriterion("KAISEN_SHUBETSU in", values, "KAISEN_SHUBETSU");
            return (Criteria) this;
        }

        public Criteria andKAISEN_SHUBETSUNotIn(List<String> values) {
            addCriterion("KAISEN_SHUBETSU not in", values, "KAISEN_SHUBETSU");
            return (Criteria) this;
        }

        public Criteria andKAISEN_SHUBETSUBetween(String value1, String value2) {
            addCriterion("KAISEN_SHUBETSU between", value1, value2, "KAISEN_SHUBETSU");
            return (Criteria) this;
        }

        public Criteria andKAISEN_SHUBETSUNotBetween(String value1, String value2) {
            addCriterion("KAISEN_SHUBETSU not between", value1, value2, "KAISEN_SHUBETSU");
            return (Criteria) this;
        }

        public Criteria andMAIN_KAISEN_IP_ADDRESSIsNull() {
            addCriterion("MAIN_KAISEN_IP_ADDRESS is null");
            return (Criteria) this;
        }

        public Criteria andMAIN_KAISEN_IP_ADDRESSIsNotNull() {
            addCriterion("MAIN_KAISEN_IP_ADDRESS is not null");
            return (Criteria) this;
        }

        public Criteria andMAIN_KAISEN_IP_ADDRESSEqualTo(String value) {
            addCriterion("MAIN_KAISEN_IP_ADDRESS =", value, "MAIN_KAISEN_IP_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andMAIN_KAISEN_IP_ADDRESSNotEqualTo(String value) {
            addCriterion("MAIN_KAISEN_IP_ADDRESS <>", value, "MAIN_KAISEN_IP_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andMAIN_KAISEN_IP_ADDRESSGreaterThan(String value) {
            addCriterion("MAIN_KAISEN_IP_ADDRESS >", value, "MAIN_KAISEN_IP_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andMAIN_KAISEN_IP_ADDRESSGreaterThanOrEqualTo(String value) {
            addCriterion("MAIN_KAISEN_IP_ADDRESS >=", value, "MAIN_KAISEN_IP_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andMAIN_KAISEN_IP_ADDRESSLessThan(String value) {
            addCriterion("MAIN_KAISEN_IP_ADDRESS <", value, "MAIN_KAISEN_IP_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andMAIN_KAISEN_IP_ADDRESSLessThanOrEqualTo(String value) {
            addCriterion("MAIN_KAISEN_IP_ADDRESS <=", value, "MAIN_KAISEN_IP_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andMAIN_KAISEN_IP_ADDRESSLike(String value) {
            addCriterion("MAIN_KAISEN_IP_ADDRESS like", value, "MAIN_KAISEN_IP_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andMAIN_KAISEN_IP_ADDRESSNotLike(String value) {
            addCriterion("MAIN_KAISEN_IP_ADDRESS not like", value, "MAIN_KAISEN_IP_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andMAIN_KAISEN_IP_ADDRESSIn(List<String> values) {
            addCriterion("MAIN_KAISEN_IP_ADDRESS in", values, "MAIN_KAISEN_IP_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andMAIN_KAISEN_IP_ADDRESSNotIn(List<String> values) {
            addCriterion("MAIN_KAISEN_IP_ADDRESS not in", values, "MAIN_KAISEN_IP_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andMAIN_KAISEN_IP_ADDRESSBetween(String value1, String value2) {
            addCriterion("MAIN_KAISEN_IP_ADDRESS between", value1, value2, "MAIN_KAISEN_IP_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andMAIN_KAISEN_IP_ADDRESSNotBetween(String value1, String value2) {
            addCriterion("MAIN_KAISEN_IP_ADDRESS not between", value1, value2, "MAIN_KAISEN_IP_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01IsNull() {
            addCriterion("YOBI_KOMOKU_01 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01IsNotNull() {
            addCriterion("YOBI_KOMOKU_01 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_01 =", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_01 <>", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_01 >", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_01 >=", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01LessThan(String value) {
            addCriterion("YOBI_KOMOKU_01 <", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_01 <=", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01Like(String value) {
            addCriterion("YOBI_KOMOKU_01 like", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01NotLike(String value) {
            addCriterion("YOBI_KOMOKU_01 not like", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01In(List<String> values) {
            addCriterion("YOBI_KOMOKU_01 in", values, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_01 not in", values, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_01 between", value1, value2, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_01 not between", value1, value2, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02IsNull() {
            addCriterion("YOBI_KOMOKU_02 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02IsNotNull() {
            addCriterion("YOBI_KOMOKU_02 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_02 =", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_02 <>", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_02 >", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_02 >=", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02LessThan(String value) {
            addCriterion("YOBI_KOMOKU_02 <", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_02 <=", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02Like(String value) {
            addCriterion("YOBI_KOMOKU_02 like", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02NotLike(String value) {
            addCriterion("YOBI_KOMOKU_02 not like", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02In(List<String> values) {
            addCriterion("YOBI_KOMOKU_02 in", values, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_02 not in", values, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_02 between", value1, value2, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_02 not between", value1, value2, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03IsNull() {
            addCriterion("YOBI_KOMOKU_03 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03IsNotNull() {
            addCriterion("YOBI_KOMOKU_03 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_03 =", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_03 <>", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_03 >", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_03 >=", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03LessThan(String value) {
            addCriterion("YOBI_KOMOKU_03 <", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_03 <=", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03Like(String value) {
            addCriterion("YOBI_KOMOKU_03 like", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03NotLike(String value) {
            addCriterion("YOBI_KOMOKU_03 not like", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03In(List<String> values) {
            addCriterion("YOBI_KOMOKU_03 in", values, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_03 not in", values, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_03 between", value1, value2, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_03 not between", value1, value2, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04IsNull() {
            addCriterion("YOBI_KOMOKU_04 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04IsNotNull() {
            addCriterion("YOBI_KOMOKU_04 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_04 =", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_04 <>", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_04 >", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_04 >=", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04LessThan(String value) {
            addCriterion("YOBI_KOMOKU_04 <", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_04 <=", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04Like(String value) {
            addCriterion("YOBI_KOMOKU_04 like", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04NotLike(String value) {
            addCriterion("YOBI_KOMOKU_04 not like", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04In(List<String> values) {
            addCriterion("YOBI_KOMOKU_04 in", values, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_04 not in", values, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_04 between", value1, value2, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_04 not between", value1, value2, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05IsNull() {
            addCriterion("YOBI_KOMOKU_05 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05IsNotNull() {
            addCriterion("YOBI_KOMOKU_05 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_05 =", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_05 <>", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_05 >", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_05 >=", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05LessThan(String value) {
            addCriterion("YOBI_KOMOKU_05 <", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_05 <=", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05Like(String value) {
            addCriterion("YOBI_KOMOKU_05 like", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05NotLike(String value) {
            addCriterion("YOBI_KOMOKU_05 not like", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05In(List<String> values) {
            addCriterion("YOBI_KOMOKU_05 in", values, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_05 not in", values, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_05 between", value1, value2, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_05 not between", value1, value2, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06IsNull() {
            addCriterion("YOBI_KOMOKU_06 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06IsNotNull() {
            addCriterion("YOBI_KOMOKU_06 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_06 =", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_06 <>", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_06 >", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_06 >=", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06LessThan(String value) {
            addCriterion("YOBI_KOMOKU_06 <", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_06 <=", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06Like(String value) {
            addCriterion("YOBI_KOMOKU_06 like", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06NotLike(String value) {
            addCriterion("YOBI_KOMOKU_06 not like", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06In(List<String> values) {
            addCriterion("YOBI_KOMOKU_06 in", values, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_06 not in", values, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_06 between", value1, value2, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_06 not between", value1, value2, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07IsNull() {
            addCriterion("YOBI_KOMOKU_07 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07IsNotNull() {
            addCriterion("YOBI_KOMOKU_07 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_07 =", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_07 <>", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_07 >", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_07 >=", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07LessThan(String value) {
            addCriterion("YOBI_KOMOKU_07 <", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_07 <=", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07Like(String value) {
            addCriterion("YOBI_KOMOKU_07 like", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07NotLike(String value) {
            addCriterion("YOBI_KOMOKU_07 not like", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07In(List<String> values) {
            addCriterion("YOBI_KOMOKU_07 in", values, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_07 not in", values, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_07 between", value1, value2, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_07 not between", value1, value2, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08IsNull() {
            addCriterion("YOBI_KOMOKU_08 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08IsNotNull() {
            addCriterion("YOBI_KOMOKU_08 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_08 =", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_08 <>", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_08 >", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_08 >=", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08LessThan(String value) {
            addCriterion("YOBI_KOMOKU_08 <", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_08 <=", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08Like(String value) {
            addCriterion("YOBI_KOMOKU_08 like", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08NotLike(String value) {
            addCriterion("YOBI_KOMOKU_08 not like", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08In(List<String> values) {
            addCriterion("YOBI_KOMOKU_08 in", values, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_08 not in", values, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_08 between", value1, value2, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_08 not between", value1, value2, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09IsNull() {
            addCriterion("YOBI_KOMOKU_09 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09IsNotNull() {
            addCriterion("YOBI_KOMOKU_09 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_09 =", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_09 <>", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_09 >", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_09 >=", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09LessThan(String value) {
            addCriterion("YOBI_KOMOKU_09 <", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_09 <=", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09Like(String value) {
            addCriterion("YOBI_KOMOKU_09 like", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09NotLike(String value) {
            addCriterion("YOBI_KOMOKU_09 not like", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09In(List<String> values) {
            addCriterion("YOBI_KOMOKU_09 in", values, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_09 not in", values, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_09 between", value1, value2, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_09 not between", value1, value2, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10IsNull() {
            addCriterion("YOBI_KOMOKU_10 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10IsNotNull() {
            addCriterion("YOBI_KOMOKU_10 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_10 =", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_10 <>", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_10 >", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_10 >=", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10LessThan(String value) {
            addCriterion("YOBI_KOMOKU_10 <", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_10 <=", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10Like(String value) {
            addCriterion("YOBI_KOMOKU_10 like", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10NotLike(String value) {
            addCriterion("YOBI_KOMOKU_10 not like", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10In(List<String> values) {
            addCriterion("YOBI_KOMOKU_10 in", values, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_10 not in", values, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_10 between", value1, value2, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_10 not between", value1, value2, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPIsNull() {
            addCriterion("REGST_TMSTMP is null");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPIsNotNull() {
            addCriterion("REGST_TMSTMP is not null");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPEqualTo(Date value) {
            addCriterion("REGST_TMSTMP =", value, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPNotEqualTo(Date value) {
            addCriterion("REGST_TMSTMP <>", value, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPGreaterThan(Date value) {
            addCriterion("REGST_TMSTMP >", value, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPGreaterThanOrEqualTo(Date value) {
            addCriterion("REGST_TMSTMP >=", value, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPLessThan(Date value) {
            addCriterion("REGST_TMSTMP <", value, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPLessThanOrEqualTo(Date value) {
            addCriterion("REGST_TMSTMP <=", value, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPIn(List<Date> values) {
            addCriterion("REGST_TMSTMP in", values, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPNotIn(List<Date> values) {
            addCriterion("REGST_TMSTMP not in", values, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPBetween(Date value1, Date value2) {
            addCriterion("REGST_TMSTMP between", value1, value2, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPNotBetween(Date value1, Date value2) {
            addCriterion("REGST_TMSTMP not between", value1, value2, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDIsNull() {
            addCriterion("REGSTR_CO_CD is null");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDIsNotNull() {
            addCriterion("REGSTR_CO_CD is not null");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDEqualTo(String value) {
            addCriterion("REGSTR_CO_CD =", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDNotEqualTo(String value) {
            addCriterion("REGSTR_CO_CD <>", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDGreaterThan(String value) {
            addCriterion("REGSTR_CO_CD >", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDGreaterThanOrEqualTo(String value) {
            addCriterion("REGSTR_CO_CD >=", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDLessThan(String value) {
            addCriterion("REGSTR_CO_CD <", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDLessThanOrEqualTo(String value) {
            addCriterion("REGSTR_CO_CD <=", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDLike(String value) {
            addCriterion("REGSTR_CO_CD like", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDNotLike(String value) {
            addCriterion("REGSTR_CO_CD not like", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDIn(List<String> values) {
            addCriterion("REGSTR_CO_CD in", values, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDNotIn(List<String> values) {
            addCriterion("REGSTR_CO_CD not in", values, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDBetween(String value1, String value2) {
            addCriterion("REGSTR_CO_CD between", value1, value2, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDNotBetween(String value1, String value2) {
            addCriterion("REGSTR_CO_CD not between", value1, value2, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDIsNull() {
            addCriterion("REGSTR_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDIsNotNull() {
            addCriterion("REGSTR_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDEqualTo(String value) {
            addCriterion("REGSTR_SOSHIKI_CD =", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("REGSTR_SOSHIKI_CD <>", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("REGSTR_SOSHIKI_CD >", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("REGSTR_SOSHIKI_CD >=", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDLessThan(String value) {
            addCriterion("REGSTR_SOSHIKI_CD <", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("REGSTR_SOSHIKI_CD <=", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDLike(String value) {
            addCriterion("REGSTR_SOSHIKI_CD like", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDNotLike(String value) {
            addCriterion("REGSTR_SOSHIKI_CD not like", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDIn(List<String> values) {
            addCriterion("REGSTR_SOSHIKI_CD in", values, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("REGSTR_SOSHIKI_CD not in", values, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("REGSTR_SOSHIKI_CD between", value1, value2, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("REGSTR_SOSHIKI_CD not between", value1, value2, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOIsNull() {
            addCriterion("REGSTR_EMP_NO is null");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOIsNotNull() {
            addCriterion("REGSTR_EMP_NO is not null");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOEqualTo(String value) {
            addCriterion("REGSTR_EMP_NO =", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NONotEqualTo(String value) {
            addCriterion("REGSTR_EMP_NO <>", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOGreaterThan(String value) {
            addCriterion("REGSTR_EMP_NO >", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOGreaterThanOrEqualTo(String value) {
            addCriterion("REGSTR_EMP_NO >=", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOLessThan(String value) {
            addCriterion("REGSTR_EMP_NO <", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOLessThanOrEqualTo(String value) {
            addCriterion("REGSTR_EMP_NO <=", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOLike(String value) {
            addCriterion("REGSTR_EMP_NO like", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NONotLike(String value) {
            addCriterion("REGSTR_EMP_NO not like", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOIn(List<String> values) {
            addCriterion("REGSTR_EMP_NO in", values, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NONotIn(List<String> values) {
            addCriterion("REGSTR_EMP_NO not in", values, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOBetween(String value1, String value2) {
            addCriterion("REGSTR_EMP_NO between", value1, value2, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NONotBetween(String value1, String value2) {
            addCriterion("REGSTR_EMP_NO not between", value1, value2, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDIsNull() {
            addCriterion("REGST_GAMEN_ID is null");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDIsNotNull() {
            addCriterion("REGST_GAMEN_ID is not null");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDEqualTo(String value) {
            addCriterion("REGST_GAMEN_ID =", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDNotEqualTo(String value) {
            addCriterion("REGST_GAMEN_ID <>", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDGreaterThan(String value) {
            addCriterion("REGST_GAMEN_ID >", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDGreaterThanOrEqualTo(String value) {
            addCriterion("REGST_GAMEN_ID >=", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDLessThan(String value) {
            addCriterion("REGST_GAMEN_ID <", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDLessThanOrEqualTo(String value) {
            addCriterion("REGST_GAMEN_ID <=", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDLike(String value) {
            addCriterion("REGST_GAMEN_ID like", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDNotLike(String value) {
            addCriterion("REGST_GAMEN_ID not like", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDIn(List<String> values) {
            addCriterion("REGST_GAMEN_ID in", values, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDNotIn(List<String> values) {
            addCriterion("REGST_GAMEN_ID not in", values, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDBetween(String value1, String value2) {
            addCriterion("REGST_GAMEN_ID between", value1, value2, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDNotBetween(String value1, String value2) {
            addCriterion("REGST_GAMEN_ID not between", value1, value2, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDIsNull() {
            addCriterion("REGST_PGM_ID is null");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDIsNotNull() {
            addCriterion("REGST_PGM_ID is not null");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDEqualTo(String value) {
            addCriterion("REGST_PGM_ID =", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDNotEqualTo(String value) {
            addCriterion("REGST_PGM_ID <>", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDGreaterThan(String value) {
            addCriterion("REGST_PGM_ID >", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDGreaterThanOrEqualTo(String value) {
            addCriterion("REGST_PGM_ID >=", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDLessThan(String value) {
            addCriterion("REGST_PGM_ID <", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDLessThanOrEqualTo(String value) {
            addCriterion("REGST_PGM_ID <=", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDLike(String value) {
            addCriterion("REGST_PGM_ID like", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDNotLike(String value) {
            addCriterion("REGST_PGM_ID not like", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDIn(List<String> values) {
            addCriterion("REGST_PGM_ID in", values, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDNotIn(List<String> values) {
            addCriterion("REGST_PGM_ID not in", values, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDBetween(String value1, String value2) {
            addCriterion("REGST_PGM_ID between", value1, value2, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDNotBetween(String value1, String value2) {
            addCriterion("REGST_PGM_ID not between", value1, value2, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPIsNull() {
            addCriterion("UPD_TMSTMP is null");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPIsNotNull() {
            addCriterion("UPD_TMSTMP is not null");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPEqualTo(Date value) {
            addCriterion("UPD_TMSTMP =", value, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPNotEqualTo(Date value) {
            addCriterion("UPD_TMSTMP <>", value, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPGreaterThan(Date value) {
            addCriterion("UPD_TMSTMP >", value, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPGreaterThanOrEqualTo(Date value) {
            addCriterion("UPD_TMSTMP >=", value, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPLessThan(Date value) {
            addCriterion("UPD_TMSTMP <", value, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPLessThanOrEqualTo(Date value) {
            addCriterion("UPD_TMSTMP <=", value, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPIn(List<Date> values) {
            addCriterion("UPD_TMSTMP in", values, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPNotIn(List<Date> values) {
            addCriterion("UPD_TMSTMP not in", values, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPBetween(Date value1, Date value2) {
            addCriterion("UPD_TMSTMP between", value1, value2, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPNotBetween(Date value1, Date value2) {
            addCriterion("UPD_TMSTMP not between", value1, value2, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDIsNull() {
            addCriterion("UPDTR_CO_CD is null");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDIsNotNull() {
            addCriterion("UPDTR_CO_CD is not null");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDEqualTo(String value) {
            addCriterion("UPDTR_CO_CD =", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDNotEqualTo(String value) {
            addCriterion("UPDTR_CO_CD <>", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDGreaterThan(String value) {
            addCriterion("UPDTR_CO_CD >", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDTR_CO_CD >=", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDLessThan(String value) {
            addCriterion("UPDTR_CO_CD <", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDLessThanOrEqualTo(String value) {
            addCriterion("UPDTR_CO_CD <=", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDLike(String value) {
            addCriterion("UPDTR_CO_CD like", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDNotLike(String value) {
            addCriterion("UPDTR_CO_CD not like", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDIn(List<String> values) {
            addCriterion("UPDTR_CO_CD in", values, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDNotIn(List<String> values) {
            addCriterion("UPDTR_CO_CD not in", values, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDBetween(String value1, String value2) {
            addCriterion("UPDTR_CO_CD between", value1, value2, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDNotBetween(String value1, String value2) {
            addCriterion("UPDTR_CO_CD not between", value1, value2, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDIsNull() {
            addCriterion("UPDTR_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDIsNotNull() {
            addCriterion("UPDTR_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDEqualTo(String value) {
            addCriterion("UPDTR_SOSHIKI_CD =", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("UPDTR_SOSHIKI_CD <>", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("UPDTR_SOSHIKI_CD >", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDTR_SOSHIKI_CD >=", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDLessThan(String value) {
            addCriterion("UPDTR_SOSHIKI_CD <", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("UPDTR_SOSHIKI_CD <=", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDLike(String value) {
            addCriterion("UPDTR_SOSHIKI_CD like", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDNotLike(String value) {
            addCriterion("UPDTR_SOSHIKI_CD not like", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDIn(List<String> values) {
            addCriterion("UPDTR_SOSHIKI_CD in", values, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("UPDTR_SOSHIKI_CD not in", values, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("UPDTR_SOSHIKI_CD between", value1, value2, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("UPDTR_SOSHIKI_CD not between", value1, value2, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOIsNull() {
            addCriterion("UPDTR_EMP_NO is null");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOIsNotNull() {
            addCriterion("UPDTR_EMP_NO is not null");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOEqualTo(String value) {
            addCriterion("UPDTR_EMP_NO =", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NONotEqualTo(String value) {
            addCriterion("UPDTR_EMP_NO <>", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOGreaterThan(String value) {
            addCriterion("UPDTR_EMP_NO >", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOGreaterThanOrEqualTo(String value) {
            addCriterion("UPDTR_EMP_NO >=", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOLessThan(String value) {
            addCriterion("UPDTR_EMP_NO <", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOLessThanOrEqualTo(String value) {
            addCriterion("UPDTR_EMP_NO <=", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOLike(String value) {
            addCriterion("UPDTR_EMP_NO like", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NONotLike(String value) {
            addCriterion("UPDTR_EMP_NO not like", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOIn(List<String> values) {
            addCriterion("UPDTR_EMP_NO in", values, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NONotIn(List<String> values) {
            addCriterion("UPDTR_EMP_NO not in", values, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOBetween(String value1, String value2) {
            addCriterion("UPDTR_EMP_NO between", value1, value2, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NONotBetween(String value1, String value2) {
            addCriterion("UPDTR_EMP_NO not between", value1, value2, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDIsNull() {
            addCriterion("UPD_GAMEN_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDIsNotNull() {
            addCriterion("UPD_GAMEN_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDEqualTo(String value) {
            addCriterion("UPD_GAMEN_ID =", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDNotEqualTo(String value) {
            addCriterion("UPD_GAMEN_ID <>", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDGreaterThan(String value) {
            addCriterion("UPD_GAMEN_ID >", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPD_GAMEN_ID >=", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDLessThan(String value) {
            addCriterion("UPD_GAMEN_ID <", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDLessThanOrEqualTo(String value) {
            addCriterion("UPD_GAMEN_ID <=", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDLike(String value) {
            addCriterion("UPD_GAMEN_ID like", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDNotLike(String value) {
            addCriterion("UPD_GAMEN_ID not like", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDIn(List<String> values) {
            addCriterion("UPD_GAMEN_ID in", values, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDNotIn(List<String> values) {
            addCriterion("UPD_GAMEN_ID not in", values, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDBetween(String value1, String value2) {
            addCriterion("UPD_GAMEN_ID between", value1, value2, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDNotBetween(String value1, String value2) {
            addCriterion("UPD_GAMEN_ID not between", value1, value2, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDIsNull() {
            addCriterion("UPD_PGM_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDIsNotNull() {
            addCriterion("UPD_PGM_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDEqualTo(String value) {
            addCriterion("UPD_PGM_ID =", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDNotEqualTo(String value) {
            addCriterion("UPD_PGM_ID <>", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDGreaterThan(String value) {
            addCriterion("UPD_PGM_ID >", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPD_PGM_ID >=", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDLessThan(String value) {
            addCriterion("UPD_PGM_ID <", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDLessThanOrEqualTo(String value) {
            addCriterion("UPD_PGM_ID <=", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDLike(String value) {
            addCriterion("UPD_PGM_ID like", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDNotLike(String value) {
            addCriterion("UPD_PGM_ID not like", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDIn(List<String> values) {
            addCriterion("UPD_PGM_ID in", values, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDNotIn(List<String> values) {
            addCriterion("UPD_PGM_ID not in", values, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDBetween(String value1, String value2) {
            addCriterion("UPD_PGM_ID between", value1, value2, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDNotBetween(String value1, String value2) {
            addCriterion("UPD_PGM_ID not between", value1, value2, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_KEYLikeInsensitive(String value) {
            addCriterion("upper(SOSHIN_SHKBTS_KEY) like", value.toUpperCase(), "SOSHIN_SHKBTS_KEY");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_SNLikeInsensitive(String value) {
            addCriterion("upper(SOSHIN_SHKBTS_SN) like", value.toUpperCase(), "SOSHIN_SHKBTS_SN");
            return (Criteria) this;
        }

        public Criteria andSOSHIN_SHKBTS_MEISAI_SNLikeInsensitive(String value) {
            addCriterion("upper(SOSHIN_SHKBTS_MEISAI_SN) like", value.toUpperCase(), "SOSHIN_SHKBTS_MEISAI_SN");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_NOLikeInsensitive(String value) {
            addCriterion("upper(NYUSHUKKINKI_NO) like", value.toUpperCase(), "NYUSHUKKINKI_NO");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHUBETSULikeInsensitive(String value) {
            addCriterion("upper(NYUSHUKKINKI_SHUBETSU) like", value.toUpperCase(), "NYUSHUKKINKI_SHUBETSU");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_SHURUILikeInsensitive(String value) {
            addCriterion("upper(NYUSHUKKINKI_SHURUI) like", value.toUpperCase(), "NYUSHUKKINKI_SHURUI");
            return (Criteria) this;
        }

        public Criteria andCHUKO_NYUSHUKKINKI_NOLikeInsensitive(String value) {
            addCriterion("upper(CHUKO_NYUSHUKKINKI_NO) like", value.toUpperCase(), "CHUKO_NYUSHUKKINKI_NO");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_PRINTLikeInsensitive(String value) {
            addCriterion("upper(NYSHKKNK_SHD_SHM_PRINT) like", value.toUpperCase(), "NYSHKKNK_SHD_SHM_PRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_SHD_SHM_REPRINTLikeInsensitive(String value) {
            addCriterion("upper(NYSHKKNK_SHD_SHM_REPRINT) like", value.toUpperCase(), "NYSHKKNK_SHD_SHM_REPRINT");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHMLikeInsensitive(String value) {
            addCriterion("upper(NYSHKKNK_JD_SHM) like", value.toUpperCase(), "NYSHKKNK_JD_SHM");
            return (Criteria) this;
        }

        public Criteria andNYUSHUKKINKI_JIDO_SHIME_TMLikeInsensitive(String value) {
            addCriterion("upper(NYUSHUKKINKI_JIDO_SHIME_TM) like", value.toUpperCase(), "NYUSHUKKINKI_JIDO_SHIME_TM");
            return (Criteria) this;
        }

        public Criteria andNYSHKKNK_JD_SHM_PRINTLikeInsensitive(String value) {
            addCriterion("upper(NYSHKKNK_JD_SHM_PRINT) like", value.toUpperCase(), "NYSHKKNK_JD_SHM_PRINT");
            return (Criteria) this;
        }

        public Criteria andNSKKNK_SM_REGI_BTLikeInsensitive(String value) {
            addCriterion("upper(NSKKNK_SM_REGI_BT) like", value.toUpperCase(), "NSKKNK_SM_REGI_BT");
            return (Criteria) this;
        }

        public Criteria andKAISEN_SHUBETSULikeInsensitive(String value) {
            addCriterion("upper(KAISEN_SHUBETSU) like", value.toUpperCase(), "KAISEN_SHUBETSU");
            return (Criteria) this;
        }

        public Criteria andMAIN_KAISEN_IP_ADDRESSLikeInsensitive(String value) {
            addCriterion("upper(MAIN_KAISEN_IP_ADDRESS) like", value.toUpperCase(), "MAIN_KAISEN_IP_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_01) like", value.toUpperCase(), "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_02) like", value.toUpperCase(), "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_03) like", value.toUpperCase(), "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_04) like", value.toUpperCase(), "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_05) like", value.toUpperCase(), "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_06) like", value.toUpperCase(), "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_07) like", value.toUpperCase(), "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_08) like", value.toUpperCase(), "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_09) like", value.toUpperCase(), "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_10) like", value.toUpperCase(), "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDLikeInsensitive(String value) {
            addCriterion("upper(REGSTR_CO_CD) like", value.toUpperCase(), "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(REGSTR_SOSHIKI_CD) like", value.toUpperCase(), "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOLikeInsensitive(String value) {
            addCriterion("upper(REGSTR_EMP_NO) like", value.toUpperCase(), "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDLikeInsensitive(String value) {
            addCriterion("upper(REGST_GAMEN_ID) like", value.toUpperCase(), "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDLikeInsensitive(String value) {
            addCriterion("upper(REGST_PGM_ID) like", value.toUpperCase(), "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDLikeInsensitive(String value) {
            addCriterion("upper(UPDTR_CO_CD) like", value.toUpperCase(), "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(UPDTR_SOSHIKI_CD) like", value.toUpperCase(), "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOLikeInsensitive(String value) {
            addCriterion("upper(UPDTR_EMP_NO) like", value.toUpperCase(), "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDLikeInsensitive(String value) {
            addCriterion("upper(UPD_GAMEN_ID) like", value.toUpperCase(), "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDLikeInsensitive(String value) {
            addCriterion("upper(UPD_PGM_ID) like", value.toUpperCase(), "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * C_EIGYO_NYUSYUKIN
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * C_EIGYO_NYUSYUKIN null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}