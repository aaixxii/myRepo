package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class ERakuJianDev implements Serializable {
    /**
     * LN_事案論理番号
     */
    private String LN_JIAN;

    /**
     * LN_上位接続装置論理番号
     */
    private String LN_UPPER_CONENCT_DEV;

    /**
     * LN_物件論理番号
     */
    private String LN_BUKKEN;

    /**
     * 機器バージョン
     */
    private String DEV_VERSION;

    /**
     * 機器製造番号
     */
    private String DEV_SERIAL_NUM;

    /**
     * 機器型式(OPT)
     */
    private String DEV_MODEL;

    /**
     * 機器名称
     */
    private String DEV_NM;

    /**
     * 機器種別ID
     */
    private String DEV_KIND_ID;

    /**
     * 警備地区
     */
    private String CHIKU;

    /**
     * 装置番号
     */
    private String DEV_NUM;

    /**
     * センサーグループ番号
     */
    private String SD_SENSOR_GRP_NUM;

    /**
     * SD.周辺機器番号
     */
    private String SD_SYUHEN_NUM;

    /**
     * SD.新伝送アドレス
     */
    private String SD_SINDENSOU_ADDR;

    /**
     * SD.スピーカ有無
     */
    private String SD_SPEAKER_FLG;

    /**
     * 接点番号
     */
    private String SETTEN_NUM;

    /**
     * ポート番号01
     */
    private String PORT01;

    /**
     * ポート番号02
     */
    private String PORT02;

    /**
     * ポート番号03
     */
    private String PORT03;

    /**
     * ポート番号04
     */
    private String PORT04;

    /**
     * ポート番号05
     */
    private String PORT05;

    /**
     * ポート番号06
     */
    private String PORT06;

    /**
     * ポート番号07
     */
    private String PORT07;

    /**
     * ポート番号08
     */
    private String PORT08;

    /**
     * ポート番号09
     */
    private String PORT09;

    /**
     * ポート番号10
     */
    private String PORT10;

    /**
     * ポート番号11
     */
    private String PORT11;

    /**
     * ポート番号12
     */
    private String PORT12;

    /**
     * ポート番号13
     */
    private String PORT13;

    /**
     * ポート番号14
     */
    private String PORT14;

    /**
     * ポート番号15
     */
    private String PORT15;

    /**
     * ポート番号16
     */
    private String PORT16;

    /**
     * ポート番号17
     */
    private String PORT17;

    /**
     * ポート番号18
     */
    private String PORT18;

    /**
     * ポート番号19
     */
    private String PORT19;

    /**
     * ポート番号20
     */
    private String PORT20;

    /**
     * ポート番号21
     */
    private String PORT21;

    /**
     * ポート番号22
     */
    private String PORT22;

    /**
     * ポート番号23
     */
    private String PORT23;

    /**
     * ポート番号24
     */
    private String PORT24;

    /**
     * ポート番号25
     */
    private String PORT25;

    /**
     * ポート番号26
     */
    private String PORT26;

    /**
     * ポート番号27
     */
    private String PORT27;

    /**
     * ポート番号28
     */
    private String PORT28;

    /**
     * ポート番号29
     */
    private String PORT29;

    /**
     * ポート番号30
     */
    private String PORT30;

    /**
     * ポート番号31
     */
    private String PORT31;

    /**
     * ポート番号32
     */
    private String PORT32;

    /**
     * FTPユーザ
     */
    private String FTP_USER;

    /**
     * FTPパスワード
     */
    private String FTP_PW;

    /**
     * 機器設置日時
     */
    private Date KIKI_SETTI_TS;

    /**
     * 機器交換日時
     */
    private Date KIKI_CNG_TS;

    /**
     * 機器交換周期情報
     */
    private String KIKI_CNG_SYUUKI;

    /**
     * 機器交換予定日時情報
     */
    private Date KIKI_CNG_YOTEI;

    /**
     * リモメン有効無効フラグ
     */
    private String RM_YUUKOU_FLG;

    /**
     * LN_設置機器グループ論理番号
     */
    private String LN_DEV_GROUP;

    /**
     * 遠隔制御有効フラグ
     */
    private String RMT_FLG;

    /**
     * 遠隔制御可能時間帯
     */
    private String RMT_ENABLE_TIME;

    /**
     * 遠隔制御機器名
     */
    private String RMT_DEV_NM;

    /**
     * 遠隔制御ON名称
     */
    private String RMT_ON_NM;

    /**
     * 遠隔制御OFF名称
     */
    private String RMT_OFF_NM;

    /**
     * KBI番号
     */
    private String KBI_NUM;

    /**
     * 操作種別
     */
    private String SOUSA_KIND;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * E_RAKU_JIAN_DEV
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_事案論理番号
     * @return LN_JIAN LN_事案論理番号
     */
    public String getLN_JIAN() {
        return LN_JIAN;
    }

    /**
     * LN_事案論理番号
     * @param LN_JIAN LN_事案論理番号
     */
    public void setLN_JIAN(String LN_JIAN) {
        this.LN_JIAN = LN_JIAN == null ? null : LN_JIAN.trim();
    }

    /**
     * LN_上位接続装置論理番号
     * @return LN_UPPER_CONENCT_DEV LN_上位接続装置論理番号
     */
    public String getLN_UPPER_CONENCT_DEV() {
        return LN_UPPER_CONENCT_DEV;
    }

    /**
     * LN_上位接続装置論理番号
     * @param LN_UPPER_CONENCT_DEV LN_上位接続装置論理番号
     */
    public void setLN_UPPER_CONENCT_DEV(String LN_UPPER_CONENCT_DEV) {
        this.LN_UPPER_CONENCT_DEV = LN_UPPER_CONENCT_DEV == null ? null : LN_UPPER_CONENCT_DEV.trim();
    }

    /**
     * LN_物件論理番号
     * @return LN_BUKKEN LN_物件論理番号
     */
    public String getLN_BUKKEN() {
        return LN_BUKKEN;
    }

    /**
     * LN_物件論理番号
     * @param LN_BUKKEN LN_物件論理番号
     */
    public void setLN_BUKKEN(String LN_BUKKEN) {
        this.LN_BUKKEN = LN_BUKKEN == null ? null : LN_BUKKEN.trim();
    }

    /**
     * 機器バージョン
     * @return DEV_VERSION 機器バージョン
     */
    public String getDEV_VERSION() {
        return DEV_VERSION;
    }

    /**
     * 機器バージョン
     * @param DEV_VERSION 機器バージョン
     */
    public void setDEV_VERSION(String DEV_VERSION) {
        this.DEV_VERSION = DEV_VERSION == null ? null : DEV_VERSION.trim();
    }

    /**
     * 機器製造番号
     * @return DEV_SERIAL_NUM 機器製造番号
     */
    public String getDEV_SERIAL_NUM() {
        return DEV_SERIAL_NUM;
    }

    /**
     * 機器製造番号
     * @param DEV_SERIAL_NUM 機器製造番号
     */
    public void setDEV_SERIAL_NUM(String DEV_SERIAL_NUM) {
        this.DEV_SERIAL_NUM = DEV_SERIAL_NUM == null ? null : DEV_SERIAL_NUM.trim();
    }

    /**
     * 機器型式(OPT)
     * @return DEV_MODEL 機器型式(OPT)
     */
    public String getDEV_MODEL() {
        return DEV_MODEL;
    }

    /**
     * 機器型式(OPT)
     * @param DEV_MODEL 機器型式(OPT)
     */
    public void setDEV_MODEL(String DEV_MODEL) {
        this.DEV_MODEL = DEV_MODEL == null ? null : DEV_MODEL.trim();
    }

    /**
     * 機器名称
     * @return DEV_NM 機器名称
     */
    public String getDEV_NM() {
        return DEV_NM;
    }

    /**
     * 機器名称
     * @param DEV_NM 機器名称
     */
    public void setDEV_NM(String DEV_NM) {
        this.DEV_NM = DEV_NM == null ? null : DEV_NM.trim();
    }

    /**
     * 機器種別ID
     * @return DEV_KIND_ID 機器種別ID
     */
    public String getDEV_KIND_ID() {
        return DEV_KIND_ID;
    }

    /**
     * 機器種別ID
     * @param DEV_KIND_ID 機器種別ID
     */
    public void setDEV_KIND_ID(String DEV_KIND_ID) {
        this.DEV_KIND_ID = DEV_KIND_ID == null ? null : DEV_KIND_ID.trim();
    }

    /**
     * 警備地区
     * @return CHIKU 警備地区
     */
    public String getCHIKU() {
        return CHIKU;
    }

    /**
     * 警備地区
     * @param CHIKU 警備地区
     */
    public void setCHIKU(String CHIKU) {
        this.CHIKU = CHIKU == null ? null : CHIKU.trim();
    }

    /**
     * 装置番号
     * @return DEV_NUM 装置番号
     */
    public String getDEV_NUM() {
        return DEV_NUM;
    }

    /**
     * 装置番号
     * @param DEV_NUM 装置番号
     */
    public void setDEV_NUM(String DEV_NUM) {
        this.DEV_NUM = DEV_NUM == null ? null : DEV_NUM.trim();
    }

    /**
     * センサーグループ番号
     * @return SD_SENSOR_GRP_NUM センサーグループ番号
     */
    public String getSD_SENSOR_GRP_NUM() {
        return SD_SENSOR_GRP_NUM;
    }

    /**
     * センサーグループ番号
     * @param SD_SENSOR_GRP_NUM センサーグループ番号
     */
    public void setSD_SENSOR_GRP_NUM(String SD_SENSOR_GRP_NUM) {
        this.SD_SENSOR_GRP_NUM = SD_SENSOR_GRP_NUM == null ? null : SD_SENSOR_GRP_NUM.trim();
    }

    /**
     * SD.周辺機器番号
     * @return SD_SYUHEN_NUM SD.周辺機器番号
     */
    public String getSD_SYUHEN_NUM() {
        return SD_SYUHEN_NUM;
    }

    /**
     * SD.周辺機器番号
     * @param SD_SYUHEN_NUM SD.周辺機器番号
     */
    public void setSD_SYUHEN_NUM(String SD_SYUHEN_NUM) {
        this.SD_SYUHEN_NUM = SD_SYUHEN_NUM == null ? null : SD_SYUHEN_NUM.trim();
    }

    /**
     * SD.新伝送アドレス
     * @return SD_SINDENSOU_ADDR SD.新伝送アドレス
     */
    public String getSD_SINDENSOU_ADDR() {
        return SD_SINDENSOU_ADDR;
    }

    /**
     * SD.新伝送アドレス
     * @param SD_SINDENSOU_ADDR SD.新伝送アドレス
     */
    public void setSD_SINDENSOU_ADDR(String SD_SINDENSOU_ADDR) {
        this.SD_SINDENSOU_ADDR = SD_SINDENSOU_ADDR == null ? null : SD_SINDENSOU_ADDR.trim();
    }

    /**
     * SD.スピーカ有無
     * @return SD_SPEAKER_FLG SD.スピーカ有無
     */
    public String getSD_SPEAKER_FLG() {
        return SD_SPEAKER_FLG;
    }

    /**
     * SD.スピーカ有無
     * @param SD_SPEAKER_FLG SD.スピーカ有無
     */
    public void setSD_SPEAKER_FLG(String SD_SPEAKER_FLG) {
        this.SD_SPEAKER_FLG = SD_SPEAKER_FLG == null ? null : SD_SPEAKER_FLG.trim();
    }

    /**
     * 接点番号
     * @return SETTEN_NUM 接点番号
     */
    public String getSETTEN_NUM() {
        return SETTEN_NUM;
    }

    /**
     * 接点番号
     * @param SETTEN_NUM 接点番号
     */
    public void setSETTEN_NUM(String SETTEN_NUM) {
        this.SETTEN_NUM = SETTEN_NUM == null ? null : SETTEN_NUM.trim();
    }

    /**
     * ポート番号01
     * @return PORT01 ポート番号01
     */
    public String getPORT01() {
        return PORT01;
    }

    /**
     * ポート番号01
     * @param PORT01 ポート番号01
     */
    public void setPORT01(String PORT01) {
        this.PORT01 = PORT01 == null ? null : PORT01.trim();
    }

    /**
     * ポート番号02
     * @return PORT02 ポート番号02
     */
    public String getPORT02() {
        return PORT02;
    }

    /**
     * ポート番号02
     * @param PORT02 ポート番号02
     */
    public void setPORT02(String PORT02) {
        this.PORT02 = PORT02 == null ? null : PORT02.trim();
    }

    /**
     * ポート番号03
     * @return PORT03 ポート番号03
     */
    public String getPORT03() {
        return PORT03;
    }

    /**
     * ポート番号03
     * @param PORT03 ポート番号03
     */
    public void setPORT03(String PORT03) {
        this.PORT03 = PORT03 == null ? null : PORT03.trim();
    }

    /**
     * ポート番号04
     * @return PORT04 ポート番号04
     */
    public String getPORT04() {
        return PORT04;
    }

    /**
     * ポート番号04
     * @param PORT04 ポート番号04
     */
    public void setPORT04(String PORT04) {
        this.PORT04 = PORT04 == null ? null : PORT04.trim();
    }

    /**
     * ポート番号05
     * @return PORT05 ポート番号05
     */
    public String getPORT05() {
        return PORT05;
    }

    /**
     * ポート番号05
     * @param PORT05 ポート番号05
     */
    public void setPORT05(String PORT05) {
        this.PORT05 = PORT05 == null ? null : PORT05.trim();
    }

    /**
     * ポート番号06
     * @return PORT06 ポート番号06
     */
    public String getPORT06() {
        return PORT06;
    }

    /**
     * ポート番号06
     * @param PORT06 ポート番号06
     */
    public void setPORT06(String PORT06) {
        this.PORT06 = PORT06 == null ? null : PORT06.trim();
    }

    /**
     * ポート番号07
     * @return PORT07 ポート番号07
     */
    public String getPORT07() {
        return PORT07;
    }

    /**
     * ポート番号07
     * @param PORT07 ポート番号07
     */
    public void setPORT07(String PORT07) {
        this.PORT07 = PORT07 == null ? null : PORT07.trim();
    }

    /**
     * ポート番号08
     * @return PORT08 ポート番号08
     */
    public String getPORT08() {
        return PORT08;
    }

    /**
     * ポート番号08
     * @param PORT08 ポート番号08
     */
    public void setPORT08(String PORT08) {
        this.PORT08 = PORT08 == null ? null : PORT08.trim();
    }

    /**
     * ポート番号09
     * @return PORT09 ポート番号09
     */
    public String getPORT09() {
        return PORT09;
    }

    /**
     * ポート番号09
     * @param PORT09 ポート番号09
     */
    public void setPORT09(String PORT09) {
        this.PORT09 = PORT09 == null ? null : PORT09.trim();
    }

    /**
     * ポート番号10
     * @return PORT10 ポート番号10
     */
    public String getPORT10() {
        return PORT10;
    }

    /**
     * ポート番号10
     * @param PORT10 ポート番号10
     */
    public void setPORT10(String PORT10) {
        this.PORT10 = PORT10 == null ? null : PORT10.trim();
    }

    /**
     * ポート番号11
     * @return PORT11 ポート番号11
     */
    public String getPORT11() {
        return PORT11;
    }

    /**
     * ポート番号11
     * @param PORT11 ポート番号11
     */
    public void setPORT11(String PORT11) {
        this.PORT11 = PORT11 == null ? null : PORT11.trim();
    }

    /**
     * ポート番号12
     * @return PORT12 ポート番号12
     */
    public String getPORT12() {
        return PORT12;
    }

    /**
     * ポート番号12
     * @param PORT12 ポート番号12
     */
    public void setPORT12(String PORT12) {
        this.PORT12 = PORT12 == null ? null : PORT12.trim();
    }

    /**
     * ポート番号13
     * @return PORT13 ポート番号13
     */
    public String getPORT13() {
        return PORT13;
    }

    /**
     * ポート番号13
     * @param PORT13 ポート番号13
     */
    public void setPORT13(String PORT13) {
        this.PORT13 = PORT13 == null ? null : PORT13.trim();
    }

    /**
     * ポート番号14
     * @return PORT14 ポート番号14
     */
    public String getPORT14() {
        return PORT14;
    }

    /**
     * ポート番号14
     * @param PORT14 ポート番号14
     */
    public void setPORT14(String PORT14) {
        this.PORT14 = PORT14 == null ? null : PORT14.trim();
    }

    /**
     * ポート番号15
     * @return PORT15 ポート番号15
     */
    public String getPORT15() {
        return PORT15;
    }

    /**
     * ポート番号15
     * @param PORT15 ポート番号15
     */
    public void setPORT15(String PORT15) {
        this.PORT15 = PORT15 == null ? null : PORT15.trim();
    }

    /**
     * ポート番号16
     * @return PORT16 ポート番号16
     */
    public String getPORT16() {
        return PORT16;
    }

    /**
     * ポート番号16
     * @param PORT16 ポート番号16
     */
    public void setPORT16(String PORT16) {
        this.PORT16 = PORT16 == null ? null : PORT16.trim();
    }

    /**
     * ポート番号17
     * @return PORT17 ポート番号17
     */
    public String getPORT17() {
        return PORT17;
    }

    /**
     * ポート番号17
     * @param PORT17 ポート番号17
     */
    public void setPORT17(String PORT17) {
        this.PORT17 = PORT17 == null ? null : PORT17.trim();
    }

    /**
     * ポート番号18
     * @return PORT18 ポート番号18
     */
    public String getPORT18() {
        return PORT18;
    }

    /**
     * ポート番号18
     * @param PORT18 ポート番号18
     */
    public void setPORT18(String PORT18) {
        this.PORT18 = PORT18 == null ? null : PORT18.trim();
    }

    /**
     * ポート番号19
     * @return PORT19 ポート番号19
     */
    public String getPORT19() {
        return PORT19;
    }

    /**
     * ポート番号19
     * @param PORT19 ポート番号19
     */
    public void setPORT19(String PORT19) {
        this.PORT19 = PORT19 == null ? null : PORT19.trim();
    }

    /**
     * ポート番号20
     * @return PORT20 ポート番号20
     */
    public String getPORT20() {
        return PORT20;
    }

    /**
     * ポート番号20
     * @param PORT20 ポート番号20
     */
    public void setPORT20(String PORT20) {
        this.PORT20 = PORT20 == null ? null : PORT20.trim();
    }

    /**
     * ポート番号21
     * @return PORT21 ポート番号21
     */
    public String getPORT21() {
        return PORT21;
    }

    /**
     * ポート番号21
     * @param PORT21 ポート番号21
     */
    public void setPORT21(String PORT21) {
        this.PORT21 = PORT21 == null ? null : PORT21.trim();
    }

    /**
     * ポート番号22
     * @return PORT22 ポート番号22
     */
    public String getPORT22() {
        return PORT22;
    }

    /**
     * ポート番号22
     * @param PORT22 ポート番号22
     */
    public void setPORT22(String PORT22) {
        this.PORT22 = PORT22 == null ? null : PORT22.trim();
    }

    /**
     * ポート番号23
     * @return PORT23 ポート番号23
     */
    public String getPORT23() {
        return PORT23;
    }

    /**
     * ポート番号23
     * @param PORT23 ポート番号23
     */
    public void setPORT23(String PORT23) {
        this.PORT23 = PORT23 == null ? null : PORT23.trim();
    }

    /**
     * ポート番号24
     * @return PORT24 ポート番号24
     */
    public String getPORT24() {
        return PORT24;
    }

    /**
     * ポート番号24
     * @param PORT24 ポート番号24
     */
    public void setPORT24(String PORT24) {
        this.PORT24 = PORT24 == null ? null : PORT24.trim();
    }

    /**
     * ポート番号25
     * @return PORT25 ポート番号25
     */
    public String getPORT25() {
        return PORT25;
    }

    /**
     * ポート番号25
     * @param PORT25 ポート番号25
     */
    public void setPORT25(String PORT25) {
        this.PORT25 = PORT25 == null ? null : PORT25.trim();
    }

    /**
     * ポート番号26
     * @return PORT26 ポート番号26
     */
    public String getPORT26() {
        return PORT26;
    }

    /**
     * ポート番号26
     * @param PORT26 ポート番号26
     */
    public void setPORT26(String PORT26) {
        this.PORT26 = PORT26 == null ? null : PORT26.trim();
    }

    /**
     * ポート番号27
     * @return PORT27 ポート番号27
     */
    public String getPORT27() {
        return PORT27;
    }

    /**
     * ポート番号27
     * @param PORT27 ポート番号27
     */
    public void setPORT27(String PORT27) {
        this.PORT27 = PORT27 == null ? null : PORT27.trim();
    }

    /**
     * ポート番号28
     * @return PORT28 ポート番号28
     */
    public String getPORT28() {
        return PORT28;
    }

    /**
     * ポート番号28
     * @param PORT28 ポート番号28
     */
    public void setPORT28(String PORT28) {
        this.PORT28 = PORT28 == null ? null : PORT28.trim();
    }

    /**
     * ポート番号29
     * @return PORT29 ポート番号29
     */
    public String getPORT29() {
        return PORT29;
    }

    /**
     * ポート番号29
     * @param PORT29 ポート番号29
     */
    public void setPORT29(String PORT29) {
        this.PORT29 = PORT29 == null ? null : PORT29.trim();
    }

    /**
     * ポート番号30
     * @return PORT30 ポート番号30
     */
    public String getPORT30() {
        return PORT30;
    }

    /**
     * ポート番号30
     * @param PORT30 ポート番号30
     */
    public void setPORT30(String PORT30) {
        this.PORT30 = PORT30 == null ? null : PORT30.trim();
    }

    /**
     * ポート番号31
     * @return PORT31 ポート番号31
     */
    public String getPORT31() {
        return PORT31;
    }

    /**
     * ポート番号31
     * @param PORT31 ポート番号31
     */
    public void setPORT31(String PORT31) {
        this.PORT31 = PORT31 == null ? null : PORT31.trim();
    }

    /**
     * ポート番号32
     * @return PORT32 ポート番号32
     */
    public String getPORT32() {
        return PORT32;
    }

    /**
     * ポート番号32
     * @param PORT32 ポート番号32
     */
    public void setPORT32(String PORT32) {
        this.PORT32 = PORT32 == null ? null : PORT32.trim();
    }

    /**
     * FTPユーザ
     * @return FTP_USER FTPユーザ
     */
    public String getFTP_USER() {
        return FTP_USER;
    }

    /**
     * FTPユーザ
     * @param FTP_USER FTPユーザ
     */
    public void setFTP_USER(String FTP_USER) {
        this.FTP_USER = FTP_USER == null ? null : FTP_USER.trim();
    }

    /**
     * FTPパスワード
     * @return FTP_PW FTPパスワード
     */
    public String getFTP_PW() {
        return FTP_PW;
    }

    /**
     * FTPパスワード
     * @param FTP_PW FTPパスワード
     */
    public void setFTP_PW(String FTP_PW) {
        this.FTP_PW = FTP_PW == null ? null : FTP_PW.trim();
    }

    /**
     * 機器設置日時
     * @return KIKI_SETTI_TS 機器設置日時
     */
    public Date getKIKI_SETTI_TS() {
        return KIKI_SETTI_TS;
    }

    /**
     * 機器設置日時
     * @param KIKI_SETTI_TS 機器設置日時
     */
    public void setKIKI_SETTI_TS(Date KIKI_SETTI_TS) {
        this.KIKI_SETTI_TS = KIKI_SETTI_TS;
    }

    /**
     * 機器交換日時
     * @return KIKI_CNG_TS 機器交換日時
     */
    public Date getKIKI_CNG_TS() {
        return KIKI_CNG_TS;
    }

    /**
     * 機器交換日時
     * @param KIKI_CNG_TS 機器交換日時
     */
    public void setKIKI_CNG_TS(Date KIKI_CNG_TS) {
        this.KIKI_CNG_TS = KIKI_CNG_TS;
    }

    /**
     * 機器交換周期情報
     * @return KIKI_CNG_SYUUKI 機器交換周期情報
     */
    public String getKIKI_CNG_SYUUKI() {
        return KIKI_CNG_SYUUKI;
    }

    /**
     * 機器交換周期情報
     * @param KIKI_CNG_SYUUKI 機器交換周期情報
     */
    public void setKIKI_CNG_SYUUKI(String KIKI_CNG_SYUUKI) {
        this.KIKI_CNG_SYUUKI = KIKI_CNG_SYUUKI == null ? null : KIKI_CNG_SYUUKI.trim();
    }

    /**
     * 機器交換予定日時情報
     * @return KIKI_CNG_YOTEI 機器交換予定日時情報
     */
    public Date getKIKI_CNG_YOTEI() {
        return KIKI_CNG_YOTEI;
    }

    /**
     * 機器交換予定日時情報
     * @param KIKI_CNG_YOTEI 機器交換予定日時情報
     */
    public void setKIKI_CNG_YOTEI(Date KIKI_CNG_YOTEI) {
        this.KIKI_CNG_YOTEI = KIKI_CNG_YOTEI;
    }

    /**
     * リモメン有効無効フラグ
     * @return RM_YUUKOU_FLG リモメン有効無効フラグ
     */
    public String getRM_YUUKOU_FLG() {
        return RM_YUUKOU_FLG;
    }

    /**
     * リモメン有効無効フラグ
     * @param RM_YUUKOU_FLG リモメン有効無効フラグ
     */
    public void setRM_YUUKOU_FLG(String RM_YUUKOU_FLG) {
        this.RM_YUUKOU_FLG = RM_YUUKOU_FLG == null ? null : RM_YUUKOU_FLG.trim();
    }

    /**
     * LN_設置機器グループ論理番号
     * @return LN_DEV_GROUP LN_設置機器グループ論理番号
     */
    public String getLN_DEV_GROUP() {
        return LN_DEV_GROUP;
    }

    /**
     * LN_設置機器グループ論理番号
     * @param LN_DEV_GROUP LN_設置機器グループ論理番号
     */
    public void setLN_DEV_GROUP(String LN_DEV_GROUP) {
        this.LN_DEV_GROUP = LN_DEV_GROUP == null ? null : LN_DEV_GROUP.trim();
    }

    /**
     * 遠隔制御有効フラグ
     * @return RMT_FLG 遠隔制御有効フラグ
     */
    public String getRMT_FLG() {
        return RMT_FLG;
    }

    /**
     * 遠隔制御有効フラグ
     * @param RMT_FLG 遠隔制御有効フラグ
     */
    public void setRMT_FLG(String RMT_FLG) {
        this.RMT_FLG = RMT_FLG == null ? null : RMT_FLG.trim();
    }

    /**
     * 遠隔制御可能時間帯
     * @return RMT_ENABLE_TIME 遠隔制御可能時間帯
     */
    public String getRMT_ENABLE_TIME() {
        return RMT_ENABLE_TIME;
    }

    /**
     * 遠隔制御可能時間帯
     * @param RMT_ENABLE_TIME 遠隔制御可能時間帯
     */
    public void setRMT_ENABLE_TIME(String RMT_ENABLE_TIME) {
        this.RMT_ENABLE_TIME = RMT_ENABLE_TIME == null ? null : RMT_ENABLE_TIME.trim();
    }

    /**
     * 遠隔制御機器名
     * @return RMT_DEV_NM 遠隔制御機器名
     */
    public String getRMT_DEV_NM() {
        return RMT_DEV_NM;
    }

    /**
     * 遠隔制御機器名
     * @param RMT_DEV_NM 遠隔制御機器名
     */
    public void setRMT_DEV_NM(String RMT_DEV_NM) {
        this.RMT_DEV_NM = RMT_DEV_NM == null ? null : RMT_DEV_NM.trim();
    }

    /**
     * 遠隔制御ON名称
     * @return RMT_ON_NM 遠隔制御ON名称
     */
    public String getRMT_ON_NM() {
        return RMT_ON_NM;
    }

    /**
     * 遠隔制御ON名称
     * @param RMT_ON_NM 遠隔制御ON名称
     */
    public void setRMT_ON_NM(String RMT_ON_NM) {
        this.RMT_ON_NM = RMT_ON_NM == null ? null : RMT_ON_NM.trim();
    }

    /**
     * 遠隔制御OFF名称
     * @return RMT_OFF_NM 遠隔制御OFF名称
     */
    public String getRMT_OFF_NM() {
        return RMT_OFF_NM;
    }

    /**
     * 遠隔制御OFF名称
     * @param RMT_OFF_NM 遠隔制御OFF名称
     */
    public void setRMT_OFF_NM(String RMT_OFF_NM) {
        this.RMT_OFF_NM = RMT_OFF_NM == null ? null : RMT_OFF_NM.trim();
    }

    /**
     * KBI番号
     * @return KBI_NUM KBI番号
     */
    public String getKBI_NUM() {
        return KBI_NUM;
    }

    /**
     * KBI番号
     * @param KBI_NUM KBI番号
     */
    public void setKBI_NUM(String KBI_NUM) {
        this.KBI_NUM = KBI_NUM == null ? null : KBI_NUM.trim();
    }

    /**
     * 操作種別
     * @return SOUSA_KIND 操作種別
     */
    public String getSOUSA_KIND() {
        return SOUSA_KIND;
    }

    /**
     * 操作種別
     * @param SOUSA_KIND 操作種別
     */
    public void setSOUSA_KIND(String SOUSA_KIND) {
        this.SOUSA_KIND = SOUSA_KIND == null ? null : SOUSA_KIND.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}