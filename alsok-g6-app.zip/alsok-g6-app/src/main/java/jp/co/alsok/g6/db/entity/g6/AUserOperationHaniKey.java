package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class AUserOperationHaniKey implements Serializable {
    /**
     * LN_利用者アカウント共通論理番号
     */
    private String LN_ACNT_USER_COMMON;

    /**
     * パス情報
     */
    private String PATH_INF;

    /**
     * A_USER_OPERATION_HANI
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_利用者アカウント共通論理番号
     * @return LN_ACNT_USER_COMMON LN_利用者アカウント共通論理番号
     */
    public String getLN_ACNT_USER_COMMON() {
        return LN_ACNT_USER_COMMON;
    }

    /**
     * LN_利用者アカウント共通論理番号
     * @param LN_ACNT_USER_COMMON LN_利用者アカウント共通論理番号
     */
    public void setLN_ACNT_USER_COMMON(String LN_ACNT_USER_COMMON) {
        this.LN_ACNT_USER_COMMON = LN_ACNT_USER_COMMON == null ? null : LN_ACNT_USER_COMMON.trim();
    }

    /**
     * パス情報
     * @return PATH_INF パス情報
     */
    public String getPATH_INF() {
        return PATH_INF;
    }

    /**
     * パス情報
     * @param PATH_INF パス情報
     */
    public void setPATH_INF(String PATH_INF) {
        this.PATH_INF = PATH_INF == null ? null : PATH_INF.trim();
    }
}