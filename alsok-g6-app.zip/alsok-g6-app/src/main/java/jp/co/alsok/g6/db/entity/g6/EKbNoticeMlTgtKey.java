package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class EKbNoticeMlTgtKey implements Serializable {
    /**
     * LN_警備お知らせ論理番号
     */
    private String LN_KB_NOTICE;

    /**
     * LN_利用者アカウント共通論理番号
     */
    private String LN_ACNT_USER_COMMON;

    /**
     * E_KB_NOTICE_ML_TGT
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_警備お知らせ論理番号
     * @return LN_KB_NOTICE LN_警備お知らせ論理番号
     */
    public String getLN_KB_NOTICE() {
        return LN_KB_NOTICE;
    }

    /**
     * LN_警備お知らせ論理番号
     * @param LN_KB_NOTICE LN_警備お知らせ論理番号
     */
    public void setLN_KB_NOTICE(String LN_KB_NOTICE) {
        this.LN_KB_NOTICE = LN_KB_NOTICE == null ? null : LN_KB_NOTICE.trim();
    }

    /**
     * LN_利用者アカウント共通論理番号
     * @return LN_ACNT_USER_COMMON LN_利用者アカウント共通論理番号
     */
    public String getLN_ACNT_USER_COMMON() {
        return LN_ACNT_USER_COMMON;
    }

    /**
     * LN_利用者アカウント共通論理番号
     * @param LN_ACNT_USER_COMMON LN_利用者アカウント共通論理番号
     */
    public void setLN_ACNT_USER_COMMON(String LN_ACNT_USER_COMMON) {
        this.LN_ACNT_USER_COMMON = LN_ACNT_USER_COMMON == null ? null : LN_ACNT_USER_COMMON.trim();
    }
}