package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.List;

public class MCtlDevLineInfExample {
    /**
     * M_CTL_DEV_LINE_INF
     */
    protected String orderByClause;

    /**
     * M_CTL_DEV_LINE_INF
     */
    protected boolean distinct;

    /**
     * M_CTL_DEV_LINE_INF
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public MCtlDevLineInfExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * M_CTL_DEV_LINE_INF null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_CTL_DEVIsNull() {
            addCriterion("LN_CTL_DEV is null");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_DEVIsNotNull() {
            addCriterion("LN_CTL_DEV is not null");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_DEVEqualTo(String value) {
            addCriterion("LN_CTL_DEV =", value, "LN_CTL_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_DEVNotEqualTo(String value) {
            addCriterion("LN_CTL_DEV <>", value, "LN_CTL_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_DEVGreaterThan(String value) {
            addCriterion("LN_CTL_DEV >", value, "LN_CTL_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_DEVGreaterThanOrEqualTo(String value) {
            addCriterion("LN_CTL_DEV >=", value, "LN_CTL_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_DEVLessThan(String value) {
            addCriterion("LN_CTL_DEV <", value, "LN_CTL_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_DEVLessThanOrEqualTo(String value) {
            addCriterion("LN_CTL_DEV <=", value, "LN_CTL_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_DEVLike(String value) {
            addCriterion("LN_CTL_DEV like", value, "LN_CTL_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_DEVNotLike(String value) {
            addCriterion("LN_CTL_DEV not like", value, "LN_CTL_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_DEVIn(List<String> values) {
            addCriterion("LN_CTL_DEV in", values, "LN_CTL_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_DEVNotIn(List<String> values) {
            addCriterion("LN_CTL_DEV not in", values, "LN_CTL_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_DEVBetween(String value1, String value2) {
            addCriterion("LN_CTL_DEV between", value1, value2, "LN_CTL_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_DEVNotBetween(String value1, String value2) {
            addCriterion("LN_CTL_DEV not between", value1, value2, "LN_CTL_DEV");
            return (Criteria) this;
        }

        public Criteria andLINE_FLGIsNull() {
            addCriterion("LINE_FLG is null");
            return (Criteria) this;
        }

        public Criteria andLINE_FLGIsNotNull() {
            addCriterion("LINE_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andLINE_FLGEqualTo(String value) {
            addCriterion("LINE_FLG =", value, "LINE_FLG");
            return (Criteria) this;
        }

        public Criteria andLINE_FLGNotEqualTo(String value) {
            addCriterion("LINE_FLG <>", value, "LINE_FLG");
            return (Criteria) this;
        }

        public Criteria andLINE_FLGGreaterThan(String value) {
            addCriterion("LINE_FLG >", value, "LINE_FLG");
            return (Criteria) this;
        }

        public Criteria andLINE_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("LINE_FLG >=", value, "LINE_FLG");
            return (Criteria) this;
        }

        public Criteria andLINE_FLGLessThan(String value) {
            addCriterion("LINE_FLG <", value, "LINE_FLG");
            return (Criteria) this;
        }

        public Criteria andLINE_FLGLessThanOrEqualTo(String value) {
            addCriterion("LINE_FLG <=", value, "LINE_FLG");
            return (Criteria) this;
        }

        public Criteria andLINE_FLGLike(String value) {
            addCriterion("LINE_FLG like", value, "LINE_FLG");
            return (Criteria) this;
        }

        public Criteria andLINE_FLGNotLike(String value) {
            addCriterion("LINE_FLG not like", value, "LINE_FLG");
            return (Criteria) this;
        }

        public Criteria andLINE_FLGIn(List<String> values) {
            addCriterion("LINE_FLG in", values, "LINE_FLG");
            return (Criteria) this;
        }

        public Criteria andLINE_FLGNotIn(List<String> values) {
            addCriterion("LINE_FLG not in", values, "LINE_FLG");
            return (Criteria) this;
        }

        public Criteria andLINE_FLGBetween(String value1, String value2) {
            addCriterion("LINE_FLG between", value1, value2, "LINE_FLG");
            return (Criteria) this;
        }

        public Criteria andLINE_FLGNotBetween(String value1, String value2) {
            addCriterion("LINE_FLG not between", value1, value2, "LINE_FLG");
            return (Criteria) this;
        }

        public Criteria andISP_NMIsNull() {
            addCriterion("ISP_NM is null");
            return (Criteria) this;
        }

        public Criteria andISP_NMIsNotNull() {
            addCriterion("ISP_NM is not null");
            return (Criteria) this;
        }

        public Criteria andISP_NMEqualTo(String value) {
            addCriterion("ISP_NM =", value, "ISP_NM");
            return (Criteria) this;
        }

        public Criteria andISP_NMNotEqualTo(String value) {
            addCriterion("ISP_NM <>", value, "ISP_NM");
            return (Criteria) this;
        }

        public Criteria andISP_NMGreaterThan(String value) {
            addCriterion("ISP_NM >", value, "ISP_NM");
            return (Criteria) this;
        }

        public Criteria andISP_NMGreaterThanOrEqualTo(String value) {
            addCriterion("ISP_NM >=", value, "ISP_NM");
            return (Criteria) this;
        }

        public Criteria andISP_NMLessThan(String value) {
            addCriterion("ISP_NM <", value, "ISP_NM");
            return (Criteria) this;
        }

        public Criteria andISP_NMLessThanOrEqualTo(String value) {
            addCriterion("ISP_NM <=", value, "ISP_NM");
            return (Criteria) this;
        }

        public Criteria andISP_NMLike(String value) {
            addCriterion("ISP_NM like", value, "ISP_NM");
            return (Criteria) this;
        }

        public Criteria andISP_NMNotLike(String value) {
            addCriterion("ISP_NM not like", value, "ISP_NM");
            return (Criteria) this;
        }

        public Criteria andISP_NMIn(List<String> values) {
            addCriterion("ISP_NM in", values, "ISP_NM");
            return (Criteria) this;
        }

        public Criteria andISP_NMNotIn(List<String> values) {
            addCriterion("ISP_NM not in", values, "ISP_NM");
            return (Criteria) this;
        }

        public Criteria andISP_NMBetween(String value1, String value2) {
            addCriterion("ISP_NM between", value1, value2, "ISP_NM");
            return (Criteria) this;
        }

        public Criteria andISP_NMNotBetween(String value1, String value2) {
            addCriterion("ISP_NM not between", value1, value2, "ISP_NM");
            return (Criteria) this;
        }

        public Criteria andLINE_CAREER_NMIsNull() {
            addCriterion("LINE_CAREER_NM is null");
            return (Criteria) this;
        }

        public Criteria andLINE_CAREER_NMIsNotNull() {
            addCriterion("LINE_CAREER_NM is not null");
            return (Criteria) this;
        }

        public Criteria andLINE_CAREER_NMEqualTo(String value) {
            addCriterion("LINE_CAREER_NM =", value, "LINE_CAREER_NM");
            return (Criteria) this;
        }

        public Criteria andLINE_CAREER_NMNotEqualTo(String value) {
            addCriterion("LINE_CAREER_NM <>", value, "LINE_CAREER_NM");
            return (Criteria) this;
        }

        public Criteria andLINE_CAREER_NMGreaterThan(String value) {
            addCriterion("LINE_CAREER_NM >", value, "LINE_CAREER_NM");
            return (Criteria) this;
        }

        public Criteria andLINE_CAREER_NMGreaterThanOrEqualTo(String value) {
            addCriterion("LINE_CAREER_NM >=", value, "LINE_CAREER_NM");
            return (Criteria) this;
        }

        public Criteria andLINE_CAREER_NMLessThan(String value) {
            addCriterion("LINE_CAREER_NM <", value, "LINE_CAREER_NM");
            return (Criteria) this;
        }

        public Criteria andLINE_CAREER_NMLessThanOrEqualTo(String value) {
            addCriterion("LINE_CAREER_NM <=", value, "LINE_CAREER_NM");
            return (Criteria) this;
        }

        public Criteria andLINE_CAREER_NMLike(String value) {
            addCriterion("LINE_CAREER_NM like", value, "LINE_CAREER_NM");
            return (Criteria) this;
        }

        public Criteria andLINE_CAREER_NMNotLike(String value) {
            addCriterion("LINE_CAREER_NM not like", value, "LINE_CAREER_NM");
            return (Criteria) this;
        }

        public Criteria andLINE_CAREER_NMIn(List<String> values) {
            addCriterion("LINE_CAREER_NM in", values, "LINE_CAREER_NM");
            return (Criteria) this;
        }

        public Criteria andLINE_CAREER_NMNotIn(List<String> values) {
            addCriterion("LINE_CAREER_NM not in", values, "LINE_CAREER_NM");
            return (Criteria) this;
        }

        public Criteria andLINE_CAREER_NMBetween(String value1, String value2) {
            addCriterion("LINE_CAREER_NM between", value1, value2, "LINE_CAREER_NM");
            return (Criteria) this;
        }

        public Criteria andLINE_CAREER_NMNotBetween(String value1, String value2) {
            addCriterion("LINE_CAREER_NM not between", value1, value2, "LINE_CAREER_NM");
            return (Criteria) this;
        }

        public Criteria andLINE_NMIsNull() {
            addCriterion("LINE_NM is null");
            return (Criteria) this;
        }

        public Criteria andLINE_NMIsNotNull() {
            addCriterion("LINE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andLINE_NMEqualTo(String value) {
            addCriterion("LINE_NM =", value, "LINE_NM");
            return (Criteria) this;
        }

        public Criteria andLINE_NMNotEqualTo(String value) {
            addCriterion("LINE_NM <>", value, "LINE_NM");
            return (Criteria) this;
        }

        public Criteria andLINE_NMGreaterThan(String value) {
            addCriterion("LINE_NM >", value, "LINE_NM");
            return (Criteria) this;
        }

        public Criteria andLINE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("LINE_NM >=", value, "LINE_NM");
            return (Criteria) this;
        }

        public Criteria andLINE_NMLessThan(String value) {
            addCriterion("LINE_NM <", value, "LINE_NM");
            return (Criteria) this;
        }

        public Criteria andLINE_NMLessThanOrEqualTo(String value) {
            addCriterion("LINE_NM <=", value, "LINE_NM");
            return (Criteria) this;
        }

        public Criteria andLINE_NMLike(String value) {
            addCriterion("LINE_NM like", value, "LINE_NM");
            return (Criteria) this;
        }

        public Criteria andLINE_NMNotLike(String value) {
            addCriterion("LINE_NM not like", value, "LINE_NM");
            return (Criteria) this;
        }

        public Criteria andLINE_NMIn(List<String> values) {
            addCriterion("LINE_NM in", values, "LINE_NM");
            return (Criteria) this;
        }

        public Criteria andLINE_NMNotIn(List<String> values) {
            addCriterion("LINE_NM not in", values, "LINE_NM");
            return (Criteria) this;
        }

        public Criteria andLINE_NMBetween(String value1, String value2) {
            addCriterion("LINE_NM between", value1, value2, "LINE_NM");
            return (Criteria) this;
        }

        public Criteria andLINE_NMNotBetween(String value1, String value2) {
            addCriterion("LINE_NM not between", value1, value2, "LINE_NM");
            return (Criteria) this;
        }

        public Criteria andCONN_FLGIsNull() {
            addCriterion("CONN_FLG is null");
            return (Criteria) this;
        }

        public Criteria andCONN_FLGIsNotNull() {
            addCriterion("CONN_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andCONN_FLGEqualTo(String value) {
            addCriterion("CONN_FLG =", value, "CONN_FLG");
            return (Criteria) this;
        }

        public Criteria andCONN_FLGNotEqualTo(String value) {
            addCriterion("CONN_FLG <>", value, "CONN_FLG");
            return (Criteria) this;
        }

        public Criteria andCONN_FLGGreaterThan(String value) {
            addCriterion("CONN_FLG >", value, "CONN_FLG");
            return (Criteria) this;
        }

        public Criteria andCONN_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("CONN_FLG >=", value, "CONN_FLG");
            return (Criteria) this;
        }

        public Criteria andCONN_FLGLessThan(String value) {
            addCriterion("CONN_FLG <", value, "CONN_FLG");
            return (Criteria) this;
        }

        public Criteria andCONN_FLGLessThanOrEqualTo(String value) {
            addCriterion("CONN_FLG <=", value, "CONN_FLG");
            return (Criteria) this;
        }

        public Criteria andCONN_FLGLike(String value) {
            addCriterion("CONN_FLG like", value, "CONN_FLG");
            return (Criteria) this;
        }

        public Criteria andCONN_FLGNotLike(String value) {
            addCriterion("CONN_FLG not like", value, "CONN_FLG");
            return (Criteria) this;
        }

        public Criteria andCONN_FLGIn(List<String> values) {
            addCriterion("CONN_FLG in", values, "CONN_FLG");
            return (Criteria) this;
        }

        public Criteria andCONN_FLGNotIn(List<String> values) {
            addCriterion("CONN_FLG not in", values, "CONN_FLG");
            return (Criteria) this;
        }

        public Criteria andCONN_FLGBetween(String value1, String value2) {
            addCriterion("CONN_FLG between", value1, value2, "CONN_FLG");
            return (Criteria) this;
        }

        public Criteria andCONN_FLGNotBetween(String value1, String value2) {
            addCriterion("CONN_FLG not between", value1, value2, "CONN_FLG");
            return (Criteria) this;
        }

        public Criteria andMDM_MAKER_NMIsNull() {
            addCriterion("MDM_MAKER_NM is null");
            return (Criteria) this;
        }

        public Criteria andMDM_MAKER_NMIsNotNull() {
            addCriterion("MDM_MAKER_NM is not null");
            return (Criteria) this;
        }

        public Criteria andMDM_MAKER_NMEqualTo(String value) {
            addCriterion("MDM_MAKER_NM =", value, "MDM_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andMDM_MAKER_NMNotEqualTo(String value) {
            addCriterion("MDM_MAKER_NM <>", value, "MDM_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andMDM_MAKER_NMGreaterThan(String value) {
            addCriterion("MDM_MAKER_NM >", value, "MDM_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andMDM_MAKER_NMGreaterThanOrEqualTo(String value) {
            addCriterion("MDM_MAKER_NM >=", value, "MDM_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andMDM_MAKER_NMLessThan(String value) {
            addCriterion("MDM_MAKER_NM <", value, "MDM_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andMDM_MAKER_NMLessThanOrEqualTo(String value) {
            addCriterion("MDM_MAKER_NM <=", value, "MDM_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andMDM_MAKER_NMLike(String value) {
            addCriterion("MDM_MAKER_NM like", value, "MDM_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andMDM_MAKER_NMNotLike(String value) {
            addCriterion("MDM_MAKER_NM not like", value, "MDM_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andMDM_MAKER_NMIn(List<String> values) {
            addCriterion("MDM_MAKER_NM in", values, "MDM_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andMDM_MAKER_NMNotIn(List<String> values) {
            addCriterion("MDM_MAKER_NM not in", values, "MDM_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andMDM_MAKER_NMBetween(String value1, String value2) {
            addCriterion("MDM_MAKER_NM between", value1, value2, "MDM_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andMDM_MAKER_NMNotBetween(String value1, String value2) {
            addCriterion("MDM_MAKER_NM not between", value1, value2, "MDM_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andMDM_NMIsNull() {
            addCriterion("MDM_NM is null");
            return (Criteria) this;
        }

        public Criteria andMDM_NMIsNotNull() {
            addCriterion("MDM_NM is not null");
            return (Criteria) this;
        }

        public Criteria andMDM_NMEqualTo(String value) {
            addCriterion("MDM_NM =", value, "MDM_NM");
            return (Criteria) this;
        }

        public Criteria andMDM_NMNotEqualTo(String value) {
            addCriterion("MDM_NM <>", value, "MDM_NM");
            return (Criteria) this;
        }

        public Criteria andMDM_NMGreaterThan(String value) {
            addCriterion("MDM_NM >", value, "MDM_NM");
            return (Criteria) this;
        }

        public Criteria andMDM_NMGreaterThanOrEqualTo(String value) {
            addCriterion("MDM_NM >=", value, "MDM_NM");
            return (Criteria) this;
        }

        public Criteria andMDM_NMLessThan(String value) {
            addCriterion("MDM_NM <", value, "MDM_NM");
            return (Criteria) this;
        }

        public Criteria andMDM_NMLessThanOrEqualTo(String value) {
            addCriterion("MDM_NM <=", value, "MDM_NM");
            return (Criteria) this;
        }

        public Criteria andMDM_NMLike(String value) {
            addCriterion("MDM_NM like", value, "MDM_NM");
            return (Criteria) this;
        }

        public Criteria andMDM_NMNotLike(String value) {
            addCriterion("MDM_NM not like", value, "MDM_NM");
            return (Criteria) this;
        }

        public Criteria andMDM_NMIn(List<String> values) {
            addCriterion("MDM_NM in", values, "MDM_NM");
            return (Criteria) this;
        }

        public Criteria andMDM_NMNotIn(List<String> values) {
            addCriterion("MDM_NM not in", values, "MDM_NM");
            return (Criteria) this;
        }

        public Criteria andMDM_NMBetween(String value1, String value2) {
            addCriterion("MDM_NM between", value1, value2, "MDM_NM");
            return (Criteria) this;
        }

        public Criteria andMDM_NMNotBetween(String value1, String value2) {
            addCriterion("MDM_NM not between", value1, value2, "MDM_NM");
            return (Criteria) this;
        }

        public Criteria andROUTER_MAKER_NMIsNull() {
            addCriterion("ROUTER_MAKER_NM is null");
            return (Criteria) this;
        }

        public Criteria andROUTER_MAKER_NMIsNotNull() {
            addCriterion("ROUTER_MAKER_NM is not null");
            return (Criteria) this;
        }

        public Criteria andROUTER_MAKER_NMEqualTo(String value) {
            addCriterion("ROUTER_MAKER_NM =", value, "ROUTER_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andROUTER_MAKER_NMNotEqualTo(String value) {
            addCriterion("ROUTER_MAKER_NM <>", value, "ROUTER_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andROUTER_MAKER_NMGreaterThan(String value) {
            addCriterion("ROUTER_MAKER_NM >", value, "ROUTER_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andROUTER_MAKER_NMGreaterThanOrEqualTo(String value) {
            addCriterion("ROUTER_MAKER_NM >=", value, "ROUTER_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andROUTER_MAKER_NMLessThan(String value) {
            addCriterion("ROUTER_MAKER_NM <", value, "ROUTER_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andROUTER_MAKER_NMLessThanOrEqualTo(String value) {
            addCriterion("ROUTER_MAKER_NM <=", value, "ROUTER_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andROUTER_MAKER_NMLike(String value) {
            addCriterion("ROUTER_MAKER_NM like", value, "ROUTER_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andROUTER_MAKER_NMNotLike(String value) {
            addCriterion("ROUTER_MAKER_NM not like", value, "ROUTER_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andROUTER_MAKER_NMIn(List<String> values) {
            addCriterion("ROUTER_MAKER_NM in", values, "ROUTER_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andROUTER_MAKER_NMNotIn(List<String> values) {
            addCriterion("ROUTER_MAKER_NM not in", values, "ROUTER_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andROUTER_MAKER_NMBetween(String value1, String value2) {
            addCriterion("ROUTER_MAKER_NM between", value1, value2, "ROUTER_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andROUTER_MAKER_NMNotBetween(String value1, String value2) {
            addCriterion("ROUTER_MAKER_NM not between", value1, value2, "ROUTER_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andROUTER_NMIsNull() {
            addCriterion("ROUTER_NM is null");
            return (Criteria) this;
        }

        public Criteria andROUTER_NMIsNotNull() {
            addCriterion("ROUTER_NM is not null");
            return (Criteria) this;
        }

        public Criteria andROUTER_NMEqualTo(String value) {
            addCriterion("ROUTER_NM =", value, "ROUTER_NM");
            return (Criteria) this;
        }

        public Criteria andROUTER_NMNotEqualTo(String value) {
            addCriterion("ROUTER_NM <>", value, "ROUTER_NM");
            return (Criteria) this;
        }

        public Criteria andROUTER_NMGreaterThan(String value) {
            addCriterion("ROUTER_NM >", value, "ROUTER_NM");
            return (Criteria) this;
        }

        public Criteria andROUTER_NMGreaterThanOrEqualTo(String value) {
            addCriterion("ROUTER_NM >=", value, "ROUTER_NM");
            return (Criteria) this;
        }

        public Criteria andROUTER_NMLessThan(String value) {
            addCriterion("ROUTER_NM <", value, "ROUTER_NM");
            return (Criteria) this;
        }

        public Criteria andROUTER_NMLessThanOrEqualTo(String value) {
            addCriterion("ROUTER_NM <=", value, "ROUTER_NM");
            return (Criteria) this;
        }

        public Criteria andROUTER_NMLike(String value) {
            addCriterion("ROUTER_NM like", value, "ROUTER_NM");
            return (Criteria) this;
        }

        public Criteria andROUTER_NMNotLike(String value) {
            addCriterion("ROUTER_NM not like", value, "ROUTER_NM");
            return (Criteria) this;
        }

        public Criteria andROUTER_NMIn(List<String> values) {
            addCriterion("ROUTER_NM in", values, "ROUTER_NM");
            return (Criteria) this;
        }

        public Criteria andROUTER_NMNotIn(List<String> values) {
            addCriterion("ROUTER_NM not in", values, "ROUTER_NM");
            return (Criteria) this;
        }

        public Criteria andROUTER_NMBetween(String value1, String value2) {
            addCriterion("ROUTER_NM between", value1, value2, "ROUTER_NM");
            return (Criteria) this;
        }

        public Criteria andROUTER_NMNotBetween(String value1, String value2) {
            addCriterion("ROUTER_NM not between", value1, value2, "ROUTER_NM");
            return (Criteria) this;
        }

        public Criteria andHUB_MAKER_NMIsNull() {
            addCriterion("HUB_MAKER_NM is null");
            return (Criteria) this;
        }

        public Criteria andHUB_MAKER_NMIsNotNull() {
            addCriterion("HUB_MAKER_NM is not null");
            return (Criteria) this;
        }

        public Criteria andHUB_MAKER_NMEqualTo(String value) {
            addCriterion("HUB_MAKER_NM =", value, "HUB_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andHUB_MAKER_NMNotEqualTo(String value) {
            addCriterion("HUB_MAKER_NM <>", value, "HUB_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andHUB_MAKER_NMGreaterThan(String value) {
            addCriterion("HUB_MAKER_NM >", value, "HUB_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andHUB_MAKER_NMGreaterThanOrEqualTo(String value) {
            addCriterion("HUB_MAKER_NM >=", value, "HUB_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andHUB_MAKER_NMLessThan(String value) {
            addCriterion("HUB_MAKER_NM <", value, "HUB_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andHUB_MAKER_NMLessThanOrEqualTo(String value) {
            addCriterion("HUB_MAKER_NM <=", value, "HUB_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andHUB_MAKER_NMLike(String value) {
            addCriterion("HUB_MAKER_NM like", value, "HUB_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andHUB_MAKER_NMNotLike(String value) {
            addCriterion("HUB_MAKER_NM not like", value, "HUB_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andHUB_MAKER_NMIn(List<String> values) {
            addCriterion("HUB_MAKER_NM in", values, "HUB_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andHUB_MAKER_NMNotIn(List<String> values) {
            addCriterion("HUB_MAKER_NM not in", values, "HUB_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andHUB_MAKER_NMBetween(String value1, String value2) {
            addCriterion("HUB_MAKER_NM between", value1, value2, "HUB_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andHUB_MAKER_NMNotBetween(String value1, String value2) {
            addCriterion("HUB_MAKER_NM not between", value1, value2, "HUB_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andHUB_NMIsNull() {
            addCriterion("HUB_NM is null");
            return (Criteria) this;
        }

        public Criteria andHUB_NMIsNotNull() {
            addCriterion("HUB_NM is not null");
            return (Criteria) this;
        }

        public Criteria andHUB_NMEqualTo(String value) {
            addCriterion("HUB_NM =", value, "HUB_NM");
            return (Criteria) this;
        }

        public Criteria andHUB_NMNotEqualTo(String value) {
            addCriterion("HUB_NM <>", value, "HUB_NM");
            return (Criteria) this;
        }

        public Criteria andHUB_NMGreaterThan(String value) {
            addCriterion("HUB_NM >", value, "HUB_NM");
            return (Criteria) this;
        }

        public Criteria andHUB_NMGreaterThanOrEqualTo(String value) {
            addCriterion("HUB_NM >=", value, "HUB_NM");
            return (Criteria) this;
        }

        public Criteria andHUB_NMLessThan(String value) {
            addCriterion("HUB_NM <", value, "HUB_NM");
            return (Criteria) this;
        }

        public Criteria andHUB_NMLessThanOrEqualTo(String value) {
            addCriterion("HUB_NM <=", value, "HUB_NM");
            return (Criteria) this;
        }

        public Criteria andHUB_NMLike(String value) {
            addCriterion("HUB_NM like", value, "HUB_NM");
            return (Criteria) this;
        }

        public Criteria andHUB_NMNotLike(String value) {
            addCriterion("HUB_NM not like", value, "HUB_NM");
            return (Criteria) this;
        }

        public Criteria andHUB_NMIn(List<String> values) {
            addCriterion("HUB_NM in", values, "HUB_NM");
            return (Criteria) this;
        }

        public Criteria andHUB_NMNotIn(List<String> values) {
            addCriterion("HUB_NM not in", values, "HUB_NM");
            return (Criteria) this;
        }

        public Criteria andHUB_NMBetween(String value1, String value2) {
            addCriterion("HUB_NM between", value1, value2, "HUB_NM");
            return (Criteria) this;
        }

        public Criteria andHUB_NMNotBetween(String value1, String value2) {
            addCriterion("HUB_NM not between", value1, value2, "HUB_NM");
            return (Criteria) this;
        }

        public Criteria andONU_MAKER_NMIsNull() {
            addCriterion("ONU_MAKER_NM is null");
            return (Criteria) this;
        }

        public Criteria andONU_MAKER_NMIsNotNull() {
            addCriterion("ONU_MAKER_NM is not null");
            return (Criteria) this;
        }

        public Criteria andONU_MAKER_NMEqualTo(String value) {
            addCriterion("ONU_MAKER_NM =", value, "ONU_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andONU_MAKER_NMNotEqualTo(String value) {
            addCriterion("ONU_MAKER_NM <>", value, "ONU_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andONU_MAKER_NMGreaterThan(String value) {
            addCriterion("ONU_MAKER_NM >", value, "ONU_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andONU_MAKER_NMGreaterThanOrEqualTo(String value) {
            addCriterion("ONU_MAKER_NM >=", value, "ONU_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andONU_MAKER_NMLessThan(String value) {
            addCriterion("ONU_MAKER_NM <", value, "ONU_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andONU_MAKER_NMLessThanOrEqualTo(String value) {
            addCriterion("ONU_MAKER_NM <=", value, "ONU_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andONU_MAKER_NMLike(String value) {
            addCriterion("ONU_MAKER_NM like", value, "ONU_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andONU_MAKER_NMNotLike(String value) {
            addCriterion("ONU_MAKER_NM not like", value, "ONU_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andONU_MAKER_NMIn(List<String> values) {
            addCriterion("ONU_MAKER_NM in", values, "ONU_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andONU_MAKER_NMNotIn(List<String> values) {
            addCriterion("ONU_MAKER_NM not in", values, "ONU_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andONU_MAKER_NMBetween(String value1, String value2) {
            addCriterion("ONU_MAKER_NM between", value1, value2, "ONU_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andONU_MAKER_NMNotBetween(String value1, String value2) {
            addCriterion("ONU_MAKER_NM not between", value1, value2, "ONU_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andONU_NMIsNull() {
            addCriterion("ONU_NM is null");
            return (Criteria) this;
        }

        public Criteria andONU_NMIsNotNull() {
            addCriterion("ONU_NM is not null");
            return (Criteria) this;
        }

        public Criteria andONU_NMEqualTo(String value) {
            addCriterion("ONU_NM =", value, "ONU_NM");
            return (Criteria) this;
        }

        public Criteria andONU_NMNotEqualTo(String value) {
            addCriterion("ONU_NM <>", value, "ONU_NM");
            return (Criteria) this;
        }

        public Criteria andONU_NMGreaterThan(String value) {
            addCriterion("ONU_NM >", value, "ONU_NM");
            return (Criteria) this;
        }

        public Criteria andONU_NMGreaterThanOrEqualTo(String value) {
            addCriterion("ONU_NM >=", value, "ONU_NM");
            return (Criteria) this;
        }

        public Criteria andONU_NMLessThan(String value) {
            addCriterion("ONU_NM <", value, "ONU_NM");
            return (Criteria) this;
        }

        public Criteria andONU_NMLessThanOrEqualTo(String value) {
            addCriterion("ONU_NM <=", value, "ONU_NM");
            return (Criteria) this;
        }

        public Criteria andONU_NMLike(String value) {
            addCriterion("ONU_NM like", value, "ONU_NM");
            return (Criteria) this;
        }

        public Criteria andONU_NMNotLike(String value) {
            addCriterion("ONU_NM not like", value, "ONU_NM");
            return (Criteria) this;
        }

        public Criteria andONU_NMIn(List<String> values) {
            addCriterion("ONU_NM in", values, "ONU_NM");
            return (Criteria) this;
        }

        public Criteria andONU_NMNotIn(List<String> values) {
            addCriterion("ONU_NM not in", values, "ONU_NM");
            return (Criteria) this;
        }

        public Criteria andONU_NMBetween(String value1, String value2) {
            addCriterion("ONU_NM between", value1, value2, "ONU_NM");
            return (Criteria) this;
        }

        public Criteria andONU_NMNotBetween(String value1, String value2) {
            addCriterion("ONU_NM not between", value1, value2, "ONU_NM");
            return (Criteria) this;
        }

        public Criteria andVPN_FLGIsNull() {
            addCriterion("VPN_FLG is null");
            return (Criteria) this;
        }

        public Criteria andVPN_FLGIsNotNull() {
            addCriterion("VPN_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andVPN_FLGEqualTo(String value) {
            addCriterion("VPN_FLG =", value, "VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andVPN_FLGNotEqualTo(String value) {
            addCriterion("VPN_FLG <>", value, "VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andVPN_FLGGreaterThan(String value) {
            addCriterion("VPN_FLG >", value, "VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andVPN_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("VPN_FLG >=", value, "VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andVPN_FLGLessThan(String value) {
            addCriterion("VPN_FLG <", value, "VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andVPN_FLGLessThanOrEqualTo(String value) {
            addCriterion("VPN_FLG <=", value, "VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andVPN_FLGLike(String value) {
            addCriterion("VPN_FLG like", value, "VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andVPN_FLGNotLike(String value) {
            addCriterion("VPN_FLG not like", value, "VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andVPN_FLGIn(List<String> values) {
            addCriterion("VPN_FLG in", values, "VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andVPN_FLGNotIn(List<String> values) {
            addCriterion("VPN_FLG not in", values, "VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andVPN_FLGBetween(String value1, String value2) {
            addCriterion("VPN_FLG between", value1, value2, "VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andVPN_FLGNotBetween(String value1, String value2) {
            addCriterion("VPN_FLG not between", value1, value2, "VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andVOIP_FLGIsNull() {
            addCriterion("VOIP_FLG is null");
            return (Criteria) this;
        }

        public Criteria andVOIP_FLGIsNotNull() {
            addCriterion("VOIP_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andVOIP_FLGEqualTo(String value) {
            addCriterion("VOIP_FLG =", value, "VOIP_FLG");
            return (Criteria) this;
        }

        public Criteria andVOIP_FLGNotEqualTo(String value) {
            addCriterion("VOIP_FLG <>", value, "VOIP_FLG");
            return (Criteria) this;
        }

        public Criteria andVOIP_FLGGreaterThan(String value) {
            addCriterion("VOIP_FLG >", value, "VOIP_FLG");
            return (Criteria) this;
        }

        public Criteria andVOIP_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("VOIP_FLG >=", value, "VOIP_FLG");
            return (Criteria) this;
        }

        public Criteria andVOIP_FLGLessThan(String value) {
            addCriterion("VOIP_FLG <", value, "VOIP_FLG");
            return (Criteria) this;
        }

        public Criteria andVOIP_FLGLessThanOrEqualTo(String value) {
            addCriterion("VOIP_FLG <=", value, "VOIP_FLG");
            return (Criteria) this;
        }

        public Criteria andVOIP_FLGLike(String value) {
            addCriterion("VOIP_FLG like", value, "VOIP_FLG");
            return (Criteria) this;
        }

        public Criteria andVOIP_FLGNotLike(String value) {
            addCriterion("VOIP_FLG not like", value, "VOIP_FLG");
            return (Criteria) this;
        }

        public Criteria andVOIP_FLGIn(List<String> values) {
            addCriterion("VOIP_FLG in", values, "VOIP_FLG");
            return (Criteria) this;
        }

        public Criteria andVOIP_FLGNotIn(List<String> values) {
            addCriterion("VOIP_FLG not in", values, "VOIP_FLG");
            return (Criteria) this;
        }

        public Criteria andVOIP_FLGBetween(String value1, String value2) {
            addCriterion("VOIP_FLG between", value1, value2, "VOIP_FLG");
            return (Criteria) this;
        }

        public Criteria andVOIP_FLGNotBetween(String value1, String value2) {
            addCriterion("VOIP_FLG not between", value1, value2, "VOIP_FLG");
            return (Criteria) this;
        }

        public Criteria andPC_CONN_NUMIsNull() {
            addCriterion("PC_CONN_NUM is null");
            return (Criteria) this;
        }

        public Criteria andPC_CONN_NUMIsNotNull() {
            addCriterion("PC_CONN_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andPC_CONN_NUMEqualTo(String value) {
            addCriterion("PC_CONN_NUM =", value, "PC_CONN_NUM");
            return (Criteria) this;
        }

        public Criteria andPC_CONN_NUMNotEqualTo(String value) {
            addCriterion("PC_CONN_NUM <>", value, "PC_CONN_NUM");
            return (Criteria) this;
        }

        public Criteria andPC_CONN_NUMGreaterThan(String value) {
            addCriterion("PC_CONN_NUM >", value, "PC_CONN_NUM");
            return (Criteria) this;
        }

        public Criteria andPC_CONN_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("PC_CONN_NUM >=", value, "PC_CONN_NUM");
            return (Criteria) this;
        }

        public Criteria andPC_CONN_NUMLessThan(String value) {
            addCriterion("PC_CONN_NUM <", value, "PC_CONN_NUM");
            return (Criteria) this;
        }

        public Criteria andPC_CONN_NUMLessThanOrEqualTo(String value) {
            addCriterion("PC_CONN_NUM <=", value, "PC_CONN_NUM");
            return (Criteria) this;
        }

        public Criteria andPC_CONN_NUMLike(String value) {
            addCriterion("PC_CONN_NUM like", value, "PC_CONN_NUM");
            return (Criteria) this;
        }

        public Criteria andPC_CONN_NUMNotLike(String value) {
            addCriterion("PC_CONN_NUM not like", value, "PC_CONN_NUM");
            return (Criteria) this;
        }

        public Criteria andPC_CONN_NUMIn(List<String> values) {
            addCriterion("PC_CONN_NUM in", values, "PC_CONN_NUM");
            return (Criteria) this;
        }

        public Criteria andPC_CONN_NUMNotIn(List<String> values) {
            addCriterion("PC_CONN_NUM not in", values, "PC_CONN_NUM");
            return (Criteria) this;
        }

        public Criteria andPC_CONN_NUMBetween(String value1, String value2) {
            addCriterion("PC_CONN_NUM between", value1, value2, "PC_CONN_NUM");
            return (Criteria) this;
        }

        public Criteria andPC_CONN_NUMNotBetween(String value1, String value2) {
            addCriterion("PC_CONN_NUM not between", value1, value2, "PC_CONN_NUM");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_FLGIsNull() {
            addCriterion("ETC_CONN_FLG is null");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_FLGIsNotNull() {
            addCriterion("ETC_CONN_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_FLGEqualTo(String value) {
            addCriterion("ETC_CONN_FLG =", value, "ETC_CONN_FLG");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_FLGNotEqualTo(String value) {
            addCriterion("ETC_CONN_FLG <>", value, "ETC_CONN_FLG");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_FLGGreaterThan(String value) {
            addCriterion("ETC_CONN_FLG >", value, "ETC_CONN_FLG");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("ETC_CONN_FLG >=", value, "ETC_CONN_FLG");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_FLGLessThan(String value) {
            addCriterion("ETC_CONN_FLG <", value, "ETC_CONN_FLG");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_FLGLessThanOrEqualTo(String value) {
            addCriterion("ETC_CONN_FLG <=", value, "ETC_CONN_FLG");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_FLGLike(String value) {
            addCriterion("ETC_CONN_FLG like", value, "ETC_CONN_FLG");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_FLGNotLike(String value) {
            addCriterion("ETC_CONN_FLG not like", value, "ETC_CONN_FLG");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_FLGIn(List<String> values) {
            addCriterion("ETC_CONN_FLG in", values, "ETC_CONN_FLG");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_FLGNotIn(List<String> values) {
            addCriterion("ETC_CONN_FLG not in", values, "ETC_CONN_FLG");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_FLGBetween(String value1, String value2) {
            addCriterion("ETC_CONN_FLG between", value1, value2, "ETC_CONN_FLG");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_FLGNotBetween(String value1, String value2) {
            addCriterion("ETC_CONN_FLG not between", value1, value2, "ETC_CONN_FLG");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NUMIsNull() {
            addCriterion("ETC_CONN_NUM is null");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NUMIsNotNull() {
            addCriterion("ETC_CONN_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NUMEqualTo(String value) {
            addCriterion("ETC_CONN_NUM =", value, "ETC_CONN_NUM");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NUMNotEqualTo(String value) {
            addCriterion("ETC_CONN_NUM <>", value, "ETC_CONN_NUM");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NUMGreaterThan(String value) {
            addCriterion("ETC_CONN_NUM >", value, "ETC_CONN_NUM");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("ETC_CONN_NUM >=", value, "ETC_CONN_NUM");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NUMLessThan(String value) {
            addCriterion("ETC_CONN_NUM <", value, "ETC_CONN_NUM");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NUMLessThanOrEqualTo(String value) {
            addCriterion("ETC_CONN_NUM <=", value, "ETC_CONN_NUM");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NUMLike(String value) {
            addCriterion("ETC_CONN_NUM like", value, "ETC_CONN_NUM");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NUMNotLike(String value) {
            addCriterion("ETC_CONN_NUM not like", value, "ETC_CONN_NUM");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NUMIn(List<String> values) {
            addCriterion("ETC_CONN_NUM in", values, "ETC_CONN_NUM");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NUMNotIn(List<String> values) {
            addCriterion("ETC_CONN_NUM not in", values, "ETC_CONN_NUM");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NUMBetween(String value1, String value2) {
            addCriterion("ETC_CONN_NUM between", value1, value2, "ETC_CONN_NUM");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NUMNotBetween(String value1, String value2) {
            addCriterion("ETC_CONN_NUM not between", value1, value2, "ETC_CONN_NUM");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NMIsNull() {
            addCriterion("ETC_CONN_NM is null");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NMIsNotNull() {
            addCriterion("ETC_CONN_NM is not null");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NMEqualTo(String value) {
            addCriterion("ETC_CONN_NM =", value, "ETC_CONN_NM");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NMNotEqualTo(String value) {
            addCriterion("ETC_CONN_NM <>", value, "ETC_CONN_NM");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NMGreaterThan(String value) {
            addCriterion("ETC_CONN_NM >", value, "ETC_CONN_NM");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NMGreaterThanOrEqualTo(String value) {
            addCriterion("ETC_CONN_NM >=", value, "ETC_CONN_NM");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NMLessThan(String value) {
            addCriterion("ETC_CONN_NM <", value, "ETC_CONN_NM");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NMLessThanOrEqualTo(String value) {
            addCriterion("ETC_CONN_NM <=", value, "ETC_CONN_NM");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NMLike(String value) {
            addCriterion("ETC_CONN_NM like", value, "ETC_CONN_NM");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NMNotLike(String value) {
            addCriterion("ETC_CONN_NM not like", value, "ETC_CONN_NM");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NMIn(List<String> values) {
            addCriterion("ETC_CONN_NM in", values, "ETC_CONN_NM");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NMNotIn(List<String> values) {
            addCriterion("ETC_CONN_NM not in", values, "ETC_CONN_NM");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NMBetween(String value1, String value2) {
            addCriterion("ETC_CONN_NM between", value1, value2, "ETC_CONN_NM");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NMNotBetween(String value1, String value2) {
            addCriterion("ETC_CONN_NM not between", value1, value2, "ETC_CONN_NM");
            return (Criteria) this;
        }

        public Criteria andUPS_FLGIsNull() {
            addCriterion("UPS_FLG is null");
            return (Criteria) this;
        }

        public Criteria andUPS_FLGIsNotNull() {
            addCriterion("UPS_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andUPS_FLGEqualTo(String value) {
            addCriterion("UPS_FLG =", value, "UPS_FLG");
            return (Criteria) this;
        }

        public Criteria andUPS_FLGNotEqualTo(String value) {
            addCriterion("UPS_FLG <>", value, "UPS_FLG");
            return (Criteria) this;
        }

        public Criteria andUPS_FLGGreaterThan(String value) {
            addCriterion("UPS_FLG >", value, "UPS_FLG");
            return (Criteria) this;
        }

        public Criteria andUPS_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("UPS_FLG >=", value, "UPS_FLG");
            return (Criteria) this;
        }

        public Criteria andUPS_FLGLessThan(String value) {
            addCriterion("UPS_FLG <", value, "UPS_FLG");
            return (Criteria) this;
        }

        public Criteria andUPS_FLGLessThanOrEqualTo(String value) {
            addCriterion("UPS_FLG <=", value, "UPS_FLG");
            return (Criteria) this;
        }

        public Criteria andUPS_FLGLike(String value) {
            addCriterion("UPS_FLG like", value, "UPS_FLG");
            return (Criteria) this;
        }

        public Criteria andUPS_FLGNotLike(String value) {
            addCriterion("UPS_FLG not like", value, "UPS_FLG");
            return (Criteria) this;
        }

        public Criteria andUPS_FLGIn(List<String> values) {
            addCriterion("UPS_FLG in", values, "UPS_FLG");
            return (Criteria) this;
        }

        public Criteria andUPS_FLGNotIn(List<String> values) {
            addCriterion("UPS_FLG not in", values, "UPS_FLG");
            return (Criteria) this;
        }

        public Criteria andUPS_FLGBetween(String value1, String value2) {
            addCriterion("UPS_FLG between", value1, value2, "UPS_FLG");
            return (Criteria) this;
        }

        public Criteria andUPS_FLGNotBetween(String value1, String value2) {
            addCriterion("UPS_FLG not between", value1, value2, "UPS_FLG");
            return (Criteria) this;
        }

        public Criteria andUPS_PERMIT_FLGIsNull() {
            addCriterion("UPS_PERMIT_FLG is null");
            return (Criteria) this;
        }

        public Criteria andUPS_PERMIT_FLGIsNotNull() {
            addCriterion("UPS_PERMIT_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andUPS_PERMIT_FLGEqualTo(String value) {
            addCriterion("UPS_PERMIT_FLG =", value, "UPS_PERMIT_FLG");
            return (Criteria) this;
        }

        public Criteria andUPS_PERMIT_FLGNotEqualTo(String value) {
            addCriterion("UPS_PERMIT_FLG <>", value, "UPS_PERMIT_FLG");
            return (Criteria) this;
        }

        public Criteria andUPS_PERMIT_FLGGreaterThan(String value) {
            addCriterion("UPS_PERMIT_FLG >", value, "UPS_PERMIT_FLG");
            return (Criteria) this;
        }

        public Criteria andUPS_PERMIT_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("UPS_PERMIT_FLG >=", value, "UPS_PERMIT_FLG");
            return (Criteria) this;
        }

        public Criteria andUPS_PERMIT_FLGLessThan(String value) {
            addCriterion("UPS_PERMIT_FLG <", value, "UPS_PERMIT_FLG");
            return (Criteria) this;
        }

        public Criteria andUPS_PERMIT_FLGLessThanOrEqualTo(String value) {
            addCriterion("UPS_PERMIT_FLG <=", value, "UPS_PERMIT_FLG");
            return (Criteria) this;
        }

        public Criteria andUPS_PERMIT_FLGLike(String value) {
            addCriterion("UPS_PERMIT_FLG like", value, "UPS_PERMIT_FLG");
            return (Criteria) this;
        }

        public Criteria andUPS_PERMIT_FLGNotLike(String value) {
            addCriterion("UPS_PERMIT_FLG not like", value, "UPS_PERMIT_FLG");
            return (Criteria) this;
        }

        public Criteria andUPS_PERMIT_FLGIn(List<String> values) {
            addCriterion("UPS_PERMIT_FLG in", values, "UPS_PERMIT_FLG");
            return (Criteria) this;
        }

        public Criteria andUPS_PERMIT_FLGNotIn(List<String> values) {
            addCriterion("UPS_PERMIT_FLG not in", values, "UPS_PERMIT_FLG");
            return (Criteria) this;
        }

        public Criteria andUPS_PERMIT_FLGBetween(String value1, String value2) {
            addCriterion("UPS_PERMIT_FLG between", value1, value2, "UPS_PERMIT_FLG");
            return (Criteria) this;
        }

        public Criteria andUPS_PERMIT_FLGNotBetween(String value1, String value2) {
            addCriterion("UPS_PERMIT_FLG not between", value1, value2, "UPS_PERMIT_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_FLGIsNull() {
            addCriterion("FWALL_FLG is null");
            return (Criteria) this;
        }

        public Criteria andFWALL_FLGIsNotNull() {
            addCriterion("FWALL_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andFWALL_FLGEqualTo(String value) {
            addCriterion("FWALL_FLG =", value, "FWALL_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_FLGNotEqualTo(String value) {
            addCriterion("FWALL_FLG <>", value, "FWALL_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_FLGGreaterThan(String value) {
            addCriterion("FWALL_FLG >", value, "FWALL_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("FWALL_FLG >=", value, "FWALL_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_FLGLessThan(String value) {
            addCriterion("FWALL_FLG <", value, "FWALL_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_FLGLessThanOrEqualTo(String value) {
            addCriterion("FWALL_FLG <=", value, "FWALL_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_FLGLike(String value) {
            addCriterion("FWALL_FLG like", value, "FWALL_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_FLGNotLike(String value) {
            addCriterion("FWALL_FLG not like", value, "FWALL_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_FLGIn(List<String> values) {
            addCriterion("FWALL_FLG in", values, "FWALL_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_FLGNotIn(List<String> values) {
            addCriterion("FWALL_FLG not in", values, "FWALL_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_FLGBetween(String value1, String value2) {
            addCriterion("FWALL_FLG between", value1, value2, "FWALL_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_FLGNotBetween(String value1, String value2) {
            addCriterion("FWALL_FLG not between", value1, value2, "FWALL_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_VPN_FLGIsNull() {
            addCriterion("FWALL_VPN_FLG is null");
            return (Criteria) this;
        }

        public Criteria andFWALL_VPN_FLGIsNotNull() {
            addCriterion("FWALL_VPN_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andFWALL_VPN_FLGEqualTo(String value) {
            addCriterion("FWALL_VPN_FLG =", value, "FWALL_VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_VPN_FLGNotEqualTo(String value) {
            addCriterion("FWALL_VPN_FLG <>", value, "FWALL_VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_VPN_FLGGreaterThan(String value) {
            addCriterion("FWALL_VPN_FLG >", value, "FWALL_VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_VPN_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("FWALL_VPN_FLG >=", value, "FWALL_VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_VPN_FLGLessThan(String value) {
            addCriterion("FWALL_VPN_FLG <", value, "FWALL_VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_VPN_FLGLessThanOrEqualTo(String value) {
            addCriterion("FWALL_VPN_FLG <=", value, "FWALL_VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_VPN_FLGLike(String value) {
            addCriterion("FWALL_VPN_FLG like", value, "FWALL_VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_VPN_FLGNotLike(String value) {
            addCriterion("FWALL_VPN_FLG not like", value, "FWALL_VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_VPN_FLGIn(List<String> values) {
            addCriterion("FWALL_VPN_FLG in", values, "FWALL_VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_VPN_FLGNotIn(List<String> values) {
            addCriterion("FWALL_VPN_FLG not in", values, "FWALL_VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_VPN_FLGBetween(String value1, String value2) {
            addCriterion("FWALL_VPN_FLG between", value1, value2, "FWALL_VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_VPN_FLGNotBetween(String value1, String value2) {
            addCriterion("FWALL_VPN_FLG not between", value1, value2, "FWALL_VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_CONF_CNG_FLGIsNull() {
            addCriterion("FWALL_CONF_CNG_FLG is null");
            return (Criteria) this;
        }

        public Criteria andFWALL_CONF_CNG_FLGIsNotNull() {
            addCriterion("FWALL_CONF_CNG_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andFWALL_CONF_CNG_FLGEqualTo(String value) {
            addCriterion("FWALL_CONF_CNG_FLG =", value, "FWALL_CONF_CNG_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_CONF_CNG_FLGNotEqualTo(String value) {
            addCriterion("FWALL_CONF_CNG_FLG <>", value, "FWALL_CONF_CNG_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_CONF_CNG_FLGGreaterThan(String value) {
            addCriterion("FWALL_CONF_CNG_FLG >", value, "FWALL_CONF_CNG_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_CONF_CNG_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("FWALL_CONF_CNG_FLG >=", value, "FWALL_CONF_CNG_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_CONF_CNG_FLGLessThan(String value) {
            addCriterion("FWALL_CONF_CNG_FLG <", value, "FWALL_CONF_CNG_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_CONF_CNG_FLGLessThanOrEqualTo(String value) {
            addCriterion("FWALL_CONF_CNG_FLG <=", value, "FWALL_CONF_CNG_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_CONF_CNG_FLGLike(String value) {
            addCriterion("FWALL_CONF_CNG_FLG like", value, "FWALL_CONF_CNG_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_CONF_CNG_FLGNotLike(String value) {
            addCriterion("FWALL_CONF_CNG_FLG not like", value, "FWALL_CONF_CNG_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_CONF_CNG_FLGIn(List<String> values) {
            addCriterion("FWALL_CONF_CNG_FLG in", values, "FWALL_CONF_CNG_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_CONF_CNG_FLGNotIn(List<String> values) {
            addCriterion("FWALL_CONF_CNG_FLG not in", values, "FWALL_CONF_CNG_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_CONF_CNG_FLGBetween(String value1, String value2) {
            addCriterion("FWALL_CONF_CNG_FLG between", value1, value2, "FWALL_CONF_CNG_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_CONF_CNG_FLGNotBetween(String value1, String value2) {
            addCriterion("FWALL_CONF_CNG_FLG not between", value1, value2, "FWALL_CONF_CNG_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_FLGIsNull() {
            addCriterion("PROXY_FLG is null");
            return (Criteria) this;
        }

        public Criteria andPROXY_FLGIsNotNull() {
            addCriterion("PROXY_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andPROXY_FLGEqualTo(String value) {
            addCriterion("PROXY_FLG =", value, "PROXY_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_FLGNotEqualTo(String value) {
            addCriterion("PROXY_FLG <>", value, "PROXY_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_FLGGreaterThan(String value) {
            addCriterion("PROXY_FLG >", value, "PROXY_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("PROXY_FLG >=", value, "PROXY_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_FLGLessThan(String value) {
            addCriterion("PROXY_FLG <", value, "PROXY_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_FLGLessThanOrEqualTo(String value) {
            addCriterion("PROXY_FLG <=", value, "PROXY_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_FLGLike(String value) {
            addCriterion("PROXY_FLG like", value, "PROXY_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_FLGNotLike(String value) {
            addCriterion("PROXY_FLG not like", value, "PROXY_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_FLGIn(List<String> values) {
            addCriterion("PROXY_FLG in", values, "PROXY_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_FLGNotIn(List<String> values) {
            addCriterion("PROXY_FLG not in", values, "PROXY_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_FLGBetween(String value1, String value2) {
            addCriterion("PROXY_FLG between", value1, value2, "PROXY_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_FLGNotBetween(String value1, String value2) {
            addCriterion("PROXY_FLG not between", value1, value2, "PROXY_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_VPN_FLGIsNull() {
            addCriterion("PROXY_VPN_FLG is null");
            return (Criteria) this;
        }

        public Criteria andPROXY_VPN_FLGIsNotNull() {
            addCriterion("PROXY_VPN_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andPROXY_VPN_FLGEqualTo(String value) {
            addCriterion("PROXY_VPN_FLG =", value, "PROXY_VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_VPN_FLGNotEqualTo(String value) {
            addCriterion("PROXY_VPN_FLG <>", value, "PROXY_VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_VPN_FLGGreaterThan(String value) {
            addCriterion("PROXY_VPN_FLG >", value, "PROXY_VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_VPN_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("PROXY_VPN_FLG >=", value, "PROXY_VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_VPN_FLGLessThan(String value) {
            addCriterion("PROXY_VPN_FLG <", value, "PROXY_VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_VPN_FLGLessThanOrEqualTo(String value) {
            addCriterion("PROXY_VPN_FLG <=", value, "PROXY_VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_VPN_FLGLike(String value) {
            addCriterion("PROXY_VPN_FLG like", value, "PROXY_VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_VPN_FLGNotLike(String value) {
            addCriterion("PROXY_VPN_FLG not like", value, "PROXY_VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_VPN_FLGIn(List<String> values) {
            addCriterion("PROXY_VPN_FLG in", values, "PROXY_VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_VPN_FLGNotIn(List<String> values) {
            addCriterion("PROXY_VPN_FLG not in", values, "PROXY_VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_VPN_FLGBetween(String value1, String value2) {
            addCriterion("PROXY_VPN_FLG between", value1, value2, "PROXY_VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_VPN_FLGNotBetween(String value1, String value2) {
            addCriterion("PROXY_VPN_FLG not between", value1, value2, "PROXY_VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_CONF_CNG_FLGIsNull() {
            addCriterion("PROXY_CONF_CNG_FLG is null");
            return (Criteria) this;
        }

        public Criteria andPROXY_CONF_CNG_FLGIsNotNull() {
            addCriterion("PROXY_CONF_CNG_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andPROXY_CONF_CNG_FLGEqualTo(String value) {
            addCriterion("PROXY_CONF_CNG_FLG =", value, "PROXY_CONF_CNG_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_CONF_CNG_FLGNotEqualTo(String value) {
            addCriterion("PROXY_CONF_CNG_FLG <>", value, "PROXY_CONF_CNG_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_CONF_CNG_FLGGreaterThan(String value) {
            addCriterion("PROXY_CONF_CNG_FLG >", value, "PROXY_CONF_CNG_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_CONF_CNG_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("PROXY_CONF_CNG_FLG >=", value, "PROXY_CONF_CNG_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_CONF_CNG_FLGLessThan(String value) {
            addCriterion("PROXY_CONF_CNG_FLG <", value, "PROXY_CONF_CNG_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_CONF_CNG_FLGLessThanOrEqualTo(String value) {
            addCriterion("PROXY_CONF_CNG_FLG <=", value, "PROXY_CONF_CNG_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_CONF_CNG_FLGLike(String value) {
            addCriterion("PROXY_CONF_CNG_FLG like", value, "PROXY_CONF_CNG_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_CONF_CNG_FLGNotLike(String value) {
            addCriterion("PROXY_CONF_CNG_FLG not like", value, "PROXY_CONF_CNG_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_CONF_CNG_FLGIn(List<String> values) {
            addCriterion("PROXY_CONF_CNG_FLG in", values, "PROXY_CONF_CNG_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_CONF_CNG_FLGNotIn(List<String> values) {
            addCriterion("PROXY_CONF_CNG_FLG not in", values, "PROXY_CONF_CNG_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_CONF_CNG_FLGBetween(String value1, String value2) {
            addCriterion("PROXY_CONF_CNG_FLG between", value1, value2, "PROXY_CONF_CNG_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_CONF_CNG_FLGNotBetween(String value1, String value2) {
            addCriterion("PROXY_CONF_CNG_FLG not between", value1, value2, "PROXY_CONF_CNG_FLG");
            return (Criteria) this;
        }

        public Criteria andLAN_PORT_FLGIsNull() {
            addCriterion("LAN_PORT_FLG is null");
            return (Criteria) this;
        }

        public Criteria andLAN_PORT_FLGIsNotNull() {
            addCriterion("LAN_PORT_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andLAN_PORT_FLGEqualTo(String value) {
            addCriterion("LAN_PORT_FLG =", value, "LAN_PORT_FLG");
            return (Criteria) this;
        }

        public Criteria andLAN_PORT_FLGNotEqualTo(String value) {
            addCriterion("LAN_PORT_FLG <>", value, "LAN_PORT_FLG");
            return (Criteria) this;
        }

        public Criteria andLAN_PORT_FLGGreaterThan(String value) {
            addCriterion("LAN_PORT_FLG >", value, "LAN_PORT_FLG");
            return (Criteria) this;
        }

        public Criteria andLAN_PORT_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("LAN_PORT_FLG >=", value, "LAN_PORT_FLG");
            return (Criteria) this;
        }

        public Criteria andLAN_PORT_FLGLessThan(String value) {
            addCriterion("LAN_PORT_FLG <", value, "LAN_PORT_FLG");
            return (Criteria) this;
        }

        public Criteria andLAN_PORT_FLGLessThanOrEqualTo(String value) {
            addCriterion("LAN_PORT_FLG <=", value, "LAN_PORT_FLG");
            return (Criteria) this;
        }

        public Criteria andLAN_PORT_FLGLike(String value) {
            addCriterion("LAN_PORT_FLG like", value, "LAN_PORT_FLG");
            return (Criteria) this;
        }

        public Criteria andLAN_PORT_FLGNotLike(String value) {
            addCriterion("LAN_PORT_FLG not like", value, "LAN_PORT_FLG");
            return (Criteria) this;
        }

        public Criteria andLAN_PORT_FLGIn(List<String> values) {
            addCriterion("LAN_PORT_FLG in", values, "LAN_PORT_FLG");
            return (Criteria) this;
        }

        public Criteria andLAN_PORT_FLGNotIn(List<String> values) {
            addCriterion("LAN_PORT_FLG not in", values, "LAN_PORT_FLG");
            return (Criteria) this;
        }

        public Criteria andLAN_PORT_FLGBetween(String value1, String value2) {
            addCriterion("LAN_PORT_FLG between", value1, value2, "LAN_PORT_FLG");
            return (Criteria) this;
        }

        public Criteria andLAN_PORT_FLGNotBetween(String value1, String value2) {
            addCriterion("LAN_PORT_FLG not between", value1, value2, "LAN_PORT_FLG");
            return (Criteria) this;
        }

        public Criteria andNETWORK_DEV_FLGIsNull() {
            addCriterion("NETWORK_DEV_FLG is null");
            return (Criteria) this;
        }

        public Criteria andNETWORK_DEV_FLGIsNotNull() {
            addCriterion("NETWORK_DEV_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andNETWORK_DEV_FLGEqualTo(String value) {
            addCriterion("NETWORK_DEV_FLG =", value, "NETWORK_DEV_FLG");
            return (Criteria) this;
        }

        public Criteria andNETWORK_DEV_FLGNotEqualTo(String value) {
            addCriterion("NETWORK_DEV_FLG <>", value, "NETWORK_DEV_FLG");
            return (Criteria) this;
        }

        public Criteria andNETWORK_DEV_FLGGreaterThan(String value) {
            addCriterion("NETWORK_DEV_FLG >", value, "NETWORK_DEV_FLG");
            return (Criteria) this;
        }

        public Criteria andNETWORK_DEV_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("NETWORK_DEV_FLG >=", value, "NETWORK_DEV_FLG");
            return (Criteria) this;
        }

        public Criteria andNETWORK_DEV_FLGLessThan(String value) {
            addCriterion("NETWORK_DEV_FLG <", value, "NETWORK_DEV_FLG");
            return (Criteria) this;
        }

        public Criteria andNETWORK_DEV_FLGLessThanOrEqualTo(String value) {
            addCriterion("NETWORK_DEV_FLG <=", value, "NETWORK_DEV_FLG");
            return (Criteria) this;
        }

        public Criteria andNETWORK_DEV_FLGLike(String value) {
            addCriterion("NETWORK_DEV_FLG like", value, "NETWORK_DEV_FLG");
            return (Criteria) this;
        }

        public Criteria andNETWORK_DEV_FLGNotLike(String value) {
            addCriterion("NETWORK_DEV_FLG not like", value, "NETWORK_DEV_FLG");
            return (Criteria) this;
        }

        public Criteria andNETWORK_DEV_FLGIn(List<String> values) {
            addCriterion("NETWORK_DEV_FLG in", values, "NETWORK_DEV_FLG");
            return (Criteria) this;
        }

        public Criteria andNETWORK_DEV_FLGNotIn(List<String> values) {
            addCriterion("NETWORK_DEV_FLG not in", values, "NETWORK_DEV_FLG");
            return (Criteria) this;
        }

        public Criteria andNETWORK_DEV_FLGBetween(String value1, String value2) {
            addCriterion("NETWORK_DEV_FLG between", value1, value2, "NETWORK_DEV_FLG");
            return (Criteria) this;
        }

        public Criteria andNETWORK_DEV_FLGNotBetween(String value1, String value2) {
            addCriterion("NETWORK_DEV_FLG not between", value1, value2, "NETWORK_DEV_FLG");
            return (Criteria) this;
        }

        public Criteria andPROVDE_MDM_MAKER_FLGIsNull() {
            addCriterion("PROVDE_MDM_MAKER_FLG is null");
            return (Criteria) this;
        }

        public Criteria andPROVDE_MDM_MAKER_FLGIsNotNull() {
            addCriterion("PROVDE_MDM_MAKER_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andPROVDE_MDM_MAKER_FLGEqualTo(String value) {
            addCriterion("PROVDE_MDM_MAKER_FLG =", value, "PROVDE_MDM_MAKER_FLG");
            return (Criteria) this;
        }

        public Criteria andPROVDE_MDM_MAKER_FLGNotEqualTo(String value) {
            addCriterion("PROVDE_MDM_MAKER_FLG <>", value, "PROVDE_MDM_MAKER_FLG");
            return (Criteria) this;
        }

        public Criteria andPROVDE_MDM_MAKER_FLGGreaterThan(String value) {
            addCriterion("PROVDE_MDM_MAKER_FLG >", value, "PROVDE_MDM_MAKER_FLG");
            return (Criteria) this;
        }

        public Criteria andPROVDE_MDM_MAKER_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("PROVDE_MDM_MAKER_FLG >=", value, "PROVDE_MDM_MAKER_FLG");
            return (Criteria) this;
        }

        public Criteria andPROVDE_MDM_MAKER_FLGLessThan(String value) {
            addCriterion("PROVDE_MDM_MAKER_FLG <", value, "PROVDE_MDM_MAKER_FLG");
            return (Criteria) this;
        }

        public Criteria andPROVDE_MDM_MAKER_FLGLessThanOrEqualTo(String value) {
            addCriterion("PROVDE_MDM_MAKER_FLG <=", value, "PROVDE_MDM_MAKER_FLG");
            return (Criteria) this;
        }

        public Criteria andPROVDE_MDM_MAKER_FLGLike(String value) {
            addCriterion("PROVDE_MDM_MAKER_FLG like", value, "PROVDE_MDM_MAKER_FLG");
            return (Criteria) this;
        }

        public Criteria andPROVDE_MDM_MAKER_FLGNotLike(String value) {
            addCriterion("PROVDE_MDM_MAKER_FLG not like", value, "PROVDE_MDM_MAKER_FLG");
            return (Criteria) this;
        }

        public Criteria andPROVDE_MDM_MAKER_FLGIn(List<String> values) {
            addCriterion("PROVDE_MDM_MAKER_FLG in", values, "PROVDE_MDM_MAKER_FLG");
            return (Criteria) this;
        }

        public Criteria andPROVDE_MDM_MAKER_FLGNotIn(List<String> values) {
            addCriterion("PROVDE_MDM_MAKER_FLG not in", values, "PROVDE_MDM_MAKER_FLG");
            return (Criteria) this;
        }

        public Criteria andPROVDE_MDM_MAKER_FLGBetween(String value1, String value2) {
            addCriterion("PROVDE_MDM_MAKER_FLG between", value1, value2, "PROVDE_MDM_MAKER_FLG");
            return (Criteria) this;
        }

        public Criteria andPROVDE_MDM_MAKER_FLGNotBetween(String value1, String value2) {
            addCriterion("PROVDE_MDM_MAKER_FLG not between", value1, value2, "PROVDE_MDM_MAKER_FLG");
            return (Criteria) this;
        }

        public Criteria andMDM_NM_FLGIsNull() {
            addCriterion("MDM_NM_FLG is null");
            return (Criteria) this;
        }

        public Criteria andMDM_NM_FLGIsNotNull() {
            addCriterion("MDM_NM_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andMDM_NM_FLGEqualTo(String value) {
            addCriterion("MDM_NM_FLG =", value, "MDM_NM_FLG");
            return (Criteria) this;
        }

        public Criteria andMDM_NM_FLGNotEqualTo(String value) {
            addCriterion("MDM_NM_FLG <>", value, "MDM_NM_FLG");
            return (Criteria) this;
        }

        public Criteria andMDM_NM_FLGGreaterThan(String value) {
            addCriterion("MDM_NM_FLG >", value, "MDM_NM_FLG");
            return (Criteria) this;
        }

        public Criteria andMDM_NM_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("MDM_NM_FLG >=", value, "MDM_NM_FLG");
            return (Criteria) this;
        }

        public Criteria andMDM_NM_FLGLessThan(String value) {
            addCriterion("MDM_NM_FLG <", value, "MDM_NM_FLG");
            return (Criteria) this;
        }

        public Criteria andMDM_NM_FLGLessThanOrEqualTo(String value) {
            addCriterion("MDM_NM_FLG <=", value, "MDM_NM_FLG");
            return (Criteria) this;
        }

        public Criteria andMDM_NM_FLGLike(String value) {
            addCriterion("MDM_NM_FLG like", value, "MDM_NM_FLG");
            return (Criteria) this;
        }

        public Criteria andMDM_NM_FLGNotLike(String value) {
            addCriterion("MDM_NM_FLG not like", value, "MDM_NM_FLG");
            return (Criteria) this;
        }

        public Criteria andMDM_NM_FLGIn(List<String> values) {
            addCriterion("MDM_NM_FLG in", values, "MDM_NM_FLG");
            return (Criteria) this;
        }

        public Criteria andMDM_NM_FLGNotIn(List<String> values) {
            addCriterion("MDM_NM_FLG not in", values, "MDM_NM_FLG");
            return (Criteria) this;
        }

        public Criteria andMDM_NM_FLGBetween(String value1, String value2) {
            addCriterion("MDM_NM_FLG between", value1, value2, "MDM_NM_FLG");
            return (Criteria) this;
        }

        public Criteria andMDM_NM_FLGNotBetween(String value1, String value2) {
            addCriterion("MDM_NM_FLG not between", value1, value2, "MDM_NM_FLG");
            return (Criteria) this;
        }

        public Criteria andBIKOUIsNull() {
            addCriterion("BIKOU is null");
            return (Criteria) this;
        }

        public Criteria andBIKOUIsNotNull() {
            addCriterion("BIKOU is not null");
            return (Criteria) this;
        }

        public Criteria andBIKOUEqualTo(String value) {
            addCriterion("BIKOU =", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUNotEqualTo(String value) {
            addCriterion("BIKOU <>", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUGreaterThan(String value) {
            addCriterion("BIKOU >", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUGreaterThanOrEqualTo(String value) {
            addCriterion("BIKOU >=", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOULessThan(String value) {
            addCriterion("BIKOU <", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOULessThanOrEqualTo(String value) {
            addCriterion("BIKOU <=", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOULike(String value) {
            addCriterion("BIKOU like", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUNotLike(String value) {
            addCriterion("BIKOU not like", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUIn(List<String> values) {
            addCriterion("BIKOU in", values, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUNotIn(List<String> values) {
            addCriterion("BIKOU not in", values, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUBetween(String value1, String value2) {
            addCriterion("BIKOU between", value1, value2, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUNotBetween(String value1, String value2) {
            addCriterion("BIKOU not between", value1, value2, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andLN_CTL_DEVLikeInsensitive(String value) {
            addCriterion("upper(LN_CTL_DEV) like", value.toUpperCase(), "LN_CTL_DEV");
            return (Criteria) this;
        }

        public Criteria andLINE_FLGLikeInsensitive(String value) {
            addCriterion("upper(LINE_FLG) like", value.toUpperCase(), "LINE_FLG");
            return (Criteria) this;
        }

        public Criteria andISP_NMLikeInsensitive(String value) {
            addCriterion("upper(ISP_NM) like", value.toUpperCase(), "ISP_NM");
            return (Criteria) this;
        }

        public Criteria andLINE_CAREER_NMLikeInsensitive(String value) {
            addCriterion("upper(LINE_CAREER_NM) like", value.toUpperCase(), "LINE_CAREER_NM");
            return (Criteria) this;
        }

        public Criteria andLINE_NMLikeInsensitive(String value) {
            addCriterion("upper(LINE_NM) like", value.toUpperCase(), "LINE_NM");
            return (Criteria) this;
        }

        public Criteria andCONN_FLGLikeInsensitive(String value) {
            addCriterion("upper(CONN_FLG) like", value.toUpperCase(), "CONN_FLG");
            return (Criteria) this;
        }

        public Criteria andMDM_MAKER_NMLikeInsensitive(String value) {
            addCriterion("upper(MDM_MAKER_NM) like", value.toUpperCase(), "MDM_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andMDM_NMLikeInsensitive(String value) {
            addCriterion("upper(MDM_NM) like", value.toUpperCase(), "MDM_NM");
            return (Criteria) this;
        }

        public Criteria andROUTER_MAKER_NMLikeInsensitive(String value) {
            addCriterion("upper(ROUTER_MAKER_NM) like", value.toUpperCase(), "ROUTER_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andROUTER_NMLikeInsensitive(String value) {
            addCriterion("upper(ROUTER_NM) like", value.toUpperCase(), "ROUTER_NM");
            return (Criteria) this;
        }

        public Criteria andHUB_MAKER_NMLikeInsensitive(String value) {
            addCriterion("upper(HUB_MAKER_NM) like", value.toUpperCase(), "HUB_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andHUB_NMLikeInsensitive(String value) {
            addCriterion("upper(HUB_NM) like", value.toUpperCase(), "HUB_NM");
            return (Criteria) this;
        }

        public Criteria andONU_MAKER_NMLikeInsensitive(String value) {
            addCriterion("upper(ONU_MAKER_NM) like", value.toUpperCase(), "ONU_MAKER_NM");
            return (Criteria) this;
        }

        public Criteria andONU_NMLikeInsensitive(String value) {
            addCriterion("upper(ONU_NM) like", value.toUpperCase(), "ONU_NM");
            return (Criteria) this;
        }

        public Criteria andVPN_FLGLikeInsensitive(String value) {
            addCriterion("upper(VPN_FLG) like", value.toUpperCase(), "VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andVOIP_FLGLikeInsensitive(String value) {
            addCriterion("upper(VOIP_FLG) like", value.toUpperCase(), "VOIP_FLG");
            return (Criteria) this;
        }

        public Criteria andPC_CONN_NUMLikeInsensitive(String value) {
            addCriterion("upper(PC_CONN_NUM) like", value.toUpperCase(), "PC_CONN_NUM");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_FLGLikeInsensitive(String value) {
            addCriterion("upper(ETC_CONN_FLG) like", value.toUpperCase(), "ETC_CONN_FLG");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NUMLikeInsensitive(String value) {
            addCriterion("upper(ETC_CONN_NUM) like", value.toUpperCase(), "ETC_CONN_NUM");
            return (Criteria) this;
        }

        public Criteria andETC_CONN_NMLikeInsensitive(String value) {
            addCriterion("upper(ETC_CONN_NM) like", value.toUpperCase(), "ETC_CONN_NM");
            return (Criteria) this;
        }

        public Criteria andUPS_FLGLikeInsensitive(String value) {
            addCriterion("upper(UPS_FLG) like", value.toUpperCase(), "UPS_FLG");
            return (Criteria) this;
        }

        public Criteria andUPS_PERMIT_FLGLikeInsensitive(String value) {
            addCriterion("upper(UPS_PERMIT_FLG) like", value.toUpperCase(), "UPS_PERMIT_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_FLGLikeInsensitive(String value) {
            addCriterion("upper(FWALL_FLG) like", value.toUpperCase(), "FWALL_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_VPN_FLGLikeInsensitive(String value) {
            addCriterion("upper(FWALL_VPN_FLG) like", value.toUpperCase(), "FWALL_VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andFWALL_CONF_CNG_FLGLikeInsensitive(String value) {
            addCriterion("upper(FWALL_CONF_CNG_FLG) like", value.toUpperCase(), "FWALL_CONF_CNG_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_FLGLikeInsensitive(String value) {
            addCriterion("upper(PROXY_FLG) like", value.toUpperCase(), "PROXY_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_VPN_FLGLikeInsensitive(String value) {
            addCriterion("upper(PROXY_VPN_FLG) like", value.toUpperCase(), "PROXY_VPN_FLG");
            return (Criteria) this;
        }

        public Criteria andPROXY_CONF_CNG_FLGLikeInsensitive(String value) {
            addCriterion("upper(PROXY_CONF_CNG_FLG) like", value.toUpperCase(), "PROXY_CONF_CNG_FLG");
            return (Criteria) this;
        }

        public Criteria andLAN_PORT_FLGLikeInsensitive(String value) {
            addCriterion("upper(LAN_PORT_FLG) like", value.toUpperCase(), "LAN_PORT_FLG");
            return (Criteria) this;
        }

        public Criteria andNETWORK_DEV_FLGLikeInsensitive(String value) {
            addCriterion("upper(NETWORK_DEV_FLG) like", value.toUpperCase(), "NETWORK_DEV_FLG");
            return (Criteria) this;
        }

        public Criteria andPROVDE_MDM_MAKER_FLGLikeInsensitive(String value) {
            addCriterion("upper(PROVDE_MDM_MAKER_FLG) like", value.toUpperCase(), "PROVDE_MDM_MAKER_FLG");
            return (Criteria) this;
        }

        public Criteria andMDM_NM_FLGLikeInsensitive(String value) {
            addCriterion("upper(MDM_NM_FLG) like", value.toUpperCase(), "MDM_NM_FLG");
            return (Criteria) this;
        }

        public Criteria andBIKOULikeInsensitive(String value) {
            addCriterion("upper(BIKOU) like", value.toUpperCase(), "BIKOU");
            return (Criteria) this;
        }
    }

    /**
     * M_CTL_DEV_LINE_INF
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * M_CTL_DEV_LINE_INF null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}