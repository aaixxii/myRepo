package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class IMngAccumulate implements Serializable {
    /**
     * LN_蓄積画像音声論理番号
     */
    private String LN_ACUM_IMGVOC;

    /**
     * 論理削除フラグ
     */
    private String DEL_FLG;

    /**
     * LN_設置機器論理番号
     */
    private String LN_DEV;

    /**
     * カメラ番号
     */
    private String CAMR_NUM;

    /**
     * 撮影開始日時
     */
    private Date SHOT_STT_TSTM;

    /**
     * 撮影終了日時
     */
    private Date SHOT_END_TSTM;

    /**
     * 保存先
     */
    private String SAVE_PATH;

    /**
     * ファイル名
     */
    private String FILE_NM;

    /**
     * ファイルサイズ
     */
    private Integer FILE_SIZE;

    /**
     * フレームレート
     */
    private String FL_RATE;

    /**
     * 画質
     */
    private String QUALITY;

    /**
     * 画像サイズ
     */
    private String PX_SIZE;

    /**
     * 符号化方式
     */
    private String ENCD_TY;

    /**
     * GOPフレームレート
     */
    private String GOP_FL_RATE;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * I_MNG_ACCUMULATE
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_蓄積画像音声論理番号
     * @return LN_ACUM_IMGVOC LN_蓄積画像音声論理番号
     */
    public String getLN_ACUM_IMGVOC() {
        return LN_ACUM_IMGVOC;
    }

    /**
     * LN_蓄積画像音声論理番号
     * @param LN_ACUM_IMGVOC LN_蓄積画像音声論理番号
     */
    public void setLN_ACUM_IMGVOC(String LN_ACUM_IMGVOC) {
        this.LN_ACUM_IMGVOC = LN_ACUM_IMGVOC == null ? null : LN_ACUM_IMGVOC.trim();
    }

    /**
     * 論理削除フラグ
     * @return DEL_FLG 論理削除フラグ
     */
    public String getDEL_FLG() {
        return DEL_FLG;
    }

    /**
     * 論理削除フラグ
     * @param DEL_FLG 論理削除フラグ
     */
    public void setDEL_FLG(String DEL_FLG) {
        this.DEL_FLG = DEL_FLG == null ? null : DEL_FLG.trim();
    }

    /**
     * LN_設置機器論理番号
     * @return LN_DEV LN_設置機器論理番号
     */
    public String getLN_DEV() {
        return LN_DEV;
    }

    /**
     * LN_設置機器論理番号
     * @param LN_DEV LN_設置機器論理番号
     */
    public void setLN_DEV(String LN_DEV) {
        this.LN_DEV = LN_DEV == null ? null : LN_DEV.trim();
    }

    /**
     * カメラ番号
     * @return CAMR_NUM カメラ番号
     */
    public String getCAMR_NUM() {
        return CAMR_NUM;
    }

    /**
     * カメラ番号
     * @param CAMR_NUM カメラ番号
     */
    public void setCAMR_NUM(String CAMR_NUM) {
        this.CAMR_NUM = CAMR_NUM == null ? null : CAMR_NUM.trim();
    }

    /**
     * 撮影開始日時
     * @return SHOT_STT_TSTM 撮影開始日時
     */
    public Date getSHOT_STT_TSTM() {
        return SHOT_STT_TSTM;
    }

    /**
     * 撮影開始日時
     * @param SHOT_STT_TSTM 撮影開始日時
     */
    public void setSHOT_STT_TSTM(Date SHOT_STT_TSTM) {
        this.SHOT_STT_TSTM = SHOT_STT_TSTM;
    }

    /**
     * 撮影終了日時
     * @return SHOT_END_TSTM 撮影終了日時
     */
    public Date getSHOT_END_TSTM() {
        return SHOT_END_TSTM;
    }

    /**
     * 撮影終了日時
     * @param SHOT_END_TSTM 撮影終了日時
     */
    public void setSHOT_END_TSTM(Date SHOT_END_TSTM) {
        this.SHOT_END_TSTM = SHOT_END_TSTM;
    }

    /**
     * 保存先
     * @return SAVE_PATH 保存先
     */
    public String getSAVE_PATH() {
        return SAVE_PATH;
    }

    /**
     * 保存先
     * @param SAVE_PATH 保存先
     */
    public void setSAVE_PATH(String SAVE_PATH) {
        this.SAVE_PATH = SAVE_PATH == null ? null : SAVE_PATH.trim();
    }

    /**
     * ファイル名
     * @return FILE_NM ファイル名
     */
    public String getFILE_NM() {
        return FILE_NM;
    }

    /**
     * ファイル名
     * @param FILE_NM ファイル名
     */
    public void setFILE_NM(String FILE_NM) {
        this.FILE_NM = FILE_NM == null ? null : FILE_NM.trim();
    }

    /**
     * ファイルサイズ
     * @return FILE_SIZE ファイルサイズ
     */
    public Integer getFILE_SIZE() {
        return FILE_SIZE;
    }

    /**
     * ファイルサイズ
     * @param FILE_SIZE ファイルサイズ
     */
    public void setFILE_SIZE(Integer FILE_SIZE) {
        this.FILE_SIZE = FILE_SIZE;
    }

    /**
     * フレームレート
     * @return FL_RATE フレームレート
     */
    public String getFL_RATE() {
        return FL_RATE;
    }

    /**
     * フレームレート
     * @param FL_RATE フレームレート
     */
    public void setFL_RATE(String FL_RATE) {
        this.FL_RATE = FL_RATE == null ? null : FL_RATE.trim();
    }

    /**
     * 画質
     * @return QUALITY 画質
     */
    public String getQUALITY() {
        return QUALITY;
    }

    /**
     * 画質
     * @param QUALITY 画質
     */
    public void setQUALITY(String QUALITY) {
        this.QUALITY = QUALITY == null ? null : QUALITY.trim();
    }

    /**
     * 画像サイズ
     * @return PX_SIZE 画像サイズ
     */
    public String getPX_SIZE() {
        return PX_SIZE;
    }

    /**
     * 画像サイズ
     * @param PX_SIZE 画像サイズ
     */
    public void setPX_SIZE(String PX_SIZE) {
        this.PX_SIZE = PX_SIZE == null ? null : PX_SIZE.trim();
    }

    /**
     * 符号化方式
     * @return ENCD_TY 符号化方式
     */
    public String getENCD_TY() {
        return ENCD_TY;
    }

    /**
     * 符号化方式
     * @param ENCD_TY 符号化方式
     */
    public void setENCD_TY(String ENCD_TY) {
        this.ENCD_TY = ENCD_TY == null ? null : ENCD_TY.trim();
    }

    /**
     * GOPフレームレート
     * @return GOP_FL_RATE GOPフレームレート
     */
    public String getGOP_FL_RATE() {
        return GOP_FL_RATE;
    }

    /**
     * GOPフレームレート
     * @param GOP_FL_RATE GOPフレームレート
     */
    public void setGOP_FL_RATE(String GOP_FL_RATE) {
        this.GOP_FL_RATE = GOP_FL_RATE == null ? null : GOP_FL_RATE.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}