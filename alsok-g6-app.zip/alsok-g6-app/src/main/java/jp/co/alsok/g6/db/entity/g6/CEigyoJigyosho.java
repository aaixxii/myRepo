package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class CEigyoJigyosho extends CEigyoJigyoshoKey implements Serializable {
    /**
     * 適用開始年月日
     */
    private String TEKIYO_KAISHI_YMD;

    /**
     * 適用終了年月日
     */
    private String TEKIYO_SHURYO_YMD;

    /**
     * 事業所区分
     */
    private String JIGYOSHO_KBN;

    /**
     * 事業所名称
     */
    private String JIGYOSHO_NM;

    /**
     * 事業所カナ名称
     */
    private String JIGYOSHO_KN_NM;

    /**
     * 事業所略称
     */
    private String JIGYOSHO_RNM;

    /**
     * 住所コード
     */
    private String JUSHO_CD;

    /**
     * 都道府県名称
     */
    private String TODOFUKEN_NM;

    /**
     * 市区町村名称
     */
    private String SHIKUCHOSON_NM;

    /**
     * 大字名称
     */
    private String OAZA_NM;

    /**
     * 丁目名称
     */
    private String CHOME_NM;

    /**
     * 補足住所１
     */
    private String HOSOKU_JUSHO_1;

    /**
     * 郵便番号
     */
    private String YUBIN_NO;

    /**
     * 住所番地
     */
    private String JUSHO_BANCHI;

    /**
     * 建物名称
     */
    private String TATEMONO_NM;

    /**
     * 建物カナ名称
     */
    private String TATEMONO_KN_NM;

    /**
     * 棟名称
     */
    private String TO_NM;

    /**
     * 階名称
     */
    private String KAI_NM;

    /**
     * 区画名称
     */
    private String KUKAKU_NM;

    /**
     * 部屋名称
     */
    private String HEYA_NM;

    /**
     * 電話番号
     */
    private String DENWA_NO;

    /**
     * 代表メールアドレス
     */
    private String DAIHYO_MAIL_ADDRESS;

    /**
     * 労務単価金額
     */
    private Long ROMU_TANKA_AMT;

    /**
     * 支払事業所コード
     */
    private String SHIHARAI_JIGYOSHO_CD;

    /**
     * 支払事業所名称
     */
    private String SHIHARAI_JIGYOSHO_NM;

    /**
     * 入金事業所コード
     */
    private String NYUKIN_JIGYOSHO_CD;

    /**
     * 入金事業所名称
     */
    private String NYUKIN_JIGYOSHO_NM;

    /**
     * 自社口座コード
     */
    private String JISHA_KOZA_CD;

    /**
     * 自社口座名称
     */
    private String JISHA_KOZA_NM;

    /**
     * 予備項目01
     */
    private String YOBI_KOMOKU_01;

    /**
     * 予備項目02
     */
    private String YOBI_KOMOKU_02;

    /**
     * 予備項目03
     */
    private String YOBI_KOMOKU_03;

    /**
     * 予備項目04
     */
    private String YOBI_KOMOKU_04;

    /**
     * 予備項目05
     */
    private String YOBI_KOMOKU_05;

    /**
     * 予備項目06
     */
    private String YOBI_KOMOKU_06;

    /**
     * 予備項目07
     */
    private String YOBI_KOMOKU_07;

    /**
     * 予備項目08
     */
    private String YOBI_KOMOKU_08;

    /**
     * 予備項目09
     */
    private String YOBI_KOMOKU_09;

    /**
     * 予備項目10
     */
    private String YOBI_KOMOKU_10;

    /**
     * 登録タイムスタンプ
     */
    private Date REGST_TMSTMP;

    /**
     * 登録者会社コード
     */
    private String REGSTR_CO_CD;

    /**
     * 登録者組織コード
     */
    private String REGSTR_SOSHIKI_CD;

    /**
     * 登録者社員番号
     */
    private String REGSTR_EMP_NO;

    /**
     * 登録画面ＩＤ
     */
    private String REGST_GAMEN_ID;

    /**
     * 登録プログラムＩＤ
     */
    private String REGST_PGM_ID;

    /**
     * 更新タイムスタンプ
     */
    private Date UPD_TMSTMP;

    /**
     * 更新者会社コード
     */
    private String UPDTR_CO_CD;

    /**
     * 更新者組織コード
     */
    private String UPDTR_SOSHIKI_CD;

    /**
     * 更新者社員番号
     */
    private String UPDTR_EMP_NO;

    /**
     * 更新画面ＩＤ
     */
    private String UPD_GAMEN_ID;

    /**
     * 更新プログラムＩＤ
     */
    private String UPD_PGM_ID;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * C_EIGYO_JIGYOSHO
     */
    private static final long serialVersionUID = 1L;

    /**
     * 適用開始年月日
     * @return TEKIYO_KAISHI_YMD 適用開始年月日
     */
    public String getTEKIYO_KAISHI_YMD() {
        return TEKIYO_KAISHI_YMD;
    }

    /**
     * 適用開始年月日
     * @param TEKIYO_KAISHI_YMD 適用開始年月日
     */
    public void setTEKIYO_KAISHI_YMD(String TEKIYO_KAISHI_YMD) {
        this.TEKIYO_KAISHI_YMD = TEKIYO_KAISHI_YMD == null ? null : TEKIYO_KAISHI_YMD.trim();
    }

    /**
     * 適用終了年月日
     * @return TEKIYO_SHURYO_YMD 適用終了年月日
     */
    public String getTEKIYO_SHURYO_YMD() {
        return TEKIYO_SHURYO_YMD;
    }

    /**
     * 適用終了年月日
     * @param TEKIYO_SHURYO_YMD 適用終了年月日
     */
    public void setTEKIYO_SHURYO_YMD(String TEKIYO_SHURYO_YMD) {
        this.TEKIYO_SHURYO_YMD = TEKIYO_SHURYO_YMD == null ? null : TEKIYO_SHURYO_YMD.trim();
    }

    /**
     * 事業所区分
     * @return JIGYOSHO_KBN 事業所区分
     */
    public String getJIGYOSHO_KBN() {
        return JIGYOSHO_KBN;
    }

    /**
     * 事業所区分
     * @param JIGYOSHO_KBN 事業所区分
     */
    public void setJIGYOSHO_KBN(String JIGYOSHO_KBN) {
        this.JIGYOSHO_KBN = JIGYOSHO_KBN == null ? null : JIGYOSHO_KBN.trim();
    }

    /**
     * 事業所名称
     * @return JIGYOSHO_NM 事業所名称
     */
    public String getJIGYOSHO_NM() {
        return JIGYOSHO_NM;
    }

    /**
     * 事業所名称
     * @param JIGYOSHO_NM 事業所名称
     */
    public void setJIGYOSHO_NM(String JIGYOSHO_NM) {
        this.JIGYOSHO_NM = JIGYOSHO_NM == null ? null : JIGYOSHO_NM.trim();
    }

    /**
     * 事業所カナ名称
     * @return JIGYOSHO_KN_NM 事業所カナ名称
     */
    public String getJIGYOSHO_KN_NM() {
        return JIGYOSHO_KN_NM;
    }

    /**
     * 事業所カナ名称
     * @param JIGYOSHO_KN_NM 事業所カナ名称
     */
    public void setJIGYOSHO_KN_NM(String JIGYOSHO_KN_NM) {
        this.JIGYOSHO_KN_NM = JIGYOSHO_KN_NM == null ? null : JIGYOSHO_KN_NM.trim();
    }

    /**
     * 事業所略称
     * @return JIGYOSHO_RNM 事業所略称
     */
    public String getJIGYOSHO_RNM() {
        return JIGYOSHO_RNM;
    }

    /**
     * 事業所略称
     * @param JIGYOSHO_RNM 事業所略称
     */
    public void setJIGYOSHO_RNM(String JIGYOSHO_RNM) {
        this.JIGYOSHO_RNM = JIGYOSHO_RNM == null ? null : JIGYOSHO_RNM.trim();
    }

    /**
     * 住所コード
     * @return JUSHO_CD 住所コード
     */
    public String getJUSHO_CD() {
        return JUSHO_CD;
    }

    /**
     * 住所コード
     * @param JUSHO_CD 住所コード
     */
    public void setJUSHO_CD(String JUSHO_CD) {
        this.JUSHO_CD = JUSHO_CD == null ? null : JUSHO_CD.trim();
    }

    /**
     * 都道府県名称
     * @return TODOFUKEN_NM 都道府県名称
     */
    public String getTODOFUKEN_NM() {
        return TODOFUKEN_NM;
    }

    /**
     * 都道府県名称
     * @param TODOFUKEN_NM 都道府県名称
     */
    public void setTODOFUKEN_NM(String TODOFUKEN_NM) {
        this.TODOFUKEN_NM = TODOFUKEN_NM == null ? null : TODOFUKEN_NM.trim();
    }

    /**
     * 市区町村名称
     * @return SHIKUCHOSON_NM 市区町村名称
     */
    public String getSHIKUCHOSON_NM() {
        return SHIKUCHOSON_NM;
    }

    /**
     * 市区町村名称
     * @param SHIKUCHOSON_NM 市区町村名称
     */
    public void setSHIKUCHOSON_NM(String SHIKUCHOSON_NM) {
        this.SHIKUCHOSON_NM = SHIKUCHOSON_NM == null ? null : SHIKUCHOSON_NM.trim();
    }

    /**
     * 大字名称
     * @return OAZA_NM 大字名称
     */
    public String getOAZA_NM() {
        return OAZA_NM;
    }

    /**
     * 大字名称
     * @param OAZA_NM 大字名称
     */
    public void setOAZA_NM(String OAZA_NM) {
        this.OAZA_NM = OAZA_NM == null ? null : OAZA_NM.trim();
    }

    /**
     * 丁目名称
     * @return CHOME_NM 丁目名称
     */
    public String getCHOME_NM() {
        return CHOME_NM;
    }

    /**
     * 丁目名称
     * @param CHOME_NM 丁目名称
     */
    public void setCHOME_NM(String CHOME_NM) {
        this.CHOME_NM = CHOME_NM == null ? null : CHOME_NM.trim();
    }

    /**
     * 補足住所１
     * @return HOSOKU_JUSHO_1 補足住所１
     */
    public String getHOSOKU_JUSHO_1() {
        return HOSOKU_JUSHO_1;
    }

    /**
     * 補足住所１
     * @param HOSOKU_JUSHO_1 補足住所１
     */
    public void setHOSOKU_JUSHO_1(String HOSOKU_JUSHO_1) {
        this.HOSOKU_JUSHO_1 = HOSOKU_JUSHO_1 == null ? null : HOSOKU_JUSHO_1.trim();
    }

    /**
     * 郵便番号
     * @return YUBIN_NO 郵便番号
     */
    public String getYUBIN_NO() {
        return YUBIN_NO;
    }

    /**
     * 郵便番号
     * @param YUBIN_NO 郵便番号
     */
    public void setYUBIN_NO(String YUBIN_NO) {
        this.YUBIN_NO = YUBIN_NO == null ? null : YUBIN_NO.trim();
    }

    /**
     * 住所番地
     * @return JUSHO_BANCHI 住所番地
     */
    public String getJUSHO_BANCHI() {
        return JUSHO_BANCHI;
    }

    /**
     * 住所番地
     * @param JUSHO_BANCHI 住所番地
     */
    public void setJUSHO_BANCHI(String JUSHO_BANCHI) {
        this.JUSHO_BANCHI = JUSHO_BANCHI == null ? null : JUSHO_BANCHI.trim();
    }

    /**
     * 建物名称
     * @return TATEMONO_NM 建物名称
     */
    public String getTATEMONO_NM() {
        return TATEMONO_NM;
    }

    /**
     * 建物名称
     * @param TATEMONO_NM 建物名称
     */
    public void setTATEMONO_NM(String TATEMONO_NM) {
        this.TATEMONO_NM = TATEMONO_NM == null ? null : TATEMONO_NM.trim();
    }

    /**
     * 建物カナ名称
     * @return TATEMONO_KN_NM 建物カナ名称
     */
    public String getTATEMONO_KN_NM() {
        return TATEMONO_KN_NM;
    }

    /**
     * 建物カナ名称
     * @param TATEMONO_KN_NM 建物カナ名称
     */
    public void setTATEMONO_KN_NM(String TATEMONO_KN_NM) {
        this.TATEMONO_KN_NM = TATEMONO_KN_NM == null ? null : TATEMONO_KN_NM.trim();
    }

    /**
     * 棟名称
     * @return TO_NM 棟名称
     */
    public String getTO_NM() {
        return TO_NM;
    }

    /**
     * 棟名称
     * @param TO_NM 棟名称
     */
    public void setTO_NM(String TO_NM) {
        this.TO_NM = TO_NM == null ? null : TO_NM.trim();
    }

    /**
     * 階名称
     * @return KAI_NM 階名称
     */
    public String getKAI_NM() {
        return KAI_NM;
    }

    /**
     * 階名称
     * @param KAI_NM 階名称
     */
    public void setKAI_NM(String KAI_NM) {
        this.KAI_NM = KAI_NM == null ? null : KAI_NM.trim();
    }

    /**
     * 区画名称
     * @return KUKAKU_NM 区画名称
     */
    public String getKUKAKU_NM() {
        return KUKAKU_NM;
    }

    /**
     * 区画名称
     * @param KUKAKU_NM 区画名称
     */
    public void setKUKAKU_NM(String KUKAKU_NM) {
        this.KUKAKU_NM = KUKAKU_NM == null ? null : KUKAKU_NM.trim();
    }

    /**
     * 部屋名称
     * @return HEYA_NM 部屋名称
     */
    public String getHEYA_NM() {
        return HEYA_NM;
    }

    /**
     * 部屋名称
     * @param HEYA_NM 部屋名称
     */
    public void setHEYA_NM(String HEYA_NM) {
        this.HEYA_NM = HEYA_NM == null ? null : HEYA_NM.trim();
    }

    /**
     * 電話番号
     * @return DENWA_NO 電話番号
     */
    public String getDENWA_NO() {
        return DENWA_NO;
    }

    /**
     * 電話番号
     * @param DENWA_NO 電話番号
     */
    public void setDENWA_NO(String DENWA_NO) {
        this.DENWA_NO = DENWA_NO == null ? null : DENWA_NO.trim();
    }

    /**
     * 代表メールアドレス
     * @return DAIHYO_MAIL_ADDRESS 代表メールアドレス
     */
    public String getDAIHYO_MAIL_ADDRESS() {
        return DAIHYO_MAIL_ADDRESS;
    }

    /**
     * 代表メールアドレス
     * @param DAIHYO_MAIL_ADDRESS 代表メールアドレス
     */
    public void setDAIHYO_MAIL_ADDRESS(String DAIHYO_MAIL_ADDRESS) {
        this.DAIHYO_MAIL_ADDRESS = DAIHYO_MAIL_ADDRESS == null ? null : DAIHYO_MAIL_ADDRESS.trim();
    }

    /**
     * 労務単価金額
     * @return ROMU_TANKA_AMT 労務単価金額
     */
    public Long getROMU_TANKA_AMT() {
        return ROMU_TANKA_AMT;
    }

    /**
     * 労務単価金額
     * @param ROMU_TANKA_AMT 労務単価金額
     */
    public void setROMU_TANKA_AMT(Long ROMU_TANKA_AMT) {
        this.ROMU_TANKA_AMT = ROMU_TANKA_AMT;
    }

    /**
     * 支払事業所コード
     * @return SHIHARAI_JIGYOSHO_CD 支払事業所コード
     */
    public String getSHIHARAI_JIGYOSHO_CD() {
        return SHIHARAI_JIGYOSHO_CD;
    }

    /**
     * 支払事業所コード
     * @param SHIHARAI_JIGYOSHO_CD 支払事業所コード
     */
    public void setSHIHARAI_JIGYOSHO_CD(String SHIHARAI_JIGYOSHO_CD) {
        this.SHIHARAI_JIGYOSHO_CD = SHIHARAI_JIGYOSHO_CD == null ? null : SHIHARAI_JIGYOSHO_CD.trim();
    }

    /**
     * 支払事業所名称
     * @return SHIHARAI_JIGYOSHO_NM 支払事業所名称
     */
    public String getSHIHARAI_JIGYOSHO_NM() {
        return SHIHARAI_JIGYOSHO_NM;
    }

    /**
     * 支払事業所名称
     * @param SHIHARAI_JIGYOSHO_NM 支払事業所名称
     */
    public void setSHIHARAI_JIGYOSHO_NM(String SHIHARAI_JIGYOSHO_NM) {
        this.SHIHARAI_JIGYOSHO_NM = SHIHARAI_JIGYOSHO_NM == null ? null : SHIHARAI_JIGYOSHO_NM.trim();
    }

    /**
     * 入金事業所コード
     * @return NYUKIN_JIGYOSHO_CD 入金事業所コード
     */
    public String getNYUKIN_JIGYOSHO_CD() {
        return NYUKIN_JIGYOSHO_CD;
    }

    /**
     * 入金事業所コード
     * @param NYUKIN_JIGYOSHO_CD 入金事業所コード
     */
    public void setNYUKIN_JIGYOSHO_CD(String NYUKIN_JIGYOSHO_CD) {
        this.NYUKIN_JIGYOSHO_CD = NYUKIN_JIGYOSHO_CD == null ? null : NYUKIN_JIGYOSHO_CD.trim();
    }

    /**
     * 入金事業所名称
     * @return NYUKIN_JIGYOSHO_NM 入金事業所名称
     */
    public String getNYUKIN_JIGYOSHO_NM() {
        return NYUKIN_JIGYOSHO_NM;
    }

    /**
     * 入金事業所名称
     * @param NYUKIN_JIGYOSHO_NM 入金事業所名称
     */
    public void setNYUKIN_JIGYOSHO_NM(String NYUKIN_JIGYOSHO_NM) {
        this.NYUKIN_JIGYOSHO_NM = NYUKIN_JIGYOSHO_NM == null ? null : NYUKIN_JIGYOSHO_NM.trim();
    }

    /**
     * 自社口座コード
     * @return JISHA_KOZA_CD 自社口座コード
     */
    public String getJISHA_KOZA_CD() {
        return JISHA_KOZA_CD;
    }

    /**
     * 自社口座コード
     * @param JISHA_KOZA_CD 自社口座コード
     */
    public void setJISHA_KOZA_CD(String JISHA_KOZA_CD) {
        this.JISHA_KOZA_CD = JISHA_KOZA_CD == null ? null : JISHA_KOZA_CD.trim();
    }

    /**
     * 自社口座名称
     * @return JISHA_KOZA_NM 自社口座名称
     */
    public String getJISHA_KOZA_NM() {
        return JISHA_KOZA_NM;
    }

    /**
     * 自社口座名称
     * @param JISHA_KOZA_NM 自社口座名称
     */
    public void setJISHA_KOZA_NM(String JISHA_KOZA_NM) {
        this.JISHA_KOZA_NM = JISHA_KOZA_NM == null ? null : JISHA_KOZA_NM.trim();
    }

    /**
     * 予備項目01
     * @return YOBI_KOMOKU_01 予備項目01
     */
    public String getYOBI_KOMOKU_01() {
        return YOBI_KOMOKU_01;
    }

    /**
     * 予備項目01
     * @param YOBI_KOMOKU_01 予備項目01
     */
    public void setYOBI_KOMOKU_01(String YOBI_KOMOKU_01) {
        this.YOBI_KOMOKU_01 = YOBI_KOMOKU_01 == null ? null : YOBI_KOMOKU_01.trim();
    }

    /**
     * 予備項目02
     * @return YOBI_KOMOKU_02 予備項目02
     */
    public String getYOBI_KOMOKU_02() {
        return YOBI_KOMOKU_02;
    }

    /**
     * 予備項目02
     * @param YOBI_KOMOKU_02 予備項目02
     */
    public void setYOBI_KOMOKU_02(String YOBI_KOMOKU_02) {
        this.YOBI_KOMOKU_02 = YOBI_KOMOKU_02 == null ? null : YOBI_KOMOKU_02.trim();
    }

    /**
     * 予備項目03
     * @return YOBI_KOMOKU_03 予備項目03
     */
    public String getYOBI_KOMOKU_03() {
        return YOBI_KOMOKU_03;
    }

    /**
     * 予備項目03
     * @param YOBI_KOMOKU_03 予備項目03
     */
    public void setYOBI_KOMOKU_03(String YOBI_KOMOKU_03) {
        this.YOBI_KOMOKU_03 = YOBI_KOMOKU_03 == null ? null : YOBI_KOMOKU_03.trim();
    }

    /**
     * 予備項目04
     * @return YOBI_KOMOKU_04 予備項目04
     */
    public String getYOBI_KOMOKU_04() {
        return YOBI_KOMOKU_04;
    }

    /**
     * 予備項目04
     * @param YOBI_KOMOKU_04 予備項目04
     */
    public void setYOBI_KOMOKU_04(String YOBI_KOMOKU_04) {
        this.YOBI_KOMOKU_04 = YOBI_KOMOKU_04 == null ? null : YOBI_KOMOKU_04.trim();
    }

    /**
     * 予備項目05
     * @return YOBI_KOMOKU_05 予備項目05
     */
    public String getYOBI_KOMOKU_05() {
        return YOBI_KOMOKU_05;
    }

    /**
     * 予備項目05
     * @param YOBI_KOMOKU_05 予備項目05
     */
    public void setYOBI_KOMOKU_05(String YOBI_KOMOKU_05) {
        this.YOBI_KOMOKU_05 = YOBI_KOMOKU_05 == null ? null : YOBI_KOMOKU_05.trim();
    }

    /**
     * 予備項目06
     * @return YOBI_KOMOKU_06 予備項目06
     */
    public String getYOBI_KOMOKU_06() {
        return YOBI_KOMOKU_06;
    }

    /**
     * 予備項目06
     * @param YOBI_KOMOKU_06 予備項目06
     */
    public void setYOBI_KOMOKU_06(String YOBI_KOMOKU_06) {
        this.YOBI_KOMOKU_06 = YOBI_KOMOKU_06 == null ? null : YOBI_KOMOKU_06.trim();
    }

    /**
     * 予備項目07
     * @return YOBI_KOMOKU_07 予備項目07
     */
    public String getYOBI_KOMOKU_07() {
        return YOBI_KOMOKU_07;
    }

    /**
     * 予備項目07
     * @param YOBI_KOMOKU_07 予備項目07
     */
    public void setYOBI_KOMOKU_07(String YOBI_KOMOKU_07) {
        this.YOBI_KOMOKU_07 = YOBI_KOMOKU_07 == null ? null : YOBI_KOMOKU_07.trim();
    }

    /**
     * 予備項目08
     * @return YOBI_KOMOKU_08 予備項目08
     */
    public String getYOBI_KOMOKU_08() {
        return YOBI_KOMOKU_08;
    }

    /**
     * 予備項目08
     * @param YOBI_KOMOKU_08 予備項目08
     */
    public void setYOBI_KOMOKU_08(String YOBI_KOMOKU_08) {
        this.YOBI_KOMOKU_08 = YOBI_KOMOKU_08 == null ? null : YOBI_KOMOKU_08.trim();
    }

    /**
     * 予備項目09
     * @return YOBI_KOMOKU_09 予備項目09
     */
    public String getYOBI_KOMOKU_09() {
        return YOBI_KOMOKU_09;
    }

    /**
     * 予備項目09
     * @param YOBI_KOMOKU_09 予備項目09
     */
    public void setYOBI_KOMOKU_09(String YOBI_KOMOKU_09) {
        this.YOBI_KOMOKU_09 = YOBI_KOMOKU_09 == null ? null : YOBI_KOMOKU_09.trim();
    }

    /**
     * 予備項目10
     * @return YOBI_KOMOKU_10 予備項目10
     */
    public String getYOBI_KOMOKU_10() {
        return YOBI_KOMOKU_10;
    }

    /**
     * 予備項目10
     * @param YOBI_KOMOKU_10 予備項目10
     */
    public void setYOBI_KOMOKU_10(String YOBI_KOMOKU_10) {
        this.YOBI_KOMOKU_10 = YOBI_KOMOKU_10 == null ? null : YOBI_KOMOKU_10.trim();
    }

    /**
     * 登録タイムスタンプ
     * @return REGST_TMSTMP 登録タイムスタンプ
     */
    public Date getREGST_TMSTMP() {
        return REGST_TMSTMP;
    }

    /**
     * 登録タイムスタンプ
     * @param REGST_TMSTMP 登録タイムスタンプ
     */
    public void setREGST_TMSTMP(Date REGST_TMSTMP) {
        this.REGST_TMSTMP = REGST_TMSTMP;
    }

    /**
     * 登録者会社コード
     * @return REGSTR_CO_CD 登録者会社コード
     */
    public String getREGSTR_CO_CD() {
        return REGSTR_CO_CD;
    }

    /**
     * 登録者会社コード
     * @param REGSTR_CO_CD 登録者会社コード
     */
    public void setREGSTR_CO_CD(String REGSTR_CO_CD) {
        this.REGSTR_CO_CD = REGSTR_CO_CD == null ? null : REGSTR_CO_CD.trim();
    }

    /**
     * 登録者組織コード
     * @return REGSTR_SOSHIKI_CD 登録者組織コード
     */
    public String getREGSTR_SOSHIKI_CD() {
        return REGSTR_SOSHIKI_CD;
    }

    /**
     * 登録者組織コード
     * @param REGSTR_SOSHIKI_CD 登録者組織コード
     */
    public void setREGSTR_SOSHIKI_CD(String REGSTR_SOSHIKI_CD) {
        this.REGSTR_SOSHIKI_CD = REGSTR_SOSHIKI_CD == null ? null : REGSTR_SOSHIKI_CD.trim();
    }

    /**
     * 登録者社員番号
     * @return REGSTR_EMP_NO 登録者社員番号
     */
    public String getREGSTR_EMP_NO() {
        return REGSTR_EMP_NO;
    }

    /**
     * 登録者社員番号
     * @param REGSTR_EMP_NO 登録者社員番号
     */
    public void setREGSTR_EMP_NO(String REGSTR_EMP_NO) {
        this.REGSTR_EMP_NO = REGSTR_EMP_NO == null ? null : REGSTR_EMP_NO.trim();
    }

    /**
     * 登録画面ＩＤ
     * @return REGST_GAMEN_ID 登録画面ＩＤ
     */
    public String getREGST_GAMEN_ID() {
        return REGST_GAMEN_ID;
    }

    /**
     * 登録画面ＩＤ
     * @param REGST_GAMEN_ID 登録画面ＩＤ
     */
    public void setREGST_GAMEN_ID(String REGST_GAMEN_ID) {
        this.REGST_GAMEN_ID = REGST_GAMEN_ID == null ? null : REGST_GAMEN_ID.trim();
    }

    /**
     * 登録プログラムＩＤ
     * @return REGST_PGM_ID 登録プログラムＩＤ
     */
    public String getREGST_PGM_ID() {
        return REGST_PGM_ID;
    }

    /**
     * 登録プログラムＩＤ
     * @param REGST_PGM_ID 登録プログラムＩＤ
     */
    public void setREGST_PGM_ID(String REGST_PGM_ID) {
        this.REGST_PGM_ID = REGST_PGM_ID == null ? null : REGST_PGM_ID.trim();
    }

    /**
     * 更新タイムスタンプ
     * @return UPD_TMSTMP 更新タイムスタンプ
     */
    public Date getUPD_TMSTMP() {
        return UPD_TMSTMP;
    }

    /**
     * 更新タイムスタンプ
     * @param UPD_TMSTMP 更新タイムスタンプ
     */
    public void setUPD_TMSTMP(Date UPD_TMSTMP) {
        this.UPD_TMSTMP = UPD_TMSTMP;
    }

    /**
     * 更新者会社コード
     * @return UPDTR_CO_CD 更新者会社コード
     */
    public String getUPDTR_CO_CD() {
        return UPDTR_CO_CD;
    }

    /**
     * 更新者会社コード
     * @param UPDTR_CO_CD 更新者会社コード
     */
    public void setUPDTR_CO_CD(String UPDTR_CO_CD) {
        this.UPDTR_CO_CD = UPDTR_CO_CD == null ? null : UPDTR_CO_CD.trim();
    }

    /**
     * 更新者組織コード
     * @return UPDTR_SOSHIKI_CD 更新者組織コード
     */
    public String getUPDTR_SOSHIKI_CD() {
        return UPDTR_SOSHIKI_CD;
    }

    /**
     * 更新者組織コード
     * @param UPDTR_SOSHIKI_CD 更新者組織コード
     */
    public void setUPDTR_SOSHIKI_CD(String UPDTR_SOSHIKI_CD) {
        this.UPDTR_SOSHIKI_CD = UPDTR_SOSHIKI_CD == null ? null : UPDTR_SOSHIKI_CD.trim();
    }

    /**
     * 更新者社員番号
     * @return UPDTR_EMP_NO 更新者社員番号
     */
    public String getUPDTR_EMP_NO() {
        return UPDTR_EMP_NO;
    }

    /**
     * 更新者社員番号
     * @param UPDTR_EMP_NO 更新者社員番号
     */
    public void setUPDTR_EMP_NO(String UPDTR_EMP_NO) {
        this.UPDTR_EMP_NO = UPDTR_EMP_NO == null ? null : UPDTR_EMP_NO.trim();
    }

    /**
     * 更新画面ＩＤ
     * @return UPD_GAMEN_ID 更新画面ＩＤ
     */
    public String getUPD_GAMEN_ID() {
        return UPD_GAMEN_ID;
    }

    /**
     * 更新画面ＩＤ
     * @param UPD_GAMEN_ID 更新画面ＩＤ
     */
    public void setUPD_GAMEN_ID(String UPD_GAMEN_ID) {
        this.UPD_GAMEN_ID = UPD_GAMEN_ID == null ? null : UPD_GAMEN_ID.trim();
    }

    /**
     * 更新プログラムＩＤ
     * @return UPD_PGM_ID 更新プログラムＩＤ
     */
    public String getUPD_PGM_ID() {
        return UPD_PGM_ID;
    }

    /**
     * 更新プログラムＩＤ
     * @param UPD_PGM_ID 更新プログラムＩＤ
     */
    public void setUPD_PGM_ID(String UPD_PGM_ID) {
        this.UPD_PGM_ID = UPD_PGM_ID == null ? null : UPD_PGM_ID.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}