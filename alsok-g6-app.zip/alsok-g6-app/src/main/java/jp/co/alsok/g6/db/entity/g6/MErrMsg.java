package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class MErrMsg implements Serializable {
    /**
     * エラーコード
     */
    private String ERR_CD;

    /**
     * エラーレベル
     */
    private String ERR_LVL;

    /**
     * エラー名称
     */
    private String ERR_NM;

    /**
     * 対処メッセージ
     */
    private String RECOVER_MSG;

    /**
     * M_ERR_MSG
     */
    private static final long serialVersionUID = 1L;

    /**
     * エラーコード
     * @return ERR_CD エラーコード
     */
    public String getERR_CD() {
        return ERR_CD;
    }

    /**
     * エラーコード
     * @param ERR_CD エラーコード
     */
    public void setERR_CD(String ERR_CD) {
        this.ERR_CD = ERR_CD == null ? null : ERR_CD.trim();
    }

    /**
     * エラーレベル
     * @return ERR_LVL エラーレベル
     */
    public String getERR_LVL() {
        return ERR_LVL;
    }

    /**
     * エラーレベル
     * @param ERR_LVL エラーレベル
     */
    public void setERR_LVL(String ERR_LVL) {
        this.ERR_LVL = ERR_LVL == null ? null : ERR_LVL.trim();
    }

    /**
     * エラー名称
     * @return ERR_NM エラー名称
     */
    public String getERR_NM() {
        return ERR_NM;
    }

    /**
     * エラー名称
     * @param ERR_NM エラー名称
     */
    public void setERR_NM(String ERR_NM) {
        this.ERR_NM = ERR_NM == null ? null : ERR_NM.trim();
    }

    /**
     * 対処メッセージ
     * @return RECOVER_MSG 対処メッセージ
     */
    public String getRECOVER_MSG() {
        return RECOVER_MSG;
    }

    /**
     * 対処メッセージ
     * @param RECOVER_MSG 対処メッセージ
     */
    public void setRECOVER_MSG(String RECOVER_MSG) {
        this.RECOVER_MSG = RECOVER_MSG == null ? null : RECOVER_MSG.trim();
    }
}