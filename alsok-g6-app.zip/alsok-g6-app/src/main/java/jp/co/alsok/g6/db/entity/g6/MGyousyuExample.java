package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.List;

public class MGyousyuExample {
    /**
     * M_GYOUSYU
     */
    protected String orderByClause;

    /**
     * M_GYOUSYU
     */
    protected boolean distinct;

    /**
     * M_GYOUSYU
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public MGyousyuExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * M_GYOUSYU null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andGYOUSYU_IDIsNull() {
            addCriterion("GYOUSYU_ID is null");
            return (Criteria) this;
        }

        public Criteria andGYOUSYU_IDIsNotNull() {
            addCriterion("GYOUSYU_ID is not null");
            return (Criteria) this;
        }

        public Criteria andGYOUSYU_IDEqualTo(String value) {
            addCriterion("GYOUSYU_ID =", value, "GYOUSYU_ID");
            return (Criteria) this;
        }

        public Criteria andGYOUSYU_IDNotEqualTo(String value) {
            addCriterion("GYOUSYU_ID <>", value, "GYOUSYU_ID");
            return (Criteria) this;
        }

        public Criteria andGYOUSYU_IDGreaterThan(String value) {
            addCriterion("GYOUSYU_ID >", value, "GYOUSYU_ID");
            return (Criteria) this;
        }

        public Criteria andGYOUSYU_IDGreaterThanOrEqualTo(String value) {
            addCriterion("GYOUSYU_ID >=", value, "GYOUSYU_ID");
            return (Criteria) this;
        }

        public Criteria andGYOUSYU_IDLessThan(String value) {
            addCriterion("GYOUSYU_ID <", value, "GYOUSYU_ID");
            return (Criteria) this;
        }

        public Criteria andGYOUSYU_IDLessThanOrEqualTo(String value) {
            addCriterion("GYOUSYU_ID <=", value, "GYOUSYU_ID");
            return (Criteria) this;
        }

        public Criteria andGYOUSYU_IDLike(String value) {
            addCriterion("GYOUSYU_ID like", value, "GYOUSYU_ID");
            return (Criteria) this;
        }

        public Criteria andGYOUSYU_IDNotLike(String value) {
            addCriterion("GYOUSYU_ID not like", value, "GYOUSYU_ID");
            return (Criteria) this;
        }

        public Criteria andGYOUSYU_IDIn(List<String> values) {
            addCriterion("GYOUSYU_ID in", values, "GYOUSYU_ID");
            return (Criteria) this;
        }

        public Criteria andGYOUSYU_IDNotIn(List<String> values) {
            addCriterion("GYOUSYU_ID not in", values, "GYOUSYU_ID");
            return (Criteria) this;
        }

        public Criteria andGYOUSYU_IDBetween(String value1, String value2) {
            addCriterion("GYOUSYU_ID between", value1, value2, "GYOUSYU_ID");
            return (Criteria) this;
        }

        public Criteria andGYOUSYU_IDNotBetween(String value1, String value2) {
            addCriterion("GYOUSYU_ID not between", value1, value2, "GYOUSYU_ID");
            return (Criteria) this;
        }

        public Criteria andNMIsNull() {
            addCriterion("NM is null");
            return (Criteria) this;
        }

        public Criteria andNMIsNotNull() {
            addCriterion("NM is not null");
            return (Criteria) this;
        }

        public Criteria andNMEqualTo(String value) {
            addCriterion("NM =", value, "NM");
            return (Criteria) this;
        }

        public Criteria andNMNotEqualTo(String value) {
            addCriterion("NM <>", value, "NM");
            return (Criteria) this;
        }

        public Criteria andNMGreaterThan(String value) {
            addCriterion("NM >", value, "NM");
            return (Criteria) this;
        }

        public Criteria andNMGreaterThanOrEqualTo(String value) {
            addCriterion("NM >=", value, "NM");
            return (Criteria) this;
        }

        public Criteria andNMLessThan(String value) {
            addCriterion("NM <", value, "NM");
            return (Criteria) this;
        }

        public Criteria andNMLessThanOrEqualTo(String value) {
            addCriterion("NM <=", value, "NM");
            return (Criteria) this;
        }

        public Criteria andNMLike(String value) {
            addCriterion("NM like", value, "NM");
            return (Criteria) this;
        }

        public Criteria andNMNotLike(String value) {
            addCriterion("NM not like", value, "NM");
            return (Criteria) this;
        }

        public Criteria andNMIn(List<String> values) {
            addCriterion("NM in", values, "NM");
            return (Criteria) this;
        }

        public Criteria andNMNotIn(List<String> values) {
            addCriterion("NM not in", values, "NM");
            return (Criteria) this;
        }

        public Criteria andNMBetween(String value1, String value2) {
            addCriterion("NM between", value1, value2, "NM");
            return (Criteria) this;
        }

        public Criteria andNMNotBetween(String value1, String value2) {
            addCriterion("NM not between", value1, value2, "NM");
            return (Criteria) this;
        }

        public Criteria andGYOUSYU_IDLikeInsensitive(String value) {
            addCriterion("upper(GYOUSYU_ID) like", value.toUpperCase(), "GYOUSYU_ID");
            return (Criteria) this;
        }

        public Criteria andNMLikeInsensitive(String value) {
            addCriterion("upper(NM) like", value.toUpperCase(), "NM");
            return (Criteria) this;
        }
    }

    /**
     * M_GYOUSYU
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * M_GYOUSYU null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}