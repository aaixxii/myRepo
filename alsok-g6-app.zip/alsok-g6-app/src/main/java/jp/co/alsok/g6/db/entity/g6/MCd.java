package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class MCd extends MCdKey implements Serializable {
    /**
     * コード名
     */
    private String CD_NM;

    /**
     * 説明_日本語
     */
    private String DESCRIPTION_JP;

    /**
     * 説明_英語
     */
    private String DESCRIPTION_EN;

    /**
     * 説明_中国語
     */
    private String DESCRIPTION_ZH;

    /**
     * 備考
     */
    private String BIKOU;

    /**
     * M_CD
     */
    private static final long serialVersionUID = 1L;

    /**
     * コード名
     * @return CD_NM コード名
     */
    public String getCD_NM() {
        return CD_NM;
    }

    /**
     * コード名
     * @param CD_NM コード名
     */
    public void setCD_NM(String CD_NM) {
        this.CD_NM = CD_NM == null ? null : CD_NM.trim();
    }

    /**
     * 説明_日本語
     * @return DESCRIPTION_JP 説明_日本語
     */
    public String getDESCRIPTION_JP() {
        return DESCRIPTION_JP;
    }

    /**
     * 説明_日本語
     * @param DESCRIPTION_JP 説明_日本語
     */
    public void setDESCRIPTION_JP(String DESCRIPTION_JP) {
        this.DESCRIPTION_JP = DESCRIPTION_JP == null ? null : DESCRIPTION_JP.trim();
    }

    /**
     * 説明_英語
     * @return DESCRIPTION_EN 説明_英語
     */
    public String getDESCRIPTION_EN() {
        return DESCRIPTION_EN;
    }

    /**
     * 説明_英語
     * @param DESCRIPTION_EN 説明_英語
     */
    public void setDESCRIPTION_EN(String DESCRIPTION_EN) {
        this.DESCRIPTION_EN = DESCRIPTION_EN == null ? null : DESCRIPTION_EN.trim();
    }

    /**
     * 説明_中国語
     * @return DESCRIPTION_ZH 説明_中国語
     */
    public String getDESCRIPTION_ZH() {
        return DESCRIPTION_ZH;
    }

    /**
     * 説明_中国語
     * @param DESCRIPTION_ZH 説明_中国語
     */
    public void setDESCRIPTION_ZH(String DESCRIPTION_ZH) {
        this.DESCRIPTION_ZH = DESCRIPTION_ZH == null ? null : DESCRIPTION_ZH.trim();
    }

    /**
     * 備考
     * @return BIKOU 備考
     */
    public String getBIKOU() {
        return BIKOU;
    }

    /**
     * 備考
     * @param BIKOU 備考
     */
    public void setBIKOU(String BIKOU) {
        this.BIKOU = BIKOU == null ? null : BIKOU.trim();
    }
}