package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CQueCtrlSigExample {
    /**
     * C_QUE_CTRL_SIG
     */
    protected String orderByClause;

    /**
     * C_QUE_CTRL_SIG
     */
    protected boolean distinct;

    /**
     * C_QUE_CTRL_SIG
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public CQueCtrlSigExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * C_QUE_CTRL_SIG null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_QUE_CTRL_SIGIsNull() {
            addCriterion("LN_QUE_CTRL_SIG is null");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_CTRL_SIGIsNotNull() {
            addCriterion("LN_QUE_CTRL_SIG is not null");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_CTRL_SIGEqualTo(String value) {
            addCriterion("LN_QUE_CTRL_SIG =", value, "LN_QUE_CTRL_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_CTRL_SIGNotEqualTo(String value) {
            addCriterion("LN_QUE_CTRL_SIG <>", value, "LN_QUE_CTRL_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_CTRL_SIGGreaterThan(String value) {
            addCriterion("LN_QUE_CTRL_SIG >", value, "LN_QUE_CTRL_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_CTRL_SIGGreaterThanOrEqualTo(String value) {
            addCriterion("LN_QUE_CTRL_SIG >=", value, "LN_QUE_CTRL_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_CTRL_SIGLessThan(String value) {
            addCriterion("LN_QUE_CTRL_SIG <", value, "LN_QUE_CTRL_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_CTRL_SIGLessThanOrEqualTo(String value) {
            addCriterion("LN_QUE_CTRL_SIG <=", value, "LN_QUE_CTRL_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_CTRL_SIGLike(String value) {
            addCriterion("LN_QUE_CTRL_SIG like", value, "LN_QUE_CTRL_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_CTRL_SIGNotLike(String value) {
            addCriterion("LN_QUE_CTRL_SIG not like", value, "LN_QUE_CTRL_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_CTRL_SIGIn(List<String> values) {
            addCriterion("LN_QUE_CTRL_SIG in", values, "LN_QUE_CTRL_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_CTRL_SIGNotIn(List<String> values) {
            addCriterion("LN_QUE_CTRL_SIG not in", values, "LN_QUE_CTRL_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_CTRL_SIGBetween(String value1, String value2) {
            addCriterion("LN_QUE_CTRL_SIG between", value1, value2, "LN_QUE_CTRL_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_CTRL_SIGNotBetween(String value1, String value2) {
            addCriterion("LN_QUE_CTRL_SIG not between", value1, value2, "LN_QUE_CTRL_SIG");
            return (Criteria) this;
        }

        public Criteria andHOST_NMIsNull() {
            addCriterion("HOST_NM is null");
            return (Criteria) this;
        }

        public Criteria andHOST_NMIsNotNull() {
            addCriterion("HOST_NM is not null");
            return (Criteria) this;
        }

        public Criteria andHOST_NMEqualTo(String value) {
            addCriterion("HOST_NM =", value, "HOST_NM");
            return (Criteria) this;
        }

        public Criteria andHOST_NMNotEqualTo(String value) {
            addCriterion("HOST_NM <>", value, "HOST_NM");
            return (Criteria) this;
        }

        public Criteria andHOST_NMGreaterThan(String value) {
            addCriterion("HOST_NM >", value, "HOST_NM");
            return (Criteria) this;
        }

        public Criteria andHOST_NMGreaterThanOrEqualTo(String value) {
            addCriterion("HOST_NM >=", value, "HOST_NM");
            return (Criteria) this;
        }

        public Criteria andHOST_NMLessThan(String value) {
            addCriterion("HOST_NM <", value, "HOST_NM");
            return (Criteria) this;
        }

        public Criteria andHOST_NMLessThanOrEqualTo(String value) {
            addCriterion("HOST_NM <=", value, "HOST_NM");
            return (Criteria) this;
        }

        public Criteria andHOST_NMLike(String value) {
            addCriterion("HOST_NM like", value, "HOST_NM");
            return (Criteria) this;
        }

        public Criteria andHOST_NMNotLike(String value) {
            addCriterion("HOST_NM not like", value, "HOST_NM");
            return (Criteria) this;
        }

        public Criteria andHOST_NMIn(List<String> values) {
            addCriterion("HOST_NM in", values, "HOST_NM");
            return (Criteria) this;
        }

        public Criteria andHOST_NMNotIn(List<String> values) {
            addCriterion("HOST_NM not in", values, "HOST_NM");
            return (Criteria) this;
        }

        public Criteria andHOST_NMBetween(String value1, String value2) {
            addCriterion("HOST_NM between", value1, value2, "HOST_NM");
            return (Criteria) this;
        }

        public Criteria andHOST_NMNotBetween(String value1, String value2) {
            addCriterion("HOST_NM not between", value1, value2, "HOST_NM");
            return (Criteria) this;
        }

        public Criteria andDENKEIIsNull() {
            addCriterion("DENKEI is null");
            return (Criteria) this;
        }

        public Criteria andDENKEIIsNotNull() {
            addCriterion("DENKEI is not null");
            return (Criteria) this;
        }

        public Criteria andDENKEIEqualTo(String value) {
            addCriterion("DENKEI =", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEINotEqualTo(String value) {
            addCriterion("DENKEI <>", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEIGreaterThan(String value) {
            addCriterion("DENKEI >", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEIGreaterThanOrEqualTo(String value) {
            addCriterion("DENKEI >=", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEILessThan(String value) {
            addCriterion("DENKEI <", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEILessThanOrEqualTo(String value) {
            addCriterion("DENKEI <=", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEILike(String value) {
            addCriterion("DENKEI like", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEINotLike(String value) {
            addCriterion("DENKEI not like", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEIIn(List<String> values) {
            addCriterion("DENKEI in", values, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEINotIn(List<String> values) {
            addCriterion("DENKEI not in", values, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEIBetween(String value1, String value2) {
            addCriterion("DENKEI between", value1, value2, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEINotBetween(String value1, String value2) {
            addCriterion("DENKEI not between", value1, value2, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andGOUKIIsNull() {
            addCriterion("GOUKI is null");
            return (Criteria) this;
        }

        public Criteria andGOUKIIsNotNull() {
            addCriterion("GOUKI is not null");
            return (Criteria) this;
        }

        public Criteria andGOUKIEqualTo(String value) {
            addCriterion("GOUKI =", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKINotEqualTo(String value) {
            addCriterion("GOUKI <>", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKIGreaterThan(String value) {
            addCriterion("GOUKI >", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKIGreaterThanOrEqualTo(String value) {
            addCriterion("GOUKI >=", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKILessThan(String value) {
            addCriterion("GOUKI <", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKILessThanOrEqualTo(String value) {
            addCriterion("GOUKI <=", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKILike(String value) {
            addCriterion("GOUKI like", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKINotLike(String value) {
            addCriterion("GOUKI not like", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKIIn(List<String> values) {
            addCriterion("GOUKI in", values, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKINotIn(List<String> values) {
            addCriterion("GOUKI not in", values, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKIBetween(String value1, String value2) {
            addCriterion("GOUKI between", value1, value2, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKINotBetween(String value1, String value2) {
            addCriterion("GOUKI not between", value1, value2, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andSERIAL_NUMIsNull() {
            addCriterion("SERIAL_NUM is null");
            return (Criteria) this;
        }

        public Criteria andSERIAL_NUMIsNotNull() {
            addCriterion("SERIAL_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andSERIAL_NUMEqualTo(String value) {
            addCriterion("SERIAL_NUM =", value, "SERIAL_NUM");
            return (Criteria) this;
        }

        public Criteria andSERIAL_NUMNotEqualTo(String value) {
            addCriterion("SERIAL_NUM <>", value, "SERIAL_NUM");
            return (Criteria) this;
        }

        public Criteria andSERIAL_NUMGreaterThan(String value) {
            addCriterion("SERIAL_NUM >", value, "SERIAL_NUM");
            return (Criteria) this;
        }

        public Criteria andSERIAL_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("SERIAL_NUM >=", value, "SERIAL_NUM");
            return (Criteria) this;
        }

        public Criteria andSERIAL_NUMLessThan(String value) {
            addCriterion("SERIAL_NUM <", value, "SERIAL_NUM");
            return (Criteria) this;
        }

        public Criteria andSERIAL_NUMLessThanOrEqualTo(String value) {
            addCriterion("SERIAL_NUM <=", value, "SERIAL_NUM");
            return (Criteria) this;
        }

        public Criteria andSERIAL_NUMLike(String value) {
            addCriterion("SERIAL_NUM like", value, "SERIAL_NUM");
            return (Criteria) this;
        }

        public Criteria andSERIAL_NUMNotLike(String value) {
            addCriterion("SERIAL_NUM not like", value, "SERIAL_NUM");
            return (Criteria) this;
        }

        public Criteria andSERIAL_NUMIn(List<String> values) {
            addCriterion("SERIAL_NUM in", values, "SERIAL_NUM");
            return (Criteria) this;
        }

        public Criteria andSERIAL_NUMNotIn(List<String> values) {
            addCriterion("SERIAL_NUM not in", values, "SERIAL_NUM");
            return (Criteria) this;
        }

        public Criteria andSERIAL_NUMBetween(String value1, String value2) {
            addCriterion("SERIAL_NUM between", value1, value2, "SERIAL_NUM");
            return (Criteria) this;
        }

        public Criteria andSERIAL_NUMNotBetween(String value1, String value2) {
            addCriterion("SERIAL_NUM not between", value1, value2, "SERIAL_NUM");
            return (Criteria) this;
        }

        public Criteria andCONN_DEV_NUMIsNull() {
            addCriterion("CONN_DEV_NUM is null");
            return (Criteria) this;
        }

        public Criteria andCONN_DEV_NUMIsNotNull() {
            addCriterion("CONN_DEV_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andCONN_DEV_NUMEqualTo(String value) {
            addCriterion("CONN_DEV_NUM =", value, "CONN_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andCONN_DEV_NUMNotEqualTo(String value) {
            addCriterion("CONN_DEV_NUM <>", value, "CONN_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andCONN_DEV_NUMGreaterThan(String value) {
            addCriterion("CONN_DEV_NUM >", value, "CONN_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andCONN_DEV_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("CONN_DEV_NUM >=", value, "CONN_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andCONN_DEV_NUMLessThan(String value) {
            addCriterion("CONN_DEV_NUM <", value, "CONN_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andCONN_DEV_NUMLessThanOrEqualTo(String value) {
            addCriterion("CONN_DEV_NUM <=", value, "CONN_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andCONN_DEV_NUMLike(String value) {
            addCriterion("CONN_DEV_NUM like", value, "CONN_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andCONN_DEV_NUMNotLike(String value) {
            addCriterion("CONN_DEV_NUM not like", value, "CONN_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andCONN_DEV_NUMIn(List<String> values) {
            addCriterion("CONN_DEV_NUM in", values, "CONN_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andCONN_DEV_NUMNotIn(List<String> values) {
            addCriterion("CONN_DEV_NUM not in", values, "CONN_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andCONN_DEV_NUMBetween(String value1, String value2) {
            addCriterion("CONN_DEV_NUM between", value1, value2, "CONN_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andCONN_DEV_NUMNotBetween(String value1, String value2) {
            addCriterion("CONN_DEV_NUM not between", value1, value2, "CONN_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMIsNull() {
            addCriterion("DEV_NUM is null");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMIsNotNull() {
            addCriterion("DEV_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMEqualTo(String value) {
            addCriterion("DEV_NUM =", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMNotEqualTo(String value) {
            addCriterion("DEV_NUM <>", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMGreaterThan(String value) {
            addCriterion("DEV_NUM >", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("DEV_NUM >=", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMLessThan(String value) {
            addCriterion("DEV_NUM <", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMLessThanOrEqualTo(String value) {
            addCriterion("DEV_NUM <=", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMLike(String value) {
            addCriterion("DEV_NUM like", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMNotLike(String value) {
            addCriterion("DEV_NUM not like", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMIn(List<String> values) {
            addCriterion("DEV_NUM in", values, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMNotIn(List<String> values) {
            addCriterion("DEV_NUM not in", values, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMBetween(String value1, String value2) {
            addCriterion("DEV_NUM between", value1, value2, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMNotBetween(String value1, String value2) {
            addCriterion("DEV_NUM not between", value1, value2, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDRIsNull() {
            addCriterion("SUB_ADDR is null");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDRIsNotNull() {
            addCriterion("SUB_ADDR is not null");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDREqualTo(String value) {
            addCriterion("SUB_ADDR =", value, "SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDRNotEqualTo(String value) {
            addCriterion("SUB_ADDR <>", value, "SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDRGreaterThan(String value) {
            addCriterion("SUB_ADDR >", value, "SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDRGreaterThanOrEqualTo(String value) {
            addCriterion("SUB_ADDR >=", value, "SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDRLessThan(String value) {
            addCriterion("SUB_ADDR <", value, "SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDRLessThanOrEqualTo(String value) {
            addCriterion("SUB_ADDR <=", value, "SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDRLike(String value) {
            addCriterion("SUB_ADDR like", value, "SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDRNotLike(String value) {
            addCriterion("SUB_ADDR not like", value, "SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDRIn(List<String> values) {
            addCriterion("SUB_ADDR in", values, "SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDRNotIn(List<String> values) {
            addCriterion("SUB_ADDR not in", values, "SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDRBetween(String value1, String value2) {
            addCriterion("SUB_ADDR between", value1, value2, "SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDRNotBetween(String value1, String value2) {
            addCriterion("SUB_ADDR not between", value1, value2, "SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andPRIORITYIsNull() {
            addCriterion("PRIORITY is null");
            return (Criteria) this;
        }

        public Criteria andPRIORITYIsNotNull() {
            addCriterion("PRIORITY is not null");
            return (Criteria) this;
        }

        public Criteria andPRIORITYEqualTo(String value) {
            addCriterion("PRIORITY =", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYNotEqualTo(String value) {
            addCriterion("PRIORITY <>", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYGreaterThan(String value) {
            addCriterion("PRIORITY >", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYGreaterThanOrEqualTo(String value) {
            addCriterion("PRIORITY >=", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYLessThan(String value) {
            addCriterion("PRIORITY <", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYLessThanOrEqualTo(String value) {
            addCriterion("PRIORITY <=", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYLike(String value) {
            addCriterion("PRIORITY like", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYNotLike(String value) {
            addCriterion("PRIORITY not like", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYIn(List<String> values) {
            addCriterion("PRIORITY in", values, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYNotIn(List<String> values) {
            addCriterion("PRIORITY not in", values, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYBetween(String value1, String value2) {
            addCriterion("PRIORITY between", value1, value2, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYNotBetween(String value1, String value2) {
            addCriterion("PRIORITY not between", value1, value2, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUMIsNull() {
            addCriterion("CMD_SEQ_NUM is null");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUMIsNotNull() {
            addCriterion("CMD_SEQ_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUMEqualTo(String value) {
            addCriterion("CMD_SEQ_NUM =", value, "CMD_SEQ_NUM");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUMNotEqualTo(String value) {
            addCriterion("CMD_SEQ_NUM <>", value, "CMD_SEQ_NUM");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUMGreaterThan(String value) {
            addCriterion("CMD_SEQ_NUM >", value, "CMD_SEQ_NUM");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("CMD_SEQ_NUM >=", value, "CMD_SEQ_NUM");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUMLessThan(String value) {
            addCriterion("CMD_SEQ_NUM <", value, "CMD_SEQ_NUM");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUMLessThanOrEqualTo(String value) {
            addCriterion("CMD_SEQ_NUM <=", value, "CMD_SEQ_NUM");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUMLike(String value) {
            addCriterion("CMD_SEQ_NUM like", value, "CMD_SEQ_NUM");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUMNotLike(String value) {
            addCriterion("CMD_SEQ_NUM not like", value, "CMD_SEQ_NUM");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUMIn(List<String> values) {
            addCriterion("CMD_SEQ_NUM in", values, "CMD_SEQ_NUM");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUMNotIn(List<String> values) {
            addCriterion("CMD_SEQ_NUM not in", values, "CMD_SEQ_NUM");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUMBetween(String value1, String value2) {
            addCriterion("CMD_SEQ_NUM between", value1, value2, "CMD_SEQ_NUM");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUMNotBetween(String value1, String value2) {
            addCriterion("CMD_SEQ_NUM not between", value1, value2, "CMD_SEQ_NUM");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMIsNull() {
            addCriterion("PROCESS_NUM is null");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMIsNotNull() {
            addCriterion("PROCESS_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMEqualTo(String value) {
            addCriterion("PROCESS_NUM =", value, "PROCESS_NUM");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMNotEqualTo(String value) {
            addCriterion("PROCESS_NUM <>", value, "PROCESS_NUM");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMGreaterThan(String value) {
            addCriterion("PROCESS_NUM >", value, "PROCESS_NUM");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("PROCESS_NUM >=", value, "PROCESS_NUM");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMLessThan(String value) {
            addCriterion("PROCESS_NUM <", value, "PROCESS_NUM");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMLessThanOrEqualTo(String value) {
            addCriterion("PROCESS_NUM <=", value, "PROCESS_NUM");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMLike(String value) {
            addCriterion("PROCESS_NUM like", value, "PROCESS_NUM");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMNotLike(String value) {
            addCriterion("PROCESS_NUM not like", value, "PROCESS_NUM");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMIn(List<String> values) {
            addCriterion("PROCESS_NUM in", values, "PROCESS_NUM");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMNotIn(List<String> values) {
            addCriterion("PROCESS_NUM not in", values, "PROCESS_NUM");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMBetween(String value1, String value2) {
            addCriterion("PROCESS_NUM between", value1, value2, "PROCESS_NUM");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMNotBetween(String value1, String value2) {
            addCriterion("PROCESS_NUM not between", value1, value2, "PROCESS_NUM");
            return (Criteria) this;
        }

        public Criteria andCMD_CDIsNull() {
            addCriterion("CMD_CD is null");
            return (Criteria) this;
        }

        public Criteria andCMD_CDIsNotNull() {
            addCriterion("CMD_CD is not null");
            return (Criteria) this;
        }

        public Criteria andCMD_CDEqualTo(String value) {
            addCriterion("CMD_CD =", value, "CMD_CD");
            return (Criteria) this;
        }

        public Criteria andCMD_CDNotEqualTo(String value) {
            addCriterion("CMD_CD <>", value, "CMD_CD");
            return (Criteria) this;
        }

        public Criteria andCMD_CDGreaterThan(String value) {
            addCriterion("CMD_CD >", value, "CMD_CD");
            return (Criteria) this;
        }

        public Criteria andCMD_CDGreaterThanOrEqualTo(String value) {
            addCriterion("CMD_CD >=", value, "CMD_CD");
            return (Criteria) this;
        }

        public Criteria andCMD_CDLessThan(String value) {
            addCriterion("CMD_CD <", value, "CMD_CD");
            return (Criteria) this;
        }

        public Criteria andCMD_CDLessThanOrEqualTo(String value) {
            addCriterion("CMD_CD <=", value, "CMD_CD");
            return (Criteria) this;
        }

        public Criteria andCMD_CDLike(String value) {
            addCriterion("CMD_CD like", value, "CMD_CD");
            return (Criteria) this;
        }

        public Criteria andCMD_CDNotLike(String value) {
            addCriterion("CMD_CD not like", value, "CMD_CD");
            return (Criteria) this;
        }

        public Criteria andCMD_CDIn(List<String> values) {
            addCriterion("CMD_CD in", values, "CMD_CD");
            return (Criteria) this;
        }

        public Criteria andCMD_CDNotIn(List<String> values) {
            addCriterion("CMD_CD not in", values, "CMD_CD");
            return (Criteria) this;
        }

        public Criteria andCMD_CDBetween(String value1, String value2) {
            addCriterion("CMD_CD between", value1, value2, "CMD_CD");
            return (Criteria) this;
        }

        public Criteria andCMD_CDNotBetween(String value1, String value2) {
            addCriterion("CMD_CD not between", value1, value2, "CMD_CD");
            return (Criteria) this;
        }

        public Criteria andEXEC_CMDIsNull() {
            addCriterion("EXEC_CMD is null");
            return (Criteria) this;
        }

        public Criteria andEXEC_CMDIsNotNull() {
            addCriterion("EXEC_CMD is not null");
            return (Criteria) this;
        }

        public Criteria andEXEC_CMDEqualTo(String value) {
            addCriterion("EXEC_CMD =", value, "EXEC_CMD");
            return (Criteria) this;
        }

        public Criteria andEXEC_CMDNotEqualTo(String value) {
            addCriterion("EXEC_CMD <>", value, "EXEC_CMD");
            return (Criteria) this;
        }

        public Criteria andEXEC_CMDGreaterThan(String value) {
            addCriterion("EXEC_CMD >", value, "EXEC_CMD");
            return (Criteria) this;
        }

        public Criteria andEXEC_CMDGreaterThanOrEqualTo(String value) {
            addCriterion("EXEC_CMD >=", value, "EXEC_CMD");
            return (Criteria) this;
        }

        public Criteria andEXEC_CMDLessThan(String value) {
            addCriterion("EXEC_CMD <", value, "EXEC_CMD");
            return (Criteria) this;
        }

        public Criteria andEXEC_CMDLessThanOrEqualTo(String value) {
            addCriterion("EXEC_CMD <=", value, "EXEC_CMD");
            return (Criteria) this;
        }

        public Criteria andEXEC_CMDLike(String value) {
            addCriterion("EXEC_CMD like", value, "EXEC_CMD");
            return (Criteria) this;
        }

        public Criteria andEXEC_CMDNotLike(String value) {
            addCriterion("EXEC_CMD not like", value, "EXEC_CMD");
            return (Criteria) this;
        }

        public Criteria andEXEC_CMDIn(List<String> values) {
            addCriterion("EXEC_CMD in", values, "EXEC_CMD");
            return (Criteria) this;
        }

        public Criteria andEXEC_CMDNotIn(List<String> values) {
            addCriterion("EXEC_CMD not in", values, "EXEC_CMD");
            return (Criteria) this;
        }

        public Criteria andEXEC_CMDBetween(String value1, String value2) {
            addCriterion("EXEC_CMD between", value1, value2, "EXEC_CMD");
            return (Criteria) this;
        }

        public Criteria andEXEC_CMDNotBetween(String value1, String value2) {
            addCriterion("EXEC_CMD not between", value1, value2, "EXEC_CMD");
            return (Criteria) this;
        }

        public Criteria andDIR_NMIsNull() {
            addCriterion("DIR_NM is null");
            return (Criteria) this;
        }

        public Criteria andDIR_NMIsNotNull() {
            addCriterion("DIR_NM is not null");
            return (Criteria) this;
        }

        public Criteria andDIR_NMEqualTo(String value) {
            addCriterion("DIR_NM =", value, "DIR_NM");
            return (Criteria) this;
        }

        public Criteria andDIR_NMNotEqualTo(String value) {
            addCriterion("DIR_NM <>", value, "DIR_NM");
            return (Criteria) this;
        }

        public Criteria andDIR_NMGreaterThan(String value) {
            addCriterion("DIR_NM >", value, "DIR_NM");
            return (Criteria) this;
        }

        public Criteria andDIR_NMGreaterThanOrEqualTo(String value) {
            addCriterion("DIR_NM >=", value, "DIR_NM");
            return (Criteria) this;
        }

        public Criteria andDIR_NMLessThan(String value) {
            addCriterion("DIR_NM <", value, "DIR_NM");
            return (Criteria) this;
        }

        public Criteria andDIR_NMLessThanOrEqualTo(String value) {
            addCriterion("DIR_NM <=", value, "DIR_NM");
            return (Criteria) this;
        }

        public Criteria andDIR_NMLike(String value) {
            addCriterion("DIR_NM like", value, "DIR_NM");
            return (Criteria) this;
        }

        public Criteria andDIR_NMNotLike(String value) {
            addCriterion("DIR_NM not like", value, "DIR_NM");
            return (Criteria) this;
        }

        public Criteria andDIR_NMIn(List<String> values) {
            addCriterion("DIR_NM in", values, "DIR_NM");
            return (Criteria) this;
        }

        public Criteria andDIR_NMNotIn(List<String> values) {
            addCriterion("DIR_NM not in", values, "DIR_NM");
            return (Criteria) this;
        }

        public Criteria andDIR_NMBetween(String value1, String value2) {
            addCriterion("DIR_NM between", value1, value2, "DIR_NM");
            return (Criteria) this;
        }

        public Criteria andDIR_NMNotBetween(String value1, String value2) {
            addCriterion("DIR_NM not between", value1, value2, "DIR_NM");
            return (Criteria) this;
        }

        public Criteria andENQ_TSIsNull() {
            addCriterion("ENQ_TS is null");
            return (Criteria) this;
        }

        public Criteria andENQ_TSIsNotNull() {
            addCriterion("ENQ_TS is not null");
            return (Criteria) this;
        }

        public Criteria andENQ_TSEqualTo(Date value) {
            addCriterion("ENQ_TS =", value, "ENQ_TS");
            return (Criteria) this;
        }

        public Criteria andENQ_TSNotEqualTo(Date value) {
            addCriterion("ENQ_TS <>", value, "ENQ_TS");
            return (Criteria) this;
        }

        public Criteria andENQ_TSGreaterThan(Date value) {
            addCriterion("ENQ_TS >", value, "ENQ_TS");
            return (Criteria) this;
        }

        public Criteria andENQ_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("ENQ_TS >=", value, "ENQ_TS");
            return (Criteria) this;
        }

        public Criteria andENQ_TSLessThan(Date value) {
            addCriterion("ENQ_TS <", value, "ENQ_TS");
            return (Criteria) this;
        }

        public Criteria andENQ_TSLessThanOrEqualTo(Date value) {
            addCriterion("ENQ_TS <=", value, "ENQ_TS");
            return (Criteria) this;
        }

        public Criteria andENQ_TSIn(List<Date> values) {
            addCriterion("ENQ_TS in", values, "ENQ_TS");
            return (Criteria) this;
        }

        public Criteria andENQ_TSNotIn(List<Date> values) {
            addCriterion("ENQ_TS not in", values, "ENQ_TS");
            return (Criteria) this;
        }

        public Criteria andENQ_TSBetween(Date value1, Date value2) {
            addCriterion("ENQ_TS between", value1, value2, "ENQ_TS");
            return (Criteria) this;
        }

        public Criteria andENQ_TSNotBetween(Date value1, Date value2) {
            addCriterion("ENQ_TS not between", value1, value2, "ENQ_TS");
            return (Criteria) this;
        }

        public Criteria andDEQ_ABL_TSIsNull() {
            addCriterion("DEQ_ABL_TS is null");
            return (Criteria) this;
        }

        public Criteria andDEQ_ABL_TSIsNotNull() {
            addCriterion("DEQ_ABL_TS is not null");
            return (Criteria) this;
        }

        public Criteria andDEQ_ABL_TSEqualTo(Date value) {
            addCriterion("DEQ_ABL_TS =", value, "DEQ_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andDEQ_ABL_TSNotEqualTo(Date value) {
            addCriterion("DEQ_ABL_TS <>", value, "DEQ_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andDEQ_ABL_TSGreaterThan(Date value) {
            addCriterion("DEQ_ABL_TS >", value, "DEQ_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andDEQ_ABL_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("DEQ_ABL_TS >=", value, "DEQ_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andDEQ_ABL_TSLessThan(Date value) {
            addCriterion("DEQ_ABL_TS <", value, "DEQ_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andDEQ_ABL_TSLessThanOrEqualTo(Date value) {
            addCriterion("DEQ_ABL_TS <=", value, "DEQ_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andDEQ_ABL_TSIn(List<Date> values) {
            addCriterion("DEQ_ABL_TS in", values, "DEQ_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andDEQ_ABL_TSNotIn(List<Date> values) {
            addCriterion("DEQ_ABL_TS not in", values, "DEQ_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andDEQ_ABL_TSBetween(Date value1, Date value2) {
            addCriterion("DEQ_ABL_TS between", value1, value2, "DEQ_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andDEQ_ABL_TSNotBetween(Date value1, Date value2) {
            addCriterion("DEQ_ABL_TS not between", value1, value2, "DEQ_ABL_TS");
            return (Criteria) this;
        }

        public Criteria andDEQ_TSIsNull() {
            addCriterion("DEQ_TS is null");
            return (Criteria) this;
        }

        public Criteria andDEQ_TSIsNotNull() {
            addCriterion("DEQ_TS is not null");
            return (Criteria) this;
        }

        public Criteria andDEQ_TSEqualTo(Date value) {
            addCriterion("DEQ_TS =", value, "DEQ_TS");
            return (Criteria) this;
        }

        public Criteria andDEQ_TSNotEqualTo(Date value) {
            addCriterion("DEQ_TS <>", value, "DEQ_TS");
            return (Criteria) this;
        }

        public Criteria andDEQ_TSGreaterThan(Date value) {
            addCriterion("DEQ_TS >", value, "DEQ_TS");
            return (Criteria) this;
        }

        public Criteria andDEQ_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("DEQ_TS >=", value, "DEQ_TS");
            return (Criteria) this;
        }

        public Criteria andDEQ_TSLessThan(Date value) {
            addCriterion("DEQ_TS <", value, "DEQ_TS");
            return (Criteria) this;
        }

        public Criteria andDEQ_TSLessThanOrEqualTo(Date value) {
            addCriterion("DEQ_TS <=", value, "DEQ_TS");
            return (Criteria) this;
        }

        public Criteria andDEQ_TSIn(List<Date> values) {
            addCriterion("DEQ_TS in", values, "DEQ_TS");
            return (Criteria) this;
        }

        public Criteria andDEQ_TSNotIn(List<Date> values) {
            addCriterion("DEQ_TS not in", values, "DEQ_TS");
            return (Criteria) this;
        }

        public Criteria andDEQ_TSBetween(Date value1, Date value2) {
            addCriterion("DEQ_TS between", value1, value2, "DEQ_TS");
            return (Criteria) this;
        }

        public Criteria andDEQ_TSNotBetween(Date value1, Date value2) {
            addCriterion("DEQ_TS not between", value1, value2, "DEQ_TS");
            return (Criteria) this;
        }

        public Criteria andSTSIsNull() {
            addCriterion("STS is null");
            return (Criteria) this;
        }

        public Criteria andSTSIsNotNull() {
            addCriterion("STS is not null");
            return (Criteria) this;
        }

        public Criteria andSTSEqualTo(String value) {
            addCriterion("STS =", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSNotEqualTo(String value) {
            addCriterion("STS <>", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSGreaterThan(String value) {
            addCriterion("STS >", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSGreaterThanOrEqualTo(String value) {
            addCriterion("STS >=", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSLessThan(String value) {
            addCriterion("STS <", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSLessThanOrEqualTo(String value) {
            addCriterion("STS <=", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSLike(String value) {
            addCriterion("STS like", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSNotLike(String value) {
            addCriterion("STS not like", value, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSIn(List<String> values) {
            addCriterion("STS in", values, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSNotIn(List<String> values) {
            addCriterion("STS not in", values, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSBetween(String value1, String value2) {
            addCriterion("STS between", value1, value2, "STS");
            return (Criteria) this;
        }

        public Criteria andSTSNotBetween(String value1, String value2) {
            addCriterion("STS not between", value1, value2, "STS");
            return (Criteria) this;
        }

        public Criteria andCENTER_ERR_DTLIsNull() {
            addCriterion("CENTER_ERR_DTL is null");
            return (Criteria) this;
        }

        public Criteria andCENTER_ERR_DTLIsNotNull() {
            addCriterion("CENTER_ERR_DTL is not null");
            return (Criteria) this;
        }

        public Criteria andCENTER_ERR_DTLEqualTo(String value) {
            addCriterion("CENTER_ERR_DTL =", value, "CENTER_ERR_DTL");
            return (Criteria) this;
        }

        public Criteria andCENTER_ERR_DTLNotEqualTo(String value) {
            addCriterion("CENTER_ERR_DTL <>", value, "CENTER_ERR_DTL");
            return (Criteria) this;
        }

        public Criteria andCENTER_ERR_DTLGreaterThan(String value) {
            addCriterion("CENTER_ERR_DTL >", value, "CENTER_ERR_DTL");
            return (Criteria) this;
        }

        public Criteria andCENTER_ERR_DTLGreaterThanOrEqualTo(String value) {
            addCriterion("CENTER_ERR_DTL >=", value, "CENTER_ERR_DTL");
            return (Criteria) this;
        }

        public Criteria andCENTER_ERR_DTLLessThan(String value) {
            addCriterion("CENTER_ERR_DTL <", value, "CENTER_ERR_DTL");
            return (Criteria) this;
        }

        public Criteria andCENTER_ERR_DTLLessThanOrEqualTo(String value) {
            addCriterion("CENTER_ERR_DTL <=", value, "CENTER_ERR_DTL");
            return (Criteria) this;
        }

        public Criteria andCENTER_ERR_DTLLike(String value) {
            addCriterion("CENTER_ERR_DTL like", value, "CENTER_ERR_DTL");
            return (Criteria) this;
        }

        public Criteria andCENTER_ERR_DTLNotLike(String value) {
            addCriterion("CENTER_ERR_DTL not like", value, "CENTER_ERR_DTL");
            return (Criteria) this;
        }

        public Criteria andCENTER_ERR_DTLIn(List<String> values) {
            addCriterion("CENTER_ERR_DTL in", values, "CENTER_ERR_DTL");
            return (Criteria) this;
        }

        public Criteria andCENTER_ERR_DTLNotIn(List<String> values) {
            addCriterion("CENTER_ERR_DTL not in", values, "CENTER_ERR_DTL");
            return (Criteria) this;
        }

        public Criteria andCENTER_ERR_DTLBetween(String value1, String value2) {
            addCriterion("CENTER_ERR_DTL between", value1, value2, "CENTER_ERR_DTL");
            return (Criteria) this;
        }

        public Criteria andCENTER_ERR_DTLNotBetween(String value1, String value2) {
            addCriterion("CENTER_ERR_DTL not between", value1, value2, "CENTER_ERR_DTL");
            return (Criteria) this;
        }

        public Criteria andRM_RESULTIsNull() {
            addCriterion("RM_RESULT is null");
            return (Criteria) this;
        }

        public Criteria andRM_RESULTIsNotNull() {
            addCriterion("RM_RESULT is not null");
            return (Criteria) this;
        }

        public Criteria andRM_RESULTEqualTo(String value) {
            addCriterion("RM_RESULT =", value, "RM_RESULT");
            return (Criteria) this;
        }

        public Criteria andRM_RESULTNotEqualTo(String value) {
            addCriterion("RM_RESULT <>", value, "RM_RESULT");
            return (Criteria) this;
        }

        public Criteria andRM_RESULTGreaterThan(String value) {
            addCriterion("RM_RESULT >", value, "RM_RESULT");
            return (Criteria) this;
        }

        public Criteria andRM_RESULTGreaterThanOrEqualTo(String value) {
            addCriterion("RM_RESULT >=", value, "RM_RESULT");
            return (Criteria) this;
        }

        public Criteria andRM_RESULTLessThan(String value) {
            addCriterion("RM_RESULT <", value, "RM_RESULT");
            return (Criteria) this;
        }

        public Criteria andRM_RESULTLessThanOrEqualTo(String value) {
            addCriterion("RM_RESULT <=", value, "RM_RESULT");
            return (Criteria) this;
        }

        public Criteria andRM_RESULTLike(String value) {
            addCriterion("RM_RESULT like", value, "RM_RESULT");
            return (Criteria) this;
        }

        public Criteria andRM_RESULTNotLike(String value) {
            addCriterion("RM_RESULT not like", value, "RM_RESULT");
            return (Criteria) this;
        }

        public Criteria andRM_RESULTIn(List<String> values) {
            addCriterion("RM_RESULT in", values, "RM_RESULT");
            return (Criteria) this;
        }

        public Criteria andRM_RESULTNotIn(List<String> values) {
            addCriterion("RM_RESULT not in", values, "RM_RESULT");
            return (Criteria) this;
        }

        public Criteria andRM_RESULTBetween(String value1, String value2) {
            addCriterion("RM_RESULT between", value1, value2, "RM_RESULT");
            return (Criteria) this;
        }

        public Criteria andRM_RESULTNotBetween(String value1, String value2) {
            addCriterion("RM_RESULT not between", value1, value2, "RM_RESULT");
            return (Criteria) this;
        }

        public Criteria andRM_ERR_CDIsNull() {
            addCriterion("RM_ERR_CD is null");
            return (Criteria) this;
        }

        public Criteria andRM_ERR_CDIsNotNull() {
            addCriterion("RM_ERR_CD is not null");
            return (Criteria) this;
        }

        public Criteria andRM_ERR_CDEqualTo(String value) {
            addCriterion("RM_ERR_CD =", value, "RM_ERR_CD");
            return (Criteria) this;
        }

        public Criteria andRM_ERR_CDNotEqualTo(String value) {
            addCriterion("RM_ERR_CD <>", value, "RM_ERR_CD");
            return (Criteria) this;
        }

        public Criteria andRM_ERR_CDGreaterThan(String value) {
            addCriterion("RM_ERR_CD >", value, "RM_ERR_CD");
            return (Criteria) this;
        }

        public Criteria andRM_ERR_CDGreaterThanOrEqualTo(String value) {
            addCriterion("RM_ERR_CD >=", value, "RM_ERR_CD");
            return (Criteria) this;
        }

        public Criteria andRM_ERR_CDLessThan(String value) {
            addCriterion("RM_ERR_CD <", value, "RM_ERR_CD");
            return (Criteria) this;
        }

        public Criteria andRM_ERR_CDLessThanOrEqualTo(String value) {
            addCriterion("RM_ERR_CD <=", value, "RM_ERR_CD");
            return (Criteria) this;
        }

        public Criteria andRM_ERR_CDLike(String value) {
            addCriterion("RM_ERR_CD like", value, "RM_ERR_CD");
            return (Criteria) this;
        }

        public Criteria andRM_ERR_CDNotLike(String value) {
            addCriterion("RM_ERR_CD not like", value, "RM_ERR_CD");
            return (Criteria) this;
        }

        public Criteria andRM_ERR_CDIn(List<String> values) {
            addCriterion("RM_ERR_CD in", values, "RM_ERR_CD");
            return (Criteria) this;
        }

        public Criteria andRM_ERR_CDNotIn(List<String> values) {
            addCriterion("RM_ERR_CD not in", values, "RM_ERR_CD");
            return (Criteria) this;
        }

        public Criteria andRM_ERR_CDBetween(String value1, String value2) {
            addCriterion("RM_ERR_CD between", value1, value2, "RM_ERR_CD");
            return (Criteria) this;
        }

        public Criteria andRM_ERR_CDNotBetween(String value1, String value2) {
            addCriterion("RM_ERR_CD not between", value1, value2, "RM_ERR_CD");
            return (Criteria) this;
        }

        public Criteria andCTL_RESULT_CDIsNull() {
            addCriterion("CTL_RESULT_CD is null");
            return (Criteria) this;
        }

        public Criteria andCTL_RESULT_CDIsNotNull() {
            addCriterion("CTL_RESULT_CD is not null");
            return (Criteria) this;
        }

        public Criteria andCTL_RESULT_CDEqualTo(String value) {
            addCriterion("CTL_RESULT_CD =", value, "CTL_RESULT_CD");
            return (Criteria) this;
        }

        public Criteria andCTL_RESULT_CDNotEqualTo(String value) {
            addCriterion("CTL_RESULT_CD <>", value, "CTL_RESULT_CD");
            return (Criteria) this;
        }

        public Criteria andCTL_RESULT_CDGreaterThan(String value) {
            addCriterion("CTL_RESULT_CD >", value, "CTL_RESULT_CD");
            return (Criteria) this;
        }

        public Criteria andCTL_RESULT_CDGreaterThanOrEqualTo(String value) {
            addCriterion("CTL_RESULT_CD >=", value, "CTL_RESULT_CD");
            return (Criteria) this;
        }

        public Criteria andCTL_RESULT_CDLessThan(String value) {
            addCriterion("CTL_RESULT_CD <", value, "CTL_RESULT_CD");
            return (Criteria) this;
        }

        public Criteria andCTL_RESULT_CDLessThanOrEqualTo(String value) {
            addCriterion("CTL_RESULT_CD <=", value, "CTL_RESULT_CD");
            return (Criteria) this;
        }

        public Criteria andCTL_RESULT_CDLike(String value) {
            addCriterion("CTL_RESULT_CD like", value, "CTL_RESULT_CD");
            return (Criteria) this;
        }

        public Criteria andCTL_RESULT_CDNotLike(String value) {
            addCriterion("CTL_RESULT_CD not like", value, "CTL_RESULT_CD");
            return (Criteria) this;
        }

        public Criteria andCTL_RESULT_CDIn(List<String> values) {
            addCriterion("CTL_RESULT_CD in", values, "CTL_RESULT_CD");
            return (Criteria) this;
        }

        public Criteria andCTL_RESULT_CDNotIn(List<String> values) {
            addCriterion("CTL_RESULT_CD not in", values, "CTL_RESULT_CD");
            return (Criteria) this;
        }

        public Criteria andCTL_RESULT_CDBetween(String value1, String value2) {
            addCriterion("CTL_RESULT_CD between", value1, value2, "CTL_RESULT_CD");
            return (Criteria) this;
        }

        public Criteria andCTL_RESULT_CDNotBetween(String value1, String value2) {
            addCriterion("CTL_RESULT_CD not between", value1, value2, "CTL_RESULT_CD");
            return (Criteria) this;
        }

        public Criteria andCTL_CMD_RSLTIsNull() {
            addCriterion("CTL_CMD_RSLT is null");
            return (Criteria) this;
        }

        public Criteria andCTL_CMD_RSLTIsNotNull() {
            addCriterion("CTL_CMD_RSLT is not null");
            return (Criteria) this;
        }

        public Criteria andCTL_CMD_RSLTEqualTo(String value) {
            addCriterion("CTL_CMD_RSLT =", value, "CTL_CMD_RSLT");
            return (Criteria) this;
        }

        public Criteria andCTL_CMD_RSLTNotEqualTo(String value) {
            addCriterion("CTL_CMD_RSLT <>", value, "CTL_CMD_RSLT");
            return (Criteria) this;
        }

        public Criteria andCTL_CMD_RSLTGreaterThan(String value) {
            addCriterion("CTL_CMD_RSLT >", value, "CTL_CMD_RSLT");
            return (Criteria) this;
        }

        public Criteria andCTL_CMD_RSLTGreaterThanOrEqualTo(String value) {
            addCriterion("CTL_CMD_RSLT >=", value, "CTL_CMD_RSLT");
            return (Criteria) this;
        }

        public Criteria andCTL_CMD_RSLTLessThan(String value) {
            addCriterion("CTL_CMD_RSLT <", value, "CTL_CMD_RSLT");
            return (Criteria) this;
        }

        public Criteria andCTL_CMD_RSLTLessThanOrEqualTo(String value) {
            addCriterion("CTL_CMD_RSLT <=", value, "CTL_CMD_RSLT");
            return (Criteria) this;
        }

        public Criteria andCTL_CMD_RSLTLike(String value) {
            addCriterion("CTL_CMD_RSLT like", value, "CTL_CMD_RSLT");
            return (Criteria) this;
        }

        public Criteria andCTL_CMD_RSLTNotLike(String value) {
            addCriterion("CTL_CMD_RSLT not like", value, "CTL_CMD_RSLT");
            return (Criteria) this;
        }

        public Criteria andCTL_CMD_RSLTIn(List<String> values) {
            addCriterion("CTL_CMD_RSLT in", values, "CTL_CMD_RSLT");
            return (Criteria) this;
        }

        public Criteria andCTL_CMD_RSLTNotIn(List<String> values) {
            addCriterion("CTL_CMD_RSLT not in", values, "CTL_CMD_RSLT");
            return (Criteria) this;
        }

        public Criteria andCTL_CMD_RSLTBetween(String value1, String value2) {
            addCriterion("CTL_CMD_RSLT between", value1, value2, "CTL_CMD_RSLT");
            return (Criteria) this;
        }

        public Criteria andCTL_CMD_RSLTNotBetween(String value1, String value2) {
            addCriterion("CTL_CMD_RSLT not between", value1, value2, "CTL_CMD_RSLT");
            return (Criteria) this;
        }

        public Criteria andCMD_TIMEOUT_TMIsNull() {
            addCriterion("CMD_TIMEOUT_TM is null");
            return (Criteria) this;
        }

        public Criteria andCMD_TIMEOUT_TMIsNotNull() {
            addCriterion("CMD_TIMEOUT_TM is not null");
            return (Criteria) this;
        }

        public Criteria andCMD_TIMEOUT_TMEqualTo(Date value) {
            addCriterion("CMD_TIMEOUT_TM =", value, "CMD_TIMEOUT_TM");
            return (Criteria) this;
        }

        public Criteria andCMD_TIMEOUT_TMNotEqualTo(Date value) {
            addCriterion("CMD_TIMEOUT_TM <>", value, "CMD_TIMEOUT_TM");
            return (Criteria) this;
        }

        public Criteria andCMD_TIMEOUT_TMGreaterThan(Date value) {
            addCriterion("CMD_TIMEOUT_TM >", value, "CMD_TIMEOUT_TM");
            return (Criteria) this;
        }

        public Criteria andCMD_TIMEOUT_TMGreaterThanOrEqualTo(Date value) {
            addCriterion("CMD_TIMEOUT_TM >=", value, "CMD_TIMEOUT_TM");
            return (Criteria) this;
        }

        public Criteria andCMD_TIMEOUT_TMLessThan(Date value) {
            addCriterion("CMD_TIMEOUT_TM <", value, "CMD_TIMEOUT_TM");
            return (Criteria) this;
        }

        public Criteria andCMD_TIMEOUT_TMLessThanOrEqualTo(Date value) {
            addCriterion("CMD_TIMEOUT_TM <=", value, "CMD_TIMEOUT_TM");
            return (Criteria) this;
        }

        public Criteria andCMD_TIMEOUT_TMIn(List<Date> values) {
            addCriterion("CMD_TIMEOUT_TM in", values, "CMD_TIMEOUT_TM");
            return (Criteria) this;
        }

        public Criteria andCMD_TIMEOUT_TMNotIn(List<Date> values) {
            addCriterion("CMD_TIMEOUT_TM not in", values, "CMD_TIMEOUT_TM");
            return (Criteria) this;
        }

        public Criteria andCMD_TIMEOUT_TMBetween(Date value1, Date value2) {
            addCriterion("CMD_TIMEOUT_TM between", value1, value2, "CMD_TIMEOUT_TM");
            return (Criteria) this;
        }

        public Criteria andCMD_TIMEOUT_TMNotBetween(Date value1, Date value2) {
            addCriterion("CMD_TIMEOUT_TM not between", value1, value2, "CMD_TIMEOUT_TM");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andLN_QUE_CTRL_SIGLikeInsensitive(String value) {
            addCriterion("upper(LN_QUE_CTRL_SIG) like", value.toUpperCase(), "LN_QUE_CTRL_SIG");
            return (Criteria) this;
        }

        public Criteria andHOST_NMLikeInsensitive(String value) {
            addCriterion("upper(HOST_NM) like", value.toUpperCase(), "HOST_NM");
            return (Criteria) this;
        }

        public Criteria andDENKEILikeInsensitive(String value) {
            addCriterion("upper(DENKEI) like", value.toUpperCase(), "DENKEI");
            return (Criteria) this;
        }

        public Criteria andGOUKILikeInsensitive(String value) {
            addCriterion("upper(GOUKI) like", value.toUpperCase(), "GOUKI");
            return (Criteria) this;
        }

        public Criteria andSERIAL_NUMLikeInsensitive(String value) {
            addCriterion("upper(SERIAL_NUM) like", value.toUpperCase(), "SERIAL_NUM");
            return (Criteria) this;
        }

        public Criteria andCONN_DEV_NUMLikeInsensitive(String value) {
            addCriterion("upper(CONN_DEV_NUM) like", value.toUpperCase(), "CONN_DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMLikeInsensitive(String value) {
            addCriterion("upper(DEV_NUM) like", value.toUpperCase(), "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andSUB_ADDRLikeInsensitive(String value) {
            addCriterion("upper(SUB_ADDR) like", value.toUpperCase(), "SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andPRIORITYLikeInsensitive(String value) {
            addCriterion("upper(PRIORITY) like", value.toUpperCase(), "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andCMD_SEQ_NUMLikeInsensitive(String value) {
            addCriterion("upper(CMD_SEQ_NUM) like", value.toUpperCase(), "CMD_SEQ_NUM");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMLikeInsensitive(String value) {
            addCriterion("upper(PROCESS_NUM) like", value.toUpperCase(), "PROCESS_NUM");
            return (Criteria) this;
        }

        public Criteria andCMD_CDLikeInsensitive(String value) {
            addCriterion("upper(CMD_CD) like", value.toUpperCase(), "CMD_CD");
            return (Criteria) this;
        }

        public Criteria andEXEC_CMDLikeInsensitive(String value) {
            addCriterion("upper(EXEC_CMD) like", value.toUpperCase(), "EXEC_CMD");
            return (Criteria) this;
        }

        public Criteria andDIR_NMLikeInsensitive(String value) {
            addCriterion("upper(DIR_NM) like", value.toUpperCase(), "DIR_NM");
            return (Criteria) this;
        }

        public Criteria andSTSLikeInsensitive(String value) {
            addCriterion("upper(STS) like", value.toUpperCase(), "STS");
            return (Criteria) this;
        }

        public Criteria andCENTER_ERR_DTLLikeInsensitive(String value) {
            addCriterion("upper(CENTER_ERR_DTL) like", value.toUpperCase(), "CENTER_ERR_DTL");
            return (Criteria) this;
        }

        public Criteria andRM_RESULTLikeInsensitive(String value) {
            addCriterion("upper(RM_RESULT) like", value.toUpperCase(), "RM_RESULT");
            return (Criteria) this;
        }

        public Criteria andRM_ERR_CDLikeInsensitive(String value) {
            addCriterion("upper(RM_ERR_CD) like", value.toUpperCase(), "RM_ERR_CD");
            return (Criteria) this;
        }

        public Criteria andCTL_RESULT_CDLikeInsensitive(String value) {
            addCriterion("upper(CTL_RESULT_CD) like", value.toUpperCase(), "CTL_RESULT_CD");
            return (Criteria) this;
        }

        public Criteria andCTL_CMD_RSLTLikeInsensitive(String value) {
            addCriterion("upper(CTL_CMD_RSLT) like", value.toUpperCase(), "CTL_CMD_RSLT");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * C_QUE_CTRL_SIG
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * C_QUE_CTRL_SIG null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}