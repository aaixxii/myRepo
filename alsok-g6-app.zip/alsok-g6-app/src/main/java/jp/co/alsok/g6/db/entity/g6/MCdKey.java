package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class MCdKey implements Serializable {
    /**
     * コードID
     */
    private String CD_ID;

    /**
     * コード値
     */
    private String CD_VALUE;

    /**
     * M_CD
     */
    private static final long serialVersionUID = 1L;

    /**
     * コードID
     * @return CD_ID コードID
     */
    public String getCD_ID() {
        return CD_ID;
    }

    /**
     * コードID
     * @param CD_ID コードID
     */
    public void setCD_ID(String CD_ID) {
        this.CD_ID = CD_ID == null ? null : CD_ID.trim();
    }

    /**
     * コード値
     * @return CD_VALUE コード値
     */
    public String getCD_VALUE() {
        return CD_VALUE;
    }

    /**
     * コード値
     * @param CD_VALUE コード値
     */
    public void setCD_VALUE(String CD_VALUE) {
        this.CD_VALUE = CD_VALUE == null ? null : CD_VALUE.trim();
    }
}