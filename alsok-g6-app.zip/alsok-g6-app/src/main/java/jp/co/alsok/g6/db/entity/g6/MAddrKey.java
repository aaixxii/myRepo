package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class MAddrKey implements Serializable {
    /**
     * 都道府県ID
     */
    private String ADDR_CD1_ID;

    /**
     * 市区町村ID
     */
    private String ADDR_CD2_ID;

    /**
     * 大字町ID
     */
    private String ADDR_CD3_ID;

    /**
     * 小字町ID
     */
    private String ADDR_CD4_ID;

    /**
     * 丁目ID
     */
    private String ADDR_CD5_ID;

    /**
     * 番地ID
     */
    private String ADDR_CD6_ID;

    /**
     * M_ADDR
     */
    private static final long serialVersionUID = 1L;

    /**
     * 都道府県ID
     * @return ADDR_CD1_ID 都道府県ID
     */
    public String getADDR_CD1_ID() {
        return ADDR_CD1_ID;
    }

    /**
     * 都道府県ID
     * @param ADDR_CD1_ID 都道府県ID
     */
    public void setADDR_CD1_ID(String ADDR_CD1_ID) {
        this.ADDR_CD1_ID = ADDR_CD1_ID == null ? null : ADDR_CD1_ID.trim();
    }

    /**
     * 市区町村ID
     * @return ADDR_CD2_ID 市区町村ID
     */
    public String getADDR_CD2_ID() {
        return ADDR_CD2_ID;
    }

    /**
     * 市区町村ID
     * @param ADDR_CD2_ID 市区町村ID
     */
    public void setADDR_CD2_ID(String ADDR_CD2_ID) {
        this.ADDR_CD2_ID = ADDR_CD2_ID == null ? null : ADDR_CD2_ID.trim();
    }

    /**
     * 大字町ID
     * @return ADDR_CD3_ID 大字町ID
     */
    public String getADDR_CD3_ID() {
        return ADDR_CD3_ID;
    }

    /**
     * 大字町ID
     * @param ADDR_CD3_ID 大字町ID
     */
    public void setADDR_CD3_ID(String ADDR_CD3_ID) {
        this.ADDR_CD3_ID = ADDR_CD3_ID == null ? null : ADDR_CD3_ID.trim();
    }

    /**
     * 小字町ID
     * @return ADDR_CD4_ID 小字町ID
     */
    public String getADDR_CD4_ID() {
        return ADDR_CD4_ID;
    }

    /**
     * 小字町ID
     * @param ADDR_CD4_ID 小字町ID
     */
    public void setADDR_CD4_ID(String ADDR_CD4_ID) {
        this.ADDR_CD4_ID = ADDR_CD4_ID == null ? null : ADDR_CD4_ID.trim();
    }

    /**
     * 丁目ID
     * @return ADDR_CD5_ID 丁目ID
     */
    public String getADDR_CD5_ID() {
        return ADDR_CD5_ID;
    }

    /**
     * 丁目ID
     * @param ADDR_CD5_ID 丁目ID
     */
    public void setADDR_CD5_ID(String ADDR_CD5_ID) {
        this.ADDR_CD5_ID = ADDR_CD5_ID == null ? null : ADDR_CD5_ID.trim();
    }

    /**
     * 番地ID
     * @return ADDR_CD6_ID 番地ID
     */
    public String getADDR_CD6_ID() {
        return ADDR_CD6_ID;
    }

    /**
     * 番地ID
     * @param ADDR_CD6_ID 番地ID
     */
    public void setADDR_CD6_ID(String ADDR_CD6_ID) {
        this.ADDR_CD6_ID = ADDR_CD6_ID == null ? null : ADDR_CD6_ID.trim();
    }
}