package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EJianExample {
    /**
     * E_JIAN
     */
    protected String orderByClause;

    /**
     * E_JIAN
     */
    protected boolean distinct;

    /**
     * E_JIAN
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public EJianExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * E_JIAN null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_JIANIsNull() {
            addCriterion("LN_JIAN is null");
            return (Criteria) this;
        }

        public Criteria andLN_JIANIsNotNull() {
            addCriterion("LN_JIAN is not null");
            return (Criteria) this;
        }

        public Criteria andLN_JIANEqualTo(String value) {
            addCriterion("LN_JIAN =", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANNotEqualTo(String value) {
            addCriterion("LN_JIAN <>", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANGreaterThan(String value) {
            addCriterion("LN_JIAN >", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANGreaterThanOrEqualTo(String value) {
            addCriterion("LN_JIAN >=", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANLessThan(String value) {
            addCriterion("LN_JIAN <", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANLessThanOrEqualTo(String value) {
            addCriterion("LN_JIAN <=", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANLike(String value) {
            addCriterion("LN_JIAN like", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANNotLike(String value) {
            addCriterion("LN_JIAN not like", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANIn(List<String> values) {
            addCriterion("LN_JIAN in", values, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANNotIn(List<String> values) {
            addCriterion("LN_JIAN not in", values, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANBetween(String value1, String value2) {
            addCriterion("LN_JIAN between", value1, value2, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANNotBetween(String value1, String value2) {
            addCriterion("LN_JIAN not between", value1, value2, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JITAIIsNull() {
            addCriterion("LN_JITAI is null");
            return (Criteria) this;
        }

        public Criteria andLN_JITAIIsNotNull() {
            addCriterion("LN_JITAI is not null");
            return (Criteria) this;
        }

        public Criteria andLN_JITAIEqualTo(String value) {
            addCriterion("LN_JITAI =", value, "LN_JITAI");
            return (Criteria) this;
        }

        public Criteria andLN_JITAINotEqualTo(String value) {
            addCriterion("LN_JITAI <>", value, "LN_JITAI");
            return (Criteria) this;
        }

        public Criteria andLN_JITAIGreaterThan(String value) {
            addCriterion("LN_JITAI >", value, "LN_JITAI");
            return (Criteria) this;
        }

        public Criteria andLN_JITAIGreaterThanOrEqualTo(String value) {
            addCriterion("LN_JITAI >=", value, "LN_JITAI");
            return (Criteria) this;
        }

        public Criteria andLN_JITAILessThan(String value) {
            addCriterion("LN_JITAI <", value, "LN_JITAI");
            return (Criteria) this;
        }

        public Criteria andLN_JITAILessThanOrEqualTo(String value) {
            addCriterion("LN_JITAI <=", value, "LN_JITAI");
            return (Criteria) this;
        }

        public Criteria andLN_JITAILike(String value) {
            addCriterion("LN_JITAI like", value, "LN_JITAI");
            return (Criteria) this;
        }

        public Criteria andLN_JITAINotLike(String value) {
            addCriterion("LN_JITAI not like", value, "LN_JITAI");
            return (Criteria) this;
        }

        public Criteria andLN_JITAIIn(List<String> values) {
            addCriterion("LN_JITAI in", values, "LN_JITAI");
            return (Criteria) this;
        }

        public Criteria andLN_JITAINotIn(List<String> values) {
            addCriterion("LN_JITAI not in", values, "LN_JITAI");
            return (Criteria) this;
        }

        public Criteria andLN_JITAIBetween(String value1, String value2) {
            addCriterion("LN_JITAI between", value1, value2, "LN_JITAI");
            return (Criteria) this;
        }

        public Criteria andLN_JITAINotBetween(String value1, String value2) {
            addCriterion("LN_JITAI not between", value1, value2, "LN_JITAI");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUIsNull() {
            addCriterion("LN_KB_CHIKU is null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUIsNotNull() {
            addCriterion("LN_KB_CHIKU is not null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUEqualTo(String value) {
            addCriterion("LN_KB_CHIKU =", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUNotEqualTo(String value) {
            addCriterion("LN_KB_CHIKU <>", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUGreaterThan(String value) {
            addCriterion("LN_KB_CHIKU >", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUGreaterThanOrEqualTo(String value) {
            addCriterion("LN_KB_CHIKU >=", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKULessThan(String value) {
            addCriterion("LN_KB_CHIKU <", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKULessThanOrEqualTo(String value) {
            addCriterion("LN_KB_CHIKU <=", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKULike(String value) {
            addCriterion("LN_KB_CHIKU like", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUNotLike(String value) {
            addCriterion("LN_KB_CHIKU not like", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUIn(List<String> values) {
            addCriterion("LN_KB_CHIKU in", values, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUNotIn(List<String> values) {
            addCriterion("LN_KB_CHIKU not in", values, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUBetween(String value1, String value2) {
            addCriterion("LN_KB_CHIKU between", value1, value2, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUNotBetween(String value1, String value2) {
            addCriterion("LN_KB_CHIKU not between", value1, value2, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGIsNull() {
            addCriterion("BUZZ_FLG is null");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGIsNotNull() {
            addCriterion("BUZZ_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGEqualTo(String value) {
            addCriterion("BUZZ_FLG =", value, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGNotEqualTo(String value) {
            addCriterion("BUZZ_FLG <>", value, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGGreaterThan(String value) {
            addCriterion("BUZZ_FLG >", value, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("BUZZ_FLG >=", value, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGLessThan(String value) {
            addCriterion("BUZZ_FLG <", value, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGLessThanOrEqualTo(String value) {
            addCriterion("BUZZ_FLG <=", value, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGLike(String value) {
            addCriterion("BUZZ_FLG like", value, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGNotLike(String value) {
            addCriterion("BUZZ_FLG not like", value, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGIn(List<String> values) {
            addCriterion("BUZZ_FLG in", values, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGNotIn(List<String> values) {
            addCriterion("BUZZ_FLG not in", values, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGBetween(String value1, String value2) {
            addCriterion("BUZZ_FLG between", value1, value2, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGNotBetween(String value1, String value2) {
            addCriterion("BUZZ_FLG not between", value1, value2, "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andPRIORITYIsNull() {
            addCriterion("PRIORITY is null");
            return (Criteria) this;
        }

        public Criteria andPRIORITYIsNotNull() {
            addCriterion("PRIORITY is not null");
            return (Criteria) this;
        }

        public Criteria andPRIORITYEqualTo(String value) {
            addCriterion("PRIORITY =", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYNotEqualTo(String value) {
            addCriterion("PRIORITY <>", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYGreaterThan(String value) {
            addCriterion("PRIORITY >", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYGreaterThanOrEqualTo(String value) {
            addCriterion("PRIORITY >=", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYLessThan(String value) {
            addCriterion("PRIORITY <", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYLessThanOrEqualTo(String value) {
            addCriterion("PRIORITY <=", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYLike(String value) {
            addCriterion("PRIORITY like", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYNotLike(String value) {
            addCriterion("PRIORITY not like", value, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYIn(List<String> values) {
            addCriterion("PRIORITY in", values, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYNotIn(List<String> values) {
            addCriterion("PRIORITY not in", values, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYBetween(String value1, String value2) {
            addCriterion("PRIORITY between", value1, value2, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andPRIORITYNotBetween(String value1, String value2) {
            addCriterion("PRIORITY not between", value1, value2, "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andJIAN_CAUSE_FLGIsNull() {
            addCriterion("JIAN_CAUSE_FLG is null");
            return (Criteria) this;
        }

        public Criteria andJIAN_CAUSE_FLGIsNotNull() {
            addCriterion("JIAN_CAUSE_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andJIAN_CAUSE_FLGEqualTo(String value) {
            addCriterion("JIAN_CAUSE_FLG =", value, "JIAN_CAUSE_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_CAUSE_FLGNotEqualTo(String value) {
            addCriterion("JIAN_CAUSE_FLG <>", value, "JIAN_CAUSE_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_CAUSE_FLGGreaterThan(String value) {
            addCriterion("JIAN_CAUSE_FLG >", value, "JIAN_CAUSE_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_CAUSE_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("JIAN_CAUSE_FLG >=", value, "JIAN_CAUSE_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_CAUSE_FLGLessThan(String value) {
            addCriterion("JIAN_CAUSE_FLG <", value, "JIAN_CAUSE_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_CAUSE_FLGLessThanOrEqualTo(String value) {
            addCriterion("JIAN_CAUSE_FLG <=", value, "JIAN_CAUSE_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_CAUSE_FLGLike(String value) {
            addCriterion("JIAN_CAUSE_FLG like", value, "JIAN_CAUSE_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_CAUSE_FLGNotLike(String value) {
            addCriterion("JIAN_CAUSE_FLG not like", value, "JIAN_CAUSE_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_CAUSE_FLGIn(List<String> values) {
            addCriterion("JIAN_CAUSE_FLG in", values, "JIAN_CAUSE_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_CAUSE_FLGNotIn(List<String> values) {
            addCriterion("JIAN_CAUSE_FLG not in", values, "JIAN_CAUSE_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_CAUSE_FLGBetween(String value1, String value2) {
            addCriterion("JIAN_CAUSE_FLG between", value1, value2, "JIAN_CAUSE_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_CAUSE_FLGNotBetween(String value1, String value2) {
            addCriterion("JIAN_CAUSE_FLG not between", value1, value2, "JIAN_CAUSE_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_HYOJI_FLGIsNull() {
            addCriterion("JIAN_HYOJI_FLG is null");
            return (Criteria) this;
        }

        public Criteria andJIAN_HYOJI_FLGIsNotNull() {
            addCriterion("JIAN_HYOJI_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andJIAN_HYOJI_FLGEqualTo(String value) {
            addCriterion("JIAN_HYOJI_FLG =", value, "JIAN_HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_HYOJI_FLGNotEqualTo(String value) {
            addCriterion("JIAN_HYOJI_FLG <>", value, "JIAN_HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_HYOJI_FLGGreaterThan(String value) {
            addCriterion("JIAN_HYOJI_FLG >", value, "JIAN_HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_HYOJI_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("JIAN_HYOJI_FLG >=", value, "JIAN_HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_HYOJI_FLGLessThan(String value) {
            addCriterion("JIAN_HYOJI_FLG <", value, "JIAN_HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_HYOJI_FLGLessThanOrEqualTo(String value) {
            addCriterion("JIAN_HYOJI_FLG <=", value, "JIAN_HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_HYOJI_FLGLike(String value) {
            addCriterion("JIAN_HYOJI_FLG like", value, "JIAN_HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_HYOJI_FLGNotLike(String value) {
            addCriterion("JIAN_HYOJI_FLG not like", value, "JIAN_HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_HYOJI_FLGIn(List<String> values) {
            addCriterion("JIAN_HYOJI_FLG in", values, "JIAN_HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_HYOJI_FLGNotIn(List<String> values) {
            addCriterion("JIAN_HYOJI_FLG not in", values, "JIAN_HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_HYOJI_FLGBetween(String value1, String value2) {
            addCriterion("JIAN_HYOJI_FLG between", value1, value2, "JIAN_HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_HYOJI_FLGNotBetween(String value1, String value2) {
            addCriterion("JIAN_HYOJI_FLG not between", value1, value2, "JIAN_HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_TANTO_FLGIsNull() {
            addCriterion("JIAN_TANTO_FLG is null");
            return (Criteria) this;
        }

        public Criteria andJIAN_TANTO_FLGIsNotNull() {
            addCriterion("JIAN_TANTO_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andJIAN_TANTO_FLGEqualTo(String value) {
            addCriterion("JIAN_TANTO_FLG =", value, "JIAN_TANTO_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_TANTO_FLGNotEqualTo(String value) {
            addCriterion("JIAN_TANTO_FLG <>", value, "JIAN_TANTO_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_TANTO_FLGGreaterThan(String value) {
            addCriterion("JIAN_TANTO_FLG >", value, "JIAN_TANTO_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_TANTO_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("JIAN_TANTO_FLG >=", value, "JIAN_TANTO_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_TANTO_FLGLessThan(String value) {
            addCriterion("JIAN_TANTO_FLG <", value, "JIAN_TANTO_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_TANTO_FLGLessThanOrEqualTo(String value) {
            addCriterion("JIAN_TANTO_FLG <=", value, "JIAN_TANTO_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_TANTO_FLGLike(String value) {
            addCriterion("JIAN_TANTO_FLG like", value, "JIAN_TANTO_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_TANTO_FLGNotLike(String value) {
            addCriterion("JIAN_TANTO_FLG not like", value, "JIAN_TANTO_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_TANTO_FLGIn(List<String> values) {
            addCriterion("JIAN_TANTO_FLG in", values, "JIAN_TANTO_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_TANTO_FLGNotIn(List<String> values) {
            addCriterion("JIAN_TANTO_FLG not in", values, "JIAN_TANTO_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_TANTO_FLGBetween(String value1, String value2) {
            addCriterion("JIAN_TANTO_FLG between", value1, value2, "JIAN_TANTO_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_TANTO_FLGNotBetween(String value1, String value2) {
            addCriterion("JIAN_TANTO_FLG not between", value1, value2, "JIAN_TANTO_FLG");
            return (Criteria) this;
        }

        public Criteria andTIMEOUT_TSIsNull() {
            addCriterion("TIMEOUT_TS is null");
            return (Criteria) this;
        }

        public Criteria andTIMEOUT_TSIsNotNull() {
            addCriterion("TIMEOUT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andTIMEOUT_TSEqualTo(Date value) {
            addCriterion("TIMEOUT_TS =", value, "TIMEOUT_TS");
            return (Criteria) this;
        }

        public Criteria andTIMEOUT_TSNotEqualTo(Date value) {
            addCriterion("TIMEOUT_TS <>", value, "TIMEOUT_TS");
            return (Criteria) this;
        }

        public Criteria andTIMEOUT_TSGreaterThan(Date value) {
            addCriterion("TIMEOUT_TS >", value, "TIMEOUT_TS");
            return (Criteria) this;
        }

        public Criteria andTIMEOUT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("TIMEOUT_TS >=", value, "TIMEOUT_TS");
            return (Criteria) this;
        }

        public Criteria andTIMEOUT_TSLessThan(Date value) {
            addCriterion("TIMEOUT_TS <", value, "TIMEOUT_TS");
            return (Criteria) this;
        }

        public Criteria andTIMEOUT_TSLessThanOrEqualTo(Date value) {
            addCriterion("TIMEOUT_TS <=", value, "TIMEOUT_TS");
            return (Criteria) this;
        }

        public Criteria andTIMEOUT_TSIn(List<Date> values) {
            addCriterion("TIMEOUT_TS in", values, "TIMEOUT_TS");
            return (Criteria) this;
        }

        public Criteria andTIMEOUT_TSNotIn(List<Date> values) {
            addCriterion("TIMEOUT_TS not in", values, "TIMEOUT_TS");
            return (Criteria) this;
        }

        public Criteria andTIMEOUT_TSBetween(Date value1, Date value2) {
            addCriterion("TIMEOUT_TS between", value1, value2, "TIMEOUT_TS");
            return (Criteria) this;
        }

        public Criteria andTIMEOUT_TSNotBetween(Date value1, Date value2) {
            addCriterion("TIMEOUT_TS not between", value1, value2, "TIMEOUT_TS");
            return (Criteria) this;
        }

        public Criteria andPRE_JIAN_HASSEI_TSIsNull() {
            addCriterion("PRE_JIAN_HASSEI_TS is null");
            return (Criteria) this;
        }

        public Criteria andPRE_JIAN_HASSEI_TSIsNotNull() {
            addCriterion("PRE_JIAN_HASSEI_TS is not null");
            return (Criteria) this;
        }

        public Criteria andPRE_JIAN_HASSEI_TSEqualTo(Date value) {
            addCriterion("PRE_JIAN_HASSEI_TS =", value, "PRE_JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andPRE_JIAN_HASSEI_TSNotEqualTo(Date value) {
            addCriterion("PRE_JIAN_HASSEI_TS <>", value, "PRE_JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andPRE_JIAN_HASSEI_TSGreaterThan(Date value) {
            addCriterion("PRE_JIAN_HASSEI_TS >", value, "PRE_JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andPRE_JIAN_HASSEI_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("PRE_JIAN_HASSEI_TS >=", value, "PRE_JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andPRE_JIAN_HASSEI_TSLessThan(Date value) {
            addCriterion("PRE_JIAN_HASSEI_TS <", value, "PRE_JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andPRE_JIAN_HASSEI_TSLessThanOrEqualTo(Date value) {
            addCriterion("PRE_JIAN_HASSEI_TS <=", value, "PRE_JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andPRE_JIAN_HASSEI_TSIn(List<Date> values) {
            addCriterion("PRE_JIAN_HASSEI_TS in", values, "PRE_JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andPRE_JIAN_HASSEI_TSNotIn(List<Date> values) {
            addCriterion("PRE_JIAN_HASSEI_TS not in", values, "PRE_JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andPRE_JIAN_HASSEI_TSBetween(Date value1, Date value2) {
            addCriterion("PRE_JIAN_HASSEI_TS between", value1, value2, "PRE_JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andPRE_JIAN_HASSEI_TSNotBetween(Date value1, Date value2) {
            addCriterion("PRE_JIAN_HASSEI_TS not between", value1, value2, "PRE_JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSIsNull() {
            addCriterion("JIAN_HASSEI_TS is null");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSIsNotNull() {
            addCriterion("JIAN_HASSEI_TS is not null");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSEqualTo(Date value) {
            addCriterion("JIAN_HASSEI_TS =", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSNotEqualTo(Date value) {
            addCriterion("JIAN_HASSEI_TS <>", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSGreaterThan(Date value) {
            addCriterion("JIAN_HASSEI_TS >", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("JIAN_HASSEI_TS >=", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSLessThan(Date value) {
            addCriterion("JIAN_HASSEI_TS <", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSLessThanOrEqualTo(Date value) {
            addCriterion("JIAN_HASSEI_TS <=", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSIn(List<Date> values) {
            addCriterion("JIAN_HASSEI_TS in", values, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSNotIn(List<Date> values) {
            addCriterion("JIAN_HASSEI_TS not in", values, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSBetween(Date value1, Date value2) {
            addCriterion("JIAN_HASSEI_TS between", value1, value2, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSNotBetween(Date value1, Date value2) {
            addCriterion("JIAN_HASSEI_TS not between", value1, value2, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIGIsNull() {
            addCriterion("LN_LAST_SIG is null");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIGIsNotNull() {
            addCriterion("LN_LAST_SIG is not null");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIGEqualTo(String value) {
            addCriterion("LN_LAST_SIG =", value, "LN_LAST_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIGNotEqualTo(String value) {
            addCriterion("LN_LAST_SIG <>", value, "LN_LAST_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIGGreaterThan(String value) {
            addCriterion("LN_LAST_SIG >", value, "LN_LAST_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIGGreaterThanOrEqualTo(String value) {
            addCriterion("LN_LAST_SIG >=", value, "LN_LAST_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIGLessThan(String value) {
            addCriterion("LN_LAST_SIG <", value, "LN_LAST_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIGLessThanOrEqualTo(String value) {
            addCriterion("LN_LAST_SIG <=", value, "LN_LAST_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIGLike(String value) {
            addCriterion("LN_LAST_SIG like", value, "LN_LAST_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIGNotLike(String value) {
            addCriterion("LN_LAST_SIG not like", value, "LN_LAST_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIGIn(List<String> values) {
            addCriterion("LN_LAST_SIG in", values, "LN_LAST_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIGNotIn(List<String> values) {
            addCriterion("LN_LAST_SIG not in", values, "LN_LAST_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIGBetween(String value1, String value2) {
            addCriterion("LN_LAST_SIG between", value1, value2, "LN_LAST_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIGNotBetween(String value1, String value2) {
            addCriterion("LN_LAST_SIG not between", value1, value2, "LN_LAST_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_NF_SIGIsNull() {
            addCriterion("LN_LAST_NF_SIG is null");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_NF_SIGIsNotNull() {
            addCriterion("LN_LAST_NF_SIG is not null");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_NF_SIGEqualTo(String value) {
            addCriterion("LN_LAST_NF_SIG =", value, "LN_LAST_NF_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_NF_SIGNotEqualTo(String value) {
            addCriterion("LN_LAST_NF_SIG <>", value, "LN_LAST_NF_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_NF_SIGGreaterThan(String value) {
            addCriterion("LN_LAST_NF_SIG >", value, "LN_LAST_NF_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_NF_SIGGreaterThanOrEqualTo(String value) {
            addCriterion("LN_LAST_NF_SIG >=", value, "LN_LAST_NF_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_NF_SIGLessThan(String value) {
            addCriterion("LN_LAST_NF_SIG <", value, "LN_LAST_NF_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_NF_SIGLessThanOrEqualTo(String value) {
            addCriterion("LN_LAST_NF_SIG <=", value, "LN_LAST_NF_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_NF_SIGLike(String value) {
            addCriterion("LN_LAST_NF_SIG like", value, "LN_LAST_NF_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_NF_SIGNotLike(String value) {
            addCriterion("LN_LAST_NF_SIG not like", value, "LN_LAST_NF_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_NF_SIGIn(List<String> values) {
            addCriterion("LN_LAST_NF_SIG in", values, "LN_LAST_NF_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_NF_SIGNotIn(List<String> values) {
            addCriterion("LN_LAST_NF_SIG not in", values, "LN_LAST_NF_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_NF_SIGBetween(String value1, String value2) {
            addCriterion("LN_LAST_NF_SIG between", value1, value2, "LN_LAST_NF_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_NF_SIGNotBetween(String value1, String value2) {
            addCriterion("LN_LAST_NF_SIG not between", value1, value2, "LN_LAST_NF_SIG");
            return (Criteria) this;
        }

        public Criteria andGC_SENT_FLGIsNull() {
            addCriterion("GC_SENT_FLG is null");
            return (Criteria) this;
        }

        public Criteria andGC_SENT_FLGIsNotNull() {
            addCriterion("GC_SENT_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andGC_SENT_FLGEqualTo(String value) {
            addCriterion("GC_SENT_FLG =", value, "GC_SENT_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_SENT_FLGNotEqualTo(String value) {
            addCriterion("GC_SENT_FLG <>", value, "GC_SENT_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_SENT_FLGGreaterThan(String value) {
            addCriterion("GC_SENT_FLG >", value, "GC_SENT_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_SENT_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("GC_SENT_FLG >=", value, "GC_SENT_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_SENT_FLGLessThan(String value) {
            addCriterion("GC_SENT_FLG <", value, "GC_SENT_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_SENT_FLGLessThanOrEqualTo(String value) {
            addCriterion("GC_SENT_FLG <=", value, "GC_SENT_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_SENT_FLGLike(String value) {
            addCriterion("GC_SENT_FLG like", value, "GC_SENT_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_SENT_FLGNotLike(String value) {
            addCriterion("GC_SENT_FLG not like", value, "GC_SENT_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_SENT_FLGIn(List<String> values) {
            addCriterion("GC_SENT_FLG in", values, "GC_SENT_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_SENT_FLGNotIn(List<String> values) {
            addCriterion("GC_SENT_FLG not in", values, "GC_SENT_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_SENT_FLGBetween(String value1, String value2) {
            addCriterion("GC_SENT_FLG between", value1, value2, "GC_SENT_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_SENT_FLGNotBetween(String value1, String value2) {
            addCriterion("GC_SENT_FLG not between", value1, value2, "GC_SENT_FLG");
            return (Criteria) this;
        }

        public Criteria andGC_SENT_TSIsNull() {
            addCriterion("GC_SENT_TS is null");
            return (Criteria) this;
        }

        public Criteria andGC_SENT_TSIsNotNull() {
            addCriterion("GC_SENT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andGC_SENT_TSEqualTo(Date value) {
            addCriterion("GC_SENT_TS =", value, "GC_SENT_TS");
            return (Criteria) this;
        }

        public Criteria andGC_SENT_TSNotEqualTo(Date value) {
            addCriterion("GC_SENT_TS <>", value, "GC_SENT_TS");
            return (Criteria) this;
        }

        public Criteria andGC_SENT_TSGreaterThan(Date value) {
            addCriterion("GC_SENT_TS >", value, "GC_SENT_TS");
            return (Criteria) this;
        }

        public Criteria andGC_SENT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("GC_SENT_TS >=", value, "GC_SENT_TS");
            return (Criteria) this;
        }

        public Criteria andGC_SENT_TSLessThan(Date value) {
            addCriterion("GC_SENT_TS <", value, "GC_SENT_TS");
            return (Criteria) this;
        }

        public Criteria andGC_SENT_TSLessThanOrEqualTo(Date value) {
            addCriterion("GC_SENT_TS <=", value, "GC_SENT_TS");
            return (Criteria) this;
        }

        public Criteria andGC_SENT_TSIn(List<Date> values) {
            addCriterion("GC_SENT_TS in", values, "GC_SENT_TS");
            return (Criteria) this;
        }

        public Criteria andGC_SENT_TSNotIn(List<Date> values) {
            addCriterion("GC_SENT_TS not in", values, "GC_SENT_TS");
            return (Criteria) this;
        }

        public Criteria andGC_SENT_TSBetween(Date value1, Date value2) {
            addCriterion("GC_SENT_TS between", value1, value2, "GC_SENT_TS");
            return (Criteria) this;
        }

        public Criteria andGC_SENT_TSNotBetween(Date value1, Date value2) {
            addCriterion("GC_SENT_TS not between", value1, value2, "GC_SENT_TS");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_MAKE_USERIsNull() {
            addCriterion("LN_JIAN_MAKE_USER is null");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_MAKE_USERIsNotNull() {
            addCriterion("LN_JIAN_MAKE_USER is not null");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_MAKE_USEREqualTo(String value) {
            addCriterion("LN_JIAN_MAKE_USER =", value, "LN_JIAN_MAKE_USER");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_MAKE_USERNotEqualTo(String value) {
            addCriterion("LN_JIAN_MAKE_USER <>", value, "LN_JIAN_MAKE_USER");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_MAKE_USERGreaterThan(String value) {
            addCriterion("LN_JIAN_MAKE_USER >", value, "LN_JIAN_MAKE_USER");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_MAKE_USERGreaterThanOrEqualTo(String value) {
            addCriterion("LN_JIAN_MAKE_USER >=", value, "LN_JIAN_MAKE_USER");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_MAKE_USERLessThan(String value) {
            addCriterion("LN_JIAN_MAKE_USER <", value, "LN_JIAN_MAKE_USER");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_MAKE_USERLessThanOrEqualTo(String value) {
            addCriterion("LN_JIAN_MAKE_USER <=", value, "LN_JIAN_MAKE_USER");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_MAKE_USERLike(String value) {
            addCriterion("LN_JIAN_MAKE_USER like", value, "LN_JIAN_MAKE_USER");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_MAKE_USERNotLike(String value) {
            addCriterion("LN_JIAN_MAKE_USER not like", value, "LN_JIAN_MAKE_USER");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_MAKE_USERIn(List<String> values) {
            addCriterion("LN_JIAN_MAKE_USER in", values, "LN_JIAN_MAKE_USER");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_MAKE_USERNotIn(List<String> values) {
            addCriterion("LN_JIAN_MAKE_USER not in", values, "LN_JIAN_MAKE_USER");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_MAKE_USERBetween(String value1, String value2) {
            addCriterion("LN_JIAN_MAKE_USER between", value1, value2, "LN_JIAN_MAKE_USER");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_MAKE_USERNotBetween(String value1, String value2) {
            addCriterion("LN_JIAN_MAKE_USER not between", value1, value2, "LN_JIAN_MAKE_USER");
            return (Criteria) this;
        }

        public Criteria andJIAN_MAKE_USER_NMIsNull() {
            addCriterion("JIAN_MAKE_USER_NM is null");
            return (Criteria) this;
        }

        public Criteria andJIAN_MAKE_USER_NMIsNotNull() {
            addCriterion("JIAN_MAKE_USER_NM is not null");
            return (Criteria) this;
        }

        public Criteria andJIAN_MAKE_USER_NMEqualTo(String value) {
            addCriterion("JIAN_MAKE_USER_NM =", value, "JIAN_MAKE_USER_NM");
            return (Criteria) this;
        }

        public Criteria andJIAN_MAKE_USER_NMNotEqualTo(String value) {
            addCriterion("JIAN_MAKE_USER_NM <>", value, "JIAN_MAKE_USER_NM");
            return (Criteria) this;
        }

        public Criteria andJIAN_MAKE_USER_NMGreaterThan(String value) {
            addCriterion("JIAN_MAKE_USER_NM >", value, "JIAN_MAKE_USER_NM");
            return (Criteria) this;
        }

        public Criteria andJIAN_MAKE_USER_NMGreaterThanOrEqualTo(String value) {
            addCriterion("JIAN_MAKE_USER_NM >=", value, "JIAN_MAKE_USER_NM");
            return (Criteria) this;
        }

        public Criteria andJIAN_MAKE_USER_NMLessThan(String value) {
            addCriterion("JIAN_MAKE_USER_NM <", value, "JIAN_MAKE_USER_NM");
            return (Criteria) this;
        }

        public Criteria andJIAN_MAKE_USER_NMLessThanOrEqualTo(String value) {
            addCriterion("JIAN_MAKE_USER_NM <=", value, "JIAN_MAKE_USER_NM");
            return (Criteria) this;
        }

        public Criteria andJIAN_MAKE_USER_NMLike(String value) {
            addCriterion("JIAN_MAKE_USER_NM like", value, "JIAN_MAKE_USER_NM");
            return (Criteria) this;
        }

        public Criteria andJIAN_MAKE_USER_NMNotLike(String value) {
            addCriterion("JIAN_MAKE_USER_NM not like", value, "JIAN_MAKE_USER_NM");
            return (Criteria) this;
        }

        public Criteria andJIAN_MAKE_USER_NMIn(List<String> values) {
            addCriterion("JIAN_MAKE_USER_NM in", values, "JIAN_MAKE_USER_NM");
            return (Criteria) this;
        }

        public Criteria andJIAN_MAKE_USER_NMNotIn(List<String> values) {
            addCriterion("JIAN_MAKE_USER_NM not in", values, "JIAN_MAKE_USER_NM");
            return (Criteria) this;
        }

        public Criteria andJIAN_MAKE_USER_NMBetween(String value1, String value2) {
            addCriterion("JIAN_MAKE_USER_NM between", value1, value2, "JIAN_MAKE_USER_NM");
            return (Criteria) this;
        }

        public Criteria andJIAN_MAKE_USER_NMNotBetween(String value1, String value2) {
            addCriterion("JIAN_MAKE_USER_NM not between", value1, value2, "JIAN_MAKE_USER_NM");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_END_USER_IDIsNull() {
            addCriterion("LN_JIAN_END_USER_ID is null");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_END_USER_IDIsNotNull() {
            addCriterion("LN_JIAN_END_USER_ID is not null");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_END_USER_IDEqualTo(String value) {
            addCriterion("LN_JIAN_END_USER_ID =", value, "LN_JIAN_END_USER_ID");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_END_USER_IDNotEqualTo(String value) {
            addCriterion("LN_JIAN_END_USER_ID <>", value, "LN_JIAN_END_USER_ID");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_END_USER_IDGreaterThan(String value) {
            addCriterion("LN_JIAN_END_USER_ID >", value, "LN_JIAN_END_USER_ID");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_END_USER_IDGreaterThanOrEqualTo(String value) {
            addCriterion("LN_JIAN_END_USER_ID >=", value, "LN_JIAN_END_USER_ID");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_END_USER_IDLessThan(String value) {
            addCriterion("LN_JIAN_END_USER_ID <", value, "LN_JIAN_END_USER_ID");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_END_USER_IDLessThanOrEqualTo(String value) {
            addCriterion("LN_JIAN_END_USER_ID <=", value, "LN_JIAN_END_USER_ID");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_END_USER_IDLike(String value) {
            addCriterion("LN_JIAN_END_USER_ID like", value, "LN_JIAN_END_USER_ID");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_END_USER_IDNotLike(String value) {
            addCriterion("LN_JIAN_END_USER_ID not like", value, "LN_JIAN_END_USER_ID");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_END_USER_IDIn(List<String> values) {
            addCriterion("LN_JIAN_END_USER_ID in", values, "LN_JIAN_END_USER_ID");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_END_USER_IDNotIn(List<String> values) {
            addCriterion("LN_JIAN_END_USER_ID not in", values, "LN_JIAN_END_USER_ID");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_END_USER_IDBetween(String value1, String value2) {
            addCriterion("LN_JIAN_END_USER_ID between", value1, value2, "LN_JIAN_END_USER_ID");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_END_USER_IDNotBetween(String value1, String value2) {
            addCriterion("LN_JIAN_END_USER_ID not between", value1, value2, "LN_JIAN_END_USER_ID");
            return (Criteria) this;
        }

        public Criteria andJIAN_END_USER_NMIsNull() {
            addCriterion("JIAN_END_USER_NM is null");
            return (Criteria) this;
        }

        public Criteria andJIAN_END_USER_NMIsNotNull() {
            addCriterion("JIAN_END_USER_NM is not null");
            return (Criteria) this;
        }

        public Criteria andJIAN_END_USER_NMEqualTo(String value) {
            addCriterion("JIAN_END_USER_NM =", value, "JIAN_END_USER_NM");
            return (Criteria) this;
        }

        public Criteria andJIAN_END_USER_NMNotEqualTo(String value) {
            addCriterion("JIAN_END_USER_NM <>", value, "JIAN_END_USER_NM");
            return (Criteria) this;
        }

        public Criteria andJIAN_END_USER_NMGreaterThan(String value) {
            addCriterion("JIAN_END_USER_NM >", value, "JIAN_END_USER_NM");
            return (Criteria) this;
        }

        public Criteria andJIAN_END_USER_NMGreaterThanOrEqualTo(String value) {
            addCriterion("JIAN_END_USER_NM >=", value, "JIAN_END_USER_NM");
            return (Criteria) this;
        }

        public Criteria andJIAN_END_USER_NMLessThan(String value) {
            addCriterion("JIAN_END_USER_NM <", value, "JIAN_END_USER_NM");
            return (Criteria) this;
        }

        public Criteria andJIAN_END_USER_NMLessThanOrEqualTo(String value) {
            addCriterion("JIAN_END_USER_NM <=", value, "JIAN_END_USER_NM");
            return (Criteria) this;
        }

        public Criteria andJIAN_END_USER_NMLike(String value) {
            addCriterion("JIAN_END_USER_NM like", value, "JIAN_END_USER_NM");
            return (Criteria) this;
        }

        public Criteria andJIAN_END_USER_NMNotLike(String value) {
            addCriterion("JIAN_END_USER_NM not like", value, "JIAN_END_USER_NM");
            return (Criteria) this;
        }

        public Criteria andJIAN_END_USER_NMIn(List<String> values) {
            addCriterion("JIAN_END_USER_NM in", values, "JIAN_END_USER_NM");
            return (Criteria) this;
        }

        public Criteria andJIAN_END_USER_NMNotIn(List<String> values) {
            addCriterion("JIAN_END_USER_NM not in", values, "JIAN_END_USER_NM");
            return (Criteria) this;
        }

        public Criteria andJIAN_END_USER_NMBetween(String value1, String value2) {
            addCriterion("JIAN_END_USER_NM between", value1, value2, "JIAN_END_USER_NM");
            return (Criteria) this;
        }

        public Criteria andJIAN_END_USER_NMNotBetween(String value1, String value2) {
            addCriterion("JIAN_END_USER_NM not between", value1, value2, "JIAN_END_USER_NM");
            return (Criteria) this;
        }

        public Criteria andLN_TOROKU_KIND_NUMIsNull() {
            addCriterion("LN_TOROKU_KIND_NUM is null");
            return (Criteria) this;
        }

        public Criteria andLN_TOROKU_KIND_NUMIsNotNull() {
            addCriterion("LN_TOROKU_KIND_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andLN_TOROKU_KIND_NUMEqualTo(String value) {
            addCriterion("LN_TOROKU_KIND_NUM =", value, "LN_TOROKU_KIND_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_TOROKU_KIND_NUMNotEqualTo(String value) {
            addCriterion("LN_TOROKU_KIND_NUM <>", value, "LN_TOROKU_KIND_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_TOROKU_KIND_NUMGreaterThan(String value) {
            addCriterion("LN_TOROKU_KIND_NUM >", value, "LN_TOROKU_KIND_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_TOROKU_KIND_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("LN_TOROKU_KIND_NUM >=", value, "LN_TOROKU_KIND_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_TOROKU_KIND_NUMLessThan(String value) {
            addCriterion("LN_TOROKU_KIND_NUM <", value, "LN_TOROKU_KIND_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_TOROKU_KIND_NUMLessThanOrEqualTo(String value) {
            addCriterion("LN_TOROKU_KIND_NUM <=", value, "LN_TOROKU_KIND_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_TOROKU_KIND_NUMLike(String value) {
            addCriterion("LN_TOROKU_KIND_NUM like", value, "LN_TOROKU_KIND_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_TOROKU_KIND_NUMNotLike(String value) {
            addCriterion("LN_TOROKU_KIND_NUM not like", value, "LN_TOROKU_KIND_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_TOROKU_KIND_NUMIn(List<String> values) {
            addCriterion("LN_TOROKU_KIND_NUM in", values, "LN_TOROKU_KIND_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_TOROKU_KIND_NUMNotIn(List<String> values) {
            addCriterion("LN_TOROKU_KIND_NUM not in", values, "LN_TOROKU_KIND_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_TOROKU_KIND_NUMBetween(String value1, String value2) {
            addCriterion("LN_TOROKU_KIND_NUM between", value1, value2, "LN_TOROKU_KIND_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_TOROKU_KIND_NUMNotBetween(String value1, String value2) {
            addCriterion("LN_TOROKU_KIND_NUM not between", value1, value2, "LN_TOROKU_KIND_NUM");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KIND_CDIsNull() {
            addCriterion("TOROKU_KIND_CD is null");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KIND_CDIsNotNull() {
            addCriterion("TOROKU_KIND_CD is not null");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KIND_CDEqualTo(String value) {
            addCriterion("TOROKU_KIND_CD =", value, "TOROKU_KIND_CD");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KIND_CDNotEqualTo(String value) {
            addCriterion("TOROKU_KIND_CD <>", value, "TOROKU_KIND_CD");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KIND_CDGreaterThan(String value) {
            addCriterion("TOROKU_KIND_CD >", value, "TOROKU_KIND_CD");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KIND_CDGreaterThanOrEqualTo(String value) {
            addCriterion("TOROKU_KIND_CD >=", value, "TOROKU_KIND_CD");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KIND_CDLessThan(String value) {
            addCriterion("TOROKU_KIND_CD <", value, "TOROKU_KIND_CD");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KIND_CDLessThanOrEqualTo(String value) {
            addCriterion("TOROKU_KIND_CD <=", value, "TOROKU_KIND_CD");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KIND_CDLike(String value) {
            addCriterion("TOROKU_KIND_CD like", value, "TOROKU_KIND_CD");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KIND_CDNotLike(String value) {
            addCriterion("TOROKU_KIND_CD not like", value, "TOROKU_KIND_CD");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KIND_CDIn(List<String> values) {
            addCriterion("TOROKU_KIND_CD in", values, "TOROKU_KIND_CD");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KIND_CDNotIn(List<String> values) {
            addCriterion("TOROKU_KIND_CD not in", values, "TOROKU_KIND_CD");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KIND_CDBetween(String value1, String value2) {
            addCriterion("TOROKU_KIND_CD between", value1, value2, "TOROKU_KIND_CD");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KIND_CDNotBetween(String value1, String value2) {
            addCriterion("TOROKU_KIND_CD not between", value1, value2, "TOROKU_KIND_CD");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KINDIsNull() {
            addCriterion("TOROKU_KIND is null");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KINDIsNotNull() {
            addCriterion("TOROKU_KIND is not null");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KINDEqualTo(String value) {
            addCriterion("TOROKU_KIND =", value, "TOROKU_KIND");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KINDNotEqualTo(String value) {
            addCriterion("TOROKU_KIND <>", value, "TOROKU_KIND");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KINDGreaterThan(String value) {
            addCriterion("TOROKU_KIND >", value, "TOROKU_KIND");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KINDGreaterThanOrEqualTo(String value) {
            addCriterion("TOROKU_KIND >=", value, "TOROKU_KIND");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KINDLessThan(String value) {
            addCriterion("TOROKU_KIND <", value, "TOROKU_KIND");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KINDLessThanOrEqualTo(String value) {
            addCriterion("TOROKU_KIND <=", value, "TOROKU_KIND");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KINDLike(String value) {
            addCriterion("TOROKU_KIND like", value, "TOROKU_KIND");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KINDNotLike(String value) {
            addCriterion("TOROKU_KIND not like", value, "TOROKU_KIND");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KINDIn(List<String> values) {
            addCriterion("TOROKU_KIND in", values, "TOROKU_KIND");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KINDNotIn(List<String> values) {
            addCriterion("TOROKU_KIND not in", values, "TOROKU_KIND");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KINDBetween(String value1, String value2) {
            addCriterion("TOROKU_KIND between", value1, value2, "TOROKU_KIND");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KINDNotBetween(String value1, String value2) {
            addCriterion("TOROKU_KIND not between", value1, value2, "TOROKU_KIND");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSIsNull() {
            addCriterion("HASSEI_TS is null");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSIsNotNull() {
            addCriterion("HASSEI_TS is not null");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSEqualTo(Date value) {
            addCriterion("HASSEI_TS =", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSNotEqualTo(Date value) {
            addCriterion("HASSEI_TS <>", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSGreaterThan(Date value) {
            addCriterion("HASSEI_TS >", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("HASSEI_TS >=", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSLessThan(Date value) {
            addCriterion("HASSEI_TS <", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSLessThanOrEqualTo(Date value) {
            addCriterion("HASSEI_TS <=", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSIn(List<Date> values) {
            addCriterion("HASSEI_TS in", values, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSNotIn(List<Date> values) {
            addCriterion("HASSEI_TS not in", values, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSBetween(Date value1, Date value2) {
            addCriterion("HASSEI_TS between", value1, value2, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSNotBetween(Date value1, Date value2) {
            addCriterion("HASSEI_TS not between", value1, value2, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andGENIN_TSIsNull() {
            addCriterion("GENIN_TS is null");
            return (Criteria) this;
        }

        public Criteria andGENIN_TSIsNotNull() {
            addCriterion("GENIN_TS is not null");
            return (Criteria) this;
        }

        public Criteria andGENIN_TSEqualTo(Date value) {
            addCriterion("GENIN_TS =", value, "GENIN_TS");
            return (Criteria) this;
        }

        public Criteria andGENIN_TSNotEqualTo(Date value) {
            addCriterion("GENIN_TS <>", value, "GENIN_TS");
            return (Criteria) this;
        }

        public Criteria andGENIN_TSGreaterThan(Date value) {
            addCriterion("GENIN_TS >", value, "GENIN_TS");
            return (Criteria) this;
        }

        public Criteria andGENIN_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("GENIN_TS >=", value, "GENIN_TS");
            return (Criteria) this;
        }

        public Criteria andGENIN_TSLessThan(Date value) {
            addCriterion("GENIN_TS <", value, "GENIN_TS");
            return (Criteria) this;
        }

        public Criteria andGENIN_TSLessThanOrEqualTo(Date value) {
            addCriterion("GENIN_TS <=", value, "GENIN_TS");
            return (Criteria) this;
        }

        public Criteria andGENIN_TSIn(List<Date> values) {
            addCriterion("GENIN_TS in", values, "GENIN_TS");
            return (Criteria) this;
        }

        public Criteria andGENIN_TSNotIn(List<Date> values) {
            addCriterion("GENIN_TS not in", values, "GENIN_TS");
            return (Criteria) this;
        }

        public Criteria andGENIN_TSBetween(Date value1, Date value2) {
            addCriterion("GENIN_TS between", value1, value2, "GENIN_TS");
            return (Criteria) this;
        }

        public Criteria andGENIN_TSNotBetween(Date value1, Date value2) {
            addCriterion("GENIN_TS not between", value1, value2, "GENIN_TS");
            return (Criteria) this;
        }

        public Criteria andEND_TSIsNull() {
            addCriterion("END_TS is null");
            return (Criteria) this;
        }

        public Criteria andEND_TSIsNotNull() {
            addCriterion("END_TS is not null");
            return (Criteria) this;
        }

        public Criteria andEND_TSEqualTo(Date value) {
            addCriterion("END_TS =", value, "END_TS");
            return (Criteria) this;
        }

        public Criteria andEND_TSNotEqualTo(Date value) {
            addCriterion("END_TS <>", value, "END_TS");
            return (Criteria) this;
        }

        public Criteria andEND_TSGreaterThan(Date value) {
            addCriterion("END_TS >", value, "END_TS");
            return (Criteria) this;
        }

        public Criteria andEND_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("END_TS >=", value, "END_TS");
            return (Criteria) this;
        }

        public Criteria andEND_TSLessThan(Date value) {
            addCriterion("END_TS <", value, "END_TS");
            return (Criteria) this;
        }

        public Criteria andEND_TSLessThanOrEqualTo(Date value) {
            addCriterion("END_TS <=", value, "END_TS");
            return (Criteria) this;
        }

        public Criteria andEND_TSIn(List<Date> values) {
            addCriterion("END_TS in", values, "END_TS");
            return (Criteria) this;
        }

        public Criteria andEND_TSNotIn(List<Date> values) {
            addCriterion("END_TS not in", values, "END_TS");
            return (Criteria) this;
        }

        public Criteria andEND_TSBetween(Date value1, Date value2) {
            addCriterion("END_TS between", value1, value2, "END_TS");
            return (Criteria) this;
        }

        public Criteria andEND_TSNotBetween(Date value1, Date value2) {
            addCriterion("END_TS not between", value1, value2, "END_TS");
            return (Criteria) this;
        }

        public Criteria andLN_GENINIsNull() {
            addCriterion("LN_GENIN is null");
            return (Criteria) this;
        }

        public Criteria andLN_GENINIsNotNull() {
            addCriterion("LN_GENIN is not null");
            return (Criteria) this;
        }

        public Criteria andLN_GENINEqualTo(String value) {
            addCriterion("LN_GENIN =", value, "LN_GENIN");
            return (Criteria) this;
        }

        public Criteria andLN_GENINNotEqualTo(String value) {
            addCriterion("LN_GENIN <>", value, "LN_GENIN");
            return (Criteria) this;
        }

        public Criteria andLN_GENINGreaterThan(String value) {
            addCriterion("LN_GENIN >", value, "LN_GENIN");
            return (Criteria) this;
        }

        public Criteria andLN_GENINGreaterThanOrEqualTo(String value) {
            addCriterion("LN_GENIN >=", value, "LN_GENIN");
            return (Criteria) this;
        }

        public Criteria andLN_GENINLessThan(String value) {
            addCriterion("LN_GENIN <", value, "LN_GENIN");
            return (Criteria) this;
        }

        public Criteria andLN_GENINLessThanOrEqualTo(String value) {
            addCriterion("LN_GENIN <=", value, "LN_GENIN");
            return (Criteria) this;
        }

        public Criteria andLN_GENINLike(String value) {
            addCriterion("LN_GENIN like", value, "LN_GENIN");
            return (Criteria) this;
        }

        public Criteria andLN_GENINNotLike(String value) {
            addCriterion("LN_GENIN not like", value, "LN_GENIN");
            return (Criteria) this;
        }

        public Criteria andLN_GENINIn(List<String> values) {
            addCriterion("LN_GENIN in", values, "LN_GENIN");
            return (Criteria) this;
        }

        public Criteria andLN_GENINNotIn(List<String> values) {
            addCriterion("LN_GENIN not in", values, "LN_GENIN");
            return (Criteria) this;
        }

        public Criteria andLN_GENINBetween(String value1, String value2) {
            addCriterion("LN_GENIN between", value1, value2, "LN_GENIN");
            return (Criteria) this;
        }

        public Criteria andLN_GENINNotBetween(String value1, String value2) {
            addCriterion("LN_GENIN not between", value1, value2, "LN_GENIN");
            return (Criteria) this;
        }

        public Criteria andKEIBI_GENIN_NAIYOUIsNull() {
            addCriterion("KEIBI_GENIN_NAIYOU is null");
            return (Criteria) this;
        }

        public Criteria andKEIBI_GENIN_NAIYOUIsNotNull() {
            addCriterion("KEIBI_GENIN_NAIYOU is not null");
            return (Criteria) this;
        }

        public Criteria andKEIBI_GENIN_NAIYOUEqualTo(String value) {
            addCriterion("KEIBI_GENIN_NAIYOU =", value, "KEIBI_GENIN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andKEIBI_GENIN_NAIYOUNotEqualTo(String value) {
            addCriterion("KEIBI_GENIN_NAIYOU <>", value, "KEIBI_GENIN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andKEIBI_GENIN_NAIYOUGreaterThan(String value) {
            addCriterion("KEIBI_GENIN_NAIYOU >", value, "KEIBI_GENIN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andKEIBI_GENIN_NAIYOUGreaterThanOrEqualTo(String value) {
            addCriterion("KEIBI_GENIN_NAIYOU >=", value, "KEIBI_GENIN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andKEIBI_GENIN_NAIYOULessThan(String value) {
            addCriterion("KEIBI_GENIN_NAIYOU <", value, "KEIBI_GENIN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andKEIBI_GENIN_NAIYOULessThanOrEqualTo(String value) {
            addCriterion("KEIBI_GENIN_NAIYOU <=", value, "KEIBI_GENIN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andKEIBI_GENIN_NAIYOULike(String value) {
            addCriterion("KEIBI_GENIN_NAIYOU like", value, "KEIBI_GENIN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andKEIBI_GENIN_NAIYOUNotLike(String value) {
            addCriterion("KEIBI_GENIN_NAIYOU not like", value, "KEIBI_GENIN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andKEIBI_GENIN_NAIYOUIn(List<String> values) {
            addCriterion("KEIBI_GENIN_NAIYOU in", values, "KEIBI_GENIN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andKEIBI_GENIN_NAIYOUNotIn(List<String> values) {
            addCriterion("KEIBI_GENIN_NAIYOU not in", values, "KEIBI_GENIN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andKEIBI_GENIN_NAIYOUBetween(String value1, String value2) {
            addCriterion("KEIBI_GENIN_NAIYOU between", value1, value2, "KEIBI_GENIN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andKEIBI_GENIN_NAIYOUNotBetween(String value1, String value2) {
            addCriterion("KEIBI_GENIN_NAIYOU not between", value1, value2, "KEIBI_GENIN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andFIRST_JIAN_HYOUJI_DEV_KINDIsNull() {
            addCriterion("FIRST_JIAN_HYOUJI_DEV_KIND is null");
            return (Criteria) this;
        }

        public Criteria andFIRST_JIAN_HYOUJI_DEV_KINDIsNotNull() {
            addCriterion("FIRST_JIAN_HYOUJI_DEV_KIND is not null");
            return (Criteria) this;
        }

        public Criteria andFIRST_JIAN_HYOUJI_DEV_KINDEqualTo(String value) {
            addCriterion("FIRST_JIAN_HYOUJI_DEV_KIND =", value, "FIRST_JIAN_HYOUJI_DEV_KIND");
            return (Criteria) this;
        }

        public Criteria andFIRST_JIAN_HYOUJI_DEV_KINDNotEqualTo(String value) {
            addCriterion("FIRST_JIAN_HYOUJI_DEV_KIND <>", value, "FIRST_JIAN_HYOUJI_DEV_KIND");
            return (Criteria) this;
        }

        public Criteria andFIRST_JIAN_HYOUJI_DEV_KINDGreaterThan(String value) {
            addCriterion("FIRST_JIAN_HYOUJI_DEV_KIND >", value, "FIRST_JIAN_HYOUJI_DEV_KIND");
            return (Criteria) this;
        }

        public Criteria andFIRST_JIAN_HYOUJI_DEV_KINDGreaterThanOrEqualTo(String value) {
            addCriterion("FIRST_JIAN_HYOUJI_DEV_KIND >=", value, "FIRST_JIAN_HYOUJI_DEV_KIND");
            return (Criteria) this;
        }

        public Criteria andFIRST_JIAN_HYOUJI_DEV_KINDLessThan(String value) {
            addCriterion("FIRST_JIAN_HYOUJI_DEV_KIND <", value, "FIRST_JIAN_HYOUJI_DEV_KIND");
            return (Criteria) this;
        }

        public Criteria andFIRST_JIAN_HYOUJI_DEV_KINDLessThanOrEqualTo(String value) {
            addCriterion("FIRST_JIAN_HYOUJI_DEV_KIND <=", value, "FIRST_JIAN_HYOUJI_DEV_KIND");
            return (Criteria) this;
        }

        public Criteria andFIRST_JIAN_HYOUJI_DEV_KINDLike(String value) {
            addCriterion("FIRST_JIAN_HYOUJI_DEV_KIND like", value, "FIRST_JIAN_HYOUJI_DEV_KIND");
            return (Criteria) this;
        }

        public Criteria andFIRST_JIAN_HYOUJI_DEV_KINDNotLike(String value) {
            addCriterion("FIRST_JIAN_HYOUJI_DEV_KIND not like", value, "FIRST_JIAN_HYOUJI_DEV_KIND");
            return (Criteria) this;
        }

        public Criteria andFIRST_JIAN_HYOUJI_DEV_KINDIn(List<String> values) {
            addCriterion("FIRST_JIAN_HYOUJI_DEV_KIND in", values, "FIRST_JIAN_HYOUJI_DEV_KIND");
            return (Criteria) this;
        }

        public Criteria andFIRST_JIAN_HYOUJI_DEV_KINDNotIn(List<String> values) {
            addCriterion("FIRST_JIAN_HYOUJI_DEV_KIND not in", values, "FIRST_JIAN_HYOUJI_DEV_KIND");
            return (Criteria) this;
        }

        public Criteria andFIRST_JIAN_HYOUJI_DEV_KINDBetween(String value1, String value2) {
            addCriterion("FIRST_JIAN_HYOUJI_DEV_KIND between", value1, value2, "FIRST_JIAN_HYOUJI_DEV_KIND");
            return (Criteria) this;
        }

        public Criteria andFIRST_JIAN_HYOUJI_DEV_KINDNotBetween(String value1, String value2) {
            addCriterion("FIRST_JIAN_HYOUJI_DEV_KIND not between", value1, value2, "FIRST_JIAN_HYOUJI_DEV_KIND");
            return (Criteria) this;
        }

        public Criteria andJIAN_OPE_AUTH_DEV_KINDIsNull() {
            addCriterion("JIAN_OPE_AUTH_DEV_KIND is null");
            return (Criteria) this;
        }

        public Criteria andJIAN_OPE_AUTH_DEV_KINDIsNotNull() {
            addCriterion("JIAN_OPE_AUTH_DEV_KIND is not null");
            return (Criteria) this;
        }

        public Criteria andJIAN_OPE_AUTH_DEV_KINDEqualTo(String value) {
            addCriterion("JIAN_OPE_AUTH_DEV_KIND =", value, "JIAN_OPE_AUTH_DEV_KIND");
            return (Criteria) this;
        }

        public Criteria andJIAN_OPE_AUTH_DEV_KINDNotEqualTo(String value) {
            addCriterion("JIAN_OPE_AUTH_DEV_KIND <>", value, "JIAN_OPE_AUTH_DEV_KIND");
            return (Criteria) this;
        }

        public Criteria andJIAN_OPE_AUTH_DEV_KINDGreaterThan(String value) {
            addCriterion("JIAN_OPE_AUTH_DEV_KIND >", value, "JIAN_OPE_AUTH_DEV_KIND");
            return (Criteria) this;
        }

        public Criteria andJIAN_OPE_AUTH_DEV_KINDGreaterThanOrEqualTo(String value) {
            addCriterion("JIAN_OPE_AUTH_DEV_KIND >=", value, "JIAN_OPE_AUTH_DEV_KIND");
            return (Criteria) this;
        }

        public Criteria andJIAN_OPE_AUTH_DEV_KINDLessThan(String value) {
            addCriterion("JIAN_OPE_AUTH_DEV_KIND <", value, "JIAN_OPE_AUTH_DEV_KIND");
            return (Criteria) this;
        }

        public Criteria andJIAN_OPE_AUTH_DEV_KINDLessThanOrEqualTo(String value) {
            addCriterion("JIAN_OPE_AUTH_DEV_KIND <=", value, "JIAN_OPE_AUTH_DEV_KIND");
            return (Criteria) this;
        }

        public Criteria andJIAN_OPE_AUTH_DEV_KINDLike(String value) {
            addCriterion("JIAN_OPE_AUTH_DEV_KIND like", value, "JIAN_OPE_AUTH_DEV_KIND");
            return (Criteria) this;
        }

        public Criteria andJIAN_OPE_AUTH_DEV_KINDNotLike(String value) {
            addCriterion("JIAN_OPE_AUTH_DEV_KIND not like", value, "JIAN_OPE_AUTH_DEV_KIND");
            return (Criteria) this;
        }

        public Criteria andJIAN_OPE_AUTH_DEV_KINDIn(List<String> values) {
            addCriterion("JIAN_OPE_AUTH_DEV_KIND in", values, "JIAN_OPE_AUTH_DEV_KIND");
            return (Criteria) this;
        }

        public Criteria andJIAN_OPE_AUTH_DEV_KINDNotIn(List<String> values) {
            addCriterion("JIAN_OPE_AUTH_DEV_KIND not in", values, "JIAN_OPE_AUTH_DEV_KIND");
            return (Criteria) this;
        }

        public Criteria andJIAN_OPE_AUTH_DEV_KINDBetween(String value1, String value2) {
            addCriterion("JIAN_OPE_AUTH_DEV_KIND between", value1, value2, "JIAN_OPE_AUTH_DEV_KIND");
            return (Criteria) this;
        }

        public Criteria andJIAN_OPE_AUTH_DEV_KINDNotBetween(String value1, String value2) {
            addCriterion("JIAN_OPE_AUTH_DEV_KIND not between", value1, value2, "JIAN_OPE_AUTH_DEV_KIND");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_SSIsNull() {
            addCriterion("LIMIT_EXT_SS is null");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_SSIsNotNull() {
            addCriterion("LIMIT_EXT_SS is not null");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_SSEqualTo(String value) {
            addCriterion("LIMIT_EXT_SS =", value, "LIMIT_EXT_SS");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_SSNotEqualTo(String value) {
            addCriterion("LIMIT_EXT_SS <>", value, "LIMIT_EXT_SS");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_SSGreaterThan(String value) {
            addCriterion("LIMIT_EXT_SS >", value, "LIMIT_EXT_SS");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_SSGreaterThanOrEqualTo(String value) {
            addCriterion("LIMIT_EXT_SS >=", value, "LIMIT_EXT_SS");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_SSLessThan(String value) {
            addCriterion("LIMIT_EXT_SS <", value, "LIMIT_EXT_SS");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_SSLessThanOrEqualTo(String value) {
            addCriterion("LIMIT_EXT_SS <=", value, "LIMIT_EXT_SS");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_SSLike(String value) {
            addCriterion("LIMIT_EXT_SS like", value, "LIMIT_EXT_SS");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_SSNotLike(String value) {
            addCriterion("LIMIT_EXT_SS not like", value, "LIMIT_EXT_SS");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_SSIn(List<String> values) {
            addCriterion("LIMIT_EXT_SS in", values, "LIMIT_EXT_SS");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_SSNotIn(List<String> values) {
            addCriterion("LIMIT_EXT_SS not in", values, "LIMIT_EXT_SS");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_SSBetween(String value1, String value2) {
            addCriterion("LIMIT_EXT_SS between", value1, value2, "LIMIT_EXT_SS");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_SSNotBetween(String value1, String value2) {
            addCriterion("LIMIT_EXT_SS not between", value1, value2, "LIMIT_EXT_SS");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_MAX_SSIsNull() {
            addCriterion("LIMIT_EXT_MAX_SS is null");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_MAX_SSIsNotNull() {
            addCriterion("LIMIT_EXT_MAX_SS is not null");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_MAX_SSEqualTo(String value) {
            addCriterion("LIMIT_EXT_MAX_SS =", value, "LIMIT_EXT_MAX_SS");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_MAX_SSNotEqualTo(String value) {
            addCriterion("LIMIT_EXT_MAX_SS <>", value, "LIMIT_EXT_MAX_SS");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_MAX_SSGreaterThan(String value) {
            addCriterion("LIMIT_EXT_MAX_SS >", value, "LIMIT_EXT_MAX_SS");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_MAX_SSGreaterThanOrEqualTo(String value) {
            addCriterion("LIMIT_EXT_MAX_SS >=", value, "LIMIT_EXT_MAX_SS");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_MAX_SSLessThan(String value) {
            addCriterion("LIMIT_EXT_MAX_SS <", value, "LIMIT_EXT_MAX_SS");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_MAX_SSLessThanOrEqualTo(String value) {
            addCriterion("LIMIT_EXT_MAX_SS <=", value, "LIMIT_EXT_MAX_SS");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_MAX_SSLike(String value) {
            addCriterion("LIMIT_EXT_MAX_SS like", value, "LIMIT_EXT_MAX_SS");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_MAX_SSNotLike(String value) {
            addCriterion("LIMIT_EXT_MAX_SS not like", value, "LIMIT_EXT_MAX_SS");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_MAX_SSIn(List<String> values) {
            addCriterion("LIMIT_EXT_MAX_SS in", values, "LIMIT_EXT_MAX_SS");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_MAX_SSNotIn(List<String> values) {
            addCriterion("LIMIT_EXT_MAX_SS not in", values, "LIMIT_EXT_MAX_SS");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_MAX_SSBetween(String value1, String value2) {
            addCriterion("LIMIT_EXT_MAX_SS between", value1, value2, "LIMIT_EXT_MAX_SS");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_MAX_SSNotBetween(String value1, String value2) {
            addCriterion("LIMIT_EXT_MAX_SS not between", value1, value2, "LIMIT_EXT_MAX_SS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSIsNull() {
            addCriterion("LASTUPD_TS is null");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSIsNotNull() {
            addCriterion("LASTUPD_TS is not null");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSEqualTo(Date value) {
            addCriterion("LASTUPD_TS =", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSNotEqualTo(Date value) {
            addCriterion("LASTUPD_TS <>", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSGreaterThan(Date value) {
            addCriterion("LASTUPD_TS >", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("LASTUPD_TS >=", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSLessThan(Date value) {
            addCriterion("LASTUPD_TS <", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSLessThanOrEqualTo(Date value) {
            addCriterion("LASTUPD_TS <=", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSIn(List<Date> values) {
            addCriterion("LASTUPD_TS in", values, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSNotIn(List<Date> values) {
            addCriterion("LASTUPD_TS not in", values, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSBetween(Date value1, Date value2) {
            addCriterion("LASTUPD_TS between", value1, value2, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSNotBetween(Date value1, Date value2) {
            addCriterion("LASTUPD_TS not between", value1, value2, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andSINPO_JISSI_FLGIsNull() {
            addCriterion("SINPO_JISSI_FLG is null");
            return (Criteria) this;
        }

        public Criteria andSINPO_JISSI_FLGIsNotNull() {
            addCriterion("SINPO_JISSI_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andSINPO_JISSI_FLGEqualTo(String value) {
            addCriterion("SINPO_JISSI_FLG =", value, "SINPO_JISSI_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_JISSI_FLGNotEqualTo(String value) {
            addCriterion("SINPO_JISSI_FLG <>", value, "SINPO_JISSI_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_JISSI_FLGGreaterThan(String value) {
            addCriterion("SINPO_JISSI_FLG >", value, "SINPO_JISSI_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_JISSI_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("SINPO_JISSI_FLG >=", value, "SINPO_JISSI_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_JISSI_FLGLessThan(String value) {
            addCriterion("SINPO_JISSI_FLG <", value, "SINPO_JISSI_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_JISSI_FLGLessThanOrEqualTo(String value) {
            addCriterion("SINPO_JISSI_FLG <=", value, "SINPO_JISSI_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_JISSI_FLGLike(String value) {
            addCriterion("SINPO_JISSI_FLG like", value, "SINPO_JISSI_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_JISSI_FLGNotLike(String value) {
            addCriterion("SINPO_JISSI_FLG not like", value, "SINPO_JISSI_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_JISSI_FLGIn(List<String> values) {
            addCriterion("SINPO_JISSI_FLG in", values, "SINPO_JISSI_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_JISSI_FLGNotIn(List<String> values) {
            addCriterion("SINPO_JISSI_FLG not in", values, "SINPO_JISSI_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_JISSI_FLGBetween(String value1, String value2) {
            addCriterion("SINPO_JISSI_FLG between", value1, value2, "SINPO_JISSI_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_JISSI_FLGNotBetween(String value1, String value2) {
            addCriterion("SINPO_JISSI_FLG not between", value1, value2, "SINPO_JISSI_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_FUKKYU_FLGIsNull() {
            addCriterion("JIAN_FUKKYU_FLG is null");
            return (Criteria) this;
        }

        public Criteria andJIAN_FUKKYU_FLGIsNotNull() {
            addCriterion("JIAN_FUKKYU_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andJIAN_FUKKYU_FLGEqualTo(String value) {
            addCriterion("JIAN_FUKKYU_FLG =", value, "JIAN_FUKKYU_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_FUKKYU_FLGNotEqualTo(String value) {
            addCriterion("JIAN_FUKKYU_FLG <>", value, "JIAN_FUKKYU_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_FUKKYU_FLGGreaterThan(String value) {
            addCriterion("JIAN_FUKKYU_FLG >", value, "JIAN_FUKKYU_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_FUKKYU_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("JIAN_FUKKYU_FLG >=", value, "JIAN_FUKKYU_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_FUKKYU_FLGLessThan(String value) {
            addCriterion("JIAN_FUKKYU_FLG <", value, "JIAN_FUKKYU_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_FUKKYU_FLGLessThanOrEqualTo(String value) {
            addCriterion("JIAN_FUKKYU_FLG <=", value, "JIAN_FUKKYU_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_FUKKYU_FLGLike(String value) {
            addCriterion("JIAN_FUKKYU_FLG like", value, "JIAN_FUKKYU_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_FUKKYU_FLGNotLike(String value) {
            addCriterion("JIAN_FUKKYU_FLG not like", value, "JIAN_FUKKYU_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_FUKKYU_FLGIn(List<String> values) {
            addCriterion("JIAN_FUKKYU_FLG in", values, "JIAN_FUKKYU_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_FUKKYU_FLGNotIn(List<String> values) {
            addCriterion("JIAN_FUKKYU_FLG not in", values, "JIAN_FUKKYU_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_FUKKYU_FLGBetween(String value1, String value2) {
            addCriterion("JIAN_FUKKYU_FLG between", value1, value2, "JIAN_FUKKYU_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_FUKKYU_FLGNotBetween(String value1, String value2) {
            addCriterion("JIAN_FUKKYU_FLG not between", value1, value2, "JIAN_FUKKYU_FLG");
            return (Criteria) this;
        }

        public Criteria andGENIN_IDIsNull() {
            addCriterion("GENIN_ID is null");
            return (Criteria) this;
        }

        public Criteria andGENIN_IDIsNotNull() {
            addCriterion("GENIN_ID is not null");
            return (Criteria) this;
        }

        public Criteria andGENIN_IDEqualTo(String value) {
            addCriterion("GENIN_ID =", value, "GENIN_ID");
            return (Criteria) this;
        }

        public Criteria andGENIN_IDNotEqualTo(String value) {
            addCriterion("GENIN_ID <>", value, "GENIN_ID");
            return (Criteria) this;
        }

        public Criteria andGENIN_IDGreaterThan(String value) {
            addCriterion("GENIN_ID >", value, "GENIN_ID");
            return (Criteria) this;
        }

        public Criteria andGENIN_IDGreaterThanOrEqualTo(String value) {
            addCriterion("GENIN_ID >=", value, "GENIN_ID");
            return (Criteria) this;
        }

        public Criteria andGENIN_IDLessThan(String value) {
            addCriterion("GENIN_ID <", value, "GENIN_ID");
            return (Criteria) this;
        }

        public Criteria andGENIN_IDLessThanOrEqualTo(String value) {
            addCriterion("GENIN_ID <=", value, "GENIN_ID");
            return (Criteria) this;
        }

        public Criteria andGENIN_IDLike(String value) {
            addCriterion("GENIN_ID like", value, "GENIN_ID");
            return (Criteria) this;
        }

        public Criteria andGENIN_IDNotLike(String value) {
            addCriterion("GENIN_ID not like", value, "GENIN_ID");
            return (Criteria) this;
        }

        public Criteria andGENIN_IDIn(List<String> values) {
            addCriterion("GENIN_ID in", values, "GENIN_ID");
            return (Criteria) this;
        }

        public Criteria andGENIN_IDNotIn(List<String> values) {
            addCriterion("GENIN_ID not in", values, "GENIN_ID");
            return (Criteria) this;
        }

        public Criteria andGENIN_IDBetween(String value1, String value2) {
            addCriterion("GENIN_ID between", value1, value2, "GENIN_ID");
            return (Criteria) this;
        }

        public Criteria andGENIN_IDNotBetween(String value1, String value2) {
            addCriterion("GENIN_ID not between", value1, value2, "GENIN_ID");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGIsNull() {
            addCriterion("SINPO_REASON_FLG is null");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGIsNotNull() {
            addCriterion("SINPO_REASON_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGEqualTo(String value) {
            addCriterion("SINPO_REASON_FLG =", value, "SINPO_REASON_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGNotEqualTo(String value) {
            addCriterion("SINPO_REASON_FLG <>", value, "SINPO_REASON_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGGreaterThan(String value) {
            addCriterion("SINPO_REASON_FLG >", value, "SINPO_REASON_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("SINPO_REASON_FLG >=", value, "SINPO_REASON_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGLessThan(String value) {
            addCriterion("SINPO_REASON_FLG <", value, "SINPO_REASON_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGLessThanOrEqualTo(String value) {
            addCriterion("SINPO_REASON_FLG <=", value, "SINPO_REASON_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGLike(String value) {
            addCriterion("SINPO_REASON_FLG like", value, "SINPO_REASON_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGNotLike(String value) {
            addCriterion("SINPO_REASON_FLG not like", value, "SINPO_REASON_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGIn(List<String> values) {
            addCriterion("SINPO_REASON_FLG in", values, "SINPO_REASON_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGNotIn(List<String> values) {
            addCriterion("SINPO_REASON_FLG not in", values, "SINPO_REASON_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGBetween(String value1, String value2) {
            addCriterion("SINPO_REASON_FLG between", value1, value2, "SINPO_REASON_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGNotBetween(String value1, String value2) {
            addCriterion("SINPO_REASON_FLG not between", value1, value2, "SINPO_REASON_FLG");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_FLGIsNull() {
            addCriterion("RAKUCHAKU_FLG is null");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_FLGIsNotNull() {
            addCriterion("RAKUCHAKU_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_FLGEqualTo(String value) {
            addCriterion("RAKUCHAKU_FLG =", value, "RAKUCHAKU_FLG");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_FLGNotEqualTo(String value) {
            addCriterion("RAKUCHAKU_FLG <>", value, "RAKUCHAKU_FLG");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_FLGGreaterThan(String value) {
            addCriterion("RAKUCHAKU_FLG >", value, "RAKUCHAKU_FLG");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("RAKUCHAKU_FLG >=", value, "RAKUCHAKU_FLG");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_FLGLessThan(String value) {
            addCriterion("RAKUCHAKU_FLG <", value, "RAKUCHAKU_FLG");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_FLGLessThanOrEqualTo(String value) {
            addCriterion("RAKUCHAKU_FLG <=", value, "RAKUCHAKU_FLG");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_FLGLike(String value) {
            addCriterion("RAKUCHAKU_FLG like", value, "RAKUCHAKU_FLG");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_FLGNotLike(String value) {
            addCriterion("RAKUCHAKU_FLG not like", value, "RAKUCHAKU_FLG");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_FLGIn(List<String> values) {
            addCriterion("RAKUCHAKU_FLG in", values, "RAKUCHAKU_FLG");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_FLGNotIn(List<String> values) {
            addCriterion("RAKUCHAKU_FLG not in", values, "RAKUCHAKU_FLG");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_FLGBetween(String value1, String value2) {
            addCriterion("RAKUCHAKU_FLG between", value1, value2, "RAKUCHAKU_FLG");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_FLGNotBetween(String value1, String value2) {
            addCriterion("RAKUCHAKU_FLG not between", value1, value2, "RAKUCHAKU_FLG");
            return (Criteria) this;
        }

        public Criteria andINTP_STSIsNull() {
            addCriterion("INTP_STS is null");
            return (Criteria) this;
        }

        public Criteria andINTP_STSIsNotNull() {
            addCriterion("INTP_STS is not null");
            return (Criteria) this;
        }

        public Criteria andINTP_STSEqualTo(String value) {
            addCriterion("INTP_STS =", value, "INTP_STS");
            return (Criteria) this;
        }

        public Criteria andINTP_STSNotEqualTo(String value) {
            addCriterion("INTP_STS <>", value, "INTP_STS");
            return (Criteria) this;
        }

        public Criteria andINTP_STSGreaterThan(String value) {
            addCriterion("INTP_STS >", value, "INTP_STS");
            return (Criteria) this;
        }

        public Criteria andINTP_STSGreaterThanOrEqualTo(String value) {
            addCriterion("INTP_STS >=", value, "INTP_STS");
            return (Criteria) this;
        }

        public Criteria andINTP_STSLessThan(String value) {
            addCriterion("INTP_STS <", value, "INTP_STS");
            return (Criteria) this;
        }

        public Criteria andINTP_STSLessThanOrEqualTo(String value) {
            addCriterion("INTP_STS <=", value, "INTP_STS");
            return (Criteria) this;
        }

        public Criteria andINTP_STSLike(String value) {
            addCriterion("INTP_STS like", value, "INTP_STS");
            return (Criteria) this;
        }

        public Criteria andINTP_STSNotLike(String value) {
            addCriterion("INTP_STS not like", value, "INTP_STS");
            return (Criteria) this;
        }

        public Criteria andINTP_STSIn(List<String> values) {
            addCriterion("INTP_STS in", values, "INTP_STS");
            return (Criteria) this;
        }

        public Criteria andINTP_STSNotIn(List<String> values) {
            addCriterion("INTP_STS not in", values, "INTP_STS");
            return (Criteria) this;
        }

        public Criteria andINTP_STSBetween(String value1, String value2) {
            addCriterion("INTP_STS between", value1, value2, "INTP_STS");
            return (Criteria) this;
        }

        public Criteria andINTP_STSNotBetween(String value1, String value2) {
            addCriterion("INTP_STS not between", value1, value2, "INTP_STS");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDIsNull() {
            addCriterion("SGS_GENIN_CD is null");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDIsNotNull() {
            addCriterion("SGS_GENIN_CD is not null");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDEqualTo(String value) {
            addCriterion("SGS_GENIN_CD =", value, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDNotEqualTo(String value) {
            addCriterion("SGS_GENIN_CD <>", value, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDGreaterThan(String value) {
            addCriterion("SGS_GENIN_CD >", value, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDGreaterThanOrEqualTo(String value) {
            addCriterion("SGS_GENIN_CD >=", value, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDLessThan(String value) {
            addCriterion("SGS_GENIN_CD <", value, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDLessThanOrEqualTo(String value) {
            addCriterion("SGS_GENIN_CD <=", value, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDLike(String value) {
            addCriterion("SGS_GENIN_CD like", value, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDNotLike(String value) {
            addCriterion("SGS_GENIN_CD not like", value, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDIn(List<String> values) {
            addCriterion("SGS_GENIN_CD in", values, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDNotIn(List<String> values) {
            addCriterion("SGS_GENIN_CD not in", values, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDBetween(String value1, String value2) {
            addCriterion("SGS_GENIN_CD between", value1, value2, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDNotBetween(String value1, String value2) {
            addCriterion("SGS_GENIN_CD not between", value1, value2, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GENIN_CDIsNull() {
            addCriterion("NET_GENIN_CD is null");
            return (Criteria) this;
        }

        public Criteria andNET_GENIN_CDIsNotNull() {
            addCriterion("NET_GENIN_CD is not null");
            return (Criteria) this;
        }

        public Criteria andNET_GENIN_CDEqualTo(String value) {
            addCriterion("NET_GENIN_CD =", value, "NET_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GENIN_CDNotEqualTo(String value) {
            addCriterion("NET_GENIN_CD <>", value, "NET_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GENIN_CDGreaterThan(String value) {
            addCriterion("NET_GENIN_CD >", value, "NET_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GENIN_CDGreaterThanOrEqualTo(String value) {
            addCriterion("NET_GENIN_CD >=", value, "NET_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GENIN_CDLessThan(String value) {
            addCriterion("NET_GENIN_CD <", value, "NET_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GENIN_CDLessThanOrEqualTo(String value) {
            addCriterion("NET_GENIN_CD <=", value, "NET_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GENIN_CDLike(String value) {
            addCriterion("NET_GENIN_CD like", value, "NET_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GENIN_CDNotLike(String value) {
            addCriterion("NET_GENIN_CD not like", value, "NET_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GENIN_CDIn(List<String> values) {
            addCriterion("NET_GENIN_CD in", values, "NET_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GENIN_CDNotIn(List<String> values) {
            addCriterion("NET_GENIN_CD not in", values, "NET_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GENIN_CDBetween(String value1, String value2) {
            addCriterion("NET_GENIN_CD between", value1, value2, "NET_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GENIN_CDNotBetween(String value1, String value2) {
            addCriterion("NET_GENIN_CD not between", value1, value2, "NET_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1IsNull() {
            addCriterion("LN_KB_INF1 is null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1IsNotNull() {
            addCriterion("LN_KB_INF1 is not null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1EqualTo(String value) {
            addCriterion("LN_KB_INF1 =", value, "LN_KB_INF1");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1NotEqualTo(String value) {
            addCriterion("LN_KB_INF1 <>", value, "LN_KB_INF1");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1GreaterThan(String value) {
            addCriterion("LN_KB_INF1 >", value, "LN_KB_INF1");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1GreaterThanOrEqualTo(String value) {
            addCriterion("LN_KB_INF1 >=", value, "LN_KB_INF1");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1LessThan(String value) {
            addCriterion("LN_KB_INF1 <", value, "LN_KB_INF1");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1LessThanOrEqualTo(String value) {
            addCriterion("LN_KB_INF1 <=", value, "LN_KB_INF1");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1Like(String value) {
            addCriterion("LN_KB_INF1 like", value, "LN_KB_INF1");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1NotLike(String value) {
            addCriterion("LN_KB_INF1 not like", value, "LN_KB_INF1");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1In(List<String> values) {
            addCriterion("LN_KB_INF1 in", values, "LN_KB_INF1");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1NotIn(List<String> values) {
            addCriterion("LN_KB_INF1 not in", values, "LN_KB_INF1");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1Between(String value1, String value2) {
            addCriterion("LN_KB_INF1 between", value1, value2, "LN_KB_INF1");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1NotBetween(String value1, String value2) {
            addCriterion("LN_KB_INF1 not between", value1, value2, "LN_KB_INF1");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2IsNull() {
            addCriterion("LN_KB_INF2 is null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2IsNotNull() {
            addCriterion("LN_KB_INF2 is not null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2EqualTo(String value) {
            addCriterion("LN_KB_INF2 =", value, "LN_KB_INF2");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2NotEqualTo(String value) {
            addCriterion("LN_KB_INF2 <>", value, "LN_KB_INF2");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2GreaterThan(String value) {
            addCriterion("LN_KB_INF2 >", value, "LN_KB_INF2");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2GreaterThanOrEqualTo(String value) {
            addCriterion("LN_KB_INF2 >=", value, "LN_KB_INF2");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2LessThan(String value) {
            addCriterion("LN_KB_INF2 <", value, "LN_KB_INF2");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2LessThanOrEqualTo(String value) {
            addCriterion("LN_KB_INF2 <=", value, "LN_KB_INF2");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2Like(String value) {
            addCriterion("LN_KB_INF2 like", value, "LN_KB_INF2");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2NotLike(String value) {
            addCriterion("LN_KB_INF2 not like", value, "LN_KB_INF2");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2In(List<String> values) {
            addCriterion("LN_KB_INF2 in", values, "LN_KB_INF2");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2NotIn(List<String> values) {
            addCriterion("LN_KB_INF2 not in", values, "LN_KB_INF2");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2Between(String value1, String value2) {
            addCriterion("LN_KB_INF2 between", value1, value2, "LN_KB_INF2");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2NotBetween(String value1, String value2) {
            addCriterion("LN_KB_INF2 not between", value1, value2, "LN_KB_INF2");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3IsNull() {
            addCriterion("LN_KB_INF3 is null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3IsNotNull() {
            addCriterion("LN_KB_INF3 is not null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3EqualTo(String value) {
            addCriterion("LN_KB_INF3 =", value, "LN_KB_INF3");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3NotEqualTo(String value) {
            addCriterion("LN_KB_INF3 <>", value, "LN_KB_INF3");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3GreaterThan(String value) {
            addCriterion("LN_KB_INF3 >", value, "LN_KB_INF3");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3GreaterThanOrEqualTo(String value) {
            addCriterion("LN_KB_INF3 >=", value, "LN_KB_INF3");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3LessThan(String value) {
            addCriterion("LN_KB_INF3 <", value, "LN_KB_INF3");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3LessThanOrEqualTo(String value) {
            addCriterion("LN_KB_INF3 <=", value, "LN_KB_INF3");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3Like(String value) {
            addCriterion("LN_KB_INF3 like", value, "LN_KB_INF3");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3NotLike(String value) {
            addCriterion("LN_KB_INF3 not like", value, "LN_KB_INF3");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3In(List<String> values) {
            addCriterion("LN_KB_INF3 in", values, "LN_KB_INF3");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3NotIn(List<String> values) {
            addCriterion("LN_KB_INF3 not in", values, "LN_KB_INF3");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3Between(String value1, String value2) {
            addCriterion("LN_KB_INF3 between", value1, value2, "LN_KB_INF3");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3NotBetween(String value1, String value2) {
            addCriterion("LN_KB_INF3 not between", value1, value2, "LN_KB_INF3");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF_CUST1IsNull() {
            addCriterion("LN_KB_INF_CUST1 is null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF_CUST1IsNotNull() {
            addCriterion("LN_KB_INF_CUST1 is not null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF_CUST1EqualTo(String value) {
            addCriterion("LN_KB_INF_CUST1 =", value, "LN_KB_INF_CUST1");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF_CUST1NotEqualTo(String value) {
            addCriterion("LN_KB_INF_CUST1 <>", value, "LN_KB_INF_CUST1");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF_CUST1GreaterThan(String value) {
            addCriterion("LN_KB_INF_CUST1 >", value, "LN_KB_INF_CUST1");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF_CUST1GreaterThanOrEqualTo(String value) {
            addCriterion("LN_KB_INF_CUST1 >=", value, "LN_KB_INF_CUST1");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF_CUST1LessThan(String value) {
            addCriterion("LN_KB_INF_CUST1 <", value, "LN_KB_INF_CUST1");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF_CUST1LessThanOrEqualTo(String value) {
            addCriterion("LN_KB_INF_CUST1 <=", value, "LN_KB_INF_CUST1");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF_CUST1Like(String value) {
            addCriterion("LN_KB_INF_CUST1 like", value, "LN_KB_INF_CUST1");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF_CUST1NotLike(String value) {
            addCriterion("LN_KB_INF_CUST1 not like", value, "LN_KB_INF_CUST1");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF_CUST1In(List<String> values) {
            addCriterion("LN_KB_INF_CUST1 in", values, "LN_KB_INF_CUST1");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF_CUST1NotIn(List<String> values) {
            addCriterion("LN_KB_INF_CUST1 not in", values, "LN_KB_INF_CUST1");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF_CUST1Between(String value1, String value2) {
            addCriterion("LN_KB_INF_CUST1 between", value1, value2, "LN_KB_INF_CUST1");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF_CUST1NotBetween(String value1, String value2) {
            addCriterion("LN_KB_INF_CUST1 not between", value1, value2, "LN_KB_INF_CUST1");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1_RMIsNull() {
            addCriterion("LN_KB_INF1_RM is null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1_RMIsNotNull() {
            addCriterion("LN_KB_INF1_RM is not null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1_RMEqualTo(String value) {
            addCriterion("LN_KB_INF1_RM =", value, "LN_KB_INF1_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1_RMNotEqualTo(String value) {
            addCriterion("LN_KB_INF1_RM <>", value, "LN_KB_INF1_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1_RMGreaterThan(String value) {
            addCriterion("LN_KB_INF1_RM >", value, "LN_KB_INF1_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1_RMGreaterThanOrEqualTo(String value) {
            addCriterion("LN_KB_INF1_RM >=", value, "LN_KB_INF1_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1_RMLessThan(String value) {
            addCriterion("LN_KB_INF1_RM <", value, "LN_KB_INF1_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1_RMLessThanOrEqualTo(String value) {
            addCriterion("LN_KB_INF1_RM <=", value, "LN_KB_INF1_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1_RMLike(String value) {
            addCriterion("LN_KB_INF1_RM like", value, "LN_KB_INF1_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1_RMNotLike(String value) {
            addCriterion("LN_KB_INF1_RM not like", value, "LN_KB_INF1_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1_RMIn(List<String> values) {
            addCriterion("LN_KB_INF1_RM in", values, "LN_KB_INF1_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1_RMNotIn(List<String> values) {
            addCriterion("LN_KB_INF1_RM not in", values, "LN_KB_INF1_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1_RMBetween(String value1, String value2) {
            addCriterion("LN_KB_INF1_RM between", value1, value2, "LN_KB_INF1_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1_RMNotBetween(String value1, String value2) {
            addCriterion("LN_KB_INF1_RM not between", value1, value2, "LN_KB_INF1_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2_RMIsNull() {
            addCriterion("LN_KB_INF2_RM is null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2_RMIsNotNull() {
            addCriterion("LN_KB_INF2_RM is not null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2_RMEqualTo(String value) {
            addCriterion("LN_KB_INF2_RM =", value, "LN_KB_INF2_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2_RMNotEqualTo(String value) {
            addCriterion("LN_KB_INF2_RM <>", value, "LN_KB_INF2_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2_RMGreaterThan(String value) {
            addCriterion("LN_KB_INF2_RM >", value, "LN_KB_INF2_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2_RMGreaterThanOrEqualTo(String value) {
            addCriterion("LN_KB_INF2_RM >=", value, "LN_KB_INF2_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2_RMLessThan(String value) {
            addCriterion("LN_KB_INF2_RM <", value, "LN_KB_INF2_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2_RMLessThanOrEqualTo(String value) {
            addCriterion("LN_KB_INF2_RM <=", value, "LN_KB_INF2_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2_RMLike(String value) {
            addCriterion("LN_KB_INF2_RM like", value, "LN_KB_INF2_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2_RMNotLike(String value) {
            addCriterion("LN_KB_INF2_RM not like", value, "LN_KB_INF2_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2_RMIn(List<String> values) {
            addCriterion("LN_KB_INF2_RM in", values, "LN_KB_INF2_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2_RMNotIn(List<String> values) {
            addCriterion("LN_KB_INF2_RM not in", values, "LN_KB_INF2_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2_RMBetween(String value1, String value2) {
            addCriterion("LN_KB_INF2_RM between", value1, value2, "LN_KB_INF2_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2_RMNotBetween(String value1, String value2) {
            addCriterion("LN_KB_INF2_RM not between", value1, value2, "LN_KB_INF2_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3_RMIsNull() {
            addCriterion("LN_KB_INF3_RM is null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3_RMIsNotNull() {
            addCriterion("LN_KB_INF3_RM is not null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3_RMEqualTo(String value) {
            addCriterion("LN_KB_INF3_RM =", value, "LN_KB_INF3_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3_RMNotEqualTo(String value) {
            addCriterion("LN_KB_INF3_RM <>", value, "LN_KB_INF3_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3_RMGreaterThan(String value) {
            addCriterion("LN_KB_INF3_RM >", value, "LN_KB_INF3_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3_RMGreaterThanOrEqualTo(String value) {
            addCriterion("LN_KB_INF3_RM >=", value, "LN_KB_INF3_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3_RMLessThan(String value) {
            addCriterion("LN_KB_INF3_RM <", value, "LN_KB_INF3_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3_RMLessThanOrEqualTo(String value) {
            addCriterion("LN_KB_INF3_RM <=", value, "LN_KB_INF3_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3_RMLike(String value) {
            addCriterion("LN_KB_INF3_RM like", value, "LN_KB_INF3_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3_RMNotLike(String value) {
            addCriterion("LN_KB_INF3_RM not like", value, "LN_KB_INF3_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3_RMIn(List<String> values) {
            addCriterion("LN_KB_INF3_RM in", values, "LN_KB_INF3_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3_RMNotIn(List<String> values) {
            addCriterion("LN_KB_INF3_RM not in", values, "LN_KB_INF3_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3_RMBetween(String value1, String value2) {
            addCriterion("LN_KB_INF3_RM between", value1, value2, "LN_KB_INF3_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3_RMNotBetween(String value1, String value2) {
            addCriterion("LN_KB_INF3_RM not between", value1, value2, "LN_KB_INF3_RM");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIG_RMIsNull() {
            addCriterion("LN_LAST_SIG_RM is null");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIG_RMIsNotNull() {
            addCriterion("LN_LAST_SIG_RM is not null");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIG_RMEqualTo(String value) {
            addCriterion("LN_LAST_SIG_RM =", value, "LN_LAST_SIG_RM");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIG_RMNotEqualTo(String value) {
            addCriterion("LN_LAST_SIG_RM <>", value, "LN_LAST_SIG_RM");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIG_RMGreaterThan(String value) {
            addCriterion("LN_LAST_SIG_RM >", value, "LN_LAST_SIG_RM");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIG_RMGreaterThanOrEqualTo(String value) {
            addCriterion("LN_LAST_SIG_RM >=", value, "LN_LAST_SIG_RM");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIG_RMLessThan(String value) {
            addCriterion("LN_LAST_SIG_RM <", value, "LN_LAST_SIG_RM");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIG_RMLessThanOrEqualTo(String value) {
            addCriterion("LN_LAST_SIG_RM <=", value, "LN_LAST_SIG_RM");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIG_RMLike(String value) {
            addCriterion("LN_LAST_SIG_RM like", value, "LN_LAST_SIG_RM");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIG_RMNotLike(String value) {
            addCriterion("LN_LAST_SIG_RM not like", value, "LN_LAST_SIG_RM");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIG_RMIn(List<String> values) {
            addCriterion("LN_LAST_SIG_RM in", values, "LN_LAST_SIG_RM");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIG_RMNotIn(List<String> values) {
            addCriterion("LN_LAST_SIG_RM not in", values, "LN_LAST_SIG_RM");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIG_RMBetween(String value1, String value2) {
            addCriterion("LN_LAST_SIG_RM between", value1, value2, "LN_LAST_SIG_RM");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIG_RMNotBetween(String value1, String value2) {
            addCriterion("LN_LAST_SIG_RM not between", value1, value2, "LN_LAST_SIG_RM");
            return (Criteria) this;
        }

        public Criteria andRM_BUZZ_NOTICE_FLGIsNull() {
            addCriterion("RM_BUZZ_NOTICE_FLG is null");
            return (Criteria) this;
        }

        public Criteria andRM_BUZZ_NOTICE_FLGIsNotNull() {
            addCriterion("RM_BUZZ_NOTICE_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andRM_BUZZ_NOTICE_FLGEqualTo(String value) {
            addCriterion("RM_BUZZ_NOTICE_FLG =", value, "RM_BUZZ_NOTICE_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_BUZZ_NOTICE_FLGNotEqualTo(String value) {
            addCriterion("RM_BUZZ_NOTICE_FLG <>", value, "RM_BUZZ_NOTICE_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_BUZZ_NOTICE_FLGGreaterThan(String value) {
            addCriterion("RM_BUZZ_NOTICE_FLG >", value, "RM_BUZZ_NOTICE_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_BUZZ_NOTICE_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("RM_BUZZ_NOTICE_FLG >=", value, "RM_BUZZ_NOTICE_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_BUZZ_NOTICE_FLGLessThan(String value) {
            addCriterion("RM_BUZZ_NOTICE_FLG <", value, "RM_BUZZ_NOTICE_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_BUZZ_NOTICE_FLGLessThanOrEqualTo(String value) {
            addCriterion("RM_BUZZ_NOTICE_FLG <=", value, "RM_BUZZ_NOTICE_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_BUZZ_NOTICE_FLGLike(String value) {
            addCriterion("RM_BUZZ_NOTICE_FLG like", value, "RM_BUZZ_NOTICE_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_BUZZ_NOTICE_FLGNotLike(String value) {
            addCriterion("RM_BUZZ_NOTICE_FLG not like", value, "RM_BUZZ_NOTICE_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_BUZZ_NOTICE_FLGIn(List<String> values) {
            addCriterion("RM_BUZZ_NOTICE_FLG in", values, "RM_BUZZ_NOTICE_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_BUZZ_NOTICE_FLGNotIn(List<String> values) {
            addCriterion("RM_BUZZ_NOTICE_FLG not in", values, "RM_BUZZ_NOTICE_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_BUZZ_NOTICE_FLGBetween(String value1, String value2) {
            addCriterion("RM_BUZZ_NOTICE_FLG between", value1, value2, "RM_BUZZ_NOTICE_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_BUZZ_NOTICE_FLGNotBetween(String value1, String value2) {
            addCriterion("RM_BUZZ_NOTICE_FLG not between", value1, value2, "RM_BUZZ_NOTICE_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_SIG_SEND_FLGIsNull() {
            addCriterion("RM_SIG_SEND_FLG is null");
            return (Criteria) this;
        }

        public Criteria andRM_SIG_SEND_FLGIsNotNull() {
            addCriterion("RM_SIG_SEND_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andRM_SIG_SEND_FLGEqualTo(String value) {
            addCriterion("RM_SIG_SEND_FLG =", value, "RM_SIG_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_SIG_SEND_FLGNotEqualTo(String value) {
            addCriterion("RM_SIG_SEND_FLG <>", value, "RM_SIG_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_SIG_SEND_FLGGreaterThan(String value) {
            addCriterion("RM_SIG_SEND_FLG >", value, "RM_SIG_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_SIG_SEND_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("RM_SIG_SEND_FLG >=", value, "RM_SIG_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_SIG_SEND_FLGLessThan(String value) {
            addCriterion("RM_SIG_SEND_FLG <", value, "RM_SIG_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_SIG_SEND_FLGLessThanOrEqualTo(String value) {
            addCriterion("RM_SIG_SEND_FLG <=", value, "RM_SIG_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_SIG_SEND_FLGLike(String value) {
            addCriterion("RM_SIG_SEND_FLG like", value, "RM_SIG_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_SIG_SEND_FLGNotLike(String value) {
            addCriterion("RM_SIG_SEND_FLG not like", value, "RM_SIG_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_SIG_SEND_FLGIn(List<String> values) {
            addCriterion("RM_SIG_SEND_FLG in", values, "RM_SIG_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_SIG_SEND_FLGNotIn(List<String> values) {
            addCriterion("RM_SIG_SEND_FLG not in", values, "RM_SIG_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_SIG_SEND_FLGBetween(String value1, String value2) {
            addCriterion("RM_SIG_SEND_FLG between", value1, value2, "RM_SIG_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_SIG_SEND_FLGNotBetween(String value1, String value2) {
            addCriterion("RM_SIG_SEND_FLG not between", value1, value2, "RM_SIG_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andLIVE_VIEWER_FLGIsNull() {
            addCriterion("LIVE_VIEWER_FLG is null");
            return (Criteria) this;
        }

        public Criteria andLIVE_VIEWER_FLGIsNotNull() {
            addCriterion("LIVE_VIEWER_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andLIVE_VIEWER_FLGEqualTo(String value) {
            addCriterion("LIVE_VIEWER_FLG =", value, "LIVE_VIEWER_FLG");
            return (Criteria) this;
        }

        public Criteria andLIVE_VIEWER_FLGNotEqualTo(String value) {
            addCriterion("LIVE_VIEWER_FLG <>", value, "LIVE_VIEWER_FLG");
            return (Criteria) this;
        }

        public Criteria andLIVE_VIEWER_FLGGreaterThan(String value) {
            addCriterion("LIVE_VIEWER_FLG >", value, "LIVE_VIEWER_FLG");
            return (Criteria) this;
        }

        public Criteria andLIVE_VIEWER_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("LIVE_VIEWER_FLG >=", value, "LIVE_VIEWER_FLG");
            return (Criteria) this;
        }

        public Criteria andLIVE_VIEWER_FLGLessThan(String value) {
            addCriterion("LIVE_VIEWER_FLG <", value, "LIVE_VIEWER_FLG");
            return (Criteria) this;
        }

        public Criteria andLIVE_VIEWER_FLGLessThanOrEqualTo(String value) {
            addCriterion("LIVE_VIEWER_FLG <=", value, "LIVE_VIEWER_FLG");
            return (Criteria) this;
        }

        public Criteria andLIVE_VIEWER_FLGLike(String value) {
            addCriterion("LIVE_VIEWER_FLG like", value, "LIVE_VIEWER_FLG");
            return (Criteria) this;
        }

        public Criteria andLIVE_VIEWER_FLGNotLike(String value) {
            addCriterion("LIVE_VIEWER_FLG not like", value, "LIVE_VIEWER_FLG");
            return (Criteria) this;
        }

        public Criteria andLIVE_VIEWER_FLGIn(List<String> values) {
            addCriterion("LIVE_VIEWER_FLG in", values, "LIVE_VIEWER_FLG");
            return (Criteria) this;
        }

        public Criteria andLIVE_VIEWER_FLGNotIn(List<String> values) {
            addCriterion("LIVE_VIEWER_FLG not in", values, "LIVE_VIEWER_FLG");
            return (Criteria) this;
        }

        public Criteria andLIVE_VIEWER_FLGBetween(String value1, String value2) {
            addCriterion("LIVE_VIEWER_FLG between", value1, value2, "LIVE_VIEWER_FLG");
            return (Criteria) this;
        }

        public Criteria andLIVE_VIEWER_FLGNotBetween(String value1, String value2) {
            addCriterion("LIVE_VIEWER_FLG not between", value1, value2, "LIVE_VIEWER_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_DISP_FLGIsNull() {
            addCriterion("RM_DISP_FLG is null");
            return (Criteria) this;
        }

        public Criteria andRM_DISP_FLGIsNotNull() {
            addCriterion("RM_DISP_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andRM_DISP_FLGEqualTo(String value) {
            addCriterion("RM_DISP_FLG =", value, "RM_DISP_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_DISP_FLGNotEqualTo(String value) {
            addCriterion("RM_DISP_FLG <>", value, "RM_DISP_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_DISP_FLGGreaterThan(String value) {
            addCriterion("RM_DISP_FLG >", value, "RM_DISP_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_DISP_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("RM_DISP_FLG >=", value, "RM_DISP_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_DISP_FLGLessThan(String value) {
            addCriterion("RM_DISP_FLG <", value, "RM_DISP_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_DISP_FLGLessThanOrEqualTo(String value) {
            addCriterion("RM_DISP_FLG <=", value, "RM_DISP_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_DISP_FLGLike(String value) {
            addCriterion("RM_DISP_FLG like", value, "RM_DISP_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_DISP_FLGNotLike(String value) {
            addCriterion("RM_DISP_FLG not like", value, "RM_DISP_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_DISP_FLGIn(List<String> values) {
            addCriterion("RM_DISP_FLG in", values, "RM_DISP_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_DISP_FLGNotIn(List<String> values) {
            addCriterion("RM_DISP_FLG not in", values, "RM_DISP_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_DISP_FLGBetween(String value1, String value2) {
            addCriterion("RM_DISP_FLG between", value1, value2, "RM_DISP_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_DISP_FLGNotBetween(String value1, String value2) {
            addCriterion("RM_DISP_FLG not between", value1, value2, "RM_DISP_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_KIDOU_FLGIsNull() {
            addCriterion("SINPO_KIDOU_FLG is null");
            return (Criteria) this;
        }

        public Criteria andSINPO_KIDOU_FLGIsNotNull() {
            addCriterion("SINPO_KIDOU_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andSINPO_KIDOU_FLGEqualTo(String value) {
            addCriterion("SINPO_KIDOU_FLG =", value, "SINPO_KIDOU_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_KIDOU_FLGNotEqualTo(String value) {
            addCriterion("SINPO_KIDOU_FLG <>", value, "SINPO_KIDOU_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_KIDOU_FLGGreaterThan(String value) {
            addCriterion("SINPO_KIDOU_FLG >", value, "SINPO_KIDOU_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_KIDOU_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("SINPO_KIDOU_FLG >=", value, "SINPO_KIDOU_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_KIDOU_FLGLessThan(String value) {
            addCriterion("SINPO_KIDOU_FLG <", value, "SINPO_KIDOU_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_KIDOU_FLGLessThanOrEqualTo(String value) {
            addCriterion("SINPO_KIDOU_FLG <=", value, "SINPO_KIDOU_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_KIDOU_FLGLike(String value) {
            addCriterion("SINPO_KIDOU_FLG like", value, "SINPO_KIDOU_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_KIDOU_FLGNotLike(String value) {
            addCriterion("SINPO_KIDOU_FLG not like", value, "SINPO_KIDOU_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_KIDOU_FLGIn(List<String> values) {
            addCriterion("SINPO_KIDOU_FLG in", values, "SINPO_KIDOU_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_KIDOU_FLGNotIn(List<String> values) {
            addCriterion("SINPO_KIDOU_FLG not in", values, "SINPO_KIDOU_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_KIDOU_FLGBetween(String value1, String value2) {
            addCriterion("SINPO_KIDOU_FLG between", value1, value2, "SINPO_KIDOU_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_KIDOU_FLGNotBetween(String value1, String value2) {
            addCriterion("SINPO_KIDOU_FLG not between", value1, value2, "SINPO_KIDOU_FLG");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_IDIsNull() {
            addCriterion("JIGYOU_ID is null");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_IDIsNotNull() {
            addCriterion("JIGYOU_ID is not null");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_IDEqualTo(String value) {
            addCriterion("JIGYOU_ID =", value, "JIGYOU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_IDNotEqualTo(String value) {
            addCriterion("JIGYOU_ID <>", value, "JIGYOU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_IDGreaterThan(String value) {
            addCriterion("JIGYOU_ID >", value, "JIGYOU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_IDGreaterThanOrEqualTo(String value) {
            addCriterion("JIGYOU_ID >=", value, "JIGYOU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_IDLessThan(String value) {
            addCriterion("JIGYOU_ID <", value, "JIGYOU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_IDLessThanOrEqualTo(String value) {
            addCriterion("JIGYOU_ID <=", value, "JIGYOU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_IDLike(String value) {
            addCriterion("JIGYOU_ID like", value, "JIGYOU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_IDNotLike(String value) {
            addCriterion("JIGYOU_ID not like", value, "JIGYOU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_IDIn(List<String> values) {
            addCriterion("JIGYOU_ID in", values, "JIGYOU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_IDNotIn(List<String> values) {
            addCriterion("JIGYOU_ID not in", values, "JIGYOU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_IDBetween(String value1, String value2) {
            addCriterion("JIGYOU_ID between", value1, value2, "JIGYOU_ID");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_IDNotBetween(String value1, String value2) {
            addCriterion("JIGYOU_ID not between", value1, value2, "JIGYOU_ID");
            return (Criteria) this;
        }

        public Criteria andOPERATOR_IDIsNull() {
            addCriterion("OPERATOR_ID is null");
            return (Criteria) this;
        }

        public Criteria andOPERATOR_IDIsNotNull() {
            addCriterion("OPERATOR_ID is not null");
            return (Criteria) this;
        }

        public Criteria andOPERATOR_IDEqualTo(String value) {
            addCriterion("OPERATOR_ID =", value, "OPERATOR_ID");
            return (Criteria) this;
        }

        public Criteria andOPERATOR_IDNotEqualTo(String value) {
            addCriterion("OPERATOR_ID <>", value, "OPERATOR_ID");
            return (Criteria) this;
        }

        public Criteria andOPERATOR_IDGreaterThan(String value) {
            addCriterion("OPERATOR_ID >", value, "OPERATOR_ID");
            return (Criteria) this;
        }

        public Criteria andOPERATOR_IDGreaterThanOrEqualTo(String value) {
            addCriterion("OPERATOR_ID >=", value, "OPERATOR_ID");
            return (Criteria) this;
        }

        public Criteria andOPERATOR_IDLessThan(String value) {
            addCriterion("OPERATOR_ID <", value, "OPERATOR_ID");
            return (Criteria) this;
        }

        public Criteria andOPERATOR_IDLessThanOrEqualTo(String value) {
            addCriterion("OPERATOR_ID <=", value, "OPERATOR_ID");
            return (Criteria) this;
        }

        public Criteria andOPERATOR_IDLike(String value) {
            addCriterion("OPERATOR_ID like", value, "OPERATOR_ID");
            return (Criteria) this;
        }

        public Criteria andOPERATOR_IDNotLike(String value) {
            addCriterion("OPERATOR_ID not like", value, "OPERATOR_ID");
            return (Criteria) this;
        }

        public Criteria andOPERATOR_IDIn(List<String> values) {
            addCriterion("OPERATOR_ID in", values, "OPERATOR_ID");
            return (Criteria) this;
        }

        public Criteria andOPERATOR_IDNotIn(List<String> values) {
            addCriterion("OPERATOR_ID not in", values, "OPERATOR_ID");
            return (Criteria) this;
        }

        public Criteria andOPERATOR_IDBetween(String value1, String value2) {
            addCriterion("OPERATOR_ID between", value1, value2, "OPERATOR_ID");
            return (Criteria) this;
        }

        public Criteria andOPERATOR_IDNotBetween(String value1, String value2) {
            addCriterion("OPERATOR_ID not between", value1, value2, "OPERATOR_ID");
            return (Criteria) this;
        }

        public Criteria andLN_FILE_SENDIsNull() {
            addCriterion("LN_FILE_SEND is null");
            return (Criteria) this;
        }

        public Criteria andLN_FILE_SENDIsNotNull() {
            addCriterion("LN_FILE_SEND is not null");
            return (Criteria) this;
        }

        public Criteria andLN_FILE_SENDEqualTo(String value) {
            addCriterion("LN_FILE_SEND =", value, "LN_FILE_SEND");
            return (Criteria) this;
        }

        public Criteria andLN_FILE_SENDNotEqualTo(String value) {
            addCriterion("LN_FILE_SEND <>", value, "LN_FILE_SEND");
            return (Criteria) this;
        }

        public Criteria andLN_FILE_SENDGreaterThan(String value) {
            addCriterion("LN_FILE_SEND >", value, "LN_FILE_SEND");
            return (Criteria) this;
        }

        public Criteria andLN_FILE_SENDGreaterThanOrEqualTo(String value) {
            addCriterion("LN_FILE_SEND >=", value, "LN_FILE_SEND");
            return (Criteria) this;
        }

        public Criteria andLN_FILE_SENDLessThan(String value) {
            addCriterion("LN_FILE_SEND <", value, "LN_FILE_SEND");
            return (Criteria) this;
        }

        public Criteria andLN_FILE_SENDLessThanOrEqualTo(String value) {
            addCriterion("LN_FILE_SEND <=", value, "LN_FILE_SEND");
            return (Criteria) this;
        }

        public Criteria andLN_FILE_SENDLike(String value) {
            addCriterion("LN_FILE_SEND like", value, "LN_FILE_SEND");
            return (Criteria) this;
        }

        public Criteria andLN_FILE_SENDNotLike(String value) {
            addCriterion("LN_FILE_SEND not like", value, "LN_FILE_SEND");
            return (Criteria) this;
        }

        public Criteria andLN_FILE_SENDIn(List<String> values) {
            addCriterion("LN_FILE_SEND in", values, "LN_FILE_SEND");
            return (Criteria) this;
        }

        public Criteria andLN_FILE_SENDNotIn(List<String> values) {
            addCriterion("LN_FILE_SEND not in", values, "LN_FILE_SEND");
            return (Criteria) this;
        }

        public Criteria andLN_FILE_SENDBetween(String value1, String value2) {
            addCriterion("LN_FILE_SEND between", value1, value2, "LN_FILE_SEND");
            return (Criteria) this;
        }

        public Criteria andLN_FILE_SENDNotBetween(String value1, String value2) {
            addCriterion("LN_FILE_SEND not between", value1, value2, "LN_FILE_SEND");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMIsNull() {
            addCriterion("PROCESS_NUM is null");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMIsNotNull() {
            addCriterion("PROCESS_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMEqualTo(String value) {
            addCriterion("PROCESS_NUM =", value, "PROCESS_NUM");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMNotEqualTo(String value) {
            addCriterion("PROCESS_NUM <>", value, "PROCESS_NUM");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMGreaterThan(String value) {
            addCriterion("PROCESS_NUM >", value, "PROCESS_NUM");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("PROCESS_NUM >=", value, "PROCESS_NUM");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMLessThan(String value) {
            addCriterion("PROCESS_NUM <", value, "PROCESS_NUM");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMLessThanOrEqualTo(String value) {
            addCriterion("PROCESS_NUM <=", value, "PROCESS_NUM");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMLike(String value) {
            addCriterion("PROCESS_NUM like", value, "PROCESS_NUM");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMNotLike(String value) {
            addCriterion("PROCESS_NUM not like", value, "PROCESS_NUM");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMIn(List<String> values) {
            addCriterion("PROCESS_NUM in", values, "PROCESS_NUM");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMNotIn(List<String> values) {
            addCriterion("PROCESS_NUM not in", values, "PROCESS_NUM");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMBetween(String value1, String value2) {
            addCriterion("PROCESS_NUM between", value1, value2, "PROCESS_NUM");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMNotBetween(String value1, String value2) {
            addCriterion("PROCESS_NUM not between", value1, value2, "PROCESS_NUM");
            return (Criteria) this;
        }

        public Criteria andKYLESS_STIsNull() {
            addCriterion("KYLESS_ST is null");
            return (Criteria) this;
        }

        public Criteria andKYLESS_STIsNotNull() {
            addCriterion("KYLESS_ST is not null");
            return (Criteria) this;
        }

        public Criteria andKYLESS_STEqualTo(String value) {
            addCriterion("KYLESS_ST =", value, "KYLESS_ST");
            return (Criteria) this;
        }

        public Criteria andKYLESS_STNotEqualTo(String value) {
            addCriterion("KYLESS_ST <>", value, "KYLESS_ST");
            return (Criteria) this;
        }

        public Criteria andKYLESS_STGreaterThan(String value) {
            addCriterion("KYLESS_ST >", value, "KYLESS_ST");
            return (Criteria) this;
        }

        public Criteria andKYLESS_STGreaterThanOrEqualTo(String value) {
            addCriterion("KYLESS_ST >=", value, "KYLESS_ST");
            return (Criteria) this;
        }

        public Criteria andKYLESS_STLessThan(String value) {
            addCriterion("KYLESS_ST <", value, "KYLESS_ST");
            return (Criteria) this;
        }

        public Criteria andKYLESS_STLessThanOrEqualTo(String value) {
            addCriterion("KYLESS_ST <=", value, "KYLESS_ST");
            return (Criteria) this;
        }

        public Criteria andKYLESS_STLike(String value) {
            addCriterion("KYLESS_ST like", value, "KYLESS_ST");
            return (Criteria) this;
        }

        public Criteria andKYLESS_STNotLike(String value) {
            addCriterion("KYLESS_ST not like", value, "KYLESS_ST");
            return (Criteria) this;
        }

        public Criteria andKYLESS_STIn(List<String> values) {
            addCriterion("KYLESS_ST in", values, "KYLESS_ST");
            return (Criteria) this;
        }

        public Criteria andKYLESS_STNotIn(List<String> values) {
            addCriterion("KYLESS_ST not in", values, "KYLESS_ST");
            return (Criteria) this;
        }

        public Criteria andKYLESS_STBetween(String value1, String value2) {
            addCriterion("KYLESS_ST between", value1, value2, "KYLESS_ST");
            return (Criteria) this;
        }

        public Criteria andKYLESS_STNotBetween(String value1, String value2) {
            addCriterion("KYLESS_ST not between", value1, value2, "KYLESS_ST");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andLN_JIANLikeInsensitive(String value) {
            addCriterion("upper(LN_JIAN) like", value.toUpperCase(), "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JITAILikeInsensitive(String value) {
            addCriterion("upper(LN_JITAI) like", value.toUpperCase(), "LN_JITAI");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKULikeInsensitive(String value) {
            addCriterion("upper(LN_KB_CHIKU) like", value.toUpperCase(), "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andBUZZ_FLGLikeInsensitive(String value) {
            addCriterion("upper(BUZZ_FLG) like", value.toUpperCase(), "BUZZ_FLG");
            return (Criteria) this;
        }

        public Criteria andPRIORITYLikeInsensitive(String value) {
            addCriterion("upper(PRIORITY) like", value.toUpperCase(), "PRIORITY");
            return (Criteria) this;
        }

        public Criteria andJIAN_CAUSE_FLGLikeInsensitive(String value) {
            addCriterion("upper(JIAN_CAUSE_FLG) like", value.toUpperCase(), "JIAN_CAUSE_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_HYOJI_FLGLikeInsensitive(String value) {
            addCriterion("upper(JIAN_HYOJI_FLG) like", value.toUpperCase(), "JIAN_HYOJI_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_TANTO_FLGLikeInsensitive(String value) {
            addCriterion("upper(JIAN_TANTO_FLG) like", value.toUpperCase(), "JIAN_TANTO_FLG");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIGLikeInsensitive(String value) {
            addCriterion("upper(LN_LAST_SIG) like", value.toUpperCase(), "LN_LAST_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_NF_SIGLikeInsensitive(String value) {
            addCriterion("upper(LN_LAST_NF_SIG) like", value.toUpperCase(), "LN_LAST_NF_SIG");
            return (Criteria) this;
        }

        public Criteria andGC_SENT_FLGLikeInsensitive(String value) {
            addCriterion("upper(GC_SENT_FLG) like", value.toUpperCase(), "GC_SENT_FLG");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_MAKE_USERLikeInsensitive(String value) {
            addCriterion("upper(LN_JIAN_MAKE_USER) like", value.toUpperCase(), "LN_JIAN_MAKE_USER");
            return (Criteria) this;
        }

        public Criteria andJIAN_MAKE_USER_NMLikeInsensitive(String value) {
            addCriterion("upper(JIAN_MAKE_USER_NM) like", value.toUpperCase(), "JIAN_MAKE_USER_NM");
            return (Criteria) this;
        }

        public Criteria andLN_JIAN_END_USER_IDLikeInsensitive(String value) {
            addCriterion("upper(LN_JIAN_END_USER_ID) like", value.toUpperCase(), "LN_JIAN_END_USER_ID");
            return (Criteria) this;
        }

        public Criteria andJIAN_END_USER_NMLikeInsensitive(String value) {
            addCriterion("upper(JIAN_END_USER_NM) like", value.toUpperCase(), "JIAN_END_USER_NM");
            return (Criteria) this;
        }

        public Criteria andLN_TOROKU_KIND_NUMLikeInsensitive(String value) {
            addCriterion("upper(LN_TOROKU_KIND_NUM) like", value.toUpperCase(), "LN_TOROKU_KIND_NUM");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KIND_CDLikeInsensitive(String value) {
            addCriterion("upper(TOROKU_KIND_CD) like", value.toUpperCase(), "TOROKU_KIND_CD");
            return (Criteria) this;
        }

        public Criteria andTOROKU_KINDLikeInsensitive(String value) {
            addCriterion("upper(TOROKU_KIND) like", value.toUpperCase(), "TOROKU_KIND");
            return (Criteria) this;
        }

        public Criteria andLN_GENINLikeInsensitive(String value) {
            addCriterion("upper(LN_GENIN) like", value.toUpperCase(), "LN_GENIN");
            return (Criteria) this;
        }

        public Criteria andKEIBI_GENIN_NAIYOULikeInsensitive(String value) {
            addCriterion("upper(KEIBI_GENIN_NAIYOU) like", value.toUpperCase(), "KEIBI_GENIN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andFIRST_JIAN_HYOUJI_DEV_KINDLikeInsensitive(String value) {
            addCriterion("upper(FIRST_JIAN_HYOUJI_DEV_KIND) like", value.toUpperCase(), "FIRST_JIAN_HYOUJI_DEV_KIND");
            return (Criteria) this;
        }

        public Criteria andJIAN_OPE_AUTH_DEV_KINDLikeInsensitive(String value) {
            addCriterion("upper(JIAN_OPE_AUTH_DEV_KIND) like", value.toUpperCase(), "JIAN_OPE_AUTH_DEV_KIND");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_SSLikeInsensitive(String value) {
            addCriterion("upper(LIMIT_EXT_SS) like", value.toUpperCase(), "LIMIT_EXT_SS");
            return (Criteria) this;
        }

        public Criteria andLIMIT_EXT_MAX_SSLikeInsensitive(String value) {
            addCriterion("upper(LIMIT_EXT_MAX_SS) like", value.toUpperCase(), "LIMIT_EXT_MAX_SS");
            return (Criteria) this;
        }

        public Criteria andSINPO_JISSI_FLGLikeInsensitive(String value) {
            addCriterion("upper(SINPO_JISSI_FLG) like", value.toUpperCase(), "SINPO_JISSI_FLG");
            return (Criteria) this;
        }

        public Criteria andJIAN_FUKKYU_FLGLikeInsensitive(String value) {
            addCriterion("upper(JIAN_FUKKYU_FLG) like", value.toUpperCase(), "JIAN_FUKKYU_FLG");
            return (Criteria) this;
        }

        public Criteria andGENIN_IDLikeInsensitive(String value) {
            addCriterion("upper(GENIN_ID) like", value.toUpperCase(), "GENIN_ID");
            return (Criteria) this;
        }

        public Criteria andSINPO_REASON_FLGLikeInsensitive(String value) {
            addCriterion("upper(SINPO_REASON_FLG) like", value.toUpperCase(), "SINPO_REASON_FLG");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_FLGLikeInsensitive(String value) {
            addCriterion("upper(RAKUCHAKU_FLG) like", value.toUpperCase(), "RAKUCHAKU_FLG");
            return (Criteria) this;
        }

        public Criteria andINTP_STSLikeInsensitive(String value) {
            addCriterion("upper(INTP_STS) like", value.toUpperCase(), "INTP_STS");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDLikeInsensitive(String value) {
            addCriterion("upper(SGS_GENIN_CD) like", value.toUpperCase(), "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GENIN_CDLikeInsensitive(String value) {
            addCriterion("upper(NET_GENIN_CD) like", value.toUpperCase(), "NET_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1LikeInsensitive(String value) {
            addCriterion("upper(LN_KB_INF1) like", value.toUpperCase(), "LN_KB_INF1");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2LikeInsensitive(String value) {
            addCriterion("upper(LN_KB_INF2) like", value.toUpperCase(), "LN_KB_INF2");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3LikeInsensitive(String value) {
            addCriterion("upper(LN_KB_INF3) like", value.toUpperCase(), "LN_KB_INF3");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF_CUST1LikeInsensitive(String value) {
            addCriterion("upper(LN_KB_INF_CUST1) like", value.toUpperCase(), "LN_KB_INF_CUST1");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF1_RMLikeInsensitive(String value) {
            addCriterion("upper(LN_KB_INF1_RM) like", value.toUpperCase(), "LN_KB_INF1_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF2_RMLikeInsensitive(String value) {
            addCriterion("upper(LN_KB_INF2_RM) like", value.toUpperCase(), "LN_KB_INF2_RM");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INF3_RMLikeInsensitive(String value) {
            addCriterion("upper(LN_KB_INF3_RM) like", value.toUpperCase(), "LN_KB_INF3_RM");
            return (Criteria) this;
        }

        public Criteria andLN_LAST_SIG_RMLikeInsensitive(String value) {
            addCriterion("upper(LN_LAST_SIG_RM) like", value.toUpperCase(), "LN_LAST_SIG_RM");
            return (Criteria) this;
        }

        public Criteria andRM_BUZZ_NOTICE_FLGLikeInsensitive(String value) {
            addCriterion("upper(RM_BUZZ_NOTICE_FLG) like", value.toUpperCase(), "RM_BUZZ_NOTICE_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_SIG_SEND_FLGLikeInsensitive(String value) {
            addCriterion("upper(RM_SIG_SEND_FLG) like", value.toUpperCase(), "RM_SIG_SEND_FLG");
            return (Criteria) this;
        }

        public Criteria andLIVE_VIEWER_FLGLikeInsensitive(String value) {
            addCriterion("upper(LIVE_VIEWER_FLG) like", value.toUpperCase(), "LIVE_VIEWER_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_DISP_FLGLikeInsensitive(String value) {
            addCriterion("upper(RM_DISP_FLG) like", value.toUpperCase(), "RM_DISP_FLG");
            return (Criteria) this;
        }

        public Criteria andSINPO_KIDOU_FLGLikeInsensitive(String value) {
            addCriterion("upper(SINPO_KIDOU_FLG) like", value.toUpperCase(), "SINPO_KIDOU_FLG");
            return (Criteria) this;
        }

        public Criteria andJIGYOU_IDLikeInsensitive(String value) {
            addCriterion("upper(JIGYOU_ID) like", value.toUpperCase(), "JIGYOU_ID");
            return (Criteria) this;
        }

        public Criteria andOPERATOR_IDLikeInsensitive(String value) {
            addCriterion("upper(OPERATOR_ID) like", value.toUpperCase(), "OPERATOR_ID");
            return (Criteria) this;
        }

        public Criteria andLN_FILE_SENDLikeInsensitive(String value) {
            addCriterion("upper(LN_FILE_SEND) like", value.toUpperCase(), "LN_FILE_SEND");
            return (Criteria) this;
        }

        public Criteria andPROCESS_NUMLikeInsensitive(String value) {
            addCriterion("upper(PROCESS_NUM) like", value.toUpperCase(), "PROCESS_NUM");
            return (Criteria) this;
        }

        public Criteria andKYLESS_STLikeInsensitive(String value) {
            addCriterion("upper(KYLESS_ST) like", value.toUpperCase(), "KYLESS_ST");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * E_JIAN
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * E_JIAN null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}