package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class EJitai implements Serializable {
    /**
     * LN_事態論理番号
     */
    private String LN_JITAI;

    /**
     * システム種別ID
     */
    private String SYSTEM_KIND_ID;

    /**
     * 事態コード
     */
    private String JITAI_CD;

    /**
     * 事態名称
     */
    private String JITAI_NM;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * E_JITAI
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_事態論理番号
     * @return LN_JITAI LN_事態論理番号
     */
    public String getLN_JITAI() {
        return LN_JITAI;
    }

    /**
     * LN_事態論理番号
     * @param LN_JITAI LN_事態論理番号
     */
    public void setLN_JITAI(String LN_JITAI) {
        this.LN_JITAI = LN_JITAI == null ? null : LN_JITAI.trim();
    }

    /**
     * システム種別ID
     * @return SYSTEM_KIND_ID システム種別ID
     */
    public String getSYSTEM_KIND_ID() {
        return SYSTEM_KIND_ID;
    }

    /**
     * システム種別ID
     * @param SYSTEM_KIND_ID システム種別ID
     */
    public void setSYSTEM_KIND_ID(String SYSTEM_KIND_ID) {
        this.SYSTEM_KIND_ID = SYSTEM_KIND_ID == null ? null : SYSTEM_KIND_ID.trim();
    }

    /**
     * 事態コード
     * @return JITAI_CD 事態コード
     */
    public String getJITAI_CD() {
        return JITAI_CD;
    }

    /**
     * 事態コード
     * @param JITAI_CD 事態コード
     */
    public void setJITAI_CD(String JITAI_CD) {
        this.JITAI_CD = JITAI_CD == null ? null : JITAI_CD.trim();
    }

    /**
     * 事態名称
     * @return JITAI_NM 事態名称
     */
    public String getJITAI_NM() {
        return JITAI_NM;
    }

    /**
     * 事態名称
     * @param JITAI_NM 事態名称
     */
    public void setJITAI_NM(String JITAI_NM) {
        this.JITAI_NM = JITAI_NM == null ? null : JITAI_NM.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}