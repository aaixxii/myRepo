package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class AUserRoleAuthKey implements Serializable {
    /**
     * LN_利用者ロール論理番号
     */
    private String LN_USER_ROLE;

    /**
     * LN_警備先地区論理番号
     */
    private String LN_KB_CHIKU;

    /**
     * 利用者アカウント権限ID
     */
    private String LN_USER_ACNT_AUTH_ID;

    /**
     * A_USER_ROLE_AUTH
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_利用者ロール論理番号
     * @return LN_USER_ROLE LN_利用者ロール論理番号
     */
    public String getLN_USER_ROLE() {
        return LN_USER_ROLE;
    }

    /**
     * LN_利用者ロール論理番号
     * @param LN_USER_ROLE LN_利用者ロール論理番号
     */
    public void setLN_USER_ROLE(String LN_USER_ROLE) {
        this.LN_USER_ROLE = LN_USER_ROLE == null ? null : LN_USER_ROLE.trim();
    }

    /**
     * LN_警備先地区論理番号
     * @return LN_KB_CHIKU LN_警備先地区論理番号
     */
    public String getLN_KB_CHIKU() {
        return LN_KB_CHIKU;
    }

    /**
     * LN_警備先地区論理番号
     * @param LN_KB_CHIKU LN_警備先地区論理番号
     */
    public void setLN_KB_CHIKU(String LN_KB_CHIKU) {
        this.LN_KB_CHIKU = LN_KB_CHIKU == null ? null : LN_KB_CHIKU.trim();
    }

    /**
     * 利用者アカウント権限ID
     * @return LN_USER_ACNT_AUTH_ID 利用者アカウント権限ID
     */
    public String getLN_USER_ACNT_AUTH_ID() {
        return LN_USER_ACNT_AUTH_ID;
    }

    /**
     * 利用者アカウント権限ID
     * @param LN_USER_ACNT_AUTH_ID 利用者アカウント権限ID
     */
    public void setLN_USER_ACNT_AUTH_ID(String LN_USER_ACNT_AUTH_ID) {
        this.LN_USER_ACNT_AUTH_ID = LN_USER_ACNT_AUTH_ID == null ? null : LN_USER_ACNT_AUTH_ID.trim();
    }
}