package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class CEigyoJigyoshoKey implements Serializable {
    /**
     * 会社コード
     */
    private String KAISHA_CD;

    /**
     * 事業所コード
     */
    private String JIGYOSHO_CD;

    /**
     * C_EIGYO_JIGYOSHO
     */
    private static final long serialVersionUID = 1L;

    /**
     * 会社コード
     * @return KAISHA_CD 会社コード
     */
    public String getKAISHA_CD() {
        return KAISHA_CD;
    }

    /**
     * 会社コード
     * @param KAISHA_CD 会社コード
     */
    public void setKAISHA_CD(String KAISHA_CD) {
        this.KAISHA_CD = KAISHA_CD == null ? null : KAISHA_CD.trim();
    }

    /**
     * 事業所コード
     * @return JIGYOSHO_CD 事業所コード
     */
    public String getJIGYOSHO_CD() {
        return JIGYOSHO_CD;
    }

    /**
     * 事業所コード
     * @param JIGYOSHO_CD 事業所コード
     */
    public void setJIGYOSHO_CD(String JIGYOSHO_CD) {
        this.JIGYOSHO_CD = JIGYOSHO_CD == null ? null : JIGYOSHO_CD.trim();
    }
}