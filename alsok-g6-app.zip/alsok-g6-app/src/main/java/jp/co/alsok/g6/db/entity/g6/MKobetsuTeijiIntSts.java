package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class MKobetsuTeijiIntSts implements Serializable {
    /**
     * 個別定時監視間隔状態
     */
    private String KOBETSU_TEIJI_INT_STS;

    /**
     * 表示名
     */
    private String DISP_NM;

    /**
     * 表示順
     */
    private String ORDER_NUM;

    /**
     * 定時監視間隔_N0
     */
    private String TEIJI_INT_N0;

    /**
     * 定時監視間隔_F0
     */
    private String TEIJI_INT_F0;

    /**
     * 定時監視実施フラグ
     */
    private String TEIJI_CHK_STS_FLG;

    /**
     * IP回線フラグ
     */
    private String IP_FLG;

    /**
     * 無線回線フラグ
     */
    private String WL_FLG;

    /**
     * アナログ回線フラグ
     */
    private String ANALOG_FLG;

    /**
     * M_KOBETSU_TEIJI_INT_STS
     */
    private static final long serialVersionUID = 1L;

    /**
     * 個別定時監視間隔状態
     * @return KOBETSU_TEIJI_INT_STS 個別定時監視間隔状態
     */
    public String getKOBETSU_TEIJI_INT_STS() {
        return KOBETSU_TEIJI_INT_STS;
    }

    /**
     * 個別定時監視間隔状態
     * @param KOBETSU_TEIJI_INT_STS 個別定時監視間隔状態
     */
    public void setKOBETSU_TEIJI_INT_STS(String KOBETSU_TEIJI_INT_STS) {
        this.KOBETSU_TEIJI_INT_STS = KOBETSU_TEIJI_INT_STS == null ? null : KOBETSU_TEIJI_INT_STS.trim();
    }

    /**
     * 表示名
     * @return DISP_NM 表示名
     */
    public String getDISP_NM() {
        return DISP_NM;
    }

    /**
     * 表示名
     * @param DISP_NM 表示名
     */
    public void setDISP_NM(String DISP_NM) {
        this.DISP_NM = DISP_NM == null ? null : DISP_NM.trim();
    }

    /**
     * 表示順
     * @return ORDER_NUM 表示順
     */
    public String getORDER_NUM() {
        return ORDER_NUM;
    }

    /**
     * 表示順
     * @param ORDER_NUM 表示順
     */
    public void setORDER_NUM(String ORDER_NUM) {
        this.ORDER_NUM = ORDER_NUM == null ? null : ORDER_NUM.trim();
    }

    /**
     * 定時監視間隔_N0
     * @return TEIJI_INT_N0 定時監視間隔_N0
     */
    public String getTEIJI_INT_N0() {
        return TEIJI_INT_N0;
    }

    /**
     * 定時監視間隔_N0
     * @param TEIJI_INT_N0 定時監視間隔_N0
     */
    public void setTEIJI_INT_N0(String TEIJI_INT_N0) {
        this.TEIJI_INT_N0 = TEIJI_INT_N0 == null ? null : TEIJI_INT_N0.trim();
    }

    /**
     * 定時監視間隔_F0
     * @return TEIJI_INT_F0 定時監視間隔_F0
     */
    public String getTEIJI_INT_F0() {
        return TEIJI_INT_F0;
    }

    /**
     * 定時監視間隔_F0
     * @param TEIJI_INT_F0 定時監視間隔_F0
     */
    public void setTEIJI_INT_F0(String TEIJI_INT_F0) {
        this.TEIJI_INT_F0 = TEIJI_INT_F0 == null ? null : TEIJI_INT_F0.trim();
    }

    /**
     * 定時監視実施フラグ
     * @return TEIJI_CHK_STS_FLG 定時監視実施フラグ
     */
    public String getTEIJI_CHK_STS_FLG() {
        return TEIJI_CHK_STS_FLG;
    }

    /**
     * 定時監視実施フラグ
     * @param TEIJI_CHK_STS_FLG 定時監視実施フラグ
     */
    public void setTEIJI_CHK_STS_FLG(String TEIJI_CHK_STS_FLG) {
        this.TEIJI_CHK_STS_FLG = TEIJI_CHK_STS_FLG == null ? null : TEIJI_CHK_STS_FLG.trim();
    }

    /**
     * IP回線フラグ
     * @return IP_FLG IP回線フラグ
     */
    public String getIP_FLG() {
        return IP_FLG;
    }

    /**
     * IP回線フラグ
     * @param IP_FLG IP回線フラグ
     */
    public void setIP_FLG(String IP_FLG) {
        this.IP_FLG = IP_FLG == null ? null : IP_FLG.trim();
    }

    /**
     * 無線回線フラグ
     * @return WL_FLG 無線回線フラグ
     */
    public String getWL_FLG() {
        return WL_FLG;
    }

    /**
     * 無線回線フラグ
     * @param WL_FLG 無線回線フラグ
     */
    public void setWL_FLG(String WL_FLG) {
        this.WL_FLG = WL_FLG == null ? null : WL_FLG.trim();
    }

    /**
     * アナログ回線フラグ
     * @return ANALOG_FLG アナログ回線フラグ
     */
    public String getANALOG_FLG() {
        return ANALOG_FLG;
    }

    /**
     * アナログ回線フラグ
     * @param ANALOG_FLG アナログ回線フラグ
     */
    public void setANALOG_FLG(String ANALOG_FLG) {
        this.ANALOG_FLG = ANALOG_FLG == null ? null : ANALOG_FLG.trim();
    }
}