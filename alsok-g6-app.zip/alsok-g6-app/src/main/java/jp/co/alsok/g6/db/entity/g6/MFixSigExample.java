package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.List;

public class MFixSigExample {
    /**
     * M_FIX_SIG
     */
    protected String orderByClause;

    /**
     * M_FIX_SIG
     */
    protected boolean distinct;

    /**
     * M_FIX_SIG
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public MFixSigExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * M_FIX_SIG null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_FIX_SIGIsNull() {
            addCriterion("LN_FIX_SIG is null");
            return (Criteria) this;
        }

        public Criteria andLN_FIX_SIGIsNotNull() {
            addCriterion("LN_FIX_SIG is not null");
            return (Criteria) this;
        }

        public Criteria andLN_FIX_SIGEqualTo(String value) {
            addCriterion("LN_FIX_SIG =", value, "LN_FIX_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_FIX_SIGNotEqualTo(String value) {
            addCriterion("LN_FIX_SIG <>", value, "LN_FIX_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_FIX_SIGGreaterThan(String value) {
            addCriterion("LN_FIX_SIG >", value, "LN_FIX_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_FIX_SIGGreaterThanOrEqualTo(String value) {
            addCriterion("LN_FIX_SIG >=", value, "LN_FIX_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_FIX_SIGLessThan(String value) {
            addCriterion("LN_FIX_SIG <", value, "LN_FIX_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_FIX_SIGLessThanOrEqualTo(String value) {
            addCriterion("LN_FIX_SIG <=", value, "LN_FIX_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_FIX_SIGLike(String value) {
            addCriterion("LN_FIX_SIG like", value, "LN_FIX_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_FIX_SIGNotLike(String value) {
            addCriterion("LN_FIX_SIG not like", value, "LN_FIX_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_FIX_SIGIn(List<String> values) {
            addCriterion("LN_FIX_SIG in", values, "LN_FIX_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_FIX_SIGNotIn(List<String> values) {
            addCriterion("LN_FIX_SIG not in", values, "LN_FIX_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_FIX_SIGBetween(String value1, String value2) {
            addCriterion("LN_FIX_SIG between", value1, value2, "LN_FIX_SIG");
            return (Criteria) this;
        }

        public Criteria andLN_FIX_SIGNotBetween(String value1, String value2) {
            addCriterion("LN_FIX_SIG not between", value1, value2, "LN_FIX_SIG");
            return (Criteria) this;
        }

        public Criteria andSINGOIsNull() {
            addCriterion("SINGO is null");
            return (Criteria) this;
        }

        public Criteria andSINGOIsNotNull() {
            addCriterion("SINGO is not null");
            return (Criteria) this;
        }

        public Criteria andSINGOEqualTo(String value) {
            addCriterion("SINGO =", value, "SINGO");
            return (Criteria) this;
        }

        public Criteria andSINGONotEqualTo(String value) {
            addCriterion("SINGO <>", value, "SINGO");
            return (Criteria) this;
        }

        public Criteria andSINGOGreaterThan(String value) {
            addCriterion("SINGO >", value, "SINGO");
            return (Criteria) this;
        }

        public Criteria andSINGOGreaterThanOrEqualTo(String value) {
            addCriterion("SINGO >=", value, "SINGO");
            return (Criteria) this;
        }

        public Criteria andSINGOLessThan(String value) {
            addCriterion("SINGO <", value, "SINGO");
            return (Criteria) this;
        }

        public Criteria andSINGOLessThanOrEqualTo(String value) {
            addCriterion("SINGO <=", value, "SINGO");
            return (Criteria) this;
        }

        public Criteria andSINGOLike(String value) {
            addCriterion("SINGO like", value, "SINGO");
            return (Criteria) this;
        }

        public Criteria andSINGONotLike(String value) {
            addCriterion("SINGO not like", value, "SINGO");
            return (Criteria) this;
        }

        public Criteria andSINGOIn(List<String> values) {
            addCriterion("SINGO in", values, "SINGO");
            return (Criteria) this;
        }

        public Criteria andSINGONotIn(List<String> values) {
            addCriterion("SINGO not in", values, "SINGO");
            return (Criteria) this;
        }

        public Criteria andSINGOBetween(String value1, String value2) {
            addCriterion("SINGO between", value1, value2, "SINGO");
            return (Criteria) this;
        }

        public Criteria andSINGONotBetween(String value1, String value2) {
            addCriterion("SINGO not between", value1, value2, "SINGO");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_NMIsNull() {
            addCriterion("KEIHOU_NM is null");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_NMIsNotNull() {
            addCriterion("KEIHOU_NM is not null");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_NMEqualTo(String value) {
            addCriterion("KEIHOU_NM =", value, "KEIHOU_NM");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_NMNotEqualTo(String value) {
            addCriterion("KEIHOU_NM <>", value, "KEIHOU_NM");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_NMGreaterThan(String value) {
            addCriterion("KEIHOU_NM >", value, "KEIHOU_NM");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_NMGreaterThanOrEqualTo(String value) {
            addCriterion("KEIHOU_NM >=", value, "KEIHOU_NM");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_NMLessThan(String value) {
            addCriterion("KEIHOU_NM <", value, "KEIHOU_NM");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_NMLessThanOrEqualTo(String value) {
            addCriterion("KEIHOU_NM <=", value, "KEIHOU_NM");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_NMLike(String value) {
            addCriterion("KEIHOU_NM like", value, "KEIHOU_NM");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_NMNotLike(String value) {
            addCriterion("KEIHOU_NM not like", value, "KEIHOU_NM");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_NMIn(List<String> values) {
            addCriterion("KEIHOU_NM in", values, "KEIHOU_NM");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_NMNotIn(List<String> values) {
            addCriterion("KEIHOU_NM not in", values, "KEIHOU_NM");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_NMBetween(String value1, String value2) {
            addCriterion("KEIHOU_NM between", value1, value2, "KEIHOU_NM");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_NMNotBetween(String value1, String value2) {
            addCriterion("KEIHOU_NM not between", value1, value2, "KEIHOU_NM");
            return (Criteria) this;
        }

        public Criteria andBIKOUIsNull() {
            addCriterion("BIKOU is null");
            return (Criteria) this;
        }

        public Criteria andBIKOUIsNotNull() {
            addCriterion("BIKOU is not null");
            return (Criteria) this;
        }

        public Criteria andBIKOUEqualTo(String value) {
            addCriterion("BIKOU =", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUNotEqualTo(String value) {
            addCriterion("BIKOU <>", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUGreaterThan(String value) {
            addCriterion("BIKOU >", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUGreaterThanOrEqualTo(String value) {
            addCriterion("BIKOU >=", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOULessThan(String value) {
            addCriterion("BIKOU <", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOULessThanOrEqualTo(String value) {
            addCriterion("BIKOU <=", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOULike(String value) {
            addCriterion("BIKOU like", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUNotLike(String value) {
            addCriterion("BIKOU not like", value, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUIn(List<String> values) {
            addCriterion("BIKOU in", values, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUNotIn(List<String> values) {
            addCriterion("BIKOU not in", values, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUBetween(String value1, String value2) {
            addCriterion("BIKOU between", value1, value2, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andBIKOUNotBetween(String value1, String value2) {
            addCriterion("BIKOU not between", value1, value2, "BIKOU");
            return (Criteria) this;
        }

        public Criteria andLN_FIX_SIGLikeInsensitive(String value) {
            addCriterion("upper(LN_FIX_SIG) like", value.toUpperCase(), "LN_FIX_SIG");
            return (Criteria) this;
        }

        public Criteria andSINGOLikeInsensitive(String value) {
            addCriterion("upper(SINGO) like", value.toUpperCase(), "SINGO");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_NMLikeInsensitive(String value) {
            addCriterion("upper(KEIHOU_NM) like", value.toUpperCase(), "KEIHOU_NM");
            return (Criteria) this;
        }

        public Criteria andBIKOULikeInsensitive(String value) {
            addCriterion("upper(BIKOU) like", value.toUpperCase(), "BIKOU");
            return (Criteria) this;
        }
    }

    /**
     * M_FIX_SIG
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * M_FIX_SIG null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}