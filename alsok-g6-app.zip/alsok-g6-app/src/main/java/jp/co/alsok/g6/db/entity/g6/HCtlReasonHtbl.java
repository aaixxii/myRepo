package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class HCtlReasonHtbl implements Serializable {
    /**
     * LN_制御理由履歴論理番号
     */
    private String LN_CTL_REASON;

    /**
     * 制御登録時間
     */
    private Date CTRL_TIME;

    /**
     * 電計番号
     */
    private String DENKEI;

    /**
     * 地区
     */
    private String CHIKU;

    /**
     * 装置番号
     */
    private String DEV_NUM;

    /**
     * 制御コマンドID
     */
    private String CTRL_CMD_ID;

    /**
     * 理由
     */
    private String REASON;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * H_CTL_REASON_HTBL
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_制御理由履歴論理番号
     * @return LN_CTL_REASON LN_制御理由履歴論理番号
     */
    public String getLN_CTL_REASON() {
        return LN_CTL_REASON;
    }

    /**
     * LN_制御理由履歴論理番号
     * @param LN_CTL_REASON LN_制御理由履歴論理番号
     */
    public void setLN_CTL_REASON(String LN_CTL_REASON) {
        this.LN_CTL_REASON = LN_CTL_REASON == null ? null : LN_CTL_REASON.trim();
    }

    /**
     * 制御登録時間
     * @return CTRL_TIME 制御登録時間
     */
    public Date getCTRL_TIME() {
        return CTRL_TIME;
    }

    /**
     * 制御登録時間
     * @param CTRL_TIME 制御登録時間
     */
    public void setCTRL_TIME(Date CTRL_TIME) {
        this.CTRL_TIME = CTRL_TIME;
    }

    /**
     * 電計番号
     * @return DENKEI 電計番号
     */
    public String getDENKEI() {
        return DENKEI;
    }

    /**
     * 電計番号
     * @param DENKEI 電計番号
     */
    public void setDENKEI(String DENKEI) {
        this.DENKEI = DENKEI == null ? null : DENKEI.trim();
    }

    /**
     * 地区
     * @return CHIKU 地区
     */
    public String getCHIKU() {
        return CHIKU;
    }

    /**
     * 地区
     * @param CHIKU 地区
     */
    public void setCHIKU(String CHIKU) {
        this.CHIKU = CHIKU == null ? null : CHIKU.trim();
    }

    /**
     * 装置番号
     * @return DEV_NUM 装置番号
     */
    public String getDEV_NUM() {
        return DEV_NUM;
    }

    /**
     * 装置番号
     * @param DEV_NUM 装置番号
     */
    public void setDEV_NUM(String DEV_NUM) {
        this.DEV_NUM = DEV_NUM == null ? null : DEV_NUM.trim();
    }

    /**
     * 制御コマンドID
     * @return CTRL_CMD_ID 制御コマンドID
     */
    public String getCTRL_CMD_ID() {
        return CTRL_CMD_ID;
    }

    /**
     * 制御コマンドID
     * @param CTRL_CMD_ID 制御コマンドID
     */
    public void setCTRL_CMD_ID(String CTRL_CMD_ID) {
        this.CTRL_CMD_ID = CTRL_CMD_ID == null ? null : CTRL_CMD_ID.trim();
    }

    /**
     * 理由
     * @return REASON 理由
     */
    public String getREASON() {
        return REASON;
    }

    /**
     * 理由
     * @param REASON 理由
     */
    public void setREASON(String REASON) {
        this.REASON = REASON == null ? null : REASON.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}