package jp.co.alsok.g6.config;

import javax.sql.DataSource;

import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

/**
 * データソース設定。
 *
 * @author APL
 */
@Configuration
public class DataSourceConfig {

    // ==================COMM START====================

    /**
     * 一つ目のDBの設定。
     *
     * @return
     */
    @ConfigurationProperties(prefix = "spring.datasource.com")
    @Bean
    @Primary
    public DataSourceProperties datasourceProperties1() {
        return new DataSourceProperties();
    }

    /**
     * 一つ目のデータソース。
     *
     * @return
     */
    @Bean(name = { "com" })
    @Primary
    public DataSource dataSource1() {
        return datasourceProperties1().initializeDataSourceBuilder().build();
    }

    // ==================COMM END====================

    // ==================g6 START====================

    /**
     * 二つ目のDBの設定。
     *
     * @return
     */
    @ConfigurationProperties(prefix = "spring.datasource.g6")
    @Bean
    public DataSourceProperties datasourceProperties2() {
        return new DataSourceProperties();
    }

    /***
     * 二つ目のデータソース。
     *
     * @return
     */
    @Bean(name = { "g6" })
    public DataSource dataSource2() {
        return datasourceProperties2().initializeDataSourceBuilder().build();
    }

    // ==================g6 END====================

    // ==================ghs START====================
    /**
     * 三つ目のDBの設定。
     *
     * @return
     */
    @ConfigurationProperties(prefix = "spring.datasource.ghs")
    @Bean
    public DataSourceProperties datasourceProperties3() {
        return new DataSourceProperties();
    }

    /***
     * 三つ目のデータソース。
     *
     * @return
     */
    @Bean(name = { "ghs" })
    public DataSource dataSource3() {
        return datasourceProperties3().initializeDataSourceBuilder().build();
    }

    // ==================ghs END====================

    // ==================gv START====================

    /**
     * 四つ目のDBの設定。
     *
     * @return
     */
    @ConfigurationProperties(prefix = "spring.datasource.gv")
    @Bean
    public DataSourceProperties datasourceProperties4() {
        return new DataSourceProperties();
    }

    /***
     * 四つ目のデータソース。
     *
     * @return
     */
    @Bean(name = { "gv" })
    public DataSource dataSource4() {
        return datasourceProperties4().initializeDataSourceBuilder().build();
    }
    // ==================gv END====================

    // ==================img START====================

    /**
     * 五四つ目のDBの設定。
     *
     * @return
     */
    @ConfigurationProperties(prefix = "spring.datasource.img")
    @Bean
    public DataSourceProperties datasourceProperties5() {
        return new DataSourceProperties();
    }

    /***
     * 五つ目のデータソース。
     *
     * @return
     */
    @Bean(name = { "img" })
    public DataSource dataSource5() {
        return datasourceProperties5().initializeDataSourceBuilder().build();
    }

    // ==================img END====================

    // ==================rm START====================

    /**
     * 六つ目のDBの設定。
     *
     * @return
     */
    @ConfigurationProperties(prefix = "spring.datasource.rm")
    @Bean
    public DataSourceProperties datasourceProperties6() {
        return new DataSourceProperties();
    }

    /***
     * 六つ目のデータソース。
     *
     * @return
     */
    @Bean(name = { "rm" })
    public DataSource dataSource6() {
        return datasourceProperties6().initializeDataSourceBuilder().build();
    }

    // ==================rm START====================

    // /**
    // * 三つ目のDBの設定。
    // *
    // * @return
    // */
    // @ConfigurationProperties(prefix = "spring.datasource.db3")
    // @Bean
    // public DataSourceProperties datasourceProperties3() {
    // return new DataSourceProperties();
    // }
    //
    // /***
    // * 二つ目のデータソース。
    // *
    // * @return
    // */
    // @Bean
    // public DataSource dataSource3() {
    // return datasourceProperties3().initializeDataSourceBuilder().build();
    // }

    // @Bean
    // public DataSourceInitializer dataSource1Initializer() {
    // DataSourceInitializer dataSourceInitializer = new DataSourceInitializer();
    // dataSourceInitializer.setDataSource(dataSource1());
    // ResourceDatabasePopulator databasePopulator = new
    // ResourceDatabasePopulator();
    // Optional.ofNullable(dataSource1().getSchema()).map(schema ->
    // context.getResource(schema))
    // .ifPresent(resource -> databasePopulator.addScript(resource));
    // Optional.ofNullable(dataSource1().getData()).map(data ->
    // context.getResource(data))
    // .ifPresent(resource -> databasePopulator.addScript(resource));
    //
    // dataSourceInitializer.setDatabasePopulator(databasePopulator);
    // dataSourceInitializer.setEnabled(true);
    //
    // return dataSourceInitializer;
    // }
}
