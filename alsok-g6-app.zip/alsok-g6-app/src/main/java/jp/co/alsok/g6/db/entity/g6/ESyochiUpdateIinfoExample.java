package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ESyochiUpdateIinfoExample {
    /**
     * E_SYOCHI_UPDATE_IINFO
     */
    protected String orderByClause;

    /**
     * E_SYOCHI_UPDATE_IINFO
     */
    protected boolean distinct;

    /**
     * E_SYOCHI_UPDATE_IINFO
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public ESyochiUpdateIinfoExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * E_SYOCHI_UPDATE_IINFO null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andGC_NUMIsNull() {
            addCriterion("GC_NUM is null");
            return (Criteria) this;
        }

        public Criteria andGC_NUMIsNotNull() {
            addCriterion("GC_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andGC_NUMEqualTo(String value) {
            addCriterion("GC_NUM =", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMNotEqualTo(String value) {
            addCriterion("GC_NUM <>", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMGreaterThan(String value) {
            addCriterion("GC_NUM >", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("GC_NUM >=", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMLessThan(String value) {
            addCriterion("GC_NUM <", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMLessThanOrEqualTo(String value) {
            addCriterion("GC_NUM <=", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMLike(String value) {
            addCriterion("GC_NUM like", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMNotLike(String value) {
            addCriterion("GC_NUM not like", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMIn(List<String> values) {
            addCriterion("GC_NUM in", values, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMNotIn(List<String> values) {
            addCriterion("GC_NUM not in", values, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMBetween(String value1, String value2) {
            addCriterion("GC_NUM between", value1, value2, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMNotBetween(String value1, String value2) {
            addCriterion("GC_NUM not between", value1, value2, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_SGSIsNull() {
            addCriterion("LN_SGS is null");
            return (Criteria) this;
        }

        public Criteria andLN_SGSIsNotNull() {
            addCriterion("LN_SGS is not null");
            return (Criteria) this;
        }

        public Criteria andLN_SGSEqualTo(String value) {
            addCriterion("LN_SGS =", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSNotEqualTo(String value) {
            addCriterion("LN_SGS <>", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSGreaterThan(String value) {
            addCriterion("LN_SGS >", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSGreaterThanOrEqualTo(String value) {
            addCriterion("LN_SGS >=", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSLessThan(String value) {
            addCriterion("LN_SGS <", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSLessThanOrEqualTo(String value) {
            addCriterion("LN_SGS <=", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSLike(String value) {
            addCriterion("LN_SGS like", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSNotLike(String value) {
            addCriterion("LN_SGS not like", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSIn(List<String> values) {
            addCriterion("LN_SGS in", values, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSNotIn(List<String> values) {
            addCriterion("LN_SGS not in", values, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSBetween(String value1, String value2) {
            addCriterion("LN_SGS between", value1, value2, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSNotBetween(String value1, String value2) {
            addCriterion("LN_SGS not between", value1, value2, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSIsNull() {
            addCriterion("JIAN_HASSEI_TS is null");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSIsNotNull() {
            addCriterion("JIAN_HASSEI_TS is not null");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSEqualTo(String value) {
            addCriterion("JIAN_HASSEI_TS =", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSNotEqualTo(String value) {
            addCriterion("JIAN_HASSEI_TS <>", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSGreaterThan(String value) {
            addCriterion("JIAN_HASSEI_TS >", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSGreaterThanOrEqualTo(String value) {
            addCriterion("JIAN_HASSEI_TS >=", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSLessThan(String value) {
            addCriterion("JIAN_HASSEI_TS <", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSLessThanOrEqualTo(String value) {
            addCriterion("JIAN_HASSEI_TS <=", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSLike(String value) {
            addCriterion("JIAN_HASSEI_TS like", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSNotLike(String value) {
            addCriterion("JIAN_HASSEI_TS not like", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSIn(List<String> values) {
            addCriterion("JIAN_HASSEI_TS in", values, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSNotIn(List<String> values) {
            addCriterion("JIAN_HASSEI_TS not in", values, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSBetween(String value1, String value2) {
            addCriterion("JIAN_HASSEI_TS between", value1, value2, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSNotBetween(String value1, String value2) {
            addCriterion("JIAN_HASSEI_TS not between", value1, value2, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andKEKKAIsNull() {
            addCriterion("KEKKA is null");
            return (Criteria) this;
        }

        public Criteria andKEKKAIsNotNull() {
            addCriterion("KEKKA is not null");
            return (Criteria) this;
        }

        public Criteria andKEKKAEqualTo(String value) {
            addCriterion("KEKKA =", value, "KEKKA");
            return (Criteria) this;
        }

        public Criteria andKEKKANotEqualTo(String value) {
            addCriterion("KEKKA <>", value, "KEKKA");
            return (Criteria) this;
        }

        public Criteria andKEKKAGreaterThan(String value) {
            addCriterion("KEKKA >", value, "KEKKA");
            return (Criteria) this;
        }

        public Criteria andKEKKAGreaterThanOrEqualTo(String value) {
            addCriterion("KEKKA >=", value, "KEKKA");
            return (Criteria) this;
        }

        public Criteria andKEKKALessThan(String value) {
            addCriterion("KEKKA <", value, "KEKKA");
            return (Criteria) this;
        }

        public Criteria andKEKKALessThanOrEqualTo(String value) {
            addCriterion("KEKKA <=", value, "KEKKA");
            return (Criteria) this;
        }

        public Criteria andKEKKALike(String value) {
            addCriterion("KEKKA like", value, "KEKKA");
            return (Criteria) this;
        }

        public Criteria andKEKKANotLike(String value) {
            addCriterion("KEKKA not like", value, "KEKKA");
            return (Criteria) this;
        }

        public Criteria andKEKKAIn(List<String> values) {
            addCriterion("KEKKA in", values, "KEKKA");
            return (Criteria) this;
        }

        public Criteria andKEKKANotIn(List<String> values) {
            addCriterion("KEKKA not in", values, "KEKKA");
            return (Criteria) this;
        }

        public Criteria andKEKKABetween(String value1, String value2) {
            addCriterion("KEKKA between", value1, value2, "KEKKA");
            return (Criteria) this;
        }

        public Criteria andKEKKANotBetween(String value1, String value2) {
            addCriterion("KEKKA not between", value1, value2, "KEKKA");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLG_KIsNull() {
            addCriterion("COLOR_FLG_K is null");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLG_KIsNotNull() {
            addCriterion("COLOR_FLG_K is not null");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLG_KEqualTo(String value) {
            addCriterion("COLOR_FLG_K =", value, "COLOR_FLG_K");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLG_KNotEqualTo(String value) {
            addCriterion("COLOR_FLG_K <>", value, "COLOR_FLG_K");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLG_KGreaterThan(String value) {
            addCriterion("COLOR_FLG_K >", value, "COLOR_FLG_K");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLG_KGreaterThanOrEqualTo(String value) {
            addCriterion("COLOR_FLG_K >=", value, "COLOR_FLG_K");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLG_KLessThan(String value) {
            addCriterion("COLOR_FLG_K <", value, "COLOR_FLG_K");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLG_KLessThanOrEqualTo(String value) {
            addCriterion("COLOR_FLG_K <=", value, "COLOR_FLG_K");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLG_KLike(String value) {
            addCriterion("COLOR_FLG_K like", value, "COLOR_FLG_K");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLG_KNotLike(String value) {
            addCriterion("COLOR_FLG_K not like", value, "COLOR_FLG_K");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLG_KIn(List<String> values) {
            addCriterion("COLOR_FLG_K in", values, "COLOR_FLG_K");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLG_KNotIn(List<String> values) {
            addCriterion("COLOR_FLG_K not in", values, "COLOR_FLG_K");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLG_KBetween(String value1, String value2) {
            addCriterion("COLOR_FLG_K between", value1, value2, "COLOR_FLG_K");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLG_KNotBetween(String value1, String value2) {
            addCriterion("COLOR_FLG_K not between", value1, value2, "COLOR_FLG_K");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSIsNull() {
            addCriterion("LASTUPD_TS is null");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSIsNotNull() {
            addCriterion("LASTUPD_TS is not null");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSEqualTo(Date value) {
            addCriterion("LASTUPD_TS =", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSNotEqualTo(Date value) {
            addCriterion("LASTUPD_TS <>", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSGreaterThan(Date value) {
            addCriterion("LASTUPD_TS >", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("LASTUPD_TS >=", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSLessThan(Date value) {
            addCriterion("LASTUPD_TS <", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSLessThanOrEqualTo(Date value) {
            addCriterion("LASTUPD_TS <=", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSIn(List<Date> values) {
            addCriterion("LASTUPD_TS in", values, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSNotIn(List<Date> values) {
            addCriterion("LASTUPD_TS not in", values, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSBetween(Date value1, Date value2) {
            addCriterion("LASTUPD_TS between", value1, value2, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSNotBetween(Date value1, Date value2) {
            addCriterion("LASTUPD_TS not between", value1, value2, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andGC_NUMLikeInsensitive(String value) {
            addCriterion("upper(GC_NUM) like", value.toUpperCase(), "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_SGSLikeInsensitive(String value) {
            addCriterion("upper(LN_SGS) like", value.toUpperCase(), "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSLikeInsensitive(String value) {
            addCriterion("upper(JIAN_HASSEI_TS) like", value.toUpperCase(), "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andKEKKALikeInsensitive(String value) {
            addCriterion("upper(KEKKA) like", value.toUpperCase(), "KEKKA");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLG_KLikeInsensitive(String value) {
            addCriterion("upper(COLOR_FLG_K) like", value.toUpperCase(), "COLOR_FLG_K");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * E_SYOCHI_UPDATE_IINFO
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * E_SYOCHI_UPDATE_IINFO null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}