package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class HUserInfoReadLog implements Serializable {
    /**
     * LN_ユーザ情報読出履歴論理番号
     */
    private String LN_USER_INFO_READ_LOG;

    /**
     * LN_制御信号キュー論理番号
     */
    private String LN_QUE_CTRL_SIG;

    /**
     * LN_警備先論理番号
     */
    private String LN_KEIBI;

    /**
     * ユーザー情報種別
     */
    private String USERINF_KIND;

    /**
     * 見守り設定
     */
    private String MIMAMORI_TY;

    /**
     * 見守り設定時間
     */
    private String MIMAMORI_TM;

    /**
     * 定刻連絡時刻1
     */
    private String TEIKOKU_TM1;

    /**
     * 定刻連絡時刻2
     */
    private String TEIKOKU_TM2;

    /**
     * 定刻連絡時刻3
     */
    private String TEIKOKU_TM3;

    /**
     * 停止状態監視タイマ
     */
    private String TEISI_TM;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * H_USER_INFO_READ_LOG
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_ユーザ情報読出履歴論理番号
     * @return LN_USER_INFO_READ_LOG LN_ユーザ情報読出履歴論理番号
     */
    public String getLN_USER_INFO_READ_LOG() {
        return LN_USER_INFO_READ_LOG;
    }

    /**
     * LN_ユーザ情報読出履歴論理番号
     * @param LN_USER_INFO_READ_LOG LN_ユーザ情報読出履歴論理番号
     */
    public void setLN_USER_INFO_READ_LOG(String LN_USER_INFO_READ_LOG) {
        this.LN_USER_INFO_READ_LOG = LN_USER_INFO_READ_LOG == null ? null : LN_USER_INFO_READ_LOG.trim();
    }

    /**
     * LN_制御信号キュー論理番号
     * @return LN_QUE_CTRL_SIG LN_制御信号キュー論理番号
     */
    public String getLN_QUE_CTRL_SIG() {
        return LN_QUE_CTRL_SIG;
    }

    /**
     * LN_制御信号キュー論理番号
     * @param LN_QUE_CTRL_SIG LN_制御信号キュー論理番号
     */
    public void setLN_QUE_CTRL_SIG(String LN_QUE_CTRL_SIG) {
        this.LN_QUE_CTRL_SIG = LN_QUE_CTRL_SIG == null ? null : LN_QUE_CTRL_SIG.trim();
    }

    /**
     * LN_警備先論理番号
     * @return LN_KEIBI LN_警備先論理番号
     */
    public String getLN_KEIBI() {
        return LN_KEIBI;
    }

    /**
     * LN_警備先論理番号
     * @param LN_KEIBI LN_警備先論理番号
     */
    public void setLN_KEIBI(String LN_KEIBI) {
        this.LN_KEIBI = LN_KEIBI == null ? null : LN_KEIBI.trim();
    }

    /**
     * ユーザー情報種別
     * @return USERINF_KIND ユーザー情報種別
     */
    public String getUSERINF_KIND() {
        return USERINF_KIND;
    }

    /**
     * ユーザー情報種別
     * @param USERINF_KIND ユーザー情報種別
     */
    public void setUSERINF_KIND(String USERINF_KIND) {
        this.USERINF_KIND = USERINF_KIND == null ? null : USERINF_KIND.trim();
    }

    /**
     * 見守り設定
     * @return MIMAMORI_TY 見守り設定
     */
    public String getMIMAMORI_TY() {
        return MIMAMORI_TY;
    }

    /**
     * 見守り設定
     * @param MIMAMORI_TY 見守り設定
     */
    public void setMIMAMORI_TY(String MIMAMORI_TY) {
        this.MIMAMORI_TY = MIMAMORI_TY == null ? null : MIMAMORI_TY.trim();
    }

    /**
     * 見守り設定時間
     * @return MIMAMORI_TM 見守り設定時間
     */
    public String getMIMAMORI_TM() {
        return MIMAMORI_TM;
    }

    /**
     * 見守り設定時間
     * @param MIMAMORI_TM 見守り設定時間
     */
    public void setMIMAMORI_TM(String MIMAMORI_TM) {
        this.MIMAMORI_TM = MIMAMORI_TM == null ? null : MIMAMORI_TM.trim();
    }

    /**
     * 定刻連絡時刻1
     * @return TEIKOKU_TM1 定刻連絡時刻1
     */
    public String getTEIKOKU_TM1() {
        return TEIKOKU_TM1;
    }

    /**
     * 定刻連絡時刻1
     * @param TEIKOKU_TM1 定刻連絡時刻1
     */
    public void setTEIKOKU_TM1(String TEIKOKU_TM1) {
        this.TEIKOKU_TM1 = TEIKOKU_TM1 == null ? null : TEIKOKU_TM1.trim();
    }

    /**
     * 定刻連絡時刻2
     * @return TEIKOKU_TM2 定刻連絡時刻2
     */
    public String getTEIKOKU_TM2() {
        return TEIKOKU_TM2;
    }

    /**
     * 定刻連絡時刻2
     * @param TEIKOKU_TM2 定刻連絡時刻2
     */
    public void setTEIKOKU_TM2(String TEIKOKU_TM2) {
        this.TEIKOKU_TM2 = TEIKOKU_TM2 == null ? null : TEIKOKU_TM2.trim();
    }

    /**
     * 定刻連絡時刻3
     * @return TEIKOKU_TM3 定刻連絡時刻3
     */
    public String getTEIKOKU_TM3() {
        return TEIKOKU_TM3;
    }

    /**
     * 定刻連絡時刻3
     * @param TEIKOKU_TM3 定刻連絡時刻3
     */
    public void setTEIKOKU_TM3(String TEIKOKU_TM3) {
        this.TEIKOKU_TM3 = TEIKOKU_TM3 == null ? null : TEIKOKU_TM3.trim();
    }

    /**
     * 停止状態監視タイマ
     * @return TEISI_TM 停止状態監視タイマ
     */
    public String getTEISI_TM() {
        return TEISI_TM;
    }

    /**
     * 停止状態監視タイマ
     * @param TEISI_TM 停止状態監視タイマ
     */
    public void setTEISI_TM(String TEISI_TM) {
        this.TEISI_TM = TEISI_TM == null ? null : TEISI_TM.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}