package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class HRmckCmpDtl2 implements Serializable {
    /**
     * LN_遠隔点検結果履歴詳細2論理番号
     */
    private String LN_RMCK_CMP_DTL2;

    /**
     * LN_遠隔点検結果履歴論理番号
     */
    private String LN_RMCK_CMP;

    /**
     * カメラ番号
     */
    private String CAMR_NO;

    /**
     * ホワイトリスト検知
     */
    private String WLUP_ST;

    /**
     * ブラックリスト検知
     */
    private String BLUP_ST;

    /**
     * 顔認証リスト番号
     */
    private String LIST_NO;

    /**
     * カメラ画像異常行動(置去り)検出
     */
    private String CAMERAS1_ST;

    /**
     * カメラ画像異常行動(不審行動)検出
     */
    private String CAMERAS2_ST;

    /**
     * カメラ画像異常行動(うずくまり)検出
     */
    private String CAMERAS3_ST;

    /**
     * 画像ファイル名
     */
    private String VFILENM;

    /**
     * フレームレート
     */
    private String FL_RATE;

    /**
     * 画像記録時間
     */
    private String VR_TIME;

    /**
     * 画像記録枚数
     */
    private String VR_ACNT;

    /**
     * 撮像開始時間
     */
    private String VR_STRT;

    /**
     * 撮像枚数
     */
    private String VFCOUNT;

    /**
     * マイク・スピーカー連動フラグ
     */
    private String MCSP_LK;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * H_RMCK_CMP_DTL2
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_遠隔点検結果履歴詳細2論理番号
     * @return LN_RMCK_CMP_DTL2 LN_遠隔点検結果履歴詳細2論理番号
     */
    public String getLN_RMCK_CMP_DTL2() {
        return LN_RMCK_CMP_DTL2;
    }

    /**
     * LN_遠隔点検結果履歴詳細2論理番号
     * @param LN_RMCK_CMP_DTL2 LN_遠隔点検結果履歴詳細2論理番号
     */
    public void setLN_RMCK_CMP_DTL2(String LN_RMCK_CMP_DTL2) {
        this.LN_RMCK_CMP_DTL2 = LN_RMCK_CMP_DTL2 == null ? null : LN_RMCK_CMP_DTL2.trim();
    }

    /**
     * LN_遠隔点検結果履歴論理番号
     * @return LN_RMCK_CMP LN_遠隔点検結果履歴論理番号
     */
    public String getLN_RMCK_CMP() {
        return LN_RMCK_CMP;
    }

    /**
     * LN_遠隔点検結果履歴論理番号
     * @param LN_RMCK_CMP LN_遠隔点検結果履歴論理番号
     */
    public void setLN_RMCK_CMP(String LN_RMCK_CMP) {
        this.LN_RMCK_CMP = LN_RMCK_CMP == null ? null : LN_RMCK_CMP.trim();
    }

    /**
     * カメラ番号
     * @return CAMR_NO カメラ番号
     */
    public String getCAMR_NO() {
        return CAMR_NO;
    }

    /**
     * カメラ番号
     * @param CAMR_NO カメラ番号
     */
    public void setCAMR_NO(String CAMR_NO) {
        this.CAMR_NO = CAMR_NO == null ? null : CAMR_NO.trim();
    }

    /**
     * ホワイトリスト検知
     * @return WLUP_ST ホワイトリスト検知
     */
    public String getWLUP_ST() {
        return WLUP_ST;
    }

    /**
     * ホワイトリスト検知
     * @param WLUP_ST ホワイトリスト検知
     */
    public void setWLUP_ST(String WLUP_ST) {
        this.WLUP_ST = WLUP_ST == null ? null : WLUP_ST.trim();
    }

    /**
     * ブラックリスト検知
     * @return BLUP_ST ブラックリスト検知
     */
    public String getBLUP_ST() {
        return BLUP_ST;
    }

    /**
     * ブラックリスト検知
     * @param BLUP_ST ブラックリスト検知
     */
    public void setBLUP_ST(String BLUP_ST) {
        this.BLUP_ST = BLUP_ST == null ? null : BLUP_ST.trim();
    }

    /**
     * 顔認証リスト番号
     * @return LIST_NO 顔認証リスト番号
     */
    public String getLIST_NO() {
        return LIST_NO;
    }

    /**
     * 顔認証リスト番号
     * @param LIST_NO 顔認証リスト番号
     */
    public void setLIST_NO(String LIST_NO) {
        this.LIST_NO = LIST_NO == null ? null : LIST_NO.trim();
    }

    /**
     * カメラ画像異常行動(置去り)検出
     * @return CAMERAS1_ST カメラ画像異常行動(置去り)検出
     */
    public String getCAMERAS1_ST() {
        return CAMERAS1_ST;
    }

    /**
     * カメラ画像異常行動(置去り)検出
     * @param CAMERAS1_ST カメラ画像異常行動(置去り)検出
     */
    public void setCAMERAS1_ST(String CAMERAS1_ST) {
        this.CAMERAS1_ST = CAMERAS1_ST == null ? null : CAMERAS1_ST.trim();
    }

    /**
     * カメラ画像異常行動(不審行動)検出
     * @return CAMERAS2_ST カメラ画像異常行動(不審行動)検出
     */
    public String getCAMERAS2_ST() {
        return CAMERAS2_ST;
    }

    /**
     * カメラ画像異常行動(不審行動)検出
     * @param CAMERAS2_ST カメラ画像異常行動(不審行動)検出
     */
    public void setCAMERAS2_ST(String CAMERAS2_ST) {
        this.CAMERAS2_ST = CAMERAS2_ST == null ? null : CAMERAS2_ST.trim();
    }

    /**
     * カメラ画像異常行動(うずくまり)検出
     * @return CAMERAS3_ST カメラ画像異常行動(うずくまり)検出
     */
    public String getCAMERAS3_ST() {
        return CAMERAS3_ST;
    }

    /**
     * カメラ画像異常行動(うずくまり)検出
     * @param CAMERAS3_ST カメラ画像異常行動(うずくまり)検出
     */
    public void setCAMERAS3_ST(String CAMERAS3_ST) {
        this.CAMERAS3_ST = CAMERAS3_ST == null ? null : CAMERAS3_ST.trim();
    }

    /**
     * 画像ファイル名
     * @return VFILENM 画像ファイル名
     */
    public String getVFILENM() {
        return VFILENM;
    }

    /**
     * 画像ファイル名
     * @param VFILENM 画像ファイル名
     */
    public void setVFILENM(String VFILENM) {
        this.VFILENM = VFILENM == null ? null : VFILENM.trim();
    }

    /**
     * フレームレート
     * @return FL_RATE フレームレート
     */
    public String getFL_RATE() {
        return FL_RATE;
    }

    /**
     * フレームレート
     * @param FL_RATE フレームレート
     */
    public void setFL_RATE(String FL_RATE) {
        this.FL_RATE = FL_RATE == null ? null : FL_RATE.trim();
    }

    /**
     * 画像記録時間
     * @return VR_TIME 画像記録時間
     */
    public String getVR_TIME() {
        return VR_TIME;
    }

    /**
     * 画像記録時間
     * @param VR_TIME 画像記録時間
     */
    public void setVR_TIME(String VR_TIME) {
        this.VR_TIME = VR_TIME == null ? null : VR_TIME.trim();
    }

    /**
     * 画像記録枚数
     * @return VR_ACNT 画像記録枚数
     */
    public String getVR_ACNT() {
        return VR_ACNT;
    }

    /**
     * 画像記録枚数
     * @param VR_ACNT 画像記録枚数
     */
    public void setVR_ACNT(String VR_ACNT) {
        this.VR_ACNT = VR_ACNT == null ? null : VR_ACNT.trim();
    }

    /**
     * 撮像開始時間
     * @return VR_STRT 撮像開始時間
     */
    public String getVR_STRT() {
        return VR_STRT;
    }

    /**
     * 撮像開始時間
     * @param VR_STRT 撮像開始時間
     */
    public void setVR_STRT(String VR_STRT) {
        this.VR_STRT = VR_STRT == null ? null : VR_STRT.trim();
    }

    /**
     * 撮像枚数
     * @return VFCOUNT 撮像枚数
     */
    public String getVFCOUNT() {
        return VFCOUNT;
    }

    /**
     * 撮像枚数
     * @param VFCOUNT 撮像枚数
     */
    public void setVFCOUNT(String VFCOUNT) {
        this.VFCOUNT = VFCOUNT == null ? null : VFCOUNT.trim();
    }

    /**
     * マイク・スピーカー連動フラグ
     * @return MCSP_LK マイク・スピーカー連動フラグ
     */
    public String getMCSP_LK() {
        return MCSP_LK;
    }

    /**
     * マイク・スピーカー連動フラグ
     * @param MCSP_LK マイク・スピーカー連動フラグ
     */
    public void setMCSP_LK(String MCSP_LK) {
        this.MCSP_LK = MCSP_LK == null ? null : MCSP_LK.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}