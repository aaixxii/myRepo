package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EMemoExample {
    /**
     * E_MEMO
     */
    protected String orderByClause;

    /**
     * E_MEMO
     */
    protected boolean distinct;

    /**
     * E_MEMO
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public EMemoExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * E_MEMO null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_E_MEMOIsNull() {
            addCriterion("LN_E_MEMO is null");
            return (Criteria) this;
        }

        public Criteria andLN_E_MEMOIsNotNull() {
            addCriterion("LN_E_MEMO is not null");
            return (Criteria) this;
        }

        public Criteria andLN_E_MEMOEqualTo(String value) {
            addCriterion("LN_E_MEMO =", value, "LN_E_MEMO");
            return (Criteria) this;
        }

        public Criteria andLN_E_MEMONotEqualTo(String value) {
            addCriterion("LN_E_MEMO <>", value, "LN_E_MEMO");
            return (Criteria) this;
        }

        public Criteria andLN_E_MEMOGreaterThan(String value) {
            addCriterion("LN_E_MEMO >", value, "LN_E_MEMO");
            return (Criteria) this;
        }

        public Criteria andLN_E_MEMOGreaterThanOrEqualTo(String value) {
            addCriterion("LN_E_MEMO >=", value, "LN_E_MEMO");
            return (Criteria) this;
        }

        public Criteria andLN_E_MEMOLessThan(String value) {
            addCriterion("LN_E_MEMO <", value, "LN_E_MEMO");
            return (Criteria) this;
        }

        public Criteria andLN_E_MEMOLessThanOrEqualTo(String value) {
            addCriterion("LN_E_MEMO <=", value, "LN_E_MEMO");
            return (Criteria) this;
        }

        public Criteria andLN_E_MEMOLike(String value) {
            addCriterion("LN_E_MEMO like", value, "LN_E_MEMO");
            return (Criteria) this;
        }

        public Criteria andLN_E_MEMONotLike(String value) {
            addCriterion("LN_E_MEMO not like", value, "LN_E_MEMO");
            return (Criteria) this;
        }

        public Criteria andLN_E_MEMOIn(List<String> values) {
            addCriterion("LN_E_MEMO in", values, "LN_E_MEMO");
            return (Criteria) this;
        }

        public Criteria andLN_E_MEMONotIn(List<String> values) {
            addCriterion("LN_E_MEMO not in", values, "LN_E_MEMO");
            return (Criteria) this;
        }

        public Criteria andLN_E_MEMOBetween(String value1, String value2) {
            addCriterion("LN_E_MEMO between", value1, value2, "LN_E_MEMO");
            return (Criteria) this;
        }

        public Criteria andLN_E_MEMONotBetween(String value1, String value2) {
            addCriterion("LN_E_MEMO not between", value1, value2, "LN_E_MEMO");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUIsNull() {
            addCriterion("LN_KB_CHIKU is null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUIsNotNull() {
            addCriterion("LN_KB_CHIKU is not null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUEqualTo(String value) {
            addCriterion("LN_KB_CHIKU =", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUNotEqualTo(String value) {
            addCriterion("LN_KB_CHIKU <>", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUGreaterThan(String value) {
            addCriterion("LN_KB_CHIKU >", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUGreaterThanOrEqualTo(String value) {
            addCriterion("LN_KB_CHIKU >=", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKULessThan(String value) {
            addCriterion("LN_KB_CHIKU <", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKULessThanOrEqualTo(String value) {
            addCriterion("LN_KB_CHIKU <=", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKULike(String value) {
            addCriterion("LN_KB_CHIKU like", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUNotLike(String value) {
            addCriterion("LN_KB_CHIKU not like", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUIn(List<String> values) {
            addCriterion("LN_KB_CHIKU in", values, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUNotIn(List<String> values) {
            addCriterion("LN_KB_CHIKU not in", values, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUBetween(String value1, String value2) {
            addCriterion("LN_KB_CHIKU between", value1, value2, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUNotBetween(String value1, String value2) {
            addCriterion("LN_KB_CHIKU not between", value1, value2, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andYOUTO_IDIsNull() {
            addCriterion("YOUTO_ID is null");
            return (Criteria) this;
        }

        public Criteria andYOUTO_IDIsNotNull() {
            addCriterion("YOUTO_ID is not null");
            return (Criteria) this;
        }

        public Criteria andYOUTO_IDEqualTo(String value) {
            addCriterion("YOUTO_ID =", value, "YOUTO_ID");
            return (Criteria) this;
        }

        public Criteria andYOUTO_IDNotEqualTo(String value) {
            addCriterion("YOUTO_ID <>", value, "YOUTO_ID");
            return (Criteria) this;
        }

        public Criteria andYOUTO_IDGreaterThan(String value) {
            addCriterion("YOUTO_ID >", value, "YOUTO_ID");
            return (Criteria) this;
        }

        public Criteria andYOUTO_IDGreaterThanOrEqualTo(String value) {
            addCriterion("YOUTO_ID >=", value, "YOUTO_ID");
            return (Criteria) this;
        }

        public Criteria andYOUTO_IDLessThan(String value) {
            addCriterion("YOUTO_ID <", value, "YOUTO_ID");
            return (Criteria) this;
        }

        public Criteria andYOUTO_IDLessThanOrEqualTo(String value) {
            addCriterion("YOUTO_ID <=", value, "YOUTO_ID");
            return (Criteria) this;
        }

        public Criteria andYOUTO_IDLike(String value) {
            addCriterion("YOUTO_ID like", value, "YOUTO_ID");
            return (Criteria) this;
        }

        public Criteria andYOUTO_IDNotLike(String value) {
            addCriterion("YOUTO_ID not like", value, "YOUTO_ID");
            return (Criteria) this;
        }

        public Criteria andYOUTO_IDIn(List<String> values) {
            addCriterion("YOUTO_ID in", values, "YOUTO_ID");
            return (Criteria) this;
        }

        public Criteria andYOUTO_IDNotIn(List<String> values) {
            addCriterion("YOUTO_ID not in", values, "YOUTO_ID");
            return (Criteria) this;
        }

        public Criteria andYOUTO_IDBetween(String value1, String value2) {
            addCriterion("YOUTO_ID between", value1, value2, "YOUTO_ID");
            return (Criteria) this;
        }

        public Criteria andYOUTO_IDNotBetween(String value1, String value2) {
            addCriterion("YOUTO_ID not between", value1, value2, "YOUTO_ID");
            return (Criteria) this;
        }

        public Criteria andSYOCHI_KBNIsNull() {
            addCriterion("SYOCHI_KBN is null");
            return (Criteria) this;
        }

        public Criteria andSYOCHI_KBNIsNotNull() {
            addCriterion("SYOCHI_KBN is not null");
            return (Criteria) this;
        }

        public Criteria andSYOCHI_KBNEqualTo(String value) {
            addCriterion("SYOCHI_KBN =", value, "SYOCHI_KBN");
            return (Criteria) this;
        }

        public Criteria andSYOCHI_KBNNotEqualTo(String value) {
            addCriterion("SYOCHI_KBN <>", value, "SYOCHI_KBN");
            return (Criteria) this;
        }

        public Criteria andSYOCHI_KBNGreaterThan(String value) {
            addCriterion("SYOCHI_KBN >", value, "SYOCHI_KBN");
            return (Criteria) this;
        }

        public Criteria andSYOCHI_KBNGreaterThanOrEqualTo(String value) {
            addCriterion("SYOCHI_KBN >=", value, "SYOCHI_KBN");
            return (Criteria) this;
        }

        public Criteria andSYOCHI_KBNLessThan(String value) {
            addCriterion("SYOCHI_KBN <", value, "SYOCHI_KBN");
            return (Criteria) this;
        }

        public Criteria andSYOCHI_KBNLessThanOrEqualTo(String value) {
            addCriterion("SYOCHI_KBN <=", value, "SYOCHI_KBN");
            return (Criteria) this;
        }

        public Criteria andSYOCHI_KBNLike(String value) {
            addCriterion("SYOCHI_KBN like", value, "SYOCHI_KBN");
            return (Criteria) this;
        }

        public Criteria andSYOCHI_KBNNotLike(String value) {
            addCriterion("SYOCHI_KBN not like", value, "SYOCHI_KBN");
            return (Criteria) this;
        }

        public Criteria andSYOCHI_KBNIn(List<String> values) {
            addCriterion("SYOCHI_KBN in", values, "SYOCHI_KBN");
            return (Criteria) this;
        }

        public Criteria andSYOCHI_KBNNotIn(List<String> values) {
            addCriterion("SYOCHI_KBN not in", values, "SYOCHI_KBN");
            return (Criteria) this;
        }

        public Criteria andSYOCHI_KBNBetween(String value1, String value2) {
            addCriterion("SYOCHI_KBN between", value1, value2, "SYOCHI_KBN");
            return (Criteria) this;
        }

        public Criteria andSYOCHI_KBNNotBetween(String value1, String value2) {
            addCriterion("SYOCHI_KBN not between", value1, value2, "SYOCHI_KBN");
            return (Criteria) this;
        }

        public Criteria andST_TSIsNull() {
            addCriterion("ST_TS is null");
            return (Criteria) this;
        }

        public Criteria andST_TSIsNotNull() {
            addCriterion("ST_TS is not null");
            return (Criteria) this;
        }

        public Criteria andST_TSEqualTo(Date value) {
            addCriterion("ST_TS =", value, "ST_TS");
            return (Criteria) this;
        }

        public Criteria andST_TSNotEqualTo(Date value) {
            addCriterion("ST_TS <>", value, "ST_TS");
            return (Criteria) this;
        }

        public Criteria andST_TSGreaterThan(Date value) {
            addCriterion("ST_TS >", value, "ST_TS");
            return (Criteria) this;
        }

        public Criteria andST_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("ST_TS >=", value, "ST_TS");
            return (Criteria) this;
        }

        public Criteria andST_TSLessThan(Date value) {
            addCriterion("ST_TS <", value, "ST_TS");
            return (Criteria) this;
        }

        public Criteria andST_TSLessThanOrEqualTo(Date value) {
            addCriterion("ST_TS <=", value, "ST_TS");
            return (Criteria) this;
        }

        public Criteria andST_TSIn(List<Date> values) {
            addCriterion("ST_TS in", values, "ST_TS");
            return (Criteria) this;
        }

        public Criteria andST_TSNotIn(List<Date> values) {
            addCriterion("ST_TS not in", values, "ST_TS");
            return (Criteria) this;
        }

        public Criteria andST_TSBetween(Date value1, Date value2) {
            addCriterion("ST_TS between", value1, value2, "ST_TS");
            return (Criteria) this;
        }

        public Criteria andST_TSNotBetween(Date value1, Date value2) {
            addCriterion("ST_TS not between", value1, value2, "ST_TS");
            return (Criteria) this;
        }

        public Criteria andED_TSIsNull() {
            addCriterion("ED_TS is null");
            return (Criteria) this;
        }

        public Criteria andED_TSIsNotNull() {
            addCriterion("ED_TS is not null");
            return (Criteria) this;
        }

        public Criteria andED_TSEqualTo(Date value) {
            addCriterion("ED_TS =", value, "ED_TS");
            return (Criteria) this;
        }

        public Criteria andED_TSNotEqualTo(Date value) {
            addCriterion("ED_TS <>", value, "ED_TS");
            return (Criteria) this;
        }

        public Criteria andED_TSGreaterThan(Date value) {
            addCriterion("ED_TS >", value, "ED_TS");
            return (Criteria) this;
        }

        public Criteria andED_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("ED_TS >=", value, "ED_TS");
            return (Criteria) this;
        }

        public Criteria andED_TSLessThan(Date value) {
            addCriterion("ED_TS <", value, "ED_TS");
            return (Criteria) this;
        }

        public Criteria andED_TSLessThanOrEqualTo(Date value) {
            addCriterion("ED_TS <=", value, "ED_TS");
            return (Criteria) this;
        }

        public Criteria andED_TSIn(List<Date> values) {
            addCriterion("ED_TS in", values, "ED_TS");
            return (Criteria) this;
        }

        public Criteria andED_TSNotIn(List<Date> values) {
            addCriterion("ED_TS not in", values, "ED_TS");
            return (Criteria) this;
        }

        public Criteria andED_TSBetween(Date value1, Date value2) {
            addCriterion("ED_TS between", value1, value2, "ED_TS");
            return (Criteria) this;
        }

        public Criteria andED_TSNotBetween(Date value1, Date value2) {
            addCriterion("ED_TS not between", value1, value2, "ED_TS");
            return (Criteria) this;
        }

        public Criteria andED_YOTEI_TSIsNull() {
            addCriterion("ED_YOTEI_TS is null");
            return (Criteria) this;
        }

        public Criteria andED_YOTEI_TSIsNotNull() {
            addCriterion("ED_YOTEI_TS is not null");
            return (Criteria) this;
        }

        public Criteria andED_YOTEI_TSEqualTo(Date value) {
            addCriterion("ED_YOTEI_TS =", value, "ED_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andED_YOTEI_TSNotEqualTo(Date value) {
            addCriterion("ED_YOTEI_TS <>", value, "ED_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andED_YOTEI_TSGreaterThan(Date value) {
            addCriterion("ED_YOTEI_TS >", value, "ED_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andED_YOTEI_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("ED_YOTEI_TS >=", value, "ED_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andED_YOTEI_TSLessThan(Date value) {
            addCriterion("ED_YOTEI_TS <", value, "ED_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andED_YOTEI_TSLessThanOrEqualTo(Date value) {
            addCriterion("ED_YOTEI_TS <=", value, "ED_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andED_YOTEI_TSIn(List<Date> values) {
            addCriterion("ED_YOTEI_TS in", values, "ED_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andED_YOTEI_TSNotIn(List<Date> values) {
            addCriterion("ED_YOTEI_TS not in", values, "ED_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andED_YOTEI_TSBetween(Date value1, Date value2) {
            addCriterion("ED_YOTEI_TS between", value1, value2, "ED_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andED_YOTEI_TSNotBetween(Date value1, Date value2) {
            addCriterion("ED_YOTEI_TS not between", value1, value2, "ED_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_NMIsNull() {
            addCriterion("PEOPLE_NM is null");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_NMIsNotNull() {
            addCriterion("PEOPLE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_NMEqualTo(String value) {
            addCriterion("PEOPLE_NM =", value, "PEOPLE_NM");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_NMNotEqualTo(String value) {
            addCriterion("PEOPLE_NM <>", value, "PEOPLE_NM");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_NMGreaterThan(String value) {
            addCriterion("PEOPLE_NM >", value, "PEOPLE_NM");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("PEOPLE_NM >=", value, "PEOPLE_NM");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_NMLessThan(String value) {
            addCriterion("PEOPLE_NM <", value, "PEOPLE_NM");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_NMLessThanOrEqualTo(String value) {
            addCriterion("PEOPLE_NM <=", value, "PEOPLE_NM");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_NMLike(String value) {
            addCriterion("PEOPLE_NM like", value, "PEOPLE_NM");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_NMNotLike(String value) {
            addCriterion("PEOPLE_NM not like", value, "PEOPLE_NM");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_NMIn(List<String> values) {
            addCriterion("PEOPLE_NM in", values, "PEOPLE_NM");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_NMNotIn(List<String> values) {
            addCriterion("PEOPLE_NM not in", values, "PEOPLE_NM");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_NMBetween(String value1, String value2) {
            addCriterion("PEOPLE_NM between", value1, value2, "PEOPLE_NM");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_NMNotBetween(String value1, String value2) {
            addCriterion("PEOPLE_NM not between", value1, value2, "PEOPLE_NM");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_CNTIsNull() {
            addCriterion("PEOPLE_CNT is null");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_CNTIsNotNull() {
            addCriterion("PEOPLE_CNT is not null");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_CNTEqualTo(String value) {
            addCriterion("PEOPLE_CNT =", value, "PEOPLE_CNT");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_CNTNotEqualTo(String value) {
            addCriterion("PEOPLE_CNT <>", value, "PEOPLE_CNT");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_CNTGreaterThan(String value) {
            addCriterion("PEOPLE_CNT >", value, "PEOPLE_CNT");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_CNTGreaterThanOrEqualTo(String value) {
            addCriterion("PEOPLE_CNT >=", value, "PEOPLE_CNT");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_CNTLessThan(String value) {
            addCriterion("PEOPLE_CNT <", value, "PEOPLE_CNT");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_CNTLessThanOrEqualTo(String value) {
            addCriterion("PEOPLE_CNT <=", value, "PEOPLE_CNT");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_CNTLike(String value) {
            addCriterion("PEOPLE_CNT like", value, "PEOPLE_CNT");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_CNTNotLike(String value) {
            addCriterion("PEOPLE_CNT not like", value, "PEOPLE_CNT");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_CNTIn(List<String> values) {
            addCriterion("PEOPLE_CNT in", values, "PEOPLE_CNT");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_CNTNotIn(List<String> values) {
            addCriterion("PEOPLE_CNT not in", values, "PEOPLE_CNT");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_CNTBetween(String value1, String value2) {
            addCriterion("PEOPLE_CNT between", value1, value2, "PEOPLE_CNT");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_CNTNotBetween(String value1, String value2) {
            addCriterion("PEOPLE_CNT not between", value1, value2, "PEOPLE_CNT");
            return (Criteria) this;
        }

        public Criteria andTEL_NUMIsNull() {
            addCriterion("TEL_NUM is null");
            return (Criteria) this;
        }

        public Criteria andTEL_NUMIsNotNull() {
            addCriterion("TEL_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andTEL_NUMEqualTo(String value) {
            addCriterion("TEL_NUM =", value, "TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andTEL_NUMNotEqualTo(String value) {
            addCriterion("TEL_NUM <>", value, "TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andTEL_NUMGreaterThan(String value) {
            addCriterion("TEL_NUM >", value, "TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andTEL_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("TEL_NUM >=", value, "TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andTEL_NUMLessThan(String value) {
            addCriterion("TEL_NUM <", value, "TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andTEL_NUMLessThanOrEqualTo(String value) {
            addCriterion("TEL_NUM <=", value, "TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andTEL_NUMLike(String value) {
            addCriterion("TEL_NUM like", value, "TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andTEL_NUMNotLike(String value) {
            addCriterion("TEL_NUM not like", value, "TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andTEL_NUMIn(List<String> values) {
            addCriterion("TEL_NUM in", values, "TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andTEL_NUMNotIn(List<String> values) {
            addCriterion("TEL_NUM not in", values, "TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andTEL_NUMBetween(String value1, String value2) {
            addCriterion("TEL_NUM between", value1, value2, "TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andTEL_NUMNotBetween(String value1, String value2) {
            addCriterion("TEL_NUM not between", value1, value2, "TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU11IsNull() {
            addCriterion("MEMO_NAIYOU11 is null");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU11IsNotNull() {
            addCriterion("MEMO_NAIYOU11 is not null");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU11EqualTo(String value) {
            addCriterion("MEMO_NAIYOU11 =", value, "MEMO_NAIYOU11");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU11NotEqualTo(String value) {
            addCriterion("MEMO_NAIYOU11 <>", value, "MEMO_NAIYOU11");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU11GreaterThan(String value) {
            addCriterion("MEMO_NAIYOU11 >", value, "MEMO_NAIYOU11");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU11GreaterThanOrEqualTo(String value) {
            addCriterion("MEMO_NAIYOU11 >=", value, "MEMO_NAIYOU11");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU11LessThan(String value) {
            addCriterion("MEMO_NAIYOU11 <", value, "MEMO_NAIYOU11");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU11LessThanOrEqualTo(String value) {
            addCriterion("MEMO_NAIYOU11 <=", value, "MEMO_NAIYOU11");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU11Like(String value) {
            addCriterion("MEMO_NAIYOU11 like", value, "MEMO_NAIYOU11");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU11NotLike(String value) {
            addCriterion("MEMO_NAIYOU11 not like", value, "MEMO_NAIYOU11");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU11In(List<String> values) {
            addCriterion("MEMO_NAIYOU11 in", values, "MEMO_NAIYOU11");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU11NotIn(List<String> values) {
            addCriterion("MEMO_NAIYOU11 not in", values, "MEMO_NAIYOU11");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU11Between(String value1, String value2) {
            addCriterion("MEMO_NAIYOU11 between", value1, value2, "MEMO_NAIYOU11");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU11NotBetween(String value1, String value2) {
            addCriterion("MEMO_NAIYOU11 not between", value1, value2, "MEMO_NAIYOU11");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU12IsNull() {
            addCriterion("MEMO_NAIYOU12 is null");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU12IsNotNull() {
            addCriterion("MEMO_NAIYOU12 is not null");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU12EqualTo(String value) {
            addCriterion("MEMO_NAIYOU12 =", value, "MEMO_NAIYOU12");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU12NotEqualTo(String value) {
            addCriterion("MEMO_NAIYOU12 <>", value, "MEMO_NAIYOU12");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU12GreaterThan(String value) {
            addCriterion("MEMO_NAIYOU12 >", value, "MEMO_NAIYOU12");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU12GreaterThanOrEqualTo(String value) {
            addCriterion("MEMO_NAIYOU12 >=", value, "MEMO_NAIYOU12");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU12LessThan(String value) {
            addCriterion("MEMO_NAIYOU12 <", value, "MEMO_NAIYOU12");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU12LessThanOrEqualTo(String value) {
            addCriterion("MEMO_NAIYOU12 <=", value, "MEMO_NAIYOU12");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU12Like(String value) {
            addCriterion("MEMO_NAIYOU12 like", value, "MEMO_NAIYOU12");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU12NotLike(String value) {
            addCriterion("MEMO_NAIYOU12 not like", value, "MEMO_NAIYOU12");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU12In(List<String> values) {
            addCriterion("MEMO_NAIYOU12 in", values, "MEMO_NAIYOU12");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU12NotIn(List<String> values) {
            addCriterion("MEMO_NAIYOU12 not in", values, "MEMO_NAIYOU12");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU12Between(String value1, String value2) {
            addCriterion("MEMO_NAIYOU12 between", value1, value2, "MEMO_NAIYOU12");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU12NotBetween(String value1, String value2) {
            addCriterion("MEMO_NAIYOU12 not between", value1, value2, "MEMO_NAIYOU12");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU13IsNull() {
            addCriterion("MEMO_NAIYOU13 is null");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU13IsNotNull() {
            addCriterion("MEMO_NAIYOU13 is not null");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU13EqualTo(String value) {
            addCriterion("MEMO_NAIYOU13 =", value, "MEMO_NAIYOU13");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU13NotEqualTo(String value) {
            addCriterion("MEMO_NAIYOU13 <>", value, "MEMO_NAIYOU13");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU13GreaterThan(String value) {
            addCriterion("MEMO_NAIYOU13 >", value, "MEMO_NAIYOU13");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU13GreaterThanOrEqualTo(String value) {
            addCriterion("MEMO_NAIYOU13 >=", value, "MEMO_NAIYOU13");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU13LessThan(String value) {
            addCriterion("MEMO_NAIYOU13 <", value, "MEMO_NAIYOU13");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU13LessThanOrEqualTo(String value) {
            addCriterion("MEMO_NAIYOU13 <=", value, "MEMO_NAIYOU13");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU13Like(String value) {
            addCriterion("MEMO_NAIYOU13 like", value, "MEMO_NAIYOU13");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU13NotLike(String value) {
            addCriterion("MEMO_NAIYOU13 not like", value, "MEMO_NAIYOU13");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU13In(List<String> values) {
            addCriterion("MEMO_NAIYOU13 in", values, "MEMO_NAIYOU13");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU13NotIn(List<String> values) {
            addCriterion("MEMO_NAIYOU13 not in", values, "MEMO_NAIYOU13");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU13Between(String value1, String value2) {
            addCriterion("MEMO_NAIYOU13 between", value1, value2, "MEMO_NAIYOU13");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU13NotBetween(String value1, String value2) {
            addCriterion("MEMO_NAIYOU13 not between", value1, value2, "MEMO_NAIYOU13");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU21IsNull() {
            addCriterion("MEMO_NAIYOU21 is null");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU21IsNotNull() {
            addCriterion("MEMO_NAIYOU21 is not null");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU21EqualTo(String value) {
            addCriterion("MEMO_NAIYOU21 =", value, "MEMO_NAIYOU21");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU21NotEqualTo(String value) {
            addCriterion("MEMO_NAIYOU21 <>", value, "MEMO_NAIYOU21");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU21GreaterThan(String value) {
            addCriterion("MEMO_NAIYOU21 >", value, "MEMO_NAIYOU21");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU21GreaterThanOrEqualTo(String value) {
            addCriterion("MEMO_NAIYOU21 >=", value, "MEMO_NAIYOU21");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU21LessThan(String value) {
            addCriterion("MEMO_NAIYOU21 <", value, "MEMO_NAIYOU21");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU21LessThanOrEqualTo(String value) {
            addCriterion("MEMO_NAIYOU21 <=", value, "MEMO_NAIYOU21");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU21Like(String value) {
            addCriterion("MEMO_NAIYOU21 like", value, "MEMO_NAIYOU21");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU21NotLike(String value) {
            addCriterion("MEMO_NAIYOU21 not like", value, "MEMO_NAIYOU21");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU21In(List<String> values) {
            addCriterion("MEMO_NAIYOU21 in", values, "MEMO_NAIYOU21");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU21NotIn(List<String> values) {
            addCriterion("MEMO_NAIYOU21 not in", values, "MEMO_NAIYOU21");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU21Between(String value1, String value2) {
            addCriterion("MEMO_NAIYOU21 between", value1, value2, "MEMO_NAIYOU21");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU21NotBetween(String value1, String value2) {
            addCriterion("MEMO_NAIYOU21 not between", value1, value2, "MEMO_NAIYOU21");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU22IsNull() {
            addCriterion("MEMO_NAIYOU22 is null");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU22IsNotNull() {
            addCriterion("MEMO_NAIYOU22 is not null");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU22EqualTo(String value) {
            addCriterion("MEMO_NAIYOU22 =", value, "MEMO_NAIYOU22");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU22NotEqualTo(String value) {
            addCriterion("MEMO_NAIYOU22 <>", value, "MEMO_NAIYOU22");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU22GreaterThan(String value) {
            addCriterion("MEMO_NAIYOU22 >", value, "MEMO_NAIYOU22");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU22GreaterThanOrEqualTo(String value) {
            addCriterion("MEMO_NAIYOU22 >=", value, "MEMO_NAIYOU22");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU22LessThan(String value) {
            addCriterion("MEMO_NAIYOU22 <", value, "MEMO_NAIYOU22");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU22LessThanOrEqualTo(String value) {
            addCriterion("MEMO_NAIYOU22 <=", value, "MEMO_NAIYOU22");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU22Like(String value) {
            addCriterion("MEMO_NAIYOU22 like", value, "MEMO_NAIYOU22");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU22NotLike(String value) {
            addCriterion("MEMO_NAIYOU22 not like", value, "MEMO_NAIYOU22");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU22In(List<String> values) {
            addCriterion("MEMO_NAIYOU22 in", values, "MEMO_NAIYOU22");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU22NotIn(List<String> values) {
            addCriterion("MEMO_NAIYOU22 not in", values, "MEMO_NAIYOU22");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU22Between(String value1, String value2) {
            addCriterion("MEMO_NAIYOU22 between", value1, value2, "MEMO_NAIYOU22");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU22NotBetween(String value1, String value2) {
            addCriterion("MEMO_NAIYOU22 not between", value1, value2, "MEMO_NAIYOU22");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU23IsNull() {
            addCriterion("MEMO_NAIYOU23 is null");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU23IsNotNull() {
            addCriterion("MEMO_NAIYOU23 is not null");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU23EqualTo(String value) {
            addCriterion("MEMO_NAIYOU23 =", value, "MEMO_NAIYOU23");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU23NotEqualTo(String value) {
            addCriterion("MEMO_NAIYOU23 <>", value, "MEMO_NAIYOU23");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU23GreaterThan(String value) {
            addCriterion("MEMO_NAIYOU23 >", value, "MEMO_NAIYOU23");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU23GreaterThanOrEqualTo(String value) {
            addCriterion("MEMO_NAIYOU23 >=", value, "MEMO_NAIYOU23");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU23LessThan(String value) {
            addCriterion("MEMO_NAIYOU23 <", value, "MEMO_NAIYOU23");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU23LessThanOrEqualTo(String value) {
            addCriterion("MEMO_NAIYOU23 <=", value, "MEMO_NAIYOU23");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU23Like(String value) {
            addCriterion("MEMO_NAIYOU23 like", value, "MEMO_NAIYOU23");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU23NotLike(String value) {
            addCriterion("MEMO_NAIYOU23 not like", value, "MEMO_NAIYOU23");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU23In(List<String> values) {
            addCriterion("MEMO_NAIYOU23 in", values, "MEMO_NAIYOU23");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU23NotIn(List<String> values) {
            addCriterion("MEMO_NAIYOU23 not in", values, "MEMO_NAIYOU23");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU23Between(String value1, String value2) {
            addCriterion("MEMO_NAIYOU23 between", value1, value2, "MEMO_NAIYOU23");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU23NotBetween(String value1, String value2) {
            addCriterion("MEMO_NAIYOU23 not between", value1, value2, "MEMO_NAIYOU23");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU24IsNull() {
            addCriterion("MEMO_NAIYOU24 is null");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU24IsNotNull() {
            addCriterion("MEMO_NAIYOU24 is not null");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU24EqualTo(String value) {
            addCriterion("MEMO_NAIYOU24 =", value, "MEMO_NAIYOU24");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU24NotEqualTo(String value) {
            addCriterion("MEMO_NAIYOU24 <>", value, "MEMO_NAIYOU24");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU24GreaterThan(String value) {
            addCriterion("MEMO_NAIYOU24 >", value, "MEMO_NAIYOU24");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU24GreaterThanOrEqualTo(String value) {
            addCriterion("MEMO_NAIYOU24 >=", value, "MEMO_NAIYOU24");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU24LessThan(String value) {
            addCriterion("MEMO_NAIYOU24 <", value, "MEMO_NAIYOU24");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU24LessThanOrEqualTo(String value) {
            addCriterion("MEMO_NAIYOU24 <=", value, "MEMO_NAIYOU24");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU24Like(String value) {
            addCriterion("MEMO_NAIYOU24 like", value, "MEMO_NAIYOU24");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU24NotLike(String value) {
            addCriterion("MEMO_NAIYOU24 not like", value, "MEMO_NAIYOU24");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU24In(List<String> values) {
            addCriterion("MEMO_NAIYOU24 in", values, "MEMO_NAIYOU24");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU24NotIn(List<String> values) {
            addCriterion("MEMO_NAIYOU24 not in", values, "MEMO_NAIYOU24");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU24Between(String value1, String value2) {
            addCriterion("MEMO_NAIYOU24 between", value1, value2, "MEMO_NAIYOU24");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU24NotBetween(String value1, String value2) {
            addCriterion("MEMO_NAIYOU24 not between", value1, value2, "MEMO_NAIYOU24");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU25IsNull() {
            addCriterion("MEMO_NAIYOU25 is null");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU25IsNotNull() {
            addCriterion("MEMO_NAIYOU25 is not null");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU25EqualTo(String value) {
            addCriterion("MEMO_NAIYOU25 =", value, "MEMO_NAIYOU25");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU25NotEqualTo(String value) {
            addCriterion("MEMO_NAIYOU25 <>", value, "MEMO_NAIYOU25");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU25GreaterThan(String value) {
            addCriterion("MEMO_NAIYOU25 >", value, "MEMO_NAIYOU25");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU25GreaterThanOrEqualTo(String value) {
            addCriterion("MEMO_NAIYOU25 >=", value, "MEMO_NAIYOU25");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU25LessThan(String value) {
            addCriterion("MEMO_NAIYOU25 <", value, "MEMO_NAIYOU25");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU25LessThanOrEqualTo(String value) {
            addCriterion("MEMO_NAIYOU25 <=", value, "MEMO_NAIYOU25");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU25Like(String value) {
            addCriterion("MEMO_NAIYOU25 like", value, "MEMO_NAIYOU25");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU25NotLike(String value) {
            addCriterion("MEMO_NAIYOU25 not like", value, "MEMO_NAIYOU25");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU25In(List<String> values) {
            addCriterion("MEMO_NAIYOU25 in", values, "MEMO_NAIYOU25");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU25NotIn(List<String> values) {
            addCriterion("MEMO_NAIYOU25 not in", values, "MEMO_NAIYOU25");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU25Between(String value1, String value2) {
            addCriterion("MEMO_NAIYOU25 between", value1, value2, "MEMO_NAIYOU25");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU25NotBetween(String value1, String value2) {
            addCriterion("MEMO_NAIYOU25 not between", value1, value2, "MEMO_NAIYOU25");
            return (Criteria) this;
        }

        public Criteria andLN_IKKATU_INSERT_RONRI_NUMIsNull() {
            addCriterion("LN_IKKATU_INSERT_RONRI_NUM is null");
            return (Criteria) this;
        }

        public Criteria andLN_IKKATU_INSERT_RONRI_NUMIsNotNull() {
            addCriterion("LN_IKKATU_INSERT_RONRI_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andLN_IKKATU_INSERT_RONRI_NUMEqualTo(String value) {
            addCriterion("LN_IKKATU_INSERT_RONRI_NUM =", value, "LN_IKKATU_INSERT_RONRI_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_IKKATU_INSERT_RONRI_NUMNotEqualTo(String value) {
            addCriterion("LN_IKKATU_INSERT_RONRI_NUM <>", value, "LN_IKKATU_INSERT_RONRI_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_IKKATU_INSERT_RONRI_NUMGreaterThan(String value) {
            addCriterion("LN_IKKATU_INSERT_RONRI_NUM >", value, "LN_IKKATU_INSERT_RONRI_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_IKKATU_INSERT_RONRI_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("LN_IKKATU_INSERT_RONRI_NUM >=", value, "LN_IKKATU_INSERT_RONRI_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_IKKATU_INSERT_RONRI_NUMLessThan(String value) {
            addCriterion("LN_IKKATU_INSERT_RONRI_NUM <", value, "LN_IKKATU_INSERT_RONRI_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_IKKATU_INSERT_RONRI_NUMLessThanOrEqualTo(String value) {
            addCriterion("LN_IKKATU_INSERT_RONRI_NUM <=", value, "LN_IKKATU_INSERT_RONRI_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_IKKATU_INSERT_RONRI_NUMLike(String value) {
            addCriterion("LN_IKKATU_INSERT_RONRI_NUM like", value, "LN_IKKATU_INSERT_RONRI_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_IKKATU_INSERT_RONRI_NUMNotLike(String value) {
            addCriterion("LN_IKKATU_INSERT_RONRI_NUM not like", value, "LN_IKKATU_INSERT_RONRI_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_IKKATU_INSERT_RONRI_NUMIn(List<String> values) {
            addCriterion("LN_IKKATU_INSERT_RONRI_NUM in", values, "LN_IKKATU_INSERT_RONRI_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_IKKATU_INSERT_RONRI_NUMNotIn(List<String> values) {
            addCriterion("LN_IKKATU_INSERT_RONRI_NUM not in", values, "LN_IKKATU_INSERT_RONRI_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_IKKATU_INSERT_RONRI_NUMBetween(String value1, String value2) {
            addCriterion("LN_IKKATU_INSERT_RONRI_NUM between", value1, value2, "LN_IKKATU_INSERT_RONRI_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_IKKATU_INSERT_RONRI_NUMNotBetween(String value1, String value2) {
            addCriterion("LN_IKKATU_INSERT_RONRI_NUM not between", value1, value2, "LN_IKKATU_INSERT_RONRI_NUM");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_MOTO_KINDIsNull() {
            addCriterion("TOUROKU_MOTO_KIND is null");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_MOTO_KINDIsNotNull() {
            addCriterion("TOUROKU_MOTO_KIND is not null");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_MOTO_KINDEqualTo(String value) {
            addCriterion("TOUROKU_MOTO_KIND =", value, "TOUROKU_MOTO_KIND");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_MOTO_KINDNotEqualTo(String value) {
            addCriterion("TOUROKU_MOTO_KIND <>", value, "TOUROKU_MOTO_KIND");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_MOTO_KINDGreaterThan(String value) {
            addCriterion("TOUROKU_MOTO_KIND >", value, "TOUROKU_MOTO_KIND");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_MOTO_KINDGreaterThanOrEqualTo(String value) {
            addCriterion("TOUROKU_MOTO_KIND >=", value, "TOUROKU_MOTO_KIND");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_MOTO_KINDLessThan(String value) {
            addCriterion("TOUROKU_MOTO_KIND <", value, "TOUROKU_MOTO_KIND");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_MOTO_KINDLessThanOrEqualTo(String value) {
            addCriterion("TOUROKU_MOTO_KIND <=", value, "TOUROKU_MOTO_KIND");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_MOTO_KINDLike(String value) {
            addCriterion("TOUROKU_MOTO_KIND like", value, "TOUROKU_MOTO_KIND");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_MOTO_KINDNotLike(String value) {
            addCriterion("TOUROKU_MOTO_KIND not like", value, "TOUROKU_MOTO_KIND");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_MOTO_KINDIn(List<String> values) {
            addCriterion("TOUROKU_MOTO_KIND in", values, "TOUROKU_MOTO_KIND");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_MOTO_KINDNotIn(List<String> values) {
            addCriterion("TOUROKU_MOTO_KIND not in", values, "TOUROKU_MOTO_KIND");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_MOTO_KINDBetween(String value1, String value2) {
            addCriterion("TOUROKU_MOTO_KIND between", value1, value2, "TOUROKU_MOTO_KIND");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_MOTO_KINDNotBetween(String value1, String value2) {
            addCriterion("TOUROKU_MOTO_KIND not between", value1, value2, "TOUROKU_MOTO_KIND");
            return (Criteria) this;
        }

        public Criteria andJOGYO_IDIsNull() {
            addCriterion("JOGYO_ID is null");
            return (Criteria) this;
        }

        public Criteria andJOGYO_IDIsNotNull() {
            addCriterion("JOGYO_ID is not null");
            return (Criteria) this;
        }

        public Criteria andJOGYO_IDEqualTo(String value) {
            addCriterion("JOGYO_ID =", value, "JOGYO_ID");
            return (Criteria) this;
        }

        public Criteria andJOGYO_IDNotEqualTo(String value) {
            addCriterion("JOGYO_ID <>", value, "JOGYO_ID");
            return (Criteria) this;
        }

        public Criteria andJOGYO_IDGreaterThan(String value) {
            addCriterion("JOGYO_ID >", value, "JOGYO_ID");
            return (Criteria) this;
        }

        public Criteria andJOGYO_IDGreaterThanOrEqualTo(String value) {
            addCriterion("JOGYO_ID >=", value, "JOGYO_ID");
            return (Criteria) this;
        }

        public Criteria andJOGYO_IDLessThan(String value) {
            addCriterion("JOGYO_ID <", value, "JOGYO_ID");
            return (Criteria) this;
        }

        public Criteria andJOGYO_IDLessThanOrEqualTo(String value) {
            addCriterion("JOGYO_ID <=", value, "JOGYO_ID");
            return (Criteria) this;
        }

        public Criteria andJOGYO_IDLike(String value) {
            addCriterion("JOGYO_ID like", value, "JOGYO_ID");
            return (Criteria) this;
        }

        public Criteria andJOGYO_IDNotLike(String value) {
            addCriterion("JOGYO_ID not like", value, "JOGYO_ID");
            return (Criteria) this;
        }

        public Criteria andJOGYO_IDIn(List<String> values) {
            addCriterion("JOGYO_ID in", values, "JOGYO_ID");
            return (Criteria) this;
        }

        public Criteria andJOGYO_IDNotIn(List<String> values) {
            addCriterion("JOGYO_ID not in", values, "JOGYO_ID");
            return (Criteria) this;
        }

        public Criteria andJOGYO_IDBetween(String value1, String value2) {
            addCriterion("JOGYO_ID between", value1, value2, "JOGYO_ID");
            return (Criteria) this;
        }

        public Criteria andJOGYO_IDNotBetween(String value1, String value2) {
            addCriterion("JOGYO_ID not between", value1, value2, "JOGYO_ID");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_TSIsNull() {
            addCriterion("UKETUKE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_TSIsNotNull() {
            addCriterion("UKETUKE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_TSEqualTo(Date value) {
            addCriterion("UKETUKE_TS =", value, "UKETUKE_TS");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_TSNotEqualTo(Date value) {
            addCriterion("UKETUKE_TS <>", value, "UKETUKE_TS");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_TSGreaterThan(Date value) {
            addCriterion("UKETUKE_TS >", value, "UKETUKE_TS");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UKETUKE_TS >=", value, "UKETUKE_TS");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_TSLessThan(Date value) {
            addCriterion("UKETUKE_TS <", value, "UKETUKE_TS");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UKETUKE_TS <=", value, "UKETUKE_TS");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_TSIn(List<Date> values) {
            addCriterion("UKETUKE_TS in", values, "UKETUKE_TS");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_TSNotIn(List<Date> values) {
            addCriterion("UKETUKE_TS not in", values, "UKETUKE_TS");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_TSBetween(Date value1, Date value2) {
            addCriterion("UKETUKE_TS between", value1, value2, "UKETUKE_TS");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UKETUKE_TS not between", value1, value2, "UKETUKE_TS");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_IDIsNull() {
            addCriterion("UKETUKE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_IDIsNotNull() {
            addCriterion("UKETUKE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_IDEqualTo(String value) {
            addCriterion("UKETUKE_ID =", value, "UKETUKE_ID");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_IDNotEqualTo(String value) {
            addCriterion("UKETUKE_ID <>", value, "UKETUKE_ID");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_IDGreaterThan(String value) {
            addCriterion("UKETUKE_ID >", value, "UKETUKE_ID");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UKETUKE_ID >=", value, "UKETUKE_ID");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_IDLessThan(String value) {
            addCriterion("UKETUKE_ID <", value, "UKETUKE_ID");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_IDLessThanOrEqualTo(String value) {
            addCriterion("UKETUKE_ID <=", value, "UKETUKE_ID");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_IDLike(String value) {
            addCriterion("UKETUKE_ID like", value, "UKETUKE_ID");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_IDNotLike(String value) {
            addCriterion("UKETUKE_ID not like", value, "UKETUKE_ID");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_IDIn(List<String> values) {
            addCriterion("UKETUKE_ID in", values, "UKETUKE_ID");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_IDNotIn(List<String> values) {
            addCriterion("UKETUKE_ID not in", values, "UKETUKE_ID");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_IDBetween(String value1, String value2) {
            addCriterion("UKETUKE_ID between", value1, value2, "UKETUKE_ID");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_IDNotBetween(String value1, String value2) {
            addCriterion("UKETUKE_ID not between", value1, value2, "UKETUKE_ID");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_NMIsNull() {
            addCriterion("UKETUKE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_NMIsNotNull() {
            addCriterion("UKETUKE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_NMEqualTo(String value) {
            addCriterion("UKETUKE_NM =", value, "UKETUKE_NM");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_NMNotEqualTo(String value) {
            addCriterion("UKETUKE_NM <>", value, "UKETUKE_NM");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_NMGreaterThan(String value) {
            addCriterion("UKETUKE_NM >", value, "UKETUKE_NM");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UKETUKE_NM >=", value, "UKETUKE_NM");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_NMLessThan(String value) {
            addCriterion("UKETUKE_NM <", value, "UKETUKE_NM");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_NMLessThanOrEqualTo(String value) {
            addCriterion("UKETUKE_NM <=", value, "UKETUKE_NM");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_NMLike(String value) {
            addCriterion("UKETUKE_NM like", value, "UKETUKE_NM");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_NMNotLike(String value) {
            addCriterion("UKETUKE_NM not like", value, "UKETUKE_NM");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_NMIn(List<String> values) {
            addCriterion("UKETUKE_NM in", values, "UKETUKE_NM");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_NMNotIn(List<String> values) {
            addCriterion("UKETUKE_NM not in", values, "UKETUKE_NM");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_NMBetween(String value1, String value2) {
            addCriterion("UKETUKE_NM between", value1, value2, "UKETUKE_NM");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_NMNotBetween(String value1, String value2) {
            addCriterion("UKETUKE_NM not between", value1, value2, "UKETUKE_NM");
            return (Criteria) this;
        }

        public Criteria andRAUKCHAKU_TSIsNull() {
            addCriterion("RAUKCHAKU_TS is null");
            return (Criteria) this;
        }

        public Criteria andRAUKCHAKU_TSIsNotNull() {
            addCriterion("RAUKCHAKU_TS is not null");
            return (Criteria) this;
        }

        public Criteria andRAUKCHAKU_TSEqualTo(Date value) {
            addCriterion("RAUKCHAKU_TS =", value, "RAUKCHAKU_TS");
            return (Criteria) this;
        }

        public Criteria andRAUKCHAKU_TSNotEqualTo(Date value) {
            addCriterion("RAUKCHAKU_TS <>", value, "RAUKCHAKU_TS");
            return (Criteria) this;
        }

        public Criteria andRAUKCHAKU_TSGreaterThan(Date value) {
            addCriterion("RAUKCHAKU_TS >", value, "RAUKCHAKU_TS");
            return (Criteria) this;
        }

        public Criteria andRAUKCHAKU_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("RAUKCHAKU_TS >=", value, "RAUKCHAKU_TS");
            return (Criteria) this;
        }

        public Criteria andRAUKCHAKU_TSLessThan(Date value) {
            addCriterion("RAUKCHAKU_TS <", value, "RAUKCHAKU_TS");
            return (Criteria) this;
        }

        public Criteria andRAUKCHAKU_TSLessThanOrEqualTo(Date value) {
            addCriterion("RAUKCHAKU_TS <=", value, "RAUKCHAKU_TS");
            return (Criteria) this;
        }

        public Criteria andRAUKCHAKU_TSIn(List<Date> values) {
            addCriterion("RAUKCHAKU_TS in", values, "RAUKCHAKU_TS");
            return (Criteria) this;
        }

        public Criteria andRAUKCHAKU_TSNotIn(List<Date> values) {
            addCriterion("RAUKCHAKU_TS not in", values, "RAUKCHAKU_TS");
            return (Criteria) this;
        }

        public Criteria andRAUKCHAKU_TSBetween(Date value1, Date value2) {
            addCriterion("RAUKCHAKU_TS between", value1, value2, "RAUKCHAKU_TS");
            return (Criteria) this;
        }

        public Criteria andRAUKCHAKU_TSNotBetween(Date value1, Date value2) {
            addCriterion("RAUKCHAKU_TS not between", value1, value2, "RAUKCHAKU_TS");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_IDIsNull() {
            addCriterion("RAKUCHAKU_ID is null");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_IDIsNotNull() {
            addCriterion("RAKUCHAKU_ID is not null");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_IDEqualTo(String value) {
            addCriterion("RAKUCHAKU_ID =", value, "RAKUCHAKU_ID");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_IDNotEqualTo(String value) {
            addCriterion("RAKUCHAKU_ID <>", value, "RAKUCHAKU_ID");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_IDGreaterThan(String value) {
            addCriterion("RAKUCHAKU_ID >", value, "RAKUCHAKU_ID");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_IDGreaterThanOrEqualTo(String value) {
            addCriterion("RAKUCHAKU_ID >=", value, "RAKUCHAKU_ID");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_IDLessThan(String value) {
            addCriterion("RAKUCHAKU_ID <", value, "RAKUCHAKU_ID");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_IDLessThanOrEqualTo(String value) {
            addCriterion("RAKUCHAKU_ID <=", value, "RAKUCHAKU_ID");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_IDLike(String value) {
            addCriterion("RAKUCHAKU_ID like", value, "RAKUCHAKU_ID");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_IDNotLike(String value) {
            addCriterion("RAKUCHAKU_ID not like", value, "RAKUCHAKU_ID");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_IDIn(List<String> values) {
            addCriterion("RAKUCHAKU_ID in", values, "RAKUCHAKU_ID");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_IDNotIn(List<String> values) {
            addCriterion("RAKUCHAKU_ID not in", values, "RAKUCHAKU_ID");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_IDBetween(String value1, String value2) {
            addCriterion("RAKUCHAKU_ID between", value1, value2, "RAKUCHAKU_ID");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_IDNotBetween(String value1, String value2) {
            addCriterion("RAKUCHAKU_ID not between", value1, value2, "RAKUCHAKU_ID");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_NMIsNull() {
            addCriterion("RAKUCHAKU_NM is null");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_NMIsNotNull() {
            addCriterion("RAKUCHAKU_NM is not null");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_NMEqualTo(String value) {
            addCriterion("RAKUCHAKU_NM =", value, "RAKUCHAKU_NM");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_NMNotEqualTo(String value) {
            addCriterion("RAKUCHAKU_NM <>", value, "RAKUCHAKU_NM");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_NMGreaterThan(String value) {
            addCriterion("RAKUCHAKU_NM >", value, "RAKUCHAKU_NM");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_NMGreaterThanOrEqualTo(String value) {
            addCriterion("RAKUCHAKU_NM >=", value, "RAKUCHAKU_NM");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_NMLessThan(String value) {
            addCriterion("RAKUCHAKU_NM <", value, "RAKUCHAKU_NM");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_NMLessThanOrEqualTo(String value) {
            addCriterion("RAKUCHAKU_NM <=", value, "RAKUCHAKU_NM");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_NMLike(String value) {
            addCriterion("RAKUCHAKU_NM like", value, "RAKUCHAKU_NM");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_NMNotLike(String value) {
            addCriterion("RAKUCHAKU_NM not like", value, "RAKUCHAKU_NM");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_NMIn(List<String> values) {
            addCriterion("RAKUCHAKU_NM in", values, "RAKUCHAKU_NM");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_NMNotIn(List<String> values) {
            addCriterion("RAKUCHAKU_NM not in", values, "RAKUCHAKU_NM");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_NMBetween(String value1, String value2) {
            addCriterion("RAKUCHAKU_NM between", value1, value2, "RAKUCHAKU_NM");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_NMNotBetween(String value1, String value2) {
            addCriterion("RAKUCHAKU_NM not between", value1, value2, "RAKUCHAKU_NM");
            return (Criteria) this;
        }

        public Criteria andZANGYO_FLGIsNull() {
            addCriterion("ZANGYO_FLG is null");
            return (Criteria) this;
        }

        public Criteria andZANGYO_FLGIsNotNull() {
            addCriterion("ZANGYO_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andZANGYO_FLGEqualTo(String value) {
            addCriterion("ZANGYO_FLG =", value, "ZANGYO_FLG");
            return (Criteria) this;
        }

        public Criteria andZANGYO_FLGNotEqualTo(String value) {
            addCriterion("ZANGYO_FLG <>", value, "ZANGYO_FLG");
            return (Criteria) this;
        }

        public Criteria andZANGYO_FLGGreaterThan(String value) {
            addCriterion("ZANGYO_FLG >", value, "ZANGYO_FLG");
            return (Criteria) this;
        }

        public Criteria andZANGYO_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("ZANGYO_FLG >=", value, "ZANGYO_FLG");
            return (Criteria) this;
        }

        public Criteria andZANGYO_FLGLessThan(String value) {
            addCriterion("ZANGYO_FLG <", value, "ZANGYO_FLG");
            return (Criteria) this;
        }

        public Criteria andZANGYO_FLGLessThanOrEqualTo(String value) {
            addCriterion("ZANGYO_FLG <=", value, "ZANGYO_FLG");
            return (Criteria) this;
        }

        public Criteria andZANGYO_FLGLike(String value) {
            addCriterion("ZANGYO_FLG like", value, "ZANGYO_FLG");
            return (Criteria) this;
        }

        public Criteria andZANGYO_FLGNotLike(String value) {
            addCriterion("ZANGYO_FLG not like", value, "ZANGYO_FLG");
            return (Criteria) this;
        }

        public Criteria andZANGYO_FLGIn(List<String> values) {
            addCriterion("ZANGYO_FLG in", values, "ZANGYO_FLG");
            return (Criteria) this;
        }

        public Criteria andZANGYO_FLGNotIn(List<String> values) {
            addCriterion("ZANGYO_FLG not in", values, "ZANGYO_FLG");
            return (Criteria) this;
        }

        public Criteria andZANGYO_FLGBetween(String value1, String value2) {
            addCriterion("ZANGYO_FLG between", value1, value2, "ZANGYO_FLG");
            return (Criteria) this;
        }

        public Criteria andZANGYO_FLGNotBetween(String value1, String value2) {
            addCriterion("ZANGYO_FLG not between", value1, value2, "ZANGYO_FLG");
            return (Criteria) this;
        }

        public Criteria andSYUKUHAKU_FLGIsNull() {
            addCriterion("SYUKUHAKU_FLG is null");
            return (Criteria) this;
        }

        public Criteria andSYUKUHAKU_FLGIsNotNull() {
            addCriterion("SYUKUHAKU_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andSYUKUHAKU_FLGEqualTo(String value) {
            addCriterion("SYUKUHAKU_FLG =", value, "SYUKUHAKU_FLG");
            return (Criteria) this;
        }

        public Criteria andSYUKUHAKU_FLGNotEqualTo(String value) {
            addCriterion("SYUKUHAKU_FLG <>", value, "SYUKUHAKU_FLG");
            return (Criteria) this;
        }

        public Criteria andSYUKUHAKU_FLGGreaterThan(String value) {
            addCriterion("SYUKUHAKU_FLG >", value, "SYUKUHAKU_FLG");
            return (Criteria) this;
        }

        public Criteria andSYUKUHAKU_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("SYUKUHAKU_FLG >=", value, "SYUKUHAKU_FLG");
            return (Criteria) this;
        }

        public Criteria andSYUKUHAKU_FLGLessThan(String value) {
            addCriterion("SYUKUHAKU_FLG <", value, "SYUKUHAKU_FLG");
            return (Criteria) this;
        }

        public Criteria andSYUKUHAKU_FLGLessThanOrEqualTo(String value) {
            addCriterion("SYUKUHAKU_FLG <=", value, "SYUKUHAKU_FLG");
            return (Criteria) this;
        }

        public Criteria andSYUKUHAKU_FLGLike(String value) {
            addCriterion("SYUKUHAKU_FLG like", value, "SYUKUHAKU_FLG");
            return (Criteria) this;
        }

        public Criteria andSYUKUHAKU_FLGNotLike(String value) {
            addCriterion("SYUKUHAKU_FLG not like", value, "SYUKUHAKU_FLG");
            return (Criteria) this;
        }

        public Criteria andSYUKUHAKU_FLGIn(List<String> values) {
            addCriterion("SYUKUHAKU_FLG in", values, "SYUKUHAKU_FLG");
            return (Criteria) this;
        }

        public Criteria andSYUKUHAKU_FLGNotIn(List<String> values) {
            addCriterion("SYUKUHAKU_FLG not in", values, "SYUKUHAKU_FLG");
            return (Criteria) this;
        }

        public Criteria andSYUKUHAKU_FLGBetween(String value1, String value2) {
            addCriterion("SYUKUHAKU_FLG between", value1, value2, "SYUKUHAKU_FLG");
            return (Criteria) this;
        }

        public Criteria andSYUKUHAKU_FLGNotBetween(String value1, String value2) {
            addCriterion("SYUKUHAKU_FLG not between", value1, value2, "SYUKUHAKU_FLG");
            return (Criteria) this;
        }

        public Criteria andRINKEI_FLGIsNull() {
            addCriterion("RINKEI_FLG is null");
            return (Criteria) this;
        }

        public Criteria andRINKEI_FLGIsNotNull() {
            addCriterion("RINKEI_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andRINKEI_FLGEqualTo(String value) {
            addCriterion("RINKEI_FLG =", value, "RINKEI_FLG");
            return (Criteria) this;
        }

        public Criteria andRINKEI_FLGNotEqualTo(String value) {
            addCriterion("RINKEI_FLG <>", value, "RINKEI_FLG");
            return (Criteria) this;
        }

        public Criteria andRINKEI_FLGGreaterThan(String value) {
            addCriterion("RINKEI_FLG >", value, "RINKEI_FLG");
            return (Criteria) this;
        }

        public Criteria andRINKEI_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("RINKEI_FLG >=", value, "RINKEI_FLG");
            return (Criteria) this;
        }

        public Criteria andRINKEI_FLGLessThan(String value) {
            addCriterion("RINKEI_FLG <", value, "RINKEI_FLG");
            return (Criteria) this;
        }

        public Criteria andRINKEI_FLGLessThanOrEqualTo(String value) {
            addCriterion("RINKEI_FLG <=", value, "RINKEI_FLG");
            return (Criteria) this;
        }

        public Criteria andRINKEI_FLGLike(String value) {
            addCriterion("RINKEI_FLG like", value, "RINKEI_FLG");
            return (Criteria) this;
        }

        public Criteria andRINKEI_FLGNotLike(String value) {
            addCriterion("RINKEI_FLG not like", value, "RINKEI_FLG");
            return (Criteria) this;
        }

        public Criteria andRINKEI_FLGIn(List<String> values) {
            addCriterion("RINKEI_FLG in", values, "RINKEI_FLG");
            return (Criteria) this;
        }

        public Criteria andRINKEI_FLGNotIn(List<String> values) {
            addCriterion("RINKEI_FLG not in", values, "RINKEI_FLG");
            return (Criteria) this;
        }

        public Criteria andRINKEI_FLGBetween(String value1, String value2) {
            addCriterion("RINKEI_FLG between", value1, value2, "RINKEI_FLG");
            return (Criteria) this;
        }

        public Criteria andRINKEI_FLGNotBetween(String value1, String value2) {
            addCriterion("RINKEI_FLG not between", value1, value2, "RINKEI_FLG");
            return (Criteria) this;
        }

        public Criteria andKGAI_FLGIsNull() {
            addCriterion("KGAI_FLG is null");
            return (Criteria) this;
        }

        public Criteria andKGAI_FLGIsNotNull() {
            addCriterion("KGAI_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andKGAI_FLGEqualTo(String value) {
            addCriterion("KGAI_FLG =", value, "KGAI_FLG");
            return (Criteria) this;
        }

        public Criteria andKGAI_FLGNotEqualTo(String value) {
            addCriterion("KGAI_FLG <>", value, "KGAI_FLG");
            return (Criteria) this;
        }

        public Criteria andKGAI_FLGGreaterThan(String value) {
            addCriterion("KGAI_FLG >", value, "KGAI_FLG");
            return (Criteria) this;
        }

        public Criteria andKGAI_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("KGAI_FLG >=", value, "KGAI_FLG");
            return (Criteria) this;
        }

        public Criteria andKGAI_FLGLessThan(String value) {
            addCriterion("KGAI_FLG <", value, "KGAI_FLG");
            return (Criteria) this;
        }

        public Criteria andKGAI_FLGLessThanOrEqualTo(String value) {
            addCriterion("KGAI_FLG <=", value, "KGAI_FLG");
            return (Criteria) this;
        }

        public Criteria andKGAI_FLGLike(String value) {
            addCriterion("KGAI_FLG like", value, "KGAI_FLG");
            return (Criteria) this;
        }

        public Criteria andKGAI_FLGNotLike(String value) {
            addCriterion("KGAI_FLG not like", value, "KGAI_FLG");
            return (Criteria) this;
        }

        public Criteria andKGAI_FLGIn(List<String> values) {
            addCriterion("KGAI_FLG in", values, "KGAI_FLG");
            return (Criteria) this;
        }

        public Criteria andKGAI_FLGNotIn(List<String> values) {
            addCriterion("KGAI_FLG not in", values, "KGAI_FLG");
            return (Criteria) this;
        }

        public Criteria andKGAI_FLGBetween(String value1, String value2) {
            addCriterion("KGAI_FLG between", value1, value2, "KGAI_FLG");
            return (Criteria) this;
        }

        public Criteria andKGAI_FLGNotBetween(String value1, String value2) {
            addCriterion("KGAI_FLG not between", value1, value2, "KGAI_FLG");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andLN_E_MEMOLikeInsensitive(String value) {
            addCriterion("upper(LN_E_MEMO) like", value.toUpperCase(), "LN_E_MEMO");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKULikeInsensitive(String value) {
            addCriterion("upper(LN_KB_CHIKU) like", value.toUpperCase(), "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andYOUTO_IDLikeInsensitive(String value) {
            addCriterion("upper(YOUTO_ID) like", value.toUpperCase(), "YOUTO_ID");
            return (Criteria) this;
        }

        public Criteria andSYOCHI_KBNLikeInsensitive(String value) {
            addCriterion("upper(SYOCHI_KBN) like", value.toUpperCase(), "SYOCHI_KBN");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_NMLikeInsensitive(String value) {
            addCriterion("upper(PEOPLE_NM) like", value.toUpperCase(), "PEOPLE_NM");
            return (Criteria) this;
        }

        public Criteria andPEOPLE_CNTLikeInsensitive(String value) {
            addCriterion("upper(PEOPLE_CNT) like", value.toUpperCase(), "PEOPLE_CNT");
            return (Criteria) this;
        }

        public Criteria andTEL_NUMLikeInsensitive(String value) {
            addCriterion("upper(TEL_NUM) like", value.toUpperCase(), "TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU11LikeInsensitive(String value) {
            addCriterion("upper(MEMO_NAIYOU11) like", value.toUpperCase(), "MEMO_NAIYOU11");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU12LikeInsensitive(String value) {
            addCriterion("upper(MEMO_NAIYOU12) like", value.toUpperCase(), "MEMO_NAIYOU12");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU13LikeInsensitive(String value) {
            addCriterion("upper(MEMO_NAIYOU13) like", value.toUpperCase(), "MEMO_NAIYOU13");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU21LikeInsensitive(String value) {
            addCriterion("upper(MEMO_NAIYOU21) like", value.toUpperCase(), "MEMO_NAIYOU21");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU22LikeInsensitive(String value) {
            addCriterion("upper(MEMO_NAIYOU22) like", value.toUpperCase(), "MEMO_NAIYOU22");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU23LikeInsensitive(String value) {
            addCriterion("upper(MEMO_NAIYOU23) like", value.toUpperCase(), "MEMO_NAIYOU23");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU24LikeInsensitive(String value) {
            addCriterion("upper(MEMO_NAIYOU24) like", value.toUpperCase(), "MEMO_NAIYOU24");
            return (Criteria) this;
        }

        public Criteria andMEMO_NAIYOU25LikeInsensitive(String value) {
            addCriterion("upper(MEMO_NAIYOU25) like", value.toUpperCase(), "MEMO_NAIYOU25");
            return (Criteria) this;
        }

        public Criteria andLN_IKKATU_INSERT_RONRI_NUMLikeInsensitive(String value) {
            addCriterion("upper(LN_IKKATU_INSERT_RONRI_NUM) like", value.toUpperCase(), "LN_IKKATU_INSERT_RONRI_NUM");
            return (Criteria) this;
        }

        public Criteria andTOUROKU_MOTO_KINDLikeInsensitive(String value) {
            addCriterion("upper(TOUROKU_MOTO_KIND) like", value.toUpperCase(), "TOUROKU_MOTO_KIND");
            return (Criteria) this;
        }

        public Criteria andJOGYO_IDLikeInsensitive(String value) {
            addCriterion("upper(JOGYO_ID) like", value.toUpperCase(), "JOGYO_ID");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_IDLikeInsensitive(String value) {
            addCriterion("upper(UKETUKE_ID) like", value.toUpperCase(), "UKETUKE_ID");
            return (Criteria) this;
        }

        public Criteria andUKETUKE_NMLikeInsensitive(String value) {
            addCriterion("upper(UKETUKE_NM) like", value.toUpperCase(), "UKETUKE_NM");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_IDLikeInsensitive(String value) {
            addCriterion("upper(RAKUCHAKU_ID) like", value.toUpperCase(), "RAKUCHAKU_ID");
            return (Criteria) this;
        }

        public Criteria andRAKUCHAKU_NMLikeInsensitive(String value) {
            addCriterion("upper(RAKUCHAKU_NM) like", value.toUpperCase(), "RAKUCHAKU_NM");
            return (Criteria) this;
        }

        public Criteria andZANGYO_FLGLikeInsensitive(String value) {
            addCriterion("upper(ZANGYO_FLG) like", value.toUpperCase(), "ZANGYO_FLG");
            return (Criteria) this;
        }

        public Criteria andSYUKUHAKU_FLGLikeInsensitive(String value) {
            addCriterion("upper(SYUKUHAKU_FLG) like", value.toUpperCase(), "SYUKUHAKU_FLG");
            return (Criteria) this;
        }

        public Criteria andRINKEI_FLGLikeInsensitive(String value) {
            addCriterion("upper(RINKEI_FLG) like", value.toUpperCase(), "RINKEI_FLG");
            return (Criteria) this;
        }

        public Criteria andKGAI_FLGLikeInsensitive(String value) {
            addCriterion("upper(KGAI_FLG) like", value.toUpperCase(), "KGAI_FLG");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * E_MEMO
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * E_MEMO null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}