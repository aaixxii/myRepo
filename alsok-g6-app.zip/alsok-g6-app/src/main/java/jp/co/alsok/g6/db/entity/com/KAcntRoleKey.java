package jp.co.alsok.g6.db.entity.com;

import java.io.Serializable;

public class KAcntRoleKey implements Serializable {
    /**
     * LN_ALSOKアカウント論理番号
     */
    private String LN_ACNT_ALSOK;

    /**
     * LN_ALSOKロール論理番号
     */
    private String LN_ROLE_ALSOK;

    /**
     * K_ACNT_ROLE
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_ALSOKアカウント論理番号
     * @return LN_ACNT_ALSOK LN_ALSOKアカウント論理番号
     */
    public String getLN_ACNT_ALSOK() {
        return LN_ACNT_ALSOK;
    }

    /**
     * LN_ALSOKアカウント論理番号
     * @param LN_ACNT_ALSOK LN_ALSOKアカウント論理番号
     */
    public void setLN_ACNT_ALSOK(String LN_ACNT_ALSOK) {
        this.LN_ACNT_ALSOK = LN_ACNT_ALSOK == null ? null : LN_ACNT_ALSOK.trim();
    }

    /**
     * LN_ALSOKロール論理番号
     * @return LN_ROLE_ALSOK LN_ALSOKロール論理番号
     */
    public String getLN_ROLE_ALSOK() {
        return LN_ROLE_ALSOK;
    }

    /**
     * LN_ALSOKロール論理番号
     * @param LN_ROLE_ALSOK LN_ALSOKロール論理番号
     */
    public void setLN_ROLE_ALSOK(String LN_ROLE_ALSOK) {
        this.LN_ROLE_ALSOK = LN_ROLE_ALSOK == null ? null : LN_ROLE_ALSOK.trim();
    }
}