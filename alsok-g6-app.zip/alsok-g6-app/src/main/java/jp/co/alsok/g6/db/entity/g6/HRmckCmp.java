package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class HRmckCmp implements Serializable {
    /**
     * LN_遠隔点検結果履歴論理番号
     */
    private String LN_RMCK_CMP;

    /**
     * LN_設置機器論理番号
     */
    private String LN_DEV;

    /**
     * 装置番号
     */
    private String DEV_NUM;

    /**
     * 立ち上がり
     */
    private String WAKE_ST;

    /**
     * センサー状態
     */
    private String SENS_STS;

    /**
     * 断線状態
     */
    private String WRBK_STS;

    /**
     * 妨害状態
     */
    private String DSTB_STS;

    /**
     * 環境状態
     */
    private String ENVI_STS;

    /**
     * 位置状態
     */
    private String POST_STS;

    /**
     * 脱落状態
     */
    private String DROP_STS;

    /**
     * 停電入力状態
     */
    private String BLOU_STS;

    /**
     * タンパー状態
     */
    private String TANP_STS;

    /**
     * 機器異常
     */
    private String BKDW_ST;

    /**
     * 入力電圧低下
     */
    private String LWVL_ST;

    /**
     * LED寿命
     */
    private String LED_STS;

    /**
     * 画像連動フラグ
     */
    private String VIDE_LK;

    /**
     * カメラ番号
     */
    private String CAMR_NO;

    /**
     * 画像ファイル名
     */
    private String VFILENM;

    /**
     * フレームレート
     */
    private String FL_RATE;

    /**
     * 画像記録時間
     */
    private String VR_TIME;

    /**
     * 画像記録枚数
     */
    private String VR_ACNT;

    /**
     * 撮像開始時間
     */
    private String VR_STRT;

    /**
     * 撮像枚数
     */
    private String VFCOUNT;

    /**
     * マイク・インターホン連動フラグ
     */
    private String MCSP_LK;

    /**
     * インターホン番号
     */
    private String INTP_NO;

    /**
     * マイク番号
     */
    private String MICP_NO;

    /**
     * スピーカ番号
     */
    private String SPKR_NO;

    /**
     * 音声ファイル名
     */
    private String AFILENM;

    /**
     * 音声記録時間
     */
    private String AR_TIME;

    /**
     * SDカード異常
     */
    private String SDCD_ST;

    /**
     * SDカード保存開始
     */
    private String SDCD1_ST;

    /**
     * SDカード容量ニアフル
     */
    private String SDCD2_ST;

    /**
     * SDカード容量フル
     */
    private String SDCD3_ST;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * H_RMCK_CMP
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_遠隔点検結果履歴論理番号
     * @return LN_RMCK_CMP LN_遠隔点検結果履歴論理番号
     */
    public String getLN_RMCK_CMP() {
        return LN_RMCK_CMP;
    }

    /**
     * LN_遠隔点検結果履歴論理番号
     * @param LN_RMCK_CMP LN_遠隔点検結果履歴論理番号
     */
    public void setLN_RMCK_CMP(String LN_RMCK_CMP) {
        this.LN_RMCK_CMP = LN_RMCK_CMP == null ? null : LN_RMCK_CMP.trim();
    }

    /**
     * LN_設置機器論理番号
     * @return LN_DEV LN_設置機器論理番号
     */
    public String getLN_DEV() {
        return LN_DEV;
    }

    /**
     * LN_設置機器論理番号
     * @param LN_DEV LN_設置機器論理番号
     */
    public void setLN_DEV(String LN_DEV) {
        this.LN_DEV = LN_DEV == null ? null : LN_DEV.trim();
    }

    /**
     * 装置番号
     * @return DEV_NUM 装置番号
     */
    public String getDEV_NUM() {
        return DEV_NUM;
    }

    /**
     * 装置番号
     * @param DEV_NUM 装置番号
     */
    public void setDEV_NUM(String DEV_NUM) {
        this.DEV_NUM = DEV_NUM == null ? null : DEV_NUM.trim();
    }

    /**
     * 立ち上がり
     * @return WAKE_ST 立ち上がり
     */
    public String getWAKE_ST() {
        return WAKE_ST;
    }

    /**
     * 立ち上がり
     * @param WAKE_ST 立ち上がり
     */
    public void setWAKE_ST(String WAKE_ST) {
        this.WAKE_ST = WAKE_ST == null ? null : WAKE_ST.trim();
    }

    /**
     * センサー状態
     * @return SENS_STS センサー状態
     */
    public String getSENS_STS() {
        return SENS_STS;
    }

    /**
     * センサー状態
     * @param SENS_STS センサー状態
     */
    public void setSENS_STS(String SENS_STS) {
        this.SENS_STS = SENS_STS == null ? null : SENS_STS.trim();
    }

    /**
     * 断線状態
     * @return WRBK_STS 断線状態
     */
    public String getWRBK_STS() {
        return WRBK_STS;
    }

    /**
     * 断線状態
     * @param WRBK_STS 断線状態
     */
    public void setWRBK_STS(String WRBK_STS) {
        this.WRBK_STS = WRBK_STS == null ? null : WRBK_STS.trim();
    }

    /**
     * 妨害状態
     * @return DSTB_STS 妨害状態
     */
    public String getDSTB_STS() {
        return DSTB_STS;
    }

    /**
     * 妨害状態
     * @param DSTB_STS 妨害状態
     */
    public void setDSTB_STS(String DSTB_STS) {
        this.DSTB_STS = DSTB_STS == null ? null : DSTB_STS.trim();
    }

    /**
     * 環境状態
     * @return ENVI_STS 環境状態
     */
    public String getENVI_STS() {
        return ENVI_STS;
    }

    /**
     * 環境状態
     * @param ENVI_STS 環境状態
     */
    public void setENVI_STS(String ENVI_STS) {
        this.ENVI_STS = ENVI_STS == null ? null : ENVI_STS.trim();
    }

    /**
     * 位置状態
     * @return POST_STS 位置状態
     */
    public String getPOST_STS() {
        return POST_STS;
    }

    /**
     * 位置状態
     * @param POST_STS 位置状態
     */
    public void setPOST_STS(String POST_STS) {
        this.POST_STS = POST_STS == null ? null : POST_STS.trim();
    }

    /**
     * 脱落状態
     * @return DROP_STS 脱落状態
     */
    public String getDROP_STS() {
        return DROP_STS;
    }

    /**
     * 脱落状態
     * @param DROP_STS 脱落状態
     */
    public void setDROP_STS(String DROP_STS) {
        this.DROP_STS = DROP_STS == null ? null : DROP_STS.trim();
    }

    /**
     * 停電入力状態
     * @return BLOU_STS 停電入力状態
     */
    public String getBLOU_STS() {
        return BLOU_STS;
    }

    /**
     * 停電入力状態
     * @param BLOU_STS 停電入力状態
     */
    public void setBLOU_STS(String BLOU_STS) {
        this.BLOU_STS = BLOU_STS == null ? null : BLOU_STS.trim();
    }

    /**
     * タンパー状態
     * @return TANP_STS タンパー状態
     */
    public String getTANP_STS() {
        return TANP_STS;
    }

    /**
     * タンパー状態
     * @param TANP_STS タンパー状態
     */
    public void setTANP_STS(String TANP_STS) {
        this.TANP_STS = TANP_STS == null ? null : TANP_STS.trim();
    }

    /**
     * 機器異常
     * @return BKDW_ST 機器異常
     */
    public String getBKDW_ST() {
        return BKDW_ST;
    }

    /**
     * 機器異常
     * @param BKDW_ST 機器異常
     */
    public void setBKDW_ST(String BKDW_ST) {
        this.BKDW_ST = BKDW_ST == null ? null : BKDW_ST.trim();
    }

    /**
     * 入力電圧低下
     * @return LWVL_ST 入力電圧低下
     */
    public String getLWVL_ST() {
        return LWVL_ST;
    }

    /**
     * 入力電圧低下
     * @param LWVL_ST 入力電圧低下
     */
    public void setLWVL_ST(String LWVL_ST) {
        this.LWVL_ST = LWVL_ST == null ? null : LWVL_ST.trim();
    }

    /**
     * LED寿命
     * @return LED_STS LED寿命
     */
    public String getLED_STS() {
        return LED_STS;
    }

    /**
     * LED寿命
     * @param LED_STS LED寿命
     */
    public void setLED_STS(String LED_STS) {
        this.LED_STS = LED_STS == null ? null : LED_STS.trim();
    }

    /**
     * 画像連動フラグ
     * @return VIDE_LK 画像連動フラグ
     */
    public String getVIDE_LK() {
        return VIDE_LK;
    }

    /**
     * 画像連動フラグ
     * @param VIDE_LK 画像連動フラグ
     */
    public void setVIDE_LK(String VIDE_LK) {
        this.VIDE_LK = VIDE_LK == null ? null : VIDE_LK.trim();
    }

    /**
     * カメラ番号
     * @return CAMR_NO カメラ番号
     */
    public String getCAMR_NO() {
        return CAMR_NO;
    }

    /**
     * カメラ番号
     * @param CAMR_NO カメラ番号
     */
    public void setCAMR_NO(String CAMR_NO) {
        this.CAMR_NO = CAMR_NO == null ? null : CAMR_NO.trim();
    }

    /**
     * 画像ファイル名
     * @return VFILENM 画像ファイル名
     */
    public String getVFILENM() {
        return VFILENM;
    }

    /**
     * 画像ファイル名
     * @param VFILENM 画像ファイル名
     */
    public void setVFILENM(String VFILENM) {
        this.VFILENM = VFILENM == null ? null : VFILENM.trim();
    }

    /**
     * フレームレート
     * @return FL_RATE フレームレート
     */
    public String getFL_RATE() {
        return FL_RATE;
    }

    /**
     * フレームレート
     * @param FL_RATE フレームレート
     */
    public void setFL_RATE(String FL_RATE) {
        this.FL_RATE = FL_RATE == null ? null : FL_RATE.trim();
    }

    /**
     * 画像記録時間
     * @return VR_TIME 画像記録時間
     */
    public String getVR_TIME() {
        return VR_TIME;
    }

    /**
     * 画像記録時間
     * @param VR_TIME 画像記録時間
     */
    public void setVR_TIME(String VR_TIME) {
        this.VR_TIME = VR_TIME == null ? null : VR_TIME.trim();
    }

    /**
     * 画像記録枚数
     * @return VR_ACNT 画像記録枚数
     */
    public String getVR_ACNT() {
        return VR_ACNT;
    }

    /**
     * 画像記録枚数
     * @param VR_ACNT 画像記録枚数
     */
    public void setVR_ACNT(String VR_ACNT) {
        this.VR_ACNT = VR_ACNT == null ? null : VR_ACNT.trim();
    }

    /**
     * 撮像開始時間
     * @return VR_STRT 撮像開始時間
     */
    public String getVR_STRT() {
        return VR_STRT;
    }

    /**
     * 撮像開始時間
     * @param VR_STRT 撮像開始時間
     */
    public void setVR_STRT(String VR_STRT) {
        this.VR_STRT = VR_STRT == null ? null : VR_STRT.trim();
    }

    /**
     * 撮像枚数
     * @return VFCOUNT 撮像枚数
     */
    public String getVFCOUNT() {
        return VFCOUNT;
    }

    /**
     * 撮像枚数
     * @param VFCOUNT 撮像枚数
     */
    public void setVFCOUNT(String VFCOUNT) {
        this.VFCOUNT = VFCOUNT == null ? null : VFCOUNT.trim();
    }

    /**
     * マイク・インターホン連動フラグ
     * @return MCSP_LK マイク・インターホン連動フラグ
     */
    public String getMCSP_LK() {
        return MCSP_LK;
    }

    /**
     * マイク・インターホン連動フラグ
     * @param MCSP_LK マイク・インターホン連動フラグ
     */
    public void setMCSP_LK(String MCSP_LK) {
        this.MCSP_LK = MCSP_LK == null ? null : MCSP_LK.trim();
    }

    /**
     * インターホン番号
     * @return INTP_NO インターホン番号
     */
    public String getINTP_NO() {
        return INTP_NO;
    }

    /**
     * インターホン番号
     * @param INTP_NO インターホン番号
     */
    public void setINTP_NO(String INTP_NO) {
        this.INTP_NO = INTP_NO == null ? null : INTP_NO.trim();
    }

    /**
     * マイク番号
     * @return MICP_NO マイク番号
     */
    public String getMICP_NO() {
        return MICP_NO;
    }

    /**
     * マイク番号
     * @param MICP_NO マイク番号
     */
    public void setMICP_NO(String MICP_NO) {
        this.MICP_NO = MICP_NO == null ? null : MICP_NO.trim();
    }

    /**
     * スピーカ番号
     * @return SPKR_NO スピーカ番号
     */
    public String getSPKR_NO() {
        return SPKR_NO;
    }

    /**
     * スピーカ番号
     * @param SPKR_NO スピーカ番号
     */
    public void setSPKR_NO(String SPKR_NO) {
        this.SPKR_NO = SPKR_NO == null ? null : SPKR_NO.trim();
    }

    /**
     * 音声ファイル名
     * @return AFILENM 音声ファイル名
     */
    public String getAFILENM() {
        return AFILENM;
    }

    /**
     * 音声ファイル名
     * @param AFILENM 音声ファイル名
     */
    public void setAFILENM(String AFILENM) {
        this.AFILENM = AFILENM == null ? null : AFILENM.trim();
    }

    /**
     * 音声記録時間
     * @return AR_TIME 音声記録時間
     */
    public String getAR_TIME() {
        return AR_TIME;
    }

    /**
     * 音声記録時間
     * @param AR_TIME 音声記録時間
     */
    public void setAR_TIME(String AR_TIME) {
        this.AR_TIME = AR_TIME == null ? null : AR_TIME.trim();
    }

    /**
     * SDカード異常
     * @return SDCD_ST SDカード異常
     */
    public String getSDCD_ST() {
        return SDCD_ST;
    }

    /**
     * SDカード異常
     * @param SDCD_ST SDカード異常
     */
    public void setSDCD_ST(String SDCD_ST) {
        this.SDCD_ST = SDCD_ST == null ? null : SDCD_ST.trim();
    }

    /**
     * SDカード保存開始
     * @return SDCD1_ST SDカード保存開始
     */
    public String getSDCD1_ST() {
        return SDCD1_ST;
    }

    /**
     * SDカード保存開始
     * @param SDCD1_ST SDカード保存開始
     */
    public void setSDCD1_ST(String SDCD1_ST) {
        this.SDCD1_ST = SDCD1_ST == null ? null : SDCD1_ST.trim();
    }

    /**
     * SDカード容量ニアフル
     * @return SDCD2_ST SDカード容量ニアフル
     */
    public String getSDCD2_ST() {
        return SDCD2_ST;
    }

    /**
     * SDカード容量ニアフル
     * @param SDCD2_ST SDカード容量ニアフル
     */
    public void setSDCD2_ST(String SDCD2_ST) {
        this.SDCD2_ST = SDCD2_ST == null ? null : SDCD2_ST.trim();
    }

    /**
     * SDカード容量フル
     * @return SDCD3_ST SDカード容量フル
     */
    public String getSDCD3_ST() {
        return SDCD3_ST;
    }

    /**
     * SDカード容量フル
     * @param SDCD3_ST SDカード容量フル
     */
    public void setSDCD3_ST(String SDCD3_ST) {
        this.SDCD3_ST = SDCD3_ST == null ? null : SDCD3_ST.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}