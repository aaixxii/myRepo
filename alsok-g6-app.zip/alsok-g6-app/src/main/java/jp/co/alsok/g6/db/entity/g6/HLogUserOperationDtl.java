package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class HLogUserOperationDtl implements Serializable {
    /**
     * LN_利用者操作履歴センサー詳細論理番号
     */
    private String LN_LOG_USER_OPERATION_DTL;

    /**
     * LN_利用者操作履歴論理番号
     */
    private String LN_LOG_USER_OPERATION;

    /**
     * 発生日時
     */
    private Date HASSEI_TS;

    /**
     * 機器名称
     */
    private String DEV_NM;

    /**
     * 部署
     */
    private String BUSYO;

    /**
     * 役職
     */
    private String YAKUSYOKU;

    /**
     * カードID
     */
    private String CARD_ID;

    /**
     * 氏名
     */
    private String USER_NM;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * H_LOG_USER_OPERATION_DTL
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_利用者操作履歴センサー詳細論理番号
     * @return LN_LOG_USER_OPERATION_DTL LN_利用者操作履歴センサー詳細論理番号
     */
    public String getLN_LOG_USER_OPERATION_DTL() {
        return LN_LOG_USER_OPERATION_DTL;
    }

    /**
     * LN_利用者操作履歴センサー詳細論理番号
     * @param LN_LOG_USER_OPERATION_DTL LN_利用者操作履歴センサー詳細論理番号
     */
    public void setLN_LOG_USER_OPERATION_DTL(String LN_LOG_USER_OPERATION_DTL) {
        this.LN_LOG_USER_OPERATION_DTL = LN_LOG_USER_OPERATION_DTL == null ? null : LN_LOG_USER_OPERATION_DTL.trim();
    }

    /**
     * LN_利用者操作履歴論理番号
     * @return LN_LOG_USER_OPERATION LN_利用者操作履歴論理番号
     */
    public String getLN_LOG_USER_OPERATION() {
        return LN_LOG_USER_OPERATION;
    }

    /**
     * LN_利用者操作履歴論理番号
     * @param LN_LOG_USER_OPERATION LN_利用者操作履歴論理番号
     */
    public void setLN_LOG_USER_OPERATION(String LN_LOG_USER_OPERATION) {
        this.LN_LOG_USER_OPERATION = LN_LOG_USER_OPERATION == null ? null : LN_LOG_USER_OPERATION.trim();
    }

    /**
     * 発生日時
     * @return HASSEI_TS 発生日時
     */
    public Date getHASSEI_TS() {
        return HASSEI_TS;
    }

    /**
     * 発生日時
     * @param HASSEI_TS 発生日時
     */
    public void setHASSEI_TS(Date HASSEI_TS) {
        this.HASSEI_TS = HASSEI_TS;
    }

    /**
     * 機器名称
     * @return DEV_NM 機器名称
     */
    public String getDEV_NM() {
        return DEV_NM;
    }

    /**
     * 機器名称
     * @param DEV_NM 機器名称
     */
    public void setDEV_NM(String DEV_NM) {
        this.DEV_NM = DEV_NM == null ? null : DEV_NM.trim();
    }

    /**
     * 部署
     * @return BUSYO 部署
     */
    public String getBUSYO() {
        return BUSYO;
    }

    /**
     * 部署
     * @param BUSYO 部署
     */
    public void setBUSYO(String BUSYO) {
        this.BUSYO = BUSYO == null ? null : BUSYO.trim();
    }

    /**
     * 役職
     * @return YAKUSYOKU 役職
     */
    public String getYAKUSYOKU() {
        return YAKUSYOKU;
    }

    /**
     * 役職
     * @param YAKUSYOKU 役職
     */
    public void setYAKUSYOKU(String YAKUSYOKU) {
        this.YAKUSYOKU = YAKUSYOKU == null ? null : YAKUSYOKU.trim();
    }

    /**
     * カードID
     * @return CARD_ID カードID
     */
    public String getCARD_ID() {
        return CARD_ID;
    }

    /**
     * カードID
     * @param CARD_ID カードID
     */
    public void setCARD_ID(String CARD_ID) {
        this.CARD_ID = CARD_ID == null ? null : CARD_ID.trim();
    }

    /**
     * 氏名
     * @return USER_NM 氏名
     */
    public String getUSER_NM() {
        return USER_NM;
    }

    /**
     * 氏名
     * @param USER_NM 氏名
     */
    public void setUSER_NM(String USER_NM) {
        this.USER_NM = USER_NM == null ? null : USER_NM.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}