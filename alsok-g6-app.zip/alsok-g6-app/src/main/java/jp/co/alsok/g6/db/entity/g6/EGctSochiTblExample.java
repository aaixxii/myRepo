package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EGctSochiTblExample {
    /**
     * E_GCT_SOCHI_TBL
     */
    protected String orderByClause;

    /**
     * E_GCT_SOCHI_TBL
     */
    protected boolean distinct;

    /**
     * E_GCT_SOCHI_TBL
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public EGctSochiTblExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * E_GCT_SOCHI_TBL null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andGC_NUMIsNull() {
            addCriterion("GC_NUM is null");
            return (Criteria) this;
        }

        public Criteria andGC_NUMIsNotNull() {
            addCriterion("GC_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andGC_NUMEqualTo(String value) {
            addCriterion("GC_NUM =", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMNotEqualTo(String value) {
            addCriterion("GC_NUM <>", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMGreaterThan(String value) {
            addCriterion("GC_NUM >", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("GC_NUM >=", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMLessThan(String value) {
            addCriterion("GC_NUM <", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMLessThanOrEqualTo(String value) {
            addCriterion("GC_NUM <=", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMLike(String value) {
            addCriterion("GC_NUM like", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMNotLike(String value) {
            addCriterion("GC_NUM not like", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMIn(List<String> values) {
            addCriterion("GC_NUM in", values, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMNotIn(List<String> values) {
            addCriterion("GC_NUM not in", values, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMBetween(String value1, String value2) {
            addCriterion("GC_NUM between", value1, value2, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMNotBetween(String value1, String value2) {
            addCriterion("GC_NUM not between", value1, value2, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_SGSIsNull() {
            addCriterion("LN_SGS is null");
            return (Criteria) this;
        }

        public Criteria andLN_SGSIsNotNull() {
            addCriterion("LN_SGS is not null");
            return (Criteria) this;
        }

        public Criteria andLN_SGSEqualTo(String value) {
            addCriterion("LN_SGS =", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSNotEqualTo(String value) {
            addCriterion("LN_SGS <>", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSGreaterThan(String value) {
            addCriterion("LN_SGS >", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSGreaterThanOrEqualTo(String value) {
            addCriterion("LN_SGS >=", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSLessThan(String value) {
            addCriterion("LN_SGS <", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSLessThanOrEqualTo(String value) {
            addCriterion("LN_SGS <=", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSLike(String value) {
            addCriterion("LN_SGS like", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSNotLike(String value) {
            addCriterion("LN_SGS not like", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSIn(List<String> values) {
            addCriterion("LN_SGS in", values, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSNotIn(List<String> values) {
            addCriterion("LN_SGS not in", values, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSBetween(String value1, String value2) {
            addCriterion("LN_SGS between", value1, value2, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSNotBetween(String value1, String value2) {
            addCriterion("LN_SGS not between", value1, value2, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSIsNull() {
            addCriterion("JIAN_HASSEI_TS is null");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSIsNotNull() {
            addCriterion("JIAN_HASSEI_TS is not null");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSEqualTo(String value) {
            addCriterion("JIAN_HASSEI_TS =", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSNotEqualTo(String value) {
            addCriterion("JIAN_HASSEI_TS <>", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSGreaterThan(String value) {
            addCriterion("JIAN_HASSEI_TS >", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSGreaterThanOrEqualTo(String value) {
            addCriterion("JIAN_HASSEI_TS >=", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSLessThan(String value) {
            addCriterion("JIAN_HASSEI_TS <", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSLessThanOrEqualTo(String value) {
            addCriterion("JIAN_HASSEI_TS <=", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSLike(String value) {
            addCriterion("JIAN_HASSEI_TS like", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSNotLike(String value) {
            addCriterion("JIAN_HASSEI_TS not like", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSIn(List<String> values) {
            addCriterion("JIAN_HASSEI_TS in", values, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSNotIn(List<String> values) {
            addCriterion("JIAN_HASSEI_TS not in", values, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSBetween(String value1, String value2) {
            addCriterion("JIAN_HASSEI_TS between", value1, value2, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSNotBetween(String value1, String value2) {
            addCriterion("JIAN_HASSEI_TS not between", value1, value2, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNTIsNull() {
            addCriterion("SOCHI_CNT is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNTIsNotNull() {
            addCriterion("SOCHI_CNT is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNTEqualTo(String value) {
            addCriterion("SOCHI_CNT =", value, "SOCHI_CNT");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNTNotEqualTo(String value) {
            addCriterion("SOCHI_CNT <>", value, "SOCHI_CNT");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNTGreaterThan(String value) {
            addCriterion("SOCHI_CNT >", value, "SOCHI_CNT");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNTGreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_CNT >=", value, "SOCHI_CNT");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNTLessThan(String value) {
            addCriterion("SOCHI_CNT <", value, "SOCHI_CNT");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNTLessThanOrEqualTo(String value) {
            addCriterion("SOCHI_CNT <=", value, "SOCHI_CNT");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNTLike(String value) {
            addCriterion("SOCHI_CNT like", value, "SOCHI_CNT");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNTNotLike(String value) {
            addCriterion("SOCHI_CNT not like", value, "SOCHI_CNT");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNTIn(List<String> values) {
            addCriterion("SOCHI_CNT in", values, "SOCHI_CNT");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNTNotIn(List<String> values) {
            addCriterion("SOCHI_CNT not in", values, "SOCHI_CNT");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNTBetween(String value1, String value2) {
            addCriterion("SOCHI_CNT between", value1, value2, "SOCHI_CNT");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNTNotBetween(String value1, String value2) {
            addCriterion("SOCHI_CNT not between", value1, value2, "SOCHI_CNT");
            return (Criteria) this;
        }

        public Criteria andHYOJIJUNIsNull() {
            addCriterion("HYOJIJUN is null");
            return (Criteria) this;
        }

        public Criteria andHYOJIJUNIsNotNull() {
            addCriterion("HYOJIJUN is not null");
            return (Criteria) this;
        }

        public Criteria andHYOJIJUNEqualTo(String value) {
            addCriterion("HYOJIJUN =", value, "HYOJIJUN");
            return (Criteria) this;
        }

        public Criteria andHYOJIJUNNotEqualTo(String value) {
            addCriterion("HYOJIJUN <>", value, "HYOJIJUN");
            return (Criteria) this;
        }

        public Criteria andHYOJIJUNGreaterThan(String value) {
            addCriterion("HYOJIJUN >", value, "HYOJIJUN");
            return (Criteria) this;
        }

        public Criteria andHYOJIJUNGreaterThanOrEqualTo(String value) {
            addCriterion("HYOJIJUN >=", value, "HYOJIJUN");
            return (Criteria) this;
        }

        public Criteria andHYOJIJUNLessThan(String value) {
            addCriterion("HYOJIJUN <", value, "HYOJIJUN");
            return (Criteria) this;
        }

        public Criteria andHYOJIJUNLessThanOrEqualTo(String value) {
            addCriterion("HYOJIJUN <=", value, "HYOJIJUN");
            return (Criteria) this;
        }

        public Criteria andHYOJIJUNLike(String value) {
            addCriterion("HYOJIJUN like", value, "HYOJIJUN");
            return (Criteria) this;
        }

        public Criteria andHYOJIJUNNotLike(String value) {
            addCriterion("HYOJIJUN not like", value, "HYOJIJUN");
            return (Criteria) this;
        }

        public Criteria andHYOJIJUNIn(List<String> values) {
            addCriterion("HYOJIJUN in", values, "HYOJIJUN");
            return (Criteria) this;
        }

        public Criteria andHYOJIJUNNotIn(List<String> values) {
            addCriterion("HYOJIJUN not in", values, "HYOJIJUN");
            return (Criteria) this;
        }

        public Criteria andHYOJIJUNBetween(String value1, String value2) {
            addCriterion("HYOJIJUN between", value1, value2, "HYOJIJUN");
            return (Criteria) this;
        }

        public Criteria andHYOJIJUNNotBetween(String value1, String value2) {
            addCriterion("HYOJIJUN not between", value1, value2, "HYOJIJUN");
            return (Criteria) this;
        }

        public Criteria andSOCHIIsNull() {
            addCriterion("SOCHI is null");
            return (Criteria) this;
        }

        public Criteria andSOCHIIsNotNull() {
            addCriterion("SOCHI is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHIEqualTo(String value) {
            addCriterion("SOCHI =", value, "SOCHI");
            return (Criteria) this;
        }

        public Criteria andSOCHINotEqualTo(String value) {
            addCriterion("SOCHI <>", value, "SOCHI");
            return (Criteria) this;
        }

        public Criteria andSOCHIGreaterThan(String value) {
            addCriterion("SOCHI >", value, "SOCHI");
            return (Criteria) this;
        }

        public Criteria andSOCHIGreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI >=", value, "SOCHI");
            return (Criteria) this;
        }

        public Criteria andSOCHILessThan(String value) {
            addCriterion("SOCHI <", value, "SOCHI");
            return (Criteria) this;
        }

        public Criteria andSOCHILessThanOrEqualTo(String value) {
            addCriterion("SOCHI <=", value, "SOCHI");
            return (Criteria) this;
        }

        public Criteria andSOCHILike(String value) {
            addCriterion("SOCHI like", value, "SOCHI");
            return (Criteria) this;
        }

        public Criteria andSOCHINotLike(String value) {
            addCriterion("SOCHI not like", value, "SOCHI");
            return (Criteria) this;
        }

        public Criteria andSOCHIIn(List<String> values) {
            addCriterion("SOCHI in", values, "SOCHI");
            return (Criteria) this;
        }

        public Criteria andSOCHINotIn(List<String> values) {
            addCriterion("SOCHI not in", values, "SOCHI");
            return (Criteria) this;
        }

        public Criteria andSOCHIBetween(String value1, String value2) {
            addCriterion("SOCHI between", value1, value2, "SOCHI");
            return (Criteria) this;
        }

        public Criteria andSOCHINotBetween(String value1, String value2) {
            addCriterion("SOCHI not between", value1, value2, "SOCHI");
            return (Criteria) this;
        }

        public Criteria andSOCHI_TMIsNull() {
            addCriterion("SOCHI_TM is null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_TMIsNotNull() {
            addCriterion("SOCHI_TM is not null");
            return (Criteria) this;
        }

        public Criteria andSOCHI_TMEqualTo(String value) {
            addCriterion("SOCHI_TM =", value, "SOCHI_TM");
            return (Criteria) this;
        }

        public Criteria andSOCHI_TMNotEqualTo(String value) {
            addCriterion("SOCHI_TM <>", value, "SOCHI_TM");
            return (Criteria) this;
        }

        public Criteria andSOCHI_TMGreaterThan(String value) {
            addCriterion("SOCHI_TM >", value, "SOCHI_TM");
            return (Criteria) this;
        }

        public Criteria andSOCHI_TMGreaterThanOrEqualTo(String value) {
            addCriterion("SOCHI_TM >=", value, "SOCHI_TM");
            return (Criteria) this;
        }

        public Criteria andSOCHI_TMLessThan(String value) {
            addCriterion("SOCHI_TM <", value, "SOCHI_TM");
            return (Criteria) this;
        }

        public Criteria andSOCHI_TMLessThanOrEqualTo(String value) {
            addCriterion("SOCHI_TM <=", value, "SOCHI_TM");
            return (Criteria) this;
        }

        public Criteria andSOCHI_TMLike(String value) {
            addCriterion("SOCHI_TM like", value, "SOCHI_TM");
            return (Criteria) this;
        }

        public Criteria andSOCHI_TMNotLike(String value) {
            addCriterion("SOCHI_TM not like", value, "SOCHI_TM");
            return (Criteria) this;
        }

        public Criteria andSOCHI_TMIn(List<String> values) {
            addCriterion("SOCHI_TM in", values, "SOCHI_TM");
            return (Criteria) this;
        }

        public Criteria andSOCHI_TMNotIn(List<String> values) {
            addCriterion("SOCHI_TM not in", values, "SOCHI_TM");
            return (Criteria) this;
        }

        public Criteria andSOCHI_TMBetween(String value1, String value2) {
            addCriterion("SOCHI_TM between", value1, value2, "SOCHI_TM");
            return (Criteria) this;
        }

        public Criteria andSOCHI_TMNotBetween(String value1, String value2) {
            addCriterion("SOCHI_TM not between", value1, value2, "SOCHI_TM");
            return (Criteria) this;
        }

        public Criteria andNYURYOKUSYAIsNull() {
            addCriterion("NYURYOKUSYA is null");
            return (Criteria) this;
        }

        public Criteria andNYURYOKUSYAIsNotNull() {
            addCriterion("NYURYOKUSYA is not null");
            return (Criteria) this;
        }

        public Criteria andNYURYOKUSYAEqualTo(String value) {
            addCriterion("NYURYOKUSYA =", value, "NYURYOKUSYA");
            return (Criteria) this;
        }

        public Criteria andNYURYOKUSYANotEqualTo(String value) {
            addCriterion("NYURYOKUSYA <>", value, "NYURYOKUSYA");
            return (Criteria) this;
        }

        public Criteria andNYURYOKUSYAGreaterThan(String value) {
            addCriterion("NYURYOKUSYA >", value, "NYURYOKUSYA");
            return (Criteria) this;
        }

        public Criteria andNYURYOKUSYAGreaterThanOrEqualTo(String value) {
            addCriterion("NYURYOKUSYA >=", value, "NYURYOKUSYA");
            return (Criteria) this;
        }

        public Criteria andNYURYOKUSYALessThan(String value) {
            addCriterion("NYURYOKUSYA <", value, "NYURYOKUSYA");
            return (Criteria) this;
        }

        public Criteria andNYURYOKUSYALessThanOrEqualTo(String value) {
            addCriterion("NYURYOKUSYA <=", value, "NYURYOKUSYA");
            return (Criteria) this;
        }

        public Criteria andNYURYOKUSYALike(String value) {
            addCriterion("NYURYOKUSYA like", value, "NYURYOKUSYA");
            return (Criteria) this;
        }

        public Criteria andNYURYOKUSYANotLike(String value) {
            addCriterion("NYURYOKUSYA not like", value, "NYURYOKUSYA");
            return (Criteria) this;
        }

        public Criteria andNYURYOKUSYAIn(List<String> values) {
            addCriterion("NYURYOKUSYA in", values, "NYURYOKUSYA");
            return (Criteria) this;
        }

        public Criteria andNYURYOKUSYANotIn(List<String> values) {
            addCriterion("NYURYOKUSYA not in", values, "NYURYOKUSYA");
            return (Criteria) this;
        }

        public Criteria andNYURYOKUSYABetween(String value1, String value2) {
            addCriterion("NYURYOKUSYA between", value1, value2, "NYURYOKUSYA");
            return (Criteria) this;
        }

        public Criteria andNYURYOKUSYANotBetween(String value1, String value2) {
            addCriterion("NYURYOKUSYA not between", value1, value2, "NYURYOKUSYA");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLGIsNull() {
            addCriterion("COLOR_FLG is null");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLGIsNotNull() {
            addCriterion("COLOR_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLGEqualTo(String value) {
            addCriterion("COLOR_FLG =", value, "COLOR_FLG");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLGNotEqualTo(String value) {
            addCriterion("COLOR_FLG <>", value, "COLOR_FLG");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLGGreaterThan(String value) {
            addCriterion("COLOR_FLG >", value, "COLOR_FLG");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("COLOR_FLG >=", value, "COLOR_FLG");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLGLessThan(String value) {
            addCriterion("COLOR_FLG <", value, "COLOR_FLG");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLGLessThanOrEqualTo(String value) {
            addCriterion("COLOR_FLG <=", value, "COLOR_FLG");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLGLike(String value) {
            addCriterion("COLOR_FLG like", value, "COLOR_FLG");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLGNotLike(String value) {
            addCriterion("COLOR_FLG not like", value, "COLOR_FLG");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLGIn(List<String> values) {
            addCriterion("COLOR_FLG in", values, "COLOR_FLG");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLGNotIn(List<String> values) {
            addCriterion("COLOR_FLG not in", values, "COLOR_FLG");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLGBetween(String value1, String value2) {
            addCriterion("COLOR_FLG between", value1, value2, "COLOR_FLG");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLGNotBetween(String value1, String value2) {
            addCriterion("COLOR_FLG not between", value1, value2, "COLOR_FLG");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andGC_NUMLikeInsensitive(String value) {
            addCriterion("upper(GC_NUM) like", value.toUpperCase(), "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_SGSLikeInsensitive(String value) {
            addCriterion("upper(LN_SGS) like", value.toUpperCase(), "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSLikeInsensitive(String value) {
            addCriterion("upper(JIAN_HASSEI_TS) like", value.toUpperCase(), "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSOCHI_CNTLikeInsensitive(String value) {
            addCriterion("upper(SOCHI_CNT) like", value.toUpperCase(), "SOCHI_CNT");
            return (Criteria) this;
        }

        public Criteria andHYOJIJUNLikeInsensitive(String value) {
            addCriterion("upper(HYOJIJUN) like", value.toUpperCase(), "HYOJIJUN");
            return (Criteria) this;
        }

        public Criteria andSOCHILikeInsensitive(String value) {
            addCriterion("upper(SOCHI) like", value.toUpperCase(), "SOCHI");
            return (Criteria) this;
        }

        public Criteria andSOCHI_TMLikeInsensitive(String value) {
            addCriterion("upper(SOCHI_TM) like", value.toUpperCase(), "SOCHI_TM");
            return (Criteria) this;
        }

        public Criteria andNYURYOKUSYALikeInsensitive(String value) {
            addCriterion("upper(NYURYOKUSYA) like", value.toUpperCase(), "NYURYOKUSYA");
            return (Criteria) this;
        }

        public Criteria andCOLOR_FLGLikeInsensitive(String value) {
            addCriterion("upper(COLOR_FLG) like", value.toUpperCase(), "COLOR_FLG");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * E_GCT_SOCHI_TBL
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * E_GCT_SOCHI_TBL null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}