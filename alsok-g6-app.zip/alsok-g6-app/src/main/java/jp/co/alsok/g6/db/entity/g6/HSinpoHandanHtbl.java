package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class HSinpoHandanHtbl implements Serializable {
    /**
     * LN_真報判断履歴論理番号
     */
    private String LN_SINPO_HANDAN;

    /**
     * LN_事案論理番号
     */
    private String LN_JIAN;

    /**
     * レベル
     */
    private String MSG_LEVEL;

    /**
     * 出動要請区分L6
     */
    private String SYUTUDOU_YOUSEI_KBN;

    /**
     * 最終更新者
     */
    private String LASTUPD_NM;

    /**
     * 真報判断選択
     */
    private String SINPO_SELECT;

    /**
     * 真報判断補助結果L6
     */
    private String SINPO_HOJO_KEKKA;

    /**
     * 真報判断結果L6
     */
    private String SINPO_KEKKA;

    /**
     * 真報判断メッセージ
     */
    private String SINPO_MSG;

    /**
     * 判断理由内容
     */
    private String SINPO_REASON_NAIYOU;

    /**
     * 真報判断フラグ
     */
    private String SINPO_FLG;

    /**
     * 真報判断理由フラグ
     */
    private String SINPO_REASON_FLG;

    /**
     * 信号種別１
     */
    private String SIG_KIND_1;

    /**
     * 信号種別２
     */
    private String SIG_KIND_2;

    /**
     * イベント種別名
     */
    private String EVENT_KIND_NM;

    /**
     * 真報判断時間
     */
    private Date SINPO_HANDAN_TM;

    /**
     * 判断時間
     */
    private Date HANDAN_TM;

    /**
     * 総時間
     */
    private Date TOTAL_TM;

    /**
     * 事業所名称
     */
    private String JIGYOU_NM;

    /**
     * ユーザー名
     */
    private String USER_NM;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * H_SINPO_HANDAN_HTBL
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_真報判断履歴論理番号
     * @return LN_SINPO_HANDAN LN_真報判断履歴論理番号
     */
    public String getLN_SINPO_HANDAN() {
        return LN_SINPO_HANDAN;
    }

    /**
     * LN_真報判断履歴論理番号
     * @param LN_SINPO_HANDAN LN_真報判断履歴論理番号
     */
    public void setLN_SINPO_HANDAN(String LN_SINPO_HANDAN) {
        this.LN_SINPO_HANDAN = LN_SINPO_HANDAN == null ? null : LN_SINPO_HANDAN.trim();
    }

    /**
     * LN_事案論理番号
     * @return LN_JIAN LN_事案論理番号
     */
    public String getLN_JIAN() {
        return LN_JIAN;
    }

    /**
     * LN_事案論理番号
     * @param LN_JIAN LN_事案論理番号
     */
    public void setLN_JIAN(String LN_JIAN) {
        this.LN_JIAN = LN_JIAN == null ? null : LN_JIAN.trim();
    }

    /**
     * レベル
     * @return MSG_LEVEL レベル
     */
    public String getMSG_LEVEL() {
        return MSG_LEVEL;
    }

    /**
     * レベル
     * @param MSG_LEVEL レベル
     */
    public void setMSG_LEVEL(String MSG_LEVEL) {
        this.MSG_LEVEL = MSG_LEVEL == null ? null : MSG_LEVEL.trim();
    }

    /**
     * 出動要請区分L6
     * @return SYUTUDOU_YOUSEI_KBN 出動要請区分L6
     */
    public String getSYUTUDOU_YOUSEI_KBN() {
        return SYUTUDOU_YOUSEI_KBN;
    }

    /**
     * 出動要請区分L6
     * @param SYUTUDOU_YOUSEI_KBN 出動要請区分L6
     */
    public void setSYUTUDOU_YOUSEI_KBN(String SYUTUDOU_YOUSEI_KBN) {
        this.SYUTUDOU_YOUSEI_KBN = SYUTUDOU_YOUSEI_KBN == null ? null : SYUTUDOU_YOUSEI_KBN.trim();
    }

    /**
     * 最終更新者
     * @return LASTUPD_NM 最終更新者
     */
    public String getLASTUPD_NM() {
        return LASTUPD_NM;
    }

    /**
     * 最終更新者
     * @param LASTUPD_NM 最終更新者
     */
    public void setLASTUPD_NM(String LASTUPD_NM) {
        this.LASTUPD_NM = LASTUPD_NM == null ? null : LASTUPD_NM.trim();
    }

    /**
     * 真報判断選択
     * @return SINPO_SELECT 真報判断選択
     */
    public String getSINPO_SELECT() {
        return SINPO_SELECT;
    }

    /**
     * 真報判断選択
     * @param SINPO_SELECT 真報判断選択
     */
    public void setSINPO_SELECT(String SINPO_SELECT) {
        this.SINPO_SELECT = SINPO_SELECT == null ? null : SINPO_SELECT.trim();
    }

    /**
     * 真報判断補助結果L6
     * @return SINPO_HOJO_KEKKA 真報判断補助結果L6
     */
    public String getSINPO_HOJO_KEKKA() {
        return SINPO_HOJO_KEKKA;
    }

    /**
     * 真報判断補助結果L6
     * @param SINPO_HOJO_KEKKA 真報判断補助結果L6
     */
    public void setSINPO_HOJO_KEKKA(String SINPO_HOJO_KEKKA) {
        this.SINPO_HOJO_KEKKA = SINPO_HOJO_KEKKA == null ? null : SINPO_HOJO_KEKKA.trim();
    }

    /**
     * 真報判断結果L6
     * @return SINPO_KEKKA 真報判断結果L6
     */
    public String getSINPO_KEKKA() {
        return SINPO_KEKKA;
    }

    /**
     * 真報判断結果L6
     * @param SINPO_KEKKA 真報判断結果L6
     */
    public void setSINPO_KEKKA(String SINPO_KEKKA) {
        this.SINPO_KEKKA = SINPO_KEKKA == null ? null : SINPO_KEKKA.trim();
    }

    /**
     * 真報判断メッセージ
     * @return SINPO_MSG 真報判断メッセージ
     */
    public String getSINPO_MSG() {
        return SINPO_MSG;
    }

    /**
     * 真報判断メッセージ
     * @param SINPO_MSG 真報判断メッセージ
     */
    public void setSINPO_MSG(String SINPO_MSG) {
        this.SINPO_MSG = SINPO_MSG == null ? null : SINPO_MSG.trim();
    }

    /**
     * 判断理由内容
     * @return SINPO_REASON_NAIYOU 判断理由内容
     */
    public String getSINPO_REASON_NAIYOU() {
        return SINPO_REASON_NAIYOU;
    }

    /**
     * 判断理由内容
     * @param SINPO_REASON_NAIYOU 判断理由内容
     */
    public void setSINPO_REASON_NAIYOU(String SINPO_REASON_NAIYOU) {
        this.SINPO_REASON_NAIYOU = SINPO_REASON_NAIYOU == null ? null : SINPO_REASON_NAIYOU.trim();
    }

    /**
     * 真報判断フラグ
     * @return SINPO_FLG 真報判断フラグ
     */
    public String getSINPO_FLG() {
        return SINPO_FLG;
    }

    /**
     * 真報判断フラグ
     * @param SINPO_FLG 真報判断フラグ
     */
    public void setSINPO_FLG(String SINPO_FLG) {
        this.SINPO_FLG = SINPO_FLG == null ? null : SINPO_FLG.trim();
    }

    /**
     * 真報判断理由フラグ
     * @return SINPO_REASON_FLG 真報判断理由フラグ
     */
    public String getSINPO_REASON_FLG() {
        return SINPO_REASON_FLG;
    }

    /**
     * 真報判断理由フラグ
     * @param SINPO_REASON_FLG 真報判断理由フラグ
     */
    public void setSINPO_REASON_FLG(String SINPO_REASON_FLG) {
        this.SINPO_REASON_FLG = SINPO_REASON_FLG == null ? null : SINPO_REASON_FLG.trim();
    }

    /**
     * 信号種別１
     * @return SIG_KIND_1 信号種別１
     */
    public String getSIG_KIND_1() {
        return SIG_KIND_1;
    }

    /**
     * 信号種別１
     * @param SIG_KIND_1 信号種別１
     */
    public void setSIG_KIND_1(String SIG_KIND_1) {
        this.SIG_KIND_1 = SIG_KIND_1 == null ? null : SIG_KIND_1.trim();
    }

    /**
     * 信号種別２
     * @return SIG_KIND_2 信号種別２
     */
    public String getSIG_KIND_2() {
        return SIG_KIND_2;
    }

    /**
     * 信号種別２
     * @param SIG_KIND_2 信号種別２
     */
    public void setSIG_KIND_2(String SIG_KIND_2) {
        this.SIG_KIND_2 = SIG_KIND_2 == null ? null : SIG_KIND_2.trim();
    }

    /**
     * イベント種別名
     * @return EVENT_KIND_NM イベント種別名
     */
    public String getEVENT_KIND_NM() {
        return EVENT_KIND_NM;
    }

    /**
     * イベント種別名
     * @param EVENT_KIND_NM イベント種別名
     */
    public void setEVENT_KIND_NM(String EVENT_KIND_NM) {
        this.EVENT_KIND_NM = EVENT_KIND_NM == null ? null : EVENT_KIND_NM.trim();
    }

    /**
     * 真報判断時間
     * @return SINPO_HANDAN_TM 真報判断時間
     */
    public Date getSINPO_HANDAN_TM() {
        return SINPO_HANDAN_TM;
    }

    /**
     * 真報判断時間
     * @param SINPO_HANDAN_TM 真報判断時間
     */
    public void setSINPO_HANDAN_TM(Date SINPO_HANDAN_TM) {
        this.SINPO_HANDAN_TM = SINPO_HANDAN_TM;
    }

    /**
     * 判断時間
     * @return HANDAN_TM 判断時間
     */
    public Date getHANDAN_TM() {
        return HANDAN_TM;
    }

    /**
     * 判断時間
     * @param HANDAN_TM 判断時間
     */
    public void setHANDAN_TM(Date HANDAN_TM) {
        this.HANDAN_TM = HANDAN_TM;
    }

    /**
     * 総時間
     * @return TOTAL_TM 総時間
     */
    public Date getTOTAL_TM() {
        return TOTAL_TM;
    }

    /**
     * 総時間
     * @param TOTAL_TM 総時間
     */
    public void setTOTAL_TM(Date TOTAL_TM) {
        this.TOTAL_TM = TOTAL_TM;
    }

    /**
     * 事業所名称
     * @return JIGYOU_NM 事業所名称
     */
    public String getJIGYOU_NM() {
        return JIGYOU_NM;
    }

    /**
     * 事業所名称
     * @param JIGYOU_NM 事業所名称
     */
    public void setJIGYOU_NM(String JIGYOU_NM) {
        this.JIGYOU_NM = JIGYOU_NM == null ? null : JIGYOU_NM.trim();
    }

    /**
     * ユーザー名
     * @return USER_NM ユーザー名
     */
    public String getUSER_NM() {
        return USER_NM;
    }

    /**
     * ユーザー名
     * @param USER_NM ユーザー名
     */
    public void setUSER_NM(String USER_NM) {
        this.USER_NM = USER_NM == null ? null : USER_NM.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}