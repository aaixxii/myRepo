package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class EJianDevKbStbl extends EJianDevKbStblKey implements Serializable {
    /**
     * 防犯警報
     */
    private String KEIHO_BOUHAN;

    /**
     * 非常警報
     */
    private String KEIHO_HIJYO;

    /**
     * 設備警報
     */
    private String KEIHO_SETUBI;

    /**
     * 防災警報
     */
    private String KEIHO_BOUSAI;

    /**
     * 保護警報
     */
    private String KEIHO_HOGO;

    /**
     * 故障正常
     */
    private String KOSYO_SEIJYO;

    /**
     * 故障異常
     */
    private String KOSYO_IJYO;

    /**
     * ｾﾝｻｰ監視異常
     */
    private String KOSYO_SENS;

    /**
     * 機器故障
     */
    private String KOSYO_KIKI;

    /**
     * 断線
     */
    private String KOSYO_DANSEN;

    /**
     * 電池劣化
     */
    private String KOSYO_BATT;

    /**
     * 停電・復電
     */
    private String KOSYO_PW_DWN;

    /**
     * 過負荷
     */
    private String KOSYO_KAFUKA;

    /**
     * 電池電圧低下
     */
    private String KOSYO_BATT_DWN;

    /**
     * ﾋｭｰｽﾞ切れ
     */
    private String KOSYO_HYUZU;

    /**
     * 外部電池接続（未使用）
     */
    private String KOSYO_CON_BATT;

    /**
     * 新伝送短絡異常
     */
    private String KOSYO_LP_SHNT;

    /**
     * 新伝送加電圧異常
     */
    private String KOSYO_LP_OVER_V;

    /**
     * 入力電圧低下
     */
    private String KOSYO_INP_BATT_DWN;

    /**
     * 通信異常
     */
    private String KOSYO_CON_NG;

    /**
     * 環境異常
     */
    private String KOSYO_EMV_NG;

    /**
     * 位置異常
     */
    private String KOSYO_ITI_NG;

    /**
     * 施錠異常
     */
    private String KOSYO_SJYO_NG;

    /**
     * 解錠異常
     */
    private String KOSYO_KIJYO_NG;

    /**
     * 開扉異常
     */
    private String KOSYO_DOOR_NG;

    /**
     * 脱落異常
     */
    private String KOSYO_FALL_NG;

    /**
     * タンパー異常
     */
    private String KOSYO_TNPA;

    /**
     * ｱﾄﾞﾚｽ重複
     */
    private String KOSYO_ADDR_DUP;

    /**
     * LED寿命
     */
    private String KOSYO_LED_OLD;

    /**
     * 妨害
     */
    private String KOSYOBOGAI;

    /**
     * こじ開け
     */
    private String KOSYO_KOJIAKE;

    /**
     * 停電入力
     */
    private String KOSYO_PW_INP;

    /**
     * ﾒｲﾝ回線異常
     */
    private String KOSYO_MAIN_LINE;

    /**
     * バックアップ回線異常
     */
    private String KOSYO_BACKUP_LINE;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * E_JIAN_DEV_KB_STBL
     */
    private static final long serialVersionUID = 1L;

    /**
     * 防犯警報
     * @return KEIHO_BOUHAN 防犯警報
     */
    public String getKEIHO_BOUHAN() {
        return KEIHO_BOUHAN;
    }

    /**
     * 防犯警報
     * @param KEIHO_BOUHAN 防犯警報
     */
    public void setKEIHO_BOUHAN(String KEIHO_BOUHAN) {
        this.KEIHO_BOUHAN = KEIHO_BOUHAN == null ? null : KEIHO_BOUHAN.trim();
    }

    /**
     * 非常警報
     * @return KEIHO_HIJYO 非常警報
     */
    public String getKEIHO_HIJYO() {
        return KEIHO_HIJYO;
    }

    /**
     * 非常警報
     * @param KEIHO_HIJYO 非常警報
     */
    public void setKEIHO_HIJYO(String KEIHO_HIJYO) {
        this.KEIHO_HIJYO = KEIHO_HIJYO == null ? null : KEIHO_HIJYO.trim();
    }

    /**
     * 設備警報
     * @return KEIHO_SETUBI 設備警報
     */
    public String getKEIHO_SETUBI() {
        return KEIHO_SETUBI;
    }

    /**
     * 設備警報
     * @param KEIHO_SETUBI 設備警報
     */
    public void setKEIHO_SETUBI(String KEIHO_SETUBI) {
        this.KEIHO_SETUBI = KEIHO_SETUBI == null ? null : KEIHO_SETUBI.trim();
    }

    /**
     * 防災警報
     * @return KEIHO_BOUSAI 防災警報
     */
    public String getKEIHO_BOUSAI() {
        return KEIHO_BOUSAI;
    }

    /**
     * 防災警報
     * @param KEIHO_BOUSAI 防災警報
     */
    public void setKEIHO_BOUSAI(String KEIHO_BOUSAI) {
        this.KEIHO_BOUSAI = KEIHO_BOUSAI == null ? null : KEIHO_BOUSAI.trim();
    }

    /**
     * 保護警報
     * @return KEIHO_HOGO 保護警報
     */
    public String getKEIHO_HOGO() {
        return KEIHO_HOGO;
    }

    /**
     * 保護警報
     * @param KEIHO_HOGO 保護警報
     */
    public void setKEIHO_HOGO(String KEIHO_HOGO) {
        this.KEIHO_HOGO = KEIHO_HOGO == null ? null : KEIHO_HOGO.trim();
    }

    /**
     * 故障正常
     * @return KOSYO_SEIJYO 故障正常
     */
    public String getKOSYO_SEIJYO() {
        return KOSYO_SEIJYO;
    }

    /**
     * 故障正常
     * @param KOSYO_SEIJYO 故障正常
     */
    public void setKOSYO_SEIJYO(String KOSYO_SEIJYO) {
        this.KOSYO_SEIJYO = KOSYO_SEIJYO == null ? null : KOSYO_SEIJYO.trim();
    }

    /**
     * 故障異常
     * @return KOSYO_IJYO 故障異常
     */
    public String getKOSYO_IJYO() {
        return KOSYO_IJYO;
    }

    /**
     * 故障異常
     * @param KOSYO_IJYO 故障異常
     */
    public void setKOSYO_IJYO(String KOSYO_IJYO) {
        this.KOSYO_IJYO = KOSYO_IJYO == null ? null : KOSYO_IJYO.trim();
    }

    /**
     * ｾﾝｻｰ監視異常
     * @return KOSYO_SENS ｾﾝｻｰ監視異常
     */
    public String getKOSYO_SENS() {
        return KOSYO_SENS;
    }

    /**
     * ｾﾝｻｰ監視異常
     * @param KOSYO_SENS ｾﾝｻｰ監視異常
     */
    public void setKOSYO_SENS(String KOSYO_SENS) {
        this.KOSYO_SENS = KOSYO_SENS == null ? null : KOSYO_SENS.trim();
    }

    /**
     * 機器故障
     * @return KOSYO_KIKI 機器故障
     */
    public String getKOSYO_KIKI() {
        return KOSYO_KIKI;
    }

    /**
     * 機器故障
     * @param KOSYO_KIKI 機器故障
     */
    public void setKOSYO_KIKI(String KOSYO_KIKI) {
        this.KOSYO_KIKI = KOSYO_KIKI == null ? null : KOSYO_KIKI.trim();
    }

    /**
     * 断線
     * @return KOSYO_DANSEN 断線
     */
    public String getKOSYO_DANSEN() {
        return KOSYO_DANSEN;
    }

    /**
     * 断線
     * @param KOSYO_DANSEN 断線
     */
    public void setKOSYO_DANSEN(String KOSYO_DANSEN) {
        this.KOSYO_DANSEN = KOSYO_DANSEN == null ? null : KOSYO_DANSEN.trim();
    }

    /**
     * 電池劣化
     * @return KOSYO_BATT 電池劣化
     */
    public String getKOSYO_BATT() {
        return KOSYO_BATT;
    }

    /**
     * 電池劣化
     * @param KOSYO_BATT 電池劣化
     */
    public void setKOSYO_BATT(String KOSYO_BATT) {
        this.KOSYO_BATT = KOSYO_BATT == null ? null : KOSYO_BATT.trim();
    }

    /**
     * 停電・復電
     * @return KOSYO_PW_DWN 停電・復電
     */
    public String getKOSYO_PW_DWN() {
        return KOSYO_PW_DWN;
    }

    /**
     * 停電・復電
     * @param KOSYO_PW_DWN 停電・復電
     */
    public void setKOSYO_PW_DWN(String KOSYO_PW_DWN) {
        this.KOSYO_PW_DWN = KOSYO_PW_DWN == null ? null : KOSYO_PW_DWN.trim();
    }

    /**
     * 過負荷
     * @return KOSYO_KAFUKA 過負荷
     */
    public String getKOSYO_KAFUKA() {
        return KOSYO_KAFUKA;
    }

    /**
     * 過負荷
     * @param KOSYO_KAFUKA 過負荷
     */
    public void setKOSYO_KAFUKA(String KOSYO_KAFUKA) {
        this.KOSYO_KAFUKA = KOSYO_KAFUKA == null ? null : KOSYO_KAFUKA.trim();
    }

    /**
     * 電池電圧低下
     * @return KOSYO_BATT_DWN 電池電圧低下
     */
    public String getKOSYO_BATT_DWN() {
        return KOSYO_BATT_DWN;
    }

    /**
     * 電池電圧低下
     * @param KOSYO_BATT_DWN 電池電圧低下
     */
    public void setKOSYO_BATT_DWN(String KOSYO_BATT_DWN) {
        this.KOSYO_BATT_DWN = KOSYO_BATT_DWN == null ? null : KOSYO_BATT_DWN.trim();
    }

    /**
     * ﾋｭｰｽﾞ切れ
     * @return KOSYO_HYUZU ﾋｭｰｽﾞ切れ
     */
    public String getKOSYO_HYUZU() {
        return KOSYO_HYUZU;
    }

    /**
     * ﾋｭｰｽﾞ切れ
     * @param KOSYO_HYUZU ﾋｭｰｽﾞ切れ
     */
    public void setKOSYO_HYUZU(String KOSYO_HYUZU) {
        this.KOSYO_HYUZU = KOSYO_HYUZU == null ? null : KOSYO_HYUZU.trim();
    }

    /**
     * 外部電池接続（未使用）
     * @return KOSYO_CON_BATT 外部電池接続（未使用）
     */
    public String getKOSYO_CON_BATT() {
        return KOSYO_CON_BATT;
    }

    /**
     * 外部電池接続（未使用）
     * @param KOSYO_CON_BATT 外部電池接続（未使用）
     */
    public void setKOSYO_CON_BATT(String KOSYO_CON_BATT) {
        this.KOSYO_CON_BATT = KOSYO_CON_BATT == null ? null : KOSYO_CON_BATT.trim();
    }

    /**
     * 新伝送短絡異常
     * @return KOSYO_LP_SHNT 新伝送短絡異常
     */
    public String getKOSYO_LP_SHNT() {
        return KOSYO_LP_SHNT;
    }

    /**
     * 新伝送短絡異常
     * @param KOSYO_LP_SHNT 新伝送短絡異常
     */
    public void setKOSYO_LP_SHNT(String KOSYO_LP_SHNT) {
        this.KOSYO_LP_SHNT = KOSYO_LP_SHNT == null ? null : KOSYO_LP_SHNT.trim();
    }

    /**
     * 新伝送加電圧異常
     * @return KOSYO_LP_OVER_V 新伝送加電圧異常
     */
    public String getKOSYO_LP_OVER_V() {
        return KOSYO_LP_OVER_V;
    }

    /**
     * 新伝送加電圧異常
     * @param KOSYO_LP_OVER_V 新伝送加電圧異常
     */
    public void setKOSYO_LP_OVER_V(String KOSYO_LP_OVER_V) {
        this.KOSYO_LP_OVER_V = KOSYO_LP_OVER_V == null ? null : KOSYO_LP_OVER_V.trim();
    }

    /**
     * 入力電圧低下
     * @return KOSYO_INP_BATT_DWN 入力電圧低下
     */
    public String getKOSYO_INP_BATT_DWN() {
        return KOSYO_INP_BATT_DWN;
    }

    /**
     * 入力電圧低下
     * @param KOSYO_INP_BATT_DWN 入力電圧低下
     */
    public void setKOSYO_INP_BATT_DWN(String KOSYO_INP_BATT_DWN) {
        this.KOSYO_INP_BATT_DWN = KOSYO_INP_BATT_DWN == null ? null : KOSYO_INP_BATT_DWN.trim();
    }

    /**
     * 通信異常
     * @return KOSYO_CON_NG 通信異常
     */
    public String getKOSYO_CON_NG() {
        return KOSYO_CON_NG;
    }

    /**
     * 通信異常
     * @param KOSYO_CON_NG 通信異常
     */
    public void setKOSYO_CON_NG(String KOSYO_CON_NG) {
        this.KOSYO_CON_NG = KOSYO_CON_NG == null ? null : KOSYO_CON_NG.trim();
    }

    /**
     * 環境異常
     * @return KOSYO_EMV_NG 環境異常
     */
    public String getKOSYO_EMV_NG() {
        return KOSYO_EMV_NG;
    }

    /**
     * 環境異常
     * @param KOSYO_EMV_NG 環境異常
     */
    public void setKOSYO_EMV_NG(String KOSYO_EMV_NG) {
        this.KOSYO_EMV_NG = KOSYO_EMV_NG == null ? null : KOSYO_EMV_NG.trim();
    }

    /**
     * 位置異常
     * @return KOSYO_ITI_NG 位置異常
     */
    public String getKOSYO_ITI_NG() {
        return KOSYO_ITI_NG;
    }

    /**
     * 位置異常
     * @param KOSYO_ITI_NG 位置異常
     */
    public void setKOSYO_ITI_NG(String KOSYO_ITI_NG) {
        this.KOSYO_ITI_NG = KOSYO_ITI_NG == null ? null : KOSYO_ITI_NG.trim();
    }

    /**
     * 施錠異常
     * @return KOSYO_SJYO_NG 施錠異常
     */
    public String getKOSYO_SJYO_NG() {
        return KOSYO_SJYO_NG;
    }

    /**
     * 施錠異常
     * @param KOSYO_SJYO_NG 施錠異常
     */
    public void setKOSYO_SJYO_NG(String KOSYO_SJYO_NG) {
        this.KOSYO_SJYO_NG = KOSYO_SJYO_NG == null ? null : KOSYO_SJYO_NG.trim();
    }

    /**
     * 解錠異常
     * @return KOSYO_KIJYO_NG 解錠異常
     */
    public String getKOSYO_KIJYO_NG() {
        return KOSYO_KIJYO_NG;
    }

    /**
     * 解錠異常
     * @param KOSYO_KIJYO_NG 解錠異常
     */
    public void setKOSYO_KIJYO_NG(String KOSYO_KIJYO_NG) {
        this.KOSYO_KIJYO_NG = KOSYO_KIJYO_NG == null ? null : KOSYO_KIJYO_NG.trim();
    }

    /**
     * 開扉異常
     * @return KOSYO_DOOR_NG 開扉異常
     */
    public String getKOSYO_DOOR_NG() {
        return KOSYO_DOOR_NG;
    }

    /**
     * 開扉異常
     * @param KOSYO_DOOR_NG 開扉異常
     */
    public void setKOSYO_DOOR_NG(String KOSYO_DOOR_NG) {
        this.KOSYO_DOOR_NG = KOSYO_DOOR_NG == null ? null : KOSYO_DOOR_NG.trim();
    }

    /**
     * 脱落異常
     * @return KOSYO_FALL_NG 脱落異常
     */
    public String getKOSYO_FALL_NG() {
        return KOSYO_FALL_NG;
    }

    /**
     * 脱落異常
     * @param KOSYO_FALL_NG 脱落異常
     */
    public void setKOSYO_FALL_NG(String KOSYO_FALL_NG) {
        this.KOSYO_FALL_NG = KOSYO_FALL_NG == null ? null : KOSYO_FALL_NG.trim();
    }

    /**
     * タンパー異常
     * @return KOSYO_TNPA タンパー異常
     */
    public String getKOSYO_TNPA() {
        return KOSYO_TNPA;
    }

    /**
     * タンパー異常
     * @param KOSYO_TNPA タンパー異常
     */
    public void setKOSYO_TNPA(String KOSYO_TNPA) {
        this.KOSYO_TNPA = KOSYO_TNPA == null ? null : KOSYO_TNPA.trim();
    }

    /**
     * ｱﾄﾞﾚｽ重複
     * @return KOSYO_ADDR_DUP ｱﾄﾞﾚｽ重複
     */
    public String getKOSYO_ADDR_DUP() {
        return KOSYO_ADDR_DUP;
    }

    /**
     * ｱﾄﾞﾚｽ重複
     * @param KOSYO_ADDR_DUP ｱﾄﾞﾚｽ重複
     */
    public void setKOSYO_ADDR_DUP(String KOSYO_ADDR_DUP) {
        this.KOSYO_ADDR_DUP = KOSYO_ADDR_DUP == null ? null : KOSYO_ADDR_DUP.trim();
    }

    /**
     * LED寿命
     * @return KOSYO_LED_OLD LED寿命
     */
    public String getKOSYO_LED_OLD() {
        return KOSYO_LED_OLD;
    }

    /**
     * LED寿命
     * @param KOSYO_LED_OLD LED寿命
     */
    public void setKOSYO_LED_OLD(String KOSYO_LED_OLD) {
        this.KOSYO_LED_OLD = KOSYO_LED_OLD == null ? null : KOSYO_LED_OLD.trim();
    }

    /**
     * 妨害
     * @return KOSYOBOGAI 妨害
     */
    public String getKOSYOBOGAI() {
        return KOSYOBOGAI;
    }

    /**
     * 妨害
     * @param KOSYOBOGAI 妨害
     */
    public void setKOSYOBOGAI(String KOSYOBOGAI) {
        this.KOSYOBOGAI = KOSYOBOGAI == null ? null : KOSYOBOGAI.trim();
    }

    /**
     * こじ開け
     * @return KOSYO_KOJIAKE こじ開け
     */
    public String getKOSYO_KOJIAKE() {
        return KOSYO_KOJIAKE;
    }

    /**
     * こじ開け
     * @param KOSYO_KOJIAKE こじ開け
     */
    public void setKOSYO_KOJIAKE(String KOSYO_KOJIAKE) {
        this.KOSYO_KOJIAKE = KOSYO_KOJIAKE == null ? null : KOSYO_KOJIAKE.trim();
    }

    /**
     * 停電入力
     * @return KOSYO_PW_INP 停電入力
     */
    public String getKOSYO_PW_INP() {
        return KOSYO_PW_INP;
    }

    /**
     * 停電入力
     * @param KOSYO_PW_INP 停電入力
     */
    public void setKOSYO_PW_INP(String KOSYO_PW_INP) {
        this.KOSYO_PW_INP = KOSYO_PW_INP == null ? null : KOSYO_PW_INP.trim();
    }

    /**
     * ﾒｲﾝ回線異常
     * @return KOSYO_MAIN_LINE ﾒｲﾝ回線異常
     */
    public String getKOSYO_MAIN_LINE() {
        return KOSYO_MAIN_LINE;
    }

    /**
     * ﾒｲﾝ回線異常
     * @param KOSYO_MAIN_LINE ﾒｲﾝ回線異常
     */
    public void setKOSYO_MAIN_LINE(String KOSYO_MAIN_LINE) {
        this.KOSYO_MAIN_LINE = KOSYO_MAIN_LINE == null ? null : KOSYO_MAIN_LINE.trim();
    }

    /**
     * バックアップ回線異常
     * @return KOSYO_BACKUP_LINE バックアップ回線異常
     */
    public String getKOSYO_BACKUP_LINE() {
        return KOSYO_BACKUP_LINE;
    }

    /**
     * バックアップ回線異常
     * @param KOSYO_BACKUP_LINE バックアップ回線異常
     */
    public void setKOSYO_BACKUP_LINE(String KOSYO_BACKUP_LINE) {
        this.KOSYO_BACKUP_LINE = KOSYO_BACKUP_LINE == null ? null : KOSYO_BACKUP_LINE.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}