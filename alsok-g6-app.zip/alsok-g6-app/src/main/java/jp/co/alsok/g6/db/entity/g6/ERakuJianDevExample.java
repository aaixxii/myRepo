package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ERakuJianDevExample {
    /**
     * E_RAKU_JIAN_DEV
     */
    protected String orderByClause;

    /**
     * E_RAKU_JIAN_DEV
     */
    protected boolean distinct;

    /**
     * E_RAKU_JIAN_DEV
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public ERakuJianDevExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * E_RAKU_JIAN_DEV null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_JIANIsNull() {
            addCriterion("LN_JIAN is null");
            return (Criteria) this;
        }

        public Criteria andLN_JIANIsNotNull() {
            addCriterion("LN_JIAN is not null");
            return (Criteria) this;
        }

        public Criteria andLN_JIANEqualTo(String value) {
            addCriterion("LN_JIAN =", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANNotEqualTo(String value) {
            addCriterion("LN_JIAN <>", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANGreaterThan(String value) {
            addCriterion("LN_JIAN >", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANGreaterThanOrEqualTo(String value) {
            addCriterion("LN_JIAN >=", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANLessThan(String value) {
            addCriterion("LN_JIAN <", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANLessThanOrEqualTo(String value) {
            addCriterion("LN_JIAN <=", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANLike(String value) {
            addCriterion("LN_JIAN like", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANNotLike(String value) {
            addCriterion("LN_JIAN not like", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANIn(List<String> values) {
            addCriterion("LN_JIAN in", values, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANNotIn(List<String> values) {
            addCriterion("LN_JIAN not in", values, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANBetween(String value1, String value2) {
            addCriterion("LN_JIAN between", value1, value2, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANNotBetween(String value1, String value2) {
            addCriterion("LN_JIAN not between", value1, value2, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_UPPER_CONENCT_DEVIsNull() {
            addCriterion("LN_UPPER_CONENCT_DEV is null");
            return (Criteria) this;
        }

        public Criteria andLN_UPPER_CONENCT_DEVIsNotNull() {
            addCriterion("LN_UPPER_CONENCT_DEV is not null");
            return (Criteria) this;
        }

        public Criteria andLN_UPPER_CONENCT_DEVEqualTo(String value) {
            addCriterion("LN_UPPER_CONENCT_DEV =", value, "LN_UPPER_CONENCT_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_UPPER_CONENCT_DEVNotEqualTo(String value) {
            addCriterion("LN_UPPER_CONENCT_DEV <>", value, "LN_UPPER_CONENCT_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_UPPER_CONENCT_DEVGreaterThan(String value) {
            addCriterion("LN_UPPER_CONENCT_DEV >", value, "LN_UPPER_CONENCT_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_UPPER_CONENCT_DEVGreaterThanOrEqualTo(String value) {
            addCriterion("LN_UPPER_CONENCT_DEV >=", value, "LN_UPPER_CONENCT_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_UPPER_CONENCT_DEVLessThan(String value) {
            addCriterion("LN_UPPER_CONENCT_DEV <", value, "LN_UPPER_CONENCT_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_UPPER_CONENCT_DEVLessThanOrEqualTo(String value) {
            addCriterion("LN_UPPER_CONENCT_DEV <=", value, "LN_UPPER_CONENCT_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_UPPER_CONENCT_DEVLike(String value) {
            addCriterion("LN_UPPER_CONENCT_DEV like", value, "LN_UPPER_CONENCT_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_UPPER_CONENCT_DEVNotLike(String value) {
            addCriterion("LN_UPPER_CONENCT_DEV not like", value, "LN_UPPER_CONENCT_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_UPPER_CONENCT_DEVIn(List<String> values) {
            addCriterion("LN_UPPER_CONENCT_DEV in", values, "LN_UPPER_CONENCT_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_UPPER_CONENCT_DEVNotIn(List<String> values) {
            addCriterion("LN_UPPER_CONENCT_DEV not in", values, "LN_UPPER_CONENCT_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_UPPER_CONENCT_DEVBetween(String value1, String value2) {
            addCriterion("LN_UPPER_CONENCT_DEV between", value1, value2, "LN_UPPER_CONENCT_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_UPPER_CONENCT_DEVNotBetween(String value1, String value2) {
            addCriterion("LN_UPPER_CONENCT_DEV not between", value1, value2, "LN_UPPER_CONENCT_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_BUKKENIsNull() {
            addCriterion("LN_BUKKEN is null");
            return (Criteria) this;
        }

        public Criteria andLN_BUKKENIsNotNull() {
            addCriterion("LN_BUKKEN is not null");
            return (Criteria) this;
        }

        public Criteria andLN_BUKKENEqualTo(String value) {
            addCriterion("LN_BUKKEN =", value, "LN_BUKKEN");
            return (Criteria) this;
        }

        public Criteria andLN_BUKKENNotEqualTo(String value) {
            addCriterion("LN_BUKKEN <>", value, "LN_BUKKEN");
            return (Criteria) this;
        }

        public Criteria andLN_BUKKENGreaterThan(String value) {
            addCriterion("LN_BUKKEN >", value, "LN_BUKKEN");
            return (Criteria) this;
        }

        public Criteria andLN_BUKKENGreaterThanOrEqualTo(String value) {
            addCriterion("LN_BUKKEN >=", value, "LN_BUKKEN");
            return (Criteria) this;
        }

        public Criteria andLN_BUKKENLessThan(String value) {
            addCriterion("LN_BUKKEN <", value, "LN_BUKKEN");
            return (Criteria) this;
        }

        public Criteria andLN_BUKKENLessThanOrEqualTo(String value) {
            addCriterion("LN_BUKKEN <=", value, "LN_BUKKEN");
            return (Criteria) this;
        }

        public Criteria andLN_BUKKENLike(String value) {
            addCriterion("LN_BUKKEN like", value, "LN_BUKKEN");
            return (Criteria) this;
        }

        public Criteria andLN_BUKKENNotLike(String value) {
            addCriterion("LN_BUKKEN not like", value, "LN_BUKKEN");
            return (Criteria) this;
        }

        public Criteria andLN_BUKKENIn(List<String> values) {
            addCriterion("LN_BUKKEN in", values, "LN_BUKKEN");
            return (Criteria) this;
        }

        public Criteria andLN_BUKKENNotIn(List<String> values) {
            addCriterion("LN_BUKKEN not in", values, "LN_BUKKEN");
            return (Criteria) this;
        }

        public Criteria andLN_BUKKENBetween(String value1, String value2) {
            addCriterion("LN_BUKKEN between", value1, value2, "LN_BUKKEN");
            return (Criteria) this;
        }

        public Criteria andLN_BUKKENNotBetween(String value1, String value2) {
            addCriterion("LN_BUKKEN not between", value1, value2, "LN_BUKKEN");
            return (Criteria) this;
        }

        public Criteria andDEV_VERSIONIsNull() {
            addCriterion("DEV_VERSION is null");
            return (Criteria) this;
        }

        public Criteria andDEV_VERSIONIsNotNull() {
            addCriterion("DEV_VERSION is not null");
            return (Criteria) this;
        }

        public Criteria andDEV_VERSIONEqualTo(String value) {
            addCriterion("DEV_VERSION =", value, "DEV_VERSION");
            return (Criteria) this;
        }

        public Criteria andDEV_VERSIONNotEqualTo(String value) {
            addCriterion("DEV_VERSION <>", value, "DEV_VERSION");
            return (Criteria) this;
        }

        public Criteria andDEV_VERSIONGreaterThan(String value) {
            addCriterion("DEV_VERSION >", value, "DEV_VERSION");
            return (Criteria) this;
        }

        public Criteria andDEV_VERSIONGreaterThanOrEqualTo(String value) {
            addCriterion("DEV_VERSION >=", value, "DEV_VERSION");
            return (Criteria) this;
        }

        public Criteria andDEV_VERSIONLessThan(String value) {
            addCriterion("DEV_VERSION <", value, "DEV_VERSION");
            return (Criteria) this;
        }

        public Criteria andDEV_VERSIONLessThanOrEqualTo(String value) {
            addCriterion("DEV_VERSION <=", value, "DEV_VERSION");
            return (Criteria) this;
        }

        public Criteria andDEV_VERSIONLike(String value) {
            addCriterion("DEV_VERSION like", value, "DEV_VERSION");
            return (Criteria) this;
        }

        public Criteria andDEV_VERSIONNotLike(String value) {
            addCriterion("DEV_VERSION not like", value, "DEV_VERSION");
            return (Criteria) this;
        }

        public Criteria andDEV_VERSIONIn(List<String> values) {
            addCriterion("DEV_VERSION in", values, "DEV_VERSION");
            return (Criteria) this;
        }

        public Criteria andDEV_VERSIONNotIn(List<String> values) {
            addCriterion("DEV_VERSION not in", values, "DEV_VERSION");
            return (Criteria) this;
        }

        public Criteria andDEV_VERSIONBetween(String value1, String value2) {
            addCriterion("DEV_VERSION between", value1, value2, "DEV_VERSION");
            return (Criteria) this;
        }

        public Criteria andDEV_VERSIONNotBetween(String value1, String value2) {
            addCriterion("DEV_VERSION not between", value1, value2, "DEV_VERSION");
            return (Criteria) this;
        }

        public Criteria andDEV_SERIAL_NUMIsNull() {
            addCriterion("DEV_SERIAL_NUM is null");
            return (Criteria) this;
        }

        public Criteria andDEV_SERIAL_NUMIsNotNull() {
            addCriterion("DEV_SERIAL_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andDEV_SERIAL_NUMEqualTo(String value) {
            addCriterion("DEV_SERIAL_NUM =", value, "DEV_SERIAL_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_SERIAL_NUMNotEqualTo(String value) {
            addCriterion("DEV_SERIAL_NUM <>", value, "DEV_SERIAL_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_SERIAL_NUMGreaterThan(String value) {
            addCriterion("DEV_SERIAL_NUM >", value, "DEV_SERIAL_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_SERIAL_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("DEV_SERIAL_NUM >=", value, "DEV_SERIAL_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_SERIAL_NUMLessThan(String value) {
            addCriterion("DEV_SERIAL_NUM <", value, "DEV_SERIAL_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_SERIAL_NUMLessThanOrEqualTo(String value) {
            addCriterion("DEV_SERIAL_NUM <=", value, "DEV_SERIAL_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_SERIAL_NUMLike(String value) {
            addCriterion("DEV_SERIAL_NUM like", value, "DEV_SERIAL_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_SERIAL_NUMNotLike(String value) {
            addCriterion("DEV_SERIAL_NUM not like", value, "DEV_SERIAL_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_SERIAL_NUMIn(List<String> values) {
            addCriterion("DEV_SERIAL_NUM in", values, "DEV_SERIAL_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_SERIAL_NUMNotIn(List<String> values) {
            addCriterion("DEV_SERIAL_NUM not in", values, "DEV_SERIAL_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_SERIAL_NUMBetween(String value1, String value2) {
            addCriterion("DEV_SERIAL_NUM between", value1, value2, "DEV_SERIAL_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_SERIAL_NUMNotBetween(String value1, String value2) {
            addCriterion("DEV_SERIAL_NUM not between", value1, value2, "DEV_SERIAL_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_MODELIsNull() {
            addCriterion("DEV_MODEL is null");
            return (Criteria) this;
        }

        public Criteria andDEV_MODELIsNotNull() {
            addCriterion("DEV_MODEL is not null");
            return (Criteria) this;
        }

        public Criteria andDEV_MODELEqualTo(String value) {
            addCriterion("DEV_MODEL =", value, "DEV_MODEL");
            return (Criteria) this;
        }

        public Criteria andDEV_MODELNotEqualTo(String value) {
            addCriterion("DEV_MODEL <>", value, "DEV_MODEL");
            return (Criteria) this;
        }

        public Criteria andDEV_MODELGreaterThan(String value) {
            addCriterion("DEV_MODEL >", value, "DEV_MODEL");
            return (Criteria) this;
        }

        public Criteria andDEV_MODELGreaterThanOrEqualTo(String value) {
            addCriterion("DEV_MODEL >=", value, "DEV_MODEL");
            return (Criteria) this;
        }

        public Criteria andDEV_MODELLessThan(String value) {
            addCriterion("DEV_MODEL <", value, "DEV_MODEL");
            return (Criteria) this;
        }

        public Criteria andDEV_MODELLessThanOrEqualTo(String value) {
            addCriterion("DEV_MODEL <=", value, "DEV_MODEL");
            return (Criteria) this;
        }

        public Criteria andDEV_MODELLike(String value) {
            addCriterion("DEV_MODEL like", value, "DEV_MODEL");
            return (Criteria) this;
        }

        public Criteria andDEV_MODELNotLike(String value) {
            addCriterion("DEV_MODEL not like", value, "DEV_MODEL");
            return (Criteria) this;
        }

        public Criteria andDEV_MODELIn(List<String> values) {
            addCriterion("DEV_MODEL in", values, "DEV_MODEL");
            return (Criteria) this;
        }

        public Criteria andDEV_MODELNotIn(List<String> values) {
            addCriterion("DEV_MODEL not in", values, "DEV_MODEL");
            return (Criteria) this;
        }

        public Criteria andDEV_MODELBetween(String value1, String value2) {
            addCriterion("DEV_MODEL between", value1, value2, "DEV_MODEL");
            return (Criteria) this;
        }

        public Criteria andDEV_MODELNotBetween(String value1, String value2) {
            addCriterion("DEV_MODEL not between", value1, value2, "DEV_MODEL");
            return (Criteria) this;
        }

        public Criteria andDEV_NMIsNull() {
            addCriterion("DEV_NM is null");
            return (Criteria) this;
        }

        public Criteria andDEV_NMIsNotNull() {
            addCriterion("DEV_NM is not null");
            return (Criteria) this;
        }

        public Criteria andDEV_NMEqualTo(String value) {
            addCriterion("DEV_NM =", value, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMNotEqualTo(String value) {
            addCriterion("DEV_NM <>", value, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMGreaterThan(String value) {
            addCriterion("DEV_NM >", value, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMGreaterThanOrEqualTo(String value) {
            addCriterion("DEV_NM >=", value, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMLessThan(String value) {
            addCriterion("DEV_NM <", value, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMLessThanOrEqualTo(String value) {
            addCriterion("DEV_NM <=", value, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMLike(String value) {
            addCriterion("DEV_NM like", value, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMNotLike(String value) {
            addCriterion("DEV_NM not like", value, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMIn(List<String> values) {
            addCriterion("DEV_NM in", values, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMNotIn(List<String> values) {
            addCriterion("DEV_NM not in", values, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMBetween(String value1, String value2) {
            addCriterion("DEV_NM between", value1, value2, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_NMNotBetween(String value1, String value2) {
            addCriterion("DEV_NM not between", value1, value2, "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_KIND_IDIsNull() {
            addCriterion("DEV_KIND_ID is null");
            return (Criteria) this;
        }

        public Criteria andDEV_KIND_IDIsNotNull() {
            addCriterion("DEV_KIND_ID is not null");
            return (Criteria) this;
        }

        public Criteria andDEV_KIND_IDEqualTo(String value) {
            addCriterion("DEV_KIND_ID =", value, "DEV_KIND_ID");
            return (Criteria) this;
        }

        public Criteria andDEV_KIND_IDNotEqualTo(String value) {
            addCriterion("DEV_KIND_ID <>", value, "DEV_KIND_ID");
            return (Criteria) this;
        }

        public Criteria andDEV_KIND_IDGreaterThan(String value) {
            addCriterion("DEV_KIND_ID >", value, "DEV_KIND_ID");
            return (Criteria) this;
        }

        public Criteria andDEV_KIND_IDGreaterThanOrEqualTo(String value) {
            addCriterion("DEV_KIND_ID >=", value, "DEV_KIND_ID");
            return (Criteria) this;
        }

        public Criteria andDEV_KIND_IDLessThan(String value) {
            addCriterion("DEV_KIND_ID <", value, "DEV_KIND_ID");
            return (Criteria) this;
        }

        public Criteria andDEV_KIND_IDLessThanOrEqualTo(String value) {
            addCriterion("DEV_KIND_ID <=", value, "DEV_KIND_ID");
            return (Criteria) this;
        }

        public Criteria andDEV_KIND_IDLike(String value) {
            addCriterion("DEV_KIND_ID like", value, "DEV_KIND_ID");
            return (Criteria) this;
        }

        public Criteria andDEV_KIND_IDNotLike(String value) {
            addCriterion("DEV_KIND_ID not like", value, "DEV_KIND_ID");
            return (Criteria) this;
        }

        public Criteria andDEV_KIND_IDIn(List<String> values) {
            addCriterion("DEV_KIND_ID in", values, "DEV_KIND_ID");
            return (Criteria) this;
        }

        public Criteria andDEV_KIND_IDNotIn(List<String> values) {
            addCriterion("DEV_KIND_ID not in", values, "DEV_KIND_ID");
            return (Criteria) this;
        }

        public Criteria andDEV_KIND_IDBetween(String value1, String value2) {
            addCriterion("DEV_KIND_ID between", value1, value2, "DEV_KIND_ID");
            return (Criteria) this;
        }

        public Criteria andDEV_KIND_IDNotBetween(String value1, String value2) {
            addCriterion("DEV_KIND_ID not between", value1, value2, "DEV_KIND_ID");
            return (Criteria) this;
        }

        public Criteria andCHIKUIsNull() {
            addCriterion("CHIKU is null");
            return (Criteria) this;
        }

        public Criteria andCHIKUIsNotNull() {
            addCriterion("CHIKU is not null");
            return (Criteria) this;
        }

        public Criteria andCHIKUEqualTo(String value) {
            addCriterion("CHIKU =", value, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKUNotEqualTo(String value) {
            addCriterion("CHIKU <>", value, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKUGreaterThan(String value) {
            addCriterion("CHIKU >", value, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKUGreaterThanOrEqualTo(String value) {
            addCriterion("CHIKU >=", value, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKULessThan(String value) {
            addCriterion("CHIKU <", value, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKULessThanOrEqualTo(String value) {
            addCriterion("CHIKU <=", value, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKULike(String value) {
            addCriterion("CHIKU like", value, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKUNotLike(String value) {
            addCriterion("CHIKU not like", value, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKUIn(List<String> values) {
            addCriterion("CHIKU in", values, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKUNotIn(List<String> values) {
            addCriterion("CHIKU not in", values, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKUBetween(String value1, String value2) {
            addCriterion("CHIKU between", value1, value2, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andCHIKUNotBetween(String value1, String value2) {
            addCriterion("CHIKU not between", value1, value2, "CHIKU");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMIsNull() {
            addCriterion("DEV_NUM is null");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMIsNotNull() {
            addCriterion("DEV_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMEqualTo(String value) {
            addCriterion("DEV_NUM =", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMNotEqualTo(String value) {
            addCriterion("DEV_NUM <>", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMGreaterThan(String value) {
            addCriterion("DEV_NUM >", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("DEV_NUM >=", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMLessThan(String value) {
            addCriterion("DEV_NUM <", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMLessThanOrEqualTo(String value) {
            addCriterion("DEV_NUM <=", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMLike(String value) {
            addCriterion("DEV_NUM like", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMNotLike(String value) {
            addCriterion("DEV_NUM not like", value, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMIn(List<String> values) {
            addCriterion("DEV_NUM in", values, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMNotIn(List<String> values) {
            addCriterion("DEV_NUM not in", values, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMBetween(String value1, String value2) {
            addCriterion("DEV_NUM between", value1, value2, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMNotBetween(String value1, String value2) {
            addCriterion("DEV_NUM not between", value1, value2, "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andSD_SENSOR_GRP_NUMIsNull() {
            addCriterion("SD_SENSOR_GRP_NUM is null");
            return (Criteria) this;
        }

        public Criteria andSD_SENSOR_GRP_NUMIsNotNull() {
            addCriterion("SD_SENSOR_GRP_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andSD_SENSOR_GRP_NUMEqualTo(String value) {
            addCriterion("SD_SENSOR_GRP_NUM =", value, "SD_SENSOR_GRP_NUM");
            return (Criteria) this;
        }

        public Criteria andSD_SENSOR_GRP_NUMNotEqualTo(String value) {
            addCriterion("SD_SENSOR_GRP_NUM <>", value, "SD_SENSOR_GRP_NUM");
            return (Criteria) this;
        }

        public Criteria andSD_SENSOR_GRP_NUMGreaterThan(String value) {
            addCriterion("SD_SENSOR_GRP_NUM >", value, "SD_SENSOR_GRP_NUM");
            return (Criteria) this;
        }

        public Criteria andSD_SENSOR_GRP_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("SD_SENSOR_GRP_NUM >=", value, "SD_SENSOR_GRP_NUM");
            return (Criteria) this;
        }

        public Criteria andSD_SENSOR_GRP_NUMLessThan(String value) {
            addCriterion("SD_SENSOR_GRP_NUM <", value, "SD_SENSOR_GRP_NUM");
            return (Criteria) this;
        }

        public Criteria andSD_SENSOR_GRP_NUMLessThanOrEqualTo(String value) {
            addCriterion("SD_SENSOR_GRP_NUM <=", value, "SD_SENSOR_GRP_NUM");
            return (Criteria) this;
        }

        public Criteria andSD_SENSOR_GRP_NUMLike(String value) {
            addCriterion("SD_SENSOR_GRP_NUM like", value, "SD_SENSOR_GRP_NUM");
            return (Criteria) this;
        }

        public Criteria andSD_SENSOR_GRP_NUMNotLike(String value) {
            addCriterion("SD_SENSOR_GRP_NUM not like", value, "SD_SENSOR_GRP_NUM");
            return (Criteria) this;
        }

        public Criteria andSD_SENSOR_GRP_NUMIn(List<String> values) {
            addCriterion("SD_SENSOR_GRP_NUM in", values, "SD_SENSOR_GRP_NUM");
            return (Criteria) this;
        }

        public Criteria andSD_SENSOR_GRP_NUMNotIn(List<String> values) {
            addCriterion("SD_SENSOR_GRP_NUM not in", values, "SD_SENSOR_GRP_NUM");
            return (Criteria) this;
        }

        public Criteria andSD_SENSOR_GRP_NUMBetween(String value1, String value2) {
            addCriterion("SD_SENSOR_GRP_NUM between", value1, value2, "SD_SENSOR_GRP_NUM");
            return (Criteria) this;
        }

        public Criteria andSD_SENSOR_GRP_NUMNotBetween(String value1, String value2) {
            addCriterion("SD_SENSOR_GRP_NUM not between", value1, value2, "SD_SENSOR_GRP_NUM");
            return (Criteria) this;
        }

        public Criteria andSD_SYUHEN_NUMIsNull() {
            addCriterion("SD_SYUHEN_NUM is null");
            return (Criteria) this;
        }

        public Criteria andSD_SYUHEN_NUMIsNotNull() {
            addCriterion("SD_SYUHEN_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andSD_SYUHEN_NUMEqualTo(String value) {
            addCriterion("SD_SYUHEN_NUM =", value, "SD_SYUHEN_NUM");
            return (Criteria) this;
        }

        public Criteria andSD_SYUHEN_NUMNotEqualTo(String value) {
            addCriterion("SD_SYUHEN_NUM <>", value, "SD_SYUHEN_NUM");
            return (Criteria) this;
        }

        public Criteria andSD_SYUHEN_NUMGreaterThan(String value) {
            addCriterion("SD_SYUHEN_NUM >", value, "SD_SYUHEN_NUM");
            return (Criteria) this;
        }

        public Criteria andSD_SYUHEN_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("SD_SYUHEN_NUM >=", value, "SD_SYUHEN_NUM");
            return (Criteria) this;
        }

        public Criteria andSD_SYUHEN_NUMLessThan(String value) {
            addCriterion("SD_SYUHEN_NUM <", value, "SD_SYUHEN_NUM");
            return (Criteria) this;
        }

        public Criteria andSD_SYUHEN_NUMLessThanOrEqualTo(String value) {
            addCriterion("SD_SYUHEN_NUM <=", value, "SD_SYUHEN_NUM");
            return (Criteria) this;
        }

        public Criteria andSD_SYUHEN_NUMLike(String value) {
            addCriterion("SD_SYUHEN_NUM like", value, "SD_SYUHEN_NUM");
            return (Criteria) this;
        }

        public Criteria andSD_SYUHEN_NUMNotLike(String value) {
            addCriterion("SD_SYUHEN_NUM not like", value, "SD_SYUHEN_NUM");
            return (Criteria) this;
        }

        public Criteria andSD_SYUHEN_NUMIn(List<String> values) {
            addCriterion("SD_SYUHEN_NUM in", values, "SD_SYUHEN_NUM");
            return (Criteria) this;
        }

        public Criteria andSD_SYUHEN_NUMNotIn(List<String> values) {
            addCriterion("SD_SYUHEN_NUM not in", values, "SD_SYUHEN_NUM");
            return (Criteria) this;
        }

        public Criteria andSD_SYUHEN_NUMBetween(String value1, String value2) {
            addCriterion("SD_SYUHEN_NUM between", value1, value2, "SD_SYUHEN_NUM");
            return (Criteria) this;
        }

        public Criteria andSD_SYUHEN_NUMNotBetween(String value1, String value2) {
            addCriterion("SD_SYUHEN_NUM not between", value1, value2, "SD_SYUHEN_NUM");
            return (Criteria) this;
        }

        public Criteria andSD_SINDENSOU_ADDRIsNull() {
            addCriterion("SD_SINDENSOU_ADDR is null");
            return (Criteria) this;
        }

        public Criteria andSD_SINDENSOU_ADDRIsNotNull() {
            addCriterion("SD_SINDENSOU_ADDR is not null");
            return (Criteria) this;
        }

        public Criteria andSD_SINDENSOU_ADDREqualTo(String value) {
            addCriterion("SD_SINDENSOU_ADDR =", value, "SD_SINDENSOU_ADDR");
            return (Criteria) this;
        }

        public Criteria andSD_SINDENSOU_ADDRNotEqualTo(String value) {
            addCriterion("SD_SINDENSOU_ADDR <>", value, "SD_SINDENSOU_ADDR");
            return (Criteria) this;
        }

        public Criteria andSD_SINDENSOU_ADDRGreaterThan(String value) {
            addCriterion("SD_SINDENSOU_ADDR >", value, "SD_SINDENSOU_ADDR");
            return (Criteria) this;
        }

        public Criteria andSD_SINDENSOU_ADDRGreaterThanOrEqualTo(String value) {
            addCriterion("SD_SINDENSOU_ADDR >=", value, "SD_SINDENSOU_ADDR");
            return (Criteria) this;
        }

        public Criteria andSD_SINDENSOU_ADDRLessThan(String value) {
            addCriterion("SD_SINDENSOU_ADDR <", value, "SD_SINDENSOU_ADDR");
            return (Criteria) this;
        }

        public Criteria andSD_SINDENSOU_ADDRLessThanOrEqualTo(String value) {
            addCriterion("SD_SINDENSOU_ADDR <=", value, "SD_SINDENSOU_ADDR");
            return (Criteria) this;
        }

        public Criteria andSD_SINDENSOU_ADDRLike(String value) {
            addCriterion("SD_SINDENSOU_ADDR like", value, "SD_SINDENSOU_ADDR");
            return (Criteria) this;
        }

        public Criteria andSD_SINDENSOU_ADDRNotLike(String value) {
            addCriterion("SD_SINDENSOU_ADDR not like", value, "SD_SINDENSOU_ADDR");
            return (Criteria) this;
        }

        public Criteria andSD_SINDENSOU_ADDRIn(List<String> values) {
            addCriterion("SD_SINDENSOU_ADDR in", values, "SD_SINDENSOU_ADDR");
            return (Criteria) this;
        }

        public Criteria andSD_SINDENSOU_ADDRNotIn(List<String> values) {
            addCriterion("SD_SINDENSOU_ADDR not in", values, "SD_SINDENSOU_ADDR");
            return (Criteria) this;
        }

        public Criteria andSD_SINDENSOU_ADDRBetween(String value1, String value2) {
            addCriterion("SD_SINDENSOU_ADDR between", value1, value2, "SD_SINDENSOU_ADDR");
            return (Criteria) this;
        }

        public Criteria andSD_SINDENSOU_ADDRNotBetween(String value1, String value2) {
            addCriterion("SD_SINDENSOU_ADDR not between", value1, value2, "SD_SINDENSOU_ADDR");
            return (Criteria) this;
        }

        public Criteria andSD_SPEAKER_FLGIsNull() {
            addCriterion("SD_SPEAKER_FLG is null");
            return (Criteria) this;
        }

        public Criteria andSD_SPEAKER_FLGIsNotNull() {
            addCriterion("SD_SPEAKER_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andSD_SPEAKER_FLGEqualTo(String value) {
            addCriterion("SD_SPEAKER_FLG =", value, "SD_SPEAKER_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_SPEAKER_FLGNotEqualTo(String value) {
            addCriterion("SD_SPEAKER_FLG <>", value, "SD_SPEAKER_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_SPEAKER_FLGGreaterThan(String value) {
            addCriterion("SD_SPEAKER_FLG >", value, "SD_SPEAKER_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_SPEAKER_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("SD_SPEAKER_FLG >=", value, "SD_SPEAKER_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_SPEAKER_FLGLessThan(String value) {
            addCriterion("SD_SPEAKER_FLG <", value, "SD_SPEAKER_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_SPEAKER_FLGLessThanOrEqualTo(String value) {
            addCriterion("SD_SPEAKER_FLG <=", value, "SD_SPEAKER_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_SPEAKER_FLGLike(String value) {
            addCriterion("SD_SPEAKER_FLG like", value, "SD_SPEAKER_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_SPEAKER_FLGNotLike(String value) {
            addCriterion("SD_SPEAKER_FLG not like", value, "SD_SPEAKER_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_SPEAKER_FLGIn(List<String> values) {
            addCriterion("SD_SPEAKER_FLG in", values, "SD_SPEAKER_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_SPEAKER_FLGNotIn(List<String> values) {
            addCriterion("SD_SPEAKER_FLG not in", values, "SD_SPEAKER_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_SPEAKER_FLGBetween(String value1, String value2) {
            addCriterion("SD_SPEAKER_FLG between", value1, value2, "SD_SPEAKER_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_SPEAKER_FLGNotBetween(String value1, String value2) {
            addCriterion("SD_SPEAKER_FLG not between", value1, value2, "SD_SPEAKER_FLG");
            return (Criteria) this;
        }

        public Criteria andSETTEN_NUMIsNull() {
            addCriterion("SETTEN_NUM is null");
            return (Criteria) this;
        }

        public Criteria andSETTEN_NUMIsNotNull() {
            addCriterion("SETTEN_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andSETTEN_NUMEqualTo(String value) {
            addCriterion("SETTEN_NUM =", value, "SETTEN_NUM");
            return (Criteria) this;
        }

        public Criteria andSETTEN_NUMNotEqualTo(String value) {
            addCriterion("SETTEN_NUM <>", value, "SETTEN_NUM");
            return (Criteria) this;
        }

        public Criteria andSETTEN_NUMGreaterThan(String value) {
            addCriterion("SETTEN_NUM >", value, "SETTEN_NUM");
            return (Criteria) this;
        }

        public Criteria andSETTEN_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("SETTEN_NUM >=", value, "SETTEN_NUM");
            return (Criteria) this;
        }

        public Criteria andSETTEN_NUMLessThan(String value) {
            addCriterion("SETTEN_NUM <", value, "SETTEN_NUM");
            return (Criteria) this;
        }

        public Criteria andSETTEN_NUMLessThanOrEqualTo(String value) {
            addCriterion("SETTEN_NUM <=", value, "SETTEN_NUM");
            return (Criteria) this;
        }

        public Criteria andSETTEN_NUMLike(String value) {
            addCriterion("SETTEN_NUM like", value, "SETTEN_NUM");
            return (Criteria) this;
        }

        public Criteria andSETTEN_NUMNotLike(String value) {
            addCriterion("SETTEN_NUM not like", value, "SETTEN_NUM");
            return (Criteria) this;
        }

        public Criteria andSETTEN_NUMIn(List<String> values) {
            addCriterion("SETTEN_NUM in", values, "SETTEN_NUM");
            return (Criteria) this;
        }

        public Criteria andSETTEN_NUMNotIn(List<String> values) {
            addCriterion("SETTEN_NUM not in", values, "SETTEN_NUM");
            return (Criteria) this;
        }

        public Criteria andSETTEN_NUMBetween(String value1, String value2) {
            addCriterion("SETTEN_NUM between", value1, value2, "SETTEN_NUM");
            return (Criteria) this;
        }

        public Criteria andSETTEN_NUMNotBetween(String value1, String value2) {
            addCriterion("SETTEN_NUM not between", value1, value2, "SETTEN_NUM");
            return (Criteria) this;
        }

        public Criteria andPORT01IsNull() {
            addCriterion("PORT01 is null");
            return (Criteria) this;
        }

        public Criteria andPORT01IsNotNull() {
            addCriterion("PORT01 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT01EqualTo(String value) {
            addCriterion("PORT01 =", value, "PORT01");
            return (Criteria) this;
        }

        public Criteria andPORT01NotEqualTo(String value) {
            addCriterion("PORT01 <>", value, "PORT01");
            return (Criteria) this;
        }

        public Criteria andPORT01GreaterThan(String value) {
            addCriterion("PORT01 >", value, "PORT01");
            return (Criteria) this;
        }

        public Criteria andPORT01GreaterThanOrEqualTo(String value) {
            addCriterion("PORT01 >=", value, "PORT01");
            return (Criteria) this;
        }

        public Criteria andPORT01LessThan(String value) {
            addCriterion("PORT01 <", value, "PORT01");
            return (Criteria) this;
        }

        public Criteria andPORT01LessThanOrEqualTo(String value) {
            addCriterion("PORT01 <=", value, "PORT01");
            return (Criteria) this;
        }

        public Criteria andPORT01Like(String value) {
            addCriterion("PORT01 like", value, "PORT01");
            return (Criteria) this;
        }

        public Criteria andPORT01NotLike(String value) {
            addCriterion("PORT01 not like", value, "PORT01");
            return (Criteria) this;
        }

        public Criteria andPORT01In(List<String> values) {
            addCriterion("PORT01 in", values, "PORT01");
            return (Criteria) this;
        }

        public Criteria andPORT01NotIn(List<String> values) {
            addCriterion("PORT01 not in", values, "PORT01");
            return (Criteria) this;
        }

        public Criteria andPORT01Between(String value1, String value2) {
            addCriterion("PORT01 between", value1, value2, "PORT01");
            return (Criteria) this;
        }

        public Criteria andPORT01NotBetween(String value1, String value2) {
            addCriterion("PORT01 not between", value1, value2, "PORT01");
            return (Criteria) this;
        }

        public Criteria andPORT02IsNull() {
            addCriterion("PORT02 is null");
            return (Criteria) this;
        }

        public Criteria andPORT02IsNotNull() {
            addCriterion("PORT02 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT02EqualTo(String value) {
            addCriterion("PORT02 =", value, "PORT02");
            return (Criteria) this;
        }

        public Criteria andPORT02NotEqualTo(String value) {
            addCriterion("PORT02 <>", value, "PORT02");
            return (Criteria) this;
        }

        public Criteria andPORT02GreaterThan(String value) {
            addCriterion("PORT02 >", value, "PORT02");
            return (Criteria) this;
        }

        public Criteria andPORT02GreaterThanOrEqualTo(String value) {
            addCriterion("PORT02 >=", value, "PORT02");
            return (Criteria) this;
        }

        public Criteria andPORT02LessThan(String value) {
            addCriterion("PORT02 <", value, "PORT02");
            return (Criteria) this;
        }

        public Criteria andPORT02LessThanOrEqualTo(String value) {
            addCriterion("PORT02 <=", value, "PORT02");
            return (Criteria) this;
        }

        public Criteria andPORT02Like(String value) {
            addCriterion("PORT02 like", value, "PORT02");
            return (Criteria) this;
        }

        public Criteria andPORT02NotLike(String value) {
            addCriterion("PORT02 not like", value, "PORT02");
            return (Criteria) this;
        }

        public Criteria andPORT02In(List<String> values) {
            addCriterion("PORT02 in", values, "PORT02");
            return (Criteria) this;
        }

        public Criteria andPORT02NotIn(List<String> values) {
            addCriterion("PORT02 not in", values, "PORT02");
            return (Criteria) this;
        }

        public Criteria andPORT02Between(String value1, String value2) {
            addCriterion("PORT02 between", value1, value2, "PORT02");
            return (Criteria) this;
        }

        public Criteria andPORT02NotBetween(String value1, String value2) {
            addCriterion("PORT02 not between", value1, value2, "PORT02");
            return (Criteria) this;
        }

        public Criteria andPORT03IsNull() {
            addCriterion("PORT03 is null");
            return (Criteria) this;
        }

        public Criteria andPORT03IsNotNull() {
            addCriterion("PORT03 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT03EqualTo(String value) {
            addCriterion("PORT03 =", value, "PORT03");
            return (Criteria) this;
        }

        public Criteria andPORT03NotEqualTo(String value) {
            addCriterion("PORT03 <>", value, "PORT03");
            return (Criteria) this;
        }

        public Criteria andPORT03GreaterThan(String value) {
            addCriterion("PORT03 >", value, "PORT03");
            return (Criteria) this;
        }

        public Criteria andPORT03GreaterThanOrEqualTo(String value) {
            addCriterion("PORT03 >=", value, "PORT03");
            return (Criteria) this;
        }

        public Criteria andPORT03LessThan(String value) {
            addCriterion("PORT03 <", value, "PORT03");
            return (Criteria) this;
        }

        public Criteria andPORT03LessThanOrEqualTo(String value) {
            addCriterion("PORT03 <=", value, "PORT03");
            return (Criteria) this;
        }

        public Criteria andPORT03Like(String value) {
            addCriterion("PORT03 like", value, "PORT03");
            return (Criteria) this;
        }

        public Criteria andPORT03NotLike(String value) {
            addCriterion("PORT03 not like", value, "PORT03");
            return (Criteria) this;
        }

        public Criteria andPORT03In(List<String> values) {
            addCriterion("PORT03 in", values, "PORT03");
            return (Criteria) this;
        }

        public Criteria andPORT03NotIn(List<String> values) {
            addCriterion("PORT03 not in", values, "PORT03");
            return (Criteria) this;
        }

        public Criteria andPORT03Between(String value1, String value2) {
            addCriterion("PORT03 between", value1, value2, "PORT03");
            return (Criteria) this;
        }

        public Criteria andPORT03NotBetween(String value1, String value2) {
            addCriterion("PORT03 not between", value1, value2, "PORT03");
            return (Criteria) this;
        }

        public Criteria andPORT04IsNull() {
            addCriterion("PORT04 is null");
            return (Criteria) this;
        }

        public Criteria andPORT04IsNotNull() {
            addCriterion("PORT04 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT04EqualTo(String value) {
            addCriterion("PORT04 =", value, "PORT04");
            return (Criteria) this;
        }

        public Criteria andPORT04NotEqualTo(String value) {
            addCriterion("PORT04 <>", value, "PORT04");
            return (Criteria) this;
        }

        public Criteria andPORT04GreaterThan(String value) {
            addCriterion("PORT04 >", value, "PORT04");
            return (Criteria) this;
        }

        public Criteria andPORT04GreaterThanOrEqualTo(String value) {
            addCriterion("PORT04 >=", value, "PORT04");
            return (Criteria) this;
        }

        public Criteria andPORT04LessThan(String value) {
            addCriterion("PORT04 <", value, "PORT04");
            return (Criteria) this;
        }

        public Criteria andPORT04LessThanOrEqualTo(String value) {
            addCriterion("PORT04 <=", value, "PORT04");
            return (Criteria) this;
        }

        public Criteria andPORT04Like(String value) {
            addCriterion("PORT04 like", value, "PORT04");
            return (Criteria) this;
        }

        public Criteria andPORT04NotLike(String value) {
            addCriterion("PORT04 not like", value, "PORT04");
            return (Criteria) this;
        }

        public Criteria andPORT04In(List<String> values) {
            addCriterion("PORT04 in", values, "PORT04");
            return (Criteria) this;
        }

        public Criteria andPORT04NotIn(List<String> values) {
            addCriterion("PORT04 not in", values, "PORT04");
            return (Criteria) this;
        }

        public Criteria andPORT04Between(String value1, String value2) {
            addCriterion("PORT04 between", value1, value2, "PORT04");
            return (Criteria) this;
        }

        public Criteria andPORT04NotBetween(String value1, String value2) {
            addCriterion("PORT04 not between", value1, value2, "PORT04");
            return (Criteria) this;
        }

        public Criteria andPORT05IsNull() {
            addCriterion("PORT05 is null");
            return (Criteria) this;
        }

        public Criteria andPORT05IsNotNull() {
            addCriterion("PORT05 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT05EqualTo(String value) {
            addCriterion("PORT05 =", value, "PORT05");
            return (Criteria) this;
        }

        public Criteria andPORT05NotEqualTo(String value) {
            addCriterion("PORT05 <>", value, "PORT05");
            return (Criteria) this;
        }

        public Criteria andPORT05GreaterThan(String value) {
            addCriterion("PORT05 >", value, "PORT05");
            return (Criteria) this;
        }

        public Criteria andPORT05GreaterThanOrEqualTo(String value) {
            addCriterion("PORT05 >=", value, "PORT05");
            return (Criteria) this;
        }

        public Criteria andPORT05LessThan(String value) {
            addCriterion("PORT05 <", value, "PORT05");
            return (Criteria) this;
        }

        public Criteria andPORT05LessThanOrEqualTo(String value) {
            addCriterion("PORT05 <=", value, "PORT05");
            return (Criteria) this;
        }

        public Criteria andPORT05Like(String value) {
            addCriterion("PORT05 like", value, "PORT05");
            return (Criteria) this;
        }

        public Criteria andPORT05NotLike(String value) {
            addCriterion("PORT05 not like", value, "PORT05");
            return (Criteria) this;
        }

        public Criteria andPORT05In(List<String> values) {
            addCriterion("PORT05 in", values, "PORT05");
            return (Criteria) this;
        }

        public Criteria andPORT05NotIn(List<String> values) {
            addCriterion("PORT05 not in", values, "PORT05");
            return (Criteria) this;
        }

        public Criteria andPORT05Between(String value1, String value2) {
            addCriterion("PORT05 between", value1, value2, "PORT05");
            return (Criteria) this;
        }

        public Criteria andPORT05NotBetween(String value1, String value2) {
            addCriterion("PORT05 not between", value1, value2, "PORT05");
            return (Criteria) this;
        }

        public Criteria andPORT06IsNull() {
            addCriterion("PORT06 is null");
            return (Criteria) this;
        }

        public Criteria andPORT06IsNotNull() {
            addCriterion("PORT06 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT06EqualTo(String value) {
            addCriterion("PORT06 =", value, "PORT06");
            return (Criteria) this;
        }

        public Criteria andPORT06NotEqualTo(String value) {
            addCriterion("PORT06 <>", value, "PORT06");
            return (Criteria) this;
        }

        public Criteria andPORT06GreaterThan(String value) {
            addCriterion("PORT06 >", value, "PORT06");
            return (Criteria) this;
        }

        public Criteria andPORT06GreaterThanOrEqualTo(String value) {
            addCriterion("PORT06 >=", value, "PORT06");
            return (Criteria) this;
        }

        public Criteria andPORT06LessThan(String value) {
            addCriterion("PORT06 <", value, "PORT06");
            return (Criteria) this;
        }

        public Criteria andPORT06LessThanOrEqualTo(String value) {
            addCriterion("PORT06 <=", value, "PORT06");
            return (Criteria) this;
        }

        public Criteria andPORT06Like(String value) {
            addCriterion("PORT06 like", value, "PORT06");
            return (Criteria) this;
        }

        public Criteria andPORT06NotLike(String value) {
            addCriterion("PORT06 not like", value, "PORT06");
            return (Criteria) this;
        }

        public Criteria andPORT06In(List<String> values) {
            addCriterion("PORT06 in", values, "PORT06");
            return (Criteria) this;
        }

        public Criteria andPORT06NotIn(List<String> values) {
            addCriterion("PORT06 not in", values, "PORT06");
            return (Criteria) this;
        }

        public Criteria andPORT06Between(String value1, String value2) {
            addCriterion("PORT06 between", value1, value2, "PORT06");
            return (Criteria) this;
        }

        public Criteria andPORT06NotBetween(String value1, String value2) {
            addCriterion("PORT06 not between", value1, value2, "PORT06");
            return (Criteria) this;
        }

        public Criteria andPORT07IsNull() {
            addCriterion("PORT07 is null");
            return (Criteria) this;
        }

        public Criteria andPORT07IsNotNull() {
            addCriterion("PORT07 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT07EqualTo(String value) {
            addCriterion("PORT07 =", value, "PORT07");
            return (Criteria) this;
        }

        public Criteria andPORT07NotEqualTo(String value) {
            addCriterion("PORT07 <>", value, "PORT07");
            return (Criteria) this;
        }

        public Criteria andPORT07GreaterThan(String value) {
            addCriterion("PORT07 >", value, "PORT07");
            return (Criteria) this;
        }

        public Criteria andPORT07GreaterThanOrEqualTo(String value) {
            addCriterion("PORT07 >=", value, "PORT07");
            return (Criteria) this;
        }

        public Criteria andPORT07LessThan(String value) {
            addCriterion("PORT07 <", value, "PORT07");
            return (Criteria) this;
        }

        public Criteria andPORT07LessThanOrEqualTo(String value) {
            addCriterion("PORT07 <=", value, "PORT07");
            return (Criteria) this;
        }

        public Criteria andPORT07Like(String value) {
            addCriterion("PORT07 like", value, "PORT07");
            return (Criteria) this;
        }

        public Criteria andPORT07NotLike(String value) {
            addCriterion("PORT07 not like", value, "PORT07");
            return (Criteria) this;
        }

        public Criteria andPORT07In(List<String> values) {
            addCriterion("PORT07 in", values, "PORT07");
            return (Criteria) this;
        }

        public Criteria andPORT07NotIn(List<String> values) {
            addCriterion("PORT07 not in", values, "PORT07");
            return (Criteria) this;
        }

        public Criteria andPORT07Between(String value1, String value2) {
            addCriterion("PORT07 between", value1, value2, "PORT07");
            return (Criteria) this;
        }

        public Criteria andPORT07NotBetween(String value1, String value2) {
            addCriterion("PORT07 not between", value1, value2, "PORT07");
            return (Criteria) this;
        }

        public Criteria andPORT08IsNull() {
            addCriterion("PORT08 is null");
            return (Criteria) this;
        }

        public Criteria andPORT08IsNotNull() {
            addCriterion("PORT08 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT08EqualTo(String value) {
            addCriterion("PORT08 =", value, "PORT08");
            return (Criteria) this;
        }

        public Criteria andPORT08NotEqualTo(String value) {
            addCriterion("PORT08 <>", value, "PORT08");
            return (Criteria) this;
        }

        public Criteria andPORT08GreaterThan(String value) {
            addCriterion("PORT08 >", value, "PORT08");
            return (Criteria) this;
        }

        public Criteria andPORT08GreaterThanOrEqualTo(String value) {
            addCriterion("PORT08 >=", value, "PORT08");
            return (Criteria) this;
        }

        public Criteria andPORT08LessThan(String value) {
            addCriterion("PORT08 <", value, "PORT08");
            return (Criteria) this;
        }

        public Criteria andPORT08LessThanOrEqualTo(String value) {
            addCriterion("PORT08 <=", value, "PORT08");
            return (Criteria) this;
        }

        public Criteria andPORT08Like(String value) {
            addCriterion("PORT08 like", value, "PORT08");
            return (Criteria) this;
        }

        public Criteria andPORT08NotLike(String value) {
            addCriterion("PORT08 not like", value, "PORT08");
            return (Criteria) this;
        }

        public Criteria andPORT08In(List<String> values) {
            addCriterion("PORT08 in", values, "PORT08");
            return (Criteria) this;
        }

        public Criteria andPORT08NotIn(List<String> values) {
            addCriterion("PORT08 not in", values, "PORT08");
            return (Criteria) this;
        }

        public Criteria andPORT08Between(String value1, String value2) {
            addCriterion("PORT08 between", value1, value2, "PORT08");
            return (Criteria) this;
        }

        public Criteria andPORT08NotBetween(String value1, String value2) {
            addCriterion("PORT08 not between", value1, value2, "PORT08");
            return (Criteria) this;
        }

        public Criteria andPORT09IsNull() {
            addCriterion("PORT09 is null");
            return (Criteria) this;
        }

        public Criteria andPORT09IsNotNull() {
            addCriterion("PORT09 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT09EqualTo(String value) {
            addCriterion("PORT09 =", value, "PORT09");
            return (Criteria) this;
        }

        public Criteria andPORT09NotEqualTo(String value) {
            addCriterion("PORT09 <>", value, "PORT09");
            return (Criteria) this;
        }

        public Criteria andPORT09GreaterThan(String value) {
            addCriterion("PORT09 >", value, "PORT09");
            return (Criteria) this;
        }

        public Criteria andPORT09GreaterThanOrEqualTo(String value) {
            addCriterion("PORT09 >=", value, "PORT09");
            return (Criteria) this;
        }

        public Criteria andPORT09LessThan(String value) {
            addCriterion("PORT09 <", value, "PORT09");
            return (Criteria) this;
        }

        public Criteria andPORT09LessThanOrEqualTo(String value) {
            addCriterion("PORT09 <=", value, "PORT09");
            return (Criteria) this;
        }

        public Criteria andPORT09Like(String value) {
            addCriterion("PORT09 like", value, "PORT09");
            return (Criteria) this;
        }

        public Criteria andPORT09NotLike(String value) {
            addCriterion("PORT09 not like", value, "PORT09");
            return (Criteria) this;
        }

        public Criteria andPORT09In(List<String> values) {
            addCriterion("PORT09 in", values, "PORT09");
            return (Criteria) this;
        }

        public Criteria andPORT09NotIn(List<String> values) {
            addCriterion("PORT09 not in", values, "PORT09");
            return (Criteria) this;
        }

        public Criteria andPORT09Between(String value1, String value2) {
            addCriterion("PORT09 between", value1, value2, "PORT09");
            return (Criteria) this;
        }

        public Criteria andPORT09NotBetween(String value1, String value2) {
            addCriterion("PORT09 not between", value1, value2, "PORT09");
            return (Criteria) this;
        }

        public Criteria andPORT10IsNull() {
            addCriterion("PORT10 is null");
            return (Criteria) this;
        }

        public Criteria andPORT10IsNotNull() {
            addCriterion("PORT10 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT10EqualTo(String value) {
            addCriterion("PORT10 =", value, "PORT10");
            return (Criteria) this;
        }

        public Criteria andPORT10NotEqualTo(String value) {
            addCriterion("PORT10 <>", value, "PORT10");
            return (Criteria) this;
        }

        public Criteria andPORT10GreaterThan(String value) {
            addCriterion("PORT10 >", value, "PORT10");
            return (Criteria) this;
        }

        public Criteria andPORT10GreaterThanOrEqualTo(String value) {
            addCriterion("PORT10 >=", value, "PORT10");
            return (Criteria) this;
        }

        public Criteria andPORT10LessThan(String value) {
            addCriterion("PORT10 <", value, "PORT10");
            return (Criteria) this;
        }

        public Criteria andPORT10LessThanOrEqualTo(String value) {
            addCriterion("PORT10 <=", value, "PORT10");
            return (Criteria) this;
        }

        public Criteria andPORT10Like(String value) {
            addCriterion("PORT10 like", value, "PORT10");
            return (Criteria) this;
        }

        public Criteria andPORT10NotLike(String value) {
            addCriterion("PORT10 not like", value, "PORT10");
            return (Criteria) this;
        }

        public Criteria andPORT10In(List<String> values) {
            addCriterion("PORT10 in", values, "PORT10");
            return (Criteria) this;
        }

        public Criteria andPORT10NotIn(List<String> values) {
            addCriterion("PORT10 not in", values, "PORT10");
            return (Criteria) this;
        }

        public Criteria andPORT10Between(String value1, String value2) {
            addCriterion("PORT10 between", value1, value2, "PORT10");
            return (Criteria) this;
        }

        public Criteria andPORT10NotBetween(String value1, String value2) {
            addCriterion("PORT10 not between", value1, value2, "PORT10");
            return (Criteria) this;
        }

        public Criteria andPORT11IsNull() {
            addCriterion("PORT11 is null");
            return (Criteria) this;
        }

        public Criteria andPORT11IsNotNull() {
            addCriterion("PORT11 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT11EqualTo(String value) {
            addCriterion("PORT11 =", value, "PORT11");
            return (Criteria) this;
        }

        public Criteria andPORT11NotEqualTo(String value) {
            addCriterion("PORT11 <>", value, "PORT11");
            return (Criteria) this;
        }

        public Criteria andPORT11GreaterThan(String value) {
            addCriterion("PORT11 >", value, "PORT11");
            return (Criteria) this;
        }

        public Criteria andPORT11GreaterThanOrEqualTo(String value) {
            addCriterion("PORT11 >=", value, "PORT11");
            return (Criteria) this;
        }

        public Criteria andPORT11LessThan(String value) {
            addCriterion("PORT11 <", value, "PORT11");
            return (Criteria) this;
        }

        public Criteria andPORT11LessThanOrEqualTo(String value) {
            addCriterion("PORT11 <=", value, "PORT11");
            return (Criteria) this;
        }

        public Criteria andPORT11Like(String value) {
            addCriterion("PORT11 like", value, "PORT11");
            return (Criteria) this;
        }

        public Criteria andPORT11NotLike(String value) {
            addCriterion("PORT11 not like", value, "PORT11");
            return (Criteria) this;
        }

        public Criteria andPORT11In(List<String> values) {
            addCriterion("PORT11 in", values, "PORT11");
            return (Criteria) this;
        }

        public Criteria andPORT11NotIn(List<String> values) {
            addCriterion("PORT11 not in", values, "PORT11");
            return (Criteria) this;
        }

        public Criteria andPORT11Between(String value1, String value2) {
            addCriterion("PORT11 between", value1, value2, "PORT11");
            return (Criteria) this;
        }

        public Criteria andPORT11NotBetween(String value1, String value2) {
            addCriterion("PORT11 not between", value1, value2, "PORT11");
            return (Criteria) this;
        }

        public Criteria andPORT12IsNull() {
            addCriterion("PORT12 is null");
            return (Criteria) this;
        }

        public Criteria andPORT12IsNotNull() {
            addCriterion("PORT12 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT12EqualTo(String value) {
            addCriterion("PORT12 =", value, "PORT12");
            return (Criteria) this;
        }

        public Criteria andPORT12NotEqualTo(String value) {
            addCriterion("PORT12 <>", value, "PORT12");
            return (Criteria) this;
        }

        public Criteria andPORT12GreaterThan(String value) {
            addCriterion("PORT12 >", value, "PORT12");
            return (Criteria) this;
        }

        public Criteria andPORT12GreaterThanOrEqualTo(String value) {
            addCriterion("PORT12 >=", value, "PORT12");
            return (Criteria) this;
        }

        public Criteria andPORT12LessThan(String value) {
            addCriterion("PORT12 <", value, "PORT12");
            return (Criteria) this;
        }

        public Criteria andPORT12LessThanOrEqualTo(String value) {
            addCriterion("PORT12 <=", value, "PORT12");
            return (Criteria) this;
        }

        public Criteria andPORT12Like(String value) {
            addCriterion("PORT12 like", value, "PORT12");
            return (Criteria) this;
        }

        public Criteria andPORT12NotLike(String value) {
            addCriterion("PORT12 not like", value, "PORT12");
            return (Criteria) this;
        }

        public Criteria andPORT12In(List<String> values) {
            addCriterion("PORT12 in", values, "PORT12");
            return (Criteria) this;
        }

        public Criteria andPORT12NotIn(List<String> values) {
            addCriterion("PORT12 not in", values, "PORT12");
            return (Criteria) this;
        }

        public Criteria andPORT12Between(String value1, String value2) {
            addCriterion("PORT12 between", value1, value2, "PORT12");
            return (Criteria) this;
        }

        public Criteria andPORT12NotBetween(String value1, String value2) {
            addCriterion("PORT12 not between", value1, value2, "PORT12");
            return (Criteria) this;
        }

        public Criteria andPORT13IsNull() {
            addCriterion("PORT13 is null");
            return (Criteria) this;
        }

        public Criteria andPORT13IsNotNull() {
            addCriterion("PORT13 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT13EqualTo(String value) {
            addCriterion("PORT13 =", value, "PORT13");
            return (Criteria) this;
        }

        public Criteria andPORT13NotEqualTo(String value) {
            addCriterion("PORT13 <>", value, "PORT13");
            return (Criteria) this;
        }

        public Criteria andPORT13GreaterThan(String value) {
            addCriterion("PORT13 >", value, "PORT13");
            return (Criteria) this;
        }

        public Criteria andPORT13GreaterThanOrEqualTo(String value) {
            addCriterion("PORT13 >=", value, "PORT13");
            return (Criteria) this;
        }

        public Criteria andPORT13LessThan(String value) {
            addCriterion("PORT13 <", value, "PORT13");
            return (Criteria) this;
        }

        public Criteria andPORT13LessThanOrEqualTo(String value) {
            addCriterion("PORT13 <=", value, "PORT13");
            return (Criteria) this;
        }

        public Criteria andPORT13Like(String value) {
            addCriterion("PORT13 like", value, "PORT13");
            return (Criteria) this;
        }

        public Criteria andPORT13NotLike(String value) {
            addCriterion("PORT13 not like", value, "PORT13");
            return (Criteria) this;
        }

        public Criteria andPORT13In(List<String> values) {
            addCriterion("PORT13 in", values, "PORT13");
            return (Criteria) this;
        }

        public Criteria andPORT13NotIn(List<String> values) {
            addCriterion("PORT13 not in", values, "PORT13");
            return (Criteria) this;
        }

        public Criteria andPORT13Between(String value1, String value2) {
            addCriterion("PORT13 between", value1, value2, "PORT13");
            return (Criteria) this;
        }

        public Criteria andPORT13NotBetween(String value1, String value2) {
            addCriterion("PORT13 not between", value1, value2, "PORT13");
            return (Criteria) this;
        }

        public Criteria andPORT14IsNull() {
            addCriterion("PORT14 is null");
            return (Criteria) this;
        }

        public Criteria andPORT14IsNotNull() {
            addCriterion("PORT14 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT14EqualTo(String value) {
            addCriterion("PORT14 =", value, "PORT14");
            return (Criteria) this;
        }

        public Criteria andPORT14NotEqualTo(String value) {
            addCriterion("PORT14 <>", value, "PORT14");
            return (Criteria) this;
        }

        public Criteria andPORT14GreaterThan(String value) {
            addCriterion("PORT14 >", value, "PORT14");
            return (Criteria) this;
        }

        public Criteria andPORT14GreaterThanOrEqualTo(String value) {
            addCriterion("PORT14 >=", value, "PORT14");
            return (Criteria) this;
        }

        public Criteria andPORT14LessThan(String value) {
            addCriterion("PORT14 <", value, "PORT14");
            return (Criteria) this;
        }

        public Criteria andPORT14LessThanOrEqualTo(String value) {
            addCriterion("PORT14 <=", value, "PORT14");
            return (Criteria) this;
        }

        public Criteria andPORT14Like(String value) {
            addCriterion("PORT14 like", value, "PORT14");
            return (Criteria) this;
        }

        public Criteria andPORT14NotLike(String value) {
            addCriterion("PORT14 not like", value, "PORT14");
            return (Criteria) this;
        }

        public Criteria andPORT14In(List<String> values) {
            addCriterion("PORT14 in", values, "PORT14");
            return (Criteria) this;
        }

        public Criteria andPORT14NotIn(List<String> values) {
            addCriterion("PORT14 not in", values, "PORT14");
            return (Criteria) this;
        }

        public Criteria andPORT14Between(String value1, String value2) {
            addCriterion("PORT14 between", value1, value2, "PORT14");
            return (Criteria) this;
        }

        public Criteria andPORT14NotBetween(String value1, String value2) {
            addCriterion("PORT14 not between", value1, value2, "PORT14");
            return (Criteria) this;
        }

        public Criteria andPORT15IsNull() {
            addCriterion("PORT15 is null");
            return (Criteria) this;
        }

        public Criteria andPORT15IsNotNull() {
            addCriterion("PORT15 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT15EqualTo(String value) {
            addCriterion("PORT15 =", value, "PORT15");
            return (Criteria) this;
        }

        public Criteria andPORT15NotEqualTo(String value) {
            addCriterion("PORT15 <>", value, "PORT15");
            return (Criteria) this;
        }

        public Criteria andPORT15GreaterThan(String value) {
            addCriterion("PORT15 >", value, "PORT15");
            return (Criteria) this;
        }

        public Criteria andPORT15GreaterThanOrEqualTo(String value) {
            addCriterion("PORT15 >=", value, "PORT15");
            return (Criteria) this;
        }

        public Criteria andPORT15LessThan(String value) {
            addCriterion("PORT15 <", value, "PORT15");
            return (Criteria) this;
        }

        public Criteria andPORT15LessThanOrEqualTo(String value) {
            addCriterion("PORT15 <=", value, "PORT15");
            return (Criteria) this;
        }

        public Criteria andPORT15Like(String value) {
            addCriterion("PORT15 like", value, "PORT15");
            return (Criteria) this;
        }

        public Criteria andPORT15NotLike(String value) {
            addCriterion("PORT15 not like", value, "PORT15");
            return (Criteria) this;
        }

        public Criteria andPORT15In(List<String> values) {
            addCriterion("PORT15 in", values, "PORT15");
            return (Criteria) this;
        }

        public Criteria andPORT15NotIn(List<String> values) {
            addCriterion("PORT15 not in", values, "PORT15");
            return (Criteria) this;
        }

        public Criteria andPORT15Between(String value1, String value2) {
            addCriterion("PORT15 between", value1, value2, "PORT15");
            return (Criteria) this;
        }

        public Criteria andPORT15NotBetween(String value1, String value2) {
            addCriterion("PORT15 not between", value1, value2, "PORT15");
            return (Criteria) this;
        }

        public Criteria andPORT16IsNull() {
            addCriterion("PORT16 is null");
            return (Criteria) this;
        }

        public Criteria andPORT16IsNotNull() {
            addCriterion("PORT16 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT16EqualTo(String value) {
            addCriterion("PORT16 =", value, "PORT16");
            return (Criteria) this;
        }

        public Criteria andPORT16NotEqualTo(String value) {
            addCriterion("PORT16 <>", value, "PORT16");
            return (Criteria) this;
        }

        public Criteria andPORT16GreaterThan(String value) {
            addCriterion("PORT16 >", value, "PORT16");
            return (Criteria) this;
        }

        public Criteria andPORT16GreaterThanOrEqualTo(String value) {
            addCriterion("PORT16 >=", value, "PORT16");
            return (Criteria) this;
        }

        public Criteria andPORT16LessThan(String value) {
            addCriterion("PORT16 <", value, "PORT16");
            return (Criteria) this;
        }

        public Criteria andPORT16LessThanOrEqualTo(String value) {
            addCriterion("PORT16 <=", value, "PORT16");
            return (Criteria) this;
        }

        public Criteria andPORT16Like(String value) {
            addCriterion("PORT16 like", value, "PORT16");
            return (Criteria) this;
        }

        public Criteria andPORT16NotLike(String value) {
            addCriterion("PORT16 not like", value, "PORT16");
            return (Criteria) this;
        }

        public Criteria andPORT16In(List<String> values) {
            addCriterion("PORT16 in", values, "PORT16");
            return (Criteria) this;
        }

        public Criteria andPORT16NotIn(List<String> values) {
            addCriterion("PORT16 not in", values, "PORT16");
            return (Criteria) this;
        }

        public Criteria andPORT16Between(String value1, String value2) {
            addCriterion("PORT16 between", value1, value2, "PORT16");
            return (Criteria) this;
        }

        public Criteria andPORT16NotBetween(String value1, String value2) {
            addCriterion("PORT16 not between", value1, value2, "PORT16");
            return (Criteria) this;
        }

        public Criteria andPORT17IsNull() {
            addCriterion("PORT17 is null");
            return (Criteria) this;
        }

        public Criteria andPORT17IsNotNull() {
            addCriterion("PORT17 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT17EqualTo(String value) {
            addCriterion("PORT17 =", value, "PORT17");
            return (Criteria) this;
        }

        public Criteria andPORT17NotEqualTo(String value) {
            addCriterion("PORT17 <>", value, "PORT17");
            return (Criteria) this;
        }

        public Criteria andPORT17GreaterThan(String value) {
            addCriterion("PORT17 >", value, "PORT17");
            return (Criteria) this;
        }

        public Criteria andPORT17GreaterThanOrEqualTo(String value) {
            addCriterion("PORT17 >=", value, "PORT17");
            return (Criteria) this;
        }

        public Criteria andPORT17LessThan(String value) {
            addCriterion("PORT17 <", value, "PORT17");
            return (Criteria) this;
        }

        public Criteria andPORT17LessThanOrEqualTo(String value) {
            addCriterion("PORT17 <=", value, "PORT17");
            return (Criteria) this;
        }

        public Criteria andPORT17Like(String value) {
            addCriterion("PORT17 like", value, "PORT17");
            return (Criteria) this;
        }

        public Criteria andPORT17NotLike(String value) {
            addCriterion("PORT17 not like", value, "PORT17");
            return (Criteria) this;
        }

        public Criteria andPORT17In(List<String> values) {
            addCriterion("PORT17 in", values, "PORT17");
            return (Criteria) this;
        }

        public Criteria andPORT17NotIn(List<String> values) {
            addCriterion("PORT17 not in", values, "PORT17");
            return (Criteria) this;
        }

        public Criteria andPORT17Between(String value1, String value2) {
            addCriterion("PORT17 between", value1, value2, "PORT17");
            return (Criteria) this;
        }

        public Criteria andPORT17NotBetween(String value1, String value2) {
            addCriterion("PORT17 not between", value1, value2, "PORT17");
            return (Criteria) this;
        }

        public Criteria andPORT18IsNull() {
            addCriterion("PORT18 is null");
            return (Criteria) this;
        }

        public Criteria andPORT18IsNotNull() {
            addCriterion("PORT18 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT18EqualTo(String value) {
            addCriterion("PORT18 =", value, "PORT18");
            return (Criteria) this;
        }

        public Criteria andPORT18NotEqualTo(String value) {
            addCriterion("PORT18 <>", value, "PORT18");
            return (Criteria) this;
        }

        public Criteria andPORT18GreaterThan(String value) {
            addCriterion("PORT18 >", value, "PORT18");
            return (Criteria) this;
        }

        public Criteria andPORT18GreaterThanOrEqualTo(String value) {
            addCriterion("PORT18 >=", value, "PORT18");
            return (Criteria) this;
        }

        public Criteria andPORT18LessThan(String value) {
            addCriterion("PORT18 <", value, "PORT18");
            return (Criteria) this;
        }

        public Criteria andPORT18LessThanOrEqualTo(String value) {
            addCriterion("PORT18 <=", value, "PORT18");
            return (Criteria) this;
        }

        public Criteria andPORT18Like(String value) {
            addCriterion("PORT18 like", value, "PORT18");
            return (Criteria) this;
        }

        public Criteria andPORT18NotLike(String value) {
            addCriterion("PORT18 not like", value, "PORT18");
            return (Criteria) this;
        }

        public Criteria andPORT18In(List<String> values) {
            addCriterion("PORT18 in", values, "PORT18");
            return (Criteria) this;
        }

        public Criteria andPORT18NotIn(List<String> values) {
            addCriterion("PORT18 not in", values, "PORT18");
            return (Criteria) this;
        }

        public Criteria andPORT18Between(String value1, String value2) {
            addCriterion("PORT18 between", value1, value2, "PORT18");
            return (Criteria) this;
        }

        public Criteria andPORT18NotBetween(String value1, String value2) {
            addCriterion("PORT18 not between", value1, value2, "PORT18");
            return (Criteria) this;
        }

        public Criteria andPORT19IsNull() {
            addCriterion("PORT19 is null");
            return (Criteria) this;
        }

        public Criteria andPORT19IsNotNull() {
            addCriterion("PORT19 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT19EqualTo(String value) {
            addCriterion("PORT19 =", value, "PORT19");
            return (Criteria) this;
        }

        public Criteria andPORT19NotEqualTo(String value) {
            addCriterion("PORT19 <>", value, "PORT19");
            return (Criteria) this;
        }

        public Criteria andPORT19GreaterThan(String value) {
            addCriterion("PORT19 >", value, "PORT19");
            return (Criteria) this;
        }

        public Criteria andPORT19GreaterThanOrEqualTo(String value) {
            addCriterion("PORT19 >=", value, "PORT19");
            return (Criteria) this;
        }

        public Criteria andPORT19LessThan(String value) {
            addCriterion("PORT19 <", value, "PORT19");
            return (Criteria) this;
        }

        public Criteria andPORT19LessThanOrEqualTo(String value) {
            addCriterion("PORT19 <=", value, "PORT19");
            return (Criteria) this;
        }

        public Criteria andPORT19Like(String value) {
            addCriterion("PORT19 like", value, "PORT19");
            return (Criteria) this;
        }

        public Criteria andPORT19NotLike(String value) {
            addCriterion("PORT19 not like", value, "PORT19");
            return (Criteria) this;
        }

        public Criteria andPORT19In(List<String> values) {
            addCriterion("PORT19 in", values, "PORT19");
            return (Criteria) this;
        }

        public Criteria andPORT19NotIn(List<String> values) {
            addCriterion("PORT19 not in", values, "PORT19");
            return (Criteria) this;
        }

        public Criteria andPORT19Between(String value1, String value2) {
            addCriterion("PORT19 between", value1, value2, "PORT19");
            return (Criteria) this;
        }

        public Criteria andPORT19NotBetween(String value1, String value2) {
            addCriterion("PORT19 not between", value1, value2, "PORT19");
            return (Criteria) this;
        }

        public Criteria andPORT20IsNull() {
            addCriterion("PORT20 is null");
            return (Criteria) this;
        }

        public Criteria andPORT20IsNotNull() {
            addCriterion("PORT20 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT20EqualTo(String value) {
            addCriterion("PORT20 =", value, "PORT20");
            return (Criteria) this;
        }

        public Criteria andPORT20NotEqualTo(String value) {
            addCriterion("PORT20 <>", value, "PORT20");
            return (Criteria) this;
        }

        public Criteria andPORT20GreaterThan(String value) {
            addCriterion("PORT20 >", value, "PORT20");
            return (Criteria) this;
        }

        public Criteria andPORT20GreaterThanOrEqualTo(String value) {
            addCriterion("PORT20 >=", value, "PORT20");
            return (Criteria) this;
        }

        public Criteria andPORT20LessThan(String value) {
            addCriterion("PORT20 <", value, "PORT20");
            return (Criteria) this;
        }

        public Criteria andPORT20LessThanOrEqualTo(String value) {
            addCriterion("PORT20 <=", value, "PORT20");
            return (Criteria) this;
        }

        public Criteria andPORT20Like(String value) {
            addCriterion("PORT20 like", value, "PORT20");
            return (Criteria) this;
        }

        public Criteria andPORT20NotLike(String value) {
            addCriterion("PORT20 not like", value, "PORT20");
            return (Criteria) this;
        }

        public Criteria andPORT20In(List<String> values) {
            addCriterion("PORT20 in", values, "PORT20");
            return (Criteria) this;
        }

        public Criteria andPORT20NotIn(List<String> values) {
            addCriterion("PORT20 not in", values, "PORT20");
            return (Criteria) this;
        }

        public Criteria andPORT20Between(String value1, String value2) {
            addCriterion("PORT20 between", value1, value2, "PORT20");
            return (Criteria) this;
        }

        public Criteria andPORT20NotBetween(String value1, String value2) {
            addCriterion("PORT20 not between", value1, value2, "PORT20");
            return (Criteria) this;
        }

        public Criteria andPORT21IsNull() {
            addCriterion("PORT21 is null");
            return (Criteria) this;
        }

        public Criteria andPORT21IsNotNull() {
            addCriterion("PORT21 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT21EqualTo(String value) {
            addCriterion("PORT21 =", value, "PORT21");
            return (Criteria) this;
        }

        public Criteria andPORT21NotEqualTo(String value) {
            addCriterion("PORT21 <>", value, "PORT21");
            return (Criteria) this;
        }

        public Criteria andPORT21GreaterThan(String value) {
            addCriterion("PORT21 >", value, "PORT21");
            return (Criteria) this;
        }

        public Criteria andPORT21GreaterThanOrEqualTo(String value) {
            addCriterion("PORT21 >=", value, "PORT21");
            return (Criteria) this;
        }

        public Criteria andPORT21LessThan(String value) {
            addCriterion("PORT21 <", value, "PORT21");
            return (Criteria) this;
        }

        public Criteria andPORT21LessThanOrEqualTo(String value) {
            addCriterion("PORT21 <=", value, "PORT21");
            return (Criteria) this;
        }

        public Criteria andPORT21Like(String value) {
            addCriterion("PORT21 like", value, "PORT21");
            return (Criteria) this;
        }

        public Criteria andPORT21NotLike(String value) {
            addCriterion("PORT21 not like", value, "PORT21");
            return (Criteria) this;
        }

        public Criteria andPORT21In(List<String> values) {
            addCriterion("PORT21 in", values, "PORT21");
            return (Criteria) this;
        }

        public Criteria andPORT21NotIn(List<String> values) {
            addCriterion("PORT21 not in", values, "PORT21");
            return (Criteria) this;
        }

        public Criteria andPORT21Between(String value1, String value2) {
            addCriterion("PORT21 between", value1, value2, "PORT21");
            return (Criteria) this;
        }

        public Criteria andPORT21NotBetween(String value1, String value2) {
            addCriterion("PORT21 not between", value1, value2, "PORT21");
            return (Criteria) this;
        }

        public Criteria andPORT22IsNull() {
            addCriterion("PORT22 is null");
            return (Criteria) this;
        }

        public Criteria andPORT22IsNotNull() {
            addCriterion("PORT22 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT22EqualTo(String value) {
            addCriterion("PORT22 =", value, "PORT22");
            return (Criteria) this;
        }

        public Criteria andPORT22NotEqualTo(String value) {
            addCriterion("PORT22 <>", value, "PORT22");
            return (Criteria) this;
        }

        public Criteria andPORT22GreaterThan(String value) {
            addCriterion("PORT22 >", value, "PORT22");
            return (Criteria) this;
        }

        public Criteria andPORT22GreaterThanOrEqualTo(String value) {
            addCriterion("PORT22 >=", value, "PORT22");
            return (Criteria) this;
        }

        public Criteria andPORT22LessThan(String value) {
            addCriterion("PORT22 <", value, "PORT22");
            return (Criteria) this;
        }

        public Criteria andPORT22LessThanOrEqualTo(String value) {
            addCriterion("PORT22 <=", value, "PORT22");
            return (Criteria) this;
        }

        public Criteria andPORT22Like(String value) {
            addCriterion("PORT22 like", value, "PORT22");
            return (Criteria) this;
        }

        public Criteria andPORT22NotLike(String value) {
            addCriterion("PORT22 not like", value, "PORT22");
            return (Criteria) this;
        }

        public Criteria andPORT22In(List<String> values) {
            addCriterion("PORT22 in", values, "PORT22");
            return (Criteria) this;
        }

        public Criteria andPORT22NotIn(List<String> values) {
            addCriterion("PORT22 not in", values, "PORT22");
            return (Criteria) this;
        }

        public Criteria andPORT22Between(String value1, String value2) {
            addCriterion("PORT22 between", value1, value2, "PORT22");
            return (Criteria) this;
        }

        public Criteria andPORT22NotBetween(String value1, String value2) {
            addCriterion("PORT22 not between", value1, value2, "PORT22");
            return (Criteria) this;
        }

        public Criteria andPORT23IsNull() {
            addCriterion("PORT23 is null");
            return (Criteria) this;
        }

        public Criteria andPORT23IsNotNull() {
            addCriterion("PORT23 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT23EqualTo(String value) {
            addCriterion("PORT23 =", value, "PORT23");
            return (Criteria) this;
        }

        public Criteria andPORT23NotEqualTo(String value) {
            addCriterion("PORT23 <>", value, "PORT23");
            return (Criteria) this;
        }

        public Criteria andPORT23GreaterThan(String value) {
            addCriterion("PORT23 >", value, "PORT23");
            return (Criteria) this;
        }

        public Criteria andPORT23GreaterThanOrEqualTo(String value) {
            addCriterion("PORT23 >=", value, "PORT23");
            return (Criteria) this;
        }

        public Criteria andPORT23LessThan(String value) {
            addCriterion("PORT23 <", value, "PORT23");
            return (Criteria) this;
        }

        public Criteria andPORT23LessThanOrEqualTo(String value) {
            addCriterion("PORT23 <=", value, "PORT23");
            return (Criteria) this;
        }

        public Criteria andPORT23Like(String value) {
            addCriterion("PORT23 like", value, "PORT23");
            return (Criteria) this;
        }

        public Criteria andPORT23NotLike(String value) {
            addCriterion("PORT23 not like", value, "PORT23");
            return (Criteria) this;
        }

        public Criteria andPORT23In(List<String> values) {
            addCriterion("PORT23 in", values, "PORT23");
            return (Criteria) this;
        }

        public Criteria andPORT23NotIn(List<String> values) {
            addCriterion("PORT23 not in", values, "PORT23");
            return (Criteria) this;
        }

        public Criteria andPORT23Between(String value1, String value2) {
            addCriterion("PORT23 between", value1, value2, "PORT23");
            return (Criteria) this;
        }

        public Criteria andPORT23NotBetween(String value1, String value2) {
            addCriterion("PORT23 not between", value1, value2, "PORT23");
            return (Criteria) this;
        }

        public Criteria andPORT24IsNull() {
            addCriterion("PORT24 is null");
            return (Criteria) this;
        }

        public Criteria andPORT24IsNotNull() {
            addCriterion("PORT24 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT24EqualTo(String value) {
            addCriterion("PORT24 =", value, "PORT24");
            return (Criteria) this;
        }

        public Criteria andPORT24NotEqualTo(String value) {
            addCriterion("PORT24 <>", value, "PORT24");
            return (Criteria) this;
        }

        public Criteria andPORT24GreaterThan(String value) {
            addCriterion("PORT24 >", value, "PORT24");
            return (Criteria) this;
        }

        public Criteria andPORT24GreaterThanOrEqualTo(String value) {
            addCriterion("PORT24 >=", value, "PORT24");
            return (Criteria) this;
        }

        public Criteria andPORT24LessThan(String value) {
            addCriterion("PORT24 <", value, "PORT24");
            return (Criteria) this;
        }

        public Criteria andPORT24LessThanOrEqualTo(String value) {
            addCriterion("PORT24 <=", value, "PORT24");
            return (Criteria) this;
        }

        public Criteria andPORT24Like(String value) {
            addCriterion("PORT24 like", value, "PORT24");
            return (Criteria) this;
        }

        public Criteria andPORT24NotLike(String value) {
            addCriterion("PORT24 not like", value, "PORT24");
            return (Criteria) this;
        }

        public Criteria andPORT24In(List<String> values) {
            addCriterion("PORT24 in", values, "PORT24");
            return (Criteria) this;
        }

        public Criteria andPORT24NotIn(List<String> values) {
            addCriterion("PORT24 not in", values, "PORT24");
            return (Criteria) this;
        }

        public Criteria andPORT24Between(String value1, String value2) {
            addCriterion("PORT24 between", value1, value2, "PORT24");
            return (Criteria) this;
        }

        public Criteria andPORT24NotBetween(String value1, String value2) {
            addCriterion("PORT24 not between", value1, value2, "PORT24");
            return (Criteria) this;
        }

        public Criteria andPORT25IsNull() {
            addCriterion("PORT25 is null");
            return (Criteria) this;
        }

        public Criteria andPORT25IsNotNull() {
            addCriterion("PORT25 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT25EqualTo(String value) {
            addCriterion("PORT25 =", value, "PORT25");
            return (Criteria) this;
        }

        public Criteria andPORT25NotEqualTo(String value) {
            addCriterion("PORT25 <>", value, "PORT25");
            return (Criteria) this;
        }

        public Criteria andPORT25GreaterThan(String value) {
            addCriterion("PORT25 >", value, "PORT25");
            return (Criteria) this;
        }

        public Criteria andPORT25GreaterThanOrEqualTo(String value) {
            addCriterion("PORT25 >=", value, "PORT25");
            return (Criteria) this;
        }

        public Criteria andPORT25LessThan(String value) {
            addCriterion("PORT25 <", value, "PORT25");
            return (Criteria) this;
        }

        public Criteria andPORT25LessThanOrEqualTo(String value) {
            addCriterion("PORT25 <=", value, "PORT25");
            return (Criteria) this;
        }

        public Criteria andPORT25Like(String value) {
            addCriterion("PORT25 like", value, "PORT25");
            return (Criteria) this;
        }

        public Criteria andPORT25NotLike(String value) {
            addCriterion("PORT25 not like", value, "PORT25");
            return (Criteria) this;
        }

        public Criteria andPORT25In(List<String> values) {
            addCriterion("PORT25 in", values, "PORT25");
            return (Criteria) this;
        }

        public Criteria andPORT25NotIn(List<String> values) {
            addCriterion("PORT25 not in", values, "PORT25");
            return (Criteria) this;
        }

        public Criteria andPORT25Between(String value1, String value2) {
            addCriterion("PORT25 between", value1, value2, "PORT25");
            return (Criteria) this;
        }

        public Criteria andPORT25NotBetween(String value1, String value2) {
            addCriterion("PORT25 not between", value1, value2, "PORT25");
            return (Criteria) this;
        }

        public Criteria andPORT26IsNull() {
            addCriterion("PORT26 is null");
            return (Criteria) this;
        }

        public Criteria andPORT26IsNotNull() {
            addCriterion("PORT26 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT26EqualTo(String value) {
            addCriterion("PORT26 =", value, "PORT26");
            return (Criteria) this;
        }

        public Criteria andPORT26NotEqualTo(String value) {
            addCriterion("PORT26 <>", value, "PORT26");
            return (Criteria) this;
        }

        public Criteria andPORT26GreaterThan(String value) {
            addCriterion("PORT26 >", value, "PORT26");
            return (Criteria) this;
        }

        public Criteria andPORT26GreaterThanOrEqualTo(String value) {
            addCriterion("PORT26 >=", value, "PORT26");
            return (Criteria) this;
        }

        public Criteria andPORT26LessThan(String value) {
            addCriterion("PORT26 <", value, "PORT26");
            return (Criteria) this;
        }

        public Criteria andPORT26LessThanOrEqualTo(String value) {
            addCriterion("PORT26 <=", value, "PORT26");
            return (Criteria) this;
        }

        public Criteria andPORT26Like(String value) {
            addCriterion("PORT26 like", value, "PORT26");
            return (Criteria) this;
        }

        public Criteria andPORT26NotLike(String value) {
            addCriterion("PORT26 not like", value, "PORT26");
            return (Criteria) this;
        }

        public Criteria andPORT26In(List<String> values) {
            addCriterion("PORT26 in", values, "PORT26");
            return (Criteria) this;
        }

        public Criteria andPORT26NotIn(List<String> values) {
            addCriterion("PORT26 not in", values, "PORT26");
            return (Criteria) this;
        }

        public Criteria andPORT26Between(String value1, String value2) {
            addCriterion("PORT26 between", value1, value2, "PORT26");
            return (Criteria) this;
        }

        public Criteria andPORT26NotBetween(String value1, String value2) {
            addCriterion("PORT26 not between", value1, value2, "PORT26");
            return (Criteria) this;
        }

        public Criteria andPORT27IsNull() {
            addCriterion("PORT27 is null");
            return (Criteria) this;
        }

        public Criteria andPORT27IsNotNull() {
            addCriterion("PORT27 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT27EqualTo(String value) {
            addCriterion("PORT27 =", value, "PORT27");
            return (Criteria) this;
        }

        public Criteria andPORT27NotEqualTo(String value) {
            addCriterion("PORT27 <>", value, "PORT27");
            return (Criteria) this;
        }

        public Criteria andPORT27GreaterThan(String value) {
            addCriterion("PORT27 >", value, "PORT27");
            return (Criteria) this;
        }

        public Criteria andPORT27GreaterThanOrEqualTo(String value) {
            addCriterion("PORT27 >=", value, "PORT27");
            return (Criteria) this;
        }

        public Criteria andPORT27LessThan(String value) {
            addCriterion("PORT27 <", value, "PORT27");
            return (Criteria) this;
        }

        public Criteria andPORT27LessThanOrEqualTo(String value) {
            addCriterion("PORT27 <=", value, "PORT27");
            return (Criteria) this;
        }

        public Criteria andPORT27Like(String value) {
            addCriterion("PORT27 like", value, "PORT27");
            return (Criteria) this;
        }

        public Criteria andPORT27NotLike(String value) {
            addCriterion("PORT27 not like", value, "PORT27");
            return (Criteria) this;
        }

        public Criteria andPORT27In(List<String> values) {
            addCriterion("PORT27 in", values, "PORT27");
            return (Criteria) this;
        }

        public Criteria andPORT27NotIn(List<String> values) {
            addCriterion("PORT27 not in", values, "PORT27");
            return (Criteria) this;
        }

        public Criteria andPORT27Between(String value1, String value2) {
            addCriterion("PORT27 between", value1, value2, "PORT27");
            return (Criteria) this;
        }

        public Criteria andPORT27NotBetween(String value1, String value2) {
            addCriterion("PORT27 not between", value1, value2, "PORT27");
            return (Criteria) this;
        }

        public Criteria andPORT28IsNull() {
            addCriterion("PORT28 is null");
            return (Criteria) this;
        }

        public Criteria andPORT28IsNotNull() {
            addCriterion("PORT28 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT28EqualTo(String value) {
            addCriterion("PORT28 =", value, "PORT28");
            return (Criteria) this;
        }

        public Criteria andPORT28NotEqualTo(String value) {
            addCriterion("PORT28 <>", value, "PORT28");
            return (Criteria) this;
        }

        public Criteria andPORT28GreaterThan(String value) {
            addCriterion("PORT28 >", value, "PORT28");
            return (Criteria) this;
        }

        public Criteria andPORT28GreaterThanOrEqualTo(String value) {
            addCriterion("PORT28 >=", value, "PORT28");
            return (Criteria) this;
        }

        public Criteria andPORT28LessThan(String value) {
            addCriterion("PORT28 <", value, "PORT28");
            return (Criteria) this;
        }

        public Criteria andPORT28LessThanOrEqualTo(String value) {
            addCriterion("PORT28 <=", value, "PORT28");
            return (Criteria) this;
        }

        public Criteria andPORT28Like(String value) {
            addCriterion("PORT28 like", value, "PORT28");
            return (Criteria) this;
        }

        public Criteria andPORT28NotLike(String value) {
            addCriterion("PORT28 not like", value, "PORT28");
            return (Criteria) this;
        }

        public Criteria andPORT28In(List<String> values) {
            addCriterion("PORT28 in", values, "PORT28");
            return (Criteria) this;
        }

        public Criteria andPORT28NotIn(List<String> values) {
            addCriterion("PORT28 not in", values, "PORT28");
            return (Criteria) this;
        }

        public Criteria andPORT28Between(String value1, String value2) {
            addCriterion("PORT28 between", value1, value2, "PORT28");
            return (Criteria) this;
        }

        public Criteria andPORT28NotBetween(String value1, String value2) {
            addCriterion("PORT28 not between", value1, value2, "PORT28");
            return (Criteria) this;
        }

        public Criteria andPORT29IsNull() {
            addCriterion("PORT29 is null");
            return (Criteria) this;
        }

        public Criteria andPORT29IsNotNull() {
            addCriterion("PORT29 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT29EqualTo(String value) {
            addCriterion("PORT29 =", value, "PORT29");
            return (Criteria) this;
        }

        public Criteria andPORT29NotEqualTo(String value) {
            addCriterion("PORT29 <>", value, "PORT29");
            return (Criteria) this;
        }

        public Criteria andPORT29GreaterThan(String value) {
            addCriterion("PORT29 >", value, "PORT29");
            return (Criteria) this;
        }

        public Criteria andPORT29GreaterThanOrEqualTo(String value) {
            addCriterion("PORT29 >=", value, "PORT29");
            return (Criteria) this;
        }

        public Criteria andPORT29LessThan(String value) {
            addCriterion("PORT29 <", value, "PORT29");
            return (Criteria) this;
        }

        public Criteria andPORT29LessThanOrEqualTo(String value) {
            addCriterion("PORT29 <=", value, "PORT29");
            return (Criteria) this;
        }

        public Criteria andPORT29Like(String value) {
            addCriterion("PORT29 like", value, "PORT29");
            return (Criteria) this;
        }

        public Criteria andPORT29NotLike(String value) {
            addCriterion("PORT29 not like", value, "PORT29");
            return (Criteria) this;
        }

        public Criteria andPORT29In(List<String> values) {
            addCriterion("PORT29 in", values, "PORT29");
            return (Criteria) this;
        }

        public Criteria andPORT29NotIn(List<String> values) {
            addCriterion("PORT29 not in", values, "PORT29");
            return (Criteria) this;
        }

        public Criteria andPORT29Between(String value1, String value2) {
            addCriterion("PORT29 between", value1, value2, "PORT29");
            return (Criteria) this;
        }

        public Criteria andPORT29NotBetween(String value1, String value2) {
            addCriterion("PORT29 not between", value1, value2, "PORT29");
            return (Criteria) this;
        }

        public Criteria andPORT30IsNull() {
            addCriterion("PORT30 is null");
            return (Criteria) this;
        }

        public Criteria andPORT30IsNotNull() {
            addCriterion("PORT30 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT30EqualTo(String value) {
            addCriterion("PORT30 =", value, "PORT30");
            return (Criteria) this;
        }

        public Criteria andPORT30NotEqualTo(String value) {
            addCriterion("PORT30 <>", value, "PORT30");
            return (Criteria) this;
        }

        public Criteria andPORT30GreaterThan(String value) {
            addCriterion("PORT30 >", value, "PORT30");
            return (Criteria) this;
        }

        public Criteria andPORT30GreaterThanOrEqualTo(String value) {
            addCriterion("PORT30 >=", value, "PORT30");
            return (Criteria) this;
        }

        public Criteria andPORT30LessThan(String value) {
            addCriterion("PORT30 <", value, "PORT30");
            return (Criteria) this;
        }

        public Criteria andPORT30LessThanOrEqualTo(String value) {
            addCriterion("PORT30 <=", value, "PORT30");
            return (Criteria) this;
        }

        public Criteria andPORT30Like(String value) {
            addCriterion("PORT30 like", value, "PORT30");
            return (Criteria) this;
        }

        public Criteria andPORT30NotLike(String value) {
            addCriterion("PORT30 not like", value, "PORT30");
            return (Criteria) this;
        }

        public Criteria andPORT30In(List<String> values) {
            addCriterion("PORT30 in", values, "PORT30");
            return (Criteria) this;
        }

        public Criteria andPORT30NotIn(List<String> values) {
            addCriterion("PORT30 not in", values, "PORT30");
            return (Criteria) this;
        }

        public Criteria andPORT30Between(String value1, String value2) {
            addCriterion("PORT30 between", value1, value2, "PORT30");
            return (Criteria) this;
        }

        public Criteria andPORT30NotBetween(String value1, String value2) {
            addCriterion("PORT30 not between", value1, value2, "PORT30");
            return (Criteria) this;
        }

        public Criteria andPORT31IsNull() {
            addCriterion("PORT31 is null");
            return (Criteria) this;
        }

        public Criteria andPORT31IsNotNull() {
            addCriterion("PORT31 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT31EqualTo(String value) {
            addCriterion("PORT31 =", value, "PORT31");
            return (Criteria) this;
        }

        public Criteria andPORT31NotEqualTo(String value) {
            addCriterion("PORT31 <>", value, "PORT31");
            return (Criteria) this;
        }

        public Criteria andPORT31GreaterThan(String value) {
            addCriterion("PORT31 >", value, "PORT31");
            return (Criteria) this;
        }

        public Criteria andPORT31GreaterThanOrEqualTo(String value) {
            addCriterion("PORT31 >=", value, "PORT31");
            return (Criteria) this;
        }

        public Criteria andPORT31LessThan(String value) {
            addCriterion("PORT31 <", value, "PORT31");
            return (Criteria) this;
        }

        public Criteria andPORT31LessThanOrEqualTo(String value) {
            addCriterion("PORT31 <=", value, "PORT31");
            return (Criteria) this;
        }

        public Criteria andPORT31Like(String value) {
            addCriterion("PORT31 like", value, "PORT31");
            return (Criteria) this;
        }

        public Criteria andPORT31NotLike(String value) {
            addCriterion("PORT31 not like", value, "PORT31");
            return (Criteria) this;
        }

        public Criteria andPORT31In(List<String> values) {
            addCriterion("PORT31 in", values, "PORT31");
            return (Criteria) this;
        }

        public Criteria andPORT31NotIn(List<String> values) {
            addCriterion("PORT31 not in", values, "PORT31");
            return (Criteria) this;
        }

        public Criteria andPORT31Between(String value1, String value2) {
            addCriterion("PORT31 between", value1, value2, "PORT31");
            return (Criteria) this;
        }

        public Criteria andPORT31NotBetween(String value1, String value2) {
            addCriterion("PORT31 not between", value1, value2, "PORT31");
            return (Criteria) this;
        }

        public Criteria andPORT32IsNull() {
            addCriterion("PORT32 is null");
            return (Criteria) this;
        }

        public Criteria andPORT32IsNotNull() {
            addCriterion("PORT32 is not null");
            return (Criteria) this;
        }

        public Criteria andPORT32EqualTo(String value) {
            addCriterion("PORT32 =", value, "PORT32");
            return (Criteria) this;
        }

        public Criteria andPORT32NotEqualTo(String value) {
            addCriterion("PORT32 <>", value, "PORT32");
            return (Criteria) this;
        }

        public Criteria andPORT32GreaterThan(String value) {
            addCriterion("PORT32 >", value, "PORT32");
            return (Criteria) this;
        }

        public Criteria andPORT32GreaterThanOrEqualTo(String value) {
            addCriterion("PORT32 >=", value, "PORT32");
            return (Criteria) this;
        }

        public Criteria andPORT32LessThan(String value) {
            addCriterion("PORT32 <", value, "PORT32");
            return (Criteria) this;
        }

        public Criteria andPORT32LessThanOrEqualTo(String value) {
            addCriterion("PORT32 <=", value, "PORT32");
            return (Criteria) this;
        }

        public Criteria andPORT32Like(String value) {
            addCriterion("PORT32 like", value, "PORT32");
            return (Criteria) this;
        }

        public Criteria andPORT32NotLike(String value) {
            addCriterion("PORT32 not like", value, "PORT32");
            return (Criteria) this;
        }

        public Criteria andPORT32In(List<String> values) {
            addCriterion("PORT32 in", values, "PORT32");
            return (Criteria) this;
        }

        public Criteria andPORT32NotIn(List<String> values) {
            addCriterion("PORT32 not in", values, "PORT32");
            return (Criteria) this;
        }

        public Criteria andPORT32Between(String value1, String value2) {
            addCriterion("PORT32 between", value1, value2, "PORT32");
            return (Criteria) this;
        }

        public Criteria andPORT32NotBetween(String value1, String value2) {
            addCriterion("PORT32 not between", value1, value2, "PORT32");
            return (Criteria) this;
        }

        public Criteria andFTP_USERIsNull() {
            addCriterion("FTP_USER is null");
            return (Criteria) this;
        }

        public Criteria andFTP_USERIsNotNull() {
            addCriterion("FTP_USER is not null");
            return (Criteria) this;
        }

        public Criteria andFTP_USEREqualTo(String value) {
            addCriterion("FTP_USER =", value, "FTP_USER");
            return (Criteria) this;
        }

        public Criteria andFTP_USERNotEqualTo(String value) {
            addCriterion("FTP_USER <>", value, "FTP_USER");
            return (Criteria) this;
        }

        public Criteria andFTP_USERGreaterThan(String value) {
            addCriterion("FTP_USER >", value, "FTP_USER");
            return (Criteria) this;
        }

        public Criteria andFTP_USERGreaterThanOrEqualTo(String value) {
            addCriterion("FTP_USER >=", value, "FTP_USER");
            return (Criteria) this;
        }

        public Criteria andFTP_USERLessThan(String value) {
            addCriterion("FTP_USER <", value, "FTP_USER");
            return (Criteria) this;
        }

        public Criteria andFTP_USERLessThanOrEqualTo(String value) {
            addCriterion("FTP_USER <=", value, "FTP_USER");
            return (Criteria) this;
        }

        public Criteria andFTP_USERLike(String value) {
            addCriterion("FTP_USER like", value, "FTP_USER");
            return (Criteria) this;
        }

        public Criteria andFTP_USERNotLike(String value) {
            addCriterion("FTP_USER not like", value, "FTP_USER");
            return (Criteria) this;
        }

        public Criteria andFTP_USERIn(List<String> values) {
            addCriterion("FTP_USER in", values, "FTP_USER");
            return (Criteria) this;
        }

        public Criteria andFTP_USERNotIn(List<String> values) {
            addCriterion("FTP_USER not in", values, "FTP_USER");
            return (Criteria) this;
        }

        public Criteria andFTP_USERBetween(String value1, String value2) {
            addCriterion("FTP_USER between", value1, value2, "FTP_USER");
            return (Criteria) this;
        }

        public Criteria andFTP_USERNotBetween(String value1, String value2) {
            addCriterion("FTP_USER not between", value1, value2, "FTP_USER");
            return (Criteria) this;
        }

        public Criteria andFTP_PWIsNull() {
            addCriterion("FTP_PW is null");
            return (Criteria) this;
        }

        public Criteria andFTP_PWIsNotNull() {
            addCriterion("FTP_PW is not null");
            return (Criteria) this;
        }

        public Criteria andFTP_PWEqualTo(String value) {
            addCriterion("FTP_PW =", value, "FTP_PW");
            return (Criteria) this;
        }

        public Criteria andFTP_PWNotEqualTo(String value) {
            addCriterion("FTP_PW <>", value, "FTP_PW");
            return (Criteria) this;
        }

        public Criteria andFTP_PWGreaterThan(String value) {
            addCriterion("FTP_PW >", value, "FTP_PW");
            return (Criteria) this;
        }

        public Criteria andFTP_PWGreaterThanOrEqualTo(String value) {
            addCriterion("FTP_PW >=", value, "FTP_PW");
            return (Criteria) this;
        }

        public Criteria andFTP_PWLessThan(String value) {
            addCriterion("FTP_PW <", value, "FTP_PW");
            return (Criteria) this;
        }

        public Criteria andFTP_PWLessThanOrEqualTo(String value) {
            addCriterion("FTP_PW <=", value, "FTP_PW");
            return (Criteria) this;
        }

        public Criteria andFTP_PWLike(String value) {
            addCriterion("FTP_PW like", value, "FTP_PW");
            return (Criteria) this;
        }

        public Criteria andFTP_PWNotLike(String value) {
            addCriterion("FTP_PW not like", value, "FTP_PW");
            return (Criteria) this;
        }

        public Criteria andFTP_PWIn(List<String> values) {
            addCriterion("FTP_PW in", values, "FTP_PW");
            return (Criteria) this;
        }

        public Criteria andFTP_PWNotIn(List<String> values) {
            addCriterion("FTP_PW not in", values, "FTP_PW");
            return (Criteria) this;
        }

        public Criteria andFTP_PWBetween(String value1, String value2) {
            addCriterion("FTP_PW between", value1, value2, "FTP_PW");
            return (Criteria) this;
        }

        public Criteria andFTP_PWNotBetween(String value1, String value2) {
            addCriterion("FTP_PW not between", value1, value2, "FTP_PW");
            return (Criteria) this;
        }

        public Criteria andKIKI_SETTI_TSIsNull() {
            addCriterion("KIKI_SETTI_TS is null");
            return (Criteria) this;
        }

        public Criteria andKIKI_SETTI_TSIsNotNull() {
            addCriterion("KIKI_SETTI_TS is not null");
            return (Criteria) this;
        }

        public Criteria andKIKI_SETTI_TSEqualTo(Date value) {
            addCriterion("KIKI_SETTI_TS =", value, "KIKI_SETTI_TS");
            return (Criteria) this;
        }

        public Criteria andKIKI_SETTI_TSNotEqualTo(Date value) {
            addCriterion("KIKI_SETTI_TS <>", value, "KIKI_SETTI_TS");
            return (Criteria) this;
        }

        public Criteria andKIKI_SETTI_TSGreaterThan(Date value) {
            addCriterion("KIKI_SETTI_TS >", value, "KIKI_SETTI_TS");
            return (Criteria) this;
        }

        public Criteria andKIKI_SETTI_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("KIKI_SETTI_TS >=", value, "KIKI_SETTI_TS");
            return (Criteria) this;
        }

        public Criteria andKIKI_SETTI_TSLessThan(Date value) {
            addCriterion("KIKI_SETTI_TS <", value, "KIKI_SETTI_TS");
            return (Criteria) this;
        }

        public Criteria andKIKI_SETTI_TSLessThanOrEqualTo(Date value) {
            addCriterion("KIKI_SETTI_TS <=", value, "KIKI_SETTI_TS");
            return (Criteria) this;
        }

        public Criteria andKIKI_SETTI_TSIn(List<Date> values) {
            addCriterion("KIKI_SETTI_TS in", values, "KIKI_SETTI_TS");
            return (Criteria) this;
        }

        public Criteria andKIKI_SETTI_TSNotIn(List<Date> values) {
            addCriterion("KIKI_SETTI_TS not in", values, "KIKI_SETTI_TS");
            return (Criteria) this;
        }

        public Criteria andKIKI_SETTI_TSBetween(Date value1, Date value2) {
            addCriterion("KIKI_SETTI_TS between", value1, value2, "KIKI_SETTI_TS");
            return (Criteria) this;
        }

        public Criteria andKIKI_SETTI_TSNotBetween(Date value1, Date value2) {
            addCriterion("KIKI_SETTI_TS not between", value1, value2, "KIKI_SETTI_TS");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_TSIsNull() {
            addCriterion("KIKI_CNG_TS is null");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_TSIsNotNull() {
            addCriterion("KIKI_CNG_TS is not null");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_TSEqualTo(Date value) {
            addCriterion("KIKI_CNG_TS =", value, "KIKI_CNG_TS");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_TSNotEqualTo(Date value) {
            addCriterion("KIKI_CNG_TS <>", value, "KIKI_CNG_TS");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_TSGreaterThan(Date value) {
            addCriterion("KIKI_CNG_TS >", value, "KIKI_CNG_TS");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("KIKI_CNG_TS >=", value, "KIKI_CNG_TS");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_TSLessThan(Date value) {
            addCriterion("KIKI_CNG_TS <", value, "KIKI_CNG_TS");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_TSLessThanOrEqualTo(Date value) {
            addCriterion("KIKI_CNG_TS <=", value, "KIKI_CNG_TS");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_TSIn(List<Date> values) {
            addCriterion("KIKI_CNG_TS in", values, "KIKI_CNG_TS");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_TSNotIn(List<Date> values) {
            addCriterion("KIKI_CNG_TS not in", values, "KIKI_CNG_TS");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_TSBetween(Date value1, Date value2) {
            addCriterion("KIKI_CNG_TS between", value1, value2, "KIKI_CNG_TS");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_TSNotBetween(Date value1, Date value2) {
            addCriterion("KIKI_CNG_TS not between", value1, value2, "KIKI_CNG_TS");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_SYUUKIIsNull() {
            addCriterion("KIKI_CNG_SYUUKI is null");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_SYUUKIIsNotNull() {
            addCriterion("KIKI_CNG_SYUUKI is not null");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_SYUUKIEqualTo(String value) {
            addCriterion("KIKI_CNG_SYUUKI =", value, "KIKI_CNG_SYUUKI");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_SYUUKINotEqualTo(String value) {
            addCriterion("KIKI_CNG_SYUUKI <>", value, "KIKI_CNG_SYUUKI");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_SYUUKIGreaterThan(String value) {
            addCriterion("KIKI_CNG_SYUUKI >", value, "KIKI_CNG_SYUUKI");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_SYUUKIGreaterThanOrEqualTo(String value) {
            addCriterion("KIKI_CNG_SYUUKI >=", value, "KIKI_CNG_SYUUKI");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_SYUUKILessThan(String value) {
            addCriterion("KIKI_CNG_SYUUKI <", value, "KIKI_CNG_SYUUKI");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_SYUUKILessThanOrEqualTo(String value) {
            addCriterion("KIKI_CNG_SYUUKI <=", value, "KIKI_CNG_SYUUKI");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_SYUUKILike(String value) {
            addCriterion("KIKI_CNG_SYUUKI like", value, "KIKI_CNG_SYUUKI");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_SYUUKINotLike(String value) {
            addCriterion("KIKI_CNG_SYUUKI not like", value, "KIKI_CNG_SYUUKI");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_SYUUKIIn(List<String> values) {
            addCriterion("KIKI_CNG_SYUUKI in", values, "KIKI_CNG_SYUUKI");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_SYUUKINotIn(List<String> values) {
            addCriterion("KIKI_CNG_SYUUKI not in", values, "KIKI_CNG_SYUUKI");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_SYUUKIBetween(String value1, String value2) {
            addCriterion("KIKI_CNG_SYUUKI between", value1, value2, "KIKI_CNG_SYUUKI");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_SYUUKINotBetween(String value1, String value2) {
            addCriterion("KIKI_CNG_SYUUKI not between", value1, value2, "KIKI_CNG_SYUUKI");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_YOTEIIsNull() {
            addCriterion("KIKI_CNG_YOTEI is null");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_YOTEIIsNotNull() {
            addCriterion("KIKI_CNG_YOTEI is not null");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_YOTEIEqualTo(Date value) {
            addCriterion("KIKI_CNG_YOTEI =", value, "KIKI_CNG_YOTEI");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_YOTEINotEqualTo(Date value) {
            addCriterion("KIKI_CNG_YOTEI <>", value, "KIKI_CNG_YOTEI");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_YOTEIGreaterThan(Date value) {
            addCriterion("KIKI_CNG_YOTEI >", value, "KIKI_CNG_YOTEI");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_YOTEIGreaterThanOrEqualTo(Date value) {
            addCriterion("KIKI_CNG_YOTEI >=", value, "KIKI_CNG_YOTEI");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_YOTEILessThan(Date value) {
            addCriterion("KIKI_CNG_YOTEI <", value, "KIKI_CNG_YOTEI");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_YOTEILessThanOrEqualTo(Date value) {
            addCriterion("KIKI_CNG_YOTEI <=", value, "KIKI_CNG_YOTEI");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_YOTEIIn(List<Date> values) {
            addCriterion("KIKI_CNG_YOTEI in", values, "KIKI_CNG_YOTEI");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_YOTEINotIn(List<Date> values) {
            addCriterion("KIKI_CNG_YOTEI not in", values, "KIKI_CNG_YOTEI");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_YOTEIBetween(Date value1, Date value2) {
            addCriterion("KIKI_CNG_YOTEI between", value1, value2, "KIKI_CNG_YOTEI");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_YOTEINotBetween(Date value1, Date value2) {
            addCriterion("KIKI_CNG_YOTEI not between", value1, value2, "KIKI_CNG_YOTEI");
            return (Criteria) this;
        }

        public Criteria andRM_YUUKOU_FLGIsNull() {
            addCriterion("RM_YUUKOU_FLG is null");
            return (Criteria) this;
        }

        public Criteria andRM_YUUKOU_FLGIsNotNull() {
            addCriterion("RM_YUUKOU_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andRM_YUUKOU_FLGEqualTo(String value) {
            addCriterion("RM_YUUKOU_FLG =", value, "RM_YUUKOU_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_YUUKOU_FLGNotEqualTo(String value) {
            addCriterion("RM_YUUKOU_FLG <>", value, "RM_YUUKOU_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_YUUKOU_FLGGreaterThan(String value) {
            addCriterion("RM_YUUKOU_FLG >", value, "RM_YUUKOU_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_YUUKOU_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("RM_YUUKOU_FLG >=", value, "RM_YUUKOU_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_YUUKOU_FLGLessThan(String value) {
            addCriterion("RM_YUUKOU_FLG <", value, "RM_YUUKOU_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_YUUKOU_FLGLessThanOrEqualTo(String value) {
            addCriterion("RM_YUUKOU_FLG <=", value, "RM_YUUKOU_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_YUUKOU_FLGLike(String value) {
            addCriterion("RM_YUUKOU_FLG like", value, "RM_YUUKOU_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_YUUKOU_FLGNotLike(String value) {
            addCriterion("RM_YUUKOU_FLG not like", value, "RM_YUUKOU_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_YUUKOU_FLGIn(List<String> values) {
            addCriterion("RM_YUUKOU_FLG in", values, "RM_YUUKOU_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_YUUKOU_FLGNotIn(List<String> values) {
            addCriterion("RM_YUUKOU_FLG not in", values, "RM_YUUKOU_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_YUUKOU_FLGBetween(String value1, String value2) {
            addCriterion("RM_YUUKOU_FLG between", value1, value2, "RM_YUUKOU_FLG");
            return (Criteria) this;
        }

        public Criteria andRM_YUUKOU_FLGNotBetween(String value1, String value2) {
            addCriterion("RM_YUUKOU_FLG not between", value1, value2, "RM_YUUKOU_FLG");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_GROUPIsNull() {
            addCriterion("LN_DEV_GROUP is null");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_GROUPIsNotNull() {
            addCriterion("LN_DEV_GROUP is not null");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_GROUPEqualTo(String value) {
            addCriterion("LN_DEV_GROUP =", value, "LN_DEV_GROUP");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_GROUPNotEqualTo(String value) {
            addCriterion("LN_DEV_GROUP <>", value, "LN_DEV_GROUP");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_GROUPGreaterThan(String value) {
            addCriterion("LN_DEV_GROUP >", value, "LN_DEV_GROUP");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_GROUPGreaterThanOrEqualTo(String value) {
            addCriterion("LN_DEV_GROUP >=", value, "LN_DEV_GROUP");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_GROUPLessThan(String value) {
            addCriterion("LN_DEV_GROUP <", value, "LN_DEV_GROUP");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_GROUPLessThanOrEqualTo(String value) {
            addCriterion("LN_DEV_GROUP <=", value, "LN_DEV_GROUP");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_GROUPLike(String value) {
            addCriterion("LN_DEV_GROUP like", value, "LN_DEV_GROUP");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_GROUPNotLike(String value) {
            addCriterion("LN_DEV_GROUP not like", value, "LN_DEV_GROUP");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_GROUPIn(List<String> values) {
            addCriterion("LN_DEV_GROUP in", values, "LN_DEV_GROUP");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_GROUPNotIn(List<String> values) {
            addCriterion("LN_DEV_GROUP not in", values, "LN_DEV_GROUP");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_GROUPBetween(String value1, String value2) {
            addCriterion("LN_DEV_GROUP between", value1, value2, "LN_DEV_GROUP");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_GROUPNotBetween(String value1, String value2) {
            addCriterion("LN_DEV_GROUP not between", value1, value2, "LN_DEV_GROUP");
            return (Criteria) this;
        }

        public Criteria andRMT_FLGIsNull() {
            addCriterion("RMT_FLG is null");
            return (Criteria) this;
        }

        public Criteria andRMT_FLGIsNotNull() {
            addCriterion("RMT_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andRMT_FLGEqualTo(String value) {
            addCriterion("RMT_FLG =", value, "RMT_FLG");
            return (Criteria) this;
        }

        public Criteria andRMT_FLGNotEqualTo(String value) {
            addCriterion("RMT_FLG <>", value, "RMT_FLG");
            return (Criteria) this;
        }

        public Criteria andRMT_FLGGreaterThan(String value) {
            addCriterion("RMT_FLG >", value, "RMT_FLG");
            return (Criteria) this;
        }

        public Criteria andRMT_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("RMT_FLG >=", value, "RMT_FLG");
            return (Criteria) this;
        }

        public Criteria andRMT_FLGLessThan(String value) {
            addCriterion("RMT_FLG <", value, "RMT_FLG");
            return (Criteria) this;
        }

        public Criteria andRMT_FLGLessThanOrEqualTo(String value) {
            addCriterion("RMT_FLG <=", value, "RMT_FLG");
            return (Criteria) this;
        }

        public Criteria andRMT_FLGLike(String value) {
            addCriterion("RMT_FLG like", value, "RMT_FLG");
            return (Criteria) this;
        }

        public Criteria andRMT_FLGNotLike(String value) {
            addCriterion("RMT_FLG not like", value, "RMT_FLG");
            return (Criteria) this;
        }

        public Criteria andRMT_FLGIn(List<String> values) {
            addCriterion("RMT_FLG in", values, "RMT_FLG");
            return (Criteria) this;
        }

        public Criteria andRMT_FLGNotIn(List<String> values) {
            addCriterion("RMT_FLG not in", values, "RMT_FLG");
            return (Criteria) this;
        }

        public Criteria andRMT_FLGBetween(String value1, String value2) {
            addCriterion("RMT_FLG between", value1, value2, "RMT_FLG");
            return (Criteria) this;
        }

        public Criteria andRMT_FLGNotBetween(String value1, String value2) {
            addCriterion("RMT_FLG not between", value1, value2, "RMT_FLG");
            return (Criteria) this;
        }

        public Criteria andRMT_ENABLE_TIMEIsNull() {
            addCriterion("RMT_ENABLE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andRMT_ENABLE_TIMEIsNotNull() {
            addCriterion("RMT_ENABLE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andRMT_ENABLE_TIMEEqualTo(String value) {
            addCriterion("RMT_ENABLE_TIME =", value, "RMT_ENABLE_TIME");
            return (Criteria) this;
        }

        public Criteria andRMT_ENABLE_TIMENotEqualTo(String value) {
            addCriterion("RMT_ENABLE_TIME <>", value, "RMT_ENABLE_TIME");
            return (Criteria) this;
        }

        public Criteria andRMT_ENABLE_TIMEGreaterThan(String value) {
            addCriterion("RMT_ENABLE_TIME >", value, "RMT_ENABLE_TIME");
            return (Criteria) this;
        }

        public Criteria andRMT_ENABLE_TIMEGreaterThanOrEqualTo(String value) {
            addCriterion("RMT_ENABLE_TIME >=", value, "RMT_ENABLE_TIME");
            return (Criteria) this;
        }

        public Criteria andRMT_ENABLE_TIMELessThan(String value) {
            addCriterion("RMT_ENABLE_TIME <", value, "RMT_ENABLE_TIME");
            return (Criteria) this;
        }

        public Criteria andRMT_ENABLE_TIMELessThanOrEqualTo(String value) {
            addCriterion("RMT_ENABLE_TIME <=", value, "RMT_ENABLE_TIME");
            return (Criteria) this;
        }

        public Criteria andRMT_ENABLE_TIMELike(String value) {
            addCriterion("RMT_ENABLE_TIME like", value, "RMT_ENABLE_TIME");
            return (Criteria) this;
        }

        public Criteria andRMT_ENABLE_TIMENotLike(String value) {
            addCriterion("RMT_ENABLE_TIME not like", value, "RMT_ENABLE_TIME");
            return (Criteria) this;
        }

        public Criteria andRMT_ENABLE_TIMEIn(List<String> values) {
            addCriterion("RMT_ENABLE_TIME in", values, "RMT_ENABLE_TIME");
            return (Criteria) this;
        }

        public Criteria andRMT_ENABLE_TIMENotIn(List<String> values) {
            addCriterion("RMT_ENABLE_TIME not in", values, "RMT_ENABLE_TIME");
            return (Criteria) this;
        }

        public Criteria andRMT_ENABLE_TIMEBetween(String value1, String value2) {
            addCriterion("RMT_ENABLE_TIME between", value1, value2, "RMT_ENABLE_TIME");
            return (Criteria) this;
        }

        public Criteria andRMT_ENABLE_TIMENotBetween(String value1, String value2) {
            addCriterion("RMT_ENABLE_TIME not between", value1, value2, "RMT_ENABLE_TIME");
            return (Criteria) this;
        }

        public Criteria andRMT_DEV_NMIsNull() {
            addCriterion("RMT_DEV_NM is null");
            return (Criteria) this;
        }

        public Criteria andRMT_DEV_NMIsNotNull() {
            addCriterion("RMT_DEV_NM is not null");
            return (Criteria) this;
        }

        public Criteria andRMT_DEV_NMEqualTo(String value) {
            addCriterion("RMT_DEV_NM =", value, "RMT_DEV_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_DEV_NMNotEqualTo(String value) {
            addCriterion("RMT_DEV_NM <>", value, "RMT_DEV_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_DEV_NMGreaterThan(String value) {
            addCriterion("RMT_DEV_NM >", value, "RMT_DEV_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_DEV_NMGreaterThanOrEqualTo(String value) {
            addCriterion("RMT_DEV_NM >=", value, "RMT_DEV_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_DEV_NMLessThan(String value) {
            addCriterion("RMT_DEV_NM <", value, "RMT_DEV_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_DEV_NMLessThanOrEqualTo(String value) {
            addCriterion("RMT_DEV_NM <=", value, "RMT_DEV_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_DEV_NMLike(String value) {
            addCriterion("RMT_DEV_NM like", value, "RMT_DEV_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_DEV_NMNotLike(String value) {
            addCriterion("RMT_DEV_NM not like", value, "RMT_DEV_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_DEV_NMIn(List<String> values) {
            addCriterion("RMT_DEV_NM in", values, "RMT_DEV_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_DEV_NMNotIn(List<String> values) {
            addCriterion("RMT_DEV_NM not in", values, "RMT_DEV_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_DEV_NMBetween(String value1, String value2) {
            addCriterion("RMT_DEV_NM between", value1, value2, "RMT_DEV_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_DEV_NMNotBetween(String value1, String value2) {
            addCriterion("RMT_DEV_NM not between", value1, value2, "RMT_DEV_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_ON_NMIsNull() {
            addCriterion("RMT_ON_NM is null");
            return (Criteria) this;
        }

        public Criteria andRMT_ON_NMIsNotNull() {
            addCriterion("RMT_ON_NM is not null");
            return (Criteria) this;
        }

        public Criteria andRMT_ON_NMEqualTo(String value) {
            addCriterion("RMT_ON_NM =", value, "RMT_ON_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_ON_NMNotEqualTo(String value) {
            addCriterion("RMT_ON_NM <>", value, "RMT_ON_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_ON_NMGreaterThan(String value) {
            addCriterion("RMT_ON_NM >", value, "RMT_ON_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_ON_NMGreaterThanOrEqualTo(String value) {
            addCriterion("RMT_ON_NM >=", value, "RMT_ON_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_ON_NMLessThan(String value) {
            addCriterion("RMT_ON_NM <", value, "RMT_ON_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_ON_NMLessThanOrEqualTo(String value) {
            addCriterion("RMT_ON_NM <=", value, "RMT_ON_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_ON_NMLike(String value) {
            addCriterion("RMT_ON_NM like", value, "RMT_ON_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_ON_NMNotLike(String value) {
            addCriterion("RMT_ON_NM not like", value, "RMT_ON_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_ON_NMIn(List<String> values) {
            addCriterion("RMT_ON_NM in", values, "RMT_ON_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_ON_NMNotIn(List<String> values) {
            addCriterion("RMT_ON_NM not in", values, "RMT_ON_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_ON_NMBetween(String value1, String value2) {
            addCriterion("RMT_ON_NM between", value1, value2, "RMT_ON_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_ON_NMNotBetween(String value1, String value2) {
            addCriterion("RMT_ON_NM not between", value1, value2, "RMT_ON_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_OFF_NMIsNull() {
            addCriterion("RMT_OFF_NM is null");
            return (Criteria) this;
        }

        public Criteria andRMT_OFF_NMIsNotNull() {
            addCriterion("RMT_OFF_NM is not null");
            return (Criteria) this;
        }

        public Criteria andRMT_OFF_NMEqualTo(String value) {
            addCriterion("RMT_OFF_NM =", value, "RMT_OFF_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_OFF_NMNotEqualTo(String value) {
            addCriterion("RMT_OFF_NM <>", value, "RMT_OFF_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_OFF_NMGreaterThan(String value) {
            addCriterion("RMT_OFF_NM >", value, "RMT_OFF_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_OFF_NMGreaterThanOrEqualTo(String value) {
            addCriterion("RMT_OFF_NM >=", value, "RMT_OFF_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_OFF_NMLessThan(String value) {
            addCriterion("RMT_OFF_NM <", value, "RMT_OFF_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_OFF_NMLessThanOrEqualTo(String value) {
            addCriterion("RMT_OFF_NM <=", value, "RMT_OFF_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_OFF_NMLike(String value) {
            addCriterion("RMT_OFF_NM like", value, "RMT_OFF_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_OFF_NMNotLike(String value) {
            addCriterion("RMT_OFF_NM not like", value, "RMT_OFF_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_OFF_NMIn(List<String> values) {
            addCriterion("RMT_OFF_NM in", values, "RMT_OFF_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_OFF_NMNotIn(List<String> values) {
            addCriterion("RMT_OFF_NM not in", values, "RMT_OFF_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_OFF_NMBetween(String value1, String value2) {
            addCriterion("RMT_OFF_NM between", value1, value2, "RMT_OFF_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_OFF_NMNotBetween(String value1, String value2) {
            addCriterion("RMT_OFF_NM not between", value1, value2, "RMT_OFF_NM");
            return (Criteria) this;
        }

        public Criteria andKBI_NUMIsNull() {
            addCriterion("KBI_NUM is null");
            return (Criteria) this;
        }

        public Criteria andKBI_NUMIsNotNull() {
            addCriterion("KBI_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andKBI_NUMEqualTo(String value) {
            addCriterion("KBI_NUM =", value, "KBI_NUM");
            return (Criteria) this;
        }

        public Criteria andKBI_NUMNotEqualTo(String value) {
            addCriterion("KBI_NUM <>", value, "KBI_NUM");
            return (Criteria) this;
        }

        public Criteria andKBI_NUMGreaterThan(String value) {
            addCriterion("KBI_NUM >", value, "KBI_NUM");
            return (Criteria) this;
        }

        public Criteria andKBI_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("KBI_NUM >=", value, "KBI_NUM");
            return (Criteria) this;
        }

        public Criteria andKBI_NUMLessThan(String value) {
            addCriterion("KBI_NUM <", value, "KBI_NUM");
            return (Criteria) this;
        }

        public Criteria andKBI_NUMLessThanOrEqualTo(String value) {
            addCriterion("KBI_NUM <=", value, "KBI_NUM");
            return (Criteria) this;
        }

        public Criteria andKBI_NUMLike(String value) {
            addCriterion("KBI_NUM like", value, "KBI_NUM");
            return (Criteria) this;
        }

        public Criteria andKBI_NUMNotLike(String value) {
            addCriterion("KBI_NUM not like", value, "KBI_NUM");
            return (Criteria) this;
        }

        public Criteria andKBI_NUMIn(List<String> values) {
            addCriterion("KBI_NUM in", values, "KBI_NUM");
            return (Criteria) this;
        }

        public Criteria andKBI_NUMNotIn(List<String> values) {
            addCriterion("KBI_NUM not in", values, "KBI_NUM");
            return (Criteria) this;
        }

        public Criteria andKBI_NUMBetween(String value1, String value2) {
            addCriterion("KBI_NUM between", value1, value2, "KBI_NUM");
            return (Criteria) this;
        }

        public Criteria andKBI_NUMNotBetween(String value1, String value2) {
            addCriterion("KBI_NUM not between", value1, value2, "KBI_NUM");
            return (Criteria) this;
        }

        public Criteria andSOUSA_KINDIsNull() {
            addCriterion("SOUSA_KIND is null");
            return (Criteria) this;
        }

        public Criteria andSOUSA_KINDIsNotNull() {
            addCriterion("SOUSA_KIND is not null");
            return (Criteria) this;
        }

        public Criteria andSOUSA_KINDEqualTo(String value) {
            addCriterion("SOUSA_KIND =", value, "SOUSA_KIND");
            return (Criteria) this;
        }

        public Criteria andSOUSA_KINDNotEqualTo(String value) {
            addCriterion("SOUSA_KIND <>", value, "SOUSA_KIND");
            return (Criteria) this;
        }

        public Criteria andSOUSA_KINDGreaterThan(String value) {
            addCriterion("SOUSA_KIND >", value, "SOUSA_KIND");
            return (Criteria) this;
        }

        public Criteria andSOUSA_KINDGreaterThanOrEqualTo(String value) {
            addCriterion("SOUSA_KIND >=", value, "SOUSA_KIND");
            return (Criteria) this;
        }

        public Criteria andSOUSA_KINDLessThan(String value) {
            addCriterion("SOUSA_KIND <", value, "SOUSA_KIND");
            return (Criteria) this;
        }

        public Criteria andSOUSA_KINDLessThanOrEqualTo(String value) {
            addCriterion("SOUSA_KIND <=", value, "SOUSA_KIND");
            return (Criteria) this;
        }

        public Criteria andSOUSA_KINDLike(String value) {
            addCriterion("SOUSA_KIND like", value, "SOUSA_KIND");
            return (Criteria) this;
        }

        public Criteria andSOUSA_KINDNotLike(String value) {
            addCriterion("SOUSA_KIND not like", value, "SOUSA_KIND");
            return (Criteria) this;
        }

        public Criteria andSOUSA_KINDIn(List<String> values) {
            addCriterion("SOUSA_KIND in", values, "SOUSA_KIND");
            return (Criteria) this;
        }

        public Criteria andSOUSA_KINDNotIn(List<String> values) {
            addCriterion("SOUSA_KIND not in", values, "SOUSA_KIND");
            return (Criteria) this;
        }

        public Criteria andSOUSA_KINDBetween(String value1, String value2) {
            addCriterion("SOUSA_KIND between", value1, value2, "SOUSA_KIND");
            return (Criteria) this;
        }

        public Criteria andSOUSA_KINDNotBetween(String value1, String value2) {
            addCriterion("SOUSA_KIND not between", value1, value2, "SOUSA_KIND");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andLN_JIANLikeInsensitive(String value) {
            addCriterion("upper(LN_JIAN) like", value.toUpperCase(), "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_UPPER_CONENCT_DEVLikeInsensitive(String value) {
            addCriterion("upper(LN_UPPER_CONENCT_DEV) like", value.toUpperCase(), "LN_UPPER_CONENCT_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_BUKKENLikeInsensitive(String value) {
            addCriterion("upper(LN_BUKKEN) like", value.toUpperCase(), "LN_BUKKEN");
            return (Criteria) this;
        }

        public Criteria andDEV_VERSIONLikeInsensitive(String value) {
            addCriterion("upper(DEV_VERSION) like", value.toUpperCase(), "DEV_VERSION");
            return (Criteria) this;
        }

        public Criteria andDEV_SERIAL_NUMLikeInsensitive(String value) {
            addCriterion("upper(DEV_SERIAL_NUM) like", value.toUpperCase(), "DEV_SERIAL_NUM");
            return (Criteria) this;
        }

        public Criteria andDEV_MODELLikeInsensitive(String value) {
            addCriterion("upper(DEV_MODEL) like", value.toUpperCase(), "DEV_MODEL");
            return (Criteria) this;
        }

        public Criteria andDEV_NMLikeInsensitive(String value) {
            addCriterion("upper(DEV_NM) like", value.toUpperCase(), "DEV_NM");
            return (Criteria) this;
        }

        public Criteria andDEV_KIND_IDLikeInsensitive(String value) {
            addCriterion("upper(DEV_KIND_ID) like", value.toUpperCase(), "DEV_KIND_ID");
            return (Criteria) this;
        }

        public Criteria andCHIKULikeInsensitive(String value) {
            addCriterion("upper(CHIKU) like", value.toUpperCase(), "CHIKU");
            return (Criteria) this;
        }

        public Criteria andDEV_NUMLikeInsensitive(String value) {
            addCriterion("upper(DEV_NUM) like", value.toUpperCase(), "DEV_NUM");
            return (Criteria) this;
        }

        public Criteria andSD_SENSOR_GRP_NUMLikeInsensitive(String value) {
            addCriterion("upper(SD_SENSOR_GRP_NUM) like", value.toUpperCase(), "SD_SENSOR_GRP_NUM");
            return (Criteria) this;
        }

        public Criteria andSD_SYUHEN_NUMLikeInsensitive(String value) {
            addCriterion("upper(SD_SYUHEN_NUM) like", value.toUpperCase(), "SD_SYUHEN_NUM");
            return (Criteria) this;
        }

        public Criteria andSD_SINDENSOU_ADDRLikeInsensitive(String value) {
            addCriterion("upper(SD_SINDENSOU_ADDR) like", value.toUpperCase(), "SD_SINDENSOU_ADDR");
            return (Criteria) this;
        }

        public Criteria andSD_SPEAKER_FLGLikeInsensitive(String value) {
            addCriterion("upper(SD_SPEAKER_FLG) like", value.toUpperCase(), "SD_SPEAKER_FLG");
            return (Criteria) this;
        }

        public Criteria andSETTEN_NUMLikeInsensitive(String value) {
            addCriterion("upper(SETTEN_NUM) like", value.toUpperCase(), "SETTEN_NUM");
            return (Criteria) this;
        }

        public Criteria andPORT01LikeInsensitive(String value) {
            addCriterion("upper(PORT01) like", value.toUpperCase(), "PORT01");
            return (Criteria) this;
        }

        public Criteria andPORT02LikeInsensitive(String value) {
            addCriterion("upper(PORT02) like", value.toUpperCase(), "PORT02");
            return (Criteria) this;
        }

        public Criteria andPORT03LikeInsensitive(String value) {
            addCriterion("upper(PORT03) like", value.toUpperCase(), "PORT03");
            return (Criteria) this;
        }

        public Criteria andPORT04LikeInsensitive(String value) {
            addCriterion("upper(PORT04) like", value.toUpperCase(), "PORT04");
            return (Criteria) this;
        }

        public Criteria andPORT05LikeInsensitive(String value) {
            addCriterion("upper(PORT05) like", value.toUpperCase(), "PORT05");
            return (Criteria) this;
        }

        public Criteria andPORT06LikeInsensitive(String value) {
            addCriterion("upper(PORT06) like", value.toUpperCase(), "PORT06");
            return (Criteria) this;
        }

        public Criteria andPORT07LikeInsensitive(String value) {
            addCriterion("upper(PORT07) like", value.toUpperCase(), "PORT07");
            return (Criteria) this;
        }

        public Criteria andPORT08LikeInsensitive(String value) {
            addCriterion("upper(PORT08) like", value.toUpperCase(), "PORT08");
            return (Criteria) this;
        }

        public Criteria andPORT09LikeInsensitive(String value) {
            addCriterion("upper(PORT09) like", value.toUpperCase(), "PORT09");
            return (Criteria) this;
        }

        public Criteria andPORT10LikeInsensitive(String value) {
            addCriterion("upper(PORT10) like", value.toUpperCase(), "PORT10");
            return (Criteria) this;
        }

        public Criteria andPORT11LikeInsensitive(String value) {
            addCriterion("upper(PORT11) like", value.toUpperCase(), "PORT11");
            return (Criteria) this;
        }

        public Criteria andPORT12LikeInsensitive(String value) {
            addCriterion("upper(PORT12) like", value.toUpperCase(), "PORT12");
            return (Criteria) this;
        }

        public Criteria andPORT13LikeInsensitive(String value) {
            addCriterion("upper(PORT13) like", value.toUpperCase(), "PORT13");
            return (Criteria) this;
        }

        public Criteria andPORT14LikeInsensitive(String value) {
            addCriterion("upper(PORT14) like", value.toUpperCase(), "PORT14");
            return (Criteria) this;
        }

        public Criteria andPORT15LikeInsensitive(String value) {
            addCriterion("upper(PORT15) like", value.toUpperCase(), "PORT15");
            return (Criteria) this;
        }

        public Criteria andPORT16LikeInsensitive(String value) {
            addCriterion("upper(PORT16) like", value.toUpperCase(), "PORT16");
            return (Criteria) this;
        }

        public Criteria andPORT17LikeInsensitive(String value) {
            addCriterion("upper(PORT17) like", value.toUpperCase(), "PORT17");
            return (Criteria) this;
        }

        public Criteria andPORT18LikeInsensitive(String value) {
            addCriterion("upper(PORT18) like", value.toUpperCase(), "PORT18");
            return (Criteria) this;
        }

        public Criteria andPORT19LikeInsensitive(String value) {
            addCriterion("upper(PORT19) like", value.toUpperCase(), "PORT19");
            return (Criteria) this;
        }

        public Criteria andPORT20LikeInsensitive(String value) {
            addCriterion("upper(PORT20) like", value.toUpperCase(), "PORT20");
            return (Criteria) this;
        }

        public Criteria andPORT21LikeInsensitive(String value) {
            addCriterion("upper(PORT21) like", value.toUpperCase(), "PORT21");
            return (Criteria) this;
        }

        public Criteria andPORT22LikeInsensitive(String value) {
            addCriterion("upper(PORT22) like", value.toUpperCase(), "PORT22");
            return (Criteria) this;
        }

        public Criteria andPORT23LikeInsensitive(String value) {
            addCriterion("upper(PORT23) like", value.toUpperCase(), "PORT23");
            return (Criteria) this;
        }

        public Criteria andPORT24LikeInsensitive(String value) {
            addCriterion("upper(PORT24) like", value.toUpperCase(), "PORT24");
            return (Criteria) this;
        }

        public Criteria andPORT25LikeInsensitive(String value) {
            addCriterion("upper(PORT25) like", value.toUpperCase(), "PORT25");
            return (Criteria) this;
        }

        public Criteria andPORT26LikeInsensitive(String value) {
            addCriterion("upper(PORT26) like", value.toUpperCase(), "PORT26");
            return (Criteria) this;
        }

        public Criteria andPORT27LikeInsensitive(String value) {
            addCriterion("upper(PORT27) like", value.toUpperCase(), "PORT27");
            return (Criteria) this;
        }

        public Criteria andPORT28LikeInsensitive(String value) {
            addCriterion("upper(PORT28) like", value.toUpperCase(), "PORT28");
            return (Criteria) this;
        }

        public Criteria andPORT29LikeInsensitive(String value) {
            addCriterion("upper(PORT29) like", value.toUpperCase(), "PORT29");
            return (Criteria) this;
        }

        public Criteria andPORT30LikeInsensitive(String value) {
            addCriterion("upper(PORT30) like", value.toUpperCase(), "PORT30");
            return (Criteria) this;
        }

        public Criteria andPORT31LikeInsensitive(String value) {
            addCriterion("upper(PORT31) like", value.toUpperCase(), "PORT31");
            return (Criteria) this;
        }

        public Criteria andPORT32LikeInsensitive(String value) {
            addCriterion("upper(PORT32) like", value.toUpperCase(), "PORT32");
            return (Criteria) this;
        }

        public Criteria andFTP_USERLikeInsensitive(String value) {
            addCriterion("upper(FTP_USER) like", value.toUpperCase(), "FTP_USER");
            return (Criteria) this;
        }

        public Criteria andFTP_PWLikeInsensitive(String value) {
            addCriterion("upper(FTP_PW) like", value.toUpperCase(), "FTP_PW");
            return (Criteria) this;
        }

        public Criteria andKIKI_CNG_SYUUKILikeInsensitive(String value) {
            addCriterion("upper(KIKI_CNG_SYUUKI) like", value.toUpperCase(), "KIKI_CNG_SYUUKI");
            return (Criteria) this;
        }

        public Criteria andRM_YUUKOU_FLGLikeInsensitive(String value) {
            addCriterion("upper(RM_YUUKOU_FLG) like", value.toUpperCase(), "RM_YUUKOU_FLG");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_GROUPLikeInsensitive(String value) {
            addCriterion("upper(LN_DEV_GROUP) like", value.toUpperCase(), "LN_DEV_GROUP");
            return (Criteria) this;
        }

        public Criteria andRMT_FLGLikeInsensitive(String value) {
            addCriterion("upper(RMT_FLG) like", value.toUpperCase(), "RMT_FLG");
            return (Criteria) this;
        }

        public Criteria andRMT_ENABLE_TIMELikeInsensitive(String value) {
            addCriterion("upper(RMT_ENABLE_TIME) like", value.toUpperCase(), "RMT_ENABLE_TIME");
            return (Criteria) this;
        }

        public Criteria andRMT_DEV_NMLikeInsensitive(String value) {
            addCriterion("upper(RMT_DEV_NM) like", value.toUpperCase(), "RMT_DEV_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_ON_NMLikeInsensitive(String value) {
            addCriterion("upper(RMT_ON_NM) like", value.toUpperCase(), "RMT_ON_NM");
            return (Criteria) this;
        }

        public Criteria andRMT_OFF_NMLikeInsensitive(String value) {
            addCriterion("upper(RMT_OFF_NM) like", value.toUpperCase(), "RMT_OFF_NM");
            return (Criteria) this;
        }

        public Criteria andKBI_NUMLikeInsensitive(String value) {
            addCriterion("upper(KBI_NUM) like", value.toUpperCase(), "KBI_NUM");
            return (Criteria) this;
        }

        public Criteria andSOUSA_KINDLikeInsensitive(String value) {
            addCriterion("upper(SOUSA_KIND) like", value.toUpperCase(), "SOUSA_KIND");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * E_RAKU_JIAN_DEV
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * E_RAKU_JIAN_DEV null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}