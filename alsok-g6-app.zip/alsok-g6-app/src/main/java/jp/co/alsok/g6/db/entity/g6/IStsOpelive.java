package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class IStsOpelive implements Serializable {
    /**
     * LN_ライブ使用機器論理番号
     */
    private String LN_OPELIVE;

    /**
     * LN_設置機器論理番号(親)
     */
    private String LN_DEV_PAR;

    /**
     * LN_設置機器論理番号
     */
    private String LN_DEV;

    /**
     * LN_ALSOKアカウント論理番号
     */
    private String LN_ACNT_ALSOK;

    /**
     * LN_利用者アカウント共通論理番号
     */
    private String LN_ACNT_USER_COMMON;

    /**
     * 操作権限継続確認日時
     */
    private Date OPE_PERM_CONTI_TSTM;

    /**
     * 映像配信サーバーIP
     */
    private String IMG_SV_IP;

    /**
     * 音声配信サーバーIP
     */
    private String VOC_SV_IP;

    /**
     * 通話状態
     */
    private String CALL_STS;

    /**
     * ライブ状態
     */
    private String LIVE_STS;

    /**
     * 一斉鳴動フラグ
     */
    private String ALL_RING_FLG;

    /**
     * 映像受信ポート番号
     */
    private Integer IMG_RECV_PORT;

    /**
     * 音声受信ポート番号
     */
    private Integer VOC_RECV_PORT;

    /**
     * 映像送信ポート番号
     */
    private Integer IMG_SEND_PORT;

    /**
     * フレームレート
     */
    private String FL_RATE;

    /**
     * 画像サイズ
     */
    private String PX_SIZE;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * I_STS_OPELIVE
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_ライブ使用機器論理番号
     * @return LN_OPELIVE LN_ライブ使用機器論理番号
     */
    public String getLN_OPELIVE() {
        return LN_OPELIVE;
    }

    /**
     * LN_ライブ使用機器論理番号
     * @param LN_OPELIVE LN_ライブ使用機器論理番号
     */
    public void setLN_OPELIVE(String LN_OPELIVE) {
        this.LN_OPELIVE = LN_OPELIVE == null ? null : LN_OPELIVE.trim();
    }

    /**
     * LN_設置機器論理番号(親)
     * @return LN_DEV_PAR LN_設置機器論理番号(親)
     */
    public String getLN_DEV_PAR() {
        return LN_DEV_PAR;
    }

    /**
     * LN_設置機器論理番号(親)
     * @param LN_DEV_PAR LN_設置機器論理番号(親)
     */
    public void setLN_DEV_PAR(String LN_DEV_PAR) {
        this.LN_DEV_PAR = LN_DEV_PAR == null ? null : LN_DEV_PAR.trim();
    }

    /**
     * LN_設置機器論理番号
     * @return LN_DEV LN_設置機器論理番号
     */
    public String getLN_DEV() {
        return LN_DEV;
    }

    /**
     * LN_設置機器論理番号
     * @param LN_DEV LN_設置機器論理番号
     */
    public void setLN_DEV(String LN_DEV) {
        this.LN_DEV = LN_DEV == null ? null : LN_DEV.trim();
    }

    /**
     * LN_ALSOKアカウント論理番号
     * @return LN_ACNT_ALSOK LN_ALSOKアカウント論理番号
     */
    public String getLN_ACNT_ALSOK() {
        return LN_ACNT_ALSOK;
    }

    /**
     * LN_ALSOKアカウント論理番号
     * @param LN_ACNT_ALSOK LN_ALSOKアカウント論理番号
     */
    public void setLN_ACNT_ALSOK(String LN_ACNT_ALSOK) {
        this.LN_ACNT_ALSOK = LN_ACNT_ALSOK == null ? null : LN_ACNT_ALSOK.trim();
    }

    /**
     * LN_利用者アカウント共通論理番号
     * @return LN_ACNT_USER_COMMON LN_利用者アカウント共通論理番号
     */
    public String getLN_ACNT_USER_COMMON() {
        return LN_ACNT_USER_COMMON;
    }

    /**
     * LN_利用者アカウント共通論理番号
     * @param LN_ACNT_USER_COMMON LN_利用者アカウント共通論理番号
     */
    public void setLN_ACNT_USER_COMMON(String LN_ACNT_USER_COMMON) {
        this.LN_ACNT_USER_COMMON = LN_ACNT_USER_COMMON == null ? null : LN_ACNT_USER_COMMON.trim();
    }

    /**
     * 操作権限継続確認日時
     * @return OPE_PERM_CONTI_TSTM 操作権限継続確認日時
     */
    public Date getOPE_PERM_CONTI_TSTM() {
        return OPE_PERM_CONTI_TSTM;
    }

    /**
     * 操作権限継続確認日時
     * @param OPE_PERM_CONTI_TSTM 操作権限継続確認日時
     */
    public void setOPE_PERM_CONTI_TSTM(Date OPE_PERM_CONTI_TSTM) {
        this.OPE_PERM_CONTI_TSTM = OPE_PERM_CONTI_TSTM;
    }

    /**
     * 映像配信サーバーIP
     * @return IMG_SV_IP 映像配信サーバーIP
     */
    public String getIMG_SV_IP() {
        return IMG_SV_IP;
    }

    /**
     * 映像配信サーバーIP
     * @param IMG_SV_IP 映像配信サーバーIP
     */
    public void setIMG_SV_IP(String IMG_SV_IP) {
        this.IMG_SV_IP = IMG_SV_IP == null ? null : IMG_SV_IP.trim();
    }

    /**
     * 音声配信サーバーIP
     * @return VOC_SV_IP 音声配信サーバーIP
     */
    public String getVOC_SV_IP() {
        return VOC_SV_IP;
    }

    /**
     * 音声配信サーバーIP
     * @param VOC_SV_IP 音声配信サーバーIP
     */
    public void setVOC_SV_IP(String VOC_SV_IP) {
        this.VOC_SV_IP = VOC_SV_IP == null ? null : VOC_SV_IP.trim();
    }

    /**
     * 通話状態
     * @return CALL_STS 通話状態
     */
    public String getCALL_STS() {
        return CALL_STS;
    }

    /**
     * 通話状態
     * @param CALL_STS 通話状態
     */
    public void setCALL_STS(String CALL_STS) {
        this.CALL_STS = CALL_STS == null ? null : CALL_STS.trim();
    }

    /**
     * ライブ状態
     * @return LIVE_STS ライブ状態
     */
    public String getLIVE_STS() {
        return LIVE_STS;
    }

    /**
     * ライブ状態
     * @param LIVE_STS ライブ状態
     */
    public void setLIVE_STS(String LIVE_STS) {
        this.LIVE_STS = LIVE_STS == null ? null : LIVE_STS.trim();
    }

    /**
     * 一斉鳴動フラグ
     * @return ALL_RING_FLG 一斉鳴動フラグ
     */
    public String getALL_RING_FLG() {
        return ALL_RING_FLG;
    }

    /**
     * 一斉鳴動フラグ
     * @param ALL_RING_FLG 一斉鳴動フラグ
     */
    public void setALL_RING_FLG(String ALL_RING_FLG) {
        this.ALL_RING_FLG = ALL_RING_FLG == null ? null : ALL_RING_FLG.trim();
    }

    /**
     * 映像受信ポート番号
     * @return IMG_RECV_PORT 映像受信ポート番号
     */
    public Integer getIMG_RECV_PORT() {
        return IMG_RECV_PORT;
    }

    /**
     * 映像受信ポート番号
     * @param IMG_RECV_PORT 映像受信ポート番号
     */
    public void setIMG_RECV_PORT(Integer IMG_RECV_PORT) {
        this.IMG_RECV_PORT = IMG_RECV_PORT;
    }

    /**
     * 音声受信ポート番号
     * @return VOC_RECV_PORT 音声受信ポート番号
     */
    public Integer getVOC_RECV_PORT() {
        return VOC_RECV_PORT;
    }

    /**
     * 音声受信ポート番号
     * @param VOC_RECV_PORT 音声受信ポート番号
     */
    public void setVOC_RECV_PORT(Integer VOC_RECV_PORT) {
        this.VOC_RECV_PORT = VOC_RECV_PORT;
    }

    /**
     * 映像送信ポート番号
     * @return IMG_SEND_PORT 映像送信ポート番号
     */
    public Integer getIMG_SEND_PORT() {
        return IMG_SEND_PORT;
    }

    /**
     * 映像送信ポート番号
     * @param IMG_SEND_PORT 映像送信ポート番号
     */
    public void setIMG_SEND_PORT(Integer IMG_SEND_PORT) {
        this.IMG_SEND_PORT = IMG_SEND_PORT;
    }

    /**
     * フレームレート
     * @return FL_RATE フレームレート
     */
    public String getFL_RATE() {
        return FL_RATE;
    }

    /**
     * フレームレート
     * @param FL_RATE フレームレート
     */
    public void setFL_RATE(String FL_RATE) {
        this.FL_RATE = FL_RATE == null ? null : FL_RATE.trim();
    }

    /**
     * 画像サイズ
     * @return PX_SIZE 画像サイズ
     */
    public String getPX_SIZE() {
        return PX_SIZE;
    }

    /**
     * 画像サイズ
     * @param PX_SIZE 画像サイズ
     */
    public void setPX_SIZE(String PX_SIZE) {
        this.PX_SIZE = PX_SIZE == null ? null : PX_SIZE.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}