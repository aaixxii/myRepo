package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class HAttendLog implements Serializable {
    /**
     * LN_出退勤管理情報履歴論理番号
     */
    private String LN_ATTEND_LOG;

    /**
     * 発生日時
     */
    private Date HASSEI_TS;

    /**
     * 警備先名称
     */
    private String KEIBI_NM;

    /**
     * 出勤退勤情報区分
     */
    private String SYUTAIKIN_KBN;

    /**
     * カード番号
     */
    private String KOKUIN_NUM;

    /**
     * 氏名
     */
    private String USER_NM;

    /**
     * 部署
     */
    private String DEPA_NM;

    /**
     * 役職
     */
    private String POSI_NM;

    /**
     * 社員コード
     */
    private String USER_CD;

    /**
     * 画像利用フラグ
     */
    private String GAZO_USE_FLG;

    /**
     * 出退勤画像ファイル情報
     */
    private String GAZO_FILE_PATH;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * H_ATTEND_LOG
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_出退勤管理情報履歴論理番号
     * @return LN_ATTEND_LOG LN_出退勤管理情報履歴論理番号
     */
    public String getLN_ATTEND_LOG() {
        return LN_ATTEND_LOG;
    }

    /**
     * LN_出退勤管理情報履歴論理番号
     * @param LN_ATTEND_LOG LN_出退勤管理情報履歴論理番号
     */
    public void setLN_ATTEND_LOG(String LN_ATTEND_LOG) {
        this.LN_ATTEND_LOG = LN_ATTEND_LOG == null ? null : LN_ATTEND_LOG.trim();
    }

    /**
     * 発生日時
     * @return HASSEI_TS 発生日時
     */
    public Date getHASSEI_TS() {
        return HASSEI_TS;
    }

    /**
     * 発生日時
     * @param HASSEI_TS 発生日時
     */
    public void setHASSEI_TS(Date HASSEI_TS) {
        this.HASSEI_TS = HASSEI_TS;
    }

    /**
     * 警備先名称
     * @return KEIBI_NM 警備先名称
     */
    public String getKEIBI_NM() {
        return KEIBI_NM;
    }

    /**
     * 警備先名称
     * @param KEIBI_NM 警備先名称
     */
    public void setKEIBI_NM(String KEIBI_NM) {
        this.KEIBI_NM = KEIBI_NM == null ? null : KEIBI_NM.trim();
    }

    /**
     * 出勤退勤情報区分
     * @return SYUTAIKIN_KBN 出勤退勤情報区分
     */
    public String getSYUTAIKIN_KBN() {
        return SYUTAIKIN_KBN;
    }

    /**
     * 出勤退勤情報区分
     * @param SYUTAIKIN_KBN 出勤退勤情報区分
     */
    public void setSYUTAIKIN_KBN(String SYUTAIKIN_KBN) {
        this.SYUTAIKIN_KBN = SYUTAIKIN_KBN == null ? null : SYUTAIKIN_KBN.trim();
    }

    /**
     * カード番号
     * @return KOKUIN_NUM カード番号
     */
    public String getKOKUIN_NUM() {
        return KOKUIN_NUM;
    }

    /**
     * カード番号
     * @param KOKUIN_NUM カード番号
     */
    public void setKOKUIN_NUM(String KOKUIN_NUM) {
        this.KOKUIN_NUM = KOKUIN_NUM == null ? null : KOKUIN_NUM.trim();
    }

    /**
     * 氏名
     * @return USER_NM 氏名
     */
    public String getUSER_NM() {
        return USER_NM;
    }

    /**
     * 氏名
     * @param USER_NM 氏名
     */
    public void setUSER_NM(String USER_NM) {
        this.USER_NM = USER_NM == null ? null : USER_NM.trim();
    }

    /**
     * 部署
     * @return DEPA_NM 部署
     */
    public String getDEPA_NM() {
        return DEPA_NM;
    }

    /**
     * 部署
     * @param DEPA_NM 部署
     */
    public void setDEPA_NM(String DEPA_NM) {
        this.DEPA_NM = DEPA_NM == null ? null : DEPA_NM.trim();
    }

    /**
     * 役職
     * @return POSI_NM 役職
     */
    public String getPOSI_NM() {
        return POSI_NM;
    }

    /**
     * 役職
     * @param POSI_NM 役職
     */
    public void setPOSI_NM(String POSI_NM) {
        this.POSI_NM = POSI_NM == null ? null : POSI_NM.trim();
    }

    /**
     * 社員コード
     * @return USER_CD 社員コード
     */
    public String getUSER_CD() {
        return USER_CD;
    }

    /**
     * 社員コード
     * @param USER_CD 社員コード
     */
    public void setUSER_CD(String USER_CD) {
        this.USER_CD = USER_CD == null ? null : USER_CD.trim();
    }

    /**
     * 画像利用フラグ
     * @return GAZO_USE_FLG 画像利用フラグ
     */
    public String getGAZO_USE_FLG() {
        return GAZO_USE_FLG;
    }

    /**
     * 画像利用フラグ
     * @param GAZO_USE_FLG 画像利用フラグ
     */
    public void setGAZO_USE_FLG(String GAZO_USE_FLG) {
        this.GAZO_USE_FLG = GAZO_USE_FLG == null ? null : GAZO_USE_FLG.trim();
    }

    /**
     * 出退勤画像ファイル情報
     * @return GAZO_FILE_PATH 出退勤画像ファイル情報
     */
    public String getGAZO_FILE_PATH() {
        return GAZO_FILE_PATH;
    }

    /**
     * 出退勤画像ファイル情報
     * @param GAZO_FILE_PATH 出退勤画像ファイル情報
     */
    public void setGAZO_FILE_PATH(String GAZO_FILE_PATH) {
        this.GAZO_FILE_PATH = GAZO_FILE_PATH == null ? null : GAZO_FILE_PATH.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}