package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class CLineSurveillanceInf extends CLineSurveillanceInfKey implements Serializable {
    /**
     * IPアドレス
     */
    private String IP_ADDR;

    /**
     * ポート番号
     */
    private String PORT_NUM;

    /**
     * 電計番号
     */
    private String DENKEI;

    /**
     * 号機番号
     */
    private String GOUKI;

    /**
     * ICCID
     */
    private String ICC_ID;

    /**
     * 最終受信日時
     */
    private Date LAST_RCV_TS;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * C_LINE_SURVEILLANCE_INF
     */
    private static final long serialVersionUID = 1L;

    /**
     * IPアドレス
     * @return IP_ADDR IPアドレス
     */
    public String getIP_ADDR() {
        return IP_ADDR;
    }

    /**
     * IPアドレス
     * @param IP_ADDR IPアドレス
     */
    public void setIP_ADDR(String IP_ADDR) {
        this.IP_ADDR = IP_ADDR == null ? null : IP_ADDR.trim();
    }

    /**
     * ポート番号
     * @return PORT_NUM ポート番号
     */
    public String getPORT_NUM() {
        return PORT_NUM;
    }

    /**
     * ポート番号
     * @param PORT_NUM ポート番号
     */
    public void setPORT_NUM(String PORT_NUM) {
        this.PORT_NUM = PORT_NUM == null ? null : PORT_NUM.trim();
    }

    /**
     * 電計番号
     * @return DENKEI 電計番号
     */
    public String getDENKEI() {
        return DENKEI;
    }

    /**
     * 電計番号
     * @param DENKEI 電計番号
     */
    public void setDENKEI(String DENKEI) {
        this.DENKEI = DENKEI == null ? null : DENKEI.trim();
    }

    /**
     * 号機番号
     * @return GOUKI 号機番号
     */
    public String getGOUKI() {
        return GOUKI;
    }

    /**
     * 号機番号
     * @param GOUKI 号機番号
     */
    public void setGOUKI(String GOUKI) {
        this.GOUKI = GOUKI == null ? null : GOUKI.trim();
    }

    /**
     * ICCID
     * @return ICC_ID ICCID
     */
    public String getICC_ID() {
        return ICC_ID;
    }

    /**
     * ICCID
     * @param ICC_ID ICCID
     */
    public void setICC_ID(String ICC_ID) {
        this.ICC_ID = ICC_ID == null ? null : ICC_ID.trim();
    }

    /**
     * 最終受信日時
     * @return LAST_RCV_TS 最終受信日時
     */
    public Date getLAST_RCV_TS() {
        return LAST_RCV_TS;
    }

    /**
     * 最終受信日時
     * @param LAST_RCV_TS 最終受信日時
     */
    public void setLAST_RCV_TS(Date LAST_RCV_TS) {
        this.LAST_RCV_TS = LAST_RCV_TS;
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}