package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.List;

public class MDispExample {
    /**
     * M_DISP
     */
    protected String orderByClause;

    /**
     * M_DISP
     */
    protected boolean distinct;

    /**
     * M_DISP
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public MDispExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * M_DISP null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andDISP_IDIsNull() {
            addCriterion("DISP_ID is null");
            return (Criteria) this;
        }

        public Criteria andDISP_IDIsNotNull() {
            addCriterion("DISP_ID is not null");
            return (Criteria) this;
        }

        public Criteria andDISP_IDEqualTo(String value) {
            addCriterion("DISP_ID =", value, "DISP_ID");
            return (Criteria) this;
        }

        public Criteria andDISP_IDNotEqualTo(String value) {
            addCriterion("DISP_ID <>", value, "DISP_ID");
            return (Criteria) this;
        }

        public Criteria andDISP_IDGreaterThan(String value) {
            addCriterion("DISP_ID >", value, "DISP_ID");
            return (Criteria) this;
        }

        public Criteria andDISP_IDGreaterThanOrEqualTo(String value) {
            addCriterion("DISP_ID >=", value, "DISP_ID");
            return (Criteria) this;
        }

        public Criteria andDISP_IDLessThan(String value) {
            addCriterion("DISP_ID <", value, "DISP_ID");
            return (Criteria) this;
        }

        public Criteria andDISP_IDLessThanOrEqualTo(String value) {
            addCriterion("DISP_ID <=", value, "DISP_ID");
            return (Criteria) this;
        }

        public Criteria andDISP_IDLike(String value) {
            addCriterion("DISP_ID like", value, "DISP_ID");
            return (Criteria) this;
        }

        public Criteria andDISP_IDNotLike(String value) {
            addCriterion("DISP_ID not like", value, "DISP_ID");
            return (Criteria) this;
        }

        public Criteria andDISP_IDIn(List<String> values) {
            addCriterion("DISP_ID in", values, "DISP_ID");
            return (Criteria) this;
        }

        public Criteria andDISP_IDNotIn(List<String> values) {
            addCriterion("DISP_ID not in", values, "DISP_ID");
            return (Criteria) this;
        }

        public Criteria andDISP_IDBetween(String value1, String value2) {
            addCriterion("DISP_ID between", value1, value2, "DISP_ID");
            return (Criteria) this;
        }

        public Criteria andDISP_IDNotBetween(String value1, String value2) {
            addCriterion("DISP_ID not between", value1, value2, "DISP_ID");
            return (Criteria) this;
        }

        public Criteria andDISP_NMIsNull() {
            addCriterion("DISP_NM is null");
            return (Criteria) this;
        }

        public Criteria andDISP_NMIsNotNull() {
            addCriterion("DISP_NM is not null");
            return (Criteria) this;
        }

        public Criteria andDISP_NMEqualTo(String value) {
            addCriterion("DISP_NM =", value, "DISP_NM");
            return (Criteria) this;
        }

        public Criteria andDISP_NMNotEqualTo(String value) {
            addCriterion("DISP_NM <>", value, "DISP_NM");
            return (Criteria) this;
        }

        public Criteria andDISP_NMGreaterThan(String value) {
            addCriterion("DISP_NM >", value, "DISP_NM");
            return (Criteria) this;
        }

        public Criteria andDISP_NMGreaterThanOrEqualTo(String value) {
            addCriterion("DISP_NM >=", value, "DISP_NM");
            return (Criteria) this;
        }

        public Criteria andDISP_NMLessThan(String value) {
            addCriterion("DISP_NM <", value, "DISP_NM");
            return (Criteria) this;
        }

        public Criteria andDISP_NMLessThanOrEqualTo(String value) {
            addCriterion("DISP_NM <=", value, "DISP_NM");
            return (Criteria) this;
        }

        public Criteria andDISP_NMLike(String value) {
            addCriterion("DISP_NM like", value, "DISP_NM");
            return (Criteria) this;
        }

        public Criteria andDISP_NMNotLike(String value) {
            addCriterion("DISP_NM not like", value, "DISP_NM");
            return (Criteria) this;
        }

        public Criteria andDISP_NMIn(List<String> values) {
            addCriterion("DISP_NM in", values, "DISP_NM");
            return (Criteria) this;
        }

        public Criteria andDISP_NMNotIn(List<String> values) {
            addCriterion("DISP_NM not in", values, "DISP_NM");
            return (Criteria) this;
        }

        public Criteria andDISP_NMBetween(String value1, String value2) {
            addCriterion("DISP_NM between", value1, value2, "DISP_NM");
            return (Criteria) this;
        }

        public Criteria andDISP_NMNotBetween(String value1, String value2) {
            addCriterion("DISP_NM not between", value1, value2, "DISP_NM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMIsNull() {
            addCriterion("ORDER_NUM is null");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMIsNotNull() {
            addCriterion("ORDER_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMEqualTo(String value) {
            addCriterion("ORDER_NUM =", value, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMNotEqualTo(String value) {
            addCriterion("ORDER_NUM <>", value, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMGreaterThan(String value) {
            addCriterion("ORDER_NUM >", value, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("ORDER_NUM >=", value, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMLessThan(String value) {
            addCriterion("ORDER_NUM <", value, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMLessThanOrEqualTo(String value) {
            addCriterion("ORDER_NUM <=", value, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMLike(String value) {
            addCriterion("ORDER_NUM like", value, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMNotLike(String value) {
            addCriterion("ORDER_NUM not like", value, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMIn(List<String> values) {
            addCriterion("ORDER_NUM in", values, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMNotIn(List<String> values) {
            addCriterion("ORDER_NUM not in", values, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMBetween(String value1, String value2) {
            addCriterion("ORDER_NUM between", value1, value2, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMNotBetween(String value1, String value2) {
            addCriterion("ORDER_NUM not between", value1, value2, "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andMENUPASS_INFIsNull() {
            addCriterion("MENUPASS_INF is null");
            return (Criteria) this;
        }

        public Criteria andMENUPASS_INFIsNotNull() {
            addCriterion("MENUPASS_INF is not null");
            return (Criteria) this;
        }

        public Criteria andMENUPASS_INFEqualTo(String value) {
            addCriterion("MENUPASS_INF =", value, "MENUPASS_INF");
            return (Criteria) this;
        }

        public Criteria andMENUPASS_INFNotEqualTo(String value) {
            addCriterion("MENUPASS_INF <>", value, "MENUPASS_INF");
            return (Criteria) this;
        }

        public Criteria andMENUPASS_INFGreaterThan(String value) {
            addCriterion("MENUPASS_INF >", value, "MENUPASS_INF");
            return (Criteria) this;
        }

        public Criteria andMENUPASS_INFGreaterThanOrEqualTo(String value) {
            addCriterion("MENUPASS_INF >=", value, "MENUPASS_INF");
            return (Criteria) this;
        }

        public Criteria andMENUPASS_INFLessThan(String value) {
            addCriterion("MENUPASS_INF <", value, "MENUPASS_INF");
            return (Criteria) this;
        }

        public Criteria andMENUPASS_INFLessThanOrEqualTo(String value) {
            addCriterion("MENUPASS_INF <=", value, "MENUPASS_INF");
            return (Criteria) this;
        }

        public Criteria andMENUPASS_INFLike(String value) {
            addCriterion("MENUPASS_INF like", value, "MENUPASS_INF");
            return (Criteria) this;
        }

        public Criteria andMENUPASS_INFNotLike(String value) {
            addCriterion("MENUPASS_INF not like", value, "MENUPASS_INF");
            return (Criteria) this;
        }

        public Criteria andMENUPASS_INFIn(List<String> values) {
            addCriterion("MENUPASS_INF in", values, "MENUPASS_INF");
            return (Criteria) this;
        }

        public Criteria andMENUPASS_INFNotIn(List<String> values) {
            addCriterion("MENUPASS_INF not in", values, "MENUPASS_INF");
            return (Criteria) this;
        }

        public Criteria andMENUPASS_INFBetween(String value1, String value2) {
            addCriterion("MENUPASS_INF between", value1, value2, "MENUPASS_INF");
            return (Criteria) this;
        }

        public Criteria andMENUPASS_INFNotBetween(String value1, String value2) {
            addCriterion("MENUPASS_INF not between", value1, value2, "MENUPASS_INF");
            return (Criteria) this;
        }

        public Criteria andCHIKU_FLGIsNull() {
            addCriterion("CHIKU_FLG is null");
            return (Criteria) this;
        }

        public Criteria andCHIKU_FLGIsNotNull() {
            addCriterion("CHIKU_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andCHIKU_FLGEqualTo(String value) {
            addCriterion("CHIKU_FLG =", value, "CHIKU_FLG");
            return (Criteria) this;
        }

        public Criteria andCHIKU_FLGNotEqualTo(String value) {
            addCriterion("CHIKU_FLG <>", value, "CHIKU_FLG");
            return (Criteria) this;
        }

        public Criteria andCHIKU_FLGGreaterThan(String value) {
            addCriterion("CHIKU_FLG >", value, "CHIKU_FLG");
            return (Criteria) this;
        }

        public Criteria andCHIKU_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("CHIKU_FLG >=", value, "CHIKU_FLG");
            return (Criteria) this;
        }

        public Criteria andCHIKU_FLGLessThan(String value) {
            addCriterion("CHIKU_FLG <", value, "CHIKU_FLG");
            return (Criteria) this;
        }

        public Criteria andCHIKU_FLGLessThanOrEqualTo(String value) {
            addCriterion("CHIKU_FLG <=", value, "CHIKU_FLG");
            return (Criteria) this;
        }

        public Criteria andCHIKU_FLGLike(String value) {
            addCriterion("CHIKU_FLG like", value, "CHIKU_FLG");
            return (Criteria) this;
        }

        public Criteria andCHIKU_FLGNotLike(String value) {
            addCriterion("CHIKU_FLG not like", value, "CHIKU_FLG");
            return (Criteria) this;
        }

        public Criteria andCHIKU_FLGIn(List<String> values) {
            addCriterion("CHIKU_FLG in", values, "CHIKU_FLG");
            return (Criteria) this;
        }

        public Criteria andCHIKU_FLGNotIn(List<String> values) {
            addCriterion("CHIKU_FLG not in", values, "CHIKU_FLG");
            return (Criteria) this;
        }

        public Criteria andCHIKU_FLGBetween(String value1, String value2) {
            addCriterion("CHIKU_FLG between", value1, value2, "CHIKU_FLG");
            return (Criteria) this;
        }

        public Criteria andCHIKU_FLGNotBetween(String value1, String value2) {
            addCriterion("CHIKU_FLG not between", value1, value2, "CHIKU_FLG");
            return (Criteria) this;
        }

        public Criteria andDISP_IDLikeInsensitive(String value) {
            addCriterion("upper(DISP_ID) like", value.toUpperCase(), "DISP_ID");
            return (Criteria) this;
        }

        public Criteria andDISP_NMLikeInsensitive(String value) {
            addCriterion("upper(DISP_NM) like", value.toUpperCase(), "DISP_NM");
            return (Criteria) this;
        }

        public Criteria andORDER_NUMLikeInsensitive(String value) {
            addCriterion("upper(ORDER_NUM) like", value.toUpperCase(), "ORDER_NUM");
            return (Criteria) this;
        }

        public Criteria andMENUPASS_INFLikeInsensitive(String value) {
            addCriterion("upper(MENUPASS_INF) like", value.toUpperCase(), "MENUPASS_INF");
            return (Criteria) this;
        }

        public Criteria andCHIKU_FLGLikeInsensitive(String value) {
            addCriterion("upper(CHIKU_FLG) like", value.toUpperCase(), "CHIKU_FLG");
            return (Criteria) this;
        }
    }

    /**
     * M_DISP
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * M_DISP null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}