package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AUserRoleAuthExample {
    /**
     * A_USER_ROLE_AUTH
     */
    protected String orderByClause;

    /**
     * A_USER_ROLE_AUTH
     */
    protected boolean distinct;

    /**
     * A_USER_ROLE_AUTH
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public AUserRoleAuthExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * A_USER_ROLE_AUTH null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_USER_ROLEIsNull() {
            addCriterion("LN_USER_ROLE is null");
            return (Criteria) this;
        }

        public Criteria andLN_USER_ROLEIsNotNull() {
            addCriterion("LN_USER_ROLE is not null");
            return (Criteria) this;
        }

        public Criteria andLN_USER_ROLEEqualTo(String value) {
            addCriterion("LN_USER_ROLE =", value, "LN_USER_ROLE");
            return (Criteria) this;
        }

        public Criteria andLN_USER_ROLENotEqualTo(String value) {
            addCriterion("LN_USER_ROLE <>", value, "LN_USER_ROLE");
            return (Criteria) this;
        }

        public Criteria andLN_USER_ROLEGreaterThan(String value) {
            addCriterion("LN_USER_ROLE >", value, "LN_USER_ROLE");
            return (Criteria) this;
        }

        public Criteria andLN_USER_ROLEGreaterThanOrEqualTo(String value) {
            addCriterion("LN_USER_ROLE >=", value, "LN_USER_ROLE");
            return (Criteria) this;
        }

        public Criteria andLN_USER_ROLELessThan(String value) {
            addCriterion("LN_USER_ROLE <", value, "LN_USER_ROLE");
            return (Criteria) this;
        }

        public Criteria andLN_USER_ROLELessThanOrEqualTo(String value) {
            addCriterion("LN_USER_ROLE <=", value, "LN_USER_ROLE");
            return (Criteria) this;
        }

        public Criteria andLN_USER_ROLELike(String value) {
            addCriterion("LN_USER_ROLE like", value, "LN_USER_ROLE");
            return (Criteria) this;
        }

        public Criteria andLN_USER_ROLENotLike(String value) {
            addCriterion("LN_USER_ROLE not like", value, "LN_USER_ROLE");
            return (Criteria) this;
        }

        public Criteria andLN_USER_ROLEIn(List<String> values) {
            addCriterion("LN_USER_ROLE in", values, "LN_USER_ROLE");
            return (Criteria) this;
        }

        public Criteria andLN_USER_ROLENotIn(List<String> values) {
            addCriterion("LN_USER_ROLE not in", values, "LN_USER_ROLE");
            return (Criteria) this;
        }

        public Criteria andLN_USER_ROLEBetween(String value1, String value2) {
            addCriterion("LN_USER_ROLE between", value1, value2, "LN_USER_ROLE");
            return (Criteria) this;
        }

        public Criteria andLN_USER_ROLENotBetween(String value1, String value2) {
            addCriterion("LN_USER_ROLE not between", value1, value2, "LN_USER_ROLE");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUIsNull() {
            addCriterion("LN_KB_CHIKU is null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUIsNotNull() {
            addCriterion("LN_KB_CHIKU is not null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUEqualTo(String value) {
            addCriterion("LN_KB_CHIKU =", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUNotEqualTo(String value) {
            addCriterion("LN_KB_CHIKU <>", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUGreaterThan(String value) {
            addCriterion("LN_KB_CHIKU >", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUGreaterThanOrEqualTo(String value) {
            addCriterion("LN_KB_CHIKU >=", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKULessThan(String value) {
            addCriterion("LN_KB_CHIKU <", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKULessThanOrEqualTo(String value) {
            addCriterion("LN_KB_CHIKU <=", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKULike(String value) {
            addCriterion("LN_KB_CHIKU like", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUNotLike(String value) {
            addCriterion("LN_KB_CHIKU not like", value, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUIn(List<String> values) {
            addCriterion("LN_KB_CHIKU in", values, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUNotIn(List<String> values) {
            addCriterion("LN_KB_CHIKU not in", values, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUBetween(String value1, String value2) {
            addCriterion("LN_KB_CHIKU between", value1, value2, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKUNotBetween(String value1, String value2) {
            addCriterion("LN_KB_CHIKU not between", value1, value2, "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_USER_ACNT_AUTH_IDIsNull() {
            addCriterion("LN_USER_ACNT_AUTH_ID is null");
            return (Criteria) this;
        }

        public Criteria andLN_USER_ACNT_AUTH_IDIsNotNull() {
            addCriterion("LN_USER_ACNT_AUTH_ID is not null");
            return (Criteria) this;
        }

        public Criteria andLN_USER_ACNT_AUTH_IDEqualTo(String value) {
            addCriterion("LN_USER_ACNT_AUTH_ID =", value, "LN_USER_ACNT_AUTH_ID");
            return (Criteria) this;
        }

        public Criteria andLN_USER_ACNT_AUTH_IDNotEqualTo(String value) {
            addCriterion("LN_USER_ACNT_AUTH_ID <>", value, "LN_USER_ACNT_AUTH_ID");
            return (Criteria) this;
        }

        public Criteria andLN_USER_ACNT_AUTH_IDGreaterThan(String value) {
            addCriterion("LN_USER_ACNT_AUTH_ID >", value, "LN_USER_ACNT_AUTH_ID");
            return (Criteria) this;
        }

        public Criteria andLN_USER_ACNT_AUTH_IDGreaterThanOrEqualTo(String value) {
            addCriterion("LN_USER_ACNT_AUTH_ID >=", value, "LN_USER_ACNT_AUTH_ID");
            return (Criteria) this;
        }

        public Criteria andLN_USER_ACNT_AUTH_IDLessThan(String value) {
            addCriterion("LN_USER_ACNT_AUTH_ID <", value, "LN_USER_ACNT_AUTH_ID");
            return (Criteria) this;
        }

        public Criteria andLN_USER_ACNT_AUTH_IDLessThanOrEqualTo(String value) {
            addCriterion("LN_USER_ACNT_AUTH_ID <=", value, "LN_USER_ACNT_AUTH_ID");
            return (Criteria) this;
        }

        public Criteria andLN_USER_ACNT_AUTH_IDLike(String value) {
            addCriterion("LN_USER_ACNT_AUTH_ID like", value, "LN_USER_ACNT_AUTH_ID");
            return (Criteria) this;
        }

        public Criteria andLN_USER_ACNT_AUTH_IDNotLike(String value) {
            addCriterion("LN_USER_ACNT_AUTH_ID not like", value, "LN_USER_ACNT_AUTH_ID");
            return (Criteria) this;
        }

        public Criteria andLN_USER_ACNT_AUTH_IDIn(List<String> values) {
            addCriterion("LN_USER_ACNT_AUTH_ID in", values, "LN_USER_ACNT_AUTH_ID");
            return (Criteria) this;
        }

        public Criteria andLN_USER_ACNT_AUTH_IDNotIn(List<String> values) {
            addCriterion("LN_USER_ACNT_AUTH_ID not in", values, "LN_USER_ACNT_AUTH_ID");
            return (Criteria) this;
        }

        public Criteria andLN_USER_ACNT_AUTH_IDBetween(String value1, String value2) {
            addCriterion("LN_USER_ACNT_AUTH_ID between", value1, value2, "LN_USER_ACNT_AUTH_ID");
            return (Criteria) this;
        }

        public Criteria andLN_USER_ACNT_AUTH_IDNotBetween(String value1, String value2) {
            addCriterion("LN_USER_ACNT_AUTH_ID not between", value1, value2, "LN_USER_ACNT_AUTH_ID");
            return (Criteria) this;
        }

        public Criteria andAUTHIsNull() {
            addCriterion("AUTH is null");
            return (Criteria) this;
        }

        public Criteria andAUTHIsNotNull() {
            addCriterion("AUTH is not null");
            return (Criteria) this;
        }

        public Criteria andAUTHEqualTo(String value) {
            addCriterion("AUTH =", value, "AUTH");
            return (Criteria) this;
        }

        public Criteria andAUTHNotEqualTo(String value) {
            addCriterion("AUTH <>", value, "AUTH");
            return (Criteria) this;
        }

        public Criteria andAUTHGreaterThan(String value) {
            addCriterion("AUTH >", value, "AUTH");
            return (Criteria) this;
        }

        public Criteria andAUTHGreaterThanOrEqualTo(String value) {
            addCriterion("AUTH >=", value, "AUTH");
            return (Criteria) this;
        }

        public Criteria andAUTHLessThan(String value) {
            addCriterion("AUTH <", value, "AUTH");
            return (Criteria) this;
        }

        public Criteria andAUTHLessThanOrEqualTo(String value) {
            addCriterion("AUTH <=", value, "AUTH");
            return (Criteria) this;
        }

        public Criteria andAUTHLike(String value) {
            addCriterion("AUTH like", value, "AUTH");
            return (Criteria) this;
        }

        public Criteria andAUTHNotLike(String value) {
            addCriterion("AUTH not like", value, "AUTH");
            return (Criteria) this;
        }

        public Criteria andAUTHIn(List<String> values) {
            addCriterion("AUTH in", values, "AUTH");
            return (Criteria) this;
        }

        public Criteria andAUTHNotIn(List<String> values) {
            addCriterion("AUTH not in", values, "AUTH");
            return (Criteria) this;
        }

        public Criteria andAUTHBetween(String value1, String value2) {
            addCriterion("AUTH between", value1, value2, "AUTH");
            return (Criteria) this;
        }

        public Criteria andAUTHNotBetween(String value1, String value2) {
            addCriterion("AUTH not between", value1, value2, "AUTH");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andLN_USER_ROLELikeInsensitive(String value) {
            addCriterion("upper(LN_USER_ROLE) like", value.toUpperCase(), "LN_USER_ROLE");
            return (Criteria) this;
        }

        public Criteria andLN_KB_CHIKULikeInsensitive(String value) {
            addCriterion("upper(LN_KB_CHIKU) like", value.toUpperCase(), "LN_KB_CHIKU");
            return (Criteria) this;
        }

        public Criteria andLN_USER_ACNT_AUTH_IDLikeInsensitive(String value) {
            addCriterion("upper(LN_USER_ACNT_AUTH_ID) like", value.toUpperCase(), "LN_USER_ACNT_AUTH_ID");
            return (Criteria) this;
        }

        public Criteria andAUTHLikeInsensitive(String value) {
            addCriterion("upper(AUTH) like", value.toUpperCase(), "AUTH");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * A_USER_ROLE_AUTH
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * A_USER_ROLE_AUTH null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}