package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CEigyoJigyoshoExample {
    /**
     * C_EIGYO_JIGYOSHO
     */
    protected String orderByClause;

    /**
     * C_EIGYO_JIGYOSHO
     */
    protected boolean distinct;

    /**
     * C_EIGYO_JIGYOSHO
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public CEigyoJigyoshoExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * C_EIGYO_JIGYOSHO null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andKAISHA_CDIsNull() {
            addCriterion("KAISHA_CD is null");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDIsNotNull() {
            addCriterion("KAISHA_CD is not null");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDEqualTo(String value) {
            addCriterion("KAISHA_CD =", value, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDNotEqualTo(String value) {
            addCriterion("KAISHA_CD <>", value, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDGreaterThan(String value) {
            addCriterion("KAISHA_CD >", value, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDGreaterThanOrEqualTo(String value) {
            addCriterion("KAISHA_CD >=", value, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDLessThan(String value) {
            addCriterion("KAISHA_CD <", value, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDLessThanOrEqualTo(String value) {
            addCriterion("KAISHA_CD <=", value, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDLike(String value) {
            addCriterion("KAISHA_CD like", value, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDNotLike(String value) {
            addCriterion("KAISHA_CD not like", value, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDIn(List<String> values) {
            addCriterion("KAISHA_CD in", values, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDNotIn(List<String> values) {
            addCriterion("KAISHA_CD not in", values, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDBetween(String value1, String value2) {
            addCriterion("KAISHA_CD between", value1, value2, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDNotBetween(String value1, String value2) {
            addCriterion("KAISHA_CD not between", value1, value2, "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_CDIsNull() {
            addCriterion("JIGYOSHO_CD is null");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_CDIsNotNull() {
            addCriterion("JIGYOSHO_CD is not null");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_CDEqualTo(String value) {
            addCriterion("JIGYOSHO_CD =", value, "JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_CDNotEqualTo(String value) {
            addCriterion("JIGYOSHO_CD <>", value, "JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_CDGreaterThan(String value) {
            addCriterion("JIGYOSHO_CD >", value, "JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_CDGreaterThanOrEqualTo(String value) {
            addCriterion("JIGYOSHO_CD >=", value, "JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_CDLessThan(String value) {
            addCriterion("JIGYOSHO_CD <", value, "JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_CDLessThanOrEqualTo(String value) {
            addCriterion("JIGYOSHO_CD <=", value, "JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_CDLike(String value) {
            addCriterion("JIGYOSHO_CD like", value, "JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_CDNotLike(String value) {
            addCriterion("JIGYOSHO_CD not like", value, "JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_CDIn(List<String> values) {
            addCriterion("JIGYOSHO_CD in", values, "JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_CDNotIn(List<String> values) {
            addCriterion("JIGYOSHO_CD not in", values, "JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_CDBetween(String value1, String value2) {
            addCriterion("JIGYOSHO_CD between", value1, value2, "JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_CDNotBetween(String value1, String value2) {
            addCriterion("JIGYOSHO_CD not between", value1, value2, "JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDIsNull() {
            addCriterion("TEKIYO_KAISHI_YMD is null");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDIsNotNull() {
            addCriterion("TEKIYO_KAISHI_YMD is not null");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDEqualTo(String value) {
            addCriterion("TEKIYO_KAISHI_YMD =", value, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDNotEqualTo(String value) {
            addCriterion("TEKIYO_KAISHI_YMD <>", value, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDGreaterThan(String value) {
            addCriterion("TEKIYO_KAISHI_YMD >", value, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDGreaterThanOrEqualTo(String value) {
            addCriterion("TEKIYO_KAISHI_YMD >=", value, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDLessThan(String value) {
            addCriterion("TEKIYO_KAISHI_YMD <", value, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDLessThanOrEqualTo(String value) {
            addCriterion("TEKIYO_KAISHI_YMD <=", value, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDLike(String value) {
            addCriterion("TEKIYO_KAISHI_YMD like", value, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDNotLike(String value) {
            addCriterion("TEKIYO_KAISHI_YMD not like", value, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDIn(List<String> values) {
            addCriterion("TEKIYO_KAISHI_YMD in", values, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDNotIn(List<String> values) {
            addCriterion("TEKIYO_KAISHI_YMD not in", values, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDBetween(String value1, String value2) {
            addCriterion("TEKIYO_KAISHI_YMD between", value1, value2, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDNotBetween(String value1, String value2) {
            addCriterion("TEKIYO_KAISHI_YMD not between", value1, value2, "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDIsNull() {
            addCriterion("TEKIYO_SHURYO_YMD is null");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDIsNotNull() {
            addCriterion("TEKIYO_SHURYO_YMD is not null");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDEqualTo(String value) {
            addCriterion("TEKIYO_SHURYO_YMD =", value, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDNotEqualTo(String value) {
            addCriterion("TEKIYO_SHURYO_YMD <>", value, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDGreaterThan(String value) {
            addCriterion("TEKIYO_SHURYO_YMD >", value, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDGreaterThanOrEqualTo(String value) {
            addCriterion("TEKIYO_SHURYO_YMD >=", value, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDLessThan(String value) {
            addCriterion("TEKIYO_SHURYO_YMD <", value, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDLessThanOrEqualTo(String value) {
            addCriterion("TEKIYO_SHURYO_YMD <=", value, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDLike(String value) {
            addCriterion("TEKIYO_SHURYO_YMD like", value, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDNotLike(String value) {
            addCriterion("TEKIYO_SHURYO_YMD not like", value, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDIn(List<String> values) {
            addCriterion("TEKIYO_SHURYO_YMD in", values, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDNotIn(List<String> values) {
            addCriterion("TEKIYO_SHURYO_YMD not in", values, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDBetween(String value1, String value2) {
            addCriterion("TEKIYO_SHURYO_YMD between", value1, value2, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDNotBetween(String value1, String value2) {
            addCriterion("TEKIYO_SHURYO_YMD not between", value1, value2, "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KBNIsNull() {
            addCriterion("JIGYOSHO_KBN is null");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KBNIsNotNull() {
            addCriterion("JIGYOSHO_KBN is not null");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KBNEqualTo(String value) {
            addCriterion("JIGYOSHO_KBN =", value, "JIGYOSHO_KBN");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KBNNotEqualTo(String value) {
            addCriterion("JIGYOSHO_KBN <>", value, "JIGYOSHO_KBN");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KBNGreaterThan(String value) {
            addCriterion("JIGYOSHO_KBN >", value, "JIGYOSHO_KBN");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KBNGreaterThanOrEqualTo(String value) {
            addCriterion("JIGYOSHO_KBN >=", value, "JIGYOSHO_KBN");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KBNLessThan(String value) {
            addCriterion("JIGYOSHO_KBN <", value, "JIGYOSHO_KBN");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KBNLessThanOrEqualTo(String value) {
            addCriterion("JIGYOSHO_KBN <=", value, "JIGYOSHO_KBN");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KBNLike(String value) {
            addCriterion("JIGYOSHO_KBN like", value, "JIGYOSHO_KBN");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KBNNotLike(String value) {
            addCriterion("JIGYOSHO_KBN not like", value, "JIGYOSHO_KBN");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KBNIn(List<String> values) {
            addCriterion("JIGYOSHO_KBN in", values, "JIGYOSHO_KBN");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KBNNotIn(List<String> values) {
            addCriterion("JIGYOSHO_KBN not in", values, "JIGYOSHO_KBN");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KBNBetween(String value1, String value2) {
            addCriterion("JIGYOSHO_KBN between", value1, value2, "JIGYOSHO_KBN");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KBNNotBetween(String value1, String value2) {
            addCriterion("JIGYOSHO_KBN not between", value1, value2, "JIGYOSHO_KBN");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_NMIsNull() {
            addCriterion("JIGYOSHO_NM is null");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_NMIsNotNull() {
            addCriterion("JIGYOSHO_NM is not null");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_NMEqualTo(String value) {
            addCriterion("JIGYOSHO_NM =", value, "JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_NMNotEqualTo(String value) {
            addCriterion("JIGYOSHO_NM <>", value, "JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_NMGreaterThan(String value) {
            addCriterion("JIGYOSHO_NM >", value, "JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_NMGreaterThanOrEqualTo(String value) {
            addCriterion("JIGYOSHO_NM >=", value, "JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_NMLessThan(String value) {
            addCriterion("JIGYOSHO_NM <", value, "JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_NMLessThanOrEqualTo(String value) {
            addCriterion("JIGYOSHO_NM <=", value, "JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_NMLike(String value) {
            addCriterion("JIGYOSHO_NM like", value, "JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_NMNotLike(String value) {
            addCriterion("JIGYOSHO_NM not like", value, "JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_NMIn(List<String> values) {
            addCriterion("JIGYOSHO_NM in", values, "JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_NMNotIn(List<String> values) {
            addCriterion("JIGYOSHO_NM not in", values, "JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_NMBetween(String value1, String value2) {
            addCriterion("JIGYOSHO_NM between", value1, value2, "JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_NMNotBetween(String value1, String value2) {
            addCriterion("JIGYOSHO_NM not between", value1, value2, "JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KN_NMIsNull() {
            addCriterion("JIGYOSHO_KN_NM is null");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KN_NMIsNotNull() {
            addCriterion("JIGYOSHO_KN_NM is not null");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KN_NMEqualTo(String value) {
            addCriterion("JIGYOSHO_KN_NM =", value, "JIGYOSHO_KN_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KN_NMNotEqualTo(String value) {
            addCriterion("JIGYOSHO_KN_NM <>", value, "JIGYOSHO_KN_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KN_NMGreaterThan(String value) {
            addCriterion("JIGYOSHO_KN_NM >", value, "JIGYOSHO_KN_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KN_NMGreaterThanOrEqualTo(String value) {
            addCriterion("JIGYOSHO_KN_NM >=", value, "JIGYOSHO_KN_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KN_NMLessThan(String value) {
            addCriterion("JIGYOSHO_KN_NM <", value, "JIGYOSHO_KN_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KN_NMLessThanOrEqualTo(String value) {
            addCriterion("JIGYOSHO_KN_NM <=", value, "JIGYOSHO_KN_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KN_NMLike(String value) {
            addCriterion("JIGYOSHO_KN_NM like", value, "JIGYOSHO_KN_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KN_NMNotLike(String value) {
            addCriterion("JIGYOSHO_KN_NM not like", value, "JIGYOSHO_KN_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KN_NMIn(List<String> values) {
            addCriterion("JIGYOSHO_KN_NM in", values, "JIGYOSHO_KN_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KN_NMNotIn(List<String> values) {
            addCriterion("JIGYOSHO_KN_NM not in", values, "JIGYOSHO_KN_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KN_NMBetween(String value1, String value2) {
            addCriterion("JIGYOSHO_KN_NM between", value1, value2, "JIGYOSHO_KN_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KN_NMNotBetween(String value1, String value2) {
            addCriterion("JIGYOSHO_KN_NM not between", value1, value2, "JIGYOSHO_KN_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_RNMIsNull() {
            addCriterion("JIGYOSHO_RNM is null");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_RNMIsNotNull() {
            addCriterion("JIGYOSHO_RNM is not null");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_RNMEqualTo(String value) {
            addCriterion("JIGYOSHO_RNM =", value, "JIGYOSHO_RNM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_RNMNotEqualTo(String value) {
            addCriterion("JIGYOSHO_RNM <>", value, "JIGYOSHO_RNM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_RNMGreaterThan(String value) {
            addCriterion("JIGYOSHO_RNM >", value, "JIGYOSHO_RNM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_RNMGreaterThanOrEqualTo(String value) {
            addCriterion("JIGYOSHO_RNM >=", value, "JIGYOSHO_RNM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_RNMLessThan(String value) {
            addCriterion("JIGYOSHO_RNM <", value, "JIGYOSHO_RNM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_RNMLessThanOrEqualTo(String value) {
            addCriterion("JIGYOSHO_RNM <=", value, "JIGYOSHO_RNM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_RNMLike(String value) {
            addCriterion("JIGYOSHO_RNM like", value, "JIGYOSHO_RNM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_RNMNotLike(String value) {
            addCriterion("JIGYOSHO_RNM not like", value, "JIGYOSHO_RNM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_RNMIn(List<String> values) {
            addCriterion("JIGYOSHO_RNM in", values, "JIGYOSHO_RNM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_RNMNotIn(List<String> values) {
            addCriterion("JIGYOSHO_RNM not in", values, "JIGYOSHO_RNM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_RNMBetween(String value1, String value2) {
            addCriterion("JIGYOSHO_RNM between", value1, value2, "JIGYOSHO_RNM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_RNMNotBetween(String value1, String value2) {
            addCriterion("JIGYOSHO_RNM not between", value1, value2, "JIGYOSHO_RNM");
            return (Criteria) this;
        }

        public Criteria andJUSHO_CDIsNull() {
            addCriterion("JUSHO_CD is null");
            return (Criteria) this;
        }

        public Criteria andJUSHO_CDIsNotNull() {
            addCriterion("JUSHO_CD is not null");
            return (Criteria) this;
        }

        public Criteria andJUSHO_CDEqualTo(String value) {
            addCriterion("JUSHO_CD =", value, "JUSHO_CD");
            return (Criteria) this;
        }

        public Criteria andJUSHO_CDNotEqualTo(String value) {
            addCriterion("JUSHO_CD <>", value, "JUSHO_CD");
            return (Criteria) this;
        }

        public Criteria andJUSHO_CDGreaterThan(String value) {
            addCriterion("JUSHO_CD >", value, "JUSHO_CD");
            return (Criteria) this;
        }

        public Criteria andJUSHO_CDGreaterThanOrEqualTo(String value) {
            addCriterion("JUSHO_CD >=", value, "JUSHO_CD");
            return (Criteria) this;
        }

        public Criteria andJUSHO_CDLessThan(String value) {
            addCriterion("JUSHO_CD <", value, "JUSHO_CD");
            return (Criteria) this;
        }

        public Criteria andJUSHO_CDLessThanOrEqualTo(String value) {
            addCriterion("JUSHO_CD <=", value, "JUSHO_CD");
            return (Criteria) this;
        }

        public Criteria andJUSHO_CDLike(String value) {
            addCriterion("JUSHO_CD like", value, "JUSHO_CD");
            return (Criteria) this;
        }

        public Criteria andJUSHO_CDNotLike(String value) {
            addCriterion("JUSHO_CD not like", value, "JUSHO_CD");
            return (Criteria) this;
        }

        public Criteria andJUSHO_CDIn(List<String> values) {
            addCriterion("JUSHO_CD in", values, "JUSHO_CD");
            return (Criteria) this;
        }

        public Criteria andJUSHO_CDNotIn(List<String> values) {
            addCriterion("JUSHO_CD not in", values, "JUSHO_CD");
            return (Criteria) this;
        }

        public Criteria andJUSHO_CDBetween(String value1, String value2) {
            addCriterion("JUSHO_CD between", value1, value2, "JUSHO_CD");
            return (Criteria) this;
        }

        public Criteria andJUSHO_CDNotBetween(String value1, String value2) {
            addCriterion("JUSHO_CD not between", value1, value2, "JUSHO_CD");
            return (Criteria) this;
        }

        public Criteria andTODOFUKEN_NMIsNull() {
            addCriterion("TODOFUKEN_NM is null");
            return (Criteria) this;
        }

        public Criteria andTODOFUKEN_NMIsNotNull() {
            addCriterion("TODOFUKEN_NM is not null");
            return (Criteria) this;
        }

        public Criteria andTODOFUKEN_NMEqualTo(String value) {
            addCriterion("TODOFUKEN_NM =", value, "TODOFUKEN_NM");
            return (Criteria) this;
        }

        public Criteria andTODOFUKEN_NMNotEqualTo(String value) {
            addCriterion("TODOFUKEN_NM <>", value, "TODOFUKEN_NM");
            return (Criteria) this;
        }

        public Criteria andTODOFUKEN_NMGreaterThan(String value) {
            addCriterion("TODOFUKEN_NM >", value, "TODOFUKEN_NM");
            return (Criteria) this;
        }

        public Criteria andTODOFUKEN_NMGreaterThanOrEqualTo(String value) {
            addCriterion("TODOFUKEN_NM >=", value, "TODOFUKEN_NM");
            return (Criteria) this;
        }

        public Criteria andTODOFUKEN_NMLessThan(String value) {
            addCriterion("TODOFUKEN_NM <", value, "TODOFUKEN_NM");
            return (Criteria) this;
        }

        public Criteria andTODOFUKEN_NMLessThanOrEqualTo(String value) {
            addCriterion("TODOFUKEN_NM <=", value, "TODOFUKEN_NM");
            return (Criteria) this;
        }

        public Criteria andTODOFUKEN_NMLike(String value) {
            addCriterion("TODOFUKEN_NM like", value, "TODOFUKEN_NM");
            return (Criteria) this;
        }

        public Criteria andTODOFUKEN_NMNotLike(String value) {
            addCriterion("TODOFUKEN_NM not like", value, "TODOFUKEN_NM");
            return (Criteria) this;
        }

        public Criteria andTODOFUKEN_NMIn(List<String> values) {
            addCriterion("TODOFUKEN_NM in", values, "TODOFUKEN_NM");
            return (Criteria) this;
        }

        public Criteria andTODOFUKEN_NMNotIn(List<String> values) {
            addCriterion("TODOFUKEN_NM not in", values, "TODOFUKEN_NM");
            return (Criteria) this;
        }

        public Criteria andTODOFUKEN_NMBetween(String value1, String value2) {
            addCriterion("TODOFUKEN_NM between", value1, value2, "TODOFUKEN_NM");
            return (Criteria) this;
        }

        public Criteria andTODOFUKEN_NMNotBetween(String value1, String value2) {
            addCriterion("TODOFUKEN_NM not between", value1, value2, "TODOFUKEN_NM");
            return (Criteria) this;
        }

        public Criteria andSHIKUCHOSON_NMIsNull() {
            addCriterion("SHIKUCHOSON_NM is null");
            return (Criteria) this;
        }

        public Criteria andSHIKUCHOSON_NMIsNotNull() {
            addCriterion("SHIKUCHOSON_NM is not null");
            return (Criteria) this;
        }

        public Criteria andSHIKUCHOSON_NMEqualTo(String value) {
            addCriterion("SHIKUCHOSON_NM =", value, "SHIKUCHOSON_NM");
            return (Criteria) this;
        }

        public Criteria andSHIKUCHOSON_NMNotEqualTo(String value) {
            addCriterion("SHIKUCHOSON_NM <>", value, "SHIKUCHOSON_NM");
            return (Criteria) this;
        }

        public Criteria andSHIKUCHOSON_NMGreaterThan(String value) {
            addCriterion("SHIKUCHOSON_NM >", value, "SHIKUCHOSON_NM");
            return (Criteria) this;
        }

        public Criteria andSHIKUCHOSON_NMGreaterThanOrEqualTo(String value) {
            addCriterion("SHIKUCHOSON_NM >=", value, "SHIKUCHOSON_NM");
            return (Criteria) this;
        }

        public Criteria andSHIKUCHOSON_NMLessThan(String value) {
            addCriterion("SHIKUCHOSON_NM <", value, "SHIKUCHOSON_NM");
            return (Criteria) this;
        }

        public Criteria andSHIKUCHOSON_NMLessThanOrEqualTo(String value) {
            addCriterion("SHIKUCHOSON_NM <=", value, "SHIKUCHOSON_NM");
            return (Criteria) this;
        }

        public Criteria andSHIKUCHOSON_NMLike(String value) {
            addCriterion("SHIKUCHOSON_NM like", value, "SHIKUCHOSON_NM");
            return (Criteria) this;
        }

        public Criteria andSHIKUCHOSON_NMNotLike(String value) {
            addCriterion("SHIKUCHOSON_NM not like", value, "SHIKUCHOSON_NM");
            return (Criteria) this;
        }

        public Criteria andSHIKUCHOSON_NMIn(List<String> values) {
            addCriterion("SHIKUCHOSON_NM in", values, "SHIKUCHOSON_NM");
            return (Criteria) this;
        }

        public Criteria andSHIKUCHOSON_NMNotIn(List<String> values) {
            addCriterion("SHIKUCHOSON_NM not in", values, "SHIKUCHOSON_NM");
            return (Criteria) this;
        }

        public Criteria andSHIKUCHOSON_NMBetween(String value1, String value2) {
            addCriterion("SHIKUCHOSON_NM between", value1, value2, "SHIKUCHOSON_NM");
            return (Criteria) this;
        }

        public Criteria andSHIKUCHOSON_NMNotBetween(String value1, String value2) {
            addCriterion("SHIKUCHOSON_NM not between", value1, value2, "SHIKUCHOSON_NM");
            return (Criteria) this;
        }

        public Criteria andOAZA_NMIsNull() {
            addCriterion("OAZA_NM is null");
            return (Criteria) this;
        }

        public Criteria andOAZA_NMIsNotNull() {
            addCriterion("OAZA_NM is not null");
            return (Criteria) this;
        }

        public Criteria andOAZA_NMEqualTo(String value) {
            addCriterion("OAZA_NM =", value, "OAZA_NM");
            return (Criteria) this;
        }

        public Criteria andOAZA_NMNotEqualTo(String value) {
            addCriterion("OAZA_NM <>", value, "OAZA_NM");
            return (Criteria) this;
        }

        public Criteria andOAZA_NMGreaterThan(String value) {
            addCriterion("OAZA_NM >", value, "OAZA_NM");
            return (Criteria) this;
        }

        public Criteria andOAZA_NMGreaterThanOrEqualTo(String value) {
            addCriterion("OAZA_NM >=", value, "OAZA_NM");
            return (Criteria) this;
        }

        public Criteria andOAZA_NMLessThan(String value) {
            addCriterion("OAZA_NM <", value, "OAZA_NM");
            return (Criteria) this;
        }

        public Criteria andOAZA_NMLessThanOrEqualTo(String value) {
            addCriterion("OAZA_NM <=", value, "OAZA_NM");
            return (Criteria) this;
        }

        public Criteria andOAZA_NMLike(String value) {
            addCriterion("OAZA_NM like", value, "OAZA_NM");
            return (Criteria) this;
        }

        public Criteria andOAZA_NMNotLike(String value) {
            addCriterion("OAZA_NM not like", value, "OAZA_NM");
            return (Criteria) this;
        }

        public Criteria andOAZA_NMIn(List<String> values) {
            addCriterion("OAZA_NM in", values, "OAZA_NM");
            return (Criteria) this;
        }

        public Criteria andOAZA_NMNotIn(List<String> values) {
            addCriterion("OAZA_NM not in", values, "OAZA_NM");
            return (Criteria) this;
        }

        public Criteria andOAZA_NMBetween(String value1, String value2) {
            addCriterion("OAZA_NM between", value1, value2, "OAZA_NM");
            return (Criteria) this;
        }

        public Criteria andOAZA_NMNotBetween(String value1, String value2) {
            addCriterion("OAZA_NM not between", value1, value2, "OAZA_NM");
            return (Criteria) this;
        }

        public Criteria andCHOME_NMIsNull() {
            addCriterion("CHOME_NM is null");
            return (Criteria) this;
        }

        public Criteria andCHOME_NMIsNotNull() {
            addCriterion("CHOME_NM is not null");
            return (Criteria) this;
        }

        public Criteria andCHOME_NMEqualTo(String value) {
            addCriterion("CHOME_NM =", value, "CHOME_NM");
            return (Criteria) this;
        }

        public Criteria andCHOME_NMNotEqualTo(String value) {
            addCriterion("CHOME_NM <>", value, "CHOME_NM");
            return (Criteria) this;
        }

        public Criteria andCHOME_NMGreaterThan(String value) {
            addCriterion("CHOME_NM >", value, "CHOME_NM");
            return (Criteria) this;
        }

        public Criteria andCHOME_NMGreaterThanOrEqualTo(String value) {
            addCriterion("CHOME_NM >=", value, "CHOME_NM");
            return (Criteria) this;
        }

        public Criteria andCHOME_NMLessThan(String value) {
            addCriterion("CHOME_NM <", value, "CHOME_NM");
            return (Criteria) this;
        }

        public Criteria andCHOME_NMLessThanOrEqualTo(String value) {
            addCriterion("CHOME_NM <=", value, "CHOME_NM");
            return (Criteria) this;
        }

        public Criteria andCHOME_NMLike(String value) {
            addCriterion("CHOME_NM like", value, "CHOME_NM");
            return (Criteria) this;
        }

        public Criteria andCHOME_NMNotLike(String value) {
            addCriterion("CHOME_NM not like", value, "CHOME_NM");
            return (Criteria) this;
        }

        public Criteria andCHOME_NMIn(List<String> values) {
            addCriterion("CHOME_NM in", values, "CHOME_NM");
            return (Criteria) this;
        }

        public Criteria andCHOME_NMNotIn(List<String> values) {
            addCriterion("CHOME_NM not in", values, "CHOME_NM");
            return (Criteria) this;
        }

        public Criteria andCHOME_NMBetween(String value1, String value2) {
            addCriterion("CHOME_NM between", value1, value2, "CHOME_NM");
            return (Criteria) this;
        }

        public Criteria andCHOME_NMNotBetween(String value1, String value2) {
            addCriterion("CHOME_NM not between", value1, value2, "CHOME_NM");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_JUSHO_1IsNull() {
            addCriterion("HOSOKU_JUSHO_1 is null");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_JUSHO_1IsNotNull() {
            addCriterion("HOSOKU_JUSHO_1 is not null");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_JUSHO_1EqualTo(String value) {
            addCriterion("HOSOKU_JUSHO_1 =", value, "HOSOKU_JUSHO_1");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_JUSHO_1NotEqualTo(String value) {
            addCriterion("HOSOKU_JUSHO_1 <>", value, "HOSOKU_JUSHO_1");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_JUSHO_1GreaterThan(String value) {
            addCriterion("HOSOKU_JUSHO_1 >", value, "HOSOKU_JUSHO_1");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_JUSHO_1GreaterThanOrEqualTo(String value) {
            addCriterion("HOSOKU_JUSHO_1 >=", value, "HOSOKU_JUSHO_1");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_JUSHO_1LessThan(String value) {
            addCriterion("HOSOKU_JUSHO_1 <", value, "HOSOKU_JUSHO_1");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_JUSHO_1LessThanOrEqualTo(String value) {
            addCriterion("HOSOKU_JUSHO_1 <=", value, "HOSOKU_JUSHO_1");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_JUSHO_1Like(String value) {
            addCriterion("HOSOKU_JUSHO_1 like", value, "HOSOKU_JUSHO_1");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_JUSHO_1NotLike(String value) {
            addCriterion("HOSOKU_JUSHO_1 not like", value, "HOSOKU_JUSHO_1");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_JUSHO_1In(List<String> values) {
            addCriterion("HOSOKU_JUSHO_1 in", values, "HOSOKU_JUSHO_1");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_JUSHO_1NotIn(List<String> values) {
            addCriterion("HOSOKU_JUSHO_1 not in", values, "HOSOKU_JUSHO_1");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_JUSHO_1Between(String value1, String value2) {
            addCriterion("HOSOKU_JUSHO_1 between", value1, value2, "HOSOKU_JUSHO_1");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_JUSHO_1NotBetween(String value1, String value2) {
            addCriterion("HOSOKU_JUSHO_1 not between", value1, value2, "HOSOKU_JUSHO_1");
            return (Criteria) this;
        }

        public Criteria andYUBIN_NOIsNull() {
            addCriterion("YUBIN_NO is null");
            return (Criteria) this;
        }

        public Criteria andYUBIN_NOIsNotNull() {
            addCriterion("YUBIN_NO is not null");
            return (Criteria) this;
        }

        public Criteria andYUBIN_NOEqualTo(String value) {
            addCriterion("YUBIN_NO =", value, "YUBIN_NO");
            return (Criteria) this;
        }

        public Criteria andYUBIN_NONotEqualTo(String value) {
            addCriterion("YUBIN_NO <>", value, "YUBIN_NO");
            return (Criteria) this;
        }

        public Criteria andYUBIN_NOGreaterThan(String value) {
            addCriterion("YUBIN_NO >", value, "YUBIN_NO");
            return (Criteria) this;
        }

        public Criteria andYUBIN_NOGreaterThanOrEqualTo(String value) {
            addCriterion("YUBIN_NO >=", value, "YUBIN_NO");
            return (Criteria) this;
        }

        public Criteria andYUBIN_NOLessThan(String value) {
            addCriterion("YUBIN_NO <", value, "YUBIN_NO");
            return (Criteria) this;
        }

        public Criteria andYUBIN_NOLessThanOrEqualTo(String value) {
            addCriterion("YUBIN_NO <=", value, "YUBIN_NO");
            return (Criteria) this;
        }

        public Criteria andYUBIN_NOLike(String value) {
            addCriterion("YUBIN_NO like", value, "YUBIN_NO");
            return (Criteria) this;
        }

        public Criteria andYUBIN_NONotLike(String value) {
            addCriterion("YUBIN_NO not like", value, "YUBIN_NO");
            return (Criteria) this;
        }

        public Criteria andYUBIN_NOIn(List<String> values) {
            addCriterion("YUBIN_NO in", values, "YUBIN_NO");
            return (Criteria) this;
        }

        public Criteria andYUBIN_NONotIn(List<String> values) {
            addCriterion("YUBIN_NO not in", values, "YUBIN_NO");
            return (Criteria) this;
        }

        public Criteria andYUBIN_NOBetween(String value1, String value2) {
            addCriterion("YUBIN_NO between", value1, value2, "YUBIN_NO");
            return (Criteria) this;
        }

        public Criteria andYUBIN_NONotBetween(String value1, String value2) {
            addCriterion("YUBIN_NO not between", value1, value2, "YUBIN_NO");
            return (Criteria) this;
        }

        public Criteria andJUSHO_BANCHIIsNull() {
            addCriterion("JUSHO_BANCHI is null");
            return (Criteria) this;
        }

        public Criteria andJUSHO_BANCHIIsNotNull() {
            addCriterion("JUSHO_BANCHI is not null");
            return (Criteria) this;
        }

        public Criteria andJUSHO_BANCHIEqualTo(String value) {
            addCriterion("JUSHO_BANCHI =", value, "JUSHO_BANCHI");
            return (Criteria) this;
        }

        public Criteria andJUSHO_BANCHINotEqualTo(String value) {
            addCriterion("JUSHO_BANCHI <>", value, "JUSHO_BANCHI");
            return (Criteria) this;
        }

        public Criteria andJUSHO_BANCHIGreaterThan(String value) {
            addCriterion("JUSHO_BANCHI >", value, "JUSHO_BANCHI");
            return (Criteria) this;
        }

        public Criteria andJUSHO_BANCHIGreaterThanOrEqualTo(String value) {
            addCriterion("JUSHO_BANCHI >=", value, "JUSHO_BANCHI");
            return (Criteria) this;
        }

        public Criteria andJUSHO_BANCHILessThan(String value) {
            addCriterion("JUSHO_BANCHI <", value, "JUSHO_BANCHI");
            return (Criteria) this;
        }

        public Criteria andJUSHO_BANCHILessThanOrEqualTo(String value) {
            addCriterion("JUSHO_BANCHI <=", value, "JUSHO_BANCHI");
            return (Criteria) this;
        }

        public Criteria andJUSHO_BANCHILike(String value) {
            addCriterion("JUSHO_BANCHI like", value, "JUSHO_BANCHI");
            return (Criteria) this;
        }

        public Criteria andJUSHO_BANCHINotLike(String value) {
            addCriterion("JUSHO_BANCHI not like", value, "JUSHO_BANCHI");
            return (Criteria) this;
        }

        public Criteria andJUSHO_BANCHIIn(List<String> values) {
            addCriterion("JUSHO_BANCHI in", values, "JUSHO_BANCHI");
            return (Criteria) this;
        }

        public Criteria andJUSHO_BANCHINotIn(List<String> values) {
            addCriterion("JUSHO_BANCHI not in", values, "JUSHO_BANCHI");
            return (Criteria) this;
        }

        public Criteria andJUSHO_BANCHIBetween(String value1, String value2) {
            addCriterion("JUSHO_BANCHI between", value1, value2, "JUSHO_BANCHI");
            return (Criteria) this;
        }

        public Criteria andJUSHO_BANCHINotBetween(String value1, String value2) {
            addCriterion("JUSHO_BANCHI not between", value1, value2, "JUSHO_BANCHI");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_NMIsNull() {
            addCriterion("TATEMONO_NM is null");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_NMIsNotNull() {
            addCriterion("TATEMONO_NM is not null");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_NMEqualTo(String value) {
            addCriterion("TATEMONO_NM =", value, "TATEMONO_NM");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_NMNotEqualTo(String value) {
            addCriterion("TATEMONO_NM <>", value, "TATEMONO_NM");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_NMGreaterThan(String value) {
            addCriterion("TATEMONO_NM >", value, "TATEMONO_NM");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_NMGreaterThanOrEqualTo(String value) {
            addCriterion("TATEMONO_NM >=", value, "TATEMONO_NM");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_NMLessThan(String value) {
            addCriterion("TATEMONO_NM <", value, "TATEMONO_NM");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_NMLessThanOrEqualTo(String value) {
            addCriterion("TATEMONO_NM <=", value, "TATEMONO_NM");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_NMLike(String value) {
            addCriterion("TATEMONO_NM like", value, "TATEMONO_NM");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_NMNotLike(String value) {
            addCriterion("TATEMONO_NM not like", value, "TATEMONO_NM");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_NMIn(List<String> values) {
            addCriterion("TATEMONO_NM in", values, "TATEMONO_NM");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_NMNotIn(List<String> values) {
            addCriterion("TATEMONO_NM not in", values, "TATEMONO_NM");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_NMBetween(String value1, String value2) {
            addCriterion("TATEMONO_NM between", value1, value2, "TATEMONO_NM");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_NMNotBetween(String value1, String value2) {
            addCriterion("TATEMONO_NM not between", value1, value2, "TATEMONO_NM");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_KN_NMIsNull() {
            addCriterion("TATEMONO_KN_NM is null");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_KN_NMIsNotNull() {
            addCriterion("TATEMONO_KN_NM is not null");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_KN_NMEqualTo(String value) {
            addCriterion("TATEMONO_KN_NM =", value, "TATEMONO_KN_NM");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_KN_NMNotEqualTo(String value) {
            addCriterion("TATEMONO_KN_NM <>", value, "TATEMONO_KN_NM");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_KN_NMGreaterThan(String value) {
            addCriterion("TATEMONO_KN_NM >", value, "TATEMONO_KN_NM");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_KN_NMGreaterThanOrEqualTo(String value) {
            addCriterion("TATEMONO_KN_NM >=", value, "TATEMONO_KN_NM");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_KN_NMLessThan(String value) {
            addCriterion("TATEMONO_KN_NM <", value, "TATEMONO_KN_NM");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_KN_NMLessThanOrEqualTo(String value) {
            addCriterion("TATEMONO_KN_NM <=", value, "TATEMONO_KN_NM");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_KN_NMLike(String value) {
            addCriterion("TATEMONO_KN_NM like", value, "TATEMONO_KN_NM");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_KN_NMNotLike(String value) {
            addCriterion("TATEMONO_KN_NM not like", value, "TATEMONO_KN_NM");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_KN_NMIn(List<String> values) {
            addCriterion("TATEMONO_KN_NM in", values, "TATEMONO_KN_NM");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_KN_NMNotIn(List<String> values) {
            addCriterion("TATEMONO_KN_NM not in", values, "TATEMONO_KN_NM");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_KN_NMBetween(String value1, String value2) {
            addCriterion("TATEMONO_KN_NM between", value1, value2, "TATEMONO_KN_NM");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_KN_NMNotBetween(String value1, String value2) {
            addCriterion("TATEMONO_KN_NM not between", value1, value2, "TATEMONO_KN_NM");
            return (Criteria) this;
        }

        public Criteria andTO_NMIsNull() {
            addCriterion("TO_NM is null");
            return (Criteria) this;
        }

        public Criteria andTO_NMIsNotNull() {
            addCriterion("TO_NM is not null");
            return (Criteria) this;
        }

        public Criteria andTO_NMEqualTo(String value) {
            addCriterion("TO_NM =", value, "TO_NM");
            return (Criteria) this;
        }

        public Criteria andTO_NMNotEqualTo(String value) {
            addCriterion("TO_NM <>", value, "TO_NM");
            return (Criteria) this;
        }

        public Criteria andTO_NMGreaterThan(String value) {
            addCriterion("TO_NM >", value, "TO_NM");
            return (Criteria) this;
        }

        public Criteria andTO_NMGreaterThanOrEqualTo(String value) {
            addCriterion("TO_NM >=", value, "TO_NM");
            return (Criteria) this;
        }

        public Criteria andTO_NMLessThan(String value) {
            addCriterion("TO_NM <", value, "TO_NM");
            return (Criteria) this;
        }

        public Criteria andTO_NMLessThanOrEqualTo(String value) {
            addCriterion("TO_NM <=", value, "TO_NM");
            return (Criteria) this;
        }

        public Criteria andTO_NMLike(String value) {
            addCriterion("TO_NM like", value, "TO_NM");
            return (Criteria) this;
        }

        public Criteria andTO_NMNotLike(String value) {
            addCriterion("TO_NM not like", value, "TO_NM");
            return (Criteria) this;
        }

        public Criteria andTO_NMIn(List<String> values) {
            addCriterion("TO_NM in", values, "TO_NM");
            return (Criteria) this;
        }

        public Criteria andTO_NMNotIn(List<String> values) {
            addCriterion("TO_NM not in", values, "TO_NM");
            return (Criteria) this;
        }

        public Criteria andTO_NMBetween(String value1, String value2) {
            addCriterion("TO_NM between", value1, value2, "TO_NM");
            return (Criteria) this;
        }

        public Criteria andTO_NMNotBetween(String value1, String value2) {
            addCriterion("TO_NM not between", value1, value2, "TO_NM");
            return (Criteria) this;
        }

        public Criteria andKAI_NMIsNull() {
            addCriterion("KAI_NM is null");
            return (Criteria) this;
        }

        public Criteria andKAI_NMIsNotNull() {
            addCriterion("KAI_NM is not null");
            return (Criteria) this;
        }

        public Criteria andKAI_NMEqualTo(String value) {
            addCriterion("KAI_NM =", value, "KAI_NM");
            return (Criteria) this;
        }

        public Criteria andKAI_NMNotEqualTo(String value) {
            addCriterion("KAI_NM <>", value, "KAI_NM");
            return (Criteria) this;
        }

        public Criteria andKAI_NMGreaterThan(String value) {
            addCriterion("KAI_NM >", value, "KAI_NM");
            return (Criteria) this;
        }

        public Criteria andKAI_NMGreaterThanOrEqualTo(String value) {
            addCriterion("KAI_NM >=", value, "KAI_NM");
            return (Criteria) this;
        }

        public Criteria andKAI_NMLessThan(String value) {
            addCriterion("KAI_NM <", value, "KAI_NM");
            return (Criteria) this;
        }

        public Criteria andKAI_NMLessThanOrEqualTo(String value) {
            addCriterion("KAI_NM <=", value, "KAI_NM");
            return (Criteria) this;
        }

        public Criteria andKAI_NMLike(String value) {
            addCriterion("KAI_NM like", value, "KAI_NM");
            return (Criteria) this;
        }

        public Criteria andKAI_NMNotLike(String value) {
            addCriterion("KAI_NM not like", value, "KAI_NM");
            return (Criteria) this;
        }

        public Criteria andKAI_NMIn(List<String> values) {
            addCriterion("KAI_NM in", values, "KAI_NM");
            return (Criteria) this;
        }

        public Criteria andKAI_NMNotIn(List<String> values) {
            addCriterion("KAI_NM not in", values, "KAI_NM");
            return (Criteria) this;
        }

        public Criteria andKAI_NMBetween(String value1, String value2) {
            addCriterion("KAI_NM between", value1, value2, "KAI_NM");
            return (Criteria) this;
        }

        public Criteria andKAI_NMNotBetween(String value1, String value2) {
            addCriterion("KAI_NM not between", value1, value2, "KAI_NM");
            return (Criteria) this;
        }

        public Criteria andKUKAKU_NMIsNull() {
            addCriterion("KUKAKU_NM is null");
            return (Criteria) this;
        }

        public Criteria andKUKAKU_NMIsNotNull() {
            addCriterion("KUKAKU_NM is not null");
            return (Criteria) this;
        }

        public Criteria andKUKAKU_NMEqualTo(String value) {
            addCriterion("KUKAKU_NM =", value, "KUKAKU_NM");
            return (Criteria) this;
        }

        public Criteria andKUKAKU_NMNotEqualTo(String value) {
            addCriterion("KUKAKU_NM <>", value, "KUKAKU_NM");
            return (Criteria) this;
        }

        public Criteria andKUKAKU_NMGreaterThan(String value) {
            addCriterion("KUKAKU_NM >", value, "KUKAKU_NM");
            return (Criteria) this;
        }

        public Criteria andKUKAKU_NMGreaterThanOrEqualTo(String value) {
            addCriterion("KUKAKU_NM >=", value, "KUKAKU_NM");
            return (Criteria) this;
        }

        public Criteria andKUKAKU_NMLessThan(String value) {
            addCriterion("KUKAKU_NM <", value, "KUKAKU_NM");
            return (Criteria) this;
        }

        public Criteria andKUKAKU_NMLessThanOrEqualTo(String value) {
            addCriterion("KUKAKU_NM <=", value, "KUKAKU_NM");
            return (Criteria) this;
        }

        public Criteria andKUKAKU_NMLike(String value) {
            addCriterion("KUKAKU_NM like", value, "KUKAKU_NM");
            return (Criteria) this;
        }

        public Criteria andKUKAKU_NMNotLike(String value) {
            addCriterion("KUKAKU_NM not like", value, "KUKAKU_NM");
            return (Criteria) this;
        }

        public Criteria andKUKAKU_NMIn(List<String> values) {
            addCriterion("KUKAKU_NM in", values, "KUKAKU_NM");
            return (Criteria) this;
        }

        public Criteria andKUKAKU_NMNotIn(List<String> values) {
            addCriterion("KUKAKU_NM not in", values, "KUKAKU_NM");
            return (Criteria) this;
        }

        public Criteria andKUKAKU_NMBetween(String value1, String value2) {
            addCriterion("KUKAKU_NM between", value1, value2, "KUKAKU_NM");
            return (Criteria) this;
        }

        public Criteria andKUKAKU_NMNotBetween(String value1, String value2) {
            addCriterion("KUKAKU_NM not between", value1, value2, "KUKAKU_NM");
            return (Criteria) this;
        }

        public Criteria andHEYA_NMIsNull() {
            addCriterion("HEYA_NM is null");
            return (Criteria) this;
        }

        public Criteria andHEYA_NMIsNotNull() {
            addCriterion("HEYA_NM is not null");
            return (Criteria) this;
        }

        public Criteria andHEYA_NMEqualTo(String value) {
            addCriterion("HEYA_NM =", value, "HEYA_NM");
            return (Criteria) this;
        }

        public Criteria andHEYA_NMNotEqualTo(String value) {
            addCriterion("HEYA_NM <>", value, "HEYA_NM");
            return (Criteria) this;
        }

        public Criteria andHEYA_NMGreaterThan(String value) {
            addCriterion("HEYA_NM >", value, "HEYA_NM");
            return (Criteria) this;
        }

        public Criteria andHEYA_NMGreaterThanOrEqualTo(String value) {
            addCriterion("HEYA_NM >=", value, "HEYA_NM");
            return (Criteria) this;
        }

        public Criteria andHEYA_NMLessThan(String value) {
            addCriterion("HEYA_NM <", value, "HEYA_NM");
            return (Criteria) this;
        }

        public Criteria andHEYA_NMLessThanOrEqualTo(String value) {
            addCriterion("HEYA_NM <=", value, "HEYA_NM");
            return (Criteria) this;
        }

        public Criteria andHEYA_NMLike(String value) {
            addCriterion("HEYA_NM like", value, "HEYA_NM");
            return (Criteria) this;
        }

        public Criteria andHEYA_NMNotLike(String value) {
            addCriterion("HEYA_NM not like", value, "HEYA_NM");
            return (Criteria) this;
        }

        public Criteria andHEYA_NMIn(List<String> values) {
            addCriterion("HEYA_NM in", values, "HEYA_NM");
            return (Criteria) this;
        }

        public Criteria andHEYA_NMNotIn(List<String> values) {
            addCriterion("HEYA_NM not in", values, "HEYA_NM");
            return (Criteria) this;
        }

        public Criteria andHEYA_NMBetween(String value1, String value2) {
            addCriterion("HEYA_NM between", value1, value2, "HEYA_NM");
            return (Criteria) this;
        }

        public Criteria andHEYA_NMNotBetween(String value1, String value2) {
            addCriterion("HEYA_NM not between", value1, value2, "HEYA_NM");
            return (Criteria) this;
        }

        public Criteria andDENWA_NOIsNull() {
            addCriterion("DENWA_NO is null");
            return (Criteria) this;
        }

        public Criteria andDENWA_NOIsNotNull() {
            addCriterion("DENWA_NO is not null");
            return (Criteria) this;
        }

        public Criteria andDENWA_NOEqualTo(String value) {
            addCriterion("DENWA_NO =", value, "DENWA_NO");
            return (Criteria) this;
        }

        public Criteria andDENWA_NONotEqualTo(String value) {
            addCriterion("DENWA_NO <>", value, "DENWA_NO");
            return (Criteria) this;
        }

        public Criteria andDENWA_NOGreaterThan(String value) {
            addCriterion("DENWA_NO >", value, "DENWA_NO");
            return (Criteria) this;
        }

        public Criteria andDENWA_NOGreaterThanOrEqualTo(String value) {
            addCriterion("DENWA_NO >=", value, "DENWA_NO");
            return (Criteria) this;
        }

        public Criteria andDENWA_NOLessThan(String value) {
            addCriterion("DENWA_NO <", value, "DENWA_NO");
            return (Criteria) this;
        }

        public Criteria andDENWA_NOLessThanOrEqualTo(String value) {
            addCriterion("DENWA_NO <=", value, "DENWA_NO");
            return (Criteria) this;
        }

        public Criteria andDENWA_NOLike(String value) {
            addCriterion("DENWA_NO like", value, "DENWA_NO");
            return (Criteria) this;
        }

        public Criteria andDENWA_NONotLike(String value) {
            addCriterion("DENWA_NO not like", value, "DENWA_NO");
            return (Criteria) this;
        }

        public Criteria andDENWA_NOIn(List<String> values) {
            addCriterion("DENWA_NO in", values, "DENWA_NO");
            return (Criteria) this;
        }

        public Criteria andDENWA_NONotIn(List<String> values) {
            addCriterion("DENWA_NO not in", values, "DENWA_NO");
            return (Criteria) this;
        }

        public Criteria andDENWA_NOBetween(String value1, String value2) {
            addCriterion("DENWA_NO between", value1, value2, "DENWA_NO");
            return (Criteria) this;
        }

        public Criteria andDENWA_NONotBetween(String value1, String value2) {
            addCriterion("DENWA_NO not between", value1, value2, "DENWA_NO");
            return (Criteria) this;
        }

        public Criteria andDAIHYO_MAIL_ADDRESSIsNull() {
            addCriterion("DAIHYO_MAIL_ADDRESS is null");
            return (Criteria) this;
        }

        public Criteria andDAIHYO_MAIL_ADDRESSIsNotNull() {
            addCriterion("DAIHYO_MAIL_ADDRESS is not null");
            return (Criteria) this;
        }

        public Criteria andDAIHYO_MAIL_ADDRESSEqualTo(String value) {
            addCriterion("DAIHYO_MAIL_ADDRESS =", value, "DAIHYO_MAIL_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andDAIHYO_MAIL_ADDRESSNotEqualTo(String value) {
            addCriterion("DAIHYO_MAIL_ADDRESS <>", value, "DAIHYO_MAIL_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andDAIHYO_MAIL_ADDRESSGreaterThan(String value) {
            addCriterion("DAIHYO_MAIL_ADDRESS >", value, "DAIHYO_MAIL_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andDAIHYO_MAIL_ADDRESSGreaterThanOrEqualTo(String value) {
            addCriterion("DAIHYO_MAIL_ADDRESS >=", value, "DAIHYO_MAIL_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andDAIHYO_MAIL_ADDRESSLessThan(String value) {
            addCriterion("DAIHYO_MAIL_ADDRESS <", value, "DAIHYO_MAIL_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andDAIHYO_MAIL_ADDRESSLessThanOrEqualTo(String value) {
            addCriterion("DAIHYO_MAIL_ADDRESS <=", value, "DAIHYO_MAIL_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andDAIHYO_MAIL_ADDRESSLike(String value) {
            addCriterion("DAIHYO_MAIL_ADDRESS like", value, "DAIHYO_MAIL_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andDAIHYO_MAIL_ADDRESSNotLike(String value) {
            addCriterion("DAIHYO_MAIL_ADDRESS not like", value, "DAIHYO_MAIL_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andDAIHYO_MAIL_ADDRESSIn(List<String> values) {
            addCriterion("DAIHYO_MAIL_ADDRESS in", values, "DAIHYO_MAIL_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andDAIHYO_MAIL_ADDRESSNotIn(List<String> values) {
            addCriterion("DAIHYO_MAIL_ADDRESS not in", values, "DAIHYO_MAIL_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andDAIHYO_MAIL_ADDRESSBetween(String value1, String value2) {
            addCriterion("DAIHYO_MAIL_ADDRESS between", value1, value2, "DAIHYO_MAIL_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andDAIHYO_MAIL_ADDRESSNotBetween(String value1, String value2) {
            addCriterion("DAIHYO_MAIL_ADDRESS not between", value1, value2, "DAIHYO_MAIL_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andROMU_TANKA_AMTIsNull() {
            addCriterion("ROMU_TANKA_AMT is null");
            return (Criteria) this;
        }

        public Criteria andROMU_TANKA_AMTIsNotNull() {
            addCriterion("ROMU_TANKA_AMT is not null");
            return (Criteria) this;
        }

        public Criteria andROMU_TANKA_AMTEqualTo(Long value) {
            addCriterion("ROMU_TANKA_AMT =", value, "ROMU_TANKA_AMT");
            return (Criteria) this;
        }

        public Criteria andROMU_TANKA_AMTNotEqualTo(Long value) {
            addCriterion("ROMU_TANKA_AMT <>", value, "ROMU_TANKA_AMT");
            return (Criteria) this;
        }

        public Criteria andROMU_TANKA_AMTGreaterThan(Long value) {
            addCriterion("ROMU_TANKA_AMT >", value, "ROMU_TANKA_AMT");
            return (Criteria) this;
        }

        public Criteria andROMU_TANKA_AMTGreaterThanOrEqualTo(Long value) {
            addCriterion("ROMU_TANKA_AMT >=", value, "ROMU_TANKA_AMT");
            return (Criteria) this;
        }

        public Criteria andROMU_TANKA_AMTLessThan(Long value) {
            addCriterion("ROMU_TANKA_AMT <", value, "ROMU_TANKA_AMT");
            return (Criteria) this;
        }

        public Criteria andROMU_TANKA_AMTLessThanOrEqualTo(Long value) {
            addCriterion("ROMU_TANKA_AMT <=", value, "ROMU_TANKA_AMT");
            return (Criteria) this;
        }

        public Criteria andROMU_TANKA_AMTIn(List<Long> values) {
            addCriterion("ROMU_TANKA_AMT in", values, "ROMU_TANKA_AMT");
            return (Criteria) this;
        }

        public Criteria andROMU_TANKA_AMTNotIn(List<Long> values) {
            addCriterion("ROMU_TANKA_AMT not in", values, "ROMU_TANKA_AMT");
            return (Criteria) this;
        }

        public Criteria andROMU_TANKA_AMTBetween(Long value1, Long value2) {
            addCriterion("ROMU_TANKA_AMT between", value1, value2, "ROMU_TANKA_AMT");
            return (Criteria) this;
        }

        public Criteria andROMU_TANKA_AMTNotBetween(Long value1, Long value2) {
            addCriterion("ROMU_TANKA_AMT not between", value1, value2, "ROMU_TANKA_AMT");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_CDIsNull() {
            addCriterion("SHIHARAI_JIGYOSHO_CD is null");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_CDIsNotNull() {
            addCriterion("SHIHARAI_JIGYOSHO_CD is not null");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_CDEqualTo(String value) {
            addCriterion("SHIHARAI_JIGYOSHO_CD =", value, "SHIHARAI_JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_CDNotEqualTo(String value) {
            addCriterion("SHIHARAI_JIGYOSHO_CD <>", value, "SHIHARAI_JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_CDGreaterThan(String value) {
            addCriterion("SHIHARAI_JIGYOSHO_CD >", value, "SHIHARAI_JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_CDGreaterThanOrEqualTo(String value) {
            addCriterion("SHIHARAI_JIGYOSHO_CD >=", value, "SHIHARAI_JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_CDLessThan(String value) {
            addCriterion("SHIHARAI_JIGYOSHO_CD <", value, "SHIHARAI_JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_CDLessThanOrEqualTo(String value) {
            addCriterion("SHIHARAI_JIGYOSHO_CD <=", value, "SHIHARAI_JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_CDLike(String value) {
            addCriterion("SHIHARAI_JIGYOSHO_CD like", value, "SHIHARAI_JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_CDNotLike(String value) {
            addCriterion("SHIHARAI_JIGYOSHO_CD not like", value, "SHIHARAI_JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_CDIn(List<String> values) {
            addCriterion("SHIHARAI_JIGYOSHO_CD in", values, "SHIHARAI_JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_CDNotIn(List<String> values) {
            addCriterion("SHIHARAI_JIGYOSHO_CD not in", values, "SHIHARAI_JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_CDBetween(String value1, String value2) {
            addCriterion("SHIHARAI_JIGYOSHO_CD between", value1, value2, "SHIHARAI_JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_CDNotBetween(String value1, String value2) {
            addCriterion("SHIHARAI_JIGYOSHO_CD not between", value1, value2, "SHIHARAI_JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_NMIsNull() {
            addCriterion("SHIHARAI_JIGYOSHO_NM is null");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_NMIsNotNull() {
            addCriterion("SHIHARAI_JIGYOSHO_NM is not null");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_NMEqualTo(String value) {
            addCriterion("SHIHARAI_JIGYOSHO_NM =", value, "SHIHARAI_JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_NMNotEqualTo(String value) {
            addCriterion("SHIHARAI_JIGYOSHO_NM <>", value, "SHIHARAI_JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_NMGreaterThan(String value) {
            addCriterion("SHIHARAI_JIGYOSHO_NM >", value, "SHIHARAI_JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_NMGreaterThanOrEqualTo(String value) {
            addCriterion("SHIHARAI_JIGYOSHO_NM >=", value, "SHIHARAI_JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_NMLessThan(String value) {
            addCriterion("SHIHARAI_JIGYOSHO_NM <", value, "SHIHARAI_JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_NMLessThanOrEqualTo(String value) {
            addCriterion("SHIHARAI_JIGYOSHO_NM <=", value, "SHIHARAI_JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_NMLike(String value) {
            addCriterion("SHIHARAI_JIGYOSHO_NM like", value, "SHIHARAI_JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_NMNotLike(String value) {
            addCriterion("SHIHARAI_JIGYOSHO_NM not like", value, "SHIHARAI_JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_NMIn(List<String> values) {
            addCriterion("SHIHARAI_JIGYOSHO_NM in", values, "SHIHARAI_JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_NMNotIn(List<String> values) {
            addCriterion("SHIHARAI_JIGYOSHO_NM not in", values, "SHIHARAI_JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_NMBetween(String value1, String value2) {
            addCriterion("SHIHARAI_JIGYOSHO_NM between", value1, value2, "SHIHARAI_JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_NMNotBetween(String value1, String value2) {
            addCriterion("SHIHARAI_JIGYOSHO_NM not between", value1, value2, "SHIHARAI_JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_CDIsNull() {
            addCriterion("NYUKIN_JIGYOSHO_CD is null");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_CDIsNotNull() {
            addCriterion("NYUKIN_JIGYOSHO_CD is not null");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_CDEqualTo(String value) {
            addCriterion("NYUKIN_JIGYOSHO_CD =", value, "NYUKIN_JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_CDNotEqualTo(String value) {
            addCriterion("NYUKIN_JIGYOSHO_CD <>", value, "NYUKIN_JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_CDGreaterThan(String value) {
            addCriterion("NYUKIN_JIGYOSHO_CD >", value, "NYUKIN_JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_CDGreaterThanOrEqualTo(String value) {
            addCriterion("NYUKIN_JIGYOSHO_CD >=", value, "NYUKIN_JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_CDLessThan(String value) {
            addCriterion("NYUKIN_JIGYOSHO_CD <", value, "NYUKIN_JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_CDLessThanOrEqualTo(String value) {
            addCriterion("NYUKIN_JIGYOSHO_CD <=", value, "NYUKIN_JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_CDLike(String value) {
            addCriterion("NYUKIN_JIGYOSHO_CD like", value, "NYUKIN_JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_CDNotLike(String value) {
            addCriterion("NYUKIN_JIGYOSHO_CD not like", value, "NYUKIN_JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_CDIn(List<String> values) {
            addCriterion("NYUKIN_JIGYOSHO_CD in", values, "NYUKIN_JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_CDNotIn(List<String> values) {
            addCriterion("NYUKIN_JIGYOSHO_CD not in", values, "NYUKIN_JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_CDBetween(String value1, String value2) {
            addCriterion("NYUKIN_JIGYOSHO_CD between", value1, value2, "NYUKIN_JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_CDNotBetween(String value1, String value2) {
            addCriterion("NYUKIN_JIGYOSHO_CD not between", value1, value2, "NYUKIN_JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_NMIsNull() {
            addCriterion("NYUKIN_JIGYOSHO_NM is null");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_NMIsNotNull() {
            addCriterion("NYUKIN_JIGYOSHO_NM is not null");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_NMEqualTo(String value) {
            addCriterion("NYUKIN_JIGYOSHO_NM =", value, "NYUKIN_JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_NMNotEqualTo(String value) {
            addCriterion("NYUKIN_JIGYOSHO_NM <>", value, "NYUKIN_JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_NMGreaterThan(String value) {
            addCriterion("NYUKIN_JIGYOSHO_NM >", value, "NYUKIN_JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_NMGreaterThanOrEqualTo(String value) {
            addCriterion("NYUKIN_JIGYOSHO_NM >=", value, "NYUKIN_JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_NMLessThan(String value) {
            addCriterion("NYUKIN_JIGYOSHO_NM <", value, "NYUKIN_JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_NMLessThanOrEqualTo(String value) {
            addCriterion("NYUKIN_JIGYOSHO_NM <=", value, "NYUKIN_JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_NMLike(String value) {
            addCriterion("NYUKIN_JIGYOSHO_NM like", value, "NYUKIN_JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_NMNotLike(String value) {
            addCriterion("NYUKIN_JIGYOSHO_NM not like", value, "NYUKIN_JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_NMIn(List<String> values) {
            addCriterion("NYUKIN_JIGYOSHO_NM in", values, "NYUKIN_JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_NMNotIn(List<String> values) {
            addCriterion("NYUKIN_JIGYOSHO_NM not in", values, "NYUKIN_JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_NMBetween(String value1, String value2) {
            addCriterion("NYUKIN_JIGYOSHO_NM between", value1, value2, "NYUKIN_JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_NMNotBetween(String value1, String value2) {
            addCriterion("NYUKIN_JIGYOSHO_NM not between", value1, value2, "NYUKIN_JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_CDIsNull() {
            addCriterion("JISHA_KOZA_CD is null");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_CDIsNotNull() {
            addCriterion("JISHA_KOZA_CD is not null");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_CDEqualTo(String value) {
            addCriterion("JISHA_KOZA_CD =", value, "JISHA_KOZA_CD");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_CDNotEqualTo(String value) {
            addCriterion("JISHA_KOZA_CD <>", value, "JISHA_KOZA_CD");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_CDGreaterThan(String value) {
            addCriterion("JISHA_KOZA_CD >", value, "JISHA_KOZA_CD");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_CDGreaterThanOrEqualTo(String value) {
            addCriterion("JISHA_KOZA_CD >=", value, "JISHA_KOZA_CD");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_CDLessThan(String value) {
            addCriterion("JISHA_KOZA_CD <", value, "JISHA_KOZA_CD");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_CDLessThanOrEqualTo(String value) {
            addCriterion("JISHA_KOZA_CD <=", value, "JISHA_KOZA_CD");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_CDLike(String value) {
            addCriterion("JISHA_KOZA_CD like", value, "JISHA_KOZA_CD");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_CDNotLike(String value) {
            addCriterion("JISHA_KOZA_CD not like", value, "JISHA_KOZA_CD");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_CDIn(List<String> values) {
            addCriterion("JISHA_KOZA_CD in", values, "JISHA_KOZA_CD");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_CDNotIn(List<String> values) {
            addCriterion("JISHA_KOZA_CD not in", values, "JISHA_KOZA_CD");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_CDBetween(String value1, String value2) {
            addCriterion("JISHA_KOZA_CD between", value1, value2, "JISHA_KOZA_CD");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_CDNotBetween(String value1, String value2) {
            addCriterion("JISHA_KOZA_CD not between", value1, value2, "JISHA_KOZA_CD");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_NMIsNull() {
            addCriterion("JISHA_KOZA_NM is null");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_NMIsNotNull() {
            addCriterion("JISHA_KOZA_NM is not null");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_NMEqualTo(String value) {
            addCriterion("JISHA_KOZA_NM =", value, "JISHA_KOZA_NM");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_NMNotEqualTo(String value) {
            addCriterion("JISHA_KOZA_NM <>", value, "JISHA_KOZA_NM");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_NMGreaterThan(String value) {
            addCriterion("JISHA_KOZA_NM >", value, "JISHA_KOZA_NM");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_NMGreaterThanOrEqualTo(String value) {
            addCriterion("JISHA_KOZA_NM >=", value, "JISHA_KOZA_NM");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_NMLessThan(String value) {
            addCriterion("JISHA_KOZA_NM <", value, "JISHA_KOZA_NM");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_NMLessThanOrEqualTo(String value) {
            addCriterion("JISHA_KOZA_NM <=", value, "JISHA_KOZA_NM");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_NMLike(String value) {
            addCriterion("JISHA_KOZA_NM like", value, "JISHA_KOZA_NM");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_NMNotLike(String value) {
            addCriterion("JISHA_KOZA_NM not like", value, "JISHA_KOZA_NM");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_NMIn(List<String> values) {
            addCriterion("JISHA_KOZA_NM in", values, "JISHA_KOZA_NM");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_NMNotIn(List<String> values) {
            addCriterion("JISHA_KOZA_NM not in", values, "JISHA_KOZA_NM");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_NMBetween(String value1, String value2) {
            addCriterion("JISHA_KOZA_NM between", value1, value2, "JISHA_KOZA_NM");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_NMNotBetween(String value1, String value2) {
            addCriterion("JISHA_KOZA_NM not between", value1, value2, "JISHA_KOZA_NM");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01IsNull() {
            addCriterion("YOBI_KOMOKU_01 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01IsNotNull() {
            addCriterion("YOBI_KOMOKU_01 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_01 =", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_01 <>", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_01 >", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_01 >=", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01LessThan(String value) {
            addCriterion("YOBI_KOMOKU_01 <", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_01 <=", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01Like(String value) {
            addCriterion("YOBI_KOMOKU_01 like", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01NotLike(String value) {
            addCriterion("YOBI_KOMOKU_01 not like", value, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01In(List<String> values) {
            addCriterion("YOBI_KOMOKU_01 in", values, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_01 not in", values, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_01 between", value1, value2, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_01 not between", value1, value2, "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02IsNull() {
            addCriterion("YOBI_KOMOKU_02 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02IsNotNull() {
            addCriterion("YOBI_KOMOKU_02 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_02 =", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_02 <>", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_02 >", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_02 >=", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02LessThan(String value) {
            addCriterion("YOBI_KOMOKU_02 <", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_02 <=", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02Like(String value) {
            addCriterion("YOBI_KOMOKU_02 like", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02NotLike(String value) {
            addCriterion("YOBI_KOMOKU_02 not like", value, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02In(List<String> values) {
            addCriterion("YOBI_KOMOKU_02 in", values, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_02 not in", values, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_02 between", value1, value2, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_02 not between", value1, value2, "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03IsNull() {
            addCriterion("YOBI_KOMOKU_03 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03IsNotNull() {
            addCriterion("YOBI_KOMOKU_03 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_03 =", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_03 <>", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_03 >", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_03 >=", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03LessThan(String value) {
            addCriterion("YOBI_KOMOKU_03 <", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_03 <=", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03Like(String value) {
            addCriterion("YOBI_KOMOKU_03 like", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03NotLike(String value) {
            addCriterion("YOBI_KOMOKU_03 not like", value, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03In(List<String> values) {
            addCriterion("YOBI_KOMOKU_03 in", values, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_03 not in", values, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_03 between", value1, value2, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_03 not between", value1, value2, "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04IsNull() {
            addCriterion("YOBI_KOMOKU_04 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04IsNotNull() {
            addCriterion("YOBI_KOMOKU_04 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_04 =", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_04 <>", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_04 >", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_04 >=", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04LessThan(String value) {
            addCriterion("YOBI_KOMOKU_04 <", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_04 <=", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04Like(String value) {
            addCriterion("YOBI_KOMOKU_04 like", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04NotLike(String value) {
            addCriterion("YOBI_KOMOKU_04 not like", value, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04In(List<String> values) {
            addCriterion("YOBI_KOMOKU_04 in", values, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_04 not in", values, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_04 between", value1, value2, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_04 not between", value1, value2, "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05IsNull() {
            addCriterion("YOBI_KOMOKU_05 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05IsNotNull() {
            addCriterion("YOBI_KOMOKU_05 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_05 =", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_05 <>", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_05 >", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_05 >=", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05LessThan(String value) {
            addCriterion("YOBI_KOMOKU_05 <", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_05 <=", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05Like(String value) {
            addCriterion("YOBI_KOMOKU_05 like", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05NotLike(String value) {
            addCriterion("YOBI_KOMOKU_05 not like", value, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05In(List<String> values) {
            addCriterion("YOBI_KOMOKU_05 in", values, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_05 not in", values, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_05 between", value1, value2, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_05 not between", value1, value2, "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06IsNull() {
            addCriterion("YOBI_KOMOKU_06 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06IsNotNull() {
            addCriterion("YOBI_KOMOKU_06 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_06 =", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_06 <>", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_06 >", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_06 >=", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06LessThan(String value) {
            addCriterion("YOBI_KOMOKU_06 <", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_06 <=", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06Like(String value) {
            addCriterion("YOBI_KOMOKU_06 like", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06NotLike(String value) {
            addCriterion("YOBI_KOMOKU_06 not like", value, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06In(List<String> values) {
            addCriterion("YOBI_KOMOKU_06 in", values, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_06 not in", values, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_06 between", value1, value2, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_06 not between", value1, value2, "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07IsNull() {
            addCriterion("YOBI_KOMOKU_07 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07IsNotNull() {
            addCriterion("YOBI_KOMOKU_07 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_07 =", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_07 <>", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_07 >", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_07 >=", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07LessThan(String value) {
            addCriterion("YOBI_KOMOKU_07 <", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_07 <=", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07Like(String value) {
            addCriterion("YOBI_KOMOKU_07 like", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07NotLike(String value) {
            addCriterion("YOBI_KOMOKU_07 not like", value, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07In(List<String> values) {
            addCriterion("YOBI_KOMOKU_07 in", values, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_07 not in", values, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_07 between", value1, value2, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_07 not between", value1, value2, "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08IsNull() {
            addCriterion("YOBI_KOMOKU_08 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08IsNotNull() {
            addCriterion("YOBI_KOMOKU_08 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_08 =", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_08 <>", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_08 >", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_08 >=", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08LessThan(String value) {
            addCriterion("YOBI_KOMOKU_08 <", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_08 <=", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08Like(String value) {
            addCriterion("YOBI_KOMOKU_08 like", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08NotLike(String value) {
            addCriterion("YOBI_KOMOKU_08 not like", value, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08In(List<String> values) {
            addCriterion("YOBI_KOMOKU_08 in", values, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_08 not in", values, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_08 between", value1, value2, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_08 not between", value1, value2, "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09IsNull() {
            addCriterion("YOBI_KOMOKU_09 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09IsNotNull() {
            addCriterion("YOBI_KOMOKU_09 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_09 =", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_09 <>", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_09 >", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_09 >=", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09LessThan(String value) {
            addCriterion("YOBI_KOMOKU_09 <", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_09 <=", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09Like(String value) {
            addCriterion("YOBI_KOMOKU_09 like", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09NotLike(String value) {
            addCriterion("YOBI_KOMOKU_09 not like", value, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09In(List<String> values) {
            addCriterion("YOBI_KOMOKU_09 in", values, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_09 not in", values, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_09 between", value1, value2, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_09 not between", value1, value2, "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10IsNull() {
            addCriterion("YOBI_KOMOKU_10 is null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10IsNotNull() {
            addCriterion("YOBI_KOMOKU_10 is not null");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10EqualTo(String value) {
            addCriterion("YOBI_KOMOKU_10 =", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10NotEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_10 <>", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10GreaterThan(String value) {
            addCriterion("YOBI_KOMOKU_10 >", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10GreaterThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_10 >=", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10LessThan(String value) {
            addCriterion("YOBI_KOMOKU_10 <", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10LessThanOrEqualTo(String value) {
            addCriterion("YOBI_KOMOKU_10 <=", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10Like(String value) {
            addCriterion("YOBI_KOMOKU_10 like", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10NotLike(String value) {
            addCriterion("YOBI_KOMOKU_10 not like", value, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10In(List<String> values) {
            addCriterion("YOBI_KOMOKU_10 in", values, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10NotIn(List<String> values) {
            addCriterion("YOBI_KOMOKU_10 not in", values, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10Between(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_10 between", value1, value2, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10NotBetween(String value1, String value2) {
            addCriterion("YOBI_KOMOKU_10 not between", value1, value2, "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPIsNull() {
            addCriterion("REGST_TMSTMP is null");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPIsNotNull() {
            addCriterion("REGST_TMSTMP is not null");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPEqualTo(Date value) {
            addCriterion("REGST_TMSTMP =", value, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPNotEqualTo(Date value) {
            addCriterion("REGST_TMSTMP <>", value, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPGreaterThan(Date value) {
            addCriterion("REGST_TMSTMP >", value, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPGreaterThanOrEqualTo(Date value) {
            addCriterion("REGST_TMSTMP >=", value, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPLessThan(Date value) {
            addCriterion("REGST_TMSTMP <", value, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPLessThanOrEqualTo(Date value) {
            addCriterion("REGST_TMSTMP <=", value, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPIn(List<Date> values) {
            addCriterion("REGST_TMSTMP in", values, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPNotIn(List<Date> values) {
            addCriterion("REGST_TMSTMP not in", values, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPBetween(Date value1, Date value2) {
            addCriterion("REGST_TMSTMP between", value1, value2, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGST_TMSTMPNotBetween(Date value1, Date value2) {
            addCriterion("REGST_TMSTMP not between", value1, value2, "REGST_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDIsNull() {
            addCriterion("REGSTR_CO_CD is null");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDIsNotNull() {
            addCriterion("REGSTR_CO_CD is not null");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDEqualTo(String value) {
            addCriterion("REGSTR_CO_CD =", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDNotEqualTo(String value) {
            addCriterion("REGSTR_CO_CD <>", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDGreaterThan(String value) {
            addCriterion("REGSTR_CO_CD >", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDGreaterThanOrEqualTo(String value) {
            addCriterion("REGSTR_CO_CD >=", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDLessThan(String value) {
            addCriterion("REGSTR_CO_CD <", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDLessThanOrEqualTo(String value) {
            addCriterion("REGSTR_CO_CD <=", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDLike(String value) {
            addCriterion("REGSTR_CO_CD like", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDNotLike(String value) {
            addCriterion("REGSTR_CO_CD not like", value, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDIn(List<String> values) {
            addCriterion("REGSTR_CO_CD in", values, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDNotIn(List<String> values) {
            addCriterion("REGSTR_CO_CD not in", values, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDBetween(String value1, String value2) {
            addCriterion("REGSTR_CO_CD between", value1, value2, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDNotBetween(String value1, String value2) {
            addCriterion("REGSTR_CO_CD not between", value1, value2, "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDIsNull() {
            addCriterion("REGSTR_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDIsNotNull() {
            addCriterion("REGSTR_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDEqualTo(String value) {
            addCriterion("REGSTR_SOSHIKI_CD =", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("REGSTR_SOSHIKI_CD <>", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("REGSTR_SOSHIKI_CD >", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("REGSTR_SOSHIKI_CD >=", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDLessThan(String value) {
            addCriterion("REGSTR_SOSHIKI_CD <", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("REGSTR_SOSHIKI_CD <=", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDLike(String value) {
            addCriterion("REGSTR_SOSHIKI_CD like", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDNotLike(String value) {
            addCriterion("REGSTR_SOSHIKI_CD not like", value, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDIn(List<String> values) {
            addCriterion("REGSTR_SOSHIKI_CD in", values, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("REGSTR_SOSHIKI_CD not in", values, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("REGSTR_SOSHIKI_CD between", value1, value2, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("REGSTR_SOSHIKI_CD not between", value1, value2, "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOIsNull() {
            addCriterion("REGSTR_EMP_NO is null");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOIsNotNull() {
            addCriterion("REGSTR_EMP_NO is not null");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOEqualTo(String value) {
            addCriterion("REGSTR_EMP_NO =", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NONotEqualTo(String value) {
            addCriterion("REGSTR_EMP_NO <>", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOGreaterThan(String value) {
            addCriterion("REGSTR_EMP_NO >", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOGreaterThanOrEqualTo(String value) {
            addCriterion("REGSTR_EMP_NO >=", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOLessThan(String value) {
            addCriterion("REGSTR_EMP_NO <", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOLessThanOrEqualTo(String value) {
            addCriterion("REGSTR_EMP_NO <=", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOLike(String value) {
            addCriterion("REGSTR_EMP_NO like", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NONotLike(String value) {
            addCriterion("REGSTR_EMP_NO not like", value, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOIn(List<String> values) {
            addCriterion("REGSTR_EMP_NO in", values, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NONotIn(List<String> values) {
            addCriterion("REGSTR_EMP_NO not in", values, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOBetween(String value1, String value2) {
            addCriterion("REGSTR_EMP_NO between", value1, value2, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NONotBetween(String value1, String value2) {
            addCriterion("REGSTR_EMP_NO not between", value1, value2, "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDIsNull() {
            addCriterion("REGST_GAMEN_ID is null");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDIsNotNull() {
            addCriterion("REGST_GAMEN_ID is not null");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDEqualTo(String value) {
            addCriterion("REGST_GAMEN_ID =", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDNotEqualTo(String value) {
            addCriterion("REGST_GAMEN_ID <>", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDGreaterThan(String value) {
            addCriterion("REGST_GAMEN_ID >", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDGreaterThanOrEqualTo(String value) {
            addCriterion("REGST_GAMEN_ID >=", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDLessThan(String value) {
            addCriterion("REGST_GAMEN_ID <", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDLessThanOrEqualTo(String value) {
            addCriterion("REGST_GAMEN_ID <=", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDLike(String value) {
            addCriterion("REGST_GAMEN_ID like", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDNotLike(String value) {
            addCriterion("REGST_GAMEN_ID not like", value, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDIn(List<String> values) {
            addCriterion("REGST_GAMEN_ID in", values, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDNotIn(List<String> values) {
            addCriterion("REGST_GAMEN_ID not in", values, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDBetween(String value1, String value2) {
            addCriterion("REGST_GAMEN_ID between", value1, value2, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDNotBetween(String value1, String value2) {
            addCriterion("REGST_GAMEN_ID not between", value1, value2, "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDIsNull() {
            addCriterion("REGST_PGM_ID is null");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDIsNotNull() {
            addCriterion("REGST_PGM_ID is not null");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDEqualTo(String value) {
            addCriterion("REGST_PGM_ID =", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDNotEqualTo(String value) {
            addCriterion("REGST_PGM_ID <>", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDGreaterThan(String value) {
            addCriterion("REGST_PGM_ID >", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDGreaterThanOrEqualTo(String value) {
            addCriterion("REGST_PGM_ID >=", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDLessThan(String value) {
            addCriterion("REGST_PGM_ID <", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDLessThanOrEqualTo(String value) {
            addCriterion("REGST_PGM_ID <=", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDLike(String value) {
            addCriterion("REGST_PGM_ID like", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDNotLike(String value) {
            addCriterion("REGST_PGM_ID not like", value, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDIn(List<String> values) {
            addCriterion("REGST_PGM_ID in", values, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDNotIn(List<String> values) {
            addCriterion("REGST_PGM_ID not in", values, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDBetween(String value1, String value2) {
            addCriterion("REGST_PGM_ID between", value1, value2, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDNotBetween(String value1, String value2) {
            addCriterion("REGST_PGM_ID not between", value1, value2, "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPIsNull() {
            addCriterion("UPD_TMSTMP is null");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPIsNotNull() {
            addCriterion("UPD_TMSTMP is not null");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPEqualTo(Date value) {
            addCriterion("UPD_TMSTMP =", value, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPNotEqualTo(Date value) {
            addCriterion("UPD_TMSTMP <>", value, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPGreaterThan(Date value) {
            addCriterion("UPD_TMSTMP >", value, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPGreaterThanOrEqualTo(Date value) {
            addCriterion("UPD_TMSTMP >=", value, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPLessThan(Date value) {
            addCriterion("UPD_TMSTMP <", value, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPLessThanOrEqualTo(Date value) {
            addCriterion("UPD_TMSTMP <=", value, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPIn(List<Date> values) {
            addCriterion("UPD_TMSTMP in", values, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPNotIn(List<Date> values) {
            addCriterion("UPD_TMSTMP not in", values, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPBetween(Date value1, Date value2) {
            addCriterion("UPD_TMSTMP between", value1, value2, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPD_TMSTMPNotBetween(Date value1, Date value2) {
            addCriterion("UPD_TMSTMP not between", value1, value2, "UPD_TMSTMP");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDIsNull() {
            addCriterion("UPDTR_CO_CD is null");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDIsNotNull() {
            addCriterion("UPDTR_CO_CD is not null");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDEqualTo(String value) {
            addCriterion("UPDTR_CO_CD =", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDNotEqualTo(String value) {
            addCriterion("UPDTR_CO_CD <>", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDGreaterThan(String value) {
            addCriterion("UPDTR_CO_CD >", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDTR_CO_CD >=", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDLessThan(String value) {
            addCriterion("UPDTR_CO_CD <", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDLessThanOrEqualTo(String value) {
            addCriterion("UPDTR_CO_CD <=", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDLike(String value) {
            addCriterion("UPDTR_CO_CD like", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDNotLike(String value) {
            addCriterion("UPDTR_CO_CD not like", value, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDIn(List<String> values) {
            addCriterion("UPDTR_CO_CD in", values, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDNotIn(List<String> values) {
            addCriterion("UPDTR_CO_CD not in", values, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDBetween(String value1, String value2) {
            addCriterion("UPDTR_CO_CD between", value1, value2, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDNotBetween(String value1, String value2) {
            addCriterion("UPDTR_CO_CD not between", value1, value2, "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDIsNull() {
            addCriterion("UPDTR_SOSHIKI_CD is null");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDIsNotNull() {
            addCriterion("UPDTR_SOSHIKI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDEqualTo(String value) {
            addCriterion("UPDTR_SOSHIKI_CD =", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDNotEqualTo(String value) {
            addCriterion("UPDTR_SOSHIKI_CD <>", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDGreaterThan(String value) {
            addCriterion("UPDTR_SOSHIKI_CD >", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDTR_SOSHIKI_CD >=", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDLessThan(String value) {
            addCriterion("UPDTR_SOSHIKI_CD <", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDLessThanOrEqualTo(String value) {
            addCriterion("UPDTR_SOSHIKI_CD <=", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDLike(String value) {
            addCriterion("UPDTR_SOSHIKI_CD like", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDNotLike(String value) {
            addCriterion("UPDTR_SOSHIKI_CD not like", value, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDIn(List<String> values) {
            addCriterion("UPDTR_SOSHIKI_CD in", values, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDNotIn(List<String> values) {
            addCriterion("UPDTR_SOSHIKI_CD not in", values, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDBetween(String value1, String value2) {
            addCriterion("UPDTR_SOSHIKI_CD between", value1, value2, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDNotBetween(String value1, String value2) {
            addCriterion("UPDTR_SOSHIKI_CD not between", value1, value2, "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOIsNull() {
            addCriterion("UPDTR_EMP_NO is null");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOIsNotNull() {
            addCriterion("UPDTR_EMP_NO is not null");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOEqualTo(String value) {
            addCriterion("UPDTR_EMP_NO =", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NONotEqualTo(String value) {
            addCriterion("UPDTR_EMP_NO <>", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOGreaterThan(String value) {
            addCriterion("UPDTR_EMP_NO >", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOGreaterThanOrEqualTo(String value) {
            addCriterion("UPDTR_EMP_NO >=", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOLessThan(String value) {
            addCriterion("UPDTR_EMP_NO <", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOLessThanOrEqualTo(String value) {
            addCriterion("UPDTR_EMP_NO <=", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOLike(String value) {
            addCriterion("UPDTR_EMP_NO like", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NONotLike(String value) {
            addCriterion("UPDTR_EMP_NO not like", value, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOIn(List<String> values) {
            addCriterion("UPDTR_EMP_NO in", values, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NONotIn(List<String> values) {
            addCriterion("UPDTR_EMP_NO not in", values, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOBetween(String value1, String value2) {
            addCriterion("UPDTR_EMP_NO between", value1, value2, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NONotBetween(String value1, String value2) {
            addCriterion("UPDTR_EMP_NO not between", value1, value2, "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDIsNull() {
            addCriterion("UPD_GAMEN_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDIsNotNull() {
            addCriterion("UPD_GAMEN_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDEqualTo(String value) {
            addCriterion("UPD_GAMEN_ID =", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDNotEqualTo(String value) {
            addCriterion("UPD_GAMEN_ID <>", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDGreaterThan(String value) {
            addCriterion("UPD_GAMEN_ID >", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPD_GAMEN_ID >=", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDLessThan(String value) {
            addCriterion("UPD_GAMEN_ID <", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDLessThanOrEqualTo(String value) {
            addCriterion("UPD_GAMEN_ID <=", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDLike(String value) {
            addCriterion("UPD_GAMEN_ID like", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDNotLike(String value) {
            addCriterion("UPD_GAMEN_ID not like", value, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDIn(List<String> values) {
            addCriterion("UPD_GAMEN_ID in", values, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDNotIn(List<String> values) {
            addCriterion("UPD_GAMEN_ID not in", values, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDBetween(String value1, String value2) {
            addCriterion("UPD_GAMEN_ID between", value1, value2, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDNotBetween(String value1, String value2) {
            addCriterion("UPD_GAMEN_ID not between", value1, value2, "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDIsNull() {
            addCriterion("UPD_PGM_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDIsNotNull() {
            addCriterion("UPD_PGM_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDEqualTo(String value) {
            addCriterion("UPD_PGM_ID =", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDNotEqualTo(String value) {
            addCriterion("UPD_PGM_ID <>", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDGreaterThan(String value) {
            addCriterion("UPD_PGM_ID >", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPD_PGM_ID >=", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDLessThan(String value) {
            addCriterion("UPD_PGM_ID <", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDLessThanOrEqualTo(String value) {
            addCriterion("UPD_PGM_ID <=", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDLike(String value) {
            addCriterion("UPD_PGM_ID like", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDNotLike(String value) {
            addCriterion("UPD_PGM_ID not like", value, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDIn(List<String> values) {
            addCriterion("UPD_PGM_ID in", values, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDNotIn(List<String> values) {
            addCriterion("UPD_PGM_ID not in", values, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDBetween(String value1, String value2) {
            addCriterion("UPD_PGM_ID between", value1, value2, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDNotBetween(String value1, String value2) {
            addCriterion("UPD_PGM_ID not between", value1, value2, "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andKAISHA_CDLikeInsensitive(String value) {
            addCriterion("upper(KAISHA_CD) like", value.toUpperCase(), "KAISHA_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_CDLikeInsensitive(String value) {
            addCriterion("upper(JIGYOSHO_CD) like", value.toUpperCase(), "JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_KAISHI_YMDLikeInsensitive(String value) {
            addCriterion("upper(TEKIYO_KAISHI_YMD) like", value.toUpperCase(), "TEKIYO_KAISHI_YMD");
            return (Criteria) this;
        }

        public Criteria andTEKIYO_SHURYO_YMDLikeInsensitive(String value) {
            addCriterion("upper(TEKIYO_SHURYO_YMD) like", value.toUpperCase(), "TEKIYO_SHURYO_YMD");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KBNLikeInsensitive(String value) {
            addCriterion("upper(JIGYOSHO_KBN) like", value.toUpperCase(), "JIGYOSHO_KBN");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_NMLikeInsensitive(String value) {
            addCriterion("upper(JIGYOSHO_NM) like", value.toUpperCase(), "JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_KN_NMLikeInsensitive(String value) {
            addCriterion("upper(JIGYOSHO_KN_NM) like", value.toUpperCase(), "JIGYOSHO_KN_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYOSHO_RNMLikeInsensitive(String value) {
            addCriterion("upper(JIGYOSHO_RNM) like", value.toUpperCase(), "JIGYOSHO_RNM");
            return (Criteria) this;
        }

        public Criteria andJUSHO_CDLikeInsensitive(String value) {
            addCriterion("upper(JUSHO_CD) like", value.toUpperCase(), "JUSHO_CD");
            return (Criteria) this;
        }

        public Criteria andTODOFUKEN_NMLikeInsensitive(String value) {
            addCriterion("upper(TODOFUKEN_NM) like", value.toUpperCase(), "TODOFUKEN_NM");
            return (Criteria) this;
        }

        public Criteria andSHIKUCHOSON_NMLikeInsensitive(String value) {
            addCriterion("upper(SHIKUCHOSON_NM) like", value.toUpperCase(), "SHIKUCHOSON_NM");
            return (Criteria) this;
        }

        public Criteria andOAZA_NMLikeInsensitive(String value) {
            addCriterion("upper(OAZA_NM) like", value.toUpperCase(), "OAZA_NM");
            return (Criteria) this;
        }

        public Criteria andCHOME_NMLikeInsensitive(String value) {
            addCriterion("upper(CHOME_NM) like", value.toUpperCase(), "CHOME_NM");
            return (Criteria) this;
        }

        public Criteria andHOSOKU_JUSHO_1LikeInsensitive(String value) {
            addCriterion("upper(HOSOKU_JUSHO_1) like", value.toUpperCase(), "HOSOKU_JUSHO_1");
            return (Criteria) this;
        }

        public Criteria andYUBIN_NOLikeInsensitive(String value) {
            addCriterion("upper(YUBIN_NO) like", value.toUpperCase(), "YUBIN_NO");
            return (Criteria) this;
        }

        public Criteria andJUSHO_BANCHILikeInsensitive(String value) {
            addCriterion("upper(JUSHO_BANCHI) like", value.toUpperCase(), "JUSHO_BANCHI");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_NMLikeInsensitive(String value) {
            addCriterion("upper(TATEMONO_NM) like", value.toUpperCase(), "TATEMONO_NM");
            return (Criteria) this;
        }

        public Criteria andTATEMONO_KN_NMLikeInsensitive(String value) {
            addCriterion("upper(TATEMONO_KN_NM) like", value.toUpperCase(), "TATEMONO_KN_NM");
            return (Criteria) this;
        }

        public Criteria andTO_NMLikeInsensitive(String value) {
            addCriterion("upper(TO_NM) like", value.toUpperCase(), "TO_NM");
            return (Criteria) this;
        }

        public Criteria andKAI_NMLikeInsensitive(String value) {
            addCriterion("upper(KAI_NM) like", value.toUpperCase(), "KAI_NM");
            return (Criteria) this;
        }

        public Criteria andKUKAKU_NMLikeInsensitive(String value) {
            addCriterion("upper(KUKAKU_NM) like", value.toUpperCase(), "KUKAKU_NM");
            return (Criteria) this;
        }

        public Criteria andHEYA_NMLikeInsensitive(String value) {
            addCriterion("upper(HEYA_NM) like", value.toUpperCase(), "HEYA_NM");
            return (Criteria) this;
        }

        public Criteria andDENWA_NOLikeInsensitive(String value) {
            addCriterion("upper(DENWA_NO) like", value.toUpperCase(), "DENWA_NO");
            return (Criteria) this;
        }

        public Criteria andDAIHYO_MAIL_ADDRESSLikeInsensitive(String value) {
            addCriterion("upper(DAIHYO_MAIL_ADDRESS) like", value.toUpperCase(), "DAIHYO_MAIL_ADDRESS");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_CDLikeInsensitive(String value) {
            addCriterion("upper(SHIHARAI_JIGYOSHO_CD) like", value.toUpperCase(), "SHIHARAI_JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andSHIHARAI_JIGYOSHO_NMLikeInsensitive(String value) {
            addCriterion("upper(SHIHARAI_JIGYOSHO_NM) like", value.toUpperCase(), "SHIHARAI_JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_CDLikeInsensitive(String value) {
            addCriterion("upper(NYUKIN_JIGYOSHO_CD) like", value.toUpperCase(), "NYUKIN_JIGYOSHO_CD");
            return (Criteria) this;
        }

        public Criteria andNYUKIN_JIGYOSHO_NMLikeInsensitive(String value) {
            addCriterion("upper(NYUKIN_JIGYOSHO_NM) like", value.toUpperCase(), "NYUKIN_JIGYOSHO_NM");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_CDLikeInsensitive(String value) {
            addCriterion("upper(JISHA_KOZA_CD) like", value.toUpperCase(), "JISHA_KOZA_CD");
            return (Criteria) this;
        }

        public Criteria andJISHA_KOZA_NMLikeInsensitive(String value) {
            addCriterion("upper(JISHA_KOZA_NM) like", value.toUpperCase(), "JISHA_KOZA_NM");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_01LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_01) like", value.toUpperCase(), "YOBI_KOMOKU_01");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_02LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_02) like", value.toUpperCase(), "YOBI_KOMOKU_02");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_03LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_03) like", value.toUpperCase(), "YOBI_KOMOKU_03");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_04LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_04) like", value.toUpperCase(), "YOBI_KOMOKU_04");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_05LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_05) like", value.toUpperCase(), "YOBI_KOMOKU_05");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_06LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_06) like", value.toUpperCase(), "YOBI_KOMOKU_06");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_07LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_07) like", value.toUpperCase(), "YOBI_KOMOKU_07");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_08LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_08) like", value.toUpperCase(), "YOBI_KOMOKU_08");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_09LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_09) like", value.toUpperCase(), "YOBI_KOMOKU_09");
            return (Criteria) this;
        }

        public Criteria andYOBI_KOMOKU_10LikeInsensitive(String value) {
            addCriterion("upper(YOBI_KOMOKU_10) like", value.toUpperCase(), "YOBI_KOMOKU_10");
            return (Criteria) this;
        }

        public Criteria andREGSTR_CO_CDLikeInsensitive(String value) {
            addCriterion("upper(REGSTR_CO_CD) like", value.toUpperCase(), "REGSTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(REGSTR_SOSHIKI_CD) like", value.toUpperCase(), "REGSTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andREGSTR_EMP_NOLikeInsensitive(String value) {
            addCriterion("upper(REGSTR_EMP_NO) like", value.toUpperCase(), "REGSTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andREGST_GAMEN_IDLikeInsensitive(String value) {
            addCriterion("upper(REGST_GAMEN_ID) like", value.toUpperCase(), "REGST_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andREGST_PGM_IDLikeInsensitive(String value) {
            addCriterion("upper(REGST_PGM_ID) like", value.toUpperCase(), "REGST_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andUPDTR_CO_CDLikeInsensitive(String value) {
            addCriterion("upper(UPDTR_CO_CD) like", value.toUpperCase(), "UPDTR_CO_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_SOSHIKI_CDLikeInsensitive(String value) {
            addCriterion("upper(UPDTR_SOSHIKI_CD) like", value.toUpperCase(), "UPDTR_SOSHIKI_CD");
            return (Criteria) this;
        }

        public Criteria andUPDTR_EMP_NOLikeInsensitive(String value) {
            addCriterion("upper(UPDTR_EMP_NO) like", value.toUpperCase(), "UPDTR_EMP_NO");
            return (Criteria) this;
        }

        public Criteria andUPD_GAMEN_IDLikeInsensitive(String value) {
            addCriterion("upper(UPD_GAMEN_ID) like", value.toUpperCase(), "UPD_GAMEN_ID");
            return (Criteria) this;
        }

        public Criteria andUPD_PGM_IDLikeInsensitive(String value) {
            addCriterion("upper(UPD_PGM_ID) like", value.toUpperCase(), "UPD_PGM_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * C_EIGYO_JIGYOSHO
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * C_EIGYO_JIGYOSHO null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}