package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EV6RakufExample {
    /**
     * E_V6_RAKUF
     */
    protected String orderByClause;

    /**
     * E_V6_RAKUF
     */
    protected boolean distinct;

    /**
     * E_V6_RAKUF
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public EV6RakufExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * E_V6_RAKUF null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andGC_NUMIsNull() {
            addCriterion("GC_NUM is null");
            return (Criteria) this;
        }

        public Criteria andGC_NUMIsNotNull() {
            addCriterion("GC_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andGC_NUMEqualTo(String value) {
            addCriterion("GC_NUM =", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMNotEqualTo(String value) {
            addCriterion("GC_NUM <>", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMGreaterThan(String value) {
            addCriterion("GC_NUM >", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("GC_NUM >=", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMLessThan(String value) {
            addCriterion("GC_NUM <", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMLessThanOrEqualTo(String value) {
            addCriterion("GC_NUM <=", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMLike(String value) {
            addCriterion("GC_NUM like", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMNotLike(String value) {
            addCriterion("GC_NUM not like", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMIn(List<String> values) {
            addCriterion("GC_NUM in", values, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMNotIn(List<String> values) {
            addCriterion("GC_NUM not in", values, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMBetween(String value1, String value2) {
            addCriterion("GC_NUM between", value1, value2, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMNotBetween(String value1, String value2) {
            addCriterion("GC_NUM not between", value1, value2, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_SGSIsNull() {
            addCriterion("LN_SGS is null");
            return (Criteria) this;
        }

        public Criteria andLN_SGSIsNotNull() {
            addCriterion("LN_SGS is not null");
            return (Criteria) this;
        }

        public Criteria andLN_SGSEqualTo(String value) {
            addCriterion("LN_SGS =", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSNotEqualTo(String value) {
            addCriterion("LN_SGS <>", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSGreaterThan(String value) {
            addCriterion("LN_SGS >", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSGreaterThanOrEqualTo(String value) {
            addCriterion("LN_SGS >=", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSLessThan(String value) {
            addCriterion("LN_SGS <", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSLessThanOrEqualTo(String value) {
            addCriterion("LN_SGS <=", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSLike(String value) {
            addCriterion("LN_SGS like", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSNotLike(String value) {
            addCriterion("LN_SGS not like", value, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSIn(List<String> values) {
            addCriterion("LN_SGS in", values, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSNotIn(List<String> values) {
            addCriterion("LN_SGS not in", values, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSBetween(String value1, String value2) {
            addCriterion("LN_SGS between", value1, value2, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andLN_SGSNotBetween(String value1, String value2) {
            addCriterion("LN_SGS not between", value1, value2, "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSIsNull() {
            addCriterion("HASSEI_TS is null");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSIsNotNull() {
            addCriterion("HASSEI_TS is not null");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSEqualTo(String value) {
            addCriterion("HASSEI_TS =", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSNotEqualTo(String value) {
            addCriterion("HASSEI_TS <>", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSGreaterThan(String value) {
            addCriterion("HASSEI_TS >", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSGreaterThanOrEqualTo(String value) {
            addCriterion("HASSEI_TS >=", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSLessThan(String value) {
            addCriterion("HASSEI_TS <", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSLessThanOrEqualTo(String value) {
            addCriterion("HASSEI_TS <=", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSLike(String value) {
            addCriterion("HASSEI_TS like", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSNotLike(String value) {
            addCriterion("HASSEI_TS not like", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSIn(List<String> values) {
            addCriterion("HASSEI_TS in", values, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSNotIn(List<String> values) {
            addCriterion("HASSEI_TS not in", values, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSBetween(String value1, String value2) {
            addCriterion("HASSEI_TS between", value1, value2, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSNotBetween(String value1, String value2) {
            addCriterion("HASSEI_TS not between", value1, value2, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andADDR_CDIsNull() {
            addCriterion("ADDR_CD is null");
            return (Criteria) this;
        }

        public Criteria andADDR_CDIsNotNull() {
            addCriterion("ADDR_CD is not null");
            return (Criteria) this;
        }

        public Criteria andADDR_CDEqualTo(String value) {
            addCriterion("ADDR_CD =", value, "ADDR_CD");
            return (Criteria) this;
        }

        public Criteria andADDR_CDNotEqualTo(String value) {
            addCriterion("ADDR_CD <>", value, "ADDR_CD");
            return (Criteria) this;
        }

        public Criteria andADDR_CDGreaterThan(String value) {
            addCriterion("ADDR_CD >", value, "ADDR_CD");
            return (Criteria) this;
        }

        public Criteria andADDR_CDGreaterThanOrEqualTo(String value) {
            addCriterion("ADDR_CD >=", value, "ADDR_CD");
            return (Criteria) this;
        }

        public Criteria andADDR_CDLessThan(String value) {
            addCriterion("ADDR_CD <", value, "ADDR_CD");
            return (Criteria) this;
        }

        public Criteria andADDR_CDLessThanOrEqualTo(String value) {
            addCriterion("ADDR_CD <=", value, "ADDR_CD");
            return (Criteria) this;
        }

        public Criteria andADDR_CDLike(String value) {
            addCriterion("ADDR_CD like", value, "ADDR_CD");
            return (Criteria) this;
        }

        public Criteria andADDR_CDNotLike(String value) {
            addCriterion("ADDR_CD not like", value, "ADDR_CD");
            return (Criteria) this;
        }

        public Criteria andADDR_CDIn(List<String> values) {
            addCriterion("ADDR_CD in", values, "ADDR_CD");
            return (Criteria) this;
        }

        public Criteria andADDR_CDNotIn(List<String> values) {
            addCriterion("ADDR_CD not in", values, "ADDR_CD");
            return (Criteria) this;
        }

        public Criteria andADDR_CDBetween(String value1, String value2) {
            addCriterion("ADDR_CD between", value1, value2, "ADDR_CD");
            return (Criteria) this;
        }

        public Criteria andADDR_CDNotBetween(String value1, String value2) {
            addCriterion("ADDR_CD not between", value1, value2, "ADDR_CD");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNIsNull() {
            addCriterion("SYUTUDOU_KBN is null");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNIsNotNull() {
            addCriterion("SYUTUDOU_KBN is not null");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNEqualTo(String value) {
            addCriterion("SYUTUDOU_KBN =", value, "SYUTUDOU_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNNotEqualTo(String value) {
            addCriterion("SYUTUDOU_KBN <>", value, "SYUTUDOU_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNGreaterThan(String value) {
            addCriterion("SYUTUDOU_KBN >", value, "SYUTUDOU_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNGreaterThanOrEqualTo(String value) {
            addCriterion("SYUTUDOU_KBN >=", value, "SYUTUDOU_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNLessThan(String value) {
            addCriterion("SYUTUDOU_KBN <", value, "SYUTUDOU_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNLessThanOrEqualTo(String value) {
            addCriterion("SYUTUDOU_KBN <=", value, "SYUTUDOU_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNLike(String value) {
            addCriterion("SYUTUDOU_KBN like", value, "SYUTUDOU_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNNotLike(String value) {
            addCriterion("SYUTUDOU_KBN not like", value, "SYUTUDOU_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNIn(List<String> values) {
            addCriterion("SYUTUDOU_KBN in", values, "SYUTUDOU_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNNotIn(List<String> values) {
            addCriterion("SYUTUDOU_KBN not in", values, "SYUTUDOU_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNBetween(String value1, String value2) {
            addCriterion("SYUTUDOU_KBN between", value1, value2, "SYUTUDOU_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNNotBetween(String value1, String value2) {
            addCriterion("SYUTUDOU_KBN not between", value1, value2, "SYUTUDOU_KBN");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKIsNull() {
            addCriterion("OUEN_MARK is null");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKIsNotNull() {
            addCriterion("OUEN_MARK is not null");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKEqualTo(String value) {
            addCriterion("OUEN_MARK =", value, "OUEN_MARK");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKNotEqualTo(String value) {
            addCriterion("OUEN_MARK <>", value, "OUEN_MARK");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKGreaterThan(String value) {
            addCriterion("OUEN_MARK >", value, "OUEN_MARK");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKGreaterThanOrEqualTo(String value) {
            addCriterion("OUEN_MARK >=", value, "OUEN_MARK");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKLessThan(String value) {
            addCriterion("OUEN_MARK <", value, "OUEN_MARK");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKLessThanOrEqualTo(String value) {
            addCriterion("OUEN_MARK <=", value, "OUEN_MARK");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKLike(String value) {
            addCriterion("OUEN_MARK like", value, "OUEN_MARK");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKNotLike(String value) {
            addCriterion("OUEN_MARK not like", value, "OUEN_MARK");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKIn(List<String> values) {
            addCriterion("OUEN_MARK in", values, "OUEN_MARK");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKNotIn(List<String> values) {
            addCriterion("OUEN_MARK not in", values, "OUEN_MARK");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKBetween(String value1, String value2) {
            addCriterion("OUEN_MARK between", value1, value2, "OUEN_MARK");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKNotBetween(String value1, String value2) {
            addCriterion("OUEN_MARK not between", value1, value2, "OUEN_MARK");
            return (Criteria) this;
        }

        public Criteria andRAKU_SEKIIsNull() {
            addCriterion("RAKU_SEKI is null");
            return (Criteria) this;
        }

        public Criteria andRAKU_SEKIIsNotNull() {
            addCriterion("RAKU_SEKI is not null");
            return (Criteria) this;
        }

        public Criteria andRAKU_SEKIEqualTo(String value) {
            addCriterion("RAKU_SEKI =", value, "RAKU_SEKI");
            return (Criteria) this;
        }

        public Criteria andRAKU_SEKINotEqualTo(String value) {
            addCriterion("RAKU_SEKI <>", value, "RAKU_SEKI");
            return (Criteria) this;
        }

        public Criteria andRAKU_SEKIGreaterThan(String value) {
            addCriterion("RAKU_SEKI >", value, "RAKU_SEKI");
            return (Criteria) this;
        }

        public Criteria andRAKU_SEKIGreaterThanOrEqualTo(String value) {
            addCriterion("RAKU_SEKI >=", value, "RAKU_SEKI");
            return (Criteria) this;
        }

        public Criteria andRAKU_SEKILessThan(String value) {
            addCriterion("RAKU_SEKI <", value, "RAKU_SEKI");
            return (Criteria) this;
        }

        public Criteria andRAKU_SEKILessThanOrEqualTo(String value) {
            addCriterion("RAKU_SEKI <=", value, "RAKU_SEKI");
            return (Criteria) this;
        }

        public Criteria andRAKU_SEKILike(String value) {
            addCriterion("RAKU_SEKI like", value, "RAKU_SEKI");
            return (Criteria) this;
        }

        public Criteria andRAKU_SEKINotLike(String value) {
            addCriterion("RAKU_SEKI not like", value, "RAKU_SEKI");
            return (Criteria) this;
        }

        public Criteria andRAKU_SEKIIn(List<String> values) {
            addCriterion("RAKU_SEKI in", values, "RAKU_SEKI");
            return (Criteria) this;
        }

        public Criteria andRAKU_SEKINotIn(List<String> values) {
            addCriterion("RAKU_SEKI not in", values, "RAKU_SEKI");
            return (Criteria) this;
        }

        public Criteria andRAKU_SEKIBetween(String value1, String value2) {
            addCriterion("RAKU_SEKI between", value1, value2, "RAKU_SEKI");
            return (Criteria) this;
        }

        public Criteria andRAKU_SEKINotBetween(String value1, String value2) {
            addCriterion("RAKU_SEKI not between", value1, value2, "RAKU_SEKI");
            return (Criteria) this;
        }

        public Criteria andRAKU_OPERATOR_NUMIsNull() {
            addCriterion("RAKU_OPERATOR_NUM is null");
            return (Criteria) this;
        }

        public Criteria andRAKU_OPERATOR_NUMIsNotNull() {
            addCriterion("RAKU_OPERATOR_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andRAKU_OPERATOR_NUMEqualTo(String value) {
            addCriterion("RAKU_OPERATOR_NUM =", value, "RAKU_OPERATOR_NUM");
            return (Criteria) this;
        }

        public Criteria andRAKU_OPERATOR_NUMNotEqualTo(String value) {
            addCriterion("RAKU_OPERATOR_NUM <>", value, "RAKU_OPERATOR_NUM");
            return (Criteria) this;
        }

        public Criteria andRAKU_OPERATOR_NUMGreaterThan(String value) {
            addCriterion("RAKU_OPERATOR_NUM >", value, "RAKU_OPERATOR_NUM");
            return (Criteria) this;
        }

        public Criteria andRAKU_OPERATOR_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("RAKU_OPERATOR_NUM >=", value, "RAKU_OPERATOR_NUM");
            return (Criteria) this;
        }

        public Criteria andRAKU_OPERATOR_NUMLessThan(String value) {
            addCriterion("RAKU_OPERATOR_NUM <", value, "RAKU_OPERATOR_NUM");
            return (Criteria) this;
        }

        public Criteria andRAKU_OPERATOR_NUMLessThanOrEqualTo(String value) {
            addCriterion("RAKU_OPERATOR_NUM <=", value, "RAKU_OPERATOR_NUM");
            return (Criteria) this;
        }

        public Criteria andRAKU_OPERATOR_NUMLike(String value) {
            addCriterion("RAKU_OPERATOR_NUM like", value, "RAKU_OPERATOR_NUM");
            return (Criteria) this;
        }

        public Criteria andRAKU_OPERATOR_NUMNotLike(String value) {
            addCriterion("RAKU_OPERATOR_NUM not like", value, "RAKU_OPERATOR_NUM");
            return (Criteria) this;
        }

        public Criteria andRAKU_OPERATOR_NUMIn(List<String> values) {
            addCriterion("RAKU_OPERATOR_NUM in", values, "RAKU_OPERATOR_NUM");
            return (Criteria) this;
        }

        public Criteria andRAKU_OPERATOR_NUMNotIn(List<String> values) {
            addCriterion("RAKU_OPERATOR_NUM not in", values, "RAKU_OPERATOR_NUM");
            return (Criteria) this;
        }

        public Criteria andRAKU_OPERATOR_NUMBetween(String value1, String value2) {
            addCriterion("RAKU_OPERATOR_NUM between", value1, value2, "RAKU_OPERATOR_NUM");
            return (Criteria) this;
        }

        public Criteria andRAKU_OPERATOR_NUMNotBetween(String value1, String value2) {
            addCriterion("RAKU_OPERATOR_NUM not between", value1, value2, "RAKU_OPERATOR_NUM");
            return (Criteria) this;
        }

        public Criteria andRAKU_NMIsNull() {
            addCriterion("RAKU_NM is null");
            return (Criteria) this;
        }

        public Criteria andRAKU_NMIsNotNull() {
            addCriterion("RAKU_NM is not null");
            return (Criteria) this;
        }

        public Criteria andRAKU_NMEqualTo(String value) {
            addCriterion("RAKU_NM =", value, "RAKU_NM");
            return (Criteria) this;
        }

        public Criteria andRAKU_NMNotEqualTo(String value) {
            addCriterion("RAKU_NM <>", value, "RAKU_NM");
            return (Criteria) this;
        }

        public Criteria andRAKU_NMGreaterThan(String value) {
            addCriterion("RAKU_NM >", value, "RAKU_NM");
            return (Criteria) this;
        }

        public Criteria andRAKU_NMGreaterThanOrEqualTo(String value) {
            addCriterion("RAKU_NM >=", value, "RAKU_NM");
            return (Criteria) this;
        }

        public Criteria andRAKU_NMLessThan(String value) {
            addCriterion("RAKU_NM <", value, "RAKU_NM");
            return (Criteria) this;
        }

        public Criteria andRAKU_NMLessThanOrEqualTo(String value) {
            addCriterion("RAKU_NM <=", value, "RAKU_NM");
            return (Criteria) this;
        }

        public Criteria andRAKU_NMLike(String value) {
            addCriterion("RAKU_NM like", value, "RAKU_NM");
            return (Criteria) this;
        }

        public Criteria andRAKU_NMNotLike(String value) {
            addCriterion("RAKU_NM not like", value, "RAKU_NM");
            return (Criteria) this;
        }

        public Criteria andRAKU_NMIn(List<String> values) {
            addCriterion("RAKU_NM in", values, "RAKU_NM");
            return (Criteria) this;
        }

        public Criteria andRAKU_NMNotIn(List<String> values) {
            addCriterion("RAKU_NM not in", values, "RAKU_NM");
            return (Criteria) this;
        }

        public Criteria andRAKU_NMBetween(String value1, String value2) {
            addCriterion("RAKU_NM between", value1, value2, "RAKU_NM");
            return (Criteria) this;
        }

        public Criteria andRAKU_NMNotBetween(String value1, String value2) {
            addCriterion("RAKU_NM not between", value1, value2, "RAKU_NM");
            return (Criteria) this;
        }

        public Criteria andRAKU_TSIsNull() {
            addCriterion("RAKU_TS is null");
            return (Criteria) this;
        }

        public Criteria andRAKU_TSIsNotNull() {
            addCriterion("RAKU_TS is not null");
            return (Criteria) this;
        }

        public Criteria andRAKU_TSEqualTo(String value) {
            addCriterion("RAKU_TS =", value, "RAKU_TS");
            return (Criteria) this;
        }

        public Criteria andRAKU_TSNotEqualTo(String value) {
            addCriterion("RAKU_TS <>", value, "RAKU_TS");
            return (Criteria) this;
        }

        public Criteria andRAKU_TSGreaterThan(String value) {
            addCriterion("RAKU_TS >", value, "RAKU_TS");
            return (Criteria) this;
        }

        public Criteria andRAKU_TSGreaterThanOrEqualTo(String value) {
            addCriterion("RAKU_TS >=", value, "RAKU_TS");
            return (Criteria) this;
        }

        public Criteria andRAKU_TSLessThan(String value) {
            addCriterion("RAKU_TS <", value, "RAKU_TS");
            return (Criteria) this;
        }

        public Criteria andRAKU_TSLessThanOrEqualTo(String value) {
            addCriterion("RAKU_TS <=", value, "RAKU_TS");
            return (Criteria) this;
        }

        public Criteria andRAKU_TSLike(String value) {
            addCriterion("RAKU_TS like", value, "RAKU_TS");
            return (Criteria) this;
        }

        public Criteria andRAKU_TSNotLike(String value) {
            addCriterion("RAKU_TS not like", value, "RAKU_TS");
            return (Criteria) this;
        }

        public Criteria andRAKU_TSIn(List<String> values) {
            addCriterion("RAKU_TS in", values, "RAKU_TS");
            return (Criteria) this;
        }

        public Criteria andRAKU_TSNotIn(List<String> values) {
            addCriterion("RAKU_TS not in", values, "RAKU_TS");
            return (Criteria) this;
        }

        public Criteria andRAKU_TSBetween(String value1, String value2) {
            addCriterion("RAKU_TS between", value1, value2, "RAKU_TS");
            return (Criteria) this;
        }

        public Criteria andRAKU_TSNotBetween(String value1, String value2) {
            addCriterion("RAKU_TS not between", value1, value2, "RAKU_TS");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMIsNull() {
            addCriterion("NYUKAN_TM is null");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMIsNotNull() {
            addCriterion("NYUKAN_TM is not null");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMEqualTo(String value) {
            addCriterion("NYUKAN_TM =", value, "NYUKAN_TM");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMNotEqualTo(String value) {
            addCriterion("NYUKAN_TM <>", value, "NYUKAN_TM");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMGreaterThan(String value) {
            addCriterion("NYUKAN_TM >", value, "NYUKAN_TM");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMGreaterThanOrEqualTo(String value) {
            addCriterion("NYUKAN_TM >=", value, "NYUKAN_TM");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMLessThan(String value) {
            addCriterion("NYUKAN_TM <", value, "NYUKAN_TM");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMLessThanOrEqualTo(String value) {
            addCriterion("NYUKAN_TM <=", value, "NYUKAN_TM");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMLike(String value) {
            addCriterion("NYUKAN_TM like", value, "NYUKAN_TM");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMNotLike(String value) {
            addCriterion("NYUKAN_TM not like", value, "NYUKAN_TM");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMIn(List<String> values) {
            addCriterion("NYUKAN_TM in", values, "NYUKAN_TM");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMNotIn(List<String> values) {
            addCriterion("NYUKAN_TM not in", values, "NYUKAN_TM");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMBetween(String value1, String value2) {
            addCriterion("NYUKAN_TM between", value1, value2, "NYUKAN_TM");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMNotBetween(String value1, String value2) {
            addCriterion("NYUKAN_TM not between", value1, value2, "NYUKAN_TM");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMIsNull() {
            addCriterion("TAIKAN_TM is null");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMIsNotNull() {
            addCriterion("TAIKAN_TM is not null");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMEqualTo(String value) {
            addCriterion("TAIKAN_TM =", value, "TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMNotEqualTo(String value) {
            addCriterion("TAIKAN_TM <>", value, "TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMGreaterThan(String value) {
            addCriterion("TAIKAN_TM >", value, "TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMGreaterThanOrEqualTo(String value) {
            addCriterion("TAIKAN_TM >=", value, "TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMLessThan(String value) {
            addCriterion("TAIKAN_TM <", value, "TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMLessThanOrEqualTo(String value) {
            addCriterion("TAIKAN_TM <=", value, "TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMLike(String value) {
            addCriterion("TAIKAN_TM like", value, "TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMNotLike(String value) {
            addCriterion("TAIKAN_TM not like", value, "TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMIn(List<String> values) {
            addCriterion("TAIKAN_TM in", values, "TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMNotIn(List<String> values) {
            addCriterion("TAIKAN_TM not in", values, "TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMBetween(String value1, String value2) {
            addCriterion("TAIKAN_TM between", value1, value2, "TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMNotBetween(String value1, String value2) {
            addCriterion("TAIKAN_TM not between", value1, value2, "TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andEND_TMIsNull() {
            addCriterion("END_TM is null");
            return (Criteria) this;
        }

        public Criteria andEND_TMIsNotNull() {
            addCriterion("END_TM is not null");
            return (Criteria) this;
        }

        public Criteria andEND_TMEqualTo(String value) {
            addCriterion("END_TM =", value, "END_TM");
            return (Criteria) this;
        }

        public Criteria andEND_TMNotEqualTo(String value) {
            addCriterion("END_TM <>", value, "END_TM");
            return (Criteria) this;
        }

        public Criteria andEND_TMGreaterThan(String value) {
            addCriterion("END_TM >", value, "END_TM");
            return (Criteria) this;
        }

        public Criteria andEND_TMGreaterThanOrEqualTo(String value) {
            addCriterion("END_TM >=", value, "END_TM");
            return (Criteria) this;
        }

        public Criteria andEND_TMLessThan(String value) {
            addCriterion("END_TM <", value, "END_TM");
            return (Criteria) this;
        }

        public Criteria andEND_TMLessThanOrEqualTo(String value) {
            addCriterion("END_TM <=", value, "END_TM");
            return (Criteria) this;
        }

        public Criteria andEND_TMLike(String value) {
            addCriterion("END_TM like", value, "END_TM");
            return (Criteria) this;
        }

        public Criteria andEND_TMNotLike(String value) {
            addCriterion("END_TM not like", value, "END_TM");
            return (Criteria) this;
        }

        public Criteria andEND_TMIn(List<String> values) {
            addCriterion("END_TM in", values, "END_TM");
            return (Criteria) this;
        }

        public Criteria andEND_TMNotIn(List<String> values) {
            addCriterion("END_TM not in", values, "END_TM");
            return (Criteria) this;
        }

        public Criteria andEND_TMBetween(String value1, String value2) {
            addCriterion("END_TM between", value1, value2, "END_TM");
            return (Criteria) this;
        }

        public Criteria andEND_TMNotBetween(String value1, String value2) {
            addCriterion("END_TM not between", value1, value2, "END_TM");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSIsNull() {
            addCriterion("END_YOTEI_TS is null");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSIsNotNull() {
            addCriterion("END_YOTEI_TS is not null");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSEqualTo(String value) {
            addCriterion("END_YOTEI_TS =", value, "END_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSNotEqualTo(String value) {
            addCriterion("END_YOTEI_TS <>", value, "END_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSGreaterThan(String value) {
            addCriterion("END_YOTEI_TS >", value, "END_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSGreaterThanOrEqualTo(String value) {
            addCriterion("END_YOTEI_TS >=", value, "END_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSLessThan(String value) {
            addCriterion("END_YOTEI_TS <", value, "END_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSLessThanOrEqualTo(String value) {
            addCriterion("END_YOTEI_TS <=", value, "END_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSLike(String value) {
            addCriterion("END_YOTEI_TS like", value, "END_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSNotLike(String value) {
            addCriterion("END_YOTEI_TS not like", value, "END_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSIn(List<String> values) {
            addCriterion("END_YOTEI_TS in", values, "END_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSNotIn(List<String> values) {
            addCriterion("END_YOTEI_TS not in", values, "END_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSBetween(String value1, String value2) {
            addCriterion("END_YOTEI_TS between", value1, value2, "END_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSNotBetween(String value1, String value2) {
            addCriterion("END_YOTEI_TS not between", value1, value2, "END_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMIsNull() {
            addCriterion("POLICE_CALL_TM is null");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMIsNotNull() {
            addCriterion("POLICE_CALL_TM is not null");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMEqualTo(String value) {
            addCriterion("POLICE_CALL_TM =", value, "POLICE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMNotEqualTo(String value) {
            addCriterion("POLICE_CALL_TM <>", value, "POLICE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMGreaterThan(String value) {
            addCriterion("POLICE_CALL_TM >", value, "POLICE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMGreaterThanOrEqualTo(String value) {
            addCriterion("POLICE_CALL_TM >=", value, "POLICE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMLessThan(String value) {
            addCriterion("POLICE_CALL_TM <", value, "POLICE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMLessThanOrEqualTo(String value) {
            addCriterion("POLICE_CALL_TM <=", value, "POLICE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMLike(String value) {
            addCriterion("POLICE_CALL_TM like", value, "POLICE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMNotLike(String value) {
            addCriterion("POLICE_CALL_TM not like", value, "POLICE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMIn(List<String> values) {
            addCriterion("POLICE_CALL_TM in", values, "POLICE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMNotIn(List<String> values) {
            addCriterion("POLICE_CALL_TM not in", values, "POLICE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMBetween(String value1, String value2) {
            addCriterion("POLICE_CALL_TM between", value1, value2, "POLICE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMNotBetween(String value1, String value2) {
            addCriterion("POLICE_CALL_TM not between", value1, value2, "POLICE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMIsNull() {
            addCriterion("POLICE_ARRIV_TM is null");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMIsNotNull() {
            addCriterion("POLICE_ARRIV_TM is not null");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMEqualTo(String value) {
            addCriterion("POLICE_ARRIV_TM =", value, "POLICE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMNotEqualTo(String value) {
            addCriterion("POLICE_ARRIV_TM <>", value, "POLICE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMGreaterThan(String value) {
            addCriterion("POLICE_ARRIV_TM >", value, "POLICE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMGreaterThanOrEqualTo(String value) {
            addCriterion("POLICE_ARRIV_TM >=", value, "POLICE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMLessThan(String value) {
            addCriterion("POLICE_ARRIV_TM <", value, "POLICE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMLessThanOrEqualTo(String value) {
            addCriterion("POLICE_ARRIV_TM <=", value, "POLICE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMLike(String value) {
            addCriterion("POLICE_ARRIV_TM like", value, "POLICE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMNotLike(String value) {
            addCriterion("POLICE_ARRIV_TM not like", value, "POLICE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMIn(List<String> values) {
            addCriterion("POLICE_ARRIV_TM in", values, "POLICE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMNotIn(List<String> values) {
            addCriterion("POLICE_ARRIV_TM not in", values, "POLICE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMBetween(String value1, String value2) {
            addCriterion("POLICE_ARRIV_TM between", value1, value2, "POLICE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMNotBetween(String value1, String value2) {
            addCriterion("POLICE_ARRIV_TM not between", value1, value2, "POLICE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMIsNull() {
            addCriterion("FIRE_CALL_TM is null");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMIsNotNull() {
            addCriterion("FIRE_CALL_TM is not null");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMEqualTo(String value) {
            addCriterion("FIRE_CALL_TM =", value, "FIRE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMNotEqualTo(String value) {
            addCriterion("FIRE_CALL_TM <>", value, "FIRE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMGreaterThan(String value) {
            addCriterion("FIRE_CALL_TM >", value, "FIRE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMGreaterThanOrEqualTo(String value) {
            addCriterion("FIRE_CALL_TM >=", value, "FIRE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMLessThan(String value) {
            addCriterion("FIRE_CALL_TM <", value, "FIRE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMLessThanOrEqualTo(String value) {
            addCriterion("FIRE_CALL_TM <=", value, "FIRE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMLike(String value) {
            addCriterion("FIRE_CALL_TM like", value, "FIRE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMNotLike(String value) {
            addCriterion("FIRE_CALL_TM not like", value, "FIRE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMIn(List<String> values) {
            addCriterion("FIRE_CALL_TM in", values, "FIRE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMNotIn(List<String> values) {
            addCriterion("FIRE_CALL_TM not in", values, "FIRE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMBetween(String value1, String value2) {
            addCriterion("FIRE_CALL_TM between", value1, value2, "FIRE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMNotBetween(String value1, String value2) {
            addCriterion("FIRE_CALL_TM not between", value1, value2, "FIRE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMIsNull() {
            addCriterion("FIRE_ARRIV_TM is null");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMIsNotNull() {
            addCriterion("FIRE_ARRIV_TM is not null");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMEqualTo(String value) {
            addCriterion("FIRE_ARRIV_TM =", value, "FIRE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMNotEqualTo(String value) {
            addCriterion("FIRE_ARRIV_TM <>", value, "FIRE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMGreaterThan(String value) {
            addCriterion("FIRE_ARRIV_TM >", value, "FIRE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMGreaterThanOrEqualTo(String value) {
            addCriterion("FIRE_ARRIV_TM >=", value, "FIRE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMLessThan(String value) {
            addCriterion("FIRE_ARRIV_TM <", value, "FIRE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMLessThanOrEqualTo(String value) {
            addCriterion("FIRE_ARRIV_TM <=", value, "FIRE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMLike(String value) {
            addCriterion("FIRE_ARRIV_TM like", value, "FIRE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMNotLike(String value) {
            addCriterion("FIRE_ARRIV_TM not like", value, "FIRE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMIn(List<String> values) {
            addCriterion("FIRE_ARRIV_TM in", values, "FIRE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMNotIn(List<String> values) {
            addCriterion("FIRE_ARRIV_TM not in", values, "FIRE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMBetween(String value1, String value2) {
            addCriterion("FIRE_ARRIV_TM between", value1, value2, "FIRE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMNotBetween(String value1, String value2) {
            addCriterion("FIRE_ARRIV_TM not between", value1, value2, "FIRE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDIsNull() {
            addCriterion("POLICE_REASON_CD is null");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDIsNotNull() {
            addCriterion("POLICE_REASON_CD is not null");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDEqualTo(String value) {
            addCriterion("POLICE_REASON_CD =", value, "POLICE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDNotEqualTo(String value) {
            addCriterion("POLICE_REASON_CD <>", value, "POLICE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDGreaterThan(String value) {
            addCriterion("POLICE_REASON_CD >", value, "POLICE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDGreaterThanOrEqualTo(String value) {
            addCriterion("POLICE_REASON_CD >=", value, "POLICE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDLessThan(String value) {
            addCriterion("POLICE_REASON_CD <", value, "POLICE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDLessThanOrEqualTo(String value) {
            addCriterion("POLICE_REASON_CD <=", value, "POLICE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDLike(String value) {
            addCriterion("POLICE_REASON_CD like", value, "POLICE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDNotLike(String value) {
            addCriterion("POLICE_REASON_CD not like", value, "POLICE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDIn(List<String> values) {
            addCriterion("POLICE_REASON_CD in", values, "POLICE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDNotIn(List<String> values) {
            addCriterion("POLICE_REASON_CD not in", values, "POLICE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDBetween(String value1, String value2) {
            addCriterion("POLICE_REASON_CD between", value1, value2, "POLICE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDNotBetween(String value1, String value2) {
            addCriterion("POLICE_REASON_CD not between", value1, value2, "POLICE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONIsNull() {
            addCriterion("POLICE_CALL_REASON is null");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONIsNotNull() {
            addCriterion("POLICE_CALL_REASON is not null");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONEqualTo(String value) {
            addCriterion("POLICE_CALL_REASON =", value, "POLICE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONNotEqualTo(String value) {
            addCriterion("POLICE_CALL_REASON <>", value, "POLICE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONGreaterThan(String value) {
            addCriterion("POLICE_CALL_REASON >", value, "POLICE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONGreaterThanOrEqualTo(String value) {
            addCriterion("POLICE_CALL_REASON >=", value, "POLICE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONLessThan(String value) {
            addCriterion("POLICE_CALL_REASON <", value, "POLICE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONLessThanOrEqualTo(String value) {
            addCriterion("POLICE_CALL_REASON <=", value, "POLICE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONLike(String value) {
            addCriterion("POLICE_CALL_REASON like", value, "POLICE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONNotLike(String value) {
            addCriterion("POLICE_CALL_REASON not like", value, "POLICE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONIn(List<String> values) {
            addCriterion("POLICE_CALL_REASON in", values, "POLICE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONNotIn(List<String> values) {
            addCriterion("POLICE_CALL_REASON not in", values, "POLICE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONBetween(String value1, String value2) {
            addCriterion("POLICE_CALL_REASON between", value1, value2, "POLICE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONNotBetween(String value1, String value2) {
            addCriterion("POLICE_CALL_REASON not between", value1, value2, "POLICE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNIsNull() {
            addCriterion("POLICE_CALL_KBN is null");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNIsNotNull() {
            addCriterion("POLICE_CALL_KBN is not null");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNEqualTo(String value) {
            addCriterion("POLICE_CALL_KBN =", value, "POLICE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNNotEqualTo(String value) {
            addCriterion("POLICE_CALL_KBN <>", value, "POLICE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNGreaterThan(String value) {
            addCriterion("POLICE_CALL_KBN >", value, "POLICE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNGreaterThanOrEqualTo(String value) {
            addCriterion("POLICE_CALL_KBN >=", value, "POLICE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNLessThan(String value) {
            addCriterion("POLICE_CALL_KBN <", value, "POLICE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNLessThanOrEqualTo(String value) {
            addCriterion("POLICE_CALL_KBN <=", value, "POLICE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNLike(String value) {
            addCriterion("POLICE_CALL_KBN like", value, "POLICE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNNotLike(String value) {
            addCriterion("POLICE_CALL_KBN not like", value, "POLICE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNIn(List<String> values) {
            addCriterion("POLICE_CALL_KBN in", values, "POLICE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNNotIn(List<String> values) {
            addCriterion("POLICE_CALL_KBN not in", values, "POLICE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNBetween(String value1, String value2) {
            addCriterion("POLICE_CALL_KBN between", value1, value2, "POLICE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNNotBetween(String value1, String value2) {
            addCriterion("POLICE_CALL_KBN not between", value1, value2, "POLICE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPOIsNull() {
            addCriterion("POLICE_SINPO is null");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPOIsNotNull() {
            addCriterion("POLICE_SINPO is not null");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPOEqualTo(String value) {
            addCriterion("POLICE_SINPO =", value, "POLICE_SINPO");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPONotEqualTo(String value) {
            addCriterion("POLICE_SINPO <>", value, "POLICE_SINPO");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPOGreaterThan(String value) {
            addCriterion("POLICE_SINPO >", value, "POLICE_SINPO");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPOGreaterThanOrEqualTo(String value) {
            addCriterion("POLICE_SINPO >=", value, "POLICE_SINPO");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPOLessThan(String value) {
            addCriterion("POLICE_SINPO <", value, "POLICE_SINPO");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPOLessThanOrEqualTo(String value) {
            addCriterion("POLICE_SINPO <=", value, "POLICE_SINPO");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPOLike(String value) {
            addCriterion("POLICE_SINPO like", value, "POLICE_SINPO");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPONotLike(String value) {
            addCriterion("POLICE_SINPO not like", value, "POLICE_SINPO");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPOIn(List<String> values) {
            addCriterion("POLICE_SINPO in", values, "POLICE_SINPO");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPONotIn(List<String> values) {
            addCriterion("POLICE_SINPO not in", values, "POLICE_SINPO");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPOBetween(String value1, String value2) {
            addCriterion("POLICE_SINPO between", value1, value2, "POLICE_SINPO");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPONotBetween(String value1, String value2) {
            addCriterion("POLICE_SINPO not between", value1, value2, "POLICE_SINPO");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMIsNull() {
            addCriterion("POLICE_TAIKAN_TM is null");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMIsNotNull() {
            addCriterion("POLICE_TAIKAN_TM is not null");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMEqualTo(String value) {
            addCriterion("POLICE_TAIKAN_TM =", value, "POLICE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMNotEqualTo(String value) {
            addCriterion("POLICE_TAIKAN_TM <>", value, "POLICE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMGreaterThan(String value) {
            addCriterion("POLICE_TAIKAN_TM >", value, "POLICE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMGreaterThanOrEqualTo(String value) {
            addCriterion("POLICE_TAIKAN_TM >=", value, "POLICE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMLessThan(String value) {
            addCriterion("POLICE_TAIKAN_TM <", value, "POLICE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMLessThanOrEqualTo(String value) {
            addCriterion("POLICE_TAIKAN_TM <=", value, "POLICE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMLike(String value) {
            addCriterion("POLICE_TAIKAN_TM like", value, "POLICE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMNotLike(String value) {
            addCriterion("POLICE_TAIKAN_TM not like", value, "POLICE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMIn(List<String> values) {
            addCriterion("POLICE_TAIKAN_TM in", values, "POLICE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMNotIn(List<String> values) {
            addCriterion("POLICE_TAIKAN_TM not in", values, "POLICE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMBetween(String value1, String value2) {
            addCriterion("POLICE_TAIKAN_TM between", value1, value2, "POLICE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMNotBetween(String value1, String value2) {
            addCriterion("POLICE_TAIKAN_TM not between", value1, value2, "POLICE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDIsNull() {
            addCriterion("FIRE_REASON_CD is null");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDIsNotNull() {
            addCriterion("FIRE_REASON_CD is not null");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDEqualTo(String value) {
            addCriterion("FIRE_REASON_CD =", value, "FIRE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDNotEqualTo(String value) {
            addCriterion("FIRE_REASON_CD <>", value, "FIRE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDGreaterThan(String value) {
            addCriterion("FIRE_REASON_CD >", value, "FIRE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDGreaterThanOrEqualTo(String value) {
            addCriterion("FIRE_REASON_CD >=", value, "FIRE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDLessThan(String value) {
            addCriterion("FIRE_REASON_CD <", value, "FIRE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDLessThanOrEqualTo(String value) {
            addCriterion("FIRE_REASON_CD <=", value, "FIRE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDLike(String value) {
            addCriterion("FIRE_REASON_CD like", value, "FIRE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDNotLike(String value) {
            addCriterion("FIRE_REASON_CD not like", value, "FIRE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDIn(List<String> values) {
            addCriterion("FIRE_REASON_CD in", values, "FIRE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDNotIn(List<String> values) {
            addCriterion("FIRE_REASON_CD not in", values, "FIRE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDBetween(String value1, String value2) {
            addCriterion("FIRE_REASON_CD between", value1, value2, "FIRE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDNotBetween(String value1, String value2) {
            addCriterion("FIRE_REASON_CD not between", value1, value2, "FIRE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONIsNull() {
            addCriterion("FIRE_CALL_REASON is null");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONIsNotNull() {
            addCriterion("FIRE_CALL_REASON is not null");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONEqualTo(String value) {
            addCriterion("FIRE_CALL_REASON =", value, "FIRE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONNotEqualTo(String value) {
            addCriterion("FIRE_CALL_REASON <>", value, "FIRE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONGreaterThan(String value) {
            addCriterion("FIRE_CALL_REASON >", value, "FIRE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONGreaterThanOrEqualTo(String value) {
            addCriterion("FIRE_CALL_REASON >=", value, "FIRE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONLessThan(String value) {
            addCriterion("FIRE_CALL_REASON <", value, "FIRE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONLessThanOrEqualTo(String value) {
            addCriterion("FIRE_CALL_REASON <=", value, "FIRE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONLike(String value) {
            addCriterion("FIRE_CALL_REASON like", value, "FIRE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONNotLike(String value) {
            addCriterion("FIRE_CALL_REASON not like", value, "FIRE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONIn(List<String> values) {
            addCriterion("FIRE_CALL_REASON in", values, "FIRE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONNotIn(List<String> values) {
            addCriterion("FIRE_CALL_REASON not in", values, "FIRE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONBetween(String value1, String value2) {
            addCriterion("FIRE_CALL_REASON between", value1, value2, "FIRE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONNotBetween(String value1, String value2) {
            addCriterion("FIRE_CALL_REASON not between", value1, value2, "FIRE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNIsNull() {
            addCriterion("FIRE_CALL_KBN is null");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNIsNotNull() {
            addCriterion("FIRE_CALL_KBN is not null");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNEqualTo(String value) {
            addCriterion("FIRE_CALL_KBN =", value, "FIRE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNNotEqualTo(String value) {
            addCriterion("FIRE_CALL_KBN <>", value, "FIRE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNGreaterThan(String value) {
            addCriterion("FIRE_CALL_KBN >", value, "FIRE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNGreaterThanOrEqualTo(String value) {
            addCriterion("FIRE_CALL_KBN >=", value, "FIRE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNLessThan(String value) {
            addCriterion("FIRE_CALL_KBN <", value, "FIRE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNLessThanOrEqualTo(String value) {
            addCriterion("FIRE_CALL_KBN <=", value, "FIRE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNLike(String value) {
            addCriterion("FIRE_CALL_KBN like", value, "FIRE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNNotLike(String value) {
            addCriterion("FIRE_CALL_KBN not like", value, "FIRE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNIn(List<String> values) {
            addCriterion("FIRE_CALL_KBN in", values, "FIRE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNNotIn(List<String> values) {
            addCriterion("FIRE_CALL_KBN not in", values, "FIRE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNBetween(String value1, String value2) {
            addCriterion("FIRE_CALL_KBN between", value1, value2, "FIRE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNNotBetween(String value1, String value2) {
            addCriterion("FIRE_CALL_KBN not between", value1, value2, "FIRE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPOIsNull() {
            addCriterion("FIRE_SINPO is null");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPOIsNotNull() {
            addCriterion("FIRE_SINPO is not null");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPOEqualTo(String value) {
            addCriterion("FIRE_SINPO =", value, "FIRE_SINPO");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPONotEqualTo(String value) {
            addCriterion("FIRE_SINPO <>", value, "FIRE_SINPO");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPOGreaterThan(String value) {
            addCriterion("FIRE_SINPO >", value, "FIRE_SINPO");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPOGreaterThanOrEqualTo(String value) {
            addCriterion("FIRE_SINPO >=", value, "FIRE_SINPO");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPOLessThan(String value) {
            addCriterion("FIRE_SINPO <", value, "FIRE_SINPO");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPOLessThanOrEqualTo(String value) {
            addCriterion("FIRE_SINPO <=", value, "FIRE_SINPO");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPOLike(String value) {
            addCriterion("FIRE_SINPO like", value, "FIRE_SINPO");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPONotLike(String value) {
            addCriterion("FIRE_SINPO not like", value, "FIRE_SINPO");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPOIn(List<String> values) {
            addCriterion("FIRE_SINPO in", values, "FIRE_SINPO");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPONotIn(List<String> values) {
            addCriterion("FIRE_SINPO not in", values, "FIRE_SINPO");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPOBetween(String value1, String value2) {
            addCriterion("FIRE_SINPO between", value1, value2, "FIRE_SINPO");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPONotBetween(String value1, String value2) {
            addCriterion("FIRE_SINPO not between", value1, value2, "FIRE_SINPO");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMIsNull() {
            addCriterion("FIRE_TAIKAN_TM is null");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMIsNotNull() {
            addCriterion("FIRE_TAIKAN_TM is not null");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMEqualTo(String value) {
            addCriterion("FIRE_TAIKAN_TM =", value, "FIRE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMNotEqualTo(String value) {
            addCriterion("FIRE_TAIKAN_TM <>", value, "FIRE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMGreaterThan(String value) {
            addCriterion("FIRE_TAIKAN_TM >", value, "FIRE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMGreaterThanOrEqualTo(String value) {
            addCriterion("FIRE_TAIKAN_TM >=", value, "FIRE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMLessThan(String value) {
            addCriterion("FIRE_TAIKAN_TM <", value, "FIRE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMLessThanOrEqualTo(String value) {
            addCriterion("FIRE_TAIKAN_TM <=", value, "FIRE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMLike(String value) {
            addCriterion("FIRE_TAIKAN_TM like", value, "FIRE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMNotLike(String value) {
            addCriterion("FIRE_TAIKAN_TM not like", value, "FIRE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMIn(List<String> values) {
            addCriterion("FIRE_TAIKAN_TM in", values, "FIRE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMNotIn(List<String> values) {
            addCriterion("FIRE_TAIKAN_TM not in", values, "FIRE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMBetween(String value1, String value2) {
            addCriterion("FIRE_TAIKAN_TM between", value1, value2, "FIRE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMNotBetween(String value1, String value2) {
            addCriterion("FIRE_TAIKAN_TM not between", value1, value2, "FIRE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDIsNull() {
            addCriterion("SGS_GENIN_CD is null");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDIsNotNull() {
            addCriterion("SGS_GENIN_CD is not null");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDEqualTo(String value) {
            addCriterion("SGS_GENIN_CD =", value, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDNotEqualTo(String value) {
            addCriterion("SGS_GENIN_CD <>", value, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDGreaterThan(String value) {
            addCriterion("SGS_GENIN_CD >", value, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDGreaterThanOrEqualTo(String value) {
            addCriterion("SGS_GENIN_CD >=", value, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDLessThan(String value) {
            addCriterion("SGS_GENIN_CD <", value, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDLessThanOrEqualTo(String value) {
            addCriterion("SGS_GENIN_CD <=", value, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDLike(String value) {
            addCriterion("SGS_GENIN_CD like", value, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDNotLike(String value) {
            addCriterion("SGS_GENIN_CD not like", value, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDIn(List<String> values) {
            addCriterion("SGS_GENIN_CD in", values, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDNotIn(List<String> values) {
            addCriterion("SGS_GENIN_CD not in", values, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDBetween(String value1, String value2) {
            addCriterion("SGS_GENIN_CD between", value1, value2, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDNotBetween(String value1, String value2) {
            addCriterion("SGS_GENIN_CD not between", value1, value2, "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOUIsNull() {
            addCriterion("GEN_DTL_NAIYOU is null");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOUIsNotNull() {
            addCriterion("GEN_DTL_NAIYOU is not null");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOUEqualTo(String value) {
            addCriterion("GEN_DTL_NAIYOU =", value, "GEN_DTL_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOUNotEqualTo(String value) {
            addCriterion("GEN_DTL_NAIYOU <>", value, "GEN_DTL_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOUGreaterThan(String value) {
            addCriterion("GEN_DTL_NAIYOU >", value, "GEN_DTL_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOUGreaterThanOrEqualTo(String value) {
            addCriterion("GEN_DTL_NAIYOU >=", value, "GEN_DTL_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOULessThan(String value) {
            addCriterion("GEN_DTL_NAIYOU <", value, "GEN_DTL_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOULessThanOrEqualTo(String value) {
            addCriterion("GEN_DTL_NAIYOU <=", value, "GEN_DTL_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOULike(String value) {
            addCriterion("GEN_DTL_NAIYOU like", value, "GEN_DTL_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOUNotLike(String value) {
            addCriterion("GEN_DTL_NAIYOU not like", value, "GEN_DTL_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOUIn(List<String> values) {
            addCriterion("GEN_DTL_NAIYOU in", values, "GEN_DTL_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOUNotIn(List<String> values) {
            addCriterion("GEN_DTL_NAIYOU not in", values, "GEN_DTL_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOUBetween(String value1, String value2) {
            addCriterion("GEN_DTL_NAIYOU between", value1, value2, "GEN_DTL_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOUNotBetween(String value1, String value2) {
            addCriterion("GEN_DTL_NAIYOU not between", value1, value2, "GEN_DTL_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1IsNull() {
            addCriterion("GEN_NAIYOU_1 is null");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1IsNotNull() {
            addCriterion("GEN_NAIYOU_1 is not null");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1EqualTo(String value) {
            addCriterion("GEN_NAIYOU_1 =", value, "GEN_NAIYOU_1");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1NotEqualTo(String value) {
            addCriterion("GEN_NAIYOU_1 <>", value, "GEN_NAIYOU_1");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1GreaterThan(String value) {
            addCriterion("GEN_NAIYOU_1 >", value, "GEN_NAIYOU_1");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1GreaterThanOrEqualTo(String value) {
            addCriterion("GEN_NAIYOU_1 >=", value, "GEN_NAIYOU_1");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1LessThan(String value) {
            addCriterion("GEN_NAIYOU_1 <", value, "GEN_NAIYOU_1");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1LessThanOrEqualTo(String value) {
            addCriterion("GEN_NAIYOU_1 <=", value, "GEN_NAIYOU_1");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1Like(String value) {
            addCriterion("GEN_NAIYOU_1 like", value, "GEN_NAIYOU_1");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1NotLike(String value) {
            addCriterion("GEN_NAIYOU_1 not like", value, "GEN_NAIYOU_1");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1In(List<String> values) {
            addCriterion("GEN_NAIYOU_1 in", values, "GEN_NAIYOU_1");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1NotIn(List<String> values) {
            addCriterion("GEN_NAIYOU_1 not in", values, "GEN_NAIYOU_1");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1Between(String value1, String value2) {
            addCriterion("GEN_NAIYOU_1 between", value1, value2, "GEN_NAIYOU_1");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1NotBetween(String value1, String value2) {
            addCriterion("GEN_NAIYOU_1 not between", value1, value2, "GEN_NAIYOU_1");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2IsNull() {
            addCriterion("GEN_NAIYOU_2 is null");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2IsNotNull() {
            addCriterion("GEN_NAIYOU_2 is not null");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2EqualTo(String value) {
            addCriterion("GEN_NAIYOU_2 =", value, "GEN_NAIYOU_2");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2NotEqualTo(String value) {
            addCriterion("GEN_NAIYOU_2 <>", value, "GEN_NAIYOU_2");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2GreaterThan(String value) {
            addCriterion("GEN_NAIYOU_2 >", value, "GEN_NAIYOU_2");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2GreaterThanOrEqualTo(String value) {
            addCriterion("GEN_NAIYOU_2 >=", value, "GEN_NAIYOU_2");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2LessThan(String value) {
            addCriterion("GEN_NAIYOU_2 <", value, "GEN_NAIYOU_2");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2LessThanOrEqualTo(String value) {
            addCriterion("GEN_NAIYOU_2 <=", value, "GEN_NAIYOU_2");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2Like(String value) {
            addCriterion("GEN_NAIYOU_2 like", value, "GEN_NAIYOU_2");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2NotLike(String value) {
            addCriterion("GEN_NAIYOU_2 not like", value, "GEN_NAIYOU_2");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2In(List<String> values) {
            addCriterion("GEN_NAIYOU_2 in", values, "GEN_NAIYOU_2");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2NotIn(List<String> values) {
            addCriterion("GEN_NAIYOU_2 not in", values, "GEN_NAIYOU_2");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2Between(String value1, String value2) {
            addCriterion("GEN_NAIYOU_2 between", value1, value2, "GEN_NAIYOU_2");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2NotBetween(String value1, String value2) {
            addCriterion("GEN_NAIYOU_2 not between", value1, value2, "GEN_NAIYOU_2");
            return (Criteria) this;
        }

        public Criteria andJIANBNRCDIsNull() {
            addCriterion("JIANBNRCD is null");
            return (Criteria) this;
        }

        public Criteria andJIANBNRCDIsNotNull() {
            addCriterion("JIANBNRCD is not null");
            return (Criteria) this;
        }

        public Criteria andJIANBNRCDEqualTo(String value) {
            addCriterion("JIANBNRCD =", value, "JIANBNRCD");
            return (Criteria) this;
        }

        public Criteria andJIANBNRCDNotEqualTo(String value) {
            addCriterion("JIANBNRCD <>", value, "JIANBNRCD");
            return (Criteria) this;
        }

        public Criteria andJIANBNRCDGreaterThan(String value) {
            addCriterion("JIANBNRCD >", value, "JIANBNRCD");
            return (Criteria) this;
        }

        public Criteria andJIANBNRCDGreaterThanOrEqualTo(String value) {
            addCriterion("JIANBNRCD >=", value, "JIANBNRCD");
            return (Criteria) this;
        }

        public Criteria andJIANBNRCDLessThan(String value) {
            addCriterion("JIANBNRCD <", value, "JIANBNRCD");
            return (Criteria) this;
        }

        public Criteria andJIANBNRCDLessThanOrEqualTo(String value) {
            addCriterion("JIANBNRCD <=", value, "JIANBNRCD");
            return (Criteria) this;
        }

        public Criteria andJIANBNRCDLike(String value) {
            addCriterion("JIANBNRCD like", value, "JIANBNRCD");
            return (Criteria) this;
        }

        public Criteria andJIANBNRCDNotLike(String value) {
            addCriterion("JIANBNRCD not like", value, "JIANBNRCD");
            return (Criteria) this;
        }

        public Criteria andJIANBNRCDIn(List<String> values) {
            addCriterion("JIANBNRCD in", values, "JIANBNRCD");
            return (Criteria) this;
        }

        public Criteria andJIANBNRCDNotIn(List<String> values) {
            addCriterion("JIANBNRCD not in", values, "JIANBNRCD");
            return (Criteria) this;
        }

        public Criteria andJIANBNRCDBetween(String value1, String value2) {
            addCriterion("JIANBNRCD between", value1, value2, "JIANBNRCD");
            return (Criteria) this;
        }

        public Criteria andJIANBNRCDNotBetween(String value1, String value2) {
            addCriterion("JIANBNRCD not between", value1, value2, "JIANBNRCD");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNRCDIsNull() {
            addCriterion("KEIHOBNRCD is null");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNRCDIsNotNull() {
            addCriterion("KEIHOBNRCD is not null");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNRCDEqualTo(String value) {
            addCriterion("KEIHOBNRCD =", value, "KEIHOBNRCD");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNRCDNotEqualTo(String value) {
            addCriterion("KEIHOBNRCD <>", value, "KEIHOBNRCD");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNRCDGreaterThan(String value) {
            addCriterion("KEIHOBNRCD >", value, "KEIHOBNRCD");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNRCDGreaterThanOrEqualTo(String value) {
            addCriterion("KEIHOBNRCD >=", value, "KEIHOBNRCD");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNRCDLessThan(String value) {
            addCriterion("KEIHOBNRCD <", value, "KEIHOBNRCD");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNRCDLessThanOrEqualTo(String value) {
            addCriterion("KEIHOBNRCD <=", value, "KEIHOBNRCD");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNRCDLike(String value) {
            addCriterion("KEIHOBNRCD like", value, "KEIHOBNRCD");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNRCDNotLike(String value) {
            addCriterion("KEIHOBNRCD not like", value, "KEIHOBNRCD");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNRCDIn(List<String> values) {
            addCriterion("KEIHOBNRCD in", values, "KEIHOBNRCD");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNRCDNotIn(List<String> values) {
            addCriterion("KEIHOBNRCD not in", values, "KEIHOBNRCD");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNRCDBetween(String value1, String value2) {
            addCriterion("KEIHOBNRCD between", value1, value2, "KEIHOBNRCD");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNRCDNotBetween(String value1, String value2) {
            addCriterion("KEIHOBNRCD not between", value1, value2, "KEIHOBNRCD");
            return (Criteria) this;
        }

        public Criteria andGENBNRCDIsNull() {
            addCriterion("GENBNRCD is null");
            return (Criteria) this;
        }

        public Criteria andGENBNRCDIsNotNull() {
            addCriterion("GENBNRCD is not null");
            return (Criteria) this;
        }

        public Criteria andGENBNRCDEqualTo(String value) {
            addCriterion("GENBNRCD =", value, "GENBNRCD");
            return (Criteria) this;
        }

        public Criteria andGENBNRCDNotEqualTo(String value) {
            addCriterion("GENBNRCD <>", value, "GENBNRCD");
            return (Criteria) this;
        }

        public Criteria andGENBNRCDGreaterThan(String value) {
            addCriterion("GENBNRCD >", value, "GENBNRCD");
            return (Criteria) this;
        }

        public Criteria andGENBNRCDGreaterThanOrEqualTo(String value) {
            addCriterion("GENBNRCD >=", value, "GENBNRCD");
            return (Criteria) this;
        }

        public Criteria andGENBNRCDLessThan(String value) {
            addCriterion("GENBNRCD <", value, "GENBNRCD");
            return (Criteria) this;
        }

        public Criteria andGENBNRCDLessThanOrEqualTo(String value) {
            addCriterion("GENBNRCD <=", value, "GENBNRCD");
            return (Criteria) this;
        }

        public Criteria andGENBNRCDLike(String value) {
            addCriterion("GENBNRCD like", value, "GENBNRCD");
            return (Criteria) this;
        }

        public Criteria andGENBNRCDNotLike(String value) {
            addCriterion("GENBNRCD not like", value, "GENBNRCD");
            return (Criteria) this;
        }

        public Criteria andGENBNRCDIn(List<String> values) {
            addCriterion("GENBNRCD in", values, "GENBNRCD");
            return (Criteria) this;
        }

        public Criteria andGENBNRCDNotIn(List<String> values) {
            addCriterion("GENBNRCD not in", values, "GENBNRCD");
            return (Criteria) this;
        }

        public Criteria andGENBNRCDBetween(String value1, String value2) {
            addCriterion("GENBNRCD between", value1, value2, "GENBNRCD");
            return (Criteria) this;
        }

        public Criteria andGENBNRCDNotBetween(String value1, String value2) {
            addCriterion("GENBNRCD not between", value1, value2, "GENBNRCD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDIsNull() {
            addCriterion("NET_GEN_CD is null");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDIsNotNull() {
            addCriterion("NET_GEN_CD is not null");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDEqualTo(String value) {
            addCriterion("NET_GEN_CD =", value, "NET_GEN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDNotEqualTo(String value) {
            addCriterion("NET_GEN_CD <>", value, "NET_GEN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDGreaterThan(String value) {
            addCriterion("NET_GEN_CD >", value, "NET_GEN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDGreaterThanOrEqualTo(String value) {
            addCriterion("NET_GEN_CD >=", value, "NET_GEN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDLessThan(String value) {
            addCriterion("NET_GEN_CD <", value, "NET_GEN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDLessThanOrEqualTo(String value) {
            addCriterion("NET_GEN_CD <=", value, "NET_GEN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDLike(String value) {
            addCriterion("NET_GEN_CD like", value, "NET_GEN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDNotLike(String value) {
            addCriterion("NET_GEN_CD not like", value, "NET_GEN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDIn(List<String> values) {
            addCriterion("NET_GEN_CD in", values, "NET_GEN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDNotIn(List<String> values) {
            addCriterion("NET_GEN_CD not in", values, "NET_GEN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDBetween(String value1, String value2) {
            addCriterion("NET_GEN_CD between", value1, value2, "NET_GEN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDNotBetween(String value1, String value2) {
            addCriterion("NET_GEN_CD not between", value1, value2, "NET_GEN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOUIsNull() {
            addCriterion("NET_GEN_NAIYOU is null");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOUIsNotNull() {
            addCriterion("NET_GEN_NAIYOU is not null");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOUEqualTo(String value) {
            addCriterion("NET_GEN_NAIYOU =", value, "NET_GEN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOUNotEqualTo(String value) {
            addCriterion("NET_GEN_NAIYOU <>", value, "NET_GEN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOUGreaterThan(String value) {
            addCriterion("NET_GEN_NAIYOU >", value, "NET_GEN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOUGreaterThanOrEqualTo(String value) {
            addCriterion("NET_GEN_NAIYOU >=", value, "NET_GEN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOULessThan(String value) {
            addCriterion("NET_GEN_NAIYOU <", value, "NET_GEN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOULessThanOrEqualTo(String value) {
            addCriterion("NET_GEN_NAIYOU <=", value, "NET_GEN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOULike(String value) {
            addCriterion("NET_GEN_NAIYOU like", value, "NET_GEN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOUNotLike(String value) {
            addCriterion("NET_GEN_NAIYOU not like", value, "NET_GEN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOUIn(List<String> values) {
            addCriterion("NET_GEN_NAIYOU in", values, "NET_GEN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOUNotIn(List<String> values) {
            addCriterion("NET_GEN_NAIYOU not in", values, "NET_GEN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOUBetween(String value1, String value2) {
            addCriterion("NET_GEN_NAIYOU between", value1, value2, "NET_GEN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOUNotBetween(String value1, String value2) {
            addCriterion("NET_GEN_NAIYOU not between", value1, value2, "NET_GEN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andKEIBI_INFIsNull() {
            addCriterion("KEIBI_INF is null");
            return (Criteria) this;
        }

        public Criteria andKEIBI_INFIsNotNull() {
            addCriterion("KEIBI_INF is not null");
            return (Criteria) this;
        }

        public Criteria andKEIBI_INFEqualTo(String value) {
            addCriterion("KEIBI_INF =", value, "KEIBI_INF");
            return (Criteria) this;
        }

        public Criteria andKEIBI_INFNotEqualTo(String value) {
            addCriterion("KEIBI_INF <>", value, "KEIBI_INF");
            return (Criteria) this;
        }

        public Criteria andKEIBI_INFGreaterThan(String value) {
            addCriterion("KEIBI_INF >", value, "KEIBI_INF");
            return (Criteria) this;
        }

        public Criteria andKEIBI_INFGreaterThanOrEqualTo(String value) {
            addCriterion("KEIBI_INF >=", value, "KEIBI_INF");
            return (Criteria) this;
        }

        public Criteria andKEIBI_INFLessThan(String value) {
            addCriterion("KEIBI_INF <", value, "KEIBI_INF");
            return (Criteria) this;
        }

        public Criteria andKEIBI_INFLessThanOrEqualTo(String value) {
            addCriterion("KEIBI_INF <=", value, "KEIBI_INF");
            return (Criteria) this;
        }

        public Criteria andKEIBI_INFLike(String value) {
            addCriterion("KEIBI_INF like", value, "KEIBI_INF");
            return (Criteria) this;
        }

        public Criteria andKEIBI_INFNotLike(String value) {
            addCriterion("KEIBI_INF not like", value, "KEIBI_INF");
            return (Criteria) this;
        }

        public Criteria andKEIBI_INFIn(List<String> values) {
            addCriterion("KEIBI_INF in", values, "KEIBI_INF");
            return (Criteria) this;
        }

        public Criteria andKEIBI_INFNotIn(List<String> values) {
            addCriterion("KEIBI_INF not in", values, "KEIBI_INF");
            return (Criteria) this;
        }

        public Criteria andKEIBI_INFBetween(String value1, String value2) {
            addCriterion("KEIBI_INF between", value1, value2, "KEIBI_INF");
            return (Criteria) this;
        }

        public Criteria andKEIBI_INFNotBetween(String value1, String value2) {
            addCriterion("KEIBI_INF not between", value1, value2, "KEIBI_INF");
            return (Criteria) this;
        }

        public Criteria andRAKU_UPDATE_TSIsNull() {
            addCriterion("RAKU_UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andRAKU_UPDATE_TSIsNotNull() {
            addCriterion("RAKU_UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andRAKU_UPDATE_TSEqualTo(String value) {
            addCriterion("RAKU_UPDATE_TS =", value, "RAKU_UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andRAKU_UPDATE_TSNotEqualTo(String value) {
            addCriterion("RAKU_UPDATE_TS <>", value, "RAKU_UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andRAKU_UPDATE_TSGreaterThan(String value) {
            addCriterion("RAKU_UPDATE_TS >", value, "RAKU_UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andRAKU_UPDATE_TSGreaterThanOrEqualTo(String value) {
            addCriterion("RAKU_UPDATE_TS >=", value, "RAKU_UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andRAKU_UPDATE_TSLessThan(String value) {
            addCriterion("RAKU_UPDATE_TS <", value, "RAKU_UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andRAKU_UPDATE_TSLessThanOrEqualTo(String value) {
            addCriterion("RAKU_UPDATE_TS <=", value, "RAKU_UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andRAKU_UPDATE_TSLike(String value) {
            addCriterion("RAKU_UPDATE_TS like", value, "RAKU_UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andRAKU_UPDATE_TSNotLike(String value) {
            addCriterion("RAKU_UPDATE_TS not like", value, "RAKU_UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andRAKU_UPDATE_TSIn(List<String> values) {
            addCriterion("RAKU_UPDATE_TS in", values, "RAKU_UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andRAKU_UPDATE_TSNotIn(List<String> values) {
            addCriterion("RAKU_UPDATE_TS not in", values, "RAKU_UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andRAKU_UPDATE_TSBetween(String value1, String value2) {
            addCriterion("RAKU_UPDATE_TS between", value1, value2, "RAKU_UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andRAKU_UPDATE_TSNotBetween(String value1, String value2) {
            addCriterion("RAKU_UPDATE_TS not between", value1, value2, "RAKU_UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDIsNull() {
            addCriterion("JIGYO_CD is null");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDIsNotNull() {
            addCriterion("JIGYO_CD is not null");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDEqualTo(String value) {
            addCriterion("JIGYO_CD =", value, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDNotEqualTo(String value) {
            addCriterion("JIGYO_CD <>", value, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDGreaterThan(String value) {
            addCriterion("JIGYO_CD >", value, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDGreaterThanOrEqualTo(String value) {
            addCriterion("JIGYO_CD >=", value, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDLessThan(String value) {
            addCriterion("JIGYO_CD <", value, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDLessThanOrEqualTo(String value) {
            addCriterion("JIGYO_CD <=", value, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDLike(String value) {
            addCriterion("JIGYO_CD like", value, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDNotLike(String value) {
            addCriterion("JIGYO_CD not like", value, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDIn(List<String> values) {
            addCriterion("JIGYO_CD in", values, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDNotIn(List<String> values) {
            addCriterion("JIGYO_CD not in", values, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDBetween(String value1, String value2) {
            addCriterion("JIGYO_CD between", value1, value2, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDNotBetween(String value1, String value2) {
            addCriterion("JIGYO_CD not between", value1, value2, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_NMIsNull() {
            addCriterion("JIGYO_NM is null");
            return (Criteria) this;
        }

        public Criteria andJIGYO_NMIsNotNull() {
            addCriterion("JIGYO_NM is not null");
            return (Criteria) this;
        }

        public Criteria andJIGYO_NMEqualTo(String value) {
            addCriterion("JIGYO_NM =", value, "JIGYO_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYO_NMNotEqualTo(String value) {
            addCriterion("JIGYO_NM <>", value, "JIGYO_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYO_NMGreaterThan(String value) {
            addCriterion("JIGYO_NM >", value, "JIGYO_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYO_NMGreaterThanOrEqualTo(String value) {
            addCriterion("JIGYO_NM >=", value, "JIGYO_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYO_NMLessThan(String value) {
            addCriterion("JIGYO_NM <", value, "JIGYO_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYO_NMLessThanOrEqualTo(String value) {
            addCriterion("JIGYO_NM <=", value, "JIGYO_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYO_NMLike(String value) {
            addCriterion("JIGYO_NM like", value, "JIGYO_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYO_NMNotLike(String value) {
            addCriterion("JIGYO_NM not like", value, "JIGYO_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYO_NMIn(List<String> values) {
            addCriterion("JIGYO_NM in", values, "JIGYO_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYO_NMNotIn(List<String> values) {
            addCriterion("JIGYO_NM not in", values, "JIGYO_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYO_NMBetween(String value1, String value2) {
            addCriterion("JIGYO_NM between", value1, value2, "JIGYO_NM");
            return (Criteria) this;
        }

        public Criteria andJIGYO_NMNotBetween(String value1, String value2) {
            addCriterion("JIGYO_NM not between", value1, value2, "JIGYO_NM");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDIsNull() {
            addCriterion("JITAI_CD is null");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDIsNotNull() {
            addCriterion("JITAI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDEqualTo(String value) {
            addCriterion("JITAI_CD =", value, "JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDNotEqualTo(String value) {
            addCriterion("JITAI_CD <>", value, "JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDGreaterThan(String value) {
            addCriterion("JITAI_CD >", value, "JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("JITAI_CD >=", value, "JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDLessThan(String value) {
            addCriterion("JITAI_CD <", value, "JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDLessThanOrEqualTo(String value) {
            addCriterion("JITAI_CD <=", value, "JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDLike(String value) {
            addCriterion("JITAI_CD like", value, "JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDNotLike(String value) {
            addCriterion("JITAI_CD not like", value, "JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDIn(List<String> values) {
            addCriterion("JITAI_CD in", values, "JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDNotIn(List<String> values) {
            addCriterion("JITAI_CD not in", values, "JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDBetween(String value1, String value2) {
            addCriterion("JITAI_CD between", value1, value2, "JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDNotBetween(String value1, String value2) {
            addCriterion("JITAI_CD not between", value1, value2, "JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_DATEIsNull() {
            addCriterion("KEIHOU_DATE is null");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_DATEIsNotNull() {
            addCriterion("KEIHOU_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_DATEEqualTo(String value) {
            addCriterion("KEIHOU_DATE =", value, "KEIHOU_DATE");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_DATENotEqualTo(String value) {
            addCriterion("KEIHOU_DATE <>", value, "KEIHOU_DATE");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_DATEGreaterThan(String value) {
            addCriterion("KEIHOU_DATE >", value, "KEIHOU_DATE");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_DATEGreaterThanOrEqualTo(String value) {
            addCriterion("KEIHOU_DATE >=", value, "KEIHOU_DATE");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_DATELessThan(String value) {
            addCriterion("KEIHOU_DATE <", value, "KEIHOU_DATE");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_DATELessThanOrEqualTo(String value) {
            addCriterion("KEIHOU_DATE <=", value, "KEIHOU_DATE");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_DATELike(String value) {
            addCriterion("KEIHOU_DATE like", value, "KEIHOU_DATE");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_DATENotLike(String value) {
            addCriterion("KEIHOU_DATE not like", value, "KEIHOU_DATE");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_DATEIn(List<String> values) {
            addCriterion("KEIHOU_DATE in", values, "KEIHOU_DATE");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_DATENotIn(List<String> values) {
            addCriterion("KEIHOU_DATE not in", values, "KEIHOU_DATE");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_DATEBetween(String value1, String value2) {
            addCriterion("KEIHOU_DATE between", value1, value2, "KEIHOU_DATE");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_DATENotBetween(String value1, String value2) {
            addCriterion("KEIHOU_DATE not between", value1, value2, "KEIHOU_DATE");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNIsNull() {
            addCriterion("TAIKAN_KBN is null");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNIsNotNull() {
            addCriterion("TAIKAN_KBN is not null");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNEqualTo(String value) {
            addCriterion("TAIKAN_KBN =", value, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNNotEqualTo(String value) {
            addCriterion("TAIKAN_KBN <>", value, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNGreaterThan(String value) {
            addCriterion("TAIKAN_KBN >", value, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNGreaterThanOrEqualTo(String value) {
            addCriterion("TAIKAN_KBN >=", value, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNLessThan(String value) {
            addCriterion("TAIKAN_KBN <", value, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNLessThanOrEqualTo(String value) {
            addCriterion("TAIKAN_KBN <=", value, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNLike(String value) {
            addCriterion("TAIKAN_KBN like", value, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNNotLike(String value) {
            addCriterion("TAIKAN_KBN not like", value, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNIn(List<String> values) {
            addCriterion("TAIKAN_KBN in", values, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNNotIn(List<String> values) {
            addCriterion("TAIKAN_KBN not in", values, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNBetween(String value1, String value2) {
            addCriterion("TAIKAN_KBN between", value1, value2, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNNotBetween(String value1, String value2) {
            addCriterion("TAIKAN_KBN not between", value1, value2, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANIsNull() {
            addCriterion("LN_JIAN is null");
            return (Criteria) this;
        }

        public Criteria andLN_JIANIsNotNull() {
            addCriterion("LN_JIAN is not null");
            return (Criteria) this;
        }

        public Criteria andLN_JIANEqualTo(String value) {
            addCriterion("LN_JIAN =", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANNotEqualTo(String value) {
            addCriterion("LN_JIAN <>", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANGreaterThan(String value) {
            addCriterion("LN_JIAN >", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANGreaterThanOrEqualTo(String value) {
            addCriterion("LN_JIAN >=", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANLessThan(String value) {
            addCriterion("LN_JIAN <", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANLessThanOrEqualTo(String value) {
            addCriterion("LN_JIAN <=", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANLike(String value) {
            addCriterion("LN_JIAN like", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANNotLike(String value) {
            addCriterion("LN_JIAN not like", value, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANIn(List<String> values) {
            addCriterion("LN_JIAN in", values, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANNotIn(List<String> values) {
            addCriterion("LN_JIAN not in", values, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANBetween(String value1, String value2) {
            addCriterion("LN_JIAN between", value1, value2, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANNotBetween(String value1, String value2) {
            addCriterion("LN_JIAN not between", value1, value2, "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMIsNull() {
            addCriterion("SIJI_TM is null");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMIsNotNull() {
            addCriterion("SIJI_TM is not null");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMEqualTo(String value) {
            addCriterion("SIJI_TM =", value, "SIJI_TM");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMNotEqualTo(String value) {
            addCriterion("SIJI_TM <>", value, "SIJI_TM");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMGreaterThan(String value) {
            addCriterion("SIJI_TM >", value, "SIJI_TM");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMGreaterThanOrEqualTo(String value) {
            addCriterion("SIJI_TM >=", value, "SIJI_TM");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMLessThan(String value) {
            addCriterion("SIJI_TM <", value, "SIJI_TM");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMLessThanOrEqualTo(String value) {
            addCriterion("SIJI_TM <=", value, "SIJI_TM");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMLike(String value) {
            addCriterion("SIJI_TM like", value, "SIJI_TM");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMNotLike(String value) {
            addCriterion("SIJI_TM not like", value, "SIJI_TM");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMIn(List<String> values) {
            addCriterion("SIJI_TM in", values, "SIJI_TM");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMNotIn(List<String> values) {
            addCriterion("SIJI_TM not in", values, "SIJI_TM");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMBetween(String value1, String value2) {
            addCriterion("SIJI_TM between", value1, value2, "SIJI_TM");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMNotBetween(String value1, String value2) {
            addCriterion("SIJI_TM not between", value1, value2, "SIJI_TM");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMIsNull() {
            addCriterion("CHOKKOU_TM is null");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMIsNotNull() {
            addCriterion("CHOKKOU_TM is not null");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMEqualTo(String value) {
            addCriterion("CHOKKOU_TM =", value, "CHOKKOU_TM");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMNotEqualTo(String value) {
            addCriterion("CHOKKOU_TM <>", value, "CHOKKOU_TM");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMGreaterThan(String value) {
            addCriterion("CHOKKOU_TM >", value, "CHOKKOU_TM");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMGreaterThanOrEqualTo(String value) {
            addCriterion("CHOKKOU_TM >=", value, "CHOKKOU_TM");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMLessThan(String value) {
            addCriterion("CHOKKOU_TM <", value, "CHOKKOU_TM");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMLessThanOrEqualTo(String value) {
            addCriterion("CHOKKOU_TM <=", value, "CHOKKOU_TM");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMLike(String value) {
            addCriterion("CHOKKOU_TM like", value, "CHOKKOU_TM");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMNotLike(String value) {
            addCriterion("CHOKKOU_TM not like", value, "CHOKKOU_TM");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMIn(List<String> values) {
            addCriterion("CHOKKOU_TM in", values, "CHOKKOU_TM");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMNotIn(List<String> values) {
            addCriterion("CHOKKOU_TM not in", values, "CHOKKOU_TM");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMBetween(String value1, String value2) {
            addCriterion("CHOKKOU_TM between", value1, value2, "CHOKKOU_TM");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMNotBetween(String value1, String value2) {
            addCriterion("CHOKKOU_TM not between", value1, value2, "CHOKKOU_TM");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMIsNull() {
            addCriterion("GENCHAKU_TM is null");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMIsNotNull() {
            addCriterion("GENCHAKU_TM is not null");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMEqualTo(String value) {
            addCriterion("GENCHAKU_TM =", value, "GENCHAKU_TM");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMNotEqualTo(String value) {
            addCriterion("GENCHAKU_TM <>", value, "GENCHAKU_TM");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMGreaterThan(String value) {
            addCriterion("GENCHAKU_TM >", value, "GENCHAKU_TM");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMGreaterThanOrEqualTo(String value) {
            addCriterion("GENCHAKU_TM >=", value, "GENCHAKU_TM");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMLessThan(String value) {
            addCriterion("GENCHAKU_TM <", value, "GENCHAKU_TM");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMLessThanOrEqualTo(String value) {
            addCriterion("GENCHAKU_TM <=", value, "GENCHAKU_TM");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMLike(String value) {
            addCriterion("GENCHAKU_TM like", value, "GENCHAKU_TM");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMNotLike(String value) {
            addCriterion("GENCHAKU_TM not like", value, "GENCHAKU_TM");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMIn(List<String> values) {
            addCriterion("GENCHAKU_TM in", values, "GENCHAKU_TM");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMNotIn(List<String> values) {
            addCriterion("GENCHAKU_TM not in", values, "GENCHAKU_TM");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMBetween(String value1, String value2) {
            addCriterion("GENCHAKU_TM between", value1, value2, "GENCHAKU_TM");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMNotBetween(String value1, String value2) {
            addCriterion("GENCHAKU_TM not between", value1, value2, "GENCHAKU_TM");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSIsNull() {
            addCriterion("LASTUPD_TS is null");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSIsNotNull() {
            addCriterion("LASTUPD_TS is not null");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSEqualTo(Date value) {
            addCriterion("LASTUPD_TS =", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSNotEqualTo(Date value) {
            addCriterion("LASTUPD_TS <>", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSGreaterThan(Date value) {
            addCriterion("LASTUPD_TS >", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("LASTUPD_TS >=", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSLessThan(Date value) {
            addCriterion("LASTUPD_TS <", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSLessThanOrEqualTo(Date value) {
            addCriterion("LASTUPD_TS <=", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSIn(List<Date> values) {
            addCriterion("LASTUPD_TS in", values, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSNotIn(List<Date> values) {
            addCriterion("LASTUPD_TS not in", values, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSBetween(Date value1, Date value2) {
            addCriterion("LASTUPD_TS between", value1, value2, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSNotBetween(Date value1, Date value2) {
            addCriterion("LASTUPD_TS not between", value1, value2, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andGC_NUMLikeInsensitive(String value) {
            addCriterion("upper(GC_NUM) like", value.toUpperCase(), "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_SGSLikeInsensitive(String value) {
            addCriterion("upper(LN_SGS) like", value.toUpperCase(), "LN_SGS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSLikeInsensitive(String value) {
            addCriterion("upper(HASSEI_TS) like", value.toUpperCase(), "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andADDR_CDLikeInsensitive(String value) {
            addCriterion("upper(ADDR_CD) like", value.toUpperCase(), "ADDR_CD");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNLikeInsensitive(String value) {
            addCriterion("upper(SYUTUDOU_KBN) like", value.toUpperCase(), "SYUTUDOU_KBN");
            return (Criteria) this;
        }

        public Criteria andOUEN_MARKLikeInsensitive(String value) {
            addCriterion("upper(OUEN_MARK) like", value.toUpperCase(), "OUEN_MARK");
            return (Criteria) this;
        }

        public Criteria andRAKU_SEKILikeInsensitive(String value) {
            addCriterion("upper(RAKU_SEKI) like", value.toUpperCase(), "RAKU_SEKI");
            return (Criteria) this;
        }

        public Criteria andRAKU_OPERATOR_NUMLikeInsensitive(String value) {
            addCriterion("upper(RAKU_OPERATOR_NUM) like", value.toUpperCase(), "RAKU_OPERATOR_NUM");
            return (Criteria) this;
        }

        public Criteria andRAKU_NMLikeInsensitive(String value) {
            addCriterion("upper(RAKU_NM) like", value.toUpperCase(), "RAKU_NM");
            return (Criteria) this;
        }

        public Criteria andRAKU_TSLikeInsensitive(String value) {
            addCriterion("upper(RAKU_TS) like", value.toUpperCase(), "RAKU_TS");
            return (Criteria) this;
        }

        public Criteria andNYUKAN_TMLikeInsensitive(String value) {
            addCriterion("upper(NYUKAN_TM) like", value.toUpperCase(), "NYUKAN_TM");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_TMLikeInsensitive(String value) {
            addCriterion("upper(TAIKAN_TM) like", value.toUpperCase(), "TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andEND_TMLikeInsensitive(String value) {
            addCriterion("upper(END_TM) like", value.toUpperCase(), "END_TM");
            return (Criteria) this;
        }

        public Criteria andEND_YOTEI_TSLikeInsensitive(String value) {
            addCriterion("upper(END_YOTEI_TS) like", value.toUpperCase(), "END_YOTEI_TS");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_TMLikeInsensitive(String value) {
            addCriterion("upper(POLICE_CALL_TM) like", value.toUpperCase(), "POLICE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_ARRIV_TMLikeInsensitive(String value) {
            addCriterion("upper(POLICE_ARRIV_TM) like", value.toUpperCase(), "POLICE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_TMLikeInsensitive(String value) {
            addCriterion("upper(FIRE_CALL_TM) like", value.toUpperCase(), "FIRE_CALL_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_ARRIV_TMLikeInsensitive(String value) {
            addCriterion("upper(FIRE_ARRIV_TM) like", value.toUpperCase(), "FIRE_ARRIV_TM");
            return (Criteria) this;
        }

        public Criteria andPOLICE_REASON_CDLikeInsensitive(String value) {
            addCriterion("upper(POLICE_REASON_CD) like", value.toUpperCase(), "POLICE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_REASONLikeInsensitive(String value) {
            addCriterion("upper(POLICE_CALL_REASON) like", value.toUpperCase(), "POLICE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andPOLICE_CALL_KBNLikeInsensitive(String value) {
            addCriterion("upper(POLICE_CALL_KBN) like", value.toUpperCase(), "POLICE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andPOLICE_SINPOLikeInsensitive(String value) {
            addCriterion("upper(POLICE_SINPO) like", value.toUpperCase(), "POLICE_SINPO");
            return (Criteria) this;
        }

        public Criteria andPOLICE_TAIKAN_TMLikeInsensitive(String value) {
            addCriterion("upper(POLICE_TAIKAN_TM) like", value.toUpperCase(), "POLICE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andFIRE_REASON_CDLikeInsensitive(String value) {
            addCriterion("upper(FIRE_REASON_CD) like", value.toUpperCase(), "FIRE_REASON_CD");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_REASONLikeInsensitive(String value) {
            addCriterion("upper(FIRE_CALL_REASON) like", value.toUpperCase(), "FIRE_CALL_REASON");
            return (Criteria) this;
        }

        public Criteria andFIRE_CALL_KBNLikeInsensitive(String value) {
            addCriterion("upper(FIRE_CALL_KBN) like", value.toUpperCase(), "FIRE_CALL_KBN");
            return (Criteria) this;
        }

        public Criteria andFIRE_SINPOLikeInsensitive(String value) {
            addCriterion("upper(FIRE_SINPO) like", value.toUpperCase(), "FIRE_SINPO");
            return (Criteria) this;
        }

        public Criteria andFIRE_TAIKAN_TMLikeInsensitive(String value) {
            addCriterion("upper(FIRE_TAIKAN_TM) like", value.toUpperCase(), "FIRE_TAIKAN_TM");
            return (Criteria) this;
        }

        public Criteria andSGS_GENIN_CDLikeInsensitive(String value) {
            addCriterion("upper(SGS_GENIN_CD) like", value.toUpperCase(), "SGS_GENIN_CD");
            return (Criteria) this;
        }

        public Criteria andGEN_DTL_NAIYOULikeInsensitive(String value) {
            addCriterion("upper(GEN_DTL_NAIYOU) like", value.toUpperCase(), "GEN_DTL_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_1LikeInsensitive(String value) {
            addCriterion("upper(GEN_NAIYOU_1) like", value.toUpperCase(), "GEN_NAIYOU_1");
            return (Criteria) this;
        }

        public Criteria andGEN_NAIYOU_2LikeInsensitive(String value) {
            addCriterion("upper(GEN_NAIYOU_2) like", value.toUpperCase(), "GEN_NAIYOU_2");
            return (Criteria) this;
        }

        public Criteria andJIANBNRCDLikeInsensitive(String value) {
            addCriterion("upper(JIANBNRCD) like", value.toUpperCase(), "JIANBNRCD");
            return (Criteria) this;
        }

        public Criteria andKEIHOBNRCDLikeInsensitive(String value) {
            addCriterion("upper(KEIHOBNRCD) like", value.toUpperCase(), "KEIHOBNRCD");
            return (Criteria) this;
        }

        public Criteria andGENBNRCDLikeInsensitive(String value) {
            addCriterion("upper(GENBNRCD) like", value.toUpperCase(), "GENBNRCD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_CDLikeInsensitive(String value) {
            addCriterion("upper(NET_GEN_CD) like", value.toUpperCase(), "NET_GEN_CD");
            return (Criteria) this;
        }

        public Criteria andNET_GEN_NAIYOULikeInsensitive(String value) {
            addCriterion("upper(NET_GEN_NAIYOU) like", value.toUpperCase(), "NET_GEN_NAIYOU");
            return (Criteria) this;
        }

        public Criteria andKEIBI_INFLikeInsensitive(String value) {
            addCriterion("upper(KEIBI_INF) like", value.toUpperCase(), "KEIBI_INF");
            return (Criteria) this;
        }

        public Criteria andRAKU_UPDATE_TSLikeInsensitive(String value) {
            addCriterion("upper(RAKU_UPDATE_TS) like", value.toUpperCase(), "RAKU_UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDLikeInsensitive(String value) {
            addCriterion("upper(JIGYO_CD) like", value.toUpperCase(), "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_NMLikeInsensitive(String value) {
            addCriterion("upper(JIGYO_NM) like", value.toUpperCase(), "JIGYO_NM");
            return (Criteria) this;
        }

        public Criteria andJITAI_CDLikeInsensitive(String value) {
            addCriterion("upper(JITAI_CD) like", value.toUpperCase(), "JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andKEIHOU_DATELikeInsensitive(String value) {
            addCriterion("upper(KEIHOU_DATE) like", value.toUpperCase(), "KEIHOU_DATE");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNLikeInsensitive(String value) {
            addCriterion("upper(TAIKAN_KBN) like", value.toUpperCase(), "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andLN_JIANLikeInsensitive(String value) {
            addCriterion("upper(LN_JIAN) like", value.toUpperCase(), "LN_JIAN");
            return (Criteria) this;
        }

        public Criteria andSIJI_TMLikeInsensitive(String value) {
            addCriterion("upper(SIJI_TM) like", value.toUpperCase(), "SIJI_TM");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_TMLikeInsensitive(String value) {
            addCriterion("upper(CHOKKOU_TM) like", value.toUpperCase(), "CHOKKOU_TM");
            return (Criteria) this;
        }

        public Criteria andGENCHAKU_TMLikeInsensitive(String value) {
            addCriterion("upper(GENCHAKU_TM) like", value.toUpperCase(), "GENCHAKU_TM");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * E_V6_RAKUF
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * E_V6_RAKUF null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}