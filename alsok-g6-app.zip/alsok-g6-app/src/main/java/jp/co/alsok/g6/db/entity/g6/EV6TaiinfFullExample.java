package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EV6TaiinfFullExample {
    /**
     * E_V6_TAIINF_FULL
     */
    protected String orderByClause;

    /**
     * E_V6_TAIINF_FULL
     */
    protected boolean distinct;

    /**
     * E_V6_TAIINF_FULL
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public EV6TaiinfFullExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * E_V6_TAIINF_FULL null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andGC_NUMIsNull() {
            addCriterion("GC_NUM is null");
            return (Criteria) this;
        }

        public Criteria andGC_NUMIsNotNull() {
            addCriterion("GC_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andGC_NUMEqualTo(String value) {
            addCriterion("GC_NUM =", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMNotEqualTo(String value) {
            addCriterion("GC_NUM <>", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMGreaterThan(String value) {
            addCriterion("GC_NUM >", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("GC_NUM >=", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMLessThan(String value) {
            addCriterion("GC_NUM <", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMLessThanOrEqualTo(String value) {
            addCriterion("GC_NUM <=", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMLike(String value) {
            addCriterion("GC_NUM like", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMNotLike(String value) {
            addCriterion("GC_NUM not like", value, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMIn(List<String> values) {
            addCriterion("GC_NUM in", values, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMNotIn(List<String> values) {
            addCriterion("GC_NUM not in", values, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMBetween(String value1, String value2) {
            addCriterion("GC_NUM between", value1, value2, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andGC_NUMNotBetween(String value1, String value2) {
            addCriterion("GC_NUM not between", value1, value2, "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_RONRI_NUMIsNull() {
            addCriterion("LN_RONRI_NUM is null");
            return (Criteria) this;
        }

        public Criteria andLN_RONRI_NUMIsNotNull() {
            addCriterion("LN_RONRI_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andLN_RONRI_NUMEqualTo(String value) {
            addCriterion("LN_RONRI_NUM =", value, "LN_RONRI_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_RONRI_NUMNotEqualTo(String value) {
            addCriterion("LN_RONRI_NUM <>", value, "LN_RONRI_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_RONRI_NUMGreaterThan(String value) {
            addCriterion("LN_RONRI_NUM >", value, "LN_RONRI_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_RONRI_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("LN_RONRI_NUM >=", value, "LN_RONRI_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_RONRI_NUMLessThan(String value) {
            addCriterion("LN_RONRI_NUM <", value, "LN_RONRI_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_RONRI_NUMLessThanOrEqualTo(String value) {
            addCriterion("LN_RONRI_NUM <=", value, "LN_RONRI_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_RONRI_NUMLike(String value) {
            addCriterion("LN_RONRI_NUM like", value, "LN_RONRI_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_RONRI_NUMNotLike(String value) {
            addCriterion("LN_RONRI_NUM not like", value, "LN_RONRI_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_RONRI_NUMIn(List<String> values) {
            addCriterion("LN_RONRI_NUM in", values, "LN_RONRI_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_RONRI_NUMNotIn(List<String> values) {
            addCriterion("LN_RONRI_NUM not in", values, "LN_RONRI_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_RONRI_NUMBetween(String value1, String value2) {
            addCriterion("LN_RONRI_NUM between", value1, value2, "LN_RONRI_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_RONRI_NUMNotBetween(String value1, String value2) {
            addCriterion("LN_RONRI_NUM not between", value1, value2, "LN_RONRI_NUM");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSIsNull() {
            addCriterion("JIAN_HASSEI_TS is null");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSIsNotNull() {
            addCriterion("JIAN_HASSEI_TS is not null");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSEqualTo(String value) {
            addCriterion("JIAN_HASSEI_TS =", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSNotEqualTo(String value) {
            addCriterion("JIAN_HASSEI_TS <>", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSGreaterThan(String value) {
            addCriterion("JIAN_HASSEI_TS >", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSGreaterThanOrEqualTo(String value) {
            addCriterion("JIAN_HASSEI_TS >=", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSLessThan(String value) {
            addCriterion("JIAN_HASSEI_TS <", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSLessThanOrEqualTo(String value) {
            addCriterion("JIAN_HASSEI_TS <=", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSLike(String value) {
            addCriterion("JIAN_HASSEI_TS like", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSNotLike(String value) {
            addCriterion("JIAN_HASSEI_TS not like", value, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSIn(List<String> values) {
            addCriterion("JIAN_HASSEI_TS in", values, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSNotIn(List<String> values) {
            addCriterion("JIAN_HASSEI_TS not in", values, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSBetween(String value1, String value2) {
            addCriterion("JIAN_HASSEI_TS between", value1, value2, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSNotBetween(String value1, String value2) {
            addCriterion("JIAN_HASSEI_TS not between", value1, value2, "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andTAIIN_NUMIsNull() {
            addCriterion("TAIIN_NUM is null");
            return (Criteria) this;
        }

        public Criteria andTAIIN_NUMIsNotNull() {
            addCriterion("TAIIN_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andTAIIN_NUMEqualTo(String value) {
            addCriterion("TAIIN_NUM =", value, "TAIIN_NUM");
            return (Criteria) this;
        }

        public Criteria andTAIIN_NUMNotEqualTo(String value) {
            addCriterion("TAIIN_NUM <>", value, "TAIIN_NUM");
            return (Criteria) this;
        }

        public Criteria andTAIIN_NUMGreaterThan(String value) {
            addCriterion("TAIIN_NUM >", value, "TAIIN_NUM");
            return (Criteria) this;
        }

        public Criteria andTAIIN_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("TAIIN_NUM >=", value, "TAIIN_NUM");
            return (Criteria) this;
        }

        public Criteria andTAIIN_NUMLessThan(String value) {
            addCriterion("TAIIN_NUM <", value, "TAIIN_NUM");
            return (Criteria) this;
        }

        public Criteria andTAIIN_NUMLessThanOrEqualTo(String value) {
            addCriterion("TAIIN_NUM <=", value, "TAIIN_NUM");
            return (Criteria) this;
        }

        public Criteria andTAIIN_NUMLike(String value) {
            addCriterion("TAIIN_NUM like", value, "TAIIN_NUM");
            return (Criteria) this;
        }

        public Criteria andTAIIN_NUMNotLike(String value) {
            addCriterion("TAIIN_NUM not like", value, "TAIIN_NUM");
            return (Criteria) this;
        }

        public Criteria andTAIIN_NUMIn(List<String> values) {
            addCriterion("TAIIN_NUM in", values, "TAIIN_NUM");
            return (Criteria) this;
        }

        public Criteria andTAIIN_NUMNotIn(List<String> values) {
            addCriterion("TAIIN_NUM not in", values, "TAIIN_NUM");
            return (Criteria) this;
        }

        public Criteria andTAIIN_NUMBetween(String value1, String value2) {
            addCriterion("TAIIN_NUM between", value1, value2, "TAIIN_NUM");
            return (Criteria) this;
        }

        public Criteria andTAIIN_NUMNotBetween(String value1, String value2) {
            addCriterion("TAIIN_NUM not between", value1, value2, "TAIIN_NUM");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KINDIsNull() {
            addCriterion("TAIIN_KIND is null");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KINDIsNotNull() {
            addCriterion("TAIIN_KIND is not null");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KINDEqualTo(String value) {
            addCriterion("TAIIN_KIND =", value, "TAIIN_KIND");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KINDNotEqualTo(String value) {
            addCriterion("TAIIN_KIND <>", value, "TAIIN_KIND");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KINDGreaterThan(String value) {
            addCriterion("TAIIN_KIND >", value, "TAIIN_KIND");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KINDGreaterThanOrEqualTo(String value) {
            addCriterion("TAIIN_KIND >=", value, "TAIIN_KIND");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KINDLessThan(String value) {
            addCriterion("TAIIN_KIND <", value, "TAIIN_KIND");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KINDLessThanOrEqualTo(String value) {
            addCriterion("TAIIN_KIND <=", value, "TAIIN_KIND");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KINDLike(String value) {
            addCriterion("TAIIN_KIND like", value, "TAIIN_KIND");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KINDNotLike(String value) {
            addCriterion("TAIIN_KIND not like", value, "TAIIN_KIND");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KINDIn(List<String> values) {
            addCriterion("TAIIN_KIND in", values, "TAIIN_KIND");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KINDNotIn(List<String> values) {
            addCriterion("TAIIN_KIND not in", values, "TAIIN_KIND");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KINDBetween(String value1, String value2) {
            addCriterion("TAIIN_KIND between", value1, value2, "TAIIN_KIND");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KINDNotBetween(String value1, String value2) {
            addCriterion("TAIIN_KIND not between", value1, value2, "TAIIN_KIND");
            return (Criteria) this;
        }

        public Criteria andGOUKIIsNull() {
            addCriterion("GOUKI is null");
            return (Criteria) this;
        }

        public Criteria andGOUKIIsNotNull() {
            addCriterion("GOUKI is not null");
            return (Criteria) this;
        }

        public Criteria andGOUKIEqualTo(String value) {
            addCriterion("GOUKI =", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKINotEqualTo(String value) {
            addCriterion("GOUKI <>", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKIGreaterThan(String value) {
            addCriterion("GOUKI >", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKIGreaterThanOrEqualTo(String value) {
            addCriterion("GOUKI >=", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKILessThan(String value) {
            addCriterion("GOUKI <", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKILessThanOrEqualTo(String value) {
            addCriterion("GOUKI <=", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKILike(String value) {
            addCriterion("GOUKI like", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKINotLike(String value) {
            addCriterion("GOUKI not like", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKIIn(List<String> values) {
            addCriterion("GOUKI in", values, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKINotIn(List<String> values) {
            addCriterion("GOUKI not in", values, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKIBetween(String value1, String value2) {
            addCriterion("GOUKI between", value1, value2, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKINotBetween(String value1, String value2) {
            addCriterion("GOUKI not between", value1, value2, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andDENKEIIsNull() {
            addCriterion("DENKEI is null");
            return (Criteria) this;
        }

        public Criteria andDENKEIIsNotNull() {
            addCriterion("DENKEI is not null");
            return (Criteria) this;
        }

        public Criteria andDENKEIEqualTo(String value) {
            addCriterion("DENKEI =", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEINotEqualTo(String value) {
            addCriterion("DENKEI <>", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEIGreaterThan(String value) {
            addCriterion("DENKEI >", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEIGreaterThanOrEqualTo(String value) {
            addCriterion("DENKEI >=", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEILessThan(String value) {
            addCriterion("DENKEI <", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEILessThanOrEqualTo(String value) {
            addCriterion("DENKEI <=", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEILike(String value) {
            addCriterion("DENKEI like", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEINotLike(String value) {
            addCriterion("DENKEI not like", value, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEIIn(List<String> values) {
            addCriterion("DENKEI in", values, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEINotIn(List<String> values) {
            addCriterion("DENKEI not in", values, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEIBetween(String value1, String value2) {
            addCriterion("DENKEI between", value1, value2, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andDENKEINotBetween(String value1, String value2) {
            addCriterion("DENKEI not between", value1, value2, "DENKEI");
            return (Criteria) this;
        }

        public Criteria andSUBADDRIsNull() {
            addCriterion("SUBADDR is null");
            return (Criteria) this;
        }

        public Criteria andSUBADDRIsNotNull() {
            addCriterion("SUBADDR is not null");
            return (Criteria) this;
        }

        public Criteria andSUBADDREqualTo(String value) {
            addCriterion("SUBADDR =", value, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRNotEqualTo(String value) {
            addCriterion("SUBADDR <>", value, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRGreaterThan(String value) {
            addCriterion("SUBADDR >", value, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRGreaterThanOrEqualTo(String value) {
            addCriterion("SUBADDR >=", value, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRLessThan(String value) {
            addCriterion("SUBADDR <", value, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRLessThanOrEqualTo(String value) {
            addCriterion("SUBADDR <=", value, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRLike(String value) {
            addCriterion("SUBADDR like", value, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRNotLike(String value) {
            addCriterion("SUBADDR not like", value, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRIn(List<String> values) {
            addCriterion("SUBADDR in", values, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRNotIn(List<String> values) {
            addCriterion("SUBADDR not in", values, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRBetween(String value1, String value2) {
            addCriterion("SUBADDR between", value1, value2, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andSUBADDRNotBetween(String value1, String value2) {
            addCriterion("SUBADDR not between", value1, value2, "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDIsNull() {
            addCriterion("KEIYAKU_ID is null");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDIsNotNull() {
            addCriterion("KEIYAKU_ID is not null");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDEqualTo(String value) {
            addCriterion("KEIYAKU_ID =", value, "KEIYAKU_ID");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDNotEqualTo(String value) {
            addCriterion("KEIYAKU_ID <>", value, "KEIYAKU_ID");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDGreaterThan(String value) {
            addCriterion("KEIYAKU_ID >", value, "KEIYAKU_ID");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDGreaterThanOrEqualTo(String value) {
            addCriterion("KEIYAKU_ID >=", value, "KEIYAKU_ID");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDLessThan(String value) {
            addCriterion("KEIYAKU_ID <", value, "KEIYAKU_ID");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDLessThanOrEqualTo(String value) {
            addCriterion("KEIYAKU_ID <=", value, "KEIYAKU_ID");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDLike(String value) {
            addCriterion("KEIYAKU_ID like", value, "KEIYAKU_ID");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDNotLike(String value) {
            addCriterion("KEIYAKU_ID not like", value, "KEIYAKU_ID");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDIn(List<String> values) {
            addCriterion("KEIYAKU_ID in", values, "KEIYAKU_ID");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDNotIn(List<String> values) {
            addCriterion("KEIYAKU_ID not in", values, "KEIYAKU_ID");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDBetween(String value1, String value2) {
            addCriterion("KEIYAKU_ID between", value1, value2, "KEIYAKU_ID");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDNotBetween(String value1, String value2) {
            addCriterion("KEIYAKU_ID not between", value1, value2, "KEIYAKU_ID");
            return (Criteria) this;
        }

        public Criteria andABBR_NMIsNull() {
            addCriterion("ABBR_NM is null");
            return (Criteria) this;
        }

        public Criteria andABBR_NMIsNotNull() {
            addCriterion("ABBR_NM is not null");
            return (Criteria) this;
        }

        public Criteria andABBR_NMEqualTo(String value) {
            addCriterion("ABBR_NM =", value, "ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andABBR_NMNotEqualTo(String value) {
            addCriterion("ABBR_NM <>", value, "ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andABBR_NMGreaterThan(String value) {
            addCriterion("ABBR_NM >", value, "ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andABBR_NMGreaterThanOrEqualTo(String value) {
            addCriterion("ABBR_NM >=", value, "ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andABBR_NMLessThan(String value) {
            addCriterion("ABBR_NM <", value, "ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andABBR_NMLessThanOrEqualTo(String value) {
            addCriterion("ABBR_NM <=", value, "ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andABBR_NMLike(String value) {
            addCriterion("ABBR_NM like", value, "ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andABBR_NMNotLike(String value) {
            addCriterion("ABBR_NM not like", value, "ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andABBR_NMIn(List<String> values) {
            addCriterion("ABBR_NM in", values, "ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andABBR_NMNotIn(List<String> values) {
            addCriterion("ABBR_NM not in", values, "ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andABBR_NMBetween(String value1, String value2) {
            addCriterion("ABBR_NM between", value1, value2, "ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andABBR_NMNotBetween(String value1, String value2) {
            addCriterion("ABBR_NM not between", value1, value2, "ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andADDRESS_CDIsNull() {
            addCriterion("ADDRESS_CD is null");
            return (Criteria) this;
        }

        public Criteria andADDRESS_CDIsNotNull() {
            addCriterion("ADDRESS_CD is not null");
            return (Criteria) this;
        }

        public Criteria andADDRESS_CDEqualTo(String value) {
            addCriterion("ADDRESS_CD =", value, "ADDRESS_CD");
            return (Criteria) this;
        }

        public Criteria andADDRESS_CDNotEqualTo(String value) {
            addCriterion("ADDRESS_CD <>", value, "ADDRESS_CD");
            return (Criteria) this;
        }

        public Criteria andADDRESS_CDGreaterThan(String value) {
            addCriterion("ADDRESS_CD >", value, "ADDRESS_CD");
            return (Criteria) this;
        }

        public Criteria andADDRESS_CDGreaterThanOrEqualTo(String value) {
            addCriterion("ADDRESS_CD >=", value, "ADDRESS_CD");
            return (Criteria) this;
        }

        public Criteria andADDRESS_CDLessThan(String value) {
            addCriterion("ADDRESS_CD <", value, "ADDRESS_CD");
            return (Criteria) this;
        }

        public Criteria andADDRESS_CDLessThanOrEqualTo(String value) {
            addCriterion("ADDRESS_CD <=", value, "ADDRESS_CD");
            return (Criteria) this;
        }

        public Criteria andADDRESS_CDLike(String value) {
            addCriterion("ADDRESS_CD like", value, "ADDRESS_CD");
            return (Criteria) this;
        }

        public Criteria andADDRESS_CDNotLike(String value) {
            addCriterion("ADDRESS_CD not like", value, "ADDRESS_CD");
            return (Criteria) this;
        }

        public Criteria andADDRESS_CDIn(List<String> values) {
            addCriterion("ADDRESS_CD in", values, "ADDRESS_CD");
            return (Criteria) this;
        }

        public Criteria andADDRESS_CDNotIn(List<String> values) {
            addCriterion("ADDRESS_CD not in", values, "ADDRESS_CD");
            return (Criteria) this;
        }

        public Criteria andADDRESS_CDBetween(String value1, String value2) {
            addCriterion("ADDRESS_CD between", value1, value2, "ADDRESS_CD");
            return (Criteria) this;
        }

        public Criteria andADDRESS_CDNotBetween(String value1, String value2) {
            addCriterion("ADDRESS_CD not between", value1, value2, "ADDRESS_CD");
            return (Criteria) this;
        }

        public Criteria andTANTOU_OUEN_KBNIsNull() {
            addCriterion("TANTOU_OUEN_KBN is null");
            return (Criteria) this;
        }

        public Criteria andTANTOU_OUEN_KBNIsNotNull() {
            addCriterion("TANTOU_OUEN_KBN is not null");
            return (Criteria) this;
        }

        public Criteria andTANTOU_OUEN_KBNEqualTo(String value) {
            addCriterion("TANTOU_OUEN_KBN =", value, "TANTOU_OUEN_KBN");
            return (Criteria) this;
        }

        public Criteria andTANTOU_OUEN_KBNNotEqualTo(String value) {
            addCriterion("TANTOU_OUEN_KBN <>", value, "TANTOU_OUEN_KBN");
            return (Criteria) this;
        }

        public Criteria andTANTOU_OUEN_KBNGreaterThan(String value) {
            addCriterion("TANTOU_OUEN_KBN >", value, "TANTOU_OUEN_KBN");
            return (Criteria) this;
        }

        public Criteria andTANTOU_OUEN_KBNGreaterThanOrEqualTo(String value) {
            addCriterion("TANTOU_OUEN_KBN >=", value, "TANTOU_OUEN_KBN");
            return (Criteria) this;
        }

        public Criteria andTANTOU_OUEN_KBNLessThan(String value) {
            addCriterion("TANTOU_OUEN_KBN <", value, "TANTOU_OUEN_KBN");
            return (Criteria) this;
        }

        public Criteria andTANTOU_OUEN_KBNLessThanOrEqualTo(String value) {
            addCriterion("TANTOU_OUEN_KBN <=", value, "TANTOU_OUEN_KBN");
            return (Criteria) this;
        }

        public Criteria andTANTOU_OUEN_KBNLike(String value) {
            addCriterion("TANTOU_OUEN_KBN like", value, "TANTOU_OUEN_KBN");
            return (Criteria) this;
        }

        public Criteria andTANTOU_OUEN_KBNNotLike(String value) {
            addCriterion("TANTOU_OUEN_KBN not like", value, "TANTOU_OUEN_KBN");
            return (Criteria) this;
        }

        public Criteria andTANTOU_OUEN_KBNIn(List<String> values) {
            addCriterion("TANTOU_OUEN_KBN in", values, "TANTOU_OUEN_KBN");
            return (Criteria) this;
        }

        public Criteria andTANTOU_OUEN_KBNNotIn(List<String> values) {
            addCriterion("TANTOU_OUEN_KBN not in", values, "TANTOU_OUEN_KBN");
            return (Criteria) this;
        }

        public Criteria andTANTOU_OUEN_KBNBetween(String value1, String value2) {
            addCriterion("TANTOU_OUEN_KBN between", value1, value2, "TANTOU_OUEN_KBN");
            return (Criteria) this;
        }

        public Criteria andTANTOU_OUEN_KBNNotBetween(String value1, String value2) {
            addCriterion("TANTOU_OUEN_KBN not between", value1, value2, "TANTOU_OUEN_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNIsNull() {
            addCriterion("SYUTUDOU_KBN is null");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNIsNotNull() {
            addCriterion("SYUTUDOU_KBN is not null");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNEqualTo(String value) {
            addCriterion("SYUTUDOU_KBN =", value, "SYUTUDOU_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNNotEqualTo(String value) {
            addCriterion("SYUTUDOU_KBN <>", value, "SYUTUDOU_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNGreaterThan(String value) {
            addCriterion("SYUTUDOU_KBN >", value, "SYUTUDOU_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNGreaterThanOrEqualTo(String value) {
            addCriterion("SYUTUDOU_KBN >=", value, "SYUTUDOU_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNLessThan(String value) {
            addCriterion("SYUTUDOU_KBN <", value, "SYUTUDOU_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNLessThanOrEqualTo(String value) {
            addCriterion("SYUTUDOU_KBN <=", value, "SYUTUDOU_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNLike(String value) {
            addCriterion("SYUTUDOU_KBN like", value, "SYUTUDOU_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNNotLike(String value) {
            addCriterion("SYUTUDOU_KBN not like", value, "SYUTUDOU_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNIn(List<String> values) {
            addCriterion("SYUTUDOU_KBN in", values, "SYUTUDOU_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNNotIn(List<String> values) {
            addCriterion("SYUTUDOU_KBN not in", values, "SYUTUDOU_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNBetween(String value1, String value2) {
            addCriterion("SYUTUDOU_KBN between", value1, value2, "SYUTUDOU_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNNotBetween(String value1, String value2) {
            addCriterion("SYUTUDOU_KBN not between", value1, value2, "SYUTUDOU_KBN");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_KBNIsNull() {
            addCriterion("CHOKKOU_KBN is null");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_KBNIsNotNull() {
            addCriterion("CHOKKOU_KBN is not null");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_KBNEqualTo(String value) {
            addCriterion("CHOKKOU_KBN =", value, "CHOKKOU_KBN");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_KBNNotEqualTo(String value) {
            addCriterion("CHOKKOU_KBN <>", value, "CHOKKOU_KBN");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_KBNGreaterThan(String value) {
            addCriterion("CHOKKOU_KBN >", value, "CHOKKOU_KBN");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_KBNGreaterThanOrEqualTo(String value) {
            addCriterion("CHOKKOU_KBN >=", value, "CHOKKOU_KBN");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_KBNLessThan(String value) {
            addCriterion("CHOKKOU_KBN <", value, "CHOKKOU_KBN");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_KBNLessThanOrEqualTo(String value) {
            addCriterion("CHOKKOU_KBN <=", value, "CHOKKOU_KBN");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_KBNLike(String value) {
            addCriterion("CHOKKOU_KBN like", value, "CHOKKOU_KBN");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_KBNNotLike(String value) {
            addCriterion("CHOKKOU_KBN not like", value, "CHOKKOU_KBN");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_KBNIn(List<String> values) {
            addCriterion("CHOKKOU_KBN in", values, "CHOKKOU_KBN");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_KBNNotIn(List<String> values) {
            addCriterion("CHOKKOU_KBN not in", values, "CHOKKOU_KBN");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_KBNBetween(String value1, String value2) {
            addCriterion("CHOKKOU_KBN between", value1, value2, "CHOKKOU_KBN");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_KBNNotBetween(String value1, String value2) {
            addCriterion("CHOKKOU_KBN not between", value1, value2, "CHOKKOU_KBN");
            return (Criteria) this;
        }

        public Criteria andCAR_NUMIsNull() {
            addCriterion("CAR_NUM is null");
            return (Criteria) this;
        }

        public Criteria andCAR_NUMIsNotNull() {
            addCriterion("CAR_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andCAR_NUMEqualTo(String value) {
            addCriterion("CAR_NUM =", value, "CAR_NUM");
            return (Criteria) this;
        }

        public Criteria andCAR_NUMNotEqualTo(String value) {
            addCriterion("CAR_NUM <>", value, "CAR_NUM");
            return (Criteria) this;
        }

        public Criteria andCAR_NUMGreaterThan(String value) {
            addCriterion("CAR_NUM >", value, "CAR_NUM");
            return (Criteria) this;
        }

        public Criteria andCAR_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("CAR_NUM >=", value, "CAR_NUM");
            return (Criteria) this;
        }

        public Criteria andCAR_NUMLessThan(String value) {
            addCriterion("CAR_NUM <", value, "CAR_NUM");
            return (Criteria) this;
        }

        public Criteria andCAR_NUMLessThanOrEqualTo(String value) {
            addCriterion("CAR_NUM <=", value, "CAR_NUM");
            return (Criteria) this;
        }

        public Criteria andCAR_NUMLike(String value) {
            addCriterion("CAR_NUM like", value, "CAR_NUM");
            return (Criteria) this;
        }

        public Criteria andCAR_NUMNotLike(String value) {
            addCriterion("CAR_NUM not like", value, "CAR_NUM");
            return (Criteria) this;
        }

        public Criteria andCAR_NUMIn(List<String> values) {
            addCriterion("CAR_NUM in", values, "CAR_NUM");
            return (Criteria) this;
        }

        public Criteria andCAR_NUMNotIn(List<String> values) {
            addCriterion("CAR_NUM not in", values, "CAR_NUM");
            return (Criteria) this;
        }

        public Criteria andCAR_NUMBetween(String value1, String value2) {
            addCriterion("CAR_NUM between", value1, value2, "CAR_NUM");
            return (Criteria) this;
        }

        public Criteria andCAR_NUMNotBetween(String value1, String value2) {
            addCriterion("CAR_NUM not between", value1, value2, "CAR_NUM");
            return (Criteria) this;
        }

        public Criteria andSIJI_METHODIsNull() {
            addCriterion("SIJI_METHOD is null");
            return (Criteria) this;
        }

        public Criteria andSIJI_METHODIsNotNull() {
            addCriterion("SIJI_METHOD is not null");
            return (Criteria) this;
        }

        public Criteria andSIJI_METHODEqualTo(String value) {
            addCriterion("SIJI_METHOD =", value, "SIJI_METHOD");
            return (Criteria) this;
        }

        public Criteria andSIJI_METHODNotEqualTo(String value) {
            addCriterion("SIJI_METHOD <>", value, "SIJI_METHOD");
            return (Criteria) this;
        }

        public Criteria andSIJI_METHODGreaterThan(String value) {
            addCriterion("SIJI_METHOD >", value, "SIJI_METHOD");
            return (Criteria) this;
        }

        public Criteria andSIJI_METHODGreaterThanOrEqualTo(String value) {
            addCriterion("SIJI_METHOD >=", value, "SIJI_METHOD");
            return (Criteria) this;
        }

        public Criteria andSIJI_METHODLessThan(String value) {
            addCriterion("SIJI_METHOD <", value, "SIJI_METHOD");
            return (Criteria) this;
        }

        public Criteria andSIJI_METHODLessThanOrEqualTo(String value) {
            addCriterion("SIJI_METHOD <=", value, "SIJI_METHOD");
            return (Criteria) this;
        }

        public Criteria andSIJI_METHODLike(String value) {
            addCriterion("SIJI_METHOD like", value, "SIJI_METHOD");
            return (Criteria) this;
        }

        public Criteria andSIJI_METHODNotLike(String value) {
            addCriterion("SIJI_METHOD not like", value, "SIJI_METHOD");
            return (Criteria) this;
        }

        public Criteria andSIJI_METHODIn(List<String> values) {
            addCriterion("SIJI_METHOD in", values, "SIJI_METHOD");
            return (Criteria) this;
        }

        public Criteria andSIJI_METHODNotIn(List<String> values) {
            addCriterion("SIJI_METHOD not in", values, "SIJI_METHOD");
            return (Criteria) this;
        }

        public Criteria andSIJI_METHODBetween(String value1, String value2) {
            addCriterion("SIJI_METHOD between", value1, value2, "SIJI_METHOD");
            return (Criteria) this;
        }

        public Criteria andSIJI_METHODNotBetween(String value1, String value2) {
            addCriterion("SIJI_METHOD not between", value1, value2, "SIJI_METHOD");
            return (Criteria) this;
        }

        public Criteria andSIJIIsNull() {
            addCriterion("SIJI is null");
            return (Criteria) this;
        }

        public Criteria andSIJIIsNotNull() {
            addCriterion("SIJI is not null");
            return (Criteria) this;
        }

        public Criteria andSIJIEqualTo(String value) {
            addCriterion("SIJI =", value, "SIJI");
            return (Criteria) this;
        }

        public Criteria andSIJINotEqualTo(String value) {
            addCriterion("SIJI <>", value, "SIJI");
            return (Criteria) this;
        }

        public Criteria andSIJIGreaterThan(String value) {
            addCriterion("SIJI >", value, "SIJI");
            return (Criteria) this;
        }

        public Criteria andSIJIGreaterThanOrEqualTo(String value) {
            addCriterion("SIJI >=", value, "SIJI");
            return (Criteria) this;
        }

        public Criteria andSIJILessThan(String value) {
            addCriterion("SIJI <", value, "SIJI");
            return (Criteria) this;
        }

        public Criteria andSIJILessThanOrEqualTo(String value) {
            addCriterion("SIJI <=", value, "SIJI");
            return (Criteria) this;
        }

        public Criteria andSIJILike(String value) {
            addCriterion("SIJI like", value, "SIJI");
            return (Criteria) this;
        }

        public Criteria andSIJINotLike(String value) {
            addCriterion("SIJI not like", value, "SIJI");
            return (Criteria) this;
        }

        public Criteria andSIJIIn(List<String> values) {
            addCriterion("SIJI in", values, "SIJI");
            return (Criteria) this;
        }

        public Criteria andSIJINotIn(List<String> values) {
            addCriterion("SIJI not in", values, "SIJI");
            return (Criteria) this;
        }

        public Criteria andSIJIBetween(String value1, String value2) {
            addCriterion("SIJI between", value1, value2, "SIJI");
            return (Criteria) this;
        }

        public Criteria andSIJINotBetween(String value1, String value2) {
            addCriterion("SIJI not between", value1, value2, "SIJI");
            return (Criteria) this;
        }

        public Criteria andCHOKKOUIsNull() {
            addCriterion("CHOKKOU is null");
            return (Criteria) this;
        }

        public Criteria andCHOKKOUIsNotNull() {
            addCriterion("CHOKKOU is not null");
            return (Criteria) this;
        }

        public Criteria andCHOKKOUEqualTo(String value) {
            addCriterion("CHOKKOU =", value, "CHOKKOU");
            return (Criteria) this;
        }

        public Criteria andCHOKKOUNotEqualTo(String value) {
            addCriterion("CHOKKOU <>", value, "CHOKKOU");
            return (Criteria) this;
        }

        public Criteria andCHOKKOUGreaterThan(String value) {
            addCriterion("CHOKKOU >", value, "CHOKKOU");
            return (Criteria) this;
        }

        public Criteria andCHOKKOUGreaterThanOrEqualTo(String value) {
            addCriterion("CHOKKOU >=", value, "CHOKKOU");
            return (Criteria) this;
        }

        public Criteria andCHOKKOULessThan(String value) {
            addCriterion("CHOKKOU <", value, "CHOKKOU");
            return (Criteria) this;
        }

        public Criteria andCHOKKOULessThanOrEqualTo(String value) {
            addCriterion("CHOKKOU <=", value, "CHOKKOU");
            return (Criteria) this;
        }

        public Criteria andCHOKKOULike(String value) {
            addCriterion("CHOKKOU like", value, "CHOKKOU");
            return (Criteria) this;
        }

        public Criteria andCHOKKOUNotLike(String value) {
            addCriterion("CHOKKOU not like", value, "CHOKKOU");
            return (Criteria) this;
        }

        public Criteria andCHOKKOUIn(List<String> values) {
            addCriterion("CHOKKOU in", values, "CHOKKOU");
            return (Criteria) this;
        }

        public Criteria andCHOKKOUNotIn(List<String> values) {
            addCriterion("CHOKKOU not in", values, "CHOKKOU");
            return (Criteria) this;
        }

        public Criteria andCHOKKOUBetween(String value1, String value2) {
            addCriterion("CHOKKOU between", value1, value2, "CHOKKOU");
            return (Criteria) this;
        }

        public Criteria andCHOKKOUNotBetween(String value1, String value2) {
            addCriterion("CHOKKOU not between", value1, value2, "CHOKKOU");
            return (Criteria) this;
        }

        public Criteria andMIKOMIIsNull() {
            addCriterion("MIKOMI is null");
            return (Criteria) this;
        }

        public Criteria andMIKOMIIsNotNull() {
            addCriterion("MIKOMI is not null");
            return (Criteria) this;
        }

        public Criteria andMIKOMIEqualTo(String value) {
            addCriterion("MIKOMI =", value, "MIKOMI");
            return (Criteria) this;
        }

        public Criteria andMIKOMINotEqualTo(String value) {
            addCriterion("MIKOMI <>", value, "MIKOMI");
            return (Criteria) this;
        }

        public Criteria andMIKOMIGreaterThan(String value) {
            addCriterion("MIKOMI >", value, "MIKOMI");
            return (Criteria) this;
        }

        public Criteria andMIKOMIGreaterThanOrEqualTo(String value) {
            addCriterion("MIKOMI >=", value, "MIKOMI");
            return (Criteria) this;
        }

        public Criteria andMIKOMILessThan(String value) {
            addCriterion("MIKOMI <", value, "MIKOMI");
            return (Criteria) this;
        }

        public Criteria andMIKOMILessThanOrEqualTo(String value) {
            addCriterion("MIKOMI <=", value, "MIKOMI");
            return (Criteria) this;
        }

        public Criteria andMIKOMILike(String value) {
            addCriterion("MIKOMI like", value, "MIKOMI");
            return (Criteria) this;
        }

        public Criteria andMIKOMINotLike(String value) {
            addCriterion("MIKOMI not like", value, "MIKOMI");
            return (Criteria) this;
        }

        public Criteria andMIKOMIIn(List<String> values) {
            addCriterion("MIKOMI in", values, "MIKOMI");
            return (Criteria) this;
        }

        public Criteria andMIKOMINotIn(List<String> values) {
            addCriterion("MIKOMI not in", values, "MIKOMI");
            return (Criteria) this;
        }

        public Criteria andMIKOMIBetween(String value1, String value2) {
            addCriterion("MIKOMI between", value1, value2, "MIKOMI");
            return (Criteria) this;
        }

        public Criteria andMIKOMINotBetween(String value1, String value2) {
            addCriterion("MIKOMI not between", value1, value2, "MIKOMI");
            return (Criteria) this;
        }

        public Criteria andGENCHAKUIsNull() {
            addCriterion("GENCHAKU is null");
            return (Criteria) this;
        }

        public Criteria andGENCHAKUIsNotNull() {
            addCriterion("GENCHAKU is not null");
            return (Criteria) this;
        }

        public Criteria andGENCHAKUEqualTo(String value) {
            addCriterion("GENCHAKU =", value, "GENCHAKU");
            return (Criteria) this;
        }

        public Criteria andGENCHAKUNotEqualTo(String value) {
            addCriterion("GENCHAKU <>", value, "GENCHAKU");
            return (Criteria) this;
        }

        public Criteria andGENCHAKUGreaterThan(String value) {
            addCriterion("GENCHAKU >", value, "GENCHAKU");
            return (Criteria) this;
        }

        public Criteria andGENCHAKUGreaterThanOrEqualTo(String value) {
            addCriterion("GENCHAKU >=", value, "GENCHAKU");
            return (Criteria) this;
        }

        public Criteria andGENCHAKULessThan(String value) {
            addCriterion("GENCHAKU <", value, "GENCHAKU");
            return (Criteria) this;
        }

        public Criteria andGENCHAKULessThanOrEqualTo(String value) {
            addCriterion("GENCHAKU <=", value, "GENCHAKU");
            return (Criteria) this;
        }

        public Criteria andGENCHAKULike(String value) {
            addCriterion("GENCHAKU like", value, "GENCHAKU");
            return (Criteria) this;
        }

        public Criteria andGENCHAKUNotLike(String value) {
            addCriterion("GENCHAKU not like", value, "GENCHAKU");
            return (Criteria) this;
        }

        public Criteria andGENCHAKUIn(List<String> values) {
            addCriterion("GENCHAKU in", values, "GENCHAKU");
            return (Criteria) this;
        }

        public Criteria andGENCHAKUNotIn(List<String> values) {
            addCriterion("GENCHAKU not in", values, "GENCHAKU");
            return (Criteria) this;
        }

        public Criteria andGENCHAKUBetween(String value1, String value2) {
            addCriterion("GENCHAKU between", value1, value2, "GENCHAKU");
            return (Criteria) this;
        }

        public Criteria andGENCHAKUNotBetween(String value1, String value2) {
            addCriterion("GENCHAKU not between", value1, value2, "GENCHAKU");
            return (Criteria) this;
        }

        public Criteria andSYOYOUIsNull() {
            addCriterion("SYOYOU is null");
            return (Criteria) this;
        }

        public Criteria andSYOYOUIsNotNull() {
            addCriterion("SYOYOU is not null");
            return (Criteria) this;
        }

        public Criteria andSYOYOUEqualTo(String value) {
            addCriterion("SYOYOU =", value, "SYOYOU");
            return (Criteria) this;
        }

        public Criteria andSYOYOUNotEqualTo(String value) {
            addCriterion("SYOYOU <>", value, "SYOYOU");
            return (Criteria) this;
        }

        public Criteria andSYOYOUGreaterThan(String value) {
            addCriterion("SYOYOU >", value, "SYOYOU");
            return (Criteria) this;
        }

        public Criteria andSYOYOUGreaterThanOrEqualTo(String value) {
            addCriterion("SYOYOU >=", value, "SYOYOU");
            return (Criteria) this;
        }

        public Criteria andSYOYOULessThan(String value) {
            addCriterion("SYOYOU <", value, "SYOYOU");
            return (Criteria) this;
        }

        public Criteria andSYOYOULessThanOrEqualTo(String value) {
            addCriterion("SYOYOU <=", value, "SYOYOU");
            return (Criteria) this;
        }

        public Criteria andSYOYOULike(String value) {
            addCriterion("SYOYOU like", value, "SYOYOU");
            return (Criteria) this;
        }

        public Criteria andSYOYOUNotLike(String value) {
            addCriterion("SYOYOU not like", value, "SYOYOU");
            return (Criteria) this;
        }

        public Criteria andSYOYOUIn(List<String> values) {
            addCriterion("SYOYOU in", values, "SYOYOU");
            return (Criteria) this;
        }

        public Criteria andSYOYOUNotIn(List<String> values) {
            addCriterion("SYOYOU not in", values, "SYOYOU");
            return (Criteria) this;
        }

        public Criteria andSYOYOUBetween(String value1, String value2) {
            addCriterion("SYOYOU between", value1, value2, "SYOYOU");
            return (Criteria) this;
        }

        public Criteria andSYOYOUNotBetween(String value1, String value2) {
            addCriterion("SYOYOU not between", value1, value2, "SYOYOU");
            return (Criteria) this;
        }

        public Criteria andNYUUKANIsNull() {
            addCriterion("NYUUKAN is null");
            return (Criteria) this;
        }

        public Criteria andNYUUKANIsNotNull() {
            addCriterion("NYUUKAN is not null");
            return (Criteria) this;
        }

        public Criteria andNYUUKANEqualTo(String value) {
            addCriterion("NYUUKAN =", value, "NYUUKAN");
            return (Criteria) this;
        }

        public Criteria andNYUUKANNotEqualTo(String value) {
            addCriterion("NYUUKAN <>", value, "NYUUKAN");
            return (Criteria) this;
        }

        public Criteria andNYUUKANGreaterThan(String value) {
            addCriterion("NYUUKAN >", value, "NYUUKAN");
            return (Criteria) this;
        }

        public Criteria andNYUUKANGreaterThanOrEqualTo(String value) {
            addCriterion("NYUUKAN >=", value, "NYUUKAN");
            return (Criteria) this;
        }

        public Criteria andNYUUKANLessThan(String value) {
            addCriterion("NYUUKAN <", value, "NYUUKAN");
            return (Criteria) this;
        }

        public Criteria andNYUUKANLessThanOrEqualTo(String value) {
            addCriterion("NYUUKAN <=", value, "NYUUKAN");
            return (Criteria) this;
        }

        public Criteria andNYUUKANLike(String value) {
            addCriterion("NYUUKAN like", value, "NYUUKAN");
            return (Criteria) this;
        }

        public Criteria andNYUUKANNotLike(String value) {
            addCriterion("NYUUKAN not like", value, "NYUUKAN");
            return (Criteria) this;
        }

        public Criteria andNYUUKANIn(List<String> values) {
            addCriterion("NYUUKAN in", values, "NYUUKAN");
            return (Criteria) this;
        }

        public Criteria andNYUUKANNotIn(List<String> values) {
            addCriterion("NYUUKAN not in", values, "NYUUKAN");
            return (Criteria) this;
        }

        public Criteria andNYUUKANBetween(String value1, String value2) {
            addCriterion("NYUUKAN between", value1, value2, "NYUUKAN");
            return (Criteria) this;
        }

        public Criteria andNYUUKANNotBetween(String value1, String value2) {
            addCriterion("NYUUKAN not between", value1, value2, "NYUUKAN");
            return (Criteria) this;
        }

        public Criteria andTAIKANIsNull() {
            addCriterion("TAIKAN is null");
            return (Criteria) this;
        }

        public Criteria andTAIKANIsNotNull() {
            addCriterion("TAIKAN is not null");
            return (Criteria) this;
        }

        public Criteria andTAIKANEqualTo(String value) {
            addCriterion("TAIKAN =", value, "TAIKAN");
            return (Criteria) this;
        }

        public Criteria andTAIKANNotEqualTo(String value) {
            addCriterion("TAIKAN <>", value, "TAIKAN");
            return (Criteria) this;
        }

        public Criteria andTAIKANGreaterThan(String value) {
            addCriterion("TAIKAN >", value, "TAIKAN");
            return (Criteria) this;
        }

        public Criteria andTAIKANGreaterThanOrEqualTo(String value) {
            addCriterion("TAIKAN >=", value, "TAIKAN");
            return (Criteria) this;
        }

        public Criteria andTAIKANLessThan(String value) {
            addCriterion("TAIKAN <", value, "TAIKAN");
            return (Criteria) this;
        }

        public Criteria andTAIKANLessThanOrEqualTo(String value) {
            addCriterion("TAIKAN <=", value, "TAIKAN");
            return (Criteria) this;
        }

        public Criteria andTAIKANLike(String value) {
            addCriterion("TAIKAN like", value, "TAIKAN");
            return (Criteria) this;
        }

        public Criteria andTAIKANNotLike(String value) {
            addCriterion("TAIKAN not like", value, "TAIKAN");
            return (Criteria) this;
        }

        public Criteria andTAIKANIn(List<String> values) {
            addCriterion("TAIKAN in", values, "TAIKAN");
            return (Criteria) this;
        }

        public Criteria andTAIKANNotIn(List<String> values) {
            addCriterion("TAIKAN not in", values, "TAIKAN");
            return (Criteria) this;
        }

        public Criteria andTAIKANBetween(String value1, String value2) {
            addCriterion("TAIKAN between", value1, value2, "TAIKAN");
            return (Criteria) this;
        }

        public Criteria andTAIKANNotBetween(String value1, String value2) {
            addCriterion("TAIKAN not between", value1, value2, "TAIKAN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNIsNull() {
            addCriterion("TAIKAN_KBN is null");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNIsNotNull() {
            addCriterion("TAIKAN_KBN is not null");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNEqualTo(String value) {
            addCriterion("TAIKAN_KBN =", value, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNNotEqualTo(String value) {
            addCriterion("TAIKAN_KBN <>", value, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNGreaterThan(String value) {
            addCriterion("TAIKAN_KBN >", value, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNGreaterThanOrEqualTo(String value) {
            addCriterion("TAIKAN_KBN >=", value, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNLessThan(String value) {
            addCriterion("TAIKAN_KBN <", value, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNLessThanOrEqualTo(String value) {
            addCriterion("TAIKAN_KBN <=", value, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNLike(String value) {
            addCriterion("TAIKAN_KBN like", value, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNNotLike(String value) {
            addCriterion("TAIKAN_KBN not like", value, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNIn(List<String> values) {
            addCriterion("TAIKAN_KBN in", values, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNNotIn(List<String> values) {
            addCriterion("TAIKAN_KBN not in", values, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNBetween(String value1, String value2) {
            addCriterion("TAIKAN_KBN between", value1, value2, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNNotBetween(String value1, String value2) {
            addCriterion("TAIKAN_KBN not between", value1, value2, "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andINTERRUPTIsNull() {
            addCriterion("INTERRUPT is null");
            return (Criteria) this;
        }

        public Criteria andINTERRUPTIsNotNull() {
            addCriterion("INTERRUPT is not null");
            return (Criteria) this;
        }

        public Criteria andINTERRUPTEqualTo(String value) {
            addCriterion("INTERRUPT =", value, "INTERRUPT");
            return (Criteria) this;
        }

        public Criteria andINTERRUPTNotEqualTo(String value) {
            addCriterion("INTERRUPT <>", value, "INTERRUPT");
            return (Criteria) this;
        }

        public Criteria andINTERRUPTGreaterThan(String value) {
            addCriterion("INTERRUPT >", value, "INTERRUPT");
            return (Criteria) this;
        }

        public Criteria andINTERRUPTGreaterThanOrEqualTo(String value) {
            addCriterion("INTERRUPT >=", value, "INTERRUPT");
            return (Criteria) this;
        }

        public Criteria andINTERRUPTLessThan(String value) {
            addCriterion("INTERRUPT <", value, "INTERRUPT");
            return (Criteria) this;
        }

        public Criteria andINTERRUPTLessThanOrEqualTo(String value) {
            addCriterion("INTERRUPT <=", value, "INTERRUPT");
            return (Criteria) this;
        }

        public Criteria andINTERRUPTLike(String value) {
            addCriterion("INTERRUPT like", value, "INTERRUPT");
            return (Criteria) this;
        }

        public Criteria andINTERRUPTNotLike(String value) {
            addCriterion("INTERRUPT not like", value, "INTERRUPT");
            return (Criteria) this;
        }

        public Criteria andINTERRUPTIn(List<String> values) {
            addCriterion("INTERRUPT in", values, "INTERRUPT");
            return (Criteria) this;
        }

        public Criteria andINTERRUPTNotIn(List<String> values) {
            addCriterion("INTERRUPT not in", values, "INTERRUPT");
            return (Criteria) this;
        }

        public Criteria andINTERRUPTBetween(String value1, String value2) {
            addCriterion("INTERRUPT between", value1, value2, "INTERRUPT");
            return (Criteria) this;
        }

        public Criteria andINTERRUPTNotBetween(String value1, String value2) {
            addCriterion("INTERRUPT not between", value1, value2, "INTERRUPT");
            return (Criteria) this;
        }

        public Criteria andINTERRUPT_CANCELIsNull() {
            addCriterion("INTERRUPT_CANCEL is null");
            return (Criteria) this;
        }

        public Criteria andINTERRUPT_CANCELIsNotNull() {
            addCriterion("INTERRUPT_CANCEL is not null");
            return (Criteria) this;
        }

        public Criteria andINTERRUPT_CANCELEqualTo(String value) {
            addCriterion("INTERRUPT_CANCEL =", value, "INTERRUPT_CANCEL");
            return (Criteria) this;
        }

        public Criteria andINTERRUPT_CANCELNotEqualTo(String value) {
            addCriterion("INTERRUPT_CANCEL <>", value, "INTERRUPT_CANCEL");
            return (Criteria) this;
        }

        public Criteria andINTERRUPT_CANCELGreaterThan(String value) {
            addCriterion("INTERRUPT_CANCEL >", value, "INTERRUPT_CANCEL");
            return (Criteria) this;
        }

        public Criteria andINTERRUPT_CANCELGreaterThanOrEqualTo(String value) {
            addCriterion("INTERRUPT_CANCEL >=", value, "INTERRUPT_CANCEL");
            return (Criteria) this;
        }

        public Criteria andINTERRUPT_CANCELLessThan(String value) {
            addCriterion("INTERRUPT_CANCEL <", value, "INTERRUPT_CANCEL");
            return (Criteria) this;
        }

        public Criteria andINTERRUPT_CANCELLessThanOrEqualTo(String value) {
            addCriterion("INTERRUPT_CANCEL <=", value, "INTERRUPT_CANCEL");
            return (Criteria) this;
        }

        public Criteria andINTERRUPT_CANCELLike(String value) {
            addCriterion("INTERRUPT_CANCEL like", value, "INTERRUPT_CANCEL");
            return (Criteria) this;
        }

        public Criteria andINTERRUPT_CANCELNotLike(String value) {
            addCriterion("INTERRUPT_CANCEL not like", value, "INTERRUPT_CANCEL");
            return (Criteria) this;
        }

        public Criteria andINTERRUPT_CANCELIn(List<String> values) {
            addCriterion("INTERRUPT_CANCEL in", values, "INTERRUPT_CANCEL");
            return (Criteria) this;
        }

        public Criteria andINTERRUPT_CANCELNotIn(List<String> values) {
            addCriterion("INTERRUPT_CANCEL not in", values, "INTERRUPT_CANCEL");
            return (Criteria) this;
        }

        public Criteria andINTERRUPT_CANCELBetween(String value1, String value2) {
            addCriterion("INTERRUPT_CANCEL between", value1, value2, "INTERRUPT_CANCEL");
            return (Criteria) this;
        }

        public Criteria andINTERRUPT_CANCELNotBetween(String value1, String value2) {
            addCriterion("INTERRUPT_CANCEL not between", value1, value2, "INTERRUPT_CANCEL");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEIIsNull() {
            addCriterion("OUEN_YOUSEI is null");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEIIsNotNull() {
            addCriterion("OUEN_YOUSEI is not null");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEIEqualTo(String value) {
            addCriterion("OUEN_YOUSEI =", value, "OUEN_YOUSEI");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEINotEqualTo(String value) {
            addCriterion("OUEN_YOUSEI <>", value, "OUEN_YOUSEI");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEIGreaterThan(String value) {
            addCriterion("OUEN_YOUSEI >", value, "OUEN_YOUSEI");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEIGreaterThanOrEqualTo(String value) {
            addCriterion("OUEN_YOUSEI >=", value, "OUEN_YOUSEI");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEILessThan(String value) {
            addCriterion("OUEN_YOUSEI <", value, "OUEN_YOUSEI");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEILessThanOrEqualTo(String value) {
            addCriterion("OUEN_YOUSEI <=", value, "OUEN_YOUSEI");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEILike(String value) {
            addCriterion("OUEN_YOUSEI like", value, "OUEN_YOUSEI");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEINotLike(String value) {
            addCriterion("OUEN_YOUSEI not like", value, "OUEN_YOUSEI");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEIIn(List<String> values) {
            addCriterion("OUEN_YOUSEI in", values, "OUEN_YOUSEI");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEINotIn(List<String> values) {
            addCriterion("OUEN_YOUSEI not in", values, "OUEN_YOUSEI");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEIBetween(String value1, String value2) {
            addCriterion("OUEN_YOUSEI between", value1, value2, "OUEN_YOUSEI");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEINotBetween(String value1, String value2) {
            addCriterion("OUEN_YOUSEI not between", value1, value2, "OUEN_YOUSEI");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEI_CANCELIsNull() {
            addCriterion("OUEN_YOUSEI_CANCEL is null");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEI_CANCELIsNotNull() {
            addCriterion("OUEN_YOUSEI_CANCEL is not null");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEI_CANCELEqualTo(String value) {
            addCriterion("OUEN_YOUSEI_CANCEL =", value, "OUEN_YOUSEI_CANCEL");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEI_CANCELNotEqualTo(String value) {
            addCriterion("OUEN_YOUSEI_CANCEL <>", value, "OUEN_YOUSEI_CANCEL");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEI_CANCELGreaterThan(String value) {
            addCriterion("OUEN_YOUSEI_CANCEL >", value, "OUEN_YOUSEI_CANCEL");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEI_CANCELGreaterThanOrEqualTo(String value) {
            addCriterion("OUEN_YOUSEI_CANCEL >=", value, "OUEN_YOUSEI_CANCEL");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEI_CANCELLessThan(String value) {
            addCriterion("OUEN_YOUSEI_CANCEL <", value, "OUEN_YOUSEI_CANCEL");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEI_CANCELLessThanOrEqualTo(String value) {
            addCriterion("OUEN_YOUSEI_CANCEL <=", value, "OUEN_YOUSEI_CANCEL");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEI_CANCELLike(String value) {
            addCriterion("OUEN_YOUSEI_CANCEL like", value, "OUEN_YOUSEI_CANCEL");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEI_CANCELNotLike(String value) {
            addCriterion("OUEN_YOUSEI_CANCEL not like", value, "OUEN_YOUSEI_CANCEL");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEI_CANCELIn(List<String> values) {
            addCriterion("OUEN_YOUSEI_CANCEL in", values, "OUEN_YOUSEI_CANCEL");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEI_CANCELNotIn(List<String> values) {
            addCriterion("OUEN_YOUSEI_CANCEL not in", values, "OUEN_YOUSEI_CANCEL");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEI_CANCELBetween(String value1, String value2) {
            addCriterion("OUEN_YOUSEI_CANCEL between", value1, value2, "OUEN_YOUSEI_CANCEL");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEI_CANCELNotBetween(String value1, String value2) {
            addCriterion("OUEN_YOUSEI_CANCEL not between", value1, value2, "OUEN_YOUSEI_CANCEL");
            return (Criteria) this;
        }

        public Criteria andENDIsNull() {
            addCriterion("END is null");
            return (Criteria) this;
        }

        public Criteria andENDIsNotNull() {
            addCriterion("END is not null");
            return (Criteria) this;
        }

        public Criteria andENDEqualTo(String value) {
            addCriterion("END =", value, "END");
            return (Criteria) this;
        }

        public Criteria andENDNotEqualTo(String value) {
            addCriterion("END <>", value, "END");
            return (Criteria) this;
        }

        public Criteria andENDGreaterThan(String value) {
            addCriterion("END >", value, "END");
            return (Criteria) this;
        }

        public Criteria andENDGreaterThanOrEqualTo(String value) {
            addCriterion("END >=", value, "END");
            return (Criteria) this;
        }

        public Criteria andENDLessThan(String value) {
            addCriterion("END <", value, "END");
            return (Criteria) this;
        }

        public Criteria andENDLessThanOrEqualTo(String value) {
            addCriterion("END <=", value, "END");
            return (Criteria) this;
        }

        public Criteria andENDLike(String value) {
            addCriterion("END like", value, "END");
            return (Criteria) this;
        }

        public Criteria andENDNotLike(String value) {
            addCriterion("END not like", value, "END");
            return (Criteria) this;
        }

        public Criteria andENDIn(List<String> values) {
            addCriterion("END in", values, "END");
            return (Criteria) this;
        }

        public Criteria andENDNotIn(List<String> values) {
            addCriterion("END not in", values, "END");
            return (Criteria) this;
        }

        public Criteria andENDBetween(String value1, String value2) {
            addCriterion("END between", value1, value2, "END");
            return (Criteria) this;
        }

        public Criteria andENDNotBetween(String value1, String value2) {
            addCriterion("END not between", value1, value2, "END");
            return (Criteria) this;
        }

        public Criteria andCANCELIsNull() {
            addCriterion("CANCEL is null");
            return (Criteria) this;
        }

        public Criteria andCANCELIsNotNull() {
            addCriterion("CANCEL is not null");
            return (Criteria) this;
        }

        public Criteria andCANCELEqualTo(String value) {
            addCriterion("CANCEL =", value, "CANCEL");
            return (Criteria) this;
        }

        public Criteria andCANCELNotEqualTo(String value) {
            addCriterion("CANCEL <>", value, "CANCEL");
            return (Criteria) this;
        }

        public Criteria andCANCELGreaterThan(String value) {
            addCriterion("CANCEL >", value, "CANCEL");
            return (Criteria) this;
        }

        public Criteria andCANCELGreaterThanOrEqualTo(String value) {
            addCriterion("CANCEL >=", value, "CANCEL");
            return (Criteria) this;
        }

        public Criteria andCANCELLessThan(String value) {
            addCriterion("CANCEL <", value, "CANCEL");
            return (Criteria) this;
        }

        public Criteria andCANCELLessThanOrEqualTo(String value) {
            addCriterion("CANCEL <=", value, "CANCEL");
            return (Criteria) this;
        }

        public Criteria andCANCELLike(String value) {
            addCriterion("CANCEL like", value, "CANCEL");
            return (Criteria) this;
        }

        public Criteria andCANCELNotLike(String value) {
            addCriterion("CANCEL not like", value, "CANCEL");
            return (Criteria) this;
        }

        public Criteria andCANCELIn(List<String> values) {
            addCriterion("CANCEL in", values, "CANCEL");
            return (Criteria) this;
        }

        public Criteria andCANCELNotIn(List<String> values) {
            addCriterion("CANCEL not in", values, "CANCEL");
            return (Criteria) this;
        }

        public Criteria andCANCELBetween(String value1, String value2) {
            addCriterion("CANCEL between", value1, value2, "CANCEL");
            return (Criteria) this;
        }

        public Criteria andCANCELNotBetween(String value1, String value2) {
            addCriterion("CANCEL not between", value1, value2, "CANCEL");
            return (Criteria) this;
        }

        public Criteria andRTRNIsNull() {
            addCriterion("RTRN is null");
            return (Criteria) this;
        }

        public Criteria andRTRNIsNotNull() {
            addCriterion("RTRN is not null");
            return (Criteria) this;
        }

        public Criteria andRTRNEqualTo(String value) {
            addCriterion("RTRN =", value, "RTRN");
            return (Criteria) this;
        }

        public Criteria andRTRNNotEqualTo(String value) {
            addCriterion("RTRN <>", value, "RTRN");
            return (Criteria) this;
        }

        public Criteria andRTRNGreaterThan(String value) {
            addCriterion("RTRN >", value, "RTRN");
            return (Criteria) this;
        }

        public Criteria andRTRNGreaterThanOrEqualTo(String value) {
            addCriterion("RTRN >=", value, "RTRN");
            return (Criteria) this;
        }

        public Criteria andRTRNLessThan(String value) {
            addCriterion("RTRN <", value, "RTRN");
            return (Criteria) this;
        }

        public Criteria andRTRNLessThanOrEqualTo(String value) {
            addCriterion("RTRN <=", value, "RTRN");
            return (Criteria) this;
        }

        public Criteria andRTRNLike(String value) {
            addCriterion("RTRN like", value, "RTRN");
            return (Criteria) this;
        }

        public Criteria andRTRNNotLike(String value) {
            addCriterion("RTRN not like", value, "RTRN");
            return (Criteria) this;
        }

        public Criteria andRTRNIn(List<String> values) {
            addCriterion("RTRN in", values, "RTRN");
            return (Criteria) this;
        }

        public Criteria andRTRNNotIn(List<String> values) {
            addCriterion("RTRN not in", values, "RTRN");
            return (Criteria) this;
        }

        public Criteria andRTRNBetween(String value1, String value2) {
            addCriterion("RTRN between", value1, value2, "RTRN");
            return (Criteria) this;
        }

        public Criteria andRTRNNotBetween(String value1, String value2) {
            addCriterion("RTRN not between", value1, value2, "RTRN");
            return (Criteria) this;
        }

        public Criteria andTAIKISYO_CDIsNull() {
            addCriterion("TAIKISYO_CD is null");
            return (Criteria) this;
        }

        public Criteria andTAIKISYO_CDIsNotNull() {
            addCriterion("TAIKISYO_CD is not null");
            return (Criteria) this;
        }

        public Criteria andTAIKISYO_CDEqualTo(String value) {
            addCriterion("TAIKISYO_CD =", value, "TAIKISYO_CD");
            return (Criteria) this;
        }

        public Criteria andTAIKISYO_CDNotEqualTo(String value) {
            addCriterion("TAIKISYO_CD <>", value, "TAIKISYO_CD");
            return (Criteria) this;
        }

        public Criteria andTAIKISYO_CDGreaterThan(String value) {
            addCriterion("TAIKISYO_CD >", value, "TAIKISYO_CD");
            return (Criteria) this;
        }

        public Criteria andTAIKISYO_CDGreaterThanOrEqualTo(String value) {
            addCriterion("TAIKISYO_CD >=", value, "TAIKISYO_CD");
            return (Criteria) this;
        }

        public Criteria andTAIKISYO_CDLessThan(String value) {
            addCriterion("TAIKISYO_CD <", value, "TAIKISYO_CD");
            return (Criteria) this;
        }

        public Criteria andTAIKISYO_CDLessThanOrEqualTo(String value) {
            addCriterion("TAIKISYO_CD <=", value, "TAIKISYO_CD");
            return (Criteria) this;
        }

        public Criteria andTAIKISYO_CDLike(String value) {
            addCriterion("TAIKISYO_CD like", value, "TAIKISYO_CD");
            return (Criteria) this;
        }

        public Criteria andTAIKISYO_CDNotLike(String value) {
            addCriterion("TAIKISYO_CD not like", value, "TAIKISYO_CD");
            return (Criteria) this;
        }

        public Criteria andTAIKISYO_CDIn(List<String> values) {
            addCriterion("TAIKISYO_CD in", values, "TAIKISYO_CD");
            return (Criteria) this;
        }

        public Criteria andTAIKISYO_CDNotIn(List<String> values) {
            addCriterion("TAIKISYO_CD not in", values, "TAIKISYO_CD");
            return (Criteria) this;
        }

        public Criteria andTAIKISYO_CDBetween(String value1, String value2) {
            addCriterion("TAIKISYO_CD between", value1, value2, "TAIKISYO_CD");
            return (Criteria) this;
        }

        public Criteria andTAIKISYO_CDNotBetween(String value1, String value2) {
            addCriterion("TAIKISYO_CD not between", value1, value2, "TAIKISYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDIsNull() {
            addCriterion("JIGYO_CD is null");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDIsNotNull() {
            addCriterion("JIGYO_CD is not null");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDEqualTo(String value) {
            addCriterion("JIGYO_CD =", value, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDNotEqualTo(String value) {
            addCriterion("JIGYO_CD <>", value, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDGreaterThan(String value) {
            addCriterion("JIGYO_CD >", value, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDGreaterThanOrEqualTo(String value) {
            addCriterion("JIGYO_CD >=", value, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDLessThan(String value) {
            addCriterion("JIGYO_CD <", value, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDLessThanOrEqualTo(String value) {
            addCriterion("JIGYO_CD <=", value, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDLike(String value) {
            addCriterion("JIGYO_CD like", value, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDNotLike(String value) {
            addCriterion("JIGYO_CD not like", value, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDIn(List<String> values) {
            addCriterion("JIGYO_CD in", values, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDNotIn(List<String> values) {
            addCriterion("JIGYO_CD not in", values, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDBetween(String value1, String value2) {
            addCriterion("JIGYO_CD between", value1, value2, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDNotBetween(String value1, String value2) {
            addCriterion("JIGYO_CD not between", value1, value2, "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSIsNull() {
            addCriterion("SIG_HASSEI_TS is null");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSIsNotNull() {
            addCriterion("SIG_HASSEI_TS is not null");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSEqualTo(String value) {
            addCriterion("SIG_HASSEI_TS =", value, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSNotEqualTo(String value) {
            addCriterion("SIG_HASSEI_TS <>", value, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSGreaterThan(String value) {
            addCriterion("SIG_HASSEI_TS >", value, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSGreaterThanOrEqualTo(String value) {
            addCriterion("SIG_HASSEI_TS >=", value, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSLessThan(String value) {
            addCriterion("SIG_HASSEI_TS <", value, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSLessThanOrEqualTo(String value) {
            addCriterion("SIG_HASSEI_TS <=", value, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSLike(String value) {
            addCriterion("SIG_HASSEI_TS like", value, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSNotLike(String value) {
            addCriterion("SIG_HASSEI_TS not like", value, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSIn(List<String> values) {
            addCriterion("SIG_HASSEI_TS in", values, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSNotIn(List<String> values) {
            addCriterion("SIG_HASSEI_TS not in", values, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSBetween(String value1, String value2) {
            addCriterion("SIG_HASSEI_TS between", value1, value2, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSNotBetween(String value1, String value2) {
            addCriterion("SIG_HASSEI_TS not between", value1, value2, "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andTAIIN_JITAI_CDIsNull() {
            addCriterion("TAIIN_JITAI_CD is null");
            return (Criteria) this;
        }

        public Criteria andTAIIN_JITAI_CDIsNotNull() {
            addCriterion("TAIIN_JITAI_CD is not null");
            return (Criteria) this;
        }

        public Criteria andTAIIN_JITAI_CDEqualTo(String value) {
            addCriterion("TAIIN_JITAI_CD =", value, "TAIIN_JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andTAIIN_JITAI_CDNotEqualTo(String value) {
            addCriterion("TAIIN_JITAI_CD <>", value, "TAIIN_JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andTAIIN_JITAI_CDGreaterThan(String value) {
            addCriterion("TAIIN_JITAI_CD >", value, "TAIIN_JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andTAIIN_JITAI_CDGreaterThanOrEqualTo(String value) {
            addCriterion("TAIIN_JITAI_CD >=", value, "TAIIN_JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andTAIIN_JITAI_CDLessThan(String value) {
            addCriterion("TAIIN_JITAI_CD <", value, "TAIIN_JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andTAIIN_JITAI_CDLessThanOrEqualTo(String value) {
            addCriterion("TAIIN_JITAI_CD <=", value, "TAIIN_JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andTAIIN_JITAI_CDLike(String value) {
            addCriterion("TAIIN_JITAI_CD like", value, "TAIIN_JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andTAIIN_JITAI_CDNotLike(String value) {
            addCriterion("TAIIN_JITAI_CD not like", value, "TAIIN_JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andTAIIN_JITAI_CDIn(List<String> values) {
            addCriterion("TAIIN_JITAI_CD in", values, "TAIIN_JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andTAIIN_JITAI_CDNotIn(List<String> values) {
            addCriterion("TAIIN_JITAI_CD not in", values, "TAIIN_JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andTAIIN_JITAI_CDBetween(String value1, String value2) {
            addCriterion("TAIIN_JITAI_CD between", value1, value2, "TAIIN_JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andTAIIN_JITAI_CDNotBetween(String value1, String value2) {
            addCriterion("TAIIN_JITAI_CD not between", value1, value2, "TAIIN_JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andKEY_SIJI_PRIORITYIsNull() {
            addCriterion("KEY_SIJI_PRIORITY is null");
            return (Criteria) this;
        }

        public Criteria andKEY_SIJI_PRIORITYIsNotNull() {
            addCriterion("KEY_SIJI_PRIORITY is not null");
            return (Criteria) this;
        }

        public Criteria andKEY_SIJI_PRIORITYEqualTo(String value) {
            addCriterion("KEY_SIJI_PRIORITY =", value, "KEY_SIJI_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andKEY_SIJI_PRIORITYNotEqualTo(String value) {
            addCriterion("KEY_SIJI_PRIORITY <>", value, "KEY_SIJI_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andKEY_SIJI_PRIORITYGreaterThan(String value) {
            addCriterion("KEY_SIJI_PRIORITY >", value, "KEY_SIJI_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andKEY_SIJI_PRIORITYGreaterThanOrEqualTo(String value) {
            addCriterion("KEY_SIJI_PRIORITY >=", value, "KEY_SIJI_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andKEY_SIJI_PRIORITYLessThan(String value) {
            addCriterion("KEY_SIJI_PRIORITY <", value, "KEY_SIJI_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andKEY_SIJI_PRIORITYLessThanOrEqualTo(String value) {
            addCriterion("KEY_SIJI_PRIORITY <=", value, "KEY_SIJI_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andKEY_SIJI_PRIORITYLike(String value) {
            addCriterion("KEY_SIJI_PRIORITY like", value, "KEY_SIJI_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andKEY_SIJI_PRIORITYNotLike(String value) {
            addCriterion("KEY_SIJI_PRIORITY not like", value, "KEY_SIJI_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andKEY_SIJI_PRIORITYIn(List<String> values) {
            addCriterion("KEY_SIJI_PRIORITY in", values, "KEY_SIJI_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andKEY_SIJI_PRIORITYNotIn(List<String> values) {
            addCriterion("KEY_SIJI_PRIORITY not in", values, "KEY_SIJI_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andKEY_SIJI_PRIORITYBetween(String value1, String value2) {
            addCriterion("KEY_SIJI_PRIORITY between", value1, value2, "KEY_SIJI_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andKEY_SIJI_PRIORITYNotBetween(String value1, String value2) {
            addCriterion("KEY_SIJI_PRIORITY not between", value1, value2, "KEY_SIJI_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andNO_KEY_SIJI_PRIORITYIsNull() {
            addCriterion("NO_KEY_SIJI_PRIORITY is null");
            return (Criteria) this;
        }

        public Criteria andNO_KEY_SIJI_PRIORITYIsNotNull() {
            addCriterion("NO_KEY_SIJI_PRIORITY is not null");
            return (Criteria) this;
        }

        public Criteria andNO_KEY_SIJI_PRIORITYEqualTo(String value) {
            addCriterion("NO_KEY_SIJI_PRIORITY =", value, "NO_KEY_SIJI_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andNO_KEY_SIJI_PRIORITYNotEqualTo(String value) {
            addCriterion("NO_KEY_SIJI_PRIORITY <>", value, "NO_KEY_SIJI_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andNO_KEY_SIJI_PRIORITYGreaterThan(String value) {
            addCriterion("NO_KEY_SIJI_PRIORITY >", value, "NO_KEY_SIJI_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andNO_KEY_SIJI_PRIORITYGreaterThanOrEqualTo(String value) {
            addCriterion("NO_KEY_SIJI_PRIORITY >=", value, "NO_KEY_SIJI_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andNO_KEY_SIJI_PRIORITYLessThan(String value) {
            addCriterion("NO_KEY_SIJI_PRIORITY <", value, "NO_KEY_SIJI_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andNO_KEY_SIJI_PRIORITYLessThanOrEqualTo(String value) {
            addCriterion("NO_KEY_SIJI_PRIORITY <=", value, "NO_KEY_SIJI_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andNO_KEY_SIJI_PRIORITYLike(String value) {
            addCriterion("NO_KEY_SIJI_PRIORITY like", value, "NO_KEY_SIJI_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andNO_KEY_SIJI_PRIORITYNotLike(String value) {
            addCriterion("NO_KEY_SIJI_PRIORITY not like", value, "NO_KEY_SIJI_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andNO_KEY_SIJI_PRIORITYIn(List<String> values) {
            addCriterion("NO_KEY_SIJI_PRIORITY in", values, "NO_KEY_SIJI_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andNO_KEY_SIJI_PRIORITYNotIn(List<String> values) {
            addCriterion("NO_KEY_SIJI_PRIORITY not in", values, "NO_KEY_SIJI_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andNO_KEY_SIJI_PRIORITYBetween(String value1, String value2) {
            addCriterion("NO_KEY_SIJI_PRIORITY between", value1, value2, "NO_KEY_SIJI_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andNO_KEY_SIJI_PRIORITYNotBetween(String value1, String value2) {
            addCriterion("NO_KEY_SIJI_PRIORITY not between", value1, value2, "NO_KEY_SIJI_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andJITAI_UPDATE_TSIsNull() {
            addCriterion("JITAI_UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andJITAI_UPDATE_TSIsNotNull() {
            addCriterion("JITAI_UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andJITAI_UPDATE_TSEqualTo(String value) {
            addCriterion("JITAI_UPDATE_TS =", value, "JITAI_UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andJITAI_UPDATE_TSNotEqualTo(String value) {
            addCriterion("JITAI_UPDATE_TS <>", value, "JITAI_UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andJITAI_UPDATE_TSGreaterThan(String value) {
            addCriterion("JITAI_UPDATE_TS >", value, "JITAI_UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andJITAI_UPDATE_TSGreaterThanOrEqualTo(String value) {
            addCriterion("JITAI_UPDATE_TS >=", value, "JITAI_UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andJITAI_UPDATE_TSLessThan(String value) {
            addCriterion("JITAI_UPDATE_TS <", value, "JITAI_UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andJITAI_UPDATE_TSLessThanOrEqualTo(String value) {
            addCriterion("JITAI_UPDATE_TS <=", value, "JITAI_UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andJITAI_UPDATE_TSLike(String value) {
            addCriterion("JITAI_UPDATE_TS like", value, "JITAI_UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andJITAI_UPDATE_TSNotLike(String value) {
            addCriterion("JITAI_UPDATE_TS not like", value, "JITAI_UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andJITAI_UPDATE_TSIn(List<String> values) {
            addCriterion("JITAI_UPDATE_TS in", values, "JITAI_UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andJITAI_UPDATE_TSNotIn(List<String> values) {
            addCriterion("JITAI_UPDATE_TS not in", values, "JITAI_UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andJITAI_UPDATE_TSBetween(String value1, String value2) {
            addCriterion("JITAI_UPDATE_TS between", value1, value2, "JITAI_UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andJITAI_UPDATE_TSNotBetween(String value1, String value2) {
            addCriterion("JITAI_UPDATE_TS not between", value1, value2, "JITAI_UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andNO_AUTO_UNYO_FLGIsNull() {
            addCriterion("NO_AUTO_UNYO_FLG is null");
            return (Criteria) this;
        }

        public Criteria andNO_AUTO_UNYO_FLGIsNotNull() {
            addCriterion("NO_AUTO_UNYO_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andNO_AUTO_UNYO_FLGEqualTo(String value) {
            addCriterion("NO_AUTO_UNYO_FLG =", value, "NO_AUTO_UNYO_FLG");
            return (Criteria) this;
        }

        public Criteria andNO_AUTO_UNYO_FLGNotEqualTo(String value) {
            addCriterion("NO_AUTO_UNYO_FLG <>", value, "NO_AUTO_UNYO_FLG");
            return (Criteria) this;
        }

        public Criteria andNO_AUTO_UNYO_FLGGreaterThan(String value) {
            addCriterion("NO_AUTO_UNYO_FLG >", value, "NO_AUTO_UNYO_FLG");
            return (Criteria) this;
        }

        public Criteria andNO_AUTO_UNYO_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("NO_AUTO_UNYO_FLG >=", value, "NO_AUTO_UNYO_FLG");
            return (Criteria) this;
        }

        public Criteria andNO_AUTO_UNYO_FLGLessThan(String value) {
            addCriterion("NO_AUTO_UNYO_FLG <", value, "NO_AUTO_UNYO_FLG");
            return (Criteria) this;
        }

        public Criteria andNO_AUTO_UNYO_FLGLessThanOrEqualTo(String value) {
            addCriterion("NO_AUTO_UNYO_FLG <=", value, "NO_AUTO_UNYO_FLG");
            return (Criteria) this;
        }

        public Criteria andNO_AUTO_UNYO_FLGLike(String value) {
            addCriterion("NO_AUTO_UNYO_FLG like", value, "NO_AUTO_UNYO_FLG");
            return (Criteria) this;
        }

        public Criteria andNO_AUTO_UNYO_FLGNotLike(String value) {
            addCriterion("NO_AUTO_UNYO_FLG not like", value, "NO_AUTO_UNYO_FLG");
            return (Criteria) this;
        }

        public Criteria andNO_AUTO_UNYO_FLGIn(List<String> values) {
            addCriterion("NO_AUTO_UNYO_FLG in", values, "NO_AUTO_UNYO_FLG");
            return (Criteria) this;
        }

        public Criteria andNO_AUTO_UNYO_FLGNotIn(List<String> values) {
            addCriterion("NO_AUTO_UNYO_FLG not in", values, "NO_AUTO_UNYO_FLG");
            return (Criteria) this;
        }

        public Criteria andNO_AUTO_UNYO_FLGBetween(String value1, String value2) {
            addCriterion("NO_AUTO_UNYO_FLG between", value1, value2, "NO_AUTO_UNYO_FLG");
            return (Criteria) this;
        }

        public Criteria andNO_AUTO_UNYO_FLGNotBetween(String value1, String value2) {
            addCriterion("NO_AUTO_UNYO_FLG not between", value1, value2, "NO_AUTO_UNYO_FLG");
            return (Criteria) this;
        }

        public Criteria andDOUKOUSYAIsNull() {
            addCriterion("DOUKOUSYA is null");
            return (Criteria) this;
        }

        public Criteria andDOUKOUSYAIsNotNull() {
            addCriterion("DOUKOUSYA is not null");
            return (Criteria) this;
        }

        public Criteria andDOUKOUSYAEqualTo(String value) {
            addCriterion("DOUKOUSYA =", value, "DOUKOUSYA");
            return (Criteria) this;
        }

        public Criteria andDOUKOUSYANotEqualTo(String value) {
            addCriterion("DOUKOUSYA <>", value, "DOUKOUSYA");
            return (Criteria) this;
        }

        public Criteria andDOUKOUSYAGreaterThan(String value) {
            addCriterion("DOUKOUSYA >", value, "DOUKOUSYA");
            return (Criteria) this;
        }

        public Criteria andDOUKOUSYAGreaterThanOrEqualTo(String value) {
            addCriterion("DOUKOUSYA >=", value, "DOUKOUSYA");
            return (Criteria) this;
        }

        public Criteria andDOUKOUSYALessThan(String value) {
            addCriterion("DOUKOUSYA <", value, "DOUKOUSYA");
            return (Criteria) this;
        }

        public Criteria andDOUKOUSYALessThanOrEqualTo(String value) {
            addCriterion("DOUKOUSYA <=", value, "DOUKOUSYA");
            return (Criteria) this;
        }

        public Criteria andDOUKOUSYALike(String value) {
            addCriterion("DOUKOUSYA like", value, "DOUKOUSYA");
            return (Criteria) this;
        }

        public Criteria andDOUKOUSYANotLike(String value) {
            addCriterion("DOUKOUSYA not like", value, "DOUKOUSYA");
            return (Criteria) this;
        }

        public Criteria andDOUKOUSYAIn(List<String> values) {
            addCriterion("DOUKOUSYA in", values, "DOUKOUSYA");
            return (Criteria) this;
        }

        public Criteria andDOUKOUSYANotIn(List<String> values) {
            addCriterion("DOUKOUSYA not in", values, "DOUKOUSYA");
            return (Criteria) this;
        }

        public Criteria andDOUKOUSYABetween(String value1, String value2) {
            addCriterion("DOUKOUSYA between", value1, value2, "DOUKOUSYA");
            return (Criteria) this;
        }

        public Criteria andDOUKOUSYANotBetween(String value1, String value2) {
            addCriterion("DOUKOUSYA not between", value1, value2, "DOUKOUSYA");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSIsNull() {
            addCriterion("LASTUPD_TS is null");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSIsNotNull() {
            addCriterion("LASTUPD_TS is not null");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSEqualTo(Date value) {
            addCriterion("LASTUPD_TS =", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSNotEqualTo(Date value) {
            addCriterion("LASTUPD_TS <>", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSGreaterThan(Date value) {
            addCriterion("LASTUPD_TS >", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("LASTUPD_TS >=", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSLessThan(Date value) {
            addCriterion("LASTUPD_TS <", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSLessThanOrEqualTo(Date value) {
            addCriterion("LASTUPD_TS <=", value, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSIn(List<Date> values) {
            addCriterion("LASTUPD_TS in", values, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSNotIn(List<Date> values) {
            addCriterion("LASTUPD_TS not in", values, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSBetween(Date value1, Date value2) {
            addCriterion("LASTUPD_TS between", value1, value2, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andLASTUPD_TSNotBetween(Date value1, Date value2) {
            addCriterion("LASTUPD_TS not between", value1, value2, "LASTUPD_TS");
            return (Criteria) this;
        }

        public Criteria andSTATUS_FLGIsNull() {
            addCriterion("STATUS_FLG is null");
            return (Criteria) this;
        }

        public Criteria andSTATUS_FLGIsNotNull() {
            addCriterion("STATUS_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andSTATUS_FLGEqualTo(String value) {
            addCriterion("STATUS_FLG =", value, "STATUS_FLG");
            return (Criteria) this;
        }

        public Criteria andSTATUS_FLGNotEqualTo(String value) {
            addCriterion("STATUS_FLG <>", value, "STATUS_FLG");
            return (Criteria) this;
        }

        public Criteria andSTATUS_FLGGreaterThan(String value) {
            addCriterion("STATUS_FLG >", value, "STATUS_FLG");
            return (Criteria) this;
        }

        public Criteria andSTATUS_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("STATUS_FLG >=", value, "STATUS_FLG");
            return (Criteria) this;
        }

        public Criteria andSTATUS_FLGLessThan(String value) {
            addCriterion("STATUS_FLG <", value, "STATUS_FLG");
            return (Criteria) this;
        }

        public Criteria andSTATUS_FLGLessThanOrEqualTo(String value) {
            addCriterion("STATUS_FLG <=", value, "STATUS_FLG");
            return (Criteria) this;
        }

        public Criteria andSTATUS_FLGLike(String value) {
            addCriterion("STATUS_FLG like", value, "STATUS_FLG");
            return (Criteria) this;
        }

        public Criteria andSTATUS_FLGNotLike(String value) {
            addCriterion("STATUS_FLG not like", value, "STATUS_FLG");
            return (Criteria) this;
        }

        public Criteria andSTATUS_FLGIn(List<String> values) {
            addCriterion("STATUS_FLG in", values, "STATUS_FLG");
            return (Criteria) this;
        }

        public Criteria andSTATUS_FLGNotIn(List<String> values) {
            addCriterion("STATUS_FLG not in", values, "STATUS_FLG");
            return (Criteria) this;
        }

        public Criteria andSTATUS_FLGBetween(String value1, String value2) {
            addCriterion("STATUS_FLG between", value1, value2, "STATUS_FLG");
            return (Criteria) this;
        }

        public Criteria andSTATUS_FLGNotBetween(String value1, String value2) {
            addCriterion("STATUS_FLG not between", value1, value2, "STATUS_FLG");
            return (Criteria) this;
        }

        public Criteria andTAIIN_TEL_NUMIsNull() {
            addCriterion("TAIIN_TEL_NUM is null");
            return (Criteria) this;
        }

        public Criteria andTAIIN_TEL_NUMIsNotNull() {
            addCriterion("TAIIN_TEL_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andTAIIN_TEL_NUMEqualTo(String value) {
            addCriterion("TAIIN_TEL_NUM =", value, "TAIIN_TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andTAIIN_TEL_NUMNotEqualTo(String value) {
            addCriterion("TAIIN_TEL_NUM <>", value, "TAIIN_TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andTAIIN_TEL_NUMGreaterThan(String value) {
            addCriterion("TAIIN_TEL_NUM >", value, "TAIIN_TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andTAIIN_TEL_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("TAIIN_TEL_NUM >=", value, "TAIIN_TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andTAIIN_TEL_NUMLessThan(String value) {
            addCriterion("TAIIN_TEL_NUM <", value, "TAIIN_TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andTAIIN_TEL_NUMLessThanOrEqualTo(String value) {
            addCriterion("TAIIN_TEL_NUM <=", value, "TAIIN_TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andTAIIN_TEL_NUMLike(String value) {
            addCriterion("TAIIN_TEL_NUM like", value, "TAIIN_TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andTAIIN_TEL_NUMNotLike(String value) {
            addCriterion("TAIIN_TEL_NUM not like", value, "TAIIN_TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andTAIIN_TEL_NUMIn(List<String> values) {
            addCriterion("TAIIN_TEL_NUM in", values, "TAIIN_TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andTAIIN_TEL_NUMNotIn(List<String> values) {
            addCriterion("TAIIN_TEL_NUM not in", values, "TAIIN_TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andTAIIN_TEL_NUMBetween(String value1, String value2) {
            addCriterion("TAIIN_TEL_NUM between", value1, value2, "TAIIN_TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andTAIIN_TEL_NUMNotBetween(String value1, String value2) {
            addCriterion("TAIIN_TEL_NUM not between", value1, value2, "TAIIN_TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andGC_NUMLikeInsensitive(String value) {
            addCriterion("upper(GC_NUM) like", value.toUpperCase(), "GC_NUM");
            return (Criteria) this;
        }

        public Criteria andLN_RONRI_NUMLikeInsensitive(String value) {
            addCriterion("upper(LN_RONRI_NUM) like", value.toUpperCase(), "LN_RONRI_NUM");
            return (Criteria) this;
        }

        public Criteria andJIAN_HASSEI_TSLikeInsensitive(String value) {
            addCriterion("upper(JIAN_HASSEI_TS) like", value.toUpperCase(), "JIAN_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andTAIIN_NUMLikeInsensitive(String value) {
            addCriterion("upper(TAIIN_NUM) like", value.toUpperCase(), "TAIIN_NUM");
            return (Criteria) this;
        }

        public Criteria andTAIIN_KINDLikeInsensitive(String value) {
            addCriterion("upper(TAIIN_KIND) like", value.toUpperCase(), "TAIIN_KIND");
            return (Criteria) this;
        }

        public Criteria andGOUKILikeInsensitive(String value) {
            addCriterion("upper(GOUKI) like", value.toUpperCase(), "GOUKI");
            return (Criteria) this;
        }

        public Criteria andDENKEILikeInsensitive(String value) {
            addCriterion("upper(DENKEI) like", value.toUpperCase(), "DENKEI");
            return (Criteria) this;
        }

        public Criteria andSUBADDRLikeInsensitive(String value) {
            addCriterion("upper(SUBADDR) like", value.toUpperCase(), "SUBADDR");
            return (Criteria) this;
        }

        public Criteria andKEIYAKU_IDLikeInsensitive(String value) {
            addCriterion("upper(KEIYAKU_ID) like", value.toUpperCase(), "KEIYAKU_ID");
            return (Criteria) this;
        }

        public Criteria andABBR_NMLikeInsensitive(String value) {
            addCriterion("upper(ABBR_NM) like", value.toUpperCase(), "ABBR_NM");
            return (Criteria) this;
        }

        public Criteria andADDRESS_CDLikeInsensitive(String value) {
            addCriterion("upper(ADDRESS_CD) like", value.toUpperCase(), "ADDRESS_CD");
            return (Criteria) this;
        }

        public Criteria andTANTOU_OUEN_KBNLikeInsensitive(String value) {
            addCriterion("upper(TANTOU_OUEN_KBN) like", value.toUpperCase(), "TANTOU_OUEN_KBN");
            return (Criteria) this;
        }

        public Criteria andSYUTUDOU_KBNLikeInsensitive(String value) {
            addCriterion("upper(SYUTUDOU_KBN) like", value.toUpperCase(), "SYUTUDOU_KBN");
            return (Criteria) this;
        }

        public Criteria andCHOKKOU_KBNLikeInsensitive(String value) {
            addCriterion("upper(CHOKKOU_KBN) like", value.toUpperCase(), "CHOKKOU_KBN");
            return (Criteria) this;
        }

        public Criteria andCAR_NUMLikeInsensitive(String value) {
            addCriterion("upper(CAR_NUM) like", value.toUpperCase(), "CAR_NUM");
            return (Criteria) this;
        }

        public Criteria andSIJI_METHODLikeInsensitive(String value) {
            addCriterion("upper(SIJI_METHOD) like", value.toUpperCase(), "SIJI_METHOD");
            return (Criteria) this;
        }

        public Criteria andSIJILikeInsensitive(String value) {
            addCriterion("upper(SIJI) like", value.toUpperCase(), "SIJI");
            return (Criteria) this;
        }

        public Criteria andCHOKKOULikeInsensitive(String value) {
            addCriterion("upper(CHOKKOU) like", value.toUpperCase(), "CHOKKOU");
            return (Criteria) this;
        }

        public Criteria andMIKOMILikeInsensitive(String value) {
            addCriterion("upper(MIKOMI) like", value.toUpperCase(), "MIKOMI");
            return (Criteria) this;
        }

        public Criteria andGENCHAKULikeInsensitive(String value) {
            addCriterion("upper(GENCHAKU) like", value.toUpperCase(), "GENCHAKU");
            return (Criteria) this;
        }

        public Criteria andSYOYOULikeInsensitive(String value) {
            addCriterion("upper(SYOYOU) like", value.toUpperCase(), "SYOYOU");
            return (Criteria) this;
        }

        public Criteria andNYUUKANLikeInsensitive(String value) {
            addCriterion("upper(NYUUKAN) like", value.toUpperCase(), "NYUUKAN");
            return (Criteria) this;
        }

        public Criteria andTAIKANLikeInsensitive(String value) {
            addCriterion("upper(TAIKAN) like", value.toUpperCase(), "TAIKAN");
            return (Criteria) this;
        }

        public Criteria andTAIKAN_KBNLikeInsensitive(String value) {
            addCriterion("upper(TAIKAN_KBN) like", value.toUpperCase(), "TAIKAN_KBN");
            return (Criteria) this;
        }

        public Criteria andINTERRUPTLikeInsensitive(String value) {
            addCriterion("upper(INTERRUPT) like", value.toUpperCase(), "INTERRUPT");
            return (Criteria) this;
        }

        public Criteria andINTERRUPT_CANCELLikeInsensitive(String value) {
            addCriterion("upper(INTERRUPT_CANCEL) like", value.toUpperCase(), "INTERRUPT_CANCEL");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEILikeInsensitive(String value) {
            addCriterion("upper(OUEN_YOUSEI) like", value.toUpperCase(), "OUEN_YOUSEI");
            return (Criteria) this;
        }

        public Criteria andOUEN_YOUSEI_CANCELLikeInsensitive(String value) {
            addCriterion("upper(OUEN_YOUSEI_CANCEL) like", value.toUpperCase(), "OUEN_YOUSEI_CANCEL");
            return (Criteria) this;
        }

        public Criteria andENDLikeInsensitive(String value) {
            addCriterion("upper(END) like", value.toUpperCase(), "END");
            return (Criteria) this;
        }

        public Criteria andCANCELLikeInsensitive(String value) {
            addCriterion("upper(CANCEL) like", value.toUpperCase(), "CANCEL");
            return (Criteria) this;
        }

        public Criteria andRTRNLikeInsensitive(String value) {
            addCriterion("upper(RTRN) like", value.toUpperCase(), "RTRN");
            return (Criteria) this;
        }

        public Criteria andTAIKISYO_CDLikeInsensitive(String value) {
            addCriterion("upper(TAIKISYO_CD) like", value.toUpperCase(), "TAIKISYO_CD");
            return (Criteria) this;
        }

        public Criteria andJIGYO_CDLikeInsensitive(String value) {
            addCriterion("upper(JIGYO_CD) like", value.toUpperCase(), "JIGYO_CD");
            return (Criteria) this;
        }

        public Criteria andSIG_HASSEI_TSLikeInsensitive(String value) {
            addCriterion("upper(SIG_HASSEI_TS) like", value.toUpperCase(), "SIG_HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andTAIIN_JITAI_CDLikeInsensitive(String value) {
            addCriterion("upper(TAIIN_JITAI_CD) like", value.toUpperCase(), "TAIIN_JITAI_CD");
            return (Criteria) this;
        }

        public Criteria andKEY_SIJI_PRIORITYLikeInsensitive(String value) {
            addCriterion("upper(KEY_SIJI_PRIORITY) like", value.toUpperCase(), "KEY_SIJI_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andNO_KEY_SIJI_PRIORITYLikeInsensitive(String value) {
            addCriterion("upper(NO_KEY_SIJI_PRIORITY) like", value.toUpperCase(), "NO_KEY_SIJI_PRIORITY");
            return (Criteria) this;
        }

        public Criteria andJITAI_UPDATE_TSLikeInsensitive(String value) {
            addCriterion("upper(JITAI_UPDATE_TS) like", value.toUpperCase(), "JITAI_UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andNO_AUTO_UNYO_FLGLikeInsensitive(String value) {
            addCriterion("upper(NO_AUTO_UNYO_FLG) like", value.toUpperCase(), "NO_AUTO_UNYO_FLG");
            return (Criteria) this;
        }

        public Criteria andDOUKOUSYALikeInsensitive(String value) {
            addCriterion("upper(DOUKOUSYA) like", value.toUpperCase(), "DOUKOUSYA");
            return (Criteria) this;
        }

        public Criteria andSTATUS_FLGLikeInsensitive(String value) {
            addCriterion("upper(STATUS_FLG) like", value.toUpperCase(), "STATUS_FLG");
            return (Criteria) this;
        }

        public Criteria andTAIIN_TEL_NUMLikeInsensitive(String value) {
            addCriterion("upper(TAIIN_TEL_NUM) like", value.toUpperCase(), "TAIIN_TEL_NUM");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * E_V6_TAIINF_FULL
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * E_V6_TAIINF_FULL null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}