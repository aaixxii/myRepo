package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EGctSendQueExample {
    /**
     * E_GCT_SEND_QUE
     */
    protected String orderByClause;

    /**
     * E_GCT_SEND_QUE
     */
    protected boolean distinct;

    /**
     * E_GCT_SEND_QUE
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public EGctSendQueExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * E_GCT_SEND_QUE null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_GCT_SEND_QUEIsNull() {
            addCriterion("LN_GCT_SEND_QUE is null");
            return (Criteria) this;
        }

        public Criteria andLN_GCT_SEND_QUEIsNotNull() {
            addCriterion("LN_GCT_SEND_QUE is not null");
            return (Criteria) this;
        }

        public Criteria andLN_GCT_SEND_QUEEqualTo(String value) {
            addCriterion("LN_GCT_SEND_QUE =", value, "LN_GCT_SEND_QUE");
            return (Criteria) this;
        }

        public Criteria andLN_GCT_SEND_QUENotEqualTo(String value) {
            addCriterion("LN_GCT_SEND_QUE <>", value, "LN_GCT_SEND_QUE");
            return (Criteria) this;
        }

        public Criteria andLN_GCT_SEND_QUEGreaterThan(String value) {
            addCriterion("LN_GCT_SEND_QUE >", value, "LN_GCT_SEND_QUE");
            return (Criteria) this;
        }

        public Criteria andLN_GCT_SEND_QUEGreaterThanOrEqualTo(String value) {
            addCriterion("LN_GCT_SEND_QUE >=", value, "LN_GCT_SEND_QUE");
            return (Criteria) this;
        }

        public Criteria andLN_GCT_SEND_QUELessThan(String value) {
            addCriterion("LN_GCT_SEND_QUE <", value, "LN_GCT_SEND_QUE");
            return (Criteria) this;
        }

        public Criteria andLN_GCT_SEND_QUELessThanOrEqualTo(String value) {
            addCriterion("LN_GCT_SEND_QUE <=", value, "LN_GCT_SEND_QUE");
            return (Criteria) this;
        }

        public Criteria andLN_GCT_SEND_QUELike(String value) {
            addCriterion("LN_GCT_SEND_QUE like", value, "LN_GCT_SEND_QUE");
            return (Criteria) this;
        }

        public Criteria andLN_GCT_SEND_QUENotLike(String value) {
            addCriterion("LN_GCT_SEND_QUE not like", value, "LN_GCT_SEND_QUE");
            return (Criteria) this;
        }

        public Criteria andLN_GCT_SEND_QUEIn(List<String> values) {
            addCriterion("LN_GCT_SEND_QUE in", values, "LN_GCT_SEND_QUE");
            return (Criteria) this;
        }

        public Criteria andLN_GCT_SEND_QUENotIn(List<String> values) {
            addCriterion("LN_GCT_SEND_QUE not in", values, "LN_GCT_SEND_QUE");
            return (Criteria) this;
        }

        public Criteria andLN_GCT_SEND_QUEBetween(String value1, String value2) {
            addCriterion("LN_GCT_SEND_QUE between", value1, value2, "LN_GCT_SEND_QUE");
            return (Criteria) this;
        }

        public Criteria andLN_GCT_SEND_QUENotBetween(String value1, String value2) {
            addCriterion("LN_GCT_SEND_QUE not between", value1, value2, "LN_GCT_SEND_QUE");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNIsNull() {
            addCriterion("SYS_KBN is null");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNIsNotNull() {
            addCriterion("SYS_KBN is not null");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNEqualTo(String value) {
            addCriterion("SYS_KBN =", value, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNNotEqualTo(String value) {
            addCriterion("SYS_KBN <>", value, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNGreaterThan(String value) {
            addCriterion("SYS_KBN >", value, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNGreaterThanOrEqualTo(String value) {
            addCriterion("SYS_KBN >=", value, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNLessThan(String value) {
            addCriterion("SYS_KBN <", value, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNLessThanOrEqualTo(String value) {
            addCriterion("SYS_KBN <=", value, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNLike(String value) {
            addCriterion("SYS_KBN like", value, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNNotLike(String value) {
            addCriterion("SYS_KBN not like", value, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNIn(List<String> values) {
            addCriterion("SYS_KBN in", values, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNNotIn(List<String> values) {
            addCriterion("SYS_KBN not in", values, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNBetween(String value1, String value2) {
            addCriterion("SYS_KBN between", value1, value2, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNNotBetween(String value1, String value2) {
            addCriterion("SYS_KBN not between", value1, value2, "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andDST_GYOUMU_CDIsNull() {
            addCriterion("DST_GYOUMU_CD is null");
            return (Criteria) this;
        }

        public Criteria andDST_GYOUMU_CDIsNotNull() {
            addCriterion("DST_GYOUMU_CD is not null");
            return (Criteria) this;
        }

        public Criteria andDST_GYOUMU_CDEqualTo(String value) {
            addCriterion("DST_GYOUMU_CD =", value, "DST_GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andDST_GYOUMU_CDNotEqualTo(String value) {
            addCriterion("DST_GYOUMU_CD <>", value, "DST_GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andDST_GYOUMU_CDGreaterThan(String value) {
            addCriterion("DST_GYOUMU_CD >", value, "DST_GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andDST_GYOUMU_CDGreaterThanOrEqualTo(String value) {
            addCriterion("DST_GYOUMU_CD >=", value, "DST_GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andDST_GYOUMU_CDLessThan(String value) {
            addCriterion("DST_GYOUMU_CD <", value, "DST_GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andDST_GYOUMU_CDLessThanOrEqualTo(String value) {
            addCriterion("DST_GYOUMU_CD <=", value, "DST_GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andDST_GYOUMU_CDLike(String value) {
            addCriterion("DST_GYOUMU_CD like", value, "DST_GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andDST_GYOUMU_CDNotLike(String value) {
            addCriterion("DST_GYOUMU_CD not like", value, "DST_GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andDST_GYOUMU_CDIn(List<String> values) {
            addCriterion("DST_GYOUMU_CD in", values, "DST_GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andDST_GYOUMU_CDNotIn(List<String> values) {
            addCriterion("DST_GYOUMU_CD not in", values, "DST_GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andDST_GYOUMU_CDBetween(String value1, String value2) {
            addCriterion("DST_GYOUMU_CD between", value1, value2, "DST_GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andDST_GYOUMU_CDNotBetween(String value1, String value2) {
            addCriterion("DST_GYOUMU_CD not between", value1, value2, "DST_GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andDST_HOST_NUMIsNull() {
            addCriterion("DST_HOST_NUM is null");
            return (Criteria) this;
        }

        public Criteria andDST_HOST_NUMIsNotNull() {
            addCriterion("DST_HOST_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andDST_HOST_NUMEqualTo(String value) {
            addCriterion("DST_HOST_NUM =", value, "DST_HOST_NUM");
            return (Criteria) this;
        }

        public Criteria andDST_HOST_NUMNotEqualTo(String value) {
            addCriterion("DST_HOST_NUM <>", value, "DST_HOST_NUM");
            return (Criteria) this;
        }

        public Criteria andDST_HOST_NUMGreaterThan(String value) {
            addCriterion("DST_HOST_NUM >", value, "DST_HOST_NUM");
            return (Criteria) this;
        }

        public Criteria andDST_HOST_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("DST_HOST_NUM >=", value, "DST_HOST_NUM");
            return (Criteria) this;
        }

        public Criteria andDST_HOST_NUMLessThan(String value) {
            addCriterion("DST_HOST_NUM <", value, "DST_HOST_NUM");
            return (Criteria) this;
        }

        public Criteria andDST_HOST_NUMLessThanOrEqualTo(String value) {
            addCriterion("DST_HOST_NUM <=", value, "DST_HOST_NUM");
            return (Criteria) this;
        }

        public Criteria andDST_HOST_NUMLike(String value) {
            addCriterion("DST_HOST_NUM like", value, "DST_HOST_NUM");
            return (Criteria) this;
        }

        public Criteria andDST_HOST_NUMNotLike(String value) {
            addCriterion("DST_HOST_NUM not like", value, "DST_HOST_NUM");
            return (Criteria) this;
        }

        public Criteria andDST_HOST_NUMIn(List<String> values) {
            addCriterion("DST_HOST_NUM in", values, "DST_HOST_NUM");
            return (Criteria) this;
        }

        public Criteria andDST_HOST_NUMNotIn(List<String> values) {
            addCriterion("DST_HOST_NUM not in", values, "DST_HOST_NUM");
            return (Criteria) this;
        }

        public Criteria andDST_HOST_NUMBetween(String value1, String value2) {
            addCriterion("DST_HOST_NUM between", value1, value2, "DST_HOST_NUM");
            return (Criteria) this;
        }

        public Criteria andDST_HOST_NUMNotBetween(String value1, String value2) {
            addCriterion("DST_HOST_NUM not between", value1, value2, "DST_HOST_NUM");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSIsNull() {
            addCriterion("HASSEI_TS is null");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSIsNotNull() {
            addCriterion("HASSEI_TS is not null");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSEqualTo(Date value) {
            addCriterion("HASSEI_TS =", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSNotEqualTo(Date value) {
            addCriterion("HASSEI_TS <>", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSGreaterThan(Date value) {
            addCriterion("HASSEI_TS >", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("HASSEI_TS >=", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSLessThan(Date value) {
            addCriterion("HASSEI_TS <", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSLessThanOrEqualTo(Date value) {
            addCriterion("HASSEI_TS <=", value, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSIn(List<Date> values) {
            addCriterion("HASSEI_TS in", values, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSNotIn(List<Date> values) {
            addCriterion("HASSEI_TS not in", values, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSBetween(Date value1, Date value2) {
            addCriterion("HASSEI_TS between", value1, value2, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andHASSEI_TSNotBetween(Date value1, Date value2) {
            addCriterion("HASSEI_TS not between", value1, value2, "HASSEI_TS");
            return (Criteria) this;
        }

        public Criteria andSEQ_NUMIsNull() {
            addCriterion("SEQ_NUM is null");
            return (Criteria) this;
        }

        public Criteria andSEQ_NUMIsNotNull() {
            addCriterion("SEQ_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andSEQ_NUMEqualTo(String value) {
            addCriterion("SEQ_NUM =", value, "SEQ_NUM");
            return (Criteria) this;
        }

        public Criteria andSEQ_NUMNotEqualTo(String value) {
            addCriterion("SEQ_NUM <>", value, "SEQ_NUM");
            return (Criteria) this;
        }

        public Criteria andSEQ_NUMGreaterThan(String value) {
            addCriterion("SEQ_NUM >", value, "SEQ_NUM");
            return (Criteria) this;
        }

        public Criteria andSEQ_NUMGreaterThanOrEqualTo(String value) {
            addCriterion("SEQ_NUM >=", value, "SEQ_NUM");
            return (Criteria) this;
        }

        public Criteria andSEQ_NUMLessThan(String value) {
            addCriterion("SEQ_NUM <", value, "SEQ_NUM");
            return (Criteria) this;
        }

        public Criteria andSEQ_NUMLessThanOrEqualTo(String value) {
            addCriterion("SEQ_NUM <=", value, "SEQ_NUM");
            return (Criteria) this;
        }

        public Criteria andSEQ_NUMLike(String value) {
            addCriterion("SEQ_NUM like", value, "SEQ_NUM");
            return (Criteria) this;
        }

        public Criteria andSEQ_NUMNotLike(String value) {
            addCriterion("SEQ_NUM not like", value, "SEQ_NUM");
            return (Criteria) this;
        }

        public Criteria andSEQ_NUMIn(List<String> values) {
            addCriterion("SEQ_NUM in", values, "SEQ_NUM");
            return (Criteria) this;
        }

        public Criteria andSEQ_NUMNotIn(List<String> values) {
            addCriterion("SEQ_NUM not in", values, "SEQ_NUM");
            return (Criteria) this;
        }

        public Criteria andSEQ_NUMBetween(String value1, String value2) {
            addCriterion("SEQ_NUM between", value1, value2, "SEQ_NUM");
            return (Criteria) this;
        }

        public Criteria andSEQ_NUMNotBetween(String value1, String value2) {
            addCriterion("SEQ_NUM not between", value1, value2, "SEQ_NUM");
            return (Criteria) this;
        }

        public Criteria andGOUKIIsNull() {
            addCriterion("GOUKI is null");
            return (Criteria) this;
        }

        public Criteria andGOUKIIsNotNull() {
            addCriterion("GOUKI is not null");
            return (Criteria) this;
        }

        public Criteria andGOUKIEqualTo(String value) {
            addCriterion("GOUKI =", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKINotEqualTo(String value) {
            addCriterion("GOUKI <>", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKIGreaterThan(String value) {
            addCriterion("GOUKI >", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKIGreaterThanOrEqualTo(String value) {
            addCriterion("GOUKI >=", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKILessThan(String value) {
            addCriterion("GOUKI <", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKILessThanOrEqualTo(String value) {
            addCriterion("GOUKI <=", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKILike(String value) {
            addCriterion("GOUKI like", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKINotLike(String value) {
            addCriterion("GOUKI not like", value, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKIIn(List<String> values) {
            addCriterion("GOUKI in", values, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKINotIn(List<String> values) {
            addCriterion("GOUKI not in", values, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKIBetween(String value1, String value2) {
            addCriterion("GOUKI between", value1, value2, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andGOUKINotBetween(String value1, String value2) {
            addCriterion("GOUKI not between", value1, value2, "GOUKI");
            return (Criteria) this;
        }

        public Criteria andDATA_SUB_ADDRIsNull() {
            addCriterion("DATA_SUB_ADDR is null");
            return (Criteria) this;
        }

        public Criteria andDATA_SUB_ADDRIsNotNull() {
            addCriterion("DATA_SUB_ADDR is not null");
            return (Criteria) this;
        }

        public Criteria andDATA_SUB_ADDREqualTo(String value) {
            addCriterion("DATA_SUB_ADDR =", value, "DATA_SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andDATA_SUB_ADDRNotEqualTo(String value) {
            addCriterion("DATA_SUB_ADDR <>", value, "DATA_SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andDATA_SUB_ADDRGreaterThan(String value) {
            addCriterion("DATA_SUB_ADDR >", value, "DATA_SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andDATA_SUB_ADDRGreaterThanOrEqualTo(String value) {
            addCriterion("DATA_SUB_ADDR >=", value, "DATA_SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andDATA_SUB_ADDRLessThan(String value) {
            addCriterion("DATA_SUB_ADDR <", value, "DATA_SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andDATA_SUB_ADDRLessThanOrEqualTo(String value) {
            addCriterion("DATA_SUB_ADDR <=", value, "DATA_SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andDATA_SUB_ADDRLike(String value) {
            addCriterion("DATA_SUB_ADDR like", value, "DATA_SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andDATA_SUB_ADDRNotLike(String value) {
            addCriterion("DATA_SUB_ADDR not like", value, "DATA_SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andDATA_SUB_ADDRIn(List<String> values) {
            addCriterion("DATA_SUB_ADDR in", values, "DATA_SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andDATA_SUB_ADDRNotIn(List<String> values) {
            addCriterion("DATA_SUB_ADDR not in", values, "DATA_SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andDATA_SUB_ADDRBetween(String value1, String value2) {
            addCriterion("DATA_SUB_ADDR between", value1, value2, "DATA_SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andDATA_SUB_ADDRNotBetween(String value1, String value2) {
            addCriterion("DATA_SUB_ADDR not between", value1, value2, "DATA_SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFIsNull() {
            addCriterion("LN_KB_INF is null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFIsNotNull() {
            addCriterion("LN_KB_INF is not null");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFEqualTo(String value) {
            addCriterion("LN_KB_INF =", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFNotEqualTo(String value) {
            addCriterion("LN_KB_INF <>", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFGreaterThan(String value) {
            addCriterion("LN_KB_INF >", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFGreaterThanOrEqualTo(String value) {
            addCriterion("LN_KB_INF >=", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFLessThan(String value) {
            addCriterion("LN_KB_INF <", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFLessThanOrEqualTo(String value) {
            addCriterion("LN_KB_INF <=", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFLike(String value) {
            addCriterion("LN_KB_INF like", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFNotLike(String value) {
            addCriterion("LN_KB_INF not like", value, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFIn(List<String> values) {
            addCriterion("LN_KB_INF in", values, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFNotIn(List<String> values) {
            addCriterion("LN_KB_INF not in", values, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFBetween(String value1, String value2) {
            addCriterion("LN_KB_INF between", value1, value2, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFNotBetween(String value1, String value2) {
            addCriterion("LN_KB_INF not between", value1, value2, "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andLN_GCT_SEND_QUELikeInsensitive(String value) {
            addCriterion("upper(LN_GCT_SEND_QUE) like", value.toUpperCase(), "LN_GCT_SEND_QUE");
            return (Criteria) this;
        }

        public Criteria andSYS_KBNLikeInsensitive(String value) {
            addCriterion("upper(SYS_KBN) like", value.toUpperCase(), "SYS_KBN");
            return (Criteria) this;
        }

        public Criteria andDST_GYOUMU_CDLikeInsensitive(String value) {
            addCriterion("upper(DST_GYOUMU_CD) like", value.toUpperCase(), "DST_GYOUMU_CD");
            return (Criteria) this;
        }

        public Criteria andDST_HOST_NUMLikeInsensitive(String value) {
            addCriterion("upper(DST_HOST_NUM) like", value.toUpperCase(), "DST_HOST_NUM");
            return (Criteria) this;
        }

        public Criteria andSEQ_NUMLikeInsensitive(String value) {
            addCriterion("upper(SEQ_NUM) like", value.toUpperCase(), "SEQ_NUM");
            return (Criteria) this;
        }

        public Criteria andGOUKILikeInsensitive(String value) {
            addCriterion("upper(GOUKI) like", value.toUpperCase(), "GOUKI");
            return (Criteria) this;
        }

        public Criteria andDATA_SUB_ADDRLikeInsensitive(String value) {
            addCriterion("upper(DATA_SUB_ADDR) like", value.toUpperCase(), "DATA_SUB_ADDR");
            return (Criteria) this;
        }

        public Criteria andLN_KB_INFLikeInsensitive(String value) {
            addCriterion("upper(LN_KB_INF) like", value.toUpperCase(), "LN_KB_INF");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * E_GCT_SEND_QUE
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * E_GCT_SEND_QUE null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}