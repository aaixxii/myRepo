package com.nec.aim.dm.dmservice.dispatch;

import java.sql.SQLException;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.aim.dm.dmservice.persistence.DmInfoRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class dmService {	

	@Autowired
	DmInfoRepository dmInfoRepository;	
	

	@PostConstruct
	public void getSetting() {
		try {
			dmInfoRepository.getAllDmServiceUrl();	
		} catch (SQLException e) {
			log.error(e.getMessage());
		}
	}

	@PreDestroy
	public void close() {
		DmServiceManager.close();
	}
}
