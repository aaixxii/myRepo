package com.nec.aim.dm.dmservice.entity;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class SegmentInfo {	
	 private Long segmentId;
	 private Long bioIdStart;	
	 private Long bioIdEnd;	
	 private Long version;
	 private Timestamp updateTs;
}
