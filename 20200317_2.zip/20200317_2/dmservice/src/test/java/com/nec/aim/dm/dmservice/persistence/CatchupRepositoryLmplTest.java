package com.nec.aim.dm.dmservice.persistence;

import java.sql.Blob;
import java.sql.SQLException;

import javax.sql.rowset.serial.SerialException;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringRunner;

import com.nec.aim.dm.dmservice.DmserviceApplication;
import com.nec.aim.dm.dmservice.entity.Catchup;


@RunWith(SpringRunner.class)  
@SpringBootTest(classes={DmserviceApplication.class})
public class CatchupRepositoryLmplTest {
	
	@Autowired
	CatchupRepository catchupRepository;
	
	@Autowired
    private JdbcTemplate jdbcTemplate;

	@Before
	public void setUp() throws Exception {	
		jdbcTemplate.execute("delete from catchup");
		jdbcTemplate.execute("delete from segments_info");
		
	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.execute("delete from catchup");
		jdbcTemplate.execute("delete from segments_info");
	}

	@Test
	public void testInsertForNewSegment() throws SQLException {	
		Long segmentId = 1000L;
		Long bioIdStart = 0L;
		Long bioIdEnd = 0L;
		Long segmentVer = 0L;
		
		String insertSegmentSql = "insert into segments_info(segment_id,bio_id_start,bio_id_end, version, update_ts) values(?,?,?,?,CURRENT_TIMESTAMP())";		
		jdbcTemplate.update(insertSegmentSql, new Object[] {segmentId, bioIdStart, bioIdEnd, segmentVer });
		catchupRepository.insertForNewSegment(1, segmentId, segmentVer, 0);
		int count = jdbcTemplate.queryForObject("select count(1) from catchup", int.class);
		Assert.assertEquals(1, count);
	}

	@Test
	public void testInsert() throws SerialException, SQLException {
		Long segmentId = 1000L;
		Long bioIdStart = 0L;
		Long bioIdEnd = 0L;
		Long segmentVer = 0L;
		
		String insertSegmentSql = "insert into segments_info(segment_id,bio_id_start,bio_id_end, version, update_ts) values(?,?,?,?,CURRENT_TIMESTAMP())";		
		jdbcTemplate.update(insertSegmentSql, new Object[] {segmentId, bioIdStart, bioIdEnd, segmentVer });
		Catchup cp = new Catchup();
		cp.setBiometricsId(1L);
		cp.setChangeType(1);
		cp.setExternalId("ex1");
		cp.setSegmentId(1000L);
		cp.setSegmentVersion(1L);
		cp.setStorageId(1);
		Blob blob = new javax.sql.rowset.serial.SerialBlob("test".getBytes());
		cp.setTemplateData(blob);
		catchupRepository.insert(cp);
		int count = jdbcTemplate.queryForObject("select count(1) from catchup", int.class);
		Assert.assertEquals(1, count);
	}

	@Test
	public void testDelete() throws SQLException {
		Long segmentId = 1000L;
		Long bioIdStart = 0L;
		Long bioIdEnd = 0L;
		Long segmentVer = 0L;
		
		String insertSegmentSql = "insert into segments_info(segment_id,bio_id_start,bio_id_end, version, update_ts) values(?,?,?,?,CURRENT_TIMESTAMP())";		
		jdbcTemplate.update(insertSegmentSql, new Object[] {segmentId, bioIdStart, bioIdEnd, segmentVer });
		Catchup cp = new Catchup();
		cp.setBiometricsId(1L);
		cp.setChangeType(2);
		cp.setExternalId("ex1");
		cp.setSegmentId(1000L);
		cp.setSegmentVersion(1L);
		cp.setStorageId(1);		
		catchupRepository.delete(cp);
		int count = jdbcTemplate.queryForObject("select count(1) from catchup", int.class);		
		Assert.assertEquals(1, count);
		
	}

}
