package com.nec.aim.dm.nodostorage.repository;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.nec.aim.dm.nodostorage.config.ConfigProperties;
import com.nec.aim.dm.nodostorage.entity.NodeStorage;



@Repository
public class NodeStorageRepositoryImpl implements NodeStorageRepository{
	
	@Autowired
    private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private ConfigProperties config;	
	
	private static final String updateMyInfoSql = "update node_storage  set status =1, update_ts=CURRENT_TIMESTAMP() where  storage_id =? and dm_storage_id=?";
	private static final String getmyMailFalg = "update node_storage set mail_flag = ''  where storage_id =? and dm_storage_id = ? and mail_flag = 'signal'";
	private static final String getMyStorageSize = "select space from node_storage WHERE storage_id=? and dm_storage_id =?";
	private static final String updateMyStorageSize = "update node_storage set space = space-? WHERE storage_id=? and dm_storage_id =?";
	
	RowMapper<NodeStorage> nodeRowMapper = (rs, rowNum) -> {
	    NodeStorage node = new NodeStorage();
	    node.setStorageId(rs.getInt("storage_id"));
	    node.setDmStorageid(rs.getString("dm_storage_id"));
	    node.setUrl(rs.getString("url"));
	    node.setDiskSize(rs.getInt("disk_size"));
	    node.setSpace(rs.getInt("space"));
	    node.setStatus(rs.getInt("status"));
	    node.setUpdateTs(rs.getTimestamp("update_ts"));
	    return node;
	};	

	@Override
	public void heatbeat() throws SQLException {
		jdbcTemplate.update(updateMyInfoSql, new Object[] {config.getId(), config.getDmId()});	
	}

	@Override
	public int getMyMailFlag()  throws SQLException  {
		int falgCount = jdbcTemplate.update(getmyMailFalg, new Object[] {config.getId(), config.getDmId()}, Integer.class);
		return falgCount;
	}

	@Override
	public long getStorageSize(int nodeStorageId, String dmStorageId) throws SQLException {
		long size = jdbcTemplate.update(getMyStorageSize, new Object[] {config.getId(), config.getDmId()}, Integer.class);
		return size;
	}

	@Override
	public void updateStorageSize(int size, int nodeStorageId, String dmStorageId) throws SQLException {
		jdbcTemplate.update(updateMyStorageSize, new Object[] {size,config.getId(), config.getDmId()}, Integer.class);		
	}

}
