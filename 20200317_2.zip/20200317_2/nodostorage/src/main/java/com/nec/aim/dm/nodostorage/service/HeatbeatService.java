package com.nec.aim.dm.nodostorage.service;

import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.aim.dm.nodostorage.config.ConfigProperties;
import com.nec.aim.dm.nodostorage.entity.Catchup;
import com.nec.aim.dm.nodostorage.manager.NodeStorageManager;
import com.nec.aim.dm.nodostorage.repository.CatchupRepository;
import com.nec.aim.dm.nodostorage.repository.NodeStorageRepository;
import com.nec.aim.dm.nodostorage.repository.SegmentLoadRepository;
import com.nec.aim.dm.nodostorage.segments.SegmentWriter;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import jp.co.nec.aim.message.proto.AIMMessages.PBTargetSegmentVersion;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class HeatbeatService {
	
	private static final ScheduledExecutorService statusUpdateScheduler = Executors.newScheduledThreadPool(1);
	private static final ScheduledExecutorService catchUpScheduler = Executors.newScheduledThreadPool(1);
	
	@Autowired
	NodeStorageRepository nodeStorageRepository;
	
	@Autowired
	SegmentLoadRepository segmentLoadRepository;
	
	@Autowired
	ConfigProperties config;
	
	@Autowired
	CatchupRepository catchupRepository;
	
	@PostConstruct
	public void updateMyInfo() throws SQLException {
		Runnable statusUpdateTask = () -> {
			try {
				nodeStorageRepository.heatbeat();
			} catch (SQLException e) {
				log.warn(e.getMessage());
			}
		};	
		statusUpdateScheduler.scheduleAtFixedRate(statusUpdateTask, 0, config.getHeatbeatInterval(), TimeUnit.MILLISECONDS);
		
		Runnable catchUpTask = () -> {			
			int mailFlag = -1;
			try {
				mailFlag = nodeStorageRepository.getMyMailFlag();
			} catch (SQLException e) {
				log.error(e.getMessage());
			}
			if (mailFlag > 0) {
				doCatchUp();
			}	
		};		
		catchUpScheduler.scheduleAtFixedRate(catchUpTask, 0, config.getCatchUpInterval(), TimeUnit.MILLISECONDS);
	}
	
	@PreDestroy
	public void colse() {
		statusUpdateScheduler.shutdown();
		catchUpScheduler.shutdown();
	}
	
	private void doCatchUp() {	
		try {
			List<Long> catchUpSegmenIds = segmentLoadRepository.getMustCatchUpSegments();
			List<Catchup> mustCatchUps = catchupRepository.getMyCathupData(config.getId(), catchUpSegmenIds);

			for (Catchup cp : mustCatchUps) {
				try {
					if (cp.getChangeType() == 0) {
						SegmentWriter sw = new SegmentWriter(cp.getSegmentId(), cp.getBiometricsId());
						sw.writeSegmentHead();

					} else if (cp.getChangeType() == 1) {
						PBDmSyncRequest.Builder dmSegReq = PBDmSyncRequest.newBuilder();
						dmSegReq.setBioIdStart(cp.getBiometricsId());
						dmSegReq.setCmd(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_NEW);
						PBTargetSegmentVersion.Builder pt = PBTargetSegmentVersion.newBuilder();
						pt.setId(cp.getSegmentId());
						pt.setVersion(cp.getSegmentVersion());
						dmSegReq.setTargetSegment(pt.build());						
						SegmentWriter segWriter = NodeStorageManager.getSegmentWriter(cp.getSegmentId());
						Boolean result = Boolean.valueOf(segWriter.writeTemplate(dmSegReq.build()));

					} else if (cp.getChangeType() == 2) {

					} else if (cp.getChangeType() == 3) {

					}

				} catch (Exception e) {

				}

			}

		} catch (SQLException e) {

		}
		
	}
	
}
