
#create mysql tablespace

CREATE TABLESPACE UID_DM_CHANGE_LOG_DATA ADD DATAFILE 'uid_dm_change_log01.ibd' Engine=InnoDB;
CREATE TABLESPACE UID_DM_SEGMINT_INFO_DATA ADD DATAFILE 'uid_dm_segment_info01.ibd' Engine=InnoDB;
CREATE TABLESPACE UID_DM_COMPONENT_DATA ADD DATAFILE 'uid_dm_component_data01.ibd'  Engine=InnoDB;


