#create uid dm database

DROP DATABASE IF EXISTS DMDB;
CREATE DATABASE DMDB character set utf8mb4;
