package com.nec.aim.dm.monitor.utp;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;

public class UdpMulticastRceiver {
	private int multCastPort;
	private String multCastIP = "230.1.1.1";

	public void init() {
	}

	public void send() {
		MulticastSocket mcSocket = null;
		InetAddress mcIPAddress = null;
		try {
			mcIPAddress = InetAddress.getByName(multCastIP);
			mcSocket = new MulticastSocket(multCastPort);
			System.out.println("Multicast Receiver running at:" + mcSocket.getLocalSocketAddress());
			mcSocket.joinGroup(mcIPAddress);
			DatagramPacket packet = new DatagramPacket(new byte[1024], 1024);

			System.out.println("Waiting for a  multicast message...");
			mcSocket.receive(packet);
			String msg = new String(packet.getData(), packet.getOffset(), packet.getLength());
			System.out.println("[Multicast  Receiver] Received:" + msg);
			mcSocket.leaveGroup(mcIPAddress);

		} catch (Exception e) {
		} finally {
			mcSocket.close();
		}
	}

}
