package com.nec.aim.dm.monitor.utp;

import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public class UdpSender {
	private String host;
	private int port;
	
	public void init() {
		
	}
	public void sendSata() {
		 DatagramChannel datagramChannel = null;
		 try {
			 Charset charset =StandardCharsets.UTF_8;
             ByteBuffer byteBuffer = charset.encode("send data");
             datagramChannel = DatagramChannel.open();
             InetSocketAddress inetSocketAddress = new InetSocketAddress(host, port);                               
             datagramChannel.send(byteBuffer, inetSocketAddress);
		 } catch (Exception e) {
			 e.printStackTrace();
		 } finally {
			 datagramChannel.blockingLock();
		 }
	}
}
