package com.nec.aim.dm.monitor.dao;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nec.aim.dm.monitor.config.ConfigProperties;

@Repository
public class MasterDaoImpl implements MasterDao {
	private static final String setTokenSql = "update master set token =1, dm_master_id = ? where token=0 ";
	private static final String setTokenToZeroSql = "update master set token =0";
	
	@Autowired
    JdbcTemplate jdbcTemplate;
	
	@Autowired
	ConfigProperties config;


	@Override
	public int setToken() throws SQLException {
		int result = jdbcTemplate.update(setTokenSql, new Object[] {config.getDmId()}, int.class);		
		return result;
	}

	@Override
	public void setTokenToZero() throws SQLException {
		jdbcTemplate.update(setTokenToZeroSql, int.class);
	}

	@Override
	public DmInfo getMyDmInfo() throws SQLException {
		
		return null;
	}

}
