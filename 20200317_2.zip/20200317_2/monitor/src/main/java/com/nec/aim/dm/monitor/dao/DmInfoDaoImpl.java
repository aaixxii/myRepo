package com.nec.aim.dm.monitor.dao;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class DmInfoDaoImpl implements DmInfoDao {
	private static final String getDmInfoSql = "select * from dm_info where dm_id = ?";
	private static final String getAllMasterSql = "select * from dm_info where server_type = 'master'";
	
	@Autowired
    private JdbcTemplate jdbcTemplate;

	@Override
	public DmInfo getDmInfoByDmId(String dmId) throws SQLException {
		return jdbcTemplate.query(getDmInfoSql, new Object[] {dmId}, dmInfoMapper).get(0);
	}	
	
	RowMapper<DmInfo> dmInfoMapper = (rs, rowNum) -> {
		DmInfo dmInfo = new DmInfo();
		dmInfo.setDmId(rs.getString("dm_id"));
		dmInfo.setConnectionUrl("server_type");
		dmInfo.setHostName("server_hostname");
		dmInfo.setServerType("connection_url");
		return dmInfo;		
	};
	
	@Override
	public List<DmInfo> getAllDmMaster() throws SQLException {		
		List<DmInfo> masters = jdbcTemplate.queryForList(getAllMasterSql, DmInfo.class);
		return masters;
	}	
}
