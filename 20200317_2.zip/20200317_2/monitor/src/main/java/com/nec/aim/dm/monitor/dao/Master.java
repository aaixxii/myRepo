package com.nec.aim.dm.monitor.dao;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class Master {
	Integer token;
	String dmMasterId;
	Integer oneTimeInterval;
	Timestamp lastTs;
}
