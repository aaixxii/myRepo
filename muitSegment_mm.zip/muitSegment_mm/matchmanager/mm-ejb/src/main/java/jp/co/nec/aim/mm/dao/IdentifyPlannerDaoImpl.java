package jp.co.nec.aim.mm.dao;

import java.math.BigInteger;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import jp.co.nec.aim.mm.entities.ResourceUpdateCountEntity;
import jp.co.nec.aim.mm.entities.SegmentEntity;
import jp.co.nec.aim.mm.identify.planner.CombinedJobInfo;
import jp.co.nec.aim.mm.identify.planner.JobInfoFromDB;
import jp.co.nec.aim.mm.identify.planner.JobInfoFromDBComparator;
import jp.co.nec.aim.mm.identify.planner.MuCpuAndPressure;
import jp.co.nec.aim.mm.identify.planner.MuSegmentMap;
import jp.co.nec.aim.mm.identify.planner.SegmentIdAndVeison;
import jp.co.nec.aim.mm.identify.planner.TopJobInfo;
import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.procedure.GetJobInfoForCreatePlansProcedure;
import jp.co.nec.aim.mm.procedure.GetLimitedJobsByFamiliyProcedure;
import jp.co.nec.aim.mm.procedure.GetMuPressureAbilityProcedure;
import jp.co.nec.aim.mm.procedure.GetNewMuSegMapsProcedures;
import jp.co.nec.aim.mm.procedure.UpdateAfterPlannedProcedure;
import jp.co.nec.aim.mm.procedure.UpdateInquiryTrafficProcedure;
import jp.co.nec.aim.mm.util.StopWatch;

/**
 *
 * @author xiazp
 *
 */
public class IdentifyPlannerDaoImpl implements IdentifyPlannerDao {
	private GetJobInfoForCreatePlansProcedure getJobInfoForCreatePlansProcedure;
	private GetLimitedJobsByFamiliyProcedure getLimitedJobsByFamiliyProcedure;
	private GetMuPressureAbilityProcedure getMuPressureAbilityProcedure;
	private GetNewMuSegMapsProcedures getNewMuSegMapsProcedures;
	private UpdateAfterPlannedProcedure updateAfterPlannedProcedure;
	private UpdateInquiryTrafficProcedure updateInquiryTrafficProcedure;

	private EntityManager manager;
	private JdbcTemplate jdbcTemplate;
	private static Logger logger = LoggerFactory.getLogger(IdentifyPlannerDaoImpl.class);

	public IdentifyPlannerDaoImpl(DataSource dataSource, EntityManager manager) {
		this.manager = manager;
		this.jdbcTemplate = new JdbcTemplate(dataSource);
		getJobInfoForCreatePlansProcedure = new GetJobInfoForCreatePlansProcedure(dataSource);
		getLimitedJobsByFamiliyProcedure = new GetLimitedJobsByFamiliyProcedure(dataSource);
		getMuPressureAbilityProcedure = new GetMuPressureAbilityProcedure(dataSource);
		getNewMuSegMapsProcedures = new GetNewMuSegMapsProcedures(dataSource);
		updateAfterPlannedProcedure = new UpdateAfterPlannedProcedure(dataSource);
		updateInquiryTrafficProcedure = new UpdateInquiryTrafficProcedure(dataSource);

	}

	private static final String GET_SEGMENT_COUNT = "SELECT count(seg.SEGMENT_ID)" + " FROM SEGMENTS seg"
			+ " where seg.CONTAINER_ID =:containerId";

	private static final String GET_RUC = "select o from ResourceUpdateCountEntity o";
	private static final String DELEDE_RUC = "delete from RESOURCE_UPDATE_COUNT";
	private static final String INSERT_RUC = "insert into RESOURCE_UPDATE_COUNT(UPDATE_COUNT,UPDATE_TS) values(?,get_epoch_time_num())";

	private static final String GET_NEW_SEG_VERSION_BY_CONTAINER_ID = "select seg from SegmentEntity seg where seg.containerId =:containerId";

	private static final String GET_WORKING_MR = "select count(*) from MAP_REDUCERS where STATE = 'WORKING'";
	private static final String LOCK_JOB_ID_SQL = "select jq.JOB_ID from JOB_QUEUE jq where jq.JOB_ID= ?  and JOB_STATE = 0 for update";

	// private static final String LOCK_FOR_PLANNER =
	// "LOCK TABLE job_queue,mu_inquiry_load IN SHARE ROW EXCLUSIVE MODE";
	private static final String LOCK_FOR_PLANNER = "select NAME from MM_EVENTS where NAME = 'JOB_PLAPNER' for update";

	/**
	 *
	 */
	@Override
	public List<Long> getLimitedJobsByFamiliy() {
		try {
			List<Long> jobIds = getLimitedJobsByFamiliyProcedure.getLimitedJobsByFamiliy();
			return jobIds;
		} catch (DataAccessException | SQLException e) {
			logger.error(e.getMessage(), e);
			return null;
		}

	}

	/**
	 * @param containerId ,functionId
	 */
	@Override
	public List<MuSegmentMap> getNewMuSegMaps(Integer containerId, Integer functionId) {
		try {
			List<MuSegmentMap> results = getNewMuSegMapsProcedures.getNewMuSegMaps(containerId, functionId);
			return results;
		} catch (DataAccessException | SQLException e) {
			logger.error(e.getMessage(), e);
			return null;
		}
	}

	/**
	 * @param containerId
	 */
	@SuppressWarnings({ "unchecked" })
	@Override
	public List<SegmentEntity> getSegmentVersionByContainerId(long containerId)
			throws PersistenceException, SQLException {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		List<SegmentIdAndVeison> results = new ArrayList<>();
		Query q = manager.createQuery(GET_NEW_SEG_VERSION_BY_CONTAINER_ID);
		q.setParameter("containerId", containerId);
		List<SegmentEntity> temp = (List<SegmentEntity>) q.getResultList();
//		for (SegmentEntity seg : temp) {
//			SegmentIdAndVeison sv = new SegmentIdAndVeison();
//			sv.setSegmentId(seg.getSegmentId());
//			sv.setVersion(seg.getVersion());
//			results.add(sv);
//		}
		stopWatch.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "getSegmentVersionByContainerId", stopWatch.elapsedTime());
		return temp;
	}

	/**
	 * @param jobInfo
	 * @param plans
	 */
	@Override
	public Long updateAfterPlanned(Long topJobId, Long containerJobId) {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		try {
			Long results = updateAfterPlannedProcedure.executeUpdate(topJobId, containerJobId);
			return results;
		} catch (DataAccessException | SQLException e) {
			logger.error(e.getMessage(), e);
			return null;
		} finally {
			stopWatch.stop();
			PerformanceLogger.log(getClass().getSimpleName(), "updateAfterPlanned", stopWatch.elapsedTime());
		}
	}

	@Override
	public long getRUCFromDB() throws PersistenceException, SQLException {
		Query q = manager.createQuery(GET_RUC);
		ResourceUpdateCountEntity ruc = (ResourceUpdateCountEntity) q.getSingleResult();
		return ruc.getUpdateCount();
	}

	@Override
	public void setRUC(Long newRUC) throws DataAccessException, SQLException {
		jdbcTemplate.execute(DELEDE_RUC);
		jdbcTemplate.update(INSERT_RUC, new Object[] { newRUC });
		jdbcTemplate.execute("commit");
	}

	@Override
	public Integer getSegmentCount(Integer containerId) throws PersistenceException, SQLException {
		Query q = manager.createNativeQuery(GET_SEGMENT_COUNT);
		q.setParameter("containerId", containerId);
		BigInteger segCount = (BigInteger) q.getSingleResult();
		return Integer.valueOf(segCount.intValue());
	}

	@Override
	public List<MuCpuAndPressure> getMuCpuAndPressure(Set<Integer> muIds) {
		String streamStr = muIds.stream().map(one -> String.valueOf(one)).collect(Collectors.joining(","));
//		StringJoiner sj = new StringJoiner(",");
//		muIds.forEach(one ->{
//			sj.add(String.valueOf(one));
//		});

		try {
			List<MuCpuAndPressure> results = getMuPressureAbilityProcedure.getMuPressureAndAbility(streamStr);

			if (results == null || results.size() == 0 || (results.size() != muIds.size())) {
				return null;
			}
			return results;
		} catch (DataAccessException | SQLException e) {
			logger.error(e.getMessage(), e);
			return null;
		}
	}

	@Override
	public Integer getWorkingMR() throws PersistenceException, SQLException {
		Query q = manager.createNativeQuery(GET_WORKING_MR);
		BigInteger mrCount = (BigInteger) q.getSingleResult();
		return Integer.valueOf(mrCount.intValue());
	}

	@Override
	public List<JobInfoFromDB> getJobInfoForCreatePlans(Long[] jobIds) {
		try {
			List<JobInfoFromDB> results = getJobInfoForCreatePlansProcedure.getJobInfoFromDB(jobIds);
			if (results == null || results.size() == 0) {
				return null;
			}
			// List<TopJobInfo> jobsInfo = convert(results);
			return results;
		} catch (DataAccessException | SQLException e) {
			logger.error(e.getMessage(), e);
			return null;
		}
	}

	public List<TopJobInfo> convert(List<JobInfoFromDB> fromDBJobInfos) {
		Collections.sort(fromDBJobInfos, new JobInfoFromDBComparator());
		List<TopJobInfo> jobInfos = new ArrayList<TopJobInfo>();
		List<CombinedJobInfo> combinedJobIfos = new ArrayList<CombinedJobInfo>();
		int currentTopJobId = fromDBJobInfos.get(0).getTopJobId().intValue();

		int currentjob = 0;
		while (currentjob < fromDBJobInfos.size()) {
			if (fromDBJobInfos.get(currentjob).getTopJobId() == currentTopJobId) {
				JobInfoFromDB dbJobInfo = fromDBJobInfos.get(currentjob);
				CombinedJobInfo info = new CombinedJobInfo(dbJobInfo.getContainerId(), dbJobInfo.getFunctionId(),
						dbJobInfo.getContainerJobId());
				combinedJobIfos.add(info);
				currentjob++;
			} else {
				addTopJobInfo(fromDBJobInfos, jobInfos, combinedJobIfos, currentjob);
				currentTopJobId = fromDBJobInfos.get(currentjob).getTopJobId().intValue();
				combinedJobIfos = null;
				combinedJobIfos = new ArrayList<CombinedJobInfo>();
			}
			if (currentjob == fromDBJobInfos.size()) {
				addTopJobInfo(fromDBJobInfos, jobInfos, combinedJobIfos, currentjob);
			}
		}
		return jobInfos;
	}

	private void addTopJobInfo(List<JobInfoFromDB> fromDBJobInfos, List<TopJobInfo> jobInfos,
			List<CombinedJobInfo> combinedJobIfos, int currentjob) {
		TopJobInfo job = new TopJobInfo();
		JobInfoFromDB dbJobInfo = fromDBJobInfos.get(currentjob - 1);
		job.setTopJobId(dbJobInfo.getTopJobId());
		job.setFamilyId(dbJobInfo.getFamilyId());
		job.setCombinedJobInfoList(combinedJobIfos);
		jobInfos.add(job);
	}

	@Override
	public boolean updateInquiryTraffic(Integer jobCount) {
		try {
			updateInquiryTrafficProcedure.updateInquiryTraffic(jobCount);
		} catch (DataAccessException | SQLException e) {
			logger.error("An Exception occurred while update InquiryTraffic.", e);
			return false;
		}
		return true;
	}

	@Override
	public void lockJobQueueRowForProcess(Long topJobId) throws DataAccessException, SQLException {
		jdbcTemplate.queryForObject(LOCK_JOB_ID_SQL, new Object[] { topJobId }, Long.class);
	}

	@Override
	public void lockForIdentifyPlaner() throws DataAccessException {
		jdbcTemplate.update(LOCK_FOR_PLANNER);
	}
}
