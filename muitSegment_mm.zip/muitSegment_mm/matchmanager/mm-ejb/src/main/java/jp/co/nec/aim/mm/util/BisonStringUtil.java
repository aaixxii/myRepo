package jp.co.nec.aim.mm.util;

public class BisonStringUtil {

	public static String getRefIdFromUrl(String url) {
		String refId = url.substring(url.lastIndexOf("/") + 1);
		if (refId.length() > 36) {
			return refId.substring(0, 36);
		} else {
			return refId;
		}
	}

}
