/**this is file TemplateDataWrapper.java
 * @author xia
   @date 2020/11/25
 */
package jp.co.nec.aim.mm.dm.client;

/**
 * @author xia
 *
 */
public class TemplateDataWrapper {
	byte[] template;

	public byte[] getTemplate() {
		return template;
	}

	public void setTemplate(byte[] template) {
		this.template = template;
	}
	
	public TemplateDataWrapper() {
		
	}
	
	public TemplateDataWrapper(byte[] data) {
		template = new byte[data.length];
		template = data.clone();		
	}	
}


