package jp.co.nec.aim.mm.identify.dispatch;

import java.io.Serializable;
import java.util.List;

import jp.co.nec.aim.message.proto.AIMMessages.PBMapInquiryJobRequest;

public class InqJobInfo implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 3816271566433653882L;

	private List<Long> conjobids;
	private PBMapInquiryJobRequest mapInqJobReq;

	/**
	 * InqDistributorInfo constructor
	 */
	public InqJobInfo() {
	}

	public List<Long> getConjobids() {
		return conjobids;
	}

	public void setConjobids(List<Long> conjobids) {
		this.conjobids = conjobids;
	}

	public PBMapInquiryJobRequest getMapInqJobReq() {
		return mapInqJobReq;
	}

	public void setMapInqJobReq(PBMapInquiryJobRequest mapInqJobReq) {
		this.mapInqJobReq = mapInqJobReq;
	}

}
