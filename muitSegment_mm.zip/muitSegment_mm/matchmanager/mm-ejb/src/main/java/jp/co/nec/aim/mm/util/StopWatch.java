package jp.co.nec.aim.mm.util;

/**
 * StopWatch class <br/>
 * Caution: This class isn't thread safe. <br/>
 * 
 * Usage: <br/>
 * Instantiate -> start -> stop -> elapsedTime
 * 
 */
public class StopWatch {

	private static final int INITIAL_TIME = 0;

	private long startTime;
	private long stopTime;

	public StopWatch() {
		init();
	}

	public void start() {
		init();
		this.startTime = System.currentTimeMillis();
	}

	public void stop() {
		this.stopTime = System.currentTimeMillis();
	}

	public long elapsedTime() {
		return this.stopTime - this.startTime;
	}

	private void init() {
		this.startTime = INITIAL_TIME;
		this.stopTime = INITIAL_TIME;
	}

}
