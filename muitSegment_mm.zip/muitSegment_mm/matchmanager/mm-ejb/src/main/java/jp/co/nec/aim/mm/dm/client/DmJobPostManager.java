package jp.co.nec.aim.mm.dm.client;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.atomic.AtomicBoolean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.dm.message.proto.AimDmMessages.PBDmSyncRequest;
import jp.co.nec.aim.mm.dm.client.mgmt.UidDmJobRunManager;
import jp.co.nec.aim.mm.sessionbeans.SystemInitializationBean;
import jp.co.nec.aim.mm.util.JndiLookup;

import org.apache.commons.lang3.StringUtils;

/**
 * @author xia
 *
 */
public class DmJobPostManager {
	private static Logger logger = LoggerFactory.getLogger(DmJobPostManager.class);
	
	public static Boolean tryPostToDM(String requestId, PBDmSyncRequest dmSegReq) {
		Integer postResult = null;
		AtomicBoolean lastDbResult = new AtomicBoolean();
		postResult = postByLast(requestId, dmSegReq, lastDbResult);
		if (postResult.intValue() >= 0) {
			return Boolean.valueOf(lastDbResult.get());
		} else {
			AtomicBoolean dmListResult = new AtomicBoolean();
			postResult = tryPostIfAny(requestId, dmSegReq, dmListResult);
			if (postResult.intValue() >= 0) {
				return Boolean.valueOf(dmListResult.get());
			} else {
				logger.warn("Try post to all dms are failed, reload dm from db");
				SystemInitializationBean initEjb = JndiLookup.lookUp(
						jp.co.nec.aim.mm.constants.JNDIConstants.SystemInitializationBean, SystemInitializationBean.class);
				initEjb.getDmServiceSetting();
				return tryPostMoreOne(requestId, dmSegReq);
			}			
		}		
	}

	public static Integer postByLast(String requestId, PBDmSyncRequest dmSegReq, AtomicBoolean fSbResult) {
		Integer result = null;
		String lastDmUrl = UidDmJobRunManager.getLastActiveDmUrl();
		if (!StringUtils.isBlank(lastDmUrl)) {
			lastDmUrl = lastDmUrl.endsWith("/") ? lastDmUrl : lastDmUrl + "/";
			lastDmUrl = lastDmUrl + jp.co.nec.aim.mm.constants.Constants.dmSync;			
			int lastIndex = UidDmJobRunManager.getLastDM().get();
			int fResult = DmJobPoster.postByOneDm(lastDmUrl, dmSegReq, fSbResult, lastIndex);
			if (fResult >= 0) {
				//UidDmJobRunManager.updateDmList(lastIndex, 0);
				result =  Integer.valueOf(lastIndex);
			} else {
				UidDmJobRunManager.updateDmList(lastIndex, -1);
				result =  Integer.valueOf(-1);
			}
		} else {
			result =  Integer.valueOf(-1);
		}
		return result;
	}
	
	public static Integer tryPostIfAny(String requestId, PBDmSyncRequest dmSegReq, AtomicBoolean sbResult ) {
		//Integer result = null;			
		DmIndexInfo[] dmList = UidDmJobRunManager.getDM_LIST();		
		for (int i = 0; i < dmList.length; i++) {		
			String dmUrl = dmList[i].getUrl();
			if (dmUrl != null) {
				dmUrl = dmUrl.endsWith("/") ? dmUrl : dmUrl + "/";
				dmUrl = dmUrl + jp.co.nec.aim.mm.constants.Constants.dmSync;				
				int postResult = DmJobPoster.postByOneDm(dmUrl, dmSegReq, sbResult, i);
				if (postResult >= 0) {
					UidDmJobRunManager.setLastDM(i);
					UidDmJobRunManager.updateDmList(i, 0);
					return Integer.valueOf(i);					
				} else {
					UidDmJobRunManager.updateDmList(i, -1);					
				}
			} 
		}
		return Integer.valueOf(-1);
		
	}

	public static byte[] tryGetTemplateFromDm(Long segId, Long bioId) throws InterruptedException, ExecutionException {
		String lastDmUrl = UidDmJobRunManager.getLastActiveDmUrl();
		if (!StringUtils.isBlank(lastDmUrl)) {
			lastDmUrl = lastDmUrl.endsWith("/") ? lastDmUrl : lastDmUrl + "/";
			lastDmUrl = lastDmUrl + jp.co.nec.aim.mm.constants.Constants.dmGetTemplate;
			TemplateDataWrapper fSbResult = new TemplateDataWrapper();
			int lastDmIndex = UidDmJobRunManager.getLastDM().get();
			int fResult = DmJobPoster.getTemplateByOneDm(lastDmUrl, segId, bioId, lastDmIndex, fSbResult);
			if (fResult >= 0) {
				//UidDmJobRunManager.updateDmList(lastDmIndex, 0);
				logger.info("Post to lastDmUrl={} successed", lastDmUrl);
				return fSbResult.getTemplate();
			} else {
				UidDmJobRunManager.updateDmList(lastDmIndex, -1);
			}
		}
		DmIndexInfo[] dmList = UidDmJobRunManager.getDM_LIST();		
		for (int i = 0; i < dmList.length; i++) {
			String dmUrl = dmList[i].getUrl();
			if (!StringUtils.isBlank(dmUrl)) {
				dmUrl = dmUrl.endsWith("/") ? dmUrl : dmUrl + "/";
				dmUrl = dmUrl + jp.co.nec.aim.mm.constants.Constants.dmGetTemplate;
				TemplateDataWrapper sbResult = new TemplateDataWrapper();
				int postResult = DmJobPoster.getTemplateByOneDm(dmUrl, segId, bioId, i, sbResult);
				if (postResult >= 0) {
					UidDmJobRunManager.setLastDM(i);
					UidDmJobRunManager.updateDmList(i, 0);
					logger.info("Post to dmUrl={} successed", dmUrl);
					return sbResult.getTemplate();
				} else {
					UidDmJobRunManager.updateDmList(i, -1);
				}
			}
		}
		logger.warn("Try get template from all dms are failed, dmCount:{}, reload dm from db", dmList.length);
		SystemInitializationBean initEjb = JndiLookup.lookUp(
				jp.co.nec.aim.mm.constants.JNDIConstants.SystemInitializationBean, SystemInitializationBean.class);
		initEjb.getDmServiceSetting();
		return tryGetMoreOne(segId, bioId);
	}

	public static byte[] tryGetMoreOne(Long segId, Long bioId) {
		DmIndexInfo[] dmList = UidDmJobRunManager.getDM_LIST();		
		for (int i = 0; i < dmList.length; i++) {
			String dmUrl = dmList[i].getUrl();
			if (!StringUtils.isBlank(dmUrl)) {
				dmUrl = dmUrl.endsWith("/") ? dmUrl : dmUrl + "/";
				dmUrl = dmUrl + jp.co.nec.aim.mm.constants.Constants.dmGetTemplate;
				TemplateDataWrapper sbResult = new TemplateDataWrapper();
				Integer postResult = null;
				try {
					postResult = DmJobPoster.getTemplateByOneDm(dmUrl, segId, bioId, i, sbResult);
				} catch (InterruptedException | ExecutionException e) {
					logger.error(e.getMessage(), e);
					postResult = -1;
				}
				if (postResult >= 0) {
					UidDmJobRunManager.setLastDM(i);
					UidDmJobRunManager.updateDmList(i, 0);
					logger.info("Post to dmUrl={} successed", dmUrl);
					return sbResult.getTemplate();
				} else {
					UidDmJobRunManager.updateDmList(i, -1);
				}
			}
		}
		return null;
	}

	public static Boolean tryPostMoreOne(String requestId, PBDmSyncRequest dmSegReq) {
		DmIndexInfo[] dmList = UidDmJobRunManager.getDM_LIST();		
		for (int i = 0; i < dmList.length; i++) {
			String dmUrl = dmList[i].getUrl();
			if (!StringUtils.isBlank(dmUrl)) {
				dmUrl = dmUrl.endsWith("/") ? dmUrl : dmUrl + "/";
				dmUrl = dmUrl + jp.co.nec.aim.mm.constants.Constants.dmSync;
				AtomicBoolean sbResult = new AtomicBoolean();
				int postResult = DmJobPoster.postByOneDm(dmUrl, dmSegReq, sbResult, i);
				if (postResult >= 0) {
					UidDmJobRunManager.setLastDM(i);
					UidDmJobRunManager.updateDmList(i, 0);
					return Boolean.valueOf(sbResult.get());
				} else {
					UidDmJobRunManager.updateDmList(i, -1);
				}
			}
		}
		return Boolean.valueOf(false);
	}
}
