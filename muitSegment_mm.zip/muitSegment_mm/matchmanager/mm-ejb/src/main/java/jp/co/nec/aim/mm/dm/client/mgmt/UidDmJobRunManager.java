package jp.co.nec.aim.mm.dm.client.mgmt;

import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantLock;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.dm.client.DmIndexInfo;
import jp.co.nec.aim.mm.entities.DmServiceEntity;

public class UidDmJobRunManager {

	private static Logger logger = LoggerFactory.getLogger(UidDmJobRunManager.class);
	private static ExecutorService dmJobExecutor = Executors.newCachedThreadPool();

	private static ReentrantLock lastDmLock = new ReentrantLock();
	private static ReentrantLock dmListLock = new ReentrantLock();

	private static DmIndexInfo DM_LIST[];
	private static AtomicInteger LastDM = new AtomicInteger();

	public static int readDmToArray(List<DmServiceEntity> dmsList) {
		dmListLock.lock();
		try {
			DM_LIST = new DmIndexInfo[dmsList.size()];
			for (int i = 0; i < dmsList.size(); i++) {
				DmServiceEntity one = dmsList.get(i);
				DmIndexInfo dmIndexInfo = new DmIndexInfo();
				dmIndexInfo.setDmId(one.getDmId());
				dmIndexInfo.setUrl(one.getContactUrl());
				dmIndexInfo.setActive(0);
				DM_LIST[i] = dmIndexInfo;
			}
			setLastDM(0);
			logger.info("dmList size = {}", DM_LIST.length);
			return DM_LIST.length;
		} finally {
			dmListLock.unlock();
		}
		
	}

//	public static void updateDmList(String url, int active) {
//		dmListLock.lock();
//		try {
//			for (int i = 0; i < DM_LIST.length; i++) {
//				if (DM_LIST[i].getUrl().equals(url)) {
//					DM_LIST[i].setActive(active);
//					break;
//				}
//			}
//			
//		} finally {
//			dmListLock.unlock();
//		}
//	}
	
	public static void updateDmList(int index, int active) {
		dmListLock.lock();
		try {
			DM_LIST[index].setActive(active);
		} finally {
			dmListLock.unlock();
		}
	}	

	public static DmIndexInfo[] getDM_LIST() {
		dmListLock.lock();
		try {
			return DM_LIST;
		} finally {
			dmListLock.unlock();
		}
	}

	public static void setDM_LIST(DmIndexInfo[] dM_LIST) {
		dmListLock.lock();
		try {
			DM_LIST = dM_LIST;
		} finally {
			dmListLock.unlock();
		}
	}

	public static String getLastActiveDmUrl() {
		lastDmLock.lock();
		try {
			if (LastDM.get() == -1) {
				logger.warn("LastDM position is -1");
				return null;
			}			
			return DM_LIST[LastDM.get()].getUrl();

		} finally {
			lastDmLock.unlock();
		}
	}

	public static void submitRunnable(Runnable task) {
		dmJobExecutor.submit(task);
	}

	public static Boolean sumitDmJob(Callable<Boolean> task) {
		Future<Boolean> future = dmJobExecutor.submit(task);
		try {
			return future.get();
		} catch (InterruptedException | ExecutionException e) {
			logger.error(e.getMessage(), e);
			return Boolean.FALSE;
		}
	}

	public static <T> CompletableFuture<T> callableAsync(Callable<T> c) {
		CompletableFuture<T> cf = new CompletableFuture<>();
		dmJobExecutor.execute(() -> {
			try {
				cf.complete(c.call());

			} catch (Throwable ex) {
				cf.completeExceptionally(ex);
			}
		});
		return cf;
	}

	public static Boolean submit(Callable<Boolean> c) throws InterruptedException, ExecutionException {
		CompletableFuture<Boolean> cf = new CompletableFuture<>();
		dmJobExecutor.execute(() -> {
			try {
				cf.complete(c.call());
			} catch (Throwable ex) {
				cf.completeExceptionally(ex);
			}
		});
		return cf.get();
	}

	public static Integer submitAndReturnInteger(Callable<Integer> c) throws InterruptedException, ExecutionException {
		CompletableFuture<Integer> cf = new CompletableFuture<>();
		dmJobExecutor.execute(() -> {
			try {
				cf.complete(c.call());
			} catch (Throwable ex) {
				cf.completeExceptionally(ex);
			}
		});
		return cf.get();
	}

	public static byte[] submitGetRequest(Callable<byte[]> c) throws InterruptedException, ExecutionException {
		CompletableFuture<byte[]> cf = new CompletableFuture<>();
		dmJobExecutor.execute(() -> {
			try {
				cf.complete(c.call());
			} catch (Throwable ex) {
				cf.completeExceptionally(ex);
			}
		});
		return cf.get();
	}
	
	public static Integer submitGetRequestByOne(Callable<Integer> c) throws InterruptedException, ExecutionException {
		CompletableFuture<Integer> cf = new CompletableFuture<>();
		dmJobExecutor.execute(() -> {
			try {
				cf.complete(c.call());
			} catch (Throwable ex) {
				cf.completeExceptionally(ex);
			}
		});
		return cf.get();
	}	

	public static void shutdown() {
		dmJobExecutor.shutdownNow();
		while (!dmJobExecutor.isShutdown()) {
			try {
				dmJobExecutor.awaitTermination(100, TimeUnit.MILLISECONDS);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * @return the lastDM
	 */
	public static AtomicInteger getLastDM() {
		lastDmLock.lock();
		try {
			return LastDM;
		} finally {
			lastDmLock.unlock();
		}
		
	}

	/**
	 * @param lastDM
	 *            the lastDM to set
	 */
	public static void setLastDM(int lastDM) {
		lastDmLock.lock();
		try {
			LastDM.set(lastDM);			
		} finally {
			lastDmLock.unlock();
		}		
	}

	/**
	 * @return
	 */
	public static String getOneActiveDm() {	
		dmListLock.lock();
		try {
			if (LastDM.get() != -1 ) {
				 return DM_LIST[LastDM.get()].getUrl();
			} else {
				String result = null;
				for (DmIndexInfo element : DM_LIST) {
					if (element.getActive() >= 0)
						result = element.getUrl();
					break;
				}
				return result;				
			}
		} finally {
			dmListLock.unlock();
		}
	}
}
