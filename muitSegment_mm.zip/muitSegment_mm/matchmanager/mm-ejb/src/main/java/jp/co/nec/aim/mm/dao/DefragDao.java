package jp.co.nec.aim.mm.dao;

import javax.sql.DataSource;

import jp.co.nec.aim.mm.exception.AimRuntimeException;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * @author mozj
 */
public class DefragDao {

	/**
	 * execute 'ALTER SYSTEM CHECKPOINT LOCAL' in DB
	 * 
	 * @param dataSource
	 */
	public void defrag(DataSource dataSource) {
		try {
			JdbcTemplate template = new JdbcTemplate(dataSource);
			template.execute("ALTER SYSTEM CHECKPOINT LOCAL");
		} catch (DataAccessException e) {
			throw new AimRuntimeException(e);
		}
	}

}
