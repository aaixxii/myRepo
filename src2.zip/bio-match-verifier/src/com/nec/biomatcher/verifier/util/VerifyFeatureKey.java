package com.nec.biomatcher.verifier.util;

import com.nec.biomatcher.spec.transfer.model.AlgorithmType;
import com.nec.biomatcher.spec.transfer.model.ImagePosition;

/**
 * The Class VerifyFeatureKey.
 */
public class VerifyFeatureKey {

	/** The candidate id. */
	private String candidateId;

	private String eventId;

	/** The container id. */
	private Integer containerId;

	/** The position. */
	protected ImagePosition position;

	/** The algorithm type. */
	protected AlgorithmType algorithmType;

	/**
	 * Instantiates a new verify feature key.
	 */
	public VerifyFeatureKey() {
	}

	/**
	 * Instantiates a new verify feature key.
	 *
	 * @param candidateId
	 *            the candidate id
	 * @param containerId
	 *            the container id
	 * @param position
	 *            the position
	 * @param algorithmType
	 *            the algorithm type
	 */
	public VerifyFeatureKey(String candidateId, Integer containerId, ImagePosition position,
			AlgorithmType algorithmType) {
		this(candidateId, null, containerId, position, algorithmType);
	}

	public VerifyFeatureKey(String candidateId, String eventId, Integer containerId, ImagePosition position,
			AlgorithmType algorithmType) {
		this.candidateId = candidateId;
		this.eventId = eventId;
		this.containerId = containerId;
		this.position = position;
		this.algorithmType = algorithmType;
	}

	public String getCandidateId() {
		return candidateId;
	}

	public void setCandidateId(String candidateId) {
		this.candidateId = candidateId;
	}

	public Integer getContainerId() {
		return containerId;
	}

	public void setContainerId(Integer containerId) {
		this.containerId = containerId;
	}

	public ImagePosition getPosition() {
		return position;
	}

	public void setPosition(ImagePosition position) {
		this.position = position;
	}

	public AlgorithmType getAlgorithmType() {
		return algorithmType;
	}

	public void setAlgorithmType(AlgorithmType algorithmType) {
		this.algorithmType = algorithmType;
	}

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}
}
