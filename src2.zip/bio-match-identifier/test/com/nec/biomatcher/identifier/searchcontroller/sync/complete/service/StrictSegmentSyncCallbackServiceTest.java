package com.nec.biomatcher.identifier.searchcontroller.sync.complete.service;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.junit.Assert;
import org.junit.Test;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherNodeSegmentInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherSegmentInfo;

public class StrictSegmentSyncCallbackServiceTest {

	private ConcurrentHashMap<StrictSyncCallbackKey, List<SyncSnSegVerInfo>> strictSyncCallbackMap = new ConcurrentHashMap<>();
	private ConcurrentHashMap<SegIdBinKey, List<SyncSnSegVerInfo>> preSnSegVerMap = new ConcurrentHashMap<>();

	@SuppressWarnings("unchecked")
	@Test
	public void testGson_bug() {
		Map<Integer, Long> newSegmentIdVersionMap = new HashMap<>();
		newSegmentIdVersionMap.put(Integer.valueOf(100), 1000L);
		newSegmentIdVersionMap.put(Integer.valueOf(200), 2000L);
		newSegmentIdVersionMap.put(Integer.valueOf(300), 3000L);
		newSegmentIdVersionMap.put(Integer.valueOf(400), 4000L);
		newSegmentIdVersionMap.put(Integer.valueOf(500), 5000L);
		Gson gson = new Gson();
		String updateSegInfos = gson.toJson(newSegmentIdVersionMap);
		Map<Integer, Long> snReportMap = new HashMap<>();
		snReportMap = gson.fromJson(updateSegInfos, snReportMap.getClass());
		Assert.assertEquals(snReportMap.size(), 5);

		updateSegInfos = "SyncJobId00001" + "#" + updateSegInfos;
		int index = updateSegInfos.indexOf("#");
		String snId = updateSegInfos.substring(0, index);
		Assert.assertTrue("SyncJobId00001".equals(snId));
		String jsonMapString = updateSegInfos.substring(index + 1, updateSegInfos.length());

		Map<Integer, Long> jsonMap = new HashMap<>();
		jsonMap = gson.fromJson(jsonMapString, jsonMap.getClass());
		Assert.assertEquals(5, jsonMap.size());
		Iterator<Entry<Integer, Long>> it = jsonMap.entrySet().iterator();
		while (it.hasNext()) {
			Entry<Integer, Long> tmp = it.next();
			Object yy = tmp.getKey();
			Integer intYY = Integer.valueOf(yy.toString());
			System.out.println(intYY);
		}
	}

	@Test
	public void testGson_ok() {
		Map<Integer, Long> newSegmentIdVersionMap = new HashMap<>();
		newSegmentIdVersionMap.put(Integer.valueOf(100), 1000L);
		newSegmentIdVersionMap.put(Integer.valueOf(200), 2000L);
		newSegmentIdVersionMap.put(Integer.valueOf(300), 3000L);
		newSegmentIdVersionMap.put(Integer.valueOf(400), 4000L);
		newSegmentIdVersionMap.put(Integer.valueOf(500), 5000L);
		Gson objGson = new GsonBuilder().setPrettyPrinting().create();
		Type mapType = new TypeToken<Map<Integer, Long>>() {
		}.getType();
		String mapToJson = objGson.toJson(newSegmentIdVersionMap, mapType);

		Map<Integer, Long> jsonToMap = objGson.fromJson(mapToJson, mapType);
		Assert.assertEquals(1000l, jsonToMap.get(100).longValue());
		jsonToMap.entrySet().forEach(e -> {
			System.out.println(e.getKey());
			System.out.println(e.getValue());
		});
	}

	@Test
	public void testCreatePreSnSegVerMap() {
		List<BioMatcherSegmentInfo> allSegInfoList = new ArrayList<>();
		BioMatcherSegmentInfo segInfo1 = new BioMatcherSegmentInfo();

		segInfo1.setBinId(35);
		segInfo1.setSegmentId(1000);
		segInfo1.setSegmentVersion(1L);
		segInfo1.setUpdateDateTime(new Date());

		BioMatcherSegmentInfo segInfo2 = new BioMatcherSegmentInfo();
		segInfo2.setBinId(35);
		segInfo2.setSegmentId(2000);
		segInfo2.setSegmentVersion(2L);
		segInfo2.setUpdateDateTime(new Date());

		allSegInfoList.add(segInfo1);
		allSegInfoList.add(segInfo2);

		List<BioMatcherNodeSegmentInfo> snSegInfoList = new ArrayList<>();
		BioMatcherNodeSegmentInfo snInfo1 = new BioMatcherNodeSegmentInfo();

		snInfo1.setMatcherNodeId("sn1");
		snInfo1.setAssignedFlag(Boolean.TRUE);
		snInfo1.setSegmentId(1000);
		snInfo1.setSegmentVersion(-1L);

		BioMatcherNodeSegmentInfo snInfo2 = new BioMatcherNodeSegmentInfo();
		snInfo2.setMatcherNodeId("sn2");
		snInfo2.setAssignedFlag(Boolean.TRUE);
		snInfo2.setSegmentId(1000);
		snInfo2.setSegmentVersion(-1L);

		BioMatcherNodeSegmentInfo snInfo3 = new BioMatcherNodeSegmentInfo();
		snInfo3.setMatcherNodeId("sn3");
		snInfo3.setAssignedFlag(Boolean.TRUE);
		snInfo3.setSegmentId(2000);
		snInfo3.setSegmentVersion(-1L);

		BioMatcherNodeSegmentInfo snInfo4 = new BioMatcherNodeSegmentInfo();
		snInfo4.setMatcherNodeId("sn4");
		snInfo4.setAssignedFlag(Boolean.TRUE);
		snInfo4.setSegmentId(2000);
		snInfo4.setSegmentVersion(-1L);

		snSegInfoList.add(snInfo1);
		snSegInfoList.add(snInfo2);
		snSegInfoList.add(snInfo3);
		snSegInfoList.add(snInfo4);

		ConcurrentHashMap<SegIdBinKey, List<SyncSnSegVerInfo>> preSnSegVerMap = new ConcurrentHashMap<>();
		allSegInfoList.parallelStream().forEach(bioMatcherSegmentInfo -> {
			Integer binId = bioMatcherSegmentInfo.getBinId();
			Integer segId = bioMatcherSegmentInfo.getSegmentId();
			preSnSegVerMap.put(new SegIdBinKey(segId, binId), getSyncSnSegVerInfo(segId, binId, snSegInfoList));
		});

		Assert.assertEquals(2, preSnSegVerMap.size());
		Set<Entry<SegIdBinKey, List<SyncSnSegVerInfo>>> tmp = preSnSegVerMap.entrySet();
		for (Entry<SegIdBinKey, List<SyncSnSegVerInfo>> one : tmp) {
			Assert.assertEquals(2, one.getValue().size());
		}
		System.out.println("OKOKOK");
	}

	@Test
	public void testGetKeyBySnIdSegId() {
		preSnSegVerMap.clear();
		List<SyncSnSegVerInfo> seg9VerInfos = new ArrayList<>();
		SyncSnSegVerInfo sn1 = new SyncSnSegVerInfo();
		sn1.setBinId(Integer.valueOf(35));
		sn1.setSegmentId(Integer.valueOf(9));
		sn1.setSnNodeId("SN001");
		sn1.setSegmentVersion(1000L);
		sn1.setIsSyncCompelted(Boolean.FALSE);
		seg9VerInfos.add(sn1);
		SegIdBinKey key = new SegIdBinKey(Integer.valueOf(9), Integer.valueOf(35));
		preSnSegVerMap.put(key, seg9VerInfos);

		List<SyncSnSegVerInfo> seg10VerInfos = new ArrayList<>();
		SyncSnSegVerInfo sn2 = new SyncSnSegVerInfo();
		sn2.setBinId(Integer.valueOf(36));
		sn2.setSegmentId(Integer.valueOf(10));
		sn2.setSnNodeId("SN001");
		sn2.setSegmentVersion(2000L);
		sn2.setIsSyncCompelted(Boolean.FALSE);
		seg10VerInfos.add(sn2);
		SegIdBinKey key2 = new SegIdBinKey(Integer.valueOf(10), Integer.valueOf(36));
		preSnSegVerMap.put(key2, seg10VerInfos);

		strictSyncCallbackMap.clear();
		StrictSyncCallbackKey key5 = new StrictSyncCallbackKey("SC-JOB1", "142028975", "1927258727",
				"http://127.0.0.1:8888");
		List<SyncSnSegVerInfo> segVerInfos = new ArrayList<>();
		SyncSnSegVerInfo sn5 = new SyncSnSegVerInfo();
		// sn1.setBinId(Integer.valueOf(35));
		sn5.setSegmentId(Integer.valueOf(9));
		sn5.setSnNodeId("SN001");
		sn5.setSegmentVersion(1000L);
		sn5.setIsSyncCompelted(Boolean.FALSE);
		segVerInfos.add(sn5);

		SyncSnSegVerInfo sn6 = new SyncSnSegVerInfo();
		sn6.setBinId(Integer.valueOf(36));
		sn6.setSegmentId(Integer.valueOf(10));
		sn6.setSnNodeId("SN001");
		sn6.setSegmentVersion(2000L);
		sn6.setIsSyncCompelted(Boolean.FALSE);
		segVerInfos.add(sn6);
		strictSyncCallbackMap.put(key5, segVerInfos);

		StrictSyncCallbackKey mainKey = getKeyBySnIdSegId("SN001", 9);
		System.out.println(mainKey.getCallbackUrl());
		Assert.assertNotNull(key);
	}

	@Test
	public void testGetKeyBySnSegInfo() {
		createPreSnSegVerMap();
		createStrcitMap();
		StrictSyncCallbackKey key = getKeyBySnSegInfo("SN001", 35, 9);
		System.out.println(key.getCallbackUrl());
		Assert.assertNotNull(key);

	}

	@Test
	public void testGetKeyByJobId() {
		createPreSnSegVerMap();
		createStrcitMap();
		StrictSyncCallbackKey key = getKeyByJobId("SC-JOB1");
		System.out.println(key.getCallbackUrl());
		Assert.assertNotNull(key);
	}

	@Test
	public void testTemplateDataMap1() {
		Map<String, byte[]> templateDataMap = null;
		List<TemplateInfo> templateInfos = new ArrayList<>();
		templateInfos.add(new TemplateInfo("type35", "type35data1data1".getBytes()));
		templateInfos.add(new TemplateInfo("type35", "type35data2data2".getBytes()));
		templateInfos.add(new TemplateInfo("type36", "type36data2data2".getBytes()));
		templateInfos.add(new TemplateInfo("type36", "type36data2data2".getBytes()));

		templateDataMap = templateInfos.stream()
				.collect(Collectors.toMap(TemplateInfo::getType, TemplateInfo::getData, (s1, s2) -> s2));
		System.out.println(templateDataMap.size());
	}

	@Test
	public void testTemplateDataMap2() {
		Map<String, byte[]> templateDataMap = null;
		List<TemplateInfo> templateInfos = new ArrayList<>();
		templateInfos.add(new TemplateInfo("type35", "type35data1data1".getBytes()));
		templateInfos.add(new TemplateInfo("type35", "type35data2data2".getBytes()));

		templateDataMap = templateInfos.stream()
				.collect(Collectors.toMap(TemplateInfo::getType, TemplateInfo::getData, (s1, s2) -> s2));
		System.out.println(templateDataMap.size());
		System.out.println(new String(templateDataMap.entrySet().iterator().next().getValue()));
	}

	@Test
	public void testTemplateDataMap3() {
		Map<String, byte[]> templateDataMap = null;
		List<TemplateInfo> templateInfos = new ArrayList<>();
		templateInfos.add(new TemplateInfo("type35", "type35data1data1".getBytes()));
		templateInfos.add(new TemplateInfo("type35", "type35data2data2".getBytes()));

		templateDataMap = templateInfos.stream()
				.collect(Collectors.toMap(TemplateInfo::getType, TemplateInfo::getData, (s1, s2) -> s1));
		System.out.println(templateDataMap.size());
		System.out.println(new String(templateDataMap.entrySet().iterator().next().getValue()));
	}

	@Test
	public void testTemplateDataMap4() {
		Map<String, byte[]> templateDataMap = new HashMap<>();
		templateDataMap.put(new String("type35"), "type35data1data1".getBytes());
		templateDataMap.put(new String("type35"), "type35data2data2".getBytes());
		System.out.println(templateDataMap.size());
		System.out.println(new String(templateDataMap.entrySet().iterator().next().getValue()));
	}

	private void createPreSnSegVerMap() {
		preSnSegVerMap.clear();
		List<SyncSnSegVerInfo> seg9VerInfos = new ArrayList<>();
		SyncSnSegVerInfo sn1 = new SyncSnSegVerInfo();
		sn1.setBinId(Integer.valueOf(35));
		sn1.setSegmentId(Integer.valueOf(9));
		sn1.setSnNodeId("SN001");
		sn1.setSegmentVersion(1000L);
		sn1.setIsSyncCompelted(Boolean.FALSE);
		seg9VerInfos.add(sn1);
		SegIdBinKey key = new SegIdBinKey(Integer.valueOf(9), Integer.valueOf(35));
		preSnSegVerMap.put(key, seg9VerInfos);

		List<SyncSnSegVerInfo> seg10VerInfos = new ArrayList<>();
		SyncSnSegVerInfo sn2 = new SyncSnSegVerInfo();
		sn2.setBinId(Integer.valueOf(36));
		sn2.setSegmentId(Integer.valueOf(10));
		sn2.setSnNodeId("SN001");
		sn2.setSegmentVersion(2000L);
		sn2.setIsSyncCompelted(Boolean.FALSE);
		seg10VerInfos.add(sn2);
		SegIdBinKey key2 = new SegIdBinKey(Integer.valueOf(10), Integer.valueOf(36));
		preSnSegVerMap.put(key2, seg10VerInfos);
	}

	private void createStrcitMap() {
		strictSyncCallbackMap.clear();
		StrictSyncCallbackKey key = new StrictSyncCallbackKey("SC-JOB1", "142028975", "1927258727",
				"http://127.0.0.1:8888");
		List<SyncSnSegVerInfo> segVerInfos = new ArrayList<>();
		SyncSnSegVerInfo sn1 = new SyncSnSegVerInfo();
		sn1.setBinId(Integer.valueOf(35));
		sn1.setSegmentId(Integer.valueOf(9));
		sn1.setSnNodeId("SN001");
		sn1.setSegmentVersion(1000L);
		sn1.setIsSyncCompelted(Boolean.FALSE);
		segVerInfos.add(sn1);

		SyncSnSegVerInfo sn2 = new SyncSnSegVerInfo();
		sn2.setBinId(Integer.valueOf(36));
		sn2.setSegmentId(Integer.valueOf(10));
		sn2.setSnNodeId("SN001");
		sn2.setSegmentVersion(2000L);
		sn2.setIsSyncCompelted(Boolean.FALSE);
		segVerInfos.add(sn2);
		strictSyncCallbackMap.put(key, segVerInfos);
	}

	private StrictSyncCallbackKey getKeyByJobId(String jobId) {
		Optional<Entry<StrictSyncCallbackKey, List<SyncSnSegVerInfo>>> result = strictSyncCallbackMap.entrySet()
				.parallelStream().filter(entry -> entry.getKey().getSyncJobId().equals(jobId)).findAny();
		if (result.isPresent()) {
			return result.get().getKey();
		} else {
			return null;
		}
	}

	private StrictSyncCallbackKey getKeyBySnSegInfo(String snId, Integer binId, Integer segId) {
		final StrictSyncCallbackKey key = new StrictSyncCallbackKey();
		Predicate<SyncSnSegVerInfo> predicate = info -> info.getBinId().intValue() == binId.intValue()
				&& info.getSegmentId().intValue() == segId.intValue() && info.getSnNodeId().equals(snId);
		strictSyncCallbackMap.entrySet().stream().forEach(entry -> {
			if (entry.getValue().stream().filter(predicate).findAny().isPresent()) {
				key.setCallbackUrl(entry.getKey().getCallbackUrl());
				key.setSyncJobId(entry.getKey().getSyncJobId());
				key.setSyncJobId(entry.getKey().getSyncJobId());
				key.setEventId(entry.getKey().getEventId());
				key.setExternalId(entry.getKey().getExternalId());
			}
		});
		return key;
	}

	private StrictSyncCallbackKey getKeyBySnIdSegId(String snId, Integer segId) {
		final StrictSyncCallbackKey key = new StrictSyncCallbackKey();
		Predicate<SyncSnSegVerInfo> predicate = info -> info.getSegmentId().intValue() == segId.intValue()
				&& info.getSnNodeId().equals(snId);
		strictSyncCallbackMap.entrySet().stream().forEach(entry -> {
			if (entry.getValue().stream().filter(predicate).findAny().isPresent()) {
				key.setCallbackUrl(entry.getKey().getCallbackUrl());
				key.setSyncJobId(entry.getKey().getSyncJobId());
				key.setSyncJobId(entry.getKey().getSyncJobId());
				key.setEventId(entry.getKey().getEventId());
				key.setExternalId(entry.getKey().getExternalId());
			}
		});
		return key;
	}

	private List<SyncSnSegVerInfo> getSyncSnSegVerInfo(Integer segmentId, Integer binId,
			List<BioMatcherNodeSegmentInfo> snSegInfoList) {
		List<SyncSnSegVerInfo> snSegVerInfos = new ArrayList<>();
		AtomicInteger count = new AtomicInteger(0);
		for (BioMatcherNodeSegmentInfo info : snSegInfoList) {
			if (info.getSegmentId().equals(segmentId) && info.getAssignedFlag().booleanValue()) {
				SyncSnSegVerInfo snSegInfo = new SyncSnSegVerInfo(info.getMatcherNodeId(), binId, info.getSegmentId(),
						info.getSegmentVersion(), Boolean.FALSE);
				snSegVerInfos.add(snSegInfo);
				count.incrementAndGet();
				if (count.intValue() >= 2) {
					break;
				}
			}
		}
		return snSegVerInfos;
	}

}
