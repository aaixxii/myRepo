package com.nec.biomatcher.identifier.util;

import java.util.Comparator;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListSet;

public class SearchNodeIdSegmentIdMatrix {
	public static final SegmentIdComparator segmentIdComparator = new SegmentIdComparator();

	private static final ConcurrentHashMap<String, ConcurrentSkipListSet<Integer>> searchNodeIdSegmentIdMatrix = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<Integer, Set<String>> segmentIdSearchNodeIdMatrix = new ConcurrentHashMap<>();

	private static final ConcurrentHashMap<String, Set<Integer>> oldSearchNodeIdSegmentIdSetRefMap = new ConcurrentHashMap<>();

	public static final ConcurrentSkipListSet<Integer> updateMatrix(String searchNodeId, Set<Integer> segmentIdSet) {
		ConcurrentSkipListSet<Integer> currentSegmentIdSet = getSegmentIdSetBySearchNodeId(searchNodeId);

		if (oldSearchNodeIdSegmentIdSetRefMap.get(searchNodeId) == segmentIdSet) {
			return currentSegmentIdSet;
		}
		synchronized (searchNodeId.intern()) {
			if (oldSearchNodeIdSegmentIdSetRefMap.get(searchNodeId) == segmentIdSet) {
				return currentSegmentIdSet;
			}

			segmentIdSet.forEach(segmentId -> {
				Set<String> currentSearchNodeIdSet = getSearchNodeIdSetBySegmentId(segmentId);
				if (currentSearchNodeIdSet.add(searchNodeId)) {
					currentSegmentIdSet.remove(segmentId);
					currentSegmentIdSet.add(segmentId);
				}
			});

			currentSegmentIdSet.forEach(segmentId -> {
				if (!segmentIdSet.contains(segmentId)) {
					if (currentSegmentIdSet.remove(segmentId)) {
						segmentIdSearchNodeIdMatrix.computeIfPresent(segmentId, (segmentIdKey, searchNodeIdSet) -> {
							if (searchNodeIdSet != null) {
								searchNodeIdSet.remove(searchNodeId);
							}
							return searchNodeIdSet;
						});
					}
				}
			});

			oldSearchNodeIdSegmentIdSetRefMap.put(searchNodeId, segmentIdSet);
		}

		return currentSegmentIdSet;
	}

	private static final Set<String> getSearchNodeIdSetBySegmentId(Integer segmentId) {
		Set<String> currentSearchNodeIdSet = segmentIdSearchNodeIdMatrix.get(segmentId);
		if (currentSearchNodeIdSet == null) {
			currentSearchNodeIdSet = segmentIdSearchNodeIdMatrix.computeIfAbsent(segmentId,
					segmentIdKey -> ConcurrentHashMap.newKeySet());
		}
		return currentSearchNodeIdSet;
	}

	public static final ConcurrentSkipListSet<Integer> getSegmentIdSetBySearchNodeId(String searchNodeId) {
		ConcurrentSkipListSet<Integer> currentSegmentIdSet = searchNodeIdSegmentIdMatrix.get(searchNodeId);
		if (currentSegmentIdSet == null) {
			currentSegmentIdSet = searchNodeIdSegmentIdMatrix.computeIfAbsent(searchNodeId,
					searchNodeIdKey -> new ConcurrentSkipListSet<>(segmentIdComparator));
		}
		return currentSegmentIdSet;
	}

	public static final class SegmentIdComparator implements Comparator<Integer> {

		@Override
		public int compare(Integer segmentId1, Integer segmentId2) {
			int segmentIdCompareValue = Integer.compare(segmentId1, segmentId2);
			if (segmentIdCompareValue == 0) {
				return 0;
			}

			int segmentId1SnCount = getSearchNodeIdSetBySegmentId(segmentId1).size();
			int segmentId2SnCount = getSearchNodeIdSetBySegmentId(segmentId2).size();

			return (segmentId1SnCount < segmentId2SnCount) ? -1
					: ((segmentId1SnCount == segmentId2SnCount) ? segmentIdCompareValue : 1);
		}
	}
}
