package com.nec.biomatcher.identifier.util;

import javax.xml.bind.JAXBContext;

import com.nec.biomatcher.core.framework.common.JaxbSerializer;
import com.nec.biomatcher.core.framework.common.exception.ObjectCreationException;
import com.nec.biomatcher.extractor.util.ExtractionJaxbXmlConvertor;
import com.nec.biomatcher.spec.transfer.job.payload.BioMatcherJobRequestPayload;
import com.nec.biomatcher.spec.transfer.job.payload.BioMatcherJobResultPayload;
import com.nec.biomatcher.spec.transfer.job.search.SearchJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.search.SearchJobResultDto;
import com.nec.biomatcher.spec.transfer.job.sync.SyncJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.sync.SyncJobResultDto;

/**
 * The Class SearchJaxbXmlConvertor.
 */
public class SearchJaxbXmlConvertor extends JaxbSerializer {

	/** The jaxb context. */
	private static volatile JAXBContext jaxbContext;

	@Override
	protected JAXBContext getJAXBContext() {
		if (jaxbContext == null) {
			synchronized (ExtractionJaxbXmlConvertor.class) {
				if (jaxbContext == null) {
					try {
						jaxbContext = JAXBContext.newInstance(SearchJobRequestDto.class, SearchJobResultDto.class,
								SyncJobRequestDto.class, SyncJobResultDto.class, BioMatcherJobRequestPayload.class,
								BioMatcherJobResultPayload.class);
					} catch (Throwable th) {
						throw new ObjectCreationException(
								"Error while creating jaxb context for SearchJaxbXmlConvertor: " + th.getMessage(), th);
					}
				}
			}
		}
		return jaxbContext;
	}

}
