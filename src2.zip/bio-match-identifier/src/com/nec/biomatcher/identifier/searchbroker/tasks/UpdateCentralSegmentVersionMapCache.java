package com.nec.biomatcher.identifier.searchbroker.tasks;

import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.google.common.util.concurrent.Uninterruptibles;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.manager.BioMatchManagerService;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.ShutdownHook;
import com.nec.biomatcher.core.framework.common.concurrent.BooleanLatch;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.identifier.searchbroker.manager.BioSearchBrokerManager;
import com.nec.biomatcher.identifier.searchbroker.util.SegmentChangeSetReader;

public class UpdateCentralSegmentVersionMapCache implements Runnable {
	private static final Logger logger = Logger.getLogger(UpdateCentralSegmentVersionMapCache.class);

	private BioParameterService bioParameterService;
	private BioSearchBrokerManager bioSearchBrokerManager;
	private BioMatchManagerService bioMatchManagerService;
	private SegmentChangeSetReader segmentChangeSetReader;
	private BooleanLatch searchBrokerConnectedFlag;
	private boolean isInitialized = false;

	@Override
	public void run() {
		Thread.currentThread().setName("UPD_CTL_SEG_VER_MAP_" + Thread.currentThread().getId());
		try {
			while (!ShutdownHook.isShutdownFlag) {
				long segmentVersionCheckDelay = TimeUnit.MINUTES.toMillis(2);
				try {
					if (!isInitialized) {
						init();
					}

					segmentVersionCheckDelay = bioParameterService.getParameterValue(
							"SB_CENTRAL_SEG_VERSION_CHECK_DELAY_MILLI", "DEFAULT", segmentVersionCheckDelay);

					searchBrokerConnectedFlag.waitForTrue();

					ConcurrentHashMap<Integer, Long> centralSegmentVersionMap = segmentChangeSetReader
							.getCentralSegmentVersionMap();

					String searchBrokerId = bioSearchBrokerManager.getSearchBrokerId();
					Map<Integer, Long> latestCentralSegmentIdVersionMap = bioMatchManagerService
							.getMatcherSegmentVersionMapBySearchBrokerId(searchBrokerId);

					for (Entry<Integer, Long> entry : latestCentralSegmentIdVersionMap.entrySet()) {
						Long newSegmentVersion = entry.getValue();
						Long oldSegmentVersion = centralSegmentVersionMap.get(entry.getKey());
						if (oldSegmentVersion == null || oldSegmentVersion < newSegmentVersion) {
							segmentChangeSetReader.notifySegmentChanges(searchBrokerId, entry.getKey(),
									newSegmentVersion);
						}
					}
				} catch (Throwable th) {
					logger.error("Error in UpdateCentralSegmentVersionMapCache loop: " + th.getMessage(), th);
					Uninterruptibles.sleepUninterruptibly(30, TimeUnit.SECONDS);
				} finally {
					Uninterruptibles.sleepUninterruptibly(segmentVersionCheckDelay, TimeUnit.MINUTES);
				}
			}
		} catch (Throwable th) {
			logger.error("Error in UpdateCentralSegmentVersionMapCache: " + th.getMessage(), th);
		} finally {
			CommonLogger.STATUS_LOG.warn(
					"Exiting UpdateCentralSegmentVersionMapCache: isShutdownFlag: " + ShutdownHook.isShutdownFlag);
		}

	}

	private final void init() {
		bioParameterService = SpringServiceManager.getBean("bioParameterService");
		bioSearchBrokerManager = SpringServiceManager.getBean("bioSearchBrokerManager");
		bioMatchManagerService = SpringServiceManager.getBean("bioMatchManagerService");
		segmentChangeSetReader = SpringServiceManager.getBean("segmentChangeSetReader");

		searchBrokerConnectedFlag = bioSearchBrokerManager.getSearchBrokerConnectedFlag();

		isInitialized = true;
	}

}
