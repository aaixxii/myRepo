package com.nec.biomatcher.identifier.searchbroker.util;

import org.apache.log4j.Logger;

import com.google.common.primitives.Ints;
import com.google.common.primitives.Longs;
import com.hazelcast.core.Message;
import com.hazelcast.core.MessageListener;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;

/**
 * The listener interface for receiving segmentDataChanges events. The class
 * that is interested in processing a segmentDataChanges event implements this
 * interface, and the object created with that class is registered with a
 * component using the component's <code>addSegmentDataChangesListener<code>
 * method. When the segmentDataChanges event occurs, that object's appropriate
 * method is invoked.
 *
 * @see SegmentDataChangesEvent
 */
public class SegmentDataChangesListener implements MessageListener<String> {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(SegmentDataChangesListener.class);

	private SegmentChangeSetReader segmentChangeSetReader;

	/** The search broker id. */
	private String searchBrokerId;

	/**
	 * Instantiates a new segment data changes listener.
	 *
	 * @param searchBrokerId
	 *            the search broker id
	 */
	public SegmentDataChangesListener(String searchBrokerId) {
		this.searchBrokerId = searchBrokerId;
	}

	@Override
	public void onMessage(final Message<String> message) {

		String segmentChangeSetRecord = message.getMessageObject();

		if (segmentChangeSetRecord != null && segmentChangeSetRecord.indexOf(":") > 0) {
			int index = segmentChangeSetRecord.indexOf(":");
			if (index > -1) {
				Integer segmentId = Ints.tryParse(segmentChangeSetRecord.substring(0, index));
				Long segmentVersion = Longs.tryParse(segmentChangeSetRecord.substring(index + 1));
				if (logger.isDebugEnabled())
					logger.debug("In SegmentDataChangesListener.onMessage: segmentId: " + segmentId
							+ ", segmentVersion: " + segmentVersion);
				if (segmentId != null && segmentVersion != null) {
					try {
						getSegmentChangeSetReader().notifySegmentChanges(searchBrokerId, segmentId, segmentVersion);
					} catch (Throwable th) {
						logger.error("Error in SegmentDataChangesListener.onMessage for segmentChangeSetRecord: "
								+ segmentChangeSetRecord + " : " + th.getMessage(), th);
					}
				}
			}
		}
	}

	private final SegmentChangeSetReader getSegmentChangeSetReader() {
		if (segmentChangeSetReader == null) {
			segmentChangeSetReader = SpringServiceManager.getBean("segmentChangeSetReader");
		}

		return segmentChangeSetReader;
	}

}
