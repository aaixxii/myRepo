package com.nec.biomatcher.identifier.searchbroker.service.impl;

import java.io.Closeable;
import java.util.Base64;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;

import com.nec.biomatcher.comp.bioevent.BiometricEventService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioConnectionType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioProtocolType;
import com.nec.biomatcher.comp.lobstream.LobImageService;
import com.nec.biomatcher.comp.manager.BioMatchManagerService;
import com.nec.biomatcher.comp.matcher.node.MatcherNodeClientHelper;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeClientException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeConnectionException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeReceiveException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeSendException;
import com.nec.biomatcher.comp.metrics.MetricsUtil;
import com.nec.biomatcher.core.framework.cache.SpringCacheManager;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.ReflectionToStringStyle;
import com.nec.biomatcher.core.framework.common.http.HttpConnectionException;
import com.nec.biomatcher.core.framework.common.http.HttpPostUtil;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.identifier.searchbroker.manager.BioSearchBrokerManager;
import com.nec.biomatcher.identifier.searchbroker.service.BioSearchBrokerService;
import com.nec.biomatcher.identifier.util.SegmentDataProtobufUtil;
import com.nec.biomatcher.spec.services.exception.BioSearchBrokerException;
import com.nec.biomatcher.spec.transfer.datadistribution.SegmentSyncRequestDto;
import com.nec.biomatcher.spec.transfer.datadistribution.SegmentSyncRequestType;
import com.nec.biomatcher.spec.transfer.datadistribution.SegmentSyncResponseDto;
import com.nec.megha.proto.segment.SegmentSyncResponseProto.SegmentSyncResponse;

/**
 * The Class BioSearchBrokerServiceImpl.
 */
public class BioSearchBrokerServiceImpl implements BioSearchBrokerService, InitializingBean {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(BioSearchBrokerServiceImpl.class);

	private static final Logger SYNC_JOB_NODE_REQUEST_LOGGER = Logger.getLogger("SYNC_JOB_NODE_REQUEST");
	private static final Logger SYNC_JOB_NODE_RESPONSE_LOGGER = Logger.getLogger("SYNC_JOB_NODE_RESPONSE");
	private static final Logger SYNC_JOB_NODE_INIT_RESPONSE_LOGGER = Logger.getLogger("SYNC_JOB_NODE_INIT_RESPONSE");
	private static final Logger MATCHER_NODE_DUMP_ERROR_PAYLOAD_LOGGER = Logger
			.getLogger("MATCHER_NODE_DUMP_ERROR_PAYLOAD");

	/** The biometric event service. */
	private BiometricEventService biometricEventService;

	/** The bio match manager service. */
	private BioMatchManagerService bioMatchManagerService;

	/** The lob image service. */
	private LobImageService lobImageService;

	/** The bio search broker manager. */
	private BioSearchBrokerManager bioSearchBrokerManager;

	private BioMatcherConfigService bioMatcherConfigService;

	/** The search broker id. */
	private String searchBrokerId;

	private MatcherNodeClientHelper matcherNodeClientHelper = new MatcherNodeClientHelper();

	public String echo(String message) {
		return message;
	}

	public void notifySearchBrokerEnabled(String searchBrokerId) {
		logger.info("In notifySearchBrokerEnabled for searchBrokerId: " + searchBrokerId);
		SpringCacheManager cacheManager = (SpringCacheManager) SpringServiceManager.getBean("methodCacheManager");
		cacheManager.removeAll();
	}

	public void notifySearchBrokerDisabled(String searchBrokerId) {
		logger.info("In notifySearchBrokerDisabled for searchBrokerId: " + searchBrokerId);
		SpringCacheManager cacheManager = (SpringCacheManager) SpringServiceManager.getBean("methodCacheManager");
		cacheManager.removeAll();
	}

	public void notifySearchNodeSyncVersion(String matcherNodeId, Map<Integer, Long> segmentIdVersionMap)
			throws BioSearchBrokerException {
		try {
			bioMatchManagerService.updateMatcherNodeSegmentVersion(matcherNodeId, segmentIdVersionMap);
		} catch (Throwable th) {
			throw new BioSearchBrokerException("Error in notifySearchNodeSyncVersion: " + th.getMessage(), th);
		}
	}

	public SegmentSyncResponseDto submitSegmentSyncRequest(String searchNodeId, SegmentSyncRequestDto request,
			long timeoutMilli) throws BioMatcherNodeClientException, BioMatcherNodeConnectionException,
			BioMatcherNodeSendException, BioMatcherNodeReceiveException {
		if (logger.isTraceEnabled())
			logger.trace(
					"In submitSegmentSyncRequest: searchNodeId: " + searchNodeId + ", timeoutMilli: " + timeoutMilli);

		boolean errorFlag = false;
		long startTimestampMilli = System.currentTimeMillis();
		try (Closeable timer = MetricsUtil.time(BioComponentType.SN, searchNodeId, "SN_SYNC_TIME_TAKEN")) {

			byte[] requestPayload = SegmentDataProtobufUtil.toRequestPayload(request);

			if (SYNC_JOB_NODE_REQUEST_LOGGER.isTraceEnabled()) {
				SYNC_JOB_NODE_REQUEST_LOGGER.trace("searchNodeId: " + searchNodeId + ", requestPayload: "
						+ ReflectionToStringBuilder.toString(request, ReflectionToStringStyle.CUSTOM_STYLE));
				SYNC_JOB_NODE_REQUEST_LOGGER.trace("searchNodeId: " + searchNodeId + ", requestPayloadBytes:  ["
						+ Base64.getEncoder().encodeToString(requestPayload) + "]");
			}

			String connectionUrl = getSegmentSyncConnectionUrl(searchNodeId, BioConnectionType.SEG_SYNC,
					BioProtocolType.HTTP);

			byte[] responsePayload = postSegmentUpdates(searchNodeId, connectionUrl, requestPayload, timeoutMilli);

			SegmentSyncResponse segSyncProtoResponse = null;
			try {
				segSyncProtoResponse = SegmentSyncResponse.parseFrom(responsePayload);

				if (SYNC_JOB_NODE_RESPONSE_LOGGER.isTraceEnabled()) {
					SYNC_JOB_NODE_RESPONSE_LOGGER.info(
							"searchNodeId: " + searchNodeId + ", responsePayload: " + segSyncProtoResponse.toString());
				} else if (SegmentSyncRequestType.INIT.equals(request.getRequestType())) {
					if (SYNC_JOB_NODE_INIT_RESPONSE_LOGGER.isTraceEnabled()) {
						SYNC_JOB_NODE_RESPONSE_LOGGER
								.info("In submitSegmentSyncRequest: After getting INIT response from searchNodeId: "
										+ searchNodeId + ", responsePayload: " + segSyncProtoResponse.toString());
					} else {
						SYNC_JOB_NODE_RESPONSE_LOGGER
								.debug("In submitSegmentSyncRequest: After getting INIT response from searchNodeId: "
										+ searchNodeId);
					}
				}
			} catch (Throwable th) {
				th = new BioMatcherNodeClientException("Error parsing SegmentSyncResponse from searchNodeId: "
						+ searchNodeId + " : " + th.getMessage(), th);
				if (MATCHER_NODE_DUMP_ERROR_PAYLOAD_LOGGER.isTraceEnabled()) {
					MATCHER_NODE_DUMP_ERROR_PAYLOAD_LOGGER.error("Response parsing error for searchNodeId: "
							+ searchNodeId + ", errorMsg: " + th.getMessage() + ", responsePayload: ["
							+ Base64.getEncoder().encodeToString(responsePayload) + "]", th);
				}
				throw th;
			}

			if (StringUtils.isBlank(segSyncProtoResponse.getInstanceId())
					|| !request.getInstanceId().equals(segSyncProtoResponse.getInstanceId())) {
				// Intentionally treating it as connection error, so
				// sendCapacity will again set the instanceId
				// BioMatcherNodeClientException
				throw new BioMatcherNodeConnectionException(
						"InstanceId does not match. InstanceId: " + request.getInstanceId() + ", responseInstanceId: "
								+ segSyncProtoResponse.getInstanceId() + ", searchNodeId: " + searchNodeId);
			}

			SegmentSyncResponseDto result = SegmentDataProtobufUtil.getSegmentSyncResponse(segSyncProtoResponse,
					request.getRequestType());

			return result;
		} catch (BioMatcherNodeSendException | BioMatcherNodeReceiveException | BioMatcherNodeConnectionException
				| BioMatcherNodeClientException ex) {
			errorFlag = true;
			logger.error(ex.getClass().getName() + " in submitSegmentSyncRequest: " + ex.getMessage(), ex);
			matcherNodeClientHelper.handleSyncSendReceiveError(searchNodeId, BioComponentType.SN,
					(System.currentTimeMillis() - startTimestampMilli), ex);
			throw ex;
		} catch (Throwable th) {
			errorFlag = true;
			logger.error(th.getClass().getName() + " in submitSegmentSyncRequest: " + th.getMessage(), th);
			matcherNodeClientHelper.handleSyncSendReceiveError(searchNodeId, BioComponentType.SN,
					(System.currentTimeMillis() - startTimestampMilli), th);
			throw new BioMatcherNodeClientException("Error in submitSegmentSyncRequest: " + th.getMessage(), th);
		} finally {
			long timeTakenMilli = System.currentTimeMillis() - startTimestampMilli;
			if (timeTakenMilli > 500 || errorFlag) {
				CommonLogger.PERF_LOG.info("In submitSegmentSyncRequest: TimeTakenMilli: " + timeTakenMilli
						+ ", searchNodeId: " + searchNodeId + (errorFlag ? ", errorFlag=true" : ""));
			}
		}
	}

	private byte[] postSegmentUpdates(String searchNodeId, String connectionUrl, byte[] requestPayload,
			long timeoutMilli) throws BioMatcherNodeReceiveException, BioMatcherNodeConnectionException {
		try {
			byte[] responsePayload = HttpPostUtil.post(searchNodeId, connectionUrl, requestPayload, timeoutMilli);

			if (responsePayload == null) {
				throw new BioMatcherNodeReceiveException("Received bytearray is null from searchNodeId: " + searchNodeId
						+ ",  connectionUrl: " + connectionUrl);
			}

			return responsePayload;
		} catch (HttpConnectionException ex) {
			throw new BioMatcherNodeConnectionException(ex.getMessage(), ex);
		}
	}

	private String getSegmentSyncConnectionUrl(String searchNodeId, BioConnectionType connectionType,
			BioProtocolType protocolType) throws Exception {
		String connectionUrl = bioMatcherConfigService.getServerConnectionUrl(searchNodeId, BioComponentType.SN,
				connectionType, protocolType);
		if (StringUtils.isBlank(connectionUrl)) {
			throw new IllegalArgumentException("Matcher node connection url is not configured for searchNodeId: "
					+ searchNodeId + ", BioComponentType: " + BioComponentType.SN + ", connectionType: "
					+ connectionType + ", protocolType: " + protocolType);
		}
		return connectionUrl;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		searchBrokerId = bioSearchBrokerManager.getSearchBrokerId();
	}

	public void setBiometricEventService(BiometricEventService biometricEventService) {
		this.biometricEventService = biometricEventService;
	}

	public void setBioMatchManagerService(BioMatchManagerService bioMatchManagerService) {
		this.bioMatchManagerService = bioMatchManagerService;
	}

	public void setLobImageService(LobImageService lobImageService) {
		this.lobImageService = lobImageService;
	}

	public void setBioSearchBrokerManager(BioSearchBrokerManager bioSearchBrokerManager) {
		this.bioSearchBrokerManager = bioSearchBrokerManager;
	}

	public void setBioMatcherConfigService(BioMatcherConfigService bioMatcherConfigService) {
		this.bioMatcherConfigService = bioMatcherConfigService;
	}
}
