package com.nec.biomatcher.identifier.searchcontroller.sync.complete.service;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

public class SegIdBinKey {
	Integer binId;
	Integer segmentId;

	public SegIdBinKey() {
	}

	public Integer getBinId() {
		return binId;
	}

	public void setBinId(Integer binId) {
		this.binId = binId;
	}

	public Integer getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(Integer segmentId) {
		this.segmentId = segmentId;
	}

	public SegIdBinKey(Integer segId, Integer binId) {
		this.binId = binId;
		this.segmentId = segId;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		} else if (!(obj instanceof SegIdBinKey)) {
			return false;
		} else {
			SegIdBinKey other = (SegIdBinKey) obj;
			return new EqualsBuilder().append(getSegmentId(), other.getSegmentId()).append(getBinId(), other.getBinId())
					.isEquals();
		}
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(getSegmentId()).append(getBinId()).toHashCode();
	}
}
