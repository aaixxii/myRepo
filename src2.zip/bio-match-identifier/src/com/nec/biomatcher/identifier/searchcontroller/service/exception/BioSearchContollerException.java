package com.nec.biomatcher.identifier.searchcontroller.service.exception;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

/**
 * The Class BioSearchContollerException.
 */
public class BioSearchContollerException extends CoreException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new bio search contoller exception.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public BioSearchContollerException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new bio search contoller exception.
	 *
	 * @param errorCode
	 *            the error code
	 * @param message
	 *            the message
	 */
	public BioSearchContollerException(String errorCode, String message) {
		super(errorCode, message);
	}

	/**
	 * Instantiates a new bio search contoller exception.
	 *
	 * @param message
	 *            the message
	 */
	public BioSearchContollerException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new bio search contoller exception.
	 *
	 * @param cause
	 *            the cause
	 */
	public BioSearchContollerException(Throwable cause) {
		super(cause);
	}
}
