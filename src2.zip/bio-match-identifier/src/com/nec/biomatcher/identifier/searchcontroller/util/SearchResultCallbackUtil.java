package com.nec.biomatcher.identifier.searchcontroller.util;

import java.util.Base64;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Supplier;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.NDC;
import org.springframework.beans.factory.InitializingBean;

import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.config.exception.BioMatcherConfigServiceException;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioConnectionType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioProtocolType;
import com.nec.biomatcher.comp.util.LocalServerComponents;
import com.nec.biomatcher.comp.zmq.ZmqPullMessageListener;
import com.nec.biomatcher.core.framework.common.BiKey;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.TriKey;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentSetQueueExecutor;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentValuedHashMap;
import com.nec.biomatcher.identifier.searchcontroller.manager.BioSearchControllerManager;
import com.nec.biomatcher.identifier.searchcontroller.queueing.SearchJobQueueHelper;
import com.nec.biomatcher.identifier.util.SearchNodeCapacityGroupLoadInfo;
import com.nec.megha.proto.search.SearchResponseProto.SearchResponse;

public class SearchResultCallbackUtil implements InitializingBean {
	private static final Logger logger = Logger.getLogger(SearchResultCallbackUtil.class);

	private static final Logger SEARCH_JOB_NODE_RESPONSE_LOGGER = Logger.getLogger("SEARCH_JOB_NODE_RESPONSE");
	private static final Logger MATCHER_NODE_DUMP_ERROR_PAYLOAD_LOGGER = Logger
			.getLogger("MATCHER_NODE_DUMP_ERROR_PAYLOAD");

	private BioSearchControllerManager bioSearchControllerManager;

	private BioMatcherConfigService bioMatcherConfigService;

	private BioParameterService bioParameterService;

	private static SearchJobQueueHelper searchJobQueueHelper;

	private static ConcurrentHashMap<String, ScSearchJobInfo> searchJobInfoMap;

	private static ZmqPullMessageListener zmqSearchResultListener;

	private static String searchControllerId = null;

	private String searchResultCallbackUrl = null;

	private ConcurrentValuedHashMap<TriKey<String, String, String>, SearchNodeCapacityGroupLoadInfo> scSearchNodePartitionedLoadMap = null;
	private ConcurrentValuedHashMap<BiKey<String, String>, SearchNodeCapacityGroupLoadInfo> snPartitionedLoadMap = null;

	// private static ConcurrentQueueExecutor<String>
	// searchResultWorkerExecutor;
	private static ConcurrentSetQueueExecutor<String> searchResultWorkerExecutor;

	private static AtomicInteger initializationCount = new AtomicInteger();

	public void startCallbackListener() throws Exception {
		logger.info("In startCallbackListener");
		try {
			searchResultCallbackUrl = getSearchResultCallbackUrl();

			Supplier<Integer> zmqIoThreadCountSupplier = BioParameterService
					.getIntSupplier("SEARCH_RESULT_LISTENER_ZMQ_IO_THREAD_COUNT", "DEFAULT", 10);
			// Supplier<Integer> messageExecutorConcurrencySupplier =
			// BioParameterService.getIntSupplier("SEARCH_RESULT_WORKER_CONCURRENCY_COUNT",
			// "DEFAULT", 50);
			Supplier<Integer> messageExecutorConcurrencySupplier = BioParameterService
					.getIntSupplier("SC_SEARCH_RESULT_LISTENER_CONCURRENCY_COUNT", "DEFAULT", 50);

			zmqSearchResultListener = new ZmqPullMessageListener("SC_SEARCH_RESULT_LISTENER", searchResultCallbackUrl,
					zmqIoThreadCountSupplier, messageExecutorConcurrencySupplier,
					(searchResponseDataBuf) -> processSearchResponseDataBuf(searchResponseDataBuf));

			zmqSearchResultListener.startZmqPullListener();
		} catch (Throwable th) {
			Exception ex = new Exception(
					"Error in startCallbackListener during binding of the ZmqPullMessageListener on searchResultCallbackUrl: "
							+ searchResultCallbackUrl + " : " + th.getMessage(),
					th);
			logger.error(ex.getMessage(), ex);

			CommonLogger.STATUS_LOG.error(ex.getMessage());

			throw ex;
		}
	}

	public static final boolean addToReceivedMessageQueue(String searchJobId, SearchResponse searchResponse) {
		if (searchControllerId != null) {
			final ScSearchJobInfo scSearchJobInfo = searchJobInfoMap.get(searchJobId);
			if (scSearchJobInfo != null) {
				scSearchJobInfo.stagingSearchResponseQueue.add(searchResponse);
				if (searchResultWorkerExecutor == null) {
					initializeSearchResultWorker(false);
				}
				searchResultWorkerExecutor.addToQueue(searchJobId);
			} else {
				logger.warn(
						"In addToReceivedMessageQueue: Cannot find scSearchJobInfo for searchJobId: " + searchJobId);
			}

			return true;
		}

		return false;
	}

	public static final boolean addToReceivedMessageQueue(SearchResponse searchResponse) {
		if (zmqSearchResultListener != null) {
			byte[] searchResponseBuf = searchResponse.toByteArray();
			zmqSearchResultListener.getReceivedMessageQueue().add(searchResponseBuf);

			return true;
		}

		return false;
	}

	private void processSearchResponseDataBuf(byte[] searchResponseDataBuf) {
		String searchJobId = null;
		String segmentJobId = null;
		String searchNodeId = null;
		long startTimestampMilli = System.currentTimeMillis();
		try {
			SearchResponse searchResponse = SearchResponse.parseFrom(searchResponseDataBuf);
			if (SEARCH_JOB_NODE_RESPONSE_LOGGER.isTraceEnabled()) {
				SEARCH_JOB_NODE_RESPONSE_LOGGER.trace("searchResponsePayload: " + searchResponse.toString());
			}

			segmentJobId = searchResponse.getMsgId();
			searchJobId = null;
			searchNodeId = null;
			if (segmentJobId.contains("|")) {
				String splitParts[] = segmentJobId.split("\\|");
				searchJobId = splitParts[0];
				searchNodeId = splitParts[2];
			} else {
				searchJobId = segmentJobId;
				segmentJobId = null;
			}

			if (searchJobId != null) {
				ScSearchJobInfo scSearchJobInfo = searchJobInfoMap.get(searchJobId);
				if (scSearchJobInfo != null) {
					if (segmentJobId != null && searchNodeId != null) {
						scSearchJobInfo.preReleasePendingSegmentJob(segmentJobId, searchNodeId, snPartitionedLoadMap);
					}
					scSearchJobInfo.stagingSearchResponseQueue.add(searchResponse);
					searchResultWorkerExecutor.addToQueue(searchJobId);
				} else {
					logger.warn("In processSearchResponseDataBuf: Cannot find scSearchJobInfo for searchJobId: "
							+ searchJobId + ", ignoring search response with segmentJobId: " + segmentJobId);
				}
			}
		} catch (Throwable th) {
			logger.error("Error in processSearchResponseDataBuf searchJobId: " + searchJobId + ", searchNodeId: "
					+ searchNodeId + ", segmentJobId: " + segmentJobId + " : " + th.getMessage(), th);
			MATCHER_NODE_DUMP_ERROR_PAYLOAD_LOGGER.error("Error in processSearchResponseDataBuf searchJobId: "
					+ searchJobId + ", searchNodeId: " + searchNodeId + ", segmentJobId: " + segmentJobId
					+ " : errorMsg: " + th.getMessage() + ", searchResponseDataBuf: ["
					+ Base64.getEncoder().encodeToString(searchResponseDataBuf) + "]", th);
		} finally {
			long timeTakenMilli = System.currentTimeMillis() - startTimestampMilli;
			if (timeTakenMilli > 10 || logger.isTraceEnabled()) {
				CommonLogger.PERF_LOG.info(
						"In processSearchResponseDataBuf: TimeTakenMilli: " + timeTakenMilli + " for searchJobId: "
								+ searchJobId + ", searchNodeId: " + searchNodeId + ", segmentJobId: " + segmentJobId);
			}
		}
	}

	private static final void processStagingSearchResponses(String searchJobId) {
		NDC.push(searchJobId);
		try {
			final ScSearchJobInfo scSearchJobInfo = searchJobInfoMap.get(searchJobId);
			if (scSearchJobInfo == null) {
				logger.debug("In processStagingSearchResponses: Cannot find scSearchJobInfo for searchJobId: "
						+ searchJobId);
				return;
			}

			if (scSearchJobInfo.isJobCompleted()) {
				logger.debug("In processStagingSearchResponses: search job is marked as completed for searchJobId: "
						+ searchJobId);
				return;
			}

			final Semaphore stagingSearchResponseTaskSemaphore = scSearchJobInfo.stagingSearchResponseTaskSemaphore;
			final ConcurrentLinkedQueue<SearchResponse> stagingSearchResponseQueue = scSearchJobInfo.stagingSearchResponseQueue;

			int loopCount = 0;
			while (!stagingSearchResponseQueue.isEmpty()) {
				if (stagingSearchResponseTaskSemaphore.tryAcquire()) {
					long startTimestampMilli = System.currentTimeMillis();
					try {
						searchJobQueueHelper.processSearchResponses(searchJobId, stagingSearchResponseQueue);
					} catch (Throwable th) {
						logger.error("Error in processStagingSearchResponses for searchJobId: " + searchJobId + " : "
								+ th.getMessage(), th);
						return;
					} finally {
						loopCount++;
						stagingSearchResponseTaskSemaphore.release();
						long timeTakenMilli = System.currentTimeMillis() - startTimestampMilli;
						if (timeTakenMilli > 10 || logger.isTraceEnabled()) {
							CommonLogger.PERF_LOG.info("In processStagingSearchResponses: TimeTakenMilli: "
									+ timeTakenMilli + " for searchJobId: " + searchJobId + ", loopCount: " + loopCount
									+ ", isJobCompleted: " + scSearchJobInfo.isJobCompleted());
						}
					}
				} else {
					break;
				}
			}
		} finally {
			NDC.pop();
		}
	}

	private final String getSearchResultCallbackUrl() throws BioMatcherConfigServiceException {
		if (LocalServerComponents.getSearchControllerId() != null) {
			String connectionUrl = bioMatcherConfigService.getServerConnectionUrl(
					LocalServerComponents.getSearchControllerId(), BioComponentType.SC,
					BioConnectionType.WORKER_CALLBACK, BioProtocolType.ZEROMQ);
			if (StringUtils.isBlank(connectionUrl)) {
				throw new IllegalArgumentException(
						"Search result callback url is not configured for searchControllerId: "
								+ LocalServerComponents.getSearchControllerId() + ", BioComponentType: "
								+ BioComponentType.SC + ", connectionType: " + BioConnectionType.WORKER_CALLBACK
								+ ", protocolType: " + BioProtocolType.ZEROMQ);
			}
			return connectionUrl;
		} else {
			throw new IllegalArgumentException(
					"Both searchControllerId and searchBrokerId is not available to get Search result callback url");
		}
	}

	private static synchronized void initializeSearchResultWorker(boolean startExecutor) {
		if (searchResultWorkerExecutor == null) {
			searchResultWorkerExecutor = new ConcurrentSetQueueExecutor<>("SC_SEARCH_RES_EXEC",
					(searchJobId -> processStagingSearchResponses(searchJobId)),
					BioParameterService.getIntSupplier("SEARCH_RESULT_WORKER_CONCURRENCY_COUNT", "DEFAULT", 50));
		}
		if (startExecutor) {
			searchResultWorkerExecutor.start();
		}
	}

	public void setBioMatcherConfigService(BioMatcherConfigService bioMatcherConfigService) {
		this.bioMatcherConfigService = bioMatcherConfigService;
	}

	public void setSearchJobQueueHelper(SearchJobQueueHelper searchJobQueueHelper) {
		SearchResultCallbackUtil.searchJobQueueHelper = searchJobQueueHelper;
	}

	public void setBioSearchControllerManager(BioSearchControllerManager bioSearchControllerManager) {
		this.bioSearchControllerManager = bioSearchControllerManager;
	}

	public void setBioParameterService(BioParameterService bioParameterService) {
		this.bioParameterService = bioParameterService;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		logger.info("In SearchResultCallbackUtil.afterPropertiesSet: " + initializationCount.get());

		synchronized (SearchResultCallbackUtil.class) {
			if (initializationCount.get() > 0) {
				return;
			}

			initializationCount.incrementAndGet();

			searchControllerId = bioSearchControllerManager.getSearchControllerId();

			searchJobInfoMap = bioSearchControllerManager.getSearchJobInfoMap();

			scSearchNodePartitionedLoadMap = bioSearchControllerManager.getScSearchNodePartitionedLoadMap();

			if (searchControllerId == null) {
				return;
			}

			initializeSearchResultWorker(true);

			snPartitionedLoadMap = new ConcurrentValuedHashMap<>(key -> scSearchNodePartitionedLoadMap
					.getValue(new TriKey<>(searchControllerId, key.getA(), key.getB())));

			startCallbackListener();
		}
	}

}
