package com.nec.biomatcher.identifier.searchcontroller.util;

import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;

import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.util.LocalServerComponents;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.identifier.searchcontroller.manager.BioSearchControllerManager;
import com.nec.biomatcher.identifier.util.SearchNodeCapacityGroupLoadInfo;
import com.nec.biomatcher.identifier.util.SegmentJobSnClientHelper;
import com.nec.megha.biomatcher.proto.common.CommonBioMatcher.SnSegmentJobInfoList;

public class SearchJobAssignmentUtil implements InitializingBean {

	private static final Logger logger = Logger.getLogger(SearchJobAssignmentUtil.class);

	private static AtomicInteger initializationCount = new AtomicInteger();

	private BioSearchControllerManager bioSearchControllerManager;
	private BioMatcherConfigService bioMatcherConfigService;
	private BioParameterService bioParameterService;
	private SegmentJobSnClientHelper segmentJobSnClientHelper;
	private ScToSbSegJobSender scToSbSegJobSender;
	private String searchControllerId;

	public final int sendAssignedSegmentJobsToRequestBuilder(SnSegmentJobInfoList snSegmentJobInfoList,
			SearchNodeCapacityGroupLoadInfo searchNodeLoadInfo, boolean scToSnDirectSegmentJobDistributionFlag) {
		if (snSegmentJobInfoList == null) {
			return 0;
		}
		int assignedJobCount = snSegmentJobInfoList.getSnSegmentJobInfoCount();
		long startTimestampMilli = System.currentTimeMillis();
		try {
			if (StringUtils.equals(searchNodeLoadInfo.getSnGroupId(),
					LocalServerComponents.getSearchBrokerSnGroupId())) {
				segmentJobSnClientHelper.addToSearchRequestBuilderQueue(snSegmentJobInfoList);
			} else if (scToSnDirectSegmentJobDistributionFlag) {
				segmentJobSnClientHelper.addToSearchRequestBuilderQueue(snSegmentJobInfoList);
			} else {
				scToSbSegJobSender.sendToSbSnGroup(searchNodeLoadInfo.getSnGroupId(), snSegmentJobInfoList);
			}
			return assignedJobCount;
		} finally {
			long timeTakenMilli = System.currentTimeMillis() - startTimestampMilli;
			if (logger.isTraceEnabled() || timeTakenMilli > 5) {
				CommonLogger.PERF_LOG.info("In sendAssignedSegmentJobsToRequestBuilder: TimeTakenMilli: "
						+ timeTakenMilli + " for searchNodeId: " + searchNodeLoadInfo.searchNodeId
						+ ", actualFreeSlots: " + searchNodeLoadInfo.getActualFreeSlots() + ", calculatedFreeSlots: "
						+ searchNodeLoadInfo.getCalculatedFreeSlots() + ", assignedJobCount: " + assignedJobCount);
			}
		}
	}

	public void setBioSearchControllerManager(BioSearchControllerManager bioSearchControllerManager) {
		this.bioSearchControllerManager = bioSearchControllerManager;
	}

	public void setBioMatcherConfigService(BioMatcherConfigService bioMatcherConfigService) {
		this.bioMatcherConfigService = bioMatcherConfigService;
	}

	public void setBioParameterService(BioParameterService bioParameterService) {
		this.bioParameterService = bioParameterService;
	}

	public void setSegmentJobSnClientHelper(SegmentJobSnClientHelper segmentJobSnClientHelper) {
		this.segmentJobSnClientHelper = segmentJobSnClientHelper;
	}

	public void setScToSbSegJobSender(ScToSbSegJobSender scToSbSegJobSender) {
		this.scToSbSegJobSender = scToSbSegJobSender;
	}

	@Override
	public synchronized void afterPropertiesSet() throws Exception {

		synchronized (SearchJobAssignmentUtil.class) {
			if (initializationCount.get() > 0) {
				return;
			}

			searchControllerId = bioSearchControllerManager.getSearchControllerId();

			initializationCount.incrementAndGet();

			// Just creating dummy logs
			ScSearchJobInfo.logger.info("Initialized logger for ScSearchJobInfo");
			ScSearchResultInfo.logger.info("Initialized logger for ScSearchResultInfo");
		}
	}

}
