package com.nec.biomatcher.tools.templatestorage.etl.service.exceptions;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

public class EtlTemplateStorageServiceException extends CoreException {
	private static final long serialVersionUID = 1L;

	public EtlTemplateStorageServiceException(String message) {
		super(message);
	}

	public EtlTemplateStorageServiceException(String message, Throwable cause) {
		super(message, cause);
	}

	public EtlTemplateStorageServiceException(String errorCode, String message, Throwable cause) {
		super(errorCode, message, cause);
	}

}
