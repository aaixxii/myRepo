package com.nec.biomatcher.tools.templatestorage.etl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.LinkedBlockingQueue;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.InitializingBean;

import com.nec.biomatcher.comp.entities.dataAccess.BiometricEventInfo;
import com.nec.biomatcher.comp.template.storage.dataAccess.BioTemplateDataInfo;
import com.nec.biomatcher.core.framework.common.BiKey;

public class EtlContext implements InitializingBean {
	private volatile boolean isExtractorCompletedFlag = false;
	private volatile boolean isTransformerCompletedFlag = false;
	private volatile boolean isLoadingCompletedFlag = false;

	private Date catchupFromDateTime;

	private int maxTransformerQueueSize = 1000;
	private int maxLoaderQueueSize = 1000;

	private int transformerConcurrency = 50;
	private int loaderConcurrency = 10;

	private int extractorBatchSize = 1000;
	private int loaderBatchSize = 50;

	private LinkedBlockingQueue<BiometricEventInfo> transformerQueue;
	private LinkedBlockingQueue<BiKey<BiometricEventInfo, BioTemplateDataInfo>> loaderQueue;

	public int getTransformerConcurrency() {
		return transformerConcurrency;
	}

	public int getLoaderConcurrency() {
		return loaderConcurrency;
	}

	public boolean getIsExtractorCompletedFlag() {
		return isExtractorCompletedFlag;
	}

	public void setIsExtractorCompletedFlag(boolean isExtractorCompletedFlag) {
		this.isExtractorCompletedFlag = isExtractorCompletedFlag;
		EtlLogger.CONFIG.info("After setting isExtractorCompletedFlag to " + isExtractorCompletedFlag);
	}

	public boolean getIsTransformerCompletedFlag() {
		return isTransformerCompletedFlag;
	}

	public void setIsTransformerCompletedFlag(boolean isTransformerCompletedFlag) {
		this.isTransformerCompletedFlag = isTransformerCompletedFlag;
		EtlLogger.CONFIG.info("After setting isTransformerCompletedFlag to " + isTransformerCompletedFlag);
	}

	public boolean getIsLoadingCompletedFlag() {
		return isLoadingCompletedFlag;
	}

	public void setIsLoadingCompletedFlag(boolean isLoadingCompletedFlag) {
		this.isLoadingCompletedFlag = isLoadingCompletedFlag;
		EtlLogger.CONFIG.info("After setting isLoadingCompletedFlag to " + isLoadingCompletedFlag);
	}

	public Date getCatchupFromDateTime() {
		return catchupFromDateTime;
	}

	public void setCatchupFromDateTime(String catchupFromDateTime) {
		if (StringUtils.isBlank(catchupFromDateTime)) {
			EtlLogger.CONFIG.info("ETL is configured in full mode");
			return;
		}

		try {
			SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
			this.catchupFromDateTime = format.parse(catchupFromDateTime);
			EtlLogger.CONFIG
					.info("ETL is configured in catchup mode, catchupFromDateTime: " + this.catchupFromDateTime);
		} catch (Throwable th) {
			throw new RuntimeException("Invalid catchupFromDateTime: " + catchupFromDateTime + " : " + th.getMessage(),
					th);
		}
	}

	public LinkedBlockingQueue<BiKey<BiometricEventInfo, BioTemplateDataInfo>> getLoaderQueue() {
		return loaderQueue;
	}

	public LinkedBlockingQueue<BiometricEventInfo> getTransformerQueue() {
		return transformerQueue;
	}

	public int getMaxTransformerQueueSize() {
		return maxTransformerQueueSize;
	}

	public void setMaxTransformerQueueSize(int maxTransformerQueueSize) {
		this.maxTransformerQueueSize = maxTransformerQueueSize;
	}

	public int getMaxloaderQueueSize() {
		return maxLoaderQueueSize;
	}

	public void setMaxLoaderQueueSize(int maxLoaderQueueSize) {
		this.maxLoaderQueueSize = maxLoaderQueueSize;
	}

	public int getExtractorBatchSize() {
		return extractorBatchSize;
	}

	public void setExtractorBatchSize(int extractorBatchSize) {
		this.extractorBatchSize = extractorBatchSize;
	}

	public int getLoaderBatchSize() {
		return loaderBatchSize;
	}

	public void setLoaderBatchSize(int loaderBatchSize) {
		this.loaderBatchSize = loaderBatchSize;
	}

	public void setTransformerConcurrency(int transformerConcurrency) {
		this.transformerConcurrency = transformerConcurrency;
	}

	public void setLoaderConcurrency(int loaderConcurrency) {
		this.loaderConcurrency = loaderConcurrency;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		transformerQueue = new LinkedBlockingQueue<>(maxTransformerQueueSize);
		loaderQueue = new LinkedBlockingQueue<>(maxLoaderQueueSize);
	}

}
