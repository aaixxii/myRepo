package com.nec.biomatcher.tools.templatestorage.etl.service.dataAccess;

import java.util.Date;
import java.util.List;

import com.nec.biomatcher.comp.entities.dataAccess.BiometricEventInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricIdInfo;
import com.nec.biomatcher.core.framework.dataAccess.DaoException;
import com.nec.biomatcher.core.framework.dataAccess.HibernateDao;

public interface EtlTemplateStorageDao extends HibernateDao {

	public void updateBiometricEventTemplateDataKey(List<Long> biometricIdList) throws DaoException;

	public void markBiometricEventsAsCorrupted(List<Long> corruptedBiometricIdList) throws DaoException;

	public void deleteTemplateDataInfoList(List<String> templateDataIdList) throws DaoException;

	public List<BiometricEventInfo> getActiveBiometricEventInfoListBySegmentIdAndBiometricId(Integer segmentId,
			Long afterBiometricId, int maxRecords) throws DaoException;

	public List<BiometricEventInfo> getActiveBiometricEventInfoListBySegmentIdAndBiometricId(Integer segmentId,
			Date catchupFromDate, Long afterBiometricId, int maxRecords) throws DaoException;

	public List<BiometricIdInfo> getActiveBiometricIdInfoList() throws DaoException;
}
