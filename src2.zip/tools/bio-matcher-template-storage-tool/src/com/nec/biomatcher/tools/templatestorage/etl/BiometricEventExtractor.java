package com.nec.biomatcher.tools.templatestorage.etl;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;

import com.google.common.util.concurrent.Uninterruptibles;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricEventInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricIdInfo;
import com.nec.biomatcher.core.framework.common.ShutdownHook;
import com.nec.biomatcher.core.framework.common.concurrent.CommonTaskScheduler;
import com.nec.biomatcher.spec.transfer.event.BiometricEventPhase;
import com.nec.biomatcher.tools.templatestorage.etl.service.EtlTemplateStorageService;

public class BiometricEventExtractor implements InitializingBean {
	private static final Logger logger = Logger.getLogger(BiometricEventExtractor.class);

	private EtlContext etlContext;
	private EtlTemplateStorageService etlTemplateStorageService;
	private List<BiometricIdInfo> biometricIdInfoList = Collections.emptyList();

	private void extract() {
		Thread.currentThread().setName("ETL_extract_" + Thread.currentThread().getId());
		EtlLogger.CONFIG.info("In BiometricEventExtractor.extract");

		LinkedBlockingQueue<BiometricEventInfo> transformerQueue = etlContext.getTransformerQueue();
		try {
			for (BiometricIdInfo biometricIdInfo : biometricIdInfoList) {
				EtlLogger.STATUS.info("In BiometricEventExtractor.extract: Started extract for binId: "
						+ biometricIdInfo.getBinId() + ", segmentId: " + biometricIdInfo.getSegmentId()
						+ ", startBiometricId: " + biometricIdInfo.getStartBiometricId() + ", endBiometricId: "
						+ biometricIdInfo.getEndBiometricId() + ", currentBiometricId: "
						+ biometricIdInfo.getCurrentBiometricId());
				Long afterBiometricId = biometricIdInfo.getStartBiometricId() - 1;
				long totalExtracBiometricIdCount = 0;
				while (!ShutdownHook.isShutdownFlag) {
					try {
						List<BiometricEventInfo> biometricEventInfoList = Collections.emptyList();

						if (etlContext.getCatchupFromDateTime() != null) {
							biometricEventInfoList = etlTemplateStorageService
									.getActiveBiometricEventInfoListBySegmentIdAndBiometricId(
											biometricIdInfo.getSegmentId(), etlContext.getCatchupFromDateTime(),
											afterBiometricId, etlContext.getExtractorBatchSize());
						} else {
							biometricEventInfoList = etlTemplateStorageService
									.getActiveBiometricEventInfoListBySegmentIdAndBiometricId(
											biometricIdInfo.getSegmentId(), afterBiometricId,
											etlContext.getExtractorBatchSize());
						}

						if (biometricEventInfoList.isEmpty()) {
							EtlLogger.STATUS.info("In BiometricEventExtractor.extract: Completed extract for binId: "
									+ biometricIdInfo.getBinId() + ", segmentId: " + biometricIdInfo.getSegmentId()
									+ ", lastAfterBiometricId: " + afterBiometricId + ", totalExtracBiometricIdCount: "
									+ totalExtracBiometricIdCount);
							break;
						}

						for (BiometricEventInfo biometricEventInfo : biometricEventInfoList) {
							if (StringUtils.contains(biometricEventInfo.getTemplateDataKey(), ":")
									&& (BiometricEventPhase.PENDING_SYNC.equals(biometricEventInfo.getPhase())
											|| BiometricEventPhase.SYNC_COMPLETED
													.equals(biometricEventInfo.getPhase()))) {
								Uninterruptibles.putUninterruptibly(transformerQueue, biometricEventInfo);
								totalExtracBiometricIdCount++;
							}
							afterBiometricId = biometricEventInfo.getBiometricId();
						}
					} catch (Throwable th) {
						EtlLogger.ERROR.error("Error in BiometricEventExtractor.extract for binId: "
								+ biometricIdInfo.getBinId() + ", segmentId: " + biometricIdInfo.getSegmentId()
								+ ", afterBiometricId: " + afterBiometricId + " : " + th.getMessage(), th);
						Uninterruptibles.sleepUninterruptibly(30, TimeUnit.MILLISECONDS);
					}
				}
			}
		} catch (Throwable th) {
			EtlLogger.ERROR.error("Error in BiometricEventExtractor.extract : " + th.getMessage(), th);
			Uninterruptibles.sleepUninterruptibly(30, TimeUnit.MILLISECONDS);
		} finally {
			etlContext.setIsExtractorCompletedFlag(true);
			EtlLogger.CONFIG.info("In BiometricEventExtractor.extract finally");
		}
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		EtlLogger.CONFIG.info("In BiometricEventExtractor.afterPropertiesSet");

		biometricIdInfoList = etlTemplateStorageService.getActiveBiometricIdInfoList();
		EtlLogger.CONFIG.info("In BiometricEventExtractor: biometricIdInfoListSize: " + biometricIdInfoList.size());

		if (biometricIdInfoList.isEmpty()) {
			etlContext.setIsExtractorCompletedFlag(true);
			return;
		}

		CommonTaskScheduler.scheduleWithFixedDelay(this::extract, 30, 30, TimeUnit.SECONDS);

	}

	public void setEtlContext(EtlContext etlContext) {
		this.etlContext = etlContext;
	}

	public void setEtlTemplateStorageService(EtlTemplateStorageService etlTemplateStorageService) {
		this.etlTemplateStorageService = etlTemplateStorageService;
	}

}
