package com.nec.biomatcher.tools.templatestorage.etl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;

import com.google.common.util.concurrent.Uninterruptibles;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricEventInfo;
import com.nec.biomatcher.comp.template.storage.dataAccess.BioTemplateDataInfo;
import com.nec.biomatcher.core.framework.common.BiKey;
import com.nec.biomatcher.core.framework.common.ShutdownHook;
import com.nec.biomatcher.core.framework.common.concurrent.CommonTaskScheduler;
import com.nec.biomatcher.tools.templatestorage.etl.service.EtlTemplateStorageService;

public class BiometricTemplateInfoLoader implements InitializingBean {
	private EtlContext etlContext;
	private EtlTemplateStorageService etlTemplateStorageService;
	private CyclicBarrier waitForExitBarrier;

	public void load() {
		Thread.currentThread().setName("ETL_load_" + Thread.currentThread().getId());
		EtlLogger.CONFIG.info("In BiometricTemplateInfoLoader.load");
		try {
			final LinkedBlockingQueue<BiKey<BiometricEventInfo, BioTemplateDataInfo>> loaderQueue = etlContext
					.getLoaderQueue();
			final List<BiKey<BiometricEventInfo, BioTemplateDataInfo>> templateDataInfoList = new ArrayList<>();
			while (!ShutdownHook.isShutdownFlag) {
				try {
					if (templateDataInfoList.isEmpty()) {
						BiKey<BiometricEventInfo, BioTemplateDataInfo> biKey = loaderQueue.poll(30, TimeUnit.SECONDS);
						if (biKey != null) {
							templateDataInfoList.add(biKey);
							if (etlContext.getLoaderBatchSize() > 1) {
								loaderQueue.drainTo(templateDataInfoList, etlContext.getLoaderBatchSize() - 1);
							}
						} else {
							if (etlContext.getIsTransformerCompletedFlag() && loaderQueue.isEmpty()) {
								EtlLogger.STATUS.info(
										"In BiometricTemplateInfoLoader.load: Transformer is completed and loaderQueue is empty");
								etlContext.setIsLoadingCompletedFlag(true);
								break;
							}
							continue;
						}
					}

					etlTemplateStorageService.saveTemplateDataInfoList(templateDataInfoList);
					templateDataInfoList.clear();
				} catch (Throwable th) {
					EtlLogger.ERROR.error("Error in BiometricTemplateInfoLoader.load : " + th.getMessage(), th);
					Uninterruptibles.sleepUninterruptibly(30, TimeUnit.SECONDS);
				}
			}
		} finally {
			EtlLogger.CONFIG.info("In BiometricTemplateInfoLoader.load finally");

			try {
				waitForExitBarrier.await();
			} catch (Throwable th) {
				EtlLogger.ERROR.error("Error in BiometricTemplateInfoLoader.load during waitForExitBarrier.await : "
						+ th.getMessage(), th);
			}
		}
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		EtlLogger.CONFIG.info("In BiometricTemplateInfoLoader.afterPropertiesSet");

		EtlLogger.CONFIG
				.info("In BiometricTemplateInfoLoader: loaderConcurrency: " + etlContext.getLoaderConcurrency());

		waitForExitBarrier = new CyclicBarrier(etlContext.getLoaderConcurrency(), () -> {
			EtlLogger.STATUS.info("ETL conversion completed");
			Logger.getLogger("CONSOLE").info("ETL conversion completed");
			System.exit(0);
		});

		for (int i = 0; i < etlContext.getLoaderConcurrency(); i++) {
			CommonTaskScheduler.CACHED_EXECUTORSERVICE.submit(this::load);
			EtlLogger.CONFIG.info("In BiometricTemplateInfoLoader: After scheduling loader task, index: " + (i + 1));
		}
	}

	public void setEtlContext(EtlContext etlContext) {
		this.etlContext = etlContext;
	}

	public void setEtlTemplateStorageService(EtlTemplateStorageService etlTemplateStorageService) {
		this.etlTemplateStorageService = etlTemplateStorageService;
	}

}
