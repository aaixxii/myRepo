package com.nec.biomatcher.tools.templatestorage.etl;

import org.apache.log4j.Logger;

public class EtlLogger {
	public static final Logger ERROR = Logger.getLogger("ERRORS");
	public static final Logger CONFIG = Logger.getLogger("CONFIG_LOG");
	public static final Logger STATUS = Logger.getLogger("STATUS_LOG");
	public static final Logger CORRUPTED = Logger.getLogger("CORRUPTED_LOG");
	public static final Logger PREF = Logger.getLogger("PFLogger");
}
