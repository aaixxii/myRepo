package com.nec.biomatcher.spec.services;

public interface BioSearchBrokerRemoteService {

	public String echo(String message);

	public void notifySearchBrokerEnabled(String searchBrokerId);

	public void notifySearchBrokerDisabled(String searchBrokerId);

}
