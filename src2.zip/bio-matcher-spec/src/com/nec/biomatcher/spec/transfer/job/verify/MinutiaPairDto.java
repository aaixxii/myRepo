package com.nec.biomatcher.spec.transfer.job.verify;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;

import com.nec.biomatcher.spec.transfer.core.Dto;

@XmlAccessorType(XmlAccessType.FIELD)
public class MinutiaPairDto implements Dto {

	private static final long serialVersionUID = 6075532255271401662L;

	@XmlAttribute
	private Integer probeMinutiaNumber;

	@XmlAttribute
	private Integer targetMinutiaNumber;

	@XmlAttribute(required = true)
	private Integer similitude;

	@XmlAttribute
	private Integer probe_direction;

	@XmlAttribute
	private Integer probe_x;

	@XmlAttribute
	private Integer probe_y;

	@XmlAttribute
	private Integer target_direction;

	@XmlAttribute
	private Integer target_x;

	@XmlAttribute
	private Integer target_y;

	public Integer getProbeMinutiaNumber() {
		return probeMinutiaNumber;
	}

	public void setProbeMinutiaNumber(Integer probeMinutiaNumber) {
		this.probeMinutiaNumber = probeMinutiaNumber;
	}

	public Integer getTargetMinutiaNumber() {
		return targetMinutiaNumber;
	}

	public void setTargetMinutiaNumber(Integer targetMinutiaNumber) {
		this.targetMinutiaNumber = targetMinutiaNumber;
	}

	public Integer getSimilitude() {
		return similitude;
	}

	public void setSimilitude(Integer similitude) {
		this.similitude = similitude;
	}

	public Integer getProbe_direction() {
		return probe_direction;
	}

	public void setProbe_direction(Integer probe_direction) {
		this.probe_direction = probe_direction;
	}

	public Integer getProbe_x() {
		return probe_x;
	}

	public void setProbe_x(Integer probe_x) {
		this.probe_x = probe_x;
	}

	public Integer getProbe_y() {
		return probe_y;
	}

	public void setProbe_y(Integer probe_y) {
		this.probe_y = probe_y;
	}

	public Integer getTarget_direction() {
		return target_direction;
	}

	public void setTarget_direction(Integer target_direction) {
		this.target_direction = target_direction;
	}

	public Integer getTarget_x() {
		return target_x;
	}

	public void setTarget_x(Integer target_x) {
		this.target_x = target_x;
	}

	public Integer getTarget_y() {
		return target_y;
	}

	public void setTarget_y(Integer target_y) {
		this.target_y = target_y;
	}
}
