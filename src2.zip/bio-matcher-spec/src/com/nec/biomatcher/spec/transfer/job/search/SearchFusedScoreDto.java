package com.nec.biomatcher.spec.transfer.job.search;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import com.nec.biomatcher.spec.transfer.core.Dto;
import com.nec.biomatcher.spec.transfer.model.ImagePosition;

@XmlAccessorType(XmlAccessType.FIELD)
public class SearchFusedScoreDto implements Dto {
	private static final long serialVersionUID = 1L;

	private ImagePosition imagePosition;
	private Integer score = 0;

	public SearchFusedScoreDto() {

	}

	public SearchFusedScoreDto(ImagePosition imagePosition, Integer score) {
		super();
		this.imagePosition = imagePosition;
		this.score = score;
	}

	public ImagePosition getImagePosition() {
		return imagePosition;
	}

	public void setImagePosition(ImagePosition imagePosition) {
		this.imagePosition = imagePosition;
	}

	public Integer getScore() {
		return score;
	}

	public void setScore(Integer score) {
		this.score = score;
	}

}
