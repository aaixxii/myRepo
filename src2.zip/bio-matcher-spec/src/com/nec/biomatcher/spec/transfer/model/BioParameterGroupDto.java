package com.nec.biomatcher.spec.transfer.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.core.Dto;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BioParameterGroupDto implements Dto {
	private static final long serialVersionUID = 1L;

	@XmlElement(required = true)
	private String groupName;

	@XmlElement(required = false, nillable = true)
	private List<BioParameterDto> keyValuePairList;

	@XmlElement(required = false, nillable = true)
	private List<BioParameterGroupDto> keyValueGroupList;
	
	@XmlElement(required = false, nillable = false)
    private AlgorithmType algType;
	
	

	public BioParameterGroupDto() {

	}

	public BioParameterGroupDto(String groupName) {
		this.groupName = groupName;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public boolean hasKeyValuePairList() {
		return keyValuePairList != null && !keyValuePairList.isEmpty();
	}

	public List<BioParameterDto> getKeyValuePairList() {
		if (keyValuePairList == null) {
			keyValuePairList = new ArrayList<>();
		}
		return keyValuePairList;
	}

	public void setKeyValuePairList(List<BioParameterDto> keyValuePairList) {
		this.keyValuePairList = keyValuePairList;
	}

	public boolean hasKeyValueGroupList() {
		return keyValueGroupList != null && !keyValueGroupList.isEmpty();
	}

	public List<BioParameterGroupDto> getKeyValueGroupList() {
		if (keyValueGroupList == null) {
			keyValueGroupList = new ArrayList<>();
		}
		return keyValueGroupList;
	}

	public void setKeyValueGroupList(List<BioParameterGroupDto> keyValueGroupList) {
		this.keyValueGroupList = keyValueGroupList;
	}

    public AlgorithmType getAlgType() {
        return algType;
    }

    public void setAlgType(AlgorithmType algType) {
        this.algType = algType;
    }

}
