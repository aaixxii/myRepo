package com.nec.biomatcher.spec.transfer.model;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.core.Dto;

/**
 * The Class ErrorMessageDto.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class ErrorMessageDto implements Dto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The error code. */
	private String errorCode;

	/** The error message. */
	private String errorMessage;

	/** The error detail. */
	private String errorDetail;

	/** The error date time. */
	private Date errorDateTime;

	/**
	 * Instantiates a new error message dto.
	 */
	public ErrorMessageDto() {

	}

	/**
	 * Instantiates a new error message dto.
	 *
	 * @param errorCode
	 *            the error code
	 * @param errorMessage
	 *            the error message
	 * @param errorDetail
	 *            the error detail
	 * @param errorDateTime
	 *            the error date time
	 */
	public ErrorMessageDto(String errorCode, String errorMessage, String errorDetail, Date errorDateTime) {
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.errorDetail = errorDetail;
		this.errorDateTime = errorDateTime;
	}

	public ErrorMessageDto(String errorCode, String errorMessage, String errorDetail) {
		this(errorCode, errorMessage, errorDetail, new Date());
	}

	public ErrorMessageDto(String errorCode, String errorMessage) {
		this(errorCode, errorMessage, null, new Date());
	}

	public ErrorMessageDto(String errorCode, String errorMessage, Throwable th) {
		this.errorCode = errorCode;
		this.errorDateTime = new Date();
		this.errorMessage = errorMessage == null ? th.getMessage() : errorMessage;
		StringWriter sw = new StringWriter();
		try (PrintWriter pw = new PrintWriter(sw)) {
			th.printStackTrace(pw);
			this.errorDetail = sw.toString();
		}
	}

	public ErrorMessageDto(String errorCode, Throwable th) {
		this(errorCode, null, th);
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getErrorDetail() {
		return errorDetail;
	}

	public void setErrorDetail(String errorDetail) {
		this.errorDetail = errorDetail;
	}

	public Date getErrorDateTime() {
		return errorDateTime;
	}

	public void setErrorDateTime(Date errorDateTime) {
		this.errorDateTime = errorDateTime;
	}

}
