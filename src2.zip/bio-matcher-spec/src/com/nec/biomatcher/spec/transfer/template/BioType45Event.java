package com.nec.biomatcher.spec.transfer.template;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BioType45Event extends BioTemplateEvent {
	private static final long serialVersionUID = 1L;

	private BioPalmFeatureInfo fullRight;
	private BioPalmFeatureInfo fullLeft;
	private BioPalmFeatureInfo writerRight;
	private BioPalmFeatureInfo writerLeft;

	public BioPalmFeatureInfo getFullRight() {
		return fullRight;
	}

	public void setFullRight(BioPalmFeatureInfo fullRight) {
		this.fullRight = fullRight;
	}

	public BioPalmFeatureInfo getFullLeft() {
		return fullLeft;
	}

	public void setFullLeft(BioPalmFeatureInfo fullLeft) {
		this.fullLeft = fullLeft;
	}

	public BioPalmFeatureInfo getWriterRight() {
		return writerRight;
	}

	public void setWriterRight(BioPalmFeatureInfo writerRight) {
		this.writerRight = writerRight;
	}

	public BioPalmFeatureInfo getWriterLeft() {
		return writerLeft;
	}

	public void setWriterLeft(BioPalmFeatureInfo writerLeft) {
		this.writerLeft = writerLeft;
	}

}
