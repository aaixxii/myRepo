package com.nec.biomatcher.spec.transfer.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.core.Dto;

/**
 * The Class ExtractInputParameter.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class ExtractInputParameter implements Dto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	protected Modality modality;

	protected AlgorithmType algorithmType;

	@XmlElement(required = false, nillable = true)
	protected List<BioParameterDto> parameters;

	public boolean hasParameters() {
		return parameters != null && parameters.size() > 0;
	}

	public List<BioParameterDto> getParameters() {
		if (parameters == null) {
			parameters = new ArrayList<>();
		}
		return parameters;
	}

	public void setParameters(List<BioParameterDto> parameters) {
		this.parameters = parameters;
	}

	public Modality getModality() {
		return modality;
	}

	public void setModality(Modality modality) {
		this.modality = modality;
	}

	public AlgorithmType getAlgorithmType() {
		return algorithmType;
	}

	public void setAlgorithmType(AlgorithmType algorithmType) {
		this.algorithmType = algorithmType;
	}

	public void setParameter(String key, String value) {
		getParameters().add(new BioParameterDto(key, value));
	}
}
