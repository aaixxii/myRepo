package com.nec.biomatcher.spec.transfer.template;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.model.AlgorithmType;
import com.nec.biomatcher.spec.transfer.model.BioFeType;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BioType33Event extends BioTemplateEvent {
	private static final long serialVersionUID = 1L;

	private AlgorithmType algorithmType;
	private BioFeType feType;

	private List<BioFingerFeatureInfo> fingerInfoList;

	public List<BioFingerFeatureInfo> getFingerInfoList() {
		return fingerInfoList;
	}

	public void setFingerInfoList(List<BioFingerFeatureInfo> fingerInfoList) {
		this.fingerInfoList = fingerInfoList;
	}

	public AlgorithmType getAlgorithmType() {
		return algorithmType;
	}

	public void setAlgorithmType(AlgorithmType algorithmType) {
		this.algorithmType = algorithmType;
	}

	public BioFeType getFeType() {
		return feType;
	}

	public void setFeType(BioFeType feType) {
		this.feType = feType;
	}

}
