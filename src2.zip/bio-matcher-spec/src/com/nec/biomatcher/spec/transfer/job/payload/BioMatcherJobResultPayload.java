package com.nec.biomatcher.spec.transfer.job.payload;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

import com.nec.biomatcher.spec.transfer.core.Dto;
import com.nec.biomatcher.spec.transfer.job.BioMatcherJobResult;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractJobResultDto;
import com.nec.biomatcher.spec.transfer.job.search.SearchJobResultDto;
import com.nec.biomatcher.spec.transfer.job.verify.VerifyJobResultDto;

/**
 * The Class BioMatcherJobResultPayload.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@XmlSeeAlso({ ExtractJobResultDto.class, VerifyJobResultDto.class, SearchJobResultDto.class })
public class BioMatcherJobResultPayload extends AbstractBioMatcherJobPayload implements Dto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The callback url. */
	protected String callbackUrl;

	/** The bio matcher job result. */
	private BioMatcherJobResult bioMatcherJobResult;

	public BioMatcherJobResult getBioMatcherJobResult() {
		return bioMatcherJobResult;
	}

	public void setBioMatcherJobResult(BioMatcherJobResult bioMatcherJobResult) {
		this.bioMatcherJobResult = bioMatcherJobResult;
	}

	public String getCallbackUrl() {
		return callbackUrl;
	}

	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}

}
