package com.nec.biomatcher.spec.transfer.job.extract;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.core.Dto;
import com.nec.biomatcher.spec.transfer.model.BioParameterGroupDto;
import com.nec.biomatcher.spec.transfer.model.MetaInfoCommon;
import com.nec.biomatcher.spec.transfer.model.TemplateExtractInputImage;

/**
 * The Class ExtractInputPayloadDto.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class ExtractInputPayloadDto implements Dto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The template extract input image list. */
	@XmlElement(required = true, nillable = false)
	protected List<TemplateExtractInputImage> templateExtractInputImageList;

	/** The meta info common. */
	@XmlElement(required = false, nillable = true)
	protected MetaInfoCommon metaInfoCommon;

	/** The candidate id. */
	@XmlElement(required = false, nillable = true)
	protected String candidateId;

	/** The event id. */
	@XmlElement(required = false, nillable = true)
	protected String eventId;

	/** The biometric id. */
	@XmlElement(required = false, nillable = true)
	protected Long biometricId;

	@XmlElement(required = false, nillable = true)
	protected List<BioParameterGroupDto> keyValueGroupList;

	public MetaInfoCommon getMetaInfoCommon() {
		return metaInfoCommon;
	}

	public void setMetaInfoCommon(MetaInfoCommon metaInfoCommon) {
		this.metaInfoCommon = metaInfoCommon;
	}

	public List<TemplateExtractInputImage> getTemplateExtractInputImageList() {
		if (templateExtractInputImageList == null) {
			templateExtractInputImageList = new ArrayList<TemplateExtractInputImage>();
		}
		return templateExtractInputImageList;
	}

	public void setTemplateExtractInputImageList(List<TemplateExtractInputImage> templateExtractInputImageList) {
		this.templateExtractInputImageList = templateExtractInputImageList;
	}

	public String getCandidateId() {
		return candidateId;
	}

	public void setCandidateId(String candidateId) {
		this.candidateId = candidateId;
	}

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	public Long getBiometricId() {
		return biometricId;
	}

	public void setBiometricId(Long biometricId) {
		this.biometricId = biometricId;
	}

	public boolean hasKeyValueGroupList() {
		return keyValueGroupList != null && !keyValueGroupList.isEmpty();
	}

	public List<BioParameterGroupDto> getKeyValueGroupList() {
		if (keyValueGroupList == null) {
			keyValueGroupList = new ArrayList<>();
		}
		return keyValueGroupList;
	}

	public void setKeyValueGroupList(List<BioParameterGroupDto> keyValueGroupList) {
		this.keyValueGroupList = keyValueGroupList;
	}
}
