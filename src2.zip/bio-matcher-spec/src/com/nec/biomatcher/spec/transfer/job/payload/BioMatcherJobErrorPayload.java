package com.nec.biomatcher.spec.transfer.job.payload;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.core.Dto;
import com.nec.biomatcher.spec.transfer.model.ErrorMessageDto;

/**
 * The Class BioMatcherJobErrorPayload.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BioMatcherJobErrorPayload extends AbstractBioMatcherJobPayload implements Dto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The error message list. */
	private List<ErrorMessageDto> errorMessageList = new ArrayList<ErrorMessageDto>();

	public List<ErrorMessageDto> getErrorMessageList() {
		return errorMessageList;
	}

	public void setErrorMessageList(List<ErrorMessageDto> errorMessageList) {
		this.errorMessageList = errorMessageList;
	}
}
