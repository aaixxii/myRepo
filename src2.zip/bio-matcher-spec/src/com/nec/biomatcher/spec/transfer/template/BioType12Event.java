package com.nec.biomatcher.spec.transfer.template;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BioType12Event extends BioTemplateEvent {
	private static final long serialVersionUID = 1L;

	private Integer irisRightQuality;
	private Integer irisLeftQuality;
	private byte irisRightDeltaIdFeatureData[];
	private byte irisLeftDeltaIdFeatureData[];

	public Integer getIrisRightQuality() {
		return irisRightQuality;
	}

	public void setIrisRightQuality(Integer irisRightQuality) {
		this.irisRightQuality = irisRightQuality;
	}

	public Integer getIrisLeftQuality() {
		return irisLeftQuality;
	}

	public void setIrisLeftQuality(Integer irisLeftQuality) {
		this.irisLeftQuality = irisLeftQuality;
	}

	public byte[] getIrisRightDeltaIdFeatureData() {
		return irisRightDeltaIdFeatureData;
	}

	public void setIrisRightDeltaIdFeatureData(byte[] irisRightDeltaIdFeatureData) {
		this.irisRightDeltaIdFeatureData = irisRightDeltaIdFeatureData;
	}

	public byte[] getIrisLeftDeltaIdFeatureData() {
		return irisLeftDeltaIdFeatureData;
	}

	public void setIrisLeftDeltaIdFeatureData(byte[] irisLeftDeltaIdFeatureData) {
		this.irisLeftDeltaIdFeatureData = irisLeftDeltaIdFeatureData;
	}

}
