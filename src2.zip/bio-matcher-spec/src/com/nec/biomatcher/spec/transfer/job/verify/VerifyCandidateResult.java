package com.nec.biomatcher.spec.transfer.job.verify;

import java.util.ArrayList;
import java.util.List;

import com.nec.biomatcher.spec.transfer.core.Dto;

/**
 * The Class VerifyCandidateResult.
 */
public class VerifyCandidateResult implements Dto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The candidate id. */
	private String candidateId;

	/** The fusion score. */
	private Double fusionScore;

	/** The modal score list. */
	private List<VerifyModalScore> modalScoreList;

	/** The success. */
	private boolean success;

	public Double getFusionScore() {
		return fusionScore;
	}

	public void setFusionScore(Double fusionScore) {
		this.fusionScore = fusionScore;
	}

	public List<VerifyModalScore> getModalScoreList() {
		if (modalScoreList == null) {
			modalScoreList = new ArrayList<VerifyModalScore>();
		}
		return modalScoreList;
	}

	public void setModalScoreList(List<VerifyModalScore> modalScoreList) {
		if (modalScoreList == null) {
			modalScoreList = new ArrayList<VerifyModalScore>();
		}
		this.modalScoreList = modalScoreList;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public String getCandidateId() {
		return candidateId;
	}

	public void setCandidateId(String candidateId) {
		this.candidateId = candidateId;
	}
}
