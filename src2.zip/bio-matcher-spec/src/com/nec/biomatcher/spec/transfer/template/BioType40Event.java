package com.nec.biomatcher.spec.transfer.template;

import java.util.Set;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.model.ImagePosition;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BioType40Event extends BioTemplateEvent {
	private static final long serialVersionUID = 1L;

	private Set<ImagePosition> partNumbers;
	private byte[] latentPc3FeatureData;

	public Set<ImagePosition> getPartNumbers() {
		return partNumbers;
	}

	public void setPartNumbers(Set<ImagePosition> partNumbers) {
		this.partNumbers = partNumbers;
	}

	public byte[] getLatentPc3FeatureData() {
		return latentPc3FeatureData;
	}

	public void setLatentPc3FeatureData(byte[] latentPc3FeatureData) {
		this.latentPc3FeatureData = latentPc3FeatureData;
	}

}
