package com.nec.biomatcher.spec.transfer.template;

import java.util.Set;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.model.AlgorithmType;
import com.nec.biomatcher.spec.transfer.model.BioFeType;
import com.nec.biomatcher.spec.transfer.model.ImagePosition;
import com.nec.biomatcher.spec.transfer.model.PatternType;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BioType34Event extends BioTemplateEvent {
	private static final long serialVersionUID = 1L;

	private AlgorithmType algorithmType;
	private BioFeType feType;

	private Set<ImagePosition> fingerNumbers;
	private PatternType latentPatterns[];
	private byte latentFeatureData[];

	public Set<ImagePosition> getFingerNumbers() {
		return fingerNumbers;
	}

	public void setFingerNumbers(Set<ImagePosition> fingerNumbers) {
		this.fingerNumbers = fingerNumbers;
	}

	public PatternType[] getLatentPatterns() {
		return latentPatterns;
	}

	public void setLatentPatterns(PatternType[] latentPatterns) {
		this.latentPatterns = latentPatterns;
	}

	public AlgorithmType getAlgorithmType() {
		return algorithmType;
	}

	public void setAlgorithmType(AlgorithmType algorithmType) {
		this.algorithmType = algorithmType;
	}

	public BioFeType getFeType() {
		return feType;
	}

	public void setFeType(BioFeType feType) {
		this.feType = feType;
	}

	public byte[] getLatentFeatureData() {
		return latentFeatureData;
	}

	public void setLatentFeatureData(byte[] latentFeatureData) {
		this.latentFeatureData = latentFeatureData;
	}
}
