package com.nec.biomatcher.spec.transfer.job.verify;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.job.BioMatcherJobRequest;
import com.nec.biomatcher.spec.transfer.model.MatchInputParameter;

/**
 * The Class VerifyJobRequestDto.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class VerifyJobRequestDto extends BioMatcherJobRequest {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The probe biomeric data. */
	@XmlElement(required = false, nillable = true)
	protected VerifyBiometricData probeBiomericData;

	/** The gallery biomeric data list. */
	@XmlElement(required = false, nillable = true)
	protected List<VerifyBiometricData> galleryBiomericDataList;

	@XmlElement(required = false, nillable = true)
	protected List<MatchInputParameter> matchInputParameterList;

	/** The job timeout mill. */
	protected Long jobTimeoutMill;

	protected String jobMode;

	protected String callbackUrl;

	@XmlElement(required = false, nillable = true)
	protected Integer priority;

	public VerifyJobRequestDto() {

	}

	public VerifyJobRequestDto(VerifyBiometricData probeBiomericData, List<VerifyBiometricData> galleryBiomericDataList,
			List<MatchInputParameter> matchInputParameterList, String callbackUrl, Long jobTimeoutMill,
			String jobMode) {
		this.probeBiomericData = probeBiomericData;
		this.galleryBiomericDataList = galleryBiomericDataList;
		this.matchInputParameterList = matchInputParameterList;
		this.callbackUrl = callbackUrl;
		this.jobTimeoutMill = jobTimeoutMill;
		this.jobMode = jobMode;

	}

	public VerifyBiometricData getProbeBiomericData() {
		return probeBiomericData;
	}

	public void setProbeBiomericData(VerifyBiometricData probeBiomericData) {
		this.probeBiomericData = probeBiomericData;
	}

	public List<VerifyBiometricData> getGalleryBiomericDataList() {
		if (galleryBiomericDataList == null) {
			galleryBiomericDataList = new ArrayList<VerifyBiometricData>();
		}
		return galleryBiomericDataList;
	}

	public void setGalleryBiomericDataList(List<VerifyBiometricData> galleryBiomericDataList) {
		this.galleryBiomericDataList = galleryBiomericDataList;
	}

	public Long getJobTimeoutMill() {
		return jobTimeoutMill;
	}

	public void setJobTimeoutMill(Long jobTimeoutMill) {
		this.jobTimeoutMill = jobTimeoutMill;
	}

	public String getJobMode() {
		return jobMode;
	}

	public void setJobMode(String jobMode) {
		this.jobMode = jobMode;
	}

	public boolean hasMatchInputParameterList() {
		return matchInputParameterList != null && matchInputParameterList.size() > 0;
	}

	public List<MatchInputParameter> getMatchInputParameterList() {
		if (matchInputParameterList == null) {
			matchInputParameterList = new ArrayList<>();
		}
		return matchInputParameterList;
	}

	public void setMatchInputParameterList(List<MatchInputParameter> matchInputParameterList) {
		this.matchInputParameterList = matchInputParameterList;
	}

	public String getCallbackUrl() {
		return callbackUrl;
	}

	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}

	public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}
}
