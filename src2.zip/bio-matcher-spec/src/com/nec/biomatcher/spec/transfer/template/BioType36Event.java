package com.nec.biomatcher.spec.transfer.template;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BioType36Event extends BioTemplateEvent {
	private static final long serialVersionUID = 1L;

	private byte matchConfig; // Used to store the config based on which the
								// match param will be chosen.
	private Integer[] rolledFingerQualities;
	private Integer[] slapFingerQualities;
	private byte rolledCmlFeatureData[];
	private byte slapCmlFeatureData[];

	public byte getMatchConfig() {
		return matchConfig;
	}

	public void setMatchConfig(byte matchConfig) {
		this.matchConfig = matchConfig;
	}

	public Integer[] getRolledFingerQualities() {
		return rolledFingerQualities;
	}

	public void setRolledFingerQualities(Integer[] rolledFingerQualities) {
		this.rolledFingerQualities = rolledFingerQualities;
	}

	public Integer[] getSlapFingerQualities() {
		return slapFingerQualities;
	}

	public void setSlapFingerQualities(Integer[] slapFingerQualities) {
		this.slapFingerQualities = slapFingerQualities;
	}

	public byte[] getRolledCmlFeatureData() {
		return rolledCmlFeatureData;
	}

	public void setRolledCmlFeatureData(byte[] rolledCmlFeatureData) {
		this.rolledCmlFeatureData = rolledCmlFeatureData;
	}

	public byte[] getSlapCmlFeatureData() {
		return slapCmlFeatureData;
	}

	public void setSlapCmlFeatureData(byte[] slapCmlFeatureData) {
		this.slapCmlFeatureData = slapCmlFeatureData;
	}

}
