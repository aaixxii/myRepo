package com.nec.biomatcher.spec.transfer.job.verify;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.job.BioMatcherJobResult;
import com.nec.biomatcher.spec.transfer.model.BioJobStatus;
import com.nec.biomatcher.spec.transfer.model.ErrorMessageDto;
import com.nec.biomatcher.spec.transfer.model.FeatureData;
import com.nec.biomatcher.spec.transfer.model.ProbeInfoDto;

/**
 * The Class VerifyJobResultDto.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class VerifyJobResultDto extends BioMatcherJobResult {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	private String jobId;

	/** The candidate result list. */
	private List<VerifyCandidateResult> candidateResultList;

	private List<ProbeInfoDto> probeInfoList;

	/** The error list. */
	private List<ErrorMessageDto> errorList;	
	
	private FeatureData featureData;

	/** The status. */
	private BioJobStatus status;

	private String jobMode;

	public VerifyJobResultDto() {

	}

	public VerifyJobResultDto(BioJobStatus status) {
		this.status = status;
	}

	public List<VerifyCandidateResult> getCandidateResultList() {
		if (candidateResultList == null) {
			candidateResultList = new ArrayList<VerifyCandidateResult>();
		}
		return candidateResultList;
	}

	public void setCandidateResultList(List<VerifyCandidateResult> candidateResultList) {
		if (candidateResultList == null) {
			candidateResultList = new ArrayList<VerifyCandidateResult>();
		}
		this.candidateResultList = candidateResultList;
	}

	public List<ErrorMessageDto> getErrorList() {
		if (errorList == null) {
			errorList = new ArrayList<ErrorMessageDto>();
		}
		return errorList;
	}

	public void setErrorList(List<ErrorMessageDto> errorList) {
		this.errorList = errorList;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public String getJobMode() {
		return jobMode;
	}

	public void setJobMode(String jobMode) {
		this.jobMode = jobMode;
	}

	public List<ProbeInfoDto> getProbeInfoList() {
		if (probeInfoList == null) {
			probeInfoList = new ArrayList<>();
		}
		return probeInfoList;
	}

	public void setProbeInfoList(List<ProbeInfoDto> probeInfoList) {
		this.probeInfoList = probeInfoList;
	}

	public BioJobStatus getStatus() {
		return status;
	}

	public void setStatus(BioJobStatus status) {
		this.status = status;
	}

	public FeatureData getFeatureData() {
		return featureData;
	}

	public void setFeatureData(FeatureData featureData) {
		this.featureData = featureData;
	}
	
	

}
