package com.nec.biomatcher.spec.transfer.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

/**
 * The Class ExtractionErrorInfo.
 */
@XmlAccessorType(XmlAccessType.FIELD)
public class ExtractionErrorInfo {

	/** The error code. */
	private String errorCode;

	/** The error message. */
	private String errorMessage;

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

}
