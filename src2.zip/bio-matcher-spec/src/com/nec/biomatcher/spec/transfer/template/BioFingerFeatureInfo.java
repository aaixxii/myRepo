package com.nec.biomatcher.spec.transfer.template;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.core.Dto;
import com.nec.biomatcher.spec.transfer.model.PatternType;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BioFingerFeatureInfo implements Dto {
	private static final long serialVersionUID = 1L;

	private int fingerPosition;
	private PatternType primaryPatternType;
	private PatternType secondaryPatternType;
	private Integer quality;
	private byte featureData[];

	public PatternType getPrimaryPatternType() {
		return primaryPatternType;
	}

	public void setPrimaryPatternType(PatternType primaryPatternType) {
		this.primaryPatternType = primaryPatternType;
	}

	public Integer getQuality() {
		return quality;
	}

	public void setQuality(Integer quality) {
		this.quality = quality;
	}

	public int getFingerPosition() {
		return fingerPosition;
	}

	public void setFingerPosition(int fingerPosition) {
		this.fingerPosition = fingerPosition;
	}

	public PatternType getSecondaryPatternType() {
		return secondaryPatternType;
	}

	public void setSecondaryPatternType(PatternType secondaryPatternType) {
		this.secondaryPatternType = secondaryPatternType;
	}

	public byte[] getFeatureData() {
		return featureData;
	}

	public void setFeatureData(byte[] featureData) {
		this.featureData = featureData;
	}
}
