package com.nec.biomatcher.spec.transfer.template;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BioType11Event extends BioTemplateEvent {
	private static final long serialVersionUID = 1L;

	private Integer irisRightQuality;
	private Integer irisLeftQuality;
	private byte irisRightNecFeatureData[];
	private byte irisLeftNecFeatureData[];

	public Integer getIrisRightQuality() {
		return irisRightQuality;
	}

	public void setIrisRightQuality(Integer irisRightQuality) {
		this.irisRightQuality = irisRightQuality;
	}

	public Integer getIrisLeftQuality() {
		return irisLeftQuality;
	}

	public void setIrisLeftQuality(Integer irisLeftQuality) {
		this.irisLeftQuality = irisLeftQuality;
	}

	public byte[] getIrisRightNecFeatureData() {
		return irisRightNecFeatureData;
	}

	public void setIrisRightNecFeatureData(byte[] irisRightNecFeatureData) {
		this.irisRightNecFeatureData = irisRightNecFeatureData;
	}

	public byte[] getIrisLeftNecFeatureData() {
		return irisLeftNecFeatureData;
	}

	public void setIrisLeftNecFeatureData(byte[] irisLeftNecFeatureData) {
		this.irisLeftNecFeatureData = irisLeftNecFeatureData;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
