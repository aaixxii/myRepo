package com.nec.biomatcher.spec.transfer.model;

import java.io.Serializable;

/**
 * The Class BioMatcherFaultDetail.
 */
public class BioMatcherFaultDetail implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The detail message. */
	private String detailMessage;

	/** The code. */
	private String code;

	/**
	 * Instantiates a new bio matcher fault detail.
	 */
	public BioMatcherFaultDetail() {

	}

	/**
	 * Instantiates a new bio matcher fault detail.
	 *
	 * @param code
	 *            the code
	 * @param detailMessage
	 *            the detail message
	 */
	public BioMatcherFaultDetail(String code, String detailMessage) {
		this.code = code;
		this.detailMessage = detailMessage;
	}

	public String getDetailMessage() {
		return detailMessage;
	}

	public void setDetailMessage(String detailMessage) {
		this.detailMessage = detailMessage;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

}
