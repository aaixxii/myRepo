package com.nec.biomatcher.spec.transfer.job.search;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.core.Dto;
import com.nec.biomatcher.spec.transfer.model.MatchInputParameter;
import com.nec.biomatcher.spec.transfer.model.MetaInfoCommon;

/**
 * The Class SearchOptionsDto.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class SearchOptionsDto implements Dto {
	private static final long serialVersionUID = 1L;

	private MetaInfoCommon metaInfoCommon;

	private List<MatchInputParameter> matchInputParameterList;

	public MetaInfoCommon getMetaInfoCommon() {
		return metaInfoCommon;
	}

	public void setMetaInfoCommon(MetaInfoCommon metaInfoCommon) {
		this.metaInfoCommon = metaInfoCommon;
	}

	public boolean hasMatchInputParameterList() {
		return matchInputParameterList != null && matchInputParameterList.size() > 0;
	}

	public List<MatchInputParameter> getMatchInputParameterList() {
		if (matchInputParameterList == null) {
			matchInputParameterList = new ArrayList<>();
		}
		return matchInputParameterList;
	}

	public void setMatchInputParameterList(List<MatchInputParameter> matchInputParameterList) {
		this.matchInputParameterList = matchInputParameterList;
	}
}
