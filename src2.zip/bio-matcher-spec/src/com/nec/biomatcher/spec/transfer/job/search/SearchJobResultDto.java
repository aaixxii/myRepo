package com.nec.biomatcher.spec.transfer.job.search;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.job.BioMatcherJobResult;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractJobResultDto;
import com.nec.biomatcher.spec.transfer.model.BioJobStatus;
import com.nec.biomatcher.spec.transfer.model.BioParameterGroupDto;
import com.nec.biomatcher.spec.transfer.model.ErrorMessageDto;
import com.nec.biomatcher.spec.transfer.model.ProbeInfoDto;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class SearchJobResultDto extends BioMatcherJobResult {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	private String jobId;

	/** The candidate result list. */
	private List<SearchHitCandidate> candidateResultList;

	private List<ProbeInfoDto> probeInfoList;

	/** The error list. */
	private List<ErrorMessageDto> errorList;

	private BioJobStatus status;

	private String jobMode;

	private List<BioParameterGroupDto> keyValueGroupList;

	@XmlElement(required = false, nillable = true)
	private List<SearchStatistics> searchStatisticsList;

	@XmlElement(required = false, nillable = true)
	private ExtractJobResultDto extractJobResult;

	public SearchJobResultDto() {

	}

	public SearchJobResultDto(BioJobStatus status) {
		this.status = status;
	}

	public SearchJobResultDto(String jobId, BioJobStatus status) {
		this.jobId = jobId;
		this.status = status;
	}

	public boolean hasErrorList() {
		return errorList != null && errorList.size() > 0;
	}

	public List<ErrorMessageDto> getErrorList() {
		if (errorList == null) {
			errorList = new ArrayList<ErrorMessageDto>();
		}
		return errorList;
	}

	public void setErrorList(List<ErrorMessageDto> errorList) {
		this.errorList = errorList;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public String getJobMode() {
		return jobMode;
	}

	public void setJobMode(String jobMode) {
		this.jobMode = jobMode;
	}

	public int getHitCandidateCount() {
		return candidateResultList == null ? 0 : candidateResultList.size();
	}

	public boolean hasCandidateResultList() {
		return candidateResultList != null && candidateResultList.size() > 0;
	}

	public List<SearchHitCandidate> getCandidateResultList() {
		if (candidateResultList == null) {
			candidateResultList = new ArrayList<SearchHitCandidate>();
		}
		return candidateResultList;
	}

	public void setCandidateResultList(List<SearchHitCandidate> candidateResultList) {
		this.candidateResultList = candidateResultList;
	}

	public BioJobStatus getStatus() {
		return status;
	}

	public void setStatus(BioJobStatus status) {
		this.status = status;
	}

	public boolean hasProbeInfoList() {
		return probeInfoList != null && !probeInfoList.isEmpty();
	}

	public List<ProbeInfoDto> getProbeInfoList() {
		if (probeInfoList == null) {
			probeInfoList = new ArrayList<>();
		}
		return probeInfoList;
	}

	public void setProbeInfoList(List<ProbeInfoDto> probeInfoList) {
		this.probeInfoList = probeInfoList;
	}

	public List<BioParameterGroupDto> getKeyValueGroupList() {
		if (keyValueGroupList == null) {
			keyValueGroupList = new ArrayList<>();
		}
		return keyValueGroupList;
	}

	public void setKeyValueGroupList(List<BioParameterGroupDto> keyValueGroupList) {
		this.keyValueGroupList = keyValueGroupList;
	}

	public boolean hasSearchStatisticsList() {
		return searchStatisticsList != null && searchStatisticsList.size() > 0;
	}

	public List<SearchStatistics> getSearchStatisticsList() {
		if (searchStatisticsList == null) {
			searchStatisticsList = new ArrayList<>();
		}
		return searchStatisticsList;
	}

	public void setSearchStatisticsList(List<SearchStatistics> searchStatisticsList) {
		this.searchStatisticsList = searchStatisticsList;
	}

	public ExtractJobResultDto getExtractJobResult() {
		return extractJobResult;
	}

	public void setExtractJobResult(ExtractJobResultDto extractJobResult) {
		this.extractJobResult = extractJobResult;
	}

}
