package com.nec.biomatcher.spec.transfer.model;

import com.nec.biomatcher.spec.transfer.core.Dto;

public class BioRectangle implements Dto {
	private static final long serialVersionUID = 4007821434969775110L;
	protected PointDto upperLeft;
	protected PointDto upperRight;
	protected PointDto lowerRight;
	protected PointDto lowerLeft;

	public PointDto getUpperLeft() {
		return upperLeft;
	}

	public void setUpperLeft(PointDto upperLeft) {
		this.upperLeft = upperLeft;
	}

	public PointDto getUpperRight() {
		return upperRight;
	}

	public void setUpperRight(PointDto upperRight) {
		this.upperRight = upperRight;
	}

	public PointDto getLowerRight() {
		return lowerRight;
	}

	public void setLowerRight(PointDto lowerRight) {
		this.lowerRight = lowerRight;
	}

	public PointDto getLowerLeft() {
		return lowerLeft;
	}

	public void setLowerLeft(PointDto lowerLeft) {
		this.lowerLeft = lowerLeft;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}