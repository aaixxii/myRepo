package com.nec.biomatcher.spec.transfer.template;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.core.Dto;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BioTemplatePayload implements Dto {
	private static final long serialVersionUID = 1L;

	private BioTemplateHeader templateHeader;

	private List<BioTemplateEvent> events;

	public List<BioTemplateEvent> getEvents() {
		return events;
	}

	public void setEvents(List<BioTemplateEvent> events) {
		this.events = events;
	}

	public BioTemplateHeader getTemplateHeader() {
		return templateHeader;
	}

	public void setTemplateHeader(BioTemplateHeader templateHeader) {
		this.templateHeader = templateHeader;
	}
}
