package com.nec.biomatcher.spec.transfer.template;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BioType5Event extends BioTemplateEvent {
	private static final long serialVersionUID = 1L;

	private Integer quality;
	private byte faceNFV3FeatureData[];

	public Integer getQuality() {
		return quality;
	}

	public void setQuality(Integer quality) {
		this.quality = quality;
	}

	public byte[] getFaceNFV3FeatureData() {
		return faceNFV3FeatureData;
	}

	public void setFaceNFV3FeatureData(byte[] faceNFV3FeatureData) {
		this.faceNFV3FeatureData = faceNFV3FeatureData;
	}
}
