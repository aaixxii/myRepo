package com.nec.biomatcher.spec.transfer.biometrics;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.job.extract.ExtractInputPayloadDto;
import com.nec.biomatcher.spec.transfer.model.InsertTemplateInfo;

/**
 * The Class InsertBiometricEventDto.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class InsertBiometricEventDto extends BiometricEventSyncTypeDto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	private ExtractInputPayloadDto extractInputPayloadDto;

	private List<InsertTemplateInfo> insertTemplateInfoList;

	@XmlElement(required = false)
	private Boolean updateFlag;

	public ExtractInputPayloadDto getExtractInputPayloadDto() {
		return extractInputPayloadDto;
	}

	public void setExtractInputPayloadDto(ExtractInputPayloadDto extractInputPayloadDto) {
		this.extractInputPayloadDto = extractInputPayloadDto;
	}

	public boolean hasInsertTemplateInfoList() {
		return insertTemplateInfoList != null && insertTemplateInfoList.size() > 0;
	}

	public List<InsertTemplateInfo> getInsertTemplateInfoList() {
		if (insertTemplateInfoList == null) {
			insertTemplateInfoList = new ArrayList<>();
		}
		return insertTemplateInfoList;
	}

	public void setInsertTemplateInfoList(List<InsertTemplateInfo> insertTemplateInfoList) {
		this.insertTemplateInfoList = insertTemplateInfoList;
	}

	public Boolean getUpdateFlag() {
		return updateFlag;
	}

	public void setUpdateFlag(Boolean updateFlag) {
		this.updateFlag = updateFlag;
	}
}
