package com.nec.biomatcher.spec.transfer.commands;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.job.BioMatcherJobResult;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class GetJobResultActionResult extends BioCommandResult {
	private static final long serialVersionUID = 1L;

	private BioMatcherJobResult jobResult;
	private byte[] compressedJobResult;

	public GetJobResultActionResult() {
	}

	public GetJobResultActionResult(BioMatcherJobResult jobResult) {
		this.jobResult = jobResult;
	}

	public GetJobResultActionResult(byte[] compressedJobResult) {
		this.compressedJobResult = compressedJobResult;
	}

	public BioMatcherJobResult getJobResult() {
		return jobResult;
	}

	public void setJobResult(BioMatcherJobResult jobResult) {
		this.jobResult = jobResult;
	}

	public byte[] getCompressedJobResult() {
		return compressedJobResult;
	}

	public void setCompressedJobResult(byte[] compressedJobResult) {
		this.compressedJobResult = compressedJobResult;
	}

}
