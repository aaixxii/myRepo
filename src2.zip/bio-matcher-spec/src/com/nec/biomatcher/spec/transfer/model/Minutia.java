package com.nec.biomatcher.spec.transfer.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.core.Dto;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Minutia implements Dto { 
	
	private static final long serialVersionUID = -3198222807302956035L;
	
	@XmlAttribute(required = false)
	protected Integer minutiaCount;

	@XmlAttribute(required = true)
	protected AlgorithmType algorithmType;

	@XmlElement(required = true, nillable=false)
	protected byte[] data;

	public AlgorithmType getAlgorithmType() {
		return algorithmType;
	}

	public void setAlgorithmType(AlgorithmType algorithmType) {
		this.algorithmType = algorithmType;
	}

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = data;
	}

	public Integer getMinutiaCount() {
		return minutiaCount;
	}

	public void setMinutiaCount(Integer minutiaCount) {
		this.minutiaCount = minutiaCount;
	}	
	
}
