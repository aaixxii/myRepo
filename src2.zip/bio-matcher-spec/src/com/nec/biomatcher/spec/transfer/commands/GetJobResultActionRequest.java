package com.nec.biomatcher.spec.transfer.commands;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.model.BioJobType;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class GetJobResultActionRequest extends BioCommandRequest {
	private static final long serialVersionUID = 1L;

	@XmlElement(required = true)
	private String jobId;

	@XmlElement(required = true)
	private BioJobType jobType;

	private Boolean returnCompressesResult;

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public BioJobType getJobType() {
		return jobType;
	}

	public void setJobType(BioJobType jobType) {
		this.jobType = jobType;
	}

	public Boolean getReturnCompressesResult() {
		return returnCompressesResult;
	}

	public void setReturnCompressesResult(Boolean returnCompressesResult) {
		this.returnCompressesResult = returnCompressesResult;
	}
}
