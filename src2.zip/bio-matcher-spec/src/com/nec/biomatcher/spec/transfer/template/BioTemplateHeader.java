package com.nec.biomatcher.spec.transfer.template;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.core.Dto;
import com.nec.biomatcher.spec.transfer.model.GenderEnum;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BioTemplateHeader implements Dto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	private String externalId;
	private GenderEnum gender;
	private short yob;
	private byte race;
	private byte[] userFlags;
	private byte[] regionFlags;

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public GenderEnum getGender() {
		return gender;
	}

	public void setGender(GenderEnum gender) {
		this.gender = gender;
	}

	public short getYob() {
		return yob;
	}

	public void setYob(short yob) {
		this.yob = yob;
	}

	public byte getRace() {
		return race;
	}

	public void setRace(byte race) {
		this.race = race;
	}

	public byte[] getUserFlags() {
		return userFlags;
	}

	public void setUserFlags(byte[] userFlags) {
		this.userFlags = userFlags;
	}

	public byte[] getRegionFlags() {
		return regionFlags;
	}

	public void setRegionFlags(byte[] regionFlags) {
		this.regionFlags = regionFlags;
	}
}
