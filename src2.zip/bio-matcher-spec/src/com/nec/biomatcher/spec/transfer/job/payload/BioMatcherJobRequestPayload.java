package com.nec.biomatcher.spec.transfer.job.payload;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.core.Dto;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.search.SearchJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.sync.SyncJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.verify.VerifyJobRequestDto;

/**
 * The Class BioMatcherJobRequestPayload.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BioMatcherJobRequestPayload extends AbstractBioMatcherJobPayload implements Dto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The sync job request. */
	@XmlElement(required = false)
	protected SyncJobRequestDto syncJobRequestDto;

	/** The extract job request. */
	@XmlElement(required = false)
	protected ExtractJobRequestDto extractJobRequest;

	/** The search job request. */
	@XmlElement(required = false)
	protected SearchJobRequestDto searchJobRequest;

	/** The verify job request. */
	@XmlElement(required = false)
	protected VerifyJobRequestDto verifyJobRequest;

	@XmlAttribute(required = false)
	protected Long createDateTimeMilli;

	public ExtractJobRequestDto getExtractJobRequest() {
		return extractJobRequest;
	}

	public void setExtractJobRequest(ExtractJobRequestDto extractJobRequest) {
		this.extractJobRequest = extractJobRequest;
	}

	public SearchJobRequestDto getSearchJobRequest() {
		return searchJobRequest;
	}

	public void setSearchJobRequest(SearchJobRequestDto searchJobRequest) {
		this.searchJobRequest = searchJobRequest;
	}

	public VerifyJobRequestDto getVerifyJobRequest() {
		return verifyJobRequest;
	}

	public void setVerifyJobRequest(VerifyJobRequestDto verifyJobRequest) {
		this.verifyJobRequest = verifyJobRequest;
	}

	public SyncJobRequestDto getSyncJobRequestDto() {
		return syncJobRequestDto;
	}

	public void setSyncJobRequestDto(SyncJobRequestDto syncJobRequestDto) {
		this.syncJobRequestDto = syncJobRequestDto;
	}

	public Long getCreateDateTimeMilli() {
		return createDateTimeMilli;
	}

	public void setCreateDateTimeMilli(Long createDateTimeMilli) {
		this.createDateTimeMilli = createDateTimeMilli;
	}
}
