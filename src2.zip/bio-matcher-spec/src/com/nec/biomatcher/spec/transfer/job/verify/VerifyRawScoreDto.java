package com.nec.biomatcher.spec.transfer.job.verify;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlType;

import com.nec.biomatcher.spec.transfer.core.Dto;
import com.nec.biomatcher.spec.transfer.model.AlgorithmType;
import com.nec.biomatcher.spec.transfer.model.ImagePosition;
import com.nec.biomatcher.spec.transfer.model.PointDto;

@XmlType(propOrder={"score", "algorithmType" , "probePosition", "position", "probeMinutiaDataIndex","targetMinutiaDataIndex","quality","probeMatchedAreaCenter", "targetMatchedAreaCenter", "minutiaPairList" })
public class VerifyRawScoreDto implements Dto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;
	
	/** The score. */
	private Integer score;

	private AlgorithmType algorithmType;

	/** The position. */
	private ImagePosition position;
	
	private ImagePosition probePosition;
	
	private Integer probeMinutiaDataIndex;
	
	private Integer targetMinutiaDataIndex;
	
	private Integer quality;
	
	private PointDto probeMatchedAreaCenter;
	
	private PointDto targetMatchedAreaCenter;
	
	private List<MinutiaPairDto> minutiaPairList;	
	
	/**
	 * Instantiates a new verify raw score.
	 */
	public VerifyRawScoreDto() {
	}

	/**
	 * Instantiates a new verify raw score.
	 *
	 * @param position
	 *            the position
	 * @param score
	 *            the score
	 */
	public VerifyRawScoreDto(AlgorithmType algorithmType, Integer score, Integer quality) {
		this.algorithmType = algorithmType;			
		this.score = score;
		this.quality = quality;
	}

	public ImagePosition getPosition() {
		return position;
	}

	public void setPosition(ImagePosition position) {
		this.position = position;
	}

	public Integer getScore() {
		return score;
	}

	public void setScore(Integer score) {
		this.score = score;
	}

	public Integer getQuality() {
		return quality;
	}

	public void setQuality(Integer quality) {
		this.quality = quality;
	}

	public AlgorithmType getAlgorithmType() {
		return algorithmType;
	}

	public void setAlgorithmType(AlgorithmType algorithmType) {
		this.algorithmType = algorithmType;
	}

	public List<MinutiaPairDto> getMinutiaPairList() {
		if (minutiaPairList == null) {
			minutiaPairList = new ArrayList<>();
		}
		return minutiaPairList;
	}

	public void setMinutiaPairList(List<MinutiaPairDto> minutiaPairList) {		
		this.minutiaPairList = minutiaPairList;
	}

	public PointDto getProbeMatchedAreaCenter() {
		return probeMatchedAreaCenter;
	}

	public void setProbeMatchedAreaCenter(PointDto probeMatchedAreaCenter) {
		this.probeMatchedAreaCenter = probeMatchedAreaCenter;
	}

	public PointDto getTargetMatchedAreaCenter() {
		return targetMatchedAreaCenter;
	}

	public void setTargetMatchedAreaCenter(PointDto targetMatchedAreaCenter) {
		this.targetMatchedAreaCenter = targetMatchedAreaCenter;
	}

	public ImagePosition getProbePosition() {
		return probePosition;
	}

	public void setProbePosition(ImagePosition probePosition) {
		this.probePosition = probePosition;
	}

	public Integer getProbeMinutiaDataIndex() {
		return probeMinutiaDataIndex;
	}

	public void setProbeMinutiaDataIndex(Integer probeMinutiaDataIndex) {
		this.probeMinutiaDataIndex = probeMinutiaDataIndex;
	}

	public Integer getTargetMinutiaDataIndex() {
		return targetMinutiaDataIndex;
	}

	public void setTargetMinutiaDataIndex(Integer targetMinutiaDataIndex) {
		this.targetMinutiaDataIndex = targetMinutiaDataIndex;
	}	
}
