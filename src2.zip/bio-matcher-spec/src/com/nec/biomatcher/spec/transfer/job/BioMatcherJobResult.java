package com.nec.biomatcher.spec.transfer.job;

import com.nec.biomatcher.spec.transfer.core.Dto;

/**
 * The Class BioMatcherJobResult.
 */
public abstract class BioMatcherJobResult implements Dto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

}
