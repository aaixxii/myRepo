package com.nec.biomatcher.spec.transfer.jobdistribution;

import java.util.HashSet;
import java.util.Set;

import com.nec.biomatcher.spec.transfer.core.Dto;

public class SnSegmentJobInfoDto implements Dto {
	private static final long serialVersionUID = 1L;

	private String segmentJobId;
	private String parentJobId;
	private String requestKey;
	private String searchControllerId;
	private String searchNodeId;
	public long jobCreateTimestampMilli;
	private long jobTimeoutMilli;
	private Integer segmentId;
	private Set<Integer> segmentIdSet;
	private long assignmentDelayMilli = 0;

	public SnSegmentJobInfoDto() {

	}

	public SnSegmentJobInfoDto(String segmentJobId, String parentJobId, String requestKey, String searchControllerId,
			String searchNodeId) {
		this.segmentJobId = segmentJobId;
		this.parentJobId = parentJobId;
		this.requestKey = requestKey;
		this.searchControllerId = searchControllerId;
		this.searchNodeId = searchNodeId;
	}

	public String getSegmentJobId() {
		return segmentJobId;
	}

	public void setSegmentJobId(String segmentJobId) {
		this.segmentJobId = segmentJobId;
	}

	public String getSearchControllerId() {
		return searchControllerId;
	}

	public void setSearchControllerId(String searchControllerId) {
		this.searchControllerId = searchControllerId;
	}

	public String getSearchNodeId() {
		return searchNodeId;
	}

	public void setSearchNodeId(String searchNodeId) {
		this.searchNodeId = searchNodeId;
	}

	public long getJobTimeoutMilli() {
		return jobTimeoutMilli;
	}

	public void setJobTimeoutMilli(long jobTimeoutMilli) {
		this.jobTimeoutMilli = jobTimeoutMilli;
	}

	public boolean hasSegmentIdSet() {
		return segmentIdSet != null && !segmentIdSet.isEmpty();
	}

	public Set<Integer> getSegmentIdSet() {
		if (segmentIdSet == null) {
			segmentIdSet = new HashSet<>();
		}
		return segmentIdSet;
	}

	public void setSegmentIdSet(Set<Integer> segmentIdSet) {
		this.segmentIdSet = segmentIdSet;
	}

	public long getJobCreateTimestampMilli() {
		return jobCreateTimestampMilli;
	}

	public void setJobCreateTimestampMilli(long jobCreateTimestampMilli) {
		this.jobCreateTimestampMilli = jobCreateTimestampMilli;
	}

	public Integer getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(Integer segmentId) {
		this.segmentId = segmentId;
	}

	public String getParentJobId() {
		return parentJobId;
	}

	public void setParentJobId(String parentJobId) {
		this.parentJobId = parentJobId;
	}

	public String getRequestKey() {
		return requestKey;
	}

	public void setRequestKey(String requestKey) {
		this.requestKey = requestKey;
	}

	public long getAssignmentDelayMilli() {
		return assignmentDelayMilli;
	}

	public void setAssignmentDelayMilli(long assignmentDelayMilli) {
		this.assignmentDelayMilli = assignmentDelayMilli;
	}

}
