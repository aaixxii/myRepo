package com.nec.biomatcher.spec.transfer.job.search;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import com.nec.biomatcher.spec.transfer.core.Dto;

@XmlAccessorType(XmlAccessType.FIELD)
public class SearchHitEvent implements Dto {
	private static final long serialVersionUID = 1L;

	private String eventId;
	private Integer compositeScore = 0;
	private List<SearchRawScoreDto> rawScoreList;

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	public Integer getCompositeScore() {
		return compositeScore;
	}

	public void setCompositeScore(Integer compositeScore) {
		this.compositeScore = compositeScore;
	}

	public boolean hasRawScoreList() {
		return rawScoreList != null && rawScoreList.size() > 0;
	}

	public List<SearchRawScoreDto> getRawScoreList() {
		if (rawScoreList == null) {
			rawScoreList = new ArrayList<>();
		}
		return rawScoreList;
	}

	public void setRawScoreList(List<SearchRawScoreDto> rawScoreList) {
		this.rawScoreList = rawScoreList;
	}
}
