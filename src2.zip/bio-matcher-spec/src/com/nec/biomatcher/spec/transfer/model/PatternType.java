package com.nec.biomatcher.spec.transfer.model;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

@XmlEnum
public enum PatternType {

	@XmlEnumValue("A")
	Arch('A'),

	@XmlEnumValue("T")
	TendArch('T'),

	@XmlEnumValue("R")
	RightLoop('R'),

	@XmlEnumValue("L")
	LeftLoop('L'),

	@XmlEnumValue("W")
	Whorl('W'),

	@XmlEnumValue("S")
	Scar('S'),

	@XmlEnumValue("N")
	None('N'),

	@XmlEnumValue("U")
	Unknown('U');

	/** The Constant valueMap. */
	private static final Map<Character, PatternType> valueMap = Arrays.stream(values())
			.collect(Collectors.toMap(PatternType::getValue, (p) -> p));

	/** The value. */
	private final char value;

	/**
	 * Instantiates a new algorithm type.
	 *
	 * @param v
	 *            the v
	 */
	PatternType(char v) {
		value = v;
	}

	public char getValue() {
		return value;
	}

	/**
	 * Enum of.
	 *
	 * @param value
	 *            the value
	 * @return the algorithm type
	 */
	public static PatternType enumOf(Integer value) {
		if(value==null) {
			return null;
		}
		 return (PatternType) valueMap.get((char)value.intValue());		
	}
}
