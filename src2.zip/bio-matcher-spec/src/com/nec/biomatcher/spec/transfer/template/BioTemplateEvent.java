package com.nec.biomatcher.spec.transfer.template;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

import com.nec.biomatcher.spec.transfer.core.Dto;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@XmlSeeAlso({ BioType1Event.class, BioType2Event.class, BioType3Event.class, BioType4Event.class,BioType5Event.class,  
		BioType11Event.class, BioType12Event.class,
		BioType31Event.class, BioType32Event.class, BioType33Event.class, BioType34Event.class, BioType35Event.class,
		BioType36Event.class, BioType37Event.class, BioType38Event.class, BioType39Event.class, BioType40Event.class,
		BioType41Event.class, BioType42Event.class, BioType43Event.class, BioType44Event.class, BioType45Event.class,
		BioType46Event.class, BioType47Event.class, BioType48Event.class })
public class BioTemplateEvent implements Dto {
	private static final long serialVersionUID = 1L;

	private String eventId;

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

}
