package com.nec.biomatcher.spec.transfer.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

import com.nec.biomatcher.spec.transfer.core.Dto;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
@XmlSeeAlso({ BioParameterKeyEnum.class })
public class BioParameterDto implements Dto {
	private static final long serialVersionUID = 1L;

	@XmlAttribute(required = true)
	private String key;

	@XmlAttribute
	private String value;

	public BioParameterDto() {

	}

	public BioParameterDto(String key, String value) {
		this.key = key;
		this.value = value;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
