package com.nec.biomatcher.spec.transfer.template;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BioType1Event extends BioTemplateEvent {
	private static final long serialVersionUID = 1L;

	private Integer quality;
	private byte faceS17FeatureData[];

	public Integer getQuality() {
		return quality;
	}

	public void setQuality(Integer quality) {
		this.quality = quality;
	}

	public byte[] getFaceS17FeatureData() {
		return faceS17FeatureData;
	}

	public void setFaceS17FeatureData(byte[] faceS17FeatureData) {
		this.faceS17FeatureData = faceS17FeatureData;
	}

}
