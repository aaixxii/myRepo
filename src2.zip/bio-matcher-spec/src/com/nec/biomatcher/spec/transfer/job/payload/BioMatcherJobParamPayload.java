package com.nec.biomatcher.spec.transfer.job.payload;

import java.util.HashMap;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.nec.biomatcher.core.framework.common.MapPropertiesAdapter;
import com.nec.biomatcher.spec.transfer.core.Dto;

/**
 * The Class BioTransactionParamPayload.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BioMatcherJobParamPayload extends AbstractBioMatcherJobPayload implements Dto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The parameters. */
	@XmlJavaTypeAdapter(MapPropertiesAdapter.class)
	private HashMap<String, String> parameters = new HashMap<String, String>();

	/**
	 * Instantiates a new bio transaction param payload.
	 */
	public BioMatcherJobParamPayload() {
	}

	/**
	 * Instantiates a new bio transaction param payload.
	 * 
	 * @param parameters
	 *            the parameters
	 */
	public BioMatcherJobParamPayload(HashMap<String, String> parameters) {
		this.parameters = parameters;
	}

	/**
	 * Gets the parameters.
	 * 
	 * @return the parameters
	 */
	public HashMap<String, String> getParameters() {
		return parameters;
	}

	/**
	 * Sets the parameters.
	 * 
	 * @param parameters
	 *            the parameters
	 */
	public void setParameters(HashMap<String, String> parameters) {
		this.parameters = parameters;
	}
}