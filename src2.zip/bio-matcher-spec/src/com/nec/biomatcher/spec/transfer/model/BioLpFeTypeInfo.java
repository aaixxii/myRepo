package com.nec.biomatcher.spec.transfer.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

import com.nec.biomatcher.spec.transfer.core.Dto;

@XmlAccessorType(XmlAccessType.FIELD)
public class BioLpFeTypeInfo implements Dto {
	private static final long serialVersionUID = 1L;

	protected BioFeType pc2FeType;
	protected BioFeType fmp5FeType;

	public BioLpFeTypeInfo() {

	}

	public BioLpFeTypeInfo(BioFeType pc2FeType, BioFeType fmp5FeType) {
		this.pc2FeType = pc2FeType;
		this.fmp5FeType = fmp5FeType;
	}

	public BioFeType getPc2FeType() {
		return pc2FeType;
	}

	public void setPc2FeType(BioFeType pc2FeType) {
		this.pc2FeType = pc2FeType;
	}

	public BioFeType getFmp5FeType() {
		return fmp5FeType;
	}

	public void setFmp5FeType(BioFeType fmp5FeType) {
		this.fmp5FeType = fmp5FeType;
	}

}
