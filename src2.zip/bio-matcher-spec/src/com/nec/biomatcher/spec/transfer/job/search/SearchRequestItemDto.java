package com.nec.biomatcher.spec.transfer.job.search;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.core.Dto;

/**
 * The Class SearchRequestItemDto.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class SearchRequestItemDto implements Dto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The request item key. */
	private String requestItemKey;

	/** The bin id. */
	private List<Integer> binIdList;

	/** The search item payload dto. */
	private SearchItemInputPayloadDto searchItemPayloadDto;

	public String getRequestItemKey() {
		return requestItemKey;
	}

	public void setRequestItemKey(String requestItemKey) {
		this.requestItemKey = requestItemKey;
	}

	public SearchItemInputPayloadDto getSearchItemPayloadDto() {
		return searchItemPayloadDto;
	}

	public void setSearchItemPayloadDto(SearchItemInputPayloadDto searchItemPayloadDto) {
		this.searchItemPayloadDto = searchItemPayloadDto;
	}

	public List<Integer> getBinIdList() {
		if (binIdList == null) {
			binIdList = new ArrayList<>();
		}
		return binIdList;
	}

	public void setBinIdList(List<Integer> binIdList) {
		this.binIdList = binIdList;
	}

}
