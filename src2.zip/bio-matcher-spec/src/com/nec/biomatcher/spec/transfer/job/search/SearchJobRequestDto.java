package com.nec.biomatcher.spec.transfer.job.search;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.job.BioMatcherJobRequest;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractInputPayloadDto;
import com.nec.biomatcher.spec.transfer.model.MatchInputParameter;

/**
 * The Class SearchJobRequestDto.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class SearchJobRequestDto extends BioMatcherJobRequest {
	private static final long serialVersionUID = 1L;

	private ExtractInputPayloadDto extractInputPayloadDto;

	private List<SearchRequestItemDto> searchRequestItemList;

	protected String callbackUrl;

	protected Long jobTimeoutMill;

	protected String jobMode;

	protected List<MatchInputParameter> matchInputParameterList;

	@XmlElement(required = false, nillable = true)
	protected Integer priority;

	@XmlElement(required = false, nillable = true)
	protected String capacityGroupKey;

	@XmlElement(required = false, nillable = true)
	protected String searchFunctionId;

	@XmlElement(required = false, nillable = true)
	protected Boolean includeExtractionResult;

	public ExtractInputPayloadDto getExtractInputPayloadDto() {
		return extractInputPayloadDto;
	}

	public void setExtractInputPayloadDto(ExtractInputPayloadDto extractInputPayloadDto) {
		this.extractInputPayloadDto = extractInputPayloadDto;
	}

	public Long getJobTimeoutMill() {
		return jobTimeoutMill;
	}

	public void setJobTimeoutMill(Long jobTimeoutMill) {
		this.jobTimeoutMill = jobTimeoutMill;
	}

	public String getJobMode() {
		return jobMode;
	}

	public void setJobMode(String jobMode) {
		this.jobMode = jobMode;
	}

	public String getCallbackUrl() {
		return callbackUrl;
	}

	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}

	public boolean hasMatchInputParameterList() {
		return matchInputParameterList != null && matchInputParameterList.size() > 0;
	}

	public List<MatchInputParameter> getMatchInputParameterList() {
		if (matchInputParameterList == null) {
			matchInputParameterList = new ArrayList<>();
		}
		return matchInputParameterList;
	}

	public void setMatchInputParameterList(List<MatchInputParameter> matchInputParameterList) {
		this.matchInputParameterList = matchInputParameterList;
	}

	public List<SearchRequestItemDto> getSearchRequestItemList() {
		if (searchRequestItemList == null) {
			searchRequestItemList = new ArrayList<>();
		}
		return searchRequestItemList;
	}

	public void setSearchRequestItemList(List<SearchRequestItemDto> searchRequestItemList) {
		this.searchRequestItemList = searchRequestItemList;
	}

	public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	public String getCapacityGroupKey() {
		return capacityGroupKey;
	}

	public void setCapacityGroupKey(String capacityGroupKey) {
		this.capacityGroupKey = capacityGroupKey;
	}

	public Boolean getIncludeExtractionResult() {
		return includeExtractionResult;
	}

	public void setIncludeExtractionResult(Boolean includeExtractionResult) {
		this.includeExtractionResult = includeExtractionResult;
	}

	public String getSearchFunctionId() {
		return searchFunctionId;
	}

	public void setSearchFunctionId(String searchFunctionId) {
		this.searchFunctionId = searchFunctionId;
	}
}
