package com.nec.biomatcher.spec.transfer.model;

/**
 * The Enum ConsolidationType.
 */
public enum ConsolidationType {

	/** The by conatiner. */
	BY_CONATINER,

	/** The by candidate. */
	BY_CANDIDATE;

}
