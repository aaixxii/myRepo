package com.nec.biomatcher.spec.transfer.template;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BioType32Event extends BioTemplateEvent {
	private static final long serialVersionUID = 1L;

	private Integer[] rolledFingerQualities;
	private Integer[] slapFingerQualities;
	private byte rolledCmlafFeatureData[];
	private byte slapCmlafFeatureData[];

	public byte[] getRolledCmlafFeatureData() {
		return rolledCmlafFeatureData;
	}

	public void setRolledCmlafFeatureData(byte[] rolledCmlafFeatureData) {
		this.rolledCmlafFeatureData = rolledCmlafFeatureData;
	}

	public byte[] getSlapCmlafFeatureData() {
		return slapCmlafFeatureData;
	}

	public void setSlapCmlafFeatureData(byte[] slapCmlafFeatureData) {
		this.slapCmlafFeatureData = slapCmlafFeatureData;
	}

	public Integer[] getRolledFingerQualities() {
		return rolledFingerQualities;
	}

	public void setRolledFingerQualities(Integer[] rolledFingerQualities) {
		this.rolledFingerQualities = rolledFingerQualities;
	}

	public Integer[] getSlapFingerQualities() {
		return slapFingerQualities;
	}

	public void setSlapFingerQualities(Integer[] slapFingerQualities) {
		this.slapFingerQualities = slapFingerQualities;
	}

}
