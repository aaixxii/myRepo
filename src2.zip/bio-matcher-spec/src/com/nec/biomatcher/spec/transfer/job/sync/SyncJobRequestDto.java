package com.nec.biomatcher.spec.transfer.job.sync;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.biometrics.BiometricEventSyncTypeDto;
import com.nec.biomatcher.spec.transfer.job.BioMatcherJobRequest;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class SyncJobRequestDto extends BioMatcherJobRequest {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	@XmlElement(required = true, nillable = false)
	protected List<BiometricEventSyncTypeDto> eventSyncDtoList;

	/** The callback url. */
	protected String callbackUrl;

	/** The job timeout mill. */
	protected Long jobTimeoutMill;

	protected String jobMode;

	public List<BiometricEventSyncTypeDto> getEventSyncDtoList() {
		if (eventSyncDtoList == null) {
			eventSyncDtoList = new ArrayList<>();
		}
		return eventSyncDtoList;
	}

	public void setEventSyncDto(List<BiometricEventSyncTypeDto> eventSyncDtoList) {
		this.eventSyncDtoList = eventSyncDtoList;
	}

	public String getCallbackUrl() {
		return callbackUrl;
	}

	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}

	public Long getJobTimeoutMill() {
		return jobTimeoutMill;
	}

	public void setJobTimeoutMill(Long jobTimeoutMill) {
		this.jobTimeoutMill = jobTimeoutMill;
	}

	public String getJobMode() {
		return jobMode;
	}

	public void setJobMode(String jobMode) {
		this.jobMode = jobMode;
	}

}
