package com.nec.biomatcher.spec.transfer.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class PalmExtractInputImage extends ExtractInputImage {
	private static final long serialVersionUID = 1L;

	protected List<Image> images;

	protected List<ExtractInputParameter> extractionParameters;

	public List<Image> getImages() {
		if (images == null) {
			images = new ArrayList<>();
		}
		return images;
	}

	public void setImages(List<Image> images) {
		this.images = images;
	}

	public boolean hasExtractionParameters() {
		return extractionParameters != null && extractionParameters.size() > 0;
	}

	public List<ExtractInputParameter> getExtractionParameters() {
		return extractionParameters;
	}

	public void setExtractionParameters(List<ExtractInputParameter> extractionParameters) {
		this.extractionParameters = extractionParameters;
	}

}
