package com.nec.biomatcher.spec.transfer.model;

import javax.xml.bind.annotation.XmlEnum;

/**
 * The Enum GenderEnum.
 */
@XmlEnum
public enum GenderEnum {

	/** The f. */
	F,
	/** The m. */
	M,
	/** The u. */
	U;

	/**
	 * Value.
	 *
	 * @return the string
	 */
	public String value() {
		return name();
	}

	/**
	 * From value.
	 *
	 * @param v
	 *            the v
	 * @return the gender enum
	 */
	public static GenderEnum fromValue(String v) {
		return valueOf(v);
	}

}
