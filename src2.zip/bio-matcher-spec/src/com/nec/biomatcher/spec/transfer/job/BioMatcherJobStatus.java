package com.nec.biomatcher.spec.transfer.job;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

/**
 * The Enum BioMatcherJobStatus.
 */
@XmlType
@XmlEnum(String.class)
public enum BioMatcherJobStatus {

	/** The pending. */
	@XmlEnumValue("PENDING")
	PENDING("Pending"),

	/** The completed. */
	@XmlEnumValue("COMPLETED")
	COMPLETED("Completed"),

	/** The error. */
	@XmlEnumValue("ERROR")
	ERROR("Error"),

	/** The expired. */
	@XmlEnumValue("EXPIRED")
	EXPIRED("Expired");

	/** The description. */
	private String description;

	/**
	 * Instantiates a new bio matcher job status.
	 *
	 * @param description
	 *            the description
	 */
	private BioMatcherJobStatus(String description) {
		this.description = description;
	}

	public String getDescription() {
		return description;
	}

}
