package com.nec.biomatcher.spec.transfer.job.search;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.core.Dto;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class SearchStatistics implements Dto {
	private static final long serialVersionUID = 1L;

	private Integer binId;

	private Long readCount;

	private Long matchCount;

	public SearchStatistics() {
	}

	public SearchStatistics(Integer binId, Long readCount, Long matchCount) {
		this.binId = binId;
		this.readCount = readCount;
		this.matchCount = matchCount;
	}

	public Long getReadCount() {
		return readCount;
	}

	public void setReadCount(Long readCount) {
		this.readCount = readCount;
	}

	public Long getMatchCount() {
		return matchCount;
	}

	public void setMatchCount(Long matchCount) {
		this.matchCount = matchCount;
	}

	public Integer getBinId() {
		return binId;
	}

	public void setBinId(Integer binId) {
		this.binId = binId;
	}
}
