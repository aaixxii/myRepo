package com.nec.biomatcher.spec.transfer.model;

public enum BioFeType {
	A, B, C, E, P, L, CMLaF, CML, ELFT;
}
