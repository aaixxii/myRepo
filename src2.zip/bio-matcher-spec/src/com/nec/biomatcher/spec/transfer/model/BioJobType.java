package com.nec.biomatcher.spec.transfer.model;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

@XmlEnum
public enum BioJobType {
	@XmlEnumValue("EXTRACT")
	EXTRACT,

	@XmlEnumValue("VERIFY")
	VERIFY,

	@XmlEnumValue("SEARCH")
	SEARCH,

	@XmlEnumValue("SYNC")
	SYNC;
}
