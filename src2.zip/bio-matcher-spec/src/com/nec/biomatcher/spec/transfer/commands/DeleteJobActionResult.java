package com.nec.biomatcher.spec.transfer.commands;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class DeleteJobActionResult extends BioCommandResult {
	private static final long serialVersionUID = 1L;

}
