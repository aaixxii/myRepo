package com.nec.biomatcher.spec.transfer.template;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BioType31Event extends BioTemplateEvent {
	private static final long serialVersionUID = 1L;

	private Integer[] fingerQualities;
	private byte cmlafFeatureData[];

	public byte[] getCmlafFeatureData() {
		return cmlafFeatureData;
	}

	public void setCmlafFeatureData(byte[] cmlafFeatureData) {
		this.cmlafFeatureData = cmlafFeatureData;
	}

	public Integer[] getFingerQualities() {
		return fingerQualities;
	}

	public void setFingerQualities(Integer[] fingerQualities) {
		this.fingerQualities = fingerQualities;
	}

}
