package com.nec.biomatcher.spec.transfer.template;

import java.util.Set;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.model.ImagePosition;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BioType48Event extends BioTemplateEvent {
	private static final long serialVersionUID = 1L;

	private Set<ImagePosition> partNumbers;
	private byte[] latentLfmlPalmFeatureData;

	public Set<ImagePosition> getPartNumbers() {
		return partNumbers;
	}

	public void setPartNumbers(Set<ImagePosition> partNumbers) {
		this.partNumbers = partNumbers;
	}

	public byte[] getLatentLfmlPalmFeatureData() {
		return latentLfmlPalmFeatureData;
	}

	public void setLatentLfmlPalmFeatureData(byte[] latentLfmlPalmFeatureData) {
		this.latentLfmlPalmFeatureData = latentLfmlPalmFeatureData;
	}

}
