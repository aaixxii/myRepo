package com.nec.biomatcher.spec.transfer.commands;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.model.BioJobStatus;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class GetJobStatusActionResult extends BioCommandResult {
	private static final long serialVersionUID = 1L;

	private BioJobStatus jobStatus;

	public GetJobStatusActionResult() {
	}

	public GetJobStatusActionResult(BioJobStatus jobStatus) {
		this.jobStatus = jobStatus;
	}

	public BioJobStatus getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(BioJobStatus jobStatus) {
		this.jobStatus = jobStatus;
	}
}
