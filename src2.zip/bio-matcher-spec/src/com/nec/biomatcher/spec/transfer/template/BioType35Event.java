package com.nec.biomatcher.spec.transfer.template;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BioType35Event extends BioTemplateEvent {
	private static final long serialVersionUID = 1L;

	private Boolean isRolledFlag;
	private byte matchConfig; // Used to store the config based on which the
								// match param will be chosen.
	private Integer[] fingerQualities;
	private byte cmlFeatureData[];

	public Boolean getIsRolledFlag() {
		return isRolledFlag;
	}

	public void setIsRolledFlag(Boolean isRolledFlag) {
		this.isRolledFlag = isRolledFlag;
	}

	public byte getMatchConfig() {
		return matchConfig;
	}

	public void setMatchConfig(byte matchConfig) {
		this.matchConfig = matchConfig;
	}

	public Integer[] getFingerQualities() {
		return fingerQualities;
	}

	public void setFingerQualities(Integer[] fingerQualities) {
		this.fingerQualities = fingerQualities;
	}

	public byte[] getCmlFeatureData() {
		return cmlFeatureData;
	}

	public void setCmlFeatureData(byte[] cmlFeatureData) {
		this.cmlFeatureData = cmlFeatureData;
	}

}
