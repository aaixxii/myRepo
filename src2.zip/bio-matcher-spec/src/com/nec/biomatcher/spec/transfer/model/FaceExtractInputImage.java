package com.nec.biomatcher.spec.transfer.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * The Class FaceExtractInputImage.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class FaceExtractInputImage extends ExtractInputImage {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The face image. */
	@XmlElement(nillable = false, required = true)
	protected Image faceImage;

	/** The face extraction parameters. */
	protected List<ExtractInputParameter> extractionParameters;

	/**
	 * Instantiates a new face extract input image.
	 */
	public FaceExtractInputImage() {

	}

	/**
	 * Instantiates a new face extract input image.
	 *
	 * @param faceImage
	 *            the face image
	 * @param faceExtractionParameters
	 *            the face extraction parameters
	 */
	public FaceExtractInputImage(Image faceImage, ExtractInputParameter... extractionParameters) {
		this.faceImage = faceImage;
		if (extractionParameters != null && extractionParameters.length > 0) {
			Collections.addAll(getExtractionParameters(), extractionParameters);
		}
	}

	public Image getFaceImage() {
		return faceImage;
	}

	public void setFaceImage(Image faceImage) {
		this.faceImage = faceImage;
	}

	public boolean hasExtractionParameters() {
		return extractionParameters != null && extractionParameters.size() > 0;
	}

	public List<ExtractInputParameter> getExtractionParameters() {
		if (extractionParameters == null) {
			extractionParameters = new ArrayList<ExtractInputParameter>();
		}
		return extractionParameters;
	}

	public void setExtractionParameters(List<ExtractInputParameter> extractionParameters) {
		this.extractionParameters = extractionParameters;
	}
}
