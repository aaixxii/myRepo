package com.nec.biomatcher.spec.transfer.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.core.Dto;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class ProbeInfoDto implements Dto {
	private static final long serialVersionUID = 1L;

	private AlgorithmType algorithmType;

	private ImagePosition position;

	private Integer quality;

	public ProbeInfoDto() {

	}

	public ProbeInfoDto(AlgorithmType algorithmType, ImagePosition position, Integer quality) {
		this.algorithmType = algorithmType;
		this.position = position;
		this.quality = quality;
	}

	public AlgorithmType getAlgorithmType() {
		return algorithmType;
	}

	public void setAlgorithmType(AlgorithmType algorithmType) {
		this.algorithmType = algorithmType;
	}

	public ImagePosition getPosition() {
		return position;
	}

	public void setPosition(ImagePosition position) {
		this.position = position;
	}

	public Integer getQuality() {
		return quality;
	}

	public void setQuality(Integer quality) {
		this.quality = quality;
	}
}
