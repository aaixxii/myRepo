package com.nec.biomatcher.extractor.queueing;

import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Supplier;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.NDC;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

import com.google.common.base.MoreObjects;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.util.concurrent.Uninterruptibles;
import com.nec.biomatcher.comp.callback.CallbackService;
import com.nec.biomatcher.comp.cluster.JobSlotClusterService;
import com.nec.biomatcher.comp.cluster.MatcherFunctionControlUtil;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.config.exception.BioMatcherConfigServiceException;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerInfo;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioConnectionType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioProtocolType;
import com.nec.biomatcher.comp.inmemory.BioTaskType;
import com.nec.biomatcher.comp.inmemory.InMemoryManager;
import com.nec.biomatcher.comp.inmemory.callback.CallbackListener;
import com.nec.biomatcher.comp.inmemory.tasktimeout.TaskTimeoutListener;
import com.nec.biomatcher.comp.lobstream.LobImageService;
import com.nec.biomatcher.comp.lobstream.exception.LobImageNotFoundException;
import com.nec.biomatcher.comp.lobstream.exception.LobImageServiceException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeConnectionException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeSendException;
import com.nec.biomatcher.comp.metrics.MetricsUtil;
import com.nec.biomatcher.comp.template.packing.model.MeghaEventHeader;
import com.nec.biomatcher.comp.template.packing.model.MeghaTemplateHeader;
import com.nec.biomatcher.comp.util.JobEntry;
import com.nec.biomatcher.comp.zmq.ZmqPullMessageListener;
import com.nec.biomatcher.core.framework.common.BiKey;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.DelayedItem;
import com.nec.biomatcher.core.framework.common.GuavaCacheCleaner;
import com.nec.biomatcher.core.framework.common.HessianSerializer;
import com.nec.biomatcher.core.framework.common.HostnameUtil;
import com.nec.biomatcher.core.framework.common.concurrent.CommonTaskScheduler;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentProducerConsumer;
import com.nec.biomatcher.core.framework.common.exception.SerializationException;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.extractor.service.BioExtractionService;
import com.nec.biomatcher.extractor.service.exception.BioExtractionException;
import com.nec.biomatcher.extractor.service.exception.BioExtractionTimeoutException;
import com.nec.biomatcher.extractor.util.ExtractJobInfo;
import com.nec.biomatcher.extractor.util.ExtractProtobufUtil;
import com.nec.biomatcher.extractor.util.ExtractionConstants;
import com.nec.biomatcher.extractor.util.ExtractionJaxbXmlConvertor;
import com.nec.biomatcher.spec.services.BioSearchJobControllerService;
import com.nec.biomatcher.spec.services.exception.BioExtractionJobServiceException;
import com.nec.biomatcher.spec.transfer.job.BioMatcherJobType;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractJobResultDto;
import com.nec.biomatcher.spec.transfer.job.payload.BioMatcherJobRequestPayload;
import com.nec.biomatcher.spec.transfer.job.payload.BioMatcherJobResultPayload;
import com.nec.biomatcher.spec.transfer.model.BioJobStatus;
import com.nec.biomatcher.spec.transfer.model.ErrorMessageDto;
import com.nec.megha.proto.extract.ExtractResponseProto.ExtractResponse;

/**
 * The Class ExtractionJobQueueHelper.
 */
public class ExtractionJobQueueHelper implements InitializingBean, DisposableBean {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(ExtractionJobQueueHelper.class);

	private static final Logger EXTRACT_JOB_NODE_REQUEST_LOGGER = Logger.getLogger("EXTRACT_JOB_NODE_REQUEST");
	private static final Logger EXTRACT_JOB_NODE_RESPONSE_LOGGER = Logger.getLogger("EXTRACT_JOB_NODE_RESPONSE");
	private static final Logger MATCHER_NODE_DUMP_ERROR_PAYLOAD_LOGGER = Logger
			.getLogger("MATCHER_NODE_DUMP_ERROR_PAYLOAD");

	/** The bio parameter service. */
	protected BioParameterService bioParameterService;

	protected BioMatcherConfigService bioMatcherConfigService;

	/** The bio extraction service. */
	private BioExtractionService bioExtractionService;

	/** The lob image service. */
	private LobImageService lobImageService;

	private CallbackService httpCallbackService;
	private CallbackService zmqCallbackService;

	/** The pending job queue. */
	private PriorityBlockingQueue<JobEntry> pendingJobQueue = new PriorityBlockingQueue<>();

	private DelayQueue<DelayedItem<String>> extractJobQueueHousekeepingQueue = new DelayQueue<>();

	/** The extraction job executor. */
	protected ConcurrentProducerConsumer<String> extractionJobExecutor;

	/** The extraction controller id. */
	private String extractionControllerId;

	/** The notify callabck in worker thread flag. */
	private boolean notifyCallabckInWorkerThreadFlag = false;

	/** The extraction jaxb xml convertor. */
	private final ExtractionJaxbXmlConvertor extractionJaxbXmlConvertor = new ExtractionJaxbXmlConvertor();

	/** The initialization count. */
	private static AtomicInteger initializationCount = new AtomicInteger();

	private ConcurrentHashMap<String, ExtractJobInfo> extractJobRequestMap = new ConcurrentHashMap<>();

	private static LoadingCache<String, BiKey<ExtractJobRequestDto, Throwable>> bioExtractJobRequestDtoCache;

	private JobSlotClusterService extractClusterService;	

	private MatcherFunctionControlUtil matcherFunctionControlUtil;

	public String getExtractionControllerId() {
		return extractionControllerId;
	}

	/**
	 * Submit extraction job.
	 *
	 * @param jobId
	 *            the job id
	 * @param jobRequestDto
	 *            the job request dto
	 * @return the string
	 * @throws BioExtractionJobServiceException
	 *             the bio extraction job service exception
	 * @throws LobImageServiceException
	 *             the lob image service exception
	 * @throws SerializationException
	 *             the serialization exception
	 */
	public String submitExtractionJob(String jobId, ExtractJobRequestDto jobRequestDto)
			throws BioExtractionJobServiceException, LobImageServiceException, SerializationException {
		logger.info(
				"In submitExtractionJob : Received extraction job with extractJobId: " + jobId + ", jobTimeoutMill: "
						+ jobRequestDto.getJobTimeoutMill() + ", callbackUrl: " + jobRequestDto.getCallbackUrl());

		MetricsUtil.meter(BioComponentType.EC, extractionControllerId, "EXTRACT_JOB_SUBMITTED");

		assert jobRequestDto.getExtractInputPayload() != null : "Invalid ExtractInputPayload";

		assert CollectionUtils.isNotEmpty(jobRequestDto.getExtractInputPayload()
				.getTemplateExtractInputImageList()) : "Invalid TemplateExtractInputImageList";

		assert StringUtils.length(jobRequestDto.getExtractInputPayload()
				.getCandidateId()) <= MeghaTemplateHeader.EXTERNAL_ID_MAX_SIZE : "Invalid externalId";

		assert StringUtils.length(jobRequestDto.getExtractInputPayload()
				.getEventId()) <= MeghaEventHeader.EVENT_ID_MAX_SIZE : "Invalid eventId";

		if (extractionControllerId == null) {
			throw new BioExtractionJobServiceException("Extraction Controller is not enabled on hostname: "
					+ HostnameUtil.getHostname() + ", ipAddress: " + HostnameUtil.getIpAddress());
		}

		long maxExtractJobTimeoutMilli = bioParameterService.getParameterValue("MAX_EXTRACT_JOB_TIMEOUT_MILLI",
				"DEFAULT", TimeUnit.MINUTES.toMillis(2));
		Long jobTimeoutMill = Math.min(maxExtractJobTimeoutMilli,
				MoreObjects.firstNonNull(jobRequestDto.getJobTimeoutMill(), maxExtractJobTimeoutMilli));

		jobRequestDto.setJobTimeoutMill(jobTimeoutMill);

		ExtractJobInfo extractJobInfo = new ExtractJobInfo(jobId, jobRequestDto.getCallbackUrl(), jobTimeoutMill);
		if (jobRequestDto.getPriority() != null) {
			extractJobInfo.setPriority(jobRequestDto.getPriority());
		}		

		try {
			if (matcherFunctionControlUtil.tryAcquireFunctionSlot(BioMatcherJobType.EXTRACT.name())) {
				extractJobInfo.markFunctionSlotAcquired();
			} else {
				throw new BioExtractionJobServiceException("Unable to acquire extraction function job slot");
			}

			InMemoryManager.registerExtractForTimeout(jobId, jobTimeoutMill);

			bioExtractJobRequestDtoCache.put(jobId, new BiKey<>(jobRequestDto, null));

			boolean saveExtractRequestPayload = bioParameterService
					.getParameterValue("SAVE_EXTRACT_REQUEST_PAYLOAD_FLAG", "DEFAULT", false);
			BioMatcherJobRequestPayload bioMatcherJobRequestPayload = new BioMatcherJobRequestPayload();
			bioMatcherJobRequestPayload.setExtractJobRequest(jobRequestDto);
			if (!saveExtractRequestPayload) {
				// replace with dummy job request without job payload
				bioMatcherJobRequestPayload.setExtractJobRequest(new ExtractJobRequestDto(null,
						jobRequestDto.getCallbackUrl(), jobRequestDto.getJobTimeoutMill(), jobRequestDto.getJobMode()));
			}

			lobImageService.createLob(jobId, HessianSerializer.marshal(bioMatcherJobRequestPayload), "req");

			long extractJobRetentionPeriodMilli = bioParameterService
					.getParameterValue("EXTRACT_JOB_RETENTION_PERIOD_MILLI", "DEFAULT", TimeUnit.MINUTES.toMillis(30));
			extractJobQueueHousekeepingQueue
					.add(new DelayedItem<String>(jobId, jobTimeoutMill + extractJobRetentionPeriodMilli));

			extractJobRequestMap.put(jobId, extractJobInfo);

			pendingJobQueue.add(new JobEntry(jobId, jobRequestDto.getPriority()));

			return jobId;
		} catch (BioExtractionJobServiceException | LobImageServiceException | SerializationException ex) {
			releaseFunctionSlot(extractJobInfo);
			throw ex;
		} catch (Throwable th) {
			releaseFunctionSlot(extractJobInfo);
			throw new BioExtractionJobServiceException("Error in submitExtractionJob: " + th.getMessage(), th);
		}
	}

	private final void releaseFunctionSlot(ExtractJobInfo extractJobInfo) {
		if (extractJobInfo != null && extractJobInfo.isFunctionSlotAcquiredFlag()) {
			extractJobInfo.releaseFunctionSlot(matcherFunctionControlUtil);
		}
	}

	/**
	 * Submit extraction job.
	 *
	 * @param jobId
	 *            the job id
	 * @return the extract job result dto
	 */
	private void submitExtractionJob(String jobId) {
		NDC.clear();
		NDC.push("EX_JOBID#" + jobId);

		ExtractJobInfo extractJobInfo = extractJobRequestMap.get(jobId);
		if (extractJobInfo == null) {
			logger.warn("In submitExtractionJob: Cannot find ExtractJobInfo with jobId: " + jobId);
			return;
		}

		ExtractJobResultDto errorResult = null;
		try {
			if (extractJobInfo.getJobRequestDto() == null) {
				BiKey<ExtractJobRequestDto, Throwable> bioExtractJobRequestKey = bioExtractJobRequestDtoCache
						.get(jobId);
				if (bioExtractJobRequestKey.getB() != null) {
					throw bioExtractJobRequestKey.getB();
				}
				extractJobInfo.setJobRequestDto(bioExtractJobRequestKey.getA());
			}

			bioExtractionService.submitExtractionJob(jobId, extractJobInfo);
		} catch (BioExtractionTimeoutException | BioMatcherNodeSendException ex) {
			logger.error(ex.getClass().getSimpleName() + " Error in submitExtractionJob: " + ex.getMessage(), ex);
			MetricsUtil.meter(BioComponentType.EC, extractionControllerId, "EXTRACT_TIMEOUT_ERROR");
			errorResult = new ExtractJobResultDto();
			errorResult.setJobId(jobId);
			errorResult.setStatus(BioJobStatus.COMPLETED);
			errorResult.getErrorList().add(new ErrorMessageDto(ExtractionConstants.ERROR_CODE_JOB_TIMEOUT,
					ex.getMessage(), null, new Date()));
		} catch (BioMatcherNodeConnectionException ex) {
			logger.error(ex.getClass().getSimpleName() + " Error in submitExtractionJob: " + ex.getMessage(), ex);
			MetricsUtil.meter(BioComponentType.EC, extractionControllerId, "EXTRACT_CONNECTION_ERROR");
			errorResult = new ExtractJobResultDto();
			errorResult.setJobId(jobId);
			errorResult.setStatus(BioJobStatus.COMPLETED);
			errorResult.getErrorList().add(new ErrorMessageDto(ExtractionConstants.ERROR_CODE_JOB_TIMEOUT,
					ex.getMessage(), null, new Date()));
		} catch (LobImageServiceException | LobImageNotFoundException | SerializationException ex) {
			logger.error(ex.getClass().getSimpleName() + " Error in submitExtractionJob: " + ex.getMessage(), ex);
			MetricsUtil.meter(BioComponentType.EC, extractionControllerId, "EXTRACT_OTHER_ERROR");
			errorResult = new ExtractJobResultDto();
			errorResult.setJobId(jobId);
			errorResult.setStatus(BioJobStatus.COMPLETED);
			errorResult.getErrorList().add(new ErrorMessageDto(ExtractionConstants.ERROR_CODE_LOBSTREAM_ACCESS,
					ex.getMessage(), null, new Date()));
		} catch (Throwable th) {
			logger.error(th.getClass().getSimpleName() + " Error in submitExtractionJob: " + th.getMessage(), th);
			MetricsUtil.meter(BioComponentType.EC, extractionControllerId, "EXTRACT_OTHER_ERROR");
			errorResult = new ExtractJobResultDto();
			errorResult.setJobId(jobId);
			errorResult.setStatus(BioJobStatus.COMPLETED);
			errorResult.getErrorList().add(new ErrorMessageDto(ExtractionConstants.ERROR_CODE_GENERAL, th.getMessage(),
					null, new Date()));
		} finally {
			extractJobInfo.setJobRequestDto(null);
		}

		if (errorResult != null) {
			saveExtractionResult(jobId, errorResult);
		}
	}

	private void saveExtractionResult(String extractJobId, ExtractJobResultDto extractJobResultDto) {
		logger.debug("In saveExtractionResult: extractJobId: " + extractJobId);

		InMemoryManager.removeFromTimeoutQueue(extractJobId);

		pendingJobQueue.remove(new JobEntry(extractJobId));

		ExtractJobInfo extractJobInfo = extractJobRequestMap.remove(extractJobId);
		if (extractJobInfo == null) {
			logger.warn("In saveExtractionResult: Cannot find ExtractJobInfo with jobId: " + extractJobId);
			return;
		}

		releaseFunctionSlot(extractJobInfo);

		if (!extractJobInfo.getJobCompletedFlag()) {
			extractJobInfo.notifyJobCompleted(extractClusterService);
			MetricsUtil.time(BioComponentType.EC, extractionControllerId, "EXTRACT_JOB_TIME_TAKEN",
					extractJobInfo.getDelayFromCreateDateTime(), TimeUnit.MILLISECONDS);
		}

		logger.info("Extract job completed for extractJobId: " + extractJobId + ", status: "
				+ extractJobResultDto.getStatus() + ", assignedExtractNodeId: "
				+ extractJobInfo.getAssignedExtractNodeId() + ", assignmentDelayMilli: "
				+ extractJobInfo.getAssignmentDelayMilli() + ", submitToExtractNodeTimeTakenMilli: "
				+ extractJobInfo.getSubmitTimeTakenMilli() + ", extractNodeTimeTakenMilli: "
				+ extractJobInfo.getExtractNodeTimeTakenMilli() + ", TotalTimeTakenMilli: "
				+ extractJobInfo.getDelayFromCreateDateTime());

		MetricsUtil.time("FUNCTION.EXTRACT.JOB_TIME_TAKEN", extractJobInfo.getExtractNodeTimeTakenMilli(),
				TimeUnit.MILLISECONDS);

		try {
			BioMatcherJobResultPayload bioMatcherJobResultPayload = new BioMatcherJobResultPayload();
			bioMatcherJobResultPayload.setBioMatcherJobResult(extractJobResultDto);
			bioMatcherJobResultPayload.setCallbackUrl(extractJobInfo.getCallbackUrl());

			byte lobData[] = HessianSerializer.marshal(bioMatcherJobResultPayload);

			try {
				lobImageService.createLob(extractJobId, lobData, "res");
			} catch (Throwable th) {
				th = new BioExtractionException(
						"Error saving extraction request for extractJobId: " + extractJobId + " : " + th.getMessage(),
						th);
				createErrorResult(extractJobId, extractJobInfo.getCallbackUrl(), "res",
						ExtractionConstants.ERROR_CODE_LOBSTREAM_ACCESS, th);
			}
		} catch (Throwable th) {
			th = new BioExtractionException(
					"Error saving extraction request for extractJobId: " + extractJobId + " : " + th.getMessage(), th);
			createErrorResult(extractJobId, extractJobInfo.getCallbackUrl(), "res",
					ExtractionConstants.ERROR_CODE_SERIALIZATION, th);
		}

		if (StringUtils.isNotBlank(extractJobInfo.getCallbackUrl())) {
			if (notifyCallabckInWorkerThreadFlag) {
				notifyJobCompleted(extractJobId, extractJobInfo.getCallbackUrl(), extractJobResultDto);
			} else {
				InMemoryManager.submitForExtractCallback(extractJobId, extractJobInfo.getCallbackUrl());
			}
		}

		try {
			lobImageService.deleteLob(extractJobId, "req");
		} catch (Throwable th) {
			th = new BioExtractionException(
					"Error deleting extraction request for extractJobId: " + extractJobId + " : " + th.getMessage(),
					th);
			createErrorLob(extractJobId, "derror", th);
		}
	}

	/**
	 * Notify job completed.
	 *
	 * @param jobId
	 *            the job id
	 */
	private void notifyJobCompleted(String jobId, String callbackUrl) {
		try {
			if (CallbackService.isBatchCallbackUrl(callbackUrl)) {
				notifyJobCompleted(jobId, callbackUrl, null);
			} else {
				byte[] lobData = lobImageService.getLobData(jobId, "res");

				BioMatcherJobResultPayload bioMatcherJobResultPayload = HessianSerializer.unmarshal(lobData);

				notifyJobCompleted(jobId, bioMatcherJobResultPayload.getCallbackUrl(),
						(ExtractJobResultDto) bioMatcherJobResultPayload.getBioMatcherJobResult());
			}
		} catch (Throwable th) {
			logger.error("Error during notifyJobCompleted for jobId: " + jobId + " : " + th.getMessage(), th);
		}
	}

	/**
	 * Notify job completed.
	 *
	 * @param jobId
	 *            the job id
	 * @param callbackUrl
	 *            the callback url
	 * @param jobResultDto
	 *            the job result dto
	 */
	private void notifyJobCompleted(String jobId, String callbackUrl, ExtractJobResultDto jobResultDto) {
		ExtractJobInfo extractJobInfo = extractJobRequestMap.remove(jobId);

		releaseFunctionSlot(extractJobInfo);

		if (extractJobInfo != null && !extractJobInfo.getJobCompletedFlag()) {
			logger.warn("In notifyJobCompleted: Marking incomplete job with jobId: " + jobId);
			extractJobInfo.notifyJobCompleted(extractClusterService);
			MetricsUtil.time(BioComponentType.EC, extractionControllerId, "EXTRACT_JOB_TIME_TAKEN",
					extractJobInfo.getDelayFromCreateDateTime(), TimeUnit.MILLISECONDS);
		}

		if (StringUtils.isBlank(callbackUrl)) {
			return;
		}
		try {
			if (!callbackUrl.startsWith("bio")) {
				if (callbackUrl.startsWith("http")) {
					httpCallbackService.postCallback(callbackUrl,
							jobResultDto == null ? null : extractionJaxbXmlConvertor.marshal(jobResultDto));
				} else {
					zmqCallbackService.postCallback(callbackUrl,
							jobResultDto == null ? null : extractionJaxbXmlConvertor.marshal(jobResultDto));
				}
			} else if (callbackUrl.startsWith("biosync://")) {
				String syncJobId = StringUtils.substringAfter(callbackUrl, "biosync://");
				BioSearchJobControllerService bioSearchJobControllerService = SpringServiceManager
						.getBean("bioSearchJobControllerService");
				bioSearchJobControllerService.notifySyncJobExtractionCompleted(syncJobId, jobResultDto);
			} else if (callbackUrl.startsWith("biosearch://")) {
				String searchJobId = StringUtils.substringAfter(callbackUrl, "biosearch://");
				BioSearchJobControllerService bioSearchJobControllerService = SpringServiceManager
						.getBean("bioSearchJobControllerService");
				bioSearchJobControllerService.notifySearchJobExtractionCompleted(searchJobId, jobResultDto);
			} else {
				logger.error("Callback url is not supported for jobId: " + jobId + ", callbackUrl: " + callbackUrl);
				throw new Exception(
						"Callback url is not supported for jobId: " + jobId + ", callbackUrl: " + callbackUrl);
			}
		} catch (Throwable th) {
			th = new BioExtractionException("Error during callback for jobId: " + jobId + ", callbackUrl: "
					+ callbackUrl + " : " + th.getMessage(), th);
			createErrorLob(jobId, "cerror", th);
		}
	}

	/**
	 * Notify job timeout.
	 *
	 * @param jobId
	 *            the job id
	 */
	private void notifyJobTimeout(String jobId) {

		pendingJobQueue.remove(new JobEntry(jobId));

		ExtractJobInfo extractJobInfo = extractJobRequestMap.get(jobId);
		if (extractJobInfo == null) {
			logger.warn("In notifyJobTimeout: Cannot find ExtractJobInfo with jobId: " + jobId);
			return;
		}

		releaseFunctionSlot(extractJobInfo);

		if (!extractJobInfo.getJobCompletedFlag()) {
			BioExtractionException ex = new BioExtractionException("Error extraction timeout for jobId: " + jobId);

			ExtractJobResultDto result = new ExtractJobResultDto();
			result.setJobId(jobId);
			result.setStatus(BioJobStatus.COMPLETED);
			result.getErrorList().add(new ErrorMessageDto(ExtractionConstants.ERROR_CODE_JOB_TIMEOUT, ex.getMessage(),
					null, new Date()));

			saveExtractionResult(jobId, result);
		}

	}

	private final String getExtractResultCallbackUrl() throws BioMatcherConfigServiceException {
		String connectionUrl = bioMatcherConfigService.getServerConnectionUrl(extractionControllerId,
				BioComponentType.EC, BioConnectionType.WORKER_CALLBACK, BioProtocolType.ZEROMQ);
		if (StringUtils.isBlank(connectionUrl)) {
			throw new IllegalArgumentException(
					"Error in getExtractResultCallbackUrl: callback url is not configured for extractionControllerId: "
							+ extractionControllerId + ", connectionType: " + BioConnectionType.WORKER_CALLBACK
							+ ", protocolType: " + BioProtocolType.ZEROMQ);
		}
		return connectionUrl;
	}

	/**
	 * Creates the error result.
	 *
	 * @param jobId
	 *            the job id
	 * @param callbackUrl
	 *            the callback url
	 * @param lobType
	 *            the lob type
	 * @param errorCode
	 *            the error code
	 * @param th
	 *            the th
	 * @return the extract job result dto
	 */
	private final ExtractJobResultDto createErrorResult(String jobId, String callbackUrl, String lobType,
			String errorCode, Throwable th) {
		ExtractJobResultDto result = new ExtractJobResultDto();

		result.setJobId(jobId);
		result.setStatus(BioJobStatus.COMPLETED);
		result.getErrorList()
				.add(new ErrorMessageDto(errorCode, th.getMessage(), null, new Date()));

		BioMatcherJobResultPayload bioMatcherJobResultPayload = new BioMatcherJobResultPayload();
		bioMatcherJobResultPayload.setBioMatcherJobResult(result);
		bioMatcherJobResultPayload.setCallbackUrl(callbackUrl);

		try {
			lobImageService.createLob(jobId, HessianSerializer.marshal(bioMatcherJobResultPayload), lobType);
		} catch (Throwable error) {
			logger.error("Error in createErrorResult while for jobId: " + jobId + " : " + error.getMessage(), error);
		}

		return result;
	}

	/**
	 * Creates the error lob.
	 *
	 * @param jobId
	 *            the job id
	 * @param lobType
	 *            the lob type
	 * @param th
	 *            the th
	 */
	private final void createErrorLob(String jobId, String lobType, Throwable th) {
		try {
			lobImageService.createLob(jobId, HessianSerializer.marshal(th), lobType);
		} catch (Throwable error) {
			logger.error("Error in createErrorLob while for jobId: " + jobId + " : " + error.getMessage(), error);
		}
	}

	/**
	 * Gets the extraction job status.
	 *
	 * @param jobId
	 *            the job id
	 * @return the extraction job status
	 * @throws LobImageServiceException
	 *             the lob image service exception
	 */
	public BioJobStatus getExtractionJobStatus(String jobId) throws LobImageServiceException {
		if (lobImageService.checkLobExists(jobId, "res")) {
			return BioJobStatus.COMPLETED;
		} else if (lobImageService.checkLobExists(jobId, "req")) {
			return BioJobStatus.PENDING;
		} else {
			return BioJobStatus.NOT_FOUND;
		}
	}

	/**
	 * Gets the extraction job result.
	 *
	 * @param jobId
	 *            the job id
	 * @return the extraction job result
	 * @throws LobImageServiceException
	 *             the lob image service exception
	 * @throws LobImageNotFoundException
	 *             the lob image not found exception
	 * @throws SerializationException
	 *             the serialization exception
	 */
	public ExtractJobResultDto getExtractionJobResult(String jobId)
			throws LobImageServiceException, LobImageNotFoundException, SerializationException {
		byte lobData[] = lobImageService.getLobData(jobId, "res");

		if (lobData != null) {
			BioMatcherJobResultPayload bioMatcherJobResultPayload = HessianSerializer.unmarshal(lobData);
			return (ExtractJobResultDto) bioMatcherJobResultPayload.getBioMatcherJobResult();
		}

		if (lobImageService.checkLobExists(jobId, "req")) {
			return new ExtractJobResultDto(BioJobStatus.PENDING);
		} else {
			return new ExtractJobResultDto(BioJobStatus.NOT_FOUND);
		}
	}

	public ExtractJobRequestDto getExtractJobRequest(String jobId)
			throws LobImageServiceException, LobImageNotFoundException, SerializationException {
		byte lobData[] = lobImageService.getLobData(jobId, "req");
		BioMatcherJobRequestPayload bioMatcherJobRequestPayload = HessianSerializer.unmarshal(lobData);
		return (ExtractJobRequestDto) bioMatcherJobRequestPayload.getExtractJobRequest();
	}
	
	public void deleteExtractionJob(String extractJobId) throws LobImageServiceException, BioMatcherConfigServiceException {
		logger.info("In deleteExtractJob: extractJobId: " + extractJobId);
		List<BioServerInfo> bioServerInfoList = bioMatcherConfigService.getServerInfoListByComponentType(BioComponentType.EC);
		if (bioServerInfoList.size() < 1) {
			logger.info("No active EC. return");
		}		

		StringBuilder sb = new StringBuilder();
		for (BioServerInfo info : bioServerInfoList) {			
			sb.append(info.getServerId());
			sb.append(",");
		}
		sb.deleteCharAt(sb.length() -1);	
		String notifyMsg = sb.toString() + ":" + extractJobId; 
		logger.info("Notify message:" + " to EC:" + notifyMsg);
		bioExtractionService.notifyExtractJobCanceling(notifyMsg);	
	}

	/**
	 * Delete extraction job.
	 *
	 * @param jobId
	 *            the job id
	 */
	public void deleteMyExtractJob(String jobId) {
		try {
			ExtractJobInfo extractJobInfo = extractJobRequestMap.remove(jobId);
			if (extractJobInfo != null && !extractJobInfo.getJobCompletedFlag()) {
				logger.warn("In deleteExtractionJob: Deleting incomplete job with jobId: " + jobId);
				extractJobInfo.notifyJobCompleted(extractClusterService);
				MetricsUtil.time(BioComponentType.EC, extractionControllerId, "EXTRACT_JOB_TIME_TAKEN",
						extractJobInfo.getDelayFromCreateDateTime(), TimeUnit.MILLISECONDS);
			}

			releaseFunctionSlot(extractJobInfo);
			pendingJobQueue.remove(new JobEntry(jobId));
			lobImageService.deleteLobsByLobId(jobId);
			extractJobQueueHousekeepingQueue.remove(new DelayedItem<String>(jobId, 0L));
			InMemoryManager.removeFromTimeoutQueue(jobId);
			
		} catch (Throwable th) {
			logger.error("Error deleting lob for lobId: " + jobId + " : " + th.getMessage(), th);
		}
	}

	private void processExtractResponseDataBuf(byte[] extractResponseDataBuf) {
		String extractJobId = null;
		try {
			ExtractResponse extractProtoResponse = null;
			try {
				extractProtoResponse = ExtractResponse.parseFrom(extractResponseDataBuf);
			} catch (Throwable th) {
				logger.error("Error parsing ExtractResponse in processExtractResponseDataBuf: " + th.getMessage(), th);
				if (MATCHER_NODE_DUMP_ERROR_PAYLOAD_LOGGER.isTraceEnabled()) {
					MATCHER_NODE_DUMP_ERROR_PAYLOAD_LOGGER
							.error("Error parsing ExtractResponse in processExtractResponseDataBuf: " + th.getMessage()
									+ ", responsePayload: ["
									+ Base64.getEncoder().encodeToString(extractResponseDataBuf) + "]", th);
				}
				return;
			}

			extractJobId = extractProtoResponse.getMsgId();
			if (EXTRACT_JOB_NODE_RESPONSE_LOGGER.isTraceEnabled()) {
				EXTRACT_JOB_NODE_RESPONSE_LOGGER.trace("In processExtractResponseDataBuf: extractJobId: " + extractJobId
						+ ", extractProtoResponse: " + extractProtoResponse.toString());
			}
			
			ExtractJobInfo extJobInfo = extractJobRequestMap.get(extractJobId);			
			if (extJobInfo == null) {
				logger.info("In processExtractResponseDataBuf: Cannot find extractJobInfo for extractJobId:" + extractJobId + ". do nothing");
				return;
			}			

			ExtractJobResultDto extractJobResultDto = ExtractProtobufUtil.getExtractJobResult(extractProtoResponse);
			extractJobResultDto.setJobId(extractJobId);

			saveExtractionResult(extractJobId, extractJobResultDto);
		} catch (Throwable th) {
			logger.error(
					"Error in processExtractResponseDataBuf: extractJobId: " + extractJobId + " : " + th.getMessage(),
					th);
		}
	}

	private void startExtractCallbackListener() throws Exception {
		logger.info("In startExtractCallbackListener");
		String extractResultCallbackUrl = null;
		try {
			extractResultCallbackUrl = getExtractResultCallbackUrl();

			Supplier<Integer> zmqIoThreadCountSupplier = BioParameterService
					.getIntSupplier("EXTRACT_RESULT_LISTENER_ZMQ_IO_THREAD_COUNT", "DEFAULT", 10);
			Supplier<Integer> messageExecutorConcurrencySupplier = BioParameterService
					.getIntSupplier("EC_EXTRACT_RESULT_LISTENER_CONCURRENCY_COUNT", "DEFAULT", 50);

			ZmqPullMessageListener zmqExtractResultListener = new ZmqPullMessageListener("EC_EXTRACT_RESULT_LISTENER",
					extractResultCallbackUrl, zmqIoThreadCountSupplier, messageExecutorConcurrencySupplier,
					(extractResponseDataBuf) -> processExtractResponseDataBuf(extractResponseDataBuf));

			zmqExtractResultListener.startZmqPullListener();
		} catch (Throwable th) {
			Exception ex = new Exception(
					"Error in startExtractCallbackListener during binding of the ZmqPullMessageListener on extractResultCallbackUrl: "
							+ extractResultCallbackUrl + " : " + th.getMessage(),
					th);
			logger.error(ex.getMessage(), ex);

			CommonLogger.STATUS_LOG.error(ex.getMessage());

			throw ex;
		}
	}

	private final synchronized void initializeExtractJobRequestDtoCache() {
		if (bioExtractJobRequestDtoCache == null) {

			logger.info("In initializeExtractJobRequestDtoCache");
			int maxExtractJobRequestDtoCacheCount = BioParameterService
					.getIntSupplier("MAX_EXTRACT_JOB_REQUEST_PAYLOAD_CACHE_COUNT", "DEFAULT", 100).get();
			long extractJobRequestDtoCacheExpiryMilli = BioParameterService.getLongSupplier(
					"EXTRACT_JOB_REQUEST_PAYLOAD_CACHE_EXPIRY_MILLI", "DEFAULT", TimeUnit.SECONDS.toMillis(2)).get();

			bioExtractJobRequestDtoCache = CacheBuilder.newBuilder().maximumSize(maxExtractJobRequestDtoCacheCount)
					// .softValues()
					.concurrencyLevel(200).expireAfterWrite(extractJobRequestDtoCacheExpiryMilli, TimeUnit.MILLISECONDS)
					.build(new CacheLoader<String, BiKey<ExtractJobRequestDto, Throwable>>() {
						public BiKey<ExtractJobRequestDto, Throwable> load(String extractJobId) {
							try {
								return new BiKey<>(getExtractJobRequest(extractJobId), null);
							} catch (Throwable th) {
								return new BiKey<>(null, th);
							}

						}
					});

			boolean registerGuavaCacheCleanerFlag = BioParameterService
					.getBooleanSupplier("REGISTER_GUAVA_CACHE_CLEANER_FLAG", "DEFAULT", false).get();
			if (registerGuavaCacheCleanerFlag) {
				GuavaCacheCleaner.registerCache("EXTRACT_JOB_REQUEST_PAYLOAD_CACHE", bioExtractJobRequestDtoCache);
			}
		}
	}

	public void setBioExtractionService(BioExtractionService bioExtractionService) {
		this.bioExtractionService = bioExtractionService;
	}

	public void setLobImageService(LobImageService lobImageService) {
		this.lobImageService = lobImageService;
	}

	public void setBioParameterService(BioParameterService bioParameterService) {
		this.bioParameterService = bioParameterService;
	}

	public void setHttpCallbackService(CallbackService httpCallbackService) {
		this.httpCallbackService = httpCallbackService;
	}

	public void setZmqCallbackService(CallbackService zmqCallbackService) {
		this.zmqCallbackService = zmqCallbackService;
	}

	@Override
	public void destroy() throws Exception {
		logger.error("Destroy called for ExtractionJobQueueHelper bean");
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		logger.info("In afterPropertiesSet: " + initializationCount.get());

		synchronized (ExtractionJobQueueHelper.class) {
			if (initializationCount.get() > 0) {
				return;
			}

			initializationCount.incrementAndGet();

			extractClusterService = bioExtractionService.getExtractClusterService();

			extractionControllerId = bioExtractionService.getExtractionControllerId();

			if (extractionControllerId == null) {
				return;
			}

			matcherFunctionControlUtil = extractClusterService.getMatcherFunctionControlUtil();

			initializeExtractJobRequestDtoCache();

			CommonTaskScheduler.scheduleWithFixedDelay(
					new ExtractJobHouseKeepingTask(extractJobQueueHousekeepingQueue, this, bioParameterService), 100,
					100, TimeUnit.MILLISECONDS);

			Supplier<Integer> workerConcurrencyCountSupplier = BioParameterService
					.getIntSupplier("EXTRACTION_WORKER_THREAD_CONCURRENCY", "DEFAULT", 50);

			extractionJobExecutor = new ConcurrentProducerConsumer<>("EXTRACT_JOB_WORKER",
					() -> Uninterruptibles.takeUninterruptibly(pendingJobQueue).getJobId(),
					(exJobId) -> submitExtractionJob(exJobId), workerConcurrencyCountSupplier);

			startExtractCallbackListener();

			InMemoryManager.callbackListenerMap.put(BioTaskType.EXTRACT, new CallbackListener() {
				@Override
				public void notifyCallback(String taskKey, String callbackUrl) {
					notifyJobCompleted(taskKey, callbackUrl);
				}
			});

			InMemoryManager.timeoutListenerMap.put(BioTaskType.EXTRACT, new TaskTimeoutListener() {

				@Override
				public void notifyTaskTimeout(String jobId) {
					notifyJobTimeout(jobId);

				}
			});

			notifyCallabckInWorkerThreadFlag = bioParameterService
					.getParameterValue("NOTIFY_EXTRACTION_CALLBACK_IN_WORKER_THREAD_FLAG", "DEFAULT", false);

			InMemoryManager.startCallbackExecutor();

			MetricsUtil.registerGauge(BioComponentType.EC, extractionControllerId, "PENDING_EXTRACT_JOB_COUNT", () -> {
				return pendingJobQueue.size();
			});
		}
	}
	
	

	public ConcurrentHashMap<String, ExtractJobInfo> getExtractJobRequestMap() {
		return extractJobRequestMap;
	}

	public void setBioMatcherConfigService(BioMatcherConfigService bioMatcherConfigService) {
		this.bioMatcherConfigService = bioMatcherConfigService;
	}
}
