package com.nec.biomatcher.extractor.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.google.protobuf.InvalidProtocolBufferException;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.common.parameter.exception.BioParameterServiceException;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.util.CommonProtobufUtil;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractInputPayloadDto;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractJobResultDto;
import com.nec.biomatcher.spec.transfer.model.AlgorithmType;
import com.nec.biomatcher.spec.transfer.model.BioCropInfo;
import com.nec.biomatcher.spec.transfer.model.BioJobStatus;
import com.nec.biomatcher.spec.transfer.model.BioParameterDto;
import com.nec.biomatcher.spec.transfer.model.BioParameterGroupDto;
import com.nec.biomatcher.spec.transfer.model.BioRectangle;
import com.nec.biomatcher.spec.transfer.model.ErrorMessageDto;
import com.nec.biomatcher.spec.transfer.model.ExtractInputParameter;
import com.nec.biomatcher.spec.transfer.model.ExtractManualData;
import com.nec.biomatcher.spec.transfer.model.FaceExtractInputImage;
import com.nec.biomatcher.spec.transfer.model.FingerExtractInputImage;
import com.nec.biomatcher.spec.transfer.model.FisData;
import com.nec.biomatcher.spec.transfer.model.Image;
import com.nec.biomatcher.spec.transfer.model.ImagePosition;
import com.nec.biomatcher.spec.transfer.model.IrisExtractInputImage;
import com.nec.biomatcher.spec.transfer.model.MetaInfoCommon;
import com.nec.biomatcher.spec.transfer.model.Minutia;
import com.nec.biomatcher.spec.transfer.model.MinutiaData;
import com.nec.biomatcher.spec.transfer.model.Modality;
import com.nec.biomatcher.spec.transfer.model.MultiModalExtractInputImage;
import com.nec.biomatcher.spec.transfer.model.PaextData;
import com.nec.biomatcher.spec.transfer.model.PalmExtractInputImage;
import com.nec.biomatcher.spec.transfer.model.PointDto;
import com.nec.biomatcher.spec.transfer.model.Skeleton;
import com.nec.biomatcher.spec.transfer.model.TemplateExtractInputImage;
import com.nec.biomatcher.spec.transfer.model.TemplateInfo;
import com.nec.biomatcher.spec.transfer.model.TemplateType;
import com.nec.megha.proto.common.CommonProto.CapsuleType;
import com.nec.megha.proto.common.CommonProto.Crop;
import com.nec.megha.proto.common.CommonProto.ExtractBiometricData;
import com.nec.megha.proto.common.CommonProto.FeatureData;
import com.nec.megha.proto.common.CommonProto.ImageData;
import com.nec.megha.proto.common.CommonProto.KeyValue;
import com.nec.megha.proto.common.CommonProto.KeyValueGroup;
import com.nec.megha.proto.common.CommonProto.KeyValueGroupHolder;
import com.nec.megha.proto.common.CommonProto.Point;
import com.nec.megha.proto.common.CommonProto.SubType;
import com.nec.megha.proto.extract.ExtractRequestProto.ExtractRequest;
import com.nec.megha.proto.extract.ExtractResponseProto.Capsule;
import com.nec.megha.proto.extract.ExtractResponseProto.ExtractResponse;


/**
 * The Class ExtractProtobufUtil.
 */
public class ExtractProtobufUtil {
	private static final Logger logger = Logger.getLogger(ExtractProtobufUtil.class);
	private static BioMatcherConfigService bioMatcherConfigService;

	/**
	 * To protobuf.
	 *
	 * @param jobId
	 *            the job id
	 * @param request
	 *            the request
	 * @param templateTypeTemplateCodeMap
	 *            the template type template code map
	 * @param bioParameterService
	 *            the bio parameter service
	 * @return the byte[]
	 * @throws BioParameterServiceException
	 *             the bio parameter service exception
	 */
	public static ExtractRequest toProtobuf(String jobId, ExtractJobRequestDto request, String extractCallbackUrl,
			BioParameterService bioParameterService) throws BioParameterServiceException {

		if (request.getExtractInputPayload() == null
				|| CollectionUtils.isEmpty(request.getExtractInputPayload().getTemplateExtractInputImageList())) {
			throw new IllegalArgumentException("Extraction payload is not set in ExtractJobRequestDto");
		}

		ExtractInputPayloadDto extractInputPayloadDto = request.getExtractInputPayload();

		ExtractRequest.Builder extractRequestBuilder = ExtractRequest.newBuilder();

		extractRequestBuilder.setMsgId(jobId);
		extractRequestBuilder.setResponseEndpoint(extractCallbackUrl);

		if (extractInputPayloadDto.getCandidateId() != null) {
			extractRequestBuilder.setExternalId(extractInputPayloadDto.getCandidateId());
		}

		if (extractInputPayloadDto.getEventId() != null) {
			extractRequestBuilder.setEventId(extractInputPayloadDto.getEventId());
		}

		if (extractInputPayloadDto.getBiometricId() != null) {
			extractRequestBuilder.setBiometricId(extractInputPayloadDto.getBiometricId());
		}

		if (request.getJobMode() != null) {
			extractRequestBuilder.setMode(request.getJobMode());
		}

		if (extractInputPayloadDto.getMetaInfoCommon() != null) {
			MetaInfoCommon metaInfoCommon = extractInputPayloadDto.getMetaInfoCommon();
			if (metaInfoCommon.getGender() != null) {
				extractRequestBuilder.setGender(metaInfoCommon.getGender().name());
			}
			if (metaInfoCommon.getYob() != null) {
				extractRequestBuilder.setYob(metaInfoCommon.getYob());
			}
			if (metaInfoCommon.getRegionFlags() != null) {
				extractRequestBuilder.setRegionFlags(metaInfoCommon.getRegionFlags());
			}
			if (StringUtils.isNotBlank(metaInfoCommon.getUserFlags())) {
				extractRequestBuilder.setUserFlags(metaInfoCommon.getUserFlags());
			}
		}

		//Set<AlgorithmType> algorithmTypeSet = new HashSet<>();
		//final List<AlgorithmType> algorithmTypeSet = new ArrayList<>();
		final List<AlgorithmType> algorithmTypeSet = new CopyOnWriteArrayList<>();

		//final Map<AlgorithmType, ExtractInputParameter> algorithmTypeExtractInputParameterMap = new HashMap<>();		
		List<ExtractInputParameter> algorithmTypeExtractInputParameterList = new CopyOnWriteArrayList<>();

		Set<CapsuleType> capsuleTypeBuilderSet = new HashSet<>();

		extractRequestBuilder.setBiometricData(buildClientExtractBiometricData(extractInputPayloadDto,
				capsuleTypeBuilderSet, algorithmTypeSet, algorithmTypeExtractInputParameterList, bioParameterService));
		List<AlgorithmType> algorithmTypeSetFromClient = new ArrayList<>();
		
		for (ExtractInputParameter para : algorithmTypeExtractInputParameterList) {
		    if (para.getAlgorithmType() != null)
		        algorithmTypeSetFromClient.add(para.getAlgorithmType());		  
		}
		if (algorithmTypeSetFromClient.size() > 1) {
		    algorithmTypeSet.clear();
		    algorithmTypeSet.addAll(algorithmTypeSetFromClient);
		}

		extractRequestBuilder.addAllCapsuleType(capsuleTypeBuilderSet);

		KeyValueGroupHolder.Builder keyValueGroupHolderBuilder = KeyValueGroupHolder.newBuilder();

		//algorithmTypeSet.addAll(algorithmTypeExtractInputParameterMap.keySet());	      

		for (AlgorithmType algorithmType : algorithmTypeSet) { 
			KeyValueGroup.Builder extractParamsKeyValueGroupBuilder = KeyValueGroup.newBuilder();
			switch (algorithmType) {
			case FACE_NEC_S17:
			case FACE_NEC_S18:
			case FACE_NEC_NFV2:
			case FACE_NEC_NFG2:
			case FACE_NEC_NFV3:
			case IRIS_NEC:
			case IRIS_DELTA_ID:
				extractParamsKeyValueGroupBuilder.setGroupName("DETECTION_PARAM_" + algorithmType.name());
				break;

            case FINGER_CMLAF:
            case FINGER_PC3R:
            case FINGER_LFML:
            case FINGER_ELFT:
            case FINGER_CML:
                extractParamsKeyValueGroupBuilder.setGroupName("EXTRACTION_PARAM_FINGER");
                break;
                
            case FINGER_PC2:
            case FINGER_FMP5:
            case FINGER_FIS:
                extractParamsKeyValueGroupBuilder.setGroupName("EXTRACTION_PARAM_FINGER");
                extractParamsKeyValueGroupBuilder.setAlgType(CommonProtobufUtil.getClientAlgorithmType(algorithmType));
                break;  
                
			case PALM_PC3R:
			case PALM_LFML:
				extractParamsKeyValueGroupBuilder.setGroupName("EXTRACTION_PARAM_PALM");
				break;
			default:
			}
			// extractParamsKeyValueGroupBuilder.setGroupName("DETECTION_PARAM_"
			// + algorithmType.name());
			
		     Map<String, String> defaultParameters = bioParameterService
	                .getPropertyMap("PROPERTIES_DEFAULT_DETECTION_PARAM_" + algorithmType.name(), "DEFAULT");
		     
		     
		     Map<String, String> overwriteParameters = bioParameterService
	                .getPropertyMap("PROPERTIES_OVERWRITE_DETECTION_PARAM_" + algorithmType.name(), "DEFAULT");
			
			ExtractInputParameter extractInputPara = isMyAlgorithmType(algorithmTypeExtractInputParameterList, algorithmType);
			if (extractInputPara != null) {			    
			    List<BioParameterDto> parameterList = extractInputPara.getParameters();
	             if (overwriteParameters != null) {
	                    for (Entry<String, String> entry : overwriteParameters.entrySet()) {
	                        if (StringUtils.isBlank(entry.getValue())) {
	                            parameterList.remove(entry.getKey());
	                        } else {
	                            BioParameterDto bioParameterDto = new BioParameterDto();
	                            bioParameterDto.setKey(entry.getKey());
	                            bioParameterDto.setValue(entry.getValue());
	                            parameterList.add(bioParameterDto);
	                        }
	                    }
	                }
	
	              List<BioParameterDto> notItem = checkIsNotDefaultParameters(defaultParameters, parameterList);
	                if (notItem != null && notItem.size() > 1) {
	                    for (BioParameterDto not : notItem) {
	                        KeyValue.Builder keyValueBuilder = KeyValue.newBuilder();
	                        keyValueBuilder.setKey(not.getKey());
	                        keyValueBuilder.setValue(not.getValue());
	                        extractParamsKeyValueGroupBuilder.addKv(keyValueBuilder.build());       
	                    }
	                } 	             
	             
			    for (BioParameterDto bioPara : parameterList) {
			        KeyValue.Builder keyValueBuilder = KeyValue.newBuilder();
	                keyValueBuilder.setKey(bioPara.getKey());
	                keyValueBuilder.setValue(bioPara.getValue());
	                extractParamsKeyValueGroupBuilder.addKv(keyValueBuilder.build());	                
			    }		    
			}
			keyValueGroupHolderBuilder.addParamGroup(extractParamsKeyValueGroupBuilder.build());
		}		

		for (TemplateExtractInputImage templateExtractInputImage : extractInputPayloadDto
				.getTemplateExtractInputImageList()) {
			if (templateExtractInputImage.getExtractInputImage().hasKeyValueGroupList()) {
				for (BioParameterGroupDto bioParameterGroupDto : templateExtractInputImage.getExtractInputImage()
						.getKeyValueGroupList()) {
					keyValueGroupHolderBuilder
							.addParamGroup(CommonProtobufUtil.buildKeyValueGroup(bioParameterGroupDto));
				}
			}
		}

		if (extractInputPayloadDto.hasKeyValueGroupList()) {
			for (BioParameterGroupDto bioParameterGroupDto : extractInputPayloadDto.getKeyValueGroupList()) {
				keyValueGroupHolderBuilder.addParamGroup(CommonProtobufUtil.buildKeyValueGroup(bioParameterGroupDto));
			}
		}

		extractRequestBuilder.setKvGroupHolder(keyValueGroupHolderBuilder.build());

		ExtractRequest extractRequest = extractRequestBuilder.build();		

		return extractRequest;
	}

	/**
	 * Builds the client extract biometric data.
	 *
	 * @param extractInputPayloadDto
	 *            the extract input payload dto
	 * @param extractRequestBuilder
	 *            the extract request builder
	 * @param templateTypeTemplateCodeMap
	 *            the template type template code map
	 * @param algorithmTypeSet
	 *            the algorithm type set
	 * @param algorithmTypeExtractInputParameterMap
	 *            the algorithm type extract input parameter map
	 * @param bioParameterService
	 *            the bio parameter service
	 * @return the extract biometric data
	 * @throws BioParameterServiceException
	 *             the bio parameter service exception
	 */
	private static ExtractBiometricData buildClientExtractBiometricData(ExtractInputPayloadDto extractInputPayloadDto,
			Set<CapsuleType> capsuleTypeBuilderSet, List<AlgorithmType> algorithmTypeSet,
			List<ExtractInputParameter> algorithmTypeExtractInputParameterMap,
			BioParameterService bioParameterService) throws BioParameterServiceException {
		if (CollectionUtils.isEmpty(extractInputPayloadDto.getTemplateExtractInputImageList())) {
			throw new IllegalArgumentException("TemplateExtractInputImageList in ExtractInputPayloadDto is empty");
		}

		ExtractBiometricData.Builder extractBiometricDataBuilder = ExtractBiometricData.newBuilder();

		for (TemplateExtractInputImage templateExtractInputImage : extractInputPayloadDto
				.getTemplateExtractInputImageList()) {
			if (templateExtractInputImage.getExtractInputImage() == null) {
				throw new IllegalArgumentException("ExtractInputImage is not set in TemplateExtractInputImage");
			}

			if (CollectionUtils.isEmpty(templateExtractInputImage.getTemplateTypes())) {
				throw new IllegalArgumentException("TemplateType is not specified in TemplateExtractInputImage");
			}

			for (String templateType : templateExtractInputImage.getTemplateTypes()) {
				TemplateType templateTypeEnum = TemplateType.valueOf(templateType);

				CapsuleType capsuleType = CapsuleType.valueOf(templateTypeEnum.getTemplateTypeCode());
				if (capsuleType == null) {
					throw new IllegalArgumentException("Unable to determine CapsuleType from templateTypeCode: "
							+ templateTypeEnum.getTemplateTypeCode());
				}
				capsuleTypeBuilderSet.add(capsuleType);

				try {
					algorithmTypeSet.addAll(getBioMatcherConfigService().getTemplateTypeAlgorithmTypesMap()
							.getOrDefault(templateTypeEnum, Collections.emptySet()));
				} catch (Throwable th) {
					logger.error(th.getMessage(), th);

				}

			}

			if (templateExtractInputImage.getExtractInputImage() instanceof FaceExtractInputImage) {
				FaceExtractInputImage faceInputImage = (FaceExtractInputImage) templateExtractInputImage
						.getExtractInputImage();

				extractBiometricDataBuilder.setFaceImage(CommonProtobufUtil
						.buildImageData(faceInputImage.getFaceImage(), Modality.FACE, SubType.SUB_TYPE_FACE));

				if (faceInputImage.hasExtractionParameters()) {
				    algorithmTypeExtractInputParameterMap.addAll(faceInputImage.getExtractionParameters()); 
				}
			} else if (templateExtractInputImage.getExtractInputImage() instanceof IrisExtractInputImage) {
				IrisExtractInputImage irisInputImage = (IrisExtractInputImage) templateExtractInputImage
						.getExtractInputImage();

				if (irisInputImage.getLeftEyeImage() != null) {
					extractBiometricDataBuilder.addIrisImage(CommonProtobufUtil.buildImageData(
							irisInputImage.getLeftEyeImage(), Modality.IRIS, SubType.SUB_TYPE_IRIS_LEFT));
				}

				if (irisInputImage.getRightEyeImage() != null) {
					extractBiometricDataBuilder.addIrisImage(CommonProtobufUtil.buildImageData(
							irisInputImage.getRightEyeImage(), Modality.IRIS, SubType.SUB_TYPE_IRIS_RIGHT));
				}

				if (irisInputImage.hasExtractionParameters()) {
				    algorithmTypeExtractInputParameterMap.addAll(irisInputImage.getExtractionParameters()); 
				}
			} else if (templateExtractInputImage.getExtractInputImage() instanceof FingerExtractInputImage) {
				FingerExtractInputImage fingerExtractInputImage = (FingerExtractInputImage) templateExtractInputImage
						.getExtractInputImage();

				for (Image image : fingerExtractInputImage.getImages()) {
					SubType imagePosition = SubType.SUB_TYPE_UNKNOWN;
					if (image.getPosition() != null) {
						imagePosition = CommonProtobufUtil.getClientSubType(image.getPosition().getPosition());
					}
					extractBiometricDataBuilder
							.addFingerImage(CommonProtobufUtil.buildImageData(image, Modality.FINGER, imagePosition));
				}

	               if (fingerExtractInputImage.hasExtractionParameters()) {
	                   algorithmTypeExtractInputParameterMap.addAll(fingerExtractInputImage.getExtractionParameters()); 
	                }		 

				} else if (templateExtractInputImage.getExtractInputImage() instanceof PalmExtractInputImage) {
				PalmExtractInputImage palmExtractInputImage = (PalmExtractInputImage) templateExtractInputImage
						.getExtractInputImage();

				for (Image image : palmExtractInputImage.getImages()) {
					SubType imagePosition = SubType.SUB_TYPE_PALM_UNKNOWN;
					if (image.getPosition() != null) {
						imagePosition = CommonProtobufUtil.getClientSubType(image.getPosition().getPosition());
					}
					extractBiometricDataBuilder
							.addPalmImage(CommonProtobufUtil.buildImageData(image, Modality.PALM, imagePosition));
				}

				if (palmExtractInputImage.hasExtractionParameters()) {
				    algorithmTypeExtractInputParameterMap.addAll(palmExtractInputImage.getExtractionParameters());
				}
			} else if (templateExtractInputImage.getExtractInputImage() instanceof MultiModalExtractInputImage) {
				MultiModalExtractInputImage multiModalExtractInputImage = (MultiModalExtractInputImage) templateExtractInputImage
						.getExtractInputImage();

				FingerExtractInputImage fingerExtractInputImage = multiModalExtractInputImage
						.getFingerExtractInputImage();
				if (fingerExtractInputImage != null) {
					for (Image image : fingerExtractInputImage.getImages()) {
						SubType imagePosition = SubType.SUB_TYPE_UNKNOWN;
						if (image.getPosition() != null) {
							imagePosition = CommonProtobufUtil.getClientSubType(image.getPosition().getPosition());
						}
						extractBiometricDataBuilder.addFingerImage(
								CommonProtobufUtil.buildImageData(image, Modality.FINGER, imagePosition));
					}

					if (fingerExtractInputImage.hasExtractionParameters()) {
					    algorithmTypeExtractInputParameterMap.addAll(fingerExtractInputImage.getExtractionParameters());					        

					}
				}

				PalmExtractInputImage palmExtractInputImage = multiModalExtractInputImage.getPalmExtractInputImage();

				if (palmExtractInputImage != null) {
					for (Image image : palmExtractInputImage.getImages()) {
						SubType imagePosition = SubType.SUB_TYPE_PALM_UNKNOWN;
						if (image.getPosition() != null) {
							imagePosition = CommonProtobufUtil.getClientSubType(image.getPosition().getPosition());
						}
						extractBiometricDataBuilder
								.addPalmImage(CommonProtobufUtil.buildImageData(image, Modality.PALM, imagePosition));
					}

					if (palmExtractInputImage.hasExtractionParameters()) {
					    algorithmTypeExtractInputParameterMap.addAll(palmExtractInputImage.getExtractionParameters());
					}
				}

				FaceExtractInputImage faceInputImage = multiModalExtractInputImage.getFaceExtractInputImage();

				if (faceInputImage != null) {
					if (faceInputImage.getFaceImage() != null) {
						extractBiometricDataBuilder.setFaceImage(CommonProtobufUtil
								.buildImageData(faceInputImage.getFaceImage(), Modality.FACE, SubType.SUB_TYPE_FACE));
					}

					if (faceInputImage.hasExtractionParameters()) {
					    algorithmTypeExtractInputParameterMap.addAll(faceInputImage.getExtractionParameters());
					}
				}

				IrisExtractInputImage irisInputImage = multiModalExtractInputImage.getIrisExtractInputImage();

				if (irisInputImage != null) {
					if (irisInputImage.getLeftEyeImage() != null) {
						extractBiometricDataBuilder.addIrisImage(CommonProtobufUtil.buildImageData(
								irisInputImage.getLeftEyeImage(), Modality.IRIS, SubType.SUB_TYPE_IRIS_LEFT));
					}

					if (irisInputImage.getRightEyeImage() != null) {
						extractBiometricDataBuilder.addIrisImage(CommonProtobufUtil.buildImageData(
								irisInputImage.getRightEyeImage(), Modality.IRIS, SubType.SUB_TYPE_IRIS_RIGHT));
					}

					if (irisInputImage.hasExtractionParameters()) {
					    algorithmTypeExtractInputParameterMap.addAll(irisInputImage.getExtractionParameters());
					}
				}

			} else {
				throw new IllegalArgumentException(
						templateExtractInputImage.getExtractInputImage().getClass().getSimpleName()
								+ " ExtractInputImage is not supported");
			}
		}

		return extractBiometricDataBuilder.build();
	}

	/**
	 * Gets the extract job result.
	 *
	 * @param extractResponse
	 *            the extract response
	 * @param templateTypeCodeTemplateTypeMap
	 *            the template type code template type map
	 * @return the extract job result
	 * @throws InvalidProtocolBufferException
	 *             the invalid protocol buffer exception
	 */
	public static ExtractJobResultDto getExtractJobResult(ExtractResponse extractResponse)
			throws InvalidProtocolBufferException {		
		ExtractJobResultDto extractJobResultDto = new ExtractJobResultDto();

		if (extractResponse.hasMsgId()) {
			extractJobResultDto.setJobId(extractResponse.getMsgId());
		}

		if (extractResponse.hasMode()) {
			extractJobResultDto.setJobMode(extractResponse.getMode());
		}

		if (extractResponse.hasKvGroupHolder()) {
			KeyValueGroupHolder keyValueGroupHolder = extractResponse.getKvGroupHolder();
			if (keyValueGroupHolder.getParamGroupCount() > 0) {
				for (KeyValueGroup keyValueGroup : keyValueGroupHolder.getParamGroupList()) {
					extractJobResultDto.getKeyValueGroupList()
							.add(CommonProtobufUtil.buildKeyValueGroup(keyValueGroup));
				}
			}
		}

		if (extractResponse.getCapsuleCount() > 0) {
			for (Capsule capsule : extractResponse.getCapsuleList()) {
				extractJobResultDto.getTemplateInfoList().add(buildTemplateInfo(capsule));
			}
		}

		 if (extractResponse.hasBiometricData()) {
		 extractJobResultDto.setExtractOutputImageList(buildExtractOutputImageList(extractResponse.getBiometricData()));
		 }

		if (extractResponse.hasStatus() && extractResponse.getStatus() != null
				&& !extractResponse.getStatus().getSuccess()) {
			Date now = new Date();
			if (extractResponse.getStatus().getErrorCount() > 0) {
				for (com.nec.megha.proto.common.CommonProto.Error error : extractResponse.getStatus().getErrorList()) {
					extractJobResultDto.getErrorList()
							.add(new ErrorMessageDto(String.valueOf(error.getCode()), error.getMsg(), null, now));
					while (error.hasInner()) {
						error = error.getInner();
						extractJobResultDto.getErrorList()
								.add(new ErrorMessageDto(String.valueOf(error.getCode()), error.getMsg(), null, now));
					}
				}
			} else {
				extractJobResultDto.getErrorList()
						.add(new ErrorMessageDto("EC004", "Extract response status success flag is false", null, now));
			}
		}
		extractJobResultDto.setStatus(BioJobStatus.COMPLETED);
		return extractJobResultDto;
	}

	 private static List<Image>  buildExtractOutputImageList(ExtractBiometricData clientBiometricData) {
	 List<Image> extractOutputImageList = new ArrayList<>();
	
	 if (clientBiometricData.hasFaceImage()) {
	 extractOutputImageList.add(buildExtractOutputImage(clientBiometricData.getFaceImage()));
	 }
	
	 if (clientBiometricData.getIrisImageCount() > 0) {
	 extractOutputImageList.addAll(buildExtractOutputImageList(clientBiometricData.getIrisImageList()));
	 }
	
	 if (clientBiometricData.getFingerImageCount() > 0) {
	 extractOutputImageList.addAll(buildExtractOutputImageList(clientBiometricData.getFingerImageList()));
	 }
	
	 if (clientBiometricData.getPalmImageCount() > 0) {
	 extractOutputImageList.addAll(buildExtractOutputImageList(clientBiometricData.getPalmImageList()));
	 }
	
	 return extractOutputImageList;
	 }

	private static List<Image> buildExtractOutputImageList(List<ImageData> clientImageDataList) {
		return clientImageDataList.stream().map(imageData -> buildExtractOutputImage(imageData))
				.collect(Collectors.toList());
	}

	private static Image buildExtractOutputImage(ImageData clientImageData) {
		Image imageData = new Image();
		imageData.setType(CommonProtobufUtil.getImageFormat(clientImageData.getFormat()));
		imageData.setPosition(CommonProtobufUtil.getImagePosition(clientImageData.getSubType()));
		imageData.setModality(CommonProtobufUtil.getModality(clientImageData.getModality()));
		imageData.setData(clientImageData.getData().toByteArray());

		if (clientImageData.hasIsBlackOnWhite()) {
			imageData.setIsBlackOnWhite(clientImageData.getIsBlackOnWhite());
		}

		if (clientImageData.hasHeight()) {
			imageData.setHeight(clientImageData.getHeight());
		}

		if (clientImageData.hasWidth()) {
			imageData.setWidth(clientImageData.getWidth());
		}

		if (clientImageData.getCropCount() > 0) {
			List<Crop> cropList = clientImageData.getCropList();
			imageData.getCropInfo().addAll(buildBioCropInfo(cropList));
		}

		if (clientImageData.hasResolution()) {
			imageData.setDpi(clientImageData.getResolution());
		}

		if (clientImageData.hasManualData()) {
			imageData.setManualData(buildExtractManualData(clientImageData.getManualData()));
		}

		if (clientImageData.hasKvGroupHolder()) {
			KeyValueGroupHolder keyValueGroupHolder = clientImageData.getKvGroupHolder();
			if (keyValueGroupHolder.getParamGroupCount() > 0) {
				for (KeyValueGroup keyValueGroup : keyValueGroupHolder.getParamGroupList()) {
					imageData.getKeyValueGroupList().add(CommonProtobufUtil.buildKeyValueGroup(keyValueGroup));
				}
			}
		}

		return imageData;
	}

	private static ExtractManualData buildExtractManualData(
			com.nec.megha.proto.common.CommonProto.ImageData.ExtractManualData clientExtractManualData) {
		ExtractManualData extractManualData = new ExtractManualData();

		if (clientExtractManualData.hasEditedMinutia()) {
			extractManualData.setEditedMinutia(clientExtractManualData.getEditedMinutia().toByteArray());
		}

		if (clientExtractManualData.hasMarkUp()) {
			extractManualData.setMarkup(clientExtractManualData.getMarkUp().toByteArray());
		}	

		return extractManualData;
	}
	
	private static List<BioCropInfo> buildBioCropInfo(List<Crop> bioCropList) {
		List<BioCropInfo> resultCropList = new ArrayList<>();
		for (Crop one : bioCropList) {
			BioCropInfo cropInfo = new BioCropInfo();
			if (one.hasSubType()) {
				SubType sub = one.getSubType();
				cropInfo.setPosition(ImagePosition.enumOf(Integer.valueOf(sub.getNumber())));
			}
			if (one.hasAngle()) {
				cropInfo.setAngle(Integer.valueOf(one.getAngle()));
			}

			if (one.hasAmputation()) {
				cropInfo.setAmputation(Boolean.valueOf(one.getAmputation()));
			}

			if (one.hasCenter()) {
				PointDto pd = new PointDto();
				pd.setX(one.getCenter().getX());
				pd.setY(one.getCenter().getY());
				cropInfo.setCenter(pd);
			}
			
			if (one.hasRectangle()) {
				BioRectangle bt = new BioRectangle();
				PointDto lowLeft = new PointDto();
				Point leftPoint = one.getRectangle().getLowerLeft();
				lowLeft.setX(leftPoint.getX());
				lowLeft.setY(leftPoint.getY());
				bt.setLowerLeft(lowLeft);

				PointDto lowRight = new PointDto();
				Point rightPoint = one.getRectangle().getLowerRight();
				lowRight.setX(rightPoint.getX());
				lowRight.setY(rightPoint.getY());
				bt.setLowerRight(lowRight);

				PointDto upperLeft = new PointDto();
				Point upperLeftPoint = one.getRectangle().getUpperLeft();
				upperLeft.setX(upperLeftPoint.getX());
				upperLeft.setY(upperLeftPoint.getY());
				bt.setUpperLeft(upperLeft);

				PointDto upperRight = new PointDto();
				Point upperRightPoint = one.getRectangle().getUpperRight();
				upperRight.setX(upperRightPoint.getX());
				upperRight.setY(upperRightPoint.getY());
				bt.setUpperRight(upperRight);

				cropInfo.setRectangle(bt);				
			}			
			resultCropList.add(cropInfo);	
			
		}
		return resultCropList;
	}
	
	   /**
     * Builds the template info.
     *
     * @param capsule
     *            the capsule
     * @param templateTypeCodeTemplateTypeMap
     *            the template type code template type map
     * @return the template info
     */
    private static TemplateInfo buildTemplateInfo(Capsule capsule) {
        TemplateInfo templateInfo = new TemplateInfo();
        if (capsule.hasCapsuleData()) {
            templateInfo.setTemplateData(capsule.getCapsuleData().toByteArray());
        }
        templateInfo.setTemplateType("TEMPLATE_TYPE_" + capsule.getCapsuleType().getNumber());

        // if (capsule.hasSubModality()) {
        // switch (capsule.getSubModality()) {
        // case SUB_MODAL_FINGER_ROLL:
        // templateInfo.setSubModality(SubModality.SUB_MODAL_FINGER_ROLL);
        // break;
        // case SUB_MODAL_FINGER_SLAP:
        // templateInfo.setSubModality(SubModality.SUB_MODAL_FINGER_SLAP);
        // break;
        // default:
        // logger.warn("No mapping for submodality returned in extraction
        // result: " + capsule.getSubModality());
        // break;
        // }
        // }

        if (capsule.getFeatureCount() > 0) {
            for (FeatureData featureData : capsule.getFeatureList()) {
                com.nec.biomatcher.spec.transfer.model.FeatureData featureDataDto = new com.nec.biomatcher.spec.transfer.model.FeatureData();
                featureDataDto.setAlgorithmType(CommonProtobufUtil.getAlgorithmType(featureData.getAlgType()));
                featureDataDto.setPosition(CommonProtobufUtil.getImagePosition(featureData.getSubType()));
                if (featureData.hasFeType()) {
                    featureDataDto.setFeType(featureData.getFeType());
                }
                if (featureData.hasData()) {
                    featureDataDto.setData(featureData.getData().toByteArray());
                }               

                if (featureData.hasKvGroupHolder()) {
                    KeyValueGroupHolder keyValueGroupHolder = featureData.getKvGroupHolder();
                    if (keyValueGroupHolder.getParamGroupCount() > 0) {
                        for (KeyValueGroup keyValueGroup : keyValueGroupHolder.getParamGroupList()) {
                            featureDataDto.getKeyValueGroupList()
                                    .add(CommonProtobufUtil.buildKeyValueGroup(keyValueGroup));
                        }
                    }
                }
                
                if (featureData.hasIqlQuality()) {
                    featureDataDto.setIqlQuality(Integer.valueOf(featureData.getIqlQuality()));
                }               
                
                if (featureData.hasFisData()) {
                    FisData fisData = new FisData();
                    Skeleton skeleton = new Skeleton();                
                    skeleton.setAlgorithmType(AlgorithmType.enumOf(featureData.getFisData().getSkeleton().getAlgType().getNumber()));
                    skeleton.setData(featureData.getFisData().getSkeleton().getData().toByteArray());
                    fisData.setSkeleton(skeleton);
                    featureDataDto.setFisData(fisData);
                }
                
                if (featureData.hasPaextData()) {
                    PaextData paextData = new PaextData();
                    Skeleton skeleton = new Skeleton();                
                    skeleton.setAlgorithmType(AlgorithmType.enumOf(featureData.getPaextData().getSkeleton().getAlgType().getNumber()));
                    skeleton.setData(featureData.getPaextData().getSkeleton().getData().toByteArray());
                    paextData.setSkeleton(skeleton);
                    featureDataDto.setPaextData(paextData);                 
                }
                
                if (featureData.hasPrimaryPattern()) {                  
                    featureDataDto.setPrimaryPattern(featureData.getPrimaryPattern());
                }
                
                if (featureData.hasSecondaryPattern()) {
                    featureDataDto.setSecondaryPattern(featureData.getSecondaryPattern());
                }
                
                if (featureData.getMinutiaDataCount() > 0 ) {
                    featureData.getMinutiaDataList().forEach(maniaData -> {
                        com.nec.biomatcher.spec.transfer.model.MinutiaData md = new MinutiaData();
                        md.setIndex(maniaData.getIndex());
                        com.nec.biomatcher.spec.transfer.model.Minutia mt = new Minutia();                  
                        mt.setAlgorithmType(AlgorithmType.enumOf(maniaData.getMinutia().getAlgType().getNumber()));
                        mt.setData(maniaData.getMinutia().getData().toByteArray());
                        if (maniaData.getMinutia().hasMinutiaCount()) {
                        	mt.setMinutiaCount(Integer.valueOf(maniaData.getMinutia().getMinutiaCount()));
                        }
                        md.setMinutia(mt); 
                        featureDataDto.getMinutiaDataList().add(md);
                    });                     
                }
                
                if (featureData.getLfmlDataCount() > 0 ) {
                    featureData.getLfmlDataList().forEach(lmflData -> {
                        com.nec.biomatcher.spec.transfer.model.LfmlData lfmlData = new com.nec.biomatcher.spec.transfer.model.LfmlData();
                        lfmlData.setIndex(lmflData.getIndex());
                        com.nec.biomatcher.spec.transfer.model.Skeleton skeleton = new com.nec.biomatcher.spec.transfer.model.Skeleton();
                        skeleton.setAlgorithmType(AlgorithmType.enumOf(lmflData.getSkeleton().getAlgType().getNumber()));
                        skeleton.setData(lmflData.getSkeleton().getData().toByteArray());
                        lfmlData.setSkeleton(skeleton);                       
                        if (lmflData.hasMinutia()) {
                            com.nec.biomatcher.spec.transfer.model.Minutia mt = new Minutia();                  
                            mt.setAlgorithmType(AlgorithmType.enumOf(lmflData.getMinutia().getAlgType().getNumber()));
                            mt.setData(lmflData.getMinutia().getData().toByteArray());                           
                            if (lmflData.getMinutia().hasMinutiaCount()) {
                            	mt.setMinutiaCount(Integer.valueOf(lmflData.getMinutia().getMinutiaCount()));
                            }
                            lfmlData.setMinutia(mt);
                        }
                        featureDataDto.getLfmlDataList().add(lfmlData);
                    });                     
                }               
                templateInfo.getFeatureDataList().add(featureDataDto);      
            }
        }
        return templateInfo;
    }



	private static BioMatcherConfigService getBioMatcherConfigService() {
		if (bioMatcherConfigService == null) {
			bioMatcherConfigService = SpringServiceManager.getBean("bioMatcherConfigService");
		}
		return bioMatcherConfigService;
	}
	
	private static ExtractInputParameter isMyAlgorithmType(List<ExtractInputParameter> extList, AlgorithmType key) {	    
	    for (int i = 0; i < extList.size(); i++) {
	        ExtractInputParameter one = extList.get(i);
	        if (one.getAlgorithmType().name().equals(key.name())) {	 
	            extList.remove(i);
	            return one;
	        }
	    }	    
	    return null;	    
	}
	
	private static List<BioParameterDto> checkIsNotDefaultParameters(Map<String, String> defaultParameters, List<BioParameterDto> myBioParrameterList) {	 
	    if (defaultParameters == null || defaultParameters.size() < 1) return null;
	    List<BioParameterDto> notPamameter = new ArrayList<>();
	    for (Entry<String, String> entry : defaultParameters.entrySet()) {
            if (!myBioParrameterList.contains(entry.getKey()) && StringUtils.isNotBlank(entry.getValue())) {
                BioParameterDto bioParameterDto = new BioParameterDto();
                bioParameterDto.setKey(entry.getKey());
                bioParameterDto.setValue(entry.getValue());
                notPamameter.add(bioParameterDto);
            }               
        }	    
	   return  notPamameter;
	    
	}
}
