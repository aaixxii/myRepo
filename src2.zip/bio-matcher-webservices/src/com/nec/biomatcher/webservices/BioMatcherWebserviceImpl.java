package com.nec.biomatcher.webservices;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import org.apache.log4j.Logger;

import com.nec.biomatcher.core.framework.common.CompressUtil;
import com.nec.biomatcher.core.framework.common.GsonSerializer;
import com.nec.biomatcher.spec.services.BioExtractionJobService;
import com.nec.biomatcher.spec.services.BioSearchJobControllerService;
import com.nec.biomatcher.spec.services.BioVerificationJobService;
import com.nec.biomatcher.spec.services.exception.BioMatcherWebserviceException;
import com.nec.biomatcher.spec.services.webservices.BioMatcherWebservice;
import com.nec.biomatcher.spec.transfer.commands.BioCommandRequest;
import com.nec.biomatcher.spec.transfer.commands.BioCommandResult;
import com.nec.biomatcher.spec.transfer.commands.DeleteJobActionRequest;
import com.nec.biomatcher.spec.transfer.commands.DeleteJobActionResult;
import com.nec.biomatcher.spec.transfer.commands.GetJobResultActionRequest;
import com.nec.biomatcher.spec.transfer.commands.GetJobResultActionResult;
import com.nec.biomatcher.spec.transfer.commands.GetJobStatusActionRequest;
import com.nec.biomatcher.spec.transfer.commands.GetJobStatusActionResult;
import com.nec.biomatcher.spec.transfer.commands.SubmitJobActionRequest;
import com.nec.biomatcher.spec.transfer.commands.SubmitJobActionResult;
import com.nec.biomatcher.spec.transfer.event.BiometricEventStatusInfoDto;
import com.nec.biomatcher.spec.transfer.job.BioMatcherJobRequest;
import com.nec.biomatcher.spec.transfer.job.BioMatcherJobResult;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.extract.ExtractJobResultDto;
import com.nec.biomatcher.spec.transfer.job.search.SearchJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.search.SearchJobResultDto;
import com.nec.biomatcher.spec.transfer.job.sync.SyncJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.sync.SyncJobResultDto;
import com.nec.biomatcher.spec.transfer.job.verify.VerifyJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.verify.VerifyJobResultDto;
import com.nec.biomatcher.spec.transfer.model.BioJobStatus;
import com.nec.biomatcher.util.BioCommandXmlUtil;

@WebService(name = "bioMatcherWebService", serviceName = "bioMatcherWebService", targetNamespace = "http://webservices.biomatcher.nec.com/", portName = "bioMatcherWebServicePort", endpointInterface = "com.nec.biomatcher.spec.services.webservices.BioMatcherWebservice")
@SOAPBinding(style = SOAPBinding.Style.DOCUMENT)
public class BioMatcherWebserviceImpl implements BioMatcherWebservice {

	private static final Logger VERIFY_JOB_WEBSERVICE_REQUEST_LOGGER = Logger
			.getLogger("VERIFY_JOB_WEBSERVICE_REQUEST");
	private static final Logger VERIFY_JOB_WEBSERVICE_RESPONSE_LOGGER = Logger
			.getLogger("VERIFY_JOB_WEBSERVICE_RESPONSE");
	private static final Logger SEARCH_JOB_WEBSERVICE_REQUEST_LOGGER = Logger
			.getLogger("SEARCH_JOB_WEBSERVICE_REQUEST");
	private static final Logger SEARCH_JOB_WEBSERVICE_RESPONSE_LOGGER = Logger
			.getLogger("SEARCH_JOB_WEBSERVICE_RESPONSE");
	private static final Logger EXTRACT_JOB_WEBSERVICE_REQUEST_LOGGER = Logger
			.getLogger("EXTRACT_JOB_WEBSERVICE_REQUEST");
	private static final Logger EXTRACT_JOB_WEBSERVICE_RESPONSE_LOGGER = Logger
			.getLogger("EXTRACT_JOB_WEBSERVICE_RESPONSE");

	private static BioVerificationJobService bioVerificationJobService;
	private static BioExtractionJobService bioExtractionJobService;
	private static BioSearchJobControllerService bioSearchJobControllerService;

	@WebMethod
	public String echo(String message) throws BioMatcherWebserviceException {
		return message;
	}

	@WebMethod
	public VerifyJobResultDto verify(VerifyJobRequestDto verifyRequest) throws BioMatcherWebserviceException {
		try {
			if (VERIFY_JOB_WEBSERVICE_REQUEST_LOGGER.isTraceEnabled()) {
				VERIFY_JOB_WEBSERVICE_REQUEST_LOGGER.trace(
						"In BioMatcherWebserviceImpl.verify verifyRequest: " + GsonSerializer.toJsonLog(verifyRequest));
			}

			VerifyJobResultDto verifyJobResultDto = bioVerificationJobService.verify(verifyRequest);

			if (VERIFY_JOB_WEBSERVICE_RESPONSE_LOGGER.isTraceEnabled()) {
				VERIFY_JOB_WEBSERVICE_RESPONSE_LOGGER.trace("In BioMatcherWebserviceImpl.verify verifyJobResultDto: "
						+ GsonSerializer.toJsonLog(verifyJobResultDto));
			}

			return verifyJobResultDto;
		} catch (Throwable th) {
			throw new BioMatcherWebserviceException("Error in verify: " + th.getMessage(), th);
		}
	}

	@WebMethod
	public String submitVerificationJob(VerifyJobRequestDto verifyRequest) throws BioMatcherWebserviceException {
		try {
			if (VERIFY_JOB_WEBSERVICE_REQUEST_LOGGER.isTraceEnabled()) {
				VERIFY_JOB_WEBSERVICE_REQUEST_LOGGER
						.trace("In BioMatcherWebserviceImpl.submitVerificationJob verifyRequest: "
								+ GsonSerializer.toJsonLog(verifyRequest));
			}

			return bioVerificationJobService.submitVerificationJob(verifyRequest);

		} catch (Throwable th) {
			throw new BioMatcherWebserviceException("Error in submitVerificationJob: " + th.getMessage(), th);
		}
	}

	@WebMethod
	public BioJobStatus getVerificationJobStatus(String jobId) throws BioMatcherWebserviceException {
		try {
			return bioVerificationJobService.getVerificationJobStatus(jobId);
		} catch (Throwable th) {
			throw new BioMatcherWebserviceException("Error in getVerificationJobStatus: " + th.getMessage(), th);
		}
	}

	@WebMethod
	public VerifyJobResultDto getVerificationJobResult(String jobId) throws BioMatcherWebserviceException {
		try {
			VerifyJobResultDto verifyJobResultDto = bioVerificationJobService.getVerificationJobResult(jobId);

			if (VERIFY_JOB_WEBSERVICE_RESPONSE_LOGGER.isTraceEnabled()) {
				VERIFY_JOB_WEBSERVICE_RESPONSE_LOGGER
						.trace("In BioMatcherWebserviceImpl.getVerificationJobResult jobId: " + jobId
								+ ", verifyJobResultDto: " + GsonSerializer.toJsonLog(verifyJobResultDto));
			}

			return verifyJobResultDto;
		} catch (Throwable th) {
			throw new BioMatcherWebserviceException("Error in getVerificationJobResult: " + th.getMessage(), th);
		}
	}

	@WebMethod
	public void deleteVerificationJob(String jobId) throws BioMatcherWebserviceException {
		try {
			bioVerificationJobService.deleteVerificationJob(jobId);
		} catch (Throwable th) {
			throw new BioMatcherWebserviceException("Error in deleteVerificationJob: " + th.getMessage(), th);
		}
	}

	@WebMethod
	public String submitExtractionJob(ExtractJobRequestDto jobRequestDto) throws BioMatcherWebserviceException {
		try {
			if (EXTRACT_JOB_WEBSERVICE_REQUEST_LOGGER.isTraceEnabled()) {
				EXTRACT_JOB_WEBSERVICE_REQUEST_LOGGER
						.trace("In BioMatcherWebserviceImpl.submitExtractionJob extractJobRequestDto: "
								+ GsonSerializer.toJsonLog(jobRequestDto));
			}

			return bioExtractionJobService.submitExtractionJob(jobRequestDto);
		} catch (Throwable th) {
			throw new BioMatcherWebserviceException("Error in submitExtractionJob: " + th.getMessage(), th);
		}
	}

	@WebMethod
	public BioJobStatus getExtractionJobStatus(String jobId) throws BioMatcherWebserviceException {
		try {
			return bioExtractionJobService.getExtractionJobStatus(jobId);
		} catch (Throwable th) {
			throw new BioMatcherWebserviceException("Error in getExtractionJobStatus: " + th.getMessage(), th);
		}
	}

	@WebMethod
	public ExtractJobResultDto getExtractionJobResult(String jobId) throws BioMatcherWebserviceException {
		try {
			ExtractJobResultDto extractJobResultDto = bioExtractionJobService.getExtractionJobResult(jobId);

			if (EXTRACT_JOB_WEBSERVICE_RESPONSE_LOGGER.isTraceEnabled()) {
				EXTRACT_JOB_WEBSERVICE_RESPONSE_LOGGER
						.trace("In BioMatcherWebserviceImpl.getExtractionJobResult jobId: " + jobId
								+ ", extractJobResultDto: " + GsonSerializer.toJsonLog(extractJobResultDto));
			}

			return extractJobResultDto;
		} catch (Throwable th) {
			throw new BioMatcherWebserviceException("Error in getExtractionJobResult: " + th.getMessage(), th);
		}
	}

	@WebMethod
	public void deleteExtractionJob(String jobId) throws BioMatcherWebserviceException {
		try {
			bioExtractionJobService.deleteExtractionJob(jobId);
		} catch (Throwable th) {
			throw new BioMatcherWebserviceException("Error in deleteExtractionJob: " + th.getMessage(), th);
		}
	}

	@WebMethod
	public BiometricEventStatusInfoDto getBiometricEventStatusInfo(Long biometricId)
			throws BioMatcherWebserviceException {
		try {
			return bioSearchJobControllerService.getBiometricEventStatusInfo(biometricId);
		} catch (Throwable th) {
			throw new BioMatcherWebserviceException("Error in getBiometricEventStatusInfo: " + th.getMessage(), th);
		}
	}

	@WebMethod
	public List<BiometricEventStatusInfoDto> getBiometricEventStatusInfoList(String externalId, String eventId,
			Integer binId) throws BioMatcherWebserviceException {
		try {
			return bioSearchJobControllerService.getBiometricEventStatusInfoList(externalId, eventId, binId);
		} catch (Throwable th) {
			throw new BioMatcherWebserviceException("Error in getBiometricEventStatusInfoList: " + th.getMessage(), th);
		}
	}

	@WebMethod
	public String submitSearchJob(SearchJobRequestDto jobRequestDto) throws BioMatcherWebserviceException {
		try {
			if (SEARCH_JOB_WEBSERVICE_REQUEST_LOGGER.isTraceEnabled()) {
				SEARCH_JOB_WEBSERVICE_REQUEST_LOGGER
						.trace("In BioMatcherWebserviceImpl.submitSearchJob searchJobRequestDto: "
								+ GsonSerializer.toJsonLog(jobRequestDto));
			}

			return bioSearchJobControllerService.submitSearchJob(jobRequestDto);
		} catch (Throwable th) {
			throw new BioMatcherWebserviceException("Error in submitSearchJob: " + th.getMessage(), th);
		}
	}

	@WebMethod
	public BioJobStatus getSearchJobStatus(String jobId) throws BioMatcherWebserviceException {
		try {
			return bioSearchJobControllerService.getSearchJobStatus(jobId);
		} catch (Throwable th) {
			throw new BioMatcherWebserviceException("Error in getSearchJobStatus: " + th.getMessage(), th);
		}
	}

	@WebMethod
	public SearchJobResultDto getSearchJobResult(String jobId) throws BioMatcherWebserviceException {
		try {
			SearchJobResultDto searchJobResultDto = bioSearchJobControllerService.getSearchJobResult(jobId);

			if (SEARCH_JOB_WEBSERVICE_RESPONSE_LOGGER.isTraceEnabled()) {
				SEARCH_JOB_WEBSERVICE_RESPONSE_LOGGER.trace("In BioMatcherWebserviceImpl.getSearchJobResult jobId: "
						+ jobId + ", searchJobResultDto: " + GsonSerializer.toJsonLog(searchJobResultDto));
			}

			return searchJobResultDto;
		} catch (Throwable th) {
			throw new BioMatcherWebserviceException("Error in getSearchJobResult: " + th.getMessage(), th);
		}
	}

	@WebMethod
	public void deleteSearchJob(String jobId) throws BioMatcherWebserviceException {
		try {
			bioSearchJobControllerService.deleteSearchJob(jobId);
		} catch (Throwable th) {
			throw new BioMatcherWebserviceException("Error in deleteSearchJob: " + th.getMessage(), th);
		}
	}

	@WebMethod
	public String submitSyncJob(SyncJobRequestDto syncJobRequestDto) throws BioMatcherWebserviceException {
		try {
			return bioSearchJobControllerService.submitSyncJob(syncJobRequestDto);
		} catch (Throwable th) {
			throw new BioMatcherWebserviceException("Error in submitSyncJob: " + th.getMessage(), th);
		}
	}

	@WebMethod
	public BioJobStatus getSyncJobStatus(String jobId) throws BioMatcherWebserviceException {
		try {
			return bioSearchJobControllerService.getSyncJobStatus(jobId);
		} catch (Throwable th) {
			throw new BioMatcherWebserviceException("Error in getSyncJobStatus: " + th.getMessage(), th);
		}
	}

	@WebMethod
	public SyncJobResultDto getSyncJobResult(String jobId) throws BioMatcherWebserviceException {
		try {
			return bioSearchJobControllerService.getSyncJobResult(jobId);
		} catch (Throwable th) {
			throw new BioMatcherWebserviceException("Error in getSyncJobResult: " + th.getMessage(), th);
		}
	}

	@WebMethod
	public void deleteSyncJob(String jobId) throws BioMatcherWebserviceException {
		try {
			bioSearchJobControllerService.deleteSyncJob(jobId);
		} catch (Throwable th) {
			throw new BioMatcherWebserviceException("Error in deleteSyncJob: " + th.getMessage(), th);
		}
	}

	@WebMethod(exclude = true)
	public BioCommandResult performBioCommandAction(BioCommandRequest bioCommandRequest)
			throws BioMatcherWebserviceException {
		try {
			if (bioCommandRequest instanceof SubmitJobActionRequest) {
				BioMatcherJobRequest bioMatcherJobRequest = ((SubmitJobActionRequest) bioCommandRequest)
						.getJobRequest();
				if (bioMatcherJobRequest instanceof ExtractJobRequestDto) {
					String jobId = submitExtractionJob((ExtractJobRequestDto) bioMatcherJobRequest);
					return new SubmitJobActionResult(jobId);
				} else if (bioMatcherJobRequest instanceof VerifyJobRequestDto) {
					String jobId = submitVerificationJob((VerifyJobRequestDto) bioMatcherJobRequest);
					return new SubmitJobActionResult(jobId);
				} else if (bioMatcherJobRequest instanceof SyncJobRequestDto) {
					String jobId = submitSyncJob((SyncJobRequestDto) bioMatcherJobRequest);
					return new SubmitJobActionResult(jobId);
				} else if (bioMatcherJobRequest instanceof SearchJobRequestDto) {
					String jobId = submitSearchJob((SearchJobRequestDto) bioMatcherJobRequest);
					return new SubmitJobActionResult(jobId);
				} else {
					throw new BioMatcherWebserviceException("Invalid bioMatcherJobRequest: " + bioMatcherJobRequest);
				}
			} else if (bioCommandRequest instanceof DeleteJobActionRequest) {
				DeleteJobActionRequest deleteJobActionRequest = (DeleteJobActionRequest) bioCommandRequest;
				switch (deleteJobActionRequest.getJobType()) {
				case EXTRACT:
					deleteExtractionJob(deleteJobActionRequest.getJobId());
					break;
				case SEARCH:
					deleteSearchJob(deleteJobActionRequest.getJobId());
					break;
				case SYNC:
					deleteSyncJob(deleteJobActionRequest.getJobId());
					break;
				case VERIFY:
					deleteVerificationJob(deleteJobActionRequest.getJobId());
					break;
				}
				return new DeleteJobActionResult();
			} else if (bioCommandRequest instanceof GetJobStatusActionRequest) {
				GetJobStatusActionRequest getJobStatusActionRequest = (GetJobStatusActionRequest) bioCommandRequest;
				BioJobStatus jobStatus = null;
				switch (getJobStatusActionRequest.getJobType()) {
				case EXTRACT:
					jobStatus = getExtractionJobStatus(getJobStatusActionRequest.getJobId());
					break;
				case SEARCH:
					jobStatus = getSearchJobStatus(getJobStatusActionRequest.getJobId());
					break;
				case SYNC:
					jobStatus = getSyncJobStatus(getJobStatusActionRequest.getJobId());
					break;
				case VERIFY:
					jobStatus = getVerificationJobStatus(getJobStatusActionRequest.getJobId());
					break;
				}
				return new GetJobStatusActionResult(jobStatus);

			} else if (bioCommandRequest instanceof GetJobResultActionRequest) {
				GetJobResultActionRequest getJobResultActionRequest = (GetJobResultActionRequest) bioCommandRequest;
				BioMatcherJobResult bioMatcherJobResult = null;
				switch (getJobResultActionRequest.getJobType()) {
				case EXTRACT:
					bioMatcherJobResult = getExtractionJobResult(getJobResultActionRequest.getJobId());
					break;
				case SEARCH:
					bioMatcherJobResult = getSearchJobResult(getJobResultActionRequest.getJobId());
					break;
				case SYNC:
					bioMatcherJobResult = getSyncJobResult(getJobResultActionRequest.getJobId());
					break;
				case VERIFY:
					bioMatcherJobResult = getVerificationJobResult(getJobResultActionRequest.getJobId());
					break;
				}
				if (Boolean.TRUE.equals(getJobResultActionRequest.getReturnCompressesResult())) {
					return new GetJobResultActionResult(
							CompressUtil.byteToGzip(BioCommandXmlUtil.serialize(bioMatcherJobResult)));
				} else {
					return new GetJobResultActionResult(bioMatcherJobResult);
				}
			}

			throw new BioMatcherWebserviceException("Invalid bioCommandRequest: " + bioCommandRequest);

		} catch (Throwable th) {
			throw new BioMatcherWebserviceException("Error in performBioCommandAction: " + th.getMessage(), th);
		}
	}

	public void setBioVerificationJobService(BioVerificationJobService bioVerificationJobService) {
		BioMatcherWebserviceImpl.bioVerificationJobService = bioVerificationJobService;
	}

	public void setBioExtractionJobService(BioExtractionJobService bioExtractionJobService) {
		BioMatcherWebserviceImpl.bioExtractionJobService = bioExtractionJobService;
	}

	public void setBioSearchJobControllerService(BioSearchJobControllerService bioSearchJobControllerService) {
		BioMatcherWebserviceImpl.bioSearchJobControllerService = bioSearchJobControllerService;
	}

}
