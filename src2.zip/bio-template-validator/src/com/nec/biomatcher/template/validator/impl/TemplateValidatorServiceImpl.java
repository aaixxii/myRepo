package com.nec.biomatcher.template.validator.impl;

import java.io.Closeable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;

import com.google.protobuf.ByteString;
import com.nec.biomatcher.comp.cluster.JobSlotClusterService;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioConnectionType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioProtocolType;
import com.nec.biomatcher.comp.matcher.node.MatcherNodeClientHelper;
import com.nec.biomatcher.comp.matcher.node.MatcherNodeExceptionUtil;
import com.nec.biomatcher.comp.matcher.node.MatcherNodeStatusCheckHelper;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeClientException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeConnectionException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeReceiveException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeSendException;
import com.nec.biomatcher.comp.metrics.MetricsUtil;
import com.nec.biomatcher.comp.zmq.ZmqSendReceiveConnection;
import com.nec.biomatcher.core.framework.common.PFLogger;
import com.nec.biomatcher.core.framework.common.exception.CoreException;
import com.nec.biomatcher.spec.transfer.model.ErrorMessageDto;
import com.nec.biomatcher.template.validator.TemplateValidatorConstants;
import com.nec.biomatcher.template.validator.TemplateValidatorService;
import com.nec.biomatcher.template.validator.exception.InvalidTemplateException;
import com.nec.biomatcher.template.validator.exception.TemplateValidatorException;
import com.nec.megha.proto.cv.CVRequestProto.CVRequest;
import com.nec.megha.proto.cv.CVRequestProto.Capsule;
import com.nec.megha.proto.cv.CVResponseProto.CVResponse;
import com.nec.megha.proto.cv.CVResponseProto.CapsuleStatus;

public class TemplateValidatorServiceImpl implements TemplateValidatorService, InitializingBean {
	private static final Logger logger = Logger.getLogger(TemplateValidatorService.class);

	private static final Logger TV_JOB_NODE_REQUEST_LOGGER = Logger.getLogger("TV_JOB_NODE_REQUEST");
	private static final Logger TV_JOB_NODE_RESPONSE_LOGGER = Logger.getLogger("TV_JOB_NODE_RESPONSE");

	private MatcherNodeClientHelper matcherNodeClientHelper = new MatcherNodeClientHelper();

	private BioParameterService bioParameterService;
	private BioMatcherConfigService bioMatcherConfigService;
	private MatcherNodeStatusCheckHelper matcherNodeStatusCheckHelper;

	private JobSlotClusterService templateValidatorClusterService;

	private String templateValidatorControllerId;

	public String getTemplateValidatorControllerId() {
		return templateValidatorControllerId;
	}

	public boolean validateTemplates(List<byte[]> templateList, long timeOutMilli)
			throws TemplateValidatorException, InvalidTemplateException {
		if (StringUtils.isBlank(templateValidatorControllerId)) {
			throw new TemplateValidatorException("Template validator controller is not configured on the host");
		}

		long startTimestampMilli = System.currentTimeMillis();
		try (Closeable timer = MetricsUtil.time(BioComponentType.TVC, templateValidatorControllerId,
				"TEMPLATE_VALIDATOR_JOB_TIME_TAKEN")) {
			CVRequest cvRequest = buildCVRequest(templateList);

			long maxTemplateValidatorTimeoutMilli = bioParameterService
					.getParameterValue("MAX_TEMPLATE_VALIDATOR_JOB_TIMEOUT_MILLI", "DEFAULT", 1000L);
			long templateValidatorTimeoutMilli = Math.min(maxTemplateValidatorTimeoutMilli, timeOutMilli);

			String templateValidatorNodeId = templateValidatorClusterService
					.acquireJobSlot(templateValidatorTimeoutMilli);
			if (templateValidatorNodeId == null) {
				throw new TemplateValidatorException(
						"Template validator job slot not available, waited for templateValidatorTimeoutMilli: "
								+ templateValidatorTimeoutMilli);
			}
			try {
				try {
					templateValidatorTimeoutMilli = templateValidatorTimeoutMilli
							- (System.currentTimeMillis() - startTimestampMilli);
					boolean isValidFlag = validateTemplate(cvRequest, templateValidatorTimeoutMilli,
							templateValidatorNodeId);
					return isValidFlag;
				} finally {
					templateValidatorClusterService.releaseJobSlot(templateValidatorNodeId);
				}
			} catch (BioMatcherNodeSendException | BioMatcherNodeReceiveException ex) {
				templateValidatorClusterService.notifyOffline(templateValidatorNodeId);
				MetricsUtil.meter(BioComponentType.TVC, templateValidatorControllerId,
						"TEMPLATE_VALIDATOR_TIMEOUT_ERROR");
				throw new TemplateValidatorException(
						ex.getClass().getSimpleName() + " during validateTemplate: " + ex.getMessage(), ex);
			} catch (BioMatcherNodeConnectionException ex) {
				templateValidatorClusterService.notifyOffline(templateValidatorNodeId);
				MetricsUtil.meter(BioComponentType.TVC, templateValidatorControllerId,
						"TEMPLATE_VALIDATOR_CONNECTION_ERROR");
				throw new TemplateValidatorException(
						ex.getClass().getSimpleName() + " during validateTemplate: " + ex.getMessage(), ex);
			} catch (TemplateValidatorException | InvalidTemplateException ex) {
				MetricsUtil.meter(BioComponentType.TVC, templateValidatorControllerId,
						"TEMPLATE_VALIDATOR_OTHER_ERROR");
				throw ex;
			} catch (Throwable th) {
				MetricsUtil.meter(BioComponentType.TVC, templateValidatorControllerId,
						"TEMPLATE_VALIDATOR_OTHER_ERROR");
				throw new TemplateValidatorException(
						th.getClass().getSimpleName() + " during validateTemplate: " + th.getMessage(), th);
			}
		} catch (TemplateValidatorException | InvalidTemplateException ex) {
			throw ex;
		} catch (Throwable th) {
			throw new TemplateValidatorException(th);
		}
	}

	private boolean validateTemplate(CVRequest cvRequest, long jobTimeoutMilli, String templateValidatorNodeId)
			throws TemplateValidatorException, InvalidTemplateException, BioMatcherNodeClientException,
			BioMatcherNodeConnectionException, BioMatcherNodeSendException, BioMatcherNodeReceiveException {

		boolean isValid = false;

		PFLogger.start();
		try {
			String connectionUrl = bioMatcherConfigService.getServerConnectionUrl(templateValidatorNodeId,
					BioComponentType.TVN, BioConnectionType.WORKER, BioProtocolType.ZEROMQ);

			if (TV_JOB_NODE_REQUEST_LOGGER.isTraceEnabled()) {
				TV_JOB_NODE_REQUEST_LOGGER.trace("templateValidatorNodeId: " + templateValidatorNodeId
						+ ", requestPayload: " + cvRequest.toString());
			}

			byte[] responsePayload = ZmqSendReceiveConnection.sendReceiveMessage(templateValidatorNodeId, connectionUrl,
					cvRequest.toByteArray(), jobTimeoutMilli);

			CVResponse cvResponse = null;
			try {
				cvResponse = CVResponse.parseFrom(responsePayload);

				if (TV_JOB_NODE_RESPONSE_LOGGER.isTraceEnabled()) {
					TV_JOB_NODE_RESPONSE_LOGGER.trace("templateValidatorNodeId: " + templateValidatorNodeId
							+ ", responsePayload: " + cvResponse.toString());
				}
			} catch (Throwable th) {
				th = new CoreException("Error parsing CVResponse  from templateValidatorNodeId: "
						+ templateValidatorNodeId + " : " + th.getMessage(), th);
				throw th;
			}

			if (cvResponse.getCapsuleStatusCount() > 0) {
				List<ErrorMessageDto> errorMessageDtoList = new ArrayList<>();

				for (CapsuleStatus capsuleStatus : cvResponse.getCapsuleStatusList()) {
					if (capsuleStatus.hasStatus() && capsuleStatus.getStatus() != null
							&& !capsuleStatus.getStatus().getSuccess()) {
						Date now = new Date();
						if (capsuleStatus.getStatus().getErrorCount() > 0) {
							for (com.nec.megha.proto.common.CommonProto.Error error : capsuleStatus.getStatus()
									.getErrorList()) {
								errorMessageDtoList.add(new ErrorMessageDto(String.valueOf(error.getCode()),
										error.getMsg(), null, now));
								while (error.hasInner()) {
									error = error.getInner();
									errorMessageDtoList.add(new ErrorMessageDto(String.valueOf(error.getCode()),
											error.getMsg(), null, now));
								}
							}
						} else {
							errorMessageDtoList
									.add(new ErrorMessageDto(TemplateValidatorConstants.ERROR_CODE_INVALID_TEMPLATE,
											"Template validator response status success flag is false", null, now));
						}
					}
				}

				if (errorMessageDtoList.size() > 0) {
					throw new InvalidTemplateException(templateValidatorNodeId, errorMessageDtoList);
				}
			}

			isValid = true;

			return isValid;
		} catch (InvalidTemplateException ex) {
			matcherNodeClientHelper.handleSendReceiveError(templateValidatorNodeId, BioComponentType.VN, ex);
			throw ex;
		} catch (Throwable th) {
			matcherNodeClientHelper.handleSendReceiveError(templateValidatorNodeId, BioComponentType.VN, th);
			MatcherNodeExceptionUtil.propogateZmqException(templateValidatorNodeId, th);
			throw new TemplateValidatorException("Encountered error during validateTemplate: templateValidatorNodeId: "
					+ templateValidatorNodeId + " : " + th.getMessage(), th);
		} finally {
			PFLogger.end("templateValidatorNodeId: " + templateValidatorNodeId + ", jobTimeoutMilli: " + jobTimeoutMilli
					+ ", isValid: " + isValid);
		}
	}

	private CVRequest buildCVRequest(List<byte[]> templateList) {
		CVRequest.Builder cvRequestBuilder = CVRequest.newBuilder();
		for (int i = 0; i < templateList.size(); i++) {
			Capsule.Builder capsuleBuilder = Capsule.newBuilder();
			capsuleBuilder.setCapsuleId(String.valueOf(i));
			capsuleBuilder.setData(ByteString.copyFrom(templateList.get(i)));
			cvRequestBuilder.addCapsule(capsuleBuilder.build());
		}
		return cvRequestBuilder.build();
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		logger.info("TemplateValidatorService.afterPropertiesSet");

		bioParameterService.renameParameterIfExists("MAX_TEMPLATE_VERIFY_JOB_TIMEOUT_MILLI", "DEFAULT",
				"MAX_TEMPLATE_VALIDATOR_JOB_TIMEOUT_MILLI");
		bioParameterService.getParameterValue("MAX_TEMPLATE_VALIDATOR_JOB_TIMEOUT_MILLI", "DEFAULT", 1000L);

		templateValidatorClusterService = new JobSlotClusterService(BioComponentType.TVC, BioComponentType.TVN,
				(templateValidatorNodeId -> matcherNodeStatusCheckHelper.sendServerCapacity(templateValidatorNodeId)),
				bioMatcherConfigService, bioParameterService);
		templateValidatorControllerId = templateValidatorClusterService.getControllerId();

		logger.info("TemplateValidatorService.afterPropertiesSet: templateValidatorControllerId: "
				+ templateValidatorControllerId);
	}

	public void setBioParameterService(BioParameterService bioParameterService) {
		this.bioParameterService = bioParameterService;
	}

	public void setBioMatcherConfigService(BioMatcherConfigService bioMatcherConfigService) {
		this.bioMatcherConfigService = bioMatcherConfigService;
	}

	public void setMatcherNodeStatusCheckHelper(MatcherNodeStatusCheckHelper matcherNodeStatusCheckHelper) {
		this.matcherNodeStatusCheckHelper = matcherNodeStatusCheckHelper;
	}

}
