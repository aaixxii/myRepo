package com.nec.biomatcher.template.validator;

public class TemplateValidatorConstants {
	public static final String ERROR_CODE_INVALID_TEMPLATE = "TV001";
}
