package com.nec.biomatcher.template.validator.exception;

import java.util.List;

import com.nec.biomatcher.core.framework.common.GsonSerializer;
import com.nec.biomatcher.core.framework.common.exception.CoreException;
import com.nec.biomatcher.spec.transfer.model.ErrorMessageDto;

public class InvalidTemplateException extends CoreException {
    private static final long serialVersionUID = 1L;

    private List<ErrorMessageDto> errorMessageDtoList;
    private String templateValidatorNodeId;

    public InvalidTemplateException(List<ErrorMessageDto> errorMessageDtoList) {
        super("Invalid template : " + GsonSerializer.toJsonLog(errorMessageDtoList));
        this.errorMessageDtoList = errorMessageDtoList;
    }

    public InvalidTemplateException(String templateValidatorNodeId, List<ErrorMessageDto> errorMessageDtoList) {
        super("Template validator: " + templateValidatorNodeId + " returned invalid template : " + GsonSerializer.toJsonLog(errorMessageDtoList));
        this.templateValidatorNodeId = templateValidatorNodeId;
        this.errorMessageDtoList = errorMessageDtoList;
    }

    public List<ErrorMessageDto> getErrorMessageDtoList() {
        return errorMessageDtoList;
    }

    public String getTemplateValidatorNodeId() {
        return templateValidatorNodeId;
    }

}
