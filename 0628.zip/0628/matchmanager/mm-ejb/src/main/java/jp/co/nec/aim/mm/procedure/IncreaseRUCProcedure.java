package jp.co.nec.aim.mm.procedure;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.object.StoredProcedure;

/**
 * IncreaseRUCProcedure
 * 
 * @author liuyq
 * 
 */
public class IncreaseRUCProcedure extends StoredProcedure {

	private static final String SQL = "MATCH_MANAGER_API.INCREASE_RUC";

	/**
	 * IncreaseRUCProcedure
	 * 
	 * @param dataSource
	 */
	public IncreaseRUCProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(SQL);
		compile();
	}

	/**
	 * execute IncreaseRUCProcedure
	 */
	public void execute() {
		Map<String, Object> map = new HashMap<String, Object>();
		execute(map);
	}

}
