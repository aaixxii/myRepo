#!/bin/bash
source /etc/profile
