#!/bin/bash

echo "build docker megha"
cd centos74
docker build -t centos74 .
cd ..
cd jdk
docker build -t jdk8 .
cd ..
cd megha
docker build -t megha .
cd ..
cd cassandra
docker build -t cassandra