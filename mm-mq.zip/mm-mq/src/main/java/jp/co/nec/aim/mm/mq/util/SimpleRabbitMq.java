package jp.co.nec.aim.mm.mq.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeoutException;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import jp.co.nec.aim.mm.mq.db.DbHandler;
import jp.co.nec.aim.mm.mq.info.MqSetting;

public class SimpleRabbitMq {

	public Connection connection;
	public List<Channel> channelList = new ArrayList<Channel>();
	public MqSetting mqSetting;
	public DbHandler dbHandler;

	public SimpleRabbitMq(String key) throws IOException, TimeoutException {
		this.dbHandler = new DbHandler();
		this.mqSetting = dbHandler.getMqSetting(key);
		connection();
	}

	public void connection() throws IOException, TimeoutException {
		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost(mqSetting.getHost());
		factory.setPort(mqSetting.getPort());
		factory.setUsername(mqSetting.getUser());
		factory.setPassword(mqSetting.getPasswd());
		if (!mqSetting.getvHost().isEmpty())
			factory.setVirtualHost(mqSetting.getvHost());
		ExecutorService executor = Executors.newFixedThreadPool(mqSetting.getThNum());
		connection = factory.newConnection(executor);
		for (int i = 0; i < mqSetting.getThNum(); i++)
			channelList.add(connection.createChannel());
	}

	public void close() throws IOException, TimeoutException {
		for (Channel channel : channelList)
			channel.close();
		connection.close();
	}

}
