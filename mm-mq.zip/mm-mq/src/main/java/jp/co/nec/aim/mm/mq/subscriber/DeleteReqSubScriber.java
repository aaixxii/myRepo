package jp.co.nec.aim.mm.mq.subscriber;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.concurrent.TimeoutException;

import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Delivery;

import jp.co.nec.aim.mm.acceptor.service.AimSyncService;
import jp.co.nec.aim.mm.acceptor.service.AimSyncServiceResult;
import jp.co.nec.aim.mm.mq.cons.MqConst;
import jp.co.nec.aim.mm.mq.publisher.DeleteResPublisher;

@Singleton
@Startup
@TransactionManagement(TransactionManagementType.BEAN)
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
public class DeleteReqSubScriber extends SimpleSubScriber {

    private static Logger log = LoggerFactory.getLogger(DeleteReqSubScriber.class);

    AimSyncService aimSyncService;

    DeleteResPublisher deleteResPublisher;

    public DeleteReqSubScriber() throws IOException, TimeoutException {
	super(MqConst.DELETE_REQ_KEY);
	this.aimSyncService = new AimSyncService();
	this.deleteResPublisher = new DeleteResPublisher();
	deleteReq();
    }

    private void deleteReq() throws IOException {
	subScribe(false);
    }

    @Override
    public void subScribeAction(Channel channel, String consumerTag, Delivery delivery) {
	try {
	    // Send SyncJob
	    AimSyncServiceResult res = aimSyncService.syncData(new String(delivery.getBody(), "UTF-8"));
	    // return dequeue ack
	    channel.basicAck(delivery.getEnvelope().getDeliveryTag(), false);
	    // publish result.
	    deleteResPublisher.deleteRes(res.getResultXml());
	} catch (IOException | TimeoutException e) {
	    // TODO ErrorHandring
	    if (e instanceof UnsupportedEncodingException) {
		log.error("An unexpected exception has occurred when encode xml.", e);
	    } else if (e instanceof TimeoutException) {
		log.error("An unexpected exception has occurred when publish result.", e);
	    } else {
		log.error("An unexpected exception has occurred.", e);
	    }
	}
    }

}
