package jp.co.nec.aim.mm.mq.subscriber;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.DeliverCallback;
import com.rabbitmq.client.Delivery;

import jp.co.nec.aim.mm.mq.util.SimpleRabbitMq;

abstract public class SimpleSubScriber extends SimpleRabbitMq {

	public SimpleSubScriber(String key) throws IOException, TimeoutException {
		super(key);
	}

	public void subScribe(boolean autoAck) throws IOException {
		for (Channel channel : channelList) {
			DeliverCallback deliverCallback = (consumerTag, delivery) -> {
				subScribeAction(channel, consumerTag, delivery);
			};
			channel.basicConsume(mqSetting.getQueueName(), autoAck, deliverCallback, consumerTag -> {
			});
		}
	}

	abstract public void subScribeAction(Channel channel, String consumerTag, Delivery delivery);

}
