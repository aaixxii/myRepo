package jp.co.nec.aim.mm.acceptor.service;

public class AimManageService {

	// TODO
	// mm-ejb内に対象のクラスがないように見えるので一時的にクラス作成

	public AimManageServiceResult getQuality(String msg) {
		String resultXml = "<sample>dummy</sample>";
		AimManageServiceResult aimManageServiceResult = new AimManageServiceResult();
		aimManageServiceResult.setResultXml(resultXml);
		return aimManageServiceResult;
	}
}
