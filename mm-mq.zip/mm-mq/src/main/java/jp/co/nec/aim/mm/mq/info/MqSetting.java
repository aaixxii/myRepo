package jp.co.nec.aim.mm.mq.info;

public class MqSetting {

	private Integer id;
	private String exchangeName;
	private String queueName;
	private String host;
	private Integer port;
	private String user;
	private String passwd;
	private String vHost;
	private Integer thNum;

	public MqSetting() {
	};

	public MqSetting(Integer id, String exchangeName, String queueName, String host, Integer port, String user,
			String passwd, String vHost, Integer thNum) {
		this.id = id;
		this.exchangeName = exchangeName;
		this.queueName = queueName;
		this.host = host;
		this.port = port;
		this.user = user;
		this.passwd = passwd;
		this.vHost = vHost;
		this.thNum = thNum;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getExchangeName() {
		return exchangeName;
	}

	public void setExchangeName(String exchangeName) {
		this.exchangeName = exchangeName;
	}

	public String getQueueName() {
		return queueName;
	}

	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public Integer getPort() {
		return port;
	}

	public void setPort(Integer port) {
		this.port = port;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPasswd() {
		return passwd;
	}

	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}

	public String getvHost() {
		return vHost;
	}

	public void setvHost(String vHost) {
		this.vHost = vHost;
	}

	public Integer getThNum() {
		return thNum;
	}

	public void setThNum(Integer thNum) {
		this.thNum = thNum;
	}

}
