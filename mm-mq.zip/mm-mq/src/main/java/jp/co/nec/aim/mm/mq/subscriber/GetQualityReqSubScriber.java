package jp.co.nec.aim.mm.mq.subscriber;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.concurrent.TimeoutException;

import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Delivery;

import jp.co.nec.aim.mm.acceptor.service.AimManageService;
import jp.co.nec.aim.mm.acceptor.service.AimManageServiceResult;
import jp.co.nec.aim.mm.mq.cons.MqConst;
import jp.co.nec.aim.mm.mq.publisher.GetQualityResPublisher;

@Singleton
@Startup
@TransactionManagement(TransactionManagementType.BEAN)
@ConcurrencyManagement(ConcurrencyManagementType.BEAN)
public class GetQualityReqSubScriber extends SimpleSubScriber {

	private static Logger log = LoggerFactory.getLogger(GetQualityReqSubScriber.class);

	AimManageService aimManageService;

	GetQualityResPublisher getQualityResPublisher;

	public GetQualityReqSubScriber() throws IOException, TimeoutException {
		super(MqConst.GETQUALITY_REQ_KEY);
		this.aimManageService = new AimManageService();
		this.getQualityResPublisher = new GetQualityResPublisher();
		getQuality();
	}

	public void getQuality() throws IOException {
		subScribe(false);
	}

	@Override
	public void subScribeAction(Channel channel, String consumerTag, Delivery delivery) {
		try {
			// Send GetQuality
			AimManageServiceResult res = aimManageService.getQuality(new String(delivery.getBody(), "UTF-8"));
			// return dequeue ack
			channel.basicAck(delivery.getEnvelope().getDeliveryTag(), true);
			// publish result.
			getQualityResPublisher.getQualityRes(res.getResultXml());
		} catch (Exception e) {
			// TODO ErrorHandring
			if (e instanceof UnsupportedEncodingException) {
				log.error("An unexpected exception has occurred when encode xml.", e);
			} else if (e instanceof TimeoutException) {
				log.error("An unexpected exception has occurred when publish result.", e);
			} else {
				log.error("An unexpected exception has occurred.", e);
			}
		}
	}

}
