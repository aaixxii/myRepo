package jp.co.nec.aim.mm.acceptor.service;

import jp.co.nec.aim.message.proto.Diagnostics.PBDiagnostics;

public class AimInquiryService {

	// TODO
	// mm-ejbがビルドエラーになるため一時的にダミークラス作成。

	public AimInquiryServiceResult inquiry(String msg, boolean flg) {
		String resultXml = "<sample>dummy</sample>";
		PBDiagnostics diagnostics = PBDiagnostics.newBuilder().build();
		AimInquiryServiceResult aimInquiryServiceResult = new AimInquiryServiceResult();
		aimInquiryServiceResult.setResultXml(resultXml);
		aimInquiryServiceResult.setDiagnostics(diagnostics);
		return aimInquiryServiceResult;
	}

}
