package jp.co.nec.aim.mm.mq.publisher;

import java.io.IOException;
import java.util.Random;
import java.util.concurrent.TimeoutException;

import jp.co.nec.aim.mm.mq.util.SimpleRabbitMq;

public class SimplePublisher extends SimpleRabbitMq {

	private Random random = new Random();

	public SimplePublisher(String key) throws IOException, TimeoutException {
		super(key);
	}

	public void publish(String msg) throws IOException {
		channelList.get(random.nextInt(mqSetting.getThNum())).basicPublish(mqSetting.getExchangeName(),
				mqSetting.getQueueName(), null,
				msg.getBytes());
	}

	public void publish(byte[] msg) throws IOException {
		channelList.get(random.nextInt(mqSetting.getThNum())).basicPublish(mqSetting.getExchangeName(),
				mqSetting.getQueueName(), null,
				msg);
	}

}
