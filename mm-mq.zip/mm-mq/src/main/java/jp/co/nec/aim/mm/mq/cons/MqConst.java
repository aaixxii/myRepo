package jp.co.nec.aim.mm.mq.cons;

public class MqConst {

	public static final String DELETE_REQ_KEY = "1";
	public static final String DELETE_RES_KEY = "2";
	public static final String GETQUALITY_REQ_KEY = "3";
	public static final String GETQUALIY_RES_KEY = "4";
	public static final String IDENTIFY_DIAG_AMR_KEY = "5";
	public static final String IDENTIFY_REQ_KEY = "6";
	public static final String IDENTIFY_RES_KEY = "7";
	public static final String INSERT_DIAG_QUALITY_KEY = "8";
	public static final String INSERT_REQ_KEY = "9";
	public static final String INSERT_RES_KEY = "10";

}
