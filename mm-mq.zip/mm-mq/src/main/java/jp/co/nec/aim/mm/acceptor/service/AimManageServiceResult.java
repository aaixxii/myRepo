package jp.co.nec.aim.mm.acceptor.service;

import jp.co.nec.aim.message.proto.Diagnostics.PBDiagnostics;

public class AimManageServiceResult {

	private String resultXml;
	private PBDiagnostics diagnostics;

	public AimManageServiceResult() {

	}

	public String getResultXml() {
		return resultXml;
	}

	public PBDiagnostics getDiagnostics() {
		return diagnostics;
	}

	public void setResultXml(String resultXml) {
		this.resultXml = resultXml;
	}

	public void setDiagnostics(PBDiagnostics diagnostics) {
		this.diagnostics = diagnostics;
	}

}
