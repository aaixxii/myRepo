package jp.co.nec.aim.mm.acceptor.service;

import jp.co.nec.aim.message.proto.Diagnostics.PBDiagnostics;

public class AimSyncService {

	// TODO
	// mm-ejbがビルドエラーになるため一時的にダミークラス作成。

	public AimSyncServiceResult syncData(String msg) {
		String resultXml = "<sample>dummy</sample>";
		PBDiagnostics diagnostics = PBDiagnostics.newBuilder().build();
		AimSyncServiceResult aimSyncServiceResult = new AimSyncServiceResult();
		aimSyncServiceResult.setResultXml(resultXml);
		aimSyncServiceResult.setDiagnostics(diagnostics);
		return aimSyncServiceResult;
	}

}
