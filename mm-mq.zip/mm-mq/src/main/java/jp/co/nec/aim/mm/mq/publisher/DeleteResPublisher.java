package jp.co.nec.aim.mm.mq.publisher;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import jp.co.nec.aim.mm.mq.cons.MqConst;

public class DeleteResPublisher extends SimplePublisher {

	public DeleteResPublisher() throws IOException, TimeoutException {
		super(MqConst.DELETE_RES_KEY);
	}

	public void deleteRes(String msg) throws IOException, TimeoutException {
		publish(msg);
	}

}
