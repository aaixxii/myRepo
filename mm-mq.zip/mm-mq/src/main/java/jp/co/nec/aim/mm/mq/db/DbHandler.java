package jp.co.nec.aim.mm.mq.db;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import jp.co.nec.aim.mm.constants.JNDIConstants;
import jp.co.nec.aim.mm.mq.info.MqSetting;
import jp.co.nec.aim.mm.util.JndiLookup;

public class DbHandler {

	private final static Logger log = LoggerFactory
			.getLogger(DbHandler.class);

	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;

	public DbHandler() {
		dataSource = JndiLookup.lookUp(JNDIConstants.DataSourceName, DataSource.class);
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public MqSetting getMqSetting(String key) {
		return jdbcTemplate.queryForObject("select * from RQ_SETTIG where ID = ?",
				new Object[] { new Integer(key) },
				new RowMapper<MqSetting>() {
					public MqSetting mapRow(ResultSet rs, int rowNum) throws SQLException {
						MqSetting mqSetting = new MqSetting();
						mqSetting.setId(rs.getInt("id"));
						mqSetting.setExchangeName(rs.getString("exchange_name"));
						mqSetting.setQueueName(rs.getString("queue_name"));
						mqSetting.setHost(rs.getString("host"));
						mqSetting.setPort(rs.getInt("port"));
						mqSetting.setUser(rs.getString("user"));
						mqSetting.setPasswd(rs.getString("passwd"));
						mqSetting.setvHost(rs.getString("v_host"));
						mqSetting.setThNum(rs.getInt("th_num"));
						return mqSetting;
					}
				});
	}

}
