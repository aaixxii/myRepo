package jp.co.nec.aim.mm.mq.publisher;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import jp.co.nec.aim.mm.mq.cons.MqConst;

public class InsertDiagQualityPublisher extends SimplePublisher {

	public InsertDiagQualityPublisher() throws IOException, TimeoutException {
		super(MqConst.INSERT_DIAG_QUALITY_KEY);
	}

	public void insertDiagQuality(byte[] msg) throws IOException, TimeoutException {
		publish(msg);
	}

}
