package jp.co.nec.aim.mm.mq.subscriber;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeoutException;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Delivery;

import jp.co.nec.aim.message.proto.Diagnostics.PBDiagnostics;
import jp.co.nec.aim.mm.acceptor.service.AimSyncServiceResult;
import jp.co.nec.aim.mm.mq.cons.MqConst;
import jp.co.nec.aim.mm.mq.publisher.SimplePublisher;
import jp.co.nec.aim.mm.mq.test.util.MqTestUtility;
import mockit.Mock;
import mockit.MockUp;

public class InsertReqSubScriberTest {

	private InsertReqSubScriber insertReqSubScriber;

	private String requestId;
	private String referenceId;
	private List<Boolean> assertFlg;

	@Before
	public void init() throws IOException, TimeoutException {
		insertReqSubScriber = new InsertReqSubScriber();
		requestId = RandomStringUtils.randomNumeric(36);
		referenceId = RandomStringUtils.randomNumeric(36);
		assertFlg = new ArrayList<Boolean>();
	}

	@After
	public void tearDown() throws IOException, TimeoutException {
		insertReqSubScriber.close();
	}

	@Test
	public void InsertReqSubScriberTest_001() throws IOException, TimeoutException, InterruptedException {

		// Mock
		new MockUp<AimSyncServiceResult>() {
			@Mock
			public String getResultXml() {
				return MqTestUtility.getTestResultXml();
			}

			@Mock
			public PBDiagnostics getDiagnostics() {
				return MqTestUtility.buildTestPBDiagnostics(requestId, referenceId);
			}
		};

		String msg = "TEST";
		SimplePublisher publisher = new SimplePublisher(MqConst.INSERT_REQ_KEY);
		publisher.publish(msg);
		Thread.sleep(1000);

		SimpleSubScriber simpleSubScriber_xml = new SimpleSubScriber(MqConst.INSERT_RES_KEY) {
			@Override
			public void subScribeAction(Channel channel, String consumerTag, Delivery delivery) {
				try {
					assertFlg.add(MqTestUtility.getTestResultXml().equals(new String(delivery.getBody(), "UTF-8")));
				} catch (Exception e) {
					e.printStackTrace();
					assertFlg.add(false);
				}
			}
		};

		SimpleSubScriber simpleSubScriber_proto = new SimpleSubScriber(MqConst.INSERT_DIAG_QUALITY_KEY) {
			@Override
			public void subScribeAction(Channel channel, String consumerTag, Delivery delivery) {
				try {
					PBDiagnostics diagnostics = PBDiagnostics.parseFrom(delivery.getBody());
					assertFlg.add(MqTestUtility.buildTestPBDiagnostics(requestId, referenceId).equals(diagnostics));
				} catch (Exception e) {
					e.printStackTrace();
					assertFlg.add(false);
				}
			}
		};
		simpleSubScriber_xml.subScribe(true);
		simpleSubScriber_proto.subScribe(true);

		MqTestUtility.waitTest(assertFlg, 2);
		MqTestUtility.checkResult(assertFlg);
	}

}
