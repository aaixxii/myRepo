package jp.co.nec.aim.mm.mq.subscriber;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeoutException;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Delivery;

import jp.co.nec.aim.mm.acceptor.service.AimManageService;
import jp.co.nec.aim.mm.acceptor.service.AimManageServiceResult;
import jp.co.nec.aim.mm.mq.cons.MqConst;
import jp.co.nec.aim.mm.mq.publisher.SimplePublisher;
import jp.co.nec.aim.mm.mq.test.util.MqTestUtility;
import mockit.Mock;
import mockit.MockUp;

public class GetQualityReqSubScriberTest {

	private GetQualityReqSubScriber getQualityReqSubScriber;

	private String requestId;
	private String referenceId;
	private List<Boolean> assertFlg;

	/** ロガー */
	private static final Logger log = LoggerFactory.getLogger(GetQualityReqSubScriberTest.class);

	@Before
	public void init() throws IOException, TimeoutException {
		getQualityReqSubScriber = new GetQualityReqSubScriber();
		requestId = RandomStringUtils.randomNumeric(36);
		referenceId = RandomStringUtils.randomNumeric(36);
		assertFlg = new ArrayList<Boolean>();
	}

	@After
	public void tearDown() throws IOException, TimeoutException {
		getQualityReqSubScriber.close();
	}

	@Test
	public void GetQualityReqSubScriberTest_001() throws IOException, TimeoutException, InterruptedException {

		// Mock
		new MockUp<AimManageServiceResult>() {
			@Mock
			public String getResultXml() {
				return MqTestUtility.getTestResultXml();
			}
		};

		new MockUp<SimplePublisher>() {
			@Mock
			public void publish(byte[] msg) throws IOException {
				throw new RuntimeException("Unexpected method called");
			}
		};

		new MockUp<AimManageService>() {
			@Mock
			public AimManageServiceResult getQuality(String msg) {
				String resultXml = "<sample>dummy</sample>";
				AimManageServiceResult aimManageServiceResult = new AimManageServiceResult();
				aimManageServiceResult.setResultXml(resultXml);
				try {
					log.info(new Date().getTime() + " " + msg);
					//					Thread.sleep(1000);
				} catch (Exception e) {
					// TODO 自動生成された catch ブロック
					e.printStackTrace();
				}
				return aimManageServiceResult;
			}
		};

		String msg = "TEST";
		SimplePublisher publisher = new SimplePublisher(MqConst.GETQUALITY_REQ_KEY);
		for (int i = 0; i < 100; i++)
			publisher.publish(msg + String.valueOf(i));
		publisher.close();
		Thread.sleep(3000);
		SimpleSubScriber simpleSubScriber = new SimpleSubScriber(MqConst.GETQUALIY_RES_KEY) {
			@Override
			public void subScribeAction(Channel channel, String consumerTag, Delivery delivery) {
				try {
					assertFlg.add(MqTestUtility.getTestResultXml().equals(new String(delivery.getBody(), "UTF-8")));
					channel.basicAck(delivery.getEnvelope().getDeliveryTag(), true);
				} catch (Exception e) {
					e.printStackTrace();
					assertFlg.add(false);
					try {
						channel.basicNack(delivery.getEnvelope().getDeliveryTag(), true, true);
					} catch (IOException e1) {
						// TODO 自動生成された catch ブロック
						e1.printStackTrace();
					}
				}
			}
		};
		simpleSubScriber.subScribe(false);

		MqTestUtility.waitTest(assertFlg, 100);
		MqTestUtility.checkResult(assertFlg);
		simpleSubScriber.close();
	}

}
