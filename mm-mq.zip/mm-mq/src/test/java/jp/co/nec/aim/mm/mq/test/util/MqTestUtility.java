package jp.co.nec.aim.mm.mq.test.util;

import static org.junit.Assert.*;

import java.util.List;

import jp.co.nec.aim.message.proto.Diagnostics.PBDataBlock;
import jp.co.nec.aim.message.proto.Diagnostics.PBDataGroup;
import jp.co.nec.aim.message.proto.Diagnostics.PBDiagnostics;

public class MqTestUtility {

	public static PBDiagnostics buildTestPBDiagnostics(String requestId, String referenceId) {
		PBDiagnostics.Builder diagnostics = PBDiagnostics.newBuilder();
		diagnostics.setRequestId(requestId);
		diagnostics.setReferenceId(referenceId);
		PBDataBlock.Builder dataBlock = PBDataBlock.newBuilder();
		PBDataGroup.Builder dataGroup = PBDataGroup.newBuilder();
		dataGroup.setGroupName("Attempt");
		dataBlock.addDataGroup(dataGroup.build());
		diagnostics.setDataBlock(dataBlock.build());
		return diagnostics.build();
	}

	public static String getTestResultXml() {
		return "<sample>a</sample>";
	}

	public static void waitTest(List<Boolean> list, int expTestCnt) {
		System.out.println("@@ wait size " + list.size());
		while (list.size() != expTestCnt) {
			System.out.println("@@ wait size " + list.size());
			try {
				System.out.println(list.size());
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public static void checkResult(List<Boolean> list) {
		if (list.contains(Boolean.FALSE)) {
			String failMsg = "An unexpected exception has occurred. No.";
			for (int i = 0; i < list.size(); i++) {
				if (!list.get(i)) {
					failMsg += String.valueOf(i + 1) + ",";
				}
			}
			fail(failMsg);
		}
	}

}
