package jp.co.nec.aim.mm.mq.subscriber;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeoutException;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Delivery;

import jp.co.nec.aim.mm.acceptor.service.AimSyncServiceResult;
import jp.co.nec.aim.mm.mq.cons.MqConst;
import jp.co.nec.aim.mm.mq.publisher.SimplePublisher;
import jp.co.nec.aim.mm.mq.test.util.MqTestUtility;
import mockit.Mock;
import mockit.MockUp;

public class DeleteReqSubScriberTest {

	private DeleteReqSubScriber deleteReqSubScriber;

	private String requestId;
	private String referenceId;
	private List<Boolean> assertFlg;

	@Before
	public void init() throws IOException, TimeoutException {
		deleteReqSubScriber = new DeleteReqSubScriber();
		requestId = RandomStringUtils.randomNumeric(36);
		referenceId = RandomStringUtils.randomNumeric(36);
		assertFlg = new ArrayList<Boolean>();
	}

	@After
	public void tearDown() throws IOException, TimeoutException {
		deleteReqSubScriber.close();
	}

	@Test
	public void DeleteReqSubScriberTest_001() throws IOException, TimeoutException, InterruptedException {

		// Mock
		new MockUp<AimSyncServiceResult>() {
			@Mock
			public String getResultXml() {
				return MqTestUtility.getTestResultXml();
			}
		};

		new MockUp<SimplePublisher>() {
			@Mock
			public void publish(byte[] msg) throws IOException {
				throw new RuntimeException("Unexpected method called");
			}
		};

		String msg = "TEST";
		SimplePublisher publisher = new SimplePublisher(MqConst.DELETE_REQ_KEY);
		publisher.publish(msg);
		Thread.sleep(1000);
		SimpleSubScriber simpleSubScriber = new SimpleSubScriber(MqConst.DELETE_RES_KEY) {
			@Override
			public void subScribeAction(Channel channel, String consumerTag, Delivery delivery) {
				try {
					assertFlg.add(MqTestUtility.getTestResultXml().equals(new String(delivery.getBody(), "UTF-8")));
				} catch (Exception e) {
					e.printStackTrace();
					assertFlg.add(false);
				}
			}
		};
		simpleSubScriber.subScribe(true);

		MqTestUtility.waitTest(assertFlg, 1);
		MqTestUtility.checkResult(assertFlg);
	}

}
