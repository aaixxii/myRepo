package jp.co.nec.aim.mm.jms;

import java.io.Serializable;
import java.util.Date;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;

import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.JNDIConstants;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.sessionbeans.pojo.ExceptionSender;
import jp.co.nec.aim.mm.spring.jms.AsynchHTTPJMSMessage;
import jp.co.nec.aim.mm.util.JndiLookup;
import jp.co.nec.aim.mm.util.SafeCloseUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.support.converter.MessageConversionException;

/**
 * JmsSender
 * 
 * @author liuyq
 * 
 */
public class JmsSender {
	/** log instance **/
	private static Logger log = LoggerFactory.getLogger(JmsSender.class);

	/** ConnectionFactory **/
	private ConnectionFactory jmsConnectionFactory;
	private ExceptionSender exceptionSender = new ExceptionSender();

	private static JmsSender instance = new JmsSender();

	private JmsSender() {
	}

	public static synchronized JmsSender getInstance() {
		return instance;
	}

	/**
	 * Send event message
	 */
	private void convertAndSend(String queueName, Object object) {
		// build ConnectionFactory And Queue is necessary
		if (this.jmsConnectionFactory == null) {
			jmsConnectionFactory = JndiLookup.lookUp(JNDIConstants.JmsFactory,
					ConnectionFactory.class);
		}

		Queue queue = JndiLookup.lookUp(queueName, Queue.class);

		Connection connect = null;
		Session session = null;
		MessageProducer producer = null;
		try {
			connect = jmsConnectionFactory.createConnection();
			session = connect.createSession(false, Session.DUPS_OK_ACKNOWLEDGE);
			producer = session.createProducer(queue);
			// create a JMS message and send it
			Message message = toMessage(queueName, object, session);
			message.setJMSDeliveryTime(new Date().getTime());

			producer.send(message);
		} catch (JMSException e) {
			String errorMessage = "JMSException while queueing:" + queueName;
			log.error(errorMessage);

			// set event into error queue
			AimError error = AimError.JMS_ERROR;
			exceptionSender.sendAimException(error.getErrorCode(),
					String.format(error.getMessage(), e.getMessage()), e);

			throw new AimRuntimeException(errorMessage, e);
		} finally {
			SafeCloseUtil.close(producer);
			SafeCloseUtil.close(session);
			SafeCloseUtil.close(connect);
		}
	}

	/**
	 * convert into Message
	 * 
	 * @param object
	 * @param session
	 * @return
	 * @throws JMSException
	 * @throws MessageConversionException
	 */
	public Message toMessage(String queueName, Object object, Session session)
			throws JMSException, MessageConversionException {
		if (object instanceof String) {
			String textMessage = (String) object;
			if (log.isDebugEnabled()) {
				log.debug("Send message to Queue:" + queueName + ", Message:"
						+ textMessage);
			}
			return session.createTextMessage(textMessage);
		} else {
			if (log.isDebugEnabled()) {
				log.debug("Send message to Queue:" + queueName);
			}
			return session.createObjectMessage((Serializable) object);
		}
	}

	/**
	 * Send the message to SLB queue
	 * 
	 * @param notifier
	 *            the instance of NotifierEnum
	 * @param message
	 *            message detail
	 */
	public void sendToSLB(NotifierEnum notifier, String message) {
		AimJmsMessage jmsMsg = new AimJmsMessage(notifier,
				ReceiverEnum.LoadBalance, message);

		convertAndSend(JNDIConstants.SLB_QUEUE, jmsMsg.toString());
	}

	/**
	 * Send the message to FEJobPlanner queue
	 * 
	 * @param notifier
	 *            the instance of NotifierEnum
	 * @param message
	 *            message detail
	 */
	public void sendToFEJobPlanner(NotifierEnum notifier, String message) {
		AimJmsMessage jmsMsg = new AimJmsMessage(notifier,
				ReceiverEnum.FEJobPlan, message);

		convertAndSend(JNDIConstants.EXTRACT_JOB_PLANNER_QUEUE,
				jmsMsg.toString());
	}

	/**
	 * Send the message to InquiryJobPlanner queue
	 * 
	 * @param notifier
	 *            the instance of NotifierEnum
	 * @param message
	 *            message detail
	 */
	public void sendToInquiryJobPlanner(NotifierEnum notifier, String message) {
		AimJmsMessage jmsMsg = new AimJmsMessage(notifier,
				ReceiverEnum.InquiryJobPlan, message);

		convertAndSend(JNDIConstants.INQUIRY_JOB_PLANNER_QUEUE,
				jmsMsg.toString());
	}

	/**
	 * Send the message to FEJobDispatch queue
	 * 
	 * @param notifier
	 *            the instance of NotifierEnum
	 * @param message
	 *            message detail
	 */
	public void sendToFEJobDispatch(NotifierEnum notifier, String message) {
		AimJmsMessage jmsMsg = new AimJmsMessage(notifier,
				ReceiverEnum.FEJobDistributor, message);

		convertAndSend(JNDIConstants.EXTRACT_JOB_DISPATCH_QUEUE,
				jmsMsg.toString());
	}

	/**
	 * Send the message to InquiryJobDispatch queue
	 * 
	 * @param notifier
	 *            the instance of NotifierEnum
	 * @param message
	 *            message detail
	 */
	public void sendToInquiryJobDispatch(NotifierEnum notifier, String message) {
		AimJmsMessage jmsMsg = new AimJmsMessage(notifier,
				ReceiverEnum.InquiryJobDistributor, message);

		convertAndSend(JNDIConstants.INQUIRY_JOB_DISPATCH_QUEUE,
				jmsMsg.toString());
	}

//	/**
//	 * Send the Object message to info queue
//	 * 
//	 */
//	public void sendToInfoQueue(Object object) {
//		convertAndSend(JNDIConstants.INFO_QUEUE, object);
//	}
//
//	/**
//	 * Send the Object message to error queue
//	 * 
//	 */
//	public void sendToErrorQueue(Object object) {
//		convertAndSend(JNDIConstants.ERROR_QUEUE, object);
//	}

	/**
	 * Send the Object message to error queue
	 * 
	 * @param notifier
	 * @param url
	 * @param body
	 * @param isBinary
	 */
	public void sendToAsynchQueue(NotifierEnum notifier, String url,
			byte[] body, boolean isBinary) {
		AsynchHTTPJMSMessage jmsMsg = new AsynchHTTPJMSMessage(notifier, url,
				body, isBinary);

		convertAndSend(JNDIConstants.ASYNCH_QUEUE, jmsMsg);
	}
}
