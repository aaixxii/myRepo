package jp.co.nec.aim.mm.acceptor;

import static org.junit.Assert.fail;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.InquiryEnumTypes.InquiryFunctionType;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryJobInfo;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobRequest;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.exception.LicenseException;
import jp.co.nec.aim.mm.jms.JmsSender;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()
@Transactional
public class InquiryTest extends AbstractTransactionalJUnit4SpringContextTests {
	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;
	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;
	@Resource
	private Inquiry inquiry;

	@Before
	public void setUp() {
		jdbcTemplate.update("delete from job_queue");
		jdbcTemplate.update("delete from container_jobs");
		jdbcTemplate.update("delete from fusion_jobs");
		jdbcTemplate.update("delete from segments");
		jdbcTemplate.update("commit");
		setMockMethod();
	}

	private void setMockMethod() {
		new MockUp<JmsSender>() {
			@Mock
			private void convertAndSend(String queueName, Object object) {
				return;
			}
		};
	}

	@After
	public void tearDown() {
		jdbcTemplate.update("delete from job_queue");
		jdbcTemplate.update("delete from container_jobs");
		jdbcTemplate.update("delete from fusion_jobs");
		jdbcTemplate.update("delete from segments");
		jdbcTemplate.update("commit");		
	}

	@Test
	public void testInquiryInquiryJobRequestCommonOptionsBothNull() {
		List<InquiryRequest> inquiryRequests = new ArrayList<InquiryRequest>();
		CommonOptions options = new CommonOptions();
		try {
			inquiry.inquiry(inquiryRequests, options);

		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof AimRuntimeException);
			Assert.assertEquals("At least one search request must be given",
					e.getMessage());
		}
	}

	@Test
	public void testInquiryCommonOptions_FunctionNameIsNull() {
		PBInquiryJobRequest.Builder inquiryJobRequest = PBInquiryJobRequest
				.newBuilder().setJobInfo(
						PBInquiryJobInfo.newBuilder().setFunction(
								InquiryFunctionType.FI));
		List<Integer> containerIds = new ArrayList<Integer>();
		containerIds.add(335);
		InquiryRequest inquiryRequest = new InquiryRequest(
				InquiryFunctionType.FI.name(), "335", inquiryJobRequest);
		List<InquiryRequest> inquiryRequests = new ArrayList<InquiryRequest>();
		inquiryRequests.add(inquiryRequest);
		CommonOptions options = new CommonOptions();
		options.setPriority(1);
		options.setFromServlet(true);
		// options.setMinScore(1);
		options.setMaxCandidates(255);
		options.setDynThreshHitThreshold(1);
		options.setDynThreshPercentagePoint((float) 0.5);
		try {
			inquiry.inquiry(inquiryRequests, options);

		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof AimRuntimeException);
			Assert.assertEquals(
					"CommonOptions functioName can not be null or empty..",
					e.getMessage());
		}
	}

	@Test
	public void testInquiryCommonOptions_FunctionNameIsWrong() {
		PBInquiryJobRequest.Builder inquiryJobRequest = PBInquiryJobRequest
				.newBuilder().setJobInfo(
						PBInquiryJobInfo.newBuilder().setFunction(
								InquiryFunctionType.FI));
		List<Integer> containerIds = new ArrayList<Integer>();
		containerIds.add(335);
		InquiryRequest inquiryRequest = new InquiryRequest(
				InquiryFunctionType.FI.name(), "335", inquiryJobRequest);
		List<InquiryRequest> inquiryRequests = new ArrayList<InquiryRequest>();
		inquiryRequests.add(inquiryRequest);
		CommonOptions options = new CommonOptions();
		options.setFunctioName("FIP");
		options.setPriority(1);
		options.setFromServlet(true);
		// options.setMinScore(1);
		options.setMaxCandidates(255);
		options.setDynThreshHitThreshold(1);
		options.setDynThreshPercentagePoint((float) 0.5);
		try {
			inquiry.inquiry(inquiryRequests, options);

		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof AimRuntimeException);
			Assert.assertEquals(
					"Can not find function type by function Name:FIP",
					e.getMessage());
		}
	}

	/*
	 * @Test public void testInquiryOptionsFunctionTypeIsNull() {
	 * PBInquiryJobRequest.Builder inquiryJobRequest = PBInquiryJobRequest
	 * .newBuilder().setJobInfo( PBInquiryJobInfo.newBuilder().setFunction(
	 * InquiryFunctionType.FI)); List<Integer> containerIds = new
	 * ArrayList<Integer>(); containerIds.add(335); InquiryRequest
	 * inquiryRequest = new InquiryRequest( InquiryFunctionType.FI.name(),
	 * containerIds, inquiryJobRequest); List<InquiryRequest> inquiryRequests =
	 * new ArrayList<InquiryRequest>(); inquiryRequests.add(inquiryRequest);
	 * CommonOptions options = new CommonOptions(); options.setPriority(1);
	 * options.setFromServlet(true); options.setMinScore(1);
	 * options.setMaxCandidates(255); options.setDynThreshHitThreshold(1);
	 * options.setDynThreshPercentagePoint((float) 0.5);
	 * options.setFunctioName("FI");
	 * jdbcTemplate.update("delete from function_types"); try {
	 * inquiry.inquiry(inquiryRequests, options); } catch (Exception e) { //
	 * TODO: handle exception Assert.assertTrue(e instanceof
	 * AimRuntimeException);
	 * Assert.assertEquals("At least one search request must be given",
	 * e.getMessage()); }
	 * 
	 * 
	 * 
	 * }
	 */
	@Test
	public void testInquiryOptionsFunctionNameisNotNull() {
		PBInquiryJobRequest.Builder inquiryJobRequest = PBInquiryJobRequest
				.newBuilder().setJobInfo(
						PBInquiryJobInfo.newBuilder().setFunction(
								InquiryFunctionType.FI));
		List<Integer> containerIds = new ArrayList<Integer>();
		containerIds.add(335);
		InquiryRequest inquiryRequest = new InquiryRequest(
				InquiryFunctionType.FI.name(), "335", inquiryJobRequest);
		List<InquiryRequest> inquiryRequests = new ArrayList<InquiryRequest>();
		inquiryRequests.add(inquiryRequest);
		CommonOptions options = new CommonOptions();
		options.setPriority(1);
		options.setFromServlet(true);
		// options.setMinScore(1);
		options.setMaxCandidates(255);
		options.setDynThreshHitThreshold(1);
		options.setDynThreshPercentagePoint((float) 0.5);
		options.setFunctioName("FI");

		long jobId = inquiry.inquiry(inquiryRequests, options);
		jdbcTemplate.update("commit");
		Assert.assertNotNull(jobId);
		List<Map<String, Object>> listJQ = jdbcTemplate
				.queryForList("select * from job_queue");
		Assert.assertEquals(1, listJQ.size());
		Map<String, Object> mapJQ = listJQ.get(0);
		Assert.assertEquals(1,
				Integer.parseInt(mapJQ.get("PRIORITY").toString()));
		Assert.assertEquals(BigDecimal.valueOf(2), mapJQ.get("JOB_STATE"));
		Assert.assertEquals(8,
				Integer.parseInt(mapJQ.get("FAMILY_ID").toString()));
		Assert.assertEquals(255,
				Integer.parseInt(mapJQ.get("MAX_CANDIDATES").toString()));
		Assert.assertEquals(0,
				Integer.parseInt(mapJQ.get("REMAIN_JOBS").toString()));
		Assert.assertEquals(0,
				Integer.parseInt(mapJQ.get("FAILURE_COUNT").toString()));

		List<Map<String, Object>> listFJ = jdbcTemplate
				.queryForList("select * from fusion_jobs");
		Assert.assertEquals(1, listFJ.size());
		Map<String, Object> mapFJ = listFJ.get(0);
		Assert.assertEquals(BigDecimal.valueOf(20), mapFJ.get("FUNCTION_ID"));
		Assert.assertEquals(mapJQ.get("JOB_ID"), mapFJ.get("JOB_ID"));
		Assert.assertEquals(BigDecimal.valueOf(0),
				mapFJ.get("SEARCH_REQUEST_INDEX"));

		List<Map<String, Object>> listCJ = jdbcTemplate
				.queryForList("select * from container_jobs");
		Assert.assertEquals(0, listCJ.size());
	}

	@Test
	public void testInquiryOptionsFunctionNameNOCorrect() {
		PBInquiryJobRequest.Builder inquiryJobRequest = PBInquiryJobRequest
				.newBuilder().setJobInfo(
						PBInquiryJobInfo.newBuilder().setFunction(
								InquiryFunctionType.FI));
		List<Integer> containerIds = new ArrayList<Integer>();
		containerIds.add(335);
		InquiryRequest inquiryRequest = new InquiryRequest("FIP", "335",
				inquiryJobRequest);
		List<InquiryRequest> inquiryRequests = new ArrayList<InquiryRequest>();
		inquiryRequests.add(inquiryRequest);
		CommonOptions options = new CommonOptions();
		options.setPriority(1);
		options.setFromServlet(true);
		// options.setMinScore(1);
		options.setMaxCandidates(255);
		options.setDynThreshHitThreshold(1);
		options.setDynThreshPercentagePoint((float) 0.5);
		options.setFunctioName("FI");
		try {
			inquiry.inquiry(inquiryRequests, options);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof LicenseException);
			return;
		}
		fail();
	}

	@Test
	public void testInquiryOptionsFunctionNameISNULL() {
		PBInquiryJobRequest.Builder inquiryJobRequest = PBInquiryJobRequest
				.newBuilder().setJobInfo(
						PBInquiryJobInfo.newBuilder().setFunction(
								InquiryFunctionType.FI));
		List<Integer> containerIds = new ArrayList<Integer>();
		containerIds.add(335);
		InquiryRequest inquiryRequest = new InquiryRequest(null, "335",
				inquiryJobRequest);
		List<InquiryRequest> inquiryRequests = new ArrayList<InquiryRequest>();
		inquiryRequests.add(inquiryRequest);
		CommonOptions options = new CommonOptions();
		options.setPriority(1);
		options.setFromServlet(true);
		// options.setMinScore(1);
		options.setMaxCandidates(255);
		options.setDynThreshHitThreshold(1);
		options.setDynThreshPercentagePoint((float) 0.5);
		options.setFunctioName("FI");
		try {
			inquiry.inquiry(inquiryRequests, options);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof LicenseException);
			return;
		}
		fail();
	}

	@Test
	public void testInquiryOptionsContainerIdISNULL() {
		PBInquiryJobRequest.Builder inquiryJobRequest = PBInquiryJobRequest
				.newBuilder().setJobInfo(
						PBInquiryJobInfo.newBuilder().setFunction(
								InquiryFunctionType.FI));
		List<Integer> containerIds = new ArrayList<Integer>();
		InquiryRequest inquiryRequest = new InquiryRequest("FI", "335",
				inquiryJobRequest);
		List<InquiryRequest> inquiryRequests = new ArrayList<InquiryRequest>();
		inquiryRequests.add(inquiryRequest);
		CommonOptions options = new CommonOptions();
		options.setPriority(1);
		options.setFromServlet(true);
		// options.setMinScore(1);
		options.setMaxCandidates(255);
		options.setDynThreshHitThreshold(1);
		options.setDynThreshPercentagePoint((float) 0.5);
		options.setFunctioName("FI");
		try {
			inquiry.inquiry(inquiryRequests, options);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof AimRuntimeException);
			Assert.assertEquals(
					"At least one search container id must be given.",
					e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void testInquiryOptionsFunctionNameisNotNullEmptyJobIsZero() {
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,1,83,1,1,1,83)");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(2,2,1,1,83,1,1,1,83)");

		PBInquiryJobRequest.Builder inquiryJobRequest = PBInquiryJobRequest
				.newBuilder().setJobInfo(
						PBInquiryJobInfo.newBuilder().setFunction(
								InquiryFunctionType.TI));
		List<Integer> containerIds = new ArrayList<Integer>();
		containerIds.add(1);
		containerIds.add(2);
		InquiryRequest inquiryRequest = new InquiryRequest(
				InquiryFunctionType.TI.name(), "335", inquiryJobRequest);
		List<InquiryRequest> inquiryRequests = new ArrayList<InquiryRequest>();
		inquiryRequests.add(inquiryRequest);
		CommonOptions options = new CommonOptions();
		options.setPriority(1);
		options.setFromServlet(true);
		// options.setMinScore(1);
		options.setMaxCandidates(255);
		options.setDynThreshHitThreshold(1);
		options.setDynThreshPercentagePoint((float) 0.5);
		options.setFunctioName("TI");
		long jobId = inquiry.inquiry(inquiryRequests, options);
		jdbcTemplate.update("commit");
		Assert.assertNotNull(jobId);
		List<Map<String, Object>> listJobQueueList = jdbcTemplate
				.queryForList("select * from job_queue");
		Assert.assertEquals(1, listJobQueueList.size());
		Map<String, Object> mapJobQueue = listJobQueueList.get(0);
		Assert.assertEquals(2,
				Integer.parseInt(mapJobQueue.get("REMAIN_JOBS").toString()));
		Assert.assertEquals(0,
				Integer.parseInt(mapJobQueue.get("JOB_STATE").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(mapJobQueue.get("PRIORITY").toString()));
		Assert.assertEquals(255,
				Integer.parseInt(mapJobQueue.get("MAX_CANDIDATES").toString()));
		Assert.assertEquals(BigDecimal.valueOf(0.5),
				mapJobQueue.get("DYNTHRESH_PERCENTAGE_POINT"));
		Assert.assertEquals(BigDecimal.valueOf(1),
				mapJobQueue.get("DYNTHRESH_HIT_THRESHOLD"));

		List<Map<String, Object>> listFJ = jdbcTemplate
				.queryForList("select * from fusion_jobs");
		Assert.assertEquals(1, listFJ.size());
		Map<String, Object> mapFJ = listFJ.get(0);
		Assert.assertEquals(1,
				Integer.parseInt(mapFJ.get("FUNCTION_ID").toString()));
		Assert.assertEquals(mapJobQueue.get("JOB_ID"), mapFJ.get("JOB_ID"));

		List<Map<String, Object>> listCJ = jdbcTemplate
				.queryForList("select * from container_jobs");
		Assert.assertEquals(2, listCJ.size());
		Map<String, Object> mapCJ = listCJ.get(0);
		Map<String, Object> mapCJ1 = listCJ.get(1);
		Assert.assertEquals(mapFJ.get("FUSION_JOB_ID"),
				mapCJ.get("FUSION_JOB_ID"));
		Assert.assertEquals(mapFJ.get("FUSION_JOB_ID"),
				mapCJ1.get("FUSION_JOB_ID"));
		if (mapCJ.get("CONTAINER_ID").equals(BigDecimal.valueOf(1))) {
			Assert.assertEquals(BigDecimal.valueOf(2),
					mapCJ1.get("CONTAINER_ID"));
		} else {
			Assert.assertEquals(BigDecimal.valueOf(1),
					mapCJ1.get("CONTAINER_ID"));
			Assert.assertEquals(BigDecimal.valueOf(2),
					mapCJ.get("CONTAINER_ID"));
		}

	}

}
