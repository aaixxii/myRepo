package jp.co.nec.aim.mm.segment.sync;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentStateType;
import jp.co.nec.aim.message.proto.AIMMessages.PBCorruptTempalte;
import jp.co.nec.aim.message.proto.AIMMessages.PBSegmentInfo;
import jp.co.nec.aim.mm.sessionbeans.pojo.ExceptionSender;
import mockit.Mock;
import mockit.MockUp;

import org.apache.commons.lang3.StringUtils;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.common.collect.Lists;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class SegReportManagerTest {

	@Resource
	private DataSource ds;

	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;

	@Resource
	private JdbcTemplate jdbcTemplate;

	private SegReportManager segReportManager;

	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();

	private static PrintStream bk_out = System.out;
	private static PrintStream bk_err = System.err;

	@Before
	public void setUp() throws Exception {
		segReportManager = new SegReportManager(entityManager, ds);
		jdbcTemplate.update("delete from PERSON_BIOMETRICS");
		jdbcTemplate.update("delete from CONTAINER_JOBS");
		jdbcTemplate.update("delete from FE_LOT_JOBS");
		jdbcTemplate.update("delete from FE_JOB_QUEUE");
		jdbcTemplate.update("delete from MU_CONTACTS");
		jdbcTemplate.update("delete from MATCH_UNITS");
		jdbcTemplate.update("delete from MU_SEG_REPORTS");
		jdbcTemplate.update("delete from DATA_MANAGERS");
		jdbcTemplate.update("delete from DM_SEG_REPORTS");
		jdbcTemplate.update("delete from DM_SEGMENTS");
		jdbcTemplate.update("delete from MAP_REDUCERS");
		jdbcTemplate.update("delete from MR_CONTACTS");
		jdbcTemplate.update("delete from FE_JOB_QUEUE");
		jdbcTemplate.update("delete from FE_LOT_JOBS");
		jdbcTemplate.update("delete from RESOURCE_UPDATE_COUNT");
		jdbcTemplate.update("delete from FE_JOB_FAILURE_REASONS");
		jdbcTemplate.update("delete from SEGMENTS");
		jdbcTemplate.update("commit");
		setMockMethod();
		System.setOut(new PrintStream(outContent));
		System.setErr(new PrintStream(errContent));
	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.update("delete from PERSON_BIOMETRICS");
		jdbcTemplate.update("delete from CONTAINER_JOBS");
		jdbcTemplate.update("delete from FE_LOT_JOBS");
		jdbcTemplate.update("delete from FE_JOB_QUEUE");
		jdbcTemplate.update("delete from MU_CONTACTS");
		jdbcTemplate.update("delete from MATCH_UNITS");
		jdbcTemplate.update("delete from MU_SEG_REPORTS");
		jdbcTemplate.update("delete from DATA_MANAGERS");
		jdbcTemplate.update("delete from DM_SEG_REPORTS");
		jdbcTemplate.update("delete from DM_SEGMENTS");
		jdbcTemplate.update("delete from MAP_REDUCERS");
		jdbcTemplate.update("delete from MR_CONTACTS");
		jdbcTemplate.update("delete from FE_JOB_QUEUE");
		jdbcTemplate.update("delete from FE_LOT_JOBS");
		jdbcTemplate.update("delete from FE_JOB_FAILURE_REASONS");
		jdbcTemplate.update("delete from RESOURCE_UPDATE_COUNT");
		jdbcTemplate.update("delete from SEGMENTS");
		jdbcTemplate.update("commit");		
		System.setOut(bk_out);
		System.setErr(bk_err);
	}

	private void setMockMethod() {
		new MockUp<ExceptionSender>() {
			@Mock
			private void send(String reasonCode, String msg, long jobId,
					long topLevelId, long unitId, Exception e) {
				return;
			}
		};

	}

	@Test
	public void testFilterSegmentInfos_NotFoundSegInDB() {
		PBSegmentInfo segmentInfo = PBSegmentInfo.newBuilder().setId(1)
				.setState(SegmentStateType.SEGMENT_STATE_DISK).setVersion(1)
				.setQueuedVersion(1)
				.setCorruptTemplates(PBCorruptTempalte.newBuilder().addId(1))
				.build();
		PBSegmentInfo segmentInfo1 = PBSegmentInfo.newBuilder().setId(2)
				.setState(SegmentStateType.SEGMENT_STATE_DISK).setVersion(1)
				.setQueuedVersion(1)
				.setCorruptTemplates(PBCorruptTempalte.newBuilder().addId(4))
				.build();
		List<PBSegmentInfo> segInfos = Lists.newArrayList();
		segInfos.add(segmentInfo);
		segInfos.add(segmentInfo1);
		segReportManager.filterSegmentInfos(segInfos);
		Assert.assertTrue(contains("Segment id: 1 is not found in System.."));
	}

	@Test
	public void testFilterSegmentInfos_VersionDiffLessThanMax() {
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,3,26,3,10,10,26)");
		jdbcTemplate.update("commit");
		PBSegmentInfo segmentInfo = PBSegmentInfo.newBuilder().setId(1)
				.setState(SegmentStateType.SEGMENT_STATE_DISK).setVersion(1)
				.setQueuedVersion(1)
				.setCorruptTemplates(PBCorruptTempalte.newBuilder().addId(1))
				.build();
		PBSegmentInfo segmentInfo1 = PBSegmentInfo.newBuilder().setId(2)
				.setState(SegmentStateType.SEGMENT_STATE_DISK).setVersion(1)
				.setQueuedVersion(1)
				.setCorruptTemplates(PBCorruptTempalte.newBuilder().addId(4))
				.build();
		List<PBSegmentInfo> segInfos = Lists.newArrayList();
		segInfos.add(segmentInfo);
		segInfos.add(segmentInfo1);
		segReportManager.filterSegmentInfos(segInfos);
		Assert.assertEquals(2, segInfos.size());
		Assert.assertEquals(1, segInfos.get(0).getId());
		Assert.assertEquals(2, segInfos.get(1).getId());

	}

	@Test
	public void testFilterSegmentInfos_VersionDiffThanMax() {
		jdbcTemplate
				.update("insert into person_biometrics (BIOMETRICS_ID,EXTERNAL_ID,BIOMETRIC_DATA,BIOMETRIC_DATA_LEN,REGISTED_TS,CORRUPTED_FLAG,EVENT_ID,CONTAINER_ID)values(1,1,CAST('111' AS BINARY),26,1111,0,1,1)");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,3,26,3,2010,2010,26)");
		jdbcTemplate.update("commit");
		PBSegmentInfo segmentInfo = PBSegmentInfo.newBuilder().setId(1)
				.setState(SegmentStateType.SEGMENT_STATE_DISK).setVersion(1)
				.setQueuedVersion(1)
				.setCorruptTemplates(PBCorruptTempalte.newBuilder().addId(1))
				.build();
		PBSegmentInfo segmentInfo1 = PBSegmentInfo.newBuilder().setId(2)
				.setState(SegmentStateType.SEGMENT_STATE_DISK).setVersion(1)
				.setQueuedVersion(1)
				.setCorruptTemplates(PBCorruptTempalte.newBuilder().addId(4))
				.build();
		List<PBSegmentInfo> segInfos = Lists.newArrayList();
		segInfos.add(segmentInfo);
		segInfos.add(segmentInfo1);
		segReportManager.filterSegmentInfos(segInfos);
		Assert.assertEquals(1, segInfos.size());
		Assert.assertEquals(2, segInfos.get(0).getId());
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from PERSON_BIOMETRICS");
		Assert.assertEquals(1,
				Integer.parseInt(list.get(0).get("CORRUPTED_FLAG").toString()));
	}

	@Test
	public void testUpdateMuSegReport() {
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,3,26,3,2010,2010,26)");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(2,1,1,3,26,3,2010,2010,26)");
		jdbcTemplate
				.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','EXITED')");
		jdbcTemplate.update("commit");
		PBSegmentInfo segmentInfo = PBSegmentInfo.newBuilder().setId(1)
				.setState(SegmentStateType.SEGMENT_STATE_DISK).setVersion(1)
				.setQueuedVersion(1)
				.setCorruptTemplates(PBCorruptTempalte.newBuilder().addId(1))
				.build();
		PBSegmentInfo segmentInfo1 = PBSegmentInfo.newBuilder().setId(2)
				.setState(SegmentStateType.SEGMENT_STATE_DISK).setVersion(1)
				.setQueuedVersion(1)
				.setCorruptTemplates(PBCorruptTempalte.newBuilder().addId(4))
				.build();
		List<PBSegmentInfo> segInfos = Lists.newArrayList();
		segInfos.add(segmentInfo);
		segInfos.add(segmentInfo1);
		segReportManager.updateMuSegReport(segInfos, 1);
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from MU_SEG_REPORTS");
		Assert.assertEquals(2, list.size());
	}

	@Test
	public void testUpdateMuSegReport_throwReportDBException() {

		/*
		 * new MockUp<MarkCorruptedTemplate>() {
		 * 
		 * @Mock public int execute() { throw new DataAccessException(); } };
		 */
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,3,26,3,2010,2010,26)");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(2,1,1,3,26,3,2010,2010,26)");
		jdbcTemplate
				.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','EXITED')");
		jdbcTemplate.update("commit");
		PBSegmentInfo segmentInfo = PBSegmentInfo.newBuilder().setId(1)
				.setState(SegmentStateType.SEGMENT_STATE_DISK).setVersion(1)
				.setQueuedVersion(1)
				.setCorruptTemplates(PBCorruptTempalte.newBuilder().addId(1))
				.build();
		PBSegmentInfo segmentInfo1 = PBSegmentInfo.newBuilder().setId(2)
				.setState(SegmentStateType.SEGMENT_STATE_DISK).setVersion(1)
				.setQueuedVersion(1)
				.setCorruptTemplates(PBCorruptTempalte.newBuilder().addId(4))
				.build();
		List<PBSegmentInfo> segInfos = Lists.newArrayList();
		segInfos.add(segmentInfo);
		segInfos.add(segmentInfo1);
		segReportManager.updateMuSegReport(segInfos, 1);
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from MU_SEG_REPORTS");
		Assert.assertEquals(2, list.size());
	}

	@Test
	public void testUpdateMuSegReport_OneRecordExistInMU_SEG_REPORTS() {
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,3,26,3,2010,2010,26)");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(2,1,1,3,26,3,2010,2010,26)");
		jdbcTemplate
				.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','EXITED')");
		jdbcTemplate
				.update("insert into mu_seg_reports(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,1,1,2,2)");
		jdbcTemplate.update("commit");
		PBSegmentInfo segmentInfo = PBSegmentInfo.newBuilder().setId(1)
				.setState(SegmentStateType.SEGMENT_STATE_DISK).setVersion(1)
				.setQueuedVersion(1)
				.setCorruptTemplates(PBCorruptTempalte.newBuilder().addId(1))
				.build();
		PBSegmentInfo segmentInfo1 = PBSegmentInfo.newBuilder().setId(2)
				.setState(SegmentStateType.SEGMENT_STATE_DISK).setVersion(1)
				.setQueuedVersion(1)
				.setCorruptTemplates(PBCorruptTempalte.newBuilder().addId(4))
				.build();
		List<PBSegmentInfo> segInfos = Lists.newArrayList();
		segInfos.add(segmentInfo);
		segInfos.add(segmentInfo1);
		segReportManager.updateMuSegReport(segInfos, 1);
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from MU_SEG_REPORTS");
		Assert.assertEquals(2, list.size());
		for (int i = 0; i < 2; i++) {
			Map<String, Object> map = list.get(i);
			if (Integer.parseInt(map.get("SEGMENT_ID").toString()) == 1) {
				Assert.assertEquals(1,
						Integer.parseInt(map.get("SEGMENT_VERSION").toString()));
				Assert.assertEquals(1, Integer.parseInt(map.get(
						"SEGMENT_QUEUED_VERSION").toString()));
			}
		}
	}

	@Test
	public void testUpdateMuSegReport_TwoRecordExistInMU_SEG_REPORTS() {
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,3,26,3,2010,2010,26)");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(2,1,1,3,26,3,2010,2010,26)");
		jdbcTemplate
				.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','EXITED')");
		jdbcTemplate
				.update("insert into mu_seg_reports(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,1,1,2,2)");
		jdbcTemplate
				.update("insert into mu_seg_reports(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,2,1,1,1)");
		jdbcTemplate.update("commit");
		PBSegmentInfo segmentInfo = PBSegmentInfo.newBuilder().setId(1)
				.setState(SegmentStateType.SEGMENT_STATE_DISK).setVersion(1)
				.setQueuedVersion(1)
				.setCorruptTemplates(PBCorruptTempalte.newBuilder().addId(1))
				.build();
		PBSegmentInfo segmentInfo1 = PBSegmentInfo.newBuilder().setId(2)
				.setState(SegmentStateType.SEGMENT_STATE_DISK).setVersion(2)
				.setQueuedVersion(3)
				.setCorruptTemplates(PBCorruptTempalte.newBuilder().addId(4))
				.build();
		List<PBSegmentInfo> segInfos = Lists.newArrayList();
		segInfos.add(segmentInfo);
		segInfos.add(segmentInfo1);
		segReportManager.updateMuSegReport(segInfos, 1);
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from MU_SEG_REPORTS");
		Assert.assertEquals(2, list.size());
		for (int i = 0; i < 2; i++) {
			Map<String, Object> map = list.get(i);
			if (Integer.parseInt(map.get("SEGMENT_ID").toString()) == 1) {
				Assert.assertEquals(1,
						Integer.parseInt(map.get("SEGMENT_VERSION").toString()));
				Assert.assertEquals(1, Integer.parseInt(map.get(
						"SEGMENT_QUEUED_VERSION").toString()));
			}
			if (Integer.parseInt(map.get("SEGMENT_ID").toString()) == 2) {
				Assert.assertEquals(2,
						Integer.parseInt(map.get("SEGMENT_VERSION").toString()));
				Assert.assertEquals(3, Integer.parseInt(map.get(
						"SEGMENT_QUEUED_VERSION").toString()));
			}
		}
	}

	@Test
	public void testUpdateMuSegReport_ThreeRecordExistInMU_SEG_REPORTS_TwoSegmentInfos() {
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,3,26,3,2010,2010,26)");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(2,1,1,3,26,3,2010,2010,26)");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(3,1,1,3,26,3,2010,2010,26)");
		jdbcTemplate
				.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','EXITED')");
		jdbcTemplate
				.update("insert into mu_seg_reports(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,1,1,2,2)");
		jdbcTemplate
				.update("insert into mu_seg_reports(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,2,1,1,1)");
		jdbcTemplate
				.update("insert into mu_seg_reports(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,3,1,1,1)");
		jdbcTemplate.update("commit");
		PBSegmentInfo segmentInfo = PBSegmentInfo.newBuilder().setId(1)
				.setState(SegmentStateType.SEGMENT_STATE_DISK).setVersion(1)
				.setQueuedVersion(1)
				.setCorruptTemplates(PBCorruptTempalte.newBuilder().addId(1))
				.build();
		PBSegmentInfo segmentInfo1 = PBSegmentInfo.newBuilder().setId(2)
				.setState(SegmentStateType.SEGMENT_STATE_DISK).setVersion(2)
				.setQueuedVersion(3)
				.setCorruptTemplates(PBCorruptTempalte.newBuilder().addId(4))
				.build();
		List<PBSegmentInfo> segInfos = Lists.newArrayList();
		segInfos.add(segmentInfo);
		segInfos.add(segmentInfo1);
		List<Map<String, Object>> listMSR = jdbcTemplate
				.queryForList("select * from MU_SEG_REPORTS");
		Assert.assertEquals(3, listMSR.size());
		segReportManager.updateMuSegReport(segInfos, 1);
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from MU_SEG_REPORTS");
		Assert.assertEquals(2, list.size());
		for (int i = 0; i < 2; i++) {
			Map<String, Object> map = list.get(i);
			if (Integer.parseInt(map.get("SEGMENT_ID").toString()) == 1) {
				Assert.assertEquals(1,
						Integer.parseInt(map.get("SEGMENT_VERSION").toString()));
				Assert.assertEquals(1, Integer.parseInt(map.get(
						"SEGMENT_QUEUED_VERSION").toString()));
			}
			if (Integer.parseInt(map.get("SEGMENT_ID").toString()) == 2) {
				Assert.assertEquals(2,
						Integer.parseInt(map.get("SEGMENT_VERSION").toString()));
				Assert.assertEquals(3, Integer.parseInt(map.get(
						"SEGMENT_QUEUED_VERSION").toString()));
			}
		}
	}

	@Test
	public void testUpdateMuSegReport_SegmentInfosIsNull() {
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,3,26,3,2010,2010,26)");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(2,1,1,3,26,3,2010,2010,26)");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(3,1,1,3,26,3,2010,2010,26)");
		jdbcTemplate
				.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','EXITED')");
		jdbcTemplate
				.update("insert into mu_seg_reports(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,1,1,2,2)");
		jdbcTemplate
				.update("insert into mu_seg_reports(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,2,1,1,1)");
		jdbcTemplate
				.update("insert into mu_seg_reports(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,3,1,1,1)");
		jdbcTemplate.update("commit");
		List<PBSegmentInfo> segInfos = Lists.newArrayList();
		List<Map<String, Object>> listMSR = jdbcTemplate
				.queryForList("select * from MU_SEG_REPORTS");
		Assert.assertEquals(3, listMSR.size());
		segReportManager.updateMuSegReport(segInfos, 1);
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from MU_SEG_REPORTS");
		Assert.assertEquals(0, list.size());
	}

	@Test
	public void testUpdateDmSegReport() {
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,3,26,3,2010,2010,26)");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(2,1,1,3,26,3,2010,2010,26)");
		jdbcTemplate
				.update("insert into data_managers(DM_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','EXITED')");
		jdbcTemplate.update("commit");
		PBSegmentInfo segmentInfo = PBSegmentInfo.newBuilder().setId(1)
				.setState(SegmentStateType.SEGMENT_STATE_DISK).setVersion(1)
				.setQueuedVersion(1)
				.setCorruptTemplates(PBCorruptTempalte.newBuilder().addId(1))
				.build();
		PBSegmentInfo segmentInfo1 = PBSegmentInfo.newBuilder().setId(2)
				.setState(SegmentStateType.SEGMENT_STATE_DISK).setVersion(1)
				.setQueuedVersion(1)
				.setCorruptTemplates(PBCorruptTempalte.newBuilder().addId(4))
				.build();
		List<PBSegmentInfo> segInfos = Lists.newArrayList();
		segInfos.add(segmentInfo);
		segInfos.add(segmentInfo1);
		segReportManager.updateDmSegReport(segInfos, 1);
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from DM_SEG_REPORTS");
		Assert.assertEquals(2, list.size());
	}

	@Test
	public void testUpdateDmSegReport_OneRecordExistInDM_SEG_REPORTS() {
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,3,26,3,2010,2010,26)");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(2,1,1,3,26,3,2010,2010,26)");
		jdbcTemplate
				.update("insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','EXITED')");
		jdbcTemplate
				.update("insert into dm_seg_reports(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,1,1,2)");
		jdbcTemplate.update("commit");
		PBSegmentInfo segmentInfo = PBSegmentInfo.newBuilder().setId(1)
				.setState(SegmentStateType.SEGMENT_STATE_DISK).setVersion(1)
				.setQueuedVersion(1)
				.setCorruptTemplates(PBCorruptTempalte.newBuilder().addId(1))
				.build();
		PBSegmentInfo segmentInfo1 = PBSegmentInfo.newBuilder().setId(2)
				.setState(SegmentStateType.SEGMENT_STATE_DISK).setVersion(1)
				.setQueuedVersion(1)
				.setCorruptTemplates(PBCorruptTempalte.newBuilder().addId(4))
				.build();
		List<PBSegmentInfo> segInfos = Lists.newArrayList();
		segInfos.add(segmentInfo);
		segInfos.add(segmentInfo1);
		segReportManager.updateDmSegReport(segInfos, 1);
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from DM_SEG_REPORTS");
		Assert.assertEquals(2, list.size());
		for (int i = 0; i < 2; i++) {
			Map<String, Object> map = list.get(i);
			if (Integer.parseInt(map.get("SEGMENT_ID").toString()) == 1) {
				Assert.assertEquals(1,
						Integer.parseInt(map.get("SEGMENT_VERSION").toString()));
			} else {
				Assert.assertEquals(2,
						Integer.parseInt(map.get("SEGMENT_ID").toString()));
				Assert.assertEquals(1,
						Integer.parseInt(map.get("SEGMENT_VERSION").toString()));
			}
		}
	}

	@Test
	public void testUpdateDmSegReport_TwoRecordExistInDM_SEG_REPORTS() {
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,3,26,3,2010,2010,26)");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(2,1,1,3,26,3,2010,2010,26)");
		jdbcTemplate
				.update("insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','EXITED')");
		jdbcTemplate
				.update("insert into dm_seg_reports(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,1,1,2)");
		jdbcTemplate
				.update("insert into dm_seg_reports(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,2,1,1)");
		jdbcTemplate.update("commit");
		PBSegmentInfo segmentInfo = PBSegmentInfo.newBuilder().setId(1)
				.setState(SegmentStateType.SEGMENT_STATE_MEMORY).setVersion(1)
				.setQueuedVersion(1)
				.setCorruptTemplates(PBCorruptTempalte.newBuilder().addId(1))
				.build();
		PBSegmentInfo segmentInfo1 = PBSegmentInfo.newBuilder().setId(2)
				.setState(SegmentStateType.SEGMENT_STATE_DISK).setVersion(2)
				.setQueuedVersion(3)
				.setCorruptTemplates(PBCorruptTempalte.newBuilder().addId(4))
				.build();
		List<PBSegmentInfo> segInfos = Lists.newArrayList();
		segInfos.add(segmentInfo);
		segInfos.add(segmentInfo1);
		segReportManager.updateDmSegReport(segInfos, 1);
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from DM_SEG_REPORTS");
		Assert.assertEquals(2, list.size());
		for (int i = 0; i < 2; i++) {
			Map<String, Object> map = list.get(i);
			if (Integer.parseInt(map.get("SEGMENT_ID").toString()) == 1) {
				Assert.assertEquals(1,
						Integer.parseInt(map.get("SEGMENT_VERSION").toString()));
				Assert.assertEquals(0,
						Integer.parseInt(map.get("STATUS").toString()));
			}
			if (Integer.parseInt(map.get("SEGMENT_ID").toString()) == 2) {
				Assert.assertEquals(2,
						Integer.parseInt(map.get("SEGMENT_VERSION").toString()));
				Assert.assertEquals(1,
						Integer.parseInt(map.get("STATUS").toString()));
			}
		}
	}

	@Test
	public void testUpdateDmSegReport_ThreeRecordExistInDM_SEG_REPORTS_TwoSegmentInfos() {
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,3,26,3,2010,2010,26)");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(2,1,1,3,26,3,2010,2010,26)");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(3,1,1,3,26,3,2010,2010,26)");
		jdbcTemplate
				.update("insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','EXITED')");
		jdbcTemplate
				.update("insert into dm_seg_reports(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,1,1,2)");
		jdbcTemplate
				.update("insert into dm_seg_reports(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,2,1,1)");
		jdbcTemplate
				.update("insert into dm_seg_reports(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,3,1,1)");
		jdbcTemplate.update("commit");
		PBSegmentInfo segmentInfo = PBSegmentInfo.newBuilder().setId(1)
				.setState(SegmentStateType.SEGMENT_STATE_DISK).setVersion(1)
				.setQueuedVersion(1)
				.setCorruptTemplates(PBCorruptTempalte.newBuilder().addId(1))
				.build();
		PBSegmentInfo segmentInfo1 = PBSegmentInfo.newBuilder().setId(2)
				.setState(SegmentStateType.SEGMENT_STATE_DISK).setVersion(2)
				.setQueuedVersion(3)
				.setCorruptTemplates(PBCorruptTempalte.newBuilder().addId(4))
				.build();
		List<PBSegmentInfo> segInfos = Lists.newArrayList();
		segInfos.add(segmentInfo);
		segInfos.add(segmentInfo1);
		List<Map<String, Object>> listMSR = jdbcTemplate
				.queryForList("select * from DM_SEG_REPORTS");
		Assert.assertEquals(3, listMSR.size());
		segReportManager.updateDmSegReport(segInfos, 1);
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from DM_SEG_REPORTS");
		Assert.assertEquals(2, list.size());
		for (int i = 0; i < 2; i++) {
			Map<String, Object> map = list.get(i);
			if (Integer.parseInt(map.get("SEGMENT_ID").toString()) == 1) {
				Assert.assertEquals(1,
						Integer.parseInt(map.get("SEGMENT_VERSION").toString()));
			}
			if (Integer.parseInt(map.get("SEGMENT_ID").toString()) == 2) {
				Assert.assertEquals(2,
						Integer.parseInt(map.get("SEGMENT_VERSION").toString()));
			}
		}
	}

	@Test
	public void testUpdateDmSegReport_SegmentInfosIsNull() {
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(1,1,1,3,26,3,2010,2010,26)");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(2,1,1,3,26,3,2010,2010,26)");
		jdbcTemplate
				.update("insert into segments(SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)values(3,1,1,3,26,3,2010,2010,26)");
		jdbcTemplate
				.update("insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','EXITED')");
		jdbcTemplate
				.update("insert into dm_seg_reports(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,1,1,2)");
		jdbcTemplate
				.update("insert into dm_seg_reports(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,2,1,1)");
		jdbcTemplate
				.update("insert into dm_seg_reports(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,3,1,1)");
		jdbcTemplate.update("commit");
		List<PBSegmentInfo> segInfos = Lists.newArrayList();
		List<Map<String, Object>> listMSR = jdbcTemplate
				.queryForList("select * from DM_SEG_REPORTS");
		Assert.assertEquals(3, listMSR.size());
		segReportManager.updateDmSegReport(segInfos, 1);
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from DM_SEG_REPORTS");
		Assert.assertEquals(0, list.size());
	}

	private boolean contains(String msg) {
		return StringUtils.contains(outContent.toString(), msg);
	}
}
