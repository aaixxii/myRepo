package jp.co.nec.aim.mm.validator;

import static org.junit.Assert.fail;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPrintType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerSetType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.TemplateFormatType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBInquiryScopeOptions;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplate;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateData;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateIndexer;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateReference;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.InquiryFunctionType;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBFusionJobInput;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryFusionWeight;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryJobInfo;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryOptions;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobRequest;
import jp.co.nec.aim.message.proto.SyncEnumTypes.SyncFunctionType;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest.PBSyncDeletePayload;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest.PBSyncInsertPayload;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.exception.ArgumentException;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.protobuf.ByteString;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class AcceptorValidatorTest {

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;

	private AcceptorValidator acceptorValidator;
	@Resource
	private JdbcTemplate jdbcTemplate;

	@Resource
	private DataSource dataSource;

	@Before
	public void setUp() {
		acceptorValidator = new AcceptorValidator(manager, dataSource);
		jdbcTemplate.update("delete from fe_lot_jobs");
		jdbcTemplate.update("delete from fe_job_queue");
		jdbcTemplate.update("delete from fe_results");
		jdbcTemplate.update("delete from job_queue");
		jdbcTemplate.update("delete from segments");
		jdbcTemplate.update("delete from match_units");
		jdbcTemplate.update("delete from system_config");
		jdbcTemplate.update("commit");
	}

	@After
	public void tearDown() {
		jdbcTemplate.update("delete from fe_job_queue");
		jdbcTemplate.update("delete from fe_results");
		jdbcTemplate.update("delete from job_queue");
		jdbcTemplate.update("delete from segments");
		jdbcTemplate.update("delete from match_units");
		jdbcTemplate.update("delete from system_config");
		jdbcTemplate.update("commit");

	}

	@Test
	public void testCheckInquiryJobRequest_priorityOutOfRange() {
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder().setPriority(11)
								.setFunction(InquiryFunctionType.TI)).build();

		try {
			acceptorValidator.checkInquiryJobRequest(request);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.PRIORITY_OUT_RANGE.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals("Inquiry Job (Priority is out of range)",
					exception.getDescription());
			return;
		}
		fail();

	}

	@Test
	public void testCheckInquiryJobRequest_FunctionTI_NOFingerPrintType() {
		jdbcTemplate
				.update("insert into fe_job_queue(JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,1,123,0)");
		jdbcTemplate
				.update("insert into fe_results(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,1,CAST('111' AS BINARY),'TEMPLATE_TI',1)");
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder().setPriority(5)
								.setFunction(InquiryFunctionType.TI))
				.addFusionJobInput(
						PBFusionJobInput
								.newBuilder()
								.setScopes(
										PBInquiryScopeOptions.newBuilder()
												.addScope(1))
								.setKeyedTemplateData(
										PBKeyedTemplateData
												.newBuilder()
												.setKeyedReferenece(
														PBKeyedTemplateReference
																.newBuilder()
																.setJobId(1)
																.setKey(TemplateFormatType.TEMPLATE_TI)
																.setIndexer(
																		PBKeyedTemplateIndexer
																				.newBuilder()
																				.setFingerPrintType(
																						FingerPrintType.FINGER_PRINT_ROLLED)))))
				.build();
		try {
			acceptorValidator.checkInquiryJobRequest(request);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.INQ_COMBINE_OF_KEY.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Inquiry Job (The combination of functionName, TemplateFormatType, Search Side FingerPrintType and File side FingerPrintType is not correct, Search Key: SearchKey[function=TI,templateFmt=TEMPLATE_TI,sFinPrint=FINGER_PRINT_ROLLED,fFinPrint=<null>])",
					exception.getDescription());
			return;
		}
		fail();

	}

	@Test
	public void testCheckInquiryJobRequest_FunctionTI_NOCorrect() {
		jdbcTemplate
				.update("insert into fe_job_queue(JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,1,123,0)");
		jdbcTemplate
				.update("insert into fe_results(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,1,CAST('111' AS BINARY),'TEMPLATE_TI',1)");
		PBInquiryScopeOptions.Builder scopeBuilder = PBInquiryScopeOptions
				.newBuilder().addScope(1)
				.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_ROLLED)
				.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_ROLLED);
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput
				.newBuilder()
				.setScopes(scopeBuilder)
				.setKeyedTemplateData(
						PBKeyedTemplateData
								.newBuilder()
								.setKeyedReferenece(
										PBKeyedTemplateReference
												.newBuilder()
												.setJobId(1)
												.setKey(TemplateFormatType.TEMPLATE_TI)
												.setIndexer(
														PBKeyedTemplateIndexer
																.newBuilder()
																.setFingerPrintType(
																		FingerPrintType.FINGER_PRINT_ROLLED))));
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder().setPriority(5)
								.setFunction(InquiryFunctionType.TI))
				.addFusionJobInput(fusionBuilder).build();
		try {
			acceptorValidator.checkInquiryJobRequest(request);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(
					AimError.INQ_SCOPE_FINGERPRINTTYPE.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Inquiry Service (Scope FingerPrintType is not correct.)",
					exception.getDescription());
			return;
		}
		fail();

	}

	@Test
	public void testCheckInquiryJobRequest_FunctionTIM_NOFingerPrintType() {
		jdbcTemplate
				.update("insert into fe_job_queue(JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,1,123,0)");
		jdbcTemplate
				.update("insert into fe_results(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,1,CAST('111' AS BINARY),'TEMPLATE_TIM',1)");
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder().setPriority(5)
								.setFunction(InquiryFunctionType.TIM))
				.addFusionJobInput(
						PBFusionJobInput
								.newBuilder()
								.setScopes(
										PBInquiryScopeOptions.newBuilder()
												.addScope(1))
								.setKeyedTemplateData(
										PBKeyedTemplateData
												.newBuilder()
												.setKeyedReferenece(
														PBKeyedTemplateReference
																.newBuilder()
																.setJobId(1)
																.setKey(TemplateFormatType.TEMPLATE_TIM)
																.setIndexer(
																		PBKeyedTemplateIndexer
																				.newBuilder()
																				.setFingerPrintType(
																						FingerPrintType.FINGER_PRINT_ROLLED)))))
				.build();
		try {
			acceptorValidator.checkInquiryJobRequest(request);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.INQ_COMBINE_OF_KEY.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Inquiry Job (The combination of functionName, TemplateFormatType, Search Side FingerPrintType and File side FingerPrintType is not correct, Search Key: SearchKey[function=TIM,templateFmt=TEMPLATE_TIM,sFinPrint=FINGER_PRINT_ROLLED,fFinPrint=<null>])",
					exception.getDescription());
			return;
		}
		fail();

	}

	@Test
	public void testCheckInquiryJobRequest_FunctionTIM_NOCorrect() {
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder().setPriority(5)
								.setFunction(InquiryFunctionType.TIM))
				.addFusionJobInput(
						PBFusionJobInput
								.newBuilder()
								.setScopes(
										PBInquiryScopeOptions
												.newBuilder()
												.addScope(1)
												.addTargetFingerPrint(
														FingerPrintType.FINGER_PRINT_ROLLED)
												.addTargetFingerPrint(
														FingerPrintType.FINGER_PRINT_ROLLED))
								.setKeyedTemplateData(
										PBKeyedTemplateData.newBuilder()))
				.build();

		try {
			acceptorValidator.checkInquiryJobRequest(request);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.INQ_TEM_TEMREF.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Inquiry Job (Both PBKeyedTemplate and PBKeyedTemplateReference are not specified)",
					exception.getDescription());
			return;
		}
		fail();

	}

	@Test
	public void testCheckInquiryJobRequest_FunctionTLI_NOFingerPrintType() {
		jdbcTemplate
				.update("insert into fe_job_queue(JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,1,123,0)");
		jdbcTemplate
				.update("insert into fe_results(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,1,CAST('111' AS BINARY),'TEMPLATE_TLI',0)");
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput
				.newBuilder()
				.setScopes(PBInquiryScopeOptions.newBuilder().addScope(1))
				.setKeyedTemplateData(
						PBKeyedTemplateData
								.newBuilder()
								.setKeyedReferenece(
										PBKeyedTemplateReference
												.newBuilder()
												.setJobId(1)
												.setKey(TemplateFormatType.TEMPLATE_TLI)));
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder().setPriority(5)
								.setFunction(InquiryFunctionType.TLI))
				.addFusionJobInput(fusionBuilder).build();
		try {
			acceptorValidator.checkInquiryJobRequest(request);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.INQ_KEY_INDEXER.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Inquiry Job (The relationship of TemplateFormatType and PBKeyedTemplateIndexer is not correct)",
					exception.getDescription());
			return;
		}
		fail();

	}

	@Test
	public void testCheckInquiryJobRequest_FunctionTLI_NOCorrect() {
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder().setPriority(5)
								.setFunction(InquiryFunctionType.TLI)).build();
		try {
			acceptorValidator.checkInquiryJobRequest(request);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.INQ_FUSION_LIST.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Inquiry Job(fusionJobInput list is null or empty)",
					exception.getDescription());
			return;
		}
		fail();

	}

	@Test
	public void testCheckInquiryJobRequest_FunctionTLIM_NOFingerPrintType() {
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput.newBuilder()
				.setScopes(PBInquiryScopeOptions.newBuilder().addScope(1))
				.setKeyedTemplateData(PBKeyedTemplateData.newBuilder());
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder().setPriority(5)
								.setFunction(InquiryFunctionType.TLIM))
				.addFusionJobInput(fusionBuilder).build();
		try {
			acceptorValidator.checkInquiryJobRequest(request);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.INQ_TEM_TEMREF.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Inquiry Job (Both PBKeyedTemplate and PBKeyedTemplateReference are not specified)",
					exception.getDescription());
			return;
		}
		fail();

	}

	@Test
	public void testCheckInquiryJobRequest_FunctionTLIM_NOCorrect() {
		PBInquiryScopeOptions.Builder scopeBuilder = PBInquiryScopeOptions
				.newBuilder().addScope(1)
				.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_ROLLED)
				.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_ROLLED);
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder().setPriority(5)
								.setFunction(InquiryFunctionType.TLIM))
				.addFusionJobInput(
						PBFusionJobInput
								.newBuilder()
								.setScopes(scopeBuilder)
								.setKeyedTemplateData(
										PBKeyedTemplateData.newBuilder()))
				.build();
		try {
			acceptorValidator.checkInquiryJobRequest(request);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.INQ_TEM_TEMREF.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Inquiry Job (Both PBKeyedTemplate and PBKeyedTemplateReference are not specified)",
					exception.getDescription());
			return;
		}
		fail();

	}

	@Test
	public void testCheckInquiryJobRequest_FunctionTLIX_NOCorrect() {
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput
				.newBuilder()
				.setScopes(
						PBInquiryScopeOptions
								.newBuilder()
								.addScope(1)
								.addTargetFingerPrint(
										FingerPrintType.FINGER_PRINT_ROLLED))
				.setKeyedTemplateData(
						PBKeyedTemplateData.newBuilder().setKeyedTemplate(
								PBKeyedTemplate.newBuilder().setKey(
										TemplateFormatType.TEMPLATE_TLIX)));
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder().setPriority(5)
								.setFunction(InquiryFunctionType.TLIX))
				.addFusionJobInput(fusionBuilder).build();
		try {
			acceptorValidator.checkInquiryJobRequest(request);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.INQ_BINARY_FORMATTYPE.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Inquiry Job (templateBinary and TemplateFormatType must be specified when PBKeyedTemplate is not null)",
					exception.getDescription());
			return;
		}
		fail();

	}

	@Test
	public void testCheckInquiryJobRequest_NOKeyTemplate_NOKeyedReference() {
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput.newBuilder()
				.setScopes(PBInquiryScopeOptions.newBuilder().addScope(1))
				.setKeyedTemplateData(PBKeyedTemplateData.newBuilder());
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder().setFunction(
								InquiryFunctionType.TLIX))
				.addFusionJobInput(fusionBuilder).build();
		try {
			acceptorValidator.checkInquiryJobRequest(request);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.INQ_TEM_TEMREF.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Inquiry Job (Both PBKeyedTemplate and PBKeyedTemplateReference are not specified)",
					exception.getDescription());
			return;
		}
		fail();
	}

	@Test
	public void testCheckInquiryJobRequest_NOKeyTemplate_HasKeyedReference_jobIdLessThanZero() {
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedReferenece(
						PBKeyedTemplateReference
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_TLIX)
								.setJobId(-1)
								.setIndexer(
										PBKeyedTemplateIndexer.newBuilder()
												.setIndex(1)));
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput.newBuilder()
				.setScopes(PBInquiryScopeOptions.newBuilder().addScope(1))
				.setKeyedTemplateData(templateBuilder);
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder()
								.setFunction(InquiryFunctionType.TLIX)
								.setPriority(5))
				.addFusionJobInput(fusionBuilder).build();
		try {
			acceptorValidator.checkInquiryJobRequest(request);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.INQ_KEY_JOBID.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Inquiry Job (FejobId and TemplateFormatType must be correct when PBKeyedTemplateReference is not null)",
					exception.getDescription());
			return;
		}
		fail();

	}

	@Test
	public void testCheckInquiryJobRequest_WrongFunctionType() {
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedReferenece(
						PBKeyedTemplateReference
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_TLIX)
								.setJobId(-1)
								.setIndexer(
										PBKeyedTemplateIndexer.newBuilder()
												.setIndex(1)));
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput.newBuilder()
				.setScopes(PBInquiryScopeOptions.newBuilder().addScope(1))
				.setKeyedTemplateData(templateBuilder);
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder()
								.setFunction(InquiryFunctionType.TI)
								.setPriority(5))
				.addFusionJobInput(fusionBuilder).build();
		try {
			acceptorValidator.checkInquiryJobRequest(request);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.INQ_KEY_JOBID.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Inquiry Job (FejobId and TemplateFormatType must be correct when PBKeyedTemplateReference is not null)",
					exception.getDescription());
			return;
		}
		fail();

	}

	@Test
	public void testCheckInquiryJobRequest_NoDataExistINFE_RESLUTS() {
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedReferenece(
						PBKeyedTemplateReference.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_TLIX)
								.setJobId(1));
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput.newBuilder()
				.setScopes(PBInquiryScopeOptions.newBuilder().addScope(1))
				.setKeyedTemplateData(templateBuilder);
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder()
								.setFunction(InquiryFunctionType.TLIX)
								.setPriority(5))
				.addFusionJobInput(fusionBuilder).build();
		try {
			acceptorValidator.checkInquiryJobRequest(request);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.INQ_GET_TEMPLATE.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Inquiry Job (Can not fetch template binary with job id and telmplete key)",
					exception.getDescription());
			return;
		}
		fail();
	}

	@Test
	public void testCheckInquiryJobRequest_NoRESULT_DATA() {
		jdbcTemplate
				.update("insert into fe_job_queue(JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,1,123,0)");
		jdbcTemplate
				.update("insert into fe_results(RESULT_ID,JOB_ID,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,1,'TEMPLATE_LIX',0)");
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedReferenece(
						PBKeyedTemplateReference.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_TLIX)
								.setJobId(1));
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput.newBuilder()
				.setScopes(PBInquiryScopeOptions.newBuilder().addScope(1))
				.setKeyedTemplateData(templateBuilder);
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder()
								.setFunction(InquiryFunctionType.TLIX)
								.setPriority(5))
				.addFusionJobInput(fusionBuilder).build();

		try {
			acceptorValidator.checkInquiryJobRequest(request);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.INQ_GET_TEMPLATE.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Inquiry Job (Can not fetch template binary with job id and telmplete key)",
					exception.getDescription());
			return;
		}
		fail();
	}

	@Test
	public void testCheckInquiryJobRequest_WrongTemplateFormatType() {
		jdbcTemplate
				.update("insert into fe_job_queue(JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,1,123,0)");
		jdbcTemplate
				.update("insert into fe_results(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,1,CAST('111' AS BINARY),'TEMPLATE_LIX',0)");
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedReferenece(
						PBKeyedTemplateReference.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_LIX)
								.setJobId(1));
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput.newBuilder()
				.setScopes(PBInquiryScopeOptions.newBuilder().addScope(1))
				.setKeyedTemplateData(templateBuilder);
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder()
								.setFunction(InquiryFunctionType.TLIX)
								.setPriority(5))
				.addFusionJobInput(fusionBuilder).build();
		try {
			acceptorValidator.checkInquiryJobRequest(request);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.INQ_COMBINE_OF_KEY.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Inquiry Job (The combination of functionName, TemplateFormatType, Search Side FingerPrintType and File side FingerPrintType is not correct, Search Key: SearchKey[function=TLIX,templateFmt=TEMPLATE_LIX,sFinPrint=<null>,fFinPrint=<null>])",
					exception.getDescription());
			return;
		}
		fail();

	}

	@Test
	public void testCheckInquiryJobRequest_Normal() {
		jdbcTemplate
				.update("insert into fe_job_queue(JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,1,123,0)");
		jdbcTemplate
				.update("insert into fe_results(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,1,CAST('111' AS BINARY),'TEMPLATE_TLIX',0)");
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedReferenece(
						PBKeyedTemplateReference.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_TLIX)
								.setJobId(1));
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput.newBuilder()
				.setScopes(PBInquiryScopeOptions.newBuilder().addScope(1))
				.setKeyedTemplateData(templateBuilder);
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder()
								.setFunction(InquiryFunctionType.TLIX)
								.setPriority(5))
				.addFusionJobInput(fusionBuilder).build();

		PBInquiryJobRequest.Builder builder = acceptorValidator
				.checkInquiryJobRequest(request);
		Assert.assertEquals(100, builder.build().getFusionJobInput(0)
				.getInquiryOptions().getMinScore());

	}

	@Test
	public void testCheckInquiryJobRequest_ScopeDup() {
		jdbcTemplate
				.update("insert into fe_job_queue(JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,1,123,0)");
		jdbcTemplate
				.update("insert into fe_results(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,1,CAST('111' AS BINARY),'TEMPLATE_TLIX',0)");
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedReferenece(
						PBKeyedTemplateReference.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_TLIX)
								.setJobId(1));
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput
				.newBuilder()
				.setScopes(
						PBInquiryScopeOptions.newBuilder().addScope(1)
								.addScope(1))
				.setKeyedTemplateData(templateBuilder);
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder()
								.setFunction(InquiryFunctionType.TLIX)
								.setPriority(5))
				.addFusionJobInput(fusionBuilder).build();
		try {
			acceptorValidator.checkInquiryJobRequest(request);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			Assert.assertEquals(
					"Inquiry Job (Specified Scope list was duplicate.)",
					e.getMessage());
		}

	}

	@Test
	public void testCheckInquiryJobRequest_Options_MAXCANDIDATES_OUT_RANGE() {
		jdbcTemplate
				.update("insert into fe_job_queue(JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,1,123,0)");
		jdbcTemplate
				.update("insert into fe_results(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,1,CAST('111' AS BINARY),'TEMPLATE_TLIX',0)");
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder()
				.setKeyedReferenece(
						PBKeyedTemplateReference
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_TLIX)
								.setJobId(1)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setFingerPrintType(
														FingerPrintType.FINGER_PRINT_ROLLED)));
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput.newBuilder()
				.setScopes(PBInquiryScopeOptions.newBuilder().addScope(1))
				.setKeyedTemplateData(templateBuilder);
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder()
								.setFunction(InquiryFunctionType.TLIX)
								.setMaxCandidate(999999).setPriority(5))
				.addFusionJobInput(fusionBuilder).build();
		try {
			acceptorValidator.checkInquiryJobRequest(request);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(
					AimError.MAXCANDIDATES_OUT_RANGE.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals("Inquiry Job (MaxCandidates is out of range)",
					exception.getDescription());
			return;
		}
		fail();
	}

	@Test
	public void testCheckInquiryJobRequest_Options_MINSCORE_OUT_RANGE() {
		jdbcTemplate
				.update("insert into fe_job_queue(JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,1,123,0)");
		jdbcTemplate
				.update("insert into fe_results(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,1,CAST('111' AS BINARY),'TEMPLATE_TLIX',0)");
		PBInquiryOptions.Builder inquiryOptions = PBInquiryOptions.newBuilder()
				.setMinScore(-1);
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedReferenece(
						PBKeyedTemplateReference.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_TLIX)
								.setJobId(1));
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput.newBuilder()
				.setInquiryOptions(inquiryOptions)
				.setScopes(PBInquiryScopeOptions.newBuilder().addScope(1))
				.setKeyedTemplateData(templateBuilder);
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder()
								.setFunction(InquiryFunctionType.TLIX)
								.setPriority(5))
				.addFusionJobInput(fusionBuilder).build();

		try {
			acceptorValidator.checkInquiryJobRequest(request);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.MINSCORE_OUT_RANGE.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals("Inquiry Job (MinScore is out of range)",
					exception.getDescription());
			return;
		}
		fail();
	}

	@Test
	public void testCheckInquiryJobRequest_Options_DynThreshPercentagePoint() {
		jdbcTemplate
				.update("insert into fe_job_queue(JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,1,123,0)");
		jdbcTemplate
				.update("insert into fe_results(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,1,CAST('111' AS BINARY),'TEMPLATE_TLIX',0)");
		PBInquiryOptions.Builder inquiryOptions = PBInquiryOptions.newBuilder()
				.setMinScore(-1);
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedReferenece(
						PBKeyedTemplateReference
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_TLIX)
								.setJobId(1)
								.setIndexer(
										PBKeyedTemplateIndexer.newBuilder()
												.setIndex(1)));
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput.newBuilder()
				.setInquiryOptions(inquiryOptions)
				.setScopes(PBInquiryScopeOptions.newBuilder().addScope(1))
				.setKeyedTemplateData(templateBuilder);
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder()
								.setFunction(InquiryFunctionType.TLIX)
								.setPriority(5)
								.setDynThreshPercentagePoint(1111.5f))
				.addFusionJobInput(fusionBuilder).build();

		try {
			acceptorValidator.checkInquiryJobRequest(request);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.DYPOINT_OUT_RANGE.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Inquiry Job (DynThreshPercentagePoint is out of range)",
					exception.getDescription());
			return;
		}
		fail();
	}

	@Test
	public void testCheckInquiryJobRequest_Options_DynThreshHitThresholdOutOfRange() {
		jdbcTemplate
				.update("insert into fe_job_queue(JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,1,123,0)");
		jdbcTemplate
				.update("insert into fe_results(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,1,CAST('111' AS BINARY),'TEMPLATE_TLIX',0)");
		PBInquiryOptions.Builder inquiryOptions = PBInquiryOptions.newBuilder()
				.setMinScore(-1);
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedReferenece(
						PBKeyedTemplateReference
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_TLIX)
								.setJobId(1)
								.setIndexer(
										PBKeyedTemplateIndexer.newBuilder()
												.setIndex(1)));
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput.newBuilder()
				.setInquiryOptions(inquiryOptions)
				.setScopes(PBInquiryScopeOptions.newBuilder().addScope(1))
				.setKeyedTemplateData(templateBuilder);
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder()
								.setFunction(InquiryFunctionType.TLIX)
								.setPriority(5).setMaxCandidate(244)
								.setDynThreshPercentagePoint(55.5f)
								.setDynThreshHitThreshold(99999))
				.addFusionJobInput(fusionBuilder).build();

		try {
			acceptorValidator.checkInquiryJobRequest(request);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.DYHIT_OUT_RANGE.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Inquiry Job (DynThreshHitThreshold is out of range)",
					exception.getDescription());
			return;
		}
		fail();
	}

	@Test
	public void testCheckInquiryJobRequest_Options_FusionWeight() {
		jdbcTemplate
				.update("insert into fe_job_queue(JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,1,123,0)");
		jdbcTemplate
				.update("insert into fe_results(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,1,CAST('111' AS BINARY),'TEMPLATE_TI',1)");
		PBInquiryOptions.Builder inquiryOptions = PBInquiryOptions.newBuilder()
				.setMinScore(1);
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder()
				.setKeyedReferenece(
						PBKeyedTemplateReference
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_TI)
								.setJobId(1)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setFingerPrintType(
														FingerPrintType.FINGER_PRINT_ROLLED)));
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput
				.newBuilder()
				.setInquiryOptions(inquiryOptions)
				.setScopes(
						PBInquiryScopeOptions
								.newBuilder()
								.addScope(1)
								.addTargetFingerPrint(
										FingerPrintType.FINGER_PRINT_ROLLED)
								.addTargetFingerPrint(
										FingerPrintType.FINGER_PRINT_SLAP))
				.setKeyedTemplateData(templateBuilder);
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder()
								.setFunction(InquiryFunctionType.TI)
								.setPriority(5).setMaxCandidate(244)
								.setDynThreshPercentagePoint(55.5f)
								.setDynThreshHitThreshold(99))
				.addFusionJobInput(fusionBuilder).build();
		try {
			acceptorValidator.checkInquiryJobRequest(request);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.INQ_FUSION_WEIGHT.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals("Inquiry Service (Fusion weight is incorrect)",
					exception.getDescription());
			return;
		}
		// fail();
	}

	@Test
	public void testCheckInquiryJobRequest_Options_FusionWeight_WrongInder() {
		jdbcTemplate
				.update("insert into fe_job_queue(JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,1,123,0)");
		jdbcTemplate
				.update("insert into fe_results(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,1,CAST('111' AS BINARY),'TEMPLATE_TI',1)");
		PBInquiryOptions.Builder inquiryOptions = PBInquiryOptions.newBuilder()
				.setMinScore(1);
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedReferenece(
						PBKeyedTemplateReference
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_TI)
								.setJobId(1)
								.setIndexer(
										PBKeyedTemplateIndexer.newBuilder()
												.setIndex(1)));
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput
				.newBuilder()
				.setInquiryOptions(inquiryOptions)
				.setScopes(
						PBInquiryScopeOptions
								.newBuilder()
								.addScope(1)
								.addTargetFingerPrint(
										FingerPrintType.FINGER_PRINT_ROLLED)
								.addTargetFingerPrint(
										FingerPrintType.FINGER_PRINT_SLAP))
				.setKeyedTemplateData(templateBuilder);
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder()
								.setFunction(InquiryFunctionType.TI)
								.setPriority(5).setMaxCandidate(244)
								.setDynThreshPercentagePoint(55.5f)
								.setDynThreshHitThreshold(99))
				.addFusionJobInput(fusionBuilder).build();
		try {
			acceptorValidator.checkInquiryJobRequest(request);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.INQ_KEY_INDEXER.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Inquiry Job (The relationship of TemplateFormatType and PBKeyedTemplateIndexer is not correct)",
					exception.getDescription());
			return;
		}
		fail();
	}

	@Test
	public void testCheckInquiryJobRequest_Options_FusionWeightLess() {
		jdbcTemplate
				.update("insert into fe_job_queue(JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,1,123,0)");
		jdbcTemplate
				.update("insert into fe_results(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,1,CAST('111' AS BINARY),'TEMPLATE_TI',1)");
		PBInquiryOptions.Builder inquiryOptions = PBInquiryOptions
				.newBuilder()
				.setMinScore(1)
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.PC2_ROLLED)
								.setWeight(100));
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder()
				.setKeyedReferenece(
						PBKeyedTemplateReference
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_TI)
								.setJobId(1)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setFingerPrintType(
														FingerPrintType.FINGER_PRINT_ROLLED)));
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput
				.newBuilder()
				.setInquiryOptions(inquiryOptions)
				.setScopes(
						PBInquiryScopeOptions
								.newBuilder()
								.addScope(1)
								.addTargetFingerPrint(
										FingerPrintType.FINGER_PRINT_ROLLED)
								.addTargetFingerPrint(
										FingerPrintType.FINGER_PRINT_SLAP))
				.setKeyedTemplateData(templateBuilder);
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder()
								.setFunction(InquiryFunctionType.TI)
								.setPriority(5).setMaxCandidate(244)
								.setDynThreshPercentagePoint(55.5f)
								.setDynThreshHitThreshold(99))
				.addFusionJobInput(fusionBuilder).build();
		acceptorValidator.checkInquiryJobRequest(request);
	}

	@Test
	public void testCheckInquiryJobRequest_Options_FusionWeight_Normal() {
		jdbcTemplate
				.update("insert into fe_job_queue(JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,1,123,0)");
		jdbcTemplate
				.update("insert into fe_results(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,1,CAST('111' AS BINARY),'TEMPLATE_TI',1)");
		PBInquiryOptions.Builder inquiryOptions = PBInquiryOptions
				.newBuilder()
				.setMinScore(1)
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.PC2_ROLLED)
								.setWeight(100));
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder()
				.setKeyedReferenece(
						PBKeyedTemplateReference
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_TI)
								.setJobId(1)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setFingerPrintType(
														FingerPrintType.FINGER_PRINT_ROLLED)));
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput
				.newBuilder()
				.setInquiryOptions(inquiryOptions)
				.setScopes(
						PBInquiryScopeOptions
								.newBuilder()
								.addScope(1)
								.addTargetFingerPrint(
										FingerPrintType.FINGER_PRINT_ROLLED)
								.addTargetFingerPrint(
										FingerPrintType.FINGER_PRINT_SLAP))
				.setKeyedTemplateData(templateBuilder);
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder()
								.setFunction(InquiryFunctionType.TI)
								.setPriority(5).setMaxCandidate(244)
								.setDynThreshPercentagePoint(55.5f)
								.setDynThreshHitThreshold(99))
				.addFusionJobInput(fusionBuilder).build();
		acceptorValidator.checkInquiryJobRequest(request);

	}

	@Test
	public void testCheckInquiryJobRequest_Options_FusionWeightMore() {
		jdbcTemplate
				.update("insert into fe_job_queue(JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,1,123,0)");
		jdbcTemplate
				.update("insert into fe_results(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,1,CAST('111' AS BINARY),'TEMPLATE_TI',1)");
		PBInquiryOptions.Builder inquiryOptions = PBInquiryOptions
				.newBuilder()
				.setMinScore(1)
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.PC2_ROLLED)
								.setWeight(100))
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.PC2_ROLLED)
								.setWeight(100));
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder()
				.setKeyedReferenece(
						PBKeyedTemplateReference
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_TI)
								.setJobId(1)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setFingerPrintType(
														FingerPrintType.FINGER_PRINT_ROLLED)));
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput
				.newBuilder()
				.setInquiryOptions(inquiryOptions)
				.setScopes(
						PBInquiryScopeOptions
								.newBuilder()
								.addScope(1)
								.addTargetFingerPrint(
										FingerPrintType.FINGER_PRINT_ROLLED)
								.addTargetFingerPrint(
										FingerPrintType.FINGER_PRINT_SLAP))
				.setKeyedTemplateData(templateBuilder);
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder()
								.setFunction(InquiryFunctionType.TI)
								.setPriority(5).setMaxCandidate(244)
								.setDynThreshPercentagePoint(55.5f)
								.setDynThreshHitThreshold(99))
				.addFusionJobInput(fusionBuilder).build();
		try {
			acceptorValidator.checkInquiryJobRequest(request);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(
					AimError.INQ_FUSION_WEIGHT_DUPLICATE.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Inquiry Service (Fusion weight is duplicate.)",
					exception.getDescription());
			return;
		}
		fail();

	}

	@Test
	public void testCheckInquiryJobRequest_Options_FusionWeightWrong() {
		jdbcTemplate
				.update("insert into fe_job_queue(JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,1,123,0)");
		jdbcTemplate
				.update("insert into fe_results(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,1,CAST('111' AS BINARY),'TEMPLATE_TI',1)");
		PBInquiryOptions.Builder inquiryOptions = PBInquiryOptions
				.newBuilder()
				.setMinScore(1)
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.PC2_ROLLED)
								.setWeight(100))
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.FMP5_SLAP)
								.setWeight(100));
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder()
				.setKeyedReferenece(
						PBKeyedTemplateReference
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_TI)
								.setJobId(1)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setFingerPrintType(
														FingerPrintType.FINGER_PRINT_ROLLED)));
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput
				.newBuilder()
				.setInquiryOptions(inquiryOptions)
				.setScopes(
						PBInquiryScopeOptions
								.newBuilder()
								.addScope(1)
								.addTargetFingerPrint(
										FingerPrintType.FINGER_PRINT_ROLLED)
								.addTargetFingerPrint(
										FingerPrintType.FINGER_PRINT_SLAP))
				.setKeyedTemplateData(templateBuilder);
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder()
								.setFunction(InquiryFunctionType.TI)
								.setPriority(5).setMaxCandidate(244)
								.setDynThreshPercentagePoint(55.5f)
								.setDynThreshHitThreshold(99))
				.addFusionJobInput(fusionBuilder).build();
		try {
			acceptorValidator.checkInquiryJobRequest(request);

		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.INQ_FUSION_WEIGHT.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals("Inquiry Service (Fusion weight is incorrect)",
					exception.getDescription());
			return;
		}
		fail();

	}

	@Test
	public void testCheckInquiryJobRequest_Options_TLI_normalLess() {
		jdbcTemplate
				.update("insert into fe_job_queue(JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,1,123,0)");
		jdbcTemplate
				.update("insert into fe_results(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,1,CAST('111' AS BINARY),'TEMPLATE_TLI',1)");
		PBInquiryOptions.Builder inquiryOptions = PBInquiryOptions.newBuilder()
				.setMinScore(1);
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder()
				.setKeyedReferenece(
						PBKeyedTemplateReference
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_TLI)
								.setJobId(1)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setFingerPrintType(
														FingerPrintType.FINGER_PRINT_ROLLED)));
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput.newBuilder()
				.setInquiryOptions(inquiryOptions)
				.setScopes(PBInquiryScopeOptions.newBuilder().addScope(1))
				.setKeyedTemplateData(templateBuilder);
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder()
								.setFunction(InquiryFunctionType.TLI)
								.setPriority(5).setMaxCandidate(244)
								.setDynThreshPercentagePoint(55.5f)
								.setDynThreshHitThreshold(99))
				.addFusionJobInput(fusionBuilder).build();
		acceptorValidator.checkInquiryJobRequest(request);
	}

	@Test
	public void testCheckInquiryJobRequest_Options_TLI_normal() {
		jdbcTemplate
				.update("insert into fe_job_queue(JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,1,123,0)");
		jdbcTemplate
				.update("insert into fe_results(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,1,CAST('111' AS BINARY),'TEMPLATE_TLI',1)");

		PBInquiryOptions.Builder inquiryOptions = PBInquiryOptions
				.newBuilder()
				.setMinScore(1)
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.FMP5_ROLLED)
								.setWeight(100));
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder()
				.setKeyedReferenece(
						PBKeyedTemplateReference
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_TLI)
								.setJobId(1)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setFingerPrintType(
														FingerPrintType.FINGER_PRINT_ROLLED)));
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput.newBuilder()
				.setInquiryOptions(inquiryOptions)
				.setScopes(PBInquiryScopeOptions.newBuilder().addScope(1))
				.setKeyedTemplateData(templateBuilder);
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder()
								.setFunction(InquiryFunctionType.TLI)
								.setPriority(5).setMaxCandidate(244)
								.setDynThreshPercentagePoint(55.5f)
								.setDynThreshHitThreshold(99))
				.addFusionJobInput(fusionBuilder).build();
		acceptorValidator.checkInquiryJobRequest(request);
	}

	@Test
	public void testcheckSyncJobRequest() {
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setExternalId("1")
				.setEventId(1).build();
		try {
			acceptorValidator.checkSyncJobRequest(syncJobRequest);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.SYNC_IN_INSERT_PAYLOAD.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Sync Job (InsertPayload is not specified when function type is insert)",
					e.getMessage());
			return;
		}
		fail();

	}

	@Test
	public void testcheckSyncJobRequestINSERTNULL() {
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setExternalId("1")
				.setEventId(1)
				.setDeletePayload(PBSyncDeletePayload.newBuilder()).build();
		try {

			System.out.print(syncJobRequest.getInsertPayload().getScope());
			acceptorValidator.checkSyncJobRequest(syncJobRequest);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.SYNC_IN_INSERT_PAYLOAD.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Sync Job (InsertPayload is not specified when function type is insert)",
					exception.getDescription());
			return;
		}
		fail();

	}

	@Test
	public void testcheckSyncJobRequestINSERTKeyTemplateDataNULL() {
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.INSERT).setExternalId("1")
				.setEventId(1)
				.setInsertPayload(PBSyncInsertPayload.newBuilder().setScope(1))
				.build();
		try {

			System.out.print(syncJobRequest.getInsertPayload().getScope());
			acceptorValidator.checkSyncJobRequest(syncJobRequest);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.SYNC_TEM_DATA_EMPTY.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Sync Job (keyedTemplateData list size is empty  when function type is insert)",
					exception.getDescription());
			return;
		}
		fail();

	}

	@Test
	public void testcheckSyncJobRequestINSERTPBKeyTemplateAndPBKeyedTemplateReferenceNull() {
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest
				.newBuilder()
				.setFunction(SyncFunctionType.INSERT)
				.setExternalId("1")
				.setEventId(1)
				.setInsertPayload(
						PBSyncInsertPayload
								.newBuilder()
								.setScope(1)
								.addKeyedTemplateData(0,
										PBKeyedTemplateData.newBuilder()))
				.build();
		try {

			System.out.print(syncJobRequest.getInsertPayload().getScope());
			acceptorValidator.checkSyncJobRequest(syncJobRequest);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.SYNC_TEM_TEMREF.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Sync Job (Both PBKeyedTemplate and PBKeyedTemplateReference are not specified  when function type is insert)",
					exception.getDescription());
			return;
		}
		fail();

	}

	/*
	 * @Test public void
	 * testcheckSyncJobRequestINSERTAndPBKeyedTemplateReferenceNull() {
	 * PBSyncJobRequest syncJobRequest = PBSyncJobRequest .newBuilder()
	 * .setFunction(SyncFunctionType.INSERT) .setExternalId("1") .setEventId(1)
	 * .setInsertPayload( PBSyncInsertPayload .newBuilder() .setScope(1)
	 * .addKeyedTemplateData( 0, PBKeyedTemplateData.newBuilder()
	 * .setKeyedReferenece( PBKeyedTemplateReference .newBuilder()))) .build();
	 * try {
	 * 
	 * System.out.print(syncJobRequest.getInsertPayload().getScope());
	 * acceptorValidator.checkSyncJobRequest(syncJobRequest);
	 * 
	 * } catch (Exception e) { // TODO: handle exception Assert.assertTrue(e
	 * instanceof IllegalArgumentException); Assert.assertEquals(
	 * "Sync Job (Both PBKeyedTemplate and PBKeyedTemplateReference are not specified  when function type is insert)"
	 * , e.getMessage()); }
	 * 
	 * }
	 */

	@Test
	public void testcheckSyncJobRequestINSERTAndTemplateFormatTypeNull() {
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest
				.newBuilder()
				.setFunction(SyncFunctionType.INSERT)
				.setExternalId("1")
				.setEventId(1)
				.setInsertPayload(
						PBSyncInsertPayload
								.newBuilder()
								.setScope(1)
								.addKeyedTemplateData(
										0,
										PBKeyedTemplateData.newBuilder()
												.setKeyedTemplate(
														PBKeyedTemplate
																.newBuilder())))
				.build();
		try {

			System.out.print(syncJobRequest.getInsertPayload().getScope());
			acceptorValidator.checkSyncJobRequest(syncJobRequest);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.SYNC_BINARY_FORMATTYPE.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Sync Job (templateBinary and TemplateFormatType must be specified when PBKeyedTemplate is not null)",
					e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void testCheckInquiryJobRequest_Options_LI() {
		jdbcTemplate
				.update("insert into fe_job_queue(JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,1,123,0)");
		jdbcTemplate
				.update("insert into fe_results(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,1,CAST('111' AS BINARY),'TEMPLATE_LI',0)");
		PBInquiryOptions.Builder inquiryOptions = PBInquiryOptions
				.newBuilder()
				.setMinScore(1)
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.PC2_ROLLED)
								.setWeight(100))
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.FMP5_SLAP)
								.setWeight(100))
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.PC2_SLAP)
								.setWeight(100))
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.FMP5_ROLLED)
								.setWeight(100));
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedReferenece(
						PBKeyedTemplateReference.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_LI)
								.setJobId(1));
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput
				.newBuilder()
				.setInquiryOptions(inquiryOptions)
				.setScopes(
						PBInquiryScopeOptions
								.newBuilder()
								.addScope(1)
								.addTargetFingerPrint(
										FingerPrintType.FINGER_PRINT_ROLLED))
				.setKeyedTemplateData(templateBuilder);
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder()
								.setFunction(InquiryFunctionType.LI)
								.setPriority(5).setMaxCandidate(244)
								.setDynThreshPercentagePoint(55.5f)
								.setDynThreshHitThreshold(99))
				.addFusionJobInput(fusionBuilder).build();

		try {
			acceptorValidator.checkInquiryJobRequest(request);

		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.INQ_FUSION_WEIGHT.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals("Inquiry Service (Fusion weight is incorrect)",
					exception.getDescription());
			return;
		}
		fail();

	}

	@Test
	public void testCheckInquiryJobRequest_Options_LI_normal() {
		jdbcTemplate
				.update("insert into fe_job_queue(JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,1,123,0)");
		jdbcTemplate
				.update("insert into fe_results(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,1,CAST('111' AS BINARY),'TEMPLATE_LI',0)");
		PBInquiryOptions.Builder inquiryOptions = PBInquiryOptions
				.newBuilder()
				.setMinScore(1)
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.FMP5_LATENT)
								.setWeight(100));
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedReferenece(
						PBKeyedTemplateReference.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_LI)
								.setJobId(1));
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput
				.newBuilder()
				.setInquiryOptions(inquiryOptions)
				.setScopes(
						PBInquiryScopeOptions
								.newBuilder()
								.addScope(1)
								.addTargetFingerPrint(
										FingerPrintType.FINGER_PRINT_ROLLED))
				.setKeyedTemplateData(templateBuilder);
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder()
								.setFunction(InquiryFunctionType.LI)
								.setPriority(5).setMaxCandidate(244)
								.setDynThreshPercentagePoint(55.5f)
								.setDynThreshHitThreshold(99))
				.addFusionJobInput(fusionBuilder).build();

		acceptorValidator.checkInquiryJobRequest(request);

	}

	@Test
	public void testCheckInquiryJobRequest_Options_LIS() {
		jdbcTemplate
				.update("insert into fe_job_queue(JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,1,123,0)");
		jdbcTemplate
				.update("insert into fe_results(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,1,CAST('111' AS BINARY),'TEMPLATE_LIS',0)");
		PBInquiryOptions.Builder inquiryOptions = PBInquiryOptions
				.newBuilder()
				.setMinScore(1)
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.PC2_ROLLED)
								.setWeight(100))
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.FMP5_SLAP)
								.setWeight(100))
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.PC2_SLAP)
								.setWeight(100))
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.FMP5_ROLLED)
								.setWeight(100));
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedReferenece(
						PBKeyedTemplateReference.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_LIS)
								.setJobId(1));
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput
				.newBuilder()
				.setInquiryOptions(inquiryOptions)
				.setScopes(
						PBInquiryScopeOptions
								.newBuilder()
								.addScope(1)
								.addTargetFingerPrint(
										FingerPrintType.FINGER_PRINT_ROLLED))
				.setKeyedTemplateData(templateBuilder);
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder()
								.setFunction(InquiryFunctionType.LI)
								.setPriority(5).setMaxCandidate(244)
								.setDynThreshPercentagePoint(55.5f)
								.setDynThreshHitThreshold(99))
				.addFusionJobInput(fusionBuilder).build();

		try {
			acceptorValidator.checkInquiryJobRequest(request);

		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.INQ_FUSION_WEIGHT.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals("Inquiry Service (Fusion weight is incorrect)",
					exception.getDescription());
			return;
		}
		fail();

	}

	@Test
	public void testCheckInquiryJobRequest_Options_LLI() {
		jdbcTemplate
				.update("insert into fe_job_queue(JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,1,123,0)");
		jdbcTemplate
				.update("insert into fe_results(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,1,CAST('111' AS BINARY),'TEMPLATE_LLI',0)");

		PBInquiryOptions.Builder inquiryOptions = PBInquiryOptions
				.newBuilder()
				.setMinScore(1)
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.PC2_LATENT)
								.setWeight(100))
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.PC2_ROLLED)
								.setWeight(100));
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedReferenece(
						PBKeyedTemplateReference
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_LLI)
								.setJobId(1)
								.setIndexer(
										PBKeyedTemplateIndexer.newBuilder()
												.setIndex(1)));
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput.newBuilder()
				.setInquiryOptions(inquiryOptions)
				.setScopes(PBInquiryScopeOptions.newBuilder().addScope(1))
				.setKeyedTemplateData(templateBuilder);
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder()
								.setFunction(InquiryFunctionType.LLI)
								.setPriority(5).setMaxCandidate(244)
								.setDynThreshPercentagePoint(55.5f)
								.setDynThreshHitThreshold(99))
				.addFusionJobInput(fusionBuilder).build();
		try {
			acceptorValidator.checkInquiryJobRequest(request);

		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.INQ_KEY_INDEXER.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Inquiry Job (The relationship of TemplateFormatType and PBKeyedTemplateIndexer is not correct)",
					exception.getDescription());
			return;
		}
		fail();
	}

	@Test
	public void testCheckInquiryJobRequest_Options_LLI_normal() {
		jdbcTemplate
				.update("insert into fe_job_queue(JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,1,123,0)");
		jdbcTemplate
				.update("insert into fe_results(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,1,CAST('111' AS BINARY),'TEMPLATE_LLI',0)");
		PBInquiryOptions.Builder inquiryOptions = PBInquiryOptions
				.newBuilder()
				.setMinScore(1)
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.PC2_ROLLED)
								.setWeight(100))
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.FMP5_SLAP)
								.setWeight(100));
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedReferenece(
						PBKeyedTemplateReference.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_LLI)
								.setJobId(1));
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput.newBuilder()
				.setInquiryOptions(inquiryOptions)
				.setScopes(PBInquiryScopeOptions.newBuilder().addScope(1))
				.setKeyedTemplateData(templateBuilder);
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder()
								.setFunction(InquiryFunctionType.LLI)
								.setPriority(5).setMaxCandidate(244)
								.setDynThreshPercentagePoint(55.5f)
								.setDynThreshHitThreshold(99))
				.addFusionJobInput(fusionBuilder).build();

		try {
			acceptorValidator.checkInquiryJobRequest(request);

		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.INQ_FUSION_WEIGHT.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals("Inquiry Service (Fusion weight is incorrect)",
					exception.getDescription());
			return;
		}
		fail();

	}

	@Test
	public void testCheckInquiryJobRequest_Options_LIP_FusionWeightWrong() {
		jdbcTemplate
				.update("insert into fe_job_queue(JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,1,123,0)");
		jdbcTemplate
				.update("insert into fe_results(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,1,CAST('111' AS BINARY),'TEMPLATE_LIP',0)");
		PBInquiryOptions.Builder inquiryOptions = PBInquiryOptions
				.newBuilder()
				.setMinScore(1)
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.PC2_ROLLED)
								.setWeight(100))
				.addFusionWeight(
						PBInquiryFusionWeight.newBuilder()
								.setInquirySet(FingerSetType.FMP5_SLAP)
								.setWeight(100));
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedReferenece(
						PBKeyedTemplateReference.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_LIP)
								.setJobId(1));
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput.newBuilder()
				.setInquiryOptions(inquiryOptions)
				.setScopes(PBInquiryScopeOptions.newBuilder().addScope(1))
				.setKeyedTemplateData(templateBuilder);
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder()
								.setFunction(InquiryFunctionType.LIP)
								.setPriority(5).setMaxCandidate(244)
								.setDynThreshPercentagePoint(55.5f)
								.setDynThreshHitThreshold(99))
				.addFusionJobInput(fusionBuilder).build();

		try {
			acceptorValidator.checkInquiryJobRequest(request);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.INQ_FUSION_WEIGHT.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals("Inquiry Service (Fusion weight is incorrect)",
					exception.getDescription());
			return;
		}
		fail();
	}

	@Test
	public void testCheckInquiryJobRequest_Options_LIP_normal() {
		jdbcTemplate
				.update("insert into fe_job_queue(JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,1,123,0)");
		jdbcTemplate
				.update("insert into fe_results(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,1,CAST('111' AS BINARY),'TEMPLATE_LIP',0)");
		PBInquiryOptions.Builder inquiryOptions = PBInquiryOptions.newBuilder()
				.setMinScore(1);
		PBKeyedTemplateData.Builder templateBuilder = PBKeyedTemplateData
				.newBuilder().setKeyedReferenece(
						PBKeyedTemplateReference.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_LIP)
								.setJobId(1));
		PBFusionJobInput.Builder fusionBuilder = PBFusionJobInput.newBuilder()
				.setInquiryOptions(inquiryOptions)
				.setScopes(PBInquiryScopeOptions.newBuilder().addScope(1))
				.setKeyedTemplateData(templateBuilder);
		PBInquiryJobRequest request = PBInquiryJobRequest
				.newBuilder()
				.setJobInfo(
						PBInquiryJobInfo.newBuilder()
								.setFunction(InquiryFunctionType.LIP)
								.setPriority(5).setMaxCandidate(244)
								.setDynThreshPercentagePoint(55.5f)
								.setDynThreshHitThreshold(99))
				.addFusionJobInput(fusionBuilder).build();

		PBInquiryJobRequest.Builder builder = acceptorValidator
				.checkInquiryJobRequest(request);
		PBInquiryJobRequest request2 = builder.build();
		Assert.assertEquals(InquiryFunctionType.LIP, request2.getJobInfo()
				.getFunction());
		Assert.assertEquals(5, request2.getJobInfo().getPriority());
		Assert.assertEquals(244, request2.getJobInfo().getMaxCandidate());
		Assert.assertEquals(99, request2.getJobInfo()
				.getDynThreshHitThreshold());

	}

	@Test
	public void testcheckSyncJobRequestDeleteAndKeyNull() {
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest
				.newBuilder()
				.setFunction(SyncFunctionType.DELETE)
				.setExternalId("1")
				.setEventId(1)
				.setDeletePayload(
						PBSyncDeletePayload
								.newBuilder()
								.addScopes(1)
								.addKeyedTemplate(0,
										PBKeyedTemplate.newBuilder())).build();
		try {

			System.out.print(syncJobRequest.getInsertPayload().getScope());
			acceptorValidator.checkSyncJobRequest(syncJobRequest);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.SYNC_FORMATTYPE.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Sync Job (TemplateFormatType is not specified when deletePayload,PBKeyedTemplate is not null)",
					e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void testcheckSyncJobRequestDeleteAndScopeDup() {
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest
				.newBuilder()
				.setFunction(SyncFunctionType.DELETE)
				.setExternalId("1")
				.setEventId(1)
				.setDeletePayload(
						PBSyncDeletePayload
								.newBuilder()
								.addScopes(1)
								.addScopes(1)
								.addKeyedTemplate(
										0,
										PBKeyedTemplate
												.newBuilder()
												.setKey(TemplateFormatType.TEMPLATE_RDBT)
												.setIndexer(
														PBKeyedTemplateIndexer
																.newBuilder()
																.setFingerPrintType(
																		FingerPrintType.FINGER_PRINT_ROLLED))))
				.build();
		try {

			System.out.print(syncJobRequest.getInsertPayload().getScope());
			acceptorValidator.checkSyncJobRequest(syncJobRequest);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(AimError.SYNC_OPEOPTIONS_SCOPE.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Sync Job (Specified Scope list in deletePayload was duplicate.)",
					e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void testcheckSyncJobRequestDeleteAndIndexerNull() {
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest
				.newBuilder()
				.setFunction(SyncFunctionType.DELETE)
				.setExternalId("1")
				.setEventId(1)
				.setDeletePayload(
						PBSyncDeletePayload
								.newBuilder()
								.addScopes(1)
								.addKeyedTemplate(
										PBKeyedTemplate
												.newBuilder()
												.setKey(TemplateFormatType.TEMPLATE_RDBL)
												.setIndexer(
														PBKeyedTemplateIndexer
																.newBuilder())))
				.build();
		try {

			acceptorValidator.checkSyncJobRequest(syncJobRequest);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			Assert.assertEquals(
					"Sync Job (Both position, fingerPrintType and index are not specified when deletePayload,keyedTemplate,indexer is not null)",
					e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void testcheckSyncJobRequestDeleteAndFINGER_PRINT_ROLLED() {
		PBSyncJobRequest syncJobRequest = PBSyncJobRequest
				.newBuilder()
				.setFunction(SyncFunctionType.DELETE)
				.setExternalId("1")
				.setEventId(1)
				.setDeletePayload(
						PBSyncDeletePayload
								.newBuilder()
								.addScopes(1)
								.addKeyedTemplate(
										PBKeyedTemplate
												.newBuilder()
												.setKey(TemplateFormatType.TEMPLATE_PDB)
												.setIndexer(
														PBKeyedTemplateIndexer
																.newBuilder()
																.setFingerPrintType(
																		FingerPrintType.FINGER_PRINT_ROLLED))))
				.build();
		try {

			acceptorValidator.checkSyncJobRequest(syncJobRequest);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			Assert.assertEquals(
					"Sync Job (fingerPrintType can not be specified)",
					e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void testvalidatePriorityIsLessThanMin() {
		jdbcTemplate
				.update("insert into SYSTEM_CONFIG(CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)values(SYSTEM_CONFIG_SEQ.nextval,'SEARCH.LIMITS.PRIORITY.MIN',1)");
		jdbcTemplate
				.update("insert into SYSTEM_CONFIG(CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)values(SYSTEM_CONFIG_SEQ.nextval,'SEARCH.LIMITS.PRIORITY.MAX',9)");
		jdbcTemplate.execute("commit");
		try {
			acceptorValidator.validate(0);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(
					AimError.EXTRACT_PRIORITY_OUT_RANGE.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals("Extraction Job (Priority is out of range)",
					e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void testCheckSyncJobRequest_update_hasDelete() {
		byte[] bytes = { 1, 2, 3 };
		PBSyncInsertPayload insertPayload = PBSyncInsertPayload
				.newBuilder()
				.addKeyedTemplateData(
						PBKeyedTemplateData
								.newBuilder()
								.setKeyedTemplate(
										PBKeyedTemplate
												.newBuilder()
												.setKey(TemplateFormatType.TEMPLATE_RDBT)
												.setTemplateBinary(
														ByteString
																.copyFrom(bytes))
												.setIndexer(
														PBKeyedTemplateIndexer
																.newBuilder()
																.setFingerPrintType(
																		FingerPrintType.FINGER_PRINT_ROLLED))))
				.build();
		PBSyncDeletePayload deletePayload = PBSyncDeletePayload
				.newBuilder()
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_RDBT)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setFingerPrintType(
														FingerPrintType.FINGER_PRINT_ROLLED)))
				.build();
		PBSyncJobRequest request = PBSyncJobRequest.newBuilder()
				.setFunction(SyncFunctionType.UPDATE).setEventId(1)
				.setExternalId("1").setInsertPayload(insertPayload)
				.setDeletePayload(deletePayload).build();
		acceptorValidator.checkSyncJobRequest(request);
	}

	@Test
	public void testvalidatePriorityIsBiggerThanMax() {
		jdbcTemplate
				.update("insert into SYSTEM_CONFIG(CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)values(SYSTEM_CONFIG_SEQ.nextval,'SEARCH.LIMITS.PRIORITY.MIN',1)");
		jdbcTemplate
				.update("insert into SYSTEM_CONFIG(CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)values(SYSTEM_CONFIG_SEQ.nextval,'SEARCH.LIMITS.PRIORITY.MAX',9)");
		jdbcTemplate.execute("commit");
		try {
			acceptorValidator.validate(10);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(
					AimError.EXTRACT_PRIORITY_OUT_RANGE.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals("Extraction Job (Priority is out of range)",
					e.getMessage());
			return;
		}
		fail();

	}

	@Test
	public void testvalidatePriority() {
		jdbcTemplate
				.update("insert into SYSTEM_CONFIG(CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)values(SYSTEM_CONFIG_SEQ.nextval,'SEARCH.LIMITS.PRIORITY.MIN',1)");
		jdbcTemplate
				.update("insert into SYSTEM_CONFIG(CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)values(SYSTEM_CONFIG_SEQ.nextval,'SEARCH.LIMITS.PRIORITY.MAX',9)");
		jdbcTemplate.execute("commit");

		acceptorValidator.validate(4);

	}

}
