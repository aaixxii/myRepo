package jp.co.nec.aim.mm.acceptor.service;

import static org.junit.Assert.fail;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.AIMMessages.PBExtractJobResultInternal;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPrintType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ImageFormatType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ImagePositionType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.JobStateType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.TemplateFormatType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplate;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateIndexer;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FaceExtractProcessType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FisTypeType;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBAimFormat;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractFaceInput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractFeType;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractFeTypeEvent;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputImage;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputPayload;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractIrisOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractLatentInput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractOutputPayload;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractTenprintInput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractTenprintOutput;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobBinaryRequest;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobBinaryResponse;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobRequest;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobResponse;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobResult;
import jp.co.nec.aim.message.proto.JobCommonService.PBDeleteJobRequest;
import jp.co.nec.aim.message.proto.JobCommonService.PBJobResultRequest;
import jp.co.nec.aim.message.proto.JobCommonService.PBJobStatusRequest;
import jp.co.nec.aim.message.proto.JobCommonService.PBJobStatusResponse;
import jp.co.nec.aim.message.proto.JobCommonService.PBListJobIdsResponse;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.dao.FEJobDao;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.exception.ArgumentException;
import jp.co.nec.aim.mm.exception.DataBaseException;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.util.Deflater;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.google.protobuf.ByteString;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()
@Transactional
public class AimExtractServiceTest extends
		AbstractTransactionalJUnit4SpringContextTests {
	@Resource
	private DataSource dataSource;
	@Resource
	private AimExtractService aimExtractService;
	@Resource
	private JdbcTemplate jdbcTemplate;

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;

	@Before
	public void setUp() {
		jdbcTemplate.update("delete from FE_JOB_QUEUE");
		jdbcTemplate.update("delete from FE_JOB_PAYLOADS");
		jdbcTemplate.update("delete from FE_RESULTS");
		jdbcTemplate.execute("commit");
		setMockMethod();
	}

	@After
	public void tearDown() {
		jdbcTemplate.update("delete from FE_JOB_QUEUE");
		jdbcTemplate.update("delete from FE_JOB_PAYLOADS");
		jdbcTemplate.update("delete from FE_RESULTS");
		jdbcTemplate.execute("commit");		
	}

	private void setMockMethod() {
		new MockUp<JmsSender>() {
			@Mock
			private void convertAndSend(String queueName, Object object) {
				return;
			}
		};
	}

	@Test
	public void testExtractisFromServletPriIsBiggerThanMax() {
		PBAimFormat.Builder aimFormatBuilder = PBAimFormat.newBuilder()
				.setFormat(TemplateFormatType.TEMPLATE_FDB);
		PBExtractTenprintInput.Builder extractTenprintInputBuilder = PBExtractTenprintInput
				.newBuilder().addAimFormats(aimFormatBuilder);
		PBExtractInputPayload.Builder extractInputPayloadBuilder = PBExtractInputPayload
				.newBuilder().setTenprintInput(extractTenprintInputBuilder);
		PBExtractJobRequest extractJobRequest = PBExtractJobRequest
				.newBuilder().setCallBackUrl("192.168.1.6").setPriority(15)
				.setInputPayload(extractInputPayloadBuilder).build();
		try {
			aimExtractService.extract(extractJobRequest, true);

		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(
					AimError.EXTRACT_PRIORITY_OUT_RANGE.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals("Extraction Job (Priority is out of range)",
					exception.getDescription());
			return;

		}
		fail();
	}

	@Test
	public void testExtractisFromServletPriIsLessThanMin() {
		PBAimFormat.Builder aimFormatBuilder = PBAimFormat.newBuilder()
				.setFormat(TemplateFormatType.TEMPLATE_FDB);
		PBExtractTenprintInput.Builder extractTenprintInputBuilder = PBExtractTenprintInput
				.newBuilder().addAimFormats(aimFormatBuilder);
		PBExtractInputPayload.Builder extractInputPayloadBuilder = PBExtractInputPayload
				.newBuilder().setTenprintInput(extractTenprintInputBuilder);
		PBExtractJobRequest extractJobRequest = PBExtractJobRequest
				.newBuilder().setCallBackUrl("192.168.1.6").setPriority(0)
				.setInputPayload(extractInputPayloadBuilder).build();
		try {
			aimExtractService.extract(extractJobRequest, true);

		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			ArgumentException exception = (ArgumentException) e;
			Assert.assertEquals(
					AimError.EXTRACT_PRIORITY_OUT_RANGE.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals("Extraction Job (Priority is out of range)",
					exception.getDescription());
			Assert.assertEquals("Extraction Job (Priority is out of range)",
					e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void testExtractisFromServlet1PRIORITYisNull() {
		PBAimFormat.Builder aimFormatBuilder = PBAimFormat.newBuilder()
				.setFormat(TemplateFormatType.TEMPLATE_FDB);
		PBExtractTenprintInput.Builder extractTenprintInputBuilder = PBExtractTenprintInput
				.newBuilder().addAimFormats(aimFormatBuilder);
		PBExtractInputPayload.Builder extractInputPayloadBuilder = PBExtractInputPayload
				.newBuilder().setTenprintInput(extractTenprintInputBuilder);
		PBExtractJobRequest extractJobRequest = PBExtractJobRequest
				.newBuilder().setInputPayload(extractInputPayloadBuilder)
				.build();
		PBExtractJobResponse ectractJobRes = aimExtractService.extract(
				extractJobRequest, true);
		manager.flush();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
				ectractJobRes.getServiceState().getState());
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from FE_JOB_QUEUE");
		Assert.assertEquals(1, list.size());
		Map<String, Object> map = list.get(0);
		Assert.assertEquals(17,
				Integer.parseInt(map.get("FUNCTION_ID").toString()));
		Assert.assertEquals(10,
				Integer.parseInt(map.get("PRIORITY").toString()));
		Assert.assertEquals(1,
				Integer.parseInt(map.get("CALLBACK_STYLE").toString()));
		List<Map<String, Object>> listJobPayloads = jdbcTemplate
				.queryForList("select * from FE_JOB_PAYLOADS");
		Assert.assertEquals(1, listJobPayloads.size());
		Map<String, Object> mapJobPayloads = list.get(0);
		Assert.assertEquals(map.get("JOB_ID"), mapJobPayloads.get("JOB_ID"));
		Assert.assertEquals(Integer.parseInt(map.get("JOB_ID").toString()),
				ectractJobRes.getJobId());

	}

	@Test
	public void testExtractTenprintInputisFromServlet() {
		PBAimFormat.Builder aimFormatBuilder = PBAimFormat.newBuilder()
				.setFormat(TemplateFormatType.TEMPLATE_FDB);
		PBExtractTenprintInput.Builder extractTenprintInputBuilder = PBExtractTenprintInput
				.newBuilder().addAimFormats(aimFormatBuilder);
		PBExtractInputPayload.Builder extractInputPayloadBuilder = PBExtractInputPayload
				.newBuilder().setTenprintInput(extractTenprintInputBuilder);
		PBExtractJobRequest extractJobRequest = PBExtractJobRequest
				.newBuilder().setCallBackUrl("192.168.1.6").setPriority(4)
				.setInputPayload(extractInputPayloadBuilder).build();
		PBExtractJobResponse ectractJobRes = aimExtractService.extract(
				extractJobRequest, true);
		manager.flush();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
				ectractJobRes.getServiceState().getState());
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from FE_JOB_QUEUE");
		Assert.assertEquals(1, list.size());
		Map<String, Object> map = list.get(0);
		Assert.assertEquals(17,
				Integer.parseInt(map.get("FUNCTION_ID").toString()));
		Assert.assertEquals(4, Integer.parseInt(map.get("PRIORITY").toString()));
		Assert.assertEquals("192.168.1.6", map.get("CALLBACK_URL"));
		Assert.assertEquals(1,
				Integer.parseInt(map.get("CALLBACK_STYLE").toString()));
		List<Map<String, Object>> listJobPayloads = jdbcTemplate
				.queryForList("select * from FE_JOB_PAYLOADS");
		Assert.assertEquals(1, listJobPayloads.size());
		Map<String, Object> mapJobPayloads = list.get(0);
		Assert.assertEquals(map.get("JOB_ID"), mapJobPayloads.get("JOB_ID"));
		Assert.assertEquals(Integer.parseInt(map.get("JOB_ID").toString()),
				ectractJobRes.getJobId());
	}

	@Test
	public void testExtractTenprintInputisNotFromServlet() {
		PBAimFormat.Builder aimFormatBuilder = PBAimFormat
				.newBuilder()
				.setFormat(TemplateFormatType.TEMPLATE_RDBT)
				.addFeTypeEvents(
						PBExtractFeTypeEvent
								.newBuilder()
								.setEvent(1)
								.addFeTypes(
										PBExtractFeType
												.newBuilder()
												.setFingerType(
														FingerPrintType.FINGER_PRINT_ROLLED)
												.setFisType(
														FisTypeType.FIS_TYPE_A)));
		PBExtractTenprintInput.Builder extractTenprintInputBuilder = PBExtractTenprintInput
				.newBuilder().addAimFormats(aimFormatBuilder);
		PBExtractInputPayload.Builder extractInputPayloadBuilder = PBExtractInputPayload
				.newBuilder().setTenprintInput(extractTenprintInputBuilder);
		PBExtractJobRequest extractJobRequest = PBExtractJobRequest
				.newBuilder().setCallBackUrl("192.168.1.6").setPriority(4)
				.setInputPayload(extractInputPayloadBuilder).build();
		PBExtractJobResponse ectractJobRes = aimExtractService.extract(
				extractJobRequest, false);
		// commitDao.commit();
		// jdbcTemplate.update("commit");
		manager.flush();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
				ectractJobRes.getServiceState().getState());
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from FE_JOB_QUEUE");

		Assert.assertEquals(1, list.size());
		Map<String, Object> map = list.get(0);
		Assert.assertEquals(17,
				Integer.parseInt(map.get("FUNCTION_ID").toString()));
		Assert.assertEquals(4, Integer.parseInt(map.get("PRIORITY").toString()));
		Assert.assertEquals("192.168.1.6", map.get("CALLBACK_URL"));
		Assert.assertEquals(0,
				Integer.parseInt(map.get("CALLBACK_STYLE").toString()));
		List<Map<String, Object>> listJobPayloads = jdbcTemplate
				.queryForList("select * from FE_JOB_PAYLOADS");
		Assert.assertEquals(1, listJobPayloads.size());
		Map<String, Object> mapJobPayloads = list.get(0);
		Assert.assertEquals(map.get("JOB_ID"), mapJobPayloads.get("JOB_ID"));
		Assert.assertEquals(Integer.parseInt(map.get("JOB_ID").toString()),
				ectractJobRes.getJobId());
	}

	@Test
	public void testExtractLatentisFromServlet() {
		PBExtractInputImage.Builder inputImageBuilder = PBExtractInputImage
				.newBuilder().setType(ImageFormatType.BMP)
				.setPosition(ImagePositionType.IMAGE_ROLLED_LEFT_INDEX);
		PBAimFormat.Builder aimFormatBuilder = PBAimFormat.newBuilder()
				.setFormat(TemplateFormatType.TEMPLATE_LDB);
		PBExtractLatentInput.Builder extractLatentBuilder = PBExtractLatentInput
				.newBuilder().addAimFormats(aimFormatBuilder)
				.setImage(inputImageBuilder);
		PBExtractInputPayload.Builder extractInputPayloadBuilder = PBExtractInputPayload
				.newBuilder().setLatentInput(extractLatentBuilder);
		PBExtractJobRequest extractJobRequest = PBExtractJobRequest
				.newBuilder().setCallBackUrl("192.168.1.6").setPriority(4)
				.setInputPayload(extractInputPayloadBuilder).build();

		PBExtractJobResponse ectractJobRes = aimExtractService.extract(
				extractJobRequest, true);
		manager.flush();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
				ectractJobRes.getServiceState().getState());
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from FE_JOB_QUEUE");
		Assert.assertEquals(1, list.size());
		Map<String, Object> map = list.get(0);
		Assert.assertEquals(17,
				Integer.parseInt(map.get("FUNCTION_ID").toString()));
		Assert.assertEquals(4, Integer.parseInt(map.get("PRIORITY").toString()));
		Assert.assertEquals("192.168.1.6", map.get("CALLBACK_URL"));
		Assert.assertEquals(1,
				Integer.parseInt(map.get("CALLBACK_STYLE").toString()));
		List<Map<String, Object>> listJobPayloads = jdbcTemplate
				.queryForList("select * from FE_JOB_PAYLOADS");
		Assert.assertEquals(1, listJobPayloads.size());
		Map<String, Object> mapJobPayloads = list.get(0);
		Assert.assertEquals(map.get("JOB_ID"), mapJobPayloads.get("JOB_ID"));
		Assert.assertEquals(Integer.parseInt(map.get("JOB_ID").toString()),
				ectractJobRes.getJobId());
	}

	@Test
	public void testExtractLatentisNotFromServlet() {
		PBExtractInputImage.Builder inputImageBuilder = PBExtractInputImage
				.newBuilder().setType(ImageFormatType.BMP)
				.setPosition(ImagePositionType.IMAGE_ROLLED_LEFT_INDEX);
		PBAimFormat.Builder aimFormatBuilder = PBAimFormat.newBuilder()
				.setFormat(TemplateFormatType.TEMPLATE_LDB);
		PBExtractLatentInput.Builder extractLatentBuilder = PBExtractLatentInput
				.newBuilder().addAimFormats(aimFormatBuilder)
				.setImage(inputImageBuilder);
		PBExtractInputPayload.Builder extractInputPayloadBuilder = PBExtractInputPayload
				.newBuilder().setLatentInput(extractLatentBuilder);
		PBExtractJobRequest extractJobRequest = PBExtractJobRequest
				.newBuilder().setCallBackUrl("192.168.1.6").setPriority(4)
				.setInputPayload(extractInputPayloadBuilder).build();

		PBExtractJobResponse ectractJobRes = aimExtractService.extract(
				extractJobRequest, false);
		manager.flush();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
				ectractJobRes.getServiceState().getState());
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from FE_JOB_QUEUE");
		Assert.assertEquals(1, list.size());
		Map<String, Object> map = list.get(0);
		Assert.assertEquals(17,
				Integer.parseInt(map.get("FUNCTION_ID").toString()));
		Assert.assertEquals(4, Integer.parseInt(map.get("PRIORITY").toString()));
		Assert.assertEquals("192.168.1.6", map.get("CALLBACK_URL"));
		Assert.assertEquals(0,
				Integer.parseInt(map.get("CALLBACK_STYLE").toString()));
		List<Map<String, Object>> listJobPayloads = jdbcTemplate
				.queryForList("select * from FE_JOB_PAYLOADS");
		Assert.assertEquals(1, listJobPayloads.size());
		Map<String, Object> mapJobPayloads = list.get(0);
		Assert.assertEquals(map.get("JOB_ID"), mapJobPayloads.get("JOB_ID"));
		Assert.assertEquals(Integer.parseInt(map.get("JOB_ID").toString()),
				ectractJobRes.getJobId());
	}

	@Test
	public void testExtractFaceisFromServlet() {

		PBExtractInputImage.Builder inputImageBuilder = PBExtractInputImage
				.newBuilder().setType(ImageFormatType.BMP)
				.setPosition(ImagePositionType.IMAGE_ROLLED_LEFT_INDEX);
		PBAimFormat.Builder aimFormatBuilder = PBAimFormat.newBuilder()
				.setFormat(TemplateFormatType.TEMPLATE_FDB);
		PBExtractFaceInput.Builder extractFaceBuilder = PBExtractFaceInput
				.newBuilder()
				.setProcess(
						FaceExtractProcessType.FACE_EXTRACT_PROCESS_EXTRATION)
				.addAimFormats(aimFormatBuilder).setImage(inputImageBuilder);
		PBExtractInputPayload.Builder extractInputPayloadBuilder = PBExtractInputPayload
				.newBuilder().setFaceInput(extractFaceBuilder);
		PBExtractJobRequest extractJobRequest = PBExtractJobRequest
				.newBuilder().setCallBackUrl("192.168.1.6").setPriority(4)
				.setInputPayload(extractInputPayloadBuilder).build();
		PBExtractJobResponse ectractJobRes = aimExtractService.extract(
				extractJobRequest, true);
		manager.flush();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
				ectractJobRes.getServiceState().getState());
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from FE_JOB_QUEUE");
		Assert.assertEquals(1, list.size());
		Map<String, Object> map = list.get(0);
		Assert.assertEquals(17,
				Integer.parseInt(map.get("FUNCTION_ID").toString()));
		Assert.assertEquals(4, Integer.parseInt(map.get("PRIORITY").toString()));
		Assert.assertEquals("192.168.1.6", map.get("CALLBACK_URL"));
		Assert.assertEquals(1,
				Integer.parseInt(map.get("CALLBACK_STYLE").toString()));
		List<Map<String, Object>> listJobPayloads = jdbcTemplate
				.queryForList("select * from FE_JOB_PAYLOADS");
		Assert.assertEquals(1, listJobPayloads.size());
		Map<String, Object> mapJobPayloads = list.get(0);
		Assert.assertEquals(map.get("JOB_ID"), mapJobPayloads.get("JOB_ID"));
		Assert.assertEquals(Integer.parseInt(map.get("JOB_ID").toString()),
				ectractJobRes.getJobId());
	}

	@Test
	public void testExtractFaceisNotFromServlet() {
		PBExtractInputImage.Builder inputImageBuilder = PBExtractInputImage
				.newBuilder().setType(ImageFormatType.BMP)
				.setPosition(ImagePositionType.IMAGE_ROLLED_LEFT_INDEX);
		PBAimFormat.Builder aimFormatBuilder = PBAimFormat.newBuilder()
				.setFormat(TemplateFormatType.TEMPLATE_FDB);
		PBExtractFaceInput.Builder extractFaceBuilder = PBExtractFaceInput
				.newBuilder()
				.setProcess(
						FaceExtractProcessType.FACE_EXTRACT_PROCESS_EXTRATION)
				.addAimFormats(aimFormatBuilder).setImage(inputImageBuilder);
		PBExtractInputPayload.Builder extractInputPayloadBuilder = PBExtractInputPayload
				.newBuilder().setFaceInput(extractFaceBuilder);
		PBExtractJobRequest extractJobRequest = PBExtractJobRequest
				.newBuilder().setCallBackUrl("192.168.1.6").setPriority(4)
				.setInputPayload(extractInputPayloadBuilder).build();

		PBExtractJobResponse ectractJobRes = aimExtractService.extract(
				extractJobRequest, false);
		manager.flush();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
				ectractJobRes.getServiceState().getState());
		List<Map<String, Object>> list = jdbcTemplate
				.queryForList("select * from FE_JOB_QUEUE");
		Assert.assertEquals(1, list.size());
		Map<String, Object> map = list.get(0);
		Assert.assertEquals(17,
				Integer.parseInt(map.get("FUNCTION_ID").toString()));
		Assert.assertEquals(4, Integer.parseInt(map.get("PRIORITY").toString()));
		Assert.assertEquals("192.168.1.6", map.get("CALLBACK_URL"));
		Assert.assertEquals(0,
				Integer.parseInt(map.get("CALLBACK_STYLE").toString()));
		List<Map<String, Object>> listJobPayloads = jdbcTemplate
				.queryForList("select * from FE_JOB_PAYLOADS");
		Assert.assertEquals(1, listJobPayloads.size());
		Map<String, Object> mapJobPayloads = list.get(0);
		Assert.assertEquals(map.get("JOB_ID"), mapJobPayloads.get("JOB_ID"));
		Assert.assertEquals(Integer.parseInt(map.get("JOB_ID").toString()),
				ectractJobRes.getJobId());
	}

	@Test
	public void testGetJobStatusDataBaseException() {
		new MockUp<FEJobDao>() {
			@Mock
			public FeJobQueueEntity findFeJob(long id) {
				throw new DataBaseException("1",
						"Exception occurred when list extract job ids",
						"111111");
			}

		};
		PBJobStatusRequest jobStatusRequest = PBJobStatusRequest.newBuilder()
				.setJobId(new Long(20)).build();
		try {
			aimExtractService.getJobStatus(jobStatusRequest);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof DataBaseException);
			DataBaseException exception = (DataBaseException) e;
			Assert.assertEquals(
					"Extract Service (DataBase error occurred, error:Exception occurred when list extract job ids)",
					exception.getDescription());
			Assert.assertEquals(AimError.EXTRACT_DB.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Extract Service (DataBase error occurred, error:Exception occurred when list extract job ids)",
					e.getMessage());
			return;
		} finally {			
		}
		fail();

	}

	@Test
	public void testGetJobStatusJobIdNotFound() {

		PBJobStatusRequest jobStatusRequest = PBJobStatusRequest.newBuilder()
				.setJobId(new Long(20)).build();
		try {
			aimExtractService.getJobStatus(jobStatusRequest);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);	
			return;
		}
		fail();
	}

	@Test
	public void testGetJobStatusJobStateQueued() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(FE_JOB_QUEUE_SEQ.nextval,17,4,0,123,0)");
		jdbcTemplate.execute("commit");
		Long jobId = jdbcTemplate.queryForObject(
				"select job_id from fe_job_queue", Long.class);
		PBJobStatusRequest jobStatusRequest = PBJobStatusRequest.newBuilder()
				.setJobId(jobId).build();
		PBJobStatusResponse jobStatusRes = aimExtractService
				.getJobStatus(jobStatusRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
				jobStatusRes.getServiceState().getState());
		Assert.assertEquals(jobId, new Long(jobStatusRes.getJobId()));
		Assert.assertEquals(JobStateType.JOB_STATE_QUEUED,
				jobStatusRes.getJobState());
		Assert.assertEquals(false, jobStatusRes.getJobFailed());
	}

	@Test
	public void testGetJobStatusJobStateWorking() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(FE_JOB_QUEUE_SEQ.nextval,17,4,1,123,0)");
		jdbcTemplate.execute("commit");
		Long jobId = jdbcTemplate.queryForObject(
				"select job_id from fe_job_queue", Long.class);
		PBJobStatusRequest jobStatusRequest = PBJobStatusRequest.newBuilder()
				.setJobId(jobId).build();
		PBJobStatusResponse jobStatusRes = aimExtractService
				.getJobStatus(jobStatusRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
				jobStatusRes.getServiceState().getState());
		Assert.assertEquals(jobId, new Long(jobStatusRes.getJobId()));
		Assert.assertEquals(JobStateType.JOB_STATE_WORKING,
				jobStatusRes.getJobState());
		Assert.assertEquals(false, jobStatusRes.getJobFailed());
	}

	@Test
	public void testGetJobStatusJobStateDone() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(FE_JOB_QUEUE_SEQ.nextval,17,4,2,123,0)");
		jdbcTemplate.execute("commit");
		Long jobId = jdbcTemplate.queryForObject(
				"select job_id from fe_job_queue", Long.class);
		PBJobStatusRequest jobStatusRequest = PBJobStatusRequest.newBuilder()
				.setJobId(jobId).build();
		PBJobStatusResponse jobStatusRes = aimExtractService
				.getJobStatus(jobStatusRequest);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
				jobStatusRes.getServiceState().getState());
		Assert.assertEquals(jobId, new Long(jobStatusRes.getJobId()));
		Assert.assertEquals(JobStateType.JOB_STATE_DONE,
				jobStatusRes.getJobState());
		Assert.assertEquals(false, jobStatusRes.getJobFailed());
	}

	@Test
	public void testlistJobIdsDataBaseException() {
		new MockUp<FEJobDao>() {
			@Mock
			public List<Long> listAllJobIds() {
				throw new DataBaseException("1",
						"Exception occurred when list extract job ids",
						"111111");
			}
		};
		try {
			aimExtractService.listJobIds();
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof DataBaseException);
			DataBaseException exception = (DataBaseException) e;
			Assert.assertEquals(
					"Extract Service (DataBase error occurred, error:Exception occurred when list extract job ids)",
					exception.getDescription());
			Assert.assertEquals(AimError.EXTRACT_DB.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Extract Service (DataBase error occurred, error:Exception occurred when list extract job ids)",
					e.getMessage());
			return;
		} finally {			
		}
		fail();

	}

	@Test
	public void testlistJobIdsAllJobIdNotFound() {
		try {
			aimExtractService.listJobIds();
		} catch (Exception e) {			
			Assert.assertTrue(e instanceof AimRuntimeException);
			Assert.assertEquals("List extract job id empty..", e.getMessage());
			return;
		}		
	}

	@Test
	public void testlistJobIds() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(10,17,4,2,123,0)");
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(12,17,4,2,456,1)");
		jdbcTemplate.execute("commit");

		PBListJobIdsResponse listJobIdsRes = aimExtractService.listJobIds();
		Assert.assertEquals(2, listJobIdsRes.getJobIdCount());
		Assert.assertEquals(10, listJobIdsRes.getJobId(0));
		Assert.assertEquals(12, listJobIdsRes.getJobId(1));
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
				listJobIdsRes.getServiceState().getState());

	}

	@Test
	public void testdeleteJobDataBaseException() {
		new MockUp<FEJobDao>() {
			@Mock
			public void deleteExtractJob(long extractJobId) {
				throw new DataBaseException("1",
						"Exception occurred when delete extract job", "111111");
			}
		};
		PBDeleteJobRequest deleteJobRequest = PBDeleteJobRequest.newBuilder()
				.setJobId(new Long(20)).build();
		try {
			aimExtractService.deleteJob(deleteJobRequest);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof DataBaseException);
			Assert.assertEquals(
					"Extract Service (DataBase error occurred, error:Exception occurred when delete extract job)",
					e.getMessage());
			return;
		} finally {			
		}
		fail();
	}

	@Test
	public void testDeleteJob() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(20,17,4,2,123,0)");
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(12,17,4,2,456,1)");
		jdbcTemplate.execute("commit");

		PBDeleteJobRequest deleteJobRequest = PBDeleteJobRequest.newBuilder()
				.setJobId(new Long(20)).build();
		aimExtractService.deleteJob(deleteJobRequest);
		Assert.assertEquals(new Integer(1), jdbcTemplate.queryForObject(
				"select count(*) from FE_JOB_QUEUE", Integer.class));
		Assert.assertEquals(new Integer(0), jdbcTemplate.queryForObject(
				"select count(*) from FE_JOB_QUEUE where job_id=20",
				Integer.class));

	}

	@Test
	public void testClearJobsDataBaseException() {
		new MockUp<FEJobDao>() {
			@Mock
			public void clearJobs() {
				throw new DataBaseException("1",
						"Exception occurred when clear extract job.", "111111");
			}
		};
		try {
			aimExtractService.clearJobs();
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof DataBaseException);
			DataBaseException exception = (DataBaseException) e;
			Assert.assertEquals(
					"Extract Service (DataBase error occurred, error:Exception occurred when clear extract job.)",
					exception.getDescription());
			Assert.assertEquals(AimError.EXTRACT_DB.getErrorCode(),
					exception.getErrorCode());
			Assert.assertEquals(
					"Extract Service (DataBase error occurred, error:Exception occurred when clear extract job.)",
					e.getMessage());
		} finally {			
		}
	}

	@Test
	public void testClearJobs() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(20,17,4,2,123,0)");
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(12,17,4,2,456,1)");
		jdbcTemplate.execute("commit");
		Assert.assertEquals(new Integer(2), jdbcTemplate.queryForObject(
				"select count(*) from FE_JOB_QUEUE", Integer.class));
		aimExtractService.clearJobs();
		Assert.assertEquals(new Integer(0), jdbcTemplate.queryForObject(
				"select count(*) from FE_JOB_QUEUE", Integer.class));

	}

	@Test
	public void testGetJobBinaryPBKeyedTemplateNull() {
		URL url = this.getClass().getResource("insert_fe_results.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder().setJobId(20).build();
		try {
			PBExtractJobBinaryResponse response = aimExtractService
					.getJobBinary(jobBinaryReq);
			response.getAllFields();
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(equals(e instanceof IllegalArgumentException));
			Assert.assertEquals("Both Key and Indexr is not specified..",
					e.getMessage());

		}
	}

	/*
	 * insert into FE_JOB_QUEUE
	 * (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)
	 * values(20,17,4,2,123,0); insert into FE_RESULTS
	 * (RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)
	 * values(1,20,CAST('111' AS BINARY),'TEMPLATE_FDB',1);
	 */

	@Test
	public void testGetJobBinaryPBKeyedTemplateNull_TemplatKeyFromFERESLUTSIsWrong() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(20,17,4,2,123,0)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,20,CAST('aimMysqltest' AS BINARY),'TEMPLATE_DDB',1)");
		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder().setJobId(20).build();
		try {
			aimExtractService.getJobBinary(jobBinaryReq);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			Assert.assertEquals(
					"Get Extract result (Fe results template key is not correct, key:TEMPLATE_DDB)",
					e.getMessage());
			return;
		}
		fail();

	}

	@Test
	public void testGetJobBinaryPBKeyedTemplateNull_TI() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(20,17,4,2,123,0)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,20,CAST('111' AS BINARY),'TEMPLATE_TI',1)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(2,20,CAST('111' AS BINARY),'TEMPLATE_TI',2)");

		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder().setJobId(20).build();

		PBExtractJobBinaryResponse response = aimExtractService
				.getJobBinary(jobBinaryReq);
		Assert.assertEquals(20, response.getJobId());
		Assert.assertEquals(2, response.getKeyedTemplateCount());

		List<FingerPrintType> fingerPrintTypeList = Lists.newArrayList();
		fingerPrintTypeList.add(FingerPrintType.FINGER_PRINT_ROLLED);
		fingerPrintTypeList.add(FingerPrintType.FINGER_PRINT_SLAP);

		Assert.assertEquals(TemplateFormatType.TEMPLATE_TI, response
				.getKeyedTemplate(0).getKey());

		Assert.assertTrue(fingerPrintTypeList.contains(response
				.getKeyedTemplate(0).getIndexer().getFingerPrintType()));
		Assert.assertEquals(TemplateFormatType.TEMPLATE_TI, response
				.getKeyedTemplate(1).getKey());
		Assert.assertTrue(fingerPrintTypeList.contains(response
				.getKeyedTemplate(1).getIndexer().getFingerPrintType()));
	}

	@Test
	public void testGetJobBinaryPBKeyedTemplateNull_TI_WrongInderFromFERESLUTS() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(20,17,4,2,123,0)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,20,CAST('111' AS BINARY),'TEMPLATE_TI',3)");

		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder().setJobId(20).build();

		try {
			aimExtractService.getJobBinary(jobBinaryReq);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			Assert.assertEquals(
					"Get Extract result (Fe results index is out of range, indexr:3)",
					e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void testGetJobBinaryPBKeyedTemplateNull_TIM() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(20,17,4,2,123,0)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,20,CAST('111' AS BINARY),'TEMPLATE_TIM',1)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(2,20,CAST('111' AS BINARY),'TEMPLATE_TIM',2)");

		List<FingerPrintType> fingerPrintTypeList = Lists.newArrayList();
		fingerPrintTypeList.add(FingerPrintType.FINGER_PRINT_ROLLED);
		fingerPrintTypeList.add(FingerPrintType.FINGER_PRINT_SLAP);

		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder().setJobId(20).build();

		PBExtractJobBinaryResponse response = aimExtractService
				.getJobBinary(jobBinaryReq);
		Assert.assertEquals(20, response.getJobId());
		Assert.assertEquals(2, response.getKeyedTemplateCount());
		Assert.assertEquals(TemplateFormatType.TEMPLATE_TIM, response
				.getKeyedTemplate(0).getKey());
		Assert.assertTrue(fingerPrintTypeList.contains(response
				.getKeyedTemplate(0).getIndexer().getFingerPrintType()));
		Assert.assertEquals(TemplateFormatType.TEMPLATE_TIM, response
				.getKeyedTemplate(1).getKey());
		Assert.assertTrue(fingerPrintTypeList.contains(response
				.getKeyedTemplate(1).getIndexer().getFingerPrintType()));
	}

	@Test
	public void testGetJobBinaryPBKeyedTemplateNull_TIM_WrongInderFromFERESLUTS() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(20,17,4,2,123,0)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,20,CAST('111' AS BINARY),'TEMPLATE_TIM',3)");

		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder().setJobId(20).build();

		try {
			aimExtractService.getJobBinary(jobBinaryReq);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			Assert.assertEquals(
					"Get Extract result (Fe results index is out of range, indexr:3)",
					e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void testGetJobBinaryPBKeyedTemplateNull_TLI() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(20,17,4,2,123,0)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,20,CAST('111' AS BINARY),'TEMPLATE_TLI',1)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(2,20,CAST('111' AS BINARY),'TEMPLATE_TLI',2)");

		List<FingerPrintType> fingerPrintTypeList = Lists.newArrayList();
		fingerPrintTypeList.add(FingerPrintType.FINGER_PRINT_ROLLED);
		fingerPrintTypeList.add(FingerPrintType.FINGER_PRINT_SLAP);

		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder().setJobId(20).build();

		PBExtractJobBinaryResponse response = aimExtractService
				.getJobBinary(jobBinaryReq);
		Assert.assertEquals(20, response.getJobId());
		Assert.assertEquals(2, response.getKeyedTemplateCount());
		Assert.assertEquals(TemplateFormatType.TEMPLATE_TLI, response
				.getKeyedTemplate(0).getKey());
		Assert.assertTrue(fingerPrintTypeList.contains(response
				.getKeyedTemplate(0).getIndexer().getFingerPrintType()));
		Assert.assertEquals(TemplateFormatType.TEMPLATE_TLI, response
				.getKeyedTemplate(1).getKey());
		Assert.assertTrue(fingerPrintTypeList.contains(response
				.getKeyedTemplate(1).getIndexer().getFingerPrintType()));
	}

	@Test
	public void testGetJobBinaryPBKeyedTemplateNull_TLI_WrongInderFromFERESLUTS() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(20,17,4,2,123,0)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,20,CAST('111' AS BINARY),'TEMPLATE_TLI',3)");

		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder().setJobId(20).build();

		try {
			aimExtractService.getJobBinary(jobBinaryReq);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			Assert.assertEquals(
					"Get Extract result (Fe results index is out of range, indexr:3)",
					e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void testGetJobBinaryPBKeyedTemplateNull_TLIS() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(20,17,4,2,123,0)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,20,CAST('111' AS BINARY),'TEMPLATE_TLIS',1)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(2,20,CAST('111' AS BINARY),'TEMPLATE_TLIS',2)");

		List<FingerPrintType> fingerPrintTypeList = Lists.newArrayList();
		fingerPrintTypeList.add(FingerPrintType.FINGER_PRINT_ROLLED);
		fingerPrintTypeList.add(FingerPrintType.FINGER_PRINT_SLAP);

		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder().setJobId(20).build();

		PBExtractJobBinaryResponse response = aimExtractService
				.getJobBinary(jobBinaryReq);
		Assert.assertEquals(20, response.getJobId());
		Assert.assertEquals(2, response.getKeyedTemplateCount());
		Assert.assertEquals(TemplateFormatType.TEMPLATE_TLIS, response
				.getKeyedTemplate(0).getKey());
		Assert.assertTrue(fingerPrintTypeList.contains(response
				.getKeyedTemplate(0).getIndexer().getFingerPrintType()));
		Assert.assertEquals(TemplateFormatType.TEMPLATE_TLIS, response
				.getKeyedTemplate(1).getKey());
		Assert.assertTrue(fingerPrintTypeList.contains(response
				.getKeyedTemplate(1).getIndexer().getFingerPrintType()));
	}

	@Test
	public void testGetJobBinaryPBKeyedTemplateNull_TLIS_WrongInderFromFERESLUTS() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(20,17,4,2,123,0)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,20,CAST('111' AS BINARY),'TEMPLATE_TLIS',3)");

		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder().setJobId(20).build();

		try {
			aimExtractService.getJobBinary(jobBinaryReq);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			Assert.assertEquals(
					"Get Extract result (Fe results index is out of range, indexr:3)",
					e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void testGetJobBinaryPBKeyedTemplateNull_TLIM() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(20,17,4,2,123,0)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,20,CAST('111' AS BINARY),'TEMPLATE_TLIM',1)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(2,20,CAST('111' AS BINARY),'TEMPLATE_TLIM',2)");

		List<FingerPrintType> fingerPrintTypeList = Lists.newArrayList();
		fingerPrintTypeList.add(FingerPrintType.FINGER_PRINT_ROLLED);
		fingerPrintTypeList.add(FingerPrintType.FINGER_PRINT_SLAP);

		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder().setJobId(20).build();

		PBExtractJobBinaryResponse response = aimExtractService
				.getJobBinary(jobBinaryReq);
		Assert.assertEquals(20, response.getJobId());
		Assert.assertEquals(2, response.getKeyedTemplateCount());
		Assert.assertEquals(TemplateFormatType.TEMPLATE_TLIM, response
				.getKeyedTemplate(0).getKey());
		Assert.assertTrue(fingerPrintTypeList.contains(response
				.getKeyedTemplate(0).getIndexer().getFingerPrintType()));
		Assert.assertEquals(TemplateFormatType.TEMPLATE_TLIM, response
				.getKeyedTemplate(1).getKey());
		Assert.assertTrue(fingerPrintTypeList.contains(response
				.getKeyedTemplate(1).getIndexer().getFingerPrintType()));
	}

	@Test
	public void testGetJobBinaryPBKeyedTemplateNull_TLIS_WrongInderFromFERESLUTM() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(20,17,4,2,123,0)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,20,CAST('111' AS BINARY),'TEMPLATE_TLIM',3)");

		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder().setJobId(20).build();

		try {
			aimExtractService.getJobBinary(jobBinaryReq);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			Assert.assertEquals(
					"Get Extract result (Fe results index is out of range, indexr:3)",
					e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void testGetJobBinaryPBKeyedTemplateNull_RDBT() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(20,17,4,2,123,0)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,20,CAST('111' AS BINARY),'TEMPLATE_RDBT',1)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(2,20,CAST('111' AS BINARY),'TEMPLATE_RDBT',2)");

		List<FingerPrintType> fingerPrintTypeList = Lists.newArrayList();
		fingerPrintTypeList.add(FingerPrintType.FINGER_PRINT_ROLLED);
		fingerPrintTypeList.add(FingerPrintType.FINGER_PRINT_SLAP);

		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder().setJobId(20).build();

		PBExtractJobBinaryResponse response = aimExtractService
				.getJobBinary(jobBinaryReq);
		Assert.assertEquals(20, response.getJobId());
		Assert.assertEquals(2, response.getKeyedTemplateCount());
		Assert.assertEquals(TemplateFormatType.TEMPLATE_RDBT, response
				.getKeyedTemplate(0).getKey());
		Assert.assertTrue(fingerPrintTypeList.contains(response
				.getKeyedTemplate(0).getIndexer().getFingerPrintType()));
		Assert.assertEquals(TemplateFormatType.TEMPLATE_RDBT, response
				.getKeyedTemplate(1).getKey());
		Assert.assertTrue(fingerPrintTypeList.contains(response
				.getKeyedTemplate(1).getIndexer().getFingerPrintType()));
	}

	@Test
	public void testGetJobBinaryPBKeyedTemplateNull_RDBT_WrongInderFromFERESLUTM() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(20,17,4,2,123,0)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,20,CAST('111' AS BINARY),'TEMPLATE_RDBT',3)");

		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder().setJobId(20).build();

		try {
			aimExtractService.getJobBinary(jobBinaryReq);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			Assert.assertEquals(
					"Get Extract result (Fe results index is out of range, indexr:3)",
					e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void testGetJobBinaryPBKeyedTemplateNull_RDBTM() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(20,17,4,2,123,0)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,20,CAST('111' AS BINARY),'TEMPLATE_RDBTM',1)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(2,20,CAST('111' AS BINARY),'TEMPLATE_RDBTM',2)");

		List<FingerPrintType> fingerPrintTypeList = Lists.newArrayList();
		fingerPrintTypeList.add(FingerPrintType.FINGER_PRINT_ROLLED);
		fingerPrintTypeList.add(FingerPrintType.FINGER_PRINT_SLAP);

		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder().setJobId(20).build();

		PBExtractJobBinaryResponse response = aimExtractService
				.getJobBinary(jobBinaryReq);
		Assert.assertEquals(20, response.getJobId());
		Assert.assertEquals(2, response.getKeyedTemplateCount());
		Assert.assertEquals(TemplateFormatType.TEMPLATE_RDBTM, response
				.getKeyedTemplate(0).getKey());
		Assert.assertTrue(fingerPrintTypeList.contains(response
				.getKeyedTemplate(0).getIndexer().getFingerPrintType()));
		Assert.assertEquals(TemplateFormatType.TEMPLATE_RDBTM, response
				.getKeyedTemplate(1).getKey());
		Assert.assertTrue(fingerPrintTypeList.contains(response
				.getKeyedTemplate(1).getIndexer().getFingerPrintType()));
	}

	@Test
	public void testGetJobBinaryPBKeyedTemplateNull_RDBTM_WrongInderFromFERESLUTM() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(20,17,4,2,123,0)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,20,CAST('111' AS BINARY),'TEMPLATE_RDBTM',3)");

		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder().setJobId(20).build();

		try {
			aimExtractService.getJobBinary(jobBinaryReq);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			Assert.assertEquals(
					"Get Extract result (Fe results index is out of range, indexr:3)",
					e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void testGetJobBinaryPBKeyedTemplateNull_RDBL() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(20,17,4,2,123,0)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,20,CAST('111' AS BINARY),'TEMPLATE_RDBL',11)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(2,20,CAST('111' AS BINARY),'TEMPLATE_RDBL',39)");
		jdbcTemplate.execute("commit");

		List<ImagePositionType> imagePositionTypeList = Lists.newArrayList();
		imagePositionTypeList.add(ImagePositionType.IMAGE_SLAP_RIGHT_THUMB);
		imagePositionTypeList.add(ImagePositionType.IMAGE_SLAP_LEFT_LITTLE);

		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder().setJobId(20).build();

		PBExtractJobBinaryResponse response = aimExtractService
				.getJobBinary(jobBinaryReq);
		Assert.assertEquals(20, response.getJobId());
		Assert.assertEquals(2, response.getKeyedTemplateCount());
		Assert.assertEquals(TemplateFormatType.TEMPLATE_RDBL, response
				.getKeyedTemplate(0).getKey());
		Assert.assertTrue(imagePositionTypeList.contains(response
				.getKeyedTemplate(0).getIndexer().getPosition()));
		Assert.assertEquals(TemplateFormatType.TEMPLATE_RDBL, response
				.getKeyedTemplate(1).getKey());
		Assert.assertTrue(imagePositionTypeList.contains(response
				.getKeyedTemplate(1).getIndexer().getPosition()));
	}

	@Test
	public void testGetJobBinaryPBKeyedTemplateNull_RDBL_WrongInderFromFERESLUTM() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(20,17,4,2,123,0)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,20,CAST('111' AS BINARY),'TEMPLATE_RDBL',1140)");

		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder().setJobId(20).build();

		try {
			aimExtractService.getJobBinary(jobBinaryReq);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			Assert.assertEquals(
					"Get Extract result (Fe results index is out of range, indexr:1140)",
					e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void testGetJobBinaryPBKeyedTemplateNull_RDBLS() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(20,17,4,2,123,0)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,20,CAST('111' AS BINARY),'TEMPLATE_RDBLS',11)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(2,20,CAST('111' AS BINARY),'TEMPLATE_RDBLS',39)");

		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder().setJobId(20).build();

		PBExtractJobBinaryResponse response = aimExtractService
				.getJobBinary(jobBinaryReq);
		Assert.assertEquals(20, response.getJobId());
		Assert.assertEquals(2, response.getKeyedTemplateCount());
		Assert.assertEquals(TemplateFormatType.TEMPLATE_RDBLS, response
				.getKeyedTemplate(0).getKey());

		List<ImagePositionType> imagePositionTypeList = Lists.newArrayList();
		imagePositionTypeList.add(ImagePositionType.IMAGE_SLAP_RIGHT_THUMB);
		imagePositionTypeList.add(ImagePositionType.IMAGE_SLAP_LEFT_LITTLE);

		Assert.assertTrue(imagePositionTypeList.contains(response
				.getKeyedTemplate(0).getIndexer().getPosition()));
		Assert.assertEquals(TemplateFormatType.TEMPLATE_RDBLS, response
				.getKeyedTemplate(1).getKey());
		Assert.assertTrue(imagePositionTypeList.contains(response
				.getKeyedTemplate(1).getIndexer().getPosition()));
	}

	@Test
	public void testGetJobBinaryPBKeyedTemplateNull_RDBLS_WrongInderFromFERESLUTM() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(20,17,4,2,123,0)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,20,CAST('111' AS BINARY),'TEMPLATE_RDBL',1140)");

		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder().setJobId(20).build();

		try {
			aimExtractService.getJobBinary(jobBinaryReq);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			Assert.assertEquals(
					"Get Extract result (Fe results index is out of range, indexr:1140)",
					e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void testGetJobBinaryPBKeyedTemplateNull_RDBLM() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(20,17,4,2,123,0)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,20,CAST('111' AS BINARY),'TEMPLATE_RDBLM',11)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(2,20,CAST('111' AS BINARY),'TEMPLATE_RDBLM',39)");

		List<ImagePositionType> imagePositionTypeList = Lists.newArrayList();
		imagePositionTypeList.add(ImagePositionType.IMAGE_SLAP_RIGHT_THUMB);
		imagePositionTypeList.add(ImagePositionType.IMAGE_SLAP_LEFT_LITTLE);

		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder().setJobId(20).build();

		PBExtractJobBinaryResponse response = aimExtractService
				.getJobBinary(jobBinaryReq);
		Assert.assertEquals(20, response.getJobId());
		Assert.assertEquals(2, response.getKeyedTemplateCount());
		Assert.assertEquals(TemplateFormatType.TEMPLATE_RDBLM, response
				.getKeyedTemplate(0).getKey());
		Assert.assertTrue(imagePositionTypeList.contains(response
				.getKeyedTemplate(0).getIndexer().getPosition()));
		Assert.assertEquals(TemplateFormatType.TEMPLATE_RDBLM, response
				.getKeyedTemplate(1).getKey());
		Assert.assertTrue(imagePositionTypeList.contains(response
				.getKeyedTemplate(1).getIndexer().getPosition()));
	}

	@Test
	public void testGetJobBinaryPBKeyedTemplateNull_RDBLM_WrongInderFromFERESLUTM() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(20,17,4,2,123,0)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,20,CAST('111' AS BINARY),'TEMPLATE_RDBLM',50)");

		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder().setJobId(20).build();

		try {
			aimExtractService.getJobBinary(jobBinaryReq);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			Assert.assertEquals(
					"Get Extract result (Fe results index is out of range, indexr:50)",
					e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void testGetJobBinaryPBKeyedTemplateNull_PDB() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(20,17,4,2,123,0)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,20,CAST('111' AS BINARY),'TEMPLATE_PDB',16)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(2,20,CAST('111' AS BINARY),'TEMPLATE_PDB',31)");

		List<ImagePositionType> imagePositionTypeList = Lists.newArrayList();
		imagePositionTypeList.add(ImagePositionType.IMAGE_PALM_RIGHT_FULL);
		imagePositionTypeList.add(ImagePositionType.IMAGE_PALM_LEFT_HYPOTHENAR);

		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder().setJobId(20).build();

		PBExtractJobBinaryResponse response = aimExtractService
				.getJobBinary(jobBinaryReq);
		Assert.assertEquals(20, response.getJobId());
		Assert.assertEquals(2, response.getKeyedTemplateCount());
		Assert.assertEquals(TemplateFormatType.TEMPLATE_PDB, response
				.getKeyedTemplate(0).getKey());
		Assert.assertTrue(imagePositionTypeList.contains(response
				.getKeyedTemplate(0).getIndexer().getPosition()));
		Assert.assertEquals(TemplateFormatType.TEMPLATE_PDB, response
				.getKeyedTemplate(1).getKey());
		Assert.assertTrue(imagePositionTypeList.contains(response
				.getKeyedTemplate(1).getIndexer().getPosition()));
	}

	@Test
	public void testGetJobBinaryPBKeyedTemplateNull_PDB_WrongInderFromFERESLUTM() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(20,17,4,2,123,0)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,20,CAST('111' AS BINARY),'TEMPLATE_RDBLM',50)");

		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder().setJobId(20).build();

		try {
			aimExtractService.getJobBinary(jobBinaryReq);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof ArgumentException);
			Assert.assertEquals(
					"Get Extract result (Fe results index is out of range, indexr:50)",
					e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void testGetJobBinaryPBKeyedTemplateNull_FDB() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(20,17,4,2,123,0)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,20,CAST('111' AS BINARY),'TEMPLATE_FDB',16)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(2,20,CAST('111' AS BINARY),'TEMPLATE_FDB',31)");

		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder().setJobId(20).build();

		PBExtractJobBinaryResponse response = aimExtractService
				.getJobBinary(jobBinaryReq);
		Assert.assertEquals(20, response.getJobId());
		Assert.assertEquals(2, response.getKeyedTemplateCount());
		Assert.assertEquals(TemplateFormatType.TEMPLATE_FDB, response
				.getKeyedTemplate(0).getKey());

		List<Integer> indexList = Lists.newArrayList();
		indexList.add(16);
		indexList.add(31);

		Assert.assertTrue(indexList.contains(response.getKeyedTemplate(0)
				.getIndexer().getIndex()));

		Assert.assertEquals(TemplateFormatType.TEMPLATE_FDB, response
				.getKeyedTemplate(1).getKey());
		Assert.assertTrue(indexList.contains(response.getKeyedTemplate(1)
				.getIndexer().getIndex()));
	}

	@Test
	public void testGetJobBinaryPBKeyedTemplateNull_RDBLX() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(20,17,4,2,123,0)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,20,CAST('111' AS BINARY),'TEMPLATE_RDBLX',0)");

		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder().setJobId(20).build();

		PBExtractJobBinaryResponse response = aimExtractService
				.getJobBinary(jobBinaryReq);
		Assert.assertEquals(20, response.getJobId());
		Assert.assertEquals(1, response.getKeyedTemplateCount());
		Assert.assertEquals(TemplateFormatType.TEMPLATE_RDBLX, response
				.getKeyedTemplate(0).getKey());
		Assert.assertFalse(response.getKeyedTemplate(0).hasIndexer());

	}

	@Test
	public void testGetJobBinaryPBKeyedTemplateHasKeyRDBT_NOIndexer() {
		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE)values(20,17,4,2,123,0)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(1,20,CAST('111' AS BINARY),'TEMPLATE_RDBT',1)");
		jdbcTemplate
				.update("insert into FE_RESULTS(RESULT_ID,JOB_ID,RESULT_DATA,TEMPLATE_KEY,TEMPLATE_INDEX)values(2,20,CAST('111' AS BINARY),'TEMPLATE_RDBT',2)");

		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder()
				.setJobId(20)
				.addKeyedTemplate(
						PBKeyedTemplate.newBuilder().setKey(
								TemplateFormatType.TEMPLATE_RDBT)).build();

		PBExtractJobBinaryResponse response = aimExtractService
				.getJobBinary(jobBinaryReq);
		Assert.assertEquals(20, response.getJobId());
		Assert.assertEquals(2, response.getKeyedTemplateCount());
		Assert.assertEquals(TemplateFormatType.TEMPLATE_RDBT, response
				.getKeyedTemplate(0).getKey());
		Assert.assertTrue(response.getKeyedTemplate(0).hasIndexer());
		Assert.assertTrue(response.getKeyedTemplate(1).hasIndexer());

	}

	@Test
	public void testGetJobBinaryBothNull() {
		byte[] bytes = { 1, 1, 1 };
		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder()
				.setJobId(20)
				.addKeyedTemplate(
						PBKeyedTemplate.newBuilder().setTemplateBinary(
								ByteString.copyFrom(bytes))).build();
		try {
			aimExtractService.getJobBinary(jobBinaryReq);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof AimRuntimeException);
			Assert.assertEquals("Extract result was not found in [FE_RESULT].",
					e.getMessage());
			return;
		}
		fail();

	}

	@Test
	public void testGetJobBinaryJustJobId() {
		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder().setJobId(20).build();
		try {
			aimExtractService.getJobBinary(jobBinaryReq);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof AimRuntimeException);
			Assert.assertEquals("Extract result was not found in [FE_RESULT].",
					e.getMessage());
			return;
		}
		fail();

	}

	@Test
	public void testGetJobBinaryNokeyHasIndexer() {
		byte[] bytes = { 1, 1, 1 };
		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder()
				.setJobId(20)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setFingerPrintType(
														FingerPrintType.FINGER_PRINT_ROLLED))
								.setTemplateBinary(ByteString.copyFrom(bytes)))
				.build();
		try {
			aimExtractService.getJobBinary(jobBinaryReq);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof IllegalArgumentException);
			Assert.assertEquals("Indexr has specified but key not specified..",
					e.getMessage());
			return;
		}

		fail();
	}

	@Test
	public void testGetJobBinaryResultNull() {
		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder()
				.setJobId(20)
				.addKeyedTemplate(
						PBKeyedTemplate.newBuilder().setKey(
								TemplateFormatType.TEMPLATE_FDB)).build();
		try {
			aimExtractService.getJobBinary(jobBinaryReq);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof AimRuntimeException);
			Assert.assertEquals("Extract result was not found in [FE_RESULT].",
					e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void testGetJobBinaryIndexNull() {
		URL url = this.getClass().getResource("insert_fe_results.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		jdbcTemplate.execute("commit");
		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder()
				.setJobId(20)
				.addKeyedTemplate(
						PBKeyedTemplate.newBuilder().setKey(
								TemplateFormatType.TEMPLATE_FDB)).build();
		PBExtractJobBinaryResponse extractJobBinaryRes = aimExtractService
				.getJobBinary(jobBinaryReq);
		Assert.assertEquals(20, extractJobBinaryRes.getJobId());
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
				extractJobBinaryRes.getServiceState().getState());
		Assert.assertEquals(TemplateFormatType.TEMPLATE_FDB,
				extractJobBinaryRes.getKeyedTemplate(0).getKey());
		Assert.assertEquals(1, extractJobBinaryRes.getKeyedTemplate(0)
				.getIndexer().getIndex());
	}

	@Test
	public void testGetJobBinary() {
		URL url = this.getClass().getResource("insert_fe_results.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder()
				.setJobId(20)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_FDB)
								.setIndexer(
										PBKeyedTemplateIndexer.newBuilder()
												.setIndex(1))).build();
		PBExtractJobBinaryResponse extractJobBinaryRes = aimExtractService
				.getJobBinary(jobBinaryReq);
		Assert.assertEquals(20, extractJobBinaryRes.getJobId());
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
				extractJobBinaryRes.getServiceState().getState());
		Assert.assertEquals(TemplateFormatType.TEMPLATE_FDB,
				extractJobBinaryRes.getKeyedTemplate(0).getKey());
		Assert.assertEquals(1, extractJobBinaryRes.getKeyedTemplate(0)
				.getIndexer().getIndex());
	}

	@Test
	public void testGetJobBinaryTwoData() {
		URL url = this.getClass().getResource("insert_fe_results.sql");
		executeSqlScript("file:///" + url.getPath(), false);
		PBExtractJobBinaryRequest jobBinaryReq = PBExtractJobBinaryRequest
				.newBuilder()
				.setJobId(20)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_FDB)
								.setIndexer(
										PBKeyedTemplateIndexer.newBuilder()
												.setIndex(1)))
				.addKeyedTemplate(PBKeyedTemplate.newBuilder()).build();
		PBExtractJobBinaryResponse extractJobBinaryRes = aimExtractService
				.getJobBinary(jobBinaryReq);
		Assert.assertEquals(20, extractJobBinaryRes.getJobId());
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
				extractJobBinaryRes.getServiceState().getState());
		Assert.assertEquals(TemplateFormatType.TEMPLATE_FDB,
				extractJobBinaryRes.getKeyedTemplate(0).getKey());
		Assert.assertEquals(1, extractJobBinaryRes.getKeyedTemplate(0)
				.getIndexer().getIndex());
		Assert.assertEquals(TemplateFormatType.TEMPLATE_FDB,
				extractJobBinaryRes.getKeyedTemplate(1).getKey());
		Assert.assertEquals(1, extractJobBinaryRes.getKeyedTemplate(1)
				.getIndexer().getIndex());
	}

	@Test
	public void testGetJobResultResultNull() {

		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE) values(20,17,4,0,123,0)");
		jdbcTemplate.execute("commit");
		PBJobResultRequest jobResultReq = PBJobResultRequest.newBuilder()
				.setJobId(20).build();
		try {
			aimExtractService.getJobResult(jobResultReq);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof AimRuntimeException);
			Assert.assertEquals(
					"Job 20 is in QUEUED state. Job must be in DONE state before calling getJobResult()",
					e.getMessage());
			return;
		}
		fail();

	}

	@Test
	public void testGetJobResult() throws IOException {
		byte[] compressedPayload = createCompuressedExtractPayload();
		byte[] bytes = PBExtractJobResultInternal
				.newBuilder()
				.setServiceState(
						PBServiceState.newBuilder().setState(
								ServiceStateType.SERVICE_STATE_SUCCESS))
				.setJobId(20)
				.addKeyedTemplate(
						PBKeyedTemplate.newBuilder().setKey(
								TemplateFormatType.TEMPLATE_FDB))
				.setCompressedOutputPayload(
						ByteString.copyFrom(compressedPayload)).build()
				.toByteArray();

		jdbcTemplate
				.update("insert into FE_JOB_QUEUE (JOB_ID,FUNCTION_ID,PRIORITY,RESULT,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE) values(20,17,4,?,2,123,0)",
						bytes);
		jdbcTemplate.execute("commit");
		PBJobResultRequest jobResultReq = PBJobResultRequest.newBuilder()
				.setJobId(20).build();

		PBExtractJobResult extractJobResult1 = aimExtractService
				.getJobResult(jobResultReq);
		Assert.assertEquals(20, extractJobResult1.getJobId());
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS,
				extractJobResult1.getServiceState().getState());
		Assert.assertEquals(TemplateFormatType.TEMPLATE_FDB, extractJobResult1
				.getKeyedTemplate(0).getKey());

	}

	public byte[] createCompuressedExtractPayload() throws IOException {
		PBExtractOutputPayload.Builder payload = PBExtractOutputPayload
				.newBuilder();
		payload.setTenprintOutput(PBExtractTenprintOutput.newBuilder())
				.setIrisOutput(PBExtractIrisOutput.newBuilder());
		byte[] bytePayload = payload.build().toByteArray();
		byte[] compressBytes = Deflater.compress(bytePayload);
		return compressBytes;
	}

}
