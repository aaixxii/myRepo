package jp.co.nec.aim.mm.procedure;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.google.common.base.Joiner;

import jp.co.nec.aim.mm.identify.planner.MuCpuAndPressure;

/**
 * 
 * @author xiazp
 *
 */
public class GetMuPressureAbilityProcedure extends StoredProcedure {
	private JdbcTemplate jdbcTemplate;
	private static final String GET_MU_PRESSURE_ABILITY = "get_mu_pressure_ability";	
	private Integer[] muIdArray;
	private String muIdStr;

	public GetMuPressureAbilityProcedure(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
		setDataSource(dataSource);
		setSql(GET_MU_PRESSURE_ABILITY);
		declareParameter(new SqlParameter("p_mu_ids", Types.VARCHAR));
		declareParameter(new SqlOutParameter("tab_name", Types.VARCHAR));
		compile();
	}

	public Integer[] getMuIdArray() {
		return muIdArray;
	}

	public void setMuIdArray(Integer[] muIdArray) {
		this.muIdArray = muIdArray;
	}
	
	public String getMuIdStr() {
		return muIdStr;
	}

	public void setMuIdStr(String muIdStr) {
		this.muIdStr = muIdStr;
	}

	/**
	 * 
	 * @param muId
	 * @return
	 * @throws DataAccessException
	 * @throws SQLException
	 */	
	public List<MuCpuAndPressure> getMuPressureAndAbility(Integer[] muIds)
			throws DataAccessException, SQLException {
		if (muIds.length < 1) {
			throw new IllegalArgumentException(
					"muIds == null when call getMuPressureAndAbility procedure");
		}
		muIdStr = Joiner.on(",").skipNulls().join(muIds);
		setMuIdArray(muIds);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_mu_ids", muIdStr);
		Map<String, Object> resultMap = execute(map);
		String tableName = (String) resultMap.get("tab_name");
		if (StringUtils.isBlank(tableName)) return null;
		String sql = "select * from " + tableName;
		 List<Map<String, Object>> result = jdbcTemplate.queryForList(sql);
		 jdbcTemplate.execute("DROP TABLE IF EXISTS " +tableName);
		 final List<MuCpuAndPressure> muCpuandPressureList =new ArrayList<>();
		result.forEach(one -> {
			int mu_id =  (int) one.get("mu_id");
			long pressure = (long) one.get("pressure");
			double ability = (double) one.get("ability");
			long report_ts = (long) one.get("report_ts");
			MuCpuAndPressure muPresure = new MuCpuAndPressure();
			muPresure.setMuId(mu_id);
			muPresure.setPressure(pressure);
			muPresure.setAbility(ability);
			muPresure.setReportTs(report_ts);
			muCpuandPressureList.add(muPresure);			
		});	
		return muCpuandPressureList;
	}

	/**
	 * 
	 * @author xiazp
	 *
	 */
	@SuppressWarnings("unused")
	private class CursorMapper implements RowMapper<MuCpuAndPressure> {
		@Override
		public MuCpuAndPressure mapRow(ResultSet rs, int row)
				throws SQLException {
			MuCpuAndPressure oneResult = new MuCpuAndPressure();
			oneResult.setMuId(rs.getInt("mu_id"));
			oneResult.setAbility(rs.getDouble("ability"));
			oneResult.setPressure(rs.getLong("pressure"));
			oneResult.setReportTs(rs.getLong("report_ts"));
			return oneResult;
		}
	}
}
