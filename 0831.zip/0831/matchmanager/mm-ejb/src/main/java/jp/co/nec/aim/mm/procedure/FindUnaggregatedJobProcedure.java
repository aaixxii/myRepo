package jp.co.nec.aim.mm.procedure;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.util.StopWatch;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.object.StoredProcedure;

/**
 * Call MATCH_MANAGER_API.find_unaggregated_jobs() and returns list of job_id.
 * 
 * @author kurosu
 * 
 */
public class FindUnaggregatedJobProcedure extends StoredProcedure {
	private static final String SQL = "find_unaggregated_jobs";
	private JdbcTemplate jdbcTemplate;

	public FindUnaggregatedJobProcedure(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
		setDataSource(dataSource);
		declareParameter(new SqlOutParameter("tab_name", Types.VARCHAR));	
		setSql(SQL);
		compile();
	}

	/**
	 * call MATCH_MANAGER_API.find_unaggregated_jobs() and returns list of
	 * job_id
	 * 
	 * @return - List of job_id
	 */
	public List<Long> execute() {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		Map<String, Object> map = execute(new HashMap<String, Object>());
		String tableName = (String) map.get("tab_name");
		String sql = "select * from " + tableName;
		List<Long> unAggregateJobList = jdbcTemplate.queryForList(sql, Long.class);
		

		stopWatch.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "execute",
				stopWatch.elapsedTime());
		jdbcTemplate.execute("DROP TABLE IF EXISTS " +  tableName);
		return unAggregateJobList;
	}

	@SuppressWarnings("unused")
	private class CursorMapper implements RowMapper<Long> {
		@Override
		public Long mapRow(ResultSet rs, int rowNum) throws SQLException {
			return new Long(rs.getLong("JOB_ID"));
		}
	}

}
