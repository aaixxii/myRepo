/**this is file XmlUtilTest.java
 * @author xia
   @date 2020/06/17
 */
package jp.co.nec.aim.mm.util;

import static org.junit.Assert.*;

import java.io.IOException;
import java.io.StringWriter;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author xia
 *
 */
public class XmlUtilTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link jp.co.nec.aim.mm.util.XmlUtil#isThisCmd(java.lang.String, java.lang.String)}.
	 */
	@Test
	public void testIsThisCmd() {
		
	}

	/**
	 * Test method for {@link jp.co.nec.aim.mm.util.XmlUtil#getXmlCmd(java.lang.String)}.
	 */
	@Test
	public void testGetXmlCmd() {
		
	}

	/**
	 * Test method for {@link jp.co.nec.aim.mm.util.XmlUtil#getRequestId(java.lang.String)}.
	 */
	@Test
	public void testGetRequestId() {
		
	}

	/**
	 * Test method for {@link jp.co.nec.aim.mm.util.XmlUtil#getRefId(java.lang.String, java.lang.String)}.
	 */
	@Test
	public void testGetRefId() {
		
	}

	/**
	 * Test method for {@link jp.co.nec.aim.mm.util.XmlUtil#getIdentifyAtribute(java.lang.String, java.lang.String)}.
	 */
	@Test
	public void testGetIdentifyAtribute() {
		
	}

	/**
	 * Test method for {@link jp.co.nec.aim.mm.util.XmlUtil#getUrl(java.lang.String, java.lang.String)}.
	 * @throws IOException 
	 */
	@Test
	public void testDom4jCreateXml() throws IOException {
		String result = dom4jCreateXml("123456789", 1);
		System.out.print(result);
	}
	
	private String dom4jCreateXml(String requestId , int success) throws IOException {
		 Document document = DocumentHelper.createDocument();
		 Element root = document.addElement( "Response")
				 .addAttribute("requestId", requestId)
				 .addAttribute("timeStamp", String.valueOf(System.currentTimeMillis()));
		 root.addElement("Return").addAttribute("value", String.valueOf(success));
		 OutputFormat format = OutputFormat.createPrettyPrint();
		String resXml = document.asXML();
		System.out.print(resXml);
		 StringWriter sw = new StringWriter();
        XMLWriter writer  = new XMLWriter(sw, format);        
        writer.write(document);
        String resuslt = sw.toString();		 
		return resuslt;		
	}

}
