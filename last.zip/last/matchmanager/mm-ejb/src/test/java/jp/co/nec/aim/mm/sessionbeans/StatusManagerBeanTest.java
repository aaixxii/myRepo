//package jp.co.nec.aim.mm.sessionbeans;
//
//import java.io.ByteArrayOutputStream;
//import java.io.PrintStream;
//import java.net.URL;
//import java.util.List;
//import java.util.Map;
//
//import javax.annotation.Resource;
//import javax.persistence.EntityManager;
//import javax.persistence.PersistenceContext;
//import javax.sql.DataSource;
//import javax.transaction.Transactional;
//
//import jp.co.nec.aim.message.proto.AIMEnumTypes.ComponentType;
//import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentAssignedStateType;
//import jp.co.nec.aim.message.proto.AIMMessages.PBComponentInfo;
//import jp.co.nec.aim.message.proto.AIMMessages.PBEnterResponse;
//import jp.co.nec.aim.message.proto.AIMMessages.PBExitRequest;
//import jp.co.nec.aim.message.proto.AIMMessages.PBHeartBeatResponse;
//import jp.co.nec.aim.mm.common.ProtobufHelper;
//import jp.co.nec.aim.mm.exception.ArgumentException;
//import jp.co.nec.aim.mm.jms.JmsSender;
//import jp.co.nec.aim.mm.logger.FeJobDoneLogger;
//import mockit.Mock;
//import mockit.MockUp;
//
//import org.apache.commons.lang3.StringUtils;
//import org.junit.After;
//import org.junit.Assert;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration
//@Transactional
//public class StatusManagerBeanTest extends
//		AbstractTransactionalJUnit4SpringContextTests {
//	@Resource
//	private DataSource ds;
//
//	@PersistenceContext(unitName = "AIMDB")
//	private EntityManager entityManager;
//
//	@Resource
//	private JdbcTemplate jdbcTemplate;
//
//	@Resource
//	private StatusManagerBean statusBean;
//	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
//	private final ByteArrayOutputStream errContent = new ByteArrayOutputStream();
//
//	private static PrintStream bk_out = System.out;
//	private static PrintStream bk_err = System.err;
//
//	@Before
//	public void setUp() throws Exception {
//		jdbcTemplate.update("delete from CONTAINER_JOBS");
//		jdbcTemplate.update("delete from FE_LOT_JOBS");
//		jdbcTemplate.update("delete from FE_JOB_QUEUE");
//		jdbcTemplate.update("delete from MU_CONTACTS");
//		jdbcTemplate.update("delete from MATCH_UNITS");
//		jdbcTemplate.update("delete from MU_SEG_REPORTS");
//		jdbcTemplate.update("delete from DATA_MANAGERS");
//		jdbcTemplate.update("delete from DM_SEG_REPORTS");
//		jdbcTemplate.update("delete from DM_SEGMENTS");
//		jdbcTemplate.update("delete from MAP_REDUCERS");
//		jdbcTemplate.update("delete from MR_CONTACTS");
//		jdbcTemplate.update("delete from FE_JOB_QUEUE");
//		jdbcTemplate.update("delete from FE_LOT_JOBS");
//		// jdbcTemplate.update("delete from RESOURCE_UPDATE_COUNT");
//		jdbcTemplate.update("delete from FE_JOB_FAILURE_REASONS");
//
//		jdbcTemplate.update("commit");
//		setMockMethod();
//		System.setOut(new PrintStream(outContent));
//		System.setErr(new PrintStream(errContent));
//	}
//
//	@After
//	public void tearDown() throws Exception {
//		jdbcTemplate.update("delete from CONTAINER_JOBS");
//		jdbcTemplate.update("delete from FE_LOT_JOBS");
//		jdbcTemplate.update("delete from FE_JOB_QUEUE");
//		// jdbcTemplate.update("delete from MU_CONTACTS");
//		jdbcTemplate.update("delete from MATCH_UNITS");
//		jdbcTemplate.update("delete from MU_SEG_REPORTS");
//		jdbcTemplate.update("delete from DATA_MANAGERS");
//		jdbcTemplate.update("delete from DM_SEG_REPORTS");
//		jdbcTemplate.update("delete from DM_SEGMENTS");
//		jdbcTemplate.update("delete from MAP_REDUCERS");
//		jdbcTemplate.update("delete from MR_CONTACTS");
//		jdbcTemplate.update("delete from FE_JOB_QUEUE");
//		jdbcTemplate.update("delete from FE_LOT_JOBS");
//		jdbcTemplate.update("delete from FE_JOB_FAILURE_REASONS");
//		// jdbcTemplate.update("delete from RESOURCE_UPDATE_COUNT");
//		jdbcTemplate.update("commit");		
//		System.setOut(bk_out);
//		System.setErr(bk_err);
//	}
//
//	/**
//	 * setMockMethod
//	 */
//	private void setMockMethod() {
//		new MockUp<JmsSender>() {
//			@Mock
//			private void convertAndSend(String queueName, Object message) {
//				// build ConnectionFactory And Queue is necessary
//				return;
//			}
//		};
//	}
//
//	@Test
//	public void testEnterNewMu() {
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		String resourceInfo = "10,10,1,1,10-1,1,5,5||1";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.MATCH_UNIT, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		PBEnterResponse response = statusBean.enter(component);
//		jdbcTemplate.update("commit");
//		List<Map<String, Object>> muelList = jdbcTemplate
//				.queryForList("select * from MU_EXTRACT_LOAD");
//		Assert.assertEquals(1, muelList.size());
//		Assert.assertEquals(0,
//				Integer.parseInt(muelList.get(0).get("PRESSURE").toString()));
//		List<Map<String, Object>> muilList = jdbcTemplate
//				.queryForList("select * from MU_INQUIRY_LOAD");
//		Assert.assertEquals(0,
//				Integer.parseInt(muilList.get(0).get("PRESSURE").toString()));
//
//		List<Map<String, Object>> muList = jdbcTemplate
//				.queryForList("select * from match_units");
//		Assert.assertEquals(1, muList.size());
//		Map<String, Object> mapMu = muList.get(0);
//		Assert.assertEquals("WORKING", mapMu.get("STATE"));
//		Assert.assertEquals(10,
//				Integer.parseInt(mapMu.get("PRIMARY_SIZE").toString()));
//		Assert.assertEquals(10,
//				Integer.parseInt(mapMu.get("SECONDARY_SIZE").toString()));
//		Assert.assertEquals(10, Integer.parseInt(mapMu.get(
//				"REPORTED_PERFORMANCE_FACTOR").toString()));
//		Assert.assertEquals(1,
//				Integer.parseInt(mapMu.get("NUMBER_OF_MATCHERS").toString()));
//		Assert.assertEquals(1,
//				Integer.parseInt(mapMu.get("NUMBER_OF_EXTRACTORS").toString()));
//
//		List<Map<String, Object>> muConList = jdbcTemplate
//				.queryForList("select * from MU_CONTACTS");
//		Assert.assertEquals(1, muList.size());
//		Map<String, Object> mapMuCon = muConList.get(0);
//		Assert.assertEquals(mapMuCon.get("mu_id"), mapMu.get("mu_id"));
//		List<Map<String, Object>> pbList = jdbcTemplate
//				.queryForList("select * from person_biometrics");
//		Map<String, Object> pbMap = pbList.get(0);
//		Assert.assertEquals(1,
//				Integer.parseInt(pbMap.get("CORRUPTED_FLAG").toString()));
//		Assert.assertTrue(response.getId() > 0);
//		Assert.assertEquals(42896, response.getWakeUpNotifyPort());
//		Assert.assertTrue(contains("Received enter() from unique id '192.168.1.1', type 'MATCH_UNIT', at URL '192.168.1.1'"));
//	}
//
//	@Test
//	public void testEnterUpdateMuSegmentsNotExist() {
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate
//				.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','EXITED')");
//		jdbcTemplate
//				.update("insert into MU_CONTACTS(MU_ID,CONTACT_TS)values(1,111)");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,1,2,1,5)");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,2,2,5,5)");
//		jdbcTemplate.update("commit");
//		String resourceInfo = "10,10,1,1,10-12,1,5,5||1@1,1,5,5||1";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.MATCH_UNIT, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		PBEnterResponse response = null;
//		response = statusBean.enter(component);
//
//		List<Map<String, Object>> muelList = jdbcTemplate
//				.queryForList("select * from MU_EXTRACT_LOAD");
//		Assert.assertEquals(1, muelList.size());
//		Assert.assertEquals(0,
//				Integer.parseInt(muelList.get(0).get("PRESSURE").toString()));
//		List<Map<String, Object>> muilList = jdbcTemplate
//				.queryForList("select * from MU_INQUIRY_LOAD");
//		Assert.assertEquals(0,
//				Integer.parseInt(muilList.get(0).get("PRESSURE").toString()));
//
//		List<Map<String, Object>> muList = jdbcTemplate
//				.queryForList("select * from match_units");
//		Assert.assertEquals(1, muList.size());
//		Map<String, Object> mapMu = muList.get(0);
//		Assert.assertEquals("WORKING", mapMu.get("STATE"));
//		Assert.assertEquals(10,
//				Integer.parseInt(mapMu.get("PRIMARY_SIZE").toString()));
//		Assert.assertEquals(10,
//				Integer.parseInt(mapMu.get("SECONDARY_SIZE").toString()));
//		Assert.assertEquals(10, Integer.parseInt(mapMu.get(
//				"REPORTED_PERFORMANCE_FACTOR").toString()));
//		Assert.assertEquals(1,
//				Integer.parseInt(mapMu.get("NUMBER_OF_MATCHERS").toString()));
//		Assert.assertEquals(1,
//				Integer.parseInt(mapMu.get("NUMBER_OF_EXTRACTORS").toString()));
//
//		List<Map<String, Object>> msrList = jdbcTemplate
//				.queryForList("select * from mu_seg_reports");
//		Assert.assertEquals(2, msrList.size());
//		List<Map<String, Object>> pbList = jdbcTemplate
//				.queryForList("select * from person_biometrics");
//		Map<String, Object> pbMap = pbList.get(0);
//		Assert.assertEquals(1,
//				Integer.parseInt(pbMap.get("CORRUPTED_FLAG").toString()));
//		Assert.assertEquals(2, response.getSegmentUpdatesCount());
//		for (int i = 0; i < 2; i++) {
//			if (response.getSegmentUpdates(i).getId() == 1) {
//				Assert.assertEquals(
//						SegmentAssignedStateType.SEGMENT_UNASSIGNED, response
//								.getSegmentUpdates(i).getAssignedState());
//			} else {
//				Assert.assertEquals(SegmentAssignedStateType.SEGMENT_DEFUNCT,
//						response.getSegmentUpdates(i).getAssignedState());
//			}
//			Assert.assertEquals(0, response.getSegmentUpdates(i).getSyncItem()
//					.getCatUpInfo().getCatchUpItemsCount());
//		}
//	}
//
//	@Test
//	public void testEnterUpdateMuSegmentsNotExist_UpdteMUInquiry_UpdateMUExtract() {
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate
//				.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','EXITED')");
//		jdbcTemplate
//				.update("insert into MU_CONTACTS(MU_ID,CONTACT_TS)values(1,111)");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,1,2,1,5)");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,2,2,5,5)");
//		jdbcTemplate
//				.update("insert into MU_INQUIRY_LOAD(MU_ID,PRESSURE,REPORT_TS)values(1,2,5111)");
//		jdbcTemplate
//				.update("insert into MU_EXTRACT_LOAD(MU_ID,PRESSURE,UPDATE_TS)values(1,2,2111)");
//		jdbcTemplate.update("commit");
//		String resourceInfo = "10,10,1,1,10-12,1,5,5||1@1,1,5,5||1";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.MATCH_UNIT, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		PBEnterResponse response = null;
//		response = statusBean.enter(component);
//		List<Map<String, Object>> muelList = jdbcTemplate
//				.queryForList("select * from MU_EXTRACT_LOAD");
//		Assert.assertEquals(1, muelList.size());
//		Assert.assertEquals(0,
//				Integer.parseInt(muelList.get(0).get("PRESSURE").toString()));
//		List<Map<String, Object>> muilList = jdbcTemplate
//				.queryForList("select * from MU_INQUIRY_LOAD");
//		Assert.assertEquals(1, muilList.size());
//		Assert.assertEquals(0,
//				Integer.parseInt(muilList.get(0).get("PRESSURE").toString()));
//
//		List<Map<String, Object>> muList = jdbcTemplate
//				.queryForList("select * from match_units");
//		Assert.assertEquals(1, muList.size());
//		Assert.assertEquals("WORKING", muList.get(0).get("STATE"));
//		List<Map<String, Object>> msrList = jdbcTemplate
//				.queryForList("select * from mu_seg_reports");
//		Assert.assertEquals(2, msrList.size());
//		List<Map<String, Object>> pbList = jdbcTemplate
//				.queryForList("select * from person_biometrics");
//		Map<String, Object> pbMap = pbList.get(0);
//		Assert.assertEquals(1,
//				Integer.parseInt(pbMap.get("CORRUPTED_FLAG").toString()));
//		Assert.assertEquals(2, response.getSegmentUpdatesCount());
//		for (int i = 0; i < 2; i++) {
//			if (response.getSegmentUpdates(i).getId() == 1) {
//				Assert.assertEquals(
//						SegmentAssignedStateType.SEGMENT_UNASSIGNED, response
//								.getSegmentUpdates(i).getAssignedState());
//			} else {
//				Assert.assertEquals(SegmentAssignedStateType.SEGMENT_DEFUNCT,
//						response.getSegmentUpdates(i).getAssignedState());
//			}
//			Assert.assertEquals(0, response.getSegmentUpdates(i).getSyncItem()
//					.getCatUpInfo().getCatchUpItemsCount());
//		}
//	}
//
//	@Test
//	public void testEnterMu_rollbackExtJobs() {
//		new MockUp<FeJobDoneLogger>() {
//			@Mock
//			public void info(long jobId) {
//				return;
//			}
//		};
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate
//				.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','EXITED')");
//		jdbcTemplate
//				.update("insert into MU_CONTACTS(MU_ID,CONTACT_TS)values(1,111)");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,1,2,1,5)");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,2,2,5,5)");
//		jdbcTemplate
//				.update("insert into FE_LOT_JOBS(LOT_JOB_ID,MU_ID,ASSIGNED_TS,TIMEOUTS)values(1,1,22,5)");
//		jdbcTemplate
//				.update("insert into FE_JOB_QUEUE(JOB_ID,LOT_JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,MU_ID,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,4,1,1,111,0)");
//		jdbcTemplate.update("commit");
//		try {
//			String resourceInfo = "10,10,1,1,10-1,1,5,5||1";
//			PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//					ComponentType.MATCH_UNIT, "1", "192.168.1.1",
//					"192.168.1.1", resourceInfo);
//			PBEnterResponse response = statusBean.enter(component);
//			List<Map<String, Object>> muList = jdbcTemplate
//					.queryForList("select * from match_units");
//			Assert.assertEquals(1, muList.size());
//			Assert.assertEquals("WORKING", muList.get(0).get("STATE"));
//			List<Map<String, Object>> mcList = jdbcTemplate
//					.queryForList("select * from MU_CONTACTS");
//			Assert.assertEquals(1, mcList.size());
//			Assert.assertFalse(mcList.get(0).get("CONTACT_TS").equals(111));
//			List<Map<String, Object>> msrList = jdbcTemplate
//					.queryForList("select * from mu_seg_reports");
//			Assert.assertEquals(1, msrList.size());
//			List<Map<String, Object>> pbList = jdbcTemplate
//					.queryForList("select * from person_biometrics");
//			Map<String, Object> pbMap = pbList.get(0);
//			Assert.assertEquals(1,
//					Integer.parseInt(pbMap.get("CORRUPTED_FLAG").toString()));
//			Assert.assertEquals(1, response.getId());
//			Assert.assertEquals(42896, response.getWakeUpNotifyPort());
//			jdbcTemplate.update("commit");
//		} finally {			
//		}
//
//	}
//
//	@Test
//	public void testEnterUpdateMu() {
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate
//				.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','EXITED')");
//		jdbcTemplate
//				.update("insert into MU_CONTACTS(MU_ID,CONTACT_TS)values(1,111)");
//
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,1,2,1,5)");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,2,2,5,5)");
//		jdbcTemplate.update("commit");
//		String resourceInfo = "10,10,1,1,10-2,1,5,5||2@1,1,5,5||1";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.MATCH_UNIT, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		PBEnterResponse response = statusBean.enter(component);
//		List<Map<String, Object>> mcList = jdbcTemplate
//				.queryForList("select * from MU_CONTACTS");
//		Assert.assertEquals(1, mcList.size());
//		Assert.assertFalse(mcList.get(0).get("CONTACT_TS").equals(111));
//		List<Map<String, Object>> muList = jdbcTemplate
//				.queryForList("select * from match_units");
//		Assert.assertEquals(1, muList.size());
//		Assert.assertEquals("WORKING", muList.get(0).get("STATE"));
//		List<Map<String, Object>> msrList = jdbcTemplate
//				.queryForList("select * from mu_seg_reports");
//		Assert.assertEquals(2, msrList.size());
//		List<Map<String, Object>> pbList = jdbcTemplate
//				.queryForList("select * from person_biometrics");
//		Map<String, Object> pbMap = pbList.get(0);
//		Assert.assertEquals(1,
//				Integer.parseInt(pbMap.get("CORRUPTED_FLAG").toString()));
//		Assert.assertEquals(1, Integer.parseInt(pbList.get(1)
//				.get("CORRUPTED_FLAG").toString()));
//		Assert.assertEquals(1, response.getId());
//		Assert.assertEquals(42896, response.getWakeUpNotifyPort());
//		jdbcTemplate.update("commit");
//
//	}
//
//	@Test
//	public void testEnterMu_ReportVersionLastestVersionSame() {
//		new MockUp<FeJobDoneLogger>() {
//			@Mock
//			public void info(long jobId) {
//				return;
//			}
//		};
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate
//				.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','EXITED')");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,1,2,1,5)");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,2,2,5,5)");
//		jdbcTemplate
//				.update("insert into FE_LOT_JOBS(LOT_JOB_ID,MU_ID,ASSIGNED_TS,TIMEOUTS)values(1,1,22,5)");
//		jdbcTemplate
//				.update("insert into FE_JOB_QUEUE(JOB_ID,LOT_JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,MU_ID,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,4,1,1,111,0)");
//		jdbcTemplate
//				.update("insert into MU_SEGMENTS(MU_ID,SEGMENT_ID,RANK)values(1,1,1)");
//		jdbcTemplate.update("commit");
//		try {
//
//			String resourceInfo = "10,10,1,1,10-1,1,5,5||1/1";
//			PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//					ComponentType.MATCH_UNIT, "1", "192.168.1.1",
//					"192.168.1.1", resourceInfo);
//			jdbcTemplate.update("commit");
//			PBEnterResponse response = statusBean.enter(component);
//			jdbcTemplate.update("commit");
//			List<Map<String, Object>> msrList = jdbcTemplate
//					.queryForList("select * from mu_seg_reports");
//			Assert.assertEquals(1, msrList.size());
//			List<Map<String, Object>> pbList = jdbcTemplate
//					.queryForList("select * from person_biometrics");
//			Map<String, Object> pbMap = pbList.get(0);
//			Assert.assertEquals(1,
//					Integer.parseInt(pbMap.get("CORRUPTED_FLAG").toString()));
//			Assert.assertEquals(1, response.getId());
//			Assert.assertEquals(42896, response.getWakeUpNotifyPort());
//			Assert.assertEquals(0, response.getSegmentUpdatesList().size());
//			jdbcTemplate.update("commit");
//		} finally {			
//		}
//	}
//
//	@Test
//	public void testEnterMu_badTemplatesIdNotExist() {
//		new MockUp<FeJobDoneLogger>() {
//			@Mock
//			public void info(long jobId) {
//				return;
//			}
//		};
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate
//				.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','EXITED')");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,1,2,1,5)");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,2,2,5,5)");
//		jdbcTemplate
//				.update("insert into FE_LOT_JOBS(LOT_JOB_ID,MU_ID,ASSIGNED_TS,TIMEOUTS)values(1,1,22,5)");
//		jdbcTemplate
//				.update("insert into FE_JOB_QUEUE(JOB_ID,LOT_JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,MU_ID,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,4,1,1,111,0)");
//		jdbcTemplate.update("commit");
//		try {
//
//			String resourceInfo = "10,10,1,1,10-1,1,1,1||1,9/1";
//			PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//					ComponentType.MATCH_UNIT, "1", "192.168.1.1",
//					"192.168.1.1", resourceInfo);
//			PBEnterResponse response = statusBean.enter(component);
//
//			List<Map<String, Object>> msrList = jdbcTemplate
//					.queryForList("select * from mu_seg_reports");
//			Assert.assertEquals(1, msrList.size());
//			List<Map<String, Object>> pbList = jdbcTemplate
//					.queryForList("select * from person_biometrics");
//			Map<String, Object> pbMap = pbList.get(0);
//			Assert.assertEquals(1,
//					Integer.parseInt(pbMap.get("CORRUPTED_FLAG").toString()));
//			Assert.assertEquals(1, response.getId());
//			Assert.assertEquals(42896, response.getWakeUpNotifyPort());
//			Assert.assertEquals(1, response.getSegmentUpdatesList().size());
//			Assert.assertEquals(2, response.getSegmentUpdates(0).getSyncItem()
//					.getCatUpInfo().getCatchUpItemsCount());
//			jdbcTemplate.update("commit");
//		} finally {		
//		}
//	}
//
//	@Test
//	public void testEnterMu_BiggerThanMaxSegVersionDiffs() {
//		new MockUp<FeJobDoneLogger>() {
//			@Mock
//			public void info(long jobId) {
//				return;
//			}
//		};
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate
//				.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','EXITED')");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,1,0,1,5)");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,2,2,5,5)");
//		jdbcTemplate
//				.update("insert into FE_LOT_JOBS(LOT_JOB_ID,MU_ID,ASSIGNED_TS,TIMEOUTS)values(1,1,22,5)");
//		jdbcTemplate
//				.update("insert into FE_JOB_QUEUE(JOB_ID,LOT_JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,MU_ID,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,4,1,1,111,0)");
//		jdbcTemplate
//				.update("update segments set VERSION = 2000 where SEGMENT_ID=1");
//		jdbcTemplate
//				.update("insert into  mu_segments (MU_ID,SEGMENT_ID,RANK)values(1,1,1)");
//		jdbcTemplate.update("commit");
//		try {
//
//			String resourceInfo = "10,10,1,1,10-1,1,2,2||1,9/1";
//			PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//					ComponentType.MATCH_UNIT, "1", "192.168.1.1",
//					"192.168.1.1", resourceInfo);
//			PBEnterResponse response = statusBean.enter(component);
//			jdbcTemplate.update("commit");
//			List<Map<String, Object>> msrList = jdbcTemplate
//					.queryForList("select * from mu_seg_reports");
//			Assert.assertEquals(0, msrList.size());
//			List<Map<String, Object>> pbList = jdbcTemplate
//					.queryForList("select * from person_biometrics");
//			Map<String, Object> pbMap = pbList.get(0);
//			Assert.assertEquals(1,
//					Integer.parseInt(pbMap.get("CORRUPTED_FLAG").toString()));
//			Assert.assertEquals(1, response.getId());
//			Assert.assertEquals(42896, response.getWakeUpNotifyPort());
//			Assert.assertEquals(1, response.getSegmentUpdatesList().size());
//			Assert.assertEquals(SegmentAssignedStateType.SEGMENT_ASSIGNED,
//					response.getSegmentUpdates(0).getAssignedState());
//			Assert.assertEquals(1, response.getSegmentUpdates(0).getId());
//			Assert.assertEquals(0, response.getSegmentUpdates(0).getSyncItem()
//					.getCatUpInfo().getCatchUpItemsCount());
//			jdbcTemplate.update("commit");
//		} finally {			
//		}
//	}
//
//	@Test
//	public void testEnterMu_TwoSegs() {
//		new MockUp<FeJobDoneLogger>() {
//			@Mock
//			public void info(long jobId) {
//				return;
//			}
//		};
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate
//				.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','EXITED')");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,1,2,1,5)");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,3,2,5,5)");
//		jdbcTemplate
//				.update("insert into FE_LOT_JOBS(LOT_JOB_ID,MU_ID,ASSIGNED_TS,TIMEOUTS)values(1,1,22,5)");
//		jdbcTemplate
//				.update("insert into FE_JOB_QUEUE(JOB_ID,LOT_JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,MU_ID,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,4,1,1,111,0)");
//		jdbcTemplate.update("commit");
//		try {
//			String resourceInfo = "10,10,1,1,10-1,1,1,1||1,9@2,1,2,2||1/1";
//			PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//					ComponentType.MATCH_UNIT, "1", "192.168.1.1",
//					"192.168.1.1", resourceInfo);
//			PBEnterResponse response = statusBean.enter(component);
//
//			List<Map<String, Object>> msrList = jdbcTemplate
//					.queryForList("select * from mu_seg_reports");
//			Assert.assertEquals(2, msrList.size());
//			List<Map<String, Object>> pbList = jdbcTemplate
//					.queryForList("select * from person_biometrics");
//			Map<String, Object> pbMap = pbList.get(0);
//			Assert.assertEquals(1,
//					Integer.parseInt(pbMap.get("CORRUPTED_FLAG").toString()));
//			Assert.assertEquals(1, response.getId());
//			Assert.assertEquals(42896, response.getWakeUpNotifyPort());
//			Assert.assertEquals(2, response.getSegmentUpdatesList().size());
//			Assert.assertEquals(2, response.getSegmentUpdates(0).getSyncItem()
//					.getCatUpInfo().getCatchUpItemsCount());
//			Assert.assertEquals(2, response.getSegmentUpdates(1).getSyncItem()
//					.getCatUpInfo().getCatchUpItemsCount());
//			jdbcTemplate.update("commit");
//		} finally {			
//		}
//	}
//
//	@Test
//	public void testEnterMu_SourceUrl() {
//		new MockUp<FeJobDoneLogger>() {
//			@Mock
//			public void info(long jobId) {
//				return;
//			}
//		};
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate
//				.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','EXITED')");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,1,2,1,5)");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,3,2,5,5)");
//		jdbcTemplate
//				.update("insert into FE_LOT_JOBS(LOT_JOB_ID,MU_ID,ASSIGNED_TS,TIMEOUTS)values(1,1,22,5)");
//		jdbcTemplate
//				.update("insert into FE_JOB_QUEUE(JOB_ID,LOT_JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,MU_ID,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,4,1,1,111,0)");
//		jdbcTemplate
//				.update("insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,CONTACT_URL,STATE,VERSION)values(1,'192.168.1.1','192.168.1.1','WORKING','1')");
//		jdbcTemplate
//				.update("insert into DM_SEG_REPORTS(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,1,1,1)");
//		jdbcTemplate
//				.update("insert into DM_SEGMENTS(DM_ID,SEGMENT_ID,RANK)values(1,1,1)");
//
//		jdbcTemplate
//				.update("insert into MU_SEGMENTS(MU_ID,SEGMENT_ID,RANK)values(1,1,1)");
//		jdbcTemplate.update("commit");
//		try {
//			String resourceInfo = "10,10,1,1,10-1,2,2,1||1,9@2,1,1,2||1/1";
//			PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//					ComponentType.MATCH_UNIT, "1", "192.168.1.1",
//					"192.168.1.1", resourceInfo);
//			PBEnterResponse response = statusBean.enter(component);
//
//			List<Map<String, Object>> msrList = jdbcTemplate
//					.queryForList("select * from mu_seg_reports");
//			Assert.assertEquals(2, msrList.size());
//			List<Map<String, Object>> pbList = jdbcTemplate
//					.queryForList("select * from person_biometrics");
//			Map<String, Object> pbMap = pbList.get(0);
//			Assert.assertEquals(1,
//					Integer.parseInt(pbMap.get("CORRUPTED_FLAG").toString()));
//			Assert.assertEquals(1, response.getId());
//			Assert.assertEquals(42896, response.getWakeUpNotifyPort());
//			Assert.assertEquals(2, response.getSegmentUpdatesList().size());
//			/*
//			 * Assert.assertEquals(2, response.getSegmentUpdates(0)
//			 * .getCatchUpCount());
//			 */
//			Assert.assertEquals(3, response.getSegmentUpdates(1).getSyncItem()
//					.getCatUpInfo().getCatchUpItemsCount());
//			Assert.assertEquals(0, response.getSegmentUpdates(1).getSyncItem()
//					.getCatUpInfo().getCatchUpItems(2).getBinaryTemplate()
//					.size());
//			/*
//			 * Assert.assertEquals( "source: " + "\"" + "192.168.1.1/segs/1" +
//			 * "\"                                                           ",
//			 * response .getSegmentUpdates(0).getDownload());
//			 */
//			jdbcTemplate.update("commit");
//		} finally {		
//		}
//	}
//
//	@Test
//	public void testEnterMu_NoResource() {
//		new MockUp<FeJobDoneLogger>() {
//			@Mock
//			public void info(long jobId) {
//				return;
//			}
//		};
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate
//				.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','EXITED')");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,1,2,1,5)");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,2,2,5,5)");
//		jdbcTemplate
//				.update("insert into FE_LOT_JOBS(LOT_JOB_ID,MU_ID,ASSIGNED_TS,TIMEOUTS)values(1,1,22,5)");
//		jdbcTemplate
//				.update("insert into FE_JOB_QUEUE(JOB_ID,LOT_JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,MU_ID,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,4,1,1,111,0)");
//		jdbcTemplate.update("commit");
//		try {
//
//			String resourceInfo = "";
//			PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//					ComponentType.MATCH_UNIT, "1", "192.168.1.1",
//					"192.168.1.1", resourceInfo);
//			PBEnterResponse response = statusBean.enter(component);
//
//			List<Map<String, Object>> msrList = jdbcTemplate
//					.queryForList("select * from mu_seg_reports");
//			Assert.assertEquals(0, msrList.size());
//			List<Map<String, Object>> pbList = jdbcTemplate
//					.queryForList("select * from person_biometrics");
//			Map<String, Object> pbMap = pbList.get(0);
//			Assert.assertEquals(0,
//					Integer.parseInt(pbMap.get("CORRUPTED_FLAG").toString()));
//			Assert.assertEquals(1, response.getId());
//			Assert.assertEquals(42896, response.getWakeUpNotifyPort());
//			Assert.assertEquals(0, response.getSegmentUpdatesList().size());
//		} finally {		
//		}
//	}
//
//	@Test
//	public void testEnterMu_NoSegmentInfo() {
//		new MockUp<FeJobDoneLogger>() {
//			@Mock
//			public void info(long jobId) {
//				return;
//			}
//		};
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate
//				.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','EXITED')");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,1,2,1,5)");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,2,2,5,5)");
//		jdbcTemplate
//				.update("insert into FE_LOT_JOBS(LOT_JOB_ID,MU_ID,ASSIGNED_TS,TIMEOUTS)values(1,1,22,5)");
//		jdbcTemplate
//				.update("insert into FE_JOB_QUEUE(JOB_ID,LOT_JOB_ID,FUNCTION_ID,PRIORITY,JOB_STATE,MU_ID,SUBMISSION_TS,CALLBACK_STYLE)values(1,1,1,4,1,1,111,0)");
//		jdbcTemplate.update("commit");
//		try {
//			String resourceInfo = "";
//			PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//					ComponentType.MATCH_UNIT, "1", "192.168.1.1",
//					"192.168.1.1", resourceInfo);
//			PBEnterResponse response = statusBean.enter(component);
//
//			List<Map<String, Object>> msrList = jdbcTemplate
//					.queryForList("select * from mu_seg_reports");
//			Assert.assertEquals(0, msrList.size());
//			List<Map<String, Object>> pbList = jdbcTemplate
//					.queryForList("select * from person_biometrics");
//			Map<String, Object> pbMap = pbList.get(0);
//			Assert.assertEquals(0,
//					Integer.parseInt(pbMap.get("CORRUPTED_FLAG").toString()));
//			Assert.assertEquals(1, response.getId());
//			Assert.assertEquals(42896, response.getWakeUpNotifyPort());
//			Assert.assertEquals(0, response.getSegmentUpdatesList().size());
//			jdbcTemplate.update("commit");
//		} finally {			
//		}
//	}
//
//	@Test
//	public void testEnterMu_NoNumOfMatchers() {
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//
//		jdbcTemplate.update("commit");
//		String resourceInfo = "10,10,1,  ,10-1,1,1,1||1,9@12,1,1,1||5,6,7,8,9/1";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.MATCH_UNIT, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		List<Map<String, Object>> msrList1 = jdbcTemplate
//				.queryForList("select * from mu_seg_reports");
//		Assert.assertEquals(0, msrList1.size());
//		PBEnterResponse response = statusBean.enter(component);
//		List<Map<String, Object>> muList = jdbcTemplate
//				.queryForList("select * from match_units");
//		Assert.assertEquals(1, muList.size());
//		Map<String, Object> muMap = muList.get(0);
//		Assert.assertEquals("WORKING", muMap.get("STATE"));
//		Assert.assertEquals(1,
//				Integer.parseInt(muMap.get("NUMBER_OF_MATCHERS").toString()));
//		Assert.assertEquals(null, muMap.get("NUMBER_OF_EXTRACTORS"));
//		List<Map<String, Object>> msrList = jdbcTemplate
//				.queryForList("select * from mu_seg_reports");
//		Assert.assertEquals(2, msrList.size());
//		List<Map<String, Object>> pbList = jdbcTemplate
//				.queryForList("select * from person_biometrics");
//		Map<String, Object> pbMap = pbList.get(0);
//		Assert.assertEquals(1,
//				Integer.parseInt(pbMap.get("CORRUPTED_FLAG").toString()));
//		Assert.assertNotNull(response.getId());
//		Assert.assertEquals(42896, response.getWakeUpNotifyPort());
//		Assert.assertEquals(2, response.getSegmentUpdatesList().size());
//		Assert.assertEquals(SegmentAssignedStateType.SEGMENT_DEFUNCT, response
//				.getSegmentUpdates(0).getAssignedState());
//		jdbcTemplate.update("commit");
//	}
//
//	@Test
//	public void testEnterMu_OneSegmentInfo_TwoRecordInMuSegReport() {
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate
//				.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','WORKING')");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,1,2,1,5)");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,2,2,5,5)");
//		jdbcTemplate.update("commit");
//		String resourceInfo = "10,10,1,1,10-1,1,5,5||1";
//		;
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.MATCH_UNIT, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		jdbcTemplate.update("commit");
//		PBEnterResponse response = statusBean.enter(component);
//		List<Map<String, Object>> msrList = jdbcTemplate
//				.queryForList("select * from MU_SEG_REPORTS");
//		Assert.assertEquals(1, msrList.size());
//		Map<String, Object> map = msrList.get(0);
//		Assert.assertEquals(5,
//				Integer.parseInt(map.get("SEGMENT_VERSION").toString()));
//		Assert.assertEquals(1, response.getSegmentUpdatesCount());
//		Assert.assertEquals(1, response.getId());
//		Assert.assertEquals(1, response.getSegmentUpdates(0).getId());
//		Assert.assertEquals(SegmentAssignedStateType.SEGMENT_UNASSIGNED,
//				response.getSegmentUpdates(0).getAssignedState());
//		Assert.assertEquals(0, response.getSegmentUpdates(0).getSyncItem()
//				.getCatUpInfo().getCatchUpItemsCount());
//	}
//
//	@Test
//	public void testEnterMu_TwoSegmentInfo_OneRecordInMuSegReport() {
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate
//				.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','WORKING')");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,1,2,1,5)");
//		/*
//		 * jdbcTemplate .update(
//		 * "insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,2,2,5,5)"
//		 * );
//		 */
//		jdbcTemplate.update("commit");
//		String resourceInfo = "10,10,1,1,10-1,1,5,5||1@2,1,5,5||1";
//		;
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.MATCH_UNIT, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		jdbcTemplate.update("commit");
//		PBEnterResponse response = statusBean.enter(component);
//		List<Map<String, Object>> list = jdbcTemplate
//				.queryForList("select * from MU_SEG_REPORTS");
//		Assert.assertEquals(2, list.size());
//		Assert.assertEquals(1, response.getSegmentUpdatesCount());
//		Assert.assertEquals(1, response.getId());
//		Assert.assertEquals(1, response.getSegmentUpdates(0).getId());
//		Assert.assertEquals(SegmentAssignedStateType.SEGMENT_UNASSIGNED,
//				response.getSegmentUpdates(0).getAssignedState());
//		Assert.assertEquals(0, response.getSegmentUpdates(0).getSyncItem()
//				.getCatUpInfo().getCatchUpItemsCount());
//	}
//
//	@Test
//	public void testEnterNewDM() {
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		String resourceInfo = "10,10,1,1,10-1,1,5,5||1";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.DATA_MANAGER, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		jdbcTemplate.update("commit");
//		PBEnterResponse response = statusBean.enter(component);
//		jdbcTemplate.update("commit");
//		List<Map<String, Object>> dmList = jdbcTemplate
//				.queryForList("select * from data_managers");
//		Assert.assertEquals(1, dmList.size());
//		Map<String, Object> mapDm = dmList.get(0);
//		Assert.assertEquals("WORKING", mapDm.get("STATE"));
//		response.getId();
//		List<Map<String, Object>> dmConList = jdbcTemplate
//				.queryForList("select * from DM_CONTACTS");
//		Assert.assertEquals(1, dmConList.size());
//		Map<String, Object> mapDmCon = dmConList.get(0);
//		Assert.assertEquals(mapDmCon.get("mu_id"), mapDm.get("mu_id"));
//		List<Map<String, Object>> pbList = jdbcTemplate
//				.queryForList("select * from person_biometrics");
//		Map<String, Object> pbMap = pbList.get(0);
//		Assert.assertEquals(1,
//				Integer.parseInt(pbMap.get("CORRUPTED_FLAG").toString()));
//		Assert.assertTrue(response.getId() > 0);
//		Assert.assertEquals(42896, response.getWakeUpNotifyPort());
//		List<Map<String, Object>> decList = jdbcTemplate
//				.queryForList("select * from DM_ELIGIBLE_CONTAINERS");
//		Assert.assertEquals(19, decList.size());
//		jdbcTemplate.update("commit");
//	}
//
//	@Test
//	public void testEnterUpdateDmSegmentsNotExist() {
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate
//				.update("insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','EXITED')");
//		jdbcTemplate
//				.update("insert into DM_CONTACTS(DM_ID,CONTACT_TS)values(1,111)");
//		jdbcTemplate
//				.update("insert into DM_SEG_REPORTS(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,1,2,1)");
//		jdbcTemplate
//				.update("insert into DM_SEG_REPORTS(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,2,2,5)");
//		jdbcTemplate.update("commit");
//		String resourceInfo = "10,10,1,1,10-12,1,5,5||1@1,1,5,5||1";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.DATA_MANAGER, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		PBEnterResponse response = null;
//		response = statusBean.enter(component);
//		List<Map<String, Object>> dmList = jdbcTemplate
//				.queryForList("select * from data_managers");
//		Assert.assertEquals(1, dmList.size());
//		Assert.assertEquals("WORKING", dmList.get(0).get("STATE"));
//		List<Map<String, Object>> msrList = jdbcTemplate
//				.queryForList("select * from dm_seg_reports");
//		Assert.assertEquals(2, msrList.size());
//		List<Map<String, Object>> pbList = jdbcTemplate
//				.queryForList("select * from person_biometrics");
//		Map<String, Object> pbMap = pbList.get(0);
//		Assert.assertEquals(1,
//				Integer.parseInt(pbMap.get("CORRUPTED_FLAG").toString()));
//		Assert.assertEquals(2, response.getSegmentUpdatesCount());
//		int size = response.getSegmentUpdatesCount();
//		for (int i = 0; i < size; i++) {
//			if (response.getSegmentUpdates(i).getId() == 1) {
//				Assert.assertEquals(
//						SegmentAssignedStateType.SEGMENT_UNASSIGNED, response
//								.getSegmentUpdates(i).getAssignedState());
//			} else {
//				Assert.assertEquals(SegmentAssignedStateType.SEGMENT_DEFUNCT,
//						response.getSegmentUpdates(i).getAssignedState());
//			}
//			Assert.assertEquals(0, response.getSegmentUpdates(i).getSyncItem()
//					.getCatUpInfo().getCatchUpItemsCount());
//		}
//	}
//
//	@Test
//	public void testEnterUpdateDm_Segments_Unassigned_OneRequireDiff() {
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate
//				.update("insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','EXITED')");
//		jdbcTemplate
//				.update("insert into DM_CONTACTS(DM_ID,CONTACT_TS)values(1,111)");
//		jdbcTemplate
//				.update("insert into DM_SEG_REPORTS(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,1,2,1)");
//		jdbcTemplate
//				.update("insert into DM_SEG_REPORTS(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,2,2,5)");
//		/*
//		 * jdbcTemplate
//		 * .update("insert into DM_SEGMENTS(DM_ID,SEGMENT_ID,RANK)values(1,2,1)"
//		 * );
//		 */
//		jdbcTemplate.update("commit");
//		String resourceInfo = "10,10,1,1,10-2,1,5,5||1@1,1,5,5||1";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.DATA_MANAGER, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		PBEnterResponse response = null;
//		response = statusBean.enter(component);
//		jdbcTemplate.update("commit");
//		List<Map<String, Object>> dmList = jdbcTemplate
//				.queryForList("select * from data_managers");
//		Assert.assertEquals(1, dmList.size());
//		Assert.assertEquals("WORKING", dmList.get(0).get("STATE"));
//		List<Map<String, Object>> msrList = jdbcTemplate
//				.queryForList("select * from dm_seg_reports");
//		Assert.assertEquals(2, msrList.size());
//		List<Map<String, Object>> pbList = jdbcTemplate
//				.queryForList("select * from person_biometrics");
//		Map<String, Object> pbMap = pbList.get(0);
//		Assert.assertEquals(1,
//				Integer.parseInt(pbMap.get("CORRUPTED_FLAG").toString()));
//		Assert.assertEquals(1, response.getSegmentUpdatesCount());
//		Assert.assertEquals(SegmentAssignedStateType.SEGMENT_UNASSIGNED,
//				response.getSegmentUpdates(0).getAssignedState());
//	}
//
//	@Test
//	public void testEnterUpdateDm_Segments_BadTemplates() {
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate
//				.update("insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','EXITED')");
//		jdbcTemplate
//				.update("insert into DM_CONTACTS(DM_ID,CONTACT_TS)values(1,111)");
//		jdbcTemplate
//				.update("insert into DM_SEG_REPORTS(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,1,2,1)");
//		jdbcTemplate
//				.update("insert into DM_SEG_REPORTS(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,2,2,5)");
//		/*
//		 * jdbcTemplate
//		 * .update("insert into DM_SEGMENTS(DM_ID,SEGMENT_ID,RANK)values(1,2,1)"
//		 * );
//		 */
//		jdbcTemplate.update("commit");
//		String resourceInfo = "10,10,1,1,10-2,1,5,5||1@1,1,5,5||1,2,3,4,5,6";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.DATA_MANAGER, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		PBEnterResponse response = null;
//		response = statusBean.enter(component);
//		jdbcTemplate.update("commit");
//		List<Map<String, Object>> dmList = jdbcTemplate
//				.queryForList("select * from data_managers");
//		Assert.assertEquals(1, dmList.size());
//		Assert.assertEquals("WORKING", dmList.get(0).get("STATE"));
//		List<Map<String, Object>> msrList = jdbcTemplate
//				.queryForList("select * from dm_seg_reports");
//		Assert.assertEquals(2, msrList.size());
//		List<Map<String, Object>> pbList = jdbcTemplate
//				.queryForList("select * from person_biometrics where BIOMETRICS_ID in (1,2,3,4,5,6)");
//		for (int i = 0; i < 6; i++) {
//			Map<String, Object> pbMap = pbList.get(i);
//			Assert.assertEquals(1,
//					Integer.parseInt(pbMap.get("CORRUPTED_FLAG").toString()));
//		}
//		Assert.assertEquals(1, response.getSegmentUpdatesCount());
//		Assert.assertEquals(SegmentAssignedStateType.SEGMENT_UNASSIGNED,
//				response.getSegmentUpdates(0).getAssignedState());
//	}
//
//	@Test
//	public void testEnterDM_NoSegmentInfo() {
//		new MockUp<FeJobDoneLogger>() {
//			@Mock
//			public void info(long jobId) {
//				return;
//			}
//		};
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate
//				.update("insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','EXITED')");
//		jdbcTemplate
//				.update("insert into DM_CONTACTS(DM_ID,CONTACT_TS)values(1,111)");
//		jdbcTemplate
//				.update("insert into DM_SEG_REPORTS(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,1,2,1)");
//		jdbcTemplate
//				.update("insert into DM_SEG_REPORTS(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,2,2,5)");
//		jdbcTemplate.update("commit");
//		try {
//			String resourceInfo = "";
//			PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//					ComponentType.DATA_MANAGER, "1", "192.168.1.1",
//					"192.168.1.1", resourceInfo);
//			PBEnterResponse response = statusBean.enter(component);
//			List<Map<String, Object>> msrList = jdbcTemplate
//					.queryForList("select * from dm_seg_reports");
//			Assert.assertEquals(0, msrList.size());
//			List<Map<String, Object>> pbList = jdbcTemplate
//					.queryForList("select * from person_biometrics");
//			Map<String, Object> pbMap = pbList.get(0);
//			Assert.assertEquals(0,
//					Integer.parseInt(pbMap.get("CORRUPTED_FLAG").toString()));
//			Assert.assertEquals(1, response.getId());
//			Assert.assertEquals(42896, response.getWakeUpNotifyPort());
//			Assert.assertEquals(0, response.getSegmentUpdatesList().size());
//		} finally {			
//		}
//	}
//
//	@Test
//	public void testEnterNewMR() {
//		String resourceInfo = "10,10,1,1,10-1,1,5,5||1";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.MAP_REDUCER, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		jdbcTemplate.update("commit");
//		PBEnterResponse response = statusBean.enter(component);
//		jdbcTemplate.update("commit");
//		List<Map<String, Object>> mrList = jdbcTemplate
//				.queryForList("select * from MAP_REDUCERS");
//		Assert.assertEquals(1, mrList.size());
//		Map<String, Object> mapMr = mrList.get(0);
//		Assert.assertEquals("WORKING", mapMr.get("STATE"));
//		Assert.assertEquals(mapMr.get("MR_ID"), mapMr.get("RING_LOCATION"));
//		response.getId();
//		List<Map<String, Object>> mrConList = jdbcTemplate
//				.queryForList("select * from MR_CONTACTS");
//		Assert.assertEquals(1, mrConList.size());
//		Map<String, Object> mapMrCon = mrConList.get(0);
//		Assert.assertEquals(mapMrCon.get("mr_id"), mapMr.get("mr_id"));
//		Assert.assertNotNull(response.getId());
//	}
//
//	@Test
//	public void testEnterUpdateMR() {
//		jdbcTemplate
//				.update("insert into MAP_REDUCERS(MR_ID,RING_LOCATION,UNIQUE_ID,STATE)values(1,1,'192.168.1.1','EXITED')");
//		jdbcTemplate
//				.update("insert into MR_CONTACTS(MR_ID,CONTACT_TS)values(1,111)");
//		jdbcTemplate.update("commit");
//		String resourceInfo = "10,10,1,1,10-1,1,5,5||1";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.MAP_REDUCER, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		jdbcTemplate.update("commit");
//		PBEnterResponse response = statusBean.enter(component);
//		jdbcTemplate.update("commit");
//		List<Map<String, Object>> mrList = jdbcTemplate
//				.queryForList("select * from MAP_REDUCERS");
//		Assert.assertEquals(1, mrList.size());
//		Map<String, Object> mapMr = mrList.get(0);
//		Assert.assertEquals("WORKING", mapMr.get("STATE"));
//		Assert.assertEquals(mapMr.get("MR_ID"), mapMr.get("RING_LOCATION"));
//		response.getId();
//		List<Map<String, Object>> mrConList = jdbcTemplate
//				.queryForList("select * from MR_CONTACTS");
//		Assert.assertEquals(1, mrConList.size());
//		Map<String, Object> mapMrCon = mrConList.get(0);
//		Assert.assertEquals(mapMrCon.get("mr_id"), mapMr.get("mr_id"));
//		Assert.assertEquals(1, response.getId());
//	}
//
//	@Test
//	public void testEnterWrongType() {
//		jdbcTemplate
//				.update("insert into MAP_REDUCERS(MR_ID,RING_LOCATION,UNIQUE_ID,STATE)values(1,1,'192.168.1.1','EXITED')");
//		jdbcTemplate
//				.update("insert into MR_CONTACTS(MR_ID,CONTACT_TS)values(1,111)");
//		jdbcTemplate.update("commit");
//		String resourceInfo = "10,10,1,1,10-1,1,5,5||1";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.MATCH_MANAGER, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		jdbcTemplate.update("commit");
//		try {
//			statusBean.enter(component);
//		} catch (Exception e) {
//			// TODO: handle exception
//			Assert.assertTrue(e instanceof ArgumentException);
//			ArgumentException argumentException = (ArgumentException) e;
//			Assert.assertEquals("814006301", argumentException.getErrorCode());
//			Assert.assertEquals(
//					"PBComponentInfo.ComponentType(MATCH_MANAGER) is not support..",
//					argumentException.getDescription());
//
//		}
//
//	}
//
//	@Test
//	public void testEnter_SYSTEM_MANAGER() {
//		jdbcTemplate
//				.update("insert into MAP_REDUCERS(MR_ID,RING_LOCATION,UNIQUE_ID,STATE)values(1,1,'192.168.1.1','EXITED')");
//		jdbcTemplate
//				.update("insert into MR_CONTACTS(MR_ID,CONTACT_TS)values(1,111)");
//		jdbcTemplate.update("commit");
//		String resourceInfo = "10,10,1,1,10-1,1,5,5||1";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.SYSTEM_MANAGER, "1", "192.168.1.1",
//				"192.168.1.1", resourceInfo);
//		jdbcTemplate.update("commit");
//		statusBean.enter(component);
//	}
//
//	@Test
//	public void testHeartBeat_WrongType() {
//		String resourceInfo = "10,10,1,1,10-1,1,5,5||1";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.MATCH_MANAGER, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		jdbcTemplate.update("commit");
//		try {
//			statusBean.heartbeat(component);
//		} catch (Exception e) {
//			// TODO: handle exception
//			Assert.assertTrue(e instanceof ArgumentException);
//			ArgumentException argumentException = (ArgumentException) e;
//			Assert.assertEquals("814006301", argumentException.getErrorCode());
//			Assert.assertEquals(
//					"PBComponentInfo.ComponentType(MATCH_MANAGER) is not support..",
//					argumentException.getDescription());
//		}
//	}
//
//	@Test
//	public void testHeartBeatMu_NotWorking() {
//		jdbcTemplate
//				.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','EXITED')");
//		String resourceInfo = "10,10,1,1,10-1,1,5,5||1";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.MATCH_UNIT, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		jdbcTemplate.update("commit");
//		PBHeartBeatResponse response = statusBean.heartbeat(component);
//		Assert.assertTrue(response.getWrongState());
//		Assert.assertEquals(0, response.getSegmentUpdatesCount());
//		Assert.assertTrue(contains("MU '1' heartBeat state is not in working state"));
//	}
//
//	@Test
//	public void testHeartBeatMu_NotFoundMu() {
//		String resourceInfo = "10,10,1,1,10-1,1,5,5||1";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.MATCH_UNIT, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		jdbcTemplate.update("commit");
//		PBHeartBeatResponse response = statusBean.heartbeat(component);
//		Assert.assertTrue(response.getWrongState());
//		Assert.assertEquals(0, response.getSegmentUpdatesCount());
//		Assert.assertTrue(contains("findAndWarnState: (heartBeat) Match unit uniqueId: 192.168.1.1 not found in database."));
//	}
//
//	@Test
//	public void testHeartBeatMu_NoResourceInfo() {
//		jdbcTemplate
//				.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','WORKING')");
//		jdbcTemplate
//				.update("insert into MU_CONTACTS(MU_ID,CONTACT_TS)values(1,111111)");
//		jdbcTemplate.update("commit");
//		String resourceInfo = "";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.MATCH_UNIT, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		PBHeartBeatResponse response = statusBean.heartbeat(component);
//		jdbcTemplate.update("commit");
//		List<Map<String, Object>> list = jdbcTemplate
//				.queryForList("select * from MU_CONTACTS");
//		Assert.assertEquals(1, list.size());
//		long l = 1424872591709l;
//		Assert.assertTrue(Long.parseLong(list.get(0).get("CONTACT_TS")
//				.toString()) > l);
//		Assert.assertEquals(1,
//				Integer.parseInt(list.get(0).get("MU_ID").toString()));
//		Assert.assertFalse(response.getWrongState());
//		Assert.assertTrue(contains("Component 192.168.1.1 has no ResourceInfo."));
//		jdbcTemplate.update("commit");
//	}
//
//	@Test
//	public void testHeartBeatMu_NoResourceInfo_DBHasSegDiffInfo() {
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate
//				.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','WORKING')");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,1,2,1,5)");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,2,2,5,5)");
//		jdbcTemplate.update("commit");
//		String resourceInfo = "";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.MATCH_UNIT, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		jdbcTemplate.update("commit");
//		PBHeartBeatResponse response = statusBean.heartbeat(component);
//		jdbcTemplate.update("commit");
//		Assert.assertFalse(response.getWrongState());
//		Assert.assertEquals(0, response.getSegmentUpdatesCount());
//	}
//
//	@Test
//	public void testHeartBeatMu_BiggerThanMaxSegVersionDiffs() {
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate
//				.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','WORKING')");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,1,2,1,5)");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,2,2,5,5)");
//
//		jdbcTemplate.update("commit");
//		String resourceInfo = "10,10,1,1,10-1,1,2005,2005||1/0";
//		;
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.MATCH_UNIT, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		jdbcTemplate.update("commit");
//		List<Map<String, Object>> listRUCPre = jdbcTemplate
//				.queryForList("select * from RESOURCE_UPDATE_COUNT");
//		PBHeartBeatResponse response = statusBean.heartbeat(component);
//		List<Map<String, Object>> listRUC = jdbcTemplate
//				.queryForList("select * from RESOURCE_UPDATE_COUNT");
//		if (listRUCPre.size() == 1) {
//			Assert.assertEquals(
//					1,
//					Integer.parseInt(listRUC.get(0).get("UPDATE_COUNT")
//							.toString())
//							- Integer.parseInt(listRUCPre.get(0)
//									.get("UPDATE_COUNT").toString()));
//		} else {
//			Assert.assertEquals(
//					1,
//					Integer.parseInt(listRUC.get(0).get("UPDATE_COUNT")
//							.toString()));
//		}
//		List<Map<String, Object>> pbList = jdbcTemplate
//				.queryForList("select * from person_biometrics");
//		Map<String, Object> pbMap = pbList.get(0);
//		Assert.assertEquals(1,
//				Integer.parseInt(pbMap.get("CORRUPTED_FLAG").toString()));
//		List<Map<String, Object>> list = jdbcTemplate
//				.queryForList("select * from MU_SEG_REPORTS");
//		Assert.assertEquals(1, list.size());
//		Assert.assertFalse(response.getWrongState());
//		Assert.assertEquals(1, response.getSegmentUpdatesCount());
//		Assert.assertEquals(1, response.getSegmentUpdates(0).getId());
//	}
//
//	@Test
//	public void testHeartBeatMu_segmentMapChangedIsTrue() {
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate
//				.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','WORKING')");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,1,2,1,5)");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,2,2,5,5)");
//
//		jdbcTemplate.update("commit");
//		String resourceInfo = "10,10,1,1,10-1,1,2,2||1/0";
//		;
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.MATCH_UNIT, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		jdbcTemplate.update("commit");
//		List<Map<String, Object>> listRUCPre = jdbcTemplate
//				.queryForList("select * from RESOURCE_UPDATE_COUNT");
//		PBHeartBeatResponse response = statusBean.heartbeat(component);
//		List<Map<String, Object>> listRUC = jdbcTemplate
//				.queryForList("select * from RESOURCE_UPDATE_COUNT");
//		if (listRUCPre.size() == 1) {
//			Assert.assertEquals(
//					1,
//					Integer.parseInt(listRUC.get(0).get("UPDATE_COUNT")
//							.toString())
//							- Integer.parseInt(listRUCPre.get(0)
//									.get("UPDATE_COUNT").toString()));
//		} else {
//			Assert.assertEquals(
//					1,
//					Integer.parseInt(listRUC.get(0).get("UPDATE_COUNT")
//							.toString()));
//		}
//		List<Map<String, Object>> pbList = jdbcTemplate
//				.queryForList("select * from person_biometrics");
//		Map<String, Object> pbMap = pbList.get(0);
//		Assert.assertEquals(1,
//				Integer.parseInt(pbMap.get("CORRUPTED_FLAG").toString()));
//		List<Map<String, Object>> list = jdbcTemplate
//				.queryForList("select * from MU_SEG_REPORTS");
//		Assert.assertEquals(1, list.size());
//		Assert.assertFalse(response.getWrongState());
//		Assert.assertEquals(1, response.getSegmentUpdatesCount());
//		Assert.assertEquals(1, response.getSegmentUpdates(0).getId());
//	}
//
//	@Test
//	public void testHeartBeatMu_RankIsNotNull() {
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate
//				.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','WORKING')");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,1,2,1,5)");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,2,2,5,5)");
//		jdbcTemplate
//				.update("insert into MU_SEGMENTS(MU_ID,SEGMENT_ID,RANK)values(1,1,1)");
//		jdbcTemplate.update("commit");
//		String resourceInfo = "10,10,1,1,10-1,1,1,1||1/0";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.MATCH_UNIT, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		jdbcTemplate.update("commit");
//		List<Map<String, Object>> listRUCPre = jdbcTemplate
//				.queryForList("select * from RESOURCE_UPDATE_COUNT");
//		PBHeartBeatResponse response = statusBean.heartbeat(component);
//		List<Map<String, Object>> listRUC = jdbcTemplate
//				.queryForList("select * from RESOURCE_UPDATE_COUNT");
//		if (listRUCPre.size() == 1) {
//			Assert.assertEquals(
//					1,
//					Integer.parseInt(listRUC.get(0).get("UPDATE_COUNT")
//							.toString())
//							- Integer.parseInt(listRUCPre.get(0)
//									.get("UPDATE_COUNT").toString()));
//		} else {
//			Assert.assertEquals(
//					1,
//					Integer.parseInt(listRUC.get(0).get("UPDATE_COUNT")
//							.toString()));
//		}
//		List<Map<String, Object>> pbList = jdbcTemplate
//				.queryForList("select * from person_biometrics");
//		Map<String, Object> pbMap = pbList.get(0);
//		Assert.assertEquals(1,
//				Integer.parseInt(pbMap.get("CORRUPTED_FLAG").toString()));
//		List<Map<String, Object>> list = jdbcTemplate
//				.queryForList("select * from MU_SEG_REPORTS");
//		Assert.assertEquals(1, list.size());
//		Assert.assertFalse(response.getWrongState());
//		Assert.assertEquals(SegmentAssignedStateType.SEGMENT_ASSIGNED, response
//				.getSegmentUpdates(0).getAssignedState());
//		Assert.assertEquals(1, response.getSegmentUpdatesCount());
//		Assert.assertEquals(1, response.getSegmentUpdates(0).getId());
//		Assert.assertEquals(2, response.getSegmentUpdates(0).getSyncItem()
//				.getCatUpInfo().getCatchUpItemsCount());
//	}
//
//	@Test
//	public void testHeartBeatMu_LastVersionIsNull() {
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate
//				.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','WORKING')");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,1,2,1,5)");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,2,2,5,5)");
//		/*
//		 * jdbcTemplate
//		 * .update("insert into MU_SEGMENTS(MU_ID,SEGMENT_ID,RANK)values(1,1,1)"
//		 * );
//		 */
//		jdbcTemplate.update("commit");
//		String resourceInfo = "10,10,1,1,10-12,1,1,1||1/0";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.MATCH_UNIT, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		jdbcTemplate.update("commit");
//		List<Map<String, Object>> listRUCPre = jdbcTemplate
//				.queryForList("select * from RESOURCE_UPDATE_COUNT");
//		PBHeartBeatResponse response = statusBean.heartbeat(component);
//		jdbcTemplate.update("commit");
//		List<Map<String, Object>> list = jdbcTemplate
//				.queryForList("select * from MU_SEG_REPORTS");
//		Assert.assertEquals(1, list.size());
//		List<Map<String, Object>> listRUC = jdbcTemplate
//				.queryForList("select * from RESOURCE_UPDATE_COUNT");
//		if (listRUCPre.size() == 1) {
//			Assert.assertEquals(
//					1,
//					Integer.parseInt(listRUC.get(0).get("UPDATE_COUNT")
//							.toString())
//							- Integer.parseInt(listRUCPre.get(0)
//									.get("UPDATE_COUNT").toString()));
//		} else {
//			Assert.assertEquals(
//					1,
//					Integer.parseInt(listRUC.get(0).get("UPDATE_COUNT")
//							.toString()));
//		}
//		List<Map<String, Object>> pbList = jdbcTemplate
//				.queryForList("select * from person_biometrics");
//		Map<String, Object> pbMap = pbList.get(0);
//		Assert.assertEquals(1,
//				Integer.parseInt(pbMap.get("CORRUPTED_FLAG").toString()));
//		List<Map<String, Object>> listMUSEG = jdbcTemplate
//				.queryForList("select * from MU_SEG_REPORTS");
//		Assert.assertEquals(1, listMUSEG.size());
//		Assert.assertFalse(response.getWrongState());
//		Assert.assertEquals(SegmentAssignedStateType.SEGMENT_DEFUNCT, response
//				.getSegmentUpdates(0).getAssignedState());
//		Assert.assertEquals(1, response.getSegmentUpdatesCount());
//		Assert.assertEquals(12, response.getSegmentUpdates(0).getId());
//		Assert.assertEquals(0, response.getSegmentUpdates(0).getSyncItem()
//				.getCatUpInfo().getCatchUpItemsCount());
//	}
//
//	@Test
//	public void testHeartBeatMu_IsNotDownloaded() {
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate
//				.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','WORKING')");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,1,2,1,5)");
//		jdbcTemplate
//				.update("insert into MU_SEG_REPORTS(MU_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION,SEGMENT_QUEUED_VERSION)values(1,2,2,5,5)");
//		jdbcTemplate
//				.update("insert into MU_SEGMENTS(MU_ID,SEGMENT_ID,RANK)values(1,1,1)");
//		jdbcTemplate.update("commit");
//		String resourceInfo = "10,10,1,1,10-12,1,1,1||1/0";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.MATCH_UNIT, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		jdbcTemplate.update("commit");
//		List<Map<String, Object>> listRUCPre = jdbcTemplate
//				.queryForList("select * from RESOURCE_UPDATE_COUNT");
//		PBHeartBeatResponse response = statusBean.heartbeat(component);
//		jdbcTemplate.update("commit");
//		List<Map<String, Object>> list = jdbcTemplate
//				.queryForList("select * from MU_SEG_REPORTS");
//		Assert.assertEquals(1, list.size());
//		List<Map<String, Object>> listRUC = jdbcTemplate
//				.queryForList("select * from RESOURCE_UPDATE_COUNT");
//		if (listRUCPre.size() == 1) {
//			Assert.assertEquals(
//					1,
//					Integer.parseInt(listRUC.get(0).get("UPDATE_COUNT")
//							.toString())
//							- Integer.parseInt(listRUCPre.get(0)
//									.get("UPDATE_COUNT").toString()));
//		} else {
//			Assert.assertEquals(
//					1,
//					Integer.parseInt(listRUC.get(0).get("UPDATE_COUNT")
//							.toString()));
//		}
//		List<Map<String, Object>> pbList = jdbcTemplate
//				.queryForList("select * from person_biometrics");
//		Map<String, Object> pbMap = pbList.get(0);
//		Assert.assertEquals(1,
//				Integer.parseInt(pbMap.get("CORRUPTED_FLAG").toString()));
//		List<Map<String, Object>> listMUSEG = jdbcTemplate
//				.queryForList("select * from MU_SEG_REPORTS");
//		Assert.assertEquals(1, listMUSEG.size());
//		Assert.assertFalse(response.getWrongState());
//		for (int i = 0; i < 2; i++) {
//			if (response.getSegmentUpdates(i).getId() == 12) {
//				Assert.assertEquals(SegmentAssignedStateType.SEGMENT_DEFUNCT,
//						response.getSegmentUpdates(i).getAssignedState());
//				Assert.assertEquals(0, response.getSegmentUpdates(0)
//						.getSyncItem().getCatUpInfo().getCatchUpItemsCount());
//			} else if (response.getSegmentUpdates(i).getId() == 1) {
//				Assert.assertEquals(SegmentAssignedStateType.SEGMENT_ASSIGNED,
//						response.getSegmentUpdates(i).getAssignedState());
//				Assert.assertEquals(0, response.getSegmentUpdates(i)
//						.getSyncItem().getCatUpInfo().getCatchUpItemsCount());
//				Assert.assertEquals("", response.getSegmentUpdates(i)
//						.getSyncItem().getDownload().getSource());
//			}
//		}
//	}
//
//	@Test
//	public void testHeartBeatDM() {
//		jdbcTemplate
//				.update("insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,CONTACT_URL,STATE,VERSION)values(1,'192.168.1.1','192.168.1.1','WORKING','1')");
//		jdbcTemplate
//				.update("insert into DM_SEG_REPORTS(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,1,1,1)");
//		jdbcTemplate
//				.update("insert into DM_SEGMENTS(DM_ID,SEGMENT_ID,RANK)values(1,1,1)");
//		jdbcTemplate.update("commit");
//		String resourceInfo = "10,10,1,1,10-1,1,1,2||1/0";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.DATA_MANAGER, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		PBHeartBeatResponse response = statusBean.heartbeat(component);
//		Assert.assertFalse(response.getWrongState());
//		// Assert.assertTrue(contains("Received heartbeat() from unique id '192.168.1.1', type 'DATA_MANAGER', at URL '192.168.1.1'"));
//	}
//
//	@Test
//	public void testHeartBeatDM_NotWORING() {
//		jdbcTemplate
//				.update("insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,CONTACT_URL,STATE,VERSION)values(1,'192.168.1.1','192.168.1.1','EXITED','1')");
//		jdbcTemplate
//				.update("insert into DM_SEG_REPORTS(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,1,1,1)");
//		jdbcTemplate
//				.update("insert into DM_SEGMENTS(DM_ID,SEGMENT_ID,RANK)values(1,1,1)");
//		jdbcTemplate.update("commit");
//		String resourceInfo = "10,10,1,1,10-1,1,1,2||1/0";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.DATA_MANAGER, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		PBHeartBeatResponse response = statusBean.heartbeat(component);
//		Assert.assertTrue(response.getWrongState());
//		Assert.assertTrue(contains("DM '1' heartBeat state is not in working state"));
//	}
//
//	@Test
//	public void testHeartBeatDM_NotExist() {
//		jdbcTemplate.update("commit");
//		String resourceInfo = "10,10,1,1,10-1,1,1,2||1/0";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.DATA_MANAGER, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		PBHeartBeatResponse response = statusBean.heartbeat(component);
//		Assert.assertTrue(response.getWrongState());
//		Assert.assertTrue(contains("findAndWarnState: (heartBeat) Data manager uniqueId: 192.168.1.1 not found in database."));
//	}
//
//	@Test
//	public void testHeartBeatDM_NoResourceInfo() {
//		jdbcTemplate
//				.update("insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,CONTACT_URL,STATE,VERSION)values(1,'192.168.1.1','192.168.1.1','WORKING','1')");
//		jdbcTemplate
//				.update("insert into DM_CONTACTS(DM_ID,CONTACT_TS)values(1,111111)");
//		jdbcTemplate.update("commit");
//		String resourceInfo = "";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.DATA_MANAGER, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		PBHeartBeatResponse response = statusBean.heartbeat(component);
//		jdbcTemplate.update("commit");
//		List<Map<String, Object>> list = jdbcTemplate
//				.queryForList("select * from DM_CONTACTS");
//		Assert.assertEquals(1, list.size());
//		long l = 1424872591709l;
//		Assert.assertTrue(Long.parseLong(list.get(0).get("CONTACT_TS")
//				.toString()) > l);
//		Assert.assertEquals(1,
//				Integer.parseInt(list.get(0).get("DM_ID").toString()));
//		Assert.assertFalse(response.getWrongState());
//		Assert.assertTrue(contains("Component 192.168.1.1 has no ResourceInfo."));
//		jdbcTemplate.update("commit");
//	}
//
//	@Test
//	public void testHeartBeatDM_NoResourceInfo_DBHasSegDiffInfo() {
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate
//				.update("insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','WORKING')");
//		jdbcTemplate
//				.update("insert into DM_SEG_REPORTS(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,1,2,1)");
//		jdbcTemplate
//				.update("insert into DM_SEG_REPORTS(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,2,2,5)");
//		jdbcTemplate.update("commit");
//		String resourceInfo = "";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.DATA_MANAGER, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		jdbcTemplate.update("commit");
//		PBHeartBeatResponse response = statusBean.heartbeat(component);
//		jdbcTemplate.update("commit");
//		Assert.assertFalse(response.getWrongState());
//		Assert.assertEquals(0, response.getSegmentUpdatesCount());
//	}
//
//	@Test
//	public void testHeartBeatDM_RankIsNotNull() {
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate
//				.update("insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','WORKING')");
//		jdbcTemplate
//				.update("insert into DM_SEG_REPORTS(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,1,2,1)");
//		jdbcTemplate
//				.update("insert into DM_SEG_REPORTS(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,2,2,5)");
//		jdbcTemplate
//				.update("insert into DM_SEGMENTS(DM_ID,SEGMENT_ID,RANK)values(1,1,1)");
//		jdbcTemplate.update("commit");
//		String resourceInfo = "10,10,1,1,10-1,1,1,1||1/0";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.DATA_MANAGER, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		jdbcTemplate.update("commit");
//		PBHeartBeatResponse response = statusBean.heartbeat(component);
//		List<Map<String, Object>> pbList = jdbcTemplate
//				.queryForList("select * from person_biometrics");
//		Map<String, Object> pbMap = pbList.get(0);
//		Assert.assertEquals(1,
//				Integer.parseInt(pbMap.get("CORRUPTED_FLAG").toString()));
//		List<Map<String, Object>> list = jdbcTemplate
//				.queryForList("select * from DM_SEG_REPORTS");
//		Assert.assertEquals(1, list.size());
//		Assert.assertFalse(response.getWrongState());
//		Assert.assertEquals(SegmentAssignedStateType.SEGMENT_ASSIGNED, response
//				.getSegmentUpdates(0).getAssignedState());
//		Assert.assertEquals(1, response.getSegmentUpdatesCount());
//		Assert.assertEquals(1, response.getSegmentUpdates(0).getId());
//		Assert.assertEquals(2, response.getSegmentUpdates(0).getSyncItem()
//				.getCatUpInfo().getCatchUpItemsCount());
//	}
//
//	@Test
//	public void testHeartBeatDm_LastVersionIsNull() {
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate
//				.update("insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','WORKING')");
//		jdbcTemplate
//				.update("insert into DM_SEG_REPORTS(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,1,2,1)");
//		jdbcTemplate
//				.update("insert into DM_SEG_REPORTS(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,2,2,5)");
//		jdbcTemplate.update("commit");
//		String resourceInfo = "10,10,1,1,10-12,1,1,1||1/0";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.DATA_MANAGER, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		jdbcTemplate.update("commit");
//		PBHeartBeatResponse response = statusBean.heartbeat(component);
//		jdbcTemplate.update("commit");
//		List<Map<String, Object>> list = jdbcTemplate
//				.queryForList("select * from DM_SEG_REPORTS");
//		Assert.assertEquals(1, list.size());
//		List<Map<String, Object>> pbList = jdbcTemplate
//				.queryForList("select * from person_biometrics");
//		Map<String, Object> pbMap = pbList.get(0);
//		Assert.assertEquals(1,
//				Integer.parseInt(pbMap.get("CORRUPTED_FLAG").toString()));
//		List<Map<String, Object>> listDMSEG = jdbcTemplate
//				.queryForList("select * from DM_SEG_REPORTS");
//		Assert.assertEquals(1, listDMSEG.size());
//		Map<String, Object> map = listDMSEG.get(0);
//		Assert.assertEquals(12,
//				Integer.parseInt(map.get("SEGMENT_ID").toString()));
//		Assert.assertFalse(response.getWrongState());
//		Assert.assertEquals(SegmentAssignedStateType.SEGMENT_DEFUNCT, response
//				.getSegmentUpdates(0).getAssignedState());
//		Assert.assertEquals(1, response.getSegmentUpdatesCount());
//		Assert.assertEquals(12, response.getSegmentUpdates(0).getId());
//		Assert.assertEquals(0, response.getSegmentUpdates(0).getSyncItem()
//				.getCatUpInfo().getCatchUpItemsCount());
//	}
//
//	@Test
//	public void testHeartBeatDm_IsNotDownloaded() {
//		URL url = this.getClass().getResource("insert_seg_change_log.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate
//				.update("insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,STATE)values(1,'192.168.1.1','WORKING')");
//		jdbcTemplate
//				.update("insert into DM_SEG_REPORTS(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,1,2,1)");
//		jdbcTemplate
//				.update("insert into DM_SEG_REPORTS(DM_ID,SEGMENT_ID,STATUS,SEGMENT_VERSION)values(1,2,2,5)");
//		jdbcTemplate
//				.update("insert into DM_SEGMENTS(DM_ID,SEGMENT_ID,RANK)values(1,1,1)");
//		jdbcTemplate.update("commit");
//		String resourceInfo = "10,10,1,1,10-12,1,1,1||1/0";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.DATA_MANAGER, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		jdbcTemplate.update("commit");
//		PBHeartBeatResponse response = statusBean.heartbeat(component);
//		jdbcTemplate.update("commit");
//		List<Map<String, Object>> list = jdbcTemplate
//				.queryForList("select * from DM_SEG_REPORTS");
//		Assert.assertEquals(1, list.size());
//		List<Map<String, Object>> pbList = jdbcTemplate
//				.queryForList("select * from person_biometrics");
//		Map<String, Object> pbMap = pbList.get(0);
//		Assert.assertEquals(1,
//				Integer.parseInt(pbMap.get("CORRUPTED_FLAG").toString()));
//		List<Map<String, Object>> listMUSEG = jdbcTemplate
//				.queryForList("select * from DM_SEG_REPORTS");
//		Assert.assertEquals(1, listMUSEG.size());
//		Assert.assertFalse(response.getWrongState());
//		for (int i = 0; i < 2; i++) {
//			if (response.getSegmentUpdates(i).getId() == 12) {
//				Assert.assertEquals(SegmentAssignedStateType.SEGMENT_DEFUNCT,
//						response.getSegmentUpdates(i).getAssignedState());
//				Assert.assertEquals(0, response.getSegmentUpdates(0)
//						.getSyncItem().getCatUpInfo().getCatchUpItemsCount());
//			} else if (response.getSegmentUpdates(i).getId() == 1) {
//				Assert.assertEquals(SegmentAssignedStateType.SEGMENT_ASSIGNED,
//						response.getSegmentUpdates(i).getAssignedState());
//				Assert.assertEquals(0, response.getSegmentUpdates(i)
//						.getSyncItem().getCatUpInfo().getCatchUpItemsCount());
//				Assert.assertEquals("", response.getSegmentUpdates(i)
//						.getSyncItem().getDownload().getSource());
//			}
//		}
//	}
//
//	@Test
//	public void testHeartBeatMR() {
//		jdbcTemplate
//				.update("insert into MAP_REDUCERS(MR_ID,RING_LOCATION,UNIQUE_ID,STATE)values(1,1,'192.168.1.1','WORKING')");
//		jdbcTemplate
//				.update("insert into MR_CONTACTS(MR_ID,CONTACT_TS)values(1,111)");
//		jdbcTemplate.update("commit");
//		String resourceInfo = "10,10,1,1,10-1,1,1,1||1/0";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.MAP_REDUCER, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		PBHeartBeatResponse response = statusBean.heartbeat(component);
//		Assert.assertFalse(response.getWrongState());
//	}
//
//	@Test
//	public void testHeartBeatMR_NotExistMR() {
//		String resourceInfo = "10,10,1,1,10-1,1,1,1||1/0";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.MAP_REDUCER, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		PBHeartBeatResponse response = statusBean.heartbeat(component);
//		Assert.assertTrue(response.getWrongState());
//	}
//
//	@Test
//	public void testHeartBeatMR_NotWorking() {
//		jdbcTemplate
//				.update("insert into MAP_REDUCERS(MR_ID,RING_LOCATION,UNIQUE_ID,STATE)values(1,1,'192.168.1.1','EXITED')");
//		jdbcTemplate
//				.update("insert into MR_CONTACTS(MR_ID,CONTACT_TS)values(1,111)");
//		jdbcTemplate.update("commit");
//		String resourceInfo = "10,10,1,1,10-1,1,1,1||1/0";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.MAP_REDUCER, "1", "192.168.1.1", "192.168.1.1",
//				resourceInfo);
//		PBHeartBeatResponse response = statusBean.heartbeat(component);
//		Assert.assertTrue(response.getWrongState());
//	}
//
//	@Test
//	public void testHeartBeat_SYSTEM_MANAGER() {
//		jdbcTemplate
//				.update("insert into MAP_REDUCERS(MR_ID,RING_LOCATION,UNIQUE_ID,STATE)values(1,1,'192.168.1.1','EXITED')");
//		jdbcTemplate
//				.update("insert into MR_CONTACTS(MR_ID,CONTACT_TS)values(1,111)");
//		jdbcTemplate.update("commit");
//		String resourceInfo = "10,10,1,1,10-1,1,5,5||1";
//		PBComponentInfo component = ProtobufHelper.PBComponentInfo(
//				ComponentType.SYSTEM_MANAGER, "1", "192.168.1.1",
//				"192.168.1.1", resourceInfo);
//		jdbcTemplate.update("commit");
//		PBHeartBeatResponse response = statusBean.heartbeat(component);
//		Assert.assertFalse(response.getWrongState());
//
//	}
//
//	@Test
//	public void testExit_WrongType() {
//		PBExitRequest exitRequest = PBExitRequest.newBuilder()
//				.setComponent(ComponentType.MATCH_MANAGER).setId(1).build();
//		try {
//			statusBean.exit(exitRequest);
//		} catch (Exception e) {
//			// TODO: handle exception
//			Assert.assertTrue(e instanceof ArgumentException);
//			ArgumentException argumentException = (ArgumentException) e;
//			Assert.assertEquals("814006301", argumentException.getErrorCode());
//			Assert.assertEquals(
//					"PBComponentInfo.ComponentType(MATCH_MANAGER) is not support..",
//					argumentException.getDescription());
//		}
//	}
//
//	@Test
//	public void testExit_MU_NotFound() {
//		PBExitRequest exitRequest = PBExitRequest.newBuilder()
//				.setComponent(ComponentType.MATCH_UNIT).setId(1).build();
//		statusBean.exit(exitRequest);
//		Assert.assertTrue(contains("Mu exit, but Mu 1 is not exist in match unit.."));
//	}
//
//	@Test
//	public void testExit_Mu_NoLotJobId() {
//		new MockUp<FeJobDoneLogger>() {
//			@Mock
//			public void info(long jobId) {
//				return;
//			}
//		};
//		URL url = this.getClass().getResource("insert_fe_job_queue1.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate.update("commit");
//		PBExitRequest exitRequest = PBExitRequest.newBuilder()
//				.setComponent(ComponentType.MATCH_UNIT).setId(1).build();
//
//		jdbcTemplate.update("commit");
//		List<Map<String, Object>> listFLJs = jdbcTemplate
//				.queryForList("select * from FE_LOT_JOBS");
//		Assert.assertEquals(1, listFLJs.size());
//		statusBean.exit(exitRequest);
//		List<Map<String, Object>> list = jdbcTemplate
//				.queryForList("select * from MATCH_UNITS");
//		Assert.assertEquals(1, list.size());
//		Assert.assertEquals("EXITED", list.get(0).get("STATE"));
//
//		List<Map<String, Object>> listFJQ = jdbcTemplate
//				.queryForList("select * from FE_JOB_QUEUE");
//		Assert.assertEquals(2, listFJQ.size());
//		for (int i = 0; i < 2; i++) {
//			Map<String, Object> map = listFJQ.get(i);
//			if (20 == Integer.parseInt(map.get("JOB_ID").toString())) {
//				Assert.assertEquals(1,
//						Integer.parseInt(map.get("FAILURE_COUNT").toString()));
//			} else {
//				Assert.assertEquals(2,
//						Integer.parseInt(map.get("FAILURE_COUNT").toString()));
//			}
//			Assert.assertEquals(2,
//					Integer.parseInt(map.get("JOB_STATE").toString()));
//		}
//		List<Map<String, Object>> listFLJ = jdbcTemplate
//				.queryForList("select * from FE_LOT_JOBS");
//		Assert.assertEquals(1, listFLJ.size());
//		List<Map<String, Object>> listFJFR = jdbcTemplate
//				.queryForList("select * from FE_JOB_FAILURE_REASONS");
//		Assert.assertEquals(2, listFJFR.size());
//		for (int i = 0; i < 2; i++) {
//			Map<String, Object> map = listFJFR.get(i);
//			if (20 == Integer.parseInt(map.get("JOB_ID").toString())) {
//				Assert.assertEquals(
//						"Status Service (ExtractJob is failed due to The MU which was assigned this extract job was Exited or Re-Entered. (ExtractJobId:20).",
//						map.get("REASON"));
//			} else {
//				Assert.assertEquals(21,
//						Integer.parseInt(map.get("JOB_ID").toString()));
//			}
//			Assert.assertEquals(1,
//					Integer.parseInt(map.get("MU_ID").toString()));
//		}
//	}
//
//	@Test
//	public void testExit_Mu() {
//		new MockUp<FeJobDoneLogger>() {
//			@Mock
//			public void info(long jobId) {
//				return;
//			}
//		};
//		URL url = this.getClass().getResource("insert_fe_job_queue.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate.update("commit");
//		PBExitRequest exitRequest = PBExitRequest.newBuilder()
//				.setComponent(ComponentType.MATCH_UNIT).setId(1).build();
//
//		jdbcTemplate.update("commit");
//		List<Map<String, Object>> listFLJs = jdbcTemplate
//				.queryForList("select * from FE_LOT_JOBS");
//		Assert.assertEquals(1, listFLJs.size());
//		statusBean.exit(exitRequest);
//		List<Map<String, Object>> list = jdbcTemplate
//				.queryForList("select * from MATCH_UNITS");
//		Assert.assertEquals(1, list.size());
//		Assert.assertEquals("EXITED", list.get(0).get("STATE"));
//
//		List<Map<String, Object>> listFJQ = jdbcTemplate
//				.queryForList("select * from FE_JOB_QUEUE");
//		Assert.assertEquals(2, listFJQ.size());
//		for (int i = 0; i < 2; i++) {
//			Map<String, Object> map = listFJQ.get(i);
//			if (20 == Integer.parseInt(map.get("JOB_ID").toString())) {
//				Assert.assertEquals(1,
//						Integer.parseInt(map.get("FAILURE_COUNT").toString()));
//			} else {
//				Assert.assertEquals(2,
//						Integer.parseInt(map.get("FAILURE_COUNT").toString()));
//			}
//			Assert.assertEquals(2,
//					Integer.parseInt(map.get("JOB_STATE").toString()));
//		}
//		List<Map<String, Object>> listFLJ = jdbcTemplate
//				.queryForList("select * from FE_LOT_JOBS");
//		Assert.assertEquals(0, listFLJ.size());
//		List<Map<String, Object>> listFJFR = jdbcTemplate
//				.queryForList("select * from FE_JOB_FAILURE_REASONS");
//		Assert.assertEquals(2, listFJFR.size());
//		for (int i = 0; i < 2; i++) {
//			Map<String, Object> map = listFJFR.get(i);
//			if (20 == Integer.parseInt(map.get("JOB_ID").toString())) {
//				Assert.assertEquals(
//						"Status Service (ExtractJob is failed due to The MU which was assigned this extract job was Exited or Re-Entered. (ExtractJobId:20).",
//						map.get("REASON"));
//			} else {
//				Assert.assertEquals(21,
//						Integer.parseInt(map.get("JOB_ID").toString()));
//			}
//			Assert.assertEquals(1,
//					Integer.parseInt(map.get("MU_ID").toString()));
//		}
//	}
//
//	@Test
//	public void testExit_MR_NotFound() {
//		PBExitRequest exitRequest = PBExitRequest.newBuilder()
//				.setComponent(ComponentType.MAP_REDUCER).setId(1).build();
//		statusBean.exit(exitRequest);
//		Assert.assertTrue(contains("MR exit, but MR 1 is not exist in Map Reducer.."));
//	}
//
//	@Test
//	public void testExit_MR() throws Exception {
//		URL url = this.getClass().getResource("insert_container_jobs.sql");
//		executeSqlScript("file:///" + url.getPath(), false);
//		jdbcTemplate.update("commit");
//		PBExitRequest exitRequest = PBExitRequest.newBuilder()
//				.setComponent(ComponentType.MAP_REDUCER).setId(1).build();
//		statusBean.exit(exitRequest);
//		List<Map<String, Object>> list = jdbcTemplate
//				.queryForList("select * from container_jobs");
//
//		Map<String, Object> map = list.get(0);
//		Assert.assertEquals(2,
//				Integer.parseInt(map.get("JOB_STATE").toString()));
//		List<Map<String, Object>> listJQ = jdbcTemplate
//				.queryForList("select * from JOB_QUEUE");
//
//		Map<String, Object> mapJQ = listJQ.get(0);
//		Assert.assertEquals(3,
//				Integer.parseInt(mapJQ.get("FAILURE_COUNT").toString()));
//		Assert.assertEquals(0,
//				Integer.parseInt(mapJQ.get("REMAIN_JOBS").toString()));
//	}
//
//	@Test
//	public void testExit_DM_NotFound() {
//		PBExitRequest exitRequest = PBExitRequest.newBuilder()
//				.setComponent(ComponentType.DATA_MANAGER).setId(1).build();
//		statusBean.exit(exitRequest);
//		Assert.assertTrue(contains("DM exit, but DM 1 is not exist in Data Manager.."));
//	}
//
//	@Test
//	public void testExit_DM() {
//		jdbcTemplate
//				.update("insert into DATA_MANAGERS(DM_ID,UNIQUE_ID,STATE) values(1,1,'WORKING')");
//		jdbcTemplate.update("commit");
//		PBExitRequest exitRequest = PBExitRequest.newBuilder()
//				.setComponent(ComponentType.DATA_MANAGER).setId(1).build();
//
//		jdbcTemplate.update("commit");
//		statusBean.exit(exitRequest);
//		List<Map<String, Object>> list = jdbcTemplate
//				.queryForList("select * from DATA_MANAGERS");
//		Assert.assertEquals(1, list.size());
//		Assert.assertEquals("EXITED", list.get(0).get("STATE"));
//	}
//
//	private boolean contains(String msg) {
//		return StringUtils.contains(outContent.toString(), msg);
//	}
//}
