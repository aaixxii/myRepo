package jp.co.nec.aim.mm.partition;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import javax.persistence.EntityManager;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.constants.JNDIConstants;
import jp.co.nec.aim.mm.dao.SystemInitDao;
import jp.co.nec.aim.mm.util.JndiLookup;

public class PartitionUtil {
	
	 private SystemInitDao systemInitDao;	
	
	private static final PartitionUtil INSTANCE = new PartitionUtil();
	private static final Logger logger = LoggerFactory.getLogger(PartitionUtil.class);
			
	
	public static PartitionUtil getInstance() {
		return INSTANCE;
	}
	
	private PartitionUtil() {
		EntityManager entityManager = JndiLookup.lookUp(JNDIConstants.EntityManagerName, EntityManager.class);	
		DataSource dataSource = JndiLookup.lookUp(JNDIConstants.DataSourceName,DataSource.class);
		systemInitDao = new SystemInitDao(entityManager);	
		
	}	
	
	public  long caculateHashAtThisToday(LocalDate thisDay) {
		Long saveDays = systemInitDao.getSegChangeLogSaveDays();
		Long adjust = systemInitDao.getInUsingAdjust();
		LocalDate epoch = LocalDate.ofEpochDay(0);
		 long epochDays = ChronoUnit.DAYS.between(epoch, thisDay);
		return (epochDays + adjust.longValue()) % (saveDays.longValue());
	}	
	
	public long caculateNewAdjustAtThisDay(long newN, LocalDate firstAddDay) {
		Long oldSaveDays = systemInitDao.getSegChangeLogSaveDays();		
		long firstAddDayHashValue = caculateHashAtThisToday(firstAddDay);
		long dbHashValue = 1;
		if (firstAddDayHashValue != dbHashValue) {
			logger.error("The p_no hash value may have mistake!");
		}
		LocalDate epoch = LocalDate.ofEpochDay(0);
		long epochDays = ChronoUnit.DAYS.between(epoch, firstAddDay);
		long quotient = epochDays/oldSaveDays.longValue();
		long deltaX = oldSaveDays * quotient + firstAddDayHashValue - epochDays;
		long X = (epochDays + deltaX) % oldSaveDays;
		long Y = epochDays % newN;		
		long adjustNew = (X - Y + newN) % newN;			
		return adjustNew;
		//long hashNew = (epochDays + adjustNew) % newN;
	}

}
