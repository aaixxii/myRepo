package jp.co.nec.aim.mm.constants;

/**
 * AimInfo with reason code and error message
 * 
 * @author liuyq
 * 
 */
public enum AimInfo {

	/** Status Information related **/
	COMPONENT_ENTER_EVENT(Type.INFORMATION, D1.APPLICATIONPROGRAMS,
			Module.STATUS, "100", InfoMessage.COMPONENT_ENTER_INFO, "ENTER"), COMPONENT_EXIT_EVENT(
			Type.INFORMATION, D1.APPLICATIONPROGRAMS, Module.STATUS, "101",
			InfoMessage.COMPONENT_EXIT_INFO, "EXIT"),

	/** MM_START_UP **/
	MM_START_UP(Type.INFORMATION, D1.APPLICATIONPROGRAMS, Module.MM_INIT,
			"102", InfoMessage.MM_START_UP_INFO, "MM_STARTUP");

	/**
	 * append the info code
	 * 
	 * @return the info code
	 */
	public String getInfoCode() {
		StringBuffer code = new StringBuffer();
		code.append(getMessageType().getErrorCode());
		code.append(Component.MATCHMANAGER.getErrorCode());
		code.append(getD1().getErrorCode());
		code.append(getD2().getErrorCode());
		code.append(getD3());
		return code.toString();
	}

	private String message; // error message

	private Type messageType;
	private D1 d1;
	private Module d2;
	private String d3;
	private String eventType;

	/**
	 * AimInfo
	 * 
	 * @param errorCode
	 * @param message
	 */
	private AimInfo(Type messageType, D1 d1, Module d2, String d3,
			String message, String eventType) {
		this.messageType = messageType;
		this.d1 = d1;
		this.d2 = d2;
		this.d3 = d3;
		this.setMessage(message);
		this.setEventType(eventType);
	}

	public Type getMessageType() {
		return messageType;
	}

	public void setMessageType(Type messageType) {
		this.messageType = messageType;
	}

	public D1 getD1() {
		return d1;
	}

	public void setD1(D1 d1) {
		this.d1 = d1;
	}

	public Module getD2() {
		return d2;
	}

	public void setD2(Module d2) {
		this.d2 = d2;
	}

	public String getD3() {
		return d3;
	}

	public void setD3(String d3) {
		this.d3 = d3;
	}

	public String getMessage() {

		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public static boolean isErrorCode(String code) {
		return code.charAt(0) == '8';
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

}
