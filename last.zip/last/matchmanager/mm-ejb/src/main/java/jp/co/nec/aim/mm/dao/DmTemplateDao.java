package jp.co.nec.aim.mm.dao;

import java.util.Map;
import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;

public class DmTemplateDao {

	private JdbcTemplate jdbcTemplate;

	public DmTemplateDao(DataSource ds) {
		jdbcTemplate = new JdbcTemplate(ds);
	}
	
	private static final String sql = "select ps.BIOMETRICS_ID s.SEGMENT_ID from PERSON_BIOMETRICS ps SEGMENTS s where ps.EXTERNAL_ID=? and  ps.BIOMETRICS_ID BETWEEN s.BIO_ID_START s.BIO_ID_START";
	
	public String getBioIdByRefId(String refId) {
		Map<String, Object> resltMap = jdbcTemplate.queryForMap(sql, new Object[] {refId});
		Long bioId = (Long) resltMap.get("BIOMETRICS_ID");
		Long segId = (Long) resltMap.get("SEGMENT_ID");
		return segId.toString() + ":" +  bioId.toString();		
	}
}
