package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the SYSTEM_MANAGERS database table.
 * 
 */
@Entity
@Table(name = "SYSTEM_MANAGERS")
@NamedQuery(name = "SystemManagerEntity.findAll", query = "SELECT s FROM SystemManagerEntity s")
public class SystemManagerEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "SM_ID")
	private long smId;

	@Column(name = "CONTACT_URL")
	private String contactUrl;

	@Column(name = "\"STATE\"")
	@Enumerated(EnumType.STRING)
	private UnitState state;

	@Column(name = "UNIQUE_ID")
	private String uniqueId;

	@Column(name = "\"VERSION\"")
	private String version;

	public SystemManagerEntity() {
	}

	public long getSmId() {
		return this.smId;
	}

	public void setSmId(long smId) {
		this.smId = smId;
	}

	public String getContactUrl() {
		return this.contactUrl;
	}

	public void setContactUrl(String contactUrl) {
		this.contactUrl = contactUrl;
	}

	public UnitState getState() {
		return this.state;
	}

	public void setState(UnitState state) {
		this.state = state;
	}

	public String getUniqueId() {
		return this.uniqueId;
	}

	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

	public String getVersion() {
		return this.version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

}