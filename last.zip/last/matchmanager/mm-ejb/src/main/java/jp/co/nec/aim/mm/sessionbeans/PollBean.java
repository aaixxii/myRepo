package jp.co.nec.aim.mm.sessionbeans;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import com.google.common.collect.Maps;

import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResultItem;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.EventLogLevel;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.dao.CommitDao;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.FEJobDao;
import jp.co.nec.aim.mm.dao.FunctionDao;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.dao.JobPurgerDao;
import jp.co.nec.aim.mm.dao.MMEventsDao;
import jp.co.nec.aim.mm.dao.MatchManagerDao;
import jp.co.nec.aim.mm.dao.MuLoadDao;
import jp.co.nec.aim.mm.dao.RUCDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.dao.UnitDao;
import jp.co.nec.aim.mm.entities.ContainerJobEntity;
import jp.co.nec.aim.mm.entities.DmServiceEntity;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.entities.FunctionTypeEntity;
import jp.co.nec.aim.mm.entities.JobQueueEntity;
import jp.co.nec.aim.mm.entities.MapReducerEntity;
import jp.co.nec.aim.mm.entities.MatchManagerEntity;
import jp.co.nec.aim.mm.entities.MatchUnitEntity;
import jp.co.nec.aim.mm.entities.UnitState;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.jms.NotifierEnum;
import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.procedure.FetchTimeoutJobProcedure;
import jp.co.nec.aim.mm.sessionbeans.pojo.AimServiceState;
import jp.co.nec.aim.mm.sessionbeans.pojo.EventSender;
import jp.co.nec.aim.mm.sessionbeans.pojo.ExceptionSender;
import jp.co.nec.aim.mm.sessionbeans.pojo.ExtractJobHandler;
import jp.co.nec.aim.mm.sessionbeans.pojo.InquiryJobHandler;
import jp.co.nec.aim.mm.util.CollectionsUtil;
import jp.co.nec.aim.mm.util.StopWatch;
import jp.co.nec.aim.mm.util.XmlUtil;

/**
 * @author mozj
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class PollBean {
	private static Logger log = LoggerFactory.getLogger(PollBean.class);
	private static Logger slbLog = LoggerFactory.getLogger("slb");
	public static final int MAX_TIMED_OUT_JOB_BATCH = 1000;

	@PersistenceContext(unitName = "AIMDB")
	private EntityManager manager;
	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;

	@EJB
	private DefragBean defragBean;
	private DateDao dateDao;
	private MatchManagerDao mmDao;
	private MMEventsDao mmeDao;
	private SystemConfigDao sysConfigDao;
	private UnitDao unitDao;
	private InquiryJobDao inquiryJobDao;
	private FEJobDao extractJobDao;
	private JobPurgerDao jobPurgerDao;	
	private FunctionDao functionDao;
	private MuLoadDao muLoadDao;

	//private FindUnaggregatedJobProcedure unMergedProcedure;
	private FetchTimeoutJobProcedure timeoutJobProcedure;
	private ExtractJobHandler extractJobHandler;
	private InquiryJobHandler inquiryJobHandler;
	private ExceptionSender exceptionSender;
	private EventSender eventSender;
	private JdbcTemplate jdbcTemplate;
	private CommitDao commitDao;
	private RUCDao rucDao;

	public PollBean() {
		// zero arg ctor for container
	}

	@PostConstruct
	public void init() {
		dateDao = new DateDao(dataSource);
		mmDao = new MatchManagerDao(manager);
		mmeDao = new MMEventsDao(manager);
		sysConfigDao = new SystemConfigDao(manager);
		unitDao = new UnitDao(manager);
		inquiryJobDao = new InquiryJobDao(manager);
		extractJobDao = new FEJobDao(manager);
		jobPurgerDao = new JobPurgerDao(manager);
		
		functionDao = new FunctionDao(manager);
		muLoadDao = new MuLoadDao(dataSource);

		//unMergedProcedure = new FindUnaggregatedJobProcedure(dataSource);
		timeoutJobProcedure = new FetchTimeoutJobProcedure(dataSource);
		extractJobHandler = new ExtractJobHandler(manager, dataSource);				
		inquiryJobHandler = new InquiryJobHandler(manager, dataSource);
				
		exceptionSender = new ExceptionSender();
		eventSender = new EventSender();
		jdbcTemplate = new JdbcTemplate(dataSource);
		commitDao = new CommitDao(dataSource);
		rucDao = new RUCDao(dataSource);

		log.debug("CNTR: PollBean init");
	}

//	public void aggregateJob() {
//		if (log.isDebugEnabled()) {
//			log.debug("About to check for unaggregated jobs...");
//		}
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			TimeHelper th = new TimeHelper("aggregateJob");
//			th.t();
//
//			List<Long> jobIds = unMergedProcedure.execute();
//			for (Long jobId : jobIds) {
//				aggregator.doAggregation(jobId.longValue());
//			}
//			log.debug("findUnaggregatedJobs found " + jobIds.size()
//					+ " jobs to aggregate.");
//			th.t();
//			if (log.isDebugEnabled()) {
//				log.debug(th.message());
//			}
//		} catch (DataAccessException ex) {
//			String message = "DataAccessException when Clear Map Reduces";
//			log.error(message, ex);			
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), Thread
//					.currentThread().getStackTrace()[1].getMethodName(),
//					stopWatch.elapsedTime());
//		}
//		if (log.isDebugEnabled()) {
//			log.debug("Finished unaggregated jobs check.");
//		}
//	}

	public void defrag() {
		log.info("Defragmenting hypersonic database file.");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		try {
			defragBean.defrag();
		} finally {
			stopWatch.stop();
			PerformanceLogger.log(getClass().getSimpleName(), Thread
					.currentThread().getStackTrace()[1].getMethodName(),
					stopWatch.elapsedTime());
		}
		log.info("Done defragmenting hypersonic database file.");
	}

	public void loadBalance() {
		slbLog.debug("Ready to send event to segment load balancing.");
		/* send Jms to SLB */
		JmsSender.getInstance().sendToSLB(NotifierEnum.PollBean, "time driven");
		slbLog.debug("Send Segment load balancing event complete.");
	}

	public void poll() {
		log.debug("poll() is called.");
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		try {
			boolean flag = heartBeatTimeout();

			topLevelJobTimeout();

			containerJobTimeout();

			extractLotJobTimeout();
		

			if (flag) {
				/* send Jms to SLB */
				JmsSender.getInstance().sendToSLB(NotifierEnum.PollBean,
						"Timeout(MU, DM, Defrag)");
			}
		} finally {
			stopWatch.stop();
			PerformanceLogger.log(getClass().getSimpleName(), Thread
					.currentThread().getStackTrace()[1].getMethodName(),
					stopWatch.elapsedTime());
		}
	}

	private void topLevelJobTimeout() {
		try {
			List<Long> jobIds = timeoutJobProcedure.execute();

			if (!CollectionsUtil.isEmpty(jobIds)) {
				for (Long jobId : jobIds) {

					JobQueueEntity job = manager.find(JobQueueEntity.class,
							jobId);
					logTopLevelJobTimeout(job);

					List<ContainerJobEntity> cJobList = inquiryJobDao
							.getAllContainerJob(jobId);
					if (CollectionsUtil.isEmpty(cJobList)) {
						log.warn("Top Level job has no Container Job");
						continue;
					}
					ContainerJobEntity cJob = cJobList.get(0);
					try {										
						String faildResult = null;
								try {
									AimError timeoutErr = AimError.JOB_TIMEOUT;
									faildResult = XmlUtil.dom4jCreateFaildXml(job.getRequestId(), timeoutErr.getUidCode());
								} catch (IOException e) {
									faildResult = e.getMessage();
								}
						inquiryJobHandler.failInquiryJob(
								cJob.getContainerJobId(),
								"1",
								"is dead due to Top Level Job time out",
								faildResult,
								dateDao.getReasonTime());

					} catch (AimRuntimeException e) {
						String message = "AimRuntimeException during poll(): ContainerJob "
								+ cJob.getContainerJobId()
								+ " is dead due to Top Level Job time out";
						log.error(message, e);
						exceptionSender.sendAimException(
								AimError.INQ_INTERNAL.getErrorCode(), message,
								cJob.getContainerJobId(), jobId,
								cJob.getMrId(), e);
					}
				}
			} else {
				if (log.isDebugEnabled()) {
					log.debug("timeoutJobProcedure.execute() found no timeout topLevelJob");
				}
			}
		} catch (DataAccessException ex) {
			String message = "DataAccessException when Top Level Job time out";
			log.error(message, ex);
		} catch (SQLException e) {
			String message = "SQLException when Top Level Job time out";
			log.error(message, e);
		}

	}

	private boolean heartBeatTimeout() {
		int heartbeatTimeout = sysConfigDao
				.getMMPropertyInt(MMConfigProperty.HEARTBEAT_TIMEOUT);
		if (0 <= heartbeatTimeout) {
			if (mmeDao.isMatchManagerAlive(heartbeatTimeout)) {
				mmHeartBeatTimeout();

				boolean dmTimeOut = dmHeartBeatTimeout();

				boolean muTimeOut = muHeartBeatTimeout();

				mrHeartBeatTimeout();

				if (muTimeOut || dmTimeOut) {
					return true;
				}

			} else {
				if (log.isDebugEnabled()) {
					log.debug("It has not passed " + heartbeatTimeout
							+ " msec since MM started. Skip heartBeatTimeout()");
				}
			}
		} else {
			log.warn(MMConfigProperty.HEARTBEAT_TIMEOUT.name()
					+ " is negative, " + heartbeatTimeout);
		}
		return false;
	}

	private void mmHeartBeatTimeout() {
		if (log.isDebugEnabled()) {
			log.debug("Querying for match managers timed out due to heartbeat...");
		}
		List<MatchManagerEntity> deadMMs = mmDao.listDeadMMs();
		for (MatchManagerEntity deadMM : deadMMs) {
			deadMM.setState(UnitState.TIMED_OUT);
		}
		if (!CollectionsUtil.isEmpty(deadMMs)) {
			manager.flush();
		}
	}

	private boolean dmHeartBeatTimeout() {
		if (log.isDebugEnabled()) {
			log.debug("Querying for match units timed out due to heartbeat...");
		}
		List<DmServiceEntity> deadDMs = unitDao.listTimedOutDMs();
		if (CollectionsUtil.isEmpty(deadDMs)) {
			if (log.isDebugEnabled()) {
				log.debug("unitDao.listTimedOutDMs() returns 0 DMs");
			}
			return false;
		}

		manager.flush();
		return true;
	}

	private boolean muHeartBeatTimeout() {
		if (log.isDebugEnabled()) {
			log.debug("Querying for match units timed out due to heartbeat...");
		}
		List<MatchUnitEntity> deadMUs = unitDao.listTimedOutMUs();
		if (CollectionsUtil.isEmpty(deadMUs)) {
			if (log.isDebugEnabled()) {
				log.debug("unitDao.listTimedOutMUs() returns 0 MUs");
			}
			return false;
		}

		for (MatchUnitEntity mu : deadMUs) {
			log.warn("MatchUnit(ID: "
					+ mu.getMuId()
					+ ") has taken too long to send HEARTBEAT message, declaring dead.");
			mu.setState(UnitState.TIMED_OUT);
			eventSender.sendEvent(AimError.MU_TIME_OUT.getErrorCode(),
					"TIMEOUT", mu.getMuId(), "MatchUnit(ID: " + mu.getMuId()
							+ ") timed out (heartbeat)", EventLogLevel.ERROR,
					dateDao.getDatabaseDate());

			//
			List<FeJobQueueEntity> deadExtractJobs = extractJobDao
					.listDeadExtractJobs(mu.getMuId());
			int maxExtractJobFailures = sysConfigDao
					.getMMPropertyInt(MMConfigProperty.MAX_EXTRACT_JOB_FAILURES);
			for (FeJobQueueEntity eje : deadExtractJobs) {
				log.debug("Dead extract job : " + eje.getId()
						+ " due to mu heatbeat timeout(" + mu.toString() + ").");
				try {
					
					String errMsg = String.format("ExtractJob dead due to mu heatbeat timeout("+ "MU_ID:" + mu.getMuId()+ " Extract_Job_Id:" + eje.getId() + ")");
					
					AimServiceState aimServiceState = 
							new AimServiceState(errMsg,AimError.EXTRACT_JOB_RETRY_OVER.getErrorCode(),String.valueOf(System.currentTimeMillis()));
					
					PBMuExtractJobResultItem.Builder extResutItem = PBMuExtractJobResultItem.newBuilder();
					extResutItem.setJobId(eje.getId());//ToDo
					int count = extractJobHandler
							.failExtractJob(extResutItem.build(), eje, eje.getMuId().longValue(),aimServiceState, false,maxExtractJobFailures);
									

					if (count > 0) {
						// muLoadDao.decreaseExtractLoad(mu.getMuId());
						extractJobDao.deleteLotJob(eje.getLotJobId());
						commitDao.commit();
					}

					JmsSender.getInstance().sendToFEJobPlanner(
							NotifierEnum.PollBean,
							"Mu: " + eje.getMuId() + " time out.");
				} catch (AimRuntimeException e) {
					String message = "AimRuntimeException during poll(): Extract job "
							+ eje.getId()
							+ " when MatchUnit "
							+ mu.getMuId()
							+ " heatbeat timeout.";
					log.error(message, e);
					exceptionSender.sendAimException(
							AimError.EXTRACT_INTERNAL.getErrorCode(), message,
							eje.getId(), eje.getId(), mu.getMuId(), e);
				}
			}

			decreaseLotJob(deadExtractJobs);
		}

		manager.flush();

		rucDao.increaseRUC();
		return true;
	}

	private void mrHeartBeatTimeout() {
		if (log.isDebugEnabled()) {
			log.debug("Querying for match units timed out due to heartbeat...");
		}
		List<MapReducerEntity> deadMRs = unitDao.listTimedOutMRs();
		if (CollectionsUtil.isEmpty(deadMRs)) {
			if (log.isDebugEnabled()) {
				log.debug("unitDao.listTimedOutMRs() returns 0 MRs");
			}
			return;
		}

		for (MapReducerEntity mr : deadMRs) {

			log.warn("MapReducer(ID: "
					+ mr.getMrId()
					+ ") has taken too long to send HEARTBEAT message, declaring dead.");
			mr.setState(UnitState.TIMED_OUT);
			mr.setRingLocation(null);
			eventSender.sendEvent(AimError.MR_TIME_OUT.getErrorCode(),
					"TIMEOUT", mr.getMrId(), "MapReducer(ID: " + mr.getMrId()
							+ ") timed out (heartbeat)", EventLogLevel.ERROR,
					dateDao.getDatabaseDate());

		}

		manager.flush();

		// List MU_JOBS which deadMus have
		List<ContainerJobEntity> deadJobs = inquiryJobDao
				.listDeadContainerJobs(deadMRs);
		for (ContainerJobEntity deadJob : deadJobs) {
			log.warn("CONTAINER_JOB_ID:{}(MR_ID:{}) HeartBeat TIMEOUT",
					deadJob.getContainerId(), deadJob.getMrId());
			try {			
				String faildXml = "mr HeartBeat Timeout";
				inquiryJobHandler.failInquiryJob(deadJob.getContainerJobId(),
						"1", "Heart Beat TIMEOUT",faildXml,
						dateDao.getReasonTime());
			} catch (AimRuntimeException e) {
				String message = "AimRuntimeException during poll(): ContainerJob "
						+ deadJob.getContainerJobId()
						+ " when MapReducer "
						+ deadJob.getMrId() + " heatbeat timeout.";
				log.error(message, e);
				exceptionSender.sendAimException(
						AimError.INQ_INTERNAL.getErrorCode(), message,
						deadJob.getContainerJobId(), 0, deadJob.getMrId(), e);
			}
		}
	}

	private void containerJobTimeout() {
		List<FunctionTypeEntity> searchFunctions = functionDao
				.getSearchFunctions();
		for (FunctionTypeEntity function : searchFunctions) {
			int containerJobTimeouts = (int) function.getContainerJobTimeouts();
			if (0 <= containerJobTimeouts
					&& mmeDao.isMatchManagerAlive(containerJobTimeouts)) {
				// Don't use Date to judge timeout. Date does not have timezone.
				log.debug("Querying for timed out search jobs of "
						+ function.getFunctionName());
				List<ContainerJobEntity> deadJobs = inquiryJobDao
						.listTimedOutJobs(function.getFunctionName());

				if (!CollectionsUtil.isEmpty(deadJobs)) {
					log.warn("Number of Dead MU jobs : " + deadJobs.size());
				}
				// how many failures?
				// if too many, fail this dead job.
				for (ContainerJobEntity containerJob : deadJobs) {
					manager.flush();
					ContainerJobEntity cJob = manager.find(
							ContainerJobEntity.class,
							new Long(containerJob.getContainerJobId()));
					manager.refresh(cJob);
					if (cJob != null && cJob.getAssignedTs() != null) {
						long elapsedMS = fetchContainerJobElapsed(cJob
								.getContainerJobId());

						String reason = "CONTAINER_JOB_ID:"
								+ cJob.getContainerJobId() + " Time out after "
								+ elapsedMS + " ms.";
						log.warn(reason);
						try {					
							
							String faildXml = "containerJob timeout";

							inquiryJobHandler.failInquiryJob(
									cJob.getContainerJobId(),
									"1",
									"jquery Job retry over", faildXml,
									dateDao.getReasonTime());
						} catch (AimRuntimeException e) {
							String message = "AimRuntimeException during poll(): Container Job "
									+ cJob.getContainerJobId()
									+ " when time out.";
							log.error(message, e);
							exceptionSender.sendAimException(
									AimError.INQ_INTERNAL.getErrorCode(),
									message, cJob.getContainerJobId(), 0l,
									cJob.getMrId(), e);
						}
					}
				}
			}
		}
	}

	private void extractLotJobTimeout() {
		int extractTimeouts = functionDao.getExtractTimeouts();
		if (0 <= extractTimeouts && mmeDao.isMatchManagerAlive(extractTimeouts)) {
			log.debug("Querying for timed out extraction jobs...");
			List<FeJobQueueEntity> deadExtractJobs = extractJobDao
					.listTimedOutExtractJobs();
			log.debug("Dead extract jobs: " + deadExtractJobs.toString());
			int maxExtractJobFailures = sysConfigDao
					.getMMPropertyInt(MMConfigProperty.MAX_EXTRACT_JOB_FAILURES);

			for (FeJobQueueEntity eje : deadExtractJobs) {
				Integer muId = eje.getMuId();
				if (muId != null) {
					try {
						long elapsedMS = fetchExtractElapsed(eje.getId());	
                        String errMsg = 
                        		String.format("Extract job failed due to job timed out or MU status was changed TIMED_OUT. It has passed for " + elapsedMS+ " ms since assigned extract job to MU.");
                        AimServiceState aimServiceState = new AimServiceState(errMsg,AimError.EXTRACT_JOB_RETRY_OVER.getErrorCode(),dateDao.getReasonTime());  
                        PBMuExtractJobResultItem.Builder extJobResultItem = PBMuExtractJobResultItem.newBuilder();
                        extJobResultItem.setJobId(eje.getId()); //Todo
						extractJobHandler.failExtractJob(extJobResultItem.build(), eje, eje.getMuId(),
								aimServiceState, true, maxExtractJobFailures);

						extractJobDao.deleteLotJob(eje.getLotJobId());
						JmsSender.getInstance().sendToFEJobPlanner(
								NotifierEnum.PollBean,
								"extract job: " + eje.getId() + " time out.");
					} catch (AimRuntimeException e) {
						String message = "AimRuntimeException during poll(): Extract job "
								+ eje.getId() + " when process extractLotJobTimeout.";
						log.error(message, e);
						exceptionSender.sendAimException(
								AimError.EXTRACT_INTERNAL.getErrorCode(),
								message, eje.getId(), eje.getId(),
								eje.getMuId(), e);
					}
				} else {
					log.warn("During poll(), found extract job "
							+ eje.getId()
							+ " supposedly timed out, but not assigned to any MU. Ignoring...");
				}
			}

			decreaseLotJob(deadExtractJobs);

		}
	}

	/**
	 * decreaseLotJob
	 * 
	 * @param deadExtractJobs
	 */
	private void decreaseLotJob(List<FeJobQueueEntity> deadExtractJobs) {
		// key MU id, value MU related lot job ids
		Map<Integer, Set<Long>> map = Maps.newHashMap();

		for (FeJobQueueEntity eje : deadExtractJobs) {
			Integer muId = eje.getMuId();
			if (muId != null) {
				if (!map.containsKey(muId)) {
					map.put(muId, new TreeSet<Long>());
				}
				if (eje.getLotJobId() != null) {
					map.get(muId).add(eje.getLotJobId());
				}
			}
		}

		for (Integer muId : map.keySet()) {
			int size = map.get(muId).size();
			muLoadDao.decreaseExtractLoad(new Long(muId), size);
		}
	}

	private void logTopLevelJobTimeout(JobQueueEntity job) {
		if (job.getAssignedTs() == null) {
			long elapsed = jdbcTemplate
					.queryForObject(
							"SELECT (extract(day    from (sys_extract_utc(systimestamp) - timestamp '1970-01-01 00:00:00')) * 86400000 + "
									+ "extract(hour   from (sys_extract_utc(systimestamp) - timestamp '1970-01-01 00:00:00')) * 3600000 +"
									+ "extract(minute from (sys_extract_utc(systimestamp) - timestamp '1970-01-01 00:00:00')) * 60000 + "
									+ "extract(second from (sys_extract_utc(systimestamp) - timestamp '1970-01-01 00:00:00')) * 1000) - submission_ts"
									+ " from JOB_QUEUE where JOB_ID=?",
							Long.class, new Long(job.getJobId()));
			log.warn("TopLevlJob, JOB_ID={} timeout after submitted {} ms",
					job.getJobId(), elapsed);
		} else {
			long elapsed = jdbcTemplate
					.queryForObject(
							"SELECT (extract(day    from (sys_extract_utc(systimestamp) - timestamp '1970-01-01 00:00:00')) * 86400000 + "
									+ "extract(hour   from (sys_extract_utc(systimestamp) - timestamp '1970-01-01 00:00:00')) * 3600000 +"
									+ "extract(minute from (sys_extract_utc(systimestamp) - timestamp '1970-01-01 00:00:00')) * 60000 + "
									+ "extract(second from (sys_extract_utc(systimestamp) - timestamp '1970-01-01 00:00:00')) * 1000) - ASSIGNED_TS"
									+ " from JOB_QUEUE where JOB_ID=?",
							Long.class, new Long(job.getJobId()));
			log.warn("TopLevlJob, JOB_ID={} timeout after assigned {} ms",
					job.getJobId(), elapsed);
		}
	}

	private long fetchContainerJobElapsed(long containerJobId) {
		try {
			return jdbcTemplate
					.queryForObject(
							"SELECT (extract(day    from (sys_extract_utc(systimestamp) - timestamp '1970-01-01 00:00:00')) * 86400000 + "
									+ "extract(hour   from (sys_extract_utc(systimestamp) - timestamp '1970-01-01 00:00:00')) * 3600000 +"
									+ "extract(minute from (sys_extract_utc(systimestamp) - timestamp '1970-01-01 00:00:00')) * 60000 + "
									+ "extract(second from (sys_extract_utc(systimestamp) - timestamp '1970-01-01 00:00:00')) * 1000) - ASSIGNED_TS"
									+ " from CONTAINER_JOBS where CONTAINER_JOB_ID=?",
							Long.class, new Long(containerJobId));
		} catch (EmptyResultDataAccessException e) {
			log.warn(
					"Couldn't get Elapsed time of CONTAINER_JOBS.CONTAINER_JOB_ID:{}",
					containerJobId);
			return 0L;
		}
	}

	private long fetchExtractElapsed(long jobId) {
		try {
			return jdbcTemplate
					.queryForObject(
							"SELECT (extract(day    from (sys_extract_utc(systimestamp) - timestamp '1970-01-01 00:00:00')) * 86400000 + "
									+ "extract(hour   from (sys_extract_utc(systimestamp) - timestamp '1970-01-01 00:00:00')) * 3600000 +"
									+ "extract(minute from (sys_extract_utc(systimestamp) - timestamp '1970-01-01 00:00:00')) * 60000 + "
									+ "extract(second from (sys_extract_utc(systimestamp) - timestamp '1970-01-01 00:00:00')) * 1000) - ASSIGNED_TS"
									+ " from FE_JOB_QUEUE where JOB_ID=?",
							Long.class, new Long(jobId));
		} catch (EmptyResultDataAccessException e) {
			log.warn("Couldn't get Elapsed time of FE_JOB_QUEUE.JOB_ID:{}",
					jobId);
			return 0L;
		}
	}

	public void updateHeartBeatTS() {
		// updates LAST_HEARTBEAT_TS of MATCH_MANAGERS table.
		mmDao.createOrLookup();
	}

	public void purgeJobQueueByResultTs() {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		try {
			jobPurgerDao.purgeByResultTs();
		} finally {
			stopWatch.stop();
			PerformanceLogger.log(getClass().getSimpleName(), Thread
					.currentThread().getStackTrace()[1].getMethodName(),
					stopWatch.elapsedTime());
		}
	}

	public void notifyInqueryJobPlanner() {
		/* send Jms to InquiryJobPlanner */
		JmsSender.getInstance().sendToInquiryJobPlanner(NotifierEnum.PollBean,
				"time driven");
	}

	public void notifyFEJobPlanner() {
		/* send Jms to ExtractJobPlanner */
		JmsSender.getInstance().sendToFEJobPlanner(NotifierEnum.PollBean,
				"time driven");
	}

//	private PBServiceStateReason createErrorReason(String code,
//			String description) {
//		PBServiceStateReason.Builder reason = PBServiceStateReason.newBuilder();
//		reason.setCode(code);
//		reason.setDescription(description);
//		reason.setTime(dateDao.getReasonTime());
//
//		return reason.build();
//	}
	

}
