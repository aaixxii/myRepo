package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the DATA_MANAGERS database table.
 * 
 */
@Entity
@Table(name = "DM_SERVICES")
public class DmServiceEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "DM_ID")
	private Integer dmId;

	@Column(name = "CONTACT_URL")
	private String contactUrl;
	
	@Column(name = "HEATBEAT_PORT")
	private String heatbeatPort;
	
	@Column(name = "HEATBEAT_INTERVAL")
	private Integer heartBeatInterval;



	@Column(name = "STATE")
	@Enumerated(EnumType.STRING)
	private UnitState state;	

	@Column(name = "VERSION")
	private String version;

	
	public DmServiceEntity() {
	}

	

	public Integer getDmId() {
		return dmId;
	}



	public void setDmId(Integer dmId) {
		this.dmId = dmId;
	}



	public String getContactUrl() {
		return this.contactUrl;
	}

	public void setContactUrl(String contactUrl) {
		this.contactUrl = contactUrl;
	}

	public UnitState getState() {
		return state;
	}

	public void setState(UnitState state) {
		this.state = state;
	}
	
	public String getVersion() {
		return this.version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getHeatbeatPort() {
		return heatbeatPort;
	}

	public void setHeatbeatPort(String heatbeatPort) {
		this.heatbeatPort = heatbeatPort;
	}

	public Integer getHeartBeatInterval() {
		return heartBeatInterval;
	}

	public void setHeartBeatInterval(Integer heartBeatInterval) {
		this.heartBeatInterval = heartBeatInterval;
	}

}