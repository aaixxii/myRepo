package jp.co.nec.aim.mm.acceptor;

/**
 * JobType is the enum that represents the types of JobQueue entry that can be
 * put into the system.
 * 
 * @author Erik Vandekieft
 * 
 */
public enum JobType {
	SEARCH, EXTRACT;
}
