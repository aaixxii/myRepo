package jp.co.nec.aim.mm.segment.sync;

import static jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE;
import static jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT;

import java.io.Serializable;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;

import com.google.protobuf.ByteString;

/**
 * The result of CatchUpInfo
 * 
 * @author liuyq
 * 
 */
public class CatchUpInfo implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -3028733835478522137L;

	private long segmentId;
	private int command;
	private long templateId;
	private long version;
	private byte[] bytes;
	private String externalId;
	private int eventId;

	/**
	 * default constructor
	 */
	public CatchUpInfo() {
	}

	public long getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(long segmentId) {
		this.segmentId = segmentId;
	}

	public SegmentSyncCommandType getCommand() {
		return (command == 0) ? SEGMENT_SYNC_COMMAND_INSERT
				: SEGMENT_SYNC_COMMAND_DELETE;
	}

	public void setCommand(int command) {
		this.command = command;
	}

	public long getTemplateId() {
		return templateId;
	}

	public void setTemplateId(long templateId) {
		this.templateId = templateId;
	}

	public long getVersion() {
		return version;
	}

	public void setVersion(long version) {
		this.version = version;
	}

	public ByteString getBytesString() {
		if (bytes == null || bytes.length == 0) {
			return ByteString.EMPTY;
		}

		return ByteString.copyFrom(bytes);
	}

	public byte[] getBytes() {
		return this.bytes;
	}

	public boolean isBytesEmpty() {
		return this.bytes == null || this.bytes.length <= 0;
	}

	public void setBytes(byte[] bytes) {
		this.bytes = bytes;
	}

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

}
