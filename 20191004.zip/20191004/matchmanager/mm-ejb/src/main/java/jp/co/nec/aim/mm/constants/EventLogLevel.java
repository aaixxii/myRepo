package jp.co.nec.aim.mm.constants;

/**
 * @author mozj
 */
public enum EventLogLevel {
	INFO(1), ERROR(2);

	private int val;

	private EventLogLevel(int val) {
		this.val = val;
	}

	public int getVal() {
		return val;
	}
}
