//package jp.co.nec.aim.mm.ws;
//
//import java.util.List;
//
//import javax.annotation.PostConstruct;
//import javax.ejb.EJB;
//import javax.ejb.Stateless;
//import javax.ejb.TransactionAttribute;
//import javax.ejb.TransactionAttributeType;
//import javax.jws.WebMethod;
//import javax.jws.WebParam;
//import javax.jws.WebService;
//import javax.jws.soap.SOAPBinding;
//import javax.xml.ws.soap.SOAPFaultException;
//
//import jp.co.nec.aim.clientapi.CommonOptions;
//import jp.co.nec.aim.clientapi.afis.AfisDeletionFunctionEnum;
//import jp.co.nec.aim.clientapi.afis.AfisLowLevelFunctionEnum;
//import jp.co.nec.aim.clientapi.afis.AfisRegistrationFunctionEnum;
//import jp.co.nec.aim.clientapi.afis.AfisUpdateFunctionEnum;
//import jp.co.nec.aim.convert.ProtoClassConvert;
//import jp.co.nec.aim.convert.WebServiceClassConvert;
//import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobRequest;
//import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobResponse;
//import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobResult;
//import jp.co.nec.aim.message.proto.JobCommonService.PBJobStatusResponse;
//import jp.co.nec.aim.message.proto.JobCommonService.PBListJobIdsResponse;
//import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest;
//import jp.co.nec.aim.mm.acceptor.JobType;
//import jp.co.nec.aim.mm.acceptor.service.AimExtractService;
//import jp.co.nec.aim.mm.acceptor.service.AimInquiryService;
//import jp.co.nec.aim.mm.acceptor.service.AimSyncService;
//import jp.co.nec.aim.mm.exception.AimRuntimeException;
//import jp.co.nec.aim.mm.exception.ExceptionHelper;
//import jp.co.nec.aim.mm.jaxb.AfisTemplateSet;
//import jp.co.nec.aim.mm.jaxb.JobStatus;
//import jp.co.nec.aim.mm.jaxb.SearchJobResult;
//import jp.co.nec.aim.mm.logger.PerformanceLogger;
//import jp.co.nec.aim.mm.util.StopWatch;
//
//import org.jboss.logging.NDC;
//import org.jboss.ws.api.annotation.WebContext;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
///**
// * AIMJobControl web service
// * 
// * @author liuyq
// * 
// */
//@WebService(name = "AIMJobControlService")
//@Stateless
//@TransactionAttribute(TransactionAttributeType.REQUIRED)
//@WebContext(contextRoot = "/AIMWebServices", secureWSDLAccess = false)
//@SOAPBinding(style = SOAPBinding.Style.DOCUMENT)
//public class AIMJobControl {
//	private static final Logger log = LoggerFactory
//			.getLogger(AIMJobControl.class);
//
//	@EJB
//	private AimSyncService syncService;
//
//	@EJB
//	private AimInquiryService inquiryService;
//
//	@EJB
//	private AimExtractService extractService;
//
//	/** exception **/
//	private ExceptionHelper exception;
//
//	/** the common of Class Converter **/
//	private ProtoClassConvert convert;
//	private WebServiceClassConvert webConvert;
//
//	/**
//	 * default constructor
//	 */
//	public AIMJobControl() {
//	}
//
//	@PostConstruct
//	public void init() {
//		this.exception = new ExceptionHelper();
//		this.convert = new ProtoClassConvert();
//		this.webConvert = new WebServiceClassConvert();
//	}
//
//	// // ////////////////////// REGISTRATION FUNCTIONS ////////////////////////
//	@WebMethod
//	public void TR(@WebParam(name = "externalId") String externalId,
//			@WebParam(name = "eventId") int eventId,
//			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet)
//			throws AimRuntimeException {		
//		NDC.push("TR");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBSyncJobRequest request = convert.toPBSyncJobRequest(
//					AfisRegistrationFunctionEnum.TR, externalId, eventId,
//					afisTemplateSet);
//			syncService.syncData(request);
//			if (log.isDebugEnabled()) {
//				log.debug("TR succeeded, ecternalId = " + externalId
//						+ ", eventId = " + eventId);
//			}
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "TR",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public void LR(@WebParam(name = "externalId") String externalId,
//			@WebParam(name = "eventId") int eventId,
//			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet)
//			throws AimRuntimeException {		
//		NDC.push("LR");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBSyncJobRequest request = convert.toPBSyncJobRequest(
//					AfisRegistrationFunctionEnum.LR, externalId, eventId,
//					afisTemplateSet);
//			syncService.syncData(request);
//			if (log.isDebugEnabled()) {
//				log.debug("LR succeeded, ecternalId = " + externalId
//						+ ", eventId = " + eventId);
//			}
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "LR",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public void LRS(@WebParam(name = "externalId") String externalId,
//			@WebParam(name = "eventId") int eventId,
//			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet)
//			throws AimRuntimeException {		
//		NDC.push("LRS");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBSyncJobRequest request = convert.toPBSyncJobRequest(
//					AfisRegistrationFunctionEnum.LRS, externalId, eventId,
//					afisTemplateSet);
//			syncService.syncData(request);
//			if (log.isDebugEnabled()) {
//				log.debug("LRS succeeded, ecternalId = " + externalId
//						+ ", eventId = " + eventId);
//			}
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "LRS",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public void LRM(@WebParam(name = "externalId") String externalId,
//			@WebParam(name = "eventId") int eventId,
//			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet)
//			throws AimRuntimeException {		
//		NDC.push("LRM");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBSyncJobRequest request = convert.toPBSyncJobRequest(
//					AfisRegistrationFunctionEnum.LRM, externalId, eventId,
//					afisTemplateSet);
//			syncService.syncData(request);
//			if (log.isDebugEnabled()) {
//				log.debug("LRM succeeded, ecternalId = " + externalId
//						+ ", eventId = " + eventId);
//			}
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "LRM",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public void LRP(@WebParam(name = "externalId") String externalId,
//			@WebParam(name = "eventId") int eventId,
//			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet)
//			throws AimRuntimeException {		
//		NDC.push("LRP");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBSyncJobRequest request = convert.toPBSyncJobRequest(
//					AfisRegistrationFunctionEnum.LRP, externalId, eventId,
//					afisTemplateSet);
//			syncService.syncData(request);
//			if (log.isDebugEnabled()) {
//				log.debug("LRP succeeded, ecternalId = " + externalId
//						+ ", eventId = " + eventId);
//			}
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "LRP",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public void LRX(@WebParam(name = "externalId") String externalId,
//			@WebParam(name = "eventId") int eventId,
//			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet)
//			throws AimRuntimeException {		
//		NDC.push("LRX");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBSyncJobRequest request = convert.toPBSyncJobRequest(
//					AfisRegistrationFunctionEnum.LRX, externalId, eventId,
//					afisTemplateSet);
//			syncService.syncData(request);
//			if (log.isDebugEnabled()) {
//				log.debug("LRX succeeded, ecternalId = " + externalId
//						+ ", eventId = " + eventId);
//			}
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "LRX",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	// ////////////////////// UPDATE FUNCTIONS //////////////////////////
//
//	@WebMethod
//	public void TU(
//			@WebParam(name = "externalId") String externalId,
//			@WebParam(name = "eventId") int eventId,
//			// In "Scope FD", because Scope is more than 1 so add afisGroupId
//			// to delete specified containerId
//			@WebParam(name = "afisGroupId") Integer afisGroupId,
//			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet)
//			throws AimRuntimeException {		
//		NDC.push("TU");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBSyncJobRequest request = convert.toPBSyncJobRequest(
//					AfisUpdateFunctionEnum.TU, externalId, eventId,
//					afisGroupId, afisTemplateSet);
//			syncService.syncData(request);
//			if (log.isDebugEnabled()) {
//				log.debug("TU succeeded, ecternalId = " + externalId
//						+ ", eventId = " + eventId + ", afisGroupId"
//						+ afisGroupId);
//			}
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "TU",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public void LU(
//			@WebParam(name = "externalId") String externalId,
//			@WebParam(name = "eventId") int eventId,
//			// In "Scope FD", because Scope is more than 1 so add afisGroupId
//			// to delete specified containerId
//			@WebParam(name = "afisGroupId") Integer afisGroupId,
//			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet)
//			throws AimRuntimeException {		
//		NDC.push("LU");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBSyncJobRequest request = convert.toPBSyncJobRequest(
//					AfisUpdateFunctionEnum.LU, externalId, eventId,
//					afisGroupId, afisTemplateSet);
//			syncService.syncData(request);
//			if (log.isDebugEnabled()) {
//				log.debug("LU succeeded, ecternalId = " + externalId
//						+ ", eventId = " + eventId + ", afisGroupId"
//						+ afisGroupId);
//			}
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "LU",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public void LUS(
//			@WebParam(name = "externalId") String externalId,
//			@WebParam(name = "eventId") int eventId,
//			// In "Scope FD", because Scope is more than 1 so add afisGroupId
//			// to delete specified containerId
//			@WebParam(name = "afisGroupId") Integer afisGroupId,
//			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet)
//			throws AimRuntimeException {		
//		NDC.push("LUS");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBSyncJobRequest request = convert.toPBSyncJobRequest(
//					AfisUpdateFunctionEnum.LUS, externalId, eventId,
//					afisGroupId, afisTemplateSet);
//			syncService.syncData(request);
//			if (log.isDebugEnabled()) {
//				log.debug("LUS succeeded, ecternalId = " + externalId
//						+ ", eventId = " + eventId + ", afisGroupId"
//						+ afisGroupId);
//			}
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "LUS",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public void LUM(
//			@WebParam(name = "externalId") String externalId,
//			@WebParam(name = "eventId") int eventId,
//			// In "Scope FD", because Scope is more than 1 so add afisGroupId
//			// to delete specified containerId
//			@WebParam(name = "afisGroupId") Integer afisGroupId,
//			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet)
//			throws AimRuntimeException {		
//		NDC.push("LUM");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBSyncJobRequest request = convert.toPBSyncJobRequest(
//					AfisUpdateFunctionEnum.LUM, externalId, eventId,
//					afisGroupId, afisTemplateSet);
//			syncService.syncData(request);
//			if (log.isDebugEnabled()) {
//				log.debug("LUM succeeded, ecternalId = " + externalId
//						+ ", eventId = " + eventId + ", afisGroupId"
//						+ afisGroupId);
//			}
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "LUM",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public void LUP(
//			@WebParam(name = "externalId") String externalId,
//			@WebParam(name = "eventId") int eventId,
//			// In "Scope FD", because Scope is more than 1 so add afisGroupId
//			// to delete specified containerId
//			@WebParam(name = "afisGroupId") Integer afisGroupId,
//			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet)
//			throws AimRuntimeException {		
//		NDC.push("LUP");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBSyncJobRequest request = convert.toPBSyncJobRequest(
//					AfisUpdateFunctionEnum.LUP, externalId, eventId,
//					afisGroupId, afisTemplateSet);
//			syncService.syncData(request);
//			if (log.isDebugEnabled()) {
//				log.debug("LUP succeeded, ecternalId = " + externalId
//						+ ", eventId = " + eventId + ", afisGroupId"
//						+ afisGroupId);
//			}
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "LUP",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public void LUX(
//			@WebParam(name = "externalId") String externalId,
//			@WebParam(name = "eventId") int eventId,
//			// In "Scope FD", because Scope is more than 1 so add afisGroupId
//			// to delete specified containerId
//			@WebParam(name = "afisGroupId") Integer afisGroupId,
//			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet)
//			throws AimRuntimeException {		
//		NDC.push("LUX");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBSyncJobRequest request = convert.toPBSyncJobRequest(
//					AfisUpdateFunctionEnum.LUX, externalId, eventId,
//					afisGroupId, afisTemplateSet);
//			syncService.syncData(request);
//			if (log.isDebugEnabled()) {
//				log.debug("LUX succeeded, ecternalId = " + externalId
//						+ ", eventId = " + eventId + ", afisGroupId"
//						+ afisGroupId);
//			}
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "LUX",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	// ////////////////////// DELETION FUNCTIONS ////////////////////////
//
//	@WebMethod
//	public void TD(@WebParam(name = "externalId") String externalId,
//			@WebParam(name = "eventId") Integer eventId,
//			// In "Scope FD", because Scope is more than 1 so add afisGroupId
//			// to delete specified containerId
//			@WebParam(name = "afisGroupId") Integer afisGroupId)
//			throws AimRuntimeException {		
//		NDC.push("TD");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBSyncJobRequest request = convert.toPBSyncJobRequest(
//					AfisDeletionFunctionEnum.TD, externalId, eventId,
//					afisGroupId);
//			syncService.syncData(request);
//			if (log.isDebugEnabled()) {
//				log.debug("TD succeeded, ecternalId = " + externalId
//						+ ", eventId = " + eventId + ", afisGroupId"
//						+ afisGroupId);
//			}
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "TD",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public void LD(@WebParam(name = "externalId") String externalId,
//			@WebParam(name = "eventId") Integer eventId,
//			// In "Scope FD", because Scope is more than 1 so add afisGroupId
//			// to delete specified containerId
//			@WebParam(name = "afisGroupId") Integer afisGroupId)
//			throws AimRuntimeException {	
//		NDC.push("LD");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBSyncJobRequest request = convert.toPBSyncJobRequest(
//					AfisDeletionFunctionEnum.LD, externalId, eventId,
//					afisGroupId);
//			syncService.syncData(request);
//			if (log.isDebugEnabled()) {
//				log.debug("LD succeeded, ecternalId = " + externalId
//						+ ", eventId = " + eventId + ", afisGroupId"
//						+ afisGroupId);
//			}
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "LD",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public void LDS(@WebParam(name = "externalId") String externalId,
//			@WebParam(name = "eventId") Integer eventId,
//			// In "Scope FD", because Scope is more than 1 so add afisGroupId
//			// to delete specified containerId
//			@WebParam(name = "afisGroupId") Integer afisGroupId)
//			throws AimRuntimeException {	
//		NDC.push("LDS");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBSyncJobRequest request = convert.toPBSyncJobRequest(
//					AfisDeletionFunctionEnum.LDS, externalId, eventId,
//					afisGroupId);
//			syncService.syncData(request);
//			if (log.isDebugEnabled()) {
//				log.debug("LDS succeeded, ecternalId = " + externalId
//						+ ", eventId = " + eventId + ", afisGroupId"
//						+ afisGroupId);
//			}
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "LDS",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public void LDM(@WebParam(name = "externalId") String externalId,
//			@WebParam(name = "eventId") Integer eventId,
//			// In "Scope FD", because Scope is more than 1 so add afisGroupId
//			// to delete specified containerId
//			@WebParam(name = "afisGroupId") Integer afisGroupId)
//			throws AimRuntimeException {
//		NDC.push("LDM");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBSyncJobRequest request = convert.toPBSyncJobRequest(
//					AfisDeletionFunctionEnum.LDM, externalId, eventId,
//					afisGroupId);
//			syncService.syncData(request);
//			if (log.isDebugEnabled()) {
//				log.debug("LDM succeeded, ecternalId = " + externalId
//						+ ", eventId = " + eventId + ", afisGroupId"
//						+ afisGroupId);
//			}
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "LDM",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public void LDP(@WebParam(name = "externalId") String externalId,
//			@WebParam(name = "eventId") Integer eventId,
//			// In "Scope FD", because Scope is more than 1 so add afisGroupId
//			// to delete specified containerId
//			@WebParam(name = "afisGroupId") Integer afisGroupId)
//			throws AimRuntimeException {
//		
//		NDC.push("LDP");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBSyncJobRequest request = convert.toPBSyncJobRequest(
//					AfisDeletionFunctionEnum.LDP, externalId, eventId,
//					afisGroupId);
//			syncService.syncData(request);
//			if (log.isDebugEnabled()) {
//				log.debug("LDP succeeded, ecternalId = " + externalId
//						+ ", eventId = " + eventId + ", afisGroupId"
//						+ afisGroupId);
//			}
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "LDP",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public void LDX(@WebParam(name = "externalId") String externalId,
//			@WebParam(name = "eventId") Integer eventId,
//			// In "Scope FD", because Scope is more than 1 so add afisGroupId
//			// to delete specified containerId
//			@WebParam(name = "afisGroupId") Integer afisGroupId)
//			throws AimRuntimeException {		
//		NDC.push("LDX");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBSyncJobRequest request = convert.toPBSyncJobRequest(
//					AfisDeletionFunctionEnum.LDX, externalId, eventId,
//					afisGroupId);
//			syncService.syncData(request);
//			if (log.isDebugEnabled()) {
//				log.debug("LDX succeeded, ecternalId = " + externalId
//						+ ", eventId = " + eventId + ", afisGroupId"
//						+ afisGroupId);
//			}
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "LDX",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	// /////////////////// INQUIRY FUNCTIONS ////////////////////////
//	@WebMethod
//	public long TI(
//			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet,
//			@WebParam(name = "commonOptions") CommonOptions commonOptions) {		
//		NDC.push("TI");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBInquiryJobRequest request = convert
//					.toPBInquiryJobRequest(AfisLowLevelFunctionEnum.TI,
//							afisTemplateSet, commonOptions);
//			PBInquiryJobResponse response = inquiryService.inquiry(request,
//					false);
//			return response.getJobId();
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "TI",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public long TIM(
//			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet,
//			@WebParam(name = "commonOptions") CommonOptions commonOptions)
//			throws AimRuntimeException {		
//		NDC.push("TIM");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBInquiryJobRequest request = convert.toPBInquiryJobRequest(
//					AfisLowLevelFunctionEnum.TIM, afisTemplateSet,
//					commonOptions);
//			PBInquiryJobResponse response = inquiryService.inquiry(request,
//					false);
//			return response.getJobId();
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "TIM",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public long LI(
//			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet,
//			@WebParam(name = "commonOptions") CommonOptions commonOptions)
//			throws AimRuntimeException {		
//		NDC.push("LI");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBInquiryJobRequest request = convert
//					.toPBInquiryJobRequest(AfisLowLevelFunctionEnum.LI,
//							afisTemplateSet, commonOptions);
//			PBInquiryJobResponse response = inquiryService.inquiry(request,
//					false);
//			return response.getJobId();
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "LI",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public long LIM(
//			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet,
//			@WebParam(name = "commonOptions") CommonOptions commonOptions)
//			throws AimRuntimeException {		
//		NDC.push("LIM");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBInquiryJobRequest request = convert.toPBInquiryJobRequest(
//					AfisLowLevelFunctionEnum.LIM, afisTemplateSet,
//					commonOptions);
//			PBInquiryJobResponse response = inquiryService.inquiry(request,
//					false);
//			return response.getJobId();
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "LIM",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public long TLI(
//			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet,
//			@WebParam(name = "commonOptions") CommonOptions commonOptions)
//			throws AimRuntimeException {		
//		NDC.push("TLI");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBInquiryJobRequest request = convert.toPBInquiryJobRequest(
//					AfisLowLevelFunctionEnum.TLI, afisTemplateSet,
//					commonOptions);
//			PBInquiryJobResponse response = inquiryService.inquiry(request,
//					false);
//			return response.getJobId();
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "TLI",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public long TLIM(
//			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet,
//			@WebParam(name = "commonOptions") CommonOptions commonOptions)
//			throws AimRuntimeException {		
//		NDC.push("TLIM");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBInquiryJobRequest request = convert.toPBInquiryJobRequest(
//					AfisLowLevelFunctionEnum.TLIM, afisTemplateSet,
//					commonOptions);
//			PBInquiryJobResponse response = inquiryService.inquiry(request,
//					false);
//			return response.getJobId();
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "TLIM",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public long LLI(
//			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet,
//			@WebParam(name = "commonOptions") CommonOptions commonOptions)
//			throws AimRuntimeException {		
//		NDC.push("LLI");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBInquiryJobRequest request = convert.toPBInquiryJobRequest(
//					AfisLowLevelFunctionEnum.LLI, afisTemplateSet,
//					commonOptions);
//			PBInquiryJobResponse response = inquiryService.inquiry(request,
//					false);
//			return response.getJobId();
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "LLI",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public long LLIM(
//			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet,
//			@WebParam(name = "commonOptions") CommonOptions commonOptions)
//			throws AimRuntimeException {		
//		NDC.push("LLIM");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBInquiryJobRequest request = convert.toPBInquiryJobRequest(
//					AfisLowLevelFunctionEnum.LLIM, afisTemplateSet,
//					commonOptions);
//			PBInquiryJobResponse response = inquiryService.inquiry(request,
//					false);
//			return response.getJobId();
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "LLIM",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public long LIP(
//			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet,
//			@WebParam(name = "commonOptions") CommonOptions commonOptions)
//			throws AimRuntimeException {		
//		NDC.push("LIP");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBInquiryJobRequest request = convert.toPBInquiryJobRequest(
//					AfisLowLevelFunctionEnum.LIP, afisTemplateSet,
//					commonOptions);
//			PBInquiryJobResponse response = inquiryService.inquiry(request,
//					false);
//			return response.getJobId();
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "LIP",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public long TLIP(
//			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet,
//			@WebParam(name = "commonOptions") CommonOptions commonOptions)
//			throws AimRuntimeException {		
//		NDC.push("TLIP");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBInquiryJobRequest request = convert.toPBInquiryJobRequest(
//					AfisLowLevelFunctionEnum.TLIP, afisTemplateSet,
//					commonOptions);
//			PBInquiryJobResponse response = inquiryService.inquiry(request,
//					false);
//			return response.getJobId();
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "TLIP",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public long LLIP(
//			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet,
//			@WebParam(name = "commonOptions") CommonOptions commonOptions)
//			throws AimRuntimeException {		
//		NDC.push("LLIP");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBInquiryJobRequest request = convert.toPBInquiryJobRequest(
//					AfisLowLevelFunctionEnum.LLIP, afisTemplateSet,
//					commonOptions);
//			PBInquiryJobResponse response = inquiryService.inquiry(request,
//					false);
//			return response.getJobId();
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "LLIP",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public long LIX(
//			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet,
//			@WebParam(name = "commonOptions") CommonOptions commonOptions)
//			throws AimRuntimeException {		
//		NDC.push("LIX");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBInquiryJobRequest request = convert.toPBInquiryJobRequest(
//					AfisLowLevelFunctionEnum.LIX, afisTemplateSet,
//					commonOptions);
//			PBInquiryJobResponse response = inquiryService.inquiry(request,
//					false);
//			return response.getJobId();
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "LIX",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public long TLIX(
//			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet,
//			@WebParam(name = "commonOptions") CommonOptions commonOptions)
//			throws AimRuntimeException {		
//		NDC.push("TLIX");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBInquiryJobRequest request = convert.toPBInquiryJobRequest(
//					AfisLowLevelFunctionEnum.TLIX, afisTemplateSet,
//					commonOptions);
//			PBInquiryJobResponse response = inquiryService.inquiry(request,
//					false);
//			return response.getJobId();
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "TLIX",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public long LLIX(
//			@WebParam(name = "afisTemplates") AfisTemplateSet afisTemplateSet,
//			@WebParam(name = "commonOptions") CommonOptions commonOptions)
//			throws AimRuntimeException {		
//		NDC.push("LLIX");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBInquiryJobRequest request = convert.toPBInquiryJobRequest(
//					AfisLowLevelFunctionEnum.LLIX, afisTemplateSet,
//					commonOptions);
//			PBInquiryJobResponse response = inquiryService.inquiry(request,
//					false);
//			return response.getJobId();
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "LLIX",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	// ////////////////// job control functions ////////////////////
//	@WebMethod
//	public void deleteJob(@WebParam(name = "jobType") JobType jobType,
//			@WebParam(name = "jobId") long jobId) throws AimRuntimeException {		
//		NDC.push("deleteJob");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			switch (jobType) {
//			case SEARCH:
//				inquiryService.deleteJob(convert.toPBDeleteJobRequest(jobId));
//				break;
//			case EXTRACT:
//				extractService.deleteJob(convert.toPBDeleteJobRequest(jobId));
//				break;
//			default:
//				break;
//			}
//		} catch (RuntimeException e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "deleteJob",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public void clearJobs(@WebParam(name = "jobType") JobType jobType)
//			throws AimRuntimeException {		
//		NDC.push("clearJobs");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			switch (jobType) {
//			case SEARCH:
//				inquiryService.clearJobs();
//				break;
//			case EXTRACT:
//				extractService.clearJobs();
//				break;
//			default:
//				break;
//			}
//		} catch (RuntimeException e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "clearJobs",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public SearchJobResult getSearchJobResult(
//			@WebParam(name = "jobId") long jobId) throws AimRuntimeException {		
//		NDC.push("getSearchJobResult");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBInquiryJobResult result = inquiryService.getJobResult(convert
//					.toPBJobResultRequest(jobId));
//			return webConvert.toSearchJobResult(result);
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(),
//					"getSearchJobResult", stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public JobStatus getJobStatus(@WebParam(name = "jobType") JobType jobType,
//			@WebParam(name = "jobId") long jobId) throws AimRuntimeException {		
//		NDC.push("getJobStatus");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBJobStatusResponse response = null;
//			switch (jobType) {
//			case SEARCH:
//				response = inquiryService.getJobStatus(convert
//						.toPBJobStatusRequest(jobId));
//				break;
//			case EXTRACT:
//				response = extractService.getJobStatus(convert
//						.toPBJobStatusRequest(jobId));
//				break;
//			default:
//				break;
//			}
//			return webConvert.toJobStatus(response);
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "getJobStatus",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//
//	@WebMethod
//	public List<Long> listJobIds(@WebParam(name = "jobType") JobType jobType)
//			throws AimRuntimeException {		
//		NDC.push("listJobIds");
//		StopWatch stopWatch = new StopWatch();
//		stopWatch.start();
//		try {
//			PBListJobIdsResponse response = null;
//			switch (jobType) {
//			case SEARCH:
//				response = inquiryService.listJobIds();
//				break;
//			case EXTRACT:
//				response = extractService.listJobIds();
//				break;
//			default:
//				break;
//			}
//			return response.getJobIdList();
//		} catch (Exception e) {
//			throw new SOAPFaultException(exception.createSOAPFault(e));
//		} finally {
//			stopWatch.stop();
//			PerformanceLogger.log(getClass().getSimpleName(), "listJobIds",
//					stopWatch.elapsedTime());
//			NDC.clear();
//		}
//	}
//}
