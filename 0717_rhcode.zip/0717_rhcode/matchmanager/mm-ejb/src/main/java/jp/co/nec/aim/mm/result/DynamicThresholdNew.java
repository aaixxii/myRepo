package jp.co.nec.aim.mm.result;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*******************************************************************************/
/*                                                                             */
/*                                                                             */
/*    Copyright (C) NEC Corporation 2009                                       */
/*                                                                             */
/*                                                                             */
/*    NEC CONFIDENTIAL AND PROPRIETARY                                         */
/*    All rights reserved by NEC Corporation.                                  */
/*                                                                             */
/*    This program must be used solely for the purpose for which               */
/*    it was furnished by NEC Corporation.  No part of this program            */
/*    may be reproduced or disclosed to others, in any form,                   */
/*    without prior written permission of NEC Corporation.                     */
/*    Use of copyright notice dose not evidence publication of the program.    */
/*                                                                             */
/*    NEC Corporation accepts no responsibility for any damages                */
/*    resulting from the use of this software.  This software is               */
/*    provided "AS IS", and you, its user, assume all risks when using it.     */
/*                                                                             */
/*                                                                             */
/*******************************************************************************/

class DynthRecord {
	int fusionScore;
	int rank;
	double percentagePoint;
	int hitFlag;
}

class DynthScoreList {
	DynthRecord dynthRecords[];
	int n;

	void sDynth_DuplicateScoreList(DynthScoreList target[]) {
		int i;
		target[0] = new DynthScoreList();
		target[0].n = this.n;
		target[0].dynthRecords = new DynthRecord[this.n];
		for (i = 0; i < n; i++) {
			target[0].dynthRecords[i] = new DynthRecord();
			target[0].dynthRecords[i] = this.dynthRecords[i];
		}
	}
}

class DynamicThresholdNew {
	private static Logger log = LoggerFactory
			.getLogger(DynamicThresholdNew.class);
	private final static int DYNTH_SUCCESS = 0;
	private final static int DYNTH_ERROR_INVALID_ARGUMENT = -1;
	private final static int DYNTH_ERROR_INTERNAL = -3;
	private final static int BIN_SIZE = 10;
	private final static double b[] = { 1.570796288, 0.03706987906,
			-0.8364353589e-3, -0.2250947176e-3, 0.6841218299e-5,
			0.5824238515e-5, -0.104527497e-5, 0.8360937017e-7,
			-0.3231081277e-8, 0.3657763036e-10, 0.6936233982e-12 };

	DynthScoreList dynthScoreList = new DynthScoreList();

	private double defPercentagePoint = 5.2;
	private int defHitThreshold = 2000;

	DynamicThresholdNew(int number, DynamicThresholdParams params) {
		defPercentagePoint = params.getPercentagePoint();
		defHitThreshold = params.getHitThreshold();
		// log.debug("Create array ["+ number + "]");
		dynthScoreList.n = number;
		dynthScoreList.dynthRecords = new DynthRecord[number];
		for (int i = 0; i < number; i++) {
			dynthScoreList.dynthRecords[i] = new DynthRecord();
		}
	}

	/**
	 * Check calculated dynamicThreshPercentagePoint :
	 * CommonOptions.dynThreshPercentagePoint<br>
	 * Check calculated dynamicThreshhold : CommonOptions.dynThreshHold<br>
	 * 
	 * @return SUCCESS
	 */
	int perform() {
		sDynth_SetPP();
		if (log.isDebugEnabled()) {
			log.debug("commonOptions:percentagePoint:" + defPercentagePoint
					+ " dynamicThreshold:" + defHitThreshold + "---");
		}
		for (int i = 0; i < dynthScoreList.n; i++) {
			if (dynthScoreList.dynthRecords[i].percentagePoint >= defPercentagePoint
					|| dynthScoreList.dynthRecords[i].fusionScore >= defHitThreshold) {
				dynthScoreList.dynthRecords[i].hitFlag = 1;
			}
			if (log.isDebugEnabled()) {
				String message = "no hit";
				if (dynthScoreList.dynthRecords[i].hitFlag == 1) {
					message = "***hit";
				}
				log.debug(message + " "
						+ dynthScoreList.dynthRecords[i].hitFlag + "["
						+ i
						+ "].pp:"
						+ dynthScoreList.dynthRecords[i].percentagePoint //
						+ " [" + i + "].scr:"
						+ dynthScoreList.dynthRecords[i].fusionScore);
			}
		}
		return (DYNTH_SUCCESS);
	}

	private int sDynth_SetPP() {
		int n;
		int st;
		DynthScoreList p_sl_tmp[] = new DynthScoreList[1];
		int[] p_scr;
		double[] p_pseudo_pp;

		/*--------------------------------------------------------------*/
		/* check input */
		/*--------------------------------------------------------------*/
		n = dynthScoreList.n;
		int sPrm_pp_n_head = 10;
		int sPrm_pp_n_population = 15000;

		/*--------------------------------------------------------------*/
		/* temporary list creation */
		/*--------------------------------------------------------------*/
		{
			/*------------------------------------------------------*/
			/* copy score list */
			/*------------------------------------------------------*/
			{
				dynthScoreList.sDynth_DuplicateScoreList(p_sl_tmp);
				sDynth_SetRank(p_sl_tmp);
			}
		}

		/*----------------------------------------------------------------*/
		/* PP counting */
		/*----------------------------------------------------------------*/
		{
			double pp[] = new double[1];
			int _n = n;

			/*--------------------------------------------------------*/
			/* work area */
			/*--------------------------------------------------------*/
			{
				p_scr = new int[n];

				p_pseudo_pp = new double[n];

				for (int i = 0; i < n; i++) {
					p_scr[i] = p_sl_tmp[0].dynthRecords[i].fusionScore;
					if (p_scr[i] <= 0) {
						_n--;
					}
				}
			}

			if (_n > 0) {
				/*------------------------------------------------------*/
				/* pseudo PP ( for less candidate) */
				/*------------------------------------------------------*/
				{
					double pseudo_pp;

					if (_n < 10) {
						pseudo_pp = 30.0 / (20.0 + (double) _n);
					} else {
						pseudo_pp = 0.0;
					}

					for (int i = 0; i < _n; i++) {
						p_pseudo_pp[i] = Math
								.sqrt((double) p_sl_tmp[0].dynthRecords[i].fusionScore)
								/ (7.0 + (p_sl_tmp[0].dynthRecords[i].rank) * 2.5)
								+ 1.0 + pseudo_pp;
					}
					/*----------------------------------------------*/
					/* monotonous decrease */
					/*----------------------------------------------*/
					for (int i = 0; i < _n; i++) {
						for (int k = i; k > 0; k--) {
							if (p_pseudo_pp[k - 1] < p_pseudo_pp[k]
									|| p_sl_tmp[0].dynthRecords[k - 1].rank == p_sl_tmp[0].dynthRecords[k].rank) {
								p_pseudo_pp[k - 1] = p_pseudo_pp[k];
							} else {
								break;
							}
						}
					}

					/*------------------------------------------------*/
					/* deterrence side effectmonotonous decrease */
					/*------------------------------------------------*/
					for (int i = 0; i < _n; i++) {
						p_pseudo_pp[i] -= (p_sl_tmp[0].dynthRecords[i].rank * 0.001);
						p_sl_tmp[0].dynthRecords[i].percentagePoint = p_pseudo_pp[i];
					}
				}

				/*--------------------------------------------------------*/
				/* calculate PP */
				/*--------------------------------------------------------*/
				if (_n > 10) {
					/*------------------------------------------------*/
					/* <UNPRINTABLE CHARS> */
					/*------------------------------------------------*/
					for (int i = 0; i < Math.min(sPrm_pp_n_head, _n - 5); i++) {
						int j;
						int my_p_scr[] = new int[dynthScoreList.n];
						pp[0] = 0.0;
						// convert from C to Java --by Su
						for (j = i + 1; j < dynthScoreList.n; j++)
							my_p_scr[j - i - 1] = p_scr[j];
						// st = sDynth_CalcPP(p_scr[i], p_scr[i + 1], _n - i -
						// 1, sPrm_pp_n_population, pp);
						st = sDynth_CalcPP(p_scr[i], my_p_scr, _n - i - 1,
								sPrm_pp_n_population, pp);
						p_scr[i + 1] = my_p_scr[0];
						if (st == DYNTH_SUCCESS) {
							p_sl_tmp[0].dynthRecords[i].percentagePoint = pp[0];
						} else {
							break;
						}
					}

					/*------------------------------------------------*/
					/* <UNPRINTABLE CHARS> */
					/*------------------------------------------------*/
					for (int i = 0; i < _n; i++) {
						for (int k = i; k > 0; k--) {
							if (p_sl_tmp[0].dynthRecords[k - 1].percentagePoint < p_sl_tmp[0].dynthRecords[k].percentagePoint
									|| p_sl_tmp[0].dynthRecords[k - 1].rank == p_sl_tmp[0].dynthRecords[k].rank) {
								p_sl_tmp[0].dynthRecords[k - 1].percentagePoint = p_sl_tmp[0].dynthRecords[k].percentagePoint;

							} else {
								break;
							}
						}
					}

					/*------------------------------------------------*/
					/* <UNPRINTABLE CHARS> */
					/*------------------------------------------------*/
					for (int i = 0; i < _n; i++) {
						p_sl_tmp[0].dynthRecords[i].percentagePoint = (p_sl_tmp[0].dynthRecords[i].percentagePoint + p_pseudo_pp[i]) / 2;
					}
				}
			}
		}

		/*----------------------------------------------------------*/
		/* out copy */
		/*----------------------------------------------------------*/
		{
			/*------------------------------------------------------*/
			/* PP copy */
			/*------------------------------------------------------*/
			for (int i = 0; i < n; i++) {
				dynthScoreList.dynthRecords[i].percentagePoint = p_sl_tmp[0].dynthRecords[i].percentagePoint;
			}
		}

		/*--------------------------------------------------------------*/
		/* Destroy -- no longer necessary */
		/*--------------------------------------------------------------*/
		{
			// dynth_DestroyScoreList(p_sl_tmp);
			// free(p_scr);
		}

		return DYNTH_SUCCESS;
	}

	/**
	 * 
	 * @param scr_m
	 *            focus score
	 * @param p_scr_nm
	 *            Descend order array
	 * @param n
	 *            number after focus score
	 * @param dbsz
	 *            DB size
	 * @param p_pp
	 *            focus score percentage point
	 * @return
	 */
	private static int sDynth_CalcPP(int scr_m, int[] p_scr_nm, int n,
			int dbsz, double[] p_pp) {
		int i, k;
		int b;
		int[] S, C;
		double[] T, P, X, myT;

		/*----------------------------------------------*/
		/* check data */
		/*----------------------------------------------*/

		/*------------------------------------------------*/
		/* Initial */
		/*------------------------------------------------*/
		{
			/*--------------------------------------*/
			/* histogram bin count */
			/*--------------------------------------*/
			b = Math.min(BIN_SIZE, n);

			/*----------------------------------------*/
			/* work area */
			/*----------------------------------------*/
			{
				S = new int[n];
				C = new int[b + 1];
				T = new double[b + 1];
				myT = new double[b + 1];
				P = new double[b + 1];
				X = new double[b + 1];
			}

			/*--------------------------------------*/
			/* copy score array */
			/*--------------------------------------*/
			{
				// memcpy(S, p_scr_nm, sizeof(int) * n);
				// from C to Java --by Su
				for (i = 0; i < n; i++) {
					S[i] = p_scr_nm[i];
				}
			}
		}

		/*----------------------------------------------*/
		/* T[k] percent array (bin) */
		/*----------------------------------------------*/
		{
			double bl;

			bl = (double) (S[0] - S[n - 1]) / (double) b;
			/*--------------------------------------*/
			/* binning error */
			/*--------------------------------------*/
			if (bl == 0.0) {
				// free(S); // free no longer necessary
				// free(C);
				// free(T);
				// free(P);
				// free(X);
				return DYNTH_ERROR_INTERNAL;
			}

			/*--------------------------------------*/
			/* percent array */
			/*--------------------------------------*/
			{
				T[0] = (double) S[0] + 1;
				T[b] = (double) S[n - 1];

				myT[b - 1] = T[b];

				for (k = 1; k <= b; k++) {
					T[k] = (int) (S[0] - k * bl);
					myT[k - 1] = T[k];
				}
			}
		}

		/*----------------------------------------------*/
		/* C[k] count array (histgram) */
		/*----------------------------------------------*/
		{
			/*--------------------------------------*/
			/* score count for each bin */
			/*--------------------------------------*/
			for (k = 0; k <= b; k++) {
				for (i = 0; i < n; i++) {
					if (S[i] < T[k] && S[i] >= T[k + 1]) {
						C[k]++;
					}
				}
			}

			/*--------------------------------------*/
			/* C[k] > 0 count C[k] */
			/*--------------------------------------*/
			{
				int cnt;
				cnt = 0;

				for (k = 0; k < b; k++) {
					if (C[k] > 0) {
						cnt++;
					}
				}

				/*------------------------------*/
				/* if no result */
				/*------------------------------*/
				if (cnt <= 1) {
					// free(S);
					// free(C);
					// free(T);
					// free(P);
					// free(X);
					return DYNTH_ERROR_INTERNAL;
				}

			}
		}

		/*----------------------------------------------*/
		/* P[k] Probability */
		/*----------------------------------------------*/
		{
			int sum;

			for (k = 0; k < b; k++) {
				sum = 0;

				for (i = 0; i <= k; i++) {
					sum += C[i];
				}
				P[k] = (double) sum / (double) dbsz;
			}
		}

		/*----------------------------------------------*/
		/* X[k] percent array */
		/*----------------------------------------------*/
		{
			for (k = 0; k < b; k++) {
				X[k] = sDynth_NormSInv(1.0 - P[k]);
			}
		}

		/*----------------------------------------------*/
		/* focus percent point count */
		/*----------------------------------------------*/
		{
			double c[] = new double[2];
			double r[], m, s;
			r = new double[1];

			/*--------------------------------------*/
			/* Initial */
			/*--------------------------------------*/
			// memset(c, 0x00, sizeof(double) * 2); // -no longer necessary

			/*--------------------------------------*/
			/* resoulte simultaneous equations */
			/*--------------------------------------*/
			// sDynth_GenLstSqrsFit(T + 1, X, b, 1, c, r);
			// T+1 only usefull at C, changed -- by Su
			sDynth_GenLstSqrsFit(myT, X, b, 1, c, r);

			/*--------------------------------------*/
			/* percent count */
			/*--------------------------------------*/
			{
				m = -c[0] / c[1];
				s = 1.0 / c[1];
				p_pp[0] = ((double) scr_m - m) / s;
			}
		}

		/*----------------------------------------------*/
		/* free -- no longer necessary */
		/*----------------------------------------------*/
		{
			// free(S);
			// free(C);
			// free(T);
			// free(P);
			// free(X);
		}

		return DYNTH_SUCCESS;
	}

	/**
	 * 
	 * @param x
	 *            x array
	 * @param y
	 *            y array
	 * @param n
	 *            array count
	 * @param m
	 *            degree [1, 3]
	 * @param c
	 *            output double array
	 * @param r2
	 *            ouput double array
	 * @return
	 */
	private static int sDynth_GenLstSqrsFit(double[] x, double[] y, int n,
			int m, double[] c, double[] r2) {
		int i, j, k, m2, mp1, mp2;
		double[] a, w;

		/*----------------------------------------------*/
		/* 1--3 degree approximation */
		/*----------------------------------------------*/
		if (m >= n || m < 1 || m > 3) {
			return DYNTH_ERROR_INVALID_ARGUMENT;
		}

		/*----------------------------------------------*/
		/* work area */
		/*----------------------------------------------*/
		mp1 = m + 1;
		mp2 = m + 2;
		m2 = 2 * m;

		a = new double[mp1 * mp2];

		w = new double[mp1 * 2];
		/*----------------------------------------------*/
		/* resoulte simultaneous equations */
		/*----------------------------------------------*/
		{
			double aik, pivot, w1, w2, w3;

			for (i = 0; i < m2; i++) {
				w1 = 0.0;
				for (j = 0; j < n; j++) {
					w2 = w3 = x[j];
					for (k = 0; k < i; k++) {
						w2 *= w3;
					}
					w1 += w2;
				}
				w[i] = w1;
			}

			a[0] = (double) n;
			for (i = 0; i < mp1; i++) {
				for (j = 0; j < mp2; j++) {
					if (i != 0 || j != 0) {
						a[i * mp2 + j] = w[i + j - 1];
					}
				}
			}

			w1 = 0.0;
			for (i = 0; i < n; i++) {
				w1 += y[i];
			}

			a[mp1] = w1;
			for (i = 0; i < m; i++) {
				w1 = 0.0;
				for (j = 0; j < n; j++) {
					w2 = w3 = x[j];
					for (k = 0; k < i; k++) {
						w2 *= w3;
					}
					w1 += (y[j] * w2);
				}
				a[mp2 * (i + 1) + mp1] = w1;
			}

			for (k = 0; k < mp1; k++) {
				pivot = a[mp2 * k + k];
				a[mp2 * k + k] = 1.0;
				for (j = k + 1; j < mp2; j++) {
					a[mp2 * k + j] /= pivot;
				}
				for (i = 0; i < mp1; i++) {
					if (i != k) {
						aik = a[mp2 * i + k];
						for (j = k; j < mp2; j++) {
							a[mp2 * i + j] -= (aik * a[mp2 * k + j]);
						}
					}
				}
			}
		}

		/*-----------------------------------------------*/
		/* approximation */
		/*-----------------------------------------------*/
		for (i = 0; i < mp1; i++) {
			c[i] = a[mp2 * i + mp1];
		}

		/*----------------------------------------------*/
		/* R2 count */
		/*----------------------------------------------*/
		{
			double _y, s1, s2, tmp;
			/*-----------------------------*/
			/* original data average count */
			/*-----------------------------*/
			_y = 0.0;
			for (i = 0; i < n; i++) {
				_y += y[i];
			}
			_y /= n;

			/*--------------------------*/
			/* distribution count */
			/*--------------------------*/
			s1 = 0.0;
			s2 = 0.0;

			for (i = 0; i < n; i++) {
				tmp = sDynth_EvalPoly(c, x[i], m) - _y;
				s1 += (tmp * tmp);
				tmp = y[i] - _y;
				s2 += (tmp * tmp);
			}

			/*--------------------------*/
			/* R2 count */
			/*--------------------------*/
			r2[0] = s1 / s2;
		}

		/*----------------------------------------------*/
		/* Free -- no longer necessary in Java --By Su */
		/*----------------------------------------------*/
		// free(a);
		// free(w);

		/*----------------------------------------------*/
		/* quit */
		/*----------------------------------------------*/
		return DYNTH_SUCCESS;
	}

	/**
	 * input:Probability [0, 1]
	 * 
	 * @param p
	 * @return
	 */
	private static double sDynth_NormSInv(double p) {
		double w1, w3;
		int i;

		if (p < 0.0 || p > 1.0) {
			// fprintf(stderr, "Error : p <= 0 or p >= 1  in pnorm()!\n");
			// error, need to conver to Java
			String message = "Error : p <= 0 or p >= 1  in pnorm()!";
			log.error(message);
			return 0.0;
		}

		if (p == 0.5) {
			return 0.0;
		}

		w1 = p;
		if (p > 0.5) {
			w1 = 1.0 - w1;
		}

		w3 = -Math.log(4.0 * w1 * (1.0 - w1));
		w1 = b[0];

		for (i = 1; i < 11; i++) {
			w1 += (b[i] * Math.pow(w3, (double) i));
		}

		if (p > 0.5) {
			return Math.sqrt(w1 * w3);
		} else {
			return -Math.sqrt(w1 * w3);
		}
	}

	/**
	 * 
	 * @param c
	 *            pointer C to Java
	 * @param x
	 * @param n
	 * @return
	 */
	private static double sDynth_EvalPoly(double[] c, double x, int n) {
		int i;
		double w;

		w = c[n];
		for (i = n - 1; i >= 0; i--) {
			w = w * x + c[i];
		}

		return w;
	}

	private static int sDynth_SetRank(DynthScoreList p_sl[]) {
		int n, r;
		DynthScoreList p_sl_tmp[] = new DynthScoreList[1];

		n = p_sl[0].n;

		/*-------------------------------------------------------*/
		/* Create temporary score list */
		/*-------------------------------------------------------*/
		{
			/*----------------------------------------------*/
			/* copy the score list */
			/*----------------------------------------------*/
			{
				p_sl[0].sDynth_DuplicateScoreList(p_sl_tmp);
			}
		}

		/*-------------------------------------------------------*/
		/* rank */
		/*-------------------------------------------------------*/
		{
			DynthRecord p_rec;

			/*-----------------------------------------------*/
			/* Initial */
			/*-----------------------------------------------*/
			{
				r = 1;
				int my_i = 0;
				p_rec = p_sl_tmp[0].dynthRecords[my_i];
				p_rec.rank = r;

				for (int i = 0; i < n; i++) {
					if (p_rec.fusionScore > 0) {
						p_rec.rank = r;
						r++;
					} else {
						p_rec.rank = 0;
					}
					// p_rec++; // --- changed from C to Java -- by Su
					my_i++;

					// difference with C & java, do not use last data -- by Su
					if (my_i >= n)
						continue;

					p_rec = p_sl_tmp[0].dynthRecords[my_i];
				}
			}

			/*-----------------------------------------------*/
			/* edit rank for same score */
			/*-----------------------------------------------*/
			for (int i = n - 1; i >= 1; i--) {
				r = p_sl_tmp[0].dynthRecords[i].rank;
				if (p_sl_tmp[0].dynthRecords[i - 1].fusionScore == p_sl_tmp[0].dynthRecords[i].fusionScore) {
					p_sl_tmp[0].dynthRecords[i - 1].rank = p_sl_tmp[0].dynthRecords[i].rank;
				}
			}
		}

		/*------------------------------------------------------*/
		/* copy to output */
		/*------------------------------------------------------*/
		{
			/*----------------------------------------------*/
			/* copy rank */
			/*----------------------------------------------*/
			for (int i = 0; i < n; i++) {
				p_sl[0].dynthRecords[i].rank = p_sl_tmp[0].dynthRecords[i].rank;
			}
		}

		/*------------------------------------------------------*/
		/* Destroy temporary record list */
		/* -----no longer necessary in Java */
		/*------------------------------------------------------*/
		// dynth_DestroyScoreList(&p_sl_tmp);

		return DYNTH_SUCCESS;
	}

}
