package jp.co.nec.aim.mm.identify.dispatch;

import java.io.Serializable;

/**
 * Inquiry Distributor Information <br>
 * 
 * fetch from database with plan id and used for build PBMapInquiryJobRequest
 * instance
 * 
 * @author liuyq
 * 
 */
public class InqDispatchInfo implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 2816271566433653882L;

	private byte[] inquiryData;
	private String inquiryRequstXml;
	private int requestIndex;

	private int messageSequence;
	private long jobTimeout;
	private int internalMaxCandidates;
	private long containerJobId;

	/**
	 * InqDistributorInfo constructor
	 */
	public InqDispatchInfo() {
	}

	public byte[] getInquiryData() {
		return inquiryData;
	}

	public void setInquiryData(byte[] inquiryData) {
		this.inquiryData = inquiryData;
	}

	public int getRequestIndex() {
		return requestIndex;
	}

	public void setRequestIndex(int requestIndex) {
		this.requestIndex = requestIndex;
	}

	public int getMessageSequence() {
		return messageSequence;
	}

	public void setMessageSequence(int messageSequence) {
		this.messageSequence = messageSequence;
	}

	public long getJobTimeout() {
		return jobTimeout;
	}

	public void setJobTimeout(long jobTimeout) {
		this.jobTimeout = jobTimeout;
	}

	public int getInternalMaxCandidates() {
		return internalMaxCandidates;
	}

	public void setInternalMaxCandidates(int internalMaxCandidates) {
		this.internalMaxCandidates = internalMaxCandidates;
	}

	public long getContainerJobId() {
		return containerJobId;
	}

	public void setContainerJobId(long containerJobId) {
		this.containerJobId = containerJobId;
	}

	public String getInquiryRequstXml() {
		return inquiryRequstXml;
	}

	public void setInquiryRequstXml(String inquiryRequstXml) {
		this.inquiryRequstXml = inquiryRequstXml;
	}	

}
