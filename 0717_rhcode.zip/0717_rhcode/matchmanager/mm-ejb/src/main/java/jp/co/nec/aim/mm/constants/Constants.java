package jp.co.nec.aim.mm.constants;

public class Constants {

	public static final String ENCODING_UTF8 = "UTF-8";

	public static final int MAX_TIMED_OUT_JOB_BATCH = 1000;

	public static final String PLAN_MAX_SESSION = "50";

	public static final int SM_SEND_TIMEOUT = 10000;
	
	public static final String dmGetTemplate = "getTemplate";
	
	public static final String dmSync = "dmSyncSegment";
	
	public static final String dmGetTemplateByRefId = "getTemplateByRefId";
	
	public static final String MR_LOCK_NAME = "mrLockName";	
	
}
