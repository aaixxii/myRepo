--------------------------------------------------------
--  �t�@�C�����쐬���܂��� - ���j��-11��-12-2018   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function SAVE_ONE_SEG_BK_LOG
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "XMPERF"."SAVE_ONE_SEG_BK_LOG" 
(
  START_BIOMETRIC_ID IN NUMBER 
, BIN_ID IN NUMBER 
, SEGMENT_ID IN NUMBER 
) RETURN VARCHAR2 AUTHID CURRENT_USER IS 
    v_blob_locater		blob;
	v_offset		integer := 1;
	v_buffer		long raw;	
	v_file_buffer_size	integer := 32000;
	v_amount		integer := 32000;
	v_totalsize		integer;
	v_filetype		utl_file.file_type;	
	v_openmode		varchar2(2) := 'wb';
    l_back_log_file_name VARCHAR2(36);
    l_hour  VARCHAR2(2);
BEGIN
    SELECT TO_CHAR(systimestamp, 'HH24') INTO l_hour FROM dual;
     -- l_back_log_path:= l_back_log_path  || '/' || BIN_ID || '/' || SEGMINET_ID || '/' || l_hour;
    l_back_log_file_name := SEGMENT_ID || '_' || '1' || '.dat';  
    select TEMPLATE_DATA into v_blob_locater from BIO_TEMPLATE_DATA_INFO where TEMPLATE_DATA_ID=START_BIOMETRIC_ID; 
	v_totalsize := dbms_lob.getlength(v_blob_locater);
	v_filetype := utl_file.fopen('SEG_BACK_LOG', l_back_log_file_name, v_openmode, v_file_buffer_size);

	while v_offset < v_totalsize loop
		if v_offset + v_amount > v_totalsize then
			v_amount := v_totalsize - v_offset + 1;
		end if;
		dbms_lob.read(
			v_blob_locater,
			v_amount, 
			v_offset,
			v_buffer
		);
		utl_file.put_raw(
			v_filetype,
			v_buffer,
			true
		);
		v_offset := v_offset + v_amount;
		--dbms_output.put_line ( 'Offset : ' || v_offset );
	end loop;	
	utl_file.fflush(v_filetype);
	utl_file.fclose(v_filetype);
     RETURN('SUCCESS!');
    EXCEPTION
      WHEN OTHERS THEN
      RETURN('FAILD!'); 
END SAVE_ONE_SEG_BK_LOG;

/
