--------------------------------------------------------
--  �t�@�C�����쐬���܂��� - ���j��-11��-12-2018   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function CREATE_SYNC_INDEX
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "XMPERF"."CREATE_SYNC_INDEX" 
(
  PERSON_ID IN NUMBER 
) RETURN VARCHAR2 AUTHID CURRENT_USER IS
  c_semicolon VARCHAR2(1) :=':';  
  c_l_brackets VARCHAR2(1) :='[';
  c_r_brackets VARCHAR2(1) :=']';
  c_comma VARCHAR2(1) :=',';
  c_l_curly_braces  VARCHAR2(1) :='{';
  c_r_curly_braces  VARCHAR2(1) :='}';
  c_double_code VARCHAR2(1) :='"';
  
  c_indexMi VARCHAR2(30)  := ' "indexTimestampMilli" ';
  c_bio_ev_list VARCHAR2(30) := ' "biometricEventInfoList" ';  
  c_biometric_id VARCHAR2(20) := ' "biometricId" ';  
  c_externalId VARCHAR2(20) := ' "externalId" ';  
  c_eventId VARCHAR2(20) := ' "eventId" ';  
  c_binId VARCHAR2(20) := ' "binId" ';  
  c_status VARCHAR2(20) := ' "status" ';  
  c_phase VARCHAR2(20) := ' "phase" ';  
  c_templateDataKey VARCHAR2(20) := ' "templateDataKey" ';  
  c_templateSize VARCHAR2(20) := ' "templateSize" ';  
  c_dataVersion VARCHAR2(20) := ' "dataVersion" ';  
  c_assignedSegmentId VARCHAR2(30) := ' "assignedSegmentId" ';  
  c_createDateTime VARCHAR2(20) := ' "createDateTime" '; 
  c_updateDateTime VARCHAR2(20) := ' "updateDateTime" ';
  c_siteId VARCHAR2(20) := ' "siteId" ';  
  
  v_json  VARCHAR2(4096);  
  row_json  VARCHAR2(2048);
  l_back_log_path VARCHAR2(128 BYTE);
  l_back_log_file_name VARCHAR2(36);
  l_hour  VARCHAR2(15);
  l_bin_id NUMBER;
  l_segment_id NUMBER;
  l_segment_version NUMBER;
  l_rec  BIO_EVENT_INFO%ROWTYPE;
  
   t_out_file   UTL_FILE.file_type;
   t_buffer     VARCHAR2(32767);
   t_amount     BINARY_INTEGER := 1000;
   t_pos        INTEGER := 1;
   t_clob_len   INTEGER;
   P_DATA CLOB;

  l_file    utl_file.file_type;
  l_amt     NUMBER := 32000;
  l_offset  NUMBER := 1;  
  l_buffer LONG RAW;
  l_file_buffer_size   INTEGER := 32000;
  l_totalsize NUMBER;  

BEGIN
    SELECT TO_CHAR(systimestamp, 'HH24') INTO l_hour FROM dual;
   SELECT * INTO  l_rec FROM BIO_EVENT_INFO WHERE BIOMETRIC_ID=PERSON_ID;
    l_bin_id := l_rec.BIN_ID;
   l_segment_id := l_rec.ASSIGNED_SEGMENT_ID;
   l_segment_version := l_rec.DATA_VERSION;
   
   v_json := c_l_curly_braces || c_indexMi  || c_semicolon || SYSDATE  || c_comma || c_bio_ev_list || c_semicolon || c_l_brackets || c_l_curly_braces;
   dbms_output.put_line(v_json);
   
   row_json := c_biometric_id || c_semicolon || l_rec.BIOMETRIC_ID || c_comma ||
                c_externalId || c_semicolon || l_rec.EXTERNAL_ID || c_comma ||
                c_eventId || c_semicolon || l_rec.EVENT_ID || c_comma ||
                c_binId  || c_semicolon || l_rec.BIN_ID || c_comma ||
                c_status || c_semicolon || c_double_code || l_rec.STATUS || c_double_code || c_comma ||              
                c_phase || c_semicolon ||  c_double_code || l_rec.PHASE ||  c_double_code || c_comma ||            
                c_templateDataKey || c_semicolon || c_double_code || l_rec.TEMPLATE_DATA_KEY ||  c_double_code || c_comma ||
               c_templateSize || c_semicolon || l_rec.TEMPLATE_SIZE || c_comma ||
               c_dataVersion || c_semicolon || l_rec.DATA_VERSION || c_comma ||
               c_assignedSegmentId  || c_semicolon || l_rec.ASSIGNED_SEGMENT_ID || c_comma ||
               c_createDateTime || c_semicolon ||  c_double_code || l_rec.CREATE_DATETIME || c_double_code || c_comma ||
               c_updateDateTime || c_semicolon ||  c_double_code || l_rec.UPDATE_DATETIME ||  c_double_code || c_comma ||
               c_siteId || c_semicolon ||  c_double_code || l_rec.SITE_ID ||  c_double_code;
     v_json :=  v_json || row_json ||  c_r_curly_braces || c_r_brackets || c_r_curly_braces;
     
      dbms_output.put_line(row_json);
      dbms_output.put_line(v_json);     
    SELECT value INTO l_back_log_path FROM BIO_PARAMETERS WHERE name ='SEGMENT_CHANGE_SET_STORAGE_PATH';
    l_back_log_path := l_back_log_path  || '/' || l_bin_id || '/' || l_segment_id || '/' || l_hour;
    l_back_log_file_name := TO_CHAR(l_segment_id) || '_' || l_segment_version || '.idx';
    
    P_DATA := v_json;
   t_clob_len := DBMS_LOB.GetLength(P_DATA);
   t_out_file := UTL_FILE.fOpen('SEG_BACK_LOG',l_back_log_file_name, 'W', 32767);
      WHILE t_pos < t_clob_len LOOP  
      DBMS_LOB.Read(p_data, t_amount, t_pos, t_buffer);
      UTL_FILE.Put(t_out_file, t_buffer);
      UTL_FILE.fflush(t_out_file);      
      t_pos := t_pos + t_amount;
   END LOOP;
   UTL_FILE.fclose(l_file);
  RETURN  'SUCCESS'; 
  EXCEPTION
    WHEN OTHERS THEN   
     IF UTL_FILE.is_open(l_file) THEN
          UTL_FILE.fclose(l_file);
    END IF;
    RETURN 'FAILD';
END CREATE_SYNC_INDEX;

/
