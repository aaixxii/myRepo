package com.nec.aim.dm.nodostorage.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.concurrent.ExecutionException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nec.aim.dm.nodostorage.exception.NodeStroageException;
import com.nec.aim.dm.nodostorage.service.TemplateService;

import lombok.extern.slf4j.Slf4j;



@Controller
@Slf4j
public class TemplateController extends HttpServlet {
	private static final long serialVersionUID = -5368691957495983136L;
	
	@Autowired
	TemplateService templateService;	
	
	@RequestMapping("/gettemplate/")
	public void getTemplate(HttpServletRequest req, HttpServletResponse res, @RequestParam("segmentid") Long segId, @RequestParam("bioid") Long bioId) throws IOException, SQLException, InterruptedException, ExecutionException {		
		log.info("Received getTemplate from {}", req.getRemoteHost());
		byte[] templateData = templateService.getTemplate(segId, bioId);	
		if (templateData != null && templateData.length > 0) {
			long length = templateData.length;
			res.setContentType("application/binary");
			res.addHeader("Content-Length", Long.toString(length));			
			res.getOutputStream().write(templateData);
			res.setStatus(200);
			log.info("Success send template data , segmentId={}, bioId={}", segId, bioId);
		} else {
			throw new NodeStroageException("Faild to get template data, segmentId=" + segId + "bioId=" + bioId);
		}	
	}
}
