package com.nec.aim.dm.nodostorage.service;

import static com.nec.aim.dm.nodostorage.segments.DmConstants.SEGMENT_HEADER_SIZE;

import java.sql.Blob;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.protobuf.ByteString;
import com.nec.aim.dm.nodostorage.config.ConfigProperties;
import com.nec.aim.dm.nodostorage.entity.SegChangeLog;
import com.nec.aim.dm.nodostorage.manager.NodeStorageManager;
import com.nec.aim.dm.nodostorage.repository.CatchupRepository;
import com.nec.aim.dm.nodostorage.repository.CommitDao;
import com.nec.aim.dm.nodostorage.repository.NodeStorageRepository;
import com.nec.aim.dm.nodostorage.repository.SegmentLoadRepository;
import com.nec.aim.dm.nodostorage.segments.SegmentWriter;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import jp.co.nec.aim.message.proto.AIMMessages.PBTargetSegmentVersion;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DBSerivce {

	@Autowired
	NodeStorageRepository nodeStorageRepository;

	@Autowired
	SegmentLoadRepository segmentLoadRepository;

	@Autowired
	CommitDao commitDao;

	@Autowired
	ConfigProperties config;

	@Autowired
	CatchupRepository catchupRepository;
	
	public void doHeatBeat() {
		try {
			commitDao.doBegin();
			nodeStorageRepository.heatbeat();
			commitDao.doCommit();
		} catch (SQLException e) {
			commitDao.doRollback();
			log.error("SQLException happend, heatbeat process do rollback.");
		}
		
	}

	public void doCatchup() {	
		try {
//			int mailFlagCont = nodeStorageRepository.getMyMailFlag();
//			if (mailFlagCont > 0) {
//				catchUp();
//			} else {
//				log.info("No catchup to do");
//			}
			catchUp();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}

	private void catchUp() throws SQLException {
		log.info("catchup is run!");
		List<SegChangeLog> mustCatchUps = null;
		try {		
			mustCatchUps = catchupRepository.getMyCathup(config.getId());
			log.info("mustCatchUps count={}", mustCatchUps.size() );
		} catch (SQLException e) {
			log.error(e.getMessage(), e);
			return;

		}
		if (null == mustCatchUps || mustCatchUps.isEmpty()) {
			return;
		}
		
		for (SegChangeLog cp : mustCatchUps) {
			try {
				if (cp.getChangeType() == 0) {
					SegmentWriter sw = new SegmentWriter(cp.getSegmentId(), cp.getBiometricsId());
					if (sw.writeSegmentHead().booleanValue()) {
						try {
							commitDao.doBegin();
							nodeStorageRepository.updateStorageSpace(SEGMENT_HEADER_SIZE,
									NodeStorageManager.getIntDmConfigValue("myId"),
									NodeStorageManager.getStringDmConfigValue("myId"));
							catchupRepository.deleteAfterCatchup(config.getId(), cp.getSegmentId());
							nodeStorageRepository.clearMyMailFlag(config.getId());
							log.info("Success do catchup, catchuptype={} segmentId={}, segmentVer={}", cp.getChangeType(), cp.getSegmentId(), cp.getSegmentVersion());
							commitDao.doCommit();
						} catch (SQLException e) {
							commitDao.doRollback();
						}
					}

				} else if (cp.getChangeType() == 1) {
					PBDmSyncRequest.Builder dmSegReq = PBDmSyncRequest.newBuilder();					
					dmSegReq.setBioIdEnd(cp.getBiometricsId());
					dmSegReq.setCmd(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT);
					PBTargetSegmentVersion.Builder pt = PBTargetSegmentVersion.newBuilder();
					pt.setId(cp.getSegmentId());
					pt.setVersion(cp.getSegmentVersion());
					dmSegReq.setTargetSegment(pt.build());
					PBTemplateInfo.Builder templateInfo = PBTemplateInfo.newBuilder();
					templateInfo.setReferenceId(cp.getExternalId());
					Blob blob = cp.getTemplateData();
					int blobLength = (int) blob.length();
					byte[] blobAsBytes = blob.getBytes(1, blobLength);
					templateInfo.setData(ByteString.copyFrom(blobAsBytes));
					dmSegReq.setTemplateData(templateInfo.build());
					log.info("run in chang type1");
					SegmentWriter segWriter = NodeStorageManager.getSegmentWriter(cp.getSegmentId());
					if (null == segWriter) {
						log.error("Can't found SegmentWriter instance, segmentId=" + cp.getSegmentId() + "ChangeType="+  SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT) ;	
						return;
					}
					if (segWriter.writeTemplate(dmSegReq.build()).booleanValue()) {					
						try {
							commitDao.doBegin();
							nodeStorageRepository.updateStorageSpace(
									NodeStorageManager.getIntDmConfigValue("templateSize"),
									NodeStorageManager.getIntDmConfigValue("myId"),
									NodeStorageManager.getStringDmConfigValue("myDmId"));
							catchupRepository.deleteAfterCatchup(config.getId(), cp.getSegmentId());
							nodeStorageRepository.clearMyMailFlag(config.getId());
							commitDao.doCommit();
							log.info("Success do catchup, catchuptype={} segmentId={}, segmentVer={}", cp.getChangeType(), cp.getSegmentId(), cp.getSegmentVersion());
						} catch (SQLException e) {
							commitDao.doRollback();
						}
					}

				} else if (cp.getChangeType() == 2) {
					log.info("run in chang type2");
					SegmentWriter segWriter = NodeStorageManager.getSegmentWriter(cp.getSegmentId());
					if (null == segWriter) {
						log.error("Can't found SegmentWriter instance, segmentId=" + cp.getSegmentId() + "ChangeType="+  SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT) ;	
						return;					
					}
					if (segWriter.deleteTemplate(cp.getSegmentId(), cp.getSegmentVersion(), cp.getBiometricsId(),
							cp.getExternalId()).booleanValue()) {
						try {
							commitDao.doBegin();
							nodeStorageRepository.updateStorageSpace(
									-1 * NodeStorageManager.getIntDmConfigValue("templateSize"),
									NodeStorageManager.getIntDmConfigValue("myId"),
									NodeStorageManager.getStringDmConfigValue("myDmId"));
							catchupRepository.deleteAfterCatchup(config.getId(), cp.getSegmentId());
							nodeStorageRepository.clearMyMailFlag(config.getId());
							log.info("Success do catchup, catchuptype={} segmentId={}, segmentVer={}", cp.getChangeType(), cp.getSegmentId(), cp.getSegmentVersion());
							commitDao.doCommit();
						} catch (SQLException e) {
							commitDao.doRollback();
						}
					}
				}
			} catch (Exception e) {
				log.error(e.getMessage(), e);
			}
		}
	}
}
