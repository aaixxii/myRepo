package com.nec.aim.dm.nodostorage.repository;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.nec.aim.dm.nodostorage.entity.SegChangeLog;



@Repository
public class CatchupRepositoryLmpl implements CatchupRepository {
	//private String getMyCatchupSql = "select * from catchup where storage_id=:storageId and segment_id in (:segmentIds)";
	private String getCatchupSql = "select sc.biometrics_id,sc.external_id,sc.template_data,sc.segment_id,sc.segment_version, sc.change_type" 
			+ " from segment_change_log sc, segment_ref_storage_info sr "
			+ " where sc.segment_id = sr.segment_id and sr.storage_id =?";
	private String delCatchupSql = "delete from segment_change_log where segment_id =? and EXISTS (select * from segment_ref_storage_info  where segment_id = ? and storage_id =?)";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	RowMapper<SegChangeLog> catchupRowMapper = (rs, rowNum) -> {
		SegChangeLog cp = new SegChangeLog();
		//cp.setSegmentChangId(rs.getLong("segment_change_id"));
		cp.setBiometricsId(rs.getLong("biometrics_id"));		
		cp.setChangeType(rs.getInt("change_type"));
		cp.setExternalId(rs.getString("external_id"));
		cp.setSegmentId(rs.getLong("segment_id"));
		cp.setSegmentVersion(rs.getLong("segment_version"));		
		cp.setTemplateData(rs.getBlob("template_data"));
		return cp;
	};

//	@Override
//	public List<Catchup> getMyCathupData(Integer storageId, List<Long> segmentIds) throws SQLException {
//		NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
//				jdbcTemplate.getDataSource());
//		Map<String, Object> params = new HashMap<>();
//		params.put("storageId", storageId);
//		params.put("segmentIds", segmentIds);
//		return namedParameterJdbcTemplate.query(getMyCatchupSql, params, catchupRowMapper);
//	}

	@Override

	public void deleteAfterCatchup(Integer storageId, Long segmentId) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(delCatchupSql, new Object[] { segmentId, segmentId, storageId });
	}

	@Override
	public List<SegChangeLog> getMyCathup(Integer storageId) throws SQLException {
		return jdbcTemplate.query(getCatchupSql, new Object[] {storageId}, catchupRowMapper);
	}
}
