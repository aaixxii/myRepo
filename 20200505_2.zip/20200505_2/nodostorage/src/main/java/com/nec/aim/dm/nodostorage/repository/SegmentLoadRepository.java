package com.nec.aim.dm.nodostorage.repository;

import java.sql.SQLException;
import java.util.List;

public interface SegmentLoadRepository {
	public List<Long> getMustCatchUpSegments() throws SQLException;	
}
