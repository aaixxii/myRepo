package com.nec.aim.uid.client.post;

import static com.nec.aim.uid.client.common.UidClientConstants.DM_SERVICES_URLS;
import static com.nec.aim.uid.client.common.UidClientConstants.DM_WEB_CONTENT;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.aim.uid.client.manager.UidCommonManager;
import com.nec.aim.uid.client.manager.UidDmJobRunManager;
import com.nec.aim.uid.client.util.StopWatch;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;

public class HeatbeatPoster implements Runnable{
	private static Logger logger = LoggerFactory.getLogger(DmRequestPoster.class);	
	private String dmWebContent;
	private String dmIpAndports;
	private  int postTimeOut = 6000;	
	
	public HeatbeatPoster(String dmWebCtx, String dmIpPort, Integer postTimeOut) {
		this.dmWebContent = dmWebCtx;
		this.dmIpAndports = dmIpPort;
		this.postTimeOut = postTimeOut.intValue();		
		logger.info("Heatbeat util is run.");
	}
	
	
	public  int judgeDmServiceIsActive() {
		final StopWatch t = new StopWatch();
		t.start();		
		//Map<String, Boolean> dmActiveMap = new HashMap<>(); //key is url
		List<String> activeDms = new ArrayList<>(); //key is url
		dmWebContent = UidCommonManager.getValue(DM_WEB_CONTENT);
		dmIpAndports = UidCommonManager.getValue(DM_SERVICES_URLS);
		if (dmWebContent == null || dmWebContent.isEmpty() || dmIpAndports == null || dmIpAndports.isEmpty()) {
			logger.error("The setting of dmWebContent or dmIpAndport have some worng!");		
		}
		String[] ipAndpotArr = dmIpAndports.split(",");
		String[] urlArr = new String[ipAndpotArr.length];
		for (int i = 0; i < ipAndpotArr.length; i++) {
			urlArr[i] = "http://" + ipAndpotArr[i] + "/" + dmWebContent + "/heatbeat";
		}
		for (int i = 0; i < urlArr.length; i++) {
			Boolean oneResult = sendHeatbeat(urlArr[i]);
			//dmActiveMap.put(urlArr[i], oneResult);
			if (oneResult.booleanValue()) {
				String baseUrl = urlArr[i].substring(0, urlArr[i].length() -9);
				activeDms.add(baseUrl);
			}
		}
		UidDmJobRunManager.updateActiveDmSeriveList(activeDms);	
		logger.info("Active dm service count is {}", activeDms.size());
		return activeDms.size();
	}
	private  Boolean sendHeatbeat(String dmUrl) {
		final StopWatch t = new StopWatch();
		t.start();
		OkHttpClient client = new OkHttpClient();
		client.setConnectTimeout(10, TimeUnit.SECONDS);
		client.setReadTimeout(20, TimeUnit.SECONDS);
		client.setWriteTimeout(30, TimeUnit.SECONDS);
		Request request = new Request.Builder().url(dmUrl).build();
		try {
			Response response = client.newCall(request).execute();
			t.stop();
			if (response.code() == 200) {
				//logger.info("Send heatbeat package to {}  used time={} and status={}",  dmUrl, t.elapsedTime(), response.code());
				logger.info("DmSerice({}) is active.",  dmUrl);
					String resStr = response.body().string();	
					if (resStr != null && ! resStr.isEmpty() && resStr.contains("active")) {
						return Boolean.TRUE;							
					} else {
						return Boolean.FALSE;
					}
				 
			} else {
				logger.error("DmSerice({}) is died!!!", dmUrl);						
				return Boolean.FALSE;
			}

		} catch (IOException e) {
			//logger.error(e.getMessage(), e);	
			String ExceptionName = null;
			if (e instanceof SocketTimeoutException) {
				ExceptionName = "SocketTimeoutException";
			} else {
				ExceptionName = "Unkown";
			}				
			logger.warn("DmSerice({}) is died due to Exception:{}", dmUrl, ExceptionName );
			return Boolean.FALSE;
		}		
	}
	@Override
	public void run() {
		judgeDmServiceIsActive();
		
	}
}
