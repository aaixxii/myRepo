package jp.co.nec.aim.mm.sessionbeans;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;

import jp.co.nec.aim.mm.acceptor.AimInquiryRequest;
import jp.co.nec.aim.mm.acceptor.CommonOptions;
import jp.co.nec.aim.mm.acceptor.Inquiry;
import jp.co.nec.aim.mm.dao.FEJobDao;
import jp.co.nec.aim.mm.dao.MatchManagerDao;
import jp.co.nec.aim.mm.entities.FeJobPayloadEntity;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.util.XmlUtil;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class InquiryAfterExtractBean {
	
	private static Logger log = LoggerFactory.getLogger(InquiryAfterExtractBean.class);
	
	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;
	
	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;	
	
	@EJB
	private Inquiry inquiry;	
	
	private FEJobDao feJobDao;	
	private MatchManagerDao mmDao;	
	
	public InquiryAfterExtractBean() {
		// zero-arg ctor for container.
	}

	@PostConstruct
	public void init() {		
		this.feJobDao = new FEJobDao(manager, dataSource);
		mmDao = new MatchManagerDao(manager);
	}	
	
	public void getExtResAndDoInquriy(long feJobId) {
		
		log.info("Process PBMuExtractJobResultItem, jobId={}", feJobId);
		FeJobQueueEntity feJobInfo = feJobDao.getFeJobInfoById(feJobId);		
		String requestId = feJobInfo.getRequestId();		
		 FeJobPayloadEntity payload = feJobDao.getFeJobPayload(feJobId);
		 String inqRequest = payload.getPayload();
		 String maxResults = XmlUtil.getIdentifyAtribute(inqRequest, "maxResults");
		
		byte[] templateData = feJobInfo.getTempalteData();
		if (templateData != null && templateData.length > 1) {
			AimInquiryRequest aimInquiryRequest = new AimInquiryRequest("MI", Integer.valueOf(1),
					feJobInfo.getRequestId(), inqRequest, templateData);
			final List<AimInquiryRequest> aimRequestList = Lists.newArrayList();
			aimRequestList.add(aimInquiryRequest);
			final CommonOptions options = new CommonOptions();
			String myUrl = mmDao.getMyIpAndPort();
			options.setFromServlet(false);
			options.setFunctioName("MI");
			options.setMaxCandidates(Integer.valueOf(maxResults));
			options.setCallBackUrl(myUrl);
			inquiry.inquiry(aimRequestList, requestId, options);
		}
	}
}
