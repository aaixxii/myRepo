package jp.co.nec.aim.mm.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class SystemInitDaoTest {
	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;
	@Resource
	private DataSource dataSource;
	@Resource
	JdbcTemplate jdbcTemplate;
	private SystemInitDao systemInitHelper;

	@Before
	public void before() {
		systemInitHelper = new SystemInitDao(entityManager);
		//jdbcTemplate.update("delete from system_init");

	}

	@After
	public void tearDown() throws Exception {
		//systemInitHelper = null;
		//jdbcTemplate.update("delete from system_init");

	}
	
	@Test
	public void testGetGallerySize() {
		Long gallerySize = systemInitHelper.getGallerySize();
		Assert.assertEquals(10000000000l, gallerySize.longValue());
	}
	
	@Test
	public void testGetClearFlag() {
		String flag = systemInitHelper.getClearFlag();
		Assert.assertEquals("TRUE", flag);
	}
	
	@Test
	public void testGetSegChangeLogSaveDays() {
		Long saveDays = systemInitHelper.getSegChangeLogSaveDays();
		Assert.assertEquals(10, saveDays.longValue());		
	}
	
	@Test
	public void testUpdateSegChangeLogSaveDays() {
		systemInitHelper.updateSegChangeLogSaveDays("7");
		Long saveDays = systemInitHelper.getSegChangeLogSaveDays();
		Assert.assertEquals(7, saveDays.longValue());	
	}
	
	@Test
	public void testGetInUsingAdjust() {
		Long adjust = systemInitHelper.getInUsingAdjust();
		Assert.assertEquals(0, adjust.longValue());	
	}
	
	@Test
	public void testUpdateInUsingAdjuist() {
		systemInitHelper.updateInUsingAdjuist(1L);
		Long adjust = systemInitHelper.getInUsingAdjust();
		Assert.assertEquals(1, adjust.longValue());	
	}

	@Test
	public void testGetUnitNetWorkSegment_dbNoData() {
		String notifyEntity = systemInitHelper.getUnitNetWorkSegment();
		assertNull(notifyEntity);
	}

	@Test
	public void testGetUnitNetworkSegment_dbHaveData() {
		jdbcTemplate.execute("Insert into SYSTEM_INIT (INIT_ID, KEY_NAME,"
				+ " KEY_VALUE) values (2, 'UNIT_NETWORK_SEGMENT',"
				+ " '192.168.22.255,192.168.21.255')");
		String notifyEntity = systemInitHelper.getUnitNetWorkSegment();
		assertNotNull(notifyEntity);
		assertEquals("192.168.22.255,192.168.21.255", notifyEntity);
	}

	@Test
	public void testGetUnitWakeupPort_dbNoData() {
		Integer notifyEntity = systemInitHelper.getUnitWakeupPort();
		assertNull(notifyEntity);
	}

	@Test
	public void testGetUnitWakeupPort_dbHaveData() {
		jdbcTemplate.execute("Insert into SYSTEM_INIT (INIT_ID, KEY_NAME,"
				+ " KEY_VALUE) values (2, 'UNIT_WAKEUP_PORT', '1234')");
		Integer notifyEntity = systemInitHelper.getUnitWakeupPort();
		assertNotNull(notifyEntity);
		assertEquals("1234", String.valueOf(notifyEntity));
	}

	@Test
	public void testGetUnitWakeupPort_Exception() {
		jdbcTemplate.execute("Insert into SYSTEM_INIT (INIT_ID, KEY_NAME,"
				+ " KEY_VALUE) values (2, 'UNIT_WAKEUP_PORT', 'werwe')");
		Integer notifyEntity = systemInitHelper.getUnitWakeupPort();
		assertNull(notifyEntity);
	}

}
