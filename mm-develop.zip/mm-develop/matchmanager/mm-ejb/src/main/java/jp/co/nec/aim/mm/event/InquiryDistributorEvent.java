package jp.co.nec.aim.mm.event;

import java.io.Serializable;

import jp.co.nec.aim.mm.entities.ExecutePlanEntity;

/**
 * InquiryDistributorEvent
 * 
 * @author liuyq
 * 
 */
public class InquiryDistributorEvent implements Serializable {
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 4795015884997556684L;

	private ExecutePlanEntity plan; // plan

	public ExecutePlanEntity getPlan() {
		return plan;
	}

	public void setPlan(ExecutePlanEntity plan) {
		this.plan = plan;
	}

}
