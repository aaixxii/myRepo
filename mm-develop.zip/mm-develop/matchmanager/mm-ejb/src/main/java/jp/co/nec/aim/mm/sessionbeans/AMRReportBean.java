package jp.co.nec.aim.mm.sessionbeans;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.ScheduleExpression;
import javax.ejb.Singleton;
import javax.ejb.Timeout;
import javax.ejb.TimerConfig;
import javax.ejb.TimerService;

import jp.co.nec.aim.mm.constants.ConfigProperties;
import jp.co.nec.aim.mm.constants.ConfigPropertyNames;
import jp.co.nec.aim.mm.exception.HttpPostException;
import jp.co.nec.aim.mm.util.CollectionsUtil;
import jp.co.nec.aim.mm.util.HttpPoster;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.FileFilterUtils;
import org.apache.commons.io.filefilter.IOFileFilter;
import org.apache.commons.io.filefilter.RegexFileFilter;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Singleton Bean to send AMR Report
 * 
 * @author kurosu
 * 
 */
@Singleton
public class AMRReportBean {
	private static final Logger log = LoggerFactory
			.getLogger(AMRReportBean.class);

	@Resource
	private TimerService timerService;

	private static final int SM_TIMEOUT = 1200000;

	public void startReport() {
		// default ScheduleExpression is second: "0" minute: "0" hour: "0"
		// timeout will be called at 00:00:00 everyday.
		ScheduleExpression schedule = new ScheduleExpression();
		schedule.hour("*");
		TimerConfig config = new TimerConfig();
		config.setPersistent(false);
		timerService.createCalendarTimer(schedule, config);
		log.info("Report Timer is set to " + schedule);
	}

	@Timeout
	public void sendReport() {
		Date cutoffDate = Calendar.getInstance().getTime();
		cutoffDate = DateUtils.truncate(cutoffDate, Calendar.HOUR);
		for (ReportType reportType : ReportType.values()) {
			send(cutoffDate, reportType);
		}
	}

	private void send(Date cutoffDate, ReportType reportType) {
		String url = generateSMURL(reportType);
		List<File> deleteFiles = new ArrayList<File>();
		Collection<File> files = fetchPastLogFile(cutoffDate,
				reportType.getPrefix());

		if (CollectionsUtil.isEmpty(files)) {
			log.info("No " + reportType + " log for sending to SM.");
		}

		for (File file : files) {
			try {
				HttpPoster.smPost(url, FileUtils.readFileToString(file),
						SM_TIMEOUT);
				log.info("Sent " + file);
				log.info("Sent file size = " + file.length());
				deleteFiles.add(file);
			} catch (Exception e) {
				log.warn(file + " can't send to SM");
			}
		}
		for (File file : deleteFiles) {
			if (!file.delete()) {
				log.warn("failed to delete " + file
						+ ". Will be tried to send to SM again");
			}
		}
		if (0 < files.size() && CollectionsUtil.isEmpty(deleteFiles)) {
			log.warn("Not any " + reportType + " report was sent to SM");
		}
	}

	private String generateSMURL(ReportType reportType) {
		StringBuffer sb = new StringBuffer("http://");
		ConfigProperties prop = ConfigProperties.getInstance();
		sb.append(prop.getPropertyValue(ConfigPropertyNames.SM_IP_ADDRESS));
		sb.append(":");
		sb.append(prop.getPropertyValue(ConfigPropertyNames.SM_PORT));
		sb.append("/");
		sb.append(reportType.getUri());
		return sb.toString();
	}

	/**
	 * Fetch log files those have prefix and before, not equal to cutoffDate.
	 * AgeFileter selects files which is older or equal timestamp.
	 * 
	 * @param cutoffDate
	 * @param prefix
	 * @return
	 */
	protected Collection<File> fetchPastLogFile(Date cutoffDate, String prefix) {
		String path = System.getProperty("jboss.home.dir") + "/statistics";
		log.info("log dir: {}..", path);
		File logDir = new File(path);
		RegexFileFilter regexFilter = new RegexFileFilter(prefix
				+ "\\.log\\..*");
		Date oneMilliBefore = DateUtils.addMilliseconds(cutoffDate, -1);
		IOFileFilter ageFilter = FileFilterUtils.ageFileFilter(oneMilliBefore);
		IOFileFilter filter = FileFilterUtils.and(regexFilter, ageFilter);
		log.info("age file Filter date is: {}", new SimpleDateFormat(
				"yyyy-MM-dd HH:mm:ss").format(oneMilliBefore));
		return FileUtils.listFiles(logDir, filter, null);
	}

	enum ReportType {
		JOB_DONE("jobdone", "systemmanager/MMJobQueueHttpListener"), //
		FE_JOB_DONE("fejobdone", "systemmanager/MMExtractJobQueueHttpListener"); //
		private final String prefix;
		private final String uri;

		ReportType(String prefix, String uri) {
			this.prefix = prefix;
			this.uri = uri;
		}

		public String getPrefix() {
			return prefix;
		}

		public String getUri() {
			return uri;
		}
	}

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		AMRReportBean bean = new AMRReportBean();
		String url = bean.generateSMURL(ReportType.JOB_DONE);
		try {
			HttpPoster.post(url, FileUtils.readFileToString(new File(
					"c:\\statistics\\jobdone.log")),
					HttpPoster.DEFAULT_RETRY_COUNT);
		} catch (HttpPostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
