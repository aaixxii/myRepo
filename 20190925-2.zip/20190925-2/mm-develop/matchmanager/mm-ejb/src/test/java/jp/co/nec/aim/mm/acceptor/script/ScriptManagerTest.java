package jp.co.nec.aim.mm.acceptor.script;

import static org.junit.Assert.fail;

import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPrintType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerSetType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ImagePositionType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.TemplateFormatType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBInquiryScopeOptions;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplate;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateIndexer;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.InquiryFunctionType;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryFusionWeight;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest.PBSyncDeletePayload;
//import jp.co.nec.aim.mm.acceptor.script.ScriptManager.ScriptValue;
import jp.co.nec.aim.mm.acceptor.script.ScriptManager.ScriptFunction;
import jp.co.nec.aim.mm.dao.ServiceLayoutDao;
import jp.co.nec.aim.mm.exception.AimRuntimeException;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class ScriptManagerTest {
	@PersistenceContext(unitName = "aim-db")
	private EntityManager em;
	private ScriptManager manager = ScriptManager.getInstance();
	private ServiceLayoutDao layOutDao;

	@Before
	public void setUp() {
		layOutDao = new ServiceLayoutDao(em);
		String xmlReg = layOutDao.findScriptXmlByName("REGISTRATION");
		manager.addScriptXml(ScriptFunction.REGISTRATION, xmlReg);
		String delReg = layOutDao.findScriptXmlByName("DELETION");
		manager.addScriptXml(ScriptFunction.DELETION, delReg);

		String delLI = layOutDao.findScriptXmlByName("LI");
		manager.addScriptXml(ScriptFunction.LI, delLI);
		// String delLIS = layOutDao.findScriptXmlByName("LIS");
		// manager.addScriptXml(ScriptFunction.LIS, delLIS);
		String delLLI = layOutDao.findScriptXmlByName("LLI");
		manager.addScriptXml(ScriptFunction.LLI, delLLI);
		// String delLLIS = layOutDao.findScriptXmlByName("LLIS");
		// manager.addScriptXml(ScriptFunction.LLIS, delLLIS);
		String delTLI = layOutDao.findScriptXmlByName("TLI");
		manager.addScriptXml(ScriptFunction.TLI, delTLI);
		// String delTLIS = layOutDao.findScriptXmlByName("TLIS");
		// manager.addScriptXml(ScriptFunction.TLIS, delTLIS);
		String delLIP = layOutDao.findScriptXmlByName("LIP");
		manager.addScriptXml(ScriptFunction.LIP, delLIP);
		String delTLIP = layOutDao.findScriptXmlByName("TLIP");
		manager.addScriptXml(ScriptFunction.TLIP, delTLIP);
		String delLLIP = layOutDao.findScriptXmlByName("LLIP");
		manager.addScriptXml(ScriptFunction.LLIP, delLLIP);
		String delTIM = layOutDao.findScriptXmlByName("TIM");
		manager.addScriptXml(ScriptFunction.TIM, delTIM);
		String delLIM = layOutDao.findScriptXmlByName("LIM");
		manager.addScriptXml(ScriptFunction.LIM, delLIM);
		String delFI = layOutDao.findScriptXmlByName("FI");
		manager.addScriptXml(ScriptFunction.FI, delFI);
		String delTLIM = layOutDao.findScriptXmlByName("TLIM");
		manager.addScriptXml(ScriptFunction.TLIM, delTLIM);
		String delLLIX = layOutDao.findScriptXmlByName("LLIX");
		manager.addScriptXml(ScriptFunction.LLIX, delLLIX);
		String delTLIX = layOutDao.findScriptXmlByName("TLIX");
		manager.addScriptXml(ScriptFunction.TLIX, delTLIX);
		String delLIX = layOutDao.findScriptXmlByName("LIX");
		manager.addScriptXml(ScriptFunction.LIX, delLIX);
		String delLLIM = layOutDao.findScriptXmlByName("LLIM");
		manager.addScriptXml(ScriptFunction.LLIM, delLLIM);
		String delII = layOutDao.findScriptXmlByName("II");
		manager.addScriptXml(ScriptFunction.II, delII);

	}

	@After
	public void tearDown() {

	}

	@Test
	public void testIsExistFunction_FunctionIsNull() {
		try {
			manager.isExistFunction(null);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertEquals("argument function is null..", e.getMessage());
			return;
		}
		fail();

	}

	@Test
	public void testIsExistFunction() {
		Assert.assertTrue(manager.isExistFunction(ScriptFunction.DELETION));
	}

	@Test
	public void testAddScriptXml_FunctionIsNull() {

		try {
			manager.addScriptXml(null, "111");
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertEquals("argument function is null..", e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void testAddScriptXml_xmlNull() {

		try {
			manager.addScriptXml(ScriptFunction.DELETION, null);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertEquals(
					"function DELETION layout script XML is empty.",
					e.getMessage());
			return;
		}
		fail();
	}

	/*
	 * @Test public void testAddScriptXml_xmlWrong() {
	 * 
	 * try { manager.addScriptXml(ScriptFunction.REGISTRATION, "123"); } catch
	 * (Exception e) { // TODO: handle exception
	 * Assert.assertEquals("function DELETION layout script XML is empty",
	 * e.getMessage()); return; } fail(); }
	 */

	@Test
	public void testFindDelContainerIdsAndDelpayloadisnull() {
		Set<Integer> ids = manager.findDelContainerIds(null);

		int[] expect = new int[] { 1, 2, 3, 4, 5, 321, 322, 323, 324, 326, 331,
				332, 333, 334, 335, 336, 341, 342, 343 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndDelpayloadHasKey() {
		PBSyncDeletePayload delPayload = PBSyncDeletePayload
				.newBuilder()
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_RDBT)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setFingerPrintType(
														FingerPrintType.FINGER_PRINT_ROLLED)))
				.build();
		Set<Integer> ids = manager.findDelContainerIds(delPayload);

		int[] expect = new int[] { 1 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndDelpayloadHasKey_NoContainerIdsFound() {
		PBSyncDeletePayload delPayload = PBSyncDeletePayload
				.newBuilder()
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_II)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setFingerPrintType(
														FingerPrintType.FINGER_PRINT_ROLLED)))
				.build();
		Set<Integer> ids = manager.findDelContainerIds(delPayload);
		int[] expect = new int[] { 1, 2, 3, 4, 5, 321, 322, 323, 324, 326, 331,
				332, 333, 334, 335, 336, 341, 342, 343 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}
	}

	@Test
	public void testFindDelContainerIdsAndDelpayloadHasKey_NoIndex() {
		PBSyncDeletePayload delPayload = PBSyncDeletePayload
				.newBuilder()
				.addKeyedTemplate(
						PBKeyedTemplate.newBuilder().setKey(
								TemplateFormatType.TEMPLATE_II)).build();
		Set<Integer> ids = manager.findDelContainerIds(delPayload);
		int[] expect = new int[] { 1, 2, 3, 4, 5, 321, 322, 323, 324, 326, 331,
				332, 333, 334, 335, 336, 341, 342, 343 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}
	}

	// TEMPLATE_RDBT
	@Test
	public void testFindDelContainerIdsAndKeyTemplateisTEMPLATE_RDBT() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate.newBuilder().setKey(
								TemplateFormatType.TEMPLATE_RDBT)).build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(2, ids.size());
		int[] expect = new int[] { 1, 2 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndKeyTemplateisTEMPLATE_RDBTAndFingerPrintTypeisFINGER_PRINT_ROLLED() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_RDBT)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setFingerPrintType(
														FingerPrintType.FINGER_PRINT_ROLLED)))
				.build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);

		int[] expect = new int[] { 1 };
		Assert.assertEquals(ids.size(), 1);
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_RDBTAndFINGER_PRINT_SLAP() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_RDBT)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setFingerPrintType(
														FingerPrintType.FINGER_PRINT_SLAP)))
				.build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);

		int[] expect = new int[] { 2 };
		int index = 0;
		for (Integer id : ids) {
			System.out.print(id.intValue());
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	// TEMPLATE_RDBTM
	@Test
	public void testFindDelContainerIdsAndKeyTemplateisTEMPLATE_RDBTM() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate.newBuilder().setKey(
								TemplateFormatType.TEMPLATE_RDBTM)).build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(2, ids.size());
		int[] expect = new int[] { 331, 332 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_RDBTMAndFINGER_PRINT_SLAP() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_RDBTM)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setFingerPrintType(
														FingerPrintType.FINGER_PRINT_SLAP)))
				.build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);

		int[] expect = new int[] { 332 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_RDBTMAndFINGER_PRINT_ROLLED() {
		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_RDBTM)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setFingerPrintType(
														FingerPrintType.FINGER_PRINT_ROLLED)))
				.build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);

		int[] expect = new int[] { 331 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	// TEMPLATE_RDBL
	@Test
	public void testFindDelContainerIdsAndTEMPLATE_RDBL() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate.newBuilder().setKey(
								TemplateFormatType.TEMPLATE_RDBL)).build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(2, ids.size());
		int[] expect = new int[] { 3, 4 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	/*
	 * @Test public void
	 * testFindDelContainerIdsAndTEMPLATE_RDBLAndFINGER_PRINT_SLAP() {
	 * 
	 * PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload .newBuilder()
	 * .addScopes(1) .addKeyedTemplate( PBKeyedTemplate .newBuilder()
	 * .setKey(TemplateFormatType.TEMPLATE_RDBL) .setIndexer(
	 * PBKeyedTemplateIndexer .newBuilder() .setFingerPrintType(
	 * FingerPrintType.FINGER_PRINT_SLAP))) .build(); Set<Integer> ids =
	 * manager.findDelContainerIds(syncDeletePayload); Assert.assertEquals(1,
	 * ids.size()); int[] expect = new int[] { 3 }; int index = 0; for (Integer
	 * id : ids) { Assert.assertEquals(expect[index++], id.intValue()); }
	 * 
	 * }
	 */
	/*
	 * @Test public void
	 * testFindDelContainerIdsAndTEMPLATE_RDBLAndFINGER_PRINT_ROLLED() {
	 * PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload .newBuilder()
	 * .addScopes(1) .addKeyedTemplate( PBKeyedTemplate .newBuilder()
	 * .setKey(TemplateFormatType.TEMPLATE_RDBL) .setIndexer(
	 * PBKeyedTemplateIndexer .newBuilder() .setFingerPrintType(
	 * FingerPrintType.FINGER_PRINT_ROLLED))) .build(); Set<Integer> ids =
	 * manager.findDelContainerIds(syncDeletePayload); Assert.assertEquals(1,
	 * ids.size()); int[] expect = new int[] { 2 }; int index = 0; for (Integer
	 * id : ids) { Assert.assertEquals(expect[index++], id.intValue()); }
	 * 
	 * }
	 */
	@Test
	public void testFindDelContainerIdsAndTEMPLATE_RDBLAndFINGER_PRINT_ROLLED() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addScopes(50)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_RDBL)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setFingerPrintType(
														FingerPrintType.FINGER_PRINT_ROLLED)))
				.build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(2, ids.size());
		int[] expect = new int[] { 3, 49003 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_RDBLAndFINGER_PRINT_SLAP() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addScopes(50)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_RDBL)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setFingerPrintType(
														FingerPrintType.FINGER_PRINT_SLAP)))
				.build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(2, ids.size());
		int[] expect = new int[] { 4, 49004 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	// TEMPLATE_RDBLS
	@Test
	public void testFindDelContainerIdsAndKeyTemplateisTEMPLATE_RDBLS() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate.newBuilder().setKey(
								TemplateFormatType.TEMPLATE_RDBLS)).build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(2, ids.size());
		int[] expect = new int[] { 323, 324 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	/*
	 * @Test public void
	 * testFindDelContainerIdsAndKeyTemplateisTEMPLATE_RDBLSAndFINGER_PRINT_ROLLED
	 * () {
	 * 
	 * PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload .newBuilder()
	 * .addScopes(1) .addKeyedTemplate( PBKeyedTemplate .newBuilder()
	 * .setKey(TemplateFormatType.TEMPLATE_RDBLS) .setIndexer(
	 * PBKeyedTemplateIndexer .newBuilder() .setFingerPrintType(
	 * FingerPrintType.FINGER_PRINT_ROLLED))) .build(); Set<Integer> ids =
	 * manager.findDelContainerIds(syncDeletePayload); Assert.assertEquals(1,
	 * ids.size()); int[] expect = new int[] { 323 }; int index = 0; for
	 * (Integer id : ids) { Assert.assertEquals(expect[index++], id.intValue());
	 * }
	 * 
	 * }
	 */

	/*
	 * @Test public void
	 * testFindDelContainerIdsAndKeyTemplateisTEMPLATE_RDBLSAndFINGER_PRINT_SLAP
	 * () {
	 * 
	 * PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload .newBuilder()
	 * .addScopes(1) .addKeyedTemplate( PBKeyedTemplate .newBuilder()
	 * .setKey(TemplateFormatType.TEMPLATE_RDBLS) .setIndexer(
	 * PBKeyedTemplateIndexer .newBuilder() .setFingerPrintType(
	 * FingerPrintType.FINGER_PRINT_SLAP))) .build(); Set<Integer> ids =
	 * manager.findDelContainerIds(syncDeletePayload); Assert.assertEquals(1,
	 * ids.size()); int[] expect = new int[] { 324 }; int index = 0; for
	 * (Integer id : ids) { Assert.assertEquals(expect[index++], id.intValue());
	 * }
	 * 
	 * }
	 */
	@Test
	public void testFindDelContainerIdsAndTEMPLATE_RDBLSAndFINGER_PRINT_SLAP() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_RDBLS)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setFingerPrintType(
														FingerPrintType.FINGER_PRINT_SLAP)))
				.build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 324 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_RDBLSAndFINGER_PRINT_ROLLED() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_RDBLS)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setFingerPrintType(
														FingerPrintType.FINGER_PRINT_ROLLED)))
				.build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 323 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	// TEMPLATE_RDBLM
	@Test
	public void testFindDelContainerIdsAndKeyTemplateisTEMPLATE_RDBLM() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate.newBuilder().setKey(
								TemplateFormatType.TEMPLATE_RDBLM)).build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(2, ids.size());
		int[] expect = new int[] { 333, 334 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_RDBLMAndFINGER_PRINT_ROLLED() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_RDBLM)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setFingerPrintType(
														FingerPrintType.FINGER_PRINT_ROLLED)))
				.build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 333 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_RDBLMAndFINGER_PRINT_SLAP() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_RDBLM)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setFingerPrintType(
														FingerPrintType.FINGER_PRINT_SLAP)))
				.build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 334 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	// TEMPLATE_RDBLX
	@Test
	public void testFindDelContainerIdsAndKeyTemplateisTEMPLATE_RDBLX() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate.newBuilder().setKey(
								TemplateFormatType.TEMPLATE_RDBLX)).build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 341 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	// TEMPLATE_PDB
	@Test
	public void testFindDelContainerIdsAndKeyTemplateisTEMPLATE_PDB() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate.newBuilder().setKey(
								TemplateFormatType.TEMPLATE_PDB)).build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}
	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_RIGHT_FULL() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_PDB)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setPosition(
														ImagePositionType.IMAGE_PALM_RIGHT_FULL)))
				.build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_RIGHT_WRITER() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_PDB)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setPosition(
														ImagePositionType.IMAGE_PALM_RIGHT_WRITER)))
				.build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_LEFT_FULL() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_PDB)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setPosition(
														ImagePositionType.IMAGE_PALM_LEFT_FULL)))
				.build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_LEFT_WRITER() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_PDB)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setPosition(
														ImagePositionType.IMAGE_PALM_LEFT_WRITER)))
				.build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_RIGHT_LOWER() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_PDB)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setPosition(
														ImagePositionType.IMAGE_PALM_RIGHT_LOWER)))
				.build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_RIGHT_UPPER() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_PDB)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setPosition(
														ImagePositionType.IMAGE_PALM_RIGHT_UPPER)))
				.build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_LEFT_LOWER() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_PDB)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setPosition(
														ImagePositionType.IMAGE_PALM_LEFT_LOWER)))
				.build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_LEFT_UPPER() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_PDB)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setPosition(
														ImagePositionType.IMAGE_PALM_LEFT_UPPER)))
				.build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_RIGHT_OTHER() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_PDB)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setPosition(
														ImagePositionType.IMAGE_PALM_RIGHT_OTHER)))
				.build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_LEFT_OTHER() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_PDB)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setPosition(
														ImagePositionType.IMAGE_PALM_LEFT_OTHER)))
				.build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_RIGHT_INTERDIGITAL() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_PDB)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setPosition(
														ImagePositionType.IMAGE_PALM_RIGHT_INTERDIGITAL)))
				.build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_RIGHT_THENAR() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_PDB)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setPosition(
														ImagePositionType.IMAGE_PALM_RIGHT_THENAR)))
				.build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_RIGHT_HYPOTHENAR() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_PDB)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setPosition(
														ImagePositionType.IMAGE_PALM_RIGHT_HYPOTHENAR)))
				.build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_LEFT_INTERDEGITAL() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_PDB)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setPosition(
														ImagePositionType.IMAGE_PALM_LEFT_INTERDIGITAL)))
				.build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_LEFT_THENAR() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_PDB)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setPosition(
														ImagePositionType.IMAGE_PALM_LEFT_THENAR)))
				.build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_LEFT_HYPOTHENAR() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_PDB)
								.setIndexer(
										PBKeyedTemplateIndexer
												.newBuilder()
												.setPosition(
														ImagePositionType.IMAGE_PALM_LEFT_HYPOTHENAR)))
				.build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	// TEMPLATE_FDB
	@Test
	public void testFindDelContainerIdsAndKeyTemplateisTEMPLATE_FDB() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate.newBuilder().setKey(
								TemplateFormatType.TEMPLATE_FDB)).build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 335 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}
	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_FDBAnd1() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_FDB)
								.setIndexer(
										PBKeyedTemplateIndexer.newBuilder()
												.setIndex(1))).build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 335 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_FDBAnd2() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_FDB)
								.setIndexer(
										PBKeyedTemplateIndexer.newBuilder()
												.setIndex(2))).build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 335 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_FDBAnd3() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_FDB)
								.setIndexer(
										PBKeyedTemplateIndexer.newBuilder()
												.setIndex(3))).build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 335 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_FDBAnd4() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_FDB)
								.setIndexer(
										PBKeyedTemplateIndexer.newBuilder()
												.setIndex(4))).build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 335 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_FDBAnd5() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_FDB)
								.setIndexer(
										PBKeyedTemplateIndexer.newBuilder()
												.setIndex(5))).build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 335 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_FDBAnd6() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_FDB)
								.setIndexer(
										PBKeyedTemplateIndexer.newBuilder()
												.setIndex(6))).build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 335 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_FDBAnd7() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_FDB)
								.setIndexer(
										PBKeyedTemplateIndexer.newBuilder()
												.setIndex(7))).build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 335 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_FDBAnd8() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_FDB)
								.setIndexer(
										PBKeyedTemplateIndexer.newBuilder()
												.setIndex(8))).build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 335 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_FDBAnd9() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_FDB)
								.setIndexer(
										PBKeyedTemplateIndexer.newBuilder()
												.setIndex(9))).build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 335 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndTEMPLATE_FDBAnd10() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate
								.newBuilder()
								.setKey(TemplateFormatType.TEMPLATE_FDB)
								.setIndexer(
										PBKeyedTemplateIndexer.newBuilder()
												.setIndex(10))).build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 335 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndKeyTemplateisTEMPLATE_IDB() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate.newBuilder().setKey(
								TemplateFormatType.TEMPLATE_IDB)).build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 343 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndKeyTemplateisTEMPLATE_LDB() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate.newBuilder().setKey(
								TemplateFormatType.TEMPLATE_LDB)).build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 321 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndKeyTemplateisTEMPLATE_PLDB() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate.newBuilder().setKey(
								TemplateFormatType.TEMPLATE_PLDB)).build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 322 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndKeyTemplateisTEMPLATE_LDBS() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate.newBuilder().setKey(
								TemplateFormatType.TEMPLATE_LDBS)).build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 326 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndKeyTemplateisTEMPLATE_LDBM() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate.newBuilder().setKey(
								TemplateFormatType.TEMPLATE_LDBM)).build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 336 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindDelContainerIdsAndKeyTemplateisTEMPLATE_LDBX() {

		PBSyncDeletePayload syncDeletePayload = PBSyncDeletePayload
				.newBuilder()
				.addScopes(1)
				.addKeyedTemplate(
						PBKeyedTemplate.newBuilder().setKey(
								TemplateFormatType.TEMPLATE_LDBX)).build();
		Set<Integer> ids = manager.findDelContainerIds(syncDeletePayload);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 342 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	/*
	 * @Test public void
	 * testFindResultByKeyTEMPLATE_RDBTAndFINGER_PRINT_ROLLEDAndINQUIRY() {
	 * TemplateFormatType formatType = TemplateFormatType.TEMPLATE_RDBT;
	 * FingerPrintType printType = FingerPrintType.FINGER_PRINT_ROLLED; //
	 * ImagePositionType position = null; ScriptType type = ScriptType.INQUIRY;
	 * ScriptKey key = new ScriptKey(formatType.toString(),
	 * printType.toString(), null); ScriptValue value =
	 * manager.findResultByKey(key, type); Assert.assertEquals(1,
	 * value.getContainerId().size()); }
	 */
	@Test
	public void findInqContainerIds() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_TI).build();

		PBInquiryScopeOptions scopeOptions = PBInquiryScopeOptions.newBuilder()
				.addScope(1).addScope(4)
				.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_ROLLED)
				.build();
		try {
			manager.findInqContainerIds(InquiryFunctionType.TI, kTemplate,
					scopeOptions);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof AimRuntimeException);
			Assert.assertEquals(
					"Can not find inquiry container id with functionName:TI, formatType:TEMPLATE_TI, Search side printType:null,File side printType:FINGER_PRINT_ROLLED..",
					e.getMessage());
			return;
		}
		fail();

	}

	@Test
	public void findInqContainerIds_ScopesNull() {
		manager.clear();
		String delTI = layOutDao.findScriptXmlByName("TI");
		manager.addScriptXml(ScriptFunction.TI, delTI);
		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_TI).build();

		try {
			manager.findInqContainerIds(InquiryFunctionType.TI, kTemplate, null);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertEquals(
					"Can not find inquiry container id with functionName:TI, formatType:TEMPLATE_TI, Search side printType:null,File side printType:null..",
					e.getMessage());
		}

	}

	@Test
	public void testFindInqContainerIdsTEMPLATE_TIAndFINGER_PRINT_ROLLED() {
		String delTI = layOutDao.findScriptXmlByName("TI");
		manager.addScriptXml(ScriptFunction.TI, delTI);
		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_TI)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setFingerPrintType(
								FingerPrintType.FINGER_PRINT_ROLLED)).build();

		PBInquiryScopeOptions scopeOptions = PBInquiryScopeOptions.newBuilder()
				.addScope(1).addScope(4)
				.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_ROLLED)
				.build();
		ScriptValue value = manager.findInqContainerIds(InquiryFunctionType.TI,
				kTemplate, scopeOptions);
		Set<Integer> set = value.getContainerIds();
		List<PBInquiryFusionWeight> fusionWeights = value.getFusionWeights();
		Assert.assertEquals(1, fusionWeights.size());
		PBInquiryFusionWeight fusionWeight = fusionWeights.get(0);
		Assert.assertEquals(100, fusionWeight.getWeight());
		Assert.assertEquals(FingerSetType.PC2_ROLLED,
				fusionWeight.getInquirySet());
		Assert.assertEquals(2, set.size());
		int[] expect = new int[] { 1, 3001 };
		int index = 0;
		for (Integer id : set) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindInqContainerIdsTEMPLATE_TIAndFINGER_PRINT_SLAP() {
		String delTI = layOutDao.findScriptXmlByName("TI");
		manager.addScriptXml(ScriptFunction.TI, delTI);
		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_TI)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setFingerPrintType(
								FingerPrintType.FINGER_PRINT_SLAP)).build();
		// ImagePositionType position = null;

		PBInquiryScopeOptions scopeOptions = PBInquiryScopeOptions.newBuilder()
				.addScope(1)
				.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_SLAP)
				.build();
		ScriptValue value = manager.findInqContainerIds(InquiryFunctionType.TI,
				kTemplate, scopeOptions);
		Set<Integer> set = value.getContainerIds();
		Assert.assertEquals(1, set.size());

		List<PBInquiryFusionWeight> fusionWeights = value.getFusionWeights();
		Assert.assertEquals(1, fusionWeights.size());
		PBInquiryFusionWeight fusionWeight = fusionWeights.get(0);
		Assert.assertEquals(100, fusionWeight.getWeight());
		Assert.assertEquals(FingerSetType.PC2_SLAP,
				fusionWeight.getInquirySet());

		int[] expect = new int[] { 2 };
		int index = 0;
		for (Integer id : set) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindInqContainerIdsTEMPLATE_TIMAndFINGER_PRINT_ROLLED() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_TIM)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setFingerPrintType(
								FingerPrintType.FINGER_PRINT_ROLLED)).build();
		// ImagePositionType position = null;

		PBInquiryScopeOptions scopeOptions = PBInquiryScopeOptions.newBuilder()
				.addScope(1)
				.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_ROLLED)
				.build();
		ScriptValue value = manager.findInqContainerIds(
				InquiryFunctionType.TIM, kTemplate, scopeOptions);
		Set<Integer> set = value.getContainerIds();
		List<PBInquiryFusionWeight> fusionWeights = value.getFusionWeights();
		Assert.assertEquals(1, fusionWeights.size());
		PBInquiryFusionWeight fusionWeight = fusionWeights.get(0);
		Assert.assertEquals(100, fusionWeight.getWeight());
		Assert.assertEquals(FingerSetType.PC2_ROLLED,
				fusionWeight.getInquirySet());
		Assert.assertEquals(1, set.size());
		int[] expect = new int[] { 331 };
		int index = 0;
		for (Integer id : set) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindInqContainerIdsTEMPLATE_TIMAndFINGER_PRINT_SLAP() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_TIM)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setFingerPrintType(
								FingerPrintType.FINGER_PRINT_SLAP)).build();
		// ImagePositionType position = null;

		PBInquiryScopeOptions scopeOptions = PBInquiryScopeOptions.newBuilder()
				.addScope(1)
				.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_SLAP)
				.build();
		ScriptValue value = manager.findInqContainerIds(
				InquiryFunctionType.TIM, kTemplate, scopeOptions);
		Set<Integer> set = value.getContainerIds();
		Assert.assertEquals(1, set.size());

		List<PBInquiryFusionWeight> fusionWeights = value.getFusionWeights();
		Assert.assertEquals(1, fusionWeights.size());
		PBInquiryFusionWeight fusionWeight = fusionWeights.get(0);
		Assert.assertEquals(100, fusionWeight.getWeight());
		Assert.assertEquals(FingerSetType.PC2_SLAP,
				fusionWeight.getInquirySet());

		int[] expect = new int[] { 332 };
		int index = 0;
		for (Integer id : set) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindInqContainerIdsTEMPLATE_TLIAndFINGER_PRINT_ROLLED() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_TLI)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setFingerPrintType(
								FingerPrintType.FINGER_PRINT_ROLLED)).build();
		// ImagePositionType position = null;

		PBInquiryScopeOptions scopeOptions = PBInquiryScopeOptions.newBuilder()
				.addScope(1).build();
		ScriptValue value = manager.findInqContainerIds(
				InquiryFunctionType.TLI, kTemplate, scopeOptions);
		Set<Integer> set = value.getContainerIds();
		List<PBInquiryFusionWeight> fusionWeights = value.getFusionWeights();
		Assert.assertEquals(1, fusionWeights.size());
		PBInquiryFusionWeight fusionWeight = fusionWeights.get(0);
		Assert.assertEquals(100, fusionWeight.getWeight());
		Assert.assertEquals(FingerSetType.FMP5_ROLLED,
				fusionWeight.getInquirySet());
		Assert.assertEquals(1, set.size());
		int[] expect = new int[] { 321 };
		int index = 0;
		for (Integer id : set) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindInqContainerIdsTEMPLATE_TLIAndFINGER_PRINT_SLAP() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_TLI)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setFingerPrintType(
								FingerPrintType.FINGER_PRINT_SLAP)).build();
		// ImagePositionType position = null;

		PBInquiryScopeOptions scopeOptions = PBInquiryScopeOptions.newBuilder()
				.addScope(1).build();
		ScriptValue value = manager.findInqContainerIds(
				InquiryFunctionType.TLI, kTemplate, scopeOptions);
		Set<Integer> set = value.getContainerIds();
		Assert.assertEquals(1, set.size());

		List<PBInquiryFusionWeight> fusionWeights = value.getFusionWeights();
		Assert.assertEquals(1, fusionWeights.size());
		PBInquiryFusionWeight fusionWeight = fusionWeights.get(0);
		Assert.assertEquals(100, fusionWeight.getWeight());
		Assert.assertEquals(FingerSetType.FMP5_SLAP,
				fusionWeight.getInquirySet());

		int[] expect = new int[] { 321 };
		int index = 0;
		for (Integer id : set) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindInqContainerIdsTEMPLATE_TLIMAndFINGER_PRINT_ROLLED() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_TLIM)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setFingerPrintType(
								FingerPrintType.FINGER_PRINT_ROLLED)).build();
		PBInquiryScopeOptions scopeOptions = PBInquiryScopeOptions.newBuilder()
				.addScope(1)
				// .addTargetFingerPrint(FingerPrintType.FINGER_PRINT_ROLLED)
				.build();
		ScriptValue value = manager.findInqContainerIds(
				InquiryFunctionType.TLIM, kTemplate, scopeOptions);
		Set<Integer> set = value.getContainerIds();
		List<PBInquiryFusionWeight> fusionWeights = value.getFusionWeights();
		Assert.assertEquals(1, fusionWeights.size());
		PBInquiryFusionWeight fusionWeight = fusionWeights.get(0);
		Assert.assertEquals(100, fusionWeight.getWeight());
		Assert.assertEquals(FingerSetType.PC2_ROLLED,
				fusionWeight.getInquirySet());
		Assert.assertEquals(1, set.size());
		int[] expect = new int[] { 336 };
		int index = 0;
		for (Integer id : set) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindInqContainerIdsTEMPLATE_TLIMAndFINGER_PRINT_SLAP() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_TLIM)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setFingerPrintType(
								FingerPrintType.FINGER_PRINT_SLAP)).build();
		// ImagePositionType position = null;

		PBInquiryScopeOptions scopeOptions = PBInquiryScopeOptions.newBuilder()
				.addScope(1).build();
		ScriptValue value = manager.findInqContainerIds(
				InquiryFunctionType.TLIM, kTemplate, scopeOptions);
		Set<Integer> set = value.getContainerIds();
		Assert.assertEquals(1, set.size());

		List<PBInquiryFusionWeight> fusionWeights = value.getFusionWeights();
		Assert.assertEquals(1, fusionWeights.size());
		PBInquiryFusionWeight fusionWeight = fusionWeights.get(0);
		Assert.assertEquals(100, fusionWeight.getWeight());
		Assert.assertEquals(FingerSetType.PC2_SLAP,
				fusionWeight.getInquirySet());

		int[] expect = new int[] { 336 };
		int index = 0;
		for (Integer id : set) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindInqContainerIdsTEMPLATE_TLIX() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_TLIX).build();

		PBInquiryScopeOptions scopeOptions = PBInquiryScopeOptions.newBuilder()
				.addScope(1).build();
		ScriptValue value = manager.findInqContainerIds(
				InquiryFunctionType.TLIX, kTemplate, scopeOptions);
		Set<Integer> set = value.getContainerIds();
		Assert.assertEquals(1, set.size());

		List<PBInquiryFusionWeight> fusionWeights = value.getFusionWeights();
		Assert.assertEquals(4, fusionWeights.size());
		Integer[] weights = { 200, 200, 100, 100 };
		FingerSetType[] types = { FingerSetType.PC2_ROLLED,
				FingerSetType.PC2_SLAP, FingerSetType.FMP5_ROLLED,
				FingerSetType.FMP5_SLAP };
		int index1 = 0;
		int index2 = 0;
		for (PBInquiryFusionWeight fusionWeight : fusionWeights) {
			Assert.assertEquals(weights[index1++].intValue(),
					fusionWeight.getWeight());
			Assert.assertEquals(types[index2++], fusionWeight.getInquirySet());
		}

		int[] expect = new int[] { 342 };
		int index = 0;
		for (Integer id : set) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindInqContainerIdsTEMPLATE_TLIXFusionWeightChanged() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_TLIX).build();

		PBInquiryScopeOptions scopeOptions = PBInquiryScopeOptions.newBuilder()
				.addScope(1).build();
		ScriptValue value = manager.findInqContainerIds(
				InquiryFunctionType.TLIX, kTemplate, scopeOptions);
		Set<Integer> set = value.getContainerIds();
		Assert.assertEquals(1, set.size());

		List<PBInquiryFusionWeight> fusionWeights = value.getFusionWeights();
		Assert.assertEquals(4, fusionWeights.size());
		Integer[] weights = { 200, 200, 100, 100 };
		FingerSetType[] types = { FingerSetType.PC2_ROLLED,
				FingerSetType.PC2_SLAP, FingerSetType.FMP5_ROLLED,
				FingerSetType.FMP5_SLAP };
		int index1 = 0;
		int index2 = 0;
		for (PBInquiryFusionWeight fusionWeight : fusionWeights) {
			Assert.assertEquals(weights[index1++].intValue(),
					fusionWeight.getWeight());
			Assert.assertEquals(types[index2++], fusionWeight.getInquirySet());
		}

		int[] expect = new int[] { 342 };
		int index = 0;
		for (Integer id : set) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindInqContainerIdsTEMPLATE_LI() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_LI).build();
		// ImagePositionType position = null;

		PBInquiryScopeOptions scopeOptions = PBInquiryScopeOptions.newBuilder()
				.addScope(1)
				.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_ROLLED)
				.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_SLAP)
				.build();
		ScriptValue value = manager.findInqContainerIds(InquiryFunctionType.LI,
				kTemplate, scopeOptions);
		Set<Integer> set = value.getContainerIds();
		Assert.assertEquals(2, set.size());

		List<PBInquiryFusionWeight> fusionWeights = value.getFusionWeights();
		Assert.assertEquals(1, fusionWeights.size());
		PBInquiryFusionWeight fusionWeight = fusionWeights.get(0);
		Assert.assertEquals(100, fusionWeight.getWeight());
		Assert.assertEquals(FingerSetType.FMP5_LATENT,
				fusionWeight.getInquirySet());

		int[] expect = new int[] { 3, 4 };
		int index = 0;
		for (Integer id : set) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	/*
	 * @Test public void testFindInqContainerIdsTEMPLATE_LIS() { PBKeyedTemplate
	 * kTemplate = PBKeyedTemplate.newBuilder()
	 * .setKey(TemplateFormatType.TEMPLATE_LIS).build(); // ImagePositionType
	 * position = null;
	 * 
	 * PBInquiryScopeOptions scopeOptions = PBInquiryScopeOptions.newBuilder()
	 * .addScope(1).build(); ScriptValue value = manager.findInqContainerIds(
	 * InquiryFunctionType.LIS, kTemplate, scopeOptions); Set<Integer> set =
	 * value.getContainerIds(); Assert.assertEquals(2, set.size());
	 * 
	 * List<PBInquiryFusionWeight> fusionWeights = value.getFusionWeights();
	 * Assert.assertEquals(1, fusionWeights.size()); PBInquiryFusionWeight
	 * fusionWeight = fusionWeights.get(0); Assert.assertEquals(200,
	 * fusionWeight.getWeight()); Assert.assertEquals(FingerSetType.PC2_LATENT,
	 * fusionWeight.getInquirySet());
	 * 
	 * int[] expect = new int[] { 323, 324 }; int index = 0; for (Integer id :
	 * set) { Assert.assertEquals(expect[index++], id.intValue()); }
	 * 
	 * }
	 */
	@Test
	public void testFindInqContainerIdsTEMPLATE_LIM() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_LIM).build();

		PBInquiryScopeOptions scopeOptions = PBInquiryScopeOptions.newBuilder()
				.addScope(1)
				.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_ROLLED)
				.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_SLAP)
				.build();
		ScriptValue value = manager.findInqContainerIds(
				InquiryFunctionType.LIM, kTemplate, scopeOptions);
		Set<Integer> set = value.getContainerIds();
		Assert.assertEquals(2, set.size());

		int[] expect = new int[] { 333, 334 };
		int index = 0;
		for (Integer id : set) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindInqContainerIdsTEMPLATE_LIX() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_LIX).build();

		PBInquiryScopeOptions scopeOptions = PBInquiryScopeOptions.newBuilder()
				.addScope(1).build();
		ScriptValue value = manager.findInqContainerIds(
				InquiryFunctionType.LIX, kTemplate, scopeOptions);
		Set<Integer> set = value.getContainerIds();
		Assert.assertEquals(1, set.size());

		List<PBInquiryFusionWeight> fusionWeights = value.getFusionWeights();
		Assert.assertEquals(4, fusionWeights.size());
		Integer[] weights = { 200, 200, 100, 100 };
		FingerSetType[] types = { FingerSetType.PC2_ROLLED,
				FingerSetType.PC2_SLAP, FingerSetType.FMP5_ROLLED,
				FingerSetType.FMP5_SLAP };
		int index1 = 0;
		int index2 = 0;
		for (PBInquiryFusionWeight fusionWeight : fusionWeights) {
			Assert.assertEquals(weights[index1++].intValue(),
					fusionWeight.getWeight());
			Assert.assertEquals(types[index2++], fusionWeight.getInquirySet());
		}

		int[] expect = new int[] { 341 };
		int index = 0;
		for (Integer id : set) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindInqContainerIdsTEMPLATE_LLI() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_LLI).build();
		// ImagePositionType position = null;

		PBInquiryScopeOptions scopeOptions = PBInquiryScopeOptions.newBuilder()
				.addScope(1).build();
		ScriptValue value = manager.findInqContainerIds(
				InquiryFunctionType.LLI, kTemplate, scopeOptions);
		Set<Integer> set = value.getContainerIds();
		List<PBInquiryFusionWeight> fusionWeights = value.getFusionWeights();
		Assert.assertEquals(1, fusionWeights.size());
		PBInquiryFusionWeight fusionWeight = fusionWeights.get(0);
		Assert.assertEquals(100, fusionWeight.getWeight());
		Assert.assertEquals(FingerSetType.FMP5_LATENT,
				fusionWeight.getInquirySet());
		Assert.assertEquals(1, set.size());
		int[] expect = new int[] { 321 };
		int index = 0;
		for (Integer id : set) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindInqContainerIdsTEMPLATE_LLIM() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_LLIM).build();

		PBInquiryScopeOptions scopeOptions = PBInquiryScopeOptions.newBuilder()
				.addScope(1).build();
		ScriptValue value = manager.findInqContainerIds(
				InquiryFunctionType.LLIM, kTemplate, scopeOptions);
		Set<Integer> set = value.getContainerIds();
		Assert.assertEquals(1, set.size());

		int[] expect = new int[] { 336 };
		int index = 0;
		for (Integer id : set) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindInqContainerIdsTEMPLATE_LLIX() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_LLIX).build();

		PBInquiryScopeOptions scopeOptions = PBInquiryScopeOptions.newBuilder()
				.addScope(1).build();
		ScriptValue value = manager.findInqContainerIds(
				InquiryFunctionType.LLIX, kTemplate, scopeOptions);
		Set<Integer> set = value.getContainerIds();
		Assert.assertEquals(1, set.size());

		List<PBInquiryFusionWeight> fusionWeights = value.getFusionWeights();
		Assert.assertEquals(2, fusionWeights.size());
		Integer[] weights = { 100, 100 };
		FingerSetType[] types = { FingerSetType.PC2_LATENT,
				FingerSetType.FMP5_LATENT };
		int index1 = 0;
		int index2 = 0;
		for (PBInquiryFusionWeight fusionWeight : fusionWeights) {
			Assert.assertEquals(weights[index1++].intValue(),
					fusionWeight.getWeight());
			Assert.assertEquals(types[index2++], fusionWeight.getInquirySet());
		}

		int[] expect = new int[] { 342 };
		int index = 0;
		for (Integer id : set) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindInqContainerIdsTEMPLATE_LIP() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_LIP).build();

		PBInquiryScopeOptions scopeOptions = PBInquiryScopeOptions.newBuilder()
				.addScope(1).build();
		ScriptValue value = manager.findInqContainerIds(
				InquiryFunctionType.LIP, kTemplate, scopeOptions);
		Set<Integer> set = value.getContainerIds();
		Assert.assertEquals(1, set.size());

		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : set) {
			Assert.assertEquals(expect[index++], id.intValue());
		}
	}

	@Test
	public void testFindInqContainerIdsTEMPLATE_TLIP() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_TLIP).build();

		PBInquiryScopeOptions scopeOptions = PBInquiryScopeOptions.newBuilder()
				.addScope(1).build();
		ScriptValue value = manager.findInqContainerIds(
				InquiryFunctionType.TLIP, kTemplate, scopeOptions);
		Set<Integer> set = value.getContainerIds();
		Assert.assertEquals(1, set.size());

		int[] expect = new int[] { 322 };
		int index = 0;
		for (Integer id : set) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindInqContainerIdsTEMPLATE_LLIP() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_LLIP).build();

		PBInquiryScopeOptions scopeOptions = PBInquiryScopeOptions.newBuilder()
				.addScope(1).build();
		ScriptValue value = manager.findInqContainerIds(
				InquiryFunctionType.LLIP, kTemplate, scopeOptions);
		Set<Integer> set = value.getContainerIds();
		Assert.assertEquals(1, set.size());

		int[] expect = new int[] { 322 };
		int index = 0;
		for (Integer id : set) {
			Assert.assertEquals(expect[index++], id.intValue());
		}
	}

	@Test
	public void testFindInqContainerIdsTEMPLATE_FI() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_FI).build();

		PBInquiryScopeOptions scopeOptions = PBInquiryScopeOptions.newBuilder()
				.addScope(1).build();
		ScriptValue value = manager.findInqContainerIds(InquiryFunctionType.FI,
				kTemplate, scopeOptions);
		Set<Integer> set = value.getContainerIds();
		Assert.assertEquals(1, set.size());

		int[] expect = new int[] { 335 };
		int index = 0;
		for (Integer id : set) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindInqContainerIdsTEMPLATE_II() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_II).build();

		PBInquiryScopeOptions scopeOptions = PBInquiryScopeOptions.newBuilder()
				.addScope(1).build();// .addTargetFingerPrint(FingerPrintType.FINGER_PRINT_ROLLED)
		ScriptValue value = manager.findInqContainerIds(InquiryFunctionType.II,
				kTemplate, scopeOptions);
		Set<Integer> set = value.getContainerIds();
		Assert.assertEquals(1, set.size());

		int[] expect = new int[] { 343 };
		int index = 0;
		for (Integer id : set) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIds_NoContainerIdsFound() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_FDB)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setFingerPrintType(
								FingerPrintType.FINGER_PRINT_ROLLED)).build();
		try {
			manager.findRegContainerIds(kTemplate, 1);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof IllegalArgumentException);
			Assert.assertEquals(
					"Can not find Register container id with formatType:TEMPLATE_FDB, printType:FINGER_PRINT_ROLLED, position:null..",
					e.getMessage());
			return;
		}
		fail();
	}

	@Test
	public void testFindRegContainerIdsTEMPLATE_RDBTAndFINGER_PRINT_ROLLED() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBT)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setFingerPrintType(
								FingerPrintType.FINGER_PRINT_ROLLED)).build();
		Set<Integer> set = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, set.size());
		int[] expect = new int[] { 1 };
		int index = 0;
		for (Integer id : set) {
			Assert.assertEquals(expect[index++], id.intValue());
		}
	}

	@Test
	public void testFindRegContainerIdsTEMPLATE_RDBTAndFINGER_PRINT_SLAP() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBT)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setFingerPrintType(
								FingerPrintType.FINGER_PRINT_SLAP)).build();
		Set<Integer> set = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, set.size());
		int[] expect = new int[] { 2 };
		int index = 0;
		for (Integer id : set) {
			Assert.assertEquals(expect[index++], id.intValue());
		}
	}

	@Test
	public void testFindRegContainerIdsTEMPLATE_RDBTMAndFINGER_PRINT_ROLLED() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBTM)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setFingerPrintType(
								FingerPrintType.FINGER_PRINT_ROLLED)).build();
		Set<Integer> set = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, set.size());
		int[] expect = new int[] { 331 };
		int index = 0;
		for (Integer id : set) {
			Assert.assertEquals(expect[index++], id.intValue());
		}
	}

	@Test
	public void testFindRegContainerIdsTEMPLATE_RDBTMAndFINGER_PRINT_SLAP() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBTM)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setFingerPrintType(
								FingerPrintType.FINGER_PRINT_SLAP)).build();
		Set<Integer> set = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, set.size());
		int[] expect = new int[] { 332 };
		int index = 0;
		for (Integer id : set) {
			Assert.assertEquals(expect[index++], id.intValue());
		}
	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLAndIMAGE_ROLLED_RIGHT_THUMB() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBL)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 3 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLAndIMAGE_ROLLED_RIGHT_INDEX() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBL)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_ROLLED_RIGHT_INDEX))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 3 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLAndIMAGE_ROLLED_RIGHT_MIDDLE() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBL)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_ROLLED_RIGHT_MIDDLE))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 3 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLAndIMAGE_ROLLED_RIGHT_RING() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBL)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_ROLLED_RIGHT_RING))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 3 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLAndIMAGE_ROLLED_RIGHT_LITTLE() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBL)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_ROLLED_RIGHT_LITTLE))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 3 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLAndIMAGE_ROLLED_LEFT_THUMB() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBL)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_ROLLED_LEFT_THUMB))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 3 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLAndIMAGE_ROLLED_LEFT_INDEX() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBL)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_ROLLED_LEFT_INDEX))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 3 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLAndIMAGE_ROLLED_LEFT_MIDDLE() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBL)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_ROLLED_LEFT_MIDDLE))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 3 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLAndIMAGE_ROLLED_LEFT_RING() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBL)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_ROLLED_LEFT_RING))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 3 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLAndIMAGE_ROLLED_LEFT_LITTLE() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBL)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_ROLLED_LEFT_LITTLE))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 3 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLAndIMAGE_SLAP_RIGHT_THUMB() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBL)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_SLAP_RIGHT_THUMB))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 4 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLAndIMAGE_SLAP_RIGHT_INDEX() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBL)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_SLAP_RIGHT_INDEX))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 4 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLAndIMAGE_SLAP_RIGHT_MIDDLE() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBL)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_SLAP_RIGHT_MIDDLE))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 4 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLAndIMAGE_SLAP_RIGHT_RING() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBL)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_SLAP_RIGHT_RING))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 4 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLAndIMAGE_SLAP_RIGHT_LITTLE() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBL)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_SLAP_RIGHT_LITTLE))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 4 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLAndIMAGE_SLAP_LEFT_THUMB() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBL)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_SLAP_LEFT_THUMB))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 4 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLAndIMAGE_SLAP_LEFT_INDEX() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBL)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_SLAP_LEFT_INDEX))
				.build();

		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 4 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLAndIMAGE_SLAP_LEFT_MIDDLE() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBL)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_SLAP_LEFT_MIDDLE))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 4 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLAndIMAGE_SLAP_LEFT_RING() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBL)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_SLAP_LEFT_RING))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 4 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLAndIMAGE_SLAP_LEFT_LITTLE() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBL)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_SLAP_LEFT_LITTLE))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 4 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLSAndIMAGE_ROLLED_RIGHT_THUMB() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBLS)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 323 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLSAndIMAGE_ROLLED_RIGHT_INDEX() {

		PBKeyedTemplate syncDeletePayload = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBLS)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_ROLLED_RIGHT_INDEX))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(syncDeletePayload, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 323 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLSAndIMAGE_ROLLED_RIGHT_MIDDLE() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBLS)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_ROLLED_RIGHT_MIDDLE))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 323 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLSAndIMAGE_ROLLED_RIGHT_RING() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBLS)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_ROLLED_RIGHT_RING))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 323 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLSAndIMAGE_ROLLED_RIGHT_LITTLE() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBLS)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_ROLLED_RIGHT_LITTLE))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 323 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLSAndIMAGE_ROLLED_LEFT_THUMB() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBLS)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_ROLLED_LEFT_THUMB))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 323 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLSAndIMAGE_ROLLED_LEFT_INDEX() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBLS)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_ROLLED_LEFT_INDEX))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 323 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLSAndIMAGE_ROLLED_LEFT_MIDDLE() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBLS)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_ROLLED_LEFT_MIDDLE))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 323 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLSAndIMAGE_ROLLED_LEFT_RING() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBLS)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_ROLLED_LEFT_RING))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 323 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLSAndIMAGE_ROLLED_LEFT_LITTLE() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBLS)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_ROLLED_LEFT_LITTLE))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 323 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	public void testFindRegContainerIdsAndTEMPLATE_RDBLSAndIMAGE_SLAP_RIGHT_THUMB() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBLS)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_SLAP_RIGHT_THUMB))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 324 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLSAndIMAGE_SLAP_RIGHT_INDEX() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBLS)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_SLAP_RIGHT_INDEX))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 324 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLSAndIMAGE_SLAP_RIGHT_MIDDLE() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBLS)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_SLAP_RIGHT_MIDDLE))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 324 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLSAndIMAGE_SLAP_RIGHT_RING() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()

				.setKey(TemplateFormatType.TEMPLATE_RDBLS)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_SLAP_RIGHT_RING))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 324 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLSAndIMAGE_SLAP_RIGHT_LITTLE() {

		PBKeyedTemplate kTemplate =

		PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBLS)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_SLAP_RIGHT_LITTLE))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 324 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLSAndIMAGE_SLAP_LEFT_THUMB() {

		PBKeyedTemplate kTemplate =

		PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBLS)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_SLAP_LEFT_THUMB))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 324 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLSAndIMAGE_SLAP_LEFT_INDEX() {

		PBKeyedTemplate kTemplate =

		PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBLS)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_SLAP_LEFT_INDEX))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 324 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLSAndIMAGE_SLAP_LEFT_MIDDLE() {

		PBKeyedTemplate kTemplate =

		PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBLS)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_SLAP_LEFT_MIDDLE))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 324 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLSAndIMAGE_SLAP_LEFT_RING() {

		PBKeyedTemplate kTemplate =

		PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBLS)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_SLAP_LEFT_RING))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 324 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_RDBLSAndIMAGE_SLAP_LEFT_LITTLE() {

		PBKeyedTemplate kTemplate =

		PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_RDBLS)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_SLAP_LEFT_LITTLE))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 324 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	// TEMPLATE_RDBLX
	@Test
	public void testFindRegContainerIdsAndKeyTemplateisTEMPLATE_RDBLX() {

		PBKeyedTemplate kTemplate =

		PBKeyedTemplate.newBuilder().setKey(TemplateFormatType.TEMPLATE_RDBLX)
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 341 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_RIGHT_FULL() {

		PBKeyedTemplate kTemplate =

		PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_PDB)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_PALM_RIGHT_FULL))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_RIGHT_WRITER() {

		PBKeyedTemplate kTemplate =

		PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_PDB)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_PALM_RIGHT_WRITER))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_LEFT_FULL() {

		PBKeyedTemplate kTemplate =

		PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_PDB)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_PALM_LEFT_FULL))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_LEFT_WRITER() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_PDB)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_PALM_LEFT_WRITER))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_RIGHT_LOWER() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_PDB)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_PALM_RIGHT_LOWER))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_RIGHT_UPPER() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_PDB)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_PALM_RIGHT_UPPER))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_LEFT_LOWER() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_PDB)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_PALM_LEFT_LOWER))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_LEFT_UPPER() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_PDB)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_PALM_LEFT_UPPER))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_RIGHT_OTHER() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_PDB)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_PALM_RIGHT_OTHER))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_LEFT_OTHER() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_PDB)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_PALM_LEFT_OTHER))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_RIGHT_INTERDIGITAL() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_PDB)
				.setIndexer(
						PBKeyedTemplateIndexer
								.newBuilder()
								.setPosition(
										ImagePositionType.IMAGE_PALM_RIGHT_INTERDIGITAL))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_RIGHT_THENAR() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_PDB)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_PALM_RIGHT_THENAR))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_RIGHT_HYPOTHENAR() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_PDB)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_PALM_RIGHT_HYPOTHENAR))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_LEFT_INTERDEGITAL() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_PDB)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_PALM_LEFT_INTERDIGITAL))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_LEFT_THENAR() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_PDB)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_PALM_LEFT_THENAR))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_PDBAndIMAGE_PALM_LEFT_HYPOTHENAR() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate
				.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_PDB)
				.setIndexer(
						PBKeyedTemplateIndexer.newBuilder().setPosition(
								ImagePositionType.IMAGE_PALM_LEFT_HYPOTHENAR))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 5 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndKeyTemplateisTEMPLATE_IDB() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_IDB).build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 343 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndKeyTemplateisTEMPLATE_LDB() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_LDB).build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 321 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndKeyTemplateisTEMPLATE_PLDB() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_PLDB).build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 322 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndKeyTemplateisTEMPLATE_LDBS() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_LDBS).build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 326 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndKeyTemplateisTEMPLATE_LDBM() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_LDBM).build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 336 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndKeyTemplateisTEMPLATE_LDBX() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_LDBX).build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 342 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	// TEMPLATE_FDB

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_FDBAnd1() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_FDB)
				.setIndexer(PBKeyedTemplateIndexer.newBuilder().setIndex(1))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 335 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_FDBAnd2() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_FDB)
				.setIndexer(PBKeyedTemplateIndexer.newBuilder().setIndex(2))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 335 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_FDBAnd3() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_FDB)
				.setIndexer(PBKeyedTemplateIndexer.newBuilder().setIndex(3))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 335 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_FDBAnd4() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_FDB)
				.setIndexer(PBKeyedTemplateIndexer.newBuilder().setIndex(4))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 335 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_FDBAnd5() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_FDB)
				.setIndexer(PBKeyedTemplateIndexer.newBuilder().setIndex(5))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 335 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}
	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_FDBAnd6() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_FDB)
				.setIndexer(PBKeyedTemplateIndexer.newBuilder().setIndex(6))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 335 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_FDBAnd7() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_FDB)
				.setIndexer(PBKeyedTemplateIndexer.newBuilder().setIndex(7))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 335 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_FDBAnd8() {
		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_FDB)
				.setIndexer(PBKeyedTemplateIndexer.newBuilder().setIndex(8))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 335 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}
	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_FDBAnd9() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_FDB)
				.setIndexer(PBKeyedTemplateIndexer.newBuilder().setIndex(9))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 335 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

	@Test
	public void testFindRegContainerIdsAndTEMPLATE_FDBAnd10() {

		PBKeyedTemplate kTemplate = PBKeyedTemplate.newBuilder()
				.setKey(TemplateFormatType.TEMPLATE_FDB)
				.setIndexer(PBKeyedTemplateIndexer.newBuilder().setIndex(10))
				.build();
		Set<Integer> ids = manager.findRegContainerIds(kTemplate, 1);
		Assert.assertEquals(1, ids.size());
		int[] expect = new int[] { 335 };
		int index = 0;
		for (Integer id : ids) {
			Assert.assertEquals(expect[index++], id.intValue());
		}

	}

}
