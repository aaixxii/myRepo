package jp.co.nec.aim.mm.procedure;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

import javax.sql.DataSource;

import oracle.jdbc.OracleConnection;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.AbstractSqlTypeValue;
import org.springframework.jdbc.support.nativejdbc.CommonsDbcpNativeJdbcExtractor;

/**
 * MarkCorruptedTemplate
 * 
 * @author liuyq
 * 
 */
public class MarkCorruptedTemplate {
	private static String SQL = "UPDATE person_biometrics SET corrupted_flag = 1 "
			+ "WHERE corrupted_flag = 0 "
			+ "AND biometrics_id IN(SELECT * FROM TABLE(CAST(:bioIds AS num_table_type))) ";

	private static final String NUM_TABLE_TYPE = "NUM_TABLE_TYPE";

	private JdbcTemplate jdbcTemplate;

	private List<Long> bioIds;

	public MarkCorruptedTemplate(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
		jdbcTemplate
				.setNativeJdbcExtractor(new CommonsDbcpNativeJdbcExtractor());
	}

	public int execute() {
		return jdbcTemplate.update(SQL, new Object[] { new BioIdArray() },
				new int[] { Types.ARRAY });

	}

	/**
	 * BioIdArray
	 * 
	 * @author liuyq
	 * 
	 */
	private class BioIdArray extends AbstractSqlTypeValue {
		@Override
		protected Object createTypeValue(Connection con, int sqlType,
				String typeName) throws SQLException {
			OracleConnection oraConn = con.unwrap(OracleConnection.class);
			return oraConn.createARRAY(NUM_TABLE_TYPE, bioIds.toArray());
		}

	}

	public void setBioIds(List<Long> bioIds) {
		this.bioIds = bioIds;
	}

}
