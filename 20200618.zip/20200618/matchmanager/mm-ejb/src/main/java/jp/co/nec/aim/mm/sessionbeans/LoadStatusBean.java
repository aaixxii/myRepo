package jp.co.nec.aim.mm.sessionbeans;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.AIMEnumTypes.ComponentType;
import jp.co.nec.aim.message.proto.AIMMessages.PBLoadState;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.MuLoadDao;
import jp.co.nec.aim.mm.dao.UnitDao;
import jp.co.nec.aim.mm.entities.MatchUnitEntity;
import jp.co.nec.aim.mm.exception.ArgumentException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * LoadStatusBean <br>
 * 
 * Update MU Load status <br>
 * 
 * @author liuyq
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class LoadStatusBean {

	/** log instance **/
	private static Logger log = LoggerFactory.getLogger(LoadStatusBean.class);

	@PersistenceContext(unitName = "AIMDB")
	private EntityManager manager;

	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;
	private MuLoadDao loadDao;
	private DateDao dateDao;
	private UnitDao unitDao;

	/**
	 * default constructor
	 */
	public LoadStatusBean() {
	}

	@PostConstruct
	private void init() {
		this.loadDao = new MuLoadDao(dataSource);
		this.dateDao = new DateDao(dataSource);
		this.unitDao = new UnitDao(manager);
	}

	/**
	 * Update MuLoad with specified argument PBLoadState
	 * 
	 * @param request
	 *            the instance of PBLoadState
	 */
	public void updateMuLoad(final PBLoadState request) {
		final ComponentType type = request.getComponent();
		if (type != ComponentType.MATCH_UNIT) {
			final AimError error = AimError.COMPONENT_TYPE;
			String message = String.format(error.getMessage(), type.name());
			log.error(message);
			throw new ArgumentException(error.getErrorCode(), message,
					String.valueOf(dateDao.getCurrentTimeMS()), error.getUidCode());
		}

		final Long muId = request.getId();
		MatchUnitEntity mu = unitDao.findMU(muId);
		if (mu == null) {
			log.warn("Could not find MU with id: {} when update MuLoad.", muId);
			return;
		}

		final int load = request.getMatchingLoad();
		log.debug("Ready to update inquiry mu load, " + "MU id:{}, load: {}.",
				muId, load);
		loadDao.updateInquiryLoad(muId.intValue(), Long.valueOf(load));
		log.debug("Update inquiry mu load successfully, "
				+ "MU id:{}, load: {}.", muId, load);
	}
}
