package jp.co.nec.aim.mm.util;

import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;

/**
 * the utility of Scope
 * 
 * @author liuyq
 * 
 */
public final class ScopeUtil {
	/** log instance **/
	private static Logger log = LoggerFactory.getLogger(ScopeUtil.class);
	private static final int MULTIPLE = 1000;
	private static final int DEFAULT_SCOPE = 1;

	/**
	 * get Real ContainerId set with specified scope
	 * 
	 * @param cId
	 *            container id
	 * @param scope
	 *            scope
	 * @return Real container id set
	 */
	public static final Set<Integer> getRealContainerId(Integer cId,
			Integer scope) {
		if (scope == null || scope <= 0) {
			scope = DEFAULT_SCOPE;
		}

		final Set<Integer> cIds = Sets.newHashSet(cId);
		final List<Integer> scopes = Lists.newArrayList(scope);

		return getRealContainerId(cIds, scopes);
	}

	/**
	 * 
	 * @param cId
	 * @param scopes
	 * @return
	 */
	public static final Set<Integer> getRealContainerId(Integer cId,
			List<Integer> scopes) {
		final Set<Integer> cIds = Sets.newHashSet(cId);
		return getRealContainerId(cIds, scopes);
	}

	/**
	 * get Real ContainerId set with specified scope
	 * 
	 * @param cIds
	 *            container id set
	 * @param scope
	 *            scope
	 * @return Real container id set
	 */
	public static final Set<Integer> getRealContainerId(Set<Integer> cIds,
			Integer scope) {
		if (scope == null || scope <= 0) {
			scope = DEFAULT_SCOPE;
		}
		List<Integer> scopes = Lists.newArrayList(scope);
		return getRealContainerId(cIds, scopes);
	}

	/**
	 * get Real ContainerId set with specified scope list
	 * 
	 * @param cIds
	 *            container id set
	 * @param scopes
	 *            scope list
	 * @return Real container id set
	 */
	public static final Set<Integer> getRealContainerId(Set<Integer> cIds,
			List<Integer> scopes) {
		Set<Integer> real = Sets.newTreeSet();
		if (CollectionsUtil.isEmpty(cIds)) {
			log.error("Input parameter container id list is null or empty..");
			return real;
		}

		Set<Integer> scopeSet = Sets.newTreeSet();
		if (CollectionsUtil.isNotEmpty(scopes)) {
			scopeSet = Sets.newTreeSet(scopes);
		} else {
			scopeSet.add(DEFAULT_SCOPE);
			log.warn("Input parameter scope List is null or empty..");
		}

		for (final Integer scope : scopeSet) {
			if (scope == null) {
				log.warn("scope is null while convert into real container ids..");
				continue;
			}

			for (Integer cid : cIds) {
				if (cid == null) {
					log.warn("container id is null while convert into real container ids..");
					continue;
				}
				real.add((scope - 1) * MULTIPLE + cid);
			}
		}
		return real;
	}
}
