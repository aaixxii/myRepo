package jp.co.nec.aim.mm.procedure;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import oracle.jdbc.OracleTypes;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.util.StopWatch;

public class GetAllContainerJobsProcedure extends StoredProcedure {

	private static final String SQL = "MATCH_MANAGER_API.get_container_results";

	public GetAllContainerJobsProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(SQL);
		declareParameter(new SqlOutParameter("p_success_refcursor",
				OracleTypes.CURSOR, new SuccessCursorMapper()));
		declareParameter(new SqlParameter("p_job_id", Types.NUMERIC));
		compile();
	}

	/**
	 * Returns JOB_QUEUE.REMAIN_JOBS if succeeded update MU_JOBS to DONE
	 * 
	 * @param jobId
	 *            JOB_ID
	 * @param containerJobId
	 * @param result
	 * @return JOB_QUEUE.REMAIN_JOBS if succeeded. -1 If it failed
	 */
	public Map<String, Object> action(long topleveljob) {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_job_id", topleveljob);
		Map<String, Object> resultMap = execute(map);

		stopWatch.stop();

		return resultMap;
	}

	private class SuccessCursorMapper implements RowMapper<ContainerJobResult> {
		@Override
		public ContainerJobResult mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			ContainerJobResult containerJobResult = new ContainerJobResult();

			containerJobResult.setContainerJobsResult(rs
					.getBytes("CONTAINER_JOB_RESULT"));
			return containerJobResult;
		}
	}
}
