package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.jdbc.object.StoredProcedure;

/**
 * 
 * @author xiazp
 *
 */
public class FeJobProcedures extends StoredProcedure {
	private static final String CREATE_NEW_FE_JOB = "CREATE_NEW_FE_JOB";

	public FeJobProcedures(DataSource dataSource) {
		setDataSource(dataSource);		
		setSql(CREATE_NEW_FE_JOB);
		declareParameter(new SqlParameter("p_exteral_id", Types.VARCHAR));
		declareParameter(new SqlParameter("p_requst_id", Types.VARCHAR));
		declareParameter(new SqlParameter("p_requst_type", Types.VARCHAR));
		declareParameter(new SqlParameter("p_payload", Types.VARCHAR));
		declareParameter(new SqlOutParameter("l_fe_job_id", Types.BIGINT));
		compile();
	}
	
	public Long createNewFeJob(String externalId, String requestId, String requestType, String payload) throws SQLException {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_exteral_id", externalId);
		map.put("p_requst_id", requestId);
		map.put("p_requst_type", requestType);
		map.put("p_payload",  payload);
		Map<String, Object> resultMap = execute(map);
		Long feJobid = (Long) resultMap.get("l_fe_job_id");
		return feJobid;		
	}	
}
