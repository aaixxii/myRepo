package jp.co.nec.aim.mm.segment.sync;

import java.io.Serializable;
import jp.co.nec.aim.dm.message.proto.AimDmMessages.SegmentSyncCommandType;

/**
 * SegSyncInfos used for save the sync information
 * 
 * @author liuyq
 * 
 */
public class SegSyncInfos implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -8112460864475125259L;
	private String externalId;
	private Long segmentId; 
	private Long segVersion; 
	private Long templateId;
	private Boolean isUpdateSegment; 
	private SegmentSyncCommandType command;
	private byte[] templateData;
	
	public SegSyncInfos() {		
	}

	/**
	 * SegSyncInfos constructor
	 * 
	 * @param segmentId
	 * @param templateBinary
	 * @param isUpdateSegment
	 */
	public SegSyncInfos(Long segmentId, Long segVersion, Long biometricId,
			 boolean isUpdateSegment,
			SegmentSyncCommandType command) {
		this.segmentId = segmentId;
		this.segVersion = segVersion;
		this.templateId = biometricId;
		//this.templateBinary = templateBinary;
		this.isUpdateSegment = isUpdateSegment;
		this.command = command;
	}

	/**
	 * SegSyncInfos another constructor
	 * 
	 * @param segmentId
	 * @param segVersion
	 * @param templateId
	 * @param command
	 */
	public SegSyncInfos(long segmentId, long segVersion, long templateId,
			SegmentSyncCommandType command) {
		this.segmentId = segmentId;
		this.segVersion = segVersion;
		this.templateId = templateId;
		this.command = command;
	}

	public Long getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(Long segmentId) {
		this.segmentId = segmentId;
	}	

	public boolean isUpdateSegment() {
		return isUpdateSegment;
	}

	public void setUpdateSegment(Boolean isUpdateSegment) {
		this.isUpdateSegment = isUpdateSegment;
	}

	public SegmentSyncCommandType getCommand() {
		return command;
	}

	public void setCommand(SegmentSyncCommandType command) {
		this.command = command;
	}

	public Long getSegVersion() {
		return segVersion;
	}

	public void setSegVersion(Long segVersion) {
		this.segVersion = segVersion;
	}

	public Long getTemplateId() {
		return templateId;
	}

	public void setTemplateId(Long templateId) {
		this.templateId = templateId;
	}

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public Boolean getIsUpdateSegment() {
		return isUpdateSegment;
	}

	public void setIsUpdateSegment(Boolean isUpdateSegment) {
		this.isUpdateSegment = isUpdateSegment;
	}

	public byte[] getTemplateData() {
		return templateData;
	}

	public void setTemplateData(byte[] templateData) {
		this.templateData = templateData;
	}
}
