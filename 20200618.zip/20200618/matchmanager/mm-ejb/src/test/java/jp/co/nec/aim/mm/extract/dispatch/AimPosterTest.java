package jp.co.nec.aim.mm.extract.dispatch;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import jp.co.nec.aim.message.proto.SyncService.SyncResponse;
import jp.co.nec.aim.mm.util.ProtobufCreater;

public class AimPosterTest {
	private static Logger logger = LoggerFactory.getLogger(AimPosterTest.class);
	private static final String URL = "localhost";
	private static final int PORT = 7878;
	private final String postString = "this is message from aim poster, pealse receive it and response to me";
	private int muPostRetryCount = 3;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testPostRequestStringByteArray() throws IOException {
		InetSocketAddress addr = new InetSocketAddress(URL, PORT);
		HttpServer server = HttpServer.create(addr, 0);
		ExecutorService httpThreadPool = Executors.newFixedThreadPool(1);
		server.setExecutor(httpThreadPool);
		server.createContext("/", new HttpHandler() {
			@Override
			public void handle(HttpExchange httpExchange) throws IOException {
				InputStream is = httpExchange.getRequestBody();
				byte[] buff = new byte[is.available()];
				BufferedInputStream bi = new BufferedInputStream(is);
				bi.read(buff);
				Assert.assertEquals(postString.getBytes().length, buff.length);
				Assert.assertEquals(postString, new String(buff));
				bi.close();
				buff = null;
				final String response = "Hello AIM5.0 AimPoster,Thanks for http post to Me!";
				httpExchange.sendResponseHeaders(200, response.length());
				OutputStream os = httpExchange.getResponseBody();
				os.write(response.getBytes());
				os.close();
			}
		});
		server.start();
		String postUrl = "http://" + URL + ":" + PORT;
		ExtractRequestPoster poster = new ExtractRequestPoster();
		boolean result = poster.postRequest(postUrl, muPostRetryCount,
				postString.getBytes());
		Assert.assertTrue(result);
		logger.info("HttpServer shutdown!");
		server.stop(1);
		httpThreadPool.shutdownNow();
	}

	@Test
	public void testPostRequestStringString() throws IOException {
		InetSocketAddress addr = new InetSocketAddress(URL, PORT);
		HttpServer server = HttpServer.create(addr, 0);
		ExecutorService httpThreadPool = Executors.newFixedThreadPool(1);
		server.setExecutor(httpThreadPool);
		server.createContext("/", new HttpHandler() {
			@Override
			public void handle(HttpExchange httpExchange) throws IOException {
				InputStream is = httpExchange.getRequestBody();
				byte[] buff = new byte[is.available()];
				BufferedInputStream bi = new BufferedInputStream(is);
				bi.read(buff);
				Assert.assertEquals(postString.getBytes().length, buff.length);
				Assert.assertEquals(postString, new String(buff));
				bi.close();
				buff = null;
				final String response = "Hello AIM5.0 AimPoster,Thanks for http post to Me!";
				httpExchange.sendResponseHeaders(200, response.length());
				OutputStream os = httpExchange.getResponseBody();
				os.write(response.getBytes());
				os.close();
			}
		});
		System.out.println("HttpServer started!");
		server.start();
		String postUrl = "http://" + URL + ":" + PORT;
		ExtractRequestPoster poster = new ExtractRequestPoster();
		boolean result = poster.postRequest(postUrl, muPostRetryCount,
				postString);
		Assert.assertTrue(result);
		logger.info("HttpServer shutdown!");
		server.stop(1);
		httpThreadPool.shutdownNow();
	}

}
