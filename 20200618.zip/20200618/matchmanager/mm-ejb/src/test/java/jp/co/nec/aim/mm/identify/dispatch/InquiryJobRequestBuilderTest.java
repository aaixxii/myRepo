package jp.co.nec.aim.mm.identify.dispatch;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.AIMMessages.PBMapInquiryJobRequest;
import jp.co.nec.aim.mm.dao.UnitDao;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.identify.planner.MuJobExecutePlan;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class InquiryJobRequestBuilderTest {

	private InquiryJobRequestBuilder inquiryJobRequestBuilder;
	@Resource
	private JdbcTemplate jdbcTemplate;

	@Resource
	private DataSource dataSource;

	@PersistenceContext(unitName = "AIMDB")
	private EntityManager entityManager;

	@Before
	public void setUp() {
		jdbcTemplate.update("delete from match_units");
		UnitDao unitDao = new UnitDao(entityManager);

		inquiryJobRequestBuilder = new InquiryJobRequestBuilder(unitDao);
		jdbcTemplate.update("commit");
	}

	@After
	public void tearDown() {
		jdbcTemplate.update("delete from match_units");
		jdbcTemplate.update("commit");
	}

	@Test
	public void testCreateRequestMuIsNull() {
		byte[] bytes = { 1, 2, 3 };
		MuJobExecutePlan muJobExecutePlan = new MuJobExecutePlan();
		muJobExecutePlan.setContainerId(1);
		muJobExecutePlan.setFunctionId(1);
		muJobExecutePlan.setJobId(1l);
		muJobExecutePlan.setPlan("1,1:1,2:1/2,4:1");
		muJobExecutePlan.setPlanedCount(1);
		muJobExecutePlan.setPlanedTs(123);
		muJobExecutePlan.setPlanId(1l);
		InqDispatchInfo info = new InqDispatchInfo();
		info.setContainerJobId(1);
		info.setInquiryData(bytes);
		info.setInternalMaxCandidates(26);
		info.setJobTimeout(111);
		info.setMessageSequence(5);
		info.setRequestIndex(1);

		try {
			inquiryJobRequestBuilder.createRequest(info, muJobExecutePlan);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof AimRuntimeException);
			Assert.assertEquals("Can not get MU(1) contact URL.",
					e.getMessage());
		}

	}

	@Test
	public void testCreateRequestMuSegIdIsEmp() {
		jdbcTemplate
				.update("insert into match_units(MU_ID,UNIQUE_ID,STATE,Contact_Url)values(1,2,'WORKING','192.168.1.1')");
		jdbcTemplate
				.update("insert into match_units(MU_ID,UNIQUE_ID,STATE,Contact_Url)values(2,2,'WORKING','192.168.1.1')");
		jdbcTemplate.update("commit");
		byte[] bytes = { 1, 2, 3 };
		MuJobExecutePlan muJobExecutePlan = new MuJobExecutePlan();
		muJobExecutePlan.setContainerId(1);
		muJobExecutePlan.setFunctionId(1);
		muJobExecutePlan.setJobId(1l);
		muJobExecutePlan.setPlan("1,1:1,2:1/2,4:1");
		muJobExecutePlan.setPlanedCount(1);
		muJobExecutePlan.setPlanedTs(123);
		muJobExecutePlan.setPlanId(1l);
		InqDispatchInfo info = new InqDispatchInfo();
		info.setContainerJobId(1);
		info.setInquiryData(bytes);
		info.setInternalMaxCandidates(26);
		info.setJobTimeout(111);
		info.setMessageSequence(5);
		info.setRequestIndex(1);
		try {
			inquiryJobRequestBuilder.createRequest(info, muJobExecutePlan);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof AimRuntimeException);
			Assert.assertEquals(
					"Exception occurred when create PBTargetSegmentVersion instance",
					e.getMessage());
		}
	}

	@Test
	public void testCreateRequestMuSegIdVerLengthNotTwo() {
		jdbcTemplate
				.update("insert into match_units(MU_ID,UNIQUE_ID,STATE,Contact_Url)values(1,2,'WORKING','192.168.1.1')");
		jdbcTemplate
				.update("insert into match_units(MU_ID,UNIQUE_ID,STATE,Contact_Url)values(2,2,'WORKING','192.168.1.1')");
		jdbcTemplate.update("commit");
		byte[] bytes = { 1, 2, 3 };
		MuJobExecutePlan muJobExecutePlan = new MuJobExecutePlan();
		muJobExecutePlan.setContainerId(1);
		muJobExecutePlan.setFunctionId(1);
		muJobExecutePlan.setJobId(1l);
		muJobExecutePlan.setPlan("1,1:2:3/2,4:1");
		muJobExecutePlan.setPlanedCount(1);
		muJobExecutePlan.setPlanedTs(123);
		muJobExecutePlan.setPlanId(1l);
		InqDispatchInfo info = new InqDispatchInfo();
		info.setContainerJobId(1);
		info.setInquiryData(bytes);
		info.setInternalMaxCandidates(26);
		info.setJobTimeout(111);
		info.setMessageSequence(5);
		info.setRequestIndex(1);
		try {
			inquiryJobRequestBuilder.createRequest(info, muJobExecutePlan);
		} catch (Exception e) {
			// TODO: handle exception
			Assert.assertTrue(e instanceof AimRuntimeException);
			Assert.assertEquals("Seg:Version length is not 2.", e.getMessage());
		}
	}

	@Test
	public void testCreateRequest() {
		jdbcTemplate
				.update("insert into match_units(MU_ID,UNIQUE_ID,STATE,Contact_Url)values(1,2,'WORKING','192.168.1.1')");
		jdbcTemplate
				.update("insert into match_units(MU_ID,UNIQUE_ID,STATE,Contact_Url)values(2,2,'WORKING','192.168.1.1')");
		jdbcTemplate.update("commit");
		byte[] bytes = { 1, 2, 3 };
		MuJobExecutePlan muJobExecutePlan = new MuJobExecutePlan();
		muJobExecutePlan.setContainerId(1);
		muJobExecutePlan.setFunctionId(1);
		muJobExecutePlan.setJobId(1l);
		muJobExecutePlan.setPlan("1,1:1,2:1/2,4:1");
		muJobExecutePlan.setPlanedCount(1);
		muJobExecutePlan.setPlanedTs(123);
		muJobExecutePlan.setPlanId(1l);
		InqDispatchInfo info = new InqDispatchInfo();
		info.setContainerJobId(1);
		info.setInquiryData(bytes);
		info.setInternalMaxCandidates(26);
		info.setJobTimeout(111);
		info.setMessageSequence(5);
		info.setRequestIndex(1);
		PBMapInquiryJobRequest.Builder mapInqReq = inquiryJobRequestBuilder
				.createRequest(info, muJobExecutePlan);
		Assert.assertEquals(2, mapInqReq.getMuJobMapList().size());
		Assert.assertEquals(1, mapInqReq.getMuJobMapList().get(0).getMuId());
		Assert.assertEquals(2, mapInqReq.getMuJobMapList().get(0)
				.getTargetSegmentsCount());
		Assert.assertEquals("192.168.1.1/matchunit/InquiryJob", mapInqReq
				.getMuJobMapList().get(0).getUrl());
		Assert.assertEquals(1, mapInqReq.getMuJobMapList().get(1)
				.getTargetSegmentsCount());
	}

	@Test
	public void testCreateRequest_timeout_value() {
		jdbcTemplate
				.update("insert into match_units(MU_ID,UNIQUE_ID,STATE,Contact_Url)values(1,2,'WORKING','192.168.1.1')");
		jdbcTemplate
				.update("insert into match_units(MU_ID,UNIQUE_ID,STATE,Contact_Url)values(2,2,'WORKING','192.168.1.1')");
		jdbcTemplate.update("commit");
		byte[] bytes = { 1, 2, 3 };
		MuJobExecutePlan muJobExecutePlan = new MuJobExecutePlan();
		muJobExecutePlan.setContainerId(1);
		muJobExecutePlan.setFunctionId(1);
		muJobExecutePlan.setJobId(1l);
		muJobExecutePlan.setPlan("1,1:1,2:1/2,4:1");
		muJobExecutePlan.setPlanedCount(1);
		muJobExecutePlan.setPlanedTs(123);
		muJobExecutePlan.setPlanId(1l);
		InqDispatchInfo info = new InqDispatchInfo();
		info.setContainerJobId(1);
		info.setInquiryData(bytes);
		info.setInternalMaxCandidates(26);
		info.setJobTimeout(-1);
		info.setMessageSequence(5);
		info.setRequestIndex(1);
		PBMapInquiryJobRequest.Builder mapInqReq = inquiryJobRequestBuilder
				.createRequest(info, muJobExecutePlan);
		Assert.assertEquals(2, mapInqReq.getMuJobMapList().size());
		Assert.assertEquals(1, mapInqReq.getMuJobMapList().get(0).getMuId());
		Assert.assertEquals(2, mapInqReq.getMuJobMapList().get(0)
				.getTargetSegmentsCount());
		Assert.assertEquals(Long.MAX_VALUE, mapInqReq.getJobInfo()
				.getJobTimeout());
		Assert.assertEquals("192.168.1.1/matchunit/InquiryJob", mapInqReq
				.getMuJobMapList().get(0).getUrl());
		Assert.assertEquals(1, mapInqReq.getMuJobMapList().get(1)
				.getTargetSegmentsCount());
	}

	@Test
	public void testCreateRequest_ContactUrl() {
		jdbcTemplate
				.update("insert into match_units(MU_ID,UNIQUE_ID,STATE,Contact_Url)values(1,2,'WORKING','192.168.1.1/')");
		jdbcTemplate
				.update("insert into match_units(MU_ID,UNIQUE_ID,STATE,Contact_Url)values(2,2,'WORKING','192.168.1.1/')");
		jdbcTemplate.update("commit");
		byte[] bytes = { 1, 2, 3 };
		MuJobExecutePlan muJobExecutePlan = new MuJobExecutePlan();
		muJobExecutePlan.setContainerId(1);
		muJobExecutePlan.setFunctionId(1);
		muJobExecutePlan.setJobId(1l);
		muJobExecutePlan.setPlan("1,1:1,2:1/2,4:1");
		muJobExecutePlan.setPlanedCount(1);
		muJobExecutePlan.setPlanedTs(123);
		muJobExecutePlan.setPlanId(1l);
		InqDispatchInfo info = new InqDispatchInfo();
		info.setContainerJobId(1);
		info.setInquiryData(bytes);
		info.setInternalMaxCandidates(26);
		info.setJobTimeout(111);
		info.setMessageSequence(5);
		info.setRequestIndex(1);
		PBMapInquiryJobRequest.Builder mapInqReq = inquiryJobRequestBuilder
				.createRequest(info, muJobExecutePlan);
		Assert.assertEquals(2, mapInqReq.getMuJobMapList().size());
		Assert.assertEquals(1, mapInqReq.getMuJobMapList().get(0).getMuId());
		Assert.assertEquals(2, mapInqReq.getMuJobMapList().get(0)
				.getTargetSegmentsCount());
		Assert.assertEquals("192.168.1.1/matchunit/InquiryJob", mapInqReq
				.getMuJobMapList().get(0).getUrl());
		Assert.assertEquals(1, mapInqReq.getMuJobMapList().get(1)
				.getTargetSegmentsCount());
	}
}
