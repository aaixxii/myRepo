package jp.co.nec.aim.mm.dao;

import javax.sql.DataSource;

import jp.co.nec.aim.mm.procedure.DecreaseExtractLoadProcedure;
import jp.co.nec.aim.mm.procedure.UpdateInquiryLoadProcedure;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author mozj
 * 
 */
public class MuLoadDao {

	/** log instance **/
	private static Logger log = LoggerFactory.getLogger(MuLoadDao.class);
	private final DataSource dataSource;

	/**
	 * 
	 * @param em
	 * @param dataSource
	 */
	public MuLoadDao(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	/**
	 * update InquiryLoad
	 * 
	 * @param muId
	 * @param inquiryLoad
	 */
	public void updateInquiryLoad(Integer muId, Long inquiryLoad) {
		final UpdateInquiryLoadProcedure procedure = new UpdateInquiryLoadProcedure(
				dataSource);
		procedure.setMuId(muId);
		procedure.setInquiryLoad(inquiryLoad);
		procedure.execute();
	}

	/**
	 * update ExtractLoad
	 * 
	 * @param muId
	 */
	public void decreaseExtractLoad(Long muId) {
		decreaseExtractLoad(muId, 1);
	}

	/**
	 * update ExtractLoad
	 * 
	 * @param muId
	 * @param count
	 */
	public void decreaseExtractLoad(Long muId, Integer count) {
		if (muId == null) {
			return;
		}
		DecreaseExtractLoadProcedure procedure = new DecreaseExtractLoadProcedure(
				dataSource);
		procedure.setMuId(muId);
		procedure.setLotJobCount(count);
		try {
			Integer pressure = procedure.execute();
			if (pressure < 0) {
				log.warn("Mu(ID={}),pressure({}) is less than 0,set to 0 is necessary)", muId, pressure);
			}
		} catch (Exception e) {
			log.error(e.getMessage());
		}
	}
}
