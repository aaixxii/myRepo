package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

/**
 * The persistent class for the FUSION_JOBS database table.
 * 
 */
@Entity
@Table(name = "FUSION_JOBS")
public class FusionJobEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "FUSION_JOB_ID")
	private long fusionJobId;	
	
	@Column(name = "FUNCTION_ID")
	private int functionId;
	
	@Column(name = "INQUIRY_JOB_XML")
	private String jnquiryJobXml;

	@Lob
	@Column(name = "INQUIRY_PROBE_DATA")
	private byte[] inquiryProbeData;

	@Column(name = "JOB_ID")
	private long jobId;

	@Column(name = "SEARCH_REQUEST_INDEX")
	private int searchRequestIndex;

	public FusionJobEntity() {
	}

	public long getFusionJobId() {
		return this.fusionJobId;
	}

	public void setFusionJobId(long fusionJobId) {
		this.fusionJobId = fusionJobId;
	}

	public int getFunctionId() {
		return this.functionId;
	}

	public void setFunctionId(int functionId) {
		this.functionId = functionId;
	}	

	public String getJnquiryJobXml() {
		return jnquiryJobXml;
	}

	public void setJnquiryJobXml(String jnquiryJobXml) {
		this.jnquiryJobXml = jnquiryJobXml;
	}

	public byte[] getInquiryProbeData() {
		return inquiryProbeData;
	}

	public void setInquiryProbeData(byte[] inquiryProbeData) {
		this.inquiryProbeData = inquiryProbeData;
	}

	public long getJobId() {
		return this.jobId;
	}

	public void setJobId(long jobId) {
		this.jobId = jobId;
	}

	public int getSearchRequestIndex() {
		return this.searchRequestIndex;
	}

	public void setSearchRequestIndex(int searchRequestIndex) {
		this.searchRequestIndex = searchRequestIndex;
	}

}