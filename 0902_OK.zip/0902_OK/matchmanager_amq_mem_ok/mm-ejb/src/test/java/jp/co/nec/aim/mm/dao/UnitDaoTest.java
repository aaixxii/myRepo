package jp.co.nec.aim.mm.dao;

import static org.junit.Assert.assertEquals;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import jp.co.nec.aim.mm.entities.MapReducerEntity;
import jp.co.nec.aim.mm.entities.MatchUnitEntity;
import jp.co.nec.slb.loadbalance.UnitNote;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class UnitDaoTest {
	@Resource
	private DataSource dataSource;

	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;

	@Resource
	private JdbcTemplate jdbcTemplate;

	private UnitDao unitDao;

	@Before
	public void setUp() throws Exception {
		unitDao = new UnitDao(entityManager);

		clearDB();

		SystemConfigDao systemconfigdao = new SystemConfigDao(entityManager);
		systemconfigdao.writeAllMissingProperties(dataSource);

		insertUnit(1, 3, 1, 3, 1, 3);
		insertEligible(1, 3, 1, 3);
	}

	@After
	public void tearDown() throws Exception {
		clearDB();
	}

	private void clearDB() {
		jdbcTemplate.execute("delete from DM_ELIGIBLE_CONTAINERS");
		jdbcTemplate.execute("delete from MU_ELIGIBLE_CONTAINERS");
		jdbcTemplate.execute("delete from MATCH_UNITS");
		jdbcTemplate.execute("delete from JOB_QUEUE");
		jdbcTemplate.execute("delete from FUSION_JOBS");
		jdbcTemplate.execute("delete from CONTAINER_JOBS");
		jdbcTemplate.execute("delete from MAP_REDUCERS");
		jdbcTemplate.execute("delete from DATA_MANAGERS");
		jdbcTemplate.execute("commit");

	}

	private void insertUnit(int startMUId, int muCount, int startMRId,
			int mrCount, int startDMId, int dmCount) {
		for (int id = startMUId; id < startMUId + muCount; id++) {
			jdbcTemplate.execute("insert into MATCH_UNITS(MU_ID, UNIQUE_ID,"
					+ " STATE, NUMBER_OF_MATCHERS,REPORTED_PERFORMANCE_FACTOR)"
					+ " values(" + id + ", '" + id + "', 'WORKING', 5, 1.0)");
			jdbcTemplate.execute("insert into MU_CONTACTS(MU_ID, CONTACT_TS)"
					+ " values(" + id + ", 1421206612748)");
		}

		for (int id = startMRId; id < startMRId + mrCount; id++) {
			jdbcTemplate.execute("insert into MAP_REDUCERS(MR_ID, UNIQUE_ID,"
					+ " STATE) values(" + id + ", '" + id + "', 'WORKING')");
			jdbcTemplate.execute("insert into MR_CONTACTS(MR_ID, CONTACT_TS)"
					+ " values(" + id + ", 1421206612748)");
		}

		for (int id = startDMId; id < startDMId + dmCount; id++) {
			jdbcTemplate.execute("insert into DATA_MANAGERS(DM_ID, UNIQUE_ID,"
					+ " STATE) values(" + id + ", '" + id + "', 'WORKING')");
			jdbcTemplate.execute("insert into DM_CONTACTS(DM_ID, CONTACT_TS)"
					+ " values(" + id + ", 1421206612748)");
		}
	}

	private void insertEligible(int startMUId, int muCount, int startDMId,
			int dmCount) {
		for (int id = startMUId; id < startMUId + muCount; id++) {
			jdbcTemplate.execute("insert into MU_ELIGIBLE_CONTAINERS(MU_ID,"
					+ " CONTAINER_ID) select  " + id
					+ " as MU_ID, CONTAINER_ID from CONTAINERS");
		}
		for (int id = startDMId; id < startDMId + dmCount; id++) {
			jdbcTemplate.execute("insert into DM_ELIGIBLE_CONTAINERS(DM_ID,"
					+ " CONTAINER_ID) select  " + id
					+ " as DM_ID, CONTAINER_ID from CONTAINERS");
		}
	}

	@Test
	public void testFindMU() {
		MatchUnitEntity mu = unitDao.findMU(new Long(1));
		assertEquals(1, mu.getMuId());
		assertEquals(1, Integer.parseInt(mu.getUniqueId().toString()));
		assertEquals("WORKING", mu.getState().toString());
	}

	@Test
	public void test_listEligibleMUs() {
		List<UnitNote> unitList = unitDao.listEligibleMUs(2);
		assertEquals(3, unitList.size());
		for (int i = 0; i < unitList.size(); i++) {
			assertEquals(i + 1, unitList.get(i).getUnitID().intValue());
			assertEquals(0, unitList.get(i).getType().intValue());
			assertEquals(5, unitList.get(i).getCpuNum().intValue());
			assertEquals(new Double(1.0), unitList.get(i).getFactor());
		}
	}

	@Test
	public void test_listTimedOutMRs() {
		List<MapReducerEntity> unitList = unitDao.listTimedOutMRs();
		assertEquals(3, unitList.size());
		for (int i = 0; i < unitList.size(); i++) {
			assertEquals(i + 1, unitList.get(i).getMrId());
		}
	}

	@Test
	public void test_listTimedOutMUs() {
		List<MatchUnitEntity> unitList = unitDao.listTimedOutMUs();
		assertEquals(3, unitList.size());
		for (int i = 0; i < unitList.size(); i++) {
			assertEquals(i + 1, unitList.get(i).getMuId());
		}
	}

}
