package jp.co.nec.aim;

import java.util.Queue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Throwables;

public class FifoQueue<T> {
	final static Logger logger = LoggerFactory.getLogger(FifoQueue.class);
	
	BlockingQueue<T> queue_;

	/**
	 * 
	 * @param capacity
	 */
	public FifoQueue(int capacity) {
		queue_ = new LinkedBlockingQueue<T>();
	}

	public FifoQueue() {
		queue_ = new LinkedBlockingQueue<T>();
	}

	/**
	 * 
	 * @param value
	 * @return
	 * @throws Exception
	 */
	public boolean add(T value)
		throws Exception {
		try {
			queue_.add(value);
		} catch (IllegalStateException ex) {
			logger.error(Throwables.getRootCause(ex).toString());
			return false;
		}
		return true;
	}

	/**
	 * 
	 * @param timeout
	 * @return
	 * @throws Exception
	 */
	public T poll(int timeout)
		throws Exception {
		return queue_.poll(timeout, TimeUnit.SECONDS);
	}

	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	public T take()
		throws Exception {
		return queue_.take();
	}
	
	/**
	 * 
	 * @return
	 */
	public Queue<T> getQueue() {
		return queue_;
	}
}
