package jp.co.nec.aim.log;

import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;

import com.google.common.base.Stopwatch;
import com.google.common.base.Strings;

public class Performance {
	/**
	 * 
	 * @param logger
	 * @param msg
	 * @param stopwatch
	 */
	static public void elapsed(Logger logger, String msg, Stopwatch stopwatch, String externalId) {
		stopwatch.stop();
		long elapsed = stopwatch.elapsed(TimeUnit.MILLISECONDS);
		logger.trace(msg.replace("%2", Long.toString(elapsed)).replace("%3", Strings.nullToEmpty(
			externalId)));
		stopwatch.reset();
	}
}
