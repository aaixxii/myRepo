package jp.co.nec.aim.mock;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CountDownLatch;
import java.util.function.UnaryOperator;

import javax.xml.bind.JAXB;
import javax.xml.transform.stream.StreamSource;

import com.google.common.base.Throwables;
import jp.co.nec.aim.client.SoapCallbackHandler;
import jp.co.nec.aim.message.proto.InquiryService;
import jp.co.nec.aim.message.proto.JobCommonService;
import jp.co.nec.proto.ProtoBuilder;
import lombok.var;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.sun.net.httpserver.HttpServer;

import jp.co.nec.aim.client.SyncType;
import jp.co.nec.aim.extraction.ExtractionClient;
import jp.co.nec.aim.soap.CallbackTest;
import jp.co.nec.aim.soap.CallbackTestResponse;
import jp.co.nec.aim.soap.ExtractJobResult;
import jp.co.nec.aim.soap.SoapClient;
import jp.co.nec.aim.soap.SoapClientConfig;
import jp.co.nec.aim.xml.Extraction;
import jp.co.nec.aim.xml.ParameterReader;
import jp.co.nec.aim.search.SearchClient;
import jp.co.nec.aim.sync.SyncClient;
import lombok.val;

public class MockMain {
    static Logger logger = LoggerFactory.getLogger(MockMain.class);
    // static final Logger logger = LogManager.getLogger(MockMain.class);

    Map<String, String> map = new HashMap<>();

    static MockMain main = new MockMain();

    static CountDownLatch latch = new CountDownLatch(1);

    static public String test() {
        System.out.println(System.getProperty("java.class.path"));
        System.out.println("called test.");
        return "test";
    }

    private static UnaryOperator<Object> IDENTITY_FN = (t) -> t;

    @SuppressWarnings("unchecked")
    public static <T> UnaryOperator<T> identityFunction() {
        return (UnaryOperator<T>) IDENTITY_FN;
    }

    public static void main(String[] args)
            throws Exception {
        ParameterReader.readParameter("./parameter.xml");
        // Verification verification = ParameterReader.getVerification();
        Extraction extraction = ParameterReader.getExtraction();

        AnnotationConfigApplicationContext appContext = new AnnotationConfigApplicationContext(
                SoapClientConfig.class);

        if (args[0].equalsIgnoreCase("--soap_search")) {
            if (Objects.isNull(ParameterReader.getSearch().getSoap())) {
                System.out.println("soap element did not exist.");
                return;
            }
            new SearchClient(appContext).sendSearchRequestWithSoap();
        } else if (args[0].equalsIgnoreCase("--soap_extraction")) {
            if (Objects.isNull(ParameterReader.getExtraction().getSoap())) {
                System.out.println("soap element did not exist.");
                return;
            }
            new ExtractionClient(appContext).sendExtractionRequestWithSoap();
        } else if (args[0].equals("--soap_extraction_with_req")) {
            // val port = verification.getSoap().getCallbackPort();
            // val server = HttpServer.create(new
            // InetSocketAddress(Integer.valueOf(port)), 4);
            // server.createContext("/", new
            // SoapCallbackHandler(SoapCallbackHandler.ProcessType.VERIFICATION,
            // null, null, 0));
            // server.setExecutor(null);
            // server.start();

            val client = appContext.getBean(SoapClient.class);
            client.extract(extraction.getSoap().getEndpoint(), new StreamSource(new FileInputStream(
                    args[1])));

            Thread.sleep(extraction.getSoap().getSleepTimer());
        } else if (args[0].equalsIgnoreCase("--soap_verification")) {
            if (Objects.isNull(ParameterReader.getVerification().getSoap())) {
                System.out.println("soap element did not exist.");
                return;
            }
            // new VerificationClient().sendVerificationRequestWithSoap();
        } else if (args[0].equalsIgnoreCase("--soap_sync_insert")) {
            new SyncClient(appContext).sendSyncRequestWithSoap(SyncType.INSERT);
        } else if (args[0].equalsIgnoreCase("--soap_sync_delete")) {
            new SyncClient(appContext).sendSyncRequestWithSoap(SyncType.DELETE);

        } else if (args[0].equalsIgnoreCase("--proto_sync_insert")) {
            new SyncClient(appContext).sendSyncRequestWithProto(SyncType.INSERT);
        } else if (args[0].equalsIgnoreCase("--proto_sync_delete")) {
            new SyncClient(appContext).sendSyncRequestWithProto(SyncType.DELETE);

        } else if (args[0].equalsIgnoreCase("--proto_inquiry")) {
            if (Objects.isNull(ParameterReader.getSearch().getProto())) {
                System.out.println("soap element did not exist.");
                return;
            }
            new SearchClient(appContext).sendSearchRequestWithProto();
        } else if (args[0].equalsIgnoreCase("--proto_extract")) {
            if (Objects.isNull(ParameterReader.getExtraction().getProto())) {
                System.out.println("proto element did not exist.");
                return;
            }
            new ExtractionClient(appContext).sendExtractionRequestWithProto();
        } else if (args[0].equalsIgnoreCase("--proto_get_inquiry_job_result")) {
            val builder = new ProtoBuilder(0);
            val request = builder.buildPBJobResultRequest(args[1]);
            val response = post(request, args[2]);
            Files.write(Paths.get("./inquiry_job_result.bin"), response.toByteArray());
        } else if (args[0].equals("--callbacktest")) {
            val port = extraction.getSoap().getCallbackPort();
            val server = HttpServer.create(new InetSocketAddress(Integer.valueOf(port)), 4);
            server.createContext("/", new SoapCallbackHandler(appContext,
                    SoapCallbackHandler.ProcessType.CALLBACKTEST, null, null, null, 0));
            server.setExecutor(null);
            server.start();

            val url = new StringBuilder(extraction.getSoap().getCallbackUrl()).append(":").append(
                    extraction.getSoap().getCallbackPort());
            val callbackTest = new CallbackTest();
            callbackTest.setCallbackURL(url.toString());
            callbackTest.setTestString("hello world");

            // ObjectFactory factory = new ObjectFactory();
            // StreamResult result = new StreamResult(new StringWriter());
            // val marshaller = appContext.getBean(Jaxb2Marshaller.class);
            // marshaller.marshal(factory.createCallbackTest(echo), result);
            // logger.info(result.getWriter().toString());
            val client = appContext.getBean(SoapClient.class);
            val response = (CallbackTestResponse) client.callbackTest(extraction.getSoap()
                    .getEndpoint(), callbackTest);
        } else if (args[0].equals("--soap_verification_with_req")) {
            // val port = verification.getSoap().getCallbackPort();
            // val server = HttpServer.create(new
            // InetSocketAddress(Integer.valueOf(port)), 4);
            // server.createContext("/", new
            // SoapCallbackHandler(SoapCallbackHandler.ProcessType.VERIFICATION,
            // null, null, 0));
            // server.setExecutor(null);
            // server.start();
            //
            // val client = appContext.getBean(SoapClient.class);
            // client.submitVerificationJob(verification.getSoap().getEndpoint(),
            // new StreamSource(
            // new FileInputStream(args[1])));
            //
            // Thread.sleep(verification.getSoap().getSleepTimer());
        } else if (args[0].equals("--unmarshall_test")) {
            val obj = JAXB.unmarshal(new StreamSource(new FileInputStream(args[1])),
                    ExtractJobResult.class);

            // val marshaller = appContext.getBean(Jaxb2Marshaller.class);
            // val obj = (ExtractJobResult)marshaller.unmarshal(new
            // StreamSource(new FileInputStream(
            // args[1])));
            for (val keyedBinary : obj.getKeyedBinary()) {
                System.out.println(keyedBinary.getKey());
            }

            // val marshaller = appContext.getBean(Jaxb2Marshaller.class);
            // val obj =
            // (JAXBElement<SubmitVerificationJob>)marshaller.unmarshal(new
            // StreamSource(
            // new FileInputStream(args[1])));
            // logger.info("{}", obj.getValue().getArg0().getCallbackUrl());
        } else if (args[0].compareTo("--validate") == 0 || args[0].compareTo("--validation") == 0) {
            // val heatbeat = new
            // Heartbeat(ParameterReader.getValidation().getManagementPort());
            // heatbeat.doHeartbeat_test();
            // new ValidationClient().sendValidationRequestWithThread();
            return;
        } else if (args[0].compareTo("--help") == 0) {
            System.out.println("  --extract");
            System.out.println("  --capacity_response");
            System.out.println("  --match");
            System.out.println("  --match_response");
            return;
        }
    }

    private static InquiryService.PBInquiryJobResult post(JobCommonService.PBJobResultRequest requestMessage, String url) throws IOException {
        var mediaType = MediaType.parse("application/x-protobuf; charset=utf-8");
        var requestBody = RequestBody.create(requestMessage.toByteArray(), mediaType);
        var request = new Request.Builder().url(url).post(requestBody).build();
        var client = new OkHttpClient();
        try (var response = client.newCall(request).execute()) {
            System.out.println("code:" + response.code());
            if (response.isSuccessful()) {
                return InquiryService.PBInquiryJobResult.parseFrom(response.body().bytes());
            }
            return InquiryService.PBInquiryJobResult.newBuilder().build();
        }
    }

}
