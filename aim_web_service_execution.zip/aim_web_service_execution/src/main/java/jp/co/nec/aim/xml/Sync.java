package jp.co.nec.aim.xml;

import org.simpleframework.xml.Element;

import jp.co.nec.aim.soap.Update;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class Sync {
	@Element(required=true)
	Insert insert;
	
	@Element(required=true)
	Soap soap;

	@Element(required=true)
	Proto proto;

	@Element(required=true)
	Deletion deletion;
}
