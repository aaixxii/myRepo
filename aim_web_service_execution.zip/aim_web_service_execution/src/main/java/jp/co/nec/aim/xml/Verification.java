package jp.co.nec.aim.xml;

import org.simpleframework.xml.Element;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class Verification {
	@Element(required=false)
	String nirisRotation;

	@Element(required=false)
	String nirisSpeed;

	@Element(required=true)
	boolean useNeoFaceParameter;
	
	@Element(required=false)
	Soap soap;

	@Element
	String useCrossMatch;
	
	@Element
	String outputChartsEnabled;
	
	@Element
	String limitOutputCharts;
	
	@Element(required=false)
	String selectFingers;
	
	@Element(required=false)
	String selectPalms;
	
	@Element(required=false)
	Integer numRepeat;

	@Element
	NeoFace neoFace;
	
	@Element
	int numMaxVerificationRequest;
	
	@Element
	int sleepTimer;

	@Element
	boolean blackOnWhite;
	
	@Element
	String elftMatchSpeed;
	
	@Element
	Probe probe;
	
	@Element
	Gallery gallery;
	
	@Element
	String algorithm;
	
	@Element
	boolean outputResponse;
	
	@Element
	boolean outputRequest;

	@Element
	int numReceptionThread;

	@Element
	int numZmqIoThread;
	
	@Element
	int baseEndpointPort;

	@Element
	String managementPort;
	
	@Element
	String jobPort;
	
	@Element
	String endpoint;
}
