package jp.co.nec.aim.xml;

import org.simpleframework.xml.Element;

import lombok.Data;

@Data
public class ElftProbe {
	@Element
	String nist27RawPath;
	
	@Element
	int numFeatureFile;
	
	@Element
	String fixedFingerNumber;
	
	@Element
	String elftTemplatePath;
	
	@Element
	int numLatentFile;
	
	@Element
	String wsqPath;
	
	@Element
	String featurePath;
	
	@Element
	String useFeature;
}
