package jp.co.nec.aim.xml;

import org.simpleframework.xml.Element;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class Fis {
	@Element(required=false)
	String latentPatterns;
	
	@Element(required=false)
	String selectFingers;

	@Element(required=false)
	String algorithm;

	@Element(required=false)
	String feType;

	@Element(required=false)
	String rollPrimaryPatterns;
	
	@Element(required=false)
	String rollReferencePatterns;

	@Element(required=false)
	String slapPrimaryPatterns;
	
	@Element(required=false)
	String slapReferencePatterns;
	
	@Element(required=false)
	ImageEnhance imageEnhance;
}
