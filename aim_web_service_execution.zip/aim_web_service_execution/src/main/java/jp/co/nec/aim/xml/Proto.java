package jp.co.nec.aim.xml;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.simpleframework.xml.Element;

@NoArgsConstructor
@Data
public class Proto {
	@Element(required=true)
	String url;
	
	@Element(required=true)
	String callbackUrl;
	
	@Element(required=true)
	String callbackPort;
	
	@Element(required=true)
	boolean outputRequest;
	
	@Element(required=true)
	boolean outputResponse;
	
	@Element(required=false)
	int sleepTimer;
}
