package jp.co.nec.aim.xml;

import org.simpleframework.xml.Element;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class Point {
	@Element
	int amputation;
	
	@Element
	int angle;
	
	@Element
	int fingerNumber; 
	
	@Element
	int croppingFingerNumber; 
	
	@Element
	Center center;

	@Element
	UpperLeft upperLeft;

	@Element
	UpperRight upperRight;

	@Element
	LowerLeft lowerLeft;

	@Element
	LowerRight lowerRight;

}
