package jp.co.nec.aim.xml;

import org.simpleframework.xml.Element;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class Soap {
	@Element(required=true)
	String endpoint;
	
	@Element(required=true)
	String callbackUrl;
	
	@Element(required=true)
	String callbackPort;
	
	@Element(required=true)
	boolean outputRequest;
	
	@Element(required=true)
	boolean outputResponse;
	
	@Element(required=false)
	int sleepTimer;
}
