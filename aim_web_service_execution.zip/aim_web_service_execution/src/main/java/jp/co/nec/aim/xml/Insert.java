package jp.co.nec.aim.xml;

import java.util.List;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.ElementList;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class Insert {
	@Element(required=true)
	int binId;
	
	@Element(required=true)
	int eventId;
	
	@ElementList(entry="templateDirectory", type=String.class, inline=true, required=false)
	List<String> templateDirectory;
	
	@Element(required=true)
	String filter;

	@Element(required=false)
	String fingerType;
}
