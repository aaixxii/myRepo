package jp.co.nec.aim.search;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.StringWriter;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

import javax.xml.transform.stream.StreamResult;

import jp.co.nec.aim.client.ProtoCallbackHandler;
import jp.co.nec.aim.client.SoapCallbackHandler;
import jp.co.nec.aim.http.HttpClient;
import jp.co.nec.aim.message.proto.InquiryService;
import jp.co.nec.aim.xml.Proto;
import jp.co.nec.proto.ProtoBuilder;
import lombok.var;
import okhttp3.*;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import com.google.common.base.Stopwatch;
import com.google.common.base.Throwables;
import com.sun.net.httpserver.HttpServer;

import jp.co.nec.aim.FifoQueue;
import jp.co.nec.aim.SendingRequestController;
import jp.co.nec.aim.soap.ObjectFactory;
import jp.co.nec.aim.soap.Search;
import jp.co.nec.aim.soap.SoapBuilder;
import jp.co.nec.aim.soap.SoapClient;
import jp.co.nec.aim.soap.SoapClientConfig;
import jp.co.nec.aim.xml.ParameterReader;
import lombok.val;

@SuppressWarnings("boxing")
public class SearchClient {
    final static Logger logger = LoggerFactory.getLogger(SearchClient.class);

    ExecutorService sendingExecutor_ = Executors.newFixedThreadPool(1);

    Map<String, Pair<AtomicInteger, Stopwatch>> map_ = new ConcurrentHashMap<>(ParameterReader
            .getExtraction().getNumZmqIoThread());

    int numFingerNistFile_ = ParameterReader.getExtraction().getNumFingerNistFile();

    int numFaceFile_ = ParameterReader.getExtraction().getNumFaceFile();

    int numIrisPair_ = ParameterReader.getExtraction().getNumIrisPair();

    int numPalmFile_ = ParameterReader.getExtraction().getNumPalmNistFile();

    final jp.co.nec.aim.xml.Search search_ = ParameterReader.getSearch();

    final Proto proto_ = ParameterReader.getSearch().getProto();

    ConcurrentHashMap<String, Pair<String, Stopwatch>> turnAroundTime_ = new ConcurrentHashMap<>();

    HttpServer httpServer_;

    final FifoQueue<String> jobQIdQueue_ = new FifoQueue<String>();

    final AnnotationConfigApplicationContext appContext_;

    /**
     * @param appContext
     */
    public SearchClient(AnnotationConfigApplicationContext appContext) {
        appContext_ = appContext;
    }

    /**
     * @throws Exception
     */
    public void sendSearchRequestWithSoap()
            throws Exception {
        try {
            val reqContoroller = new SendingRequestController<String>(1);
            val port = search_.getSoap().getCallbackPort();
            httpServer_ = HttpServer.create(new InetSocketAddress(Integer.valueOf(port)), 4);
            httpServer_.createContext("/", new SoapCallbackHandler(appContext_, SoapCallbackHandler.ProcessType.IDENTIFY,
                    reqContoroller, turnAroundTime_, jobQIdQueue_, 0));
            httpServer_.setExecutor(null);
            httpServer_.start();

            val endpoint = new ArrayList<String>();
            ConcurrentHashMap<String, Pair<String, Stopwatch>> turnAroundTime =
                    new ConcurrentHashMap<>();
            sendingExecutor_.submit(new SendingSoapClient(reqContoroller, endpoint, turnAroundTime,
                    jobQIdQueue_, 0/* terminal ID */));

            logger.info("waiting for all threads terminated");

            // receptionExecutor_.shutdown();
            sendingExecutor_.shutdown();
            while (!Thread.currentThread().isInterrupted()) {
                Thread.sleep(1000);
                if (sendingExecutor_.isTerminated()) {
                    break;
                }
            }
            logger.info("stopping the main thread");
        } catch (Exception ex) {
            logger.info(Throwables.getStackTraceAsString(ex));
        } finally {
        }
    }

    /**
     * @throws Exception
     */
    public void sendSearchRequestWithProto()
            throws Exception {
        try {
            val reqContoroller = new SendingRequestController<String>(1);
            val port = search_.getSoap().getCallbackPort();
            httpServer_ = HttpServer.create(new InetSocketAddress(Integer.valueOf(port)), 4);
            httpServer_.createContext("/", new ProtoCallbackHandler(ProtoCallbackHandler.ProcessType.IDENTIFY,
                    reqContoroller, turnAroundTime_, jobQIdQueue_, 0));
            httpServer_.setExecutor(null);
            httpServer_.start();

            val endpoint = new ArrayList<String>();
            ConcurrentHashMap<String, Pair<String, Stopwatch>> turnAroundTime =
                    new ConcurrentHashMap<>();
            sendingExecutor_.submit(new SendingProtoClient(reqContoroller, endpoint, turnAroundTime,
                    jobQIdQueue_, 0/* terminal ID */));

            logger.info("waiting for all threads terminated");

            // receptionExecutor_.shutdown();
            sendingExecutor_.shutdown();
            while (!Thread.currentThread().isInterrupted()) {
                Thread.sleep(1000);
                if (sendingExecutor_.isTerminated()) {
                    break;
                }
            }
            logger.info("stopping the main thread");
        } catch (Exception ex) {
            logger.info(Throwables.getStackTraceAsString(ex));
        } finally {
        }
    }

    /**
     * @return
     * @throws Exception
     */
    private List<Path> getTemplateList()
            throws Exception {
        val list = new ArrayList<Path>();
        try (Stream<Path> stream = Files.list(Paths.get(ParameterReader.getSearch()
                .getTemplatePath()))) {
            stream.filter(path -> path.toFile().isFile()).filter(path -> path.toString().matches(
                    search_.getFilter())).forEach(path -> {
                list.add(path);
            });
        } catch (Exception ex) {
            logger.error(Throwables.getStackTraceAsString(ex));
            throw ex;
        }

        logger.info("the number of capsules : {}", list.size());
        return list;
    }

    /**
     * @author soapui
     */
    class SendingSoapClient extends Thread {
        SendingRequestController<String> reqController_;

        List<String> endpoint_;

        SoapClient client_ = appContext_.getBean(SoapClient.class);

        int terminalId_ = 0;

        ConcurrentHashMap<String, Pair<String, Stopwatch>> turnAroundTime_;

        String templatePath_ = ParameterReader.getSearch().getTemplatePath();

        FifoQueue<String> jobIdQueue_;

        public SendingSoapClient(
                SendingRequestController<String> controller,
                List<String> endPoint,
                ConcurrentHashMap<String, Pair<String, Stopwatch>> turnAroundTime,
                FifoQueue<String> jobIdQueue,
                int terminalId) {
            reqController_ = controller;
            endpoint_ = endPoint;
            turnAroundTime_ = turnAroundTime;
            jobIdQueue_ = jobIdQueue;
            terminalId_ = terminalId;
        }

        @Override
        public void run() {
            val algorithm = ParameterReader.getExtraction().getAlgorithm();

            if (algorithm.equalsIgnoreCase("finger")) {
                processFingerRequest();
            } else if (algorithm.equalsIgnoreCase("s17") || algorithm.equalsIgnoreCase("s18")
                    || algorithm.equalsIgnoreCase("nfv2") || algorithm.equalsIgnoreCase("nfg2")) {
                // processFaceRequest();
            } else if (algorithm.equalsIgnoreCase("niris") || algorithm.equalsIgnoreCase(
                    "delta_id")) {
                // processIrisRequest();
            } else if (algorithm.equalsIgnoreCase("palm")) {
                // processPalmRequest();
            }
        }

        /**
         * @throws Exception
         */
        private void addRequestQueue(String value)
                throws Exception {
            try {
                while (true) {
                    if (reqController_.add(value)) {
                        return;
                    }
                }
            } catch (Exception ex) {
                logger.error(Throwables.getStackTraceAsString(ex));
                throw ex;
            }
        }

        /**
         *
         */
        private void processFingerRequest() {
            try {
                List<Path> paths = getTemplateList();
                val soapBuilder = new SoapBuilder(terminalId_);

                addRequestQueue("start job");

                for (val path : paths) {
                    val fileName = path.toFile().getName();
                    logger.info("Next file is {}.", fileName);

                    Search request = soapBuilder.buildFingerSearch(path);

                    if (search_.getSoap().isOutputRequest()) {
                        output(request);
                    }

                    logger.info("waiting for takeing from queue");
                    String jobId = reqController_.take();
                    logger.info("got job ID:{} from queue", jobId);

                    val stopwatch = Stopwatch.createStarted();
                    jobId = String.valueOf(client_.search(search_.getSoap().getEndpoint(), request)
                            .getReturn());
                    logger.info("got job ID:{}", jobId);
                    jobIdQueue_.add(jobId);

                    turnAroundTime_.put(jobId, Pair.of(fileName, stopwatch));
                }

                logger.info("waiting for takeing from queue");
                val jobId = reqController_.take();
                logger.info("got job ID:{} from queue", jobId);

                sleep(4 * 1000);
            } catch (Exception ex) {
                logger.error(Throwables.getStackTraceAsString(ex));
            } finally {
                httpServer_.stop(0);
            }
            logger.info("stopped a sending thread as {}", Thread.currentThread().getName());
        }

        /**
         *
         */
        private void processPalmRequest() {

            // val nistReader = new NistReader();
            // try {
            // List<Path> paths = getNistType15FileList();
            //
            // val soapBuilder = new SoapBuilder(terminalId_);
            // for (val path : paths) {
            // val fileName = path.toFile().getName();
            // logger.info("Next file is {}.", fileName);
            //
            // SubmitSearchJob request = null;
            // val map =
            // nistReader.getType15Image(path.toAbsolutePath().toString());
            // request = soapBuilder.buildPalmSubmitSearchJob(map, "");
            //
            // if (search_.getSoap().isOutputRequest()) {
            // output(request);
            // }
            //
            // val stopwatch = Stopwatch.createStarted();
            // val jobId =
            // client_.submitSearchJob(search_.getSoap().getEndpoint(), request)
            // .getReturn();
            // turnAroundTime_.put(jobId, Pair.of(fileName, stopwatch));
            //
            // val completedJobId = reqController_.take();
            // logger.info("received {}.", completedJobId);
            // }
            //
            // httpServer_.stop(0);
            // } catch (Exception ex) {
            // logger.error(Throwables.getStackTraceAsString(ex));
            // } finally {
            // // zeroMq.close();
            // }
            // logger.info("stopped a sending thread as {}",
            // Thread.currentThread().getName());
        }

        private void output(Search request) {
            AnnotationConfigApplicationContext appContext = new AnnotationConfigApplicationContext(
                    SoapClientConfig.class);
            ObjectFactory factory = new ObjectFactory();
            StreamResult result = new StreamResult(new StringWriter());
            val marshaller = appContext.getBean(Jaxb2Marshaller.class);
            marshaller.marshal(factory.createSearch(request), result);

            try {
                Files.write(Paths.get("search_request.xml"), result.getWriter().toString()
                        .getBytes());
            } catch (IOException ex) {
                logger.error(Throwables.getRootCause(ex).toString());
            } finally {
                appContext.close();
            }
        }
    }

    class SendingProtoClient extends Thread {
        SendingRequestController<String> reqController_;

        List<String> endpoint_;

        SoapClient client_ = appContext_.getBean(SoapClient.class);

        int terminalId_ = 0;

        ConcurrentHashMap<String, Pair<String, Stopwatch>> turnAroundTime_;

        String templatePath_ = ParameterReader.getSearch().getTemplatePath();

        FifoQueue<String> jobIdQueue_;

        public SendingProtoClient(
                SendingRequestController<String> controller,
                List<String> endPoint,
                ConcurrentHashMap<String, Pair<String, Stopwatch>> turnAroundTime,
                FifoQueue<String> jobIdQueue,
                int terminalId) {
            reqController_ = controller;
            endpoint_ = endPoint;
            turnAroundTime_ = turnAroundTime;
            jobIdQueue_ = jobIdQueue;
            terminalId_ = terminalId;
        }

        @Override
        public void run() {
            val algorithm = ParameterReader.getExtraction().getAlgorithm();

            if (algorithm.equalsIgnoreCase("finger")) {
                processFingerRequest();
            } else if (algorithm.equalsIgnoreCase("s17") || algorithm.equalsIgnoreCase("s18")
                    || algorithm.equalsIgnoreCase("nfv2") || algorithm.equalsIgnoreCase("nfg2")) {
                // processFaceRequest();
            } else if (algorithm.equalsIgnoreCase("niris") || algorithm.equalsIgnoreCase(
                    "delta_id")) {
                // processIrisRequest();
            } else if (algorithm.equalsIgnoreCase("palm")) {
                // processPalmRequest();
            }
        }

        /**
         * @throws Exception
         */
        private void addRequestQueue(String value)
                throws Exception {
            try {
                while (true) {
                    if (reqController_.add(value)) {
                        return;
                    }
                }
            } catch (Exception ex) {
                logger.error(Throwables.getStackTraceAsString(ex));
                throw ex;
            }
        }

        /**
         *
         */
        private void processFingerRequest() {
            try {
                List<Path> paths = getTemplateList();
                val soapBuilder = new ProtoBuilder(terminalId_);

                addRequestQueue("start job");

                for (val path : paths) {
                    val fileName = path.toFile().getName();
                    logger.info("Next file is {}.", fileName);

                    var request = soapBuilder.buildFingerInquiryJobRequest(path);

                    if (search_.getSoap().isOutputRequest()) {
                        output(request);
                    }

                    logger.info("waiting for takeing from queue");
                    String jobId = reqController_.take();
                    logger.info("got job ID:{} from queue", jobId);

                    val stopwatch = Stopwatch.createStarted();

                    var response = HttpClient.post(request);
                    if (!response.isPresent()) {
                        logger.error("response data did not exit.");
                        continue;
                    }
                    jobId = String.valueOf(response.get().getJobId());

                    logger.info("got job ID:{}", jobId);
                    jobIdQueue_.add(jobId);

                    turnAroundTime_.put(jobId, Pair.of(fileName, stopwatch));
                }

                logger.info("waiting for takeing from queue");
                val jobId = reqController_.take();
                logger.info("got job ID:{} from queue", jobId);

                sleep(4 * 1000);
            } catch (Exception ex) {
                logger.error(Throwables.getStackTraceAsString(ex));
            } finally {
                httpServer_.stop(0);
            }
            logger.info("stopped a sending thread as {}", Thread.currentThread().getName());
        }

        /**
         *
         */
        private void processPalmRequest() {

            // val nistReader = new NistReader();
            // try {
            // List<Path> paths = getNistType15FileList();
            //
            // val soapBuilder = new SoapBuilder(terminalId_);
            // for (val path : paths) {
            // val fileName = path.toFile().getName();
            // logger.info("Next file is {}.", fileName);
            //
            // SubmitSearchJob request = null;
            // val map =
            // nistReader.getType15Image(path.toAbsolutePath().toString());
            // request = soapBuilder.buildPalmSubmitSearchJob(map, "");
            //
            // if (search_.getSoap().isOutputRequest()) {
            // output(request);
            // }
            //
            // val stopwatch = Stopwatch.createStarted();
            // val jobId =
            // client_.submitSearchJob(search_.getSoap().getEndpoint(), request)
            // .getReturn();
            // turnAroundTime_.put(jobId, Pair.of(fileName, stopwatch));
            //
            // val completedJobId = reqController_.take();
            // logger.info("received {}.", completedJobId);
            // }
            //
            // httpServer_.stop(0);
            // } catch (Exception ex) {
            // logger.error(Throwables.getStackTraceAsString(ex));
            // } finally {
            // // zeroMq.close();
            // }
            // logger.info("stopped a sending thread as {}",
            // Thread.currentThread().getName());
        }

        /**
         * @param request
         */
        private void output(InquiryService.PBInquiryJobRequest request) {
            try (BufferedWriter writer = Files.newBufferedWriter(Paths.get("search_request.txt"), StandardCharsets.UTF_8)) {
                writer.write(request.toString());
            } catch (IOException ex) {
                logger.error(Throwables.getRootCause(ex).toString());
            } finally {
            }
        }
    }

}
