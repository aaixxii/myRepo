package jp.co.nec.aim.xml;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import org.simpleframework.xml.Serializer;
import org.simpleframework.xml.core.Persister;

import com.google.common.base.Throwables;

public class ParameterReader {
	static Parameter parameter_;
	/**
	 * 
	 */
	public static void readParameter(String path)
		throws Exception {
		try (InputStream inputStream = new FileInputStream(new File(path))) {
			Serializer serializer = new Persister();
			parameter_ = serializer.read(Parameter.class, inputStream);
		} catch (Exception ex) {
			System.out.println(Throwables.getStackTraceAsString(ex));
			throw ex;
		}
	}

	public static Sync getSync() {
		return parameter_.getSync();
	}
	
	public static Search getSearch() {
		return parameter_.getSearch();
	}
	
	public static Extraction getExtraction() {
		return parameter_.getExtraction();
	}
	
	public static Verification getVerification() {
		return parameter_.getVerification();
	}

	public static Validation getValidation() {
		return parameter_.getValidation();
	}
}
