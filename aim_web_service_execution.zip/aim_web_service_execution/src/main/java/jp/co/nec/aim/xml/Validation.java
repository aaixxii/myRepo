package jp.co.nec.aim.xml;

import org.simpleframework.xml.Element;

import lombok.Data;

@Data
public class Validation {
	@Element
	int sleepTimer;
	@Element
	boolean outputRequest;
	
	@Element
	boolean outputResponse;
	
	@Element
	String managementPort;
	
	@Element
	String jobPort;
	
	@Element
	int numCapsule;
	
	@Element
	String capsulePath;
}
