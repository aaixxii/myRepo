package jp.co.nec.aim.xml;

import org.simpleframework.xml.Element;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class NeoFace {
	@Element(required=false)
	String maxFaces;
	
	@Element(required=false)
	String detectionOnly;
	
	@Element(required=false)
	String padHeightPercent;
	
	@Element(required=false)
	String padWidthPercent;
	
	@Element(required=false)
	String padByte;
	
	@Element(required=false)
	String algorithm;
	
	@Element(required=false)
	String reliability;
	
	@Element(required=false)
	String minEyeDist;
	
	@Element(required=false)
	String maxEyeDist;
	
	@Element(required=false)
	String enableG2Attributes;
	
	@Element(required=false)
	String enableV3Attributes;
	
	@Element
	String enableEeyPosition;
	
	@Element
	RightEye rightEye;
	
	@Element
	LeftEye leftEye;
	
	@Element(required=false)
	String shrinkFactor;
	
	@Element(required=false)
	String eyeRoll;
}
