package jp.co.nec.aim.xml;

import org.simpleframework.xml.Element;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class Center {
	@Element
	int x;
	
	@Element
	int y;
}
