package jp.co.nec.aim.client;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.concurrent.ConcurrentHashMap;

import javax.xml.bind.JAXB;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.google.common.base.Stopwatch;
import com.google.common.base.Throwables;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import jp.co.nec.aim.FifoQueue;
import jp.co.nec.aim.SendingRequestController;
import jp.co.nec.aim.soap.ExtractJobResult;
import jp.co.nec.aim.soap.GetExtractJobBinary;
import jp.co.nec.aim.soap.SoapClient;
import jp.co.nec.aim.xml.Extraction;
import jp.co.nec.aim.xml.ParameterReader;
import jp.co.nec.aim.xml.Sync;
import jp.co.nec.aim.xml.Verification;
import lombok.val;

public class SoapCallbackHandler implements HttpHandler {
	final static Logger logger = LoggerFactory.getLogger(SoapCallbackHandler.class);

	final AnnotationConfigApplicationContext appContext_;

	SendingRequestController<String> reqController_;

	Path buffXml_;

	// key is job ID and value is NIST file name
	ConcurrentHashMap<String, Pair<String, Stopwatch>> turnAroundTime_;

	final Extraction extraction_ = ParameterReader.getExtraction();

	final jp.co.nec.aim.xml.Search search_ = ParameterReader.getSearch();

	final Verification verification_ = ParameterReader.getVerification();

	final Sync sync_ = ParameterReader.getSync();

	Path performancePath_;

	Path candidatePath_;

	Path rankPath_;

	int terminalId_;

	int index_;

	public enum ProcessType {
		VERIFICATION, EXTRACATION, IDENTIFY, SYNC, CALLBACKTEST
	};

	ProcessType processType_;

	FifoQueue<String> jobIdQueue_;

	SoapClient client_;

	public SoapCallbackHandler(
		AnnotationConfigApplicationContext appContext,
		ProcessType processType,
		SendingRequestController<String> reqController,
		ConcurrentHashMap<String, Pair<String, Stopwatch>> turnAroundTime,
		FifoQueue<String> jobIdQueue,
		int terminalId) {
		appContext_ = appContext;
		processType_ = processType;
		reqController_ = reqController;
		turnAroundTime_ = turnAroundTime;
		jobIdQueue_ = jobIdQueue;
		terminalId_ = terminalId;

		client_ = appContext_.getBean(SoapClient.class);

		try {
			if (!Files.exists(Paths.get("/dev/shm/unmarshal"))) {
				Files.createDirectory(Paths.get("/dev/shm/unmarshal"));
			}
		} catch (IOException ex) {
			logger.error(Throwables.getRootCause(ex).toString());
		}

		if (processType_ == ProcessType.EXTRACATION) {
			{
				val builder = new StringBuilder("/dev/shm/unmarshal/extract_job_result_").append(
					terminalId_).append(".xml");
				buffXml_ = Paths.get(builder.toString());
			}
			{
				val builder = new StringBuilder("./extraction_TAT_").append(terminalId_).append(
					".txt");
				performancePath_ = Paths.get(builder.toString());

				try {
					Files.deleteIfExists(performancePath_);
					Files.createFile(performancePath_);
				} catch (IOException ex) {
					logger.error(Throwables.getRootCause(ex).toString());
				}
			}
		} else if (processType_ == ProcessType.SYNC) {
			{
				val builder = new StringBuilder("/dev/shm/unmarshal/SyncJobResult_").append(
					terminalId_).append(".xml");
				buffXml_ = Paths.get(builder.toString());
			}

			performancePath_ = Paths.get("./sync_TAT.txt");
			try {
				Files.deleteIfExists(performancePath_);
				Files.createFile(performancePath_);
			} catch (IOException ex) {
				logger.error(Throwables.getRootCause(ex).toString());
			}
		} else if (processType_ == ProcessType.IDENTIFY) {
			{
				val builder = new StringBuilder("/dev/shm/unmarshal/SearchJobResult_").append(
					terminalId_).append(".xml");
				buffXml_ = Paths.get(builder.toString());
			}

			performancePath_ = Paths.get("./identify_TAT.txt");
			try {
				Files.deleteIfExists(performancePath_);
				Files.createFile(performancePath_);
			} catch (IOException ex) {
				logger.error(Throwables.getRootCause(ex).toString());
			}

			{
				val builderPath = new StringBuilder("./rank_").append(terminalId_).append(".csv");
				try {
					Files.deleteIfExists(Paths.get(builderPath.toString()));
					Files.createFile(Paths.get(builderPath.toString()));
					rankPath_ = Paths.get(builderPath.toString());
				} catch (IOException ex) {
					logger.error(Throwables.getRootCause(ex).toString());
				}
			}

			{
				val builderPath = new StringBuilder("./candidate_").append(terminalId_).append(
					".csv");
				try {
					Files.deleteIfExists(Paths.get(builderPath.toString()));
					Files.createFile(Paths.get(builderPath.toString()));
					candidatePath_ = Paths.get(builderPath.toString());
				} catch (IOException ex) {
					logger.error(Throwables.getRootCause(ex).toString());
				}
			}
		} else if (processType_ == ProcessType.VERIFICATION) {
			// {
			// val builder = new
			// StringBuilder("/dev/shm/unmarshal/VerificationJobResult_").append(
			// terminalId_).append(".xml");
			// buffXml_ = Paths.get(builder.toString());
			// }
			//
			// performancePath_ = Paths.get("./verification_TAT.txt");
			// try {
			// Files.deleteIfExists(performancePath_);
			// Files.createFile(performancePath_);
			// } catch (IOException ex) {
			// logger.error(Throwables.getRootCause(ex).toString());
			// }
		} else if (processType_ == ProcessType.CALLBACKTEST) {
			val builder = new StringBuilder("/dev/shm/unmarshal/callbacktest_response_").append(
				terminalId_).append(".xml");
			buffXml_ = Paths.get(builder.toString());
		}
	}

	@Override
	public void handle(HttpExchange exchange)
		throws IOException {
		String body = IOUtils.toString(exchange.getRequestBody(), "utf-8");
		logger.info("received");

		try {
			Files.write(buffXml_, body.getBytes());
			if (processType_ == ProcessType.EXTRACATION) {
				processExtraction(body);
			} else if (processType_ == ProcessType.VERIFICATION) {
				// processVerification(body);
			} else if (processType_ == ProcessType.SYNC) {
				processSync(body);
			} else if (processType_ == ProcessType.IDENTIFY) {
				processSearch(body);
			} else if (processType_ == ProcessType.CALLBACKTEST) {
				processCallbackTest(body);
			}
		} catch (Exception ex) {
			logger.error(Throwables.getRootCause(ex).toString());
		} finally {
			String message = "Ok";
			exchange.sendResponseHeaders(200, message.length());
			val os = exchange.getResponseBody();
			os.write(message.getBytes());
			os.close();

			logger.info("send response");
		}
	}

	private void addRequestQueue(String str)
		throws Exception {
		try {
			while (true) {
				if (reqController_.add(str)) {
					return;
				}
			}
		} catch (Exception ex) {
			logger.error(Throwables.getStackTraceAsString(ex));
			throw ex;
		}
	}

	private void processCallbackTest(String body)
		throws IOException {
		if (extraction_.getSoap().isOutputResponse()) {
			val builder = new StringBuilder("./callbacktest_response_").append(terminalId_).append(
				"_").append(index_++).append(".xml");
			Files.write(Paths.get(builder.toString()), body.getBytes());
		}
	}

	private void processExtraction(String body)
		throws IOException {
		if (extraction_.getSoap().isOutputResponse()) {
			val builder = new StringBuilder("./extract_result_").append(terminalId_).append("_")
				.append(index_++).append(".xml");
			Files.write(Paths.get(builder.toString()), body.getBytes());
		}

		try {
			val jobId = jobIdQueue_.take();

			val obj = JAXB.unmarshal(buffXml_.toFile(), ExtractJobResult.class);
			val keyedBinaries = obj.getKeyedBinary();

			val request = new GetExtractJobBinary();
			request.setJobId(Long.valueOf(jobId));
			for (val keyedBinary : keyedBinaries) {
				request.setKey(keyedBinary.getKey());
				val response = client_.getExtractJobBinary(extraction_.getSoap().getEndpoint(),
					request);
				StringBuilder name = new StringBuilder(extraction_.getOutputTemplatePath()).append(
					"/").append(turnAroundTime_.get(jobId).getLeft()).append("_-_").append(
						keyedBinary.getKey()).append(".bin");
				Files.write(Paths.get(name.toString()), response.getReturn(),
					StandardOpenOption.CREATE);
			}

			addRequestQueue(jobId);
		} catch (Exception ex) {
			logger.error(Throwables.getRootCause(ex).toString());
		}
	}

	private void processSearch(String body)
		throws IOException {
		if (search_.getSoap().isOutputResponse()) {
			val builder = new StringBuilder("./search_job_result_").append(terminalId_).append("_")
				.append(index_).append(".xml");
			Files.write(Paths.get(builder.toString()), body.getBytes());
		}

		try {
			val jobId = jobIdQueue_.take();

//			val obj = JAXB.unmarshal(buffXml_.toFile(), SearchJobResult.class);
//			val request = new GetSearchJobResult();
//			request.setJobId(Long.valueOf(jobId));
//			val response = client_.getSearchJobResult(extraction_.getSoap().getEndpoint(), request);
			// Files.write(candidatePath_, response.getReturn(),
			// StandardOpenOption.CREATE);

			// val builder = new StringBuilder();
			// builder.append(buff.getLeft()).append(",").append(tat).append("\n");
			// Files.write(performancePath_, builder.toString().getBytes(),
			// StandardOpenOption.APPEND);
			//
			// addRequestQueue(obj.getJobId());
			//
			// outputCandidate(buff.getLeft(), obj);
			// outputRank(buff.getLeft(), obj);
			addRequestQueue(jobId);
			index_++;
		} catch (Exception ex) {
			logger.error(Throwables.getRootCause(ex).toString());
		}
	}

	// private void processVerification(String body)
	// throws IOException {
	// if (verification_.getSoap().isOutputResponse()) {
	// val builder = new
	// StringBuilder("./VerificationJobResult_").append(terminalId_).append(
	// "_").append(index_).append(".xml");
	// Files.write(Paths.get(builder.toString()), body.getBytes());
	// }
	//
	// try {
	// val obj = JAXB.unmarshal(buffXml_.toFile(), VerifyJobResultDto.class);
	//
	// while (true) {
	// if (!turnAroundTime_.containsKey(obj.getJobId())) {
	// logger.error("job ID({}) not exist. waiting for a second.",
	// obj.getJobId());
	// Thread.sleep(200);
	// continue;
	// }
	// break;
	// }
	// val buff = turnAroundTime_.get(obj.getJobId());
	// val tat = buff.getRight().elapsed(TimeUnit.MILLISECONDS);
	//
	// logger.info("job ID, {} which is got from VerifyJobResultDto",
	// obj.getJobId());
	//
	// val builder = new StringBuilder();
	// builder.append(buff.getLeft()).append(",").append(tat).append("\n");
	// Files.write(performancePath_, builder.toString().getBytes(),
	// StandardOpenOption.APPEND);
	//
	// addRequestQueue(obj.getJobId());
	//
	// // outputCandidate(buff.getLeft(), obj);
	// // outputRank(buff.getLeft(), obj);
	//
	// index_++;
	// } catch (Exception ex) {
	// logger.error(Throwables.getRootCause(ex).toString());
	// }
	// }

	private void processSync(String body)
		throws IOException {
		if (sync_.getSoap().isOutputResponse()) {
			Files.write(Paths.get("./sync_result.xml"), body.getBytes());
		}

		try {
//			val obj = JAXB.unmarshal(buffXml_.toFile(), SyncJobResultDto.class);
//
//			while (true) {
//				if (!turnAroundTime_.containsKey(obj.getJobId())) {
//					logger.error("job ID({}) not exist. waiting for a second.", obj.getJobId());
//					Thread.sleep(200);
//					continue;
//				}
//				break;
//			}
//
//			val buff = turnAroundTime_.get(obj.getJobId());
//			val tat = buff.getRight().elapsed(TimeUnit.MILLISECONDS);
//
//			logger.info("job ID, {} which is got from SyncJobResultDto", obj.getJobId());
//
//			val builder = new StringBuilder();
//			builder.append(buff.getLeft()).append(",").append(tat).append("\n");
//			Files.write(performancePath_, builder.toString().getBytes(), StandardOpenOption.APPEND);
//
//			addRequestQueue(obj.getJobId());
		} catch (Exception ex) {
			logger.error(Throwables.getRootCause(ex).toString());
		}
	}

	// private void outputCandidate(String fileName, SearchJobResultDto
	// searchJobResultDto)
	// throws IOException {
	// if (searchJobResultDto.getCandidateResultList() == null ||
	// searchJobResultDto
	// .getCandidateResultList().size() == 0) {
	// return;
	// }
	//
	// // file name example is SD27P.300.02.raw_BT5_ROI.TEMPLATE_TYPE_44.bin
	// val index = fileName.lastIndexOf(".TEMP");
	// val externalId = fileName.substring(0, index);
	//
	// // query external ID, target external ID, score, bin ID, position
	// int rank = 1;
	// for (val candidate : searchJobResultDto.getCandidateResultList()) {
	// val builderCandidate = new StringBuilder(externalId);
	// builderCandidate.append(",").append(candidate.getExternalId()).append(",").append(
	// candidate.getScore()).append(",").append(rank++).append("\n");
	//
	// Files.write(candidatePath_, builderCandidate.toString().getBytes(),
	// StandardOpenOption.APPEND);
	// }
	// }

	// private void outputRank(String fileName, SearchJobResultDto
	// searchJobResultDto)
	// throws IOException {
	// val externalId = fileName.substring(0, fileName.lastIndexOf(".TEMP"));
	// val key = externalId.substring(0, externalId.indexOf("_"));
	// logger.info("key:{}", key);
	//
	// if (searchJobResultDto.getCandidateResultList() == null ||
	// searchJobResultDto
	// .getCandidateResultList().size() == 0) {
	// val builderRank = new StringBuilder(externalId);
	// builderRank.append(",").append(-2).append("\n");
	// Files.write(rankPath_, builderRank.toString().getBytes(),
	// StandardOpenOption.APPEND);
	// return;
	// }
	//
	// // query external ID, rank
	// int rank = 1;
	// int score = -1;
	// for (val candidate : searchJobResultDto.getCandidateResultList()) {
	// if (!candidate.getExternalId().contains(key)) {
	// ++rank;
	// continue;
	// }
	// score = candidate.getScore();
	// break;
	// }
	//
	// if (rank == searchJobResultDto.getCandidateResultList().size() + 1) {
	// rank = -1;
	// }
	//
	// val builderRank = new StringBuilder(externalId);
	// builderRank.append(",").append(rank).append(",").append(score).append("\n");
	// Files.write(rankPath_, builderRank.toString().getBytes(),
	// StandardOpenOption.APPEND);
	// }

}
