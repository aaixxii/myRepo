package jp.co.nec.aim;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.tuple.Pair;

import com.google.common.base.Stopwatch;

public class SendingRequestController<T> {
	BlockingQueue<T> queue_;

	/**
	 * 
	 * @param capacity
	 */
	public SendingRequestController(int capacity) {
		queue_ = new ArrayBlockingQueue<T>(capacity, false);
	}

	/**
	 * 
	 * @param value
	 * @return
	 * @throws Exception
	 */
	public boolean add(T value)
		throws Exception {
		try {
			queue_.add(value);
		} catch (IllegalStateException ex) {
			return false;
		}
		return true;
	}

	/**
	 * 
	 * @param timeout
	 * @return
	 * @throws Exception
	 */
	public T poll(int timeout)
		throws Exception {
		return queue_.poll(timeout, TimeUnit.SECONDS);
	}

	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	public T take()
		throws Exception {
		return queue_.take();
	}
}
