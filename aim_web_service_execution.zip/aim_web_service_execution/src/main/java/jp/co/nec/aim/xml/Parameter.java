package jp.co.nec.aim.xml;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Root
@Data
public class Parameter {
	@Element
	Sync sync;
	
	@Element
	Search search;
	
	@Element
	Validation validation;

	@Element
	Extraction extraction;
	
	@Element
	Verification verification;

}
