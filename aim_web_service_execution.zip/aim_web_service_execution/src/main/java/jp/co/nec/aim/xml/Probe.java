package jp.co.nec.aim.xml;

import org.simpleframework.xml.Element;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class Probe {
	@Element(required=true)
	String candidateId;

	@Element(required=true)
	int containerId;

	@Element(required=false)
	String capsuleType;

	@Element
	int numNistFile;

	@Element
	String faceCapsulePath;
	
	@Element
	String fingerCapsulePath;

	@Element
	String palmCapsulePath;

	@Element
	ElftProbe elftProbe;
	
	@Element
	int numIrisFile;
	
	@Element
	String irisPath;
	
	@Element
	int numFaceFile;
	
	@Element
	String facePath;
	
	@Element
	int nistType;
	
	@Element
	String nistType14Path;

	@Element
	String nistType4Path;

	@Element
	String nistType15Path;

}
