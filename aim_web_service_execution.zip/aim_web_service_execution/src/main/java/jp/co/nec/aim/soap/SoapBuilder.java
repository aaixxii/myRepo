package jp.co.nec.aim.soap;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.xml.bind.JAXB;
import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.dom.DOMResult;

import org.apache.commons.lang3.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;

import com.google.common.base.Splitter;
import com.google.common.base.Throwables;

import jp.co.nec.aim.soap.AimFormats;
import jp.co.nec.aim.soap.CommonOptions;
import jp.co.nec.aim.soap.Delete;
import jp.co.nec.aim.soap.ExtInput;
import jp.co.nec.aim.soap.Extract;
import jp.co.nec.aim.soap.GenderEnum;
import jp.co.nec.aim.soap.InputImage;
import jp.co.nec.aim.soap.Insert;
import jp.co.nec.aim.soap.LatentInput;
import jp.co.nec.aim.soap.MetaInfo;
import jp.co.nec.aim.soap.ObjectFactory;
import jp.co.nec.aim.soap.Record;
import jp.co.nec.aim.soap.Search;
import jp.co.nec.aim.soap.TenprintInput;
import jp.co.nec.aim.xml.Extraction;
import jp.co.nec.aim.xml.ParameterReader;
import jp.co.nec.aim.xml.Sync;
import jp.co.nec.aim.xml.Verification;
import lombok.val;

enum GenerationMode {
	TENPRINT_EXTRACTION, LATENT_EXTRACTION, VERIFICATION_PROBE, VERIFICATION_GALLERY,
}

@SuppressWarnings({
	"boxing", "unchecked", "rawtypes"
})
public class SoapBuilder {
	final static Logger logger = LoggerFactory.getLogger(SoapBuilder.class);

	final ObjectFactory factory_ = new ObjectFactory();

	final Extraction extraction_ = ParameterReader.getExtraction();

	final Verification verification_ = ParameterReader.getVerification();

	final Sync sync_ = ParameterReader.getSync();

	final jp.co.nec.aim.xml.Search search_ = ParameterReader.getSearch();

	String searchCallback_;

	String syncCallback_;

	String extractionCallback_;

	String verificationCallback_;

	GenerationMode generationMode_;

	int terminalId_;

	// final Map<String, ImagePosition> positionMap_ = new HashMap() {
	// private static final long serialVersionUID = 1L;
	// {
	// put("0", 0);
	// put("1", 1);
	// put("2", 2);
	// put("3", 3);
	// put("4", 4);
	// put("5", 5);
	// put("6", 6);
	// put("7", 7);
	// put("8", 8);
	// put("9", 9);
	// put("10", 10);
	// put("11", 11);
	// put("12", 12);
	// put("13", 13);
	// put("14", 14);
	// put("15", 15);
	// put("40", 40);
	// put("41", 41);
	// put("42", 42);
	// put("43", 43);
	// put("44", 44);
	// put("45", 45);
	// put("46", 46);
	// put("47", 47);
	// put("20", 20);
	// put("21", 21);
	// put("22", 22);
	// put("23", 23);
	// put("24", 24);
	// put("25", 25);
	// put("26", 26);
	// put("27", 27);
	// put("28", 28);
	// put("31", 31);
	// put("32", 32);
	// put("33", 33);
	// put("34", 34);
	// put("35", 35);
	// put("36", 36);
	// }
	// };

	final Map<String, String> encodedMap_ = new HashMap() {
		private static final long serialVersionUID = 1L;
		{
			put("RAW", "0");
			put("WSQ", "1");
			put("J2K", "2");
			put("JPG", "3");
			put("BMP", "4");
			put("PNG", "5");
		}
	};

	public SoapBuilder(int terminalId) {
		terminalId_ = terminalId;
		StringBuilder searchBuilder = new StringBuilder(search_.getSoap().getCallbackUrl());
		searchCallback_ = searchBuilder.append(":").append(Integer.valueOf(search_.getSoap()
			.getCallbackPort()) + terminalId_).toString();
		StringBuilder syncBuilder = new StringBuilder(sync_.getSoap().getCallbackUrl());
		syncCallback_ = syncBuilder.append(":").append(Integer.valueOf(sync_.getSoap()
			.getCallbackPort()) + terminalId_).toString();
		StringBuilder extractionBuilder = new StringBuilder(extraction_.getSoap().getCallbackUrl());
		extractionCallback_ = extractionBuilder.append(":").append(Integer.valueOf(extraction_
			.getSoap().getCallbackPort()) + terminalId_).toString();
		StringBuilder verificationBuilder = new StringBuilder(verification_.getSoap()
			.getCallbackUrl());
		verificationCallback_ = verificationBuilder.append(":").append(Integer.valueOf(verification_
			.getSoap().getCallbackPort()) + terminalId_).toString();

		logger.info("searchCallback_:{}", searchCallback_);
		logger.info("syncCallback_:{}", syncCallback_);
		logger.info("extractionCallback_:{}", extractionCallback_);
		logger.info("verificationCallback_:{}", verificationCallback_);
	}

	public Extract buildFingerExtract(
		Map<Integer, jp.co.nec.aim.nistpack.Image> images,
		String externalId)
		throws ParserConfigurationException {
		generationMode_ = GenerationMode.TENPRINT_EXTRACTION;

		val extInput = factory_.createExtInput();
		extInput.setTenprintInput(buildTenprintInput(images));

		Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
		JAXB.marshal(new JAXBElement<ExtInput>(new QName("ext-input"), ExtInput.class, extInput),
			new DOMResult(document));
		val dynamicXml = factory_.createDynamicXml();
		dynamicXml.setAny(document.getDocumentElement());

		val extractionInputs = factory_.createExtractExtractionInputs();
		extractionInputs.setPriority(3);
		extractionInputs.setCallbackURL(extractionCallback_);
		extractionInputs.setExtractionInputsPayload(dynamicXml);

		val extract = factory_.createExtract();
		extract.setExtractionInputs(extractionInputs);
		return extract;
	}

	public Extract buildLatentFingerExtract(
		jp.co.nec.aim.nistpack.Image image,
		String externalId)
		throws ParserConfigurationException {
		generationMode_ = GenerationMode.TENPRINT_EXTRACTION;

		val extInput = factory_.createExtInput();
		extInput.setLatentInput(buildLatentInput(image));

		Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
		JAXB.marshal(new JAXBElement<ExtInput>(new QName("ext-input"), ExtInput.class, extInput),
			new DOMResult(document));
		val dynamicXml = factory_.createDynamicXml();
		dynamicXml.setAny(document.getDocumentElement());

		val extractionInputs = factory_.createExtractExtractionInputs();
		extractionInputs.setPriority(3);
		extractionInputs.setCallbackURL(extractionCallback_);
		extractionInputs.setExtractionInputsPayload(dynamicXml);

		val extract = factory_.createExtract();
		extract.setExtractionInputs(extractionInputs);
		return extract;
	}

	public Insert buildInsert(String externalId, int eventId, Path templatePath, int binId)
		throws IOException {
		val record = factory_.createRecord();
		record.setBinary(Files.readAllBytes(templatePath));

		val reqs = factory_.createInsertReqs();
		reqs.setDestinationContainer(binId);
		reqs.setRecord(record);

		val insert = factory_.createInsert();
		insert.setExternalId(externalId);
		insert.setEventId(eventId);
		insert.getReqs().add(reqs);
		return insert;
	}

	public Search buildFingerSearch(Path templatePath)
		throws ParserConfigurationException, IOException {
		val searchRequest = factory_.createSearchSearchRequests();
		searchRequest.setFunctionName(search_.getFunction());
		searchRequest.setRecord(buildRecord(templatePath));

		val containers = Splitter.on(",").trimResults().split(ParameterReader.getSearch()
			.getContainer());
		for (val container : containers) {
			searchRequest.getSearchContainer().add(Integer.valueOf(container));
		}

		val search = factory_.createSearch();
		search.getSearchRequests().add(searchRequest);
		search.setCommonOptions(buildCommonOptions());
		return search;
	}

	private Record buildRecord(Path templatePath)
		throws IOException {
		val record = factory_.createRecord();
		record.setBinary(Files.readAllBytes(templatePath));
		return record;
	}

	private CommonOptions buildCommonOptions() {
		val commonOptions = factory_.createCommonOptions();
		val buff = new StringBuffer(search_.getSoap().getCallbackUrl()).append(":").append(search_
			.getSoap().getCallbackPort());
		commonOptions.setCallbackURL(buff.toString());
		commonOptions.setConsolidateByContainer(search_.isConsolidateByContainer());
		commonOptions.setMaxCandidates(search_.getMaxCandidates());
		commonOptions.setMinScore(search_.getMaxCandidates());
		commonOptions.setMultiRecordCandidates(search_.isMultiRecordCandidates());
		commonOptions.setPriority(search_.getPriority());
		return commonOptions;
	}

	// public SubmitExtractionJob buildLatentFingerSubmitExtractionJob(
	// Triple<Path, Path, Path> triplePath,
	// String externalId)
	// throws IOException {
	// generationMode_ = GenerationMode.EXTRACTION;
	// val inputImage = factory_.createTemplateExtractInputImage();
	// inputImage.setExtractInputImage(buildLatentFingerExtractInputImage(triplePath));
	//
	// val capsuleTypes =
	// Splitter.on(",").trimResults().split(ParameterReader.getExtraction()
	// .getCapsuleType());
	// for (val capsuleType : capsuleTypes) {
	// inputImage.getTemplateTypes().add("TEMPLATE_TYPE_" + capsuleType);
	// }
	//
	// val payload = factory_.createExtractInputPayloadDto();
	// payload.getTemplateExtractInputImageList().add(inputImage);
	// payload.setCandidateId(externalId);
	//
	// val requset = factory_.createExtractJobRequestDto();
	// requset.setExtractInputPayload(payload);
	// requset.setCallbackUrl(extractionCallback_);
	// requset.setJobTimeoutMill(120000L);
	// requset.setJobMode("live");
	// requset.setPriority(10);
	//
	// val job = new SubmitExtractionJob();
	// job.setArg0(requset);
	// return job;
	// }

	/**
	 * palm
	 * 
	 * @param image
	 * @return
	 */
	// public SubmitExtractionJob buildPalmSubmitExtractionJob(
	// Map<Integer, jp.co.nec.aim_xm.nistpack.Image> image) {
	// val buff = factory_.createTemplateExtractInputImage();
	// generationMode_ = GenerationMode.EXTRACTION;
	// buff.setExtractInputImage(buildPalmExtractInputImage(image));
	//
	// val capsuleTypes =
	// Splitter.on(",").trimResults().split(ParameterReader.getExtraction()
	// .getCapsuleType());
	// for (val capsuleType : capsuleTypes) {
	// buff.getTemplateTypes().add("TEMPLATE_TYPE_" + capsuleType);
	// }
	//
	// val payload = factory_.createExtractInputPayloadDto();
	// payload.getTemplateExtractInputImageList().add(buff);
	//
	// val requset = factory_.createExtractJobRequestDto();
	// requset.setExtractInputPayload(payload);
	// requset.setCallbackUrl(extractionCallback_);
	// requset.setJobTimeoutMill(120000L);
	// requset.setJobMode("live");
	// requset.setPriority(10);
	//
	// val job = new SubmitExtractionJob();
	// job.setArg0(requset);
	// return job;
	// }

	/**
	 * palm
	 * 
	 * @param image
	 * @return
	 */
	// public SubmitExtractionJob buildIrisSubmitExtractionJob(Pair<Path, Path>
	// image) {
	// val buff = factory_.createTemplateExtractInputImage();
	// buff.setExtractInputImage(buildIrisExtractInputImage(image));
	//
	// val capsuleTypes =
	// Splitter.on(",").trimResults().split(ParameterReader.getExtraction()
	// .getCapsuleType());
	// for (val capsuleType : capsuleTypes) {
	// buff.getTemplateTypes().add("TEMPLATE_TYPE_" + capsuleType);
	// }
	//
	// val payload = factory_.createExtractInputPayloadDto();
	// payload.getTemplateExtractInputImageList().add(buff);
	//
	// val requset = factory_.createExtractJobRequestDto();
	// requset.setExtractInputPayload(payload);
	// requset.setCallbackUrl(extractionCallback_);
	// requset.setJobTimeoutMill(120000L);
	// requset.setJobMode("live");
	// requset.setPriority(10);
	//
	// val job = new SubmitExtractionJob();
	// job.setArg0(requset);
	// return job;
	// }

	/**
	 * 
	 * @param images
	 * @return
	 */
	private TenprintInput buildTenprintInput(Map<Integer, jp.co.nec.aim.nistpack.Image> images) {
		val tenprintInput = factory_.createTenprintInput();
		tenprintInput.setAimformats(buildAimFormats());
		tenprintInput.setImages(buildImages(images));
		tenprintInput.setMetaInfo(buildMetaInfo());
		// outut templates and all extraction data.
		tenprintInput.setExtInfoMode(0);
		tenprintInput.setReturnCroppedImages(true);

		val cmlExtOptions = factory_.createCmlExtOptions();
		cmlExtOptions.setParameterId(ParameterReader.getExtraction().getCmlOption());
		tenprintInput.setCmlExtOptions(cmlExtOptions);

		return tenprintInput;
	}

	private LatentInput buildLatentInput(jp.co.nec.aim.nistpack.Image image) {
		val latentInput = factory_.createLatentInput();
		latentInput.setAimformats(buildAimFormats());
		latentInput.setImages(buildImages(image));
		latentInput.setMetaInfo(buildMetaInfo());
		// outut templates and all extraction data.
		latentInput.setExtInfoMode(0);
		return latentInput;
	}

	private MetaInfo buildMetaInfo() {
		val metaCommon = factory_.createMetaInfoMetaCommon();
		metaCommon.setGender(GenderEnum.U);
		metaCommon.setYob(-1);
		metaCommon.setYobRange(-1);
		metaCommon.setRace("-1");
		metaCommon.setRegion("U");

		val metaInfo = factory_.createMetaInfo();
		metaInfo.setMetaCommon(metaCommon);
		if (generationMode_ == GenerationMode.TENPRINT_EXTRACTION) {
			val metaTenprint = factory_.createMetaInfoMetaTenprint();
			metaTenprint.setPrimaryPatterns(ParameterReader.getExtraction().getPrimaryPatterns());
			metaTenprint.setReferencePatterns(ParameterReader.getExtraction()
				.getReferencePatterns());

			metaInfo.setMetaTenprint(metaTenprint);
		} else if (generationMode_ == GenerationMode.LATENT_EXTRACTION) {

		}
		return metaInfo;
	}

	private AimFormats buildAimFormats() {
		val aimFormatsEle = factory_.createAimFormats();

		val aimFormats = Splitter.on(",").trimResults().split(ParameterReader.getExtraction()
			.getAimFormats());
		for (val format : aimFormats) {
			aimFormatsEle.getFmt().add(format);
		}
		return aimFormatsEle;
	}

	private TenprintInput.Images buildImages(Map<Integer, jp.co.nec.aim.nistpack.Image> images) {
		val imagesEle = factory_.createTenprintInputImages();
		for (val fingerNumber : images.keySet()) {
			imagesEle.getImage().add(buildImage(fingerNumber, images.get(fingerNumber)));
		}
		return imagesEle;
	}

	/**
	 * 
	 * @param image
	 * @return
	 */
	private LatentInput.Images buildImages(jp.co.nec.aim.nistpack.Image image) {
		val imagesEle = factory_.createLatentInputImages();
		imagesEle.setImage(buildImage(0, image));
		return imagesEle;
	}

	/*
	 * private ExtractInputImage buildLatentFingerExtractInputImage(
	 * Triple<Path, Path, Path> triplePath) throws IOException { if
	 * (triplePath.getLeft() == null) { throw new
	 * FileNotFoundException("no latent image"); }
	 * 
	 * val inputImage = factory_.createFingerExtractInputImage();
	 * inputImage.getImages().add(buildImage(triplePath));
	 * inputImage.getExtractionParameters().addAll(buildExtractInputParameter())
	 * ; return inputImage; }
	 * 
	 * private ExtractInputImage buildPalmExtractInputImage( Map<Integer,
	 * jp.co.nec.aim_xm.nistpack.Image> image) { val inputImage =
	 * factory_.createPalmExtractInputImage();
	 * 
	 * for (val partNumber : image.keySet()) {
	 * inputImage.getImages().add(buildImage(partNumber,
	 * image.get(partNumber))); }
	 * 
	 * inputImage.getExtractionParameters().addAll(buildExtractInputParameter())
	 * ;
	 * 
	 * return inputImage; }
	 * 
	 * private ExtractInputImage buildIrisExtractInputImage(Pair<Path, Path>
	 * image) { val inputImage = factory_.createIrisExtractInputImage();
	 * 
	 * val imageEle = buildIrisImage(image);
	 * inputImage.setRightEyeImage(imageEle.getRight());
	 * inputImage.setLeftEyeImage(imageEle.getLeft()); return inputImage; }
	 */
	/**
	 * 
	 * @param fingerNumber
	 * @param image
	 * @return
	 */
	private InputImage buildImage(int fingerNumber, jp.co.nec.aim.nistpack.Image image) {
		val inputImage = factory_.createInputImage();

		inputImage.setData(ArrayUtils.toPrimitive(image.getData()));
		inputImage.setDpi(image.getDpi());

		inputImage.setType(encodedMap_.get(image.getType()));
		inputImage.setWidth(image.getWidth());
		inputImage.setHeight(image.getHeight());

		inputImage.setWhiteBlackLevel(ParameterReader.getExtraction().isBlackOnWhite() ? "0" : "1");

		inputImage.setPos(String.valueOf(fingerNumber));
		return inputImage;
	}

	/*
	 * private Image buildImage(Path bt5Path) throws IOException { val imageEle
	 * = factory_.createImage(); try { val manualDataEle =
	 * factory_.createExtractManualData();
	 * manualDataEle.setEditedMinutia(Files.readAllBytes(bt5Path));
	 * imageEle.setManualData(manualDataEle); } catch (IOException ex) { throw
	 * ex; } return imageEle; }
	 * 
	 * private Image buildImage(Triple<Path, Path, Path> triplePath) throws
	 * IOException { val imageEle = factory_.createImage(); try {
	 * imageEle.setData(Files.readAllBytes(triplePath.getLeft())); } catch
	 * (IOException ex) { throw ex; } imageEle.setDpi(500);
	 * imageEle.setType(ImageFormat.RAW); imageEle.setWidth(512);
	 * imageEle.setHeight(512); imageEle.setIsBlackOnWhite(true);
	 * imageEle.setPosition(ImagePosition.UNKNOWN);
	 * imageEle.setManualData(buildManualData(triplePath)); return imageEle; }
	 * 
	 * private Pair<Image, Image> buildIrisImage(Pair<Path, Path> path) { val
	 * leftImage = factory_.createImage();
	 * leftImage.setData(ArrayUtils.toPrimitive(readFile(path.getLeft())));
	 * leftImage.setType(ImageFormat.JPEG_2000);
	 * leftImage.setPosition(ImagePosition.LEFT_IRIS);
	 * 
	 * val rightImage = factory_.createImage();
	 * rightImage.setData(ArrayUtils.toPrimitive(readFile(path.getRight())));
	 * rightImage.setType(ImageFormat.JPEG_2000);
	 * rightImage.setPosition(ImagePosition.RIGHT_IRIS);
	 * 
	 * val buff = Pair.of(leftImage, rightImage); return buff; }
	 */
	private QName buildQname(String localPart) {
		return new QName("http://webservices.biomatcher.nec.com/", localPart);
	}

	private Byte[] readFile(Path path) {
		try {
			return ArrayUtils.toObject(Files.readAllBytes(path));
		} catch (IOException ex) {
			logger.error(Throwables.getStackTraceAsString(ex));
		}
		return null;
	}

	// public SubmitVerificationJob buildIrisSubmitVerificationJob(
	// Pair<Path, Path> probeImage,
	// Pair<Path, Path> galleryImage) {
	//
	// val requset = factory_.createVerifyJobRequestDto();
	// // probe
	// generationMode_ = GenerationMode.VERIFICATION_PROBE;
	// requset.setProbeBiomericData(buildVerifyBiometricData(probeImage));
	//
	// // gallery
	// generationMode_ = GenerationMode.VERIFICATION_GALLERY;
	// requset.getGalleryBiomericDataList().add(buildVerifyBiometricData(galleryImage));
	//
	// val matchInputParam = factory_.createMatchInputParameter();
	// requset.getMatchInputParameterList().add(matchInputParam);
	// buildMatchParameter(matchInputParam);
	// requset.setCallbackUrl(verificationCallback_);
	// requset.setJobTimeoutMill(600 * 1000L);
	// requset.setJobMode("live");
	// requset.setPriority(10);
	//
	// val job = new SubmitVerificationJob();
	// job.setArg0(requset);
	// return job;
	// }

	// public SubmitVerificationJob buildPalmSubmitVerificationJob(
	// Map<Integer, jp.co.nec.aim_xm.nistpack.Image> probeImage,
	// Map<Integer, jp.co.nec.aim_xm.nistpack.Image> galleryImage,
	// Byte[] probeCapsule,
	// Byte[] galleryCapsule) {
	//
	// val requset = factory_.createVerifyJobRequestDto();
	// generationMode_ = GenerationMode.VERIFICATION_PROBE;
	// requset.setProbeBiomericData(buildVerifyBiometricData(probeImage,
	// probeCapsule));
	//
	// generationMode_ = GenerationMode.VERIFICATION_GALLERY;
	// requset.getGalleryBiomericDataList().add(buildVerifyBiometricData(galleryImage,
	// galleryCapsule));
	//
	// val matchInputParam = factory_.createMatchInputParameter();
	// requset.getMatchInputParameterList().add(matchInputParam);
	// buildMatchParameter(matchInputParam);
	//
	// requset.setCallbackUrl(verificationCallback_);
	// requset.setJobTimeoutMill(600 * 1000L);
	// requset.setJobMode("live");
	// requset.setPriority(10);
	//
	// val job = new SubmitVerificationJob();
	// job.setArg0(requset);
	// return job;
	// }

	/**
	 * finger
	 * 
	 * Map<Integer, Pair<Byte[], Integer>>
	 * 
	 * @param image
	 * @return
	 */
	// public SubmitVerificationJob buildFingerSubmitVerificationJob(
	// Map<Integer, jp.co.nec.aim_xm.nistpack.Image> probeImage,
	// Map<Integer, jp.co.nec.aim_xm.nistpack.Image> galleryImage,
	// Byte[] probeCapsule,
	// Byte[] galleryCapsule) {
	//
	// val requset = factory_.createVerifyJobRequestDto();
	// generationMode_ = GenerationMode.VERIFICATION_PROBE;
	// requset.setProbeBiomericData(buildVerifyBiometricData(probeImage,
	// probeCapsule));
	//
	// generationMode_ = GenerationMode.VERIFICATION_GALLERY;
	// requset.getGalleryBiomericDataList().add(buildVerifyBiometricData(galleryImage,
	// galleryCapsule));
	//
	// val matchInputParam = factory_.createMatchInputParameter();
	// requset.getMatchInputParameterList().add(matchInputParam);
	// buildMatchParameter(matchInputParam);
	//
	// requset.setCallbackUrl(verificationCallback_);
	// requset.setJobTimeoutMill(600 * 1000L);
	// requset.setJobMode("live");
	// requset.setPriority(10);
	//
	// val job = new SubmitVerificationJob();
	// job.setArg0(requset);
	// return job;
	// }

	// public SubmitVerificationJob buildFingerSubmitVerificationJob(
	// Path probeImage,
	// List<Path> feature,
	// List<Path> galleryImage) {
	//
	// val requset = factory_.createVerifyJobRequestDto();
	// // probe
	// val image = new jp.co.nec.aim_xm.nistpack.Image();
	// if (!Objects.isNull(probeImage)) {
	// image.setData(readFile(probeImage));
	// image.setFile(probeImage);
	// image.setDpi(500);
	// if
	// (!verification_.getProbe().getElftProbe().getWsqPath().equalsIgnoreCase("none"))
	// {
	// image.setType("WSQ");
	// } else if
	// (!verification_.getProbe().getElftProbe().getNist27RawPath().equalsIgnoreCase(
	// "none")) {
	// image.setType("RAW");
	// image.setWidth(800);
	// image.setHeight(768);
	// }
	// }
	// requset.setProbeBiomericData(buildVerifyBiometricData(Pair.of(0, image),
	// feature));
	//
	// // gallery
	// val offset =
	// verification_.getGallery().getElftGallery().getNumFingerByCandidate();
	// for (int index = 0; index < verification_.getGallery().getElftGallery()
	// .getNumFew(); ++index) {
	// requset.getGalleryBiomericDataList().add(buildVerifyBiometricData(galleryImage,
	// index
	// * offset));
	// }
	//
	// val matchInputParam = factory_.createMatchInputParameter();
	// requset.getMatchInputParameterList().add(matchInputParam);
	// buildMatchParameter(matchInputParam);
	// requset.setCallbackUrl(verificationCallback_);
	// requset.setJobTimeoutMill(600 * 1000L);
	// requset.setJobMode("live");
	// requset.setPriority(10);
	//
	// val job = new SubmitVerificationJob();
	// job.setArg0(requset);
	// return job;
	// }

	// private VerifyBiometricData buildVerifyBiometricData(Pair<Path, Path>
	// image) {
	// val biometricData = factory_.createVerifyBiometricData();
	// biometricData.getImageList().add(buildFeatureExtractInputImage(image));
	//
	// if (generationMode_ == GenerationMode.VERIFICATION_PROBE) {
	// biometricData.setContainerId(verification_.getProbe().getContainerId());
	// biometricData.setCandidateId(verification_.getProbe().getCandidateId());
	// } else if (generationMode_ == GenerationMode.VERIFICATION_GALLERY) {
	// biometricData.setContainerId(verification_.getGallery().getContainerId());
	// biometricData.setCandidateId(verification_.getGallery().getCandidateId());
	// }
	// return biometricData;
	// }

	// private VerifyBiometricData buildVerifyBiometricData(Byte[] image, Byte[]
	// capsule) {
	// val biometricData = factory_.createVerifyBiometricData();
	// if (!Objects.isNull(image)) {
	// biometricData.getImageList().add(buildFeatureExtractInputImage(image));
	// } else if (!Objects.isNull(capsule)) {
	// biometricData.getTemplateInfoList().add(buildTemplateInfo(capsule));
	// }
	//
	// if (generationMode_ == GenerationMode.VERIFICATION_PROBE) {
	// biometricData.setContainerId(verification_.getProbe().getContainerId());
	// biometricData.setCandidateId(verification_.getProbe().getCandidateId());
	// } else if (generationMode_ == GenerationMode.VERIFICATION_GALLERY) {
	// biometricData.setContainerId(verification_.getGallery().getContainerId());
	// biometricData.setCandidateId(verification_.getGallery().getCandidateId());
	// }
	// return biometricData;
	// }
	/*
	 * private VerifyBiometricData buildVerifyBiometricData( Pair<Integer,
	 * jp.co.nec.aim_xm.nistpack.Image> image, List<Path> featurePath) { val
	 * biometricData = factory_.createVerifyBiometricData(); int containerId =
	 * 0; val algorithm = verification_.getAlgorithm(); if
	 * (algorithm.equalsIgnoreCase("elft")) { containerId = 49; } else if
	 * (algorithm.equalsIgnoreCase("elfml")) { containerId = 50; }
	 * 
	 * if (!Objects.isNull(image.getRight().getData())) {
	 * biometricData.getImageList().add(buildFeatureExtractInputImage( new
	 * HashMap<Integer, jp.co.nec.aim_xm.nistpack.Image>() { {
	 * put(image.getLeft(), image.getRight()); } }));
	 * 
	 * biometricData.setCandidateId(image.getRight().getFile().toFile().getName(
	 * )); } else { val templatePath =
	 * verification_.getProbe().getElftProbe().getElftTemplatePath();
	 * biometricData.setCandidateId(Paths.get(templatePath).toFile().getName());
	 * }
	 * 
	 * val feature = buildFeatureData(featurePath); if (feature.getData().length
	 * != 0) {
	 * biometricData.getFeatureDataList().add(buildFeatureData(featurePath)); }
	 * 
	 * biometricData.setContainerId(containerId); return biometricData; }
	 * 
	 * private VerifyBiometricData buildVerifyBiometricData(List<Path>
	 * galleryImage, int offset) { val biometricData =
	 * factory_.createVerifyBiometricData(); int containerId = 0; val algorithm
	 * = verification_.getAlgorithm(); if (algorithm.equalsIgnoreCase("elft")) {
	 * containerId = 49; } else if (algorithm.equalsIgnoreCase("elfml")) {
	 * containerId = 50; } biometricData.setContainerId(containerId);
	 * 
	 * for (int index = 0; index < verification_.getGallery().getElftGallery()
	 * .getNumFingerByCandidate(); ++index) {
	 * 
	 * val image = new jp.co.nec.aim_xm.nistpack.Image();
	 * image.setData(readFile(galleryImage.get(offset + index)));
	 * image.setFile(galleryImage.get(offset + index)); image.setDpi(500); if
	 * (verification_.getGallery().getElftGallery().getSelectedImage().
	 * equalsIgnoreCase( "wsq")) { image.setType("WSQ"); } else if
	 * (verification_.getGallery().getElftGallery().getSelectedImage()
	 * .equalsIgnoreCase("raw")) { image.setType("RAW"); image.setWidth(800);
	 * image.setHeight(768); }
	 * 
	 * int fingerNumber = 1; if
	 * (!verification_.getGallery().getElftGallery().getFixedFingerNumber()
	 * .equalsIgnoreCase("none")) { fingerNumber =
	 * Integer.valueOf(verification_.getGallery().getElftGallery()
	 * .getFixedFingerNumber()).intValue(); }
	 * 
	 * val map = new HashMap<Integer, jp.co.nec.aim_xm.nistpack.Image>();
	 * map.put(fingerNumber, image);
	 * biometricData.getImageList().add(buildFeatureExtractInputImage(map));
	 * 
	 * if (index == 0) {
	 * biometricData.setCandidateId(image.getFile().toFile().getName()); } }
	 * return biometricData; }
	 * 
	 * private VerifyBiometricData buildVerifyBiometricData( Map<Integer,
	 * jp.co.nec.aim_xm.nistpack.Image> image, Byte[] capsule) { val
	 * biometricData = factory_.createVerifyBiometricData(); if (image.size() !=
	 * 0) {
	 * biometricData.getImageList().add(buildFeatureExtractInputImage(image)); }
	 * else if (!Objects.isNull(capsule)) {
	 * biometricData.getTemplateInfoList().add(buildTemplateInfo(capsule)); }
	 * 
	 * if (generationMode_ == GenerationMode.VERIFICATION_PROBE) {
	 * biometricData.setContainerId(verification_.getProbe().getContainerId());
	 * biometricData.setCandidateId(verification_.getProbe().getCandidateId());
	 * } else if (generationMode_ == GenerationMode.VERIFICATION_GALLERY) {
	 * biometricData.setContainerId(verification_.getGallery().getContainerId())
	 * ;
	 * biometricData.setCandidateId(verification_.getGallery().getCandidateId())
	 * ; } return biometricData; }
	 */

	// private void buildMatchParameter(MatchInputParameter inputParameter)
	// throws IllegalArgumentException {
	// if (verification_.getAlgorithm().equalsIgnoreCase("cml")) {
	// inputParameter.setModality(Modality.FINGER);
	// inputParameter.setAlgorithmType(jp.co.nec.aim_xm.client.soap.AlgorithmType.FINGER_CML);
	// inputParameter.getParameters().add(buildBioParameterDto("OutputChartsEnabled",
	// verification_.getOutputChartsEnabled()));
	// inputParameter.getParameters().add(buildBioParameterDto("LimitOutputCharts",
	// verification_.getLimitOutputCharts()));
	// inputParameter.getParameters().add(buildBioParameterDto("UseCrossMatch",
	// verification_
	// .getUseCrossMatch()));
	// } else if (verification_.getAlgorithm().equalsIgnoreCase("elft")) {
	// inputParameter.setModality(Modality.FINGER);
	// inputParameter.setAlgorithmType(jp.co.nec.aim_xm.client.soap.AlgorithmType.FINGER_ELFT);
	// inputParameter.getParameters().add(buildBioParameterDto("Speed",
	// verification_
	// .getElftMatchSpeed()));
	// } else if (verification_.getAlgorithm().equalsIgnoreCase("finger_lfml"))
	// {
	// inputParameter.setModality(Modality.FINGER);
	// inputParameter.setAlgorithmType(jp.co.nec.aim_xm.client.soap.AlgorithmType.FINGER_LFML);
	// if (!Objects.isNull(verification_.getSelectFingers())) {
	// inputParameter.getParameters().add(buildBioParameterDto("SelectFingers",
	// verification_.getSelectFingers()));
	// }
	// inputParameter.getParameters().add(buildBioParameterDto("OutputChartsEnabled",
	// verification_.getOutputChartsEnabled()));
	// inputParameter.getParameters().add(buildBioParameterDto("LimitOutputCharts",
	// verification_.getLimitOutputCharts()));
	// } else if (verification_.getAlgorithm().equalsIgnoreCase("palm_lfml")) {
	// inputParameter.setModality(Modality.PALM);
	// inputParameter.setAlgorithmType(jp.co.nec.aim_xm.client.soap.AlgorithmType.PALM_LFML);
	// if (!Objects.isNull(verification_.getSelectPalms())) {
	// inputParameter.getParameters().add(buildBioParameterDto("SelectPalms",
	// verification_
	// .getSelectPalms()));
	// }
	// inputParameter.getParameters().add(buildBioParameterDto("OutputChartsEnabled",
	// verification_.getOutputChartsEnabled()));
	// inputParameter.getParameters().add(buildBioParameterDto("LimitOutputCharts",
	// verification_.getLimitOutputCharts()));
	//
	// } else if (verification_.getAlgorithm().equalsIgnoreCase("niris")) {
	// inputParameter.setModality(Modality.IRIS);
	// inputParameter.setAlgorithmType(jp.co.nec.aim_xm.client.soap.AlgorithmType.IRIS_NEC);
	//
	// if (!Objects.isNull(verification_.getNirisRotation())) {
	// inputParameter.getParameters().add(buildBioParameterDto("Rotation",
	// verification_
	// .getNirisRotation()));
	// }
	//
	// if (!Objects.isNull(verification_.getNirisSpeed())) {
	// inputParameter.getParameters().add(buildBioParameterDto("Speed",
	// verification_
	// .getNirisSpeed()));
	// }
	//
	// } else if (verification_.getAlgorithm().equalsIgnoreCase("s17") ||
	// verification_
	// .getAlgorithm().equalsIgnoreCase("nfg2") || verification_.getAlgorithm()
	// .equalsIgnoreCase("nfv2") ||
	// verification_.getAlgorithm().equalsIgnoreCase(
	// "nfv3")) {
	//
	// inputParameter.setModality(Modality.FACE);
	// if (verification_.getAlgorithm().equalsIgnoreCase("s17")) {
	// inputParameter.setAlgorithmType(
	// jp.co.nec.aim_xm.client.soap.AlgorithmType.FACE_NEC_S_17);
	// } else if (verification_.getAlgorithm().equalsIgnoreCase("nfg2")) {
	// inputParameter.setAlgorithmType(
	// jp.co.nec.aim_xm.client.soap.AlgorithmType.FACE_NEC_NFG_2);
	// } else if (verification_.getAlgorithm().equalsIgnoreCase("nfv2")) {
	// inputParameter.setAlgorithmType(
	// jp.co.nec.aim_xm.client.soap.AlgorithmType.FACE_NEC_NFV_2);
	// } else if (verification_.getAlgorithm().equalsIgnoreCase("nfv3")) {
	// inputParameter.setAlgorithmType(
	// jp.co.nec.aim_xm.client.soap.AlgorithmType.FACE_NEC_NFV_3);
	// }

	// if (!verification_.isUseNeoFaceParameter()) {
	// return;
	// }

	// if
	// (!Objects.isNull(verification_.getNeoFace().getShrinkFactor())) {
	// inputParameter.getParameters().add(buildBioParameterDto("ShrinkFactor",
	// verification_.getNeoFace().getShrinkFactor()));
	// }
	// if (!Objects.isNull(verification_.getNeoFace().getEyeRoll())) {
	// inputParameter.getParameters().add(buildBioParameterDto("EyeRoll",
	// verification_
	// .getNeoFace().getEyeRoll()));
	// }
	//
	// if (!Objects.isNull(verification_.getNeoFace().getMaxEyeDist()))
	// {
	// inputParameter.getParameters().add(buildBioParameterDto("MaxEyeDist",
	// verification_
	// .getNeoFace().getMaxEyeDist()));
	// }
	// if (!Objects.isNull(verification_.getNeoFace().getMinEyeDist()))
	// {
	// inputParameter.getParameters().add(buildBioParameterDto("MinEyeDist",
	// verification_
	// .getNeoFace().getMinEyeDist()));
	// }
	// if (!Objects.isNull(verification_.getNeoFace().getReliability()))
	// {
	// inputParameter.getParameters().add(buildBioParameterDto("Reliability",
	// verification_
	// .getNeoFace().getReliability()));
	// }
	// if (!Objects.isNull(verification_.getNeoFace().getAlgorithm())) {
	// inputParameter.getParameters().add(buildBioParameterDto("Algorithm",
	// verification_
	// .getNeoFace().getAlgorithm()));
	// }
	//
	// if
	// (verification_.getNeoFace().getEnableEeyPosition().compareTo("true")
	// == 0) {
	// if (!Objects.isNull(verification_.getNeoFace().getRightEye())) {
	// inputParameter.getParameters().add(buildBioParameterDto("RightEyeCenterX",
	// String.valueOf(verification_.getNeoFace().getRightEye().getX())));
	// inputParameter.getParameters().add(buildBioParameterDto("RightEyeCenterY",
	// String.valueOf(verification_.getNeoFace().getRightEye().getY())));
	// inputParameter.getParameters().add(buildBioParameterDto("LeftEyeCenterX",
	// String
	// .valueOf(verification_.getNeoFace().getLeftEye().getX())));
	// inputParameter.getParameters().add(buildBioParameterDto("LeftEyeCenterY",
	// String
	// .valueOf(verification_.getNeoFace().getLeftEye().getY())));
	// }
	// }
	//
	// if
	// (Objects.nonNull(verification_.getNeoFace().getEnableG2Attributes()))
	// {
	// inputParameter.getParameters().add(buildBioParameterDto("EnableG2Attributes",
	// String
	// .valueOf(verification_.getNeoFace().getEnableG2Attributes())));
	// }
	// }
	// }

	/*
	 * private FeatureData buildFeatureData(List<Path> feature) { val
	 * featureData = factory_.createFeatureData(); val templatePath =
	 * verification_.getProbe().getElftProbe().getElftTemplatePath(); val
	 * featureType = verification_.getProbe().getElftProbe().getUseFeature();
	 * 
	 * if (!templatePath.equalsIgnoreCase("none")) {
	 * featureData.setData(ArrayUtils.toPrimitive(readFile(Paths.get(
	 * templatePath)))); featureData.setPosition(ImagePosition.UNKNOWN);
	 * featureData.setAlgorithmType(AlgorithmType.FINGER_ELFT); } else if
	 * (!featureType.equalsIgnoreCase("none")) {
	 * featureData.setData(ArrayUtils.toPrimitive(readFile(feature.get(0))));
	 * featureData.setPosition(ImagePosition.UNKNOWN);
	 * 
	 * if (featureType.equalsIgnoreCase("pc2")) {
	 * featureData.setAlgorithmType(AlgorithmType.FINGER_PC_2); } else if
	 * (featureType.equalsIgnoreCase("bt5")) {
	 * featureData.setAlgorithmType(AlgorithmType.FINGER_BT_5); } else if
	 * (featureType.equalsIgnoreCase("fmp5")) {
	 * featureData.setAlgorithmType(AlgorithmType.FINGER_FMP_5); } }
	 * 
	 * return featureData; }
	 * 
	 * private TemplateInfo buildTemplateInfo(Byte[] capsule) { val templateInfo
	 * = factory_.createTemplateInfo();
	 * templateInfo.setTemplateData(ArrayUtils.toPrimitive(capsule)); if
	 * (generationMode_ == GenerationMode.VERIFICATION_PROBE) {
	 * templateInfo.setTemplateType(verification_.getProbe().getCapsuleType());
	 * } else if (generationMode_ == GenerationMode.VERIFICATION_GALLERY) {
	 * templateInfo.setTemplateType(verification_.getGallery().getCapsuleType())
	 * ; } return templateInfo; }
	 * 
	 * public SubmitSyncJob buildDeletionSubmitSyncJob(String externalId,
	 * List<Integer> binId) { val payload =
	 * factory_.createDeleteBiometricEventDto();
	 * payload.setExternalId(externalId); payload.setEventId("0");
	 * payload.getBinIdSet().addAll(binId);
	 * 
	 * val requset = factory_.createSyncJobRequestDto();
	 * requset.getEventSyncDtoList().add(payload);
	 * requset.setCallbackUrl(syncCallback_);
	 * requset.setJobTimeoutMill(120000L); requset.setJobMode("live");
	 * 
	 * val job = new SubmitSyncJob(); job.setArg0(requset); return job; }
	 * 
	 * 
	 * public SubmitSearchJob buildFingerSubmitSearchJob( Map<Integer,
	 * jp.co.nec.aim_xm.nistpack.Image> image, String externalId) {
	 * generationMode_ = GenerationMode.EXTRACTION; val inputImage =
	 * factory_.createTemplateExtractInputImage();
	 * inputImage.setExtractInputImage(buildFingerExtractInputImage(image));
	 * 
	 * val payload = factory_.createExtractInputPayloadDto(); val capsuleTypes =
	 * Splitter.on(",").trimResults().split(ParameterReader.getExtraction()
	 * .getCapsuleType()); for (val capsuleType : capsuleTypes) {
	 * inputImage.getTemplateTypes().add("TEMPLATE_TYPE_" + capsuleType); }
	 * payload.getTemplateExtractInputImageList().add(inputImage);
	 * 
	 * val searchRequest = factory_.createSearchRequestItemDto(); val binId =
	 * Splitter.on(",").trimResults().split(search_.getBinId()); for (val buff :
	 * binId) { searchRequest.getBinIdList().add(Integer.valueOf(buff)); }
	 * searchRequest.setSearchItemPayloadDto(buildSearchItemInputPayloadDto());
	 * 
	 * val requset = factory_.createSearchJobRequestDto();
	 * requset.setExtractInputPayloadDto(payload);
	 * requset.getSearchRequestItemList().add(searchRequest);
	 * requset.setCallbackUrl(searchCallback_);
	 * requset.setJobTimeoutMill(120000L); requset.setJobMode("live");
	 * requset.setIncludeExtractionResult(false);
	 * 
	 * val job = new SubmitSearchJob(); job.setArg0(requset); return job; }
	 * 
	 * public SubmitSearchJob buildFingerSubmitSearchJob(Path path, String
	 * externalId) throws IOException { val searchRequest =
	 * factory_.createSearchRequestItemDto(); val binId =
	 * Splitter.on(",").trimResults().split(search_.getBinId()); for (val buff :
	 * binId) { searchRequest.getBinIdList().add(Integer.valueOf(buff)); }
	 * searchRequest.setSearchItemPayloadDto(buildSearchItemInputPayloadDto(path
	 * ));
	 * 
	 * val requset = factory_.createSearchJobRequestDto();
	 * requset.getSearchRequestItemList().add(searchRequest);
	 * requset.setCallbackUrl(searchCallback_);
	 * requset.setJobTimeoutMill(120000L); requset.setJobMode("live");
	 * requset.setIncludeExtractionResult(false);
	 * 
	 * val job = new SubmitSearchJob(); job.setArg0(requset); return job; }
	 * 
	 * public SubmitSearchJob buildPalmSubmitSearchJob( Map<Integer,
	 * jp.co.nec.aim_xm.nistpack.Image> image, String externalId) {
	 * generationMode_ = GenerationMode.EXTRACTION; val inputImage =
	 * factory_.createTemplateExtractInputImage();
	 * inputImage.setExtractInputImage(buildPalmExtractInputImage(image));
	 * 
	 * val payload = factory_.createExtractInputPayloadDto(); val capsuleTypes =
	 * Splitter.on(",").trimResults().split(ParameterReader.getExtraction()
	 * .getCapsuleType()); for (val capsuleType : capsuleTypes) {
	 * inputImage.getTemplateTypes().add("TEMPLATE_TYPE_" + capsuleType); }
	 * payload.getTemplateExtractInputImageList().add(inputImage);
	 * 
	 * val searchRequest = factory_.createSearchRequestItemDto(); val binId =
	 * Splitter.on(",").trimResults().split(search_.getBinId()); for (val buff :
	 * binId) { searchRequest.getBinIdList().add(Integer.valueOf(buff)); }
	 * searchRequest.setSearchItemPayloadDto(buildSearchItemInputPayloadDto());
	 * 
	 * val requset = factory_.createSearchJobRequestDto();
	 * requset.setExtractInputPayloadDto(payload);
	 * requset.getSearchRequestItemList().add(searchRequest);
	 * requset.setCallbackUrl(searchCallback_);
	 * requset.setJobTimeoutMill(120000L); requset.setJobMode("live");
	 * requset.setIncludeExtractionResult(false);
	 * 
	 * val job = new SubmitSearchJob(); job.setArg0(requset); return job; }
	 * 
	 * private SearchItemInputPayloadDto buildSearchItemInputPayloadDto() { val
	 * request = factory_.createSearchItemInputPayloadDto();
	 * request.setMaxHitCount(search_.getMaxHitCount());
	 * request.setMinScoreThreshold(search_.getMinScoreThreshold());
	 * 
	 * val capsuleTypes =
	 * Splitter.on(",").trimResults().split(ParameterReader.getExtraction()
	 * .getCapsuleType()); for (val capsuleType : capsuleTypes) {
	 * request.setTemplateType("TEMPLATE_TYPE_" + capsuleType); } return
	 * request; }
	 * 
	 * private SearchItemInputPayloadDto buildSearchItemInputPayloadDto(Path
	 * path) throws IOException { val request =
	 * factory_.createSearchItemInputPayloadDto();
	 * request.setTemplateData(Files.readAllBytes(path));
	 * request.setMaxHitCount(search_.getMaxHitCount());
	 * request.setMinScoreThreshold(search_.getMinScoreThreshold());
	 * request.setTemplateType("TEMPLATE_TYPE_" +
	 * ParameterReader.getSearch().getCapsuleType()); return request; }
	 */

	/**
	 * 
	 * @param externalId
	 * @param contianerIds
	 * @param eventId
	 * @return
	 */
	public Delete buildDelet(
		String externalId,
		List<Integer> contianerIds,
		Integer eventId) {
		val job = factory_.createDelete();
		job.setExternalId(externalId);
		if (!Objects.isNull(eventId)) {
			job.setEventId(eventId);
		}
		if (!contianerIds.isEmpty()) {
			job.getContainerIds().addAll(contianerIds);
		}
		return job;
	}

	public Extract buildPalmExtract(
			Map<Integer, jp.co.nec.aim.nistpack.Image> images,
			String externalId)
			throws ParserConfigurationException {
		generationMode_ = GenerationMode.TENPRINT_EXTRACTION;

		val extInput = factory_.createExtInput();
		extInput.setTenprintInput(buildTenprintInput(images));

		Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
		JAXB.marshal(new JAXBElement<ExtInput>(new QName("ext-input"), ExtInput.class, extInput),
				new DOMResult(document));
		val dynamicXml = factory_.createDynamicXml();
		dynamicXml.setAny(document.getDocumentElement());

		val extractionInputs = factory_.createExtractExtractionInputs();
		extractionInputs.setPriority(3);
		extractionInputs.setCallbackURL(extractionCallback_);
		extractionInputs.setExtractionInputsPayload(dynamicXml);

		val extract = factory_.createExtract();
		extract.setExtractionInputs(extractionInputs);
		return extract;
	}

}
