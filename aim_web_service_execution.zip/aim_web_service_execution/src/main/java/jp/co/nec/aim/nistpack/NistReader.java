package jp.co.nec.aim.nistpack;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aware.nistpack.INistpack;
import com.aware.nistpack.NistpackException;
import com.aware.nistpack.NistpackJNI;
import com.google.common.base.Throwables;

import lombok.val;

public class NistReader {
	final static Logger logger = LoggerFactory.getLogger(NistReader.class);

	final INistpack nistPack_;

	String path_;

	public NistReader() {
		logger.info("NistpackJNI started to initialize.");
		nistPack_ = new NistpackJNI();
		logger.info("NistpackJNI initialized.");
	}

	/**
	 * 
	 * @param path
	 */
	public NistReader(String path) {
		nistPack_ = new NistpackJNI();
		logger.info("NistpackJNI initialized.");

		path_ = path;
	}

	/**
	 * 
	 * @param file
	 */
	public Map<Integer, Image> getType4Image(String path) {
		path_ = path;
		Map<Integer, Image> map = new HashMap<>();
		try {
			nistPack_.readTransaction(path_);

			logger.info("nistPack_.getRecordTypeCount(4):{}", nistPack_.getRecordTypeCount(4));
			for (int i = 0; i < nistPack_.getRecordTypeCount(4); ++i) {
				try {
					val record = nistPack_.getRecordMem(4, i + 1);

					val image = new Image();
					image.setData(ArrayUtils.toObject(nistPack_.getImage(4, i + 1)));
					image.setDpi(500);
					if (record[17] == 1) {
						image.setType("WSQ");
					} else if (record[17] == 2) {
						image.setType("JP2");
					} else {
						image.setType("RAW");
						val is = new DataInputStream(new ByteArrayInputStream(record, 13, 4));
						val width = is.readShort();
						val height = is.readShort();
						image.setWidth(Integer.valueOf(width));
						image.setHeight(Integer.valueOf(height));
					}
					image.setFile(Paths.get(path));
					
					map.put(Integer.valueOf(record[6]), image);

					logger.debug("finger number:{}, format:{}", record[6], record[17]);
				} catch (NistpackException ex) {
					logger.warn(Throwables.getStackTraceAsString(ex));
				}

			}
		} catch (Exception ex) {
			logger.error(Throwables.getStackTraceAsString(ex));
		} finally {
			nistPack_.close();
		}
		return map;
	}

	/**
	 * 
	 * @param file
	 */
	public Map<Integer, Image> getType14Image(String path) {
		path_ = path;
		Map<Integer, Image> map = new HashMap<>();
		try {
			nistPack_.readTransaction(path_);
			logger.info("nistPack_.getRecordTypeCount(14):{}", nistPack_.getRecordTypeCount(14));

			for (int i = 0; i < nistPack_.getRecordTypeCount(14); ++i) {
				try {
					String record = new String(nistPack_.getRecordMem(14, i + 1));

					val image = new Image();
					image.setDpi(Integer.parseInt(getFieldValue(record, "14.009:")));
					image.setWidth(Integer.parseInt(getFieldValue(record, "14.006:")));
					image.setHeight(Integer.parseInt(getFieldValue(record, "14.007:")));
					image.setType(getFieldValue(record, "14.011:"));
					image.setData(ArrayUtils.toObject(nistPack_.getImage(14, i + 1)));
					// finger number
					val fingerNumber = Integer.parseInt(getFieldValue(record, "14.013:"));
					image.setFile(Paths.get(path));

					logger.debug("get finger number {}, {}", fingerNumber, image.getType());

					map.put(Integer.valueOf(fingerNumber), image);
				} catch (NistpackException ex) {
					logger.warn(Throwables.getStackTraceAsString(ex));
				}
			}
		} catch (Exception ex) {
			logger.error(Throwables.getStackTraceAsString(ex));
		} finally {
			nistPack_.close();
		}
		return map;
	}

	/**
	 * 
	 * @param path
	 * @return
	 */
	public Map<Integer, Image> getType15Image(String path) {
		path_ = path;
		Map<Integer, Image> map = new HashMap<>();
		try {
			nistPack_.readTransaction(path_);
			logger.info("nistPack_.getRecordTypeCount(15):{}", nistPack_.getRecordTypeCount(15));

			for (int i = 0; i < nistPack_.getRecordTypeCount(15); ++i) {
				try {
					String record = new String(nistPack_.getRecordMem(15, i + 1));
					val width = Integer.parseInt(getFieldValue(record, "15.006:"));
					val height = Integer.parseInt(getFieldValue(record, "15.007:"));
					val dpi = Integer.parseInt(getFieldValue(record, "15.009:"));
					val partNumber = Integer.parseInt(getFieldValue(record, "15.013:"));
					val algorithm = getFieldValue(record, "15.011:");

					logger.debug("get part number {}", partNumber);

					val image = new Image();
					image.setData(ArrayUtils.toObject(nistPack_.getImage(15, i + 1)));
					image.setDpi(dpi);
					image.setWidth(width);
					image.setHeight(height);
					image.setType(algorithm);
					image.setFile(Paths.get(path));
					
					map.put(Integer.valueOf(partNumber), image);
				} catch (NistpackException ex) {
					logger.warn(Throwables.getStackTraceAsString(ex));
				}
			}
		} catch (Exception ex) {
			logger.error(Throwables.getStackTraceAsString(ex));
		} finally {
			nistPack_.close();
		}
		return map;
	}

	public Map<Integer, Image> getType17Image(String path) {
		path_ = path;
		Map<Integer, Image> map = new HashMap<>();
		try {
			nistPack_.readTransaction(path_);
			logger.info("nistPack_.getRecordTypeCount(17):{}", nistPack_.getRecordTypeCount(17));

			for (int i = 0; i < nistPack_.getRecordTypeCount(17); ++i) {
				try {
					String record = new String(nistPack_.getRecordMem(17, i + 1));
					val width = Integer.parseInt(getFieldValue(record, "17.006:"));
					val height = Integer.parseInt(getFieldValue(record, "17.007:"));
					val dpi = Integer.parseInt(getFieldValue(record, "17.009:"));
					val eyeLabel = Integer.parseInt(getFieldValue(record, "17.003:"));
					val algorithm = getFieldValue(record, "17.011:");

					logger.debug("get part number {}", eyeLabel);

					val image = new Image();
					image.setData(ArrayUtils.toObject(nistPack_.getImage(17, i + 1)));
					image.setDpi(dpi);
					image.setWidth(width);
					image.setHeight(height);
					image.setType(algorithm);
					image.setFile(Paths.get(path));
					
					map.put(Integer.valueOf(eyeLabel), image);
				} catch (NistpackException ex) {
					logger.warn(Throwables.getStackTraceAsString(ex));
				}
			}
		} catch (Exception ex) {
			logger.error(Throwables.getStackTraceAsString(ex));
		} finally {
			nistPack_.close();
		}
		return map;
	}

	
	/**
	 * 
	 * @return
	 */
	public String getFieldValue(String src, String field) {
		val startIndex = src.indexOf(field);
		val endIndex = src.indexOf(0x1d, startIndex + field.length());
		return src.substring(startIndex + field.length(), endIndex);
	}
}
