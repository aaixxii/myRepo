package jp.co.nec.proto;

import com.google.common.base.Splitter;
import com.google.common.base.Throwables;
import com.google.protobuf.ByteString;
import jp.co.nec.aim.message.proto.*;
import jp.co.nec.aim.nistpack.Image;
import jp.co.nec.aim.xml.*;
import lombok.val;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.tuple.Triple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

import static jp.co.nec.aim.message.proto.CommonEnumTypes.*;
import static jp.co.nec.aim.message.proto.InquiryEnumTypes.*;

public class ProtoBuilder {
    final static Logger logger = LoggerFactory.getLogger(ProtoBuilder.class);

    final String SPLIT = "_-_";

    final Search search_ = ParameterReader.getSearch();

    final Extraction extraction_ = ParameterReader.getExtraction();

    final Insert insert_ = ParameterReader.getSync().getInsert();

    final Proto inquiryProto_ = ParameterReader.getSearch().getProto();

    final Proto extractionProto_ = ParameterReader.getExtraction().getProto();

    final Map<String, InquiryFunctionType> inquiryFunctionTypes_ = Collections.unmodifiableMap(new HashMap() {
        {
            put("LI-M", InquiryFunctionType.LIM);
            put("LLI-M", InquiryFunctionType.LLIM);
            put("TLI-M", InquiryFunctionType.TLIM);
            put("TI-M", InquiryFunctionType.TIM);
            put("LI-P", InquiryFunctionType.LIP);
            put("LLI-P", InquiryFunctionType.LLIP);
            put("TLI-P", InquiryFunctionType.TLIP);
            put("LI-P", InquiryFunctionType.LIP);
            put("LLI-P", InquiryFunctionType.LLIP);
        }
    });

    static final String RDBTM_CONTAINER_ID = "331";
    static final String SDBTM_CONTAINER_ID = "332";
    static final String RDBLM_CONTAINER_ID = "333";
    static final String SDBLM_CONTAINER_ID = "334";
    static final String PDB_CONTAINER_ID = "5";
    static final String PLDB_CONTAINER_ID = "322";
    static final String LDBM_CONTAINER_ID = "336";

    final Map<String, TemplateFormatType> templateFormatTypes_ = Collections.unmodifiableMap(new HashMap() {
        {
            put(RDBTM_CONTAINER_ID, TemplateFormatType.TEMPLATE_RDBTM);
            put(SDBTM_CONTAINER_ID, TemplateFormatType.TEMPLATE_RDBTM);
            put(RDBLM_CONTAINER_ID, TemplateFormatType.TEMPLATE_RDBLM);
            put(SDBLM_CONTAINER_ID, TemplateFormatType.TEMPLATE_RDBLM);
            put(PDB_CONTAINER_ID, TemplateFormatType.TEMPLATE_PDB);
            put(PLDB_CONTAINER_ID, TemplateFormatType.TEMPLATE_PLDB);
            put(LDBM_CONTAINER_ID, TemplateFormatType.TEMPLATE_LDBM);

            put("LI-M", TemplateFormatType.TEMPLATE_LIM);
            put("TI-M", TemplateFormatType.TEMPLATE_TIM);

            put("25", TemplateFormatType.TEMPLATE_TIM);
            put("31", TemplateFormatType.TEMPLATE_TLIM);
            put("26", TemplateFormatType.TEMPLATE_RDBTM);
            put("28", TemplateFormatType.TEMPLATE_RDBLM);
            put("27", TemplateFormatType.TEMPLATE_LIM);
            put("32", TemplateFormatType.TEMPLATE_LLIM);
            put("33", TemplateFormatType.TEMPLATE_LDBM);
            put("11", TemplateFormatType.TEMPLATE_TLIP);
            put("19", TemplateFormatType.TEMPLATE_PDB);
            put("9", TemplateFormatType.TEMPLATE_LIP);
            put("10", TemplateFormatType.TEMPLATE_LLIP);
            put("20", TemplateFormatType.TEMPLATE_PLDB);
        }
    });

    final Map<Integer, ImagePositionType> imagePositionTypes = Collections.unmodifiableMap(new HashMap() {
        {
            put(1, ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB);
            put(2, ImagePositionType.IMAGE_ROLLED_RIGHT_INDEX);
            put(3, ImagePositionType.IMAGE_ROLLED_RIGHT_MIDDLE);
            put(4, ImagePositionType.IMAGE_ROLLED_RIGHT_RING);
            put(5, ImagePositionType.IMAGE_ROLLED_RIGHT_LITTLE);
            put(6, ImagePositionType.IMAGE_ROLLED_LEFT_THUMB);
            put(7, ImagePositionType.IMAGE_ROLLED_LEFT_INDEX);
            put(8, ImagePositionType.IMAGE_ROLLED_LEFT_MIDDLE);
            put(9, ImagePositionType.IMAGE_ROLLED_LEFT_RING);
            put(10, ImagePositionType.IMAGE_ROLLED_LEFT_LITTLE);
            put(11, ImagePositionType.IMAGE_SLAP_RIGHT_THUMB);
            put(40, ImagePositionType.IMAGE_SLAP_RIGHT_INDEX);
            put(41, ImagePositionType.IMAGE_SLAP_RIGHT_MIDDLE);
            put(42, ImagePositionType.IMAGE_SLAP_RIGHT_RING);
            put(43, ImagePositionType.IMAGE_SLAP_RIGHT_LITTLE);
            put(12, ImagePositionType.IMAGE_SLAP_LEFT_THUMB);
            put(44, ImagePositionType.IMAGE_SLAP_LEFT_INDEX);
            put(45, ImagePositionType.IMAGE_SLAP_LEFT_MIDDLE);
            put(46, ImagePositionType.IMAGE_SLAP_LEFT_RING);
            put(47, ImagePositionType.IMAGE_SLAP_LEFT_LITTLE);
            put(13, ImagePositionType.IMAGE_SLAP_RIGHT_FOUR);
            put(14, ImagePositionType.IMAGE_SLAP_LEFT_FOUR);
            put(15, ImagePositionType.IMAGE_SLAP_THUMBS);
            put(21, ImagePositionType.IMAGE_PALM_RIGHT_FULL);
            put(22, ImagePositionType.IMAGE_PALM_RIGHT_WRITER);
            put(23, ImagePositionType.IMAGE_PALM_LEFT_FULL);
            put(24, ImagePositionType.IMAGE_PALM_LEFT_WRITER);
            put(25, ImagePositionType.IMAGE_PALM_RIGHT_LOWER);
            put(26, ImagePositionType.IMAGE_PALM_RIGHT_UPPER);
            put(27, ImagePositionType.IMAGE_PALM_LEFT_LOWER);
            put(28, ImagePositionType.IMAGE_PALM_LEFT_UPPER);
            put(31, ImagePositionType.IMAGE_PALM_RIGHT_INTERDIGITAL);
            put(32, ImagePositionType.IMAGE_PALM_RIGHT_THENAR);
            put(33, ImagePositionType.IMAGE_PALM_RIGHT_HYPOTHENAR);
            put(34, ImagePositionType.IMAGE_PALM_LEFT_INTERDIGITAL);
            put(35, ImagePositionType.IMAGE_PALM_LEFT_THENAR);
            put(36, ImagePositionType.IMAGE_PALM_LEFT_HYPOTHENAR);
        }
    });

    final HashMap<String, ImageFormatType> imageFormatTypes_ = new HashMap() {
        {
            put("RAW", ImageFormatType.RAW);
            put("WSQ", ImageFormatType.WSQ);
            put("J2K", ImageFormatType.JPEG2000);
            put("JP2", ImageFormatType.JPEG2000);
            put("JPG", ImageFormatType.JPEG);
            put("BMP", ImageFormatType.BMP);
            put("PNG", ImageFormatType.PNG);
        }
    };

    final HashMap<ImagePositionType, String> positions_ = new HashMap() {
        {
            put(ImagePositionType.IMAGE_PALM_RIGHT_FULL, "1");
            put(ImagePositionType.IMAGE_PALM_RIGHT_WRITER, "2");
            put(ImagePositionType.IMAGE_PALM_LEFT_FULL, "3");
            put(ImagePositionType.IMAGE_PALM_LEFT_WRITER, "4");
            put(ImagePositionType.IMAGE_PALM_RIGHT_LOWER, "5");
            put(ImagePositionType.IMAGE_PALM_RIGHT_UPPER, "6");
            put(ImagePositionType.IMAGE_PALM_LEFT_LOWER, "7");
            put(ImagePositionType.IMAGE_PALM_LEFT_UPPER, "8");
            put(ImagePositionType.IMAGE_PALM_RIGHT_OTHER, "9");
            put(ImagePositionType.IMAGE_PALM_LEFT_OTHER, "10");
            put(ImagePositionType.IMAGE_PALM_RIGHT_INTERDIGITAL, "11");
            put(ImagePositionType.IMAGE_PALM_RIGHT_THENAR, "12");
            put(ImagePositionType.IMAGE_PALM_RIGHT_HYPOTHENAR, "13");
            put(ImagePositionType.IMAGE_PALM_LEFT_INTERDIGITAL, "14");
            put(ImagePositionType.IMAGE_PALM_LEFT_THENAR, "15");
            put(ImagePositionType.IMAGE_PALM_LEFT_HYPOTHENAR, "16");
        }
    };

    final Map<String, CommonEnumTypes.ImagePositionType> imagePositionTypes_ = new HashMap() {
        {
            put("RDBLM_1.bin", CommonEnumTypes.ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB);
            put("RDBLM_2.bin", CommonEnumTypes.ImagePositionType.IMAGE_ROLLED_RIGHT_INDEX);
            put("RDBLM_3.bin", CommonEnumTypes.ImagePositionType.IMAGE_ROLLED_RIGHT_MIDDLE);
            put("RDBLM_4.bin", CommonEnumTypes.ImagePositionType.IMAGE_ROLLED_RIGHT_RING);
            put("RDBLM_5.bin", CommonEnumTypes.ImagePositionType.IMAGE_ROLLED_RIGHT_LITTLE);
            put("RDBLM_6.bin", CommonEnumTypes.ImagePositionType.IMAGE_ROLLED_LEFT_THUMB);
            put("RDBLM_7.bin", CommonEnumTypes.ImagePositionType.IMAGE_ROLLED_LEFT_INDEX);
            put("RDBLM_8.bin", CommonEnumTypes.ImagePositionType.IMAGE_ROLLED_LEFT_MIDDLE);
            put("RDBLM_9.bin", CommonEnumTypes.ImagePositionType.IMAGE_ROLLED_LEFT_RING);
            put("RDBLM_10.bin", CommonEnumTypes.ImagePositionType.IMAGE_ROLLED_LEFT_LITTLE);
            put("SDBLM_1.bin", CommonEnumTypes.ImagePositionType.IMAGE_SLAP_RIGHT_THUMB);
            put("SDBLM_2.bin", CommonEnumTypes.ImagePositionType.IMAGE_SLAP_RIGHT_INDEX);
            put("SDBLM_3.bin", CommonEnumTypes.ImagePositionType.IMAGE_SLAP_RIGHT_MIDDLE);
            put("SDBLM_4.bin", CommonEnumTypes.ImagePositionType.IMAGE_SLAP_RIGHT_RING);
            put("SDBLM_5.bin", CommonEnumTypes.ImagePositionType.IMAGE_SLAP_RIGHT_LITTLE);
            put("SDBLM_6.bin", CommonEnumTypes.ImagePositionType.IMAGE_SLAP_LEFT_THUMB);
            put("SDBLM_7.bin", CommonEnumTypes.ImagePositionType.IMAGE_SLAP_LEFT_INDEX);
            put("SDBLM_8.bin", CommonEnumTypes.ImagePositionType.IMAGE_SLAP_LEFT_MIDDLE);
            put("SDBLM_9.bin", CommonEnumTypes.ImagePositionType.IMAGE_SLAP_LEFT_RING);
            put("SDBLM_10.bin", CommonEnumTypes.ImagePositionType.IMAGE_SLAP_LEFT_LITTLE);
            put("PDB_1.bin", CommonEnumTypes.ImagePositionType.IMAGE_PALM_RIGHT_FULL);
            put("PDB_2.bin", CommonEnumTypes.ImagePositionType.IMAGE_PALM_RIGHT_WRITER);
            put("PDB_3.bin", CommonEnumTypes.ImagePositionType.IMAGE_PALM_LEFT_FULL);
            put("PDB_4.bin", CommonEnumTypes.ImagePositionType.IMAGE_PALM_LEFT_WRITER);
            put("PDB_5.bin", CommonEnumTypes.ImagePositionType.IMAGE_PALM_RIGHT_LOWER);
            put("PDB_6.bin", CommonEnumTypes.ImagePositionType.IMAGE_PALM_RIGHT_UPPER);
            put("PDB_7.bin", CommonEnumTypes.ImagePositionType.IMAGE_PALM_LEFT_LOWER);
            put("PDB_8.bin", CommonEnumTypes.ImagePositionType.IMAGE_PALM_LEFT_UPPER);
            put("PDB_9.bin", CommonEnumTypes.ImagePositionType.IMAGE_PALM_RIGHT_OTHER);
            put("PDB_10.bin", CommonEnumTypes.ImagePositionType.IMAGE_PALM_LEFT_OTHER);
            put("PDB_11.bin", CommonEnumTypes.ImagePositionType.IMAGE_PALM_RIGHT_INTERDIGITAL);
            put("PDB_12.bin", CommonEnumTypes.ImagePositionType.IMAGE_PALM_RIGHT_THENAR);
            put("PDB_13.bin", CommonEnumTypes.ImagePositionType.IMAGE_PALM_RIGHT_HYPOTHENAR);
            put("PDB_14.bin", CommonEnumTypes.ImagePositionType.IMAGE_PALM_LEFT_INTERDIGITAL);
            put("PDB_15.bin", CommonEnumTypes.ImagePositionType.IMAGE_PALM_LEFT_THENAR);
            put("PDB_16.bin", CommonEnumTypes.ImagePositionType.IMAGE_PALM_LEFT_HYPOTHENAR);
        }
    };

    int terminalId_;

    public ProtoBuilder(int terminalId) {
        terminalId_ = terminalId;
    }

    public InquiryService.PBInquiryJobRequest buildFingerInquiryJobRequest(Path templatePath) throws IOException {
        val builder = InquiryService.PBInquiryJobRequest.newBuilder();
        builder.setJobInfo(buildPBInquiryJobInfo());
        builder.addFusionJobInput(buildPBFusionJobInput(templatePath));
        return builder.build();
    }

    private InquiryPayloads.PBInquiryJobInfo buildPBInquiryJobInfo() {
        val builder = InquiryPayloads.PBInquiryJobInfo.newBuilder();
        builder.setFunction(inquiryFunctionTypes_.get(search_.getFunction()));
        builder.setMaxCandidate(search_.getMaxCandidates());
        builder.setPriority(search_.getPriority());

        val buff = new StringBuffer(inquiryProto_.getCallbackUrl()).append(":").append(inquiryProto_.getCallbackPort())
                .toString();
        builder.setCallBackUrl(buff);
        return builder.build();
    }

    private InquiryPayloads.PBFusionJobInput buildPBFusionJobInput(Path templatePath) throws IOException {
        val builder = InquiryPayloads.PBFusionJobInput.newBuilder();
        builder.setScopes(buildPBPbInquiryScopeOptions());
        builder.setKeyedTemplateData(buildPBPbKeyedTemplateData(templatePath));
        return builder.build();
    }

    private CommonPayloads.PBInquiryScopeOptions buildPBPbInquiryScopeOptions() {
        val builder = CommonPayloads.PBInquiryScopeOptions.newBuilder();
        val containers = Splitter.on(",").trimResults().split(ParameterReader.getSearch().getContainer());
        builder.addScope(1);
        for (val container : containers) {
            if (container.equalsIgnoreCase("333") || container.equalsIgnoreCase("331")) {
                builder.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_ROLLED);
            } else if (container.equalsIgnoreCase("334") || container.equalsIgnoreCase("332")) {
                builder.addTargetFingerPrint(FingerPrintType.FINGER_PRINT_SLAP);
            }
        }
        return builder.build();
    }

    private CommonPayloads.PBKeyedTemplateData buildPBPbKeyedTemplateData(Path templatePath) throws IOException {
        val builder = CommonPayloads.PBKeyedTemplateData.newBuilder();
        builder.setKeyedTemplate(buildPBKeyedTemplate(templatePath));
        return builder.build();
    }

    private CommonPayloads.PBKeyedTemplate buildPBKeyedTemplate(Path templatePath) throws IOException {
        val builder = CommonPayloads.PBKeyedTemplate.newBuilder();
        builder.setTemplateBinary(ByteString.copyFrom(Files.readAllBytes(templatePath)));
        builder.setKey(templateFormatTypes_.get(search_.getFunction()));
        if (search_.getFunction().equalsIgnoreCase("TI-M") || search_.getFunction().equalsIgnoreCase("TLI-M")) {
            builder.setIndexer(buildPBKeyedTemplateIndexer(templatePath));
        }
        return builder.build();
    }

    private CommonPayloads.PBKeyedTemplateIndexer buildPBKeyedTemplateIndexer(Path templatePath) throws IOException {
        val index1 = templatePath.toString().lastIndexOf("_");
        val index2 = templatePath.toString().lastIndexOf(".");
        val fingerType = templatePath.toString().substring(index1 + 1, index2);
        logger.info("finger type:{}", fingerType);

        val builder = CommonPayloads.PBKeyedTemplateIndexer.newBuilder();
        if (fingerType.equalsIgnoreCase("slap")) {
            builder.setFingerPrintType(FingerPrintType.FINGER_PRINT_SLAP);
        } else if (fingerType.equalsIgnoreCase("rolled")) {
            builder.setFingerPrintType(FingerPrintType.FINGER_PRINT_ROLLED);
        }
        return builder.build();
    }

    public JobCommonService.PBJobResultRequest buildPBJobResultRequest(String jobId) {
        val builder = JobCommonService.PBJobResultRequest.newBuilder();
        builder.setJobId(Long.valueOf(jobId));
        return builder.build();
    }

    public ExtractService.PBExtractJobBinaryRequest buildPBExtractJobBinaryRequest(
            List<CommonPayloads.PBKeyedTemplate> templates, String jobId) {
        val builder = ExtractService.PBExtractJobBinaryRequest.newBuilder();
        builder.addAllKeyedTemplate(templates);
        builder.setJobId(Long.valueOf(jobId));
        return builder.build();
    }

    public ExtractService.PBExtractJobRequest buildFingerExtractJobRequest(Map<Integer, Image> images,
                                                                           String externalId) {
        val builder = ExtractService.PBExtractJobRequest.newBuilder();
        val buff =
                new StringBuffer(inquiryProto_.getCallbackUrl()).append(":").append(extractionProto_.getCallbackPort())
                        .toString();
        builder.setCallBackUrl(buff);
        builder.setInputPayload(ExtractPayloads.PBExtractInputPayload.newBuilder()
                .setTenprintInput(buildPBPbExtractTenprintInput(images, externalId)).build());
        return builder.build();
    }

    public ExtractService.PBExtractJobRequest buildLatentFingerExtractJobRequest(Triple<Path, Path, Path> paths)
            throws IOException {
        val builder = ExtractService.PBExtractJobRequest.newBuilder();
        val buff = new StringBuffer(inquiryProto_.getCallbackUrl()).append(":").append(inquiryProto_.getCallbackPort())
                .toString();
        builder.setCallBackUrl(buff);
        builder.setInputPayload(
                ExtractPayloads.PBExtractInputPayload.newBuilder().setLatentInput(buildPBPbExtractLatentInput(paths))
                        .build());
        return builder.build();
    }

    private ExtractPayloads.PBExtractTenprintInput buildPBPbExtractTenprintInput(Map<Integer, Image> fingerImages,
                                                                                 String externalId) {
        val builder = ExtractPayloads.PBExtractTenprintInput.newBuilder();
        builder.addAllAimFormats(buildPBPbAimFormat());
        builder.addAllImages(buildPBExtractInputImage(fingerImages));
        builder.setCmlOptions(
                ExtractPayloads.PBExtractCMLOptions.newBuilder().setParameterId(extraction_.getCmlOption()).build());
        builder.setCommonOptions(ExtractPayloads.PBExtractCommonOptionTenprint.newBuilder()
                .setOutputMode(ExtractEnumTypes.ExtractOutputModeType.EXTRACT_OUTPUT_MODE_ALL)
                .setReturnCroppedImages(true).build());
        return builder.build();
    }

    private List<ExtractPayloads.PBAimFormat> buildPBPbAimFormat() {
        val formats = new ArrayList<ExtractPayloads.PBAimFormat>();
        val aimFormats = Splitter.on(",").trimResults().split(extraction_.getAimFormats());
        for (val format : aimFormats) {
            val builder = ExtractPayloads.PBAimFormat.newBuilder();
            builder.setFormat(templateFormatTypes_.get(format));
            formats.add(builder.build());
        }
        return formats;
    }

    private List<ExtractPayloads.PBExtractInputImage> buildPBExtractInputImage(Map<Integer, Image> fingerImages) {
        val images = new ArrayList<ExtractPayloads.PBExtractInputImage>();

        for (val fingerNumber : fingerImages.keySet()) {
            val image = fingerImages.get(fingerNumber);
            val builder = ExtractPayloads.PBExtractInputImage.newBuilder();
            builder.setPosition(imagePositionTypes.get(fingerNumber));
            builder.setType(imageFormatTypes_.get(image.getType()));
            builder.setBpp(image.getDpi());
            if (!Objects.isNull(image.getWidth())) {
                builder.setWidth(image.getWidth());
            }
            if (!Objects.isNull(image.getHeight())) {
                builder.setHeight(image.getHeight());
            }
            builder.setData(ByteString.copyFrom(ArrayUtils.toPrimitive(image.getData())));
            images.add(builder.build());
        }
        return images;
    }

    private ExtractPayloads.PBExtractInputImage buildPBExtractInputImage(Image image) {
        val builder = ExtractPayloads.PBExtractInputImage.newBuilder();
        builder.setType(imageFormatTypes_.get(image.getType()));
        builder.setBpp(image.getDpi());
        if (!Objects.isNull(image.getWidth())) {
            builder.setWidth(image.getWidth());
        }
        if (!Objects.isNull(image.getHeight())) {
            builder.setHeight(image.getHeight());
        }
        builder.setData(ByteString.copyFrom(ArrayUtils.toPrimitive(image.getData())));
        return builder.build();
    }

    private ExtractPayloads.PBExtractLatentInput buildPBPbExtractLatentInput(Triple<Path, Path, Path> paths)
            throws IOException {
        val builder = ExtractPayloads.PBExtractLatentInput.newBuilder();
        builder.addAllAimFormats(buildPBPbAimFormat());

        builder.setImage(buildPBExtractInputImage(createNist27LatentImage(paths.getLeft())));
        if (!Objects.isNull(paths.getMiddle())) {
            builder.setMinutia(buildPBExtractInputMinutiaLatent(paths.getMiddle()));
        }
        if (!Objects.isNull(paths.getRight())) {
            builder.setMarkUp(buildPBExtractInputMarkUp(paths.getRight()));
        }

        builder.setCommonOptions(ExtractPayloads.PBExtractCommonOptionLatent.newBuilder()
                .setOutputMode(ExtractEnumTypes.ExtractOutputModeType.EXTRACT_OUTPUT_MODE_ALL).build());
        return builder.build();
    }

    private Image createNist27LatentImage(Path path) {
        val image = new Image();
        try {
            image.setDpi(Integer.parseInt("500"));
            image.setWidth(extraction_.getSpecialDatabase27().getWidth());
            image.setHeight(extraction_.getSpecialDatabase27().getHeight());
            image.setType("RAW");
            image.setData(org.apache.commons.lang.ArrayUtils.toObject(Files.readAllBytes(path)));

            // finger number
            // format is SD27P.287.03.raw
            val pathStr = path.toString();
            val lastIndex = pathStr.length() - ".raw".length();
            val index = path.toString().lastIndexOf(".", lastIndex - 1);
            image.setFile(path);
        } catch (Exception ex) {
            logger.error(Throwables.getStackTraceAsString(ex));
        } finally {
        }
        return image;
    }

    private ExtractPayloads.PBExtractInputMinutiaLatent buildPBExtractInputMinutiaLatent(Path path) throws IOException {
        val builder = ExtractPayloads.PBExtractInputMinutiaLatent.newBuilder();
        builder.setType(ExtractEnumTypes.MinutiaType.MINUTIA_BT5);
        builder.setMinutiaData(ByteString.copyFrom((Files.readAllBytes(path))));
        return builder.build();
    }

    private ExtractPayloads.PBExtractInputMarkUp buildPBExtractInputMarkUp(Path path) throws IOException {
        val builder = ExtractPayloads.PBExtractInputMarkUp.newBuilder();
        builder.setMarkUpData(ByteString.copyFrom((Files.readAllBytes(path))));
        return builder.build();
    }

    public ExtractService.PBExtractJobRequest buildPalmExtractJobRequest(Map<Integer, Image> images,
                                                                         String externalId) {
        val builder = ExtractService.PBExtractJobRequest.newBuilder();
        val buff =
                new StringBuffer(inquiryProto_.getCallbackUrl()).append(":").append(extractionProto_.getCallbackPort())
                        .toString();
        builder.setCallBackUrl(buff);
        builder.setInputPayload(ExtractPayloads.PBExtractInputPayload.newBuilder()
                .setTenprintInput(buildPBPbExtractTenprintInput(images, externalId)).build());
        return builder.build();
    }

    public ExtractService.PBExtractJobRequest buildLatentPalmExtractJobRequest(Map<Integer, Image> images)
            throws IOException {
        val builder = ExtractService.PBExtractJobRequest.newBuilder();
        val buff = new StringBuffer(inquiryProto_.getCallbackUrl()).append(":").append(inquiryProto_.getCallbackPort())
                .toString();
        builder.setCallBackUrl(buff);
        builder.setInputPayload(ExtractPayloads.PBExtractInputPayload.newBuilder()
                .setLatentInput(buildPBPbExtractLatentInput(images.get(20))).build());
        return builder.build();
    }

    private ExtractPayloads.PBExtractLatentInput buildPBPbExtractLatentInput(Image image) throws IOException {
        val builder = ExtractPayloads.PBExtractLatentInput.newBuilder();
        builder.addAllAimFormats(buildPBPbAimFormat());
        builder.setImage(buildPBExtractInputImage(image));
        builder.setCommonOptions(ExtractPayloads.PBExtractCommonOptionLatent.newBuilder()
                .setOutputMode(ExtractEnumTypes.ExtractOutputModeType.EXTRACT_OUTPUT_MODE_ALL).build());
        return builder.build();
    }

    public SyncService.PBSyncJobRequest buildInsertJobRequest(String externalId, int eventId, Path templatePath,
                                                              int binId) throws IOException {
        val builder = SyncService.PBSyncJobRequest.newBuilder();
        builder.setFunction(SyncEnumTypes.SyncFunctionType.INSERT);
        builder.setExternalId(externalId);
        builder.setEventId(eventId);
        builder.setInsertPayload(buildPBPbSyncInsertPayload(templatePath, binId));
        return builder.build();
    }

    private SyncService.PBSyncJobRequest.PBSyncInsertPayload buildPBPbSyncInsertPayload(Path templatePath, int binId)
            throws IOException {
        val builder = SyncService.PBSyncJobRequest.PBSyncInsertPayload.newBuilder();
        builder.addKeyedTemplateData(buildPBPbKeyedTemplateData(templatePath, binId));
        return builder.build();
    }

    private CommonPayloads.PBKeyedTemplateData buildPBPbKeyedTemplateData(Path templatePath, int binId)
            throws IOException {
        val builder = CommonPayloads.PBKeyedTemplateData.newBuilder();
        builder.setKeyedTemplate(buildPBKeyedTemplate(templatePath, binId));
        return builder.build();
    }

    private CommonPayloads.PBKeyedTemplate buildPBKeyedTemplate(Path templatePath, int binId) throws IOException {
        val builder = CommonPayloads.PBKeyedTemplate.newBuilder();
        builder.setTemplateBinary(ByteString.copyFrom(Files.readAllBytes(templatePath)));
        val templateFormatType = templateFormatTypes_.get(String.valueOf(binId));
        builder.setKey(templateFormatType);

        val indexerBuilder = CommonPayloads.PBKeyedTemplateIndexer.newBuilder();
        if (templateFormatType == TemplateFormatType.TEMPLATE_RDBTM) {
            if (templatePath.toString().contains("_-_RDBTM")) {
                indexerBuilder.setFingerPrintType(FingerPrintType.FINGER_PRINT_ROLLED);
            } else if (templatePath.toString().contains("_-_SDBTM")) {
                indexerBuilder.setFingerPrintType(FingerPrintType.FINGER_PRINT_SLAP);
            } else {

                val type = insert_.getFingerType();
                if (!Objects.isNull(type)) {
                    if (type.equalsIgnoreCase("roll")) {
                        indexerBuilder.setFingerPrintType(FingerPrintType.FINGER_PRINT_ROLLED);
                    } else if (type.equalsIgnoreCase("slap")) {
                        indexerBuilder.setFingerPrintType(FingerPrintType.FINGER_PRINT_SLAP);
                    }
                }
            }
            builder.setIndexer(indexerBuilder);
        } else if (templateFormatType == TemplateFormatType.TEMPLATE_RDBLM ||
                templateFormatType == TemplateFormatType.TEMPLATE_PDB) {
            val index = templatePath.toString().indexOf(SPLIT);
            val key = templatePath.toString().substring(index + SPLIT.length());
            indexerBuilder.setPosition(imagePositionTypes_.get(key));
            builder.setIndexer(indexerBuilder);
        }

        return builder.build();
    }

    public SyncService.PBSyncJobRequest buildDeleteJobRequest(String externalId, List<Integer> contianerIds,
                                                              Integer eventId) throws IOException {
        val builder = SyncService.PBSyncJobRequest.newBuilder();
        builder.setFunction(SyncEnumTypes.SyncFunctionType.DELETE);
        builder.setExternalId(externalId);
        builder.setEventId(eventId);
        builder.setDeletePayload(buildPBPbSyncDeletePayload(contianerIds));
        return builder.build();
    }

    private SyncService.PBSyncJobRequest.PBSyncDeletePayload buildPBPbSyncDeletePayload(List<Integer> binIds)
            throws IOException {
        val builder = SyncService.PBSyncJobRequest.PBSyncDeletePayload.newBuilder();
        for (val binId : binIds) {
            builder.addKeyedTemplate(buildPBKeyedTemplate(binId));
        }
        return builder.build();
    }

    private CommonPayloads.PBKeyedTemplate buildPBKeyedTemplate(int binId) throws IOException {
        val builder = CommonPayloads.PBKeyedTemplate.newBuilder();
        val templateFormatType = templateFormatTypes_.get(String.valueOf(binId));
        builder.setKey(templateFormatType);
        return builder.build();
    }
}
