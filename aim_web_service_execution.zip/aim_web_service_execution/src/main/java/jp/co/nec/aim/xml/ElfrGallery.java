package jp.co.nec.aim.xml;

import org.simpleframework.xml.Element;

import lombok.Data;

@Data
public class ElfrGallery {
	@Element
	String fixedCandidateId;
	
	@Element
	String fixedFingerNumber;
	
	@Element
	String selectedImage;
	
	@Element
	String j2kPath;
	
	@Element
	String wsqPath;
	
	@Element
	int numUsingFile;
	
	@Element
	int numFingerByCandidate;
	
	@Element
	int numFew;

}
