package jp.co.nec.aim.http;

import com.google.protobuf.GeneratedMessage;
import jp.co.nec.aim.message.proto.ExtractService;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobResponse;
import jp.co.nec.aim.message.proto.InquiryService;
import jp.co.nec.aim.message.proto.SyncService;
import jp.co.nec.aim.search.SearchClient;
import jp.co.nec.aim.xml.ParameterReader;
import jp.co.nec.aim.xml.Proto;
import lombok.var;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Optional;

public class HttpClient {
    final static Logger logger = LoggerFactory.getLogger(SearchClient.class);

    final static Proto searchProto_ = ParameterReader.getSearch().getProto();

    final static Proto extractionProto_ = ParameterReader.getExtraction().getProto();

    final static Proto syncProto_ = ParameterReader.getSync().getProto();

    public static Optional<InquiryService.PBInquiryJobResponse> post(InquiryService.PBInquiryJobRequest message) throws IOException {
        var response = innerPost(message, searchProto_.getUrl());
        if (response.isPresent()) {
            return Optional.of(InquiryService.PBInquiryJobResponse.parseFrom(response.get()));
        }
        return Optional.empty();
    }

    public static Optional<PBExtractJobResponse> post(ExtractService.PBExtractJobRequest message) throws IOException {
        var response = innerPost(message, extractionProto_.getUrl());
        if (response.isPresent()) {
            return Optional.of(PBExtractJobResponse.parseFrom(response.get()));
        }
        return Optional.empty();
    }

    public static Optional<SyncService.PBSyncJobResponse> post(SyncService.PBSyncJobRequest message) throws IOException {
        var response = innerPost(message, syncProto_.getUrl());
        if (response.isPresent()) {
            return Optional.of(SyncService.PBSyncJobResponse.parseFrom(response.get()));
        }
        return Optional.empty();
    }

    private static <T extends GeneratedMessage> Optional<byte[]> innerPost(T message, String url) throws IOException {
        var mediaType = MediaType.parse("application/x-protobuf; charset=utf-8");
        var requestBody = RequestBody.create(message.toByteArray(), mediaType);
        var request = new Request.Builder().url(url).post(requestBody).build();
        var client = new OkHttpClient();
        try (var response = client.newCall(request).execute()) {
            logger.info("HTTP response code:{}, ", response.code());
            if (response.isSuccessful()) {
                return Optional.of(response.body().bytes());
            }
            return Optional.empty();
        }
    }
}
