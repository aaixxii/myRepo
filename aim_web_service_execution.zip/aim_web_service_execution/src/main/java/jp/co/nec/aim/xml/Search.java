package jp.co.nec.aim.xml;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.simpleframework.xml.Element;

@NoArgsConstructor
@Data
public class Search {
//	@Element(required=false)
//	LfmlSearch lfmlSearch;

	@Element(required=true)
	String filter;
	
	@Element(required=true)
	String function;
	
	@Element(required=true)
	String templatePath;
	
	@Element(required=true)
	Soap soap;

	@Element(required=true)
	Proto proto;

	@Element(required=true)
	String container;
	
	@Element(required=true)
	boolean consolidateByContainer;
	
	@Element(required=true)
	boolean multiRecordCandidates;
	
	@Element(required=true)
	int maxCandidates;
	
	@Element(required=true)
	int minScore;
	
	@Element(required=true)
	int priority;
}
