package jp.co.nec.aim.xml;

import org.simpleframework.xml.Default;
import org.simpleframework.xml.Element;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class ImageEnhance {
	@Element(required=false)
	String latent;
	
	@Element(required=false)
	String tenprint;
}
