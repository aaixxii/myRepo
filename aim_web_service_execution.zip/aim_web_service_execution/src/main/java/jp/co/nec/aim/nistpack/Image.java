package jp.co.nec.aim.nistpack;

import java.nio.file.Path;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class Image {
	Byte data[];
	
	int dpi;
	
	Integer width;
	
	Integer height;
	
	String type;
	
	Path file;
}
