package jp.co.nec.aim.soap;

import java.io.IOException;
import java.io.StringWriter;

import javax.xml.bind.JAXBElement;
import javax.xml.transform.Source;
import javax.xml.transform.TransformerException;
import javax.xml.transform.stream.StreamResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.SoapMessage;

import jp.co.nec.aim.soap.CallbackTest;
import jp.co.nec.aim.soap.CallbackTestResponse;
import jp.co.nec.aim.soap.Delete;
import jp.co.nec.aim.soap.DeleteResponse;
import jp.co.nec.aim.soap.Extract;
import jp.co.nec.aim.soap.ExtractResponse;
import jp.co.nec.aim.soap.GetExtractJobBinary;
import jp.co.nec.aim.soap.GetExtractJobBinaryResponse;
import jp.co.nec.aim.soap.GetExtractJobResult;
import jp.co.nec.aim.soap.GetExtractJobResultResponse;
import jp.co.nec.aim.soap.GetSearchJobResult;
import jp.co.nec.aim.soap.GetSearchJobResultResponse;
import jp.co.nec.aim.soap.Insert;
import jp.co.nec.aim.soap.InsertResponse;
import jp.co.nec.aim.soap.ObjectFactory;
import jp.co.nec.aim.soap.Search;
import jp.co.nec.aim.soap.SearchResponse;
import lombok.val;

@SuppressWarnings("unchecked")
public class SoapClient extends WebServiceGatewaySupport {
	final static Logger logger = LoggerFactory.getLogger(SoapClient.class);

	final ObjectFactory factory = new ObjectFactory();

	// public ExtractResponse extract(String endpoint, Extract request) {
	// val response =
	// (JAXBElement<ExtractResponse>)getWebServiceTemplate().marshalSendAndReceive(
	// endpoint, factory.createExtract(request));
	// return response.getValue();
	// }

	public ExtractResponse extract(String endpoint, Extract request) {
		val response = (JAXBElement<ExtractResponse>)getWebServiceTemplate().marshalSendAndReceive(
			endpoint, factory.createExtract(request), new WebServiceMessageCallback() {
				@Override
				public void doWithMessage(WebServiceMessage message)
					throws IOException, TransformerException {
					SoapMessage soapMessage = (SoapMessage)message;
					soapMessage.getEnvelope().addNamespaceDeclaration("ws",
						"http://ws.mm.aim.nec.co.jp/");
				}
			});
		return response.getValue();
	}

	public String extract(String endpoint, Source request) {
		StreamResult result = new StreamResult(new StringWriter());
		getWebServiceTemplate().sendSourceAndReceiveToResult(endpoint, request, result);
		return result.getWriter().toString();
	}

	public GetExtractJobBinaryResponse getExtractJobBinary(
		String endpoint,
		GetExtractJobBinary request) {
		val response = (JAXBElement<GetExtractJobBinaryResponse>)getWebServiceTemplate()
			.marshalSendAndReceive(endpoint, factory.createGetExtractJobBinary(request));
		return response.getValue();
	}

	public InsertResponse insert(String endpoint, Insert job) {
		val response = (JAXBElement<InsertResponse>)getWebServiceTemplate().marshalSendAndReceive(
			endpoint, factory.createInsert(job));
		return response.getValue();
	}

	public DeleteResponse delete(String endpoint, Delete job) {
		val response = (JAXBElement<DeleteResponse>)getWebServiceTemplate().marshalSendAndReceive(
			endpoint, factory.createDelete(job));
		return response.getValue();
	}

	public GetExtractJobResultResponse getExtractJobResult(
		String endpoint,
		GetExtractJobResult request) {
		val response = (JAXBElement<GetExtractJobResultResponse>)getWebServiceTemplate()
			.marshalSendAndReceive(endpoint, factory.createGetExtractJobResult(request));
		return response.getValue();
	}

	public CallbackTestResponse callbackTest(String endpoint, CallbackTest job) {
		val response = (JAXBElement<CallbackTestResponse>)getWebServiceTemplate()
			.marshalSendAndReceive(endpoint, factory.createCallbackTest(job));
		return response.getValue();
	}

	public SearchResponse search(String endpoint, Search request) {
		val response = (JAXBElement<SearchResponse>)getWebServiceTemplate().marshalSendAndReceive(
			endpoint, factory.createSearch(request));
		return response.getValue();
	}

	public GetSearchJobResultResponse getSearchJobResult(
		String endpoint,
		GetSearchJobResult request) {
		val response = (JAXBElement<GetSearchJobResultResponse>)getWebServiceTemplate()
			.marshalSendAndReceive(endpoint, factory.createGetSearchJobResult(request));
		return response.getValue();
	}

	/*
	 * public SubmitVerificationJobResponse submitVerificationJob( String
	 * endpoint, SubmitVerificationJob job) { val response =
	 * (JAXBElement<SubmitVerificationJobResponse>)getWebServiceTemplate()
	 * .marshalSendAndReceive(endpoint,
	 * factory.createSubmitVerificationJob(job)); return response.getValue(); }
	 * 
	 * public String submitVerificationJob(String endpoint, Source request) {
	 * StreamResult result = new StreamResult(new StringWriter());
	 * getWebServiceTemplate().sendSourceAndReceiveToResult(endpoint, request,
	 * result); return result.getWriter().toString(); }
	 * 
	 */
}
