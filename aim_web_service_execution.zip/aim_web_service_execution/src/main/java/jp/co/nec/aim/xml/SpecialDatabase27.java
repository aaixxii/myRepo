package jp.co.nec.aim.xml;

import org.simpleframework.xml.Element;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class SpecialDatabase27 {
	@Element(required=true)
	boolean enable;
	
	@Element(required=false)
	String rolledPath;

	@Element(required=false)
	String slapPath;

	@Element(required=false)
	String bt5Path;
	
	@Element(required=false)
	String latentPath;

	@Element(required=false)
	String roiPath;
	
	@Element(required=true)
	int width;

	@Element(required=true)
	int height;
}
