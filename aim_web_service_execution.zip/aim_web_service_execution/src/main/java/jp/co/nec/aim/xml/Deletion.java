package jp.co.nec.aim.xml;

import java.util.List;

import org.simpleframework.xml.Element;
import org.simpleframework.xml.ElementList;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class Deletion {
	@ElementList(entry="containerIds", type=Integer.class, inline=true, required=false)
	List<Integer> containerIds;
	
	@ElementList(entry="externalIds", type=String.class, inline=true, required=false)
	List<String> externalIds;
	
	@Element(required=false)
	Integer eventId;

}
