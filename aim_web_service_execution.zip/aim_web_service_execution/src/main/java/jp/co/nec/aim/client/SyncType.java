package jp.co.nec.aim.client;

public enum SyncType {
	INSERT, DELETE, UPDATE
}
