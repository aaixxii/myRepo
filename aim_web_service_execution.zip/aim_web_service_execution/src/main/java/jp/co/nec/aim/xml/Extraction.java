package jp.co.nec.aim.xml;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.simpleframework.xml.Element;

@NoArgsConstructor
@Data
public class Extraction {
    @Element(required = true)
    String outputTemplatePath;

    @Element(required = true)
    int cmlOption;

    @Element(required = true)
    boolean imageEnable;

    @Element(required = true)
    boolean bt5Enable;

    @Element(required = false)
    String bt5Path;

    @Element(required = true)
    SpecialDatabase27 specialDatabase27;

    @Element(required = true)
    int numSendingRequestThread;

    @Element(required = false)
    Soap soap;

    @Element(required = false)
    Proto proto;

    @Element(required = false)
    String latentPatterns;

    @Element(required = false)
    String selectFingers;

    @Element(required = false)
    String primaryPatterns;

    @Element(required = false)
    String referencePatterns;

    @Element
    NeoFace neoFace;

    @Element
    Point point;

    @Element
    String manualCrop;

    @Element(required = false)
    String selectPalms;

    @Element
    boolean blackOnWhite;

    @Element
    int numPalmNistFile;

    @Element
    String aimFormats;

    @Element
    String nistType14Path;

    @Element
    String nistType15Path;

    @Element
    int nistType;

    @Element
    int numIrisPair;

    @Element
    String irisPath;

    @Element
    int numFaceFile;

    @Element
    String facePath;

    @Element
    String algorithm;

    @Element
    int numFingerNistFile;

    @Element
    int numReceptionThread;

    @Element
    int numZmqIoThread;

    @Element
    String nistType4Path;

}
