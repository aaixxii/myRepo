package jp.co.nec.aim.xml;

import org.simpleframework.xml.Element;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class FingerAutoCorrection {
	@Element(required=true)
	int index;
	
	@Element(required=false)
	String fingerAutoCorrection;
	
	@Element(required=false)
	String slapConfidenceThreshold;
	
	@Element(required=false)
	String slapHandConfidenceThreshold;
	
	@Element(required=false)
	String duplicationCheckScoreThreshold;
	
	@Element(required=false)
	String sequenceCheckScoreThreshold;
	
	@Element(required=false)
	String sequenceCheckScoreThresholdLittle; 
}
