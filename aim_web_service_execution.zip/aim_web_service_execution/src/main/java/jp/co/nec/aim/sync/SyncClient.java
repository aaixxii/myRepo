package jp.co.nec.aim.sync;

import java.io.IOException;
import java.io.StringWriter;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

import javax.xml.transform.stream.StreamResult;

import jp.co.nec.aim.client.ProtoCallbackHandler;
import jp.co.nec.aim.client.SoapCallbackHandler;
import jp.co.nec.aim.http.HttpClient;
import jp.co.nec.aim.message.proto.SyncService;
import jp.co.nec.proto.ProtoBuilder;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import com.google.common.base.Stopwatch;
import com.google.common.base.Throwables;
import com.google.common.collect.Lists;
import com.sun.net.httpserver.HttpServer;

import jp.co.nec.aim.SendingRequestController;
import jp.co.nec.aim.client.SyncType;
import jp.co.nec.aim.nistpack.NistReader;
import jp.co.nec.aim.soap.Delete;
import jp.co.nec.aim.soap.Insert;
import jp.co.nec.aim.soap.ObjectFactory;
import jp.co.nec.aim.soap.SoapBuilder;
import jp.co.nec.aim.soap.SoapClient;
import jp.co.nec.aim.xml.ParameterReader;
import jp.co.nec.aim.xml.Sync;
import lombok.val;

@SuppressWarnings("boxing")
public class SyncClient {
    final static Logger logger = LoggerFactory.getLogger(SyncClient.class);

    ExecutorService sendingExecutor_ = Executors.newFixedThreadPool(1);

    Map<String, Pair<AtomicInteger, Stopwatch>> map_ =
            new ConcurrentHashMap<>(ParameterReader.getExtraction().getNumZmqIoThread());

    AnnotationConfigApplicationContext appContext_;

    final Sync sync_ = ParameterReader.getSync();

    ConcurrentHashMap<String, Pair<String, Stopwatch>> turnAroundTime_ = new ConcurrentHashMap<>();

    HttpServer httpServer_;

    /**
     * @param appContext
     */
    public SyncClient(AnnotationConfigApplicationContext appContext) {
        appContext_ = appContext;
    }

    /**
     * @throws Exception
     */
    public void sendSyncRequestWithSoap(SyncType syncType) throws Exception {
        try {
            // 1 == extraction.getNumZmqIoThread()
            val reqContoroller = new SendingRequestController<String>(1);
            val endpoint = new ArrayList<String>();

            val port = sync_.getSoap().getCallbackPort();
            httpServer_ = HttpServer.create(new InetSocketAddress(Integer.valueOf(port)), 4);
            httpServer_.createContext("/",
                    new SoapCallbackHandler(appContext_, SoapCallbackHandler.ProcessType.SYNC, reqContoroller,
                            turnAroundTime_, null, 0));
            httpServer_.setExecutor(null);
            httpServer_.start();

            sendingExecutor_.submit(new SendingSoapClient(syncType, reqContoroller, endpoint));

            logger.info("waiting for all threads terminated");

            // receptionExecutor_.shutdown();
            sendingExecutor_.shutdown();
            while (!Thread.currentThread().isInterrupted()) {
                Thread.sleep(1000);
                if (sendingExecutor_.isTerminated()) {
                    break;
                }
            }
            logger.info("stopping the main thread");
        } catch (Exception ex) {
            logger.info(Throwables.getStackTraceAsString(ex));
        } finally {
        }
    }

    public void sendSyncRequestWithProto(SyncType syncType) throws Exception {
        try {
            // 1 == extraction.getNumZmqIoThread()
            val reqContoroller = new SendingRequestController<String>(1);
            val endpoint = new ArrayList<String>();

            val port = sync_.getSoap().getCallbackPort();
            httpServer_ = HttpServer.create(new InetSocketAddress(Integer.valueOf(port)), 4);
            httpServer_.createContext("/",
                    new ProtoCallbackHandler(ProtoCallbackHandler.ProcessType.SYNC, reqContoroller, turnAroundTime_,
                            null, 0));
            httpServer_.setExecutor(null);
            httpServer_.start();

            sendingExecutor_.submit(new SendingProtoClient(syncType, reqContoroller, endpoint));

            logger.info("waiting for all threads terminated");

            // receptionExecutor_.shutdown();
            sendingExecutor_.shutdown();
            while (!Thread.currentThread().isInterrupted()) {
                Thread.sleep(1000);
                if (sendingExecutor_.isTerminated()) {
                    break;
                }
            }
            logger.info("stopping the main thread");
        } catch (Exception ex) {
            logger.info(Throwables.getStackTraceAsString(ex));
        } finally {
        }
    }

    private List<Path> getCapsuleList() throws Exception {
        val list = new ArrayList<Path>();
        final List<String> templatePaths = Lists.newArrayList();
        if (!Objects.isNull(sync_.getInsert().getTemplateDirectory())) {
            templatePaths.addAll(sync_.getInsert().getTemplateDirectory());
        }
        for (val dir : templatePaths) {
            try (Stream<Path> stream = Files.list(Paths.get(dir))) {
                stream.filter(path -> path.toString().matches(sync_.getInsert().getFilter()))
                        .filter(path -> path.toFile().isFile()).forEach(path -> {
                    list.add(path);
                });
            } catch (Exception ex) {
                logger.error(Throwables.getStackTraceAsString(ex));
                throw ex;
            }
        }

        logger.info("the number of capsules : {}", list.size());
        return list;
    }

    class SendingSoapClient extends Thread {
        final Map<Integer, Integer> slapPositionMap_ = new HashMap() {
            private static final long serialVersionUID = 1L;

            {
                put(1, 11);
                put(2, 40);
                put(3, 41);
                put(4, 42);
                put(5, 43);
                put(6, 12);
                put(7, 44);
                put(8, 45);
                put(9, 46);
                put(10, 47);
            }
        };

        SendingRequestController<String> reqController_;

        List<String> endpoint_;

        Random random_ = new Random();

        SoapClient client_ = appContext_.getBean(SoapClient.class);

        SyncType syncType_;

        int terminalId_ = 0;

//        String capsulePath_ = ParameterReader.getSync().getInsert().getTemplatePath();

        public SendingSoapClient(SyncType syncType, SendingRequestController<String> controller,
                                 List<String> endPoint) {
            syncType_ = syncType;
            reqController_ = controller;
            endpoint_ = endPoint;
        }

        @Override
        public void run() {
            if (syncType_ == SyncType.DELETE) {
                processDeletionRequest();
                return;
            }

            val algorithm = ParameterReader.getExtraction().getAlgorithm();
            if (algorithm.equalsIgnoreCase("finger")) {
                processFingerCapsuleRequest();
            } else if (algorithm.equalsIgnoreCase("niris") || algorithm.equalsIgnoreCase("delta_id")) {
                // processIrisRequest();
            } else if (algorithm.equalsIgnoreCase("palm")) {
                //				processPalmRequest();
            }
        }

        /**
         * @param pair
         * @throws Exception
         */
        private void addRequestQueue(String value) throws Exception {
            try {
                while (true) {
                    if (reqController_.add(value)) {
                        return;
                    }
                }
            } catch (Exception ex) {
                logger.error(Throwables.getStackTraceAsString(ex));
                throw ex;
            }
        }

        private void processDeletionRequest() {
            try {
                final List<Integer> containerIds = Lists.newArrayList();
                final List<String> externalIds = Lists.newArrayList();

                if (!Objects.isNull(sync_.getDeletion().getExternalIds())) {
                    externalIds.addAll(sync_.getDeletion().getExternalIds());
                }
                if (!Objects.isNull(sync_.getDeletion().getContainerIds())) {
                    containerIds.addAll(sync_.getDeletion().getContainerIds());
                }

                val soapBuilder = new SoapBuilder(terminalId_);
                for (val externalId : externalIds) {
                    logger.info("Next external ID is {}.", externalId);

                    Delete request = soapBuilder.buildDelet(externalId, containerIds, sync_.getDeletion().getEventId());

                    if (sync_.getSoap().isOutputRequest()) {
                        output(request);
                    }

                    client_.delete(sync_.getSoap().getEndpoint(), request);

                    // wait
                    Thread.sleep(500);
                }
            } catch (Exception ex) {
                logger.error(Throwables.getStackTraceAsString(ex));
            } finally {
                httpServer_.stop(0);
            }
            logger.info("stopped a sending thread as {}", Thread.currentThread().getName());
        }

        private void processFingerCapsuleRequest() {
            try {
                addRequestQueue("start job");

                List<Path> paths = getCapsuleList();
                val soapBuilder = new SoapBuilder(terminalId_);
                for (val path : paths) {
                    val fileName = path.toFile().getName();
                    logger.info("Next file is {}.", fileName);

                    int index = fileName.lastIndexOf("_-_");
                    if (35 < index) {
                        index = 35;
                    }
                    val externalId = fileName.substring(0, index);

                    Insert request = null;
                    request = soapBuilder.buildInsert(externalId, sync_.getInsert().getEventId(), path,
                            sync_.getInsert().getBinId());

                    if (sync_.getSoap().isOutputRequest()) {
                        output(request);
                    }

                    // logger.info("waiting for takeing from queue");
                    // String jobId = reqController_.take();
                    // logger.info("got job ID:{} from queue", jobId);

                    client_.insert(sync_.getSoap().getEndpoint(), request);

                    // wait
                    Thread.sleep(500);
                }
                httpServer_.stop(0);
            } catch (Exception ex) {
                logger.error(Throwables.getStackTraceAsString(ex));
            } finally {
            }
            logger.info("stopped a sending thread as {}", Thread.currentThread().getName());
        }

        /**
         *
         */
        private void processPalmRequest() {
            val nistReader = new NistReader();
            try {
                // List<Path> paths = getNistType15FileList();
                // val soapBuilder = new SoapBuilder(terminalId_);
                // for (val path : paths) {
                // val fileName = path.toFile().getName();
                // logger.info("Next file is {}.", fileName);

                // SubmitSyncJob request = null;
                // val map =
                // nistReader.getType15Image(path.toAbsolutePath().toString());
                // request = soapBuilder.buildPalmSubmitSyncJob(map, fileName);
                //
                // if (sync_.getSoap().isOutputRequest()) {
                // output(request);
                // }
                //
                // val stopwatch = Stopwatch.createStarted();
                // val jobId =
                // client_.submitSyncJob(sync_.getSoap().getEndpoint(), request)
                // .getReturn();
                // turnAroundTime_.put(jobId, Pair.of(fileName, stopwatch));

                // val completedJobId = reqController_.take();
                // logger.info("received {}.", completedJobId);
                // }
                httpServer_.stop(0);
            } catch (Exception ex) {
                logger.error(Throwables.getStackTraceAsString(ex));
            } finally {
            }
            logger.info("stopped a sending thread as {}", Thread.currentThread().getName());
        }

        /**
         * @param request
         */
        private void output(Insert request) {
            ObjectFactory factory = new ObjectFactory();
            StreamResult result = new StreamResult(new StringWriter());
            val marshaller = appContext_.getBean(Jaxb2Marshaller.class);
            marshaller.marshal(factory.createInsert(request), result);

            try {
                Files.write(Paths.get("insert_request.xml"), result.getWriter().toString().getBytes());
            } catch (IOException ex) {
                logger.error(Throwables.getRootCause(ex).toString());
            } finally {
            }
        }

        /**
         * @param request
         */
        private void output(Delete request) {
            ObjectFactory factory = new ObjectFactory();
            StreamResult result = new StreamResult(new StringWriter());
            val marshaller = appContext_.getBean(Jaxb2Marshaller.class);
            marshaller.marshal(factory.createDelete(request), result);

            try {
                Files.write(Paths.get("delete_request.xml"), result.getWriter().toString().getBytes());
            } catch (IOException ex) {
                logger.error(Throwables.getRootCause(ex).toString());
            } finally {
            }
        }
    }

    class SendingProtoClient extends Thread {
        final Map<Integer, Integer> slapPositionMap_ = new HashMap() {
            private static final long serialVersionUID = 1L;

            {
                put(1, 11);
                put(2, 40);
                put(3, 41);
                put(4, 42);
                put(5, 43);
                put(6, 12);
                put(7, 44);
                put(8, 45);
                put(9, 46);
                put(10, 47);
            }
        };

        SendingRequestController<String> reqController_;

        List<String> endpoint_;

        Random random_ = new Random();

        SoapClient client_ = appContext_.getBean(SoapClient.class);

        SyncType syncType_;

        int terminalId_ = 0;

//      String capsulePath_ = ParameterReader.getSync().getInsert().getTemplatePath();

        public SendingProtoClient(SyncType syncType, SendingRequestController<String> controller,
                                  List<String> endPoint) {
            syncType_ = syncType;
            reqController_ = controller;
            endpoint_ = endPoint;
        }

        @Override
        public void run() {
            if (syncType_ == SyncType.DELETE) {
                processDeletionRequest();
                return;
            }
            processFingerCapsuleRequest();
        }

        /**
         * @param pair
         * @throws Exception
         */
        private void addRequestQueue(String value) throws Exception {
            try {
                while (true) {
                    if (reqController_.add(value)) {
                        return;
                    }
                }
            } catch (Exception ex) {
                logger.error(Throwables.getStackTraceAsString(ex));
                throw ex;
            }
        }

        private void processDeletionRequest() {
            try {
                final List<Integer> containerIds = Lists.newArrayList();
                final List<String> externalIds = Lists.newArrayList();

                if (!Objects.isNull(sync_.getDeletion().getExternalIds())) {
                    externalIds.addAll(sync_.getDeletion().getExternalIds());
                }
                if (!Objects.isNull(sync_.getDeletion().getContainerIds())) {
                    containerIds.addAll(sync_.getDeletion().getContainerIds());
                }

                val protoBuilder = new ProtoBuilder(terminalId_);
                for (val externalId : externalIds) {
                    logger.info("Next external ID is {}.", externalId);

                    val request = protoBuilder
                            .buildDeleteJobRequest(externalId, containerIds, sync_.getDeletion().getEventId());

                    if (sync_.getSoap().isOutputRequest()) {
                        try {
                            Files.write(Paths.get("delete_request.txt"), request.toString().getBytes());
                        } catch (IOException ex) {
                            logger.error(Throwables.getRootCause(ex).toString());
                        } finally {
                        }
                    }

                    val response = HttpClient.post(request);
                    if (!response.isPresent()) {
                        logger.error("resposne data did not exit.");
                        continue;
                    }

                    // wait
                    Thread.sleep(500);
                }
            } catch (Exception ex) {
                logger.error(Throwables.getStackTraceAsString(ex));
            } finally {
                httpServer_.stop(0);
            }
            logger.info("stopped a sending thread as {}", Thread.currentThread().getName());
        }

        private void processFingerCapsuleRequest() {
            try {
                addRequestQueue("start job");

                List<Path> paths = getCapsuleList();
                val protoBuilder = new ProtoBuilder(terminalId_);
                for (val path : paths) {
                    val fileName = path.toFile().getName();
                    logger.info("Next file is {}.", fileName);

                    //                    int index = fileName.lastIndexOf("_-_");
                    int index = fileName.lastIndexOf(".bin");
                    if (35 < index) {
                        index = 35;
                    }
                    val externalId = fileName.substring(0, index);

                    SyncService.PBSyncJobRequest request = protoBuilder
                            .buildInsertJobRequest(externalId, sync_.getInsert().getEventId(), path,
                                    sync_.getInsert().getBinId());
                    if (sync_.getSoap().isOutputRequest()) {
                        output(request);
                    }

                    // logger.info("waiting for takeing from queue");
                    // String jobId = reqController_.take();
                    // logger.info("got job ID:{} from queue", jobId);
//@@
                    val response = HttpClient.post(request);
                    if (!response.isPresent()) {
                        logger.error("resposne data did not exit.");
                        continue;
                    }

                    // wait
                    Thread.sleep(500);
                }
                httpServer_.stop(0);
            } catch (Exception ex) {
                logger.error(Throwables.getStackTraceAsString(ex));
            } finally {
            }
            logger.info("stopped a sending thread as {}", Thread.currentThread().getName());
        }

        /**
         *
         */
        private void processPalmRequest() {
            val nistReader = new NistReader();
            try {
                // List<Path> paths = getNistType15FileList();
                // val soapBuilder = new SoapBuilder(terminalId_);
                // for (val path : paths) {
                // val fileName = path.toFile().getName();
                // logger.info("Next file is {}.", fileName);

                // SubmitSyncJob request = null;
                // val map =
                // nistReader.getType15Image(path.toAbsolutePath().toString());
                // request = soapBuilder.buildPalmSubmitSyncJob(map, fileName);
                //
                // if (sync_.getSoap().isOutputRequest()) {
                // output(request);
                // }
                //
                // val stopwatch = Stopwatch.createStarted();
                // val jobId =
                // client_.submitSyncJob(sync_.getSoap().getEndpoint(), request)
                // .getReturn();
                // turnAroundTime_.put(jobId, Pair.of(fileName, stopwatch));

                // val completedJobId = reqController_.take();
                // logger.info("received {}.", completedJobId);
                // }
                httpServer_.stop(0);
            } catch (Exception ex) {
                logger.error(Throwables.getStackTraceAsString(ex));
            } finally {
            }
            logger.info("stopped a sending thread as {}", Thread.currentThread().getName());
        }

        /**
         * @param request
         */
        private void output(SyncService.PBSyncJobRequest request) {
            try {
                Files.write(Paths.get("insert_request.txt"), request.toString().getBytes());
            } catch (IOException ex) {
                logger.error(Throwables.getRootCause(ex).toString());
            } finally {
            }
        }
    }
}

// class SoapCallbackHandler implements HttpHandler {
// final static Logger logger = LoggerFactory.getLogger(SoapCallbackHandler.class);
//
// final AnnotationConfigApplicationContext appContext = new
// AnnotationConfigApplicationContext(
// SoapClientConfig.class);
//
// SendingRequestController<String> controller_;
//
// final Path buffXml_ = Paths.get("/dev/shm/unmarshal/SyncJobResult.xml");
//
// // key is job ID and value is NIST file name
// ConcurrentHashMap<String, Pair<String, Stopwatch>> turnAroundTime_;
//
// final Sync sync_ = ParameterReader.getSync();
//
// final Path performancePath_ = Paths.get("./extraction_TAT.txt");
//
// public SoapCallbackHandler(
// SendingRequestController<String> controller,
// ConcurrentHashMap<String, Pair<String, Stopwatch>> turnAroundTime) {
// controller_ = controller;
// turnAroundTime_ = turnAroundTime;
//
// try {
// if (!Files.exists(Paths.get("/dev/shm/unmarshal"))) {
// Files.createDirectory(Paths.get("/dev/shm/unmarshal"));
// }
// } catch (IOException ex) {
// logger.error(Throwables.getRootCause(ex).toString());
// }
// }
//
// @Override
// public void handle(HttpExchange exchange)
// throws IOException {
// String body = IOUtils.toString(exchange.getRequestBody(), "utf-8");
// Files.write(buffXml_, body.getBytes());
// try {
// processSync(body);
// } catch (Exception ex) {
// logger.error(Throwables.getRootCause(ex).toString());
// } finally {
// exchange.sendResponseHeaders(200, 0);
// }
// }
//
// private void addRequestQueue(String str)
// throws Exception {
// try {
// while (true) {
// if (controller_.add(str)) {
// return;
// }
// }
// } catch (Exception ex) {
// logger.error(Throwables.getStackTraceAsString(ex));
// throw ex;
// }
// }
//
// private void processSync(String body)
// throws IOException {
// val obj = JAXB.unmarshal(buffXml_.toFile(), SyncJobResultDto.class);
// if (sync_.getSoap().isOutputResponse()) {
// Files.write(Paths.get("./SyncJobResult.xml"), body.getBytes());
// }
// try {
// addRequestQueue(obj.getJobId());
// } catch (Exception ex) {
// logger.error(Throwables.getRootCause(ex).toString());
// }
// }
// }
