package jp.co.nec.aim.client;

import com.google.common.base.Stopwatch;
import com.google.common.base.Throwables;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import jp.co.nec.aim.FifoQueue;
import jp.co.nec.aim.SendingRequestController;
import jp.co.nec.aim.message.proto.CommonEnumTypes;
import jp.co.nec.aim.message.proto.ExtractService;
import jp.co.nec.aim.message.proto.InquiryService;
import jp.co.nec.aim.xml.Extraction;
import jp.co.nec.aim.xml.ParameterReader;
import jp.co.nec.aim.xml.Search;
import jp.co.nec.aim.xml.Sync;
import lombok.val;
import lombok.var;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@SuppressWarnings("unchecked")
public class ProtoCallbackHandler implements HttpHandler {
    final static Logger logger = LoggerFactory.getLogger(ProtoCallbackHandler.class);

    SendingRequestController<String> reqController_;

    // key is job ID and value is NIST file name
    ConcurrentHashMap<String, Pair<String, Stopwatch>> turnAroundTime_;

    final Extraction extraction_ = ParameterReader.getExtraction();

    final Search search_ = ParameterReader.getSearch();

    final Sync sync_ = ParameterReader.getSync();

    Path performancePath_;

    Path candidatePath_;

    Path rankPath_;

    int terminalId_;

    int index_;

    public enum ProcessType {
        VERIFICATION, EXTRACATION, IDENTIFY, SYNC, CALLBACKTEST
    }

    ProcessType processType_;

    FifoQueue<String> jobIdQueue_;

    final Map<CommonEnumTypes.ImagePositionType, String> positionTypes_ = new HashMap() {
        {
            put(CommonEnumTypes.ImagePositionType.IMAGE_ROLLED_RIGHT_THUMB, "1");
            put(CommonEnumTypes.ImagePositionType.IMAGE_ROLLED_RIGHT_INDEX, "2");
            put(CommonEnumTypes.ImagePositionType.IMAGE_ROLLED_RIGHT_MIDDLE, "3");
            put(CommonEnumTypes.ImagePositionType.IMAGE_ROLLED_RIGHT_RING, "4");
            put(CommonEnumTypes.ImagePositionType.IMAGE_ROLLED_RIGHT_LITTLE, "5");
            put(CommonEnumTypes.ImagePositionType.IMAGE_ROLLED_LEFT_THUMB, "6");
            put(CommonEnumTypes.ImagePositionType.IMAGE_ROLLED_LEFT_INDEX, "7");
            put(CommonEnumTypes.ImagePositionType.IMAGE_ROLLED_LEFT_MIDDLE, "8");
            put(CommonEnumTypes.ImagePositionType.IMAGE_ROLLED_LEFT_RING, "9");
            put(CommonEnumTypes.ImagePositionType.IMAGE_ROLLED_LEFT_LITTLE, "10");
            put(CommonEnumTypes.ImagePositionType.IMAGE_SLAP_RIGHT_THUMB, "1");
            put(CommonEnumTypes.ImagePositionType.IMAGE_SLAP_RIGHT_INDEX, "2");
            put(CommonEnumTypes.ImagePositionType.IMAGE_SLAP_RIGHT_MIDDLE, "3");
            put(CommonEnumTypes.ImagePositionType.IMAGE_SLAP_RIGHT_RING, "4");
            put(CommonEnumTypes.ImagePositionType.IMAGE_SLAP_RIGHT_LITTLE, "5");
            put(CommonEnumTypes.ImagePositionType.IMAGE_SLAP_LEFT_THUMB, "6");
            put(CommonEnumTypes.ImagePositionType.IMAGE_SLAP_LEFT_INDEX, "7");
            put(CommonEnumTypes.ImagePositionType.IMAGE_SLAP_LEFT_MIDDLE, "8");
            put(CommonEnumTypes.ImagePositionType.IMAGE_SLAP_LEFT_RING, "9");
            put(CommonEnumTypes.ImagePositionType.IMAGE_SLAP_LEFT_LITTLE, "10");
            put(CommonEnumTypes.ImagePositionType.IMAGE_PALM_RIGHT_FULL, "1");
            put(CommonEnumTypes.ImagePositionType.IMAGE_PALM_RIGHT_WRITER, "2");
            put(CommonEnumTypes.ImagePositionType.IMAGE_PALM_LEFT_FULL, "3");
            put(CommonEnumTypes.ImagePositionType.IMAGE_PALM_LEFT_WRITER, "4");
            put(CommonEnumTypes.ImagePositionType.IMAGE_PALM_RIGHT_LOWER, "5");
            put(CommonEnumTypes.ImagePositionType.IMAGE_PALM_RIGHT_UPPER, "6");
            put(CommonEnumTypes.ImagePositionType.IMAGE_PALM_LEFT_LOWER, "7");
            put(CommonEnumTypes.ImagePositionType.IMAGE_PALM_LEFT_UPPER, "8");
            put(CommonEnumTypes.ImagePositionType.IMAGE_PALM_RIGHT_OTHER, "9");
            put(CommonEnumTypes.ImagePositionType.IMAGE_PALM_LEFT_OTHER, "10");
            put(CommonEnumTypes.ImagePositionType.IMAGE_PALM_RIGHT_INTERDIGITAL, "11");
            put(CommonEnumTypes.ImagePositionType.IMAGE_PALM_RIGHT_THENAR, "12");
            put(CommonEnumTypes.ImagePositionType.IMAGE_PALM_RIGHT_HYPOTHENAR, "13");
            put(CommonEnumTypes.ImagePositionType.IMAGE_PALM_LEFT_INTERDIGITAL, "14");
            put(CommonEnumTypes.ImagePositionType.IMAGE_PALM_LEFT_THENAR, "15");
            put(CommonEnumTypes.ImagePositionType.IMAGE_PALM_LEFT_HYPOTHENAR, "16");
        }

    };


    public ProtoCallbackHandler(
            ProcessType processType,
            SendingRequestController<String> reqController,
            ConcurrentHashMap<String, Pair<String, Stopwatch>> turnAroundTime,
            FifoQueue<String> jobIdQueue,
            int terminalId) {
        processType_ = processType;
        reqController_ = reqController;
        turnAroundTime_ = turnAroundTime;
        jobIdQueue_ = jobIdQueue;
        terminalId_ = terminalId;
    }

    @Override
    public void handle(HttpExchange exchange)
            throws IOException {
        val body = IOUtils.toByteArray(exchange.getRequestBody());
        logger.info("received");

        try {
            if (processType_ == ProcessType.EXTRACATION) {
                processExtraction(body);
            } else if (processType_ == ProcessType.VERIFICATION) {
                // processVerification(body);
            } else if (processType_ == ProcessType.SYNC) {
//                processSync(body);
            } else if (processType_ == ProcessType.IDENTIFY) {
                processSearch(body);
            } else if (processType_ == ProcessType.CALLBACKTEST) {
//                processCallbackTest(body);
            }
        } catch (Exception ex) {
            logger.error(Throwables.getRootCause(ex).toString());
        } finally {
            String message = "Ok";
            exchange.sendResponseHeaders(200, message.length());
            val os = exchange.getResponseBody();
            os.write(message.getBytes());
            os.close();

            logger.info("send response");
        }
    }

    private void addRequestQueue(String str)
            throws Exception {
        try {
            while (true) {
                if (reqController_.add(str)) {
                    return;
                }
            }
        } catch (Exception ex) {
            logger.error(Throwables.getStackTraceAsString(ex));
            throw ex;
        }
    }

    private void processExtraction(byte[] body)
            throws IOException {
        val response = ExtractService.PBExtractJobResult.parseFrom(body);
        if (extraction_.getProto().isOutputResponse()) {
            val builder = new StringBuilder("./extract_result_").append(terminalId_).append("_")
                    .append(index_).append(".txt");
            Files.write(Paths.get(builder.toString()), response.toString().getBytes());
        }

        try {
            val jobId = jobIdQueue_.take();
            val builder =
                    new StringBuilder("./extract_result_").append("job-").append(jobId).append("_").append(terminalId_)
                            .append("_").append(index_++).append(".bin");
            Files.write(Paths.get(builder.toString()), response.toByteArray());

            for (val keyedBinary : response.getKeyedTemplateList()) {

                val index = keyedBinary.getKey().toString().lastIndexOf("_");
                var key = keyedBinary.getKey().toString().substring(index + 1);

                if (keyedBinary.hasIndexer()) {
                    val indexer = keyedBinary.getIndexer();
                    if (indexer.hasFingerPrintType()) {
                        if (indexer.getFingerPrintType() ==
                                CommonEnumTypes.FingerPrintType.FINGER_PRINT_ROLLED) {
                            if (keyedBinary.getKey() != CommonEnumTypes.TemplateFormatType.TEMPLATE_RDBTM) {
                                key += "_ROLLED";
                            }
                        } else if (indexer.getFingerPrintType() ==
                                CommonEnumTypes.FingerPrintType.FINGER_PRINT_SLAP) {
                            if (keyedBinary.getKey() != CommonEnumTypes.TemplateFormatType.TEMPLATE_RDBTM) {
                                key += "_SLAP";
                            } else {
                                key = key.replace("RDBTM", "SDBTM");
                            }
                        }
                    } else if (indexer.hasPosition()) {
                        val position = indexer.getPosition();
                        key += "_" + positionTypes_.get(position);
                        if (position == CommonEnumTypes.ImagePositionType.IMAGE_SLAP_RIGHT_THUMB ||
                                position == CommonEnumTypes.ImagePositionType.IMAGE_SLAP_LEFT_THUMB ||
                                (CommonEnumTypes.ImagePositionType.IMAGE_SLAP_RIGHT_INDEX.getNumber() <=
                                        position.getNumber() &&
                                        CommonEnumTypes.ImagePositionType.IMAGE_SLAP_LEFT_LITTLE.getNumber() <=
                                                position.getNumber())) {
                            key = key.replace("RDBLM", "SDBLM");
                        }
                    }
                }

                StringBuilder name = new StringBuilder(extraction_.getOutputTemplatePath()).append(
                        "/").append(turnAroundTime_.get(jobId).getLeft()).append("_-_").append(
                        key).append(".bin");
                Files.write(Paths.get(name.toString()), keyedBinary.getTemplateBinary().toByteArray(),
                        StandardOpenOption.CREATE);
            }

            addRequestQueue(jobId);
        } catch (Exception ex) {
            logger.error(Throwables.getRootCause(ex).toString());
        }
    }

    private void processSearch(byte[] body)
            throws IOException {
        if (search_.getProto().isOutputResponse()) {
            val response = InquiryService.PBInquiryJobResult.parseFrom(body);
            val builder = new StringBuilder("./search_job_result_").append(terminalId_).append("_")
                    .append(index_).append(".txt");
            Files.write(Paths.get(builder.toString()), response.toString().getBytes());
        }

        try {
            val jobId = jobIdQueue_.take();
            addRequestQueue(jobId);
            index_++;
        } catch (Exception ex) {
            logger.error(Throwables.getRootCause(ex).toString());
        }
    }

    // private void processVerification(String body)
    // throws IOException {
    // if (verification_.getSoap().isOutputResponse()) {
    // val builder = new
    // StringBuilder("./VerificationJobResult_").append(terminalId_).append(
    // "_").append(index_).append(".xml");
    // Files.write(Paths.get(builder.toString()), body.getBytes());
    // }
    //
    // try {
    // val obj = JAXB.unmarshal(buffXml_.toFile(), VerifyJobResultDto.class);
    //
    // while (true) {
    // if (!turnAroundTime_.containsKey(obj.getJobId())) {
    // logger.error("job ID({}) not exist. waiting for a second.",
    // obj.getJobId());
    // Thread.sleep(200);
    // continue;
    // }
    // break;
    // }
    // val buff = turnAroundTime_.get(obj.getJobId());
    // val tat = buff.getRight().elapsed(TimeUnit.MILLISECONDS);
    //
    // logger.info("job ID, {} which is got from VerifyJobResultDto",
    // obj.getJobId());
    //
    // val builder = new StringBuilder();
    // builder.append(buff.getLeft()).append(",").append(tat).append("\n");
    // Files.write(performancePath_, builder.toString().getBytes(),
    // StandardOpenOption.APPEND);
    //
    // addRequestQueue(obj.getJobId());
    //
    // // outputCandidate(buff.getLeft(), obj);
    // // outputRank(buff.getLeft(), obj);
    //
    // index_++;
    // } catch (Exception ex) {
    // logger.error(Throwables.getRootCause(ex).toString());
    // }
    // }

    private void processSync(String body)
            throws IOException {
        if (sync_.getSoap().isOutputResponse()) {
            Files.write(Paths.get("./sync_result.xml"), body.getBytes());
        }

        try {
//			val obj = JAXB.unmarshal(buffXml_.toFile(), SyncJobResultDto.class);
//
//			while (true) {
//				if (!turnAroundTime_.containsKey(obj.getJobId())) {
//					logger.error("job ID({}) not exist. waiting for a second.", obj.getJobId());
//					Thread.sleep(200);
//					continue;
//				}
//				break;
//			}
//
//			val buff = turnAroundTime_.get(obj.getJobId());
//			val tat = buff.getRight().elapsed(TimeUnit.MILLISECONDS);
//
//			logger.info("job ID, {} which is got from SyncJobResultDto", obj.getJobId());
//
//			val builder = new StringBuilder();
//			builder.append(buff.getLeft()).append(",").append(tat).append("\n");
//			Files.write(performancePath_, builder.toString().getBytes(), StandardOpenOption.APPEND);
//
//			addRequestQueue(obj.getJobId());
        } catch (Exception ex) {
            logger.error(Throwables.getRootCause(ex).toString());
        }
    }

    // private void outputCandidate(String fileName, SearchJobResultDto
    // searchJobResultDto)
    // throws IOException {
    // if (searchJobResultDto.getCandidateResultList() == null ||
    // searchJobResultDto
    // .getCandidateResultList().size() == 0) {
    // return;
    // }
    //
    // // file name example is SD27P.300.02.raw_BT5_ROI.TEMPLATE_TYPE_44.bin
    // val index = fileName.lastIndexOf(".TEMP");
    // val externalId = fileName.substring(0, index);
    //
    // // query external ID, target external ID, score, bin ID, position
    // int rank = 1;
    // for (val candidate : searchJobResultDto.getCandidateResultList()) {
    // val builderCandidate = new StringBuilder(externalId);
    // builderCandidate.append(",").append(candidate.getExternalId()).append(",").append(
    // candidate.getScore()).append(",").append(rank++).append("\n");
    //
    // Files.write(candidatePath_, builderCandidate.toString().getBytes(),
    // StandardOpenOption.APPEND);
    // }
    // }

    // private void outputRank(String fileName, SearchJobResultDto
    // searchJobResultDto)
    // throws IOException {
    // val externalId = fileName.substring(0, fileName.lastIndexOf(".TEMP"));
    // val key = externalId.substring(0, externalId.indexOf("_"));
    // logger.info("key:{}", key);
    //
    // if (searchJobResultDto.getCandidateResultList() == null ||
    // searchJobResultDto
    // .getCandidateResultList().size() == 0) {
    // val builderRank = new StringBuilder(externalId);
    // builderRank.append(",").append(-2).append("\n");
    // Files.write(rankPath_, builderRank.toString().getBytes(),
    // StandardOpenOption.APPEND);
    // return;
    // }
    //
    // // query external ID, rank
    // int rank = 1;
    // int score = -1;
    // for (val candidate : searchJobResultDto.getCandidateResultList()) {
    // if (!candidate.getExternalId().contains(key)) {
    // ++rank;
    // continue;
    // }
    // score = candidate.getScore();
    // break;
    // }
    //
    // if (rank == searchJobResultDto.getCandidateResultList().size() + 1) {
    // rank = -1;
    // }
    //
    // val builderRank = new StringBuilder(externalId);
    // builderRank.append(",").append(rank).append(",").append(score).append("\n");
    // Files.write(rankPath_, builderRank.toString().getBytes(),
    // StandardOpenOption.APPEND);
    // }


    private static ExtractService.PBExtractJobBinaryResponse post(
            ExtractService.PBExtractJobBinaryRequest requestMessage, String url) throws IOException {
        var mediaType = MediaType.parse("application/x-protobuf; charset=utf-8");
        var requestBody = RequestBody.create(requestMessage.toByteArray(), mediaType);
        var request = new Request.Builder().url(url).post(requestBody).build();
        var client = new OkHttpClient();
        try (var response = client.newCall(request).execute()) {
            System.out.println("code:" + response.code());
            if (response.isSuccessful()) {
                return ExtractService.PBExtractJobBinaryResponse.parseFrom(response.body().bytes());
            }
            return ExtractService.PBExtractJobBinaryResponse.newBuilder().build();
        }
    }

}
