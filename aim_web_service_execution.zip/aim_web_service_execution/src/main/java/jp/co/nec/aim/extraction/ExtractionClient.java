package jp.co.nec.aim.extraction;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.xml.transform.stream.StreamResult;

import jp.co.nec.aim.client.ProtoCallbackHandler;
import jp.co.nec.aim.client.SoapCallbackHandler;
import jp.co.nec.aim.http.HttpClient;
import jp.co.nec.aim.message.proto.ExtractService;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobRequest;
import jp.co.nec.proto.ProtoBuilder;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.commons.lang3.tuple.Triple;
import org.apache.commons.math3.stat.descriptive.SynchronizedSummaryStatistics;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import com.google.common.base.Stopwatch;
import com.google.common.base.Throwables;
import com.sun.net.httpserver.HttpServer;

import jp.co.nec.aim.FifoQueue;
import jp.co.nec.aim.SendingRequestController;
import jp.co.nec.aim.nistpack.Image;
import jp.co.nec.aim.nistpack.NistReader;
import jp.co.nec.aim.soap.Extract;
import jp.co.nec.aim.soap.ObjectFactory;
import jp.co.nec.aim.soap.SoapBuilder;
import jp.co.nec.aim.soap.SoapClient;
import jp.co.nec.aim.xml.Extraction;
import jp.co.nec.aim.xml.ParameterReader;
import lombok.val;

@SuppressWarnings("boxing")
public class ExtractionClient {
	final static Logger logger = LoggerFactory.getLogger(ExtractionClient.class);

	final List<String> fileList = new ArrayList<>();

	final ExecutorService sendingExecutor_ = Executors.newFixedThreadPool(ParameterReader
		.getExtraction().getNumSendingRequestThread());

	final ExecutorService receptionExecutor_ = Executors.newFixedThreadPool(ParameterReader
		.getExtraction().getNumReceptionThread());

	volatile static boolean headerCreated = false;

	final Map<String, Pair<AtomicInteger, Stopwatch>> map_ = new ConcurrentHashMap<>(ParameterReader
		.getExtraction().getNumZmqIoThread());

	final Extraction extraction_ = ParameterReader.getExtraction();

	final FifoQueue<Long> elapsedTimeQueue_ = new FifoQueue<Long>();

	final FifoQueue<Long> responseTimeQueue_ = new FifoQueue<Long>();

	final AnnotationConfigApplicationContext appContext_;

	final ObjectFactory factory_ = new ObjectFactory();

	final FifoQueue<String> jobQIdQueue_ = new FifoQueue<>();

	HttpServer httpServer_;

	// ConcurrentHashMap<String, Pair<String, Stopwatch>> turnAroundTime_ = new
	// ConcurrentHashMap<>();

	static final Map<Integer, Integer> slapPositionMap_ = new HashMap<Integer, Integer>() {
		private static final long serialVersionUID = 1L;
		{
			put(1, 11);
			put(2, 40);
			put(3, 41);
			put(4, 42);
			put(5, 43);
			put(6, 12);
			put(7, 44);
			put(8, 45);
			put(9, 46);
			put(10, 47);
		}
	};

	int numFingerNistFile_ = extraction_.getNumFingerNistFile();

	int numFaceFile_ = extraction_.getNumFaceFile();

	int numIrisPair_ = extraction_.getNumIrisPair();

	int numPalmFile_ = extraction_.getNumPalmNistFile();

	/**
	 * 
	 * @param appContext
	 */
	public ExtractionClient(AnnotationConfigApplicationContext appContext) {
		appContext_ = appContext;
	}

	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	private List<Map<Integer, Byte[]>> createFileList()
		throws Exception {
		val list = new ArrayList<Map<Integer, Byte[]>>();
		val nistReader = new NistReader();
		try (Stream<Path> stream = Files.list(Paths.get(extraction_.getNistType4Path()))) {
			stream.filter(path -> path.toFile().isFile()).forEach(path -> {
				val map = nistReader.getType4Image(path.toAbsolutePath().toString());
				// list.add(map);
			});
		} catch (Exception ex) {
			logger.error(Throwables.getStackTraceAsString(ex));
			throw ex;
		}
		return list;
	}

	/**
	 * left is raw and center is bt5 and right is ROI
	 * 
	 * @return
	 * @throws Exception
	 */

	public List<Triple<Path, Path, Path>> getSpecialDatabase27LatentFileList()
		throws Exception {
		val list = new ArrayList<Triple<Path, Path, Path>>();

		val latentPaths = getSpecialDatabase27LatentRawList();
		val bt5Paths = getSpecialDatabase27Bt5FileList();
		val roiPaths = getSpecialDatabase27RoiFileList();

		val numPaths = latentPaths.size();
		for (int i = 0; i < numPaths; ++i) {
			Path latent = null;
			Path bt5 = null;
			Path roi = null;
			if (i < latentPaths.size()) {
				latent = latentPaths.get(i);
			}
			if (i < bt5Paths.size()) {
				bt5 = bt5Paths.get(i);
			}
			if (i < roiPaths.size()) {
				roi = roiPaths.get(i);
			}
			list.add(Triple.of(latent, bt5, roi));
		}
		return list;
	}

	static private List<Path> getSpecialDatabase27LatentRawList()
		throws Exception {
		final Extraction extraction = ParameterReader.getExtraction();
		val list = new ArrayList<Path>();
		val rawPath = extraction.getSpecialDatabase27().getLatentPath();
		if (rawPath != null) {
			try (Stream<Path> stream = Files.list(Paths.get(rawPath)).sorted()) {
				stream.filter(path -> path.toFile().isFile()).forEach(path -> {
					list.add(path);
				});
			} catch (Exception ex) {
				logger.error(Throwables.getStackTraceAsString(ex));
				throw ex;
			}
		}

		logger.info("the number of latent files of NIST 27 : {}", list.size());
		return list;
	}

	static private List<Path> getBt5FileList()
		throws Exception {
		final Extraction extraction = ParameterReader.getExtraction();
		val list = new ArrayList<Path>();
		val bt5Path = extraction.getBt5Path();
		if (bt5Path != null) {
			try (Stream<Path> stream = Files.list(Paths.get(bt5Path)).sorted()) {
				stream.filter(path -> path.toFile().isFile()).forEach(path -> {
					list.add(path);
				});
			} catch (Exception ex) {
				logger.error(Throwables.getStackTraceAsString(ex));
				throw ex;
			}
		}

		logger.info("the number of BT5 files of NIST 27 : {}", list.size());
		return list;
	}

	static private List<Path> getSpecialDatabase27Bt5FileList()
		throws Exception {
		final Extraction extraction = ParameterReader.getExtraction();
		val list = new ArrayList<Path>();
		val bt5Path = extraction.getSpecialDatabase27().getBt5Path();
		if (bt5Path != null) {
			try (Stream<Path> stream = Files.list(Paths.get(bt5Path)).sorted()) {
				stream.filter(path -> path.toFile().isFile()).forEach(path -> {
					list.add(path);
				});
			} catch (Exception ex) {
				logger.error(Throwables.getStackTraceAsString(ex));
				throw ex;
			}
		}

		logger.info("the number of BT5 files of NIST 27 : {}", list.size());
		return list;
	}

	static private List<Path> getSpecialDatabase27RoiFileList()
		throws Exception {
		final Extraction extraction = ParameterReader.getExtraction();
		val list = new ArrayList<Path>();
		val roiPath = extraction.getSpecialDatabase27().getRoiPath();
		if (roiPath != null) {
			try (Stream<Path> stream = Files.list(Paths.get(roiPath)).sorted()) {
				stream.filter(path -> path.toFile().isFile()).forEach(path -> {
					list.add(path);
				});
			} catch (Exception ex) {
				logger.error(Throwables.getStackTraceAsString(ex));
				throw ex;
			}
		}

		logger.info("the number of ROI files of NIST 27 : {}", list.size());
		return list;
	}

	/**
	 * left is rolled and right is slap
	 * 
	 * @return
	 * @throws Exception
	 */
	static public List<Pair<Path, Path>> getSpecialDatabase27TenprintdFileList()
		throws Exception {
		val list = new ArrayList<Pair<Path, Path>>();

		val rolledPaths = getSpecialDatabase27RolledFileList();
		val slapPaths = getSpecialDatabase27SlapFileList();

		val numPaths = rolledPaths.size() < slapPaths.size() ? slapPaths.size() : rolledPaths
			.size();
		for (int i = 0; i < numPaths; ++i) {
			Path rolled = null;
			Path slap = null;
			if (i < rolledPaths.size()) {
				rolled = rolledPaths.get(i);
			}
			if (i < slapPaths.size()) {
				slap = slapPaths.get(i);
			}
			list.add(Pair.of(rolled, slap));
		}
		return list;
	}

	static public List<Path> getSpecialDatabase27RolledFileList()
		throws Exception {
		final Extraction extraction = ParameterReader.getExtraction();
		val list = new ArrayList<Path>();
		val rolledPath = extraction.getSpecialDatabase27().getRolledPath();
		if (rolledPath != null) {
			try (Stream<Path> stream = Files.list(Paths.get(rolledPath)).sorted()) {
				stream.filter(path -> path.toFile().isFile()).forEach(path -> {
					list.add(path);
				});
			} catch (Exception ex) {
				logger.error(Throwables.getStackTraceAsString(ex));
				throw ex;
			}
		}

		logger.info("the number of rolled files of NIST 27 : {}", list.size());
		return list;
	}

	static public List<Path> getSpecialDatabase27SlapFileList()
		throws Exception {
		final Extraction extraction = ParameterReader.getExtraction();
		val list = new ArrayList<Path>();
		val slapPath = extraction.getSpecialDatabase27().getSlapPath();
		if (slapPath != null) {
			try (Stream<Path> stream = Files.list(Paths.get(slapPath)).sorted()) {
				stream.filter(path -> path.toFile().isFile()).forEach(path -> {
					list.add(path);
				});
			} catch (Exception ex) {
				logger.error(Throwables.getStackTraceAsString(ex));
				throw ex;
			}
		}

		logger.info("the number of slap files of NIST 27 : {}", list.size());
		return list;
	}

	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	private List<Path> getNistType4FileList()
		throws Exception {
		val list = new ArrayList<Path>();
		val extraction = extraction_;
		try (Stream<Path> stream = Files.list(Paths.get(extraction.getNistType4Path())).limit(
			numFingerNistFile_)) {
			stream.filter(path -> path.toFile().isFile()).forEach(path -> {
				list.add(path);
			});
		} catch (Exception ex) {
			logger.error(Throwables.getStackTraceAsString(ex));
			throw ex;
		}

		if (list.size() < numFingerNistFile_) {
			numFingerNistFile_ = list.size();
		}

		logger.info("the number of type 4 files : {}", list.size());
		return list;
	}

	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	private List<Path> getNistType14FileList()
		throws Exception {
		val list = new ArrayList<Path>();
		try (Stream<Path> stream = Files.list(Paths.get(extraction_.getNistType14Path())).limit(
			numFingerNistFile_)) {
			stream.filter(path -> path.toFile().isFile()).forEach(path -> {
				list.add(path);
			});
		} catch (Exception ex) {
			logger.error(Throwables.getStackTraceAsString(ex));
			throw ex;
		}

		if (list.size() < numFingerNistFile_) {
			numFingerNistFile_ = list.size();
		}

		logger.info("the number of type 14 files : {}", list.size());
		return list;
	}

	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	private List<Path> getNistType15FileList()
		throws Exception {
		val list = new ArrayList<Path>();
		try (Stream<Path> stream = Files.list(Paths.get(extraction_.getNistType15Path())).limit(
			numPalmFile_)) {
			stream.filter(path -> path.toFile().isFile()).forEach(path -> {
				list.add(path);
			});
		} catch (Exception ex) {
			logger.error(Throwables.getStackTraceAsString(ex));
			throw ex;
		}

		if (list.size() < numPalmFile_) {
			numFingerNistFile_ = list.size();
		}

		logger.info("the number of type 15 files : {}", list.size());
		return list;
	}

	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	private List<Pair<Path, Map<Integer, Byte[]>>> createNistFileList()
		throws Exception {
		val list = new ArrayList<Pair<Path, Map<Integer, Byte[]>>>();
		val nistReader = new NistReader();
		try (Stream<Path> stream = Files.list(Paths.get(extraction_.getNistType4Path())).limit(
			extraction_.getNumFingerNistFile())) {
			stream.filter(path -> path.toFile().isFile()).forEach(path -> {
				val map = nistReader.getType4Image(path.toAbsolutePath().toString());
				// list.add(Pair.of(path, map));
			});
		} catch (Exception ex) {
			logger.error(Throwables.getStackTraceAsString(ex));
			throw ex;
		}

		logger.info("a number of NIST files is {} for using test.", list.size());

		if (list.size() < numFingerNistFile_) {
			numFingerNistFile_ = list.size();
		}

		return list;
	}

	/**
	 * 
	 * @param binary
	 * @param file
	 * @throws IOException
	 */
	private void saveBinary(String file, Byte[] binary)
		throws IOException {
		BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(new File(file)));
		bos.write(ArrayUtils.toPrimitive(binary));
		bos.close();
	}

	private void saveBinary(String file, byte[] binary)
		throws IOException {
		BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(new File(file)));
		bos.write(binary);
		bos.close();
	}

	/**
	 * 
	 * @throws Exception
	 */
	public void sendExtractionRequestWithSoap()
		throws Exception {
		try {
			val extraction = extraction_;
			val endpoint = new ArrayList<String>();
			// val requestCount = new AtomicInteger(0);

			val port = Integer.valueOf(extraction.getSoap().getCallbackPort());

			for (int i = 0; i < ParameterReader.getExtraction().getNumSendingRequestThread(); ++i) {
				val reqContoroller = new SendingRequestController<String>(1);
				httpServer_ = HttpServer.create(new InetSocketAddress(port + i), 4);

				ConcurrentHashMap<String, Pair<String, Stopwatch>> turnAroundTime =
					new ConcurrentHashMap<>();
				httpServer_.createContext("/", new SoapCallbackHandler(appContext_,
					SoapCallbackHandler.ProcessType.EXTRACATION, reqContoroller, turnAroundTime,
					jobQIdQueue_, i));
				httpServer_.setExecutor(null);
				httpServer_.start();

				sendingExecutor_.submit(new SendingSoapClient(reqContoroller, endpoint,
					turnAroundTime, jobQIdQueue_, i));
			}

			logger.info("waiting for all threads terminated");

			// receptionExecutor_.shutdown();
			sendingExecutor_.shutdown();
			while (!Thread.currentThread().isInterrupted()) {
				Thread.sleep(1000);
				if (sendingExecutor_.isTerminated()) {
					break;
				}
			}
			logger.info("stopping the main thread");
			//
			// if (extraction.getAlgorithm().equalsIgnoreCase("finger")) {
			// createOutput();
			// }
		} catch (Exception ex) {
			logger.info(Throwables.getStackTraceAsString(ex));
		} finally {
		}
	}

	public void sendExtractionRequestWithProto()
			throws Exception {
		try {
			val extraction = extraction_;
			val endpoint = new ArrayList<String>();
			// val requestCount = new AtomicInteger(0);

			val port = Integer.valueOf(extraction.getProto().getCallbackPort());

			for (int i = 0; i < ParameterReader.getExtraction().getNumSendingRequestThread(); ++i) {
				val reqContoroller = new SendingRequestController<String>(1);
				httpServer_ = HttpServer.create(new InetSocketAddress(port + i), 4);

				ConcurrentHashMap<String, Pair<String, Stopwatch>> turnAroundTime =
						new ConcurrentHashMap<>();
				httpServer_.createContext("/", new ProtoCallbackHandler(
						ProtoCallbackHandler.ProcessType.EXTRACATION, reqContoroller, turnAroundTime,
						jobQIdQueue_, i));
				httpServer_.setExecutor(null);
				httpServer_.start();

				sendingExecutor_.submit(new SendingProtoClient(reqContoroller, endpoint,
						turnAroundTime, jobQIdQueue_, i));
			}

			logger.info("waiting for all threads terminated");

			// receptionExecutor_.shutdown();
			sendingExecutor_.shutdown();
			while (!Thread.currentThread().isInterrupted()) {
				Thread.sleep(1000);
				if (sendingExecutor_.isTerminated()) {
					break;
				}
			}
			logger.info("stopping the main thread");
			//
			// if (extraction.getAlgorithm().equalsIgnoreCase("finger")) {
			// createOutput();
			// }
		} catch (Exception ex) {
			logger.info(Throwables.getStackTraceAsString(ex));
		} finally {
		}
	}

	/**
	 * 
	 */
	private void createOutput() {
		val minElapsedTime = elapsedTimeQueue_.getQueue().stream().mapToLong(time -> time
			.longValue()).min().getAsLong();
		val maxElapsedTime = elapsedTimeQueue_.getQueue().stream().mapToLong(time -> time
			.longValue()).max().getAsLong();

		val avrResponseTime = new BigDecimal(responseTimeQueue_.getQueue().stream().mapToLong(
			elapsed -> elapsed.longValue()).average().getAsDouble()).setScale(3,
				BigDecimal.ROUND_HALF_UP).doubleValue();
		val minResponseTime = responseTimeQueue_.getQueue().stream().mapToLong(elapsed -> elapsed
			.longValue()).min().getAsLong();
		val maxResponseTime = responseTimeQueue_.getQueue().stream().mapToLong(elapsed -> elapsed
			.longValue()).max().getAsLong();

		final val responseStatistics = new SynchronizedSummaryStatistics();
		responseTimeQueue_.getQueue().stream().forEach(v -> {
			responseStatistics.addValue(v);
		});

		DecimalFormat df = new DecimalFormat("####.#######");
		Path path = Paths.get("./extraction_performance.txt");
		{
			val builder = new StringBuilder();
			val elapsed = new BigDecimal((maxElapsedTime - minElapsedTime) / (double)1000).setScale(
				0, BigDecimal.ROUND_UP).longValue();

			builder.append("elapsed time: ").append(elapsed).append(" sec\n").append("throughput: ")
				.append(new BigDecimal(numFingerNistFile_ / (double)elapsed).setScale(0,
					BigDecimal.ROUND_DOWN).longValue() * 60 * 60).append(" capsules/h\n");

			try {
				Files.write(path, builder.toString().getBytes());
			} catch (Exception ex) {
				logger.error(Throwables.getStackTraceAsString(ex));
			}
		}
		{
			val builder = new StringBuilder();
			builder.append(
				"|~ response(avest crer~ standard deviation |~ min response |~ max response |\n")
				.append("|").append(avrResponseTime).append(" ms | ").append(df.format(
					new BigDecimal(responseStatistics.getStandardDeviation()).setScale(3,
						BigDecimal.ROUND_HALF_UP).doubleValue())).append(" ms | ").append(
							minResponseTime).append(" ms | ").append(maxResponseTime).append(
								" ms |\n");

			try {
				Files.write(path, builder.toString().getBytes(), StandardOpenOption.APPEND);
			} catch (Exception ex) {
				logger.error(Throwables.getStackTraceAsString(ex));
			}
		}
	}

	private List<Pair<Path, Byte[]>> createFaceFileList()
		throws Exception {
		val list = new ArrayList<Pair<Path, Byte[]>>();
		try (Stream<Path> stream = Files.list(Paths.get(extraction_.getFacePath())).limit(
			numFaceFile_)) {
			stream.filter(path -> path.toFile().isFile()).forEach(path -> {
				try {
					list.add(Pair.of(path, ArrayUtils.toObject(Files.readAllBytes(path))));
				} catch (IOException ex) {
					logger.error(Throwables.getStackTraceAsString(ex));
				}
			});
		} catch (Exception ex) {
			logger.error(Throwables.getStackTraceAsString(ex));
			throw ex;
		}

		logger.info("a number of face files is {} for using test.", list.size());

		if (list.size() < numFingerNistFile_) {
			numFingerNistFile_ = list.size();
		}

		return list;
	}

	private List<Path> getFaceFileList()
		throws Exception {
		val list = new ArrayList<Path>();
		try (Stream<Path> stream = Files.list(Paths.get(extraction_.getFacePath())).limit(
			extraction_.getNumFaceFile())) {
			stream.filter(path -> path.toFile().isFile()).forEach(path -> {
				list.add(path);
			});
		} catch (Exception ex) {
			logger.error(Throwables.getStackTraceAsString(ex));
			throw ex;
		}

		if (list.size() < numFaceFile_) {
			numFaceFile_ = list.size();
		}

		logger.info("the  number of face files : {}", list.size());
		return list;
	}

	private List<Pair<Path, Path>> getIrisFileList()
		throws Exception {
		val list = new ArrayList<Path>();
		val extraction = extraction_;
		try (Stream<Path> stream = Files.list(Paths.get(extraction.getIrisPath())).limit(
			numIrisPair_ * 2)) {
			stream.filter(path -> path.toFile().isFile()).forEach(path -> {
				list.add(path);
			});
		} catch (Exception ex) {
			logger.error(Throwables.getStackTraceAsString(ex));
			throw ex;
		}

		val rightList = list.stream().filter(path -> path.toFile().getName().contains("_R."))
			.sorted().collect(Collectors.toList());
		val leftList = list.stream().filter(path -> path.toFile().getName().contains("_L."))
			.sorted().collect(Collectors.toList());
		int index = 0;
		val pairList = new ArrayList<Pair<Path, Path>>();
		for (Path path : rightList) {
			pairList.add(Pair.of(leftList.get(index), path));
			++index;
		}

		if (list.size() < numIrisPair_) {
			numFaceFile_ = list.size();
		}

		logger.info("the number of iris files : {}", list.size());
		return pairList;
	}

	private Byte[] readFile(Path path) {
		try {
			return ArrayUtils.toObject(Files.readAllBytes(path));
		} catch (IOException ex) {
			logger.error(Throwables.getStackTraceAsString(ex));
		}
		return null;
	}

	static public Map<Integer, Image> createNist27TenprintImage(Pair<Path, Path> pair) {
		Map<Integer, Image> map = new HashMap<>();
		try {
			if (pair.getLeft() != null) {
				// rolled
				val image = new Image();
				image.setDpi(Integer.parseInt("500"));
				image.setWidth(Integer.parseInt("512"));
				image.setHeight(Integer.parseInt("512"));
				image.setType("RAW");
				image.setData(ArrayUtils.toObject(Files.readAllBytes(pair.getLeft())));

				// finger number
				// format is SD27P.287.03.raw
				val pathStr = pair.getLeft().toString();
				val lastIndex = pathStr.length() - ".raw".length();
				val index = pair.getLeft().toString().lastIndexOf(".", lastIndex - 1);
				val fingerNumber = pathStr.substring(index + 1, lastIndex);
				image.setFile(pair.getLeft());
				logger.info("get rolled finger number {}, {}", fingerNumber, image.getType());
				map.put(Integer.valueOf(fingerNumber), image);
			}
			if (pair.getRight() != null) {
				// slap
				val image = new Image();
				image.setDpi(Integer.parseInt("500"));
				image.setWidth(Integer.parseInt("512"));
				image.setHeight(Integer.parseInt("512"));
				image.setType("RAW");
				image.setData(ArrayUtils.toObject(Files.readAllBytes(pair.getLeft())));

				// finger number
				// format is SD27P.287.03.raw
				val pathStr = pair.getLeft().toString();
				val lastIndex = pathStr.length() - ".raw".length();
				val index = pair.getLeft().toString().lastIndexOf(".", lastIndex - 1);
				val fingerNumber = pathStr.substring(index + 1, lastIndex);
				image.setFile(pair.getLeft());
				logger.info("get slap finger number {}, {}", slapPositionMap_.get(Integer.valueOf(
					fingerNumber)), image.getType());
				map.put(slapPositionMap_.get(Integer.valueOf(fingerNumber)), image);
			}
		} catch (Exception ex) {
			logger.error(Throwables.getStackTraceAsString(ex));
		} finally {
		}
		return map;
	}

	/**
	 * 
	 * @param path
	 * @return
	 */
	public Image createNist27LatentImage(Path path) {
		val image = new Image();
		try {
			image.setDpi(Integer.parseInt("500"));
			image.setWidth(extraction_.getSpecialDatabase27().getWidth());
			image.setHeight(extraction_.getSpecialDatabase27().getHeight());
			image.setType("RAW");
			image.setData(ArrayUtils.toObject(Files.readAllBytes(path)));

			// finger number
			// format is SD27P.287.03.raw
			val pathStr = path.toString();
			val lastIndex = pathStr.length() - ".raw".length();
			val index = path.toString().lastIndexOf(".", lastIndex - 1);
			image.setFile(path);
		} catch (Exception ex) {
			logger.error(Throwables.getStackTraceAsString(ex));
		} finally {
		}
		return image;
	}

	class SendingSoapClient extends Thread {

		SendingRequestController<String> reqController_;

		List<String> endpoint_;

		Random random_ = new Random();

		ConcurrentHashMap<String, Pair<String, Stopwatch>> turnAroundTime_;

		int terminalId_;

		FifoQueue<String> jobIdQueue_;

		public SendingSoapClient(
			SendingRequestController<String> controller,
			List<String> endPoint,
			ConcurrentHashMap<String, Pair<String, Stopwatch>> turnAroundTime,
			FifoQueue<String> jobIdQueue,
			int terminalId) {
			reqController_ = controller;
			endpoint_ = endPoint;
			turnAroundTime_ = turnAroundTime;
			jobIdQueue_ = jobIdQueue;
			terminalId_ = terminalId;
		}

		@Override
		public void run() {
			val algorithm = extraction_.getAlgorithm();
			if (algorithm.equalsIgnoreCase("finger")) {
				if (extraction_.getSpecialDatabase27().isEnable()) {
					if (extraction_.getSpecialDatabase27().getRolledPath() != null || extraction_.getSpecialDatabase27()
						.getSlapPath() != null) {
						processSpecialDatabase27TenprintRequest();
					} else {
						processSpecialDatabase27LatentRequest();
					}
				} else {
					processFingerRequest();
				}
			} else if (algorithm.equalsIgnoreCase("palm")) {
				processPalmRequest();
			} else if (algorithm.equalsIgnoreCase("s17") || algorithm.equalsIgnoreCase("s18")
				|| algorithm.equalsIgnoreCase("nfv2") || algorithm.equalsIgnoreCase("nfg2")
				|| algorithm.equalsIgnoreCase("nfv3")) {
				// processFaceRequest();
			} else if (algorithm.equalsIgnoreCase("niris")) {
				// processIrisRequest();
			}
		}

		/**
		 * 
		 * @param pair
		 * @throws Exception
		 */
		private void addRequestQueue(String value)
			throws Exception {
			try {
				while (true) {
					if (reqController_.add(value)) {
						return;
					}
				}
			} catch (Exception ex) {
				logger.error(Throwables.getStackTraceAsString(ex));
				throw ex;
			}
		}

		private void processFingerRequest() {
			val nistReader = new NistReader();
			try {
				List<Path> paths = null;
				val nistType = extraction_.getNistType();

				if (extraction_.isBt5Enable()) {
					// paths = getBt5FileList();
				} else if (extraction_.isImageEnable()) {
					if (nistType == 4) {
						paths = getNistType4FileList();
					} else if (nistType == 14) {
						paths = getNistType14FileList();
					} else if (nistType == 15) {
						paths = getNistType15FileList();
					}
				}

				addRequestQueue("start job");

				val soapBuilder = new SoapBuilder(terminalId_);
				val client = appContext_.getBean(SoapClient.class);
				for (val path : paths) {
					val fileName = path.toFile().getName();
					logger.info("Next file is {}.", fileName);

					Extract request = null;
					if (extraction_.isBt5Enable() && !extraction_.isImageEnable()) {
						// request = soapBuilder.buildFingerExtract(path,
						// fileName);
					} else if (extraction_.isImageEnable()) {
						if (nistType == 4) {
							val map = nistReader.getType4Image(path.toAbsolutePath().toString());
							request = soapBuilder.buildFingerExtract(map, fileName);
						} else if (nistType == 14) {
							val map = nistReader.getType14Image(path.toAbsolutePath().toString());
							request = soapBuilder.buildFingerExtract(map, fileName);
						}
					}

					if (extraction_.getSoap().isOutputRequest()) {
						output(request);
					}

					logger.info("waiting for takeing from queue");
					String jobId = reqController_.take();
					logger.info("got job ID:{} from queue", jobId);

					val stopwatch = Stopwatch.createStarted();
					jobId = String.valueOf(client.extract(extraction_.getSoap().getEndpoint(),
						request).getReturn());
					logger.info("got job ID:{}", jobId);
					jobIdQueue_.add(jobId);

					turnAroundTime_.put(jobId, Pair.of(fileName, stopwatch));
				}

				logger.info("waiting for takeing from queue");
				val jobId = reqController_.take();
				logger.info("got job ID:{} from queue", jobId);

				// waiting for sending latest request.
				sleep(4 * 1000);
			} catch (Exception ex) {
				logger.error(Throwables.getStackTraceAsString(ex));
			} finally {
				httpServer_.stop(0);
			}
			logger.info("stopped a sending thread as {}", Thread.currentThread().getName());
		}

		private void processSpecialDatabase27TenprintRequest() {
			try {
				List<Pair<Path, Path>> paths = getSpecialDatabase27TenprintdFileList();

				addRequestQueue("start job");

				val soapBuilder = new SoapBuilder(terminalId_);
				val client = appContext_.getBean(SoapClient.class);
				for (val path : paths) {
					String rolledFileName = null;
					String slapFileName = null;
					if (path.getLeft() != null) {
						rolledFileName = path.getLeft().toFile().getName();
					}
					if (path.getRight() != null) {
						slapFileName = path.getRight().toFile().getName();
					}
					rolledFileName = rolledFileName == null ? "" : rolledFileName;
					slapFileName = slapFileName == null ? "" : slapFileName;
					val builder = new StringBuilder(rolledFileName).append("_").append(
						slapFileName);
					logger.info("Next file is {}.", builder.toString());

					val map = createNist27TenprintImage(path);
					Extract request = soapBuilder.buildFingerExtract(map, builder.toString());
					if (extraction_.getSoap().isOutputRequest()) {
						output(request);
					}

					logger.info("waiting for takeing from queue");
					String jobId = reqController_.take();
					logger.info("got job ID:{} from queue", jobId);

					val stopwatch = Stopwatch.createStarted();
					jobId = String.valueOf(client.extract(extraction_.getSoap().getEndpoint(),
						request).getReturn());
					logger.info("got job ID:{}", jobId);
					jobIdQueue_.add(jobId);

					turnAroundTime_.put(jobId, Pair.of(builder.toString(), stopwatch));
				}

				logger.info("waiting for takeing from queue");
				val jobId = reqController_.take();
				logger.info("got job ID:{} from queue", jobId);

				// waiting for sending latest request.
				sleep(4 * 1000);
			} catch (Exception ex) {
				logger.error(Throwables.getStackTraceAsString(ex));
			} finally {
				httpServer_.stop(0);
			}
			logger.info("stopped a sending thread as {}", Thread.currentThread().getName());
		}

		private void processSpecialDatabase27LatentRequest() {
			try {
				List<Triple<Path, Path, Path>> paths = getSpecialDatabase27LatentFileList();

				addRequestQueue("start job");

				val soapBuilder = new SoapBuilder(terminalId_);
				val client = appContext_.getBean(SoapClient.class);
				for (val triplePath : paths) {
					String latentFileName = null;
					if (triplePath.getLeft() == null) {
						throw new FileNotFoundException("Not found latent image.");
					}
					latentFileName = triplePath.getLeft().toFile().getName();

					val builder = new StringBuilder(latentFileName).append("_").append(triplePath
						.getMiddle() == null ? "noBT5" : "BT5").append("_").append(triplePath
							.getRight() == null ? "noROI" : "ROI");

					logger.info("Next file is {}.", builder.toString());

					val image = createNist27LatentImage(triplePath.getLeft());
					Extract request = soapBuilder.buildLatentFingerExtract(image, builder
						.toString());
					if (extraction_.getSoap().isOutputRequest()) {
						output(request);
					}

					logger.info("waiting for takeing from queue");
					String jobId = reqController_.take();
					logger.info("got job ID:{} from queue", jobId);

					val stopwatch = Stopwatch.createStarted();
					jobId = String.valueOf(client.extract(extraction_.getSoap().getEndpoint(),
						request).getReturn());
					logger.info("got job ID:{}", jobId);
					jobIdQueue_.add(jobId);

					turnAroundTime_.put(jobId, Pair.of(builder.toString(), stopwatch));
				}

				logger.info("waiting for takeing from queue");
				val jobId = reqController_.take();
				logger.info("got job ID:{} from queue", jobId);

				// waiting for sending latest request.
				sleep(4 * 1000);
			} catch (Exception ex) {
				logger.error(Throwables.getStackTraceAsString(ex));
			} finally {
				httpServer_.stop(0);
			}
			logger.info("stopped a sending thread as {}", Thread.currentThread().getName());
		}

		private void processFaceRequest() {
			val soapBuilder = new SoapBuilder(terminalId_);
			val client = appContext_.getBean(SoapClient.class);
			try {
				for (val path : getFaceFileList()) {
					val fileName = path.toFile().getName();

					// Extract request = soapBuilder.buildFaceExtract(path);
					Extract request = null;
					if (extraction_.getSoap().isOutputRequest()) {
						output(request);
					}

					logger.info("waiting for takeing from queue");
					String jobId = reqController_.take();
					logger.info("got job ID:{} from queue", jobId);

					val stopwatch = Stopwatch.createStarted();
					// jobId =
					// client.submitExtractionJob(extraction_.getSoap().getEndpoint(),
					// request)
					// .getReturn();
					logger.info("got job ID:{}", jobId);

					if (extraction_.getSoap().isOutputRequest()) {
						output(request);
					}

					turnAroundTime_.put(jobId, Pair.of(fileName, stopwatch));

					// val completedJobId = reqController_.take();
					// logger.info("received {}.", completedJobId);
				}

				logger.info("waiting for takeing from queue");
				val jobId = reqController_.take();
				logger.info("got job ID:{} from queue", jobId);

				// waiting for sending latest request.
				sleep(4 * 1000);
			} catch (Exception ex) {
				logger.error(Throwables.getStackTraceAsString(ex));
			} finally {
				// zeroMq.close();
			}
			logger.info("stopped a sending thread as {}", Thread.currentThread().getName());
		}

		private void processIrisRequest() {
			try {
				val soapBuilder = new SoapBuilder(terminalId_);
				val client = appContext_.getBean(SoapClient.class);

				addRequestQueue("start job");

				for (val path : getIrisFileList()) {
					val builder = new StringBuilder(path.getLeft().toFile().getName()).append("_")
						.append(path.getLeft().toFile().getName());
					val fileName = builder.toString();
					logger.info("Next file is {}.", fileName);

					Extract request = null;
					// val request = soapBuilder.buildIrisExtract(path);
					if (extraction_.getSoap().isOutputRequest()) {
						output(request);
					}

					logger.info("waiting for takeing from queue");
					String jobId = reqController_.take();
					logger.info("got job ID:{} from queue", jobId);

					val stopwatch = Stopwatch.createStarted();
					// jobId =
					// client.submitExtractionJob(extraction_.getSoap().getEndpoint(),
					// request)
					// .getReturn();
					logger.info("got job ID:{}", jobId);

					if (extraction_.getSoap().isOutputRequest()) {
						output(request);
					}

					turnAroundTime_.put(jobId, Pair.of(fileName, stopwatch));
				}

				logger.info("waiting for takeing from queue");
				val jobId = reqController_.take();
				logger.info("got job ID:{} from queue", jobId);

				// waiting for sending latest request.
				sleep(4 * 1000);
			} catch (Exception ex) {
				logger.error(Throwables.getStackTraceAsString(ex));
			} finally {
			}
			logger.info("stopped a sending thread as {}", Thread.currentThread().getName());
		}

		/**
		 * 
		 */
		private void processPalmRequest() {
			val nistReader = new NistReader();
			try {
				List<Path> paths = null;
				paths = getNistType15FileList();

				addRequestQueue("start job");

				val soapBuilder = new SoapBuilder(terminalId_);
				val client = appContext_.getBean(SoapClient.class);
				for (val path : paths) {
					val fileName = path.toFile().getName();
					logger.info("Next file is {}.", fileName);

					val map = nistReader.getType15Image(path.toAbsolutePath().toString());

					Extract request = null;
					// Extract request = soapBuilder.buildPalmExtract(map);
					if (extraction_.getSoap().isOutputRequest()) {
						output(request);
					}

					logger.info("waiting for takeing from queue");
					String jobId = reqController_.take();
					logger.info("got job ID:{} from queue", jobId);

					val stopwatch = Stopwatch.createStarted();
					// jobId =
					// client.submitExtractionJob(extraction_.getSoap().getEndpoint(),
					// request)
					// .getReturn();
					logger.info("got job ID:{}", jobId);

					if (extraction_.getSoap().isOutputRequest()) {
						output(request);
					}

					turnAroundTime_.put(jobId, Pair.of(fileName, stopwatch));

					// val completedJobId = reqController_.take();
					// logger.info("received {}.", completedJobId);
				}

				logger.info("waiting for takeing from queue");
				val jobId = reqController_.take();
				logger.info("got job ID:{} from queue", jobId);

				// waiting for sending latest request.
				sleep(4 * 1000);
			} catch (Exception ex) {
				logger.error(Throwables.getStackTraceAsString(ex));
			} finally {
				// zeroMq.close();
			}
			logger.info("stopped a sending thread as {}", Thread.currentThread().getName());
		}

		private void output(Extract request) {
			StreamResult result = new StreamResult(new StringWriter());
			val marshaller = appContext_.getBean(Jaxb2Marshaller.class);
			marshaller.marshal(factory_.createExtract(request), result);

			val builder = new StringBuilder("extract_request_").append(terminalId_).append(".xml");
			try {
				Files.write(Paths.get(builder.toString()), result.getWriter().toString()
					.getBytes());
			} catch (IOException ex) {
				logger.error(Throwables.getRootCause(ex).toString());
			}
		}
	}


	class SendingProtoClient extends Thread {

		SendingRequestController<String> reqController_;

		List<String> endpoint_;

		Random random_ = new Random();

		ConcurrentHashMap<String, Pair<String, Stopwatch>> turnAroundTime_;

		int terminalId_;

		FifoQueue<String> jobIdQueue_;

		public SendingProtoClient(
				SendingRequestController<String> controller,
				List<String> endPoint,
				ConcurrentHashMap<String, Pair<String, Stopwatch>> turnAroundTime,
				FifoQueue<String> jobIdQueue,
				int terminalId) {
			reqController_ = controller;
			endpoint_ = endPoint;
			turnAroundTime_ = turnAroundTime;
			jobIdQueue_ = jobIdQueue;
			terminalId_ = terminalId;
		}

		@Override
		public void run() {
			val algorithm = extraction_.getAlgorithm();
			if (algorithm.equalsIgnoreCase("finger")) {
				if (extraction_.getSpecialDatabase27().isEnable()) {
					if (extraction_.getSpecialDatabase27().getRolledPath() != null || extraction_.getSpecialDatabase27()
							.getSlapPath() != null) {
						processSpecialDatabase27TenprintRequest();
					} else {
						processSpecialDatabase27LatentRequest();
					}
				} else {
					processFingerRequest();
				}
			} else if (algorithm.equalsIgnoreCase("palm")) {
				processPalmRequest();
			} else if (algorithm.equalsIgnoreCase("s17") || algorithm.equalsIgnoreCase("s18")
					|| algorithm.equalsIgnoreCase("nfv2") || algorithm.equalsIgnoreCase("nfg2")
					|| algorithm.equalsIgnoreCase("nfv3")) {
				// processFaceRequest();
			} else if (algorithm.equalsIgnoreCase("niris")) {
				// processIrisRequest();
			}
		}

		/**
		 *
		 * @param pair
		 * @throws Exception
		 */
		private void addRequestQueue(String value)
				throws Exception {
			try {
				while (true) {
					if (reqController_.add(value)) {
						return;
					}
				}
			} catch (Exception ex) {
				logger.error(Throwables.getStackTraceAsString(ex));
				throw ex;
			}
		}

		private void processFingerRequest() {
			val nistReader = new NistReader();
			try {
				List<Path> paths = null;
				val nistType = extraction_.getNistType();

				if (extraction_.isBt5Enable()) {
					// paths = getBt5FileList();
				} else if (extraction_.isImageEnable()) {
					if (nistType == 4) {
						paths = getNistType4FileList();
					} else if (nistType == 14) {
						paths = getNistType14FileList();
					} else if (nistType == 15) {
						paths = getNistType15FileList();
					}
				}

				addRequestQueue("start job");

				val builder = new ProtoBuilder(terminalId_);
				for (val path : paths) {
					val fileName = path.toFile().getName();
					logger.info("Next file is {}.", fileName);

					PBExtractJobRequest request = null;
					if (extraction_.isBt5Enable() && !extraction_.isImageEnable()) {
						// request = soapBuilder.buildFingerExtract(path,
						// fileName);
					} else if (extraction_.isImageEnable()) {
						if (nistType == 4) {
							val map = nistReader.getType4Image(path.toAbsolutePath().toString());
							request = builder.buildFingerExtractJobRequest(map, fileName);
						} else if (nistType == 14) {
							val map = nistReader.getType14Image(path.toAbsolutePath().toString());
							request = builder.buildFingerExtractJobRequest(map, fileName);
						}
					}

					if (extraction_.getSoap().isOutputRequest()) {
						output(request);
					}

					logger.info("waiting for takeing from queue");
					String jobId = reqController_.take();
					logger.info("got job ID:{} from queue", jobId);

					val stopwatch = Stopwatch.createStarted();
					val response = HttpClient.post(request);
					if (!response.isPresent()) {
						logger.error("response did not exit.");
						continue;
					}
					jobId = String.valueOf(response.get().getJobId());
					logger.info("got job ID:{}", jobId);
					jobIdQueue_.add(jobId);

					turnAroundTime_.put(jobId, Pair.of(fileName, stopwatch));
				}

				logger.info("waiting for takeing from queue");
				val jobId = reqController_.take();
				logger.info("got job ID:{} from queue", jobId);

				// waiting for sending latest request.
				sleep(4 * 1000);
			} catch (Exception ex) {
				logger.error(Throwables.getStackTraceAsString(ex));
			} finally {
				httpServer_.stop(0);
			}
			logger.info("stopped a sending thread as {}", Thread.currentThread().getName());
		}

		private void processSpecialDatabase27TenprintRequest() {
			try {
				List<Pair<Path, Path>> paths = getSpecialDatabase27TenprintdFileList();

				addRequestQueue("start job");

				val protoBuilder = new ProtoBuilder(terminalId_);
				val client = appContext_.getBean(SoapClient.class);
				for (val path : paths) {
					String rolledFileName = null;
					String slapFileName = null;
					if (path.getLeft() != null) {
						rolledFileName = path.getLeft().toFile().getName();
					}
					if (path.getRight() != null) {
						slapFileName = path.getRight().toFile().getName();
					}
					rolledFileName = rolledFileName == null ? "" : rolledFileName;
					slapFileName = slapFileName == null ? "" : slapFileName;


					val builder = new StringBuilder(rolledFileName).append("_").append(
							slapFileName);
					logger.info("Next file is {}.", builder.toString());

					val map = createNist27TenprintImage(path);

					PBExtractJobRequest request = protoBuilder.buildFingerExtractJobRequest(map, builder.toString());
					if (extraction_.getSoap().isOutputRequest()) {
						output(request);
					}

					logger.info("waiting for takeing from queue");
					String jobId = reqController_.take();
					logger.info("got job ID:{} from queue", jobId);

					val stopwatch = Stopwatch.createStarted();
					val response = HttpClient.post(request);
					if (!response.isPresent()) {
						logger.error("response data did not exit.");
						continue;
					}
					jobId = String.valueOf(response.get().getJobId());

					logger.info("got job ID:{}", jobId);
					jobIdQueue_.add(jobId);

					turnAroundTime_.put(jobId, Pair.of(builder.toString(), stopwatch));
				}

				logger.info("waiting for takeing from queue");
				val jobId = reqController_.take();
				logger.info("got job ID:{} from queue", jobId);

				// waiting for sending latest request.
				sleep(4 * 1000);
			} catch (Exception ex) {
				logger.error(Throwables.getStackTraceAsString(ex));
			} finally {
				httpServer_.stop(0);
			}
			logger.info("stopped a sending thread as {}", Thread.currentThread().getName());
		}

		private void processSpecialDatabase27LatentRequest() {
			try {
				List<Triple<Path, Path, Path>> paths = getSpecialDatabase27LatentFileList();

				addRequestQueue("start job");

				val protoBuilder = new ProtoBuilder(terminalId_);

				val client = appContext_.getBean(SoapClient.class);
				for (val triplePath : paths) {
					String latentFileName = null;
					if (triplePath.getLeft() == null) {
						throw new FileNotFoundException("Not found latent image.");
					}
					latentFileName = triplePath.getLeft().toFile().getName();

					val builder = new StringBuilder(latentFileName).append("_").append(triplePath
							.getMiddle() == null ? "noBT5" : "BT5").append("_").append(triplePath
							.getRight() == null ? "noROI" : "ROI");

					logger.info("Next file is {}.", builder.toString());

					PBExtractJobRequest request = protoBuilder.buildLatentFingerExtractJobRequest(triplePath);
					if (extraction_.getSoap().isOutputRequest()) {
						output(request);
					}

					logger.info("waiting for takeing from queue");
					String jobId = reqController_.take();
					logger.info("got job ID:{} from queue", jobId);

					val stopwatch = Stopwatch.createStarted();
					val response = HttpClient.post(request);
					if (!response.isPresent()) {
						logger.error("response data did not exit.");
						continue;
					}
					jobId = String.valueOf(response.get().getJobId());
					logger.info("got job ID:{}", jobId);
					jobIdQueue_.add(jobId);

					turnAroundTime_.put(jobId, Pair.of(builder.toString(), stopwatch));
				}

				logger.info("waiting for takeing from queue");
				val jobId = reqController_.take();
				logger.info("got job ID:{} from queue", jobId);

				// waiting for sending latest request.
				sleep(4 * 1000);
			} catch (Exception ex) {
				logger.error(Throwables.getStackTraceAsString(ex));
			} finally {
				httpServer_.stop(0);
			}
			logger.info("stopped a sending thread as {}", Thread.currentThread().getName());
		}

		private void processFaceRequest() {
			val soapBuilder = new SoapBuilder(terminalId_);
			val client = appContext_.getBean(SoapClient.class);
			try {
				for (val path : getFaceFileList()) {
					val fileName = path.toFile().getName();

					// Extract request = soapBuilder.buildFaceExtract(path);
					Extract request = null;
					if (extraction_.getSoap().isOutputRequest()) {
//						output(request);
					}

					logger.info("waiting for takeing from queue");
					String jobId = reqController_.take();
					logger.info("got job ID:{} from queue", jobId);

					val stopwatch = Stopwatch.createStarted();
					// jobId =
					// client.submitExtractionJob(extraction_.getSoap().getEndpoint(),
					// request)
					// .getReturn();
					logger.info("got job ID:{}", jobId);

					if (extraction_.getSoap().isOutputRequest()) {
//						output(request);
					}

					turnAroundTime_.put(jobId, Pair.of(fileName, stopwatch));

					// val completedJobId = reqController_.take();
					// logger.info("received {}.", completedJobId);
				}

				logger.info("waiting for takeing from queue");
				val jobId = reqController_.take();
				logger.info("got job ID:{} from queue", jobId);

				// waiting for sending latest request.
				sleep(4 * 1000);
			} catch (Exception ex) {
				logger.error(Throwables.getStackTraceAsString(ex));
			} finally {
				// zeroMq.close();
			}
			logger.info("stopped a sending thread as {}", Thread.currentThread().getName());
		}

		private void processIrisRequest() {
			try {
				val soapBuilder = new SoapBuilder(terminalId_);
				val client = appContext_.getBean(SoapClient.class);

				addRequestQueue("start job");

				for (val path : getIrisFileList()) {
					val builder = new StringBuilder(path.getLeft().toFile().getName()).append("_")
							.append(path.getLeft().toFile().getName());
					val fileName = builder.toString();
					logger.info("Next file is {}.", fileName);

					Extract request = null;
					// val request = soapBuilder.buildIrisExtract(path);
					if (extraction_.getSoap().isOutputRequest()) {
//						output(request);
					}

					logger.info("waiting for takeing from queue");
					String jobId = reqController_.take();
					logger.info("got job ID:{} from queue", jobId);

					val stopwatch = Stopwatch.createStarted();
					// jobId =
					// client.submitExtractionJob(extraction_.getSoap().getEndpoint(),
					// request)
					// .getReturn();
					logger.info("got job ID:{}", jobId);

					if (extraction_.getSoap().isOutputRequest()) {
//						output(request);
					}

					turnAroundTime_.put(jobId, Pair.of(fileName, stopwatch));
				}

				logger.info("waiting for takeing from queue");
				val jobId = reqController_.take();
				logger.info("got job ID:{} from queue", jobId);

				// waiting for sending latest request.
				sleep(4 * 1000);
			} catch (Exception ex) {
				logger.error(Throwables.getStackTraceAsString(ex));
			} finally {
			}
			logger.info("stopped a sending thread as {}", Thread.currentThread().getName());
		}

		/**
		 *
		 */
		private void processPalmRequest() {
			val nistReader = new NistReader();
			try {
				List<Path> paths = null;
				paths = getNistType15FileList();

				addRequestQueue("start job");

				val protoBuilder = new ProtoBuilder(terminalId_);
				for (val path : paths) {
					val fileName = path.toFile().getName();
					logger.info("Next file is {}.", fileName);

					val map = nistReader.getType15Image(path.toAbsolutePath().toString());

					PBExtractJobRequest request = null;
					if (map.containsKey(20)) {
						request = protoBuilder.buildLatentPalmExtractJobRequest(map);
					} else {
						request = protoBuilder.buildPalmExtractJobRequest(map, "");
					}

					if (extraction_.getProto().isOutputRequest()) {
						output(request);
					}

					logger.info("waiting for takeing from queue");
					String jobId = reqController_.take();
					logger.info("got job ID:{} from queue", jobId);

					val stopwatch = Stopwatch.createStarted();
					val response = HttpClient.post(request);
					if (!response.isPresent()) {
						logger.error("response did not exit.");
						continue;
					}




					jobId = String.valueOf(response.get().getJobId());
					logger.info("got job ID:{}", jobId);
					jobIdQueue_.add(jobId);

					turnAroundTime_.put(jobId, Pair.of(fileName, stopwatch));
				}

				logger.info("waiting for takeing from queue");
				val jobId = reqController_.take();
				logger.info("got job ID:{} from queue", jobId);

				// waiting for sending latest request.
				sleep(4 * 1000);
			} catch (Exception ex) {
				logger.error(Throwables.getStackTraceAsString(ex));
			} finally {
				httpServer_.stop(0);
			}
			logger.info("stopped a sending thread as {}", Thread.currentThread().getName());
		}

		private void output(PBExtractJobRequest request) {
			val builder = new StringBuilder("extract_request_").append(terminalId_).append(".txt");
			try {
				Files.write(Paths.get(builder.toString()), request.toString().getBytes());
			} catch (IOException ex) {
				logger.error(Throwables.getRootCause(ex).toString());
			}
		}
	}

}
