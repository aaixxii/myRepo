#!/bin/sh

#export JAVA_OPTS="-Xms2048m -Xmx4096m -XX:+HeapDumpOnOutOfMemoryError -XX:+TieredCompilation -XX:+UseG1GC -XX:+UseAdaptiveSizePolicy -XX:ReservedCodeCacheSize=128m"


#export PATH=./segment-mathcer_jar/bin

export JAVA_OPTS="-Xms2048m -Xmx4096m -XX:+TieredCompilation -XX:+UseG1GC -XX:+UseAdaptiveSizePolicy -XX:ReservedCodeCacheSize=128m"

#export JAVA_OPTS="-Xms2048m -Xmx4096m -XX:+TieredCompilation -XX:+UseG1GC -XX:+UseAdaptiveSizePolicy -XX:ReservedCodeCacheSize=128m"

rm -f *.log
rm -f *.csv


#java $JAVA_OPTS -Dlogback.configurationFile=./logback.xml -Dlog4j.configuration=file:///home/soapui/xm/segment-matcher/log4j.xml -Djava.library.path=/home/kawamura/lib:/home/kawamura/lmx-sdk-4.9/linux_x64 -jar target/xm-segment_matcher-jar-with-dependencies.jar $1 $2 $3

#java $JAVA_OPTS -Dlogback.configurationFile=logback.xml -Dlog4j.configuration=logging/log4j.xml -Djava.library.path=/home/kawamura/lib:/home/kawamura/lmx-sdk-4.9/linux_x64 -jar target/xm-segment_matcher-jar-with-dependencies.jar $1 $2 $3

java $JAVA_OPTS -Dlogback.configurationFile=logback.xml -Djava.library.path=/home/soapui/lib:/home/soapui/lmx-sdk-4.9/linux_x64 -jar target/aim_web_service_execution-jar-with-dependencies.jar $1 $2 $3

#java $JAVA_OPTS -Dlog4j2.configurationFile=file:///home/soapui/xm/segment-matcher/log4j2.xml -Djava.library.path=/home/kawamura/lib:/home/kawamura/lmx-sdk-4.9/linux_x64 -jar target/xm-segment_matcher-jar-with-dependencies.jar $1 $2 $3

#java $JAVA_OPTS -Dlog4j2.configurationFile=./log4j2.xml -Djava.library.path=/home/kawamura/lib:/home/kawamura/lmx-sdk-4.9/linux_x64 -jar target/xm-segment_matcher-jar-with-dependencies.jar $1 $2 $3
