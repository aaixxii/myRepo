package com.nec.aim.uid.client.socket;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.aim.uid.client.exception.UidClientException;
import com.nec.aim.uid.client.manager.UidDmJobRunManager;


public class SocketHeatBeatSender implements Runnable{
	private static Logger logger = LoggerFactory.getLogger(SocketHeatBeatSender.class);
	private String dmWebContent;
	private String dmsIpandProt;
	private int dmSocketPort;
	private List<Selector> selectorList = new ArrayList<>();
	private Map<String , Selector> socketMap = new HashMap<>();
	private final static int WRITTING_LATENCY = 5 * 1000;//ms
	private int socketTimeout = 5 * 1000;	
	private ByteBuffer reUsableBuffer = ByteBuffer.allocateDirect(1024);
	
	public SocketHeatBeatSender(String dmWebContent, String allDmUrl, String dmSocketPort) {
		this.dmWebContent = dmWebContent;
		this.dmsIpandProt = allDmUrl;	
		this.dmSocketPort = Integer.valueOf(dmSocketPort).intValue();
		init();
	}
	
	private void init() {
		String[] ipAndPorts = dmsIpandProt.split(",");
		if (ipAndPorts == null || ipAndPorts.length < 1) {
			throw new UidClientException("DM Service ip and port not setting in config file.");
		}
		
		for (String one : ipAndPorts) {
			String ip = one.split(":")[0];
			//String port = one.split(":")[1];
			int port = dmSocketPort;
			if (ip != null && !ip.isEmpty() && port > 0) {
				InetSocketAddress hostAddress = new InetSocketAddress(ip, Integer.valueOf(port).intValue());
				try {
					SocketChannel socketChannel = SocketChannel.open(hostAddress);
					socketChannel.configureBlocking(false);
					socketChannel.socket().setReuseAddress(true);
					socketChannel.socket().setKeepAlive(true);
					socketChannel.socket().setSoTimeout(socketTimeout);
					Selector selector = Selector.open();
					socketChannel.register(selector, SelectionKey.OP_WRITE | SelectionKey.OP_READ);
					selectorList.add(selector);
					socketMap.put(one, selector);
				} catch (IOException e) {
					logger.error(e.getMessage(), e);				
				}
			}			
		}
	}	

	@Override
	public void run() {
		socketMap.entrySet().forEach( entry -> {
			runOneEntry(entry);
		});
		
	}
	
	public void runOneEntry(Entry<String, Selector> entry) {
		SelectionKey key = null;
		Selector selector = entry.getValue();
		String ipAndPort = entry.getKey();
		try {
			while (selector.select() > 0 ) {			
				Set<SelectionKey> keys = selector.selectedKeys();
				Iterator<SelectionKey> keyIterator = keys.iterator();
				while (keyIterator.hasNext()) {
					key = (SelectionKey) keyIterator.next();
					keyIterator.remove();
					if (!key.isValid()) {
						continue;
					}
				}
				if (key.isReadable()) {
					 SocketChannel myClient = (SocketChannel) key.channel();
					 reUsableBuffer.clear();
					
					 int readCount = myClient.read(reUsableBuffer);
				       if (readCount > 0) {
				             reUsableBuffer.flip();
				             byte[] subStringBytes = new byte[readCount];
				             reUsableBuffer.get(subStringBytes);
				             String serverRes = new String(subStringBytes);
				             logger.info(serverRes);
				          }
					 
					 
				}
				 if (key.isWritable()) {
//					 String baseUrl =  "http://" + ipAndPort +"/" + dmWebContent;
//					 SocketChannel myClient = (SocketChannel) key.channel();					 
//					if (isServerClosed(myClient.socket())) {						
//						logger.error("Socket Channl may be Closed!");
//						logger.warn("{} is not active!", baseUrl);
//						UidDmJobRunManager.removeDmServiceFromMe(baseUrl);
//					} else {
//						UidDmJobRunManager.addActiveDmServiceTome(baseUrl);	
//						logger.info("{} is active!", baseUrl);
//					}
				 }
				
				try {
					Thread.sleep(WRITTING_LATENCY);
				} catch (InterruptedException e) {
					logger.error(e.getMessage(), e);
				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}
	
	private boolean isServerClosed(Socket socket) {
		try {
			socket.sendUrgentData(0);
			return false;
		} catch (IOException e) {
			return true;
		}		
	}
}
