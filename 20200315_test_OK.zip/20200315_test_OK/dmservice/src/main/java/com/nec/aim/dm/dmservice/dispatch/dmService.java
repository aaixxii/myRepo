package com.nec.aim.dm.dmservice.dispatch;

import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.aim.dm.dmservice.config.ConfigProperties;
import com.nec.aim.dm.dmservice.socket.HeatBeatSocketServer;

@Service
public class dmService {
	private static final ConcurrentHashMap<String, String> myMap = new ConcurrentHashMap<>();
	private static final String ALL_CONN_STR = "connectionString";
	private static final String SERVER_SOCKET_PORT = "socketPort";
	private static final String SERVER_SOCKET_TIMEOUT = "serverSocketTimeout";
	private HeatBeatSocketServer server;

	@Autowired
	ConfigProperties config;

	@PostConstruct
	public void getSetting() {
//		String conStrs = config.getConnectString();
//		myMap.put(ALL_CONN_STR, conStrs);
//		String socketPort = config.getServerSocketPort();
//		myMap.put(SERVER_SOCKET_PORT, socketPort);
//		String socketTimelout = config.getServerSocketTimeout();
//		myMap.put(SERVER_SOCKET_TIMEOUT, socketTimelout);
//		server = new HeatBeatSocketServer();
//		server.start(Integer.valueOf( socketPort), conStrs);
	}

	@PreDestroy
	public void close() {
		
	}
	
	public String getValue(String key) {
		return myMap.get(key);
	}
	
	public void put(String key, String value) {
		myMap.putIfAbsent(key, value);
		
	}

}
