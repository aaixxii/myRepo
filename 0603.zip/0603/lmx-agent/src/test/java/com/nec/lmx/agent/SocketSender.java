package com.nec.lmx.agent;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.SocketChannel;

class SocketSender {
	private static final int BUFF_SIZE = 256;
	private ByteBuffer sendBuff;
	private SocketChannel socketChannel;
	private Object channelLocker;	
	
	public SocketSender() {	
		this.channelLocker = new Object();
		sendBuff = ByteBuffer.allocate(BUFF_SIZE);
	}
	
	public void init(SocketChannel socketChannel) {
		this.socketChannel = socketChannel;			
		System.out.println("LmxSocketSender started!");		
	}
	
	public void sendLinceseInfo(String licenseInfo) {
		int sendSize = 0;
		try {
			byte[] bodys = licenseInfo.getBytes("UTF-8");
			int sizeOfBody = bodys.length;
			sendBuff.clear();
			sendBuff.order(ByteOrder.BIG_ENDIAN);
			sendBuff.put(bodys);
			sendBuff.flip();
			synchronized (channelLocker) {
				while (sendBuff.hasRemaining()) {
					sendSize = socketChannel.write(sendBuff);
					assert(sizeOfBody == sendSize );
					System.out.println("Send data size{}: " + sendSize);
				}
			}
			sendBuff.clear();
			try {
				Thread.sleep(10 * 60 * 1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
