package com.nec.lmx.agent;

import java.io.IOException;
import java.lang.reflect.Type;
import java.net.InetSocketAddress;
import java.nio.channels.SocketChannel;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

public class LmxSenderMain {
	private final static ConcurrentHashMap<String, String> licenseMap = new ConcurrentHashMap<>();

	public static void main(String[] args) {
		SocketSender mock = new SocketSender();
		mock.init(createSocketChannel(8888));
		licenseMap.put("AFIS", "TYPE=FULL;COMPONENT=VM;MODALTY=FINGER,FACE,PALM,IRIS");
		licenseMap.put("EXPIRED", "false");		
		Gson gson = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
		Type mapType = new TypeToken<Map<String, String>>() {}.getType();		
		String licesneInfo = gson.toJson(licenseMap, mapType);	
		//String sendMsg = "TYPE=FULL;COMPONENT=VM;MODALTY=FINGER,FACE,PALM,IRIS" + "EXPIRED=false";
		mock.sendLinceseInfo(licesneInfo);

	}
	
	public static SocketChannel createSocketChannel(int port) {
		SocketChannel socketChannel = null;
		try {			
			InetSocketAddress hostAddress = new InetSocketAddress("localhost", port); 
			socketChannel = SocketChannel.open(hostAddress);			
			socketChannel.configureBlocking(false);
			socketChannel.socket().setKeepAlive(true);
			socketChannel.socket().setSoTimeout(500000);
			System.out.println("Connecting to local Server on port:" + port);		
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		return socketChannel;
	}

}
