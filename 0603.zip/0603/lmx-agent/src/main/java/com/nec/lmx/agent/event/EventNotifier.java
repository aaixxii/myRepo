package com.nec.lmx.agent.event;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author xiazp <br/>
 *         EventNotifier fired event while some thing is happened
 */
public class EventNotifier {
	private static final EventNotifier INSTANCE = new EventNotifier();

	private static List<EventListener> listenerQueue = new ArrayList<>();	

	private EventNotifier() {
	}

	public static EventNotifier getInstance() {
		return INSTANCE;
	}

	public synchronized void addListener(EventListener listener) {
		listenerQueue.remove(listener);
		listenerQueue.add(listener);
	}

	public synchronized void removeListener(EventListener listener) {
		listenerQueue.remove(listener);
	}
	
	public void fireOnMessage(String message) {
		for (EventListener listener :listenerQueue) {
			listener.onMessage(message);						
		}
	}
	
	public void fireOnError(String error) {
		for (EventListener listener :listenerQueue) {
			listener.onError(error);						
		}
	}

	public void fireOnStop() throws IOException {
		for (EventListener listener :listenerQueue) {
			listener.onStop();
			listenerQueue.remove(listener);			
		}
	}
}
