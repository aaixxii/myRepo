package jp.co.nec.aim.mm.procedure;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.helper.TemplateHeaderHelper;
import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;
import jp.co.nec.aim.mm.segment.sync.SegSyncInfos;

import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.jdbc.object.StoredProcedure;

import com.google.protobuf.ByteString;

/**
 * AddBiometricsProcedure
 * 
 * @author liuyq
 * 
 */
public class AddBiometricsProcedure extends StoredProcedure {
	/** the name of add_biometrics Procedure **/
	private static final String SQL = "MATCH_MANAGER_API.ADD_BIOMETRICS";
	private static final int UPDATE_EXIST_SEG = 0; // update exist segment

	private String externalId; // externalId
	//private Integer eventId; // eventId
	private Integer containerId; // containerId
	//private byte[] biometricsData; // template data

	/**
	 * AddBiometricsProcedure constructor
	 * 
	 * @param dataSource
	 *            the instance of DataSource
	 */
	public AddBiometricsProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(SQL);
		setFunction(true);
		declareParameter(new SqlOutParameter("l_seg_created", Types.BIGINT));
		declareParameter(new SqlParameter("p_external_id", Types.VARCHAR));
		//declareParameter(new SqlParameter("p_event_id", Types.INTEGER));
		declareParameter(new SqlParameter("p_container_id", Types.INTEGER));
		//declareParameter(new SqlParameter("p_biometric_data", Types.BLOB));
		declareParameter(new SqlOutParameter("p_seg_id", Types.BIGINT));
		declareParameter(new SqlOutParameter("p_seg_version", Types.BIGINT));
		declareParameter(new SqlOutParameter("p_biometric_id", Types.BIGINT));
		compile();
	}

	/**
	 * execute the Procedure add_biometrics
	 * 
	 * @return is new segment generated
	 */
	public SegSyncInfos execute() {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_external_id", getExternalId());
		//map.put("p_event_id", getEventId());
		map.put("p_container_id", getContainerId());
		//map.put("p_biometric_data", new SqlLobValue(getBiometricsData()));
		Map<String, Object> resultMap = execute(map);
		int segCreated = ((Long) resultMap.get("l_seg_created")).intValue();
		Long segmentId = (Long) resultMap.get("p_seg_id");
		Long segVersion = (Long) resultMap.get("p_seg_version");
		Long biometricId = (Long) resultMap.get("p_biometric_id");
		return new SegSyncInfos(
				segmentId,
				segVersion,	
				biometricId,
				(segCreated == UPDATE_EXIST_SEG),
				SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT);
	}

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public Integer getContainerId() {
		return containerId;
	}

	public void setContainerId(Integer containerId) {
		this.containerId = containerId;
	}
}
