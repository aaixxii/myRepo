package jp.co.nec.aim.mm.util;

import jp.co.nec.aim.mm.acceptor.Record;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.exception.TemplateValidatorException;

/**
 * RecordChecker
 * 
 * @author liuyq
 * 
 */
public class RecordChecker {

	/**
	 * checkRecord
	 * 
	 * @param r
	 *            the instance of Record
	 */
	public static void checkRecord(Record r) {
		String binary = r.getResult();
		if (binary == null || binary.length() <= 0) {
			AimError templateErr = AimError.TEMPLATE_VALIDATOR_ERROR;
			String errMsg = String.format(templateErr.getMessage(), "no data found while do insert template to db");			
			throw new TemplateValidatorException(templateErr.getErrorCode(), errMsg, String.valueOf(System.currentTimeMillis()),templateErr.getUidCode());
		}
	}
}
