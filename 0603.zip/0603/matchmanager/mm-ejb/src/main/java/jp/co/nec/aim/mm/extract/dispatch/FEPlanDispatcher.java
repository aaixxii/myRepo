package jp.co.nec.aim.mm.extract.dispatch;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

import jp.co.nec.aim.message.proto.AIMMessages.PBImageSelectionMode;
import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobItem;
import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobOption;
import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobRequest;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.dao.CommitDao;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.FEJobDao;
import jp.co.nec.aim.mm.dao.FEPlanDispatchDao;
import jp.co.nec.aim.mm.dao.FEPlanDispatchDaoImpl;
import jp.co.nec.aim.mm.dao.MuLoadDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.entities.FeJobPayloadEntity;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.entities.FeLotJobEntity;
import jp.co.nec.aim.mm.entities.MatchUnitEntity;
import jp.co.nec.aim.mm.entities.UnitState;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.sessionbeans.pojo.AimServiceState;
import jp.co.nec.aim.mm.sessionbeans.pojo.ExtractJobHandler;
import jp.co.nec.aim.mm.util.StopWatch;
import jp.co.nec.aim.uid.jaxb.Diagnostics;
import jp.co.nec.aim.uid.jaxb.Response;
import jp.co.nec.aim.uid.jaxb.Return;

/**
 * dispatch extract plan to mu
 * 
 * @author xiazp
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class FEPlanDispatcher {
	private static Logger logger = LoggerFactory
			.getLogger(FEPlanDispatcher.class);

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;
	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	private FEPlanDispatchDao fEPlanDispatchDao;
	private ExtractJobHandler extractJobHandler;
	private MuLoadDao muLoadDao;
	private FEJobDao extractJobDao;
	private CommitDao commitDao;
	private SystemConfigDao systemConfigDao;

	private static final String DISPATCH_MU_URL_CONTENT = "matchunit/ExtractJob";
	private static final String SLASH = "/";
	private static final String HTTP = "http://";
	private static final String COMMA = ",";
	
	private DateDao dateDao;

	public FEPlanDispatcher() {
	}

	@PostConstruct
	public void init() {
		jdbcTemplate = new JdbcTemplate(dataSource);
		fEPlanDispatchDao = new FEPlanDispatchDaoImpl(manager, jdbcTemplate);
		dateDao = new DateDao(dataSource);
		muLoadDao = new MuLoadDao(dataSource);
		extractJobDao = new FEJobDao(manager);
		extractJobHandler = new ExtractJobHandler(manager, dataSource);
		systemConfigDao = new SystemConfigDao(manager);			
		commitDao = new CommitDao(dataSource);
	}

	@PreDestroy
	public void destroy() {
		fEPlanDispatchDao = null;
	}

	/**
	 * Get feJobInfo from database and dispach it to mu.
	 * 
	 * @param feLotJobId
	 * @throws SQLException
	 * @throws PersistenceException
	 */
	public boolean doDispatch(Long feLotJobId) {
		logger.info("FEPlanDispatcher prepare to dispathing　feLotJobId={} ...",
				feLotJobId);
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		boolean isFailed = false;
		ComponentProcessStautsInfo processInfo = new ComponentProcessStautsInfo();
		FeLotJobEntity feLotJob = fEPlanDispatchDao.getFeLotJob(feLotJobId);
		if (feLotJob == null) {
			logger.error(
					"feLotJob(Id:{}) is not found while prepare dispatch extract job to mus",
					feLotJobId);
			final AimError aimError = AimError.EXTRACT_DISPATCH_FE_LOT_JOB_NOT_FOUND;
			processInfo.setMsgCode(aimError.getErrorCode());
			processInfo.setMsgType(MessageType.ERROR);
			processInfo.setProcessType(ProcessType.EXTRACT);
			processInfo.setFailureReason(String.format(aimError.getMessage(),
					feLotJob));
			processInfo.setReasonTime(dateDao.getReasonTime());
			processInfo.setResultTime(dateDao.getCurrentTimeMS());
			isFailed = true;
		}
		if (!isFailed && feLotJob.getMuId() <= 0) {
			logger.error("MuId is incorrect! muId({})", feLotJob.getMuId());
			final AimError aimError = AimError.EXTRACT_DISPATCH_MU_NOT_FOUND;
			processInfo.setMsgCode(aimError.getErrorCode());
			processInfo.setMsgType(MessageType.ERROR);
			processInfo.setProcessType(ProcessType.EXTRACT);
			processInfo.setFailureReason(String.format(aimError.getMessage(),
					feLotJob.getMuId()));
			processInfo.setReasonTime(dateDao.getReasonTime());
			processInfo.setResultTime(dateDao.getCurrentTimeMS());
			isFailed = true;
		}
		String muUrl = null;
		if (!isFailed) {
			muUrl = fEPlanDispatchDao.getMuUrl(feLotJob.getMuId());
		}
		if (!isFailed
				&& (muUrl == null || muUrl.isEmpty() || !muUrl.startsWith(HTTP))) {
			logger.error("Mu URL is not found or incorrect!");
			final AimError aimError = AimError.EXTRACT_DISPATCH_MU_URL_NOT_FOUND;
			processInfo.setMsgCode(aimError.getErrorCode());
			processInfo.setMsgType(MessageType.ERROR);
			processInfo.setProcessType(ProcessType.EXTRACT);
			processInfo.setFailureReason(aimError.getMessage());
			processInfo.setReasonTime(dateDao.getReasonTime());
			processInfo.setResultTime(dateDao.getCurrentTimeMS());
			isFailed = true;
		}
		if (!isFailed && !muUrl.endsWith(SLASH)) {
			muUrl = muUrl + SLASH;
		}
		muUrl = muUrl + DISPATCH_MU_URL_CONTENT;
		List<FeJobQueueEntity> feJobList = null;
		if (!isFailed) {
			feJobList = fEPlanDispatchDao.getFeJobs(feLotJobId);
		}

		if (!isFailed && (feJobList == null || feJobList.size() == 0)) {
			logger.error("feJob is not exist in FeLotJob({})",
					feLotJob.getLotJobId());
			final AimError aimError = AimError.EXTRACT_DISPATCH_FE_JOB_NOT_FOUND;
			processInfo.setMsgCode(aimError.getErrorCode());
			processInfo.setMsgType(MessageType.ERROR);
			processInfo.setProcessType(ProcessType.EXTRACT);
			processInfo.setFailureReason(String.format(aimError.getMessage(),
					feLotJobId));
			processInfo.setReasonTime(dateDao.getReasonTime());
			processInfo.setResultTime(dateDao.getCurrentTimeMS());
			isFailed = true;
		}

		List<Long> feJobIds = new ArrayList<>();
		if (!isFailed && feJobList.size() > 0) {
			for (FeJobQueueEntity feJob : feJobList) {
				feJobIds.add(feJob.getId());
			}
		}
		List<FeJobPayloadEntity> feJobsPayLoadList = null;
		if (feJobIds.size() > 0) {
			feJobsPayLoadList = fEPlanDispatchDao.getFeJobPayLoads(feJobIds);
		}

		if (!isFailed
				&& (feJobsPayLoadList == null
						|| feJobsPayLoadList.size() < feJobIds.size() || feJobsPayLoadList
						.size() != feJobIds.size())) {
			logger.error(
					"some extract payload is not found in FeLotjob(ID={})",
					feLotJob.getLotJobId());
			final AimError aimError = AimError.EXTRACT_DISPATCH_FE_PAYLOAD_NOT_FOUND;
			processInfo.setMsgCode(aimError.getErrorCode());
			processInfo.setMsgType(MessageType.ERROR);
			processInfo.setProcessType(ProcessType.EXTRACT);
			processInfo.setFailureReason(aimError.getMessage());
			processInfo.setReasonTime(dateDao.getReasonTime());
			processInfo.setResultTime(dateDao.getCurrentTimeMS());
			isFailed = true;
		}
		PBMuExtractJobRequest extractJobRequest = null;
		if (!isFailed) {
			extractJobRequest = buildFeRequest(feLotJob.getLotJobId(),
					feLotJob.getTimeouts(), feJobIds, feJobsPayLoadList);
			if (!Objects.isNull(extractJobRequest)) {
				int muPostRetryCount = Integer.valueOf(fEPlanDispatchDao
						.getSystemConfigValue(MMConfigProperty.MU_POST_COUNT
								.getName()));
				ExtractRequestPoster poster = new ExtractRequestPoster(); //dipatch to mu
				if (!poster.postRequest(muUrl, muPostRetryCount,
						extractJobRequest.toByteArray())) {
					final AimError aimError = AimError.EXTRACT_DISPATCH_SEND_RETRY_OVER;
					processInfo.setMsgCode(aimError.getErrorCode());
					processInfo.setMsgType(MessageType.ERROR);
					processInfo.setProcessType(ProcessType.EXTRACT);
					processInfo.setFailureReason(aimError.getMessage());
					processInfo.setReasonTime(dateDao.getReasonTime());
					processInfo.setResultTime(dateDao.getCurrentTimeMS());
					setTimeOutforPostFailedMu(feLotJob.getMuId());
					isFailed = true;
					poster = null;
				} else {
					StringBuilder sb = new StringBuilder();
					for (FeJobQueueEntity feJob : feJobList) {
						sb.append(feJob.getId());
						sb.append(COMMA);
					}
					int last = sb.length();
					sb.deleteCharAt(last - 1);
					logger.info(
							"FeLotJob({})- feJobs({}) is success to dispatched to {}",
							feLotJobId, sb.toString(), feLotJob.getMuId());
					stopWatch.stop();
					PerformanceLogger.log(getClass().getSimpleName(), "doDispatch",
							stopWatch.elapsedTime());
				}
				
			}

		}
		if (isFailed && feJobList != null) {
			Integer maxFailedCount = fEPlanDispatchDao.getMaxExtractJobRetryCount();
					
			for (FeJobQueueEntity feJob : feJobList) {
				logger.debug("FeLotJob({})- feJob({}) is failed", feLotJobId,
						feJob.getId());
				setTimeOutforPostFailedMu(feJob.getMuId().longValue());
				AimServiceState aimServiceState = new AimServiceState();
				aimServiceState.setErrMsg(processInfo.getFailureReason());
				aimServiceState.setErrorcode(processInfo.getMsgCode());
				aimServiceState.setFailureTime(processInfo.getReasonTime());
				//Create faild xml repose;
//				Response xmlRes = new Response();
//				xmlRes.setRequestId(feJob.getRequestId());
//				xmlRes.setTimeStamp(System.currentTimeMillis());
//				Return rt = new Return();
//				rt.setValue(0);
//				rt.setFailureReason(-1);
//				xmlRes.setReturn(rt);
//				Diagnostics ds = new Diagnostics();
//				xmlRes.setDiagnostics(ds);
						
				try {
					int count = extractJobHandler.failExtractJob(null, feJob, feJob .getMuId().longValue(), aimServiceState, false, maxFailedCount);							
					if (count > 0) {
						extractJobDao.deleteLotJob(feJob.getLotJobId());
						commitDao.commit();
					}
				} catch (AimRuntimeException e) {
					logger.error(e.getMessage(), e);
				}
			}
			muLoadDao.decreaseExtractLoad(new Long(feLotJob.getMuId()));
		}
		processInfo = null;
		return !isFailed;
	}

	/**
	 * Create PBMuExtractJobRequest
	 * 
	 * @param lotJobId
	 * @param timeout
	 * @param feJobIds
	 * @param payLoads
	 * @return
	 */
	protected PBMuExtractJobRequest buildFeRequest(long lotJobId, long timeout, final List<Long> feJobIds,
			final List<FeJobPayloadEntity> payLoads) {
		PBMuExtractJobRequest.Builder request = PBMuExtractJobRequest.newBuilder();
		request.setLotJobId(lotJobId);
		try {
			for (int i = 0; i < feJobIds.size(); i++) {
				PBMuExtractJobItem.Builder extractItem = PBMuExtractJobItem.newBuilder();
				final Long jobId = feJobIds.get(i);
				extractItem.setJobId(feJobIds.get(i));
				extractItem.setJobTimeout(timeout < 0 ? Long.MAX_VALUE : timeout);
				payLoads.forEach(py -> {
					if (py.getJobId() == jobId.longValue()) {
						extractItem.setRequest(py.getPayload());
					}
				});		
				
				request.addJobs(i, extractItem.build());			
			}
			PBMuExtractJobOption.Builder pbMuExtJobOption = PBMuExtractJobOption.newBuilder();
			PBImageSelectionMode.Builder pBImageSelectionMode = PBImageSelectionMode.newBuilder();
			pBImageSelectionMode.setFace(systemConfigDao.getMMProperty(MMConfigProperty.IMAGE_SELECTION_MODE_FACE));
			pBImageSelectionMode.setIris(systemConfigDao.getMMProperty(MMConfigProperty.IMAGE_SELECTION_MODE_IRIS));
			pBImageSelectionMode.setFinger(systemConfigDao.getMMProperty(MMConfigProperty.IMAGE_SELECTION_MODE_FINGER));
			pbMuExtJobOption.setImageSelectionMode(pBImageSelectionMode.build());
			request.setOption(pbMuExtJobOption.build());
		} catch (Exception e) {
			logger.error(e.getMessage(), e.getCause().getMessage());
			return null;
		}
		
		return request.build();
	}		

	private void setTimeOutforPostFailedMu(long muId) {
		MatchUnitEntity mu = manager.find(MatchUnitEntity.class, muId);
		mu.setState(UnitState.TIMED_OUT);
		manager.merge(mu);

	}
}
