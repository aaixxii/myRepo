package jp.co.nec.aim.mm.procedure;

import java.sql.Array;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import oracle.jdbc.OracleArray;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.object.StoredProcedure;

/**
 * 
 * @author xiazp
 *
 */
public class GetLimitedJobsByFamiliyProcedure extends StoredProcedure {
	private static final String GET_LIMITED_JOBS_BY_FAMILIY = "MATCH_MANAGER_API.get_limited_jobs_by_familiy";
	private static final String NUM_TABLE_TYPE = "NUM_TABLE_TYPE";

	public GetLimitedJobsByFamiliyProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setFunction(true);
		setSql(GET_LIMITED_JOBS_BY_FAMILIY);
		declareParameter(new SqlOutParameter("l_job_ids", Types.ARRAY,
				NUM_TABLE_TYPE));
		compile();
	}

	/**
	 * 
	 * @return
	 * @throws DataAccessException
	 * @throws SQLException
	 */
	public List<Long> getLimitedJobsByFamiliy() throws DataAccessException,
			SQLException {
		Map<String, Object> results = execute();
		Array array = (Array) results.get("l_job_ids");
		OracleArray rsAarray = (OracleArray) array;
		long[] tmp = rsAarray.getLongArray();
		if (tmp.length == 0) {
			return null;
		}
		List<Long> jobIds = new ArrayList<>();
		for (int i = 0; i < tmp.length; i++) {
			jobIds.add(new Long(tmp[i]));
		}
		return jobIds;
	}
}
