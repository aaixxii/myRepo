package jp.co.nec.aim.mm.acceptor;

/**
 * Record information used for save the template
 * 
 * @author liuyq
 * 
 */
public class Record {
	
	private String result;
	private byte[] diagnostcs;

	
	public Record(byte[] binary) {
		this.diagnostcs = binary;
	}
	
	public Record(String result) {
		this.result = result;
	}
	
	public Record(String result, byte[] binary) {
		this.result = result;
		this.diagnostcs = binary;
	}

	
	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public byte[] getDiagnostcs() {
		return diagnostcs;
	}

	public void setDiagnostcs(byte[] diagnostcs) {
		this.diagnostcs = diagnostcs;
	}
	
}
