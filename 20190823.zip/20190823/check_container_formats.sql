CREATE DEFINER=`aimuser`@`%` PROCEDURE `check_container_formats`(
     in p_function_id int,
     in  p_candidate_containers VARCHAR(1024)
)
BEGIN
      DECLARE l_actual_format_name VARCHAR(255);
      DECLARE l_target_format_name VARCHAR(255);
      DECLARE l_target_format_id int;
      DECLARE l_function_name VARCHAR(20);
      
       SELECT  f.target_format_id, f.function_name
              INTO l_target_format_id, l_function_name
      FROM function_types f
      WHERE f.function_id = p_function_id;


END