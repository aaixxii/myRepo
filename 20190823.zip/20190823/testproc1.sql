CREATE PROCEDURE `new_procedure` ()
BEGIN
 use AIMDB;
SELECT 
    *
FROM
    containers;
END
