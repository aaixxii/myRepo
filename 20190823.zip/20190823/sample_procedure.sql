DROP PROCEDURE IF EXISTS sample_procedure;
DELIMITER //
CREATE PROCEDURE sample_procedure(
  IN v_user_id varchar(45),      -- userId
  IN v_item_id bigint(20),       -- 付与アイテムID
  IN v_add_count int(11),        -- 付与アイテム数
  OUT code TEXT                  -- 結果コード
)

BEGIN
  DECLARE a_cnt BIGINT;
  DECLARE i_cnt BIGINT;
  DECLARE EXIT HANDLER FOR SQLWARNING, SQLEXCEPTION, NOT FOUND
    BEGIN
    SET code    = '-99';
    END;
  SELECT '' as '---------- add item ----------';
  SELECT v_user_id, v_item_id, v_add_count;
  -- ユーザの存在チェック
  SELECT count(*) INTO a_cnt FROM user WHERE id = v_user_id;
  IF a_cnt > 0 THEN
    SELECT count(*) INTO i_cnt FROM my_item WHERE user_id = v_user_id AND item_id = v_item_id;
    IF i_cnt = 0 THEN 
    -- アイテムレコードがなければ新規作成
      INSERT into my_item (user_id,  item_id,  count )
      VALUES (v_user_id,  v_item_id,  v_add_count);
    ELSE
      -- アイテムがあれば個数を更新
      UPDATE my_item set count = count + v_add_count where user_id = v_user_id and item_id = v_item_id;
    END IF;
  ELSE
  SELECT 'user not found' as message;
  END IF;
  SET code = '0'; -- 正常コードを返す
END;
//
DELIMITER ;