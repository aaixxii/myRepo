package com.nec.aim.bison;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BisonApplication {

	public static void main(String[] args) {
		SpringApplication.run(BisonApplication.class, args);
	}

}
