package com.nec.aim.dm.dmservice.entity;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class SegmentLoading {
	Integer nsmId;
	Long segmentId;
	String status; // 'CREATED', 'ONLINE'
	Long lastVersion;
	Timestamp lastTs;
}
