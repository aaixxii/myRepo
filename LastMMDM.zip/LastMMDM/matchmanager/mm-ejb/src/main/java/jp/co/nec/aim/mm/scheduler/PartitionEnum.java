/**
 * 
 */
package jp.co.nec.aim.mm.scheduler;

/**
 * @author xia
 *
 */
public enum PartitionEnum {
	RotationTask("rotationTask",  "rotationTaskTri", "rotationTaskGroup"),
	TodayPnoSet("todayPnoSet", "todayPnoSetTri", "todayPnoSetGroup"),
	CreateNextDayPartition("createNextDayPartition",  "createNextDayPartitionTri", "CreateNextDayPartitionGroup"),
	ClearOldPartition("clearOldPartition",  "clearOldPartitionTri", "ClearOldPartitionGroup"),
	ReservationReducePartition("reservationReducePartition",  "reservationReducePartitionTri", "tReservationReducePartitiontGroup");	
	
	public String getJobKey() {
		return jobKey;
	}

	public void setJobKey(String jobKey) {
		this.jobKey = jobKey;
	}

	public String getTriggerKey() {
		return triggerKey;
	}

	public void setTriggerKey(String triggerKey) {
		this.triggerKey = triggerKey;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	private String jobKey;
	private String triggerKey;
	private String group;	

	private PartitionEnum(String jobKey, String triggerKey,  String group) {
		this.jobKey = jobKey;
		this.triggerKey = triggerKey;
		this.group = group;
	}
}
