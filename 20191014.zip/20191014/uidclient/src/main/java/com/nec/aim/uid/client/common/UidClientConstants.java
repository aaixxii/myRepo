package com.nec.aim.uid.client.common;

public class UidClientConstants {
	public static final String UID_SYNC_URL = "/AIMSyncService/sync";
	
	public static final String UID_INQUIRY_URL = "/AIMInquiryService/inquiry";
	public static final String UID_INQUIRY_DEL_URL = "/AIMInquiryService/deleteJob";
	public static final String UID_INQUIRY_CLEAR_URL = "/AIMInquiryService/clearJobs";
	
	public static final String UID_EXTRACT_URL = "/AIMExtractService/extract";	
	public static final String UID_EXTRACT_DEL_URL = "/AIMExtractService/deleteJob";
	public static final String UID_EXTRACT_CLEAR_URL = "/AIMExtractService/clearJobs";
	
	public static final String UID_MR_JOB_POST_URL = "/mapreducer/MapInquiryJob";
	public static final String UID_MU_JOB_POST_URL = "/matchunit/ExtractJob";
	
	public static final String UID_xxx = "/AIMSyncService/sync";	


}
