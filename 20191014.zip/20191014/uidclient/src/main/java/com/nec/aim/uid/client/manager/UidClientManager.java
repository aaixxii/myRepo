package com.nec.aim.uid.client.manager;



import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.log4j.PropertyConfigurator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.aim.uid.client.proerties.PropertyUtil;
import com.nec.aim.uid.client.util.ClientUtil;



public class UidClientManager {
	public static final UidClientManager manager = new UidClientManager();
	private static final ConcurrentHashMap<String, String> keyValueMap = new ConcurrentHashMap<>();
	private static Logger logger = LoggerFactory.getLogger(XmClientManager.class);
	private ExecutorService clientExecutor;	
	private ExecutorService callbacExecutor;	
	private static final Random sRandom = new Random(System.currentTimeMillis());
	
	private static final ConcurrentHashMap<String, Long> timesMap = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<String, Integer> priorityMap = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<String, Object> lockerMap = new ConcurrentHashMap<>();
	private static final Lock timesMapLock = new ReentrantLock();

	public UidClientManager() {
		clientExecutor = Executors.newCachedThreadPool();
		callbacExecutor = Executors.newCachedThreadPool();
		
//		ThreadPoolExecutor executor = 
//				new ThreadPoolExecutor(0, Integer.MAX_VALUE, 60L, TimeUnit.SECONDS,
//				new LinkedBlockingQueue<Runnable>());
				
	}
	
	public static Object getLock(String jobId) {
		if (jobId == null) {
			return null;
		} else {
			return lockerMap.get(jobId);
		}
	}
	
	public static void putLocker(String jobId, Object locker) {
		if (jobId != null && locker != null) {
			lockerMap.put(jobId, locker);
		}
	}
	
	public static void removeLock(String jobId) {
		if (jobId != null) {
			lockerMap.remove(jobId);
		}
	}	
	
	public static ConcurrentHashMap<String, Long> getTimesMap() {
		timesMapLock.lock();
		try {
			return timesMap;
		} finally {
			timesMapLock.unlock();
		}
	}

	public static UidClientManager getInstance() {
		return manager;
	}

	public void commitJob(Runnable task) {
		clientExecutor.submit(task);
	}
	
	public void commitCallbackJob(Runnable task) {
		callbacExecutor.submit(task);
	}
	
	public int getMapSize() {
		return keyValueMap.size();
	}

	public void putData(String key, String value) {
		keyValueMap.putIfAbsent(key, value);
	}

	public String getValue(String key) {
		return keyValueMap.get(key);
	}
	
	public static void  putPriority(String jobId, Integer priroty) {
		priorityMap.putIfAbsent(jobId, priroty);
	}
	
	public static Integer getPriority(String jobId) {
		return priorityMap.get(jobId);
	}
	
	public static void removePriority(String jobId) {
		priorityMap.remove(jobId);
	}
	
	public void getBasePath() {
		String properyFullPath = null;
		String jobReqeustPath = null;
		String templatesPath = null;
		String jobresultPathXml = null;		
		String jobresultPathXlsx = null;
		String callbackpath = null;
		String loggerPath = null;		
		
		String myPath = UidClientManager.class.getProtectionDomain().getCodeSource().getLocation().getPath();
		String xmBaseDir = myPath.substring(0, myPath.length() - 16);
		xmBaseDir = xmBaseDir.endsWith("/") ? xmBaseDir.substring(0,xmBaseDir.length() - 1) : xmBaseDir;
		properyFullPath = xmBaseDir + "/" + "config" + "/" + "xm.client.properties";
		loggerPath =  xmBaseDir + "/" + "config" + "/" + "log4j.properties";		
		jobReqeustPath = xmBaseDir + "/" + "jobrequests";
		templatesPath = xmBaseDir + "/" + "templates";
		jobresultPathXml = xmBaseDir + "/" + "jobresults" + "/" + "xml";		
		jobresultPathXlsx = xmBaseDir + "/" + "jobresults" + "/" + "xlsx";
		callbackpath =  xmBaseDir + "/" + "callbackpath";
		PropertyConfigurator.configure(loggerPath);
		
//		File file = new File(jarPath).getParentFile().getParentFile();
		

	}
	
	public String buildMehgaUrl(String meghaIds, String ports) {
		int serverIpCount = meghaIds.split(",").length;
		int serverPortCount = ports.split(",").length;		
		if (serverIpCount != serverPortCount) {	
			logger.error("There are miss in xm.client.properties file, the count of MEGHA_WS_IP_ADDRESS is not equal the count of MEGHA_WS_PORT_NUM");
			return null;
		}		
		String[] serIps = new String[serverIpCount];
		String[] serPorts = new String[serverIpCount];
		
		for (int i = 0; i < serverIpCount; i++) {
			int ipIndex = meghaIds.indexOf(",");
			if (ipIndex < 0) {
				serIps[i] = meghaIds;
			} else {
				String ip = meghaIds.substring(0, ipIndex);
				serIps[i] = ip;
				meghaIds = meghaIds.substring(ipIndex + 1, meghaIds.length());				
			}			
			int portIndex = ports.indexOf(",");
			if (portIndex < 0) {
				serPorts[i] = ports;				
			} else {
				String port = ports.substring(0, portIndex);
				serPorts[i] = port;	
				ports = ports.substring(portIndex + 1, ports.length());
				}			
			}
		int pickUp = sRandom.nextInt(serverIpCount);
		return serIps[pickUp] + ":" + serPorts[pickUp];		
		}	

	public boolean getAllProperties() {
		getBasePath();
		String propertyFileFullName = keyValueMap.get(PROPERTY_FULL_NAME);	
		try {
			PropertyUtil util = new PropertyUtil(propertyFileFullName);
			String serverIds = util.getPropertyValue(PropertyNames.MEGHA_WS_IP_ADDRESS.name());
			String serverPorts = util.getPropertyValue(PropertyNames.MEGHA_WS_PORT_NUM.name());	
			
			String callbackPort = util.getPropertyValue(PropertyNames.CLIENT_CALLBACK_PORT.name());
			String callbackIp = util.getPropertyValue(PropertyNames.CLIENT_CALLBACK_IP.name());
			if (serverIds == null || serverPorts == null || serverIds.isEmpty() || serverPorts.isEmpty()) {
				String error = "There are miss in xm.client.properties is! serverId or port is empty!";
				logger.error(error);
				return false;
			}
//			String useMehgaIpAndPort = buildMehgaUrl(serverIds, serverPorts);
//			if (useMehgaIpAndPort == null || useMehgaIpAndPort.isEmpty()) {
//				return false;
//			}
			//int idx = useMehgaIpAndPort.indexOf(":");
			//String serverId = useMehgaIpAndPort.substring(0, idx);
			//String serverPort = useMehgaIpAndPort.substring(idx + 1, useMehgaIpAndPort.length());
			
			String serverId = serverIds.split(",")[0];
			String serverPort = serverPorts.split(",")[0];
			ClientUtil cu = new ClientUtil();
			if (!cu.checkIP(serverId)) {
				logger.error("Server ip is incorrect! ip:" + serverId);
				return false;
			}
			
			String circleThreadCurrentCount = util.getPropertyValue(PropertyNames.CIRCLE_THREAD_CURRENET_COUNT.name());
			String oneCircleJobCount = util.getPropertyValue(PropertyNames.ONE_CIRCLE_JOB_COUNT.name());			
			String jobTimeout = util.getPropertyValue(PropertyNames.CLIENT_JOB_TIME_OUT.name());
			String oneByOne = util.getPropertyValue(PropertyNames.ONE_BY_ONE.name());
			String prioryJobInfo = util.getPropertyValue(PropertyNames.PRIORITY_JOB.name());
			String searchJobCancelInfo = util.getPropertyValue(PropertyNames.SEARCH_JOB_CANCEL_INFO.name());
			String extractionJobCancelInfo = util.getPropertyValue(PropertyNames.EXTRACTION_JOB_CANCEL_INFO.name());
			String verifyJobCancelInfo = util.getPropertyValue(PropertyNames.VERIFY_JOB_CANCEL_INFO.name());
			String muitSyncCout = util.getPropertyValue(PropertyNames.MUILT_SYNC_COUNT.name());


			if (circleThreadCurrentCount == null || circleThreadCurrentCount.isEmpty()) {
				circleThreadCurrentCount = "5";
			}
			
			if (oneCircleJobCount == null || oneCircleJobCount.isEmpty()) {
				oneCircleJobCount = "100";
			}
			
			if (jobTimeout == null || jobTimeout.isEmpty()) {
				jobTimeout = "5000";
			}			
			String wsdlUrl = "http://" + serverId + ":" + serverPort;
			wsdlUrl = wsdlUrl.endsWith("/") ? wsdlUrl : wsdlUrl + "/";
			wsdlUrl = wsdlUrl + MEGHA_CONTEXT_NAME + XM_SERVICE_NAME + MEGHA_WSDL_PATTEN;
			
			String server2Id = null;
			String server2Port = null;
			String wsdlUrl2 = null;
			if (serverIds.split(",").length >=2 && serverPorts.split(",").length >= 2 && serverIds.split(",").length == serverPorts.split(",").length) {
				server2Id = serverIds.split(",")[1];
				server2Port = serverPorts.split(",")[1];
				wsdlUrl2 = "http://" + server2Id + ":" + server2Port;
				wsdlUrl2 = wsdlUrl2.endsWith("/") ? wsdlUrl2 : wsdlUrl2 + "/";
				wsdlUrl2 = wsdlUrl2 + MEGHA_CONTEXT_NAME + XM_SERVICE_NAME + MEGHA_WSDL_PATTEN;

			}	
		
			keyValueMap.putIfAbsent(WSDL_URL, wsdlUrl);
			keyValueMap.putIfAbsent(SERVER_ID, serverId);
			keyValueMap.putIfAbsent(SERVER_PORT, serverPort);
			keyValueMap.putIfAbsent(CIRCLE_THREAD_CURRENET_COUNT, circleThreadCurrentCount);
			keyValueMap.putIfAbsent(ONE_CIRCLE_JOB_COUNT, oneCircleJobCount);
			keyValueMap.putIfAbsent(SEARCH_JOB_TIMEOUT, jobTimeout);
			keyValueMap.putIfAbsent(CLIENT_CALLBACK_PORT, callbackPort);
			keyValueMap.putIfAbsent(CLIENT_CALLBACK_IP, callbackIp);
			keyValueMap.putIfAbsent(ONE_BY_ONE, oneByOne);
			keyValueMap.putIfAbsent(PRIORITY_JOB, prioryJobInfo);
			keyValueMap.putIfAbsent(SEARCH_JOB_CANCEL_INFO, searchJobCancelInfo);
			keyValueMap.putIfAbsent(EXTRACTION_JOB_CANCEL_INFO, extractionJobCancelInfo);
			keyValueMap.putIfAbsent(VERIFY_JOB_CANCEL_INFO, verifyJobCancelInfo);
			keyValueMap.putIfAbsent(MUILT_SYNC_JOB_INFO, muitSyncCout);
			if (server2Id != null && server2Port!= null && wsdlUrl2 != null) {
				keyValueMap.putIfAbsent(SERVER2_ID, server2Id);
				keyValueMap.putIfAbsent(SERVER2_PORT, server2Port);
				keyValueMap.putIfAbsent(WSDL_URL2, wsdlUrl2);
			}
			return true;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return false;
		}
	}

	public void shutdown() {		
		clientExecutor.shutdown();
		callbacExecutor.shutdown();
		keyValueMap.clear();
	}
}
