package com.nec.aim.uid.client.main;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UidClientMain {
	private static Logger logger = LoggerFactory.getLogger(UidClientMain.class);
	private static final String START = "start";
	private static final String STOP = "stop";
	

}
