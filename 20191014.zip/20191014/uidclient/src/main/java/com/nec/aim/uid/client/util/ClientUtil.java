package com.nec.aim.uid.client.util;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;

public class ClientUtil {
	private static final ClientUtil INSTANCE = new ClientUtil();
	private static Logger logger = LoggerFactory.getLogger(ClientUtil.class);

	public static ClientUtil getInstance() {
		return INSTANCE;
	}

	private static final String IPADDRESS_PATTERN =
			"^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\."
			+ "([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\."
			+ "([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\."
			+ "([01]?\\d\\d?|2[0-4]\\d|25[0-5])$";

	public ClientUtil() {
	}

	public boolean checkIP(String ip) {
		Pattern pattern = Pattern.compile(IPADDRESS_PATTERN);
		Matcher matcher = pattern.matcher(ip);
		return matcher.matches();
	}
	
	public String formatXml(String strXml) {
		InputStream in = null;
		StringWriter sw = null;
		try {
			in = new ByteArrayInputStream(strXml.getBytes("UTF-8"));
			sw = new StringWriter();
	    	DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	    	DocumentBuilder builder = factory.newDocumentBuilder();
	    	Document doc = builder.parse(in);
	    	doc.setXmlStandalone(true);  
	    	Transformer tf = TransformerFactory.newInstance().newTransformer();
	    	tf.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
	    	tf.setOutputProperty(OutputKeys.METHOD, "xml");
	    	tf.setOutputProperty(OutputKeys.INDENT, "yes");
	    	tf.setOutputProperty(OutputKeys.STANDALONE, "yes");
	    	tf.setOutputProperty("{http://xml.apache.org/xslt}indent-amount","4");	    	
	    	tf.transform(new DOMSource(doc), new StreamResult(sw));	
		} catch (Exception  e) {
		}
		return sw.toString();
	}
	
	public byte[] getTemplateData(String requestFullPath) {		
		if (requestFullPath == null || requestFullPath.isEmpty()) {
			logger.error("The template data file is not found!");
			return null;
		}	
		File templateFile = new File(requestFullPath);
		if (!templateFile.exists() || !templateFile.isFile()) {
			logger.error("The template file is wrong. skip process...");
			return null;
		}		
		
		FileInputStream input = null;	
		byte[] temp = null;
		try {
			input = new FileInputStream(requestFullPath);
			temp = new byte[input.available()];
			input.read(temp);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		} finally {			
			try {
				input.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return temp;
	}
}
