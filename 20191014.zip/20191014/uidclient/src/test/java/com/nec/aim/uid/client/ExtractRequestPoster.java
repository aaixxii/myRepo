package com.nec.aim.uid.client;

import static org.junit.Assert.*;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;

import org.json.JSONObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.googlecode.protobuf.format.HtmlFormat;
import com.googlecode.protobuf.format.JsonFormat;
import com.googlecode.protobuf.format.XmlFormat;
import com.nec.aim.uid.client.util.ProtobufCreater;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import jp.co.nec.aim.message.proto.BusinessMessage.E_REQUESET_TYPE;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.ExtractService.ExtractRequest;
import jp.co.nec.aim.message.proto.ExtractService.ExtractResponse;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyResponse;
import jp.co.nec.aim.message.proto.SyncService.SyncRequest;

public class ExtractRequestPoster {
	  private static final MediaType MEDIA_TYPE_PLAINTEXT = MediaType.parse("text/plain; charset=utf-8");
	   
		private ProtobufCreater protobufCreater = new ProtobufCreater();

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() throws IOException {
		ExtractRequest extReq = protobufCreater.createExtractRequest();
		
		Gson gson = new Gson();
		String jsonObject = gson.toJson(extReq.toBuilder());
		System.out.println(jsonObject);
		Gson gson2 = new GsonBuilder().setPrettyPrinting().create();
		String prettyJson = gson2.toJson(extReq.toBuilder());
		System.out.println(prettyJson);
		//FileOutputStream outputStream = new FileOutputStream("C:/Users/xia/Desktop/test/protobof.dat");
		//extReq.writeTo(outputStream);
		//ExtractRequest extReq2 = ExtractRequest.parseFrom(new FileInputStream("C:/Users/xia/Desktop/test/protobof.dat"));
       
		
//		OkHttpClient client = new OkHttpClient();
//		  Request request = new Request.Builder()
//			      .url("http://localhost:8080/matchmanager/AIMExtractService/extract")
//			      .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, extReq.toByteArray()))
//			      .build();
//		  try {
//			Response response = client.newCall(request).execute();			
//			ExtractResponse extRes = ExtractResponse.parseFrom(response.body().bytes());
//			 PBBusinessMessage psMsg = PBBusinessMessage.parseFrom(extRes.getBusinessMessage(0));
////			System.out.print(extRes.toString());
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	}
	
	@Test
	public void testSync() {
		SyncRequest syncReq = protobufCreater.createInsertRequest(E_REQUESET_TYPE.INSERT_REFID_DEFAULT);
	
	}
	
	@Test
	public void testGson() {
		IdentifyResponse iqyRes = protobufCreater.createIdentifyResponse();
		Gson gson2 = new GsonBuilder().setPrettyPrinting().create();
		String prettyJson = gson2.toJson(iqyRes.toBuilder());
		System.out.println(prettyJson);
		try (FileWriter writer = new FileWriter("C:/Users/xia/Desktop/test/result.json")) {
			gson2.toJson(iqyRes.toBuilder(), writer);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void testProtobufFromat() throws IOException {
 		PBBusinessMessage pbmsg = protobufCreater.createPBBusinessMessage();
		JsonFormat jsonFormat = new JsonFormat();
		String asJson = jsonFormat.printToString(pbmsg); 
		//System.out.print(asJson);
		InputStream in = new ByteArrayInputStream(asJson.getBytes("UTF-8"));
		PBBusinessMessage.Builder newPbMsg = PBBusinessMessage.newBuilder();
		jsonFormat.merge(in, newPbMsg);
		
		FileOutputStream outputStream = new FileOutputStream("C:/Users/xia/Desktop/test/data.json");
		//pbmsg.writeTo(outputStream);
		jsonFormat.print(pbmsg, outputStream);
		outputStream.close();
		
		try (FileWriter file = new FileWriter("C:/Users/xia/Desktop/test/xia.json")) {
			file.write(asJson );
			
		}	
		JSONObject jsono = new JSONObject(asJson);
		try (FileWriter file = new FileWriter("C:/Users/xia/Desktop/test/xia3.json")) {
			jsono.write(file);
			
		}	
	
		
		
//		Gson gson2 = new GsonBuilder().setPrettyPrinting().create();
//		String prettyJson = gson2.toJson(pbmsg.toBuilder());
//		System.out.print(prettyJson);
//		try (FileWriter file = new FileWriter("C:/Users/xia/Desktop/test/xia_format.json")) {
//			file.write(prettyJson);			
//		}

		
//		System.out.print(newPbMsg.toString());
//		XmlFormat xmlFormat = new XmlFormat();
//		String asXml = xmlFormat.printToString(pbmsg);
//		System.out.print(asXml);
//		PBBusinessMessage.Builder xmlPbMsg = PBBusinessMessage.newBuilder();
//		StringReader xmlIn = new StringReader(asXml);
//		char[] buffer = new char[asXml.length()];
//		 xmlIn.read(buffer);
//		InputStream xmInput = new ByteArrayInputStream(new String(buffer).getBytes("UTF-8"));
//		xmlFormat.merge(xmInput, xmlPbMsg);
//		System.out.print(xmlPbMsg.toString());
//		HtmlFormat htmlFormat = new HtmlFormat();
//		String asHtml = htmlFormat.printToString(pbmsg);
//		System.out.print(asHtml);
	}
}
