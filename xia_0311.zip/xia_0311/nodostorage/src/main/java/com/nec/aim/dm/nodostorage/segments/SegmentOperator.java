package com.nec.aim.dm.nodostorage.segments;
import static com.nec.aim.dm.nodostorage.segments.DmConstants.SEGMENT_HEADER_SIZE;
import static com.nec.aim.dm.nodostorage.segments.DmConstants.SIZE_CHECKSUM;
import static com.nec.aim.dm.nodostorage.segments.DmConstants.SIZE_DELETE_FLAG;
import static com.nec.aim.dm.nodostorage.segments.DmConstants.SIZE_EVENT_ID;
import static com.nec.aim.dm.nodostorage.segments.DmConstants.SIZE_EXTERNAL_ID;
import static com.nec.aim.dm.nodostorage.segments.DmConstants.SIZE_TEMPLATE_HEADER;
import static com.nec.aim.dm.nodostorage.segments.DmConstants.SIZE_TSZ;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.util.Objects;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.locks.Lock;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.InvalidProtocolBufferException;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;

public class SegmentOperator {
	
	private static final Logger logger = LoggerFactory.getLogger(SegmentOperator.class);
	private static final int AIM_VERSION = 2;
	private static final short FORMAT_ID = 1;
	private static final long MAX_SEGMENT_SIZE = 20000000;
	private static final Object locker  = new Object();
	
	private static SegmentOperator INSTANCE = new SegmentOperator();
	private String rootPath;
	private long segId;
	private  File myFile;
	
	public SegmentOperator() {
		
	}
	
	public static SegmentOperator getInstance() {
		return INSTANCE;
	}
	
	public void init(long segId, String rootDir) {
		this.segId = segId;
		this.rootPath = rootDir;
		String fullPath = this.rootPath.endsWith("/") ? rootPath + String.valueOf(segId) : rootPath + "/" + String.valueOf(segId);
		this.myFile = new File(fullPath);
	}
	
	public Boolean processRequest(PBDmSyncRequest dmSegReq, SegmentInfo segInfo, SegmentUpdateType updateType)
			throws InvalidProtocolBufferException, InterruptedException, ExecutionException {		
		String changeType = dmSegReq.getCmd().name().toUpperCase();
		long bioId = dmSegReq.getBioId();
		PBTemplateInfo templateInfo = dmSegReq.getTemplateData();
			String externalId = null;
  			byte[] templateData = null;
  			if (templateInfo.hasReferenceId()) {
  				externalId = templateInfo.getReferenceId();
  			}
  			if (templateInfo.hasData()) {
  				templateData = templateInfo.getData().toByteArray();
  			} 
		long segId = dmSegReq.getTargetSegments().getId();
		long segVer = dmSegReq.getTargetSegments().getVersion();
		if (Objects.isNull(templateData) || templateData.length < 0) {
			logger.warn("Received empty template data!!");
			return false;
		}
		boolean resulst = false;		
		if (updateType == SegmentUpdateType.NEW && changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT.name())) {
			resulst =  newSegment(templateData, bioId, externalId, segVer);						
		} else if (updateType == SegmentUpdateType.UPDATE && changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT.name())) {			
			resulst = updateSegment(segInfo, templateData, bioId, externalId, segVer);			
		} else if (updateType == SegmentUpdateType.DELETE && changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE.name())) {
			if (Objects.isNull(segInfo)) {
				logger.warn("can't found segment data for sementId={}", segId);
				resulst = false;
			} else {
				try {
					resulst = deleteTemplate(segInfo, bioId, externalId);					
				} catch (IOException e) {
					logger.error(e.getMessage(), e);
					resulst = false;
				}
			}
		}
		return Boolean.valueOf(resulst);
	}	


	private Boolean newSegment(byte[] data, long bioId, String extId, long segVer) throws InterruptedException, ExecutionException {
		Callable<Boolean> newSegmentTask = () -> {
			int tSize = SEGMENT_HEADER_SIZE + SIZE_TEMPLATE_HEADER + SIZE_CHECKSUM + data.length;
			System.out.print(tSize);
			ByteBuffer segBuffer = ByteBuffer.allocate(tSize);
			SegmentInfo newSegInfo = new SegmentInfo(segId);
			if (myFile.exists()) {
				logger.warn("There are some wrong, the file:{} is exist!", segId);
				//return false;
			}
			FileOutputStream outputStream = null;				
			synchronized (locker) {
				try {
					outputStream = new FileOutputStream(myFile);				
					segBuffer.position(0);
					segBuffer.putInt(AIM_VERSION);
					segBuffer.putShort(FORMAT_ID);
					segBuffer.putLong(MAX_SEGMENT_SIZE);
					segBuffer.putInt(1);
					segBuffer.putLong(segVer);
					byte[] templateWithHeader = TemplateHeaderHelper.prependHeader(bioId, data, extId, 1);
					int temSize = templateWithHeader.length;
					System.out.print(temSize);
					segBuffer.put(templateWithHeader);
					outputStream.write(segBuffer.array());
					outputStream.flush();
					logger.info("Success saved tempate data to segment file, segmentId={}", segId);
					newSegInfo.setRecordcount(1);
					SegmentManager.saveToQueue(Long.valueOf(segId), newSegInfo);				
				} catch (Exception e) {
					logger.error(e.getMessage(), e);
					myFile.delete();
					return Boolean.valueOf(false);
				} finally {						
					if (outputStream != null) {
						outputStream.close();
					}									
					segBuffer.clear();
					segBuffer = null;
				}				
			}
			return Boolean.valueOf(true);			
		};
		return SegmentManager.submit(newSegmentTask);
	}


	private Boolean updateSegment(SegmentInfo segInfo, byte[] data, long bioId, String extId, long segVer)
			throws InterruptedException, ExecutionException {
		Callable<Boolean> updateSegmentTask = () -> {
			if (!myFile.exists()) {
				logger.warn("There are some wrong, the file:{} is not exist!", segId);				
			}
			FileOutputStream outputStream = null;
			//int templateSize = SIZE_TEMPLATE_HEADER + SIZE_CHECKSUM + data.length;
			synchronized (locker) {
				try {
					byte[] templateWithHeader = TemplateHeaderHelper.prependHeader(bioId, data, extId, 1);					
					outputStream = new FileOutputStream(myFile, true);	
					outputStream.write(templateWithHeader);
					outputStream.flush();
					segInfo.setRecordcount(segInfo.getRecordcount() + 1);
					logger.info("Success upate tempate data to segment file, segmentId={}", segId);		
				} catch (Exception e) {
					logger.error(e.getMessage(), e);
					return false;
				} finally {	
					if (outputStream != null) {
						outputStream.close();
					}
				}				
			}
			return true;
		};
		return SegmentManager.submit(updateSegmentTask);
	}

	private Boolean deleteTemplate(SegmentInfo segInfo, long bioId, String extId)
			throws InterruptedException, ExecutionException, IOException {
		Callable<Boolean> delTemplateTask = () -> {
			long segId = segInfo.getSegId();
			if (!myFile.exists()) {
				logger.warn("There are some wrong, the file:{} is not exist!", segId);
				return false;
			}
			RandomAccessFile randomFile = null;
			boolean deleted = false;
			Lock locker = segInfo.getLocker().writeLock();
			try {
				randomFile = new RandomAccessFile(myFile, "rw");
				byte b = 1;
				byte[] delFlag = new byte[] { b };				
				int firstSeekPositon = SEGMENT_HEADER_SIZE + SIZE_CHECKSUM;
				randomFile.seek(firstSeekPositon);
				long prePostion = randomFile.getFilePointer();
				long nextPosition = -1;
				boolean finish = false;				
				while (!finish) {
					nextPosition = prePostion + SIZE_TSZ;
					randomFile.seek(nextPosition);
					long templateId = randomFile.readLong();
					if (templateId == bioId) {
						randomFile.write(delFlag);
						deleted = true;
						finish = true;
						break;
					}
					nextPosition = nextPosition + SIZE_DELETE_FLAG + SIZE_EXTERNAL_ID + SIZE_EVENT_ID;
					prePostion = nextPosition;
				}
				if (!finish) {
					logger.info("Can't found templateId({}) in this segment({})", bioId, segId);
					deleted = false;
				}				
			} catch (Exception e) {
				deleted = false;
				logger.error(e.getMessage(), e);
			} finally {
				locker.unlock();
				randomFile.close();
			}
			return  Boolean.valueOf(deleted);
		};
		return SegmentManager.submit(delTemplateTask);
	}
	
	public boolean isFileExists(long segmentId) {
		if (this.segId == segmentId &&  this.myFile != null && myFile.exists()) {
			return true;
		} else {
			return false;
		}			
	}	
}
