package com.nec.aim.dm.nodostorage.repository;

import java.sql.SQLException;

public interface DmConfigRepository {
	
	public int getRedundancy() throws SQLException;
	public int getMaxSegmentSize() throws SQLException;

}
