package com.nec.aim.dm.nodostorage.segments;

import javax.annotation.PostConstruct;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import lombok.extern.slf4j.Slf4j;

@Service
public class SegmentOperationHandler {
	

	
	

	@PostConstruct
	public void init() {
	}	

	public boolean handerRequest(PBDmSyncRequest dmSegRequest) throws Exception {
		PBDmSyncRequest dmSegReq = PBDmSyncRequest.parseFrom(dmSegRequest.toByteString());		
		long segId = dmSegReq.getTargetSegments().getId();	
		boolean result = false;
	
		return result;
		
	}
}




