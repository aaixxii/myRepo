package com.nec.aim.dm.nodostorage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NodostorageApplication {

	public static void main(String[] args) {
		SpringApplication.run(NodostorageApplication.class, args);
	}

}
