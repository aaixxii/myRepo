package com.nec.aim.dm.nodostorage.segments;

public enum SegmentUpdateType {
	NEW, UPDATE, DELETE, COMPACTION, RE_CREATE;
}
