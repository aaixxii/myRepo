package com.nec.aim.dm.nodostorage.segments;

import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SegmentManager {
	
	private static ExecutorService dmJobExecutor = Executors.newCachedThreadPool(); 
	private static final ConcurrentHashMap<Long, SegmentInfo> segmentsQueue = new ConcurrentHashMap<>();
	
	public static void saveToQueue (Long segId, SegmentInfo segInfo)  {
		segmentsQueue.putIfAbsent(segId, segInfo);
		log.info("success saved to queue");	
		}
	
	public static void updateToQueue (Long segId, SegmentInfo segInfo)  {
		segmentsQueue.remove(segId);
		segmentsQueue.put(segId, segInfo);
		log.info("success update to queue");	
		}
	
	public static SegmentInfo getSegmentInfo(Long segId) {
		return segmentsQueue.get(segId);		
	}
	
	public static Boolean sumitDmJob(Callable<Boolean> task) {
		Future<Boolean> future = dmJobExecutor.submit(task);
		try {
			return future.get();
		} catch (InterruptedException | ExecutionException e) {
			log.error(e.getMessage(), e);
			return Boolean.FALSE;
		}
	}
	
	public static <T> CompletableFuture<T> callableAsync(Callable<T> c) {
		CompletableFuture<T> cf = new CompletableFuture<>();
		dmJobExecutor.execute(() -> {
			try {
				cf.complete(c.call());

			} catch (Throwable ex) {
				cf.completeExceptionally(ex);
			}
		});
		return cf;
	}
	
	public static Boolean submit(Callable<Boolean> c) throws InterruptedException, ExecutionException {
		CompletableFuture<Boolean> cf = new CompletableFuture<>();
		dmJobExecutor.execute(() -> {
			try {
				cf.complete(c.call());
			} catch (Throwable ex) {
				cf.completeExceptionally(ex);
			}
		});
		return cf.get();
	}

}
