package com.nec.aim.dm.nodostorage.segments;
import java.io.File;

public class FileUtil {
	
	public static boolean isFileExist(String path) {
		File file = new File(path);
		return file.exists();		
	}	

}
