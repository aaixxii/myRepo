package jp.co.nec.aim.mm.acceptor.service;

import java.io.IOException;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractIrisOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractOutputPayload;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractTenprintOutput;
import jp.co.nec.aim.message.proto.ExtractService.ExtractRequest;
import jp.co.nec.aim.mm.exception.ArgumentException;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.util.Deflater;
import jp.co.nec.aim.mm.util.ProtobufCreater;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()
@Transactional
public class AimExtractServiceTest extends
		AbstractTransactionalJUnit4SpringContextTests {
	@Resource
	private DataSource dataSource;
	@Resource
	private AimExtractService aimExtractService;
	@Resource
	private JdbcTemplate jdbcTemplate;

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;
	
	private ProtobufCreater protobufCreater;

	@Before
	public void setUp() {
		jdbcTemplate.update("delete from FE_JOB_QUEUE");
		jdbcTemplate.update("delete from FE_JOB_PAYLOADS");
		jdbcTemplate.update("delete from FE_RESULTS");
		jdbcTemplate.execute("commit");
		setMockMethod();
		protobufCreater = new ProtobufCreater();
	}

	@After
	public void tearDown() {
		jdbcTemplate.update("delete from FE_JOB_QUEUE");
		jdbcTemplate.update("delete from FE_JOB_PAYLOADS");
		jdbcTemplate.update("delete from FE_RESULTS");
		jdbcTemplate.execute("commit");		
	}

	private void setMockMethod() {
		new MockUp<JmsSender>() {
			@Mock
			private void convertAndSend(String queueName, Object object) {
				return;
			}
		};
	}
	
	@Test
	public void testExtract() {
		ExtractRequest exq = protobufCreater.createExtractRequest();
		Long jobId = aimExtractService.extract(exq, true);
		Assert.assertNotNull(jobId);		
	}
	
	
	public void testExtract_protobuf_err() {
		ExtractRequest exq = protobufCreater.createExtractRequestHaveErr();
		try {
			Long jobId = aimExtractService.extract(exq, true);
			Assert.assertNotNull(jobId);
		} catch (Exception e) {			
		}
		
				
	}

	public byte[] createCompuressedExtractPayload() throws IOException {
		PBExtractOutputPayload.Builder payload = PBExtractOutputPayload
				.newBuilder();
		payload.setTenprintOutput(PBExtractTenprintOutput.newBuilder())
				.setIrisOutput(PBExtractIrisOutput.newBuilder());
		byte[] bytePayload = payload.build().toByteArray();
		byte[] compressBytes = Deflater.compress(bytePayload);
		return compressBytes;
	}

}
