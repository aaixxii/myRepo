package jp.co.nec.aim.license.local;

public class LicenseState {
	private static LicenseState licenseState = new LicenseState();
	private LicenseRights lr = null;

	private LicenseState() {
	}

	public static LicenseState getInstance()
	{
		return licenseState;
	}
	
	public synchronized void setLicenseRights(LicenseRights lr) {
		this.lr = lr;
	}

	public synchronized LicenseRights getLicenseRights() {
		return lr;
	}

}
