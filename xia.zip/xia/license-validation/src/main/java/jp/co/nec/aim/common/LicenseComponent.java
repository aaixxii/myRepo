package jp.co.nec.aim.common;

public enum LicenseComponent {
	MM, VM
}
