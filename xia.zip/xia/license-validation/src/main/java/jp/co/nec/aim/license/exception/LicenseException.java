package jp.co.nec.aim.license.exception;

public class LicenseException extends RuntimeException {
	
	private static final long serialVersionUID = 3194924856583553665L;
	public LicenseException() {
	}

	public LicenseException(String detail) {
		super(detail);
	}

	public LicenseException(Throwable ex) {
		super(ex);
	}

	public LicenseException(String detail, Throwable ex) {
		super(detail, ex);
	}

}
