package jp.co.nec.aim.license.local;

/**
 * @author Erik Vandekieft
 */
public enum LicenseRightsType {
	TRIAL, FULL
}
