package jp.co.nec.aim.common;

public enum LicenseVerifyType {
	FLOATING, LOCAL;
}
