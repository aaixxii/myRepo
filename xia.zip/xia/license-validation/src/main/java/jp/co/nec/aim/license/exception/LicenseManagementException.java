package jp.co.nec.aim.license.exception;

import java.security.GeneralSecurityException;

public class LicenseManagementException extends GeneralSecurityException {
	private static final long serialVersionUID = 7537296642097794077L;

	public LicenseManagementException()
	{
	}

	public LicenseManagementException(String msg)
	{
		super(msg);
	}

	public LicenseManagementException(Throwable cause)
	{
		super(cause);
	}

	public LicenseManagementException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
