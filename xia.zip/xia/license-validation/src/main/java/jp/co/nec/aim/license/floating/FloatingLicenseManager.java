package jp.co.nec.aim.license.floating;


import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.commons.lang3.StringUtils;
import org.quartz.SchedulerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xformation.lmx.Lmx;
import com.xformation.lmx.LmxException;
import com.xformation.lmx.LmxFeatureInfo;
import com.xformation.lmx.LmxSettings;

import jp.co.nec.aim.clientapi.afis.AfisLowLevelFunctionEnum;
import jp.co.nec.aim.common.LicenseComponent;
import jp.co.nec.aim.common.ModalityType;
import jp.co.nec.aim.license.CronScheduler;
import jp.co.nec.aim.license.LmxTask;
import jp.co.nec.aim.license.exception.LicenseException;

/*
 * FloatingLicenseManager:
 * 1. get license info from license server and save it to map.<br/>
 * 2. validate license while inquiry job is coming using license info in map.<br/>
 * 
 * @author xiazp
 */
public class FloatingLicenseManager {
	private final ConcurrentHashMap<String, String> licenseMap = new ConcurrentHashMap<>();
	private static Logger logger = LoggerFactory.getLogger(FloatingLicenseManager.class);

	private static final String COMMA = ",";
	private static final String FEATURE_KEY = "afis";
	private static final String SEMICOLON = ";";
	private static final String EQUAL = "=";
	
	private static final List<String> COMPONENT_LIST = Arrays.asList("MM", "VM");

	private static final String LICENSE_MODALITY = "FINGER,FACE,PALM,IRIS";

	private static final String KEY_LICENSE_TYPE = "TYPE";
	private static final String KEY_COMPONENT = "COMPONENT";
	private static final String KEY_MODALITY = "MODALITY";
	
	private final int VER_MAJOR = 1;
	private final int VER_MINOR = 0;
	private final int LMX_OPTION = 1;
	
	private static final long INTERVAL_ONE_DAY = 86400000;
	
	private static boolean isInitialized = false;

	private ReentrantLock managerLocker;

	private static final Lmx MM_LMX = new Lmx();
	
	private static final ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor();
	
	private CronScheduler cronScheduler;
	

	private FloatingLicenseManager() {
		managerLocker = new ReentrantLock();
	}

	public Lmx getLmx() {
		return MM_LMX;
	}	

	public void initLmx(String floatingSeverInfo) throws LmxException, SchedulerException {			
		managerLocker.lock();
		try {
			if (!isInitialized) {
				logger.info("Floating license manager init...");
				logger.debug(floatingSeverInfo);			
				MM_LMX.init();
				MM_LMX.setOption(LmxSettings.LMX_OPT_AUTOMATIC_HEARTBEAT_ATTEMPTS, -1);
				MM_LMX.setOption(LmxSettings.LMX_OPT_AUTOMATIC_HEARTBEAT_INTERVAL, 30);	
				MM_LMX.setOption(LmxSettings.LMX_OPT_LICENSE_PATH, floatingSeverInfo);
				FloatLicenseHandler.getInstance().initHeatbeatHandler(MM_LMX);	
				cronScheduler = new CronScheduler();
				cronScheduler.startLmxDailyJob();
				executor.scheduleAtFixedRate(new LmxTask(), 0, INTERVAL_ONE_DAY, TimeUnit.MILLISECONDS);				
				isInitialized = true;
			}			
		} finally {
			managerLocker.unlock();			
		}	
	}

	public void clearLicenseInfoMap() {
		licenseMap.clear();
	}

	private static final FloatingLicenseManager INSTANCE = new FloatingLicenseManager();

	public static FloatingLicenseManager getInstance() {
		return INSTANCE;
	}

	/*
	 * @param functionName the function name
	 * 
	 * @param now the current time
	 * 
	 * @throws LicenseException,LmxException
	 */
	public void checkFeature(String functionName, LicenseComponent component, Date now) throws LicenseException {
		logger.info("Floating license manager check feature at {}", now);
		AfisLowLevelFunctionEnum functionEnum = AfisLowLevelFunctionEnum.valueOf(functionName);
		String modality = functionEnum.getName();
		if (StringUtils.isBlank(modality)) {
			throw new LicenseException("Modality in not found.");
		}
		managerLocker.lock();
		try {
			if (licenseMap.isEmpty()) {
				checkOutFromServer();
			}
			checkLicense(modality, component);
		} finally {
			managerLocker.unlock();
		}
	}

	/*
	 * @param now the current time
	 * 
	 * @throws LicenseException
	 */
	public void checkOutFromServer() throws LicenseException {		
		LmxFeatureInfo feature = null;
		try {
			MM_LMX.checkout(FEATURE_KEY, this.VER_MAJOR, this.VER_MINOR, this.LMX_OPTION);
			feature = MM_LMX.getFeatureInfo(FEATURE_KEY);		
			saveFeatureToMap(feature);		
		} catch (Exception e) {
			logger.error("Error messge is:" + e.getMessage(), e);				
		}
		if (feature == null) {
			String errMsg = String.format(
					"FLoating license server error occurred, Error message:can't get %s from license server", feature);
			throw new LicenseException(errMsg);
		}
	}

	/*
	 * @param LmxFeatureInfo the lmx feature
	 * 
	 * @param now the current time
	 * 
	 * @throws LicenseException,LmxException
	 */
	private void saveFeatureToMap(LmxFeatureInfo feature)
			throws LicenseException {

		String licenseInfo = feature.getOptions();
		if (StringUtils.isBlank(licenseInfo)) {
			String errMsg = String.format("FLoating license server error occurred, can't found license info from %s.",
					feature);
			throw new LicenseException(errMsg);
		}	

		String[] temp = licenseInfo.split(SEMICOLON);
		for (String one : temp) {
			String[] oneArr = one.split(EQUAL);
			if (oneArr.length != 2) {
				String errMsg = "license file formart error";
				throw new LicenseException(errMsg);
			}
			switch (oneArr[0]) {
			case "TYPE":
				licenseMap.putIfAbsent(KEY_LICENSE_TYPE, oneArr[1]);
				break;
			case "COMPONENT":
				licenseMap.putIfAbsent(KEY_COMPONENT, oneArr[1]);
				break;
			case "MODALTY":
				licenseMap.putIfAbsent(KEY_MODALITY, oneArr[1]);
				break;
			default:
			}			
		}
	}

	/*
	 * @param modality modality data, such as FINGER,FACE,PALM,IRIS etc.
	 * 
	 * @param now the current time
	 */
	private void checkLicense(String modality, LicenseComponent component) {
		
		if (StringUtils.isBlank(licenseMap.get(KEY_COMPONENT))) {
			String errMsg = String.format("Floating license validate %s has a error, Error message: %s is not set",
					"component", "component");
			throw new LicenseException(errMsg);
		}

		if (!COMPONENT_LIST.contains(component.name()) ) {
			String errMsg = String.format(
					"Floating license validate %s has a error, Error message: %s is not equal MM.", "component",
					"component");
			throw new LicenseException(errMsg);
		}

		String licenseType = licenseMap.get(KEY_LICENSE_TYPE);
		if (StringUtils.isBlank(licenseType)) {
			String errMsg = String.format("Floating license validate %s has a error, Error message: %s is not set",
					"license type", "license type");
			throw new LicenseException(errMsg);
		}	

		if (licenseType.equals(ModalityType.FULL.name())) {
			String[] modalityArr = licenseMap.get(KEY_MODALITY).split(COMMA);
			for (String one : modalityArr) {
				if (!LICENSE_MODALITY.toUpperCase().contains(one.toUpperCase())) {
					String errMsg = String.format(
							"Floating license validate %s has a error, Error message: %s is not available.",
							"license modality", one);
					throw new LicenseException(errMsg);
				}
			}
		}		
	}

	public void cleanAllLmxResource() {
		managerLocker.lock();
		try {
			executor.shutdown();
			cronScheduler.stopLmxDailyJob();
			licenseMap.clear();
			MM_LMX.checkin(FEATURE_KEY, Lmx.LMX_ALL_LICENSES);
			MM_LMX.free();
		} catch (LmxException e) {
			logger.error(e.getMessage(), e);
		} finally {
			managerLocker.unlock();
		}
	}
	
	public void checkEndDate() {
		managerLocker.lock();
		try {
			licenseMap.clear();
			MM_LMX.checkin(FEATURE_KEY, Lmx.LMX_ALL_LICENSES);	
		} catch (LmxException e) {
			logger.error(e.getMessage(), e);
		} finally {
			managerLocker.unlock();
		}
		
	}

}
