package jp.co.nec.aim.license.local;

/**
 * @author Erik Vandekieft
 */
public class LicenseRights {
	private LicenseRightsType type;
	private String name;
	private String expirationStr;
	private String signature;
	private String version;
	private String functionCsv;
	private String component;

	public LicenseRights(String name, LicenseRightsType type,
			String expirationStr, String signature, String version,
			String functionCsv, String componentCsv) {
		this.type = type;
		this.name = name;
		this.expirationStr = expirationStr;
		this.signature = signature;
		this.version = version;
		this.functionCsv = functionCsv;
		this.component = componentCsv;
	}

	public String getExpiration() {
		return expirationStr;
	}

	public String getName() {
		return name;
	}

	public String getSignature() {
		return signature;
	}

	public LicenseRightsType getType() {
		return type;
	}

	public String getVersion() {
		return version;
	}

	public String getFunctionCsv() {
		return functionCsv;
	}
	
	public String getComponent() {
		return component;
	}

	public void setComponent(String componentCsv) {
		this.component = componentCsv;
	}
}
