package jp.co.nec.aim.license;

import org.quartz.CronScheduleBuilder;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CronScheduler {
	private Scheduler scheduler;
	
	private static Logger logger = LoggerFactory.getLogger(CronScheduler.class);
	
	public void startLmxDailyJob() throws SchedulerException {
		SchedulerFactory schfa = new StdSchedulerFactory();
		scheduler = schfa.getScheduler();
		JobDetail jobdetail = JobBuilder.newJob(LmxJob.class)
				.withIdentity("lmxJob", "group1").build();
		
	   	Trigger trigger = TriggerBuilder
			.newTrigger()
			.withIdentity("lmxTrigger", "group1")
			.withSchedule(
				CronScheduleBuilder.cronSchedule("0 0 12 * * ?"))
			.build();
	   	
	   	scheduler.scheduleJob(jobdetail, trigger);
	   	scheduler.start(); 
	}
	
	public void stopLmxDailyJob() {
		try {
			scheduler.shutdown(true);
		} catch (SchedulerException e) {
			logger.error(e.getMessage(), e);
		}
	}
}


