package jp.co.nec.aim.license.local;

/**
 * @author Erik Vandekieft 
 */
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.SocketException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.spec.DSAPublicKeySpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.SAXException;

import com.google.common.base.Splitter;
import com.google.common.base.Throwables;

import jp.co.nec.aim.clientapi.afis.AfisLowLevelFunctionEnum;
import jp.co.nec.aim.clientapi.afis.FunctionEnum;
import jp.co.nec.aim.common.LicenseComponent;
import jp.co.nec.aim.license.exception.LicenseManagementException;
import jp.co.nec.aim.license.exception.LicenseValidationException;
import jp.co.nec.aim.license.helper.Encryption;
import jp.co.nec.aim.license.helper.HardwareInfo;
import jp.co.nec.aim.license.helper.constants.Key;

public final class LocalLicenseManager {
	private static Logger log = LoggerFactory.getLogger(LocalLicenseManager.class);

	private static LocalLicenseManager licenseManager = new LocalLicenseManager();
	private LicenseRights cachedRights = null;

	private static final BigInteger y = new BigInteger(Key.STRING_Y);
	private static final BigInteger p = new BigInteger(Key.STRING_P);
	private static final BigInteger q = new BigInteger(Key.STRING_Q);
	private static final BigInteger g = new BigInteger(Key.STRING_G);

	//static final String LICENSE_XML = "license" + File.separator + "license.xml";

	public static LocalLicenseManager getInstance() {
		return licenseManager;
	}

	/**
	 * Check license information
	 * 
	 * If instance variable of cacheRights is exist, authentication has been
	 * already valid.<br>
	 * If instance variable of cacheRights isn't exist, authentication will be
	 * 
	 * @param now
	 * @throws LicenseValidationException
	 *             if validated set of rights is inadequate, will throw
	 *             LicenseException
	 */
	// public void validate(String function, Date now, LicenseComponent
	// component)
	public void validate(
		AfisLowLevelFunctionEnum function,
		Date now,
		LicenseComponent component)
		throws LicenseManagementException, LicenseValidationException {
		LicenseRights cachedRights = LicenseState.getInstance().getLicenseRights();
		if (cachedRights == null) {
			throw new LicenseManagementException("no license file or invalid license file.");
		}
		checkRightsDateOnTrial(cachedRights, function.name(), now, component.name());
	}

	/**
	 * 
	 * @param xmlFileName
	 * @return
	 */
	private LicenseRights validateRights(InputStream is)
		throws LicenseManagementException {
		try {
			LicenseRights claimedRights = LicenseXMLUtil.parse(is);

			String claimedUser = claimedRights.getName();
			LicenseRightsType claimedType = claimedRights.getType();
			String expirationDateStr = claimedRights.getExpiration();
			String claimedSignature = claimedRights.getSignature();
			String version = claimedRights.getVersion();
			String functionCsv = claimedRights.getFunctionCsv();
			String component = claimedRights.getComponent();

			log.debug("claimed user: " + claimedUser);
			log.debug("claimed type: " + claimedType);
			log.debug("claimed expiration date: " + expirationDateStr);
			log.debug("claimed signature: " + claimedSignature);
			log.debug("claimed version: " + version);
			log.debug("claimed functionCsv: " + functionCsv);
			log.debug("claimed componentCsv: " + component);

			if (claimedType == LicenseRightsType.TRIAL) {
				Signature dsa = createAndUpdateSignature(claimedUser, claimedType);
				dsa.update(claimedUser.getBytes(Encryption.US_ASCII));
				dsa.update(claimedType.toString().getBytes(Encryption.US_ASCII));
				dsa.update(expirationDateStr.getBytes(Encryption.US_ASCII));
				dsa.update(version.getBytes(Encryption.US_ASCII));
				dsa.update(functionCsv.getBytes(Encryption.US_ASCII));
				dsa.update(component.getBytes(Encryption.US_ASCII));

				byte[] sig = Base64.decodeBase64(claimedSignature.getBytes());
				if (dsa.verify(sig)) {
					return new LicenseRights(claimedRights.getName(), claimedRights
						.getType(), claimedRights.getExpiration(), claimedSignature,
						version, functionCsv, component);
				}
			} else if (claimedType == LicenseRightsType.FULL) {
				List<String> listAddresses = HardwareInfo.getMacAddresses();
				for (String macAddress : listAddresses) {
					Signature dsa = createAndUpdateSignature(claimedUser, claimedType);
					String cpuInfo = HardwareInfo.getLinuxCpuInfo();
					dsa.update(claimedUser.getBytes(Encryption.US_ASCII));
					dsa.update(claimedType.toString().getBytes(Encryption.US_ASCII));
					dsa.update(cpuInfo.getBytes(Encryption.US_ASCII));
					dsa.update(macAddress.getBytes(Encryption.US_ASCII));
					dsa.update(expirationDateStr.getBytes(Encryption.US_ASCII));
					dsa.update(version.getBytes(Encryption.US_ASCII));
					dsa.update(functionCsv.getBytes(Encryption.US_ASCII));
					dsa.update(component.getBytes(Encryption.US_ASCII));

					byte[] sig = Base64.decodeBase64(claimedSignature.getBytes());
					if (dsa.verify(sig)) {
						return new LicenseRights(claimedRights.getName(), claimedRights
							.getType(), claimedRights.getExpiration(), claimedSignature,
							version, functionCsv, component);
					}
				}
			}
		} catch (InvalidKeyException | NoSuchAlgorithmException | SignatureException
			| UnsupportedEncodingException | SocketException | InvalidKeySpecException e) {
			throw new LicenseManagementException(com.google.common.base.Throwables
				.getRootCause(e).getMessage());
		} catch (IOException e) {
			throw new LicenseManagementException(com.google.common.base.Throwables
				.getRootCause(e).getMessage());
		}
		throw new LicenseValidationException(
			"Invalid license: Signature doesn't match inputs.");
	}

	/**
	 * Create signature and update using name and type
	 * 
	 * @param claimedUser
	 * @param claimedType
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws InvalidKeySpecException
	 * @throws InvalidKeyException
	 * @throws SignatureException
	 * @throws UnsupportedEncodingException
	 */
	private Signature createAndUpdateSignature(
		String claimedUser,
		LicenseRightsType claimedType)
		throws NoSuchAlgorithmException, InvalidKeySpecException, InvalidKeyException,
		SignatureException, UnsupportedEncodingException {
		Signature dsa = Signature.getInstance("SHA1withDSA");
		KeyFactory kf = KeyFactory.getInstance("DSA");
		KeySpec spec = new DSAPublicKeySpec(y, p, q, g);
		PublicKey pub = kf.generatePublic(spec);
		dsa.initVerify(pub);
		return dsa;
	}

	/**
	 * Each type(FULL and TRIAL) must be checked expiry date.
	 * 
	 * @param cachedRights
	 * @param functionStr
	 * @param now
	 * @throws LicenseValidationException
	 */
	private void checkRightsDateOnTrial(
		LicenseRights cachedRights,
		String functionStr,
		Date now,
		String componentStr)
		throws LicenseValidationException, LicenseManagementException {
		log.debug("Checking license rights...");

		// if rights is non-null then its signature has already been verified.
		String expirationDateStr = cachedRights.getExpiration();
		try {
			Date expirationDate = LicenseXMLUtil.parseDate2359(expirationDateStr);
			if (now.after(expirationDate)) {
				throw new LicenseValidationException("License for '"
					+ cachedRights.getName() + "' expired on "
					+ LicenseXMLUtil.formatDate(expirationDate) + "; it is now "
					+ LicenseXMLUtil.formatDate(now) + ".");
			}
		} catch (ParseException e) {
			// never come in
			throw new LicenseManagementException(new StringBuffer(
				"Invalid license date '" + expirationDateStr).append("'").append(
				Throwables.getRootCause(e).getMessage()).toString());
		}

		FunctionEnum function =
			AfisLowLevelFunctionEnum.valueOf(functionStr).getFunction();
		Iterable<String> iteFunction =
			Splitter.on(',').split(cachedRights.getFunctionCsv());
		boolean invalidFunction = true;
		for (String validFunction : iteFunction) {
			if (validFunction.equals(function.name())) {
				invalidFunction = false;
			}
		}
		if (invalidFunction) {
			throw new LicenseValidationException("Invalid license function '"
				+ functionStr + "'");
		}

		Iterable<String> iteCOmponent =
			Splitter.on(',').split(cachedRights.getComponent());
		boolean invalidComponent = true;
		for (String component : iteCOmponent) {
			if (component.equals(componentStr)) {
				invalidComponent = false;
			}
		}
		if (invalidComponent) {
			throw new LicenseValidationException(
				"An invalid license: there is an invalid component.");
		}

		log.debug("License rights are OK.");
	}

	/**
	 * 
	 * @param is
	 * @throws LicenseManagementException
	 */
	public synchronized void init(InputStream is)
		throws LicenseManagementException {
		if (cachedRights != null) {
			return;
		}

		if (is == null) {
			throw new LicenseManagementException("There is not the license.xml.");
		}
		
		byte[] license = null;
		try {
			license = IOUtils.toByteArray(is);
		} catch (IOException e) {
			throw new LicenseManagementException(e.getMessage());
		}

		validateXml(new ByteArrayInputStream(license));
		cachedRights = validateRights(new ByteArrayInputStream(license));
		LicenseState.getInstance().setLicenseRights(cachedRights);
	}

	/**
	 * validation license.xml file with schema
	 * 
	 * @param xmlIs
	 * @throws LicenseManagementException
	 */
	private void validateXml(InputStream xmlIs)
		throws LicenseManagementException {
		try {
			SchemaFactory factory =
				SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
			InputStream xsdIs =
				this.getClass().getClassLoader().getResourceAsStream("aim-license.xsd");
			Validator validator =
				factory.newSchema(new StreamSource(xsdIs)).newValidator();
			validator.validate(new StreamSource(xmlIs));
		} catch (SAXException | IOException e) {
			throw new LicenseManagementException(Throwables.getRootCause(e));
		}
	}
}
