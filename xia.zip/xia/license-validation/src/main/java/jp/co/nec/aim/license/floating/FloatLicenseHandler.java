package jp.co.nec.aim.license.floating;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xformation.lmx.Lmx;
import com.xformation.lmx.Lmx.HeartbeatCheckoutFailureCallback;
import com.xformation.lmx.Lmx.HeartbeatConnectionLostCallback;
import com.xformation.lmx.Lmx.HeartbeatRetryFailureCallback;
import com.xformation.lmx.LmxException;
import com.xformation.lmx.LmxStatus;


/*
 * FloatLicenseHandler is called after failed in license server heartbeat.<br/>
 * @author xiazp
 * 
 */
public class FloatLicenseHandler {
	
	private static final String FEATURE_KEY = "afis";
	private static Logger logger = LoggerFactory.getLogger(FloatLicenseHandler.class);
	private static final FloatLicenseHandler INSTANCE = new FloatLicenseHandler();
	private Lmx lmx;

	public static FloatLicenseHandler getInstance() {
		return INSTANCE;
	}

	public void initHeatbeatHandler(Lmx lmx) {
		try {
			lmx.setHeartbeatConnectionLostCallback(handlerConnectionLostConsumer());
			lmx.setHeartbeatRetryFailureCallback(handlerRetryFailureConsumer());
			lmx.setHeartbeatCheckoutFailureCallback(handlerCheckoutFailureConsumer());			
			this.lmx = lmx;
		} catch (LmxException e) {
			e.printStackTrace();
		}
	}

	private HeartbeatCheckoutFailureCallback handlerCheckoutFailureConsumer() {
		return new HeartbeatCheckoutFailureCallback() {
			@Override
			public void accept(String featureName, Integer usedCount, LmxStatus status) {
				logger.warn("HeartbeatCheckoutFailured. featureName:{}, status:{}", featureName, status.name());
				FloatingLicenseManager.getInstance().clearLicenseInfoMap();
			}
		};
	}

	private HeartbeatConnectionLostCallback handlerConnectionLostConsumer() {
		return new HeartbeatConnectionLostCallback() {
			@Override
			public void accept(String host, Integer port, Integer failedHeartbeats) {
				logger.warn("Heartbeat connection is lost. host:{}, port:{}", host, port);
				FloatingLicenseManager.getInstance().clearLicenseInfoMap();
				try {
					lmx.checkin(FEATURE_KEY, 1);
				} catch (LmxException e) {
					logger.error(e.getMessage(), e);
				}
			}
		};
	}

	private HeartbeatRetryFailureCallback handlerRetryFailureConsumer() {
		return new HeartbeatRetryFailureCallback() {
			@Override
			public void accept(String featureName, Integer usedCount) {
				logger.warn("HeartbeatRetryFailure. feature:{}", featureName);
				FloatingLicenseManager.getInstance().clearLicenseInfoMap();	
			}
		};
	}	
}
