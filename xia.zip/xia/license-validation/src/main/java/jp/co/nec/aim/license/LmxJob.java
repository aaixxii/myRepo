package jp.co.nec.aim.license;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import jp.co.nec.aim.license.floating.FloatingLicenseManager;

public class LmxJob implements Job {

	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		FloatingLicenseManager fm = FloatingLicenseManager.getInstance();
		fm.checkEndDate();		
	}
}
