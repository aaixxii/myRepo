package jp.co.nec.aim.license;

import jp.co.nec.aim.license.floating.FloatingLicenseManager;

public class LmxTask implements Runnable {
	@Override
	public void run() {
		FloatingLicenseManager fm = FloatingLicenseManager.getInstance();
		fm.checkEndDate();		
	}
}
