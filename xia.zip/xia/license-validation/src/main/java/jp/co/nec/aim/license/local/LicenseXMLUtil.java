package jp.co.nec.aim.license.local;

import static jp.co.nec.aim.license.helper.constants.LicenseElement.XMLNAME_COMPONENT;
import static jp.co.nec.aim.license.helper.constants.LicenseElement.XMLNAME_EXPIRATION;
import static jp.co.nec.aim.license.helper.constants.LicenseElement.XMLNAME_FUNCTION_CSV;
import static jp.co.nec.aim.license.helper.constants.LicenseElement.XMLNAME_NAME;
import static jp.co.nec.aim.license.helper.constants.LicenseElement.XMLNAME_SIGNATURE;
import static jp.co.nec.aim.license.helper.constants.LicenseElement.XMLNAME_TYPE;
import static jp.co.nec.aim.license.helper.constants.LicenseElement.XMLNAME_VERSION;

import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.google.common.base.Throwables;

import jp.co.nec.aim.license.exception.LicenseManagementException;
import jp.co.nec.aim.license.helper.constants.Version;

/**
 * @author Erik Vandekieft
 */
public class LicenseXMLUtil {
	/**
	 * Format date from string as "MM/yyyy/dd"
	 * 
	 * @param d
	 * @return
	 */
	public static String formatDate(Date d) {
		return DateFormat.getDateInstance(DateFormat.SHORT, Locale.US).format(d);
	}

	private static Date parseDate(String s)
		throws ParseException {
		return DateFormat.getDateInstance(DateFormat.SHORT, Locale.US).parse(s);
	}

	/**
	 * create LicenseRights after parse for check using a local xml file
	 * 
	 * @param is
	 * @return
	 * @throws LicenseManagementException
	 */
	public static LicenseRights parse(InputStream is)
		throws LicenseManagementException {
		try {
			Document document = getDocument(is);
			return parseLicense((Element)document.getDocumentElement());
		} catch (ParserConfigurationException | SAXException | IOException e) {
			throw new LicenseManagementException(Throwables.getRootCause(e).getMessage());
		}
	}

	/**
	 * 
	 * @param licElem
	 * @param version
	 * @return
	 * @throws LicenseManagementException
	 */
	private static LicenseRights parseLicense(Element licElem)
		throws LicenseManagementException {
		String version = licElem.getAttribute(XMLNAME_VERSION);
		if (0 <= Version.Version30.getName().compareTo(version)) {
			throw new LicenseManagementException("An unsupported license version.");
		}

		NodeList list = licElem.getChildNodes();
		Element rightsElem = null;
		for (int i = 0; i < list.getLength(); i++) {
			Node node = list.item(i);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				rightsElem = (Element)node;
				break;
			}
		}
		String nameStr = rightsElem.getAttribute(XMLNAME_NAME);
		String typeStr = rightsElem.getAttribute(XMLNAME_TYPE);
		String expirationStr = rightsElem.getAttribute(XMLNAME_EXPIRATION);
		String signatureStr = rightsElem.getAttribute(XMLNAME_SIGNATURE);
		String functionCsv = rightsElem.getAttribute(XMLNAME_FUNCTION_CSV);
		String component = rightsElem.getAttribute(XMLNAME_COMPONENT);

		try {
			parseDate(expirationStr);
		} catch (ParseException e) {
			throw new LicenseManagementException(
				"An invalid date: could'nt parse expiration.");
		}

		LicenseRightsType type = LicenseRightsType.FULL;
		if (typeStr.equals("TRIAL")) {
			type = LicenseRightsType.TRIAL;
		}

		return new LicenseRights(nameStr, type, expirationStr, signatureStr, version,
			functionCsv, component);
	}

	/**
	 * Get expireDay + 23:59:59.
	 * 
	 * @param s
	 * @return
	 * @throws ParseException
	 */
	public static Date parseDate2359(String s)
		throws ParseException {
		SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss", Locale.US);
		return format.parse(s + " 23:59:59");
	}
	/**
	 * 
	 * @param is
	 * @return
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 */
	private static Document getDocument(InputStream is)
		throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = docFactory.newDocumentBuilder();
		Document document = builder.parse(new InputSource(is));
		return document;
	}

}
