package jp.co.nec.aim.license.exception;

public class LicenseValidationException extends LicenseManagementException {

	private static final long serialVersionUID = 1871260550287222317L;

	public LicenseValidationException() {
		super();
	}

	public LicenseValidationException(String message, Throwable cause) {
		super(message, cause);
	}

	public LicenseValidationException(String msg) {
		super(msg);
	}

	public LicenseValidationException(Throwable cause) {
		super(cause);
	}

	
}
