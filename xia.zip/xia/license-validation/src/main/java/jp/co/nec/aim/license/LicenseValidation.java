package jp.co.nec.aim.license;

import java.io.InputStream;
import java.util.Date;
import java.util.concurrent.locks.ReentrantLock;

import org.quartz.SchedulerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xformation.lmx.LmxException;

import jp.co.nec.aim.clientapi.afis.AfisLowLevelFunctionEnum;
import jp.co.nec.aim.common.LicenseComponent;
import jp.co.nec.aim.common.LicenseVerifyType;
import jp.co.nec.aim.license.exception.LicenseManagementException;
import jp.co.nec.aim.license.exception.LicenseValidationException;
import jp.co.nec.aim.license.floating.FloatingLicenseManager;
import jp.co.nec.aim.license.local.LocalLicenseManager;

public final class LicenseValidation {

	private static Logger logger = LoggerFactory.getLogger(LicenseValidation.class);

	private static final LicenseValidation instance = new LicenseValidation();

	private LicenseVerifyType icenseVerifyType;

	private ReentrantLock locker = new ReentrantLock();

	public static LicenseValidation getInstance() {
		return instance;
	}

	public void setLicenseVerifyType(LicenseVerifyType type) {
		locker.lock();
		try {
			this.icenseVerifyType = type;
		} finally {
			locker.unlock();
		}
	}

	public LicenseVerifyType getLicenseVerifyType() throws LicenseManagementException {
		locker.lock();
		try {
			if (icenseVerifyType == null) {
				throw new LicenseManagementException("LicenseVerifyType is null.");
			}
			return icenseVerifyType;
		} finally {
			locker.unlock();
		}
	}

	public synchronized void init(InputStream licenseFile) throws LicenseManagementException, LmxException {
		LocalLicenseManager.getInstance().init(licenseFile);
		setLicenseVerifyType(LicenseVerifyType.LOCAL);
		logger.info("Local license validation initialized");
	}

	public synchronized void init(String floatingSeverInfo) throws LicenseManagementException, LmxException, SchedulerException {
		FloatingLicenseManager fm = FloatingLicenseManager.getInstance();
		fm.initLmx(floatingSeverInfo);
		setLicenseVerifyType(LicenseVerifyType.FLOATING);
		logger.info("Floating license validation initialized");
	}

	public void validate(AfisLowLevelFunctionEnum function, Date now, LicenseComponent component)
			throws LicenseManagementException, LicenseValidationException {
		LicenseVerifyType licenseType = getLicenseVerifyType();
		if (licenseType.name().equals(LicenseVerifyType.FLOATING.name())) {
			FloatingLicenseManager.getInstance().checkFeature(function.name(), component, now);
		} else if (licenseType.name().equals(LicenseVerifyType.LOCAL.name())) {
			LocalLicenseManager.getInstance().validate(function, now, component);
		}
	}
}
