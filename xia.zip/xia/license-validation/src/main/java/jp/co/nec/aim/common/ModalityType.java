package jp.co.nec.aim.common;

public enum ModalityType {
	TRIAL,FULL;
}
