package jp.co.nec.aim.license;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class JdkSchduleer {
	private static ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor();
	
	public static void main(String [] args) {
		
		executor.scheduleAtFixedRate(new LmxTaskMock(), 0, 43200000, TimeUnit.MILLISECONDS);	
		System.out.println("JdkSchduleer Started!");
	}
	
	

}
