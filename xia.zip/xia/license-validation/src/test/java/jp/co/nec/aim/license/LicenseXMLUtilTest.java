/**
 * 
 */
package jp.co.nec.aim.license;

import static org.hamcrest.MatcherAssert.*;
import static org.hamcrest.Matchers.*;

import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang.time.FastDateFormat;
import org.junit.Rule;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.experimental.theories.DataPoints;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.google.common.base.Throwables;

import jp.co.nec.aim.license.exception.LicenseManagementException;
import jp.co.nec.aim.license.local.LicenseRights;
import jp.co.nec.aim.license.local.LicenseRightsType;
import jp.co.nec.aim.license.local.LicenseXMLUtil;


/**
 * @author f-kawakami
 * 
 */
@RunWith(Enclosed.class)
public class LicenseXMLUtilTest {

	/**
	 * Test method for
	 * {@link jp.co.nec.nhm.mm.license.LicenseXMLUtil#parseDate2359(java.lang.String)}
	 * .
	 * 
	 * @throws ParseException
	 */
	public static class ParseDate2359With_String {
		@Test
		public void testReturnDate()
			throws ParseException {
			// setup
			FastDateFormat format = FastDateFormat.getInstance("MM/dd/yyyy HH:mm:ss");

			// exercise
			Date actual = LicenseXMLUtil.parseDate2359("03/31/2010");

			// verify
			assertThat(format.format(actual), is("03/31/2010 23:59:59"));
		}
	}

	/**
	 * test formatDate(Date)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class FormatDateWith_Date {
		@Test
		public void tesReturnString()
			throws ParseException {
			// setup
			Date date = DateUtils.parseDate("2010-12-31 00:00:00", new String[] {
				"yyyy-MM-dd HH:mm:ss"
			});

			// exercise
			String actual = LicenseXMLUtil.formatDate(date);

			// verify
			assertThat(actual, is("12/31/10"));
		}
	}

	/**
	 * test parseDate(String)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ParseDateWith_String {
		@Test
		public void testReturnDate()
			throws Exception {
			// exercise
			Method sut =
				LicenseXMLUtil.class.getDeclaredMethod("parseDate", String.class);
			sut.setAccessible(true);
			Date actual = (Date)sut.invoke(null, "03/15/2015");

			// verify
			assertThat(LicenseXMLUtil.formatDate(actual), is("3/15/15"));
		}
	}

	/**
	 * test parse(InputStream)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class GetDocumentWith_InputStream {
		@Test
		public void testReturnDocument()
			throws Exception {
			// setup
			InputStream is =
				getClass().getClassLoader().getResourceAsStream("license/license.xml");

			// exercise
			Method sut =
				LicenseXMLUtil.class.getDeclaredMethod("getDocument", InputStream.class);
			sut.setAccessible(true);
			Document actual = (Document)sut.invoke(null, is);

			// verify
			assertThat(actual, is(notNullValue()));
		}
	}

	/**
	 * test parse(InputStream)
	 * 
	 * @author kawamura
	 * 
	 */
	public static class ParseWith_InputStream {
		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@Test
		public void testReturnLicenseRights()
			throws Exception {
			// setup
			InputStream is =
				getClass().getClassLoader().getResourceAsStream("license/license.xml");

			// exercise
			LicenseRights sut = LicenseXMLUtil.parse(is);

			// verify
			assertThat(sut, is(notNullValue()));
		}

		@Test
		public void testThrowException()
			throws Exception {
			// setup
			InputStream is =
				getClass().getClassLoader().getResourceAsStream("license/license.xm");

			expectedException.expect(LicenseManagementException.class);

			// exercise
			LicenseXMLUtil.parse(is);

			org.junit.Assert.fail();
		}
	}

	/**
	 * test parseLicense(Element)
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ParseLicenseWith_Element {
		@DataPoints
		public static String versionFiles[] = {
			"license/license-version2.0.xml", "license/license-version3.0.xml"
		};

		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@Test
		public void testReturnName()
			throws Exception {
			// setup
			InputStream is =
				getClass().getClassLoader().getResourceAsStream("license/license.xml");
			Method method =
				LicenseXMLUtil.class.getDeclaredMethod("getDocument", InputStream.class);
			method.setAccessible(true);
			Document document = (Document)method.invoke(null, is);

			// exercise
			Method sut =
				LicenseXMLUtil.class.getDeclaredMethod("parseLicense", Element.class);
			sut.setAccessible(true);
			LicenseRights actual =
				(LicenseRights)sut.invoke(null, (Element)document.getDocumentElement());

			// verify
			assertThat(actual.getName(), is("AIM"));
		}

		@Test
		public void testReturnExpiration()
			throws Exception {
			// setup
			InputStream is =
				getClass().getClassLoader().getResourceAsStream("license/license.xml");
			Method method =
				LicenseXMLUtil.class.getDeclaredMethod("getDocument", InputStream.class);
			method.setAccessible(true);
			Document document = (Document)method.invoke(null, is);

			// exercise
			Method sut =
				LicenseXMLUtil.class.getDeclaredMethod("parseLicense", Element.class);
			sut.setAccessible(true);
			LicenseRights actual =
				(LicenseRights)sut.invoke(null, (Element)document.getDocumentElement());

			// verify
			assertThat(actual.getExpiration(), is("03/31/2026"));
		}

		@Test
		public void testReturnFunction()
			throws Exception {
			// setup
			InputStream is =
				getClass().getClassLoader().getResourceAsStream("license/license.xml");
			Method method =
				LicenseXMLUtil.class.getDeclaredMethod("getDocument", InputStream.class);
			method.setAccessible(true);
			Document document = (Document)method.invoke(null, is);

			// exercise
			Method sut =
				LicenseXMLUtil.class.getDeclaredMethod("parseLicense", Element.class);
			sut.setAccessible(true);
			LicenseRights actual =
				(LicenseRights)sut.invoke(null, (Element)document.getDocumentElement());

			// verify
			assertThat(actual.getFunctionCsv(), is("FINGER,PALM,FACE,IRIS"));
		}

		@Test
		public void testReturnSignature()
			throws Exception {
			// setup
			InputStream is =
				getClass().getClassLoader().getResourceAsStream("license/license.xml");
			Method method =
				LicenseXMLUtil.class.getDeclaredMethod("getDocument", InputStream.class);
			method.setAccessible(true);
			Document document = (Document)method.invoke(null, is);

			// exercise
			Method sut =
				LicenseXMLUtil.class.getDeclaredMethod("parseLicense", Element.class);
			sut.setAccessible(true);
			LicenseRights actual =
				(LicenseRights)sut.invoke(null, (Element)document.getDocumentElement());

			// verify
			assertThat(actual.getSignature(), is("MCWCFEWL"));
		}

		@Test
		public void testReturnType()
			throws Exception {
			// setup
			InputStream is =
				getClass().getClassLoader().getResourceAsStream("license/license.xml");
			Method method =
				LicenseXMLUtil.class.getDeclaredMethod("getDocument", InputStream.class);
			method.setAccessible(true);
			Document document = (Document)method.invoke(null, is);

			// exercise
			Method sut =
				LicenseXMLUtil.class.getDeclaredMethod("parseLicense", Element.class);
			sut.setAccessible(true);
			LicenseRights actual =
				(LicenseRights)sut.invoke(null, (Element)document.getDocumentElement());

			// verify
			assertThat(actual.getType(), is(LicenseRightsType.TRIAL));
		}

		@Test
		public void testReturnComponent()
			throws Exception {
			// setup
			InputStream is =
				getClass().getClassLoader().getResourceAsStream("license/license.xml");
			Method method =
				LicenseXMLUtil.class.getDeclaredMethod("getDocument", InputStream.class);
			method.setAccessible(true);
			Document document = (Document)method.invoke(null, is);

			// exercise
			Method sut =
				LicenseXMLUtil.class.getDeclaredMethod("parseLicense", Element.class);
			sut.setAccessible(true);
			LicenseRights actual =
				(LicenseRights)sut.invoke(null, (Element)document.getDocumentElement());

			// verify
			assertThat(actual.getComponent(), is("MM,VM"));
		}

		@Theory
		public void testThrowException_WhenUnsupportedVersion(String fileName)
			throws Exception {
			// setup
			InputStream is = getClass().getClassLoader().getResourceAsStream(fileName);
			Method method =
				LicenseXMLUtil.class.getDeclaredMethod("getDocument", InputStream.class);
			method.setAccessible(true);
			Document document = (Document)method.invoke(null, is);

			expectedException.expect(LicenseManagementException.class);
			expectedException.expectMessage("An unsupported license version.");

			// exercise
			try {
				Method sut =
					LicenseXMLUtil.class.getDeclaredMethod("parseLicense", Element.class);
				sut.setAccessible(true);
				sut.invoke(null, (Element)document.getDocumentElement());
			} catch (InvocationTargetException e) {
				Throwable t = e.getCause();
				if (t instanceof LicenseManagementException) {
					throw new LicenseManagementException(Throwables.getRootCause(e)
						.getMessage());
				}
			}
			org.junit.Assert.fail();
		}

		@Test
		public void testThrowException_WhenCannotParseExpiration()
			throws Exception {
			// setup
			InputStream is =
				getClass().getClassLoader().getResourceAsStream(
					"license/license-trial-wrongdate.xml");
			Method method =
				LicenseXMLUtil.class.getDeclaredMethod("getDocument", InputStream.class);
			method.setAccessible(true);
			Document document = (Document)method.invoke(null, is);

			expectedException.expect(LicenseManagementException.class);
			expectedException
				.expectMessage("An invalid date: could'nt parse expiration.");

			// exercise
			try {
				Method sut =
					LicenseXMLUtil.class.getDeclaredMethod("parseLicense", Element.class);
				sut.setAccessible(true);
				sut.invoke(null, (Element)document.getDocumentElement());
			} catch (InvocationTargetException e) {
				Throwable t = e.getCause();
				if (t instanceof LicenseManagementException) {
					throw new LicenseManagementException(Throwables.getRootCause(e)
						.getMessage());
				}
			}
			org.junit.Assert.fail();
		}
	}
}
