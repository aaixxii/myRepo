package jp.co.nec.aim.license;

import static org.junit.Assume.*;

import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jp.co.nec.aim.clientapi.afis.AfisLowLevelFunctionEnum;
import jp.co.nec.aim.clientapi.afis.FunctionEnum;
import jp.co.nec.aim.common.LicenseComponent;
import jp.co.nec.aim.license.exception.LicenseManagementException;
import jp.co.nec.aim.license.exception.LicenseValidationException;
import jp.co.nec.aim.license.local.LicenseRights;
import jp.co.nec.aim.license.local.LicenseRightsType;
import jp.co.nec.aim.license.local.LicenseState;
import jp.co.nec.aim.license.local.LocalLicenseManager;
import mockit.Mocked;
import mockit.NonStrictExpectations;

import org.apache.commons.lang.time.DateUtils;
import org.junit.Rule;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.experimental.theories.DataPoints;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Throwables;

@RunWith(Enclosed.class)
public class LicenseValidationTest {
	private final LocalLicenseManager sut = new LocalLicenseManager();
	private final String MAC_ADDRESS = "001D92935829";
	private static Logger log = LoggerFactory.getLogger(LicenseValidationTest.class);

	@RunWith(Theories.class)
	public static class ValidationTest {
		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@Mocked
		LicenseState mockeState;

		@DataPoints
		public static AfisLowLevelFunctionEnum[] functions = {
			AfisLowLevelFunctionEnum.TI, AfisLowLevelFunctionEnum.TIM,
			AfisLowLevelFunctionEnum.LI, AfisLowLevelFunctionEnum.TLI,
			AfisLowLevelFunctionEnum.LLI, AfisLowLevelFunctionEnum.LIP,
			AfisLowLevelFunctionEnum.TIP, AfisLowLevelFunctionEnum.LLIP,
			AfisLowLevelFunctionEnum.TLIP, AfisLowLevelFunctionEnum.LIM,
			AfisLowLevelFunctionEnum.TLIM, AfisLowLevelFunctionEnum.LLIM,
			AfisLowLevelFunctionEnum.FI, AfisLowLevelFunctionEnum.LIX,
			AfisLowLevelFunctionEnum.TLIX, AfisLowLevelFunctionEnum.LLIX,
			AfisLowLevelFunctionEnum.II
		};

		/**
		 * Set data 2009/01/01, License is valid
		 */
		@Test
		public void test_Befottre1YearIsValid()
			throws Exception {
			// setup
			final String macAddress = "00:24:21:07:AB:12";
			final String macAddress2 = "001D92935829";

			final List<String> macAddressList = new ArrayList<String>(2);
			macAddressList.add(macAddress);
			macAddressList.add(macAddress2);

			final LicenseRights licenseRights =
				new LicenseRights("AIM", LicenseRightsType.FULL, "01/01/2010", "", "",
					"FINGER", "MM,VM");
			new NonStrictExpectations() {
				{
					mockeState.getLicenseRights();
					result = licenseRights;
				}
			};

			Date now = new Date();
			Date date = DateUtils.setYears(now, 2009);
			date = DateUtils.setMonths(date, 0);
			date = DateUtils.setDays(date, 1);
			date = DateUtils.setHours(date, 0);
			date = DateUtils.setMinutes(date, 0);
			date = DateUtils.setSeconds(date, 0);
			date = DateUtils.setMilliseconds(date, 0);

			// exercise
			LocalLicenseManager sut = new LocalLicenseManager();
			sut.validate(AfisLowLevelFunctionEnum.TI, date, LicenseComponent.MM);
		}

		/**
		 * Set data 2009/12/01, License is valid
		 */
		@Test
		public void test_Before1MonthIsValid()
			throws Exception {
			// setup
			final LicenseRights licenseRights =
				new LicenseRights("AIM", LicenseRightsType.FULL, "01/01/2010", "", "",
					"FINGER", "MM,VM");
			new NonStrictExpectations() {
				{
					mockeState.getLicenseRights();
					result = licenseRights;
				}
			};

			Date now = new Date();
			Date date = DateUtils.setYears(now, 2009);
			date = DateUtils.setMonths(date, 11);
			date = DateUtils.setDays(date, 1);
			date = DateUtils.setHours(date, 0);
			date = DateUtils.setMinutes(date, 0);
			date = DateUtils.setSeconds(date, 0);
			date = DateUtils.setMilliseconds(date, 0);

			// exercise
			LocalLicenseManager sut = new LocalLicenseManager();
			sut.validate(AfisLowLevelFunctionEnum.TI, date, LicenseComponent.MM);
		}

		/**
		 * Set data 2010/01/01, License is valid
		 */
		@Test
		public void test_Before1DayIsValid()
			throws Exception {
			// setup
			final LicenseRights licenseRights =
				new LicenseRights("AIM", LicenseRightsType.FULL, "01/02/2010", "", "",
					"FINGER", "MM,VM");
			new NonStrictExpectations() {
				{
					mockeState.getLicenseRights();
					result = licenseRights;
				}
			};

			Date now = new Date();
			Date date = DateUtils.setYears(now, 2010);
			date = DateUtils.setMonths(date, 0);
			date = DateUtils.setDays(date, 1);
			date = DateUtils.setHours(date, 0);
			date = DateUtils.setMinutes(date, 0);
			date = DateUtils.setSeconds(date, 0);
			date = DateUtils.setMilliseconds(date, 0);

			// exercise
			LocalLicenseManager sut = new LocalLicenseManager();
			sut.validate(AfisLowLevelFunctionEnum.TI, date, LicenseComponent.MM);
		}

		/**
		 * Set data 2010/01/01 23:00, License is valid
		 */
		@Test
		public void test_Before1HourIsValid()
			throws Exception {
			// setup
			final LicenseRights licenseRights =
				new LicenseRights("AIM", LicenseRightsType.FULL, "01/02/2010", "", "",
					"FINGER", "MM,VM");
			new NonStrictExpectations() {
				{
					mockeState.getLicenseRights();
					result = licenseRights;
				}
			};

			Date now = new Date();
			Date date = DateUtils.setYears(now, 2010);
			date = DateUtils.setMonths(date, 0);
			date = DateUtils.setDays(date, 1);
			date = DateUtils.setHours(date, 23);
			date = DateUtils.setMinutes(date, 0);
			date = DateUtils.setSeconds(date, 0);
			date = DateUtils.setMilliseconds(date, 0);

			// exercise
			LocalLicenseManager sut = new LocalLicenseManager();
			sut.validate(AfisLowLevelFunctionEnum.TI, date, LicenseComponent.MM);
		}

		/**
		 * Set data 2010/01/01 23:58:59, License is valid
		 */
		@Test
		public void test_Before1MinIsValid()
			throws Exception {
			// setup
			final LicenseRights licenseRights =
				new LicenseRights("AIM", LicenseRightsType.FULL, "01/02/2010", "", "",
					"FINGER", "MM,VM");
			new NonStrictExpectations() {
				{
					mockeState.getLicenseRights();
					result = licenseRights;
				}
			};

			Date now = new Date();
			Date date = DateUtils.setYears(now, 2010);
			date = DateUtils.setMonths(date, 0);
			date = DateUtils.setDays(date, 1);
			date = DateUtils.setHours(date, 23);
			date = DateUtils.setMinutes(date, 58);
			date = DateUtils.setSeconds(date, 59);
			date = DateUtils.setMilliseconds(date, 0);

			// exercise
			LocalLicenseManager sut = new LocalLicenseManager();
			sut.validate(AfisLowLevelFunctionEnum.TI, date, LicenseComponent.MM);
		}

		/**
		 * Set data 2010/01/01 23:59.59, License is valid
		 */
		@Test
		public void test_Before1SecIsValid()
			throws Exception {
			// setup
			final LicenseRights licenseRights =
				new LicenseRights("AIM", LicenseRightsType.FULL, "01/02/2010", "", "",
					"FINGER", "MM,VM");
			new NonStrictExpectations() {
				{
					mockeState.getLicenseRights();
					result = licenseRights;
				}
			};

			Date now = new Date();
			Date date = DateUtils.setYears(now, 2010);
			date = DateUtils.setMonths(date, 0);
			date = DateUtils.setDays(date, 1);
			date = DateUtils.setHours(date, 23);
			date = DateUtils.setMinutes(date, 59);
			date = DateUtils.setSeconds(date, 59);
			date = DateUtils.setMilliseconds(date, 0);

			// exercise
			LocalLicenseManager sut = new LocalLicenseManager();
			sut.validate(AfisLowLevelFunctionEnum.TI, date, LicenseComponent.MM);
		}

		/**
		 * Set data 2010/1/1 23:59.59, License is valid
		 */
		@Test
		public void test_SameTimeIsValid()
			throws Exception {
			// setup
			final LicenseRights licenseRights =
				new LicenseRights("AIM", LicenseRightsType.FULL, "01/01/2010", "", "",
					"FINGER", "MM,VM");
			new NonStrictExpectations() {
				{
					mockeState.getLicenseRights();
					result = licenseRights;
				}
			};

			Date now = new Date();
			Date date = DateUtils.setYears(now, 2010);
			date = DateUtils.setMonths(date, 0);
			date = DateUtils.setDays(date, 1);
			date = DateUtils.setHours(date, 23);
			date = DateUtils.setMinutes(date, 59);
			date = DateUtils.setSeconds(date, 59);
			date = DateUtils.setMilliseconds(date, 0);

			// exercise
			LocalLicenseManager sut = new LocalLicenseManager();
			sut.validate(AfisLowLevelFunctionEnum.TI, date, LicenseComponent.MM);
		}

		/**
		 * Set data 2012/1/2 00:00.00, License is expired
		 */
		@Test
		public void test_After1SecIsExpired()
			throws Exception {
			// setup
			final LicenseRights licenseRights =
				new LicenseRights("AIM", LicenseRightsType.FULL, "01/01/2012", "", "",
					"FINGER", "MM,VM");
			new NonStrictExpectations() {
				{
					mockeState.getLicenseRights();
					result = licenseRights;
				}
			};

			Date now = new Date();
			Date date = DateUtils.setYears(now, 2012);
			date = DateUtils.setMonths(date, 0);
			date = DateUtils.setDays(date, 2);
			date = DateUtils.setHours(date, 0);
			date = DateUtils.setMinutes(date, 0);
			date = DateUtils.setSeconds(date, 0);
			date = DateUtils.setMilliseconds(date, 0);

			expectedException.expect(LicenseValidationException.class);
			expectedException
				.expectMessage("License for 'AIM' expired on 1/1/12; it is now 1/2/12.");

			// exercise
			LocalLicenseManager sut = new LocalLicenseManager();
			sut.validate(AfisLowLevelFunctionEnum.TI, date, LicenseComponent.MM);

			org.junit.Assert.fail("It's " + date + ", but license is valid!");
		}

		/**
		 * Set data 2012/1/2 00:01.59, License is expired
		 */
		@Test
		public void test_After1MinIsExpired()
			throws Exception {
			// setup
			final LicenseRights licenseRights =
				new LicenseRights("AIM", LicenseRightsType.FULL, "01/01/2012", "", "",
					"FINGER", "MM,VM");
			new NonStrictExpectations() {
				{
					mockeState.getLicenseRights();
					result = licenseRights;
				}
			};

			Date now = new Date();
			Date date = DateUtils.setYears(now, 2012);
			date = DateUtils.setMonths(date, 0);
			date = DateUtils.setDays(date, 2);
			date = DateUtils.setHours(date, 0);
			date = DateUtils.setMinutes(date, 0);
			date = DateUtils.setSeconds(date, 59);
			date = DateUtils.setMilliseconds(date, 0);

			expectedException.expect(LicenseValidationException.class);
			expectedException
				.expectMessage("License for 'AIM' expired on 1/1/12; it is now 1/2/12.");

			// exercise
			LocalLicenseManager sut = new LocalLicenseManager();
			sut.validate(AfisLowLevelFunctionEnum.TI, date, LicenseComponent.MM);

			org.junit.Assert.fail("It's " + date + ", but license is valid!");
		}

		/**
		 * Set data 2010/1/2 01:00.00, License is expired
		 */
		@Test
		public void test_After1HourIsExpired()
			throws Exception {
			// setup
			final LicenseRights licenseRights =
				new LicenseRights("AIM", LicenseRightsType.FULL, "01/01/2012", "", "",
					"FINGER", "MM,VM");
			new NonStrictExpectations() {
				{
					mockeState.getLicenseRights();
					result = licenseRights;
				}
			};

			Date now = new Date();
			Date date = DateUtils.setYears(now, 2012);
			date = DateUtils.setMonths(date, 0);
			date = DateUtils.setDays(date, 2);
			date = DateUtils.setHours(date, 0);
			date = DateUtils.setMinutes(date, 59);
			date = DateUtils.setSeconds(date, 59);
			date = DateUtils.setMilliseconds(date, 0);

			expectedException.expect(LicenseValidationException.class);
			expectedException
				.expectMessage("License for 'AIM' expired on 1/1/12; it is now 1/2/12.");

			// exercise
			LocalLicenseManager sut = new LocalLicenseManager();
			sut.validate(AfisLowLevelFunctionEnum.TI, date, LicenseComponent.MM);

			org.junit.Assert.fail("It's " + date + ", but license is valid!");
		}

		/**
		 * Set data 2010/1/2 00:00.00, License is expired
		 */
		@Test
		public void test_After1DayIsExpired()
			throws Exception {
			// setup
			final LicenseRights licenseRights =
				new LicenseRights("AIM", LicenseRightsType.FULL, "01/01/2012", "", "",
					"FINGER", "MM,VM");
			new NonStrictExpectations() {
				{
					mockeState.getLicenseRights();
					result = licenseRights;
				}
			};

			Date now = new Date();
			Date date = DateUtils.setYears(now, 2012);
			date = DateUtils.setMonths(date, 0);
			date = DateUtils.setDays(date, 2);
			date = DateUtils.setHours(date, 0);
			date = DateUtils.setMinutes(date, 0);
			date = DateUtils.setSeconds(date, 0);
			date = DateUtils.setMilliseconds(date, 0);

			expectedException.expect(LicenseValidationException.class);
			expectedException
				.expectMessage("License for 'AIM' expired on 1/1/12; it is now 1/2/12.");

			// exercise
			LocalLicenseManager sut = new LocalLicenseManager();
			sut.validate(AfisLowLevelFunctionEnum.TI, date, LicenseComponent.MM);

			org.junit.Assert.fail("It's " + date + ", but license is valid!");
		}

		/**
		 * Set data 2010/2/1 00:00.00, License is expired
		 */
		@Test
		public void test_After1MonthIsExpired()
			throws Exception {
			// setup
			final LicenseRights licenseRights =
				new LicenseRights("AIM", LicenseRightsType.FULL, "01/01/2012", "", "",
					"FINGER", "MM,VM");
			new NonStrictExpectations() {
				{
					mockeState.getLicenseRights();
					result = licenseRights;
				}
			};

			Date now = new Date();
			Date date = DateUtils.setYears(now, 2012);
			date = DateUtils.setDays(date, 1);
			// Month must be set after setting day because it is error Feb 30,
			// 2010.
			date = DateUtils.setMonths(date, 1);
			date = DateUtils.setHours(date, 0);
			date = DateUtils.setMinutes(date, 0);
			date = DateUtils.setSeconds(date, 0);
			date = DateUtils.setMilliseconds(date, 0);

			expectedException.expect(LicenseValidationException.class);
			expectedException
				.expectMessage("License for 'AIM' expired on 1/1/12; it is now 2/1/12.");

			// exercise
			LocalLicenseManager sut = new LocalLicenseManager();
			sut.validate(AfisLowLevelFunctionEnum.TI, date, LicenseComponent.MM);

			org.junit.Assert.fail("It's " + date + ", but license is valid!");
		}

		/**
		 * Set data 2011/1/1 00:00.00, License is expired
		 */
		@Test
		public void test_After1YearIsExpired()
			throws Exception {
			// setup
			final LicenseRights licenseRights =
				new LicenseRights("AIM", LicenseRightsType.FULL, "01/01/2012", "", "",
					"FINGER", "MM,VM");
			new NonStrictExpectations() {
				{
					mockeState.getLicenseRights();
					result = licenseRights;
				}
			};

			Date date = DateUtils.parseDate("2013/01/01 00:00:00", new String[] {
				"yyyy/MM/dd HH:mm:ss"
			});

			expectedException.expect(LicenseValidationException.class);
			expectedException
				.expectMessage("License for 'AIM' expired on 1/1/12; it is now 1/1/13.");

			// exercise
			LocalLicenseManager sut = new LocalLicenseManager();
			sut.validate(AfisLowLevelFunctionEnum.TI, date, LicenseComponent.MM);
		}

		/**
		 * 3.0 07/08/2011 FINGER,PALM,IRIS, TRIAL
		 */
		@Theory
		public void test30_07_08_2011_FingerPalmIris_trial(
			AfisLowLevelFunctionEnum function)
			throws Exception {
			FunctionEnum functionEnum = function.getFunction();
			assumeTrue(functionEnum == FunctionEnum.FINGER
				|| functionEnum == FunctionEnum.PALM || functionEnum == FunctionEnum.IRIS);

			// setup
			final LicenseRights licenseRights =
				new LicenseRights("AIM", LicenseRightsType.TRIAL, "07/08/2011", "", "",
					"FINGER,PALM,IRIS", "MM,VM");
			new NonStrictExpectations() {
				{
					mockeState.getLicenseRights();
					result = licenseRights;
				}
			};

			Date date = DateUtils.parseDate("2011/01/01 00:00:00", new String[] {
				"yyyy/MM/dd HH:mm:ss"
			});

			// exercise
			LocalLicenseManager sut = new LocalLicenseManager();
			sut.validate(function, date, LicenseComponent.MM);
		}

		//
		// /**
		// * Using a new trial xml created by creator.
		// */
		// @Test
		// public void testTrialValid() throws Exception {
		// addReturnValue(LicenseValidation.class, "getLicenseXml", Path
		// .getPath("license/Jan201201License.xml"));
		// LicenseValidation licenseManager = new LicenseValidation();
		// licenseManager
		// .validate(AfisLowLevelFunctionEnum.TI.name(), createDate20120101());
		// LicenseRights licenseRights =
		// SharedStateSingleton.instance().getLicenseState().getLicenseRights();
		// assertEquals("01/01/2012", licenseRights.getExpiration());
		// }
		//
		// /**
		// * Using a new FULL xml created by creator.
		// */
		// @Test
		// public void testFullValid() throws Exception {
		// final String macAddress2 = "00242107AB12";
		// final String macAddress = "001D92935829";
		// addReturnValue("HardwareInfo", "getLinuxCpuInfo",
		// "model name	: Intel(R) Xeon(R) CPU           X5470  ");
		// addReturnValue("HardwareInfo", "getLinuxCpuInfo",
		// "model name	: Intel(R) Xeon(R) CPU           X5470  ");
		// List<String> macAddressList = new ArrayList<String>(2);
		// macAddressList.add(macAddress);
		// macAddressList.add(macAddress2);
		// addReturnValue("HardwareInfo", "getMacAddresses", macAddressList);
		// addReturnValue("LicenseValidation", "getLicenseXml", Path
		// .getPath("license/license-full.xml"));
		// LicenseValidation licenseManager = new LicenseValidation();
		// licenseManager
		// .validate(AfisLowLevelFunctionEnum.TI.name(), createDate20100101());
		// }
		//
		// /**
		// * Using a new formatted FULL xml created by creator.
		// */
		// @Test
		// public void testFullValidFormatXml() throws Exception {
		// final String macAddress2 = "00242107AB12";
		// final String macAddress = "001D92935829";
		// addReturnValue("HardwareInfo", "getLinuxCpuInfo",
		// "model name	: Intel(R) Xeon(R) CPU           X5470  ");
		// addReturnValue("HardwareInfo", "getLinuxCpuInfo",
		// "model name	: Intel(R) Xeon(R) CPU           X5470  ");
		// List<String> macAddressList = new ArrayList<String>(2);
		// macAddressList.add(macAddress);
		// macAddressList.add(macAddress2);
		// addReturnValue("HardwareInfo", "getMacAddresses", macAddressList);
		// addReturnValue("LicenseValidation", "getLicenseXml", Path
		// .getPath("license/license-full-format.xml"));
		// LicenseValidation licenseManager = new LicenseValidation();
		// licenseManager
		// .validate(AfisLowLevelFunctionEnum.TI.name(), createDate20100101());
		// }
		//

		/**
		 * using a wrong mac-address
		 */
		// @Test
		// public void testWrongMacAddress()
		// throws Exception {
		// // setup
		// final LicenseRights licenseRights =
		// new LicenseRights("AIM", LicenseRightsType.FULL, "01/01/2012", "",
		// "",
		// "FINGER,PALM,IRIS", "MM,VM");
		// new NonStrictExpectations() {
		// {
		// mockeState.getLicenseRights();
		// result = licenseRights;
		// }
		// };
		//
		// final List<String> macAddressList = new ArrayList<String>(2);
		// macAddressList.add("001122334455");
		// new NonStrictExpectations(HardwareInfo.class) {
		// {
		// HardwareInfo.getCpuInfo();
		// result = "proc/cpuinfo";
		//
		// HardwareInfo.getMacAddresses();
		// result = macAddressList;
		//
		// HardwareInfo.getLinuxCpuInfo();
		// result = "aaa";
		// }
		// };
		//
		// Date date = DateUtils.parseDate("2010/01/01 00:00:00", new String[] {
		// "yyyy/MM/dd HH:mm:ss"
		// });
		//
		// // exercise
		// LicenseValidation sut = new LicenseValidation();
		// sut.validate(AfisLowLevelFunctionEnum.TI, date, "MM,VM");
		//
		// org.junit.Assert.fail("Error is not occured is invalid. ");
		// }

		//
		// /**
		// * using multi mac-addresses
		// */
		// @Test
		// public void testMultiMacAddressError() throws Exception {
		// try {
		// final String macAddress1 = "001122334455";
		// final String macAddress2 = "667788990011";
		// List<String> macAddressList = new ArrayList<String>(2);
		// macAddressList.add(macAddress1);
		// macAddressList.add(macAddress2);
		// addReturnValue("LicenseValidation", "getLicenseXml", Path
		// .getPath("license/license-full.xml"));
		// addReturnValue("HardwareInfo", "getLinuxCpuInfo", Path
		// .getPath("proc/cpuinfo"));
		// addReturnValue("HardwareInfo", "getLinuxCpuInfo", Path
		// .getPath("proc/cpuinfo"));
		// addReturnValue("HardwareInfo", "getMacAddresses", macAddressList);
		// licenseManager.validate(AfisLowLevelFunctionEnum.TI.name(), new
		// Date());
		// fail("Error is not occured is invalid. ");
		// } catch (LicenseException e) {
		// }
		// }
		//
		// /**
		// * using multi mac-addresses
		// */
		// @Test
		// public void testMultiMacAddress() throws Exception {
		// addReturnValue("LicenseValidation", "getLicenseXml", Path
		// .getPath("license/license-full.xml"));
		// final String macAddress1 = "00242107AB12";
		// final String macAddress2 = MAC_ADDRESS;
		// addReturnValue("HardwareInfo", "getLinuxCpuInfo",
		// "model name	: Intel(R) Xeon(R) CPU           X5470  ");
		// addReturnValue("HardwareInfo", "getLinuxCpuInfo",
		// "model name	: Intel(R) Xeon(R) CPU           X5470  ");
		// List<String> macAddressList = new ArrayList<String>(2);
		// macAddressList.add(macAddress1);
		// macAddressList.add(macAddress2);
		// addReturnValue("HardwareInfo", "getMacAddresses", macAddressList);
		// licenseManager.validate(AfisLowLevelFunctionEnum.TI.name(),
		// createDate(2010, 1,
		// 1, 0, 0, 0));
		// LicenseRights licenseRights =
		// SharedStateSingleton.instance().getLicenseState().getLicenseRights();
		// assertEquals("AIM", licenseRights.getName());
		// }
		//
		// /**
		// * TYPE ERROR
		// */
		// @Test
		// public void testLicenseNothing() throws Exception {
		// try {
		// List<String> macAddressList = new ArrayList<String>(2);
		// macAddressList.add(MAC_ADDRESS);
		// addReturnValue("LicenseValidation", "getLicenseXml",
		// "license/license-nothing.xml");
		// addReturnValue("HardwareInfo", "getMacAddresses", macAddressList);
		// addReturnValue("HardwareInfo", "getCpuInfo",
		// Path.getPath("proc/cpuinfo"));
		// addReturnValue("HardwareInfo", "getCpuInfo",
		// Path.getPath("proc/cpuinfo"));
		// LicenseValidation licenseManager = new LicenseValidation();
		// licenseManager.validate(AfisLowLevelFunctionEnum.TI.name(),
		// createDate(2010,
		// 1, 1, 0, 0, 0));
		// fail("Error should be occured.");
		// } catch (LicenseException e) {
		// }
		// }
		//
		// @Test
		// public void testGetLicenseXml() throws Exception {
		// addReturnValue("System", "getProperty", "hoge");
		// assertEquals("hoge" + File.separator + LicenseValidation.LICENSE_XML,
		// LicenseValidation.getLicenseXml());
		// }
		//

		/**
		 * 3.0 01/01/2012 FINGER, TRIAL
		 */
		@Theory
		public void test30_01012012_Finger_trial(AfisLowLevelFunctionEnum function)
			throws Exception {
			// filter
			FunctionEnum functionEnum = function.getFunction();
			assumeTrue(functionEnum == FunctionEnum.FINGER);

			// setup
			final LicenseRights licenseRights =
				new LicenseRights("AIM", LicenseRightsType.TRIAL, "01/01/2012", "", "",
					"FINGER", "MM,VM");
			new NonStrictExpectations() {
				{
					mockeState.getLicenseRights();
					result = licenseRights;
				}
			};

			Date date = DateUtils.parseDate("2009/01/01 00:00:00", new String[] {
				"yyyy/MM/dd HH:mm:ss"
			});

			// exercise
			LocalLicenseManager sut = new LocalLicenseManager();
			sut.validate(function, date, LicenseComponent.MM);
		}

		/**
		 * throw Exception when there is no FINGER in the license.
		 * 
		 * @param function
		 * @throws Exception
		 */
		@Theory
		public void test_throwException_WhenNoFingerInTheLicense(
			AfisLowLevelFunctionEnum function)
			throws Exception {
			// filter
			FunctionEnum functionEnum = function.getFunction();
			assumeTrue(functionEnum == FunctionEnum.FINGER);

			// setup
			final LicenseRights licenseRights =
				new LicenseRights("AIM", LicenseRightsType.FULL, "07/08/2011", "", "",
					"PALM,IRIS", "MM,VM");
			new NonStrictExpectations() {
				{
					mockeState.getLicenseRights();
					result = licenseRights;
				}
			};

			Date date = DateUtils.parseDate("2011/01/01 00:00:00", new String[] {
				"yyyy/MM/dd HH:mm:ss"
			});

			expectedException.expect(LicenseValidationException.class);
			expectedException
				.expectMessage("Invalid license function '" + function + "'");

			// exercise
			LocalLicenseManager sut = new LocalLicenseManager();
			sut.validate(function, date, LicenseComponent.MM);

			org.junit.Assert.fail();
		}

		/**
		 * throw Exception when there is no FACE in the license.
		 * 
		 * @param function
		 * @throws Exception
		 */
		@Test
		public void test_throwException_WhenNoFaceInTheLicense()
			throws Exception {
			// setup
			final LicenseRights licenseRights =
				new LicenseRights("AIM", LicenseRightsType.FULL, "07/08/2011", "", "",
					"FINGER,PALM,IRIS", "MM,VM");
			new NonStrictExpectations() {
				{
					mockeState.getLicenseRights();
					result = licenseRights;
				}
			};

			Date date = DateUtils.parseDate("2011/01/01 00:00:00", new String[] {
				"yyyy/MM/dd HH:mm:ss"
			});

			expectedException.expect(LicenseValidationException.class);
			expectedException.expectMessage("Invalid license function 'FI'");

			// exercise
			LocalLicenseManager sut = new LocalLicenseManager();
			sut.validate(AfisLowLevelFunctionEnum.FI, date, LicenseComponent.MM);

			org.junit.Assert.fail();
		}

		/**
		 * throw Exception when there is no PALM in the license.
		 * 
		 * @param function
		 * @throws Exception
		 */
		@Theory
		public void test_throwException_WhenNoPalmInTheLicense(
			AfisLowLevelFunctionEnum function)
			throws Exception {
			// filter
			FunctionEnum functionEnum = function.getFunction();
			assumeTrue(functionEnum == FunctionEnum.PALM);

			// setup
			final LicenseRights licenseRights =
				new LicenseRights("AIM", LicenseRightsType.FULL, "07/08/2011", "", "",
					"FINGER,IRIS,FACE", "MM,VM");
			new NonStrictExpectations() {
				{
					mockeState.getLicenseRights();
					result = licenseRights;
				}
			};

			Date date = DateUtils.parseDate("2011/01/01 00:00:00", new String[] {
				"yyyy/MM/dd HH:mm:ss"
			});

			expectedException.expect(LicenseValidationException.class);
			expectedException
				.expectMessage("Invalid license function '" + function + "'");

			// exercise
			LocalLicenseManager sut = new LocalLicenseManager();
			sut.validate(function, date, LicenseComponent.MM);

			org.junit.Assert.fail();
		}

		/**
		 * throw Exception when there is no IRIS in the license.
		 * 
		 * @param function
		 * @throws Exception
		 */
		@Theory
		public void test_throwException_WhenNoIrisInTheLicense(
			AfisLowLevelFunctionEnum function)
			throws Exception {
			// filter
			FunctionEnum functionEnum = function.getFunction();
			assumeTrue(functionEnum == FunctionEnum.IRIS);

			// setup
			final LicenseRights licenseRights =
				new LicenseRights("AIM", LicenseRightsType.FULL, "07/08/2011", "", "",
					"FINGER,FACE", "MM,VM");
			new NonStrictExpectations() {
				{
					mockeState.getLicenseRights();
					result = licenseRights;
				}
			};

			Date date = DateUtils.parseDate("2011/01/01 00:00:00", new String[] {
				"yyyy/MM/dd HH:mm:ss"
			});

			expectedException.expect(LicenseValidationException.class);
			expectedException
				.expectMessage("Invalid license function '" + function + "'");

			// exercise
			LocalLicenseManager sut = new LocalLicenseManager();
			sut.validate(function, date, LicenseComponent.MM);

			org.junit.Assert.fail();
		}

		/**
		 * 3.0 01/01/2012 Finger,Palm, TRIAL
		 */
		@Theory
		public void test30_01012012_FingerPalm_trial(AfisLowLevelFunctionEnum function)
			throws Exception {
			// filter
			FunctionEnum functionEnum = function.getFunction();
			assumeTrue(functionEnum == FunctionEnum.FINGER
				|| functionEnum == FunctionEnum.PALM);

			// setup
			final LicenseRights licenseRights =
				new LicenseRights("AIM", LicenseRightsType.TRIAL, "01/01/2012", "", "",
					"FINGER,PALM", "MM,VM");
			new NonStrictExpectations() {
				{
					mockeState.getLicenseRights();
					result = licenseRights;
				}
			};

			Date date = DateUtils.parseDate("2009/01/01 00:00:00", new String[] {
				"yyyy/MM/dd HH:mm:ss"
			});

			// exercise
			LocalLicenseManager sut = new LocalLicenseManager();
			sut.validate(function, date, LicenseComponent.MM);
		}

		/**
		 * 3.0 01/01/2012 Finger,Palm,Face, TRIAL
		 */
		@Theory
		public void test30_01012012_FingerPalmFace_trial(AfisLowLevelFunctionEnum function)
			throws Exception {
			// filter
			FunctionEnum functionEnum = function.getFunction();
			assumeTrue(functionEnum == FunctionEnum.FINGER
				|| functionEnum == FunctionEnum.PALM || functionEnum == FunctionEnum.FACE);

			// setup
			final LicenseRights licenseRights =
				new LicenseRights("AIM", LicenseRightsType.TRIAL, "01/01/2012", "", "",
					"FINGER,PALM,FACE", "MM,VM");
			new NonStrictExpectations() {
				{
					mockeState.getLicenseRights();
					result = licenseRights;
				}
			};

			Date now = new Date();
			Date date = DateUtils.setYears(now, 2009);
			date = DateUtils.setMonths(date, 0);
			date = DateUtils.setDays(date, 1);
			date = DateUtils.setHours(date, 0);
			date = DateUtils.setMinutes(date, 0);
			date = DateUtils.setSeconds(date, 0);
			date = DateUtils.setMilliseconds(date, 0);

			// exercise
			LocalLicenseManager sut = new LocalLicenseManager();
			sut.validate(function, date, LicenseComponent.MM);
		}

		/**
		 * 01/01/2012 30 Finger, Full
		 */
		@Theory
		public void test01012012_30_Finger_full(AfisLowLevelFunctionEnum function)
			throws Exception {
			// filter
			FunctionEnum functionEnum = function.getFunction();
			assumeTrue(functionEnum == FunctionEnum.FINGER);

			// setup
			final LicenseRights licenseRights =
				new LicenseRights("AIM", LicenseRightsType.FULL, "01/01/2012", "", "",
					"FINGER", "MM,VM");
			new NonStrictExpectations() {
				{
					mockeState.getLicenseRights();
					result = licenseRights;
				}
			};

			Date date = DateUtils.parseDate("2010/01/01 00:00:00", new String[] {
				"yyyy/MM/dd HH:mm:ss"
			});

			// exercise
			LocalLicenseManager sut = new LocalLicenseManager();
			sut.validate(function, date, LicenseComponent.MM);
		}

		/**
		 * 01/01/2012 30 Palm, Full
		 */
		@Theory
		public void test01012012_30_Palm_full(AfisLowLevelFunctionEnum function)
			throws Exception {
			// filter
			FunctionEnum functionEnum = function.getFunction();
			assumeTrue(functionEnum == FunctionEnum.PALM);

			// setup
			final LicenseRights licenseRights =
				new LicenseRights("AIM", LicenseRightsType.FULL, "01/01/2012", "", "",
					"PALM", "MM,VM");
			new NonStrictExpectations() {
				{
					mockeState.getLicenseRights();
					result = licenseRights;
				}
			};

			Date date = DateUtils.parseDate("2010/01/01 00:00:00", new String[] {
				"yyyy/MM/dd HH:mm:ss"
			});

			// exercise
			LocalLicenseManager sut = new LocalLicenseManager();
			sut.validate(function, date, LicenseComponent.MM);
		}

		/**
		 * 01/01/2012 30 Palm, Full
		 */
		@Theory
		public void test01012012_30_FIngerPalm_full(AfisLowLevelFunctionEnum function)
			throws Exception {
			// filter
			FunctionEnum functionEnum = function.getFunction();
			assumeTrue(functionEnum == FunctionEnum.PALM
				|| functionEnum == FunctionEnum.FINGER);

			// setup
			final LicenseRights licenseRights =
				new LicenseRights("AIM", LicenseRightsType.FULL, "01/01/2012", "", "",
					"FINGER,PALM", "MM,VM");
			new NonStrictExpectations() {
				{
					mockeState.getLicenseRights();
					result = licenseRights;
				}
			};

			Date date = DateUtils.parseDate("2010/01/01 00:00:00", new String[] {
				"yyyy/MM/dd HH:mm:ss"
			});

			// exercise
			LocalLicenseManager sut = new LocalLicenseManager();
			sut.validate(function, date, LicenseComponent.MM);
		}

		/**
		 * 01/01/2012 30 Finger,Palm,Face,Iris, Full
		 */
		@Theory
		public void test01012012_30_FIngerPalmFaceIris_full(
			AfisLowLevelFunctionEnum function)
			throws Exception {
			// setup
			final LicenseRights licenseRights =
				new LicenseRights("AIM", LicenseRightsType.FULL, "01/01/2012", "", "",
					"FINGER,PALM,FACE,IRIS", "MM,VM");
			new NonStrictExpectations() {
				{
					mockeState.getLicenseRights();
					result = licenseRights;
				}
			};

			Date date = DateUtils.parseDate("2010/01/01 00:00:00", new String[] {
				"yyyy/MM/dd HH:mm:ss"
			});

			// exercise
			LocalLicenseManager sut = new LocalLicenseManager();
			sut.validate(function, date, LicenseComponent.MM);
		}

		/**
		 * The MM is not covered by component
		 * 
		 */
		@Test
		public void test_throwException_WhenMatchManagerIsNotCoveredByComponent()
			throws Exception {
			// setup
			final LicenseRights licenseRights =
				new LicenseRights("AIM", LicenseRightsType.FULL, "01/01/2012", "", "",
					"FINGER,PALM,FACE,IRIS", "VM");
			new NonStrictExpectations() {
				{
					mockeState.getLicenseRights();
					result = licenseRights;
				}
			};

			Date date = DateUtils.parseDate("2010/01/01 00:00:00", new String[] {
				"yyyy/MM/dd HH:mm:ss"
			});

			expectedException.expect(LicenseValidationException.class);
			expectedException
				.expectMessage("An invalid license: there is an invalid component.");

			// exercise
			LocalLicenseManager sut = new LocalLicenseManager();
			sut.validate(AfisLowLevelFunctionEnum.TI, date, LicenseComponent.MM);

			org.junit.Assert.fail();
		}

		/**
		 * The VM is not covered by component
		 * 
		 */
		@Test
		public void test_throwException_WhenVerificationManagerIsNotCoveredByComponent()
			throws Exception {
			// setup
			final LicenseRights licenseRights =
				new LicenseRights("AIM", LicenseRightsType.FULL, "01/01/2012", "", "",
					"FINGER,PALM,FACE,IRIS", "MM");
			new NonStrictExpectations() {
				{
					mockeState.getLicenseRights();
					result = licenseRights;
				}
			};

			Date date = DateUtils.parseDate("2010/01/01 00:00:00", new String[] {
				"yyyy/MM/dd HH:mm:ss"
			});

			expectedException.expect(LicenseValidationException.class);
			expectedException
				.expectMessage("An invalid license: there is an invalid component.");

			// exercise
			LocalLicenseManager sut = new LocalLicenseManager();
			sut.validate(AfisLowLevelFunctionEnum.TI, date, LicenseComponent.VM);

			org.junit.Assert.fail();
		}

		/**
		 * The MM is covered by component
		 * 
		 */
		@Test
		public void test_MatchManagerIsCoveredByComponent()
			throws Exception {
			// setup
			final LicenseRights licenseRights =
				new LicenseRights("AIM", LicenseRightsType.FULL, "01/01/2012", "", "",
					"FINGER,PALM,FACE,IRIS", "VM,MM");
			new NonStrictExpectations() {
				{
					mockeState.getLicenseRights();
					result = licenseRights;
				}
			};

			Date date = DateUtils.parseDate("2010/01/01 00:00:00", new String[] {
				"yyyy/MM/dd HH:mm:ss"
			});

			// exercise
			LocalLicenseManager sut = new LocalLicenseManager();
			sut.validate(AfisLowLevelFunctionEnum.TI, date, LicenseComponent.MM);
		}

		/**
		 * The VM is covered by component
		 * 
		 */
		@Test
		public void test_VerificationManagerIsCoveredByComponent()
			throws Exception {
			// setup
			final LicenseRights licenseRights =
				new LicenseRights("AIM", LicenseRightsType.FULL, "01/01/2012", "", "",
					"FINGER,PALM,FACE,IRIS", "VM");
			new NonStrictExpectations() {
				{
					mockeState.getLicenseRights();
					result = licenseRights;
				}
			};

			Date date = DateUtils.parseDate("2010/01/01 00:00:00", new String[] {
				"yyyy/MM/dd HH:mm:ss"
			});

			// exercise
			LocalLicenseManager sut = new LocalLicenseManager();
			sut.validate(AfisLowLevelFunctionEnum.TI, date, LicenseComponent.VM);
		}
	}

	/**
	 * test validateXml(InputStream)
	 * 
	 * @author kawamura
	 * 
	 */
	@RunWith(Theories.class)
	public static class ValidateWith_InputStream {
		@Rule
		public ExpectedException expectedException = ExpectedException.none();

		@DataPoints
		public static String[] invalidLicense = {
			"license/invalid/component_is_empty.xml",
			"license/invalid/expiration_is_empty.xml",
			"license/invalid/function_is_empty.xml", "license/invalid/name_is_empty.xml",
			"license/invalid/nothing_is_component_attribute.xml",
			"license/invalid/nothing_is_expiration_attribute.xml",
			"license/invalid/nothing_is_function_attribute.xml",
			"license/invalid/nothing_is_name_attribute.xml",
			"license/invalid/nothing_is_rights_element.xml",
			"license/invalid/nothing_is_signature_attribute.xml",
			"license/invalid/nothing_is_type_attribute.xml",
			"license/invalid/nothing_is_version_attribute.xml",
			"license/invalid/signature_is_empty.xml",
			"license/invalid/type_is_invalid.xml",
			"license/invalid/version_is_invalid.xml",
		};

		@Theory
		public void test_throwException_WhenNothingIsVersionElement(String file)
			throws Exception {
			// setup
			InputStream is = getClass().getClassLoader().getResourceAsStream(file);

			expectedException.expect(LicenseManagementException.class);

			// exercise
			try {
				Method sut =
					LocalLicenseManager.class.getDeclaredMethod("validateXml",
						InputStream.class);
				sut.setAccessible(true);
				sut.invoke(new LocalLicenseManager(), is);
			} catch (InvocationTargetException e) {
				Throwable t = e.getCause();
				// verify
				if (t instanceof LicenseManagementException) {
					throw new LicenseManagementException(Throwables.getRootCause(e)
						.getMessage());
				}
			}
			org.junit.Assert.fail();
		}
		
		/**
		 * test init(InputStream)
		 * 
		 * @param file
		 * @throws Exception
		 */
		@Test
		public void test_throwException_NotExistLicense()
			throws Exception {
			// setup
			InputStream is = getClass().getClassLoader().getResourceAsStream("not exist.xml");

			expectedException.expect(LicenseManagementException.class);
			expectedException.expectMessage("There is not the license.xml.");

			// exercise
			LocalLicenseManager license = new LocalLicenseManager();
			license.init(is);
			org.junit.Assert.fail();
		}
	}
}
