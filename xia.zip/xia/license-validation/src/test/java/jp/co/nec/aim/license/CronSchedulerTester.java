package jp.co.nec.aim.license;

import org.quartz.CronScheduleBuilder;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;

public class CronSchedulerTester {
	Scheduler sch;
	public CronSchedulerTester() {
		SchedulerFactory schfa = new StdSchedulerFactory();
		try {
			sch = schfa.getScheduler();
		} catch (SchedulerException e) {			
			e.printStackTrace();
		}
	}
	
	
	public  void startCornJob() throws SchedulerException, InterruptedException {		
		JobDetail jobdetail = JobBuilder.newJob(NewJob.class)
		    .withIdentity("myjob1", "mygroup1").build();
		//Executes only one time
		Trigger trigger = TriggerBuilder.newTrigger().withIdentity("mytrigger1", "mygroup1")
				.withSchedule(
						CronScheduleBuilder.cronSchedule("0/5 * * * * ?"))
					.build();		
		sch.scheduleJob(jobdetail, trigger);
		sch.start();
		System.out.println("CornJob is started!");
	}
	
	public void stopCornJob() {
		try {
			sch.shutdown(true);
			System.out.println("CornJob is shutdown!");
		} catch (SchedulerException e) {			
			e.printStackTrace();
		}
	}
}
