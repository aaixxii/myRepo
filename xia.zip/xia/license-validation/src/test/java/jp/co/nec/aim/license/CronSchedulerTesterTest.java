package jp.co.nec.aim.license;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.quartz.SchedulerException;

public class CronSchedulerTesterTest {	
	
	CronSchedulerTester cornJob;

	@Before
	public void setUp() throws Exception {
		cornJob = new CronSchedulerTester();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testStartCornJob() throws SchedulerException, InterruptedException {
		CronSchedulerTester cornJob = new CronSchedulerTester();
		cornJob.startCornJob();
	}

	@Test
	public void testStopCornJob() {
		cornJob.stopCornJob();
	}

}
