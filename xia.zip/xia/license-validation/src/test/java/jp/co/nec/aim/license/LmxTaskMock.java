package jp.co.nec.aim.license;

public class LmxTaskMock implements Runnable {

	@Override
	public void run() {
		System.out.println("Lmx DailyJob runing!");		
	}

}
