package com.nec.aim.audio.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nec.aim.audio.persistence.entity.User;
import com.nec.aim.audio.persistence.repository.UserRepository;

@Controller
public class AimAudioController {

	@Autowired
	private UserRepository userRepository;

	@GetMapping({ "/", "/login" })
	public String index() {
		return "login";
	}

	@PostMapping("/login")
	public String logininmain(HttpServletRequest request, HttpServletResponse response,
			@RequestParam("username") String username, @RequestParam("password") String password) {
		AtomicBoolean sucess = new AtomicBoolean(false);
		List<User> listUser = userRepository.findAll();
		listUser.forEach(one -> {
			if (one.getUsername().equals(username) && one.getPassword().equals(password)) {
				sucess.set(true);
				request.getSession().setAttribute("AUDIO_USER", username + "_" + password);
			}
		});

		if (sucess.get()) {
			return "demo_main";
		} else {
			return "login";
		}
	}

	
	@GetMapping("/demoA")
	public String doGetDemoA() {
		return "demo_a";	
	}

	
	@GetMapping("/demoB")
	public String doGetDemoB() {
		return "demo_b";	
	}
	

	@GetMapping("/demo")
	public String getAudio() {
		return "audio";
	}

	@GetMapping(value = "/get-image-with-media-type", produces = MediaType.IMAGE_JPEG_VALUE)
	public @ResponseBody byte[] getImageWithMediaType() throws IOException {
		InputStream in = getClass().getResourceAsStream("/com/baeldung/produceimage/image.jpg");
		return IOUtils.toByteArray(in);
	}

}
