CREATE DEFINER=`aimuser`@`%` PROCEDURE `get_seg_catchup_info`(
	IN p_component_type int,
	IN p_seg_diffs VARCHAR(1024)
	)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
mylable:BEGIN
  -- p_seg_diffs= '{segmentId:1000;reportVersion:1;lastVersion:5},{segmentId:1000;reportVersion:1;lastVersion:5},{segmentId:1000;reportVersion:1;lastVersion:5}';
	DECLARE v_idx INT DEFAULT 999;
	DECLARE v_tmp_str VARCHAR(1024);
    DECLARE v_view_str VARCHAR(1024);
	DECLARE v_ch_log_id int(38);
    DECLARE his_count int;
	DECLARE seg_diff varchar(64);
	DECLARE v_segmentId int(38);
	DECLARE v_reportVersion int(38);
	DECLARE v_latestVersion int(38);
	DECLARE t_error integer DEFAULT 0;
	DECLARE not_found integer DEFAULT 0;  	
	DECLARE cur CURSOR FOR
   	SELECT c.SEGMENT_CHANGE_ID
	FROM   SEGMENT_CHANGE_LOG c
	WHERE  SEGMENT_ID = (SELECT d.segmentId
                     FROM   segment_diffs d
                     WHERE  c.SEGMENT_ID = d.segmentId
                            AND c.SEGMENT_VERSION <= d.latestVersion
                            AND c.SEGMENT_VERSION > d.reportVersion)
	ORDER  BY c.SEGMENT_CHANGE_ID,c.SEGMENT_VERSION;
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET not_found = 1;
	DROP TEMPORARY TABLE IF EXISTS history_ids;
	CREATE TEMPORARY TABLE history_ids(id int(38) PRIMARY KEY) ENGINE = MEMORY;   
	DROP TEMPORARY TABLE IF EXISTS segment_diffs;
	CREATE TEMPORARY TABLE segment_diffs (
      segmentId int(38),
      reportVersion int(38),
      latestVersion int(38)
	) ENGINE = MEMORY;
     
	SET  @@autocommit=0;
    IF LENGTH(p_seg_diffs) < 1 THEN
	    LEAVE mylable;
	END IF;
	while_labe: WHILE v_idx > 0 DO
     SET v_idx = INSTR(p_seg_diffs,',');
	IF v_idx <=0 then
         SET v_tmp_str = substr(p_seg_diffs,2,LENGTH(p_seg_diffs)-2);
         BEGIN
            call parseOneSegDiff(v_tmp_str,'segment_diffs', @err);
		 END;            
         LEAVE while_labe;
      END IF;
      SET v_tmp_str = substr(p_seg_diffs,1,v_idx-1); 
	  SET v_tmp_str = substr(v_tmp_str,2,LENGTH(v_tmp_str)-2); 
      BEGIN
        call parseOneSegDiff(v_tmp_str,'segment_diffs', @err);
	  END;
       SET p_seg_diffs=substr(p_seg_diffs,v_idx +1 ,LENGTH(p_seg_diffs));
	END WHILE;
    IF t_error = 1 THEN	 
       LEAVE mylable;
	END IF;    
  
	OPEN cur;
	lable_loop: LOOP
	  FETCH cur INTO v_ch_log_id;
	  IF not_found = 1 THEN
         LEAVE lable_loop;
       END IF;
      INSERT INTO history_ids (id) VALUES( v_ch_log_id);
    END LOOP;
    CLOSE cur; 
    SELECT count(id) INTO his_count FROM history_ids;
    IF t_error = 1 THEN	 
       LEAVE mylable;
	END IF;    
   
	IF (p_component_type = 3) THEN
	SELECT
      scl.SEGMENT_ID,
      scl.BIOMETRICS_ID,
      scl.SEGMENT_VERSION,
      scl.CHANGE_TYPE,
      CASE WHEN scl.CHANGE_TYPE = 1 THEN NULL ELSE pb.BIOMETRIC_DATA END AS BIOMETRIC_DATA,
      pb.EXTERNAL_ID,
      pb.EVENT_ID
	FROM SEGMENT_CHANGE_LOG scl,PERSON_BIOMETRICS pb
	WHERE scl.BIOMETRICS_ID = pb.BIOMETRICS_ID 
	AND scl.SEGMENT_CHANGE_ID IN (SELECT id FROM  history_ids) 
	ORDER BY scl.SEGMENT_ID, scl.SEGMENT_CHANGE_ID; 
  ELSEIF (p_component_type = 1) THEN
    SELECT
       SEGMENT_ID,
       BIOMETRICS_ID,
       SEGMENT_VERSION,
       CHANGE_TYPE,
       NULL AS BIOMETRIC_DATA,
       NULL AS EXTERNAL_ID,
       NULL AS EVENT_ID
     FROM SEGMENT_CHANGE_LOG
     WHERE segment_change_id IN (SELECT id from history_ids)       
     ORDER BY segment_id, segment_change_id;
  END IF;
  IF t_error = 1 THEN
    ROLLBACK;   
  ELSE
    COMMIT;    
  END IF;
  DROP TEMPORARY TABLE IF EXISTS history_ids;
  DROP TEMPORARY TABLE IF EXISTS segment_diffs; 
END