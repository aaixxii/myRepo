package jp.co.nec.aim.mm.extract.dispatch;

import java.math.BigDecimal;
import java.util.Map;
import java.util.concurrent.Future;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.AsyncResult;
import javax.ejb.Asynchronous;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.convert.ConvertException;
import jp.co.nec.aim.convert.WebServiceClassConvert;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobResult;
import jp.co.nec.aim.mm.constants.CallbackStyle;
import jp.co.nec.aim.mm.constants.JobCallbackSender;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.exception.HttpPostException;
import jp.co.nec.aim.mm.jaxb.ExtractJobResult;
import jp.co.nec.aim.mm.util.HttpPoster;
import jp.co.nec.aim.mm.util.JAXBHelper;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * callback to client to send extract job results
 * 
 * @author xiazp
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class ExtractJobResultCallBacker {
	private static Logger log = LoggerFactory
			.getLogger(ExtractJobResultCallBacker.class);
	private static final String URL_SQL = "select CALLBACK_URL, CALLBACK_STYLE from FE_JOB_QUEUE where JOB_ID=?";
	private static final String UNKNOWN = "unknown";

	private SystemConfigDao configDao;
	private JAXBHelper jaxbHelper;
	private JdbcTemplate jdbcTemplate;
	/** the common of Class Converter **/
	private WebServiceClassConvert convert;

	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;

	@PostConstruct
	public void init() {
		jaxbHelper = new JAXBHelper();
		jdbcTemplate = new JdbcTemplate(dataSource);
		convert = new WebServiceClassConvert();
		configDao = new SystemConfigDao(manager);
	}

	@Asynchronous
	public Future<Boolean> asynchCallback(String url, int muPostRetryCount,
			String response) {
		ExtractRequestPoster poster = new ExtractRequestPoster();
		return new AsyncResult<Boolean>(poster.postRequest(url,
				muPostRetryCount, response));
	}

	@Asynchronous
	public Future<Boolean> asynchCallback(String url, int muPostRetyCount,
			byte[] results) {
		ExtractRequestPoster poster = new ExtractRequestPoster();
		return new AsyncResult<Boolean>(poster.postRequest(url,
				muPostRetyCount, results));
	}

	/**
	 * asynchCallback
	 * 
	 * @param jobId
	 * @param result
	 */
	@Asynchronous
	public void asynchCallback(long jobId, PBExtractJobResult result) {
		String url = UNKNOWN;
		try {
			log.info("asynchCallback Extract job {}", jobId);

			Map<String, Object> callback = jdbcTemplate.queryForMap(URL_SQL,
					new Long(jobId));
			Object objCallBack = callback.get("CALLBACK_URL");
			if (objCallBack == null) {
				return;
			}

			String callbackURL = objCallBack.toString();

			int callbackStyle = ((BigDecimal) callback.get("CALLBACK_STYLE"))
					.intValue();
			final int retryCount = configDao
					.getMMPropertyInt(MMConfigProperty.CLIENT_POST_COUNT);

			if (StringUtils.isNotBlank(callbackURL)) {
				url = JobCallbackSender.generateURL(callbackURL, jobId);
				if (callbackStyle == CallbackStyle.PROTOBUF.getStyle()) {
					HttpPoster.post(url, result.toByteArray(), retryCount);
				} else {
					String resultXml = convetToXML(result);
					HttpPoster.post(url, resultXml, retryCount);
				}
				log.info("Finished sending Extract job({}) callback to {}.", jobId, callbackURL);
			}else{
				log.info("Skipped sending Extract job({}) callback due to callback url wasn't specified from client.");
			}
		} catch (HttpPostException e) {
			String errorMessage = String.format(
					"HttpPostException while attempting Extract job(%s) callback to '%s'.", jobId, url);
			log.error(errorMessage, e);
			throw new AimRuntimeException(e.getMessage(), e);
		}
	}

	private String convetToXML(PBExtractJobResult pbResult) {
		try {
			ExtractJobResult fdJobResult = convert.toExtractJobResult(pbResult);
			String xmlResult = jaxbHelper.marshal(fdJobResult);
			return xmlResult;
		} catch (ConvertException e) {
			log.error(e.getMessage(), e);
			throw new AimRuntimeException(e.getMessage(), e);
		}
	}
}
