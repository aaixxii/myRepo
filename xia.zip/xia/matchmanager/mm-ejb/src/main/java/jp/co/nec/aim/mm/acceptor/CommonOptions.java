package jp.co.nec.aim.mm.acceptor;

/**
 * 
 * @author liuyq
 * 
 */
public class CommonOptions {
	private Integer priority;
	private String callbackURL;
	private Integer maxCandidates;
	// private Integer minScore;
	private Boolean multiRecordCandidates;
	private Float dynThreshPercentagePoint;
	private Integer dynThreshHitThreshold;
	private boolean isFromServlet;
	private String functioName;

	public Integer getMaxCandidates() {
		return maxCandidates;
	}

	public void setMaxCandidates(Integer maxCandidates) {
		this.maxCandidates = maxCandidates;
	}

	// public Integer getMinScore() {
	// return minScore;
	// }
	//
	// public void setMinScore(Integer minScore) {
	// this.minScore = minScore;
	// }

	public String getCallbackURL() {
		return callbackURL;
	}

	public void setCallbackURL(String callbackURL) {
		this.callbackURL = callbackURL;
	}

	public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	public Boolean getMultiRecordCandidates() {
		return multiRecordCandidates;
	}

	public void setMultiRecordCandidates(Boolean multiRecordCandidates) {
		this.multiRecordCandidates = multiRecordCandidates;
	}

	public Float getDynThreshPercentagePoint() {
		return dynThreshPercentagePoint;
	}

	public void setDynThreshPercentagePoint(Float dynThreshPercentagePoint) {
		this.dynThreshPercentagePoint = dynThreshPercentagePoint;
	}

	public Integer getDynThreshHitThreshold() {
		return dynThreshHitThreshold;
	}

	public void setDynThreshHitThreshold(Integer dynThreshHitThreshold) {
		this.dynThreshHitThreshold = dynThreshHitThreshold;
	}

	public boolean isFromServlet() {
		return isFromServlet;
	}

	public void setFromServlet(boolean isFromServlet) {
		this.isFromServlet = isFromServlet;
	}

	public String getFunctioName() {
		return functioName;
	}

	public void setFunctioName(String functioName) {
		this.functioName = functioName;
	}

}
