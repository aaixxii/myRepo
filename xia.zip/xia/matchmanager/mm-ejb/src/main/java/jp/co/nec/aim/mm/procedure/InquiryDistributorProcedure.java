package jp.co.nec.aim.mm.procedure;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.mm.identify.dispatch.InqDispatchInfo;
import jp.co.nec.aim.mm.util.CollectionsUtil;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

/**
 * InquiryDistributorProcedure
 * 
 * @author liuyq
 * 
 */
public class InquiryDistributorProcedure extends StoredProcedure {

	private static final String SQL = "MATCH_MANAGER_API.GET_INQUIRY_DISTRIBUTOR_INFO";
	private Long planId;
	private Long jobId;
	private Integer functionId;

	/**
	 * InquiryDistributorProcedure
	 * 
	 * @param dataSource
	 */
	public InquiryDistributorProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(SQL);
//		declareParameter(new SqlOutParameter("p_refcursor", OracleTypes.CURSOR,
//				new CursorMapper()));
		declareParameter(new SqlParameter("p_job_id", Types.BIGINT, "NUMBER"));
		declareParameter(new SqlParameter("p_function_id", Types.BIGINT,
				"NUMBER"));
		declareParameter(new SqlParameter("p_plan_id", Types.BIGINT, "NUMBER"));
		compile();
	}

	/**
	 * execute
	 * 
	 * @return InqDistributorInfo instance
	 */
	public InqDispatchInfo execute() {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_job_id", getJobId());
		map.put("p_function_id", getFunctionId());
		map.put("p_plan_id", getPlanId());

		Map<String, Object> resultMap = execute(map);
		@SuppressWarnings("unchecked")
		List<InqDispatchInfo> list = (List<InqDispatchInfo>) resultMap
				.get("p_refcursor");
		if (CollectionsUtil.isEmpty(list)) {
			return null;
		} else {
			return CollectionsUtil.getFirst(list);
		}
	}

	public Long getJobId() {
		return jobId;
	}

	public void setJobId(Long jobId) {
		this.jobId = jobId;
	}

	public Long getPlanId() {
		return planId;
	}

	public void setPlanId(Long planId) {
		this.planId = planId;
	}

	public Integer getFunctionId() {
		return functionId;
	}

	public void setFunctionId(Integer functionId) {
		this.functionId = functionId;
	}

	/**
	 * CursorMapper
	 * 
	 * @author liuyq
	 * 
	 */
	private class CursorMapper implements RowMapper<InqDispatchInfo> {
		@Override
		public InqDispatchInfo mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			final InqDispatchInfo info = new InqDispatchInfo();
			info.setMessageSequence(rs.getInt("failure_count"));
			info.setRequestIndex(rs.getInt("search_request_index"));
			info.setInquiryData(rs.getBytes("inquiry_job_data"));
			info.setJobTimeout(rs.getLong("container_job_timeouts"));
			info.setInternalMaxCandidates(rs.getInt("internal_candidate_size"));
			info.setContainerJobId(rs.getInt("container_job_id"));
			return info;

		}
	}

}
