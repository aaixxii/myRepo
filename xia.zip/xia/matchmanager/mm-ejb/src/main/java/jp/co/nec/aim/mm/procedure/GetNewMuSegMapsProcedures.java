package jp.co.nec.aim.mm.procedure;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import jp.co.nec.aim.mm.identify.planner.MuSegmentMap;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

/**
 * 
 * @author xiazp
 *
 */
public class GetNewMuSegMapsProcedures extends StoredProcedure {
	private static final String GET_NEW_MU_SEG_MAPS = "MATCH_MANAGER_API.get_new_mu_seg_maps";

	public GetNewMuSegMapsProcedures(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(GET_NEW_MU_SEG_MAPS);
		declareParameter(new SqlParameter("p_container_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_function_id", Types.BIGINT));
//		declareParameter(new SqlOutParameter("p_refcursor", OracleTypes.CURSOR,
//				new CursorMapper()));
		compile();
	}

	/**
	 * 
	 * @param containerId
	 * @param fuctionId
	 * @return
	 * @throws DataAccessException
	 * @throws SQLException
	 */
	@SuppressWarnings("unchecked")
	public List<MuSegmentMap> getNewMuSegMaps(Integer containerId,
			Integer fuctionId) throws DataAccessException, SQLException {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_container_id", containerId);
		map.put("p_function_id", fuctionId);
		Map<String, Object> resultMap = execute(map);
		if (resultMap.values().toString().equals("[[]]")) {
			return null;
		}
		List<MuSegmentMap> newMuMaps = (List<MuSegmentMap>) resultMap
				.get("p_refcursor");
		return newMuMaps;
	}

	/**
	 * 
	 * @author xiazp
	 *
	 */
	private class CursorMapper implements RowMapper<MuSegmentMap> {
		@Override
		public MuSegmentMap mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			MuSegmentMap msMap = new MuSegmentMap();
			msMap.setContainerId(rs.getInt("container_id"));
			msMap.setMuId(rs.getInt("mu_id"));
			msMap.setSegmentId(rs.getLong("segment_id"));
			msMap.setSegmentVersion(rs.getLong("segment_version"));
			msMap.setFunctionId(rs.getInt("function_id"));
			return msMap;
		}
	}
}
