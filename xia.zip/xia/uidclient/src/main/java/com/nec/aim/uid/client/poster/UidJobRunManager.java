package com.nec.aim.uid.client.poster;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class UidJobRunManager {
	private static Logger logger = LoggerFactory.getLogger("HttpPost");
	private  final static UidJobRunManager INSTANCE = new UidJobRunManager();
	private static AtomicBoolean mustRun;
	private ExecutorService uidJobExecutor;
	private ExecutorService resultWriteExecutor;
	// saved reuqest prameter file for create
	private static BlockingQueue<String> uidJobQueue;
	private static List<String> pendingQueue = Collections.synchronizedList(new ArrayList<>());

	public UidJobRunManager() {
		uidJobExecutor = Executors.newCachedThreadPool();
		resultWriteExecutor = Executors.newCachedThreadPool();				
	}
	
	public  void init(int currCount) {
		uidJobQueue = new ArrayBlockingQueue<>(currCount);
		mustRun = new AtomicBoolean(true);
	}

	public static UidJobRunManager getInstance() {
		return INSTANCE;
	}

	public void addJobtoMe(List<String> paramterFiles) {
		paramterFiles.forEach(one -> {
			if (!uidJobQueue.offer(one)) {
				pendingQueue.add(one);
				logger.info("added requst setting file:{}", one);
			}
		});
	}

	public void run() {
		while (mustRun.get()) {
			if (pendingQueue.size() > 0) {
				int removeAbleCount = Math.min(pendingQueue.size(), uidJobQueue.remainingCapacity());
				if (removeAbleCount < 1)
					continue;
				for (int i = 0; i < removeAbleCount; i++) {
					uidJobQueue.offer(pendingQueue.remove(i));
				}
			}
			try {
				String path = uidJobQueue.poll(100, TimeUnit.MILLISECONDS);
				if (path != null) {
					if (path.contains("extract"))  {
						ExtractJobPoster postTask = new ExtractJobPoster(path);
						this.commitPostJobTask(postTask);
					} else if (path.contains("identify")) {
						IdentifyJobPoster postTask = new IdentifyJobPoster(path);
						this.commitPostJobTask(postTask);
					} else if (path.contains("sync")) {
						SyncJobPoster syncTask = new SyncJobPoster(path); 
						this.commitPostJobTask(syncTask);
					}					
				}
				Thread.sleep(300);
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		}
	}

	public boolean isMustRun() {
		return mustRun.get();
	}

	public void setMustRun(boolean newMustRun) {
		mustRun.set(newMustRun);
	}

	public void commitPostJobTask(Runnable task) {
		uidJobExecutor.submit(task);
	}

	public void commitWriteTask(Runnable task) {
		resultWriteExecutor.submit(task);
	}
	
	public void shutdown () {
		setMustRun(false);
		uidJobExecutor.shutdown();
		resultWriteExecutor.shutdown();
		uidJobQueue.clear();
		pendingQueue.clear();
	}
}
