package com.nec.aim.uid.client.result.writer;

import static com.nec.aim.uid.client.common.UidClientConstants.JOB_REQUEST_PATH;

import java.io.FileWriter;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.aim.uid.client.manager.UidCommonManager;

import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.ExtractService.ExtractResponse;

public class ExtractResultWriter implements Runnable {
	private static Logger logger = LoggerFactory.getLogger(ExtractResultWriter.class);
	private ExtractResponse.Builder extractResponse;

	public ExtractResultWriter(ExtractResponse.Builder extRes) {
		this.extractResponse = extRes;
	}

	@Override
	public void run() {
		String outPutPath = UidCommonManager.getValue(JOB_REQUEST_PATH);
		outPutPath = outPutPath.endsWith("/") ? outPutPath : outPutPath + "/";
		outPutPath = outPutPath + "/" + extractResponse.getBatchJobId();
		try (FileWriter writer = new FileWriter(outPutPath)) {
			writer.write("batchJobId: " + String.valueOf(extractResponse.getBatchJobId()));
			writer.write(System.lineSeparator());
			writer.append("type: " + String.valueOf(extractResponse.getType()));
			writer.write(System.lineSeparator());
			PBBusinessMessage pbmsg = PBBusinessMessage.parseFrom(extractResponse.getBusinessMessage(0));
			writer.append(pbmsg.toString());
			logger.info("success writed batchjob({}) result", extractResponse.getBatchJobId());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
