package com.nec.aim.uid.client.monitor;

import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.aim.uid.client.poster.UidJobRunManager;


public class DirectoryMonitor {
	private static Logger logger = LoggerFactory.getLogger(DirectoryMonitor.class);
	private String monitorPath;
	private AtomicBoolean stop = new AtomicBoolean(false);
	public DirectoryMonitor(String watchPath) {
		this.monitorPath = watchPath;		
	}
	
	
	public  void watch() {		  
		try {		
			logger.info("begin nomitor directory:{}", monitorPath);
			 Path path=Paths.get(monitorPath);
			 WatchService watchService= FileSystems.getDefault().newWatchService();
			 path.register(watchService,StandardWatchEventKinds.ENTRY_CREATE,StandardWatchEventKinds.ENTRY_MODIFY);	
			 List<String> newFiles = new ArrayList<>();
			 while (!stop.get()) {
				 WatchKey watchKey = watchService.poll(100, TimeUnit.MILLISECONDS);
				watchKey.pollEvents().forEach( event -> {
					String newPath  = (String)event.context();
					if (newPath != null) {
						newFiles.add(newPath);	
						logger.info("found new file:{}!", newPath);
					}
									
					if (newFiles.size() > 0) {
						UidJobRunManager.getInstance().addJobtoMe(newFiles);
						newFiles.clear();
					}
				});
				watchKey.reset();
				Thread.sleep(1000);
			 }
		} catch (Exception e) {
			logger.warn(e.getMessage());
		}		
		
	}
	
	public void setStop(boolean action) {
		stop.set(action);
	}
}
