package com.nec.aim.uid.client.result.writer;

import static com.nec.aim.uid.client.common.UidClientConstants.JOB_REQUEST_PATH;

import java.io.FileWriter;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.aim.uid.client.manager.UidCommonManager;

import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.SyncService.SyncResponse;

public class SyncResultWriter implements Runnable {
	private static Logger logger = LoggerFactory.getLogger(SyncResultWriter.class);
	private SyncResponse.Builder syncResponse;

	public SyncResultWriter(SyncResponse.Builder syncRes) {
		this.syncResponse = syncRes;
	}

	@Override
	public void run() {
		String outPutPath = UidCommonManager.getValue(JOB_REQUEST_PATH);
		outPutPath = outPutPath.endsWith("/") ? outPutPath : outPutPath + "/";
		outPutPath = outPutPath + "/" + syncResponse.getBatchJobId();
		try (FileWriter writer = new FileWriter(outPutPath)) {
			writer.write("batchJobId: " + String.valueOf(syncResponse.getBatchJobId()));
			writer.write(System.lineSeparator());
			writer.append("type: " + String.valueOf(syncResponse.getType()));
			writer.write(System.lineSeparator());
			PBBusinessMessage pbmsg = PBBusinessMessage.parseFrom(syncResponse.getBusinessMessage(0));
			writer.append(pbmsg.toString());
			logger.info("success writed batchjob({}) result", syncResponse.getBatchJobId());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
