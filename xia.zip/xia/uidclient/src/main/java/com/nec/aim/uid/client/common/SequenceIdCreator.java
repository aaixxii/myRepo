package com.nec.aim.uid.client.common;
import java.util.concurrent.atomic.AtomicLong;

public class SequenceIdCreator {
	private static AtomicLong lastBatchJobId = new AtomicLong(0);
	private static AtomicLong lastEnrollmentId = new AtomicLong(0);
	private static AtomicLong lastReqeustId = new AtomicLong(0);
	
	
	public static synchronized String createNextSequence(SequenceIdType type) {
		long value = 0;
		switch (type){
		case BATCHJOB_ID:
			value  = lastBatchJobId.incrementAndGet();	
			  return  String.valueOf(value);			
		case ENROLLMENT_ID:
			value = lastEnrollmentId.incrementAndGet();
			 String enrollValue = "ERO_" + String.format("%032d", value);			 
			 return enrollValue;
		case REQUST_ID:
			value = lastReqeustId.incrementAndGet();
			 String reqValue = "REQ_" + String.format("%032d", value);			
			return reqValue;	
		 default:
			 return "-1";
		}
		
	}
}
