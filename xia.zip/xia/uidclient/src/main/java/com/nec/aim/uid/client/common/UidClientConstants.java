package com.nec.aim.uid.client.common;

public class UidClientConstants {
	
	public static final String COMMON_PROPERTY_FULL_NAME = "uid.common.properties";	 //fullName with path
	public static final String EXTRACT_JOB_SETING_FILE_FULL_NAME = "extractJobRequestFullName";
	public static final String IDENDIFY_JOB_SETING_FILE_FULL_NAME = "idendityJobRequestFullName";
	public static final String SYNC_JOB_SETING_FILE_FULL_NAME = "syncJobRequestFullName";
	
	public static final String JOB_REQUEST_PATH = "jobReqeustPath";	
	public static final String JOB_TEMPLATES_PATH = "jobTemplatesPath";		
	public static final String JOB_RESULT_PATH = "jobresultPath";
	
	public static final String MM_IP = "mmIp";	
	public static final String MM_PORT = "mmPort";
	public static final String MM_WEB_CONTENT = "mmWebContent";	
	public static final String MM_BASE_URL ="mmBaseUrl";	
	public static final String DEFALUT_MM_BASE_URL="defalutMMBaseUrl";	
	public static final String  PICKUP_MM_ALGORITHM = "pickUpMmAlg";
	public static final String  CONCURRENT_THEAD_COUNT = "concurrentThreadCount";
	
	public static final String UID_SYNC_URL = "/AIMSyncService/sync";
	
	public static final String UID_INQUIRY_URL = "/AIMInquiryService/inquiry";
	public static final String UID_INQUIRY_DEL_URL = "/AIMInquiryService/deleteJob";
	public static final String UID_INQUIRY_CLEAR_URL = "/AIMInquiryService/clearJobs";
	
	public static final String UID_EXTRACT_URL = "/AIMExtractService/extract";	
	public static final String UID_EXTRACT_DEL_URL = "/AIMExtractService/deleteJob";
	public static final String UID_EXTRACT_CLEAR_URL = "/AIMExtractService/clearJobs";
	
	public static final String UID_MR_JOB_POST_URL = "/mapreducer/MapInquiryJob";
	public static final String UID_MU_JOB_POST_URL = "/matchunit/ExtractJob";
	
	
	
	public static final String UID_xxx = "/AIMSyncService/sync";	
	
	public static final String SLASH = "/";
	
	public static final String REQUEST_PARAMETER_INFO_FIRST_SEPARATOR = ",";
	public static final String REQUEST_PARAMETER_INFO_SECOND_SEPARATOR = ":";
	


}
