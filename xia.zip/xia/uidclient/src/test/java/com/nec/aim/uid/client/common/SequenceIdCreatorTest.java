package com.nec.aim.uid.client.common;

import static org.junit.Assert.*;

import java.text.NumberFormat;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class SequenceIdCreatorTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCreateNextSequence() {
		 NumberFormat nfNum = NumberFormat.getNumberInstance();
		 nfNum.setMinimumIntegerDigits(64);
		 nfNum.setGroupingUsed(false);
		
		 System.out.println(nfNum.format(2L));
		
		String batchJobIdStr =  SequenceIdCreator.createNextSequence(SequenceIdType.BATCHJOB_ID);
		Long batchJobId = Long.valueOf(batchJobIdStr);
		System.out.println(batchJobId);
		batchJobIdStr =  SequenceIdCreator.createNextSequence(SequenceIdType.BATCHJOB_ID);
		batchJobId = Long.valueOf(batchJobIdStr);
		System.out.println(batchJobId);
		batchJobIdStr =  SequenceIdCreator.createNextSequence(SequenceIdType.BATCHJOB_ID);
		batchJobId = Long.valueOf(batchJobIdStr);
		System.out.println(batchJobId);
		String erollId = (String) SequenceIdCreator.createNextSequence(SequenceIdType.ENROLLMENT_ID);
		erollId = (String) SequenceIdCreator.createNextSequence(SequenceIdType.ENROLLMENT_ID);
		System.out.println(erollId);
		erollId = (String) SequenceIdCreator.createNextSequence(SequenceIdType.ENROLLMENT_ID);
		System.out.println(erollId);
		erollId = (String) SequenceIdCreator.createNextSequence(SequenceIdType.ENROLLMENT_ID);
		System.out.println(erollId);
		String reqId = (String) SequenceIdCreator.createNextSequence(SequenceIdType.REQUST_ID);
	    reqId = (String) SequenceIdCreator.createNextSequence(SequenceIdType.REQUST_ID);
	    System.out.println(reqId);
	    reqId = (String) SequenceIdCreator.createNextSequence(SequenceIdType.REQUST_ID);
	    System.out.println(reqId);
	    reqId = (String) SequenceIdCreator.createNextSequence(SequenceIdType.REQUST_ID);
	    System.out.println(reqId);		
		
		
		
		
		
	}

}
