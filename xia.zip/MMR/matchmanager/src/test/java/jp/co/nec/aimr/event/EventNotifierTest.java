package jp.co.nec.aimr.event;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import jp.co.nec.aimr.common.UnitCard;
import jp.co.nec.aimr.common.UnitStatus;
import jp.co.nec.aimr.common.UnitType;
import jp.co.nec.aimr.management.AIMrManger;
import jp.co.nec.aimr.matchunit.UnitMessageSender;
import jp.co.nec.aimr.persistence.aimdb.ContainerInfo;
import mockit.Mock;
import mockit.MockUp;

public class EventNotifierTest {
	private MockUp<AIMrManger> aIMrMangerMock;

	@SuppressWarnings("unchecked")
	@Before
	public void setUp() throws Exception {
		aIMrMangerMock =
				new MockUp<AIMrManger>() {
			@Mock
			private void init() {
				return;
			}
			@Mock
			public  List<ContainerInfo> getMuEliginbleConatainerInfo(Long muId) {
				List<ContainerInfo> infos = new ArrayList<>();
				ContainerInfo info = new ContainerInfo();
				info.setContainerId(1);
				info.setPersonBiTtableName("");
				info.setConatainerLogTableName("");
			
				infos.add(info);
				return infos;
			}
		};
		Class<EventNotifier> cls = EventNotifier.class;
		Field field = cls.getDeclaredField("lastSelectEu");
		field.setAccessible(true);
		field.set(EventNotifier.getInstance(), new AtomicInteger(-1));
		
		Field field1 = cls.getDeclaredField("lastSelectMu");
		field1.setAccessible(true);
		field.set(EventNotifier.getInstance(), new AtomicInteger(-1));
		
		Field field2 = cls.getDeclaredField("euSenderListenerList");
		field2.setAccessible(true);
		CopyOnWriteArrayList<EventListener> listEu = ((CopyOnWriteArrayList<EventListener>) field2.get(EventNotifier.getInstance()));
		listEu.clear();
		
		Field field3 = cls.getDeclaredField("muSenderListenerList");
		field3.setAccessible(true);
		CopyOnWriteArrayList<EventListener> listMu = ((CopyOnWriteArrayList<EventListener>) field3.get(EventNotifier.getInstance()));
		listMu.clear();
		
		Field field4 = cls.getDeclaredField("systemListenerQueue");
		field4.setAccessible(true);
		CopyOnWriteArrayList<EventListener> listSys = ((CopyOnWriteArrayList<EventListener>) field4.get(EventNotifier.getInstance()));
		listSys.clear();		
	}

	@After
	public void tearDown() throws Exception {
		aIMrMangerMock.tearDown();
	}

	@Test
	public void testGetInstance() {
		Assert.assertNotNull(EventNotifier.getInstance());
		Assert.assertTrue(EventNotifier.getInstance() instanceof EventNotifier);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testAddSystemListener() throws InstantiationException, IllegalAccessException, NoSuchFieldException, SecurityException {
		EventListener listener = new EventAdapter();
		EventNotifier.getInstance().addSystemListener(listener);
		Class<EventNotifier> cls = EventNotifier.class;
		Field field = cls.getDeclaredField("systemListenerQueue");
		field.setAccessible(true);
		CopyOnWriteArrayList<EventListener> copyOnWriteArrayList = (CopyOnWriteArrayList<EventListener>) field.get(EventNotifier.getInstance());
		Assert.assertEquals(1, copyOnWriteArrayList.size());
		copyOnWriteArrayList.clear();
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testAddEuSenderListenerList() throws InstantiationException, IllegalAccessException, NoSuchFieldException, SecurityException {
		EventListener listener = new EventAdapter();
		EventNotifier.getInstance().addEuSenderListener(listener);
		Class<EventNotifier> cls = EventNotifier.class;
		Field field = cls.getDeclaredField("euSenderListenerList");
		field.setAccessible(true);
		CopyOnWriteArrayList<EventListener> copyOnWriteArrayList = (CopyOnWriteArrayList<EventListener>) field.get(EventNotifier.getInstance());
		Assert.assertEquals(1, copyOnWriteArrayList.size());
		copyOnWriteArrayList.clear();
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testAddMuSenderListenerList() throws InstantiationException, IllegalAccessException, NoSuchFieldException, SecurityException {
		EventListener listener = new EventAdapter();
		EventNotifier.getInstance().addMuSenderListener(listener);
		Class<EventNotifier> cls = EventNotifier.class;
		Field field = cls.getDeclaredField("muSenderListenerList");
		field.setAccessible(true);
		CopyOnWriteArrayList<EventListener> copyOnWriteArrayList = (CopyOnWriteArrayList<EventListener>) field.get(EventNotifier.getInstance());
		Assert.assertEquals(1, copyOnWriteArrayList.size());
		copyOnWriteArrayList.clear();
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testRemoveSystemListener() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		EventListener listener = new EventAdapter();
		EventNotifier.getInstance().addSystemListener(listener);
		Class<EventNotifier> cls = EventNotifier.class;
		Field field = cls.getDeclaredField("systemListenerQueue");
		field.setAccessible(true);
		CopyOnWriteArrayList<EventListener> copyOnWriteArrayList = (CopyOnWriteArrayList<EventListener>) field.get(EventNotifier.getInstance());
		Assert.assertEquals(1, copyOnWriteArrayList.size());
		EventNotifier.getInstance().removeSystemListener(listener);
		Assert.assertEquals(0, copyOnWriteArrayList.size());
		copyOnWriteArrayList.clear();
	}
	

	@SuppressWarnings("unchecked")
	@Test
	public void testRemoveMuSenderListener() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		EventListener listener = new EventAdapter();
		EventNotifier.getInstance().addMuSenderListener(listener);
		Class<EventNotifier> cls = EventNotifier.class;
		Field field = cls.getDeclaredField("muSenderListenerList");
		field.setAccessible(true);
		CopyOnWriteArrayList<EventListener> copyOnWriteArrayList = (CopyOnWriteArrayList<EventListener>) field.get(EventNotifier.getInstance());
		Assert.assertEquals(1, copyOnWriteArrayList.size());
		EventNotifier.getInstance().removeMuSenderListener(listener);
		Assert.assertEquals(0, copyOnWriteArrayList.size());
		copyOnWriteArrayList.clear();
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testRemoveEuSenderListener() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		EventListener listener = new EventAdapter();
		EventNotifier.getInstance().addEuSenderListener(listener);
		Class<EventNotifier> cls = EventNotifier.class;
		Field field = cls.getDeclaredField("euSenderListenerList");
		field.setAccessible(true);
		CopyOnWriteArrayList<EventListener> copyOnWriteArrayList = (CopyOnWriteArrayList<EventListener>) field.get(EventNotifier.getInstance());
		Assert.assertEquals(1, copyOnWriteArrayList.size());
		EventNotifier.getInstance().removeEuSenderListener(listener);
		Assert.assertEquals(0, copyOnWriteArrayList.size());
		copyOnWriteArrayList.clear();
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testCaculateNextEu() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		int size = 5;
		for (int i = 0 ; i < size; i++) {
			UnitCard unitCard = new UnitCard();
			unitCard.setUnitId(Long.valueOf(i + 1));
			unitCard.setUnitType(UnitType.EXTRACTOR);
			unitCard.setStatus(UnitStatus.ready);
			UnitMessageSender sender = new UnitMessageSender(unitCard);
			EventNotifier.getInstance().addEuSenderListener(sender);
		}
		Class<EventNotifier> cls = EventNotifier.class;
		Field field = cls.getDeclaredField("lastSelectEu");
		field.setAccessible(true);
		field.set(EventNotifier.getInstance(), new AtomicInteger(-1));
		for (int i = 0 ; i < size - 1; i++) {
			EventNotifier.getInstance().caculateNextEu();
			int result = ((AtomicInteger)field.get(EventNotifier.getInstance())).intValue();
			Assert.assertEquals(i, result);
		}
		
		Field field1 = cls.getDeclaredField("euSenderListenerList");
		field1.setAccessible(true);
		CopyOnWriteArrayList<EventListener> copyOnWriteArrayList2 = (CopyOnWriteArrayList<EventListener>) field1.get(EventNotifier.getInstance());		
		copyOnWriteArrayList2.clear();		
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testCaculateNextEu_maxSize() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		int size = 5;
		for (int i = 0 ; i < size; i++) {
			UnitCard unitCard = new UnitCard();
			unitCard.setUnitId(Long.valueOf(i + 1));
			unitCard.setUnitType(UnitType.EXTRACTOR);
			unitCard.setStatus(UnitStatus.ready);
			UnitMessageSender sender = new UnitMessageSender(unitCard);
			EventNotifier.getInstance().addEuSenderListener(sender);
		}
		Class<EventNotifier> cls = EventNotifier.class;
		Field field = cls.getDeclaredField("lastSelectEu");
		field.setAccessible(true);
		field.set(EventNotifier.getInstance(), new AtomicInteger(4));	
		
		EventNotifier.getInstance().caculateNextEu();
		int lastResult = ((AtomicInteger)field.get(EventNotifier.getInstance())).intValue();
		Assert.assertEquals(0, lastResult);
		Field field1 = cls.getDeclaredField("euSenderListenerList");
		field1.setAccessible(true);
		CopyOnWriteArrayList<EventListener> copyOnWriteArrayList2 = (CopyOnWriteArrayList<EventListener>) field1.get(EventNotifier.getInstance());		
		copyOnWriteArrayList2.clear();
		
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testCaculateNextEu_have_notReady() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		int size = 5;
		for (int i = 0 ; i < size; i++) {
			UnitCard unitCard = new UnitCard();
			unitCard.setUnitId(Long.valueOf(i + 1));
			unitCard.setUnitType(UnitType.EXTRACTOR);
			if (i == 3) {
				unitCard.setStatus(UnitStatus.connected);	
			} else {
				unitCard.setStatus(UnitStatus.ready);
			}
			
			UnitMessageSender sender = new UnitMessageSender(unitCard);
			EventNotifier.getInstance().addEuSenderListener(sender);
		}
		Class<EventNotifier> cls = EventNotifier.class;
		Field field = cls.getDeclaredField("lastSelectEu");
		field.setAccessible(true);
		field.set(EventNotifier.getInstance(), new AtomicInteger(-1));
		for (int i = 0 ; i < size - 2; i++) {
			EventNotifier.getInstance().caculateNextEu();
			int result = ((AtomicInteger)field.get(EventNotifier.getInstance())).intValue();
			Assert.assertEquals(i, result);
		}
		
		Field field1 = cls.getDeclaredField("euSenderListenerList");
		field1.setAccessible(true);
		CopyOnWriteArrayList<EventListener> copyOnWriteArrayList2 = (CopyOnWriteArrayList<EventListener>) field1.get(EventNotifier.getInstance());		
		copyOnWriteArrayList2.clear();
	}
	
	@Test
	public void testCaculateNextEu_size_init_zero() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {

		Class<EventNotifier> cls = EventNotifier.class;
		Field field = cls.getDeclaredField("lastSelectEu");
		field.setAccessible(true);
	
		EventNotifier.getInstance().caculateNextEu();
		int result = ((AtomicInteger) field.get(EventNotifier.getInstance())).intValue();
		Assert.assertEquals(-1, result);
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testCaculateNextEu_size_zero() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		int size = 5;
		for (int i = 0; i < size; i++) {
			UnitCard unitCard = new UnitCard();
			unitCard.setUnitId(Long.valueOf(i + 1));
			unitCard.setUnitType(UnitType.EXTRACTOR);
			unitCard.setStatus(UnitStatus.ready);
			UnitMessageSender sender = new UnitMessageSender(unitCard);
			EventNotifier.getInstance().addEuSenderListener(sender);
		}
		
		EventNotifier.getInstance().caculateNextEu();

		Class<EventNotifier> cls = EventNotifier.class;
		Field field = cls.getDeclaredField("lastSelectEu");
		field.setAccessible(true);		

		Field field1 = cls.getDeclaredField("euSenderListenerList");
		field1.setAccessible(true);
		CopyOnWriteArrayList<EventListener> list = ((CopyOnWriteArrayList<EventListener>) field1.get(EventNotifier.getInstance()));
		list.clear();
		Assert.assertEquals(0, list.size());
		EventNotifier.getInstance().caculateNextEu();
		int result = ((AtomicInteger) field.get(EventNotifier.getInstance())).intValue();
		Assert.assertEquals(-1, result);
		list.clear();
	}	
	
	@SuppressWarnings("unchecked")
	@Test
	public void testCaculateNextMu() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		int size = 5;
		for (int i = 0 ; i < size; i++) {
			UnitCard unitCard = new UnitCard();
			unitCard.setUnitId(Long.valueOf(i + 1));
			unitCard.setUnitType(UnitType.MATCHER);
			unitCard.setStatus(UnitStatus.ready);
			UnitMessageSender sender = new UnitMessageSender(unitCard);
			EventNotifier.getInstance().addMuSenderListener(sender);
		}
		Class<EventNotifier> cls = EventNotifier.class;
		Field field = cls.getDeclaredField("lastSelectMu");
		field.setAccessible(true);
		field.set(EventNotifier.getInstance(), new AtomicInteger(-1));
		for (int i = 0 ; i < size - 1; i++) {
			EventNotifier.getInstance().caculateNextMu(1);
			int result = ((AtomicInteger)field.get(EventNotifier.getInstance())).intValue();
			Assert.assertEquals(i, result);
		}		
		Field field1 = cls.getDeclaredField("muSenderListenerList");
		field1.setAccessible(true);
		CopyOnWriteArrayList<EventListener> copyOnWriteArrayList = (CopyOnWriteArrayList<EventListener>) field1.get(EventNotifier.getInstance());
		copyOnWriteArrayList.clear();			
		
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testCaculateNextMu_maxSize() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		int size = 5;
		for (int i = 0 ; i < size; i++) {
			UnitCard unitCard = new UnitCard();
			unitCard.setUnitId(Long.valueOf(i + 1));
			unitCard.setUnitType(UnitType.MATCHER);
			unitCard.setStatus(UnitStatus.ready);
			UnitMessageSender sender = new UnitMessageSender(unitCard);
			EventNotifier.getInstance().addMuSenderListener(sender);
		}
		Class<EventNotifier> cls = EventNotifier.class;
		Field field = cls.getDeclaredField("lastSelectMu");
		field.setAccessible(true);
		field.set(EventNotifier.getInstance(), new AtomicInteger(4));	
		
		EventNotifier.getInstance().caculateNextMu(1);
		int lastResult = ((AtomicInteger)field.get(EventNotifier.getInstance())).intValue();
		Assert.assertEquals(0, lastResult);
		Field field1 = cls.getDeclaredField("muSenderListenerList");
		field1.setAccessible(true);
		CopyOnWriteArrayList<EventListener> copyOnWriteArrayList = (CopyOnWriteArrayList<EventListener>) field1.get(EventNotifier.getInstance());
		copyOnWriteArrayList.clear();			
		
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testCaculateNextMu_have_notReady() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		int size = 5;
		for (int i = 0 ; i < size; i++) {
			UnitCard unitCard = new UnitCard();
			unitCard.setUnitId(Long.valueOf(i + 1));
			unitCard.setUnitType(UnitType.MATCHER);
			if (i == 3) {
				unitCard.setStatus(UnitStatus.connected);	
			} else {
				unitCard.setStatus(UnitStatus.ready);
			}			
			UnitMessageSender sender = new UnitMessageSender(unitCard);
			EventNotifier.getInstance().addMuSenderListener(sender);
		}
		Class<EventNotifier> cls = EventNotifier.class;
		Field field = cls.getDeclaredField("lastSelectMu");
		field.setAccessible(true);
		field.set(EventNotifier.getInstance(), new AtomicInteger(-1));
		for (int i = 0 ; i < size - 2; i++) {
			EventNotifier.getInstance().caculateNextMu(1);
			int result = ((AtomicInteger)field.get(EventNotifier.getInstance())).intValue();
			Assert.assertEquals(i, result);
		}
		
		Field field1 = cls.getDeclaredField("muSenderListenerList");
		field1.setAccessible(true);
		CopyOnWriteArrayList<EventListener> copyOnWriteArrayList = (CopyOnWriteArrayList<EventListener>) field1.get(EventNotifier.getInstance());
		copyOnWriteArrayList.clear();		
	}
	
	@Test
	public void testCaculateNextMu_size_init_zero() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {

		Class<EventNotifier> cls = EventNotifier.class;
		Field field = cls.getDeclaredField("lastSelectMu");
		field.setAccessible(true);
	
		EventNotifier.getInstance().caculateNextMu(1);
		int result = ((AtomicInteger) field.get(EventNotifier.getInstance())).intValue();
		Assert.assertEquals(-1, result);
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testCaculateNextMu_size_zero() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		int size = 5;
		for (int i = 0; i < size; i++) {
			UnitCard unitCard = new UnitCard();
			unitCard.setUnitId(Long.valueOf(i + 1));
			unitCard.setUnitType(UnitType.MATCHER);
			unitCard.setStatus(UnitStatus.ready);
			UnitMessageSender sender = new UnitMessageSender(unitCard);
			EventNotifier.getInstance().addMuSenderListener(sender);
		}
		
		EventNotifier.getInstance().caculateNextMu(1);

		Class<EventNotifier> cls = EventNotifier.class;
		Field field = cls.getDeclaredField("lastSelectMu");
		field.setAccessible(true);		

		Field field1 = cls.getDeclaredField("muSenderListenerList");
		field1.setAccessible(true);
		CopyOnWriteArrayList<EventListener> list = ((CopyOnWriteArrayList<EventListener>) field1.get(EventNotifier.getInstance()));
		list.clear();
		Assert.assertEquals(0, list.size());
		EventNotifier.getInstance().caculateNextMu(1);
		int result = ((AtomicInteger) field.get(EventNotifier.getInstance())).intValue();
		Assert.assertEquals(-1, result);
		list.clear();
	}

}
