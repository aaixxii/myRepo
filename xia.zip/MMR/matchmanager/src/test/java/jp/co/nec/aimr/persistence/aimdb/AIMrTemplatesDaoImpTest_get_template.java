package jp.co.nec.aimr.persistence.aimdb;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import jp.co.nec.aim.message.proto.AIMEnumTypes.ContainerAssignedStateType;
import jp.co.nec.aim.message.proto.AIMMessages.PBContainerCatchUpInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBContainerSyncRequest;
import jp.co.nec.aim.message.proto.ManageService.PBGetTemplateResponse;
import jp.co.nec.aim.message.proto.SyncEnumTypes.SyncFunctionType;
import jp.co.nec.aimr.common.ErrorDifinitions;
import jp.co.nec.aimr.management.AIMrManger;
import jp.co.nec.aimr.persistence.aimdb.AIMrTemplatesDao;
import jp.co.nec.aimr.persistence.aimdb.AIMrTemplatesDaoImp;
import jp.co.nec.aimr.persistence.aimdb.DataBaseUtil;
import jp.co.nec.aimr.properties.PropertyUtil;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class AIMrTemplatesDaoImpTest_get_template {

	@Resource
	private DataSource ds;

	@Resource
	private DataSource testDs;

	private AIMrTemplatesDao dao;
	private JdbcTemplate jdbcTemplate;
	private MockUp<DataBaseUtil> dbMock;
	private MockUp<PropertyUtil> proMock;
	private MockUp<AIMrManger> manager;

	@Before
	public void setUp() throws Exception {
		jdbcTemplate = new JdbcTemplate(ds);
		dao = new AIMrTemplatesDaoImp(jdbcTemplate);
		jdbcTemplate.execute("delete from PERSON_BIOMETRICS_1");
		jdbcTemplate.execute("delete from PERSON_BIO_CHANGE_LOG_1");
		jdbcTemplate.execute("COMMIT");
		recoverConatainerData();
		dbMock = new MockUp<DataBaseUtil>() {
			@Mock
			public DataSource lookupDataSource() {
				return ds;
			}
		};
		proMock = new MockUp<PropertyUtil>() {
			@Mock
			public void $init() {
				return;
			}

			@Mock
			public PropertyUtil getInstance() {
				return new PropertyUtil();
			}

			@Mock
			public Integer getPropertyIntValue(String name) {
				return 3;
			}

			@Mock
			public String getPropertyValue(String name) {
				return "Oracle";
			}
		};

		manager = new MockUp<AIMrManger>() {
			@Mock
			private void init() {
				return;
			}
		};
	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.execute("delete from PERSON_BIOMETRICS_1");
		jdbcTemplate.execute("delete from PERSON_BIO_CHANGE_LOG_1");
		jdbcTemplate.execute("COMMIT");
		recoverConatainerData();
		dbMock.tearDown();
		proMock.tearDown();
		manager.tearDown();
	}

	@Test
	public void testGetTemplates_eventId_null() {
		PBGetTemplateResponse getTemplateResponse = null;
		Integer containerId = 1;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "INSERT INTO PERSON_BIOMETRICS_1 (BIOMETRICS_ID,USER_KEY, USER_EVENT_ID, BIOMETRICS_DATA, BIOMETRICS_DATA_LEN, REGISTERED_TS) VALUES (? ,?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] { i + 1, userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		getTemplateResponse = dao.getTemplates(containerId, userKey, null);
		Assert.assertNotNull(getTemplateResponse);
		Assert.assertEquals(4, getTemplateResponse.getTemplateRefInfoCount());
		for (int i = 0; i < 4; i++) {
			Assert.assertEquals(containerId.intValue(),
					getTemplateResponse.getTemplateRefInfoList().get(i).getContainerId());
			Assert.assertEquals(i + 1, getTemplateResponse.getTemplateRefInfoList().get(i).getEventId());
			Assert.assertEquals(userKey, getTemplateResponse.getTemplateRefInfoList().get(i).getExternalId());
			Assert.assertEquals(sdata,
					new String(getTemplateResponse.getTemplateRefInfoList().get(i).getTemplate().toByteArray()));
		}
	}

	@Test
	public void testGetTemplates_eventId_null_results() {
		PBGetTemplateResponse getTemplateResponse = null;
		Integer containerId = 1;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "INSERT INTO PERSON_BIOMETRICS_1 (BIOMETRICS_ID,USER_KEY, USER_EVENT_ID, BIOMETRICS_DATA, BIOMETRICS_DATA_LEN, REGISTERED_TS) VALUES (? ,?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] { i + 1, userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		getTemplateResponse = dao.getTemplates(containerId, "test1", null);
		Assert.assertNotNull(getTemplateResponse);
		Assert.assertEquals(ErrorDifinitions.DB_GET_TEMPLATES_EMPTY.getDescriptionWithKey(containerId, "test1", null),
				getTemplateResponse.getServiceState().getReason().getDescription());
		Assert.assertEquals(ErrorDifinitions.DB_GET_TEMPLATES_EMPTY.getStringCode(),
				getTemplateResponse.getServiceState().getReason().getCode());
		Assert.assertEquals(0, getTemplateResponse.getTemplateRefInfoCount());
		Assert.assertEquals(0, getTemplateResponse.getTemplateRefInfoList().size());
	}

	@Test
	public void testGetTemplates_eventId_null_error() {
		PBGetTemplateResponse getTemplateResponse = null;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "INSERT INTO PERSON_BIOMETRICS_1 (BIOMETRICS_ID,USER_KEY, USER_EVENT_ID, BIOMETRICS_DATA, BIOMETRICS_DATA_LEN, REGISTERED_TS) VALUES (? ,?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] { i + 1, userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		getTemplateResponse = dao.getTemplates(-9999, "test", null);
		Assert.assertNotNull(getTemplateResponse);
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getDescriptionWithKey(-9999, userKey, null),
				getTemplateResponse.getServiceState().getReason().getDescription());
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getStringCode(),
				getTemplateResponse.getServiceState().getReason().getCode());
		Assert.assertEquals(0, getTemplateResponse.getTemplateRefInfoCount());
		Assert.assertEquals(0, getTemplateResponse.getTemplateRefInfoList().size());
	}

	@Test
	public void testGetTemplates_eventId_not_null() {
		PBGetTemplateResponse getTemplateResponse = null;
		Integer containerId = 1;
		String userKey = "test";
		Integer eventId = 1;
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "INSERT INTO PERSON_BIOMETRICS_1 (BIOMETRICS_ID,USER_KEY, USER_EVENT_ID, BIOMETRICS_DATA, BIOMETRICS_DATA_LEN, REGISTERED_TS) VALUES (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] { i + 1, userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		getTemplateResponse = dao.getTemplates(containerId, userKey, eventId);
		Assert.assertNotNull(getTemplateResponse);
		Assert.assertEquals(1, getTemplateResponse.getTemplateRefInfoCount());

		Assert.assertEquals(containerId.intValue(),
				getTemplateResponse.getTemplateRefInfoList().get(0).getContainerId());
		Assert.assertEquals(1, getTemplateResponse.getTemplateRefInfoList().get(0).getEventId());
		Assert.assertEquals(userKey, getTemplateResponse.getTemplateRefInfoList().get(0).getExternalId());
		Assert.assertEquals(sdata,
				new String(getTemplateResponse.getTemplateRefInfoList().get(0).getTemplate().toByteArray()));
	}

	@Test
	public void testGetTemplates_eventId_not_null_results_empty() {
		PBGetTemplateResponse getTemplateResponse = null;
		Integer containerId = 1;
		String userKey = "test";
		Integer eventId = 1;
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "INSERT INTO PERSON_BIOMETRICS_1 (BIOMETRICS_ID,USER_KEY, USER_EVENT_ID, BIOMETRICS_DATA, BIOMETRICS_DATA_LEN, REGISTERED_TS) VALUES (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] { i + 1, userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		getTemplateResponse = dao.getTemplates(containerId, "test1", eventId);
		Assert.assertNotNull(getTemplateResponse);
		Assert.assertEquals(
				ErrorDifinitions.DB_GET_TEMPLATES_EMPTY.getDescriptionWithKey(containerId, "test1", eventId),
				getTemplateResponse.getServiceState().getReason().getDescription());
		Assert.assertEquals(ErrorDifinitions.DB_GET_TEMPLATES_EMPTY.getStringCode(),
				getTemplateResponse.getServiceState().getReason().getCode());
		Assert.assertEquals(0, getTemplateResponse.getTemplateRefInfoCount());
		Assert.assertEquals(0, getTemplateResponse.getTemplateRefInfoList().size());
	}

	@Test
	public void testGetTemplates_eventId_not_null_error() {
		PBGetTemplateResponse getTemplateResponse = null;
		String userKey = "test";
		Integer eventId = 1;
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "INSERT INTO PERSON_BIOMETRICS_1 (BIOMETRICS_ID,USER_KEY, USER_EVENT_ID, BIOMETRICS_DATA, BIOMETRICS_DATA_LEN, REGISTERED_TS) VALUES (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] { i + 1, userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		getTemplateResponse = dao.getTemplates(-9999, "test1", eventId);
		Assert.assertNotNull(getTemplateResponse);
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getDescriptionWithKey(-9999, "test1", eventId),
				getTemplateResponse.getServiceState().getReason().getDescription());
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getStringCode(),
				getTemplateResponse.getServiceState().getReason().getCode());
		Assert.assertEquals(0, getTemplateResponse.getTemplateRefInfoCount());
		Assert.assertEquals(0, getTemplateResponse.getTemplateRefInfoList().size());
	}

	@Test
	public void testGetTemplates_eventId_not_null_results_error() {
		PBGetTemplateResponse getTemplateResponse = null;
		String userKey = "test";
		Integer eventId = 1;
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "INSERT INTO PERSON_BIOMETRICS_1 (BIOMETRICS_ID,USER_KEY, USER_EVENT_ID, BIOMETRICS_DATA, BIOMETRICS_DATA_LEN, REGISTERED_TS) VALUES (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] { i + 1, userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		getTemplateResponse = dao.getTemplates(-9999, userKey, eventId);
		Assert.assertNotNull(getTemplateResponse);
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getDescriptionWithKey(-9999, userKey, eventId),
				getTemplateResponse.getServiceState().getReason().getDescription());
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getStringCode(),
				getTemplateResponse.getServiceState().getReason().getCode());
		Assert.assertEquals(0, getTemplateResponse.getTemplateRefInfoCount());
		Assert.assertEquals(0, getTemplateResponse.getTemplateRefInfoList().size());
	}

	@Test
	public void prirnt() {
		PBContainerSyncRequest.Builder pBContainerSyncRequest = PBContainerSyncRequest.newBuilder();
		pBContainerSyncRequest.setContainerId(1);
		pBContainerSyncRequest.setAssignedState(ContainerAssignedStateType.CONTAINER_ASSIGNED);
		List<PBContainerCatchUpInfo> syncList = new ArrayList<>();
		for (int i = 0; i < 5; i++) {
			PBContainerCatchUpInfo.Builder pBContainerCatchUpInfo = PBContainerCatchUpInfo.newBuilder();
			pBContainerCatchUpInfo.setCommand(SyncFunctionType.INSERT);
			pBContainerCatchUpInfo.setEventId(i);
			pBContainerCatchUpInfo.setExternalId("test");
			pBContainerCatchUpInfo.setVersion(i);
			syncList.add(pBContainerCatchUpInfo.build());
		}
		pBContainerSyncRequest.addAllContainerSyncInfo(syncList);
		System.out.println(pBContainerSyncRequest.toString());

	}

	private void recoverConatainerData() {
		String sql = "UPDATE CONTAINERS SET TEMPLATE_SIZE =15680 ,VERSION =0 ,RECORD_COUNT=0 WHERE CONTAINER_ID=1";
		jdbcTemplate.update(sql);
		jdbcTemplate.execute("COMMIT");
	}
}
