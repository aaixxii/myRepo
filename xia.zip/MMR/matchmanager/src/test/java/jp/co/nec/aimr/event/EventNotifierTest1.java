package jp.co.nec.aimr.event;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import jp.co.nec.aimr.common.UnitCard;
import jp.co.nec.aimr.common.UnitStatus;
import jp.co.nec.aimr.common.UnitType;
import jp.co.nec.aimr.exception.NoActiveUnitException;
import jp.co.nec.aimr.management.AIMrManger;
import jp.co.nec.aimr.matchunit.UnitMessageSender;
import jp.co.nec.aimr.persistence.aimdb.ContainerInfo;
import jp.co.nec.aimr.properties.PropertyUtil;
import mockit.Mock;
import mockit.MockUp;

public class EventNotifierTest1 {
	private MockUp<PropertyUtil> propertyUtilMock;
	private MockUp<AIMrManger> aIMrMangerMock;

	@SuppressWarnings("unchecked")
	@Before
	public void setUp() throws Exception {
		propertyUtilMock = 
		new MockUp<PropertyUtil>() {
			@Mock
			public void $init() {
				return;
			}
			@Mock
			public PropertyUtil getInstance() {
				return new PropertyUtil();
			}
			@Mock
			public Integer getPropertyIntValue(String name) {
				return 300;
			}			
			@Mock
			public Long getPropertyLongValue(String name) {
				return 400L;
			}
			
			@Mock
			public String getPropertyValue(String name) {
				return "Oracle";
			}
		};
		
		aIMrMangerMock =
				new MockUp<AIMrManger>() {
			@Mock
			private void init() {
				return;
			}
			
			@Mock
			public  List<ContainerInfo> getMuEliginbleConatainerInfo(Long muId) {
				List<ContainerInfo> infos = new ArrayList<>();
				ContainerInfo info = new ContainerInfo();
				info.setContainerId(1);
				info.setPersonBiTtableName("");
				info.setConatainerLogTableName("");
			
				infos.add(info);
				return infos;
			}			
			
		};		
		Class<EventNotifier> cls = EventNotifier.class;
		Field field = cls.getDeclaredField("lastSelectEu");
		field.setAccessible(true);
		field.set(EventNotifier.getInstance(), new AtomicInteger(-1));
		
		Field field1 = cls.getDeclaredField("lastSelectMu");
		field1.setAccessible(true);
		field.set(EventNotifier.getInstance(), new AtomicInteger(-1));
		
		Field field2 = cls.getDeclaredField("euSenderListenerList");
		field2.setAccessible(true);
		CopyOnWriteArrayList<EventListener> listEu = ((CopyOnWriteArrayList<EventListener>) field2.get(EventNotifier.getInstance()));
		listEu.clear();
		
		Field field3 = cls.getDeclaredField("muSenderListenerList");
		field3.setAccessible(true);
		CopyOnWriteArrayList<EventListener> listMu = ((CopyOnWriteArrayList<EventListener>) field3.get(EventNotifier.getInstance()));
		listMu.clear();
		
		Field field4 = cls.getDeclaredField("systemListenerQueue");
		field4.setAccessible(true);
		CopyOnWriteArrayList<EventListener> listSys = ((CopyOnWriteArrayList<EventListener>) field4.get(EventNotifier.getInstance()));
		listSys.clear();		
	}

	@After
	public void tearDown() throws Exception {
		propertyUtilMock.tearDown();
		aIMrMangerMock.tearDown();
	}

	@Test
	public void testFireOnIdentifyJobqueueing_normal() {
		MockUp<UnitMessageSender> mocker =
		new MockUp<UnitMessageSender>() {
			@Mock
			public void onIdentifyJobqueueing( Long inquiryJobId) {
				return;
			}
		};
		for (int i = 0 ; i < 5; i++) {
			UnitCard unitCard = new UnitCard();
			unitCard.setUnitId(Long.valueOf(i + 1));
			unitCard.setUnitType(UnitType.MATCHER);
			unitCard.setStatus(UnitStatus.ready);
			UnitMessageSender sender = new UnitMessageSender(unitCard);
			EventNotifier.getInstance().addMuSenderListener(sender);
		}
		EventNotifier.getInstance().fireOnIdentifyJobqueueing(1,1l);
		mocker.tearDown();
	}
	
	@Test(expected = NoActiveUnitException.class)
	public void testFireOnIdentifyJobqueueing_no_mu() {
		MockUp<UnitMessageSender> mocker =
		new MockUp<UnitMessageSender>() {
			@Mock
			public void onIdentifyJobqueueing( Long inquiryJobId) {
				return;
			}
		};

		EventNotifier.getInstance().fireOnIdentifyJobqueueing(1,1l);
		mocker.tearDown();
	}
	
	@Test(expected =NoActiveUnitException.class)
	public void testFireOnIdentifyJobqueueing_no_ready_mu() {
		MockUp<UnitMessageSender> mocker =
		new MockUp<UnitMessageSender>() {
			@Mock
			public void onIdentifyJobqueueing( Long inquiryJobId) {
				return;
			}
		};
		List<ContainerInfo> myContainerList = new ArrayList<>();
		ContainerInfo info = new ContainerInfo();
		info.setContainerId(1);
		myContainerList.add(info);		
		for (int i = 0 ; i < 5; i++) {
			UnitCard unitCard = new UnitCard();
			unitCard.setUnitId(Long.valueOf(i + 1));
			unitCard.setUnitType(UnitType.MATCHER);
			unitCard.setStatus(UnitStatus.connected);
			 AIMrManger.saveMuEligiblecontaineinfo(Long.valueOf(i + 1), myContainerList);
			UnitMessageSender sender = new UnitMessageSender(unitCard);
			EventNotifier.getInstance().addMuSenderListener(sender);
		}
		EventNotifier.getInstance().fireOnIdentifyJobqueueing(1,1l);
		mocker.tearDown();
	}

	@Test
	public void testFireOnVerifyJobqueueing_normal() {
		MockUp<UnitMessageSender> mocker =
		new MockUp<UnitMessageSender>() {
			@Mock
			public void onVerifyJobqueueing( Long inquiryJobId) {
				return;
			}
		};
		for (int i = 0 ; i < 5; i++) {
			UnitCard unitCard = new UnitCard();
			unitCard.setUnitId(Long.valueOf(i + 1));
			unitCard.setUnitType(UnitType.EXTRACTOR);
			unitCard.setStatus(UnitStatus.ready);
			UnitMessageSender sender = new UnitMessageSender(unitCard);
			EventNotifier.getInstance().addEuSenderListener(sender);
		}
		EventNotifier.getInstance().fireOnVerifyJobqueueing(1l);
		mocker.tearDown();

	}
	
	@Test(expected = NoActiveUnitException.class)
	public void testFireOnVerifyJobqueueing_no_eu() {
		MockUp<UnitMessageSender> mocker =
		new MockUp<UnitMessageSender>() {
			@Mock
			public void onVerifyJobqueueing( Long inquiryJobId) {
				return;
			}
		};

		EventNotifier.getInstance().fireOnVerifyJobqueueing(1l);
		mocker.tearDown();

	}
	
	@Test(expected = NoActiveUnitException.class)
	public void testFireOnVerifyJobqueueing_no_ready_eu() {
		MockUp<UnitMessageSender> mocker =
		new MockUp<UnitMessageSender>() {
			@Mock
			public void onVerifyJobqueueing( Long inquiryJobId) {
				return;
			}
		};
		
		for (int i = 0 ; i < 5; i++) {
			UnitCard unitCard = new UnitCard();
			unitCard.setUnitId(Long.valueOf(i + 1));
			unitCard.setUnitType(UnitType.EXTRACTOR);
			unitCard.setStatus(UnitStatus.connected);
			UnitMessageSender sender = new UnitMessageSender(unitCard);
			EventNotifier.getInstance().addEuSenderListener(sender);
		}
		EventNotifier.getInstance().fireOnVerifyJobqueueing(1l);
		mocker.tearDown();
	}

	@Test
	public void testFireOnExtractJobqueueing_normal() {
		MockUp<UnitMessageSender> mocker =
		new MockUp<UnitMessageSender>() {
			@Mock
			public void onExtractJobqueueing( Long inquiryJobId) {
				return;
			}
		};
		for (int i = 0 ; i < 5; i++) {
			UnitCard unitCard = new UnitCard();
			unitCard.setUnitId(Long.valueOf(i + 1));
			unitCard.setUnitType(UnitType.EXTRACTOR);
			unitCard.setStatus(UnitStatus.ready);
			UnitMessageSender sender = new UnitMessageSender(unitCard);
			EventNotifier.getInstance().addEuSenderListener(sender);
		}
		EventNotifier.getInstance().fireOnExtractJobqueueing(1l);
		mocker.tearDown();
	}
	
	@Test(expected = NoActiveUnitException.class)
	public void testFireOnExtractJobqueueing_no_eu() {
		MockUp<UnitMessageSender> mocker =
		new MockUp<UnitMessageSender>() {
			@Mock
			public void onExtractJobqueueing( Long inquiryJobId) {
				return;
			}
		};

		EventNotifier.getInstance().fireOnExtractJobqueueing(1l);
		mocker.tearDown();
		

	}
	
	@Test(expected = NoActiveUnitException.class)
	public void testFireOnExtractJobqueueing_no_ready_eu() {
		MockUp<UnitMessageSender> mocker =
		new MockUp<UnitMessageSender>() {
			@Mock
			public void onExtractJobqueueing( Long inquiryJobId) {
				return;
			}
		};
		
		for (int i = 0 ; i < 5; i++) {
			UnitCard unitCard = new UnitCard();
			unitCard.setUnitId(Long.valueOf(i + 1));
			unitCard.setUnitType(UnitType.EXTRACTOR);
			unitCard.setStatus(UnitStatus.connected);
			UnitMessageSender sender = new UnitMessageSender(unitCard);
			EventNotifier.getInstance().addEuSenderListener(sender);
		}
		EventNotifier.getInstance().fireOnExtractJobqueueing(1l);
		mocker.tearDown();

	}

	@Test
	public void testFireOnStop() {

	}

	@Test
	public void testFireOnSyncTemplates() {

	}
}
