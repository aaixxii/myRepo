package jp.co.nec.aimr.matchunit;



import java.io.IOException;
import java.nio.channels.SocketChannel;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import jp.co.nec.aim.message.proto.AIMEnumTypes.ContainerAssignedStateType;
import jp.co.nec.aim.message.proto.AIMMessages.PBContainerSyncRequest;
import jp.co.nec.aimr.common.UnitCard;
import jp.co.nec.aimr.common.UnitStatus;
import jp.co.nec.aimr.common.UnitType;
import mockit.Mock;
import mockit.MockUp;

public class UnitMessageSenderTest {
	

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testOnIdentifyJobqueueing() {
		UnitCard muCard = new UnitCard();
		muCard.setUnitType(UnitType.MATCHER);
		muCard.setStatus(UnitStatus.ready);
		UnitMessageSender us = new UnitMessageSender(muCard);
		us.onIdentifyJobqueueing(1l);		
	}

	@Test
	public void testOnStop() {
		
	}

	@Test
	public void testOnExtractJobqueueing() {
		UnitCard muCard = new UnitCard();
		muCard.setUnitType(UnitType.EXTRACTOR);
		muCard.setStatus(UnitStatus.ready);
		UnitMessageSender us = new UnitMessageSender(muCard);
		us.onExtractJobqueueing(1l);
	}

	@Test
	public void testOnVerifyJobqueueing() {
		UnitCard muCard = new UnitCard();
		muCard.setUnitType(UnitType.EXTRACTOR);
		muCard.setStatus(UnitStatus.ready);
		UnitMessageSender us = new UnitMessageSender(muCard);
		us.onVerifyJobqueueing(1l);
	}

	@Test
	public void testOnSyncTemplates() {
		MockUp<UnitMessageSender> sender = new MockUp<UnitMessageSender>() {
			@Mock
			private boolean sendSyncTemplateRequest(Long syncJobId, PBContainerSyncRequest syncRequust) {
				return true;
			}
		};
		UnitCard muCard = new UnitCard();
		muCard.setUnitType(UnitType.MATCHER);
		muCard.setStatus(UnitStatus.ready);
		UnitMessageSender us = new UnitMessageSender(muCard);
		PBContainerSyncRequest.Builder syncRequust = PBContainerSyncRequest.newBuilder();
		syncRequust.setContainerId(1);
		syncRequust.setAssignedState(ContainerAssignedStateType.CONTAINER_ASSIGNED);
		us.onSyncTemplates(1L, syncRequust.build());
		sender.tearDown();
	}

	@Test
	public void testUnitMessageSender() {
		UnitCard muCard = new UnitCard();
		UnitMessageSender us = new UnitMessageSender(muCard);
		Assert.assertNotNull(us);
		Assert.assertTrue(us instanceof UnitMessageSender);
		muCard = null;
		us = null;
	}

	@Test
	public void testOnReady() {
		UnitCard muCard = new UnitCard();
		muCard.setUnitType(UnitType.MATCHER);
		UnitMessageSender us = new UnitMessageSender(muCard);
		us.onReady();		
	}

	@Test
	public void testOnHold() {
		UnitCard muCard = new UnitCard();
		UnitMessageSender us = new UnitMessageSender(muCard);
		us.onHold();
		Assert.assertEquals(UnitStatus.hold,us.getUnitStatus());
		muCard = null;
		us = null;		
	}

	@Test
	public void testOnExit() throws IOException {
		UnitCard muCard = new UnitCard();
		muCard.setSocketChannel(SocketChannel.open());
		UnitMessageSender us = new UnitMessageSender(muCard);
		us.onExit();
		Assert.assertNull(us.getUnitCard());			
	}

	@Test
	public void testGetExtJobCominglocker() {
		UnitCard muCard = new UnitCard();
		muCard.setUnitType(UnitType.EXTRACTOR);
		UnitMessageSender us = new UnitMessageSender(muCard);
		 Object result = us.getExtJobCominglocker();
		Assert.assertNotNull(result);
		muCard = null;
		us = null;
	}

	@Test
	public void testGetVerifyJobCominglocker() {
		UnitCard muCard = new UnitCard();
		muCard.setUnitType(UnitType.EXTRACTOR);
		UnitMessageSender us = new UnitMessageSender(muCard);
		 Object result = us.getVerifyJobCominglocker();
		Assert.assertNotNull(result);
		muCard = null;
		us = null;
	}

	@Test
	public void testGetInqJobCominglocker() {
		UnitCard muCard = new UnitCard();
		muCard.setUnitType(UnitType.EXTRACTOR);
		UnitMessageSender us = new UnitMessageSender(muCard);
		 Object result = us.getInqJobCominglocker();
		Assert.assertNotNull(result);	
		muCard = null;
		us = null;
	}

	@Test
	public void testGetUnitType() {
		UnitCard muCard = new UnitCard();
		muCard.setUnitType(UnitType.EXTRACTOR);
		UnitMessageSender us = new UnitMessageSender(muCard);
		 UnitType result = us.getUnitType();
		Assert.assertEquals(UnitType.EXTRACTOR, result);
		muCard = null;
		us = null;
	}

	@Test
	public void testGetUnitStatus() {
		UnitCard muCard = new UnitCard();
		muCard.setStatus(UnitStatus.ready);
		UnitMessageSender us = new UnitMessageSender(muCard);
		UnitStatus result = us.getUnitStatus();
		Assert.assertEquals(UnitStatus.ready, result);
		muCard = null;
		us = null;
	}

	@Test
	public void testGetUnitCard() {
		UnitCard muCard = new UnitCard();
		UnitMessageSender us = new UnitMessageSender(muCard);
		UnitCard resutl = us.getUnitCard();
		Assert.assertNotNull(resutl);
		muCard = null;
		us = null;
	}
}
