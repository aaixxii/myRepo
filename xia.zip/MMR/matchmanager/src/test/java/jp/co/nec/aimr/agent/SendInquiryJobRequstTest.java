package jp.co.nec.aimr.agent;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.InquiryService.PBIdentifyResponse;
import jp.co.nec.aimr.common.SequenceIdCreator;
import jp.co.nec.aimr.common.SequenceIdType;

public class SendInquiryJobRequstTest {

	private final int SERVERPORT = 8888;
	private SocketChannel client = null;

	public SendInquiryJobRequstTest() {
		InetSocketAddress hostAddress = new InetSocketAddress("10.197.23.100", SERVERPORT);
		try {
			client = SocketChannel.open(hostAddress);
			System.out.println("Success to connected to server!");
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	// public void sendMuJobRequestTest() {
	// try {
	// EventNotifier.getInstance().fireOnTest(client);
	// } catch (IOException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	// }
	//

	public void sendMuJobResult() {
		System.out.println("Send  msg to mu ....");
		Long head = 513L;
		PBIdentifyResponse muJobResult = CreateInquiryJobResult();
		byte[] jobRequst = muJobResult.toByteArray();
		long jobId = SequenceIdCreator.createNextSequence(SequenceIdType.INQUIRY_ID);
		int size = jobRequst.length;
		ByteBuffer headBuff = ByteBuffer.allocate(32 + jobRequst.length);
		headBuff.putLong(head);
		headBuff.putInt(size);
		headBuff.putInt(size);
		headBuff.putLong(1L);
		headBuff.putLong(jobId);
		headBuff.put(jobRequst);
		headBuff.flip();
		try {
			while (headBuff.hasRemaining()) {
				client.write(headBuff);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		headBuff.clear();

	}

	private PBIdentifyResponse CreateInquiryJobResult() {
		PBIdentifyResponse.Builder jobResult = PBIdentifyResponse.newBuilder();
		PBServiceState.Builder status = PBServiceState.newBuilder();
		status.setState(ServiceStateType.SERVICE_STATE_SUCCESS);
		jobResult.setServiceState(status);
		return jobResult.build();
	}

}
