package jp.co.nec.aimr.persistence.postgres;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import jp.co.nec.aim.message.proto.AIMMessages.PBContainerSyncRequest;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aimr.common.ErrorDifinitions;
import jp.co.nec.aimr.management.AIMrManger;
import jp.co.nec.aimr.persistence.aimdb.AIMrTemplatesDao;
import jp.co.nec.aimr.persistence.aimdb.AIMrTemplatesPostgresDaoImp;
import jp.co.nec.aimr.persistence.aimdb.SyncResultWithStatus;
import jp.co.nec.aimr.properties.PropertyUtil;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationPostgresContext.xml" })
@Transactional
public class AIMrTemplatesDaoImpTest_update {

	@Resource
	private DataSource ds;
	
	@Resource
	private DataSource testDs;

	private AIMrTemplatesDao dao;
	private JdbcTemplate jdbcTemplate;	
	private  MockUp<PropertyUtil> proMock;
	private MockUp<AIMrManger> manager;
	  

	@Before
	public void setUp() throws Exception {
		proMock = new MockUp<PropertyUtil>() {
			@Mock
			public void $init() {
				return;
			}
			@Mock
			public PropertyUtil getInstance() {
				return new PropertyUtil();
			}			
			@Mock
			public Integer getPropertyIntValue(String name) {
				return 3;
			}
			@Mock
			public String getPropertyValue(String name) {
				return "postgresql";
			}	
		};
		
		manager = new MockUp<AIMrManger>() {
			@Mock
			private void init() {
				return;
			}
			
			@Mock
			public String getDB_DRIVER() {
				return "postgresql";
			}
		};
		jdbcTemplate = new JdbcTemplate(ds);
		dao = new AIMrTemplatesPostgresDaoImp(jdbcTemplate);
		jdbcTemplate.execute("delete from \"PERSON_BIOMETRICS_1\"");
		jdbcTemplate.execute("delete from \"PERSON_BIO_CHANGE_LOG_1\"");
		jdbcTemplate.execute("COMMIT");
		recoverConatainerData();		
	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.execute("delete from \"PERSON_BIOMETRICS_1\"");
		jdbcTemplate.execute("delete from \"PERSON_BIO_CHANGE_LOG_1\"");
		jdbcTemplate.execute("COMMIT");
		recoverConatainerData();		
		proMock.tearDown();
		manager.tearDown();
	}	
	
	@Test
	public void testUpdateTemplate_eventId_null_4() {
		PBContainerSyncRequest pbSyncRequet = null;
		SyncResultWithStatus syncResultWithStatus = null;
		Integer containerId = 1;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		String tobeUpdateString = "zyxwvumlkjihjfedcba1234";
		byte[] tobeUpdateData = tobeUpdateString.getBytes();		
		
		long  biometricsId = jdbcTemplate.queryForObject("SELECT \"SEQUENCE_VALUE\" FROM \"SEQUENCE\" WHERE \"SEQUENCE_NAME\" = 'BIOMETRICS_ID_SEQ'", Long.class);	
		long changeId = jdbcTemplate.queryForObject("SELECT \"SEQUENCE_VALUE\" FROM \"SEQUENCE\" WHERE \"SEQUENCE_NAME\" = 'CHANGE_ID_SEQ'", Long.class);		

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "insert into \"PERSON_BIOMETRICS_1\" (\"BIOMETRICS_ID\",\"USER_KEY\", \"USER_EVENT_ID\", \"BIOMETRICS_DATA\", \"BIOMETRICS_DATA_LEN\", \"REGISTERED_TS\") values (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] {Long.valueOf(biometricsId + i), userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		syncResultWithStatus = dao.updateTemplate(containerId, userKey, null, tobeUpdateData);
		pbSyncRequet = syncResultWithStatus.getpBContainerSyncRequest();
		int biometorisRecordCout = jdbcTemplate.queryForObject("select count(\"BIOMETRICS_ID\") from \"PERSON_BIOMETRICS_1\"", Integer.class).intValue();

		Assert.assertNotNull(pbSyncRequet);
		for (int i = 0; i < 4; i++) {
			Assert.assertEquals(containerId.intValue(), pbSyncRequet.getContainerId());
			Assert.assertEquals(4, pbSyncRequet.getContainerSyncInfoCount());
			Assert.assertEquals("CONTAINER_ASSIGNED", pbSyncRequet.getAssignedState().name());
			Assert.assertEquals(i + 1, pbSyncRequet.getContainerSyncInfoList().get(i).getVersion());
			Assert.assertEquals(i + 1, pbSyncRequet.getContainerSyncInfoList().get(i).getEventId());
			Assert.assertEquals("UPDATE", pbSyncRequet.getContainerSyncInfoList().get(i).getCommand().name());
			Assert.assertEquals(userKey, pbSyncRequet.getContainerSyncInfoList().get(i).getExternalId());			
			Assert.assertEquals(tobeUpdateString, new String(pbSyncRequet.getContainerSyncInfoList().get(i).getTemplate().toByteArray()));
		}		
		Assert.assertEquals(biometorisRecordCout, jdbcTemplate.queryForObject("select count(\"BIOMETRICS_ID\") from \"PERSON_BIOMETRICS_1\"", Integer.class).intValue());
		Assert.assertEquals(changeId + 4,  jdbcTemplate.queryForObject("SELECT \"SEQUENCE_VALUE\" FROM \"SEQUENCE\" WHERE \"SEQUENCE_NAME\" = 'CHANGE_ID_SEQ'", Long.class).longValue());		
	}
	
	@Test
	public void testUpdateTemplate_eventId_null_1() {
		PBContainerSyncRequest pbSyncRequet = null;
		SyncResultWithStatus syncResultWithStatus = null;
		Integer containerId = 1;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		String tobeUpdateString = "zyxwvumlkjihjfedcba1234";
		byte[] tobeUpdateData = tobeUpdateString.getBytes();		
		
		long  biometricsId = jdbcTemplate.queryForObject("SELECT \"SEQUENCE_VALUE\" FROM \"SEQUENCE\" WHERE \"SEQUENCE_NAME\" = 'BIOMETRICS_ID_SEQ'", Long.class);	
		long changeId = jdbcTemplate.queryForObject("SELECT \"SEQUENCE_VALUE\" FROM \"SEQUENCE\" WHERE \"SEQUENCE_NAME\" = 'CHANGE_ID_SEQ'", Long.class);		

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "insert into \"PERSON_BIOMETRICS_1\" (\"BIOMETRICS_ID\",\"USER_KEY\", \"USER_EVENT_ID\", \"BIOMETRICS_DATA\", \"BIOMETRICS_DATA_LEN\", \"REGISTERED_TS\") values (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 1; i++) {
			jdbcTemplate.update(insSql, new Object[] {Long.valueOf(biometricsId + i), userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		syncResultWithStatus = dao.updateTemplate(containerId, userKey, null, tobeUpdateData);
		pbSyncRequet = syncResultWithStatus.getpBContainerSyncRequest();
		int biometorisRecordCout = jdbcTemplate.queryForObject("select count(\"BIOMETRICS_ID\") from \"PERSON_BIOMETRICS_1\"", Integer.class).intValue();

		Assert.assertNotNull(pbSyncRequet);
		for (int i = 0; i < 1; i++) {
			Assert.assertEquals(containerId.intValue(), pbSyncRequet.getContainerId());
			Assert.assertEquals(1, pbSyncRequet.getContainerSyncInfoCount());
			Assert.assertEquals("CONTAINER_ASSIGNED", pbSyncRequet.getAssignedState().name());
			Assert.assertEquals(i + 1, pbSyncRequet.getContainerSyncInfoList().get(i).getVersion());
			Assert.assertEquals(i + 1, pbSyncRequet.getContainerSyncInfoList().get(i).getEventId());
			Assert.assertEquals("UPDATE", pbSyncRequet.getContainerSyncInfoList().get(i).getCommand().name());
			Assert.assertEquals(userKey, pbSyncRequet.getContainerSyncInfoList().get(i).getExternalId());			
			Assert.assertEquals(tobeUpdateString, new String(pbSyncRequet.getContainerSyncInfoList().get(i).getTemplate().toByteArray()));
		}		
		Assert.assertEquals(biometorisRecordCout, jdbcTemplate.queryForObject("select count(\"BIOMETRICS_ID\") from \"PERSON_BIOMETRICS_1\"", Integer.class).intValue());
		Assert.assertEquals(changeId + 1,  jdbcTemplate.queryForObject("SELECT \"SEQUENCE_VALUE\" FROM \"SEQUENCE\" WHERE \"SEQUENCE_NAME\" = 'CHANGE_ID_SEQ'", Long.class).longValue());		
	}
	
	@Test
	public void testUpdateTemplate_eventId_null_rollback() {
		PBContainerSyncRequest pbSyncRequet = null;
		SyncResultWithStatus syncResultWithStatus = null;		
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		String tobeUpdateString = "zyxwvumlkjihjfedcba1234";
		byte[] tobeUpdateData = tobeUpdateString.getBytes();		
		
		long  biometricsId = jdbcTemplate.queryForObject("SELECT \"SEQUENCE_VALUE\" FROM \"SEQUENCE\" WHERE \"SEQUENCE_NAME\" = 'BIOMETRICS_ID_SEQ'", Long.class);	
		long changeId = jdbcTemplate.queryForObject("SELECT \"SEQUENCE_VALUE\" FROM \"SEQUENCE\" WHERE \"SEQUENCE_NAME\" = 'CHANGE_ID_SEQ'", Long.class);		

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "insert into \"PERSON_BIOMETRICS_1\" (\"BIOMETRICS_ID\",\"USER_KEY\", \"USER_EVENT_ID\", \"BIOMETRICS_DATA\", \"BIOMETRICS_DATA_LEN\", \"REGISTERED_TS\") values (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] {Long.valueOf(biometricsId + i), userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		syncResultWithStatus = dao.updateTemplate(-9999, userKey, null, tobeUpdateData);
		pbSyncRequet = syncResultWithStatus.getpBContainerSyncRequest();
		int biometorisRecordCout = jdbcTemplate.queryForObject("select count(\"BIOMETRICS_ID\") from \"PERSON_BIOMETRICS_1\"", Integer.class).intValue();

		Assert.assertNull(pbSyncRequet);
		Assert.assertEquals(changeId,  jdbcTemplate.queryForObject("SELECT \"SEQUENCE_VALUE\" FROM \"SEQUENCE\" WHERE \"SEQUENCE_NAME\" = 'CHANGE_ID_SEQ'", Long.class).longValue());
		Assert.assertEquals(biometorisRecordCout, jdbcTemplate.queryForObject("select count(\"BIOMETRICS_ID\") from \"PERSON_BIOMETRICS_1\"", Integer.class).intValue());
		PBServiceState syncStatus = syncResultWithStatus.getpBServiceState();
		Assert.assertNotNull(syncStatus);
		System.out.println(syncStatus.toString());		

	}
	
	@Test
	public void testUpdateTemplate_eventId_null_over_max_record() {
		PBContainerSyncRequest pbSyncRequet = null;	
		SyncResultWithStatus syncResultWithStatus = null;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		String tobeUpdateString = "zyxwvumlkjihjfedcba1234";
		byte[] tobeUpdateData = tobeUpdateString.getBytes();		
		
		long changeId = jdbcTemplate.queryForObject("SELECT \"SEQUENCE_VALUE\" FROM \"SEQUENCE\" WHERE \"SEQUENCE_NAME\" = 'CHANGE_ID_SEQ'", Long.class);
		long  biometricsId = jdbcTemplate.queryForObject("SELECT \"SEQUENCE_VALUE\" FROM \"SEQUENCE\" WHERE \"SEQUENCE_NAME\" = 'BIOMETRICS_ID_SEQ'", Long.class);	
		
		String updateContainersSql = "UPDATE \"CONTAINERS\" SET \"RECORD_COUNT\" = \"RECORD_COUNT\" + \"MAX_RECORD_COUNT\""		
			    + "where \"CONTAINER_ID\" = ?";
				jdbcTemplate.update(updateContainersSql, 1L);

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "insert into \"PERSON_BIOMETRICS_1\" (\"BIOMETRICS_ID\",\"USER_KEY\", \"USER_EVENT_ID\", \"BIOMETRICS_DATA\", \"BIOMETRICS_DATA_LEN\", \"REGISTERED_TS\") values (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] {Long.valueOf(biometricsId + i), userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		syncResultWithStatus = dao.updateTemplate(-9999, userKey, null, tobeUpdateData);
		pbSyncRequet = syncResultWithStatus.getpBContainerSyncRequest();
		int biometorisRecordCout = jdbcTemplate.queryForObject("select count(\"BIOMETRICS_ID\") from \"PERSON_BIOMETRICS_1\"", Integer.class).intValue();

		Assert.assertNull(pbSyncRequet);
		Assert.assertEquals(changeId,  jdbcTemplate.queryForObject("SELECT \"SEQUENCE_VALUE\" FROM \"SEQUENCE\" WHERE \"SEQUENCE_NAME\" = 'CHANGE_ID_SEQ'", Long.class).longValue());
		Assert.assertEquals(biometorisRecordCout, jdbcTemplate.queryForObject("select count(\"BIOMETRICS_ID\") from \"PERSON_BIOMETRICS_1\"", Integer.class).intValue());
		String sql = "select \"BIOMETRICS_ID\",\"USER_KEY\", \"USER_EVENT_ID\", \"BIOMETRICS_DATA\", \"BIOMETRICS_DATA_LEN\", \"REGISTERED_TS\" from \"PERSON_BIOMETRICS_1\"";
		List<Map<String, Object>> results = jdbcTemplate.queryForList(sql);
		long i = 0l;
		for (Map<String, Object> map : results) {			
			Assert.assertEquals(biometricsId + i++, map.get("biometrics_id"));
			Assert.assertEquals(userKey, (String)map.get("user_key"));
			Assert.assertEquals(i++, map.get("user_event_id"));
			Assert.assertEquals(sdata, (String)map.get("biometrics_data"));
			Assert.assertEquals(dataSize, ((Integer)map.get("biometrics_data_len")).intValue());
			Assert.assertEquals("2016/06/14", (String)map.get("registered_ts"));
		}
	}
	
	@Test
	public void testUpdateTemplate_eventId_notNull() {
		PBContainerSyncRequest pbSyncRequet = null;
		SyncResultWithStatus syncResultWithStatus = null;
		Integer containerId = 1;
		String userKey = "test";
		Integer eventId = 1;
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		String tobeUpdateString = "zyxwvumlkjihjfedcba1234";
		byte[] tobeUpdateData = tobeUpdateString.getBytes();		
	
		long  biometricsId = jdbcTemplate.queryForObject("SELECT \"SEQUENCE_VALUE\" FROM \"SEQUENCE\" WHERE \"SEQUENCE_NAME\" = 'BIOMETRICS_ID_SEQ'", Long.class);
		long changeId = jdbcTemplate.queryForObject("SELECT \"SEQUENCE_VALUE\" FROM \"SEQUENCE\" WHERE \"SEQUENCE_NAME\" = 'CHANGE_ID_SEQ'", Long.class);

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "INSERT INTO \"PERSON_BIOMETRICS_1\" (\"BIOMETRICS_ID\", \"USER_KEY\", \"USER_EVENT_ID\", \"BIOMETRICS_DATA\", \"BIOMETRICS_DATA_LEN\", \"REGISTERED_TS\") VALUES (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] {Long.valueOf(biometricsId + i), userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		int biometorisRecordCout = jdbcTemplate.queryForObject("select count(\"BIOMETRICS_ID\") from \"PERSON_BIOMETRICS_1\"", Integer.class).intValue();	
		syncResultWithStatus = dao.updateTemplate(containerId, userKey, eventId, tobeUpdateData);
		
		pbSyncRequet = syncResultWithStatus.getpBContainerSyncRequest();
		Assert.assertNotNull(pbSyncRequet);
		Assert.assertEquals(1, pbSyncRequet.getContainerSyncInfoList().size());

		Assert.assertEquals(containerId.intValue(), pbSyncRequet.getContainerId());
		Assert.assertEquals(1, pbSyncRequet.getContainerSyncInfoCount());
		Assert.assertEquals("CONTAINER_ASSIGNED", pbSyncRequet.getAssignedState().name());
		Assert.assertEquals(1, pbSyncRequet.getContainerSyncInfoList().get(0).getVersion());
		Assert.assertEquals(1, pbSyncRequet.getContainerSyncInfoList().get(0).getEventId());
		Assert.assertEquals("UPDATE", pbSyncRequet.getContainerSyncInfoList().get(0).getCommand().name());
		Assert.assertEquals(userKey, pbSyncRequet.getContainerSyncInfoList().get(0).getExternalId());
		Assert.assertEquals(tobeUpdateString, new String(pbSyncRequet.getContainerSyncInfoList().get(0).getTemplate().toByteArray()));
		Assert.assertEquals(changeId + 1,  jdbcTemplate.queryForObject("SELECT \"SEQUENCE_VALUE\" FROM \"SEQUENCE\" WHERE \"SEQUENCE_NAME\" = 'CHANGE_ID_SEQ'", Long.class).longValue());		
		
		Assert.assertEquals(biometorisRecordCout, jdbcTemplate.queryForObject("select count(\"BIOMETRICS_ID\") from \"PERSON_BIOMETRICS_1\"", Integer.class).intValue());
		
	}
	
	@Test
	public void testUpdateTemplate_eventId_notNull_rolback() {				
		String userKey = "test";
		Integer eventId = 1;
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		String tobeUpdateString = "zyxwvumlkjihjfedcba1234";
		byte[] tobeUpdateData = tobeUpdateString.getBytes();		
	
		long  biometricsId = jdbcTemplate.queryForObject("SELECT \"SEQUENCE_VALUE\" FROM \"SEQUENCE\" WHERE \"SEQUENCE_NAME\" = 'BIOMETRICS_ID_SEQ'", Long.class);
		long changeId = jdbcTemplate.queryForObject("SELECT \"SEQUENCE_VALUE\" FROM \"SEQUENCE\" WHERE \"SEQUENCE_NAME\" = 'CHANGE_ID_SEQ'", Long.class);
		int biometorisRecordCout = jdbcTemplate.queryForObject("select count(\"BIOMETRICS_ID\") from \"PERSON_BIOMETRICS_1\"", Integer.class).intValue();	
		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "INSERT INTO \"PERSON_BIOMETRICS_1\" (\"BIOMETRICS_ID\", \"USER_KEY\", \"USER_EVENT_ID\", \"BIOMETRICS_DATA\", \"BIOMETRICS_DATA_LEN\", \"REGISTERED_TS\") VALUES (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] {Long.valueOf(biometricsId + i), userKey, i + 1, data, dataSize, "2016/06/14" });
		}		
		dao.updateTemplate(-9999, userKey, eventId, tobeUpdateData);
		Assert.assertEquals(changeId ,  jdbcTemplate.queryForObject("SELECT \"SEQUENCE_VALUE\" FROM \"SEQUENCE\" WHERE \"SEQUENCE_NAME\" = 'CHANGE_ID_SEQ'", Long.class).longValue());
		Assert.assertEquals(biometorisRecordCout, jdbcTemplate.queryForObject("select count(\"BIOMETRICS_ID\") from \"PERSON_BIOMETRICS_1\"", Integer.class).intValue());
		String sql = "SELECT \"BIOMETRICS_ID\",\"USER_KEY\", \"USER_EVENT_ID\", \"BIOMETRICS_DATA\", \"BIOMETRICS_DATA_LEN\", \"REGISTERED_TS\" FROM \"PERSON_BIOMETRICS_1\"";
		List<Map<String, Object>> results = jdbcTemplate.queryForList(sql);
		long i = 0l;
		for (Map<String, Object> map : results) {			
			Assert.assertEquals(biometricsId + i++, map.get("biometrics_id"));
			Assert.assertEquals(userKey, (String)map.get("user_key"));
			Assert.assertEquals(i++, map.get("user_event_id"));
			Assert.assertEquals(sdata, (String)map.get("biometrics_data"));
			Assert.assertEquals(dataSize, ((Integer)map.get("biometrics_data_len")).intValue());
			Assert.assertEquals("2016/06/14", (String)map.get("registered_ts"));
		}	
	}

	@Test
	public void testUpdateTemplate_eventId_null_update_zero() {
		PBContainerSyncRequest pbSyncRequet = null;
		SyncResultWithStatus syncResultWithStatus = null;
		Integer containerId = 1;
		String userKey = "test";
		String tobeUpdateString = "zyxwvumlkjihjfedcba1234";
		byte[] tobeUpdateData = tobeUpdateString.getBytes();		

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");		

		syncResultWithStatus = dao.updateTemplate(containerId, userKey, null, tobeUpdateData);
		PBServiceState resultState = syncResultWithStatus.getpBServiceState();
		pbSyncRequet = syncResultWithStatus.getpBContainerSyncRequest();
		int biometorisRecordCout = jdbcTemplate.queryForObject("select count(\"BIOMETRICS_ID\") from \"PERSON_BIOMETRICS_1\"", Integer.class).intValue();		
		Assert.assertNotNull(resultState);
		Assert.assertNull(pbSyncRequet);
		Assert.assertEquals(ErrorDifinitions.DB_UPDATE_COUNT_ZERO.getStringCode(), resultState.getReason().getCode());
		Assert.assertEquals(ErrorDifinitions.DB_UPDATE_COUNT_ZERO.getDescriptionWithKey(containerId, userKey, null), resultState.getReason().getDescription());
		Assert.assertEquals(biometorisRecordCout, jdbcTemplate.queryForObject("select count(\"BIOMETRICS_ID\") from \"PERSON_BIOMETRICS_1\"", Integer.class).intValue());
	}
	
	@Test
	public void testUpdateTemplate_eventId_null_update_process_error_1() {
		PBContainerSyncRequest pbSyncRequet = null;
		SyncResultWithStatus syncResultWithStatus = null;		
		String userKey = "test";
		
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		String tobeUpdateString = "zyxwvumlkjihjfedcba1234";
		byte[] tobeUpdateData = tobeUpdateString.getBytes();
		
		
		long  biometricsId = jdbcTemplate.queryForObject("SELECT \"SEQUENCE_VALUE\" FROM \"SEQUENCE\" WHERE \"SEQUENCE_NAME\" = 'BIOMETRICS_ID_SEQ'", Long.class);

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "INSERT INTO \"PERSON_BIOMETRICS_1\" (\"BIOMETRICS_ID\", \"USER_KEY\", \"USER_EVENT_ID\", \"BIOMETRICS_DATA\", \"BIOMETRICS_DATA_LEN\", \"REGISTERED_TS\") VALUES (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] {Long.valueOf(biometricsId + i), userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		syncResultWithStatus = dao.updateTemplate(-9999, userKey, null, tobeUpdateData);
		PBServiceState resultState = syncResultWithStatus.getpBServiceState();
		pbSyncRequet = syncResultWithStatus.getpBContainerSyncRequest();
		int biometorisRecordCout = jdbcTemplate.queryForObject("select count(\"BIOMETRICS_ID\") from \"PERSON_BIOMETRICS_1\"", Integer.class).intValue();		
		Assert.assertNotNull(resultState);
		Assert.assertNull(pbSyncRequet);
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getStringCode(), resultState.getReason().getCode());
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getDescriptionWithKey(-9999, userKey, null), resultState.getReason().getDescription());
		Assert.assertEquals(biometorisRecordCout, jdbcTemplate.queryForObject("select count(\"BIOMETRICS_ID\") from \"PERSON_BIOMETRICS_1\"", Integer.class).intValue());
	}
	
	@Test
	public void testUpdateTemplate_eventId_null_update_process_error_2() {
		PBContainerSyncRequest pbSyncRequet = null;
		SyncResultWithStatus syncResultWithStatus = null;		
		String userKey = "test";
		
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		String tobeUpdateString = "zyxwvumlkjihjfedcba1234";
		byte[] tobeUpdateData = tobeUpdateString.getBytes();
		
		
		long  biometricsId = jdbcTemplate.queryForObject("SELECT \"SEQUENCE_VALUE\" FROM \"SEQUENCE\" WHERE \"SEQUENCE_NAME\" = 'BIOMETRICS_ID_SEQ'", Long.class);
	
		String insSql = "INSERT INTO \"PERSON_BIOMETRICS_1\" (\"BIOMETRICS_ID\", \"USER_KEY\", \"USER_EVENT_ID\", \"BIOMETRICS_DATA\", \"BIOMETRICS_DATA_LEN\", \"REGISTERED_TS\") VALUES (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] {Long.valueOf(biometricsId + i), userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		AIMrManger.saveTopersonBiometricsTabMap(1, "");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "");
		syncResultWithStatus = dao.updateTemplate(-9999, userKey, null, tobeUpdateData);
		PBServiceState resultState = syncResultWithStatus.getpBServiceState();
		pbSyncRequet = syncResultWithStatus.getpBContainerSyncRequest();
		int biometorisRecordCout = jdbcTemplate.queryForObject("select count(\"BIOMETRICS_ID\") from \"PERSON_BIOMETRICS_1\"", Integer.class).intValue();		
		Assert.assertNotNull(resultState);
		Assert.assertNull(pbSyncRequet);
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getStringCode(), resultState.getReason().getCode());
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getDescriptionWithKey(-9999, userKey, null), resultState.getReason().getDescription());
		Assert.assertEquals(biometorisRecordCout, jdbcTemplate.queryForObject("select count(\"BIOMETRICS_ID\") from \"PERSON_BIOMETRICS_1\"", Integer.class).intValue());
	}
	
	
	@Test
	public void testUpdateTemplate_eventId_notNull_update_zero() {
		PBContainerSyncRequest pbSyncRequet = null;
		SyncResultWithStatus syncResultWithStatus = null;
		Integer containerId = 1;
		String userKey = "test";
		Integer eventId = 1;
		String tobeUpdateString = "zyxwvumlkjihjfedcba1234";
		byte[] tobeUpdateData = tobeUpdateString.getBytes();

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		
		int biometorisRecordCout = jdbcTemplate.queryForObject("select count(\"BIOMETRICS_ID\") from \"PERSON_BIOMETRICS_1\"", Integer.class).intValue();

		syncResultWithStatus = dao.updateTemplate(containerId, userKey, eventId, tobeUpdateData);		
		
		PBServiceState resultState = syncResultWithStatus.getpBServiceState();
		pbSyncRequet = syncResultWithStatus.getpBContainerSyncRequest();
			
		Assert.assertNotNull(resultState);
		Assert.assertNull(pbSyncRequet);
		Assert.assertEquals(ErrorDifinitions.DB_UPDATE_COUNT_ZERO.getStringCode(), resultState.getReason().getCode());
		Assert.assertEquals(ErrorDifinitions.DB_UPDATE_COUNT_ZERO.getDescriptionWithKey(containerId, userKey, eventId), resultState.getReason().getDescription());
		Assert.assertEquals(biometorisRecordCout, jdbcTemplate.queryForObject("select count(\"BIOMETRICS_ID\") from \"PERSON_BIOMETRICS_1\"", Integer.class).intValue());
		
	}
	
	@Test
	public void testUpdateTemplate_eventId_notNull_update_process_error_1() {
		PBContainerSyncRequest pbSyncRequet = null;
		SyncResultWithStatus syncResultWithStatus = null;		
		String userKey = "test";
		Integer eventId = 1;
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		String tobeUpdateString = "zyxwvumlkjihjfedcba1234";
		byte[] tobeUpdateData = tobeUpdateString.getBytes();		
		
		long  biometricsId = jdbcTemplate.queryForObject("SELECT \"SEQUENCE_VALUE\" FROM \"SEQUENCE\" WHERE \"SEQUENCE_NAME\" = 'BIOMETRICS_ID_SEQ'", Long.class);

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "INSERT INTO \"PERSON_BIOMETRICS_1\" (\"BIOMETRICS_ID\", \"USER_KEY\", \"USER_EVENT_ID\", \"BIOMETRICS_DATA\", \"BIOMETRICS_DATA_LEN\", \"REGISTERED_TS\") VALUES (?, ?, ?, ?, ?, ?)";
		int biometorisRecordCout = jdbcTemplate.queryForObject("select count(\"BIOMETRICS_ID\") from \"PERSON_BIOMETRICS_1\"", Integer.class).intValue();
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] {Long.valueOf(biometricsId + i), userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		
		syncResultWithStatus = dao.updateTemplate(-9999, userKey, eventId, tobeUpdateData);		
		
		PBServiceState resultState = syncResultWithStatus.getpBServiceState();
		pbSyncRequet = syncResultWithStatus.getpBContainerSyncRequest();
			
		Assert.assertNotNull(resultState);
		Assert.assertNull(pbSyncRequet);
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getStringCode(), resultState.getReason().getCode());
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getDescriptionWithKey(-9999, userKey, eventId), resultState.getReason().getDescription());
		Assert.assertEquals(biometorisRecordCout, jdbcTemplate.queryForObject("select count(\"BIOMETRICS_ID\") from \"PERSON_BIOMETRICS_1\"", Integer.class).intValue());
		
	}
	
	@Test
	public void testUpdateTemplate_eventId_notNull_update_process_error_2() {
		PBContainerSyncRequest pbSyncRequet = null;
		SyncResultWithStatus syncResultWithStatus = null;		
		String userKey = "test";
		Integer containerId = 1;
		Integer eventId = 1;
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		String tobeUpdateString = "zyxwvumlkjihjfedcba1234";
		byte[] tobeUpdateData = tobeUpdateString.getBytes();		
		
		long  biometricsId = jdbcTemplate.queryForObject("SELECT \"SEQUENCE_VALUE\" FROM \"SEQUENCE\" WHERE \"SEQUENCE_NAME\" = 'BIOMETRICS_ID_SEQ'", Long.class);
	
		String insSql = "INSERT INTO \"PERSON_BIOMETRICS_1\" (\"BIOMETRICS_ID\", \"USER_KEY\", \"USER_EVENT_ID\", \"BIOMETRICS_DATA\", \"BIOMETRICS_DATA_LEN\", \"REGISTERED_TS\") VALUES (?, ?, ?, ?, ?, ?)";
		int biometorisRecordCout = jdbcTemplate.queryForObject("select count(\"BIOMETRICS_ID\") from \"PERSON_BIOMETRICS_1\"", Integer.class).intValue();
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] {Long.valueOf(biometricsId + i), userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		AIMrManger.saveTopersonBiometricsTabMap(1, "");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "");
		
		syncResultWithStatus = dao.updateTemplate(containerId, userKey, eventId, tobeUpdateData);		
		
		PBServiceState resultState = syncResultWithStatus.getpBServiceState();
		pbSyncRequet = syncResultWithStatus.getpBContainerSyncRequest();
			
		Assert.assertNotNull(resultState);
		Assert.assertNull(pbSyncRequet);
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getStringCode(), resultState.getReason().getCode());
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getDescriptionWithKey(containerId, userKey, eventId), resultState.getReason().getDescription());
		Assert.assertEquals(biometorisRecordCout, jdbcTemplate.queryForObject("select count(\"BIOMETRICS_ID\") from \"PERSON_BIOMETRICS_1\"", Integer.class).intValue());		
	}	
	
	
	private void recoverConatainerData() {
		String sql = "UPDATE \"CONTAINERS\" SET \"TEMPLATE_SIZE\" =15680 ,\"VERSION\"=0 ,\"RECORD_COUNT\"=0 WHERE \"CONTAINER_ID\"=1";
		jdbcTemplate.update(sql);
		jdbcTemplate.execute("COMMIT");
	}
}
