package jp.co.nec.aimr.agent;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TestWaitNotify {
	private static final ExecutorService unitExecutor = Executors.newFixedThreadPool(5);
	private final static Object locker = new Object();

	public TestWaitNotify() {
	}

	public void test() {
		for (int i = 0; i < 5; i++) {
			unitExecutor.submit(new Child());
		}
	}

	public static void main(String[] args) {
		TestWaitNotify tn = new TestWaitNotify();
		tn.test();
		synchronized (locker) {
			locker.notify();
		}
		try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		unitExecutor.shutdown();
	}

	public class Child implements Runnable {
		public void test() {
			synchronized (locker) {
				try {
					locker.wait(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			System.out.println(Thread.currentThread().getName() + " wakuped!");
		}

		@Override
		public void run() {
			test();
		}
	}
}