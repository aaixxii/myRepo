package jp.co.nec.aimr.agent;

import jp.co.nec.aimr.common.UnitCard;

public class Parent {
	private static UnitCard unit;

	private void gnerate() {
		for (int i = 0; i < 5; i++) {
			unit = new UnitCard();
			unit.setUnitId(1l + i);			
			unit.setUniqueKey("url and port");

			Childs tester = new Childs(unit);
			Thread th = new Thread(tester);
			th.start();
		}
	}

	public static void main(String[] args) {
		Parent pt = new Parent();
		pt.gnerate();
	}

}