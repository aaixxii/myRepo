package jp.co.nec.aimr.agent;

public class EuSender {

	public static void main(String[] args) {
		EuClinet client = new EuClinet();
		client.run();

	}

}
