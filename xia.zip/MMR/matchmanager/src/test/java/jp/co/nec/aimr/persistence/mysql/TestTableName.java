package jp.co.nec.aimr.persistence.mysql;

import javax.annotation.Resource;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import jp.co.nec.aimr.common.ProtobufUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationMysqlContext.xml" })
@Transactional
public class TestTableName {

	@Resource
	private DataSource ds;

	@Test
	public void testGetTableName() {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
		Integer containerId = 1;
		// String timeSql = "SELECT TO_CHAR(SYSTIMESTAMP, 'yyyy/mm/dd
		// hh24:mi:ss.ff3') FROM DUAL";
		String currentTime = ProtobufUtil.getCurrentTime();
		String getPersonBioTableName = "SELECT CONTAINER_TABLE_NAME FROM CONTAINERS WHERE CONTAINER_ID = ?";
		String personBioTableName = jdbcTemplate.queryForObject(getPersonBioTableName, new Object[] { containerId },
				String.class);

		String sql = String.format("insert into  %s values (?,?,?,?,?,?)", personBioTableName);
		String data = "abcedef";

		jdbcTemplate.update(sql, new Object[] { 10, "s", 1, data.getBytes(), 4, currentTime });
		jdbcTemplate.execute("COMMIT");
	}

	@Test
	public void testGetTableName1() {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
		Integer containerId = 1;
		// String timeSql = "SELECT TO_CHAR(SYSTIMESTAMP, 'yyyy/mm/dd
		// hh24:mi:ss.ff3') FROM DUAL";
		String currentTime = ProtobufUtil.getCurrentTime();
		String getPersonBioTableName = "SELECT CONTAINER_TABLE_NAME FROM CONTAINERS WHERE CONTAINER_ID = ?";
		String personBioTableName = jdbcTemplate.queryForObject(getPersonBioTableName, new Object[] { containerId },
				String.class);
		String insertPbSql = "insert into  $TABLENAME values (?,?,?,?,?,?)";
		String query = insertPbSql.replace("$TABLENAME", personBioTableName);
		// String sql = String.format("insert into %s values (?,?,?,?,?)",
		// personBioTableName);
		String data = "abcedef";

		jdbcTemplate.update(query, new Object[] { 20, "t", 2, data.getBytes(), 4, currentTime });
		System.out.print("OKOK");
	}
}
