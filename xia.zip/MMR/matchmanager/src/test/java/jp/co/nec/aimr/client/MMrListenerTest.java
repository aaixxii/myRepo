package jp.co.nec.aimr.client;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import jp.co.nec.aimr.agent.AimRSocketServer;
import jp.co.nec.aimr.common.XmlUtil;
import jp.co.nec.aimr.management.AIMrManger;
import jp.co.nec.aimr.persistence.aimdb.DataBaseUtil;
import jp.co.nec.aimr.properties.PropertyUtil;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
public class MMrListenerTest {
	
	@Resource
	private DataSource ds;
	
	@Autowired
	private MMrListener mMrListener;	

	private MockUp<DataBaseUtil> dataBaseUtilMock;
	private MockUp<PropertyUtil> propertyUtilMock;
	private MockUp<AIMrManger> aIMrMangerMock;
	private MockUp<XmlUtil> xmlUtilMock;
	

	@Before
	public void setUp() throws Exception {
		dataBaseUtilMock = new MockUp<DataBaseUtil>() {
			@Mock
			public DataSource lookupDataSource() {
				return ds;
			}
		};
		propertyUtilMock = new MockUp<PropertyUtil>() {
			@Mock
			public Integer getPropertyIntValue(String name) {
				return 30;
			}
			@Mock
			public String getPropertyValue(String name) {
				return "Oracle";
			}
		};

		aIMrMangerMock = new MockUp<AIMrManger>() {
			@Mock
			private void init() {
				return;
			}
			
			@Mock
			public ExecutorService getUnitReceiveExecutor() {
				ExecutorService service = Executors.newFixedThreadPool(1);
				return service;
			}
			
			@Mock
			public  String getDB_DRIVER() {				
				return "Oracle";
			}			
		};
		
		xmlUtilMock = new MockUp<XmlUtil>() {
			@Mock
			 public  void setResourceRef(String dbName) {
				return ;
			}
		};
	
	}

	@After
	public void tearDown() throws Exception {
		dataBaseUtilMock.tearDown();
		propertyUtilMock.tearDown();
		aIMrMangerMock.tearDown();
		xmlUtilMock.tearDown();		
	}

	@Test
	public void testContextInitialized() {	
		MockUp<AimRSocketServer> agent = new MockUp<AimRSocketServer>() {
			@Mock
			private void init() {
				return;
			}
			@Mock
			public void run() {
				return;
			}
		};
		
		mMrListener.contextInitialized(null);
		agent.tearDown();
	}

	@Test
	public void testContextDestroyed() {
		mMrListener.contextDestroyed(null);
	}
}
