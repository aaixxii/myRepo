package jp.co.nec.aimr.exception;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import jp.co.nec.aimr.common.ErrorDifinitions;

public class AimRuntimeExceptionTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAimRuntimeException() {
		AimRuntimeException aimException = new AimRuntimeException();
		Assert.assertNotNull(aimException);
		Assert.assertTrue(aimException instanceof AimRuntimeException);
	}

	@Test
	public void testAimRuntimeExceptionString() {
		AimRuntimeException aimException = new AimRuntimeException("aim exception happend.");
		Assert.assertNotNull(aimException);
		Assert.assertTrue(aimException instanceof AimRuntimeException);		
	}

	@Test
	public void testAimRuntimeExceptionThrowable() {
		Throwable e = new Throwable();
		AimRuntimeException aimException = new AimRuntimeException(e);
		Assert.assertNotNull(aimException);
		Assert.assertTrue(aimException instanceof AimRuntimeException);		
	}

	@Test
	public void testAimRuntimeExceptionStringThrowable() {
		String eMsg = "aim exception happend.";
		Throwable e = new Throwable();
		AimRuntimeException aimException = new AimRuntimeException(eMsg, e);
		Assert.assertNotNull(aimException);
		Assert.assertTrue(aimException instanceof AimRuntimeException);
		
		
	}

	@Test
	public void testAimRuntimeExceptionErrorDifinitions() {
		ErrorDifinitions es = ErrorDifinitions.DB_PROCESS_ERROR;
		AimRuntimeException aimException = new AimRuntimeException(es);
		Assert.assertNotNull(aimException);
		Assert.assertTrue(aimException instanceof AimRuntimeException);		
	}
}
