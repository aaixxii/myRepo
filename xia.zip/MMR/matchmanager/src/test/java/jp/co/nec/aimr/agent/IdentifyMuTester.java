package jp.co.nec.aimr.agent;

import com.google.protobuf.ByteString;

import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryJobInfo;
import jp.co.nec.aim.message.proto.InquiryService.PBIdentifyRequest;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobRequest;

public class IdentifyMuTester {

	public static void main(String[] args) {

		AimrHttpClientUtil util = new AimrHttpClientUtil();
		String postUrl = "http://10.197.23.100:8080/matchmanager/AIMInquiryService/identify";
		PBIdentifyRequest jobRequst = CreateInquiryJobRequst();
		byte[] byteJobRespose = null;
		for (int i = 0; i < 10; i++) {
			byteJobRespose = util.postByteData(postUrl, jobRequst.toByteArray());
			// PBInquiryJobResult pbResult =
			// PBInquiryJobResult.parseFrom(byteJobRespose);
			assert byteJobRespose != null;
		}
	}

	private static PBIdentifyRequest CreateInquiryJobRequst() {		
		PBIdentifyRequest.Builder pbIdentiyReq = PBIdentifyRequest.newBuilder();
		//PBExtractInputPayload.Builder pbExtPayload = PBExtractInputPayload.newBuilder();
		//PBCMLOptions.Builder pmCm = PBCMLOptions.newBuilder();
		// pmCm.setRotationLimit(Pc2RotationLimitType.PC2_ROTATION_DEGREE_15);
		// pmCm.setParameterId(1);
		// pbIdentiyReq.setExtractInputPayload(pbExtPayload);
		PBInquiryJobRequest.Builder jobRequest = PBInquiryJobRequest.newBuilder();
		PBInquiryJobInfo.Builder info = PBInquiryJobInfo.newBuilder();
		info.setContainerId(1);
		info.setMaxCandidate(100);
		jobRequest.setJobInfo(info);
		jobRequest.setTemplate(ByteString.copyFrom("abcedefjhigklmnoprqstuvwxyz".getBytes()));		
		pbIdentiyReq.setInquiryJobRequest(jobRequest);
		 return pbIdentiyReq.build();
//	
	}

}
