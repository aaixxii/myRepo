package jp.co.nec.aimr.client;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import javax.servlet.ServletException;

import org.apache.http.HttpStatus;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;

import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceStateReason;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputPayload;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBVerifyDataInfo;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBVerifyJobInfo;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBVerifyJobInput;
import jp.co.nec.aim.message.proto.InquiryService.PBVerifyRequest;
import jp.co.nec.aim.message.proto.InquiryService.PBVerifyResponse;
import jp.co.nec.aimr.common.ErrorDifinitions;
import jp.co.nec.aimr.event.EventNotifier;
import jp.co.nec.aimr.management.AIMrManger;
import jp.co.nec.aimr.properties.PropertyUtil;
import jp.co.nec.aimr.service.verity.VerityService;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/applicationContext.xml" })
public class VerifyServletTest {
	private static final String VERIFY_URL = "/AIMInquiryService/verify";
	@Autowired
	private VerifyServlet verifyServlet;
	
	private MockUp<PropertyUtil> propertyUtilMock;
	private MockUp<AIMrManger> aIMrMangerMock;


	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		propertyUtilMock = new MockUp<PropertyUtil>() {
			@Mock
			public void $init() {
				return;
			}
			@Mock
			public PropertyUtil getInstance() {
				return new PropertyUtil();
			}
			@Mock
			public Integer getPropertyIntValue(String name) {
				return 300;
			}
			
			@Mock
			public Long getPropertyLongValue(String name) {
				return 400L;
			}
			
			@Mock
			public String getPropertyValue(String name) {
				return "Oracle";
			}
		};
		aIMrMangerMock = new MockUp<AIMrManger>() {
			@Mock
			private void init() {
				return;
			}
			@Mock
			public String getDB_DRIVER() {
				return "Oracle";
			}
		};
	}

	@After
	public void tearDown() throws Exception {
		propertyUtilMock.tearDown();
		aIMrMangerMock.tearDown();
	}
	
	@Test
	public void testDoPostVerify_OK() {		
		MockUp<VerityService> verifyMock = new MockUp<VerityService>() {
			@Mock
			private PBVerifyResponse doVerify() {
				return createPBVerifyResponse(ServiceStateType.SERVICE_STATE_SUCCESS, null);
			}
		};	

		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		PBVerifyRequest verifyJobReq = createPBVerifyRequest();
		req.setRequestURI(VERIFY_URL);
		req.setContent(verifyJobReq.toByteArray());
		try {
			verifyServlet.doPost(req, res);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBVerifyResponse pBVerifyResponse = null;
		try {
			pBVerifyResponse = PBVerifyResponse.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Assert.assertNotNull(pBVerifyResponse);
		ServiceStateType state = pBVerifyResponse.getServiceState().getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, state);
		 verifyMock.tearDown();	
	}
	
	@Test
	public void testDoPostVerify_error() {		
		MockUp<VerityService> verifyMock = new MockUp<VerityService>() {
			@Mock
			private PBVerifyResponse doVerify() {
				return createPBVerifyResponse(ServiceStateType.SERVICE_STATE_ERROR, null);
			}
		};	

		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		PBVerifyRequest verifyJobReq = createPBVerifyRequest();
		req.setRequestURI(VERIFY_URL);
		req.setContent(verifyJobReq.toByteArray());
		try {
			verifyServlet.doPost(req, res);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBVerifyResponse pBVerifyResponse = null;
		try {
			pBVerifyResponse = PBVerifyResponse.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Assert.assertNotNull(pBVerifyResponse);
		ServiceStateType state = pBVerifyResponse.getServiceState().getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state);
		 verifyMock.tearDown();	
	}
	
	@Test
	public void testDoPostVerify_no_active_eu() {		
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		PBVerifyRequest verifyJobReq = createPBVerifyRequest();
		req.setRequestURI(VERIFY_URL);
		req.setContent(verifyJobReq.toByteArray());
		try {
			verifyServlet.doPost(req, res);

		} catch (IOException e) {			
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBVerifyResponse pBVerifyResponse = null;
		try {
			pBVerifyResponse = PBVerifyResponse.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {			
			e.printStackTrace();
		}

		Assert.assertNotNull(pBVerifyResponse);
		ServiceStateType state = pBVerifyResponse.getServiceState().getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, state);
		String code = pBVerifyResponse.getServiceState().getReason().getCode();
		String description = pBVerifyResponse.getServiceState().getReason().getDescription();
		Assert.assertEquals(ErrorDifinitions.VERIFY_JOB_NO_ACTIVE_EU.getStringCode(), code);
		Assert.assertEquals(ErrorDifinitions.VERIFY_JOB_NO_ACTIVE_EU.getDescriptionWithKey(null, null, null), description);		 	
	}
	
	@Test
	public void testDoPostVerify_timeout() {	
		
		MockUp<EventNotifier> notifer = new MockUp<EventNotifier>() {
			@Mock
			public void fireOnVerifyJobqueueing(Long verifyJobId) {
				return;
			}
		};
		
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		PBVerifyRequest verifyJobReq = createPBVerifyRequest();
		req.setRequestURI(VERIFY_URL);
		req.setContent(verifyJobReq.toByteArray());
		try {
			verifyServlet.doPost(req, res);

		} catch (IOException e) {			
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBVerifyResponse pBVerifyResponse = null;
		try {
			pBVerifyResponse = PBVerifyResponse.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {			
			e.printStackTrace();
		}

		Assert.assertNotNull(pBVerifyResponse);
		ServiceStateType state = pBVerifyResponse.getServiceState().getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, state);
		String code = pBVerifyResponse.getServiceState().getReason().getCode();
		String description = pBVerifyResponse.getServiceState().getReason().getDescription();
		Assert.assertEquals(ErrorDifinitions.VERIFY_JOB_TIMEOUT.getStringCode(), code);
		String ts = ErrorDifinitions.VERIFY_JOB_TIMEOUT.getDescriptionWithKey(null, null, null);
		Assert.assertEquals(ts, description);
		notifer.tearDown();
	}
	
	@Test
	public void testDoPostVerify_query_no_image_no_template() {
		
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		PBVerifyRequest verifyJobReq = createPBVerifyRequest_query_no_image_no_template();
		req.setRequestURI(VERIFY_URL);
		req.setContent(verifyJobReq.toByteArray());
		try {
			verifyServlet.doPost(req, res);

		} catch (IOException e) {			
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBVerifyResponse pBVerifyResponse = null;
		try {
			pBVerifyResponse = PBVerifyResponse.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {			
			e.printStackTrace();
		}

		Assert.assertNotNull(pBVerifyResponse);
		ServiceStateType state = pBVerifyResponse.getServiceState().getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state);
		String code = pBVerifyResponse.getServiceState().getReason().getCode();
		String description = pBVerifyResponse.getServiceState().getReason().getDescription();
		Assert.assertEquals(ErrorDifinitions.VERIFY_NO_IMAGE_AND_NO_TEMPLATE.getStringCode(), code);
		Assert.assertEquals(ErrorDifinitions.VERIFY_NO_IMAGE_AND_NO_TEMPLATE.getDescription(), description);		
	}
	
	@Test
	public void testDoPostVerify_query_no_target() {
		
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		PBVerifyRequest verifyJobReq = createPBVerifyRequest_no_target();
		req.setRequestURI(VERIFY_URL);
		req.setContent(verifyJobReq.toByteArray());
		try {
			verifyServlet.doPost(req, res);

		} catch (IOException e) {			
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBVerifyResponse pBVerifyResponse = null;
		try {
			pBVerifyResponse = PBVerifyResponse.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {			
			e.printStackTrace();
		}

		Assert.assertNotNull(pBVerifyResponse);
		ServiceStateType state = pBVerifyResponse.getServiceState().getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state);
		String code = pBVerifyResponse.getServiceState().getReason().getCode();
		String description = pBVerifyResponse.getServiceState().getReason().getDescription();
		Assert.assertEquals(ErrorDifinitions.VERIFY_TARGET_IS_NULL.getStringCode(), code);
		Assert.assertEquals(ErrorDifinitions.VERIFY_TARGET_IS_NULL.getDescription(), description);		
	}
	
	@Test
	public void testDoPostVerify_query_no_template() {
		
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		PBVerifyRequest verifyJobReq = createPBVerifyRequest_no_target();
		req.setRequestURI(VERIFY_URL);
		req.setContent(verifyJobReq.toByteArray());
		try {
			verifyServlet.doPost(req, res);

		} catch (IOException e) {			
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBVerifyResponse pBVerifyResponse = null;
		try {
			pBVerifyResponse = PBVerifyResponse.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {			
			e.printStackTrace();
		}

		Assert.assertNotNull(pBVerifyResponse);
		ServiceStateType state = pBVerifyResponse.getServiceState().getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state);
		String code = pBVerifyResponse.getServiceState().getReason().getCode();
		String description = pBVerifyResponse.getServiceState().getReason().getDescription();
		Assert.assertEquals(ErrorDifinitions.VERIFY_TARGET_IS_NULL.getStringCode(), code);
		Assert.assertEquals(ErrorDifinitions.VERIFY_TARGET_IS_NULL.getDescription(), description);		
	}
	
	@Test
	public void testDoPostVerify_query_target_no_template_noimage_nokey() {
		
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		PBVerifyRequest verifyJobReq = createPBVerifyRequest_target_no_image_nokey_noTemplate();
		req.setRequestURI(VERIFY_URL);
		req.setContent(verifyJobReq.toByteArray());
		try {
			verifyServlet.doPost(req, res);

		} catch (IOException e) {			
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBVerifyResponse pBVerifyResponse = null;
		try {
			pBVerifyResponse = PBVerifyResponse.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {			
			e.printStackTrace();
		}

		Assert.assertNotNull(pBVerifyResponse);
		ServiceStateType state = pBVerifyResponse.getServiceState().getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state);
		String code = pBVerifyResponse.getServiceState().getReason().getCode();
		String description = pBVerifyResponse.getServiceState().getReason().getDescription();
		Assert.assertEquals(ErrorDifinitions.VERIFY_TARGET_NO_IMAGE_AND_NO_TEMPLATE_NO_KEY.getStringCode(), code);
		Assert.assertEquals(ErrorDifinitions.VERIFY_TARGET_NO_IMAGE_AND_NO_TEMPLATE_NO_KEY.getDescription(), description);		
	}
	
	@Test
	public void testDoPostVerify_notSupport() {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		PBVerifyRequest verifyJobReq = createPBVerifyRequest();
		req.setRequestURI("/AIMInquiryService/verifys");
		req.setContent(verifyJobReq.toByteArray());
		try {
			verifyServlet.doPost(req, res);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_METHOD_NOT_ALLOWED);
	}
	
	@Test
	public void testDoGet() {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		PBVerifyRequest verifyJobReq = createPBVerifyRequest();
		req.setRequestURI(VERIFY_URL);
		req.setContent(verifyJobReq.toByteArray());
		
		try {
			verifyServlet.doGet(req, res);
		} catch (ServletException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_METHOD_NOT_ALLOWED);
	}
	
	@Test
	public void testDoGet_unkown() {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		PBVerifyRequest verifyJobReq = createPBVerifyRequest();
		req.setRequestURI("/AIMInquiryService/verifys");
		req.setContent(verifyJobReq.toByteArray());
		
		try {
			verifyServlet.doGet(req, res);
		} catch (ServletException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_BAD_REQUEST);
	}
	
	
	
	private PBVerifyRequest createPBVerifyRequest_no_target() {
		PBVerifyRequest.Builder pBVerifyRequest = PBVerifyRequest.newBuilder();
		PBVerifyJobInput.Builder pBVerifyJobInput = PBVerifyJobInput.newBuilder();
		PBVerifyJobInfo.Builder pBVerifyJobInfo = PBVerifyJobInfo.newBuilder();
		PBExtractInputPayload.Builder pBExtractInputPayload = PBExtractInputPayload.newBuilder();		
		PBVerifyDataInfo.Builder pBVerifyDataInfo = PBVerifyDataInfo.newBuilder();
		pBVerifyDataInfo.setImage(pBExtractInputPayload);
		pBVerifyDataInfo.setTemplate(ByteString.copyFrom("I am a image date".getBytes()));
		pBVerifyJobInput.setQuery(pBVerifyDataInfo);
		pBVerifyJobInfo.setContainerId(1);
		pBVerifyRequest.setJobInfo(pBVerifyJobInfo.build());
		pBVerifyRequest.setJobInput(pBVerifyJobInput.build());
		return pBVerifyRequest.build();
	}
	
	private PBVerifyRequest createPBVerifyRequest_query_no_image_no_template() {
		PBVerifyRequest.Builder pBVerifyRequest = PBVerifyRequest.newBuilder();
		PBVerifyJobInput.Builder pBVerifyJobInput = PBVerifyJobInput.newBuilder();
		PBVerifyJobInfo.Builder pBVerifyJobInfo = PBVerifyJobInfo.newBuilder();
		PBExtractInputPayload.Builder pBExtractInputPayload = PBExtractInputPayload.newBuilder();		
		PBVerifyDataInfo.Builder pBVerifyDataInfo = PBVerifyDataInfo.newBuilder();
		//pBVerifyDataInfo.setImage(pBExtractInputPayload);
		//pBVerifyDataInfo.setTemplate(ByteString.copyFrom("I am a image date".getBytes()));		
		PBVerifyDataInfo.Builder targetVerifyDataInfo = PBVerifyDataInfo.newBuilder();
		targetVerifyDataInfo.setImage(pBExtractInputPayload);
		targetVerifyDataInfo.setTemplate(ByteString.copyFrom("I am a image date".getBytes()));
		pBVerifyJobInput.addTarget(targetVerifyDataInfo.build());
		pBVerifyJobInput.setQuery(pBVerifyDataInfo);
		pBVerifyJobInfo.setContainerId(1);
		pBVerifyRequest.setJobInfo(pBVerifyJobInfo.build());
		pBVerifyRequest.setJobInput(pBVerifyJobInput.build());
		return pBVerifyRequest.build();
		
	}
	
	private PBVerifyRequest createPBVerifyRequest_target_no_image_nokey_noTemplate() {
		PBVerifyRequest.Builder pBVerifyRequest = PBVerifyRequest.newBuilder();
		PBVerifyJobInput.Builder pBVerifyJobInput = PBVerifyJobInput.newBuilder();
		PBVerifyJobInfo.Builder pBVerifyJobInfo = PBVerifyJobInfo.newBuilder();
		PBExtractInputPayload.Builder pBExtractInputPayload = PBExtractInputPayload.newBuilder();		
		PBVerifyDataInfo.Builder pBVerifyDataInfo = PBVerifyDataInfo.newBuilder();
		pBVerifyDataInfo.setImage(pBExtractInputPayload);
		pBVerifyDataInfo.setTemplate(ByteString.copyFrom("I am a image date".getBytes()));		
		PBVerifyDataInfo.Builder targetVerifyDataInfo = PBVerifyDataInfo.newBuilder();		
		pBVerifyJobInput.addTarget(targetVerifyDataInfo.build());
		pBVerifyJobInput.setQuery(pBVerifyDataInfo);
		pBVerifyJobInfo.setContainerId(1);
		pBVerifyRequest.setJobInfo(pBVerifyJobInfo.build());
		pBVerifyRequest.setJobInput(pBVerifyJobInput.build());
		return pBVerifyRequest.build();
	}
	
	private PBVerifyRequest createPBVerifyRequest() {
		PBVerifyRequest.Builder pBVerifyRequest = PBVerifyRequest.newBuilder();
		PBVerifyJobInput.Builder pBVerifyJobInput = PBVerifyJobInput.newBuilder();
		PBVerifyJobInfo.Builder pBVerifyJobInfo = PBVerifyJobInfo.newBuilder();
		PBExtractInputPayload.Builder pBExtractInputPayload = PBExtractInputPayload.newBuilder();		
		PBVerifyDataInfo.Builder pBVerifyDataInfo = PBVerifyDataInfo.newBuilder();
		pBVerifyDataInfo.setImage(pBExtractInputPayload);
		pBVerifyDataInfo.setTemplate(ByteString.copyFrom("I am a image date".getBytes()));		
		PBVerifyDataInfo.Builder targetVerifyDataInfo = PBVerifyDataInfo.newBuilder();
		targetVerifyDataInfo.setImage(pBExtractInputPayload);
		targetVerifyDataInfo.setTemplate(ByteString.copyFrom("I am a image date".getBytes()));
		pBVerifyJobInput.addTarget(targetVerifyDataInfo.build());
		pBVerifyJobInput.setQuery(pBVerifyDataInfo);
		pBVerifyJobInfo.setContainerId(1);
		pBVerifyRequest.setJobInfo(pBVerifyJobInfo.build());
		pBVerifyRequest.setJobInput(pBVerifyJobInput.build());
		return pBVerifyRequest.build();
	}
	
	private PBVerifyResponse createPBVerifyResponse(ServiceStateType type, ErrorDifinitions errDifinition) {
		PBVerifyResponse.Builder pBVerifyResponse = PBVerifyResponse.newBuilder();
		PBServiceState.Builder pBServiceState = PBServiceState.newBuilder();
		PBServiceStateReason.Builder pBServiceStateReason = PBServiceStateReason.newBuilder();
		pBServiceState.setState(type);		
		if (errDifinition != null) {
			pBServiceStateReason.setCode(errDifinition.getStringCode());
			pBServiceStateReason.setDescription(errDifinition.getDescription());
			pBServiceState.setReason(pBServiceStateReason);
		}		
		pBVerifyResponse.setServiceState(pBServiceState);
		return pBVerifyResponse.build();
		
	}



}
