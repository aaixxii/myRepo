package jp.co.nec.aimr.service.template;

import java.io.IOException;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractJobResult;
import jp.co.nec.aim.message.proto.SyncEnumTypes.SyncFunctionType;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest;
import jp.co.nec.aimr.common.ErrorDifinitions;
import jp.co.nec.aimr.management.AIMrManger;
import jp.co.nec.aimr.persistence.aimdb.DataBaseUtil;
import jp.co.nec.aimr.persistence.aimdb.SyncResultWithStatus;
import jp.co.nec.aimr.properties.PropertyUtil;
import jp.co.nec.aimr.service.extract.ExtractService;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/applicationContext.xml" })
public class SyncTemplateServiceUpdateTest {
	
	private SyncTemplateTestUtil util;
	
	@Resource
	private DataSource ds;	
	
	private MockUp<DataBaseUtil> dataBaseUtilMock;
	private MockUp<PropertyUtil> propertyUtilMock;
	private MockUp<AIMrManger> aIMrMangerMock;

	@Before
	public void setUp() throws Exception {
		util = new SyncTemplateTestUtil();
		dataBaseUtilMock = new MockUp<DataBaseUtil>() {
			@Mock
			public DataSource lookupDataSource() {
				return ds;
			}
		};
		propertyUtilMock = 
		new MockUp<PropertyUtil>() {
			@Mock
			public void $init() {
				return;
			}
			@Mock
			public PropertyUtil getInstance() {
				return new PropertyUtil();
			}
			@Mock
			public Integer getPropertyIntValue(String name) {
				return 300;
			}
			
			@Mock
			public Long getPropertyLongValue(String name) {
				return 400L;
			}
			
			@Mock
			public String getPropertyValue(String name) {
				return "Oracle";
			}
		};
		
		aIMrMangerMock =
				new MockUp<AIMrManger>() {
			@Mock
			private void init() {
				return;
			}			
			@Mock
			public String getDB_DRIVER() {
				return "postgresql";
			}
		};		
	}

	@After
	public void tearDown() throws Exception {
		dataBaseUtilMock.tearDown();
		propertyUtilMock.tearDown();
		aIMrMangerMock.tearDown();
		util = null;
	}
	
	@Test
	public void testSyncTemplateService() {
		Integer containerId = 1;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();		
		Integer eventId = 1;
		SyncTemplateService service = new SyncTemplateService(util.createPBSyncJobRequestWithTemplate(SyncFunctionType.UPDATE, containerId, userKey, eventId, data));
		Assert.assertNotNull(service);
		Assert.assertTrue(service instanceof SyncTemplateService);		
	}
	
	@Test
	public void testProcessSyncRequest_no_eventid_hasTemplate_update_exception() throws IOException {
		MockUp<ExtractService> extMocker = new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return util.createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};

		MockUp<SyncTemplateService> syncMocker = new MockUp<SyncTemplateService>() {
			@Mock
			private SyncResultWithStatus doUpdateWithTemplete(JdbcTemplate jdbcTemplate, PBSyncJobRequest synJobRequest) {
				return util.creatSyncResultWithStatus(ServiceStateType.SERVICE_STATE_SUCCESS, 1l);
			}
		};

		Integer containerId = 1;
		String userKey = "test";		

		SyncTemplateService service = new SyncTemplateService(util.createPBSyncJobRequestNoTemplateNoPayload(SyncFunctionType.UPDATE, containerId, userKey, null));
		PBServiceState state = service.processSyncRequest();
		Assert.assertNotNull(state);
		
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state.getState());
		Assert.assertEquals(ErrorDifinitions.SYNC_UPDATE_REQUEST_NO_TEMPLATE_NO_EXTRACT_PAYLOAD.getStringCode(), state.getReason().getCode());
		Assert.assertEquals(ErrorDifinitions.SYNC_UPDATE_REQUEST_NO_TEMPLATE_NO_EXTRACT_PAYLOAD.getDescriptionWithKey(null, null, null), state.getReason().getDescription());
		extMocker.tearDown();
		syncMocker.tearDown();
	}
	
	@Test
	public void testProcessSyncRequest_hasTemplate_update_exception() throws IOException {
		MockUp<ExtractService> extMocker = new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return util.createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};

		MockUp<SyncTemplateService> syncMocker = new MockUp<SyncTemplateService>() {
			@Mock
			private SyncResultWithStatus doUpdateWithTemplete(JdbcTemplate jdbcTemplate, PBSyncJobRequest synJobRequest) {
				return util.creatSyncResultWithStatus(ServiceStateType.SERVICE_STATE_SUCCESS, 1l);
			}
		};

		Integer containerId = 1;
		String userKey = "test";
		Integer eventId = 1;

		SyncTemplateService service = new SyncTemplateService(util.createPBSyncJobRequestNoTemplateNoPayload(SyncFunctionType.UPDATE, containerId, userKey, eventId));
		PBServiceState state = service.processSyncRequest();
		Assert.assertNotNull(state);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state.getState());
		Assert.assertEquals(ErrorDifinitions.SYNC_UPDATE_REQUEST_NO_TEMPLATE_NO_EXTRACT_PAYLOAD.getStringCode(), state.getReason().getCode());
		Assert.assertEquals(ErrorDifinitions.SYNC_UPDATE_REQUEST_NO_TEMPLATE_NO_EXTRACT_PAYLOAD.getDescriptionWithKey(null, null, null), state.getReason().getDescription());
		extMocker.tearDown();
		syncMocker.tearDown();
	}

	@Test
	public void testProcessSyncRequest_hasTemplate_update_normal() throws IOException {
		MockUp<ExtractService> extMocker =
				new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return util.createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};	
		
		MockUp<SyncTemplateService> syncMocker =
				new MockUp<SyncTemplateService>() {
			@Mock
			private SyncResultWithStatus doUpdateWithTemplete(JdbcTemplate jdbcTemplate, PBSyncJobRequest synJobRequest) {
				return util.creatSyncResultWithStatus(ServiceStateType.SERVICE_STATE_SUCCESS, 1l);
			}
		};
	
		Integer containerId = 1;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();		
		Integer eventId = 1;

		SyncTemplateService service = new SyncTemplateService(util.createPBSyncJobRequestWithTemplate(SyncFunctionType.UPDATE, containerId, userKey, eventId, data));
		PBServiceState state = service.processSyncRequest();
		Assert.assertNotNull(state);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, state.getState());
		extMocker.tearDown();
		syncMocker.tearDown();
	}
	
	@Test
	public void testProcessSyncRequest_hasTemplate_update_errror() throws IOException {
		MockUp<ExtractService> extMocker =
				new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return util.createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};	
		
		MockUp<SyncTemplateService> syncMocker =
				new MockUp<SyncTemplateService>() {
			@Mock
			private SyncResultWithStatus doUpdateWithTemplete(JdbcTemplate jdbcTemplate, PBSyncJobRequest synJobRequest) {
				return util.creatSyncResultWithStatus(ServiceStateType.SERVICE_STATE_ERROR, 1l);
			}
		};
	
		Integer containerId = 1;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();		
		Integer eventId = 1;

		SyncTemplateService service = new SyncTemplateService(util.createPBSyncJobRequestWithTemplate(SyncFunctionType.UPDATE, containerId, userKey, eventId, data));
		PBServiceState state = service.processSyncRequest();
		Assert.assertNotNull(state);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state.getState());
		extMocker.tearDown();
		syncMocker.tearDown();
	}	
	
	@Test
	public void testProcessSyncRequest_hasExtract_update_normal() throws IOException {
		MockUp<ExtractService> extMocker =
				new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return util.createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};	
		
		MockUp<ExtractService> extMock = new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return util.createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};
		
		MockUp<SyncTemplateService> syncMocker =
				new MockUp<SyncTemplateService>() {
			@Mock
			private SyncResultWithStatus doUpdateWithTemplete(JdbcTemplate jdbcTemplate, PBSyncJobRequest synJobRequest) {
				return util.creatSyncResultWithStatus(ServiceStateType.SERVICE_STATE_SUCCESS, 1l);
			}
		};
	
		Integer containerId = 1;
		String userKey = "test";		
		Integer eventId = 1;

		SyncTemplateService service = new SyncTemplateService(util.createPBSyncJobRequestWithExtract(SyncFunctionType.UPDATE, containerId, userKey, eventId));
		PBServiceState state = service.processSyncRequest();
		Assert.assertNotNull(state);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, state.getState());
		extMocker.tearDown();
		syncMocker.tearDown();
		 extMock.tearDown();
	}
	
	@Test
	public void testProcessSyncRequest_hasExtract_update_error() throws IOException {
		MockUp<ExtractService> extMocker =
				new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return util.createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};	
		
		MockUp<ExtractService> extMock = new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return util.createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};		
		
		MockUp<SyncTemplateService> syncMocker =
				new MockUp<SyncTemplateService>() {
			@Mock
			private SyncResultWithStatus doUpdateWithTemplete(JdbcTemplate jdbcTemplate, PBSyncJobRequest synJobRequest) {
				return util.creatSyncResultWithStatus(ServiceStateType.SERVICE_STATE_ERROR, 1l);
			}
		};
	
		Integer containerId = 1;
		String userKey = "test";
		Integer eventId = 1;

		SyncTemplateService service = new SyncTemplateService(util.createPBSyncJobRequestWithExtract(SyncFunctionType.UPDATE, containerId, userKey, eventId));
		PBServiceState state = service.processSyncRequest();
		Assert.assertNotNull(state);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state.getState());
		extMocker.tearDown();
		syncMocker.tearDown();
		extMock.tearDown();
	}
	
	@Test
	public void testProcessSyncRequest_hasExtract_update_ext_error() throws IOException {
		MockUp<ExtractService> extMocker =
				new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return util.createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};	
		
		MockUp<ExtractService> extMock = new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return util.createExtractResult(ServiceStateType.SERVICE_STATE_ERROR);
			}
		};	
	
		Integer containerId = 1;
		String userKey = "test";
		Integer eventId = 1;

		SyncTemplateService service = new SyncTemplateService(util.createPBSyncJobRequestWithExtract(SyncFunctionType.UPDATE, containerId, userKey, eventId));
		PBServiceState state = service.processSyncRequest();
		Assert.assertNotNull(state);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state.getState());
		extMocker.tearDown();		
		extMock.tearDown();
	}	
	
	@Test
	public void testProcessSyncRequest_no_eventId_hasTemplate_update_normal() throws IOException {
		MockUp<ExtractService> extMocker =
				new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return util.createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};	
		
		MockUp<SyncTemplateService> syncMocker =
				new MockUp<SyncTemplateService>() {
			@Mock
			private SyncResultWithStatus doUpdateWithTemplete(JdbcTemplate jdbcTemplate, PBSyncJobRequest synJobRequest) {
				return util.creatSyncResultWithStatus(ServiceStateType.SERVICE_STATE_SUCCESS, 1l);
			}
		};
	
		Integer containerId = 1;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();		

		SyncTemplateService service = new SyncTemplateService(util.createPBSyncJobRequestWithTemplate(SyncFunctionType.UPDATE, containerId, userKey, null, data));
		PBServiceState state = service.processSyncRequest();
		Assert.assertNotNull(state);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, state.getState());
		extMocker.tearDown();
		syncMocker.tearDown();
	}
	
	@Test
	public void testProcessSyncRequest_no_eventId_hasTemplate_update_errror() throws IOException {
		MockUp<ExtractService> extMocker =
				new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return util.createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};	
		
		MockUp<SyncTemplateService> syncMocker =
				new MockUp<SyncTemplateService>() {
			@Mock
			private SyncResultWithStatus doUpdateWithTemplete(JdbcTemplate jdbcTemplate, PBSyncJobRequest synJobRequest) {
				return util.creatSyncResultWithStatus(ServiceStateType.SERVICE_STATE_ERROR, 1l);
			}
		};
	
		Integer containerId = 1;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();			

		SyncTemplateService service = new SyncTemplateService(util.createPBSyncJobRequestWithTemplate(SyncFunctionType.UPDATE, containerId, userKey, null, data));
		PBServiceState state = service.processSyncRequest();
		Assert.assertNotNull(state);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state.getState());
		extMocker.tearDown();
		syncMocker.tearDown();
	}	
	
	@Test
	public void testProcessSyncRequest_no_eventId_hasExtract_update_normal() throws IOException {
		MockUp<ExtractService> extMocker =
				new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return util.createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};	
		
		MockUp<ExtractService> extMock = new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return util.createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};
		
		MockUp<SyncTemplateService> syncMocker =
				new MockUp<SyncTemplateService>() {
			@Mock
			private SyncResultWithStatus doUpdateWithTemplete(JdbcTemplate jdbcTemplate, PBSyncJobRequest synJobRequest) {
				return util.creatSyncResultWithStatus(ServiceStateType.SERVICE_STATE_SUCCESS, 1l);
			}
		};
	
		Integer containerId = 1;
		String userKey = "test";		

		SyncTemplateService service = new SyncTemplateService(util.createPBSyncJobRequestWithExtract(SyncFunctionType.UPDATE, containerId, userKey, null));
		PBServiceState state = service.processSyncRequest();
		Assert.assertNotNull(state);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, state.getState());
		extMocker.tearDown();
		syncMocker.tearDown();
		 extMock.tearDown();
	}
	
	@Test
	public void testProcessSyncRequest_no_eventId_hasExtract_update_error() throws IOException {
		MockUp<ExtractService> extMocker =
				new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return util.createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};	
		
		MockUp<ExtractService> extMock = new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return util.createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};		
		
		MockUp<SyncTemplateService> syncMocker =
				new MockUp<SyncTemplateService>() {
			@Mock
			private SyncResultWithStatus doUpdateWithTemplete(JdbcTemplate jdbcTemplate, PBSyncJobRequest synJobRequest) {
				return util.creatSyncResultWithStatus(ServiceStateType.SERVICE_STATE_ERROR, 1l);
			}
		};
	
		Integer containerId = 1;
		String userKey = "test";		

		SyncTemplateService service = new SyncTemplateService(util.createPBSyncJobRequestWithExtract(SyncFunctionType.UPDATE, containerId, userKey, null));
		PBServiceState state = service.processSyncRequest();
		Assert.assertNotNull(state);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state.getState());
		extMocker.tearDown();
		syncMocker.tearDown();
		extMock.tearDown();
	}
	
	@Test
	public void testProcessSyncRequest_hasExtract_no_eventId_update_ext_error() throws IOException {
		MockUp<ExtractService> extMocker =
				new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return util.createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};	
		
		MockUp<ExtractService> extMock = new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return util.createExtractResult(ServiceStateType.SERVICE_STATE_ERROR);
			}
		};	
	
		Integer containerId = 1;
		String userKey = "test";		

		SyncTemplateService service = new SyncTemplateService(util.createPBSyncJobRequestWithExtract(SyncFunctionType.UPDATE, containerId, userKey, null));
		PBServiceState state = service.processSyncRequest();
		Assert.assertNotNull(state);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state.getState());
		extMocker.tearDown();		
		extMock.tearDown();
	}


}
