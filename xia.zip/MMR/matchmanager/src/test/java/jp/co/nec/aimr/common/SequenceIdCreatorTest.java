package jp.co.nec.aimr.common;

import java.lang.reflect.Field;
import java.util.concurrent.atomic.AtomicLong;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import mockit.Deencapsulation;

public class SequenceIdCreatorTest {

	@Before
	public void setUp() throws Exception {
		Class<SequenceIdCreator> cls = SequenceIdCreator.class;
		Field field = cls.getDeclaredField("lastUnitId");
		field.setAccessible(true);
		Deencapsulation.setField(SequenceIdCreator.class, "lastUnitId", new AtomicLong(0));

		Field field1 = cls.getDeclaredField("lastVerifyJobId");
		field1.setAccessible(true);
		Deencapsulation.setField(SequenceIdCreator.class, "lastVerifyJobId", new AtomicLong(0));

		Field field2 = cls.getDeclaredField("lastInquriyJobId");
		field2.setAccessible(true);
		Deencapsulation.setField(SequenceIdCreator.class, "lastInquriyJobId", new AtomicLong(0));

		Field field3 = cls.getDeclaredField("lastExtractJobId");
		field3.setAccessible(true);
		Deencapsulation.setField(SequenceIdCreator.class, "lastExtractJobId", new AtomicLong(0));
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCreateNextMuIdSequence() {
		long muId = -1;
		long value = 1;
		for (int i = 0; i < 100; i++) {
			muId = SequenceIdCreator.createNextSequence(SequenceIdType.UNIT_ID);
			Assert.assertEquals(value++, muId);
		}
	}

	@Test
	public void testNextMuIdOverMax() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException, InstantiationException {
		Class<SequenceIdCreator> cls = SequenceIdCreator.class;
		// SequenceIdCreator seqClass = cls.newInstance();
		Field field = cls.getDeclaredField("lastUnitId");
		field.setAccessible(true);
		Deencapsulation.setField(SequenceIdCreator.class, "lastUnitId", new AtomicLong(Long.MAX_VALUE));
		long result = SequenceIdCreator.createNextSequence(SequenceIdType.UNIT_ID);
		Assert.assertEquals(1l, result);
	}

	@Test
	public void testCreateNextIdentifyJobIdSequence() {
		long identiyJobId = -1;
		long value = 1;
		for (int i = 0; i < 100; i++) {
			identiyJobId = SequenceIdCreator.createNextSequence(SequenceIdType.INQUIRY_ID);
			Assert.assertEquals(value++, identiyJobId);
		}
	}

	@Test
	public void testNextIdentifyJobIdOverMax() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException, InstantiationException {
		Class<SequenceIdCreator> cls = SequenceIdCreator.class;
		Field field = cls.getDeclaredField("lastInquriyJobId");
		field.setAccessible(true);
		Deencapsulation.setField(SequenceIdCreator.class, "lastInquriyJobId", new AtomicLong(Long.MAX_VALUE));
		long result = SequenceIdCreator.createNextSequence(SequenceIdType.INQUIRY_ID);
		Assert.assertEquals(1l, result);
	}

	@Test
	public void testCreateNextExtractJobIdSequence() {
		long identiyJobId = -1;
		long value = 1;
		for (int i = 0; i < 100; i++) {
			identiyJobId = SequenceIdCreator.createNextSequence(SequenceIdType.EXTEACT_ID);
			Assert.assertEquals(value++, identiyJobId);
		}
	}

	@Test
	public void testNextExtractJobIdOverMax() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException, InstantiationException {
		Class<SequenceIdCreator> cls = SequenceIdCreator.class;
		Field field = cls.getDeclaredField("lastExtractJobId");
		field.setAccessible(true);
		Deencapsulation.setField(SequenceIdCreator.class, "lastExtractJobId", new AtomicLong(Long.MAX_VALUE));
		long result = SequenceIdCreator.createNextSequence(SequenceIdType.EXTEACT_ID);
		Assert.assertEquals(1l, result);
	}

	@Test
	public void testCreateNextVerifyJobIdSequence() {
		long identiyJobId = -1;
		long value = 1;
		for (int i = 0; i < 100; i++) {
			identiyJobId = SequenceIdCreator.createNextSequence(SequenceIdType.VERIFY_JOB_ID);
			Assert.assertEquals(value++, identiyJobId);
		}
	}

	@Test
	public void testNextVerifyJobIdOverMax() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException, InstantiationException {
		Class<SequenceIdCreator> cls = SequenceIdCreator.class;
		Field field = cls.getDeclaredField("lastVerifyJobId");
		field.setAccessible(true);
		Deencapsulation.setField(SequenceIdCreator.class, "lastVerifyJobId", new AtomicLong(Long.MAX_VALUE));
		long result = SequenceIdCreator.createNextSequence(SequenceIdType.VERIFY_JOB_ID);
		Assert.assertEquals(1l, result);
	}
}
