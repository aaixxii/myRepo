package jp.co.nec.aimr.management;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractJobResult;
import jp.co.nec.aim.message.proto.InquiryService.PBIdentifyResponse;
import jp.co.nec.aim.message.proto.InquiryService.PBVerifyResponse;
import jp.co.nec.aimr.common.JobState;
import jp.co.nec.aimr.service.extract.ExtractJob;
import jp.co.nec.aimr.service.extract.ExtractJobStatus;
import jp.co.nec.aimr.service.inquiry.InquiryJob;
import jp.co.nec.aimr.service.inquiry.InquiryJobStatus;
import jp.co.nec.aimr.service.verity.VerifyJob;
import jp.co.nec.aimr.service.verity.VerifyJobStatus;

public class MMrJobManagerTest {

	@Before
	public void setUp() throws Exception {
		MMrJobManager.getInquiryjobqueue().clear();
		MMrJobManager.getExtractjobqueue().clear();
		MMrJobManager.getVerifyjobqueue().clear();		
		
		MMrJobManager.getInquiryjobresultsqueue().clear();
		MMrJobManager.getExtractjobresultsqueue().clear();
		MMrJobManager.getVerifyjobresultsqueue().clear();		
		
		MMrJobManager.getInquiryjobstatusmap().clear();
		MMrJobManager.getExtractjobstatusmap().clear();
		MMrJobManager.getVerifyjobstatusmap().clear();
		
		MMrJobManager.getInquiryjoblockerqueue().clear();
		MMrJobManager.getVerifyjoblockerqueue().clear();
		MMrJobManager.getExtractjoblockerqueue().clear();		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testSaveInqjobstatus() {
		Long jobId = 1L;
		 InquiryJobStatus status =  new  InquiryJobStatus();
		 status.setInqJobId(jobId);
		 status.setInqJobStatus(JobState.QUEUED);		
		MMrJobManager.saveInqjobstatus(jobId, status);
		Assert.assertEquals(1, MMrJobManager.getInquiryjobstatusmap().size());
		Assert.assertEquals(JobState.QUEUED, MMrJobManager.getInquiryJobStatus(jobId));		
	}

	@Test
	public void testSaveVerifyJobstatus() {
		Long jobId = 1L;
		VerifyJobStatus status =  new  VerifyJobStatus();
		 status.setVerifyJobId(jobId);
		 status.setVerifyJobStates(JobState.QUEUED);		
		MMrJobManager.saveVerifyJobStatus(jobId, status);
		Assert.assertEquals(1, MMrJobManager.getVerifyjobstatusmap().size());
		Assert.assertEquals(JobState.QUEUED, MMrJobManager.getVerifyJobStatus(jobId));		
	}

	@Test
	public void testSaveExtractJobstatus() {
		Long jobId = 1L;
		ExtractJobStatus status =  new  ExtractJobStatus();
		 status.setExtJobId(jobId);
		 status.setExtJobStatus(JobState.QUEUED);		
		MMrJobManager.saveExtractJobStatus(jobId, status);
		Assert.assertEquals(1, MMrJobManager.getExtractjobstatusmap().size());
		Assert.assertEquals(JobState.QUEUED, MMrJobManager.getExtractJobStatus(jobId));			
	}

	@Test
	public void testChangeInquiryJobstatus() {
		Long jobId = 1L;
		 InquiryJobStatus status =  new  InquiryJobStatus();
		 status.setInqJobId(jobId);
		 status.setInqJobStatus(JobState.QUEUED);		
		MMrJobManager.saveInqjobstatus(jobId, status);
		Assert.assertEquals(1, MMrJobManager.getInquiryjobstatusmap().size());
		Assert.assertEquals(JobState.QUEUED, MMrJobManager.getInquiryJobStatus(jobId));
		
		JobState newState = JobState.ASSIGNED;
		MMrJobManager.changeInquiryJobstatus(jobId, newState);
		Assert.assertEquals(1, MMrJobManager.getInquiryjobstatusmap().size());
		Assert.assertEquals(JobState.ASSIGNED, MMrJobManager.getInquiryJobStatus(jobId));		
	}

	@Test
	public void testChangeVerifyJobstatus() {
		Long jobId = 1L;
		VerifyJobStatus status =  new  VerifyJobStatus();
		 status.setVerifyJobId(jobId);
		 status.setVerifyJobStates(JobState.QUEUED);		
		MMrJobManager.saveVerifyJobStatus(jobId, status);
		Assert.assertEquals(1, MMrJobManager.getVerifyjobstatusmap().size());
		Assert.assertEquals(JobState.QUEUED, MMrJobManager.getVerifyJobStatus(jobId));
		JobState newState = JobState.ASSIGNED;
		MMrJobManager.changeVerifyJobstatus(jobId, newState);
		Assert.assertEquals(1, MMrJobManager.getVerifyjobstatusmap().size());
		Assert.assertEquals(JobState.ASSIGNED, MMrJobManager.getVerifyJobStatus(jobId));
	}

	@Test
	public void testChangeExtractJobstatus() {
		Long jobId = 1L;
		ExtractJobStatus status =  new  ExtractJobStatus();
		 status.setExtJobId(jobId);
		 status.setExtJobStatus(JobState.QUEUED);		
		MMrJobManager.saveExtractJobStatus(jobId, status);
		Assert.assertEquals(1, MMrJobManager.getExtractjobstatusmap().size());
		Assert.assertEquals(JobState.QUEUED, MMrJobManager.getExtractJobStatus(jobId));
		JobState newState = JobState.ASSIGNED;
		MMrJobManager.changeExtractJobstatus(jobId, newState);
		Assert.assertEquals(1, MMrJobManager.getExtractjobstatusmap().size());
		Assert.assertEquals(JobState.ASSIGNED, MMrJobManager.getExtractJobStatus(jobId));		
	}

	@Test
	public void testSaveInquiryjob() {
		Long jobId = 1L;
		byte[]  jobReqeust = "aim job results".getBytes();
		InquiryJob job = new InquiryJob(jobId, jobReqeust);
		MMrJobManager.saveInquiryjob(jobId, job);
		Assert.assertEquals(1, MMrJobManager.getInquiryjobqueue().size());
		Assert.assertEquals(job, MMrJobManager.getInquiryjob(jobId));
	}

	@Test
	public void testSaveVerifyjob() {
		Long jobId = 1L;
		byte[]  jobReqeust = "aim job results".getBytes();
		VerifyJob job = new VerifyJob(jobId, jobReqeust);
		MMrJobManager.saveVerifyjob(jobId, job);
		Assert.assertEquals(1, MMrJobManager.getVerifyjobqueue().size());
		Assert.assertEquals(job, MMrJobManager.getVerifyjob(jobId));		
	}

	@Test
	public void testSaveExtractJobjob() {
		Long jobId = 1L;
		byte[]  jobReqeust = "aim job results".getBytes();
		byte[] postCard = "aim post card".getBytes();
		ExtractJob job = new ExtractJob(jobId, jobReqeust, postCard);
		MMrJobManager.saveExtractJobjob(jobId, job);
		Assert.assertEquals(1, MMrJobManager.getExtractjobqueue().size());
		Assert.assertEquals(job, MMrJobManager.getExtractjob(jobId));
	}

	@Test
	public void testGetInquiryjob() {
		Long jobId = 1L;
		Assert.assertNull(MMrJobManager.getInquiryjob(jobId));		
		byte[]  jobReqeust = "aim job results".getBytes();
		InquiryJob job = new InquiryJob(jobId, jobReqeust);
		MMrJobManager.saveInquiryjob(jobId, job);
		Assert.assertEquals(1, MMrJobManager.getInquiryjobqueue().size());
		Assert.assertEquals(job, MMrJobManager.getInquiryjob(jobId));		
	}

	@Test
	public void testGetVerifyjob() {
		Long jobId = 1L;
		Assert.assertNull(MMrJobManager.getInquiryjob(jobId));	
		byte[]  jobReqeust = "aim job results".getBytes();
		VerifyJob job = new VerifyJob(jobId, jobReqeust);
		MMrJobManager.saveVerifyjob(jobId, job);
		Assert.assertEquals(1, MMrJobManager.getVerifyjobqueue().size());
		Assert.assertEquals(job, MMrJobManager.getVerifyjob(jobId));
	}

	@Test
	public void testGetExtractjob() {
		Long jobId = 1L;
		Assert.assertNull(MMrJobManager.getInquiryjob(jobId));	
		byte[]  jobReqeust = "aim job results".getBytes();
		byte[] postCard = "aim post card".getBytes();
		ExtractJob job = new ExtractJob(jobId, jobReqeust, postCard);
		MMrJobManager.saveExtractJobjob(jobId, job);
		Assert.assertEquals(1, MMrJobManager.getExtractjobqueue().size());
		Assert.assertEquals(job, MMrJobManager.getExtractjob(jobId));		
	}

	@Test
	public void testCheckInqJobIsReulsted() {		
		Long jobId = 1L;
		Assert.assertTrue(MMrJobManager.checkInqJobIsReulstedOrFinished(jobId));
		MMrJobManager.saveInquiryJobLocker(jobId, new Object());
		PBServiceState.Builder pBServiceState = PBServiceState.newBuilder();
		pBServiceState.setState(ServiceStateType.SERVICE_STATE_SUCCESS);
		PBIdentifyResponse.Builder pBIdentifyResponse = PBIdentifyResponse.newBuilder();
		pBIdentifyResponse.setServiceState( pBServiceState);
		MMrJobManager.saveInquiryJobResult(jobId, pBIdentifyResponse.build());
		Assert.assertTrue(MMrJobManager.checkInqJobIsReulstedOrFinished(jobId));
	}

	@Test
	public void testCheckVerifyJobIsReulsted() {
		Long jobId = 1L;
		Assert.assertTrue(MMrJobManager.checkVerifyJobIsReulstedOrFinished(jobId));
		MMrJobManager.saveVerifyJobLocker(jobId, new Object());
		PBServiceState.Builder pBServiceState = PBServiceState.newBuilder();
		pBServiceState.setState(ServiceStateType.SERVICE_STATE_SUCCESS);
		PBVerifyResponse.Builder pBVerifyResponse = PBVerifyResponse.newBuilder();
		pBVerifyResponse.setServiceState( pBServiceState);
		MMrJobManager.saveVerifyJobResult(jobId, pBVerifyResponse.build());
		Assert.assertTrue(MMrJobManager.checkVerifyJobIsReulstedOrFinished(jobId));
	}

	@Test
	public void testCheckExtractJobIsReulsted() {
		Long jobId = 1L;
		Assert.assertTrue(MMrJobManager.checkExtractJobIsReulstedOrFinished(jobId));
		MMrJobManager.saveExtractJobLocker(jobId, new Object());
		PBServiceState.Builder pBServiceState = PBServiceState.newBuilder();
		pBServiceState.setState(ServiceStateType.SERVICE_STATE_SUCCESS);
		PBExtractJobResult.Builder pBExtractJobResult = PBExtractJobResult.newBuilder();
		pBExtractJobResult.setServiceState( pBServiceState);
		MMrJobManager.saveExtractJobResult(jobId, pBExtractJobResult.build());
		Assert.assertTrue(MMrJobManager.checkExtractJobIsReulstedOrFinished(jobId));
	}

	@Test
	public void testFetchOneInquiryJob() {
		Long jobId = 1L;
		Assert.assertEquals(null, MMrJobManager.fetchOneInquiryJob());
		 InquiryJobStatus status =  new  InquiryJobStatus();
		 status.setInqJobId(jobId);
		 status.setInqJobStatus(JobState.QUEUED);		
		MMrJobManager.saveInqjobstatus(jobId, status);
		byte[]  jobReqeust = "aim job results".getBytes();
		InquiryJob job = new InquiryJob(jobId, jobReqeust);
		MMrJobManager.saveInquiryjob(jobId, job);
		Assert.assertEquals(job, MMrJobManager.fetchOneInquiryJob());		
	}
	
	@Test
	public void testFetchOneInquiryJob_null() {
		Long jobId = 1L;
		Assert.assertEquals(null, MMrJobManager.fetchOneInquiryJob());
		 InquiryJobStatus status =  new  InquiryJobStatus();
		 status.setInqJobId(jobId);
		 status.setInqJobStatus(JobState.ASSIGNED);		
		MMrJobManager.saveInqjobstatus(jobId, status);
		byte[]  jobReqeust = "aim job results".getBytes();
		InquiryJob job = new InquiryJob(jobId, jobReqeust);
		MMrJobManager.saveInquiryjob(jobId, job);
		Assert.assertEquals(null, MMrJobManager.fetchOneInquiryJob());		
	}

	@Test
	public void testFetchOneVerifyJob() {
		Long jobId = 1L;
		VerifyJobStatus status =  new  VerifyJobStatus();
		 status.setVerifyJobId(jobId);
		 status.setVerifyJobStates(JobState.QUEUED);		
		MMrJobManager.saveVerifyJobStatus(jobId, status);

		byte[]  jobReqeust = "aim job results".getBytes();
		VerifyJob job = new VerifyJob(jobId, jobReqeust);
		MMrJobManager.saveVerifyjob(jobId, job);
		Assert.assertEquals(job, MMrJobManager.fetchOneVerifyJob());
	}
	
	@Test
	public void testFetchOneVerifyJob_null() {
		Long jobId = 1L;
		VerifyJobStatus status =  new  VerifyJobStatus();
		 status.setVerifyJobId(jobId);
		 status.setVerifyJobStates(JobState.ASSIGNED);		
		MMrJobManager.saveVerifyJobStatus(jobId, status);

		byte[]  jobReqeust = "aim job results".getBytes();
		VerifyJob job = new VerifyJob(jobId, jobReqeust);
		MMrJobManager.saveVerifyjob(jobId, job);
		Assert.assertEquals(null, MMrJobManager.fetchOneVerifyJob());
	}

	@Test
	public void testFetchOneExtractJob() {
		Long jobId = 1L;
		ExtractJobStatus status =  new  ExtractJobStatus();
		 status.setExtJobId(jobId);
		 status.setExtJobStatus(JobState.QUEUED);		
		MMrJobManager.saveExtractJobStatus(jobId, status);
		byte[]  jobReqeust = "aim job results".getBytes();
		byte[] postCard = "aim post card".getBytes();
		ExtractJob job = new ExtractJob(jobId, jobReqeust, postCard);
		MMrJobManager.saveExtractJobjob(jobId, job);
		Assert.assertEquals(job, MMrJobManager.fetchOneExtractJob());		
	}
	
	@Test
	public void testFetchOneExtractJob_null() {
		Long jobId = 1L;
		ExtractJobStatus status =  new  ExtractJobStatus();
		 status.setExtJobId(jobId);
		 status.setExtJobStatus(JobState.ASSIGNED);		
		MMrJobManager.saveExtractJobStatus(jobId, status);
		byte[]  jobReqeust = "aim job results".getBytes();
		byte[] postCard = "aim post card".getBytes();
		ExtractJob job = new ExtractJob(jobId, jobReqeust, postCard);
		MMrJobManager.saveExtractJobjob(jobId, job);
		Assert.assertEquals(null, MMrJobManager.fetchOneExtractJob());		
	}
	
	@Test
	public void testFetchOneInquiryJob_withJobId() {
		Long jobId = 1L;
		Assert.assertEquals(null, MMrJobManager.fetchOneInquiryJob());
		 InquiryJobStatus status =  new  InquiryJobStatus();
		 status.setInqJobId(jobId);
		 status.setInqJobStatus(JobState.QUEUED);		
		MMrJobManager.saveInqjobstatus(jobId, status);
		byte[]  jobReqeust = "aim job results".getBytes();
		InquiryJob job = new InquiryJob(jobId, jobReqeust);
		MMrJobManager.saveInquiryjob(jobId, job);
		Assert.assertEquals(job, MMrJobManager.fetchOneInquiryJob(jobId));		
	}
	
	@Test
	public void testFetchOneInquiryJob_withJobId_null() {
		Long jobId = 1L;
		Assert.assertEquals(null, MMrJobManager.fetchOneInquiryJob());
		 InquiryJobStatus status =  new  InquiryJobStatus();
		 status.setInqJobId(jobId);
		 status.setInqJobStatus(JobState.ASSIGNED);		
		MMrJobManager.saveInqjobstatus(jobId, status);
		byte[]  jobReqeust = "aim job results".getBytes();
		InquiryJob job = new InquiryJob(jobId, jobReqeust);
		MMrJobManager.saveInquiryjob(jobId, job);
		Assert.assertEquals(null, MMrJobManager.fetchOneInquiryJob(jobId));		
	}

	@Test
	public void testFetchOneVerifyJob_withJobId() {
		Long jobId = 1L;
		VerifyJobStatus status =  new  VerifyJobStatus();
		 status.setVerifyJobId(jobId);
		 status.setVerifyJobStates(JobState.QUEUED);		
		MMrJobManager.saveVerifyJobStatus(jobId, status);

		byte[]  jobReqeust = "aim job results".getBytes();
		VerifyJob job = new VerifyJob(jobId, jobReqeust);
		MMrJobManager.saveVerifyjob(jobId, job);
		Assert.assertEquals(job, MMrJobManager.fetchOneVerifyJob(jobId));
	}
	
	@Test
	public void testFetchOneVerifyJob_withJobId_null() {
		Long jobId = 1L;
		VerifyJobStatus status =  new  VerifyJobStatus();
		 status.setVerifyJobId(jobId);
		 status.setVerifyJobStates(JobState.ASSIGNED);		
		MMrJobManager.saveVerifyJobStatus(jobId, status);

		byte[]  jobReqeust = "aim job results".getBytes();
		VerifyJob job = new VerifyJob(jobId, jobReqeust);
		MMrJobManager.saveVerifyjob(jobId, job);
		Assert.assertEquals(null, MMrJobManager.fetchOneVerifyJob(jobId));
	}

	@Test
	public void testFetchOneExtractJob_withJobId() {
		Long jobId = 1L;
		ExtractJobStatus status =  new  ExtractJobStatus();
		 status.setExtJobId(jobId);
		 status.setExtJobStatus(JobState.QUEUED);		
		MMrJobManager.saveExtractJobStatus(jobId, status);
		byte[]  jobReqeust = "aim job results".getBytes();
		byte[] postCard = "aim post card".getBytes();
		ExtractJob job = new ExtractJob(jobId, jobReqeust, postCard);
		MMrJobManager.saveExtractJobjob(jobId, job);
		Assert.assertEquals(job, MMrJobManager.fetchOneExtractJob(jobId));		
	}
	
	@Test
	public void testFetchOneExtractJob_withJobId_null() {
		Long jobId = 1L;
		ExtractJobStatus status =  new  ExtractJobStatus();
		 status.setExtJobId(jobId);
		 status.setExtJobStatus(JobState.ASSIGNED);		
		MMrJobManager.saveExtractJobStatus(jobId, status);
		byte[]  jobReqeust = "aim job results".getBytes();
		byte[] postCard = "aim post card".getBytes();
		ExtractJob job = new ExtractJob(jobId, jobReqeust, postCard);
		MMrJobManager.saveExtractJobjob(jobId, job);
		Assert.assertEquals(null, MMrJobManager.fetchOneExtractJob(jobId));		
	}

	@Test
	public void testGetInquiryJobStatus() {
		Long jobId = 1L;
		 InquiryJobStatus status =  new  InquiryJobStatus();
		 status.setInqJobId(jobId);
		 status.setInqJobStatus(JobState.QUEUED);		
		MMrJobManager.saveInqjobstatus(jobId, status);
		Assert.assertEquals(1, MMrJobManager.getInquiryjobstatusmap().size());
		Assert.assertEquals(JobState.QUEUED, MMrJobManager.getInquiryJobStatus(jobId));
		
	}

	@Test
	public void testGetVerifyJobStatus() {
		Long jobId = 1L;
		VerifyJobStatus status =  new  VerifyJobStatus();
		 status.setVerifyJobId(jobId);
		 status.setVerifyJobStates(JobState.QUEUED);		
		MMrJobManager.saveVerifyJobStatus(jobId, status);
		Assert.assertEquals(1, MMrJobManager.getVerifyjobstatusmap().size());
		Assert.assertEquals(JobState.QUEUED, MMrJobManager.getVerifyJobStatus(jobId));
		
	}

	@Test
	public void testGetExtractJobStatus() {
		Long jobId = 1L;
		ExtractJobStatus status =  new  ExtractJobStatus();
		 status.setExtJobId(jobId);
		 status.setExtJobStatus(JobState.QUEUED);		
		MMrJobManager.saveExtractJobStatus(jobId, status);
		Assert.assertEquals(1, MMrJobManager.getExtractjobstatusmap().size());
		Assert.assertEquals(JobState.QUEUED, MMrJobManager.getExtractJobStatus(jobId));	
		
	}

	@Test
	public void testGetInquiryjobresultsqueue() {
		Assert.assertEquals(0, MMrJobManager.getInquiryjobqueue().size());
		Long jobId = 1L;
		byte[]  jobReqeust = "aim job results".getBytes();
		InquiryJob job = new InquiryJob(jobId, jobReqeust);
		MMrJobManager.saveInquiryjob(jobId, job);
		Assert.assertEquals(1, MMrJobManager.getInquiryjobqueue().size());		
		
	}

	@Test
	public void testGetVerifyjobresultsqueue() {
		Assert.assertEquals(0, MMrJobManager.getVerifyjobqueue().size());
		Long jobId = 1L;
		byte[]  jobReqeust = "aim job results".getBytes();
		VerifyJob job = new VerifyJob(jobId, jobReqeust);
		MMrJobManager.saveVerifyjob(jobId, job);
		Assert.assertEquals(1, MMrJobManager.getVerifyjobqueue().size());
		
	}

	@Test
	public void testGetExtractjobresultsqueue() {
		Assert.assertEquals(0, MMrJobManager.getExtractjobqueue().size());
		Long jobId = 1L;
		byte[]  jobReqeust = "aim job results".getBytes();
		byte[] postCard = "aim post card".getBytes();
		ExtractJob job = new ExtractJob(jobId, jobReqeust, postCard);
		MMrJobManager.saveExtractJobjob(jobId, job);
		Assert.assertEquals(1, MMrJobManager.getExtractjobqueue().size());
	}

	@Test
	public void testSaveInquiryJobStatus() {
		Long jobId = 1L;
		 InquiryJobStatus status =  new  InquiryJobStatus();
		 status.setInqJobId(jobId);
		 status.setInqJobStatus(JobState.QUEUED);		
		MMrJobManager.saveInqjobstatus(jobId, status);
		Assert.assertEquals(1, MMrJobManager.getInquiryjobstatusmap().size());
		Assert.assertEquals(JobState.QUEUED, MMrJobManager.getInquiryJobStatus(jobId));
	}

	@Test
	public void testSaveExtractJobStatus() {
		Long jobId = 1L;
		ExtractJobStatus status =  new  ExtractJobStatus();
		 status.setExtJobId(jobId);
		 status.setExtJobStatus(JobState.QUEUED);		
		MMrJobManager.saveExtractJobStatus(jobId, status);
		Assert.assertEquals(1, MMrJobManager.getExtractjobstatusmap().size());
		Assert.assertEquals(JobState.QUEUED, MMrJobManager.getExtractJobStatus(jobId));
	}

	@Test
	public void testSaveVerifyJobStatus() {
		Long jobId = 1L;
		VerifyJobStatus status =  new  VerifyJobStatus();
		 status.setVerifyJobId(jobId);
		 status.setVerifyJobStates(JobState.QUEUED);		
		MMrJobManager.saveVerifyJobStatus(jobId, status);
		Assert.assertEquals(1, MMrJobManager.getVerifyjobstatusmap().size());
		Assert.assertEquals(JobState.QUEUED, MMrJobManager.getVerifyJobStatus(jobId));
	}

	@Test
	public void testFinishIdentifyJob() {
		Long jobId = 1L;
		 InquiryJobStatus status =  new  InquiryJobStatus();
		 status.setInqJobId(jobId);
		 status.setInqJobStatus(JobState.QUEUED);		
		MMrJobManager.saveInqjobstatus(jobId, status);
		byte[]  jobReqeust = "aim job results".getBytes();
		InquiryJob job = new InquiryJob(jobId, jobReqeust);
		MMrJobManager.saveInquiryjob(jobId, job);
		MMrJobManager.saveVerifyJobLocker(jobId, new Object());
		PBServiceState.Builder pBServiceState = PBServiceState.newBuilder();
		pBServiceState.setState(ServiceStateType.SERVICE_STATE_SUCCESS);
		PBVerifyResponse.Builder pBVerifyResponse = PBVerifyResponse.newBuilder();
		pBVerifyResponse.setServiceState( pBServiceState);
		MMrJobManager.saveVerifyJobResult(jobId, pBVerifyResponse.build());
		MMrJobManager.finishIdentifyJob(jobId);
		Assert.assertFalse(MMrJobManager.getInquiryjobqueue().containsKey(jobId));
		Assert.assertFalse(MMrJobManager.getInquiryjobstatusmap().containsKey(jobId));
		Assert.assertFalse(MMrJobManager.getInquiryjobresultsqueue().containsKey(jobId));
		Assert.assertFalse(MMrJobManager.getInquiryjoblockerqueue().containsKey(jobId));		
	}

	@Test
	public void testFinishVerifyJob() {
		Long jobId = 1L;
		VerifyJobStatus status =  new  VerifyJobStatus();
		 status.setVerifyJobId(jobId);
		 status.setVerifyJobStates(JobState.QUEUED);		
		MMrJobManager.saveVerifyJobStatus(jobId, status);
		byte[]  jobReqeust = "aim job results".getBytes();
		VerifyJob job = new VerifyJob(jobId, jobReqeust);
		MMrJobManager.saveVerifyjob(jobId, job);
		MMrJobManager.saveVerifyJobLocker(jobId, new Object());
		PBServiceState.Builder pBServiceState = PBServiceState.newBuilder();
		pBServiceState.setState(ServiceStateType.SERVICE_STATE_SUCCESS);
		PBVerifyResponse.Builder pBVerifyResponse = PBVerifyResponse.newBuilder();
		pBVerifyResponse.setServiceState( pBServiceState);
		MMrJobManager.saveVerifyJobResult(jobId, pBVerifyResponse.build());
		MMrJobManager.finishVerifyJob(jobId);
		Assert.assertFalse(MMrJobManager.getVerifyjobqueue().containsKey(jobId));
		Assert.assertFalse(MMrJobManager.getVerifyjobstatusmap().containsKey(jobId));
		Assert.assertFalse(MMrJobManager.getVerifyjobresultsqueue().containsKey(jobId));
		Assert.assertFalse(MMrJobManager.getVerifyjoblockerqueue().containsKey(jobId));	
	}

	@Test
	public void testFinishExtractJob() {
		Long jobId = 1L;
		ExtractJobStatus status =  new  ExtractJobStatus();
		 status.setExtJobId(jobId);
		 status.setExtJobStatus(JobState.QUEUED);		
		MMrJobManager.saveExtractJobStatus(jobId, status);
		byte[]  jobReqeust = "aim job results".getBytes();
		byte[] postCard = "aim post card".getBytes();
		ExtractJob job = new ExtractJob(jobId, jobReqeust, postCard);
		MMrJobManager.saveExtractJobjob(jobId, job);
		MMrJobManager.saveExtractJobLocker(jobId, new Object());
		PBServiceState.Builder pBServiceState = PBServiceState.newBuilder();
		pBServiceState.setState(ServiceStateType.SERVICE_STATE_SUCCESS);
		PBExtractJobResult.Builder pBExtractJobResult = PBExtractJobResult.newBuilder();
		pBExtractJobResult.setServiceState( pBServiceState);
		MMrJobManager.saveExtractJobResult(jobId, pBExtractJobResult.build());
		MMrJobManager.finishExtractJob(jobId);
		Assert.assertFalse(MMrJobManager.getExtractjobqueue().containsKey(jobId));
		Assert.assertFalse(MMrJobManager.getExtractjobstatusmap().containsKey(jobId));
		Assert.assertFalse(MMrJobManager.getExtractjobresultsqueue().containsKey(jobId));
		Assert.assertFalse(MMrJobManager.getExtractjoblockerqueue().containsKey(jobId));
		
	}

	@Test
	public void testSetInquiryJobStatus() {
		Long jobId = 1L;
		 InquiryJobStatus status =  new  InquiryJobStatus();
		 status.setInqJobId(jobId);
		 status.setInqJobStatus(JobState.QUEUED);		
		MMrJobManager.saveInqjobstatus(jobId, status);
		MMrJobManager.setInquiryJobStatus(jobId, JobState.ASSIGNED);
		Assert.assertEquals(JobState.ASSIGNED, MMrJobManager.getInquiryJobStatus(jobId));
	}

	@Test
	public void testSetVerifyJobStatus() {
		Long jobId = 1L;
		VerifyJobStatus status =  new  VerifyJobStatus();
		 status.setVerifyJobId(jobId);
		 status.setVerifyJobStates(JobState.QUEUED);		
		MMrJobManager.saveVerifyJobStatus(jobId, status);
		Assert.assertEquals(1, MMrJobManager.getVerifyjobstatusmap().size());
		Assert.assertEquals(JobState.QUEUED, MMrJobManager.getVerifyJobStatus(jobId));
		MMrJobManager.setVerifyJobStatus(jobId, JobState.FAILD);
		Assert.assertEquals(JobState.FAILD, MMrJobManager.getVerifyJobStatus(jobId));		
	}

	@Test
	public void testSetExtractJobStatus() {
		Long jobId = 1L;
		ExtractJobStatus status =  new  ExtractJobStatus();
		 status.setExtJobId(jobId);
		 status.setExtJobStatus(JobState.QUEUED);		
		MMrJobManager.saveExtractJobStatus(jobId, status);
		Assert.assertEquals(1, MMrJobManager.getExtractjobstatusmap().size());
		Assert.assertEquals(JobState.QUEUED, MMrJobManager.getExtractJobStatus(jobId));
		MMrJobManager.setExtractJobStatus(jobId, JobState.RETURNED);
		Assert.assertEquals(JobState.RETURNED, MMrJobManager.getExtractJobStatus(jobId));		
	}

	@Test
	public void testGetOneInqJobResult() {
		Long jobId = 2L;
		Assert.assertTrue(MMrJobManager.checkInqJobIsReulstedOrFinished(jobId));
		MMrJobManager.saveInquiryJobLocker(jobId, new Object());
		PBServiceState.Builder pBServiceState = PBServiceState.newBuilder();
		pBServiceState.setState(ServiceStateType.SERVICE_STATE_SUCCESS);
		PBIdentifyResponse.Builder pBIdentifyResponse = PBIdentifyResponse.newBuilder();
		pBIdentifyResponse.setServiceState( pBServiceState);
		MMrJobManager.saveInquiryJobResult(jobId, pBIdentifyResponse.build());
		Assert.assertTrue(MMrJobManager.checkInqJobIsReulstedOrFinished(jobId));		
		Assert.assertEquals(1, MMrJobManager.getInquiryjobresultsqueue().size());		
	}

	@Test
	public void testGetOneVerifyJobResult() {
		Long jobId = 2L;
		Assert.assertTrue(MMrJobManager.checkVerifyJobIsReulstedOrFinished(jobId));
		MMrJobManager.saveVerifyJobLocker(jobId, new Object());
		PBServiceState.Builder pBServiceState = PBServiceState.newBuilder();
		pBServiceState.setState(ServiceStateType.SERVICE_STATE_SUCCESS);
		PBVerifyResponse.Builder pBVerifyResponse = PBVerifyResponse.newBuilder();
		pBVerifyResponse.setServiceState( pBServiceState);
		MMrJobManager.saveVerifyJobResult(jobId, pBVerifyResponse.build());
		Assert.assertTrue(MMrJobManager.checkVerifyJobIsReulstedOrFinished(jobId));
		Assert.assertNotNull(MMrJobManager.getOneVerifyJobResult(jobId));
		Assert.assertEquals(1, MMrJobManager.getVerifyjobresultsqueue().size());		
	}

	@Test
	public void testGetOneExtJobResult() {
		Long jobId = 1L;
		Assert.assertTrue(MMrJobManager.checkExtractJobIsReulstedOrFinished(jobId));
		MMrJobManager.saveExtractJobLocker(jobId, new Object());
		PBServiceState.Builder pBServiceState = PBServiceState.newBuilder();
		pBServiceState.setState(ServiceStateType.SERVICE_STATE_SUCCESS);
		PBExtractJobResult.Builder pBExtractJobResult = PBExtractJobResult.newBuilder();
		pBExtractJobResult.setServiceState( pBServiceState);
		MMrJobManager.saveExtractJobResult(jobId, pBExtractJobResult.build());
		Assert.assertTrue(MMrJobManager.checkExtractJobIsReulstedOrFinished(jobId));
		Assert.assertNotNull(MMrJobManager.getOneExtJobResult(jobId));
		Assert.assertEquals(1, MMrJobManager.getExtractjobresultsqueue().size());
	}
	
	@Test
	public void testSaveInquiryJobLocker() {
		Long jobId = 1L;
		Object locker = new Object();
		MMrJobManager.saveInquiryJobLocker(jobId, locker);
		Assert.assertEquals(1, MMrJobManager.getInquiryjoblockerqueue().size());		
	}

	@Test
	public void testSaveVerifyJobLocker() {
		Long jobId = 1L;
		Object locker = new Object();
		MMrJobManager.saveVerifyJobLocker(jobId, locker);
		Assert.assertEquals(1, MMrJobManager.getVerifyjoblockerqueue().size());		
	}

	@Test
	public void testSaveExtractJobLocker() {
		Long jobId = 1L;
		Object locker = new Object();
		MMrJobManager.saveExtractJobLocker(jobId, locker);
		Assert.assertEquals(1, MMrJobManager.getExtractjoblockerqueue().size());
		
	}

	@Test
	public void testRemoveInquiryJobLocker() {
		Long jobId = 1L;
		Object locker = new Object();
		MMrJobManager.saveInquiryJobLocker(jobId, locker);
		Assert.assertEquals(1, MMrJobManager.getInquiryjoblockerqueue().size());
		MMrJobManager.removeInquiryJobLocker(jobId);
		Assert.assertEquals(0, MMrJobManager.getInquiryjoblockerqueue().size());		
	}

	@Test
	public void testRemoveVerifyJobLocker() {
		Long jobId = 1L;
		Object locker = new Object();
		MMrJobManager.saveVerifyJobLocker(jobId, locker);
		Assert.assertEquals(1, MMrJobManager.getVerifyjoblockerqueue().size());	
		MMrJobManager.removeVerifyJobLocker(jobId);
		Assert.assertEquals(0, MMrJobManager.getVerifyjoblockerqueue().size());	
		
	}

	@Test
	public void testRemoveExtractJobLocker() {
		Long jobId = 1L;
		Object locker = new Object();
		MMrJobManager.saveExtractJobLocker(jobId, locker);
		Assert.assertEquals(1, MMrJobManager.getExtractjoblockerqueue().size());
		MMrJobManager.removeExtractJobLocker(jobId);
		Assert.assertEquals(0, MMrJobManager.getExtractjoblockerqueue().size());		
	}
	
	@Test
	public void testGetInquiryjobqueue() {	
		Assert.assertNotNull(MMrJobManager.getInquiryjobqueue());
	}
	
	@Test
	public void testGetExtractjobqueue() {	
		Assert.assertNotNull(MMrJobManager.getExtractjobqueue());		
	}
	@Test
	public void testGetVerifyjobqueue() {	
		Assert.assertNotNull(MMrJobManager.getVerifyjobqueue());
	}
	@Test
	public void testGetInquiryjobstatusmap() {	
		Assert.assertNotNull(MMrJobManager.getInquiryjobstatusmap());
	}
	@Test
	public void testGetExtractjobstatusmap() {	
		Assert.assertNotNull(MMrJobManager.getExtractjobstatusmap());
		
	}
	@Test
	public void testGetVerifyjobstatusmap() {	
		Assert.assertNotNull(MMrJobManager.getVerifyjobstatusmap());
	}
	@Test
	public void testgetInquiryjoblockerqueue() {	
		Assert.assertNotNull(MMrJobManager.getInquiryjoblockerqueue());
	}
	@Test
	public void testGetExtractjoblockerqueue() {	
		Assert.assertNotNull(MMrJobManager.getExtractjoblockerqueue());
	}
	@Test
	public void testGetVerifyjoblockerqueue() {	
		Assert.assertNotNull(MMrJobManager.getVerifyjoblockerqueue());
	}

}
