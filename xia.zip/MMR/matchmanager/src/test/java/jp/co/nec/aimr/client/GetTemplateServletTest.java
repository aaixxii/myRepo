package jp.co.nec.aimr.client;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.sql.DataSource;

import org.apache.http.HttpStatus;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.protobuf.InvalidProtocolBufferException;

import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.ManageService.PBGetTemplateRequest;
import jp.co.nec.aim.message.proto.ManageService.PBGetTemplateResponse;
import jp.co.nec.aimr.common.ErrorDifinitions;
import jp.co.nec.aimr.management.AIMrManger;
import jp.co.nec.aimr.persistence.aimdb.AIMrTemplatesDaoImp;
import jp.co.nec.aimr.persistence.aimdb.DataBaseUtil;
import jp.co.nec.aimr.properties.PropertyUtil;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/applicationContext.xml" })
public class GetTemplateServletTest {

	private static final String GET_TEMPLATE_URL = "/AIMManageService/gettemplate";
	@Autowired
	private GetTemplateServlet getTemplateServlet;

	@Resource
	private DataSource ds;

	private JdbcTemplate jdbcTemplate;

	private MockUp<DataBaseUtil> dataBaseUtilMock;
	private MockUp<PropertyUtil> propertyUtilMock;
	private MockUp<AIMrManger> aIMrMangerMock;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		jdbcTemplate = new JdbcTemplate(ds);
		new AIMrTemplatesDaoImp(jdbcTemplate);
		jdbcTemplate.execute("delete from PERSON_BIOMETRICS_1");
		jdbcTemplate.execute("delete from PERSON_BIO_CHANGE_LOG_1");
		jdbcTemplate.execute("COMMIT");
		recoverConatainerData();

		dataBaseUtilMock = new MockUp<DataBaseUtil>() {
			@Mock
			public DataSource lookupDataSource() {
				return ds;
			}
		};
		propertyUtilMock = new MockUp<PropertyUtil>() {
			@Mock
			public String getPropertyValue(String name) {
				return "Oracle";
			}
			@Mock
			public Integer getPropertyIntValue(String name) {
				return 30;
			}
			
		};

		aIMrMangerMock = new MockUp<AIMrManger>() {
			@Mock
			private void init() {
				return;
			}
			@Mock
			public String getDB_DRIVER() {
				return "Oracle";
			}
		};
	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.execute("COMMIT");
		dataBaseUtilMock.tearDown();
		propertyUtilMock.tearDown();
		aIMrMangerMock.tearDown();
	}

	@Test
	public void testTemplate_eventId_null_Ok() {
		Integer containerId = 1;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "insert into PERSON_BIOMETRICS_1 (biometrics_id,user_key, user_event_id, biometrics_data, biometrics_data_len, registered_ts) values (? ,?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] { i + 1, userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		PBGetTemplateRequest getTemplatereq = createPBGetTemplateRequest(containerId, userKey, null);
		req.setRequestURI(GET_TEMPLATE_URL);
		req.setContent(getTemplatereq.toByteArray());
		try {
			getTemplateServlet.doPost(req, res);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBGetTemplateResponse getTemplateResponse = null;
		try {
			getTemplateResponse = PBGetTemplateResponse.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Assert.assertNotNull(getTemplateResponse);
		ServiceStateType state = getTemplateResponse.getServiceState().getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, state);
		Assert.assertEquals(4, getTemplateResponse.getTemplateRefInfoCount());
		for (int i = 0; i < 4; i++) {
			Assert.assertEquals(containerId.intValue(), getTemplateResponse.getTemplateRefInfoList().get(i).getContainerId());
			Assert.assertEquals(i + 1, getTemplateResponse.getTemplateRefInfoList().get(i).getEventId());
			Assert.assertEquals(userKey, getTemplateResponse.getTemplateRefInfoList().get(i).getExternalId());
			Assert.assertEquals(sdata, new String(getTemplateResponse.getTemplateRefInfoList().get(i).getTemplate().toByteArray()));
		}

	}

	@Test
	public void testTemplate_eventId_null_no_result() {
		Integer containerId = 1;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "insert into PERSON_BIOMETRICS_1 (biometrics_id,user_key, user_event_id, biometrics_data, biometrics_data_len, registered_ts) values (? ,?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] { i + 1, userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		PBGetTemplateRequest getTemplatereq = createPBGetTemplateRequest(containerId, "test1", null);
		req.setRequestURI(GET_TEMPLATE_URL);
		req.setContent(getTemplatereq.toByteArray());
		try {
			getTemplateServlet.doPost(req, res);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBGetTemplateResponse getTemplateResponse = null;
		try {
			getTemplateResponse = PBGetTemplateResponse.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Assert.assertNotNull(getTemplateResponse);
		Assert.assertEquals(ErrorDifinitions.DB_GET_TEMPLATES_EMPTY.getDescriptionWithKey(containerId, "test1", null), getTemplateResponse.getServiceState().getReason().getDescription());
		Assert.assertEquals(ErrorDifinitions.DB_GET_TEMPLATES_EMPTY.getStringCode(), getTemplateResponse.getServiceState().getReason().getCode());
		Assert.assertEquals(0, getTemplateResponse.getTemplateRefInfoCount());
		Assert.assertEquals(0, getTemplateResponse.getTemplateRefInfoList().size());
	}

	@Test
	public void testTemplate_eventId_null_error() {
		Integer containerId = -1;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "insert into PERSON_BIOMETRICS_1 (biometrics_id,user_key, user_event_id, biometrics_data, biometrics_data_len, registered_ts) values (? ,?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] { i + 1, userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		PBGetTemplateRequest getTemplatereq = createPBGetTemplateRequest(containerId, userKey, null);
		req.setRequestURI(GET_TEMPLATE_URL);
		req.setContent(getTemplatereq.toByteArray());
		try {
			getTemplateServlet.doPost(req, res);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBGetTemplateResponse getTemplateResponse = null;
		try {
			getTemplateResponse = PBGetTemplateResponse.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Assert.assertNotNull(getTemplateResponse);
		Assert.assertNotNull(getTemplateResponse);
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getDescriptionWithKey(containerId, userKey, null), getTemplateResponse.getServiceState().getReason().getDescription());
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getStringCode(), getTemplateResponse.getServiceState().getReason().getCode());
		Assert.assertEquals(0, getTemplateResponse.getTemplateRefInfoCount());
		Assert.assertEquals(0, getTemplateResponse.getTemplateRefInfoList().size());
	}

	@Test
	public void testTemplate_eventId_not_null_Ok() {
		Integer containerId = 1;
		String userKey = "test";
		Integer eventId = 1;
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "insert into PERSON_BIOMETRICS_1 (biometrics_id,user_key, user_event_id, biometrics_data, biometrics_data_len, registered_ts) values (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] { i + 1, userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		PBGetTemplateRequest getTemplatereq = createPBGetTemplateRequest(containerId, userKey, eventId);
		req.setRequestURI(GET_TEMPLATE_URL);
		req.setContent(getTemplatereq.toByteArray());
		try {
			getTemplateServlet.doPost(req, res);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBGetTemplateResponse getTemplateResponse = null;
		try {
			getTemplateResponse = PBGetTemplateResponse.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Assert.assertNotNull(getTemplateResponse);
		ServiceStateType state = getTemplateResponse.getServiceState().getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, state);
		Assert.assertEquals(1, getTemplateResponse.getTemplateRefInfoCount());
		Assert.assertEquals(containerId.intValue(), getTemplateResponse.getTemplateRefInfoList().get(0).getContainerId());
		Assert.assertEquals(1, getTemplateResponse.getTemplateRefInfoList().get(0).getEventId());
		Assert.assertEquals(userKey, getTemplateResponse.getTemplateRefInfoList().get(0).getExternalId());
		Assert.assertEquals(sdata, new String(getTemplateResponse.getTemplateRefInfoList().get(0).getTemplate().toByteArray()));
	}

	@Test
	public void testTemplate_eventId_not_null_result_empty() {
		Integer containerId = 1;
		String userKey = "test";
		Integer eventId = 1;
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "insert into PERSON_BIOMETRICS_1 (biometrics_id,user_key, user_event_id, biometrics_data, biometrics_data_len, registered_ts) values (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] { i + 1, userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		PBGetTemplateRequest getTemplatereq = createPBGetTemplateRequest(containerId, "test1", eventId);
		req.setRequestURI(GET_TEMPLATE_URL);
		req.setContent(getTemplatereq.toByteArray());
		try {
			getTemplateServlet.doPost(req, res);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBGetTemplateResponse getTemplateResponse = null;
		try {
			getTemplateResponse = PBGetTemplateResponse.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Assert.assertNotNull(getTemplateResponse);
		ServiceStateType state = getTemplateResponse.getServiceState().getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state);
		Assert.assertEquals(ErrorDifinitions.DB_GET_TEMPLATES_EMPTY.getDescriptionWithKey(containerId, "test1", eventId), getTemplateResponse.getServiceState().getReason().getDescription());
		Assert.assertEquals(ErrorDifinitions.DB_GET_TEMPLATES_EMPTY.getStringCode(), getTemplateResponse.getServiceState().getReason().getCode());
		Assert.assertEquals(0, getTemplateResponse.getTemplateRefInfoCount());
		Assert.assertEquals(0, getTemplateResponse.getTemplateRefInfoList().size());
	}

	@Test
	public void testTemplate_eventId_not_null_result_error() {
		Integer containerId = -1;
		String userKey = "test";
		Integer eventId = 1;
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "insert into PERSON_BIOMETRICS_1 (biometrics_id,user_key, user_event_id, biometrics_data, biometrics_data_len, registered_ts) values (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] { i + 1, userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		PBGetTemplateRequest getTemplatereq = createPBGetTemplateRequest(containerId, "test1", eventId);
		req.setRequestURI(GET_TEMPLATE_URL);
		req.setContent(getTemplatereq.toByteArray());
		try {
			getTemplateServlet.doPost(req, res);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_OK);
		byte[] results = res.getContentAsByteArray();
		PBGetTemplateResponse getTemplateResponse = null;
		try {
			getTemplateResponse = PBGetTemplateResponse.parseFrom(results);
		} catch (InvalidProtocolBufferException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Assert.assertNotNull(getTemplateResponse);
		ServiceStateType state = getTemplateResponse.getServiceState().getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state);
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getDescriptionWithKey(containerId, "test1", eventId), getTemplateResponse.getServiceState().getReason().getDescription());
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getStringCode(), getTemplateResponse.getServiceState().getReason().getCode());
		Assert.assertEquals(0, getTemplateResponse.getTemplateRefInfoCount());
		Assert.assertEquals(0, getTemplateResponse.getTemplateRefInfoList().size());
	}

	@Test
	public void testDoGet() {
		Integer containerId = 1;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "insert into PERSON_BIOMETRICS_1 (biometrics_id,user_key, user_event_id, biometrics_data, biometrics_data_len, registered_ts) values (? ,?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] { i + 1, userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		PBGetTemplateRequest getTemplatereq = createPBGetTemplateRequest(containerId, userKey, null);
		req.setRequestURI(GET_TEMPLATE_URL);
		req.setContent(getTemplatereq.toByteArray());
		try {
			getTemplateServlet.doGet(req, res);
		} catch (ServletException | IOException e) {

			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_METHOD_NOT_ALLOWED);
	}

	@Test
	public void testDoGet_unkown() {
		Integer containerId = 1;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "insert into PERSON_BIOMETRICS_1 (biometrics_id,user_key, user_event_id, biometrics_data, biometrics_data_len, registered_ts) values (? ,?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] { i + 1, userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		PBGetTemplateRequest getTemplatereq = createPBGetTemplateRequest(containerId, userKey, null);
		req.setRequestURI("/AIMManageService/getTemplates");
		req.setContent(getTemplatereq.toByteArray());
		try {
			getTemplateServlet.doGet(req, res);
		} catch (ServletException | IOException e) {

			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_BAD_REQUEST);
	}

	@Test
	public void testDoPostUrlNotSupport() {
		Integer containerId = 1;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "insert into PERSON_BIOMETRICS_1 (biometrics_id,user_key, user_event_id, biometrics_data, biometrics_data_len, registered_ts) values (? ,?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] { i + 1, userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		PBGetTemplateRequest getTemplatereq = createPBGetTemplateRequest(containerId, userKey, null);
		req.setRequestURI("/AIMManageService/gettemplates");
		req.setContent(getTemplatereq.toByteArray());
		try {
			getTemplateServlet.doPost(req, res);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		final int status = res.getStatus();
		assertEquals(status, HttpStatus.SC_METHOD_NOT_ALLOWED);
	}

	private void recoverConatainerData() {
		String sql = "update containers set TEMPLATE_SIZE =15680 ,VERSION =0 ,RECORD_COUNT=0 where CONTAINER_ID=1";
		jdbcTemplate.update(sql);
		jdbcTemplate.execute("COMMIT");
	}

	private PBGetTemplateRequest createPBGetTemplateRequest(Integer containerId, String externalId, Integer eventId) {
		PBGetTemplateRequest.Builder pBGetTemplateRequest = PBGetTemplateRequest.newBuilder();
		if (containerId != null) {
			pBGetTemplateRequest.setContainerId(containerId.intValue());
		}

		if (externalId != null) {
			pBGetTemplateRequest.setExternalId(externalId);
		}

		if (eventId != null) {
			pBGetTemplateRequest.setEventId(eventId.intValue());
		}
		return pBGetTemplateRequest.build();
	}

}
