package jp.co.nec.aimr.agent;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import jp.co.nec.aimr.client.InquiryServlet;

@Configuration
public class AppConfig {

	@Bean
	public InquiryServlet getInquiryServlete() {
		return new InquiryServlet();
	}
}
