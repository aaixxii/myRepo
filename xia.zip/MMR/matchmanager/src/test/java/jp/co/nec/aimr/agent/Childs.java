package jp.co.nec.aimr.agent;

import jp.co.nec.aimr.common.UnitCard;

public class Childs implements Runnable {
	private UnitCard mu;

	public Childs(UnitCard mu) {
		this.mu = mu;
	}

	public void changeMu() {
		mu.setUniqueKey("abc");
		mu.setUnitId(1000L);
		System.out.println(mu.getUniqueKey());
		System.out.println(mu.getUnitId());
		System.out.println(Thread.currentThread().getName() + " has changed parent data! OKOKOKOKOK");
	}

	@Override
	public void run() {
		changeMu();
	}

}