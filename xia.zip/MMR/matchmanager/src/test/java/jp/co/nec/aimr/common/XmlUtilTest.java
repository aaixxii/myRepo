package jp.co.nec.aimr.common;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.net.URL;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import mockit.Mock;
import mockit.MockUp;

@Ignore
public class XmlUtilTest {

	private MockUp<XmlUtil> xmlMock;

	@Before
	public void setUp() throws Exception {
		URL url = Thread.currentThread().getContextClassLoader().getResource("web.xml");
		String testWebXmlPath = url.getPath();
		final String base = testWebXmlPath.substring(0, testWebXmlPath.length() - 20);
		String webXmlPath = testWebXmlPath.substring(testWebXmlPath.length() - 20, testWebXmlPath.length() - 7);
		Class<XmlUtil> cls = XmlUtil.class;
		Field nameField = cls.getDeclaredField("WEB_XML_PATH");

		Field modifiersField = Field.class.getDeclaredField("modifiers");  
		modifiersField.setAccessible(true);
		modifiersField.setInt(null, nameField.getModifiers() & ~Modifier.FINAL); 

		nameField.setAccessible(true); 
		nameField.set(XmlUtil.class, webXmlPath);

		xmlMock = new MockUp<XmlUtil>() {
			@Mock
			private String getTomcatBase() {
				return base;
			}
		};

	}

	@After
	public void tearDown() throws Exception {
		xmlMock.tearDown();
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testSetResourceRef() throws NoSuchFieldException, SecurityException, IllegalArgumentException,
			IllegalAccessException, IOException, DocumentException {

		XmlUtil.setResourceRef("mysql");

		SAXReader reader = new SAXReader();
		URL url = Thread.currentThread().getContextClassLoader().getResource("web.xml");
		Document document = reader.read(url.getPath());
		Element root = document.getRootElement();
		List<Element> resourceRefs = root.elements("resource-ref");
		Element resourceRef = resourceRefs.get(0);
		Element des = resourceRef.element("description");
		Assert.assertEquals("Mysql JNDI Datasource", des.getText());
		Element refNameNode = resourceRef.element("res-ref-name");
		Assert.assertEquals("jdbc/mysql", refNameNode.getText());
	}
}
