package jp.co.nec.aimr.service.verity;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.google.protobuf.ByteString;

import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceStateReason;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputPayload;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBVerifyDataInfo;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBVerifyJobInfo;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBVerifyJobInput;
import jp.co.nec.aim.message.proto.InquiryService.PBVerifyRequest;
import jp.co.nec.aim.message.proto.InquiryService.PBVerifyResponse;
import jp.co.nec.aimr.common.ErrorDifinitions;
import jp.co.nec.aimr.event.EventNotifier;
import jp.co.nec.aimr.management.AIMrManger;
import jp.co.nec.aimr.management.MMrJobManager;
import jp.co.nec.aimr.properties.PropertyUtil;
import mockit.Mock;
import mockit.MockUp;

public class VerifyServiceTest {
	private MockUp<PropertyUtil> proMock;
	private MockUp<AIMrManger> manager;

	@Before
	public void setUp() throws Exception {
		proMock = new MockUp<PropertyUtil>() {
			@Mock
			public void $init() {
				return;
			}

			@Mock
			public PropertyUtil getInstance() {
				return new PropertyUtil();
			}

			@Mock
			public Integer getPropertyIntValue(String name) {
				return 300;
			}

			@Mock
			public Long getPropertyLongValue(String name) {
				return 400L;
			}
			
			@Mock
			public String getPropertyValue(String name) {
				return "Oracle";
			}
		};

		manager = new MockUp<AIMrManger>() {
			@Mock
			private void init() {
				return;
			}
		};
	}

	@After
	public void tearDown() throws Exception {
		proMock.tearDown();
		manager.tearDown();
	}

	public void testVerityService() {
		VerityService service = new VerityService(createPBVerifyRequest());
		Assert.assertNotNull(service);
		Assert.assertTrue(service instanceof VerityService);

	}

	@Test
	public void testProcessVerityRequest_normoal() {
		MockUp<EventNotifier> notifyMocker = new MockUp<EventNotifier>() {
			@Mock
			public void fireOnVerifyJobqueueing(Long verifyJobId) {
				return;
			}
		};
		MockUp<MMrJobManager> jobMangerMocker = new MockUp<MMrJobManager>() {
			@Mock
			public PBVerifyResponse getOneVerifyJobResult(Long verifyJobId) {
				PBVerifyResponse result = createPBVerifyResponse(ServiceStateType.SERVICE_STATE_SUCCESS, null);
				return result;
			}
		};
		VerityService service = new VerityService(createPBVerifyRequest());
		PBVerifyResponse result = service.processVerityRequest();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, result.getServiceState().getState());
		notifyMocker.tearDown();
		jobMangerMocker.tearDown();
	}

	@Test
	public void testProcessVerityRequest_no_active_eu() {
		MockUp<MMrJobManager> jobMangerMocker = new MockUp<MMrJobManager>() {
			@Mock
			public PBVerifyResponse getOneVerifyJobResult(Long verifyJobId) {
				PBVerifyResponse result = createPBVerifyResponse(ServiceStateType.SERVICE_STATE_SUCCESS, null);
				return result;
			}
		};
		VerityService service = new VerityService(createPBVerifyRequest());
		PBVerifyResponse result = service.processVerityRequest();
		PBServiceState sate = result.getServiceState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, sate.getState());
		Assert.assertEquals(ErrorDifinitions.VERIFY_JOB_NO_ACTIVE_EU.getDescriptionWithKey(null, null, null), sate.getReason().getDescription());
		Assert.assertEquals(ErrorDifinitions.VERIFY_JOB_NO_ACTIVE_EU.getStringCode(), sate.getReason().getCode());
		jobMangerMocker.tearDown();
	}

	@Test
	public void testProcessVerityRequest_time_out() {
		MockUp<EventNotifier> notifyMocker = new MockUp<EventNotifier>() {
			@Mock
			public void fireOnVerifyJobqueueing(Long verifyJobId) {
				return;
			}
		};
		VerityService service = new VerityService(createPBVerifyRequest());
		PBVerifyResponse result = service.processVerityRequest();
		PBServiceState sate = result.getServiceState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, sate.getState());
		Assert.assertEquals(ErrorDifinitions.VERIFY_JOB_TIMEOUT.getDescriptionWithKey(null, null, null), sate.getReason().getDescription());
		Assert.assertEquals(ErrorDifinitions.VERIFY_JOB_TIMEOUT.getStringCode(), sate.getReason().getCode());
		notifyMocker.tearDown();
	}
	
	@Test
	public void testProcessVerityRequest_no_target() {
		MockUp<EventNotifier> notifyMocker = new MockUp<EventNotifier>() {
			@Mock
			public void fireOnVerifyJobqueueing(Long verifyJobId) {
				return;
			}
		};
		MockUp<MMrJobManager> jobMangerMocker = new MockUp<MMrJobManager>() {
			@Mock
			public PBVerifyResponse getOneVerifyJobResult(Long verifyJobId) {
				PBVerifyResponse result = createPBVerifyResponse(ServiceStateType.SERVICE_STATE_SUCCESS, null);
				return result;
			}
		};
		VerityService service = new VerityService(createPBVerifyRequest_no_target());
		PBVerifyResponse result = service.processVerityRequest();
		ServiceStateType state = result.getServiceState().getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state);
		String code = result.getServiceState().getReason().getCode();
		String description = result.getServiceState().getReason().getDescription();
		Assert.assertEquals(ErrorDifinitions.VERIFY_TARGET_IS_NULL.getStringCode(), code);
		Assert.assertEquals(ErrorDifinitions.VERIFY_TARGET_IS_NULL.getDescription(), description);		
		notifyMocker.tearDown();
		jobMangerMocker.tearDown();
	}
	
	@Test
	public void testProcessVerityRequest_query_no_image_no_template() {
		MockUp<EventNotifier> notifyMocker = new MockUp<EventNotifier>() {
			@Mock
			public void fireOnVerifyJobqueueing(Long verifyJobId) {
				return;
			}
		};
		MockUp<MMrJobManager> jobMangerMocker = new MockUp<MMrJobManager>() {
			@Mock
			public PBVerifyResponse getOneVerifyJobResult(Long verifyJobId) {
				PBVerifyResponse result = createPBVerifyResponse(ServiceStateType.SERVICE_STATE_SUCCESS, null);
				return result;
			}
		};
		VerityService service = new VerityService(createPBVerifyRequest_query_no_image_no_template());
		PBVerifyResponse result = service.processVerityRequest();
		ServiceStateType state = result.getServiceState().getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state);
		String code = result.getServiceState().getReason().getCode();
		String description = result.getServiceState().getReason().getDescription();
		Assert.assertEquals(ErrorDifinitions.VERIFY_NO_IMAGE_AND_NO_TEMPLATE.getStringCode(), code);
		Assert.assertEquals(ErrorDifinitions.VERIFY_NO_IMAGE_AND_NO_TEMPLATE.getDescription(), description);		
		notifyMocker.tearDown();
		jobMangerMocker.tearDown();
	}
	
	@Test
	public void testProcessVerityRequest_query_target_no_image_nokey_noTemplate() {
		MockUp<EventNotifier> notifyMocker = new MockUp<EventNotifier>() {
			@Mock
			public void fireOnVerifyJobqueueing(Long verifyJobId) {
				return;
			}
		};
		MockUp<MMrJobManager> jobMangerMocker = new MockUp<MMrJobManager>() {
			@Mock
			public PBVerifyResponse getOneVerifyJobResult(Long verifyJobId) {
				PBVerifyResponse result = createPBVerifyResponse(ServiceStateType.SERVICE_STATE_SUCCESS, null);
				return result;
			}
		};
		VerityService service = new VerityService(createPBVerifyRequest_target_no_image_nokey_noTemplate());
		PBVerifyResponse result = service.processVerityRequest();
		ServiceStateType state = result.getServiceState().getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state);
		String code = result.getServiceState().getReason().getCode();
		String description = result.getServiceState().getReason().getDescription();
		Assert.assertEquals(ErrorDifinitions.VERIFY_TARGET_NO_IMAGE_AND_NO_TEMPLATE_NO_KEY.getStringCode(), code);
		Assert.assertEquals(ErrorDifinitions.VERIFY_TARGET_NO_IMAGE_AND_NO_TEMPLATE_NO_KEY.getDescription(), description);		
		notifyMocker.tearDown();
		jobMangerMocker.tearDown();
	}
	

	private PBVerifyRequest createPBVerifyRequest_no_target() {
		PBVerifyRequest.Builder pBVerifyRequest = PBVerifyRequest.newBuilder();
		PBVerifyJobInput.Builder pBVerifyJobInput = PBVerifyJobInput.newBuilder();
		PBVerifyJobInfo.Builder pBVerifyJobInfo = PBVerifyJobInfo.newBuilder();
		PBExtractInputPayload.Builder pBExtractInputPayload = PBExtractInputPayload.newBuilder();
		PBVerifyDataInfo.Builder pBVerifyDataInfo = PBVerifyDataInfo.newBuilder();
		pBVerifyDataInfo.setImage(pBExtractInputPayload);
		pBVerifyDataInfo.setTemplate(ByteString.copyFrom("I am a image date".getBytes()));
		pBVerifyJobInput.setQuery(pBVerifyDataInfo);
		pBVerifyJobInfo.setContainerId(1);
		pBVerifyRequest.setJobInfo(pBVerifyJobInfo.build());
		pBVerifyRequest.setJobInput(pBVerifyJobInput.build());
		return pBVerifyRequest.build();
	}

	private PBVerifyRequest createPBVerifyRequest_query_no_image_no_template() {
		PBVerifyRequest.Builder pBVerifyRequest = PBVerifyRequest.newBuilder();
		PBVerifyJobInput.Builder pBVerifyJobInput = PBVerifyJobInput.newBuilder();
		PBVerifyJobInfo.Builder pBVerifyJobInfo = PBVerifyJobInfo.newBuilder();
		PBExtractInputPayload.Builder pBExtractInputPayload = PBExtractInputPayload.newBuilder();
		PBVerifyDataInfo.Builder pBVerifyDataInfo = PBVerifyDataInfo.newBuilder();
		PBVerifyDataInfo.Builder targetVerifyDataInfo = PBVerifyDataInfo.newBuilder();
		targetVerifyDataInfo.setImage(pBExtractInputPayload);
		targetVerifyDataInfo.setTemplate(ByteString.copyFrom("I am a image date".getBytes()));
		pBVerifyJobInput.addTarget(targetVerifyDataInfo.build());
		pBVerifyJobInput.setQuery(pBVerifyDataInfo);
		pBVerifyJobInfo.setContainerId(1);
		pBVerifyRequest.setJobInfo(pBVerifyJobInfo.build());
		pBVerifyRequest.setJobInput(pBVerifyJobInput.build());
		return pBVerifyRequest.build();

	}

	private PBVerifyRequest createPBVerifyRequest_target_no_image_nokey_noTemplate() {
		PBVerifyRequest.Builder pBVerifyRequest = PBVerifyRequest.newBuilder();
		PBVerifyJobInput.Builder pBVerifyJobInput = PBVerifyJobInput.newBuilder();
		PBVerifyJobInfo.Builder pBVerifyJobInfo = PBVerifyJobInfo.newBuilder();
		PBExtractInputPayload.Builder pBExtractInputPayload = PBExtractInputPayload.newBuilder();
		PBVerifyDataInfo.Builder pBVerifyDataInfo = PBVerifyDataInfo.newBuilder();
		pBVerifyDataInfo.setImage(pBExtractInputPayload);
		pBVerifyDataInfo.setTemplate(ByteString.copyFrom("I am a image date".getBytes()));
		PBVerifyDataInfo.Builder targetVerifyDataInfo = PBVerifyDataInfo.newBuilder();
		pBVerifyJobInput.addTarget(targetVerifyDataInfo.build());
		pBVerifyJobInput.setQuery(pBVerifyDataInfo);
		pBVerifyJobInfo.setContainerId(1);
		pBVerifyRequest.setJobInfo(pBVerifyJobInfo.build());
		pBVerifyRequest.setJobInput(pBVerifyJobInput.build());
		return pBVerifyRequest.build();
	}

	private PBVerifyRequest createPBVerifyRequest() {
		PBVerifyRequest.Builder pBVerifyRequest = PBVerifyRequest.newBuilder();
		PBVerifyJobInput.Builder pBVerifyJobInput = PBVerifyJobInput.newBuilder();
		PBVerifyJobInfo.Builder pBVerifyJobInfo = PBVerifyJobInfo.newBuilder();
		PBExtractInputPayload.Builder pBExtractInputPayload = PBExtractInputPayload.newBuilder();
		PBVerifyDataInfo.Builder pBVerifyDataInfo = PBVerifyDataInfo.newBuilder();
		pBVerifyDataInfo.setImage(pBExtractInputPayload);
		pBVerifyDataInfo.setTemplate(ByteString.copyFrom("I am a image date".getBytes()));
		PBVerifyDataInfo.Builder targetVerifyDataInfo = PBVerifyDataInfo.newBuilder();
		targetVerifyDataInfo.setImage(pBExtractInputPayload);
		targetVerifyDataInfo.setTemplate(ByteString.copyFrom("I am a image date".getBytes()));
		pBVerifyJobInput.addTarget(targetVerifyDataInfo.build());
		pBVerifyJobInput.setQuery(pBVerifyDataInfo);
		pBVerifyJobInfo.setContainerId(1);
		pBVerifyRequest.setJobInfo(pBVerifyJobInfo.build());
		pBVerifyRequest.setJobInput(pBVerifyJobInput.build());
		return pBVerifyRequest.build();
	}

	private PBVerifyResponse createPBVerifyResponse(ServiceStateType type, ErrorDifinitions errDifinition) {
		PBVerifyResponse.Builder pBVerifyResponse = PBVerifyResponse.newBuilder();
		PBServiceState.Builder pBServiceState = PBServiceState.newBuilder();
		PBServiceStateReason.Builder pBServiceStateReason = PBServiceStateReason.newBuilder();
		pBServiceState.setState(type);
		if (errDifinition != null) {
			pBServiceStateReason.setCode(errDifinition.getStringCode());
			pBServiceStateReason.setDescription(errDifinition.getDescription());
			pBServiceState.setReason(pBServiceStateReason);
		}
		pBVerifyResponse.setServiceState(pBServiceState);
		return pBVerifyResponse.build();

	}

}
