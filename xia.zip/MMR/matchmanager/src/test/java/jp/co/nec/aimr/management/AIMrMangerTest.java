package jp.co.nec.aimr.management;

import java.lang.reflect.Field;
import java.util.List;
import java.util.concurrent.ExecutorService;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import jp.co.nec.aimr.properties.PropertyUtil;
import mockit.Deencapsulation;
import mockit.Mock;
import mockit.MockUp;


public class AIMrMangerTest {
	
	private MockUp<PropertyUtil> propertyUtilMock;	

	@Before
	public void setUp() throws Exception {
		propertyUtilMock = 
		new MockUp<PropertyUtil>() {
			@Mock
			public void $init() {
				return;
			}
			
//			@Mock
//			public PropertyUtil getInstance() {
//				return new PropertyUtil();
//			}
			@Mock
			public Integer getPropertyIntValue(String name) {
				return 5;
			}
			
			@Mock
			public Long getPropertyLongValue(String name) {
				return 5L;
			}
			
			@Mock
			public String getPropertyValue(String name) {
				return "Oracle";
			}
		};	
	}

	@After
	public void tearDown() throws Exception {
		propertyUtilMock.tearDown();		
	}

	@Test
	public void testGetInstance() {
		Assert.assertNotNull(AIMrManger.getInstance());		
		Assert.assertTrue(AIMrManger.getInstance() instanceof AIMrManger);
	}

	@Test	
	public void testGetDB_DRIVER() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {		
		Class<AIMrManger> cls = AIMrManger.class;
		Field field = cls.getDeclaredField("DB_DRIVER");
		field.setAccessible(true);
		Deencapsulation.setField(AIMrManger.getInstance(), "DB_DRIVER", "Oracle");
		 String driver = (String)field.get(AIMrManger.getInstance());
		Assert.assertEquals("Oracle", driver);
	}

	@Test
	public void testGetContainerKeys() {
		List<Integer> result = AIMrManger.getContainerKeys();
		Assert.assertNotNull(result);		
	}

	@Test
	public void testSaveTopersonBiometricsTabMap() {
		AIMrManger.saveTopersonBiometricsTabMap(1, "test");
		String name = AIMrManger.getPersonBiometricsTabName(1);
		Assert.assertEquals("test", name);
		AIMrManger.getPersonbiometricstabmap().clear();		
	}

	@Test
	public void testGetPersonBiometricsTabName() {
		AIMrManger.saveTopersonBiometricsTabMap(1, "test");
		String name = AIMrManger.getPersonBiometricsTabName(1);
		Assert.assertEquals("test", name);
		AIMrManger.getPersonbiometricstabmap().clear();		
	}

	@Test
	public void testSaveTopersonBiometricsChangeLogTabMap() {
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "logtest");
		String name = AIMrManger.getPersonBiometricsChangeLogTabName(1);
		Assert.assertEquals("logtest", name);
		AIMrManger.getPersonbiometricschangelogtabmap().clear();
	}

	@Test
	public void testGetPersonBiometricsChangeLogTabName() {
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "logtest");
		String name = AIMrManger.getPersonBiometricsChangeLogTabName(1);
		Assert.assertEquals("logtest", name);
		AIMrManger.getPersonbiometricschangelogtabmap().clear();		
	}

	@Test	
	@Ignore
	public void testGetUnitReceiveExecutor() {
		Assert.assertNotNull(AIMrManger.getInstance().getUnitReceiveExecutor());
		Assert.assertTrue(AIMrManger.getInstance().getUnitReceiveExecutor() instanceof ExecutorService);		
	}
	
	@Test
	public void testGetPersonbiometricstabmap() {
		Assert.assertNotNull(AIMrManger.getPersonbiometricstabmap());		
	}
	
	@Test
	public void testGetPersonbiometricschangelogtabmap() {
		Assert.assertNotNull(AIMrManger.getPersonbiometricschangelogtabmap());
	}

}
