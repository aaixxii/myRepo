package jp.co.nec.aimr.agent;

public class InquiryJobResultSender {
	private static SendInquiryJobRequstTest send;

	public static void main(String[] args) {
		send = new SendInquiryJobRequstTest();
		run();

		// EventNotifier.getInstance().fireOnAcceptAble(1L);
	}

	public static void run() {
		send.sendMuJobResult();
		try {
			Thread.sleep(50000 * 24);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
