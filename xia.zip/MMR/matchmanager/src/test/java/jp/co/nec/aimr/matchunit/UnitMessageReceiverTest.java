package jp.co.nec.aimr.matchunit;

import java.io.IOException;
import java.nio.channels.SocketChannel;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;



public class UnitMessageReceiverTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testOnStop() {
		
	}

	@Test
	public void testUnitMessageReceiver() throws IOException {
		SocketChannel channel = SocketChannel.open();
		UnitMessageReceiver uc = new UnitMessageReceiver(channel);
		Assert.assertNotNull(uc);
		Assert.assertTrue(uc instanceof UnitMessageReceiver);	
		uc = null;
		channel.close();
	}

	@Test
	public void testGetUnitMessageSenderInstance() throws IOException {
		SocketChannel channel = SocketChannel.open();
		UnitMessageReceiver uc = new UnitMessageReceiver(channel);	
		UnitMessageSender result = uc.getUnitMessageSenderInstance();
		Assert.assertNull(result);		
		uc = null;
		channel.close();
	}
}
