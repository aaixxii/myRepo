package jp.co.nec.aimr.agent;

import jp.co.nec.aim.message.proto.InquiryService.PBIdentifyRequest;

public class InquiryClient {
	
	public static void main(String[] args) {

		AimrHttpClientUtil util = new AimrHttpClientUtil();
		String postUrl = "http://10.197.23.100:8080/matchmanager/AIMInquiryService/identify";
		PBIdentifyRequest jobRequst = CreateInquiryJobRequst();
		byte[] byteJobRespose = null;
		byteJobRespose = util.postByteData(postUrl, jobRequst.toByteArray());
		// PBInquiryJobResult pbResult =
		// PBInquiryJobResult.parseFrom(byteJobRespose);
		assert byteJobRespose != null;
	}

	private static PBIdentifyRequest CreateInquiryJobRequst() {
		
		return null;
	}
	

}
