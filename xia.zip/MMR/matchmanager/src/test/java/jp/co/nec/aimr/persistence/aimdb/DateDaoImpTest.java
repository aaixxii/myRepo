package jp.co.nec.aimr.persistence.aimdb;

import java.util.Date;

import javax.annotation.Resource;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import jp.co.nec.aimr.management.AIMrManger;
import jp.co.nec.aimr.persistence.aimdb.DataDao;
import jp.co.nec.aimr.persistence.aimdb.DateDaoImp;
import jp.co.nec.aimr.properties.PropertyUtil;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class DateDaoImpTest {
	@Resource
	private DataSource ds;
	private DataDao dao;
	private MockUp<PropertyUtil> proMock;
	private MockUp<AIMrManger> manager;

	@Before
	public void setUp() throws Exception {
		proMock = new MockUp<PropertyUtil>() {
			@Mock
			public void $init() {
				return;
			}

			@Mock
			public PropertyUtil getInstance() {
				return new PropertyUtil();
			}

			@Mock
			public Integer getPropertyIntValue(String name) {
				return 3;
			}

			@Mock
			public String getPropertyValue(String name) {
				return "Oracle";
			}
		};

		manager = new MockUp<AIMrManger>() {
			@Mock
			private void init() {
				return;
			}
		};
		dao = new DateDaoImp(new JdbcTemplate(ds));
	}

	@After
	public void tearDown() throws Exception {
		dao = null;
		proMock.tearDown();
		manager.tearDown();
	}

	@Test
	public void testDateDaoImp() {
		Assert.assertNotNull(dao);
		Assert.assertTrue(dao instanceof DateDaoImp);
	}

	@Test
	public void testGetDatabaseDate() {
		Date result = dao.getDatabaseDate();
		Assert.assertNotNull(result);
	}

	@Test
	public void testGetStringCurrentTimeMS() {
		String tm = dao.getStringCurrentTimeMS();
		Assert.assertNotNull(tm);
	}
}
