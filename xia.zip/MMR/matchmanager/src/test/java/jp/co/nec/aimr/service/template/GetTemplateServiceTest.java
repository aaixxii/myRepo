package jp.co.nec.aimr.service.template;

import java.util.List;

import javax.annotation.Resource;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.ManageService.PBGetTemplateRequest;
import jp.co.nec.aim.message.proto.ManageService.PBGetTemplateResponse;
import jp.co.nec.aim.message.proto.ManageService.PBTemplateRefInfo;
import jp.co.nec.aimr.common.ErrorDifinitions;
import jp.co.nec.aimr.management.AIMrManger;
import jp.co.nec.aimr.persistence.aimdb.DataBaseUtil;
import jp.co.nec.aimr.properties.PropertyUtil;
import mockit.Mock;
import mockit.MockUp;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class GetTemplateServiceTest {	
	@Resource
	private DataSource ds;

	
	private JdbcTemplate jdbcTemplate;
	private MockUp<DataBaseUtil> dbMock;
	private  MockUp<PropertyUtil> proMock;
	private MockUp<AIMrManger> manager;

	@Before
	public void setUp() throws Exception {
		jdbcTemplate = new JdbcTemplate(ds);		
		jdbcTemplate.execute("delete from PERSON_BIOMETRICS_1");
		jdbcTemplate.execute("delete from PERSON_BIO_CHANGE_LOG_1");
		jdbcTemplate.execute("COMMIT");
		
		 dbMock = new MockUp<DataBaseUtil>() {
			@Mock
			public DataSource lookupDataSource() {
				return ds;
			}
		};
	  proMock = new MockUp<PropertyUtil>() {
			@Mock
			public Integer getPropertyIntValue(String name) {
				return 30;
			}
			@Mock
			public String getPropertyValue(String name) {
				return "Oracle";
			}
		};
		
		 manager = new MockUp<AIMrManger>() {
			@Mock
			private void init() {
				return ;
			}
			@Mock
			public String getDB_DRIVER() {
				return "postgresql";
			}
		};		
	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.execute("delete from PERSON_BIOMETRICS_1");
		jdbcTemplate.execute("delete from PERSON_BIO_CHANGE_LOG_1");
		jdbcTemplate.execute("COMMIT");
		recoverConatainerData();
		dbMock.tearDown();
		proMock.tearDown();
		manager.tearDown();
	}
	
	@Test
	public void testGetTemplateService() {
		PBGetTemplateRequest getTempRequest = createPBGetTemplateRequest(1, "key", 1);
		GetTemplateService service = new GetTemplateService(getTempRequest);
		Assert.assertNotNull(service);
		Assert.assertTrue(service instanceof GetTemplateService);		
	}

	@Test
	public void testProcessGetTemplateRequest_no_eventId_normal() {				
		Integer containerId = 1;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "insert into PERSON_BIOMETRICS_1 (biometrics_id,user_key, user_event_id, biometrics_data, biometrics_data_len, registered_ts) values (? ,?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] {i + 1, userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		PBGetTemplateRequest getTempRequest = createPBGetTemplateRequest(containerId, userKey, null);
		GetTemplateService service = new GetTemplateService(getTempRequest);
		 PBGetTemplateResponse result = service.processGetTemplateRequest();
		PBServiceState state = result.getServiceState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, state.getState());
		
		List<PBTemplateRefInfo> infoList = result.getTemplateRefInfoList();
		Assert.assertEquals(4, infoList.size());
		for (int i = 0; i < 4; i++) {
			Assert.assertEquals(containerId.intValue(), infoList.get(i).getContainerId());
			Assert.assertEquals(i + 1, infoList.get(i).getEventId());
			Assert.assertEquals(userKey, infoList.get(i).getExternalId());
			Assert.assertEquals(sdata, new String(infoList.get(i).getTemplate().toByteArray()));
		}		
	}
	
	@Test
	public void testProcessGetTemplateRequest_have_eventId_normal() {
		Integer containerId = 1;
		String userKey = "test";
		Integer eventId = 1;
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "insert into PERSON_BIOMETRICS_1 (biometrics_id,user_key, user_event_id, biometrics_data, biometrics_data_len, registered_ts) values (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] { i + 1, userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		PBGetTemplateRequest getTempRequest = createPBGetTemplateRequest(containerId, userKey, eventId);
		GetTemplateService service = new GetTemplateService(getTempRequest);
		PBGetTemplateResponse result = service.processGetTemplateRequest();
		PBServiceState state = result.getServiceState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, state.getState());

		List<PBTemplateRefInfo> infoList = result.getTemplateRefInfoList();
		Assert.assertEquals(1, infoList.size());

		Assert.assertEquals(containerId.intValue(), infoList.get(0).getContainerId());
		Assert.assertEquals(1, infoList.get(0).getEventId());
		Assert.assertEquals(userKey, infoList.get(0).getExternalId());
		Assert.assertEquals(sdata, new String(infoList.get(0).getTemplate().toByteArray()));		
	}
	
	@Test
	public void testProcessGetTemplateRequest_eventId_null_error() {				
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;		

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "insert into PERSON_BIOMETRICS_1 (biometrics_id,user_key, user_event_id, biometrics_data, biometrics_data_len, registered_ts) values (? ,?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] {i + 1, userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		
		PBGetTemplateRequest getTempRequest = createPBGetTemplateRequest(-1, userKey, null);
		GetTemplateService service = new GetTemplateService(getTempRequest);
		 PBGetTemplateResponse result = service.processGetTemplateRequest();
		PBServiceState state = result.getServiceState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state.getState());		
		
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getDescriptionWithKey(-1, userKey, null), state.getReason().getDescription());
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getStringCode(), state.getReason().getCode());
		Assert.assertEquals(0, result.getTemplateRefInfoCount());
		Assert.assertEquals(0, result.getTemplateRefInfoList().size());			
	}
	
	@Test
	public void testProcessGetTemplateRequest_eventId_not_null_results_empty() {		
		Integer containerId = 1;
		String userKey = "test";
		Integer eventId = 1;
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "insert into PERSON_BIOMETRICS_1 (biometrics_id,user_key, user_event_id, biometrics_data, biometrics_data_len, registered_ts) values (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] { i + 1, userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		PBGetTemplateRequest getTempRequest = createPBGetTemplateRequest(containerId, "test1", eventId);
		GetTemplateService service = new GetTemplateService(getTempRequest);
		 PBGetTemplateResponse result = service.processGetTemplateRequest();
		PBServiceState state = result.getServiceState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state.getState());
		
		Assert.assertNotNull(result);		
		Assert.assertEquals(ErrorDifinitions.DB_GET_TEMPLATES_EMPTY.getDescriptionWithKey(containerId, "test1", eventId), state.getReason().getDescription());
		Assert.assertEquals(ErrorDifinitions.DB_GET_TEMPLATES_EMPTY.getStringCode(), state.getReason().getCode());
		Assert.assertEquals(0, result.getTemplateRefInfoCount());
		Assert.assertEquals(0, result.getTemplateRefInfoList().size());
		
	}
	
	@Test
	public void testProcessGetTemplateRequest_eventId_not_null_error() {			
		String userKey = "test";
		Integer eventId = 1;
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "insert into PERSON_BIOMETRICS_1 (biometrics_id,user_key, user_event_id, biometrics_data, biometrics_data_len, registered_ts) values (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] { i + 1, userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		
		PBGetTemplateRequest getTempRequest = createPBGetTemplateRequest(-1, "test1", eventId);
		GetTemplateService service = new GetTemplateService(getTempRequest);
		 PBGetTemplateResponse result = service.processGetTemplateRequest();
		PBServiceState state = result.getServiceState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state.getState());		
		Assert.assertNotNull(result);
		
		
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getDescriptionWithKey(-1, "test1", eventId), state.getReason().getDescription());
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getStringCode(), state.getReason().getCode());
		Assert.assertEquals(0, result.getTemplateRefInfoCount());
		Assert.assertEquals(0, result.getTemplateRefInfoList().size());		
	}
	
	@Test
	public void testProcessGetTemplateRequest_eventId_not_null_results_error() {				
		String userKey = "test";
		Integer eventId = 1;
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "insert into PERSON_BIOMETRICS_1 (biometrics_id,user_key, user_event_id, biometrics_data, biometrics_data_len, registered_ts) values (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql, new Object[] { i + 1, userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		
		PBGetTemplateRequest getTempRequest = createPBGetTemplateRequest(-1, userKey, eventId);
		GetTemplateService service = new GetTemplateService(getTempRequest);
		 PBGetTemplateResponse result = service.processGetTemplateRequest();
		PBServiceState state = result.getServiceState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, state.getState());		
		
		Assert.assertNotNull(result);		
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getDescriptionWithKey(-1, userKey, eventId), state.getReason().getDescription());
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getStringCode(), state.getReason().getCode());
		Assert.assertEquals(0, result.getTemplateRefInfoCount());
		Assert.assertEquals(0, result.getTemplateRefInfoList().size());		
	}
	
	private PBGetTemplateRequest createPBGetTemplateRequest(Integer contaierId, String key , Integer eventId) {
		PBGetTemplateRequest.Builder pBGetTemplateRequest = PBGetTemplateRequest.newBuilder();
		pBGetTemplateRequest.setContainerId(contaierId.intValue());
		pBGetTemplateRequest.setExternalId(key);
		if (eventId != null) {
			pBGetTemplateRequest.setEventId(eventId.intValue());
		}
		return pBGetTemplateRequest.build();		
	}
	
	private void recoverConatainerData() {
		String sql = "update containers set TEMPLATE_SIZE =15680 ,VERSION =0 ,RECORD_COUNT=0 where CONTAINER_ID=1";
		jdbcTemplate.update(sql);
		jdbcTemplate.execute("COMMIT");
	}

}
