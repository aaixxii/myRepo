package jp.co.nec.aimr.client;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import javax.servlet.ServletException;

import org.apache.http.HttpStatus;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import jp.co.nec.aimr.exception.AimRuntimeException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:/applicationContext.xml" })
public class BaseServletTest {	
	
	@Autowired
	private BaseServlet baseServlet;	


	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testIsContextSizeEmpty() {
		final MockHttpServletRequest req = new MockHttpServletRequest();		
		boolean result = baseServlet.isContextSizeEmpty(req);
		Assert.assertTrue(result);
	}
	
	@Test
	public void testIsContextSizeEmpty_null() {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		req.setContent("test content".getBytes());		
		boolean result = baseServlet.isContextSizeEmpty(req);
		Assert.assertFalse(result);
	}	

	@Test
	public void testWriteToResponse() throws UnsupportedEncodingException {		
		final MockHttpServletResponse res = new MockHttpServletResponse();
		int statusCode = HttpStatus.SC_OK;
		String content = "test test";
		byte[] array = "test test".getBytes();
		baseServlet.writeToResponse(res, statusCode, array, null);
		Assert.assertEquals(array.length, res.getContentLength());
		Assert.assertEquals(statusCode,res.getStatus());
		Assert.assertEquals(content, res.getContentAsString());		
	}
	
	@Test
	public void testWriteToResponse1() throws UnsupportedEncodingException {		
		final MockHttpServletResponse res = new MockHttpServletResponse();
		int statusCode = HttpStatus.SC_OK;	
		baseServlet.writeToResponse(res, statusCode, null, null);		
	}
	
	@Test
	public void testWriteToResponse2() throws UnsupportedEncodingException {		
		final MockHttpServletResponse res = new MockHttpServletResponse();
		int statusCode = HttpStatus.SC_OK;
		String content = "test test";
		byte[] array = "test test".getBytes();
		AimRuntimeException e = new AimRuntimeException("test");
		baseServlet.writeToResponse(res, statusCode, array, e);
		Assert.assertEquals(array.length, res.getContentLength());
		Assert.assertEquals(statusCode,res.getStatus());
		Assert.assertEquals(content, res.getContentAsString());		
	}

	@Test
	public void testWriteErrorToResponse() throws UnsupportedEncodingException {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		int statusCode = HttpStatus.SC_INTERNAL_SERVER_ERROR;	
		String message = "error message.";
		AimRuntimeException e = new AimRuntimeException("test");
		baseServlet.writeErrorToResponse(req, res, statusCode, message, e);		
		Assert.assertEquals(statusCode,res.getStatus());			
	}
	
	@Test
	public void testWriteErrorToResponse1() throws UnsupportedEncodingException {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();
		int statusCode = HttpStatus.SC_INTERNAL_SERVER_ERROR;	
		String message = "error message.";		
		baseServlet.writeErrorToResponse(req, res, statusCode, message, null);		
		Assert.assertEquals(statusCode,res.getStatus());		
	}

	@Test
	public void testWriteResultToResponseByteArray() throws UnsupportedEncodingException {		
		final MockHttpServletResponse res = new MockHttpServletResponse();
		String content = "test test";
		byte[] array = "test test".getBytes();
		baseServlet.writeResultToResponse(array, res);
		Assert.assertEquals(content, res.getContentAsString());
	}

	@Test
	public void testWriteResultToResponseString() throws UnsupportedEncodingException {	
		final MockHttpServletResponse res = new MockHttpServletResponse();		String content = "test test";		
		baseServlet.writeResultToResponse(content, res);
		Assert.assertEquals(content, res.getContentAsString());		
		
	}

	@Test
	public void testDoHead() throws ServletException, IOException {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();	
		baseServlet.doHead(req, res);
		Assert.assertEquals( HttpStatus.SC_METHOD_NOT_ALLOWED, res.getStatus());
		
	}

	@Test
	public void testDoPut() throws ServletException, IOException {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();	
		baseServlet.doPut(req, res);
		Assert.assertEquals( HttpStatus.SC_METHOD_NOT_ALLOWED, res.getStatus());
		
	}

	@Test
	public void testDoDelete() throws ServletException, IOException {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();	
		baseServlet.doDelete(req, res);
		Assert.assertEquals( HttpStatus.SC_METHOD_NOT_ALLOWED, res.getStatus());
		
	}

	@Test
	public void testDoTrace() throws ServletException, IOException {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();	
		baseServlet.doTrace(req, res);
		Assert.assertEquals( HttpStatus.SC_METHOD_NOT_ALLOWED, res.getStatus());	
	}

	@Test
	public void testDoNoSuport_delete() throws ServletException, IOException {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();	
		baseServlet.doNoSuport(req, res, "DELETE");
		Assert.assertEquals( HttpStatus.SC_METHOD_NOT_ALLOWED, res.getStatus());		
	}
	
	@Test
	public void testDoNoSuport_Head() throws ServletException, IOException {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();	
		baseServlet.doNoSuport(req, res, "HEAD");
		Assert.assertEquals( HttpStatus.SC_METHOD_NOT_ALLOWED, res.getStatus());		
	}
	
	@Test
	public void testDoNoSuport_Trace() throws ServletException, IOException {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();	
		baseServlet.doNoSuport(req, res, "TRACE");
		Assert.assertEquals( HttpStatus.SC_METHOD_NOT_ALLOWED, res.getStatus());		
	}

	@Test
	public void testDoNoSuport_Put() throws ServletException, IOException {
		final MockHttpServletRequest req = new MockHttpServletRequest();
		final MockHttpServletResponse res = new MockHttpServletResponse();	
		baseServlet.doNoSuport(req, res, "PUT");
		Assert.assertEquals( HttpStatus.SC_METHOD_NOT_ALLOWED, res.getStatus());		
	}
}
