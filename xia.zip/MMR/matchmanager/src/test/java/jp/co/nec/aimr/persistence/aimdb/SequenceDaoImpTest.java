package jp.co.nec.aimr.persistence.aimdb;

import javax.annotation.Resource;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import jp.co.nec.aimr.management.AIMrManger;
import jp.co.nec.aimr.persistence.aimdb.SequenceDao;
import jp.co.nec.aimr.persistence.aimdb.SequenceDaoImp;
import jp.co.nec.aimr.properties.PropertyUtil;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class SequenceDaoImpTest {

	@Resource
	private DataSource ds;

	private SequenceDao dao;
	private JdbcTemplate jdbcTemplate;
	private MockUp<PropertyUtil> proMock;
	private MockUp<AIMrManger> manager;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		proMock = new MockUp<PropertyUtil>() {
			@Mock
			public void $init() {
				return;
			}

			@Mock
			public PropertyUtil getInstance() {
				return new PropertyUtil();
			}

			@Mock
			public Integer getPropertyIntValue(String name) {
				return 3;
			}

			@Mock
			public String getPropertyValue(String name) {
				return "oracle";
			}
		};

		manager = new MockUp<AIMrManger>() {
			@Mock
			private void init() {
				return;
			}

			@Mock
			public String getDB_DRIVER() {
				return "Oracle";
			}
		};
		jdbcTemplate = new JdbcTemplate(ds);
		dao = new SequenceDaoImp(jdbcTemplate);
		jdbcTemplate.execute("delete from PERSON_BIO_CHANGE_LOG_1");
		jdbcTemplate.execute("COMMIT");
	}

	@After
	public void tearDown() throws Exception {
		dao = null;
		jdbcTemplate = null;
		proMock.tearDown();
		manager.tearDown();
	}

	@Test
	public void testSequenceDaoImp() {
		Assert.assertNotNull(dao);
		Assert.assertTrue(dao instanceof SequenceDaoImp);
	}

	@Test
	public void testNextBiometicsId() throws Exception {
		String sql = "SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'BIOMETRICS_ID_SEQ'";
		long oldVaule = jdbcTemplate.queryForObject(sql, Long.class).longValue();
		long newValue = dao.getNextBiometricsId();
		jdbcTemplate.execute("COMMIT");
		long lastValue = jdbcTemplate.queryForObject(sql, Long.class).longValue();
		Assert.assertEquals(oldVaule + 1l, newValue);
		Assert.assertEquals(oldVaule + 1l, lastValue);
	}

	@Test
	public void testNextBiometicsId_rollback() throws Exception {
		String sql = "SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'BIOMETRICS_ID_SEQ'";
		long oldVaule = jdbcTemplate.queryForObject(sql, Long.class).longValue();
		long newValue = dao.getNextBiometricsId();
		jdbcTemplate.execute("ROLLBACK");
		long lastValue = jdbcTemplate.queryForObject(sql, Long.class).longValue();
		Assert.assertEquals(oldVaule + 1l, newValue);
		Assert.assertEquals(oldVaule, lastValue);
	}

	@Test
	public void testNextChangeLogId() throws Exception {
		String sql = "select SEQUENCE_VALUE from SEQUENCE where SEQUENCE_NAME = 'CHANGE_ID_SEQ'";
		long oldVaule = jdbcTemplate.queryForObject(sql, Long.class).longValue();
		long newValue = dao.getNextChangeLogId();
		jdbcTemplate.execute("COMMIT");
		long lastValue = jdbcTemplate.queryForObject(sql, Long.class).longValue();
		Assert.assertEquals(oldVaule + 1l, newValue);
		Assert.assertEquals(oldVaule + 1l, lastValue);
	}

	@Test
	public void testNextChangeLogId_rollback() throws Exception {
		String sql = "select SEQUENCE_VALUE from SEQUENCE where SEQUENCE_NAME = 'CHANGE_ID_SEQ'";
		long oldVaule = jdbcTemplate.queryForObject(sql, Long.class).longValue();
		long newValue = dao.getNextChangeLogId();
		jdbcTemplate.execute("ROLLBACK");
		long lastValue = jdbcTemplate.queryForObject(sql, Long.class).longValue();
		Assert.assertEquals(oldVaule + 1l, newValue);
		Assert.assertEquals(oldVaule, lastValue);
	}

	@Test
	public void testNextUnitId() throws Exception {
		String sql = "select SEQUENCE_VALUE from SEQUENCE where SEQUENCE_NAME = 'UNIT_ID_SEQ'";
		long oldVaule = jdbcTemplate.queryForObject(sql, Long.class).longValue();
		long newValue = dao.getNextUnitId();
		jdbcTemplate.execute("COMMIT");
		long lastValue = jdbcTemplate.queryForObject(sql, Long.class).longValue();
		Assert.assertEquals(oldVaule + 1l, lastValue);
		System.out.println(oldVaule + ":" + newValue);
	}

	@Test
	public void testNextUnitId_rollback() throws Exception {
		String sql = "select SEQUENCE_VALUE from SEQUENCE where SEQUENCE_NAME = 'UNIT_ID_SEQ'";
		long oldVaule = jdbcTemplate.queryForObject(sql, Long.class).longValue();
		long newValue = dao.getNextUnitId();
		jdbcTemplate.execute("ROLLBACK");
		long lastValue = jdbcTemplate.queryForObject(sql, Long.class).longValue();
		Assert.assertEquals(oldVaule, lastValue);
		System.out.println(oldVaule + ":" + newValue);
	}

	@Test
	public void testGetNextChangeLogVersion() throws Exception {
		String insertSql = "INSERT INTO PERSON_BIO_CHANGE_LOG_1 (CHANGE_ID, BIOMETRICS_ID, USER_KEY, USER_EVENT_ID, CHANGE_TYPE, VERSION) VALUES (1, 0, 'test', 1, 1, 5)";
		jdbcTemplate.update(insertSql);
		long oldVersion = jdbcTemplate.queryForObject("SELECT VERSION FROM PERSON_BIO_CHANGE_LOG_1 WHERE CHANGE_ID = 1",
				Long.class);
		String tableName = "PERSON_BIO_CHANGE_LOG_1";
		long newValue = dao.getNextChangeLogVersion(tableName);
		jdbcTemplate.execute("COMMIT");
		long lastValue = jdbcTemplate
				.queryForObject("SELECT VERSION FROM PERSON_BIO_CHANGE_LOG_1 WHERE CHANGE_ID = 1", Long.class)
				.longValue();
		Assert.assertEquals(oldVersion + 1, newValue);
		Assert.assertEquals(oldVersion, lastValue);
	}

	@Test
	public void testGetNextChangeLogVersion_rollback() throws Exception {
		String insertSql = "INSERT INTO PERSON_BIO_CHANGE_LOG_1 (CHANGE_ID, BIOMETRICS_ID, USER_KEY, USER_EVENT_ID, CHANGE_TYPE, VERSION) VALUES (1, 0, 'test', 1, 1, 5)";
		jdbcTemplate.execute(insertSql);
		long oldVersion = jdbcTemplate.queryForObject("SELECT VERSION FROM PERSON_BIO_CHANGE_LOG_1 WHERE CHANGE_ID = 1",
				Long.class);
		String tableName = "PERSON_BIO_CHANGE_LOG_1";
		long newValue = dao.getNextChangeLogVersion(tableName);
		Assert.assertEquals(oldVersion + 1, newValue);
		jdbcTemplate.execute("ROLLBACK");
	}

	@Test
	public void testToUperDbName() {
		String oracle[] = { "ORACLE", "oracle", "Oracle", "ORacle", "oRaCle" };
		String postgres[] = { "PostgreSQL", "POSTGRESQL", "postgresql", "Postgresql", "poSTGresql" };
		String mysql[] = { "MySQL", "MYSQL", "mysql", "MYsql", "mySQl" };
		String sqlServer[] = { "SqlServer", "SQLSERVER", "sqlserver", "SQLserver", "sqlSERVER" };

		for (int i = 0; i < 5; i++) {
			Assert.assertEquals("ORACLE", oracle[i].toUpperCase());
			Assert.assertEquals("POSTGRESQL", postgres[i].toUpperCase());
			Assert.assertEquals("MYSQL", mysql[i].toUpperCase());
			Assert.assertEquals("SQLSERVER", sqlServer[i].toUpperCase());
		}
	}

	@SuppressWarnings("unused")
	private void init() {
		String sql = "update SEQUENCE set SEQUENCE_VALUE=0";
		int count = jdbcTemplate.update(sql);
		Assert.assertEquals(3, count);

		String sql2 = "update CONTAINERS set LAST_ENROLLED_BIO_ID=0";
		jdbcTemplate.update(sql2);
	}

}
