package jp.co.nec.aimr.properties;

import java.io.InputStream;
import java.util.Properties;
import java.util.Set;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class PropertyUtilTest {
	private final String properyName = "aimr.mm.properties";
	private Properties props;
	
	@Before
	public void setUp() throws Exception {
		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		 props = new Properties();
		InputStream resourceStream = loader.getResourceAsStream(properyName);
		props.load(resourceStream);
	}

	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void testGet_MMR_WEB_CONTEXT_NAME() {
		String result = props.getProperty("MMR_WEB_CONTEXT_NAME");
		Assert.assertEquals("matchmanager", result);		
	}
	
	@Test
	public void testGet_MMR_WEB_PORT_NUM() {
		String result = props.getProperty("MMR_WEB_PORT_NUM");
		Assert.assertEquals(null, result);		
	}
	
	@Test
	public void testGet_MMR_IP_ADDRESS() {
		String result = props.getProperty("MMR_IP_ADDRESS");
		Assert.assertEquals("127.0.0.1", result);		
	}
	@Test
	public void testGet_MMR_SERVER_SOCKET_TIMEOUT() {
		String result = props.getProperty("MMR_SERVER_SOCKET_TIMEOUT");
		Assert.assertEquals("6000", result);		
	}
	@Test
	public void testGet_MMR_MMR_GET_INQUIRY_JOB_RESULTS_WAITTIME_LIMIT() {
		String result = props.getProperty("MMR_GET_INQUIRY_JOB_RESULTS_WAITTIME_LIMIT");
		Assert.assertEquals("1500", result);		
	}
	@Test
	public void testGet_MMR_GET_EXTRACT_JOB_RESULTS_WAITTIME_LIMIT() {
		String result = props.getProperty("MMR_GET_EXTRACT_JOB_RESULTS_WAITTIME_LIMIT");
		Assert.assertEquals("1000", result);		
	}
	@Test
	public void testGet_MMR_GET_VERIFY_JOB_RESULTS_WAITTIME_LIMIT() {
		String result = props.getProperty("MMR_GET_VERIFY_JOB_RESULTS_WAITTIME_LIMIT");
		Assert.assertEquals("1000", result);		
	}
	@Test
	public void testGet_MMR_JOB_QUEUING_WAITTIME_LIMIT() {
		String result = props.getProperty("MMR_JOB_QUEUING_WAITTIME_LIMIT");
		Assert.assertEquals("1000", result);		
	}
	@Test
	public void testGet_MMR_UNIT_RECEIVER_THREAD_POLL_SIZE() {
		String result = props.getProperty("MMR_UNIT_RECEIVER_THREAD_POLL_SIZE");
		Assert.assertEquals("30", result);		
	}	

	@Test
	public void testGet_MMR_CLINET_JOB_TIME_OUT() {
		String result = props.getProperty("MMR_CLINET_JOB_TIME_OUT");
		Assert.assertEquals("3000", result);		
	}
	
	@Test
	public void testGet_MMR_DB_DRIVER() {
		String result = props.getProperty("MMR_DB_DRIVER");
		Assert.assertEquals("Oracle", result);		
	}
	
	@Test
	public void testGet_MMR_SOCKET_SERVER_PORT() {
		String result = props.getProperty("MMR_SOCKET_SERVER_PORT");
		Assert.assertEquals("8888", result);		
	}

	@Test
	public void testGetAllKeySet() {	
			Set<Object> sets = props.keySet();		
		Assert.assertEquals(11, sets.size());		
	}
}
