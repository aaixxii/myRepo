package jp.co.nec.aimr.persistence.mysql;

import java.util.List;

import javax.annotation.Resource;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import jp.co.nec.aimr.management.AIMrManger;
import jp.co.nec.aimr.persistence.aimdb.ContainerInfo;
import jp.co.nec.aimr.persistence.aimdb.ContainersDao;
import jp.co.nec.aimr.persistence.aimdb.ContainersDaoImp;
import jp.co.nec.aimr.properties.PropertyUtil;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationMysqlContext.xml" })
@Transactional
@Ignore
public class ContainersDaoImpTest {

	@Resource
	private DataSource ds;

	private ContainersDao dao;
	private JdbcTemplate jdbcTemplate;

	private MockUp<PropertyUtil> proMock;
	private MockUp<AIMrManger> manager;

	@Before
	public void setUp() throws Exception {
		proMock = new MockUp<PropertyUtil>() {
			@Mock
			public void $init() {
				return;
			}

			@Mock
			public PropertyUtil getInstance() {
				return new PropertyUtil();
			}

			@Mock
			public Integer getPropertyIntValue(String name) {
				return 3;
			}

			@Mock
			public String getPropertyValue(String name) {
				return "Oracle";
			}
		};

		manager = new MockUp<AIMrManger>() {
			@Mock
			private void init() {
				return;
			}

			@Mock
			public String getDB_DRIVER() {
				return "mysql";
			}
		};

		jdbcTemplate = new JdbcTemplate(ds);
		dao = new ContainersDaoImp(jdbcTemplate);
		jdbcTemplate = new JdbcTemplate(ds);
	}

	@After
	public void tearDown() throws Exception {
		dao = null;
		jdbcTemplate = null;
		proMock.tearDown();
		manager.tearDown();
	}

	@Test
	public void testGetAllContainerInfo() {
		List<ContainerInfo> fullContainerInfo = dao.getAllContainerInfo();
		Assert.assertNotNull(fullContainerInfo);
		for (ContainerInfo info : fullContainerInfo) {
			switch (info.getContainerId()) {
			case 1:
				Assert.assertEquals("CML", info.getAlgorithm());
				Assert.assertEquals("PERSON_BIOMETRICS_1", info.getPersonBiTtableName());
				Assert.assertEquals("PERSON_BIO_CHANGE_LOG_1", info.getConatainerLogTableName());
				Assert.assertEquals("FINGER(10)", info.getModality());
				Assert.assertEquals(50000, info.getMaxRecordCount().intValue());
				Assert.assertEquals(0, info.getRecordCount().intValue());
				Assert.assertEquals(15680, info.getTemplateSize().intValue());
				Assert.assertEquals(0, info.getVersion().intValue());
				break;

			case 2:
				Assert.assertEquals("S17", info.getAlgorithm());
				Assert.assertEquals("PERSON_BIOMETRICS_2", info.getPersonBiTtableName());
				Assert.assertEquals("PERSON_BIO_CHANGE_LOG_2", info.getConatainerLogTableName());
				Assert.assertEquals("FACE", info.getModality());
				Assert.assertEquals(50000, info.getMaxRecordCount().intValue());
				Assert.assertEquals(1, info.getRecordCount().intValue());
				Assert.assertEquals(2555, info.getTemplateSize().intValue());
				Assert.assertEquals(1, info.getVersion().intValue());
				break;
			case 3:
				Assert.assertEquals("S14", info.getAlgorithm());
				Assert.assertEquals("PERSON_BIOMETRICS_3", info.getPersonBiTtableName());
				Assert.assertEquals("PERSON_BIO_CHANGE_LOG_3", info.getConatainerLogTableName());
				Assert.assertEquals("FACE", info.getModality());				
				Assert.assertEquals(1, info.getRecordCount().intValue());
				Assert.assertEquals(2555, info.getTemplateSize().intValue());
				Assert.assertEquals(1, info.getVersion().intValue());
				break;
			case 4:
				Assert.assertEquals("NIRIS", info.getAlgorithm());
				Assert.assertEquals("PERSON_BIOMETRICS_4", info.getPersonBiTtableName());
				Assert.assertEquals("PERSON_BIO_CHANGE_LOG_4", info.getConatainerLogTableName());
				Assert.assertEquals("IRIS", info.getModality());
				Assert.assertEquals(50000, info.getMaxRecordCount().intValue());
				Assert.assertEquals(4, info.getRecordCount().intValue());
				Assert.assertEquals(4713, info.getTemplateSize().intValue());
				Assert.assertEquals(4, info.getVersion().intValue());
				break;
			case 8:
				Assert.assertEquals("CML", info.getAlgorithm());
				Assert.assertEquals("PERSON_BIOMETRICS_8", info.getPersonBiTtableName());
				Assert.assertEquals("PERSON_BIO_CHANGE_LOG_8", info.getConatainerLogTableName());
				Assert.assertEquals("FINGER(2)", info.getModality());
				Assert.assertEquals(50000, info.getMaxRecordCount().intValue());
				Assert.assertEquals(1, info.getRecordCount().intValue());
				Assert.assertEquals(3000, info.getTemplateSize().intValue());
				Assert.assertEquals(1, info.getVersion().intValue());
				break;
			case 9:
				Assert.assertEquals("NIRIS+S17", info.getAlgorithm());
				Assert.assertEquals("PERSON_BIOMETRICS_9", info.getPersonBiTtableName());
				Assert.assertEquals("PERSON_BIO_CHANGE_LOG_9", info.getConatainerLogTableName());
				Assert.assertEquals("IRIS+FACE", info.getModality());
				Assert.assertEquals(50000, info.getMaxRecordCount().intValue());
				Assert.assertEquals(1, info.getRecordCount().intValue());
				Assert.assertEquals(7268, info.getTemplateSize().intValue());
				Assert.assertEquals(1, info.getVersion().intValue());
				break;
			}
		}
	}
}
