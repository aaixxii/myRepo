package jp.co.nec.aimr.agent;

import java.io.IOException;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import jp.co.nec.aimr.properties.PropertyUtil;
import mockit.Mock;
import mockit.MockUp;

public class AimRSocketServerTest {
	private MockUp<PropertyUtil> proMock;
	private MockUp<AimRSocketServer> server;

	@Before
	public void setUp() throws Exception {
		proMock = new MockUp<PropertyUtil>() {
			@Mock
			public void $init() {
				return;
			}

			@Mock
			public PropertyUtil getInstance() {
				return new PropertyUtil();
			}

			@Mock
			public Integer getPropertyIntValue(String name) {
				return 300;
			}

			@Mock
			public Long getPropertyLongValue(String name) {
				return 400L;
			}
		};	
		
		server = new MockUp<AimRSocketServer>() {
			@Mock
			public void $init() {
				return;
			}
			
			@Mock
			public void service() throws IOException {
				return;
			}
		};
	}

	@After
	public void tearDown() throws Exception {
		proMock.tearDown();
		server.tearDown();
	}

	@Test
	@Ignore
	public void testOnStop() throws IOException {
		AimRSocketServer server = new AimRSocketServer();
		Assert.assertNotNull(server);
		Assert.assertTrue(server instanceof AimRSocketServer);
		server.onStop();
		server = null;
	}

	@Test
	public void testAimRSocketServer() throws IOException {
		
		AimRSocketServer server = new AimRSocketServer();
		Assert.assertNotNull(server);
		Assert.assertTrue(server instanceof AimRSocketServer);	
		server = null;
	}
}
