package jp.co.nec.aimr.service.inquiry;

import java.lang.reflect.Field;
import java.util.concurrent.CopyOnWriteArrayList;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.google.protobuf.ByteString;

import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputPayload;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractJobResult;
import jp.co.nec.aim.message.proto.InquiryEnumTypes.Pc2RotationLimitType;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBCMLOptions;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBInquiryJobInfo;
import jp.co.nec.aim.message.proto.InquiryService.PBIdentifyRequest;
import jp.co.nec.aim.message.proto.InquiryService.PBIdentifyResponse;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobRequest;
import jp.co.nec.aimr.common.ErrorDifinitions;
import jp.co.nec.aimr.common.UnitCard;
import jp.co.nec.aimr.common.UnitStatus;
import jp.co.nec.aimr.common.UnitType;
import jp.co.nec.aimr.event.EventListener;
import jp.co.nec.aimr.event.EventNotifier;
import jp.co.nec.aimr.management.AIMrManger;
import jp.co.nec.aimr.management.MMrJobManager;
import jp.co.nec.aimr.matchunit.UnitMessageSender;
import jp.co.nec.aimr.properties.PropertyUtil;
import jp.co.nec.aimr.service.extract.ExtractService;
import mockit.Mock;
import mockit.MockUp;

public class AimrInquiryServiceTest {
	private MockUp<PropertyUtil> proMock;
	private MockUp<AIMrManger> manager;

	@Before
	public void setUp() throws Exception {
		proMock = new MockUp<PropertyUtil>() {
			@Mock
			public void $init() {
				return;
			}

			@Mock
			public PropertyUtil getInstance() {
				return new PropertyUtil();
			}

			@Mock
			public Integer getPropertyIntValue(String name) {
				return 300;
			}

			@Mock
			public Long getPropertyLongValue(String name) {
				return 400L;
			}
			@Mock
			public String getPropertyValue(String name) {
				return "Oracle";
			}
		};

		manager = new MockUp<AIMrManger>() {
			@Mock
			private void init() {
				return;
			}
		};
	}

	@After
	public void tearDown() throws Exception {
		proMock.tearDown();
		manager.tearDown();
	}

	@Test
	public void testAimrInquiryService() {
		AimrInquiryService service = new AimrInquiryService(createInquiryJobRequst());
		Assert.assertNotNull(service);
		Assert.assertTrue(service instanceof AimrInquiryService);
	}

	@Test
	public void testProcessIdentifyRequest_hasExtract_normal() {
		MockUp<EventNotifier> notifyMocker = new MockUp<EventNotifier>() {
			@Mock
			public void fireOnIdentifyJobqueueing(int containerId, Long inquiryJobId) {
				return;
			}
		};

		MockUp<MMrJobManager> jobMangerMocker = new MockUp<MMrJobManager>() {
			@Mock
			public PBIdentifyResponse getOneInqJobResult(Long inqJobId) {
				return CreateOKInquiryJobResult();
			}
		};

		MockUp<ExtractService> extMock = new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};

		AimrInquiryService service = new AimrInquiryService(createInquiryJobRequst());
		PBIdentifyResponse result = service.processIdentifyRequest();
		Assert.assertNotNull(result);
		PBServiceState sate = result.getServiceState();
		ServiceStateType stateType = sate.getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, stateType);
		notifyMocker.tearDown();
		jobMangerMocker.tearDown();
		extMock.tearDown();
	}

	@Test
	public void testProcessIdentifyRequest_hasExtract_no_active_mu() {
		MockUp<ExtractService> extMock = new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};
		AimrInquiryService service = new AimrInquiryService(createInquiryJobRequst());
		PBIdentifyResponse result = service.processIdentifyRequest();
		Assert.assertNotNull(result);
		PBServiceState sate = result.getServiceState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, sate.getState());
		Assert.assertEquals(ErrorDifinitions.IDENTIFY_JOB_NO_ACTIVE_MU.getDescriptionWithKey(null, null, null), sate.getReason().getDescription());
		Assert.assertEquals(ErrorDifinitions.IDENTIFY_JOB_NO_ACTIVE_MU.getStringCode(), sate.getReason().getCode());

		extMock.tearDown();
	}

	@Test
	public void testProcessIdentifyRequest_hasExtract_timeout() {
		MockUp<EventNotifier> notifyMocker = new MockUp<EventNotifier>() {
			@Mock
			public void fireOnIdentifyJobqueueing(int containerId, Long inquiryJobId) {
				return;
			}
		};
		MockUp<ExtractService> extMock = new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};

		AimrInquiryService service = new AimrInquiryService(createInquiryJobRequst());
		PBIdentifyResponse result = service.processIdentifyRequest();
		Assert.assertNotNull(result);
		PBServiceState sate = result.getServiceState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, sate.getState());
		Assert.assertEquals(ErrorDifinitions.IDENTIFY_JOB_TIMEOUT.getDescriptionWithKey(null, null, null), sate.getReason().getDescription());
		Assert.assertEquals(ErrorDifinitions.IDENTIFY_JOB_TIMEOUT.getStringCode(), sate.getReason().getCode());
		notifyMocker.tearDown();
		extMock.tearDown();
	}

	@Test
	public void testProcessIdentifyRequest_hasTemplate_normal() {
		MockUp<EventNotifier> notifyMocker = new MockUp<EventNotifier>() {
			@Mock
			public void fireOnIdentifyJobqueueing(int containerId, Long inquiryJobId) {
				return;
			}
		};

		MockUp<MMrJobManager> jobMangerMocker = new MockUp<MMrJobManager>() {
			@Mock
			public PBIdentifyResponse getOneInqJobResult(Long inqJobId) {
				return CreateOKInquiryJobResult();
			}
		};

		MockUp<ExtractService> extMock = new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};

		AimrInquiryService service = new AimrInquiryService(CreateInquiryJobRequstHasTemplagte());
		PBIdentifyResponse result = service.processIdentifyRequest();
		Assert.assertNotNull(result);
		PBServiceState sate = result.getServiceState();
		ServiceStateType stateType = sate.getState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_SUCCESS, stateType);
		notifyMocker.tearDown();
		jobMangerMocker.tearDown();
		extMock.tearDown();
	}

	@Test
	public void testProcessIdentifyRequest_hasTemplate_no_active_mu() {
		MockUp<ExtractService> extMock = new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};
		AimrInquiryService service = new AimrInquiryService(CreateInquiryJobRequstHasTemplagte());
		PBIdentifyResponse result = service.processIdentifyRequest();
		Assert.assertNotNull(result);
		PBServiceState sate = result.getServiceState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, sate.getState());
		Assert.assertEquals(ErrorDifinitions.IDENTIFY_JOB_NO_ACTIVE_MU.getDescriptionWithKey(null, null, null), sate.getReason().getDescription());
		Assert.assertEquals(ErrorDifinitions.IDENTIFY_JOB_NO_ACTIVE_MU.getStringCode(), sate.getReason().getCode());

		extMock.tearDown();
	}

	@Test
	public void testProcessIdentifyRequest_hasTemplate_timeout() {
		MockUp<EventNotifier> notifyMocker = new MockUp<EventNotifier>() {
			@Mock
			public void fireOnIdentifyJobqueueing(int containerId, Long inquiryJobId) {
				return;
			}
		};
		MockUp<ExtractService> extMock = new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};

		AimrInquiryService service = new AimrInquiryService(CreateInquiryJobRequstHasTemplagte());
		PBIdentifyResponse result = service.processIdentifyRequest();
		Assert.assertNotNull(result);
		PBServiceState sate = result.getServiceState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, sate.getState());
		Assert.assertEquals(ErrorDifinitions.IDENTIFY_JOB_TIMEOUT.getDescriptionWithKey(null, null, null), sate.getReason().getDescription());
		Assert.assertEquals(ErrorDifinitions.IDENTIFY_JOB_TIMEOUT.getStringCode(), sate.getReason().getCode());
		notifyMocker.tearDown();
		extMock.tearDown();
	}

	@SuppressWarnings("unchecked")
	@Test
	@Ignore
	public void testProcessIdentifyRequest_hasTemplate_send_faild() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		int size = 5;
		for (int i = 0; i < size; i++) {
			UnitCard unitCard = new UnitCard();
			unitCard.setUnitId(Long.valueOf(i + 1));
			unitCard.setUnitType(UnitType.MATCHER);
			unitCard.setStatus(UnitStatus.ready);
			UnitMessageSender sender = new UnitMessageSender(unitCard);
			EventNotifier.getInstance().addMuSenderListener(sender);
		}

		MockUp<UnitMessageSender> sender = new MockUp<UnitMessageSender>() {
			@Mock
			private boolean sendInquiryJob(InquiryJob inquiryJob) {
				return false;
			}
		};

		MockUp<ExtractService> extMock = new MockUp<ExtractService>() {
			@Mock
			public PBExtractJobResult doExtract() {
				return createExtractResult(ServiceStateType.SERVICE_STATE_SUCCESS);
			}
		};

		AimrInquiryService service = new AimrInquiryService(CreateInquiryJobRequstHasTemplagte());
		PBIdentifyResponse result = service.processIdentifyRequest();
		Assert.assertNotNull(result);
		PBServiceState sate = result.getServiceState();
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, sate.getState());
		Assert.assertEquals(ErrorDifinitions.IDENTIFY_REQUST_SEND_FAILD.getDescription(), sate.getReason().getDescription());
		Assert.assertEquals(ErrorDifinitions.IDENTIFY_REQUST_SEND_FAILD.getStringCode(), sate.getReason().getCode());
		Class<EventNotifier> cls = EventNotifier.class;
		Field field = cls.getDeclaredField("muSenderListenerList");
		field.setAccessible(true);
		CopyOnWriteArrayList<EventListener> copyOnWriteArrayList = (CopyOnWriteArrayList<EventListener>) field.get(EventNotifier.getInstance());
		copyOnWriteArrayList.clear();
		extMock.tearDown();
		sender.tearDown();
	}

	private static PBIdentifyRequest CreateInquiryJobRequstHasTemplagte() {
		PBIdentifyRequest.Builder pbIdentiyReq = PBIdentifyRequest.newBuilder();
		// PBExtractInputPayload.Builder pbExtPayload =
		// PBExtractInputPayload.newBuilder();
		PBCMLOptions.Builder pmCm = PBCMLOptions.newBuilder();
		pmCm.setRotationLimit(Pc2RotationLimitType.PC2_ROTATION_DEGREE_15);
		pmCm.setParameterId(1);
		// pbIdentiyReq.setExtractInputPayload(pbExtPayload);
		PBInquiryJobRequest.Builder jobRequest = PBInquiryJobRequest.newBuilder();
		PBInquiryJobInfo.Builder info = PBInquiryJobInfo.newBuilder();
		info.setContainerId(1);
		info.setMaxCandidate(100);
		jobRequest.setJobInfo(info);
		jobRequest.setTemplate(ByteString.copyFrom("abcdefghijklmnoprqstuvwxyz".getBytes()));
		pbIdentiyReq.setInquiryJobRequest(jobRequest);
		return pbIdentiyReq.build();
	}

	private static PBIdentifyRequest createInquiryJobRequst() {
		PBIdentifyRequest.Builder pbIdentiyReq = PBIdentifyRequest.newBuilder();
		PBExtractInputPayload.Builder pbExtPayload = PBExtractInputPayload.newBuilder();
		PBCMLOptions.Builder pmCm = PBCMLOptions.newBuilder();
		pmCm.setRotationLimit(Pc2RotationLimitType.PC2_ROTATION_DEGREE_15);
		pmCm.setParameterId(1);
		pbIdentiyReq.setExtractInputPayload(pbExtPayload);
		PBInquiryJobRequest.Builder jobRequest = PBInquiryJobRequest.newBuilder();
		PBInquiryJobInfo.Builder info = PBInquiryJobInfo.newBuilder();
		info.setContainerId(1);
		info.setMaxCandidate(100);
		jobRequest.setJobInfo(info);

		pbIdentiyReq.setInquiryJobRequest(jobRequest);
		return pbIdentiyReq.build();
	}

	private PBExtractJobResult createExtractResult(ServiceStateType state) {
		PBExtractJobResult.Builder pBExtractJobResult = PBExtractJobResult.newBuilder();
		PBServiceState.Builder status = PBServiceState.newBuilder();
		status.setState(state);
		pBExtractJobResult.setServiceState(status);
		pBExtractJobResult.setTemplate(ByteString.copyFrom("abcdefjhijklm".getBytes()));
		return pBExtractJobResult.build();
	}

	private PBIdentifyResponse CreateOKInquiryJobResult() {
		PBIdentifyResponse.Builder jobResult = PBIdentifyResponse.newBuilder();
		PBServiceState.Builder status = PBServiceState.newBuilder();
		status.setState(ServiceStateType.SERVICE_STATE_SUCCESS);
		jobResult.setServiceState(status);
		return jobResult.build();
	}

}
