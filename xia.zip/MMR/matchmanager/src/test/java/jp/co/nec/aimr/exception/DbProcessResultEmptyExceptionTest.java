package jp.co.nec.aimr.exception;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import jp.co.nec.aimr.common.ErrorDifinitions;

public class DbProcessResultEmptyExceptionTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testDbProcessResultEmptyExceptionString() {
		String eMsg = "db error!";
		DbProcessResultEmptyException dbException = new DbProcessResultEmptyException(eMsg);
		Assert.assertNotNull(dbException);
		Assert.assertTrue(dbException instanceof DbProcessResultEmptyException);
		
	}

	@Test
	public void testDbProcessResultEmptyExceptionThrowable() {
		Throwable e = new Throwable();
		DbProcessResultEmptyException dbException = new DbProcessResultEmptyException(e);
		Assert.assertNotNull(dbException);
		Assert.assertTrue(dbException instanceof DbProcessResultEmptyException);		
	}

	@Test
	public void testDbProcessResultEmptyExceptionStringThrowable() {
		String eMsg = "db error!";
		Throwable e = new Throwable();
		DbProcessResultEmptyException dbException = new DbProcessResultEmptyException(eMsg, e);
		Assert.assertNotNull(dbException);
		Assert.assertTrue(dbException instanceof DbProcessResultEmptyException);		
		
	}

	@Test
	public void testDbProcessResultEmptyExceptionErrorDifinitions() {
		ErrorDifinitions e = ErrorDifinitions.DB_PROCESS_ERROR;
		DbProcessResultEmptyException dbException = new DbProcessResultEmptyException(e);
		Assert.assertNotNull(dbException);
		Assert.assertTrue(dbException instanceof DbProcessResultEmptyException);		
	}

}
