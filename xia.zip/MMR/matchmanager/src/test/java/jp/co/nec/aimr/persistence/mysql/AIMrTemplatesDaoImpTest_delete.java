
package jp.co.nec.aimr.persistence.mysql;

import javax.annotation.Resource;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import jp.co.nec.aim.message.proto.AIMMessages.PBContainerSyncRequest;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aimr.common.ErrorDifinitions;
import jp.co.nec.aimr.management.AIMrManger;
import jp.co.nec.aimr.persistence.aimdb.AIMrTemplatesDao;
import jp.co.nec.aimr.persistence.aimdb.AIMrTemplatesDaoImp;
import jp.co.nec.aimr.persistence.aimdb.DataBaseUtil;
import jp.co.nec.aimr.persistence.aimdb.SyncResultWithStatus;
import jp.co.nec.aimr.properties.PropertyUtil;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationMysqlContext.xml" })
@Transactional
public class AIMrTemplatesDaoImpTest_delete {

	@Resource
	private DataSource ds;

	@Resource
	private DataSource testDs;

	private AIMrTemplatesDao dao;
	private JdbcTemplate jdbcTemplate;
	private MockUp<DataBaseUtil> dbMock;
	private MockUp<PropertyUtil> proMock;
	private MockUp<AIMrManger> manager;

	@Before
	public void setUp() throws Exception {
		jdbcTemplate = new JdbcTemplate(ds);
		dao = new AIMrTemplatesDaoImp(jdbcTemplate);
		jdbcTemplate.execute("delete from PERSON_BIOMETRICS_1");
		jdbcTemplate.execute("delete from PERSON_BIO_CHANGE_LOG_1");
		jdbcTemplate.execute("COMMIT");
		recoverConatainerData();
		dbMock = new MockUp<DataBaseUtil>() {
			@Mock
			public DataSource lookupDataSource() {
				return ds;
			}
		};
		proMock = new MockUp<PropertyUtil>() {
			@Mock
			public void $init() {
				return;
			}

			@Mock
			public PropertyUtil getInstance() {
				return new PropertyUtil();
			}

			@Mock
			public Integer getPropertyIntValue(String name) {
				return 3;
			}

			@Mock
			public String getPropertyValue(String name) {
				return "mysql";
			}
		};

		manager = new MockUp<AIMrManger>() {
			@Mock
			private void init() {
				return;
			}
		};

	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.execute("delete from PERSON_BIOMETRICS_1");
		jdbcTemplate.execute("delete from PERSON_BIO_CHANGE_LOG_1");
		jdbcTemplate.execute("COMMIT");
		recoverConatainerData();
		dbMock.tearDown();
		proMock.tearDown();
		manager.tearDown();
	}

	@Test
	public void testAIMrTemplatesDaoImp() {
		Assert.assertNotNull(dao);
		Assert.assertTrue(dao instanceof AIMrTemplatesDaoImp);
	}

	@Test
	public void testDeleteTemplate_eventId_null_4() {
		PBContainerSyncRequest pbSyncRequet = null;
		SyncResultWithStatus syncResultWithStatus = null;
		Integer containerId = 1;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		long changeId = jdbcTemplate.queryForObject(
				"SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'CHANGE_ID_SEQ'", Long.class);
		long biometricsId = jdbcTemplate.queryForObject(
				"SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'BIOMETRICS_ID_SEQ'", Long.class);

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "INSERT INTO PERSON_BIOMETRICS_1 (BIOMETRICS_ID, USER_KEY, USER_EVENT_ID, BIOMETRICS_DATA, BIOMETRICS_DATA_LEN, REGISTERED_TS) VALUES (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql,
					new Object[] { Long.valueOf(biometricsId + i), userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		int biometorisRecordCout = jdbcTemplate
				.queryForObject("SELECT COUNT(BIOMETRICS_ID) FROM PERSON_BIOMETRICS_1", Integer.class).intValue();
		syncResultWithStatus = dao.deleteTemplate(containerId, userKey, null);
		pbSyncRequet = syncResultWithStatus.getpBContainerSyncRequest();
		Assert.assertNotNull(pbSyncRequet);
		for (int i = 0; i < 4; i++) {
			Assert.assertEquals(containerId.intValue(), pbSyncRequet.getContainerId());
			Assert.assertEquals(4, pbSyncRequet.getContainerSyncInfoCount());
			Assert.assertEquals("CONTAINER_ASSIGNED", pbSyncRequet.getAssignedState().name());
			Assert.assertEquals(i + 1, pbSyncRequet.getContainerSyncInfoList().get(i).getVersion());
			Assert.assertEquals(i + 1, pbSyncRequet.getContainerSyncInfoList().get(i).getEventId());
			Assert.assertEquals("DELETE", pbSyncRequet.getContainerSyncInfoList().get(0).getCommand().name());
			Assert.assertEquals(userKey, pbSyncRequet.getContainerSyncInfoList().get(0).getExternalId());
		}
		Assert.assertEquals(changeId + 4, jdbcTemplate
				.queryForObject("SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'CHANGE_ID_SEQ'", Long.class)
				.longValue());
		Assert.assertEquals(biometorisRecordCout - 4, jdbcTemplate
				.queryForObject("SELECT COUNT(BIOMETRICS_ID) FROM PERSON_BIOMETRICS_1", Integer.class).intValue());
	}

	@Test
	public void testDeleteTemplate_eventId_null_1() {
		PBContainerSyncRequest pbSyncRequet = null;
		SyncResultWithStatus syncResultWithStatus = null;
		Integer containerId = 1;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		long changeId = jdbcTemplate.queryForObject(
				"SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'CHANGE_ID_SEQ'", Long.class);
		long biometricsId = jdbcTemplate.queryForObject(
				"SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'BIOMETRICS_ID_SEQ'", Long.class);

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "INSERT INTO PERSON_BIOMETRICS_1 (BIOMETRICS_ID, USER_KEY, USER_EVENT_ID, BIOMETRICS_DATA, BIOMETRICS_DATA_LEN, REGISTERED_TS) VALUES (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 1; i++) {
			jdbcTemplate.update(insSql,
					new Object[] { Long.valueOf(biometricsId + i), userKey, i + 1, data, dataSize, "2016/06/14" });
		}
		int biometorisRecordCout = jdbcTemplate
				.queryForObject("select count(BIOMETRICS_ID) from PERSON_BIOMETRICS_1", Integer.class).intValue();
		syncResultWithStatus = dao.deleteTemplate(containerId, userKey, null);
		pbSyncRequet = syncResultWithStatus.getpBContainerSyncRequest();
		Assert.assertNotNull(pbSyncRequet);
		for (int i = 0; i < 1; i++) {
			Assert.assertEquals(containerId.intValue(), pbSyncRequet.getContainerId());
			Assert.assertEquals(1, pbSyncRequet.getContainerSyncInfoCount());
			Assert.assertEquals("CONTAINER_ASSIGNED", pbSyncRequet.getAssignedState().name());
			Assert.assertEquals(i + 1, pbSyncRequet.getContainerSyncInfoList().get(i).getVersion());
			Assert.assertEquals(i + 1, pbSyncRequet.getContainerSyncInfoList().get(i).getEventId());
			Assert.assertEquals("DELETE", pbSyncRequet.getContainerSyncInfoList().get(0).getCommand().name());
			Assert.assertEquals(userKey, pbSyncRequet.getContainerSyncInfoList().get(0).getExternalId());
		}
		Assert.assertEquals(changeId + 1, jdbcTemplate
				.queryForObject("SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'CHANGE_ID_SEQ'", Long.class)
				.longValue());
		Assert.assertEquals(biometorisRecordCout - 1, jdbcTemplate
				.queryForObject("select count(BIOMETRICS_ID) from PERSON_BIOMETRICS_1", Integer.class).intValue());
	}

	@Test
	public void testDeleteTemplate_eventId_null_rollback() {
		PBContainerSyncRequest pbSyncRequet = null;
		SyncResultWithStatus syncResultWithStatus = null;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		long changeId = jdbcTemplate.queryForObject(
				"SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'CHANGE_ID_SEQ'", Long.class);
		long biometricsId = jdbcTemplate.queryForObject(
				"SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'BIOMETRICS_ID_SEQ'", Long.class);
		int biometorisRecordCout = jdbcTemplate
				.queryForObject("select count(BIOMETRICS_ID) from PERSON_BIOMETRICS_1", Integer.class).intValue();

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "INSERT INTO PERSON_BIOMETRICS_1 (BIOMETRICS_ID, USER_KEY, USER_EVENT_ID, BIOMETRICS_DATA, BIOMETRICS_DATA_LEN, REGISTERED_TS) VALUES (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql,
					new Object[] { Long.valueOf(biometricsId + i), userKey, i + 1, data, dataSize, "2016/06/14" });
		}

		syncResultWithStatus = dao.deleteTemplate(-9999, userKey, null);
		pbSyncRequet = syncResultWithStatus.getpBContainerSyncRequest();
		Assert.assertNull(pbSyncRequet);
		Assert.assertEquals(changeId, jdbcTemplate
				.queryForObject("SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'CHANGE_ID_SEQ'", Long.class)
				.longValue());
		Assert.assertEquals(biometorisRecordCout, jdbcTemplate
				.queryForObject("select count(BIOMETRICS_ID) from PERSON_BIOMETRICS_1", Integer.class).intValue());
		PBServiceState syncStatus = syncResultWithStatus.getpBServiceState();
		System.out.println(syncStatus.toString());
	}

	@Test
	public void testDeleteTemplate_eventId_null_rollback2() {
		PBContainerSyncRequest pbSyncRequet = null;
		SyncResultWithStatus syncResultWithStatus = null;
		Integer containerId = 1;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		long changeId = jdbcTemplate.queryForObject(
				"SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'CHANGE_ID_SEQ'", Long.class);
		long biometricsId = jdbcTemplate.queryForObject(
				"SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'BIOMETRICS_ID_SEQ'", Long.class);
		int biometorisRecordCout = jdbcTemplate
				.queryForObject("select count(BIOMETRICS_ID) from PERSON_BIOMETRICS_1", Integer.class).intValue();

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "INSERT INTO PERSON_BIOMETRICS_1 (BIOMETRICS_ID, USER_KEY, USER_EVENT_ID, BIOMETRICS_DATA, BIOMETRICS_DATA_LEN, REGISTERED_TS) VALUES (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql,
					new Object[] { Long.valueOf(biometricsId + i), userKey, i + 1, data, dataSize, "2016/06/14" });
		}

		syncResultWithStatus = dao.deleteTemplate(containerId, null, null);
		pbSyncRequet = syncResultWithStatus.getpBContainerSyncRequest();
		Assert.assertNull(pbSyncRequet);
		Assert.assertEquals(changeId, jdbcTemplate
				.queryForObject("SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'CHANGE_ID_SEQ'", Long.class)
				.longValue());
		Assert.assertEquals(biometorisRecordCout, jdbcTemplate
				.queryForObject("select count(BIOMETRICS_ID) from PERSON_BIOMETRICS_1", Integer.class).intValue());
	}

	@Test
	public void testDeleteTemplate_eventId_null_more_one() {
		PBContainerSyncRequest pbSyncRequet = null;
		SyncResultWithStatus syncResultWithStatus = null;
		Integer containerId = 1;
		String userKey = "test";
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		String updateContainersSql = "UPDATE CONTAINERS SET  RECORD_COUNT = RECORD_COUNT + MAX_RECORD_COUNT "
				+ "where container_id = ?";
		jdbcTemplate.update(updateContainersSql, 1L);

		long changeId = jdbcTemplate.queryForObject(
				"SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'CHANGE_ID_SEQ'", Long.class);
		long biometricsId = jdbcTemplate.queryForObject(
				"SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'BIOMETRICS_ID_SEQ'", Long.class);
		int biometorisRecordCout = jdbcTemplate
				.queryForObject("select count(BIOMETRICS_ID) from PERSON_BIOMETRICS_1", Integer.class).intValue();

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		String insSql = "INSERT INTO PERSON_BIOMETRICS_1 (BIOMETRICS_ID, USER_KEY, USER_EVENT_ID, BIOMETRICS_DATA, BIOMETRICS_DATA_LEN, REGISTERED_TS) VALUES (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql,
					new Object[] { Long.valueOf(biometricsId + i), userKey, i + 1, data, dataSize, "2016/06/14" });
		}

		syncResultWithStatus = dao.deleteTemplate(containerId, null, null);
		pbSyncRequet = syncResultWithStatus.getpBContainerSyncRequest();
		Assert.assertNull(pbSyncRequet);
		Assert.assertEquals(changeId, jdbcTemplate
				.queryForObject("SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'CHANGE_ID_SEQ'", Long.class)
				.longValue());
		Assert.assertEquals(biometorisRecordCout, jdbcTemplate
				.queryForObject("select count(BIOMETRICS_ID) from PERSON_BIOMETRICS_1", Integer.class).intValue());
		PBServiceState syncStauts = syncResultWithStatus.getpBServiceState();
		Assert.assertNotNull(syncStauts);
		System.out.println(syncStauts.toString());
	}

	@Test
	public void testDeleteTemplate_eventId_notNull() {
		PBContainerSyncRequest pbSyncRequet = null;
		SyncResultWithStatus syncResultWithStatus = null;
		Integer containerId = 1;
		String userKey = "test";
		Integer eventId = 1;
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		long changeId = jdbcTemplate.queryForObject(
				"SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'CHANGE_ID_SEQ'", Long.class);
		long biometricsId = jdbcTemplate.queryForObject(
				"SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'BIOMETRICS_ID_SEQ'", Long.class);

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");

		String insSql = "INSERT INTO PERSON_BIOMETRICS_1 (BIOMETRICS_ID, USER_KEY, USER_EVENT_ID, BIOMETRICS_DATA, BIOMETRICS_DATA_LEN, REGISTERED_TS) VALUES (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql,
					new Object[] { Long.valueOf(biometricsId + i), userKey, i + 1, data, dataSize, "2016/06/14" });
		}

		syncResultWithStatus = dao.deleteTemplate(containerId, userKey, eventId);
		pbSyncRequet = syncResultWithStatus.getpBContainerSyncRequest();
		Assert.assertNotNull(pbSyncRequet);
		Assert.assertEquals(1, pbSyncRequet.getContainerSyncInfoList().size());

		Assert.assertEquals(containerId.intValue(), pbSyncRequet.getContainerId());
		Assert.assertEquals(1, pbSyncRequet.getContainerSyncInfoCount());
		Assert.assertEquals("CONTAINER_ASSIGNED", pbSyncRequet.getAssignedState().name());
		Assert.assertEquals(1, pbSyncRequet.getContainerSyncInfoList().get(0).getVersion());
		Assert.assertEquals(1, pbSyncRequet.getContainerSyncInfoList().get(0).getEventId());
		Assert.assertEquals("DELETE", pbSyncRequet.getContainerSyncInfoList().get(0).getCommand().name());
		Assert.assertEquals(userKey, pbSyncRequet.getContainerSyncInfoList().get(0).getExternalId());
		Assert.assertEquals(changeId + 1, jdbcTemplate
				.queryForObject("SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'CHANGE_ID_SEQ'", Long.class)
				.longValue());
		Assert.assertEquals(4 - 1, jdbcTemplate
				.queryForObject("select count(BIOMETRICS_ID) from PERSON_BIOMETRICS_1", Integer.class).intValue());
	}

	@Test
	public void testDeleteTemplate_eventId_notNull_rollback() {
		PBContainerSyncRequest pbSyncRequet = null;
		SyncResultWithStatus syncResultWithStatus = null;
		String userKey = "test";
		Integer eventId = 1;
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		long changeId = jdbcTemplate.queryForObject(
				"SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'CHANGE_ID_SEQ'", Long.class);
		long biometricsId = jdbcTemplate.queryForObject(
				"SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'BIOMETRICS_ID_SEQ'", Long.class);

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		int biometorisRecordCout = jdbcTemplate
				.queryForObject("select count(BIOMETRICS_ID) from PERSON_BIOMETRICS_1", Integer.class).intValue();

		String insSql = "INSERT INTO PERSON_BIOMETRICS_1 (BIOMETRICS_ID, USER_KEY, USER_EVENT_ID, BIOMETRICS_DATA, BIOMETRICS_DATA_LEN, REGISTERED_TS) VALUES (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql,
					new Object[] { Long.valueOf(biometricsId + i), userKey, i + 1, data, dataSize, "2016/06/14" });
		}

		syncResultWithStatus = dao.deleteTemplate(-9999, userKey, eventId);
		pbSyncRequet = syncResultWithStatus.getpBContainerSyncRequest();
		Assert.assertNull(pbSyncRequet);

		Assert.assertEquals(changeId, jdbcTemplate
				.queryForObject("SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'CHANGE_ID_SEQ'", Long.class)
				.longValue());
		Assert.assertEquals(biometorisRecordCout, jdbcTemplate
				.queryForObject("select count(BIOMETRICS_ID) from PERSON_BIOMETRICS_1", Integer.class).intValue());
	}

	@Test
	public void testDeleteTemplate_eventId_notNull_rollback2() {
		PBContainerSyncRequest pbSyncRequet = null;
		SyncResultWithStatus syncResultWithStatus = null;
		Integer containerId = 1;
		String userKey = "test";
		Integer eventId = 1;
		String sdata = "abcdefjhijklmuvwxyz";
		byte[] data = sdata.getBytes();
		int dataSize = data.length;

		long changeId = jdbcTemplate.queryForObject(
				"SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'CHANGE_ID_SEQ'", Long.class);
		long biometricsId = jdbcTemplate.queryForObject(
				"SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'BIOMETRICS_ID_SEQ'", Long.class);

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		int biometorisRecordCout = jdbcTemplate
				.queryForObject("select count(BIOMETRICS_ID) from PERSON_BIOMETRICS_1", Integer.class).intValue();

		String insSql = "INSERT INTO PERSON_BIOMETRICS_1 (BIOMETRICS_ID, USER_KEY, USER_EVENT_ID, BIOMETRICS_DATA, BIOMETRICS_DATA_LEN, REGISTERED_TS) VALUES (?, ?, ?, ?, ?, ?)";
		for (int i = 0; i < 4; i++) {
			jdbcTemplate.update(insSql,
					new Object[] { Long.valueOf(biometricsId + i), userKey, i + 1, data, dataSize, "2016/06/14" });
		}

		syncResultWithStatus = dao.deleteTemplate(containerId, null, eventId);
		pbSyncRequet = syncResultWithStatus.getpBContainerSyncRequest();
		Assert.assertNull(pbSyncRequet);

		Assert.assertEquals(changeId, jdbcTemplate
				.queryForObject("SELECT SEQUENCE_VALUE FROM SEQUENCE WHERE SEQUENCE_NAME = 'CHANGE_ID_SEQ'", Long.class)
				.longValue());
		Assert.assertEquals(biometorisRecordCout, jdbcTemplate
				.queryForObject("select count(BIOMETRICS_ID) from PERSON_BIOMETRICS_1", Integer.class).intValue());
	}

	@Test
	public void testDeleteTemplate_eventId_null_Delete_Count_zero() {
		PBContainerSyncRequest pbSyncRequet = null;
		SyncResultWithStatus syncResultWithStatus = null;
		Integer containerId = 1;
		String userKey = "test";

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		syncResultWithStatus = dao.deleteTemplate(containerId, userKey, null);
		pbSyncRequet = syncResultWithStatus.getpBContainerSyncRequest();
		PBServiceState errorState = syncResultWithStatus.getpBServiceState();
		Assert.assertNull(pbSyncRequet);
		Assert.assertNotNull(errorState);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, errorState.getState());
		Assert.assertEquals(ErrorDifinitions.DB_DELETE_COUNT_ZERO.getStringCode(), errorState.getReason().getCode());
		Assert.assertEquals(ErrorDifinitions.DB_DELETE_COUNT_ZERO.getDescriptionWithKey(containerId, userKey, null),
				errorState.getReason().getDescription());
	}

	@Test
	public void testDeleteTemplate_eventId_null_Delete_process_error_1() {
		PBContainerSyncRequest pbSyncRequet = null;
		SyncResultWithStatus syncResultWithStatus = null;
		String userKey = "test";

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");
		syncResultWithStatus = dao.deleteTemplate(-9999, userKey, null);
		pbSyncRequet = syncResultWithStatus.getpBContainerSyncRequest();
		PBServiceState errorState = syncResultWithStatus.getpBServiceState();
		Assert.assertNull(pbSyncRequet);
		Assert.assertNotNull(errorState);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, errorState.getState());
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getStringCode(), errorState.getReason().getCode());
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getDescriptionWithKey(-9999, userKey, null),
				errorState.getReason().getDescription());
	}

	@Test
	public void testDeleteTemplate_eventId_null_Delete_process_error_2() {
		PBContainerSyncRequest pbSyncRequet = null;
		SyncResultWithStatus syncResultWithStatus = null;
		Integer containerId = 1;
		String userKey = "test";

		AIMrManger.saveTopersonBiometricsTabMap(1, "");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "");

		syncResultWithStatus = dao.deleteTemplate(containerId, userKey, null);
		pbSyncRequet = syncResultWithStatus.getpBContainerSyncRequest();
		PBServiceState errorState = syncResultWithStatus.getpBServiceState();
		Assert.assertNull(pbSyncRequet);
		Assert.assertNotNull(errorState);
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, errorState.getState());
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getStringCode(), errorState.getReason().getCode());
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getDescriptionWithKey(containerId, userKey, null),
				errorState.getReason().getDescription());
	}

	@Test
	public void testDeleteTemplate_eventId_notNull_Delete_Count_zero() {
		PBContainerSyncRequest pbSyncRequet = null;
		SyncResultWithStatus syncResultWithStatus = null;
		Integer containerId = 1;
		String userKey = "test";
		Integer eventId = 1;

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");

		syncResultWithStatus = dao.deleteTemplate(containerId, userKey, eventId);
		PBServiceState errorState = syncResultWithStatus.getpBServiceState();
		Assert.assertNull(pbSyncRequet);
		Assert.assertNotNull(errorState);
		Assert.assertEquals(ErrorDifinitions.DB_DELETE_COUNT_ZERO.getStringCode(), errorState.getReason().getCode());
		Assert.assertEquals(ErrorDifinitions.DB_DELETE_COUNT_ZERO.getDescriptionWithKey(containerId, userKey, eventId),
				errorState.getReason().getDescription());
	}

	@Test
	public void testDeleteTemplate_eventId_notNull_Delete_process_error_1() {
		PBContainerSyncRequest pbSyncRequet = null;
		SyncResultWithStatus syncResultWithStatus = null;
		String userKey = "test";
		Integer eventId = 1;

		AIMrManger.saveTopersonBiometricsTabMap(1, "PERSON_BIOMETRICS_1");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "PERSON_BIO_CHANGE_LOG_1");

		syncResultWithStatus = dao.deleteTemplate(-9999, userKey, eventId);
		PBServiceState errorState = syncResultWithStatus.getpBServiceState();
		Assert.assertNull(pbSyncRequet);
		Assert.assertNotNull(errorState);
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getStringCode(), errorState.getReason().getCode());
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getDescriptionWithKey(-9999, userKey, eventId),
				errorState.getReason().getDescription());
	}

	@Test
	public void testDeleteTemplate_eventId_notNull_Delete_process_error_2() {
		PBContainerSyncRequest pbSyncRequet = null;
		SyncResultWithStatus syncResultWithStatus = null;
		Integer containerId = 1;
		String userKey = "test";
		Integer eventId = 1;
		AIMrManger.saveTopersonBiometricsTabMap(1, "");
		AIMrManger.saveTopersonBiometricsChangeLogTabMap(1, "");
		syncResultWithStatus = dao.deleteTemplate(containerId, userKey, eventId);
		PBServiceState errorState = syncResultWithStatus.getpBServiceState();
		Assert.assertNull(pbSyncRequet);
		Assert.assertNotNull(errorState);
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getStringCode(), errorState.getReason().getCode());
		Assert.assertEquals(ErrorDifinitions.DB_PROCESS_ERROR.getDescriptionWithKey(containerId, userKey, eventId),
				errorState.getReason().getDescription());
	}

	@Test
	public void testStringFormat() {
		String strQuery = "SELECT USER_KEY,USER_EVENT_ID,BIOMETRICS_DATA FROM %S WHERE USER_KEY=? ";
		String selSql = String.format(strQuery, "testTableName");
		System.out.println(selSql);
	}

	@Test
	public void testStringFormatWithNull() {
		String strQuery = "SELECT USER_KEY,USER_EVENT_ID,BIOMETRICS_DATA FROM %S WHERE USER_KEY=? ";
		String nullString = null;
		String selSql = String.format(strQuery, nullString);
		System.out.println(selSql);
	}

	@Test
	public void testStringReplace() {
		String strQuery = "SELECT USER_KEY,USER_EVENT_ID,BIOMETRICS_DATA FROM $TABLENAME WHERE USER_KEY=? ";
		String selSql = strQuery.replace("$TABLENAME", "testTableName");
		System.out.println(selSql);
	}

	@Test(expected = NullPointerException.class)
	public void testStringReplaceWithNull() {
		String strQuery = "SELECT USER_KEY,USER_EVENT_ID,BIOMETRICS_DATA FROM $TABLENAME WHERE USER_KEY=? ";
		String selSql = strQuery.replace("$TABLENAME", null);
		System.out.println(selSql);
	}

	private void recoverConatainerData() {
		String sql = "UPDATE CONTAINERS SET TEMPLATE_SIZE =15680 ,VERSION =0 ,RECORD_COUNT=0 WHERE CONTAINER_ID=1";
		jdbcTemplate.update(sql);
		jdbcTemplate.execute("COMMIT");
	}
}
