package jp.co.nec.aimr.common;


import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceStateReason;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractJobResult;
import jp.co.nec.aim.message.proto.InquiryService.PBIdentifyResponse;
import jp.co.nec.aim.message.proto.InquiryService.PBVerifyResponse;
import jp.co.nec.aimr.exception.AimRuntimeException;

public class ProtobufUtilTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void testGetCurrentTime() {
		String testDate = ProtobufUtil.getCurrentTime();
		System.out.println(testDate);
	}

	@Test
	public void testBuildFaildPBExtractJobResult_check_sum_error() {
		PBExtractJobResult result = ProtobufUtil.buildFaildPBExtractJobResult(ErrorDifinitions.EXTRACT_JOB_RESULT_CHECK_SUM_ERROR, null, null, null);
		PBServiceState state = result.getServiceState();
		ServiceStateType stateType = state.getState();
		PBServiceStateReason reason = state.getReason();		
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, stateType);
		Assert.assertEquals(ErrorDifinitions.EXTRACT_JOB_RESULT_CHECK_SUM_ERROR.getStringCode(), reason.getCode());	
		Assert.assertEquals(ErrorDifinitions.EXTRACT_JOB_RESULT_CHECK_SUM_ERROR.getDescriptionWithKey(null, null, null), reason.getDescription());	
	}
	
	@Test(expected = AimRuntimeException.class)
	public void testBuildFaildPBExtractJobResult_exception() {
		ProtobufUtil.buildFaildPBExtractJobResult(null, null, null, null);			
	}
	
	@Test
	public void testBuildRollbackPBExtractJobResult_empty() {
		PBExtractJobResult result = ProtobufUtil.buildRollbackPBExtractJobResult(ErrorDifinitions.EXTRACT_RESULT_EMPTY, null, null, null);
		PBServiceState state = result.getServiceState();
		ServiceStateType stateType = state.getState();
		PBServiceStateReason reason = state.getReason();		
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, stateType);
		Assert.assertEquals(ErrorDifinitions.EXTRACT_RESULT_EMPTY.getStringCode(), reason.getCode());
		Assert.assertEquals(ErrorDifinitions.EXTRACT_RESULT_EMPTY.getDescriptionWithKey(null, null, null), reason.getDescription());	
	}
	
	@Test
	public void testBuildRollbackPBExtractJobResult_request_send_faild() {
		PBExtractJobResult result = ProtobufUtil.buildRollbackPBExtractJobResult(ErrorDifinitions.EXTRACT_REQUST_SEND_FAILD, null, null, null);
		PBServiceState state = result.getServiceState();
		ServiceStateType stateType = state.getState();
		PBServiceStateReason reason = state.getReason();		
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, stateType);
		Assert.assertEquals(ErrorDifinitions.EXTRACT_REQUST_SEND_FAILD.getStringCode(), reason.getCode());	
		Assert.assertEquals(ErrorDifinitions.EXTRACT_REQUST_SEND_FAILD.getDescriptionWithKey(null, null, null), reason.getDescription());
	}
	
	@Test
	public void testBuildRollbackPBExtractJobResult_timeout() {
		PBExtractJobResult result = ProtobufUtil.buildRollbackPBExtractJobResult(ErrorDifinitions.EXTRACT_JOB_TIMEOUT, null, null, null);
		PBServiceState state = result.getServiceState();
		ServiceStateType stateType = state.getState();
		PBServiceStateReason reason = state.getReason();		
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, stateType);
		Assert.assertEquals(ErrorDifinitions.EXTRACT_JOB_TIMEOUT.getStringCode(), reason.getCode());
		Assert.assertEquals(ErrorDifinitions.EXTRACT_JOB_TIMEOUT.getDescriptionWithKey(null, null, null), reason.getDescription());
	}
	
	@Test
	public void testBuildRollbackPBExtractJobResult_receive_faild() {
		PBExtractJobResult result = ProtobufUtil.buildRollbackPBExtractJobResult(ErrorDifinitions.EXTRACT_JOB_RESULT_CHECK_SUM_ERROR, null, null, null);
		PBServiceState state = result.getServiceState();
		ServiceStateType stateType = state.getState();
		PBServiceStateReason reason = state.getReason();		
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, stateType);
		Assert.assertEquals(ErrorDifinitions.EXTRACT_JOB_RESULT_CHECK_SUM_ERROR.getStringCode(), reason.getCode());
		Assert.assertEquals(ErrorDifinitions.EXTRACT_JOB_RESULT_CHECK_SUM_ERROR.getDescriptionWithKey(null, null, null), reason.getDescription());
	}
	

	@Test
	public void testBuildRollbackPBExtractJobResult_no_activeMu() {
		PBExtractJobResult result = ProtobufUtil.buildRollbackPBExtractJobResult(ErrorDifinitions.EXTRACT_JOB_NO_ACTIVE_EU, null, null, null);
		PBServiceState state = result.getServiceState();
		ServiceStateType stateType = state.getState();
		PBServiceStateReason reason = state.getReason();		
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, stateType);
		Assert.assertEquals(ErrorDifinitions.EXTRACT_JOB_NO_ACTIVE_EU.getStringCode(), reason.getCode());
		Assert.assertEquals(ErrorDifinitions.EXTRACT_JOB_NO_ACTIVE_EU.getDescriptionWithKey(null, null, null), reason.getDescription());
	}
	
	@Test
	public void testBuildFaildPBExtractJobResult_CLINET_EMPTY_REQUEST_MSG() {
		PBExtractJobResult result = ProtobufUtil.buildFaildPBExtractJobResult(ErrorDifinitions.CLINET_EMPTY_REQUEST_MSG, null, null, null);
		PBServiceState state = result.getServiceState();
		ServiceStateType stateType = state.getState();
		PBServiceStateReason reason = state.getReason();		
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, stateType);
		Assert.assertEquals(ErrorDifinitions.CLINET_EMPTY_REQUEST_MSG.getStringCode(), reason.getCode());
		Assert.assertEquals(ErrorDifinitions.CLINET_EMPTY_REQUEST_MSG.getDescriptionWithKey(null, null, null), reason.getDescription());
	}
	
	@Test
	public void testBuildFaildPBExtractJobResult_CLINET_NOT_SUPPORT_METHOD() {
		PBExtractJobResult result = ProtobufUtil.buildFaildPBExtractJobResult(ErrorDifinitions.CLINET_NOT_SUPPORT_METHOD, null, null, null);
		PBServiceState state = result.getServiceState();
		ServiceStateType stateType = state.getState();
		PBServiceStateReason reason = state.getReason();		
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, stateType);
		Assert.assertEquals(ErrorDifinitions.CLINET_NOT_SUPPORT_METHOD.getStringCode(), reason.getCode());
		Assert.assertEquals(ErrorDifinitions.CLINET_NOT_SUPPORT_METHOD.getDescriptionWithKey(null, null, null), reason.getDescription());
	}

	@Test
	public void testBuildFaildPBIdentifyResponse_CLINET_EMPTY_REQUEST_MSG() {
		PBIdentifyResponse result = ProtobufUtil.buildFaildPBIdentifyResponse(ErrorDifinitions.CLINET_EMPTY_REQUEST_MSG, null, null, null);
		PBServiceState state = result.getServiceState();
		ServiceStateType stateType = state.getState();
		PBServiceStateReason reason = state.getReason();		
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, stateType);
		Assert.assertEquals(ErrorDifinitions.CLINET_EMPTY_REQUEST_MSG.getStringCode(), reason.getCode());	
		Assert.assertEquals(ErrorDifinitions.CLINET_EMPTY_REQUEST_MSG.getDescriptionWithKey(null, null, null), reason.getDescription());		
	}
	
	@Test
	public void testBuildFaildPBIdentifyResponse_CLINET_NOT_SUPPORT_METHOD() {
		PBIdentifyResponse result = ProtobufUtil.buildFaildPBIdentifyResponse(ErrorDifinitions.CLINET_NOT_SUPPORT_METHOD, null, null, null);
		PBServiceState state = result.getServiceState();
		ServiceStateType stateType = state.getState();
		PBServiceStateReason reason = state.getReason();		
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, stateType);
		Assert.assertEquals(ErrorDifinitions.CLINET_NOT_SUPPORT_METHOD.getStringCode(), reason.getCode());	
		Assert.assertEquals(ErrorDifinitions.CLINET_NOT_SUPPORT_METHOD.getDescriptionWithKey(null, null, null), reason.getDescription());		
	}
	
	@Test(expected = AimRuntimeException.class)
	public void testBuildFaildPBIdentifyJobResult_exception() {
		ProtobufUtil.buildFaildPBExtractJobResult(null, null, null, null);			
	}
	
	@Test
	public void testBuildRollbackPBIdentifyResponse_REQUST_SEND_FAILD() {
		PBIdentifyResponse result = ProtobufUtil.buildRollbackPBIdentifyResponse(ErrorDifinitions.IDENTIFY_REQUST_SEND_FAILD, null, null, null);
		PBServiceState state = result.getServiceState();
		ServiceStateType stateType = state.getState();
		PBServiceStateReason reason = state.getReason();		
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, stateType);
		Assert.assertEquals(ErrorDifinitions.IDENTIFY_REQUST_SEND_FAILD.getStringCode(), reason.getCode());	
		Assert.assertEquals(ErrorDifinitions.IDENTIFY_REQUST_SEND_FAILD.getDescriptionWithKey(null, null, null), reason.getDescription());		
	}
	
	@Test
	public void testBuildRollbackPBIdentifyResponse_PROCESS_FAILD() {
		PBIdentifyResponse result = ProtobufUtil.buildRollbackPBIdentifyResponse(ErrorDifinitions.IDENTIFY_PROCESS_FAILD, null, null, null);
		PBServiceState state = result.getServiceState();
		ServiceStateType stateType = state.getState();
		PBServiceStateReason reason = state.getReason();		
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, stateType);
		Assert.assertEquals(ErrorDifinitions.IDENTIFY_PROCESS_FAILD.getStringCode(), reason.getCode());	
		Assert.assertEquals(ErrorDifinitions.IDENTIFY_PROCESS_FAILD.getDescriptionWithKey(null, null, null), reason.getDescription());		
	}
	
	@Test
	public void testBuildRollbackPBIdentifyResponse_IDENTIFY_JOB_TIMEOUT() {
		PBIdentifyResponse result = ProtobufUtil.buildRollbackPBIdentifyResponse(ErrorDifinitions.IDENTIFY_JOB_TIMEOUT, null, null, null);
		PBServiceState state = result.getServiceState();
		ServiceStateType stateType = state.getState();
		PBServiceStateReason reason = state.getReason();		
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, stateType);
		Assert.assertEquals(ErrorDifinitions.IDENTIFY_JOB_TIMEOUT.getStringCode(), reason.getCode());	
		Assert.assertEquals(ErrorDifinitions.IDENTIFY_JOB_TIMEOUT.getDescriptionWithKey(null, null, null), reason.getDescription());		
	}
	
	@Test
	public void testBuildRollbackPBIdentifyResponse_RESULT_EMPTY_RECEIVE_FAILD() {
		PBIdentifyResponse result = ProtobufUtil.buildRollbackPBIdentifyResponse(ErrorDifinitions.IDENTIFY_RESULT_RECEIVE_FAILD, null, null, null);
		PBServiceState state = result.getServiceState();
		ServiceStateType stateType = state.getState();
		PBServiceStateReason reason = state.getReason();		
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, stateType);
		Assert.assertEquals(ErrorDifinitions.IDENTIFY_RESULT_RECEIVE_FAILD.getStringCode(), reason.getCode());	
		Assert.assertEquals(ErrorDifinitions.IDENTIFY_RESULT_RECEIVE_FAILD.getDescriptionWithKey(null, null, null), reason.getDescription());		
	}
	
	@Test
	public void testBuildRollbackPBIdentifyResponse_no_active_mu() {
		PBIdentifyResponse result = ProtobufUtil.buildRollbackPBIdentifyResponse(ErrorDifinitions.IDENTIFY_JOB_NO_ACTIVE_MU, null, null, null);
		PBServiceState state = result.getServiceState();
		ServiceStateType stateType = state.getState();
		PBServiceStateReason reason = state.getReason();		
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, stateType);
		Assert.assertEquals(ErrorDifinitions.IDENTIFY_JOB_NO_ACTIVE_MU.getStringCode(), reason.getCode());	
		Assert.assertEquals(ErrorDifinitions.IDENTIFY_JOB_NO_ACTIVE_MU.getDescriptionWithKey(null, null, null), reason.getDescription());		
	}
	
	@Test
	public void testBuildRollbackPBIdentifyResponse_RESULT_check_sum_error() {
		PBIdentifyResponse result = ProtobufUtil.buildRollbackPBIdentifyResponse(ErrorDifinitions.IDENTIFY_JOB_RESULT_CHECK_SUM_ERROR, null, null, null);
		PBServiceState state = result.getServiceState();
		ServiceStateType stateType = state.getState();
		PBServiceStateReason reason = state.getReason();		
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, stateType);
		Assert.assertEquals(ErrorDifinitions.IDENTIFY_JOB_RESULT_CHECK_SUM_ERROR.getStringCode(), reason.getCode());	
		Assert.assertEquals(ErrorDifinitions.IDENTIFY_JOB_RESULT_CHECK_SUM_ERROR.getDescriptionWithKey(null, null, null), reason.getDescription());		
	}	

	@Test
	public void testBuildPBIdentifyResponseWithState() {
		PBServiceState.Builder state = PBServiceState.newBuilder();
		state.setState(ServiceStateType.SERVICE_STATE_ERROR);		
		 PBIdentifyResponse result = ProtobufUtil.buildPBIdentifyResponseWithState(state.build());		
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, result.getServiceState().getState());		
	}
	
	@Test(expected = AimRuntimeException.class)
	public void testBuildPBIdentifyResponseWithState_exception() {
		ProtobufUtil.buildPBIdentifyResponseWithState(null);			
	}	

	@Test
	public void testBuildFaildPBServiceState() {			
		 PBServiceState state = ProtobufUtil.buildFaildPBServiceState(ErrorDifinitions.CLINET_EMPTY_REQUEST_MSG, null, null, null);				
			ServiceStateType stateType = state.getState();
			PBServiceStateReason reason = state.getReason();
			Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, stateType);
			Assert.assertEquals(ErrorDifinitions.CLINET_EMPTY_REQUEST_MSG.getStringCode(), reason.getCode());	
			Assert.assertEquals(ErrorDifinitions.CLINET_EMPTY_REQUEST_MSG.getDescription(), reason.getDescription());
	}

	@Test
	public void testBuildRollbackPBServiceState() {
		 PBServiceState state = ProtobufUtil.buildRollbackPBServiceState(ErrorDifinitions.EXTRACT_JOB_NO_ACTIVE_EU, null, null, null);				
			ServiceStateType stateType = state.getState();
			PBServiceStateReason reason = state.getReason();
			Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, stateType);
			Assert.assertEquals(ErrorDifinitions.EXTRACT_JOB_NO_ACTIVE_EU.getStringCode(), reason.getCode());	
			Assert.assertEquals(ErrorDifinitions.EXTRACT_JOB_NO_ACTIVE_EU.getStringCode(), reason.getCode());		
	}
	
	@Test(expected = AimRuntimeException.class)
	public void testBuildService_status_exception() {
		ProtobufUtil.buildFaildPBServiceState(null, null, null, null);			
	}	

	@Test
	public void testBuildFaildPBVerifyResponse_CLINET_EMPTY_REQUEST_MSG() {
		PBVerifyResponse result = ProtobufUtil.buildFaildPBVerifyResponse(ErrorDifinitions.CLINET_EMPTY_REQUEST_MSG, null, null, null);
		PBServiceState state = result.getServiceState();
		ServiceStateType stateType = state.getState();
		PBServiceStateReason reason = state.getReason();		
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, stateType);
		Assert.assertEquals(ErrorDifinitions.CLINET_EMPTY_REQUEST_MSG.getStringCode(), reason.getCode());	
		Assert.assertEquals(ErrorDifinitions.CLINET_EMPTY_REQUEST_MSG.getDescriptionWithKey(null, null, null), reason.getDescription());
	}
	
	@Test
	public void testBuildFaildPBVerifyResponse_CLINET_NOT_SUPPORT_METHOD() {
		PBVerifyResponse result = ProtobufUtil.buildFaildPBVerifyResponse(ErrorDifinitions.CLINET_NOT_SUPPORT_METHOD, null, null, null);
		PBServiceState state = result.getServiceState();
		ServiceStateType stateType = state.getState();
		PBServiceStateReason reason = state.getReason();		
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ERROR, stateType);
		Assert.assertEquals(ErrorDifinitions.CLINET_NOT_SUPPORT_METHOD.getStringCode(), reason.getCode());	
		Assert.assertEquals(ErrorDifinitions.CLINET_NOT_SUPPORT_METHOD.getDescriptionWithKey(null, null, null), reason.getDescription());
	}
	
	@Test(expected = AimRuntimeException.class)
	public void testBuildFaildPBVerifyResponse_exception() {
		ProtobufUtil.buildRollbackPBVerifyResponse(null, null, null, null);
		
	}

	@Test
	public void testBuildRollbackPBVerifyResponse_RESULT_EMPTY() {
		PBVerifyResponse result = ProtobufUtil.buildRollbackPBVerifyResponse(ErrorDifinitions.VERIFY_RESULT_EMPTY, null, null, null);
		PBServiceState state = result.getServiceState();
		ServiceStateType stateType = state.getState();
		PBServiceStateReason reason = state.getReason();		
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, stateType);
		Assert.assertEquals(ErrorDifinitions.VERIFY_RESULT_EMPTY.getStringCode(), reason.getCode());	
		Assert.assertEquals(ErrorDifinitions.VERIFY_RESULT_EMPTY.getDescriptionWithKey(null, null, null), reason.getDescription());
	}
	
	@Test
	public void testBuildRollbackPBVerifyResponse_RESULT_REQUST_SEND_FAILD() {
		PBVerifyResponse result = ProtobufUtil.buildRollbackPBVerifyResponse(ErrorDifinitions.VERIFY_REQUST_SEND_FAILD, null, null, null);
		PBServiceState state = result.getServiceState();
		ServiceStateType stateType = state.getState();
		PBServiceStateReason reason = state.getReason();		
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, stateType);
		Assert.assertEquals(ErrorDifinitions.VERIFY_REQUST_SEND_FAILD.getStringCode(), reason.getCode());	
		Assert.assertEquals(ErrorDifinitions.VERIFY_REQUST_SEND_FAILD.getDescriptionWithKey(null, null, null), reason.getDescription());
	}
	
	@Test
	public void testBuildRollbackPBVerifyResponse_PROCESS_FAILD() {
		PBVerifyResponse result = ProtobufUtil.buildRollbackPBVerifyResponse(ErrorDifinitions.VERIFY_PROCESS_FAILD, null, null, null);
		PBServiceState state = result.getServiceState();
		ServiceStateType stateType = state.getState();
		PBServiceStateReason reason = state.getReason();		
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, stateType);
		Assert.assertEquals(ErrorDifinitions.VERIFY_PROCESS_FAILD.getStringCode(), reason.getCode());	
		Assert.assertEquals(ErrorDifinitions.VERIFY_PROCESS_FAILD.getDescriptionWithKey(null, null, null), reason.getDescription());
	}
	
	@Test
	public void testBuildRollbackPBVerifyResponse_JOB_TIMEOUT() {
		PBVerifyResponse result = ProtobufUtil.buildRollbackPBVerifyResponse(ErrorDifinitions.VERIFY_JOB_TIMEOUT, null, null, null);
		PBServiceState state = result.getServiceState();
		ServiceStateType stateType = state.getState();
		PBServiceStateReason reason = state.getReason();		
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, stateType);
		Assert.assertEquals(ErrorDifinitions.VERIFY_JOB_TIMEOUT.getStringCode(), reason.getCode());	
		Assert.assertEquals(ErrorDifinitions.VERIFY_JOB_TIMEOUT.getDescriptionWithKey(null, null, null), reason.getDescription());
	}
	
	@Test
	public void testBuildRollbackPBVerifyResponse_RESULT_RESULT_RECEIVE_FAILD() {
		PBVerifyResponse result = ProtobufUtil.buildRollbackPBVerifyResponse(ErrorDifinitions.VERIFY_RESULT_RECEIVE_FAILD, null, null, null);
		PBServiceState state = result.getServiceState();
		ServiceStateType stateType = state.getState();
		PBServiceStateReason reason = state.getReason();		
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, stateType);
		Assert.assertEquals(ErrorDifinitions.VERIFY_RESULT_RECEIVE_FAILD.getStringCode(), reason.getCode());	
		Assert.assertEquals(ErrorDifinitions.VERIFY_RESULT_RECEIVE_FAILD.getDescriptionWithKey(null, null, null), reason.getDescription());
	}
	
	@Test
	public void testBuildRollbackPBVerifyResponse_NO_ACTIVE_EU() {
		PBVerifyResponse result = ProtobufUtil.buildRollbackPBVerifyResponse(ErrorDifinitions.VERIFY_JOB_NO_ACTIVE_EU, null, null, null);
		PBServiceState state = result.getServiceState();
		ServiceStateType stateType = state.getState();
		PBServiceStateReason reason = state.getReason();		
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, stateType);
		Assert.assertEquals(ErrorDifinitions.VERIFY_JOB_NO_ACTIVE_EU.getStringCode(), reason.getCode());	
		Assert.assertEquals(ErrorDifinitions.VERIFY_JOB_NO_ACTIVE_EU.getDescriptionWithKey(null, null, null), reason.getDescription());
	}
	
	@Test
	public void testBuildRollbackPBVerifyResponse_JOB_RESULT_CHECK_SUM_ERROR() {
		PBVerifyResponse result = ProtobufUtil.buildRollbackPBVerifyResponse(ErrorDifinitions.VERIFY_JOB_RESULT_CHECK_SUM_ERROR, null, null, null);
		PBServiceState state = result.getServiceState();
		ServiceStateType stateType = state.getState();
		PBServiceStateReason reason = state.getReason();		
		Assert.assertEquals(ServiceStateType.SERVICE_STATE_ROLLBACK, stateType);
		Assert.assertEquals(ErrorDifinitions.VERIFY_JOB_RESULT_CHECK_SUM_ERROR.getStringCode(), reason.getCode());	
		Assert.assertEquals(ErrorDifinitions.VERIFY_JOB_RESULT_CHECK_SUM_ERROR.getDescriptionWithKey(null, null, null), reason.getDescription());
	}

}
