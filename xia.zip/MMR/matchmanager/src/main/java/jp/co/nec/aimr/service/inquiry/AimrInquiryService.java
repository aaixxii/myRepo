package jp.co.nec.aimr.service.inquiry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.ByteString;

import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractJobResult;
import jp.co.nec.aim.message.proto.InquiryService.PBIdentifyRequest;
import jp.co.nec.aim.message.proto.InquiryService.PBIdentifyResponse;
import jp.co.nec.aim.message.proto.InquiryService.PBInquiryJobRequest;
import jp.co.nec.aimr.common.ErrorDifinitions;
import jp.co.nec.aimr.common.JobState;
import jp.co.nec.aimr.common.PostCardType;
import jp.co.nec.aimr.common.ProtobufUtil;
import jp.co.nec.aimr.common.SequenceIdCreator;
import jp.co.nec.aimr.common.SequenceIdType;
import jp.co.nec.aimr.common.StopWatch;
import jp.co.nec.aimr.event.EventNotifier;
import jp.co.nec.aimr.exception.NoActiveUnitException;
import jp.co.nec.aimr.exception.PropertyFileException;
import jp.co.nec.aimr.logging.PerformanceLogger;
import jp.co.nec.aimr.management.MMrJobManager;
import jp.co.nec.aimr.properties.PropertyNames;
import jp.co.nec.aimr.properties.PropertyUtil;
import jp.co.nec.aimr.service.extract.ExtractService;

/**
 * @author xiazp <br/>
 * AimrInquiryService hander inquiry job request from <br/>
 * client and response to client <br/>
 */
public class AimrInquiryService {
	private PBIdentifyRequest pBIdentifyRequest;
	private int inquiryJobWaitTime;

	private static Logger logger = LoggerFactory.getLogger(AimrInquiryService.class);

	public AimrInquiryService(PBIdentifyRequest pBIdentifyRequest) {
		this.pBIdentifyRequest = pBIdentifyRequest;
	}

	/**
	 * @return
	 */
	public PBIdentifyResponse processIdentifyRequest() {
		StopWatch t = new StopWatch();		
		t.start();
		logger.info("Start to proccess client identify requist...");
		long startProccessTime = System.currentTimeMillis();
		PBInquiryJobRequest inquiryJobRequest = pBIdentifyRequest.getInquiryJobRequest();
		PBIdentifyResponse pBIdentifyResponse = null;
		inquiryJobWaitTime = PropertyUtil.getInstance().getPropertyIntValue(PropertyNames.MMR_GET_INQUIRY_JOB_RESULTS_WAITTIME_LIMIT.name());		
		boolean isHaveExtractjob = pBIdentifyRequest.hasExtractInputPayload();
		boolean isHaveTemplate = pBIdentifyRequest.getInquiryJobRequest().hasTemplate();
		if (!isHaveExtractjob && !isHaveTemplate) {
			String errMsg = "There are no template and no ExtractInputPayload. one of them is required!";
			logger.error(errMsg);
			pBIdentifyResponse = ProtobufUtil.buildFaildPBIdentifyResponse(ErrorDifinitions.IDENTIFY_REQUEST_NO_EXTACTPAYLOAD_NO_TEMPLATE, null, null, null);
			return pBIdentifyResponse;
			
		}

		if (isHaveExtractjob) {
			PBExtractJobResult extractJobResult = doExtract();
			if (extractJobResult != null && extractJobResult.getServiceState().getState().name().equals(ServiceStateType.SERVICE_STATE_SUCCESS.name())) {
				byte[] byteResult = extractJobResult.getTemplate().toByteArray();
				PBInquiryJobRequest.Builder pBInquiryJobRequest = PBInquiryJobRequest.newBuilder();
				pBInquiryJobRequest.mergeFrom(inquiryJobRequest);
				pBInquiryJobRequest.setTemplate(ByteString.copyFrom(byteResult));
				pBIdentifyResponse = doIquiry(pBInquiryJobRequest.build());
			} else {	
				 PBServiceState sericebState = extractJobResult.getServiceState();	
				 pBIdentifyResponse = ProtobufUtil.buildPBIdentifyResponseWithState(sericebState);
			}
		} else if (isHaveTemplate) {
			pBIdentifyResponse = doIquiry(inquiryJobRequest);
		}
		
		if (pBIdentifyResponse == null) {
			pBIdentifyResponse = ProtobufUtil.buildRollbackPBIdentifyResponse(ErrorDifinitions.IDENTIFY_PROCESS_FAILD, null, null, null); 
		}
		long endProccessTime = System.currentTimeMillis();
		logger.info("proccess client requist used time {}", endProccessTime - startProccessTime);
		t.stop();
		PerformanceLogger.trace(getClass().getSimpleName(), "processIdentifyRequest", null, null, t.elapsedTime());
		t = null;
		return pBIdentifyResponse;
	}

	private PBIdentifyResponse doIquiry(PBInquiryJobRequest inquiryJobRequest) {
		logger.debug("Start to proccess inquiry job...");
		StopWatch t = new StopWatch();
		t.start();
		long startSaveInqJobQueueTime = System.currentTimeMillis();
		Object inquiryJobResultlocker = new Object();		
		Long inquryJobId = Long.valueOf(SequenceIdCreator.createNextSequence(SequenceIdType.INQUIRY_ID));		
		InquiryJobStatus inquiryJobStatus = new InquiryJobStatus();
		inquiryJobStatus.setInqJobId(inquryJobId);
		inquiryJobStatus.setInqJobStatus(JobState.QUEUED);
		InquiryJob inquiryJob = new InquiryJob(inquryJobId, inquiryJobRequest.toByteArray());
		int reqContainerId = inquiryJobRequest.getJobInfo().getContainerId();
		MMrJobManager.saveInquiryJobLocker(inquryJobId, inquiryJobResultlocker);		
		MMrJobManager.saveInqjobstatus(inquryJobId, inquiryJobStatus);
		MMrJobManager.saveInquiryjob( inquryJobId, inquiryJob);		
		long endSaveJobQueueTime = System.currentTimeMillis();
		logger.info("*****MMr save to job queue used time = {}****", endSaveJobQueueTime - startSaveInqJobQueueTime);	
		PBIdentifyResponse toBeGetResult = null;
		try {
			EventNotifier.getInstance().fireOnIdentifyJobqueueing(reqContainerId, inquryJobId);
		} catch (Exception e) {
			MMrJobManager.finishIdentifyJob(inquryJobId);
			logger.error(e.getMessage(), e);
			if (e instanceof NoActiveUnitException) {				
				toBeGetResult = ProtobufUtil.buildRollbackPBIdentifyResponse(ErrorDifinitions.IDENTIFY_JOB_NO_ACTIVE_MU, null, null, null);
				return toBeGetResult;
			} else if (e instanceof PropertyFileException) {
				toBeGetResult = ProtobufUtil.buildRollbackPBIdentifyResponse(ErrorDifinitions.PROPERTY_FILE_READ_FAILD, null, null, null);
				return toBeGetResult;
			} else {
				toBeGetResult = ProtobufUtil.buildRollbackPBIdentifyResponse(ErrorDifinitions.AIM_PROCESS_UNKNOWN, null, null, null);
			}			
			return toBeGetResult;				
		}
		
		synchronized (inquiryJobResultlocker) {
			long startGetResultTime = System.currentTimeMillis();
			logger.info("Go to waiting  job results!");
			try {
				inquiryJobResultlocker.wait(inquiryJobWaitTime);
			} catch (InterruptedException e) {
				logger.error(e.getMessage(), e);
				Thread.currentThread().interrupt();
			}
			logger.info("Finished wait job results!");
			toBeGetResult = MMrJobManager.getOneInqJobResult(inquryJobId);
			if (toBeGetResult != null) {
				logger.info("Get job({}) result success", inquryJobId);
			} else {
				long currentTime = System.currentTimeMillis();
				if (currentTime -  startGetResultTime >= inquiryJobWaitTime) {
					logger.warn(
							"Timeout is happend! the waiting time = ({}), jobId({})",
							currentTime - startGetResultTime, inquryJobId);
					MMrJobManager.changeInquiryJobstatus(inquryJobId, JobState.TIMEOUT);
					toBeGetResult = ProtobufUtil.buildRollbackPBIdentifyResponse(ErrorDifinitions.IDENTIFY_JOB_TIMEOUT, null, null, null);
				} 
			}
			long endGetResultTime = System.currentTimeMillis();
			logger.info("*****MMr get job results used time = {}****",
					endGetResultTime - startGetResultTime);	
		}
		MMrJobManager.finishIdentifyJob(inquryJobId);		
		t.stop();
		PerformanceLogger.trace(getClass().getSimpleName(), "doIquiry", null, null, t.elapsedTime());
		return toBeGetResult;
	}

	private PBExtractJobResult doExtract() {
		ExtractService extractService = new ExtractService(pBIdentifyRequest.toByteArray(), PostCardType.identify);
		return extractService.doExtract();
	}
}
