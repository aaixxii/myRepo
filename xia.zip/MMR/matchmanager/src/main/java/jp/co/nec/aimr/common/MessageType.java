package jp.co.nec.aimr.common;

public enum MessageType {
	connect(0x010),//
	ready(0x020),//
	hold(0x200), //
	exit(0x100),//
	heartBeat(0x000);

	private int val;

	private MessageType(int val) {
		this.val = val;
	}

	public int getVal() {
		return val;
	}

}