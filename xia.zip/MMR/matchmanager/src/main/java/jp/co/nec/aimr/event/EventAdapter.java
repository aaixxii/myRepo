package jp.co.nec.aimr.event;

import java.io.IOException;

import jp.co.nec.aim.message.proto.AIMMessages.PBContainerSyncRequest;

/**
 * @author xiazp <br/>
 * The interface of EventListener
 */
public class EventAdapter implements EventListener {

	@Override
	public void onError(String error) {
	}

	@Override
	public void onIdentifyJobqueueing(Long batchJobId) {
	}

	@Override
	public void onStop() throws IOException {
	}

	@Override
	public void onExtractJobqueueing(Long extractJobId) {
	}

	@Override
	public void onVerifyJobqueueing(Long verifyJobId) {
	}

	@Override
	public void onSyncTemplates(Long syncJobId, PBContainerSyncRequest syncRequust) {		
	}
}