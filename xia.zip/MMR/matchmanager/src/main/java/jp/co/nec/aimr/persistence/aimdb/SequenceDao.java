package jp.co.nec.aimr.persistence.aimdb;

import org.springframework.dao.DataAccessException;

/**
 * 
 * @author xiazp
 * SequenceDao used to get sequence id for database
 */
public interface SequenceDao {	
	public long getNextUnitId();
	public long getNextChangeLogId();
	public long getNextBiometricsId();
	public long getNextChangeLogVersion(String tableName) throws DataAccessException;	
	public void updateChangeLogId(long changeLogId) ;
	public void commit();
	public void rollback();
}
