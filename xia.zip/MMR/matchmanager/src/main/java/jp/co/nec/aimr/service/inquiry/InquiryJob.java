package jp.co.nec.aimr.service.inquiry;

public class InquiryJob {
	private long jobId;
	// private PBInquiryJobRequest pBInquiryJobRequest;
	private byte[] pBInquiryJobRequest;

	public long getJobId() {
		return jobId;
	}

	public InquiryJob(long jobId, byte[] inquiryRequist) {
		this.jobId = jobId;
		this.pBInquiryJobRequest = inquiryRequist;

	}

	public byte[] getpBInquiryJobRequest() {
		return pBInquiryJobRequest;
	}

	public void setpBInquiryJobRequest(byte[] pBInquiryJobRequest) {
		this.pBInquiryJobRequest = pBInquiryJobRequest;
	}

	public void setJobId(long jobId) {
		this.jobId = jobId;
	}
}
