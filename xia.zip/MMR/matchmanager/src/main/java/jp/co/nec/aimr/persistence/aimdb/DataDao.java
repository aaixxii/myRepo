package jp.co.nec.aimr.persistence.aimdb;

import java.util.Date;

/**
 * 
 * @author xiazp
 * DB time util class used to get time form db
 *
 */
public interface DataDao {
	/**
	 * 
	 * @return
	 */
	public Date getDatabaseDate();
	/**
	 * 
	 * @return
	 */
	public String getStringCurrentTimeMS();

}
