package jp.co.nec.aimr.service.extract;

public class ExtractJob {
	private long exJobId;
	private byte[] extJobRequest;
	private byte[] postCard;

	public ExtractJob(long extractJobId, byte[] extJobRequest, byte[] postCard) {
		this.exJobId = extractJobId;
		this.extJobRequest = extJobRequest;
		this.postCard = postCard;
	}

	public long getExJobId() {
		return exJobId;
	}

	public void setExJobId(long exJobId) {
		this.exJobId = exJobId;
	}

	public byte[] getExtJobRequest() {
		return extJobRequest;
	}

	public void setExtJobRequest(byte[] extJobRequest) {
		this.extJobRequest = extJobRequest;
	}

	public byte[] getPostCard() {
		return postCard;
	}

	public void setPostCard(byte[] postCard) {
		this.postCard = postCard;
	}

}
