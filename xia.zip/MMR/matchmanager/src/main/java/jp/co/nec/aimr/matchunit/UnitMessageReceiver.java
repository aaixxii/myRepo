package jp.co.nec.aimr.matchunit;

import static jp.co.nec.aimr.common.Constants.BUF_HEAD_SIZE;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

import com.google.protobuf.InvalidProtocolBufferException;

import jp.co.nec.aim.message.proto.AIMEnumTypes.ComponentType;
import jp.co.nec.aim.message.proto.AIMMessages.PBComponentInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBConnectResponse;
import jp.co.nec.aim.message.proto.AIMMessages.PBContainerInfo;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractJobResult;
import jp.co.nec.aim.message.proto.InquiryService.PBIdentifyResponse;
import jp.co.nec.aim.message.proto.InquiryService.PBVerifyResponse;
import jp.co.nec.aimr.common.ErrorDifinitions;
import jp.co.nec.aimr.common.JobState;
import jp.co.nec.aimr.common.MessageType;
import jp.co.nec.aimr.common.ProtobufUtil;
import jp.co.nec.aimr.common.SocketMessageUtil;
import jp.co.nec.aimr.common.StopWatch;
import jp.co.nec.aimr.common.UnitCard;
import jp.co.nec.aimr.common.UnitStatus;
import jp.co.nec.aimr.common.UnitType;
import jp.co.nec.aimr.event.EventAdapter;
import jp.co.nec.aimr.event.EventNotifier;
import jp.co.nec.aimr.exception.AimRuntimeException;
import jp.co.nec.aimr.logging.PerformanceLogger;
import jp.co.nec.aimr.management.AIMrManger;
import jp.co.nec.aimr.management.MMrJobManager;
import jp.co.nec.aimr.persistence.aimdb.AimUnits;
import jp.co.nec.aimr.persistence.aimdb.AimUnitsDao;
import jp.co.nec.aimr.persistence.aimdb.AimUnitsDaoImp;
import jp.co.nec.aimr.persistence.aimdb.ContainerInfo;
import jp.co.nec.aimr.persistence.aimdb.ContainersDao;
import jp.co.nec.aimr.persistence.aimdb.ContainersDaoImp;
import jp.co.nec.aimr.persistence.aimdb.DataBaseUtil;
import jp.co.nec.aimr.persistence.aimdb.MuUsedContainerDao;
import jp.co.nec.aimr.persistence.aimdb.MuUsedContainerDaoImp;
import jp.co.nec.aimr.persistence.aimdb.SequenceDao;
import jp.co.nec.aimr.persistence.aimdb.SequenceDaoImp;

/**
 * @author xiazp <br/>
 *         MatcherMsgReceiver receive message from unit at the keep alive <br/>
 *         connected channel <br/>
 */
public class UnitMessageReceiver extends EventAdapter implements Runnable {
	private Selector selector;
	private UnitCard unitCard;
	private Long unitId;
	private SocketChannel channel;
	private UnitMessageSender unitMessageSender;
	private Object channelLocker;

	public UnitMessageReceiver(SocketChannel channel) {
		this.channel = channel;
		this.unitMessageSender = null;
		this.channelLocker = new Object();
		this.unitId = -1L;
	}

	public UnitMessageSender getUnitMessageSenderInstance() {
		return unitMessageSender;
	}

	private static Logger logger = LoggerFactory.getLogger(UnitMessageReceiver.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Runnable#run() Thread run is process of receive message
	 * coming in this channel.
	 */
	@Override
	public void run() {
		try {
			selector = Selector.open();
			channel.register(selector, SelectionKey.OP_READ);
		} catch (IOException e) {
			String errmsg = "Can't starting UnitMessageReceiver socket server!";
			throw new AimRuntimeException(errmsg, e);
		}
		String uniqieKey = channel.socket().getInetAddress().getHostAddress() + ":" + String.valueOf(channel.socket().getPort());
		logger.info("Unit Receiver from {} is starting...", uniqieKey);
		int ringTimer = 2000;
		int conversationTimer = 1000;	
		ByteBuffer headBuff = ByteBuffer.allocate(BUF_HEAD_SIZE);
		for (;;) {			
			headBuff.order(ByteOrder.BIG_ENDIAN);
			int readHeadReturnVal = -9999;
			StopWatch t = new StopWatch();			
			t.start();
			readHeadReturnVal = receiveData(headBuff, ringTimer, conversationTimer);
			t.stop();
			logger.debug("****Get message head used time = {} ****", t.elapsedTime());
			t = null;
			if (readHeadReturnVal != 0) {	
				if (readHeadReturnVal < -4) {
					logger.warn("Unit({}) chanel has been killed! off line this unit...",  uniqieKey);
					removeUnitListener();
					exitUnitOnDB();					
					break;
				}
				logger.debug("UnitReceiver({}) recieved Head is not correct!,skip by code={}", uniqieKey, readHeadReturnVal);
				continue;
			}
			// read head data from headbuff
			headBuff.flip();
			Long msgId = headBuff.getLong();
			int bodyLegth = headBuff.getInt();			
			int checkSum = headBuff.getInt();
			long clientMuId = headBuff.getLong();
			Long jobId = Long.valueOf(headBuff.getLong());
			byte[] postCardByte = new byte[16];
			headBuff.get(postCardByte);
			String postCardString = SocketMessageUtil.convertNullToSpace(new String(postCardByte));			
			logger.debug("postCardString = {}", postCardString);
			logger.info("Received messageID:{}, unitId:{}, jobId:{} form {}", msgId, clientMuId, jobId, uniqieKey);
			Long responId = parseMessageID(msgId);
			if (responId != null && responId.longValue() == 17l) { // this is enter=connect	
				doEnter(bodyLegth, responId, uniqieKey, conversationTimer);				
			} else if (responId != null && responId.longValue() == 513l && bodyLegth > 0) { // it's identifyJobResults																							 
				try {
					proccessInquiryJobResults(jobId, bodyLegth, checkSum, responId, conversationTimer);
				} catch (Exception e) {
					makeRollbackIdentifyJobResults(jobId);
					logger.error("Get inquiry job({}) results from mu({}) is faild!", jobId, this.unitId, e);	
				}
			} else if (responId != null && responId.longValue() == 257l && bodyLegth > 0) { // it's extractJobResult																							 
				try {
					proccessExtractJobResults(jobId, bodyLegth, checkSum,  responId, conversationTimer);
				} catch (Exception e) {
					makeRollbackExtractJobResults(jobId);
					logger.error("Get extract job({}) results from eu({}) is faild!", jobId, this.unitId, e);					
				}
			} else if (responId != null && responId.longValue() == 1025l && bodyLegth > 0) { // it's verifyJobResult																								 
				try {
					proccessVerifyJobResults(jobId, bodyLegth, checkSum, responId, conversationTimer);
				} catch (Exception e) {
					 makeRollbackVerifyJobResults(jobId);
					logger.error("Get verify job({}) results from eu({}) is faild!", jobId, this.unitId, e);
				}
			}
			headBuff.clear();			
		}		
	}

	/**
	 * @param recivedId
	 * @return
	 */
	private Long parseMessageID(Long recivedId) {
		Long resposeId = null;
		if (recivedId.longValue() == 16l) { // mu enter=connect
			resposeId = 17L;
		} else if (recivedId.longValue() == 32l) { // mu job ready(job accepteable)
													
			proccssUnitMessage(MessageType.ready);
		} else if (recivedId.longValue() == 64l) { // mu busy= hold
			proccssUnitMessage(MessageType.hold);
		} else if (recivedId.longValue() == 128l) { // mu stop
			proccssUnitMessage(MessageType.exit);
		} else if (recivedId.longValue() == 513l) { // inquriyJobResult
			resposeId = 513l;
		} else if (recivedId.longValue() == 257l) { // extractJobResult
			resposeId = 257l;
		} else if (recivedId.longValue() == 1025l) { // verifyResult
			resposeId = 1025l;
		}
		return resposeId;
	}

	/**
	 * @param toBeReadBuff
	 * @param ringtimer
	 * @param conversationtimer
	 * @return
	 */
	public int receiveData(ByteBuffer toBeReadBuff, int ringtimer, int conversationtimer) {
		int selected = 0;
		SocketChannel currentChannel;
		long timer = ringtimer * 1000;
		for (int i = 0;; i++) {
			if (i != 0)
				timer = conversationtimer * 1000;
			try {
				selected = selector.select(timer);
			} catch (IOException e) {
				String msg = "Exception happened in selectiong ";
				logger.error(msg, e.getMessage(), e);
				selected = -9;
			}
			switch (selected) {
			case 0:
				if (i == 0)
					return (-1);
				else
					return (-2);
			case -9:
				return (-9);
			case 1:
				break;
			default:
				logger.info("Un known case....");
				return (-9);
			}
			Set<SelectionKey> keys = selector.selectedKeys();
			Iterator<SelectionKey> keyIterator = keys.iterator();
			while (keyIterator.hasNext()) {
				SelectionKey key = (SelectionKey) keyIterator.next();
				keyIterator.remove();
				if (!key.isReadable()) {
					System.out.println("coding miss.");
					System.exit(-9);
				}
				currentChannel = (SocketChannel) key.channel();
				try {
					synchronized (channelLocker) {
						if (currentChannel.read(toBeReadBuff) < 0) {
							logger.debug(
									"Reading data from channel return minus value! it means this channel may be closed");
							return (-5);
						}
					}
				} catch (IOException ex) {
					removeUnitListener();
					exitUnitOnDB();
					String errMsg = "Exception happend while read data from this channel({}),MMr will offline this unit({})";
					logger.error(errMsg, channel.socket().getInetAddress(), this.unitCard.getUniqueKey());
					return (-5); 
				}
				if (toBeReadBuff.remaining() == 0) {
					return (0);
				}
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.nec.aimr.event.EventAdapter#onStop()
	 */
	@Override
	public void onStop() throws IOException {
		if (channel != null || channel.isOpen()) {
			channel.close();
		}
		if (selector != null || selector.isOpen()) {
			selector.close();
		}
	}
	
	/**	
	 *  
	 * @param bodyLegth
	 * @param responId
	 * @param uniqKey
	 * @param conversationTimer
	 */
	private void doEnter(int bodyLegth, Long responId, String uniqKey, int conversationTimer) {
		StopWatch t = new StopWatch();		
		t.start();
		logger.info("unitReceiver({}) Will go to receive enter body", uniqKey);
		ByteBuffer clientBodyBuff = ByteBuffer.allocate(bodyLegth);
		clientBodyBuff.order(ByteOrder.BIG_ENDIAN);
		if (bodyLegth < 0) {
			logger.warn("unitRecever({}) received empty enter body! mmr will skip proccess...", uniqKey);
			return;
		}
		int readBodyReturnVal = -9999;
		readBodyReturnVal = receiveData(clientBodyBuff, 30, conversationTimer);
		logger.debug("The result of read enter body *PROCESS* is {}", readBodyReturnVal);	
		if (readBodyReturnVal < -4) {
			logger.warn("unit({}) may be no active!", uniqKey);
			return;
		}
		clientBodyBuff.flip();
		byte[] clietyBody = new byte[bodyLegth];
		clientBodyBuff.get(clietyBody);
		PBComponentInfo enterInfo = null;
		try {
			enterInfo = PBComponentInfo.parseFrom(clietyBody);
		} catch (InvalidProtocolBufferException e) {
			String protobufErrMsg = "Protocolbuffer deserialize happend. can't continue to  process!skip...";
			logger.error(protobufErrMsg, e);
			return;
		}
		this.unitCard = new UnitCard();
		unitCard.setUniqueKey(uniqKey);
		unitCard.setStatus(UnitStatus.connected);
		unitCard.setSocketChannel(channel);		
		ComponentType unitType = enterInfo.getComponent();
		if (unitType.name().equals(ComponentType.MATCH_UNIT.name())) {
			unitCard.setUnitType(UnitType.MATCHER);
		} else if (unitType.name().equals(ComponentType.EXTRACT_UNIT.name())) {
			unitCard.setUnitType(UnitType.EXTRACTOR);
		} else {
			logger.error("Incorrect unit type" + unitType.name() + "skip...");
			return;
		}
		logger.info("unitRecever({}) Received body(size={}) in unit enter", uniqKey, bodyLegth);
		List<ContainerInfo> unitConatainerInfo = null;
		unitConatainerInfo = updateDbForEnter(enterInfo);
		if (unitConatainerInfo != null) {
			try {
				buildAndSendPBConnectResponse(unitConatainerInfo, this.unitId, responId);
				logger.info("Success enterd unit({})", this.unitCard.getUnitId());
			} catch (IOException e) {
				logger.error(e.getMessage(), e);
				exitUnitOnDB();
			}
		} else {
			logger.warn("Got empty unitConatainerInfo from DB!! skip process...");
			return;
		}
		unitMessageSender = new UnitMessageSender(unitCard);
		EventNotifier.getInstance().addSystemListener(unitMessageSender);
		t.stop();
		logger.debug("****MMr proccess unit({}) enter  used time = {} ****", uniqKey, t.elapsedTime());
		PerformanceLogger.trace(getClass().getSimpleName(), "doEnter", unitCard.getUnitId(), null, t.elapsedTime());
		clientBodyBuff = null;
		t = null;
	}

	/** 
	 * 
	 * @param jobId
	 * @param bodyLegth
	 * @param checkSum
	 * @param responId
	 * @param conversationTimer
	 * @throws InvalidProtocolBufferException
	 */
	private void proccessInquiryJobResults(Long jobId, int bodyLegth, int checkSum, Long responId, int conversationTimer) throws InvalidProtocolBufferException {
		StopWatch t = new StopWatch();		
		t.start();
		logger.info("unitReceiver({}) Will go to receive inquiry job results body", this.unitId);
		if (bodyLegth != checkSum) {
			PBIdentifyResponse checkSumErrResult = ProtobufUtil.buildRollbackPBIdentifyResponse(ErrorDifinitions.IDENTIFY_JOB_RESULT_CHECK_SUM_ERROR, null, null, null);
			MMrJobManager.saveInquiryJobResult(jobId, checkSumErrResult);
			MMrJobManager.setInquiryJobStatus(jobId, JobState.FAILD);
			return;
		}
		if (!this.unitCard.getUnitType().name().equals(UnitType.MATCHER.name())) {
			String unitTypeError = "There are some wrong! this unit is not a matcher!";
			logger.error(unitTypeError);
			return;
		}
		ByteBuffer bodyBuff = ByteBuffer.allocate(bodyLegth);
		bodyBuff.order(ByteOrder.BIG_ENDIAN);
		int readBodyReturnVal = -9999;
		if (jobId <= 0) {
			logger.warn("JobId({}) is incorrected in muId({}). skip...", jobId, this.unitId);
		}
		readBodyReturnVal = receiveData(bodyBuff, 30, conversationTimer);
		if (readBodyReturnVal == -5) { // offline this unit
			String errMsg = "Unit(" + String.valueOf(this.unitId) + ") is no active!";
			if (!channel.isConnected()) {				
				throw new AimRuntimeException(errMsg);
			}
		}		
		logger.debug("Mu({}) reading inquiry job result of body *PROCESS* return value is {}", this.unitId, readBodyReturnVal);		
		if (readBodyReturnVal < -4) {
			String errMsg = "MU(" + String.valueOf(this.unitId) + ") may be no active!";
			logger.debug(errMsg);
			return;
		}
		byte[] pbBody = new byte[bodyLegth];
		bodyBuff.flip();
		bodyBuff.get(pbBody);
		logger.info("received job({}) result form mu{},body size={}", jobId, this.unitId, bodyLegth);	
		
		PBIdentifyResponse jobResult = PBIdentifyResponse.parseFrom(pbBody);		
		logger.info("muReceiver({}) will go to save inquiry job({}) results!", this.unitId, jobId);
		if (MMrJobManager.checkInqJobIsReulstedOrFinished(jobId)) {
			logger.error("The inquiry job({}) already has finished! MMr will skip save job results", jobId);
			return;
		}
		MMrJobManager.saveInquiryJobResult(jobId, jobResult);
		boolean isSaved = MMrJobManager.checkInqJobIsReulstedOrFinished(jobId);
		logger.info("MMr save mu({}) job({}) result is success = {} ", this.unitId, jobId, isSaved);
		MMrJobManager.setInquiryJobStatus(Long.valueOf(jobId), JobState.RESULTED);
		bodyBuff = null;
		t.stop();
		logger.debug("****Get mu({}) inquriy job results body used time = {} ****", this.unitId, jobId, t.elapsedTime());
		PerformanceLogger.trace(getClass().getSimpleName(), "proccessInquiryJobResults", this.unitId, jobId, t.elapsedTime());
		t = null;
	}

	/**	
	 *  
	 * @param jobId
	 * @param bodyLegth
	 * @param checkSum
	 * @param responId
	 * @param conversationTimer
	 * @throws InvalidProtocolBufferException
	 */
	private void proccessVerifyJobResults(Long jobId, int bodyLegth, int checkSum, Long responId, int conversationTimer) throws InvalidProtocolBufferException {
		StopWatch t = new StopWatch();		
		t.start();
		logger.info("EuReceiver({}) Will go to receive verify job results body", this.unitId);
		if (bodyLegth != checkSum) {
			PBVerifyResponse checkSumErrResult = ProtobufUtil.buildRollbackPBVerifyResponse(ErrorDifinitions.VERIFY_JOB_RESULT_CHECK_SUM_ERROR, null, null, null);
			MMrJobManager.saveVerifyJobResult(jobId, checkSumErrResult);
			MMrJobManager.setInquiryJobStatus(jobId, JobState.FAILD);
			return;
		}
		if (!this.unitCard.getUnitType().name().equals(UnitType.EXTRACTOR.name())) {
			String unitTypeError = "There are some wrong! this unit is not a extractor!";
			logger.error(unitTypeError);
			return;
		}
		ByteBuffer bodyBuff = ByteBuffer.allocate(bodyLegth);
		bodyBuff.order(ByteOrder.BIG_ENDIAN);
		int readBodyReturnVal = -9999;
		if (jobId <= 0) {
			logger.warn("JobId({} is incorrected in muId({}). skip...", jobId, this.unitId);
		}
		readBodyReturnVal = receiveData(bodyBuff, 30, conversationTimer);
		logger.debug("Eu({}) read verify job results body *PROCESS* is value of {}", this.unitId, readBodyReturnVal);
		if (readBodyReturnVal == -5) { // offline this unit
			String errMsg = "Unit(" + String.valueOf(this.unitId) + ") may be no active!";
			if (!channel.isConnected()) {
				//handleUnitEvent(MessageType.exit);
				throw new AimRuntimeException(errMsg);
			}
		}	
		if (readBodyReturnVal < -4) {
			logger.debug("EU({}) may be no active!", this.unitId);
			return;
		}
		byte[] pbBody = new byte[bodyLegth];
		bodyBuff.flip();
		bodyBuff.get(pbBody);
		logger.info("received job({}) result form mu{},body size={}", jobId, this.unitId, bodyLegth);		
		PBVerifyResponse verifyResult = PBVerifyResponse.parseFrom(pbBody);

		logger.info("euReceiver({}) will go to save job({}) results!", this.unitId, jobId);
		if (MMrJobManager.checkVerifyJobIsReulstedOrFinished(jobId)) {
			logger.error("The verify job({}) already has finished! MMr will skip save job results", jobId);
			return;
		}
		MMrJobManager.saveVerifyJobResult(jobId, verifyResult);
		boolean isSaved = MMrJobManager.checkVerifyJobIsReulstedOrFinished(jobId);
		logger.debug("MMr save eu({}) verify job({}) result is success = {} ", this.unitId, jobId, isSaved);

		MMrJobManager.setVerifyJobStatus(Long.valueOf(jobId), JobState.RESULTED);
		bodyBuff = null;
		t.stop();		
		logger.debug("****Get eu({}) verify job results body used time = {} ****", this.unitId, jobId, t.elapsedTime());
		PerformanceLogger.trace(getClass().getSimpleName(),  "proccessVerifyJobResults", this.unitId, jobId, t.elapsedTime());
		t = null;
	}

	/**
	 * 
	 * @param jobId
	 * @param bodyLegth
	 * @param checkSum
	 * @param responId
	 * @param conversationTimer
	 * @throws InvalidProtocolBufferException
	 */
	private void proccessExtractJobResults(Long jobId, int bodyLegth, int checkSum, Long responId, int conversationTimer) throws InvalidProtocolBufferException {
		StopWatch t = new StopWatch();		
		t.start();
		logger.info("EuReceiver({}) Will go to receive extract job results body", this.unitId);
		if (bodyLegth != checkSum) {
			logger.warn("The checkSum is incorrect, bodyLegth = {}, while checkSum = {}", bodyLegth, checkSum);
			PBExtractJobResult.Builder checkSumErrResult = PBExtractJobResult.newBuilder();
			PBServiceState checkSumErrState = ProtobufUtil.buildRollbackPBServiceState(ErrorDifinitions.EXTRACT_JOB_RESULT_CHECK_SUM_ERROR, null, null, null);
			checkSumErrResult.setServiceState(checkSumErrState);
			MMrJobManager.saveExtractJobResult(jobId, checkSumErrResult.build());
			MMrJobManager.setExtractJobStatus(jobId, JobState.FAILD);
			return;
		}
		if (!this.unitCard.getUnitType().name().equals(UnitType.EXTRACTOR.name())) {
			String unitTypeError = "There are some wrong! this unit is not a extractor!";
			logger.error(unitTypeError);
			return;
		}
		ByteBuffer bodyBuff = ByteBuffer.allocate(bodyLegth);
		bodyBuff.order(ByteOrder.BIG_ENDIAN);
		int readBodyReturnVal = -9999;
		if (jobId <= 0) {
			logger.warn("JobId({} is incorrected in muId({}). skip...", jobId, this.unitId);
		}
		readBodyReturnVal = receiveData(bodyBuff, 30, conversationTimer);
		logger.debug("Eu({}) result of read body *PROCESS* is {}", this.unitId, readBodyReturnVal);
		if (readBodyReturnVal == -5) { // offline this unit
			String errMsg = "Unit(" + String.valueOf(this.unitId) + ") may be no active!";
			if (!channel.isConnected()) {				
				throw new AimRuntimeException(errMsg);
			}
		}		
		if (readBodyReturnVal < -4) {
			logger.debug("EU({}) may be no active!", this.unitId);
			return;
		}

		byte[] pbBody = new byte[bodyLegth];
		bodyBuff.flip();
		bodyBuff.get(pbBody);
		logger.info("received job({}) result form eu{},body size={}", jobId, this.unitId, bodyLegth);		
		PBExtractJobResult extResult =PBExtractJobResult.parseFrom(pbBody);			
		logger.info("euReceiver({}) will go to save job({}) results!", this.unitId, jobId);

		if (MMrJobManager.checkExtractJobIsReulstedOrFinished(jobId)) {
			logger.error("The extract job({}) already has finished! MMr will skip save job results", jobId);
			return;
		}

		MMrJobManager.saveExtractJobResult(jobId, extResult);
		boolean isSaved = MMrJobManager.checkExtractJobIsReulstedOrFinished(jobId);
		logger.info("MMr save eu({}) exatrct job({}) result is success = {} ", this.unitId, jobId, isSaved);
		MMrJobManager.setExtractJobStatus(Long.valueOf(jobId), JobState.RESULTED);
		bodyBuff = null;
		t.stop();		
		logger.debug("****Get eu({}) extract job results body used time = {} ****", this.unitId, jobId, t.elapsedTime());
		PerformanceLogger.trace(getClass().getSimpleName(), "proccessExtractJobResults", this.unitId, jobId, t.elapsedTime());
		t = null;
	}

	/**
	 * 
	 * @param msnType
	 */
	private void proccssUnitMessage(MessageType msnType) {		
		AimUnitsDao dao = new AimUnitsDaoImp(new JdbcTemplate(DataBaseUtil.lookupDataSource()));
		// String unique = unitCard.getUniqueKey();
		if (this.unitCard == null) {
			String errMsg = "This unit isn't entered(connected) to MMr, because of it's unitCard is null";
			throw new AimRuntimeException(errMsg);
		}
		logger.info("Event arrived: UnitId={}, message Type={}.", this.unitCard.getUnitId(), msnType.name());
		switch (msnType) {
		case ready:	
			logger.info("Unit({}) ready event arrived!", this.unitCard.getUnitId());
			if (dao.updateAimUnit(this.unitId, UnitStatus.ready.name())) {
				dao.commit();
				this.unitCard.setStatus(UnitStatus.ready);
				logger.info("unit({}) status is turn to ready ", unitId);
				addUnitListener();
				unitMessageSender.onReady();
			} else {
				dao.rollback();
			}
			break;
		case hold:
			logger.info("Unit({}) hold event arrived!", this.unitCard.getUnitId());
			if (dao.setUnitStatus(this.unitId, UnitStatus.hold.name())) {
				this.unitCard.setStatus(UnitStatus.hold);
				logger.info("unit({}) status is turn to busy ", unitId);
				dao.commit();
				unitMessageSender.onHold();				
			} else {
				dao.rollback();
				String errMsg = "An error occurred while update db status to hold!";
				throw new AimRuntimeException(errMsg);				
			}
			break;
		case exit:
			logger.info("Unit({}) exit event arrived!", this.unitCard.getUnitId());			
			removeUnitListener();
			if (dao.setUnitStatus(this.unitId, UnitStatus.exit.name())) {
				this.unitCard.setStatus(UnitStatus.exit);
				logger.info("unit receiver({}) status is turn to exit ", unitId);
				dao.commit();
				unitMessageSender.onExit();				
			} else {
				dao.rollback();
				String errMsg = "An error occurred while update db status to exit!";
				throw new AimRuntimeException(errMsg);
			}			
			if (this.channel != null | this.channel.isOpen()) {
				try {
					this.channel.close();
				} catch (IOException e) {
					logger.error(e.getMessage(), e);
				}
			}	
			if (this.channelLocker != null)
			this.channelLocker = null;
			if (this.unitCard != null)
			this.unitCard = null;
			if (this.unitMessageSender != null);
			this.unitMessageSender =null;			
			break;
		default:
			break;
		}
	}

	private List<ContainerInfo> updateDbForEnter(PBComponentInfo enterInfo) {
		List<ContainerInfo> unitContainerInfo = null;	
		AimUnitsDao dao = null;
		SequenceDao sqDao = null;
		ContainersDao containerDao = null;
		DataSource ds = null;
		try {
			ds = DataBaseUtil.lookupDataSource();
			JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
			dao = new AimUnitsDaoImp(jdbcTemplate);
			sqDao = new SequenceDaoImp(jdbcTemplate);
			MuUsedContainerDao muCDao = new MuUsedContainerDaoImp(jdbcTemplate);
			containerDao = new ContainersDaoImp(jdbcTemplate);
			long toBeSetUnitId = -999;
			AimUnits unit = dao.getUnitUsingUrlAndPort(enterInfo.getUniqueId());
			boolean isEnteredMu = this.unitCard != null && this.unitCard.getUnitType().name().equals(UnitType.MATCHER.name());
			boolean isEnteredEu = this.unitCard != null && this.unitCard.getUnitType().name().equals(UnitType.EXTRACTOR.name());
			
			if (unit == null || unit.getUniqueId() == null) {
				toBeSetUnitId = sqDao.getNextUnitId();
				dao.insertAimUnit(toBeSetUnitId, enterInfo.getComponent().getNumber(), enterInfo.getUniqueId(), UnitStatus.connected.name());
				if (isEnteredMu) {
					dao.insertMuEligibleContainers(Long.valueOf(toBeSetUnitId));
				}	
			} else if (unit.getUniqueId().equals(enterInfo.getUniqueId())) {
				toBeSetUnitId = unit.getUnitId();
				dao.updateAimUnit(Long.valueOf(toBeSetUnitId), UnitStatus.connected.name());
			}			
			if (isEnteredMu) {
				unitContainerInfo = muCDao.getMuEligibleContainerInfo(Long.valueOf(toBeSetUnitId));
				AIMrManger.saveMuEligiblecontaineinfo(Long.valueOf(toBeSetUnitId), unitContainerInfo);
			} else if (isEnteredEu) {
				unitContainerInfo = containerDao.getAllContainerInfo();
			}			
			dao.commit();
			sqDao.commit();			
			unitId = Long.valueOf(toBeSetUnitId);
			this.unitCard.setUnitId(toBeSetUnitId);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			dao.rollback();
			sqDao.rollback();
		}
		return unitContainerInfo;
	}

	private Long buildAndSendPBConnectResponse(List<ContainerInfo> muContainerInfo, long toBeSetUnitId, long responId) throws IOException {
		PBConnectResponse.Builder enterResponse = PBConnectResponse.newBuilder();
		enterResponse.setUnitId(toBeSetUnitId);
		for (ContainerInfo info : muContainerInfo) {
			PBContainerInfo.Builder pBContainerInfo = PBContainerInfo.newBuilder();
			pBContainerInfo.setContainerId(info.getContainerId());
			pBContainerInfo.setAlgorithm(info.getAlgorithm());
			pBContainerInfo.setMaxRecordCount(info.getMaxRecordCount().longValue());
			pBContainerInfo.setModality(info.getModality());
			pBContainerInfo.setRecordCount(info.getRecordCount());
			pBContainerInfo.setTableName(info.getPersonBiTtableName());
			pBContainerInfo.setTemplateSize(info.getTemplateSize());
			pBContainerInfo.setVersion(info.getVersion());
			enterResponse.addContainerInfo(pBContainerInfo);
		}
		byte[] enterBody = enterResponse.build().toByteArray();
		int enterSize = enterBody.length;
		ByteBuffer respByte = ByteBuffer.allocate(BUF_HEAD_SIZE + enterSize);
		respByte.order(ByteOrder.BIG_ENDIAN);
		String postCard = "0000000000000000";
		respByte.putLong(responId);
		respByte.putInt(enterSize);
		respByte.putInt(enterSize);
		respByte.putLong(Long.valueOf(toBeSetUnitId));
		respByte.putLong(0L);
		respByte.put(postCard.getBytes());
		respByte.put(enterBody);
		respByte.flip();		
		if (respByte.hasRemaining()) {
			while (respByte.hasRemaining()) {
				channel.write(respByte);
			}
		}		
		logger.info("MMr sended messageId({}), unitId({}),messageBody(size={}) to unit({}).", responId, Long.valueOf(toBeSetUnitId), enterSize, toBeSetUnitId);
		respByte = null;
		return Long.valueOf(toBeSetUnitId);
	}
	
	private void makeRollbackExtractJobResults(Long extJobId) {
		MMrJobManager.setExtractJobStatus(extJobId, JobState.GETRESULTFAILD);
		PBExtractJobResult faildExtResult = ProtobufUtil.buildRollbackPBExtractJobResult(ErrorDifinitions.EXTRACT_RESULT_RECEIVE_FAILD, null, null, null);
		MMrJobManager.saveExtractJobResult(extJobId, faildExtResult);
	}
	
	private void makeRollbackIdentifyJobResults(Long inquiryJobId) {	
		MMrJobManager.setInquiryJobStatus(inquiryJobId, JobState.GETRESULTFAILD);
		PBIdentifyResponse identifyResponse = ProtobufUtil.buildFaildPBIdentifyResponse(ErrorDifinitions.IDENTIFY_RESULT_RECEIVE_FAILD, null, null, null);
		MMrJobManager.saveInquiryJobResult(inquiryJobId, identifyResponse);
	}

	
	private void makeRollbackVerifyJobResults(Long verifyJobId) {	
		MMrJobManager.setVerifyJobStatus(verifyJobId, JobState.GETRESULTFAILD);
		PBVerifyResponse verifyResponse = ProtobufUtil.buildFaildPBVerifyResponse(ErrorDifinitions.VERIFY_RESULT_RECEIVE_FAILD, null, null, null);
		MMrJobManager.saveVerifyJobResult(verifyJobId, verifyResponse);
	}
	
	private void exitUnitOnDB() {
		AimUnitsDao dao = new AimUnitsDaoImp(new JdbcTemplate(DataBaseUtil.lookupDataSource()));
		Long unitId = this.unitCard.getUnitId();		
		if (dao.updateAimUnit(unitId,  UnitStatus.exit.name())) {
			dao.commit();
			this.unitCard.setStatus(UnitStatus.exit);
			unitMessageSender.onExit();	
			logger.info("unit{} status is turn to exit" , unitId);							
		} else {
			dao.rollback();
		}
		dao = null;			
	}

	private void removeUnitListener() {
		unitMessageSender.getUnitCard().setStatus(UnitStatus.exit);
		EventNotifier notify = EventNotifier.getInstance();		
		if (this.unitCard.getUnitType().name().equals(UnitType.MATCHER.name())) {
			notify.removeMuSenderListener(unitMessageSender);
		} else if (this.unitCard.getUnitType().name().equals(UnitType.EXTRACTOR.name())) {
			notify.removeEuSenderListener(unitMessageSender);
		}
	}
	
	private void addUnitListener() {
		unitMessageSender.getUnitCard().setStatus(UnitStatus.ready);
		EventNotifier notify = EventNotifier.getInstance();		
		if (this.unitCard.getUnitType().name().equals(UnitType.MATCHER.name())) {			
			notify.addMuSenderListener(unitMessageSender);
		} else if (this.unitCard.getUnitType().name().equals(UnitType.EXTRACTOR.name())) {
			notify.addEuSenderListener(unitMessageSender);
		}
	}
}