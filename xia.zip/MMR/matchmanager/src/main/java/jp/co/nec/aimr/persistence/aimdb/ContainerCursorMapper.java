package jp.co.nec.aimr.persistence.aimdb;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class ContainerCursorMapper implements RowMapper<ContainerInfo> {
	@Override
	public ContainerInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
		ContainerInfo uc = new ContainerInfo();
		uc.setContainerId(rs.getInt("CONTAINER_ID"));
		uc.setMaxRecordCount(rs.getLong("MAX_RECORD_COUNT"));
		uc.setRecordCount(rs.getInt("RECORD_COUNT"));
		uc.setTemplateSize(rs.getInt("TEMPLATE_SIZE"));
		uc.setVersion(rs.getInt("VERSION"));
		uc.setAlgorithm(rs.getString("ALGORITHM"));
		uc.setModality(String.format("%s", rs.getString("MODALITY")));
		uc.setPersonBiTtableName(rs.getString("CONTAINER_TABLE_NAME"));
		uc.setConatainerLogTableName(rs.getString("CONTAINER_LOG_TABLE_NAME"));
		return uc;
	}
}
