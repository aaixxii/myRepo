package jp.co.nec.aimr.persistence.aimdb;

import jp.co.nec.aim.message.proto.ManageService.PBGetTemplateResponse;

/**
 * 
 * @author xiazp
 * AIMrTemplatesDao updating template from database
 *
 */
public interface AIMrTemplatesDao {

	/**
	 * 
	 * @param containerId
	 * @param userKey
	 * @param eventId
	 * @param data
	 * @return
	 */
	public SyncResultWithStatus insertTemplate(Integer containerId, String userKey, Integer eventId, byte[] data);

	/**
	 * 
	 * @param containerId
	 * @param userKey
	 * @param eventId
	 * @param data
	 * @return
	 */
	public SyncResultWithStatus updateTemplate(Integer containerId, String userKey, Integer eventId, byte[] data);

	/**
	 * 
	 * @param containerId
	 * @param userKey
	 * @param eventId
	 * @return
	 */
	public SyncResultWithStatus deleteTemplate(Integer containerId, String userKey, Integer eventId);

	/**
	 * 
	 * @param containerId
	 * @param externalId
	 * @param eventId
	 * @return
	 */
	public PBGetTemplateResponse getTemplates(Integer containerId, String externalId, Integer eventId);
	
	public void commit();

	public void rollback();

}
