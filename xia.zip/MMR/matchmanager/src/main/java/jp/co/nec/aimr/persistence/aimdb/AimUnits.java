package jp.co.nec.aimr.persistence.aimdb;

import jp.co.nec.aimr.common.UnitStatus;

public class AimUnits {
	Long unitId;
	Integer unitType;
	String uniqueId;
	UnitStatus unitStatus;
	
	public Long getUnitId() {
		return unitId != null ? unitId : null;
	}
	public void setUnitId(Long unitId) {
		this.unitId = unitId;
	}
	public Integer getUnitType() {
		return unitType;
	}
	public void setUnitType(Integer unitType) {
		this.unitType = unitType;
	}
	public String getUniqueId() {
		return uniqueId != null ? uniqueId : null;
	}
	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}
	public UnitStatus getUnitStatus() {
		return unitStatus;
	}
	public void setUnitStatus(UnitStatus unitStatus) {
		this.unitStatus = unitStatus;
	}

}
