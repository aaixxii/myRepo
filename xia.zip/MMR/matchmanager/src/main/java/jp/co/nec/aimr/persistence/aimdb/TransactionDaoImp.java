package jp.co.nec.aimr.persistence.aimdb;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

public class TransactionDaoImp implements TransactionDao {
	private DataSource dataSource;

	public TransactionDaoImp(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	@Override
	public void COMMIT() {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		jdbcTemplate.execute("COMMIT");
		
	}

	@Override
	public void rollback() {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		jdbcTemplate.execute("ROLLBACK");		
	}
}
