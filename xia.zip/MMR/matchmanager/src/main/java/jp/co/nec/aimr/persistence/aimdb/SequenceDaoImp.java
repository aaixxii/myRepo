package jp.co.nec.aimr.persistence.aimdb;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aimr.management.AIMrManger;

public class SequenceDaoImp implements SequenceDao { 
	private JdbcTemplate jdbcTemplate;
	private String DB_NAME;

	private static Logger logger = LoggerFactory.getLogger(SequenceDaoImp.class);

	public SequenceDaoImp(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
		DB_NAME = AIMrManger.getInstance().getDB_DRIVER();
		DB_NAME = DB_NAME.toUpperCase();
	}

	@Override
	public long getNextUnitId() {
		Long nextUnitId = null;
		String sql = null;
		String realSql = null;		
		String upSql = null;
		switch (DB_NAME) {
		case "ORACLE":		
		case "MYSQL":
			sql = "SELECT SEQUENCE_VALUE + 1 FROM SEQUENCE WHERE SEQUENCE_NAME = 'UNIT_ID_SEQ' ";
			realSql = sql + "FOR UPDATE";
			upSql = "UPDATE SEQUENCE SET SEQUENCE_VALUE=? WHERE SEQUENCE_NAME = 'UNIT_ID_SEQ'";
			break;
		case "POSTGRESQL":
			sql = "SELECT \"SEQUENCE_VALUE\" + 1 FROM \"SEQUENCE\" WHERE \"SEQUENCE_NAME\" = 'UNIT_ID_SEQ' ";
			realSql = sql + "FOR UPDATE";
			upSql = "UPDATE \"SEQUENCE\" SET \"SEQUENCE_VALUE\"=? WHERE \"SEQUENCE_NAME\" = 'UNIT_ID_SEQ'";
			break;
		case "SQLSERVER":
			sql = "SELECT SEQUENCE_VALUE + 1 FROM SEQUENCE WHERE SEQUENCE_NAME = 'UNIT_ID_SEQ' ";
			realSql = "SELECT SEQUENCE_VALUE + 1 FROM SEQUENCE WITH(ROWLOCK, UPDLOCK) WHERE SEQUENCE_NAME = 'UNIT_ID_SEQ'";
			upSql = "UPDATE SEQUENCE SET SEQUENCE_VALUE=? WHERE SEQUENCE_NAME = 'UNIT_ID_SEQ'";
			break;
		default:
			break;
		}
		nextUnitId = jdbcTemplate.queryForObject(realSql, Long.class);
		//String upSql = "UPDATE SEQUENCE SET SEQUENCE_VALUE=? WHERE SEQUENCE_NAME = 'UNIT_ID_SEQ'";
		jdbcTemplate.update(upSql, new Object[] { Long.valueOf(nextUnitId) });
		return nextUnitId;

	}

	@Override
	public long getNextChangeLogId() throws DataAccessException {
		Long nextId = null;
		String sql = null;		
		String realSql = null;	
		String upSql = null;
		switch (DB_NAME) {
		case "ORACLE":	
		case "MYSQL":
			sql = "SELECT SEQUENCE_VALUE + 1 FROM SEQUENCE WHERE SEQUENCE_NAME = 'CHANGE_ID_SEQ'";
			realSql = sql + " for update";
			upSql = "UPDATE SEQUENCE SET SEQUENCE_VALUE=? WHERE SEQUENCE_NAME = 'CHANGE_ID_SEQ'";
			break;
		case "POSTGRESQL":
			sql = "SELECT \"SEQUENCE_VALUE\" + 1 FROM \"SEQUENCE\" WHERE \"SEQUENCE_NAME\" = 'CHANGE_ID_SEQ'";
			realSql = sql + " for update";
			upSql = "UPDATE \"SEQUENCE\" SET \"SEQUENCE_VALUE\"=? WHERE \"SEQUENCE_NAME\" = 'CHANGE_ID_SEQ'";
			break;			
			
		case "SQLSERVER":
			realSql = "SELECT SEQUENCE_VALUE + 1 FROM SEQUENCE WITH(ROWLOCK, UPDLOCK) WHERE SEQUENCE_NAME = 'CHANGE_ID_SEQ'";
			break;
		default:
			break;
		}
		nextId = jdbcTemplate.queryForObject(realSql, Long.class);		
		jdbcTemplate.update(upSql, new Object[] { Long.valueOf(nextId) });
		return nextId;
	}

	@Override
	public long getNextBiometricsId() {
		Long nextId = null;
		String sql = null;
		String realSql = null;
		String upSql = null;		
		switch (DB_NAME) {
		case "ORACLE":		
		case "MYSQL":	
			sql = "SELECT SEQUENCE_VALUE + 1 FROM SEQUENCE WHERE SEQUENCE_NAME = 'BIOMETRICS_ID_SEQ'";
			realSql = sql + " FOR UPDATE";
			upSql = "UPDATE SEQUENCE SET SEQUENCE_VALUE=? WHERE SEQUENCE_NAME = 'BIOMETRICS_ID_SEQ'";
			break;
		case "POSTGRESQL":
			sql = "SELECT \"SEQUENCE_VALUE\" + 1 FROM \"SEQUENCE\" WHERE \"SEQUENCE_NAME\" = 'BIOMETRICS_ID_SEQ'";
			realSql = sql + " FOR UPDATE";
			upSql = "UPDATE \"SEQUENCE\" SET \"SEQUENCE_VALUE\"=? WHERE \"SEQUENCE_NAME\" = 'BIOMETRICS_ID_SEQ'";
			break;			
		case "SQLSERVER":
			realSql = "SELECT SEQUENCE_VALUE + 1 FROM SEQUENCE WITH(ROWLOCK, UPDLOCK) WHERE SEQUENCE_NAME = 'BIOMETRICS_ID_SEQ'";
			break;
		default:
			break;
		}
		nextId = jdbcTemplate.queryForObject(realSql, Long.class);		 
		jdbcTemplate.update(upSql, new Object[] { Long.valueOf(nextId) });
		return nextId;
	}

	@Override
	public long getNextChangeLogVersion(String tableName) throws DataAccessException {
		Long currentId = null;
		String realSql = null;
		String strQuery = null;
		String execSql = null;
		switch (DB_NAME) {
		case "ORACLE":		
		case "MYSQL":
			strQuery = "SELECT VERSION FROM $TABLENAME WHERE VERSION = (SELECT MAX(VERSION)  FROM $TABLENAME) FOR UPDATE";
			execSql = strQuery.replace("$TABLENAME", tableName);
			realSql = execSql;
			break;
		case "POSTGRESQL":	
			tableName = "\"" + tableName +  "\"";
			strQuery = "SELECT \"VERSION\" FROM %s WHERE \"VERSION\" = (SELECT MAX(\"VERSION\")  FROM %s) FOR UPDATE";
			execSql = String.format(strQuery, tableName, tableName);
			realSql = execSql;
			break;
		case "SQLSERVER":
			String msSql = "SELECT MAX(VERSION) FROM $TABLENAME WITH(ROWLOCK, UPDLOCK)";
			realSql = msSql.replace("$TABLENAME", tableName);
			break;
		default:
			break;
		}
		try {
			currentId = jdbcTemplate.queryForObject(realSql, Long.class);
		} catch (Exception e) {
			if (e instanceof EmptyResultDataAccessException) {
				logger.warn("The table {} is not data", tableName);
				currentId = 0L;
			} else {
				currentId = -1L;
			}			
		}		
		return currentId + 1;
	}

	@Override
	public void commit() {
		jdbcTemplate.execute("COMMIT");
	}

	@Override
	public void rollback() {
		jdbcTemplate.execute("ROLLBACK");
	}

	@Override
	public void updateChangeLogId(long changeLogId) {
		String setChangeLogIdSql = null;
		switch (DB_NAME) {
		case "ORACLE":		
		case "MYSQL":
			setChangeLogIdSql = "UPDATE SEQUENCE SET SEQUENCE_VALUE=SEQUENCE_VALUE + ? WHERE SEQUENCE_NAME = 'CHANGE_ID_SEQ'";
			break;
		case "POSTGRESQL":	
			setChangeLogIdSql = "UPDATE \"SEQUENCE\" SET \"SEQUENCE_VALUE\"=\"SEQUENCE_VALUE\" + ? WHERE \"SEQUENCE_NAME\" = 'CHANGE_ID_SEQ'";
		case "SQLSERVER":
	
			break;
		default:
			break;
		}		
		jdbcTemplate.update(setChangeLogIdSql, new Object[] {changeLogId});		
	}

}
