package jp.co.nec.aimr.logging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PerformanceLogger {
	private static Logger log = LoggerFactory.getLogger(PerformanceLogger.class);

	// Basic Items
	private static final String KEY_VALUE_SEPARATOR = "===";
	private static final String LOG_ITEM_SEPARATOR = "<>";

	// Key-Values
	private static final String KEY_FORMAT = "FORMAT";
	private static final String KEY_CATEGORY = "CATEGORY";
	private static final String KEY_COMPONENT = "COMPONENT";
	private static final String KEY_FUNCTION = "FUNC";
	private static final String KEY_UNIT_ID = "UNIT_ID";
	private static final String KEY_JOB_ID = "JOB_ID";
	private static final String KEY_CLASS = "CLASS";
	private static final String KEY_ELAPSED_TIME = "ELAPSED_TIME";
	

	private static final String VALUE_FORMAT = "NSV";
	private static final String VALUE_CATEGORY = "PERF";

	private PerformanceLogger() {
	}

	public static final void trace(String className, String functionName,  Long muId, Long jobId, long elapsedTime) {
		// Don't throw exception because logger must not affect application
		// behavior
		if (className == null) {
			return;
		}

		if (functionName == null) {
			return;
		}

		String performanceLogMessage = buildPerformanceLog("MM", className, functionName, muId, jobId, elapsedTime);		
			log.trace(performanceLogMessage);
		
	}

	private static final String buildPerformanceLog(String componentName, String className, String functionName, Long muId, Long jobId, long elapsedTime) {
		StringBuilder logMessage = new StringBuilder();

		appendKeyAndValue(logMessage, KEY_FORMAT, VALUE_FORMAT);
		appendLogItemSeparator(logMessage);

		appendKeyAndValue(logMessage, KEY_CATEGORY, VALUE_CATEGORY);
		appendLogItemSeparator(logMessage);

		appendKeyAndValue(logMessage, KEY_COMPONENT, componentName);
		appendLogItemSeparator(logMessage);

		appendKeyAndValue(logMessage, KEY_CLASS, className);
		appendLogItemSeparator(logMessage);

		appendKeyAndValue(logMessage, KEY_FUNCTION, functionName);
		appendLogItemSeparator(logMessage);
		
		if (muId != null) {
			appendKeyAndValue(logMessage, KEY_UNIT_ID, String.valueOf(muId));
			appendLogItemSeparator(logMessage);
		}
		
		if (jobId != null) {
			appendKeyAndValue(logMessage, KEY_JOB_ID, String.valueOf(jobId));
			appendLogItemSeparator(logMessage);
		}

		appendKeyAndValue(logMessage, KEY_ELAPSED_TIME, new Long(elapsedTime).toString());

		String performanceLogMessage = logMessage.toString();
		return performanceLogMessage;
	}

	private static final void appendKeyAndValue(StringBuilder logMessage, String key, String value) {
		logMessage.append(key);
		logMessage.append(KEY_VALUE_SEPARATOR);
		logMessage.append(value);
	}

	private static final void appendLogItemSeparator(StringBuilder logMessage) {
		logMessage.append(LOG_ITEM_SEPARATOR);
	}
}
