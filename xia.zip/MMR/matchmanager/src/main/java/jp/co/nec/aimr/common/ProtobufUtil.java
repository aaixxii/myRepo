package jp.co.nec.aimr.common;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceStateReason;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractJobResult;
import jp.co.nec.aim.message.proto.InquiryService.PBIdentifyResponse;
import jp.co.nec.aim.message.proto.InquiryService.PBVerifyResponse;
import jp.co.nec.aimr.exception.AimRuntimeException;

public class ProtobufUtil {
	
	public static final PBExtractJobResult buildFaildPBExtractJobResult(ErrorDifinitions errDifinition, Integer conainerId, String userKey, Integer eventId) {
		if (errDifinition == null) {
			throw new AimRuntimeException("The parameter to build PBExtractJobResult is null!");
		}
		PBExtractJobResult.Builder pBExtractJobResult = PBExtractJobResult.newBuilder();
		
		PBServiceStateReason.Builder pBServiceStateReason = PBServiceStateReason.newBuilder();
		pBServiceStateReason.setCode(errDifinition.getStringCode());
		pBServiceStateReason.setDescription(errDifinition.getDescriptionWithKey(conainerId, userKey, eventId));
		pBServiceStateReason.setTime(getCurrentTime());
		PBServiceState.Builder pBServiceState = PBServiceState.newBuilder();
		pBServiceState.setState(ServiceStateType.SERVICE_STATE_ERROR);
		pBServiceState.setReason(pBServiceStateReason);
		pBExtractJobResult.setServiceState(pBServiceState.build());
		return pBExtractJobResult.build();		
	}
	
	public static final PBExtractJobResult buildRollbackPBExtractJobResult(ErrorDifinitions errDifinition, Integer conainerId, String userKey, Integer eventId) {
		if (errDifinition == null) {
			throw new AimRuntimeException("The parameter to build PBExtractJobResult is null!");
		}
		PBExtractJobResult.Builder pBExtractJobResult = PBExtractJobResult.newBuilder();		
		PBServiceStateReason.Builder pBServiceStateReason = PBServiceStateReason.newBuilder();
		pBServiceStateReason.setCode(errDifinition.getStringCode());
		pBServiceStateReason.setDescription(errDifinition.getDescriptionWithKey(conainerId, userKey, eventId));
		pBServiceStateReason.setTime(getCurrentTime());
		PBServiceState.Builder pBServiceState = PBServiceState.newBuilder();
		pBServiceState.setState(ServiceStateType.SERVICE_STATE_ROLLBACK);
		pBServiceState.setReason(pBServiceStateReason);
		pBExtractJobResult.setServiceState(pBServiceState.build());
		return pBExtractJobResult.build();		
	}	

	public static final PBIdentifyResponse buildFaildPBIdentifyResponse(ErrorDifinitions errDifinition, Integer conainerId, String userKey, Integer eventId) {
		if (errDifinition == null) {
			throw new AimRuntimeException("The parameter to build PBIdentifyResponse is null!");
		}
		PBIdentifyResponse.Builder pBIdentifyResponse = PBIdentifyResponse.newBuilder();
		PBServiceStateReason.Builder pBServiceStateReason = PBServiceStateReason.newBuilder();
		pBServiceStateReason.setCode(errDifinition.getStringCode());
		pBServiceStateReason.setDescription(errDifinition.getDescriptionWithKey(conainerId, userKey, eventId));
		pBServiceStateReason.setTime(getCurrentTime());
		PBServiceState.Builder pBServiceState = PBServiceState.newBuilder();
		pBServiceState.setState(ServiceStateType.SERVICE_STATE_ERROR);
		pBServiceState.setReason(pBServiceStateReason);
		pBIdentifyResponse.setServiceState(pBServiceState.build());
		return pBIdentifyResponse.build();
	}
	
	public static final PBIdentifyResponse buildPBIdentifyResponseWithState(PBServiceState pBServiceState) {
		if (pBServiceState == null) {
			throw new AimRuntimeException("The parameter to build PBIdentifyResponse is null!");
		}
		PBIdentifyResponse.Builder pBIdentifyResponse = PBIdentifyResponse.newBuilder();	
		pBIdentifyResponse.setServiceState(pBServiceState);
		return pBIdentifyResponse.build();
	}
	
	public static final PBIdentifyResponse buildRollbackPBIdentifyResponse(ErrorDifinitions errDifinition, Integer conainerId, String userKey, Integer eventId) {
		if (errDifinition == null) {
			throw new AimRuntimeException("The parameter to build PBIdentifyResponse is null!");
		}
		PBIdentifyResponse.Builder pBIdentifyResponse = PBIdentifyResponse.newBuilder();
		PBServiceStateReason.Builder pBServiceStateReason = PBServiceStateReason.newBuilder();
		pBServiceStateReason.setCode(errDifinition.getStringCode());
		pBServiceStateReason.setDescription(errDifinition.getDescriptionWithKey(conainerId, userKey, eventId));
		pBServiceStateReason.setTime(getCurrentTime());
		PBServiceState.Builder pBServiceState = PBServiceState.newBuilder();
		pBServiceState.setState(ServiceStateType.SERVICE_STATE_ROLLBACK);
		pBServiceState.setReason(pBServiceStateReason);
		pBIdentifyResponse.setServiceState(pBServiceState.build());
		return pBIdentifyResponse.build();
	}

	public static final PBServiceState buildFaildPBServiceState(ErrorDifinitions errDifinition, Integer conainerId, String userKey, Integer eventId) {
		if (errDifinition == null) {
			throw new AimRuntimeException("The parameter to build PBServiceState is null!");
		}
		PBServiceState.Builder pBServiceState = PBServiceState.newBuilder();
		pBServiceState.setState(ServiceStateType.SERVICE_STATE_ERROR);
		PBServiceStateReason.Builder reason = PBServiceStateReason.newBuilder();
		reason.setCode(errDifinition.getStringCode());
		reason.setDescription(errDifinition.getDescriptionWithKey(conainerId, userKey, eventId));
		reason.setTime(getCurrentTime());
		pBServiceState.setReason(reason);
		return pBServiceState.build();
	}
	
	public static final PBServiceState buildRollbackPBServiceState(ErrorDifinitions errDifinition, Integer conainerId, String userKey, Integer eventId) {
		if (errDifinition == null) {
			throw new AimRuntimeException("The parameter to build PBServiceState is null!");
		}
		PBServiceState.Builder pBServiceState = PBServiceState.newBuilder();
		pBServiceState.setState(ServiceStateType.SERVICE_STATE_ROLLBACK);
		PBServiceStateReason.Builder reason = PBServiceStateReason.newBuilder();
		reason.setCode(errDifinition.getStringCode());
		reason.setDescription(errDifinition.getDescriptionWithKey(conainerId, userKey, eventId));
		reason.setTime(getCurrentTime());
		pBServiceState.setReason(reason);
		return pBServiceState.build();
	}

	public static final PBVerifyResponse buildFaildPBVerifyResponse(ErrorDifinitions errDifinition, Integer conainerId, String userKey, Integer eventId) {
		if (errDifinition == null) {
			throw new AimRuntimeException("The parameter to build PBVerifyResponse is null!");
		}
		PBVerifyResponse.Builder pBVerifyResponse = PBVerifyResponse.newBuilder();
		PBServiceStateReason.Builder pBServiceStateReason = PBServiceStateReason.newBuilder();
		pBServiceStateReason.setCode(errDifinition.getStringCode());
		pBServiceStateReason.setDescription(errDifinition.getDescriptionWithKey(conainerId, userKey, eventId));
		pBServiceStateReason.setTime(getCurrentTime());
		PBServiceState.Builder pBServiceState = PBServiceState.newBuilder();
		pBServiceState.setState(ServiceStateType.SERVICE_STATE_ERROR);
		pBServiceState.setReason(pBServiceStateReason);
		pBVerifyResponse.setServiceState(pBServiceState.build());
		return pBVerifyResponse.build();
	}
	
	public static final PBVerifyResponse buildRollbackPBVerifyResponse(ErrorDifinitions errDifinition, Integer conainerId, String userKey, Integer eventId) {
		if (errDifinition == null) {
			throw new AimRuntimeException("The parameter to build PBVerifyResponse is null!");
		}
		PBVerifyResponse.Builder pBVerifyResponse = PBVerifyResponse.newBuilder();
		PBServiceStateReason.Builder pBServiceStateReason = PBServiceStateReason.newBuilder();
		pBServiceStateReason.setCode(errDifinition.getStringCode());
		pBServiceStateReason.setDescription(errDifinition.getDescriptionWithKey(conainerId, userKey, eventId));
		pBServiceStateReason.setTime(getCurrentTime());
		PBServiceState.Builder pBServiceState = PBServiceState.newBuilder();
		pBServiceState.setState(ServiceStateType.SERVICE_STATE_ROLLBACK);
		pBServiceState.setReason(pBServiceStateReason);
		pBVerifyResponse.setServiceState(pBServiceState.build());
		return pBVerifyResponse.build();
	}
	
	public static String getCurrentTime() {
		String format = "dd-MM-yyyy HH:mm:ss";
		SimpleDateFormat dateFormat = new SimpleDateFormat(format);		
		Calendar cal = Calendar.getInstance();		
		return dateFormat.format(cal.getTime());
	}
	
}
