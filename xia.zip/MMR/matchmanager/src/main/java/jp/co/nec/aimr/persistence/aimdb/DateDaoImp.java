package jp.co.nec.aimr.persistence.aimdb;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

import jp.co.nec.aimr.management.AIMrManger;

/**
 * @author xiazp
 */
public class DateDaoImp implements DataDao {	
	private String DB_NAME;
	private String STRING_TIMESTAMP_SQL;
	private String DB_DATE_SQL;
	private JdbcTemplate jdbcTemplate;
	private static Logger log = LoggerFactory.getLogger(DateDaoImp.class);
	

	public DateDaoImp(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
		this.DB_NAME = AIMrManger.getInstance().getDB_DRIVER().toUpperCase();
		this.STRING_TIMESTAMP_SQL = getStringTimeStampSql();
		this.DB_DATE_SQL = getDBDataSql();
	}

	/**
	 * get current Data
	 * 
	 * @return
	 */
	@Override
	public Date getDatabaseDate() {	
		if (DB_DATE_SQL == null) {
			DB_DATE_SQL = getDBDataSql();
		}
		Date date = (Date) jdbcTemplate.queryForObject(DB_DATE_SQL, Date.class);		
		log.debug("DateHelper Oracle Date = " + date);				
		return date;
	}

	@Override
	public String getStringCurrentTimeMS() {
		if (STRING_TIMESTAMP_SQL == null) {
			STRING_TIMESTAMP_SQL = getStringTimeStampSql();
		}
		String timestamp = (String) jdbcTemplate.queryForObject(STRING_TIMESTAMP_SQL, String.class);
		return timestamp;
	}
	
	private String getDBDataSql() {
		String dateSql = null;		
		switch (DB_NAME) {
		case "ORACLE":
			dateSql = "select systimestamp from dual";	
			break;
		case "PostgreSQL":
			dateSql = "select current_timestamp";
			break;
		case "MYSQL":
			dateSql = "SELECT CURRENT_TIMESTAMP";
			break;
		case "SQLSERVER":
			dateSql = "SELECT CURRENT_TIMESTAMP";	
			break;
		default:
			break;
		}
		return dateSql;		
	}
	
	private String getStringTimeStampSql() {
		String timestampSql = null;		
		switch (DB_NAME) {
		case "ORACLE":
			timestampSql = "SELECT TO_CHAR(SYSTIMESTAMP, 'yyyy/mm/dd hh24:mi:ss.ff3') FROM DUAL";	
			break;
		case "POSTGRESQL":
			timestampSql = "select now()";
			break;
		case "MYSQL":
			timestampSql = "SELECT NOW()";
			break;
		case "SQLSERVER":
			timestampSql = "SELECT GETDATE()";	
			break;
		default:
			break;
		}
		return timestampSql;		
	}
}
