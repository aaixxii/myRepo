package jp.co.nec.aimr.event;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.message.proto.AIMMessages.PBContainerSyncRequest;
import jp.co.nec.aimr.common.JobState;
import jp.co.nec.aimr.common.UnitStatus;
import jp.co.nec.aimr.exception.NoActiveUnitException;
import jp.co.nec.aimr.exception.PropertyFileException;
import jp.co.nec.aimr.management.AIMrManger;
import jp.co.nec.aimr.management.MMrJobManager;
import jp.co.nec.aimr.matchunit.UnitMessageSender;
import jp.co.nec.aimr.persistence.aimdb.ContainerInfo;
import jp.co.nec.aimr.properties.PropertyNames;
import jp.co.nec.aimr.properties.PropertyUtil;

/**
 * @author xiazp <br/>
 *         EventNotifier fired event while some thing is happened
 */
public class EventNotifier {
	private static final EventNotifier INSTANCE = new EventNotifier();

	private static CopyOnWriteArrayList<EventListener> systemListenerQueue = new CopyOnWriteArrayList<>();
	private static CopyOnWriteArrayList<EventListener> euSenderListenerList = new CopyOnWriteArrayList<>();
	private static CopyOnWriteArrayList<EventListener> muSenderListenerList = new CopyOnWriteArrayList<>();

	private  AtomicInteger lastSelectEu = new AtomicInteger(-1);
	private  AtomicInteger lastSelectMu = new AtomicInteger(-1);
	private Lock muLock = new ReentrantLock();
	private Lock euLock = new ReentrantLock();

	private static Logger logger = LoggerFactory.getLogger(EventNotifier.class);

	private EventNotifier() {
	}

	public static EventNotifier getInstance() {
		return INSTANCE;
	}

	public synchronized void addSystemListener(EventListener listener) {
		systemListenerQueue.remove(listener);
		systemListenerQueue.add(listener);
	}

	public synchronized void removeSystemListener(EventListener listener) {
		systemListenerQueue.remove(listener);
	}
	
//	public synchronized void removeUnitReceiver(UnitMessageReceiver unitReciver) {		
//		systemListenerQueue.remove((EventListener)unitReciver);
//		unitReciver = null;
//	}

	public synchronized void addMuSenderListener(EventListener listener) {
		muSenderListenerList.remove(listener);
		muSenderListenerList.add(listener);
	}

	public synchronized void removeMuSenderListener(EventListener listener) {
		muSenderListenerList.remove(listener);
	}

	public synchronized void addEuSenderListener(EventListener listener) {
		euSenderListenerList.remove(listener);
		euSenderListenerList.add(listener);
	}

	public synchronized void removeEuSenderListener(EventListener listener) {
		euSenderListenerList.remove(listener);
	}

	public void fireOnIdentifyJobqueueing(int containerId, Long inquiryJobId) {
		muLock.lock();
		try {
			caculateNextMu(containerId);
			if (lastSelectMu.intValue() >= 0) {
				UnitMessageSender sender = (UnitMessageSender) muSenderListenerList.get(lastSelectMu.intValue());
				sender.onIdentifyJobqueueing(inquiryJobId);
			} else {
				MMrJobManager.setInquiryJobStatus(inquiryJobId,JobState.TRYASSIGNING);
				Long clientJobWaitingTime = null;
				try {
					clientJobWaitingTime = PropertyUtil.getInstance()
							.getPropertyLongValue(PropertyNames.MMR_CLIENT_JOB_TIME_OUT.name());
				} catch (Exception e) {
					logger.error(e.getMessage(), e);
					String proErrMsg = "An excetpion occurred while reading 'aimr.mm.properties' file.";
					throw new PropertyFileException(proErrMsg);
				}
				long beginTime = System.currentTimeMillis();
				while (System.currentTimeMillis() - beginTime <= clientJobWaitingTime) {
					caculateNextMu(containerId);
					if (lastSelectMu.intValue() >= 0) {
						UnitMessageSender sender = (UnitMessageSender) muSenderListenerList
								.get(lastSelectMu.intValue());
						MMrJobManager.setInquiryJobStatus(inquiryJobId,JobState.QUEUED);
						sender.onIdentifyJobqueueing(inquiryJobId);
						return;
					}
					Thread.currentThread();
					try {
						logger.debug("No active Mu, try waiting...");
						Thread.sleep(1000l);
					} catch (InterruptedException e) {
						logger.error(e.getMessage(), e);
					}
				}
				String errMsg = "No active mu to proccss identify job(%s)!";
				String fs = String.format(errMsg, inquiryJobId);
				throw new NoActiveUnitException(fs);
			}

		} finally {
			muLock.unlock();
		}
	}

	public void fireOnVerifyJobqueueing(Long verifyJobId) {
		euLock.lock();
		try {
			caculateNextEu();
			if (lastSelectEu.intValue() >= 0) {
				UnitMessageSender sender = (UnitMessageSender) euSenderListenerList.get(lastSelectEu.intValue());
				sender.onVerifyJobqueueing(verifyJobId);
			} else {
				MMrJobManager.setVerifyJobStatus(verifyJobId,JobState.TRYASSIGNING);
				Long clientJobWaitingTime = null;
				try {
					clientJobWaitingTime = PropertyUtil.getInstance()
							.getPropertyLongValue(PropertyNames.MMR_CLIENT_JOB_TIME_OUT.name());
				} catch (Exception e) {
					logger.error(e.getMessage(), e);
					String proErrMsg = "An excetpion occurred while reading 'aimr.mm.properties' file.";
					throw new PropertyFileException(proErrMsg);
				}
				long beginTime = System.currentTimeMillis();
				while (System.currentTimeMillis() - beginTime <= clientJobWaitingTime) {
					caculateNextEu();
					if (lastSelectEu.intValue() >= 0) {
						UnitMessageSender sender = (UnitMessageSender) euSenderListenerList
								.get(lastSelectEu.intValue());
						MMrJobManager.setVerifyJobStatus(verifyJobId, JobState.QUEUED);
						sender.onVerifyJobqueueing(verifyJobId);
						return;
					}
					Thread.currentThread();
					try {
						logger.debug("No active eu, try waiting...");
						Thread.sleep(1000l);
					} catch (InterruptedException e) {
						logger.error(e.getMessage(), e);
					}
				}
				String errMsg = "No active eu to proccss verify job(%s)!";
				String fs = String.format(errMsg, verifyJobId);
				throw new NoActiveUnitException(fs);
			}
		} finally {
			euLock.unlock();
		}

	}

	public void fireOnExtractJobqueueing(Long extractJobId) {
		euLock.lock();
		try {
			caculateNextEu();
			if (lastSelectEu.intValue() >= 0) {
				UnitMessageSender sender = (UnitMessageSender) euSenderListenerList.get(lastSelectEu.intValue());
				sender.onExtractJobqueueing(extractJobId);
			} else {
				MMrJobManager.setExtractJobStatus(extractJobId, JobState.TRYASSIGNING);
				Long clientJobWaitingTime = null;
				try {
					clientJobWaitingTime = PropertyUtil.getInstance()
							.getPropertyLongValue(PropertyNames.MMR_CLIENT_JOB_TIME_OUT.name());
				} catch (Exception e) {
					logger.error(e.getMessage(), e);
					String proErrMsg = "An excetpion occurred while reading 'aimr.mm.properties' file.";
					throw new PropertyFileException(proErrMsg);
				}
				long beginTime = System.currentTimeMillis();
				while (System.currentTimeMillis() - beginTime <= clientJobWaitingTime) {
					caculateNextEu();
					if (lastSelectEu.intValue() >= 0) {
						UnitMessageSender sender = (UnitMessageSender) euSenderListenerList
								.get(lastSelectEu.intValue());
						MMrJobManager.setExtractJobStatus(extractJobId, JobState.QUEUED);
						sender.onExtractJobqueueing(extractJobId);
						logger.debug("try sucessed! assigned job({}) to eu({})", extractJobId, sender.getUnitCard().getUnitId());
						return;
					}
					Thread.currentThread();
					try {
						logger.debug("No active eu, try waiting...");
						Thread.sleep(1000l);
					} catch (InterruptedException e) {
						logger.error(e.getMessage(), e);
					}
				}
				String errMsg = "No active eu to proccss extract job(%s)!";
				String fs = String.format(errMsg, extractJobId);
				throw new NoActiveUnitException(fs);
			}

		} finally {
			euLock.unlock();
		}
	}

	public void fireOnStop() throws IOException {
		for (EventListener listener : systemListenerQueue) {
			listener.onStop();
			removeSystemListener(listener);
		}
	}

	public void fireOnSyncTemplates(Long syncJobId, PBContainerSyncRequest syncRequust) {
		muLock.lock();
		try {
			for (EventListener listener : muSenderListenerList) {
				UnitMessageSender sender = (UnitMessageSender) listener;
				if (sender.getUnitStatus().name().equals(UnitStatus.exit.name())) {
					muSenderListenerList.remove(listener);
				}
			}
			if (muSenderListenerList.size() < 1) {
				logger.info("No mu which status in ready and hold, skip...");
				return;
			}
			int requestContainerId = syncRequust.getContainerId();
			ConcurrentHashMap<Long, List<ContainerInfo>> muEliginContainers = AIMrManger.getMuEligiblecontaineinfoMap();
			for (EventListener listener : muSenderListenerList) {
				UnitMessageSender sender = (UnitMessageSender) listener;
				List<ContainerInfo> alowdContaiers = muEliginContainers.get(sender.getUnitCard().getUnitId());
				if (alowdContaiers != null && isHaveMe(alowdContaiers, requestContainerId)
						&& (sender.getUnitStatus().name().equals(UnitStatus.ready.name())
								|| sender.getUnitStatus().name().equals(UnitStatus.hold.name()))) {
					listener.onSyncTemplates(syncJobId, syncRequust);
				}
			}

		} finally {
			muLock.unlock();
		}

	}

	public void caculateNextEu() {
		euLock.lock();
		try {
			if (euSenderListenerList.size() < 1) {
				lastSelectEu = new AtomicInteger(-1);
				return;
			}
			if (euSenderListenerList.size() == 1) {
				UnitMessageSender sender = (UnitMessageSender) euSenderListenerList.get(0);
				if (sender.getUnitStatus().name().equals(UnitStatus.ready.name())) {
					lastSelectEu = new AtomicInteger(0);
				} else {
					lastSelectEu = new AtomicInteger(-1);
				}
				return;
			}
			lastSelectEu.incrementAndGet();
			for (int i = 0; i < euSenderListenerList.size(); i++) {
				if (lastSelectEu.intValue() >= euSenderListenerList.size()) {
					lastSelectEu = new AtomicInteger(0);
				}
				UnitMessageSender sender = (UnitMessageSender) euSenderListenerList.get(lastSelectEu.intValue());
				if (sender.getUnitStatus().name().equals(UnitStatus.ready.name())) {
					return;
				} else {
					lastSelectEu.incrementAndGet();
				}
			}
			lastSelectEu = new AtomicInteger(-1);

		} finally {
			euLock.unlock();
		}

	}

	public void caculateNextMu(int containerId) {
		muLock.lock();
		try {
			List<ContainerInfo> myContainerList = null;
			if (muSenderListenerList.size() < 1) {
				lastSelectMu = new AtomicInteger(-1);
				return;
			}

			if (muSenderListenerList.size() == 1) {
				UnitMessageSender sender = (UnitMessageSender) muSenderListenerList.get(0);
				myContainerList = AIMrManger.getMuEliginbleConatainerInfo(sender.getUnitCard().getUnitId());
				if (myContainerList != null && sender.getUnitStatus().name().equals(UnitStatus.ready.name())
						&& isHaveMe(myContainerList, containerId)) {
					lastSelectMu = new AtomicInteger(0);
				} else {
					lastSelectMu = new AtomicInteger(-1);
				}
				return;
			}

			lastSelectMu.incrementAndGet();

			for (int i = 0; i < muSenderListenerList.size(); i++) {
				if (lastSelectMu.intValue() >= muSenderListenerList.size()) {
					lastSelectMu = new AtomicInteger(0);
				}
				UnitMessageSender sender = (UnitMessageSender) muSenderListenerList.get(lastSelectMu.intValue());
				myContainerList = AIMrManger.getMuEliginbleConatainerInfo(sender.getUnitCard().getUnitId());
				if (myContainerList != null && sender.getUnitStatus().name().equals(UnitStatus.ready.name())
						&& isHaveMe(myContainerList, containerId)) {
					return;
				} else {
					lastSelectMu.incrementAndGet();
				}
			}
			lastSelectMu = new AtomicInteger(-1);

		} finally {
			muLock.unlock();
		}

	}

	private boolean isHaveMe(List<ContainerInfo> containerList, int containerId) {
		for (ContainerInfo info : containerList) {
			if (info.getContainerId().intValue() == containerId) {
				return true;
			}
		}
		return false;
	}
}
