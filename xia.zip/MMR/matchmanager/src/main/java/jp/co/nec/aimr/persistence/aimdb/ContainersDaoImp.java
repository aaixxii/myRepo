package jp.co.nec.aimr.persistence.aimdb;

import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import jp.co.nec.aimr.management.AIMrManger;

public class ContainersDaoImp implements ContainersDao{
	private JdbcTemplate jdbcTemplate;
	private String DB_NAME;
	
	public ContainersDaoImp(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
		DB_NAME = AIMrManger.getInstance().getDB_DRIVER();
		DB_NAME = DB_NAME.toUpperCase();
	}

	@Override
	public List<ContainerInfo> getAllContainerInfo() throws DataAccessException {
		String sql = null;
		switch (DB_NAME) {
		case "ORACLE":		
		case "MYSQL":
			sql = ""
					+ "SELECT CS.CONTAINER_ID, CS.CONTAINER_TABLE_NAME,CS.CONTAINER_LOG_TABLE_NAME,CS.ALGORITHM, "
					+ "CS.MODALITY,CS.MAX_RECORD_COUNT,CS.RECORD_COUNT,CS.TEMPLATE_SIZE,CS.VERSION "
					+ "FROM CONTAINERS CS ";
			break;
		case "POSTGRESQL":
			sql = ""
					+ "SELECT CS.\"CONTAINER_ID\", CS.\"CONTAINER_TABLE_NAME\",CS.\"CONTAINER_LOG_TABLE_NAME\",CS.\"ALGORITHM\", "
					+ "CS.\"MODALITY\",CS.\"MAX_RECORD_COUNT\",CS.\"RECORD_COUNT\",CS.\"TEMPLATE_SIZE\",CS.\"VERSION\" "
					+ "FROM \"CONTAINERS\" CS ";
			break;
		case "SQLSERVER":	
			break;
		default:
			break;
		}
		
		List<ContainerInfo> reuslts = jdbcTemplate.query(sql, new ContainerCursorMapper());
		return reuslts;
	}
}
