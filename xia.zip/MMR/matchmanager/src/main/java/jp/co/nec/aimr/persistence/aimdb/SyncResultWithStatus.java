package jp.co.nec.aimr.persistence.aimdb;

import jp.co.nec.aim.message.proto.AIMMessages.PBContainerSyncRequest;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;

public class SyncResultWithStatus {
	private PBContainerSyncRequest pBContainerSyncRequest;
	private PBServiceState pBServiceState;
	public PBContainerSyncRequest getpBContainerSyncRequest() {
		return pBContainerSyncRequest;
	}
	public void setpBContainerSyncRequest(PBContainerSyncRequest pBContainerSyncRequest) {
		this.pBContainerSyncRequest = pBContainerSyncRequest;
	}
	public PBServiceState getpBServiceState() {
		
		return pBServiceState == null ? null: pBServiceState;
	}
	public void setpBServiceState(PBServiceState pBServiceState) {
		this.pBServiceState = pBServiceState;
	}
}
