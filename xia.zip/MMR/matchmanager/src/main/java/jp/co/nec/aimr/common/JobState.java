package jp.co.nec.aimr.common;

public enum JobState {
	QUEUED(0), //
	TRYASSIGNING(1),
	ASSIGNED(2), //
	SENDED(3), //
	SENDFAILD(4),
	RESULTED(5), //
	GETRESULTFAILD(6),//
	RETURNED(7), //
	TIMEOUT(8), //	
	FAILD(9);

	private int val;

	private JobState(int val) {
		this.val = val;
	}

	public int getVal() {
		return val;
	}

}