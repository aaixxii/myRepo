package jp.co.nec.aimr.exception;

import jp.co.nec.aimr.common.ErrorDifinitions;

public class DbProcessResultEmptyException extends RuntimeException {	
	private static final long serialVersionUID = -3939200294798640465L;	
	
	public DbProcessResultEmptyException(String detail) {
		super(detail);
	}

	public DbProcessResultEmptyException(Throwable ex) {
		super(ex);
	}

	public DbProcessResultEmptyException(String detail, Throwable ex) {
		super(detail, ex);
	}

	public DbProcessResultEmptyException(ErrorDifinitions errorDifinition) {
		super(errorDifinition.toString());
	}

}
