package jp.co.nec.aimr.management;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import jp.co.nec.aimr.persistence.aimdb.ContainerInfo;
import jp.co.nec.aimr.properties.PropertyNames;
import jp.co.nec.aimr.properties.PropertyUtil;

/**
 * @author xiazp
 * ThreadPollManger manage thread pool in MMr
 */
public class AIMrManger {
	private ExecutorService unitReceiveExecutor;

	private static final ConcurrentHashMap<Integer, String> personBiometricsTabMap = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<Integer, String> personBiometricsChangeLogTabMap = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<Long, List<ContainerInfo>> muEligibleContaineInfoMap = new ConcurrentHashMap<>();
	
	private static final Object personBiometricsTabMapLocker = new Object();
	private static final Object personBiometricsChangeLogTabMapLocker = new Object();
	private static final Object muEligibleContaineInfoMapLocker = new Object();
	
	private static final Object DB_DRIVER_LOCKER = new Object();
	
	
	

	private static final AIMrManger mMrManagerInstance = new AIMrManger();
	
	private  String DB_DRIVER;

	public  static AIMrManger getInstance() {
		return mMrManagerInstance;
	}

	public AIMrManger() {
		init();
	}	


	public static ConcurrentHashMap<Integer, String> getPersonbiometricstabmap() {
		synchronized(personBiometricsTabMapLocker){
			return personBiometricsTabMap;
		}		
	}

	public static ConcurrentHashMap<Integer, String> getPersonbiometricschangelogtabmap() {
		synchronized(personBiometricsChangeLogTabMapLocker) {
			return personBiometricsChangeLogTabMap;
		}		
	}

	public static ConcurrentHashMap<Long, List<ContainerInfo>> getMuEligiblecontaineinfoMap() {
		synchronized(muEligibleContaineInfoMapLocker) {
			return muEligibleContaineInfoMap;
		}		
	}
	
	public static List<ContainerInfo> getMuEliginbleConatainerInfo(Long muId) {
		if (muId != null) {
			return getMuEligiblecontaineinfoMap().get(muId);
			
		} else {
			return null;
		}		
	}
	
	public static void saveMuEligiblecontaineinfo(Long muId, List<ContainerInfo> muUsedContaierInfos) {
		getMuEligiblecontaineinfoMap().remove(muId);
		getMuEligiblecontaineinfoMap().put(muId, muUsedContaierInfos);		
	}

	/**
	 * ThreadPoll initialize
	 */
	private void init() {
		PropertyUtil util = PropertyUtil.getInstance();			
		DB_DRIVER = util.getPropertyValue(PropertyNames.MMR_DB_DRIVER.name());
		unitReceiveExecutor = Executors.newCachedThreadPool();		
	}	

	public  String getDB_DRIVER() {
		synchronized(DB_DRIVER_LOCKER) {
			if (DB_DRIVER != null) {
				return DB_DRIVER;
			} else {
				return  PropertyUtil.getInstance().getPropertyValue(PropertyNames.MMR_DB_DRIVER.name());
			}
		}		
	}

	public static List<Integer> getContainerKeys() {
		return Collections.list(personBiometricsTabMap.keys());
	}

	public static void saveTopersonBiometricsTabMap(Integer containerId, String pbName) {		
		getPersonbiometricstabmap().put(containerId, pbName);
		
	}

	public static String getPersonBiometricsTabName(Integer containerId) {
		return getPersonbiometricstabmap().get(containerId);
	}

	public static void saveTopersonBiometricsChangeLogTabMap(Integer containerId, String pbChangelogName) {
		getPersonbiometricschangelogtabmap().put(containerId, pbChangelogName);		
	}

	public static String getPersonBiometricsChangeLogTabName(Integer containerId) {
		return getPersonbiometricschangelogtabmap().get(containerId);
	}

	public ExecutorService getUnitReceiveExecutor() {
		return unitReceiveExecutor;
	}
}