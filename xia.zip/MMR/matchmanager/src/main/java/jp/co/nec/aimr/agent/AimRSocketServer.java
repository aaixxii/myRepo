package jp.co.nec.aimr.agent;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aimr.event.EventAdapter;
import jp.co.nec.aimr.event.EventNotifier;
import jp.co.nec.aimr.exception.AimRuntimeException;
import jp.co.nec.aimr.management.AIMrManger;
import jp.co.nec.aimr.matchunit.UnitMessageReceiver;
import jp.co.nec.aimr.properties.PropertyNames;
import jp.co.nec.aimr.properties.PropertyUtil;

/**
 * @author xiazp <br/>
 *  Socket Server accept connections from client<br/>
 */
public class AimRSocketServer extends EventAdapter implements Runnable {
	private ServerSocketChannel serverSocketChannel ;
	private Selector selector;

	private static Logger logger = LoggerFactory.getLogger(AimRSocketServer.class);

	int port;
	int serverSocketTimeout;

	public AimRSocketServer() throws IOException {
		init();
	}

	/**
	 * Socket Server initialize and startup
	 */
	private void init() {
		int port = PropertyUtil.getInstance().getPropertyIntValue(PropertyNames.MMR_SOCKET_SERVER_PORT.name());
		int serverSocketTimeout = PropertyUtil.getInstance().getPropertyIntValue(PropertyNames.MMR_SERVER_SOCKET_TIMEOUT.name());
		try {
			selector = Selector.open();
			serverSocketChannel = ServerSocketChannel.open();
			serverSocketChannel.socket().setReuseAddress(true);
			serverSocketChannel.socket().setSoTimeout(serverSocketTimeout);
			serverSocketChannel.configureBlocking(false);
			serverSocketChannel.socket().bind(new InetSocketAddress(port));
		} catch (IOException e) {
			String errmsg = "Can't starting MMR socket server!";
			throw new AimRuntimeException(errmsg, e);
		}
		logger.info("MMR Socket Server is starting...");
	}

	/**
	 * Socket Server accept client connection
	 * 
	 * @author xiazp
	 * @param
	 * @return
	 * @throws IOException
	 */
	public void service() throws IOException {
		serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);
		while (selector.select() > 0) {
			Set<SelectionKey> readyKeys = selector.selectedKeys();
			Iterator<SelectionKey> it = readyKeys.iterator();
			while (it.hasNext()) {
				SelectionKey key = null;
				try {
					key = (SelectionKey) it.next();
					it.remove();
					if (key.isAcceptable()) {
						SocketChannel socketChannel = serverSocketChannel.accept();
						socketChannel.configureBlocking(false);
						logger.info("Accepted unit: " + socketChannel.socket().getInetAddress() + ":" + socketChannel.socket().getPort());
						socketChannel.register(selector, SelectionKey.OP_READ);
						UnitMessageReceiver unitReciver = new UnitMessageReceiver(socketChannel);							
						AIMrManger.getInstance().getUnitReceiveExecutor().submit(unitReciver);
						EventNotifier.getInstance().addSystemListener(unitReciver);
					}
				} catch (Exception e) {
					logger.error(e.getMessage(), e);
					try {
						if (key != null) {
							key.cancel();
							key.channel().close();
						}
					} catch (Exception ex) {
						logger.error(e.getMessage(), e);
					}
				}
			} // #while
		} // #while
	}

	@Override
	public void run() {
		logger.info("MMR server service is started. waiting for message..");
		try {
			service();
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
	}

	@Override
	public void onStop() throws IOException {
		if (serverSocketChannel != null || serverSocketChannel.isOpen()) {
			serverSocketChannel.close();
		}
	}
}