package jp.co.nec.aimr.persistence.aimdb;

import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

/**
 * 
 * @author xiazp
 * AimUnitsDao updating units info to database
 */
public interface AimUnitsDao {	

	/**
	 * 
	 * @param unitId
	 * @param status
	 * @return
	 * @throws DataAccessException
	 */
	public boolean updateAimUnit(Long unitId, String status) throws DataAccessException;
	/**
	 * 
	 * @param unitId
	 * @return
	 * @throws DataAccessException
	 */
	public boolean deleteAimUnit(Long unitId) throws DataAccessException;
	/**
	 * 
	 * @param unitId
	 * @return
	 * @throws DataAccessException
	 */
	public List<Map<String, Object>> getUnitEligibleContainers(Integer unitId) throws DataAccessException;
	/**
	 * 
	 * @return
	 * @throws DataAccessException
	 */
	public List<ContainerInfo> getAllContainerInfo() throws DataAccessException;
	/**
	 * 
	 * @param unitId
	 * @param type
	 * @param uniqueId
	 * @param status
	 * @return
	 * @throws DataAccessException
	 */
	public boolean insertAimUnit(long unitId, int type, String uniqueId, String status) throws DataAccessException;	
	/**
	 * 
	 * @param muId
	 * @return
	 * @throws DataAccessException
	 */
	public int insertMuEligibleContainers(Long muId) throws DataAccessException;
	/**
	 * 
	 * @param uniqueKey
	 * @return
	 * @throws DataAccessException
	 */
	public AimUnits getUnitUsingUrlAndPort(String  uniqueKey) throws DataAccessException;
	/**
	 * 
	 * @param unitId
	 * @param status
	 * @return
	 * @throws DataAccessException
	 */
	public boolean setUnitStatus(Long unitId, String status) throws DataAccessException;
	/**
	 * 
	 * @param uniqueKey
	 * @return
	 * @throws DataAccessException
	 */
	public boolean removeAimUnit(String uniqueKey) throws DataAccessException;
	
	public void commit();
	public void rollback();
}
