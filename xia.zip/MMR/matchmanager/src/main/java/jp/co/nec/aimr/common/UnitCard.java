package jp.co.nec.aimr.common;

import java.nio.channels.SocketChannel;

public class UnitCard {
	private Long unitId;
	private UnitStatus status;
	private UnitType unitType;	
	private String uniqueKey; //ip:port
	private SocketChannel socketChannel;	
	private boolean socketChannelIsUseing;

	public UnitCard() {
	}

	public Long getUnitId() {
		return unitId;
	}

	public void setUnitId(Long unitId) {
		this.unitId = unitId;
	}

	public synchronized UnitStatus getStatus() {
		return status;
	}

	public synchronized void setStatus(UnitStatus status) {
		this.status = status;
	}

	public synchronized UnitType getUnitType() {
		return unitType;
	}

	public synchronized void setUnitType(UnitType unitType) {
		this.unitType = unitType;
	}



	public synchronized SocketChannel getSocketChannel() {
		return socketChannel;
	}

	public synchronized void setSocketChannel(SocketChannel socketChannel) {
		this.socketChannel = socketChannel;
	}



	public synchronized boolean isSocketChannelIsUseing() {
		return socketChannelIsUseing;
	}

	public synchronized void setSocketChannelIsUseing(boolean socketChannelIsUseing) {
		this.socketChannelIsUseing = socketChannelIsUseing;
	}

	@Override
	public int hashCode() {
		return this.unitType.ordinal() + 10 + unitId.intValue();
	}

	@Override
	public boolean equals(Object other) { 
		if (other != null && other instanceof UnitCard && this.uniqueKey.equals(((UnitCard) other).getUniqueKey())) {				
			return true;
		} else {
			return false;
		}
	}

	public String getUniqueKey() {
		return uniqueKey;
	}

	public void setUniqueKey(String uniqueKey) {
		this.uniqueKey = uniqueKey;
	}
}
