package jp.co.nec.aimr.event;

import java.io.IOException;

import jp.co.nec.aim.message.proto.AIMMessages.PBContainerSyncRequest;

/**
 * @author xiazp <br/>
 *  EventListener handler event while some thing happened
 */
public interface EventListener {
	public void onIdentifyJobqueueing(Long inquiryJobId);

	public void onExtractJobqueueing(Long extractJobId);

	public void onVerifyJobqueueing(Long verifyJobId);

	public void onError(String error);

	public void onStop() throws IOException;

	public void onSyncTemplates(Long syncJobId, PBContainerSyncRequest syncRequust);

}