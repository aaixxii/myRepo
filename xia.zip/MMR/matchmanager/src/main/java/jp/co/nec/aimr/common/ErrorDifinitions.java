package jp.co.nec.aimr.common;

/**
 * MMr error code and error message
 * <li>Sample: 813000100
 * <li>D1: Message Type (8:Error)
 * <li>D2: Component Type(1:MatchManager)
 * <li>D3: Detail Code 1(3: Database 4: Application Programs)
 * <li>D4D5D6: Detail Code 2
 *     <li>(000:db related)
 *     <li>(001:identify related) 
 *     <li>(002:extract related)    
 *     <li>(003:verify related)     
 *     <li>(004:sync templates related)     
 *     <li>(005:servlet related)
 *     <li>(006:property file related)      
 * <li>D7D8D9: Detail Code 3(100 – 199: Communication messages) 
 * <li>
 * 
 * @author xiazp
 */

public enum ErrorDifinitions {
	
	DB_PROCESS_ERROR("813000100", "An error occurred while access to database!"),//
	DB_DUPLICATE_KEY("813000101", "The key is already exists."),//
	DB_EMPTY_RESULT("813000102", "Gotten empty reslts."),//
	DB_DEAD_LOCK("813000103", "DB dead lock happend."),//	
	DB_PERMISSION_DENIED("813000104", "DB access permission denied."),//	
	DB_QUERY_TIMOUT("813000105", "Query timeout happend."),//
	DB_TYPE_MISMATCH("813000106", "The type mismatch."),//
	DB_UNCATEGORIZE_DATA("813000107", "UncategorizedDataAccessException happend."),//	
	
	DB_UPDATE_COUNT_ZERO("813000108", "Update template count is zero!"),//
	DB_DELETE_COUNT_ZERO("813000109", "Delete template count is zero!"),//			
	DB_CONTAINERS_OVER_MAX_RECORD_COUNT("813000110", "The record count is over max records in containers table!"),//
	DB_GET_TEMPLATES_ERROR("813000111", "Can't get templates info."),//
	DB_GET_TEMPLATES_EMPTY("813000112", "Gotten empty templates info."),//
	
	IDENTIFY_RESULT_EMPTY("814001113", "The iquiry job results is empty!"),//
	IDENTIFY_REQUST_SEND_FAILD("814001114", "Send identify job request to mu is faild!"),//
	IDENTIFY_PROCESS_FAILD("814001115", "The identify job process is faild!"),//
	IDENTIFY_JOB_TIMEOUT("814001116", "The identify job is timeout!"),//
	IDENTIFY_RESULT_RECEIVE_FAILD("814001117", "The receive identiy job results process faild!"),//
	IDENTIFY_JOB_RERUN_FAILD("814001118", "The identify job rerun faild!"),//
	IDENTIFY_JOB_NO_ACTIVE_MU("81401119", "No active mu to proccess identify job!"),//
	IDENTIFY_JOB_RESULT_CHECK_SUM_ERROR("81401120", "The checksum is not equal with idenitify job result body length!"),//
	IDENTIFY_REQUEST_NO_EXTACTPAYLOAD_NO_TEMPLATE("81401121", "The PBIdentifyRequest neither extractpayload nor template. one of them is required!"),//
	

	EXTRACT_RESULT_EMPTY("814002122", "The extract job results is empty!"),//
	EXTRACT_REQUST_SEND_FAILD("814002123", "Send extract job request to eu is faild!"),//
	EXTRACT_PROCESS_FAILD("814002124", "The extract job process is faild!"),//
	EXTRACT_JOB_TIMEOUT("814002125", "The extract job is timeout!"),//
	EXTRACT_RESULT_RECEIVE_FAILD("814002126", "The receive extract job results process faild!"),//
	EXTRACT_JOB_RERUN_FAILD("814002127", "The extract job rerun faild!"),//
	EXTRACT_JOB_NO_ACTIVE_EU("814002128", "No active eu to proccess extract job!"),//
	EXTRACT_JOB_RESULT_CHECK_SUM_ERROR("814002129", "The checksum is not equal with extract job result body length!"),//


	VERIFY_RESULT_EMPTY("814003130", "The verify job results is empty!"),//	
	VERIFY_REQUST_SEND_FAILD("814003131", "Send verify job request to mu is faild!"),//
	VERIFY_PROCESS_FAILD("814003132", "The verify job process is faild!"),//
	VERIFY_JOB_TIMEOUT("814003133", "The verify job is timeout!"),//
	VERIFY_RESULT_RECEIVE_FAILD("814003134", "The receive verify job results process faild!"),//
	VERIFY_JOB_RERUN_FAILD("814003135", "The verify job rerun faild!"),//
	VERIFY_JOB_NO_ACTIVE_EU("814003136", "No active eu to proccess verify job!"),//
	VERIFY_JOB_RESULT_CHECK_SUM_ERROR("814003137", "The checksum is not equal with verify job result body length!"),//
	
	VERIFY_TARGET_NO_IMAGE_AND_NO_TEMPLATE_NO_KEY("814003138", "The PBVerifyJobInput neither image, nor template, nor key. one of them is required!"),//	
	VERIFY_NO_IMAGE_AND_NO_TEMPLATE("814003139", "The PBVerifyJobInput neither image nor template. one of them is required!"),//
	VERIFY_TARGET_IS_NULL("814003138", "The target data is not exist in PBVerifyJobInput."),//

	SYNC_PROCESS_ERROR("814004141", "Update templates to db process error!"),//
	SYNC_INSERT_REQUEST_NO_TEMPLATE_NO_EXTRACT_PAYLOAD("814004142", "The PBSync insert request neither extractpayload nor template. one of them is required!"),//
	SYNC_UPDATE_REQUEST_NO_TEMPLATE_NO_EXTRACT_PAYLOAD("814004143", "The PBSync update request neither extractpayload nor template. one of them is required!"),//
	SYNC_DELETE_REQUEST_HAVE_EXTRACT_PAYLOAD("814004144", "The PBSync delete request have a extractpayload!"),//
	
	
	CLINET_EMPTY_REQUEST_MSG("814005145", "Received an empty POST request."),//
	CLINET_NOT_SUPPORT_METHOD("814005146", "Not support method."),//
	
	PROPERTY_FILE_READ_FAILD("814006100", "Faild to read mmr property file."),//
	
	AIM_PROCESS_UNKNOWN("814007100", "An unknown exception occurred!");

	private final String code;
	private final String description;

	private ErrorDifinitions(String code, String description) {
		this.code = code;
		this.description = description;
	}

	public String getDescription() {
		return description;
	}

	public String getCode() {
		return code;
	}

	public String getStringCode() {
		return code;
	}
	
	public String getDescriptionWithKey(Integer conainerId, String userKey, Integer eventId) {
		StringBuilder sb = new StringBuilder();
		sb.append(description);		
		
		if (conainerId != null) {
			sb.append(" ConainerId = " + String.valueOf(conainerId));			
		}
		
		if (userKey != null) {
			sb.append(" userKey = " + String.valueOf(userKey));			
		}
		
		if (eventId != null) {
			sb.append(" eventId = " + String.valueOf(eventId));			
		}		
		return sb.toString();
	}

	@Override
	public String toString() {
		return code + ": " + description;
	}
}
