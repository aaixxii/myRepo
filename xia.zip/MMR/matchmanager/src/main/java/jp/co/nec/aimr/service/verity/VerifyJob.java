package jp.co.nec.aimr.service.verity;

public class VerifyJob {
	private long verifyJobId;
	private byte[] verifyJobRequest;

	public VerifyJob(long verifyJobId, byte[] verifyJobRequest) {
		this.verifyJobId = verifyJobId;
		this.verifyJobRequest = verifyJobRequest;
	}

	public long getVerifyJobId() {
		return verifyJobId;
	}

	public void setVerifyJobId(long verifyJobId) {
		this.verifyJobId = verifyJobId;
	}

	public byte[] getVerifyJobRequest() {
		return verifyJobRequest;
	}

	public void setVerifyJobRequest(byte[] verifyJobRequest) {
		this.verifyJobRequest = verifyJobRequest;
	}
}
