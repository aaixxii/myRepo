package jp.co.nec.aimr.service.template;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

import jp.co.nec.aim.message.proto.ManageService.PBGetTemplateRequest;
import jp.co.nec.aim.message.proto.ManageService.PBGetTemplateResponse;
import jp.co.nec.aimr.common.StopWatch;
import jp.co.nec.aimr.logging.PerformanceLogger;
import jp.co.nec.aimr.management.AIMrManger;
import jp.co.nec.aimr.persistence.aimdb.AIMrTemplatesDao;
import jp.co.nec.aimr.persistence.aimdb.AIMrTemplatesDaoImp;
import jp.co.nec.aimr.persistence.aimdb.AIMrTemplatesPostgresDaoImp;
import jp.co.nec.aimr.persistence.aimdb.DataBaseUtil;

/**
 * 
 * @author xiazp
 * GetTemplateService get templates from database and creating response 
 */
public class GetTemplateService {
	private PBGetTemplateRequest request;
	private static Logger logger = LoggerFactory.getLogger(GetTemplateService.class);

	public GetTemplateService(PBGetTemplateRequest request) {
		this.request = request;
	}

	/**
	 * 
	 * @return
	 */
	public PBGetTemplateResponse processGetTemplateRequest() {
		StopWatch t = new StopWatch();		
		t.start();
		String dbName = AIMrManger.getInstance().getDB_DRIVER().toUpperCase();
		PBGetTemplateResponse getTemplateResponse = null;
		Integer containerId = Integer.valueOf(request.getContainerId());
		String usekey = request.getExternalId();
		Integer eventId = (request.hasEventId() != true ? null : Integer.valueOf(request.getEventId()));
		DataSource ds = DataBaseUtil.lookupDataSource();
		JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
		AIMrTemplatesDao dao = null;
		if (dbName.equals("POSTGRESQL")) {
			dao = new AIMrTemplatesPostgresDaoImp(jdbcTemplate);
		} else {
			 dao = new AIMrTemplatesDaoImp(jdbcTemplate);
		}		
		getTemplateResponse = dao.getTemplates(containerId, usekey, eventId);
		try {
			DataSource currentDs = jdbcTemplate.getDataSource();
			DataBaseUtil.closeConnection(currentDs.getConnection(), currentDs);			
		} catch (SQLException e) {			
			logger.error(e.getMessage(), e);
		}
		PerformanceLogger.trace(getClass().getSimpleName(), "processGetTemplateRequest", null, null,  t.elapsedTime());
		t = null;
		return getTemplateResponse;
	}
}
