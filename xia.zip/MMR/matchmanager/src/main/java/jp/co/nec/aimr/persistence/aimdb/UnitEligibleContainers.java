package jp.co.nec.aimr.persistence.aimdb;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class UnitEligibleContainers implements Serializable {
	private static final long serialVersionUID = 1928186453289237317L;

	private Integer unitId;
	List<ContainerInfo> unitContainerInfos = new ArrayList<>();

	public Integer getUnitId() {
		return unitId;
	}

	public void setUnitId(Integer unitId) {
		this.unitId = unitId;
	}

	public List<ContainerInfo> getUnitContainerInfos() {
		return unitContainerInfos;
	}

	public void setUnitContainerInfos(List<ContainerInfo> unitContainerInfos) {
		this.unitContainerInfos = unitContainerInfos;
	}

}
