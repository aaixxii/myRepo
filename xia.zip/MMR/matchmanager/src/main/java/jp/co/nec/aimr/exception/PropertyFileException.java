package jp.co.nec.aimr.exception;

import jp.co.nec.aimr.common.ErrorDifinitions;

public class PropertyFileException extends RuntimeException {	

	private static final long serialVersionUID = -7952843325869562198L;

	public PropertyFileException() {
	}

	public PropertyFileException(String detail) {
		super(detail);
	}

	public PropertyFileException(Throwable ex) {
		super(ex);
	}

	public PropertyFileException(String detail, Throwable ex) {
		super(detail, ex);
	}

	public PropertyFileException(ErrorDifinitions errorDifinition) {
		super(errorDifinition.toString());
	}
}
