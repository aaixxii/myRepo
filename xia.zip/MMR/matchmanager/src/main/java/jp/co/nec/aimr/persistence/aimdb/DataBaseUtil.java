package jp.co.nec.aimr.persistence.aimdb;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceUtils;

import jp.co.nec.aimr.exception.AimRuntimeException;
import jp.co.nec.aimr.management.AIMrManger;
/**
 * 
 * @author xiazp
 * DataBaseUtil class used to get datasource, etc.
 */
public class DataBaseUtil {
	private static Logger logger = LoggerFactory.getLogger(DataBaseUtil.class);
	
	public static DataSource lookupDataSource() {
		DataSource dataSource = null;
		String dbDriver = AIMrManger.getInstance().getDB_DRIVER().toUpperCase();
		switch (dbDriver) {
		case "ORACLE":
			dataSource =  lookupOracleDataSource();	
			break;
		case "POSTGRESQL":
			dataSource =  lookupPostgreSQLDataSource();
			break;			
		case "MYSQL":
			dataSource =  lookupMySQLDataSource();	
			break;
		default:
			break;
		}
		return dataSource;	
		
	}

	/**
	 * 
	 * @return
	 */
	public static DataSource lookupOracleDataSource() {
		DataSource dataSource = null;
		Context initContext;
		Context envContext;
		try {
			initContext = new InitialContext();
			envContext = (Context) initContext.lookup("java:/comp/env");
			dataSource = (DataSource) envContext.lookup("jdbc/oracle");
			if (dataSource != null) {
				logger.debug("Success geted datasource!!");
			}
		} catch (NamingException e) {
			logger.error(e.getMessage(), e);
		}
		return dataSource;
	}
	
	public static DataSource lookupPostgreSQLDataSource() {
		DataSource dataSource = null;
		Context initContext;
		Context envContext;
		try {
			initContext = new InitialContext();
			envContext = (Context) initContext.lookup("java:/comp/env");
			dataSource = (DataSource) envContext.lookup("jdbc/postgresql");
			if (dataSource != null) {
				logger.debug("Success geted datasource!!");
			}
		} catch (NamingException e) {
			logger.error(e.getMessage(), e);
		}
		return dataSource;
	}
	
	public static DataSource lookupMySQLDataSource() {
		DataSource dataSource = null;
		Context initContext;
		Context envContext;
		try {
			initContext = new InitialContext();
			envContext = (Context) initContext.lookup("java:/comp/env");
			dataSource = (DataSource) envContext.lookup("jdbc/mysql");
			if (dataSource != null) {
				logger.debug("Success geted datasource!!");
			}
		} catch (NamingException e) {
			logger.error(e.getMessage(), e);
		}
		return dataSource;
	}
	/**
	 * 
	 * @param jdbcTemplate
	 */
	public static void setAutoCOMMITFalse(Connection conn) {		
	    try {
	        conn.setAutoCommit(false);
	    } catch (SQLException e) {
	    	logger.error(e.getMessage(), e);
	    	throw new AimRuntimeException("Can't get connection from jdbc template!");
	    }		
	}
	/**
	 * 
	 * @param jdbcTemplate
	 * @return
	 */
	public static Connection getJdbcConnetion(JdbcTemplate jdbcTemplate) {
		Connection conn = DataSourceUtils.getConnection(jdbcTemplate.getDataSource());
		return conn;
	}
	
	/**
	 * 
	 * @param conn
	 * @param dataSource
	 */
	public static void closeConnection(Connection conn, DataSource dataSource) {
		DataSourceUtils.releaseConnection(conn, dataSource);
	}
}
