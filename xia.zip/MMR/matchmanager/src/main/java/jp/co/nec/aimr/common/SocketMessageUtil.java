package jp.co.nec.aimr.common;

import java.nio.ByteBuffer;

import jp.co.nec.aimr.exception.AimRuntimeException;

public class SocketMessageUtil {	
	
	private static final String SPACE = " ";

	public SocketMessageUtil() {
	}

	public static final int createSum(byte[] bytes) {
		byte sum = 0;
		for (byte b : bytes) {
			sum ^= b;
		}
		Byte B = Byte.valueOf(sum);
		return B.intValue();
	}

	public static final int byteArrayToInt(byte[] bytes) {
		int value = 0;
		for (int i = 0; i < 4; i++) {
			int shift = (4 - 1 - i) * 8;
			value += (bytes[i] & 0x000000FF) << shift;
		}
		return value;
	}

	public static final byte[] intToByteArray(int i) {
		byte[] result = new byte[4];
		result[0] = (byte) ((i >> 24) & 0xFF);
		result[1] = (byte) ((i >> 16) & 0xFF);
		result[2] = (byte) ((i >> 8) & 0xFF);
		result[3] = (byte) (i & 0xFF);
		return result;
	}

	@SuppressWarnings("unused")
	private int change16To10(String oXString) {
		return Integer.decode(oXString).intValue();
	}

	public static final byte[] createPostCardMessage(String msg) {		
		String empty = "\0";		
		int left = 16 - msg.length();		
		if (left < 0) {
			throw new AimRuntimeException("The size of post card is over 16 byte!");
		}
		StringBuilder sb = new StringBuilder();		
		sb.append(msg);
		while (left > 0) {
			sb.append(empty);
			left--;
		}	
		return sb.toString().getBytes();		
	}
	
	public static String convertNullToSpace(String postCard) {
		int index = postCard.indexOf("\0");	
		if (index < 0) {			
			return postCard;
		}
		int size = postCard.length();
		StringBuilder sb = new StringBuilder();
		sb.append(postCard.substring(0, index));
		for (int i = 0; i < size - index; i++) {			
			sb.append(SPACE);
		}		
		return sb.toString();
	}

	public static final void buildPostCardMessage(String msg, ByteBuffer postCard) {
		byte[] msgByte = msg.getBytes();
		if (msgByte.length > 16) {
			throw new AimRuntimeException("The size of post card is over 16 byte!");
		}

		int emptyLenght = 16 - msgByte.length;
		postCard.put(msgByte);
		byte meptyChar = 0;
		if (emptyLenght > 0) {
			for (int i = 0; i < emptyLenght; i++) {
				postCard.put(meptyChar);
			}
		}
	}
}
