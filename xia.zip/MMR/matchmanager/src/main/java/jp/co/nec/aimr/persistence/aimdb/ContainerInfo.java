package jp.co.nec.aimr.persistence.aimdb;

import java.io.Serializable;

public class ContainerInfo implements Serializable {
	private static final long serialVersionUID = 8759776081720003916L;
	private Integer containerId;
	private String personBiTtableName;
	private String conatainerLogTableName;
	private String modality; // like FINGER,FACE,IRIS,IRIS+FACE
	private String algorithm; // like CML,S17,S14,NIRIS,NIRIS+S17
	private Integer templateSize;
	private Long maxRecordCount;
	private Integer recordCount;
	private Integer version;
	private Long lastEnrolledBioId;

	public Integer getContainerId() {
		return containerId;
	}

	public void setContainerId(Integer containerId) {
		this.containerId = containerId;
	}

	public String getPersonBiTtableName() {
		return personBiTtableName;
	}

	public void setPersonBiTtableName(String personBiTtableName) {
		this.personBiTtableName = personBiTtableName;
	}

	public String getModality() {
		return modality;
	}

	public void setModality(String modality) {
		this.modality = modality;
	}

	public String getAlgorithm() {
		return algorithm;
	}

	public void setAlgorithm(String algorithm) {
		this.algorithm = algorithm;
	}

	public Integer getTemplateSize() {
		return templateSize;
	}

	public void setTemplateSize(Integer templateSize) {
		this.templateSize = templateSize;
	}

	public Long getMaxRecordCount() {
		return maxRecordCount;
	}

	public void setMaxRecordCount(Long maxRecordCount) {
		this.maxRecordCount = maxRecordCount;
	}

	public Integer getRecordCount() {
		return recordCount;
	}

	public void setRecordCount(Integer recordCount) {
		this.recordCount = recordCount;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public String getConatainerLogTableName() {
		return conatainerLogTableName;
	}

	public void setConatainerLogTableName(String conatainerLogTableName) {
		this.conatainerLogTableName = conatainerLogTableName;
	}

	public Long getLastEnrolledBioId() {
		return lastEnrolledBioId;
	}

	public void setLastEnrolledBioId(Long lastEnrolledBioId) {
		this.lastEnrolledBioId = lastEnrolledBioId;
	}
	
	

}
