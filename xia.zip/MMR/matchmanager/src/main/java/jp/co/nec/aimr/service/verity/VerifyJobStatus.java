package jp.co.nec.aimr.service.verity;

import jp.co.nec.aimr.common.JobState;

public class VerifyJobStatus {
	private long verifyJobId;
	private JobState verifyJobStates;
	private String errFlg;
	private String resion;
	private long queuedTime;

	public long getVerifyJobId() {
		return verifyJobId;
	}

	public void setVerifyJobId(long verifyJobId) {
		this.verifyJobId = verifyJobId;
	}

	public JobState getVerifyJobStates() {
		return verifyJobStates;
	}

	public void setVerifyJobStates(JobState verifyJobStates) {
		this.verifyJobStates = verifyJobStates;
	}

	public String getErrFlg() {
		return errFlg;
	}

	public void setErrFlg(String errFlg) {
		this.errFlg = errFlg;
	}

	public String getResion() {
		return resion;
	}

	public void setResion(String resion) {
		this.resion = resion;
	}

	public long getQueuedTime() {
		return queuedTime;
	}

	public void setQueuedTime(long queuedTime) {
		this.queuedTime = queuedTime;
	}
}
