package jp.co.nec.aimr.common;

public enum UnitType {
	MATCHER(0), //
	EXTRACTOR(1);
	// VERIFIER(2);

	private int val;

	private UnitType(int val) {
		this.val = val;
	}

	public int getVal() {
		return val;
	}

}
