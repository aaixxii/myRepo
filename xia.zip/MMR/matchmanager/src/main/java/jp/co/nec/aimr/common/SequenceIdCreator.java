package jp.co.nec.aimr.common;

import java.util.concurrent.atomic.AtomicLong;

public class SequenceIdCreator {
	private static AtomicLong lastVerifyJobId = new AtomicLong(0);
	private static AtomicLong lastSyncTemplateJobId = new AtomicLong(0);
	private static AtomicLong lastInquriyJobId = new AtomicLong(0);
	private static AtomicLong lastExtractJobId = new AtomicLong(0);
	private static AtomicLong lastUnitId = new AtomicLong(0);

	public static final synchronized long createNextSequence(SequenceIdType jobType) {
		long value = 0;
		switch (jobType) {
		case VERIFY_JOB_ID:
			if (lastVerifyJobId.longValue() >= Long.MAX_VALUE) {
				lastVerifyJobId = new AtomicLong(0);
			}
			value = lastVerifyJobId.incrementAndGet();
			break;
		case SYNC_TEMPLATE_ID:
			if (lastSyncTemplateJobId.longValue() >= Long.MAX_VALUE) {
				lastSyncTemplateJobId = new AtomicLong(0);
			}			
			value = lastSyncTemplateJobId.incrementAndGet();
			break;
		case INQUIRY_ID:
			if (lastInquriyJobId.longValue() >= Long.MAX_VALUE) {
				lastInquriyJobId = new AtomicLong(0);
			}			
			value = lastInquriyJobId.incrementAndGet();
			break;
		case EXTEACT_ID:
			if (lastExtractJobId.longValue() >= Long.MAX_VALUE) {
				lastExtractJobId = new AtomicLong(0);
			}			
			value = lastExtractJobId.incrementAndGet();
			break;
		case UNIT_ID:
			if (lastUnitId.longValue() >= Long.MAX_VALUE) {
				lastUnitId = new AtomicLong(0);
			}			
			value = lastUnitId.incrementAndGet();
			break;			
		default:
			break;
		}
		return value;
	}
}
