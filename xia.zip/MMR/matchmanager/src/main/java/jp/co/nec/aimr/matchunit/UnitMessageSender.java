package jp.co.nec.aimr.matchunit;

import static jp.co.nec.aimr.common.Constants.BUF_HEAD_SIZE;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.SocketChannel;

import jp.co.nec.aim.message.proto.AIMMessages.PBContainerSyncRequest;
import jp.co.nec.aimr.common.JobState;
import jp.co.nec.aimr.common.StopWatch;
import jp.co.nec.aimr.common.UnitCard;
import jp.co.nec.aimr.common.UnitStatus;
import jp.co.nec.aimr.common.UnitType;
import jp.co.nec.aimr.event.EventAdapter;
import jp.co.nec.aimr.exception.AimRuntimeException;
import jp.co.nec.aimr.logging.PerformanceLogger;
import jp.co.nec.aimr.management.MMrJobManager;
import jp.co.nec.aimr.service.extract.ExtractJob;
import jp.co.nec.aimr.service.inquiry.InquiryJob;
import jp.co.nec.aimr.service.verity.VerifyJob;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author xiazp <br/>
 *         MatcherMsgSender send inquiry job request to mu at the <br/>
 *         keep alive connected channel <br/>
 */
public class UnitMessageSender extends EventAdapter {
	private UnitCard unitCard;
	private SocketChannel socketChannel;
	private Object extJobCominglocker;
	private Object verifyJobCominglocker;
	private Object inqJobCominglocker;
	private Object channelLocker;	

	private static Logger logger = LoggerFactory
			.getLogger(UnitMessageSender.class);

	public UnitMessageSender(final UnitCard muCard) {
		this.unitCard = muCard;
		this.socketChannel = muCard.getSocketChannel();
		this.extJobCominglocker = new Object();
		this.verifyJobCominglocker = new Object();
		this.inqJobCominglocker = new Object();
		this.channelLocker = new Object();
		logger.info("MuMessageSender(Id={}) is starting...", muCard.getUnitId());
	}

	/**
	 * handler mu/eu ready event
	 */
	public void onReady() {
		if (this.unitCard == null) {
			String errMsg = "This unit isn't entered(connected) to MMr, because of it's unitCard is null";
			logger.error(errMsg);
			return;
		}
		if (UnitType.MATCHER.name().equals(unitCard.getUnitType().name())) {
			getAndSendInquiryJob();
		} else if (UnitType.EXTRACTOR.name().equals(
				unitCard.getUnitType().name())) {
			getAndSendExtractJob();
			getAndSendVerifyJob();
		}
	}

	@Override
	public void onIdentifyJobqueueing(Long inquiryJobId) {
		StopWatch t = new StopWatch();
		t.start();
		logger.info("assgn inquiry job to Active macther ...");
		if (!checkStatus()) {
			return;
		}
		if (unitCard.getUnitType().name().equals(UnitType.MATCHER.name())) {
			InquiryJob inquiryJob = MMrJobManager
					.fetchOneInquiryJob(inquiryJobId);
			if (inquiryJob == null) {
				logger.info("No mu to assign job! skip...");
				return;
			}			
			sendInquiryJob(inquiryJob);
		}
		t.stop();
		PerformanceLogger.trace(getClass().getSimpleName(),
				"onIdentifyJobqueueing", null, inquiryJobId, t.elapsedTime());
		t = null;
	}

	@Override
	public void onExtractJobqueueing(Long extractJobId) {
		StopWatch t = new StopWatch();
		t.start();
		logger.info("onExtractJobqueueing evnet arived. try assign extract job to Active extractor ...");
		if (!checkStatus()) {
			return;
		}
		if (unitCard.getUnitType().name().equals(UnitType.EXTRACTOR.name())) {
			ExtractJob extractJob = MMrJobManager
					.fetchOneExtractJob(extractJobId);
			if (extractJob == null) {
				logger.info("No extract job to assign to eu! skip...");
				return;
			}			
			sendExtactJob(extractJob);
		}
		t.stop();
		PerformanceLogger.trace(getClass().getSimpleName(),
				"onExtractJobqueueing", null, extractJobId, t.elapsedTime());
		t = null;
	}

	@Override
	public void onVerifyJobqueueing(Long verifyJobId) {
		StopWatch t = new StopWatch();
		t.start();
		logger.info("assgn verify job to Active extractor ...");
		if (!checkStatus()) {
			return;
		}
		if (unitCard.getUnitType().name().equals(UnitType.EXTRACTOR.name())) {
			VerifyJob verifyJob = MMrJobManager.fetchOneVerifyJob(verifyJobId);
			if (verifyJob == null) {
				logger.info("No verify job to assign to eu! skip...");
				return;
			}			
			sendVerify(verifyJob);
		}
		t.stop();
		PerformanceLogger.trace(getClass().getSimpleName(),
				"onVerifyJobqueueing", null, verifyJobId, t.elapsedTime());
		t = null;
	}

	@Override
	public void onStop() {
		if (socketChannel != null || socketChannel.isOpen()) {
			try {
				socketChannel.close();
			} catch (IOException e) {
				logger.error(e.getMessage(), e);
			}
		}
	}

	private void getAndSendInquiryJob() {
		InquiryJob inqJob = MMrJobManager.fetchOneInquiryJob();
		if (inqJob == null) {
			logger.info("No inquiry job to assign mu! skip...");
			return;
		}
		if (!checkStatus()) {
			return;
		}	
		sendInquiryJob(inqJob);
	}

	private void getAndSendExtractJob() {
		ExtractJob extractJob = MMrJobManager.fetchOneExtractJob();
		if (extractJob == null) {
			logger.info("No extract job to assign to Eu! skip...");
			return;
		}
		if (!checkStatus()) {
			return;
		}		
		sendExtactJob(extractJob);
	}

	private void getAndSendVerifyJob() {
		VerifyJob verifyJob = MMrJobManager.fetchOneVerifyJob();
		if (verifyJob == null) {
			logger.info("No verify job assign to eu! skip...");
			return;
		}
		if (!checkStatus()) {
			return;
		}		
		sendVerify(verifyJob);
	}

	private boolean sendExtactJob(ExtractJob extJob) {
		StopWatch t = new StopWatch();
		t.start();
		Long euId = unitCard.getUnitId();
		boolean sendSuccess = false;
		try {
			Long jobId = extJob.getExJobId();
			byte[] toBeAssignJob = extJob.getExtJobRequest();
			Long mesId = 256L;
			int sizeOfBody = toBeAssignJob.length;
			ByteBuffer sendBuff = ByteBuffer.allocate(BUF_HEAD_SIZE
					+ sizeOfBody);
			sendBuff.order(ByteOrder.BIG_ENDIAN);
			sendBuff.putLong(mesId);
			sendBuff.putInt(sizeOfBody);
			sendBuff.putInt(sizeOfBody);
			sendBuff.putLong(euId);
			sendBuff.putLong(jobId);
			sendBuff.put(extJob.getPostCard());
			sendBuff.put(toBeAssignJob);
			sendBuff.flip();
			synchronized (channelLocker) {
				while (sendBuff.hasRemaining()) {
					socketChannel.write(sendBuff);
				}
			}
			sendBuff = null;
			sendSuccess = true;
			MMrJobManager.setExtractJobStatus(jobId.longValue(),
					JobState.SENDED);
			logger.info(
					"Sent extract request to EU({}). MessageId({}), JobId({}) Body size({}).",
					euId, mesId, jobId, sizeOfBody);
		} catch (IOException e) {
			logger.error("Faild to send extract job:{} to EU:{}",
					extJob.getExJobId(), euId, e);
			sendSuccess = false;
		}
		t.stop();
		logger.info("Sent extract job request to EU({}) used time = {}.", euId,
				t.elapsedTime());
		PerformanceLogger.trace(getClass().getSimpleName(), "sendExtactJob",
				euId, extJob.getExJobId(), t.elapsedTime());
		t = null;
		return sendSuccess;
	}

	private boolean sendVerify(VerifyJob verifyJob) {
		StopWatch t = new StopWatch();
		t.start();
		Long euId = unitCard.getUnitId();
		boolean sendSuccess = false;
		try {
			Long jobId = verifyJob.getVerifyJobId();
			byte[] toBeAssignJob = verifyJob.getVerifyJobRequest();
			Long mesId = 1024L;
			String postCard = "0000000000000000";
			int sizeOfBody = toBeAssignJob.length;
			ByteBuffer sendBuff = ByteBuffer.allocate(BUF_HEAD_SIZE
					+ sizeOfBody);
			sendBuff.order(ByteOrder.BIG_ENDIAN);
			sendBuff.putLong(mesId);
			sendBuff.putInt(sizeOfBody);
			sendBuff.putInt(sizeOfBody);
			sendBuff.putLong(euId);
			sendBuff.putLong(jobId);
			sendBuff.put(postCard.getBytes());
			sendBuff.put(toBeAssignJob);
			sendBuff.flip();
			synchronized (channelLocker) {
				while (sendBuff.hasRemaining()) {
					socketChannel.write(sendBuff);
				}
			}
			sendBuff = null;
			sendSuccess = true;
			MMrJobManager
					.setVerifyJobStatus(jobId.longValue(), JobState.SENDED);
			logger.info(
					"Sent verify request to EU({}). MessageId({}), JobId({}) Body size({}).",
					euId, mesId, jobId, sizeOfBody);
		} catch (IOException e) {
			logger.error("Faild to send verify job:{} to EU:{}",
					verifyJob.getVerifyJobId(), euId, e);
			sendSuccess = false;
		}
		t.stop();
		logger.info("Sent verify request to EU({}) used time = {}.", euId,
				t.elapsedTime());
		PerformanceLogger.trace(getClass().getSimpleName(), "sendVerify", euId,
				verifyJob.getVerifyJobId(), t.elapsedTime());
		t = null;
		return sendSuccess;
	}

	private boolean sendInquiryJob(InquiryJob inquiryJob) {
		StopWatch t = new StopWatch();
		t.start();
		Long muId = unitCard.getUnitId();
		Long inqJobId = inquiryJob.getJobId();
		boolean sendSuccess = false;
		try {
			String postCard = "0000000000000000";
			byte[] toBeAssignJob = inquiryJob.getpBInquiryJobRequest();
			Long mesId = 512L;
			int sizeOfBody = toBeAssignJob.length;
			ByteBuffer sendBuff = ByteBuffer.allocate(BUF_HEAD_SIZE
					+ sizeOfBody);
			sendBuff.order(ByteOrder.BIG_ENDIAN);
			sendBuff.putLong(mesId);
			sendBuff.putInt(sizeOfBody);
			sendBuff.putInt(sizeOfBody);
			sendBuff.putLong(muId);
			sendBuff.putLong(inqJobId);
			sendBuff.put(postCard.getBytes());
			sendBuff.put(toBeAssignJob);
			sendBuff.flip();
			synchronized (channelLocker) {
				while (sendBuff.hasRemaining()) {
					socketChannel.write(sendBuff);
				}
			}
			sendBuff = null;
			MMrJobManager.setInquiryJobStatus(inqJobId, JobState.SENDED);
			logger.info(
					"Sent identify request to MU({}). MessageId({}), JobId({}) Body size({}).",
					muId, mesId, inqJobId, sizeOfBody);
			sendSuccess = true;
		} catch (Exception e) {
			logger.error("Faild to send inquiry job:{} to MU:{}",
					inquiryJob.getJobId(), muId.longValue(), e);
			sendSuccess = false;
		}
		t.stop();
		logger.info("Sent identify job({}) request used time = {}.", inqJobId,
				t.elapsedTime());
		PerformanceLogger.trace(getClass().getSimpleName(), "sendInquiryJob",
				muId, inqJobId, t.elapsedTime());
		t = null;
		return sendSuccess;
	}

	@Override
	public void onSyncTemplates(Long syncJobId,
			PBContainerSyncRequest syncRequust) {
		logger.info("SyncTemplate event arrived!");
		if (this.unitCard == null) {
			String errMsg = "This unit isn't entered(connected) to MMr, because of it's unitCard is null";
			throw new AimRuntimeException(errMsg);
		}
		if (UnitType.MATCHER.name().equals(unitCard.getUnitType().name())) {
			sendSyncTemplateRequest(syncJobId, syncRequust);
		}
	}

	public void onHold() {
		unitCard.setStatus(UnitStatus.hold);
	}

	public void onExit() {
		unitCard.setStatus(UnitStatus.exit);
		logger.info("unit sender({}) status is turn to exit ", this.unitCard.getUnitId());
		if (socketChannel != null || socketChannel.isOpen()) {
			try {
				socketChannel.close();
			} catch (IOException e) {
				logger.error(e.getMessage(), e);
			}
		}	
		if (this.unitCard != null)
		this.unitCard = null;		
		if (this.channelLocker != null)
			this.channelLocker = null;
		if (this.extJobCominglocker != null)
			this.extJobCominglocker = null;
		if (this.verifyJobCominglocker != null)
			this.verifyJobCominglocker = null;
		if (this.inqJobCominglocker != null)
			this.inqJobCominglocker = null;
	}

	private boolean sendSyncTemplateRequest(Long syncJobId,
			PBContainerSyncRequest syncRequust) {
		StopWatch t = new StopWatch();
		t.start();
		Long muId = unitCard.getUnitId();
		boolean sendSuccess = false;
		try {
			// Long jobId = 0L;
			String postCard = "0000000000000000";
			byte[] syncTemplates = syncRequust.toByteArray();
			Long mesId = 2048L;
			int sizeOfBody = syncTemplates.length;
			ByteBuffer sendBuff = ByteBuffer.allocate(BUF_HEAD_SIZE
					+ sizeOfBody);
			sendBuff.order(ByteOrder.BIG_ENDIAN);
			sendBuff.putLong(mesId);
			sendBuff.putInt(sizeOfBody);
			sendBuff.putInt(sizeOfBody);
			sendBuff.putLong(muId);
			sendBuff.putLong(syncJobId);
			sendBuff.put(postCard.getBytes());
			sendBuff.put(syncTemplates);
			sendBuff.flip();
			synchronized (channelLocker) {
				while (sendBuff.hasRemaining()) {
					socketChannel.write(sendBuff);
				}
			}
			sendBuff = null;
			sendSuccess = true;
			logger.info(
					"Sent syncData to MU({}). MessageId({}), JobId({}) Body size({}).",
					muId, mesId, syncJobId, sizeOfBody);
		} catch (IOException e) {
			logger.error("Faild to send syncData job:{} to MU:{}", syncJobId,
					muId, e);
			sendSuccess = false;
		}
		t.stop();
		logger.info("Sent syncData request to MU({}) used time = {}.", muId,
				t.elapsedTime());
		PerformanceLogger.trace(getClass().getSimpleName(),
				"sendSyncTemplateRequest", muId, null, t.elapsedTime());
		t = null;
		return sendSuccess;
	}

	private boolean checkStatus() {
		boolean checkOk = true;
		UnitStatus currentStatus = this.unitCard.getStatus();
		if (this.unitCard.getStatus() == null
				|| !currentStatus.name().equals(UnitStatus.ready.name())) {
			logger.warn("The unit({})'s status is not ready. it's {}. skip...",
					this.unitCard.getUnitId(), currentStatus.name());
			checkOk = false;
		}
		return checkOk;
	}

	public Object getExtJobCominglocker() {
		return extJobCominglocker;
	}

	public Object getVerifyJobCominglocker() {
		return verifyJobCominglocker;
	}

	public Object getInqJobCominglocker() {
		return inqJobCominglocker;
	}

	public UnitType getUnitType() {
		return this.unitCard.getUnitType();
	}

	public UnitStatus getUnitStatus() {
		return this.unitCard.getStatus();
	}

	public UnitCard getUnitCard() {
		return unitCard;
	}
}
