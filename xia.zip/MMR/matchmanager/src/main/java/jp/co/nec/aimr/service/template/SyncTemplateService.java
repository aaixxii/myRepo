package jp.co.nec.aimr.service.template;

import java.io.IOException;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

import com.google.protobuf.ByteString;

import jp.co.nec.aim.message.proto.AIMMessages.PBContainerSyncRequest;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractJobResult;
import jp.co.nec.aim.message.proto.SyncEnumTypes.SyncFunctionType;
import jp.co.nec.aim.message.proto.SyncService.PBSyncJobRequest;
import jp.co.nec.aim.message.proto.SyncService.PBSyncRequest;
import jp.co.nec.aimr.common.ErrorDifinitions;
import jp.co.nec.aimr.common.PostCardType;
import jp.co.nec.aimr.common.ProtobufUtil;
import jp.co.nec.aimr.common.SequenceIdCreator;
import jp.co.nec.aimr.common.SequenceIdType;
import jp.co.nec.aimr.common.StopWatch;
import jp.co.nec.aimr.event.EventNotifier;
import jp.co.nec.aimr.logging.PerformanceLogger;
import jp.co.nec.aimr.management.AIMrManger;
import jp.co.nec.aimr.persistence.aimdb.AIMrTemplatesDao;
import jp.co.nec.aimr.persistence.aimdb.AIMrTemplatesDaoImp;
import jp.co.nec.aimr.persistence.aimdb.AIMrTemplatesPostgresDaoImp;
import jp.co.nec.aimr.persistence.aimdb.DataBaseUtil;
import jp.co.nec.aimr.persistence.aimdb.SyncResultWithStatus;
import jp.co.nec.aimr.service.extract.ExtractService;

/**
 * 
 * @author xiazp
 * SyncTemplateService update templates info to database.
 */
public class SyncTemplateService {
	private static Logger logger = LoggerFactory.getLogger(SyncTemplateService.class);
	private PBSyncRequest request;
	private final static Object locker = new Object();

	public SyncTemplateService(PBSyncRequest request) {
		this.request = request;
	}
	
	/**
	 * 
	 * @return
	 * @throws IOException
	 */
	public PBServiceState processSyncRequest() throws IOException {
		StopWatch t = new StopWatch();		
		t.start();
		PBSyncJobRequest synJobRequest = request.getSyncJobRequest();
		boolean haveExtractPayload = request.hasExtractInputPayload();
		boolean hasTemplate = synJobRequest.hasTemplate();
		PBServiceState pBServiceState = null;
		SyncResultWithStatus syncResultWithStatus = new SyncResultWithStatus();		
		DataSource ds = DataBaseUtil.lookupDataSource();
		JdbcTemplate jdbcTemplate = new JdbcTemplate(ds);
		SyncFunctionType function = synJobRequest.getFunction();
		if (!function.name().equals(SyncFunctionType.DELETE.name())) {
			if (!haveExtractPayload && !hasTemplate) {
				String errMsg = "There are no template and no ExtractInputPayload! one of them is required.";
				logger.error(errMsg);
				if (function.name().equals(SyncFunctionType.INSERT.name())) {
					pBServiceState = ProtobufUtil.buildFaildPBServiceState(ErrorDifinitions.SYNC_INSERT_REQUEST_NO_TEMPLATE_NO_EXTRACT_PAYLOAD, null, null, null);
				} else if (function.name().equals(SyncFunctionType.UPDATE.name())) {
					pBServiceState = ProtobufUtil.buildFaildPBServiceState(ErrorDifinitions.SYNC_UPDATE_REQUEST_NO_TEMPLATE_NO_EXTRACT_PAYLOAD, null, null, null);
				}
				return pBServiceState;				
			}			
		} else {
			if(haveExtractPayload) {
				String errMsg = "Have a extract template in delete template request.";
				logger.error(errMsg);
				pBServiceState = ProtobufUtil.buildFaildPBServiceState(ErrorDifinitions.SYNC_DELETE_REQUEST_HAVE_EXTRACT_PAYLOAD, null, null, null);
				return pBServiceState;
			}
		}

		if (haveExtractPayload) {
			PBExtractJobResult extractJobResult = doUpdateWithExtract();
			if (extractJobResult != null && extractJobResult.getServiceState().getState().name().equals(ServiceStateType.SERVICE_STATE_SUCCESS.name())) {
				logger.info("Get extract job results is sucessed. results size .");
				byte[] byteTemplate = extractJobResult.getTemplate().toByteArray();
				PBSyncJobRequest.Builder syncRequest = null;
				try {
					syncRequest = PBSyncJobRequest.newBuilder();
					syncRequest.mergeFrom(request.getSyncJobRequest());
					syncRequest.setTemplate(ByteString.copyFrom(byteTemplate));					
				} catch (Exception e) {
					logger.info(e.getMessage(), e.getMessage());					
				}
				logger.info("Extract is sucess. will go to update template....");
				syncResultWithStatus = doUpdateWithTemplete(jdbcTemplate, syncRequest.build());				
			} else {
				if (extractJobResult == null) {
					pBServiceState = ProtobufUtil.buildFaildPBServiceState(ErrorDifinitions.EXTRACT_RESULT_EMPTY, null, null, null);
					syncResultWithStatus.setpBServiceState(pBServiceState);
				} else {
					syncResultWithStatus.setpBServiceState(extractJobResult.getServiceState());	
				}			
			}
		} else {
			syncResultWithStatus = doUpdateWithTemplete(jdbcTemplate, synJobRequest);
		}
		if (syncResultWithStatus.getpBServiceState() == null) {
			PBServiceState.Builder oKServiceState = PBServiceState.newBuilder();
			oKServiceState.setState(ServiceStateType.SERVICE_STATE_SUCCESS);
			pBServiceState = oKServiceState.build();
		} else {
			pBServiceState = syncResultWithStatus.getpBServiceState();
		}
		t.stop();
		PerformanceLogger.trace(getClass().getSimpleName(), "processSyncRequest", null, null,  t.elapsedTime());
		t = null;
		return pBServiceState;
	}

	private PBExtractJobResult doUpdateWithExtract() {
		ExtractService extractService = new ExtractService(request.toByteArray(), PostCardType.sync);
		return extractService.doExtract();
	}

	private SyncResultWithStatus doUpdateWithTemplete(JdbcTemplate jdbcTemplate, PBSyncJobRequest synJobRequest) {
		logger.info("MMr will go to update template to DB....");
		String dbName = AIMrManger.getInstance().getDB_DRIVER().toUpperCase();
		SyncFunctionType function = synJobRequest.getFunction();
		Integer eventId = null;
		if (function.name().equals(SyncFunctionType.INSERT.name())) {
			eventId = synJobRequest.hasEventId() ? Integer.valueOf(synJobRequest.getEventId()) : 0;
		} else {
			eventId = synJobRequest.hasEventId() ? Integer.valueOf(synJobRequest.getEventId()) : null;
		}		
		AIMrTemplatesDao syncDao = null;
		if (dbName.equals("POSTGRESQL")) {
			syncDao = new AIMrTemplatesPostgresDaoImp(jdbcTemplate);
		} else {
			syncDao = new AIMrTemplatesDaoImp(jdbcTemplate);
		}		
		Integer containerId = Integer.valueOf(synJobRequest.getContainerId());
		String ExternalId = synJobRequest.getExternalId();
		byte[] templates = synJobRequest.getTemplate().toByteArray();	
		
		SyncResultWithStatus syncResultWithStatus  = null;	
		synchronized(locker) {
			if (function.getNumber() == 1) {
				syncResultWithStatus = syncDao.insertTemplate(containerId, ExternalId, eventId, templates);
			} else if (function.getNumber() == 2) {
				syncResultWithStatus = syncDao.deleteTemplate(containerId, ExternalId, eventId);
			} else if (function.getNumber() == 3) {
				syncResultWithStatus = syncDao.updateTemplate(containerId, ExternalId, eventId, templates);
			}
		}
		
		PBContainerSyncRequest syncData = syncResultWithStatus.getpBContainerSyncRequest();
		Long syncJobId = Long.valueOf(SequenceIdCreator.createNextSequence(SequenceIdType.SYNC_TEMPLATE_ID));	
		if (syncResultWithStatus.getpBServiceState() == null 
			&& syncResultWithStatus.getpBContainerSyncRequest() != null) {
			EventNotifier.getInstance().fireOnSyncTemplates(syncJobId, syncData);
		} else {
			logger.warn("No sync data to send to mu, skip...");
		}		
		syncDao = null;
		return syncResultWithStatus;
	}
}
