package jp.co.nec.aimr.persistence.aimdb;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import jp.co.nec.aimr.common.UnitStatus;
import jp.co.nec.aimr.management.AIMrManger;

public class AimUnitsDaoImp implements AimUnitsDao {
	private JdbcTemplate jdbcTemplate;
	private String DB_NAME;

	public AimUnitsDaoImp(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
		this.DB_NAME = AIMrManger.getInstance().getDB_DRIVER();
		DB_NAME = DB_NAME.toUpperCase();
	}

	@Override
	public boolean updateAimUnit(Long unitId, String status) throws DataAccessException {
		boolean updateOk;
		String updateSql = null;
		switch (DB_NAME) {
		case "ORACLE":		
		case "MYSQL":
			updateSql = "UPDATE AIM_UNITS SET STATUS = ? WHERE UNIT_ID = ?";
			break;
		case "POSTGRESQL":
			updateSql = "UPDATE \"AIM_UNITS\" SET \"STATUS\" = ? WHERE \"UNIT_ID\" = ?";
			break;
		case "SQLSERVER":	
			break;
		default:
			break;
		}	
	
		int updated = jdbcTemplate.update(updateSql, new Object[] { status, unitId });		
		if (updated == 1) {
			updateOk = true;
		} else {
			updateOk = false;
		}		
		return updateOk;
	}

	@Override
	public boolean deleteAimUnit(Long unitId) throws DataAccessException {
		boolean deleteOk;
		String deleteSql = null;
		switch (DB_NAME) {
		case "ORACLE":		
		case "MYSQL":
			deleteSql = "DELETE AIM_UNITS WHERE UNIT_ID = ?";
			break;
		case "POSTGRESQL":
			deleteSql = "DELETE \"AIM_UNITS\" WHERE \"UNIT_ID\" = ?";
			break;
		case "SQLSERVER":	
			break;
		default:
			break;
		}		
		
		int deleted = jdbcTemplate.update(deleteSql, new Object[] { unitId });
		if (deleted == 1) {
			deleteOk = true;
		} else {
			deleteOk = false;
		}		
		return deleteOk;
	}

	@Override
	public List<Map<String, Object>> getUnitEligibleContainers(Integer unitId) throws DataAccessException {	
		String getUnitEligbleContainerSql = null;
		switch (DB_NAME) {
		case "ORACLE":		
		case "MYSQL":
			getUnitEligbleContainerSql = ""
					+ "SELECT CS.CONTAINER_ID,CS.CONTAINER_TABLE_NAME, CS.MODALITY,CS.ALGORITHM,CS.TEMPLATE_SIZE,CS.VERSION,CS.RECORD_COUNT, CS.MAX_RECORD_COUNT,CS.VERSION "
					+ "FROM CONTAINERS CS, MU_ELIGIBLE_CONTAINERS MS "
					+ "WHERE MS.CONTAINER_ID = CS.CONTAINER_ID";
			break;
		case "POSTGRESQL":
			getUnitEligbleContainerSql = ""
					+ "SELECT CS.\"CONTAINER_ID\",CS.\"CONTAINER_TABLE_NAME\", CS.\"MODALITY\",CS.\"ALGORITHM\",CS.\"TEMPLATE_SIZE\",CS.\"VERSION\",CS.\"RECORD_COUNT\", CS.\"MAX_RECORD_COUNT\",CS.\"VERSION\" "
					+ "FROM \"CONTAINERS\" CS, \"MU_ELIGIBLE_CONTAINERS\" MS "
					+ "WHERE MS.\"CONTAINER_ID\" = CS.\"CONTAINER_ID\"";			
			break;
		case "SQLSERVER":	
			break;
		default:
			break;
		}

		List<Map<String, Object>> results = jdbcTemplate.queryForList(getUnitEligbleContainerSql);		
		return results;
	}

	@Override
	public List<ContainerInfo> getAllContainerInfo() throws DataAccessException {
		String getAllContainerSql = null;	
		switch (DB_NAME) {
		case "ORACLE":		
		case "MYSQL":
			getAllContainerSql = "SELECT * FROM CONTAINERS";	
			break;
		case "POSTGRESQL":
			getAllContainerSql = "SELECT * FROM \"CONTAINERS\"";
			break;
		case "SQLSERVER":	
			break;
		default:
			break;
		}
				
		RowMapper<ContainerInfo> mapper = new ContainerMapper();
		List<ContainerInfo> results = jdbcTemplate.query(getAllContainerSql, mapper);		
		return results;
	}

	
	private static class ContainerMapper implements RowMapper<ContainerInfo> {
		@Override
		public ContainerInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
			ContainerInfo info = new ContainerInfo();
			info.setContainerId(rs.getInt("CONTAINER_ID"));
			info.setPersonBiTtableName(rs.getString("CONTAINER_TABLE_NAME"));
			info.setConatainerLogTableName(rs.getString("CONTAINER_LOG_TABLE_NAME"));
			info.setModality(rs.getString("MODALITY"));
			info.setAlgorithm(rs.getString("ALGORITHM"));
			info.setTemplateSize(rs.getInt("TEMPLATE_SIZE"));
			info.setMaxRecordCount(rs.getLong("MAX_RECORD_COUNT"));
			info.setRecordCount(rs.getInt("RECORD_COUNT"));
			info.setVersion(rs.getInt("VERSION"));
			return info;
		}
	}

	@Override
	public int insertMuEligibleContainers(final Long muId) throws DataAccessException {	
		String sql = null;
		switch (DB_NAME) {
		case "ORACLE":		
		case "MYSQL":
			sql = "INSERT INTO MU_ELIGIBLE_CONTAINERS(MU_ID, CONTAINER_ID) VALUES (?,?)";
			break;
		case "POSTGRESQL":
			sql = "INSERT INTO \"MU_ELIGIBLE_CONTAINERS\"(\"MU_ID\", \"CONTAINER_ID\") VALUES (?,?)";
			break;
		case "SQLSERVER":	
			break;
		default:
			break;
		}		
		final List<Integer> containerKeys = AIMrManger.getContainerKeys();		
		int[] results = jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setLong(1, muId);
				ps.setInt(2, containerKeys.get(i));
			}
			@Override
			public int getBatchSize() {				
				return containerKeys.size();
			}
		});		
		return results.length;
	}

	@Override
	public void commit() {		
		jdbcTemplate.execute("COMMIT");		
	}

	@Override
	public void rollback() {		
		jdbcTemplate.execute("ROLLBACK");		
	}

	@Override
	public boolean insertAimUnit(long unitId, int type, String uniqueId, String status) throws DataAccessException {		
		String insertSql = null;
		switch (DB_NAME) {
		case "ORACLE":		
		case "MYSQL":
		insertSql = "INSERT INTO AIM_UNITS (UNIT_ID, UNIT_TYPE, UNIQUE_ID, STATUS) VALUES(?,?,?,?)";
			break;
		case "POSTGRESQL":
			insertSql = "INSERT INTO \"AIM_UNITS\" (\"UNIT_ID\", \"UNIT_TYPE\", \"UNIQUE_ID\", \"STATUS\") VALUES(?,?,?,?)";
			break;
		case "SQLSERVER":	
			break;
		default:
			break;
		}		
		int result = jdbcTemplate.update(insertSql, new Object[] { unitId, type, uniqueId, status });
		return result == 1 ? true : false;
	}

	@Override
	public AimUnits getUnitUsingUrlAndPort(String uniqueKey) throws DataAccessException {		
		String selectSql = null;
		switch (DB_NAME) {
		case "ORACLE":		
		case "MYSQL":
			selectSql = "SELECT UNIT_ID,UNIT_TYPE, UNIQUE_ID, STATUS FROM AIM_UNITS WHERE UNIQUE_ID = ?";
			break;
		case "POSTGRESQL":
			selectSql = "SELECT \"UNIT_ID\",\"UNIT_TYPE\", \"UNIQUE_ID\", \"STATUS\" FROM \"AIM_UNITS\" WHERE \"UNIQUE_ID\" = ?";
			break;
		case "SQLSERVER":	
			break;
		default:
			break;
		}		
		try {
			AimUnits result = jdbcTemplate.queryForObject(selectSql, new Object[] { uniqueKey }, new RowMapper<AimUnits>() {
				@Override
				public AimUnits mapRow(ResultSet rs, int rowNum) throws SQLException {
					AimUnits unit = new AimUnits();
					unit.setUnitId(rs.getLong("UNIT_ID"));
					unit.setUnitType(rs.getInt("UNIT_TYPE"));
					unit.setUniqueId(rs.getString("UNIQUE_ID"));
					unit.setUnitStatus(UnitStatus.valueOf(rs.getString("STATUS")));
					return unit;
				}
			});
			return result;

		} catch (Exception e) {
			return null;
		}

	}

	@Override
	public boolean setUnitStatus(Long unitId, String status) throws DataAccessException {
		boolean updateOk;	
		String updateSql = null;
		switch (DB_NAME) {
		case "ORACLE":		
		case "MYSQL":
			updateSql = "UPDATE AIM_UNITS SET STATUS = ? WHERE UNIT_ID = ?";
			break;
		case "POSTGRESQL":
			updateSql = "UPDATE \"AIM_UNITS\" SET \"STATUS\" = ? WHERE \"UNIT_ID\" = ?";
			break;
		case "SQLSERVER":	
			break;
		default:
			break;
		}
		
		int updated = jdbcTemplate.update(updateSql, new Object[] { status, unitId });
		if (updated == 1) {
			updateOk = true;
		} else {
			updateOk = false;
		}		
		return updateOk;
	}

	@Override
	public boolean removeAimUnit(String uniqueKey) throws DataAccessException {
		String deleteSql = null;
		boolean deleteOk;	
		switch (DB_NAME) {
		case "ORACLE":		
		case "MYSQL":
			deleteSql = "DELETE FROM  AIM_UNITS WHERE UNIQUE_ID=?";
			break;
		case "POSTGRESQL":
			deleteSql = "DELETE FROM  \"AIM_UNITS\" WHERE \"UNIQUE_ID\"=?";
			break;
		case "SQLSERVER":	
			break;
		default:
			break;
		}		
		int deleted = jdbcTemplate.update(deleteSql, new Object[] { uniqueKey });
		if (deleted == 1) {
			deleteOk = true;
		} else {
			deleteOk = false;
		}		
		return deleteOk;
	}
}
