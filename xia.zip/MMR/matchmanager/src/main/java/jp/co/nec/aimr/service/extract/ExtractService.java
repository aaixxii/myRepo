package jp.co.nec.aimr.service.extract;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractJobResult;
import jp.co.nec.aimr.common.ErrorDifinitions;
import jp.co.nec.aimr.common.JobState;
import jp.co.nec.aimr.common.PostCardType;
import jp.co.nec.aimr.common.ProtobufUtil;
import jp.co.nec.aimr.common.SequenceIdCreator;
import jp.co.nec.aimr.common.SequenceIdType;
import jp.co.nec.aimr.common.SocketMessageUtil;
import jp.co.nec.aimr.common.StopWatch;
import jp.co.nec.aimr.event.EventNotifier;
import jp.co.nec.aimr.exception.NoActiveUnitException;
import jp.co.nec.aimr.exception.PropertyFileException;
import jp.co.nec.aimr.logging.PerformanceLogger;
import jp.co.nec.aimr.management.MMrJobManager;
import jp.co.nec.aimr.properties.PropertyNames;
import jp.co.nec.aimr.properties.PropertyUtil;

/**
 * 
 * @author xiazp
 * ExtractService process extract request and creating response 
 */
public class ExtractService {

	private static Logger logger = LoggerFactory.getLogger(ExtractService.class);
	private PostCardType postCardType;
	private byte[] parentRequst;

	public ExtractService(byte[] parentRequst, PostCardType postCardType) {
		this.parentRequst = parentRequst;
		this.postCardType = postCardType;
	}

	/**
	 * 
	 * @return
	 */
	public PBExtractJobResult doExtract() {
		StopWatch t = new StopWatch();		
		t.start();
		logger.info("Start to proccess extract job...");
		int extractJobWaitTime = PropertyUtil.getInstance().getPropertyIntValue(PropertyNames.MMR_GET_EXTRACT_JOB_RESULTS_WAITTIME_LIMIT.name());		
		long startSaveExtJobQueueTime = System.currentTimeMillis();
		Object extractJoblocker = new Object();		
		Long extractJobId = Long.valueOf(SequenceIdCreator.createNextSequence(SequenceIdType.EXTEACT_ID));		
		byte[] postCard = SocketMessageUtil.createPostCardMessage(postCardType.name());
		ExtractJob extractJob = new ExtractJob(extractJobId, parentRequst, postCard);
		ExtractJobStatus extractJobStatus = new ExtractJobStatus();
		extractJobStatus.setExtJobId(extractJobId);
		extractJobStatus.setExtJobStatus(JobState.QUEUED);		
		
		MMrJobManager.saveExtractJobLocker(extractJobId, extractJoblocker);		
		MMrJobManager.saveExtractJobStatus(extractJobId, extractJobStatus);	
		MMrJobManager.saveExtractJobjob(extractJobId, extractJob);	
		long endSaveJobQueueTime = System.currentTimeMillis();
		logger.info("*****MMr save to extact job({}) queue used time = {}****", extractJobId,  endSaveJobQueueTime - startSaveExtJobQueueTime);
		
		PBExtractJobResult extJobResult = null;
		try {
			EventNotifier.getInstance().fireOnExtractJobqueueing(extractJobId);	
		} catch (Exception e) {
			MMrJobManager.finishExtractJob(extractJobId);
			logger.error(e.getMessage(), e);
			if (e instanceof NoActiveUnitException) {				
				extJobResult = ProtobufUtil.buildRollbackPBExtractJobResult(ErrorDifinitions.EXTRACT_JOB_NO_ACTIVE_EU, null, null, null);
			} else if (e instanceof PropertyFileException){
				extJobResult = ProtobufUtil.buildRollbackPBExtractJobResult(ErrorDifinitions.PROPERTY_FILE_READ_FAILD, null, null, null);
			} else {
				extJobResult = ProtobufUtil.buildRollbackPBExtractJobResult(ErrorDifinitions.AIM_PROCESS_UNKNOWN, null, null, null);
			}
			return extJobResult;
		}
		
		synchronized (extractJoblocker) {
			long startGetExtResultTime = System.currentTimeMillis();
			logger.info("Go to waiting  job results!");
			try {
				extractJoblocker.wait(extractJobWaitTime);
			} catch (InterruptedException e) {
				logger.error(e.getMessage(), e);
				Thread.currentThread().interrupt();
			}			
			extJobResult = MMrJobManager.getOneExtJobResult(extractJobId);
			if (extJobResult != null) {
				logger.info("Get job({}) result success", extractJobId);
				long endGetResultTime = System.currentTimeMillis();
				logger.info("*****MMr get job results used time = {}****",
						endGetResultTime - startGetExtResultTime);				
			} else {
				long currentTime = System.currentTimeMillis();			
				if (currentTime -  startGetExtResultTime >= extractJobWaitTime) {
					logger.warn(
							"Timeout is happend! the waiting time = ({}), jobId({})",
							currentTime - startGetExtResultTime, extractJobId);
	
					MMrJobManager.changeExtractJobstatus(extractJobId, JobState.TIMEOUT);
					extJobResult = ProtobufUtil.buildRollbackPBExtractJobResult(ErrorDifinitions.EXTRACT_JOB_TIMEOUT, null, null, null);
				} 
			}			
			MMrJobManager.finishExtractJob(extractJobId);			
		}
		t.stop();
		PerformanceLogger.trace(getClass().getSimpleName(), "doExtract", null, extractJobId, t.elapsedTime());
		t = null;
		return extJobResult;
	}
}
