package jp.co.nec.aimr.management;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractJobResult;
import jp.co.nec.aim.message.proto.InquiryService.PBIdentifyResponse;
import jp.co.nec.aim.message.proto.InquiryService.PBVerifyResponse;
import jp.co.nec.aimr.common.JobState;
import jp.co.nec.aimr.service.extract.ExtractJob;
import jp.co.nec.aimr.service.extract.ExtractJobStatus;
import jp.co.nec.aimr.service.inquiry.InquiryJob;
import jp.co.nec.aimr.service.inquiry.InquiryJobStatus;
import jp.co.nec.aimr.service.verity.VerifyJob;
import jp.co.nec.aimr.service.verity.VerifyJobStatus;

/**
 * @author xiazp
 * InquiryJobManager manage jobs status
 */
public class MMrJobManager {

	private static final ConcurrentHashMap<Long, InquiryJob> inquiryJobQueue = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<Long, ExtractJob> extractJobQueue = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<Long, VerifyJob> verifyJobQueue = new ConcurrentHashMap<>();

	private static final ConcurrentHashMap<Long, PBIdentifyResponse> inquiryJobResultsQueue = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<Long, PBExtractJobResult> extractJobResultsQueue = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<Long, PBVerifyResponse> verifyJobResultsQueue = new ConcurrentHashMap<>();

	private static final ConcurrentHashMap<Long, Object> inquiryJobLockerQueue = new ConcurrentHashMap<>(); //key is jobId used get job result
	private static final ConcurrentHashMap<Long, Object> extractJobLockerQueue = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<Long, Object> verifyJobLockerQueue = new ConcurrentHashMap<>();	

	private static final ConcurrentHashMap<Long, InquiryJobStatus> inquiryJobStatusMap = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<Long, ExtractJobStatus> extractJobStatusMap = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<Long, VerifyJobStatus> verifyJobStatusMap = new ConcurrentHashMap<>();
	
	private static final Object inquiryJobQueueLocker = new Object();
	private static final Object extractJobQueueLocker = new Object();
	private static final Object verifyJobQueueLocker = new Object();
	
	private static final Object inquiryJobResultsQueueLocker = new Object();
	private static final Object extractJobResultsQueueLocker = new Object();
	private static final Object verifyJobResultsQueueLocker = new Object();
	
	private static final Object inquiryJobLockerQueueLocker = new Object();
	private static final Object extractJobLockerQueueLocker = new Object();
	private static final Object verifyJobLockerQueueLocker = new Object();
	
	private static final Object inquiryJobStatusMapLocker = new Object();
	private static final Object extractJobStatusMapLocker = new Object();
	private static final Object verifyJobStatusMapLocker = new Object();
	
	
	public static ConcurrentHashMap<Long, InquiryJob> getInquiryjobqueue() {
		synchronized(inquiryJobQueueLocker) {
			return inquiryJobQueue;	
		}		
	}	

	public static ConcurrentHashMap<Long, ExtractJob> getExtractjobqueue() {
		synchronized(extractJobQueueLocker){
			return extractJobQueue;	
		}		
	}

	public static ConcurrentHashMap<Long, VerifyJob> getVerifyjobqueue() {
		 synchronized(verifyJobQueueLocker){
			 return verifyJobQueue;
		 }		
	}

	public static ConcurrentHashMap<Long, Object> getVerifyjoblockerqueue() {
		 synchronized(verifyJobLockerQueueLocker){
			 return verifyJobLockerQueue;
		 }		
	}

	public static ConcurrentHashMap<Long, InquiryJobStatus> getInquiryjobstatusmap() {
		 synchronized(inquiryJobStatusMapLocker){
			 return inquiryJobStatusMap;
		 }		
	}

	public static ConcurrentHashMap<Long, ExtractJobStatus> getExtractjobstatusmap() {
		 synchronized(extractJobStatusMapLocker){
			 return extractJobStatusMap;
		 }		
	}

	public static ConcurrentHashMap<Long, VerifyJobStatus> getVerifyjobstatusmap() {
		 synchronized(verifyJobStatusMapLocker){
			 return verifyJobStatusMap;
		 }		
	}

	public static ConcurrentHashMap<Long, Object> getInquiryjoblockerqueue() {
		 synchronized(inquiryJobLockerQueueLocker){
			 return inquiryJobLockerQueue; 
		 }		
	}		

	public static ConcurrentHashMap<Long, Object> getExtractjoblockerqueue() {
		 synchronized(extractJobLockerQueueLocker){
			 return extractJobLockerQueue;
		 }		
	}
	
	/**
	 * @return
	 */
	public static ConcurrentHashMap<Long, PBIdentifyResponse> getInquiryjobresultsqueue() {
		 synchronized(inquiryJobResultsQueueLocker){
			 return inquiryJobResultsQueue;
		 }		
	}

	public static ConcurrentHashMap<Long, PBVerifyResponse> getVerifyjobresultsqueue() {
		 synchronized(verifyJobResultsQueueLocker){
			 return verifyJobResultsQueue; 
		 }		
	}

	public static ConcurrentHashMap<Long, PBExtractJobResult> getExtractjobresultsqueue() {
		 synchronized(extractJobResultsQueueLocker){
			 return extractJobResultsQueue; 
		 }		
	}

	private static Logger logger = LoggerFactory.getLogger(MMrJobManager.class);

	public MMrJobManager() {
	}

	/**
	 * @param status
	 */
	public static void saveInqjobstatus(Long inquiryJobId, InquiryJobStatus status) {
		getInquiryjobstatusmap().put(inquiryJobId, status);
	}

	public static void saveVerifyJobstatus(Long verifyJobId, VerifyJobStatus status) {
		getVerifyjobstatusmap().put(verifyJobId, status);
	}

	public static void saveExtractJobstatus(Long extractJobId, ExtractJobStatus status) {
		getExtractjobstatusmap().put(extractJobId, status);
	}

	public static void changeInquiryJobstatus(Long inquiryJobId, JobState jobState) {
		if (getInquiryjobstatusmap().get(inquiryJobId) != null) {
			getInquiryjobstatusmap().get(inquiryJobId).setInqJobStatus(jobState);
		} else {
			logger.error("The requied inquiryJobId({}) is not exists in inquiryJobStatusMap!", inquiryJobId);
		}
	}

	public static void changeVerifyJobstatus(Long verifyJobId, JobState jobState) {
		if (getVerifyjobstatusmap().get(verifyJobId) != null) {
			getVerifyjobstatusmap().get(verifyJobId).setVerifyJobStates(jobState);
		} else {
			logger.error("The requied verifyJobId({}) is not exists in verifyJobStatusMap!", verifyJobId);
		}
	}

	public static void changeExtractJobstatus(Long extractJobId, JobState jobState) {
		if (getExtractjobstatusmap().get(extractJobId) != null) {
			getExtractjobstatusmap().get(extractJobId).setExtJobStatus(jobState);
		} else {
			logger.error("The requied extract JobId({}) is not exists in extractJobStatusMap!", extractJobId);
		}
	}

	/**
	 * @param jobId
	 * @param inquiryJobReq
	 */
	public static void saveInquiryjob(Long jobId, InquiryJob inquiryJobReq) {
		getInquiryjobqueue().put(jobId, inquiryJobReq);
	}

	public static void saveVerifyjob(Long jobId, VerifyJob verifyJob) {
		getVerifyjobqueue().put(jobId, verifyJob);
	}

	public static void saveExtractJobjob(Long jobId, ExtractJob extractJob) {	
		getExtractjobqueue().put(jobId, extractJob);
		logger.info("Successed to save extract job({}) request to queue", jobId);
	}

	/**
	 * @param jobId
	 * @return
	 */
	public static InquiryJob getInquiryjob(Long jobId) {		
		return getInquiryjobqueue().get(jobId);
	}

	public static VerifyJob getVerifyjob(Long jobId) {
		return getVerifyjobqueue().get(jobId);
	}
	
	public static ExtractJob getExtractjob(Long jobId) {
		return getExtractjobqueue().get(jobId);
	}	

	public static boolean checkInqJobIsReulstedOrFinished(Long inquiryJobId) {
		if ((getInquiryjob(inquiryJobId) == null && getInquiryJobLocker(inquiryJobId) == null) 
				 || getInquiryjobresultsqueue().get(inquiryJobId) != null) {
				return true;
			} else {
				return false;
			}
	}

	public static boolean checkVerifyJobIsReulstedOrFinished(Long verifyJobId) {
		if ((getVerifyjob(verifyJobId) == null && getExtractJobLocker(verifyJobId) == null) 
				 || getVerifyjobresultsqueue().get(verifyJobId) != null) {
				return true;
			} else {
				return false;
			}		
	}
	
	public static boolean checkExtractJobIsReulstedOrFinished(Long extractJobId) {
		if ((getExtractjob(extractJobId) == null && getExtractJobLocker(extractJobId) == null) 
			 || getExtractjobresultsqueue().get(extractJobId) != null) {
			return true;
		} else {
			return false;
		}		
	}

	/**
	 * @param batchJobId
	 * @return
	 */
	public static InquiryJob fetchOneInquiryJob(Long inquiryJobId) {
		InquiryJob inqJob = null;
		JobState status = getInquiryJobStatus(inquiryJobId);
		if (status != null && status.name().equals(JobState.QUEUED.name())) {
			inqJob = getInquiryjobqueue().get(inquiryJobId);
		}
		if (inqJob != null) {
			MMrJobManager.setInquiryJobStatus(inquiryJobId,JobState.ASSIGNED);
		}
		return inqJob;
	}

	public static VerifyJob fetchOneVerifyJob(Long verifyJobId) {
		VerifyJob verifyJob = null;
		JobState status = getVerifyJobStatus(verifyJobId);
		if (status != null && status.name().equals(JobState.QUEUED.name())) {
			verifyJob = getVerifyjobqueue().get(verifyJobId);
		}
		if (verifyJob != null) {
			MMrJobManager.setVerifyJobStatus(verifyJobId,JobState.ASSIGNED);					
		}
		return verifyJob;
	}

	public static ExtractJob fetchOneExtractJob(Long extractJobId) {
		ExtractJob extractJob = null;
		JobState status = getExtractJobStatus(extractJobId);		
		if (status != null && status.name().equals(JobState.QUEUED.name())) {
			extractJob = getExtractjobqueue().get(extractJobId);
		}	
		if (extractJob != null) {
			MMrJobManager.setExtractJobStatus(extractJobId,JobState.ASSIGNED);					
		}
		return extractJob;
	}

	/**
	 * @return
	 */
	public static InquiryJob fetchOneInquiryJob() {		
		if (getInquiryjobqueue().size() < 1) {
			return null;
		}
		InquiryJob inqJob = null;
		Map<Long, InquiryJob> sortedInqJobQueue = new TreeMap<Long, InquiryJob>(getInquiryjobqueue());
		Set<Entry<Long, InquiryJob>> entrySet = sortedInqJobQueue.entrySet();
		Iterator<Entry<Long, InquiryJob>> it = entrySet.iterator();
		while (it.hasNext()) {
			Entry<Long, InquiryJob> tmp = it.next();
			 inqJob = tmp.getValue();
			JobState state = getInquiryJobStatus(Long.valueOf(inqJob.getJobId()));
			 if (state != null && state.equals(JobState.QUEUED)) {
				 MMrJobManager.setInquiryJobStatus(Long.valueOf(inqJob.getJobId()),JobState.ASSIGNED);
				 return inqJob;
			 }
		}
		return null;	
	}

	public static VerifyJob fetchOneVerifyJob() {
		if (getVerifyjobqueue().size() < 1) {
			return null;
		}		
		VerifyJob verifyJob = null;
		Map<Long, VerifyJob> sortedVerifyJobQueue = new TreeMap<Long, VerifyJob>(getVerifyjobqueue());
		Set<Entry<Long, VerifyJob>> entrySet = sortedVerifyJobQueue.entrySet();
		Iterator<Entry<Long, VerifyJob>> it = entrySet.iterator();
		while (it.hasNext()) {
			Entry<Long, VerifyJob> tmp = it.next();
			verifyJob = tmp.getValue();
			JobState state = getVerifyJobStatus(Long.valueOf(verifyJob.getVerifyJobId()));
			 if (state != null && state.equals(JobState.QUEUED)) {
				 MMrJobManager.setVerifyJobStatus(Long.valueOf(verifyJob.getVerifyJobId()),JobState.ASSIGNED);
				 return verifyJob;
			 }
		}
		return null;	
	}

	public static ExtractJob fetchOneExtractJob() {
		if (getExtractjobqueue().size() < 1) {
			return null;
		}
		ExtractJob extJob = null;
		Map<Long, ExtractJob> sortedExtractQueue = new TreeMap<Long, ExtractJob>(getExtractjobqueue());
		Set<Entry<Long, ExtractJob>> entrySet = sortedExtractQueue.entrySet();
		Iterator<Entry<Long, ExtractJob>> it = entrySet.iterator();
		while (it.hasNext()) {
			Entry<Long, ExtractJob> tmp = it.next();
			extJob = tmp.getValue();
			JobState state = getExtractJobStatus(Long.valueOf(extJob.getExJobId()));
			 if (state != null && state.equals(JobState.QUEUED)) {
				 MMrJobManager.setVerifyJobStatus(Long.valueOf(extJob.getExJobId()),JobState.ASSIGNED);
				 return extJob;
			 }
		}
		return null;	
	}

	/**
	 * @param jobId
	 * @return
	 */
	public static JobState getInquiryJobStatus(Long jobId) {
		InquiryJobStatus state = getInquiryjobstatusmap().get(jobId);
		if (state != null && state.getInqJobStatus() != null) {
			return state.getInqJobStatus();
		} else {
			return null;
		}
	}

	public static JobState getVerifyJobStatus(Long jobId) {
		VerifyJobStatus state = getVerifyjobstatusmap().get(jobId);
		if (state != null && state.getVerifyJobStates() != null) {
			return state.getVerifyJobStates();
		} else {
			return null;
		}
	}
	
	public static JobState getExtractJobStatus(Long jobId) {
		 ExtractJobStatus state = getExtractjobstatusmap().get(jobId);
		if (state != null && state.getExtJobStatus() != null) {
			return state.getExtJobStatus();
		} else {
			return null;
		}
	}



	/**
	 * @param batchJobId
	 * @param jobSet
	 */
	public static void saveInquiryJobStatus(Long inquiryJobId, InquiryJobStatus jobStatus) {
		getInquiryjobstatusmap().put(inquiryJobId, jobStatus);
	}

	public static void saveExtractJobStatus(Long extractJobId, ExtractJobStatus jobStatus) {
		getExtractjobstatusmap().put(extractJobId, jobStatus);
	}
	
	public static void saveVerifyJobStatus(Long verifyJobId, VerifyJobStatus jobStatus) {
		getVerifyjobstatusmap().put(verifyJobId, jobStatus);
	}

	/**
	 * @param batchJobid
	 */
	public static void finishIdentifyJob(Long inquiryJobid) {
		getInquiryjobqueue().remove(inquiryJobid);
		getInquiryjobresultsqueue().remove(inquiryJobid);
		getInquiryjoblockerqueue().remove(inquiryJobid);
		getInquiryjobstatusmap().remove(inquiryJobid);	
		logger.debug("IdentifyJob({}) has been removed from queues", inquiryJobid);
	}

	public static void finishVerifyJob(Long verifyJobid) {
		getVerifyjobqueue().remove(verifyJobid);
		getVerifyjobresultsqueue().remove(verifyJobid);
		getVerifyjoblockerqueue().remove(verifyJobid);
		getVerifyjobstatusmap().remove(verifyJobid);
		logger.debug("VerifyJob({}) has been removed from queues", verifyJobid);
	}

	public static void finishExtractJob(Long extJobId) {
		getExtractjobqueue().remove(extJobId);
		getExtractjobresultsqueue().remove(extJobId);
		getExtractjoblockerqueue().remove(extJobId);
		getExtractjobstatusmap().remove(extJobId);	
		logger.debug("ExtractJob({}) has been removed from queues", extJobId);
	}

	/**
	 * @param jobId
	 * @param state
	 */
	public static void setInquiryJobStatus(Long jobId, JobState state) {
		InquiryJobStatus status = getInquiryjobstatusmap().get(jobId);
		if (status != null) {
			 status.setInqJobStatus(state);
		}
	}

	public static void setVerifyJobStatus(Long jobId, JobState state) {
		VerifyJobStatus status = getVerifyjobstatusmap().get(jobId);
		if (status != null) {
			status.setVerifyJobStates(state);
		}
	}

	public static void setExtractJobStatus(Long jobId, JobState state) {
		ExtractJobStatus status = getExtractjobstatusmap().get(jobId);
		if (status != null) {
			status.setExtJobStatus(state);
		}
	}

	public static PBIdentifyResponse getOneInqJobResult(Long inqJobId) {
		return getInquiryjobresultsqueue().get(inqJobId);
	}

	public static PBVerifyResponse getOneVerifyJobResult(Long verifyJobId) {
		return getVerifyjobresultsqueue().get(verifyJobId);
	}

	public static PBExtractJobResult getOneExtJobResult(Long extJobId) {
		return getExtractjobresultsqueue().get(extJobId);
	}

	/**
	 * @param jobId
	 * @param jobResult
	 */
	public static void saveInquiryJobResult(Long jobId, PBIdentifyResponse jobResult) {
		Object locker = getInquiryjoblockerqueue().get(jobId);
		synchronized (locker) {
			logger.info("Save inquiry job({}) results to queue", jobId);
			getInquiryjobresultsqueue().put(jobId, jobResult);
			locker.notify();
		}
	}

	public static void saveVerifyJobResult(Long jobId, PBVerifyResponse jobResult) {
		Object locker = getVerifyjoblockerqueue().get(jobId);
		synchronized (locker) {
			logger.info("Save verify job({}) results to queue", jobId);
			verifyJobResultsQueue.put(jobId, jobResult);
			locker.notify();
		}
	}

	public static void saveExtractJobResult(Long jobId, PBExtractJobResult jobResult) {
		Object locker = getExtractjoblockerqueue().get(jobId);
		synchronized (locker) {			
			logger.info("Save extract job({}) results to queue", jobId);
			getExtractjobresultsqueue().put(jobId, jobResult);
			locker.notify();
		}
	}

	/**
	 * @param inqJobId
	 * @return
	 */
	public static Object getInquiryJobLocker(Long inqJobId) {
		return getInquiryjoblockerqueue().get(inqJobId);
	}

	public static Object getVerifyJobLocker(Long verifyJobId) {
		return getVerifyjoblockerqueue().get(verifyJobId);
	}
	
	public static Object getExtractJobLocker(Long extractJobId) {
		return getExtractjoblockerqueue().get(extractJobId);
	}

	/**
	 * @param inquryJobId
	 * @param locker
	 */
	public static void saveInquiryJobLocker(Long inquryJobId, Object locker) {
		getInquiryjoblockerqueue().put(inquryJobId, locker);
	}

	public static void saveVerifyJobLocker(Long verifyJobId, Object locker) {
		getVerifyjoblockerqueue().put(verifyJobId, locker);
	}

	public static void saveExtractJobLocker(Long extJobId, Object locker) {
		getExtractjoblockerqueue().put(extJobId, locker);

	}

	/**
	 * @param inquryJobId
	 */
	public static void removeInquiryJobLocker(Long inquryJobId) {
		getInquiryjoblockerqueue().remove(inquryJobId);
	}

	public static void removeVerifyJobLocker(Long verifyJobId) {
		getVerifyjoblockerqueue().remove(verifyJobId);
	}

	public static void removeExtractJobLocker(Long extJobId) {
		getExtractjoblockerqueue().remove(extJobId);
	}	
}
