package jp.co.nec.aimr.service.template;

public class CatchUpInfo {
	private Integer conatanerId;
	private Integer version;
	private String command;
	private byte[] templates;
	private String ensternalId;
	private Integer evnetId;

	public Integer getConatanerId() {
		return conatanerId;
	}

	public void setConatanerId(Integer conatanerId) {
		this.conatanerId = conatanerId;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public String getCommand() {
		return command;
	}

	public void setCommand(String command) {
		this.command = command;
	}

	public byte[] getTemplates() {
		return templates;
	}

	public void setTemplates(byte[] templates) {
		this.templates = templates;
	}

	public String getEnsternalId() {
		return ensternalId;
	}

	public void setEnsternalId(String ensternalId) {
		this.ensternalId = ensternalId;
	}

	public Integer getEvnetId() {
		return evnetId;
	}

	public void setEvnetId(Integer evnetId) {
		this.evnetId = evnetId;
	}
}
