package jp.co.nec.aimr.persistence.aimdb;

import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import jp.co.nec.aimr.management.AIMrManger;

public class MuUsedContainerDaoImp implements MuUsedContainerDao {
	private JdbcTemplate jdbcTemplate;
	private String DB_NAME;

	public MuUsedContainerDaoImp(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
		DB_NAME = AIMrManger.getInstance().getDB_DRIVER();
		DB_NAME = DB_NAME.toUpperCase();
	}

	@Override
	public List<ContainerInfo> getMuEligibleContainerInfo(Long muId) throws DataAccessException {	
		String sql = null;
		switch (DB_NAME) {
		case "ORACLE":		
		case "MYSQL":
		case "SQLSERVER":
			sql = ""
					+ "SELECT CS.CONTAINER_ID, CS.CONTAINER_TABLE_NAME,CS.CONTAINER_LOG_TABLE_NAME,CS.ALGORITHM, "
					+ "CS.MODALITY,CS.MAX_RECORD_COUNT,CS.RECORD_COUNT,CS.TEMPLATE_SIZE,CS.VERSION "
					+ "FROM  MU_ELIGIBLE_CONTAINERS ME, CONTAINERS CS "
					+ "WHERE ME.CONTAINER_ID = CS.CONTAINER_ID "
					+ "AND ME.MU_ID = ? "
					+ "AND EXISTS "
					+ " (SELECT AU.UNIT_ID FROM AIM_UNITS AU " + "   WHERE AU.UNIT_ID = ME.MU_ID " + ")";			
			break;
			
		case "POSTGRESQL":
			sql = ""
					+ "SELECT CS.\"CONTAINER_ID\", CS.\"CONTAINER_TABLE_NAME\",CS.\"CONTAINER_LOG_TABLE_NAME\",CS.\"ALGORITHM\", "
					+ "CS.\"MODALITY\",CS.\"MAX_RECORD_COUNT\",CS.\"RECORD_COUNT\",CS.\"TEMPLATE_SIZE\",CS.\"VERSION\" "
					+ "FROM  \"MU_ELIGIBLE_CONTAINERS\" ME, \"CONTAINERS\" CS "
					+ "WHERE ME.\"CONTAINER_ID\" = CS.\"CONTAINER_ID\" "
					+ "AND ME.\"MU_ID\" = ? "
					+ "AND EXISTS "
					+ " (SELECT AU.\"UNIT_ID\" FROM \"AIM_UNITS\" AU " + "   WHERE AU.\"UNIT_ID\" = ME.\"MU_ID\" " + ")";
			break;
		default:
			break;
		
		}

		List<ContainerInfo> reuslts = jdbcTemplate.query(sql, new Object[] { muId }, new ContainerCursorMapper());
		return reuslts;
	}
}
