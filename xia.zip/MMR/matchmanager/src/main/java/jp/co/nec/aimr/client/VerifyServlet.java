package jp.co.nec.aimr.client;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.aim.message.proto.InquiryService.PBVerifyRequest;
import jp.co.nec.aim.message.proto.InquiryService.PBVerifyResponse;
import jp.co.nec.aimr.common.StopWatch;
import jp.co.nec.aimr.logging.PerformanceLogger;
import jp.co.nec.aimr.service.verity.VerityService;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author xiazp <br/>
 * VerityServlet response to verify request from client <br/>
 */
@WebServlet(name = "VerityServlet", urlPatterns = { "/AIMInquiryService/verify" })
public class VerifyServlet extends BaseServlet {
	private static final long serialVersionUID = 4486939581016399636L;
	private static final String VERIFY_URL_PATTERN = "/AIMInquiryService/verify";

	private static Logger logger = LoggerFactory.getLogger(VerifyServlet.class);

	public void init() throws ServletException {
	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		StopWatch t = new StopWatch();		
		t.start();

		final String url = req.getRequestURL().toString().toLowerCase();
		logger.info("Received servlet request! form URL", url);
		if (url.endsWith((VERIFY_URL_PATTERN.toLowerCase()))) {
			doVerity(req, res);
		} else {
			doNoSuport(req, res, NOT_SUPPORT_METHOD);
		}

		t.stop();
		logger.info("MMr server used {} ms to process verity request.", t.elapsedTime());
		PerformanceLogger.trace(getClass().getSimpleName(), "doPost", null, null, t.elapsedTime());
		t = null;
	}

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		final String url = req.getRequestURL().toString().toLowerCase();
		if (url.endsWith(VERIFY_URL_PATTERN.toLowerCase())) {
			doNoSuport(req, res, "verity with get is not supported");
		} else {
			final String unknownMsg = String.format(NOT_SUPPORT_METHOD, "unknown");
			logger.error(unknownMsg);
			writeErrorToResponse(req, res, HttpStatus.SC_BAD_REQUEST, unknownMsg, null);
			return;
		}
	}

	private void doVerity(final HttpServletRequest req, final HttpServletResponse res) throws IOException {
		if (isContextSizeEmpty(req)) {
			writeErrorToResponse(req, res, HttpStatus.SC_BAD_REQUEST, EMPTY_REQUEST_MSG, null);
			return;
		}		
		logger.debug("ready to deSerial from inputStream..");
		
		PBVerifyRequest request = null;
		try {
			request = PBVerifyRequest.parseFrom(req.getInputStream());
		} catch (Exception ex) {
			writeErrorToResponse(req, res, HttpStatus.SC_BAD_REQUEST, ex.getMessage(), ex);
			return;
		}		
		logger.debug("ready to call verity with parameter PBVerifyRequests...");
		
		PBVerifyResponse clientResp = null;
		VerityService verityService = new VerityService(request);
		try {
			clientResp = verityService.processVerityRequest();
			logger.info("MMR return result is success = {}", clientResp != null);
			if (clientResp == null) {
				String errMsg = " The verify job results is empty!";
				writeErrorToResponse(req, res, HttpStatus.SC_INTERNAL_SERVER_ERROR, errMsg, null);
				return;
			}

		} catch (Exception ex) {
			String errMsg = "Internal exception is accored!";
			writeErrorToResponse(req, res, HttpStatus.SC_INTERNAL_SERVER_ERROR, errMsg, ex);
		}		
		logger.debug("ready to Serial the BVerifyResponses and write into outputstream..");		
		clientResp.writeTo(res.getOutputStream());
		res.setStatus(HttpStatus.SC_OK);
		logger.info("Success to send verity job respose to client. Http status = {}", HttpStatus.SC_OK);
		verityService = null;
	}

	public void destroy() {
	}
}
