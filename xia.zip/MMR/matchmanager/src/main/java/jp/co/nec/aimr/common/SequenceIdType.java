package jp.co.nec.aimr.common;

public enum SequenceIdType {
	VERIFY_JOB_ID(0),//
	SYNC_TEMPLATE_ID(1),//
	INQUIRY_ID(2),//
	EXTEACT_ID(3),//
	UNIT_ID(4);


	private long val;
	

	private SequenceIdType(long val) {
		this.val = val;
	}

	public long getVal() {
		return val;
	}

}
