package jp.co.nec.aimr.persistence.aimdb;

import java.util.List;

import org.springframework.dao.DataAccessException;

public interface ContainersDao {
	public List<ContainerInfo> getAllContainerInfo() throws DataAccessException;
}
