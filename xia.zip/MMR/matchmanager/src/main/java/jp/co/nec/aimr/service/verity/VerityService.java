package jp.co.nec.aimr.service.verity;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBVerifyDataInfo;
import jp.co.nec.aim.message.proto.InquiryPayloads.PBVerifyJobInput;
import jp.co.nec.aim.message.proto.InquiryService.PBVerifyRequest;
import jp.co.nec.aim.message.proto.InquiryService.PBVerifyResponse;
import jp.co.nec.aimr.common.ErrorDifinitions;
import jp.co.nec.aimr.common.JobState;
import jp.co.nec.aimr.common.ProtobufUtil;
import jp.co.nec.aimr.common.SequenceIdCreator;
import jp.co.nec.aimr.common.SequenceIdType;
import jp.co.nec.aimr.common.StopWatch;
import jp.co.nec.aimr.event.EventNotifier;
import jp.co.nec.aimr.exception.NoActiveUnitException;
import jp.co.nec.aimr.exception.PropertyFileException;
import jp.co.nec.aimr.logging.PerformanceLogger;
import jp.co.nec.aimr.management.MMrJobManager;
import jp.co.nec.aimr.properties.PropertyNames;
import jp.co.nec.aimr.properties.PropertyUtil;

/**
 * 
 * @author xiazp
 * VerityService send verify request to eu and result from it.
 */
public class VerityService {
	private PBVerifyRequest verifyRequest;
	private static Logger logger = LoggerFactory.getLogger(VerityService.class);

	public VerityService(PBVerifyRequest request) {
		this.verifyRequest = request;
	}

	/**
	 * 
	 * @return
	 */
	public PBVerifyResponse processVerityRequest() {
		StopWatch t = new StopWatch();		
		t.start();		
		logger.info("Start to proccess client identify requist...");
		PBVerifyResponse pBVerifyResponse = null;
		long startProccessTime = System.currentTimeMillis();
		PBVerifyJobInput pBVerifyJobInput = verifyRequest.getJobInput();

		if (!pBVerifyJobInput.getQuery().hasTemplate() && !pBVerifyJobInput.getQuery().hasImage()) {
			logger.error(ErrorDifinitions.VERIFY_NO_IMAGE_AND_NO_TEMPLATE.toString());
			pBVerifyResponse = buildFaildPBVerifyResponse(ErrorDifinitions.VERIFY_NO_IMAGE_AND_NO_TEMPLATE);
			return pBVerifyResponse;
		}
		if (pBVerifyJobInput.getTargetCount() == 0) {
			logger.error(ErrorDifinitions.VERIFY_TARGET_IS_NULL.toString());
			pBVerifyResponse = buildFaildPBVerifyResponse(ErrorDifinitions.VERIFY_TARGET_IS_NULL);
			return pBVerifyResponse;
		}

		List<PBVerifyDataInfo> targetList = pBVerifyJobInput.getTargetList();
		for (PBVerifyDataInfo target : targetList) {
			if (!target.hasImage() && !target.hasTemplate() && !target.hasKey()) {
				logger.error(ErrorDifinitions.VERIFY_TARGET_NO_IMAGE_AND_NO_TEMPLATE_NO_KEY.toString());
				pBVerifyResponse = buildFaildPBVerifyResponse(ErrorDifinitions.VERIFY_TARGET_NO_IMAGE_AND_NO_TEMPLATE_NO_KEY);
				return pBVerifyResponse;
			}
		}
		pBVerifyResponse = doVerify();
		if (pBVerifyResponse == null) {
			pBVerifyResponse = buildFaildPBVerifyResponse(ErrorDifinitions.VERIFY_RESULT_EMPTY);
		} 
		long endProccessTime = System.currentTimeMillis();
		logger.info("proccess client requist used time {}", endProccessTime - startProccessTime);
		t.stop();
		PerformanceLogger.trace(getClass().getSimpleName(), "processVerityRequest", null, null, t.elapsedTime());
		t = null;
		return pBVerifyResponse;
	}

	private PBVerifyResponse buildFaildPBVerifyResponse(ErrorDifinitions errorDifinition) {
		PBVerifyResponse.Builder verifyRespose = PBVerifyResponse.newBuilder();
		PBServiceState errState = ProtobufUtil.buildFaildPBServiceState(errorDifinition, null, null, null);
		verifyRespose.setServiceState(errState);
		return verifyRespose.build();
	}

	private PBVerifyResponse doVerify() {
		logger.debug("Start to proccess verify job...");
		StopWatch t = new StopWatch();
		t.start();
		int verifyJobWaitTime = PropertyUtil.getInstance().getPropertyIntValue(PropertyNames.MMR_GET_VERIFY_JOB_RESULTS_WAITTIME_LIMIT.name());
		long startSaveInqJobQueueTime = System.currentTimeMillis();
		Object verifyJoblocker = new Object();		
		Long verifyJobId = Long.valueOf(SequenceIdCreator.createNextSequence(SequenceIdType.VERIFY_JOB_ID));	
		MMrJobManager.saveVerifyJobLocker(verifyJobId, verifyJoblocker);		
		VerifyJobStatus verifyJobStatus = new VerifyJobStatus();
		verifyJobStatus.setVerifyJobId(verifyJobId);
		verifyJobStatus.setVerifyJobStates(JobState.QUEUED);
		VerifyJob verifyJob = new VerifyJob(verifyJobId, verifyRequest.toByteArray());
				
		MMrJobManager.saveVerifyJobstatus(verifyJobId, verifyJobStatus);
		MMrJobManager.saveVerifyjob(verifyJobId, verifyJob);
		
		long endSaveJobQueueTime = System.currentTimeMillis();
		logger.info("*****MMr save to verify job queue used time = {}****", endSaveJobQueueTime - startSaveInqJobQueueTime);
		
		PBVerifyResponse toBeGetResult = null;
		try {
			EventNotifier.getInstance().fireOnVerifyJobqueueing(verifyJobId);		
		} catch (Exception e) {
			MMrJobManager.finishVerifyJob(verifyJobId);
			logger.error(e.getMessage(), e);
			if (e instanceof NoActiveUnitException) {				
				toBeGetResult = ProtobufUtil.buildRollbackPBVerifyResponse(ErrorDifinitions.VERIFY_JOB_NO_ACTIVE_EU, null, null, null);				
			} else if (e instanceof PropertyFileException) {				
				toBeGetResult = ProtobufUtil.buildRollbackPBVerifyResponse(ErrorDifinitions.PROPERTY_FILE_READ_FAILD, null, null, null);								
			} else {
				toBeGetResult = ProtobufUtil.buildRollbackPBVerifyResponse(ErrorDifinitions.AIM_PROCESS_UNKNOWN, null, null, null);
			}			
			return toBeGetResult;
		}
		
		synchronized (verifyJoblocker) {
			long startGetResultTime = System.currentTimeMillis();
			logger.info("Go to waiting  verify job results!");
			try {
				verifyJoblocker.wait(verifyJobWaitTime);
			} catch (InterruptedException e) {
				logger.error(e.getMessage(), e);				
			}
			toBeGetResult = MMrJobManager.getOneVerifyJobResult(verifyJobId);
			if (toBeGetResult != null) {
				logger.info("Get verify job({}) result success", verifyJobId);
			} else  {
				long currentTime = System.currentTimeMillis();
				if (currentTime -  startGetResultTime >= verifyJobWaitTime) {
					logger.warn(
							"Timeout is happend! the waiting time = ({}), jobId({})",
							currentTime - startGetResultTime, verifyJobId);
					MMrJobManager.changeVerifyJobstatus(verifyJobId, JobState.TIMEOUT);
					toBeGetResult = ProtobufUtil.buildRollbackPBVerifyResponse(ErrorDifinitions.VERIFY_JOB_TIMEOUT, null, null, null);					
				}
			}
			long endGetResultTime = System.currentTimeMillis();
			logger.info("*****MMr get verify job results used time = {}****",
					endGetResultTime - startGetResultTime);
		}
		MMrJobManager.finishVerifyJob(verifyJobId);		
		t.stop();
		PerformanceLogger.trace(getClass().getSimpleName(), "doVerify", null, null, t.elapsedTime());
		return toBeGetResult;
	}
}
