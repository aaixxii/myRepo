
spool build_aim.log

WHENEVER OSERROR  EXIT FAILURE;
WHENEVER SQLERROR EXIT SQL.SQLCODE;

prompt
prompt Creating AIM database objects...
prompt

prompt Creating tables ...
@@ddl/create_tab.sql

prompt Creating constraints ...
@@ddl/create_con.sql

prompt Creating indexes ...
@@ddl/create_idx.sql

prompt Creating AIM Containers ...
@@ddl/create_pb_and_pb_log.sql

prompt
prompt Populating AIM seed data...
prompt

@@seed/seed.sql

prompt
prompt Checking for any invalid objects after installation...
prompt
SELECT Count(*) as "Number of invalid objects" FROM user_objects WHERE status != 'VALID';

prompt
prompt DONE.
prompt

exit success;




