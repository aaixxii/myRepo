
set serveroutput on

DECLARE
    l_container_id      NUMBER;
    l_modality          VARCHAR2(128 BYTE) := 'FINGER(10)';
    l_algorithm         VARCHAR2(128 BYTE) := 'CML';
    l_template_size     NUMBER := 20608;
    l_verseion          NUMBER := 0;
    l_record_count      NUMBER := 0;
    l_max_record_count  NUMBER := 10;
    l_last_bio_id       NUMBER := 0;

    l_pb_tab_name       VARCHAR2(128 BYTE);
    l_pb_pk_name        VARCHAR2(128 BYTE);
    l_pb_uidx_name      VARCHAR2(128 BYTE);
    l_pb_log_tab_name   VARCHAR2(128 BYTE);
    l_pb_log_pk_name    VARCHAR2(128 BYTE);
    l_pb_log_uidx_name  VARCHAR2(128 BYTE);
    l_pb_secfile_name   VARCHAR2(128 BYTE);
BEGIN

    SELECT NVL(MAX(CONTAINER_ID), 0)+1 INTO l_container_id FROM CONTAINERS;

    l_pb_tab_name       := 'PERSON_BIOMETRICS_' || l_container_id;
    l_pb_pk_name        := 'PERSON_BIOMETRICS_' || l_container_id || '_PK';
    l_pb_uidx_name      := 'PERSON_BIOMETRICS_' || l_container_id || '_UIDX1';
    l_pb_log_tab_name   := 'PERSON_BIO_CHANGE_LOG_' || l_container_id;
    l_pb_log_pk_name    := 'PERSON_BIO_CHANGE_LOG_' || l_container_id || '_PK';
    l_pb_log_uidx_name  := 'PERSON_BIO_CHANGE_LOG_' || l_container_id || '_UIDX1';
    l_pb_secfile_name   := 'PERSON_BIO_' || l_container_id || '_LOB_DATA_SEC';

    EXECUTE IMMEDIATE '
CREATE TABLE ' || l_pb_tab_name || '
(
    BIOMETRICS_ID         NUMBER(38)  NOT NULL ,
    USER_KEY              VARCHAR2(64 BYTE)  NOT NULL ,
    USER_EVENT_ID         NUMBER(8)  NOT NULL ,
    BIOMETRICS_DATA       BLOB  NOT NULL ,
    BIOMETRICS_DATA_LEN   NUMBER(16)  NOT NULL ,
    REGISTERED_TS         VARCHAR2(32) NOT NULL ,
    CONSTRAINT ' || l_pb_pk_name || ' PRIMARY KEY (BIOMETRICS_ID) USING INDEX(
        CREATE UNIQUE INDEX ' || l_pb_pk_name || ' ON ' || l_pb_tab_name || ' (BIOMETRICS_ID ASC)
        PCTFREE    10
        INITRANS   20
        MAXTRANS   255
        STORAGE (
            INITIAL          64M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
        )
        TABLESPACE AIM_BIOMETRICS_DATA
    )
)
    LOB (BIOMETRICS_DATA) STORE AS SECUREFILE ' || l_pb_secfile_name || ' (
    TABLESPACE AIM_BIOMETRICS_LOB_DATA
    ENABLE      STORAGE IN ROW
    CHUNK       8192
    RETENTION   AUTO
    NOCACHE
    LOGGING
    STORAGE(
        INITIAL 64M
        MINEXTENTS 1
        MAXEXTENTS UNLIMITED
        PCTINCREASE 0
        BUFFER_POOL DEFAULT
    )
) TABLESPACE AIM_BIOMETRICS_DATA';


EXECUTE IMMEDIATE '
CREATE TABLE ' || l_pb_log_tab_name || '
(
    CHANGE_ID             NUMBER(38)  NOT NULL ,
    BIOMETRICS_ID         NUMBER(38)  NOT NULL ,
    USER_KEY              VARCHAR2(64 BYTE)  NOT NULL ,
    USER_EVENT_ID         NUMBER(8)  NOT NULL ,
    VERSION               NUMBER(38)  NOT NULL ,
    CHANGE_TYPE           NUMBER(4)  NOT NULL , 
    CONSTRAINT ' || l_pb_log_pk_name || ' PRIMARY KEY (CHANGE_ID) USING INDEX(
        CREATE UNIQUE INDEX ' || l_pb_log_pk_name || ' ON ' || l_pb_log_tab_name || ' (CHANGE_ID ASC)
        PCTFREE    10
        INITRANS   20
        MAXTRANS   255
        STORAGE (
            INITIAL          64M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
        )
        TABLESPACE AIM_SYSTEM_DATA
    )
)';


    INSERT INTO "CONTAINERS" (
        CONTAINER_ID,
        CONTAINER_TABLE_NAME,
        CONTAINER_LOG_TABLE_NAME,
        MODALITY,
        ALGORITHM,
        TEMPLATE_SIZE,
        VERSION,
        RECORD_COUNT,
        MAX_RECORD_COUNT,
        LAST_ENROLLED_BIO_ID)
    values (
        l_container_id,
        l_pb_tab_name,
        l_pb_log_tab_name,
        l_modality,
        l_algorithm,
        l_template_size,
        l_verseion,
        l_record_count,
        l_max_record_count,
        l_last_bio_id
    );

EXECUTE IMMEDIATE '
ALTER TABLE ' || l_pb_tab_name || '
ADD CONSTRAINT ' || l_pb_uidx_name || ' UNIQUE (USER_KEY, USER_EVENT_ID)';

END;
/


set serveroutput on

DECLARE
    l_container_id      NUMBER;
    l_modality          VARCHAR2(128 BYTE) := 'FACE';
    l_algorithm         VARCHAR2(128 BYTE) := 'S17';
    l_template_size     NUMBER := 5248;
    l_verseion          NUMBER := 0;
    l_record_count      NUMBER := 0;
    l_max_record_count  NUMBER := 10;
    l_last_bio_id       NUMBER := 0;

    l_pb_tab_name       VARCHAR2(128 BYTE);
    l_pb_pk_name        VARCHAR2(128 BYTE);
    l_pb_uidx_name      VARCHAR2(128 BYTE);
    l_pb_log_tab_name   VARCHAR2(128 BYTE);
    l_pb_log_pk_name    VARCHAR2(128 BYTE);
    l_pb_log_uidx_name  VARCHAR2(128 BYTE);
    l_pb_secfile_name   VARCHAR2(128 BYTE);
BEGIN

    SELECT NVL(MAX(CONTAINER_ID), 0)+1 INTO l_container_id FROM CONTAINERS;

    l_pb_tab_name       := 'PERSON_BIOMETRICS_' || l_container_id;
    l_pb_pk_name        := 'PERSON_BIOMETRICS_' || l_container_id || '_PK';
    l_pb_uidx_name      := 'PERSON_BIOMETRICS_' || l_container_id || '_UIDX1';
    l_pb_log_tab_name   := 'PERSON_BIO_CHANGE_LOG_' || l_container_id;
    l_pb_log_pk_name    := 'PERSON_BIO_CHANGE_LOG_' || l_container_id || '_PK';
    l_pb_log_uidx_name  := 'PERSON_BIO_CHANGE_LOG_' || l_container_id || '_UIDX1';
    l_pb_secfile_name   := 'PERSON_BIO_' || l_container_id || '_LOB_DATA_SEC';

    EXECUTE IMMEDIATE '
CREATE TABLE ' || l_pb_tab_name || '
(
    BIOMETRICS_ID         NUMBER(38)  NOT NULL ,
    USER_KEY              VARCHAR2(64 BYTE)  NOT NULL ,
    USER_EVENT_ID         NUMBER(8)  NOT NULL ,
    BIOMETRICS_DATA       BLOB  NOT NULL ,
    BIOMETRICS_DATA_LEN   NUMBER(16)  NOT NULL ,
    REGISTERED_TS         VARCHAR2(32) NOT NULL ,
    CONSTRAINT ' || l_pb_pk_name || ' PRIMARY KEY (BIOMETRICS_ID) USING INDEX(
        CREATE UNIQUE INDEX ' || l_pb_pk_name || ' ON ' || l_pb_tab_name || ' (BIOMETRICS_ID ASC)
        PCTFREE    10
        INITRANS   20
        MAXTRANS   255
        STORAGE (
            INITIAL          64M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
        )
        TABLESPACE AIM_BIOMETRICS_DATA
    )
)
    LOB (BIOMETRICS_DATA) STORE AS SECUREFILE ' || l_pb_secfile_name || ' (
    TABLESPACE AIM_BIOMETRICS_LOB_DATA
    ENABLE      STORAGE IN ROW
    CHUNK       8192
    RETENTION   AUTO
    NOCACHE
    LOGGING
    STORAGE(
        INITIAL 64M
        MINEXTENTS 1
        MAXEXTENTS UNLIMITED
        PCTINCREASE 0
        BUFFER_POOL DEFAULT
    )
) TABLESPACE AIM_BIOMETRICS_DATA';


EXECUTE IMMEDIATE '
CREATE TABLE ' || l_pb_log_tab_name || '
(
    CHANGE_ID             NUMBER(38)  NOT NULL ,
    BIOMETRICS_ID         NUMBER(38)  NOT NULL ,
    USER_KEY              VARCHAR2(64 BYTE)  NOT NULL ,
    USER_EVENT_ID         NUMBER(8)  NOT NULL ,
    VERSION               NUMBER(38)  NOT NULL ,
    CHANGE_TYPE           NUMBER(4)  NOT NULL , 
    CONSTRAINT ' || l_pb_log_pk_name || ' PRIMARY KEY (CHANGE_ID) USING INDEX(
        CREATE UNIQUE INDEX ' || l_pb_log_pk_name || ' ON ' || l_pb_log_tab_name || ' (CHANGE_ID ASC)
        PCTFREE    10
        INITRANS   20
        MAXTRANS   255
        STORAGE (
            INITIAL          64M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
        )
        TABLESPACE AIM_SYSTEM_DATA
    )
)';


    INSERT INTO "CONTAINERS" (
        CONTAINER_ID,
        CONTAINER_TABLE_NAME,
        CONTAINER_LOG_TABLE_NAME,
        MODALITY,
        ALGORITHM,
        TEMPLATE_SIZE,
        VERSION,
        RECORD_COUNT,
        MAX_RECORD_COUNT,
        LAST_ENROLLED_BIO_ID)
    values (
        l_container_id,
        l_pb_tab_name,
        l_pb_log_tab_name,
        l_modality,
        l_algorithm,
        l_template_size,
        l_verseion,
        l_record_count,
        l_max_record_count,
        l_last_bio_id
    );

EXECUTE IMMEDIATE '
ALTER TABLE ' || l_pb_tab_name || '
ADD CONSTRAINT ' || l_pb_uidx_name || ' UNIQUE (USER_KEY, USER_EVENT_ID)';

END;
/


set serveroutput on

DECLARE
    l_container_id      NUMBER;
    l_modality          VARCHAR2(128 BYTE) := 'FACE';
    l_algorithm         VARCHAR2(128 BYTE) := 'S14';
    l_template_size     NUMBER := 5248;
    l_verseion          NUMBER := 0;
    l_record_count      NUMBER := 0;
    l_max_record_count  NUMBER := 10;
    l_last_bio_id       NUMBER := 0;

    l_pb_tab_name       VARCHAR2(128 BYTE);
    l_pb_pk_name        VARCHAR2(128 BYTE);
    l_pb_uidx_name      VARCHAR2(128 BYTE);
    l_pb_log_tab_name   VARCHAR2(128 BYTE);
    l_pb_log_pk_name    VARCHAR2(128 BYTE);
    l_pb_log_uidx_name  VARCHAR2(128 BYTE);
    l_pb_secfile_name   VARCHAR2(128 BYTE);
BEGIN

    SELECT NVL(MAX(CONTAINER_ID), 0)+1 INTO l_container_id FROM CONTAINERS;

    l_pb_tab_name       := 'PERSON_BIOMETRICS_' || l_container_id;
    l_pb_pk_name        := 'PERSON_BIOMETRICS_' || l_container_id || '_PK';
    l_pb_uidx_name      := 'PERSON_BIOMETRICS_' || l_container_id || '_UIDX1';
    l_pb_log_tab_name   := 'PERSON_BIO_CHANGE_LOG_' || l_container_id;
    l_pb_log_pk_name    := 'PERSON_BIO_CHANGE_LOG_' || l_container_id || '_PK';
    l_pb_log_uidx_name  := 'PERSON_BIO_CHANGE_LOG_' || l_container_id || '_UIDX1';
    l_pb_secfile_name   := 'PERSON_BIO_' || l_container_id || '_LOB_DATA_SEC';

    EXECUTE IMMEDIATE '
CREATE TABLE ' || l_pb_tab_name || '
(
    BIOMETRICS_ID         NUMBER(38)  NOT NULL ,
    USER_KEY              VARCHAR2(64 BYTE)  NOT NULL ,
    USER_EVENT_ID         NUMBER(8)  NOT NULL ,
    BIOMETRICS_DATA       BLOB  NOT NULL ,
    BIOMETRICS_DATA_LEN   NUMBER(16)  NOT NULL ,
    REGISTERED_TS         VARCHAR2(32) NOT NULL ,
    CONSTRAINT ' || l_pb_pk_name || ' PRIMARY KEY (BIOMETRICS_ID) USING INDEX(
        CREATE UNIQUE INDEX ' || l_pb_pk_name || ' ON ' || l_pb_tab_name || ' (BIOMETRICS_ID ASC)
        PCTFREE    10
        INITRANS   20
        MAXTRANS   255
        STORAGE (
            INITIAL          64M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
        )
        TABLESPACE AIM_BIOMETRICS_DATA
    )
)
    LOB (BIOMETRICS_DATA) STORE AS SECUREFILE ' || l_pb_secfile_name || ' (
    TABLESPACE AIM_BIOMETRICS_LOB_DATA
    ENABLE      STORAGE IN ROW
    CHUNK       8192
    RETENTION   AUTO
    NOCACHE
    LOGGING
    STORAGE(
        INITIAL 64M
        MINEXTENTS 1
        MAXEXTENTS UNLIMITED
        PCTINCREASE 0
        BUFFER_POOL DEFAULT
    )
) TABLESPACE AIM_BIOMETRICS_DATA';


EXECUTE IMMEDIATE '
CREATE TABLE ' || l_pb_log_tab_name || '
(
    CHANGE_ID             NUMBER(38)  NOT NULL ,
    BIOMETRICS_ID         NUMBER(38)  NOT NULL ,
    USER_KEY              VARCHAR2(64 BYTE)  NOT NULL ,
    USER_EVENT_ID         NUMBER(8)  NOT NULL ,
    VERSION               NUMBER(38)  NOT NULL ,
    CHANGE_TYPE           NUMBER(4)  NOT NULL , 
    CONSTRAINT ' || l_pb_log_pk_name || ' PRIMARY KEY (CHANGE_ID) USING INDEX(
        CREATE UNIQUE INDEX ' || l_pb_log_pk_name || ' ON ' || l_pb_log_tab_name || ' (CHANGE_ID ASC)
        PCTFREE    10
        INITRANS   20
        MAXTRANS   255
        STORAGE (
            INITIAL          64M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
        )
        TABLESPACE AIM_SYSTEM_DATA
    )
)';


    INSERT INTO "CONTAINERS" (
        CONTAINER_ID,
        CONTAINER_TABLE_NAME,
        CONTAINER_LOG_TABLE_NAME,
        MODALITY,
        ALGORITHM,
        TEMPLATE_SIZE,
        VERSION,
        RECORD_COUNT,
        MAX_RECORD_COUNT,
        LAST_ENROLLED_BIO_ID)
    values (
        l_container_id,
        l_pb_tab_name,
        l_pb_log_tab_name,
        l_modality,
        l_algorithm,
        l_template_size,
        l_verseion,
        l_record_count,
        l_max_record_count,
        l_last_bio_id
    );

EXECUTE IMMEDIATE '
ALTER TABLE ' || l_pb_tab_name || '
ADD CONSTRAINT ' || l_pb_uidx_name || ' UNIQUE (USER_KEY, USER_EVENT_ID)';

END;
/


set serveroutput on

DECLARE
    l_container_id      NUMBER;
    l_modality          VARCHAR2(128 BYTE) := 'IRIS';
    l_algorithm         VARCHAR2(128 BYTE) := 'NIRIS';
    l_template_size     NUMBER := 6272;
    l_verseion          NUMBER := 0;
    l_record_count      NUMBER := 0;
    l_max_record_count  NUMBER := 10;
    l_last_bio_id       NUMBER := 0;

    l_pb_tab_name       VARCHAR2(128 BYTE);
    l_pb_pk_name        VARCHAR2(128 BYTE);
    l_pb_uidx_name      VARCHAR2(128 BYTE);
    l_pb_log_tab_name   VARCHAR2(128 BYTE);
    l_pb_log_pk_name    VARCHAR2(128 BYTE);
    l_pb_log_uidx_name  VARCHAR2(128 BYTE);
    l_pb_secfile_name   VARCHAR2(128 BYTE);
BEGIN

    SELECT NVL(MAX(CONTAINER_ID), 0)+1 INTO l_container_id FROM CONTAINERS;

    l_pb_tab_name       := 'PERSON_BIOMETRICS_' || l_container_id;
    l_pb_pk_name        := 'PERSON_BIOMETRICS_' || l_container_id || '_PK';
    l_pb_uidx_name      := 'PERSON_BIOMETRICS_' || l_container_id || '_UIDX1';
    l_pb_log_tab_name   := 'PERSON_BIO_CHANGE_LOG_' || l_container_id;
    l_pb_log_pk_name    := 'PERSON_BIO_CHANGE_LOG_' || l_container_id || '_PK';
    l_pb_log_uidx_name  := 'PERSON_BIO_CHANGE_LOG_' || l_container_id || '_UIDX1';
    l_pb_secfile_name   := 'PERSON_BIO_' || l_container_id || '_LOB_DATA_SEC';

    EXECUTE IMMEDIATE '
CREATE TABLE ' || l_pb_tab_name || '
(
    BIOMETRICS_ID         NUMBER(38)  NOT NULL ,
    USER_KEY              VARCHAR2(64 BYTE)  NOT NULL ,
    USER_EVENT_ID         NUMBER(8)  NOT NULL ,
    BIOMETRICS_DATA       BLOB  NOT NULL ,
    BIOMETRICS_DATA_LEN   NUMBER(16)  NOT NULL ,
    REGISTERED_TS         VARCHAR2(32) NOT NULL ,
    CONSTRAINT ' || l_pb_pk_name || ' PRIMARY KEY (BIOMETRICS_ID) USING INDEX(
        CREATE UNIQUE INDEX ' || l_pb_pk_name || ' ON ' || l_pb_tab_name || ' (BIOMETRICS_ID ASC)
        PCTFREE    10
        INITRANS   20
        MAXTRANS   255
        STORAGE (
            INITIAL          64M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
        )
        TABLESPACE AIM_BIOMETRICS_DATA
    )
)
    LOB (BIOMETRICS_DATA) STORE AS SECUREFILE ' || l_pb_secfile_name || ' (
    TABLESPACE AIM_BIOMETRICS_LOB_DATA
    ENABLE      STORAGE IN ROW
    CHUNK       8192
    RETENTION   AUTO
    NOCACHE
    LOGGING
    STORAGE(
        INITIAL 64M
        MINEXTENTS 1
        MAXEXTENTS UNLIMITED
        PCTINCREASE 0
        BUFFER_POOL DEFAULT
    )
) TABLESPACE AIM_BIOMETRICS_DATA';


EXECUTE IMMEDIATE '
CREATE TABLE ' || l_pb_log_tab_name || '
(
    CHANGE_ID             NUMBER(38)  NOT NULL ,
    BIOMETRICS_ID         NUMBER(38)  NOT NULL ,
    USER_KEY              VARCHAR2(64 BYTE)  NOT NULL ,
    USER_EVENT_ID         NUMBER(8)  NOT NULL ,
    VERSION               NUMBER(38)  NOT NULL ,
    CHANGE_TYPE           NUMBER(4)  NOT NULL , 
    CONSTRAINT ' || l_pb_log_pk_name || ' PRIMARY KEY (CHANGE_ID) USING INDEX(
        CREATE UNIQUE INDEX ' || l_pb_log_pk_name || ' ON ' || l_pb_log_tab_name || ' (CHANGE_ID ASC)
        PCTFREE    10
        INITRANS   20
        MAXTRANS   255
        STORAGE (
            INITIAL          64M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
        )
        TABLESPACE AIM_SYSTEM_DATA
    )
)';


    INSERT INTO "CONTAINERS" (
        CONTAINER_ID,
        CONTAINER_TABLE_NAME,
        CONTAINER_LOG_TABLE_NAME,
        MODALITY,
        ALGORITHM,
        TEMPLATE_SIZE,
        VERSION,
        RECORD_COUNT,
        MAX_RECORD_COUNT,
        LAST_ENROLLED_BIO_ID)
    values (
        l_container_id,
        l_pb_tab_name,
        l_pb_log_tab_name,
        l_modality,
        l_algorithm,
        l_template_size,
        l_verseion,
        l_record_count,
        l_max_record_count,
        l_last_bio_id
    );

EXECUTE IMMEDIATE '
ALTER TABLE ' || l_pb_tab_name || '
ADD CONSTRAINT ' || l_pb_uidx_name || ' UNIQUE (USER_KEY, USER_EVENT_ID)';

END;
/


set serveroutput on

DECLARE
    l_container_id      NUMBER;
    l_modality          VARCHAR2(128 BYTE) := 'IRIS';
    l_algorithm         VARCHAR2(128 BYTE) := 'NIRIS';
    l_template_size     NUMBER := 6272;
    l_verseion          NUMBER := 0;
    l_record_count      NUMBER := 0;
    l_max_record_count  NUMBER := 10;
    l_last_bio_id       NUMBER := 0;

    l_pb_tab_name       VARCHAR2(128 BYTE);
    l_pb_pk_name        VARCHAR2(128 BYTE);
    l_pb_uidx_name      VARCHAR2(128 BYTE);
    l_pb_log_tab_name   VARCHAR2(128 BYTE);
    l_pb_log_pk_name    VARCHAR2(128 BYTE);
    l_pb_log_uidx_name  VARCHAR2(128 BYTE);
    l_pb_secfile_name   VARCHAR2(128 BYTE);
BEGIN

    SELECT NVL(MAX(CONTAINER_ID), 0)+1 INTO l_container_id FROM CONTAINERS;

    l_pb_tab_name       := 'PERSON_BIOMETRICS_' || l_container_id;
    l_pb_pk_name        := 'PERSON_BIOMETRICS_' || l_container_id || '_PK';
    l_pb_uidx_name      := 'PERSON_BIOMETRICS_' || l_container_id || '_UIDX1';
    l_pb_log_tab_name   := 'PERSON_BIO_CHANGE_LOG_' || l_container_id;
    l_pb_log_pk_name    := 'PERSON_BIO_CHANGE_LOG_' || l_container_id || '_PK';
    l_pb_log_uidx_name  := 'PERSON_BIO_CHANGE_LOG_' || l_container_id || '_UIDX1';
    l_pb_secfile_name   := 'PERSON_BIO_' || l_container_id || '_LOB_DATA_SEC';

    EXECUTE IMMEDIATE '
CREATE TABLE ' || l_pb_tab_name || '
(
    BIOMETRICS_ID         NUMBER(38)  NOT NULL ,
    USER_KEY              VARCHAR2(64 BYTE)  NOT NULL ,
    USER_EVENT_ID         NUMBER(8)  NOT NULL ,
    BIOMETRICS_DATA       BLOB  NOT NULL ,
    BIOMETRICS_DATA_LEN   NUMBER(16)  NOT NULL ,
    REGISTERED_TS         VARCHAR2(32) NOT NULL ,
    CONSTRAINT ' || l_pb_pk_name || ' PRIMARY KEY (BIOMETRICS_ID) USING INDEX(
        CREATE UNIQUE INDEX ' || l_pb_pk_name || ' ON ' || l_pb_tab_name || ' (BIOMETRICS_ID ASC)
        PCTFREE    10
        INITRANS   20
        MAXTRANS   255
        STORAGE (
            INITIAL          64M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
        )
        TABLESPACE AIM_BIOMETRICS_DATA
    )
)
    LOB (BIOMETRICS_DATA) STORE AS SECUREFILE ' || l_pb_secfile_name || ' (
    TABLESPACE AIM_BIOMETRICS_LOB_DATA
    ENABLE      STORAGE IN ROW
    CHUNK       8192
    RETENTION   AUTO
    NOCACHE
    LOGGING
    STORAGE(
        INITIAL 64M
        MINEXTENTS 1
        MAXEXTENTS UNLIMITED
        PCTINCREASE 0
        BUFFER_POOL DEFAULT
    )
) TABLESPACE AIM_BIOMETRICS_DATA';


EXECUTE IMMEDIATE '
CREATE TABLE ' || l_pb_log_tab_name || '
(
    CHANGE_ID             NUMBER(38)  NOT NULL ,
    BIOMETRICS_ID         NUMBER(38)  NOT NULL ,
    USER_KEY              VARCHAR2(64 BYTE)  NOT NULL ,
    USER_EVENT_ID         NUMBER(8)  NOT NULL ,
    VERSION               NUMBER(38)  NOT NULL ,
    CHANGE_TYPE           NUMBER(4)  NOT NULL , 
    CONSTRAINT ' || l_pb_log_pk_name || ' PRIMARY KEY (CHANGE_ID) USING INDEX(
        CREATE UNIQUE INDEX ' || l_pb_log_pk_name || ' ON ' || l_pb_log_tab_name || ' (CHANGE_ID ASC)
        PCTFREE    10
        INITRANS   20
        MAXTRANS   255
        STORAGE (
            INITIAL          64M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
        )
        TABLESPACE AIM_SYSTEM_DATA
    )
)';


    INSERT INTO "CONTAINERS" (
        CONTAINER_ID,
        CONTAINER_TABLE_NAME,
        CONTAINER_LOG_TABLE_NAME,
        MODALITY,
        ALGORITHM,
        TEMPLATE_SIZE,
        VERSION,
        RECORD_COUNT,
        MAX_RECORD_COUNT,
        LAST_ENROLLED_BIO_ID)
    values (
        l_container_id,
        l_pb_tab_name,
        l_pb_log_tab_name,
        l_modality,
        l_algorithm,
        l_template_size,
        l_verseion,
        l_record_count,
        l_max_record_count,
        l_last_bio_id
    );

EXECUTE IMMEDIATE '
ALTER TABLE ' || l_pb_tab_name || '
ADD CONSTRAINT ' || l_pb_uidx_name || ' UNIQUE (USER_KEY, USER_EVENT_ID)';

END;
/


set serveroutput on

DECLARE
    l_container_id      NUMBER;
    l_modality          VARCHAR2(128 BYTE) := 'FACE+IRIS';
    l_algorithm         VARCHAR2(128 BYTE) := 'S17+NIRIS';
    l_template_size     NUMBER := 11392;
    l_verseion          NUMBER := 0;
    l_record_count      NUMBER := 0;
    l_max_record_count  NUMBER := 10;
    l_last_bio_id       NUMBER := 0;

    l_pb_tab_name       VARCHAR2(128 BYTE);
    l_pb_pk_name        VARCHAR2(128 BYTE);
    l_pb_uidx_name      VARCHAR2(128 BYTE);
    l_pb_log_tab_name   VARCHAR2(128 BYTE);
    l_pb_log_pk_name    VARCHAR2(128 BYTE);
    l_pb_log_uidx_name  VARCHAR2(128 BYTE);
    l_pb_secfile_name   VARCHAR2(128 BYTE);
BEGIN

    SELECT NVL(MAX(CONTAINER_ID), 0)+1 INTO l_container_id FROM CONTAINERS;

    l_pb_tab_name       := 'PERSON_BIOMETRICS_' || l_container_id;
    l_pb_pk_name        := 'PERSON_BIOMETRICS_' || l_container_id || '_PK';
    l_pb_uidx_name      := 'PERSON_BIOMETRICS_' || l_container_id || '_UIDX1';
    l_pb_log_tab_name   := 'PERSON_BIO_CHANGE_LOG_' || l_container_id;
    l_pb_log_pk_name    := 'PERSON_BIO_CHANGE_LOG_' || l_container_id || '_PK';
    l_pb_log_uidx_name  := 'PERSON_BIO_CHANGE_LOG_' || l_container_id || '_UIDX1';
    l_pb_secfile_name   := 'PERSON_BIO_' || l_container_id || '_LOB_DATA_SEC';

    EXECUTE IMMEDIATE '
CREATE TABLE ' || l_pb_tab_name || '
(
    BIOMETRICS_ID         NUMBER(38)  NOT NULL ,
    USER_KEY              VARCHAR2(64 BYTE)  NOT NULL ,
    USER_EVENT_ID         NUMBER(8)  NOT NULL ,
    BIOMETRICS_DATA       BLOB  NOT NULL ,
    BIOMETRICS_DATA_LEN   NUMBER(16)  NOT NULL ,
    REGISTERED_TS         VARCHAR2(32) NOT NULL ,
    CONSTRAINT ' || l_pb_pk_name || ' PRIMARY KEY (BIOMETRICS_ID) USING INDEX(
        CREATE UNIQUE INDEX ' || l_pb_pk_name || ' ON ' || l_pb_tab_name || ' (BIOMETRICS_ID ASC)
        PCTFREE    10
        INITRANS   20
        MAXTRANS   255
        STORAGE (
            INITIAL          64M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
        )
        TABLESPACE AIM_BIOMETRICS_DATA
    )
)
    LOB (BIOMETRICS_DATA) STORE AS SECUREFILE ' || l_pb_secfile_name || ' (
    TABLESPACE AIM_BIOMETRICS_LOB_DATA
    ENABLE      STORAGE IN ROW
    CHUNK       8192
    RETENTION   AUTO
    NOCACHE
    LOGGING
    STORAGE(
        INITIAL 64M
        MINEXTENTS 1
        MAXEXTENTS UNLIMITED
        PCTINCREASE 0
        BUFFER_POOL DEFAULT
    )
) TABLESPACE AIM_BIOMETRICS_DATA';


EXECUTE IMMEDIATE '
CREATE TABLE ' || l_pb_log_tab_name || '
(
    CHANGE_ID             NUMBER(38)  NOT NULL ,
    BIOMETRICS_ID         NUMBER(38)  NOT NULL ,
    USER_KEY              VARCHAR2(64 BYTE)  NOT NULL ,
    USER_EVENT_ID         NUMBER(8)  NOT NULL ,
    VERSION               NUMBER(38)  NOT NULL ,
    CHANGE_TYPE           NUMBER(4)  NOT NULL , 
    CONSTRAINT ' || l_pb_log_pk_name || ' PRIMARY KEY (CHANGE_ID) USING INDEX(
        CREATE UNIQUE INDEX ' || l_pb_log_pk_name || ' ON ' || l_pb_log_tab_name || ' (CHANGE_ID ASC)
        PCTFREE    10
        INITRANS   20
        MAXTRANS   255
        STORAGE (
            INITIAL          64M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
        )
        TABLESPACE AIM_SYSTEM_DATA
    )
)';


    INSERT INTO "CONTAINERS" (
        CONTAINER_ID,
        CONTAINER_TABLE_NAME,
        CONTAINER_LOG_TABLE_NAME,
        MODALITY,
        ALGORITHM,
        TEMPLATE_SIZE,
        VERSION,
        RECORD_COUNT,
        MAX_RECORD_COUNT,
        LAST_ENROLLED_BIO_ID)
    values (
        l_container_id,
        l_pb_tab_name,
        l_pb_log_tab_name,
        l_modality,
        l_algorithm,
        l_template_size,
        l_verseion,
        l_record_count,
        l_max_record_count,
        l_last_bio_id
    );

EXECUTE IMMEDIATE '
ALTER TABLE ' || l_pb_tab_name || '
ADD CONSTRAINT ' || l_pb_uidx_name || ' UNIQUE (USER_KEY, USER_EVENT_ID)';

END;
/


set serveroutput on

DECLARE
    l_container_id      NUMBER;
    l_modality          VARCHAR2(128 BYTE) := 'FINGER(10)+IRIS+FACE';
    l_algorithm         VARCHAR2(128 BYTE) := 'CML+NIRIS+S17';
    l_template_size     NUMBER := 31872;
    l_verseion          NUMBER := 0;
    l_record_count      NUMBER := 0;
    l_max_record_count  NUMBER := 10;
    l_last_bio_id       NUMBER := 0;

    l_pb_tab_name       VARCHAR2(128 BYTE);
    l_pb_pk_name        VARCHAR2(128 BYTE);
    l_pb_uidx_name      VARCHAR2(128 BYTE);
    l_pb_log_tab_name   VARCHAR2(128 BYTE);
    l_pb_log_pk_name    VARCHAR2(128 BYTE);
    l_pb_log_uidx_name  VARCHAR2(128 BYTE);
    l_pb_secfile_name   VARCHAR2(128 BYTE);
BEGIN

    SELECT NVL(MAX(CONTAINER_ID), 0)+1 INTO l_container_id FROM CONTAINERS;

    l_pb_tab_name       := 'PERSON_BIOMETRICS_' || l_container_id;
    l_pb_pk_name        := 'PERSON_BIOMETRICS_' || l_container_id || '_PK';
    l_pb_uidx_name      := 'PERSON_BIOMETRICS_' || l_container_id || '_UIDX1';
    l_pb_log_tab_name   := 'PERSON_BIO_CHANGE_LOG_' || l_container_id;
    l_pb_log_pk_name    := 'PERSON_BIO_CHANGE_LOG_' || l_container_id || '_PK';
    l_pb_log_uidx_name  := 'PERSON_BIO_CHANGE_LOG_' || l_container_id || '_UIDX1';
    l_pb_secfile_name   := 'PERSON_BIO_' || l_container_id || '_LOB_DATA_SEC';

    EXECUTE IMMEDIATE '
CREATE TABLE ' || l_pb_tab_name || '
(
    BIOMETRICS_ID         NUMBER(38)  NOT NULL ,
    USER_KEY              VARCHAR2(64 BYTE)  NOT NULL ,
    USER_EVENT_ID         NUMBER(8)  NOT NULL ,
    BIOMETRICS_DATA       BLOB  NOT NULL ,
    BIOMETRICS_DATA_LEN   NUMBER(16)  NOT NULL ,
    REGISTERED_TS         VARCHAR2(32) NOT NULL ,
    CONSTRAINT ' || l_pb_pk_name || ' PRIMARY KEY (BIOMETRICS_ID) USING INDEX(
        CREATE UNIQUE INDEX ' || l_pb_pk_name || ' ON ' || l_pb_tab_name || ' (BIOMETRICS_ID ASC)
        PCTFREE    10
        INITRANS   20
        MAXTRANS   255
        STORAGE (
            INITIAL          64M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
        )
        TABLESPACE AIM_BIOMETRICS_DATA
    )
)
    LOB (BIOMETRICS_DATA) STORE AS SECUREFILE ' || l_pb_secfile_name || ' (
    TABLESPACE AIM_BIOMETRICS_LOB_DATA
    ENABLE      STORAGE IN ROW
    CHUNK       8192
    RETENTION   AUTO
    NOCACHE
    LOGGING
    STORAGE(
        INITIAL 64M
        MINEXTENTS 1
        MAXEXTENTS UNLIMITED
        PCTINCREASE 0
        BUFFER_POOL DEFAULT
    )
) TABLESPACE AIM_BIOMETRICS_DATA';


EXECUTE IMMEDIATE '
CREATE TABLE ' || l_pb_log_tab_name || '
(
    CHANGE_ID             NUMBER(38)  NOT NULL ,
    BIOMETRICS_ID         NUMBER(38)  NOT NULL ,
    USER_KEY              VARCHAR2(64 BYTE)  NOT NULL ,
    USER_EVENT_ID         NUMBER(8)  NOT NULL ,
    VERSION               NUMBER(38)  NOT NULL ,
    CHANGE_TYPE           NUMBER(4)  NOT NULL , 
    CONSTRAINT ' || l_pb_log_pk_name || ' PRIMARY KEY (CHANGE_ID) USING INDEX(
        CREATE UNIQUE INDEX ' || l_pb_log_pk_name || ' ON ' || l_pb_log_tab_name || ' (CHANGE_ID ASC)
        PCTFREE    10
        INITRANS   20
        MAXTRANS   255
        STORAGE (
            INITIAL          64M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
        )
        TABLESPACE AIM_SYSTEM_DATA
    )
)';


    INSERT INTO "CONTAINERS" (
        CONTAINER_ID,
        CONTAINER_TABLE_NAME,
        CONTAINER_LOG_TABLE_NAME,
        MODALITY,
        ALGORITHM,
        TEMPLATE_SIZE,
        VERSION,
        RECORD_COUNT,
        MAX_RECORD_COUNT,
        LAST_ENROLLED_BIO_ID)
    values (
        l_container_id,
        l_pb_tab_name,
        l_pb_log_tab_name,
        l_modality,
        l_algorithm,
        l_template_size,
        l_verseion,
        l_record_count,
        l_max_record_count,
        l_last_bio_id
    );

EXECUTE IMMEDIATE '
ALTER TABLE ' || l_pb_tab_name || '
ADD CONSTRAINT ' || l_pb_uidx_name || ' UNIQUE (USER_KEY, USER_EVENT_ID)';

END;
/


set serveroutput on

DECLARE
    l_container_id      NUMBER;
    l_modality          VARCHAR2(128 BYTE) := 'FINGER(2)';
    l_algorithm         VARCHAR2(128 BYTE) := 'CML';
    l_template_size     NUMBER := 4224;
    l_verseion          NUMBER := 0;
    l_record_count      NUMBER := 0;
    l_max_record_count  NUMBER := 10;
    l_last_bio_id       NUMBER := 0;

    l_pb_tab_name       VARCHAR2(128 BYTE);
    l_pb_pk_name        VARCHAR2(128 BYTE);
    l_pb_uidx_name      VARCHAR2(128 BYTE);
    l_pb_log_tab_name   VARCHAR2(128 BYTE);
    l_pb_log_pk_name    VARCHAR2(128 BYTE);
    l_pb_log_uidx_name  VARCHAR2(128 BYTE);
    l_pb_secfile_name   VARCHAR2(128 BYTE);
BEGIN

    SELECT NVL(MAX(CONTAINER_ID), 0)+1 INTO l_container_id FROM CONTAINERS;

    l_pb_tab_name       := 'PERSON_BIOMETRICS_' || l_container_id;
    l_pb_pk_name        := 'PERSON_BIOMETRICS_' || l_container_id || '_PK';
    l_pb_uidx_name      := 'PERSON_BIOMETRICS_' || l_container_id || '_UIDX1';
    l_pb_log_tab_name   := 'PERSON_BIO_CHANGE_LOG_' || l_container_id;
    l_pb_log_pk_name    := 'PERSON_BIO_CHANGE_LOG_' || l_container_id || '_PK';
    l_pb_log_uidx_name  := 'PERSON_BIO_CHANGE_LOG_' || l_container_id || '_UIDX1';
    l_pb_secfile_name   := 'PERSON_BIO_' || l_container_id || '_LOB_DATA_SEC';

    EXECUTE IMMEDIATE '
CREATE TABLE ' || l_pb_tab_name || '
(
    BIOMETRICS_ID         NUMBER(38)  NOT NULL ,
    USER_KEY              VARCHAR2(64 BYTE)  NOT NULL ,
    USER_EVENT_ID         NUMBER(8)  NOT NULL ,
    BIOMETRICS_DATA       BLOB  NOT NULL ,
    BIOMETRICS_DATA_LEN   NUMBER(16)  NOT NULL ,
    REGISTERED_TS         VARCHAR2(32) NOT NULL ,
    CONSTRAINT ' || l_pb_pk_name || ' PRIMARY KEY (BIOMETRICS_ID) USING INDEX(
        CREATE UNIQUE INDEX ' || l_pb_pk_name || ' ON ' || l_pb_tab_name || ' (BIOMETRICS_ID ASC)
        PCTFREE    10
        INITRANS   20
        MAXTRANS   255
        STORAGE (
            INITIAL          64M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
        )
        TABLESPACE AIM_BIOMETRICS_DATA
    )
)
    LOB (BIOMETRICS_DATA) STORE AS SECUREFILE ' || l_pb_secfile_name || ' (
    TABLESPACE AIM_BIOMETRICS_LOB_DATA
    ENABLE      STORAGE IN ROW
    CHUNK       8192
    RETENTION   AUTO
    NOCACHE
    LOGGING
    STORAGE(
        INITIAL 64M
        MINEXTENTS 1
        MAXEXTENTS UNLIMITED
        PCTINCREASE 0
        BUFFER_POOL DEFAULT
    )
) TABLESPACE AIM_BIOMETRICS_DATA';


EXECUTE IMMEDIATE '
CREATE TABLE ' || l_pb_log_tab_name || '
(
    CHANGE_ID             NUMBER(38)  NOT NULL ,
    BIOMETRICS_ID         NUMBER(38)  NOT NULL ,
    USER_KEY              VARCHAR2(64 BYTE)  NOT NULL ,
    USER_EVENT_ID         NUMBER(8)  NOT NULL ,
    VERSION               NUMBER(38)  NOT NULL ,
    CHANGE_TYPE           NUMBER(4)  NOT NULL , 
    CONSTRAINT ' || l_pb_log_pk_name || ' PRIMARY KEY (CHANGE_ID) USING INDEX(
        CREATE UNIQUE INDEX ' || l_pb_log_pk_name || ' ON ' || l_pb_log_tab_name || ' (CHANGE_ID ASC)
        PCTFREE    10
        INITRANS   20
        MAXTRANS   255
        STORAGE (
            INITIAL          64M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
        )
        TABLESPACE AIM_SYSTEM_DATA
    )
)';


    INSERT INTO "CONTAINERS" (
        CONTAINER_ID,
        CONTAINER_TABLE_NAME,
        CONTAINER_LOG_TABLE_NAME,
        MODALITY,
        ALGORITHM,
        TEMPLATE_SIZE,
        VERSION,
        RECORD_COUNT,
        MAX_RECORD_COUNT,
        LAST_ENROLLED_BIO_ID)
    values (
        l_container_id,
        l_pb_tab_name,
        l_pb_log_tab_name,
        l_modality,
        l_algorithm,
        l_template_size,
        l_verseion,
        l_record_count,
        l_max_record_count,
        l_last_bio_id
    );

EXECUTE IMMEDIATE '
ALTER TABLE ' || l_pb_tab_name || '
ADD CONSTRAINT ' || l_pb_uidx_name || ' UNIQUE (USER_KEY, USER_EVENT_ID)';

END;
/


set serveroutput on

DECLARE
    l_container_id      NUMBER;
    l_modality          VARCHAR2(128 BYTE) := 'FACE+IRIS';
    l_algorithm         VARCHAR2(128 BYTE) := 'S17+NIRIS';
    l_template_size     NUMBER := 11392;
    l_verseion          NUMBER := 0;
    l_record_count      NUMBER := 0;
    l_max_record_count  NUMBER := 1;
    l_last_bio_id       NUMBER := 0;

    l_pb_tab_name       VARCHAR2(128 BYTE);
    l_pb_pk_name        VARCHAR2(128 BYTE);
    l_pb_uidx_name      VARCHAR2(128 BYTE);
    l_pb_log_tab_name   VARCHAR2(128 BYTE);
    l_pb_log_pk_name    VARCHAR2(128 BYTE);
    l_pb_log_uidx_name  VARCHAR2(128 BYTE);
    l_pb_secfile_name   VARCHAR2(128 BYTE);
BEGIN

    SELECT NVL(MAX(CONTAINER_ID), 0)+1 INTO l_container_id FROM CONTAINERS;

    l_pb_tab_name       := 'PERSON_BIOMETRICS_' || l_container_id;
    l_pb_pk_name        := 'PERSON_BIOMETRICS_' || l_container_id || '_PK';
    l_pb_uidx_name      := 'PERSON_BIOMETRICS_' || l_container_id || '_UIDX1';
    l_pb_log_tab_name   := 'PERSON_BIO_CHANGE_LOG_' || l_container_id;
    l_pb_log_pk_name    := 'PERSON_BIO_CHANGE_LOG_' || l_container_id || '_PK';
    l_pb_log_uidx_name  := 'PERSON_BIO_CHANGE_LOG_' || l_container_id || '_UIDX1';
    l_pb_secfile_name   := 'PERSON_BIO_' || l_container_id || '_LOB_DATA_SEC';

    EXECUTE IMMEDIATE '
CREATE TABLE ' || l_pb_tab_name || '
(
    BIOMETRICS_ID         NUMBER(38)  NOT NULL ,
    USER_KEY              VARCHAR2(64 BYTE)  NOT NULL ,
    USER_EVENT_ID         NUMBER(8)  NOT NULL ,
    BIOMETRICS_DATA       BLOB  NOT NULL ,
    BIOMETRICS_DATA_LEN   NUMBER(16)  NOT NULL ,
    REGISTERED_TS         VARCHAR2(32) NOT NULL ,
    CONSTRAINT ' || l_pb_pk_name || ' PRIMARY KEY (BIOMETRICS_ID) USING INDEX(
        CREATE UNIQUE INDEX ' || l_pb_pk_name || ' ON ' || l_pb_tab_name || ' (BIOMETRICS_ID ASC)
        PCTFREE    10
        INITRANS   20
        MAXTRANS   255
        STORAGE (
            INITIAL          64M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
        )
        TABLESPACE AIM_BIOMETRICS_DATA
    )
)
    LOB (BIOMETRICS_DATA) STORE AS SECUREFILE ' || l_pb_secfile_name || ' (
    TABLESPACE AIM_BIOMETRICS_LOB_DATA
    ENABLE      STORAGE IN ROW
    CHUNK       8192
    RETENTION   AUTO
    NOCACHE
    LOGGING
    STORAGE(
        INITIAL 64M
        MINEXTENTS 1
        MAXEXTENTS UNLIMITED
        PCTINCREASE 0
        BUFFER_POOL DEFAULT
    )
) TABLESPACE AIM_BIOMETRICS_DATA';


EXECUTE IMMEDIATE '
CREATE TABLE ' || l_pb_log_tab_name || '
(
    CHANGE_ID             NUMBER(38)  NOT NULL ,
    BIOMETRICS_ID         NUMBER(38)  NOT NULL ,
    USER_KEY              VARCHAR2(64 BYTE)  NOT NULL ,
    USER_EVENT_ID         NUMBER(8)  NOT NULL ,
    VERSION               NUMBER(38)  NOT NULL ,
    CHANGE_TYPE           NUMBER(4)  NOT NULL , 
    CONSTRAINT ' || l_pb_log_pk_name || ' PRIMARY KEY (CHANGE_ID) USING INDEX(
        CREATE UNIQUE INDEX ' || l_pb_log_pk_name || ' ON ' || l_pb_log_tab_name || ' (CHANGE_ID ASC)
        PCTFREE    10
        INITRANS   20
        MAXTRANS   255
        STORAGE (
            INITIAL          64M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
        )
        TABLESPACE AIM_SYSTEM_DATA
    )
)';


    INSERT INTO "CONTAINERS" (
        CONTAINER_ID,
        CONTAINER_TABLE_NAME,
        CONTAINER_LOG_TABLE_NAME,
        MODALITY,
        ALGORITHM,
        TEMPLATE_SIZE,
        VERSION,
        RECORD_COUNT,
        MAX_RECORD_COUNT,
        LAST_ENROLLED_BIO_ID)
    values (
        l_container_id,
        l_pb_tab_name,
        l_pb_log_tab_name,
        l_modality,
        l_algorithm,
        l_template_size,
        l_verseion,
        l_record_count,
        l_max_record_count,
        l_last_bio_id
    );

EXECUTE IMMEDIATE '
ALTER TABLE ' || l_pb_tab_name || '
ADD CONSTRAINT ' || l_pb_uidx_name || ' UNIQUE (USER_KEY, USER_EVENT_ID)';

END;
/


set serveroutput on

DECLARE
    l_container_id      NUMBER;
    l_modality          VARCHAR2(128 BYTE) := 'FACE+IRIS';
    l_algorithm         VARCHAR2(128 BYTE) := 'S17+NIRIS';
    l_template_size     NUMBER := 11392;
    l_verseion          NUMBER := 0;
    l_record_count      NUMBER := 0;
    l_max_record_count  NUMBER := 500;
    l_last_bio_id       NUMBER := 0;

    l_pb_tab_name       VARCHAR2(128 BYTE);
    l_pb_pk_name        VARCHAR2(128 BYTE);
    l_pb_uidx_name      VARCHAR2(128 BYTE);
    l_pb_log_tab_name   VARCHAR2(128 BYTE);
    l_pb_log_pk_name    VARCHAR2(128 BYTE);
    l_pb_log_uidx_name  VARCHAR2(128 BYTE);
    l_pb_secfile_name   VARCHAR2(128 BYTE);
BEGIN

    SELECT NVL(MAX(CONTAINER_ID), 0)+1 INTO l_container_id FROM CONTAINERS;

    l_pb_tab_name       := 'PERSON_BIOMETRICS_' || l_container_id;
    l_pb_pk_name        := 'PERSON_BIOMETRICS_' || l_container_id || '_PK';
    l_pb_uidx_name      := 'PERSON_BIOMETRICS_' || l_container_id || '_UIDX1';
    l_pb_log_tab_name   := 'PERSON_BIO_CHANGE_LOG_' || l_container_id;
    l_pb_log_pk_name    := 'PERSON_BIO_CHANGE_LOG_' || l_container_id || '_PK';
    l_pb_log_uidx_name  := 'PERSON_BIO_CHANGE_LOG_' || l_container_id || '_UIDX1';
    l_pb_secfile_name   := 'PERSON_BIO_' || l_container_id || '_LOB_DATA_SEC';

    EXECUTE IMMEDIATE '
CREATE TABLE ' || l_pb_tab_name || '
(
    BIOMETRICS_ID         NUMBER(38)  NOT NULL ,
    USER_KEY              VARCHAR2(64 BYTE)  NOT NULL ,
    USER_EVENT_ID         NUMBER(8)  NOT NULL ,
    BIOMETRICS_DATA       BLOB  NOT NULL ,
    BIOMETRICS_DATA_LEN   NUMBER(16)  NOT NULL ,
    REGISTERED_TS         VARCHAR2(32) NOT NULL ,
    CONSTRAINT ' || l_pb_pk_name || ' PRIMARY KEY (BIOMETRICS_ID) USING INDEX(
        CREATE UNIQUE INDEX ' || l_pb_pk_name || ' ON ' || l_pb_tab_name || ' (BIOMETRICS_ID ASC)
        PCTFREE    10
        INITRANS   20
        MAXTRANS   255
        STORAGE (
            INITIAL          64M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
        )
        TABLESPACE AIM_BIOMETRICS_DATA
    )
)
    LOB (BIOMETRICS_DATA) STORE AS SECUREFILE ' || l_pb_secfile_name || ' (
    TABLESPACE AIM_BIOMETRICS_LOB_DATA
    ENABLE      STORAGE IN ROW
    CHUNK       8192
    RETENTION   AUTO
    NOCACHE
    LOGGING
    STORAGE(
        INITIAL 64M
        MINEXTENTS 1
        MAXEXTENTS UNLIMITED
        PCTINCREASE 0
        BUFFER_POOL DEFAULT
    )
) TABLESPACE AIM_BIOMETRICS_DATA';


EXECUTE IMMEDIATE '
CREATE TABLE ' || l_pb_log_tab_name || '
(
    CHANGE_ID             NUMBER(38)  NOT NULL ,
    BIOMETRICS_ID         NUMBER(38)  NOT NULL ,
    USER_KEY              VARCHAR2(64 BYTE)  NOT NULL ,
    USER_EVENT_ID         NUMBER(8)  NOT NULL ,
    VERSION               NUMBER(38)  NOT NULL ,
    CHANGE_TYPE           NUMBER(4)  NOT NULL , 
    CONSTRAINT ' || l_pb_log_pk_name || ' PRIMARY KEY (CHANGE_ID) USING INDEX(
        CREATE UNIQUE INDEX ' || l_pb_log_pk_name || ' ON ' || l_pb_log_tab_name || ' (CHANGE_ID ASC)
        PCTFREE    10
        INITRANS   20
        MAXTRANS   255
        STORAGE (
            INITIAL          64M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
        )
        TABLESPACE AIM_SYSTEM_DATA
    )
)';


    INSERT INTO "CONTAINERS" (
        CONTAINER_ID,
        CONTAINER_TABLE_NAME,
        CONTAINER_LOG_TABLE_NAME,
        MODALITY,
        ALGORITHM,
        TEMPLATE_SIZE,
        VERSION,
        RECORD_COUNT,
        MAX_RECORD_COUNT,
        LAST_ENROLLED_BIO_ID)
    values (
        l_container_id,
        l_pb_tab_name,
        l_pb_log_tab_name,
        l_modality,
        l_algorithm,
        l_template_size,
        l_verseion,
        l_record_count,
        l_max_record_count,
        l_last_bio_id
    );

EXECUTE IMMEDIATE '
ALTER TABLE ' || l_pb_tab_name || '
ADD CONSTRAINT ' || l_pb_uidx_name || ' UNIQUE (USER_KEY, USER_EVENT_ID)';

END;
/

