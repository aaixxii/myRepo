set scan off

prompt Populating seed data...

@@insert_sequence.sql

set scan on

