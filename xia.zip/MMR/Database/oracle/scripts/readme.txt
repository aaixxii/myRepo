
AIM database creation instructions
==================================

General instructions:

- all install actions are to be performed though SQL*Plus (sqlplus) utility

- the steps must be performed in the exact order listed here

- each step must be completed successufully, the installation should not proceed to the next step if there are any errors

- the scripts are designed to exit with a "failure" status code if any errors are encountered

- a log file will be created for each action/step, the user must check all log files for any errors

- any errors must be corrected before attempting to run the same script again


Step 1. Create AIM tablespaces
------------------------------

NOTE: If tablespaces already exist an error will be raised by Oracle.
If the target database already has the tablespaces created you should proceed to Step 2.

1.1 Connect to the target database as SYS user and run create_tablespaces.sql

sqlplus sys/<sys_user_password>@<TNS alias> as sysdba

1.2 At SQL*Plus command prompt enter:

SQL> @create_tablespaces.sql

You will be propmted to enter a fully qualified directory name where Oracle will create the tablespaces on RDBMS server

Enter a full path for AIM tablespaces directory (no trailing slashes):<path>

Hit enter, the installation will proceed.

1.3 After the script finishes examine create_tablespace.log file for any errors.


Step 2. Create AIM database user
--------------------------------

2.1 Connect to the target database as SYS user and run create_user.sql

sqlplus sys/<sys_user_password>@<TNS alias> as sysdba

2.2 At SQL*Plus command prompt enter:

SQL> @create_user.sql

You will be propmted to enter a username and a password

Enter AIM database username:<AIM_target_username>
Enter AIM database user password:<AIM_target_password>

Hit enter, the installation will proceed.

2.3 After the script finishes examine create_user.log file for any errors.


Step 3. Run build script to create schema objects
-------------------------------------------------

3.1 Edit 'PARAMS' variable in 'create_pb_sql_script.sh' to create your purpuse container tables.

3.2 Run script as below. 

./create_pb_sql_script.sh

'create_pb_tab_and_con.sql' will be created under ddl directory. This sql script will be called at the step 4.


Step 4. Run build script to create schema objects
-------------------------------------------------

4.1 Connect to the target database as AIM database user and run build_aim.sql

sqlplus <AIM user>/<AIM password>@<TNS alias>

4.2 At SQL*Plus command prompt enter:

SQL> @build_aim.sql

4.3 The installation will proceed automatically, there are no parameters/arguments.

4.4 After the script finishes examine build_aim.log file for any errors.


That's it, you're done.
-----------------------


