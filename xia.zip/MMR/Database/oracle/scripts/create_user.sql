
spool create_user.log

WHENEVER OSERROR  EXIT FAILURE;
WHENEVER SQLERROR EXIT SQL.SQLCODE;

accept aim_user char prompt 'Enter AIM database username:';
accept aim_pwd  char prompt 'Enter AIM database user password:';

----------------------------------------------
prompt
prompt Creating AIM schema owner...
prompt

create user          &&aim_user 
identified by        &&aim_pwd
default tablespace   aim_system_data
temporary tablespace temp;

grant connect to                   &&aim_user;
grant resource to                  &&aim_user;
grant unlimited tablespace to      &&aim_user;

--- ### TEMPORARY GRANT
grant dba                       to &&aim_user;

exit success;
