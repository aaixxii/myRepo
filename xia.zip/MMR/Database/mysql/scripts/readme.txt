#-------------------
# Requirement 
#-------------------
- Mysql client
    $ wget http://sv18/cobbler/localmirror/pkgs/mysql57-community-release-el7-9.noarch.rpm
    $ rpm -ihv mysql57-community-release-el7-9.noarch.rpm
    $ yum install mysql-community-client.x86_64

#-----------------------------
# Create DB user and tables
#-----------------------------
1. Edit 'CONTAINER_PARAMS' parameter in 'prepare_for_pb_create_sql.sh' to arrange AIM CONTAINERS for your env.
    $ vim prepare_for_pb_create_sql

2. Execute prepare_for_pb_create_sql
    $ ./prepare_for_pb_create_sql

3. Execute setup_aimdb.sh
    $ ./setup_aimdb.sh

