
DELIMITER @@@
DROP PROCEDURE IF EXISTS pb_and_log_create;
CREATE PROCEDURE pb_and_log_create()

BEGIN
    DECLARE l_container_id      INT;
    DECLARE l_modality          VARCHAR(128);
    DECLARE l_algorithm         VARCHAR(128);
    DECLARE l_template_size     INT;
    DECLARE l_verseion          INT;
    DECLARE l_record_count      INT;
    DECLARE l_max_record_count  INT;
    DECLARE l_last_bio_id       INT;
    DECLARE l_pb_tab_name       VARCHAR(128);
    DECLARE l_pb_log_tab_name   VARCHAR(128);

    SET l_modality = 'FINGER(10)';
    SET l_algorithm = 'CML';
    SET l_template_size = 20608;
    SET l_verseion = 0;
    SET l_record_count = 0;
    SET l_max_record_count = 10;
    SET l_last_bio_id = 0;

    SELECT IFNULL(MAX(CONTAINER_ID), 0)+1 INTO l_container_id FROM CONTAINERS;
    SET l_pb_tab_name       = CONCAT('PERSON_BIOMETRICS_', l_container_id);
    SET l_pb_log_tab_name   = CONCAT('PERSON_BIO_CHANGE_LOG_', l_container_id);

    SET @sql = CONCAT('CREATE TABLE ', l_pb_tab_name, '
(
    BIOMETRICS_ID         BIGINT  NOT NULL PRIMARY KEY,
    USER_KEY              VARCHAR(64)  NOT NULL,
    USER_EVENT_ID         INT  NOT NULL,
    BIOMETRICS_DATA       BLOB  NOT NULL,
    BIOMETRICS_DATA_LEN   INT  NOT NULL,
    REGISTERED_TS         VARCHAR(32) NOT NULL,
    UNIQUE(USER_KEY, USER_EVENT_ID)
) engine=InnoDB');

    PREPARE stmt FROM @sql;
    EXECUTE stmt;

    SET @sql = CONCAT('CREATE TABLE ', l_pb_log_tab_name, '
(
    CHANGE_ID             BIGINT  NOT NULL PRIMARY KEY,
    BIOMETRICS_ID         BIGINT  NOT NULL ,
    USER_KEY              VARCHAR(64)  NOT NULL,
    USER_EVENT_ID         INT  NOT NULL,
    VERSION               BIGINT  NOT NULL,
    CHANGE_TYPE           INT  NOT NULL
) engine=InnoDB');

    PREPARE stmt FROM @sql;
    EXECUTE stmt;

    INSERT INTO CONTAINERS (
        CONTAINER_ID,
        CONTAINER_TABLE_NAME,
        CONTAINER_LOG_TABLE_NAME,
        MODALITY,
        ALGORITHM,
        TEMPLATE_SIZE,
        VERSION,
        RECORD_COUNT,
        MAX_RECORD_COUNT,
        LAST_ENROLLED_BIO_ID)
    VALUES (
        l_container_id,
        l_pb_tab_name,
        l_pb_log_tab_name,
        l_modality,
        l_algorithm,
        l_template_size,
        l_verseion,
        l_record_count,
        l_max_record_count,
        l_last_bio_id
    );


    SET l_modality = 'FACE';
    SET l_algorithm = 'S17';
    SET l_template_size = 5248;
    SET l_verseion = 0;
    SET l_record_count = 0;
    SET l_max_record_count = 10;
    SET l_last_bio_id = 0;

    SELECT IFNULL(MAX(CONTAINER_ID), 0)+1 INTO l_container_id FROM CONTAINERS;
    SET l_pb_tab_name       = CONCAT('PERSON_BIOMETRICS_', l_container_id);
    SET l_pb_log_tab_name   = CONCAT('PERSON_BIO_CHANGE_LOG_', l_container_id);

    SET @sql = CONCAT('CREATE TABLE ', l_pb_tab_name, '
(
    BIOMETRICS_ID         BIGINT  NOT NULL PRIMARY KEY,
    USER_KEY              VARCHAR(64)  NOT NULL,
    USER_EVENT_ID         INT  NOT NULL,
    BIOMETRICS_DATA       BLOB  NOT NULL,
    BIOMETRICS_DATA_LEN   INT  NOT NULL,
    REGISTERED_TS         VARCHAR(32) NOT NULL,
    UNIQUE(USER_KEY, USER_EVENT_ID)
) engine=InnoDB');

    PREPARE stmt FROM @sql;
    EXECUTE stmt;

    SET @sql = CONCAT('CREATE TABLE ', l_pb_log_tab_name, '
(
    CHANGE_ID             BIGINT  NOT NULL PRIMARY KEY,
    BIOMETRICS_ID         BIGINT  NOT NULL ,
    USER_KEY              VARCHAR(64)  NOT NULL,
    USER_EVENT_ID         INT  NOT NULL,
    VERSION               BIGINT  NOT NULL,
    CHANGE_TYPE           INT  NOT NULL
) engine=InnoDB');

    PREPARE stmt FROM @sql;
    EXECUTE stmt;

    INSERT INTO CONTAINERS (
        CONTAINER_ID,
        CONTAINER_TABLE_NAME,
        CONTAINER_LOG_TABLE_NAME,
        MODALITY,
        ALGORITHM,
        TEMPLATE_SIZE,
        VERSION,
        RECORD_COUNT,
        MAX_RECORD_COUNT,
        LAST_ENROLLED_BIO_ID)
    VALUES (
        l_container_id,
        l_pb_tab_name,
        l_pb_log_tab_name,
        l_modality,
        l_algorithm,
        l_template_size,
        l_verseion,
        l_record_count,
        l_max_record_count,
        l_last_bio_id
    );


    SET l_modality = 'FACE';
    SET l_algorithm = 'S14';
    SET l_template_size = 5248;
    SET l_verseion = 0;
    SET l_record_count = 0;
    SET l_max_record_count = 10;
    SET l_last_bio_id = 0;

    SELECT IFNULL(MAX(CONTAINER_ID), 0)+1 INTO l_container_id FROM CONTAINERS;
    SET l_pb_tab_name       = CONCAT('PERSON_BIOMETRICS_', l_container_id);
    SET l_pb_log_tab_name   = CONCAT('PERSON_BIO_CHANGE_LOG_', l_container_id);

    SET @sql = CONCAT('CREATE TABLE ', l_pb_tab_name, '
(
    BIOMETRICS_ID         BIGINT  NOT NULL PRIMARY KEY,
    USER_KEY              VARCHAR(64)  NOT NULL,
    USER_EVENT_ID         INT  NOT NULL,
    BIOMETRICS_DATA       BLOB  NOT NULL,
    BIOMETRICS_DATA_LEN   INT  NOT NULL,
    REGISTERED_TS         VARCHAR(32) NOT NULL,
    UNIQUE(USER_KEY, USER_EVENT_ID)
) engine=InnoDB');

    PREPARE stmt FROM @sql;
    EXECUTE stmt;

    SET @sql = CONCAT('CREATE TABLE ', l_pb_log_tab_name, '
(
    CHANGE_ID             BIGINT  NOT NULL PRIMARY KEY,
    BIOMETRICS_ID         BIGINT  NOT NULL ,
    USER_KEY              VARCHAR(64)  NOT NULL,
    USER_EVENT_ID         INT  NOT NULL,
    VERSION               BIGINT  NOT NULL,
    CHANGE_TYPE           INT  NOT NULL
) engine=InnoDB');

    PREPARE stmt FROM @sql;
    EXECUTE stmt;

    INSERT INTO CONTAINERS (
        CONTAINER_ID,
        CONTAINER_TABLE_NAME,
        CONTAINER_LOG_TABLE_NAME,
        MODALITY,
        ALGORITHM,
        TEMPLATE_SIZE,
        VERSION,
        RECORD_COUNT,
        MAX_RECORD_COUNT,
        LAST_ENROLLED_BIO_ID)
    VALUES (
        l_container_id,
        l_pb_tab_name,
        l_pb_log_tab_name,
        l_modality,
        l_algorithm,
        l_template_size,
        l_verseion,
        l_record_count,
        l_max_record_count,
        l_last_bio_id
    );


    SET l_modality = 'IRIS';
    SET l_algorithm = 'NIRIS';
    SET l_template_size = 6272;
    SET l_verseion = 0;
    SET l_record_count = 0;
    SET l_max_record_count = 10;
    SET l_last_bio_id = 0;

    SELECT IFNULL(MAX(CONTAINER_ID), 0)+1 INTO l_container_id FROM CONTAINERS;
    SET l_pb_tab_name       = CONCAT('PERSON_BIOMETRICS_', l_container_id);
    SET l_pb_log_tab_name   = CONCAT('PERSON_BIO_CHANGE_LOG_', l_container_id);

    SET @sql = CONCAT('CREATE TABLE ', l_pb_tab_name, '
(
    BIOMETRICS_ID         BIGINT  NOT NULL PRIMARY KEY,
    USER_KEY              VARCHAR(64)  NOT NULL,
    USER_EVENT_ID         INT  NOT NULL,
    BIOMETRICS_DATA       BLOB  NOT NULL,
    BIOMETRICS_DATA_LEN   INT  NOT NULL,
    REGISTERED_TS         VARCHAR(32) NOT NULL,
    UNIQUE(USER_KEY, USER_EVENT_ID)
) engine=InnoDB');

    PREPARE stmt FROM @sql;
    EXECUTE stmt;

    SET @sql = CONCAT('CREATE TABLE ', l_pb_log_tab_name, '
(
    CHANGE_ID             BIGINT  NOT NULL PRIMARY KEY,
    BIOMETRICS_ID         BIGINT  NOT NULL ,
    USER_KEY              VARCHAR(64)  NOT NULL,
    USER_EVENT_ID         INT  NOT NULL,
    VERSION               BIGINT  NOT NULL,
    CHANGE_TYPE           INT  NOT NULL
) engine=InnoDB');

    PREPARE stmt FROM @sql;
    EXECUTE stmt;

    INSERT INTO CONTAINERS (
        CONTAINER_ID,
        CONTAINER_TABLE_NAME,
        CONTAINER_LOG_TABLE_NAME,
        MODALITY,
        ALGORITHM,
        TEMPLATE_SIZE,
        VERSION,
        RECORD_COUNT,
        MAX_RECORD_COUNT,
        LAST_ENROLLED_BIO_ID)
    VALUES (
        l_container_id,
        l_pb_tab_name,
        l_pb_log_tab_name,
        l_modality,
        l_algorithm,
        l_template_size,
        l_verseion,
        l_record_count,
        l_max_record_count,
        l_last_bio_id
    );


    SET l_modality = 'IRIS';
    SET l_algorithm = 'NIRIS';
    SET l_template_size = 6272;
    SET l_verseion = 0;
    SET l_record_count = 0;
    SET l_max_record_count = 10;
    SET l_last_bio_id = 0;

    SELECT IFNULL(MAX(CONTAINER_ID), 0)+1 INTO l_container_id FROM CONTAINERS;
    SET l_pb_tab_name       = CONCAT('PERSON_BIOMETRICS_', l_container_id);
    SET l_pb_log_tab_name   = CONCAT('PERSON_BIO_CHANGE_LOG_', l_container_id);

    SET @sql = CONCAT('CREATE TABLE ', l_pb_tab_name, '
(
    BIOMETRICS_ID         BIGINT  NOT NULL PRIMARY KEY,
    USER_KEY              VARCHAR(64)  NOT NULL,
    USER_EVENT_ID         INT  NOT NULL,
    BIOMETRICS_DATA       BLOB  NOT NULL,
    BIOMETRICS_DATA_LEN   INT  NOT NULL,
    REGISTERED_TS         VARCHAR(32) NOT NULL,
    UNIQUE(USER_KEY, USER_EVENT_ID)
) engine=InnoDB');

    PREPARE stmt FROM @sql;
    EXECUTE stmt;

    SET @sql = CONCAT('CREATE TABLE ', l_pb_log_tab_name, '
(
    CHANGE_ID             BIGINT  NOT NULL PRIMARY KEY,
    BIOMETRICS_ID         BIGINT  NOT NULL ,
    USER_KEY              VARCHAR(64)  NOT NULL,
    USER_EVENT_ID         INT  NOT NULL,
    VERSION               BIGINT  NOT NULL,
    CHANGE_TYPE           INT  NOT NULL
) engine=InnoDB');

    PREPARE stmt FROM @sql;
    EXECUTE stmt;

    INSERT INTO CONTAINERS (
        CONTAINER_ID,
        CONTAINER_TABLE_NAME,
        CONTAINER_LOG_TABLE_NAME,
        MODALITY,
        ALGORITHM,
        TEMPLATE_SIZE,
        VERSION,
        RECORD_COUNT,
        MAX_RECORD_COUNT,
        LAST_ENROLLED_BIO_ID)
    VALUES (
        l_container_id,
        l_pb_tab_name,
        l_pb_log_tab_name,
        l_modality,
        l_algorithm,
        l_template_size,
        l_verseion,
        l_record_count,
        l_max_record_count,
        l_last_bio_id
    );


    SET l_modality = 'FACE+IRIS';
    SET l_algorithm = 'S17+NIRIS';
    SET l_template_size = 11392;
    SET l_verseion = 0;
    SET l_record_count = 0;
    SET l_max_record_count = 10;
    SET l_last_bio_id = 0;

    SELECT IFNULL(MAX(CONTAINER_ID), 0)+1 INTO l_container_id FROM CONTAINERS;
    SET l_pb_tab_name       = CONCAT('PERSON_BIOMETRICS_', l_container_id);
    SET l_pb_log_tab_name   = CONCAT('PERSON_BIO_CHANGE_LOG_', l_container_id);

    SET @sql = CONCAT('CREATE TABLE ', l_pb_tab_name, '
(
    BIOMETRICS_ID         BIGINT  NOT NULL PRIMARY KEY,
    USER_KEY              VARCHAR(64)  NOT NULL,
    USER_EVENT_ID         INT  NOT NULL,
    BIOMETRICS_DATA       BLOB  NOT NULL,
    BIOMETRICS_DATA_LEN   INT  NOT NULL,
    REGISTERED_TS         VARCHAR(32) NOT NULL,
    UNIQUE(USER_KEY, USER_EVENT_ID)
) engine=InnoDB');

    PREPARE stmt FROM @sql;
    EXECUTE stmt;

    SET @sql = CONCAT('CREATE TABLE ', l_pb_log_tab_name, '
(
    CHANGE_ID             BIGINT  NOT NULL PRIMARY KEY,
    BIOMETRICS_ID         BIGINT  NOT NULL ,
    USER_KEY              VARCHAR(64)  NOT NULL,
    USER_EVENT_ID         INT  NOT NULL,
    VERSION               BIGINT  NOT NULL,
    CHANGE_TYPE           INT  NOT NULL
) engine=InnoDB');

    PREPARE stmt FROM @sql;
    EXECUTE stmt;

    INSERT INTO CONTAINERS (
        CONTAINER_ID,
        CONTAINER_TABLE_NAME,
        CONTAINER_LOG_TABLE_NAME,
        MODALITY,
        ALGORITHM,
        TEMPLATE_SIZE,
        VERSION,
        RECORD_COUNT,
        MAX_RECORD_COUNT,
        LAST_ENROLLED_BIO_ID)
    VALUES (
        l_container_id,
        l_pb_tab_name,
        l_pb_log_tab_name,
        l_modality,
        l_algorithm,
        l_template_size,
        l_verseion,
        l_record_count,
        l_max_record_count,
        l_last_bio_id
    );


    SET l_modality = 'FINGER(10)+IRIS+FACE';
    SET l_algorithm = 'CML+NIRIS+S17';
    SET l_template_size = 31872;
    SET l_verseion = 0;
    SET l_record_count = 0;
    SET l_max_record_count = 10;
    SET l_last_bio_id = 0;

    SELECT IFNULL(MAX(CONTAINER_ID), 0)+1 INTO l_container_id FROM CONTAINERS;
    SET l_pb_tab_name       = CONCAT('PERSON_BIOMETRICS_', l_container_id);
    SET l_pb_log_tab_name   = CONCAT('PERSON_BIO_CHANGE_LOG_', l_container_id);

    SET @sql = CONCAT('CREATE TABLE ', l_pb_tab_name, '
(
    BIOMETRICS_ID         BIGINT  NOT NULL PRIMARY KEY,
    USER_KEY              VARCHAR(64)  NOT NULL,
    USER_EVENT_ID         INT  NOT NULL,
    BIOMETRICS_DATA       BLOB  NOT NULL,
    BIOMETRICS_DATA_LEN   INT  NOT NULL,
    REGISTERED_TS         VARCHAR(32) NOT NULL,
    UNIQUE(USER_KEY, USER_EVENT_ID)
) engine=InnoDB');

    PREPARE stmt FROM @sql;
    EXECUTE stmt;

    SET @sql = CONCAT('CREATE TABLE ', l_pb_log_tab_name, '
(
    CHANGE_ID             BIGINT  NOT NULL PRIMARY KEY,
    BIOMETRICS_ID         BIGINT  NOT NULL ,
    USER_KEY              VARCHAR(64)  NOT NULL,
    USER_EVENT_ID         INT  NOT NULL,
    VERSION               BIGINT  NOT NULL,
    CHANGE_TYPE           INT  NOT NULL
) engine=InnoDB');

    PREPARE stmt FROM @sql;
    EXECUTE stmt;

    INSERT INTO CONTAINERS (
        CONTAINER_ID,
        CONTAINER_TABLE_NAME,
        CONTAINER_LOG_TABLE_NAME,
        MODALITY,
        ALGORITHM,
        TEMPLATE_SIZE,
        VERSION,
        RECORD_COUNT,
        MAX_RECORD_COUNT,
        LAST_ENROLLED_BIO_ID)
    VALUES (
        l_container_id,
        l_pb_tab_name,
        l_pb_log_tab_name,
        l_modality,
        l_algorithm,
        l_template_size,
        l_verseion,
        l_record_count,
        l_max_record_count,
        l_last_bio_id
    );


    SET l_modality = 'FINGER(2)';
    SET l_algorithm = 'CML';
    SET l_template_size = 4224;
    SET l_verseion = 0;
    SET l_record_count = 0;
    SET l_max_record_count = 10;
    SET l_last_bio_id = 0;

    SELECT IFNULL(MAX(CONTAINER_ID), 0)+1 INTO l_container_id FROM CONTAINERS;
    SET l_pb_tab_name       = CONCAT('PERSON_BIOMETRICS_', l_container_id);
    SET l_pb_log_tab_name   = CONCAT('PERSON_BIO_CHANGE_LOG_', l_container_id);

    SET @sql = CONCAT('CREATE TABLE ', l_pb_tab_name, '
(
    BIOMETRICS_ID         BIGINT  NOT NULL PRIMARY KEY,
    USER_KEY              VARCHAR(64)  NOT NULL,
    USER_EVENT_ID         INT  NOT NULL,
    BIOMETRICS_DATA       BLOB  NOT NULL,
    BIOMETRICS_DATA_LEN   INT  NOT NULL,
    REGISTERED_TS         VARCHAR(32) NOT NULL,
    UNIQUE(USER_KEY, USER_EVENT_ID)
) engine=InnoDB');

    PREPARE stmt FROM @sql;
    EXECUTE stmt;

    SET @sql = CONCAT('CREATE TABLE ', l_pb_log_tab_name, '
(
    CHANGE_ID             BIGINT  NOT NULL PRIMARY KEY,
    BIOMETRICS_ID         BIGINT  NOT NULL ,
    USER_KEY              VARCHAR(64)  NOT NULL,
    USER_EVENT_ID         INT  NOT NULL,
    VERSION               BIGINT  NOT NULL,
    CHANGE_TYPE           INT  NOT NULL
) engine=InnoDB');

    PREPARE stmt FROM @sql;
    EXECUTE stmt;

    INSERT INTO CONTAINERS (
        CONTAINER_ID,
        CONTAINER_TABLE_NAME,
        CONTAINER_LOG_TABLE_NAME,
        MODALITY,
        ALGORITHM,
        TEMPLATE_SIZE,
        VERSION,
        RECORD_COUNT,
        MAX_RECORD_COUNT,
        LAST_ENROLLED_BIO_ID)
    VALUES (
        l_container_id,
        l_pb_tab_name,
        l_pb_log_tab_name,
        l_modality,
        l_algorithm,
        l_template_size,
        l_verseion,
        l_record_count,
        l_max_record_count,
        l_last_bio_id
    );


    SET l_modality = 'FACE+IRIS';
    SET l_algorithm = 'S17+NIRIS';
    SET l_template_size = 11392;
    SET l_verseion = 0;
    SET l_record_count = 0;
    SET l_max_record_count = 1;
    SET l_last_bio_id = 0;

    SELECT IFNULL(MAX(CONTAINER_ID), 0)+1 INTO l_container_id FROM CONTAINERS;
    SET l_pb_tab_name       = CONCAT('PERSON_BIOMETRICS_', l_container_id);
    SET l_pb_log_tab_name   = CONCAT('PERSON_BIO_CHANGE_LOG_', l_container_id);

    SET @sql = CONCAT('CREATE TABLE ', l_pb_tab_name, '
(
    BIOMETRICS_ID         BIGINT  NOT NULL PRIMARY KEY,
    USER_KEY              VARCHAR(64)  NOT NULL,
    USER_EVENT_ID         INT  NOT NULL,
    BIOMETRICS_DATA       BLOB  NOT NULL,
    BIOMETRICS_DATA_LEN   INT  NOT NULL,
    REGISTERED_TS         VARCHAR(32) NOT NULL,
    UNIQUE(USER_KEY, USER_EVENT_ID)
) engine=InnoDB');

    PREPARE stmt FROM @sql;
    EXECUTE stmt;

    SET @sql = CONCAT('CREATE TABLE ', l_pb_log_tab_name, '
(
    CHANGE_ID             BIGINT  NOT NULL PRIMARY KEY,
    BIOMETRICS_ID         BIGINT  NOT NULL ,
    USER_KEY              VARCHAR(64)  NOT NULL,
    USER_EVENT_ID         INT  NOT NULL,
    VERSION               BIGINT  NOT NULL,
    CHANGE_TYPE           INT  NOT NULL
) engine=InnoDB');

    PREPARE stmt FROM @sql;
    EXECUTE stmt;

    INSERT INTO CONTAINERS (
        CONTAINER_ID,
        CONTAINER_TABLE_NAME,
        CONTAINER_LOG_TABLE_NAME,
        MODALITY,
        ALGORITHM,
        TEMPLATE_SIZE,
        VERSION,
        RECORD_COUNT,
        MAX_RECORD_COUNT,
        LAST_ENROLLED_BIO_ID)
    VALUES (
        l_container_id,
        l_pb_tab_name,
        l_pb_log_tab_name,
        l_modality,
        l_algorithm,
        l_template_size,
        l_verseion,
        l_record_count,
        l_max_record_count,
        l_last_bio_id
    );


    SET l_modality = 'FACE+IRIS';
    SET l_algorithm = 'S17+NIRIS';
    SET l_template_size = 11392;
    SET l_verseion = 0;
    SET l_record_count = 0;
    SET l_max_record_count = 500;
    SET l_last_bio_id = 0;

    SELECT IFNULL(MAX(CONTAINER_ID), 0)+1 INTO l_container_id FROM CONTAINERS;
    SET l_pb_tab_name       = CONCAT('PERSON_BIOMETRICS_', l_container_id);
    SET l_pb_log_tab_name   = CONCAT('PERSON_BIO_CHANGE_LOG_', l_container_id);

    SET @sql = CONCAT('CREATE TABLE ', l_pb_tab_name, '
(
    BIOMETRICS_ID         BIGINT  NOT NULL PRIMARY KEY,
    USER_KEY              VARCHAR(64)  NOT NULL,
    USER_EVENT_ID         INT  NOT NULL,
    BIOMETRICS_DATA       BLOB  NOT NULL,
    BIOMETRICS_DATA_LEN   INT  NOT NULL,
    REGISTERED_TS         VARCHAR(32) NOT NULL,
    UNIQUE(USER_KEY, USER_EVENT_ID)
) engine=InnoDB');

    PREPARE stmt FROM @sql;
    EXECUTE stmt;

    SET @sql = CONCAT('CREATE TABLE ', l_pb_log_tab_name, '
(
    CHANGE_ID             BIGINT  NOT NULL PRIMARY KEY,
    BIOMETRICS_ID         BIGINT  NOT NULL ,
    USER_KEY              VARCHAR(64)  NOT NULL,
    USER_EVENT_ID         INT  NOT NULL,
    VERSION               BIGINT  NOT NULL,
    CHANGE_TYPE           INT  NOT NULL
) engine=InnoDB');

    PREPARE stmt FROM @sql;
    EXECUTE stmt;

    INSERT INTO CONTAINERS (
        CONTAINER_ID,
        CONTAINER_TABLE_NAME,
        CONTAINER_LOG_TABLE_NAME,
        MODALITY,
        ALGORITHM,
        TEMPLATE_SIZE,
        VERSION,
        RECORD_COUNT,
        MAX_RECORD_COUNT,
        LAST_ENROLLED_BIO_ID)
    VALUES (
        l_container_id,
        l_pb_tab_name,
        l_pb_log_tab_name,
        l_modality,
        l_algorithm,
        l_template_size,
        l_verseion,
        l_record_count,
        l_max_record_count,
        l_last_bio_id
    );


END;
@@@
DELIMITER ;
call pb_and_log_create();
DROP PROCEDURE pb_and_log_create;
