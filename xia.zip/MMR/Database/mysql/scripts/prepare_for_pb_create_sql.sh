#!/bin/bash 

DDL_SQL=./ddl/create_pb_and_pb_log.sql

#Modality,Algorithm,TemplateSize,MaxRecordCount
CONTAINER_PARAMS=(
"FINGER(10),CML,20608,10"
"FACE,S17,5248,10"
"FACE,S14,5248,10"
"IRIS,NIRIS,6272,10"
"IRIS,NIRIS,6272,10"
"FACE+IRIS,S17+NIRIS,11392,10"
"FINGER(10)+IRIS+FACE,CML+NIRIS+S17,31872,10"
"FINGER(2),CML,4224,10"
"FACE+IRIS,S17+NIRIS,11392,1"
"FACE+IRIS,S17+NIRIS,11392,500"
)


function mk_pb_ddl_sql() {
    local modality=$1
    local algorithm=$2
    local template_size=$3
    local max_record_count=$4

    echo "
    SET l_modality = '$modality';
    SET l_algorithm = '$algorithm';
    SET l_template_size = $template_size;
    SET l_verseion = 0;
    SET l_record_count = 0;
    SET l_max_record_count = $max_record_count;
    SET l_last_bio_id = 0;

    SELECT IFNULL(MAX(CONTAINER_ID), 0)+1 INTO l_container_id FROM CONTAINERS;
    SET l_pb_tab_name       = CONCAT('PERSON_BIOMETRICS_', l_container_id);
    SET l_pb_log_tab_name   = CONCAT('PERSON_BIO_CHANGE_LOG_', l_container_id);

    SET @sql = CONCAT('CREATE TABLE ', l_pb_tab_name, '
(
    BIOMETRICS_ID         BIGINT  NOT NULL PRIMARY KEY,
    USER_KEY              VARCHAR(64)  NOT NULL,
    USER_EVENT_ID         INT  NOT NULL,
    BIOMETRICS_DATA       BLOB  NOT NULL,
    BIOMETRICS_DATA_LEN   INT  NOT NULL,
    REGISTERED_TS         VARCHAR(32) NOT NULL,
    UNIQUE(USER_KEY, USER_EVENT_ID)
) engine=InnoDB');

    PREPARE stmt FROM @sql;
    EXECUTE stmt;

    SET @sql = CONCAT('CREATE TABLE ', l_pb_log_tab_name, '
(
    CHANGE_ID             BIGINT  NOT NULL PRIMARY KEY,
    BIOMETRICS_ID         BIGINT  NOT NULL ,
    USER_KEY              VARCHAR(64)  NOT NULL,
    USER_EVENT_ID         INT  NOT NULL,
    VERSION               BIGINT  NOT NULL,
    CHANGE_TYPE           INT  NOT NULL
) engine=InnoDB');

    PREPARE stmt FROM @sql;
    EXECUTE stmt;

    INSERT INTO CONTAINERS (
        CONTAINER_ID,
        CONTAINER_TABLE_NAME,
        CONTAINER_LOG_TABLE_NAME,
        MODALITY,
        ALGORITHM,
        TEMPLATE_SIZE,
        VERSION,
        RECORD_COUNT,
        MAX_RECORD_COUNT,
        LAST_ENROLLED_BIO_ID)
    VALUES (
        l_container_id,
        l_pb_tab_name,
        l_pb_log_tab_name,
        l_modality,
        l_algorithm,
        l_template_size,
        l_verseion,
        l_record_count,
        l_max_record_count,
        l_last_bio_id
    );
" >> $DDL_SQL

}

function init_sql_script() {
    : > $DDL_SQL
}

function append_header() {
    echo "
DELIMITER @@@
DROP PROCEDURE IF EXISTS pb_and_log_create;
CREATE PROCEDURE pb_and_log_create()

BEGIN
    DECLARE l_container_id      INT;
    DECLARE l_modality          VARCHAR(128);
    DECLARE l_algorithm         VARCHAR(128);
    DECLARE l_template_size     INT;
    DECLARE l_verseion          INT;
    DECLARE l_record_count      INT;
    DECLARE l_max_record_count  INT;
    DECLARE l_last_bio_id       INT;
    DECLARE l_pb_tab_name       VARCHAR(128);
    DECLARE l_pb_log_tab_name   VARCHAR(128);" >> $DDL_SQL
}

function append_footer() {
    echo "
END;
@@@
DELIMITER ;
call pb_and_log_create();
DROP PROCEDURE pb_and_log_create;" >> $DDL_SQL
}

function main() {
    local modality=$1
    local algorithm=$2
    local template_size=$3
    local max_record_count=$4

    init_sql_script
    append_header
    for param in ${CONTAINER_PARAMS[@]}
    do
        modality=`echo $param | awk -F',' '{print $1}'`
        algorithm=`echo $param | awk -F',' '{print $2}'`
        template_size=`echo $param | awk -F',' '{print $3}'`
        max_record_count=`echo $param | awk -F',' '{print $4}'`
        mk_pb_ddl_sql "$modality" "$algorithm" "$template_size" "$max_record_count"
    done
    append_footer
}

main
