#!/bin/bash 

COLOR_RED=31
COLOR_GREEN=32
CREATE_TAB_SQL_SCRIPT="./ddl/create_tab.sql"
CREATE_PB_TAB_SQL_SCRIPT="./ddl/create_pb_and_pb_log.sql"
INSERT_SEQ_SQL_SCRIPT="./dml/insert_sequence.sql"
DB_USER=""
DB_PASS=""
DB_HOST=""
DB_ROOT_PASS=""

function check_installed_mysql_client() {
    test -x `which mysql`
    if [ $? -ne 0 ]; then
        echo "Not found mysql command. Please set mysql command to your PATH env variable."
        exit
    fi
}

function read_db_parameter(){
    echo -n "Enter database hostname or IP address:"
    read DB_HOST
    echo -n "Enter database root password:"
    stty -echo
    read DB_ROOT_PASS
    stty echo
    echo
    echo -n "Enter database new user name(Database will be also created as same name):"
    read DB_USER
    echo -n "Enter database new user password:"
    read DB_PASS
    echo
}

function create_db_and_user() {
    sql="
DROP DATABASE IF EXISTS $DB_USER;
DROP USER IF EXISTS $DB_USER;
CREATE DATABASE $DB_USER;
USE $DB_USER;
CREATE USER '$DB_USER'@'%' IDENTIFIED BY '$DB_PASS';
GRANT ALL PRIVILEGES ON $DB_USER.* TO '$DB_USER'@'%' IDENTIFIED BY '$DB_PASS';
"
    MYSQL_PWD=$DB_ROOT_PASS mysql -u root -h $DB_HOST -e "$sql"
    check_result_status $? "Create database and user"
}

function create_table() {
    sql="
USE $DB_USER;
source $CREATE_TAB_SQL_SCRIPT;
source $CREATE_PB_TAB_SQL_SCRIPT;
"
    MYSQL_PWD=$DB_ROOT_PASS mysql -u root -h $DB_HOST -e "$sql"
    check_result_status $? "Create tables"
}

function insert_records() {
    sql="
USE $DB_USER;
source $INSERT_SEQ_SQL_SCRIPT
"
    MYSQL_PWD=$DB_ROOT_PASS mysql -u root -h $DB_HOST -e "$sql"
    check_result_status $? "Insert records"
}

function check_result_status() {
    local ret=$1
    local content="$2"

    echo -n "$content --> "
    if [ $ret -eq 0 ]; then
        print_success
    else
        print_fail
        exit -1
    fi
}

function print_success() {
    echo_color "Successed" $COLOR_GREEN
}

function print_fail() {
    echo_color "Failed" $COLOR_RED
}


function echo_color() {
    local messg=$1
    local color=$2
    echo -e "\e[${color}m${messg}\e[m"
}

function main() {
    check_installed_mysql_client
    read_db_parameter
    create_db_and_user
    create_table
    insert_records
}

main

