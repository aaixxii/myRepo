/**
 *
 */
package jp.co.alsok.g6.zzw.web.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import jp.co.alsok.g6.zzw.web.dao.mapper.g5.G5KeibisakiInfoMapper;
import jp.co.alsok.g6.zzw.web.dao.mapper.g6.G6KeibisakiInfoMapper;
import jp.co.alsok.g6.zzw.web.dao.mapper.ghs.GhsKeibisakiInfoMapper;
import jp.co.alsok.g6.zzw.web.dto.KeibisakiInfoDto;

/**
 * G5, 次期(G6), GHSの警備先情報取得 Service
 *
 * @author SNG
 */
@Service
public class UserAuthKeibisakiService {
	@Autowired
	private G6KeibisakiInfoMapper g6KeibisakiInfoMapper;
	@Autowired
	private GhsKeibisakiInfoMapper ghsKeibisakiInfoMapper;
	@Autowired
	private G5KeibisakiInfoMapper g5KeibisakiInfoMapper;

	@Transactional(propagation = Propagation.REQUIRED)
	public Map<String, Object> getG6UserInfo(Map<String, Object> param) {
		Map<String, Object> result = new HashMap<String, Object>();
		result = g6KeibisakiInfoMapper.selectG6ACnt(param);
		// 次期のログイン情報が存在する場合
		if (result != null) {
			// 取得したG6のログイン情報:アカウント論理番号をパラメータに設定
			param.put("G6_ACNT_NO", result.get("G6_ACNT_NO"));

			// 取得した次期のログイン情報のメールアドレスをパラメータに設定
			param.put("ML_ADDR", result.get("ML_ADDR"));

			// 次期のログイン情報のGVアカウント論理番号をパラメータに設定
			param.put("G5_ACNT_NO", result.get("G5_ACNT_NO"));

			return result;
		} else {
			return new HashMap<String, Object>();
		}
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public Map<String, Object> getGhsUserInfo(Map<String, Object> param) {
		Map<String, Object> result = new HashMap<String, Object>();
		result = ghsKeibisakiInfoMapper.selectGhsACnt(param);
		// 次期のログイン情報が存在する場合
		if (result != null) {
			// 取得したGHSのログイン情報：アカウント論理番号をパラメータに設定
			param.put("GHS_ACNT_NO", result.get("GHS_ACNT_NO"));
			// 取得したGHSのログイン情報：メールアドレスをパラメータに設定
			param.put("ML_ADDR", result.get("ML_ADDR"));

			return result;
		} else {
			return new HashMap<String, Object>();
		}
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public Map<String, Object> getG5UserInfo(Map<String, Object> param) {
		Map<String, Object> result = g5KeibisakiInfoMapper.selectG5ACnt(param);
		if (result != null) {
			return result;
		} else {
			return new HashMap<String, Object>();
		}
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public List<KeibisakiInfoDto> getG6KeibisakiInfo(Map<String, Object> param) {
		return g6KeibisakiInfoMapper.selectG6KeibisakiInfo(param);
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public List<KeibisakiInfoDto> getGhsKeibisakiInfo(Map<String, Object> param) {
		return ghsKeibisakiInfoMapper.selectGhsKeibisakiInfo(param);
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public List<KeibisakiInfoDto> getG5KeibisakiInfo(Map<String, Object> param) {
		return g5KeibisakiInfoMapper.selectG5KeibisakiInfo(param);
	}
}
