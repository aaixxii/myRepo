package jp.co.alsok.g6.zzw.web.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import jp.co.alsok.g6.common.exception.IllegalParameterException;
import jp.co.alsok.g6.zzw.util.StringUtil;
import jp.co.alsok.g6.zzw.web.constants.CommonComponentConstants;
import jp.co.alsok.g6.zzw.web.constants.DbAccessConstants.DB_ACCESS_FLG;
import jp.co.alsok.g6.zzw.web.constants.MassageConstants;
import jp.co.alsok.g6.zzw.web.dao.mapper.g6.CommonHLogAlsokUserOperationMapper;
import jp.co.alsok.g6.zzw.web.dao.mapper.g6.CommonHUserOperationLogMapper;
import jp.co.alsok.g6.zzw.web.dto.AlsokAccountInfoDto;
import jp.co.alsok.g6.zzw.web.dto.HLogAlsokUserOperationDto;
import jp.co.alsok.g6.zzw.web.dto.HUserOperationLogDto;
import jp.co.alsok.g6.zzw.web.dto.KeiyakuUserInfoDto;
import jp.co.alsok.g6.zzw.web.entity.g6.HLogAlsokUserOperation;
import jp.co.alsok.g6.zzw.web.entity.g6.HUserOperationLog;


/**
 * 共通関数 - 操作履歴出力部品Service
 */
@Service
public class OperationHistoryService {

	/** 論理番号取得部品 */
    @Autowired
	private DbUtilityG6WebCommonService dbUtility;

    // ALSOK操作履歴Mapper
    @Autowired
    private CommonHLogAlsokUserOperationMapper commonHLogAlsokUserOperationMapper;
    // 利用者操作履歴Mapper
    @Autowired
    private CommonHUserOperationLogMapper commonHUserOperationLogMapper;
    // DB共通項目設定Service
    @Autowired
    private EntityUtilReflectionService entityUtilReflectionService;

    /**
     * ALSOC操作履歴テーブルに登録します.
     *
     * @param HLogAlsokUserOperationDto ALSOK操作履歴 パラメータDTO
     * @param alsokAccountInfoDto 次期(G6)、GHS、GVのALSOKアカウント論理番号を格納したDto
     * @throws Exception
     * @throws IOException
     * @throws UnsupportedEncodingException
     * @throws FileNotFoundException
     */
	@Transactional(propagation = Propagation.REQUIRED)
    public void alsokUserOperation(HLogAlsokUserOperationDto hLogAlsokUserOperationDto
                                             , AlsokAccountInfoDto alsokAccountInfoDto)
                                               throws FileNotFoundException, UnsupportedEncodingException, IOException, Exception {
        // 必須チェック
        String errMsgHissu = isNullParamsAlsok(hLogAlsokUserOperationDto);
        if (StringUtil.isNotNullOrEmpty(errMsgHissu)) {
            throw new IllegalParameterException(errMsgHissu + MassageConstants.LZWO0200);
        }

        // 桁数チェック
        String errMsgKeta = lengthCheck(hLogAlsokUserOperationDto);
        if (StringUtil.isNotNullOrEmpty(errMsgKeta)) {
            throw new IllegalParameterException(errMsgKeta + MassageConstants.LZWO0201);
        }

        // ALSOC操作履歴Entityに設定
        HLogAlsokUserOperation entity = this.setEntityParam(hLogAlsokUserOperationDto, alsokAccountInfoDto);
        // ALSOC操作履歴テーブル登録
        commonHLogAlsokUserOperationMapper.insert(entity);
    }

    /**
     * 利用者操作履歴テーブルに登録します。
     *
     * @param hUserOperationLogDto 利用者操作履歴 パラメータDTO
     * @param lnAcntUserCommon DB共通項目設定 (LN_利用者アカウント共通論理番号)
     * @param acntNm DB共通項目設定 (アカウント名称)
     * @throws Exception
     * @throws IOException
     * @throws UnsupportedEncodingException
     * @throws FileNotFoundException
     */
	@Transactional(propagation = Propagation.REQUIRED)
    public void entryUserOperation(HUserOperationLogDto hUserOperationLogDto
                                  , String lnAcntUserCommon
                                  , String acntNm) throws FileNotFoundException, UnsupportedEncodingException, IOException, Exception {
        // 必須チェック
        String errMsgHissu = isNullParamsUser(hUserOperationLogDto);
        if (StringUtil.isNotNullOrEmpty(errMsgHissu)) {
            throw new IllegalParameterException(errMsgHissu + MassageConstants.LZWO0200);
        }

        // 桁数チェック
        String errMsgKeta = this.lengthCheck(hUserOperationLogDto);
        if (StringUtil.isNotNullOrEmpty(errMsgKeta)) {
            throw new IllegalParameterException(errMsgKeta + MassageConstants.LZWO0201);
        }

        // 利用者操作履歴Entityに設定
        HUserOperationLog entity = this.setEntityParam(hUserOperationLogDto,lnAcntUserCommon, acntNm);
        // 利用者操作履歴テーブル登録
        commonHUserOperationLogMapper.insert(entity);
    }

    /**
     * 運用管理サイト 入力項目の必須チェック
     *
     * @param hLogAlsokUserOperationDto
     * @return 必須チェックエラーの項目名
     */
    private String isNullParamsAlsok(HLogAlsokUserOperationDto hLogAlsokUserOperationDto) {

        // 返却値
        String result = "";
        // 必須項目の取得
        String lnAcntAlsok = hLogAlsokUserOperationDto.getLN_ALSOK_USER_OPERATION();
        String userNm = hLogAlsokUserOperationDto.getUSER_NM();
        String dispId = hLogAlsokUserOperationDto.getDISP_ID();
        String alsokOparationNaiyoCd = hLogAlsokUserOperationDto.getALSOK_OPERATION_NAIYOU_CD();

        // LN_ALSOK操作履歴論理番号 必須チェック
        if (StringUtil.isNullOrEmpty(lnAcntAlsok)) {
            return MassageConstants.LN_ALSOK_USER_OPERATION + ":";
        }
        // 氏名（社員名／ユーザー氏名） 必須チェック
        if (StringUtil.isNullOrEmpty(userNm)) {
            return MassageConstants.USER_NM_ALSOK + ":";
        }
        // 操作画面ID 必須チェック
        if (StringUtil.isNullOrEmpty(dispId)) {
            return MassageConstants.DISP_ID_ALSOK + ":";
        }
        // 操作内容コード 必須チェック
        if (StringUtil.isNullOrEmpty(alsokOparationNaiyoCd)) {
            return MassageConstants.ALSOK_OPERATION_NAIYOU_CD + ":";
        }
        // 必須チェック正常
        return result;
    }

    /**
     * 利用者サイト 入力項目の必須チェック
     *
     * @param hUserOperationLogDto 利用者操作履歴 パラメータDTO
     * @return 必須チェックエラーの項目名
     */
    private String isNullParamsUser(HUserOperationLogDto hUserOperationLogDto) {

        // 返却値
        String result = "";
        // 必須項目の取得
        String lnKeiyk = hUserOperationLogDto.getLN_KEIYK();
        String lnLogUserOperation = hUserOperationLogDto.getLN_LOG_USER_OPERATION();
        String userNm = hUserOperationLogDto.getUSER_NM();
        String acntUserKbn = hUserOperationLogDto.getACNT_USER_KBN();
        String dispId = hUserOperationLogDto.getDISP_ID();
        String userOperationNaiyouCd = hUserOperationLogDto.getUSER_OPERATION_NAIYOU_CD();

        // LN_契約先論理番号
        if (StringUtil.isNullOrEmpty(lnKeiyk)) {
            return MassageConstants.LN_KEIYK + ":";
        }
        // LN_利用者操作履歴論理番号
        if (StringUtil.isNullOrEmpty(lnLogUserOperation)) {
            return MassageConstants.LN_LOG_USER_OPERATION + ":";
        }
        // 氏名（社員名／ユーザー氏名）
        if (StringUtil.isNullOrEmpty(userNm)) {
            return MassageConstants.USER_NM_USER + ":";
        }
        // 利用者アカウント区分
        if (StringUtil.isNullOrEmpty(acntUserKbn)) {
            return MassageConstants.ACNT_USER_KBN + ":";
        }
        // 操作画面ID
        if (StringUtil.isNullOrEmpty(dispId)) {
            return MassageConstants.DISP_ID_USER + ":";
        }
        // 操作内容コード
        if (StringUtil.isNullOrEmpty(userOperationNaiyouCd)) {
            return MassageConstants.USER_OPERATION_NAIYOU_CD + ":";
        }
        // 必須チェック正常
        return result;
    }

    /**
     * 桁数チェック処理
     *
     * @param paramDto ALSOK操作履歴 パラメータDTO
     * @return 桁数チェックエラーの項目名
     */
    private String lengthCheck(Object paramDto) {

        // Alsokアカウントの場合
        if(paramDto instanceof HLogAlsokUserOperationDto) {
            return this.isAlsokUserOperationParam((HLogAlsokUserOperationDto) paramDto);
        }
        // 操作者アカウントの場合
        return this.isHuserOperationLogParam((HUserOperationLogDto) paramDto);
    }

    /**
     * ALSOK操作履歴 パラメータ の桁数チェック処理
     *
     * @param hLogAlsokUserOperationDto ALSOK操作履歴 パラメータDTO
     * @return 桁数チェックエラーの項目名
     */
    private String isAlsokUserOperationParam(HLogAlsokUserOperationDto paramDto){

        String result = "";
        // LN_ALSOK操作履歴論理番号 桁数チェック
        if (StringUtil.isNotNullOrEmpty(paramDto.getLN_ALSOK_USER_OPERATION())) {
            if (paramDto.getLN_ALSOK_USER_OPERATION().length() >
                                 paramDto.getLN_ALSOK_USER_OPERATION_SIZE()) {

                 return MassageConstants.LN_ALSOK_USER_OPERATION;
             }
        }
        // 警備先名称  桁数チェック
        if (StringUtil.isNotNullOrEmpty(paramDto.getKEIBI_NM())) {
            if (paramDto.getKEIBI_NM().length() > paramDto.getKEIBI_NM_SIZE()) {

                return MassageConstants.KEIBI_NM_ALSOK;
             }
        }
        // お客様番号２  桁数チェック
        if (StringUtil.isNotNullOrEmpty(paramDto.getCUSTOMER_NUM2())) {
            if (paramDto.getCUSTOMER_NUM2().length() > paramDto.getCUSTOMER_NUM2_SIZE()) {

                return MassageConstants.CUSTOMER_NUM2;
             }
        }
        //  警備先地区名称（SD_個別名称）  桁数チェック
        if (StringUtil.isNotNullOrEmpty(paramDto.getSD_KOBETU_NM())) {
            if (paramDto.getSD_KOBETU_NM().length() > paramDto.getSD_KOBETU_NM_SIZE()) {

                return MassageConstants.SD_KOBETU_NM_ALSOK;
             }
        }
        // 氏名（社員名／ユーザー氏名）   桁数チェック
        if (StringUtil.isNotNullOrEmpty(paramDto.getUSER_NM())) {
            if (paramDto.getUSER_NM().length() > paramDto.getUSER_NM_SIZE()) {

                return MassageConstants.USER_NM_ALSOK;
             }
        }
        // 操作画面ID 桁数チェック
        if (StringUtil.isNotNullOrEmpty(paramDto.getDISP_ID())) {
            if (paramDto.getDISP_ID().length() > paramDto.getDISP_ID_SIZE()) {

                return MassageConstants.DISP_ID_ALSOK;
            }
        }
        // 操作内容コード 桁数チェック
        if (StringUtil.isNotNullOrEmpty(paramDto.getALSOK_OPERATION_NAIYOU_CD())) {
            if (paramDto.getALSOK_OPERATION_NAIYOU_CD().length() >
                                    paramDto.getALSOK_OPERATION_NAIYOU_CD_SIZE()) {

                return MassageConstants.ALSOK_OPERATION_NAIYOU_CD;
            }
        }
        // 操作内容コード 桁数チェック
        if (StringUtil.isNotNullOrEmpty(paramDto.getALSOK_OPERATION_NAIYOU())) {
            if (paramDto.getALSOK_OPERATION_NAIYOU().length() >
                                    paramDto.getALSOK_OPERATION_NAIYOU_SIZE()) {

                return MassageConstants.ALSOK_OPERATION_NAIYOU;
            }
        }
        // 桁数正常の場合
        return result;
    }

    /**
     * 操作者アカウント パラメータの桁数チェック処理
     *
     * @param paramDto 利用者操作履歴 パラメータDTO
     * @return 桁数チェックエラーの項目名
     */
    private String isHuserOperationLogParam(HUserOperationLogDto paramDto) {

        String result = "";
        // LN_契約先論理番号 桁数チェック
        if (StringUtil.isNotNullOrEmpty(paramDto.getLN_KEIYK())) {
            if (paramDto.getLN_KEIYK().length() >
                                    paramDto.getLN_KEIYK_SIZE()) {

                return MassageConstants.LN_KEIYK;
             }
        }
        // LN_利用者操作履歴論理番号 桁数チェック
        if (StringUtil.isNotNullOrEmpty(paramDto.getLN_LOG_USER_OPERATION())) {
            if (paramDto.getLN_LOG_USER_OPERATION().length() >
                                    paramDto.getLN_LOG_USER_OPERATION_SIZE()) {

                return MassageConstants.LN_LOG_USER_OPERATION;
             }
        }
        //
        // 操作日付（共通関数内で設定するためチェック不要）
        //
        // LN_警備先論理番号 桁数チェック
        if (StringUtil.isNotNullOrEmpty(paramDto.getLN_KEIBI())) {
            if (paramDto.getLN_KEIBI().length() >
                                    paramDto.getLN_KEIBI_SIZE()) {

                return MassageConstants.LN_KEIBI;
             }
        }
        // 警備先名称
        if (StringUtil.isNotNullOrEmpty(paramDto.getKEIBI_NM())) {
            if (paramDto.getKEIBI_NM().length() > paramDto.getKEIBI_NM_SIZE()) {

                return MassageConstants.KEIBI_NM_USER;
             }
        }
        // LN_警備先地区論理番号 桁数チェック
        if (StringUtil.isNotNullOrEmpty(paramDto.getLN_KB_CHIKU())) {
            if (paramDto.getLN_KB_CHIKU().length() >
                                    paramDto.getLN_KB_CHIKU_SIZE()) {

                return MassageConstants.LN_KB_CHIKU;
             }
        }
        // 警備先地区名称（SD_個別名称）
        if (StringUtil.isNotNullOrEmpty(paramDto.getSD_KOBETU_NM())) {
            if (paramDto.getSD_KOBETU_NM().length() > paramDto.getSD_KOBETU_NM_SIZE()) {

                return MassageConstants.SD_KOBETU_NM_USER;
             }
        }
        // 氏名（社員名／ユーザー氏名）
        if (StringUtil.isNotNullOrEmpty(paramDto.getUSER_NM())) {
            if (paramDto.getUSER_NM().length() > paramDto.getUSER_NM_SIZE()) {

                return MassageConstants.USER_NM_USER;
             }
        }
        // 操作者種別
        if (StringUtil.isNotNullOrEmpty(paramDto.getACNT_USER_KBN())) {
            if (paramDto.getACNT_USER_KBN().length() > paramDto.getACNT_USER_KBN_SIZE()) {

                return MassageConstants.ACNT_USER_KBN;
             }
        }
        // 操作画面ID
        if (StringUtil.isNotNullOrEmpty(paramDto.getDISP_ID())) {
            if (paramDto.getDISP_ID().length() > paramDto.getDISP_ID_SIZE()) {

                return MassageConstants.DISP_ID_USER;
             }
        }
        // 操作内容コード
        if (StringUtil.isNotNullOrEmpty(paramDto.getUSER_OPERATION_NAIYOU_CD())) {
            if (paramDto.getUSER_OPERATION_NAIYOU_CD().length() >
                                    paramDto.getUSER_OPERATION_NAIYOU_CD_SIZE()) {

                return MassageConstants.USER_OPERATION_NAIYOU_CD;
             }
        }
        // 内容
        if (StringUtil.isNotNullOrEmpty(paramDto.getUSER_OPERATION_NAIYOU())) {
            if (paramDto.getUSER_OPERATION_NAIYOU().length() >
                                    paramDto.getUSER_OPERATION_NAIYOU_SIZE()) {

                return MassageConstants.USER_OPERATION_NAIYOU;
             }
        }
        //
        // 備考（桁数オーバーの場合はカットして登録するため、チェック不要）
        //

        // 桁数正常の場合
        return result;
    }

    /**
     * ALSOC操作履歴Entitiyに設定処理を行う
     *
     * @param paramDto ALSOK操作履歴 パラメータDTO
     * @param alsokAccountInfoDto  次期(G6)、GHS、GVのALSOKアカウント論理番号を格納したDto
     * @return HLogAlsokUserOperation ALSOK操作履歴 Entity
     * @throws Exception
     * @throws IOException
     * @throws UnsupportedEncodingException
     * @throws FileNotFoundException
     */
    private HLogAlsokUserOperation setEntityParam(HLogAlsokUserOperationDto paramDto, AlsokAccountInfoDto alsokAccountInfoDto) throws FileNotFoundException, UnsupportedEncodingException, IOException, Exception {


		String operationHistorySequence = dbUtility.getLn(CommonComponentConstants.OPERATION_HISTORY_ALSOK_SEQUECE_ID);

        HLogAlsokUserOperation entitiy = new HLogAlsokUserOperation();
        // LN_ALSOK操作履歴論理番号
        entitiy.setLN_ALSOK_USER_OPERATION(operationHistorySequence);
        // 警備先名称
        entitiy.setKEIBI_NM(paramDto.getKEIBI_NM());
        // お客様番号２
        entitiy.setCUSTOMER_NUM2(paramDto.getCUSTOMER_NUM2());
        // 警備先地区名称（SD_個別名称）
        entitiy.setSD_KOBETU_NM(paramDto.getSD_KOBETU_NM());
        // 氏名（社員名／ユーザー氏名）
        entitiy.setUSER_NM(paramDto.getUSER_NM());
        // 操作画面ID
        entitiy.setDISP_ID(paramDto.getDISP_ID());
        // 操作内容コード
        entitiy.setALSOK_OPERATION_NAIYOU_CD(paramDto.getALSOK_OPERATION_NAIYOU_CD());
        // 内容
        entitiy.setALSOK_OPERATION_NAIYOU(paramDto.getALSOK_OPERATION_NAIYOU());

        // 共通関数を基にDB共通項目を設定(Alsokアカウントの場合)
        entityUtilReflectionService.setCommonParameterG6DateOverride(DB_ACCESS_FLG.INSERT, entitiy, alsokAccountInfoDto);
        return entitiy;
    }

    /**
     * 利用者操作履歴Entitiyに設定処理を行う
     *
     * @param paramDto 利用者操作履歴 パラメータDTO
     * @param lnAcntUserCommon ALSOKアカウント論理番号
     * @param acntNm ALSOKアカウント名
     * @return HUserOperationLog 利用者操作履歴Entitiy
     * @throws Exception
     * @throws IOException
     * @throws UnsupportedEncodingException
     * @throws FileNotFoundException
     */
    private HUserOperationLog setEntityParam(HUserOperationLogDto paramDto, String lnAcntUserCommon, String acntNm) throws FileNotFoundException, UnsupportedEncodingException, IOException, Exception {

		String operationHistorySequence = dbUtility.getLn(CommonComponentConstants.OPERATION_HISTORY_USER_SEQUECE_ID);

        HUserOperationLog entity = new HUserOperationLog();
        // LN_契約先論理番号
        entity.setLnKeiyk(paramDto.getLN_KEIYK());
        // LN_利用者操作履歴論理番号
        entity.setLnLogUserOperation( operationHistorySequence );
        // LN_操作日付
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        entity.setUseDay(sdf.format(new Date()));
        // LN_警備先論理番号
        entity.setLnKeibi(paramDto.getLN_KEIBI());
        // 警備先名称
        entity.setKeibiNm(paramDto.getKEIBI_NM());
        // LN_警備先地区論理番号
        entity.setLnKbChiku(paramDto.getLN_KB_CHIKU());
        // 警備先地区名称（SD_個別名称）
        entity.setSdKobetuNm(paramDto.getSD_KOBETU_NM());
        // 氏名（社員名／ユーザー氏名）
        entity.setUserNm(paramDto.getUSER_NM());
        // 操作画面ID
        entity.setDispId(paramDto.getDISP_ID());
        // 操作内容コード
        entity.setUserOperationNaiyouCd(paramDto.getUSER_OPERATION_NAIYOU_CD());
        // 内容
        entity.setUserOperationNaiyou(paramDto.getUSER_OPERATION_NAIYOU());
        // 利用者アカウント区分
        entity.setAcntUserKbn(paramDto.getACNT_USER_KBN());
        // 備考
        String tmpBikou = paramDto.getBIKOU();
        if(StringUtil.isNotNullOrEmpty(tmpBikou) && tmpBikou.length() > paramDto.getBIKOU_SIZE()) {
        	tmpBikou = tmpBikou.substring(0, paramDto.getBIKOU_SIZE());
        }
        entity.setBikou(tmpBikou);

        KeiyakuUserInfoDto userInfoDto = new KeiyakuUserInfoDto();
        userInfoDto.setG6LnAcntAlsokNo(lnAcntUserCommon);
        userInfoDto.setG6LnAcntAlsokName(acntNm);

        // 共通関数を基にDB共通項目を設定(利用者アカウントの場合)
        entityUtilReflectionService.setCommonParameterG6DateOverride(DB_ACCESS_FLG.INSERT, entity, userInfoDto);
        return entity;
    }
}
