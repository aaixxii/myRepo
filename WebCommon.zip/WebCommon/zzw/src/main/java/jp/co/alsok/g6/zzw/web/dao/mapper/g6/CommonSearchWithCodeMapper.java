package jp.co.alsok.g6.zzw.web.dao.mapper.g6;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

/**
 * コード検索テキストボックス用のMapperクラスです
 * @author SNG
 *
 */
@Mapper
public interface CommonSearchWithCodeMapper {

    // **************************
    // 監視巡回サイト、運用サイト共通のコード検索
    // **************************
    /**
     * ガードセンター.GC名称を、GCコードを基に取得する.
     *
     * @param gcCd GCコード
     * @return gcNm GC名称
     */
    List<Map<String, String>> selectGcNmByCode(String gcCd);

    /**
     * 契約先.事業所.事業所名称 を 、事業所コードを基に取得する.
     *
     * @param reasonId 事業所コード
     * @return jigyouNm 事業所.事業所名称
     */
    List<Map<String, String>> selectJigyouNmByCode(String jigyouCd);

    // **************************
    // 監視巡回サイトのコード検索
    // **************************
    /**
     * G6 判断理由マスタ.内容を、判断理由IDを基に取得する.
     *
     * @param reasonId 判断理由ID
     * @return reasonNaiyou G6内容
     */
    List<Map<String, String>> selectReasonNaiyouByCode(String reasonId);

    /**
     * GV 判断理由マスタ.内容を、判断理由IDを基に取得する.
     *
     * @param idReason 判断理由ID
     * @return naiyou GV内容
     */
    List<Map<String, String>> selectReasonNaiyouGVByCode(String idReason);

    /**
     * 原因マスター.原因内容を、原因IDを基に、内容を取得する.
     *
     * @param geninId 原因ID
     * @return geninNaiyou 原因内容
     */
    List<Map<String, String>> selectGeninNaiyouByCode(String geninId);

    /**
     * V6事案分類コードファイル.内容を、ID事案分類コードを基に取得する.
     *
     * @param reasonId ID事案分類コード
     * @return jianbnrcdNaiyou 内容
     */
    List<Map<String, String>> selectJianbnrcdNaiyouByCode(String idJianbnrCd);

    /**
     * V6警報分類コード.内容IDを、警報分類コードを基に取得する.
     *
     * @param idKeihobnrcd ID_警報分類コード
     * @return 内容
     */
    List<Map<String, String>> selectV6KeihobnrcdNaiyouByCode(String idKeihobnrcd);

    /**
     * V6原因分類コード.内容を、判断ID_原因分類コードを基に取得する.
     *
     * @param reasonId 判断ID_原因分類コード
     * @return v6GenbnrcdNaiyou 内容
     */
    List<Map<String, String>> selectV6GenbnrcdNaiyouByCode(String idGenbnrcd);

    // **************************
    // 運用サイトのコード検索
    // **************************
    /**
     * 警備先.「警備先名1＋警備先名2」を お客様番号２を基に取得する.
     *
     * @param customerNum2 お客様番号２
     * @return 「警備先名1＋警備先名2」
     */
    List<Map<String, String>> selectKeibiNameByCode(String customerNum2);

    /**
     * 警備先.警備先略称名称 を お客様番号２を基に取得する.
     *
     * @param customerNum2 入力コード値
     * @return keibisakiAbbrNm 警備先略称名称
     */
    List<Map<String, String>> selectKeibisakiAbbrNmByCode(String customerNum2);

    /**
     *  契約先.契約先名称を 契約先コードを基に取得する.
     *
     * @param keiykCd 契約先コード
     * @return keiykNm 契約先名称
     */
    List<Map<String, String>> selectKeiykNmByCode(String keiykCd);

    // **************************
    // < 住所を取得 >
    // **************************
    /**
     *  住所マスター.住所を (都道府県名)を基に取得する.
     *
     * @param addrNm1 (都道府県名名)
     * @return jyusyo 契約先名称
     */
    List<Map<String, String>> selectJyusyoAddrCd1ByCode(Map<String, Object> param);

    /**
     *  住所マスター.住所を (都道府県名,市区町村名)を基に取得する.
     *
     * @param addrNm1～addrNm2 (都道府県名,市区町村名)
     * @return jyusyo 契約先名称
     */
    List<Map<String, String>> selectJyusyoAddrCd2ByCode(Map<String, Object> param);

    /**
     *  住所マスター.住所を (都道府県名,市区町村名,大字町名)を基に取得する.
     *
     * @param addrNm1～addrNm3 (都道府県名,市区町村名,大字町名)
     * @return jyusyo 契約先名称
     */
    List<Map<String, String>> selectJyusyoAddrCd3ByCode(Map<String, Object> param);

    /**
     *  住所マスター.住所を (都道府県名,市区町村名,大字町名,小字町名)を基に取得する.
     *
     * @param addrNm1～addrNm4 (都道府県名,市区町村名,大字町名,小字町名)
     * @return jyusyo 契約先名称
     */
    List<Map<String, String>> selectJyusyoAddrCd4ByCode(Map<String, Object> param);

    /**
     *  住所マスター.住所を (都道府県名,市区町村名,大字町名,小字町名,丁目名)を基に取得する.
     *
     * @param addrNm1～addrNm5 (都道府県名,市区町村名,大字町名,小字町名,丁目名)
     * @return jyusyo 契約先名称
     */
    List<Map<String, String>> selectJyusyoAddrCd5ByCode(Map<String, Object> param);

    /**
     *  住所マスター.住所を (都道府県名,市区町村名,大字町名,小字町名,丁目名,番地名)を基に取得する.
     *
     * @param addrNm1～addrNm6 (都道府県名,市区町村名,大字町名,小字町名,丁目名,番地名)
     * @return jyusyo 契約先名称
     */
    List<Map<String, String>> selectJyusyoAddrCd6ByCode(Map<String, Object> param);

    // **************************
    // < 住所(カナ)を取得 >
    // **************************
    /**
     *  住所マスター.住所を (都道府県名)を基に取得する.
     *
     * @param addrNm1 (都道府県名名)
     * @return jyusyo 契約先名称
     */
    List<Map<String, String>> selectJyusyoAddrCd1KanaByCode(Map<String, Object> param);

    /**
     *  住所マスター.住所を (都道府県名,市区町村名)を基に取得する.
     *
     * @param addrNm1～addrNm2 (都道府県名,市区町村名)
     * @return jyusyo 契約先名称
     */
    List<Map<String, String>> selectJyusyoAddrCd2KanaByCode(Map<String, Object> param);

    /**
     *  住所マスター.住所を (都道府県名,市区町村名,大字町名)を基に取得する.
     *
     * @param addrNm1～addrNm3 (都道府県名,市区町村名,大字町名)
     * @return jyusyo 契約先名称
     */
    List<Map<String, String>> selectJyusyoAddrCd3KanaByCode(Map<String, Object> param);

    /**
     *  住所マスター.住所を (都道府県名,市区町村名,大字町名,小字町名)を基に取得する.
     *
     * @param addrNm1～addrNm4 (都道府県名,市区町村名,大字町名,小字町名)
     * @return jyusyo 契約先名称
     */
    List<Map<String, String>> selectJyusyoAddrCd4KanaByCode(Map<String, Object> param);

    /**
     *  住所マスター.住所を (都道府県名,市区町村名,大字町名,小字町名,丁目名)を基に取得する.
     *
     * @param addrNm1～addrNm5 (都道府県名,市区町村名,大字町名,小字町名,丁目名)
     * @return jyusyo 契約先名称
     */
    List<Map<String, String>> selectJyusyoAddrCd5KanaByCode(Map<String, Object> param);

    /**
     *  住所マスター.住所を (都道府県名,市区町村名,大字町名,小字町名,丁目名,番地名)を基に取得する.
     *
     * @param addrNm1～addrNm6 (都道府県名,市区町村名,大字町名,小字町名,丁目名,番地名)
     * @return jyusyo 契約先名称
     */
    List<Map<String, String>> selectJyusyoAddrCd6KanaByCode(Map<String, Object> param);
}
