package jp.co.alsok.g6.zzw.web.dto;

/**
 * ALSOK操作履歴 パラメータDTO
  * (ALSOK操作履歴 登録用 DTO)
 */
public class HLogAlsokUserOperationDto {

    /** LN_ALSOK操作履歴論理番号 */
    private String LN_ALSOK_USER_OPERATION;
    /** 警備先名称 */
    private String KEIBI_NM;
    /** お客様番号２ */
    private String CUSTOMER_NUM2;
    /** 警備先地区名称（SD_個別名称） */
    private String SD_KOBETU_NM;
    /** 氏名（社員名／ユーザー氏名） */
    private String USER_NM;
    /** 操作画面ID */
    private String DISP_ID;
    /** 操作内容コード */
    private String ALSOK_OPERATION_NAIYOU_CD;
    /** 内容 */
    private String ALSOK_OPERATION_NAIYOU;

    /**
     * LN_ALSOK操作履歴論理番号
     * @return lN_ALSOK_USER_OPERATION
     */
    public String getLN_ALSOK_USER_OPERATION() {
        return LN_ALSOK_USER_OPERATION;
    }
    /**
     * LN_ALSOK操作履歴論理番号 ※必須項目
     * @param lN_ALSOK_USER_OPERATION セットする lN_ALSOK_USER_OPERATION
     */
    public void setLN_ALSOK_USER_OPERATION(String lN_ALSOK_USER_OPERATION) {
        LN_ALSOK_USER_OPERATION = lN_ALSOK_USER_OPERATION;
    }
    /**
     * 警備先名称
     * @return kEIBI_NM
     */
    public String getKEIBI_NM() {
        return KEIBI_NM;
    }
    /**
     * 警備先名称
     * @param kEIBI_NM セットする kEIBI_NM
     */
    public void setKEIBI_NM(String kEIBI_NM) {
        KEIBI_NM = kEIBI_NM;
    }
    /**
     * お客様番号２
     * @return cUSTOMER_NUM2
     */
    public String getCUSTOMER_NUM2() {
        return CUSTOMER_NUM2;
    }
    /**
     * お客様番号２
     * @param cUSTOMER_NUM2 セットする cUSTOMER_NUM2
     */
    public void setCUSTOMER_NUM2(String cUSTOMER_NUM2) {
        CUSTOMER_NUM2 = cUSTOMER_NUM2;
    }
    /**
     * 警備先地区名称（SD_個別名称）
     * @return sD_KOBETU_NM
     */
    public String getSD_KOBETU_NM() {
        return SD_KOBETU_NM;
    }
    /**
     * 警備先地区名称（SD_個別名称）
     * @param sD_KOBETU_NM セットする sD_KOBETU_NM
     */
    public void setSD_KOBETU_NM(String sD_KOBETU_NM) {
        SD_KOBETU_NM = sD_KOBETU_NM;
    }
    /**
     * 氏名（社員名／ユーザー氏名）
     * @return uSER_NM
     */
    public String getUSER_NM() {
        return USER_NM;
    }
    /**
     * 氏名（社員名／ユーザー氏名） ※必須項目
     * @param uSER_NM セットする uSER_NM
     */
    public void setUSER_NM(String uSER_NM) {
        USER_NM = uSER_NM;
    }
    /**
     * 操作画面ID
     * @return dISP_ID
     */
    public String getDISP_ID() {
        return DISP_ID;
    }
    /**
     * 操作画面ID ※ 必須項目
     * @param dISP_ID セットする dISP_ID
     */
    public void setDISP_ID(String dISP_ID) {
        DISP_ID = dISP_ID;
    }
    /**
     * 操作内容コード
     * @return aLSOK_OPERATION_NAIYOU_CD
     */
    public String getALSOK_OPERATION_NAIYOU_CD() {
        return ALSOK_OPERATION_NAIYOU_CD;
    }
    /**
     * 操作内容コード ※ 必須項目
     * @param aLSOK_OPERATION_NAIYOU_CD セットする aLSOK_OPERATION_NAIYOU_CD
     */
    public void setALSOK_OPERATION_NAIYOU_CD(String aLSOK_OPERATION_NAIYOU_CD) {
        ALSOK_OPERATION_NAIYOU_CD = aLSOK_OPERATION_NAIYOU_CD;
    }
    /*
     * 内容*
     * @return aLSOK_OPERATION_NAIYOU
     */
    public String getALSOK_OPERATION_NAIYOU() {
        return ALSOK_OPERATION_NAIYOU;
    }
    /**
     * 内容
     * @param aLSOK_OPERATION_NAIYOU セットする aLSOK_OPERATION_NAIYOU
     */
    public void setALSOK_OPERATION_NAIYOU(String aLSOK_OPERATION_NAIYOU) {
        ALSOK_OPERATION_NAIYOU = aLSOK_OPERATION_NAIYOU;
    }

    // **************************************
    // HLogAlsokUserOperation テーブルのカラムサイズを取得
    // **************************************
    /** LN_ALSOK操作履歴論理番号 サイズ*/
    private int LN_ALSOK_USER_OPERATION_SIZE = 20;
    /** 警備先名称 サイズ*/
    private int KEIBI_NM_SIZE = 60;
    /** お客様番号２ サイズ*/
    private int CUSTOMER_NUM2_SIZE = 9;
    /** 警備先地区名称（SD_個別名称） サイズ*/
    private int SD_KOBETU_NM_SIZE = 40;
    /** 氏名（社員名／ユーザー氏名） サイズ*/
    private int USER_NM_SIZE = 20;
    /** 操作画面ID サイズ*/
    private int DISP_ID_SIZE = 10;
    /** 操作内容コード サイズ*/
    private int ALSOK_OPERATION_NAIYOU_CD_SIZE = 2;
    /** 内容 サイズ*/
    private int ALSOK_OPERATION_NAIYOU_SIZE = 40;

    /**
     * LN_ALSOK操作履歴論理番号 サイズ
     * @return lN_ALSOK_USER_OPERATION_SIZE
     */
    public int getLN_ALSOK_USER_OPERATION_SIZE() {
        return LN_ALSOK_USER_OPERATION_SIZE;
    }
    /**
     * 警備先名称 サイズ
     * @return kEIBI_NM_SIZE
     */
    public int getKEIBI_NM_SIZE() {
        return KEIBI_NM_SIZE;
    }
    /**
     * お客様番号２ サイズ
     * @return cUSTOMER_NUM2_SIZE
     */
    public int getCUSTOMER_NUM2_SIZE() {
        return CUSTOMER_NUM2_SIZE;
    }
    /**
     * 警備先地区名称（SD_個別名称） サイズ
     * @return sD_KOBETU_NM_SIZE
     */
    public int getSD_KOBETU_NM_SIZE() {
        return SD_KOBETU_NM_SIZE;
    }
    /**
     * 氏名（社員名／ユーザー氏名） サイズ
     * @return uSER_NM_SIZE
     */
    public int getUSER_NM_SIZE() {
        return USER_NM_SIZE;
    }
    /**
     * 操作画面ID サイズ
     * @return dISP_ID_SIZE
     */
    public int getDISP_ID_SIZE() {
        return DISP_ID_SIZE;
    }
    /**
     * 操作内容コード サイズ
     * @return aLSOK_OPERATION_NAIYOU_CD_SIZE
     */
    public int getALSOK_OPERATION_NAIYOU_CD_SIZE() {
        return ALSOK_OPERATION_NAIYOU_CD_SIZE;
    }
    /**
     * 内容 サイズ
     * @return aLSOK_OPERATION_NAIYOU_SIZE
     */
    public int getALSOK_OPERATION_NAIYOU_SIZE() {
        return ALSOK_OPERATION_NAIYOU_SIZE;
    }
}
