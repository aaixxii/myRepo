package jp.co.alsok.g6.zzw.web.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

import org.springframework.stereotype.Service;

import jp.co.alsok.g6.common.util.db.DbUtility;

/**
 * 論理番号取得クラス
 * 内部処理でDbUtilityを呼び出し保持することによってDBのコネクションを節約します。
 *
 * @author NEC
 *
 */
@Service
class DbUtilityG6WebCommonService {

	private DbUtility g6DbUtility;

	public DbUtilityG6WebCommonService() throws FileNotFoundException, UnsupportedEncodingException, IOException, Exception {
	    if (g6DbUtility == null) {
            this.g6DbUtility = new DbUtility();
	    }
	}

	/**
	 * DbUtility.getLn(String key)を呼び出し、論理番号を返却します。
	 *
	 * @param key
	 * @return
	 * @throws FileNotFoundException
	 * @throws UnsupportedEncodingException
	 * @throws IOException
	 * @throws Exception
	 */
	public String getLn(String key) throws FileNotFoundException, UnsupportedEncodingException, IOException, Exception {

		synchronized (g6DbUtility) {
			if (!this.g6DbUtility.isConnected()) {
				this.g6DbUtility.connect();
			}
		}
		String ln = g6DbUtility.getLn(key);
		g6DbUtility.close();
		return ln;
	}

}
