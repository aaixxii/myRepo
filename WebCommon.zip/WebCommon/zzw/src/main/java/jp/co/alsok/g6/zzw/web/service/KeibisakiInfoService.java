/**
 *
 */
package jp.co.alsok.g6.zzw.web.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.alsok.g6.zzw.util.StringUtil;
import jp.co.alsok.g6.zzw.web.dto.KeibisakiInfoDto;

/**
 * G5, 次期(G6), GHSの警備先情報取得 Service
 *
 * @author SNG
 */
@Service
public class KeibisakiInfoService {

	/** ログインユーザ検索DBフラグ(全て) */
	private static final int systemAll = 0;
	/** ログインユーザ検索DBフラグ(次期) */
	private static final int systemG6 = 1;
	/** ログインユーザ検索DBフラグ(GHS) */
	private static final int systemGhs = 2;
	/** ログインユーザ検索DBフラグ(GV) */
	private static final int systemGv = 3;
	/** ログインユーザ検索DBフラグ(次期、GHS) */
	private static final int systemG6Ghs = 4;
	/** ログインユーザ検索DBフラグ(次期、GV) */
	private static final int systemG6Gv = 5;
	/** ログインユーザ検索DBフラグ(ERROR:全てない場合) */
	private static final int systemError = 9;

	/** 検索DBフラグ(全て) */
	private static final int selectDbAll = 0;
	/** 検索DBフラグ(次期のみ) */
	private static final int selectDbG6 = 1;
	/** 検索DBフラグ(GHSのみ) */
	private static final int selectDbGhs = 2;

	/** 次期用:文字列「/」 */
	private static final String pathSlash = "/";

	/** 次期用:論理番号の桁数(20桁) */
	private static final int NUM_LENGTH = 20;

	/** 次期用:「/」の桁数(1桁) */
	private static final int PATH_SLASH_LENGTH = 1;

	/** 次期用:パス情報の桁数(警備先論理番号)41桁 */
	private static final int KEIBI_LENGTH = NUM_LENGTH + PATH_SLASH_LENGTH + NUM_LENGTH;

	@Autowired
	private UserAuthKeibisakiService UserAuthKeibisakiService;

	/**
	 * LN_利用者アカウント共通論理番号を基に警備先リストを取得する。
	 *
	 * @param systemId ログインシステムフラグ(1=次期、2=GHS)
	 * @param lnAcntUserCommon LN_利用者アカウント共通論理番号
	 * @param selectDbFlg 検索DBフラグ(0=全て(次期、GHS、GV)、1=次期、2=GHS)
	 * @return 警備先情報リスト
	 */
	public List<KeibisakiInfoDto> getKeibisakiInfo(int systemId,
			String lnAcntUserCommon, int selectDbFlg) {
		List<KeibisakiInfoDto> result = new ArrayList<KeibisakiInfoDto>();

		// ログインシステムフラグが「1」、「2」以外の場合、空のListを返却する
		if (systemId != systemG6 && systemId != systemGhs) {
			return result;
		}

		// LN_利用者アカウント共通論理番号がNULLの場合、空のListを返却する
		if (StringUtil.isNullOrEmpty(lnAcntUserCommon) || lnAcntUserCommon.length() != NUM_LENGTH) {
			return result;
		}

		// 検索DBフラグが「0」、「1」、「2」以外の場合、空のListを返却する
		if (selectDbFlg != selectDbAll && selectDbFlg != selectDbG6 && selectDbFlg != selectDbGhs) {
			return result;
		}

		// 取得対象DBフラグ
		int selectId;
		//抽出条件のパラメータ
		Map<String, Object> param = new HashMap<>();
		//アカウント論理番号を設定
		param.put("lnAcntUserCommon", lnAcntUserCommon);
		//ログインシステムフラグ設定
		param.put("systemId", systemId);

		//警備先取得時に参照するフラグとアカウント論値番号を設定
		selectId = this.getSelectId(systemId, selectDbFlg, param);

		if (selectId == systemError) {
			return result;
		}

		//警備先情報リストを取得
		result = this.selectKeibisakiInfo(selectId, selectDbFlg, param);

		return result;
	}

	/**
	 * LN_利用者アカウント共通論理番号を基に次期、GHS、GVからアカウント情報を取得する
	 * 引数selectDbFlgで取得対象のDBを限定します。
	 * <pre>
	 * 引数：ログインシステムフラグ
	 * systemId = 1：①次期のDBからアカウント論理番号、メールアドレス、G5のアカウント論理番号を取得して
	 *               GHSとGVのアカウント情報を取得し紐づけます。
	 * systemId = 2：GHSのDBからアカウント論理番号、メールアドレスを取得してG6、G5のアカウント情報を取得し紐づけます。
	 * </pre>
	 *
	 * @param systemId ログインシステムフラグ(1=次期、2=GHS)
	 * @param lnAcntUserCommon LN_利用者アカウント共通論理番号
	 * @param param 抽出条件
	 * @return 取得対象DBフラグ
	 */
	private int getSelectId(int systemId, int selectDbFlg, Map<String, Object> param) {
		// 次期システムのログインユーザ情報
		Map<String, Object> g6AcntInfo = new HashMap<String, Object>();
		// GHSシステムのログインユーザ情報
		Map<String, Object> ghsAcntInfo = new HashMap<String, Object>();
		// GVシステムのログインユーザ情報
		Map<String, Object> g5AcntInfo = new HashMap<String, Object>();

		// 次期でログインしている場合
		if (systemId == systemG6) {

			// 次期のログイン情報を取得
			g6AcntInfo = UserAuthKeibisakiService.getG6UserInfo(param);

			// 次期のログイン情報が存在するかつ、検索DBフラグが次期のみ以外の場合
			if (!g6AcntInfo.isEmpty() && selectDbFlg != selectDbG6) {

				// GHSのログイン情報を取得
				ghsAcntInfo = UserAuthKeibisakiService.getGhsUserInfo(param);
			}

			// 次期のログイン情報でアカウント種別:'GV'が存在するかつ、検索DBフラグがすべての場合
			if (!g6AcntInfo.isEmpty() && param.get("G5_ACNT_NO") != null
					&& selectDbFlg == selectDbAll) {

				// GVのログイン情報を取得
				g5AcntInfo = UserAuthKeibisakiService.getG5UserInfo(param);
			}

			// GHSでログインしている場合
		} else if (systemId == systemGhs) {

			// GHSのログイン情報を取得
			ghsAcntInfo = UserAuthKeibisakiService.getGhsUserInfo(param);

			// GHSのログイン情報が存在するかつ、検索DBフラグがGHSのみ以外の場合
			if (!ghsAcntInfo.isEmpty() && selectDbFlg != selectDbGhs) {
				// 次期のログイン情報を取得
				g6AcntInfo = UserAuthKeibisakiService.getG6UserInfo(param);
			}

			// 次期のログイン情報でアカウント種別:'GV'が存在するかつ、検索DBフラグがすべての場合
			if (!g6AcntInfo.isEmpty() && param.get("G5_ACNT_NO") != null
					&& selectDbFlg == selectDbAll) {

				// GVのログイン情報を取得
				g5AcntInfo = UserAuthKeibisakiService.getG5UserInfo(param);
			}
		}

		// 次期、GHS、GVが存在する場合
		if (!g6AcntInfo.isEmpty() && !ghsAcntInfo.isEmpty() && !g5AcntInfo.isEmpty()) {
			return systemAll;

		// 次期のみ存在する場合
		} else if (!g6AcntInfo.isEmpty() && ghsAcntInfo.isEmpty() && g5AcntInfo.isEmpty()) {
			return systemG6;

		// GHSのみ存在する場合
		} else if (g6AcntInfo.isEmpty() && !ghsAcntInfo.isEmpty() && g5AcntInfo.isEmpty()) {
			return systemGhs;

		// 次期とGHSが存在する場合
		} else if (!g6AcntInfo.isEmpty() && !ghsAcntInfo.isEmpty() && g5AcntInfo.isEmpty()) {
			return systemG6Ghs;

		// 次期とGVが存在する場合
		} else if (!g6AcntInfo.isEmpty() && ghsAcntInfo.isEmpty() && !g5AcntInfo.isEmpty()) {
			return systemG6Gv;

		// 上記以外の場合
		}else {
			return systemError;
		}
	}

	/**
	 * LN_利用者アカウント共通論理番号を基に次期、GHS、GVから警備先情報を取得する
	 * <pre>
	 * 引数：取得対象DBフラグ
	 * selectId = 0：G6、GHS、GVから警備先、警備先地区、契約先を取得します。
	 * selectId = 1：G6のみから警備先、警備先地区、契約先を取得します。
	 * selectId = 2：GHSのみから警備先、警備先地区、契約先を取得します。
	 * selectId = 4：G6、GHSから警備先、警備先地区、契約先を取得します。
	 * selectId = 5：G6、GVから警備先、警備先地区、契約先を取得します。
	 * </pre>
	 *
	 * @param selectId 取得対象DBフラグ
	 * @param param 抽出条件
	 * @return List<KeibisakiInfoDto>
	 */
	private List<KeibisakiInfoDto> selectKeibisakiInfo(int selectId, int selectDbFlg, Map<String, Object> param) {
		List<KeibisakiInfoDto> keibisakiInfo = new ArrayList<KeibisakiInfoDto>();
		// スラッシュ("/")を設定
		param.put("pathSlash", pathSlash);
		// 次期フラグを設定
		param.put("systemG6", systemG6);
		// GHSフラグを設定
		param.put("systemGhs", systemGhs);
		// GVフラグを設定
		param.put("systemGv", systemGv);
		// 警備先論理番号の桁数を設定
		param.put("KEIBI_LENGTH", KEIBI_LENGTH);
		// 論理番号の桁数を設定
		param.put("NUM_LENGTH", NUM_LENGTH);

		if (selectId != systemGhs && selectDbFlg != selectDbGhs) {
			// 次期の警備先情報を取得
			keibisakiInfo.addAll(UserAuthKeibisakiService.getG6KeibisakiInfo(param));
		}
		if (selectId != systemG6 && selectId != systemG6Gv && selectDbFlg != selectDbG6) {
			// GHSの警備先情報を取得
			keibisakiInfo.addAll(UserAuthKeibisakiService.getGhsKeibisakiInfo(param));
		}
		if ((selectId == systemAll || selectId == systemG6Gv) && selectDbFlg == selectDbAll) {
			// GVの警備先情報を取得
			keibisakiInfo.addAll(UserAuthKeibisakiService.getG5KeibisakiInfo(param));
		}

		return keibisakiInfo;
	}

}
