package jp.co.alsok.g6.zzw.web.dto;

/**
 * 利用者アカウント情報Dto
 */
public class KeiyakuUserInfoDto extends AbstractAccountInfoDto {

    /** G6利用者アカウント論理番号 */
    private String g6LnAcntAlsokNo;

    /** G6利用者アカウント名 */
    private String g6LnAcntAlsokName;

    /** G6利用者メールアドレス */
    private String g6MlAddr;

    /** G5利用者アカウント論理番号 */
    private String g5LnAcntAlsokNo;

    /** G5利用者アカウント名 */
    private String g5LnAcntAlsokName;

    /** G5利用者メールアドレス */
    private String g5MlAddr;

    /** Ghs利用者kアカウント論理番号 */
    private String ghsLnAcntAlsokNo;

    /** Ghs利用者アカウント名 */
    private String ghsLnAcntAlsokName;

    /** GHS利用者メールアドレス */
    private String ghsMlAddr;

    /**
     * G6利用者アカウント論理番号を取得
     * @return g6LnAcntAlsokNo
     */
    public String getG6LnAcntAlsokNo() {
        return g6LnAcntAlsokNo;
    }
    /**
     * G6利用者アカウント名を取得
     * @return g6LnAcntAlsokName
     */
    public String getG6LnAcntAlsokName() {
        return g6LnAcntAlsokName;
    }
    /**
     * G6利用者メールアドレスを取得
     * @return g6MlAddr
     */
    public String getG6MlAddr() {
        return g6MlAddr;
    }
    /**
     * G5利用者アカウント論理番号を取得
     * @return g5LnAcntAlsokNo
     */
    public String getG5LnAcntAlsokNo() {
        return g5LnAcntAlsokNo;
    }
    /**
     * G5利用者アカウント名を取得
     * @return g5LnAcntAlsokName
     */
    public String getG5LnAcntAlsokName() {
        return g5LnAcntAlsokName;
    }
    /**
     * G5利用者メールアドレスを取得
     * @return g5MlAddr
     */
    public String getG5MlAddr() {
        return g5MlAddr;
    }
    /**
     * Ghs利用者kアカウント論理番号を取得
     * @return ghsLnAcntAlsokNo
     */
    public String getGhsLnAcntAlsokNo() {
        return ghsLnAcntAlsokNo;
    }
    /**
     * Ghs利用者アカウント名を取得
     * @return ghsLnAcntAlsokName
     */
    public String getGhsLnAcntAlsokName() {
        return ghsLnAcntAlsokName;
    }
    /**
     * GHS利用者メールアドレスを取得
     * @return ghsMlAddr
     */
    public String getGhsMlAddr() {
        return ghsMlAddr;
    }

    /**
     * G6利用者アカウント論理番号を設定
     * @param g6LnAcntAlsokNo セットする g6LnAcntAlsokNo
     */
    public void setG6LnAcntAlsokNo(String g6LnAcntAlsokNo) {
        this.g6LnAcntAlsokNo = g6LnAcntAlsokNo;
    }
    /**
     * G6利用者アカウント名を設定
     * @param g6LnAcntAlsokName セットする g6LnAcntAlsokName
     */
    public void setG6LnAcntAlsokName(String g6LnAcntAlsokName) {
        this.g6LnAcntAlsokName = g6LnAcntAlsokName;
    }
    /**
     * G6利用者メールアドレスを設定
     * @param g6MlAddr セットする g6MlAddr
     */
    public void setG6MlAddr(String g6MlAddr) {
        this.g6MlAddr = g6MlAddr;
    }
    /**
     * G5利用者アカウント論理番号を設定
     * @param g5LnAcntAlsokNo セットする g5LnAcntAlsokNo
     */
    public void setG5LnAcntAlsokNo(String g5LnAcntAlsokNo) {
        this.g5LnAcntAlsokNo = g5LnAcntAlsokNo;
    }
    /**
     * G5利用者アカウント名を設定
     * @param g5LnAcntAlsokName セットする g5LnAcntAlsokName
     */
    public void setG5LnAcntAlsokName(String g5LnAcntAlsokName) {
        this.g5LnAcntAlsokName = g5LnAcntAlsokName;
    }
    /**
     * G5利用者メールアドレスを設定
     * @param g5MlAddr セットする g5MlAddr
     */
    public void setG5MlAddr(String g5MlAddr) {
        this.g5MlAddr = g5MlAddr;
    }
    /**
     * Ghs利用者kアカウント論理番号を設定
     * @param ghsLnAcntAlsokNo セットする ghsLnAcntAlsokNo
     */
    public void setGhsLnAcntAlsokNo(String ghsLnAcntAlsokNo) {
        this.ghsLnAcntAlsokNo = ghsLnAcntAlsokNo;
    }
    /**
     * Ghs利用者アカウント名を設定
     * @param ghsLnAcntAlsokName セットする ghsLnAcntAlsokName
     */
    public void setGhsLnAcntAlsokName(String ghsLnAcntAlsokName) {
        this.ghsLnAcntAlsokName = ghsLnAcntAlsokName;
    }
    /**
     * GHS利用者メールアドレスを設定
     * @param ghsMlAddr セットする ghsMlAddr
     */
    public void setGhsMlAddr(String ghsMlAddr) {
        this.ghsMlAddr = ghsMlAddr;
    }
}
