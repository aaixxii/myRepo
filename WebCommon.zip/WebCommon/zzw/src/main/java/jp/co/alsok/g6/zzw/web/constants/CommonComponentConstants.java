package jp.co.alsok.g6.zzw.web.constants;

import java.util.Arrays;

/**
 * 共通で使用可能な定数を定義するクラスです。
 */
public class CommonComponentConstants {

	//--------------------------------------------------------------
	// 暗号化関連
	//--------------------------------------------------------------
	/** 暗号化：塩*/
	public static final String ENCRYPT_SALT = "/2D77?_#>1";

	/**
	 * 暗号化：ハッシュ方式
	 *
	 * 指定可能暗号方式
	 * SHA-1
	 * SHA-224
	 * SHA-256
	 * SHA-384
	 * SHA-512
	 */
	public static final String ENCRYPT_HASH_STYLE = "SHA-256";

	//--------------------------------------------------------------
	// セッション関連
	//--------------------------------------------------------------
	/** cookieに保存する際のKey */
	public static final String COOKIE_KEY_SESSION_ID = "G6SESSION_ID";

	/** G6Sessionから取得する際のKey */
	public static final String SESSION_KEY_ALSOK_ACCOUNT_INFO = "ALSOK_ACCOUNT_INFO";

	//--------------------------------------------------------------
	// WEB Tag 関連
	//--------------------------------------------------------------
	/**
	 * disabled属性が設定可能な要素一覧を定義します。
	 *
	 * @author SNG
	 *
	 */
	public enum DISABLED_TAG {
		button, submit, command, fieldset, keygen, menuitem, optgroup, option, select,
		;
		/**
		 * タグにdisabled属性が設定可能か判定します。
		 *
		 * @param target 判定するタグの名称
		 * @return disabled属性が設定可能な場合、true
		 */
		public static boolean isTagAttrDisabled(String target) {
			return !Arrays.stream(DISABLED_TAG.values())
					.noneMatch(tag -> tag.toString().equals(target));
		}
	}

	/**
	 * readonly属性が設定可能な要素一覧を定義します。
	 *
	 * @author SNG
	 *
	 */
	public enum READONLY_TAG {
		input, textarea,
		;
		/**
		 * タグにreadonlyTag属性が設定可能か判定します。
		 *
		 * @param target 判定するタグの名称
		 * @return disabled属性が設定可能な場合、true
		 */
		public static boolean isTagAttrReadonly(String target) {
			return !Arrays.stream(READONLY_TAG.values())
					.noneMatch(tag -> tag.toString().equals(target));
		}
	}

	/**
	 * 運用管理サイトの画面制御権限を定義します。
	 */
	public static enum PERMISSION_SZWO {
		/** 閲覧・変更可 */
		EDIT(0),
		/** 閲覧可・変更不可 */
		READ(1),
		/** 閲覧不可・変更不可 */
		NONE(2),
		;
		/** 制御 */
		private int permission;

		private PERMISSION_SZWO(int permission) {
			this.permission = permission;
		}

		/**
		 * 画面制御権限を返却する。
		 * @return 画面制御権限
		 */
		public final int getPermission() {
			return this.permission;
		}

		/**
		 * valueからenumを返却する。
		 * @return 画面制御権限enum
		 */
		public static final PERMISSION_SZWO getPermissionEnum(int val) {
			return Arrays.stream(PERMISSION_SZWO.values())
					.filter(perm -> perm.getPermission() == val)
					.findFirst()
					.orElse(null);
		}
	}

	/**
	 * ALSOK権限
	 */
	public static enum ALSOK_AUTHORITY {
		/** 監視 */
		MONITORING("101"),
		/** 運用管理（マスタメンテナンス） */
		MASTER_MNT("102"),
		/** 運用管理（運用情報） */
		OPERAT_MNG("103"),
		/** 運用管理（ユーザメンテナンス） */
		USER_MNT("104"),
		/** ALSOKお知らせ */
		ALSOK_NOTICE("106"),
		/** システムメンテナンス */
		SYS_MNT("107"),
		;
		/** 制御 */
		private String authority;

		private ALSOK_AUTHORITY(String authority) {
			this.authority = authority;
		}

		/**
		 * 画面制御権限を返却する。
		 * @return ALSOK権限
		 */
		public final String getAuthority() {
			return this.authority;
		}
	}

	/** コード検索定義 */
	public static enum CODE_SEARCH_TYPE {

		// 監視巡回サイト、運用サイト共通 コード検索
		/** ガードセンター.GC名称. */
		SELECT_GC_NM_BY_CODE("selectGcNmByCode", "searchKey")
		/** 事業所.事業所名称. */
		,SELECT_JIGYOU_NM_BY_CODE("selectJigyouNmByCode", "searchKey")

		// 監視巡回サイト コード検索
		/** 判断理由マスター.内容. */
		,SELECT_REASON_NAIYOU_BY_CODE("selectReasonNaiyouByCode", "searchKey")
		/** 原因マスタ原因マスター.原因内容. */
		,SELECT_GENIN_NAIYOU_BY_CODE("selectGeninNaiyouByCode", "searchKey")
		/** GV 判断理由マスタ.内容. */
		,SELECT_REASON_NAIYOU_GV_BY_CODE("selectReasonNaiyouGVByCode", "searchKey")
		/** V6事案分類コードファイル.内容. */
		,SELECT_JIANBNRCD_NAIYOU_BY_CODE("selectJianbnrcdNaiyouByCode", "searchKey")
		/** V6警報分類コード.内容. */
		,SELECT_V6_KEIHOBNRCD_NAIYOU_BY_CODE("selectV6KeihobnrcdNaiyouByCode", "searchKey")
		/** V6原因分類コード.内容. */
		,SELECT_V6_GENBNRCD_NAIYOU_BY_CODE("selectV6GenbnrcdNaiyouByCode", "searchKey")

		// 運用サイト コード検索
		/** 警備先.「警備先名1＋警備先名2」 */
		,SELECT_KEIBINAME_BYCODE("selectKeibiNameByCode", "searchKey")
		/** 警備先.警備先略称名称*/
		,SELECT_KEIBISAKI_ABBRNM_BYCODE("selectKeibisakiAbbrNmByCode", "searchKey")
		/** 契約先.契約先名称*/
		,SELECT_KEIYKNM_BYCODE("selectKeiykNmByCode", "searchKey")
		/** 住所マスター.住所を (都道府県名,市区町村名,大字町名,小字町名,丁目名,番地名)*/
		,SELECT_JYUSYO_BYCODE("selectJyusyoByCode", "addrCd1Id", "addrCd2Id", "addrCd3Id", "addrCd4Id", "addrCd5Id",
				"addrCd6Id")
		/** 住所マスター.住所(カナ)を (都道府県名,市区町村名,大字町名,小字町名,丁目名,番地名)*/
		,SELECT_JYUSYO_KANA_BYCODE("selectJyusyoKanaByCode", "addrCd1Id", "addrCd2Id", "addrCd3Id", "addrCd4Id",
				"addrCd5Id", "addrCd6Id");

		/** メソッド名*/
		private String methodName;
		/** メソッド パラメータ名 */
		private String[] methodParamNames;

		/**
		 * コード検索 メソッド名・メソッドパラメータ コンストラクタ
		 * @param methodName メソッド名
		 * @param methodParamNames メソッドパラメータ
		 */
		private CODE_SEARCH_TYPE(String methodName, String... methodParamNames) {
			this.methodName = methodName;
			this.methodParamNames = methodParamNames;
		}

		/**
		 * ajaxから呼ばれるメソッド名を返却する
		 * @return メソッド名
		 */
		public String getMethodName() {
			return this.methodName;
		}

		/**
		 * メソッドのパラメータ名を返却する
		 * @return パラメータ
		 */
		public String[] getMethodParamNames() {
			return this.methodParamNames;
		}

		/**
		 * メソッド名からenumを返却する
		 * @param methodName メソッド名
		 * @return CODE_SEARCH_TYPE
		 */
		public static CODE_SEARCH_TYPE getCodeSearchTypeByMethodName(String methodName) {
			return Arrays.stream(CODE_SEARCH_TYPE.values())
					.filter(item -> item.getMethodName().equals(methodName))
					.findFirst()
					.orElse(null);
		}
	}

	/** 属性名プレフィックス(th) */
	public static final String PREFIX_TH = "th";
	/** カスタム属性名：auth */
	public static final String ATTR_THIS_AUTH = "auth";
	/** カスタム属性名：neAuth */
	public static final String ATTR_NEXT_AUTH = "neAuth";
	/** disabled属性 */
	public static final String ATTR_DISABLED = "disabled";
	/** readonly属性 */
	public static final String ATTR_READONLY = "readonly";
	/** style属性 */
	public static final String ATTR_STYLE = "style";
	/** style値：display:none */
	public static final String ATTR_DISPLAY_NONE = "display:none;";
    /** type属性 */
    public static final String ATTR_TYPE = "type";
	/** 利用者操作履歴 シーケンスID */
	public static final String OPERATION_HISTORY_USER_SEQUECE_ID = "LN_LOG_USER_OPERATION";

	/** ALSOK操作履歴 シーケンスID */
	public static final String OPERATION_HISTORY_ALSOK_SEQUECE_ID = "LN_ALSOK_USER_OPERATION";

}
