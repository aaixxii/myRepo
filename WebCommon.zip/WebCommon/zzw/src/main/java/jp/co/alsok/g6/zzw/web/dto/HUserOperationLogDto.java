package jp.co.alsok.g6.zzw.web.dto;

/**
 * 利用者操作履歴 パラメータDTO
 * (利用者操作履歴 登録用 DTO)
 */
public class HUserOperationLogDto {

    /** LN_契約先論理番号 */
    private String LN_KEIYK;
    /** LN_利用者操作履歴論理番号 */
    private String LN_LOG_USER_OPERATION;
    /** 操作日付 */
    private String USE_DAY;
    /** LN_警備先論理番号 */
    private String LN_KEIBI;
    /** 警備先名称 */
    private String KEIBI_NM;
    /** LN_警備先地区論理番号 */
    private String LN_KB_CHIKU;
    /** 警備先地区名称（SD_個別名称） */
    private String SD_KOBETU_NM;
    /** 氏名（社員名／ユーザー氏名）  */
    private String USER_NM;
    /** 操作画面ID */
    private String DISP_ID;
    /** 操作内容コード */
    private String USER_OPERATION_NAIYOU_CD;
    /** 内容 */
    private String USER_OPERATION_NAIYOU;
    /** 利用者アカウント区分 */
    private String ACNT_USER_KBN;
    /** 備考 */
    private String BIKOU;

    // ************************************************
    // HUserOperationLog テーブルのカラムサイズを設定
    // ************************************************
    /** LN_契約先論理番号 サイズ */
    private int LN_KEIYK_SIZE = 20;
    /** LN_利用者操作履歴論理番号 サイズ*/
    private int LN_LOG_USER_OPERATION_SIZE = 20;
    /** 操作日付 サイズ */
    private int USE_DAY_SIZE = 8;
    /** LN_警備先論理番号 サイズ */
    private int LN_KEIBI_SIZE =  20;
    /** 警備先名称 サイズ*/
    private int KEIBI_NM_SIZE =  60;
    /** LN_警備先地区論理番号 サイズ */
    private int LN_KB_CHIKU_SIZE =  20;
    /** 警備先地区名称（SD_個別名称） サイズ*/
    private int SD_KOBETU_NM_SIZE = 40;
    /** 氏名（社員名／ユーザー氏名） サイズ*/
    private int USER_NM_SIZE = 20;
    /** 利用者アカウント区分 サイズ*/
    private int ACNT_USER_KBN_SIZE = 1;
    /** 操作画面ID サイズ*/
    private int DISP_ID_SIZE = 5;
    /** 操作内容コード サイズ*/
    private int USER_OPERATION_NAIYOU_CD_SIZE = 2;
    /** 内容 サイズ*/
    private int USER_OPERATION_NAIYOU_SIZE = 40;
    /** 備考 サイズ*/
    private int BIKOU_SIZE = 200;


    /**
     * LN_契約先論理番号を取得
     * @return LN_KEIYK
     */
    public String getLN_KEIYK() {
        return LN_KEIYK;
    }
    /**
     * LN_契約先論理番号を設定 ※ 必須項目
     * @param lN_KEIYK セットする lN_KEIYK
     */
    public void setLN_KEIYK(String lN_KEIYK) {
    	LN_KEIYK = lN_KEIYK;
    }
    /**
     * LN_利用者操作履歴論理番号を取得
     * @return lN_LOG_USER_OPERATION
     */
    public String getLN_LOG_USER_OPERATION() {
        return LN_LOG_USER_OPERATION;
    }
    /**
     * LN_利用者操作履歴論理番号を設定 ※ 必須項目
     * @param lN_LOG_USER_OPERATION セットする lN_LOG_USER_OPERATION
     */
    public void setLN_LOG_USER_OPERATION(String lN_LOG_USER_OPERATION) {
        LN_LOG_USER_OPERATION = lN_LOG_USER_OPERATION;
    }
    /**
     * 操作日付を取得
     * @return LN_KEIYK
     */
    public String getUSE_DAY() {
        return USE_DAY;
    }
    /**
     * 操作日付を設定 ※ 必須項目
     * @param uSE_DAY セットする uSE_DAY
     */
    public void setUSE_DAY(String uSE_DAY) {
    	USE_DAY = uSE_DAY;
    }
    /**
     * LN_警備先論理番号を取得
     * @return LN_KEIBI
     */
    public String getLN_KEIBI() {
        return LN_KEIBI;
    }
    /**
     * LN_警備先論理番号を設定
     * @param lN_KEIBI セットする lN_KEIBI
     */
    public void setLN_KEIBI(String lN_KEIBI) {
    	LN_KEIBI = lN_KEIBI;
    }
    /**
     * 警備先名称を取得
     * @return kEIBI_NM
     */
    public String getKEIBI_NM() {
        return KEIBI_NM;
    }
    /**
     * 警備先名称を設定
     * @param kEIBI_NM セットする kEIBI_NM
     */
    public void setKEIBI_NM(String kEIBI_NM) {
        KEIBI_NM = kEIBI_NM;
    }
    /**
     * LN_警備先地区論理番号を取得
     * @return LN_KEIBI
     */
    public String getLN_KB_CHIKU() {
        return LN_KB_CHIKU;
    }
    /**
     * LN_警備先地区論理番号を設定
     * @param lN_KB_CHIKU セットする lN_KB_CHIKU
     */
    public void setLN_KB_CHIKU(String lN_KB_CHIKU) {
    	LN_KB_CHIKU = lN_KB_CHIKU;
    }
    /**
     * 警備先地区名称（SD_個別名称）を取得
     * @return sD_KOBETU_NM
     */
    public String getSD_KOBETU_NM() {
        return SD_KOBETU_NM;
    }
    /**
     * 警備先地区名称（SD_個別名称）を設定
     * @param sD_KOBETU_NM セットする sD_KOBETU_NM
     */
    public void setSD_KOBETU_NM(String sD_KOBETU_NM) {
        SD_KOBETU_NM = sD_KOBETU_NM;
    }
    /**
     * 氏名（社員名／ユーザー氏名）を取得
     * @return uSER_NM
     */
    public String getUSER_NM() {
        return USER_NM;
    }
    /**
     * 氏名（社員名／ユーザー氏名）を設定※ 必須項目
     * @param uSER_NM セットする uSER_NM
     */
    public void setUSER_NM(String uSER_NM) {
        USER_NM = uSER_NM;
    }
    /**
     * 操作画面IDを取得
     * @return dISP_ID
     */
    public String getDISP_ID() {
        return DISP_ID;
    }
    /**
     * 操作画面IDを設定 ※ 必須項目
     * @param dISP_ID セットする dISP_ID
     */
    public void setDISP_ID(String dISP_ID) {
        DISP_ID = dISP_ID;
    }
    /**
     * 操作内容コードを取得
     * @return uSER_OPERATION_NAIYOU_CD
     */
    public String getUSER_OPERATION_NAIYOU_CD() {
        return USER_OPERATION_NAIYOU_CD;
    }
    /**
     * 操作内容コードを設定 ※ 必須項目
     * @param uSER_OPERATION_NAIYOU_CD セットする uSER_OPERATION_NAIYOU_CD
     */
    public void setUSER_OPERATION_NAIYOU_CD(String uSER_OPERATION_NAIYOU_CD) {
        USER_OPERATION_NAIYOU_CD = uSER_OPERATION_NAIYOU_CD;
    }
    /**
     * 内容を取得
     * @return uSER_OPERATION_NAIYOU
     */
    public String getUSER_OPERATION_NAIYOU() {
        return USER_OPERATION_NAIYOU;
    }
    /**
     * 内容を設定
     * @param uSER_OPERATION_NAIYOU セットする uSER_OPERATION_NAIYOU
     */
    public void setUSER_OPERATION_NAIYOU(String uSER_OPERATION_NAIYOU) {
        USER_OPERATION_NAIYOU = uSER_OPERATION_NAIYOU;
    }
    /**
     * 利用者アカウント区分を設定
     * @return
     */
    public String getACNT_USER_KBN() {
		return ACNT_USER_KBN;
	}
    /**
     * 利用者アカウント区分を取得
     * @param aCNT_USER_KBN
     */
	public void setACNT_USER_KBN(String aCNT_USER_KBN) {
		ACNT_USER_KBN = aCNT_USER_KBN;
	}
	/**
     * 備考を取得
     * @return bIKOU
     */
    public String getBIKOU() {
        return BIKOU;
    }
    /**
     * 備考を設定
     * @param bIKOU セットする bIKOU
     */
    public void setBIKOU(String bIKOU) {
        BIKOU = bIKOU;
    }

    // ============================================================================
    // テーブルカラムサイズ取得メソッド
    // ============================================================================

    /**
     * LN_契約先論理番号 サイズ
     * @return lN_KEIYK_SIZE
     */
    public int getLN_KEIYK_SIZE() {
        return LN_KEIYK_SIZE;
    }
    /**
     * LN_利用者操作履歴論理番号 サイズ
     * @return lN_LOG_USER_OPERATION_SIZE
     */
    public int getLN_LOG_USER_OPERATION_SIZE() {
        return LN_LOG_USER_OPERATION_SIZE;
    }
    /**
     * 操作日付 サイズ
     * @return uSE_DAY
     */
    public int getUSE_DAY_SIZE() {
        return USE_DAY_SIZE;
    }
    /**
     * LN_警備先論理番号 サイズ
     * @return lN_KEIBI_SIZE
     */
    public int getLN_KEIBI_SIZE() {
        return LN_KEIBI_SIZE;
    }
    /**
     * 警備先名称 サイズ
     * @return kEIBI_NM_SIZE
     */
    public int getKEIBI_NM_SIZE() {
        return KEIBI_NM_SIZE;
    }
    /**
     * LN_警備先地区論理番号 サイズ
     * @return lN_KB_CHIKU_SIZE
     */
    public int getLN_KB_CHIKU_SIZE() {
        return LN_KB_CHIKU_SIZE;
    }
    /**
     * 警備先地区名称（SD_個別名称） サイズ
     * @return sD_KOBETU_NM_SIZE
     */
    public int getSD_KOBETU_NM_SIZE() {
        return SD_KOBETU_NM_SIZE;
    }
    /**
     * 氏名（社員名／ユーザー氏名） サイズ
     * @return uSER_NM_SIZE
     */
    public int getUSER_NM_SIZE() {
        return USER_NM_SIZE;
    }
    /**
     * 利用者アカウント区分 サイズ
     * @return uSER_KIND_SIZE
     */
    public int getACNT_USER_KBN_SIZE() {
        return ACNT_USER_KBN_SIZE;
    }
    /**
     * 操作画面ID サイズ
     * @return dISP_ID_SIZE
     */
    public int getDISP_ID_SIZE() {
        return DISP_ID_SIZE;
    }
    /**
     * 操作内容コード サイズ
     * @return uSER_OPERATION_NAIYOU_CD_SIZE
     */
    public int getUSER_OPERATION_NAIYOU_CD_SIZE() {
        return USER_OPERATION_NAIYOU_CD_SIZE;
    }
    /**
     * 内容 サイズ
     * @return uSER_OPERATION_NAIYOU_SIZE
     */
    public int getUSER_OPERATION_NAIYOU_SIZE() {
        return USER_OPERATION_NAIYOU_SIZE;
    }
    /**
     * 備考 サイズ
     * @return bIKOU_SIZE
     */
    public int getBIKOU_SIZE() {
        return BIKOU_SIZE;
    }
}
