/**
 *
 */
package jp.co.alsok.g6.zzw.web.dto;

public class KeibichikuDto {

	/** 警備先地区名称 */
	private String keibisakiChikuName = "";
	/** LN_警備先地区論理番号 */
	private String keibisakiChikuId = "";
	/** LN_警備先論理番号 */
	private String keibisakId = "";
	/**
	* keibisakiChikuName 取得
	* @return keibisakiChikuName
	*/
	public String getKeibisakiChikuName() {
		return keibisakiChikuName;
	}
	/**
	* @param keibisakiChikuName 設定 keibisakiChikuName
	*/
	public void setKeibisakiChikuName(String keibisakiChikuName) {
		this.keibisakiChikuName = keibisakiChikuName;
	}
	/**
	* keibisakiChikuId 取得
	* @return keibisakiChikuId
	*/
	public String getKeibisakiChikuId() {
		return keibisakiChikuId;
	}
	/**
	* @param keibisakiChikuId 設定 keibisakiChikuId
	*/
	public void setKeibisakiChikuId(String keibisakiChikuId) {
		this.keibisakiChikuId = keibisakiChikuId;
	}
	/**
	* keibisakId 取得
	* @return keibisakId
	*/
	public String getKeibisakId() {
		return keibisakId;
	}
	/**
	* @param keibisakId 設定 keibisakId
	*/
	public void setKeibisakId(String keibisakId) {
		this.keibisakId = keibisakId;
	}



}
