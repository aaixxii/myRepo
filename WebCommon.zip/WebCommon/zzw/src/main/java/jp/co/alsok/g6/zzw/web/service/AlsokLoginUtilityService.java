package jp.co.alsok.g6.zzw.web.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.alsok.g6.zzw.web.constants.DbAccessConstants;
import jp.co.alsok.g6.zzw.web.dto.AlsokAccountInfoDto;

/**
 * 時期,G5,GHSのアカウント論理番号、アカウント名、社員番号取得Service
 *
 * @author SNG-105
 */
@Service
public class AlsokLoginUtilityService {

	@Autowired
	AlsokAccountInfoService alsokAccountInfoService;

	/**
	 * ALSOKアカウント論理番号を基にG6,G5,GHSのアカウント論理番号と社員番号を取得し、
	 * AlsokAccountInfoDtoで返却します。
	 *
	 * 引数systemFlgで取得対象のDBを限定します。
	 * <pre>
	 * 引数：システム判定フラグ
	 * systemFlg = 0 : G6, G5, GHS それぞれのアカウント論理番号と社員番号を取得します。
	 * systemFlg = 1 : G6, GHS それぞれのアカウント論理番号と社員番号を取得します。
	 * systemFlg = 2 : G6, G5 それぞれのアカウント論理番号と社員番号を取得します。
	 * systemFlg = 3 : G6 のアカウント論理番号と社員番号を取得します。
	 * </pre>
	 *
	 * @param lnAcntAlsokNo 時期Alsokアカウント論理番号
	 * @param systemFlg システム判定フラグ
	 * @return AlsokAccountInfoDto 次期、GHS、GVのALSOKアカウント論理番号を格納したDto
	 */
	public AlsokAccountInfoDto getAlsokAccountInfo(String lnAcntAlsokNo, int systemFlg) {

		// 返却値
		AlsokAccountInfoDto alsokAccountInfoDto = new AlsokAccountInfoDto();

		// パラメータのシステムフラグの値判定処理
		if (!this.isSystemFlgVal(systemFlg)) {
			return alsokAccountInfoDto;
		}

		// G6(次期)のアカウント論理番号、アカウント名、社員番号を取得
		alsokAccountInfoService.setG6AccountInfo(lnAcntAlsokNo, alsokAccountInfoDto);
		// G6(次期)の社員番号を取得
		String g6UserNum = alsokAccountInfoDto.getG6UserNum();
		// G6(次期)の事業所コードを取得
		String g6JigyouCd = alsokAccountInfoDto.getG6JigyouCd();

		// 全体の場合
		if (DbAccessConstants.CONNECT_DB_G6_G5_GHS == systemFlg) {
			// [G5]のアカウント情報取得
			alsokAccountInfoDto = alsokAccountInfoService.setG5AccountInfo(g6UserNum, g6JigyouCd, alsokAccountInfoDto);
			// [GHS]のアカウント情報取得
			return alsokAccountInfoService.setGhsAccountInfo(g6UserNum, g6JigyouCd, alsokAccountInfoDto);

		} else if (DbAccessConstants.CONNECT_DB_G6_GHS == systemFlg) {
			// 運用の場合(G6,GHSのDBにアクセス)
			// [GHS]のアカウント情報取得
			return alsokAccountInfoService.setGhsAccountInfo(g6UserNum, g6JigyouCd, alsokAccountInfoDto);
		} else if (DbAccessConstants.CONNECT_DB_G6_G5 == systemFlg) {
			// 監視巡回の場合(G6,G5のDBにアクセス)
			// [G5]のアカウント情報取得
			return alsokAccountInfoService.setG5AccountInfo(g6UserNum, g6JigyouCd, alsokAccountInfoDto);
		} else {

			//systemFlgがCONNECT_DB_G6の場合には[G6]のアカウント情報のみ返却
			return alsokAccountInfoDto;
		}
	}

	/**
	 * パラメータのフラグが正常な値かの判定処理
	 * @param systemFlg システム判定フラグ
	 *
	 * @return true: 正常  / false: 不正値
	 */
	private boolean isSystemFlgVal(int systemFlg) {
		if (DbAccessConstants.CONNECT_DB_G6_G5_GHS == systemFlg
				|| DbAccessConstants.CONNECT_DB_G6_GHS == systemFlg
				|| DbAccessConstants.CONNECT_DB_G6_G5 == systemFlg
				|| DbAccessConstants.CONNECT_DB_G6 == systemFlg) {
			// 正常値
			return true;
		}
		// 不正値
		return false;
	}
}
