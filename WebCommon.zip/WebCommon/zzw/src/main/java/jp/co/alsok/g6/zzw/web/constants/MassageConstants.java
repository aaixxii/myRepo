package jp.co.alsok.g6.zzw.web.constants;

/**
 * 共通部品 メッセージ定数クラス
 */
public class MassageConstants {

    // *****************
    // メッセージID
    // *****************
    /** エラーメッセージLZWO0200[必須チェックに不正がありました] */
    public static final String LZWO0200 = "パラメータの必須チェックに不正がありました。";
    /** エラーメッセージLZWO0201[の桁数チェックに不正がありました。] */
    public static final String LZWO0201 = "の桁数チェックに不正がありました。";
    /** エラーメッセージLZWO0203[引数の値が不正です。] */
    public static final String LZWO0203 = "引数の値が不正です。";

    // *****************
    // 項目名
    // *****************
    // ALSOK操作履歴テーブル 項目名
    /** ALSOK操作履歴 */
    public static final String H_LOG_ALSOK_USER_OPERATION = "ALSOK操作履歴";
    /** LN_ALSOK操作履歴論理番号 */
    public static final String LN_ALSOK_USER_OPERATION = "LN_ALSOK操作履歴論理番号";
    /** 警備先名称 */
    public static final String KEIBI_NM_ALSOK = "警備先名称";
    /** お客様番号２ */
    public static final String CUSTOMER_NUM2 = "お客様番号２";
    /** 警備先地区名称（SD_個別名称） */
    public static final String SD_KOBETU_NM_ALSOK = "警備先地区名称（SD_個別名称）";
    /** 氏名（社員名／ユーザー氏名） */
    public static final String USER_NM_ALSOK = "氏名（社員名／ユーザー氏名）";
    /** 操作画面ID */
    public static final String DISP_ID_ALSOK = "操作画面ID";
    /** 操作内容コード */
    public static final String ALSOK_OPERATION_NAIYOU_CD = "操作内容コード";
    /** 内容 */
    public static final String ALSOK_OPERATION_NAIYOU = "内容";

    // 利用者操作履歴テーブル
    /** 利用者操作履歴  */
    public static final String H_USER_OPERATION_LOG = "利用者操作履歴";
    /** LN_契約先論理番号 */
    public static final String LN_KEIYK = "LN_契約先論理番号";
    /** LN_利用者操作履歴論理番号 */
    public static final String LN_LOG_USER_OPERATION = "LN_利用者操作履歴論理番号";
    /** 操作日付 */
    public static final String USE_DAY = "操作日付";
    /** LN_警備先論理番号 */
    public static final String LN_KEIBI = "LN_警備先論理番号";
    /** 警備先名称 */
    public static final String KEIBI_NM_USER = "警備先名称";
    /** LN_警備先地区論理番号 */
    public static final String LN_KB_CHIKU = "LN_警備先地区論理番号";
    /** 警備先地区名称（SD_個別名称） */
    public static final String SD_KOBETU_NM_USER = "警備先地区名称（SD_個別名称）";
    /** 氏名（社員名／ユーザー氏名） */
    public static final String USER_NM_USER = "氏名（社員名／ユーザー氏名）";
    /** 利用者アカウント区分 */
    public static final String ACNT_USER_KBN = "利用者アカウント区分";
    /** 操作画面ID */
    public static final String DISP_ID_USER = "操作画面ID";
    /** 操作内容コード */
    public static final String USER_OPERATION_NAIYOU_CD = "操作内容コード";
    /** 内容 */
    public static final String USER_OPERATION_NAIYOU = "内容";
    /** 備考 */
    public static final String BIKOU = "備考";
}
