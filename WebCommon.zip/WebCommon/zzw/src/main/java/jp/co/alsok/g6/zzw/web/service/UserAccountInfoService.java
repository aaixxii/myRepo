package jp.co.alsok.g6.zzw.web.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import jp.co.alsok.g6.zzw.util.StringUtil;
import jp.co.alsok.g6.zzw.web.constants.DbAccessConstants.ACNT_KIND;
import jp.co.alsok.g6.zzw.web.constants.DbAccessConstants.LOGIN_SYS_FLG;
import jp.co.alsok.g6.zzw.web.dao.mapper.g6.CommonKAcntUserCommonMapper;
import jp.co.alsok.g6.zzw.web.dto.KeiyakuUserInfoDto;

/**
 * [利用者アカウント]
 * 時期,G5,GHSのアカウント論理番号、アカウント名、社員番号取得 g5,g6,ghs DBアクセス Service
 */
@Service
public class UserAccountInfoService {

    /** G6 利用者アカウント情報取得 Mapper */
    @Autowired
    CommonKAcntUserCommonMapper commonKAcntUserCommonMapper;

    /**
     * 次期(G6)の利用者アカウント情報を取得
     *
     * @param loginSysFlg ログインのシステム情報
     *        (SYS_G6=次期ログイン時, SYS_GHS=GHSログイン時, SYS_G5=G5ログイン時)
     * @param lnAcntUserCommon LN_利用者アカウント共通論理番号
     * @param keiyakuUserInfoDto 利用者アカウント情報Dto
     * @param acntKind アカウント種別
     * 		  (0:次期警備システム, 1:GⅤ, 2:GHS(利用者),3:GHS(契約先))
     */
    @Transactional(propagation = Propagation.SUPPORTS)
    public void getG6UserInfo(LOGIN_SYS_FLG loginSysFlg
                                   , String lnAcntUserCommon
                                   , KeiyakuUserInfoDto keiyakuUserInfoDto
                                   , ACNT_KIND acntKind) {
        // メールアドレス変数
        String mailAddress = null;
        // DBアクセスの引数用変数
        Map<String, Object> param = null;
        // DBアクセス結果
        Map<String, Object> dbResult = new HashMap<String, Object>();

        // 次期(G6)でログインした場合(G6アカウント論理番号で紐づける)
        if (loginSysFlg == LOGIN_SYS_FLG.SYS_G6) {
            param = this.createMapParam(loginSysFlg, lnAcntUserCommon, null);
            dbResult = commonKAcntUserCommonMapper.selectG6KAcntUserCommonByAcnt(param);
        }
        // GHSでログインした場合(G6メールアドレスで紐づける)
        else if (loginSysFlg == LOGIN_SYS_FLG.SYS_GHS) {
            mailAddress = keiyakuUserInfoDto.getGhsMlAddr();
            param = this.createMapParam(loginSysFlg, null, mailAddress);
            dbResult = commonKAcntUserCommonMapper.selectG6KAcntUserCommonByMail(param);
        }
        // G5でログインした場合(G6アカウント論理番号で紐づける)
        else {
            param = this.createMapParam(loginSysFlg, lnAcntUserCommon, null);
            dbResult = commonKAcntUserCommonMapper.selectG6KAcntUserCommonByG5Acnt(param);
        }
        // 対象データが存在しない場合は返却
        if (null == dbResult) {
            return;
        }

        // G6利用者アカウント論理番号を設定
        if (null != dbResult.get("lnAcntUserCommon")) {
            keiyakuUserInfoDto.setG6LnAcntAlsokNo(dbResult.get("lnAcntUserCommon").toString());
        }
        // G6利用者アカウント名を設定
        if (null != dbResult.get("acntNm")) {
            keiyakuUserInfoDto.setG6LnAcntAlsokName(dbResult.get("acntNm").toString());
        }
        // G6利用者メールアドレスを設定
        if (null != dbResult.get("mlAddr")) {
            keiyakuUserInfoDto.setG6MlAddr(dbResult.get("mlAddr").toString());
        }

    }

    /**
     * G5の利用者アカウント情報を取得
     *
     * @param loginSysFlg ログインシステム判定フラグ
     *        (SYS_G6=次期ログイン時, SYS_GHS=GHSログイン時, SYS_G5=G5ログイン時)
     * @param lnAcntUserCommon LN_利用者アカウント共通論理番号
     * @param keiyakuUserInfoDto 利用者アカウント情報Dto
     * @param acntKind アカウント種別
     * 		  (0:次期警備システム, 1:GⅤ, 2:GHS(利用者),3:GHS(契約先))
     */
    @Transactional(propagation = Propagation.SUPPORTS)
    public void getG5UserInfo(LOGIN_SYS_FLG loginSysFlg
                                   , String lnAcntUserCommon
                                   , KeiyakuUserInfoDto keiyakuUserInfoDto
                                   , ACNT_KIND acntKind) {
        // DBアクセスの引数変数
        Map<String, Object> param = null;
        // DBアクセス結果変数
        Map<String, Object> dbResult = new HashMap<String, Object>();

        // G5でログインした場合(G5のアカウント番号を設定しアカウント番号で紐づける)
        if(loginSysFlg == LOGIN_SYS_FLG.SYS_G5) {
            param = this.createMapParam(loginSysFlg, lnAcntUserCommon, null);
            dbResult = commonKAcntUserCommonMapper.selectG5KeiyakuKojinMstByG5Acnt(param);
        }
        // 次期(G6)でログインした場合(G6のアカウント番号を設定しアカウント番号で紐づける)
        else if (loginSysFlg == LOGIN_SYS_FLG.SYS_G6) {
            param = this.createMapParam(loginSysFlg, keiyakuUserInfoDto.getG6LnAcntAlsokNo(), null);
            dbResult = commonKAcntUserCommonMapper.selectG5KeiyakuKojinMstByG6Acnt(param);
        }
        // GHSでログインした場合(G6のアカウント番号を基に、メールアドレスで紐づける)
        else {
            param = this.createMapParam(loginSysFlg, keiyakuUserInfoDto.getG6LnAcntAlsokNo(), null);
            dbResult = commonKAcntUserCommonMapper.selectG5KeiyakuKojinMstByG6Acnt(param);
        }
        // 対象データが存在しない場合は返却
        if (null == dbResult) {
            return;
        }

        // G5利用者アカウント論理番号を設定
        if (null != dbResult.get("lnAcntUserCommon")) {
            keiyakuUserInfoDto.setG5LnAcntAlsokNo(dbResult.get("lnAcntUserCommon").toString());
        }
        // G5利用者アカウント名を設定
        if (null != dbResult.get("acntNm")) {
            keiyakuUserInfoDto.setG5LnAcntAlsokName(dbResult.get("acntNm").toString());
        }
        // G5利用者メールアドレスを設定
        if (null != dbResult.get("mlAddr")) {
            keiyakuUserInfoDto.setG5MlAddr(dbResult.get("mlAddr").toString());
        }

    }

    /**
     * GHSの利用者アカウント情報を取得
     *
     * @param loginSysFlg ログインシステムflag
     *        (SYS_G6=次期ログイン時, SYS_GHS=GHSログイン時, SYS_G5=G5ログイン時)
     * @param lnAcntUserCommon N_利用者アカウント共通論理番号
     * @param keiyakuUserInfoDto 利用者アカウント情報Dto
     * @param acntKind アカウント種別
     * 		  (0:次期警備システム, 1:GⅤ, 2:GHS(利用者),3:GHS(契約先))
     */
    @Transactional(propagation = Propagation.SUPPORTS)
    public void getGhsUserInfo(LOGIN_SYS_FLG loginSysFlg
                                    , String lnAcntUserCommon
                                    , KeiyakuUserInfoDto keiyakuUserInfoDto
                                    , ACNT_KIND acntKind) {
        // メールアドレス変数
        String mailAddress = null;
        // DBアクセスの引数変数
        Map<String, Object> param = null;
        // DBアクセス結果
        Map<String, Object> dbResult = new HashMap<String, Object>();

        // GHSでログインした場合(GHSアカウント論理番号で紐づける)
        if (loginSysFlg == LOGIN_SYS_FLG.SYS_GHS) {
            param = this.createMapParam(loginSysFlg, lnAcntUserCommon, null);
            dbResult = commonKAcntUserCommonMapper.selectGhsRAcntUserByGhsAcnt(param);
        }
        // GHS以外でログインした場合(G6のメールアドレスで紐づける)
        else {
            // G6, G5でログインした場合にはG6メールアドレスでGHSの利用者アカウントを検索する。
            mailAddress = keiyakuUserInfoDto.getG6MlAddr();
            param = this.createMapParam(loginSysFlg, null, mailAddress);
            dbResult = commonKAcntUserCommonMapper.selectGhsRAcntUserByG6Mail(param);
        }
        // 対象データが存在しない場合は返却
        if (null == dbResult) {
            return;
        }

        // GHS利用者アカウント論理番号を設定
        if (null != dbResult.get("lnAcntUserCommon")) {
            keiyakuUserInfoDto.setGhsLnAcntAlsokNo(dbResult.get("lnAcntUserCommon").toString());
        }
        // GHS利用者アカウント名を設定
        if (null != dbResult.get("acntNm")) {
            keiyakuUserInfoDto.setGhsLnAcntAlsokName(dbResult.get("acntNm").toString());
        }
        // GHS利用者メールアドレスを設定
        if (null != dbResult.get("mlAddr")) {
            keiyakuUserInfoDto.setGhsMlAddr(dbResult.get("mlAddr").toString());
        }

    }


    /**
     * DBアクセスの場合の引数を作成
     *
     * @param loginSysFlg ログインのシステム情報
     * @param lnAcntUserCommon LN_利用者アカウント共通論理番号
     * @param mailAddress メールアドレス
     * @return result DBアクセスパラメータMap
     */
    private Map<String, Object> createMapParam(LOGIN_SYS_FLG loginSysFlg, String lnAcntUserCommon, String mailAddress) {
        // 返却値
        Map<String, Object> result = new HashMap<String, Object>();

        // LN_利用者アカウント共通論理番号
        result.put("lnAcntUserCommon", lnAcntUserCommon);
        // メールアドレスを設定
        if (StringUtil.isNotNullOrEmpty(mailAddress)) {
            result.put("mailAddress", mailAddress);
        } else {
            result.put("mailAddress", "");
        }
        return result;
    }
}
