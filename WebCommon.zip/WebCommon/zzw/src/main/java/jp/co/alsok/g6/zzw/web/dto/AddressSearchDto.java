package jp.co.alsok.g6.zzw.web.dto;

/**
 * 住所検索用 DTO
 */
public class AddressSearchDto {

    /** 都道府県ID */
    private String addrCd1Id;
    /** 市区町村ID */
    private String addrCd2Id;
    /** 大字町ID */
    private String addrCd3Id;
    /** 小字町ID */
    private String addrCd4Id;
    /** 丁目ID */
    private String addrCd5Id;
    /** 番地ID */
    private String addrCd6Id;

    /**
     * 都道府県ID
     * @return addrCd1Id
     */
    public String getAddrCd1Id() {
        return addrCd1Id;
    }
    /**
     * 都道府県ID
     * @param addrCd1Id セットする addrCd1Id
     */
    public void setAddrCd1Id(String addrCd1Id) {
        this.addrCd1Id = addrCd1Id;
    }
    /**
     * 市区町村ID
     * @return addrCd2Id
     */
    public String getAddrCd2Id() {
        return addrCd2Id;
    }
    /**
     * 市区町村ID
     * @param addrCd2Id セットする addrCd2Id
     */
    public void setAddrCd2Id(String addrCd2Id) {
        this.addrCd2Id = addrCd2Id;
    }
    /**
     * 大字町ID
     * @return addrCd3Id
     */
    public String getAddrCd3Id() {
        return addrCd3Id;
    }
    /**
     * 大字町ID
     * @param addrCd3Id セットする addrCd3Id
     */
    public void setAddrCd3Id(String addrCd3Id) {
        this.addrCd3Id = addrCd3Id;
    }
    /**
     * 小字町ID
     * @return addrCd4Id
     */
    public String getAddrCd4Id() {
        return addrCd4Id;
    }
    /**
     * 小字町ID
     * @param addrCd4Id セットする addrCd4Id
     */
    public void setAddrCd4Id(String addrCd4Id) {
        this.addrCd4Id = addrCd4Id;
    }
    /**
     * 丁目ID
     * @return addrCd5Id
     */
    public String getAddrCd5Id() {
        return addrCd5Id;
    }
    /**
     * 丁目ID
     * @param addrCd5Id セットする addrCd5Id
     */
    public void setAddrCd5Id(String addrCd5Id) {
        this.addrCd5Id = addrCd5Id;
    }
    /**
     * 番地ID
     * @return addrCd6Id
     */
    public String getAddrCd6Id() {
        return addrCd6Id;
    }
    /**
     * 番地ID
     * @param addrCd6Id セットする addrCd6Id
     */
    public void setAddrCd6Id(String addrCd6Id) {
        this.addrCd6Id = addrCd6Id;
    }
}
