package jp.co.alsok.g6.zzw.web.dao.mapper.g6;

import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

/**
 * 【利用者アカウント】
 * 時期(G6) 利用者のアカウント情報を取得 Mapper
 */
@Mapper
public interface CommonKAcntUserCommonMapper {

    /**
     * 【利用者アカウント】
     * G6利用者論理番号でG6利用者のアカウント情報を取得
     *
     * @param param G6 LN_ACNT_USER_COMMON LN_利用者アカウント共通論理番号
     * @return Map<String, Object> 利用者アカウント情報
     */
    Map<String, Object> selectG6KAcntUserCommonByAcnt(Map<String, Object> param);

    /**
     * 【利用者アカウント】
     * メールアドレスでG6利用者のアカウント情報を取得
     *
     * @param param G6 LN_ACNT_USER_COMMON LN_利用者アカウント共通論理番号
     * @return Map<String, Object> 利用者アカウント情報
     */
    Map<String, Object> selectG6KAcntUserCommonByMail(Map<String, Object> param);

    /**
     * 【利用者アカウント】
     * G6利用者論理番号でG5利用者のアカウント情報を取得
     *
     * @param param G6 LN_ACNT_USER_COMMON LN_利用者アカウント共通論理番号
     * @return Map<String, Object> 利用者アカウント情報
     */
    Map<String, Object> selectG5KeiyakuKojinMstByG6Acnt(Map<String, Object> param);

    /**
     * 【利用者アカウント】
     * G6メールアドレスでGHS利用者のアカウント情報を取得
     *
     * @param param G6 LN_ACNT_USER_COMMON LN_利用者アカウント共通論理番号
     * @return Map<String, Object> 利用者アカウント情報
     */
    Map<String, Object> selectGhsRAcntUserByG6Mail(Map<String, Object> param);

    /**
     * 【利用者アカウント】
     * GHS利用者論理番号でGHS利用者のアカウント情報を取得
     *
     * @param param G6 LN_ACNT_USER_COMMON LN_利用者アカウント共通論理番号
     * @return Map<String, Object> 利用者アカウント情報
     */
    Map<String, Object> selectGhsRAcntUserByGhsAcnt(Map<String, Object> param);

    /**
     * 【利用者アカウント】
     * G5利用者論理番号でG6利用者のアカウント情報を取得
     *
     * @param param G6 LN_ACNT_USER_COMMON LN_利用者アカウント共通論理番号
     * @return Map<String, Object> 利用者アカウント情報
     */
    Map<String, Object> selectG6KAcntUserCommonByG5Acnt(Map<String, Object> param);

    /**
     * 【利用者アカウント】
     * G5利用者論理番号でG5利用者のアカウント情報を取得
     *
     * @param param G6 LN_ACNT_USER_COMMON LN_利用者アカウント共通論理番号
     * @return Map<String, Object> 利用者アカウント情報
     */
    Map<String, Object> selectG5KeiyakuKojinMstByG5Acnt(Map<String, Object> param);

}