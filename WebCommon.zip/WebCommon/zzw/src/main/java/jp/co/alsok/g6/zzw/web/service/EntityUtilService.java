package jp.co.alsok.g6.zzw.web.service;

import java.text.ParseException;
import java.util.Date;

import org.springframework.stereotype.Service;

import jp.co.alsok.g6.common.util.string.StringUtil;
import jp.co.alsok.g6.zzw.web.constants.DbAccessConstants;
import jp.co.alsok.g6.zzw.web.constants.MassageConstants;
import jp.co.alsok.g6.zzw.web.constants.DbAccessConstants.DB_ACCESS_FLG;
import jp.co.alsok.g6.zzw.web.dto.AlsokAccountInfoDto;
import jp.co.alsok.g6.zzw.web.entity.g5.G5BaseEntity;
import jp.co.alsok.g6.zzw.web.entity.g6.G6BaseEntity;
import jp.co.alsok.g6.zzw.web.entity.ghs.GhsBaseEntity;

/**
 * G5, 次期(G6), GHSのDB共通項目設定 Service
 *
 * @author SNG-105
 */
@Service
public class EntityUtilService {

    /**
     * G6BaseEntity, G5BaseEntity, GhsBaseEntityを継承したEntityクラスの共通項目の設定を行います。
     * BaseEntityを継承しない場合にはEntityUtilReflectionServiceを利用ください。
     *
     * [ALSOKアカウント共通]
     * G5, 次期(G6), GHSのDB共通項目の設定を行う。
     * (更新日時のデータが存在する場合でも更新日時の設定を行います。)
     *
     * @param dbAccessFlg DBアクセスフラグ(1:登録 / 2:更新/ 3:削除)
     * @param baseEntity ベースエンティティ(G5BaseEntity, G6BaseEntity, GhsBaseEntity)
     * @param alsokAccountInfoDto 次期、GHS、GVのALSOKアカウント論理番号を格納したDto
     * @throws ParseException 日付変換処理エラー
     * @throws IllegalArgumentException 不適切な引数をメソッドに渡した場合
     */
    public void setCommonPropertyDateOverride(DB_ACCESS_FLG dbAccessFlg
                                              , Object baseEntity
                                              , AlsokAccountInfoDto alsokAccountInfoDto)
                                                throws ParseException, IllegalArgumentException {
        // 論理番号、アカウント名変数
        String lnAcntUserCommon = "";
        String acntNm = "";

        // ***************
        // G5の場合
        // ***************
        if (baseEntity instanceof G5BaseEntity) {

			// 次期警-管理-18008(ALSOK-NEC課題・質問管理表(画面)) No59の対応 start
            //lnAcntUserCommon = alsokAccountInfoDto.getG5UserNum();
            //acntNm = alsokAccountInfoDto.getG5LnAcntAlsokName();
            lnAcntUserCommon = this.getEmpolyeeNo(alsokAccountInfoDto.getG6UserNum());
            acntNm = alsokAccountInfoDto.getG6LnAcntAlsokName();
			// 次期警-管理-18008(ALSOK-NEC課題・質問管理表(画面)) No59の対応 end

            // 登録の場合
            if (DB_ACCESS_FLG.INSERT.getDbAcsessFlg() == dbAccessFlg.getDbAcsessFlg()) {
                this.setInsertProperty(
                                    baseEntity
                                    , lnAcntUserCommon
                                    , acntNm);
                return;
            }
            // 更新.削除の場合
            else {
                this.setUpdateProperty(
                                    baseEntity
                                    , lnAcntUserCommon
                                    , acntNm
                                    , DbAccessConstants.DATE_OVERRIDE_FLG_ON);
                return;
            }
        }
        // ***************
        // G6の場合
        // ***************
        else if (baseEntity instanceof G6BaseEntity) {

            // DTOから論理番号、アカウント名の取得
            lnAcntUserCommon = alsokAccountInfoDto.getG6LnAcntAlsokNo();
            acntNm = alsokAccountInfoDto.getG6LnAcntAlsokName();

            // 登録の場合
            if (DB_ACCESS_FLG.INSERT.getDbAcsessFlg() == dbAccessFlg.getDbAcsessFlg()) {
                this.setInsertProperty(
                                    baseEntity
                                    , lnAcntUserCommon
                                    , acntNm);
                return;
            }
            // 更新.削除の場合
            else {
                this.setUpdateProperty(
                                    baseEntity
                                    , lnAcntUserCommon
                                    , acntNm
                                    , DbAccessConstants.DATE_OVERRIDE_FLG_ON);
                return;
            }
        }
        // ***************
        // GHSの場合
        // ***************
        else if (baseEntity instanceof GhsBaseEntity) {

            // DTOから論理番号、アカウント名の取得
			// 次期警-管理-18008(ALSOK-NEC課題・質問管理表(画面)) No59の対応 start
            //lnAcntUserCommon = alsokAccountInfoDto.getGhsLnAcntAlsokNo();
            //acntNm = alsokAccountInfoDto.getGhsLnAcntAlsokName();
            lnAcntUserCommon = alsokAccountInfoDto.getG6LnAcntAlsokNo();
            acntNm = alsokAccountInfoDto.getG6LnAcntAlsokName();
			// 次期警-管理-18008(ALSOK-NEC課題・質問管理表(画面)) No59の対応 end

            // 登録の場合
            if (DB_ACCESS_FLG.INSERT.getDbAcsessFlg() == dbAccessFlg.getDbAcsessFlg()) {
                this.setInsertProperty(
                                    baseEntity
                                    , lnAcntUserCommon
                                    , acntNm);
                return;
            }
            // 更新.削除の場合
            else {
                this.setUpdateProperty(
                                    baseEntity
                                    , lnAcntUserCommon
                                    , acntNm
                                    , DbAccessConstants.DATE_OVERRIDE_FLG_ON);
                return;
            }
        }
        else {
            throw new IllegalArgumentException(MassageConstants.LZWO0203);
        }
    }

    /**
     * G6BaseEntity, G5BaseEntity, GhsBaseEntityを継承したEntityクラスの共通項目の設定を行います。
     * BaseEntityを継承しない場合にはEntityUtilReflectionServiceを利用ください。
     *
     * [ALSOKアカウント共通]
     * G5, 次期(G6), GHSのDB共通項目の設定を行う。
     * (更新日時のデータが存在する場合、更新日時を設定しません。)
     *
     * @param dbAccessFlg DBアクセスフラグ(1:登録 / 2:更新/ 3:削除)
     * @param baseEntity ベースエンティティ(G5BaseEntity, G6BaseEntity, GhsBaseEntity)
     * @param alsokAccountInfoDto 次期、GHS、GVのALSOKアカウント論理番号を格納したDto
     * @throws ParseException 日付変換処理エラー
     */
    public void setCommonProperty(DB_ACCESS_FLG dbAccessFlg
                                  , Object baseEntity
                                  , AlsokAccountInfoDto alsokAccountInfoDto)
                                    throws ParseException , IllegalArgumentException{
        // 論理番号、アカウント名変数
        String lnAcntUserCommon = "";
        String acntNm = "";

        // ***************
        // G5の場合
        // ***************
        if (baseEntity instanceof G5BaseEntity) {

            // DTOから論理番号(※ G5の場合は社員番号) 、アカウント名の取得
			// 次期警-管理-18008(ALSOK-NEC課題・質問管理表(画面)) No59の対応 start
            //lnAcntUserCommon = alsokAccountInfoDto.getG5UserNum();
            //acntNm = alsokAccountInfoDto.getG5LnAcntAlsokName();
            lnAcntUserCommon = this.getEmpolyeeNo(alsokAccountInfoDto.getG6UserNum());
            acntNm = alsokAccountInfoDto.getG6LnAcntAlsokName();
			// 次期警-管理-18008(ALSOK-NEC課題・質問管理表(画面)) No59の対応 end

            // 登録の場合
            if (DB_ACCESS_FLG.INSERT.getDbAcsessFlg() == dbAccessFlg.getDbAcsessFlg()) {
                this.setInsertProperty(
                                        baseEntity
                                        , lnAcntUserCommon
                                        , acntNm);
                return;
            }
            // 更新.削除の場合
            else {
                // 更新日時の取得
                G5BaseEntity entity = (G5BaseEntity)baseEntity;

                // 更新日時の設定有無チェック
                if (null != entity.getLASTUPD_TS()) {
                    // データが存在する場合、更新日時を設定しない。
                    this.setUpdateProperty(
                                        baseEntity
                                        , lnAcntUserCommon
                                        , acntNm
                                        , DbAccessConstants.DATE_OVERRIDE_FLG_OFF);
                    return;
                }
                // データが存在しない場合、更新日時を設定する。
                this.setUpdateProperty(
                                        baseEntity
                                        , lnAcntUserCommon
                                        , acntNm
                                        , DbAccessConstants.DATE_OVERRIDE_FLG_ON);
                return;
            }
        }
        // ***************
        // G6の場合
        // ***************
        else if (baseEntity instanceof G6BaseEntity) {

            // DTOから論理番号、アカウント名の取得
            lnAcntUserCommon = alsokAccountInfoDto.getG6LnAcntAlsokNo();
            acntNm = alsokAccountInfoDto.getG6LnAcntAlsokName();

            // 登録の場合
            if (DB_ACCESS_FLG.INSERT.getDbAcsessFlg() == dbAccessFlg.getDbAcsessFlg()) {
                this.setInsertProperty(
                                        baseEntity
                                        , lnAcntUserCommon
                                        , acntNm);
                return;
            }
            // 更新.削除の場合
            else {
                // 更新日時の取得
                G6BaseEntity entity = (G6BaseEntity)baseEntity;

                // 更新日時の設定有無チェック
                if (null != entity.getUPDATE_TS()) {
                    // データが存在する場合、更新日時を設定しない。
                     this.setUpdateProperty(
                                        baseEntity
                                        , lnAcntUserCommon
                                        , acntNm
                                        , DbAccessConstants.DATE_OVERRIDE_FLG_OFF);
                     return;
                }
                // データが存在しない場合、更新日時を設定する。
                this.setUpdateProperty(
                                        baseEntity
                                        , lnAcntUserCommon
                                        , acntNm
                                        , DbAccessConstants.DATE_OVERRIDE_FLG_ON);
                return;
            }
        }
        // ***************
        // GHSの場合
        // ***************
        else if (baseEntity instanceof GhsBaseEntity) {

        	// DTOから論理番号、アカウント名の取得
			// 次期警-管理-18008(ALSOK-NEC課題・質問管理表(画面)) No59の対応 start
            //lnAcntUserCommon = alsokAccountInfoDto.getGhsLnAcntAlsokNo();
            //acntNm = alsokAccountInfoDto.getGhsLnAcntAlsokName();
            lnAcntUserCommon = alsokAccountInfoDto.getG6LnAcntAlsokNo();
            acntNm = alsokAccountInfoDto.getG6LnAcntAlsokName();
			// 次期警-管理-18008(ALSOK-NEC課題・質問管理表(画面)) No59の対応 end

            // 登録の場合
            if (DB_ACCESS_FLG.INSERT.getDbAcsessFlg() == dbAccessFlg.getDbAcsessFlg()) {
                this.setInsertProperty(
                                        baseEntity
                                        , lnAcntUserCommon
                                        , acntNm);
                return;
            }
            // 更新.削除の場合
            else {
                // 更新日時の取得
                GhsBaseEntity entity = (GhsBaseEntity)baseEntity;

                // 更新日時の存在チェック
                if (null != entity.getUPDATE_TS()) {
                    // データが存在する場合、更新日時を設定しない。
                    this.setUpdateProperty(
                                        baseEntity
                                        , lnAcntUserCommon
                                        , acntNm
                                        , DbAccessConstants.DATE_OVERRIDE_FLG_OFF);
                    return;
                }
                // データが存在しない場合、更新日時を設定する。
                this.setUpdateProperty(
                                        baseEntity
                                        , lnAcntUserCommon
                                        , acntNm
                                        , DbAccessConstants.DATE_OVERRIDE_FLG_ON);
                return;
            }
        }
        else {
            throw new IllegalArgumentException(MassageConstants.LZWO0203);
        }
    }

    /**
     * G6BaseEntity, G5BaseEntity, GhsBaseEntityを継承したEntityクラスの共通項目の設定を行います。
     * 引数に設定された利用者アカウント共通論理番号と氏名をBaseEntityの項目に設定します。
     *
     * BaseEntityを継承しない場合にはEntityUtilReflectionServiceを利用ください。
     *
     * [利用者アカウント共通]
     * G5, G6, GHSのDB共通項目の設定を行う。
     * (更新日時のデータが存在する場合でも更新日時の設定を行います。)
     *
     * @param dbAccessFlg DBアクセスフラグ(1:登録 / 2:更新/ 3:削除)
     * @param baseEntity ベースエンティティ(G5BaseEntity, G6BaseEntity, GhsBaseEntity)
     * @param lnAcntUserCommon LN_利用者アカウント共通論理番号(G5の場合は社員番号)
     * @param アカウント名称
     * @throws ParseException 日付変換処理エラー
     */
    public void setCommonPropertyDateOverride(
            DB_ACCESS_FLG dbAccessFlg, Object baseEntity, String lnAcntUserCommon, String acntNm)
                                                                            throws ParseException {
        // ***************
        // G5の場合
        // ***************
        if (baseEntity instanceof G5BaseEntity) {
            // 登録の場合
            if (DB_ACCESS_FLG.INSERT.getDbAcsessFlg() == dbAccessFlg.getDbAcsessFlg()) {
                this.setInsertProperty(
                                    baseEntity
                                    , lnAcntUserCommon
                                    , acntNm);
                return;
            }
            // 更新.削除の場合
            else {
                this.setUpdateProperty(
                                    baseEntity
                                    , lnAcntUserCommon
                                    , acntNm
                                    , DbAccessConstants.DATE_OVERRIDE_FLG_ON);
                return;
            }
        }
        // ***************
        // G6の場合
        // ***************
        else if (baseEntity instanceof G6BaseEntity) {
             // 登録の場合
            if (DB_ACCESS_FLG.INSERT.getDbAcsessFlg() == dbAccessFlg.getDbAcsessFlg()) {
                this.setInsertProperty(
                                    baseEntity
                                    , lnAcntUserCommon
                                    , acntNm);
                return;
            }
            // 更新.削除の場合
            else {
                this.setUpdateProperty(
                                    baseEntity
                                    , lnAcntUserCommon
                                    , acntNm
                                    , DbAccessConstants.DATE_OVERRIDE_FLG_ON);
                return;
            }
        }
        // ***************
        // GHSの場合
        // ***************
        else if (baseEntity instanceof GhsBaseEntity) {
             // 登録の場合
            if (DB_ACCESS_FLG.INSERT.getDbAcsessFlg() == dbAccessFlg.getDbAcsessFlg()) {
                this.setInsertProperty(
                                    baseEntity
                                    , lnAcntUserCommon
                                    , acntNm);
                return;
            }
            // 更新.削除の場合
            else {
                this.setUpdateProperty(
                                    baseEntity
                                    , lnAcntUserCommon
                                    , acntNm
                                    , DbAccessConstants.DATE_OVERRIDE_FLG_ON);
                return;
            }
        }
        else {
            throw new IllegalArgumentException(MassageConstants.LZWO0203);
        }
    }

    /**
     * G6BaseEntity, G5BaseEntity, GhsBaseEntityを継承したEntityクラスの共通項目の設定を行います。
     * 引数に設定された利用者アカウント共通論理番号と氏名をBaseEntityの項目に設定します。
     *
     * BaseEntityを継承しない場合にはEntityUtilReflectionServiceを利用ください。
     *
     * [利用者アカウント共通]
     * G5, G6, GHSのDB共通項目の設定を行う。
     * (更新日時のデータが存在する場合、更新日時を設定しません。)
     *
     * @param dbAccessFlg DBアクセスフラグ(1:登録 / 2:更新/ 3:削除)
     * @param baseEntity ベースエンティティ(G5BaseEntity, G6BaseEntity, GhsBaseEntity)
     * @param lnAcntUserCommon LN_利用者アカウント共通論理番号/(G5の場合は社員番号)
     * @param アカウント名称
     * @throws ParseException 日付変換処理エラー
     */
    public void setCommonProperty(
            DB_ACCESS_FLG dbAccessFlg, Object baseEntity, String lnAcntUserCommon, String acntNm)
                                                                            throws ParseException {
        // ***************
        // G5の場合
        // ***************
        if (baseEntity instanceof G5BaseEntity) {
            // 登録の場合
            if (DB_ACCESS_FLG.INSERT.getDbAcsessFlg() == dbAccessFlg.getDbAcsessFlg()) {
                this.setInsertProperty(
                                    baseEntity
                                    , lnAcntUserCommon
                                    , acntNm);
                return;
            }
            // 更新.削除の場合
            else {
                // 更新日時の取得
                G5BaseEntity entity = (G5BaseEntity)baseEntity;

                // 更新日時の設定有無チェック
                if (null != entity.getLASTUPD_TS()) {
                    // データが存在する場合、更新日時を設定しない
                    this.setUpdateProperty(
                                    baseEntity
                                    , lnAcntUserCommon
                                    , acntNm
                                    , DbAccessConstants.DATE_OVERRIDE_FLG_OFF);
                    return;
                }
                // データが存在しない場合、更新日時を設定する。
                this.setUpdateProperty(
                                    baseEntity
                                    , lnAcntUserCommon
                                    , acntNm
                                    , DbAccessConstants.DATE_OVERRIDE_FLG_ON);
                return;
            }
        }
        // ***************
        // G6の場合
        // ***************
        else if (baseEntity instanceof G6BaseEntity) {
            // 登録の場合
            if (DB_ACCESS_FLG.INSERT.getDbAcsessFlg() == dbAccessFlg.getDbAcsessFlg()) {
                this.setInsertProperty(
                                    baseEntity
                                    , lnAcntUserCommon
                                    , acntNm);
                return;
            }
            // 更新.削除の場合
            else {
                  // 更新日時の取得
                G6BaseEntity entity = (G6BaseEntity)baseEntity;

                // 更新日時の設定有無チェック
                if (null != entity.getUPDATE_TS()) {
                    // データが存在する場合、更新日時を設定しない。
                    this.setUpdateProperty(
                                    baseEntity
                                    , lnAcntUserCommon
                                    , acntNm
                                    , DbAccessConstants.DATE_OVERRIDE_FLG_OFF);
                    return;
                }
                // データが存在しない場合、更新日時を設定する。
                this.setUpdateProperty(
                                    baseEntity
                                    , lnAcntUserCommon
                                    , acntNm
                                    , DbAccessConstants.DATE_OVERRIDE_FLG_ON);
                return;
            }
        }
        // ***************
        // GHSの場合
        // ***************
        else if (baseEntity instanceof GhsBaseEntity) {
             // 登録の場合
            if (DB_ACCESS_FLG.INSERT.getDbAcsessFlg() == dbAccessFlg.getDbAcsessFlg()) {
                this.setInsertProperty(
                                    baseEntity
                                    , lnAcntUserCommon
                                    , acntNm);
                return;
            }
            // 更新.削除の場合
            else {
                // 更新日時の取得
                GhsBaseEntity entity = (GhsBaseEntity)baseEntity;

                // 更新日時の設定有無チェック
                if (null != entity.getUPDATE_TS()) {
                    // データが存在する場合、更新日時を設定しない。
                    this.setUpdateProperty(
                                    baseEntity
                                    , lnAcntUserCommon
                                    , acntNm
                                    , DbAccessConstants.DATE_OVERRIDE_FLG_OFF);
                    return;
                }
                // データが存在しない場合、更新日時を設定する。
                this.setUpdateProperty(
                                    baseEntity
                                    , lnAcntUserCommon
                                    , acntNm
                                    , DbAccessConstants.DATE_OVERRIDE_FLG_ON);
                return;
            }
        }
        else {
            throw new IllegalArgumentException(MassageConstants.LZWO0203);
        }
    }

    /**
     * ALSOKアカウント, 利用者アカウントINSERTの場合の項目設定
     *
     * @param baseEntity 対象のbaseEntity
     * @param lnAcntUserCommon LN_利用者アカウント共通論理番号
     * @param acntNm アカウント名称
     */
    private void setInsertProperty(Object baseEntity, String lnAcntUserCommon, String acntNm) {

        // システム日付を取得
        Date nowDate = new Date();

        // G5の場合の項目設定
        if (baseEntity instanceof G5BaseEntity) {
            G5BaseEntity entity = (G5BaseEntity)baseEntity;
            // 登録者ID
            entity.setID_INSERT(lnAcntUserCommon);
            // 登録者名
            entity.setINSERT_NM(acntNm);
            // 登録日時
            entity.setINSERT_TS(nowDate);
            // 更新者ID
            entity.setID_LASTUPD(lnAcntUserCommon);
            // 更新者名
            entity.setLASTUPD_NM(acntNm);
            // 更新日時
            entity.setLASTUPD_TS(nowDate);
            return;
        }

        // G6の場合の項目設定
        if (baseEntity instanceof G6BaseEntity) {
            G6BaseEntity entity = (G6BaseEntity)baseEntity;
            // 登録者ID
            entity.setINSERT_ID(lnAcntUserCommon);
            // 登録者名
            entity.setINSERT_NM(acntNm);
            // 登録日時
            entity.setINSERT_TS(nowDate);
            // 更新者ID
            entity.setUPDATE_ID(lnAcntUserCommon);
            // 更新者名
            entity.setUPDATE_NM(acntNm);
            // 更新日時
            entity.setUPDATE_TS(nowDate);
            return;
        }

        // GHSの場合の項目設定
        if (baseEntity instanceof GhsBaseEntity) {
            GhsBaseEntity entity = (GhsBaseEntity)baseEntity;
            // 登録者ID
            entity.setID_INSERT(lnAcntUserCommon);
            // 登録者名
            entity.setINSERT_NM(acntNm);
            // 登録日時
            entity.setINSERT_TS(nowDate);
            // 更新者ID
            entity.setID_UPDATE(lnAcntUserCommon);
            // 更新者名
            entity.setUPDATE_NM(acntNm);
            // 更新日時
            entity.setUPDATE_TS(nowDate);
        }
    }

    /**
     * ALSOKアカウント, 利用者アカウントUPDATE, DELETEの場合の項目設定
     *
     * @param baseEntity 対象のbaseEntity
     * @param lnAcntUserCommon LN_利用者アカウント共通論理番号
     * @param acntNm アカウント名称
     */
    private void setUpdateProperty(Object baseEntity, String lnAcntUserCommon, String acntNm, int dateOverrideFlg) {

        // システム日付を取得
        Date nowDate = new Date();

        // G5の場合の項目設定
        if (baseEntity instanceof G5BaseEntity) {
            G5BaseEntity entity = (G5BaseEntity)baseEntity;
            // 更新者ID
            entity.setID_LASTUPD(lnAcntUserCommon);
            // 更新者名
            entity.setLASTUPD_NM(acntNm);
            // 更新日時
            if (DbAccessConstants.DATE_OVERRIDE_FLG_ON == dateOverrideFlg) {
                entity.setLASTUPD_TS(nowDate);
            }
            return;
        }

        // G6の場合の項目設定
        if (baseEntity instanceof G6BaseEntity) {
            G6BaseEntity entity = (G6BaseEntity)baseEntity;
            // 更新者ID
            entity.setUPDATE_ID(lnAcntUserCommon);
            // 更新者名
            entity.setUPDATE_NM(acntNm);
            // 更新日時
            if (DbAccessConstants.DATE_OVERRIDE_FLG_ON == dateOverrideFlg) {
                entity.setUPDATE_TS(nowDate);
            }
            return;
        }

        // GHSの場合の項目設定
        if (baseEntity instanceof GhsBaseEntity) {
            GhsBaseEntity entity = (GhsBaseEntity)baseEntity;
            // 更新者ID
            entity.setID_UPDATE(lnAcntUserCommon);
            // 更新者名
            entity.setUPDATE_NM(acntNm);
            // 更新日時
            if (DbAccessConstants.DATE_OVERRIDE_FLG_ON == dateOverrideFlg) {
                entity.setUPDATE_TS(nowDate);
            }
        }
    }

	/**
	 * 引数noから末尾6文字を切り出して返却します。
	 *
	 * @param no
	 * @return
	 */
	private String getEmpolyeeNo(String no) {

		String empolyeeNo = no;

		if (StringUtil.isNullOrEmpty(no)) {
			return null;
		}

		if (no.length() > 6) {
			for (int i = 0; i < no.length(); i++) {
				if (no.length() - i == 6) {
					empolyeeNo = no.substring(i);
				}
			}
		}

		return empolyeeNo;
	}

}
