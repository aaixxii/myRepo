package jp.co.alsok.g6.zzw;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InjectionPoint;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.context.annotation.Scope;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.jmx.support.RegistrationPolicy;

/**
 * Bean設定
 *
 * @author SSC
 */
@Configuration
@EnableMBeanExport(registration = RegistrationPolicy.IGNORE_EXISTING)
@Aspect
public class BeanConfig {
	/**
	 * Autowired対応ロガー
	 *
	 * @param ip
	 *            インジェクションポイント
	 * @return ロガー
	 */
	@Bean
	@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
	public Logger logger(InjectionPoint ip) {
		return LoggerFactory.getLogger(ip.getMember().getDeclaringClass());
	}

	/**
	 * commondbデータベースアクセス用
	 *
	 * @author SSC
	 */
	@Configuration
	@ConfigurationProperties(prefix = "commondb.datasource")
	static class CommondbConfig {
		/** JNDI名 */
		private String jndiName;
		/**
		 * JNDI名を取得する。
		 * @return JNDI名
		 */
		public String getJndiName() {
			return this.jndiName;
		}
		/**
		 * JNDI名を設定する。
		 * @param jndiName 設定するJNDI名
		 */
		public void setJndiName(String jndiName) {
			this.jndiName = jndiName;
		}
		/**
		 * @return commondbデータベースアクセス用
		 */
		@Bean("commondb")
		public JdbcTemplate commondb() {
			JndiDataSourceLookup jndiDataSourceLookup = new JndiDataSourceLookup();
			return new JdbcTemplate(jndiDataSourceLookup.getDataSource(jndiName));
		}
	}

	/**
	 * g6dbデータベースアクセス用
	 *
	 * @author SSC
	 */
	@Configuration
	@ConfigurationProperties(prefix = "g6db.datasource")
	static class G6dbConfig {
		/** JNDI名 */
		private String jndiName;
		/**
		 * JNDI名を取得する。
		 * @return JNDI名
		 */
		public String getJndiName() {
			return this.jndiName;
		}
		/**
		 * JNDI名を設定する。
		 * @param jndiName 設定するJNDI名
		 */
		public void setJndiName(String jndiName) {
			this.jndiName = jndiName;
		}
		/**
		 * @return g6dbデータベースアクセス用
		 */
		@Bean("g6db")
		public JdbcTemplate g6db() {
			JndiDataSourceLookup jndiDataSourceLookup = new JndiDataSourceLookup();
			return new JdbcTemplate(jndiDataSourceLookup.getDataSource(jndiName));
		}
	}

	/**
	 * メソッド開始、終了時にログを出す
	 *
	 * @param point
	 *            ジョイントポイント
	 * @return メソッドの戻り値
	 * @throws Throwable
	 *             例外
	 */
	@Around("execution(public * jp.co.alsok.g6.zzw.web.G6*Impl.*(..))")
	public Object around(ProceedingJoinPoint point) throws Throwable {
		final Logger logger = LoggerFactory.getLogger(point.getTarget().getClass());
		// 引数の検証
		new ValidateArgs(((MethodSignature) point.getSignature()).getMethod()).validate(point.getArgs());
		// メソッド開始ログ
		logger.debug("begin@" + point.getSignature());
		// メソッド実行
		Object result = point.proceed();
		// メソッド終了ログ
		logger.debug("end@" + point.getSignature());
		return result;
	}
}
