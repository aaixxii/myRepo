package jp.co.alsok.g6.zzw.web.dao.mapper.g6;

import org.apache.ibatis.annotations.Mapper;

import jp.co.alsok.g6.zzw.web.entity.g6.HLogAlsokUserOperation;

/**
 * ALSOK操作履歴 Mapper
 */
@Mapper
public interface CommonHLogAlsokUserOperationMapper {

    /**
     * ALSOK操作履歴 登録
     *
     * @param record ALSOK操作履歴Entity
     */
    int insert(HLogAlsokUserOperation record);
}