package jp.co.alsok.g6.zzw.web.entity.g6;

public class LoginUserInfo {
    
    private String lnAcntAlsok;
    private String jigyouCd;
    private String mlAddr;
    private String passwd;
    private String userNm;
    private String userNum;

    public String getLnAcntAlsok() {
        return lnAcntAlsok;
    }
    public void setLnAcntAlsok(String lnAcntAlsok) {
        this.lnAcntAlsok = lnAcntAlsok;
    }
    public String getJigyouCd() {
        return jigyouCd;
    }
    public void setJigyouCd(String jigyouCd) {
        this.jigyouCd = jigyouCd;
    }
    public String getMlAddr() {
        return mlAddr;
    }
    public void setMlAddr(String mlAddr) {
        this.mlAddr = mlAddr;
    }
    public String getPasswd() {
        return passwd;
    }
    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }
    public String getUserNm() {
        return userNm;
    }
    public void setUserNm(String userNm) {
        this.userNm = userNm;
    }
    public String getUserNum() {
        return userNum;
    }
    public void setUserNum(String userNum) {
        this.userNum = userNum;
    } 

}
