package jp.co.alsok.g6.zzw.web.repository.g6;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import jp.co.alsok.g6.zzw.web.dao.mapper.g6.CommonAcntAlsokInfoMapper;

@Repository
public class AcntAlsokInfoRepository {

    @Autowired
    private CommonAcntAlsokInfoMapper acntAlsokInfoMapper;

    public List<String> selectAuthorityByLnAcntAlsok(String lnAcntAlsok) {
        return acntAlsokInfoMapper.selectAuthorityByLnAcntAlsok(lnAcntAlsok);
    }
}
