package jp.co.alsok.g6.zzw.web.service;

import org.springframework.data.domain.AbstractPageRequest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

/**
 * ページング共通部品 <br>
 * リクエストパラメータで自動生成された Pageable を利用せずに <br>
 * Pageable を個別に生成する <br>
 *
 * @author NEC
 */
public class PagenationPageRequest extends AbstractPageRequest {

	/**
	 * コンストラクタ<br>
	 * 引数の値で、ページ数、表示件数、の値を設定して Pageable を生成する<br>
	 * <br>
	 * @param page ページ数
	 * @param size 表示件数( 行数 )
	 */
	public PagenationPageRequest(int page, int size) {
		super(page, size);
	}

	/**
	 * ソートするパラメータを返却する <br>
	 * 2018/06時点で未使用のため未実装 <br>
	 */
	@Override
	public Sort getSort() {
		return null;
	}

	/**
	 * first：先頭ページ取得 <br>
	 * 2018/06時点で未使用のため未実装 <br>
	 * <br>
	 * @see org.springframework.data.domain.Pageable#first()
	 */
	@Override
	public Pageable first() {
		return null;
	}

	/**
	 * next：次ページ取得 <br>
	 * 2018/06時点で未使用のため未実装 <br>
	 * <br>
	 * @see org.springframework.data.domain.Pageable#next()
	 */
	@Override
	public Pageable next() {
		return null;
	}

	/**
	 * previous：前ページ取得 <br>
	 * 2018/06時点で未使用のため未実装 <br>
	 * <br>
	 * Returns the {@link Pageable} requesting the previous {@link Page}.
	 */
	@Override
	public Pageable previous() {
		return null;
	}
}
