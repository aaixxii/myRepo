/**
 *
 */
package jp.co.alsok.g6.zzw.web.dto;

import java.util.ArrayList;
import java.util.List;


public class KeibisakiInfoDto {
	/** 取得DBフラグ */
	private int systemId;

	/** LN_警備先論理番号 */
	private String lnKeibi;

	/** 警備先 */
	private KeibisakiDto keibisaki = new KeibisakiDto();

	/** 警備先地区 */
	private List<KeibichikuDto> keibichiku = new ArrayList<KeibichikuDto>();

	/** 契約先 */
	private KeiyakusakiDto keiyakusaki = new KeiyakusakiDto();

	/**
	* systemId 取得
	* @return systemId
	*/
	public int getSystemId() {
		return systemId;
	}

	/**
	* @param lnKeibi 設定 lnKeibi
	*/
	public void setLnKeibi(String lnKeibi) {
		this.lnKeibi = lnKeibi;
	}

	/**
	* lnKeibi 取得
	* @return lnKeibi
	*/
	public String getLnKeibiId() {
		return lnKeibi;
	}

	/**
	* @param systemId 設定 systemId
	*/
	public void setSystemId(int systemId) {
		this.systemId = systemId;
	}

	/**
	* keibisaki 取得
	* @return keibisaki
	*/
	public KeibisakiDto getKeibisaki() {
		return keibisaki;
	}

	/**
	* @param keibisaki 設定 keibisaki
	*/
	public void setKeibisaki(KeibisakiDto keibisaki) {
		this.keibisaki = keibisaki;
	}

	/**
	* keibichiku 取得
	* @return keibichiku
	*/
	public List<KeibichikuDto> getKeibichiku() {
		return keibichiku;
	}

	/**
	* @param keibichiku 設定 keibichiku
	*/
	public void setKeibichiku(List<KeibichikuDto> keibichiku) {
		this.keibichiku = keibichiku;
	}

	/**
	* keiyakusaki 取得
	* @return keiyakusaki
	*/
	public KeiyakusakiDto getKeiyakusaki() {
		return keiyakusaki;
	}

	/**
	* @param keiyakusaki 設定 keiyakusaki
	*/
	public void setKeiyakusaki(KeiyakusakiDto keiyakusaki) {
		this.keiyakusaki = keiyakusaki;
	}


}
