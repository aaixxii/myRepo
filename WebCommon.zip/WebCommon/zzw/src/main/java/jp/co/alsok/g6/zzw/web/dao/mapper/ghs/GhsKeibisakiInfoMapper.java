package jp.co.alsok.g6.zzw.web.dao.mapper.ghs;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import jp.co.alsok.g6.zzw.web.dto.KeibisakiInfoDto;

@Mapper
public interface GhsKeibisakiInfoMapper {
	/**
     * LN_利用者アカウント共通論理番号を基にログインユーザ情報を取得する。
     *
     * @param param LN_利用者アカウント共通論理番号
     * @return 警備先情報リスト
     */
	List<KeibisakiInfoDto> selectGhsKeibisakiInfo(Map<String, Object> param);

	/**
     * LN_利用者アカウント共通論理番号を基にログインユーザ情報を取得する。
     *
     * @param param LN_利用者アカウント共通論理番号
     * @return ログインユーザ情報
     */
	Map<String, Object> selectGhsACnt(Map<String, Object> param);
}
