package jp.co.alsok.g6.zzw.web.dao.mapper.g6;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

/**
 * ALSOKアカウント関連情報を扱うMapperクラスです。
 *
 * @author SNG
 *
 */
@Mapper
public interface CommonAcntAlsokInfoMapper {

    /**
     * LN_ALSOKアカウント論理番号を基に権限リストを取得する。
     *
     * @param lnAcntAlsok LN_ALSOKアカウント論理番号
     * @return 権限リスト
     */
    List<String> selectAuthorityByLnAcntAlsok(String lnAcntAlsok);
}
