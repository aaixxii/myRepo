package jp.co.alsok.g6.zzw.web.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import jp.co.alsok.g6.zzw.util.StringUtil;
import jp.co.alsok.g6.zzw.web.dao.mapper.g5.CommonOperatorMstMapper;
import jp.co.alsok.g6.zzw.web.dao.mapper.g6.CommonKAcntAlsokMapper;
import jp.co.alsok.g6.zzw.web.dao.mapper.ghs.CommonRAcntAlsokMapper;
import jp.co.alsok.g6.zzw.web.dto.AlsokAccountInfoDto;
import jp.co.alsok.g6.zzw.web.entity.g5.OperatorMst;
import jp.co.alsok.g6.zzw.web.entity.g5.OperatorMstCondition;
import jp.co.alsok.g6.zzw.web.entity.g6.KAcntAlsok;
import jp.co.alsok.g6.zzw.web.entity.g6.KAcntAlsokCondition;
import jp.co.alsok.g6.zzw.web.entity.ghs.RAcntAlsok;
import jp.co.alsok.g6.zzw.web.entity.ghs.RAcntAlsokCondition;
/**
 * 時期,G5,GHSのアカウント論理番号、アカウント名、社員番号取得
 * g5,g6,ghs DBアクセス Service
 *
 */
@Service
public class AlsokAccountInfoService {

    @Autowired
    CommonKAcntAlsokMapper kAcntAlsokMapper;
    @Autowired
    CommonRAcntAlsokMapper ghsRAcntAlsokMapper;
    @Autowired
    CommonOperatorMstMapper operatorMstMapper;
//	@Autowired
//	TaiinMstMapper taiinMstMapper;

    /**
     * G6のAlsokアカウント情報を取得する
     *
     * @param lnAcntAlsokNo 時期Alsokアカウント論理番号
     * @param result (次期Alsokアカウント論理番号, 次期Alsokアカウント名, 次期社員番号)
    */
    @Transactional(propagation = Propagation.SUPPORTS)
    public AlsokAccountInfoDto setG6AccountInfo(String lnAcntAlsokNo, AlsokAccountInfoDto result) {

        KAcntAlsokCondition kAcntAlsokCondition = new KAcntAlsokCondition();
        kAcntAlsokCondition.createCriteria().andLN_ACNT_ALSOKEqualTo(lnAcntAlsokNo);
        List<KAcntAlsok> list = kAcntAlsokMapper.selectByCondition(kAcntAlsokCondition);

        // 返却値は1件のみ
        for(KAcntAlsok entity : list) {
            // G6 Alsokアカウント論理番号
            result.setG6LnAcntAlsokNo(entity.getLN_ACNT_ALSOK());
            // G6 Alsokアカウント名
            result.setG6LnAcntAlsokName(entity.getUSER_NM());
            // G6 社員番号
            result.setG6UserNum(entity.getUSER_NUM());
            // G6 事業所コード
            result.setG6JigyouCd(entity.getJIGYOU_CD());
            break;
        }
        return result;
    }

    /**
     * 次期(G6)社員番号を基に[GHS]のアカウント情報を取得する。
     *
     * @param g6UserNum g6社員番号
     * @param g6JigyouCd G6事業所コード
     * @param result AlsokAccountInfoDto
    */
    @Transactional(propagation = Propagation.SUPPORTS)
    public AlsokAccountInfoDto setGhsAccountInfo(String g6UserNum, String g6JigyouCd, AlsokAccountInfoDto result) {

        // TODO:仮実装
        // 社員番号の桁数の下6桁のみ取得する。
        if (StringUtil.isNullOrEmpty(g6UserNum)) {
            // 社員番号が取得できない場合
            return result;
        }
        String userNum6keta = g6UserNum.substring(14, 20);

        // 次期社員番号を基に[R_ACNT_ALSOKテーブル]にアクセスし、GHSのアカウント論理番号、アカウント名を取得
        RAcntAlsokCondition rAcntAlsokCondition = new RAcntAlsokCondition();
        rAcntAlsokCondition.createCriteria().andUSER_NUMEqualTo(userNum6keta)
                                            .andJIGYOU_CDEqualTo(g6JigyouCd);
        List<RAcntAlsok> list = ghsRAcntAlsokMapper.selectByCondition(rAcntAlsokCondition);

        // 返却値は1件のみ
        for(RAcntAlsok entity : list) {
            // GHS Alsokアカウント論理番号
            result.setGhsLnAcntAlsokNo(entity.getLN_ACNT_ALSOK());
            // GHS Alsokアカウント名
            result.setGhsLnAcntAlsokName(entity.getUSER_NM());
            // GHS 社員番号
            result.setGhsUserNum(entity.getUSER_NUM());
            // GHS 事業所コード
            result.setGhsJigyouCd(entity.getJIGYOU_CD());
            break;
        }
        return result;
    }

    /**
     * 次期(G6)社員番号を基に[G5]のアカウント情報を取得する。
     *
     * @param g6UserNum g6社員番号
     * @param g6JigyouCd G6事業所コード
     * @param result AlsokAccountInfoDto
     */
    @Transactional(propagation = Propagation.SUPPORTS)
    public AlsokAccountInfoDto setG5AccountInfo(String g6UserNum, String g6JigyouCd, AlsokAccountInfoDto result) {

        // TODO:仮実装
        // 社員番号の桁数の下6桁のみ取得する。
        if (StringUtil.isNullOrEmpty(g6UserNum)) {
            // 社員番号が取得できない場合
            return result;
        }
        String userNum6keta = g6UserNum.substring(14, 20);

        // TODO: データを取得するテーブルが「R_ACNT_ALSOK」「OperatorMst」のどちらが正しいか確認中の為、コメントアウト
        // 次期社員番号を基に[R_ACNT_ALSOKテーブル]にアクセスし、G5のアカウント論理番号、アカウント名を取得
//        TaiinMstCondition taiinMstCondition = new TaiinMstCondition();
//        taiinMstCondition.createCriteria().andSYAIN_NUMEqualTo(userNum6keta);
//        List<TaiinMst> list = taiinMstMapper.selectByCondition(taiinMstCondition);

        OperatorMstCondition operatorMstCondition = new OperatorMstCondition();
        operatorMstCondition.createCriteria().andSYAIN_NUMEqualTo(userNum6keta)
                                             .andID_JIGYOUEqualTo(g6JigyouCd);
        List<OperatorMst> list = operatorMstMapper.selectByCondition(operatorMstCondition);

        // 返却値は1件のみ
        for(OperatorMst entity : list) {
            // G5 Alsokアカウント論理番号
            result.setG5LnAcntAlsokNo(entity.getLN_OPERATOR());
            // G5 Alsokアカウント名
            result.setG5LnAcntAlsokName(entity.getNM());
            // G5 社員番号
            result.setG5UserNum(entity.getSYAIN_NUM());
            // G5 事業所コード
            result.setG5JigyouCd(entity.getID_JIGYOU());
            break;
        }
        return result;
    }
}
