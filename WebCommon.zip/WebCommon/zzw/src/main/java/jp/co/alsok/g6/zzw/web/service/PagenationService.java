package jp.co.alsok.g6.zzw.web.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;


/**
 * ページング共通部品
 *
 * @author NEC
 */
@Service
public class PagenationService {

    /**
     * List<E>からpageNo, pageSizeで指定ページの件数をList(Page)形式で返却します。
     *
     * @param pageNo 抽出するページ番号 0～n
     * @param pageSize ページ内の表示件数
     * @param list List<E> セッションで保持している表示用リスト
	 * @param indxSize  ページ番号を表示する最大件数
     * @return Page<E>
     */
	public <E> Page<E> getTargetPage(int pageNo, int pageSize, List<E> list, int indxSize ) {

        int totalListCount = (list != null) ? list.size() : 0; //表示リストの全件数
        int fromIndex       = pageSize * pageNo;        //開始する行数位置
        int toIndex         = fromIndex + pageSize;     //終了する行数位置
        toIndex = ( toIndex > totalListCount ) ? totalListCount : toIndex ;

        List<E> findList = new ArrayList<E>();
        findList = (list != null) ? list.subList( fromIndex, toIndex ) : findList;

        Pageable limit = new PagenationPageRequest( pageNo, pageSize );

        @SuppressWarnings("unchecked")
        Page<E> result = new PagenationImpl<>( findList, limit, totalListCount );

        //ページ数の幅( ページイインデックス数 )を編集して、返却する
        return setPageSize( pageNo
                           , pageSize
                           , indxSize
                           , totalListCount
                           , result
                           );
    }

    /**
     * SQL文の｢ limit ｣｢ offset ｣を使用する場合
     * pageNo, pageSizeで指定ページの件数をList(Page)形式で返却します。
     *
     * @param pageNo    抽出するページ番号 0～n
     * @param pageSize  ページ内の表示件数
     * @param list      SQL文の｢ limit ｣｢ offset ｣を使用したＤＢからの取得データリスト
     * @param listSize  SQL文の｢ limit ｣｢ offset ｣を使用しない場合の取得対象データ件数( 全件数 )
	 * @param indxSize  ページ番号を表示する最大件数
     * @return Page<E>
     */
    public <E> Page<E> getTargetPage(int pageNo, int pageSize, List<E> list, int listSize, int indxSize) {

        int fromIndex = pageSize * pageNo;        //開始する行数位置
        int toIndex   = fromIndex + pageSize;     //終了する行数位置
        toIndex = ( toIndex > listSize ) ? listSize : toIndex ;

        Pageable limit = new PagenationPageRequest( pageNo, pageSize );

        List<E> findList = new ArrayList<E>();
        findList = (list != null) ? list : findList;

        @SuppressWarnings("unchecked")
		Page<E> result = new PagenationImpl<>( findList, limit, listSize );

        //ページ数の幅( ページイインデックス数 )を編集して、返却する
        return setPageSize( pageNo
                           , pageSize
                           , indxSize
                           , listSize
                           , result
                           );
    }


    /**
     * ページ数の幅( ページイインデックス数 )を編集
     *
     * @param movePageNo
     * @param pageRowCount
     * @param createLinkSize
     * @param listSize
     * @param page
     * @return
     */
    private <E> Page<E> setPageSize( int movePageNo
                                    , int pageRowCount
                                    , int createLinkSize
                                    , int listSize
                                    , Page<E> page
                                    ){
        //表示するページインデックスの数、開始ページ、終了ページを算出する

        //全体のページ数
        int maxPageSize = listSize / pageRowCount;
        int maxPageSizeMod = listSize % pageRowCount;
        if (maxPageSizeMod == 0) {
        	// 全件数と表示件数がちょうど割り切れる際に余計なページリンクが生成されてしまうのでリンク生成数を-1する。
        	maxPageSize--;
        }

        // Linkは0～始まるため-1して調整する
        createLinkSize--;

        //後半分
        int backSpan  = createLinkSize / 2;
        //前半分
        int forthSpan = createLinkSize - backSpan;

        //表示幅に従うと存在しないページ(0ページ以下)が生成されるので、１ページ目から始める
        if (movePageNo - backSpan < 1) {

            int wkEndPage = ( createLinkSize < maxPageSize ) ? createLinkSize : maxPageSize;

            ((PagenationImpl<?>) page).setStartPage( 0 );
            ((PagenationImpl<?>) page).setEndPage( wkEndPage );

        //表示幅に従うと存在しないページ(最終ページ以降)が生成されるので、
    	//表示領域を最終ページから逆算する
        } else if (movePageNo + forthSpan > maxPageSize) {

            int wkStartPage = ( maxPageSize - createLinkSize > 1 ) ? maxPageSize - createLinkSize : 1;

            ((PagenationImpl<?>) page).setStartPage( wkStartPage  );
            ((PagenationImpl<?>) page).setEndPage( maxPageSize );

        // その間なので、中央に pageNo がくるように配置する。
        // ページのリストの端に当たっていないので、単純に中央にくるような両端を考えればよい。
        } else {
            ((PagenationImpl<?>) page).setStartPage( movePageNo - backSpan );
            ((PagenationImpl<?>) page).setEndPage( movePageNo + forthSpan );
        }
        return page;
    }
}
