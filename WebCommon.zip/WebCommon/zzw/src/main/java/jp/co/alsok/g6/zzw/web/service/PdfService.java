package jp.co.alsok.g6.zzw.web.service;

import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.springframework.stereotype.Service;

/**
 * PDF関連の処理を行うサービス.<br>
 */
@Service
public class PdfService {

	/**
	 * PDFの全ページをJPEGに変換してJPEGデータのリストを返却します.<br>
	 *
	 * @param pdfData PDFデータ
	 * @return PDF全ページをJPEG化したデータのリスト<br>
	 * 			リストにはページ順に格納されます<br>
	 * @throws IOException PDFファイル読み込みに失敗した場合
	 * @throws InvalidPasswordException PDFファイルのパスワードがかかっており、パスワードが一致しない場合
	 */
	public List<byte[]> toJpeg(byte[] pdfData) throws InvalidPasswordException, IOException {
		List<byte[]> result = new ArrayList<>();
		try(PDDocument document = PDDocument.load(pdfData)) {
			PDFRenderer renderer = new PDFRenderer(document);
			byte[] imageData = null;
			BufferedImage bufferedImage = null;
			ByteArrayOutputStream baos = null;
			BufferedOutputStream bos = null;
			int pageCount = document.getNumberOfPages();
			for (int pageIndex = 0; pageIndex < pageCount; pageIndex++) {
				bufferedImage = renderer.renderImage(pageIndex);
				baos = new ByteArrayOutputStream();
				bos = new BufferedOutputStream(baos);
				ImageIO.write(bufferedImage, "jpeg", bos);
				imageData = baos.toByteArray();
				result.add(imageData);
			}
		}
		return result;
	}

	/**
	 * PDFファイルの全ページをJPEG化して指定されたフォルダに出力します.<br>
	 * 出力するJPEGファイル名は "00123.jpeg" のように、[0から始まる連番の5桁0パディング形式] + ".jpeg" となります。<br>
	 *
	 * @param pdfPath PDFファイルのパス
	 * @param outputDir 出力先フォルダのパス
	 * @throws IOException PDFファイル読み込みに失敗した場合<br>
	 * 						JPEG出力先フォルダの作成に失敗した場合<br>
	 * 						JPEGファイル出力に失敗した場合<br>
	 * @throws InvalidPasswordException PDFファイルのパスワードがかかっており、パスワードが一致しない場合
	 */
	public void outputJpeg(String pdfPath, String outputDir) throws InvalidPasswordException, IOException{
		Path outputDirPath = Paths.get(outputDir);
		Files.createDirectories(outputDirPath);
		File pdfFile = new File(pdfPath);
		try(PDDocument document = PDDocument.load(pdfFile)) {
			PDFRenderer renderer = new PDFRenderer(document);
			BufferedImage bufferedImage = null;
			int pageCount = document.getNumberOfPages();
			for (int pageIndex = 0; pageIndex < pageCount; pageIndex++) {
				bufferedImage = renderer.renderImage(pageIndex);
				ImageIO.write(bufferedImage, "jpeg", new File(outputDir + "/" + String.format("%05d.jpeg", pageIndex)));
			}
		}
	}
}
