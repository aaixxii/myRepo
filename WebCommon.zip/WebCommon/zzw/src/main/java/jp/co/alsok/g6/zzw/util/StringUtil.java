package jp.co.alsok.g6.zzw.util;

/**
 * 文字列関連の共通部品.
 */
public class StringUtil {

	/**
	 * 文字列がNull、または、空か判定します。<br>
	 *
	 * @param value
	 *            文字列
	 * @return {@code true} 文字列がNull、または、空の場合<br>
	 *         {@code false} 文字列に何かしら値が入っている場合<br>
	 */
	public static boolean isNullOrEmpty(final String value) {
		return value == null || value.length() == 0;
	}

	/**
	 * 文字列に何か値が入っているか判定します。<br>
	 *
	 * @param value
	 *            文字列
	 * @return {@code true} 文字列に何かしら値が入っている場合<br>
	 *         {@code false} 文字列がNull、または、空の場合<br>
	 */
	public static boolean isNotNullOrEmpty(final String value) {
		return !isNullOrEmpty(value);
	}
}
