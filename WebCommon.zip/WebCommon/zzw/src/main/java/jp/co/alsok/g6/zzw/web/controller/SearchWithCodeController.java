package jp.co.alsok.g6.zzw.web.controller;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.xml.sax.SAXException;

import jp.co.alsok.g6.zzw.web.constants.CommonComponentConstants.CODE_SEARCH_TYPE;
import jp.co.alsok.g6.zzw.web.dto.SearchWithCodeDto;
import jp.co.alsok.g6.zzw.web.service.SearchWithCodeService;
import net.arnx.jsonic.JSON;

/**
 * コード検索テキストボックス用のコントローラークラスです
 * @author SNG
 *
 */
@RestController
@RequestMapping("/common/SearchWithCode")
public class SearchWithCodeController {

    /** コード検索サービス. */
    @Autowired
    SearchWithCodeService searchWithCodeService;

    /**
     * コードによる名称検索を行う.
     * リクエストパラメータは以下の通り。
     * <ul>
     *  <li>searchKey: 検索キー</li>
     *  <li>methodName: 検索メソッド名称</li>
     * <ul>
     *
     * @param queryParameters リクエストパラメータ
     *
     * @return JSON
     * @throws URISyntaxException
     * @throws IOException
     * @throws SAXException
     * @throws ParserConfigurationException
     */
    @RequestMapping("/")
    public String searchWithCode(@RequestParam Map<String, String> queryParameters) throws ParserConfigurationException, SAXException, IOException, URISyntaxException {

        CODE_SEARCH_TYPE searchType = CODE_SEARCH_TYPE.getCodeSearchTypeByMethodName(queryParameters.get("methodName"));
        SearchWithCodeDto seachResult = searchWithCodeService.seachExecut(searchType, queryParameters);
        String json = JSON.encode(seachResult);

        return json;
    }
}
