package jp.co.alsok.g6.zzw.web;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.sql.Timestamp;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;

import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectMapper.DefaultTypeResolverBuilder;
import com.fasterxml.jackson.databind.ObjectMapper.DefaultTyping;
import com.fasterxml.jackson.databind.SerializationFeature;

/**
 * セッションオブジェクト制御部品実装
 *
 * @author SSC
 */
@Component("g6SessionControl")
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
public class G6SessionControlImpl implements G6SessionControl {
	/** 16進文字列のフォーマット */
	private static final String HEX_STRING_FORMAT = "%016x";

	/**
	 * ログ出力用
	 */
	@Autowired
	Logger logger;

	/**
	 * データベースアクセス用
	 */
	@Autowired
	@Qualifier("commondb")
	JdbcTemplate jdbcTemplate;

	/**
	 * タイムアウト(分)
	 */
	@Value("${server.servlet.session.timeout:30}")
	int timeout;

	/**
	 * JSON化、復元用
	 */
	static ObjectMapper objectMapper = new ObjectMapper().configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false)
			.setDefaultTyping(new DefaultTypeResolverBuilder(DefaultTyping.NON_FINAL).init(JsonTypeInfo.Id.CLASS, null)
					.inclusion(JsonTypeInfo.As.PROPERTY))
			.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);

	/**
	 * セッション破棄時処理
	 */
	Set<Consumer<String>> onTimeoutProcesses = new LinkedHashSet<>();

	/**
	 * タイムアウトセッションの破棄前回実行日時
	 */
	static ZonedDateTime cleanAt = ZonedDateTime.now();

	/**
	 * インジェクション専用のためインスタンス化不可
	 */
	protected G6SessionControlImpl() {
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * jp.co.alsok.g6.common.web.G6SessionControl#saveSession(jp.co.alsok.g6.common.
	 * web.G6Session)
	 */
	@Override
	@Transactional(rollbackFor = Exception.class)
	public void saveSession(@NotNull G6Session session) {
		try {
			// セッションオブジェクトをJSON化
			byte[] sessionData = objectMapper.writeValueAsBytes(session);
			// DBへ書き込み（存在すればUPDATE、しない場合はINSERT）
			jdbcTemplate.update(
					"INSERT INTO K_SESSION_INFO(SESSION_ID, SESSION_DATA, CREATE_DATE, LAST_ACCESS_DATE)"
							+ " VALUES(?, ?, NOW(), NOW())"
							+ " ON DUPLICATE KEY UPDATE SESSION_DATA = ?, LAST_ACCESS_DATE = NOW()",
					session.getSessionId(), sessionData, sessionData);
			logger.info("session saved: " + session.getSessionId());
		} catch (IOException e) {
			throw new UncheckedIOException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see jp.co.alsok.g6.common.web.G6SessionControl#loadSession(java.lang.String,
	 * boolean)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public <T extends G6Session> T loadSession(@NotNull @Size(max = 64) String sessionId, Supplier<T> create) {
		try {
			// DBからJSONデータを読み込み
			byte[] sessionData = jdbcTemplate.query("SELECT SESSION_DATA FROM K_SESSION_INFO WHERE SESSION_ID = ?",
					(ResultSetExtractor<byte[]>) rs -> rs.next() ? rs.getBytes("SESSION_DATA") : null, sessionId);
			// データが存在し無いときは新規作成
			if (sessionData == null) {
				if (create == null) {
					logger.info("session not found: " + sessionId);
					return null;
				}
				logger.info("session create: " + sessionId);
				return create.get();
			}
			// JSONからセッションオブジェクトへデシリアライズ
			T g6Session = (T) objectMapper.readValue(sessionData, G6Session.class);
			logger.info("session loaded: " + g6Session.getSessionId());
			return g6Session;
		} catch (IOException e) {
			throw new UncheckedIOException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see jp.co.alsok.g6.common.web.G6SessionControl#registerOnTimeout(java.util.
	 * function.Consumer)
	 */
	@Override
	public void registerOnTimeout(@NotNull Consumer<String> process) {
		// セッション破棄時処理を追加
		onTimeoutProcesses.add(process);
	}

	@Override
	public <T extends G6Session> void useSession(boolean save, @NotNull Consumer<T> consumer,
			Function<String, T> create) {
		// セッションID取得
		String sessionId = RequestContextHolder.currentRequestAttributes().getSessionId();
		// セッションオブジェクト取得
		T g6Session = loadSession(sessionId, create == null ? null : () -> create.apply(sessionId));
		// セッションが取得できない場合はエラー
		if (g6Session == null) {
			logger.info("session lost");
			throw new RuntimeException("session lost");
		}
		// セッション読み書き処理
		consumer.accept((T) g6Session);
		// セッションオブジェクト保存
		if (save) {
			saveSession(g6Session);
			clean();
		}
	}

	/**
	 * セッション破棄処理
	 */
	@Transactional(rollbackFor = Exception.class)
	@Override
	public void clean() {
		ZonedDateTime now = ZonedDateTime.now();
		// 1分以内に複数回呼ばれた場合は実行しない
		if (cleanAt.plusMinutes(1).isBefore(now)) {
			return;
		}
		cleanAt = now;
		List<String> sessionIdList = new ArrayList<>();
		jdbcTemplate.query("SELECT DISTINCT SESSION_ID FROM K_SESSION_INFO WHERE LAST_ACCESS_DATE < ?", rs -> {
			String sessionId = rs.getString("SESSION_ID");
			onTimeoutProcesses.forEach(i -> i.accept(sessionId));
			logger.info("session removed: " + sessionId);
			sessionIdList.add(sessionId);
		}, Timestamp.from(now.minusMinutes(timeout).toInstant()));
		jdbcTemplate
				.update("DELETE FROM K_SESSION_INFO WHERE SESSION_ID IN('" + String.join("', '", sessionIdList) + "')");
	}

	@Override
	public @NotNull String generateSessionId() {
		for (;;) {
			UUID[] uuid = { UUID.randomUUID(), UUID.randomUUID() };
			String sessionId = toHexString(uuid[0].getMostSignificantBits())
					+ toHexString(uuid[0].getLeastSignificantBits())
					+ toHexString(uuid[1].getMostSignificantBits())
					+ toHexString(uuid[1].getLeastSignificantBits());
			if (jdbcTemplate.query("SELECT 1 FROM K_SESSION_INFO WHERE SESSION_ID = ?",
					(ResultSetExtractor<Boolean>) rs -> rs.isBeforeFirst(), sessionId)) {
				continue;
			}
			return sessionId;
		}
	}

	/**
	 * long 型の引数の文字列表現を、基数 16 の0パディングありの16桁の整数として返す。
	 * @param value 文字列に変換する long値
	 * @return 16 進数 (基数 16) の引数で表される0パディングありの16桁のlong 値の文字列表現
	 */
	protected String toHexString(long value) {
		return String.format(HEX_STRING_FORMAT, value);
	}
}
