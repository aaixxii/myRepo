/**
 *
 */
package jp.co.alsok.g6.zzw.web.dto;


public class KeiyakusakiDto {
	/** 契約先名称 */
	private String keiyakusakiName = "";
	/** LN_契約先論理番号 */
	private String keiyakusakiId = "";

	/**
	* keiyakusakiName 取得
	* @return keiyakusakiName
	*/
	public String getKeiyakusakiName() {
		return keiyakusakiName;
	}
	/**
	* @param keiyakusakiName 設定 keiyakusakiName
	*/
	public void setKeiyakusakiName(String keiyakusakiName) {
		this.keiyakusakiName = keiyakusakiName;
	}
	/**
	* keiyakusakiId 取得
	* @return keiyakusakiId
	*/
	public String getKeiyakusakiId() {
		return keiyakusakiId;
	}
	/**
	* @param keiyakusakiId 設定 keiyakusakiId
	*/
	public void setKeiyakusakiId(String keiyakusakiId) {
		this.keiyakusakiId = keiyakusakiId;
	}


}
