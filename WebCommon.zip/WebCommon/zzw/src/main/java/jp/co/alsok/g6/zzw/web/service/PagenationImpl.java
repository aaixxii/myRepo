package jp.co.alsok.g6.zzw.web.service;

import java.util.List;

import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

@SuppressWarnings("rawtypes")
public class PagenationImpl<T> extends PageImpl {

	/** 開始ページ番号 */
	private int startPage;
	/** 終了ページ番号 */
	private int endPage;

	/**
	 * 初期化
	 * @param content
	 * @param pageable
	 * @param total
	 */
	@SuppressWarnings("unchecked")
	public PagenationImpl(List<T> content, Pageable pageable, long total) {
		super(content, pageable, total);
	}

	/**
	 * 開始ページ番号、取得
	 * @return
	 */
	public int getStartPage() {
		return startPage;
	}
	/**
	 * 開始ページ番号、設定
	 * @param startPage
	 */
	public void setStartPage(int startPage) {
		this.startPage = startPage;
	}


	/**
	 * 終了ページ番号、取得
	 * @return
	 */
	public int getEndPage() {
		return endPage;
	}
	/**
	 * 終了ページ番号、設定
	 * @param endPage
	 */
	public void setEndPage(int endPage) {
		this.endPage = endPage;
	}

}
