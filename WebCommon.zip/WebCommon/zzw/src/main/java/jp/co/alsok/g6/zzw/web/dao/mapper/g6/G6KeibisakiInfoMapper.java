package jp.co.alsok.g6.zzw.web.dao.mapper.g6;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import jp.co.alsok.g6.zzw.web.dto.KeibisakiInfoDto;

@Mapper
public interface G6KeibisakiInfoMapper {

	/**
     * LN_利用者アカウント共通論理番号を基に閲覧範囲内の警備先情報リストを取得する。
     *
     * @param param 抽出条件
     * @return 警備先情報リスト
     */
	List<KeibisakiInfoDto> selectG6KeibisakiInfo(Map<String, Object> param);

    /**
     * LN_利用者アカウント共通論理番号を基にログインユーザ情報を取得する。
     *
     * @param param 抽出条件
     * @return ログインユーザ情報
     */
	Map<String, Object> selectG6ACnt(Map<String, Object> param);
}
