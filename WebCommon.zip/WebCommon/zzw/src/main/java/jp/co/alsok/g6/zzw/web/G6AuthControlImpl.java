package jp.co.alsok.g6.zzw.web;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

/**
 * 利用者権限部品実装
 *
 * @author SSC
 */
@Component("g6AuthControl")
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
public class G6AuthControlImpl implements G6AuthControl {

	/**
	 * ログ出力用
	 */
	@Autowired
	Logger logger;

	/**
	 * データベースアクセス用
	 */
	@Autowired
	@Qualifier("g6db")
	JdbcTemplate jdbcTemplate;

	/**
	 * セッションオブジェクト制御用
	 */
	@Autowired
	G6SessionControl g6SessionControl;

	/**
	 * インジェクション専用のためインスタンス化不可
	 */
	protected G6AuthControlImpl() {
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see jp.co.alsok.g6.common.web.G6AuthControl#getUserRole(java.lang.String)
	 */
	@Override
	public @NotNull UserRole getUserRole(@NotNull @Size(max = 20) String lnUserRole, @NotNull @Size(max = 1) String disp_ptn) {
		final UserRole role = new UserRole();
		role.userAuthList = new ArrayList<>();
		// final Map<String, String> chiku = new HashMap<>();
		// final Map<String, List<String>> defined = new HashMap<>();
        jdbcTemplate.query("SELECT ur.LN_USER_ROLE"//
                + ", ur.USER_ROLE_NM"//
                + ", ur.PATH_INF"//
                + ", ura.LN_KB_CHIKU"//
                + ", ura.AUTH"//
                + ", uaa1.USER_ACNT_AUTH_NM AS AUTH_SERVICE"//
                + ", uaa2.LN_USER_ACNT_AUTH_ID"//
                + ", uaa2.USER_ACNT_AUTH_NM AS AUTH_VIEW"//
                + ", uaa2.MENUPASS_INF"//
                + ", d.DISP_ID"//
                + ", d.CHIKU_FLG"//
                + ", kc.SD_KOBETU_NM"//
                + " FROM M_DISP d"//
                + " INNER JOIN A_USER_ACNT_AUTH_MST uaa1 ON uaa1.MENUPASS_INF = LEFT(d.MENUPASS_INF, 2)"//
                + " INNER JOIN A_USER_ACNT_AUTH_MST uaa2 ON uaa2.MENUPASS_INF = d.MENUPASS_INF"//
                + " LEFT JOIN A_USER_ROLE_AUTH ura ON uaa2.LN_USER_ACNT_AUTH_ID = ura.LN_USER_ACNT_AUTH_ID AND ura.LN_USER_ROLE = ?"//
                + " LEFT JOIN A_USER_ROLE ur ON ura.LN_USER_ROLE = ur.LN_USER_ROLE AND ur.LN_USER_ROLE = ?"//
                + " LEFT JOIN R_KB_CHIKU kc ON kc.LN_KB_CHIKU = ura.LN_KB_CHIKU"//
                + " WHERE d.DISP_ID LIKE CONCAT(?, '%')"//
                + " ORDER BY uaa2.MENUPASS_INF, ura.LN_KB_CHIKU", rs -> {
                    role.lnUserRole = lnUserRole;
                    final String name = rs.getString("USER_ROLE_NM");
                    if (rs.getString("LN_USER_ROLE") != null) {
                        role.userRoleNm = name;
                        role.pathInf = rs.getString("PATH_INF");
                    }
                    final UserAuth auth = new UserAuth();
                    auth.lnKbChiku = rs.getString("LN_KB_CHIKU");
                    auth.auth = rs.getInt("AUTH");
                    auth.serviceNm = rs.getString("AUTH_SERVICE");
                    auth.lnUserAcntAuthId = rs.getString("LN_USER_ACNT_AUTH_ID");
                    auth.dispNm = rs.getString("AUTH_VIEW");
                    auth.menupassInf = Optional.ofNullable(rs.getString("MENUPASS_INF"))
                            .map(String::trim).orElse("");
                    auth.dispId = rs.getString("DISP_ID");
                    auth.chikuFlg = rs.getString("CHIKU_FLG");
                    auth.sdKobetuNm = rs.getString("SD_KOBETU_NM");
                    auth.authList = Arrays.asList(READ_ONLY, READ_WRITE, HIDDEN);
                    role.userAuthList.add(auth);
				}, lnUserRole, lnUserRole, disp_ptn);
		// defined.forEach((authId, chikuIds) -> {
		// chiku.forEach((chikuId, chikuName) -> {
		// if (!chikuIds.contains(chikuId)) {
		// UserAuth auth = new UserAuth();
		// role.userAuthList.stream().filter(i ->
		// authId.equals(i.lnUserAcntAuthId)).findFirst()
		// .ifPresent(i -> {
		// auth.serviceNm = i.serviceNm;
		// auth.lnUserAcntAuthId = i.lnUserAcntAuthId;
		// auth.dispId = i.dispId;
		// auth.dispNm = i.dispNm;
		// });
		// auth.lnKbChiku = chikuId;
		// auth.sdKobetuNm = chikuName;
		// auth.authList = Arrays.asList(READ_ONLY, READ_WRITE, HIDDEN);
		// auth.auth = 0;
		// role.userAuthList.add(auth);
		// }
		// });
		// });
		// Collections.sort(role.userAuthList,
		// Comparator.comparing(UserAuth::getMenupassInf,
		// Comparator.nullsFirst(Comparator.naturalOrder()))
		// .thenComparing(Comparator.comparing(UserAuth::getLnKbChiku,
		// Comparator.nullsFirst(Comparator.naturalOrder()))));
		return role;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * jp.co.alsok.g6.common.web.G6AuthControl#setUserRole(jp.co.alsok.g6.common.web
	 * .G6AuthControl.UserRole)
	 */
	@Override
//	@Transactional(rollbackFor = Exception.class)
	public void setUserRole(@NotNull UserRole userRole) {
		// 権限値のチェック
		userRole.userAuthList.forEach(i -> {
			if (!i.authList.contains(i.auth)) {
				throw new IllegalArgumentException("auth(" + i.auth + ") must in(" + i.authList + ")");
			}
		});

		// トランザクション開始
		PlatformTransactionManager transactionManager = getTransactionManager();
		TransactionDefinition definition = new DefaultTransactionDefinition();
		TransactionStatus status = transactionManager.getTransaction(definition);
		try {
			g6SessionControl.useSession(false, g6Session -> {
				final String id = g6Session.getSessionValue("LN_ACNT_USER_COMMON");
				final String nm = g6Session.getSessionValue("ACNT_NM");
				// 利用者ロールを登録／更新
				jdbcTemplate.update("INSERT INTO A_USER_ROLE(LN_USER_ROLE"//
						+ ", USER_ROLE_NM"//
						+ ", ACNT_USER_KBN"//
						+ ", CHG_FLG"//
						+ ", KOBETSU_FLG"//
						+ ", PATH_INF"//
						+ ", INSERT_ID"//
						+ ", INSERT_NM"//
						+ ", INSERT_TS"//
						+ ", UPDATE_ID"//
						+ ", UPDATE_NM"//
						+ ", UPDATE_TS)"//
						+ " VALUES(?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, ?, NOW())"//
						+ " ON DUPLICATE KEY UPDATE USER_ROLE_NM = ?"//
						+ ", UPDATE_ID = ?"//
						+ ", UPDATE_NM = ?"//
						+ ", UPDATE_TS = NOW()", //
						userRole.lnUserRole, //
						userRole.userRoleNm, //
						userRole.acntUserKbn, //
						"0", // 変更可能
						userRole.kobetsuFlg, //
						Optional.ofNullable(userRole.pathInf).orElse(""), //
						id, //
						nm, //
						id, //
						nm, //
						userRole.userRoleNm, //
						id, //
						nm);
				// 登録済み権限をすべて取得
				List<String[]> keys = jdbcTemplate.query("SELECT LN_KB_CHIKU"//
						+ ", LN_USER_ACNT_AUTH_ID"//
						+ " FROM A_USER_ROLE_AUTH"//
						+ " WHERE LN_USER_ROLE = ?",
						(rs, i) -> new String[] { userRole.lnUserRole, rs.getString("LN_KB_CHIKU"),
								rs.getString("LN_USER_ACNT_AUTH_ID") },
						userRole.lnUserRole);
				// 利用者ロール－権限連関を登録／更新
				userRole.userAuthList.forEach(userAuth -> {
					jdbcTemplate.update("INSERT INTO A_USER_ROLE_AUTH(LN_USER_ROLE"//
							+ ", LN_KB_CHIKU"//
							+ ", LN_USER_ACNT_AUTH_ID"//
							+ ", AUTH"//
							+ ", INSERT_ID"//
							+ ", INSERT_NM"//
							+ ", INSERT_TS"//
							+ ", UPDATE_ID"//
							+ ", UPDATE_NM"//
							+ ", UPDATE_TS)"//
							+ " VALUES(?, ?, ?, ?, ?, ?, NOW(), ?, ?, NOW())"//
							+ " ON DUPLICATE KEY UPDATE AUTH = ?"//
							+ ", UPDATE_ID = ?"//
							+ ", UPDATE_NM = ?"//
							+ ", UPDATE_TS = NOW()", //
							userRole.lnUserRole, //
							Optional.ofNullable(userAuth.lnKbChiku).orElse(""), //
							userAuth.lnUserAcntAuthId, //
							userAuth.auth, //
							id, //
							nm, //
							id, //
							nm, //
							userAuth.auth, //
							id, //
							nm);
					keys.stream().filter(i -> Objects.equals(i[0], userAuth.lnKbChiku)
							&& Objects.equals(i[1], userAuth.lnUserAcntAuthId)).findFirst().ifPresent(keys::remove);
				});
				// 不要分を削除
				keys.forEach(i -> jdbcTemplate.update("DELETE FROM A_USER_ROLE_AUTH"//
						+ " WHERE LN_USER_ROLE = ?"//
						+ " AND LN_KB_CHIKU = ?"//
						+ " AND LN_USER_ACNT_AUTH_ID = ?", userRole.lnUserRole, i[0], i[1]));
			}, id -> {
				G6Session session = new G6SessionImpl();
				session.putSessionValue("LN_ACNT_USER_COMMON", "unknown");
				session.putSessionValue("ACNT_NM", "unknown");
				return session;
			});
			transactionManager.commit(status);
		} finally {
			if (!status.isCompleted()) {
				transactionManager.rollback(status);
			}
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see jp.co.alsok.g6.common.web.G6AuthControl#getUserOperationHani(java.lang.
	 * String)
	 */
	@Override
	public @NotNull List<Keiyk> getUserOperationHani(@NotNull @Size(max = 20) String lnAcntUserCommon) {
		List<Keiyk> keiykList = new ArrayList<>();
		jdbcTemplate.query("SELECT CHIKU.PATH_INF AS PATH_INF"//
				        + " FROM R_KB_CHIKU CHIKU"//
        				+ " INNER JOIN A_USER_OPERATION_HANI HANI ON HANI.LN_ACNT_USER_COMMON = ?"//
		        		+ " AND ( HANI.PATH_INF = CHIKU.PATH_INF"//
        				+ " OR HANI.PATH_INF = LEFT(CHIKU.PATH_INF, 41)"//
        				+ " OR HANI.PATH_INF = LEFT(CHIKU.PATH_INF, 20))"//
        			    + " AND CHIKU.DEL_FLG = '0'"//
            			+ " GROUP BY PATH_INF"//
				        + " ORDER BY PATH_INF", rs -> {
					String[] trio = rs.getString("PATH_INF").split("/");
					final String lnKeiyk = trio[0];
					Keiyk keiyk = keiykList.stream().filter(i -> Objects.equals(lnKeiyk, i.lnKeiyk)).findFirst()
							.orElseGet(() -> {
								Keiyk k = new Keiyk();
								k.lnKeiyk = lnKeiyk;
								k.keibiList = new ArrayList<>();
								keiykList.add(k);
								return k;
							});
					final String lnKeibi = trio[1];
					Keibi keibi = keiyk.keibiList.stream().filter(i -> Objects.equals(lnKeibi, i.lnKeibi)).findFirst()
							.orElseGet(() -> {
								Keibi k = new Keibi();
								k.lnKeibi = lnKeibi;
								k.chikuList = new ArrayList<>();
								keiyk.keibiList.add(k);
								return k;
							});
					final String lnKbChiku = trio[2];
					if (keibi.chikuList.stream().noneMatch(i -> Objects.equals(lnKbChiku, i))) {
						keibi.chikuList.add(lnKbChiku);
					}
				}, lnAcntUserCommon);
		return keiykList;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * jp.co.alsok.g6.common.web.G6AuthControl#getUserMenuList(java.lang.String,
	 * java.lang.String)
	 */
	@Override
	public @NotNull List<Menu> getUserMenuList(@NotNull @Size(max = 20) String lnAcntUserCommon,
			@NotNull @Size(max = 20) String lnKeibi) {
		List<Menu> menuList = new ArrayList<>();
		jdbcTemplate.query("SELECT d.DISP_ID, d.DISP_NM, d.MENUPASS_INF, MAX(ura.AUTH) AUTH"//
				+ " FROM M_DISP d"//
				+ " INNER JOIN A_USER_ACNT_AUTH_MST uaa ON uaa.MENUPASS_INF = d.MENUPASS_INF"//
				+ " INNER JOIN A_USER_ROLE_AUTH ura ON ura.LN_USER_ACNT_AUTH_ID = uaa.LN_USER_ACNT_AUTH_ID"//
				+ " INNER JOIN A_USER_ROLE ur ON ur.LN_USER_ROLE = ura.LN_USER_ROLE"//
				+ " INNER JOIN A_ACNT_USER_ROLE aur ON aur.LN_USER_ROLE = ur.LN_USER_ROLE"//
				+ " WHERE aur.LN_ACNT_USER_COMMON = ?"//
				+ " AND ura.AUTH <> ?"
				+ " AND aur.PATH_INF LIKE CONCAT('____________________/', ?, '/____________________')"//
				+ " GROUP BY d.DISP_ID, d.DISP_NM, d.MENUPASS_INF"
				+ " ORDER BY MENUPASS_INF", rs -> {
					Menu menu = new Menu();
					menu.dispId = rs.getString("DISP_ID");
					menu.dispNm = rs.getString("DISP_NM");
					menu.menupassInf = rs.getString("MENUPASS_INF");
					menu.auth = rs.getInt("AUTH");
					menuList.add(menu);
				}, HIDDEN, lnAcntUserCommon, lnKeibi);
		return menuList;
	}

    /*
     * (non-Javadoc)
     *
     * @see jp.co.alsok.g6.common.web.G6AuthControl#getAuth(java.lang.String,
     * java.lang.String, java.lang.String)
     */
    @Override
    public int getAuth(@NotNull @Size(max = 20) String lnAcntUserCommon,
            @NotNull @Size(max = 20) String lnKeiyk, @NotNull @Size(max = 20) String lnKeibi,
            @Size(max = 20) String lnKbChiku, @NotNull @Size(max = 5) String dispId) {
        return jdbcTemplate.query("SELECT ura.AUTH"//
                + " FROM A_USER_OPERATION_HANI auoh "//
                + " INNER JOIN A_ACNT_USER_ROLE aur ON auoh.LN_ACNT_USER_COMMON = ? "//
                + " AND auoh.LN_ACNT_USER_COMMON = aur.LN_ACNT_USER_COMMON "//
                + " INNER JOIN A_USER_ROLE ur ON aur.LN_USER_ROLE = ur.LN_USER_ROLE "//
                + " INNER JOIN A_USER_ROLE_AUTH ura ON ur.LN_USER_ROLE = ura.LN_USER_ROLE "//
                + " INNER JOIN A_USER_ACNT_AUTH_MST uaa ON ura.LN_USER_ACNT_AUTH_ID = uaa.LN_USER_ACNT_AUTH_ID "//
                + " INNER JOIN M_DISP d ON d.DISP_ID = ? "//
                + " AND uaa.MENUPASS_INF = LEFT(d.MENUPASS_INF, 4)"//
                + " WHERE ( IFNULL(?, '') <> '' "//
                + " AND ( auoh.PATH_INF = ? "//
                + " OR auoh.PATH_INF = CONCAT(?, '/', ?) "//
                + " OR (auoh.PATH_INF = CONCAT(?, '/', ?, '/', ?) AND ( IFNULL(ura.LN_KB_CHIKU, '') = '' OR ura.LN_KB_CHIKU = ?)))) "//
                + " OR ( IFNULL(?, '') = '' "//
                + " AND ( auoh.PATH_INF = ? "//
                + " OR auoh.PATH_INF LIKE CONCAT(?, '/', ?, '%'))) "//
                + " ORDER BY ura.AUTH DESC LIMIT 1", rs -> rs.next() ? rs.getInt("AUTH") : 0,
                lnAcntUserCommon, dispId, lnKbChiku, lnKeiyk, lnKeiyk, lnKeibi, lnKeiyk, lnKeibi, lnKbChiku, lnKbChiku, lnKbChiku, lnKeiyk, lnKeiyk, lnKeibi);
    }

	/*
	 * (non-Javadoc)
	 *
	 * @see jp.co.alsok.g6.common.web.G6AuthControl#getRoles(java.lang.String)
	 */
	@Override
	public @NotNull Map<String, String> getRoles(@NotNull @Size(max = 20) String lnAcntUserCommon) {
		Map<String, String> map = new LinkedHashMap<>();
		jdbcTemplate.query("SELECT ur.LN_USER_ROLE, ur.USER_ROLE_NM"//
				+ " FROM A_ACNT_USER_ROLE aur"//
				+ " INNER JOIN A_USER_ROLE ur ON ur.LN_USER_ROLE = aur.LN_USER_ROLE"
				+ " WHERE aur.LN_ACNT_USER_COMMON = ?", //
				(rs, i) -> map.put(rs.getString("LN_USER_ROLE"), rs.getString("USER_ROLE_NM")), //
				lnAcntUserCommon);
		return map;
	}


    /*
     * (non-Javadoc)
     *
     * @see
     * jp.co.alsok.g6.common.web.G6AuthControl#getAcntUserKbnInf(java.lang.String,
     * java.lang.String)
     */
    @Override
    public YukoAcntUserInf getYukoAcntUserKbnInf(@NotNull @Size(max = 5) String dispId) {
        YukoAcntUserInf resultInf = new YukoAcntUserInf();
        jdbcTemplate.query("SELECT MENUPASS_INF, CHIKU_FLG, YUKO_ACNT_USER_KBN"//
                + " FROM M_DISP"//
                + " WHERE DISP_ID = ?", rs -> {
                    resultInf.menupassInf = rs.getString("MENUPASS_INF");
                    resultInf.chikuFlg = rs.getString("CHIKU_FLG");
                    resultInf.yukoAdntUserKbn = rs.getString("YUKO_ACNT_USER_KBN");
                }, dispId);
        return resultInf;
    }

    /*
     * (non-Javadoc)
     *
     * @see
     * jp.co.alsok.g6.common.web.G6AuthControl#getAcntUserKbn(java.lang.String,
     * java.lang.String)
     */
    @Override
    public String getAcntUserKbn(@NotNull @Size(max = 20) String lnAcntUserCommon) {
        StringBuffer result = new StringBuffer();
        jdbcTemplate.query("SELECT ACNT_USER_KBN"//
                + " FROM commondb.K_ACNT_USER_COMMON"//
                + " WHERE LN_ACNT_USER_COMMON = ?", rs -> {
                    result.append(rs.getString("ACNT_USER_KBN"));
                }, lnAcntUserCommon);
        return result.toString();
    }

	/**
	 * PlatformTransactionManagerインスタンスを取得する。
	 *
	 * @return PlatformTransactionManagerインスタンス
	 */
	private PlatformTransactionManager getTransactionManager() {
		DataSourceTransactionManager transactionManager = new DataSourceTransactionManager(jdbcTemplate.getDataSource());
		transactionManager.setRollbackOnCommitFailure(true);
		return transactionManager;
	}
}
