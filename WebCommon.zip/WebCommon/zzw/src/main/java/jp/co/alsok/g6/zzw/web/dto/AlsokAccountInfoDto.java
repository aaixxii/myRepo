package jp.co.alsok.g6.zzw.web.dto;

/**
 * 次期(G6)、GHS、GVのALSOKアカウント論理番号を格納したDtoクラス
 *
 * @author SNG-105
 */
public class AlsokAccountInfoDto extends AbstractAccountInfoDto {

    /** G6Alsokアカウント論理番号 */
    private String g6LnAcntAlsokNo;

    /** G6Alsokアカウント名 */
    private String g6LnAcntAlsokName;

    /** G5Alsokアカウント論理番号 */
    private String g5LnAcntAlsokNo;

    /** G5Alsokアカウント名 */
    private String g5LnAcntAlsokName;

    /** GhsAlsokアカウント論理番号 */
    private String ghsLnAcntAlsokNo;

    /** GhsAlsokアカウント名 */
    private String ghsLnAcntAlsokName;

    /** G6 社員番号*/
    private String g6UserNum;

    /** G5 社員番号*/
    private String g5UserNum;

    /** GHS 社員番号*/
    private String ghsUserNum;

    /** G6 事業コード*/
    private String g6JigyouCd;

    /** G5 事業コード*/
    private String g5JigyouCd;

    /** GHS 事業コード*/
    private String ghsJigyouCd;

    /**
    * g6LnAcntAlsokNo 取得
    * @return g6LnAcntAlsokNo
    */
    public String getG6LnAcntAlsokNo() {
        return g6LnAcntAlsokNo;
    }
    /**
    * @param g6LnAcntAlsokNo 設定 g6LnAcntAlsokNo
    */
    public void setG6LnAcntAlsokNo(String g6LnAcntAlsokNo) {
        this.g6LnAcntAlsokNo = g6LnAcntAlsokNo;
    }
    /**
    * g6LnAcntAlsokName 取得
    * @return g6LnAcntAlsokName
    */
    public String getG6LnAcntAlsokName() {
        return g6LnAcntAlsokName;
    }
    /**
    * @param g6LnAcntAlsokName 設定 g6LnAcntAlsokName
    */
    public void setG6LnAcntAlsokName(String g6LnAcntAlsokName) {
        this.g6LnAcntAlsokName = g6LnAcntAlsokName;
    }
    /**
    * g5LnAcntAlsokNo 取得
    * @return g5LnAcntAlsokNo
    */
    public String getG5LnAcntAlsokNo() {
        return g5LnAcntAlsokNo;
    }
    /**
    * @param g5LnAcntAlsokNo 設定 g5LnAcntAlsokNo
    */
    public void setG5LnAcntAlsokNo(String g5LnAcntAlsokNo) {
        this.g5LnAcntAlsokNo = g5LnAcntAlsokNo;
    }
    /**
    * g5LnAcntAlsokName 取得
    * @return g5LnAcntAlsokName
    */
    public String getG5LnAcntAlsokName() {
        return g5LnAcntAlsokName;
    }
    /**
    * @param g5LnAcntAlsokName 設定 g5LnAcntAlsokName
    */
    public void setG5LnAcntAlsokName(String g5LnAcntAlsokName) {
        this.g5LnAcntAlsokName = g5LnAcntAlsokName;
    }
    /**
    * ghsLnAcntAlsokNo 取得
    * @return ghsLnAcntAlsokNo
    */
    public String getGhsLnAcntAlsokNo() {
        return ghsLnAcntAlsokNo;
    }
    /**
    * @param ghsLnAcntAlsokNo 設定 ghsLnAcntAlsokNo
    */
    public void setGhsLnAcntAlsokNo(String ghsLnAcntAlsokNo) {
        this.ghsLnAcntAlsokNo = ghsLnAcntAlsokNo;
    }
    /**
    * ghsLnAcntAlsokName 取得
    * @return ghsLnAcntAlsokName
    */
    public String getGhsLnAcntAlsokName() {
        return ghsLnAcntAlsokName;
    }
    /**
    * @param ghsLnAcntAlsokName 設定 ghsLnAcntAlsokName
    */
    public void setGhsLnAcntAlsokName(String ghsLnAcntAlsokName) {
        this.ghsLnAcntAlsokName = ghsLnAcntAlsokName;
    }
    /**
    * g6UserNum 取得
    * @return g6UserNum
    */
    public String getG6UserNum() {
        return g6UserNum;
    }
    /**
    * @param g6UserNum 設定 g6UserNum
    */
    public void setG6UserNum(String g6UserNum) {
        this.g6UserNum = g6UserNum;
    }
    /**
    * g5UserNum 取得
    * @return g5UserNum
    */
    public String getG5UserNum() {
        return g5UserNum;
    }
    /**
    * @param g5UserNum 設定 g5UserNum
    */
    public void setG5UserNum(String g5UserNum) {
        this.g5UserNum = g5UserNum;
    }
    /**
    * ghsUserNum 取得
    * @return ghsUserNum
    */
    public String getGhsUserNum() {
        return ghsUserNum;
    }
    /**
    * @param ghsUserNum 設定 ghsUserNum
    */
    public void setGhsUserNum(String ghsUserNum) {
        this.ghsUserNum = ghsUserNum;
    }
    /**
    * g6JigyouCd 取得
    * @return g6JigyouCd
    */
    public String getG6JigyouCd() {
        return g6JigyouCd;
    }
    /**
    * @param g6JigyouCd 設定 g6JigyouCd
    */
    public void setG6JigyouCd(String g6JigyouCd) {
        this.g6JigyouCd = g6JigyouCd;
    }
    /**
    * g5JigyouCd 取得
    * @return g5JigyouCd
    */
    public String getG5JigyouCd() {
        return g5JigyouCd;
    }
    /**
    * @param g5JigyouCd 設定 g5JigyouCd
    */
    public void setG5JigyouCd(String g5JigyouCd) {
        this.g5JigyouCd = g5JigyouCd;
    }
    /**
    * ghsJigyouCd 取得
    * @return ghsJigyouCd
    */
    public String getGhsJigyouCd() {
        return ghsJigyouCd;
    }
    /**
    * @param ghsJigyouCd 設定 ghsJigyouCd
    */
    public void setGhsJigyouCd(String ghsJigyouCd) {
        this.ghsJigyouCd = ghsJigyouCd;
    }
}
