package jp.co.alsok.g6.zzw.web.dto;

public abstract class AbstractAccountInfoDto {

}
