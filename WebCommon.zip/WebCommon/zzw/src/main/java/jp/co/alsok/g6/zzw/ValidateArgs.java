package jp.co.alsok.g6.zzw;

import java.lang.annotation.Annotation;
import java.lang.reflect.Executable;
import java.util.stream.Stream;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * メソッドまたはコンストラクタ引数の検証
 * 
 * @author SSC
 */
public class ValidateArgs {
	/**
	 * 対象メソッド
	 */
	public final Executable target;

	/**
	 * コンストラクタ
	 * 
	 * @param method
	 *            対象メソッドまたはコンストラクタ
	 */
	public ValidateArgs(Executable method) {
		this.target = method;
	}

	/**
	 * コンストラクタ
	 * 
	 * @param clazz
	 *            対象クラス
	 * @param methodName
	 *            対象メソッド名
	 * @param parameterTypes
	 *            引数の型
	 */
	public ValidateArgs(Class<?> clazz, String methodName, Class<?>... parameterTypes) {
		try {
			target = clazz.getMethod(methodName, parameterTypes);
		} catch (NoSuchMethodException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * コンストラクタ
	 * 
	 * @param clazz
	 *            対象クラス
	 * @param parameterTypes
	 *            コンストラクタの引数の型
	 */
	public ValidateArgs(Class<?> clazz, Class<?>... parameterTypes) {
		try {
			target = clazz.getConstructor(parameterTypes);
		} catch (NoSuchMethodException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * 引数の検証
	 * 
	 * @param args
	 *            実引数
	 */
	public void validate(Object... args) {
		final Annotation[][] annotations = target.getParameterAnnotations();
		for (int i = 0; i < args.length; i++) {
			final String name = target.getName() + " " + (i + 1) + "th parameter";
			final Object value = args[i];

			// 必須チェック
			Stream.of(annotations[i]).filter(a -> a instanceof NotNull).findFirst().map(NotNull.class::cast)
					.ifPresent(a -> {
						if (value == null) {
							throw new IllegalArgumentException(name + " must not be null");
						}
					});
			if (value != null) {

				// 桁数チェック
				Stream.of(annotations[i]).filter(a -> a instanceof Size).findFirst().map(Size.class::cast)
						.ifPresent(a -> {
							int length = String.valueOf(value).length();
							if (length < a.min() || a.max() < length) {
								throw new IllegalArgumentException(
										name + " size(" + length + ") must between " + a.min() + " and " + a.max());
							}
						});
			}
		}
	}
}