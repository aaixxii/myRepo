package jp.co.alsok.g6.zzw.web.constants;

/**
 * 共通 DBアクセス用 定数クラス
 *
 * @author kadena.t
 */
public class EntityType {

    /** DBアクセスフラグ */
    public static enum TYPE {

        G6(1), GHS(2), G5(3);

        /** DBアクセスフラグ */
        private int type;

        /**
         * コンストラクタ
         */
        private TYPE(int type) {
            this.type = type;
        }

        /**
         * Entityタイプを返却します。
         *
         * @return
         */
        public int getValue() {
            return this.type;
        }

        public TYPE getType() {

        	if (type == G6.type) {
        		return G6;
        	} else if (type == G5.type) {
        		return G5;
        	} else {
        		return GHS;
        	}
        }
    }
}
