/**
 * 
 */
package jp.co.alsok.g6.zzw.web;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.validation.constraints.NotNull;

import jp.co.alsok.g6.zzw.ValidateArgs;

/**
 * セッション共通部品実装
 * 
 * @author SSC
 */
public class G6SessionImpl implements G6Session {

	/**
	 * セッションID
	 */
	String sessionId;

	/**
	 * ユーザID
	 */
	String userId;

	/**
	 * セッション生成日時
	 */
	Date createDate;

	/* (non-Javadoc)
	 * @see jp.co.alsok.g6.common.web.G6Session#getSessionId()
	 */
	@Override
	public String getSessionId() {
		return sessionId;
	}

	/* (non-Javadoc)
	 * @see jp.co.alsok.g6.common.web.G6Session#getUserId()
	 */
	@Override
	public String getUserId() {
		return userId;
	}

	/* (non-Javadoc)
	 * @see jp.co.alsok.g6.common.web.G6Session#getCreateDate()
	 */
	@Override
	public Date getCreateDate() {
		return createDate;
	}

	/**
	 * コンストラクタ
	 * 
	 * @param sessionId
	 *            セッションID
	 */
	public G6SessionImpl(@NotNull String sessionId, @NotNull String userId, @NotNull Date createDate) {
		new ValidateArgs(G6SessionImpl.class, String.class, String.class, Date.class).validate(sessionId, userId,
				createDate);
		this.sessionId = sessionId;
		this.userId = userId;
		this.createDate = createDate;
	}

	/**
	 * JSONデシリアライズ用
	 */
	protected G6SessionImpl() {
	}
	
	/**
	 * セッション情報格納先
	 */
	protected final Map<String, Object> map = new HashMap<>();

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.alsok.g6.common.web.G6Session#putSessionValue(java.lang.String,
	 * java.lang.Object)
	 */
	@Override
	public void putSessionValue(@NotNull String key, Object value) {
		new ValidateArgs(G6Session.class, "putSessionValue", String.class, Object.class).validate(key, value);
		map.put(key, value);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.alsok.g6.common.web.G6Session#getSessionValue(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public <T> T getSessionValue(@NotNull String key) {
		new ValidateArgs(G6Session.class, "getSessionValue", String.class).validate(key);
		return (T) map.get(key);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.alsok.g6.common.web.G6Session#removeSession(java.lang.String)
	 */
	@Override
	public void removeSession(@NotNull String key) {
		new ValidateArgs(G6Session.class, "removeSession", String.class).validate(key);
		map.remove(key);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see jp.co.alsok.g6.common.web.G6Session#removeAllSession()
	 */
	@Override
	public void removeAllSession() {
		map.clear();
	}
	
	@Override
	public String toString() {
		return "[" + sessionId + "]" + map.toString();
	}

	@Override
	public @NotNull Set<String> keySet() {
		return map.keySet();
	}
}
