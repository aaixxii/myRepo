package jp.co.alsok.g6.zzw.web.constants;

/**
 * 操作履歴登録 操作内容コード
 */
public class OperationNaiyouCdConstants {

    /** 操作内容コード '00'ログイン */
    public static final String LOGIN_00 = "00";
    /** 操作内容コード '01'パスワード再登録 */
    public static final String RE_PASSWORD_01 = "01";
    /** 操作内容コード '02'ログアウト */
    public static final String LOGOUT_02 = "02";
    /** 操作内容コード '03'アカウント情報削除*/
    public static final String DELETE_ACCOUNT_03 = "03";
    /** 操作内容コード '04'アカウント情報メール再通知 */
    public static final String RE_ACCOUNT_INFO_MAIL = "04";
    /** 操作内容コード '05'アカウント情報登録 */
    public static final String REGISTER_ACCOUNT_INFO = "05";
    /** 操作内容コード '06'メイン管理者アカウント情報削除*/
    public static final String DELETE_ADMIN_ACCOUNT_INFO = "05";
    /** 操作内容コード '07'メイン管理者アカウント情報メール再通知*/
    public static final String RE_ADMIN_ACCOUNT_INFO_MAIL = "07";
    /** 操作内容コード '08'メイン管理者アカウント情報設定 */
    public static final String SET_ADMIN_ACCOUNT_INFO = "08";
    /** 操作内容コード '09'メール配信設定*/
    public static final String SET_MAIL_DELIVERS = "09";
    /** 操作内容コード '0A'外出ALSOK警備開始*/
    public static final String OUTGO_ALSOK_SECURITY_START = "0A";
    /** 操作内容コード '0B'外出ALSOK警備解除 */
    public static final String OUTGO_ALSOK_SECURITY_CANCEL = "0B";
    /** 操作内容コード '0C'在宅ALSOK警備解除 */
    public static final String HOME_ALSOK_SECURITY_CANCEL = "0C";
    /** 操作内容コード '0D','警備解除'*/
    public static final String SECURITY_CANCEL = "0D";
    /** 操作内容コード '0E','警備開始'*/
    public static final String SECURITY_START = "0E";
    /** 操作内容コード '0F','在宅ALSOK警備開始'*/
    public static final String HOME_ALSOK_SECURITY_START = "0F";
    /** 操作内容コード '10'遠隔設備操作状態読出し */
    public static final String REMOTE_FACILITY_OPERATION_READ_STATE = "10";
    /** 操作内容コード '11'遠隔設備操作ON設定*/
    public static final String REMOTE_FACILITY_OPERATION_ON = "11";
    /** 操作内容コード '12','遠隔設備操作OFF設定'*/
    public static final String REMOTE_FACILITY_OPERATION_OFF = "12";
    /** 操作内容コード '13'パスワード変更 */
    public static final String CHANGE_PASSWORD_13 = "13";
    /** 操作内容コード '14'ログインユーザー情報変更 */
    public static final String CHANGE_LOGIN_USER_INFO_14 = "14";
    /** 操作内容コード '15'緊急時のご連絡先情報登録*/
    public static final String REGISTER_CONTACT_INFO_ON_EMERGENCY_15 = "15";
    /** 操作内容コード '16'同居家族情報登録*/
    public static final String REGISTER_LIVING_FAMILY_INFO_16 = "16";
    /** 操作内容コード '17'救急情報登録 */
    public static final String REGISTER_EMERGENCY_INFO_17 = "17";
    /** 操作内容コード '18','警備セット忘れ通知設定'*/
    public static final String  SECURITY_SET_FORGET_NOTIFICATION = "18";
    /** 操作内容コード '19','警備セット忘れ通知設定削除'*/
    public static final String  DELETE_SECURITY_SET_FORGET_NOTIFICATION= "19";
    /** 操作内容コード '1A','空室メール設定'*/
    public static final String  SET_VACANCY_MAIL = "1A";
    /** 操作内容コード '1B','空室メール設定削除'*/
    public static final String  DELETE_VACANCY_MAIL = "1B";
    /** 操作内容コード '1C','カード情報設定読出し'*/
    public static final String  SET_CARD_INFO_READOUT = "1C";
    /** 操作内容コード '1D','カード情報設定'*/
    public static final String  SET_CARD_INFO = "1D";
    /** 操作内容コード '50','ログイン'*/
    public static final String  LOGIN_50= "50";
    /** 操作内容コード '51','パスワード再登録（秘密の質問回答）'*/
    public static final String  RE_PASSWORD_SECRET_QUESTION_ANSWER = "51";
    /** 操作内容コード '53'パスワード再登録'*/
    public static final String  RE_PASSWORD_53 = "53";
    /** 操作内容コード '54'ログアウト'*/
    public static final String  LOGOUT_54 = "54";
    /** 操作内容コード '55'見守り配信設定'*/
    public static final String  SET_WATCHING_OVERDELIVERY = "55";
    /** 操作内容コード '56'見守り配信設定情報読出し'*/
    public static final String  SET_READING_WATCHING_GUARD_DELIVERY_INFO = "56";
    /** 操作内容コード '57'見守りアカウント情報削除'*/
    public static final String  DELETE_READING_WATCHING_GUARD_DELIVERY_INFO= "57";
    /** 操作内容コード '58'見守りアカウント情報登録'*/
    public static final String  REGISTER_READING_WATCHING_GUARD_DELIVERY_INFO = "58";
    /** 操作内容コード '59'パスワード変更'*/
    public static final String  CHANGE_PASSWORD_59 = "59";
    /** 操作内容コード '5A'ログインユーザー情報変更'*/
    public static final String  CHANGE_LOGIN_USER_INFO_5A= "5A";
    /** 操作内容コード '5B'見守りアカウント情報メール再通知'*/
    public static final String  RE_READING_WATCHING_GUARD_DELIVERY_INFO= "5B";
    /** 操作内容コード '80'ログイン'*/
    public static final String  LOGIN_80 = "80";
    /** 操作内容コード '81'ログアウト'*/
    public static final String  LOGOUT_81 = "81";
    /** 操作内容コード '82'新着一覧情報削除'*/
    public static final String  DELETE_NEW_ARRIVAL_INFO = "82";
    /** 操作内容コード '83'契約先登録'*/
    public static final String  SUBSCRIBER_REGISTRATION = "83";
    /** 操作内容コード '84'契約先情報削除'*/
    public static final String  DELETE_CONTRACT_INFO= "84";
    /** 操作内容コード '85'代表メイン管理者アカウント削除'*/
    public static final String  DELETE_MAIN_DELEGATE_ADMIN_ACCOUNT = "85";
    /** 操作内容コード '86'代表メイン管理者アカウント更新'*/
    public static final String  UPDATE_MAIN_DELEGATE_ADMIN_ACCOUNT = "86";
    /** 操作内容コード '87'警備先情報削除'*/
    public static final String  DELETE_SECURITY_INFO = "87";
    /** 操作内容コード '88'警備先情報登録'*/
    public static final String  SECURITY_INFOR_REGISTRATION = "88";
    /** 操作内容コード '89'緊急時のご連絡先情報登録'*/
    public static final String  REGISTER_CONTACT_INFO_ON_EMERGENCY_89 = "89";
    /** 操作内容コード '8A'同居家族情報登録'*/
    public static final String  REGISTER_LIVING_FAMILY_INFO_8A = "8A";
    /** 操作内容コード '8B'救急情報登録'*/
    public static final String  REGISTER_EMERGENCY_INFO_8B = "8B";
    /** 操作内容コード '8C'警備先メインユーザー削除'*/
    public static final String  SECURITY_MAIN_USER = "8C";
    /** 操作内容コード '8D'見守りメインユーザー削除'*/
    public static final String  DELETE_WATCHING_OVER_MAIN_USER = "8D";
    /** 操作内容コード '8E'メインユーザーアカウント更新'*/
    public static final String  UPDATE_MAIN_USER_ACCOUNT = "8E";
    /** 操作内容コード '8F'作動試験結果読出し'*/
    public static final String  READ_OPERATION_RESULT_TEST = "8F";
    /** 操作内容コード '90'シャント状態読出し'*/
    public static final String  SHUNT_STATE_READOUT = "90";
    /** 操作内容コード '91'シャント状態設定'*/
    public static final String  SET_SHUNT_STATE = "91";
    /** 操作内容コード '92'履歴情報読出し'*/
    public static final String  READ_HISTORY_INFO = "92";
    /** 操作内容コード '93'装置リセット'*/
    public static final String  DEVICE_RESET = "93";
    /** 操作内容コード '94'通信テスト'*/
    public static final String  COMMUNICATION_TEST = "94";
    /** 操作内容コード '95'バッテリー劣化確認'*/
    public static final String CHECK_BATTERY_DEGRADATION = "95";
    /** 操作内容コード '96'ダイレクト制御状態読出し'*/
    public static final String  DIRECT_CONTROL_STATE_READOUT = "96";
    /** 操作内容コード '97'ダイレクト制御ON設定'*/
    public static final String  DIRECT_CONTROL_STATE_ON = "97";
    /** 操作内容コード '98'ダイレクト制御OFF設定'*/
    public static final String  DIRECT_CONTROL_STATE_OFF = "98";
    /** 操作内容コード '99'制御保持設定状態読出し'*/
    public static final String  READ_CONTROL_HOLD_SETTING_STATUS = "99";
    /** 操作内容コード '9A'制御保持設定'*/
    public static final String  SET_CONTROL_HOLD = "9A";
    /** 操作内容コード '9B'警備状態読出し'*/
    public static final String  READ_SECURITY_STATUS = "9B";
    /** 操作内容コード '9C'N0設定'*/
    public static final String  SET_NO = "9C";
    /** 操作内容コード '9D'KN設定／KF設定'*/
    public static final String  SET_KN_AND_SET_KF= "9D";
    /** 操作内容コード '9E'アカウント削除'*/
    public static final String  DELETE_ACCOUNT_9E = "9E";
    /** 操作内容コード '9F'アカウント編集'*/
    public static final String  EDIT_ACCOUNT = "9F";
    /** 操作内容コード 'A0'お知らせ内容登録'*/
    public static final String  NOTIFICATION_CONTENT_REGISTRATION = "A0";
    /** 操作内容コード 'A1'お知らせメール送信取消'*/
    public static final String  CANCEL_SENDING_NOTIFICATION_MAIL = "A1";
    /** 操作内容コード 'A2'メールアドレス変更'*/
    public static final String  CHANGE_E_MAIL_ADDRESS = "A2";
    /** 操作内容コード 'A3'パスワード変更'*/
    public static final String  CHANGE_PASSWORD_A3 = "A3";
    /** 操作内容コード 'A4'遠隔点検予約'*/
    public static final String  REMOTE_CHECK_RESERVATION = "A4";
    /** 操作内容コード 'A5'遠隔点検'*/
    public static final String  REMOTE_CHECK = "A5";
    /** 操作内容コード 'A6'メイン／サブ／利用者アカウント削除'*/
    public static final String  DELETE_USER_ACCOUNT_MAIN_AND_SUB = "A6";
    /** 操作内容コード 'A7'警備先サブユーザー削除'*/
    public static final String  DELETE_SECURITY_SUB_USER = "A7";
    /** 操作内容コード 'A8'見守りサブユーザー削除'*/
    public static final String  DELETE_WATCHING_OVER_SUB_USER = "A8";
    /** 操作内容コード 'A9'警備先情報登録（住戸一括）'*/
    public static final String  SECURITY_INFOR_REGISTRATION_LUMP_SUM = "A9";
    /** 操作内容コード 'AA'{0}削除'*/
    public static final String  DELETE = "AA";
    /** 操作内容コード 'AB'{0}一括登録'*/
    public static final String  BULK_REGISTRATION = "AB";
    /** 操作内容コード 'AC'{0}一括削除'*/
    public static final String  DELETE_ALL = "AC";
    /** 操作内容コード 'AD'{0}CSV取込'*/
    public static final String  CSV_IMPORT = "AD";
    /** 操作内容コード 'AE'{0}登録'*/
    public static final String  INSERT = "登録";
    /** 操作内容コード 'D0'ログイン (ｺﾝﾄﾛｰﾗ製造番号登録ｻｲﾄ)'*/
    public static final String  LOGIN_D0 = "D0";
    /** 操作内容コード 'D1'ログアウト (ｺﾝﾄﾛｰﾗ製造番号登録ｻｲﾄ)'*/
    public static final String  LOGOUT_D1 = "D1";
    /** 操作内容コード 'D2'警備先情報登録 (ｺﾝﾄﾛｰﾗ製造番号登録ｻｲﾄ)'*/
    public static final String  SECURITY_INFOR_REGISTRATION_LA_PRODUCTION_NUMBER = "D2";
    /** 操作内容コード 'D3'パスワード変更 (ｺﾝﾄﾛｰﾗ製造番号登録ｻｲﾄ)*/
    public static final String  CHANGE_PASSWORD_D3 = "D3";
}
