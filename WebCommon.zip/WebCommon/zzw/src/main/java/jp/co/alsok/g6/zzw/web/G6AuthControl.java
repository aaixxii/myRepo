package jp.co.alsok.g6.zzw.web;

import java.util.List;
import java.util.Map;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * 利用者権限制御部品インターフェイス
 * @author SSC
 */
public interface G6AuthControl {
	
	/**
	 * 閲覧のみ
	 */
	static final int READ_ONLY = 1;
	
	/**
	 * 閲覧・設定
	 */
	static final int READ_WRITE = 2;
	
	/**
	 * 非表示
	 */
	static final int HIDDEN = 0;
	
	/**
	 * <pre>
	 * 権限設定項目一覧取得
	 * ・指定したロールの権限設定情報を取得する。
	 * ・指定したロールが未定義の場合はすべての権限が非表示の情報を返却する。
	 * </pre>
	 * @param lnUserRole
	 *            LN_利用者ロール論理番号
	 * @param disp_ptn
	 *            画面パターン（U:利用者サイト, P:スマホ）
	 * @return 権限設定情報
	 */
	@NotNull UserRole getUserRole(@NotNull @Size(max = 20) String lnUserRole, @NotNull @Size(max = 1) String disp_ptn);

	/**
	 * <pre>
	 * 権限設定項目一覧登録
	 * ・指定したロールの権限設定情報を登録する。
	 * ・指定したロールが未定義の場合はレコードをINSER、定義済みの場合はUPDATEする。
	 * </pre>
	 * @param userRole 権限設定情報
	 */
	void setUserRole(@NotNull UserRole userRole);
	
	/**
	 * <pre>
	 * 利用者操作範囲取得部品
	 * ・指定した利用者の契約先、警備先、警備先地区を取得する。
	 * ・契約先が一つも見つからない場合は空のリストを返却する。
	 * </pre>
	 * @param lnAcntUserCommon LN_利用者アカウント共通論理番号
	 * @return 契約先情報のリスト
	 */
	@NotNull List<Keiyk> getUserOperationHani(@NotNull @Size(max = 20) String lnAcntUserCommon);
	
	/**
	 * <pre>
	 * 利用者メニュー取得部品
	 * ・指定した利用者、警備先地区で利用可能なメニュー情報一覧を取得する。
	 * ・利用可能なメニューが一つもない場合は空のリストを返却する。
	 * </pre>
	 * @param lnAcntUserCommon LN_利用者アカウント共通論理番号
	 * @param lnKeibi LN_警備先論理番号
	 * @return メニュー情報一覧
	 */
	@NotNull List<Menu> getUserMenuList(@NotNull @Size(max = 20) String lnAcntUserCommon, @NotNull @Size(max = 20) String lnKeibi);
	
	/**
	 * <pre>
	 * 利用権限チェック部品
	 * ・指定した利用者、警備先地区、画面IDの利用権限を調べる。
	 * ・利用権限は、閲覧のみ(1)／閲覧・設定(2)／非表示(0)のいずれか
	 * </pre>
	 * @param lnAcntUserCommon LN_利用者アカウント共通論理番号
	 * @param lnKeiyk LN_契約先論理番号
	 * @param lnKeibi LN_警備先論理番号
	 * @param lnKbChiku 権限有無判定用警備地区論理番号
	 * @param dispId 画面ID
	 * @return 利用権限
	 */
    int getAuth(@NotNull @Size(max = 20) String lnAcntUserCommon,
            @NotNull @Size(max = 20) String lnKeiyk, @NotNull @Size(max = 20) String lnKeibi,
            @Size(max = 20) String lnKbChiku, @NotNull @Size(max = 5) String dispId);
	
	/**
	 * <pre>
	 * 利用者ロール一覧取得部品
	 * ・指定した利用者が編集可能な全てのロールを取得する。
	 * ・対象ロールが1つもない場合は空のリストを返却する。
	 * </pre>
	 * @param lnAcntUserCommon LN_利用者アカウント共通論理番号
	 * @return LN_利用者ロール論理番号がキー、利用者ロール名が値のマップ																																														
	 */
	@NotNull @NotNull Map<String, String> getRoles(@NotNull @Size(max = 20) String lnAcntUserCommon);
	
    /**
     * <pre>
     *         
     * 画面有効アカウント区分情報取得部品
     * 指定した画面の有効アカウント区分情報を取得する。
     * </pre>
     *
     * @param dispId
     *            画面ID
     * @return 有効アカウント区分情報
     */
    YukoAcntUserInf getYukoAcntUserKbnInf(@NotNull @Size(max = 5) String dispId);

    /**
     * <pre>
     *
     * 利用者アカウント区分取得部品
     * 指定した利用者のアカウント区分情報を取得する。
     * </pre>
     *
     * @param lnAcntUserCommon
     *            LN_利用者アカウント共通論理番号
     * @return 利用者アカウント区分
     */
    String getAcntUserKbn(@NotNull @Size(max = 20) String lnAcntUserCommon);
	
	/**
	 * ロール情報
	 * @author SSC
	 */
	static class UserRole {
		/**
		 * LN_利用者ロール論理番号
		 */
		protected String lnUserRole;
		/**
		 * 利用者ロール名
		 */
		protected String userRoleNm;
		/**
		 * 利用者アカウント区分
		 */
		protected String acntUserKbn;
		/**
		 * 個別設定フラグ
		 */
		protected String kobetsuFlg;
		/**
		 * パス情報
		 */
		protected String pathInf;
		/**
		 * 権限情報一覧
		 */
		protected List<UserAuth> userAuthList;
		/**
		 * @return the lnUserRole
		 */
		public String getLnUserRole() {
			return lnUserRole;
		}
		/**
		 * @param lnUserRole the lnUserRole to set
		 */
		public void setLnUserRole(String lnUserRole) {
			this.lnUserRole = lnUserRole;
		}
		/**
		 * @return the userAuthList
		 */
		public List<UserAuth> getUserAuthList() {
			return userAuthList;
		}
		/**
		 * @param userAuthList the userAuthList to set
		 */
		public void setUserAuthList(List<UserAuth> userAuthList) {
			this.userAuthList = userAuthList;
		}
		/**
		 * @return the acntUserKbn
		 */
		public String getAcntUserKbn() {
			return acntUserKbn;
		}
		/**
		 * @param acntUserKbn the acntUserKbn to set
		 */
		public void setAcntUserKbn(String acntUserKbn) {
			this.acntUserKbn = acntUserKbn;
		}
		/**
		 * @return the userRoleNm
		 */
		public String getUserRoleNm() {
			return userRoleNm;
		}
		/**
		 * @param userRoleNm the userRoleNm to set
		 */
		public void setUserRoleNm(String userRoleNm) {
			this.userRoleNm = userRoleNm;
		}
		/**   
		 * @return the kobetsuFlg   
		 */ 
		public String getKobetsuFlg() { 
		    return kobetsuFlg;
		}   
		/** 
		 * @param kobetsuFlg the kobetsuFlg to set  
		 */ 
		public void setKobetsuFlg(String kobetsuFlg) {  
		    this.kobetsuFlg = kobetsuFlg;
		}   
		/**
		 * @return the pathInf
		 */
		public String getPathInf() {
			return pathInf;
		}
		/**
		 * @param pathInf the pathInf to set
		 */
		public void setPathInf(String pathInf) {
			this.pathInf = pathInf;
		}
	}

	/**
	 * 権限情報
	 * @author SSC
	 */
    static class UserAuth {
        /**
         * サービス名称
         */
        protected String serviceNm;
        /**
         * LN_警備先地区論理番号
         */
        protected String lnKbChiku;
        /**
         * 警備先地区名称
         */
        protected String sdKobetuNm;
        /**
         * 利用者アカウント権限ID
         */
        protected String lnUserAcntAuthId;
        /**
         * 画面ID
         */
        protected String dispId;
        /**
         * 画面名
         */
        protected String dispNm;
        /**
         * 設定内容選択肢
         */
        protected List<Integer> authList;
        /**
         * 地区別権限有無
         */
        protected String chikuFlg;
        /**
         * 設定内容
         */
        protected int auth;
        /**
         * メニューパス情報
         */
        protected String menupassInf;

        /**
         * @return the auth
         */
        public int getAuth() {
            return auth;
        }

        /**
         * @param auth
         *            the auth to set
         */
        public void setAuth(int auth) {
            this.auth = auth;
        }

        /**
         * @return the serviceNm
         */
        public String getServiceNm() {
            return serviceNm;
        }

        /**
         * @param serviceNm
         *            the serviceNm to set
         */
        public void setServiceNm(String serviceNm) {
            this.serviceNm = serviceNm;
        }

        /**
         * @return the lnKbChiku
         */
        public String getLnKbChiku() {
            return lnKbChiku;
        }

        /**
         * @param lnKbChiku
         *            the lnKbChiku to set
         */
        public void setLnKbChiku(String lnKbChiku) {
            this.lnKbChiku = lnKbChiku;
        }

        /**
         * @return the sdKobetuNm
         */
        public String getSdKobetuNm() {
            return sdKobetuNm;
        }

        /**
         * @param sdKobetuNm
         *            the sdKobetuNm to set
         */
        public void setSdKobetuNm(String sdKobetuNm) {
            this.sdKobetuNm = sdKobetuNm;
        }

        /**
         * @return the lnUserAcntAuthId
         */
        public String getLnUserAcntAuthId() {
            return lnUserAcntAuthId;
        }

        /**
         * @param lnUserAcntAuthId
         *            the lnUserAcntAuthId to set
         */
        public void setLnUserAcntAuthId(String lnUserAcntAuthId) {
            this.lnUserAcntAuthId = lnUserAcntAuthId;
        }

        /**
         * @return the dispId
         */
        public String getDispId() {
            return dispId;
        }

        /**
         * @param dispId
         *            the dispId to set
         */
        public void setDispId(String dispId) {
            this.dispId = dispId;
        }

        /**
         * @return the dispNm
         */
        public String getDispNm() {
            return dispNm;
        }

        /**
         * @param dispNm
         *            the dispNm to set
         */
        public void setDispNm(String dispNm) {
            this.dispNm = dispNm;
        }

        /**
         * @return the authList
         */
        public List<Integer> getAuthList() {
            return authList;
        }

        /**
         * @param authList
         *            the authList to set
         */
        public void setAuthList(List<Integer> authList) {
            this.authList = authList;
        }

        /**
         * @return the menupassInf
         */
        public String getMenupassInf() {
            return menupassInf;
        }

        /**
         * @param menupassInf
         *            the menupassInf to set
         */
        public void setMenupassInf(String menupassInf) {
            this.menupassInf = menupassInf;
        }
        /**
         * @return the chikuFlg
         */
        public String getChikuFlg() {
            return chikuFlg;
        }
        /**
         * @param chikuFlg
         *            the chikuFlg to set
         */
        public void setChikuFlg(String chikuFlg) {
            this.chikuFlg = chikuFlg;
        }
    }
	
	/**
	 * 契約先情報
	 * @author SSC
	 */
	static class Keiyk {
		/**
		 * LN_契約先論理番号
		 */
		protected String lnKeiyk;
		/**
		 * 警備先一覧
		 */
		protected List<Keibi> keibiList;
		/**
		 * @return the lnKeiyk
		 */
		public String getLnKeiyk() {
			return lnKeiyk;
		}
		/**
		 * @return the keibiList
		 */
		public List<Keibi> getKeibiList() {
			return keibiList;
		}
	}
	
	/**
	 * 警備先情報
	 * @author SSC
	 */
	static class Keibi {
		/**
		 * LN_警備先論理番号
		 */
		protected String lnKeibi;
		/**
		 * 警備先地区一覧
		 */
		protected List<String> chikuList;
		/**
		 * @return the lnKeibi
		 */
		public String getLnKeibi() {
			return lnKeibi;
		}
		/**
		 * @return the chikuList
		 */
		public List<String> getChikuList() {
			return chikuList;
		}
	}
	
	/**
	 * メニュー情報
	 * @author SSC
	 */
	static class Menu {
		/**
		 * 画面ID
		 */
		protected String dispId;
		/**
		 * 画面名
		 */
		protected String dispNm;
		/**
		 * メニューパス情報
		 */
		protected String menupassInf;
		/**
		 * 設定内容
		 */
		protected int auth;
		/**
		 * @return the dispId
		 */
		public String getDispId() {
			return dispId;
		}
		/**
		 * @return the dispNm
		 */
		public String getDispNm() {
			return dispNm;
		}
		/**
		 * @return the menupassInf
		 */
		public String getMenupassInf() {
			return menupassInf;
		}
		/**
		 * @return the auth
		 */
		public int getAuth() {
			return auth;
		}
	}
	
    /**
     * 有効利用者アカウント区分情報.
     *
     * @author SSC
     */
    static class YukoAcntUserInf {
        /**
         * メニューパス情報
         */
        protected String menupassInf;
        /**
         * 地区別権限有無
         */
        protected String chikuFlg;
        /**
         * 有効利用者アカウント区分
         */
        protected String yukoAdntUserKbn;
        /**
         * @return the menupassInf
         */
        public String getMenupassInf() {
            return menupassInf;
        }
        /**
         * @return the chikuFlg
         */
        public String getChikuFlg() {
            return chikuFlg;
        }
        /**
         * @return the yukoAdntUserKbn
         */
        public String getYukoAdntUserKbn() {
            return yukoAdntUserKbn;
        }
    }
}
