package jp.co.alsok.g6.zzw.web;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * セッションオブジェクト制御部品インターフェイス
 * 
 * @author SSC
 */
public interface G6SessionControl {

	/**
	 * <pre>
	 * セッションオブジェクト格納部品
	 * ・セッションオブジェクトをJSON形式でシリアライズしセッションDBに格納する。
	 * ・セッションIDに対応するレコードがない場合はINSERT、ある場合はUPDATEする。
	 * </pre>
	 * 
	 * @param session
	 *            セッションオブジェクト
	 */
	void saveSession(@NotNull G6Session session);

	/**
	 * <pre>
	 * セッションオブジェクト復元部品
	 * ・セッションDBから指定したセッションIDのレコードを取得しオブジェクトを復元する。
	 * ・指定したキーがない場合、createを呼び新規セッションオブジェクトを作成する。（createがnullの場合は生成せずnullを返却する）
	 * </pre>
	 * 
	 * @param <T>
	 *            セッションオブジェクトの型
	 * @param sessionId
	 *            セッションID
	 * @param create
	 *            指定したセッションIDに対応するセッションがない場合に呼び出されるセッション生成処理（引数はセッションID）,
	 *            nullの場合は作成せずnullを返す
	 * @return セッションオブジェクト
	 */
	<T extends G6Session> T loadSession(@NotNull @Size(max = 64) String sessionId, Supplier<T> create);

	/**
	 * <pre>
	 * セッションタイムアウトが発生した際に呼び出す処理を登録する
	 * ・タイムアウト処理実行時にはセッションIDが引数として渡される。処理が終わるまではセッションオブジェクトを参照可能。
	 * </pre>
	 * 
	 * @param process
	 *            タイムアウト時処理(引数はセッションID)
	 */
	void registerOnTimeout(@NotNull Consumer<String> process);

	/**
	 * <pre>
	 * セッションID生成部品
	 * ・複数のAPサーバで呼び出しても重複しないセッションIDを生成する。
	 * ・UUIDをベースに生成したIDがセッションテーブルに存在しないことを確認して返却する（存在する場合は再生成する）
	 * </pre>
	 * 
	 * @return セッションID
	 */
	@NotNull
	String generateSessionId();

	/**
	 * <pre>
	 * セッション読み書き部品
	 * ・セッションオブジェクトの復元、格納を自動で行うためのユーティリティ部品
	 * </pre>
	 * 
	 * @param <T>
	 *            セッションオブジェクトの型
	 * 
	 * @param save
	 *            true:セッションを保存する, false:しない(参照のみの場合に使用)
	 * @param consumer
	 *            セッション読み書き処理
	 * @param create
	 *            セッション新規作成処理(NULLの場合は作成しない)
	 */
	<T extends G6Session> void useSession(boolean save, @NotNull Consumer<T> consumer, Function<String, T> create);

	/**
	 * セッション破棄処理
	 */
	void clean();
}
