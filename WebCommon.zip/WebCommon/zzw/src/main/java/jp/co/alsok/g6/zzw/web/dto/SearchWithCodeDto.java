package jp.co.alsok.g6.zzw.web.dto;

import java.util.Map;

/**
 * コード検索テキストボックス用のDTOクラスです
 * @author SNG
 *
 */
public class SearchWithCodeDto {

	/** 検索データ. */
	private Map<String, String> data;

	/** 検索結果ステータス. */
	private String status;

	/**
	 * 検索データを返却する.
	 * @return 検索データ
	 */
	public Map<String, String> getData() {
		return data;
	}

	/**
	 * 検索データをセットする.
	 * @param data 検索データ
	 */
	public void setData(Map<String, String> data) {
		this.data = data;
	}

	/**
	 * 検索結果ステータスを返却する.
	 * @return 検索結果ステータス
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * 検索結果ステータスをセットする.
	 * @param status 検索結果ステータス
	 */
	public void setStatus(String status) {
		this.status = status;
	}
}
