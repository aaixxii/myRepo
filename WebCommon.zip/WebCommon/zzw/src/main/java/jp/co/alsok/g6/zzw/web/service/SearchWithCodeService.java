package jp.co.alsok.g6.zzw.web.service;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.xml.sax.SAXException;

import jp.co.alsok.g6.zzw.util.StringUtil;
import jp.co.alsok.g6.zzw.web.constants.CommonComponentConstants.CODE_SEARCH_TYPE;
import jp.co.alsok.g6.zzw.web.dao.mapper.g6.CommonSearchWithCodeMapper;
import jp.co.alsok.g6.zzw.web.dto.SearchWithCodeDto;

/**
 * コード検索テキストボックス用のサービスクラスです
 * @author SNG
 *
 */
@Service
public class SearchWithCodeService {

    @Autowired
    /** ログ  */
    ResourceLoader resourceLoader;
    /** コード検索マッパ */
    @Autowired
    private CommonSearchWithCodeMapper commonSearchWithCodeMapper;

    /** 検索結果ステータス定義. */
    private enum STATUS {
            /** 検索成功(1件以上データあり) */
            SUCCESS,
            /** 検索失敗 */
            ERROR,
            /** 検索成功(0件) */
            NOT_EXIST;
    }

    /**
     * 検索キーを基にコード検索結果を返却
     *
     * @param searchType コード検索定義
     * @param searchKey 検索キー
     * @return SearchWithCodeDto コード検索テキストボックス用のDTO
     *
     * @throws URISyntaxException URIを解析することができなかったことを通知する例外。
     * @throws IOException 入出力に関する例外。
     * @throws SAXException SAXに関する例外。
     * @throws ParserConfigurationException XMLパーサーに重大な問題があることを通知する例外。
     */
	@Transactional(propagation = Propagation.REQUIRED)
    public SearchWithCodeDto seachExecut(CODE_SEARCH_TYPE searchType, Map<String, String> queryParameters)
                            throws ParserConfigurationException, SAXException, IOException, URISyntaxException {

        // 返却値
        SearchWithCodeDto ret = new SearchWithCodeDto();
        try {
            // メソッドのパラメータを作成
            Method method = getMethod(queryParameters);
            Object[] methodParams = new String[queryParameters.size()-1 ];
            String[] methodParamNames = searchType.getMethodParamNames();
            int idx = 0;
            for (String name : methodParamNames) {
                // データが取得できない場合
                if (StringUtil.isNullOrEmpty(queryParameters.get(name))) {
                    break;
                }
                methodParams[idx] = queryParameters.get(name);
                idx++;
            }

            List<Map<String, String>> searchResult = new ArrayList<Map<String, String>>();

            // 住所検索の場合
            if (method.getName().equals(CODE_SEARCH_TYPE.SELECT_JYUSYO_BYCODE.getMethodName())) {
                searchResult = this.selectJyusyoByCode(methodParams);
            }
            // 住所カナ検索の場合
            else if (method.getName().equals(CODE_SEARCH_TYPE.SELECT_JYUSYO_KANA_BYCODE.getMethodName())) {
                searchResult = this.selectJyusyoKanaByCode(methodParams);
            }
            // 住所検索以外の場合
            else {
                // 検索実行
                searchResult = autoCast(method.invoke(this, methodParams));
            }

            // 住所検索結果判定
            if (CollectionUtils.isEmpty(searchResult)) {
                ret.setStatus(STATUS.NOT_EXIST.toString());
            } else {
                ret.setStatus(STATUS.SUCCESS.toString());
                ret.setData(searchResult.get(0));
            }
        } catch (Exception e) {
            ret.setStatus(STATUS.ERROR.toString());
        }

        return ret;
    }

    /**
     * 対象のメソッド名 取得
     *
     * @param queryParameters
     * @return Method 対象のメソッド名
     */
    private Method getMethod(Map<String, String> queryParameters) {
        // 実行メソッドの判定. オバーロードは考慮しない。
        Method[] methods = this.getClass().getMethods();
        for (Method method : methods) {
            // 指定されたメソッド名か判定
            if(!method.getName().equals(queryParameters.get("methodName"))) {
                continue;
            }
            return method;
        }
        return null;
    }

    /**
     * オブジェクトのキャストを行う.
     * @param object キャストするオブジェクト
     * @return キャストしたオブジェクト
     */
    @SuppressWarnings("unchecked")
    private <T>  T autoCast(Object object) {
        return (T) object;
    }

    // **************************
    // 監視巡回サイト,運用サイト共通のコード検索
    // **************************
    /**
     * ガードセンター.GC名称を、GCコードを基に取得する.
     *
     * @param gcCd GCコード
     * @return gcNm GC名称
     */
	@Transactional(propagation = Propagation.REQUIRED)
    public List<Map<String, String>> selectGcNmByCode(String gcCd) {
        return commonSearchWithCodeMapper.selectGcNmByCode(gcCd);
    }

    /**
     * 契約先.事業所.事業所名称 を 、事業所コードを基に取得する.
     *
     * @param jigyouCd 事業所コード
     * @return jigyouNm 事業所.事業所名称
     */
	@Transactional(propagation = Propagation.REQUIRED)
    public List<Map<String, String>> selectJigyouNmByCode(String jigyouCd) {
        return commonSearchWithCodeMapper.selectJigyouNmByCode(jigyouCd);
    }

    // **************************
    // 監視巡回サイトのコード検索
    // **************************
    /**
     * G6 判断理由マスタ.内容を、判断理由IDを基に、内容を取得する.
     *
     * @param reasonId 判断理由ID
     * @return reasonNaiyou G6内容
     */
	@Transactional(propagation = Propagation.REQUIRED)
    public List<Map<String, String>> selectReasonNaiyouByCode(String reasonId) {
        return commonSearchWithCodeMapper.selectReasonNaiyouByCode(reasonId);
    }

    /**
     * GV 判断理由マスタ.内容を、判断理由IDを基に、内容を取得する.
     *
     * @param idReason 判断理由ID
     * @return naiyou GV内容
     */
	@Transactional(propagation = Propagation.REQUIRED)
    public List<Map<String, String>> selectReasonNaiyouGVByCode(String idReason) {
        return commonSearchWithCodeMapper.selectReasonNaiyouGVByCode(idReason);
    }

    /**
     * 原因マスター.原因内容を、原因IDを基に、内容を取得する.
     *
     * @param geninId 原因ID
     * @return geninNaiyou 原因内容
     */
	@Transactional(propagation = Propagation.REQUIRED)
    public List<Map<String, String>> selectGeninNaiyouByCode(String geninId) {
        return commonSearchWithCodeMapper.selectGeninNaiyouByCode(geninId);
    }

    /**
     * V6事案分類コードファイル.内容を、ID事案分類コードを基に、内容を取得する.
     *
     * @param idJianbnrCd ID事案分類コード
     * @return jianbnrcdNaiyou 内容
     */
	@Transactional(propagation = Propagation.REQUIRED)
    public List<Map<String, String>> selectJianbnrcdNaiyouByCode(String idJianbnrCd) {
        return commonSearchWithCodeMapper.selectJianbnrcdNaiyouByCode(idJianbnrCd);
    }

    /**
     * V6警報分類コード.内容を、ID_警報分類コードを基に、内容を取得する.
     *
     * @param reasonId ID_警報分類コード
     * @return v6KeihobnrcdNaiyou 内容
     */
	@Transactional(propagation = Propagation.REQUIRED)
    public List<Map<String, String>> selectV6KeihobnrcdNaiyouByCode(String idKeihobnrcd) {
        return commonSearchWithCodeMapper.selectV6KeihobnrcdNaiyouByCode(idKeihobnrcd);
    }

    /**
     * V6原因分類コード.内容を、判断ID_原因分類コードを基に、内容を取得する.
     *
     * @param reasonId 判断ID_原因分類コード
     * @return v6GenbnrcdNaiyou 内容
     */
	@Transactional(propagation = Propagation.REQUIRED)
    public List<Map<String, String>> selectV6GenbnrcdNaiyouByCode(String idGenbnrcd) {
        return commonSearchWithCodeMapper.selectV6GenbnrcdNaiyouByCode(idGenbnrcd);
    }

    // **************************
    // 運用サイトのコード検索
    // **************************
    /**
     * 警備先.「警備先名1＋警備先名2」を お客様番号２を基に取得する.
     *
     * @param customerNum2 お客様番号２
     * @return 「警備先名1＋警備先名2」
     */
	@Transactional(propagation = Propagation.REQUIRED)
    public List<Map<String, String>> selectKeibiNameByCode(String customerNum2) {
        return commonSearchWithCodeMapper.selectKeibiNameByCode(customerNum2);
    }

    /**
     * 警備先.警備先略称名称 を お客様番号２を基に取得する.
     *
     * @param customerNum2 入力コード値
     * @return keibisakiAbbrNm 警備先略称名称
     */
	@Transactional(propagation = Propagation.REQUIRED)
    public List<Map<String, String>> selectKeibisakiAbbrNmByCode(String customerNum2) {
        return commonSearchWithCodeMapper.selectKeibisakiAbbrNmByCode(customerNum2);
    }

    /**
     *  契約先.契約先名称を 契約先コードを基に取得する.
     *
     * @param keiykCd 契約先コード
     * @return keiykNm 契約先名称
     */
	@Transactional(propagation = Propagation.REQUIRED)
    public List<Map<String, String>> selectKeiykNmByCode(String keiykCd)  {
        return commonSearchWithCodeMapper.selectKeiykNmByCode(keiykCd);
    }

    /**
     *  住所マスター.住所を (都道府県名,市区町村名,大字町名,小字町名,丁目名,番地名)を基に取得する.
     *
     * @param  addrNm1～addrNm6 (都道府県名,市区町村名,大字町名,小字町名,丁目名,番地名)
     * @return jyusyo 契約先名称
     */
	@Transactional(propagation = Propagation.REQUIRED)
    public List<Map<String, String>> selectJyusyoByCode(Object[] methodParams) {

        // 住所検索用のパラメータを設定
        Map<String, Object> param = new HashMap<String, Object>();
        int index = 1;
        String key = "";
        for (Object col : methodParams) {
            if(null == col){
                break;
            }
            // 検索keyの生成
            key = "addrCd" + index;
            param.put(key, col);
            index++;
        }

        // 住所検索
        List<Map<String, String>> result = new ArrayList<Map<String, String>>();
        if ("addrCd1".equals(key)) {
            result = commonSearchWithCodeMapper.selectJyusyoAddrCd1ByCode(param);
        } else if ("addrCd2".equals(key)) {
            result = commonSearchWithCodeMapper.selectJyusyoAddrCd2ByCode(param);
        } else if ("addrCd3".equals(key)) {
            result = commonSearchWithCodeMapper.selectJyusyoAddrCd3ByCode(param);
        } else if ("addrCd4".equals(key)) {
            result = commonSearchWithCodeMapper.selectJyusyoAddrCd4ByCode(param);
        } else if ("addrCd5".equals(key)) {
            result = commonSearchWithCodeMapper.selectJyusyoAddrCd5ByCode(param);
        } else if ("addrCd6".equals(key)) {
            result = commonSearchWithCodeMapper.selectJyusyoAddrCd6ByCode(param);
        }
        return result;
    }


    /**
     * 住所マスター.住所(カナ)を (都道府県名,市区町村名,大字町名,小字町名,丁目名,番地名)を基に取得する.
     * @param methodParams
     * @return
     */
	@Transactional(propagation = Propagation.REQUIRED)
    public List<Map<String, String>> selectJyusyoKanaByCode(Object[] methodParams) {
         // 住所検索用のパラメータを設定
        Map<String, Object> param = new HashMap<String, Object>();
        int index = 1;
        String key = "";
        for (Object col : methodParams) {
            if(null == col){
                break;
            }
            // 検索keyの生成
            key = "addrCd" + index;
            param.put(key, col);
            index++;
        }

        // 住所検索
        List<Map<String, String>> result = new ArrayList<Map<String, String>>();
        if ("addrCd1".equals(key)) {
            result = commonSearchWithCodeMapper.selectJyusyoAddrCd1KanaByCode(param);
        } else if ("addrCd2".equals(key)) {
            result = commonSearchWithCodeMapper.selectJyusyoAddrCd2KanaByCode(param);
        } else if ("addrCd3".equals(key)) {
            result = commonSearchWithCodeMapper.selectJyusyoAddrCd3KanaByCode(param);
        } else if ("addrCd4".equals(key)) {
            result = commonSearchWithCodeMapper.selectJyusyoAddrCd4KanaByCode(param);
        } else if ("addrCd5".equals(key)) {
            result = commonSearchWithCodeMapper.selectJyusyoAddrCd5KanaByCode(param);
        } else if ("addrCd6".equals(key)) {
            result = commonSearchWithCodeMapper.selectJyusyoAddrCd6KanaByCode(param);
        }
        return result;
    }
}
