package jp.co.alsok.g6.zzw.web.constants;

/**
 * 共通 DBアクセス用 定数クラス
 *
 * @author SNG-105
 */
public class DbAccessConstants {

    /** DBアクセスフラグ */
    public static enum DB_ACCESS_FLG {

        /** 登録 */
        INSERT(1),
        /** 更新 */
        UPDATE(2),
        /** 削除 */
        DELETE(3);

        /** DBアクセスフラグ */
        private int dbAcsessFlg;

        /**
         * アクセスフラグ
         * @param dbAcsessFlg
         */
        private DB_ACCESS_FLG(int dbAcsessFlg) {
            this.dbAcsessFlg = dbAcsessFlg;
        }

        /**
         * アクセスフラグを返却
         * @return dbAcsessFlg
         */
        public int getDbAcsessFlg() {
            return this.dbAcsessFlg;
        }
    }

    /** ログインシステムフラグ */
    public static enum LOGIN_SYS_FLG {

        /** システムflag 次期(G6) */
        SYS_G6(1),
        /** システムflag GHS */
        SYS_GHS(2),
        /** システムflag G5 */
        SYS_G5(3);

        /** ログインシステムフラグ */
        private int loginSysFlg;

        /**
         * ログインシステムフラグ を設定
         * @param loginSysFlg
         */
        private LOGIN_SYS_FLG(int loginSysFlg) {
            this.loginSysFlg = loginSysFlg;
        }

        /**
         * ログインシステムフラグを返却
         * @return loginSysFlg ログインシステムflag
         */
        public int getLoginSysFlg() {
            return loginSysFlg;
        }
    }
    /** アカウント種別 */
    public static enum ACNT_KIND {

        /** 0:次期警備システム */
        G6_ACNT_KIND("0"),
        /** 1:GⅤ */
        G5_ACNT_KIND("1"),
        /** 2:GHS(利用者) */
        GHS_USER_ACNT_KIND("2"),
        /** 3:GHS(契約先) */
        GHS_ALSOK_ACNT_KIND("3");

        /** アカウント種別 */
        private String acntKind;

        /**
         * アカウント種別
         * @param acntKind
         */
        private ACNT_KIND(String acntKind) {
            this.acntKind = acntKind;
        }
        /**
         * アカウント種別を取得
         * @return acntKind
         */
        public String getAcntKind() {
            return acntKind;
        }
    }

    // 接続するDB指定フラグ
    /** システムフラグ G6,G5,GHSに接続 */
    public static final int CONNECT_DB_G6_G5_GHS = 0;
    /** システムフラグ G6,GHSに接続 */
    public static final int CONNECT_DB_G6_GHS = 1;
    /** システムフラグ G6,G5に接続  */
    public static final int CONNECT_DB_G6_G5 = 2;
    /** システムフラグ G6に接続  */
    public static final int CONNECT_DB_G6 = 3;

    // 更新日時 判定フラグ
    /** 更新日時判定フラグ (0:更新しない)*/
    public static final int DATE_OVERRIDE_FLG_OFF = 0;
    /** 更新日時判定フラグ (1:更新する)*/
    public static final int DATE_OVERRIDE_FLG_ON = 1;

}
