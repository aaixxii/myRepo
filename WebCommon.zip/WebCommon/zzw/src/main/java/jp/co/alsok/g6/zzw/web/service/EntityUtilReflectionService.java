package jp.co.alsok.g6.zzw.web.service;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Date;

import org.springframework.stereotype.Service;

import jp.co.alsok.g6.common.exception.IllegalParameterException;
import jp.co.alsok.g6.common.util.string.StringUtil;
import jp.co.alsok.g6.zzw.web.constants.EntityType;
import jp.co.alsok.g6.zzw.web.constants.DbAccessConstants.DB_ACCESS_FLG;
import jp.co.alsok.g6.zzw.web.dto.AbstractAccountInfoDto;
import jp.co.alsok.g6.zzw.web.dto.AlsokAccountInfoDto;
import jp.co.alsok.g6.zzw.web.dto.KeiyakuUserInfoDto;

/**
 * DB共通項目設定部品（リフレクション版）
 *
 * @author kadena.t
 *
 */
@Service
public class EntityUtilReflectionService {

	private final int DATE_OVERRIDE_FALSE = 0;
	private final int DATE_OVERRIDE_TRUE = 1;
	private final int DATE_NOSET = 2;

	static protected final String[] METHOD_G6_INS_SEQ = { "setInsertId", "setINSERT_ID" };
	static protected final String[] METHOD_G6_INS_UID = { "setInsertNm", "setINSERT_NM" };
	static protected final String[] METHOD_G6_INS_DATE = { "setInsertTs", "setINSERT_TS" };
	static protected final String[] METHOD_G6_UPD_SEQ = { "setUpdateId", "setUPDATE_ID" };
	static protected final String[] METHOD_G6_UPD_UID = { "setUpdateNm", "setUPDATE_NM" };
	static protected final String[] METHOD_G6_UPD_DATE = { "setUpdateTs", "setUPDATE_TS" };

	static protected final String[] METHOD_G5_INS_SEQ = { "setIdInsert", "setID_INSERT", "setInsertId", "setINSERT_ID" };
	static protected final String[] METHOD_G5_INS_UID = { "setInsertNm", "setINSERT_NM", "setInsertName", "setINSERT_NAME" };
	static protected final String[] METHOD_G5_INS_DATE = { "setInsertTs", "setINSERT_TS" };
	static protected final String[] METHOD_G5_UPD_SEQ = { "setIdLastupd", "setID_LASTUPD" };
	static protected final String[] METHOD_G5_UPD_UID = { "setLastupdNm", "setLASTUPD_NM", "setLastupdName", "setLASTUPD_NAME" };
	static protected final String[] METHOD_G5_UPD_DATE = { "setLastupdTs", "setLASTUPD_TS" };

	static protected final String[] METHOD_GHS_INS_SEQ = { "setIdInsert", "setID_INSERT" };
	static protected final String[] METHOD_GHS_INS_UID = { "setInsertNm", "setINSERT_NM" };
	static protected final String[] METHOD_GHS_INS_DATE = { "setInsertTs", "setINSERT_TS" };
	static protected final String[] METHOD_GHS_UPD_SEQ = { "setIdUpdate", "setID_UPDATE" };
	static protected final String[] METHOD_GHS_UPD_UID = { "setUpdateNm", "setUPDATE_NM" };
	static protected final String[] METHOD_GHS_UPD_DATE = { "setUpdateTs", "setUPDATE_TS" };

	/**
	 * <pre>
	 * G6のEntity共通項目の設定を行います。日付フィールドにシステム日時を設定します。
	 *
	 * 引数dbAccessFlgの指定によって次の項目を設定します。
	 *   Insert:
	 *     登録アカウント論理番号,登録ユーザー名, 登録日時
	 *     更新アカウント論理番号,更新ユーザー名, 更新日時
	 *   Update:
	 *     更新アカウント論理番号,更新ユーザー名, 更新日時
	 *   Delete:
	 *     更新アカウント論理番号,更新ユーザー名, 更新日時
	 *
	 * 引数obj にG6のDB共通項目を持つEntityまたはDTOクラスを設定します。
	 * </pre>
	 *
	 * @param dbAccessFlg
	 * @param obj
	 * @param alsokAccountInfoDto
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @throws IllegalParameterException
	 */
	public void setCommonParameterG6DateOverride(DB_ACCESS_FLG dbAccessFlg, Object obj,
			AbstractAccountInfoDto accountInfoDto)
			throws IllegalAccessException, InvocationTargetException, IllegalParameterException {
		this.setCommonParameter(dbAccessFlg, EntityType.TYPE.G6, obj, accountInfoDto, DATE_OVERRIDE_TRUE);
	}

	/**
	 * <pre>
	 * G5のEntity共通項目の設定を行います。日付フィールドにシステム日時を設定します。
	 *
	 * 引数dbAccessFlgの指定によって次の項目を設定します。
	 *   Insert:
	 *     登録アカウント論理番号,登録ユーザー名, 登録日時
	 *     更新アカウント論理番号,更新ユーザー名, 更新日時
	 *   Update:
	 *     更新アカウント論理番号,更新ユーザー名, 更新日時
	 *   Delete:
	 *     更新アカウント論理番号,更新ユーザー名, 更新日時
	 *
	 * 引数obj にG5のDB共通項目を持つEntityまたはDTOクラスを設定します。
	 * </pre>
	 *
	 * @param dbAccessFlg
	 * @param obj
	 * @param alsokAccountInfoDto
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @throws IllegalParameterException
	 */
	public void setCommonParameterG5DateOverride(DB_ACCESS_FLG dbAccessFlg, Object obj,
			AbstractAccountInfoDto accountInfoDto)
			throws IllegalAccessException, InvocationTargetException, IllegalParameterException {
		this.setCommonParameter(dbAccessFlg, EntityType.TYPE.G5, obj, accountInfoDto, DATE_OVERRIDE_TRUE);
	}

	/**
	 * <pre>
	 * GHSのEntity共通項目の設定を行います。日付フィールドにシステム日時を設定します。
	 *
	 * 引数dbAccessFlgの指定によって次の項目を設定します。
	 *   Insert:
	 *     登録アカウント論理番号,登録ユーザー名, 登録日時
	 *     更新アカウント論理番号,更新ユーザー名, 更新日時
	 *   Update:
	 *     更新アカウント論理番号,更新ユーザー名, 更新日時
	 *   Delete:
	 *     更新アカウント論理番号,更新ユーザー名, 更新日時
	 *
	 * 引数obj にGHSのDB共通項目を持つEntityまたはDTOクラスを設定します。
	 * </pre>
	 *
	 * @param dbAccessFlg
	 * @param obj
	 * @param alsokAccountInfoDto
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @throws IllegalParameterException
	 */
	public void setCommonParameterGhsDateOverride(DB_ACCESS_FLG dbAccessFlg, Object obj,
			AbstractAccountInfoDto accountInfoDto)
			throws IllegalAccessException, InvocationTargetException, IllegalParameterException {
		this.setCommonParameter(dbAccessFlg, EntityType.TYPE.GHS, obj, accountInfoDto, DATE_OVERRIDE_TRUE);
	}

	/**
	 * <pre>
	 * G6のEntity共通項目の設定を行います。登録日時、更新日時を設定しません。
	 * 日付フィールドで楽観ロックを実装する際に利用される想定です。
	 *
	 * 引数dbAccessFlgの指定によって次の項目を設定します。
	 *   Insert:
	 *     登録アカウント論理番号,登録ユーザー名, 登録日時
	 *     更新アカウント論理番号,更新ユーザー名, 更新日時
	 *   Update:
	 *     更新アカウント論理番号,更新ユーザー名, 更新日時
	 *   Delete:
	 *     更新アカウント論理番号,更新ユーザー名, 更新日時
	 *
	 * 引数obj にG6のDB共通項目を持つEntityまたはDTOクラスを設定します。
	 * </pre>
	 *
	 * @param dbAccessFlg
	 * @param obj
	 * @param alsokAccountInfoDto
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @throws IllegalParameterException
	 */
	public void setCommonParameterG6(DB_ACCESS_FLG dbAccessFlg, Object obj,
			AbstractAccountInfoDto accountInfoDto)
			throws IllegalAccessException, InvocationTargetException, IllegalParameterException {
		this.setCommonParameter(dbAccessFlg, EntityType.TYPE.G6, obj, accountInfoDto, DATE_NOSET);
	}

	/**
	 * <pre>
	 * G5のEntity共通項目の設定を行います。登録日時、更新日時を設定しません。
	 * 日付フィールドで楽観ロックを実装する際に利用される想定です。
	 *
	 * 引数dbAccessFlgの指定によって次の項目を設定します。
	 *   Insert:
	 *     登録アカウント論理番号,登録ユーザー名, 登録日時
	 *     更新アカウント論理番号,更新ユーザー名, 更新日時
	 *   Update:
	 *     更新アカウント論理番号,更新ユーザー名, 更新日時
	 *   Delete:
	 *     更新アカウント論理番号,更新ユーザー名, 更新日時
	 *
	 * 引数obj にG5のDB共通項目を持つEntityまたはDTOクラスを設定します。
	 * </pre>
	 *
	 * @param dbAccessFlg
	 * @param obj
	 * @param alsokAccountInfoDto
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @throws IllegalParameterException
	 */
	public void setCommonParameterG5(DB_ACCESS_FLG dbAccessFlg, Object obj,
			AbstractAccountInfoDto accountInfoDto)
			throws IllegalAccessException, InvocationTargetException, IllegalParameterException {
		this.setCommonParameter(dbAccessFlg, EntityType.TYPE.G5, obj, accountInfoDto, DATE_NOSET);
	}

	/**
	 * <pre>
	 * GHSのEntity共通項目の設定を行います。登録日時、更新日時を設定しません。
	 * 日付フィールドで楽観ロックを実装する際に利用される想定です。
	 *
	 * 引数dbAccessFlgの指定によって次の項目を設定します。
	 *   Insert:
	 *     登録アカウント論理番号,登録ユーザー名, 登録日時
	 *     更新アカウント論理番号,更新ユーザー名, 更新日時
	 *   Update:
	 *     更新アカウント論理番号,更新ユーザー名, 更新日時
	 *   Delete:
	 *     更新アカウント論理番号,更新ユーザー名, 更新日時
	 *
	 * 引数obj にGHSのDB共通項目を持つEntityまたはDTOクラスを設定します。
	 * </pre>
	 *
	 * @param dbAccessFlg 登録:INSERT, 更新:UPDATE, 削除:DELETE
	 * @param obj 共通項目を設定するEntity
	 * @param alsokAccountInfoDto
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @throws IllegalParameterException
	 */
	public void setCommonParameterGhs(DB_ACCESS_FLG dbAccessFlg, Object obj,
			AbstractAccountInfoDto accountInfoDto)
			throws IllegalAccessException, InvocationTargetException, IllegalParameterException {
		this.setCommonParameter(dbAccessFlg, EntityType.TYPE.GHS, obj, accountInfoDto, DATE_NOSET);
	}

	/**
	 * <pre>
	 * 次期(G6), G5, GHSのEntity共通項目の設定を行います。
	 * 引数dbAccessFlgの指定によって次の項目を設定します。
	 *   Insert:
	 *     登録アカウント論理番号,登録ユーザー名, 登録日時
	 *     更新アカウント論理番号,更新ユーザー名, 更新日時
	 *   Update:
	 *     更新アカウント論理番号,更新ユーザー名, 更新日時
	 *   Delete:
	 *     更新アカウント論理番号,更新ユーザー名, 更新日時
	 *
	 * 引数EntityTypeでEntityのタイプ(G6, G5, GHS)を設定する必要があります。
	 * 引数obj にDB共通項目を持つEntityまたはDTOクラスを設定します。
	 * 引数DateOverrideの値で日付フィールドの更新有無を決定します。
	 * </pre>
	 *
	 * @param dbAccessFlg 登録:INSERT, 更新:UPDATE, 削除:DELETE
	 * @param type EntityType G6, G5, GHS
	 * @param obj 共通項目を設定するEntity
	 * @param account AlsokAccountInfoDtoまたはKeiyakuUserInfoDto
	 * @param dateOverride true:日付を更新, false:日付を更新しない
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @throws IllegalParameterException
	 */
	public void setCommonParameter(DB_ACCESS_FLG dbAccessFlg, EntityType.TYPE type, Object obj,
			AbstractAccountInfoDto account, int dateOverride)
			throws IllegalAccessException, InvocationTargetException, IllegalParameterException {

		String userNo = ""; // 次期, GHSはアカウント論理番号、G5は社員番号
		String userNm = ""; // ユーザー名

		Method[] ms = obj.getClass().getMethods();

		if (type == EntityType.TYPE.G6) {

			if (account instanceof AlsokAccountInfoDto) {
				// AlsokAccount
				userNo = ((AlsokAccountInfoDto) account).getG6LnAcntAlsokNo();
				userNm = ((AlsokAccountInfoDto) account).getG6LnAcntAlsokName();

			} else if (account instanceof KeiyakuUserInfoDto) {
				// 利用者Account
				userNo = ((KeiyakuUserInfoDto) account).getG6LnAcntAlsokNo();
				userNm = ((KeiyakuUserInfoDto) account).getG6LnAcntAlsokName();
			}

			if (dbAccessFlg == DB_ACCESS_FLG.INSERT) {
				// 登録
				this.setInsertG6(ms, type, obj, userNo, userNm, dateOverride);
			} else {
				// 更新・削除
				this.setUpdateG6(ms, type, obj, userNo, userNm, dateOverride);
			}

		} else if (type == EntityType.TYPE.G5) {

			if (account instanceof AlsokAccountInfoDto) {
				// AlsokAccount
				// 次期警-管理-18008(ALSOK-NEC課題・質問管理表(画面)) No59の対応 start
				//userNo = ((AlsokAccountInfoDto)account).getgetG5UserNum();
				//userNm = ((AlsokAccountInfoDto)account).getG5LnAcntAlsokName();
				userNo = this.getEmpolyeeNo(((AlsokAccountInfoDto) account).getG6UserNum());
				userNm = ((AlsokAccountInfoDto) account).getG6LnAcntAlsokName();
				// 次期警-管理-18008(ALSOK-NEC課題・質問管理表(画面)) No59の対応 end

			} else if (account instanceof KeiyakuUserInfoDto) {
				// 利用者Account
				userNo = ((KeiyakuUserInfoDto) account).getG5LnAcntAlsokNo();
				userNm = ((KeiyakuUserInfoDto) account).getG5LnAcntAlsokName();
			}

			if (dbAccessFlg == DB_ACCESS_FLG.INSERT) {
				// 登録
				this.setInsertG5(ms, type, obj, userNo, userNm, dateOverride);
			} else {
				// 更新・削除
				this.setUpdateG5(ms, type, obj, userNo, userNm, dateOverride);
			}

		} else if (type == EntityType.TYPE.GHS) {

			if (account instanceof AlsokAccountInfoDto) {
				// AlsokAccount
				// 次期警-管理-18008(ALSOK-NEC課題・質問管理表(画面)) No59の対応 start
				//userNo = ((AlsokAccountInfoDto)account).getGhsLnAcntAlsokNo();
				//userNm = ((AlsokAccountInfoDto)account).getGhsLnAcntAlsokName();
				userNo = ((AlsokAccountInfoDto) account).getG6LnAcntAlsokNo();
				userNm = ((AlsokAccountInfoDto) account).getG6LnAcntAlsokName();
				// 次期警-管理-18008(ALSOK-NEC課題・質問管理表(画面)) No59の対応 end

			} else if (account instanceof KeiyakuUserInfoDto) {
				// 利用者Account
				userNo = ((KeiyakuUserInfoDto) account).getGhsLnAcntAlsokNo();
				userNm = ((KeiyakuUserInfoDto) account).getGhsLnAcntAlsokName();
			}

			if (dbAccessFlg == DB_ACCESS_FLG.INSERT) {
				// 登録
				this.setInsertGhs(ms, type, obj, userNo, userNm, dateOverride);
			} else {
				// 更新・削除
				this.setUpdateGhs(ms, type, obj, userNo, userNm, dateOverride);
			}

		}

	}

	private void setInsertG6(Method[] ms, EntityType.TYPE type, Object obj, String userNo, String userNm,
			int dateOverride)
			throws IllegalAccessException, InvocationTargetException, IllegalParameterException {

		// システム日付を取得
		Date nowDate = new Date();

		for (Method m : ms) {

			this.executeInvokeMethod(this.getG6InsertSeqMethodNames(), m, obj, userNo);
			this.executeInvokeMethod(this.getG6InsertUidMethodNames(), m, obj, userNm);
			if (!isDateNotSet(dateOverride)) {
				this.executeDateInvokeMethod(this.getG6InsertTsMethodNames(), m, obj, nowDate, dateOverride);
			}

			this.executeInvokeMethod(this.getG6UpdateSeqMethodNames(), m, obj, userNo);
			this.executeInvokeMethod(this.getG6UpdateUidMethodNames(), m, obj, userNm);
			if (!isDateNotSet(dateOverride)) {
				this.executeDateInvokeMethod(this.getG6UpdateTsMethodNames(), m, obj, nowDate, dateOverride);
			}
		}

	}

	private void setUpdateG6(Method[] ms, EntityType.TYPE type, Object obj, String userNo, String userNm,
			int dateOverride)
			throws IllegalAccessException, InvocationTargetException, IllegalParameterException {

		// システム日付を取得
		Date nowDate = new Date();

		for (Method m : ms) {

			this.executeInvokeMethod(this.getG6UpdateSeqMethodNames(), m, obj, userNo);
			this.executeInvokeMethod(this.getG6UpdateUidMethodNames(), m, obj, userNm);

			if (!isDateNotSet(dateOverride)) {
				this.executeDateInvokeMethod(this.getG6UpdateTsMethodNames(), m, obj, nowDate, dateOverride);
			}
		}
	}

	private void setInsertG5(Method[] ms, EntityType.TYPE type, Object obj, String userNo, String userNm,
			int dateOverride)
			throws IllegalAccessException, InvocationTargetException, IllegalParameterException {

		// システム日付を取得
		Date nowDate = new Date();

		for (Method m : ms) {

			this.executeInvokeMethod(this.getG5InsertSeqMethodNames(), m, obj, userNo);
			this.executeInvokeMethod(this.getG5InsertUidMethodNames(), m, obj, userNm);

			if (!isDateNotSet(dateOverride)) {
				this.executeDateInvokeMethod(this.getG5InsertTsMethodNames(), m, obj, nowDate, dateOverride);
			}

			this.executeInvokeMethod(this.getG5UpdateSeqMethodNames(), m, obj, userNo);
			this.executeInvokeMethod(this.getG5UpdateUidMethodNames(), m, obj, userNm);

			if (!isDateNotSet(dateOverride)) {
				this.executeDateInvokeMethod(this.getG5UpdateTsMethodNames(), m, obj, nowDate, dateOverride);
			}
		}
	}

	private void setUpdateG5(Method[] ms, EntityType.TYPE type, Object obj, String userNo, String userNm,
			int dateOverride)
			throws IllegalAccessException, InvocationTargetException, IllegalParameterException {

		// システム日付を取得
		Date nowDate = new Date();

		for (Method m : ms) {

			this.executeInvokeMethod(this.getG5UpdateSeqMethodNames(), m, obj, userNo);
			this.executeInvokeMethod(this.getG5UpdateUidMethodNames(), m, obj, userNm);

			if (!isDateNotSet(dateOverride)) {
				this.executeDateInvokeMethod(this.getG5UpdateTsMethodNames(), m, obj, nowDate, dateOverride);
			}
		}
	}

	private void setInsertGhs(Method[] ms, EntityType.TYPE type, Object obj, String userNo, String userNm,
			int dateOverride)
			throws IllegalAccessException, InvocationTargetException, IllegalParameterException {

		// システム日付を取得
		Date nowDate = new Date();

		for (Method m : ms) {

			this.executeInvokeMethod(this.getGhsInsertSeqMethodNames(), m, obj, userNo);
			this.executeInvokeMethod(this.getGhsInsertUidMethodNames(), m, obj, userNm);

			if (!isDateNotSet(dateOverride)) {
				this.executeDateInvokeMethod(this.getGhsInsertTsMethodNames(), m, obj, nowDate, dateOverride);
			}

			this.executeInvokeMethod(this.getGhsUpdateSeqMethodNames(), m, obj, userNo);
			this.executeInvokeMethod(this.getGhsUpdateUidMethodNames(), m, obj, userNm);

			if (!isDateNotSet(dateOverride)) {
				this.executeDateInvokeMethod(this.getGhsUpdateTsMethodNames(), m, obj, nowDate, dateOverride);
			}
		}
	}

	private void setUpdateGhs(Method[] ms, EntityType.TYPE type, Object obj, String userNo, String userNm,
			int dateOverride)
			throws IllegalAccessException, InvocationTargetException, IllegalParameterException {

		// システム日付を取得
		Date nowDate = new Date();

		for (Method m : ms) {

			this.executeInvokeMethod(this.getGhsUpdateSeqMethodNames(), m, obj, userNo);
			this.executeInvokeMethod(this.getGhsUpdateUidMethodNames(), m, obj, userNm);

			if (!isDateNotSet(dateOverride)) {
				this.executeDateInvokeMethod(this.getGhsUpdateTsMethodNames(), m, obj, nowDate, dateOverride);
			}
		}
	}

	/**
	 * メソッド名と一致するメソッドがある場合、メソッドを実行します。
	 *
	 * @param names
	 * @param m
	 * @param obj
	 * @param param
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 * @throws InvocationTargetException
	 */
	private void executeInvokeMethod(String[] names, Method m, Object obj, Object param)
			throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		for (String methodName : names) {
			if (methodName.equals(m.getName())) {
				m.invoke(obj, param);
			}
		}
	}

	/**
	 * メソッド名と一致するメソッドがある場合、メソッドを実行します。
	 *
	 * @param names
	 * @param m
	 * @param obj
	 * @param param
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 * @throws InvocationTargetException
	 */
	private void executeDateInvokeMethod(String[] names, Method m, Object obj, Object param, int override)
			throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		for (String methodName : names) {
			if (methodName.equals(m.getName())) {

				Date date = this.getDate(m, methodName, obj);

				if (date == null || isDateOverrideTrue(override)) {

					m.invoke(obj, param);
				}
			}
		}
	}

	private Date getDate(Method m, String methodName, Object obj) {

		StringBuffer buf = new StringBuffer();
		buf.append("get");
		buf.append(methodName.substring(3));
		Method getMethod = null;
		try {
			getMethod = obj.getClass().getMethod(buf.toString(), new Class[] {});

			Object result = getMethod.invoke(obj);

			if (result instanceof Date) {
				return (Date) result;
			}

		} catch (Exception e) {
			e.printStackTrace();
			// ここでメソッドが存在しない場合などで例外が発生する場合、
			// 値が取得できなかったと判断し、例外を投げない。
		}

		return null;
	}

	/**
	 * 引数noから末尾6文字を切り出して返却します。
	 *
	 * @param no
	 * @return
	 */
	private String getEmpolyeeNo(String no) {

		String empolyeeNo = no;

		if (StringUtil.isNullOrEmpty(no)) {
			return null;
		}

		if (no.length() > 6) {
			for (int i = 0; i < no.length(); i++) {
				if (no.length() - i == 6) {
					empolyeeNo = no.substring(i);
				}
			}
		}

		return empolyeeNo;
	}

	private boolean isDateOverrideTrue(int value) {
		if (DATE_OVERRIDE_TRUE == value) {
			return true;
		}
		return false;
	}

	private boolean isDateNotSet(int value) {
		if (DATE_NOSET == value) {
			return true;
		}
		return false;
	}

	// ------------------------------------------------

	/**
	 * リフレクションで呼び出すG6登録ユーザー論理番号のメソッドパターンを返却します。
	 * クラス規定のメソッドパターンで足りない場合にはOverrideしてメソッドパターンを追加してください。
	 * @return
	 */
	protected String[] getG6InsertSeqMethodNames() {
		return METHOD_G6_INS_SEQ;
	}

	/**
	 * リフレクションで呼び出すG6登録ユーザーIDのメソッドパターンを返却します。
	 * クラス規定のメソッドパターンで足りない場合にはOverrideしてメソッドパターンを追加してください。
	 * @return
	 */
	protected String[] getG6InsertUidMethodNames() {
		return METHOD_G6_INS_UID;
	}

	/**
	 * リフレクションで呼び出すG6登録日時のメソッドパターンを返却します。
	 * クラス規定のメソッドパターンで足りない場合にはOverrideしてメソッドパターンを追加してください。
	 * @return
	 */
	protected String[] getG6InsertTsMethodNames() {
		return METHOD_G6_INS_DATE;
	}

	/**
	 * リフレクションで呼び出すG6更新ユーザー論理番号のメソッドパターンを返却します。
	 * クラス規定のメソッドパターンで足りない場合にはOverrideしてメソッドパターンを追加してください。
	 * @return
	 */
	protected String[] getG6UpdateSeqMethodNames() {
		return METHOD_G6_UPD_SEQ;
	}

	/**
	 * リフレクションで呼び出すG6更新ユーザーIDのメソッドパターンを返却します。
	 * クラス規定のメソッドパターンで足りない場合にはOverrideしてメソッドパターンを追加してください。
	 * @return
	 */
	protected String[] getG6UpdateUidMethodNames() {
		return METHOD_G6_UPD_UID;
	}

	/**
	 * リフレクションで呼び出すG6更新日時のメソッドパターンを返却します。
	 * クラス規定のメソッドパターンで足りない場合にはOverrideしてメソッドパターンを追加してください。
	 * @return
	 */
	protected String[] getG6UpdateTsMethodNames() {
		return METHOD_G6_UPD_DATE;
	}

	// ------------------------------------------------

	/**
	 * リフレクションで呼び出すG5登録ユーザー論理番号のメソッドパターンを返却します。
	 * クラス規定のメソッドパターンで足りない場合にはOverrideしてメソッドパターンを追加してください。
	 * @return
	 */
	protected String[] getG5InsertSeqMethodNames() {
		return METHOD_G5_INS_SEQ;
	}

	/**
	 * リフレクションで呼び出すG5登録ユーザーIDのメソッドパターンを返却します。
	 * クラス規定のメソッドパターンで足りない場合にはOverrideしてメソッドパターンを追加してください。
	 * @return
	 */
	protected String[] getG5InsertUidMethodNames() {
		return METHOD_G5_INS_UID;
	}

	/**
	 * リフレクションで呼び出すG5登録日時のメソッドパターンを返却します。
	 * クラス規定のメソッドパターンで足りない場合にはOverrideしてメソッドパターンを追加してください。
	 * @return
	 */
	protected String[] getG5InsertTsMethodNames() {
		return METHOD_G5_INS_DATE;
	}

	/**
	 * リフレクションで呼び出すG5更新ユーザー論理番号のメソッドパターンを返却します。
	 * クラス規定のメソッドパターンで足りない場合にはOverrideしてメソッドパターンを追加してください。
	 * @return
	 */
	protected String[] getG5UpdateSeqMethodNames() {
		return METHOD_G5_UPD_SEQ;
	}

	/**
	 * リフレクションで呼び出すG5更新ユーザーIDのメソッドパターンを返却します。
	 * クラス規定のメソッドパターンで足りない場合にはOverrideしてメソッドパターンを追加してください。
	 * @return
	 */
	protected String[] getG5UpdateUidMethodNames() {
		return METHOD_G5_UPD_UID;
	}

	/**
	 * リフレクションで呼び出すG5更新日時のメソッドパターンを返却します。
	 * クラス規定のメソッドパターンで足りない場合にはOverrideしてメソッドパターンを追加してください。
	 * @return
	 */
	protected String[] getG5UpdateTsMethodNames() {
		return METHOD_G5_UPD_DATE;
	}

	// ------------------------------------------------

	/**
	 * リフレクションで呼び出すGHS登録ユーザー論理番号のメソッドパターンを返却します。
	 * クラス規定のメソッドパターンで足りない場合にはOverrideしてメソッドパターンを追加してください。
	 * @return
	 */
	protected String[] getGhsInsertSeqMethodNames() {
		return METHOD_GHS_INS_SEQ;
	}

	/**
	 * リフレクションで呼び出すGHS登録ユーザーIDのメソッドパターンを返却します。
	 * クラス規定のメソッドパターンで足りない場合にはOverrideしてメソッドパターンを追加してください。
	 * @return
	 */
	protected String[] getGhsInsertUidMethodNames() {
		return METHOD_GHS_INS_UID;
	}

	/**
	 * リフレクションで呼び出すGHS登録日時のメソッドパターンを返却します。
	 * クラス規定のメソッドパターンで足りない場合にはOverrideしてメソッドパターンを追加してください。
	 * @return
	 */
	protected String[] getGhsInsertTsMethodNames() {
		return METHOD_GHS_INS_DATE;
	}

	/**
	 * リフレクションで呼び出すGHS更新ユーザー論理番号のメソッドパターンを返却します。
	 * クラス規定のメソッドパターンで足りない場合にはOverrideしてメソッドパターンを追加してください。
	 * @return
	 */
	protected String[] getGhsUpdateSeqMethodNames() {
		return METHOD_GHS_UPD_SEQ;
	}

	/**
	 * リフレクションで呼び出すGHS更新ユーザーIDのメソッドパターンを返却します。
	 * クラス規定のメソッドパターンで足りない場合にはOverrideしてメソッドパターンを追加してください。
	 * @return
	 */
	protected String[] getGhsUpdateUidMethodNames() {
		return METHOD_GHS_UPD_UID;
	}

	/**
	 * リフレクションで呼び出すGHS更新日時のメソッドパターンを返却します。
	 * クラス規定のメソッドパターンで足りない場合にはOverrideしてメソッドパターンを追加してください。
	 * @return
	 */
	protected String[] getGhsUpdateTsMethodNames() {
		return METHOD_GHS_UPD_DATE;
	}

}
