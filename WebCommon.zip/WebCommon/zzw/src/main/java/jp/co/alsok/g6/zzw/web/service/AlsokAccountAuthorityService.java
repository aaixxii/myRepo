package jp.co.alsok.g6.zzw.web.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.alsok.g6.zzw.web.constants.CommonComponentConstants.ALSOK_AUTHORITY;
import jp.co.alsok.g6.zzw.web.constants.CommonComponentConstants.PERMISSION_SZWO;
import jp.co.alsok.g6.zzw.web.repository.g6.AcntAlsokInfoRepository;

/**
 * ALSOKアカウント権限関連共通関数
 * @author SNG
 *
 */
@Service
public class AlsokAccountAuthorityService {

	@Autowired
	private AcntAlsokInfoRepository commonAcntAlsokInfoRepository;

	/**
	 * 権限による画面毎の制御を定義します。</br>
	 *</br>
	 * 定義 ：</br>
	 *  要素名(画面ID,
	 *   制御1(権限=101), 制御2(権限=102), 制御3(権限=103),
	 *   制御4(権限=104), 制御5(権限=106), 制御6(権限=107))</br>
	 * ※制御1～6はALSOK権限毎の制御を示す。</br>
	 *</br>
	 * ALSOK権限種類  :</br>
	 *  監視							= 101</br>
 	 *  運用管理（マスタメンテナンス） 	= 102</br>
 	 *  運用管理（運用情報）			= 103</br>
 	 *  運用管理（ユーザメンテナンス）	= 104</br>
 	 *  ALSOKお知らせ					= 106</br>
 	 *  システムメンテナンス			= 107</br>
 	 *</br>
 	 * 制御 ：</br>
 	 *  0(〇) = 閲覧・変更可, 1(▲) = 閲覧可・変更不可 ,2(×) = 閲覧不可・変更不可</br>
 	 *
	 * @author SNG
	 *
	 */
	public static enum SZWOControlAuthority {

		// 画面毎ALSOK権限					：101, 102, 103, 104, 106, 107
		// 共通								： ○, ○, ○, ○, ○, ○
		/** ログイン画面 */
		SZWO0000("SZWO0000", 0, 0, 0, 0, 0, 0),

		/** メニュー画面 */
		SZWO0100("SZWO0100", 0, 0, 0, 0, 0, 0),

		// 契約先検索						： ×, ○, ○, ×, ×, ×
		/** 契約先マスタ作成画面 */
		SZWO1800("SZWO1800", 2, 0, 0, 2, 2, 2),

		/** 契約先-特約作成画面 */
		SZWO1900("SZWO1900", 2, 0, 0, 2, 2, 2),

		/** 契約先情報削除確認画面 */
		SZWO210C("SZWO210C", 2, 0, 0, 2, 2, 2),

		/** 契約先コード一覧画面 */
		SZWOA600("SZWOA600", 2, 0, 0, 2, 2, 2),

		/** 住所コード一覧画面 */
		SZWOA700("SZWOA700", 2, 0, 0, 2, 2, 2),

		/** 郵便番号検索結果画面 */
		SZWO2900("SZWO2900", 2, 0, 0, 2, 2, 2),

		/** 契約先検索画面 */
		SZWO9500("SZWO9500", 2, 0, 0, 2, 2, 2),

		// 警備先情報						： ×, ○, ○, ×, ×, ×
		/** 警備先情報メニュー画面 */
		SZWO9B00("SZWO9B00", 2, 0, 0, 2, 2, 2),

		/** ＦＷバージョン確認画面 */
		SZWOF300("SZWOF300", 2, 0, 0, 2, 2, 2),

		/** 警備・地区マスタ作成画面 */
		SZWO0400("SZWO0400", 2, 0, 0, 2, 2, 2),

		/** 警備先一覧画面（警備先情報） */
		SZWO1700("SZWO1700", 2, 0, 0, 2, 2, 2),

		/** 警備セット忘れ通知／空室設定画面 */
		SZWO1600("SZWO1600", 2, 0, 0, 2, 2, 2),

		/** 地区詳細設定画面 */
		SZWOC000("SZWOC000", 2, 0, 0, 2, 2, 2),

		/** 警備先検索画面 */
		SZWO3700("SZWO3700", 2, 0, 0, 2, 2, 2),

		/** 業種コード一覧画面 */
		SZWO4000("SZWO4000", 2, 0, 0, 2, 2, 2),

		/** 任務区分一覧画面 */
		SZWO5100("SZWO5100", 2, 0, 0, 2, 2, 2),

		/** 信号履歴情報表示画面 */
		SZWO2600("SZWO2600", 2, 0, 0, 2, 2, 2),

		/** 前後画像画面 */
		SZWO2610("SZWO2610", 2, 0, 0, 2, 2, 2),

		/** 多重配信設定画面 */
		SZWO8800("SZWO8800", 2, 0, 0, 2, 2, 2),

		/** 緊急連絡先編集画面 */
		SZWO4800("SZWO4800", 2, 0, 0, 2, 2, 2),

		/** 機器-回線情報画面 */
		SZWO0200("SZWO0200", 2, 0, 0, 2, 2, 2),

		/** 物件-工事情報画面 */
		SZWO0300("SZWO0300", 2, 0, 0, 2, 2, 2),

		/** 地区-住所作成画面 */
		SZWO1300("SZWO1300", 2, 0, 0, 2, 2, 2),

		/** 警備先-定休日設定画面 */
		SZWO0500("SZWO0500", 2, 0, 0, 2, 2, 2),

		/** 警備先-図面マスタ作成画面 */
		SZWO0800("SZWO0800", 2, 0, 0, 2, 2, 2),

		/** 巡回警備先一覧画面 */
		SZWOB200("SZWOB200", 2, 0, 0, 2, 2, 2),

		/** 巡回カメラ一覧画面 */
		SZWOB300("SZWOB300", 2, 0, 0, 2, 2, 2),

		/** ユーザーWebオプション設定画面 */
		SZWO0700("SZWO0700", 2, 0, 0, 2, 2, 2),

		// 警備先情報						： ×, ▲, ○, ×, ×, ×
		/** 地区-警報任務区分設定画面 */
		SZWO1100("SZWO1100", 2, 1, 0, 2, 2, 2),

		/** 地区-監視条件設定画面 */
		SZWO1500("SZWO1500", 2, 1, 0, 2, 2, 2),

		/** 地区-特約設定画面 */
		SZWO1400("SZWO1400", 2, 1, 0, 2, 2, 2),

		// 営業連携							： ×, ○, ○, ×, ×, ×
		/** 回路区分一覧画面 */
		SZWO4900("SZWO4900", 2, 0, 0, 2, 2, 2),

		/** 営業連携検索画面 */
		SZWO8600("SZWO8600", 2, 0, 0, 2, 2, 2),

		/** 営業連携編集画面 */
		SZWO2300("SZWO2300", 2, 0, 0, 2, 2, 2),

		// 地区特約マスタ					： ×, ▲, ○, ×, ×, ×
		/** 警備先地区特約マスタ作成画面 */
		SZWO3200("SZWO3200", 2, 1, 0, 2, 2, 2),

		// アカウント関連設定（お客様）		： ×, ○, ○, 〇, ×, ×
		/** アカウント関連設定メニュー画面 */
		SZWO9000("SZWO9000", 2, 0, 0, 0, 2, 2),

		/** 契約先ユーザマスタ画面 */
		SZWO4100("SZWO4100", 2, 0, 0, 2, 2, 2),

		/** 契約先-ユーザマスタ作成画面 */
		SZWO4200("SZWO4200", 2, 0, 0, 2, 2, 2),

		/** 契約先ユーザーメール受信設定画面 */
		SZWO4300("SZWO4300", 2, 0, 0, 2, 2, 2),

		/** ユーザマスタ更新画面 */
		SZWO4400("SZWO4400", 2, 0, 0, 2, 2, 2),

		/** 閲覧地区設定画面 */
		SZWO4500("SZWO4500", 2, 0, 0, 2, 2, 2),

		// アカウント関連設定（社員）		： ×, ×, ×, ○, ×, ×
		/** 社員アカウント一覧画面 */
		SZWO9800("SZWO9800", 2, 2, 2, 0, 2, 2),

		/** ALSOKアカウント編集画面 */
		SZWO9900("SZWO9900", 2, 2, 2, 0, 2, 2),

		/** ALSOKアカウント編集確認画面 */
		SZWOA00C("SZWOA00C", 2, 2, 2, 0, 2, 2),

		/** ALSOKアカウント編集完了画面 */
		SZWOA10D("SZWOA10D", 2, 2, 2, 0, 2, 2),

		/** 隊員アカウント編集画面 */
		SZWOB500("SZWOB500", 2, 2, 2, 0, 2, 2),

		/** 隊員アカウント編集確認画面 */
		SZWOB600("SZWOB600", 2, 2, 2, 0, 2, 2),

		/** 隊員アカウント編集完了画面 */
		SZWOB700("SZWOB700", 2, 2, 2, 0, 2, 2),

		// 機器状態確認						： ×, ○, ○, ×, ×, ×
		/** 機器状態確認メニュー画面 */
		SZWO9100("SZWO9100", 2, 0, 0, 2, 2, 2),

		/** 回線接続状態一覧画面 */
		SZWO6600("SZWO6600", 2, 0, 0, 2, 2, 2),

		/** シャント警備先検索画面(警備先検索) */
		SZWO7300("SZWO7300", 2, 0, 0, 2, 2, 2),

		/** シャント警備先検索画面(住戸検索) */
		SZWO6210("SZWO6210", 2, 0, 0, 2, 2, 2),

		/** 操作種別画面（シャント） */
		SZWO2500("SZWO2500", 2, 0, 0, 2, 2, 2),

		/** 操作種別画面（電気錠制御） */
		SZWO2700("SZWO2700", 2, 0, 0, 2, 2, 2),

		/** 遠隔点検画面 */
		SZWO9400("SZWO9400", 2, 0, 0, 2, 2, 2),

		/** 遠隔点検情報画面 */
		SZWO9600("SZWO9600", 2, 0, 0, 2, 2, 2),

		/** 遠隔点検詳細画面 */
		SZWO2800("SZWO2800", 2, 0, 0, 2, 2, 2),

		/** 遠隔点検完了待ち画面 */
		SZWO970D("SZWO970D", 2, 0, 0, 2, 2, 2),

		/** 操作種別画面（ALSOK警備 */
		SZWO2A00("SZWO2A00", 2, 0, 0, 2, 2, 2),

		/** 操作種別画面（ALSOK警備 */
		SZWO2B00("SZWO2B00", 2, 0, 0, 2, 2, 2),

		/** 操作種別画面（装置リセット） */
		SZWO2C00("SZWO2C00", 2, 0, 0, 2, 2, 2),

		/** 操作種別画面（バッテリー劣化） */
		SZWO2D00("SZWO2D00", 2, 0, 0, 2, 2, 2),

		/** 操作種別画面（ダイレクト制御） */
		SZWO2E00("SZWO2E00", 2, 0, 0, 2, 2, 2),

		/** 操作種別画面（制御保持設定） */
		SZWO2F00("SZWO2F00", 2, 0, 0, 2, 2, 2),

		// 画像関連設定						： ×, ○, ○, ×, ×, ×
		/** 画像関連設定メニュー画面 */
		SZWO8900("SZWO8900", 2, 0, 0, 2, 2, 2),

		/** 重要犯罪者情報共有メニュー画面 */
		SZWO8300("SZWO8300", 2, 0, 0, 2, 2, 2),

		/** 契約先情報一覧画面 */
		SZWO2000("SZWO2000", 2, 0, 0, 2, 2, 2),

		/** カメラ閲覧設定画面 */
		SZWO7910("SZWO7910", 2, 0, 0, 2, 2, 2),

		/** 重要犯罪者画像登録画面 */
		SZWOD200("SZWOD200", 2, 0, 0, 2, 2, 2),

		/** 重要犯罪者登録済み画像一覧画面 */
		SZWOD400("SZWOD400", 2, 0, 0, 2, 2, 2),

		/** 一括送信先装置選択画面 */
		SZWOD700("SZWOD700", 2, 0, 0, 2, 2, 2),

		/** 装置内登録状態確認画面 */
		SZWO8000("SZWO8000", 2, 0, 0, 2, 2, 2),

		/** 装置一覧画面 */
		SZWOB900("SZWOB900", 2, 0, 0, 2, 2, 2),

		/** 装置内画像一覧画面 */
		SZWOE000("SZWOE000", 2, 0, 0, 2, 2, 2),

		/** 警備先一覧画面（画像蓄積設定） */
		SZWO3800("SZWO3800", 2, 0, 0, 2, 2, 2),

		/** 蓄積画像設定画面 */
		SZWO8100("SZWO8100", 2, 0, 0, 2, 2, 2),

		/** 画像送信(装置指定)画面 */
		SZWO8400("SZWO8400", 2, 0, 0, 2, 2, 2),

		/** 登録済み画像選択画面 */
		SZWO8500("SZWO8500", 2, 0, 0, 2, 2, 2),

		/** 内部統制・外部警戒提供機能設定画面 */
		SZWO2400("SZWO2400", 2, 0, 0, 2, 2, 2),

		/** 地域選択画面 */
		SZWOB800("SZWOB800", 2, 0, 0, 2, 2, 2),

		// 各種履歴							： ×, ○, ○, ×, ×, ×
		/** 各種履歴メニュー画面 */
		SZWO9A00("SZWO9A00", 2, 0, 0, 2, 2, 2),

		/** マスタメンテナンス履歴画面 */
		SZWO6300("SZWO6300", 2, 0, 0, 2, 2, 2),

		/** メール送信履歴画面 */
		SZWO3500("SZWO3500", 2, 0, 0, 2, 2, 2),

		/** Ｗｅｂ操作履歴情報検索画面 */
		SZWO7200("SZWO7200", 2, 0, 0, 2, 2, 2),

		/** Ｗｅｂ操作履歴情報検索画面（警備先検索） */
		SZWO6100("SZWO6100", 2, 0, 0, 2, 2, 2),

		// ユーティリティ					： ×, ○, ○, ×, ×, ×
		/** ユーティリティメニュー画面 */
		SZWOB000("SZWOB000", 2, 0, 0, 2, 2, 2),

		/** お客様番号変更画面 */
		SZWO6400("SZWO6400", 2, 0, 0, 2, 2, 2),

		/** お客様番号変更履歴画面 */
		SZWO6500("SZWO6500", 2, 0, 0, 2, 2, 2),

		/** VPN管理画面 */
		SZWO8700("SZWO8700", 2, 0, 0, 2, 2, 2),

		/** IP詳細画面 */
		SZWO8710("SZWO8710", 2, 0, 0, 2, 2, 2),

		// システムメンテナンス				： ×, ×, ×, ×, ×, ○
		/** システムメンテナンスメニュー画面 */
		SZWOA800("SZWOA800", 2, 2, 2, 2, 2, 0),

		/** 真報マスタメニュー画面 */
		SZWO9200("SZWO9200", 2, 2, 2, 2, 2, 0),

		/** 機器種別一覧画面 */
		SZWO7400("SZWO7400", 2, 2, 2, 2, 2, 0),

		/** 外部情報通知メンテ画面 */
		SZWO3400("SZWO3400", 2, 2, 2, 2, 2, 0),

		/** 機器種別コマンドマスタ作成画面 */
		SZWOC100("SZWOC100", 2, 2, 2, 2, 2, 0),

		/** 真報判断補助メッセージマスタ作成画面 */
		SZWO5000("SZWO5000", 2, 2, 2, 2, 2, 0),

		/** 真報判断補助メッセージコードファイルメンテ画面 */
		SZWOC200("SZWOC200", 2, 2, 2, 2, 2, 0),

		/** システムパラメータ画面 */
		SZWOC300("SZWOC300", 2, 2, 2, 2, 2, 0),

		/** 祝日マスタ作成画面 */
		SZWO5300("SZWO5300", 2, 2, 2, 2, 2, 0),

		/** エクスポート画面 */
		SZWO6200("SZWO6200", 2, 2, 2, 2, 2, 0),

		// コードメンテナンス				： ×, ×, ×, ×, ×, ○
		/** コードメンテナンスメニュー画面 */
		SZWOA900("SZWOA900", 2, 2, 2, 2, 2, 0),

		/** 回路区分コードメンテ画面 */
		SZWO5400("SZWO5400", 2, 2, 2, 2, 2, 0),

		/** 任務区分コードメンテ画面 */
		SZWO5500("SZWO5500", 2, 2, 2, 2, 2, 0),

		/** 判断理由コードメンテ画面 */
		SZWO5600("SZWO5600", 2, 2, 2, 2, 2, 0),

		/** 原因コードメンテ画面 */
		SZWO5700("SZWO5700", 2, 2, 2, 2, 2, 0),

		/** エリアコードメンテ画面 */
		SZWO5800("SZWO5800", 2, 2, 2, 2, 2, 0),

		/** 事業所マスタ作成画面 */
		SZWO5900("SZWO5900", 2, 2, 2, 2, 2, 0),

		/** 事業所コード一覧画面 */
		SZWO3000("SZWO3000", 0, 0, 0, 0, 0, 0),

		/** 担当GC一覧画面 */
		SZWO3100("SZWO3100", 2, 2, 2, 2, 2, 0),

		/** 画面登録区分マスタ作成画面 */
		SZWO6000("SZWO6000", 2, 2, 2, 2, 2, 0),

		/** 信号種別一覧画面 */
		SZWO7500("SZWO7500", 2, 2, 2, 2, 2, 0),

		/** エリアコード一覧画面 */
		SZWO3600("SZWO3600", 2, 2, 2, 2, 2, 0),

		/** 信号種別マスタ画面 */
		SZWO6110("SZWOC400", 2, 2, 2, 2, 2, 0),

		/** 信号区分一覧画面 */
		SZWO7700("SZWO7700", 2, 2, 2, 2, 2, 0),

		// お知らせ作成						： ×, ×, ×, ×, ○, ×
		/** お知らせ一覧画面 */
		SZWO6700("SZWO6700", 2, 2, 2, 2, 0, 2),

		/** お知らせ送信エラー画面 */
		SZWO6710("SZWO6710", 2, 2, 2, 2, 0, 2),

		/** お知らせ内容詳細画面 */
		SZWO6800("SZWO6800", 2, 2, 2, 2, 0, 2),

		/** お知らせ内容登録画面 */
		SZWO6900("SZWO6900", 2, 2, 2, 2, 0, 2),

		/** お知らせ内容登録確認画面 */
		SZWO700C("SZWO700C", 2, 2, 2, 2, 0, 2),

		/** お知らせ内容登録完了画面 */
		SZWO710D("SZWO710D", 2, 2, 2, 2, 0, 2),

		// ログインID変更/パスワード変更	： ○, ○, ○, ○, ○, ○
		/** ログインＩＤ変更画面 */
		SZWOA200("SZWOA200", 0, 0, 0, 0, 0, 0),

		/** ログインＩＤ変更完了画面 */
		SZWOA30D("SZWOA30D", 0, 0, 0, 0, 0, 0),

		/** パスワード変更画面 */
		SZWOA400("SZWOA400", 0, 0, 0, 0, 0, 0),

		/** パスワード変更完了画面 */
		SZWOA50D("SZWOA50D", 0, 0, 0, 0, 0, 0),

		// TODO：不明						： ○, ○, ○, ○, ○, ○
		/** 警備先一覧画面（機器設定） */
		SZWO3900("SZWO3900", 0, 0, 0, 0, 0, 0),

		/** Fw更新確認画面 */
		SZWOB400("SZWOB400", 0, 0, 0, 0, 0, 0),

		/** 物件一覧画面 */
		SZWO7800("SZWO7800", 0, 0, 0, 0, 0, 0),
		;
		/** 画面ID */
		private String screenId;
		/** 権限：監視 */
		private int monitoringAuth;
		/** 権限：運用管理（マスタメンテナンス） */
		private int masterMngMntAuth;
		/** 権限：運用管理（運用情報） */
		private int operatMngMntAuth;
		/** 権限：運用管理（ユーザメンテナンス） */
		private int userMngMntAuth;
		/** 権限：ALSOKお知らせ */
		private int alsokNoticeAuth;
		/** 権限：システムメンテナンス */
		private int systemMntAuth;

		private SZWOControlAuthority(String screenId
								, int monitoringAuth  , int masterMngMntAuth
								, int operatMngMntAuth, int userMngMntAuth
								, int alsokNoticeAuth , int systemMntAuth) {
			this.screenId         = screenId;
			this.monitoringAuth   = monitoringAuth;
			this.masterMngMntAuth = masterMngMntAuth;
			this.operatMngMntAuth = operatMngMntAuth;
			this.userMngMntAuth   = userMngMntAuth;
			this.alsokNoticeAuth  = alsokNoticeAuth;
			this.systemMntAuth    = systemMntAuth;
		}

		/**
		 * 画面IDを返却する。
		 *
		 * @return 画面ID
		 */
		public String getScreenId() {
			return this.screenId;
		}

		/**
		 * 監視の画面制御権限を返却する。
		 *
		 * @return 監視画面制御権限
		 */
		public int getMonitoringAuth() {
			return this.monitoringAuth;
		}
		/**
		 * 運用管理（マスタメンテナンス）の画面制御権限を返却する。
		 *
		 * @return 運用管理（マスタメンテナンス）画面制御権限
		 */
		public int getMasterMngMntAuth() {
			return this.masterMngMntAuth;
		}
		/**
		 * 運用管理（運用情報）の画面制御権限を返却する。
		 *
		 * @return 運用管理（運用情報）画面制御権限
		 */
		public int getOperatMngMntAuth() {
			return this.operatMngMntAuth;
		}
		/**
		 * 運用管理（ユーザメンテナンス）の画面制御権限を返却する。
		 *
		 * @return 運用管理（ユーザメンテナンス）画面制御権限
		 */
		public int getUserMngMntAuth() {
			return this.userMngMntAuth;
		}
		/**
		 * ALSOKお知らせの画面制御権限を返却する。
		 *
		 * @return ALSOKお知らせ画面制御権限
		 */
		public int getAlsokNoticeAuth() {
			return this.alsokNoticeAuth;
		}
		/**
		 * システムメンテナンスの画面制御権限を返却する。
		 *
		 * @return システムメンテナンス画面制御権限
		 */
		public int systemMntAuth() {
			return this.systemMntAuth;
		}
		/**
		 * 画面IDに対応したcontrolAuthority要素を返却する。
		 *
		 * @return controlAuthority要素
		 */
		public static SZWOControlAuthority getCntrlAuth(String screenId) {
			return Arrays.stream(SZWOControlAuthority.values())
					.filter(predicate -> predicate.getScreenId()
							.equals(screenId)).findFirst().orElse(null);
		}
	}

	/**
	 * 運用管理サイトの画面IDとLN_ALSOKアカウント論理番号を基に、<br/>
	 * 画面閲覧・変更可否を判定する。<br/>
	 * <br/>
	 * 画面IDがSZWOControlAuthorityに定義されていない場合、0（画面閲覧・変更可）<br/>
	 * アカウントからALSOK権限が取得できない場合、2（画面閲覧・変更不可）を返す。
	 *
	 * @param lnAcntAlsok LN_ALSOKアカウント論理番号
	 * @param screenId 画面ID
	 * @return 画面閲覧・変更可:0, 画面閲覧可・変更不可:1, 画面閲覧・変更不可:2,
	 */
	public int findPermissionSZWOByAccountId(String lnAcntAlsok, String screenId) {
		// 引数が空、またはnullの場合、編集・閲覧不可（2）を返却する。
		if(lnAcntAlsok == null || lnAcntAlsok.length() == 0 ||
				screenId == null || screenId.length() == 0) {
			return PERMISSION_SZWO.NONE.getPermission();
		}

		// LN_ALSOKアカウント論理番号に紐づく権限リストを取得する。
		// 権限が存在しない場合、編集・閲覧不可（2）を返却する。
		List<String> authList = findAuthorityByAccountId(lnAcntAlsok);
		if(authList.size() == 0) {
			return PERMISSION_SZWO.NONE.getPermission();
		}

		// 画面IDを基に画面制御情報を取得する。
		// 制御対象外の画面IDだった場合、編集・閲覧可（0）を返却する。
		SZWOControlAuthority target = SZWOControlAuthority.getCntrlAuth(screenId);
		if(target == null) {
			return PERMISSION_SZWO.EDIT.getPermission();
		}

		// 制御権限を取得する。複数の権限が設定されている場合、強い方を優先する。
		int parm = PERMISSION_SZWO.NONE.getPermission();
		int buf = PERMISSION_SZWO.NONE.getPermission();
		for(String auth : authList) {
			// 監視権限が設定されている場合
			if(ALSOK_AUTHORITY.MONITORING.getAuthority().equals(auth)) {
				buf = target.getMonitoringAuth();
			// 運用管理（マスタメンテナンス）が設定されている場合
			} else if(ALSOK_AUTHORITY.MASTER_MNT.getAuthority().equals(auth)) {
				buf = target.getMasterMngMntAuth();
			// 運用管理（運用情報） 権限が設定されている場合
			} else if(ALSOK_AUTHORITY.OPERAT_MNG.getAuthority().equals(auth)) {
				buf = target.getOperatMngMntAuth();
			// 運用管理（ユーザメンテナンス）が設定されている場合
			} else if(ALSOK_AUTHORITY.USER_MNT.getAuthority().equals(auth)) {
				buf = target.getUserMngMntAuth();
			// ALSOKお知らせが設定されている場合
			} else if(ALSOK_AUTHORITY.ALSOK_NOTICE.getAuthority().equals(auth)) {
				buf = target.getAlsokNoticeAuth();
			// システムメンテナンスが設定されている場合
			} else if(ALSOK_AUTHORITY.SYS_MNT.getAuthority().equals(auth)) {
				buf = target.systemMntAuth();
			}
			// より強い制御権限を保持する。
			parm = (parm > buf) ? buf : parm;
		}
		return parm;
	}

	/**
	 * LN_ALSOKアカウント論理番号を基に、権限のリストを返す。
	 *
	 * @param lnAcntAlsok LN_ALSOKアカウント論理番号
	 * @return 権限IDのリスト
	 */
	public List<String> findAuthorityByAccountId(String lnAcntAlsok) {

		// LN_ALSOKアカウント論理番号がnull、または空の場合、nullを返却する。
		if(lnAcntAlsok == null || lnAcntAlsok.length() == 0) {
			return null;
		}
		return commonAcntAlsokInfoRepository.selectAuthorityByLnAcntAlsok(lnAcntAlsok);
	}
}
