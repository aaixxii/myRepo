package jp.co.alsok.g6.zzw.web.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import jp.co.alsok.g6.zzw.web.constants.DbAccessConstants.ACNT_KIND;
import jp.co.alsok.g6.zzw.web.constants.DbAccessConstants.LOGIN_SYS_FLG;
import jp.co.alsok.g6.zzw.web.dto.KeiyakuUserInfoDto;

/**
 * [利用者アカウント]
 *
 * 時期,G5,GHSのアカウント論理番号、アカウント名、社員番号取得Service
 */
@Service
public class UserLoginUtilityService {

	/** 利用者情報取得 Service*/
	@Autowired
	UserAccountInfoService userAccountInfoService;

	/**
	 * 利用者アカウント論理番号を基にG6,G5,GHSのアカウント情報を取得し、
	 * KeiyakuUserInfoDtoで返却します。
	 *
	 * ■ 引数loginSysFlgでログインしたシステムを判定します。
	 *  LOGIN_SYS_FLG.SYS_G6  = 次期でログインの場合
	 *  LOGIN_SYS_FLG.SYS_GHS = GHSでログインの場合
	 *  LOGIN_SYS_FLG.SYS_G5  = G5でログインの場合
	 *
	 * ■ 引数systemFlgで取得対象のDBを限定します。
	 * systemFlg = '0' (DbAccessConstants.CONNECT_DB_G6_G5_GHS)
	 *             G6, G5, GHS のアカウント情報を取得します。
	 * systemFlg = '1' (DbAccessConstants.CONNECT_DB_G6_GHS)
	 *             G6, GHS のアカウント情報を取得します。
	 * systemFlg = '2' (DbAccessConstants.CONNECT_DB_G6_G5)
	 *             G6, G5 のアカウント情報を取得します。
	 *
	 * @param loginSysFlg ログインシステムフラグ
	 * @param lnAcntUserCommon LN_利用者アカウント共通論理番号
	 * @return KeiyakuUserInfoDto 利用者アカウント情報Dto
	 */
	@Transactional(propagation = Propagation.REQUIRED)
	public KeiyakuUserInfoDto getUsetAccountInfo(LOGIN_SYS_FLG loginSysFlg, String lnAcntUserCommon) {
		// 返却値
		KeiyakuUserInfoDto keiyakuUserInfoDto = new KeiyakuUserInfoDto();

		// ■ G6でのログインの場合
		// G6 -> G5 -> GHSの順で紐付ける
		if (loginSysFlg == LOGIN_SYS_FLG.SYS_G6) {
			// G6のアカウント情報を取得
			userAccountInfoService.getG6UserInfo(loginSysFlg, lnAcntUserCommon, keiyakuUserInfoDto,
					ACNT_KIND.G6_ACNT_KIND);
			// G5のアカウント情報を取得
			userAccountInfoService.getG5UserInfo(loginSysFlg, lnAcntUserCommon, keiyakuUserInfoDto,
					ACNT_KIND.G5_ACNT_KIND);
			// GHSのアカウント情報を取得
			userAccountInfoService.getGhsUserInfo(loginSysFlg, lnAcntUserCommon, keiyakuUserInfoDto,
					ACNT_KIND.GHS_USER_ACNT_KIND);

		}
		// ■ G5でのログインの場合
		// G5 -> G6 -> GHSの順で紐付ける
		else if (loginSysFlg == LOGIN_SYS_FLG.SYS_G5) {
			// G5のアカウント情報を取得
			userAccountInfoService.getG5UserInfo(loginSysFlg, lnAcntUserCommon, keiyakuUserInfoDto,
					ACNT_KIND.G5_ACNT_KIND);
			// G6のアカウント情報を取得
			userAccountInfoService.getG6UserInfo(loginSysFlg, lnAcntUserCommon, keiyakuUserInfoDto,
					ACNT_KIND.G6_ACNT_KIND);
			// GHSのアカウント情報を取得
			userAccountInfoService.getGhsUserInfo(loginSysFlg, lnAcntUserCommon, keiyakuUserInfoDto,
					ACNT_KIND.GHS_USER_ACNT_KIND);

		} else {
			// ■ GHSでのログインの場合
			// GHS -> G6 -> G5の順で紐付ける
			// GHSのアカウント情報を取得
			userAccountInfoService.getGhsUserInfo(loginSysFlg, lnAcntUserCommon, keiyakuUserInfoDto,
					ACNT_KIND.GHS_USER_ACNT_KIND);
			// G6のアカウント情報を取得
			userAccountInfoService.getG6UserInfo(loginSysFlg, lnAcntUserCommon, keiyakuUserInfoDto,
					ACNT_KIND.G6_ACNT_KIND);
			// G5のアカウント情報を取得
			userAccountInfoService.getG5UserInfo(loginSysFlg, lnAcntUserCommon, keiyakuUserInfoDto,
					ACNT_KIND.G5_ACNT_KIND);
		}

		return keiyakuUserInfoDto;
	}


}
