package jp.co.alsok.g6.zzw.util.db;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import javax.sql.DataSource;
import org.apache.commons.dbcp.BasicDataSource;
import jp.co.alsok.g6.common.util.file.PropertyXmlReader;

/**
 * G5DB論理番号取得用ユーティリティクラス
 *
 * @author NEC
 */
public class DbUtilityG5 {

    /** DBタイプ_ORACLE */
    private final static String DB_TYPE_ORACLE = "1";

    /** DBタイプ_MYSQL */
    private final static String DB_TYPE_MYSQL = "2";

    /** DBタイプ_MYSQL */
    private final static String DB_TYPE_POSTGRES = "3";

    /** 接続タイプ_ローカル接続 */
    private final static String ENVIRONMENT_TYPE_LOCALAP = "3";

    /** コネクション */
    private Connection conn;

    /** シーケンス用コネクション */
    private Connection seqConn;

    /** データソース */
    private DataSource ds;

    /** コマンドシーケンス番号 */
    private final static String CMD_SEQ_NUM = "CMD_SEQ_NUM";

    /** トランザクションシーケンス番号 */
    private final static String TRAN_SEQ_NUM = "TRAN_SEQ_NUM";

    /** データベースの接続プロパティファイル */
    private final static String PROPERTY_FILE_DATABASE = "DbPropApG5";

    /** プロパティファイルリーダ */
    private PropertyXmlReader propertyReader = null;

    /** データタイプ */
    private String dbType;

    /** ドライバクラス名 */
    private String driverClassName;

    /** サーバ名 */
    private String server;

    /** ポート番号 */
    private String port;

    /** DB名 */
    private String dbname;

    /** ユーザ */
    private String user;

    /** パスワード */
    private String password;

    /** スキーマ */
    private String schema;

    /** 接続先ファイル名 */
    private String propertyFile;

    // 定数
    /** 警備信号論理番号用シーケンス番号名 */
    private final String LN_QUE_KB_SIG_SEQ_NAME = "LN_KEIBI_SIG";

    /** ストアド「GET_SEQUENCE」 */
    private final String GET_SEQUENCE = "{call GET_SEQUENCE(?, ?)}";

    /**
     * コンストラクタ<br>
     * 引数がない場合、初期化時にデフォルトの接続先に接続する<br>
     *
     * @throws Exception
     * @throws IOException
     * @throws UnsupportedEncodingException
     * @throws FileNotFoundException
     */
    public DbUtilityG5() throws FileNotFoundException, UnsupportedEncodingException, IOException, Exception {
        this.setPropertyFile(PROPERTY_FILE_DATABASE);
        this.connect();
    }

    /**
     * コンストラクタ<br>
     * 引数がある場合、初期化時に引数で渡された接続先情報に接続する<br>
     *
     * @param propertyFile 接続先プロパティファイル名
     * @throws Exception
     * @throws IOException
     * @throws UnsupportedEncodingException
     * @throws FileNotFoundException
     */
    public DbUtilityG5(String propertyFile)
            throws FileNotFoundException, UnsupportedEncodingException, IOException, Exception {
        this.setPropertyFile(propertyFile);
        this.connect();
    }

    /**
     * コネクションを取得する<br>
     *
     * @return Connection
     */
    public Connection getConnection() {
        return getConn();
    }

    /**
     * DBに接続する<br>
     *
     * @return Connection
     * @throws Exception
     * @throws IOException
     * @throws UnsupportedEncodingException
     * @throws FileNotFoundException
     */
    public Connection connect() throws FileNotFoundException, UnsupportedEncodingException, IOException, Exception {

        //プロパティファイル読み込みを実行
        getPropertyXmlReader();
        final String environmentType = propertyReader.getValue("ENVIRONMENT_TYPE");
        setDbType(this.propertyReader.getValue("DB_TYPE"));

        if (environmentType.equals(ENVIRONMENT_TYPE_LOCALAP)) {
            this.getLocalConnection();
        } else {

            // TODO ローカル以外のDB接続は現状不可
            //            String apServerType = this.propertyReader.getValue("AP_SERVER_TYPE");
            //            String contextString = "";
            //            if (apServerType == null || apServerType.equals("")
            //                    || apServerType.equals(AP_SERVER_TYPE_TOMCAT)) {
            //                contextString = "java:comp/env/"
            //                        + propertyReader.getValue(DbUtility.PROPERTY_KEY_CONTEXT);
            //            } else if (apServerType.equals(AP_SERVER_TYPE_WEBOTX)) {
            //                contextString = this.propertyReader.getValue(DbUtility.PROPERTY_KEY_CONTEXT);
            //            }
            //            Context context;
            //            try {
            //                context = new InitialContext();
            //                this.ds = (DataSource) context.lookup(contextString);
            //                getDbConnection();
            //            } catch (NamingException e) {
            //                if (environmentType.equals(ENVIRONMENT_TYPE_WEBAP_DEVELOP)) {
            //                    this.getLocalConnection();
            //                } else if (environmentType.equals(ENVIRONMENT_TYPE_WEBAP_RELEASE)) {
            //                    //               log.error(e.getMessage(), e);
            //                } else {
            //                    //               log.error(e.getMessage(), e);
            //                }
            //            } catch (SQLException e) {
            //                throw new KeibiSystemException(e.getMessage(), e);
            //            }

        }
        if (getConn() != null) {
            getConn().setAutoCommit(false);
        }
        //      log.debug(CLASS_NAME + "." + METHOD_NAME + ":END");
        return getConn();
    }

    /**
     * プロパティ読み込みクラスを取得する<br>
     *
     * @throws Exception
     * @throws IOException
     * @throws UnsupportedEncodingException
     * @throws FileNotFoundException
     */
    protected void getPropertyXmlReader()
            throws FileNotFoundException, UnsupportedEncodingException, IOException, Exception {
        this.propertyReader = new PropertyXmlReader(this.getPropertyFile());
    }

    /**
     * DBコネクションを取得する<br>
     *
     * @throws SQLException
     */
    protected void getDbConnection() throws SQLException {
        setConn(ds.getConnection());
    }

    /**
     * コミットする<br>
     *
     * @throws SQLException
     */
    public void commit() throws SQLException {
        if (getConn() != null && !(getConn().isClosed())) {
            getConn().commit();
        }
    }

    /**
     * ロールバックする<br>
     *
     * @throws SQLException
     */
    public void rollback() throws SQLException {
        if (getConn() != null && !(getConn().isClosed())) {
            getConn().rollback();
        }
    }

    /**
     * DBとの接続を切断する<br>
     *
     * @throws SQLException
     */
    public void close() throws SQLException {

        // シーケンス発番コネクションを切断する
        seqClose();

        // コネクションを切断する
        if (getConn() != null && !(getConn().isClosed())) {
            getConn().close();
            setConn(null);
            if (getDs() instanceof BasicDataSource) {
                ((BasicDataSource) getDs()).close();
            }
            setDs(null);
        }
    }

    /**
     * シーケンス発番用コネクションとの接続を切断する<br>
     *
     * @throws SQLException
     */
    private void seqClose() throws SQLException {
        if (getSeqConn() != null && !(getSeqConn().isClosed())) {
            getSeqConn().close();
            setSeqConn(null);
            if (getDs() instanceof BasicDataSource) {
                ((BasicDataSource) getDs()).close();
            }
            setDs(null);
        }
    }

    /**
     * ローカル接続を行う<br>
     *
     * @throws SQLException
     */
    protected void getLocalConnection() throws SQLException {
        BasicDataSource bds = new BasicDataSource();
        String connectStr = "";

        setDriverClassName(this.propertyReader.getValue("DRIVER_CLASS_NAME"));
        setServer(this.propertyReader.getValue("SERVER"));
        setPort(this.propertyReader.getValue("PORT"));
        setDbname(this.propertyReader.getValue("DB_NAME"));
        setUser(this.propertyReader.getValue("USER"));
        setPassword(this.propertyReader.getValue("PASSWORD"));
        setSchema(this.propertyReader.getValue("SCHEMA"));

        if (getDbType().equals(DB_TYPE_ORACLE)) {
            connectStr = "jdbc:oracle:thin:@" + getServer() + ":" + getPort() + ":" + getDbname();
        } else if (getDbType().equals(DB_TYPE_MYSQL)) {
            connectStr = "jdbc:mysql://" + getServer() + ":" + getPort() + "/" + getDbname();
        } else if (getDbType().equals(DB_TYPE_POSTGRES)) {
            connectStr = "jdbc:postgresql://" + getServer() + ":" + getPort() + "/" + getDbname() + "?currentSchema="
                    + getSchema();
        }
        //         log.trace("DriverClassName=" + driverClassName);
        //         log.trace("ConnectStr=" + connectStr);
        bds.setDriverClassName(getDriverClassName());
        bds.setUrl(connectStr);
        bds.setUsername(getUser());
        bds.setPassword(getPassword());
        bds.setDefaultAutoCommit(false);

        setDs(bds);

        getDbConnection();
    }

    /**
     * ストアド「GET_SEQUENCE」でテーブル「c_sequence」から、<br>
     * 引数のsequenceIdに紐付くカラム「CURRENT_VALUE」の次の値を取得する<br>
     * カラム「CURRENT_VALUE」をインクリメント後、即時コミットを行う<br>
     *
     * @param sequenceId シーケンスID
     * @return 次のSEQUENSE値
     */
    private String getSequenceImpl(String sequenceId) {
        String ret = "";

        CallableStatement callableStatement = null;
        try {

            // シーケンス用コネクションがすでにある場合は接続しない
            if (getSeqConn() == null) {
                // シーケンス用コネクションを取得
                DbUtilityG5 seqDbUtility = new DbUtilityG5();
                setSeqConn(seqDbUtility.getConnection());
            }

            // ストアド「GET_SEQUENCE」を呼び出す
            callableStatement = getSeqConn().prepareCall(GET_SEQUENCE);
            callableStatement.setString(1, sequenceId);
            callableStatement.registerOutParameter(2, Types.VARCHAR);
            // ストアド実行
            callableStatement.execute();
            ret = callableStatement.getString(2);
            // シーケンス用コネクションをコミットする
            getSeqConn().commit();

        } catch (SQLException e) {
            // シーケンス用のコネクションをロールバック、切断、初期化する
            try {
                getSeqConn().rollback();
                getSeqConn().close();
                setSeqConn(null);
                return null;
            } catch (SQLException e1) {
                // TODO 自動生成された catch ブロック
                e1.printStackTrace();
            }

            //         log.error(e.getMessage(), e);
        } catch (Exception e) {
            try {
                getSeqConn().rollback();
                getSeqConn().close();
                setSeqConn(null);
                return null;
            } catch (SQLException e1) {
                // TODO 自動生成された catch ブロック
                e1.printStackTrace();
            }
        } finally {
            if (callableStatement != null) {
                try {
                    callableStatement.close();
                } catch (SQLException e) {
                    // 後処理のため、無視する。
                }
            }
            callableStatement = null;
        }

        return ret;
    }

    /**
     * 指定SEQUENSE_IDの論理番号を取得する<br>
     *
     * @param sequenceId シーケンスID
     * @return 論理番号
     * @throws SQLException
     */
    public String getLn(String sequenceId) {
        long sequenceNo = Long.parseLong(this.getSequenceImpl(sequenceId));
        DecimalFormat df = new DecimalFormat();
        SimpleDateFormat sdf = new SimpleDateFormat("");
        java.util.Date dt = new java.util.Date();
        sdf.setLenient(false);
        sdf.applyPattern("yyyyMMddHHmmssSSS");
        if (sequenceId.equals(LN_QUE_KB_SIG_SEQ_NAME)) {
            // 警備信号の場合のみシーケンスは二桁とし、末尾は0として返却
            df.applyPattern("00");
            return sdf.format(dt) + df.format(sequenceNo) + "0";
        }

        df.applyPattern("000");
        return sdf.format(dt) + df.format(sequenceNo);

    }

    /**
     * SEQUENCE_MANAGER表から、指定SEQUENSE_IDの次の値を取得し、指定の桁数で返却する<br>
     *
     * @param sequenceId シーケンスID
     * @param len 桁数
     * @return 次のSEQUENSE値
     * @throws SQLException
     */
    private String getSeq(String sequenceId, int len) {
        long sequenceNo = Long.parseLong(this.getSequenceImpl(sequenceId));
        DecimalFormat df = new DecimalFormat();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < len; i++) {
            sb.append("0");
        }
        df.applyPattern(sb.toString());
        return df.format(sequenceNo);
    }

    /**
     * SEQUENCE_MANAGER表から、制御キュー用のコマンドシーケンス番号を取得する<br>
     *
     * @return 次のSEQUENSE値(12桁)
     * @throws SQLException
     */
    public String getCmdSeq() {
        return this.getSeq(CMD_SEQ_NUM, 12);
    }

    /**
     * SEQUENCE_MANAGER表から、制御キュー用のトランザクション番号を取得する<br>
     *
     * @return 次のSEQUENSE値(12桁)
     * @throws SQLException
     */
    public String getTranSeq() {
        return this.getSeq(TRAN_SEQ_NUM, 12);
    }

    /**
     * 接続中か確認する<br>
     *
     * @return 接続している場合true
     * @throws SQLException
     */
    public boolean isConnected() throws SQLException {
        if (getConn() == null || getConn().isClosed()) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * @return the server
     */
    public String getServer() {
        return server;
    }

    /**
     * @return the dbname
     */
    public String getDbname() {
        return dbname;
    }

    /**
     * @return the user
     */
    public String getUser() {
        return user;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param dbType セットする dbType
     */
    private void setDbType(String dbType) {
        this.dbType = dbType;
    }

    /**
     * @return the dbType
     */
    private String getDbType() {
        return dbType;
    }

    /**
     * @return the driverClassName
     */
    private String getDriverClassName() {
        return driverClassName;
    }

    /**
     * @return the port
     */
    private String getPort() {
        return port;
    }

    /**
     * @return propertyFile
     */
    private String getPropertyFile() {
        return propertyFile;
    }

    /**
     * @param propertyFile セットする propertyFile
     */
    private void setPropertyFile(String propertyFile) {
        this.propertyFile = propertyFile;
    }

    /**
     * @param driverClassName セットする driverClassName
     */
    private void setDriverClassName(String driverClassName) {
        this.driverClassName = driverClassName;
    }

    /**
     * @param server セットする server
     */
    private void setServer(String server) {
        this.server = server;
    }

    /**
     * @param port セットする port
     */
    private void setPort(String port) {
        this.port = port;
    }

    /**
     * @param dbname セットする dbname
     */
    private void setDbname(String dbname) {
        this.dbname = dbname;
    }

    /**
     * @param user セットする user
     */
    private void setUser(String user) {
        this.user = user;
    }

    /**
     * @param password セットする password
     */
    private void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return schema
     */
    private String getSchema() {
        return schema;
    }

    /**
     * @param schema セットする schema
     */
    private void setSchema(String schema) {
        this.schema = schema;
    }

    /**
     * @return seqConn
     */
    private Connection getSeqConn() {
        return seqConn;
    }

    /**
     * @param seqConn セットする seqConn
     */
    private void setSeqConn(Connection seqConn) {
        this.seqConn = seqConn;
    }

    /**
     * @return conn
     */
    private Connection getConn() {
        return conn;
    }

    /**
     * @param conn セットする conn
     */
    private void setConn(Connection conn) {
        this.conn = conn;
    }

    /**
     * @return ds
     */
    private DataSource getDs() {
        return ds;
    }

    /**
     * @param ds セットする ds
     */
    private void setDs(DataSource ds) {
        this.ds = ds;
    }
}