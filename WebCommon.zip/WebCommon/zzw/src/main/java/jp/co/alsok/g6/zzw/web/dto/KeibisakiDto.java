/**
 *
 */
package jp.co.alsok.g6.zzw.web.dto;


public class KeibisakiDto {
	/** 警備先名称 */
	private String keibisakiName = "";
	/** LN_警備先論理番号 */
	private String keibisakiId = "";
	/** 警備先住所 */
	private String keibisakiAddress = "";


	/**
	* keibisakiName 取得
	* @return keibisakiName
	*/
	public String getKeibisakiName() {
		return keibisakiName;
	}
	/**
	* @param keibisakiName 設定 keibisakiName
	*/
	public void setKeibisakiName(String keibisakiName) {
		this.keibisakiName = keibisakiName;
	}
	/**
	* keibisakiId 取得
	* @return keibisakiId
	*/
	public String getKeibisakiId() {
		return keibisakiId;
	}
	/**
	* @param keibisakiId 設定 keibisakiId
	*/
	public void setKeibisakiId(String keibisakiId) {
		this.keibisakiId = keibisakiId;
	}
	/**
	* keibisakiAddress 取得
	* @return keibisakiAddress
	*/
	public String getKeibisakiAddress() {
		return keibisakiAddress;
	}
	/**
	* @param keibisakiAddress 設定 keibisakiAddress
	*/
	public void setKeibisakiAddress(String keibisakiAddress) {
		this.keibisakiAddress = keibisakiAddress;
	}
}
