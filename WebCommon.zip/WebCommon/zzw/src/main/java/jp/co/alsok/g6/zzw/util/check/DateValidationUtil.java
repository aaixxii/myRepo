package jp.co.alsok.g6.zzw.util.check;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.util.Calendar;
import java.util.Date;

/**
 * 共通関数 - 日付チェック部品.<br>
 */
public class DateValidationUtil {

	/** 日付フォーマット： yyyyMMdd */
	public static final String FORMAT_YYYYMMDD = "yyyyMMdd";
	/** 日付フォーマット： yyyy/M/d */
	public static final String FORMAT_YYYYMD_SLASH = "yyyy/M/d";
	/** 日付フォーマット： yyyy/MM/dd */
	public static final String FORMAT_YYYYMMDD_SLASH = "yyyy/MM/dd";
	/** 時刻フォーマット： HH:mm */
	public static final String FORMAT_HHMM_COLON = "HH:mm";
	/** 時刻フォーマット： HH:mm:ss */
	public static final String FROMAT_HHMMSS_COLON = "HH:mm:ss";
	/** 時刻フォーマット： HH:mm:ss.SSS */
	public static final String FORMAT_HHMMSS_SSS_COLON = "HH:mm:ss.SSS";
	/** 日付フォーマット： yyyy/MM/dd HH:mm:ss */
	public static final String FORMAT_YYYYMMDD_HHMMSS_SLASH_COLON = "yyyy/MM/dd HH:mm:ss";
	/** 日付フォーマット： yyyy/MM/dd HH:mm:ss.SSS */
	public static final String FORMAT_YYYYMMDD_HHMMSS_SSS_SLASH_COLON = "yyyy/MM/dd HH:mm:ss";

	/**
	 * 日付・時刻フォーマットチェック関数.<br>
	 * 文字列の日付が正しい日付、形式か判定を行います。<br>
	 *
	 * @param value 文字列の日付、時刻
	 * @param format 日付、時刻のフォーマット
	 * @return {@code true} 正しい日付、形式の場合<br>
	 * 			{@code false} 正しくない日付、または、形式が正しくない場合
	 */
	public static boolean validDateFormat(final String value, final String format) {
		if (value == null || value.isEmpty()) return false;
		if (format == null || format.isEmpty()) return false;

		try {
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			sdf.setLenient(false);
			Date result = sdf.parse(value);
			// 桁数過不足が通る為、再フォーマットした結果と突合する
			if (!sdf.format(result).equalsIgnoreCase(value)) return false;
		} catch (ParseException e) {
			// 日付、時刻の変換に失敗した場合
			return false;
		} catch (IllegalArgumentException e2) {
			// 日付、時刻のフォーマットが不正な場合
			return false;
		}
		return true;
	}

	/**
	 * 日付・時刻の大小比較関数.<br>
	 * 日付・時刻を比較します。<br>
	 * {@code value1} に日付の文字列を引き渡す場合、{@code value2} も同様に日付の文字列を引き渡してください。<br>
	 * {@code value1} に時刻の文字列を引き渡す場合、{@code value2} も同様に時刻の文字列を引き渡してください。<br>
	 * {@code value1} と {@code value2} は正しい日付、または、時刻が引き渡されるものとするため、事前に日付・時刻フォーマットチェックを行ってください。
	 *
	 * @param value1 文字列の日付、または、時刻
	 * @param value2 文字列の日付、または、時刻
	 * @param format 日付、または、時刻のフォーマット
	 * @return {@code value1} < {@code value2} の場合、0未満（マイナス値）を返却<br>
	 * 			{@code value1} = {@code value2} の場合、0を返却<br>
	 * 			{@code value1} > {@code value2} の場合、0より大きい数を返却
	 * @throws ParseException 日付、時刻変換に失敗した場合にスロー
	 */
	public static int compareToDate(final String value1, final String value2, final String format) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		sdf.setLenient(false);
		Date date1 = sdf.parse(value1);
		Date date2 = sdf.parse(value2);
		return date1.compareTo(date2);
	}

	/**
	 * 曜日取得関数.<br>
	 * 文字列の日付の曜日の列挙対を返却します。<br>
	 * {@code value} は正しい日付が引き渡されるものとするため、事前に日付・時刻フォーマットチェックを行ってください。
	 *
	 * @param value 文字列の日付
	 * @param format 日付のフォーマット
	 * @return {@link DayOfWeek} 日付の列挙対
	 * @throws ParseException 日付変換に失敗した場合にスロー
	 */
	public static DayOfWeek getDayOfWeek(final String value, final String format) throws ParseException {
		int ret = getDayOfWeekInt(value, format);
		return DayOfWeek.of(ret);
	}

	/**
	 * 曜日取得関数.<br>
	 * 文字列の日付の曜日の数値を返却します。<br>
	 * {@code value} は正しい日付が引き渡されるものとするため、事前に日付・時刻フォーマットチェックを行ってください。
	 *
	 * @param value 文字列の日付
	 * @param format 日付のフォーマット
	 * @return 1:月曜日<br>
	 * 			2:火曜日<br>
	 * 			3:水曜日<br>
	 * 			4:木曜日<br>
	 * 			5:金曜日<br>
	 * 			6:土曜日<br>
	 * 			7:日曜日<br>
	 * 			※{@link DayOfWeek} の値に準じます
	 * @throws ParseException 日付変換に失敗した場合にスロー
	 */
	public static int getDayOfWeekInt(final String value, final String format) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		sdf.setLenient(false);
		Date date = sdf.parse(value);
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		int ret = calendar.get(Calendar.DAY_OF_WEEK);
		// Calendar.get(Calendar.DAY_OF_WEEK)で取得できる値は日曜=1～土曜=7となる為、変換
		return (ret == 1) ? 7 : ret - 1;
	}
}
