package jp.co.alsok.g6.zzw.web;

import java.util.Date;
import java.util.Set;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * セッション共通部品インターフェイス
 * @author SSC
 */
public interface G6Session {

	/**
	 * <pre>
	 * セッション情報登録
	 * ・入力された引数（KEY,値）をセッションオブジェクトに登録する。
	 * ・KEYに対する値が既に存在する場合は更新、しない場合は登録となる。
	 * </pre>
	 * @param key
	 *            キー
	 * @param value
	 *            情報
	 */
	void putSessionValue(@NotNull @Size(max = 64) String key, Object value);

	/**
	 * <pre>
	 * セッション情報取得
	 * ・セッションオブジェクトから指定したKEYの値を取得する。
	 * ・指定したキーがない場合はnullを返却する。
	 * </pre>
	 * @param <T> セッションオブジェクトの型
	 * @param key
	 *            キー
	 * @return KEYに対応する値
	 */
	<T> T getSessionValue(@NotNull @Size(max = 64) String key);

	/**
	 * <pre>
	 * セッション情報部分削除
	 * ・セッションオブジェクトから指定したKEYの値を削除する。
	 * ・指定したキーが存在しない場合は何もしない
	 * </pre>
	 * @param key
	 *            キー
	 */
	void removeSession(@NotNull @Size(max = 64) String key);

	/**
	 * <pre>
	 * セッション情報部分削除
	 * ・セッションオブジェクトが保持している情報を全削除する。
	 * </pre>
	 */
	void removeAllSession();
	
	/**
	 * <pre>
	 * セッションID取得
	 * </pre>
	 * @return セッションID
	 */
	@NotNull String getSessionId();
	
	/**
	 * <pre>
	 * ユーザID取得
	 * </pre>
	 * @return ユーザID
	 */
	@NotNull String getUserId();
	
	/**
	 * <pre>
	 * セッション生成日時取得
	 * </pre>
	 *
	 * @return セッション生成日時
	 */
	@NotNull Date getCreateDate();
	
	/**
	 * <pre>
	 * セッションキー一覧取得部品
	 * ・セッションオブジェクトが保持している情報のキー一覧を取得する。
	 * ・情報が１つもない場合は空のセットを返却する。
	 * </pre>
	 * @return キー一覧
	 */
	@NotNull Set<String> keySet();
}
