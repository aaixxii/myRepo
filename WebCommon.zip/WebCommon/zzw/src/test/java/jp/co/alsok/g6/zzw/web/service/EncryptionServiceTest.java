package jp.co.alsok.g6.zzw.web.service;

import static org.junit.Assert.*;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.xml.bind.DatatypeConverter;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import jp.co.alsok.g6.zzw.web.constants.CommonComponentConstants;

public class EncryptionServiceTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testConvStringToCipher() {
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			String target = "aimalsok4" + CommonComponentConstants.ENCRYPT_SALT;
			byte[] bytes = md.digest(target.getBytes(StandardCharsets.UTF_8));
			String result = DatatypeConverter.printHexBinary(bytes);
			System.out.println(result);


			
		} catch (NoSuchAlgorithmException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
	}

}
