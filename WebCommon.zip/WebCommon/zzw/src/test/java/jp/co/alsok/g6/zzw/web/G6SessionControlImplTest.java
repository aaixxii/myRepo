package jp.co.alsok.g6.zzw.web;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
/**
 * セッションオブジェクト制御部品実装クラスのテストクラスである。
 *
 * @author NEC
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class G6SessionControlImplTest {
    @Mock
    private JdbcTemplate jdbcTemplate;

    @InjectMocks
    private G6SessionControlImpl g6SessionControlImpl;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }
    /**
     * generateSessionId()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列が返ってくること<br>
     *
     */
    @SuppressWarnings("unchecked")
	@Test
    public void test_セッションID生成処理のテスト() {
        // mock準備
        // DBアクセスして同じsessionIdがあるかどうかのチェックをモック化
        when(jdbcTemplate.query(anyString(), any(ResultSetExtractor.class), anyString())).thenReturn(false);

        String sessionId = g6SessionControlImpl.generateSessionId();

        int actual = sessionId.length();
        assertThat(actual, is(64));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("0000000000000000")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0x0() {

        long value = 0x0L;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("0000000000000000"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("0000000000000001")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0x1() {

        long value = 0x1L;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("0000000000000001"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("000000000000000f")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0xf() {

        long value = 0xfL;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("000000000000000f"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("0000000000000010")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0x10() {

        long value = 0x10L;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("0000000000000010"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("00000000000000ff")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0xff() {

        long value = 0xffL;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("00000000000000ff"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("0000000000000100")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0x100() {

        long value = 0x100L;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("0000000000000100"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("0000000000000fff")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0xfff() {

        long value = 0xfffL;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("0000000000000fff"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("0000000000001000")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0x1000() {

        long value = 0x1000L;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("0000000000001000"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("000000000000ffff")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0xffff() {

        long value = 0xffffL;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("000000000000ffff"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("0000000000010000")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0x10000() {

        long value = 0x10000L;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("0000000000010000"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("00000000000fffff")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0xfffff() {

        long value = 0xfffffL;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("00000000000fffff"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("0000000000100000")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0x100000() {

        long value = 0x100000L;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("0000000000100000"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("0000000000ffffff")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0xffffff() {

        long value = 0xffffffL;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("0000000000ffffff"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("0000000001000000")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0x1000000() {

        long value = 0x1000000L;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("0000000001000000"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("000000000fffffff")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0xfffffff() {

        long value = 0xfffffffL;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("000000000fffffff"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("0000000010000000")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0x10000000() {

        long value = 0x10000000L;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("0000000010000000"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("00000000ffffffff")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0xffffffff() {

        long value = 0xffffffffL;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("00000000ffffffff"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("0000000100000000")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0x100000000() {

        long value = 0x100000000L;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("0000000100000000"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("0000000fffffffff")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0xfffffffff() {

        long value = 0xfffffffffL;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("0000000fffffffff"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("0000001000000000")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0x1000000000() {

        long value = 0x1000000000L;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("0000001000000000"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("000000ffffffffff")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0xffffffffff() {

        long value = 0xffffffffffL;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("000000ffffffffff"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("0000010000000000")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0x10000000000() {

        long value = 0x10000000000L;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("0000010000000000"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("00000fffffffffff")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0xfffffffffff() {

        long value = 0xfffffffffffL;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("00000fffffffffff"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("0000100000000000")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0x100000000000() {

        long value = 0x100000000000L;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("0000100000000000"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("0000ffffffffffff")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0xffffffffffff() {

        long value = 0xffffffffffffL;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("0000ffffffffffff"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("0001000000000000")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0x1000000000000() {

        long value = 0x1000000000000L;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("0001000000000000"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("000fffffffffffff")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0xfffffffffffff() {

        long value = 0xfffffffffffffL;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("000fffffffffffff"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("0010000000000000")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0x10000000000000() {

        long value = 0x10000000000000L;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("0010000000000000"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("00ffffffffffffff")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0xffffffffffffff() {

        long value = 0xffffffffffffffL;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("00ffffffffffffff"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("0100000000000000")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0x100000000000000() {

        long value = 0x100000000000000L;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("0100000000000000"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("0fffffffffffffff")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0xfffffffffffffff() {

        long value = 0xfffffffffffffffL;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("0fffffffffffffff"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("1000000000000000")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0x1000000000000000() {

        long value = 0x1000000000000000L;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("1000000000000000"));
    }
    /**
     * toHexString()メソッドのテスト<br>
     *
     * 処理が正常終了すること<br>
     * 64バイトの文字列("ffffffffffffffff")が返ってくること<br>
     *
     */
    @Test
    public void test_64bitを16進数文字列に変換処理のテスト_0xffffffffffffffff() {

        long value = 0xffffffffffffffffL;
        String actual = g6SessionControlImpl.toHexString(value);

        assertThat(actual, is("ffffffffffffffff"));
    }
}
