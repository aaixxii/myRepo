package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.extract.planner.MuRemainLots;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class GetFirstMuRemainLotsProcedureTest extends
		AbstractTransactionalJUnit4SpringContextTests {
	@PersistenceContext(unitName = "AIMDB")
	protected EntityManager entityManager;
	@Resource
	protected DataSource dataSource;
	@Resource
	protected JdbcTemplate jdbcTemplate;

	private GetFirstMuRemainLotsProcedure firstProcedureDao;

	@Before
	public void setUp() throws Exception {
		firstProcedureDao = new GetFirstMuRemainLotsProcedure(dataSource);
		jdbcTemplate.update("delete from match_units");
		jdbcTemplate.update("delete from mu_extract_load");
		jdbcTemplate.update("delete from mu_eligible_functions");
		jdbcTemplate.execute("commit");
	}

	@After
	public void tearDown() throws Exception {
		firstProcedureDao = null;
		jdbcTemplate.update("delete from match_units");
		jdbcTemplate.update("delete from mu_extract_load");
		jdbcTemplate.update("delete from mu_eligible_functions");
		jdbcTemplate.execute("commit");
	}

	@Test
	public void testGetfirstMuRemainLots() {
		int maxMulots = 12;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";

		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		String[] muStautus = { "WORKING", "EXIT", "WORKING", "WORKING",
				"WORKING" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 4, 5, 6, 7, 8 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		long epochTime = System.currentTimeMillis();
		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(epochTime) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
			jdbcTemplate.execute("commit");

		}
		MuRemainLots firstMuRemainLots = null;
		try {
			firstMuRemainLots = firstProcedureDao
					.getfirstMuRemainLots(maxMulots);
		} catch (DataAccessException | SQLException e) {
			e.printStackTrace();
		}
		Assert.assertNotNull(firstMuRemainLots);
		Assert.assertEquals(1000, firstMuRemainLots.getMuId().intValue());
	}
	
	
	@Test
	public void testGetfirstMuRemainLots_numOfExractor__all_zero() {
		int maxMulots = 12;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";

		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		String[] muStautus = { "WORKING", "EXIT", "WORKING", "WORKING",
				"WORKING" };
		int[] muCpus = { 0, 0, 0, 0, 0 };
		int[] muPressure = { 4, 5, 6, 7, 8 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		long epochTime = System.currentTimeMillis();
		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(epochTime) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
			jdbcTemplate.execute("commit");

		}
		MuRemainLots firstMuRemainLots = null;
		try {
			firstMuRemainLots = firstProcedureDao
					.getfirstMuRemainLots(maxMulots);
		} catch (DataAccessException | SQLException e) {
			e.printStackTrace();
		}
		Assert.assertNull(firstMuRemainLots);		
	}
	
	@Test
	public void testGetfirstMuRemainLots_numOfExractor_has_zero() {
		int maxMulots = 12;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";

		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		String[] muStautus = { "WORKING", "EXIT", "WORKING", "WORKING",
				"WORKING" };
		int[] muCpus = { 0, 8, 4, 4, 0 };
		int[] muPressure = { 4, 5, 6, 7, 8 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		long epochTime = System.currentTimeMillis();
		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(epochTime) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
			jdbcTemplate.execute("commit");

		}
		MuRemainLots firstMuRemainLots = null;
		try {
			firstMuRemainLots = firstProcedureDao
					.getfirstMuRemainLots(maxMulots);
		} catch (DataAccessException | SQLException e) {
			e.printStackTrace();
		}
		Assert.assertNotNull(firstMuRemainLots);
		Assert.assertEquals(1002, firstMuRemainLots.getMuId().intValue());		
		
	}
	
	
	@Test
	public void testGetfirstMuRemainLots_numOfExractor_has_zero_more_one() {
		int maxMulots = 12;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";

		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		String[] muStautus = { "WORKING", "EXIT", "WORKING", "WORKING",
				"WORKING" };
		int[] muCpus = { 0, 0, 4, 4, 0 };
		int[] muPressure = { 4, 5, 7, 6, 8 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		long epochTime = System.currentTimeMillis();
		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(epochTime) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
			jdbcTemplate.execute("commit");

		}
		MuRemainLots firstMuRemainLots = null;
		try {
			firstMuRemainLots = firstProcedureDao
					.getfirstMuRemainLots(maxMulots);
		} catch (DataAccessException | SQLException e) {
			e.printStackTrace();
		}
		Assert.assertNotNull(firstMuRemainLots);
		Assert.assertEquals(1002, firstMuRemainLots.getMuId().intValue());		
		
	}
	
	

	@Test
	public void testGetfirstMuRemainLots_max_pressure_selected() {
		int maxMulots = 12;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";
		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		String[] muStautus = { "WORKING", "EXIT", "WORKING", "WORKING",
				"WORKING" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 4, 5, 6, 7, 8 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		long epochTime = System.currentTimeMillis();
		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(epochTime) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
			jdbcTemplate.execute("commit");

		}
		MuRemainLots firstMuRemainLots = null;
		try {
			firstMuRemainLots = firstProcedureDao
					.getfirstMuRemainLots(maxMulots);
		} catch (DataAccessException | SQLException e) {
			e.printStackTrace();
		}
		Assert.assertNotNull(firstMuRemainLots);
		Assert.assertEquals(1000, firstMuRemainLots.getMuId().intValue());
	}

	@Test
	public void testGetfirstMuRemainLots_max_pressure_exit_not_select() {
		int maxMulots = 12;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";
		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		String[] muStautus = { "EXIT", "EXIT", "WORKING", "WORKING", "WORKING" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 8, 5, 6, 7, 4 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		long epochTime = System.currentTimeMillis();
		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(epochTime) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
			jdbcTemplate.execute("commit");

		}
		MuRemainLots firstMuRemainLots = null;
		try {
			firstMuRemainLots = firstProcedureDao
					.getfirstMuRemainLots(maxMulots);
		} catch (DataAccessException | SQLException e) {
			e.printStackTrace();
		}
		Assert.assertNotNull(firstMuRemainLots);
		Assert.assertEquals(1002, firstMuRemainLots.getMuId().intValue());
		Assert.assertNotEquals(1001, firstMuRemainLots.getMuId().intValue());
	}

	@Test
	public void testGetfirstMuRemainLots_max_pressure_function17_olny_selected() {
		int maxMulots = 12;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";
		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		String[] muStautus = { "WORKING", "EXIT", "WORKING", "WORKING", "EXIT" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 4, 5, 6, 7, 8 };
		int[] muFunctionId = { 17, 17, 17, 1, 1 };
		long epochTime = System.currentTimeMillis();
		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(epochTime) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
			jdbcTemplate.execute("commit");

		}
		MuRemainLots firstMuRemainLots = null;
		try {
			firstMuRemainLots = firstProcedureDao
					.getfirstMuRemainLots(maxMulots);
		} catch (DataAccessException | SQLException e) {
			e.printStackTrace();
		}
		Assert.assertNotNull(firstMuRemainLots);
		Assert.assertEquals(1000, firstMuRemainLots.getMuId().intValue());
		Assert.assertNotEquals(1003, firstMuRemainLots.getMuId().intValue());
		Assert.assertNotEquals(1004, firstMuRemainLots.getMuId().intValue());
	}

	@Test
	public void testGetfirstMuRemainLots_minUpdateTs_selected() {
		int maxMulots = 12;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";
		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		String[] muStautus = { "WORKING", "EXIT", "WORKING", "WORKING",
				"WORKING" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 5, 5, 5, 5, 5 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		long epochTime = System.currentTimeMillis();
		long[] updateTs = { epochTime - 1000, epochTime - 2000,
				epochTime - 3000, epochTime - 4000, epochTime - 5000 };
		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(updateTs[i]) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
			jdbcTemplate.execute("commit");

		}
		MuRemainLots firstMuRemainLots = null;
		try {
			firstMuRemainLots = firstProcedureDao
					.getfirstMuRemainLots(maxMulots);
		} catch (DataAccessException | SQLException e) {
			e.printStackTrace();
		}
		Assert.assertNotNull(firstMuRemainLots);
		Assert.assertEquals(1000, firstMuRemainLots.getMuId().intValue());
	}

	@Test
	public void testGetfirstMuRemainLots_results_null() {
		int maxMulots = 5;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";
		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		String[] muStautus = { "EXIT", "EXIT", "EXIT", "WORKING", "WORKING" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 1, 2, 3, 4, 5 };
		int[] muFunctionId = { 17, 17, 17, 1, 1 };
		long epochTime = System.currentTimeMillis();
		long[] updateTs = { epochTime - 1000, epochTime - 2000,
				epochTime - 3000, epochTime - 4000, epochTime - 5000 };
		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(updateTs[i]) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
			jdbcTemplate.execute("commit");
		}

		MuRemainLots firstMuRemainLots = null;
		try {
			firstMuRemainLots = firstProcedureDao
					.getfirstMuRemainLots(maxMulots);
		} catch (DataAccessException | SQLException e) {
			e.printStackTrace();
		}
		Assert.assertNull(firstMuRemainLots);
	}

	@Test
	public void testGetfirstMuRemainLots_zeroRemainLots_not_selected() {
		int maxMulots = 5;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String extratLoadSql = "INSERT INTO MU_EXTRACT_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";
		String eligibleFunctionsSql = "INSERT INTO MU_ELIGIBLE_FUNCTIONS (MU_ID,FUNCTION_ID) VALUES(?,?)";
		int[] muIds = { 1000, 1001, 1002, 1003, 1004 };
		String[] muStautus = { "WORKING", "EXIT", "WORKING", "WORKING",
				"WORKING" };
		int[] muCpus = { 4, 8, 4, 4, 4 };
		int[] muPressure = { 1, 2, 3, 4, 5 };
		int[] muFunctionId = { 17, 17, 17, 17, 17 };
		long epochTime = System.currentTimeMillis();
		long[] updateTs = { epochTime - 1000, epochTime - 2000,
				epochTime - 3000, epochTime - 4000, epochTime - 5000 };
		for (int i = 0; i < 5; i++) {
			jdbcTemplate.update(muSql, new Object[] { new Integer(muIds[i]),
					String.valueOf((muIds[i])), muStautus[i],
					new Integer(muCpus[i]) });
			jdbcTemplate.update(extratLoadSql, new Object[] {
					new Integer(muIds[i]), new Integer(muPressure[i]),
					new Long(updateTs[i]) });
			jdbcTemplate.update(eligibleFunctionsSql, new Object[] {
					new Integer(muIds[i]), new Integer(muFunctionId[i]) });
			jdbcTemplate.execute("commit");

		}
		MuRemainLots firstMuRemainLots = null;
		try {
			firstMuRemainLots = firstProcedureDao
					.getfirstMuRemainLots(maxMulots);
		} catch (DataAccessException | SQLException e) {
			e.printStackTrace();
		}
		Assert.assertNotNull(firstMuRemainLots);
		Assert.assertEquals(1000, firstMuRemainLots.getMuId().intValue());
		Assert.assertNotEquals(1004, firstMuRemainLots.getMuId().intValue());
	}

}
