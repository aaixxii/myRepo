package jp.co.nec.aim.mm.extract.dispatch;

public class ComponentProcessStautsInfo {
	private String msgCode;
	private MessageType msgType;
	private ProcessType processType;
	private String failureReason;
	private String reasonTime;
	private long resultTime;

	public String getMsgCode() {
		return msgCode;
	}

	public void setMsgCode(String msgCode) {
		this.msgCode = msgCode;
	}

	public MessageType getMsgType() {
		return msgType;
	}

	public void setMsgType(MessageType msgType) {
		this.msgType = msgType;
	}

	public ProcessType getProcessType() {
		return processType;
	}

	public void setProcessType(ProcessType processType) {
		this.processType = processType;
	}

	public String getFailureReason() {
		return failureReason;
	}

	public void setFailureReason(String failureReason) {
		this.failureReason = failureReason;
	}

	public String getReasonTime() {
		return reasonTime;
	}

	public void setReasonTime(String reasonTime) {
		this.reasonTime = reasonTime;
	}

	public long getResultTime() {
		return resultTime;
	}

	public void setResultTime(long resultTime) {
		this.resultTime = resultTime;
	}
}
