package jp.co.nec.aim.mm.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import jp.co.nec.aim.mm.entities.PersonBiometricEntity;

public class UniqueKeyCheckDao {
	
	private EntityManager em;

	public UniqueKeyCheckDao(EntityManager em) {
		this.em = em;
	}
	
	@SuppressWarnings("unchecked")
	public  List<PersonBiometricEntity> checkEnrollmentID(String enrollId) {
		try {
			Query q = em.createNamedQuery("NQ::checkEnrollmentID");
			q.setParameter("enrollId", enrollId);
			List<PersonBiometricEntity> results = q.getResultList();
			return results;			
		} catch (Exception e) {
			return null;
		}
	}
	
	
	
	

	
}
