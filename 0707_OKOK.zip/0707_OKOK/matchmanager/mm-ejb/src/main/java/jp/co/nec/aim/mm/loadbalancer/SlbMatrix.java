package jp.co.nec.aim.mm.loadbalancer;

import java.io.Serializable;

/**
 * SlbMatrix that will be persist into procedure as parameter
 * 
 * @author liuyq
 * 
 */
public class SlbMatrix implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -5561112995562679279L;

	private Long unitId; // unit Id(include DM id and MU id)
	private Long segId; // the segment id

	/**
	 * default constructor
	 */
	public SlbMatrix() {
	}

	/**
	 * default constructor
	 */
	public SlbMatrix(Long unitId, Long segId) {
		this.unitId = unitId;
		this.segId = segId;
	}

	public Long getUnitId() {
		return unitId;
	}

	public void setUnitId(Long unitId) {
		this.unitId = unitId;
	}

	public Long getSegId() {
		return segId;
	}

	public void setSegId(Long segId) {
		this.segId = segId;
	}

}
