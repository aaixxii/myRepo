package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.jdbc.object.StoredProcedure;

import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.util.StopWatch;

/**
 * Spring StoredProcedure class to call finish_extract_job()
 * 
 * @author kurosu
 * 
 */
public class FinishExtractJobProcedure extends StoredProcedure {

	private static final String SQL = "finish_extract_job";
	
	public FinishExtractJobProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		//setFunction(true);
		setSql(SQL);		
		declareParameter(new SqlParameter("p_mu_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_job_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_result", Types.VARCHAR));
		declareParameter(new SqlParameter("p_diagnostics", Types.BLOB));
		declareParameter(new SqlParameter("p_template", Types.BLOB));
		declareParameter(new SqlOutParameter("l_count", Types.INTEGER));
				
		compile();
	}

	/**
	 * Update FE_JOB_QUEUE SET JOB_STATE=DONE, and insert records into
	 * FE_RESULTS If keyedBinaries contains same keys, save 1st one.
	 * 
	 * @param muId
	 * @param jobId
	 * @param result
	 * @param keyedBinaries
	 * @return number of updated records of fe_job_queue
	 * @throws SQLException
	 */
	public int execute(long muId, long jobId, String xmlResult, byte[] diagnostics,  String key, byte[] template) throws SQLException {
			
		if (muId < 1L) {
			throw new IllegalArgumentException("muId is less than 1");
		}
		if (jobId < 1L) {
			throw new IllegalArgumentException("jobId is less than 1");
		}
		if (xmlResult == null) {
			throw new IllegalArgumentException("results is null");
		}

		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_mu_id", new Long(muId));
		map.put("p_job_id", new Long(jobId));
		map.put("p_result", xmlResult);
		map.put("p_diagnostics", new SqlLobValue(diagnostics));	
		map.put("p_template", new SqlLobValue(template));
		Map<String, Object> resultMap = execute(map);		
		int count = ((Integer) resultMap.get("l_count")).intValue();

		stopWatch.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "execute",
				stopWatch.elapsedTime());
		return count;
	}	
}
