/**this is file UidaiRequstTester.java
 * @author xia
   @date 2020/07/03
 */
package com.nec.aim.uid.client.uidplus;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * @author xia
 *
 */
public class UidaiRequstTester {
    private static AtomicLong lastReqeustId;    
    private static AtomicLong lastEnrollmentId;    
    private static String sequecFilePath;
    private static PropertiesConfiguration propsConfig;
    String postUrl = "http://localhost:8080/matchmanager/AIMExtractService";
    
//	@Before
//	public void setUp() throws Exception {
//		   URL url = Thread.currentThread().getContextClassLoader().getResource("uid.sequece.properties");
//	        sequecFilePath = url.getPath();
//	        propsConfig = new PropertiesConfiguration();
//	        propsConfig.setEncoding("UTF-8");
//	        propsConfig.load(sequecFilePath); 
//	        long reqeustId = propsConfig.getLong("REQUEST_Id");
//	        lastReqeustId = new AtomicLong(reqeustId);
//	        long enrollmentId = propsConfig.getLong("ENROLLMENT_ID");
//	        lastEnrollmentId = new AtomicLong(enrollmentId);	       
//	}
	
	@BeforeClass
	public static void setUp() throws Exception {
		String path = "src/test/resources/uid.sequece.properties";		 
		File file = new File(path);
		sequecFilePath = file.getPath();
		//String xx = file.getAbsolutePath();
	        propsConfig = new PropertiesConfiguration();
	        propsConfig.setEncoding("UTF-8");
	        propsConfig.load(sequecFilePath); 
	        long reqeustId = propsConfig.getLong("REQUEST_Id");
	        lastReqeustId = new AtomicLong(reqeustId);
	        long enrollmentId = propsConfig.getLong("ENROLLMENT_ID");
	        lastEnrollmentId = new AtomicLong(enrollmentId);	       
	}

	@AfterClass
	public static void tearDown() throws Exception {
		 try {
	            PropertiesConfiguration properties = new PropertiesConfiguration(sequecFilePath);	           
	            properties.setProperty("REQUEST_Id", String.valueOf(lastReqeustId.get()));
	            properties.setProperty("ENROLLMENT_ID", String.valueOf(lastEnrollmentId.incrementAndGet()));
	            properties.save();
	            properties = null;
	        } catch (ConfigurationException e) {
	            System.out.println(e.getMessage());
	        }
	}
	
	@Test
	public void createExtRequest() throws IOException {		
		String enrollId = "REF_" + String.format("%032d", lastEnrollmentId.incrementAndGet());
		String requestId = "REQ_" + String.format("%032d", lastReqeustId.incrementAndGet());
		String refUrl = "http://localhost:8080/image/1";
		String extReq = UidaiRequestCreater.buildExtractRequest(requestId, enrollId, refUrl);
		System.out.println(extReq);
	}
	
	@Test
	public void createInsertRequest() throws IOException {
		String enrollId = "REF_" + String.format("%032d", lastEnrollmentId.incrementAndGet());
		String requestId = "REQ_" + String.format("%032d", lastReqeustId.incrementAndGet());
		String refUrl = "http://localhost:8080/image/1";
		String insertReq = UidaiRequestCreater.buildInsertRequest(requestId, enrollId, refUrl);
		System.out.println(insertReq);
	}
	
	@Test
	public void createIndeityRequest() throws IOException {
		String enrollId = "REF_" + String.format("%032d", lastEnrollmentId.incrementAndGet());
		String requestId = "REQ_" + String.format("%032d", lastReqeustId.incrementAndGet());
		String refUrl = "http://localhost:8080/image/1";
		String insertReq = UidaiRequestCreater.buildInquiryRequest(requestId, enrollId, refUrl);
		System.out.println(insertReq);
	}

}
