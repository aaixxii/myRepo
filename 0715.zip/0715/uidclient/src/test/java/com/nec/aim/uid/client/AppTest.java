package com.nec.aim.uid.client;

import java.util.UUID;

import org.junit.Test;

import junit.framework.TestCase;

/**
 * Unit test for simple App.
 */
public class AppTest 
    extends TestCase
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
  @Test
    public void testApp()  {   
    	UUID uuid = UUID.randomUUID();
        String str = uuid.toString();      
        System.out.println(str.getBytes().length);
   
    
    }
	
    public static String getUUID32(){
		return UUID.randomUUID().toString().replace("-", "").toLowerCase();
	}
	public static String[] getUUID(int num){
		
		if( num <= 0)
			return null;
		
		String[] uuidArr = new String[num];
		
		for (int i = 0; i < uuidArr.length; i++) {
			uuidArr[i] = getUUID32();
		}
		
		return uuidArr;
	}
  
	@Test
	public void testPath() {		
		String test = "000000000000000000000000000000000000";		
		System.out.print(test.length());
	}
	@Test
	public void test7() {
		String thisUrl = "http://127.0.0.1:8080/dm";
				
		 String[] tmpArr = thisUrl.split(":");			
		 String ip = tmpArr[1].substring(2, tmpArr[1].length());
		 System.out.print(ip);
		 String temp = tmpArr[2];
		 String port = temp.substring(0, temp.length() -3);
		 System.out.print(port);
		 int idx = temp.indexOf("/");
		 String dmWebContent = temp.substring(idx + 1, temp.length());
		 System.out.print(dmWebContent);
		 String ipAndPort = ip + ":" + port;
		 System.out.print(ipAndPort);
	}
	
	@Test
	public void testStr() {
		String mm = "i am tester";
		System.out.print(String.format("%s", mm));
	}
}
