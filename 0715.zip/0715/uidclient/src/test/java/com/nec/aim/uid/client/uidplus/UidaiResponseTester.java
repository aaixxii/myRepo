/**this is file UidaiResponseCreater.java
 * @author xia
   @date 2020/07/04
 */
package com.nec.aim.uid.client.uidplus;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * @author xia
 *
 */
public class UidaiResponseTester {
	  private static AtomicLong lastReqeustId;    
	    private static AtomicLong lastEnrollmentId;    
	    private static String sequecFilePath;
	    private static PropertiesConfiguration propsConfig;
	    String postUrl = "http://localhost:8080/matchmanager/AIMExtractService";
	@BeforeClass
	public static void setUp() throws Exception {
		String path = "src/test/resources/uid.sequece.properties";		 
		File file = new File(path);
		sequecFilePath = file.getPath();
		//String xx = file.getAbsolutePath();
	        propsConfig = new PropertiesConfiguration();
	        propsConfig.setEncoding("UTF-8");
	        propsConfig.load(sequecFilePath); 
	        long reqeustId = propsConfig.getLong("REQUEST_Id");
	        lastReqeustId = new AtomicLong(reqeustId);
	        long enrollmentId = propsConfig.getLong("ENROLLMENT_ID");
	        lastEnrollmentId = new AtomicLong(enrollmentId);	       
	}

	@AfterClass
	public static void tearDown() throws Exception {
		 try {
	            PropertiesConfiguration properties = new PropertiesConfiguration(sequecFilePath);	           
	            properties.setProperty("REQUEST_Id", String.valueOf(lastReqeustId.get()));
	            properties.setProperty("ENROLLMENT_ID", String.valueOf(lastEnrollmentId.incrementAndGet()));
	            properties.save();
	            properties = null;
	        } catch (ConfigurationException e) {
	            System.out.println(e.getMessage());
	        }
	}
	
	@Test
	public void createSuccessIndeityRespose() throws IOException {
		String enrollId = "REF_" + String.format("%032d", lastEnrollmentId.incrementAndGet());
		String requestId = "REQ_" + String.format("%032d", lastReqeustId.incrementAndGet());
		String refUrl = "http://localhost:8080/image/1";
		String insertReq = UidaiResposeCreater.buildSuccessInquiryRespose(requestId, enrollId, refUrl);
		System.out.println(insertReq);
	}
	
	@Test
	public void createFaildIndeityRespose() throws IOException {
		String enrollId = "REF_" + String.format("%032d", lastEnrollmentId.incrementAndGet());
		String requestId = "REQ_" + String.format("%032d", lastReqeustId.incrementAndGet());
		String refUrl = "http://localhost:8080/image/1";
		String insertReq = UidaiResposeCreater.buildFaildInquiryRespose(requestId, enrollId, refUrl, 2, 8);
		System.out.println(insertReq);
	}
	
	@Test
	public void buildgiagnosticsTester() throws IOException {
		String diagnostics = UidaiResposeCreater.buildgiagnostics(4);		
		System.out.println(diagnostics);		
	}
	
	@Test
	public void buildSuccessExtractXmlResposeTester() throws IOException {
		String requestId = "REQ_" + String.format("%032d", lastReqeustId.incrementAndGet());
		String extRes = UidaiResposeCreater.buildSuccessExtractXmlRespose(requestId);
		System.out.println(extRes);
	}
	
	@Test
	public void buildFaildExtractXmlResposeTester() throws IOException {		
		String requestId = "REQ_" + String.format("%032d", lastReqeustId.incrementAndGet());
		
		String extRes = UidaiResposeCreater.buildFaildExtractXmlRespose(requestId, "false", "8");
		System.out.println(extRes);
	}

}
