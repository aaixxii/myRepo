/**this is file uidaiRequestCreater.java
 * @author xia
   @date 2020/07/03
 */
package com.nec.aim.uid.client.uidplus;

import java.io.IOException;
import java.io.StringWriter;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;

/**
 * @author xia
 *
 */
public class UidaiRequestCreater {
	
	public static String buildInquiryRequest(String requeustid, String refId, String url) throws IOException {
		 Document document = DocumentHelper.createDocument();
		 Element root = document.addElement("Request");
		 root.addElement("Identify")
				 .addAttribute("referenceId", refId)
				 .addAttribute("referenceUrl", url)
				 .addAttribute("maxResults", "10")
				 .addAttribute("targetFPIR", "1")
				 .addAttribute("targetModalityFPIR", "1")
				 .addAttribute("dedupModalityInstance", "1")
				 .addAttribute("missingBiometric", "1")
				 .addAttribute("fullsearch", "false");	
		 root.addAttribute("timeStamp", String.valueOf(System.currentTimeMillis()))
		     .addAttribute("version", "1")
		     .addAttribute("requestId", requeustid);		 
		 
		 OutputFormat format = OutputFormat.createPrettyPrint();
		 StringWriter sw = new StringWriter();
       XMLWriter writer  = new XMLWriter(sw, format);        
       writer.write(document);
       String resuslt = sw.toString();		 
		return resuslt;		
	}
	
	public static String buildDeleteRequest(String requeustid,String refId) throws IOException {
		 Document document = DocumentHelper.createDocument();
		 Element root = document.addElement("Request");
		 root.addElement("Delete")
				 .addAttribute("referenceId", refId);		
		 root.addAttribute("timeStamp", String.valueOf(System.currentTimeMillis()))
		     .addAttribute("version", "1")
		     .addAttribute("requestId", requeustid);	
		 OutputFormat format = OutputFormat.createPrettyPrint();
		 StringWriter sw = new StringWriter();
       XMLWriter writer  = new XMLWriter(sw, format);        
       writer.write(document);
       String resuslt = sw.toString();		 
		return resuslt;		
		
	}
	
	public static String buildExtractRequest(String requeustid,String refId, String url) throws IOException {
		 Document document = DocumentHelper.createDocument();
		 Element root = document.addElement("Request");
		 root.addElement("Quality")
				 .addAttribute("referenceId", refId)
				 .addAttribute("referenceUrl", url);
				
		 root.addAttribute("timeStamp", String.valueOf(System.currentTimeMillis()))
		     .addAttribute("version", "1")
		     .addAttribute("requestId", requeustid);	
		 OutputFormat format = OutputFormat.createPrettyPrint();
		 StringWriter sw = new StringWriter();
      XMLWriter writer  = new XMLWriter(sw, format);        
      writer.write(document);
      String resuslt = sw.toString();		 
		return resuslt;	
	}
	
	public static String buildInsertRequest(String requeustid,String refId, String url) throws IOException {
		 Document document = DocumentHelper.createDocument();		
		 Element root = document.addElement("Request");
		 root.addElement("Insert")
				 .addAttribute("referenceId", refId)
				 .addAttribute("referenceUrl", url);
				
		 root.addAttribute("timeStamp", String.valueOf(System.currentTimeMillis()))
		     .addAttribute("version", "3.0")
		     .addAttribute("requestId", requeustid);	
		 OutputFormat format = OutputFormat.createPrettyPrint();
		 String encoding = format.getEncoding();		 
		 StringWriter sw = new StringWriter();		 
     XMLWriter writer  = new XMLWriter(sw, format);      
     writer.write(document);
     String resuslt = sw.toString();
     System.out.print(resuslt);
		return resuslt;	
	}

}
