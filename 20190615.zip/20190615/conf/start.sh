#!/bin/sh
PWD=`pwd`

function remove {
        clear
        echo ======================================
        echo
        echo "rm -rf logs/*"
        echo "rm -rf webapps/alsok-g6-app"
        echo -n "remove these dirs ? [y/n] => "
        read ANS
        if [ $ANS = 'y' -o $ANS = 'Y' ]; then
                rm -rf logs/*
                rm -rf webapps/alsok-g6-app
        else
                echo "delete canceld"
                echo "$PWD is not started!"
                exit
        fi
        echo
        echo ======================================
}

if [ "$1" == "-x" ]; then
        remove
fi

nohup ./bin/startup.sh
tail -f logs/catalina.out