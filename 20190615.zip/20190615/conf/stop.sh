#!/bin/sh
./bin/shutdown.sh

#ps -u smuser1
PWD=`pwd`
while(true); do
        RET=`ps -ef | grep java |grep -v grep | grep $PWD|wc | awk '{print $1}'`
        if [ "$RET" = "0" ]; then
                echo "============================================================"
                echo
                echo "  $PWD is stopped!"
                echo
                echo "============================================================"
                break;
        else
                echo "......... $PWD is still running ......."
        fi
        sleep 1
done

rm -rf webapps/alsok-g6-app
rm -rf work/Catalina/localhost/alsok-g6-app
