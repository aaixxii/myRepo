USE XMDB
GO
IF EXISTS (SELECT * FROM sys.objects so JOIN sys.schemas sc ON so.schema_id = sc.schema_id WHERE so.name = N'BIO_LOB_DATA_INFO'  AND sc.name = N'XMDBUSER'  AND type in (N'U'))
BEGIN

  DECLARE @drop_statement nvarchar(500)

  DECLARE drop_cursor CURSOR FOR
      SELECT 'alter table '+quotename(schema_name(ob.schema_id))+
      '.'+quotename(object_name(ob.object_id))+ ' drop constraint ' + quotename(fk.name) 
      FROM sys.objects ob INNER JOIN sys.foreign_keys fk ON fk.parent_object_id = ob.object_id
      WHERE fk.referenced_object_id = 
          (
             SELECT so.object_id 
             FROM sys.objects so JOIN sys.schemas sc
             ON so.schema_id = sc.schema_id
             WHERE so.name = N'BIO_LOB_DATA_INFO'  AND sc.name = N'XMDBUSER'  AND type in (N'U')
           )

  OPEN drop_cursor

  FETCH NEXT FROM drop_cursor
  INTO @drop_statement

  WHILE @@FETCH_STATUS = 0
  BEGIN
     EXEC (@drop_statement)

     FETCH NEXT FROM drop_cursor
     INTO @drop_statement
  END

  CLOSE drop_cursor
  DEALLOCATE drop_cursor

  DROP TABLE [XMDBUSER].[BIO_LOB_DATA_INFO]
END 
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE 
[XMDBUSER].[BIO_LOB_DATA_INFO]
(
   [LOB_ID] varchar(60)  NOT NULL,
   [LOB_TYPE] varchar(40)  NOT NULL,
   [LOB_DATA] varbinary(max)  NULL,
   [CREATE_DATETIME] datetime2(6) NOT NULL
   
)
WITH (DATA_COMPRESSION = NONE)
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDBUSER.BIO_LOB_DATA_INFO',
        N'SCHEMA', N'XMDBUSER',
        N'TABLE', N'BIO_LOB_DATA_INFO'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDBUSER.BIO_LOB_DATA_INFO.LOB_ID',
        N'SCHEMA', N'XMDBUSER',
        N'TABLE', N'BIO_LOB_DATA_INFO',
        N'COLUMN', N'LOB_ID'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH

BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDBUSER.BIO_LOB_DATA_INFO.LOB_TYPE',
        N'SCHEMA', N'XMDBUSER',
        N'TABLE', N'BIO_LOB_DATA_INFO',
        N'COLUMN', N'LOB_TYPE'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH


BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDBUSER.BIO_LOB_DATA_INFO.LOB_DATA',
        N'SCHEMA', N'XMDBUSER',
        N'TABLE', N'BIO_LOB_DATA_INFO',
        N'COLUMN', N'LOB_DATA'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDBUSER.BIO_LOB_DATA_INFO.CREATE_DATETIME',
        N'SCHEMA', N'XMDBUSER',
        N'TABLE', N'BIO_LOB_DATA_INFO',
        N'COLUMN', N'CREATE_DATETIME'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO

ALTER TABLE [XMDBUSER].[BIO_LOB_DATA_INFO]
 ADD CONSTRAINT [BIO_LOB_DATA_INFO_PK]
   PRIMARY KEY
   CLUSTERED ([LOB_ID] ASC)
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDBUSER.BIO_LOB_DATA_INFO.BIO_LOB_DATA_INFO_PK',
        N'SCHEMA', N'XMDBUSER',
        N'TABLE', N'BIO_LOB_DATA_INFO',
        N'CONSTRAINT', N'BIO_LOB_DATA_INFO_PK'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO


USE XMDB
GO
IF EXISTS (
       SELECT * FROM sys.objects  so JOIN sys.indexes si
       ON so.object_id = si.object_id
       JOIN sys.schemas sc
       ON so.schema_id = sc.schema_id
       WHERE so.name = N'BIO_LOB_DATA_INFO'  AND sc.name = N'XMDBUSER'  AND si.name = N'BIO_LOB_DATA_INFO_IX02' AND so.type in (N'U'))
   DROP INDEX [BIO_LOB_DATA_INFO_IX02] ON [XMDBUSER].[BIO_LOB_DATA_INFO] 
GO
CREATE NONCLUSTERED INDEX [BIO_LOB_DATA_INFO_IX02] ON [XMDBUSER].[BIO_LOB_DATA_INFO]
(
   [LOB_ID] ASC
)
WITH (SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF) ON [PRIMARY] 
GO
BEGIN TRY
    EXEC sp_addextendedproperty
        N'MS_SSMA_SOURCE', N'XMDBUSER.BIO_LOB_DATA_INFO.BIO_LOB_DATA_INFO_IX02',
        N'SCHEMA', N'XMDBUSER',
        N'TABLE', N'BIO_LOB_DATA_INFO',
        N'INDEX', N'BIO_LOB_DATA_INFO_IX02'
END TRY
BEGIN CATCH
    IF (@@TRANCOUNT > 0) ROLLBACK
    PRINT ERROR_MESSAGE()
END CATCH
GO