package com.nec.biomatcher.identifier.searchcontroller.manager;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.PriorityBlockingQueue;

import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.IAtomicLong;
import com.hazelcast.core.IMap;
import com.hazelcast.core.IQueue;
import com.nec.biomatcher.comp.cluster.MatcherFunctionControlUtil;
import com.nec.biomatcher.comp.util.JobEntry;
import com.nec.biomatcher.core.framework.common.DelayedItem;
import com.nec.biomatcher.core.framework.common.TriKey;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentReader;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentSetProcessor;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentValuedHashMap;
import com.nec.biomatcher.core.framework.common.concurrent.VersionLatch;
import com.nec.biomatcher.identifier.searchcontroller.tasks.BiometricEventVersionAssignmentTask;
import com.nec.biomatcher.identifier.searchcontroller.util.ScSearchJobInfo;
import com.nec.biomatcher.identifier.util.ScSyncJobInfo;
import com.nec.biomatcher.identifier.util.SearchNodeCapacityGroupLoadInfo;

/**
 * The Interface BioSearchControllerManager.
 */
public interface BioSearchControllerManager {

	public HazelcastInstance getHazelcastInstance();

	public String getSearchControllerId();

	public DelayQueue<DelayedItem<String>> getSearchBrokerFailoverQueue();

	/**
	 * Notify segment changes to search broker.
	 *
	 * @param segmentId
	 *            the segment id
	 * @param segmentVersion
	 *            the segment version
	 */
	public void notifySegmentChangesToSearchBroker(Integer segmentId, Long segmentVersion);
	
	public void notifySearchJobCanceling(String message);

	/**
	 * Acquire segment change set writer backlog lock.
	 */
	public void acquireSegmentChangeSetWriterBacklogLock();

	/**
	 * Release segment change set writer backlog lock.
	 */
	public void releaseSegmentChangeSetWriterBacklogLock();

	public IMap<String, String> getBuildMissingChangeSetFileRequestMap();

	public VersionLatch getBuildMissingChangeSetFileRequestVersionLatch();

	/**
	 * Acquire search broker failover lock.
	 */
	public void acquireSearchBrokerFailoverLock();

	/**
	 * Release search broker failover lock.
	 */
	public void releaseSearchBrokerFailoverLock();

	public long getSegmentChangeSetWriterBacklogTimestamp();

	public void setSegmentChangeSetWriterBacklogTimestamp(long timestamp);

	public ConcurrentSkipListSet<String> getPendingExtractSearchJobIdSet();

	public ConcurrentValuedHashMap<String, PriorityBlockingQueue<JobEntry>> getPendingSearchJobQueueMap();

	public DelayQueue<DelayedItem<String>> getSearchJobQueueHousekeepingQueue();

	public ConcurrentValuedHashMap<String, ConcurrentReader<Boolean>> getSearchNodeOnlineStatusMap();

	/**
	 * Gets the search node online flag.
	 *
	 * @param searchNodeId
	 *            the search node id
	 * @return the search node online flag
	 */
	public boolean getSearchNodeOnlineFlag(String searchNodeId);

	public ConcurrentHashMap<String, ScSearchJobInfo> getSearchJobInfoMap();

	/**
	 * Acquire job assignment lock.
	 *
	 * @param searchNodeId
	 *            the search node id
	 */
	public void acquireJobAssignmentLock(String searchNodeId);

	public boolean tryAcquireJobAssignmentLock(String searchNodeId);

	public boolean tryAcquireJobAssignmentLock(String lockKey, long lockWaitMilli) throws InterruptedException;

	/**
	 * Release job assignment lock.
	 *
	 * @param searchNodeId
	 *            the search node id
	 */
	public void releaseJobAssignmentLock(String searchNodeId);

	public IQueue<Integer> getCreateFullSegmentFileRequestQueue();

	public IMap<Integer, String> getCreateFullSegmentFileRequestMap();

	public void submitReSegmentationRequest(Integer segmentId);

	public ConcurrentSkipListSet<String> getPendingExtractSyncJobIdSet();

	public ConcurrentHashMap<String, ScSyncJobInfo> getSyncJobInfoMap();

	public LinkedBlockingQueue<String> getPendingSyncJobQueue();

	public DelayQueue<DelayedItem<String>> getSyncJobQueueHousekeepingQueue();

	public ConcurrentSetProcessor<Integer> getEventVersionAssignmentProcesseor();

	public ConcurrentSetProcessor<Integer> getSearchBrokerNotificationProcessor();

	public ConcurrentValuedHashMap<TriKey<String, String, String>, SearchNodeCapacityGroupLoadInfo> getScSearchNodePartitionedLoadMap();

	public ConcurrentValuedHashMap<String, IAtomicLong> getSearchNodeOnlineFlagMap();

	public void notifySearchNodeOffline(String searchNodeId);

	public MatcherFunctionControlUtil getMatcherFunctionControlUtil();

	public BiometricEventVersionAssignmentTask getBiometricEventVersionAssignmentTask();

}
