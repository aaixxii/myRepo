package com.nec.biomatcher.identifier.searchcontroller.tasks;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.google.common.util.concurrent.AtomicLongMap;
import com.google.common.util.concurrent.RateLimiter;
import com.google.common.util.concurrent.Uninterruptibles;
import com.hazelcast.core.ILock;
import com.nec.biomatcher.comp.bioevent.BiometricEventService;
import com.nec.biomatcher.comp.cluster.ClusterInstance;
import com.nec.biomatcher.comp.cluster.ClusterInstanceRegistry;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherSegmentInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricEventInfo;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.manager.BioMatchManagerService;
import com.nec.biomatcher.core.framework.common.ShutdownHook;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentSetProcessor;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.identifier.searchcontroller.manager.BioSearchControllerManager;
import com.nec.biomatcher.identifier.util.SegmentationUtil;

/**
 * Task to assign version to biometric events
 * 
 * @author MAHESH
 *
 *         24-Jan-2017 Mahesh: Modified to protect against hazelcast cluster
 *         access errors
 */
public class BiometricEventVersionAssignmentTask implements Runnable {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(BiometricEventVersionAssignmentTask.class);

	/** The bio search controller manager. */
	private BioSearchControllerManager bioSearchControllerManager;

	private BiometricEventService biometricEventService;

	private BioMatcherConfigService bioMatcherConfigService;

	private BioMatchManagerService bioMatchManagerService;

	private BioParameterService bioParameterService;

	public ConcurrentSetProcessor<Integer> eventVersionAssignmentProcesseor;
	private final AtomicLongMap<Integer> eventVersionAssignmentEmptyLoopCounterMap = AtomicLongMap.create();
	private final AtomicLongMap<Integer> eventVersionAssignmentCheckTimestampMap = AtomicLongMap.create();

	private ClusterInstance clusterInstance;

	private ConcurrentHashMap<Integer, RateLimiter> segmentIdRateLimiterMap = new ConcurrentHashMap<>();

	/** The is initialized. */
	private boolean isInitialized = false;

	/**
	 * Instantiates a new segment change set writer task.
	 */
	public BiometricEventVersionAssignmentTask() {

	}

	public void notifyEventChangesForVersioning(Integer segmentId) {
		if (segmentId != null) {
			eventVersionAssignmentProcesseor.add(segmentId);
		}
	}

	public void notifyEventChangesForVersioning(Collection<Integer> segmentIdSet) {
		if (segmentIdSet != null) {
			eventVersionAssignmentProcesseor.addAll(segmentIdSet);
		}
	}

	@Override
	public void run() {
		logger.info("In BiometricEventVersionAssignmentTask.run");
		try {
			if (!isInitialized) {
				init();
			}

			while (!ShutdownHook.isShutdownFlag) {
				try {
					long segmentIdDelayItemMilli = bioParameterService.getParameterValue(
							"EVENT_VERSION_NOTIFICATION_DELAY_MILLI", "DEFAULT", TimeUnit.MINUTES.toMillis(3));

					loadSegmentIdListForVersionCheck(segmentIdDelayItemMilli);

					Uninterruptibles.sleepUninterruptibly(segmentIdDelayItemMilli, TimeUnit.MILLISECONDS);
				} catch (Throwable th) {
					logger.error("Error during BiometricEventVersionAssignmentTask.pollUpdatedSegmentChangeSetId: "
							+ th.getMessage(), th);
					Uninterruptibles.sleepUninterruptibly(500, TimeUnit.MILLISECONDS);
				}
			}
		} catch (Throwable th) {
			logger.error("Error in BiometricEventVersionAssignmentTask: " + th.getMessage(), th);
		}
	}

	public void assignEventDataVersion(Integer segmentId) {
		logger.debug("In assignEventDataVersion for segmentId: " + segmentId);

		long segmentIdDelayItemMilli = TimeUnit.MINUTES.toMillis(3);
		try {
			if (!isInitialized) {
				init();
			}

			if (clusterInstance == null) {
				clusterInstance = ClusterInstanceRegistry.getClusterInstance(BioComponentType.SC);
			}

			boolean isConversionMode = bioParameterService.getParameterValue("SC_CONVERSION_MODE_FLAG", "DEFAULT",
					false);

			double eventVersionAssignmentRatePerSecond = bioParameterService
					.getParameterValue("EVENT_VERSION_ASSIGNMENT_RATE_PER_SECOND", "DEFAULT", 5.0);
			RateLimiter rateLimiter = getRateLimiter(segmentId, eventVersionAssignmentRatePerSecond);
			rateLimiter.tryAcquire(1, TimeUnit.SECONDS);

			segmentIdDelayItemMilli = bioParameterService.getParameterValue("EVENT_VERSION_NOTIFICATION_DELAY_MILLI",
					"DEFAULT", segmentIdDelayItemMilli);

			ILock lock = null;
			try {
				lock = clusterInstance.getLock("EventVersionAssignmentLock_" + segmentId);
				boolean acquiredFlag = lock.tryLock();
				if (!acquiredFlag) {
					eventVersionAssignmentProcesseor.add(segmentId);
					return;
				}
			} catch (Throwable th) {
				logger.error("Error in assignEventDataVersion while acquiring lock for segmentId: " + segmentId + " : "
						+ th.getMessage(), th);
				return;
			}

			Long lastAssignedEventDataVersion = null;
			try {
				BioMatcherSegmentInfo bioMatcherSegmentInfo = bioMatchManagerService.getMatcherSegmentInfo(segmentId);
				if (bioMatcherSegmentInfo == null) {
					logger.warn(
							"In BiometricEventVersionAssignmentTask.assignEventDataVersion: Cannot find BioMatcherSegmentInfo with segmentId : "
									+ segmentId);
					segmentId = null;
					return;
				}

				List<BiometricEventInfo> biometricEventInfoList = biometricEventService
						.assignDataVersionToBiometricEvents(segmentId, isConversionMode);

				if (biometricEventInfoList.size() > 0) {
					lastAssignedEventDataVersion = biometricEventInfoList.get(biometricEventInfoList.size() - 1)
							.getDataVersion();
					eventVersionAssignmentEmptyLoopCounterMap.put(segmentId, 0);
				} else {
					eventVersionAssignmentEmptyLoopCounterMap.incrementAndGet(segmentId);
				}

				eventVersionAssignmentCheckTimestampMap.put(segmentId, System.currentTimeMillis());

				if (!isConversionMode) {
					SegmentationUtil.saveSegmentCanngeSetIndexFile(bioMatcherSegmentInfo.getBinId(), segmentId,
							bioMatcherSegmentInfo.getSegmentVersion() + 1, biometricEventInfoList);
				}
			} finally {
				if (lock != null) {
					lock.unlock();
				}
			}

			if (lastAssignedEventDataVersion != null) {
				bioSearchControllerManager.notifySegmentChangesToSearchBroker(segmentId, lastAssignedEventDataVersion);

				// During above lock period, some more changes might have
				// occurred for this segment
				if (eventVersionAssignmentEmptyLoopCounterMap.get(segmentId) < 2) {
					eventVersionAssignmentProcesseor.add(segmentId);
				}
			}
		} catch (Throwable th) {
			logger.error("Error in assignEventDataVersion for segmentId: " + segmentId + " : " + th.getMessage(), th);
		}
	}

	private void loadSegmentIdListForVersionCheck(long segmentIdDelayItemMilli) {
		try {
			final long currentTimestampMilli = System.currentTimeMillis();

			Map<Integer, Integer> segmentIdBinIdMap = bioMatcherConfigService.getSegmentIdBinIdMap();
			segmentIdBinIdMap.keySet().forEach(segmentId -> {
				long lastAssignmentTimestampMilli = eventVersionAssignmentCheckTimestampMap.get(segmentId);
				if ((lastAssignmentTimestampMilli + segmentIdDelayItemMilli) < currentTimestampMilli) {
					eventVersionAssignmentProcesseor.add(segmentId);
				}
			});
		} catch (Throwable th) {
			logger.error("Error in loadSegmentIdListForVersionCheck : " + th.getMessage(), th);
		}
	}

	private final RateLimiter getRateLimiter(Integer segmentId, double eventVersionAssignmentRatePerSecond) {
		RateLimiter rateLimiter = segmentIdRateLimiterMap.get(segmentId);
		if (rateLimiter == null) {
			rateLimiter = segmentIdRateLimiterMap.computeIfAbsent(segmentId, (newSegmentId) -> {
				return RateLimiter.create(eventVersionAssignmentRatePerSecond, 1, TimeUnit.SECONDS);
			});
		}

		if (rateLimiter.getRate() != eventVersionAssignmentRatePerSecond) {
			rateLimiter.setRate(eventVersionAssignmentRatePerSecond);
		}

		return rateLimiter;
	}

	/**
	 * Inits the.
	 */
	private final void init() {
		bioSearchControllerManager = SpringServiceManager.getBean("bioSearchControllerManager");
		biometricEventService = SpringServiceManager.getBean("biometricEventService");
		bioMatcherConfigService = SpringServiceManager.getBean("bioMatcherConfigService");
		bioMatchManagerService = SpringServiceManager.getBean("bioMatchManagerService");
		bioParameterService = SpringServiceManager.getBean("bioParameterService");

		eventVersionAssignmentProcesseor = bioSearchControllerManager.getEventVersionAssignmentProcesseor();

		isInitialized = true;
	}

}
