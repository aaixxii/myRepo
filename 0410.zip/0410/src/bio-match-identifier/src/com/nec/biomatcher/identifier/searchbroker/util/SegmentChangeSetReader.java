package com.nec.biomatcher.identifier.searchbroker.util;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;

import com.google.common.base.Throwables;
import com.google.common.util.concurrent.Uninterruptibles;
import com.hazelcast.core.ILock;
import com.nec.biomatcher.comp.bioevent.BiometricEventService;
import com.nec.biomatcher.comp.bioevent.exception.BiometricEventServiceException;
import com.nec.biomatcher.comp.cluster.ClusterInstance;
import com.nec.biomatcher.comp.cluster.ClusterInstanceRegistry;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherSegmentInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricEventInfo;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.manager.BioMatchManagerService;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateParser;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateUtil;
import com.nec.biomatcher.core.framework.common.FileUtils;
import com.nec.biomatcher.core.framework.common.GsonSerializer;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentValuedHashMap;
import com.nec.biomatcher.core.framework.common.concurrent.VersionLatch;
import com.nec.biomatcher.identifier.util.SegmentChangeSetIndexInfo;
import com.nec.biomatcher.identifier.util.SegmentationUtil;
import com.nec.biomatcher.identifier.util.SegmentationUtil.SegmentChangeSetConstants;
import com.nec.biomatcher.spec.transfer.datadistribution.SegmentStatus;
import com.nec.biomatcher.spec.transfer.datadistribution.SegmentUpdateDto;
import com.nec.biomatcher.spec.transfer.model.KeyValuePair;

public class SegmentChangeSetReader implements InitializingBean {
	private static final Logger logger = Logger.getLogger(SegmentChangeSetReader.class);

	private ConcurrentHashMap<Integer, Long> centralSegmentVersionMap = new ConcurrentHashMap<>();
	private ConcurrentHashMap<String, VersionLatch> searchNodeSegmentDataVersionLatchMap = new ConcurrentHashMap<>();
	private ConcurrentValuedHashMap<Integer, ConcurrentSkipListSet<Long>> inProgressChangeSetFileCreationMap = new ConcurrentValuedHashMap<>(
			segmentId -> new ConcurrentSkipListSet<>());

	private BiometricEventService biometricEventService;
	private BioMatchManagerService bioMatchManagerService;
	private BioMatcherConfigService bioMatcherConfigService;
	private BioParameterService bioParameterService;

	public void afterPropertiesSet() throws Exception {

	}

	public ConcurrentHashMap<Integer, Long> getCentralSegmentVersionMap() {
		return centralSegmentVersionMap;
	}

	public SegmentUpdateDto getSegmentChangesAfter(int segmentId, long lastSyncSegmentVersion,
			AtomicBoolean lockAcquiredFailedFlag, AtomicLong totalChangeSetSize) throws Exception {

		KeyValuePair<Path, byte[]> changeSetFileInfo = getSegmentChangesAfterSegmentVersion(segmentId,
				lastSyncSegmentVersion, lockAcquiredFailedFlag);
		if (changeSetFileInfo == null || (changeSetFileInfo.getKey() == null && changeSetFileInfo.getValue() == null)) {
			// No changes
			return null;
		}

		Path segmentChangeSetFile = changeSetFileInfo.getKey();
		byte[] segmentChangeSetData = changeSetFileInfo.getValue();

		int recordCount = 0;
		long startSegmentVersion = 0;
		long endSegmentVersion = 0;

		try {
			if (segmentChangeSetData == null) {
				segmentChangeSetData = Files.readAllBytes(segmentChangeSetFile);
			}

			if (segmentChangeSetData.length <= SegmentChangeSetConstants.EMPTY_HEADER_BYTES.length) {
				throw new Exception("Invalid segment changeset content size: " + segmentChangeSetData.length
						+ ", expected grater than: " + SegmentChangeSetConstants.EMPTY_HEADER_BYTES.length);
			}

			ByteBuffer segmentChangeSetBuf = ByteBuffer.wrap(segmentChangeSetData)
					.order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);

			recordCount = segmentChangeSetBuf.getInt(SegmentChangeSetConstants.HEADER_RECORD_COUNT_POS);
			startSegmentVersion = segmentChangeSetBuf
					.getLong(SegmentChangeSetConstants.HEADER_START_SEGMENT_VERSION_POS);
			endSegmentVersion = segmentChangeSetBuf.getLong(SegmentChangeSetConstants.HEADER_END_SEGMENT_VERSION_POS);
			int segmentChangeSetContentSize = segmentChangeSetBuf
					.getInt(SegmentChangeSetConstants.HEADER_CHANGESET_CONTENT_SIZE_POS);

			if (segmentChangeSetData.length != (SegmentChangeSetConstants.EMPTY_HEADER_BYTES.length
					+ segmentChangeSetContentSize)) {
				logger.error("In getSegmentChangesAfter: Invalid segment changeset content size: "
						+ segmentChangeSetData.length + ", expected size : "
						+ (SegmentChangeSetConstants.EMPTY_HEADER_BYTES.length + segmentChangeSetContentSize)
						+ ", segmentId : " + segmentId + ", segmentChangeSetFile: " + segmentChangeSetFile);
				if (segmentChangeSetFile != null) {
					FileUtils.deleteFileQuietly(segmentChangeSetFile);
				}
				return null;
			}

			segmentChangeSetData = Arrays.copyOfRange(segmentChangeSetData,
					SegmentChangeSetConstants.SEGMENT_CHANGESET_CONTENT_POS, segmentChangeSetData.length);
		} catch (Throwable th) {
			logger.error("Error in getSegmentChangesAfter for segmentId : " + segmentId + ", lastSyncSegmentVersion: "
					+ lastSyncSegmentVersion + ", segmentChangeSetFile: " + segmentChangeSetFile + " : "
					+ th.getMessage(), th);
			if (segmentChangeSetFile != null) {
				FileUtils.deleteFileQuietly(segmentChangeSetFile);
			}
			return null;
		}

		if (recordCount == 0) {
			logger.debug("Record count is 0 for segmentId : " + segmentId + ", lastSyncSegmentVersion: "
					+ lastSyncSegmentVersion);
			return null;
		}

		SegmentUpdateDto segmentUpdateDto = new SegmentUpdateDto();
		segmentUpdateDto.setSegmentId(segmentId);
		segmentUpdateDto.setSegmentStatus(SegmentStatus.ACTIVE);
		segmentUpdateDto.setTotalRecords(recordCount);
		segmentUpdateDto.setStartSegmentVersion(startSegmentVersion);
		segmentUpdateDto.setEndSegmentVersion(endSegmentVersion);
		segmentUpdateDto.setSegmentChangeSetData(segmentChangeSetData);

		totalChangeSetSize.addAndGet(segmentChangeSetData.length);

		return segmentUpdateDto;
	}

	private KeyValuePair<Path, byte[]> getSegmentChangesAfterSegmentVersion(int segmentId, long lastSyncSegmentVersion,
			AtomicBoolean lockAcquiredFailedFlag) throws Exception {
		final Map<Integer, Integer> segmentIdBinIdMap = bioMatcherConfigService.getSegmentIdBinIdMap();
		final Integer binId = segmentIdBinIdMap.get(segmentId);
		if (binId == null) {
			return null;
		}

		ConcurrentSkipListSet<Long> inProgressChangeSetFileCreationSet = inProgressChangeSetFileCreationMap
				.getValue(segmentId);
		if (inProgressChangeSetFileCreationSet.contains(lastSyncSegmentVersion)) {
			// Currently changeset file creation is in progress by some other
			// thread
			Uninterruptibles.sleepUninterruptibly(50, TimeUnit.MILLISECONDS);
			if (inProgressChangeSetFileCreationSet.contains(lastSyncSegmentVersion)) {
				if (logger.isDebugEnabled())
					logger.debug(
							"In getSegmentChangesAfterSegmentVersion: Ignoring because some other thread is trying to build segmentchangeset for segmentId: "
									+ segmentId + ", lastSyncSegmentVersion: " + lastSyncSegmentVersion);
				lockAcquiredFailedFlag.set(true);
				return null;
			}
		}

		Calendar cal = Calendar.getInstance();

		Path segChangeSetFilePath = SegmentationUtil.getSegmentChangeSetFilePath(segmentIdBinIdMap.get(segmentId),
				segmentId, lastSyncSegmentVersion + 1, cal.get(Calendar.HOUR_OF_DAY), "dat");
		if (Files.exists(segChangeSetFilePath)) {
			return new KeyValuePair<>(segChangeSetFilePath, null);
		} else {
			if (cal.get(Calendar.MINUTE) < 5) {
				cal.add(Calendar.HOUR_OF_DAY, -1);
				Path oldSegChangeSetIndexFilePath = SegmentationUtil.getSegmentChangeSetFilePath(
						segmentIdBinIdMap.get(segmentId), segmentId, lastSyncSegmentVersion + 1,
						cal.get(Calendar.HOUR_OF_DAY), "dat");
				if (Files.exists(oldSegChangeSetIndexFilePath)) {
					return new KeyValuePair<>(oldSegChangeSetIndexFilePath, null);
				}
			}
		}

		String lockKey = "SEG_WRITER_" + segmentId + "_" + Math.floorMod(lastSyncSegmentVersion, 5);
		ClusterInstance clusterInstance = ClusterInstanceRegistry.getClusterInstance(BioComponentType.SB);

		ILock lock = clusterInstance.getLock(lockKey);
		boolean acquireFlag = lock.tryLock();
		if (!acquireFlag) {
			lockAcquiredFailedFlag.set(true);
			// Some other thread might be creating the segment changeset file,
			// So for now we treat it as no more changes for this segmentId
			// after lastSyncSegmentVersion
			if (logger.isDebugEnabled())
				logger.debug(
						"In getSegmentChangesAfterSegmentVersion: Ignoring because some other thread is trying to build segmentchangeset for segmentId: "
								+ segmentId + ", lastSyncSegmentVersion: " + lastSyncSegmentVersion + ", lockKey: "
								+ lockKey);

			return null;
		}

		try {
			if (Files.exists(segChangeSetFilePath)) {
				return new KeyValuePair<>(segChangeSetFilePath, null);
			}

			List<BiometricEventInfo> biometricEventInfoList = getBiometricEventListAfterSegmentVersion(binId, segmentId,
					lastSyncSegmentVersion);
			if (biometricEventInfoList == null || biometricEventInfoList.size() == 0) {
				return null;
			}

			List<Long> errorDataVersionIdList = new ArrayList<>();
			MeghaTemplateParser meghaTemplateParser = bioMatcherConfigService.getBinIdMeghaTemplateParserMap()
					.get(binId);

			KeyValuePair<Path, byte[]> changeSetFileInfo = null;

			inProgressChangeSetFileCreationSet.add(lastSyncSegmentVersion);
			try {
				changeSetFileInfo = SegmentationUtil.saveSegmentChangeSetFile(binId, segmentId, lastSyncSegmentVersion,
						biometricEventInfoList, errorDataVersionIdList, meghaTemplateParser);
			} finally {
				inProgressChangeSetFileCreationSet.remove(lastSyncSegmentVersion);
			}

			if (errorDataVersionIdList.size() > 0) {
				SegmentationUtil.saveNotificationsFromSearchBroker(binId, segmentId, null, errorDataVersionIdList);
			}

			return changeSetFileInfo;
		} catch (Throwable th) {
			logger.error("Error in getSegmentChangesAfterSegmentVersion binId: " + binId + ", segmentId: " + segmentId
					+ ", segmentVersion: " + lastSyncSegmentVersion + " : " + th.getMessage(), th);
			throw Throwables.propagate(th);
		} finally {
			lock.unlock();
		}
	}

	private List<BiometricEventInfo> getBiometricEventListAfterSegmentVersion(int binId, int segmentId,
			long lastSyncSegmentVersion) throws BiometricEventServiceException {
		/**
		 * Since this getBiometricEventListAfterSegmentVersion method is only
		 * called if lastSyncSegmentVersion < centralSegmentDataVersion, if we
		 * cannot find the events in index file, we need to load events from
		 * database
		 */

		int maxRecordsToLoad = bioParameterService.getParameterValue("MAX_SEGMENT_CHANGES_TO_LOAD_PER_REQUEST",
				"DEFAULT", 300);
		List<BiometricEventInfo> biometricEventInfoList = getSegmentChangeSetIndexData(binId, segmentId,
				lastSyncSegmentVersion + 1, maxRecordsToLoad);
		if (CollectionUtils.isEmpty(biometricEventInfoList)) {
			biometricEventInfoList = biometricEventService.getBiometricEventInfoListBySegmentIdForSync(segmentId,
					lastSyncSegmentVersion, maxRecordsToLoad);
		}

		return biometricEventInfoList;
	}

	public final List<BiometricEventInfo> getSegmentChangeSetIndexData(Integer binId, Integer segmentId,
			Long firstAssignedEventDataVersion, int maxRecordsToLoad) {
		Path segChangeSetIndexFilePath = null;
		try {
			Calendar cal = Calendar.getInstance();

			segChangeSetIndexFilePath = SegmentationUtil.getSegmentChangeSetFilePath(binId, segmentId,
					firstAssignedEventDataVersion, cal.get(Calendar.HOUR_OF_DAY), "idx");

			if (!Files.exists(segChangeSetIndexFilePath)) {
				if (cal.get(Calendar.MINUTE) < 5) {
					cal.add(Calendar.HOUR_OF_DAY, -1);
					segChangeSetIndexFilePath = SegmentationUtil.getSegmentChangeSetFilePath(binId, segmentId,
							firstAssignedEventDataVersion, cal.get(Calendar.HOUR_OF_DAY), "idx");
					if (!Files.exists(segChangeSetIndexFilePath)) {
						return null;
					}
				} else {
					return null;
				}
			}

			List<BiometricEventInfo> biometricEventInfoList = new ArrayList<>();

			loadSegmentChangeSetIndexData(segmentId, segChangeSetIndexFilePath, maxRecordsToLoad,
					biometricEventInfoList);

			return biometricEventInfoList;
		} catch (Throwable th) {
			logger.error(
					"Error in getSegmentCanngeSetIndexData: binId: " + binId + ", segmentId: " + segmentId
							+ ", firstAssignedEventDataVersion: " + firstAssignedEventDataVersion
							+ ", segChangeSetIndexFilePath: " + segChangeSetIndexFilePath + " : " + th.getMessage(),
					th);
		}

		return null;
	}

	public final void loadSegmentChangeSetIndexData(Integer segmentId, Path segChangeSetIndexFilePath,
			int maxRecordsToLoad, List<BiometricEventInfo> biometricEventInfoList) {
		if (logger.isDebugEnabled())
			logger.debug("In loadSegmentChangeSetIndexData: segmentId: " + segmentId + ", segChangeSetIndexFilePath: "
					+ segChangeSetIndexFilePath + ", maxRecordsToLoad: " + maxRecordsToLoad);

		try {
			SegmentChangeSetIndexInfo segmentChangeSetIndexInfo = null;

			byte[] indexBuf = Files.readAllBytes(segChangeSetIndexFilePath);
			if (indexBuf != null && indexBuf.length > 0) {
				String json = new String(indexBuf, StandardCharsets.UTF_8);
				if (json != null) {
					segmentChangeSetIndexInfo = GsonSerializer.fromJson(json, SegmentChangeSetIndexInfo.class);
				}
			}

			if (segmentChangeSetIndexInfo == null || !segmentChangeSetIndexInfo.hasBiometricEventInfoList()) {
				return;
			}

			biometricEventInfoList.addAll(segmentChangeSetIndexInfo.getBiometricEventInfoList());

			if (biometricEventInfoList.size() < maxRecordsToLoad) {
				Long lastReadDataVersion = biometricEventInfoList.get(biometricEventInfoList.size() - 1)
						.getDataVersion();

				if (lastReadDataVersion < getCentralSegmentDataVersion(segmentId)) {
					Path nextSegChangeSetIndexFilePath = segChangeSetIndexFilePath
							.resolveSibling(segmentId + "_" + (lastReadDataVersion + 1) + ".idx");

					if (Files.exists(nextSegChangeSetIndexFilePath)) {
						loadSegmentChangeSetIndexData(segmentId, nextSegChangeSetIndexFilePath, maxRecordsToLoad,
								biometricEventInfoList);
					}
				}
			}
		} catch (Throwable th) {
			logger.error("Error in loadSegmentChangeSetIndexData: segmentId: " + segmentId
					+ ", segChangeSetIndexFilePath: " + segChangeSetIndexFilePath + " : " + th.getMessage(), th);
		}
	}

	public void reloadCentralSegmentVersionMap(String searchBrokerId) {
		try {
			Map<Integer, Long> segmentIdVersionMap = bioMatchManagerService
					.getMatcherSegmentVersionMapBySearchBrokerId(searchBrokerId);
			centralSegmentVersionMap.putAll(segmentIdVersionMap);

			Map<Integer, Set<String>> assignedSegmentIdSearchNodeIdListMap = bioMatcherConfigService
					.getAssignedSegmentIdSearchNodeIdListMapBySearchBrokerId(searchBrokerId);

			for (Entry<Integer, Long> entry : segmentIdVersionMap.entrySet()) {
				Integer segmentId = entry.getKey();
				Long segmentVersion = entry.getValue();
				if (segmentVersion != null && segmentVersion > -1L) {
					Set<String> searchNodeIdSet = assignedSegmentIdSearchNodeIdListMap.get(segmentId);
					if (searchNodeIdSet != null) {
						searchNodeIdSet.forEach((searchNodeId) -> {
							getSearchNodeSegmentDataChangedLatch(searchNodeId).incrementVersion();
						});
					}
				}
			}
		} catch (Throwable th) {
			logger.error("Error during reloadCentralSegmentVersionMap searchBrokerId: " + searchBrokerId + " : "
					+ th.getMessage(), th);
		}
	}

	public final Long getCentralSegmentDataVersion(Integer segmentId) {
		Long centralSegmentDataVersion = centralSegmentVersionMap.get(segmentId);
		if (centralSegmentDataVersion == null) {
			centralSegmentDataVersion = centralSegmentVersionMap.computeIfAbsent(segmentId, (newSegmentId) -> {
				try {
					BioMatcherSegmentInfo bioMatcherSegmentInfo = bioMatchManagerService
							.getMatcherSegmentInfo(segmentId);
					if (bioMatcherSegmentInfo != null) {
						return bioMatcherSegmentInfo.getSegmentVersion();
					} else {
						return -1L;
					}
				} catch (Throwable th) {
					logger.error("In getCentralSegmentDataVersion: segmentId: " + segmentId + " : " + th.getMessage(),
							th);
					return -1L;
					// throw Throwables.propagate(th);
				}
			});
		}

		return centralSegmentDataVersion == null ? -1L : centralSegmentDataVersion;
	}

	public void notifySegmentChanges(String searchBrokerId, Integer segmentId, Long centralSegmentVersion)
			throws Exception {
		if (segmentId == null || centralSegmentVersion == null) {
			return;
		}

		Long newAssignedSegmentVersion = compareAndSetSegmentDataVersion(segmentId, centralSegmentVersion);

		if (logger.isDebugEnabled())
			logger.debug("In notifySegmentChanges: received changes from SC for segmentId: " + segmentId
					+ ", centralSegmentVersion: " + centralSegmentVersion + ", newAssignedSegmentVersion: "
					+ newAssignedSegmentVersion);

		if (!bioMatcherConfigService.getAssignedSegmentIdListBySearchBrokerId(searchBrokerId).contains(segmentId)) {
			return;
		}

		if (centralSegmentVersion.equals(newAssignedSegmentVersion)) {
			Map<Integer, Set<String>> assignedSegmentIdSearchNodeIdListMap = bioMatcherConfigService
					.getAssignedSegmentIdSearchNodeIdListMapBySearchBrokerId(searchBrokerId);

			Set<String> searchNodeIdSet = assignedSegmentIdSearchNodeIdListMap.get(segmentId);
			if (searchNodeIdSet != null) {
				searchNodeIdSet.forEach((searchNodeId) -> {
					getSearchNodeSegmentDataChangedLatch(searchNodeId).incrementVersion();
				});
			}
		}
	}

	public Long compareAndSetSegmentDataVersion(Integer segmentId, Long segmentDataVersion) {
		final long newSegmentDataVersion = segmentDataVersion == null ? -1L : segmentDataVersion.longValue();
		return centralSegmentVersionMap.compute(segmentId, (currSegmentId, currSegmentVersion) -> {
			if (currSegmentVersion == null || currSegmentVersion < newSegmentDataVersion) {
				return newSegmentDataVersion;
			} else {
				return currSegmentVersion;
			}
		});
	}

	public VersionLatch getSearchNodeSegmentDataChangedLatch(String searchNodeId) {
		VersionLatch versionLatch = searchNodeSegmentDataVersionLatchMap.get(searchNodeId);
		if (versionLatch == null) {
			versionLatch = searchNodeSegmentDataVersionLatchMap.computeIfAbsent(searchNodeId,
					newSearchNodeId -> new VersionLatch());
		}
		return versionLatch;
	}

	public void setBiometricEventService(BiometricEventService biometricEventService) {
		this.biometricEventService = biometricEventService;
	}

	public void setBioMatchManagerService(BioMatchManagerService bioMatchManagerService) {
		this.bioMatchManagerService = bioMatchManagerService;
	}

	public void setBioMatcherConfigService(BioMatcherConfigService bioMatcherConfigService) {
		this.bioMatcherConfigService = bioMatcherConfigService;
	}

	public void setBioParameterService(BioParameterService bioParameterService) {
		this.bioParameterService = bioParameterService;
	}

}
