package com.nec.biomatcher.identifier.searchcontroller.tasks;

import java.util.List;

import org.apache.log4j.Logger;

import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherSegmentInfo;
import com.nec.biomatcher.comp.manager.BioMatchManagerService;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.identifier.searchcontroller.manager.BioSearchControllerManager;

/**
 * The Class SegmentChangeSetBacklogTask.
 */
public class SegmentChangeSetBacklogTask implements Runnable {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(SegmentChangeSetBacklogTask.class);

	/**
	 * Instantiates a new segment change set backlog task.
	 */
	public SegmentChangeSetBacklogTask() {
	}

	@Override
	public void run() {
		Thread.currentThread().setName("SEG_CHANGESET_BACKLOG_TASK");
		logger.info("In SegmentChangeSetBacklogTask.run");
		try {
			BioSearchControllerManager bioSearchControllerManager = SpringServiceManager
					.getBean("bioSearchControllerManager");
			BioMatchManagerService bioMatchManagerService = SpringServiceManager.getBean("bioMatchManagerService");

			bioSearchControllerManager.acquireSegmentChangeSetWriterBacklogLock();
			try {
				long segmentChangeSetBacklogCheckTimestamp = bioSearchControllerManager
						.getSegmentChangeSetWriterBacklogTimestamp();
				if (segmentChangeSetBacklogCheckTimestamp > 0) {
					logger.info("SegmentChangeSetBacklogTask is already done: timestamp: "
							+ segmentChangeSetBacklogCheckTimestamp);
					return;
				}

				List<BioMatcherSegmentInfo> bioMatcherSegmentInfoList = bioMatchManagerService
						.getMatcherSegmentInfoList();
				for (BioMatcherSegmentInfo bioMatcherSegmentInfo : bioMatcherSegmentInfoList) {
					bioSearchControllerManager.getBiometricEventVersionAssignmentTask()
							.notifyEventChangesForVersioning(bioMatcherSegmentInfo.getSegmentId());
					bioSearchControllerManager.getSearchBrokerNotificationProcessor()
							.add(bioMatcherSegmentInfo.getSegmentId());
					logger.info("In SegmentChangeSetBacklogTask: After notifyEventChangesForVersioning for segmentId: "
							+ bioMatcherSegmentInfo.getSegmentId() + ", matcherSegmentVersion: "
							+ bioMatcherSegmentInfo.getSegmentVersion());
				}

				bioSearchControllerManager.setSegmentChangeSetWriterBacklogTimestamp(System.currentTimeMillis());
			} finally {
				bioSearchControllerManager.releaseSegmentChangeSetWriterBacklogLock();
			}
		} catch (Throwable th) {
			logger.error("Error in SegmentChangeSetBacklogTask: " + th.getMessage(), th);
		}
	}

}
