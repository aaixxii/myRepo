package com.nec.biomatcher.identifier.searchbroker.manager;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.LinkedBlockingDeque;

import com.hazelcast.core.IQueue;
import com.nec.biomatcher.core.framework.common.concurrent.BooleanLatch;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentValuedHashMap;
import com.nec.biomatcher.identifier.searchbroker.util.SearchBrokerClusterClient;
import com.nec.biomatcher.spec.transfer.datadistribution.SegmentReportDto;
import com.nec.biomatcher.spec.transfer.datadistribution.SegmentSyncResponseDto;

/**
 * The Interface BioSearchBrokerManager.
 */
public interface BioSearchBrokerManager {
	public String getSearchBrokerId();

	public BooleanLatch getSearchBrokerEnabledFlag();

	public BooleanLatch getSearchBrokerConnectedFlag();

	public CopyOnWriteArraySet<String> getOnlineSearchNodeIdList();

	public CopyOnWriteArraySet<String> getOfflineSearchNodeIdList();

	/**
	 * Gets the search node online flag.
	 *
	 * @param searchNodeId
	 *            the search node id
	 * @return the search node online flag
	 */
	public BooleanLatch getSearchNodeOnlineFlag(String searchNodeId);

	public ConcurrentValuedHashMap<String, BooleanLatch> getSearchNodeOnlineStatusMap();

	public SearchBrokerClusterClient getSearchBrokerClusterClient();

	/**
	 * Gets the search node segment version map.
	 *
	 * @param searchNodeId
	 *            the search node id
	 * @return the search node segment version map
	 */
	public ConcurrentHashMap<Integer, SegmentReportDto> getSearchNodeSegmentVersionMap(String searchNodeId);

	public LinkedBlockingDeque<SegmentSyncResponseDto> getNotifySyncCompletedQueue();

	/**
	 * Notify search node online.
	 *
	 * @param searchNodeId
	 *            the search node id
	 */
	public void notifySearchNodeOnline(String searchNodeId);

	/**
	 * Notify search node offline.
	 *
	 * @param searchNodeId
	 *            the search node id
	 */
	public void notifySearchNodeOffline(String searchNodeId);

	/**
	 * Notify search node segment version to controller.
	 *
	 * @param searchNodeId
	 *            the search node id
	 * @param searchNodeSegmentVersionMap
	 *            the search node segment version map
	 */
	public void notifySearchNodeSegmentVersionToController(String searchNodeId,
			Map<Integer, Long> searchNodeSegmentVersionMap);

	/**
	 * Start search node data distribution tasks.
	 *
	 * @throws Exception
	 *             the exception
	 */
	public void startSearchNodeDataDistributionTasks() throws Exception;

	/**
	 * Stop search node data distribution tasks.
	 *
	 * @throws Exception
	 *             the exception
	 */
	public void stopSearchNodeDataDistributionTasks() throws Exception;

	/**
	 * Check search node connection.
	 *
	 * @param searchNodeId
	 *            the search node id
	 * @param firstRunFlag
	 *            the first run flag
	 * @return true, if successful
	 */
	public boolean checkSearchNodeConnection(String searchNodeId, boolean firstRunFlag);

	/**
	 * Gets the search node the search group job queue
	 * 
	 * @param searchNodeGroupId
	 * @return the search node group job queue
	 */
	public IQueue<byte[]> getSearchNodeGroupJobQueue(String searchNodeGroupId);

	/**
	 * Adds the search node load.
	 *
	 * @param searchNodeId
	 *            the search node id
	 * @param loadValue
	 *            the load value
	 * @return the int
	 */
	public int addSearchNodeLoad(String searchNodeId, int loadValue);
}
