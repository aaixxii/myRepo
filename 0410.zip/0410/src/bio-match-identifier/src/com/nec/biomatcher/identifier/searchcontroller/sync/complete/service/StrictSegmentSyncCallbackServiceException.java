package com.nec.biomatcher.identifier.searchcontroller.sync.complete.service;

/**
 * 
 * @author 000001A006PBP
 *
 */
public class StrictSegmentSyncCallbackServiceException extends RuntimeException {

	private static final long serialVersionUID = 3980389304234269230L;
	private String jobId;
	private String snId;
	private Integer binId;
	private Integer segId;
	private String errmsg;
	private String errCode;

	/**
	 * @param message
	 */
	public StrictSegmentSyncCallbackServiceException(String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public StrictSegmentSyncCallbackServiceException(Throwable cause) {
		super(cause);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public StrictSegmentSyncCallbackServiceException(String message, Throwable cause) {
		super(message, cause);
	}

	public String getSnId() {
		return snId;
	}

	public void setSnId(String snId) {
		this.snId = snId;
	}

	public Integer getBinId() {
		return binId;
	}

	public void setBinId(Integer binId) {
		this.binId = binId;
	}

	public Integer getSegId() {
		return segId;
	}

	public void setSegId(Integer segId) {
		this.segId = segId;
	}

	public String getErrmsg() {
		return errmsg;
	}

	public void setErrmsg(String errmsg) {
		this.errmsg = errmsg;
	}

	public String getErrCode() {
		return errCode;
	}

	public void setErrCode(String errCode) {
		this.errCode = errCode;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
}