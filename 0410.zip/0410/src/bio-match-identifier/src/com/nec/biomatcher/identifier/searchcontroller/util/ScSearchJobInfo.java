package com.nec.biomatcher.identifier.searchcontroller.util;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ConcurrentSkipListMap;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.nec.biomatcher.comp.cluster.MatcherFunctionControlUtil;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.metrics.MetricsUtil;
import com.nec.biomatcher.comp.util.JobEntry;
import com.nec.biomatcher.core.framework.common.BiKey;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentValuedHashMap;
import com.nec.biomatcher.identifier.util.SearchNodeCapacityGroupLoadInfo;
import com.nec.megha.proto.search.SearchResponseProto.SearchResponse;

public class ScSearchJobInfo {
	public static final Logger logger = Logger.getLogger(ScSearchJobInfo.class);

	/** The search job id. */
	public final String searchJobId;

	/** The max candidates. */
	public final Integer maxCandidates;

	/** The callback url. */
	public final String callbackUrl;

	/** The job mode. */
	public final String jobMode;

	public final long jobTimeoutMilli;

	public final String capacityGroupKey;

	public final Set<Integer> binIdSet;

	public final ConcurrentValuedHashMap<Integer, ConcurrentSkipListSet<String>> pendingSegmentIdRequestKeySetMap;

	public final Map<Integer, Long> taggedSegmentVersionMap;

	public final ConcurrentSkipListMap<String, Long> inProgressSegmentJobIdSet;

	public final ScSearchResultInfo scSearchResultInfo;

	/** The create date time milli. */
	public final long createDateTimeMilli = System.currentTimeMillis();

	public final AtomicInteger totalAssignedSegmentJobCount = new AtomicInteger(0);
	public final AtomicInteger totalBatchedSegmentJobCount = new AtomicInteger(0);

	/** The fisrt assignment date time milli. */
	public volatile long fisrtAssignmentDateTimeMilli = -1;

	/** The last assignment date time milli. */
	public long lastAssignmentDateTimeMilli = -1;

	/** The job completed date time milli. */
	public long jobCompletedDateTimeMilli = -1;

	/** The has errors flag. */
	public volatile boolean hasErrorsFlag = false;

	/** The job completed flag. */
	public volatile boolean jobCompletedFlag = false;

	private volatile boolean includeExtractionResultFlag = false;

	private long jobRescheduledCount = 0;

	/** The extraction job id. */
	private String extractionJobId;

	private long extractionCompletedDateTimeMilli = -1;

	private long templateVerifyTimeTakenMilli = 0L;

	private boolean timeoutErrorFlag = false;

	private boolean searchExtractErrorFlag = false;

	private JobEntry jobEntry;

	private final String defaultSearchFunctionId;
	private boolean functionSlotAcquiredFlag;

	public final ReadWriteLock assignmentInProgressLock = new ReentrantReadWriteLock(true);

	public final Semaphore assignmentInProgressSemaphore = new Semaphore(1, true);

	public final ConcurrentSkipListSet<String> releasedSegmentJobIdSet = new ConcurrentSkipListSet<>();

	public final ConcurrentLinkedQueue<SearchResponse> stagingSearchResponseQueue = new ConcurrentLinkedQueue<>();

	public final Semaphore stagingSearchResponseTaskSemaphore = new Semaphore(1);

	private final String functionCapacityGroupKey;

	public ScSearchJobInfo(String searchJobId, Integer priority, Integer maxCandidates, String callbackUrl,
			String jobMode, long jobTimeoutMilli, String capacityGroupKey, Set<Integer> binIdSet,
			ConcurrentValuedHashMap<Integer, ConcurrentSkipListSet<String>> segmentIdRequestKeySetMap,
			Map<Integer, Long> taggedSegmentVersionMap, String defaultSearchFunctionId, int internalMaxCandidates) {
		this.searchJobId = searchJobId;
		this.maxCandidates = maxCandidates;
		this.callbackUrl = callbackUrl;
		this.jobMode = jobMode;
		this.jobTimeoutMilli = jobTimeoutMilli;
		this.capacityGroupKey = StringUtils.isBlank(capacityGroupKey) ? "0" : capacityGroupKey;
		this.binIdSet = binIdSet;
		this.pendingSegmentIdRequestKeySetMap = segmentIdRequestKeySetMap;
		this.taggedSegmentVersionMap = taggedSegmentVersionMap;
		this.defaultSearchFunctionId = defaultSearchFunctionId;

		this.jobEntry = new JobEntry(searchJobId, priority);
		this.inProgressSegmentJobIdSet = new ConcurrentSkipListMap<>();
		this.scSearchResultInfo = new ScSearchResultInfo(maxCandidates, internalMaxCandidates);
		this.functionCapacityGroupKey = capacityGroupKey.contains("~") ? capacityGroupKey
				: (defaultSearchFunctionId + "~" + capacityGroupKey);
	}

	public final boolean notifySegmentJobResults(Queue<SearchResponse> searchResponseQueue,
			ConcurrentValuedHashMap<BiKey<String, String>, SearchNodeCapacityGroupLoadInfo> snPartitionedLoadMap) {
		if (jobCompletedFlag) {
			searchResponseQueue.clear();
			return true;
		}

		SearchResponse searchResponse = null;
		while ((searchResponse = searchResponseQueue.poll()) != null) {
			String segmentJobId = null;
			String searchNodeId = null;
			String requestKey = null;
			if (searchResponse.getMsgId().contains("|")) {
				segmentJobId = searchResponse.getMsgId();

				String splitParts[] = segmentJobId.split("\\|");
				String searchJobId = splitParts[0];
				String segmentJobIdPart = splitParts[1];// Just for logging
				searchNodeId = splitParts[2];
				requestKey = splitParts[3];
				if (logger.isDebugEnabled())
					logger.debug("In notifySegmentJobResults: searchJobId: " + searchJobId + ", segmentJobIdPart: "
							+ segmentJobIdPart + ", searchNodeId: " + searchNodeId + ", requestKey: " + requestKey
							+ ", candidateCount: " + searchResponse.getCandidateCount());
			} else {
				String searchJobId = searchResponse.getMsgId();
				if (logger.isDebugEnabled())
					logger.debug("In notifySegmentJobResults: searchJobId: " + searchJobId);
			}

			if (searchResponse.hasStatus() && searchResponse.getStatus() != null
					&& !searchResponse.getStatus().getSuccess()) {
				scSearchResultInfo.appendSearchResponse(searchResponse, requestKey, true);
				hasErrorsFlag = true;
				logger.warn("In notifySegmentJobResults: has errors for searchJobId: " + searchJobId
						+ ", segmentJobId: " + segmentJobId);
				break;
			}

			scSearchResultInfo.appendSearchResponse(searchResponse, requestKey, false);

			if (segmentJobId != null) {
				Long assignedTimestampMilli = inProgressSegmentJobIdSet.remove(segmentJobId);
				boolean isRemovedFlag = assignedTimestampMilli != null;
				if (isRemovedFlag && searchNodeId != null) {
					if (releasedSegmentJobIdSet.add(segmentJobId)) {
						SearchNodeCapacityGroupLoadInfo searchNodeLoadInfo = snPartitionedLoadMap
								.getValue(new BiKey<>(searchNodeId, capacityGroupKey));
						searchNodeLoadInfo.releaseSlot();

						MetricsUtil.time(BioComponentType.SN, searchNodeId, "SN_JOB_TIME_TAKEN",
								(System.currentTimeMillis() - assignedTimestampMilli), TimeUnit.MILLISECONDS);

						if (logger.isTraceEnabled()) {
							logger.trace("After releasing slot for searchNodeId: " + searchNodeId
									+ ", capacityGroupKey: " + capacityGroupKey + ", segmentJobId: " + segmentJobId
									+ ", snCurrentLoad: " + searchNodeLoadInfo.getCurrentLoadFromReader()
									+ ", snScCurrentLoad: " + searchNodeLoadInfo.getScCurrentLoadFromReader()
									+ ", segmentJobTimeTakenMilli: "
									+ (System.currentTimeMillis() - assignedTimestampMilli));
						} else if (logger.isDebugEnabled()) {
							logger.debug("After releasing slot for searchNodeId: " + searchNodeId
									+ ", capacityGroupKey: " + capacityGroupKey + ", segmentJobId: " + segmentJobId
									+ ", segmentJobTimeTakenMilli: "
									+ (System.currentTimeMillis() - assignedTimestampMilli));
						}
					}
				}
			}
		}

		if (!jobCompletedFlag) {
			if (hasErrorsFlag) {
				Lock writeLock = assignmentInProgressLock.writeLock();
				writeLock.lock();
				try {
					if (!jobCompletedFlag) {
						markAsCompleted(snPartitionedLoadMap);
					}
				} finally {
					writeLock.unlock();
				}
			} else if (inProgressSegmentJobIdSet.isEmpty() && pendingSegmentIdRequestKeySetMap.isEmpty()) {
				Lock writeLock = assignmentInProgressLock.writeLock();
				writeLock.lock();
				try {
					if (!jobCompletedFlag && inProgressSegmentJobIdSet.isEmpty()
							&& pendingSegmentIdRequestKeySetMap.isEmpty()) {
						markAsCompleted(snPartitionedLoadMap);
					}
				} finally {
					writeLock.unlock();
				}
			} else {
				if (logger.isDebugEnabled())
					logger.debug("In notifySegmentJobResults: searchJobId: " + searchJobId
							+ ", inProgressSegmentJobIdSet.isEmpty: " + inProgressSegmentJobIdSet.isEmpty()
							+ ", pendingSegmentIdRequestKeySetMap.isEmpty: "
							+ pendingSegmentIdRequestKeySetMap.isEmpty() + ", jobCompletedFlag:" + jobCompletedFlag);
			}
		}

		return jobCompletedFlag;
	}

	private void markAsCompleted(
			ConcurrentValuedHashMap<BiKey<String, String>, SearchNodeCapacityGroupLoadInfo> snPartitionedLoadMap) {
		if (hasErrorsFlag) {
			logger.info("In markAsCompleted: searchJobId: " + searchJobId + ", hasErrorsFlag: " + hasErrorsFlag
					+ ", pendingSegmentIdRequestKeySetMap: " + pendingSegmentIdRequestKeySetMap
					+ ", releasedSegmentJobIdSet: " + releasedSegmentJobIdSet + ", inProgressSegmentJobIdSet: "
					+ inProgressSegmentJobIdSet.keySet());
		} else if (logger.isDebugEnabled()) {
			logger.debug("In markAsCompleted: searchJobId: " + searchJobId + ", hasErrorsFlag: " + hasErrorsFlag);
		}

		jobCompletedFlag = true;
		if (jobCompletedDateTimeMilli == -1) {
			jobCompletedDateTimeMilli = System.currentTimeMillis();
		}

		pendingSegmentIdRequestKeySetMap.clear();

		releasePendingSegmentJobs(snPartitionedLoadMap);
	}

	public final void preReleasePendingSegmentJob(String segmentJobId, String searchNodeId,
			ConcurrentValuedHashMap<BiKey<String, String>, SearchNodeCapacityGroupLoadInfo> snPartitionedLoadMap) {
		if (releasedSegmentJobIdSet.add(segmentJobId)) {
			try {
				SearchNodeCapacityGroupLoadInfo searchNodeLoadInfo = snPartitionedLoadMap
						.getValue(new BiKey<>(searchNodeId, capacityGroupKey));
				searchNodeLoadInfo.releaseSlot();

				Long assignmentTimestamp = inProgressSegmentJobIdSet.get(segmentJobId);

				if (assignmentTimestamp != null) {
					MetricsUtil.time(BioComponentType.SN, searchNodeId, "SN_JOB_TIME_TAKEN",
							(System.currentTimeMillis() - assignmentTimestamp), TimeUnit.MILLISECONDS);
				}

				if (logger.isDebugEnabled() || jobCompletedFlag || hasErrorsFlag) {
					if (assignmentTimestamp == null) {
						logger.info("In preReleasePendingSegmentJob: After releasing slot for searchNodeId: "
								+ searchNodeId + ", capacityGroupKey: " + capacityGroupKey + ", segmentJobId: "
								+ segmentJobId + ", snCurrentLoad: " + searchNodeLoadInfo.getCurrentLoadFromReader()
								+ ", snScCurrentLoad: " + searchNodeLoadInfo.getScCurrentLoadFromReader()
								+ (hasErrorsFlag ? (", hasErrorsFlag: " + hasErrorsFlag) : "")
								+ (jobCompletedFlag ? (", jobCompletedFlag: " + jobCompletedFlag) : ""));
					} else {
						logger.info("In preReleasePendingSegmentJob: After releasing slot for searchNodeId: "
								+ searchNodeId + ", capacityGroupKey: " + capacityGroupKey + ", segmentJobId: "
								+ segmentJobId + ", snCurrentLoad: " + searchNodeLoadInfo.getCurrentLoadFromReader()
								+ ", snScCurrentLoad: " + searchNodeLoadInfo.getScCurrentLoadFromReader()
								+ (hasErrorsFlag ? (", hasErrorsFlag: " + hasErrorsFlag) : "")
								+ (jobCompletedFlag ? (", jobCompletedFlag: " + jobCompletedFlag) : "")
								+ ", segmentJobTimeTakenMilli: " + (System.currentTimeMillis() - assignmentTimestamp));
					}
				}
			} catch (Throwable th) {
				logger.error("Error releasing slot for searchNodeId: " + searchNodeId + ", capacityGroupKey: "
						+ capacityGroupKey + ", segmentJobId: " + segmentJobId);
			}
		} else {
			logger.warn("In preReleasePendingSegmentJob: Segment job slot already released for searchNodeId: "
					+ searchNodeId + ", capacityGroupKey: " + capacityGroupKey + ", segmentJobId: " + segmentJobId);
		}
	}

	public final synchronized void releasePendingSegmentJobs(
			ConcurrentValuedHashMap<BiKey<String, String>, SearchNodeCapacityGroupLoadInfo> snPartitionedLoadMap) {
		if (inProgressSegmentJobIdSet.isEmpty()) {
			return;
		}

		Entry<String, Long> entry = null;
		while ((entry = inProgressSegmentJobIdSet.pollFirstEntry()) != null) {
			String segmentJobId = entry.getKey();
			Long assignmentTimestamp = entry.getValue();
			if (releasedSegmentJobIdSet.add(segmentJobId)) {
				String splitParts[] = segmentJobId.split("\\|");
				String searchNodeId = splitParts[2];
				try {
					SearchNodeCapacityGroupLoadInfo searchNodeLoadInfo = snPartitionedLoadMap
							.getValue(new BiKey<>(searchNodeId, capacityGroupKey));
					
					logger.info("Before releaseSlot, snCurrentLoad=" + searchNodeLoadInfo.getCurrentLoadFromReader() + " searchNodeId=" + searchNodeId);
					
					searchNodeLoadInfo.releaseSlot();
					
					logger.info("After releaseSlot, snCurrentLoad=" + searchNodeLoadInfo.getCurrentLoadFromReader() + " searchNodeId=" + searchNodeId);

					if (assignmentTimestamp != null) {
						MetricsUtil.time(BioComponentType.SN, searchNodeId, "SN_JOB_TIME_TAKEN",
								(System.currentTimeMillis() - assignmentTimestamp), TimeUnit.MILLISECONDS);
					}

					if (logger.isDebugEnabled() || hasErrorsFlag) {
						if (assignmentTimestamp == null) {
							logger.info("In releasePendingSegmentJobs: After releasing slot for searchNodeId: "
									+ searchNodeId + ", capacityGroupKey: " + capacityGroupKey + ", segmentJobId: "
									+ segmentJobId + ", snCurrentLoad: " + searchNodeLoadInfo.getCurrentLoadFromReader()
									+ ", snScCurrentLoad: " + searchNodeLoadInfo.getScCurrentLoadFromReader()
									+ (hasErrorsFlag ? (", hasErrorsFlag: " + hasErrorsFlag) : "")
									+ (jobCompletedFlag ? (", jobCompletedFlag: " + jobCompletedFlag) : ""));
						} else {
							logger.info("In releasePendingSegmentJobs: After releasing slot for searchNodeId: "
									+ searchNodeId + ", capacityGroupKey: " + capacityGroupKey + ", segmentJobId: "
									+ segmentJobId + ", snCurrentLoad: " + searchNodeLoadInfo.getCurrentLoadFromReader()
									+ ", snScCurrentLoad: " + searchNodeLoadInfo.getScCurrentLoadFromReader()
									+ (hasErrorsFlag ? (", hasErrorsFlag: " + hasErrorsFlag) : "")
									+ (jobCompletedFlag ? (", jobCompletedFlag: " + jobCompletedFlag) : "")
									+ ", segmentJobTimeTakenMilli: "
									+ (System.currentTimeMillis() - assignmentTimestamp));
						}
					}
				} catch (Throwable th) {
					logger.error("Error releasing slot for searchNodeId: " + searchNodeId + ", capacityGroupKey: "
							+ capacityGroupKey + ", segmentJobId: " + segmentJobId);
				}
			}
		}
	}

	public final int calculateCurrentPendingSegmentJobsBySearchNodeId(String searchNodeId) {
		final String searchKey = "|" + searchNodeId + "|";
		return inProgressSegmentJobIdSet.keySet().stream()
				.mapToInt(segmentJobId -> segmentJobId.indexOf(searchKey) > -1 ? 1 : 0).sum();
	}

	public ConcurrentValuedHashMap<Integer, ConcurrentSkipListSet<String>> getPendingSegmentIdRequestKeySetMap() {
		return pendingSegmentIdRequestKeySetMap;
	}

	public int getTotalSearchResponseCount() {
		return scSearchResultInfo.getSearchResponseCounter().get();
	}

	public final boolean hasPendingSegmentIdsForAssignment() {
		return !jobCompletedFlag && !pendingSegmentIdRequestKeySetMap.isEmpty();
	}

	public void incrementJobRescheduledCount() {
		jobRescheduledCount++;
	}

	public long getJobRescheduledCount() {
		return jobRescheduledCount;
	}

	public boolean isJobCompleted() {
		return jobCompletedFlag;
	}

	public String getExtractionJobId() {
		return extractionJobId;
	}

	public void setExtractionJobId(String extractionJobId) {
		this.extractionJobId = extractionJobId;
	}

	public long getExtractionCompletedDateTimeMilli() {
		return extractionCompletedDateTimeMilli;
	}

	public void setExtractionCompletedDateTimeMilli(long extractionCompletedDateTimeMilli) {
		this.extractionCompletedDateTimeMilli = extractionCompletedDateTimeMilli;
	}

	public long getDelayFromCreateDateTime() {
		return System.currentTimeMillis() - createDateTimeMilli;
	}

	public long getFisrtAssignmentDateTimeMilli() {
		return fisrtAssignmentDateTimeMilli;
	}

	public long getExtractTimeTakenMilli() {
		if (extractionCompletedDateTimeMilli == -1L) {
			return 0;
		} else {
			return extractionCompletedDateTimeMilli - createDateTimeMilli;
		}
	}

	public long getAssignmentDelayMilli() {
		if (lastAssignmentDateTimeMilli == -1L) {
			return 0;
		} else if (extractionCompletedDateTimeMilli == -1L) {
			return lastAssignmentDateTimeMilli - createDateTimeMilli - templateVerifyTimeTakenMilli;
		} else {
			return lastAssignmentDateTimeMilli - extractionCompletedDateTimeMilli - templateVerifyTimeTakenMilli;
		}
	}

	public long getSearchTimeTakenMilli() {
		if (fisrtAssignmentDateTimeMilli == -1L) {
			return 0;
		} else if (extractionCompletedDateTimeMilli == -1L) {
			return jobCompletedDateTimeMilli - createDateTimeMilli - templateVerifyTimeTakenMilli;
		} else {
			return jobCompletedDateTimeMilli - extractionCompletedDateTimeMilli - templateVerifyTimeTakenMilli;
		}
	}

	public boolean isTimeoutErrorFlag() {
		return timeoutErrorFlag;
	}

	public void setTimeoutErrorFlag(boolean timeoutErrorFlag) {
		this.timeoutErrorFlag = timeoutErrorFlag;
	}

	public boolean isSearchExtractErrorFlag() {
		return searchExtractErrorFlag;
	}

	public void setSearchExtractErrorFlag(boolean searchExtractErrorFlag) {
		this.searchExtractErrorFlag = searchExtractErrorFlag;
	}

	public String getCallbackUrl() {
		return callbackUrl;
	}

	public Set<Integer> getBinIdSet() {
		return binIdSet;
	}

	public JobEntry getJobEntry() {
		return jobEntry;
	}

	public long getTemplateVerifyTimeTakenMilli() {
		return templateVerifyTimeTakenMilli;
	}

	public void setTemplateVerifyTimeTakenMilli(long templateVerifyTimeTakenMilli) {
		this.templateVerifyTimeTakenMilli = templateVerifyTimeTakenMilli;
	}

	public boolean isIncludeExtractionResultFlag() {
		return includeExtractionResultFlag;
	}

	public void setIncludeExtractionResultFlag(boolean includeExtractionResultFlag) {
		this.includeExtractionResultFlag = includeExtractionResultFlag;
	}

	public String getDefaultSearchFunctionId() {
		return defaultSearchFunctionId;
	}

	public boolean isFunctionSlotAcquiredFlag() {
		return functionSlotAcquiredFlag;
	}

	public void markFunctionSlotAcquired() {
		this.functionSlotAcquiredFlag = true;
	}

	public synchronized void releaseFunctionSlot(MatcherFunctionControlUtil matcherFunctionControlUtil) {
		if (functionSlotAcquiredFlag) {
			matcherFunctionControlUtil.releaseFunctionSlot(defaultSearchFunctionId);
			functionSlotAcquiredFlag = false;
		}
	}

	public final ReadWriteLock getAssignmentInProgressLock() {
		return assignmentInProgressLock;
	}

	public String getCapacityGroupKey() {
		return capacityGroupKey;
	}

	public String getFunctionCapacityGroupKey() {
		return functionCapacityGroupKey;
	}
}
