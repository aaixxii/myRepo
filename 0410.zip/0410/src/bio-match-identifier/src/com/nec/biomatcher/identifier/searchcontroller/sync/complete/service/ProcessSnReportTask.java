package com.nec.biomatcher.identifier.searchcontroller.sync.complete.service;

import static com.nec.biomatcher.identifier.util.SearchConstants.ERROR_CODE_STRIC_SYNC_SEGMENT_PROCESS;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;

/**
 * 
 * @author 000001A006PBP<br/>
 *         ProcessSnReportTask update SN segments report to memory for strict
 *         callback
 *
 */
public class ProcessSnReportTask implements Runnable {
	private BioMatcherConfigService bioMatcherConfigService;
	private StrictSegmentSyncCallbackService strictCallbackService;
	private String reportMeg;
	private static final Logger logger = Logger.getLogger(ProcessSnReportTask.class);

	/**
	 * Constructor of class
	 * 
	 * @param message
	 */
	public ProcessSnReportTask(String message) {
		init();
		this.reportMeg = message;
	}

	/**
	 * Initialize class
	 */
	private void init() {
		try {
			bioMatcherConfigService = SpringServiceManager.getBean("bioMatcherConfigService");
			strictCallbackService = SpringServiceManager.getBean("strictSegmentSyncCallbackService");
		} catch (Exception e) {
			logger.error("Error occurred in ProcessSnReportTask.init()", e);
			throw e;
		}
	}

	@Override
	public void run() {
		handleSnSegmentReportMeg();
	}

	/**
	 * 
	 * @param reportMeg
	 */
	public void handleSnSegmentReportMeg() {
		try {
			final Map<Integer, Integer> segmentIdBinIdMap = bioMatcherConfigService.getSegmentIdBinIdMap();
			if (reportMeg == null || reportMeg.isEmpty()) {
				logger.warn("Receied empty sn report, skip process!");
				return;
			}
			if (segmentIdBinIdMap.isEmpty()) {
				logger.warn("The size of segmentIdBinIdMap is zero, skip process!");
			}
			int index = reportMeg.indexOf("#");
			String snId = reportMeg.substring(0, index);
			String jsonMapString = reportMeg.substring(index + 1, reportMeg.length());
			logger.info("Sn report message:" + jsonMapString);
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			Map<Integer, Long> snReportMap = new HashMap<>();
			Type mapType = new TypeToken<Map<Integer, Long>>() {
			}.getType();
			snReportMap = gson.fromJson(jsonMapString, mapType);
			snReportMap.entrySet().stream().forEach(e -> {
				Integer binId = segmentIdBinIdMap.get(e.getKey());
				if (binId == null) {
					String errMsg = "The BinId is null for segment:" + e.getKey() + "SnId=" + snId
							+ "Skip to update sn report!";
					logger.error(errMsg);

					StrictSegmentSyncCallbackServiceException ex = new StrictSegmentSyncCallbackServiceException(
							errMsg);
					ex.setSegId(e.getKey());
					ex.setSnId(snId);
					ex.setErrmsg(errMsg);
					ex.setErrCode(ERROR_CODE_STRIC_SYNC_SEGMENT_PROCESS);
					strictCallbackService.faildStrictSyncCallback(ex);

				}
				updatePreSnSegVerMap(snId, binId, e.getKey(), e.getValue());
				updateStrictSyncCallbackMap(snId, binId, e.getKey(), e.getValue());
			});
			checkHaveSyncCompletedKey();		
		} catch (Exception e) {
			logger.error("Error occurred in handleSnSegmentReportMeg", e);
		}
	}

	/**
	 * 
	 * @param snId
	 * @param binId
	 * @param segId
	 * @param segVer
	 */
	private void updateStrictSyncCallbackMap(String snId, Integer binId, Integer segId, Long segVer) {		
		try {
			ConcurrentHashMap<StrictSyncCallbackKey, List<SyncSnSegVerInfo>> strictSyncCallbackMap = StrictSegmentSyncCallbackService
					.getStrictSyncCallbackMap();
			if (strictSyncCallbackMap.isEmpty()) {
				logger.debug("The size of strictSyncCallbackMap is zero! skip process!");
				return;
			}			
			strictSyncCallbackMap.entrySet().stream().forEach(entry -> {
				List<SyncSnSegVerInfo> tmp = entry.getValue();
				Predicate<SyncSnSegVerInfo> predicate = info -> info.getBinId() != null && info.getSegmentId() != null
						&& info.getSnNodeId() != null && info.getBinId().intValue() == binId.intValue()
						&& info.getSegmentId().intValue() == segId.intValue() && info.getSnNodeId().equals(snId)
						&& segVer.longValue() >= info.getSegmentVersion().longValue();
				Optional<SyncSnSegVerInfo> found = tmp.stream().filter(predicate).findAny();
				if (found.isPresent()) {
					found.get().setSegmentVersion(segVer);
					found.get().setIsSyncCompelted(Boolean.TRUE);
					logger.info("found strcit callback map update key, segmentId=" + found.get().getSegmentId() + "SnId=" + snId);
					logger.info("SegmentVersion=" + found.get().getSegmentVersion() + " IsSyncCompelted="
							+ found.get().getIsSyncCompelted());
					return;
				}
			});
		} catch (Exception e) {
			String errMsg = "An error occurred in updateStrictSyncCallbackMap";
			logger.warn(errMsg, e);
			StrictSegmentSyncCallbackServiceException ex = new StrictSegmentSyncCallbackServiceException(e);
			ex.setBinId(binId);
			ex.setSegId(segId);
			ex.setSnId(snId);
			ex.setErrmsg(errMsg);
			ex.setErrCode(ERROR_CODE_STRIC_SYNC_SEGMENT_PROCESS);
			strictCallbackService.faildStrictSyncCallback(ex);
		}
	}

	/**
	 * 
	 * @param snId
	 * @param segId
	 * @param segVer
	 */
	private void updatePreSnSegVerMap(String snId, Integer binId, Integer segId, Long segVer) {
		try {
			ConcurrentHashMap<SegIdBinKey, List<SyncSnSegVerInfo>> preSnSegVerMap = StrictSegmentSyncCallbackService
					.getPreSnSegVerMap();
			if (preSnSegVerMap.isEmpty()) {
				logger.warn("The size of preSnSegVerMap is zero! skip process!");
				return;
			}

			Predicate<Entry<SegIdBinKey, List<SyncSnSegVerInfo>>> predicate = oneSet -> oneSet.getKey().getSegmentId()
					.intValue() == segId.intValue() && oneSet.getKey().getBinId().intValue() == binId.intValue();
			List<Entry<SegIdBinKey, List<SyncSnSegVerInfo>>> tmp = preSnSegVerMap.entrySet().stream().filter(predicate)
					.collect(Collectors.toList());
			if (tmp.isEmpty()) {
				logger.warn("No data to process sn report:snId:" + snId + "segId:" + segId + "binId:" + binId);
				return;
			}
			Predicate<SyncSnSegVerInfo> pd = info -> info.getSegmentId().intValue() == segId.intValue()
					&& info.getSnNodeId().equals(snId) && info.getBinId().intValue() == binId.intValue()
					&& segVer.longValue() > info.getSegmentVersion().longValue();
			tmp.forEach(entry -> {
				Optional<SyncSnSegVerInfo> found = entry.getValue().stream().filter(pd).findAny();
				if (found.isPresent()) {
					found.get().setSegmentVersion(segVer);
					logger.info("Found preMap update key, segmentId=" + found.get().getSegmentId());
					logger.info("SegmentVersion:" + found.get().getSegmentVersion());
					return;
				}
			});

		} catch (Exception e) {
			String errMsg = "An error occurred in updatePreSnSegVerMap";
			logger.warn(errMsg, e);
			StrictSegmentSyncCallbackServiceException ex = new StrictSegmentSyncCallbackServiceException(e);
			ex.setBinId(binId);
			ex.setSegId(segId);
			ex.setSnId(snId);
			ex.setErrmsg(errMsg);
			ex.setErrCode(ERROR_CODE_STRIC_SYNC_SEGMENT_PROCESS);
			strictCallbackService.faildStrictSyncCallback(ex);
		}
	}
	
	/**
	 * 
	 */
	private void checkHaveSyncCompletedKey() {
		final List<StrictSyncCallbackKey> syncCompletedKeys = new ArrayList<>();
		ConcurrentHashMap<StrictSyncCallbackKey, List<SyncSnSegVerInfo>> strictSyncCallbackMap = StrictSegmentSyncCallbackService
				.getStrictSyncCallbackMap();		
		if (strictSyncCallbackMap.isEmpty()) {
			logger.debug("The size of strictSyncCallbackMap is zero! skip callback!");
			return;
		}
		 AtomicLong maxSegVer = new  AtomicLong(0);
		Comparator <SyncSnSegVerInfo> comparator = (s1, s2) -> Long.compare(s1.getSegmentVersion(), s2.getSegmentVersion());
		Predicate<SyncSnSegVerInfo> fp = info -> info.getIsSyncCompelted().booleanValue() == Boolean.FALSE.booleanValue();
		strictSyncCallbackMap.entrySet().stream().forEach(e -> {
			List<SyncSnSegVerInfo> tmpList = e.getValue();	
			 maxSegVer.set(tmpList.stream().max(comparator).get().getSegmentVersion());					
			if (tmpList.stream().filter(fp).findAny().isPresent()) return;
			tmpList.parallelStream().forEach(s -> {
				if (s.getSegmentVersion().longValue() < maxSegVer.get()) {
					return;
				}
			});			
			syncCompletedKeys.add(e.getKey());
			logger.info("Find sync semgnet completed key, syncJobId:" + e.getKey().getSyncJobId());
		});		
		if (syncCompletedKeys.isEmpty()) return;
		checkCanCallback(syncCompletedKeys);			
	}

	/**
	 * 
	 * @param canCallbackKeyList
	 */
	public void checkCanCallback(List<StrictSyncCallbackKey> canCallbackKeyList) {
		ConcurrentHashMap<String, List<StrictSyncCallbackKey>> jobIdKeyMap = StrictSegmentSyncCallbackService
				.getJobIdKeyMap();
		if (jobIdKeyMap.isEmpty()) {
			logger.warn("jobIdKeyMap is empty, skip...");
			return;
		}
		if (jobIdKeyMap.isEmpty()) {
			logger.warn("jobIdKeyMap is empty, skip...");
			return;
		}		
		jobIdKeyMap.entrySet().parallelStream().forEach(en -> {
			List<StrictSyncCallbackKey> oneJobkeyList = en.getValue();
			if (canCallbackKeyList.containsAll(oneJobkeyList)) {
				logger.info("Found strict sync callback jobId:" + en.getKey());
				reSetStatus(oneJobkeyList);				
				strictCallbackService.callbackToClient(en.getKey(), oneJobkeyList);
			}
		});
	}
	
	/**
	 * 
	 * @param oneJobkeyList
	 */
	private void reSetStatus(List<StrictSyncCallbackKey> oneJobkeyList) {
		ConcurrentHashMap<StrictSyncCallbackKey, List<SyncSnSegVerInfo>> strictSyncCallbackMap = StrictSegmentSyncCallbackService
				.getStrictSyncCallbackMap();
		if (strictSyncCallbackMap.isEmpty()) {
			logger.debug("The size of strictSyncCallbackMap is zero! skip callback!");
			return;
		}
		if (oneJobkeyList != null) {
			oneJobkeyList.parallelStream().forEach(key -> {
				List<SyncSnSegVerInfo> tmep = strictSyncCallbackMap.get(key);
				if (tmep != null) {
					strictSyncCallbackMap.get(key).forEach(e -> {
						e.setIsSyncCompelted(Boolean.FALSE);
					});
				}
			});
		}
	}
}
