package com.nec.biomatcher.identifier.searchbroker.tasks;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.google.common.util.concurrent.Uninterruptibles;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerInfo;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioServerState;
import com.nec.biomatcher.comp.util.LocalServerComponents;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.ShutdownHook;
import com.nec.biomatcher.core.framework.common.concurrent.BooleanLatch;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentValuedHashMap;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.identifier.searchbroker.manager.BioSearchBrokerManager;
import com.nec.biomatcher.identifier.searchbroker.util.SearchBrokerClusterClient;

/**
 * The Class SearchBrokerManagerTask.
 */
public class SearchBrokerManagerTask implements Runnable {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(SearchBrokerManagerTask.class);

	/** The bio search broker manager. */
	private BioSearchBrokerManager bioSearchBrokerManager;

	/** The bio matcher config service. */
	private BioMatcherConfigService bioMatcherConfigService;

	/** The bio parameter service. */
	private BioParameterService bioParameterService;

	private ConcurrentValuedHashMap<String, BooleanLatch> searchNodeOnlineStatusMap;

	/** The is initialized. */
	private boolean isInitialized = false;

	/** The first run flag. */
	private boolean firstRunFlag = true;

	@Override
	public void run() {
		Thread.currentThread().setName("SEARCH_BROKER_MANAGER_TASK");
		logger.info("SearchBrokerManagerTask started");
		String previousSubSystemGroupId = null;
		while (!ShutdownHook.isShutdownFlag) {
			long sleepIntervalMilli = TimeUnit.SECONDS.toMillis(20);

			try {
				if (!isInitialized) {
					init();
				}

				sleepIntervalMilli = bioParameterService.getParameterValue(
						"SEARCH_BROKER_MANAGER_TASK_SLEEP_INTERVAL_MILLI", "DEFAULT", sleepIntervalMilli);

				BioServerInfo searchBrokerServerInfo = bioMatcherConfigService
						.getServerInfo(bioSearchBrokerManager.getSearchBrokerId());
				if (searchBrokerServerInfo == null) {
					logger.error("Cannot find searchBroker: " + bioSearchBrokerManager.getSearchBrokerId());

					LocalServerComponents.setSearchBrokerSnGroupId(null);

					if (StringUtils.isNotBlank(previousSubSystemGroupId)) {
						bioSearchBrokerManager.stopSearchNodeDataDistributionTasks();
						previousSubSystemGroupId = null;
					}

					Uninterruptibles.sleepUninterruptibly(1, TimeUnit.MINUTES);
					continue;
				}

				if (StringUtils.isBlank(searchBrokerServerInfo.getSubSystemGroupId())) {
					if (!StringUtils.equals(previousSubSystemGroupId, searchBrokerServerInfo.getSubSystemGroupId())) {
						CommonLogger.STATUS_LOG.error("Subsystem groupId is not set for searchBroker ServerId: "
								+ searchBrokerServerInfo.getServerId());
					}

					LocalServerComponents.setSearchBrokerSnGroupId(null);

					previousSubSystemGroupId = searchBrokerServerInfo.getSubSystemGroupId();

					bioSearchBrokerManager.stopSearchNodeDataDistributionTasks();

					continue;
				}

				if (BioServerState.ACTIVE.equals(searchBrokerServerInfo.getServerState())) {

					bioSearchBrokerManager.getSearchBrokerClusterClient().connect();

					bioSearchBrokerManager.getSearchBrokerEnabledFlag().setFlag(true);

					LocalServerComponents.setSearchBrokerSnGroupId(searchBrokerServerInfo.getSubSystemGroupId());

					bioSearchBrokerManager.startSearchNodeDataDistributionTasks();

					SearchBrokerClusterClient searchBrokerClusterClient = bioSearchBrokerManager
							.getSearchBrokerClusterClient();

					List<BioServerInfo> searchNodeInfoList = bioMatcherConfigService.getServerInfoListByServerGroup(
							searchBrokerServerInfo.getSubSystemGroupId(), BioComponentType.SN);

					searchNodeInfoList.parallelStream().forEach(searchNodeInfo -> {
						if (BioServerState.ACTIVE.equals(searchNodeInfo.getServerState())) {
							BooleanLatch onlineFlag = searchNodeOnlineStatusMap.getValue(searchNodeInfo.getServerId());
							if (!onlineFlag.getFlag()
									|| !searchBrokerClusterClient.isSearchNodeOnline(searchNodeInfo.getServerId())) {
								bioSearchBrokerManager.checkSearchNodeConnection(searchNodeInfo.getServerId(),
										firstRunFlag);
							}
						}
					});

					firstRunFlag = false;
				} else {
					LocalServerComponents.setSearchBrokerSnGroupId(null);

					bioSearchBrokerManager.stopSearchNodeDataDistributionTasks();

					bioSearchBrokerManager.getSearchBrokerEnabledFlag().setFlag(false);

				}
			} catch (Throwable th) {
				logger.error("Errro in SearchBrokerManagerTask.run : " + th.getMessage(), th);
				Uninterruptibles.sleepUninterruptibly(sleepIntervalMilli, TimeUnit.MILLISECONDS);// Additional
																									// sleep
																									// due
																									// to
																									// error
			} finally {
				Uninterruptibles.sleepUninterruptibly(sleepIntervalMilli, TimeUnit.MILLISECONDS);
			}
		}

		logger.warn("Exiting SearchBrokerManagerTask: isShutdownFlag: " + ShutdownHook.isShutdownFlag);
	}

	/**
	 * Inits the.
	 */
	private final void init() {
		bioSearchBrokerManager = SpringServiceManager.getBean("bioSearchBrokerManager");
		bioMatcherConfigService = SpringServiceManager.getBean("bioMatcherConfigService");
		bioParameterService = SpringServiceManager.getBean("bioParameterService");
		searchNodeOnlineStatusMap = bioSearchBrokerManager.getSearchNodeOnlineStatusMap();

		isInitialized = true;
	}
}
