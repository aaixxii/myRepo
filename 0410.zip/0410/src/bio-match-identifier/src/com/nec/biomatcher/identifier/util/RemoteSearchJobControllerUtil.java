package com.nec.biomatcher.identifier.util;

import java.util.concurrent.TimeUnit;

import org.apache.commons.pool2.BaseKeyedPooledObjectFactory;
import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.impl.DefaultPooledObject;
import org.apache.commons.pool2.impl.GenericKeyedObjectPool;
import org.apache.log4j.Logger;
import org.springframework.remoting.RemoteConnectFailureException;
import org.springframework.remoting.caucho.HessianProxyFactoryBean;
import org.springframework.remoting.rmi.RmiProxyFactoryBean;

import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerInfo;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioConnectionType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioProtocolType;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.identifier.searchcontroller.service.exception.BioSearchContollerException;
import com.nec.biomatcher.spec.services.BioSearchJobControllerService;
import com.nec.biomatcher.spec.transfer.job.search.SearchJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.search.SearchJobResultDto;

public class RemoteSearchJobControllerUtil {
	private static final Logger logger = Logger.getLogger(RemoteSearchJobControllerUtil.class);

	private static final GenericKeyedObjectPool<String, BioSearchJobControllerService> servicePool = buildServicePool();

	private RemoteSearchJobControllerUtil() {
	}

	public static SearchJobRequestDto getSearchJobRequest(String searchJobId, String searchControllerId)
			throws RemoteConnectFailureException, BioSearchContollerException {
		try {
			BioSearchJobControllerService service = servicePool.borrowObject(searchControllerId);
			try {
				return service.getSearchJobRequest(searchJobId);
			} finally {
				servicePool.returnObject(searchControllerId, service);
			}
		} catch (RemoteConnectFailureException ex) {
			logger.error("RemoteConnectFailureException while getSearchJobRequest on searchControllerId: "
					+ searchControllerId + ", searchJobId: " + searchJobId + " : " + ex.getMessage(), ex);
			throw ex;
		} catch (Throwable th) {
			throw new BioSearchContollerException("Error in getSearchJobRequest on searchControllerId: "
					+ searchControllerId + ", searchJobId: " + searchJobId + " : " + th.getMessage(), th);
		}
	}

	public static SearchJobResultDto getSearchJobResult(String searchJobId, String searchControllerId)
			throws RemoteConnectFailureException, BioSearchContollerException {
		try {
			BioSearchJobControllerService service = servicePool.borrowObject(searchControllerId);
			try {
				return service.getSearchJobResult(searchJobId);
			} finally {
				servicePool.returnObject(searchControllerId, service);
			}
		} catch (RemoteConnectFailureException ex) {
			logger.error("RemoteConnectFailureException while getSearchJobResult on searchControllerId: "
					+ searchControllerId + ", searchJobId: " + searchJobId + " : " + ex.getMessage(), ex);
			throw ex;
		} catch (Throwable th) {
			throw new BioSearchContollerException("Error in getSearchJobResult on searchControllerId: "
					+ searchControllerId + ", searchJobId: " + searchJobId + " : " + th.getMessage(), th);
		}
	}

	/**
	 * Builds the service pool.
	 *
	 * @return the generic keyed object pool
	 */
	private static GenericKeyedObjectPool<String, BioSearchJobControllerService> buildServicePool() {

		BaseKeyedPooledObjectFactory<String, BioSearchJobControllerService> poolFactory = new BaseKeyedPooledObjectFactory<String, BioSearchJobControllerService>() {

			@Override
			public BioSearchJobControllerService create(String searchControllerId) throws Exception {
				BioMatcherConfigService bioMatcherConfigService = SpringServiceManager
						.getBean("bioMatcherConfigService");
				BioParameterService bioParameterService = SpringServiceManager.getBean("bioParameterService");
				boolean useRmiSearchControllerClient = bioParameterService
						.getParameterValue("USE_RMI_SEARCH_CONTROLLER_CLIENT", "DEFAULT", false);
				if (useRmiSearchControllerClient) {
					BioServerInfo bioServerInfo = bioMatcherConfigService.getServerInfo(searchControllerId);
					RmiProxyFactoryBean proxy = new RmiProxyFactoryBean();
					proxy.setBeanClassLoader(BioSearchJobControllerService.class.getClassLoader());
					proxy.setServiceInterface(BioSearchJobControllerService.class);
					proxy.setServiceUrl(
							"rmi://" + bioServerInfo.getServerHost().trim() + ":1772/bioSearchJobControllerRmiService");
					proxy.setLookupStubOnStartup(false);
					proxy.setRefreshStubOnConnectFailure(true);
					proxy.afterPropertiesSet();
					BioSearchJobControllerService service = (BioSearchJobControllerService) proxy.getObject();
					return service;
				} else {
					String connectionUrl = bioMatcherConfigService.getServerConnectionUrl(searchControllerId,
							BioComponentType.SC, BioConnectionType.COMPONENT, BioProtocolType.HESSIAN);

					long timeoutMilli = bioParameterService.getParameterValue("SEARCH_CONTROLLER_HESSIAN_TIMEOUT_MILLI",
							"DEFAULT", TimeUnit.MINUTES.toMillis(2));

					HessianProxyFactoryBean proxy = new HessianProxyFactoryBean();
					proxy.setBeanClassLoader(BioSearchJobControllerService.class.getClassLoader());
					proxy.setServiceUrl(connectionUrl);
					proxy.setOverloadEnabled(true);
					proxy.setReadTimeout(timeoutMilli);
					proxy.setServiceInterface(BioSearchJobControllerService.class);
					proxy.afterPropertiesSet();
					BioSearchJobControllerService service = (BioSearchJobControllerService) proxy.getObject();
					return service;
				}
			}

			@Override
			public PooledObject<BioSearchJobControllerService> wrap(BioSearchJobControllerService value) {
				return new DefaultPooledObject<>(value);
			}
		};

		GenericKeyedObjectPool<String, BioSearchJobControllerService> servicePool = new GenericKeyedObjectPool<String, BioSearchJobControllerService>(
				poolFactory);
		servicePool.setMaxTotalPerKey(500);
		servicePool.setMinEvictableIdleTimeMillis(TimeUnit.MINUTES.toMillis(5));

		return servicePool;
	}

}
