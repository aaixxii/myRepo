package com.nec.biomatcher.identifier.searchcontroller.sync.complete.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.junit.Assert;
import org.junit.Test;

import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherNodeSegmentInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherSegmentInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricEventInfo;

public class StrictSyncCallbackDataRegisterTest {
	ConcurrentHashMap<SegIdBinKey, List<SyncSnSegVerInfo>> preSnSegVerMap = new ConcurrentHashMap<SegIdBinKey, List<SyncSnSegVerInfo>>();
	ConcurrentHashMap<StrictSyncCallbackKey, List<SyncSnSegVerInfo>> strictSyncCallbackMap = new ConcurrentHashMap<StrictSyncCallbackKey, List<SyncSnSegVerInfo>>();

	@Test
	public void testRegisterStrictSyncCallbackData() {
		preSnSegVerMap.clear();
		strictSyncCallbackMap.clear();
		createPreSnSegVerMap();

		String syncJobId = "SnycJob100";
		String callbackUrl = "http://localhost:8080";
		List<BiometricEventInfo> modifiedBiometricEventInfoList = new ArrayList<>();
		BiometricEventInfo bioEventInfo1 = new BiometricEventInfo();
		bioEventInfo1.setBinId(35);
		bioEventInfo1.setAssignedSegmentId(1000);
		bioEventInfo1.setBiometricId(200L);
		bioEventInfo1.setEventId("event001");
		bioEventInfo1.setEventId("ex001");
		modifiedBiometricEventInfoList.add(bioEventInfo1);

		BiometricEventInfo bioEventInfo2 = new BiometricEventInfo();
		bioEventInfo2.setBinId(35);
		bioEventInfo2.setAssignedSegmentId(2000);
		bioEventInfo2.setBiometricId(300L);
		bioEventInfo2.setEventId("event002");
		bioEventInfo2.setEventId("ex002");
		modifiedBiometricEventInfoList.add(bioEventInfo2);

		System.out.println(preSnSegVerMap.size());

		regesterData(syncJobId, callbackUrl, modifiedBiometricEventInfoList);
		Assert.assertEquals(2, strictSyncCallbackMap.size());
		Set<Entry<StrictSyncCallbackKey, List<SyncSnSegVerInfo>>> tmp = strictSyncCallbackMap.entrySet();
		for (Entry<StrictSyncCallbackKey, List<SyncSnSegVerInfo>> one : tmp) {
			Assert.assertEquals(2, one.getValue().size());
		}
		System.out.println("OKOKOKOK");

	}

	public void regesterData(final String jobId, final String url,
			final List<BiometricEventInfo> modifiedBiometricEventInfoList) {
		modifiedBiometricEventInfoList.stream().forEach(biometricEventInfo -> {
			StrictSyncCallbackKey key = new StrictSyncCallbackKey(jobId, biometricEventInfo.getExternalId(),
					biometricEventInfo.getEventId(), url);
			preSnSegVerMap.entrySet().parallelStream().forEach(e -> {
				if (e.getKey().getSegmentId().intValue() == biometricEventInfo.getAssignedSegmentId().intValue()
						&& e.getKey().getBinId().intValue() == biometricEventInfo.getBinId().intValue()) {
					strictSyncCallbackMap.putIfAbsent(key, e.getValue());
				}
			});
		});

	}

	public void createPreSnSegVerMap() {
		List<BioMatcherSegmentInfo> allSegInfoList = new ArrayList<>();
		BioMatcherSegmentInfo segInfo1 = new BioMatcherSegmentInfo();

		segInfo1.setBinId(35);
		segInfo1.setSegmentId(1000);
		segInfo1.setSegmentVersion(1L);
		segInfo1.setUpdateDateTime(new Date());

		BioMatcherSegmentInfo segInfo2 = new BioMatcherSegmentInfo();
		segInfo2.setBinId(35);
		segInfo2.setSegmentId(2000);
		segInfo2.setSegmentVersion(2L);
		segInfo2.setUpdateDateTime(new Date());

		allSegInfoList.add(segInfo1);
		allSegInfoList.add(segInfo2);

		List<BioMatcherNodeSegmentInfo> snSegInfoList = new ArrayList<>();
		BioMatcherNodeSegmentInfo snInfo1 = new BioMatcherNodeSegmentInfo();

		snInfo1.setMatcherNodeId("sn1");
		snInfo1.setAssignedFlag(Boolean.TRUE);
		snInfo1.setSegmentId(1000);
		snInfo1.setSegmentVersion(-1L);

		BioMatcherNodeSegmentInfo snInfo2 = new BioMatcherNodeSegmentInfo();
		snInfo2.setMatcherNodeId("sn2");
		snInfo2.setAssignedFlag(Boolean.TRUE);
		snInfo2.setSegmentId(1000);
		snInfo2.setSegmentVersion(-1L);

		BioMatcherNodeSegmentInfo snInfo3 = new BioMatcherNodeSegmentInfo();
		snInfo3.setMatcherNodeId("sn3");
		snInfo3.setAssignedFlag(Boolean.TRUE);
		snInfo3.setSegmentId(2000);
		snInfo3.setSegmentVersion(-1L);

		BioMatcherNodeSegmentInfo snInfo4 = new BioMatcherNodeSegmentInfo();
		snInfo4.setMatcherNodeId("sn4");
		snInfo4.setAssignedFlag(Boolean.TRUE);
		snInfo4.setSegmentId(2000);
		snInfo4.setSegmentVersion(-1L);

		snSegInfoList.add(snInfo1);
		snSegInfoList.add(snInfo2);
		snSegInfoList.add(snInfo3);
		snSegInfoList.add(snInfo4);

		allSegInfoList.parallelStream().forEach(bioMatcherSegmentInfo -> {
			Integer binId = bioMatcherSegmentInfo.getBinId();
			Integer segId = bioMatcherSegmentInfo.getSegmentId();
			preSnSegVerMap.put(new SegIdBinKey(segId, binId), getSyncSnSegVerInfo(segId, binId, snSegInfoList));
		});

		Assert.assertEquals(2, preSnSegVerMap.size());
		Set<Entry<SegIdBinKey, List<SyncSnSegVerInfo>>> tmp = preSnSegVerMap.entrySet();
		for (Entry<SegIdBinKey, List<SyncSnSegVerInfo>> one : tmp) {
			Assert.assertEquals(2, one.getValue().size());
		}
	}

	private List<SyncSnSegVerInfo> getSyncSnSegVerInfo(Integer segmentId, Integer binId,
			List<BioMatcherNodeSegmentInfo> snSegInfoList) {
		List<SyncSnSegVerInfo> snSegVerInfos = new ArrayList<>();
		AtomicInteger count = new AtomicInteger(0);
		for (BioMatcherNodeSegmentInfo info : snSegInfoList) {
			if (info.getSegmentId().intValue() == segmentId.intValue() && info.getAssignedFlag().booleanValue()) {
				SyncSnSegVerInfo snSegInfo = new SyncSnSegVerInfo(info.getMatcherNodeId(), binId, info.getSegmentId(),
						info.getSegmentVersion(), Boolean.FALSE);
				snSegVerInfos.add(snSegInfo);
				count.incrementAndGet();
				if (count.intValue() >= 2) {
					break;
				}
			}
		}
		return snSegVerInfos;
	}

	public List<BioMatcherSegmentInfo> createSegInfoList(int count) {
		List<BioMatcherSegmentInfo> allSegInfoList = new ArrayList<>();
		for (int i = 0; i < count; i++) {
			BioMatcherSegmentInfo segInfo = new BioMatcherSegmentInfo();
			segInfo.setBinId(35);
			segInfo.setSegmentId(1000 * (i + 1));
			segInfo.setSegmentVersion(Long.valueOf(i + 1));
			segInfo.setUpdateDateTime(new Date());
			allSegInfoList.add(segInfo);
		}
		return allSegInfoList;

	}

	public List<BioMatcherNodeSegmentInfo> createSnSegInfoList(int count) {
		List<BioMatcherNodeSegmentInfo> snSegInfoList = new ArrayList<>();
		for (int i = 0; i < count; i++) {
			BioMatcherNodeSegmentInfo snInfo = new BioMatcherNodeSegmentInfo();
			snInfo.setMatcherNodeId("sn" + (i + 1));
			snInfo.setAssignedFlag(Boolean.TRUE);
			snInfo.setSegmentId(1000 * (i + 1));
			snInfo.setSegmentVersion(-1L);
		}
		return snSegInfoList;
	}
}
