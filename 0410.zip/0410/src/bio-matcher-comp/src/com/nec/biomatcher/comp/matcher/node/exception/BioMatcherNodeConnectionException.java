package com.nec.biomatcher.comp.matcher.node.exception;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

/**
 * The Class BioMatcherNodeConnectionException.
 */
public class BioMatcherNodeConnectionException extends CoreException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new bio matcher node connection exception.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public BioMatcherNodeConnectionException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new bio matcher node connection exception.
	 *
	 * @param message
	 *            the message
	 */
	public BioMatcherNodeConnectionException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new bio matcher node connection exception.
	 *
	 * @param cause
	 *            the cause
	 */
	public BioMatcherNodeConnectionException(Throwable cause) {
		super(cause.getMessage(), cause);
	}

}
