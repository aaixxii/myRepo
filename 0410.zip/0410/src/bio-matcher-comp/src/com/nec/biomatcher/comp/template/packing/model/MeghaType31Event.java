package com.nec.biomatcher.comp.template.packing.model;

import java.io.PrintStream;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Set;

import com.google.common.collect.Sets;
import com.nec.biomatcher.comp.template.packing.exception.MeghaTemplateException;
import com.nec.biomatcher.comp.template.packing.util.MeghaEventDataSizeBuilder;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateConfig;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateUtil;
import com.nec.biomatcher.spec.transfer.model.AlgorithmType;

public class MeghaType31Event extends MeghaEvent {
	public static final int COUNT_MAX_FINGERS = 10;

	private byte[] quality;
	private byte cmlafFeatureData[];

	public void print(PrintStream printStream) {
		if (eventHeader != null) {
			eventHeader.print(printStream);
		}

		printStream.printf("%-20s - %s\n", "quality", Arrays.toString(quality));
		printStream.printf("%-20s - %s\n", "cmlafFeatureData", cmlafFeatureData != null);
	}

	public static int getEventDataSize(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		return new MeghaEventDataSizeBuilder(meghaTemplateConfig).quality(10).featureDataLength(4)
				.featureData(1, "FINGER_CMLAF_FEATURE_DATA_SIZE").build();
	}

	public static final Set<AlgorithmType> getAlgorithmTypes() {
		return Sets.newHashSet(AlgorithmType.FINGER_CMLAF);
	}

	@Override
	public byte[] pack(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {

		if (cmlafFeatureData == null) {
			throw new MeghaTemplateException("cmlafFeatureData is not set");
		}

		if (eventHeader == null) {
			eventHeader = new MeghaEventHeader();
		}

		eventHeader.setAlgType(AlgorithmType.FINGER_CMLAF.getValue().byteValue());

		if (quality == null) {
			quality = new byte[COUNT_MAX_FINGERS];
		}

		byte[] eventData = new byte[getEventDataSize(meghaTemplateConfig)];
		ByteBuffer eventDataBuf = ByteBuffer.wrap(eventData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		eventDataBuf.put(eventHeader.pack());
		eventDataBuf.put(quality);

		if (cmlafFeatureData.length == 0
				|| cmlafFeatureData.length > meghaTemplateConfig.getFeatureSize("FINGER_CMLAF_FEATURE_DATA_SIZE")) {
			throw new MeghaTemplateException("Invalid cmlafFeatureData length, actual: " + cmlafFeatureData.length
					+ ", expected: " + meghaTemplateConfig.getFeatureSize("FINGER_CMLAF_FEATURE_DATA_SIZE"));
		}

		eventDataBuf.putInt(cmlafFeatureData.length);

		eventDataBuf.put(cmlafFeatureData);

		eventDataBuf.position(eventDataBuf.position()
				+ meghaTemplateConfig.getFeatureSize("FINGER_CMLAF_FEATURE_DATA_SIZE") - cmlafFeatureData.length);

		return eventData;
	}

	@Override
	public void unpack(byte[] eventData, MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		ByteBuffer eventDataBuf = ByteBuffer.wrap(eventData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		eventHeader = new MeghaEventHeader();
		eventHeader.unpack(eventDataBuf);

		quality = new byte[COUNT_MAX_FINGERS];
		eventDataBuf.get(quality);

		int dataSize = eventDataBuf.getInt();

		if (dataSize == 0 || dataSize > meghaTemplateConfig.getFeatureSize("FINGER_CMLAF_FEATURE_DATA_SIZE")) {
			throw new MeghaTemplateException("Invalid dataSize length, actual: " + dataSize + ", expected: "
					+ meghaTemplateConfig.getFeatureSize("FINGER_CMLAF_FEATURE_DATA_SIZE"));
		}

		cmlafFeatureData = new byte[dataSize];

		eventDataBuf.get(cmlafFeatureData);

		eventDataBuf.position(eventDataBuf.position()
				+ meghaTemplateConfig.getFeatureSize("FINGER_CMLAF_FEATURE_DATA_SIZE") - cmlafFeatureData.length);
	}

	public byte[] getQuality() {
		return quality;
	}

	public void setQuality(byte[] quality) {
		this.quality = quality;
	}

	public byte[] getCmlafFeatureData() {
		return cmlafFeatureData;
	}

	public void setCmlafFeatureData(byte[] cmlafFeatureData) {
		this.cmlafFeatureData = cmlafFeatureData;
	}

}
