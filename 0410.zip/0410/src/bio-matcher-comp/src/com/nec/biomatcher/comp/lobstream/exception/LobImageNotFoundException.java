package com.nec.biomatcher.comp.lobstream.exception;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

/**
 * The Class LobImageNotFoundException.
 */
public class LobImageNotFoundException extends CoreException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new lob image not found exception.
	 *
	 * @param errorCode
	 *            the error code
	 * @param message
	 *            the message
	 */
	public LobImageNotFoundException(String errorCode, String message) {
		super(errorCode, message);
	}

	/**
	 * Instantiates a new lob image not found exception.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public LobImageNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new lob image not found exception.
	 *
	 * @param message
	 *            the message
	 */
	public LobImageNotFoundException(String message) {
		super("LB002", message);
	}

	/**
	 * Instantiates a new lob image not found exception.
	 *
	 * @param cause
	 *            the cause
	 */
	public LobImageNotFoundException(Throwable cause) {
		super(cause);
	}
}
