package com.nec.biomatcher.comp.admin.model;

import java.util.Date;
import java.util.Set;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.core.Dto;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BioUserInfo implements Dto {
	private static final long serialVersionUID = 1L;

	@XmlAttribute
	private String userId;

	@XmlAttribute
	private String userName;

	@XmlAttribute
	private String password;

	@XmlAttribute
	private Date dateTimeCreate;

	@XmlAttribute
	private Date dateTimeupdate;

	@XmlElement(nillable = true, required = false)
	private Set<String> roles;

	public BioUserInfo() {

	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Set<String> getRoles() {
		return roles;
	}

	public void setRoles(Set<String> roles) {
		this.roles = roles;
	}

	public Date getDateTimeCreate() {
		return dateTimeCreate;
	}

	public void setDateTimeCreate(Date dateTimeCreate) {
		this.dateTimeCreate = dateTimeCreate;
	}

	public Date getDateTimeupdate() {
		return dateTimeupdate;
	}

	public void setDateTimeupdate(Date dateTimeupdate) {
		this.dateTimeupdate = dateTimeupdate;
	}

}
