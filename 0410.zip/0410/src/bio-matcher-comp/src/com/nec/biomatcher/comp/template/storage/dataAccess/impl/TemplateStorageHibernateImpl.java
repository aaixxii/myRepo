package com.nec.biomatcher.comp.template.storage.dataAccess.impl;

import com.nec.biomatcher.comp.template.storage.dataAccess.TemplateStorageDao;
import com.nec.biomatcher.core.framework.dataAccess.AbstractHibernateDao;
import com.nec.biomatcher.core.framework.dataAccess.DaoException;
import com.nec.biomatcher.core.framework.dataAccess.HibernateDaoException;

/**
 * The Class TemplateStorageHibernateImpl.
 */
public class TemplateStorageHibernateImpl extends AbstractHibernateDao implements TemplateStorageDao {

	public int deleteBioTemplateDataInfo(String templateDataId) throws DaoException {
		try {
			String hql = "delete from BioTemplateDataInfo where templateDataId=:templateDataId";

			int deleteCount = this.currentSession().createQuery(hql).setString("templateDataId", templateDataId)
					.executeUpdate();

			return deleteCount;
		} catch (Throwable th) {
			throw new HibernateDaoException(th);
		}
	}
}
