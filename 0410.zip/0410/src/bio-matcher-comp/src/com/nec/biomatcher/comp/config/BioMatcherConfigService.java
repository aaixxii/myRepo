package com.nec.biomatcher.comp.config;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import com.nec.biomatcher.comp.config.exception.BioMatcherConfigServiceException;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherBinInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherNodeSegmentInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherSegmentInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerConnectionInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerGroupInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricIdInfo;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioConnectionType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioProtocolType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioServerState;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioServerType;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateConfig;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateParser;
import com.nec.biomatcher.core.framework.cache.InvalidateMethodCache;
import com.nec.biomatcher.core.framework.cache.MethodCache;
import com.nec.biomatcher.core.framework.common.ValuedHashMap;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentValuedHashMap;
import com.nec.biomatcher.spec.transfer.model.AlgorithmType;
import com.nec.biomatcher.spec.transfer.model.TemplateType;

/**
 * The Interface BioMatcherConfigService.
 */
public interface BioMatcherConfigService {

	@MethodCache
	public List<BioMatcherBinInfo> getMatcherBinInfoList() throws BioMatcherConfigServiceException;

	/**
	 * Gets the matcher bin info.
	 *
	 * @param binId
	 *            the bin id
	 * @return the matcher bin info
	 * @throws BioMatcherConfigServiceException
	 *             the bio matcher config service exception
	 */
	@MethodCache
	public BioMatcherBinInfo getMatcherBinInfo(Integer binId) throws BioMatcherConfigServiceException;

	/**
	 * Gets the matcher bin info for update.
	 *
	 * @param binId
	 *            the bin id
	 * @return the matcher bin info for update
	 * @throws BioMatcherConfigServiceException
	 *             the bio matcher config service exception
	 */
	@MethodCache
	public BioMatcherBinInfo getMatcherBinInfoForUpdate(Integer binId) throws BioMatcherConfigServiceException;

	@MethodCache
	public List<BioServerGroupInfo> getServerGroupInfoList() throws BioMatcherConfigServiceException;

	@MethodCache
	public BioServerGroupInfo getServerGroupInfo(String groupId) throws BioMatcherConfigServiceException;

	@InvalidateMethodCache
	public void saveServerGroupInfo(BioServerGroupInfo bioServerGroupInfo) throws BioMatcherConfigServiceException;

	@InvalidateMethodCache
	public void deleteServerGroupInfo(String groupId) throws BioMatcherConfigServiceException;

	/**
	 * ******************************.
	 *
	 * @param serverId
	 *            the server id
	 * @return the server info
	 * @throws BioMatcherConfigServiceException
	 *             the bio matcher config service exception
	 */

	@MethodCache
	public BioServerInfo getServerInfo(String serverId) throws BioMatcherConfigServiceException;

	@MethodCache
	public Map<String, Integer> getServerCapacityGroupMap(String serverId) throws BioMatcherConfigServiceException;

	@InvalidateMethodCache
	public void saveServerInfo(BioServerInfo bioServerInfo) throws BioMatcherConfigServiceException;

	@InvalidateMethodCache
	public void deleteServerInfo(String serverId) throws BioMatcherConfigServiceException;

	@MethodCache
	public List<BioServerInfo> getServerInfoList() throws BioMatcherConfigServiceException;

	/**
	 * Gets the server info list.
	 *
	 * @param serverType
	 *            the server type
	 * @return the server info list
	 * @throws BioMatcherConfigServiceException
	 *             the bio matcher config service exception
	 */
	@MethodCache
	public List<BioServerInfo> getServerInfoList(BioServerType serverType) throws BioMatcherConfigServiceException;

	@MethodCache
	public Set<String> getServerHostnameSet(BioServerType serverType) throws BioMatcherConfigServiceException;

	/**
	 * Gets the server info by server type.
	 *
	 * @param serverType
	 *            the server type
	 * @param componentType
	 *            the component type
	 * @return the server info by server type
	 * @throws BioMatcherConfigServiceException
	 *             the bio matcher config service exception
	 */
	@MethodCache
	public BioServerInfo getServerInfoByServerType(BioServerType serverType, BioComponentType componentType)
			throws BioMatcherConfigServiceException;

	@MethodCache
	public List<BioServerInfo> getServerInfoListByServerType(BioServerType serverType, BioComponentType componentType)
			throws BioMatcherConfigServiceException;

	/**
	 * Gets the server info list by server group.
	 *
	 * @param serverGroupId
	 *            the server group id
	 * @return the server info list by server group
	 * @throws BioMatcherConfigServiceException
	 *             the bio matcher config service exception
	 */
	@MethodCache
	public List<BioServerInfo> getServerInfoListByServerGroup(String serverGroupId)
			throws BioMatcherConfigServiceException;

	/**
	 * Gets the server info list by server host.
	 *
	 * @param serverHost
	 *            the server host
	 * @return the server info list by server host
	 * @throws BioMatcherConfigServiceException
	 *             the bio matcher config service exception
	 */
	@MethodCache
	public List<BioServerInfo> getServerInfoListByServerHost(String serverHost) throws BioMatcherConfigServiceException;

	/**
	 * Gets the server info by server host.
	 *
	 * @param serverHost
	 *            the server host
	 * @param componentType
	 *            the component type
	 * @return the server info by server host
	 * @throws BioMatcherConfigServiceException
	 *             the bio matcher config service exception
	 */
	@MethodCache
	public BioServerInfo getServerInfoByServerHost(String serverHost, BioComponentType componentType)
			throws BioMatcherConfigServiceException;

	@MethodCache
	public BioServerInfo getServerInfoByServerHost(String serverHost, String serverIpAddress,
			BioComponentType componentType) throws BioMatcherConfigServiceException;

	/**
	 * Gets the server info list by server group.
	 *
	 * @param serverGroupId
	 *            the server group id
	 * @param componentType
	 *            the component type
	 * @return the server info list by server group
	 * @throws BioMatcherConfigServiceException
	 *             the bio matcher config service exception
	 */
	@MethodCache
	public List<BioServerInfo> getServerInfoListByServerGroup(String serverGroupId, BioComponentType componentType)
			throws BioMatcherConfigServiceException;

	/**
	 * Gets the server info list by component type.
	 *
	 * @param componentType
	 *            the component type
	 * @return the server info list by component type
	 * @throws BioMatcherConfigServiceException
	 *             the bio matcher config service exception
	 */
	@MethodCache
	public List<BioServerInfo> getServerInfoListByComponentType(BioComponentType componentType)
			throws BioMatcherConfigServiceException;

	/**
	 * Gets the server info list by component type.
	 *
	 * @param componentType
	 *            the component type
	 * @param serverState
	 *            the server state
	 * @return the server info list by component type
	 * @throws BioMatcherConfigServiceException
	 *             the bio matcher config service exception
	 */
	@MethodCache
	public List<BioServerInfo> getServerInfoListByComponentType(BioComponentType componentType,
			BioServerState serverState) throws BioMatcherConfigServiceException;

	@MethodCache
	public List<String> getRemoteServerInfoListBySiteId(String siteId) throws BioMatcherConfigServiceException;

	@InvalidateMethodCache
	public void updateServerInfo(BioServerInfo bioServerInfo) throws BioMatcherConfigServiceException;

	/**
	 * Gets the server connection info.
	 *
	 * @param serverId
	 *            the server id
	 * @param componentType
	 *            the component type
	 * @param connectionType
	 *            the connection type
	 * @return the server connection info
	 * @throws BioMatcherConfigServiceException
	 *             the bio matcher config service exception
	 */
	@MethodCache
	public BioServerConnectionInfo getServerConnectionInfo(String serverId, BioComponentType componentType,
			BioConnectionType connectionType) throws BioMatcherConfigServiceException;

	@MethodCache
	public List<BioServerConnectionInfo> getServerConnectionInfoList() throws BioMatcherConfigServiceException;

	/**
	 * Gets the server connection url.
	 *
	 * @param serverId
	 *            the server id
	 * @param componentType
	 *            the component type
	 * @param connectionType
	 *            the connection type
	 * @param protocolType
	 *            the protocol type
	 * @return the server connection url
	 * @throws BioMatcherConfigServiceException
	 *             the bio matcher config service exception
	 */
	@MethodCache
	public String getServerConnectionUrl(String serverId, BioComponentType componentType,
			BioConnectionType connectionType, BioProtocolType protocolType) throws BioMatcherConfigServiceException;

	@MethodCache
	public String getServerConnectionUrl(String serverId, BioConnectionType connectionType,
			BioProtocolType protocolType) throws BioMatcherConfigServiceException;

	@InvalidateMethodCache
	public void deleteStaleConnectionSettings() throws BioMatcherConfigServiceException;

	@InvalidateMethodCache
	public void createServerConnnections(String serverId, String serverHost, BioComponentType componentType)
			throws BioMatcherConfigServiceException;

	@MethodCache
	public List<BioMatcherSegmentInfo> getSearchSegmentInfoListByBinId(Integer binId)
			throws BioMatcherConfigServiceException;

	@MethodCache
	public Map<Integer, BioMatcherSegmentInfo> getSegmentIdMatcherSegmentInfoMap()
			throws BioMatcherConfigServiceException;

	@MethodCache
	public List<BioMatcherNodeSegmentInfo> getAllSearchNodeSegmentInfoList() throws BioMatcherConfigServiceException;

	@MethodCache
	public ConcurrentValuedHashMap<String, List<BioMatcherNodeSegmentInfo>> getSearchNodeIdSearchNodeSegmentInfoListMap()
			throws BioMatcherConfigServiceException;

	@MethodCache
	public ConcurrentValuedHashMap<Integer, List<BioMatcherNodeSegmentInfo>> getSegmentIdSearchNodeSegmentInfoListMap()
			throws BioMatcherConfigServiceException;

	@MethodCache
	public BioMatcherNodeSegmentInfo getSearchNodeSegmentInfo(String searchNodeId, Integer segmentId)
			throws BioMatcherConfigServiceException;

	@MethodCache
	public Map<Integer, Set<String>> getAssignedSegmentIdSearchNodeIdListMapBySearchBrokerId(String searchBrokerId)
			throws BioMatcherConfigServiceException;

	@MethodCache
	public Set<String> getAssignedSearchNodeIdListByBinId(Integer binId) throws BioMatcherConfigServiceException;

	@MethodCache
	public Set<String> getAssignedSearchNodeIdListByBinId(Integer binId, String capacityGroupKey)
			throws BioMatcherConfigServiceException;

	@MethodCache
	public Set<Integer> getMissingSegmentAssignmentsByBinId(Integer binId, String capacityGroupKey)
			throws BioMatcherConfigServiceException;

	@MethodCache
	public ConcurrentValuedHashMap<String, Set<String>> getCapacityGroupSearchNodeIdListMap()
			throws BioMatcherConfigServiceException;

	@MethodCache
	public Set<String> getAssignedSearchNodeIdCapacityGroupIdKeyList() throws BioMatcherConfigServiceException;

	@MethodCache
	public Set<String> getAssignedSearchNodeIdListByBinId(Collection<Integer> binIdList)
			throws BioMatcherConfigServiceException;

	@MethodCache
	public Set<String> getAssignedSearchNodeIdListBySegmentId(Integer segmentId)
			throws BioMatcherConfigServiceException;

	@MethodCache
	public Set<String> getAssignedSearchNodeIdList() throws BioMatcherConfigServiceException;

	@MethodCache
	public Set<Integer> getAssignedSegmentIdList() throws BioMatcherConfigServiceException;

	@MethodCache
	public Map<Integer, BiometricIdInfo> getSegmentIdBiometricIdInfoMap() throws BioMatcherConfigServiceException;

	@MethodCache
	public List<BiometricIdInfo> getBiometricIdInfoListByBinId(Integer binId) throws BioMatcherConfigServiceException;

	@MethodCache
	public List<BiometricIdInfo> getBiometricIdInfoList() throws BioMatcherConfigServiceException;

	@MethodCache(timeToLiveSeconds = 120, timeToLiveSecondsParamName = "BIOMETRIC_ID_INFO_CACHE_TTL_SECONDS")
	public Iterator<Integer> getCyclicSegmentIdListByBinId(Integer binId) throws BioMatcherConfigServiceException;

	@MethodCache(timeToLiveSeconds = 120, timeToLiveSecondsParamName = "BIOMETRIC_ID_INFO_CACHE_TTL_SECONDS")
	public TreeSet<Integer> getOrderedSegmentIdSetByBinId(Integer binId) throws BioMatcherConfigServiceException;

	@MethodCache
	public Map<Integer, Integer> getSegmentIdBinIdMap() throws BioMatcherConfigServiceException;

	@MethodCache
	public Set<Integer> getAssignedSegmentIdListBySearchNodeId(String searchNodeId)
			throws BioMatcherConfigServiceException;

	@MethodCache
	public ConcurrentValuedHashMap<String, List<Integer>> getSortedSearchNodeIdSegmentIdListMap()
			throws BioMatcherConfigServiceException;

	@MethodCache
	public ValuedHashMap<String, Set<Integer>> getAssignedSearchNodeIdBinIdSetMap()
			throws BioMatcherConfigServiceException;

	@MethodCache
	public Set<Integer> getAssignedSegmentIdListBySearchBrokerId(String searchBrokerId)
			throws BioMatcherConfigServiceException;

	@MethodCache
	public Set<Integer> getAssignedBinIdListBySearchBrokerId(String searchBrokerId)
			throws BioMatcherConfigServiceException;

	@MethodCache
	public Set<String> getAssignedSearchNodeIdListBySearchBrokerId(String searchBrokerId)
			throws BioMatcherConfigServiceException;

	@MethodCache
	public String getAssignedSearchBrokerIdBySearchNodeGroupId(String searchNodeGroupId)
			throws BioMatcherConfigServiceException;

	@MethodCache
	public Map<String, String> getSearchNodeIdSearchBrokerIdMap() throws BioMatcherConfigServiceException;

	@MethodCache
	public Map<Integer, String> getSegmentIdTemplateTypeMap() throws BioMatcherConfigServiceException;

	@InvalidateMethodCache
	public void saveServerConnectionInfo(BioServerConnectionInfo bioServerConnectionInfo)
			throws BioMatcherConfigServiceException;

	@InvalidateMethodCache
	public void deleteServerConnectionInfo(String serverId, BioComponentType componentType,
			BioConnectionType connectionType) throws BioMatcherConfigServiceException;

	@InvalidateMethodCache
	public void saveMatcherBinInfo(BioMatcherBinInfo bioMatcherBinInfo) throws BioMatcherConfigServiceException;

	@InvalidateMethodCache
	public void deleteMatcherBinInfo(Integer binId) throws BioMatcherConfigServiceException;

	@InvalidateMethodCache
	public void autoCreateAndAssignSegments(Integer binId, Long totalRecords, Long maxRecordsPerSegment,
			Integer snRamSize, Integer segmentRedundancy, String assignedSearchNodes[])
			throws BioMatcherConfigServiceException;

	@InvalidateMethodCache
	public void saveMatcherSegmentInfo(BioMatcherSegmentInfo bioMatcherSegmentInfo)
			throws BioMatcherConfigServiceException;

	@InvalidateMethodCache
	public void saveMatcherSegmentInfo(Integer segmentId, Integer binId, Long startBiometricId, Long endBiometricId,
			String assignedSearchNodes) throws BioMatcherConfigServiceException;

	@InvalidateMethodCache
	public BioMatcherSegmentInfo deleteMatcherSegmentInfo(Integer segmentId) throws BioMatcherConfigServiceException;

	@InvalidateMethodCache
	public void saveMatcherNodeSegmentInfo(String searchNodeId, Integer segmentId, boolean assignedFlag,
			Long segmentVersion) throws BioMatcherConfigServiceException;

	@MethodCache
	public MeghaTemplateConfig getMeghaTemplateConfig() throws BioMatcherConfigServiceException;

	@MethodCache
	public Map<TemplateType, MeghaTemplateParser> getTemplateTypeMeghaTemplateParserMap()
			throws BioMatcherConfigServiceException;

	@MethodCache
	public Map<Integer, MeghaTemplateParser> getBinIdMeghaTemplateParserMap() throws BioMatcherConfigServiceException;

	@MethodCache
	public Map<Integer, Integer> getBinIdMaxEventCountMap() throws BioMatcherConfigServiceException;

	@MethodCache
	public Map<Integer, Integer> getBinIdTemplateDataSizeMap() throws BioMatcherConfigServiceException;

	@MethodCache
	public Map<Integer, Integer> getBinIdTemplateTypeCodeMap() throws BioMatcherConfigServiceException;

	@MethodCache
	public Map<TemplateType, Set<AlgorithmType>> getTemplateTypeAlgorithmTypesMap()
			throws BioMatcherConfigServiceException;

	@MethodCache
	public int getUserFlagByteCount() throws BioMatcherConfigServiceException;

	@MethodCache
	public Map<String, Integer> getFeatureDataSizeMap() throws BioMatcherConfigServiceException;

	@MethodCache
	public Map<String, Integer> getFunctionCapacityMap() throws BioMatcherConfigServiceException;

	@MethodCache
	public Map<String, Integer> getSearchFunctionMaxMultiSegmentJobCountMap() throws BioMatcherConfigServiceException;

	@MethodCache
	public Map<String, Float> getSearchNodeFunctionCapacityOverloadFactorMap() throws BioMatcherConfigServiceException;

	@InvalidateMethodCache
	public void clearCache();
}
