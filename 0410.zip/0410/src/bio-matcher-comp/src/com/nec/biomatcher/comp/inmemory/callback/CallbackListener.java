package com.nec.biomatcher.comp.inmemory.callback;

@FunctionalInterface
public interface CallbackListener {
	public void notifyCallback(String taskKey, String callbackUrl);
}
