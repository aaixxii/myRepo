package com.nec.biomatcher.comp.cluster;

@FunctionalInterface
public interface ClusterEventHandler {
    public void handleEvent(ClusterEvent clusterEvent);
}
