package com.nec.biomatcher.comp.callback.impl;

import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Supplier;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.apache.http.impl.client.DefaultHttpRequestRetryHandler;
import org.apache.log4j.Logger;
import org.apache.log4j.NDC;
import org.springframework.beans.factory.InitializingBean;

import com.nec.biomatcher.comp.callback.CallbackService;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.concurrent.BlockingQueueExecutor;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentValuedHashMap;

public class HttpCallbackServiceImpl implements CallbackService, InitializingBean {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(HttpCallbackServiceImpl.class);
	private static final Logger dumpBatchCallbackPayloadLogger = Logger.getLogger("DUMP_BATCH_CALLBACK_PAYLOAD");

	private static final MultiThreadedHttpConnectionManager connectionManager = new MultiThreadedHttpConnectionManager();
	private static final HttpClient httpClient = buildHttpClient();

	private static ConcurrentValuedHashMap<String, LinkedBlockingQueue<String>> hostKeyCallbackUrlQueueMap = new ConcurrentValuedHashMap<>(
			callbackHostKey -> new LinkedBlockingQueue<>());

	private static ConcurrentValuedHashMap<String, Lock> callbackHostKeyPollingLockMap = new ConcurrentValuedHashMap<>(
			callbackHostKey -> new ReentrantLock());

	private static BlockingQueueExecutor<String> batchCallbackExecutor;

	private static AtomicInteger initializationCount = new AtomicInteger();

	/**
	 * Post callback.
	 *
	 * @param url
	 *            the url
	 * @param body
	 *            the body
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public final void postCallback(String url, String body) throws Exception {
		if (CallbackService.isBatchCallbackUrl(url)) {
			postBatchCallback(url);
		} else {
			postCallbackInternal(url, body, false);
		}
	}

	public final void postBatchCallback(String url) throws Exception {
		URI uri = new URI(url);
		String callbackHostKey = uri.getRawAuthority();
		addToBatchCallbackQueue(callbackHostKey, url);
	}

	private static final void postCallbackInternal(String url, String body, boolean isBatchCallback)
			throws IOException {
		PostMethod httpPost = new PostMethod(url);
		int payloadSize = 0;
		try {
			if (isBatchCallback) {
				httpPost.setRequestHeader("batchCallbackFlag", "true");
			}

			body = body == null ? "COMPLETED" : body;

			payloadSize = body.length();

			StringRequestEntity entity = new StringRequestEntity(body, "application/octet-stream",
					StandardCharsets.UTF_8.name());
			httpPost.setRequestEntity(entity);

			Integer result = null;
			long startTimeMilli = System.currentTimeMillis();
			boolean errorFlag = true;
			try {
				result = httpClient.executeMethod(httpPost);

				if (result == HttpStatus.SC_OK) {
					errorFlag = false;
				}
			} finally {
				long timeTakenMilli = System.currentTimeMillis() - startTimeMilli;
				if (errorFlag) {
					logger.error("Error postCallbackInternal: responseCode: " + result + ", payloadSize: " + payloadSize
							+ ", url: " + url + ", body: " + body + ", timeTakenMilli: " + timeTakenMilli);
				} else if (timeTakenMilli > 100 || logger.isTraceEnabled()) {
					CommonLogger.PERF_LOG.trace("Finished postCallbackInternal: responseCode: " + result
							+ ", payloadSize: " + payloadSize + (isBatchCallback ? ", isBatchCallback: true" : "")
							+ ", url: " + url + ", timeTakenMilli: " + (System.currentTimeMillis() - startTimeMilli));
				} else if (isBatchCallback && dumpBatchCallbackPayloadLogger.isTraceEnabled()) {
					CommonLogger.PAYLOAD_LOG.trace("Finished batch postCallbackInternal: responseCode: " + result
							+ ", url: " + url + ", body: " + body + ", timeTakenMilli: " + timeTakenMilli);
				}
			}
		} finally {
			if (httpPost != null) {
				httpPost.releaseConnection();
			}
		}
	}

	private static final void processBatchCallbackByHostKey(String callbackHostKey) {
		Lock pollingLock = callbackHostKeyPollingLockMap.getValue(callbackHostKey);

		if (!pollingLock.tryLock()) {
			return;
		}

		final long maxPollWaitMill = 10;
		final LinkedBlockingQueue<String> callbackUrlQueue = hostKeyCallbackUrlQueueMap.getValue(callbackHostKey);

		String firstCallbackUrl = null;
		StringBuilder callbackUrListPayload = null;
		try {
			NDC.clear();
			NDC.push(callbackHostKey);

			int index = 0;
			String callbackUrl = null;
			long pollStartTime = System.currentTimeMillis();
			long pendingPollMill = maxPollWaitMill;
			while ((callbackUrl = callbackUrlQueue.poll(pendingPollMill, TimeUnit.MILLISECONDS)) != null) {
				if (index == 0) {
					firstCallbackUrl = callbackUrl;
					callbackUrListPayload = new StringBuilder();
				}

				callbackUrListPayload.append(callbackUrl);
				callbackUrListPayload.append(System.lineSeparator());
				index++;

				pendingPollMill = maxPollWaitMill - (System.currentTimeMillis() - pollStartTime);

				if (index >= 50 || pendingPollMill <= 0) {
					break;
				}
			}
		} catch (Throwable th) {
			logger.error("Error during processBatchCallbackByHostKey polling : " + th.getMessage(), th);
		} finally {
			pollingLock.unlock();
		}

		if (!callbackUrlQueue.isEmpty()) {
			batchCallbackExecutor.addToQueue(callbackHostKey);
		}

		if (firstCallbackUrl != null && callbackUrListPayload != null) {
			try {
				postCallbackInternal(firstCallbackUrl, callbackUrListPayload.toString(), true);
			} catch (Throwable th) {
				logger.error("Error during processBatchCallbackByHostKey: callbackHostKey: " + callbackHostKey
						+ ", firstCallbackUrl: " + firstCallbackUrl + ", callbackUrListPayload: "
						+ callbackUrListPayload + " : " + th.getMessage(), th);
			}
		}
	}

	private static final void addToBatchCallbackQueue(String callbackHostKey, String callbackUrl) {
		LinkedBlockingQueue<String> callbackUrlQueue = hostKeyCallbackUrlQueueMap.getValue(callbackHostKey);
		callbackUrlQueue.add(callbackUrl);
		batchCallbackExecutor.addToQueue(callbackHostKey);
	}

	private static final HttpClient buildHttpClient() {
		connectionManager.getParams().setDefaultMaxConnectionsPerHost(250);
		connectionManager.getParams().setMaxTotalConnections(3000);
		connectionManager.getParams().setLinger(1);
		connectionManager.getParams().setConnectionTimeout(120000);
		connectionManager.getParams().setSoTimeout(120000);
		// connectionManager.getParams().setTcpNoDelay(true);
		connectionManager.getParams().setParameter(HttpMethodParams.RETRY_HANDLER,
				new DefaultHttpRequestRetryHandler(0, false));
		HttpClient httpClient = new HttpClient(connectionManager);
		return httpClient;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		logger.info("In afterPropertiesSet: " + initializationCount.get());

		synchronized (ZmqCallbackServiceImpl.class) {
			if (initializationCount.get() > 0) {
				return;
			}

			initializationCount.incrementAndGet();

			Supplier<Integer> concurrencySupplier = BioParameterService.getIntSupplier("CALLBACK_EXECUTOR_CONCURRENCY",
					"DEFAULT", 50);

			batchCallbackExecutor = new BlockingQueueExecutor<>("HTTP_CALLBACK_EXECUTOR",
					callbackHostKey -> processBatchCallbackByHostKey(callbackHostKey), concurrencySupplier);
		}
	}

}
