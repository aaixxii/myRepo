package com.nec.biomatcher.comp.entities.dataAccess.types;

import javax.xml.bind.annotation.XmlEnum;

/**
 * The Enum BioMatcherNodeState.
 */
@XmlEnum
public enum BioMatcherNodeState {

	/** The active. */
	ACTIVE,

	/** The offline. */
	OFFLINE,

	/** The standby. */
	STANDBY;
}
