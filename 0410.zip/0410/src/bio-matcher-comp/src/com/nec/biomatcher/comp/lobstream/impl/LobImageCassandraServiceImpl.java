package com.nec.biomatcher.comp.lobstream.impl;

import java.nio.ByteBuffer;
import java.util.Date;
import java.util.Iterator;
import java.util.UUID;

import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;

import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.utils.Bytes;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.lobstream.LobImageService;
import com.nec.biomatcher.comp.lobstream.exception.LobImageNotFoundException;
import com.nec.biomatcher.comp.lobstream.exception.LobImageServiceException;
import com.nec.biomatcher.comp.util.CassandraConnector;
import com.nec.biomatcher.core.framework.common.CommonLogger;

public class LobImageCassandraServiceImpl  implements LobImageService, InitializingBean {

    private static final Logger logger = Logger.getLogger(LobImageCassandraServiceImpl.class);

    private BioMatcherConfigService bioMatcherConfigService;
    
    private BioParameterService bioParameterService;
    
    private CassandraConnector cassandraConnector;
    
    private String insertSql = "insert into BIO_LOB_DATA_INFO (LOB_ID, LOB_TYPE, CREATE_DATETIME, LOB_DATA) values (?, ?, ?, ?)";
    private String selectLobDataQuery = "select LOB_DATA from BIO_LOB_DATA_INFO where LOB_ID=? and LOB_TYPE=?";
    private String selectLobIdQuery = "select LOB_ID from BIO_LOB_DATA_INFO where LOB_ID=? and LOB_TYPE=?";
    private String deleteLobSql = "delete from BIO_LOB_DATA_INFO where LOB_ID=? and LOB_TYPE=?";
    private String deleteLobsByLobIdSql = "delete from BIO_LOB_DATA_INFO where LOB_ID=?";
    private String lobHousekeepingSelectSql = "select LOB_ID, LOB_TYPE from BIO_LOB_DATA_INFO where CREATE_DATETIME<=? LIMIT 5000 ALLOW FILTERING";

    public String createLob(String lobId, byte[] lobData, String lobType) throws LobImageServiceException {
        try {
            Session session = cassandraConnector.getPooledSession(bioMatcherConfigService);
            PreparedStatement preparedStatement = session.prepare(insertSql);
            BoundStatement boundStatement = preparedStatement.bind(lobId, lobType, new Date(), ByteBuffer.wrap(lobData));
            session.execute(boundStatement);
            return lobId;
        } catch (Throwable th) {
            throw new LobImageServiceException(th);
        }
    }

    public String createLob(byte[] lobData, String lobType) throws LobImageServiceException {
        String lobId = UUID.randomUUID().toString();
        return createLob(lobId, lobData, lobType);
    }

    public byte[] getLobData(String lobId, String lobType) throws LobImageServiceException, LobImageNotFoundException {
        try {
            Session session = cassandraConnector.getPooledSession(bioMatcherConfigService);
            PreparedStatement preparedStatement = session.prepare(selectLobDataQuery);
            BoundStatement boundStatement = preparedStatement.bind(lobId, lobType);
            Row row = session.execute(boundStatement).one();
            if (row == null) {
                throw new LobImageNotFoundException("Lob data not found with lobId: " + lobId+", lobType: "+lobType);
            }
            ByteBuffer lobDataBuffer = row.getBytes("LOB_DATA");
            return Bytes.getArray(lobDataBuffer);
        } catch (LobImageNotFoundException ex) {
            throw ex;
        } catch (Throwable th) {
            throw new LobImageServiceException("Error in getLobData: lobId: " + lobId + ", lobType: " + lobType + " : " + th.getMessage(), th);
        }
    }

    public boolean checkLobExists(String lobId, String lobType) throws LobImageServiceException {
        try {
            Session session = cassandraConnector.getPooledSession(bioMatcherConfigService);
            PreparedStatement preparedStatement = session.prepare(selectLobIdQuery);
            BoundStatement boundStatement = preparedStatement.bind(lobId, lobType);
            Row row = session.execute(boundStatement).one();
            return row!=null && !row.isNull("LOB_ID");
        } catch (Throwable th) {
            throw new LobImageServiceException(th);
        }
    }

    public boolean deleteLob(String lobId, String lobType) throws LobImageServiceException {
        try {
            Session session = cassandraConnector.getPooledSession(bioMatcherConfigService);
            PreparedStatement preparedStatement = session.prepare(deleteLobSql);
            BoundStatement boundStatement = preparedStatement.bind(lobId, lobType);
            return session.execute(boundStatement).wasApplied();
        } catch (Throwable th) {
            throw new LobImageServiceException(th);
        }
    }

    public void deleteLobsByLobId(String lobId) throws LobImageServiceException {
        try {
            Session session = cassandraConnector.getPooledSession(bioMatcherConfigService);
            PreparedStatement preparedStatement = session.prepare(deleteLobsByLobIdSql);
            BoundStatement boundStatement = preparedStatement.bind(lobId);
            session.execute(boundStatement);
        } catch (Throwable th) {
            throw new LobImageServiceException(th);
        }
    }

    public void performLobHousekeeping() {
        try {
            int lobStreamRetentionHours = bioParameterService.getParameterValue("LOBSTREAM_RETENTION_HOURS", "DEFAULT", 2);
            Date retentionDate = DateUtils.addHours(new Date(), -lobStreamRetentionHours);
            Session session = cassandraConnector.getPooledSession(bioMatcherConfigService);
            PreparedStatement preparedStatement = session.prepare(lobHousekeepingSelectSql);
            BoundStatement boundStatement = preparedStatement.bind(retentionDate);
            ResultSet resultSet =session.execute(boundStatement);
            
            preparedStatement = session.prepare(deleteLobSql);
            
            Iterator<Row> rows = resultSet.iterator();
            while (rows.hasNext()) {
                Row row = rows.next();
                String lobId =row.getString("LOB_ID");
                String lobType = row.getString("LOB_TYPE");
                try {
                    boundStatement = preparedStatement.bind(lobId, lobType);
                    session.execute(boundStatement);
                    logger.info("In performLobHousekeeping: After deleting lob with lobId: "+lobId+", lobType: "+lobType);
                }
                catch(Throwable th) {
                    CommonLogger.ERROR_LOG.error("Error in performLobHousekeeping while deleting the lob record with lobId: "+lobId+", lobType: "+lobType+" : "+th.getMessage(), th);
                }
            }
        } catch (Throwable th) {
            th = new LobImageServiceException(th);
            CommonLogger.ERROR_LOG.error("Error during performLobHousekeeping: "+th.getMessage(), th);
        }
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        logger.info("In LobImageCassandraServiceImpl.afterPropertiesSet");
        cassandraConnector = CassandraConnector.getInstance();
        cassandraConnector.initializeConfig(bioMatcherConfigService);
    }

    public void setBioParameterService(BioParameterService bioParameterService) {
        this.bioParameterService = bioParameterService;
    }

    public void setBioMatcherConfigService(BioMatcherConfigService bioMatcherConfigService) {
        this.bioMatcherConfigService = bioMatcherConfigService;
    }
 


}
