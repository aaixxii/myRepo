package com.nec.biomatcher.comp.config.dataAccess.impl;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Restrictions;

import com.nec.biomatcher.comp.config.dataAccess.BioMatcherConfigDao;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerInfo;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioConnectionType;
import com.nec.biomatcher.core.framework.dataAccess.AbstractHibernateDao;
import com.nec.biomatcher.core.framework.dataAccess.DaoException;

/**
 * The Class BioMatcherConfigHibernateImpl.
 */
public class BioMatcherConfigHibernateImpl extends AbstractHibernateDao implements BioMatcherConfigDao {

    public BioServerInfo getServerInfoByServerHostOrIpAddress(String serverHost, String serverIpAddress, BioComponentType componentType) throws DaoException {
        try {
            Session session = this.currentSession();
            Criteria criteria = session.createCriteria(BioServerInfo.class).add(Restrictions.eq("componentType", componentType));
            Disjunction disjunction = Restrictions.disjunction();
            if(StringUtils.isNotBlank(serverHost)) {
                disjunction.add(Restrictions.eq("serverHost", serverHost).ignoreCase());
            }
            if(StringUtils.isNotBlank(serverIpAddress)) {
                disjunction.add(Restrictions.eq("serverHost", serverIpAddress).ignoreCase());
            }
            criteria.add(disjunction);
            criteria.setMaxResults(1);
            return (BioServerInfo)criteria.uniqueResult();
        } catch (Throwable th) {
            throw new DaoException("Error in getServerInfoByServerHostOrIpAddress: " + th.getMessage(), th);
        }
    }
    
    
    public void deleteServerConnectionInfo(String serverId, BioComponentType componentType, BioConnectionType connectionType) throws DaoException {
        try {
            String hql = "delete from BioServerConnectionInfo where serverId=:serverId and componentType=:componentType and connectionType=:connectionType order by serverId";
            this.currentSession().createQuery(hql).setString("serverId", serverId).setParameter("componentType", componentType).setParameter("connectionType", connectionType).executeUpdate();
        } catch (Throwable th) {
            throw new DaoException("Error in deleteServerConnectionInfo: " + th.getMessage(), th);
        }
    }

    public void deleteStaleConnectionSettings() throws DaoException {
        try {
            String hql = "delete from BioServerConnectionInfo where connectionType not in (:connectionType) order by serverId";
            this.currentSession().createQuery(hql).setParameterList("connectionType", BioConnectionType.values()).executeUpdate();
        } catch (Throwable th) {
            throw new DaoException("Error in deleteServerConnectionInfo: " + th.getMessage(), th);
        }
    }
}

