package com.nec.biomatcher.comp.common.parameter;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

import com.nec.biomatcher.comp.common.parameter.dataAccess.BioParameter;
import com.nec.biomatcher.comp.common.parameter.dataAccess.BioParameterScope;
import com.nec.biomatcher.comp.common.parameter.exception.BioParameterServiceException;
import com.nec.biomatcher.comp.common.parameter.impl.BioParameterServiceImpl;
import com.nec.biomatcher.comp.util.ValueChangeNotification;
import com.nec.biomatcher.core.framework.cache.InvalidateMethodCache;
import com.nec.biomatcher.core.framework.cache.MethodCache;
import com.nec.biomatcher.core.framework.common.CheckedFunction;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.pagination.PageRequest;
import com.nec.biomatcher.core.framework.common.pagination.PageResult;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;

/**
 * The Interface BioParameterService.
 */
public interface BioParameterService {

	@InvalidateMethodCache
	public void saveParameter(BioParameter bioParameter) throws BioParameterServiceException;

	@InvalidateMethodCache
	public void saveParameterValue(String parameterName, String scope, String parameterValue)
			throws BioParameterServiceException;

	@InvalidateMethodCache
	public void saveParameterValue(String parameterName, String scope, String dataType, String description,
			String parameterValue) throws BioParameterServiceException;

	@InvalidateMethodCache
	public void updateParameterDataTypeDescription(String parameterName, String scope, String dataType,
			String description) throws BioParameterServiceException;

	public void saveParameterValueIfNotExists(String parameterName, String scope, String dataType, String description,
			String parameterValue) throws BioParameterServiceException;

	public void compareAndSetParameterValue(String parameterName, String scope, String oldParameterValue,
			String newParameterValue) throws BioParameterServiceException;

	public void renameParameterIfExists(String fromParameterName, String scope, String toParameterName)
			throws BioParameterServiceException;

	/**
	 * Gets the parameter.
	 *
	 * @param parameterName
	 *            the parameter name
	 * @param scope
	 *            the scope
	 * @return the parameter
	 * @throws BioParameterServiceException
	 *             the bio parameter service exception
	 */
	@MethodCache
	public BioParameter getParameter(String parameterName, String scope) throws BioParameterServiceException;

	/**
	 * Gets the parameter value.
	 *
	 * @param parameterName
	 *            the parameter name
	 * @param scope
	 *            the scope
	 * @return the parameter value
	 * @throws BioParameterServiceException
	 *             the bio parameter service exception
	 */
	@MethodCache
	public String getParameterValue(String parameterName, String scope) throws BioParameterServiceException;

	/**
	 * Gets the parameter value.
	 *
	 * @param parameterName
	 *            the parameter name
	 * @param scope
	 *            the scope
	 * @param defaultValue
	 *            the default value
	 * @return the parameter value
	 */
	@MethodCache
	public String getParameterValue(String parameterName, String scope, String defaultValue);

	/**
	 * Gets the parameter value.
	 *
	 * @param parameterName
	 *            the parameter name
	 * @param scope
	 *            the scope
	 * @param defaultValue
	 *            the default value
	 * @return the parameter value
	 */
	@MethodCache
	public boolean getParameterValue(String parameterName, String scope, boolean defaultValue);

	/**
	 * Gets the parameter value.
	 *
	 * @param parameterName
	 *            the parameter name
	 * @param scope
	 *            the scope
	 * @param defaultValue
	 *            the default value
	 * @return the parameter value
	 */
	@MethodCache
	public int getParameterValue(String parameterName, String scope, int defaultValue);

	/**
	 * Gets the parameter value.
	 *
	 * @param parameterName
	 *            the parameter name
	 * @param scope
	 *            the scope
	 * @param defaultValue
	 *            the default value
	 * @return the parameter value
	 */
	@MethodCache
	public long getParameterValue(String parameterName, String scope, long defaultValue);

	/**
	 * Gets the parameter value.
	 *
	 * @param parameterName
	 *            the parameter name
	 * @param scope
	 *            the scope
	 * @param defaultValue
	 *            the default value
	 * @return the parameter value
	 */
	@MethodCache
	public double getParameterValue(String parameterName, String scope, double defaultValue);

	/**
	 * Gets the parameter value.
	 *
	 * @param parameterName
	 *            the parameter name
	 * @param scope
	 *            the scope
	 * @param defaultValue
	 *            the default value
	 * @return the parameter value
	 */
	@MethodCache
	public float getParameterValue(String parameterName, String scope, float defaultValue);

	/**
	 * Save variable value.
	 *
	 * @param parameterName
	 *            the parameter name
	 * @param scope
	 *            the scope
	 * @param parameterValue
	 *            the parameter value
	 * @throws BioParameterServiceException
	 *             the bio parameter service exception
	 */
	public void saveVariableValue(String parameterName, String scope, String parameterValue)
			throws BioParameterServiceException;

	/**
	 * Gets the variable value.
	 *
	 * @param parameterName
	 *            the parameter name
	 * @param scope
	 *            the scope
	 * @return the variable value
	 * @throws BioParameterServiceException
	 *             the bio parameter service exception
	 */
	public String getVariableValue(String parameterName, String scope) throws BioParameterServiceException;

	@InvalidateMethodCache
	public void deleteParameter(String parameterName, String scope) throws BioParameterServiceException;

	@InvalidateMethodCache
	public void deleteParameterLike(String parameterName, String scope) throws BioParameterServiceException;

	@MethodCache
	public <R> R getParameterValue(String parameterName, String scope, Function<String, R> convertorFunction)
			throws BioParameterServiceException;

	@MethodCache
	public <R> R getParameterValue(String parameterName, String scope, Function<String, R> convertorFunction,
			String defaultValue) throws BioParameterServiceException;

	@MethodCache
	public <R> R getParameterValue(String parameterName, String scope, CheckedFunction<String, R> convertorFunction)
			throws BioParameterServiceException;

	@MethodCache
	public <R> R getParameterValue(String parameterName, String scope, CheckedFunction<String, R> convertorFunction,
			String defaultValue) throws BioParameterServiceException;

	@MethodCache
	public Map<String, String> getPropertyMap(String parameterName, String scope) throws BioParameterServiceException;

	@InvalidateMethodCache
	public void mergePropertyMap(String parameterName, String scope, Map<String, String> defaultPropertyMap,
			Set<String> keysToBeRemoved, String comments) throws BioParameterServiceException;

	@InvalidateMethodCache
	public Set<String> mergeSet(String parameterName, String scope, String delimiter, String... values)
			throws BioParameterServiceException;

	@MethodCache
	public Set<String> getParameterValueSet(String parameterName, String scope, String delimiter)
			throws BioParameterServiceException;

	@MethodCache
	public List<BioParameter> getParameterList(boolean includeVariableScope) throws BioParameterServiceException;

	@MethodCache
	public List<BioParameterScope> getParameterScopeList() throws BioParameterServiceException;

	@MethodCache
	public <R> R getCachedResult(String cacheKey, Supplier<R> supplier) throws BioParameterServiceException;

	public PageResult<BioParameter> getParameterList(PageRequest pageRequest) throws BioParameterServiceException;

	public static AtomicReference<BioParameterService> bioParameterServiceRef = new AtomicReference<BioParameterService>();

	public static BioParameterService getBioParameterServiceRef() {
		BioParameterService bioParameterService = bioParameterServiceRef.get();
		if (bioParameterService == null) {
			bioParameterService = BioParameterServiceImpl.getSelfAssignedRef();
			if (bioParameterService == null) {
				bioParameterService = SpringServiceManager.getBean("bioParameterService");
				if (bioParameterService != null) {
					bioParameterServiceRef.set(bioParameterService);
				}
			} else {
				bioParameterServiceRef.compareAndSet(null, bioParameterService);
			}
		}
		return bioParameterService;
	}

	public static Supplier<Integer> getIntSupplier(String parameterName, String scope, int defaultValue) {
		Supplier<Integer> supplier = new Supplier<Integer>() {
			BioParameterService bioParameterService;

			@Override
			public Integer get() {
				try {
					if (bioParameterService == null) {
						bioParameterService = getBioParameterServiceRef();
					}

					return bioParameterService.getParameterValue(parameterName, scope, defaultValue);
				} catch (Throwable th) {
					CommonLogger.ERROR_LOG.error("Error in getIntSupplier for parameterName: " + parameterName
							+ ", scope: " + scope + " : " + th.getMessage(), th);
				}
				return defaultValue;
			}
		};
		return supplier;
	}

	public static Supplier<Long> getLongSupplier(String parameterName, String scope, long defaultValue) {
		Supplier<Long> supplier = new Supplier<Long>() {
			BioParameterService bioParameterService;

			@Override
			public Long get() {
				try {
					if (bioParameterService == null) {
						bioParameterService = getBioParameterServiceRef();
					}

					return bioParameterService.getParameterValue(parameterName, scope, defaultValue);
				} catch (Throwable th) {
					CommonLogger.ERROR_LOG.error("Error in getLongSupplier for parameterName: " + parameterName
							+ ", scope: " + scope + " : " + th.getMessage(), th);
				}
				return defaultValue;
			}
		};
		return supplier;
	}

	public static Supplier<String> getStringSupplier(String parameterName, String scope, String defaultValue) {
		Supplier<String> supplier = new Supplier<String>() {
			BioParameterService bioParameterService;

			@Override
			public String get() {
				try {
					if (bioParameterService == null) {
						bioParameterService = getBioParameterServiceRef();
					}

					return bioParameterService.getParameterValue(parameterName, scope, defaultValue);
				} catch (Throwable th) {
					CommonLogger.ERROR_LOG.error("Error in getStringSupplier for parameterName: " + parameterName
							+ ", scope: " + scope + " : " + th.getMessage(), th);
				}
				return defaultValue;
			}
		};
		return supplier;
	}

	public static Supplier<Boolean> getBooleanSupplier(String parameterName, String scope, boolean defaultValue) {
		Supplier<Boolean> supplier = new Supplier<Boolean>() {
			BioParameterService bioParameterService;

			@Override
			public Boolean get() {
				try {
					if (bioParameterService == null) {
						bioParameterService = getBioParameterServiceRef();
					}

					return bioParameterService.getParameterValue(parameterName, scope, defaultValue);
				} catch (Throwable th) {
					CommonLogger.ERROR_LOG.error("Error in getBooleanSupplier for parameterName: " + parameterName
							+ ", scope: " + scope + " : " + th.getMessage(), th);
				}
				return defaultValue;
			}
		};
		return supplier;
	}

	public static ValueChangeNotification<String> getValueChangeNotification(String parameterName, String scope,
			String defaultValue, Consumer<String> consumer) {
		ValueChangeNotification<String> valueChangeNotification = new ValueChangeNotification<>(parameterName,
				getStringSupplier(parameterName, scope, defaultValue), consumer);
		return valueChangeNotification;
	}

	public static ValueChangeNotification<String> getValueChangeNotification(BioParameterService bioParameterService,
			String parameterName, String scope, String defaultValue, Consumer<String> consumer) {
		ValueChangeNotification<String> valueChangeNotification = new ValueChangeNotification<>(parameterName,
				() -> bioParameterService.getParameterValue(parameterName, scope, defaultValue), consumer);
		return valueChangeNotification;
	}
}
