package com.nec.biomatcher.comp.lobstream.impl;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;

import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.lobstream.LobImageService;
import com.nec.biomatcher.comp.lobstream.dataAccess.BioLobDataInfo;
import com.nec.biomatcher.comp.lobstream.dataAccess.LobStrorageDao;
import com.nec.biomatcher.comp.lobstream.exception.LobImageNotFoundException;
import com.nec.biomatcher.comp.lobstream.exception.LobImageServiceException;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.PFLogger;
import com.nec.biomatcher.core.framework.dataAccess.DaoException;

public class LobImageMsSqlServerLmpl implements LobImageService {
    private static final Logger logger = Logger.getLogger(LobImageMsSqlServerLmpl.class);
    
    private LobStrorageDao lobStrorageDao;
    
    private BioParameterService bioParameterService;
    
    @Override
    public String createLob(String lobId, byte[] lobData, String lobType) throws LobImageServiceException {
        BioLobDataInfo bioLobInfo = new BioLobDataInfo();
        bioLobInfo.setLobId(lobId);
        bioLobInfo.setLobType(lobType);
        bioLobInfo.setLobData(lobData);
        bioLobInfo.setCreateDateTime(new Date());
        try {
        	lobStrorageDao.deleteBioLobDataInfo(lobId);
            lobStrorageDao.saveEntity(bioLobInfo);
            lobStrorageDao.flush();
            lobStrorageDao.evict(bioLobInfo);
        } catch (DaoException e) {
            throw new LobImageServiceException(e);
        }
        return lobId;
    }
    
    @Override
    public String createLob(byte[] lobData, String lobType) throws LobImageServiceException {
        String lobId = UUID.randomUUID().toString();
        return createLob(lobId, lobData, lobType);
    }
    
    @Override
    public byte[] getLobData(String lobId, String lobType) throws LobImageServiceException, LobImageNotFoundException {
//        PFLogger.start();
//        if (StringUtils.isBlank(lobId)) {
//            throw new LobImageServiceException("lobId is null or empty");
//        }
//        
//        if (StringUtils.isBlank(lobType)) {
//            throw new LobImageServiceException("lobType is null or empty");
//        }
//        
        BioLobDataInfo bioLobInfo = null;
        
        try {
            bioLobInfo = lobStrorageDao.getEntity(BioLobDataInfo.class, lobId);
            if (bioLobInfo.getLobData() == null || bioLobInfo.getLobData().length < 1) {
                throw new LobImageServiceException(
                    "Lob data bytes is null or empty for lobKey: " + lobId);
            }
            lobStrorageDao.evict(bioLobInfo);
            return bioLobInfo.getLobData();
        } catch (DaoException e) {
            throw new LobImageServiceException(e);
        } finally {
            PFLogger.end(100, "lobKey: " + lobId);
        }
    }
    
    @Override
    public boolean checkLobExists(String lobId, String lobType) throws LobImageServiceException {
        if (StringUtils.isBlank(lobId)) {
            throw new LobImageServiceException("lobId is null or empty");
        }        
        try {
            BioLobDataInfo bioLobInfo = lobStrorageDao.getEntity(BioLobDataInfo.class, lobId);
            if (bioLobInfo != null && bioLobInfo.getLobId() != null) {
                return true;
            } else {
                return false;
            }
        } catch (Throwable th) {
            throw new LobImageServiceException(th);
        }
    }
    
    @Override
    public boolean deleteLob(String lobId, String lobType) throws LobImageServiceException {
        if (StringUtils.isBlank(lobId)) {
            throw new LobImageServiceException("lobId is null or empty");
        }
        
        if (StringUtils.isBlank(lobType)) {
            throw new LobImageServiceException("lobType is null or empty");
        }
        
        try {
            return lobStrorageDao.deleteLob(lobId, lobType);
        } catch (DaoException e) {
            throw new LobImageServiceException(e);
        }
    }
    
    @Override
    public void deleteLobsByLobId(String lobId) throws LobImageServiceException {
        if (StringUtils.isBlank(lobId)) {
            throw new LobImageServiceException("lobId is null or empty");
        }
        
        try {
            lobStrorageDao.deleteBioLobDataInfo(lobId);
        } catch (DaoException e) {
            throw new LobImageServiceException(e);
        }
    }
    
    @Override
    public void performLobHousekeeping() {
    	   int lobStreamRetentionHours = bioParameterService.getParameterValue("LOBSTREAM_RETENTION_HOURS", "DEFAULT", 2);
           Date retentionDate = DateUtils.addHours(new Date(), -lobStreamRetentionHours);
           int count = 0;
           try {
        	  List<BioLobDataInfo> listLobDatas = lobStrorageDao.getLobDataBeforeDate(retentionDate);
        	  if (null == listLobDatas || listLobDatas.size() < 1) return;        		  
        	  for (BioLobDataInfo info : listLobDatas) {
        		  lobStrorageDao.deleteLob(info.getLobId(), info.getLobType());
        		  count++;
        	  }
        	  logger.info("In performLobHousekeeping: delete lob data info count: " + count);
        	   
           }  catch (DaoException e) {
        	   CommonLogger.ERROR_LOG.error(e.getMessage());
           }    	
    }
    
  
    public void performLobHousekeeping_1() {
        int lobStreamRetentionHours = bioParameterService.getParameterValue("LOBSTREAM_RETENTION_HOURS", "DEFAULT", 2);
        Date retentionDate = DateUtils.addHours(new Date(), -lobStreamRetentionHours);
        try {
            int deleteCount = lobStrorageDao.deleteLobDataBeforeDate(retentionDate);
            logger.info("In performLobHousekeeping: delete lob data info count: " + deleteCount);
        } catch (DaoException e) {
            CommonLogger.ERROR_LOG.error(e.getMessage());
        }
    }
    
    public void setLobStrorageDao(LobStrorageDao lobStorageDao) {
        this.lobStrorageDao = lobStorageDao;
    }
    
    public void setBioParameterService(BioParameterService bioParameterService) {
        this.bioParameterService = bioParameterService;
    }
}
