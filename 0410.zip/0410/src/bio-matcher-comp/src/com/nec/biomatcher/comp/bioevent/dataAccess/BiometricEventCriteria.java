package com.nec.biomatcher.comp.bioevent.dataAccess;

import com.nec.biomatcher.comp.common.query.criteria.CriteriaDto;
import com.nec.biomatcher.spec.transfer.core.Dto;

public class BiometricEventCriteria implements Dto {
	private static final long serialVersionUID = 1L;

	private CriteriaDto biometricId;

	private CriteriaDto externalId;

	private CriteriaDto eventId;

	private CriteriaDto binId;

	private CriteriaDto status;

	private CriteriaDto phase;

	private CriteriaDto templateDataKey;

	private CriteriaDto templateSize;

	private CriteriaDto dataVersion;

	private CriteriaDto assignedSegmentId;

	private CriteriaDto updateDateTime;

	public CriteriaDto getBiometricId() {
		return biometricId;
	}

	public void setBiometricId(CriteriaDto biometricId) {
		this.biometricId = biometricId;
	}

	public CriteriaDto getExternalId() {
		return externalId;
	}

	public void setExternalId(CriteriaDto externalId) {
		this.externalId = externalId;
	}

	public CriteriaDto getEventId() {
		return eventId;
	}

	public void setEventId(CriteriaDto eventId) {
		this.eventId = eventId;
	}

	public CriteriaDto getBinId() {
		return binId;
	}

	public void setBinId(CriteriaDto binId) {
		this.binId = binId;
	}

	public CriteriaDto getStatus() {
		return status;
	}

	public void setStatus(CriteriaDto status) {
		this.status = status;
	}

	public CriteriaDto getPhase() {
		return phase;
	}

	public void setPhase(CriteriaDto phase) {
		this.phase = phase;
	}

	public CriteriaDto getTemplateDataKey() {
		return templateDataKey;
	}

	public void setTemplateDataKey(CriteriaDto templateDataKey) {
		this.templateDataKey = templateDataKey;
	}

	public CriteriaDto getTemplateSize() {
		return templateSize;
	}

	public void setTemplateSize(CriteriaDto templateSize) {
		this.templateSize = templateSize;
	}

	public CriteriaDto getDataVersion() {
		return dataVersion;
	}

	public void setDataVersion(CriteriaDto dataVersion) {
		this.dataVersion = dataVersion;
	}

	public CriteriaDto getAssignedSegmentId() {
		return assignedSegmentId;
	}

	public void setAssignedSegmentId(CriteriaDto assignedSegmentId) {
		this.assignedSegmentId = assignedSegmentId;
	}

	public CriteriaDto getUpdateDateTime() {
		return updateDateTime;
	}

	public void setUpdateDateTime(CriteriaDto updateDateTime) {
		this.updateDateTime = updateDateTime;
	}

}
