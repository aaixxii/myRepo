package com.nec.biomatcher.comp.config.dataAccess;

import com.nec.biomatcher.comp.entities.dataAccess.BioServerInfo;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioConnectionType;
import com.nec.biomatcher.core.framework.dataAccess.DaoException;
import com.nec.biomatcher.core.framework.dataAccess.HibernateDao;

/**
 * The Interface BioMatcherConfigDao.
 */
public interface BioMatcherConfigDao extends HibernateDao {
    public BioServerInfo getServerInfoByServerHostOrIpAddress(String serverHost, String serverIpAddress, BioComponentType componentType) throws DaoException;
    
    public void deleteServerConnectionInfo(String serverId, BioComponentType componentType, BioConnectionType connectionType) throws DaoException;

    public void deleteStaleConnectionSettings() throws DaoException;

}
