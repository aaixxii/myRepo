package com.nec.biomatcher.comp.template.packing.model;

import java.io.PrintStream;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.google.common.collect.Sets;
import com.google.common.primitives.UnsignedBytes;
import com.nec.biomatcher.comp.template.packing.exception.MeghaTemplateException;
import com.nec.biomatcher.comp.template.packing.util.MeghaEventDataSizeBuilder;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateConfig;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateUtil;
import com.nec.biomatcher.core.framework.common.HoldFlagUtil;
import com.nec.biomatcher.spec.transfer.model.AlgorithmType;
import com.nec.biomatcher.spec.transfer.model.ImagePosition;

public class MeghaType37Event extends MeghaEvent {
	private byte featureHoldFlag = 0;

	private MeghaPalmPartInfo fullRight;
	private MeghaPalmPartInfo fullLeft;
	private MeghaPalmPartInfo writerRight;
	private MeghaPalmPartInfo writerLeft;

	public void print(PrintStream printStream) {
		if (eventHeader != null) {
			eventHeader.print(printStream);
		}

		printStream.printf("%-20s - %s\n", "featureHoldFlag",
				StringUtils.leftPad(UnsignedBytes.toString(featureHoldFlag, 2), Byte.SIZE, "0"));
		if (fullRight != null) {
			printStream.printf("%-20s - %s\n", "fullRight", "");
			fullRight.print(printStream);
		}

		if (fullLeft != null) {
			printStream.printf("%-20s - %s\n", "fullLeft", "");
			fullLeft.print(printStream);
		}

		if (writerRight != null) {
			printStream.printf("%-20s - %s\n", "writerRight", "");
			writerRight.print(printStream);
		}

		if (writerLeft != null) {
			printStream.printf("%-20s - %s\n", "writerLeft", "");
			writerLeft.print(printStream);
		}
	}

	public MeghaPalmPartInfo getFullRight() {
		return fullRight;
	}

	public void setFullRight(Integer quality, byte[] pc3FeatureData) {
		this.fullRight = new MeghaPalmPartInfo((byte) ImagePosition.PALM_RFULL.getPosition(), quality, pc3FeatureData);
	}

	public MeghaPalmPartInfo getFullLeft() {
		return fullLeft;
	}

	public void setFullLeft(Integer quality, byte[] pc3FeatureData) {
		this.fullLeft = new MeghaPalmPartInfo((byte) ImagePosition.PALM_LFULL.getPosition(), quality, pc3FeatureData);
	}

	public MeghaPalmPartInfo getWriterRight() {
		return writerRight;
	}

	public void setWriterRight(Integer quality, byte[] pc3FeatureData) {
		this.writerRight = new MeghaPalmPartInfo((byte) ImagePosition.PALM_RWRITER.getPosition(), quality,
				pc3FeatureData);
	}

	public MeghaPalmPartInfo getWriterLeft() {
		return writerLeft;
	}

	public void setWriterLeft(Integer quality, byte[] pc3FeatureData) {
		this.writerLeft = new MeghaPalmPartInfo((byte) ImagePosition.PALM_LWRITER.getPosition(), quality,
				pc3FeatureData);
	}

	public static int getEventDataSize(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		return new MeghaEventDataSizeBuilder(meghaTemplateConfig).featureHoldFlag(1).bytes(1).quality(1)
				.featureDataLength(4).featureData(1, "PALM_PC3_FULL_FEATURE_DATA_SIZE").bytes(1).quality(1)
				.featureDataLength(4).featureData(1, "PALM_PC3_FULL_FEATURE_DATA_SIZE").bytes(1).quality(1)
				.featureDataLength(4).featureData(1, "PALM_PC3_WRITERS_FEATURE_DATA_SIZE").bytes(1).quality(1)
				.featureDataLength(4).featureData(1, "PALM_PC3_WRITERS_FEATURE_DATA_SIZE").build();
	}

	public static final Set<AlgorithmType> getAlgorithmTypes() {
		return Sets.newHashSet(AlgorithmType.PALM_PC3R);
	}

	@Override
	public byte[] pack(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		if (eventHeader == null) {
			eventHeader = new MeghaEventHeader();
		}

		eventHeader.setAlgType(AlgorithmType.PALM_PC3R.getValue().byteValue());

		featureHoldFlag = 0;
		featureHoldFlag = HoldFlagUtil.setHoldFlag(featureHoldFlag, 0, fullRight != null);
		featureHoldFlag = HoldFlagUtil.setHoldFlag(featureHoldFlag, 1, fullLeft != null);
		featureHoldFlag = HoldFlagUtil.setHoldFlag(featureHoldFlag, 2, writerRight != null);
		featureHoldFlag = HoldFlagUtil.setHoldFlag(featureHoldFlag, 3, writerLeft != null);

		byte[] eventData = new byte[getEventDataSize(meghaTemplateConfig)];
		ByteBuffer eventDataBuf = ByteBuffer.wrap(eventData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		eventDataBuf.put(eventHeader.pack());
		eventDataBuf.put(featureHoldFlag);

		writePalmPartInfo(eventDataBuf, fullRight,
				meghaTemplateConfig.getFeatureSize("PALM_PC3_FULL_FEATURE_DATA_SIZE"));
		writePalmPartInfo(eventDataBuf, fullLeft,
				meghaTemplateConfig.getFeatureSize("PALM_PC3_FULL_FEATURE_DATA_SIZE"));
		writePalmPartInfo(eventDataBuf, writerRight,
				meghaTemplateConfig.getFeatureSize("PALM_PC3_WRITERS_FEATURE_DATA_SIZE"));
		writePalmPartInfo(eventDataBuf, writerLeft,
				meghaTemplateConfig.getFeatureSize("PALM_PC3_WRITERS_FEATURE_DATA_SIZE"));

		return eventData;
	}

	@Override
	public void unpack(byte[] eventData, MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		ByteBuffer eventDataBuf = ByteBuffer.wrap(eventData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		eventHeader = new MeghaEventHeader();
		eventHeader.unpack(eventDataBuf);

		featureHoldFlag = eventDataBuf.get();

		List<Integer> featureIndexFlagList = HoldFlagUtil.getHoldFlagIndexList(featureHoldFlag, 4);

		fullRight = readPalmPartInfo(eventDataBuf,
				meghaTemplateConfig.getFeatureSize("PALM_PC3_FULL_FEATURE_DATA_SIZE"),
				featureIndexFlagList.contains(0));
		fullLeft = readPalmPartInfo(eventDataBuf, meghaTemplateConfig.getFeatureSize("PALM_PC3_FULL_FEATURE_DATA_SIZE"),
				featureIndexFlagList.contains(1));
		writerRight = readPalmPartInfo(eventDataBuf,
				meghaTemplateConfig.getFeatureSize("PALM_PC3_WRITERS_FEATURE_DATA_SIZE"),
				featureIndexFlagList.contains(2));
		writerLeft = readPalmPartInfo(eventDataBuf,
				meghaTemplateConfig.getFeatureSize("PALM_PC3_WRITERS_FEATURE_DATA_SIZE"),
				featureIndexFlagList.contains(3));
	}

	private void writePalmPartInfo(ByteBuffer eventDataBuf, MeghaPalmPartInfo palmPartInfo, int featureDataSize)
			throws MeghaTemplateException {
		if (palmPartInfo != null && palmPartInfo.getFeatureData() != null) {
			if (palmPartInfo.getFeatureData().length == 0 || palmPartInfo.getFeatureData().length > featureDataSize) {
				throw new MeghaTemplateException("Invalid Pc3FeatureData length, actual: "
						+ palmPartInfo.getFeatureData().length + ", expected: " + featureDataSize
						+ " for palmPartNumber: " + palmPartInfo.getPartNumber());
			}
			eventDataBuf.put(palmPartInfo.getPartNumber());
			eventDataBuf.put(palmPartInfo.getQuality());
			eventDataBuf.putInt(palmPartInfo.getFeatureData().length);
			eventDataBuf.put(palmPartInfo.getFeatureData());
			eventDataBuf.position(eventDataBuf.position() + featureDataSize - palmPartInfo.getFeatureData().length);
		} else {
			eventDataBuf.position(eventDataBuf.position() + 1 + 1 + 4 + featureDataSize);
		}
	}

	private MeghaPalmPartInfo readPalmPartInfo(ByteBuffer eventDataBuf, int featureDataSize, boolean featureFlag)
			throws MeghaTemplateException {
		if (featureFlag) {
			MeghaPalmPartInfo palmPartInfo = new MeghaPalmPartInfo();
			palmPartInfo.setPartNumber(eventDataBuf.get());
			palmPartInfo.setQuality(eventDataBuf.get());

			int dataSize = eventDataBuf.getInt();
			if (dataSize == 0 || dataSize > featureDataSize) {
				throw new MeghaTemplateException("Invalid dataSize length, actual: " + dataSize + ", expected: "
						+ featureDataSize + " for palmPartNumber: " + palmPartInfo.getPartNumber());
			}

			byte[] pc3FeatureData = new byte[dataSize];
			eventDataBuf.get(pc3FeatureData);

			palmPartInfo.setFeatureData(pc3FeatureData);

			eventDataBuf.position(eventDataBuf.position() + featureDataSize - dataSize);

			return palmPartInfo;
		} else {
			eventDataBuf.position(eventDataBuf.position() + 1 + 1 + 4 + featureDataSize);
			return null;
		}
	}

}
