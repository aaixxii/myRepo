package com.nec.biomatcher.comp.callback.impl;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.NDC;

import com.google.common.util.concurrent.Uninterruptibles;
import com.nec.biomatcher.comp.callback.CallbackService;
import com.nec.biomatcher.comp.zmq.ZmqPushConnection;
import com.nec.biomatcher.comp.zmq.ZmqPushConnection.ZmqPushSocket;
import com.nec.biomatcher.core.framework.common.BiKey;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.ShutdownHook;
import com.nec.biomatcher.core.framework.common.concurrent.CommonTaskScheduler;
import com.nec.biomatcher.core.framework.common.concurrent.IdleTimeoutTask;

public class ZmqCallbackServiceImpl implements CallbackService {
	private static final Logger logger = Logger.getLogger(ZmqCallbackServiceImpl.class);

	private static final ExecutorService cachedExecutorService = CommonTaskScheduler.CACHED_EXECUTORSERVICE;
	private static final ConcurrentHashMap<String, ZmqCallbackTask> zmqCallbackTaskMap = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<String, ZmqCallbackTask> zmqBatchCallbackTaskMap = new ConcurrentHashMap<>();

	public final void postCallback(String url, String body) throws Exception {
		URI uri = new URI(url);
		String callbackHostKey = uri.getRawAuthority();

		if (CallbackService.isBatchCallbackUrl(url)) {
			getZmqCallbackTask(callbackHostKey, true).addToQueue(url, null);
		} else {
			getZmqCallbackTask(callbackHostKey, false).addToQueue(url, body);
		}
	}

	public void postBatchCallback(String url) throws Exception {
		URI uri = new URI(url);
		String callbackHostKey = uri.getRawAuthority();

		getZmqCallbackTask(callbackHostKey, true).addToQueue(url, null);
	}

	private final ZmqCallbackTask getZmqCallbackTask(String callbackHostKey, boolean isBatched) {
		ZmqCallbackTask zmqCallbackTask = null;
		if (isBatched) {
			zmqCallbackTask = zmqBatchCallbackTaskMap.get(callbackHostKey);
			if (zmqCallbackTask == null) {
				zmqCallbackTask = zmqBatchCallbackTaskMap.computeIfAbsent(callbackHostKey,
						callbackHostKeyParam -> new ZmqCallbackTask(callbackHostKeyParam, true,
								TimeUnit.MINUTES.toMillis(30)));
			}
		} else {
			zmqCallbackTask = zmqCallbackTaskMap.get(callbackHostKey);
			if (zmqCallbackTask == null) {
				zmqCallbackTask = zmqCallbackTaskMap.computeIfAbsent(callbackHostKey,
						callbackHostKeyParam -> new ZmqCallbackTask(callbackHostKeyParam, false,
								TimeUnit.MINUTES.toMillis(30)));
			}
		}
		return zmqCallbackTask;
	}

	class ZmqCallbackTask extends IdleTimeoutTask {
		private final LinkedBlockingQueue<BiKey<String, String>> callbackUrlQueue = new LinkedBlockingQueue<>();
		private final String callbackHostKey;
		private final boolean batchCallbackFlag;

		public ZmqCallbackTask(String callbackHostKey, boolean batchCallbackFlag, long idleTimeoutMilli) {
			super(idleTimeoutMilli);
			this.callbackHostKey = callbackHostKey;
			this.batchCallbackFlag = batchCallbackFlag;
			cachedExecutorService.execute(this);
		}

		public void addToQueue(String callbackUrl, String callbackBody) {
			notifyActivity();
			callbackUrlQueue.add(new BiKey<>(callbackUrl, batchCallbackFlag ? null : callbackBody));
		}

		@Override
		public void run() {
			Thread.currentThread().setName("ZmqCallbackTask_" + Thread.currentThread().getId());
			NDC.clear();

			CommonLogger.STATUS_LOG.info("In ZmqCallbackTask: batchCallbackFlag: " + batchCallbackFlag
					+ ", callbackHostKey: " + callbackHostKey + ", callbackUrlQueueSize: " + callbackUrlQueue.size());

			ZmqPushSocket zmqPushSocket = null;
			try {
				do {
					try {
						BiKey<String, String> callbackData = callbackUrlQueue.poll(idleTimeoutMilli,
								TimeUnit.MILLISECONDS);
						if (callbackData == null) {
							continue;
						}

						notifyActivity();

						if (zmqPushSocket == null) {
							zmqPushSocket = ZmqPushConnection.createSocket("tcp://" + callbackHostKey);
						} else if (zmqPushSocket.isErrorSendFlag()) {
							ZmqPushConnection.closeSocketQuitely(zmqPushSocket);
							zmqPushSocket = ZmqPushConnection.createSocket("tcp://" + callbackHostKey);
						}

						String callbackBody = null;
						if (batchCallbackFlag) {
							StringBuilder callbackUrListPayload = new StringBuilder();

							int polledCount = 0;

							do {
								callbackUrListPayload.append(callbackData.a);
								callbackUrListPayload.append(System.lineSeparator());
							} while (++polledCount < 20 && (callbackData = callbackUrlQueue.poll()) != null);

							callbackBody = callbackUrListPayload.toString();

							ZmqPushConnection.sendMessage(zmqPushSocket, callbackHostKey,
									callbackBody.getBytes(StandardCharsets.UTF_8));

							if (logger.isTraceEnabled()) {
								logger.trace("In ZmqCallbackTask: batchCallbackFlag: " + batchCallbackFlag
										+ ", callbackHostKey: " + callbackHostKey + ", callbackBody: " + callbackBody);
							}
						} else {
							do {
								callbackBody = callbackData.b;
								if (callbackBody == null) {
									callbackBody = "COMPLETED";
								}

								ZmqPushConnection.sendMessage(zmqPushSocket, callbackData.a,
										callbackBody.getBytes(StandardCharsets.UTF_8));

								if (logger.isTraceEnabled()) {
									logger.trace("In ZmqCallbackTask: batchCallbackFlag: " + batchCallbackFlag
											+ ", callbackHostKey: " + callbackHostKey + ", callbackRef: "
											+ callbackData.a);
								}
							} while ((callbackData = callbackUrlQueue.poll()) != null);
						}

						notifyActivity();
					} catch (Throwable th) {
						logger.error("Error during sending callback to callbackHostKey: " + callbackHostKey + " : "
								+ th.getMessage(), th);
					}
				} while ((!isIdleTimeout() || !callbackUrlQueue.isEmpty()) && !ShutdownHook.isShutdownFlag);
			} finally {
				CommonLogger.STATUS_LOG.info("Exiting the CallbackService.ZmqCallbackTask for callbackHostKey: "
						+ callbackHostKey + ", isIdleTimeout: " + isIdleTimeout() + ", callbackUrlQueueSize: "
						+ callbackUrlQueue.size());

				if (!ShutdownHook.isShutdownFlag) {
					if (batchCallbackFlag) {
						zmqBatchCallbackTaskMap.remove(callbackHostKey, ZmqCallbackTask.this);
					} else {
						zmqCallbackTaskMap.remove(callbackHostKey, ZmqCallbackTask.this);
					}

					// Flush any pending callbacks
					transferPendingCallbacks();
					Uninterruptibles.sleepUninterruptibly(100, TimeUnit.MILLISECONDS);
					transferPendingCallbacks();
				}

				ZmqPushConnection.closeSocketQuitely(zmqPushSocket);
			}
		}

		private final void transferPendingCallbacks() {
			ZmqCallbackTask zmqCallbackTask = null;

			BiKey<String, String> callbackData = null;
			while ((callbackData = callbackUrlQueue.poll()) != null) {
				try {
					if (zmqCallbackTask == null) {
						zmqCallbackTask = getZmqCallbackTask(callbackHostKey, batchCallbackFlag);
					}
					zmqCallbackTask.addToQueue(callbackData.a, callbackData.b);
				} catch (Throwable th) {
					logger.error("Error in transferPendingCallbacks for callbackUrl: " + callbackData.a + " : "
							+ th.getMessage(), th);
				}
			}
		}
	}

}
