package com.nec.biomatcher.comp.common.parameter.dataAccess.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.nec.biomatcher.comp.common.parameter.dataAccess.BioParameter;
import com.nec.biomatcher.comp.common.parameter.dataAccess.BioParameterDao;
import com.nec.biomatcher.comp.common.parameter.dataAccess.BioParameterScope;
import com.nec.biomatcher.core.framework.common.pagination.PageRequest;
import com.nec.biomatcher.core.framework.common.pagination.PageResult;
import com.nec.biomatcher.core.framework.dataAccess.AbstractHibernateDao;
import com.nec.biomatcher.core.framework.dataAccess.DaoException;

/**
 * The Class BioParameterHibernateImpl.
 */
public class BioParameterHibernateImpl extends AbstractHibernateDao implements BioParameterDao {

	public List<BioParameterScope> getAllParameterScopes() throws DaoException {
		try {
			List<BioParameterScope> entityList = this.getAllEntity(BioParameterScope.class);
			return entityList;
		} catch (HibernateException e) {
			throw new DaoException(e);
		}
	}

	public List<BioParameter> getParametersLike(String parameterName, String scope) throws DaoException {
		try {
			Criteria criteria = this.currentSession().createCriteria(BioParameter.class);
			criteria.add(Restrictions.eq("scope", scope));
			criteria.add(Restrictions.like("name", parameterName, MatchMode.START));
			return criteria.list();
		} catch (HibernateException e) {
			throw new DaoException(e);
		}
	}

	public List<BioParameter> getAllParameters(boolean includeVariableScope) throws DaoException {
		try {
			Criteria criteria = this.currentSession().createCriteria(BioParameter.class);
			if (!includeVariableScope) {
				criteria.add(Restrictions.ne("scope", "VARIABLE"));
			}
			return criteria.list();
		} catch (HibernateException e) {
			throw new DaoException(e);
		}
	}

	public PageResult<BioParameter> getAllParameters(PageRequest pageRequest) throws DaoException {
		Long count = 0L;
		PageResult<BioParameter> pageResult = null;
		try {
			Criteria criteria = this.currentSession().createCriteria(BioParameter.class);
			if (pageRequest.isCalculateRecordCount()) {
				count = (Long) criteria.setProjection(Projections.rowCount()).uniqueResult();
			}

			criteria = this.currentSession().createCriteria(BioParameter.class);
			criteria.addOrder(Order.asc("name")).list();

			List<BioParameter> resultList = (List<BioParameter>) criteria.setFirstResult(pageRequest.getFirstRowIndex())
					.setMaxResults(pageRequest.getMaxRecords() == -1 ? count.intValue() : pageRequest.getMaxRecords())
					.list();

			pageResult = new PageResult<>();
			pageResult.setResultList(resultList);
			pageResult.setTotalRecords(count == 0 ? resultList.size() : count.intValue());
			return pageResult;
		} catch (HibernateException e) {
			throw new DaoException(e);
		}
	}
}
