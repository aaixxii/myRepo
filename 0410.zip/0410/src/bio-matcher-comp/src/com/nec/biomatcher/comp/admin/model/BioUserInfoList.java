package com.nec.biomatcher.comp.admin.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.core.Dto;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BioUserInfoList implements Dto {
	private static final long serialVersionUID = 1L;

	@XmlElement(nillable = true, required = false)
	private List<BioUserInfo> userList;

	public BioUserInfoList() {

	}

	public List<BioUserInfo> getUserList() {
		if (userList == null) {
			userList = new ArrayList<>();
		}
		return userList;
	}

	public void setUserList(List<BioUserInfo> userList) {
		this.userList = userList;
	}

	public void addUser(BioUserInfo bioUserInfo) {
		bioUserInfo.setUserId(bioUserInfo.getUserId().toUpperCase());

		for (BioUserInfo currentUserInfo : getUserList()) {
			if (currentUserInfo.getUserId().equalsIgnoreCase(bioUserInfo.getUserId())) {
				currentUserInfo.setUserId(bioUserInfo.getUserId());
				currentUserInfo.setUserName(bioUserInfo.getUserName());
				currentUserInfo.setPassword(bioUserInfo.getPassword());
				currentUserInfo.setDateTimeupdate(new Date());
				currentUserInfo.setRoles(bioUserInfo.getRoles());
				return;
			}
		}

		bioUserInfo.setDateTimeCreate(new Date());

		getUserList().add(bioUserInfo);
	}

	public BioUserInfo getUser(String userId) {
		BioUserInfo tempUser = null;
		for (BioUserInfo currentUserInfo : getUserList()) {
			if (currentUserInfo.getUserId().equalsIgnoreCase(userId)) {
				tempUser = currentUserInfo;
				break;
			}
		}
		return tempUser;
	}

	public void removeUser(String userId) {
		BioUserInfo toBeRemovedUser = null;
		for (BioUserInfo currentUserInfo : getUserList()) {
			if (currentUserInfo.getUserId().equalsIgnoreCase(userId)) {
				toBeRemovedUser = currentUserInfo;
				break;
			}
		}

		if (toBeRemovedUser != null) {
			getUserList().remove(toBeRemovedUser);
		}
	}
}
