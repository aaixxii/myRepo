package com.nec.biomatcher.comp.metrics;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;

import com.google.common.base.Charsets;
import com.google.common.util.concurrent.Uninterruptibles;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.core.framework.common.DateUtil;
import com.nec.biomatcher.core.framework.common.FileUtils;
import com.nec.biomatcher.core.framework.common.ShutdownHook;
import com.nec.biomatcher.core.framework.common.concurrent.CommonTaskScheduler;
import com.nec.biomatcher.core.framework.common.exception.CoreException;

public class MetricsFileStorage implements InitializingBean {
	private static final Logger logger = Logger.getLogger(MetricsFileStorage.class);

	private BioParameterService bioParameterService;

	private File metricsStoragePath;

	private String metricsStorageAbsolutePath;

	private File currentServerStoragePath;

	private String currentServerStorageAbsolutePath;

	private Supplier<Integer> retentionHoursSupplier;

	private String currentServerHost;

	private Long lastHouseKeepingRetTimestamp = null;

	public void performMetricsHousekeeping() {
		logger.info("In performMetricsHousekeeping");
		if (StringUtils.isBlank(currentServerHost)) {
			logger.warn("In performMetricsHousekeeping: currentServerHost is blank: " + currentServerHost);
			return;
		}

		File metricServerFileStorage = new File(metricsStoragePath, currentServerHost);
		try {
			int retentionHours = retentionHoursSupplier.get();
			Calendar retentionCal = Calendar.getInstance();
			retentionCal.add(Calendar.HOUR_OF_DAY, -1 * retentionHours);

			String retYyyymmdd = DateUtil.parseDate(retentionCal.getTime(), DateUtil.FORMAT_YYYYMMDD);
			logger.info("In performMetricsHousekeeping: retYyyymmdd: " + retYyyymmdd);
			Calendar workingCal = Calendar.getInstance();
			if (lastHouseKeepingRetTimestamp != null) {
				workingCal.setTimeInMillis(lastHouseKeepingRetTimestamp);
				workingCal.add(Calendar.HOUR, -24);
			} else {
				workingCal.add(Calendar.HOUR_OF_DAY, -1 * retentionHours);
				workingCal.add(Calendar.HOUR, -48);
			}

			while (workingCal.before(retentionCal)) {
				Date date = workingCal.getTime();
				String yyyymmdd = DateUtil.parseDate(date, DateUtil.FORMAT_YYYYMMDD);
				logger.info("In performMetricsHousekeeping: retYyyymmdd: " + retYyyymmdd + ", yyyymmdd: " + yyyymmdd);
				if (!yyyymmdd.equals(retYyyymmdd)) {
					// Delete old folder
					Path metricFolderPath = Paths.get(currentServerStorageAbsolutePath, yyyymmdd);
					try {
						if (Files.isDirectory(metricFolderPath)) {
							FileUtils.deleteFolderQuietly(metricFolderPath);
							logger.info("In performMetricsHousekeeping: dayFolder: " + metricFolderPath);
						}
					} catch (Throwable th) {
						logger.error("Error deleting metrics storage data folder : " + metricFolderPath + " : "
								+ th.getMessage(), th);
					}

					lastHouseKeepingRetTimestamp = workingCal.getTimeInMillis();
				} else {
					// Intentionally ignoring the deletion of files for hours
					// for performance reason
				}

				workingCal.add(Calendar.DAY_OF_YEAR, 1);
			}

			lastHouseKeepingRetTimestamp = retentionCal.getTimeInMillis();
		} catch (Throwable th) {
			logger.error("Error in performMetricsHousekeeping for metricServerFileStorage: "
					+ metricServerFileStorage.getAbsolutePath() + " : " + th.getMessage(), th);
		}
	}

	public void saveMetricsData(String serverHost, Calendar metricTimestamp, byte[] metricData) {
		try {
			if (currentServerHost == null) {
				prepareCurrentServerMetricsFolder(serverHost);
			}
			Path latestFilePath = Paths.get(currentServerStorageAbsolutePath, "latest.dat");

			boolean savedFlag = FileUtils.saveFile(latestFilePath, metricData);

			if (savedFlag) {
				Date date = metricTimestamp.getTime();
				String yyyymmdd = DateUtil.parseDate(date, DateUtil.FORMAT_YYYYMMDD);
				String hhmi = DateUtil.parseDate(date, DateUtil.FORMAT_HH24MI);

				Path metricFilePath = Paths.get(currentServerStorageAbsolutePath, yyyymmdd, hhmi + ".dat");
				Files.createDirectories(metricFilePath.getParent());
				Files.copy(latestFilePath, metricFilePath, StandardCopyOption.REPLACE_EXISTING);
			}

		} catch (Throwable th) {
			if (logger.isDebugEnabled())
				logger.debug("Error storing the metricData for serverHost: " + serverHost + ", metricTimestamp: "
						+ metricTimestamp + " : " + th.getMessage(), th);
		}
	}

	public String getLatestMetricData(String serverHost) {
		Path latestFilePath = Paths.get(metricsStorageAbsolutePath, serverHost, "latest.dat");
		byte[] metricData = null;
		if (Files.isRegularFile(latestFilePath)) {
			try {
				metricData = Files.readAllBytes(latestFilePath);
			} catch (Throwable th) {
				logger.debug("Error in getLatestMetricData for serverHost: " + serverHost + " : " + th.getMessage(),
						th);

				// May be in middle of writing the file, try again
				if (Files.isRegularFile(latestFilePath)) {
					try {
						Thread.sleep(50);
						metricData = Files.readAllBytes(latestFilePath);
					} catch (Throwable th1) {
						logger.error("Error in getLatestMetricData retry for serverHost: " + serverHost + " : "
								+ th1.getMessage(), th);
					}
				}
			}
		}

		if (metricData != null && metricData.length > 0) {
			return new String(metricData, Charsets.UTF_8);
		}

		return null;
	}

	public List<String> getMetricDataAfterMarker(String serverHost, Calendar metricTimestamp) {
		List<String> metricDataList = new ArrayList<>();
		try {
			Calendar currentCal = Calendar.getInstance();

			metricTimestamp.add(Calendar.MINUTE, 1);

			while (metricTimestamp.before(currentCal)) {
				Date date = metricTimestamp.getTime();
				String yyyymmdd = DateUtil.parseDate(date, DateUtil.FORMAT_YYYYMMDD);
				String hhmi = DateUtil.parseDate(date, DateUtil.FORMAT_HH24MI);

				Path metricFilePath = Paths.get(currentServerStorageAbsolutePath, yyyymmdd, hhmi + ".dat");
				try {
					if (Files.isRegularFile(metricFilePath)) {
						byte[] metricData = Files.readAllBytes(metricFilePath);
						if (metricData != null && metricData.length > 0) {
							metricDataList.add(new String(metricData, Charsets.UTF_8));
						}
					}
				} catch (Throwable th) {
					logger.error("Error in getMetricDataAfterMarker for serverHost: " + serverHost
							+ ", metricFilePath: " + metricFilePath.toString() + " : " + th.getMessage(), th);
				}

				metricTimestamp.add(Calendar.MINUTE, 1);
			}
		} catch (Throwable th) {
			logger.error("Error in getMetricDataAfterMarker for serverHost: " + serverHost + ", metricTimestamp: "
					+ metricTimestamp + " : " + th.getMessage(), th);
		}
		return metricDataList;
	}

	private synchronized void prepareCurrentServerMetricsFolder(String serverHost) throws IOException {
		if (currentServerHost != null) {
			return;
		}
		Path tempMetricsServerStoragePath = Paths.get(metricsStorageAbsolutePath, serverHost);
		try {
			Files.createDirectories(tempMetricsServerStoragePath);
			currentServerStoragePath = tempMetricsServerStoragePath.toFile();
			currentServerStorageAbsolutePath = currentServerStoragePath.getAbsolutePath();
			currentServerHost = serverHost;
		} catch (Throwable th) {
			logger.error("Error in prepareCurrentServerMetricsFolder for serverHost: " + serverHost
					+ ", metricsServerStoragePath: " + tempMetricsServerStoragePath.toString() + " : "
					+ th.getMessage(), th);
		}

	}

	@Override
	public void afterPropertiesSet() throws Exception {
		String path = bioParameterService.getParameterValue("LOBSTREAM_STORAGE_PATH", "DEFAULT",
				new File(System.getProperty("user.home"), "storage/lobstream/data/").getAbsolutePath());
		logger.info("In MetricsFileStorage: LOBSTREAM_STORAGE_PATH: " + path);

		File lobStreamStoragePath = new File(path);
		lobStreamStoragePath.mkdirs();
		if (!lobStreamStoragePath.isDirectory()) {
			throw new CoreException(
					"LobStream storage path does not exist : " + lobStreamStoragePath.getAbsolutePath());
		}

		metricsStoragePath = new File(lobStreamStoragePath, "metrics");
		metricsStoragePath.mkdirs();
		if (!metricsStoragePath.isDirectory()) {
			throw new CoreException("Metrics storage path does not exist : " + metricsStorageAbsolutePath);
		}

		metricsStorageAbsolutePath = metricsStoragePath.getAbsolutePath();

		retentionHoursSupplier = BioParameterService.getIntSupplier("METRICS_FILE_STORAGE_RETENTION_HOURS", "DEFAULT",
				5 * 24);

		Runnable metricStorageHouseKeepingTask = () -> {
			Thread.currentThread().setName("METRIC_STORAGE_HK_" + Thread.currentThread().getId());

			while (!ShutdownHook.isShutdownFlag) {
				try {
					performMetricsHousekeeping();
				} catch (Throwable th) {
					logger.error("Error during metricStorage housekeeping : " + th.getMessage(), th);
				} finally {
					Uninterruptibles.sleepUninterruptibly(1, TimeUnit.HOURS);
				}
			}
		};

		CommonTaskScheduler.scheduleWithFixedDelay(metricStorageHouseKeepingTask, 60, 60, TimeUnit.SECONDS);
	}

	public void setBioParameterService(BioParameterService bioParameterService) {
		this.bioParameterService = bioParameterService;
	}

}
