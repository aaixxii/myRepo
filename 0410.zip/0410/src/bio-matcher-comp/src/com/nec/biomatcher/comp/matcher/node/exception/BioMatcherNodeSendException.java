package com.nec.biomatcher.comp.matcher.node.exception;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

/**
 * The Class BioMatcherNodeSendException.
 */
public class BioMatcherNodeSendException extends CoreException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new bio matcher node send exception.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public BioMatcherNodeSendException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new bio matcher node send exception.
	 *
	 * @param message
	 *            the message
	 */
	public BioMatcherNodeSendException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new bio matcher node send exception.
	 *
	 * @param cause
	 *            the cause
	 */
	public BioMatcherNodeSendException(Throwable cause) {
		super(cause.getMessage(), cause);
	}

}
