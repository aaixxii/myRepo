package com.nec.biomatcher.comp.zmq;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import java.util.function.Supplier;

import org.apache.log4j.Logger;
import org.zeromq.ZMQ;
import org.zeromq.ZMQ.Context;
import org.zeromq.ZMQ.Socket;

import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.ShutdownHook;
import com.nec.biomatcher.core.framework.common.concurrent.CommonTaskScheduler;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentExecutor;
import com.nec.biomatcher.core.framework.common.concurrent.CustomRunnable;

public class ZmqPullMessageListener {
	private static final Logger logger = Logger.getLogger(ZmqPullMessageListener.class);

	private final String listenerName;
	private final String listenerBindUrl;
	private final Supplier<Integer> zmqIoThreadCountSupplier;
	private final Supplier<Integer> messageExecutorConcurrencySupplier;
	private final Consumer<byte[]> messageConsumer;
	private final Consumer<List<byte[]>> messageListConsumer;

	private ZmqPullListenerThread zmqPullListenerThread = new ZmqPullListenerThread();

	private ConcurrentExecutor zmqPullMessageExecutor;

	private final LinkedBlockingQueue<byte[]> messageQueue = new LinkedBlockingQueue<>();

	private Context context = null;
	private Socket receiver = null;

	public ZmqPullMessageListener(String listenerName, String listenerBindUrl,
			Supplier<Integer> zmqIoThreadCountSupplier, Supplier<Integer> messageExecutorConcurrencySupplier,
			Consumer<byte[]> messageConsumer) {
		this.listenerName = listenerName;
		this.listenerBindUrl = listenerBindUrl;
		this.zmqIoThreadCountSupplier = zmqIoThreadCountSupplier;
		this.messageExecutorConcurrencySupplier = messageExecutorConcurrencySupplier;
		this.messageConsumer = messageConsumer;
		this.messageListConsumer = null;
	}

	public ZmqPullMessageListener(String listenerName, String listenerBindUrl,
			Supplier<Integer> zmqIoThreadCountSupplier, Supplier<Integer> messageExecutorConcurrencySupplier,
			Consumer<List<byte[]>> messageListConsumer, boolean isBatched) {
		this.listenerName = listenerName;
		this.listenerBindUrl = listenerBindUrl;
		this.zmqIoThreadCountSupplier = zmqIoThreadCountSupplier;
		this.messageExecutorConcurrencySupplier = messageExecutorConcurrencySupplier == null ? () -> 1
				: messageExecutorConcurrencySupplier;
		this.messageListConsumer = messageListConsumer;
		this.messageConsumer = null;
	}

	public LinkedBlockingQueue<byte[]> getReceivedMessageQueue() {
		return messageQueue;
	}

	public synchronized void startZmqPullListener() throws Exception {
		try {
			int zmqIoThreadCount = zmqIoThreadCountSupplier.get();

			CommonLogger.CONFIG_LOG.info("In startZmqPullListener: listenerName: " + listenerName
					+ ", listenerBindUrl: " + listenerBindUrl + ", zmqIoThreadCount: " + zmqIoThreadCount);

			context = ZMQ.context(zmqIoThreadCount);

			receiver = context.socket(ZMQ.PULL);

			receiver.bind(listenerBindUrl);

			CommonLogger.STATUS_LOG.info("After binding ZmqPullListener listenerName: " + listenerName
					+ " on listenerBindUrl: " + listenerBindUrl);

			zmqPullListenerThread.setStopFlag(false);

			CommonTaskScheduler.scheduleWithFixedDelay(zmqPullListenerThread, 10, 100, TimeUnit.MILLISECONDS);

			startZmqMessageExecutor();
		} catch (Throwable th) {
			Exception ex = new Exception("Error in startZmqPullListener during binding of the listenerName: "
					+ listenerName + " on listenerBindUrl: " + listenerBindUrl + " : " + th.getMessage(), th);
			logger.error(ex.getMessage(), ex);
			throw ex;
		}
	}

	public synchronized void stopZmqPullListener() throws Exception {
		zmqPullListenerThread.setStopFlag(true);
		CommonTaskScheduler.cancelTask(zmqPullListenerThread, true);

		if (zmqPullMessageExecutor != null) {
			zmqPullMessageExecutor.stop();
		}

		receiver.close();
		context.close();
	}

	private synchronized void startZmqMessageExecutor() {
		logger.info("In startZmqMessageExecutor for listenerName: " + listenerName);
		if (zmqPullMessageExecutor == null && messageExecutorConcurrencySupplier != null) {
			if (messageConsumer != null) {
				zmqPullMessageExecutor = new ConcurrentExecutor(listenerName + "_MSG_EXEC",
						new ZmqMessageWorkerThread(), messageExecutorConcurrencySupplier);
				zmqPullMessageExecutor.start();
			} else {
				zmqPullMessageExecutor = new ConcurrentExecutor(listenerName + "_MSG_EXEC",
						new ZmqMessageListWorkerThread(), messageExecutorConcurrencySupplier);
				zmqPullMessageExecutor.start();
			}
		}
	}

	private class ZmqPullListenerThread implements Runnable {
		private final Logger logger = Logger.getLogger(ZmqPullListenerThread.class);

		private AtomicBoolean stopFlag = new AtomicBoolean(false);

		public void setStopFlag(boolean flag) {
			stopFlag.set(flag);
		}

		@Override
		public void run() {
			Thread currentThread = Thread.currentThread();
			currentThread.setName(listenerName + "_LISTENER_" + Thread.currentThread().getId());

			CommonLogger.STATUS_LOG.info("In ZmqPullListenerThread.run: listenerName: " + listenerName);
			try {
				while (!ShutdownHook.isShutdownFlag && !stopFlag.get()) {
					try {
						byte[] messageDataBuf = receiver.recv(0);

						if (messageDataBuf == null) {
							logger.error("In ZmqPullListenerThread.run for listenerName: " + listenerName
									+ " : Received null messageDataBuf");
							continue;
						}

						if (logger.isTraceEnabled())
							logger.trace("In ZmqPullListenerThread.run for listenerName: " + listenerName
									+ " : After receiving messageDataBuf: size: " + messageDataBuf.length);

						if (messageExecutorConcurrencySupplier == null && messageConsumer != null) {
							messageConsumer.accept(messageDataBuf);
						} else {
							messageQueue.add(messageDataBuf);
						}
					} catch (Throwable th) {
						logger.error("Error in ZmqPullListenerThread.run for listenerName: " + listenerName
								+ " while receiving on listenerBindUrl: " + listenerBindUrl + " : " + th.getMessage(),
								th);
					}
				}
			} finally {
				CommonLogger.STATUS_LOG.warn("Exiting ZmqPullListenerThread.run for listenerName: " + listenerName
						+ ", isShutdownFlag: " + ShutdownHook.isShutdownFlag + ", stopFlag: " + stopFlag.get());
			}
		}
	}

	private class ZmqMessageWorkerThread implements CustomRunnable {
		private final Logger logger = Logger.getLogger(ZmqMessageWorkerThread.class);

		public ZmqMessageWorkerThread() {
		}

		public void run(AtomicBoolean stopFlag) {

			CommonLogger.STATUS_LOG.info(
					"In ZmqMessageWorkerThread.run:listenerName: " + listenerName + ", stopFlag: " + stopFlag.get());

			try {
				while (!ShutdownHook.isShutdownFlag && !stopFlag.get()) {
					try {
						byte[] messageDataBuf = messageQueue.poll(5, TimeUnit.SECONDS);
						if (messageDataBuf == null) {
							continue;
						}

						try {
							messageConsumer.accept(messageDataBuf);
						} catch (Throwable th) {
							logger.error("Error in ZmqMessageWorkerThread.run for listenerName: " + listenerName
									+ " while messageConsumer.accept: " + th.getMessage(), th);
						}
					} catch (Throwable th) {
						logger.error("Error in ZmqMessageWorkerThread.run for listenerName: " + listenerName
								+ " while polling on messageQueue: " + th.getMessage(), th);
					}
				}
			} catch (Throwable th) {
				logger.error("Error in ZmqMessageWorkerThread.run for listenerName: " + listenerName + " : "
						+ th.getMessage(), th);
			} finally {
				CommonLogger.STATUS_LOG.warn("Exiting ZmqMessageWorkerThread.run for listenerName: " + listenerName
						+ ", stopFlag: " + stopFlag.get() + ", isShutdownFlag: " + ShutdownHook.isShutdownFlag);
			}
		}
	}

	private class ZmqMessageListWorkerThread implements CustomRunnable {
		private final Logger logger = Logger.getLogger(ZmqMessageWorkerThread.class);

		public ZmqMessageListWorkerThread() {
		}

		public void run(AtomicBoolean stopFlag) {

			CommonLogger.STATUS_LOG.info("In ZmqMessageListWorkerThread.run:listenerName: " + listenerName
					+ ", stopFlag: " + stopFlag.get());

			try {
				while (!ShutdownHook.isShutdownFlag && !stopFlag.get()) {
					try {
						byte[] messageDataBuf = messageQueue.poll(5, TimeUnit.SECONDS);
						if (messageDataBuf == null) {
							continue;
						}

						List<byte[]> workingMessgeList = new ArrayList<>();
						workingMessgeList.add(messageDataBuf);
						messageQueue.drainTo(workingMessgeList);

						try {
							messageListConsumer.accept(workingMessgeList);
						} catch (Throwable th) {
							logger.error("Error in ZmqMessageWorkerThread.run for listenerName: " + listenerName
									+ " while messageConsumer.accept: " + th.getMessage(), th);
						}
					} catch (Throwable th) {
						logger.error("Error in ZmqMessageWorkerThread.run for listenerName: " + listenerName
								+ " while polling on messageQueue: " + th.getMessage(), th);
					}
				}
			} catch (Throwable th) {
				logger.error("Error in ZmqMessageListWorkerThread.run for listenerName: " + listenerName + " : "
						+ th.getMessage(), th);
			} finally {
				CommonLogger.STATUS_LOG.warn("Exiting ZmqMessageListWorkerThread.run for listenerName: " + listenerName
						+ ", stopFlag: " + stopFlag.get() + ", isShutdownFlag: " + ShutdownHook.isShutdownFlag);
			}
		}
	}

}
