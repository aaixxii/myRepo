package com.nec.biomatcher.comp.template.packing.model;

import java.io.PrintStream;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.google.common.collect.Sets;
import com.google.common.primitives.UnsignedBytes;
import com.nec.biomatcher.comp.template.packing.exception.MeghaTemplateException;
import com.nec.biomatcher.comp.template.packing.util.MeghaEventDataSizeBuilder;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateConfig;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateUtil;
import com.nec.biomatcher.core.framework.common.HoldFlagUtil;
import com.nec.biomatcher.spec.transfer.model.AlgorithmType;

public class MeghaType39Event extends MeghaEvent {
	private byte featureHoldFlag = 0;

	private MeghaPalmPartInfo interDigitalRight;
	private MeghaPalmPartInfo thenarRight;
	private MeghaPalmPartInfo hypothenarRight;
	private MeghaPalmPartInfo interDigitalLeft;
	private MeghaPalmPartInfo thenarLeft;
	private MeghaPalmPartInfo hypothenarLeft;
	private MeghaPalmPartInfo writerRight;
	private MeghaPalmPartInfo writerLeft;

	public void print(PrintStream printStream) {
		if (eventHeader != null) {
			eventHeader.print(printStream);
		}

		printStream.printf("%-20s - %s\n", "featureHoldFlag",
				StringUtils.leftPad(UnsignedBytes.toString(featureHoldFlag, 2), Byte.SIZE, "0"));
		if (interDigitalRight != null) {
			printStream.printf("%-20s - %s\n", "interDigitalRight", "");
			interDigitalRight.print(printStream);
		}

		if (thenarRight != null) {
			printStream.printf("%-20s - %s\n", "thenarRight", "");
			thenarRight.print(printStream);
		}

		if (hypothenarRight != null) {
			printStream.printf("%-20s - %s\n", "hypothenarRight", "");
			hypothenarRight.print(printStream);
		}

		if (interDigitalLeft != null) {
			printStream.printf("%-20s - %s\n", "interDigitalLeft", "");
			interDigitalLeft.print(printStream);
		}

		if (thenarLeft != null) {
			printStream.printf("%-20s - %s\n", "thenarLeft", "");
			thenarLeft.print(printStream);
		}

		if (hypothenarLeft != null) {
			printStream.printf("%-20s - %s\n", "hypothenarLeft", "");
			hypothenarLeft.print(printStream);
		}

		if (writerRight != null) {
			printStream.printf("%-20s - %s\n", "writerRight", "");
			writerRight.print(printStream);
		}

		if (writerLeft != null) {
			printStream.printf("%-20s - %s\n", "writerLeft", "");
			writerLeft.print(printStream);
		}
	}

	public MeghaPalmPartInfo getInterDigitalRight() {
		return interDigitalRight;
	}

	public void setInterDigitalRight(Integer quality, byte[] pc3FeatureData) {
		this.interDigitalRight = new MeghaPalmPartInfo((byte) 31, quality, pc3FeatureData);
	}

	public MeghaPalmPartInfo getThenarRight() {
		return thenarRight;
	}

	public void setThenarRight(Integer quality, byte[] pc3FeatureData) {
		this.thenarRight = new MeghaPalmPartInfo((byte) 32, quality, pc3FeatureData);
	}

	public MeghaPalmPartInfo getHypothenarRight() {
		return hypothenarRight;
	}

	public void setHypothenarRight(Integer quality, byte[] pc3FeatureData) {
		this.hypothenarRight = new MeghaPalmPartInfo((byte) 33, quality, pc3FeatureData);
	}

	public MeghaPalmPartInfo getInterDigitalLeft() {
		return interDigitalLeft;
	}

	public void setInterDigitalLeft(Integer quality, byte[] pc3FeatureData) {
		this.interDigitalLeft = new MeghaPalmPartInfo((byte) 34, quality, pc3FeatureData);
	}

	public MeghaPalmPartInfo getThenarLeft() {
		return thenarLeft;
	}

	public void setThenarLeft(Integer quality, byte[] pc3FeatureData) {
		this.thenarLeft = new MeghaPalmPartInfo((byte) 35, quality, pc3FeatureData);
	}

	public MeghaPalmPartInfo getHypothenarLeft() {
		return hypothenarLeft;
	}

	public void setHypothenarLeft(Integer quality, byte[] pc3FeatureData) {
		this.hypothenarLeft = new MeghaPalmPartInfo((byte) 36, quality, pc3FeatureData);
	}

	public MeghaPalmPartInfo getWriterRight() {
		return writerRight;
	}

	public void setWriterRight(Integer quality, byte[] pc3FeatureData) {
		this.writerRight = new MeghaPalmPartInfo((byte) 22, quality, pc3FeatureData);
	}

	public MeghaPalmPartInfo getWriterLeft() {
		return writerLeft;
	}

	public void setWriterLeft(Integer quality, byte[] pc3FeatureData) {
		this.writerLeft = new MeghaPalmPartInfo((byte) 24, quality, pc3FeatureData);
	}

	public static int getEventDataSize(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		return new MeghaEventDataSizeBuilder(meghaTemplateConfig).featureHoldFlag(1).bytes(1).quality(1)
				.featureDataLength(4).featureData(1, "PALM_PC3_LEGACY_FEATURE_DATA_SIZE").bytes(1).quality(1)
				.featureDataLength(4).featureData(1, "PALM_PC3_LEGACY_FEATURE_DATA_SIZE").bytes(1).quality(1)
				.featureDataLength(4).featureData(1, "PALM_PC3_LEGACY_FEATURE_DATA_SIZE").bytes(1).quality(1)
				.featureDataLength(4).featureData(1, "PALM_PC3_LEGACY_FEATURE_DATA_SIZE").bytes(1).quality(1)
				.featureDataLength(4).featureData(1, "PALM_PC3_LEGACY_FEATURE_DATA_SIZE").bytes(1).quality(1)
				.featureDataLength(4).featureData(1, "PALM_PC3_LEGACY_FEATURE_DATA_SIZE").bytes(1).quality(1)
				.featureDataLength(4).featureData(1, "PALM_PC3_WRITERS_FEATURE_DATA_SIZE").bytes(1).quality(1)
				.featureDataLength(4).featureData(1, "PALM_PC3_WRITERS_FEATURE_DATA_SIZE").build();
	}

	public static final Set<AlgorithmType> getAlgorithmTypes() {
		return Sets.newHashSet(AlgorithmType.PALM_PC3R);
	}

	@Override
	public byte[] pack(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		if (eventHeader == null) {
			eventHeader = new MeghaEventHeader();
		}

		eventHeader.setAlgType(AlgorithmType.PALM_PC3R.getValue().byteValue());

		featureHoldFlag = 0;
		featureHoldFlag = HoldFlagUtil.setHoldFlag(featureHoldFlag, 0, interDigitalRight != null);
		featureHoldFlag = HoldFlagUtil.setHoldFlag(featureHoldFlag, 1, thenarRight != null);
		featureHoldFlag = HoldFlagUtil.setHoldFlag(featureHoldFlag, 2, hypothenarRight != null);
		featureHoldFlag = HoldFlagUtil.setHoldFlag(featureHoldFlag, 3, interDigitalLeft != null);
		featureHoldFlag = HoldFlagUtil.setHoldFlag(featureHoldFlag, 4, thenarLeft != null);
		featureHoldFlag = HoldFlagUtil.setHoldFlag(featureHoldFlag, 5, hypothenarLeft != null);
		featureHoldFlag = HoldFlagUtil.setHoldFlag(featureHoldFlag, 6, writerRight != null);
		featureHoldFlag = HoldFlagUtil.setHoldFlag(featureHoldFlag, 7, writerLeft != null);

		byte[] eventData = new byte[getEventDataSize(meghaTemplateConfig)];
		ByteBuffer eventDataBuf = ByteBuffer.wrap(eventData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		eventDataBuf.put(eventHeader.pack());
		eventDataBuf.put(featureHoldFlag);

		writePalmPartInfo(eventDataBuf, interDigitalRight,
				meghaTemplateConfig.getFeatureSize("PALM_PC3_LEGACY_FEATURE_DATA_SIZE"));
		writePalmPartInfo(eventDataBuf, thenarRight,
				meghaTemplateConfig.getFeatureSize("PALM_PC3_LEGACY_FEATURE_DATA_SIZE"));
		writePalmPartInfo(eventDataBuf, hypothenarRight,
				meghaTemplateConfig.getFeatureSize("PALM_PC3_LEGACY_FEATURE_DATA_SIZE"));
		writePalmPartInfo(eventDataBuf, interDigitalLeft,
				meghaTemplateConfig.getFeatureSize("PALM_PC3_LEGACY_FEATURE_DATA_SIZE"));
		writePalmPartInfo(eventDataBuf, thenarLeft,
				meghaTemplateConfig.getFeatureSize("PALM_PC3_LEGACY_FEATURE_DATA_SIZE"));
		writePalmPartInfo(eventDataBuf, hypothenarLeft,
				meghaTemplateConfig.getFeatureSize("PALM_PC3_LEGACY_FEATURE_DATA_SIZE"));
		writePalmPartInfo(eventDataBuf, writerRight,
				meghaTemplateConfig.getFeatureSize("PALM_PC3_WRITERS_FEATURE_DATA_SIZE"));
		writePalmPartInfo(eventDataBuf, writerLeft,
				meghaTemplateConfig.getFeatureSize("PALM_PC3_WRITERS_FEATURE_DATA_SIZE"));

		return eventData;
	}

	@Override
	public void unpack(byte[] eventData, MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		ByteBuffer eventDataBuf = ByteBuffer.wrap(eventData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		eventHeader = new MeghaEventHeader();
		eventHeader.unpack(eventDataBuf);

		featureHoldFlag = eventDataBuf.get();

		List<Integer> featureIndexFlagList = HoldFlagUtil.getHoldFlagIndexList(featureHoldFlag, 8);

		interDigitalRight = readPalmPartInfo(eventDataBuf,
				meghaTemplateConfig.getFeatureSize("PALM_PC3_LEGACY_FEATURE_DATA_SIZE"),
				featureIndexFlagList.contains(0));
		thenarRight = readPalmPartInfo(eventDataBuf,
				meghaTemplateConfig.getFeatureSize("PALM_PC3_LEGACY_FEATURE_DATA_SIZE"),
				featureIndexFlagList.contains(1));
		hypothenarRight = readPalmPartInfo(eventDataBuf,
				meghaTemplateConfig.getFeatureSize("PALM_PC3_LEGACY_FEATURE_DATA_SIZE"),
				featureIndexFlagList.contains(2));
		interDigitalLeft = readPalmPartInfo(eventDataBuf,
				meghaTemplateConfig.getFeatureSize("PALM_PC3_LEGACY_FEATURE_DATA_SIZE"),
				featureIndexFlagList.contains(3));
		thenarLeft = readPalmPartInfo(eventDataBuf,
				meghaTemplateConfig.getFeatureSize("PALM_PC3_LEGACY_FEATURE_DATA_SIZE"),
				featureIndexFlagList.contains(4));
		hypothenarLeft = readPalmPartInfo(eventDataBuf,
				meghaTemplateConfig.getFeatureSize("PALM_PC3_LEGACY_FEATURE_DATA_SIZE"),
				featureIndexFlagList.contains(5));
		writerRight = readPalmPartInfo(eventDataBuf,
				meghaTemplateConfig.getFeatureSize("PALM_PC3_WRITERS_FEATURE_DATA_SIZE"),
				featureIndexFlagList.contains(6));
		writerLeft = readPalmPartInfo(eventDataBuf,
				meghaTemplateConfig.getFeatureSize("PALM_PC3_WRITERS_FEATURE_DATA_SIZE"),
				featureIndexFlagList.contains(7));

	}

	private void writePalmPartInfo(ByteBuffer eventDataBuf, MeghaPalmPartInfo palmPartInfo, int featureDataSize)
			throws MeghaTemplateException {
		if (palmPartInfo != null && palmPartInfo.getFeatureData() != null) {
			if (palmPartInfo.getFeatureData().length == 0 || palmPartInfo.getFeatureData().length > featureDataSize) {
				throw new MeghaTemplateException("Invalid Pc3FeatureData length, actual: "
						+ palmPartInfo.getFeatureData().length + ", expected: " + featureDataSize
						+ " for palmPartNumber: " + palmPartInfo.getPartNumber());
			}
			eventDataBuf.put(palmPartInfo.getPartNumber());
			eventDataBuf.put(palmPartInfo.getQuality());
			eventDataBuf.putInt(palmPartInfo.getFeatureData().length);
			eventDataBuf.put(palmPartInfo.getFeatureData());

			eventDataBuf.position(eventDataBuf.position() + featureDataSize - palmPartInfo.getFeatureData().length);
		} else {
			eventDataBuf.position(eventDataBuf.position() + 1 + 1 + 4 + featureDataSize);
		}
	}

	private MeghaPalmPartInfo readPalmPartInfo(ByteBuffer eventDataBuf, int featureDataSize, boolean featureFlag)
			throws MeghaTemplateException {
		if (featureFlag) {
			MeghaPalmPartInfo palmPartInfo = new MeghaPalmPartInfo();
			palmPartInfo.setPartNumber(eventDataBuf.get());
			palmPartInfo.setQuality(eventDataBuf.get());

			int dataSize = eventDataBuf.getInt();
			if (dataSize == 0 || dataSize > featureDataSize) {
				throw new MeghaTemplateException("Invalid dataSize length, actual: " + dataSize + ", expected: "
						+ featureDataSize + " for palmPartNumber: " + palmPartInfo.getPartNumber());
			}

			byte[] pc3FeatureData = new byte[featureDataSize];
			eventDataBuf.get(pc3FeatureData);

			palmPartInfo.setFeatureData(pc3FeatureData);

			eventDataBuf.position(eventDataBuf.position() + featureDataSize - dataSize);

			return palmPartInfo;
		} else {
			eventDataBuf.position(eventDataBuf.position() + 1 + 1 + 4 + featureDataSize);
			return null;
		}
	}
}
