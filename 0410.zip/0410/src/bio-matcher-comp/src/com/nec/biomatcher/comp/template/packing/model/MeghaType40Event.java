package com.nec.biomatcher.comp.template.packing.model;

import java.io.PrintStream;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Set;

import com.google.common.collect.Sets;
import com.nec.biomatcher.comp.template.packing.exception.MeghaTemplateException;
import com.nec.biomatcher.comp.template.packing.util.MeghaEventDataSizeBuilder;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateConfig;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateUtil;
import com.nec.biomatcher.spec.transfer.model.AlgorithmType;

public class MeghaType40Event extends MeghaEvent {
	public static final int MAX_PALM_PART_COUNT = 17;

	private byte[] partNumbers;
	private byte[] pc3PldbFeatureData;

	public void print(PrintStream printStream) {
		if (eventHeader != null) {
			eventHeader.print(printStream);
		}

		printStream.printf("%-20s - %s\n", "partNumbers", Arrays.toString(partNumbers));

	}

	public static int getEventDataSize(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		return new MeghaEventDataSizeBuilder(meghaTemplateConfig).bytes(MAX_PALM_PART_COUNT).featureDataLength(4)
				.featureData(1, "LATENT_PALM_PC3_FEATURE_DATA_SIZE").build();
	}

	public static final Set<AlgorithmType> getAlgorithmTypes() {
		return Sets.newHashSet(AlgorithmType.PALM_PC3R);
	}

	@Override
	public byte[] pack(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		if (pc3PldbFeatureData == null) {
			throw new MeghaTemplateException("Invalid pc3PldbFeatureData is not set");
		}

		if (pc3PldbFeatureData.length == 0 || pc3PldbFeatureData.length > meghaTemplateConfig
				.getFeatureSize("LATENT_PALM_PC3_FEATURE_DATA_SIZE")) {
			throw new MeghaTemplateException("Invalid pc3PldbFeatureData length, actual: " + pc3PldbFeatureData.length
					+ ", expected: " + meghaTemplateConfig.getFeatureSize("LATENT_PALM_PC3_FEATURE_DATA_SIZE"));
		}

		if (partNumbers != null && partNumbers.length != MAX_PALM_PART_COUNT) {
			throw new MeghaTemplateException(
					"Invalid partNumbers length, actual: " + partNumbers.length + ", expected: " + MAX_PALM_PART_COUNT);
		}

		if (eventHeader == null) {
			eventHeader = new MeghaEventHeader();
		}

		eventHeader.setAlgType(AlgorithmType.PALM_PC3R.getValue().byteValue());

		byte[] eventData = new byte[getEventDataSize(meghaTemplateConfig)];

		ByteBuffer eventDataBuf = ByteBuffer.wrap(eventData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		eventDataBuf.order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);

		eventDataBuf.put(eventHeader.pack());

		if (partNumbers == null) {
			partNumbers = new byte[MAX_PALM_PART_COUNT];
		}
		eventDataBuf.put(partNumbers);

		eventDataBuf.putInt(pc3PldbFeatureData.length);
		eventDataBuf.put(pc3PldbFeatureData);

		eventDataBuf.position(eventDataBuf.position()
				+ meghaTemplateConfig.getFeatureSize("LATENT_PALM_PC3_FEATURE_DATA_SIZE") - pc3PldbFeatureData.length);

		return eventData;
	}

	@Override
	public void unpack(byte[] eventData, MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		ByteBuffer eventDataBuf = ByteBuffer.wrap(eventData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		eventHeader = new MeghaEventHeader();
		eventHeader.unpack(eventDataBuf);

		partNumbers = new byte[MAX_PALM_PART_COUNT];
		eventDataBuf.get(partNumbers);

		int dataSize = eventDataBuf.getInt();
		if (dataSize == 0 || dataSize > meghaTemplateConfig.getFeatureSize("LATENT_PALM_PC3_FEATURE_DATA_SIZE")) {
			throw new MeghaTemplateException("Invalid dataSize length, actual: " + dataSize + ", expected: "
					+ meghaTemplateConfig.getFeatureSize("LATENT_PALM_PC3_FEATURE_DATA_SIZE"));
		}

		pc3PldbFeatureData = new byte[dataSize];
		eventDataBuf.get(pc3PldbFeatureData);

		eventDataBuf.position(eventDataBuf.position()
				+ meghaTemplateConfig.getFeatureSize("LATENT_PALM_PC3_FEATURE_DATA_SIZE") - dataSize);
	}

	public byte[] getPc3PldbFeatureData() {
		return pc3PldbFeatureData;
	}

	public void setPc3PldbFeatureData(byte[] pc3PldbFeatureData) {
		this.pc3PldbFeatureData = pc3PldbFeatureData;
	}

	public byte[] getPartNumbers() {
		return partNumbers;
	}

	public void setPartNumbers(byte[] partNumbers) {
		this.partNumbers = partNumbers;
	}
}
