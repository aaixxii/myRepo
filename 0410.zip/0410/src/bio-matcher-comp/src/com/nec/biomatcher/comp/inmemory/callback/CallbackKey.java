package com.nec.biomatcher.comp.inmemory.callback;

import com.nec.biomatcher.comp.inmemory.BioTaskType;

public class CallbackKey {

	private String taskKey;
	private BioTaskType taskType;
	private String callbackUrl;

	public CallbackKey() {

	}

	public CallbackKey(String taskKey, BioTaskType taskType) {
		this.taskKey = taskKey;
		this.taskType = taskType;
	}

	public CallbackKey(String taskKey, BioTaskType taskType, String callbackUrl) {
		this.taskKey = taskKey;
		this.taskType = taskType;
		this.callbackUrl = callbackUrl;
	}

	public String getTaskKey() {
		return taskKey;
	}

	public void setTaskKey(String taskKey) {
		this.taskKey = taskKey;
	}

	public BioTaskType getTaskType() {
		return taskType;
	}

	public void setTaskType(BioTaskType taskType) {
		this.taskType = taskType;
	}

	public String getCallbackUrl() {
		return callbackUrl;
	}

	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}

	@Override
	public String toString() {
		return "CallbackKey[taskKey: " + taskKey + ", taskType: " + taskType + ", callbackUrl: " + callbackUrl + "]";
	}
}
