package com.nec.biomatcher.comp.util;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;

import org.apache.log4j.Logger;

public class ValueChangeNotification<T> {
	private static final Logger logger = Logger.getLogger(ValueChangeNotification.class);

	private final String name;
	private final Supplier<T> valueSupplier;
	private final Consumer<T> valueConsumer;
	private T oldValue;
	private T newValue;

	public ValueChangeNotification(String name, Supplier<T> valueSupplier, Consumer<T> valueConsumer) {
		this.name = name;
		this.valueSupplier = valueSupplier;
		this.valueConsumer = valueConsumer;
		ValueChangeListener.registerValueChangeNotification(this);
	}

	public final synchronized void checkAndNotify() {
		newValue = valueSupplier.get();
		if (!Objects.equals(oldValue, newValue)) {
			logger.info("In ValueChangeNotification: name: " + name + ", oldValue: " + oldValue + ", newValue: "
					+ newValue);
			valueConsumer.accept(newValue);
			oldValue = newValue;
		}
	}

	@Override
	public String toString() {
		return name != null ? name : super.toString();
	}

	public final T getValue() {
		return valueSupplier.get();
	}

	public T getOldValue() {
		return oldValue;
	}

	public T getNewValue() {
		return newValue;
	}
}
