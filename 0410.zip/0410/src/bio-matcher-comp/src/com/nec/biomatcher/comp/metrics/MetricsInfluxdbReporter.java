package com.nec.biomatcher.comp.metrics;

import java.io.IOException;
import java.net.URI;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URIBuilder;
import org.apache.log4j.Logger;
import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.dto.Point;
import org.influxdb.dto.Point.Builder;

import com.codahale.metrics.Counter;
import com.codahale.metrics.Gauge;
import com.codahale.metrics.Histogram;
import com.codahale.metrics.Meter;
import com.codahale.metrics.Metered;
import com.codahale.metrics.MetricFilter;
import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.ScheduledReporter;
import com.codahale.metrics.Snapshot;
import com.codahale.metrics.Timer;
import com.nec.biomatcher.core.framework.common.HostnameUtil;

/**
 * The Class MetricsInfluxdbReporter.
 */
public class MetricsInfluxdbReporter extends ScheduledReporter {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(MetricsInfluxdbReporter.class);

	/** The connection url. */
	private String connectionUrl;

	/** The influx db. */
	private InfluxDB influxDB;

	/** The database name. */
	private String databaseName;

	/** The retention policy. */
	private String retentionPolicy = "default";

	/** The hostname. */
	private String hostname;

	/**
	 * Initialize connection.
	 *
	 * @throws Exception
	 *             the exception
	 */
	private synchronized void initializeConnection() throws Exception {
		logger.info("In MetricsInfluxdbReporter.initializeConnection : " + influxDB);
		hostname = HostnameUtil.getHostname();
		if (influxDB != null) {
			logger.info("In MetricsInfluxdbReporter.initializeConnection: Connection already established");
			return;
		}

		URI uri = new URI(connectionUrl);
		String influxDbConnectionUrl = uri.getScheme() + "://" + uri.getHost() + ":" + uri.getPort();
		String influxDbName = StringUtils.replaceEach(uri.getPath(), new String[] { "/", "@" },
				new String[] { "", "" });
		String influxDbUserName = StringUtils.substringBefore(uri.getRawUserInfo(), ":");
		String influxDbPassword = StringUtils.substringAfter(uri.getRawUserInfo(), ":");
		URIBuilder uriBuilder = new URIBuilder(uri);

		for (NameValuePair nameValuePair : uriBuilder.getQueryParams()) {
			if ("retentionPolicy".equalsIgnoreCase(nameValuePair.getName())) {
				if (StringUtils.isNotBlank(nameValuePair.getValue())) {
					retentionPolicy = nameValuePair.getValue();
				}
			}
		}

		databaseName = influxDbName;
		logger.info("Influx database connection: influxDbConnectionUrl: " + influxDbConnectionUrl + ", influxDbName: "
				+ influxDbName + ", influxDbUserName: " + influxDbUserName + ", influxDbPassword: " + influxDbPassword);

		try {
			influxDB = InfluxDBFactory.connect(influxDbConnectionUrl, influxDbUserName, influxDbPassword);

			List<String> databaseList = influxDB.describeDatabases();
			boolean createDatabase = true;
			for (String databaseName : databaseList) {
				if (databaseName.equalsIgnoreCase(influxDbName)) {
					createDatabase = false;
					break;
				}
			}

			if (createDatabase) {
				influxDB.createDatabase(influxDbName);
			}

		} catch (Throwable th) {
			logger.error("Error checking/creating influxdb: influxDbConnectionUrl: " + influxDbConnectionUrl
					+ ", influxDbName: " + influxDbName + " : " + th.getMessage(), th);
		}
	}

	/**
	 * For registry.
	 *
	 * @param registry
	 *            the registry
	 * @return the report builder
	 */
	public static ReportBuilder forRegistry(MetricRegistry registry) {
		return new ReportBuilder(registry);
	}

	/**
	 * The Class ReportBuilder.
	 */
	public static class ReportBuilder {

		/** The registry. */
		private final MetricRegistry registry;

		/** The connection url. */
		private String connectionUrl;

		/** The rate unit. */
		private TimeUnit rateUnit;

		/** The duration unit. */
		private TimeUnit durationUnit;

		/** The filter. */
		private MetricFilter filter;

		/**
		 * Instantiates a new report builder.
		 *
		 * @param registry
		 *            the registry
		 */
		private ReportBuilder(MetricRegistry registry) {
			this.registry = registry;
			this.rateUnit = TimeUnit.SECONDS;
			this.durationUnit = TimeUnit.MILLISECONDS;
			this.filter = MetricFilter.ALL;
		}

		/**
		 * With connection url.
		 *
		 * @param connectionUrl
		 *            the connection url
		 * @return the report builder
		 */
		public ReportBuilder withConnectionUrl(String connectionUrl) {
			this.connectionUrl = connectionUrl;
			return this;
		}

		/**
		 * Convert rates to.
		 *
		 * @param rateUnit
		 *            the rate unit
		 * @return the report builder
		 */
		public ReportBuilder convertRatesTo(TimeUnit rateUnit) {
			this.rateUnit = rateUnit;
			return this;
		}

		/**
		 * Convert durations to.
		 *
		 * @param durationUnit
		 *            the duration unit
		 * @return the report builder
		 */
		public ReportBuilder convertDurationsTo(TimeUnit durationUnit) {
			this.durationUnit = durationUnit;
			return this;
		}

		/**
		 * Filter.
		 *
		 * @param filter
		 *            the filter
		 * @return the report builder
		 */
		public ReportBuilder filter(MetricFilter filter) {
			this.filter = filter;
			return this;
		}

		/**
		 * Builds the.
		 *
		 * @return the metrics influxdb reporter
		 */
		public MetricsInfluxdbReporter build() {
			return new MetricsInfluxdbReporter(registry, connectionUrl, filter, rateUnit, durationUnit);
		}
	}

	/**
	 * Instantiates a new metrics influxdb reporter.
	 *
	 * @param registry
	 *            the registry
	 * @param connectionUrl
	 *            the connection url
	 * @param filter
	 *            the filter
	 * @param rateUnit
	 *            the rate unit
	 * @param durationUnit
	 *            the duration unit
	 */
	private MetricsInfluxdbReporter(MetricRegistry registry, String connectionUrl, MetricFilter filter,
			TimeUnit rateUnit, TimeUnit durationUnit) {
		super(registry, "influxdb-reporter", filter, rateUnit, durationUnit);
		this.connectionUrl = connectionUrl;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public void report(SortedMap<String, Gauge> gauges, SortedMap<String, Counter> counters,
			SortedMap<String, Histogram> histograms, SortedMap<String, Meter> meters, SortedMap<String, Timer> timers) {
		logger.trace("In MetricsInfluxdbReporter.report");
		final long timestamp = System.currentTimeMillis();

		try {
			if (influxDB == null) {
				initializeConnection();
			}

			for (Map.Entry<String, Gauge> entry : gauges.entrySet()) {
				reportGauge(entry.getKey(), entry.getValue(), timestamp);
			}

			for (Map.Entry<String, Counter> entry : counters.entrySet()) {
				reportCounter(entry.getKey(), entry.getValue(), timestamp);
			}

			for (Map.Entry<String, Histogram> entry : histograms.entrySet()) {
				reportHistogram(entry.getKey(), entry.getValue(), timestamp);
			}

			for (Map.Entry<String, Meter> entry : meters.entrySet()) {
				reportMeter(entry.getKey(), entry.getValue(), timestamp);
			}

			for (Map.Entry<String, Timer> entry : timers.entrySet()) {
				reportTimer(entry.getKey(), entry.getValue(), timestamp);
			}
		} catch (Throwable th) {
			logger.error("Error in MetricsInfluxdbReporter: Unable to report to InfluxDB, forgot data : " + th, th);
		}
	}

	/**
	 * Report timer.
	 *
	 * @param name
	 *            the name
	 * @param timer
	 *            the timer
	 * @param timestamp
	 *            the timestamp
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	private void reportTimer(String name, Timer timer, long timestamp) throws IOException {
		final Snapshot snapshot = timer.getSnapshot();
		Builder builder = buildPoint(name);
		builder.tag("metricType", "timer");
		builder.time(timestamp, TimeUnit.MILLISECONDS);
		builder.field("count", snapshot.size());
		builder.field("timeTakenMin", convertDuration(snapshot.getMin()));
		builder.field("timeTakenMax", convertDuration(snapshot.getMax()));
		builder.field("timeTakenMean", convertDuration(snapshot.getMean()));
		builder.field("timeTakenStdDev", convertDuration(snapshot.getStdDev()));
		builder.field("timeTaken50Percentile", convertDuration(snapshot.getMedian()));
		builder.field("timeTaken75Percentile", convertDuration(snapshot.get75thPercentile()));
		builder.field("timeTaken95Percentile", convertDuration(snapshot.get95thPercentile()));
		builder.field("timeTaken99Percentile", convertDuration(snapshot.get99thPercentile()));
		builder.field("timeTaken999Percentile", convertDuration(snapshot.get999thPercentile()));
		builder.field("timeTakenOneMinute", convertRate(timer.getOneMinuteRate()));
		builder.field("timeTakenFiveMinute", convertRate(timer.getFiveMinuteRate()));
		builder.field("timeTakenFifteenMinute", convertRate(timer.getFifteenMinuteRate()));
		builder.field("meanRate", convertRate(timer.getMeanRate()));

		influxDB.write(databaseName, retentionPolicy, builder.build());
	}

	/**
	 * Report histogram.
	 *
	 * @param name
	 *            the name
	 * @param histogram
	 *            the histogram
	 * @param timestamp
	 *            the timestamp
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	private void reportHistogram(String name, Histogram histogram, long timestamp) throws IOException {
		final Snapshot snapshot = histogram.getSnapshot();
		Builder builder = buildPoint(name);
		builder.tag("metricType", "histogram");
		builder.time(timestamp, TimeUnit.MILLISECONDS);
		builder.field("count", snapshot.size());
		builder.field("min", snapshot.getMin());
		builder.field("max", snapshot.getMax());
		builder.field("mean", snapshot.getMean());
		builder.field("std-dev", snapshot.getStdDev());
		builder.field("50Percentile", snapshot.getMedian());
		builder.field("75Percentile", snapshot.get75thPercentile());
		builder.field("95Percentile", snapshot.get95thPercentile());
		builder.field("99Percentile", snapshot.get99thPercentile());
		builder.field("999Percentile", snapshot.get999thPercentile());

		influxDB.write(databaseName, retentionPolicy, builder.build());
	}

	/**
	 * Report counter.
	 *
	 * @param name
	 *            the name
	 * @param counter
	 *            the counter
	 * @param timestamp
	 *            the timestamp
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	private void reportCounter(String name, Counter counter, long timestamp) throws IOException {
		Builder builder = buildPoint(name);
		builder.tag("metricType", "histogram");
		builder.time(timestamp, TimeUnit.MILLISECONDS);
		builder.field("count", counter.getCount());

		influxDB.write(databaseName, retentionPolicy, builder.build());
	}

	/**
	 * Report gauge.
	 *
	 * @param name
	 *            the name
	 * @param gauge
	 *            the gauge
	 * @param timestamp
	 *            the timestamp
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	private void reportGauge(String name, Gauge<?> gauge, long timestamp) throws IOException {
		Builder builder = buildPoint(name);
		builder.tag("metricType", "gauge");
		builder.time(timestamp, TimeUnit.MILLISECONDS);
		builder.field("value", gauge.getValue());

		influxDB.write(databaseName, retentionPolicy, builder.build());
	}

	/**
	 * Report meter.
	 *
	 * @param name
	 *            the name
	 * @param meter
	 *            the meter
	 * @param timestamp
	 *            the timestamp
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	private void reportMeter(String name, Metered meter, long timestamp) throws IOException {
		Builder builder = buildPoint(name);
		builder.tag("metricType", "meter");
		builder.time(timestamp, TimeUnit.MILLISECONDS);
		builder.field("count", meter.getCount());
		builder.field("oneMinuteRate", convertRate(meter.getOneMinuteRate()));
		builder.field("fiveMinuteRate", convertRate(meter.getFiveMinuteRate()));
		builder.field("fifteenMinuteRate", convertRate(meter.getFifteenMinuteRate()));
		builder.field("meanRate", convertRate(meter.getMeanRate()));

		influxDB.write(databaseName, retentionPolicy, builder.build());
	}

	/**
	 * Builds the point.
	 *
	 * @param key
	 *            the key
	 * @return the builder
	 */
	private Builder buildPoint(String key) {
		String keyParts[] = key.split("\\.");
		if (keyParts.length % 2 == 0) {
			throw new IllegalArgumentException(
					"Unable to parse metricKey. Invalid metric key: " + key + ", mod: " + (keyParts.length % 2));
		}

		Builder builder = Point.measurement(keyParts[keyParts.length - 1]);
		for (int i = 0; i < keyParts.length - 1; i += 2) {
			builder.tag(keyParts[i], keyParts[i + 1]);
		}
		builder.tag("hostname", hostname);
		return builder;
	}

	/**
	 * The main method.
	 *
	 * @param args
	 *            the arguments
	 * @throws Exception
	 *             the exception
	 */
	public static void main(String args[]) throws Exception {
		String str = "nodeType.VC.nodeName.VC001.JJJ";
		System.out.println(str.split("\\.").length % 2);
		for (String s : str.split("\\.")) {
			System.out.println(s);
		}
	}
}
