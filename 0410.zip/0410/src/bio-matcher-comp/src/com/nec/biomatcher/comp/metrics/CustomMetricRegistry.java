package com.nec.biomatcher.comp.metrics;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

import com.codahale.metrics.Counter;
import com.codahale.metrics.Histogram;
import com.codahale.metrics.Meter;
import com.codahale.metrics.Metric;
import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.Reservoir;
import com.codahale.metrics.SlidingTimeWindowReservoir;
import com.codahale.metrics.Timer;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;

public class CustomMetricRegistry extends MetricRegistry {
	private ConcurrentMap<String, Metric> metrics;
	private static Supplier<Integer> slidingTimeWindowReservoirSeconds = BioParameterService
			.getIntSupplier("SLIDING_TIME_WINDOW_RESERVOIR_SECONDS", "DEFAULT", 60);

	public CustomMetricRegistry() {
		super();
		metrics = buildMap();
	}

	protected ConcurrentMap<String, Metric> buildMap() {
		if (metrics == null) {
			metrics = new ConcurrentHashMap<String, Metric>();
		}
		return metrics;
	}

	private static Reservoir getReservoirInstance() {
		return new SlidingTimeWindowReservoir(slidingTimeWindowReservoirSeconds.get(), TimeUnit.SECONDS);
	}

	public Counter counter(String name) {
		return getOrAdd(name, MetricBuilder.COUNTERS);
	}

	public Histogram histogram(String name) {
		return getOrAdd(name, MetricBuilder.HISTOGRAMS);
	}

	public Meter meter(String name) {
		return getOrAdd(name, MetricBuilder.METERS);
	}

	public Timer timer(String name) {
		return getOrAdd(name, MetricBuilder.TIMERS);
	}

	@SuppressWarnings("unchecked")
	private <T extends Metric> T getOrAdd(String name, MetricBuilder<T> builder) {
		final Metric metric = metrics.get(name);
		if (builder.isInstance(metric)) {
			return (T) metric;
		} else if (metric == null) {
			try {
				return register(name, builder.newMetric());
			} catch (IllegalArgumentException e) {
				final Metric added = metrics.get(name);
				if (builder.isInstance(added)) {
					return (T) added;
				}
			}
		}
		throw new IllegalArgumentException(name + " is already used for a different type of metric");
	}

	private interface MetricBuilder<T extends Metric> {
		MetricBuilder<Counter> COUNTERS = new MetricBuilder<Counter>() {
			@Override
			public Counter newMetric() {
				return new Counter();
			}

			@Override
			public boolean isInstance(Metric metric) {
				return Counter.class.isInstance(metric);
			}
		};

		MetricBuilder<Histogram> HISTOGRAMS = new MetricBuilder<Histogram>() {
			@Override
			public Histogram newMetric() {
				return new Histogram(getReservoirInstance());
			}

			@Override
			public boolean isInstance(Metric metric) {
				return Histogram.class.isInstance(metric);
			}
		};

		MetricBuilder<Meter> METERS = new MetricBuilder<Meter>() {
			@Override
			public Meter newMetric() {
				return new Meter();
			}

			@Override
			public boolean isInstance(Metric metric) {
				return Meter.class.isInstance(metric);
			}
		};

		MetricBuilder<Timer> TIMERS = new MetricBuilder<Timer>() {
			@Override
			public Timer newMetric() {
				return new Timer(getReservoirInstance());
			}

			@Override
			public boolean isInstance(Metric metric) {
				return Timer.class.isInstance(metric);
			}
		};

		T newMetric();

		boolean isInstance(Metric metric);
	}
}
