package com.nec.biomatcher.comp.template.packing.model;

import java.io.PrintStream;

import com.nec.biomatcher.comp.template.packing.exception.MeghaTemplateException;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateConfig;

public class MeghaType49Template extends MeghaTemplate {

	public MeghaType49Template(int userFlagByteCount) {
		super(userFlagByteCount);
	}

	public void print(PrintStream printStream) {
		printStream.println("---------Not supported---------");
	}

	@Override
	public byte[] pack(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		throw new MeghaTemplateException("Packing is not supported for templateType 49");
	}

	@Override
	public void unpack(byte[] templateData, MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		throw new MeghaTemplateException("UnPacking is not supported for templateType 49");
	}
}
