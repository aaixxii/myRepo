package com.nec.biomatcher.comp.template.packing.model;

import java.io.PrintStream;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.google.common.collect.Sets;
import com.google.common.primitives.UnsignedBytes;
import com.nec.biomatcher.comp.template.packing.exception.MeghaTemplateException;
import com.nec.biomatcher.comp.template.packing.util.MeghaEventDataSizeBuilder;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateConfig;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateUtil;
import com.nec.biomatcher.core.framework.common.HoldFlagUtil;
import com.nec.biomatcher.spec.transfer.model.AlgorithmType;

public class MeghaType12Event extends MeghaEvent {
	private byte featureHoldFlag = 0;
	private byte irisRightQuality;
	private byte irisLeftQuality;
	private byte pad[] = new byte[7];
	private byte irisRightFeatureData[];
	private byte irisLeftFeatureData[];

	public void print(PrintStream printStream) {
		if (eventHeader != null) {
			eventHeader.print(printStream);
		}
		printStream.printf("%-20s - %s\n", "featureHoldFlag",
				StringUtils.leftPad(UnsignedBytes.toString(featureHoldFlag, 2), Byte.SIZE, "0"));
		printStream.printf("%-20s - %s\n", "irisRightQuality", irisRightQuality);
		printStream.printf("%-20s - %s\n", "irisLeftQuality", irisLeftQuality);
		printStream.printf("%-20s - %s\n", "irisRightFeatureData", irisRightFeatureData != null);
		printStream.printf("%-20s - %s\n", "irisLeftFeatureData", irisLeftFeatureData != null);
	}

	public static int getEventDataSize(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		return new MeghaEventDataSizeBuilder(meghaTemplateConfig).featureHoldFlag(1).quality(2).pad(7)
				.featureData(2, "IRIS_DELTA_ID_FEATURE_DATA_SIZE").build();
	}

	public static final Set<AlgorithmType> getAlgorithmTypes() {
		return Sets.newHashSet(AlgorithmType.IRIS_DELTA_ID);
	}

	@Override
	public byte[] pack(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		if (eventHeader == null) {
			eventHeader = new MeghaEventHeader();
		}

		eventHeader.setAlgType(AlgorithmType.IRIS_DELTA_ID.getValue().byteValue());

		featureHoldFlag = 0;
		featureHoldFlag = HoldFlagUtil.setHoldFlag(featureHoldFlag, 0, irisRightFeatureData != null);
		featureHoldFlag = HoldFlagUtil.setHoldFlag(featureHoldFlag, 1, irisLeftFeatureData != null);

		byte[] eventData = new byte[getEventDataSize(meghaTemplateConfig)];
		ByteBuffer eventDataBuf = ByteBuffer.wrap(eventData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);

		eventDataBuf.put(eventHeader.pack());

		eventDataBuf.put(featureHoldFlag);

		eventDataBuf.put(irisRightQuality);
		eventDataBuf.put(irisLeftQuality);

		eventDataBuf.put(pad);

		if (irisRightFeatureData != null) {
			if (irisRightFeatureData.length != meghaTemplateConfig.getFeatureSize("IRIS_DELTA_ID_FEATURE_DATA_SIZE")) {
				throw new MeghaTemplateException(
						"Invalid irisRightFeatureData length, actual: " + irisRightFeatureData.length + ", expected: "
								+ meghaTemplateConfig.getFeatureSize("IRIS_DELTA_ID_FEATURE_DATA_SIZE"));
			}
			eventDataBuf.put(irisRightFeatureData);
		} else {
			eventDataBuf.position(
					eventDataBuf.position() + meghaTemplateConfig.getFeatureSize("IRIS_DELTA_ID_FEATURE_DATA_SIZE"));
		}

		if (irisLeftFeatureData != null) {
			if (irisLeftFeatureData.length != meghaTemplateConfig.getFeatureSize("IRIS_DELTA_ID_FEATURE_DATA_SIZE")) {
				throw new MeghaTemplateException(
						"Invalid irisLeftFeatureData length, actual: " + irisLeftFeatureData.length + ", expected: "
								+ meghaTemplateConfig.getFeatureSize("IRIS_DELTA_ID_FEATURE_DATA_SIZE"));
			}
			eventDataBuf.put(irisLeftFeatureData);
		} else {
			eventDataBuf.position(
					eventDataBuf.position() + meghaTemplateConfig.getFeatureSize("IRIS_DELTA_ID_FEATURE_DATA_SIZE"));
		}

		return eventData;
	}

	@Override
	public void unpack(byte[] eventData, MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		ByteBuffer eventDataBuf = ByteBuffer.wrap(eventData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		eventHeader = new MeghaEventHeader();
		eventHeader.unpack(eventDataBuf);

		featureHoldFlag = eventDataBuf.get();

		irisRightQuality = eventDataBuf.get();
		irisLeftQuality = eventDataBuf.get();

		eventDataBuf.position(eventDataBuf.position() + pad.length);

		List<Integer> featureIndexFlagList = HoldFlagUtil.getHoldFlagIndexList(featureHoldFlag, 2);

		if (featureIndexFlagList.contains(0)) {
			irisRightFeatureData = new byte[meghaTemplateConfig.getFeatureSize("IRIS_DELTA_ID_FEATURE_DATA_SIZE")];
			eventDataBuf.get(irisRightFeatureData);
		} else {
			eventDataBuf.position(
					eventDataBuf.position() + meghaTemplateConfig.getFeatureSize("IRIS_DELTA_ID_FEATURE_DATA_SIZE"));
		}

		if (featureIndexFlagList.contains(1)) {
			irisLeftFeatureData = new byte[meghaTemplateConfig.getFeatureSize("IRIS_DELTA_ID_FEATURE_DATA_SIZE")];
			eventDataBuf.get(irisLeftFeatureData);
		} else {
			eventDataBuf.position(
					eventDataBuf.position() + meghaTemplateConfig.getFeatureSize("IRIS_DELTA_ID_FEATURE_DATA_SIZE"));
		}
	}

	public byte getIrisRightQuality() {
		return irisRightQuality;
	}

	public void setIrisRightQuality(byte irisRightQuality) {
		this.irisRightQuality = irisRightQuality;
	}

	public byte getIrisLeftQuality() {
		return irisLeftQuality;
	}

	public void setIrisLeftQuality(byte irisLeftQuality) {
		this.irisLeftQuality = irisLeftQuality;
	}

	public byte[] getIrisRightFeatureData() {
		return irisRightFeatureData;
	}

	public void setIrisRightFeatureData(byte[] irisRightFeatureData) {
		this.irisRightFeatureData = irisRightFeatureData;
	}

	public byte[] getIrisLeftFeatureData() {
		return irisLeftFeatureData;
	}

	public void setIrisLeftFeatureData(byte[] irisLeftFeatureData) {
		this.irisLeftFeatureData = irisLeftFeatureData;
	}

}
