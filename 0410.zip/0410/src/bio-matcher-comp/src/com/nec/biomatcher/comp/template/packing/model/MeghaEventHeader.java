package com.nec.biomatcher.comp.template.packing.model;

import java.io.PrintStream;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Map;

import com.nec.biomatcher.comp.template.packing.exception.MeghaTemplateException;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateUtil;
import com.nec.biomatcher.comp.template.packing.util.OffsetInfo;
import com.nec.biomatcher.spec.transfer.model.AlgorithmType;

public class MeghaEventHeader {
	public static final int EVENT_HEADER_SIZE = 38;

	public static final int EVENT_ID_MAX_SIZE = 36;

	private String eventId;
	private byte algType;
	private byte feType;

	public void print(PrintStream printStream) {
		printStream.printf("%-20s - %s\n", "eventId", eventId);
		printStream.printf("%-20s - %s\n", "algType", AlgorithmType.enumOf((int) algType));
		printStream.printf("%-20s - %s\n", "feType", (char) feType);
	}

	public byte[] pack() throws MeghaTemplateException {
		byte[] eventHeader = new byte[EVENT_HEADER_SIZE];

		ByteBuffer eventHeaderBuf = ByteBuffer.wrap(eventHeader).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);

		eventHeaderBuf.position(0);

		MeghaTemplateUtil.setStringData(eventId, EVENT_ID_MAX_SIZE, eventHeaderBuf);

		eventHeaderBuf.put(algType);
		eventHeaderBuf.put(feType);

		return eventHeader;
	}

	public void unpack(ByteBuffer eventHeader) throws MeghaTemplateException {
		eventId = MeghaTemplateUtil.getStringData(EVENT_ID_MAX_SIZE, eventHeader);
		algType = eventHeader.get();
		feType = eventHeader.get();
	}

	public static final Map<String, OffsetInfo> getEventHeaderFieldOffsetInfoMap() {
		Map<String, OffsetInfo> eventHeaderFieldOffsetInfoMap = new HashMap<>();

		byte[] eventHeader = new byte[EVENT_HEADER_SIZE];
		ByteBuffer eventHeaderBuf = ByteBuffer.wrap(eventHeader).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		eventHeaderBuf.position(0);

		eventHeaderFieldOffsetInfoMap.put("eventId", new OffsetInfo(eventHeaderBuf.position(), EVENT_ID_MAX_SIZE));
		eventHeaderBuf.get(new byte[EVENT_ID_MAX_SIZE]);

		eventHeaderFieldOffsetInfoMap.put("algType", new OffsetInfo(eventHeaderBuf.position(), 1));
		eventHeaderBuf.get();

		eventHeaderFieldOffsetInfoMap.put("feType", new OffsetInfo(eventHeaderBuf.position(), 1));
		eventHeaderBuf.get();

		return eventHeaderFieldOffsetInfoMap;
	}

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	public byte getAlgType() {
		return algType;
	}

	public void setAlgType(byte algType) {
		this.algType = algType;
	}

	public byte getFeType() {
		return feType;
	}

	public void setFeType(byte feType) {
		this.feType = feType;
	}

}
