package com.nec.biomatcher.comp.template.packing.util;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

public class EventKey {
	private String eventId;
	private byte algorithmTypeCode;
	private byte feTypeCode;

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	public byte getAlgorithmTypeCode() {
		return algorithmTypeCode;
	}

	public void setAlgorithmTypeCode(byte algorithmTypeCode) {
		this.algorithmTypeCode = algorithmTypeCode;
	}

	public byte getFeTypeCode() {
		return feTypeCode;
	}

	public void setFeTypeCode(byte feTypeCode) {
		this.feTypeCode = feTypeCode;
	}

	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof EventKey)) {
			return false;
		}

		EventKey other = (EventKey) obj;
		return new EqualsBuilder().append(eventId, other.eventId).append(algorithmTypeCode, other.algorithmTypeCode)
				.append(feTypeCode, other.feTypeCode).isEquals();
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(eventId).append(algorithmTypeCode).append(feTypeCode).toHashCode();
	}

	@Override
	public String toString() {
		return new StringBuilder().append(eventId).append(":").append(algorithmTypeCode).append(":").append(feTypeCode)
				.toString();
	}

}
