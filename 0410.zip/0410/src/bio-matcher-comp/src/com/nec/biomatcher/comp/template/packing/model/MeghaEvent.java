package com.nec.biomatcher.comp.template.packing.model;

import java.io.PrintStream;

import com.nec.biomatcher.comp.template.packing.exception.MeghaTemplateException;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateConfig;

public abstract class MeghaEvent {

	protected MeghaEventHeader eventHeader;

	public MeghaEventHeader getEventHeader() {
		if (eventHeader == null) {
			eventHeader = new MeghaEventHeader();
		}
		return eventHeader;
	}

	public void setEventHeader(MeghaEventHeader eventHeader) {
		this.eventHeader = eventHeader;
	}

	public abstract byte[] pack(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException;

	public abstract void unpack(byte[] templateData, MeghaTemplateConfig meghaTemplateConfig)
			throws MeghaTemplateException;

	public abstract void print(PrintStream printStream);
}
