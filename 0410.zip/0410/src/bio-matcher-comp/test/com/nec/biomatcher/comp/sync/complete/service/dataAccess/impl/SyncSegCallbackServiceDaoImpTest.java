package com.nec.biomatcher.comp.sync.complete.service.dataAccess.impl;

import java.util.Date;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherNodeSegmentInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherSegmentInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricEventInfo;
import com.nec.biomatcher.comp.sync.complete.service.dataAccess.SyncSegCallbackServiceDao;
import com.nec.biomatcher.core.framework.dataAccess.DaoException;

public class SyncSegCallbackServiceDaoImpTest {

	private ApplicationContext appContext;

	@Before
	public void setUp() throws Exception {

	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetAllActiveSnSegInfo() {

	}

	@Test
	public void testGetAllSegmentInfo() throws DaoException {
		appContext = new ClassPathXmlApplicationContext("/F:/Ms_sql_server/megha_ms_sql/src/bio-matcher-comp/test/resources/spring-hibernate.xml");
		SyncSegCallbackServiceDao dao = (SyncSegCallbackServiceDaoImp) appContext.getBean("syncSegCallbackServiceDao");

		BioMatcherSegmentInfo segInfo = new BioMatcherSegmentInfo();
		segInfo.setBinId(35);
		segInfo.setSegmentId(1000);
		segInfo.setSegmentVersion(1L);
		segInfo.setUpdateDateTime(new Date());

		List<BioMatcherNodeSegmentInfo> sn = dao.getNodeSegmentInfoBySegId(10001);
		Assert.assertEquals(1, sn.size());
		List<BiometricEventInfo> sd = dao.getStrictBiometricEventInfoList(1, 1l, "1");
		Assert.assertNotNull(sd);

	}
}