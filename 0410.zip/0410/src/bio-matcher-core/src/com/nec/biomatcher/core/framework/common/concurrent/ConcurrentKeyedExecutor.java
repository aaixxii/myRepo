package com.nec.biomatcher.core.framework.common.concurrent;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Supplier;

import org.apache.log4j.Logger;

import com.google.common.collect.Sets;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.ShutdownHook;

public class ConcurrentKeyedExecutor<K> {
	private static final Logger logger = Logger.getLogger(ConcurrentKeyedExecutor.class);

	private static final ConcurrentHashMap<String, ConcurrentKeyedExecutor<?>> CONCURRENT_INSTANCE_MAP = new ConcurrentHashMap<>();
	private static final ManagementThread MANAGEMENT_THREAD = new ManagementThread();

	private final ConcurrentSkipListSet<K> workingSet = new ConcurrentSkipListSet<>();
	private final String name;
	private final CustomKeyedRunnable<K> keyedRunnable;
	private final Supplier<Integer> concurrencyCountPerKeySupplier;
	private final Supplier<? extends Set<K>> keySetSupplier;
	private final ConcurrentValuedHashMap<K, ConcurrentSkipListSet<WorkerThread>> keyWorkerThreadListMap = new ConcurrentValuedHashMap<>(
			(key) -> new ConcurrentSkipListSet<>());
	private final ConcurrentValuedHashMap<K, Semaphore> keyDataWaitSemaphoreMap = new ConcurrentValuedHashMap<>(
			(key) -> new Semaphore(0));

	public ConcurrentKeyedExecutor(String name, Supplier<? extends Set<K>> keySetSupplier,
			CustomKeyedRunnable<K> keyedRunnable, Supplier<Integer> concurrencyCountPerKeySupplier) {
		this.name = name;
		this.keySetSupplier = keySetSupplier;
		this.keyedRunnable = keyedRunnable;
		this.concurrencyCountPerKeySupplier = concurrencyCountPerKeySupplier;

		CONCURRENT_INSTANCE_MAP.put(name, this);
	}

	public void notifyData(K key) {
		keyDataWaitSemaphoreMap.getValue(key).release();
	}

	private void manageKeySetWorkers() {
		Set<K> newKeySet = keySetSupplier.get();

		Set<K> newAddedKeys = Sets.difference(newKeySet, workingSet);
		for (K key : newAddedKeys) {
			manageKeySetWorkers(key);
		}
	}

	private void manageKeySetWorkers(K key) {
		ConcurrentSkipListSet<WorkerThread> workerThreadList = keyWorkerThreadListMap.getValue(key);
		int newConcurrencyCount = concurrencyCountPerKeySupplier.get();

		while (workerThreadList.size() < newConcurrencyCount) {
			WorkerThread workerThread = new WorkerThread(key);
			workerThread.start();
			workerThread.waitForStart();

			CommonLogger.STATUS_LOG.info("After starting the WorkerThread for name: " + name + ", key: " + key
					+ ", workerThreadListSize: " + workerThreadList.size());
		}

		while (workerThreadList.size() > newConcurrencyCount) {
			WorkerThread workerThread = workerThreadList.first();
			workerThread.stopWorker();
			workerThread.waitForStop();
			CommonLogger.STATUS_LOG.info("After starting the WorkerThread for name:  " + name + ", key: " + key
					+ " is stopped, newConcurrencyCount: " + newConcurrencyCount + ", workerThreadListSize: "
					+ workerThreadList.size());
		}

	}

	private static class ManagementThread implements Runnable {
		private boolean isFirstRun = true;

		public ManagementThread() {
			schedule();
		}

		@Override
		public void run() {
			Thread.currentThread().setName("CONCURRENT_KEYED_EXECUTOR_MGMT_THREAD_" + Thread.currentThread().getId());

			if (isFirstRun) {
				CommonLogger.STATUS_LOG.info("ConcurrentKeyedExecutor.ManagementThread.run");
				isFirstRun = false;
			}

			for (String name : CONCURRENT_INSTANCE_MAP.keySet()) {
				ConcurrentKeyedExecutor<?> concurrentKeyedExecutor = CONCURRENT_INSTANCE_MAP.get(name);
				if (concurrentKeyedExecutor != null) {
					concurrentKeyedExecutor.manageKeySetWorkers();
				}
			}
		}

		public void schedule() {
			CommonTaskScheduler.cancelTask(this, true);

			CommonTaskScheduler.scheduleWithFixedDelay(this, 30, 45, TimeUnit.SECONDS);
		}
	}

	private class WorkerThread extends Thread implements Comparable<WorkerThread> {

		/** The start latch. */
		private final Semaphore startLatch = new Semaphore(0);

		private final Semaphore stopLatch = new Semaphore(0);

		private final AtomicBoolean stopFlag = new AtomicBoolean(false);

		private final K key;

		private final String threadName;

		private final Semaphore keyDataWaitSemaphore;

		/**
		 * Instantiates a new worker thread.
		 */
		public WorkerThread(K key) {
			this.key = key;
			this.threadName = name + "_" + key + "_WORKER_" + getId();
			this.keyDataWaitSemaphore = keyDataWaitSemaphoreMap.getValue(key);
		}

		public void run() {
			try {
				setName(threadName);

				CommonLogger.STATUS_LOG.info("In ConcurrentKeyedExecutor worker thread run key: " + key);

				keyWorkerThreadListMap.getValue(key).add(this);
				startLatch.release();

				// As these objects are used in loop, bellow assignment will
				// result in faster access to these objects
				final CustomKeyedRunnable<K> keyedRunnable = ConcurrentKeyedExecutor.this.keyedRunnable;
				// final AtomicBoolean stopFlag = this.stopFlag;

				while (!stopFlag.get()) {
					try {
						keyedRunnable.run(stopFlag, key, keyDataWaitSemaphore);
					} catch (Throwable th) {
						logger.error("Error in ConcurrentKeyedExecutor worker: " + threadName + ", keyedRunnable: "
								+ keyedRunnable.getClass().getSimpleName() + " : " + th.getMessage(), th);
					}
				}
				logger.info("Exiting worker thread : " + threadName + ", key: " + key);
			} finally {
				keyWorkerThreadListMap.getValue(key).remove(this);
				stopLatch.release(100);
				CommonLogger.STATUS_LOG.info("Exited worker thread : " + threadName + ", key: " + key + ", stopFlag: "
						+ stopFlag.get() + ", shutdownFlag: " + ShutdownHook.isShutdownFlag);
			}
		}

		/**
		 * Wait for start.
		 */
		public void waitForStart() {
			startLatch.acquireUninterruptibly();
		}

		public void waitForStop() {
			stopLatch.acquireUninterruptibly();
		}

		public void stopWorker() {
			stopFlag.set(true);
		}

		public boolean equals(Object obj) {
			if (this == obj) {
				return true;
			}

			if (obj instanceof ConcurrentKeyedExecutor.WorkerThread) {
				return threadName.equals(((ConcurrentKeyedExecutor<?>.WorkerThread) obj).threadName);
			}

			return false;
		}

		@Override
		public int compareTo(WorkerThread other) {
			if (this == other) {
				return 0;
			} else if (other == null) {
				return Integer.MAX_VALUE;
			}
			return threadName.compareTo(other.threadName);
		}
	}
}
