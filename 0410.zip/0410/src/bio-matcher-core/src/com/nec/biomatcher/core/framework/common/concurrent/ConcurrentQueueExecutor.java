package com.nec.biomatcher.core.framework.common.concurrent;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.Semaphore;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.Supplier;

import org.apache.log4j.Logger;
import org.apache.log4j.NDC;

import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.ShutdownHook;

public class ConcurrentQueueExecutor<T> {
	private static final Logger logger = Logger.getLogger(ConcurrentQueueExecutor.class);

	private final ThreadPoolExecutor executorService = new ThreadPoolExecutor(0, Integer.MAX_VALUE, 60L,
			TimeUnit.SECONDS, new SynchronousQueue<Runnable>(), new RejectedHandler());

	private final String name;
	private final BlockingQueue<T> queue;
	private final Consumer<T> consumer;
	private final DynamicSemaphore concurrencySemaphore;
	private final Semaphore startWaitSemaphore = new Semaphore(0);

	public ConcurrentQueueExecutor(String name, BlockingQueue<T> queue, Consumer<T> consumer,
			Supplier<Integer> concurrencySupplier) {
		this.name = name;
		this.queue = queue;
		this.consumer = consumer;
		this.concurrencySemaphore = DynamicSemaphore.getInstance("CQE_Concurrency_" + name, concurrencySupplier);

		CommonTaskScheduler.scheduleWithFixedDelay(new SubmitThread(), 10, 10, TimeUnit.MILLISECONDS);

		CommonLogger.STATUS_LOG.info("In ConcurrentQueueExecutor() for  name: " + name);
	}

	public ConcurrentQueueExecutor(String name, Consumer<T> consumer, Supplier<Integer> concurrencySupplier) {
		this(name, new LinkedBlockingQueue<>(), consumer, concurrencySupplier);
	}

	public void start() {
		startWaitSemaphore.release(10);
	}

	public void addToQueue(T data) {
		if (data != null) {
			queue.add(data);
		}
	}

	public int getQueueSize() {
		return queue.size();
	}

	public int getAvailablePermits() {
		return concurrencySemaphore.availablePermits();
	}

	public int getCurrentExecutionThreadCount() {
		return concurrencySemaphore.acquiredCount();
	}

	private final class SubmitThread implements Runnable {
		@Override
		public void run() {
			try {
				NDC.clear();
				Thread.currentThread().setName("CQE_SUB_" + name + "_" + Thread.currentThread().getId());
				CommonLogger.STATUS_LOG.info("In ConcurrentQueueExecutor.SubmitThread for  name: " + name
						+ ", startWaitSemaphore.availablePermits: " + startWaitSemaphore.availablePermits());

				startWaitSemaphore.acquireUninterruptibly();

				while (!ShutdownHook.isShutdownFlag) {
					try {
						T data = queue.take();

						concurrencySemaphore.acquireUninterruptibly();
						try {
							executorService.execute(new WorkerThread(data));
						} catch (Throwable th) {
							concurrencySemaphore.release();

							// Add it back to queue
							addToQueue(data);

							logger.error("Error while submitting to WorkerThread for name: " + name + " : "
									+ th.getMessage(), th);
						}
					} catch (Throwable th) {
						logger.error(
								"Error while submitting to WorkerThread for name: " + name + " : " + th.getMessage(),
								th);
					}
				}
			} catch (Throwable th) {
				logger.error("Error during WorkerThread.run for name: " + name + " : " + th.getMessage(), th);
			} finally {
				startWaitSemaphore.release();
				CommonLogger.STATUS_LOG.warn("Exiting ConcurrentQueueExecutor.SubmitThread for name: " + name
						+ ", isShutdownFlag: " + ShutdownHook.isShutdownFlag);
			}

		}
	}

	private final class WorkerThread implements Runnable {
		private T data;

		public WorkerThread(T data) {
			this.data = data;
		}

		@Override
		public void run() {
			try {
				Thread.currentThread().setName("CQE_WRK_" + name + "_" + Thread.currentThread().getId());
				do {
					NDC.clear();
					consumer.accept(data);
				} while ((data = queue.poll()) != null);
			} catch (Throwable th) {
				logger.error(
						"Error during WorkerThread.run for name: " + name + ", data: " + data + " : " + th.getMessage(),
						th);
			} finally {
				concurrencySemaphore.release();
			}
		}
	}

	private final class RejectedHandler implements RejectedExecutionHandler {
		@Override
		public void rejectedExecution(Runnable r, ThreadPoolExecutor executor) {
			CommonLogger.STATUS_LOG.error("In ConcurrentQueueExecutor[RejectedHandler.rejectedExecution] for name: "
					+ name + ", isPoolShutdown: " + executor.isShutdown() + ", Runnable: " + r.getClass().getName());

			if (!executor.isShutdown()) {
				try {
					r.run();
				} catch (Throwable th) {
					logger.error("In while run in ConcurrentQueueExecutor[RejectedHandler.rejectedExecution] for name: "
							+ name);
				}
			}
		}
	}
}
