package com.nec.biomatcher.core.framework.common.concurrent;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

import org.apache.log4j.Logger;
import org.jboss.logging.NDC;

import com.google.common.util.concurrent.Uninterruptibles;
import com.nec.biomatcher.core.framework.common.CheckedConsumer;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.ShutdownHook;

public class ConcurrentProducerConsumer<T> {
	private static final Logger logger = Logger.getLogger(ConcurrentProducerConsumer.class);

	private static final ExecutorService cachedExecutorService = CommonTaskScheduler.CACHED_EXECUTORSERVICE;

	private final String name;
	private final Supplier<T> producer;
	private final CheckedConsumer<T> consumer;
	private final Runnable producerThread;
	private final DynamicSemaphore concurrencySemaphore;

	public ConcurrentProducerConsumer(String name, Supplier<T> producer, CheckedConsumer<T> consumer,
			Supplier<Integer> concurrencyCountSupplier) {
		CommonLogger.STATUS_LOG.info("In ConcurrentProducerConsumer() for  name: " + name);

		this.name = name;
		this.producer = producer;
		this.consumer = consumer;
		this.producerThread = () -> {
			submitToWorker();
		};
		this.concurrencySemaphore = DynamicSemaphore.getInstance(name, concurrencyCountSupplier);

		CommonTaskScheduler.scheduleWithFixedDelay(producerThread, 100, 500, TimeUnit.MILLISECONDS);
	}

	private final void submitToWorker() {
		Thread.currentThread().setName("CPC_SUB_" + name + "_" + Thread.currentThread().getId());
		CommonLogger.STATUS_LOG.info("In ConcurrentProducerConsumer.submitToWorker for  name: " + name);

		while (!ShutdownHook.isShutdownFlag) {
			try {
				T value = producer.get();

				concurrencySemaphore.acquireUninterruptibly();
				try {
					cachedExecutorService.execute(new WorkerThread(value));
				} catch (Throwable th) {
					concurrencySemaphore.release();
					logger.error("Error while submitting in submitToWorker for name: " + name + ", value: " + value
							+ " : " + th.getMessage(), th);
					Uninterruptibles.sleepUninterruptibly(500, TimeUnit.MILLISECONDS);
				}
			} catch (Throwable th) {
				logger.error("Error during producer.get in submitToWorker for name: " + name + " : " + th.getMessage(),
						th);
				Uninterruptibles.sleepUninterruptibly(500, TimeUnit.MILLISECONDS);
			}
		}
		CommonLogger.STATUS_LOG.warn("Exiting ConcurrentProducerConsumer.submitToWorker for name: " + name);
	}

	private class WorkerThread implements Runnable {
		private T value;

		public WorkerThread(T value) {
			this.value = value;
		}

		public void run() {
			try {
				Thread.currentThread().setName("CPC_WRK_" + name + "_" + Thread.currentThread().getId());

				NDC.clear();

				consumer.accept(value);
			} catch (Throwable th) {
				logger.error("Error during WorkerThread.run for name: " + name + ", value: " + value + " : "
						+ th.getMessage(), th);
			} finally {
				concurrencySemaphore.release();
			}
		}
	}

}
