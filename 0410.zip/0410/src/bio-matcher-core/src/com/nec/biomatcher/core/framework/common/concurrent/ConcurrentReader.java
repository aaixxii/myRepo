package com.nec.biomatcher.core.framework.common.concurrent;

import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.function.Supplier;

public class ConcurrentReader<T> {
	private final Supplier<T> resourceValueSupplier;

	private final AtomicReference<T> valueRef = new AtomicReference<>();

	private final Semaphore waitSemaphore = new Semaphore(0);

	private final ReadWriteLock rwLock = new ReentrantReadWriteLock();
	private final Lock readLock = rwLock.readLock();
	private final Lock writeLock = rwLock.writeLock();

	private final long valueExpiryMilli;
	private volatile long valueTimestampMilli;

	public ConcurrentReader(Supplier<T> resourceValueSupplier) {
		this.resourceValueSupplier = resourceValueSupplier;
		this.valueExpiryMilli = 2;
	}

	public ConcurrentReader(Supplier<T> resourceValueSupplier, long valueExpiryMilli) {
		this.resourceValueSupplier = resourceValueSupplier;
		this.valueExpiryMilli = valueExpiryMilli;
	}

	public final void update(T value) {
		if (writeLock.tryLock()) {
			try {
				valueRef.set(value);
				valueTimestampMilli = System.currentTimeMillis();
			} finally {
				waitSemaphore.release(waitSemaphore.getQueueLength() + 20);
				writeLock.unlock();
			}
		}
	}

	public final T get() {
		if (writeLock.tryLock()) {
			try {
				waitSemaphore.drainPermits();
				T value = resourceValueSupplier.get();
				valueRef.set(value);
				valueTimestampMilli = System.currentTimeMillis();
				return value;
			} finally {
				waitSemaphore.release(waitSemaphore.getQueueLength() + 20);
				writeLock.unlock();
			}
		} else {
			T refValue = valueRef.get();
			if (refValue != null && valueExpiryMilli >= (System.currentTimeMillis() - valueTimestampMilli)) {
				return refValue;
			}

			waitSemaphore.acquireUninterruptibly();
			refValue = valueRef.get();
			if (refValue != null) {
				return refValue;
			}

			readLock.lock();
			try {
				return valueRef.get();
			} finally {
				readLock.unlock();
			}
		}
	}

	/*
	 * private final ResettableCountDownLatch countDownLatch = new
	 * ResettableCountDownLatch(1); public final T getUsingCountDown() {
	 * if(writeLock.tryLock()) { try { countDownLatch.reset();
	 * 
	 * T value = resourceValueSupplier.get(); valueRef.set(value);
	 * countDownLatch.countDown();
	 * 
	 * return value; } finally { writeLock.unlock(); } } else { try {
	 * countDownLatch.await(); } catch(Throwable th) {
	 * CommonLogger.APP_LOG.error("Error in ConcurrentReader.get: "+th.
	 * getMessage(), th); return resourceValueSupplier.get(); }
	 * 
	 * return valueRef.get(); } }
	 */
}
