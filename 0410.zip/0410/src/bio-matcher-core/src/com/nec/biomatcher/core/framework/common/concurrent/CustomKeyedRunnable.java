package com.nec.biomatcher.core.framework.common.concurrent;

import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicBoolean;

public interface CustomKeyedRunnable<K> {
	public void run(AtomicBoolean stopFlag, K key, Semaphore waitSemaphore);

}
