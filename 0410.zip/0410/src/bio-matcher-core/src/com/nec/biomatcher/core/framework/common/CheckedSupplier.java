package com.nec.biomatcher.core.framework.common;

@FunctionalInterface
public interface CheckedSupplier<T> {

	T get() throws Throwable;
}
