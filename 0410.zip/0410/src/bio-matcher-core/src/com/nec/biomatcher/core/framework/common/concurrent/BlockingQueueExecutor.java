package com.nec.biomatcher.core.framework.common.concurrent;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.Supplier;

import org.apache.log4j.Logger;
import org.apache.log4j.NDC;

import com.google.common.util.concurrent.Uninterruptibles;
import com.nec.biomatcher.core.framework.common.BiKey;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.ShutdownHook;

public class BlockingQueueExecutor<T> {
	private static final Logger logger = Logger.getLogger(BlockingQueueExecutor.class);

	private static final ExecutorService cachedExecutorService = CommonTaskScheduler.CACHED_EXECUTORSERVICE;

	private final BlockingQueue<T> blockingQueue;
	private final String name;
	private final String key;
	private final DynamicSemaphore concurrencySemaphore;
	private final int batchSize;

	private final Consumer<T> consumer;
	private final Consumer<Collection<T>> batchConsumer;
	private final Consumer<BiKey<String, T>> keyedConsumer;
	private final Consumer<BiKey<String, Collection<T>>> keyedBatchConsumer;

	public BlockingQueueExecutor(String name, Consumer<T> consumer, Supplier<Integer> concurrencyCountSupplier) {
		this.name = name;
		this.key = null;
		this.concurrencySemaphore = DynamicSemaphore.getInstance(name, concurrencyCountSupplier);
		this.blockingQueue = new LinkedBlockingQueue<>();
		this.batchSize = 1;

		this.consumer = consumer;
		this.batchConsumer = null;
		this.keyedConsumer = null;
		this.keyedBatchConsumer = null;

		CommonTaskScheduler.scheduleWithFixedDelay(new SubmitThread(), 5, 500, TimeUnit.MILLISECONDS);
	}

	public BlockingQueueExecutor(String name, Consumer<Collection<T>> batchConsumer, int batchSize,
			Supplier<Integer> concurrencyCountSupplier) {
		this.name = name;
		this.key = null;
		this.concurrencySemaphore = DynamicSemaphore.getInstance(name, concurrencyCountSupplier);
		this.blockingQueue = new LinkedBlockingQueue<>();
		this.batchSize = batchSize;

		this.consumer = null;
		this.batchConsumer = batchConsumer;
		this.keyedConsumer = null;
		this.keyedBatchConsumer = null;

		CommonTaskScheduler.scheduleWithFixedDelay(new SubmitThread(), 5, 500, TimeUnit.MILLISECONDS);
	}

	public BlockingQueueExecutor(String name, String key, Consumer<BiKey<String, T>> keyedConsumer,
			Supplier<Integer> concurrencyCountSupplier) {
		this.name = name;
		this.key = key;
		this.concurrencySemaphore = DynamicSemaphore.getInstance(name, concurrencyCountSupplier);
		this.blockingQueue = new LinkedBlockingQueue<>();
		this.batchSize = 1;

		this.consumer = null;
		this.batchConsumer = null;
		this.keyedConsumer = keyedConsumer;
		this.keyedBatchConsumer = null;

		CommonTaskScheduler.scheduleWithFixedDelay(new SubmitThread(), 5, 500, TimeUnit.MILLISECONDS);
	}

	public BlockingQueueExecutor(String name, String key, Consumer<BiKey<String, Collection<T>>> keyedBatchConsumer,
			int batchSize, Supplier<Integer> concurrencyCountSupplier) {
		this.name = name;
		this.key = key;
		this.concurrencySemaphore = DynamicSemaphore.getInstance(name, concurrencyCountSupplier);
		this.blockingQueue = new LinkedBlockingQueue<>();
		this.batchSize = batchSize;

		this.consumer = null;
		this.batchConsumer = null;
		this.keyedConsumer = null;
		this.keyedBatchConsumer = keyedBatchConsumer;

		CommonTaskScheduler.scheduleWithFixedDelay(new SubmitThread(), 5, 500, TimeUnit.MILLISECONDS);
	}

	public void addToQueue(T value) {
		blockingQueue.add(value);
	}

	private class SubmitThread implements Runnable {

		public void run() {
			try {
				NDC.clear();
				Thread.currentThread().setName("BQE_SUB_" + name + "_" + Thread.currentThread().getId());
				logger.info("In BlockingQueueExecutor.submitToWorker for  name: " + name);

				while (!ShutdownHook.isShutdownFlag) {
					try {
						concurrencySemaphore.acquireUninterruptibly();
						try {
							if (consumer != null || keyedConsumer != null) {
								T value = blockingQueue.take();
								cachedExecutorService.execute(new WorkerThread(value));
							} else {
								T value = blockingQueue.take();
								List<T> valueList = new ArrayList<>();
								valueList.add(value);

								while (valueList.size() < batchSize && (value = blockingQueue.poll()) != null) {
									valueList.add(value);
								}
								cachedExecutorService.execute(new WorkerThread(valueList));
							}
						} catch (Throwable th) {
							concurrencySemaphore.release();
							logger.error("Error while submitting in submitToWorker for name: " + name + " : "
									+ th.getMessage(), th);
							Uninterruptibles.sleepUninterruptibly(500, TimeUnit.MILLISECONDS);
						}
					} catch (Throwable th) {
						logger.error("Error during producer.get in submitToWorker for name: " + name + " : "
								+ th.getMessage(), th);
						Uninterruptibles.sleepUninterruptibly(500, TimeUnit.MILLISECONDS);
					}
				}
				CommonLogger.STATUS_LOG.warn("Exiting BlockingQueueExecutor.submitToWorker for name: " + name);
			} catch (Throwable th) {
				logger.error("Error during WorkerThread.run for name: " + name + " : " + th.getMessage(), th);
			} finally {
				concurrencySemaphore.release();
			}
		}
	}

	private class WorkerThread implements Runnable {
		private T value;
		private List<T> valueList;

		public WorkerThread(T value) {
			this.value = value;
		}

		public WorkerThread(List<T> valueList) {
			this.valueList = valueList;
		}

		public void run() {
			try {
				Thread.currentThread().setName("BQE_WRK_" + name + "_" + Thread.currentThread().getId());
				NDC.clear();
				if (key == null) {
					if (consumer != null) {
						consumer.accept(value);
					} else {
						batchConsumer.accept(valueList);
					}
				} else {
					if (keyedConsumer != null) {
						keyedConsumer.accept(new BiKey<>(key, value));
					} else {
						keyedBatchConsumer.accept(new BiKey<>(key, valueList));
					}
				}
			} catch (Throwable th) {
				logger.error("Error during WorkerThread.run for name: " + name + ", value: " + value + " : "
						+ th.getMessage(), th);
			} finally {
				concurrencySemaphore.release();
			}
		}
	}

}
