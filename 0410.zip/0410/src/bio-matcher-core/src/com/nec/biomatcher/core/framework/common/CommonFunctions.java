package com.nec.biomatcher.core.framework.common;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;

public class CommonFunctions {
	public static final Function<String, List<String>> STRING_TO_LIST = (p) -> StringUtil.stringToList(p, ",");

	public static final Function<String, Set<String>> STRING_TO_SET = (p) -> StringUtil.stringToSet(p, ",");

	public static final Function<String, Map<String, String>> STRING_TO_MAP = (p) -> StringUtil.stringToMap(p, "=",
			",");

	public static final Function<?, AtomicInteger> NEW_ATOMICINTEGER_INSTANCE = (p) -> new AtomicInteger(0);
}
