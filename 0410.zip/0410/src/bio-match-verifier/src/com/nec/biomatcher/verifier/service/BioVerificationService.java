package com.nec.biomatcher.verifier.service;

import com.nec.biomatcher.comp.cluster.JobSlotClusterService;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeClientException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeConnectionException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeReceiveException;
import com.nec.biomatcher.comp.matcher.node.exception.BioMatcherNodeSendException;
import com.nec.biomatcher.verifier.service.exception.BioVerificationTimeoutException;
import com.nec.biomatcher.verifier.util.VerifyJobInfo;

/**
 * The Interface BioVerificationService.
 */
public interface BioVerificationService {

	public String getVerificationControllerId();

	public JobSlotClusterService getVerifyClusterService();

	public void submitVerificationJob(String verifyJobId, VerifyJobInfo verifyJobInfo)
			throws BioMatcherNodeClientException, BioMatcherNodeConnectionException, BioMatcherNodeSendException,
			BioMatcherNodeReceiveException, BioVerificationTimeoutException;
	
	public void notifyVerifyJobCanceling(String msg);

}
