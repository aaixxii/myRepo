package com.nec.biomatcher.verifier.service.exception;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

/**
 * The Class BioVerificationException.
 */
public class BioVerificationException extends CoreException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new bio verification exception.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public BioVerificationException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new bio verification exception.
	 *
	 * @param message
	 *            the message
	 */
	public BioVerificationException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new bio verification exception.
	 *
	 * @param errorCode
	 *            the error code
	 * @param message
	 *            the message
	 */
	public BioVerificationException(String errorCode, String message) {
		super(errorCode, message);
	}

	/**
	 * Instantiates a new bio verification exception.
	 *
	 * @param cause
	 *            the cause
	 */
	public BioVerificationException(Throwable cause) {
		super(cause);
	}

}
