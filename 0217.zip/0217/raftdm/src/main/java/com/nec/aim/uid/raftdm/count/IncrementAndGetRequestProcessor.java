package com.nec.aim.uid.raftdm.count;

import java.nio.ByteBuffer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alipay.remoting.AsyncContext;
import com.alipay.remoting.BizContext;
import com.alipay.remoting.exception.CodecException;
import com.alipay.remoting.rpc.protocol.AsyncUserProcessor;
import com.alipay.sofa.jraft.Closure;
import com.alipay.sofa.jraft.Status;
import com.alipay.sofa.jraft.entity.Task;
import com.nec.aim.uid.raftdm.count.HessianSerializer;

public class IncrementAndGetRequestProcessor extends AsyncUserProcessor<IncrementAndGetRequest> {
    private static final Logger LOG = LoggerFactory.getLogger(IncrementAndGetRequestProcessor.class);

    private CounterServer       counterServer;

    public IncrementAndGetRequestProcessor(CounterServer counterServer) {
        super();
        this.counterServer = counterServer;
    }

    @Override
    public void handleRequest(BizContext bizCtx, AsyncContext asyncCtx, IncrementAndGetRequest request) {
        if (!counterServer.getFsm().isLeader()) {
            asyncCtx.sendResponse(counterServer.redirect());
            return;
        }

        // 构建应答回调
        ValueResponse response = new ValueResponse();
        IncrementAndAddClosure closure = new IncrementAndAddClosure(counterServer, request, response, new Closure() {

            @Override
            public void run(Status status) {
                // 提交后处理
                if (!status.isOk()) {
                    // 提交失败，返回错误信息
                    response.setErrorMsg(status.getErrorMsg());
                    response.setSuccess(false);
                }
                // 成功，返回ValueResponse应答
                asyncCtx.sendResponse(response);

            }
        });

        try {
            // 构建提交任务
            Task task = new Task();
            task.setDone(closure); // 设置回调
            // 填充数据，将请求用 hessian２序列化到 data　字段          
            task.setData(ByteBuffer.wrap(HessianSerializer.marshal(request)));

            // 提交到 raft group
            counterServer.getNode().apply(task);
        } catch (CodecException e) {
            // 处理序列化异常
            LOG.error("Fail to encode IncrementAndGetRequest", e);
            ValueResponse responseObject = response;
            responseObject.setSuccess(false);
            responseObject.setErrorMsg(e.getMessage());
            asyncCtx.sendResponse(responseObject);
        }
    }

    @Override
    public String interest() {
        return IncrementAndGetRequest.class.getName();
    }

}
