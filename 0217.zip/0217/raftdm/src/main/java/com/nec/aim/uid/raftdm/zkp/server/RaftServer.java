package com.nec.aim.uid.raftdm.zkp.server;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;

import com.alipay.remoting.rpc.RpcServer;
import com.alipay.sofa.jraft.Node;
import com.alipay.sofa.jraft.RaftGroupService;
import com.alipay.sofa.jraft.conf.Configuration;
import com.alipay.sofa.jraft.entity.PeerId;

import com.alipay.sofa.jraft.option.NodeOptions;
import com.alipay.sofa.jraft.rpc.RaftRpcServerFactory;
import com.nec.aim.uid.raftdm.count.CounterStateMachine;

import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncResponce;

public class RaftServer {   
    private RaftGroupService    raftGroupService;
    
    private Node                node;    
    private CounterStateMachine fsm;

    public RaftServer(String dataPath, String groupId, PeerId serverId, NodeOptions nodeOptions) throws IOException {        
        FileUtils.forceMkdir(new File(dataPath));      
        RpcServer rpcServer = new RpcServer(serverId.getPort());
        RaftRpcServerFactory.addRaftRequestProcessors(rpcServer);        
        rpcServer.registerUserProcessor(new DmSyncRequestProcessor(this));
        //rpcServer.registerUserProcessor(new IncrementAndGetRequestProcessor(this));       
        this.fsm = new CounterStateMachine();        
        nodeOptions.setFsm(this.fsm);        
        nodeOptions.setLogUri(dataPath + File.separator + "log");       
        nodeOptions.setRaftMetaUri(dataPath + File.separator + "raft_meta");        
        nodeOptions.setSnapshotUri(dataPath + File.separator + "snapshot");       
        this.raftGroupService = new RaftGroupService(groupId, serverId, nodeOptions, rpcServer);        
        this.node = this.raftGroupService.start();
    }

    public CounterStateMachine getFsm() {
        return this.fsm;
    }

    public Node getNode() {
        return this.node;
    }

    public RaftGroupService RaftGroupService() {
        return this.raftGroupService;
    }
    
    public PBDmSyncResponce redirect() {
    	PBDmSyncResponce.Builder response = PBDmSyncResponce.newBuilder();
        response.setSuccess(false);
        if (node != null) {
            PeerId leader = node.getLeaderId();
            if (leader != null) {
                //response.setRedirect(leader.toString());
            }
        }

        return response.build();
    }

    public static void main(String[] args) throws IOException {
        if (args.length != 4) {
            System.out
                .println("Useage : java com.alipay.jraft.example.counter.CounterServer {dataPath} {groupId} {serverId} {initConf}");
            System.out
                .println("Example: java com.alipay.jraft.example.counter.CounterServer /tmp/server1 counter 127.0.0.1:8081 127.0.0.1:8081,127.0.0.1:8082,127.0.0.1:8083");
            System.exit(1);
        }
        String dataPath = args[0];
        String groupId = args[1];
        String serverIdStr = args[2];
        String initConfStr = args[3];

        NodeOptions nodeOptions = new NodeOptions();        
        nodeOptions.setElectionTimeoutMs(5000);
        nodeOptions.setDisableCli(false);
        nodeOptions.setSnapshotIntervalSecs(30);       
        PeerId serverId = new PeerId();
        if (!serverId.parse(serverIdStr)) {
            throw new IllegalArgumentException("Fail to parse serverId:" + serverIdStr);
        }
        Configuration initConf = new Configuration();
        if (!initConf.parse(initConfStr)) {
            throw new IllegalArgumentException("Fail to parse initConf:" + initConfStr);
        }      
        nodeOptions.setInitialConf(initConf);
       
        RaftServer zkpServer = new RaftServer(dataPath, groupId, serverId, nodeOptions);
        System.out.println("Started counter server at port:"
                           + zkpServer.getNode().getNodeId().getPeerId().getPort());
    }
}