package com.nec.aim.uid.raftdm.exception;

/**
 * The Class SerializationException.
 */
public class SerializationException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new serialization exception.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public SerializationException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new serialization exception.
	 *
	 * @param message
	 *            the message
	 */
	public SerializationException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new serialization exception.
	 *
	 * @param cause
	 *            the cause
	 */
	public SerializationException(Throwable cause) {
		super(cause);
	}

}
