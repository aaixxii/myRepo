package com.nec.aim.uid.zkpdm.curator;

import java.nio.charset.Charset;
import java.util.List;
import java.util.Objects;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.curator.RetryPolicy;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.framework.recipes.cache.ChildData;
import org.apache.curator.framework.recipes.cache.PathChildrenCache;
import org.apache.curator.framework.recipes.cache.PathChildrenCacheListener;
import org.apache.curator.framework.state.ConnectionState;
import org.apache.curator.retry.ExponentialBackoffRetry;
import org.apache.curator.utils.CloseableUtils;
import org.apache.curator.utils.ZKPaths;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.data.Stat;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.nec.aim.uid.zkpdm.exception.CuratorClientException;
import com.nec.aim.uid.zkpdm.segmenter.SegmentInfo;
import com.nec.aim.uid.zkpdm.segmenter.SegmentManager;
import com.nec.aim.uid.zkpdm.segmenter.SegmentOperater;

import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Component
@Scope("singleton")
@Slf4j
@Data
public class CuratorPathCacher {
	
	private CuratorFramework client;
	private PathChildrenCache pathChildrenCache;	
	
	@Value("${zookeeper.connection.string}")
	private String zkpConnString;

	@Value("${segments.root.dir}")
	private String segmentRootDir;	
	
	private static final String CHARSET = "utf8";

	@PostConstruct
	public void setup() {
		RetryPolicy retryPolicy = new ExponentialBackoffRetry(1000, 3);
		client = CuratorFrameworkFactory
				.builder()
				.connectString(zkpConnString)
				.sessionTimeoutMs(5000)
				.connectionTimeoutMs(5000)
				.retryPolicy(retryPolicy)
				.namespace(segmentRootDir).build();
		client.start();
		client.getConnectionStateListenable().addListener((client, state) -> {
			if (state == ConnectionState.LOST) {
				log.info("lost session with zookeeper");
			} else if (state == ConnectionState.CONNECTED) {
				log.info("Success to connected with zookeeper");
			} else if (state == ConnectionState.RECONNECTED) {
				log.info("reconnected with zookeeper");
			}
		});		
		
	}
	
	public void init(long segmentId) throws Exception {
		client
		.create()
		.creatingParentsIfNeeded()
		.withMode(CreateMode.PERSISTENT_SEQUENTIAL)
		.forPath(String.valueOf(segmentId));		
		pathChildrenCache = new PathChildrenCache(client, String.valueOf(segmentId), true);
		pathChildrenCache.start();
		 PathChildrenCacheListener listener = (client, event) -> {			
	            switch (event.getType())  { 	           
                case CHILD_ADDED:
                case CHILD_UPDATED:
                    System.out.println("Node added: " + ZKPaths.getNodeFromPath(event.getData().getPath()));
                    String nodeName = event.getData().getPath();
  	    		    byte[] nodeData = event.getData().getData();
  	    		    Stat nodeStatus = event.getData().getStat();   	    		  
  	    		    if (!nodeName.equals(String.valueOf(segmentId)) || Objects.isNull(nodeData)) {
  	    		    	log.warn("");
  	    		    	//ToDo
  	    		    }
  	    		  PBDmSyncRequest dmSegReq = PBDmSyncRequest.parseFrom(nodeData);
  	    			SegmentInfo segInfo = SegmentManager.getSegmentInfo(Long.valueOf(segmentId));
  	    			SegmentOperater segOprater = null;
  	    			if (Objects.isNull(segInfo)) {
  	    				segInfo = new SegmentInfo(segmentId);
  	    				 segOprater = SegmentOperater.getInstance();
  	    				segOprater.init(segmentRootDir, segmentId);
  	    				segInfo.setSegOperater(segOprater);  	    				
  	    			} else {
  	    				segOprater = segInfo.getSegOperater();  	    				
  	    			}
  	    			boolean successed = segOprater.handerRequest(dmSegReq); 
  	    			if (successed) {
  	    				deleteNodeAfterSuccess(String.valueOf(segmentId));
  	    			}
                    break; 
                case CHILD_REMOVED:                   
                    System.out.println("Node removed: " + ZKPaths.getNodeFromPath(event.getData().getPath()));
                    break;
				default:
					break;
            }
			 
		 };
		 
		pathChildrenCache.getListenable().addListener(listener);
	}
  
	@PreDestroy
	public void stop() {
		CloseableUtils.closeQuietly(pathChildrenCache);
		CloseableUtils.closeQuietly(client);
	}

	@SuppressWarnings("unused")
	private static void list(PathChildrenCache cache) {
		if (cache.getCurrentData().size() == 0) {
			System.out.println("* empty *");
		} else {
			for (ChildData data : cache.getCurrentData()) {
				System.out.println(data.getPath() + " = " + new String(data.getData()));
			}
		}
	}
	
	public boolean createNode(CreateMode mode, String path, byte[] nodeData) {
		try {
			client.create().creatingParentsIfNeeded().withMode(mode).forPath(path, nodeData);
			return true;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return false;
		}
	}

	public boolean deleteNode(final String path) {
		try {
			deleteNode(path, false);
			return true;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return false;
		}
	}

	public void deleteNode(final String path, Boolean deleteChildre) {
		try {
			if (deleteChildre) {

				client.delete().guaranteed().deletingChildrenIfNeeded().forPath(path);
			} else {
				client.delete().guaranteed().forPath(path);
			}
		} catch (Exception e) {
			throw new CuratorClientException("Faild to delete node", e);
		}
	}

	public void setNodeData(String path, String data) {
		try {
			client.setData().forPath(path, data.getBytes(Charset.forName(CHARSET)));
		} catch (Exception ex) {
			throw new CuratorClientException("Faild to delete node", ex);
		}
	}

	public String getNodeData(String path) {
		try {
			return new String(client.getData().forPath(path), Charset.forName(CHARSET));
		} catch (Exception e) {
			throw new CuratorClientException("Faild to get nodeData", e);
		}
	}

	public String synNodeData(String path) {
		client.sync();
		return getNodeData(path);
	}

	public boolean isExistNode(final String path) {
		client.sync();
		try {
			return null != client.checkExists().forPath(path);
		} catch (Exception e) {
			return false;
		}
	}

	public List<String> getChildren(String path) {
		List<String> childrenList;
		try {
			childrenList = client.getChildren().forPath(path);
		} catch (Exception e) {
			throw new CuratorClientException("Faild to get nodeData", e);
		}
		return childrenList;
	}	
	
	private boolean deleteNodeAfterSuccess(final String path) {
		try {
			deleteNode(path, false);
			return true;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return false;
		}
		
	}
	
//	public PathChildrenCache(CuratorFramework client, String path, boolean cacheData)
//	public PathChildrenCache(CuratorFramework client, String path, boolean cacheData, boolean dataIsCompressed, final CloseableExecutorService executorService)
//	public PathChildrenCache(CuratorFramework client, String path, boolean cacheData, boolean dataIsCompressed, final ExecutorService executorService)
//	public PathChildrenCache(CuratorFramework client, String path, boolean cacheData, boolean dataIsCompressed, ThreadFactory threadFactory)
//	public PathChildrenCache(CuratorFramework client, String path, boolean cacheData, ThreadFactory threadFactory)
//	
	
}
