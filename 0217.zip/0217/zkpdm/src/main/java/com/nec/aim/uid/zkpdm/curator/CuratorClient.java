package com.nec.aim.uid.zkpdm.curator;

import java.nio.charset.Charset;
import java.util.List;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.curator.RetryPolicy;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.framework.recipes.cache.TreeCache;
import org.apache.curator.framework.recipes.cache.TreeCacheListener;
import org.apache.curator.framework.recipes.locks.InterProcessLock;
import org.apache.curator.framework.recipes.locks.InterProcessMultiLock;
import org.apache.curator.framework.recipes.locks.InterProcessMutex;
import org.apache.curator.framework.recipes.locks.InterProcessReadWriteLock;
import org.apache.curator.framework.recipes.locks.InterProcessSemaphoreMutex;
import org.apache.curator.framework.state.ConnectionState;
import org.apache.curator.retry.ExponentialBackoffRetry;
import org.apache.curator.utils.CloseableUtils;
import org.apache.curator.x.async.AsyncCuratorFramework;
import org.apache.curator.x.async.AsyncEventException;
import org.apache.curator.x.async.WatchMode;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.WatchedEvent;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.nec.aim.uid.zkpdm.exception.CuratorClientException;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Component
@Scope("singleton")
@Slf4j
@Data
public class CuratorClient {	
	private CuratorFramework CLIENT;	
	private AsyncCuratorFramework ASYNC_CLIENT;
	private static final String CHARSET = "utf8";
	
	@Value("${zookeeper.connection.string}")
    private String zkpConnString;
	
	 @Value("${segments.root.dir}")
	    private String segmentRootDir;
	
	@PostConstruct
	public void init() {
		RetryPolicy retryPolicy = new ExponentialBackoffRetry(1000, 3);
		CLIENT = CuratorFrameworkFactory
				.builder()
				.connectString(zkpConnString)
				.sessionTimeoutMs(5000)
				.connectionTimeoutMs(5000)
				.retryPolicy(retryPolicy)
				.namespace(segmentRootDir).build();
		CLIENT.start();
		CLIENT.getConnectionStateListenable().addListener((CLIENT, state) -> {
			if (state == ConnectionState.LOST) {
				log.info("lost session with zookeeper");
			} else if (state == ConnectionState.CONNECTED) {
				log.info("Success to connected with zookeeper");
			} else if (state == ConnectionState.RECONNECTED) {
				log.info("reconnected with zookeeper");
			}
		});
		
		ASYNC_CLIENT = AsyncCuratorFramework.wrap(CLIENT);
	}
 
	@PreDestroy
	public void stop() {		
		CloseableUtils.closeQuietly(CLIENT);		
	}

	public void createNode(CreateMode mode, String path, String nodeData) {
		try {
			CLIENT.create().creatingParentsIfNeeded().withMode(mode).forPath(path,
					nodeData.getBytes(Charset.forName(CHARSET)));
		} catch (Exception e) {
			throw new CuratorClientException("Faild to create node", e);
		}
	}

	public void deleteNode(final String path) {
		try {
			deleteNode(path, true);
		} catch (Exception e) {
			throw new CuratorClientException("Faild to delete node", e);
		}
	}

	public void deleteNode(final String path, Boolean deleteChildre) {
		try {
			if (deleteChildre) {

				CLIENT.delete().guaranteed().deletingChildrenIfNeeded().forPath(path);
			} else {
				CLIENT.delete().guaranteed().forPath(path);
			}
		} catch (Exception e) {
			throw new CuratorClientException("Faild to delete node", e);
		}
	}

	public void setNodeData(String path, String data) {
		try {
			CLIENT.setData().forPath(path, data.getBytes(Charset.forName(CHARSET)));
		} catch (Exception ex) {
			throw new CuratorClientException("Faild to delete node", ex);
		}
	}

	public String getNodeData(String path) {
		try {
			return new String(CLIENT.getData().forPath(path), Charset.forName(CHARSET));
		} catch (Exception e) {
			throw new CuratorClientException("Faild to get nodeData", e);
		}
	}

	public String synNodeData(String path) {
		CLIENT.sync();
		return getNodeData(path);
	}

	public boolean isExistNode(final String path) {
		CLIENT.sync();
		try {
			return null != CLIENT.checkExists().forPath(path);
		} catch (Exception e) {
			return false;
		}
	}

	public List<String> getChildren(String path) {
		List<String> childrenList;
		try {
			childrenList = CLIENT.getChildren().forPath(path);
		} catch (Exception e) {
			throw new CuratorClientException("Faild to get nodeData", e);
		}
		return childrenList;
	}

	public InterProcessSemaphoreMutex getSemaphoreMutexLock(String path) {
		return new InterProcessSemaphoreMutex(CLIENT, path);
	}

	public InterProcessMutex getMutexLock(String path) {
		return new InterProcessMutex(CLIENT, path);
	}

	public InterProcessMultiLock getMultiMutexLock(List<String> paths) {
		return new InterProcessMultiLock(CLIENT, paths);
	}

	public InterProcessMultiLock getMultiLock(List<InterProcessLock> locks) {
		return new InterProcessMultiLock(locks);
	}

	public void acquire(InterProcessLock lock) {
		try {
			lock.acquire();
		} catch (Exception e) {
			throw new CuratorClientException(e.getMessage(), e);
		}
	}

	public void acquire(InterProcessLock lock, long time, TimeUnit unit) {
		try {
			lock.acquire(time, unit);
		} catch (Exception e) {
			throw new CuratorClientException(e.getMessage(), e);
		}
	}

	public void release(InterProcessLock lock) {
		try {
			lock.release();
		} catch (Exception e) {
			throw new CuratorClientException(e.getMessage(), e);
		}
	}

	public boolean isAcquiredInThisProcess(InterProcessLock lock) {
		return lock.isAcquiredInThisProcess();
	}

	public InterProcessReadWriteLock getReadWriteLock(String path) {
		return new InterProcessReadWriteLock(CLIENT, path);
	}

	public TreeCache watch(String path, TreeCacheListener listener, Executor pool) {
		TreeCache cache = new TreeCache(CLIENT, path);
		cache.getListenable().addListener(listener, pool);
		try {
			cache.start();
		} catch (Exception e) {
			throw new CuratorClientException(e.getMessage(), e);
		}
		return cache;
	}

	public TreeCache watch(String path, TreeCacheListener listener) {
		TreeCache cache = new TreeCache(CLIENT, path);
		cache.getListenable().addListener(listener);
		try {
			cache.start();
		} catch (Exception e) {
			throw new CuratorClientException(e.getMessage(), e);
		}
		return cache;
	}

	public void unwatch(TreeCache cache, TreeCacheListener listener) {
		if (cache == null) {
			throw new CuratorClientException("TreeCache can't be null");
		}
		cache.getListenable().removeListener(listener);
	}
	
	public void create(String path, byte[] payload) {		
		ASYNC_CLIENT.create().forPath(path, payload).whenComplete((name, exception) -> {
			if (exception != null) {
				log.error(exception.getMessage(), exception);
			} else {
				log.info("Created node name is: " + name);
				// Todo
			}
		});
	}

	public void createThenWatch(String path) {		
		ASYNC_CLIENT.create().forPath(path).whenComplete((name, exception) -> {
			if (exception != null) {
				log.error(exception.getMessage(), exception);
			} else {
				handleWatchedStage(ASYNC_CLIENT.watched().checkExists().forPath(path).event());
			}
		});
	}

	public void createThenWatchSimple(CuratorFramework client, String path) {		
		ASYNC_CLIENT.create().forPath(path).whenComplete((name, exception) -> {
			if (exception != null) {
				log.error(exception.getMessage(), exception);
			} else {
				ASYNC_CLIENT.with(WatchMode.successOnly).watched().checkExists().forPath(path).event().thenAccept(event -> {
					System.out.println(event.getType());
					System.out.println(event);
				});
			}
		});
	}
	
	private void handleWatchedStage(CompletionStage<WatchedEvent> watchedStage) {
		watchedStage.thenAccept(event -> {
			System.out.println(event.getType());
			System.out.println(event);
			// todo
		});

		watchedStage.exceptionally(exception -> {
			AsyncEventException asyncEx = (AsyncEventException) exception;
			asyncEx.printStackTrace(); // handle the error as needed
			handleWatchedStage(asyncEx.reset());
			return null;
		});
	}

}
