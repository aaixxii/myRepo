package com.nec.aim.dm.dmservice.dispatch;

import java.sql.SQLException;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import com.nec.aim.dm.dmservice.entity.SegBioNsmUrl;
import com.nec.aim.dm.dmservice.exception.DmServiceException;
import com.nec.aim.dm.dmservice.persistence.SegmentLoadRepository;
import com.nec.aim.dm.dmservice.persistence.SegmentRefenceStorageRepository;
import com.nec.aim.dm.dmservice.post.HttpPoster;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DmTemplateService {
	
	@Autowired
	SegmentLoadRepository segmentLoadRepository;
	
	@Autowired
	SegmentRefenceStorageRepository segRefStorageRepository;
	
	@Transactional(isolation = Isolation.READ_COMMITTED)
	public byte[] getTemplateFromNodeStorage(String refId) throws SQLException, InterruptedException, ExecutionException {
		final StopWatch t = new StopWatch();
		t.start();
		List<SegBioNsmUrl> infoForGetTemplte = segRefStorageRepository.getInfoForGetTemplate(refId);
		if (infoForGetTemplte == null || infoForGetTemplte.size() < 1) {
			throw new DmServiceException("No dm stroage node hoding externalId:" + refId);
		}
		Collections.shuffle(infoForGetTemplte);
		SegBioNsmUrl postInfo = infoForGetTemplte.get(0);
		String postUrl = postInfo.getUrl();
		postUrl = postUrl.endsWith("/") ? postUrl: postUrl + "/";
		postUrl = postUrl + "gettemplate/?segmentid="+ postInfo.getSegmentId() + "&bioid=" + postInfo.getBioId();
		byte[] result = HttpPoster.getTemplate(postUrl, postInfo.getSegmentId(), postInfo.getBioId());
		if (null == result) {
			throw new DmServiceException("faild to get template from " + postUrl + ". refId=" + refId);
		}
		t.stop();
		log.info("Success get template data. dataSize={} refId({}) used time:{}", result.length, refId, t.elapsedTime());
		return result;		
	}
	
	@Transactional(isolation = Isolation.READ_COMMITTED)
	public byte[] getTemplateFromNodeStorage(Long segId, Long bioId) throws SQLException, InterruptedException, ExecutionException {
		final StopWatch t = new StopWatch();
		t.start();
		List<String> storagesUrl = segmentLoadRepository.getActiveStorageUrl(segId);		
		if (storagesUrl == null || storagesUrl.size() < 1) {
			throw new DmServiceException("No dm stroage node hoding segmentId:" + segId);
		}
		Collections.shuffle(storagesUrl);
		String getUrl = storagesUrl.get(0);
		getUrl = getUrl.endsWith("/") ? getUrl: getUrl + "/";
		getUrl = getUrl + "gettemplate/?segmentid="+ segId + "&bioid=" + bioId;
		byte[] result = HttpPoster.getTemplate(getUrl, segId, bioId);
		if (null == result) {
			throw new DmServiceException("faild to get template from " + storagesUrl + ". segId=" + segId + ". bioId=" + bioId);
		}
		t.stop();
		log.info("Success get template data. dataSize={} segId={}  bioId={} used time:{}", result.length, segId, bioId, t.elapsedTime());
		return result;
	}
}
