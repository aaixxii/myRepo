package com.nec.aim.dm.dmservice.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.concurrent.ExecutionException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nec.aim.dm.dmservice.dispatch.DmTemplateService;
import com.nec.aim.dm.dmservice.exception.DmServiceException;

import lombok.extern.slf4j.Slf4j;



@Controller
@Slf4j
public class TemplateController extends HttpServlet {
	private static final long serialVersionUID = -5368691957495983136L;
	
	@Autowired
	DmTemplateService dmTemplateService;	
	
	@RequestMapping("/getTemplate/")
	public void getTemplate(HttpServletRequest req, HttpServletResponse res, @RequestParam("segId") Long segId, @RequestParam("bioId") Long bioId) throws IOException {		
		log.info("Received getTemplate from {}", req.getRemoteHost());
		byte[] templateData = null;
		try {
			templateData = dmTemplateService.getTemplateFromNodeStorage(segId, bioId);
		} catch (SQLException | InterruptedException | ExecutionException e) {
			log.error(e.getMessage(), e);
		}	
		if (templateData != null && templateData.length > 0) {
			long length = templateData.length;
			res.setContentType("application/binary");
			res.addHeader("Content-Length", Long.toString(length));			
			res.getOutputStream().write(templateData);
			res.setStatus(200);
			log.info("Success send template data to client, segmentId={}, bioId={}", segId, bioId);
		} else {
			throw new DmServiceException("Faild to get template data, segmentId=" + segId + "bioId=" + bioId);
		}	
	}		
	

	@RequestMapping("/getTemplateByRefId/")
	public void getTemplateByRefId(HttpServletRequest req, HttpServletResponse res, @RequestParam("refId") String refId) throws IOException {
		log.info("Received getTemplateByRefId from {}", req.getRemoteHost());
		byte[] templateData = null;
		try {
			templateData = dmTemplateService.getTemplateFromNodeStorage(refId);
		} catch (SQLException | InterruptedException | ExecutionException e) {
			log.error(e.getMessage(), e);
		}	
		if (templateData != null && templateData.length > 0) {
			long length = templateData.length;
			res.setContentType("application/binary");
			res.addHeader("Content-Length", Long.toString(length));			
			res.getOutputStream().write(templateData);
			res.setStatus(200);
			log.info("Success send template data , refernceId={}", refId);
		} else {
			throw new DmServiceException("Faild to get template data, refId=" + refId);
		}	
	}	
}
