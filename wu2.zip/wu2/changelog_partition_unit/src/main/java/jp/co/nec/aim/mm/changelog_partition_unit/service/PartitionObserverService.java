package jp.co.nec.aim.mm.changelog_partition_unit.service;

import jp.co.nec.aim.mm.changelog_partition_unit.ChangelogPartitionUnit;
import jp.co.nec.aim.mm.changelog_partition_unit.controller.PartitionController;

/**
 * The PartitionObserverService is Observer for check current partition number and check current period.
 *
 * @author Go
 * @version 1.0
 * @since 2020-05-31
 */
public class PartitionObserverService implements Runnable {
    private Thread threadPartitionObserverService;
    public static Long longStartTime;
    public Long longCurrentTime;

    public static Integer intPartitionNum;

    /**
     * Another constructor for class PartitionObserverService.
     *
     * @return Nothing.
     */
    public PartitionObserverService() {
        longStartTime = System.currentTimeMillis() / 1000L;
        intPartitionNum = null;
    }

    public void run() {
        PartitionController objPartitionController = new PartitionController();
        try {
            ChangelogPartitionUnit.LOGGER.info("Starting Partition Observer");
            while (true) {
                this.longCurrentTime = System.currentTimeMillis() / 1000L;
                // TODO need fix
                Thread.sleep(3000);
                // check current period
                objPartitionController.checkPeriod(longStartTime, longCurrentTime);
            }
        } catch (InterruptedException e) {
            ChangelogPartitionUnit.LOGGER.info("got interrupted!");
        }
    }

    /**
     * Start a new Thread for PartitionObserverService.
     *
     * @return Nothing.
     */
    public void start() {
        threadPartitionObserverService = new Thread(this, "PartitionObserverService");
        threadPartitionObserverService.start();
    }
}
