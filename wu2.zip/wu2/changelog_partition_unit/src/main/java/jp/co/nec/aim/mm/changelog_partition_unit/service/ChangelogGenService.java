package jp.co.nec.aim.mm.changelog_partition_unit.service;

import java.time.LocalDateTime;
import java.util.Random;
import jp.co.nec.aim.mm.changelog_partition_unit.ChangelogPartitionUnit;
import jp.co.nec.aim.mm.changelog_partition_unit.model.Partition;

/**
 * The ChangelogGenService is test data generator for run test.
 *
 * @author Go
 * @version 1.0
 * @since 2020-05-31
 */
public class ChangelogGenService implements Runnable {
    private Thread threadChangelogGenService;

    Partition objPartition = new Partition();

    public void run() {
        try {
            ChangelogPartitionUnit.LOGGER.info("Starting generate Test data");
            while (true) {
                if (PartitionObserverService.intPartitionNum != null) {
                    Random rd = new Random();
                    byte[] byteTemplateBlob = new byte[36684];
                    rd.nextBytes(byteTemplateBlob);
                    // inster test data
                    objPartition.testData(1, 1, 1, 1, byteTemplateBlob, LocalDateTime.now(),
                            PartitionObserverService.intPartitionNum);
                }
                Thread.sleep(100);
            }
        } catch (InterruptedException e) {
            System.out.println("got interrupted!");
        }
    }

    /**
     * Start a new Thread for ChangelogGenService.
     *
     * @return Nothing.
     */
    public void start() {
        threadChangelogGenService = new Thread(this, "ChangelogGenService");
        threadChangelogGenService.start();
    }
}
