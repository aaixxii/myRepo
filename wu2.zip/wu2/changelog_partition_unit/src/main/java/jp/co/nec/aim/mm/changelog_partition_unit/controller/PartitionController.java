package jp.co.nec.aim.mm.changelog_partition_unit.controller;

import jp.co.nec.aim.mm.changelog_partition_unit.ChangelogPartitionUnit;
import jp.co.nec.aim.mm.changelog_partition_unit.model.Partition;
import jp.co.nec.aim.mm.changelog_partition_unit.service.PartitionObserverService;

/**
 * The PartitionController is the controller for check and change partition.
 *
 * @author Go
 * @version 1.0
 * @since 2020-05-31
 */
public class PartitionController {
    Long longElapsedTime;
    Integer intPartitionNum;
    Integer intNextPartitionNum;
    Integer intAdjust;

    public static Integer intChangeMode;
    public static Integer intPeriodNew;
    String pattern;
    Partition objPartition = new Partition();

    /**
     * Another constructor for class PartitionController.
     *
     * @return Nothing.
     */
    public PartitionController() {
        this.pattern = "yyyy-MM-dd";
        PartitionController.intChangeMode = 0;
        PartitionController.intPeriodNew = 0;
    }

    /**
     * Clear partition by partition number.
     *
     * @param intPNo This is the partition number.
     * @return Nothing.
     */
    public void clear(Integer intPNo) {
        // ChangelogPartitionUnit.LOGGER.info(
        // objChangelogRepository.clear(intPNo).toString() + " row(s) affected");
        objPartition.clear(intPNo);
        ChangelogPartitionUnit.LOGGER.info("Clear partition " + intPNo.toString());
        ChangelogPartitionUnit.LOGGER.info("Partition " + intPNo.toString() + " have "
                + Integer.toString(objPartition.getDataCountByPNo(intPNo)) + " element");
        // ChangelogPartitionUnit.LOGGER.info("Partition " + intPNo.toString() + " have "
        // + Integer.toString(objChangelogRepository.getChangelog(intPNo).size())
        // + " element");
    }

    /**
     * Check current partition period by start time and current time.
     *
     * @param longStartTime   This is the start time.
     * @param longCurrentTime This is the current time.
     * @return Nothing.
     */
    public void checkPeriod(Long longStartTime, Long longCurrentTime) {
        this.longElapsedTime = longCurrentTime - longStartTime;
        Integer intTmp = this.longElapsedTime.intValue() / ChangelogPartitionUnit.intPeriodTime;
        this.intPartitionNum =
                ((this.longElapsedTime.intValue() / ChangelogPartitionUnit.intPeriodTime)
                        + ChangelogPartitionUnit.intAdjust) % ChangelogPartitionUnit.intPeriod;
        // if intPartitionNum is null, it is the first time check partition period.
        if (PartitionObserverService.intPartitionNum != null) {
            // if current partition number not same as the last check result, it's time for clear
            // next partition.
            if (!this.intPartitionNum.equals(PartitionObserverService.intPartitionNum)) {
                ChangelogPartitionUnit.LOGGER.info("Partition has changed");
                // check the last partition
                if (this.intPartitionNum + 1 == ChangelogPartitionUnit.intPeriod) {
                    this.intNextPartitionNum = 0;
                } else {
                    this.intNextPartitionNum = this.intPartitionNum + 1;
                }

                ChangelogPartitionUnit.LOGGER
                        .info("IntPeriod: " + ChangelogPartitionUnit.intPeriod.toString());
                ChangelogPartitionUnit.LOGGER
                        .info("intPeriodTime: " + ChangelogPartitionUnit.intPeriodTime.toString());
                ChangelogPartitionUnit.LOGGER.info("ElapsedTime: " + intTmp.toString());
                ChangelogPartitionUnit.LOGGER.info("Current partition number is "
                        + this.intPartitionNum.toString() + ", Next Partition number is "
                        + this.intNextPartitionNum.toString());
                ChangelogPartitionUnit.LOGGER.info("Starting clear next partition");

                // clear next partition.
                clear(this.intNextPartitionNum);
            }
        } else {
            ChangelogPartitionUnit.LOGGER.info("PartitionObserver initialize");
            ChangelogPartitionUnit.LOGGER
                    .info("Current partition number is " + this.intPartitionNum.toString());
            ChangelogPartitionUnit.LOGGER.info("Clear partition p0 and p1");
            clear(0);
            clear(1);
            ChangelogPartitionUnit.LOGGER.info("Starting check partition number");
        }
        PartitionObserverService.intPartitionNum = this.intPartitionNum;
    }

    /**
     * Change partition period by partition number.
     *
     * @param intPeriodNew This is the partition number.
     * @return Nothing.
     */
    public void changePartition(Integer intPeriodNew) {
        Integer intAdjustNew;
        Integer intElapsedUnitInterval;

        ChangelogPartitionUnit.LOGGER.info("Start set changlog period.");
        // if the new period number same as old, will not do any thing.
        if (ChangelogPartitionUnit.intPeriod.equals(intPeriodNew)) {
            ChangelogPartitionUnit.LOGGER.info("Changlog period have not changed.");

        } else {
            ChangelogPartitionUnit.LOGGER.info("Changlog period have changed.");

            Long longElapsedTime =
                    (System.currentTimeMillis() / 1000L) - PartitionObserverService.longStartTime;
            intElapsedUnitInterval =
                    longElapsedTime.intValue() / ChangelogPartitionUnit.intPeriodTime;

            ChangelogPartitionUnit.LOGGER
                    .info("Change partition count " + ChangelogPartitionUnit.intPeriod.toString()
                            + " to " + intPeriodNew.toString());
            // get Adjust.
            intAdjustNew =
                    (intPeriodNew + (intElapsedUnitInterval % ChangelogPartitionUnit.intPeriod))
                            - (intElapsedUnitInterval % intPeriodNew);
            if (intAdjustNew > intPeriodNew) {
                intAdjustNew = intAdjustNew % intPeriodNew;
            }
            // if new period bigger than the old, will add partition, else will drop partition.
            // have checked the new period same as the old at top.
            if (ChangelogPartitionUnit.intPeriod < intPeriodNew) {
                for (Integer i = ChangelogPartitionUnit.intPeriod; i < intPeriodNew; i++) {
                    ChangelogPartitionUnit.LOGGER.info("Add Partition: " + i.toString());
                    // strSQL = strSQL + "PARTITION p" + i + " VALUES IN (" + i + "),";
                    try {
                        objPartition.create(i);
                    } catch (Exception e) {
                    }
                }
            } else {
                for (Integer i = intPeriodNew; i < ChangelogPartitionUnit.intPeriod; i++) {
                    ChangelogPartitionUnit.LOGGER.info("Drop Partition: " + i.toString());
                    // strSQL = strSQL + "PARTITION p" + i + " VALUES IN (" + i + "),";
                    try {
                        objPartition.drop(i);
                    } catch (Exception e) {
                    }
                }
            }

            ChangelogPartitionUnit.intAdjust = intAdjustNew;
            ChangelogPartitionUnit.LOGGER
                    .info("Change changlog period to " + intPeriodNew.toString());
            ChangelogPartitionUnit.intPeriod = intPeriodNew;
            PartitionObserverService.intPartitionNum =
                    ((intElapsedUnitInterval % intPeriodNew) + intAdjustNew) % intPeriodNew;
            ChangelogPartitionUnit.LOGGER
                    .info("intAdjust: " + ChangelogPartitionUnit.intAdjust.toString());
        }
    }
}
