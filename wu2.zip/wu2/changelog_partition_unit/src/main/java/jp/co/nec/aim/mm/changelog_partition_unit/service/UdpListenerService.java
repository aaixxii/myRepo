package jp.co.nec.aim.mm.changelog_partition_unit.service;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.Arrays;
import jp.co.nec.aim.mm.changelog_partition_unit.ChangelogPartitionUnit;
import jp.co.nec.aim.mm.changelog_partition_unit.controller.PartitionController;

/**
 * The UdpListenerService is UDP Server. Can use this class to set something when run test.
 *
 * @author Go
 * @version 1.0
 * @since 2020-05-31
 */
public class UdpListenerService implements Runnable {
    private DatagramSocket socket;
    // UDP pocket's max size.
    private byte[] buf = new byte[256];

    Thread threadUdpListenerService;
    PartitionController objPartitionController = new PartitionController();

    /**
     * Another constructor for class UdpListenerService.
     *
     * @return Nothing.
     */
    public UdpListenerService() {
        try {
            socket = new DatagramSocket(5555);
        } catch (SocketException e) {
            ChangelogPartitionUnit.LOGGER.error(e.getMessage());
        }
    }

    public void run() {
        ChangelogPartitionUnit.LOGGER.info("Starting UdpListener Service");

        while (true) {
            DatagramPacket packet = new DatagramPacket(buf, buf.length);

            try {
                socket.receive(packet);
            } catch (IOException e) {
                ChangelogPartitionUnit.LOGGER.error(e.getMessage());
            }

            // Get real data by pocket size.
            byte[] realData = Arrays.copyOf(packet.getData(), packet.getLength());
            String received = new String(realData);
            objPartitionController.changePartition(Integer.parseInt(received));
        }
    }

    /**
     * Start a new Thread for UdpListenerService.
     *
     * @return Nothing.
     */
    public void start() {
        threadUdpListenerService = new Thread(this, "UdpListenerService");
        threadUdpListenerService.start();
    }
}
