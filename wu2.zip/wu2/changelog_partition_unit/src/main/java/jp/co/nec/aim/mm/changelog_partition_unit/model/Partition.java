package jp.co.nec.aim.mm.changelog_partition_unit.model;

import java.time.LocalDateTime;
import jp.co.nec.aim.mm.changelog_partition_unit.ChangelogPartitionUnit;

/**
 * The Partition is class for partition IO.
 *
 * @author Go
 * @version 1.0
 * @since 2020-05-31
 */
public class Partition {
    String strSQL;
    int intResult;

    /**
     * Clear partition's data by partition number.
     *
     * @param intPNo This is the partition number.
     * @return Nothing.
     */
    public void clear(Integer intPNo) {
        strSQL = "ALTER TABLE change_log TRUNCATE PARTITION p" + intPNo.toString();
        // ChangelogPartitionUnit.LOGGER.info(strSQL);
        ChangelogPartitionUnit.DATABASE.executeUpdate(strSQL);
    }

    /**
     * Create new partition by partition number.
     *
     * @param intPNo This is the partition number.
     * @return Nothing.
     */
    public void create(Integer intPNo) {
        strSQL = "ALTER TABLE change_log ADD PARTITION ( PARTITION p" + intPNo.toString()
                + " VALUES IN (" + intPNo.toString() + "))";
        // ChangelogPartitionUnit.LOGGER.info(strSQL);
        ChangelogPartitionUnit.DATABASE.executeUpdate(strSQL);
    }

    /**
     * Drop partition by partition number.
     *
     * @param intPNo This is the partition number.
     * @return Nothing.
     */
    public void drop(Integer intPNo) {
        strSQL = "ALTER TABLE change_log DROP PARTITION p" + intPNo.toString();
        // ChangelogPartitionUnit.LOGGER.info(strSQL);
        ChangelogPartitionUnit.DATABASE.executeUpdate(strSQL);
    }

    /**
     * Get partition's data count by partition number.
     *
     * @param intPNo This is the partition number.
     * @return intResult.
     */
    public int getDataCountByPNo(Integer intPNo) {
        strSQL = "SELECT * FROM change_log PARTITION (p" + intPNo.toString() + ")";
        // ChangelogPartitionUnit.LOGGER.info(strSQL);

        intResult = ChangelogPartitionUnit.DATABASE.executeQuery(strSQL);

        return intResult;
    }

    /**
     * Insert test data.
     *
     * @param intSegmentId This is the Segment Id.
     * @param intRequestType This is the Request Type Id.
     * @param intSegmentVersion This is the Segment Version.
     * @param intTemplateId This is the Template Id.
     * @param byteTemplateBlob This is the Template binary data.
     * @param Timestamp This is the Timestamp.
     * @param intPNo This is the partition number.
     * @return Nothing.
     */
    public void testData(Integer intSegmentId, Integer intRequestType, Integer intSegmentVersion,
            Integer intTemplateId, byte[] byteTemplateBlob, LocalDateTime Timestamp,
            Integer intPNo) {
        strSQL = "INSERT INTO `change_log` (`segment_id`, `request_type`, `segment_version`, `template_id`,"
                + " `template_blob`, `TS`, `p_no`) VALUES ('" + intSegmentId.toString() + "', '"
                + intRequestType.toString() + "', '" + intSegmentVersion.toString() + "', '"
                + intTemplateId.toString() + "', '" + byteTemplateBlob.toString() + "', '"
                + Timestamp.toString() + "', '" + intPNo.toString() + "');";
        // ChangelogPartitionUnit.LOGGER.info(strSQL);
        ChangelogPartitionUnit.DATABASE.executeUpdate(strSQL);

    }
}
