package jp.co.nec.aim.mm.changelog_partition_unit.lib.log;

import java.time.LocalDateTime;

/**
 * The Logger is class for log generator.
 *
 * @author Go
 * @version 1.0
 * @since 2020-05-31
 */
public class Logger {
    String strInfo;
    String strError;

    /**
     * Another constructor for class Logger.
     *
     * @return Nothing.
     */
    public Logger() {
        strInfo = "[INFO] ";
        strError = "[ERROR] ";
    }

    /**
     * Entry for info log.
     *
     * @return Nothing.
     */
    public void info(String log) {
        print(strInfo + LocalDateTime.now() + " " + log);
    }

    /**
     * Entry for error log.
     *
     * @return Nothing.
     */
    public void error(String log) {
        print(strError + LocalDateTime.now() + " " + log);
    }

    /**
     * Print log.
     *
     * @return Nothing.
     */
    public void print(String log) {
        System.out.println(log);
    }
}
