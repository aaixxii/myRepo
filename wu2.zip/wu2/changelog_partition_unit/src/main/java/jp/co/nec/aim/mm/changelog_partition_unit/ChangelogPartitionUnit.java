package jp.co.nec.aim.mm.changelog_partition_unit;

import jp.co.nec.aim.mm.changelog_partition_unit.lib.db.Database;
import jp.co.nec.aim.mm.changelog_partition_unit.lib.log.Logger;
import jp.co.nec.aim.mm.changelog_partition_unit.service.ChangelogGenService;
import jp.co.nec.aim.mm.changelog_partition_unit.service.PartitionObserverService;
import jp.co.nec.aim.mm.changelog_partition_unit.service.UdpListenerService;

/**
 * The ChangelogPartitionUnit can manage DB partition for changelog clear old data.
 *
 * @author Go
 * @version 1.0
 * @since 2020-05-31
 */
public class ChangelogPartitionUnit {
    public static Logger LOGGER;
    public static Database DATABASE;
    public static Integer intAdjust;
    public static Integer intPeriod;
    public static Integer intPeriodTime;

    /**
     * Another constructor for class ChangelogPartitionUnit.
     *
     * @param intPeriod     This is the period for change partition.
     * @param intPeriodTime This is the period time for change partition period.
     * @return Nothing.
     */
    public ChangelogPartitionUnit(Integer intPeriod, Integer intPeriodTime) {
        ChangelogPartitionUnit.LOGGER = new Logger();
        ChangelogPartitionUnit.DATABASE = new Database();
        ChangelogPartitionUnit.intAdjust = 0;
        ChangelogPartitionUnit.intPeriod = intPeriod;
        ChangelogPartitionUnit.intPeriodTime = intPeriodTime;
    }

    /**
     * The main method.
     *
     * @param argv[0] This is the flg for TestMode. Will run TestMode when value is "test".
     * @param argv[1] This is the period for change partition. default value is 7.
     * @param argv[2] This is the period time for change partition period. default value is 30.
     * @return Nothing.
     */
    public static void main(String[] argv) {
        String regex = "\\d+";
        Integer intDefaultPeriod = 7;
        Integer intDefaultPeriodTime = 30;

        try {
            if (argv[0].equals("test")) {
                try {
                    if (argv[1].matches(regex) && argv[2].matches(regex)) {
                        new ChangelogPartitionUnit(Integer.parseInt(argv[1]),
                                Integer.parseInt(argv[2]));
                    } else {
                        new ChangelogPartitionUnit(intDefaultPeriod, intDefaultPeriodTime);
                    }
                } catch (ArrayIndexOutOfBoundsException e) {
                    new ChangelogPartitionUnit(intDefaultPeriod, intDefaultPeriodTime);
                    System.out.println(
                            "Period and PeriodTime will use 7 and 30. You can set them by parameter.");
                }

                new PartitionObserverService().start();
                new UdpListenerService().start();
                new ChangelogGenService().start();
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("ArrayIndexOutOfBoundsException caught");
        }
    }

    /**
     * Call Partition Observer.
     *
     * @return Nothing.
     */
    public void run() {
        System.out.println("Call Partition Observer");
        new PartitionObserverService().start();
    }
}
