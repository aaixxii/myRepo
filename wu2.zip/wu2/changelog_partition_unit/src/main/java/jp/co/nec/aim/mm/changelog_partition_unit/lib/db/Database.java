package jp.co.nec.aim.mm.changelog_partition_unit.lib.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * The Database is class for JDBC.
 *
 * @author Go
 * @version 1.0
 * @since 2020-05-31
 */
public class Database {
    public Integer intResultCount = 0;

    /**
     * execute method for execute query.
     *
     * @param strSql  This is the query text.
     * @param intType This is the query type.
     * @return intResultCount.
     */
    public int execute(String strSql, Integer intType) {
        /*
         * Declare variables that require explicit assignments because they're addressed in the
         * finally block.
         */
        Connection conn = null;
        Statement stmt = null;
        ResultSet rset = null;

        /* Declare other variables. */
        // TODO need fix
        String url;
        String username = "root";
        String password = "root";
        String database = "dm";
        String hostname = "localhost";
        String port = "3306";

        /* Attempt a connection. */
        try {
            // Set URL.
            url = "jdbc:mysql://" + hostname + ":" + port + "/" + database + "?serverTimezone=JST";

            // Create instance of MySQLDriver.
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            conn = DriverManager.getConnection(url, username, password);

            // Query the version of the database.
            stmt = conn.createStatement();
            if (intType == 0) {
                rset = stmt.executeQuery(strSql);
                rset.last();
                intResultCount = rset.getRow();

                // Read row returns for one column.
                while (rset.next()) {
                    System.out.println("MySQLDriver Version [" + rset.getString(1) + "]");
                }
                // return rset.getRow();
                // return rset;
            } else {
                stmt.executeUpdate(strSql);
            }


            // System.out.println("Database connection established");


        } catch (SQLException e) {
            System.err.println("Cannot connect to database server:");
            System.out.println(e.getMessage());
        } catch (ClassNotFoundException e) {
            System.err.println("Cannot find MySQL driver class:");
            System.out.println(e.getMessage());
        } catch (InstantiationException e) {
            System.err.println("Cannot instantiate class:");
            System.out.println(e.getMessage());
        } catch (IllegalAccessException e) {
            System.err.println("Illegal access exception:");
            System.out.println(e.getMessage());
        } finally {
            if (conn != null) {
                try {
                    rset.close();
                    stmt.close();
                    conn.close();
                    // System.out.println("Database connection terminated");
                } catch (Exception e) {
                    /* ignore close errors */ }
            }
        }
        return intResultCount;
    }

    /**
     * Entry for Select query.
     *
     * @return execute(strSql, 0).
     */
    public int executeQuery(String strSql) {
        return execute(strSql, 0);
    }

    /**
     * Entry for Update(e.x. Update, Inster, Delete...) query.
     *
     * @return Nothing.
     */
    public void executeUpdate(String strSql) {
        execute(strSql, 1);
    }
}
