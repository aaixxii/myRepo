package com.example.nodes_master.aspect;

import com.example.nodes_master.NodesMasterApplication;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class CheckServicesFlgServiceAspect {

    @After("execution(* com.example.nodes_master.service.CheckServicesFlgService.start(..))")
    public void After(JoinPoint joinPoint) {
        System.out.println("After method:" + joinPoint.getSignature());
        NodesMasterApplication.logger.info("helloWorld by AOP!");
    }

}
