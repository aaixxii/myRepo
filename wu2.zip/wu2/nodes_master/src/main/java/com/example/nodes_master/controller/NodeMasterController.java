package com.example.nodes_master.controller;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.annotation.PostConstruct;
import com.example.nodes_master.NodesMasterApplication;
import com.example.nodes_master.model.ChangelogRepository;
import com.example.nodes_master.service.ChangelogGenService;
import com.example.nodes_master.service.CheckMasterIdService;
import com.example.nodes_master.service.CheckNodeStorageService;
import com.example.nodes_master.service.CheckServicesFlgService;
import com.example.nodes_master.service.CheckTSService;
import com.example.nodes_master.service.PartitionObserverService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Controller
public class NodeMasterController {
    public static boolean boolFlgCheckService;
    public static boolean boolFlgCheckMasterId;
    public static boolean boolFlgCheckTS;
    public static Integer intMasterId;
    public static Integer intUDPPort;
    public static Long longCheckAddressTime;
    public static Long longCheckTSTime;
    public static Long longObserverTime;
    public static Integer intPeriod;
    public static Integer intPeriodTime;
    public static Integer intChangelogGenTime;
    public static boolean boolFlgChangelogGen;
    public static Integer intAdjust;

    public NodeMasterController() {
        NodeMasterController.intAdjust = 0;
    }

    // @Autowired
    // private HostsMasterRepository hostsMasterRepository;

    @Autowired
    public CheckTSService objCheckTSService;

    @Autowired
    public CheckMasterIdService objCheckMasterId;

    @Autowired
    public CheckServicesFlgService objCheckDMFlgService;

    @Autowired
    public CheckNodeStorageService objCheckNodeStorageService;

    @Autowired
    public PartitionObserverService objPartitionObserverService;

    @Autowired
    public ChangelogGenService objChangelogGenService;

    @Value("${dm.config.udp-port}")
    public void setUDPPort(Integer UDPPort) {
        NodeMasterController.intUDPPort = UDPPort;
    }

    @Value("${dm.config.master-id}")
    public void setMasterId(Integer masterId) {
        NodeMasterController.intMasterId = masterId;
    }

    @Value("${dm.config.check-address-time}")
    public void setCheckAddressTime(Long checkAddressTime) {
        NodeMasterController.longCheckAddressTime = checkAddressTime;
    }

    @Value("${dm.config.check-TS-time}")
    public void setCheckTSTime(Long checkTSTime) {
        NodeMasterController.longCheckTSTime = checkTSTime;
    }

    @Value("${dm.config.check-TS-time}")
    public void setObserverTime(Long observerTime) {
        NodeMasterController.longObserverTime = observerTime;
    }

    @Value("${dm.config.partition_period}")
    public void setPartitionPeriod(Integer partitionPeriod) {
        NodeMasterController.intPeriod = partitionPeriod;
    }

    @Value("${dm.config.partition_period_time}")
    public void setPartitionPeriodTime(Integer partitionPeriodTime) {
        NodeMasterController.intPeriodTime = partitionPeriodTime;
    }

    @Value("${dm.config.changelog_gen_time}")
    public void setChangelogGenTime(Integer changelogGenTime) {
        NodeMasterController.intChangelogGenTime = changelogGenTime;
    }

    @Value("${dm.config.changelog_gen}")
    public void setChangelogGen(boolean changelogGen) {
        NodeMasterController.boolFlgChangelogGen = changelogGen;
    }


    @PostConstruct
    public void initService() {
        boolFlgCheckService = true;
        boolFlgCheckMasterId = false;
        boolFlgCheckTS = true;

        // hostsMasterRepository.updateStatus(1, intMasterId);

        // this.objCheckTSService.run();
        // this.objCheckMasterId.run();
        // this.objCheckNodeStorageService.run();
        this.objPartitionObserverService.run();
        if (NodeMasterController.boolFlgChangelogGen) {
            this.objChangelogGenService.run();
        }
        // check services_status
        // this.objCheckDMFlgService.run();

        // ActionScheduleController objActionScheduleController = new ActionScheduleController();
        // objActionScheduleController.JobDestributeFlatFuzzy();
        // objActionScheduleController.demo();
        // objActionScheduleController.demo2();


    }

    @GetMapping(value = "/stopService")
    public String stopService() {
        boolFlgCheckService = false;
        // UPDATE Hosts table
        // hostsMasterRepository.updateStatus(0, intMasterId);
        NodesMasterApplication.logger.info("Stop Nodes Master!");
        return String.format("Stop Nodes Master!");
    }

    @GetMapping(value = "/startService")
    public String startService() {
        if (boolFlgCheckService == false) {
            boolFlgCheckService = true;
            boolFlgCheckMasterId = false;
            boolFlgCheckTS = true;
            this.objCheckTSService.run();
            this.objCheckMasterId.run();
            NodesMasterApplication.logger.info("Start Nodes Master!");
            return String.format("Start Nodes Master!");
        } else {
            NodesMasterApplication.logger.info("Don't start again!");
            return String.format("Don't start again!");
        }
    }

    @GetMapping(value = "/UDPSSender")
    public void UDPSSender() {
        UDPAdapterController objUDPAdapterController = new UDPAdapterController();
        objUDPAdapterController.UDPSSender("10.84.75.134", NodeMasterController.intUDPPort,
                "Hello world");
    }

    @GetMapping(value = "/demo")
    public void demo() {
        ActionScheduleController objActionScheduleController = new ActionScheduleController();
        objActionScheduleController.demo();
    }

    @GetMapping(value = "/demo2")
    public void demo2() {
        ActionScheduleController objActionScheduleController = new ActionScheduleController();
        objActionScheduleController.demo2();
    }

    @Autowired
    private ChangelogRepository changelogRepository;

    @GetMapping(value = "/getChangelog")
    public String getChangelog(@RequestParam(defaultValue = "0") Integer p) {
        // changelogRepository.getChangelog(0).forEach(objChangelog ->
        // System.out.println(objChangelog.getUpdateTS()));
        // System.out.println(Arrays.toString(changelogRepository.getChangelog().toArray()));
        return "Partition " + p + ", Found rows: "
                + Integer.toString(changelogRepository.getChangelog(p).size());
    }

    @Autowired
    private ChangelogRepository objChangelogRepository;

    @GetMapping(value = "/setBackupPeriod")
    public void setBackupPeriod(@RequestParam(defaultValue = "0") String s,
            @RequestParam(defaultValue = "7") Integer p,
            @RequestParam(defaultValue = "99") Integer t) {
        // changelogRepository.setBackupPeriod(intStartTime, intPeriod);
        // SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        // Date date = format.parse("2020-04-02");
        // long timestamp = date.getTime();
        String pattern = "yyyy-MM-dd";
        String strT = s;
        Integer intPeriodNew = p;
        Integer intCritical;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        Integer intAdjust;
        String strSQL;

        intAdjust = 0;

        NodesMasterApplication.logger.info("Start set changlog period.");
        if (NodeMasterController.intPeriod.equals(intPeriodNew)) {
            NodesMasterApplication.logger.info("Have not changed.");
            // intAdjust = 0;
        } else {
            if (intPeriodNew > NodeMasterController.intPeriod) {
                intCritical = NodeMasterController.intPeriod;
            } else {
                intCritical = intPeriodNew;
            }
            NodesMasterApplication.logger.info("Change data for test");
            // PartitionObserverService.longStartTime =
            //         PartitionObserverService.longStartTime - 550650;
            Long longElapsedTime =
                    (System.currentTimeMillis() / 1000L) - PartitionObserverService.longStartTime;
            Integer temp = (longElapsedTime.intValue() / NodeMasterController.intPeriodTime);

            // temp = t;
            Integer intModeBefore = (temp % NodeMasterController.intPeriod);
            Integer intModeAfter = (temp % intPeriodNew);

            NodesMasterApplication.logger.info("ElapsedTime: " + temp.toString());
            NodesMasterApplication.logger.info("Mod result(before): " + intModeBefore.toString());
            NodesMasterApplication.logger.info("Mod result(after): " + intModeAfter.toString());
            NodesMasterApplication.logger.info("Critical point: " + intCritical.toString());
            NodesMasterApplication.logger.info(
                    NodeMasterController.intPeriod.toString() + " to " + intPeriodNew.toString());
            intAdjust = (intPeriodNew + (temp % NodeMasterController.intPeriod))
                    - (temp % intPeriodNew);
            if (intAdjust > intPeriodNew) {
                intAdjust = intAdjust % intPeriodNew;
            }

            // objChangelogRepository.clearPartition(6);
            // objChangelogRepository.addPartition(7);

            strSQL = "";

            if (NodeMasterController.intPeriod < intPeriodNew) {
                for (Integer i = NodeMasterController.intPeriod; i < intPeriodNew; i++) {
                    NodesMasterApplication.logger.info("Add Partition: " + i.toString());
                    // strSQL = strSQL + "PARTITION p" + i + " VALUES IN (" + i + "),";
                    try {
                        objChangelogRepository.addPartition(i);
                    } catch (Exception e) {
                    }
                }
            } else {
                for (Integer i = intPeriodNew; i < NodeMasterController.intPeriod; i++) {
                    NodesMasterApplication.logger.info("Drop Partition: " + i.toString());
                    // strSQL = strSQL + "PARTITION p" + i + " VALUES IN (" + i + "),";
                    try {
                        objChangelogRepository.dropPartition(i);
                    } catch (Exception e) {
                    }
                }
            }


            // strSQL = strSQL.substring(0, strSQL.length() - 1);
            // NodesMasterApplication.logger.info(strSQL);

            NodeMasterController.intAdjust = intAdjust;
            NodesMasterApplication.logger.info("Change period to " + intPeriodNew.toString());
            NodeMasterController.intPeriod = intPeriodNew;
            PartitionObserverService.intPartitionNum =
                    ((temp % intPeriodNew) + intAdjust) % intPeriodNew;

        }
        NodesMasterApplication.logger.info("intAdjust: " + intAdjust.toString());
        // PartitionObserverController objPartitionObserverController =
        // new PartitionObserverController();
        // objPartitionObserverController.changePartition(intPeriodNew);
        try {
            Date date = simpleDateFormat.parse(strT);
            Long timestamp = date.getTime();
            // NodesMasterApplication.logger.info(timestamp.toString());
            // changelogRepository.setBackupPeriod(timestamp, intPeriod);
        } catch (ParseException e) {

        }
        // NodesMasterApplication.logger.info(intPeriod.toString());
    }
}
