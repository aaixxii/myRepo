package com.example.nodes_master.model;

import java.time.LocalDateTime;
import org.apache.ibatis.annotations.Param;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public interface MasterRepository extends JpaRepository<Master, Integer> {
    @Transactional
    @Modifying
    @Query("UPDATE Master m SET m.TS = Now() WHERE m.TS = :ldtOldTS")
    int updateTS(@Param("ldtOldTS") LocalDateTime ldtOldTS);

    @Transactional
    @Modifying
    @Query("UPDATE Master m SET m.master_id = :intMaster_id, m.token_start = Now(),"
            + "m.address = :strAddress, m.TS = Now() WHERE m.TS = :ldtOldTS")
    int updateMaster(@Param("ldtOldTS") LocalDateTime ldtOldTS,
            @Param("intMaster_id") Integer intMaster_id, @Param("strAddress") String strAddress);
}
