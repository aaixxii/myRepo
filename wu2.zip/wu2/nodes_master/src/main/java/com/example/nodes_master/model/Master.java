package com.example.nodes_master.model;

import java.time.LocalDateTime;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "master")
public class Master {
    @Id
    private Integer master_id;
    private LocalDateTime token_start;
    private String address;
    private LocalDateTime TS;

    public Integer getId() {
        return master_id;
    }

    public LocalDateTime getTokenStart() {
        return token_start;
    }

    public String getAddress() {
        return address;
    }

    public LocalDateTime getTS() {
        return TS;
    }

    public void setTokenStart(LocalDateTime TS) {
        this.token_start = TS;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setTS(LocalDateTime TS) {
        this.TS = TS;
    }
}
