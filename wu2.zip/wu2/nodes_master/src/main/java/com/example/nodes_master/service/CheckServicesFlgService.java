package com.example.nodes_master.service;

import com.example.nodes_master.NodesMasterApplication;
import com.example.nodes_master.controller.NodeMasterController;
import com.example.nodes_master.model.Services;
import com.example.nodes_master.model.ServicesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class CheckServicesFlgService{
    @Autowired
    private ServicesRepository servicesRepository;

    public CheckServicesFlgService() {
    }

    @Async
    public void run() {
        try {
            while (true) {
                if (NodeMasterController.boolFlgCheckService == false) {
                    break;
                }
                Thread.sleep(NodeMasterController.longCheckTSTime);

                Services objServices =
                        servicesRepository.findById(NodeMasterController.intMasterId).get();
                if (objServices.getDMFlg() == 0) {
                    NodesMasterApplication.logger.info("Service will offline");
                    NodeMasterController.boolFlgCheckService = false;
                }
            }
        } catch (InterruptedException e) {
            System.out.println("got interrupted!");
        }
    }
}
