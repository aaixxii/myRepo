package com.example.nodes_master.service;

import com.example.nodes_master.NodesMasterApplication;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;

@Service
public class UDPServerService
{
  public void handleMessage(Message<byte[]> message)
  {
    String data = new String((byte[]) message.getPayload());
    NodesMasterApplication.logger.info(data);
  }
}