package com.example.nodes_master.controller;

import java.time.LocalDateTime;
import com.example.nodes_master.NodesMasterApplication;
import com.example.nodes_master.model.Master;
import com.example.nodes_master.model.MasterRepository;
import com.example.nodes_master.service.CheckTSService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
public class CheckTSController {
    @Autowired
    private MasterRepository masterRepository;

    public CheckTSController() {

    }

    public void checkTS() {
        if (NodeMasterController.boolFlgCheckMasterId == false) {
            Master        objmaster       = masterRepository.findAll().get(0);
            LocalDateTime ldtOldTS        = objmaster.getTS();
            if (CheckTSService.ldtTempTS != null) {
                if (CheckTSService.ldtTempTS.equals(ldtOldTS)) {
                    if (masterRepository.updateMaster(ldtOldTS, NodeMasterController.intMasterId,
                    CheckTSService.strlocalAddress) == 1) {
                        NodesMasterApplication.logger
                                .info("Node " + NodeMasterController.intMasterId + " get token !");
                        NodeMasterController.boolFlgCheckMasterId = true;
                    }
                }
            }
            CheckTSService.ldtTempTS = ldtOldTS;
        }
    }
}
