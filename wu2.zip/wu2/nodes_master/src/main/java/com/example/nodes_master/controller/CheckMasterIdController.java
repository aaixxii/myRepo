package com.example.nodes_master.controller;

import java.time.LocalDateTime;
import com.example.nodes_master.NodesMasterApplication;
import com.example.nodes_master.model.Master;
import com.example.nodes_master.model.MasterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Controller;

@Controller
public class CheckMasterIdController {
    @Autowired
    private MasterRepository masterRepository;

    public CheckMasterIdController() {

    }

    @Async
    public void checkMasterId() {
        if (NodeMasterController.boolFlgCheckMasterId == true) {
            Master        objmaster = masterRepository.findAll().get(0);
            LocalDateTime ldtOldTS  = objmaster.getTS();

            if (objmaster.getId().equals(NodeMasterController.intMasterId)) {
                // fix
                if (masterRepository.updateTS(ldtOldTS) == 1) {
                    // NodesMasterApplication.logger.info("token has been updated!");
                }
            } else {
                NodesMasterApplication.logger.info("node " + NodeMasterController.intMasterId + " lost token !");
                NodeMasterController.boolFlgCheckMasterId = false;
                NodesMasterApplication.logger.info(ldtOldTS.toString());
            }
        }
    }
}