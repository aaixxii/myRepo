package com.example.nodes_master.model;

import java.time.LocalDateTime;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "change_log")
public class Changelog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer change_log_id;
    private Integer segment_id;
    private Integer request_type;
    private Integer segment_version;
    private Integer template_id;
    private byte[] template_blob;
    private LocalDateTime TS;
    private Integer P_NO;

    public Integer getSegmentId() {
        return segment_id;
    }

    public Integer getRequestType() {
        return request_type;
    }

    public Integer getSegmentVersion() {
        return segment_version;
    }

    public Integer getTemplateId() {
        return template_id;
    }

    public byte[] getTemplateBlob() {
        return template_blob;
    }

    public LocalDateTime getUpdateTS() {
        return TS;
    }

    public Integer getP_NO() {
        return P_NO;
    }

    public void setSegmentId(Integer intSegmentId) {
        this.segment_id = intSegmentId;
    }

    public void setRequestType(Integer intRequestType) {
        this.request_type = intRequestType;
    }

    public void setSegmentVersion(Integer intSegmentVersion) {
        this.segment_version = intSegmentVersion;
    }

    public void setTemplateId(Integer intTemplateId) {
        this.template_id = intTemplateId;
    }

    public void setTemplateBlob(byte[] byteTemplateBlob) {
        this.template_blob = byteTemplateBlob;
    }

    public void setTS(LocalDateTime TS) {
        this.TS = TS;
    }

    public void setP_NO(Integer intPNo) {
        this.P_NO = intPNo;
    }
}
