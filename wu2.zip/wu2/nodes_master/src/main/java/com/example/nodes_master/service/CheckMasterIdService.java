package com.example.nodes_master.service;

import com.example.nodes_master.controller.CheckMasterIdController;
import com.example.nodes_master.controller.NodeMasterController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class CheckMasterIdService {
    @Autowired
    private CheckMasterIdController checkMasterIdController;

    public CheckMasterIdService() {
    }

    @Async
    public void run() {
        try {
            while (true) {
                if (NodeMasterController.boolFlgCheckService == false) {
                    break;
                }

                checkMasterIdController.checkMasterId();

                Thread.sleep(NodeMasterController.longCheckAddressTime);
            }
        } catch (InterruptedException e) {
            System.out.println("got interrupted!");
        }
    }
}
