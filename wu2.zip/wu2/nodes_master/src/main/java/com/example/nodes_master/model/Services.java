package com.example.nodes_master.model;

import java.time.LocalDateTime;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "services_status")
public class Services {
    @Id
    private Integer master_id;
    private Integer dm_flg;
    private LocalDateTime TS;

    public Integer getId() {
        return master_id;
    }

    public Integer getDMFlg() {
        return dm_flg;
    }

    public LocalDateTime getTS() {
        return TS;
    }
}