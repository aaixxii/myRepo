package com.example.nodes_master.model;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;


@Component
public interface ChangelogRepository extends JpaRepository<Changelog, Integer> {
    @Transactional
    @Modifying
    @Query(value = "SELECT * FROM change_log PARTITION (p?1)", nativeQuery = true)
    List<Changelog> getChangelog(@Param("intStatus") Integer intStatus);

    @Transactional
    @Modifying
    @Query(value = "ALTER TABLE change_log PARTITION BY HASH ((UNIX_TIMESTAMP(TS) - ?1) DIV 86400) PARTITIONS ?2",
            nativeQuery = true)
    void setBackupPeriod(@Param("longStartTime") Long longStartTime,
            @Param("intPeriod") Integer intPeriod);

    @Transactional
    @Modifying
    @Query(value = "ALTER TABLE change_log TRUNCATE PARTITION p?1", nativeQuery = true)
    Integer clearPartition(@Param("intPNo") Integer intPNo);

    @Transactional
    @Modifying
    @Query(value = "ALTER TABLE change_log DROP PARTITION p?1", nativeQuery = true)
    Integer dropPartition(@Param("intPNo") Integer intPNo);

    @Transactional
    @Modifying
    @Query(value = " ALTER TABLE change_log ADD PARTITION ( PARTITION p?1 VALUES IN (?1))", nativeQuery = true)
    // Integer addPartition(@Param("strPNo") String strPNo);
    Integer addPartition(@Param("intPNo") Integer intPNo);
}
