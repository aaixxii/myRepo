package com.example.nodes_master.controller;

import java.util.List;
import com.example.nodes_master.NodesMasterApplication;
import com.example.nodes_master.model.NodeStorage;
import com.example.nodes_master.model.NodeStorageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
public class CheckNodeStorageController {
    private List<NodeStorage> nodeStorageList;
    private Integer intNodeCount;
    // private NodeStorage[] nodeStorageMatrix;

    @Autowired
    private NodeStorageRepository nodeStorageRepository;

    public CheckNodeStorageController() {

    }

    public List<NodeStorage> CheckNodeStorage(List<NodeStorage> oldNodeStorageMatrix) {
        this.nodeStorageList = nodeStorageRepository.findAll();
        this.intNodeCount = this.nodeStorageList.size();
        if (NodeMasterController.boolFlgCheckMasterId == true) {
            for (int i = 0; i < this.intNodeCount; i++) {
                if (oldNodeStorageMatrix.get(i).getUpdateTS()
                        .equals(this.nodeStorageList.get(i).getUpdateTS())) {
                    NodesMasterApplication.logger.info("Node Storage "
                            + this.nodeStorageList.get(i).getDmStorageId() + " have offline!");
                }
            }
        }

        return this.nodeStorageList;
    }
}
