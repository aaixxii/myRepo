package com.example.nodes_master.service;

import java.util.List;
import com.example.nodes_master.controller.CheckNodeStorageController;
import com.example.nodes_master.controller.NodeMasterController;
import com.example.nodes_master.model.NodeStorage;
import com.example.nodes_master.model.NodeStorageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class CheckNodeStorageService {
    @Autowired
    private CheckNodeStorageController checkNodeStorageController;

    private List<NodeStorage> oldNodeStorageMatrix;

    @Autowired
    private NodeStorageRepository nodeStorageRepository;

    public CheckNodeStorageService() {
    }

    @Async
    public void run() {
        try {
            this.oldNodeStorageMatrix = nodeStorageRepository.findAll();
            while (true) {
                if (NodeMasterController.boolFlgCheckService == false) {
                    break;
                }

                this.oldNodeStorageMatrix = checkNodeStorageController.CheckNodeStorage(this.oldNodeStorageMatrix);

                Thread.sleep(NodeMasterController.longCheckTSTime);
            }
        } catch (InterruptedException e) {
            System.out.println("got interrupted!");
        }
    }
}