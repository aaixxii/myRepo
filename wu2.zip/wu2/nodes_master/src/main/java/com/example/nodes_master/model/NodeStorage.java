package com.example.nodes_master.model;

import java.time.LocalDateTime;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "node_storage")
public class NodeStorage {
    @Id
    private Integer storage_id;
    private String dm_storage_id;
    private String url;
    private String mail_flag;
    private Integer disk_size;
    private Integer space;
    private Integer status;
    private LocalDateTime update_ts;

    public String getDmStorageId() {
        return dm_storage_id;
    }

    public String getURL() {
        return url;
    }

    public String getMailFlag() {
        return mail_flag;
    }

    public Integer getDiskSize() {
        return disk_size;
    }

    public Integer getSpace() {
        return space;
    }

    public Integer getStatus() {
        return status;
    }

    public LocalDateTime getUpdateTS() {
        return update_ts;
    }
}
