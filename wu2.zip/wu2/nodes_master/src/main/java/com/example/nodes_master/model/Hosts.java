package com.example.nodes_master.model;

import java.time.LocalDateTime;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "hosts")
public class Hosts {
    @Id
    private Integer master_id;
    private String address;
    private String rhel_version;
    private Integer status;
    private LocalDateTime TS;

    public Integer getId() {
        return master_id;
    }

    public String getAddress() {
        return address;
    }

    public String getVersion() {
        return rhel_version;
    }

    public Integer getStatus() {
        return status;
    }

    public LocalDateTime getTS() {
        return TS;
    }

}