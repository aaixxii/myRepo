package com.example.nodes_master.model;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface HostsMasterRepository extends JpaRepository<Hosts, Integer> {
    @Transactional
    @Modifying
    @Query("UPDATE Hosts h SET h.TS = Now(), h.status = :intStatus WHERE h.master_id = :intMaster_id")
    int updateStatus(@Param("intStatus") Integer intStatus, @Param("intMaster_id") Integer intMaster_id);
}