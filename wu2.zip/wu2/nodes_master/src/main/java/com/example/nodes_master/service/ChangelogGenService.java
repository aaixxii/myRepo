package com.example.nodes_master.service;

import java.time.LocalDateTime;
import java.util.Random;
import com.example.nodes_master.NodesMasterApplication;
import com.example.nodes_master.controller.NodeMasterController;
import com.example.nodes_master.model.Changelog;
import com.example.nodes_master.model.ChangelogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class ChangelogGenService {
    @Autowired
    private ChangelogRepository objChangelogRepository;

    Changelog objChangelog;

    public ChangelogGenService() {

    }

    @Async
    public void run() {
        try {
            NodesMasterApplication.logger.info("Starting generate Test data");
            while (true) {
                if (PartitionObserverService.intPartitionNum != null) {
                    Random rd = new Random();
                    byte[] byteTemplateBlob = new byte[36684];
                    rd.nextBytes(byteTemplateBlob);
                    this.objChangelog = new Changelog();
                    this.objChangelog.setSegmentId(1);
                    this.objChangelog.setRequestType(1);
                    this.objChangelog.setSegmentVersion(1);
                    this.objChangelog.setTemplateId(1);
                    this.objChangelog.setTemplateBlob(byteTemplateBlob);
                    this.objChangelog.setTS(LocalDateTime.now());
                    this.objChangelog.setP_NO(PartitionObserverService.intPartitionNum);
                    objChangelogRepository.save(this.objChangelog);
                }
                Thread.sleep(NodeMasterController.intChangelogGenTime);
            }
        } catch (InterruptedException e) {
            System.out.println("got interrupted!");
        }
    }

}
