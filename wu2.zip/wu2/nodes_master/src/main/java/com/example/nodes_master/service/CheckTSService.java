package com.example.nodes_master.service;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.time.LocalDateTime;
import com.example.nodes_master.controller.CheckTSController;
import com.example.nodes_master.controller.NodeMasterController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class CheckTSService {
    @Autowired
    private CheckTSController checkTSController;

    @Autowired
    private Environment environment;

    public static String strlocalAddress;
    public static LocalDateTime ldtTempTS = null;

    private String strIP;

    public CheckTSService() {
    }

    @Async
    public void run() {
        try {
            getAddress();
            Thread.sleep(NodeMasterController.longCheckTSTime);
            while (true) {
                if (NodeMasterController.boolFlgCheckService == false) {
                    break;
                }
                checkTSController.checkTS();
                Thread.sleep(NodeMasterController.longCheckTSTime);
            }
        } catch (InterruptedException e) {
            System.out.println("got interrupted!");
        }
    }

    public void getAddress() {
        try {
            InetAddress ip;
            try {
                ip = InetAddress.getLocalHost();
                strIP = ip.getHostAddress();
            } catch (UnknownHostException e) {
                e.printStackTrace();
            }
        } catch (NullPointerException e) {
            System.out.println(e.toString());
        }
        String strPort = environment.getProperty("local.server.port");
        strlocalAddress = strIP + ":" + strPort;
    }
}
