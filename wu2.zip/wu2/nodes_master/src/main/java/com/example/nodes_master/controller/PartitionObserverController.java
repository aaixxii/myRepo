package com.example.nodes_master.controller;

import com.example.nodes_master.NodesMasterApplication;
import com.example.nodes_master.model.ChangelogRepository;
import com.example.nodes_master.service.PartitionObserverService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Controller;

@Controller
public class PartitionObserverController {
    @Autowired
    private ChangelogRepository objChangelogRepository;

    Long longElapsedTime;
    Integer intPartitionNum;
    Integer intNextPartitionNum;
    Integer intAdjust;
    public static Integer intCritical;
    public static Integer intChangeMode;
    public static Integer intPeriodNew;
    String pattern;

    public PartitionObserverController() {
        this.pattern = "yyyy-MM-dd";
        PartitionObserverController.intChangeMode = 0;
        PartitionObserverController.intPeriodNew = 0;
    }

    @Async
    public void changePartition(Integer intPeriodNew) {
        NodeMasterController.intPeriod = intPeriodNew;
        // clearPartition(7);
        // objChangelogRepository.clearPartition(7);
        // if (NodeMasterController.intPeriod.equals(intPeriodNew)) {
        //     NodesMasterApplication.logger.info("Have no change");
        // } else {
        //     if (intPeriodNew > NodeMasterController.intPeriod) {
        //         PartitionObserverController.intCritical = NodeMasterController.intPeriod;
        //         PartitionObserverController.intChangeMode = 1;
        //     } else {
        //         PartitionObserverController.intCritical = intPeriodNew;
        //         PartitionObserverController.intChangeMode = 2;
        //     }
        //     PartitionObserverController.intPeriodNew = intPeriodNew;
        // }
        // NodesMasterApplication.logger.info("Start change Partition");
        // NodesMasterApplication.logger
        //         .info("Change Mode: " + PartitionObserverController.intChangeMode.toString());
        // NodesMasterApplication.logger
        //         .info("Critical point: " + PartitionObserverController.intCritical.toString());
        // NodesMasterApplication.logger
        //         .info("New Period: " + PartitionObserverController.intPeriodNew.toString());
    }

    @Async
    public void clearPartition(Integer intPNo) {
        NodesMasterApplication.logger
                .info(objChangelogRepository.clearPartition(intPNo).toString() + " row(s) affected");
        NodesMasterApplication.logger.info("Clear partition " + intPNo.toString());
        NodesMasterApplication.logger.info("Partition " + intPNo.toString() + " have "
                + Integer.toString(objChangelogRepository.getChangelog(intPNo).size()) + " element");
    }

    @Async
    public void checkPeriod(Long longStartTime, Long longCurrentTime) {
        this.longElapsedTime = longCurrentTime - longStartTime;

        // this.intPartitionNum =
        //         ((this.longElapsedTime.intValue() / NodeMasterController.intPeriodTime)
        //                 + NodeMasterController.intAdjust) % NodeMasterController.intPeriod;

        // check intChangeMode
        // if (PartitionObserverController.intChangeMode > 0) {
        //     if (this.intPartitionNum + 1 == PartitionObserverController.intCritical) {
        //         NodesMasterApplication.logger.info("Now is Critical Point!");
        //         NodeMasterController.intPeriod = PartitionObserverController.intPeriodNew;
        //         if (PartitionObserverController.intChangeMode == 1) {
        //             // will create string
        //             for (Integer i = NodeMasterController.intPeriod; i < PartitionObserverController.intPeriodNew; i++) {
        //                 objChangelogRepository.addPartition(i);
        //             }
        //         }
        //     }
        // }

        Integer intTmp = this.longElapsedTime.intValue() / NodeMasterController.intPeriodTime;
        this.intPartitionNum =
                ((this.longElapsedTime.intValue() / NodeMasterController.intPeriodTime)
                        + NodeMasterController.intAdjust) % NodeMasterController.intPeriod;


        if (PartitionObserverService.intPartitionNum != null) {
            if (!this.intPartitionNum.equals(PartitionObserverService.intPartitionNum)) {
                NodesMasterApplication.logger.info("Partition has changed");

                if (this.intPartitionNum + 1 == NodeMasterController.intPeriod) {
                    this.intNextPartitionNum = 0;
                } else {
                    this.intNextPartitionNum = this.intPartitionNum + 1;
                }

                NodesMasterApplication.logger.info("IntPeriod: " + NodeMasterController.intPeriod.toString());
                NodesMasterApplication.logger.info("intPeriodTime: " + NodeMasterController.intPeriodTime.toString());
                NodesMasterApplication.logger.info("ElapsedTime: " + intTmp.toString());
                NodesMasterApplication.logger.info("Current partition number is "
                        + this.intPartitionNum.toString() + ", Next Partition number is "
                        + this.intNextPartitionNum.toString());
                NodesMasterApplication.logger.info("Starting clear next partition");
                clearPartition(this.intNextPartitionNum);
            }
        } else {
            NodesMasterApplication.logger.info("PartitionObserver initialize");
            NodesMasterApplication.logger
                    .info("Current partition number is " + this.intPartitionNum.toString());
            NodesMasterApplication.logger.info("Clear partition p0 and p1");
            clearPartition(0);
            clearPartition(1);
            NodesMasterApplication.logger.info("Starting check partition number");
        }
        PartitionObserverService.intPartitionNum = this.intPartitionNum;
    }
}
