package com.example.nodes_master.service;

import com.example.nodes_master.NodesMasterApplication;
import com.example.nodes_master.controller.NodeMasterController;
import com.example.nodes_master.controller.PartitionObserverController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class PartitionObserverService {
    @Autowired
    private PartitionObserverController objPartitionObserverController;

    public static Long longStartTime;
    public Long longCurrentTime;

    public static Integer intPartitionNum;

    public PartitionObserverService() {
        longStartTime = System.currentTimeMillis() / 1000L;
        intPartitionNum    = null;
    }

    @Async
    public void run() {
        try {
            NodesMasterApplication.logger.info("Starting partition observer");
            while (true) {
                this.longCurrentTime = System.currentTimeMillis() / 1000L;
                Thread.sleep(NodeMasterController.longObserverTime);
                objPartitionObserverController.checkPeriod(longStartTime, longCurrentTime);
            }
        } catch (InterruptedException e) {
            System.out.println("got interrupted!");
        }
    }
}