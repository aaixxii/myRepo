package com.example.nodes_master.controller;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.LinkedList;
import com.example.nodes_master.NodesMasterApplication;
import org.springframework.stereotype.Controller;

@Controller
public class ActionScheduleController {
    Integer[] node4 = {0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0,
            0, 0, 0, 0, 0, 4};
    Integer[] node3 = {0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1,
            0, 0, 0, 0, 1, 3};
    Integer[] node6 = {0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0,
            0, 0, 1, 1, 0, 6};
    Integer[] node2 = {1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0,
            1, 1, 0, 0, 0, 2};
    Integer[] node1 = {1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0,
            1, 0, 1, 0, 0, 1};
    Integer[] node0 = {0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0,
            0, 1, 0, 1, 0, 0};
    Integer[] node5 = {0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 1,
            0, 0, 0, 0, 1, 5};

    Integer intCount;

    public ActionScheduleController() {
    }

    void demo() {
        long startTime = System.nanoTime();
        for (int j = 0; j < 1; j++) {
            JobDestributeFlatFuzzy();
        }
        long stopTime = System.nanoTime();
        double seconds = ((double) (stopTime - startTime) / 1000000000);
        NodesMasterApplication.logger
                .info("demo1: " + new DecimalFormat("#.##########").format(seconds) + " Seconds");
    }

    void demo2() {
        long startTime = System.nanoTime();
        for (int j = 0; j < 1; j++) {
            JobDestributeFlatFuzzy2();
        }
        long stopTime = System.nanoTime();
        double seconds = ((double) (stopTime - startTime) / 1000000000);
        NodesMasterApplication.logger
                .info("demo2: " + new DecimalFormat("#.##########").format(seconds) + " Seconds");
    }

    void JobDestributeFlatFuzzy2() {
        Integer NumberOfSegment = 31;
        Integer NumberOfMU = 7;
        Integer SegNum;
        Integer MuNum;

        LinkedList<Integer[]> objLinkedList = new LinkedList<Integer[]>();
        objLinkedList.add(node4);
        objLinkedList.add(node3);
        objLinkedList.add(node6);
        objLinkedList.add(node2);
        objLinkedList.add(node1);
        objLinkedList.add(node0);
        objLinkedList.add(node5);

        intCount = 0;

        ArrayList<ArrayList<Integer>> MUResult = new ArrayList<ArrayList<Integer>>();
        for (MuNum = 0; MuNum < NumberOfMU; MuNum++) {
            MUResult.add(new ArrayList<Integer>());
        }

        for (SegNum = 0; SegNum < NumberOfSegment; SegNum++) {
            int i = 0;
            for (Integer[] nodeDate : objLinkedList) {
                i++;
                intCount = intCount + 1;
                if (nodeDate[SegNum] == 1) {
                    MUResult.get(nodeDate[31]).add(SegNum);
                    objLinkedList.remove(i - 1);
                    objLinkedList.add(nodeDate);
                    break;
                }
            }
        }

        for (MuNum = 0; MuNum < NumberOfMU; MuNum++) {
            String temp = "";
            for (int i = 0; i < MUResult.get(MuNum).size(); i++) {
                temp = temp + MUResult.get(MuNum).get(i).toString();
                if (i + 1 < MUResult.get(MuNum).size()) {
                    temp = temp + ",";
                }
            }
            NodesMasterApplication.logger.info("MuNum " + MuNum + ": " + temp);
        }

        NodesMasterApplication.logger.info("Loop count: " + intCount.toString());
    }

    void JobDestributeFlatFuzzy() {
        Integer MuNum = 0;
        Integer WhichMU[] = new Integer[31];
        Integer AssignedCount = 0;
        Integer Circle = 0;
        Integer VirtualCount = 0; // will convert to MuNum by random
        Integer SegNum = 0; // segment count
        Integer NumberOfSegment = 31;
        Integer NumberOfMU = 7;
        Integer MatrixMUSegment[][] = new Integer[7][31];
        Boolean flg;
        MatrixMUSegment[0] = node0;
        MatrixMUSegment[1] = node1;
        MatrixMUSegment[2] = node2;
        MatrixMUSegment[3] = node3;
        MatrixMUSegment[4] = node4;
        MatrixMUSegment[5] = node5;
        MatrixMUSegment[6] = node6;

        intCount = 0;
        flg = true;


        // MUのセグメントピックアップ順はFuzzy配置
        // ReOrder(MyMUList);
        Integer MyMUList[] = {4, 3, 6, 2, 1, 0, 5};
        Integer MUCheckPoint[] = {0, 0, 0, 0, 0, 0, 0};
        // Integer MUResult[][] = new Integer[7][];
        ArrayList<ArrayList<Integer>> MUResult = new ArrayList<ArrayList<Integer>>();
        for (MuNum = 0; MuNum < NumberOfMU; MuNum++) {
            MUResult.add(new ArrayList<Integer>());
        }

        for (MuNum = 0; MuNum < NumberOfSegment; MuNum++) {
            WhichMU[MuNum] = -1; // no one assigned
        }


        while (flg) {
            for (VirtualCount = 0; VirtualCount < NumberOfMU; VirtualCount++) {
                MuNum = MyMUList[VirtualCount];
                for (Circle = 0; Circle < NumberOfSegment;) {
                    int intSegNum = 0;
                    if (MUCheckPoint[VirtualCount] > 0) {
                        intSegNum = MUCheckPoint[VirtualCount] + 1;
                    }
                    for (SegNum = intSegNum; SegNum < NumberOfSegment; SegNum++) {
                        intCount = intCount + 1;
                        if (WhichMU[SegNum] == -1 && MatrixMUSegment[MuNum][SegNum] == 1) {
                            WhichMU[SegNum] = MuNum;
                            MUResult.get(MuNum).add(SegNum);
                            MUCheckPoint[VirtualCount] = SegNum;
                            AssignedCount++;
                            if (AssignedCount == NumberOfSegment) {
                                for (MuNum = 0; MuNum < NumberOfMU; MuNum++) {
                                    String temp = "";
                                    for (int i = 0; i < MUResult.get(MuNum).size(); i++) {
                                        temp = temp + MUResult.get(MuNum).get(i).toString();
                                        if (i + 1 < MUResult.get(MuNum).size()) {
                                            temp = temp + ",";
                                        }
                                    }
                                    NodesMasterApplication.logger
                                    .info("MuNum " + MuNum + ": " + temp);
                                }
                                NodesMasterApplication.logger
                                .info("Loop count: " + intCount.toString());
                                flg = false;
                                return;
                            }
                            break;
                        }
                    }
                    break;
                }
            }
        }

    }
}
