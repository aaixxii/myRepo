package com.example.nodes_master.controller;

import org.springframework.context.annotation.Bean;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.ip.dsl.Udp;
import org.springframework.integration.ip.udp.UnicastSendingMessageHandler;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.stereotype.Controller;

@Controller
public class UDPAdapterController {
    public UDPAdapterController() {

    }

    // @Bean
    // public IntegrationFlow udpOutFlow() {
    //     return IntegrationFlows.from("udpOut")
    //             .handle(Udp.outboundAdapter("localhost", 1234)).get();
    // }

    @Bean
    public IntegrationFlow udpIn() {
        return IntegrationFlows.from(Udp.inboundAdapter(NodeMasterController.intUDPPort))
                .channel("udpChannel")
                .handle("UDPServerService", "handleMessage")
                .get();
    }

    public void UDPSSender(String strAddress, Integer intUDPPort, String strText) {
        UnicastSendingMessageHandler handler =
                new UnicastSendingMessageHandler(strAddress, intUDPPort);

        String payload = strText;
        handler.handleMessage(MessageBuilder.withPayload(payload).build());
    }
}
