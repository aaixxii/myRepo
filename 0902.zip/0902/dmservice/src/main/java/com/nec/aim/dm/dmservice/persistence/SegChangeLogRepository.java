package com.nec.aim.dm.dmservice.persistence;


import java.sql.SQLException;

import com.nec.aim.dm.dmservice.entity.SegChangeLog;

public interface SegChangeLogRepository {
	/**
	 * @param biometricsId
	 * @param segmentId
	 * @param segmentVer
	 * @param catchUpp
	 * @throws SQLException
	 */
	public void insertForNewSegment(Long biometricsId, Long segmentId, Long segmentVer, Integer catchUpp) throws SQLException;
	/**
	 * @param catchUp
	 * @throws SQLException
	 */
	public void insert(SegChangeLog catchUp) throws SQLException;
	/**
	 * @param catchUp
	 * @throws SQLException
	 */
	public void delete(SegChangeLog catchUp) throws SQLException;
}
