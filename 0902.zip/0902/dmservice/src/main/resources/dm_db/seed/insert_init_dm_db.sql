#insert init data todm_info table
use DMDB;

insert into storage_box(sb_id,url, disk_size, space,status, update_ts) values(1,'http://192.168.22.20:8080',200000,500000,0,CURRENT_TIMESTAMP());
insert into storage_box(sb_id,url, disk_size, space,status, update_ts) values(2,'http://192.168.22.21:8081',200000,500000,0,CURRENT_TIMESTAMP());
insert into storage_box(sb_id,url, disk_size, space,status, update_ts) values(3,'http://192.168.22.22:8082',200000,500000,0,CURRENT_TIMESTAMP());


#for election leader
#insert into node_master(master_id,dm_master_id, one_time_interval, last_ts) values(0,'dm_master1',100,CURRENT_TIMESTAMP());

insert into dm_config_info(key_name, key_value) values('redundancy',3);
insert into dm_config_info(key_name, key_value) values('segment_max_record',5000000);
insert into dm_config_info(key_name, key_value) values('segment_head_size',26);
insert into dm_config_info(key_name, key_value) values('template_size',28672); 
insert into dm_config_info(key_name, key_value) values('sync_mode','ANY'); # LOG,ANY, ALL

COMMIT;
