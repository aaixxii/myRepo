CREATE DEFINER=`aimuser`@`%` PROCEDURE `update_existing_segment`(
 in p_binary_length_compacted long,
 in p_binary_length_uncompacted long,
 in p_record_count long,
 in p_version long,
 in p_revision long,
 in p_segment_id long,
 in p_data_len long,
 out o_seg_version long,
 out o_seg_id long
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
 declare l_new_binary_len_comp long;
 declare l_new_binary_len_uncomp long;
 declare  l_new_rec_count  long;
 declare  l_new_version long;
 declare  l_new_revision long;
 declare  l_new_end  long;
DECLARE t_error INTEGER DEFAULT 0;  
declare not_found INTEGER DEFAULT 0; 
  DECLARE EXIT HANDLER FOR SQLEXCEPTION SET t_error=1;  
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET not_found=1; 
    set  l_new_binary_len_comp = p_binary_length_compacted + l_data_len + 54;                 
	set l_new_binary_len_uncomp =p_binary_length_uncompacted + 54;                  
    set  l_new_rec_count = p_record_count + 1;
	set  l_new_version = p_version + 1;
	set  l_new_revision  = p_revision + 1;
	IF l_biometrics_id > p_bio_id_end THEN
		set l_new_end := l_biometrics_id;
	ELSE
		set l_new_end = p_bio_id_end;
   END IF;
   
UPDATE SEGMENTS
SET    BINARY_LENGTH_COMPACTED = L_NEW_BINARY_LEN_COMP,
       BINARY_LENGTH_UNCOMPACTED = L_NEW_BINARY_LEN_UNCOMP,
       RECORD_COUNT = L_NEW_REC_COUNT,
       VERSION = L_NEW_VERSION,
       REVISION = L_NEW_REVISION,
       BIO_ID_END = L_NEW_END
WHERE  SEGMENT_ID = P_SEGMENT_ID
AND REVISION = P_REVISION; 

INSERT INTO SEGMENT_CHANGE_LOG
            (SEGMENT_ID,
             SEGMENT_VERSION,
             CHANGE_TYPE,
             BIOMETRICS_ID)
VALUES   ( SEG_REC.segment_id,
              L_NEW_VERSION,
              0,
              L_BIOMETRICS_ID ); 
    set o_seg_version := l_new_version;
	set o_seg_id := p_segment_id;
END