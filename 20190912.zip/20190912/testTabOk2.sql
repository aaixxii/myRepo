CREATE DEFINER=`aimuser`@`%` PROCEDURE `testTab`(
 IN  p_candidate_containers VARCHAR(1024),
 OUT v_count int
)
BEGIN
  declare v_id int;
  declare v_idx int default 999 ;
  declare v_tmp_str varchar(20);  
  DECLARE t_error INTEGER DEFAULT 0;  
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;
  	SET @dropSql=CONCAT(
			"DROP TEMPORARY TABLE IF EXISTS arr_container_ids" 
        );
		PREPARE stmt FROM @dropSql;
        EXECUTE stmt;
      DEALLOCATE PREPARE stmt;
      	SET @createSql=CONCAT(
			"create TEMPORARY table arr_container_ids(id int) engine=innodb" 
        );
		PREPARE stmt1 FROM @createSql;
        EXECUTE stmt1;
      DEALLOCATE PREPARE stmt1;      
	-- DROP TEMPORARY TABLE IF EXISTS arr_container_ids;
	-- create TEMPORARY table arr_container_ids(id int) engine=innodb; 
		while v_idx > 0 do
          SET v_idx = INSTR(p_candidate_containers,',');
          SET v_tmp_str = substr(p_candidate_containers,1,v_idx-1);    
          insert into arr_container_ids (id)  values( CAST(v_tmp_str AS UNSIGNED));
          set p_candidate_containers=substr(p_candidate_containers,v_idx +1 ,LENGTH(p_candidate_containers)); 
          if v_idx +1 = LENGTH(p_candidate_containers) then
           insert into arr_container_ids (id)  values( CAST(p_candidate_containers AS UNSIGNED));
          end if;         
      end while;     
      
     select count(id) into v_count from arr_container_ids;

END