package jp.co.nec.aim.mm.dao;

import java.sql.Timestamp;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import jp.co.nec.aim.mm.entities.RqSettingEntity;

public class AmqSettingDao {
	
	private EntityManager em;

	public AmqSettingDao(EntityManager em) {
		this.em = em;
	}	

	
	public RqSettingEntity findAmqSetting(String id) {
		return em.find(RqSettingEntity.class, id);
	}	
	
	public List<RqSettingEntity> findAllAmqSetting() {
		String allSql = "select e from RqSettingEntity e";		 
		List<RqSettingEntity> result = em.createQuery(allSql, RqSettingEntity.class).getResultList();
		return result;
	}
	
	public int updateMasterNode(String masterNode, Timestamp ts, String id) {
		Query q = em.createNamedQuery("NQ::updateMqMasterNode");
		q.setParameter("masterNode", masterNode);
		q.setParameter("newTs", ts);
		q.setParameter("id", id);
		int result =  q.executeUpdate();
		em.flush();
		return result;
	}
	
	public RqSettingEntity updateMqEntity(RqSettingEntity newRqSetting) {
		RqSettingEntity newMqSetting = em.merge(newRqSetting);
		em.flush();
		return newMqSetting;
	}	
}
