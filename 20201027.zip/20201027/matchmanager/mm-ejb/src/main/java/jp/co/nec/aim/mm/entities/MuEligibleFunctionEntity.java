package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

/**
 * The persistent class for the MU_ELIGIBLE_FUNCTIONS database table.
 * 
 */
@Entity
@IdClass(jp.co.nec.aim.mm.entities.MuEligibleFunctionEntityPK.class)
@Table(name = "MU_ELIGIBLE_FUNCTIONS")
public class MuEligibleFunctionEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "FUNCTION_ID")
	private int functionId;

	@Id
	@Column(name = "MU_ID")
	private long muId;

	public int getFunctionId() {
		return functionId;
	}

	public void setFunctionId(int functionId) {
		this.functionId = functionId;
	}

	public long getMuId() {
		return muId;
	}

	public void setMuId(long muId) {
		this.muId = muId;
	}

}