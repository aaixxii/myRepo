package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.nec.aim.dm.dmservice.entity.NodeStorageManager;
import com.nec.aim.dm.dmservice.entity.NsmIdUrl;

@Repository
public class NodeStorageManagerRepositoryImpl implements NodeStorageManagerRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private static final String sqlAll = "select * from STORAGE_BOX ";
	private static final String sqlById = "select * from STORAGE_BOX where SB_ID=? ";	
	private static final String sqlByRedundancy = "select * from STORAGE_BOX where (STATUS=1 or STATUS=0) limit ?";
	private static final String setMailFlagSql = "update STORAGE_BOX  set MAIL_FLAG ='signal' where  SB_ID =?";
	private static final String getNodeStorageBySegIdSql = "select N.* from STORAGE_BOX N, SEGMENT_LOADING S where (N.STATUS =1 or N.STATUS =0) and N.SB_ID = S.SB_ID and S.SEGMENT_ID=? limit ?";
	private static final String getNsmIplAndId = "select SB_ID, URL from STORAGE_BOX where STATUS=0 or STATUS=1 or STATUS=2";
	
	private ReentrantLock sbLock = new ReentrantLock();


	@Override
	public List<NodeStorageManager> findAll() throws SQLException {
		return jdbcTemplate.query(sqlAll, nodeRowMapper);
	}

	@Override
	public NodeStorageManager findById(Long id, String dmStrorageId) throws SQLException {
		return jdbcTemplate.queryForObject(sqlById, new Object[] { id, dmStrorageId }, nodeRowMapper);
	}

	RowMapper<NodeStorageManager> nodeRowMapper = (rs, rowNum) -> {
		NodeStorageManager node = new NodeStorageManager();
		node.setNsmId(rs.getInt("SB_ID"));
		node.setUrl(rs.getString("URL"));		
		node.setStatus(rs.getInt("STATUS"));
		node.setUpdateTs(rs.getTimestamp("UPDATE_TS"));
		return node;
	};

	@Override
	public List<NodeStorageManager> findNeedNodeByRedundancy(int redundancy) throws SQLException {
		return jdbcTemplate.query(sqlByRedundancy, new Object[] { redundancy }, nodeRowMapper);
	}

	@Override
	public void setSignalMailFlag(int storageId) {
		jdbcTemplate.execute("SET @@autocommit=0");
		if (sbLock.tryLock()) {
			try {
				jdbcTemplate.update(setMailFlagSql, new Object[] { storageId });
			} finally {
				sbLock.unlock();
			}
		}
	}

	@Override
	public List<NodeStorageManager> getNodeStorgeBySegmentId(Long segmentId, Integer redundancy) throws SQLException {
		List<NodeStorageManager> results = jdbcTemplate.query(getNodeStorageBySegIdSql,
				new Object[] { segmentId, redundancy }, nodeRowMapper);
		return results;
	}

	RowMapper<NsmIdUrl> nsmIdUrlMapper = (rs, rowNum) -> {
		NsmIdUrl nu = new NsmIdUrl();
		nu.setStorageId(rs.getInt("SB_ID"));
		nu.setBasUrl(rs.getString("URL"));
		return nu;
	};

	@Override
	public List<NsmIdUrl> getNodeStorageUrlAndId() throws SQLException {
		List<NsmIdUrl> result = jdbcTemplate.query(getNsmIplAndId, nsmIdUrlMapper);
		return result;
		
	}

	@Override
	public void commit() throws SQLException {
		jdbcTemplate.execute("commit");

	}

	@Override
	public void rollback() throws SQLException {
		jdbcTemplate.execute("rollback");
	}
}
