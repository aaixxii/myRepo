#insert init data to dm_info table
use DMDB;

insert into STORAGE_BOX(SB_ID,URL,STATUS, UPDATE_TS) values(1,'http://127.0.0.1:12000',2,CURRENT_TIMESTAMP());

insert into DM_CONFIG_INFO(KEY_NAME, KEY_VALUE) values('REDUNDANCY',3);
insert into DM_CONFIG_INFO(KEY_NAME, KEY_VALUE) values('TEMPLATE_SIZE',28672);
insert into DM_CONFIG_INFO(KEY_NAME, KEY_VALUE) values('SYNC_MODE','ANY'); # LOG,ANY, ALL

COMMIT;
