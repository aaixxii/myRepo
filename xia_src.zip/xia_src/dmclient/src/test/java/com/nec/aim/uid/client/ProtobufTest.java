package com.nec.aim.uid.client;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import jp.co.nec.aim.message.proto.AIMMessages.PBTargetSegmentVersion;

public class ProtobufTest {
	
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
	
	@Test
	public void getSyncReq () {
		PBDmSyncRequest req = testProtobuf();
		System.out.print(req.toString());
	}
	
	public PBDmSyncRequest testProtobuf() {
		PBDmSyncRequest.Builder dmRequest = PBDmSyncRequest.newBuilder();
		dmRequest.setCmd(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_NEW);
		PBTargetSegmentVersion.Builder segVer = PBTargetSegmentVersion.newBuilder();
		segVer.setId(1000);
		segVer.setVersion(-1);
		dmRequest.setTargetSegment(segVer);
		return dmRequest.build();
	}
	
	@Test
	public void testSplit() {
		String str = "aa";
		String[] strArr = str.split(",");
		int size = strArr.length;
		System.out.println(size);
		
	}
}
