package jp.co.nec.aim.mm.dm.client.mgmt;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.entities.DmServiceEntity;
import jp.co.nec.aim.mm.entities.UnitState;

public class UidDmJobRunManager {

	private static Logger logger = LoggerFactory.getLogger(UidDmJobRunManager.class);
	private static ExecutorService dmJobExecutor = Executors.newCachedThreadPool();

	private static final ScheduledExecutorService httpHeatbeatScheduler = Executors.newScheduledThreadPool(1);
	private static ExecutorService socketHeatbeatExcutor;	
	private static List<DmServiceEntity> dmSeriveList = Collections.synchronizedList(new ArrayList<DmServiceEntity>());
	private static final ConcurrentHashMap<String, String> dmsUrlMap = new ConcurrentHashMap<>(); 	

	public static void putToDmsUrlMap(String key, String value) {
		dmsUrlMap.putIfAbsent(key, value);
	}

	public static String getValueFromDmsUrlMap(String key) {
		return dmsUrlMap.get(key);
	}

	public static void setSocketHeatbeatExector(int count) {
		socketHeatbeatExcutor = Executors.newFixedThreadPool(count);
	}

	public static void sumitSocketHeatbeatJobToMe(Runnable task) {
		socketHeatbeatExcutor.submit(task);
	}

	public static void httpHeatbeatSheduleTask(Runnable task, long rate) {
		httpHeatbeatScheduler.scheduleAtFixedRate(task, 0, rate, TimeUnit.MILLISECONDS);
	}

	public static DmServiceEntity getOneActiveDm() {
		if (dmSeriveList.size() <= 0)
			return null;
		DmServiceEntity result = null;
		Collections.sort(dmSeriveList, new DmServiceComparator());
		Collections.reverse(dmSeriveList);
		for (int i = 0; i < dmSeriveList.size(); i++) {
			if (dmSeriveList.get(i).getState() == UnitState.WORKING) {
				result = dmSeriveList.get(i);
				break;
			}
		}
		if (result != null) {
			logger.info("got dm id:{} status:{} base url is:{}", result.getDmId(), result.getState().name(),result.getContactUrl());
		} else {
			logger.warn("got active dm is null");
		}		
		return result;
	}

	public static void addActiveDmServiceTome(DmServiceEntity dm) {
		if (!dmSeriveList.contains(dm)) {
			dmSeriveList.add(dm);
		}
	}

	public static void removeNoActiveDm(DmServiceEntity dm) {
		dmSeriveList.remove(dm);
	}

	public static int getActiveServiceCount() {
		return dmSeriveList.size();		
	}

	public static void submitRunnable(Runnable task) {
		dmJobExecutor.submit(task);
	}

	public static Boolean sumitDmJob(Callable<Boolean> task) {
		Future<Boolean> future = dmJobExecutor.submit(task);
		try {
			return future.get();
		} catch (InterruptedException | ExecutionException e) {
			logger.error(e.getMessage(), e);
			return Boolean.FALSE;
		}
	}

	public static <T> CompletableFuture<T> callableAsync(Callable<T> c) {
		CompletableFuture<T> cf = new CompletableFuture<>();
		dmJobExecutor.execute(() -> {
			try {
				cf.complete(c.call());

			} catch (Throwable ex) {
				cf.completeExceptionally(ex);
			}
		});
		return cf;
	}

	public static Boolean submit(Callable<Boolean> c) throws InterruptedException, ExecutionException {
		CompletableFuture<Boolean> cf = new CompletableFuture<>();
		dmJobExecutor.execute(() -> {
			try {
				cf.complete(c.call());
			} catch (Throwable ex) {
				cf.completeExceptionally(ex);
			}
		});
		return cf.get();
	}

	public static byte[] submitGetRequest(Callable<byte[]> c) throws InterruptedException, ExecutionException {
		CompletableFuture<byte[]> cf = new CompletableFuture<>();
		dmJobExecutor.execute(() -> {
			try {
				cf.complete(c.call());
			} catch (Throwable ex) {
				cf.completeExceptionally(ex);
			}
		});
		return cf.get();
	}

	public static void shutdown() {
		dmJobExecutor.shutdownNow();
		while (!dmJobExecutor.isShutdown()) {
			try {
				dmJobExecutor.awaitTermination(100, TimeUnit.MILLISECONDS);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		httpHeatbeatScheduler.shutdownNow();
		while (!httpHeatbeatScheduler.isShutdown()) {
			try {
				httpHeatbeatScheduler.awaitTermination(100, TimeUnit.MILLISECONDS);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		if (socketHeatbeatExcutor != null) {
			socketHeatbeatExcutor.shutdown();
		}
		dmSeriveList.clear();
	}
}
