package jp.co.nec.aim.mm.dm.client.mgmt;

import java.util.Comparator;

import jp.co.nec.aim.mm.entities.DmServiceEntity;
import jp.co.nec.aim.mm.entities.UnitState;

public class DmServiceComparator implements Comparator<DmServiceEntity> {

	@Override
	public int compare(DmServiceEntity d1, DmServiceEntity d2) {
		int first = -999;
		int second = -999;
		int third = -999;		
		if (d1.getState() == UnitState.WORKING && d2.getState() == UnitState.WORKING) {	
			first = d1.getState().compareTo(d1.getState());					
		} else  if (d1.getState() == UnitState.WORKING && (d2.getState() != UnitState.WORKING || d2.getState() == null)) {
			 first = 1;			
		} else if ((d1.getState() == null || d1.getState() != UnitState.WORKING) && d2.getState() == UnitState.WORKING) {
			 first = -1;			
		} 
		
		 if (d1.getState() == UnitState.TIMED_OUT && d2.getState() == UnitState.TIMED_OUT) {
			 second = d1.getState().name().compareTo(d1.getState().name());			
		} else  if (d1.getState() == UnitState.TIMED_OUT && (d2.getState() == UnitState.EXITED || d2.getState() == null)) {
			 second = 1;			
		} else if ((d1.getState() == null || d1.getState() == UnitState.EXITED) && d2.getState() == UnitState.TIMED_OUT) {
			 second = -1;			
		} 
		 
		 if (d1.getState() == UnitState.EXITED && d2.getState() == UnitState.EXITED) {
			 third = d1.getState().name().compareTo(d1.getState().name());			
		} else if (d1.getState() == UnitState.EXITED && d2.getState() == null) {
			third = 1;
		} else if (d1.getState() == null && d2.getState() == UnitState.EXITED) {
			third = -1;
		}
		return first != -999 ? first: (second != -999 ? second: third);
	}
}
