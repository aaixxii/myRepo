package com.nec.biomatcher.web.controller.templatestorage;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.nec.biomatcher.comp.template.storage.TemplateStorageService;
import com.nec.biomatcher.comp.template.storage.dataAccess.BioTemplateStorageInfo;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.web.controller.common.BaseController;

@Controller
@RequestMapping(value = "/secured/admin/templatestorage")
public class TemplateStorageController extends BaseController {

	private static final Logger logger = Logger.getLogger(TemplateStorageController.class);

	private TemplateStorageService templateStorageService = (TemplateStorageService) SpringServiceManager
			.getBean("templateStorageService");

	private enum TemplateStorageColumnOrder {
		STORAGE_ID, ROOT_PATH, ACTIVE_FLAG;
	}

	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public ModelAndView index(HttpServletRequest request) {
		logger.debug("In TemplateStorageController.index");
		return new ModelAndView("storage.list");
	}

	@RequestMapping(value = "/getTemplateStorageList", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<String> getTemplateStorageList(HttpServletRequest request) {
		logger.info("In TemplateStorageController.getTemplateStorageList: " + new Date());
		String resposne = new String("");
		List<BioTemplateStorageInfo> templateStorageInfoList = null;
		try {
			templateStorageInfoList = templateStorageService.getTemplateStorageInfoList();
		} catch (Throwable th) {
			templateStorageInfoList = Collections.emptyList();
			logger.error("Error in getTemplateStorageList: " + th.getMessage(), th);
		}

		JsonArray jsonStorageInfoArray = new JsonArray();
		if (CollectionUtils.isNotEmpty(templateStorageInfoList)) {
			for (BioTemplateStorageInfo bioTemplateStorageInfo : templateStorageInfoList) {
				JsonObject jsonObject = new JsonObject();
				jsonObject.addProperty(TemplateStorageColumnOrder.STORAGE_ID.name(),
						bioTemplateStorageInfo.getStorageId());
				jsonObject.addProperty(TemplateStorageColumnOrder.ROOT_PATH.name(),
						StringUtils.trimToEmpty(bioTemplateStorageInfo.getRootPath()));
				jsonObject.addProperty(TemplateStorageColumnOrder.ACTIVE_FLAG.name(),
						bioTemplateStorageInfo.getActiveFalg());
				jsonStorageInfoArray.add(jsonObject);
			}
		}
		JsonObject jsonResponse = new JsonObject();
		jsonResponse.add("data", jsonStorageInfoArray);
		logger.info("Total Storage Path Records : " + templateStorageInfoList.size());
		resposne = jsonResponse.toString();
		return new ResponseEntity<>(resposne, HttpStatus.OK);
	}

	@RequestMapping(value = "/addTemplateStorageInfo", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<String> addTemplateStorageInfo(HttpServletRequest request,
			BioTemplateStorageInfo templateStorageInfo) {
		try {

			String rootPath = templateStorageInfo.getRootPath();
			if (StringUtils.isEmpty(rootPath)) {
				return new ResponseEntity<>("Path can not be blank", HttpStatus.BAD_REQUEST);
			}
			List<BioTemplateStorageInfo> templateStorageInfoList = templateStorageService.getTemplateStorageInfoList();
			if (CollectionUtils.isNotEmpty(templateStorageInfoList)) {
				for (BioTemplateStorageInfo bioTemplateStorageInfo : templateStorageInfoList) {
					Path existingPath = Paths.get(bioTemplateStorageInfo.getRootPath());
					if (StringUtils.equalsIgnoreCase(rootPath, existingPath.toString())) {
						return new ResponseEntity<>(this.getMessage("errors.templateStorage.storagepath.already.exists",
								new Object[] { rootPath }, request), HttpStatus.INTERNAL_SERVER_ERROR);
					}
				}
			}

			templateStorageService.saveTemplateStorageInfo(templateStorageInfo);
			return new ResponseEntity<>(
					this.getMessage("messages.templateStorage.save.success", new Object[] { rootPath }, request),
					HttpStatus.OK);

		} catch (Throwable th) {
			logger.error("Error in addParameter: " + th.getMessage(), th);
			return new ResponseEntity<>(
					this.getMessage("errors.templateStorage.SaveStoragePathFailed",
							new Object[] { templateStorageInfo.getRootPath() }, request),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@RequestMapping(value = "/updateTemplateStorageInfo", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<String> updateTemplateStorageInfo(HttpServletRequest request) {
		try {

			String storageId = request.getParameter("pk");
			String updatedColName = request.getParameter("name");
			String value = request.getParameter("value");
			logger.debug("updateTemplateStorageInfo :: " + updatedColName + ", " + value);

			if (!StringUtils.isNumeric(storageId)) {
				return new ResponseEntity<>("Storage Id can not be blank", HttpStatus.BAD_REQUEST);
			}
			if (StringUtils.isBlank(value)) {
				return new ResponseEntity<>("Path can not be blank", HttpStatus.BAD_REQUEST);
			}

			BioTemplateStorageInfo existingTemplateStorageInfo = templateStorageService
					.getTemplateStorageInfo(Integer.parseInt(storageId));

			if ("rootPath".equalsIgnoreCase(updatedColName)) {
				List<BioTemplateStorageInfo> templateStorageInfoList = templateStorageService
						.getTemplateStorageInfoList();
				if (CollectionUtils.isNotEmpty(templateStorageInfoList)) {
					for (BioTemplateStorageInfo bioTemplateStorageInfo : templateStorageInfoList) {
						Path existingPath = Paths.get(bioTemplateStorageInfo.getRootPath());
						if (StringUtils.equalsIgnoreCase(Paths.get(value).toString(), existingPath.toString())
								&& existingTemplateStorageInfo.getStorageId().intValue() != bioTemplateStorageInfo
										.getStorageId()) {
							return new ResponseEntity<>(
									this.getMessage("errors.templateStorage.storagepath.already.exists",
											new Object[] { value }, request),
									HttpStatus.BAD_REQUEST);
						}
					}
				}

				existingTemplateStorageInfo.setRootPath(value);
				templateStorageService.updateTemplateStorageInfo(existingTemplateStorageInfo);

			} else if ("activeFalg".equalsIgnoreCase(updatedColName)) {
				logger.info("updatedColName :: activeFalg");
				existingTemplateStorageInfo.setActiveFalg(Boolean.valueOf(value));
				templateStorageService.updateTemplateStorageInfo(existingTemplateStorageInfo);
			}

			return new ResponseEntity<>(
					this.getMessage("messages.templateStorage.update.success", new Object[] {}, request),
					HttpStatus.OK);

		} catch (Throwable th) {
			logger.error("Error in updateTemplateStorageInfo: " + th.getMessage(), th);
			return new ResponseEntity<>(
					this.getMessage("errors.templateStorage.updateStoragePathFailed", new Object[] {}, request),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@RequestMapping(value = "/deleteTemplateStorageInfo", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<String> deleteTemplateStorageInfo(HttpServletRequest request,
			@RequestParam("storageId") String storageId) {
		try {

			if (StringUtils.isNumeric(storageId)) {
				return new ResponseEntity<>("Storage Id can not be blank", HttpStatus.BAD_REQUEST);
			}

			templateStorageService.deleteTemplateStorageInfo(Integer.parseInt(storageId));
			return new ResponseEntity<>(
					this.getMessage("messages.templateStorage.delete.success", new Object[] {}, request),
					HttpStatus.OK);

		} catch (Throwable th) {
			logger.error("Error in deleteTemplateStorageInfo: " + th.getMessage(), th);
			return new ResponseEntity<>(
					this.getMessage("errors.templateStorage.deleteStoragePathFailed", new Object[] {}, request),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
