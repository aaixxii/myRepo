package com.nec.biomatcher.web.controller.parameter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.common.parameter.dataAccess.BioParameter;
import com.nec.biomatcher.comp.common.parameter.dataAccess.BioParameterScope;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.spec.transfer.model.KeyValuePair;
import com.nec.biomatcher.web.controller.common.BaseController;

@Controller
@RequestMapping(value = "/secured/admin/parameter")
public class SystemParameterController extends BaseController {

    private static final Logger logger = Logger.getLogger(SystemParameterController.class);

    private BioParameterService bioParameterService = (BioParameterService) SpringServiceManager.getBean("bioParameterService");

    private enum ParameterColumnOrder {
        PARAM_NAME, PARAM_VALUE, PARAM_DESC, PARAM_SCOPE, PARAM_DATATYPE;
    }

    @RequestMapping(value = "/index", method = RequestMethod.GET)
    public ModelAndView index(HttpServletRequest request) {
        logger.debug("In SystemParameterController.index");
        return new ModelAndView("parameters.list");
    }

    @RequestMapping(value = "/getParameterList", method = RequestMethod.GET)
    @ResponseBody
    public ResponseEntity<String> getParameterList(HttpServletRequest request) {
        logger.info("In SystemParameterController.getParameterList: " + new Date());
        String resposne = new String("");
        List<BioParameter> parameterList = null;
        try {
            boolean includeVariableScope = bioParameterService.getParameterValue("PARAMETER_LIST_DISPLAY_VARIABLE_SCOPE_FLAG", "ADMIN", false);
            parameterList = bioParameterService.getParameterList(includeVariableScope);
        } catch (Throwable th) {
            parameterList = new ArrayList<BioParameter>();
            logger.error("Error in getParameterList: " + th.getMessage(), th);
        }

        JsonArray jsonParameterArray = new JsonArray();
        if (CollectionUtils.isNotEmpty(parameterList)) {
            for (BioParameter bioParameter : parameterList) {
                JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty(ParameterColumnOrder.PARAM_NAME.name(), StringUtils.trimToEmpty(bioParameter.getName()));
                jsonObject.addProperty(ParameterColumnOrder.PARAM_DESC.name(), StringUtils.trimToEmpty(bioParameter.getDescription()));
                jsonObject.addProperty(ParameterColumnOrder.PARAM_SCOPE.name(), StringUtils.trimToEmpty(bioParameter.getScope()));
                jsonObject.addProperty(ParameterColumnOrder.PARAM_VALUE.name(), StringUtils.trimToEmpty(bioParameter.getValue()));
                jsonObject.addProperty(ParameterColumnOrder.PARAM_DATATYPE.name(), StringUtils.trimToEmpty(bioParameter.getDataType()));
                jsonParameterArray.add(jsonObject);
            }
        }
        JsonObject jsonResponse = new JsonObject();
        jsonResponse.add("data", jsonParameterArray);
        logger.info("Total Parameter Records : " + parameterList.size());
        resposne = jsonResponse.toString();
        return new ResponseEntity<>(resposne, HttpStatus.OK);
    }

    @RequestMapping(value = "/getParameterScopeList", method = RequestMethod.GET)
    @ResponseBody
    public ResponseEntity<String> getParameterScopeList(HttpServletRequest request) {
        JsonArray jsonParameterScopeArray = new JsonArray();
        for (BioParameterScope bioParameterScope : getScopeList()) {
            JsonObject paramScopeJson = new JsonObject();

            paramScopeJson.addProperty("id", bioParameterScope.getScopeName());
            paramScopeJson.addProperty("text", bioParameterScope.getScopeName());

            jsonParameterScopeArray.add(paramScopeJson);
        }

        JsonObject jsonObject = new JsonObject();
        jsonObject.add("data", jsonParameterScopeArray);

        return new ResponseEntity<>(jsonObject.toString(), HttpStatus.OK);
    }

    @RequestMapping(value = "/getParameterDataTypeList", method = RequestMethod.GET)
    @ResponseBody
    public ResponseEntity<String> getParameterDataTypeList(HttpServletRequest request) {
        JsonArray jsonParameterDataTypeArray = new JsonArray();

        for (KeyValuePair<String, String> dataType : getDataTypeList()) {
            JsonObject paramDataTypeJson = new JsonObject();

            paramDataTypeJson.addProperty("id", dataType.getKey());
            paramDataTypeJson.addProperty("text", dataType.getValue());

            jsonParameterDataTypeArray.add(paramDataTypeJson);
        }

        JsonObject jsonResponse = new JsonObject();
        jsonResponse.add("data", jsonParameterDataTypeArray);
        return new ResponseEntity<>(jsonResponse.toString(), HttpStatus.OK);
    }

    @ModelAttribute("dataTypeList")
    public List<KeyValuePair<String, String>> getDataTypeList() {
        return Arrays.asList(new KeyValuePair<String, String>("STRING", "STRING"), new KeyValuePair<String, String>("BOOLEAN", "BOOLEAN"), new KeyValuePair<String, String>("NUMBER", "NUMBER"));
    }

    @ModelAttribute("scopeList")
    public List<BioParameterScope> getScopeList() {
        try {
            return bioParameterService.getParameterScopeList();
        } catch (Throwable th) {
            logger.error("Error in getScopeList: " + th.getMessage(), th);
        }
        return new ArrayList<>();
    }

    @RequestMapping(value = "/addParameter", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<String> addParameter(HttpServletRequest request, BioParameter parameter) {
        try {
            if (StringUtils.isNotBlank(parameter.getName())) {
                BioParameter existingBioParameter = bioParameterService.getParameter(StringUtils.trim(parameter.getName()), StringUtils.trim(parameter.getScope()));
                if (existingBioParameter != null) {
                    return new ResponseEntity<>(this.getMessage("errors.systemParameter.systemParameter.already.exists", new Object[] { parameter.getName() }, request), HttpStatus.INTERNAL_SERVER_ERROR);
                }
            }

            bioParameterService.saveParameterValue(StringUtils.trim(parameter.getName()), StringUtils.trim(parameter.getScope()), StringUtils.trim(parameter.getDataType()), StringUtils.trim(parameter.getDescription()), StringUtils.trim(parameter.getValue()));

            return new ResponseEntity<>(this.getMessage("messages.systemParam.save.success", new Object[] { parameter.getName() }, request), HttpStatus.OK);

        } catch (Throwable th) {
            logger.error("Error in addParameter: " + th.getMessage(), th);
            return new ResponseEntity<>(this.getMessage("errors.systemParameter.SaveSystemParamFailed", new Object[] { parameter.getName() }, request), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/updateParameter", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<String> updateParameter(HttpServletRequest request) {
        String parameterNameScope = request.getParameter("pk");
        String paramName = StringUtils.trimToNull(StringUtils.substringBefore(parameterNameScope, "&"));
        String scope = StringUtils.trimToNull(StringUtils.substringAfter(parameterNameScope, "&"));
        String updatedColName = request.getParameter("name");
        String value = request.getParameter("value");
        try {

            logger.info("In updateParameter: parameterName: " + paramName + ", parameterScope: " + scope + ", updatedColName: " + updatedColName + ", value: " + value);
            if (paramName == null) {
                return new ResponseEntity<>("Name can not be blank", HttpStatus.BAD_REQUEST);
            }

            if (scope == null) {
                return new ResponseEntity<>("Scope can not be blank", HttpStatus.BAD_REQUEST);
            }

            BioParameter bioParameter = bioParameterService.getParameter(paramName, scope);

            if ("scope".equals(updatedColName)) {
                if (!StringUtils.equals(bioParameter.getScope(), value)) {
                    bioParameterService.deleteParameter(bioParameter.getName(), bioParameter.getValue());
                }
                bioParameter.setScope(scope);
            } else if ("description".equals(updatedColName)) {
                bioParameter.setDescription(value);
            } else if ("dataType".equals(updatedColName)) {
                bioParameter.setDataType(value);
            } else if ("value".equals(updatedColName)) {
                bioParameter.setValue(value);
            }

            bioParameterService.saveParameter(bioParameter);

            return new ResponseEntity<>(this.getMessage("messages.systemParam.update.success", new Object[] { paramName }, request), HttpStatus.OK);

        } catch (Throwable th) {
            logger.error("Error in updateParameter: " + th.getMessage(), th);
            return new ResponseEntity<>(this.getMessage("errors.systemParameter.SaveSystemParamFailed", new Object[] { parameterNameScope }, request), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @RequestMapping(value = "/deleteParameter", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<String> deleteParameter(HttpServletRequest request) {
        String parameterName = request.getParameter("parameterName");
        String parameterScope = request.getParameter("parameterScope");
        logger.info("In deleteParameter: parameterName: " + parameterName + ", parameterScope: " + parameterScope);
        try {
            bioParameterService.deleteParameter(StringUtils.trim(parameterName), StringUtils.trim(parameterScope));
            return new ResponseEntity<>(this.getMessage("messages.systemParam.delete.success", new Object[] { parameterName }, request), HttpStatus.OK);
        } catch (Throwable th) {
            logger.error("Error in deleteParameter: " + th.getMessage(), th);
            return new ResponseEntity<>(this.getMessage("errors.systemParameter.DelSystemParamFailed", new Object[] { parameterName }, request), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
