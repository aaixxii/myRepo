package com.nec.biomatcher.web.controller.login;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.nec.biomatcher.comp.admin.BioAdminService;
import com.nec.biomatcher.comp.admin.exception.BioAdminServiceException;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;
import com.nec.biomatcher.core.framework.web.session.UserSession;
import com.nec.biomatcher.spec.transfer.model.KeyValuePair;
import com.nec.biomatcher.web.modules.login.LoginForm;

@Controller
public class LoginController {

	private Logger logger = Logger.getLogger(this.getClass().getName());

	private BioAdminService bioAdminService = (BioAdminService) SpringServiceManager.getBean("bioAdminService");

	@RequestMapping(value = "/login/preLogin", method = RequestMethod.GET)
	public ModelAndView preLogin(HttpServletRequest request) {
		logger.debug("preLogin");
		return new ModelAndView("preLogin");
	}

	@RequestMapping(value = "/login/index", method = RequestMethod.GET)
	public ModelAndView initPage(Model model) {
		model.addAttribute("loginForm", new LoginForm());
		return new ModelAndView("login", "localeLangList", getLocaleLanguageList());
	}

	@RequestMapping(value = "/login/doLogin", method = RequestMethod.POST)
	public ModelAndView doLogin(HttpServletRequest request, LoginForm loginForm) {
		boolean hasError = false;
		try {
			UserSession userSession = bioAdminService.login(loginForm.getUserId(), loginForm.getPassword());
			request.getSession(false).setAttribute(UserSession.attributeName, userSession);
		} catch (BioAdminServiceException ex) {
			ex.printStackTrace();
			request.setAttribute("localeLangList", getLocaleLanguageList());
			hasError = true;
		} catch (Exception e) {
			logger.error("Error login: " + e.getMessage(), e);
			request.setAttribute("localeLangList", getLocaleLanguageList());
			hasError = true;
		}

		if (hasError) {
			return new ModelAndView("login");
		} else {
			return new ModelAndView("redirect:/secured/home/index.htm");
		}
	}

	@RequestMapping(value = "/login/logout", method = RequestMethod.GET)
	public ModelAndView logout(HttpServletRequest request) {
		logger.debug("logout");
		request.getSession().invalidate();
		return new ModelAndView("preLogin");
	}

	public List<KeyValuePair<String, String>> getLocaleLanguageList() {
		List<KeyValuePair<String, String>> localeLangList = new ArrayList<>();

		KeyValuePair<String, String> nsysCode = new KeyValuePair<String, String>("en_EN", "st.language.english");
		localeLangList.add(nsysCode);

		return localeLangList;
	}
}
