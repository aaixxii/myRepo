package com.nec.biomatcher.web.modules.login;

/**
 * The Class SecurityQuestionParameter
 * 
 * @author Peddi Swapna
 * 
 */
public class SecurityQuestionParameter implements Comparable<SecurityQuestionParameter> {

	public SecurityQuestionParameter() {
	}

	public int compareTo(SecurityQuestionParameter obj) {
		/* CDI fixes */
		if (this.getDisplayOrder().equals(obj.getDisplayOrder()))
			return 0;
		else if (this.getDisplayOrder() > obj.getDisplayOrder())
			return 1;
		else
			return -1;
	}

	/** The field id. */
	private String fieldId;

	/** The field name. */
	private String fieldName;

	/** The field description. */
	private String fieldDescription;

	/** The field value. */
	private String fieldValue;

	/** The display order. */
	private Integer displayOrder;

	public String getFieldId() {
		return fieldId;
	}

	public void setFieldId(String fieldId) {
		this.fieldId = fieldId;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getFieldDescription() {
		return fieldDescription;
	}

	public void setFieldDescription(String fieldDescription) {
		this.fieldDescription = fieldDescription;
	}

	public String getFieldValue() {
		return fieldValue;
	}

	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}

	public Integer getDisplayOrder() {
		return displayOrder;
	}

	public void setDisplayOrder(Integer displayOrder) {
		this.displayOrder = displayOrder;
	}

}
