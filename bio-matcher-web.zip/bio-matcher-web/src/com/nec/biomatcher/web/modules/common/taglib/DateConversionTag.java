package com.nec.biomatcher.web.modules.common.taglib;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.log4j.Logger;

public class DateConversionTag extends TagSupport {
	private static final long serialVersionUID = 1L;

	private static final Logger _logger = Logger.getLogger(DateConversionTag.class);

	private String format;

	private Date date;

	public DateConversionTag() {
		format = null;

		date = null;
	}

	public void release() {
		super.release();
		format = null;
		date = null;
	}

	public int doStartTag() throws JspException {
		try {
			pageContext.getOut().print(convertToDate());
		} catch (Exception e) {
			_logger.error("Error occured while converting the date:" + date + ", error:" + e.getMessage(), e);
			// throw new JspException("Error:" + e.getMessage());
		}
		return SKIP_BODY;
	}

	public String convertToDate() {
		if (date != null) {
			return parseDateTime(date, pageContext.getRequest().getLocale());
		}
		return "";
	}

	/**
	 * Description: This method parsed java.util.Date type to java.lang.String
	 * by specified string format
	 *
	 * @param date
	 *            the date
	 * @param format
	 *            the format
	 * @return the string
	 */
	public static String parseDateTime(java.util.Date date, Locale locale) {
		if (date != null) {
			return DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM, locale).format(date);
		}
		return "";
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

}
