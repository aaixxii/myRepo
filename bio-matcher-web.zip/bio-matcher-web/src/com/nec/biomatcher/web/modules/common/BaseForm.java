package com.nec.biomatcher.web.modules.common;

import java.io.Serializable;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

public abstract class BaseForm implements Serializable {

	private static final long serialVersionUID = 1L;

	private String mode;

	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

}
