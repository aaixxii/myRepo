package com.nec.biomatcher.web.modules.common.taglib;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.TagSupport;

import com.nec.biomatcher.core.framework.web.session.UserSession;

/**
 * Checks user has access to specified function. If yest then it proceeds with
 * evaluating the body Otherwise it will skip the body
 * 
 */
public class CheckUserPrivilegeTag extends TagSupport {
	private static final long serialVersionUID = 1L;

	public CheckUserPrivilegeTag() {
	}

	public void release() {
		super.release();
	}

	public int doStartTag() throws JspException {
		boolean result = condition();
		return result ? EVAL_BODY_INCLUDE : SKIP_BODY;
	}

	private boolean condition() throws JspTagException {
		UserSession userSession = (UserSession) pageContext.getSession().getAttribute(UserSession.attributeName);

		return userSession != null;
	}
}
