package com.nec.aim.uid.client.poster;

import static com.nec.aim.uid.client.common.UidClientConstants.DEFALUT_MM_BASE_URL;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.aim.uid.client.common.SequenceIdCreator;
import com.nec.aim.uid.client.common.SequenceIdType;
import com.nec.aim.uid.client.exception.UidClientException;
import com.nec.aim.uid.client.logger.PerformanceLogger;
import com.nec.aim.uid.client.manager.ExecutorManager;
import com.nec.aim.uid.client.manager.UidCommonManager;
import com.nec.aim.uid.client.result.writer.SyncResultWriter;
import com.nec.aim.uid.client.util.StopWatch;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import jp.co.nec.aim.message.proto.BatchTypeProto.BatchType;
import jp.co.nec.aim.message.proto.BusinessMessage.E_BIOMETRIC_DATA_FORMAT;
import jp.co.nec.aim.message.proto.BusinessMessage.E_REQUESET_TYPE;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBiometricElement;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBiometricsData;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBParameterGroup;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequestParameter;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequestParameters;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;
import jp.co.nec.aim.message.proto.SyncService.SyncRequest;
import jp.co.nec.aim.message.proto.SyncService.SyncResponse;


public class SyncJobPoster implements Runnable {
	private String syncParaFilePath;
	private Long syncJobTimeOut;	
	private String mmBaseUrl;
	private long batchId;
	private String requestId;
	private Properties prop = new Properties();
	private static Logger logger = LoggerFactory.getLogger("HttpPostLogger");	
	private static final String SYNC_URL = "AIMSyncService/sync";	
	 private static final MediaType MEDIA_TYPE_PLAINTEXT = MediaType.parse("text/plain; charset=utf-8");
	public SyncJobPoster(String paraFilePath ) {
		this.syncParaFilePath = paraFilePath;
	}	

	@Override
	public void run() {			
		SyncResponse syncRes = null;
		SyncRequest syncReq = buildSyncRequest();
//		 NumberFormat nfNum = NumberFormat.getNumberInstance();
//		 nfNum.setMinimumIntegerDigits(64);
//		 nfNum.setGroupingUsed(false);
//		logger.info("prepare post sync job batchJobId={}, requestId={}", nfNum.format(batchId), requestId);
		logger.trace("prepare post sync job batchJobId={}, requestId={}", batchId, requestId);
		String syncPostUrl = mmBaseUrl.endsWith("/") ? mmBaseUrl + SYNC_URL: mmBaseUrl +"/" + SYNC_URL;		
		OkHttpClient client = new OkHttpClient();
		client.setConnectTimeout(syncJobTimeOut/4, TimeUnit.MILLISECONDS); 
		client.setReadTimeout(syncJobTimeOut/4, TimeUnit.SECONDS); 
		client.setWriteTimeout(syncJobTimeOut/2, TimeUnit.SECONDS); 
		final StopWatch t = new StopWatch();
		t.start();
		  Request request = new Request.Builder()
			      .url(syncPostUrl)
			      .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, syncReq.toByteArray()))
			      .build();
		  try {
			Response response = client.newCall(request).execute();	
			t.stop();
			PerformanceLogger.trace("extractPost", batchId, requestId, t.elapsedTime());
			syncRes = SyncResponse.parseFrom(response.body().bytes());
			SyncResultWriter writeTask = new SyncResultWriter(syncRes.toBuilder());
			ExecutorManager.getInstance().commitWriteTask(writeTask);
			logger.trace("batchJobId:{} http status:{}", this.batchId, response.code());			
		  } catch (Exception e) {
			  logger.error(e.getMessage(), e);
		  }		
	}
	
	public SyncRequest buildSyncRequest() {		
		 SyncRequest.Builder syncReq =  SyncRequest.newBuilder();
		 batchId = SequenceIdCreator.createNextSequence(SequenceIdType.BATCHJOB_ID);		
		 syncReq.setBatchJobId(batchId);
		 PBBusinessMessage.Builder syncPbMsg = PBBusinessMessage.newBuilder();
			PBRequest.Builder req = PBRequest.newBuilder();
			requestId = String.valueOf(SequenceIdCreator.createNextSequence(SequenceIdType.REQUST_ID));
			req.setRequestId(requestId);
		try (InputStream input = new FileInputStream(syncParaFilePath)) {
			prop.load(input);
			mmBaseUrl = UidCommonManager.getValue(DEFALUT_MM_BASE_URL);	
			syncJobTimeOut = Long.valueOf(prop.getProperty("SYNC_JOB_TIME_OUT"));			
			String batchJobType = prop.getProperty("BATCH_TYPE");
			String eRequestType = prop.getProperty("E_REQUESET_TYPE");
			if (batchJobType == null || eRequestType == null) {
				throw new UidClientException("batchJobType or bioDataFormat is null!");	
			}
			syncReq.setType(BatchType.valueOf(batchJobType));
			req.setRequestType(E_REQUESET_TYPE.valueOf(eRequestType));			
			String enrollmentID = UUID.randomUUID().toString().toUpperCase();
			req.setEnrollmentId(enrollmentID);	
			PBBiometricsData.Builder bioData = PBBiometricsData.newBuilder();
			String bioDataFormat = prop.getProperty("E_BIOMETRIC_DATA_FORMAT");
			if (batchJobType == null || bioDataFormat == null) {
				throw new UidClientException("batchJobType or bioDataFormat is null!");				
			}
			bioData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.valueOf(bioDataFormat));
			PBBiometricElement.Builder bioElement = PBBiometricElement.newBuilder();			
			if (eRequestType.equals(E_REQUESET_TYPE.INSERT_REFID_DEFAULT.name())) {
				PBTemplateInfo.Builder template = PBTemplateInfo.newBuilder();
				String templateReferenceId = prop.getProperty("TEMPLATE_REFERENCE_ID");
				template.setReferenceId(templateReferenceId);
				bioElement.setTemplateInfo(template.build());
			} else if (eRequestType.equals(E_REQUESET_TYPE.INSERT_REFURL_DEFAULT.name())) {
				String templateFileUrl = prop.getProperty("BINARY_DATA_FILE_PATH");
				String checkSum = prop.getProperty("CHECKSUM");
				bioElement.setFilePath(templateFileUrl);
				bioElement.setChecksum(checkSum);
			}		
			bioData.setBiometricElement(bioElement.build());
			req.setBiometricsData(bioData.build());
			PBRequestParameters.Builder syncReqParam = PBRequestParameters.newBuilder();
			Integer groupNameCount = Integer.valueOf(prop.getProperty("GROUP_NAME_COUNT"));	
			for (int i = 1; i <= groupNameCount; i++) {
				String requestParamters = prop.getProperty("REQUEST_PARAMETER" + i);
				String[] paramArr = requestParamters.split("#");
				String gpName = paramArr[0];
				String keyValusList = paramArr[1];
				String[] keyValueArr = keyValusList.split(",");
				PBParameterGroup.Builder pbPG = PBParameterGroup.newBuilder();
				pbPG.setGroupName(gpName);
				for (int j = 0; j < keyValueArr.length; j++) {
					PBRequestParameter.Builder pbParam = PBRequestParameter.newBuilder();
					String[] tmp = keyValueArr[j].split(":");
					pbParam.setParameterName(tmp[0]);
					pbParam.setParameterValue(tmp[1]);
					pbPG.addRequestParameter(pbParam.build());
				}
				syncReqParam.addParameterGroup(pbPG.build());
			}	
			req.setRequestParameters(syncReqParam.build());
			syncPbMsg.setRequest(req.build());
			syncReq.addBusinessMessage(syncPbMsg.build().toByteString());			
			return syncReq.build();
			
		} catch (Exception e) {			
			throw new UidClientException(e.getMessage(), e);
		}		
	}
}
