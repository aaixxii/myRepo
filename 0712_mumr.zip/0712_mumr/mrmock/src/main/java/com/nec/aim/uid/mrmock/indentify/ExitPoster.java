package com.nec.aim.uid.mrmock.indentify;

import com.nec.aim.uid.mrmock.post.HttpPoster;
import com.nec.aim.uid.mrmock.protobuf.ProtobufCreater;

import jp.co.nec.aim.message.proto.AIMEnumTypes.ComponentType;
import jp.co.nec.aim.message.proto.AIMMessages.PBExitRequest;

public class ExitPoster {
	public ExitPoster() {		
	}
	
	public void exitToMM() {
		String url = "http://127.0.0.1:8080/matchmanager/Exit";
		PBExitRequest pbExit = ProtobufCreater.buildPBExitRequest(ComponentType.MAP_REDUCER);
		HttpPoster.post(url, pbExit.toByteArray());
	}

}
