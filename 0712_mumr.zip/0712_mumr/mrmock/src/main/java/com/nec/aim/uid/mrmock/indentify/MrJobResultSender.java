package com.nec.aim.uid.mrmock.indentify;

import com.nec.aim.uid.mrmock.post.HttpPoster;
import com.nec.aim.uid.mrmock.protobuf.ProtobufCreater;

import jp.co.nec.aim.message.proto.AIMMessages.PBMapInquiryJobRequest;
import jp.co.nec.aim.message.proto.AIMMessages.PBMapInquiryJobResult;

public class MrJobResultSender implements Runnable{
	private PBMapInquiryJobRequest mrJobReq;
	public MrJobResultSender(PBMapInquiryJobRequest mrJobReq) {
		this.mrJobReq = mrJobReq;		
	}

	@Override
	public void run() {	
		PBMapInquiryJobResult mrJobRes = ProtobufCreater.buildPBMapInquiryJobResult(this.mrJobReq);
		String url = "http://127.0.0.1:8080/matchmanager/InquiryJobComplete";		
		HttpPoster.doIdentifyComplete(url, mrJobRes.toByteArray());		
	}
}
