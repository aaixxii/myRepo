package com.nec.aim.uid.mrmock.indentify;

import com.google.protobuf.InvalidProtocolBufferException;
import com.nec.aim.uid.mrmock.constants.Configer;
import com.nec.aim.uid.mrmock.post.HttpPoster;
import com.nec.aim.uid.mrmock.protobuf.ProtobufCreater;

import jp.co.nec.aim.message.proto.AIMEnumTypes.ComponentType;
import jp.co.nec.aim.message.proto.AIMMessages.PBComponentInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBEnterResponse;

public class EnterPoster {
	
	public EnterPoster() {
		
	}
	public void entertoMM() throws InvalidProtocolBufferException {
		
		PBComponentInfo enterReq = ProtobufCreater.buildEnterReqeust(ComponentType.MAP_REDUCER, "http://127.0.0.1:8085", "http://127.0.0.1:8085");	
		String url = "http://127.0.0.1:8080/matchmanager/Enter";
		byte[] enterRespose = HttpPoster.post(url, enterReq.toByteArray());
		PBEnterResponse enterRes = PBEnterResponse.parseFrom(enterRespose);	
		System.out.print(enterRes.toString());
		Configer.setMrId(enterRes.getId());
	}
}
