package com.nec.aim.uid.mrmock;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MockApplicationTests {

	@Test
	void contextLoads() {
	}

}
