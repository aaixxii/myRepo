package jp.co.nec.aim.mm.dao;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import jp.co.nec.aim.mm.entities.SegmentEntity;

/**
 * SegmentDao
 * 
 * @author liuyq
 * 
 */
public class SegmentDao {

	private EntityManager manager;

	public SegmentDao(EntityManager manager) {
		this.manager = manager;
	}

	/**
	 * findSegment
	 * 
	 * @param segId
	 * @return SegmentEntity instance
	 */
	public SegmentEntity findSegment(long segId) {
		return manager.find(SegmentEntity.class, segId);
	}
	
	public int updateSegmentVersin(long segVersion, long revesion, long segmetId) {
		Query q = manager.createNamedQuery("NQ::updateSegmentVersion");
		q.setParameter("segVer", segVersion);
		q.setParameter("revision", revesion);
		q.setParameter("segId", segmetId);
		int result =  q.executeUpdate();
		manager.flush();
		return result;
	}	

}
