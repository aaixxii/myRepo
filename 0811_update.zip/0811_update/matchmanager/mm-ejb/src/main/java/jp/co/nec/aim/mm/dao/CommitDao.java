package jp.co.nec.aim.mm.dao;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

public class CommitDao {

	private JdbcTemplate jdbcTemplate;

	public CommitDao(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	/**
	 * commit operation
	 */
	public void commit() {
		jdbcTemplate.execute("COMMIT");
	}
	
	public void rollback() {
		jdbcTemplate.execute("ROLLBACK");
	}

}
