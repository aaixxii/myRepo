package jp.co.nec.aim.mm.exception;

public class XmlException extends RuntimeException {

	private static final long serialVersionUID = 2626082645396399681L;

	public XmlException(String message) {
		super(message);
	}

	public XmlException(Throwable cause) {
		super(cause);
	}

	public XmlException(String message, Throwable cause) {
		super(message, cause);
	}

}
