package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.jfree.util.Log;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

/**
 * 
 * @author xiazp
 *
 */
public class BatchJobInfoProcedures extends StoredProcedure {
	private static final String CREATE_NEW_BATCH_JOB_INFO = "MATCH_MANAGER_API.CREATE_NEW_BATCH_JOB_INFO";

	public BatchJobInfoProcedures(DataSource dataSource) {
		setDataSource(dataSource);		
		setSql(CREATE_NEW_BATCH_JOB_INFO);
		declareParameter(new SqlParameter("p_batch_job_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_reqeust_id", Types.VARCHAR));
		declareParameter(new SqlParameter("p_batch_type", Types.VARCHAR));	
		declareParameter(new SqlParameter("p_fe_job_id", Types.BIGINT));	
		compile();
	}
	
	public void createNewBatchJobInfo(long batchJobId, String requestId, String batchType, long internalJobid) throws SQLException {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_batch_job_id", Long.valueOf(batchJobId));
		map.put("p_reqeust_id",  requestId);
		map.put("p_batch_type",  batchType);
		map.put("p_fe_job_id",  Long.valueOf(internalJobid));
		if (internalJobid > 0) {
			map.put("p_fe_job_id",  Long.valueOf(internalJobid));
		} else {
			map.put("p_fe_job_id",  null);
		}
		execute(map);
	}	
}
