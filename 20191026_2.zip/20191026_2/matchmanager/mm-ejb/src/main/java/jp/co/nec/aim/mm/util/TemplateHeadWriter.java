package jp.co.nec.aim.mm.util;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

public class TemplateHeadWriter {
	// Template Header field sizes in byte
		public static final int SIZE_CHECKSUM = 1;
		public static final int SIZE_TSZ = 4;
		public static final int SIZE_TEMPLATE_ID = 8;
		public static final int SIZE_DELETE_FLAG = 1;
		public static final int SIZE_EXTERNAL_ID = 36;
		public static final int SIZE_EVENT_ID = 4;
		public static final int SIZE_TEMPLATE_HEADER = SIZE_TSZ + SIZE_TEMPLATE_ID
				+ SIZE_DELETE_FLAG + SIZE_EXTERNAL_ID + SIZE_EVENT_ID;
		public static final int SIZE_TEMPLATE_HEADER_CHECKSUM = SIZE_TEMPLATE_HEADER + SIZE_CHECKSUM; 
		
		public  byte[] prependHeader(long templateId, byte[] templateData, String externalId, int eventId) {
			if(templateId <= 0L) {
				throw new IllegalArgumentException(
						"TemplateId must be positive long, it's " + templateId);
			}
			if (templateData == null) {
				throw new IllegalArgumentException(
						"Attempting to prepend header onto null template");
			}
			if(externalId == null) {
				throw new IllegalArgumentException("externalId is null!");
			}
			byte[] bytesOfExtId = externalId.getBytes(StandardCharsets.UTF_8);		
			int writeTtotalTemplateSize = SIZE_TEMPLATE_HEADER_CHECKSUM + templateData.length ;
			int totalTemplateSize = SIZE_TEMPLATE_HEADER;
			byte[] byteTempateArr = new byte[writeTtotalTemplateSize];
			ByteBuffer byteTemplate = ByteBuffer.wrap(byteTempateArr);
			byte[] emptyOneByte = new byte[1];
			byteTemplate.position(0);	
			byteTemplate.put(emptyOneByte); //checkSum
			byteTemplate.putInt(totalTemplateSize);
			byteTemplate.putLong(templateId);
			byteTemplate.put((byte)0); // delete flag
			byteTemplate.put(bytesOfExtId); 
			int blankExtIdSize = SIZE_EXTERNAL_ID - bytesOfExtId.length;			
			if (blankExtIdSize > 0) {				
				byteTemplate.put(new byte[blankExtIdSize]); 
			}
			if (eventId > 0)  {
				byteTemplate.putInt(eventId);
			} else {
				byteTemplate.put(new byte[SIZE_EVENT_ID]);
			}
			byteTemplate.put(templateData);	
			return byteTempateArr;			
		}
}
