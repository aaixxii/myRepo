package jp.co.nec.aim.mm.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;

import javax.jms.Connection;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author liuyq
 */
public final class SafeCloseUtil {

	private static Logger log = LoggerFactory.getLogger(SafeCloseUtil.class);

	/**
	 * constructor
	 */
	private SafeCloseUtil() {
	}

	/**
	 * safeClose resource
	 * 
	 * @param InputStream
	 */
	public static void close(InputStream is) {
		if (is != null) {
			try {
				is.close();
				is = null;
			} catch (IOException e) {
				log.error("close InputStream error.", e);
			}
		}
	}

	/**
	 * safeClose resource
	 * 
	 * @param OutputStream
	 */
	public static void close(OutputStream os) {
		if (os != null) {
			try {
				os.close();
				os = null;
			} catch (IOException e) {
				log.error("close OutputStream error.", e);
			}
		}
	}

	/**
	 * safeClose resource
	 * 
	 * @param PrintWriter
	 */
	public static void close(PrintWriter pw) {
		if (pw != null) {
			pw.close();
			pw = null;
		}
	}

	/**
	 * safeClose resource
	 * 
	 * @param InitialContext
	 */
	public static void close(InitialContext context) {
		if (context != null) {
			try {
				context.close();
				context = null;
			} catch (NamingException e) {
				log.error("close InitialContext error.", e);
			}
		}
	}

	/**
	 * safeClose resource
	 * 
	 * @param producer
	 */
	public static void close(MessageProducer producer) {
		if (producer != null) {
			try {
				producer.close();
				producer = null;
			} catch (JMSException e) {
				log.error("close MessageProducer error.", e);
			}
		}
	}

	/**
	 * safeClose resource
	 * 
	 * @param session
	 */
	public static void close(Session session) {
		if (session != null) {
			try {
				session.close();
				session = null;
			} catch (JMSException e) {
				log.error("close Session error.", e);
			}
		}
	}

	/**
	 * safeClose resource
	 * 
	 * @param connect
	 */
	public static void close(Connection connect) {
		if (connect != null) {
			try {
				connect.close();
				connect = null;
			} catch (JMSException e) {
				log.error("close Connection error.", e);
			}
		}
	}

}
