package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.identify.planner.MuCpuAndPressure;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class GetMuPressureAbilityProcedureTest extends
		AbstractTransactionalJUnit4SpringContextTests {
	@PersistenceContext(unitName = "aim-db")
	protected EntityManager entityManager;
	@Resource
	protected DataSource dataSource;
	@Resource
	protected JdbcTemplate jdbcTemplate;
	private GetMuPressureAbilityProcedure muAbilityDao;

	@Before
	public void setUp() throws Exception {
		muAbilityDao = new GetMuPressureAbilityProcedure(dataSource);
		jdbcTemplate.execute("delete from FE_LOT_JOBS");
		jdbcTemplate.execute("delete from MATCH_UNITS");
		jdbcTemplate.execute("delete from MU_EXTRACT_LOAD");
		jdbcTemplate.execute("commit");
	}

	@After
	public void tearDown() throws Exception {
		muAbilityDao = null;
		jdbcTemplate.execute("delete from FE_LOT_JOBS");
		jdbcTemplate.execute("delete from MATCH_UNITS");
		jdbcTemplate.execute("delete from MU_EXTRACT_LOAD");
		jdbcTemplate.execute("commit");
	}

	@Test
	public void testGetMuPressureAndAbility() {
		Integer[] muIds = { 1, 2, 3, 4, 5 };
		String[] muStatus = { "WORKING", "WORKING", "WORKING", "timeout",
				"exit" };
		Integer[] muCpus = { 4, 8, 12, 8, 16 };
		Double[] reportedPerformanceFactor = { 1.8D, 1.8D, 2.4D, 1.8D, 2.4D };
		Long[] muPressure = { 4l, 5l, 6l, 7l, 8l };
		Long updateTS = new Long(System.currentTimeMillis());
		String insertMuSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_MATCHERS,REPORTED_PERFORMANCE_FACTOR) "
				+ "VALUES(?,?,?,?,?)";
		String inquiryLoadSql = "INSERT INTO MU_INQUIRY_LOAD (MU_ID, PRESSURE, REPORT_TS)  VALUES(?,?,?)";

		for (int i = 0; i < muIds.length; i++) {
			jdbcTemplate.update(insertMuSql,
					new Object[] { muIds[i], muIds[i].toString(), muStatus[i],
							muCpus[i], reportedPerformanceFactor[i] });
			jdbcTemplate.update(inquiryLoadSql, new Object[] { muIds[i],
					muPressure[i], updateTS });
			jdbcTemplate.execute("commit");
		}
		List<MuCpuAndPressure> rsults = null;
		try {
			rsults = muAbilityDao.getMuPressureAndAbility(muIds);
		} catch (DataAccessException | SQLException e) {
			e.printStackTrace();
		}
		Assert.assertNotNull(rsults);
		Assert.assertEquals(3, rsults.size());
		for (int i = 0; i < rsults.size(); i++) {
			Assert.assertEquals(muIds[i].intValue(), rsults.get(i).getMuId());
			Assert.assertEquals(muPressure[i].longValue(), rsults.get(i)
					.getPressure());
			double expected = muCpus[i] * reportedPerformanceFactor[i];
			double real = rsults.get(i).getAbility();
			Assert.assertTrue(expected - real < 0.000001);
			Assert.assertEquals(updateTS.longValue(), rsults.get(i)
					.getReportTs());
		}
	}

	@Test
	public void testGetMuPressureAndAbility_No_data() {
		Integer[] muIds = { 1, 2, 3, 4, 5 };
		List<MuCpuAndPressure> Rsults = null;
		try {
			Rsults = muAbilityDao.getMuPressureAndAbility(muIds);
		} catch (DataAccessException | SQLException e) {
			e.printStackTrace();
		}
		Assert.assertEquals(0, Rsults.size());
	}
}
