package jp.co.nec.aim.mm.sessionbeans;

import static org.junit.Assert.assertEquals;

import javax.annotation.Resource;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.dao.DateDao;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class BinDefragBeanTest {

	@Resource
	private DataSource dataSource;
	@Resource
	private BinDefragBean binDefragBean;

	private JdbcTemplate jdbcTemplate;

	/**
	 * insertSystemInitBinId
	 */
	private void insertSystemInitBinId(long binid) {
		final Long curTime = new DateDao(dataSource).getCurrentTimeMS();
		jdbcTemplate.update("insert into SEGMENT_DEFRAGMENTATION("
				+ "CONTAINER_ID, START_TS, END_TS) values(" + binid + ", "
				+ curTime + ", " + curTime + ")");
	}

	private void delete() {
		jdbcTemplate.execute("delete from SEGMENT_DEFRAGMENTATION");
		jdbcTemplate.execute("delete from SYSTEM_CONFIG");
		jdbcTemplate.execute("commit");
	}

	@Before
	public void setUp() throws Exception {
		jdbcTemplate = new JdbcTemplate(dataSource);
		delete();
		insertSystemInitBinId(-1);
	}

	@After
	public void tearDown() throws Exception {
		delete();
	}

	private void init(int value) {
		jdbcTemplate.execute("update SEGMENT_DEFRAGMENTATION set CONTAINER_ID="
				+ value);
	}

	@Test
	public void testStartBinDefrag_true() {
		int sendbinid = 1;
		int initbinid = -1;
		init(initbinid);
		int binId01 = jdbcTemplate.queryForObject(
				"select CONTAINER_ID from SEGMENT_DEFRAGMENTATION",
				Integer.class);
		assertEquals(binId01, initbinid);

		jdbcTemplate.execute("commit");

		int resultbinid = binDefragBean.startBinDefrag(sendbinid);
		assertEquals(sendbinid, resultbinid);
	}

	@Test
	public void testStartBinDefrag_false() {
		int binid = 1;
		int sendbinid = 4;
		int result = -2;
		init(binid);
		int binId01 = jdbcTemplate.queryForObject(
				"select CONTAINER_ID from SEGMENT_DEFRAGMENTATION",
				Integer.class);
		assertEquals(binId01, binid);

		jdbcTemplate.execute("commit");

		int resultbinid = binDefragBean.startBinDefrag(sendbinid);
		assertEquals(result, resultbinid);
	}

	@Test
	public void testStopBinDefrag_true() {
		int sendbinid = 4;
		int initbinid = 4;
		int resbinid = -1;
		init(initbinid);
		int binId01 = jdbcTemplate.queryForObject(
				"select CONTAINER_ID from SEGMENT_DEFRAGMENTATION",
				Integer.class);
		assertEquals(binId01, initbinid);

		jdbcTemplate.execute("commit");

		int resultbinid = binDefragBean.stopBinDefrag(sendbinid);
		assertEquals(resbinid, resultbinid);
	}

	@Test
	public void testStopBinDefrag_false() {
		int sendbinid = 4;
		int initbinid = 5;
		init(initbinid);
		int binId01 = jdbcTemplate.queryForObject(
				"select CONTAINER_ID from SEGMENT_DEFRAGMENTATION",
				Integer.class);
		assertEquals(binId01, initbinid);

		jdbcTemplate.execute("commit");

		int resultbinid = binDefragBean.stopBinDefrag(sendbinid);
		assertEquals(initbinid, resultbinid);
	}

}
