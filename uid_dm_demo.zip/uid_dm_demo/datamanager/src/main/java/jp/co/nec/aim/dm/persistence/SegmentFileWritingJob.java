package jp.co.nec.aim.dm.persistence;

import jp.co.nec.aim.dm.constants.JobState;
import jp.co.nec.aim.dm.constants.WriteAction;
import jp.co.nec.aim.dm.exception.DataManagerException;
import jp.co.nec.aim.dm.log.LogConstants;
import jp.co.nec.aim.dm.log.PerformanceLogger;
import jp.co.nec.aim.dm.manager.SegmentFileManager;
import jp.co.nec.aim.dm.manager.SegmentFileState;
import jp.co.nec.aim.dm.util.StopWatch;

import org.jboss.logging.NDC;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;

public class SegmentFileWritingJob implements Runnable {

	private static Logger log = LoggerFactory.getLogger(SegmentFileWritingJob.class);
	private SegmentFileState state;
	private SegmentFileWriter fw;
	private JobState jobState;

	public SegmentFileWritingJob(SegmentFileState state) {
		this.state = state;
		jobState = JobState.WAITING_TO_RUN;
	}

	public synchronized String getJobState() {
		if (jobState == JobState.EXECUTING) {
			return "Executing: " + fw.getJobState();
		} else {
			return jobState.name();
		}
	}

	private synchronized void updateJobState(JobState jobState) {
		this.jobState = jobState;
	}

	public void run() {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		updateJobState(JobState.RUNNING);		
		NDC.push("DM|WRITE");
		log
				.debug("SegmentFileWritingThread about to acquire write lock on segment: "
						+ state.getSegmentId());

		// as in the segment reading servlet, the lock order acquisition is
		// critical...
		// the write lock must be obtained first, THEN internal SegmentFileState
		// state
		// can be accessed and modified (startAction(), finishAction(),
		// failAction()).
		updateJobState(JobState.WAITING_FOR_WRITE_LOCK);
		state.acquireWriteLock();
		updateJobState(JobState.ACQUIRED_WRITE_LOCK);
		try {
			log.debug("Acquired write lock on segment Id: "
					+ state.getSegmentId().toString());
			// state.startAction() is synchronized and sets a boolean flag
			// inside the SegmentFileState object that will prohibit any further
			// state changes by any other thread (in this case, that's just the
			// communication thread attempting to call scheduleWrite(). the only
			// way that the flag is unset is by this thread subsequently calling
			// finishAction()
			// or failAction().
			WriteAction neededAction = state.startAction();
			fw = getBean(neededAction);

			updateJobState(JobState.EXECUTING);
			SegmentFileWriteResult fwr = fw.execute(state.getSegmentId(), state.getVersion());
			state.finishAction(fwr);
		} catch (Throwable t) {
			log.error("Caught exception during write fw, failing fw", t);
			state.failAction();
		} finally {
			state.releaseWriteLock();
			updateJobState(JobState.DONE);
			log.debug("Released write lock on segment Id "
					+ state.getSegmentId().toString());

			stopWatch.stop();
			PerformanceLogger.log(LogConstants.COMPONENT_DM, getClass()
					.getSimpleName(), Thread.currentThread().getStackTrace()[1].getMethodName(), 
					stopWatch.elapsedTime());
			NDC.clear();
		}

	}

	private SegmentFileWriter getBean(WriteAction action) {
		ApplicationContext appContext = SegmentFileManager.getInstance()
				.getAppContext();
		switch (action) {
		case NO_OP:
			return (SegmentFileWriter) appContext.getBean("segmentFileNoOp");
		case CREATE:
			return (SegmentFileWriter) appContext.getBean("segmentFileCreator");
		case DELETE:
			return (SegmentFileWriter) appContext.getBean("segmentFileDeleter");
		case UPDATE:
			return (SegmentFileWriter) appContext.getBean("segmentFileUpdater");
		case COMPACTION:
			return (SegmentFileWriter) appContext.getBean("segmentFileCompactor");
		case RE_CREATE:
			return (SegmentFileWriter) appContext.getBean("segmentFileReCreator");
		default:
			throw new DataManagerException("Unknown Write Action: " + action);
		}
	}
}
