package jp.co.nec.aim.dm.web;

import static javax.servlet.http.HttpServletResponse.SC_SERVICE_UNAVAILABLE;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.aim.dm.constants.DMConstants;
import jp.co.nec.aim.dm.log.LogConstants;
import jp.co.nec.aim.dm.log.PerformanceLogger;
import jp.co.nec.aim.dm.manager.SegmentFileManager;
import jp.co.nec.aim.dm.manager.SegmentFileState;
import jp.co.nec.aim.dm.util.DownLoadLimiter;
import jp.co.nec.aim.dm.util.StopWatch;

import org.jboss.logging.NDC;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Erik Vandekieft
 * @web.servlet name="SegmentServletRemote" load-on-startup="1"
 * @web.servlet-mapping url-pattern="/segs/*"
 */
public class SegmentServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7736070740785208676L;
	private static Logger log = LoggerFactory.getLogger(SegmentServlet.class);
	private SegmentFileManager segFileManager;
	private DownLoadLimiter limiter;

	public void init(ServletConfig servletConfig) throws ServletException {
		segFileManager = (SegmentFileManager) servletConfig.getServletContext()
				.getAttribute(DataManagerListener.SEGMENT_FILE_MANAGER);
		limiter = DownLoadLimiter.getInstance();
	}

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		
		NDC.push("DM|GETSEGMENT");
		Integer segmentId = new Integer(req.getPathInfo().substring(1));

		// if the number of Parallel request is over max limit
		// response SC_SERVICE_UNAVAILABLE status..
		if (!limiter.isAllowable()) {
			log.warn(
					"Received Segment download request(MU IP:{}, "
							+ "segment ID:{}). But DM has already kept {}"
							+ " segment download request. Return HTTP status:{}",
					new Object[] { req.getRemoteHost(), segmentId,
							limiter.getLimit(), SC_SERVICE_UNAVAILABLE });
			res.setStatus(SC_SERVICE_UNAVAILABLE);
			return;
		}

		try {
			log.debug("Received GET for path: " + req.getPathInfo()
					+ " (segment ID: " + segmentId + ")");
			SegmentFileState segState = segFileManager.getState(segmentId);
			if (segState != null) {
				// lock order very important! first must acquire read lock,
				// THEN access SegmentFileState object internal state.
				// (isOnDisk(),
				// getInputStream()).
				// Otherwise, internal state could have changed between calls.
				// For example, it would be INCORRECT to check isOnDisk(),
				// then acquire the read lock: after calling isOnDisk(), a write
				// thread could potentially
				// have acquired the write lock, deleted the segment, and
				// released
				// the write lock. acquiring
				// the read lock first ensures that no write thread can be
				// executing
				// from that point
				// until the read lock is released.

				// checking isWriteInProgress() before acquiring the read lock
				// is purely a performance optimization that allows
				// clients to avoid getting blocked on the write lock most of
				// the
				// time (it is not sufficient
				// by itself; one still MUST acquire the read lock before
				// proceeding
				// for the reasons described
				// above), then check the internal state again.

				if (!segState.isWriteInProgress()) {
					try {
						segState.acquireReadLock();
						if (segState.isOnDisk()) {
							File segmentFile = segState.getFile();
							long length = segmentFile.length();
							InputStream segInputStream = new FileInputStream(
									segmentFile);
							log.info("Responding to GET segment_id="
									+ segmentId + " for MU:"
									+ req.getRemoteAddr() + ". Length: "
									+ length + " bytes. Buffer size:"
									+ res.getBufferSize() + ". Sending...");
							res.setContentType("application/binary");
							res.addHeader("Content-Length",
									Long.toString(length));
							res.setHeader("Content-Disposition",
									"attachment; filename=" + segmentId
											+ DMConstants.SEG_FILE_EXTENSION);
							sendSegment(segmentId, res, segInputStream);
						} else {
							log.warn("Segment "
									+ segmentId
									+ " not yet created, returning HTTP 404 not found");
							res.sendError(HttpServletResponse.SC_NOT_FOUND,
									"Segment " + segmentId + " is not on disk.");
						}
					} finally {
						log.debug("Released read lock on segment Id: "
								+ segmentId);
						segState.releaseReadLock();
					}
				} else {
					log.warn("Segment " + segmentId
							+ " is currently being written to, client should"
							+ " try again later... sending HTTP 409");
					res.sendError(
							HttpServletResponse.SC_CONFLICT,
							"Segment "
									+ segmentId
									+ " is currently being written to. Please come back later.");
				}
			} else {
				log.warn("Segment status for segment id " + segmentId
						+ " unknown, returning HTTP 404 not found");
				res.sendError(HttpServletResponse.SC_NOT_FOUND, "Segment "
						+ segmentId + " unknown.");
			}

			stopWatch.stop();
			PerformanceLogger.log(LogConstants.COMPONENT_DM, getClass()
					.getSimpleName(), Thread.currentThread().getStackTrace()[1]
					.getMethodName(), stopWatch.elapsedTime());
		} finally {
			limiter.finished();
			NDC.clear();
		}
	}

	private void sendSegment(int segmentId, HttpServletResponse res,
			InputStream segInputStream) throws IOException {
		long t1 = System.nanoTime();
		byte[] buf = new byte[1024];
		int read = 0;
		int total = 0;
		while ((read = segInputStream.read(buf)) > 0) {
			res.getOutputStream().write(buf, 0, read);
			total += read;
		}
		long t2 = System.nanoTime();
		double elapsedMS = (double) (t2 - t1) / (double) 1000000;
		double bps = (double) total * 8 / (elapsedMS / 1000);
		log.debug("For segment " + segmentId + ", Sent " + total
				+ " bytes down HTTP socket. Took " + elapsedMS
				+ " ms (transfer rate: " + bps + " bps)");
	}
}
