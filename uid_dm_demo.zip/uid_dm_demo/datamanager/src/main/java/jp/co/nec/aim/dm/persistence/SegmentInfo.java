package jp.co.nec.aim.dm.persistence;

/**
 * Header info of Segment File
 * @author kurosu
 *
 */
public class SegmentInfo {
	private long segmentId;
	private long bioIdStart;
	private long bioIdEnd;
	private int embeddedId;
	private long maxSegmentSize;
	private int recordCount;
	private int version;

	public int getEmbeddedId() {
		return embeddedId;
	}
	public void setEmbeddedId(int embeddedId) {
		this.embeddedId = embeddedId;
	}
	public long getMaxSegmentSize() {
		return maxSegmentSize;
	}
	public void setMaxSegmentSize(long maxSegmentSize) {
		this.maxSegmentSize = maxSegmentSize;
	}
	public int getRecordCount() {
		return recordCount;
	}
	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public long getBioIdStart() {
		return bioIdStart;
	}
	public void setBioIdStart(long bioIdStart) {
		this.bioIdStart = bioIdStart;
	}
	public long getBioIdEnd() {
		return bioIdEnd;
	}
	public void setBioIdEnd(long bioIdEnd) {
		this.bioIdEnd = bioIdEnd;
	}
	public long getSegmentId() {
		return segmentId;
	}
	public void setSegmentId(long segmentId) {
		this.segmentId = segmentId;
	}

}
