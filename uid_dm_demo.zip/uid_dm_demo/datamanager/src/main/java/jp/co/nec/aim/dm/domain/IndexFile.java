package jp.co.nec.aim.dm.domain;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import jp.co.nec.aim.dm.properties.DynamicProperties;
import jp.co.nec.aim.dm.properties.DynamicPropertyNames;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.RegexFileFilter;


public class IndexFile {
	private final static int NAME_LENGTH = 6;
	public final static String FORMAT = String.format("%%0%dd",NAME_LENGTH);
	public static final String SUFFIX = "index";
	
	private long segmentId;
	private String name;

	public static List<IndexFile> listIndexFile() {
		String dir = DynamicProperties.getInstance().getPropertyValue(
				DynamicPropertyNames.SEGMENT_FILE_DIRECTORY);
		RegexFileFilter filter = new RegexFileFilter("\\..*\\." + SUFFIX);
		File directory = new File(dir);
		Collection<File> files = FileUtils.listFiles(directory, filter, null);	
		List<IndexFile> indexFiles = new ArrayList<IndexFile>();
		for(File file : files) {
			int index = file.getName().lastIndexOf(".");
			String num = file.getName().substring(1, index);
			long segmentId = Long.valueOf(num).longValue();
			indexFiles.add(new IndexFile(segmentId));
		}
		return indexFiles;
	}

	public IndexFile(long segmentId) {
		this.segmentId = segmentId;
		String dir = DynamicProperties.getInstance().getPropertyValue(
				DynamicPropertyNames.SEGMENT_FILE_DIRECTORY);
		StringBuffer sb = new StringBuffer();
		sb.append(dir);
		if (!dir.endsWith("/")) {
			sb.append("/");
		}
		sb.append(".");
		sb.append(String.format(FORMAT, segmentId));
		sb.append(".");
		sb.append(SUFFIX);
		this.name = sb.toString();
	}

	public String getName() {
		return name;
	}
	
	public long getSegmentId() {
		return segmentId;
	}

	
}
