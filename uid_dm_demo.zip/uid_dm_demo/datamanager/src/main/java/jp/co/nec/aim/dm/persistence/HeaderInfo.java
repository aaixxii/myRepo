package jp.co.nec.aim.dm.persistence;

public class HeaderInfo {

	public static final int SIZE_HEADER_VERSION = 4;
	public static final int SIZE_SEGMENT_GROUP = 2;
	public static final int SIZE_MAX_SEGMENT_FILE_LENGTH = 8;
	public static final int SIZE_RECORD_COUNT = 4;
	public static final int SIZE_CHECK_SUM = 1;
	public static final int SIZE_SEGMENT_FILE_HEADER = 26;

}
