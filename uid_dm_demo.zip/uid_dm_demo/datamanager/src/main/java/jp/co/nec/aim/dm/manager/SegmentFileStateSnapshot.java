package jp.co.nec.aim.dm.manager;

import java.util.Date;
import java.util.List;

import jp.co.nec.aim.dm.constants.SegmentStatusValue;

import org.apache.commons.lang.builder.ToStringBuilder;

public class SegmentFileStateSnapshot {
	private final int segmentId;
	private final SegmentStatusValue statusValue;
	private final Integer version; // if null, not on disk
	private final Integer serverVersion;
	private final String writeJobState;
	private final boolean writeJobInProgress;
	private final Date lastFailure;
	private final int deletesAfterSegmentation;
	private final List<Long> badTemplateIds;

	public SegmentFileStateSnapshot(int segmentId,
			SegmentStatusValue statusValue, Integer version,
			Integer serverVersion, String writeJobState,
			boolean writeJobInProgress, Date lastFailure,
			int deletesAfterSegmentation, List<Long> badTemplateIds) {
		this.segmentId = segmentId;
		this.statusValue = statusValue;
		this.version = version;
		this.serverVersion = serverVersion;
		this.writeJobState = writeJobState;
		this.writeJobInProgress = writeJobInProgress;
		this.lastFailure = lastFailure;
		this.deletesAfterSegmentation = deletesAfterSegmentation;
		this.badTemplateIds = badTemplateIds;
	}

	public List<Long> getBadTemplateIds() {
		return badTemplateIds;
	}

	public int getDeletesAfterSegmentation() {
		return deletesAfterSegmentation;
	}

	public Date getLastFailure() {
		return lastFailure;
	}

	public int getSegmentId() {
		return segmentId;
	}

	public SegmentStatusValue getStatusValue() {
		return statusValue;
	}

	public Integer getServerVersion() {
		return serverVersion;
	}

	public Integer getVersion() {
		return version;
	}

	public boolean isWriteJobInProgress() {
		return writeJobInProgress;
	}

	public String getWriteJobState() {
		return writeJobState;
	}

	public String toString() {

		return new ToStringBuilder(this).append("segmentId", segmentId).append(
				"version", version).append("serverVersion", serverVersion)
				.append("writeJobState", writeJobState).append(
						"writeJobInProgress", writeJobInProgress).append(
						"lastFailure", lastFailure).append(
						"deletesAfterSegmentation", deletesAfterSegmentation)
				.toString();

	}

}
