/**
 * 
 */
package jp.co.nec.aim.dm.web;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import jp.co.nec.aim.dm.manager.IndexManager;
import jp.co.nec.aim.dm.manager.SegmentFileManager;
import jp.co.nec.aim.dm.properties.Version;

/**
 * @author RKumarak
 * @web:listener
 */
public class DataManagerListener implements ServletContextListener {

	public static final String SEGMENT_FILE_MANAGER = "SegmentFileManager";

	/*
	 * (non-Javadoc)
	 * 
	 * @seejavax.servlet.ServletContextListener#contextDestroyed(javax.servlet.
	 * ServletContextEvent)
	 */
	public void contextDestroyed(ServletContextEvent sce) {
		IndexManager.getInstance().saveAllIndex();
		SegmentFileManager sfm = SegmentFileManager.getInstance();
		sfm.shutdown();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.servlet.ServletContextListener#contextInitialized(javax.servlet
	 * .ServletContextEvent)
	 */
	public void contextInitialized(ServletContextEvent sce) {
		ServletContext sc = sce.getServletContext();
		Version.loadVersion(sc);
		SegmentFileManager sfm = SegmentFileManager.getInstance();
		IndexManager.getInstance();
		sfm.startCommucationThread();
		sc.setAttribute(SEGMENT_FILE_MANAGER, sfm);
	}

}
