package jp.co.nec.aim.dm.util;

import java.io.File;
import java.util.List;

import jp.co.nec.aim.dm.properties.DynamicProperties;
import jp.co.nec.aim.dm.properties.DynamicPropertyNames;

import org.apache.commons.io.FileUtils;

public class SegFileUtil {
	public static void removeIndexAndSegment() {
		String dir = DynamicProperties.getInstance().getPropertyValue(
				DynamicPropertyNames.SEGMENT_FILE_DIRECTORY);
		// List all files which has "sum" extension , under dir includes sub
		// directory.
		List<File> fileList = (List<File>) FileUtils.listFiles(
				new File(dir),
				new String[] { ".sum".substring(1, ".sum".length()),
						".index".substring(1, ".index".length()),
						".seg".substring(1, ".seg".length()) }, true);
		for (File sumFile : fileList) {
			if (sumFile.exists()) {
				if (!sumFile.delete()) {
					System.out.println("can not delete file");
				}
			}
		}
	}

}
