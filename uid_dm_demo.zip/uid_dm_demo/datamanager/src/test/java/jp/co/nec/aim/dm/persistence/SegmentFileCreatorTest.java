package jp.co.nec.aim.dm.persistence;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;

import jp.co.nec.aim.dm.domain.SegmentFileName;
import jp.co.nec.aim.dm.util.SegmentUtil;
import jp.co.nec.aim.helper.SegmentFileConstants;

import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

/**
 * Test class for SegmentFileCreator
 * 
 * @author kurosu
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class SegmentFileCreatorTest {
	private static final Logger log = LoggerFactory
			.getLogger(SegmentFileCreatorTest.class);
	@Resource
	private JdbcTemplate jdbcTemplate;
	@Resource
	private SegmentFileCreator segmentFileCreator;

	@Before
	public void before() {
		jdbcTemplate.execute("delete from person_biometrics");
		// jdbcTemplate.execute("delete from mu_jobs");
		jdbcTemplate.execute("delete from segments");
		SegmentUtil.createDir();
	}

	@After
	public void after() {
		SegmentUtil.cleanSegmentFile();
	}

	/**
	 * Create 5 Segments, SEGMENT_ID=1..4 have 40 records, SEGMENT_ID=5 has 30
	 * records
	 * 
	 * @throws IOException
	 */
	@Test
	public void testExecute() throws IOException {
		int records = 230;
		int unit = 40;
		int templateSize = 100;
		SegmentUtil.insertSegmentRecords(records, unit, templateSize,
				jdbcTemplate);
		int version = 1;

		int segmentId;
		for (segmentId = 1; segmentId <= 5; segmentId++) {
			segmentFileCreator.execute(segmentId, version);
			checkSegmentFile(segmentId, unit, templateSize);
		}
		segmentFileCreator.execute(segmentId, version);
		checkSegmentFile(segmentId, 30, templateSize);
	}

	/**
	 * SegmentFileCreater gets 10,000 Templates in once. Gets templates 3 times
	 * for 25,000 Templates.
	 * 
	 * @throws IOException
	 */
	@Test
	public void testExecute_25000TemplatesSegment() throws IOException {
		int records = 25000;
		int unit = 30000;
		int templateSize = 10;
		SegmentUtil.insertSegmentRecords(records, unit, templateSize,
				jdbcTemplate);
		int version = 1;

		int segmentId = 1;
		segmentFileCreator.execute(segmentId, version);
		checkSegmentFile(segmentId, records, templateSize);
	}

	@Test
	public void testExecute_TemplateAddedOnTheWay() throws IOException,
			InterruptedException, ExecutionException {
		int records = 2000;
		int unit = 10000;
		int templateSize = 40000;
		try {
			SegmentUtil.insertSegmentRecords(records, unit, templateSize,
					jdbcTemplate);
			jdbcTemplate.update("commit");
			int version = 1;
			int segmentId = 1;
			int toAddTempltes = 100;
			ScheduledExecutorService service = Executors
					.newScheduledThreadPool(5);
			Future<Long> createFuture = service.schedule(new CreateTask(
					segmentFileCreator, segmentId, version), 1000L,
					TimeUnit.MILLISECONDS);
			Future<Long> addFuture = service.schedule(
					new AddBioTask(jdbcTemplate, (long) segmentId,
							templateSize, toAddTempltes), 1100,
					TimeUnit.MILLISECONDS);

			Long createStartTime = createFuture.get();
			Long addStartTime = addFuture.get();
			assertTrue(createStartTime.longValue() < addStartTime.longValue());
			checkSegmentFile(segmentId, records, templateSize);
		} finally {
			before();
			jdbcTemplate.execute("commit");
		}
	}

	/**
	 * Test case for http://10.84.75.229/actiontracker/view.php?id=2381#bugnotes
	 * 
	 * @throws IOException
	 */
	@Test
	public void testExecuteNoRecordSegment() throws IOException {
		int segmentId = 1;
		int version = 0;
		// SEGMENT_HEADER_SIZE = 26
		String sql = "INSERT INTO SEGMENTS (SEGMENT_ID, container_id, VERSION, BIO_ID_START, BIO_ID_END, "
				+ "RECORD_COUNT,  BINARY_LENGTH_COMPACTED, BINARY_LENGTH_UNCOMPACTED, REVISION) VALUES(1, 1, 0, 0, 0, 0, 26, 26, 0)";
		jdbcTemplate.update(sql);
		segmentFileCreator.execute(segmentId, new Integer(version));

		SegmentFileName segFileName = new SegmentFileName(segmentId);
		File segFile = new File(segFileName.getName());
		assertTrue(segFile.exists());
		byte[] array = FileUtils.readFileToByteArray(segFile);

		ByteBuffer bb = ByteBuffer.wrap(array);
		assertEquals(SegmentFileCreator.AIM_VERSION, bb.getInt());
		assertEquals((short) 1, bb.getShort()); // EMBEDDED_ID
		assertEquals(20000000L, bb.getLong()); // MAX_SEGMENT_SIZE
		assertEquals(0, bb.getInt()); // RECORD_COUNT
		assertEquals(0L, bb.getLong()); // VERSION
	}

	/**
	 * Task to add template into PERSON_BIOMETRICS
	 * 
	 * @author kurosu
	 * 
	 */
	class AddBioTask implements Callable<Long> {
		private JdbcTemplate jdbcTemplate;
		private long segmentId;
		private int templateSize;
		private int toAdd;

		public AddBioTask(JdbcTemplate jdbcTemplate, long segmentId,
				int templateSize, int toAdd) {
			this.jdbcTemplate = jdbcTemplate;
			this.segmentId = segmentId;
			this.templateSize = templateSize;
			this.toAdd = toAdd;
		}

		@Override
		public Long call() throws Exception {
			Long startTime = new Long(System.currentTimeMillis());
			int start = 0;
			int end = -1;
			int step = 5;
			while (start < toAdd) {
				end += step;
				if (toAdd <= end) {
					end = toAdd - 1;
				}
				for (int i = start; i <= end; i++) {
					SegmentUtil.addTemplate(segmentId, templateSize,
							jdbcTemplate);
				}
				jdbcTemplate.execute("commit");
				log.info("Added " + step
						+ " templates into PERSON_BIOMETRICS for segmentId = "
						+ segmentId);
				Thread.sleep(100L);
				start += step;
			}
			return startTime;
		}

	}

	/**
	 * Class to create segment<br/>
	 * call() returns start timestamp.
	 * 
	 * @author kurosu
	 * 
	 */
	class CreateTask implements Callable<Long> {
		private SegmentFileCreator creator;
		private int segmentId;
		private int version;

		public CreateTask(SegmentFileCreator segmentFileCreator, int segmentId,
				int version) {
			this.creator = segmentFileCreator;
			this.segmentId = segmentId;
			this.version = version;
		}

		@Override
		public Long call() throws Exception {
			Long startTime = new Long(System.currentTimeMillis());
			creator.execute(segmentId, version);
			return startTime;
		}

	}

	@Test
	public void testExecute_SegmentHasNotAllTemplates() throws IOException {
		int records = 200;
		int unit = 100;
		int templateSize = 33;
		SegmentUtil.insertSegmentRecords(records, unit, templateSize,
				jdbcTemplate);
		for (long id = 1; id <= 100; id += 20) {
			jdbcTemplate.update(
					"delete from PERSON_BIOMETRICS where BIOMETRICS_ID=?",
					new Long(id));
		}

		segmentFileCreator.execute(1, null);

		segmentFileCreator.execute(2, null);
		checkSegmentFile(2, unit, templateSize);
	}

	private void checkSegmentFile(int segmentId, int records, int templateSize)
			throws IOException {
		SegmentFileName segFileName = new SegmentFileName(segmentId);
		File segFile = new File(segFileName.getName());
		assertTrue(segFile.exists());
		byte[] contents = FileUtils.readFileToByteArray(segFile);
		ByteBuffer bb = ByteBuffer.wrap(contents);
		assertEquals(SegmentFileCreator.AIM_VERSION, bb.getInt());
		assertEquals((short) 1, bb.getShort()); // EMBEDDED_ID
		assertEquals(20000000L, bb.getLong()); // MAX_SEGMENT_SIZE
		assertEquals(records, bb.getInt()); // RECORD_COUNT
		assertEquals((long) (records - 1), bb.getLong()); // VERSION
		assertEquals(
				SegmentFileConstants.SEGMENT_HEADER_SIZE
						+ records
						* (templateSize + SegmentFileConstants.SIZE_TEMPLATE_HEADER_CHECKSUM),
				contents.length);
	}

}