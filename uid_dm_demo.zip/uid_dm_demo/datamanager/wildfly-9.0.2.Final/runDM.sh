#!/bin/sh
PWD=`pwd`

function remove {
	clear
	echo ======================================
	echo
	echo "rm -rf standalone/data/*"
	echo "rm -rf standalone/tmp/*"
	echo "rm -rf standalone/log/*"
	echo -n "remove these dirs ? [y/n] => "
	read ANS
	if [ $ANS = 'y' -o $ANS = 'Y' ]; then
		rm -rf standalone/data/*
		rm -rf standalone/tmp/*
		rm -rf standalone/log/*
	else
		echo "delete canceld"
		echo "$PWD is not started!"
		exit
	fi
	echo
	echo ======================================
}

if [ "$1" == "-x" ]; then
	remove
fi

find ./standalone/deployments/ -name "*.undeployed" -exec rm -f {} \; 
nohup bin/standalone.sh -c standalone-full.xml -bmanagement 0.0.0.0 -b 0.0.0.0 > nohup.out &
echo "$PWD is starting ....."
sleep 1
cat nohup.out
LOGDIR=standalone/log
LOG=$LOGDIR/info.log
mkdir -p $LOGDIR
touch $LOG
tail -f $LOG
