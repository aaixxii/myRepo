---- How to update version in pom.xml ----
DataManager is single module project.
You can update version in pom.xml by hand, but I recommend you to use 
 version-maven-plugin for safety update.
 
To update version in pom.xml, follow the next steps.

1. Update version with version:set command.
 > mvn versions:set -DnewVersion=[X.X.X]
 
2. Confirm build success, no error.
 > mvn clean package
 
3. Remove local backup copy of pom.xml
 > mvn versions:commit
 
 version-maven-plugin creates a local backup copy pom.xml.versionsBackup.
 versions:commit removes this copy file.
