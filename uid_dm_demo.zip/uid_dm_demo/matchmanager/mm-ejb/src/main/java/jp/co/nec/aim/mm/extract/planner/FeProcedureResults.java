package jp.co.nec.aim.mm.extract.planner;

public class FeProcedureResults {
	private Long muId;
	private Long feLotJobId;
	private Long currentlots;

	public Long getMuId() {
		return muId;
	}

	public void setMuId(Long muId) {
		this.muId = muId;
	}

	public Long getFeLotJobId() {
		return feLotJobId;
	}

	public void setFeLotJobId(Long feLotJobId) {
		this.feLotJobId = feLotJobId;
	}

	public Long getCurrentlots() {
		return currentlots;
	}

	public void setCurrentlots(Long currentlots) {
		this.currentlots = currentlots;
	}

}
