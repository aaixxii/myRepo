package jp.co.nec.aim.mm.constants;

/**
 * Detail Code 2, Module
 */
public enum Module {
	CLASSCONVERT("000"), ACCEPTOR("001"), PLANNER("002"), DISPATCHER("003"), AGGREGATION(
			"004"), POLLBEAN("005"), STATUS("006"), MM_INIT("007"), OTHER("008"), TEMPLATEVALIDATOR(
			"009"), SCHEDULABLE("010");
	private String errorCode; // error code

	private Module(String errorCode) {
		this.setErrorCode(errorCode);

	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

}
