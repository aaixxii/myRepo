package jp.co.nec.aim.mm.entities;

public enum SegAssignmentRank {
	PRIMARY, SECONDARY, DYNAMIC, MANUAL;
}
