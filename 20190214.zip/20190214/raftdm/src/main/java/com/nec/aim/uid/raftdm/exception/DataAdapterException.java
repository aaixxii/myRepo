package com.nec.aim.uid.raftdm.exception;
public class DataAdapterException extends RuntimeException {

	private static final long serialVersionUID = 2626082645396399681L;

	public DataAdapterException(String message) {
		super(message);
	}

	public DataAdapterException(Throwable cause) {
		super(cause);
	}

	public DataAdapterException(String message, Throwable cause) {
		super(message, cause);
	}

}
