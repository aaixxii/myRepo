package com.nec.aim.uid.zkpdm.curator;


import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.framework.recipes.cache.TreeCache;
import org.apache.curator.framework.recipes.cache.TreeCacheListener;
import org.apache.curator.framework.recipes.locks.*;
import org.apache.curator.framework.state.ConnectionState;
import org.apache.zookeeper.CreateMode;

import com.nec.aim.uid.zkpdm.exception.CuratorClientException;

import java.nio.charset.Charset;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;

@Data
@NoArgsConstructor
@Slf4j
public class CuratorClient {

    private static final String DEFAULT_CHARSET = "utf8";
    private CuratorFramework client;
    private String charset = DEFAULT_CHARSET;

    public CuratorClient(CuratorFrameworkFactory.Builder builder) {
        if (builder==null) {
            throw new CuratorClientException("builder不能为null");
        }
        client = builder.build();
    }

    public CuratorClient(CuratorFrameworkFactory.Builder builder, String charset) {
        if (builder==null) {
            throw new CuratorClientException("builder can't be null");
        }
        client = builder.build();
        this.charset = charset;
    }

    public void init() {
        client.start();
        client.getConnectionStateListenable().addListener((client, state) -> {
            if (state==ConnectionState.LOST) {               
                log.info("lost session with zookeeper");
            } else if (state==ConnectionState.CONNECTED) {                
                log.info("connected with zookeeper");
            } else if (state==ConnectionState.RECONNECTED) {                
                log.info("reconnected with zookeeper");
            }
        });
    }

    public void stop() {
        client.close();
    }
   
    public void createNode(CreateMode mode, String path, String nodeData) {
        try {
          
            client.create().creatingParentsIfNeeded().withMode(mode).forPath(path, nodeData.getBytes(Charset.forName(charset)));
        } catch (Exception e) {
            throw new CuratorClientException("Faild to create node", e);
        }
    }
   
    public void createNode(CreateMode mode, String path) {
        try {
          
            client.create().creatingParentsIfNeeded().withMode(mode).forPath(path);
        } catch (Exception e) {
            throw new CuratorClientException("Faild to create node", e);
        }
    }
  
    public void deleteNode(final String path) {
        try {
            deleteNode(path, true);
        } catch (Exception e) {
            throw new CuratorClientException("Faild to delete node", e);
        }
    }

  
    public void deleteNode(final String path, Boolean deleteChildre) {
        try {
            if (deleteChildre) {
             
                client.delete().guaranteed().deletingChildrenIfNeeded().forPath(path);
            } else {
                client.delete().guaranteed().forPath(path);
            }
        } catch (Exception e) {
            throw new CuratorClientException("Faild to delete node", e);
        }
    }
    public void setNodeData(String path, String data) {
        try {
            client.setData().forPath(path, data.getBytes(Charset.forName(charset)));
        } catch (Exception ex) {
            throw new CuratorClientException("Faild to delete node", ex);
        }
    }

  
    public String getNodeData(String path) {
        try {
            return new String(client.getData().forPath(path), Charset.forName(charset));
        } catch (Exception e) {
            throw new CuratorClientException("Faild to get nodeData", e);
        }
    }

  
    public String synNodeData(String path) {
        client.sync();
        return getNodeData(path);
    }

  
    public boolean isExistNode(final String path) {
        client.sync();
        try {
            return null!=client.checkExists().forPath(path);
        } catch (Exception e) {
            return false;
        }
    }

  
    public List<String> getChildren(String path) {
        List<String> childrenList;
        try {
            childrenList = client.getChildren().forPath(path);
        } catch (Exception e) {
            throw new CuratorClientException("Faild to get nodeData", e);
        }
        return childrenList;
    }

   
    public InterProcessSemaphoreMutex getSemaphoreMutexLock(String path) {
        return new InterProcessSemaphoreMutex(client, path);
    }
  
    public InterProcessMutex getMutexLock(String path) {
        return new InterProcessMutex(client, path);
    }

  
    public InterProcessMultiLock getMultiMutexLock(List<String> paths) {
        return new InterProcessMultiLock(client, paths);
    }

 
    public InterProcessMultiLock getMultiLock(List<InterProcessLock> locks) {
        return new InterProcessMultiLock(locks);
    }
  
    public void acquire(InterProcessLock lock) {
        try {
            lock.acquire();
        } catch (Exception e) {
            throw new CuratorClientException(e.getMessage(), e);
        }
    }

    public void acquire(InterProcessLock lock, long time, TimeUnit unit) {
        try {
            lock.acquire(time, unit);
        } catch (Exception e) {
            throw new CuratorClientException(e.getMessage(), e);
        }
    }
  
    public void release(InterProcessLock lock) {
        try {
            lock.release();
        } catch (Exception e) {
            throw new CuratorClientException(e.getMessage(), e);
        }
    }
  
    public boolean isAcquiredInThisProcess(InterProcessLock lock) {
        return lock.isAcquiredInThisProcess();
    }

 
    public InterProcessReadWriteLock getReadWriteLock(String path) {
        return new InterProcessReadWriteLock(client, path);
    }
 
    public TreeCache watch(String path, TreeCacheListener listener, Executor pool) {
        TreeCache cache = new TreeCache(client, path);
        cache.getListenable().addListener(listener, pool);
        try {
            cache.start();
        } catch (Exception e) {
            throw new CuratorClientException(e.getMessage(), e);
        }
        return cache;
    }
 
    public TreeCache watch(String path, TreeCacheListener listener) {
        TreeCache cache = new TreeCache(client, path);
        cache.getListenable().addListener(listener);
        try {
            cache.start();
        } catch (Exception e) {
            throw new CuratorClientException(e.getMessage(), e);
        }
        return cache;
    }
  
    public void unwatch(TreeCache cache, TreeCacheListener listener) {
        if (cache==null) {
            throw new CuratorClientException("TreeCache can't be null");
        }
        cache.getListenable().removeListener(listener);
    }

}
