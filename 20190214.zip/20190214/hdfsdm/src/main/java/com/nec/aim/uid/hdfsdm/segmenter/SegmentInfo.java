package com.nec.aim.uid.hdfsdm.segmenter;

public class SegmentInfo {
	private long segId;	
	private boolean isUsing;
	private int recordcount;	
	private boolean corrupted;
	
	
	public SegmentInfo(long segmentId) {
		this.segId = segmentId;
		this.recordcount = 1;
		this.corrupted = false;
		this.isUsing = true;
	}

	public long getSegId() {
		return segId;
	}

	public void setSegId(long segId) {
		this.segId = segId;
	}
	public boolean isUsing() {
		return isUsing;
	}

	public void setUsing(boolean isUsing) {
		this.isUsing = isUsing;
	}

	public boolean isCorrupted() {
		return corrupted;
	}

	public void setCorrupted(boolean corrupted) {
		this.corrupted = corrupted;
	}

	public int getRecordcount() {
		return recordcount;
	}

	public void setRecordcount(int recordcount) {
		this.recordcount = recordcount;
	}	
}
