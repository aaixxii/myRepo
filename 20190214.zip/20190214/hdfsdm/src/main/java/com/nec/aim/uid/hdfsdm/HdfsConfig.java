package com.nec.aim.uid.hdfsdm;

import java.net.URI;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FsShell;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;


@Configuration
@ConditionalOnProperty(name="hadoop.name-node")
@Slf4j
@Data
public class HdfsConfig {
	
	@Value("${hadoop.name-node}")
    private String nameNode;
	
	
	
	@Autowired
    FsShell fsShell;	 
	
	 @Value("${com.domain.app.hadoop.fs-uri}")
	    private URI hdfsUri;

	    @Value("${com.domain.app.hadoop.user}")
	    private String user;
	

    @Bean
    public org.apache.hadoop.conf.Configuration hadoopConfiguration() {
        return new org.apache.hadoop.conf.Configuration();
    }   
  
    public org.apache.hadoop.conf.Configuration getConfiguration() {       
        org.apache.hadoop.conf.Configuration conf = new org.apache.hadoop.conf.Configuration();
        conf.set("dfs.replication", "1");
        conf.set("fs.defaultFS", nameNode);
        conf.set("mapred.job.tracker", nameNode);
        return conf;
    }

    @Bean
    public FileSystem fs(){       
        FileSystem fs = null;
        try {
            URI uri = new URI(nameNode.trim());
            fs = FileSystem.get(uri, this.getConfiguration());
        } catch (Exception e) {
            log.error("FileSystem initializing is faild!", e);
        }
        return fs;
    }
    
  public String getNameNodeUrl() {
	  return nameNode;
  }
    
}
