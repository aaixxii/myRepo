package com.nec.aim.uid.zkpdm.controller;

import java.io.IOException;
import java.util.concurrent.ExecutionException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.google.protobuf.InvalidProtocolBufferException;
import com.nec.aim.uid.zkpdm.segmenter.SegmentOperationHandler;

import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncResponce;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class SegmentController extends HttpServlet{	
	private static final long serialVersionUID = 8978225136377187339L;
	
	@Autowired
	SegmentOperationHandler segmentOperater;	

	@RequestMapping(value = "/dmSyncSegment", method = RequestMethod.POST)
	public void dmSegmentHandler(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PBDmSyncRequest dmSegReq =PBDmSyncRequest.parseFrom(req.getInputStream());
		PBDmSyncResponce.Builder dmRes = PBDmSyncResponce.newBuilder();
		try {
			boolean result = segmentOperater.handerRequest(dmSegReq);
			dmRes.setSuccess(result);	
			dmRes.build().writeTo(res.getOutputStream());
			log.info("success update segment");
		} catch (InvalidProtocolBufferException | InterruptedException |ExecutionException  e) {
			log.error(e.getMessage(), e);
			dmRes.setSuccess(false);
			dmRes.build().writeTo(res.getOutputStream());
		} 
	}
}
