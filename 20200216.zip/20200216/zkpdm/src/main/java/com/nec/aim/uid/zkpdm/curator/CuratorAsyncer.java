package com.nec.aim.uid.zkpdm.curator;

import org.apache.curator.RetryPolicy;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.framework.state.ConnectionState;
import org.apache.curator.retry.ExponentialBackoffRetry;
import org.apache.curator.x.async.AsyncCuratorFramework;
import org.apache.curator.x.async.AsyncEventException;
import org.apache.curator.x.async.WatchMode;
import org.apache.zookeeper.WatchedEvent;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import java.util.concurrent.CompletionStage;

import javax.annotation.PostConstruct;

@Component
@Scope("singleton")
@Slf4j
@Data
public class CuratorAsyncer {	
	private AsyncCuratorFramework asyncClient;
	
	@Value("${zookeeper.connection.string}")
	private String zkpConnString;

	@Value("${segments.root.dir}")
	private String segmentRootDir;

	@PostConstruct
	public void init() {
		RetryPolicy retryPolicy = new ExponentialBackoffRetry(1000, 3);
		CuratorFramework curatorFramework = CuratorFrameworkFactory.builder().connectString(zkpConnString)
				.sessionTimeoutMs(5000).connectionTimeoutMs(5000).retryPolicy(retryPolicy).namespace(segmentRootDir)
				.build();
		curatorFramework.start();
		curatorFramework.getConnectionStateListenable().addListener((CLIENT, state) -> {
			if (state == ConnectionState.LOST) {
				log.info("lost session with zookeeper");
			} else if (state == ConnectionState.CONNECTED) {
				log.info("Success to connected with zookeeper");
			} else if (state == ConnectionState.RECONNECTED) {
				log.info("reconnected with zookeeper");
			}
		});
		asyncClient = AsyncCuratorFramework.wrap(curatorFramework);
	}

	public void create(String path, byte[] payload) {		
		asyncClient.create().forPath(path, payload).whenComplete((name, exception) -> {
			if (exception != null) {
				log.error(exception.getMessage(), exception);
			} else {
				log.info("Created node name is: " + name);
				// Todo
			}
		});
	}

	public void createThenWatch(String path) {		
		asyncClient.create().forPath(path).whenComplete((name, exception) -> {
			if (exception != null) {
				log.error(exception.getMessage(), exception);
			} else {
				handleWatchedStage(asyncClient.watched().checkExists().forPath(path).event());
			}
		});
	}

	public void createThenWatchSimple(CuratorFramework client, String path) {		
		asyncClient.create().forPath(path).whenComplete((name, exception) -> {
			if (exception != null) {
				log.error(exception.getMessage(), exception);
			} else {
				asyncClient.with(WatchMode.successOnly).watched().checkExists().forPath(path).event().thenAccept(event -> {
					System.out.println(event.getType());
					System.out.println(event);
				});
			}
		});
	}

	private void handleWatchedStage(CompletionStage<WatchedEvent> watchedStage) {
		watchedStage.thenAccept(event -> {
			System.out.println(event.getType());
			System.out.println(event);
			// todo
		});

		watchedStage.exceptionally(exception -> {
			AsyncEventException asyncEx = (AsyncEventException) exception;
			asyncEx.printStackTrace(); // handle the error as needed
			handleWatchedStage(asyncEx.reset());
			return null;
		});
	}
}
