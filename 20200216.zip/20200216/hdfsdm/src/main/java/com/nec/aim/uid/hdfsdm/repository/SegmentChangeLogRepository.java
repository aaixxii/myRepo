package com.nec.aim.uid.hdfsdm.repository;

import org.springframework.data.repository.CrudRepository;

import com.nec.aim.uid.hdfsdm.model.SegmengChangeLog;

public interface SegmentChangeLogRepository extends CrudRepository<SegmengChangeLog, Long> {
}
