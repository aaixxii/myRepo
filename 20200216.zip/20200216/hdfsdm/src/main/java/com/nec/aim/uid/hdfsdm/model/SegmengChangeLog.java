package com.nec.aim.uid.hdfsdm.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity
public class SegmengChangeLog implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = -1468372533905085999L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)	
    long segChangeId;
    
   
    long bioId;
    
    
    long segId;
    
   
    long segVer;
    
   
    short changeType; 
    
    @Override
    public boolean equals(Object obj) {
        return false;
    }
    @Override
    public int hashCode() {
        return 0;        
    }   
}
