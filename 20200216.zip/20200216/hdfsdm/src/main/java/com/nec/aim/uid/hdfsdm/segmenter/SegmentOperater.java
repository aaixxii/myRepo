package com.nec.aim.uid.hdfsdm.segmenter;

import static com.nec.aim.uid.hdfsdm.segmenter.DmConstants.SEGMENT_HEADER_SIZE;
import static com.nec.aim.uid.hdfsdm.segmenter.DmConstants.SIZE_CHECKSUM; //templateCheckSum
import static com.nec.aim.uid.hdfsdm.segmenter.DmConstants.SIZE_DELETE_FLAG;
import static com.nec.aim.uid.hdfsdm.segmenter.DmConstants.SIZE_EVENT_ID;
import static com.nec.aim.uid.hdfsdm.segmenter.DmConstants.SIZE_EXTERNAL_ID;
import static com.nec.aim.uid.hdfsdm.segmenter.DmConstants.SIZE_TEMPLATE_HEADER;
import static com.nec.aim.uid.hdfsdm.segmenter.DmConstants.SIZE_TEMPLATE_ID;
import static com.nec.aim.uid.hdfsdm.segmenter.DmConstants.SIZE_TSZ; //templateTotalSize;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.util.Objects;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.google.protobuf.InvalidProtocolBufferException;
import com.nec.aim.uid.hdfsdm.HdfsConfig;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;
import lombok.extern.slf4j.Slf4j;

@Service
@Scope("prototype")

@Slf4j
public class SegmentOperater {
	public static final int AIM_VERSION = 2;
	public static final short FORMAT_ID = 1;
	public static long MAX_SEGMENT_SIZE = 1000000000;

	private static String HDFS_PATH = "/SEGMENTS";

	@PostConstruct
	public void init() {

	}

	@PreDestroy
	public void onDestroy() throws Exception {
		fileSystem.close();
	}

	@Autowired
	HdfsConfig hdfsConfig;

	@Autowired
	FileSystem fileSystem;

	public Boolean handerRequest(PBDmSyncRequest dmSegRequest)
			throws InvalidProtocolBufferException, InterruptedException, ExecutionException {
		PBDmSyncRequest dmSegReq = PBDmSyncRequest.parseFrom(dmSegRequest.toByteString());
		String changeType = dmSegReq.getCmd().name().toUpperCase();
		long bioId = dmSegReq.getBioId();
		PBTemplateInfo templateInfo = dmSegReq.getTemplateData();
		String externalId = templateInfo.getReferenceId();
		byte[] templateData = templateInfo.getData().toByteArray();
		long segId = dmSegReq.getTargetSegments().getId();
		long segVer = dmSegReq.getTargetSegments().getVersion();
		if (Objects.isNull(templateData) || templateData.length < 0) {
			log.warn("Received empty template data!!");
			return false;
		}
		boolean resulst = false;
		SegmentInfo segInfo = SegmentManager.getSegmentInfo(segId);
		if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT.name())) {
			if (Objects.isNull(segInfo)) {
				resulst = newSegment(templateData, bioId, externalId, segId, segVer);
			} else {
				resulst = updateSegment(segInfo, templateData, bioId, externalId, segId, segVer);
			}
		} else if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE.name())) {
			if (Objects.isNull(segInfo)) {
				log.warn("can't found segment data for sementId={}", segId);
				resulst = false;
			} else {
				try {
					resulst = deleteTemplate(segInfo, bioId, externalId);
				} catch (IOException e) {
					log.error(e.getMessage(), e);
					resulst = false;
				}
			}
		}
		return Boolean.valueOf(resulst);
	}

	private Boolean newSegment(byte[] data, long bioId, String extId, long segId, long segVer) {
		Callable<Boolean> newSegmentTask = () -> {
			int tSize = SEGMENT_HEADER_SIZE + SIZE_TEMPLATE_HEADER + data.length;
			ByteBuffer segBuffer = ByteBuffer.allocate(tSize);
			SegmentInfo newSegInfo = new SegmentInfo(segId);
			newSegInfo.setSegId(segId);
			FSDataOutputStream outputStream = null;
			try {
				segBuffer.position(0);
				segBuffer.putInt(AIM_VERSION);
				segBuffer.putShort(FORMAT_ID);
				segBuffer.putLong(MAX_SEGMENT_SIZE);
				segBuffer.putInt(1);
				segBuffer.putLong(segVer);
				byte[] templateWithHeader = TemplateHeadBuilder.prependHeader(bioId, data, extId, 1);
				segBuffer.put(templateWithHeader);
				segBuffer.put(data);
				newSegInfo.setRecordcount(1);
				SegmentManager.saveToQueue(Long.valueOf(segId), newSegInfo);
				String strPath = HDFS_PATH + "/" + String.valueOf(segId);
				Path newPath = new Path(strPath);
				if (fileSystem.exists(newPath)) {
					log.warn("There are some wrong, the file:{} is exist!", segId);
					return false;
				}
				outputStream = fileSystem.create(newPath, false);
				outputStream.write(segBuffer.array());
				outputStream.flush();
				segBuffer.clear();
				segBuffer = null;
			} catch (Exception e) {
				log.error(e.getMessage(), e);
				return false;
			} finally {
				IOUtils.closeStream(outputStream);
				segBuffer.clear();
				segBuffer = null;
			}
			return true;
		};
		try {
			return SegmentManager.submit(newSegmentTask);
		} catch (InterruptedException | ExecutionException e) {
			log.error(e.getMessage(), e);
			return false;
		}
	}

	private Boolean updateSegment(SegmentInfo segInfo, byte[] data, long bioId, String extId, long segId, long segVer)
			throws InterruptedException, ExecutionException {
		Callable<Boolean> updateSegmentTask = () -> {
			String strPath = HDFS_PATH + "/" + String.valueOf(segId);
			Path newPath = new Path(strPath);
			if (!fileSystem.exists(newPath)) {
				log.warn("There are some wrong, the file:{} is not exist!", segId);
				return false;
			}
			int templateSize = SIZE_TEMPLATE_HEADER + data.length;
			ByteBuffer updateByteBuf = ByteBuffer.allocate(templateSize);
			byte[] templateWithHeader = TemplateHeadBuilder.prependHeader(bioId, data, extId, 1);
			updateByteBuf.put(templateWithHeader);
			updateByteBuf.put(data);
			byte[] newData = updateByteBuf.array();
			FSDataOutputStream fileOutputStream = null;
			try {
				fileOutputStream = fileSystem.append(newPath);
				fileOutputStream.write(newData);

				segInfo.setRecordcount(segInfo.getRecordcount() + 1);
				log.info("Success upate tempate data to segment file, segmentId={}", segId);
				updateByteBuf.clear();
				updateByteBuf = null;
			} catch (Exception e) {
				log.error(e.getMessage(), e);
				return false;
			} finally {
				IOUtils.closeStream(fileOutputStream);
				updateByteBuf.clear();
				updateByteBuf = null;
			}
			return true;
		};
		return SegmentManager.submit(updateSegmentTask);
	}

	private Boolean deleteTemplate(SegmentInfo segInfo, long bioId, String extId)
			throws InterruptedException, ExecutionException, IOException {
		Callable<Boolean> delTemplateTask = () -> {
			long segId = segInfo.getSegId();
			FSDataOutputStream fileOutputStream = null;
			try {
				String strPath = HDFS_PATH + "/" + String.valueOf(segId);
				Path updatePath = new Path(strPath);
				if (!fileSystem.exists(updatePath)) {
					log.warn("There are some wrong, the file:{} is not exist!", segId);
					return false;
				}
				Path local = new Path("./temp");
				fileSystem.copyToLocalFile(false, updatePath, local, true);
				markDelFlag(local, segId, bioId);
				fileSystem.copyFromLocalFile(true, true, local, updatePath);
				segInfo.setRecordcount(segInfo.getRecordcount() - 1);
			} catch (Exception e) {
				log.error(e.getMessage(), e);
				return false;
			} finally {
				IOUtils.closeStream(fileOutputStream);
			}
			return true;
		};
		return SegmentManager.submit(delTemplateTask);
	}
	
	private void markDelFlag(Path local, long segId, long bioId) throws IOException {
		byte b = 1;
		byte[] delFlag = new byte[] { b };
		RandomAccessFile randomFile = null;
		try {
			randomFile = new RandomAccessFile(local.getName(), "rw");
			int firstSeekPositon = SEGMENT_HEADER_SIZE + SIZE_CHECKSUM;
			randomFile.seek(firstSeekPositon);
			long prePostion = randomFile.getFilePointer();
			long nextPosition = -1;
			boolean finish = false;
			while (!finish) {
				nextPosition = prePostion + SIZE_TSZ;
				randomFile.seek(nextPosition);
				long templateId = randomFile.readLong();
				if (templateId == bioId) {
					randomFile.write(delFlag);
					finish = true;
					break;
				}
				nextPosition = nextPosition + SIZE_DELETE_FLAG + SIZE_EXTERNAL_ID + SIZE_EVENT_ID;
				prePostion = nextPosition;
			}
			if (!finish) {
				log.info("Can't found templateId({}) in this segment({})", bioId, segId);
				return;
			}
			
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		} finally {
			randomFile.close();
		}
	}

	@SuppressWarnings("unused")
	private Long foundPositon(long segId, long bioId, String extId)
			throws InterruptedException, ExecutionException, IOException {
		Long postion = -1L;
		String strPath = HDFS_PATH + "/" + String.valueOf(segId);
		Path newPath = new Path(strPath);
		if (!fileSystem.exists(newPath)) {
			//
			return -1L;
		}
		FSDataInputStream in;
		in = fileSystem.open(newPath);
		int firstSeekPositon = SEGMENT_HEADER_SIZE + SIZE_CHECKSUM;
		// in.seek(firstSeekPositon);
		byte[] tmp = new byte[32];
		in.readFully(firstSeekPositon, tmp);
		int templateSize = ByteBuffer.wrap(tmp).getInt();
		byte[] bioIdByte = new byte[64];
		in.readFully(firstSeekPositon + templateSize, bioIdByte);
		long seachedBioId = ByteBuffer.wrap(bioIdByte).getLong();
		if (seachedBioId == bioId) {
			postion = Long.valueOf(in.getPos());
			return postion;
		} else {
			boolean finish = false;
			int currentTemplateSize = templateSize;
			long currentBioId = seachedBioId;
			while (!finish) {
				int nextSeekSize = (int) (in.getPos() + currentTemplateSize
						- (SIZE_CHECKSUM + SIZE_TSZ + SIZE_TEMPLATE_ID) + SIZE_CHECKSUM + SIZE_TSZ);
				byte[] temp = new byte[32];
				in.readFully(nextSeekSize, temp);
				currentTemplateSize = ByteBuffer.wrap(temp).getInt();
				byte[] tmpBioIdByte = new byte[64];
				in.readFully(nextSeekSize + currentTemplateSize, tmpBioIdByte);
				currentBioId = ByteBuffer.wrap(tmpBioIdByte).getLong();
				if (currentBioId == bioId) {
					finish = true;
					postion = Long.valueOf(in.getPos());
					break;
				}
			}
			if (!finish) {
				log.info("Can't found templateId({}) in this segment({})", bioId, segId);
				return postion;
			}
		}
		return segId;
	}
}
