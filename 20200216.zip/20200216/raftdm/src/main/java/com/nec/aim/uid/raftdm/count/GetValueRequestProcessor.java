/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.nec.aim.uid.raftdm.count;

import java.nio.ByteBuffer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alipay.remoting.AsyncContext;
import com.alipay.remoting.BizContext;
import com.alipay.remoting.exception.CodecException;
import com.alipay.remoting.rpc.protocol.AsyncUserProcessor;
import com.alipay.sofa.jraft.Closure;
import com.alipay.sofa.jraft.Status;
import com.alipay.sofa.jraft.entity.Task;


/**
 * GetValueRequest processor.
 *
 * @author boyan (boyan@alibaba-inc.com)
 *
 * 2018-Apr-09 5:48:33 PM
 */
public class GetValueRequestProcessor extends AsyncUserProcessor<GetValueRequest> {

    private static final Logger  LOG = LoggerFactory.getLogger(GetValueRequestProcessor.class);

    private final CounterServer counterServer;   
    

    public GetValueRequestProcessor(CounterServer countServer) {
        super();
        this.counterServer =countServer;
    }

    @Override
    public void handleRequest(BizContext bizCtx, AsyncContext asyncCtx, GetValueRequest request) {
        if (!counterServer.getFsm().isLeader()) {
            asyncCtx.sendResponse(counterServer.redirect());
            return;
        }

        // 构建应答回调
        ValueResponse response = new ValueResponse();
        GetValueClosure closure = new GetValueClosure(counterServer, request, response, new Closure() {

            @Override
            public void run(Status status) {
                // 提交后处理
                if (!status.isOk()) {
                    // 提交失败，返回错误信息
                    response.setErrorMsg(status.getErrorMsg());
                    response.setSuccess(false);
                }
                // 成功，返回ValueResponse应答
                asyncCtx.sendResponse(response);

            }
        });

        try {
            // 构建提交任务
            Task task = new Task();
            task.setDone(closure); // 设置回调
            // 填充数据，将请求用 hessian２序列化到 data　字段          
            task.setData(ByteBuffer.wrap(HessianSerializer.marshal(request)));

            // 提交到 raft group
            counterServer.getNode().apply(task);
        } catch (CodecException e) {
            // 处理序列化异常
            LOG.error("Fail to encode IncrementAndGetRequest", e);
            ValueResponse responseObject = response;
            responseObject.setSuccess(false);
            responseObject.setErrorMsg(e.getMessage());
            asyncCtx.sendResponse(responseObject);
        }
    }

    @Override
    public String interest() {
        return GetValueRequest.class.getName();
    }
}
