package com.nec.aim.uid.rafedm;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RafedmApplicationTests {

	@Test
	void contextLoads() {
	}

}
