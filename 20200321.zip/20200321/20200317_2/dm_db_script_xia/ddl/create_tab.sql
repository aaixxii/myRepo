#create dm tables

USE DMDB;
CREATE TABLE IF NOT EXISTS action_schedule (
  action_id int NOT NULL AUTO_INCREMENT,
  action_type tinyint NOT NULL DEFAULT '0', #nothing:0,download:1,catchup:2
  start_time datetime NOT NULL,
  status tinyint NOT NULL DEFAULT '0', # pending:0, runing:1, done:2
  TS timestamp NOT NULL,
  PRIMARY KEY (action_id) 
)TABLESPACE UID_DM_COMPONENT_DATA;


CREATE TABLE IF NOT EXISTS dm_info (
  dm_id  VARCHAR(30) NOT NULL , 
  server_type VARCHAR(20) NOT NULL, # dm_service,master,node_storage
  server_hostname VARCHAR(128) NOT NULL ,
  connection_url VARCHAR(500) NOT NULL,
  UNIQUE KEY url(connection_url),
  PRIMARY KEY (dm_id) 
) TABLESPACE UID_DM_COMPONENT_DATA; 


CREATE TABLE IF NOT EXISTS master (
  token int NOT NULL  DEFAULT 0  CHECK (0 <= token AND token <= 1), #master_id=1 is leader
  dm_master_id VARCHAR(30) NOT NULL,
  one_time_interval int NOT NULL DEFAULT 1000 ,  #1000ms,
  last_ts timestamp NOT NULL,
  CONSTRAINT FOREIGN KEY (dm_master_id) REFERENCES dm_info(dm_id) ON DELETE CASCADE
) TABLESPACE UID_DM_COMPONENT_DATA;



CREATE TABLE IF NOT EXISTS node_storage (
  storage_id int NOT NULL, #storage number
  dm_storage_id VARCHAR(30) NOT NULL,
  mail_flag VARCHAR(10) default '', #nonal:'', exception:'signal'
  disk_size int NOT NULL ,
  space int NOT NULL ,
  status tinyint NOT NULL ,  #pending:0 working:1 stopped:2 suspending:4 detached:5
  update_ts timestamp NOT NULL, 
  PRIMARY KEY (storage_id),
  CONSTRAINT FOREIGN KEY (dm_storage_id) REFERENCES dm_info(dm_id) ON DELETE CASCADE 
) TABLESPACE UID_DM_SEGMINT_INFO_DATA;


CREATE TABLE segments_info (
  segment_id  BIGINT(38)  NOT NULL , 
  bio_id_start  BIGINT(38) ,
  bio_id_end  BIGINT(38)  ,
  version BIGINT(38) NOT NULL , 
  update_ts  TIMESTAMP NOT NULL,
  PRIMARY KEY (segment_id ASC)
) TABLESPACE UID_DM_SEGMINT_INFO_DATA;

CREATE TABLE IF NOT EXISTS segment_loading ( 
  storage_id  int NOT NULL ,
  segment_id BIGINT(38)  NOT NULL , 
  status int NOT NULL, # working:1
  last_version BIGINT(38)  NOT NULL , 
  last_ts timestamp ,
  PRIMARY KEY ( storage_id, segment_id), 
  FOREIGN KEY (storage_id) REFERENCES node_storage(storage_id),
  FOREIGN KEY (segment_id) REFERENCES segments_info (segment_id) ON DELETE CASCADE
) TABLESPACE UID_DM_SEGMINT_INFO_DATA;

CREATE TABLE catchup (
  segment_change_id BIGINT(38)  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  storage_id int NOT NULL ,
  biometrics_id BIGINT(38),
  external_id varchar(36),
  template_data BLOB,   
  segment_id BIGINT(38)  NOT NULL ,
  segment_version BIGINT(38)  NOT NULL ,
  change_type INT(4)  NOT NULL,   #new:0,insert:1,delete:2,update:3   
  FOREIGN KEY (storage_id) REFERENCES node_storage(storage_id),
  FOREIGN KEY (segment_id) REFERENCES segments_info (segment_id) ON DELETE CASCADE
) TABLESPACE UID_DM_CHANGE_LOG_DATA;

CREATE TABLE dm_config_info (
   config_id tinyint NOT NULL AUTO_INCREMENT PRIMARY KEY,
    key_name             VARCHAR(60)  UNIQUE NOT NULL ,
    key_value            VARCHAR(60)  NOT NULL   
) TABLESPACE UID_DM_COMPONENT_DATA;

#ALTER TABLE dm_config_info add column config_id int(4) primary KEY AUTO_INCREMENT;
#alter table segments_info add column external_id VARCHAR(36)  NOT NULL;
#ALTER table segments_info MODIFY COLUMN  bio_id_start BIGINT(38), MODIFY COLUMN bio_end  BIGINT(38);
#ALTER TABLE dm_config_info add column config_id int(4) primary KEY AUTO_INCREMENT;
#ALTER table segment_loading  drop COLUMN deta_size;

