package com.nec.aim.dm.nodostorage.segments;

public class DmConstants {

	// Size of Segment File Header
	public static final int SIZE_VERSION = 4;
	public static final int SIZE_EMBEDDED_ID = 2;
	public static final int SIZE_MAX_SEGMENT = 8;
	public static final int SIZE_RECORD_COUNT = 4;
	public static final int SIZE_SEGMENT_VERSION = 8;
	public static final int SEGMENT_HEADER_SIZE = SIZE_VERSION + SIZE_EMBEDDED_ID + SIZE_MAX_SEGMENT + SIZE_RECORD_COUNT
			+ SIZE_SEGMENT_VERSION;
	// Template Header field sizes
	public static final int SIZE_CHECKSUM = 1;
	public static final int SIZE_TSZ = 4;
	public static final int SIZE_TEMPLATE_ID = 8;
	public static final int SIZE_DELETE_FLAG = 1;
	public static final int SIZE_EXTERNAL_ID = 36;
	public static final int SIZE_EVENT_ID = 4;
	public static final int SIZE_TEMPLATE_HEADER = SIZE_TSZ + SIZE_TEMPLATE_ID + SIZE_DELETE_FLAG + SIZE_EXTERNAL_ID
			+ SIZE_EVENT_ID;
	public static final int SIZE_TEMPLATE_HEADER_CHECKSUM = SIZE_TEMPLATE_HEADER + SIZE_CHECKSUM;
	
	public static final int AIM_VERSION = 2;
	public static final short FORMAT_ID = 1;
	public static final long MAX_SEGMENT_SIZE = 20000000;	
	public static final long MAX_RECORD_COUNT= 1000;

}
