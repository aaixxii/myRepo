package com.nec.aim.dm.nodostorage.repository;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.nec.aim.dm.nodostorage.entity.Catchup;

@Repository
public class CatchupRepositoryLmpl implements CatchupRepository {
	private String getMyCatchupSql = "select * from catchup where storage_id=? and segment_id in (?);";
	
	@Autowired
    private JdbcTemplate jdbcTemplate;	
	
	RowMapper<Catchup> catchupRowMapper = (rs, rowNum) -> {
		Catchup cp = new Catchup();
		cp.setSegmentChangId(rs.getLong("segment_change_id"));
		cp.setBiometricsId(rs.getLong("biometrics_id"));
		cp.setChangeType(rs.getInt("change_type"));
		cp.setExternalId(rs.getString("external_id"));
		cp.setSegmentId(rs.getLong("segment_id"));
		cp.setSegmentVersion(rs.getLong("segment_version"));
		cp.setStorageId(rs.getInt("storage_id"));
		cp.setTemplateData(rs.getBlob("template_data"));
		return cp;		
	};

	@Override
	public List<Catchup> getMyCathupData(Integer storageId, List segmentIds) throws SQLException {
		return jdbcTemplate.query(getMyCatchupSql, new Object[] {storageId, segmentIds}, catchupRowMapper);	
	}
}
