package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.nec.aim.dm.dmservice.dispatch.DmServiceManager;
import com.nec.aim.dm.dmservice.entity.DmInfo;

@Repository
public class DmInfoRepositoryImpl implements DmInfoRepository {
	private static final String getDmInfoSql = "select * from dm_info where dm_id = ?";
	private static final String getActiveNodeStorage = "select dm.connection_url from dm_info dm, node_storage nd where nd.dm_storage_id= dm.dm_id and nd.status=1 and nd.space>0 order by nd.space DESC limit ?";
	private static final String getOneNodeStorageUrl = "select dm.connection_url from dm_info dm, node_storage nd where nd.dm_storage_id= dm.dm_id and nd.status=1 and nd.storage_id=?";
	private static final String getAllDmServiceUrl= "select connection_url from dm_info where server_type ='dm_service'";
	
	@Autowired
    private JdbcTemplate jdbcTemplate;

	@Override
	public DmInfo getDmInfoByDmId(String dmId) throws SQLException {
		return jdbcTemplate.query(getDmInfoSql, new Object[] {dmId}, dmInfoMapper).get(0);
		
	}

	@Override
	public List<String> getAllActiveNodeStorageUrl(int redundancy) throws SQLException {
		return jdbcTemplate.queryForList(getActiveNodeStorage, new Object[] {redundancy}, String.class);		
	}
	
	RowMapper<DmInfo> dmInfoMapper = (rs, rowNum) -> {
		DmInfo dmInfo = new DmInfo();
		dmInfo.setDmId(rs.getString("dm_id"));
		dmInfo.setConnectionUrl("server_type");
		dmInfo.setHostName("server_hostname");
		dmInfo.setServerType("connection_url");
		return dmInfo;		
	};

	@Override
	public String getNodeStorageUrl(int nodeStorageId) throws SQLException {
		String nodeUrl = jdbcTemplate.queryForObject(getOneNodeStorageUrl, new Object[] {nodeStorageId}, String.class);
		return nodeUrl;
	}

	@Override
	public List<String> getAllDmServiceUrl() throws SQLException {		
		List<String> allDmServiceUrl = jdbcTemplate.queryForList(getAllDmServiceUrl, String.class);
		DmServiceManager.putSeriveUrl("allDmSeriveUrl", allDmServiceUrl);
		return allDmServiceUrl;
	}
	
}
