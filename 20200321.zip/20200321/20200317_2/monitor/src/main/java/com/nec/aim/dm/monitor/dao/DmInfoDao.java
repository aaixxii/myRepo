package com.nec.aim.dm.monitor.dao;

import java.sql.SQLException;
import java.util.List;

public interface DmInfoDao {
	
	public DmInfo  getDmInfoByDmId(String dmId) throws SQLException;
	public List<DmInfo> getAllDmMaster() throws SQLException;	
}
