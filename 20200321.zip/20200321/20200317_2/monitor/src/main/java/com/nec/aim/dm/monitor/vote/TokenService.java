package com.nec.aim.dm.monitor.vote;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nec.aim.dm.monitor.config.ConfigProperties;
import com.nec.aim.dm.monitor.dao.DmInfo;
import com.nec.aim.dm.monitor.dao.DmInfoDao;
import com.nec.aim.dm.monitor.dao.MasterDao;

import lombok.extern.slf4j.Slf4j;


@Service
@Slf4j
public class TokenService {
	
	@Autowired
	MasterDao masterDao;
	
	@Autowired
	DmInfoDao dmInfoDao;
	
	@Autowired
	ConfigProperties config;
	
	@PostConstruct
	public void init() {
		try {
			getMyIP();
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		setTokenTask ();
	}
	
	
	public void setTokenTask () {
		Runnable tokenTask = () -> {			
			try {
				String myId = config.getDmId();
				int result = masterDao.setToken();
				if (result == 1) {					
					log.info("MasterId({}) sucess get token, I am leader!", Manager.getValue("masterId"));
					log.info("Setting token value to zero for next election.");							
					log.info("I will checking node storage manangers active or no....");
					masterDao.setTokenToZero();
				} else {
					log.info("MasterId({}), DmId({}) faild to get token.", config.getMyId(), config.getDmId());
				}
			} catch (SQLException e) {
				log.warn(e.getMessage());
			}
		};
		Manager.sheduleTask(tokenTask, config.getInterval());
	}
	
	
	private void getMyIP() throws Exception {		
		Enumeration<NetworkInterface> e = NetworkInterface.getNetworkInterfaces();
		boolean stop = false;		
		while (e.hasMoreElements() && !stop) {
			NetworkInterface n = (NetworkInterface) e.nextElement();
			Enumeration<?> ee = n.getInetAddresses();
			while (ee.hasMoreElements()) {
				InetAddress i = (InetAddress) ee.nextElement();
				if (isMyId(i)) {
					stop = true;				
				}
				if (stop) break;
			}
			if (stop) break;
		}	
	}	
	
	private boolean isMyId(InetAddress address) throws SQLException {
		List<DmInfo> masterList = dmInfoDao.getAllDmMaster();		
		for (int i = 0; i < masterList.size(); i++) {
			DmInfo dmInfo = masterList.get(i);
			String name = address.getHostName();
			String ip = address.getHostAddress();
			if (name.equals(dmInfo.getHostName()) || ip.equals(dmInfo.getHostName())) {
				Manager.put("masterId", dmInfo.getDmId());
				Manager.put("hostName", name);
				Manager.put("ip", ip);
				return true;				
			}
		}	
		return false;
	}


	@PreDestroy
	public void colse() {
		Manager.shutdown();
	}
}
