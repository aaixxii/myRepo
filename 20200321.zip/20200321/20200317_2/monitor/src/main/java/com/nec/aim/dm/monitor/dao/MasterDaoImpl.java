package com.nec.aim.dm.monitor.dao;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nec.aim.dm.monitor.config.ConfigProperties;

@Repository
public class MasterDaoImpl implements MasterDao {
	private static final String setTokenSql = "update master set token=1, dm_master_id=?, last_ts=CURRENT_TIMESTAMP() where token=0";
	private static final String setTokenToZeroSql = "update master set token =0";
	private static final String setLockSql = "SELECT GET_LOCK('dmlock', 1)";
	private static final String releaseLockSql = "RELEASE_LOCK('dmlock')";
	
	@Autowired
    JdbcTemplate jdbcTemplate;
	
	@Autowired
	ConfigProperties config;


	@Override
	public int setToken() throws SQLException {
		int result = jdbcTemplate.update(setTokenSql, new Object[] {config.getDmId()});		
		return result;
	}

	@Override
	public void setTokenToZero() throws SQLException {
		jdbcTemplate.update(setTokenToZeroSql);
	}

	@Override
	public DmInfo getMyDmInfo() throws SQLException {
		
		return null;
	}

	@Override
	public int setLock() throws SQLException {
		return jdbcTemplate.update(setLockSql);
		
	}

	@Override
	public int releaseLock() throws SQLException {
		return jdbcTemplate.update(releaseLockSql);		
	}

}
