create or replace PROCEDURE XM_DB_EXPAND 
(
  CAPSULE_TEMPLATE_TYPE IN VARCHAR2 
, TEMPLATE_SIZE IN NUMBER 
) AS 
--c_template_size  NUMBER := 25500;
--c_bin_id NUMBER := 35;

l_template_id   BIO_TEMPLATE_DATA_INFO.TEMPLATE_DATA_ID%TYPE;
l_template_data  BIO_TEMPLATE_DATA_INFO.TEMPLATE_DATA%TYPE;

l_bio_detail_info_rec  BIO_IDENTIFIER_DETAIL_INFO%ROWTYPE;
l_event_info_rec  BIO_EVENT_INFO%ROWTYPE;
l_semgnet_id NUMBER;
l_bin_id  NUMBER;
l_sn_node_id VARCHAR2(15);
l_last_sement_version NUMBER;

l_init_biometricId  NUMBER;
l_init_external_id VARCHAR2(36);
l_init_event_id VARCHAR2(36);
l_event_info_count NUMBER;

CURSOR event_c1 IS
SELECT * FROM BIO_EVENT_INFO WHERE BIOMETRIC_ID <> (select min(BIOMETRIC_ID) from BIO_EVENT_INFO);
event_rec event_c1%rowtype;

BEGIN
  SELECT bin_id INTO l_bin_id FROM BIO_MATCHER_BIN_INFO WHERE TEMPLATE_TYPE=CAPSULE_TEMPLATE_TYPE;
  SELECT * into l_event_info_rec from BIO_EVENT_INFO WHERE BIOMETRIC_ID=(SELECT max(BIOMETRIC_ID) FROM BIO_EVENT_INFO);
 l_init_biometricId := l_event_info_rec.BIOMETRIC_ID;
 l_init_external_id := l_event_info_rec.EXTERNAL_ID;
 l_init_event_id := l_event_info_rec.EVENT_ID;
 --l_bin_id := l_event_info_rec.BIN_ID;
 
 SELECT SEGMENT_ID INTO l_semgnet_id FROM BIO_IDENTIFIER_INFO WHERE BIN_ID=l_bin_id And SEGMENT_ID=(SELECT max(SEGMENT_ID) from BIO_IDENTIFIER_INFO);
 
 SELECT MATCHER_NODE_ID INTO l_sn_node_id FROM BIO_MATCHER_NODE_SEGMENT_INFO WHERE SEGMENT_ID=l_semgnet_id AND ASSIGNED_FLAG='Y';
 
 SELECT TEMPLATE_DATA into l_template_data FROM BIO_TEMPLATE_DATA_INFO WHERE TEMPLATE_DATA_ID= l_init_biometricId;
 
  FOR i IN 1..TEMPLATE_SIZE LOOP
   INSERT INTO BIO_EVENT_INFO(BIOMETRIC_ID,EXTERNAL_ID,EVENT_ID,BIN_ID,STATUS,PHASE,CREATE_DATETIME,UPDATE_DATETIME,TEMPLATE_DATA_KEY,TEMPLATE_SIZE,DATA_VERSION,ASSIGNED_SEGMENT_ID,SITE_ID)
   VALUES(l_init_biometricId || i,  l_init_external_id || i, l_init_event_id || i, l_event_info_rec.BIN_ID, l_event_info_rec.STATUS,l_event_info_rec.PHASE, SYSTIMESTAMP,SYSTIMESTAMP,
   l_init_biometricId || i,TEMPLATE_SIZE, l_event_info_rec.DATA_VERSION + 1, l_event_info_rec.ASSIGNED_SEGMENT_ID, l_event_info_rec.SITE_ID); 
    commit;
 END LOOP; 
  SELECT count(BIOMETRIC_ID) INTO l_event_info_count FROM BIO_EVENT_INFO;  
     INSERT INTO BIO_MATCHER_NODE_SEGMENT_INFO(MATCHER_NODE_ID,SEGMENT_ID,ASSIGNED_FLAG,SEGMENT_VERSION,UPDATE_DATETIME) VALUES(l_sn_node_id,l_semgnet_id,'Y', l_last_sement_version, SYSTIMESTAMP);
   commit;
     EXCEPTION
    WHEN OTHERS THEN
      dbms_output.put_line ('An error occurred while do fuction:EXPANDABLE_JOBS_TRAFFIC_OFF()'); 
END XM_DB_EXPAND;
