package com.nec.biomatcher.core.framework.cache;

import java.util.function.BiFunction;
import java.util.function.Supplier;

import com.nec.biomatcher.core.framework.common.CheckedFunction;
import com.nec.biomatcher.core.framework.common.CheckedSupplier;

public class FunctionalCacheServiceImpl implements FunctionalCacheService {
	public <K, V> V getCachedValue(K param, CheckedFunction<K, V> function) throws Throwable {
		return function.apply(param);
	}

	public <K, V> V getCachedValue(K param, CheckedFunction<K, V> function, CacheExpiryParam cacheExpiryParam)
			throws Throwable {
		return function.apply(param);
	}

	public <K, L, V> V getCachedValue(K param1, L param2, BiFunction<K, L, V> function) {
		return function.apply(param1, param2);
	}

	public <K, L, V> V getCachedValue(K param1, L param2, BiFunction<K, L, V> function,
			CacheExpiryParam cacheExpiryParam) throws Throwable {
		return function.apply(param1, param2);
	}

	public <V> V getCachedValue(CheckedSupplier<V> supplier) throws Throwable {
		return supplier.get();
	}

	public <V> V getCachedValue(CheckedSupplier<V> supplier, CacheExpiryParam cacheExpiryParam) throws Throwable {
		return supplier.get();
	}

	public <V> V getUnCheckedCachedValue(Supplier<V> supplier) {
		return supplier.get();
	}

	public <V> V getUnCheckedCachedValue(Supplier<V> supplier, CacheExpiryParam cacheExpiryParam) {
		return supplier.get();
	}
}
