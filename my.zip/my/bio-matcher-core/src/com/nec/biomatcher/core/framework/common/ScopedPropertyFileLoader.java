package com.nec.biomatcher.core.framework.common;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

/**
 * The Class ScopedPropertyFileLoader.
 */
public class ScopedPropertyFileLoader {

	/** The logger. */
	private static Logger logger = Logger.getLogger(ScopedPropertyFileLoader.class);

	/** The Constant DEFAULT_KEY. */
	public static final String DEFAULT_KEY = "default";

	/** The Constant COMMON_KEY. */
	public static final String COMMON_KEY = "common";

	/** The deployment mode. */
	private final String deploymentMode;

	/** The fallback to default. */
	private boolean fallbackToDefault = false;

	/** The common value list. */
	private List<String> commonValueList;

	/** The default value list. */
	private List<String> defaultValueList;

	/** The value list. */
	private List<String> valueList;

	/**
	 * Instantiates a new scoped property file loader.
	 */
	public ScopedPropertyFileLoader() {
		deploymentMode = System.getProperty("DEPLOYMENT_MODE", "PRODUCTION").toUpperCase();

		logger.info("ScopedPropertyFileLoader: Deployment mode: : " + deploymentMode);
	}

	/**
	 * Sets the scoped value list map.
	 *
	 * @param scopeValueListMap
	 *            the scoped value list map
	 */
	public void setScopedValueListMap(Map<String, List<String>> scopeValueListMap) {
		logger.debug("Current configured valueList keys: " + scopeValueListMap.keySet());

		commonValueList = scopeValueListMap.get(COMMON_KEY);

		defaultValueList = scopeValueListMap.get(DEFAULT_KEY);

		for (String scope : scopeValueListMap.keySet()) {
			valueList = scopeValueListMap.get(scope);
			scope = scope.toUpperCase().trim();
			if (scope.equals(deploymentMode) || scope.startsWith(deploymentMode + ",")
					|| scope.indexOf("," + deploymentMode + ",") > -1 || scope.endsWith("," + deploymentMode)) {
				logger.info("Found valueList for deploymentMode: " + deploymentMode + " matching with scope: " + scope);
				logger.debug("ValueList for deploymentMode: " + deploymentMode + ", values: " + valueList);
				break;
			} else {
				valueList = null;
			}
		}

		if (valueList == null) {
			logger.warn("Cannot find valueList for deploymentMode: " + deploymentMode
					+ ". Current configured valueList keys: " + scopeValueListMap.keySet());
		}

		if (commonValueList != null && commonValueList.size() > 0) {
			if (defaultValueList != null) {
				defaultValueList.addAll(commonValueList);
			}

			if (valueList != null) {
				valueList.addAll(commonValueList);
			}
		}
	}

	/**
	 * Sets the fallback to default.
	 *
	 * @param fallbackToDefault
	 *            the fallbackToDefault to set
	 */
	public void setFallbackToDefault(boolean fallbackToDefault) {
		this.fallbackToDefault = fallbackToDefault;
		logger.debug("In setFallbackToDefault, fallbackToDefault: " + fallbackToDefault);
	}

	/**
	 * Gets the value list.
	 *
	 * @return the value list
	 */
	public List getValueList() {
		if (valueList == null) {
			logger.warn("Cannot find valueList for deploymentMode: " + deploymentMode);
			logger.debug("fallbackToDefault: " + fallbackToDefault);
			if (fallbackToDefault) {
				logger.warn("Trying to fallback on default list");
				if (defaultValueList == null) {
					throw new IllegalArgumentException(
							"Value list not configured for <deploymentMode> or default: " + deploymentMode);
				} else {
					logger.debug("DefaultValueList values: " + defaultValueList);
					return defaultValueList;
				}
			} else {
				throw new IllegalArgumentException("Value list not configured for <deploymentMode>: " + deploymentMode);
			}
		}
		return valueList;
	}

}
