package com.nec.biomatcher.core.framework.common;

public class ApplicationBuildInfo {
	private static String buildVersion;
	private static String buildDateTime;

	public static String getBuildVersion() {
		return buildVersion;
	}

	public void setBuildVersion(String buildVersion) {
		ApplicationBuildInfo.buildVersion = buildVersion;
	}

	public static String getBuildDateTime() {
		return buildDateTime;
	}

	public void setBuildDateTime(String buildDateTime) {
		ApplicationBuildInfo.buildDateTime = buildDateTime;
	}
}
