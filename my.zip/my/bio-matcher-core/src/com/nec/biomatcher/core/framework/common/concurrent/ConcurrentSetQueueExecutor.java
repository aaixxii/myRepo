package com.nec.biomatcher.core.framework.common.concurrent;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.Semaphore;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.Supplier;

import org.apache.log4j.Logger;
import org.apache.log4j.NDC;

import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.ComparableItem;
import com.nec.biomatcher.core.framework.common.ShutdownHook;

/**
 * Objective of the set queue processor is to minimize the number of executions
 * called for the key if concurrently same key is added to the queue. And also
 * keep the execution order in the order in which its added to queue.
 * 
 * @author MAHESH
 *
 * @param <T>
 */
public class ConcurrentSetQueueExecutor<T> {
	private static final Logger logger = Logger.getLogger(ConcurrentSetQueueExecutor.class);

	private final ThreadPoolExecutor executorService = new ThreadPoolExecutor(0, Integer.MAX_VALUE, 60L,
			TimeUnit.SECONDS, new SynchronousQueue<Runnable>(), new RejectedHandler());

	private final String name;
	private final ConcurrentSkipListSet<ComparableItem<T>> queue = new ConcurrentSkipListSet<>();
	private final Consumer<T> consumer;
	private final DynamicSemaphore concurrencySemaphore;

	private final Semaphore queueDataWaitSemaphore = new Semaphore(0);
	private final Semaphore startWaitSemaphore = new Semaphore(0);

	private final ConcurrentHashMap<T, WorkerThread> execWorkerMap = new ConcurrentHashMap<>();

	public ConcurrentSetQueueExecutor(String name, Consumer<T> consumer, Supplier<Integer> concurrencySupplier) {
		this.name = name;
		this.consumer = consumer;
		this.concurrencySemaphore = DynamicSemaphore.getInstance("CSQE_Concurrency_" + name, concurrencySupplier);

		CommonTaskScheduler.scheduleWithFixedDelay(new SubmitThread(), 10, 10, TimeUnit.MILLISECONDS);

		CommonLogger.STATUS_LOG.info("In ConcurrentSetQueueExecutor() for  name: " + name);
	}

	public void start() {
		startWaitSemaphore.release(10);
	}

	public final boolean addToQueue(T data) {
		if (data != null) {
			WorkerThread oldWorker = execWorkerMap.get(data);
			if (oldWorker != null && oldWorker.notifyNewData()) {
				return true;
			}

			return addToQueue(new ComparableItem<>(data));
		}
		return false;
	}

	private final boolean addToQueue(ComparableItem<T> item) {
		if (item != null) {
			if (queue.add(item)) {
				queueDataWaitSemaphore.release();
				return true;
			}
		}
		return false;
	}

	public int getQueueSize() {
		return queue.size();
	}

	public int getAvailablePermits() {
		return concurrencySemaphore.availablePermits();
	}

	public int getCurrentExecutionThreadCount() {
		return concurrencySemaphore.acquiredCount();
	}

	private final class SubmitThread implements Runnable {
		@Override
		public void run() {
			try {
				NDC.clear();
				Thread.currentThread().setName("CSQE_SUB_" + name + "_" + Thread.currentThread().getId());
				CommonLogger.STATUS_LOG.info("In ConcurrentSetQueueExecutor.SubmitThread for  name: " + name
						+ ", startWaitSemaphore.availablePermits: " + startWaitSemaphore.availablePermits());

				startWaitSemaphore.acquireUninterruptibly();

				while (!ShutdownHook.isShutdownFlag) {
					try {
						concurrencySemaphore.acquireUninterruptibly();
						try {
							ComparableItem<T> item = null;
							do {
								while ((item = queue.pollFirst()) == null) {
									queueDataWaitSemaphore.tryAcquire(5, TimeUnit.SECONDS);
									queueDataWaitSemaphore.drainPermits();
								}

								WorkerThread oldWorker = execWorkerMap.get(item.getValue());
								if (oldWorker != null && oldWorker.notifyNewData()) {
									// ignore this item as oldWorker is
									// currently executing it
									item = null;
								}
							} while (item == null);

							WorkerThread newWorkerThread = new WorkerThread(item);
							try {
								executorService.execute(newWorkerThread);
							} catch (Throwable th) {
								execWorkerMap.remove(item.getValue(), newWorkerThread);

								concurrencySemaphore.release();

								// Add it back to queue, so it will try to
								// process it in next cycle
								addToQueue(item);

								logger.error("Error while submitting to WorkerThread for name: " + name + " : "
										+ th.getMessage(), th);
							}
						} catch (Throwable th) {
							concurrencySemaphore.release();
							logger.error("Error in SubmitThread while polling setQueue for name: " + name + " : "
									+ th.getMessage(), th);
						}
					} catch (Throwable th) {
						logger.error(
								"Error while submitting to WorkerThread for name: " + name + " : " + th.getMessage(),
								th);
					}
				}
			} catch (Throwable th) {
				logger.error("Error during WorkerThread.run for name: " + name + " : " + th.getMessage(), th);
			} finally {
				startWaitSemaphore.release();
				CommonLogger.STATUS_LOG.warn("Exiting ConcurrentSetQueueExecutor.SubmitThread for name: " + name
						+ ", isShutdownFlag: " + ShutdownHook.isShutdownFlag);
			}

		}
	}

	private final class WorkerThread implements Runnable {
		private final ComparableItem<T> item;
		private volatile boolean newDataFlag = true;
		private volatile boolean execFlag = true;

		public WorkerThread(ComparableItem<T> item) {
			this.item = item;
			execWorkerMap.put(item.getValue(), WorkerThread.this);
		}

		public final boolean notifyNewData() {
			newDataFlag = true;
			return execFlag;
		}

		@Override
		public void run() {
			try {
				Thread.currentThread().setName("CSQE_WRK_" + name + "_" + Thread.currentThread().getId());
				NDC.clear();
				try {
					do {
						newDataFlag = false;
						consumer.accept(item.getValue());
					} while (newDataFlag);
				} catch (Throwable th) {
					throw th;
				} finally {
					execFlag = false;
					execWorkerMap.remove(item.getValue(), WorkerThread.this);

					if (newDataFlag) {
						// Add it back to queue, so it will try to process it in
						// next cycle
						addToQueue(item);
					}
				}
			} catch (Throwable th) {
				logger.error("Error during WorkerThread.run for name: " + name + ", data: " + item.getValue() + " : "
						+ th.getMessage(), th);
			} finally {
				concurrencySemaphore.release();
			}
		}
	}

	private final class RejectedHandler implements RejectedExecutionHandler {
		@Override
		public void rejectedExecution(Runnable r, ThreadPoolExecutor executor) {
			CommonLogger.STATUS_LOG.error("In ConcurrentSetQueueExecutor[RejectedHandler.rejectedExecution] for name: "
					+ name + ", isPoolShutdown: " + executor.isShutdown() + ", Runnable: " + r.getClass().getName());

			if (!executor.isShutdown()) {
				try {
					r.run();
				} catch (Throwable th) {
					logger.error(
							"In while run in ConcurrentSetQueueExecutor[RejectedHandler.rejectedExecution] for name: "
									+ name);
				}
			}
		}
	}

}
