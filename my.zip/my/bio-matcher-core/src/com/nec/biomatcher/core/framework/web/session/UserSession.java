package com.nec.biomatcher.core.framework.web.session;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.nec.biomatcher.core.framework.dataAccess.Dbo;

/**
 * The Class UserSession.
 */
public class UserSession implements Dbo {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Constant attributeName. */
	public final static String attributeName = "ATTRIB_USERSESSION";

	/** The user id. */
	private String userId;

	/** The user id. */
	private String userAcctId;

	/** The user name. */
	private String userName;

	/** The workstation id. */
	private String workstationId;

	/** The system id. */
	private String systemId;

	/** The login date time. */
	private Date loginDateTime;

	/** The domain. */
	private String domain;

	/** The organization. */
	private String organization;

	/** The scope. */
	private String scope;

	/** The functions. */
	private Set<String> functions = new HashSet<String>();

	/** The roles. */
	private Set<String> roles = new HashSet<String>();

	/** The days to expire. */
	private int daysToExpire = 0;

	/** The attributes. */
	private HashMap<String, String> attributes = new HashMap<String, String>();

	/** The password change required. */
	private boolean passwordChangeRequired = false;

	/** The system account type. */
	private boolean systemAccountType = false;

	/**
	 * Gets the attributes.
	 *
	 * @return the attributes
	 */
	public HashMap<String, String> getAttributes() {
		return attributes;
	}

	/**
	 * Sets the attributes.
	 *
	 * @param attributes
	 *            the attributes
	 */
	public void setAttributes(HashMap<String, String> attributes) {
		this.attributes = attributes;
	}

	/**
	 * Gets the user id.
	 *
	 * @return the user id
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * Sets the user id.
	 *
	 * @param userId
	 *            the new user id
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * Gets the user name.
	 *
	 * @return the user name
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * Sets the user name.
	 *
	 * @param userName
	 *            the new user name
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * Gets the workstation id.
	 *
	 * @return the workstation id
	 */
	public String getWorkstationId() {
		return workstationId;
	}

	/**
	 * Sets the workstation id.
	 *
	 * @param workstationId
	 *            the new workstation id
	 */
	public void setWorkstationId(String workstationId) {
		this.workstationId = workstationId;
	}

	/**
	 * Gets the login date time.
	 *
	 * @return the login date time
	 */
	public Date getLoginDateTime() {
		return loginDateTime;
	}

	/**
	 * Sets the login date time.
	 *
	 * @param loginDateTime
	 *            the new login date time
	 */
	public void setLoginDateTime(Date loginDateTime) {
		this.loginDateTime = loginDateTime;
	}

	/**
	 * Gets the functions.
	 *
	 * @return the functions
	 */
	public Set<String> getFunctions() {
		return functions;
	}

	/**
	 * Sets the functions.
	 *
	 * @param functions
	 *            the new functions
	 */
	public void setFunctions(Set<String> functions) {
		this.functions = functions;
	}

	/**
	 * Adds the function.
	 *
	 * @param functionId
	 *            the function id
	 */
	public void addFunction(String functionId) {
		this.functions.add(functionId);
	}

	/**
	 * Gets the roles.
	 *
	 * @return the roles
	 */
	public Set<String> getRoles() {
		return roles;
	}

	/**
	 * Sets the roles.
	 *
	 * @param roles
	 *            the new roles
	 */
	public void setRoles(Set<String> roles) {
		this.roles = roles;
	}

	/**
	 * Adds the role.
	 *
	 * @param roleId
	 *            the role id
	 */
	public void addRole(String roleId) {
		this.roles.add(roleId);
	}

	/**
	 * Gets the functions list.
	 *
	 * @return the functions list
	 */
	public String getFunctionsList() {
		String functionStr = StringUtils.join(this.functions.iterator(), " ");
		return functionStr;
	}

	/**
	 * Gets the days to expire.
	 *
	 * @return the days to expire
	 */
	public int getDaysToExpire() {
		return daysToExpire;
	}

	/**
	 * Sets the days to expire.
	 *
	 * @param daysToExpire
	 *            the new days to expire
	 */
	public void setDaysToExpire(int daysToExpire) {
		this.daysToExpire = daysToExpire;
	}

	/**
	 * Gets the system id.
	 *
	 * @return the system id
	 */
	public String getSystemId() {
		return systemId;
	}

	/**
	 * Sets the system id.
	 *
	 * @param systemId
	 *            the new system id
	 */
	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	/**
	 * Gets the domain.
	 *
	 * @return the domain
	 */
	public String getDomain() {
		return domain;
	}

	/**
	 * Sets the domain.
	 *
	 * @param domain
	 *            the new domain
	 */
	public void setDomain(String domain) {
		this.domain = domain;
	}

	/**
	 * Gets the scope.
	 *
	 * @return the scope
	 */
	public String getScope() {
		return scope;
	}

	/**
	 * Sets the scope.
	 *
	 * @param scope
	 *            the new scope
	 */
	public void setScope(String scope) {
		this.scope = scope;
	}

	/**
	 * @return the userAcctId
	 */
	public String getUserAcctId() {
		return userAcctId;
	}

	/**
	 * @param userAcctId
	 *            the userAcctId to set
	 */
	public void setUserAcctId(String userAcctId) {
		this.userAcctId = userAcctId;
	}

	/**
	 * @return the passwordChangeRequired
	 */
	public boolean isPasswordChangeRequired() {
		return passwordChangeRequired;
	}

	/**
	 * @param passwordChangeRequired
	 *            the passwordChangeRequired to set
	 */
	public void setPasswordChangeRequired(boolean passwordChangeRequired) {
		this.passwordChangeRequired = passwordChangeRequired;
	}

	/**
	 * @return the organization
	 */
	public String getOrganization() {
		return organization;
	}

	/**
	 * @param organization
	 *            the organization to set
	 */
	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public boolean isSystemAccountType() {
		return systemAccountType;
	}

	public void setSystemAccountType(boolean systemAccountType) {
		this.systemAccountType = systemAccountType;
	}

}
