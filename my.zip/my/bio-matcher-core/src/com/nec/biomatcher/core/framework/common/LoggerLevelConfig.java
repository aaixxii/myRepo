package com.nec.biomatcher.core.framework.common;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;

public class LoggerLevelConfig implements InitializingBean {
	private static final Logger logger = Logger.getLogger(LoggerLevelConfig.class);

	private Map<String, String> logCategoryMap = new HashMap<>();

	public void setLogCategoryMap(Map<String, String> logCategoryMap) {
		if (logCategoryMap != null) {
			this.logCategoryMap.putAll(logCategoryMap);
		}
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		logger.info("In LoggerLevelConfig: afterPropertiesSet: logCategoryMapSize: " + logCategoryMap.size());

		for (String logCategory : logCategoryMap.keySet()) {
			String logLevel = logCategoryMap.get(logCategory);
			try {
				Logger _logger = Logger.getLogger(logCategory);
				_logger.setLevel(Level.toLevel(logLevel));
				// _logger.setAdditivity(false);
			} catch (Throwable th) {
				logger.error("Error in LoggerLevelConfig for logCategory: " + logCategory + ", logLevel: " + logLevel
						+ " : " + th.getMessage(), th);
			}
		}

		logCategoryMap.clear();
	}

}
