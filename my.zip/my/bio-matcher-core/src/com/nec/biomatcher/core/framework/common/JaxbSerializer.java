package com.nec.biomatcher.core.framework.common;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;
import javax.xml.transform.stream.StreamSource;

import org.apache.log4j.Logger;
import org.w3c.dom.Node;

import com.nec.biomatcher.core.framework.common.exception.ObjectCreationException;
import com.nec.biomatcher.core.framework.common.exception.SerializationException;

/**
 * The Class JaxbSerializer.
 */
public abstract class JaxbSerializer {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(JaxbSerializer.class);

	public static final JaxbSerializer getInstance(final Class<?>... classes) {
		JaxbSerializer jaxbSerializer = new JaxbSerializer() {
			@Override
			protected JAXBContext getJAXBContext() {
				try {
					return JAXBContext.newInstance(classes);
				} catch (Throwable th) {
					throw new ObjectCreationException("Error creating jaxbContext : " + th.getMessage(), th);
				}
			}
		};
		return jaxbSerializer;
	}

	/**
	 * Gets the jAXB context.
	 *
	 * @return the jAXB context
	 */
	protected abstract JAXBContext getJAXBContext();

	/**
	 * Unmarshal.
	 *
	 * @param objXml
	 *            the obj xml
	 * @return the object
	 * @throws SerializationException
	 *             the jaxb xml convertor exception
	 */
	public Object unmarshal(String objXml) throws SerializationException {
		try {

			Unmarshaller unMarshaller = getJAXBContext().createUnmarshaller();
			StringReader reader = new StringReader(objXml);
			try {
				Object obj = (Object) unMarshaller.unmarshal(reader);
				if (obj == null) {
					throw new SerializationException("Invalid objXml");
				}

				return obj;
			} catch (JAXBException ex) {
				logger.error("Error unmarshalling objXml: " + objXml, ex);
				throw new SerializationException("Error unmarshalling objXml: " + ex.getMessage(), ex);
			} finally {
				reader.close();
			}
		} catch (JAXBException ex) {
			logger.error("objXml: " + objXml, ex);
			throw new SerializationException(
					"Error creating Unmarshaller to parse objXml: " + ex.getMessage() + ", objXml: " + objXml, ex);
		}
	}

	/**
	 * Unmarshal.
	 *
	 * @param inNode
	 *            the in node
	 * @return the object
	 * @throws SerializationException
	 *             the jaxb xml convertor exception
	 */
	public Object unmarshal(Node inNode) throws SerializationException {
		try {

			Unmarshaller unMarshaller = getJAXBContext().createUnmarshaller();
			try {
				Object obj = (Object) unMarshaller.unmarshal(inNode);

				if (obj == null) {
					throw new SerializationException("Invalid inNode");
				}

				return obj;
			} catch (JAXBException ex) {
				logger.error("Error in unmarshal : inNode: " + inNode, ex);
				throw new SerializationException("Error unmarshalling inNode: " + ex.getMessage(), ex);
			}
		} catch (JAXBException ex) {
			throw new SerializationException(
					"Error creating Unmarshaller to parse inNode: " + ex.getMessage() + ", inNode: " + inNode, ex);
		}
	}

	/**
	 * Unmarshal.
	 *
	 * @param inputStream
	 *            the input stream
	 * @return the object
	 * @throws SerializationException
	 *             the serialization exception
	 */
	public Object unmarshal(InputStream inputStream) throws SerializationException {
		try {

			Unmarshaller unMarshaller = getJAXBContext().createUnmarshaller();
			try {
				Object obj = (Object) unMarshaller.unmarshal(inputStream);
				if (obj == null) {
					throw new SerializationException("Invalid objXml");
				}

				return obj;
			} catch (JAXBException ex) {
				logger.error("Error during unmarshal with inputstream: " + ex.getMessage(), ex);
				throw new SerializationException("Error during unmarshal with inputstream: " + ex.getMessage(), ex);
			}
		} catch (JAXBException ex) {
			logger.error("Error during unmarshal with inputstream: " + ex.getMessage(), ex);
			throw new SerializationException("Error during unmarshal with inputstream: " + ex.getMessage(), ex);
		}
	}

	/**
	 * Used for unmarshaling non root objects xml content.
	 *
	 * @param <T>
	 *            the generic type
	 * @param inputStream
	 *            the input stream
	 * @param declaredType
	 *            the declared type
	 * @return the t
	 * @throws SerializationException
	 *             the serialization exception
	 */
	public <T> T unmarshal(InputStream inputStream, Class<T> declaredType) throws SerializationException {
		try {

			Unmarshaller unMarshaller = getJAXBContext().createUnmarshaller();
			try {
				JAXBElement<T> jaxbObj = unMarshaller.unmarshal(new StreamSource(inputStream), declaredType);
				if (jaxbObj == null || jaxbObj.getValue() == null) {
					throw new SerializationException("Invalid objXml");
				}

				return jaxbObj.getValue();
			} catch (JAXBException ex) {
				logger.error("Error during unmarshal with inputstream: " + ex.getMessage(), ex);
				throw new SerializationException("Error during unmarshal with inputstream: " + ex.getMessage(), ex);
			}
		} catch (JAXBException ex) {
			logger.error("Error during unmarshal with inputstream: " + ex.getMessage(), ex);
			throw new SerializationException("Error during unmarshal with inputstream: " + ex.getMessage(), ex);
		}
	}

	/**
	 * Marshal.
	 *
	 * @param obj
	 *            the obj
	 * @return the string
	 * @throws SerializationException
	 *             the jaxb xml convertor exception
	 */
	public String marshal(Object obj) throws SerializationException {
		try {
			Marshaller marshaller = getJAXBContext().createMarshaller();
			if (formatOutput()) {
				marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			}
			StringWriter writer = new StringWriter();
			try {
				marshaller.marshal(obj, writer);
				String objXml = writer.toString();

				if (objXml == null || objXml.trim().length() == 0) {
					throw new SerializationException("Error marshalling obj to xml, obj: " + obj);
				}
				return objXml;
			} catch (JAXBException ex) {
				throw new SerializationException("Error marshalling objXml: " + ex.getMessage(), ex);
			} finally {
				// closing writer has no effect
				try {
					writer.close();
				} catch (IOException e) {
				}
			}
		} catch (JAXBException ex) {
			throw new SerializationException("Error creating Marshaller to generate objXml: " + ex.getMessage(), ex);
		}
	}

	public byte[] marshalToBytes(Object obj) throws SerializationException {
		try {
			Marshaller marshaller = getJAXBContext().createMarshaller();
			if (formatOutput()) {
				marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			}
			try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
				marshaller.marshal(obj, baos);
				byte[] byteBuf = baos.toByteArray();
				if (byteBuf == null || byteBuf.length == 0) {
					throw new SerializationException("Error marshalling obj to xml, obj: " + obj);
				}
				return byteBuf;
			} catch (JAXBException ex) {
				throw new SerializationException("Error marshalling obj: " + ex.getMessage(), ex);
			} catch (IOException ex) {
				throw new SerializationException("Error marshalling obj: " + ex.getMessage(), ex);
			}
		} catch (JAXBException ex) {
			throw new SerializationException("Error creating Marshaller : " + ex.getMessage(), ex);
		}
	}

	/**
	 * Marshal.
	 *
	 * @param obj
	 *            the obj
	 * @param outNode
	 *            the out node
	 * @throws SerializationException
	 *             the jaxb xml convertor exception
	 */
	public void marshal(Object obj, Node outNode) throws SerializationException {
		try {
			Marshaller marshaller = getJAXBContext().createMarshaller();
			if (formatOutput()) {
				marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			}
			try {
				marshaller.marshal(obj, outNode);
				if (!outNode.hasChildNodes()) {
					throw new SerializationException(
							"Error marshalling obj to xml node, No child nodes found, obj: " + obj);
				}
			} catch (JAXBException ex) {
				throw new SerializationException("Error marshalling obj to Xml node: " + ex.getMessage(), ex);
			}
		} catch (JAXBException ex) {
			throw new SerializationException("Error creating Marshaller to generate objXml: " + ex.getMessage(), ex);
		}
	}

	/**
	 * Marshal.
	 *
	 * @param obj
	 *            the obj
	 * @param outputStream
	 *            the output stream
	 * @throws SerializationException
	 *             the serialization exception
	 */
	public void marshal(Object obj, OutputStream outputStream) throws SerializationException {
		try {
			Marshaller marshaller = getJAXBContext().createMarshaller();
			if (formatOutput()) {
				marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			}
			try {
				marshaller.marshal(obj, outputStream);
			} catch (JAXBException ex) {
				throw new SerializationException("Error marshalling objXml: " + ex.getMessage(), ex);
			}
		} catch (JAXBException ex) {
			throw new SerializationException("Error creating Marshaller to generate objXml: " + ex.getMessage(), ex);
		}
	}

	/**
	 * Used for marshaling non root objects.
	 *
	 * @param obj
	 *            the obj
	 * @param qName
	 *            the q name
	 * @param declaredType
	 *            the declared type
	 * @param outputStream
	 *            the output stream
	 * @throws SerializationException
	 *             the serialization exception
	 */
	public void marshal(Object obj, QName qName, Class declaredType, OutputStream outputStream)
			throws SerializationException {
		try {
			Marshaller marshaller = getJAXBContext().createMarshaller();
			if (formatOutput()) {
				marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			}
			try {
				JAXBElement<Object> root = new JAXBElement<Object>(qName, declaredType, obj);
				marshaller.marshal(root, outputStream);
			} catch (JAXBException ex) {
				throw new SerializationException("Error marshalling objXml: " + ex.getMessage(), ex);
			}
		} catch (JAXBException ex) {
			throw new SerializationException("Error creating Marshaller to generate objXml: " + ex.getMessage(), ex);
		}
	}

	/**
	 * Format output.
	 *
	 * @return true, if successful
	 */
	protected boolean formatOutput() {
		return false;
	}
}
