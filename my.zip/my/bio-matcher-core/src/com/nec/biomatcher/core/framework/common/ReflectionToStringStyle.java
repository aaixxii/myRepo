package com.nec.biomatcher.core.framework.common;

import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.SystemUtils;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * This ToString style class will output primitive arrays in summary format
 * insted of dumping each element of array.
 * 
 * @author Mahesh
 */
public final class ReflectionToStringStyle extends ToStringStyle {

	/** The Constant CUSTOM_STYLE. */
	public static final ToStringStyle CUSTOM_STYLE = new ReflectionToStringStyle();

	/**
	 * Read resolve.
	 *
	 * @return the object
	 */
	private Object readResolve() {

		return ReflectionToStringStyle.CUSTOM_STYLE;
	}

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new reflection to string style.
	 */
	private ReflectionToStringStyle() {
		setContentStart("[");
		setFieldSeparator(SystemUtils.LINE_SEPARATOR + "  ");
		setFieldSeparatorAtStart(true);
		setContentEnd(SystemUtils.LINE_SEPARATOR + "]");
		setDefaultFullDetail(true);
		setUseShortClassName(true);
		setUseIdentityHashCode(false);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.apache.commons.lang.builder.ToStringStyle#appendDetail(java.lang.
	 * StringBuffer, java.lang.String, java.lang.Object)
	 */
	protected void appendDetail(StringBuffer buffer, String fieldName, Object value) {
		if (value != null) {
			Class valueClass = value.getClass();
			if (!valueClass.isPrimitive() && !valueClass.isArray() && !valueClass.equals(String.class)) {
				try {
					Method method = valueClass.getMethod("toString", (Class[]) null);
					if (method.getDeclaringClass().equals(Object.class)) {
						new ReflectionToStringBuilder(value, this, buffer).toString();
						return;
					}
				} catch (Exception e) {
					throw new InternalError(ExceptionMessageFormatter.format(e));
				}
			}
		}

		super.appendDetail(buffer, fieldName, value);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.apache.commons.lang.builder.ToStringStyle#appendDetail(java.lang.
	 * StringBuffer, java.lang.String, java.util.Collection)
	 */
	protected void appendDetail(StringBuffer buffer, String fieldName, Collection coll) {
		if (coll != null && !coll.isEmpty()) {
			for (Object obj : coll) {
				appendDetail(buffer, fieldName, obj);
			}
		} else {
			buffer.append(coll);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.apache.commons.lang.builder.ToStringStyle#appendDetail(java.lang.
	 * StringBuffer, java.lang.String, java.util.Map)
	 */
	protected void appendDetail(StringBuffer buffer, String fieldName, Map map) {
		if (map != null && !map.isEmpty()) {
			appendDetail(buffer, fieldName, map.entrySet());
		} else {
			buffer.append(map);
		}
	}

	/**
	 * Append detail.
	 *
	 * @param buffer
	 *            the buffer
	 * @param fieldName
	 *            the field name
	 * @param entry
	 *            the entry
	 */
	protected void appendDetail(StringBuffer buffer, String fieldName, Entry entry) {
		buffer.append("[").append(entry.getKey()).append("=");
		appendDetail(buffer, fieldName, entry.getValue());
		buffer.append("]");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.apache.commons.lang.builder.ToStringStyle#appendDetail(java.lang.
	 * StringBuffer, java.lang.String, boolean[])
	 */
	protected void appendDetail(StringBuffer buffer, String fieldName, boolean array[]) {
		appendSummarySize(buffer, fieldName, array.length);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.apache.commons.lang.builder.ToStringStyle#appendDetail(java.lang.
	 * StringBuffer, java.lang.String, byte[])
	 */
	protected void appendDetail(StringBuffer buffer, String fieldName, byte array[]) {
		appendSummarySize(buffer, fieldName, array.length);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.apache.commons.lang.builder.ToStringStyle#appendDetail(java.lang.
	 * StringBuffer, java.lang.String, char[])
	 */
	protected void appendDetail(StringBuffer buffer, String fieldName, char array[]) {
		appendSummarySize(buffer, fieldName, array.length);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.apache.commons.lang.builder.ToStringStyle#appendDetail(java.lang.
	 * StringBuffer, java.lang.String, short[])
	 */
	protected void appendDetail(StringBuffer buffer, String fieldName, short array[]) {
		appendSummarySize(buffer, fieldName, array.length);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.apache.commons.lang.builder.ToStringStyle#appendDetail(java.lang.
	 * StringBuffer, java.lang.String, int[])
	 */
	protected void appendDetail(StringBuffer buffer, String fieldName, int array[]) {
		appendSummarySize(buffer, fieldName, array.length);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.apache.commons.lang.builder.ToStringStyle#appendDetail(java.lang.
	 * StringBuffer, java.lang.String, float[])
	 */
	protected void appendDetail(StringBuffer buffer, String fieldName, float array[]) {
		appendSummarySize(buffer, fieldName, array.length);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.apache.commons.lang.builder.ToStringStyle#appendDetail(java.lang.
	 * StringBuffer, java.lang.String, double[])
	 */
	protected void appendDetail(StringBuffer buffer, String fieldName, double array[]) {
		appendSummarySize(buffer, fieldName, array.length);
	}
}