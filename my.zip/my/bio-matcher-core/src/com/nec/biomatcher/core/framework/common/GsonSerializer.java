package com.nec.biomatcher.core.framework.common;

import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.Collection;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

/**
 * The Class GsonSerializer.
 */
public class GsonSerializer {

	/** The Constant GSON. */
	public static final Gson GSON = new Gson();

	public static final Gson GSON_PRETTY = new GsonBuilder().setPrettyPrinting().create();

	private static final Gson GSON_LOG = new GsonBuilder()
			.registerTypeHierarchyAdapter(byte[].class, new ByteArrayToLenghtTypeAdapter()).create();

	private static final Gson GSON_PRETTY_LOG = new GsonBuilder().setPrettyPrinting()
			.registerTypeHierarchyAdapter(byte[].class, new ByteArrayToLenghtTypeAdapter()).create();

	private static class ByteArrayToLenghtTypeAdapter implements JsonSerializer<byte[]>, JsonDeserializer<byte[]> {
		private static final char[] hexCode = "0123456789ABCDEF".toCharArray();

		public byte[] deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context)
				throws JsonParseException {
			return json.getAsString().getBytes();
		}

		public JsonElement serialize(byte[] src, Type typeOfSrc, JsonSerializationContext context) {
			if (src == null || src.length > 64 || src.length == 0) {
				return new JsonPrimitive("byteDataLength: " + (src == null ? "null" : src.length));
			} else {
				StringBuilder sb = new StringBuilder(src.length * 3);
				for (byte b : src) {
					sb.append(hexCode[(b >> 4) & 0xF]);
					sb.append(hexCode[(b & 0xF)]);
					sb.append(' ');
				}
				return new JsonPrimitive(sb.toString().trim());
			}
		}
	}

	/**
	 * To json.
	 *
	 * @param src
	 *            the src
	 * @return the string
	 */
	public static final String toJson(Object src) {
		if (src == null) {
			return null;
		}
		return GSON.toJson(src);
	}

	public static final String toPrettyJson(Object src) {
		if (src == null) {
			return null;
		}
		return GSON_PRETTY.toJson(src);
	}

	/**
	 * To json.
	 *
	 * @param src
	 *            the src
	 * @param typeOfT
	 *            the type of t
	 * @return the string
	 */
	public static final String toJson(Object src, Type typeOfT) {
		return GSON.toJson(src, typeOfT);
	}

	public static final String toPrettyJson(Object src, Type typeOfT) {
		return GSON_PRETTY.toJson(src, typeOfT);
	}

	/**
	 * From json.
	 *
	 * @param <T>
	 *            the generic type
	 * @param src
	 *            the src
	 * @param typeOfT
	 *            the type of t
	 * @return the t
	 */
	public static final <T> T fromJson(String src, Type typeOfT) {
		return GSON.fromJson(src, typeOfT);
	}

	/**
	 * From json.
	 *
	 * @param <T>
	 *            the generic type
	 * @param src
	 *            the src
	 * @param classOfT
	 *            the class of t
	 * @return the t
	 */
	public static final <T> T fromJson(String src, Class<T> classOfT) {
		return GSON.fromJson(src, classOfT);
	}

	public static final JsonArray toJsonArray(Collection<String> coll) {
		JsonArray jsonArray = new JsonArray();
		if (coll != null) {
			for (String item : coll) {
				jsonArray.add(new JsonPrimitive(item));
			}
		}
		return jsonArray;
	}

	public static final String toJsonLog(Object src) {
		try {
			if (src != null) {
				return GSON_LOG.toJson(src);
			}
		} catch (Throwable th) {
			// Suppress the error, since its for logging only
		}
		return "";
	}

	public static final String toJsonLog(Object... src) {
		try {
			if (src != null) {
				return GSON_LOG.toJson(src);
			}
		} catch (Throwable th) {
			// Suppress the error, since its for logging only
		}
		return "";
	}

	public static final String toPrettyJsonLog(Object... src) {
		try {
			if (src != null) {
				return GSON_PRETTY_LOG.toJson(src);
			}
		} catch (Throwable th) {
			// Suppress the error, since its for logging only
		}
		return "";
	}

	/**
	 * The main method.
	 *
	 * @param args
	 *            the arguments
	 * @throws Exception
	 *             the exception
	 */
	public static void main(String args[]) throws Exception {
		byte b[] = new byte[100];
		Arrays.fill(b, (byte) 99);
		System.out.println(toJson(b));
	}
}
