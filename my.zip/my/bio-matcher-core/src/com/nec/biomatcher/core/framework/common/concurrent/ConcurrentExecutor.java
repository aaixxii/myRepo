package com.nec.biomatcher.core.framework.common.concurrent;

import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Supplier;

import org.apache.log4j.Logger;

import com.nec.biomatcher.core.framework.common.ShutdownHook;

/**
 * This ConcurrentExecutor data structure provides ability to increase or
 * decrease the concurrency of the worker threads by starting or stopping the
 * worker threads. The concurrency value is provided dynamically through the
 * concurrencyCountSupplier.
 * 
 * @author mreddy
 *
 */
public class ConcurrentExecutor {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(ConcurrentExecutor.class);

	/** The name. */
	private final String name;

	/** The runnable. */
	private final CustomRunnable runnable;

	/** The concurrency count supplier. */
	private final Supplier<Integer> concurrencyCountSupplier;

	/** The controller thread. */
	private final ControllerThread controllerThread;

	/** The current concurrency count. */
	private int currentConcurrencyCount;

	/** The concurrency semaphore. */
	private Semaphore concurrencySemaphore = new Semaphore(0, true);

	private ConcurrentSkipListSet<WorkerThread> workerThreadList = new ConcurrentSkipListSet<WorkerThread>();

	/**
	 * Instantiates a new concurrent executor.
	 *
	 * @param name
	 *            the name
	 * @param runnable
	 *            the runnable
	 * @param concurrencyCountSupplier
	 *            the concurrency count supplier
	 */
	public ConcurrentExecutor(String name, CustomRunnable runnable, Supplier<Integer> concurrencyCountSupplier) {
		this.name = name;
		this.runnable = runnable;
		this.concurrencyCountSupplier = concurrencyCountSupplier;
		this.controllerThread = new ControllerThread();
	}

	/**
	 * Start.
	 */
	public void start() {
		controllerThread.start();
	}

	private void stopWorker(WorkerThread workerThread) {
		workerThread.stopWorker();
		workerThread.waitForStop();
		logger.info("Worker for : " + name + " is stopped, workerThreadListSize: " + workerThreadList.size());
	}

	/**
	 * The Class ControllerThread.
	 */
	private class ControllerThread extends Thread {
		public void run() {
			while (!ShutdownHook.isShutdownFlag) {
				try {

					// To handle negative value
					int newConcurrencyCount = Math.max(0, concurrencyCountSupplier.get());

					// Adjust Concurrency
					if (newConcurrencyCount != currentConcurrencyCount) {
						long startTimeMilli = System.currentTimeMillis();
						logger.info("Before adjusting concurrency for ConcurrentExecutor: " + name
								+ ", currentConcurrencyCount: " + currentConcurrencyCount + ", newConcurrencyCount: "
								+ newConcurrencyCount);
						if (currentConcurrencyCount < newConcurrencyCount) {
							concurrencySemaphore.release(newConcurrencyCount - currentConcurrencyCount);
						} else {
							int numWorkersToStop = currentConcurrencyCount - newConcurrencyCount;
							for (int i = 0; i < numWorkersToStop && workerThreadList.size() > 0; i++) {
								stopWorker(workerThreadList.first());
							}
						}
						currentConcurrencyCount = newConcurrencyCount;

						logger.info("After adjusting concurrency for ConcurrentExecutor: " + name
								+ ", currentConcurrencyCount: " + currentConcurrencyCount + ", newConcurrencyCount: "
								+ newConcurrencyCount + ", timeTakenMilli: "
								+ (System.currentTimeMillis() - startTimeMilli));
					}

					if (newConcurrencyCount != workerThreadList.size()) {
						int startedCount = 0;
						while (workerThreadList.size() < newConcurrencyCount) {

							WorkerThread workerThread = new WorkerThread();
							workerThread.start();
							workerThread.waitForStart();
							startedCount++;
						}
						logger.info("After starting the WorkerThread for ConcurrentExecutor: " + name
								+ " : workerThreadListSize: " + workerThreadList.size() + ", newlyStartedCount: "
								+ startedCount);
					}
				} catch (Throwable th) {
					logger.error("Error in ControllerThread of ConcurrentExecutor: " + name + " : " + th.getMessage(),
							th);
				} finally {
					try {
						sleep(TimeUnit.SECONDS.toMillis(60));
					} catch (Throwable th) {
						logger.error("Error diring ControllerThread sleep for ConcurrentExecutor: " + name + " : "
								+ th.getMessage(), th);
					}
				}
			}
		}
	}

	/**
	 * The Class WorkerThread.
	 */
	private class WorkerThread extends Thread implements Comparable<WorkerThread> {

		/** The start latch. */
		private final Semaphore startLatch = new Semaphore(0);

		private final Semaphore stopLatch = new Semaphore(0);

		private final AtomicBoolean stopFlag = new AtomicBoolean(false);

		private final String threadName = name + "_WORKER_" + getId();

		/**
		 * Instantiates a new worker thread.
		 */
		public WorkerThread() {

		}

		public void run() {
			try {
				setName(threadName);

				if (logger.isDebugEnabled())
					logger.debug("In Worker thread run : " + threadName);

				workerThreadList.add(this);
				startLatch.release();

				// As these objects are used in loop, bellow assignment will
				// result in faster access to these objects
				final CustomRunnable runnable = ConcurrentExecutor.this.runnable;
				final AtomicBoolean stopFlag = this.stopFlag;

				while (!stopFlag.get()) {
					try {
						runnable.run(stopFlag);
					} catch (Throwable th) {
						logger.error("Error in ConcurrentExecutor worker: " + threadName + ", runnable: "
								+ runnable.getClass().getSimpleName() + " : " + th.getMessage(), th);
					}
				}
				logger.info("Exiting worker thread : " + threadName + ", stopFlag: " + stopFlag.get());
			} finally {
				workerThreadList.remove(this);
				stopLatch.release(100);
				logger.info("Exited worker thread : " + threadName + ", stopFlag: " + stopFlag.get());
			}
		}

		/**
		 * Wait for start.
		 */
		public void waitForStart() {
			startLatch.acquireUninterruptibly();
		}

		public void waitForStop() {
			stopLatch.acquireUninterruptibly();
		}

		public void stopWorker() {
			stopFlag.set(true);
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj) {
				return true;
			}

			if (obj instanceof WorkerThread) {
				return threadName.equals(((WorkerThread) obj).threadName);
			}

			return false;
		}

		@Override
		public int compareTo(WorkerThread other) {
			if (this == other) {
				return 0;
			}
			return threadName.compareTo(other.threadName);
		}
	}

	/**
	 * Stop.
	 */
	public final void stop() {
		workerThreadList.forEach((worker) -> {
			stopWorker(worker);
		});
	}

	@Override
	protected void finalize() throws Throwable {
		stop();

		super.finalize();
	}
}
