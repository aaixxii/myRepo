package com.nec.biomatcher.core.framework.springSupport.function;

import com.google.common.base.Function;

/**
 * The Interface GenericSpringFunctionService.
 */
public interface GenericSpringFunctionService {

	/**
	 * Execute function.
	 *
	 * @param <F>
	 *            the generic type
	 * @param <T>
	 *            the generic type
	 * @param function
	 *            the function
	 * @param input
	 *            the input
	 * @return the t
	 * @throws Exception
	 *             the exception
	 */
	public <F, T> T executeFunction(Function<F, T> function, F input) throws Exception;
}
