package com.nec.biomatcher.core.framework.common;

import org.apache.log4j.Logger;

public interface CommonLogger {
	public static final Logger ERROR_LOG = Logger.getLogger("ERRORS");
	public static final Logger APP_LOG = Logger.getLogger("APP_LOG");
	public static final Logger STATUS_LOG = Logger.getLogger("STATUS_LOG");
	public static final Logger CONFIG_LOG = Logger.getLogger("CONFIG_LOG");
	public static final Logger PERF_LOG = Logger.getLogger("PFLogger");
	public static final Logger PAYLOAD_LOG = Logger.getLogger("MATCHER_PAYLOAD_LOG");
	public static final Logger REQUEST_PAYLOAD_LOG = Logger.getLogger("MATCHER_NODE_REQUEST");
	public static final Logger RESPONSE_PAYLOAD_LOG = Logger.getLogger("MATCHER_NODE_RESPONSE");

}
