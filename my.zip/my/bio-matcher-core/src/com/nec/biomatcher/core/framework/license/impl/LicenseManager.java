package com.nec.biomatcher.core.framework.license.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

import com.google.common.base.Throwables;
import com.nec.biomatcher.core.framework.common.DateUtil;
import com.nec.biomatcher.core.framework.license.exception.InvalidLicenseException;
import com.xformation.lmx.Lmx;
import com.xformation.lmx.LmxException;
import com.xformation.lmx.LmxFeatureInfo;
import com.xformation.lmx.LmxHostidType;
import com.xformation.lmx.LmxSettings;

import jp.co.nec.aim_xm.license.broker.LicenseBroker;
import jp.co.nec.aim_xm.license.exception.InvalidFloatingLicenseException;
import jp.co.nec.aim_xm.license.floating.FloatingLicenseManager;

/**
 * License Control Manager to load the license information from the license key.
 * Currently, it is implemented based on License3j API which provides the
 * underlying functions to create and assert license files. This implementation
 * uses assymetric cryptography which uses different key to encode and decode
 * the license and thus making the application more secure. Currently, the
 * license information is only limited to the followings:
 * 
 * 1) Valid Start Date (Issue Date) 2) Valid End Date (Expiry Date) 3) Maximum
 * Client Allowed. This controls the number of workstations that can be defined
 * in the system.
 * 
 * @author Alvin Chua
 * @since 15 Sep 2011
 * @version 1.0
 *
 */

public class LicenseManager implements InitializingBean, DisposableBean {
	/** The license control policy. */
	final ConcurrentHashMap<String, LicenseControlPolicy> featureLicenseControlPolicyMap =
		new ConcurrentHashMap<>();

	@SuppressWarnings("serial")
	final ConcurrentHashMap<String, String> capsuleMap = new ConcurrentHashMap<String, String>() {
		{
			put("TEMPLATE_TYPE_1", "FACE");
			put("TEMPLATE_TYPE_2", "FACE");
			put("TEMPLATE_TYPE_3", "FACE");
			put("TEMPLATE_TYPE_4", "FACE");
			put("TEMPLATE_TYPE_11", "IRIS");
			put("TEMPLATE_TYPE_12", "IRIS");
			put("TEMPLATE_TYPE_22", "IRIS");
			put("TEMPLATE_TYPE_31", "FINGER");
			put("TEMPLATE_TYPE_32", "FINGER");
			put("TEMPLATE_TYPE_33", "FINGER");
			put("TEMPLATE_TYPE_34", "FINGER");
			put("TEMPLATE_TYPE_35", "FINGER");
			put("TEMPLATE_TYPE_36", "FINGER");
			put("TEMPLATE_TYPE_37", "PALM");
			put("TEMPLATE_TYPE_38", "PALM");
			put("TEMPLATE_TYPE_39", "PALM");
			put("TEMPLATE_TYPE_40", "PALM");
			put("TEMPLATE_TYPE_41", "FINGER");
			put("TEMPLATE_TYPE_42", "FINGER");
			put("TEMPLATE_TYPE_43", "FINGER");
			put("TEMPLATE_TYPE_44", "FINGER");
			put("TEMPLATE_TYPE_45", "PALM");
			put("TEMPLATE_TYPE_46", "PALM");
			put("TEMPLATE_TYPE_47", "PALM");
			put("TEMPLATE_TYPE_48", "PALM");
		}
	};

	/** The Constant logger. */
	final Logger logger = Logger.getLogger(LicenseManager.class);

	final static int MAJOR = 1;

	final static int MINOR = 0;

	Lmx lmx = new Lmx();

	boolean floating;

	LicenseBroker licenseBroker;

	FloatingLicenseManager floatingLicenseManager;

	public void setLicenseBroker(LicenseBroker licenseBroker) {
		this.licenseBroker = licenseBroker;
	}

	public void setFloatingLicenseManager(FloatingLicenseManager floatingLicenseManager) {
		this.floatingLicenseManager = floatingLicenseManager;
	}

	public void checkFeatureLicense(String featureId)
		throws InvalidLicenseException {
		if (floating) {
			checkFloatingLicense(featureId);
			return;
		} else {
			LicenseControlPolicy licenseControlPolicy = null;
			licenseControlPolicy = featureLicenseControlPolicyMap.get(featureId);
			if (licenseControlPolicy == null) {
				licenseControlPolicy = featureLicenseControlPolicyMap.computeIfAbsent(featureId,
					featureIdKey -> readFeature(featureIdKey));
			}

			if (!licenseControlPolicy.isFeatureEnabled()) {
				throw new InvalidLicenseException("License is not enabled for featureId: "
					+ featureId + ", errorCode: " + licenseControlPolicy.getErrorCode()
					+ ", errorMessage: " + licenseControlPolicy.getErrorMessage());
			}

			long currentTimeMilli = System.currentTimeMillis();
			if (currentTimeMilli < licenseControlPolicy.getValidStartDate().getTime()
				|| currentTimeMilli > licenseControlPolicy.getValidEndDate().getTime()) {
				throw new InvalidLicenseException("License is not enabled for featureId: "
					+ featureId + ", startDate: " + DateUtil.parseDate(licenseControlPolicy
						.getValidStartDate(), DateUtil.FORMAT_DATE) + ", endDate: " + DateUtil
							.parseDate(licenseControlPolicy.getValidEndDate(),
								DateUtil.FORMAT_DATE));
			}
		}
	}

	private LicenseControlPolicy readFeature(String featureId) {
		long startTimeMilli = System.currentTimeMillis();
		try {
			String licensePath = System.getProperty("jboss.server.config.dir");
			logger.info("Reading license file from licensePath: " + licensePath);

			String strHostid = lmx.getHostidSimple(LmxHostidType.LMX_HOSTID_ETHERNET);
			logger.info("Ethernet hostid for this system is: " + strHostid);

			lmx.setOption(LmxSettings.LMX_OPT_LICENSE_PATH, licensePath);

			try {
				logger.info("Before checking feature license for featureId: " + featureId);

				lmx.checkout(featureId, MAJOR, MINOR, 1);

				LicenseControlPolicy licenseControlPolicy = new LicenseControlPolicy(featureId);
				licenseControlPolicy.setFeatureEnabled(true);

				// Get information about the license
				LmxFeatureInfo lmxFeatureInfo = lmx.getFeatureInfo(featureId);
				logger.info("end:" + lmxFeatureInfo.getEndDate());

				licenseControlPolicy.setMaxClientAllowed((long)lmxFeatureInfo
					.getAvailableLicCount());

				if (StringUtils.isNotBlank(lmxFeatureInfo.getStartDate())) {
					Date date = DateUtil.strToDate(lmxFeatureInfo.getStartDate(),
						DateUtil.FORMAT_DATE);
					Calendar cal = Calendar.getInstance();
					cal.setTime(date);
					cal.set(Calendar.HOUR_OF_DAY, 0);
					cal.set(Calendar.MINUTE, 0);
					cal.set(Calendar.SECOND, 0);
					licenseControlPolicy.setValidStartDate(cal.getTime());
				} else {
					Calendar cal = Calendar.getInstance();
					cal.setTime(new Date());
					cal.set(Calendar.HOUR_OF_DAY, 0);
					cal.set(Calendar.MINUTE, 0);
					cal.set(Calendar.SECOND, 0);
					licenseControlPolicy.setValidStartDate(cal.getTime());
				}
				if (StringUtils.isNotBlank(lmxFeatureInfo.getEndDate())) {
					Date date = DateUtil.strToDate(lmxFeatureInfo.getEndDate(),
						DateUtil.FORMAT_DATE);
					Calendar cal = Calendar.getInstance();
					cal.setTime(date);
					cal.set(Calendar.HOUR_OF_DAY, 23);
					cal.set(Calendar.MINUTE, 59);
					cal.set(Calendar.SECOND, 59);
					licenseControlPolicy.setValidEndDate(cal.getTime());
				}

				lmx.checkin(featureId, Lmx.LMX_ALL_LICENSES);

				return licenseControlPolicy;
			} catch (LmxException ex) {
				logger.error("Error during checking feature license for featureId: " + featureId
					+ ", errorCode: " + ex.getErrorCode() + ", errorMessage: " + ex.getErrorStr()
					+ " : " + ex.getMessage(), ex);
				LicenseControlPolicy licenseControlPolicy = new LicenseControlPolicy(featureId);
				licenseControlPolicy.setFeatureId(featureId);
				licenseControlPolicy.setFeatureEnabled(false);
				licenseControlPolicy.setErrorCode(ex.getErrorCode() == null ? "0" : ex
					.getErrorCode().name());
				licenseControlPolicy.setErrorMessage(ex.getErrorStr());
				return licenseControlPolicy;
			}
		} catch (Exception ex) {
			logger.error("Error in readFeature for featureId: " + featureId + " : " + ex
				.getMessage(), ex);
			LicenseControlPolicy licenseControlPolicy = new LicenseControlPolicy(featureId);
			licenseControlPolicy.setFeatureId(featureId);
			licenseControlPolicy.setFeatureEnabled(false);
			licenseControlPolicy.setErrorCode("0");
			licenseControlPolicy.setErrorMessage("Error in readFeature for featureId: " + featureId
				+ " : " + ex.getMessage());
			return licenseControlPolicy;
		} finally {
			long timeTakenMilli = System.currentTimeMillis() - startTimeMilli;
			logger.info("In readFeature for featureId: " + featureId + ", TimeTakenMilli: "
				+ timeTakenMilli);
		}
	}

	private void checkFloatingLicense(String featureId)
		throws InvalidLicenseException {
		try {
			if (!capsuleMap.containsKey(featureId)) {
				throw new InvalidLicenseException("Invalid featureId: " + featureId);
			}
			floatingLicenseManager.checkLicense("", capsuleMap.get(featureId));
		} catch (InvalidFloatingLicenseException ex) {
			if (!floatingLicenseManager.isValid()) {
				throw new InvalidLicenseException("License is not enabled for featureId: "
					+ featureId + ", errorCode: " + ex.getCode() + ", errorMessage: " + ex
						.getMessage());
			} else {
				throw new InvalidLicenseException(ex.getMessage());
			}
		}
	}

	@Override
	public void afterPropertiesSet() {
		logger.debug("called afterPropertiesSet.");

		try {
			lmx.init();

			if (!Objects.isNull(System.getenv("LMX_LICENSE_PATH"))) {
				floating = true;
				lmx.setOption(LmxSettings.LMX_OPT_HOSTID_DISABLED, LmxHostidType.LMX_HOSTID_ALL);
				licenseBroker.init(MAJOR);
			} else {
				lmx.setOption(LmxSettings.LMX_OPT_HOSTID_ENABLED,
					LmxHostidType.LMX_HOSTID_ETHERNET);
			}
		} catch (LmxException ex) {
			logger.error(Throwables.getRootCause(ex).getMessage());
		}
	}

	@Override
	public void destroy()
		throws Exception {
		logger.debug("called destroy.");

		lmx.free();
	}
}