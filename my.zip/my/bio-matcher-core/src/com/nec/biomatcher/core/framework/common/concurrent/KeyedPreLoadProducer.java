package com.nec.biomatcher.core.framework.common.concurrent;

import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import java.util.function.Supplier;

import org.apache.log4j.Logger;

import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.ShutdownHook;

public class KeyedPreLoadProducer<K, V> {
	private static final Logger logger = Logger.getLogger(KeyedPreLoadProducer.class);

	private final ConcurrentValuedHashMap<K, PreLoaderTask> preLoaderTaskMap = new ConcurrentValuedHashMap<>(
			(key) -> new PreLoaderTask(key));

	private final String name;
	private final Function<K, List<V>> valueListProducerFunction;
	private final Supplier<Integer> preLoadMinSizeCheckThresholdSupplier;
	private final DynamicSemaphore concurrencySemaphore;

	public KeyedPreLoadProducer(String name, Function<K, List<V>> valueListProducerFunction,
			Supplier<Integer> preLoadMinSizeCheckThresholdSupplier, Supplier<Integer> concurrencyCountSupplier) {
		CommonLogger.CONFIG_LOG.info("In KeyedPreLoadProducer() for  name: " + name);
		this.name = name;
		this.valueListProducerFunction = valueListProducerFunction;
		this.preLoadMinSizeCheckThresholdSupplier = preLoadMinSizeCheckThresholdSupplier;
		this.concurrencySemaphore = DynamicSemaphore.getInstance(name + "_SEMAPHORE", concurrencyCountSupplier);
	}

	public final V take(K key) throws Throwable {
		PreLoaderTask preLoaderTask = preLoaderTaskMap.getValue(key);
		preLoaderTask.notifyTakeRequest();

		V value = preLoaderTask.getValueListQueue().poll(60, TimeUnit.SECONDS);
		if (value == null) {
			Throwable error = preLoaderTask.getError();
			if (error != null) {
				throw error;
			}
			throw new Exception("valueListQueue.poll returned null for preload producer: " + name + ", key: " + key);
		} else {
			preLoaderTask.getValueListSizeCounter().decrementAndGet();
			return value;
		}
	}

	public void clearPreloaded(K key) {
		PreLoaderTask preLoaderTask = preLoaderTaskMap.getValue(key);
		preLoaderTask.getValueListQueue().clear();
	}

	private final void preLoad(PreLoaderTask preLoaderTask) {
		try {
			logger.debug("In KeyedPreLoadProducer.preLoad for name: " + name + ", key: " + preLoaderTask.getKey());

			int preLoadMinSizeCheckThreshold = preLoadMinSizeCheckThresholdSupplier.get();

			LinkedBlockingQueue<V> valueListQueue = preLoaderTask.getValueListQueue();
			int loopCount = 0;
			while (loopCount++ < 3) {

				if (valueListQueue.size() > preLoadMinSizeCheckThreshold) {
					return;
				}

				List<V> valueList = valueListProducerFunction.apply(preLoaderTask.getKey());

				preLoaderTask.setError(null);

				if (valueList != null && valueList.size() > 0) {
					final int valueListSize = valueList.size();

					valueListQueue.addAll(valueList);

					preLoaderTask.getValueListSizeCounter().addAndGet(valueListSize);
				}
			}
		} catch (Throwable th) {
			preLoaderTask.setError(th);
			logger.error("Error in preLoad for  name: " + name + ", key: " + preLoaderTask.getKey() + " : "
					+ th.getMessage(), th);
		}
	}

	class PreLoaderTask implements Runnable {
		private final Semaphore waitSemaphore = new Semaphore(0);
		private final LinkedBlockingQueue<V> valueListQueue = new LinkedBlockingQueue<>();
		private final AtomicInteger valueListSizeCounter = new AtomicInteger(0);

		private final K key;

		private Throwable error;

		PreLoaderTask(K key) {
			this.key = key;
			CommonTaskScheduler.scheduleWithFixedDelay(this, 50, 100, TimeUnit.MILLISECONDS);
		}

		public K getKey() {
			return key;
		}

		public Throwable getError() {
			return error;
		}

		public void setError(Throwable error) {
			this.error = error;
		}

		public LinkedBlockingQueue<V> getValueListQueue() {
			return valueListQueue;
		}

		public AtomicInteger getValueListSizeCounter() {
			return valueListSizeCounter;
		}

		public void notifyTakeRequest() {
			waitSemaphore.release();
		}

		@Override
		public void run() {
			Thread.currentThread().setName("PRELOADER_" + name + "_" + key + "_" + Thread.currentThread().getId());
			CommonLogger.CONFIG_LOG.info("In PreLoaderTask.run for name: " + name + ", key: " + key);

			while (!ShutdownHook.isShutdownFlag) {
				try {
					waitSemaphore.acquireUninterruptibly();

					int preLoadMinSizeCheckThreshold = preLoadMinSizeCheckThresholdSupplier.get();
					if (valueListSizeCounter.get() > preLoadMinSizeCheckThreshold) {
						waitSemaphore.drainPermits();
						continue;
					}

					concurrencySemaphore.acquireUninterruptibly();
					try {
						waitSemaphore.drainPermits();

						preLoad(this);
					} finally {
						concurrencySemaphore.release();
					}
				} catch (Throwable th) {
					logger.error("Error in PreLoaderTask.run: for  name: " + name + ", key: " + key + " : "
							+ th.getMessage(), th);
				}
			}

			CommonLogger.CONFIG_LOG.warn("Exiting the preloader task for name: " + name + ", key: " + key);
		}
	}
}
