package com.nec.biomatcher.core.framework.dataAccess.types;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.type.StandardBasicTypes;
import org.hibernate.usertype.UserType;

import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import com.nec.biomatcher.core.framework.common.CommonLogger;

/**
 * The Class StringMapUserType.
 */
@SuppressWarnings("rawtypes")
public class StringMapUserType implements UserType, Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	@Override
	public int[] sqlTypes() {
		return new int[] { StandardBasicTypes.STRING.sqlType() };
	}

	@Override
	public Class returnedClass() {
		return Map.class;
	}

	@Override
	public boolean equals(Object x, Object y) throws HibernateException {
		if (x == y) {
			return true;
		}
		if (x == null || y == null) {
			return false;
		}
		return x.equals(y);
	}

	@Override
	public int hashCode(Object x) throws HibernateException {
		return x != null ? x.hashCode() : 1980;
	}

	@Override
	public Object nullSafeGet(ResultSet rs, String[] names, SessionImplementor session, Object owner)
			throws HibernateException, SQLException {
		String value = rs.getString(names[0]);
		if (value == null || value.trim().length() == 0) {
			return null;
		} else {
			try {
				return Splitter.on(",").trimResults().omitEmptyStrings()
						.withKeyValueSeparator(Splitter.on("=").trimResults()).split(value);
			} catch (Throwable th) {
				CommonLogger.ERROR_LOG.error("Error parsing map string: value: " + value + " : " + th.getMessage(), th);
			}
			return null;
		}
	}

	@Override
	public void nullSafeSet(PreparedStatement st, Object value, int index, SessionImplementor session)
			throws HibernateException, SQLException {

		if (value == null) {
			st.setNull(index, StandardBasicTypes.STRING.sqlType());
		} else {
			String stringValue = null;
			if (value instanceof String) {
				stringValue = (String) value;
			} else if (value instanceof Map) {
				stringValue = Joiner.on(",").withKeyValueSeparator("=").join((Map) value);
			}

			if (stringValue != null && stringValue.trim().length() > 0) {
				st.setString(index, stringValue);
			} else {
				st.setNull(index, StandardBasicTypes.STRING.sqlType());
			}
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public Object deepCopy(Object value) throws HibernateException {
		if (value == null) {
			return null;
		}
		return new HashMap((Map) value);
	}

	@Override
	public boolean isMutable() {
		return true;
	}

	@Override
	public Serializable disassemble(Object value) throws HibernateException {
		return (Serializable) value;
	}

	@Override
	public Object assemble(Serializable cached, Object owner) throws HibernateException {
		return cached;
	}

	@Override
	public Object replace(Object original, Object target, Object owner) throws HibernateException {
		return original;
	}

}
