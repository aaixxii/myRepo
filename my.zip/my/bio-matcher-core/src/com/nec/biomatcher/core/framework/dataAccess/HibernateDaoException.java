package com.nec.biomatcher.core.framework.dataAccess;

/**
 * The Class HibernateDaoException.
 */
public class HibernateDaoException extends DaoException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new hibernate dao exception.
	 *
	 * @param message
	 *            the message
	 * @param th
	 *            the th
	 */
	public HibernateDaoException(String message, Throwable th) {
		super(message, th);
	}

	/**
	 * Instantiates a new hibernate dao exception.
	 *
	 * @param message
	 *            the message
	 */
	public HibernateDaoException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new hibernate dao exception.
	 *
	 * @param th
	 *            the th
	 */
	public HibernateDaoException(Throwable th) {
		super(th);
	}

}
