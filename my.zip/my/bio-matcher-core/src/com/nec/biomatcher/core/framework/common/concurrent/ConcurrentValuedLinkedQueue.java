package com.nec.biomatcher.core.framework.common.concurrent;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.function.Supplier;

public class ConcurrentValuedLinkedQueue<T> extends ConcurrentLinkedQueue<T> {
	private static final long serialVersionUID = 1L;
	private Supplier<T> valueSupplier;

	public ConcurrentValuedLinkedQueue(Supplier<T> valueSupplier) {
		this.valueSupplier = valueSupplier;
	}

	@Override
	public T poll() {
		T value = super.poll();
		if (value == null) {
			value = valueSupplier.get();
		}
		return value;
	}

}
