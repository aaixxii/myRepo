package com.nec.biomatcher.core.framework.common;

@FunctionalInterface
public interface CheckedFunction<T, R> {

	R apply(T t) throws Throwable;

}
