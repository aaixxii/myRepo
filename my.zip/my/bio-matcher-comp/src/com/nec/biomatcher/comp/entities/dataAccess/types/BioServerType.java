package com.nec.biomatcher.comp.entities.dataAccess.types;

/**
 * The Enum BioServerType.
 */
public enum BioServerType {

	/** The manager. */
	MANAGER("Manager"),

	/** The worker. */
	WORKER("Worker"),

	/** The report db. */
	REPORT_DB("Report Database"),

	CASSANDRA_DB("Cassandra Database");

	/** The description. */
	private final String description;

	/**
	 * Instantiates a new bio server type.
	 *
	 * @param description
	 *            the description
	 */
	BioServerType(String description) {
		this.description = description;
	}

	public String getDescription() {
		return description;
	}

	public String toString() {
		return name();
	}
}
