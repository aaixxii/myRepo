package com.nec.biomatcher.comp.util;

import org.apache.log4j.Logger;

import com.nec.biomatcher.comp.cluster.ClusterEvent;
import com.nec.biomatcher.comp.cluster.HazelcastAdminCluster;
import com.nec.biomatcher.core.framework.cache.SpringCacheManager;
import com.nec.biomatcher.core.framework.common.HostnameUtil;
import com.nec.biomatcher.core.framework.springSupport.SpringServiceManager;

public class ClearRemoteCacheUtil {
	private static final Logger logger = Logger.getLogger(ClearRemoteCacheUtil.class);
	
	   public static void clearRemoteCache() {
	        try {
	            //Clear local cache
	            SpringCacheManager cacheManager = (SpringCacheManager) SpringServiceManager.getBean("methodCacheManager");
	            cacheManager.removeAll();
	            
	            //Clear cache on all cluster members
	            HazelcastAdminCluster hazelcastAdminCluster = SpringServiceManager.getBean("hazelcastAdminCluster");
	            hazelcastAdminCluster.notifyClusterEvent(new ClusterEvent(HostnameUtil.getHostname(), "CLEAR_CACHE", null));
	            
	        } catch (Throwable th) {
	            logger.error("Error in clearRemoteCache: " + th.getMessage(), th);
	        }
	    }
}
