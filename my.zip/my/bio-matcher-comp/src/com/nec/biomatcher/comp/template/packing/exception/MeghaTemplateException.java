package com.nec.biomatcher.comp.template.packing.exception;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

public class MeghaTemplateException extends CoreException {
	private static final long serialVersionUID = 1L;

	public MeghaTemplateException(String message) {
		super(message);
	}

	public MeghaTemplateException(String message, Throwable cause) {
		super(message, cause);
	}

	public MeghaTemplateException(Throwable cause) {
		super(cause);
	}

}
