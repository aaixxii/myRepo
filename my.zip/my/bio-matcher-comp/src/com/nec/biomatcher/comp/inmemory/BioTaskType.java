package com.nec.biomatcher.comp.inmemory;

public enum BioTaskType {
	EXTRACT, VERIFY, SEARCH, ENROLL, STRICT_SYNC;
}
