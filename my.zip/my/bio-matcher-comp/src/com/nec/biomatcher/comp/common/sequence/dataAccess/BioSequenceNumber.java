package com.nec.biomatcher.comp.common.sequence.dataAccess;

import java.util.Date;

import com.nec.biomatcher.core.framework.dataAccess.Dbo;

/**
 * The Class BioSequenceNumber.
 */
public class BioSequenceNumber implements Dbo {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The reset policy none. */
	public static int RESET_POLICY_NONE = 0;

	/** The reset policy hourly. */
	public static int RESET_POLICY_HOURLY = 1;

	/** The reset policy daily. */
	public static int RESET_POLICY_DAILY = 3;

	/** The reset policy yearly. */
	public static int RESET_POLICY_YEARLY = 9;

	/** The name. */
	private String name;

	/** The group. */
	private String group;

	/** The maximum. */
	private Long maximum;

	/** The minimum. */
	private Long minimum;

	/** The value. */
	private Long value;

	/** The reset policy. */
	private Integer resetPolicy;

	/** The create date time. */
	private Date createDateTime;

	/** The reset date time. */
	private Date resetDateTime;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public Long getMaximum() {
		return maximum;
	}

	public void setMaximum(Long maximum) {
		this.maximum = maximum;
	}

	public Long getMinimum() {
		return minimum;
	}

	public void setMinimum(Long minimum) {
		this.minimum = minimum;
	}

	public Long getValue() {
		return value;
	}

	public void setValue(Long value) {
		this.value = value;
	}

	public Integer getResetPolicy() {
		return resetPolicy;
	}

	public void setResetPolicy(Integer resetPolicy) {
		this.resetPolicy = resetPolicy;
	}

	public Date getCreateDateTime() {
		return createDateTime;
	}

	public void setCreateDateTime(Date createDateTime) {
		this.createDateTime = createDateTime;
	}

	public Date getResetDateTime() {
		return resetDateTime;
	}

	public void setResetDateTime(Date resetDateTime) {
		this.resetDateTime = resetDateTime;
	}

}
