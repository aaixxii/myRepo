package com.nec.biomatcher.comp.admin;

import java.util.Map;

import com.nec.biomatcher.comp.admin.exception.BioAdminServiceException;
import com.nec.biomatcher.comp.admin.model.BioUserInfo;
import com.nec.biomatcher.comp.admin.model.BioUserInfoList;
import com.nec.biomatcher.core.framework.cache.InvalidateMethodCache;
import com.nec.biomatcher.core.framework.cache.MethodCache;
import com.nec.biomatcher.core.framework.web.session.UserSession;

public interface BioAdminService {

	@MethodCache
	public UserSession login(String userId, String password) throws BioAdminServiceException;

	@InvalidateMethodCache
	public void saveUser(BioUserInfo bioUserInfo) throws BioAdminServiceException;

	@InvalidateMethodCache
	public void deleteUser(String userId) throws BioAdminServiceException;

	@MethodCache
	public BioUserInfo getUser(String userId) throws BioAdminServiceException;

	@MethodCache
	public BioUserInfoList getUserInfoList() throws BioAdminServiceException;

	@MethodCache
	public Map<String, String> getDisplayLabelMap(String displayLabelGroup) throws BioAdminServiceException;

}
