package com.nec.biomatcher.comp.template.storage.dataAccess;

import java.util.Date;

import com.nec.biomatcher.core.framework.dataAccess.Dbo;

/**
 * The Class BioTemplateStorageInfo.
 */
public class BioTemplateStorageInfo implements Dbo {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The storage id. */
	private Integer storageId;

	/** The active. */
	private Boolean activeFalg;

	/** The root path. */
	private String rootPath;

	/** The create date time. */
	private Date createDateTime;

	/** The update date time. */
	private Date updateDateTime;

	public Integer getStorageId() {
		return storageId;
	}

	public void setStorageId(Integer storageId) {
		this.storageId = storageId;
	}

	public String getRootPath() {
		return rootPath;
	}

	public void setRootPath(String rootPath) {
		this.rootPath = rootPath;
	}

	public Boolean getActiveFalg() {
		return activeFalg;
	}

	public void setActiveFalg(Boolean activeFalg) {
		this.activeFalg = activeFalg;
	}

	public Date getUpdateDateTime() {
		return updateDateTime;
	}

	public void setUpdateDateTime(Date updateDateTime) {
		this.updateDateTime = updateDateTime;
	}

	public Date getCreateDateTime() {
		return createDateTime;
	}

	public void setCreateDateTime(Date createDateTime) {
		this.createDateTime = createDateTime;
	}

}
