package com.nec.biomatcher.comp.template.packing.model;

import java.io.PrintStream;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;

import com.google.common.primitives.Bytes;
import com.google.common.primitives.UnsignedBytes;
import com.google.common.primitives.UnsignedLong;
import com.nec.biomatcher.comp.template.packing.exception.MeghaTemplateException;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateUtil;
import com.nec.biomatcher.comp.template.packing.util.OffsetInfo;

public class MeghaTemplateHeader {
	public static final int SANITY_BYTE_POSITION = 0;

	public static final int EXTERNAL_ID_MAX_SIZE = 36;
	public static final int REGION_FLAGS_MAX_SIZE = 8;

	public static final int TEMPLATE_HEADER_SIZE_WITHOUT_USERFLAG = 72;

	private byte sanity;
	private byte templateTypeCode;
	private byte controlFlag;
	private byte maxEventCount;
	private long biometricId;
	private String externalId;
	private long eventHoldFlag;
	private byte gender;
	private short yob;
	private byte race;
	private byte[] userFlags;
	private byte[] regionFlags;
	private byte[] templatePaddingField = new byte[4];

	private final int userFlagByteCount;

	public MeghaTemplateHeader(int userFlagByteCount) {
		this.userFlagByteCount = userFlagByteCount;
	}

	public final int getTemplateHeaderSize() {
		return TEMPLATE_HEADER_SIZE_WITHOUT_USERFLAG + userFlagByteCount;
	}

	public void print(PrintStream printStream) {
		printStream.printf("%-20s - %s\n", "sanity", sanity);
		printStream.printf("%-20s - %s\n", "templateTypeCode", templateTypeCode);
		printStream.printf("%-20s - %s\n", "maxEventCount", maxEventCount);
		printStream.printf("%-20s - %s\n", "biometricId", biometricId);
		printStream.printf("%-20s - %s\n", "externalId", externalId);
		printStream.printf("%-20s - %s\n", "eventHoldFlag",
				StringUtils.leftPad(UnsignedLong.valueOf(eventHoldFlag).toString(2), Long.SIZE, "0"));
		printStream.printf("%-20s - %s\n", "gender", (char) gender);
		printStream.printf("%-20s - %s\n", "yob", yob);
		printStream.printf("%-20s - %s\n", "userFlags",
				Bytes.asList(userFlags == null ? new byte[userFlagByteCount] : userFlags).stream()
						.map(i -> StringUtils.leftPad(UnsignedBytes.toString((byte) i, 2), 8, "0"))
						.collect(Collectors.joining(", ")));
		printStream.printf("%-20s - %s\n", "regionFlags", Arrays.toString(regionFlags));
	}

	public byte[] pack() throws MeghaTemplateException {
		byte[] templateHeader = new byte[MeghaTemplateHeader.TEMPLATE_HEADER_SIZE_WITHOUT_USERFLAG + userFlagByteCount];
		ByteBuffer templateData = ByteBuffer.wrap(templateHeader).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		templateData.position(0);
		templateData.put(sanity);
		templateData.put(templateTypeCode);
		templateData.put(controlFlag);
		templateData.put(maxEventCount);
		templateData.putLong(biometricId);

		MeghaTemplateUtil.setStringData(externalId, EXTERNAL_ID_MAX_SIZE, templateData);

		templateData.putLong(eventHoldFlag);

		templateData.put(gender);
		templateData.putShort(yob);
		templateData.put(race);
		MeghaTemplateUtil.setByteData(userFlags, userFlagByteCount, templateData);
		MeghaTemplateUtil.setByteData(regionFlags, REGION_FLAGS_MAX_SIZE, templateData);

		templateData.put(templatePaddingField);

		return templateHeader;
	}

	public void unpack(ByteBuffer templateData) throws MeghaTemplateException {
		sanity = templateData.get();
		templateTypeCode = templateData.get();
		controlFlag = templateData.get();
		maxEventCount = templateData.get();
		biometricId = templateData.getLong();

		externalId = MeghaTemplateUtil.getStringData(EXTERNAL_ID_MAX_SIZE, templateData);
		eventHoldFlag = templateData.getLong();

		gender = templateData.get();
		yob = templateData.getShort();
		race = templateData.get();

		userFlags = new byte[userFlagByteCount];
		templateData.get(userFlags);

		regionFlags = new byte[REGION_FLAGS_MAX_SIZE];
		templateData.get(regionFlags);

		templateData.get(templatePaddingField);
	}

	public static final Map<String, OffsetInfo> getTemplateHeaderFieldOffsetInfoMap(int userFlagByteCount) {
		Map<String, OffsetInfo> templateFieldOffsetInfoMap = new HashMap<>();

		byte[] templateHeader = new byte[MeghaTemplateHeader.TEMPLATE_HEADER_SIZE_WITHOUT_USERFLAG + userFlagByteCount];
		ByteBuffer templateData = ByteBuffer.wrap(templateHeader).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);
		templateData.position(0);

		templateFieldOffsetInfoMap.put("sanity", new OffsetInfo(templateData.position(), 1));
		templateData.get();

		templateFieldOffsetInfoMap.put("templateTypeCode", new OffsetInfo(templateData.position(), 1));
		templateData.get();

		templateFieldOffsetInfoMap.put("controlFlag", new OffsetInfo(templateData.position(), 1));
		templateData.get();

		templateFieldOffsetInfoMap.put("maxEventCount", new OffsetInfo(templateData.position(), 1));
		templateData.get();

		templateFieldOffsetInfoMap.put("biometricId", new OffsetInfo(templateData.position(), 8));
		templateData.getLong();

		templateFieldOffsetInfoMap.put("externalId", new OffsetInfo(templateData.position(), EXTERNAL_ID_MAX_SIZE));
		templateData.get(new byte[EXTERNAL_ID_MAX_SIZE]);

		templateFieldOffsetInfoMap.put("eventHoldFlag", new OffsetInfo(templateData.position(), 8));
		templateData.getLong();

		templateFieldOffsetInfoMap.put("gender", new OffsetInfo(templateData.position(), 1));
		templateData.get();

		templateFieldOffsetInfoMap.put("yob", new OffsetInfo(templateData.position(), 2));
		templateData.getShort();

		templateFieldOffsetInfoMap.put("race", new OffsetInfo(templateData.position(), 1));
		templateData.get();

		templateFieldOffsetInfoMap.put("userFlags", new OffsetInfo(templateData.position(), userFlagByteCount));
		templateData.get(new byte[userFlagByteCount]);

		templateFieldOffsetInfoMap.put("regionFlags", new OffsetInfo(templateData.position(), REGION_FLAGS_MAX_SIZE));
		templateData.get(new byte[REGION_FLAGS_MAX_SIZE]);

		return templateFieldOffsetInfoMap;
	}

	public byte getSanity() {
		return sanity;
	}

	public void setSanity(byte sanity) {
		this.sanity = sanity;
	}

	public byte getTemplateTypeCode() {
		return templateTypeCode;
	}

	public void setTemplateTypeCode(byte templateTypeCode) {
		this.templateTypeCode = templateTypeCode;
	}

	public byte getControlFlag() {
		return controlFlag;
	}

	public void setControlFlag(byte controlFlag) {
		this.controlFlag = controlFlag;
	}

	public byte getMaxEventCount() {
		return maxEventCount;
	}

	public void setMaxEventCount(byte maxEventCount) {
		this.maxEventCount = maxEventCount;
	}

	public long getBiometricId() {
		return biometricId;
	}

	public void setBiometricId(long biometricId) {
		this.biometricId = biometricId;
	}

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public long getEventHoldFlag() {
		return eventHoldFlag;
	}

	public void setEventHoldFlag(long eventHoldFlag) {
		this.eventHoldFlag = eventHoldFlag;
	}

	public byte getGender() {
		return gender;
	}

	public void setGender(byte gender) {
		this.gender = gender;
	}

	public short getYob() {
		return yob;
	}

	public void setYob(short yob) {
		this.yob = yob;
	}

	public byte getRace() {
		return race;
	}

	public void setRace(byte race) {
		this.race = race;
	}

	public byte[] getUserFlags() {
		return userFlags;
	}

	public void setUserFlags(byte[] userFlags) {
		this.userFlags = userFlags;
	}

	public byte[] getRegionFlags() {
		return regionFlags;
	}

	public void setRegionFlags(byte[] regionFlags) {
		this.regionFlags = regionFlags;
	}
}
