package com.nec.biomatcher.comp.common.sequence.dataAccess;

import com.nec.biomatcher.core.framework.common.pagination.PageRequest;
import com.nec.biomatcher.core.framework.common.pagination.PageResult;
import com.nec.biomatcher.core.framework.dataAccess.DaoException;

/**
 * The Interface BioSequenceGeneratorDao.
 */
public interface BioSequenceGeneratorDao {

	/**
	 * Creates the.
	 *
	 * @param sequenceNumber
	 *            the sequence number
	 * @throws DaoException
	 *             the dao exception
	 */
	public void create(BioSequenceNumber sequenceNumber) throws DaoException;

	/**
	 * Delete.
	 *
	 * @param sequenceNumber
	 *            the sequence number
	 * @throws DaoException
	 *             the dao exception
	 */
	public void delete(BioSequenceNumber sequenceNumber) throws DaoException;

	/**
	 * Gets the seqence number.
	 *
	 * @param name
	 *            the name
	 * @param group
	 *            the group
	 * @return the seqence number
	 * @throws DaoException
	 *             the dao exception
	 */
	public BioSequenceNumber getSeqenceNumber(String name, String group) throws DaoException;

	/**
	 * Gets the seqence number for update.
	 *
	 * @param name
	 *            the name
	 * @param group
	 *            the group
	 * @return the seqence number for update
	 * @throws DaoException
	 *             the dao exception
	 */
	public BioSequenceNumber getSeqenceNumberForUpdate(String name, String group) throws DaoException;

	/**
	 * Update.
	 *
	 * @param sequenceNumber
	 *            the sequence number
	 * @throws DaoException
	 *             the dao exception
	 */
	public void update(BioSequenceNumber sequenceNumber) throws DaoException;

	/**
	 * Gets the all seqences.
	 *
	 * @param pageRequest
	 *            the page request
	 * @return the all seqences
	 * @throws DaoException
	 *             the dao exception
	 */
	public PageResult<BioSequenceNumber> getAllSeqences(PageRequest pageRequest) throws DaoException;

}
