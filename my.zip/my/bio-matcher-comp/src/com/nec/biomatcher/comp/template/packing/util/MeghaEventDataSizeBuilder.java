package com.nec.biomatcher.comp.template.packing.util;

import com.nec.biomatcher.comp.template.packing.exception.MeghaTemplateException;
import com.nec.biomatcher.comp.template.packing.model.MeghaEventHeader;

public class MeghaEventDataSizeBuilder {
	private int eventDataSize;
	private final MeghaTemplateConfig meghaTemplateConfig;

	public MeghaEventDataSizeBuilder(MeghaTemplateConfig meghaTemplateConfig) {
		this.meghaTemplateConfig = meghaTemplateConfig;
		eventDataSize = MeghaEventHeader.EVENT_HEADER_SIZE;
	}

	public MeghaEventDataSizeBuilder pad(int bytes) {
		eventDataSize += bytes;
		return this;
	}

	public MeghaEventDataSizeBuilder featureHoldFlag(int bytes) {
		eventDataSize += bytes;
		return this;
	}

	public MeghaEventDataSizeBuilder quality(int bytes) {
		eventDataSize += bytes;
		return this;
	}

	public MeghaEventDataSizeBuilder bytes(int bytes) {
		eventDataSize += bytes;
		return this;
	}

	public MeghaEventDataSizeBuilder featureDataLength(int bytes) throws MeghaTemplateException {
		eventDataSize += bytes;
		return this;
	}

	public MeghaEventDataSizeBuilder featureData(int count, String featureTypeKey) throws MeghaTemplateException {
		eventDataSize += (count * meghaTemplateConfig.getFeatureSize(featureTypeKey));
		return this;
	}

	public int build() {
		return eventDataSize;
	}
}
