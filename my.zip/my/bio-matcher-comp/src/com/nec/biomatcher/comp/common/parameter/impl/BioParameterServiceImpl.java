package com.nec.biomatcher.comp.common.parameter.impl;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Supplier;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.google.common.primitives.Doubles;
import com.google.common.primitives.Floats;
import com.google.common.primitives.Ints;
import com.google.common.primitives.Longs;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.common.parameter.dataAccess.BioParameter;
import com.nec.biomatcher.comp.common.parameter.dataAccess.BioParameterDao;
import com.nec.biomatcher.comp.common.parameter.dataAccess.BioParameterScope;
import com.nec.biomatcher.comp.common.parameter.exception.BioParameterServiceException;
import com.nec.biomatcher.core.framework.common.CheckedFunction;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.pagination.PageRequest;
import com.nec.biomatcher.core.framework.common.pagination.PageResult;
import com.nec.biomatcher.core.framework.springSupport.SpringSelfAssignmentMarker;

/**
 * The Class BioParameterServiceImpl.
 */
public class BioParameterServiceImpl implements BioParameterService, SpringSelfAssignmentMarker {

	/** The logger. */
	private static Logger logger = Logger.getLogger(BioParameterServiceImpl.class);

	/** The bio parameter dao. */
	private BioParameterDao bioParameterDao;

	/** The _this. */
	private static BioParameterService _this;
	private static boolean isSelfAssigned;

	public BioParameterServiceImpl() {
		_this = this;
	}

	public BioParameter getParameter(String parameterName, String scope) throws BioParameterServiceException {
		try {
			if (StringUtils.isBlank(scope)) {
				scope = "SYSTEM";
			}

			BioParameter bioParameter = bioParameterDao.getEntityByFields(BioParameter.class, "name", parameterName,
					"scope", scope);
			return bioParameter;
		} catch (Throwable th) {
			throw new BioParameterServiceException("Error in getParameter: " + th.getMessage(), th);
		}
	}

	public void saveParameter(BioParameter bioParameter) throws BioParameterServiceException {
		try {
			if (StringUtils.isBlank(bioParameter.getScope())) {
				bioParameter.setScope("SYSTEM");
			}
			bioParameterDao.saveOrUpdateEntity(bioParameter);
		} catch (Throwable th) {
			throw new BioParameterServiceException("Error in saveParameter: " + th.getMessage(), th);
		}
	}

	@Override
	public void saveParameterValue(String parameterName, String scope, String parameterValue)
			throws BioParameterServiceException {
		saveParameterValue(parameterName, scope, null, null, parameterValue);
	}

	@Override
	public void saveParameterValue(String parameterName, String scope, String dataType, String description,
			String parameterValue) throws BioParameterServiceException {
		try {
			if (StringUtils.isBlank(scope)) {
				scope = "SYSTEM";
			}

			if (StringUtils.isBlank(dataType)) {
				dataType = "STRING";
			}

			BioParameter bioParameter = bioParameterDao.getEntityByFields(BioParameter.class, "name", parameterName,
					"scope", scope);
			if (bioParameter == null) {
				BioParameterScope bioParameterScope = bioParameterDao.getEntity(BioParameterScope.class, scope);
				if (bioParameterScope == null) {
					bioParameterScope = new BioParameterScope();
					bioParameterScope.setScopeName(scope);
					bioParameterScope.setDescription(scope);
					bioParameterDao.saveOrUpdateEntity(bioParameterScope);
					bioParameterDao.flush();
				}

				bioParameter = new BioParameter();
				bioParameter.setCreateDateTime(new Date());
				bioParameter.setName(parameterName);
				bioParameter.setScope(scope);
				bioParameter.setDataType(dataType);
				bioParameter.setDescription(description);
				bioParameter.setValue(parameterValue);
				bioParameter.setCreatedBy("ADMIN");
				bioParameter.setCreateDateTime(new Date());
				bioParameterDao.saveOrUpdateEntity(bioParameter);
				bioParameterDao.flush();
			} else {
				if (StringUtils.isBlank(bioParameter.getDescription())) {
					bioParameter.setDescription(description);
				}
				bioParameter.setUpdateDateTime(new Date());
				bioParameter.setDataType(dataType);
				bioParameter.setValue(parameterValue);
				bioParameterDao.updateEntity(bioParameter);
				bioParameterDao.flush();
			}
		} catch (Throwable th) {
			throw new BioParameterServiceException("Error in saveParameter: " + th.getMessage(), th);
		}
	}

	public void saveParameterValueIfNotExists(String parameterName, String scope, String dataType, String description,
			String parameterValue) throws BioParameterServiceException {
		try {
			if (StringUtils.isBlank(scope)) {
				scope = "SYSTEM";
			}

			BioParameter bioParameter = _this.getParameter(parameterName, scope);
			if (bioParameter == null) {
				_this.saveParameterValue(parameterName, scope, dataType, description, parameterValue);
			}
		} catch (Throwable th) {
			throw new BioParameterServiceException("Error in saveParameterValueIfNotExists: " + th.getMessage(), th);
		}

	}

	public void compareAndSetParameterValue(String parameterName, String scope, String oldParameterValue,
			String newParameterValue) throws BioParameterServiceException {
		try {
			if (StringUtils.isBlank(scope)) {
				scope = "SYSTEM";
			}
			String currentParameterValue = _this.getParameterValue(parameterName, scope);
			if (StringUtils.equals(currentParameterValue, oldParameterValue)) {
				_this.saveParameterValue(parameterName, scope, newParameterValue);
			}
		} catch (Throwable th) {
			throw new BioParameterServiceException("Error in compareAndSetParameterValue: " + th.getMessage(), th);
		}
	}

	public void renameParameterIfExists(String fromParameterName, String scope, String toParameterName)
			throws BioParameterServiceException {
		try {
			if (StringUtils.equals(fromParameterName, toParameterName)) {
				return;
			}

			if (StringUtils.isBlank(scope)) {
				scope = "SYSTEM";
			}

			BioParameter bioParameter = bioParameterDao.getEntityByFields(BioParameter.class, "name", fromParameterName,
					"scope", scope);
			if (bioParameter != null) {
				bioParameterDao.deleteEntity(bioParameter);
				saveParameterValueIfNotExists(toParameterName, bioParameter.getScope(), bioParameter.getDataType(),
						bioParameter.getDescription(), bioParameter.getValue());
				CommonLogger.CONFIG_LOG.info("After renameParameterIfExists: fromParameterName: " + fromParameterName
						+ ", scope: " + scope + ", toParameterName: " + toParameterName);
			}
		} catch (Throwable th) {
			throw new BioParameterServiceException("Error in saveParameter: " + th.getMessage(), th);
		}
	}

	public void updateParameterDataTypeDescription(String parameterName, String scope, String dataType,
			String description) throws BioParameterServiceException {
		try {
			if (StringUtils.isBlank(scope)) {
				scope = "SYSTEM";
			}

			BioParameter bioParameter = _this.getParameter(parameterName, scope);
			if (bioParameter != null) {
				boolean updateFlag = false;
				if (dataType != null && StringUtils.isBlank(bioParameter.getDataType())) {
					bioParameter.setDataType(dataType);
					updateFlag = true;
				}
				if (description != null && StringUtils.isBlank(bioParameter.getDescription())) {
					bioParameter.setDescription(description);
					updateFlag = true;
				}
				if (updateFlag) {
					bioParameterDao.updateEntity(bioParameter);
				}
			}
		} catch (Throwable th) {
			throw new BioParameterServiceException("Error in saveParameterValueIfNotExists: " + th.getMessage(), th);
		}
	}

	/**
	 * Creates the parameter scope.
	 *
	 * @param scope
	 *            the scope
	 * @param description
	 *            the description
	 * @throws BioParameterServiceException
	 *             the bio parameter service exception
	 */
	public void createParameterScope(String scope, String description) throws BioParameterServiceException {
		try {
			BioParameterScope bioParameterScope = bioParameterDao.getEntity(BioParameterScope.class, scope);
			if (bioParameterScope != null) {
				return;
			}

			bioParameterScope = new BioParameterScope();
			bioParameterScope.setScopeName(scope);
			bioParameterScope.setDescription(description);
			bioParameterDao.saveOrUpdateEntity(bioParameterScope);
		} catch (Throwable th) {
			throw new BioParameterServiceException("Error in createParameterScope: " + th.getMessage(), th);
		}
	}

	@Override
	public String getParameterValue(String parameterName, String scope) throws BioParameterServiceException {
		try {
			BioParameter bioParameter = _this.getParameter(parameterName, scope);
			return bioParameter != null ? bioParameter.getValue() : null;
		} catch (Throwable th) {
			throw new BioParameterServiceException("Error in getParameterValue: " + th.getMessage(), th);
		}
	}

	@Override
	public String getParameterValue(String parameterName, String scope, String defaultValue) {
		try {
			BioParameter bioParameter = _this.getParameter(parameterName, scope);
			if (bioParameter != null) {
				return bioParameter.getValue();
			} else /* if (StringUtils.isNotBlank(defaultValue)) */ {
				saveParameterValue(parameterName, scope, defaultValue);
			}
		} catch (Throwable th) {
			logger.warn(
					"System parameter '" + parameterName
							+ "' does not exists or cannot be loaded. Default value will be used : " + th.getMessage(),
					th);
			return defaultValue;
		}
		return defaultValue;
	}

	public boolean getParameterValue(String parameterName, String scope, boolean defaultValue) {
		try {
			BioParameter bioParameter = _this.getParameter(parameterName, scope);
			if (bioParameter != null && StringUtils.isNotBlank(bioParameter.getValue())) {
				return new Boolean(bioParameter.getValue());
			} else {
				saveParameterValue(parameterName, scope, String.valueOf(defaultValue));
			}
		} catch (Throwable th) {
			logger.warn(
					"System parameter '" + parameterName
							+ "' does not exists or cannot be loaded. Default value will be used : " + th.getMessage(),
					th);
			return defaultValue;
		}
		return defaultValue;
	}

	@Override
	public int getParameterValue(String parameterName, String scope, int defaultValue) {
		try {
			BioParameter bioParameter = _this.getParameter(parameterName, scope);
			if (bioParameter != null && StringUtils.isNotBlank(bioParameter.getValue())) {
				Integer parameterValue = Ints.tryParse(StringUtils.trim(bioParameter.getValue()));
				return parameterValue != null ? parameterValue : defaultValue;
			} else {
				saveParameterValue(parameterName, scope, String.valueOf(defaultValue));
			}
		} catch (Throwable th) {
			logger.warn(
					"System parameter '" + parameterName
							+ "' does not exists or cannot be loaded. Default value will be used : " + th.getMessage(),
					th);
			return defaultValue;
		}
		return defaultValue;
	}

	@Override
	public long getParameterValue(String parameterName, String scope, long defaultValue) {
		try {
			BioParameter bioParameter = _this.getParameter(parameterName, scope);
			if (bioParameter != null && StringUtils.isNotBlank(bioParameter.getValue())) {
				Long parameterValue = Longs.tryParse(StringUtils.trim(bioParameter.getValue()));
				return parameterValue != null ? parameterValue : defaultValue;
			} else {
				saveParameterValue(parameterName, scope, String.valueOf(defaultValue));
			}
		} catch (Throwable th) {
			logger.warn(
					"System parameter '" + parameterName
							+ "' does not exists or cannot be loaded. Default value will be used : " + th.getMessage(),
					th);
			return defaultValue;
		}
		return defaultValue;
	}

	@Override
	public double getParameterValue(String parameterName, String scope, double defaultValue) {
		try {
			BioParameter bioParameter = _this.getParameter(parameterName, scope);
			if (bioParameter != null && StringUtils.isNotBlank(bioParameter.getValue())) {
				Double parameterValue = Doubles.tryParse(StringUtils.trim(bioParameter.getValue()));
				return parameterValue != null ? parameterValue : defaultValue;
			} else {
				saveParameterValue(parameterName, scope, String.valueOf(defaultValue));
			}
		} catch (Throwable th) {
			logger.warn(
					"System parameter '" + parameterName
							+ "' does not exists or cannot be loaded. Default value will be used : " + th.getMessage(),
					th);
			return defaultValue;
		}
		return defaultValue;
	}

	@Override
	public float getParameterValue(String parameterName, String scope, float defaultValue) {
		try {
			BioParameter bioParameter = _this.getParameter(parameterName, scope);
			if (bioParameter != null && StringUtils.isNotBlank(bioParameter.getValue())) {
				Float parameterValue = Floats.tryParse(StringUtils.trim(bioParameter.getValue()));
				return parameterValue != null ? parameterValue : defaultValue;
			} else {
				saveParameterValue(parameterName, scope, String.valueOf(defaultValue));
			}
		} catch (Throwable th) {
			logger.warn(
					"System parameter '" + parameterName
							+ "' does not exists or cannot be loaded. Default value will be used : " + th.getMessage(),
					th);
			return defaultValue;
		}
		return defaultValue;
	}

	@Override
	public void saveVariableValue(String parameterName, String scope, String parameterValue)
			throws BioParameterServiceException {
		saveParameterValue(parameterName, scope, parameterValue);
	}

	@Override
	public String getVariableValue(String parameterName, String scope) throws BioParameterServiceException {
		try {
			BioParameter bioParameter = bioParameterDao.getEntityByFields(BioParameter.class, "name", parameterName,
					"scope", scope);
			return bioParameter != null ? bioParameter.getValue() : null;
		} catch (Throwable th) {
			throw new BioParameterServiceException("Error in getVariableValue: " + th.getMessage(), th);
		}
	}

	@Override
	public PageResult<BioParameter> getParameterList(PageRequest pageRequest) throws BioParameterServiceException {
		try {
			return bioParameterDao.getAllParameters(pageRequest);
		} catch (Throwable th) {
			throw new BioParameterServiceException("Error in getParameterList: " + th.getMessage(), th);
		}
	}

	public List<BioParameter> getParameterList(boolean includeVariableScope) throws BioParameterServiceException {
		try {
			return bioParameterDao.getAllParameters(includeVariableScope);
		} catch (Throwable th) {
			throw new BioParameterServiceException("Error in getParameterList: " + th.getMessage(), th);
		}
	}

	public List<BioParameterScope> getParameterScopeList() throws BioParameterServiceException {
		try {
			return bioParameterDao.getAllParameterScopes();
		} catch (Throwable th) {
			throw new BioParameterServiceException("Error in getParameterScopeList: " + th.getMessage(), th);
		}
	}

	public void deleteParameter(String parameterName, String scope) throws BioParameterServiceException {
		try {
			if (StringUtils.isBlank(scope)) {
				scope = "SYSTEM";
			}

			BioParameter bioParameter = bioParameterDao.getEntityByFields(BioParameter.class, "name", parameterName,
					"scope", scope);
			if (bioParameter != null) {
				bioParameterDao.deleteEntity(bioParameter);
			}
		} catch (Throwable th) {
			throw new BioParameterServiceException("Error in deleteParameter: " + th.getMessage(), th);
		}
	}

	public void deleteParameterLike(String parameterName, String scope) throws BioParameterServiceException {
		try {
			if (StringUtils.isBlank(scope)) {
				scope = "SYSTEM";
			}

			List<BioParameter> bioParameterList = bioParameterDao.getParametersLike(parameterName, scope);
			if (!bioParameterList.isEmpty()) {
				bioParameterDao.deleteEntities(bioParameterList);
			}
		} catch (Throwable th) {
			throw new BioParameterServiceException("Error in deleteParameter: " + th.getMessage(), th);
		}
	}

	public <R> R getParameterValue(String parameterName, String scope, Function<String, R> convertorFunction)
			throws BioParameterServiceException {
		try {
			String parameterValue = _this.getParameterValue(parameterName, scope);
			return convertorFunction.apply(parameterValue);
		} catch (Throwable th) {
			throw new BioParameterServiceException("Error in getParameterValue: " + th.getMessage(), th);
		}
	}

	public <R> R getParameterValue(String parameterName, String scope, Function<String, R> convertorFunction,
			String defaultValue) throws BioParameterServiceException {
		try {
			String parameterValue = _this.getParameterValue(parameterName, scope, defaultValue);
			return convertorFunction.apply(parameterValue);
		} catch (Throwable th) {
			throw new BioParameterServiceException("Error in getParameterValue: " + th.getMessage(), th);
		}
	}

	public <R> R getParameterValue(String parameterName, String scope, CheckedFunction<String, R> convertorFunction)
			throws BioParameterServiceException {
		try {
			String parameterValue = _this.getParameterValue(parameterName, scope);
			return convertorFunction.apply(parameterValue);
		} catch (Throwable th) {
			throw new BioParameterServiceException("Error in getParameterValue: " + th.getMessage(), th);
		}
	}

	public <R> R getParameterValue(String parameterName, String scope, CheckedFunction<String, R> convertorFunction,
			String defaultValue) throws BioParameterServiceException {
		try {
			String parameterValue = _this.getParameterValue(parameterName, scope, defaultValue);
			return convertorFunction.apply(parameterValue);
		} catch (Throwable th) {
			throw new BioParameterServiceException("Error in getParameterValue: " + th.getMessage(), th);
		}
	}

	public <R> R getCachedResult(String cacheKey, Supplier<R> supplier) throws BioParameterServiceException {
		try {
			return supplier.get();
		} catch (Throwable th) {
			throw new BioParameterServiceException(
					"Error in getCachedResult for cacheKey: " + cacheKey + ": " + th.getMessage(), th);
		}
	}

	public Map<String, String> getPropertyMap(String parameterName, String scope) throws BioParameterServiceException {
		try {
			HashMap<String, String> propertyMap = new HashMap<String, String>();

			String propertyParameterValue = _this.getParameterValue(parameterName, scope, "");

			if (StringUtils.isNotBlank(propertyParameterValue)) {
				Properties properties = new Properties();
				properties.load(new StringReader(propertyParameterValue));

				for (Object key : properties.keySet()) {
					if (key != null) {
						String value = properties.getProperty(key.toString());
						propertyMap.put(key.toString(), value);
					}
				}
			}

			return propertyMap;
		} catch (Throwable th) {
			throw new BioParameterServiceException(
					"Error in getPropertyMap for parameterName: " + parameterName + " : " + th.getMessage(), th);
		}
	}

	public void mergePropertyMap(String parameterName, String scope, Map<String, String> defaultPropertyMap,
			Set<String> keysToBeRemoved, String comments) throws BioParameterServiceException {
		try {
			if (defaultPropertyMap == null || defaultPropertyMap.isEmpty()) {
				return;
			}

			boolean isModified = false;

			Map<String, String> propertyMap = getPropertyMap(parameterName, scope);

			Properties properties = new Properties();
			for (Entry<String, String> entry : propertyMap.entrySet()) {
				if (keysToBeRemoved != null && keysToBeRemoved.contains(entry.getKey())) {
					isModified = true;
					continue;
				}
				properties.setProperty(entry.getKey(), entry.getValue());
			}

			for (Entry<String, String> entry : defaultPropertyMap.entrySet()) {
				if (!propertyMap.containsKey(entry.getKey())) {
					properties.setProperty(entry.getKey(), entry.getValue());
					isModified = true;
				}
			}

			if (isModified) {
				StringWriter sw = new StringWriter();
				properties.store(sw, comments);

				String parameterValue = sw.toString();

				saveParameterValue(parameterName, scope, null, comments, parameterValue);
			}
		} catch (Throwable th) {
			throw new BioParameterServiceException("Error in mergePropertyMap for parameterName: " + parameterName
					+ ", scope: " + scope + " : " + th.getMessage(), th);
		}
	}

	public Set<String> mergeSet(String parameterName, String scope, String delimiter, String... values)
			throws BioParameterServiceException {
		try {
			if (StringUtils.isBlank(scope)) {
				scope = "SYSTEM";
			}

			Set<String> valuesSet = new HashSet<>();
			String parameterValue = _this.getParameterValue(parameterName, scope, "");
			String splitValues[] = StringUtils.split(parameterValue, delimiter);
			if (splitValues != null) {
				for (String splitValue : splitValues) {
					if (StringUtils.isNotBlank(splitValue)) {
						valuesSet.add(splitValue.trim());
					}
				}
			}

			boolean isModified = false;

			if (values != null) {
				for (String value : values) {
					if (StringUtils.isNotBlank(value)) {
						if (valuesSet.add(value.trim())) {
							isModified = true;
						}
					}
				}
			}

			if (isModified) {
				parameterValue = StringUtils.join(valuesSet, delimiter);

				saveParameterValue(parameterName, scope, parameterValue);
			}

			return Collections.unmodifiableSet(valuesSet);
		} catch (Throwable th) {
			throw new BioParameterServiceException("Error in mergeSet for parameterName: " + parameterName + ", scope: "
					+ scope + " : " + th.getMessage(), th);
		}
	}

	public Set<String> getParameterValueSet(String parameterName, String scope, String delimiter)
			throws BioParameterServiceException {
		try {
			if (StringUtils.isBlank(scope)) {
				scope = "SYSTEM";
			}

			Set<String> valuesSet = new HashSet<>();
			String parameterValue = _this.getParameterValue(parameterName, scope, "");
			String splitValues[] = StringUtils.split(parameterValue, delimiter);
			if (splitValues != null) {
				for (String splitValue : splitValues) {
					if (StringUtils.isNotBlank(splitValue)) {
						valuesSet.add(splitValue.trim());
					}
				}
			}

			return Collections.unmodifiableSet(valuesSet);
		} catch (Throwable th) {
			throw new BioParameterServiceException("Error in getParameterValueSet: " + th.getMessage(), th);
		}
	}

	public static BioParameterService getSelfAssignedRef() {
		if (isSelfAssigned) {
			return _this;
		}
		return null;
	}

	public void setBioParameterDao(BioParameterDao bioParameterDao) {
		this.bioParameterDao = bioParameterDao;
	}

	@Override
	public void assignSelf(Object self) throws Exception {
		logger.info("In BioParameterServiceImpl.assignSelf");
		_this = (BioParameterService) self;
		bioParameterServiceRef.set(_this);
		isSelfAssigned = true;
	}

}
