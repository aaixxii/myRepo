package com.nec.biomatcher.comp.util;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;

import com.google.common.util.concurrent.AtomicLongMap;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.metrics.MetricsUtil;
import com.nec.biomatcher.core.framework.common.concurrent.ConcurrentValuedHashMap;

public class ServerStatusMonitor {
	private static final Logger STATUS_LOGGER = Logger.getLogger("STATUS_LOG");

	private static final ConcurrentValuedHashMap<BioComponentType, Set<String>> onlineServerIdListMap = new ConcurrentValuedHashMap<>(
			serverId -> ConcurrentHashMap.newKeySet());
	private static final ConcurrentValuedHashMap<BioComponentType, Set<String>> offlineServerIdListMap = new ConcurrentValuedHashMap<>(
			serverId -> ConcurrentHashMap.newKeySet());
	private static final AtomicLongMap<String> statusVersionMap = AtomicLongMap.create();

	public static final long getStatusVersion(String serverId) {
		return statusVersionMap.get(serverId);
	}

	public static final boolean notifyOnline(BioComponentType bioComponentType, String serverId) {
		Set<String> onlineServerIdList = onlineServerIdListMap.getValue(bioComponentType);

		boolean addedFlag = onlineServerIdList.add(serverId);
		if (addedFlag) {
			statusVersionMap.incrementAndGet(serverId);

			boolean removedFlag = offlineServerIdListMap.getValue(bioComponentType).remove(serverId);

			MetricsUtil.incCounter(bioComponentType, serverId, "ONLINE_SERVER_STATUS");

			MetricsUtil.setCounterValue(bioComponentType, serverId, "OFFLINE_SERVER_STATUS", 0);

			STATUS_LOGGER.info("In ServerStatusMonitor.notifyOnline: bioComponentType: " + bioComponentType.name()
					+ ", serverId: " + serverId + " is online");
		}

		MetricsUtil.meter(bioComponentType, serverId, "NUMBER_OF_TIMES_ONLINE");

		return addedFlag;
	}

	public static final boolean notifyOffline(BioComponentType bioComponentType, String serverId) {
		Set<String> offlineServerIdList = offlineServerIdListMap.getValue(bioComponentType);

		boolean addedFlag = offlineServerIdList.add(serverId);
		if (addedFlag) {
			statusVersionMap.incrementAndGet(serverId);

			boolean removedFlag = onlineServerIdListMap.getValue(bioComponentType).remove(serverId);

			MetricsUtil.incCounter(bioComponentType, serverId, "OFFLINE_SERVER_STATUS");

			MetricsUtil.setCounterValue(bioComponentType, serverId, "ONLINE_SERVER_STATUS", 0);

			STATUS_LOGGER.info("In ServerStatusMonitor.notifyOffline: bioComponentType: " + bioComponentType.name()
					+ ", serverId: " + serverId + " is offline");
		}

		MetricsUtil.meter(bioComponentType, serverId, "NUMBER_OF_TIMES_OFFLINE");

		return addedFlag;

	}

	public static final boolean isMonitored(BioComponentType bioComponentType) {
		return onlineServerIdListMap.containsKey(bioComponentType)
				|| offlineServerIdListMap.containsKey(bioComponentType);
	}

	public static final boolean isOnline(BioComponentType bioComponentType, String serverId) {
		return onlineServerIdListMap.getValue(bioComponentType).contains(serverId);
	}

	public static final boolean isOffline(BioComponentType bioComponentType, String serverId) {
		return offlineServerIdListMap.getValue(bioComponentType).contains(serverId);
	}

	public static final Set<String> getOnlineServerIdList(BioComponentType bioComponentType) {
		return onlineServerIdListMap.getValue(bioComponentType);
	}

	public static final Set<String> getOfflineServerIdList(BioComponentType bioComponentType) {
		return offlineServerIdListMap.getValue(bioComponentType);
	}

}
