package com.nec.biomatcher.comp.metrics;

import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;

import com.codahale.metrics.JmxReporter;
import com.codahale.metrics.MetricFilter;
import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerInfo;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioConnectionType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioProtocolType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioServerType;
import com.nec.biomatcher.core.framework.common.HostnameUtil;

/**
 * The Class MetricsDataReporter.
 */
public class MetricsDataReporter implements InitializingBean {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(MetricsDataReporter.class);

	/** The bio parameter service. */
	private BioParameterService bioParameterService;

	/** The bio matcher config service. */
	private BioMatcherConfigService bioMatcherConfigService;

	/** The jmx reporter. */
	private JmxReporter jmxReporter;

	/** The influxdb reporter. */
	private MetricsInfluxdbReporter influxdbReporter;

	private MetricsFileStorageReporter fileStorageReporter;

	private MetricsFileStorage metricsFileStorage;

	/**
	 * Configure jmx reporter.
	 *
	 * @throws Exception
	 *             the exception
	 */
	public void configureJmxReporter() throws Exception {
		logger.info("In MetricsDataReporter.configureJmxReporter");
		if (jmxReporter != null) {
			return;
		}

		boolean enabledFlag = bioParameterService.getParameterValue("ENABLE_METRICS_JMX_REPORTER_FLAG", "DEFAULT",
				true);
		if (!enabledFlag) {
			logger.warn(
					"JmxReporter is not enabled, System parameter 'ENABLE_METRICS_JMX_REPORTER_FLAG' value is false");
			return;
		}

		final JmxReporter tempJmxReporter = JmxReporter.forRegistry(MetricsUtil.METRICS_REGISTRY)
				.convertRatesTo(TimeUnit.SECONDS).convertDurationsTo(TimeUnit.MILLISECONDS).filter(MetricFilter.ALL)
				.build();
		tempJmxReporter.start();

		jmxReporter = tempJmxReporter;

		logger.info("In MetricsDataReporter.configureJmxReporter: success");
	}

	/**
	 * Configure influxdb reporter.
	 *
	 * @throws Exception
	 *             the exception
	 */
	public synchronized void configureInfluxdbReporter() throws Exception {
		logger.info("In MetricsDataReporter.configureInfluxdbReporter");
		if (influxdbReporter != null) {
			return;
		}

		boolean enabledFlag = bioParameterService.getParameterValue("ENABLE_METRICS_INFLUX_DB_REPORTER_FLAG", "DEFAULT",
				false);
		if (!enabledFlag) {
			logger.warn(
					"Influx report database is not enabled, System parameter 'ENABLE_METRICS_INFLUX_DB_REPORTER_FLAG' value is false");
			return;
		}

		BioServerInfo serverInfo = bioMatcherConfigService.getServerInfoByServerType(BioServerType.REPORT_DB,
				BioComponentType.IF);
		if (serverInfo == null) {
			logger.warn("Influx report database is not configured");
			return;
		}

		bioMatcherConfigService.createServerConnnections(serverInfo.getServerId(), serverInfo.getServerHost(),
				serverInfo.getComponentType());

		String connectionUrl = bioMatcherConfigService.getServerConnectionUrl(serverInfo.getServerId(),
				BioComponentType.IF, BioConnectionType.SERVICE, BioProtocolType.HTTP);
		if (StringUtils.isBlank(connectionUrl)) {
			return;
		}

		int influxDbReporterDelayInterval = bioParameterService
				.getParameterValue("METRICS_INFLUX_DB_REPORTER_DELAY_SECONDS", "DEFAULT", 10);

		final MetricsInfluxdbReporter tempInfluxdbReporter = MetricsInfluxdbReporter
				.forRegistry(MetricsUtil.METRICS_REGISTRY).withConnectionUrl(connectionUrl)
				.convertRatesTo(TimeUnit.SECONDS).convertDurationsTo(TimeUnit.MILLISECONDS).filter(MetricFilter.ALL)
				.build();

		tempInfluxdbReporter.start(influxDbReporterDelayInterval, TimeUnit.SECONDS);

		influxdbReporter = tempInfluxdbReporter;
		logger.info("In MetricsDataReporter.configureInfluxdbReporter: success");
	}

	public void configureMetricsFileStorageReporter() throws Exception {
		if (fileStorageReporter != null) {
			return;
		}

		Supplier<Integer> schedulerDalaySeconds = BioParameterService
				.getIntSupplier("METRICS_FILE_STORAGE_REPORTER_DELAY_SECONDS", "DEFAULT", 20);

		final MetricsFileStorageReporter tempMetricsFileStorageReporter = MetricsFileStorageReporter
				.forRegistry(MetricsUtil.METRICS_REGISTRY).metricsFileStorage(metricsFileStorage)
				.serverHost(getCurrentServerHostName()).convertRatesTo(TimeUnit.MINUTES)
				.convertDurationsTo(TimeUnit.SECONDS).schedulerDalaySeconds(schedulerDalaySeconds)
				.filter(MetricFilter.ALL).build();

		tempMetricsFileStorageReporter.start(schedulerDalaySeconds.get(), TimeUnit.SECONDS);

		fileStorageReporter = tempMetricsFileStorageReporter;
	}

	private String getCurrentServerHostName() throws Exception {
		Set<String> serverHostSet = bioMatcherConfigService.getServerHostnameSet(BioServerType.MANAGER);

		for (String serverHostname : HostnameUtil.getHostnameIpAddressList()) {
			if (serverHostSet.contains(serverHostname)) {
				return serverHostname;
			}
		}
		return HostnameUtil.getHostname();
	}

	public void setBioParameterService(BioParameterService bioParameterService) {
		this.bioParameterService = bioParameterService;
	}

	public void setBioMatcherConfigService(BioMatcherConfigService bioMatcherConfigService) {
		this.bioMatcherConfigService = bioMatcherConfigService;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		logger.info("In MetricsDataReporter.afterPropertiesSet");

		configureJmxReporter();

		boolean enabledFlag = bioParameterService.getParameterValue("ENABLE_METRICS_INFLUX_DB_REPORTER_FLAG", "DEFAULT",
				false);
		if (enabledFlag) {
			configureInfluxdbReporter();
		} else {
			logger.warn(
					"Metrics Influx report database is not enabled, System parameter 'ENABLE_METRICS_INFLUX_DB_REPORTER_FLAG' value is false");
		}

		enabledFlag = bioParameterService.getParameterValue("ENABLE_METRICS_FILE_STORAGE_REPORTER_FLAG", "DEFAULT",
				false);
		if (enabledFlag) {
			configureMetricsFileStorageReporter();
		} else {
			logger.warn(
					"Metrics file storage is not enabled, System parameter 'ENABLE_METRICS_FILE_STORAGE_REPORTER_FLAG' value is false");
		}

		ServerHealth.registerFreeMemoryGauge(null, null);
		ServerHealth.registerSystemLoadGauge(null, null);
	}

	public void setMetricsFileStorage(MetricsFileStorage metricsFileStorage) {
		this.metricsFileStorage = metricsFileStorage;
	}

}
