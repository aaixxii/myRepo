package com.nec.biomatcher.comp.common;

import java.util.Arrays;

/**
 * The Class Constants.
 */
public class Constants {

	/** The Constant VARIABLE_LENGTH_DATA_FILL_BYTE. */
	public static final byte VARIABLE_LENGTH_DATA_FILL_BYTE = '~';

	/** The Constant ACTIVE_FLAG. */
	public static final byte ACTIVE_FLAG = 'A';

	/** The Constant DELETED_FLAG. */
	public static final byte DELETED_FLAG = 'D';

	/** The Constant SIZE_1KB. */
	public static final int SIZE_1KB = 1024;

	/** The Constant SIZE_50KB. */
	public static final int SIZE_50KB = 50 * SIZE_1KB;

	/** The Constant SIZE_1MB. */
	public static final int SIZE_1MB = 1024 * 1024;

	/** The Constant SIZE_5MB. */
	public static final int SIZE_5MB = 5 * SIZE_1MB;

	/** The Constant EXTERNAL_ID_LENGTH. */
	public static final int EXTERNAL_ID_LENGTH = 20;

	/** The Constant EXTERNAL_ID_FILLER_BYTES. */
	public static final byte[] EXTERNAL_ID_FILLER_BYTES = new byte[EXTERNAL_ID_LENGTH];

	/** The Constant EVENT_ID_LENGTH. */
	public static final int EVENT_ID_LENGTH = 20;

	/** The Constant EVENT_ID_FILLER_BYTES. */
	public static final byte[] EVENT_ID_FILLER_BYTES = new byte[EXTERNAL_ID_LENGTH];

	/** The Constant MAX_TEMPLATE_LENGTH. */
	public static final int MAX_TEMPLATE_LENGTH = 16 * SIZE_1KB;

	/** The Constant TEMPLATE_FILLER_BYTES. */
	public static final byte[] TEMPLATE_FILLER_BYTES = new byte[MAX_TEMPLATE_LENGTH];

	/** The Constant MAX_TEMPLATE_RECORD_SIZE. */
	public static final int MAX_TEMPLATE_RECORD_SIZE = 16 * SIZE_1KB;

	static {
		Arrays.fill(EXTERNAL_ID_FILLER_BYTES, VARIABLE_LENGTH_DATA_FILL_BYTE);
		Arrays.fill(EVENT_ID_FILLER_BYTES, VARIABLE_LENGTH_DATA_FILL_BYTE);
		Arrays.fill(TEMPLATE_FILLER_BYTES, VARIABLE_LENGTH_DATA_FILL_BYTE);
	}
}
