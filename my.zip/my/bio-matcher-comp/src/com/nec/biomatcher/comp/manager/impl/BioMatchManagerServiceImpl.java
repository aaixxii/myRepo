package com.nec.biomatcher.comp.manager.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;

import com.google.common.base.Throwables;
import com.nec.biomatcher.comp.common.locking.BioLockingService;
import com.nec.biomatcher.comp.config.BioMatcherConfigService;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherNodeSegmentInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioMatcherSegmentInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioRemoteSiteSyncInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BioServerInfo;
import com.nec.biomatcher.comp.entities.dataAccess.BiometricIdInfo;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioComponentType;
import com.nec.biomatcher.comp.entities.dataAccess.types.BioServerState;
import com.nec.biomatcher.comp.inmemory.InMemoryManager;
import com.nec.biomatcher.comp.manager.BioMatchManagerService;
import com.nec.biomatcher.comp.manager.dataAccess.BioMatchManagerDao;
import com.nec.biomatcher.comp.manager.exception.BioMatchManagerException;
import com.nec.biomatcher.core.framework.common.BiKey;
import com.nec.biomatcher.spec.transfer.event.BiometricEventStatus;

/**
 * The Class BioMatchManagerServiceImpl.
 */
public class BioMatchManagerServiceImpl implements BioMatchManagerService, InitializingBean {
	private static final Logger logger = Logger.getLogger(BioMatchManagerServiceImpl.class);

	/** The bio match manager dao. */
	private BioMatchManagerDao bioMatchManagerDao;

	/** The bio locking service. */
	private BioLockingService bioLockingService;

	private BioMatcherConfigService bioMatcherConfigService;

	public BioServerInfo getServerInfo(String serverId) throws BioMatchManagerException {
		try {
			return bioMatchManagerDao.getEntity(BioServerInfo.class, serverId);
		} catch (Throwable th) {
			throw new BioMatchManagerException("Error in getServerInfoList: " + th.getMessage(), th);
		}
	}

	public List<BioServerInfo> getServerInfoListByComponentType(BioComponentType componentType,
			BioServerState serverState) throws BioMatchManagerException {
		try {
			return bioMatchManagerDao.getEntityListByFields(BioServerInfo.class, "componentType", componentType,
					"serverState", serverState);
		} catch (Throwable th) {
			throw new BioMatchManagerException("Error in getServerInfoListByComponentType: " + th.getMessage(), th);
		}
	}

	public BioRemoteSiteSyncInfo getRemoteSiteSyncInfo(String siteId, Integer segmentId)
			throws BioMatchManagerException {
		try {
			BioRemoteSiteSyncInfo bioRemoteSiteSyncInfo = bioMatchManagerDao
					.getEntityByFields(BioRemoteSiteSyncInfo.class, "siteId", siteId, "segmentId", segmentId);
			if (bioRemoteSiteSyncInfo == null) {
				bioMatchManagerDao.getEntityForUpdate(BioMatcherSegmentInfo.class, segmentId);

				bioRemoteSiteSyncInfo = bioMatchManagerDao.getEntityByFields(BioRemoteSiteSyncInfo.class, "siteId",
						siteId, "segmentId", segmentId);
				if (bioRemoteSiteSyncInfo == null) {
					bioRemoteSiteSyncInfo = new BioRemoteSiteSyncInfo();
					bioRemoteSiteSyncInfo.setSiteId(siteId);
					bioRemoteSiteSyncInfo.setSegmentId(segmentId);
					bioRemoteSiteSyncInfo.setInsertSegmentVersion(-1L);
					bioRemoteSiteSyncInfo.setDeleteSegmentVersion(-1L);
					bioRemoteSiteSyncInfo.setUpdateDateTime(new Date());
					bioMatchManagerDao.saveOrUpdateEntity(bioRemoteSiteSyncInfo);
				}
			}

			return bioRemoteSiteSyncInfo;
		} catch (Throwable th) {
			throw new BioMatchManagerException("Error in getRemoteSiteSyncSegmentVersion for siteId: " + siteId
					+ ", segmentId: " + segmentId + " : " + th.getMessage(), th);
		}
	}

	public void updateRemoteSiteSyncSegmentVersion(String siteId, Integer segmentId, Long segmentVersion,
			BiometricEventStatus biometricEventStatus) throws BioMatchManagerException {
		try {
			BioRemoteSiteSyncInfo bioRemoteSiteSyncInfo = bioMatchManagerDao
					.getEntityByFields(BioRemoteSiteSyncInfo.class, "siteId", siteId, "segmentId", segmentId);
			if (bioRemoteSiteSyncInfo == null) {
				bioRemoteSiteSyncInfo = new BioRemoteSiteSyncInfo();
				bioRemoteSiteSyncInfo.setSiteId(siteId);
				bioRemoteSiteSyncInfo.setSegmentId(segmentId);
				bioRemoteSiteSyncInfo.setUpdateDateTime(new Date());
				if (BiometricEventStatus.ACTIVE.equals(biometricEventStatus)) {
					bioRemoteSiteSyncInfo.setInsertSegmentVersion(segmentVersion);
					bioRemoteSiteSyncInfo.setDeleteSegmentVersion(-1L);
				} else {
					bioRemoteSiteSyncInfo.setDeleteSegmentVersion(segmentVersion);
					bioRemoteSiteSyncInfo.setInsertSegmentVersion(-1L);
				}

				bioMatchManagerDao.saveOrUpdateEntity(bioRemoteSiteSyncInfo);
			} else {
				bioRemoteSiteSyncInfo.setUpdateDateTime(new Date());
				if (BiometricEventStatus.ACTIVE.equals(biometricEventStatus)) {
					bioRemoteSiteSyncInfo.setInsertSegmentVersion(segmentVersion);
				} else {
					bioRemoteSiteSyncInfo.setDeleteSegmentVersion(segmentVersion);
				}
				bioMatchManagerDao.updateEntity(bioRemoteSiteSyncInfo);
			}
		} catch (Throwable th) {
			throw new BioMatchManagerException("Error in updateRemoteSiteSyncSegmentVersion for siteId: " + siteId
					+ ", segmentId: " + segmentId + " : " + th.getMessage(), th);
		}
	}

	public void updateRemoteSiteSyncSegmentVersion(String siteId, Map<Integer, Long> segmentVersionMap,
			BiometricEventStatus biometricEventStatus) throws BioMatchManagerException {
		try {
			for (Integer segmentId : segmentVersionMap.keySet()) {
				updateRemoteSiteSyncSegmentVersion(siteId, segmentId, segmentVersionMap.get(segmentId),
						biometricEventStatus);
			}
		} catch (Throwable th) {
			throw new BioMatchManagerException(
					"Error in updateRemoteSiteSyncSegmentVersion for siteId: " + siteId + " : " + th.getMessage(), th);
		}
	}

	public int updateMatcherSegmentVersion(Integer segmentId, Long segmentVersion) throws BioMatchManagerException {
		try {
			return bioMatchManagerDao.updateMatcherSegmentVersion(segmentId, segmentVersion);
		} catch (Throwable th) {
			throw new BioMatchManagerException(
					"Error in updateMatcherSegmentVersion for segmentId: " + segmentId + " : " + th.getMessage(), th);
		}
	}

	public int updateMatcherNodeSegmentVersion(String matcherNodeId, Map<Integer, Long> segmentIdVersionMap)
			throws BioMatchManagerException {
		try {
			return bioMatchManagerDao.updateMatcherNodeSegmentVersion(matcherNodeId, segmentIdVersionMap);
		} catch (Throwable th) {
			throw new BioMatchManagerException("Error in updateMatcherNodeSegmentVersion for matcherNodeId: "
					+ matcherNodeId + " : " + th.getMessage(), th);
		}
	}

	public BioMatcherSegmentInfo getMatcherSegmentInfo(Integer segmentId) throws BioMatchManagerException {
		try {
			return bioMatchManagerDao.getEntity(BioMatcherSegmentInfo.class, segmentId);
		} catch (Throwable th) {
			throw new BioMatchManagerException(
					"Error in getMatcherSegmentInfo for segmentId: " + segmentId + " : " + th.getMessage(), th);
		}
	}

	public Long getMaxMatcherNodeSegmentVersion(Integer segmentId) throws BioMatchManagerException {
		try {
			return bioMatchManagerDao.getMaxMatcherNodeSegmentVersion(segmentId);
		} catch (Throwable th) {
			throw new BioMatchManagerException("Error in getMatcherNodeSegmentInfoList : " + th.getMessage(), th);
		}
	}

	public List<BioMatcherNodeSegmentInfo> getMatcherNodeSegmentInfoList() throws BioMatchManagerException {
		try {
			return bioMatchManagerDao.getAllEntity(BioMatcherNodeSegmentInfo.class);
		} catch (Throwable th) {
			throw new BioMatchManagerException("Error in getMatcherNodeSegmentInfoList : " + th.getMessage(), th);
		}
	}

	public List<BioMatcherNodeSegmentInfo> getMatcherNodeSegmentInfoList(String searchNodeId)
			throws BioMatchManagerException {
		try {
			return bioMatchManagerDao.getEntityListByField(BioMatcherNodeSegmentInfo.class, "matcherNodeId",
					searchNodeId);
		} catch (Throwable th) {
			throw new BioMatchManagerException("Error in getMatcherNodeSegmentInfoList for searchNodeId: "
					+ searchNodeId + " : " + th.getMessage(), th);
		}
	}

	public BioMatcherNodeSegmentInfo getMatcherNodeSegmentInfo(String searchNodeId, Integer segmentId)
			throws BioMatchManagerException {
		try {
			return bioMatchManagerDao.getEntityByFields(BioMatcherNodeSegmentInfo.class, "matcherNodeId", searchNodeId,
					"segmentId", segmentId);
		} catch (Throwable th) {
			throw new BioMatchManagerException("Error in getMatcherNodeSegmentInfo for searchNodeId: " + searchNodeId
					+ ", segmentId: " + segmentId + " : " + th.getMessage(), th);
		}
	}

	public List<BioMatcherSegmentInfo> getMatcherSegmentInfoList() throws BioMatchManagerException {
		try {
			return bioMatchManagerDao.getAllEntity(BioMatcherSegmentInfo.class);
		} catch (Throwable th) {
			throw new BioMatchManagerException("Error in getMatcherSegmentInfoList: " + th.getMessage(), th);
		}
	}

	public List<BioMatcherSegmentInfo> getMatcherSegmentInfoListByBinId(Integer binId) throws BioMatchManagerException {
		try {
			return bioMatchManagerDao.getEntityListByField(BioMatcherSegmentInfo.class, "binId", binId);
		} catch (Throwable th) {
			throw new BioMatchManagerException("Error in getMatcherSegmentInfoListByBinId: " + th.getMessage(), th);
		}
	}

	public Map<Integer, Long> getLiveMatcherSegmentVersionMap(Integer binId) throws BioMatchManagerException {
		try {
			Map<Integer, Long> matcherSegmentVersionMap = new ConcurrentHashMap<>();

			List<BioMatcherSegmentInfo> bioMatcherSegmentInfoList = bioMatchManagerDao
					.getEntityListByField(BioMatcherSegmentInfo.class, "binId", binId);

			for (BioMatcherSegmentInfo bioMatcherSegmentInfo : bioMatcherSegmentInfoList) {
				if (bioMatcherSegmentInfo.getSegmentVersion() > 0) {
					matcherSegmentVersionMap.put(bioMatcherSegmentInfo.getSegmentId(),
							bioMatcherSegmentInfo.getSegmentVersion());
				}
			}

			return matcherSegmentVersionMap;
		} catch (Throwable th) {
			throw new BioMatchManagerException(
					"Error in getLiveMatcherSegmentVersionMap for binId: " + binId + " : " + th.getMessage(), th);
		}
	}

	public ConcurrentHashMap<Integer, Long> getLiveMatcherNodeSegmentVersionMap(String searchNodeId)
			throws BioMatchManagerException {
		try {
			ConcurrentHashMap<Integer, Long> matcherNodeSegmentVersionMap = new ConcurrentHashMap<>();

			List<BioMatcherNodeSegmentInfo> bioMatcherNodeSegmentInfoList = bioMatchManagerDao.getEntityListByFields(
					BioMatcherNodeSegmentInfo.class, "matcherNodeId", searchNodeId, "assignedFlag", Boolean.TRUE);

			for (BioMatcherNodeSegmentInfo bioMatcherNodeSegmentInfo : bioMatcherNodeSegmentInfoList) {
				matcherNodeSegmentVersionMap.put(bioMatcherNodeSegmentInfo.getSegmentId(),
						bioMatcherNodeSegmentInfo.getSegmentVersion());
			}

			return matcherNodeSegmentVersionMap;
		} catch (Throwable th) {
			throw new BioMatchManagerException("Error in getLiveMatcherNodeSegmentVersionMap for searchNodeId: "
					+ searchNodeId + " : " + th.getMessage(), th);
		}
	}

	public Map<Integer, Long> getMatcherSegmentVersionMapBySearchBrokerId(String searchBrokerId)
			throws BioMatchManagerException {
		try {
			Map<Integer, Long> matcherNodeSegmentVersionMap = new HashMap<>();

			Set<Integer> binIdList = bioMatcherConfigService.getAssignedBinIdListBySearchBrokerId(searchBrokerId);

			binIdList.forEach((binId) -> {
				try {
					getMatcherSegmentInfoListByBinId(binId).forEach((bioMatcherSegmentInfo) -> {
						matcherNodeSegmentVersionMap.put(bioMatcherSegmentInfo.getSegmentId(),
								bioMatcherSegmentInfo.getSegmentVersion());
					});
				} catch (Throwable th) {
					Throwables.propagate(th);
				}
			});
			return matcherNodeSegmentVersionMap;
		} catch (Throwable th) {
			throw new BioMatchManagerException(
					"Error in getMatcherSegmentVersionMapBySearchBrokerId for searchBrokerId: " + searchBrokerId + " : "
							+ th.getMessage(),
					th);
		}
	}

	public Map<BiKey<Integer, Integer>, Long> getEventCountByBinIdSegmentId() throws BioMatchManagerException {
		try {
			// return bioMatchManagerDao.getEventCountByBinIdSegmentId();

			List<BiometricIdInfo> biometricIdInfoList = bioMatchManagerDao.getAllEntity(BiometricIdInfo.class);

			Map<BiKey<Integer, Integer>, Long> eventCountByBinSegmentMap = new HashMap<>();

			biometricIdInfoList.forEach((biometricIdInfo) -> {
				long delta = (biometricIdInfo.getCurrentBiometricId() > 0L) ? (biometricIdInfo.getCurrentBiometricId()
						- Math.max(1L, biometricIdInfo.getStartBiometricId())) : 0L;
				BiKey<Integer, Integer> binIdSegmentIdKey = new BiKey<>(biometricIdInfo.getBinId(),
						biometricIdInfo.getSegmentId());

				eventCountByBinSegmentMap.compute(binIdSegmentIdKey, (oldBinIdSegmentIdKey, oldCount) -> {
					return oldCount == null ? delta : delta + oldCount;
				});
			});

			return eventCountByBinSegmentMap;
		} catch (Throwable th) {
			throw new BioMatchManagerException("Error in getEventCountByBinIdSegmentId : " + th.getMessage(), th);
		}
	}

	public void setBioMatchManagerDao(BioMatchManagerDao bioMatchManagerDao) {
		this.bioMatchManagerDao = bioMatchManagerDao;
	}

	public void setBioLockingService(BioLockingService bioLockingService) {
		this.bioLockingService = bioLockingService;
	}

	public void setBioMatcherConfigService(BioMatcherConfigService bioMatcherConfigService) {
		this.bioMatcherConfigService = bioMatcherConfigService;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		logger.info("In BioMatchManagerServiceImpl.afterPropertiesSet");
		InMemoryManager.startCallbackExecutor();
		InMemoryManager.startJobTimeoutExecutor();
		bioMatcherConfigService.deleteStaleConnectionSettings();
	}
}
