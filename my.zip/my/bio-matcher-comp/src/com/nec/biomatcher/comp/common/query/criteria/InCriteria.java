package com.nec.biomatcher.comp.common.query.criteria;

/**
 * Criteria for specifying In criteria condition with array value.
 *
 * @author Mahesh
 */
public class InCriteria extends CriteriaDto implements ValueCriteriaDto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The value. */
	private Object value;

	/**
	 * Instantiates a new equal criteria.
	 */
	public InCriteria() {

	}

	/**
	 * Instantiates a new equal criteria.
	 *
	 * @param value
	 *            the value
	 */
	public InCriteria(Object value) {
		this.value = value;
	}

	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public Object getValue() {
		return value;
	}

	/**
	 * Sets the value.
	 *
	 * @param value
	 *            the value to set
	 */
	public void setValue(Object value) {
		this.value = value;
	}
}
