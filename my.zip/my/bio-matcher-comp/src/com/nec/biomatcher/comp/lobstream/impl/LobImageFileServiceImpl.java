package com.nec.biomatcher.comp.lobstream.impl;

import java.io.File;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;

import com.nec.biomatcher.comp.common.parameter.BioParameterService;
import com.nec.biomatcher.comp.lobstream.LobImageService;
import com.nec.biomatcher.comp.lobstream.exception.LobImageNotFoundException;
import com.nec.biomatcher.comp.lobstream.exception.LobImageServiceException;
import com.nec.biomatcher.comp.lobstream.util.LobFileSystemUtil;
import com.nec.biomatcher.comp.metrics.ServerHealth;
import com.nec.biomatcher.comp.util.ValueChangeNotification;
import com.nec.biomatcher.core.framework.common.CommonLogger;
import com.nec.biomatcher.core.framework.common.StringUtil;

/**
 * The Class LobImageFileServiceImpl.
 */
public class LobImageFileServiceImpl implements LobImageService, InitializingBean {

	/** The Constant logger. */
	private static final Logger logger = Logger.getLogger(LobImageFileServiceImpl.class);

	/** The bio parameter service. */
	private BioParameterService bioParameterService;

	/** The lob stream storage path. */
	private File lobStreamStoragePath;

	/** The retention hours. */
	private AtomicInteger retentionHours = new AtomicInteger(2);

	@Override
	public String createLob(String lobId, byte[] lobData, String lobType) throws LobImageServiceException {
		try {
			File lobFile = LobFileSystemUtil.buildLobStreamFile(lobId, lobType, lobStreamStoragePath);
			LobFileSystemUtil.writeToFile(lobData, lobFile);
			return lobId;
		} catch (Throwable th) {
			throw new LobImageServiceException(th);
		}
	}

	@Override
	public String createLob(byte[] lobData, String lobType) throws LobImageServiceException {
		String lobId = UUID.randomUUID().toString();
		return createLob(lobId, lobData, lobType);
	}

	@Override
	public byte[] getLobData(String lobId, String lobType) throws LobImageServiceException, LobImageNotFoundException {
		try {
			return LobFileSystemUtil.getLobData(lobId, lobType, lobStreamStoragePath, retentionHours.get());
		} catch (LobImageServiceException | LobImageNotFoundException ex) {
			throw ex;
		} catch (Throwable th) {
			throw new LobImageServiceException(
					"Error in getLobData: lobId: " + lobId + ", lobType: " + lobType + " : " + th.getMessage(), th);
		}
	}

	public boolean checkLobExists(String lobId, String lobType) throws LobImageServiceException {
		try {
			return LobFileSystemUtil.checkLobFileExists(lobId, lobType, lobStreamStoragePath, retentionHours.get());
		} catch (Throwable th) {
			throw new LobImageServiceException(th);
		}
	}

	@Override
	public boolean deleteLob(String lobId, String lobType) throws LobImageServiceException {
		try {
			return LobFileSystemUtil.deleteLob(lobId, lobType, lobStreamStoragePath, retentionHours.get());
		} catch (Throwable th) {
			throw new LobImageServiceException(th);
		}
	}

	@Override
	public void deleteLobsByLobId(String lobId) throws LobImageServiceException {
		try {
			LobFileSystemUtil.deleteLobsByLobId(lobId, lobStreamStoragePath, retentionHours.get());
		} catch (Throwable th) {
			throw new LobImageServiceException(th);
		}
	}

	@Override
	public void performLobHousekeeping() {
		try {
			LobFileSystemUtil.performHousekeeping(lobStreamStoragePath, retentionHours.get());
		} catch (Throwable th) {
			th = new LobImageServiceException(th);
			CommonLogger.STATUS_LOG.error("Error during performLobHousekeeping: " + th.getMessage(), th);
		}
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		logger.info("In LobImageFileServiceImpl.afterPropertiesSet");

		String path = bioParameterService.getParameterValue("LOBSTREAM_STORAGE_PATH", "DEFAULT",
				new File(System.getProperty("user.home"), "storage/lobstream/data/").getAbsolutePath());
		logger.info("In LobImageFileServiceImpl: LOBSTREAM_STORAGE_PATH: " + path);

		lobStreamStoragePath = new File(path);
		lobStreamStoragePath.mkdirs();
		if (!lobStreamStoragePath.isDirectory()) {
			throw new LobImageServiceException(
					"LobStream storage path does not exist : " + lobStreamStoragePath.getAbsolutePath());
		}

		ValueChangeNotification<String> lobStreamRetentionHoursVCN = BioParameterService.getValueChangeNotification(
				bioParameterService, "LOBSTREAM_RETENTION_HOURS", "DEFAULT", "2",
				value -> retentionHours.set(StringUtil.stringToInt(value, 2)));
		lobStreamRetentionHoursVCN.checkAndNotify();

		ValueChangeNotification<String> lobFileRecheckDelayMilliVCN = BioParameterService.getValueChangeNotification(
				bioParameterService, "LOB_FILE_RECHECK_DELAY_MILLI", "DEFAULT", "200",
				value -> LobFileSystemUtil.setLobFileRecheckDelayMilli(StringUtil.stringToLong(value, 200L)));
		lobFileRecheckDelayMilliVCN.checkAndNotify();

		ServerHealth.registerFreeSpaceGauge(null, null, "LOB_STORAGE_FREE_SPACE", lobStreamStoragePath.toPath());
	}

	public void setBioParameterService(BioParameterService bioParameterService) {
		this.bioParameterService = bioParameterService;
	}

}
