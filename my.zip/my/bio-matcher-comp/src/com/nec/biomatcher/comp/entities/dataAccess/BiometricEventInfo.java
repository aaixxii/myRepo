package com.nec.biomatcher.comp.entities.dataAccess;

import java.util.Date;

import com.nec.biomatcher.core.framework.dataAccess.Dbo;
import com.nec.biomatcher.spec.transfer.event.BiometricEventPhase;
import com.nec.biomatcher.spec.transfer.event.BiometricEventStatus;

/**
 * The Class BiometricEventInfo.
 */
public class BiometricEventInfo implements Dbo {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The biometric id. */
	private Long biometricId;

	/** The external id. */
	private String externalId;

	private String eventId;

	/** The bin id. */
	private Integer binId;

	/** The status. */
	private BiometricEventStatus status;

	private BiometricEventPhase phase;

	/** The template data key. */
	private String templateDataKey;

	/** The template size. */
	private Integer templateSize;

	/** The data version. */
	private Long dataVersion;

	/** The assigned segment id. */
	private Integer assignedSegmentId;

	/** The segment sync date time. */
	private Date segmentSyncDateTime;

	/** The create date time. */
	private Date createDateTime;

	/** The update date time. */
	private Date updateDateTime;

	/** The error date time. */
	private Date errorDateTime;

	private String siteId;

	public Long getBiometricId() {
		return biometricId;
	}

	public void setBiometricId(Long biometricId) {
		this.biometricId = biometricId;
	}

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	public Integer getBinId() {
		return binId;
	}

	public void setBinId(Integer binId) {
		this.binId = binId;
	}

	public BiometricEventStatus getStatus() {
		return status;
	}

	public void setStatus(BiometricEventStatus status) {
		this.status = status;
	}

	public Date getCreateDateTime() {
		return createDateTime;
	}

	public void setCreateDateTime(Date createDateTime) {
		this.createDateTime = createDateTime;
	}

	public Date getUpdateDateTime() {
		return updateDateTime;
	}

	public void setUpdateDateTime(Date updateDateTime) {
		this.updateDateTime = updateDateTime;
	}

	public String getTemplateDataKey() {
		return templateDataKey;
	}

	public void setTemplateDataKey(String templateDataKey) {
		this.templateDataKey = templateDataKey;
	}

	public Integer getTemplateSize() {
		return templateSize;
	}

	public void setTemplateSize(Integer templateSize) {
		this.templateSize = templateSize;
	}

	public Long getDataVersion() {
		return dataVersion;
	}

	public void setDataVersion(Long dataVersion) {
		this.dataVersion = dataVersion;
	}

	public Integer getAssignedSegmentId() {
		return assignedSegmentId;
	}

	public void setAssignedSegmentId(Integer assignedSegmentId) {
		this.assignedSegmentId = assignedSegmentId;
	}

	public Date getSegmentSyncDateTime() {
		return segmentSyncDateTime;
	}

	public void setSegmentSyncDateTime(Date segmentSyncDateTime) {
		this.segmentSyncDateTime = segmentSyncDateTime;
	}

	public Date getErrorDateTime() {
		return errorDateTime;
	}

	public void setErrorDateTime(Date errorDateTime) {
		this.errorDateTime = errorDateTime;
	}

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	public BiometricEventPhase getPhase() {
		return phase;
	}

	public void setPhase(BiometricEventPhase phase) {
		this.phase = phase;
	}

	public String getSiteId() {
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

}
