package com.nec.biomatcher.comp.common.parameter.exception;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

/**
 * The Class BioParameterServiceException.
 */
public class BioParameterServiceException extends CoreException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new bio parameter service exception.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public BioParameterServiceException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new bio parameter service exception.
	 *
	 * @param message
	 *            the message
	 */
	public BioParameterServiceException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new bio parameter service exception.
	 *
	 * @param cause
	 *            the cause
	 */
	public BioParameterServiceException(Throwable cause) {
		super(cause);
	}

}
