package com.nec.biomatcher.comp.common.query.criteria;

import com.nec.biomatcher.spec.transfer.core.Dto;

/**
 * Criteria for specifying value criteria.
 *
 * @author Mahesh
 */
public interface ValueCriteriaDto extends Dto {

	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public Object getValue();

}
