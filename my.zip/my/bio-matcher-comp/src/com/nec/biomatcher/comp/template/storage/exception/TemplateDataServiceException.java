package com.nec.biomatcher.comp.template.storage.exception;

import com.nec.biomatcher.core.framework.common.exception.CoreException;

/**
 * The Class TemplateDataServiceException.
 */
public class TemplateDataServiceException extends CoreException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new template data service exception.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public TemplateDataServiceException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Instantiates a new template data service exception.
	 *
	 * @param message
	 *            the message
	 */
	public TemplateDataServiceException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new template data service exception.
	 *
	 * @param cause
	 *            the cause
	 */
	public TemplateDataServiceException(Throwable cause) {
		super(cause);
	}

}
