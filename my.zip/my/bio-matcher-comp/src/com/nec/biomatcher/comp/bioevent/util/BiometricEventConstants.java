package com.nec.biomatcher.comp.bioevent.util;

public class BiometricEventConstants {
	public static final String ERROR_CODE_GENERAL = "BE001";

	public static final String ERROR_CODE_EXTRACTION = "BE002";
}
