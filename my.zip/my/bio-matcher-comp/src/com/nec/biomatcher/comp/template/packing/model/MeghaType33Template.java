package com.nec.biomatcher.comp.template.packing.model;

import java.io.PrintStream;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.nec.biomatcher.comp.template.packing.exception.MeghaTemplateException;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateConfig;
import com.nec.biomatcher.comp.template.packing.util.MeghaTemplateUtil;
import com.nec.biomatcher.core.framework.common.HoldFlagUtil;

public class MeghaType33Template extends MeghaTemplate {
	private Map<Integer, MeghaType33Event> eventMap = new HashMap<Integer, MeghaType33Event>();

	public MeghaType33Template(int userFlagByteCount) {
		super(userFlagByteCount);
	}

	public Map<Integer, MeghaType33Event> getEventMap() {
		return eventMap;
	}

	public void setEventMap(Map<Integer, MeghaType33Event> eventMap) {
		this.eventMap = eventMap;
	}

	public void print(PrintStream printStream) {
		printStream.println("---------Header---------");
		if (templateHeader != null) {
			templateHeader.print(printStream);
		}
		eventMap.entrySet().forEach((entry) -> {
			printStream.println("---------Event Index: " + entry.getKey() + " ---------");
			((MeghaEvent) entry.getValue()).print(printStream);
		});
	}

	@Override
	public byte[] pack(MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		if (templateHeader == null) {
			templateHeader = new MeghaTemplateHeader(userFlagByteCount);
		}
		templateHeader.setTemplateTypeCode((byte) 33);
		templateHeader.setEventHoldFlag(0);
		templateHeader.setMaxEventCount((byte) eventMap.size());

		byte[] templateData = new byte[MeghaTemplate.calculateTemplateSize(templateHeader.getTemplateHeaderSize(),
				MeghaType33Event.getEventDataSize(meghaTemplateConfig), templateHeader.getMaxEventCount())];
		ByteBuffer templateDataBuf = ByteBuffer.wrap(templateData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);

		for (int eventIndex : eventMap.keySet()) {
			MeghaType33Event event = eventMap.get(eventIndex);
			templateDataBuf.position(templateHeader.getTemplateHeaderSize()
					+ (eventIndex * MeghaType33Event.getEventDataSize(meghaTemplateConfig)));
			templateDataBuf.put(event.pack(meghaTemplateConfig));
			templateHeader
					.setEventHoldFlag(HoldFlagUtil.setHoldFlag(templateHeader.getEventHoldFlag(), eventIndex, true));
		}

		templateDataBuf.position(0);
		templateDataBuf.put(templateHeader.pack());

		templateData[MeghaTemplateHeader.SANITY_BYTE_POSITION] = 0;
		templateData[MeghaTemplateHeader.SANITY_BYTE_POSITION] = MeghaTemplateUtil.calculateChecksum(templateData);

		return templateData;
	}

	@Override
	public void unpack(byte[] templateData, MeghaTemplateConfig meghaTemplateConfig) throws MeghaTemplateException {
		if (templateData == null) {
			throw new MeghaTemplateException("templateData is null");
		}
		if ((templateData.length - MeghaTemplateUtil.getTemplateHeaderSize(userFlagByteCount))
				% MeghaType33Event.getEventDataSize(meghaTemplateConfig) != 0) {
			throw new MeghaTemplateException("Invalid template size. TemplateSize: " + templateData.length
					+ " minus HeaderSize: " + MeghaTemplateUtil.getTemplateHeaderSize(userFlagByteCount)
					+ " shuould be divisable by EvendDataSize: "
					+ MeghaType33Event.getEventDataSize(meghaTemplateConfig));
		}

		ByteBuffer templateDataBuf = ByteBuffer.wrap(templateData).order(MeghaTemplateUtil.DEFAULT_BYTE_ORDER);

		templateHeader = new MeghaTemplateHeader(userFlagByteCount);
		templateHeader.unpack(templateDataBuf);

		List<Integer> eventIndexList = HoldFlagUtil.getHoldFlagIndexList(templateHeader.getEventHoldFlag(),
				templateHeader.getMaxEventCount());
		for (int eventIndex : eventIndexList) {
			byte eventData[] = new byte[MeghaType33Event.getEventDataSize(meghaTemplateConfig)];

			templateDataBuf.position(templateHeader.getTemplateHeaderSize()
					+ (eventIndex * MeghaType33Event.getEventDataSize(meghaTemplateConfig)));
			templateDataBuf.get(eventData);

			MeghaType33Event event = new MeghaType33Event();
			event.unpack(eventData, meghaTemplateConfig);

			eventMap.put(eventIndex, event);
		}
	}

}
