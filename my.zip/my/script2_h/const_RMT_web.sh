
# script setting
MODULE=RMT_web
URI=alsok-g6-app-wr

SETTING=( DbPropAp.xml application.properties )


for file in ${SETTING[@]} ; do 
  echo $file
done

TOMCAT_DIR="/usr/local/src/apache-tomcat-9.0.19"
################

REL_DIR=$TOMCAT_DIR"/webapps/"$URI"/WEB-INF/classes"
BACK_DIR="/tmp/"$MODULE"_backup"

DIFF_COPY="diff_result_copy.txt"
DIFF_BACK="diff_result_setting.txt"


# Backup

DATE=`date "+%Y%m%d"`
BACK_DIR=$BACK_DIR"/"$DATE
SETTING_BACK_DIR=$BACK_DIR"_setting"
MODULE_BACK_DIR=$BACK_DIR"_module"

mkdir -p $MODULE_BACK_DIR
mkdir -p $SETTING_BACK_DIR

echo "== Today is " $DATE


