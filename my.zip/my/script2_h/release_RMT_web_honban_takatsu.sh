#!/bin/sh

#####################################################
#
#       REPLACEMENT CONFIG (honban-nishi)
#
#####################################################

###
# Setting
###
MYNAME="RMT_web"
MODE="Honban.Nishi"

####
# diff file
####
diff_file(){
  echo "diff [" $1 "]==[" $2 "]"
  diff -s $1 $2 >> $3
}

####
# file copy and output diff
###
copy_file(){
  echo "copy [" $1 "]->[" $2 "]"
  cp -p -f $1 $2
  diff_file $1 $2 $DIFF_COPY
}


####
#  main
####

SCRIPT_DIR=$(cd $(dirname $0); pwd)
cd $SCRIPT_DIR

source "const_"$MYNAME".sh"


echo "---------------------------------"
echo "change setting to Honban Nishi"
echo "---------------------------------"

echo "execute in [" $SCRIPT_DIR "]"

if [[ -f $DIFF_COPY ]]; then
  echo "clean old diff file"
  rm $DIFF_COPY
fi

if [[ -f $DIFF_DIFF_BACK ]]; then
  echo "clean old diff file"
  rm $DIFF_BACK
fi

echo ""
echo "=== diff backup file"
for file in ${SETTING[@]} ; do
  diff_file $SETTING_BACK_DIR"/"$file $REL_DIR"/"$file"."$MODE $DIFF_BACK
done
cat $DIFF_BACK
echo "=========================================== end"

echo ""

echo "=== start copy"
for file in ${SETTING[@]} ; do
  copy_file $REL_DIR"/"$file"."$MODE $REL_DIR"/"$file
done
cat $DIFF_COPY
echo "================= end"

echo ""


echo "=== else prop copy start"

mkdir -m 755 -p /data/kbs_proc/data/tmp/RMTweb/ini/default
mkdir -m 755 -p /home/kbs_proc/conf/RMTwebi18n
mkdir -m 755 -p /home/kbs_proc/conf/zwr/properties

cp -f $REL_DIR"/rmt_appLog.xml" /home/kbs_proc/conf/rmt_appLog.xml
cp -f $REL_DIR"/i18n/"* /home/kbs_proc/conf/RMTwebi18n
cp -f $REL_DIR"/zwr/properties/"* /home/kbs_proc/conf/zwr/properties

if [[ -e /home/kbs_proc/conf/appLog.xml ]]; then
  echo "appLog.xml exist"
  else
  echo "appLog.xml not exist"
  cp -f $REL_DIR"/appLog.xml" /home/kbs_proc/conf/appLog.xml
  chmod 755 /home/kbs_proc/conf/appLog.xml
fi

if [[ -e /home/kbs_proc/conf/appLog.xsd ]]; then
  echo "appLog.xsd exist"
  else
  echo "appLog.xsd not exist"
  cp -f $REL_DIR"/appLog.xsd" /home/kbs_proc/conf/appLog.xsd
  chmod 755 /home/kbs_proc/conf/appLog.xsd
fi

echo "=== else prop copy end"


