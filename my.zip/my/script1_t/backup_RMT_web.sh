#!/bin/sh


# script setting
MYNAME="RMT_web"
URI=alsok-g6-app-wr

################

SCRIPT_DIR=$(cd $(dirname $0); pwd)
cd $SCRIPT_DIR

source "const_"$MYNAME".sh"

# Backup

mkdir -p $MODULE_BACK_DIR
mkdir -p $SETTING_BACK_DIR

echo "== Backup old zip file"
echo "backup to ["$MODULE_BACK_DIR"] "
mv "/tmp/"$MYNAME".zip" $MODULE_BACK_DIR"/"$MYNAME".zip"
ls -al $MODULE_BACK_DIR


echo "== Backup Old Setting file"
echo "backup from ["$REL_DIR"]"
echo "backup to ["$SETTING_BACK_DIR"] "

cp -p $REL_DIR/*.xml $SETTING_BACK_DIR 
cp -p $REL_DIR/*.properties $SETTING_BACK_DIR
ls -al $SETTING_BACK_DIR

echo "end script"
#################

