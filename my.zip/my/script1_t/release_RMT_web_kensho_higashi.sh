#!/bin/sh

#####################################################
#
#       REPLACEMENT CONFIG (kensho-higashi)
#
#####################################################

###
# Setting
###
MYNAME="RMT_web"
MODE="Kensho"

####
# diff file
####
diff_file(){
  echo "diff [" $1 "]==[" $2 "]"
  diff -s $1 $2 >> $3
}

####
# file copy and output diff
###
copy_file(){
  echo "copy [" $1 "]->[" $2 "]"
  cp -p -f $1 $2
  diff_file $1 $2 $DIFF_COPY
}


####
#  main
####

SCRIPT_DIR=$(cd $(dirname $0); pwd)
cd $SCRIPT_DIR

source "const_"$MYNAME".sh"


echo "---------------------------------"
echo "change setting to Kensho Higashi"
echo "---------------------------------"

echo "execute in [" $SCRIPT_DIR "]"

if [[ -f $DIFF_COPY ]]; then
  echo "clean old diff file"
  rm $DIFF_COPY
fi

if [[ -f $DIFF_DIFF_BACK ]]; then
  echo "clean old diff file"
  rm $DIFF_BACK
fi

echo ""
echo "=== diff backup file"
for file in ${SETTING[@]} ; do
  diff_file $SETTING_BACK_DIR"/"$file $REL_DIR"/"$file"."$MODE $DIFF_BACK
done
cat $DIFF_BACK
echo "=========================================== end"

echo ""

echo "=== start copy"
for file in ${SETTING[@]} ; do
  copy_file $REL_DIR"/"$file"."$MODE $REL_DIR"/"$file
done
cat $DIFF_COPY
echo "================= end"

echo ""


echo "=== else prop copy start"
cp -f $REL_DIR"/rmt_appLog.xml" /home/kbs_proc/conf/KBS_rmt/rmt_appLog.xml
cp -f $REL_DIR"/i18n/"* /home/kbs_proc/conf/KBS_rmt/RMTwebi18n
cp -f $REL_DIR"/zwr/properties/"* /home/kbs_proc/conf/KBS_rmt/zwr/properties

echo "=== else prop copy end"


