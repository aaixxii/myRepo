package com.nec.biomatcher.spec.services;

import com.nec.biomatcher.spec.services.exception.BioVerificationJobServiceException;
import com.nec.biomatcher.spec.transfer.job.verify.VerifyJobRequestDto;
import com.nec.biomatcher.spec.transfer.job.verify.VerifyJobResultDto;
import com.nec.biomatcher.spec.transfer.model.BioJobStatus;

/**
 * The Interface BioVerificationJobService.
 */
public interface BioVerificationJobService {

	/**
	 * Verify.
	 *
	 * @param request
	 *            the request
	 * @return the verify job result dto
	 * @throws BioVerificationJobServiceException
	 *             the bio verification job service exception
	 */
	public VerifyJobResultDto verify(VerifyJobRequestDto request) throws BioVerificationJobServiceException;

	public String submitVerificationJob(VerifyJobRequestDto jobRequestDto) throws BioVerificationJobServiceException;

	public BioJobStatus getVerificationJobStatus(String jobId) throws BioVerificationJobServiceException;

	public VerifyJobResultDto getVerificationJobResult(String jobId) throws BioVerificationJobServiceException;

	public void deleteVerificationJob(String jobId) throws BioVerificationJobServiceException;

}
