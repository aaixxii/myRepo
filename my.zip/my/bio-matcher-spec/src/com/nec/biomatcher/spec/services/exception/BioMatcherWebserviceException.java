package com.nec.biomatcher.spec.services.exception;

import java.rmi.RemoteException;

import com.google.common.base.Throwables;

/**
 * The Class BioMatcherWebserviceException.
 */
public class BioMatcherWebserviceException extends RemoteException {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new bio matcher webservice exception.
	 */
	public BioMatcherWebserviceException() {
		super("BioMatcherWebserviceException encountered.");
	}

	/**
	 * Instantiates a new bio matcher webservice exception.
	 *
	 * @param message
	 *            the message
	 */
	public BioMatcherWebserviceException(String message) {
		super(message);
	}

	/**
	 * Instantiates a new bio matcher webservice exception.
	 *
	 * @param message
	 *            the message
	 * @param cause
	 *            the cause
	 */
	public BioMatcherWebserviceException(String message, Throwable cause) {
		super(message + " : " + Throwables.getStackTraceAsString(cause));
	}
}
