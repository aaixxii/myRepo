package com.nec.biomatcher.spec.transfer.event;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

/**
 * The Enum BiometricEventStatus.
 */
@XmlType
@XmlEnum(String.class)
public enum BiometricEventStatus {

	/** The active. */
	@XmlEnumValue("A")
	ACTIVE("A"),

	/** The deleted. */
	@XmlEnumValue("D")
	DELETED("D");

	/** The Constant valueMap. */
	private static final Map<String, BiometricEventStatus> valueMap = Arrays.stream(values())
			.collect(Collectors.toMap(BiometricEventStatus::getValue, (p) -> p));

	/** The value. */
	private final String value;

	/**
	 * Instantiates a new biometric event status.
	 *
	 * @param value
	 *            the value
	 */
	BiometricEventStatus(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	/**
	 * Enum of.
	 *
	 * @param value
	 *            the value
	 * @return the biometric event status
	 */
	public static BiometricEventStatus enumOf(String value) {
		return (BiometricEventStatus) valueMap.get(value);
	}
}
