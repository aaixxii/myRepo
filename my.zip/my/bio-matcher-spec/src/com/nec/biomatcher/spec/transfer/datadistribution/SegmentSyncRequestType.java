package com.nec.biomatcher.spec.transfer.datadistribution;

public enum SegmentSyncRequestType {
	INIT, UPDATE;
}
