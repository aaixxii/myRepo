package com.nec.biomatcher.spec.transfer.job;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.nec.biomatcher.spec.transfer.core.Dto;
import com.nec.biomatcher.spec.transfer.model.BioJobStatus;

/**
 * The Class BioMatcherJobQueueDto.
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class BioMatcherJobQueueDto implements Dto {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The job id. */
	@XmlElement(required = true, nillable = false)
	private String jobId;

	/** The bio matcher job type. */
	@XmlElement(required = true, nillable = false)
	private BioMatcherJobType bioMatcherJobType;

	/** The bio matcher job request. */
	private BioMatcherJobRequest bioMatcherJobRequest;

	/** The bio matcher job result. */
	private BioMatcherJobResult bioMatcherJobResult;

	/** The status. */
	@XmlElement(required = true, nillable = false)
	private BioJobStatus status;

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public BioMatcherJobRequest getBioMatcherJobRequest() {
		return bioMatcherJobRequest;
	}

	public void setBioMatcherJobRequest(BioMatcherJobRequest bioMatcherJobRequest) {
		this.bioMatcherJobRequest = bioMatcherJobRequest;
	}

	public BioMatcherJobResult getBioMatcherJobResult() {
		return bioMatcherJobResult;
	}

	public void setBioMatcherJobResult(BioMatcherJobResult bioMatcherJobResult) {
		this.bioMatcherJobResult = bioMatcherJobResult;
	}

	public BioJobStatus getStatus() {
		return status;
	}

	public void setStatus(BioJobStatus status) {
		this.status = status;
	}

	public BioMatcherJobType getBioMatcherJobType() {
		return bioMatcherJobType;
	}

	public void setBioMatcherJobType(BioMatcherJobType bioMatcherJobType) {
		this.bioMatcherJobType = bioMatcherJobType;
	}
}
