package com.nec.aim.dm.nodostorage.repository;

import java.sql.SQLException;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringRunner;

import com.nec.aim.dm.nodostorage.NodostorageApplication;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { NodostorageApplication.class })
public class DmConfigRepositoryImplTest {
	
	@Autowired
    private JdbcTemplate jdbcTemplate;	
	
	@Autowired
    private DmConfigRepository dmConfigRepository;
	

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetRedundancy() throws SQLException {
		int redundancy = dmConfigRepository.getRedundancy();
		Assert.assertEquals(3, redundancy);
		System.out.print(redundancy);
	}

	@Test
	public void testGetMaxSegmentSize() {
		
	}

	@Test
	public void testGetMaxSegmentRecord() {
		
	}

	@Test
	public void testGetOneTempalteSize() {
		
	}

}
