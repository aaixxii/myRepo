package com.nec.aim.dm.nodostorage.repository;

import java.sql.SQLException;

import com.nec.aim.dm.nodostorage.entity.SegmentInfo;

public interface SegmentRepository {	
	
}
