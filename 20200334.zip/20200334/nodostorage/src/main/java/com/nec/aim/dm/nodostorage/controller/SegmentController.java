package com.nec.aim.dm.nodostorage.controller;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nec.aim.dm.nodostorage.service.SegmentService;

import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncResponce;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class SegmentController extends HttpServlet {
	private static final long serialVersionUID = 8978225136377187339L;

	@Autowired
	SegmentService segmentService;

	@RequestMapping(value = "/dmSyncSegment", method = RequestMethod.POST)
	@ResponseBody
	public Boolean dmSegmentHandler(HttpServletRequest req, HttpServletResponse res) {
		log.info("Received dmSyncSegment from {}", req.getRemoteHost());
		Boolean result = null;
		try {			
			PBDmSyncRequest dmSegReq = PBDmSyncRequest.parseFrom(req.getInputStream());
			result = segmentService.handlePostRequest(dmSegReq);
			PBDmSyncResponce.Builder dmRes = PBDmSyncResponce.newBuilder();
			dmRes.setSuccess(result);
			log.info("Got respone from node storage, response = {}", result);
			dmRes.build().writeTo(res.getOutputStream());
				
		} catch (Exception e) {
			log.error(e.getMessage());
			result = Boolean.FALSE;
		}
		return result;
	}
}
