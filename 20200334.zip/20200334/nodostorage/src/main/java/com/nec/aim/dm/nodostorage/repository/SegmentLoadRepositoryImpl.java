package com.nec.aim.dm.nodostorage.repository;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nec.aim.dm.nodostorage.config.ConfigProperties;



@Repository
public class SegmentLoadRepositoryImpl implements SegmentLoadRepository {	
	private static final String getMustCatchUpSegments = "select segment_id from segment_loading where storage_id =? and last_version < -1;";
	
	@Autowired
	private ConfigProperties config;
	
	@Autowired
    private JdbcTemplate jdbcTemplate;	
	

	@Override
	public List<Long>  getMustCatchUpSegments() throws SQLException {
		List<Long> result = jdbcTemplate.queryForList(getMustCatchUpSegments, new Object[] {config.getId()}, Long.class);
		return result;
	}
}
