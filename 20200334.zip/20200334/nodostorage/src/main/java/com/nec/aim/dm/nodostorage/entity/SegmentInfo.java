package com.nec.aim.dm.nodostorage.entity;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class SegmentInfo {	
	 private long segmentId;
	 private long bioIdStart;	
	 private long bioIdEnd;
	 private  long binaryLegth;
	 private long recordCount;
	 private long version;
	 private Timestamp updateTs;
	
}
