package com.nec.aim.dm.nodostorage.service;

import java.sql.SQLException;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nec.aim.dm.nodostorage.config.ConfigProperties;
import com.nec.aim.dm.nodostorage.manager.NodeStorageManager;
import com.nec.aim.dm.nodostorage.repository.DmConfigRepository;
import com.nec.aim.dm.nodostorage.repository.NodeStorageRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class NodeStorageCommonService {
	
	 @Autowired
	    ConfigProperties config;
	    
	    @Autowired
	    DmConfigRepository dmConfigRepository;
	    
	    @Autowired
		NodeStorageRepository nodeStorageRepository;
	
	
	@PostConstruct
	@Transactional
	public void getSetting() {
		try {
			NodeStorageManager.saveDmIntConfigToMe("redundancy", Integer.valueOf(dmConfigRepository.getRedundancy()));
			NodeStorageManager.saveDmIntConfigToMe("segmentMaxRecord", Integer.valueOf(dmConfigRepository.getMaxSegmentRecord()));
			NodeStorageManager.saveDmIntConfigToMe("segmentHeadSize", Integer.valueOf(dmConfigRepository.getSegmentHeadSize()));
			NodeStorageManager.saveDmIntConfigToMe("templateSize", Integer.valueOf(dmConfigRepository.getOneTempalteSize()));			
			NodeStorageManager.saveDmIntConfigToMe("myId", Integer.valueOf(config.getId()));			
			NodeStorageManager.saveDmIntConfigToMe("heatbeatInterval", Integer.valueOf(config.getHeatbeatInterval()));
			NodeStorageManager.saveDmIntConfigToMe("catchUpInterval", Integer.valueOf(config.getCatchUpInterval()));
			NodeStorageManager.saveDmIntConfigToMe("fileWriteTheads", Integer.valueOf(config.getFileWriteTheads()));
			NodeStorageManager.saveStringDmConfigToMe("storagePath", config.getPath());
			NodeStorageManager.saveStringDmConfigToMe("myDmId", config.getDmId());		
		
		} catch (SQLException e) {
			log.error(e.getMessage(), e);
		}
	}
	
	@PreDestroy 
	public void close() {
		
	}

}
