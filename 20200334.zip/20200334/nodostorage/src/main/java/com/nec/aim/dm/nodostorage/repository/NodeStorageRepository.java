package com.nec.aim.dm.nodostorage.repository;

import java.sql.SQLException;



public interface NodeStorageRepository {	
	public void heatbeat() throws SQLException;
	public int getMyMailFlag() throws SQLException;
	public long getStorageSize(int nodeStorageId, String dmStorageId) throws SQLException;
	public void updateStorageSize(int size, int nodeStorageId, String dmStorageId) throws SQLException;
	public void clearMyMailFlag(int nodeStorageId) throws SQLException;
}
