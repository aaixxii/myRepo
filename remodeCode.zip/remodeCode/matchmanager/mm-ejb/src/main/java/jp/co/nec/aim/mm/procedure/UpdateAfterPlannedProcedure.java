package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.jdbc.object.StoredProcedure;

/**
 *
 * @author xiazp
 *
 */
public class UpdateAfterPlannedProcedure extends StoredProcedure {
	private static final String UPDATE_AFTER_PLANNED = "update_after_planned";

	public UpdateAfterPlannedProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(UPDATE_AFTER_PLANNED);
		declareParameter(new SqlParameter("p_job_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_container_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_container_job_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_function_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_plans_string", Types.VARCHAR));
		declareParameter(new SqlOutParameter("r_plan_id", Types.BIGINT));
		compile();
	}

	/**
	 * @param topJobId
	 * @param contaierId
	 * @param fucntonId
	 * @param planString
	 * @return
	 * @throws DataAccessException
	 * @throws SQLException
	 */
	public Long executeUpdate(Long topJobId, Integer contaierId, Long containerJobId, Integer fucntonId,
			String planString) throws DataAccessException, SQLException {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_job_id", topJobId);
		map.put("p_container_id", contaierId);
		map.put("p_container_job_id", containerJobId);
		map.put("p_function_id", fucntonId);
		map.put("p_plans_string", planString);
		Map<String, Object> resultMap = execute(map);
		Long planId = (Long) resultMap.get("r_plan_id");
		return planId;
	}
}
