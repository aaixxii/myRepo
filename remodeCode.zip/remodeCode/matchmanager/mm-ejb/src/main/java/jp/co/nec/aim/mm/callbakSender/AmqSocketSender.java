package jp.co.nec.aim.mm.callbakSender;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.SocketChannel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AmqSocketSender implements Runnable {
	private static Logger logger = LoggerFactory.getLogger(AmqSocketSender.class);
	private int socketTimeout = 5 * 10000;
	private byte[] dataMessage;
	private SocketChannel socketChannel;
	private Object channelLocker = new Object();

	public AmqSocketSender(int port, byte[] dataMsg) {
		InetSocketAddress hostAddress = new InetSocketAddress("127.0.0.1", port);
		this.dataMessage = dataMsg;
		try {
			socketChannel = SocketChannel.open(hostAddress);
			socketChannel.configureBlocking(false);
			socketChannel.socket().setKeepAlive(true);
			socketChannel.socket().setSoTimeout(socketTimeout);
			logger.info(
					"Connected to" + socketChannel.socket().getInetAddress() + ":" + socketChannel.socket().getPort());
		} catch (IOException e) {
			logger.warn("Can't connection to AmqSocketServer!!");
			return;
		}
	}

	public void sendMessageToAmq() {
		int sendSize = 0;
		try {
			int sizeOfBody = dataMessage.length;
			ByteBuffer sendBuff = ByteBuffer.wrap(dataMessage);
			sendBuff.order(ByteOrder.BIG_ENDIAN);
			synchronized (channelLocker) {
				while (sendBuff.hasRemaining()) {
					sendSize = socketChannel.write(sendBuff);
					assert (sizeOfBody == sendSize);
					logger.info("Send data size:{}", sendSize);
				}
			}
			sendBuff.clear();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (socketChannel != null && socketChannel.isOpen()) {
				try {
					socketChannel.close();
				} catch (IOException e) {
				}
			}
		}
	}

	@Override
	public void run() {
		sendMessageToAmq();
	}
}
