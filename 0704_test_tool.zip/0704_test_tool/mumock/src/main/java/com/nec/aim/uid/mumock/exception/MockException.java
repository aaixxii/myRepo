package com.nec.aim.uid.mumock.exception;

public class MockException extends RuntimeException {

	private static final long serialVersionUID = 4092967622896782047L;

	/**
	 * @param message
	 */
	public MockException(String message) {
		super(message);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public MockException(String message, Throwable cause) {
		super(message, cause);
	}
}
