package com.nec.aim.uid.mumock.post;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.aim.uid.mumock.constants.Configer;
import com.nec.aim.uid.mumock.mant.MockManager;
import com.nec.aim.uid.mumock.util.ProtobufCreater;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import jp.co.nec.aim.message.proto.AIMEnumTypes.ComponentType;
import jp.co.nec.aim.message.proto.AIMMessages.PBComponentInfo;
import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResult;

public class HttpPoster {
	private static Logger logger = LoggerFactory.getLogger(HttpPoster.class);	
	private static final MediaType MEDIA_TYPE_PLAINTEXT = MediaType.parse("text/plain; charset=utf-8");
	
	/**
	 * @param url
	 * @param dmSegReq
	 * @return
	 */
	public static byte[] post(String url, byte[] data) {
		Callable<byte[]> newPostTask = () -> {
			OkHttpClient client = new OkHttpClient();
			client.setConnectTimeout(30, TimeUnit.SECONDS);
			client.setReadTimeout(30, TimeUnit.SECONDS);
			client.setWriteTimeout(30, TimeUnit.SECONDS);			
			Request request = new Request.Builder().url(url)
					.post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, data)).build();
			byte[] responseData = null;
			try {
				Response response = client.newCall(request).execute();	
				responseData = response.body().bytes();
				logger.info("reposen is success:" + response.isSuccessful());			
			
			} catch (Exception  e) {
				logger.error(e.getMessage(), e);
				responseData = null;
			}			
			return responseData;
		};
		try {
			return MockManager.submitBinary(newPostTask);
		} catch (InterruptedException | ExecutionException e) {
			logger.error(e.getMessage(), e);
			return null;
		}
	}
	
	public static void doExtractComplete(PBMuExtractJobResult extRes, String url) {	
			OkHttpClient client = new OkHttpClient();
			client.setConnectTimeout(30, TimeUnit.SECONDS);
			client.setReadTimeout(30, TimeUnit.SECONDS);
			client.setWriteTimeout(30, TimeUnit.SECONDS);			
			Request request = new Request.Builder().url(url)
					.post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, extRes.toByteArray())).build();			
			try {
				Response response = client.newCall(request).execute();
				logger.info("ExtractComplete Reposene is success:" + response.isSuccessful());	
			
			} catch (Exception  e) {
				logger.error(e.getMessage(), e);
			}
				
	}
	
	public static void doMuHeatbeat() {
		PBComponentInfo info = ProtobufCreater.buildEnterReqeust(ComponentType.MATCH_UNIT, String.valueOf(Configer.getMuId()), Configer.getMuIpPort());
		Runnable task = () -> {
			OkHttpClient client = new OkHttpClient();
			client.setConnectTimeout(30, TimeUnit.SECONDS);
			client.setReadTimeout(30, TimeUnit.SECONDS);
			client.setWriteTimeout(30, TimeUnit.SECONDS);			
			Request request = new Request.Builder().url(Configer.getMuIpPort())
					.post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, info.toByteArray())).build();
		
			try {
				Response response = client.newCall(request).execute();
				logger.info("reposen is success:" + response.isSuccessful());			
			
			} catch (Exception  e) {
				logger.error(e.getMessage(), e);
			}
		};		
		MockManager.scheduleMuheartbeat(task);	
	}
}
