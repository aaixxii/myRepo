/**this is file UidaiRequstTester.java
 * @author xia
   @date 2020/07/03
 */
package com.nec.aim.uid.client.uidplus;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import jp.co.nec.aim.mm.sessionbeans.pojo.UidAimAmqResponse;

/**
 * @author xia
 *
 */
public class UidaiPoster {
	private static AtomicLong lastReqeustId;
	private static AtomicLong lastEnrollmentId;
	private static String sequecFilePath;
	private static PropertiesConfiguration propsConfig;
	String postExtUrl = "http://localhost:8080/matchmanager/AIMExtractService";
	String postMrJobUrl = "http://localhost:8080/matchmanager/AIMInquiryService";
	
	 private static final MediaType MEDIA_TYPE_PLAINTEXT = MediaType.parse("text/plain; charset=utf-8");


	@BeforeClass
	public static void setUp() throws Exception {
		String path = "src/test/resources/uid.sequece.properties";
		File file = new File(path);
		sequecFilePath = file.getPath();
		// String xx = file.getAbsolutePath();
		propsConfig = new PropertiesConfiguration();
		propsConfig.setEncoding("UTF-8");
		propsConfig.load(sequecFilePath);
		long reqeustId = propsConfig.getLong("REQUEST_Id");
		lastReqeustId = new AtomicLong(reqeustId);
		long enrollmentId = propsConfig.getLong("ENROLLMENT_ID");
		lastEnrollmentId = new AtomicLong(enrollmentId);
	}

	@AfterClass
	public static void tearDown() throws Exception {
		try {
			PropertiesConfiguration properties = new PropertiesConfiguration(sequecFilePath);
			properties.setProperty("REQUEST_Id", String.valueOf(lastReqeustId.get()));
			properties.setProperty("ENROLLMENT_ID", String.valueOf(lastEnrollmentId.incrementAndGet()));
			properties.save();
			properties = null;
		} catch (ConfigurationException e) {
			System.out.println(e.getMessage());
		}
	}
	
	@Test
	public void testRepeatExtract() throws IOException, InterruptedException {
		for (int i= 0; i < 30; i++) {
			testExtract();
		}
		
	}

	//@Test
	public void testExtract() throws IOException, InterruptedException {
		String enrollId = "REF_" + String.format("%032d", lastEnrollmentId.incrementAndGet());
		String requestId = "REQ_" + String.format("%032d", lastReqeustId.incrementAndGet());
		String refUrl = "http://127.0.0.1:/8081";
		String extReq = UidaiRequestCreater.buildExtractRequest(requestId, enrollId, refUrl);
		RequestBody requestBody = RequestBody.create(MediaType.parse("text/xml;charset=utf-8"), extReq);
		OkHttpClient client = new OkHttpClient();
		client.setReadTimeout(1000, TimeUnit.MINUTES);
		Request request = new Request.Builder()
				// .url("http://10.197.23.100:8882/matchmanager/AIMExtractService/extract")
				.url("http://127.0.0.1:8080/matchmanager/AIMExtractService/extract").post(requestBody).build();
		try {
			Response response = client.newCall(request).execute();
			String result = response.body().string();
			System.out.println(result);

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void testRepeatSyncInsert() throws ClassNotFoundException, IOException {
		for (int i = 0; i < 30; i++) {
			testSyncInsert();
		}
	}

	//@Test
	public void testSyncInsert() throws IOException, ClassNotFoundException {
		//String enrollId = "REF_00000000000000000000000000000418";
		String enrollId = "REF_" + String.format("%032d", lastEnrollmentId.incrementAndGet());
		String requestId = "REQ_" + String.format("%032d", lastReqeustId.incrementAndGet());
		String refUrl = "http://127.0.0.1:/8081";
		String insertReq = UidaiRequestCreater.buildInsertRequest(requestId, enrollId, refUrl);
		RequestBody requestBody = RequestBody.create(MediaType.parse("text/xml;charset=utf-8"), insertReq);
		OkHttpClient client = new OkHttpClient();
		client.setReadTimeout(1000, TimeUnit.MINUTES);
		Request request = new Request.Builder()
				// .url("http://10.197.23.100:8882/matchmanager/AIMExtractService/extract")
				.url("http://127.0.0.1:8080/matchmanager/AIMSyncService/sync").post(requestBody).build();
		try {
			Response response = client.newCall(request).execute();
			InputStream in = response.body().byteStream();

			// ByteArrayInputStream byteInput = new
			// ByteArrayInputStream(response.body().bytes());
			ObjectInputStream is = new ObjectInputStream(in);
			UidAimAmqResponse ua = (UidAimAmqResponse) is.readObject();
			System.out.println(ua);

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testSyncDelete() throws IOException, ClassNotFoundException {
		String enrollId = "REF_00000000000000000000000000000418";
		String requestId = "REQ_" + String.format("%032d", lastReqeustId.incrementAndGet());
		String refUrl = "http://127.0.0.1:/8081";
		String insertReq = UidaiRequestCreater.buildDeleteRequest(requestId, enrollId);
		RequestBody requestBody = RequestBody.create(MediaType.parse("text/xml;charset=utf-8"), insertReq);
		OkHttpClient client = new OkHttpClient();
		client.setReadTimeout(1000, TimeUnit.MINUTES);
		Request request = new Request.Builder()
				// .url("http://10.197.23.100:8882/matchmanager/AIMExtractService/extract")
				.url("http://127.0.0.1:8080/matchmanager/AIMSyncService/sync").post(requestBody).build();
		try {
			Response response = client.newCall(request).execute();
			InputStream in = response.body().byteStream();

			// ByteArrayInputStream byteInput = new
			// ByteArrayInputStream(response.body().bytes());
			ObjectInputStream is = new ObjectInputStream(in);
			UidAimAmqResponse ua = (UidAimAmqResponse) is.readObject();
			System.out.println(ua);

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testIdentifyByRefID() throws IOException {
		//String enrollId = "REF_00000000000000000000000000000418";
		String enrollId = "REF_" + String.format("%032d", lastEnrollmentId.incrementAndGet());
		String requestId = "REQ_" + String.format("%032d", lastReqeustId.incrementAndGet());
		String refUrl = "http://127.0.0.1:/image/8085";
		String inqReq = UidaiRequestCreater.buildInquiryRequest(requestId, enrollId, refUrl);
		RequestBody requestBody = RequestBody.create(MediaType.parse("text/xml;charset=utf-8"), inqReq);
		OkHttpClient client = new OkHttpClient();
		client.setReadTimeout(5, TimeUnit.MINUTES);
		Request request = new Request.Builder()
				// .url("http://10.197.23.100:8882/matchmanager/AIMInquiryService/inquiry")
				.url("http://127.0.0.1:8080/matchmanager/AIMInquiryService/inquiry").post(requestBody).build();	
			Response response = client.newCall(request).execute();	
			System.out.print(response.body().toString());
		// InputStream is = response.body().byteStream();
		// DataInputStream ds = new DataInputStream(is);
		   // ds.readLong();			
	}
	
	@Test
	public void testRepeatIdentifyByRefID() throws ClassNotFoundException, IOException, InterruptedException {
		for (int i = 0; i < 10; i++) {
			testIdentifyByRefID();
			Thread.sleep(100);
		}
	}
}
