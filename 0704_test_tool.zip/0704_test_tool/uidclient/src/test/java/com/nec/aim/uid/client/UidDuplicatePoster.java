package com.nec.aim.uid.client;

import java.io.ByteArrayInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.TimeUnit;

import org.json.JSONObject;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.googlecode.protobuf.format.JsonFormat;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import jp.co.nec.aim.message.proto.BatchTypeProto.BatchType;
import jp.co.nec.aim.message.proto.BusinessMessage.E_BIOMETRIC_DATA_FORMAT;
import jp.co.nec.aim.message.proto.BusinessMessage.E_REQUESET_TYPE;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBiometricElement;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBiometricsData;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;
import jp.co.nec.aim.message.proto.ExtractService.ExtractRequest;
import jp.co.nec.aim.message.proto.ExtractService.ExtractResponse;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyRequest;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyResponse;
import jp.co.nec.aim.message.proto.SyncService.SyncRequest;
import jp.co.nec.aim.message.proto.SyncService.SyncResponse;

public class UidDuplicatePoster {
    private static final MediaType MEDIA_TYPE_PLAINTEXT = MediaType.parse("text/plain; charset=utf-8");
    
    private PocProtobufCreater protobufCreater = new PocProtobufCreater();
    
    @Before
    public void setUp() throws Exception {
    }
    
    @After
    public void tearDown() throws Exception {
    }
    
    @Test
    public void printExtractRequest() throws IOException {
        ExtractRequest.Builder extReq = ExtractRequest.newBuilder();
        extReq.setBatchJobId(100000000000008l);
        extReq.setType(BatchType.EXTRACT);
        PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();
        PBRequest.Builder pq = PBRequest.newBuilder();
        pq.setRequestId("REQ_100000000000008");
        pq.setEnrollmentId("000000000000000000000000000000123456");
        pq.setRequestType(E_REQUESET_TYPE.INSERT_REFID_DEFAULT);
        PBBiometricsData.Builder pdBiData = PBBiometricsData.newBuilder();
        pdBiData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FIR);
        PBBiometricElement.Builder pbEl = PBBiometricElement.newBuilder();
        pbEl.setFilePath("http://192.168.22.117/test/finger_iris.tar");
        pbEl.setChecksum("130b8c330dc57e2b1314a8eca9c70eda");
        pdBiData.setBiometricElement(pbEl.build());
        pq.setBiometricsData(pdBiData.build());
        pbMsg.setRequest(pq.build());
        extReq.addBusinessMessage(pbMsg.build().toByteString());
        StringBuilder sb = new StringBuilder();
        sb.append("");
        sb.append(System.lineSeparator());
        sb.append("ExtractRequest");
        sb.append(System.lineSeparator());
        sb.append("batchJobId:" + extReq.getBatchJobId());
        sb.append(System.lineSeparator());
        sb.append("batchType:" + extReq.getType());
        sb.append(System.lineSeparator());     
        sb.append(pbMsg.toString());
        sb.append("");      
        System.out.println(sb.toString() );      
    }
    
    @Test
    public void printExtractResponse() throws IOException {
        ExtractResponse exres = PocProtobufCreater.createExtractResponse();
        StringBuilder sb = new StringBuilder();
        sb.append("");
        sb.append(System.lineSeparator());
        sb.append("ExtractResponse");
        sb.append(System.lineSeparator());
        sb.append("batchJobId:" + exres.getBatchJobId());
        sb.append(System.lineSeparator());
        sb.append("batchType:" + exres.getType());
        sb.append(System.lineSeparator());   
        PBBusinessMessage pbMsg = PBBusinessMessage.parseFrom(exres.getBusinessMessage(0).toByteArray());
        sb.append(pbMsg.toString());
        sb.append("");      
        System.out.println(sb.toString() );   
    
    }
    
    @Test
    public void RepeatIdentifyByRefTempalteTest() {
        for (int i = 0 ; i < 5; i++) {
            try {
                testExtract_nomal();
            } catch (InvalidProtocolBufferException e) {                
                e.printStackTrace();
            } catch (IOException e) {                
                e.printStackTrace();
            }
        }
    } 
    
   
    public void testExtract_nomal() throws IOException {
        ExtractRequest.Builder extReq = ExtractRequest.newBuilder();
        extReq.setBatchJobId(100000000000008l);
        extReq.setType(BatchType.EXTRACT);
        PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();
        PBRequest.Builder pq = PBRequest.newBuilder();
        pq.setRequestId("REQ_100000000000008");
        pq.setEnrollmentId("000000000000000000000000000000123456");
        pq.setRequestType(E_REQUESET_TYPE.INSERT_REFID_DEFAULT);
        PBBiometricsData.Builder pdBiData = PBBiometricsData.newBuilder();
        pdBiData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FIR);
        PBBiometricElement.Builder pbEl = PBBiometricElement.newBuilder();
        pbEl.setFilePath("http://192.168.22.117/test/finger_iris.tar");
        pbEl.setChecksum("130b8c330dc57e2b1314a8eca9c70eda");
        pdBiData.setBiometricElement(pbEl.build());
        pq.setBiometricsData(pdBiData.build());
        pbMsg.setRequest(pq.build());
        extReq.addBusinessMessage(pbMsg.build().toByteString());
        
        OkHttpClient client = new OkHttpClient();
        client.setReadTimeout(5, TimeUnit.MINUTES);
        Request request = new Request.Builder()
            .url("http://10.197.23.100:8883/matchmanager/AIMExtractService/extract")
            .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, extReq.build().toByteArray()))
            .build();
        try {
            Response response = client.newCall(request).execute();
            ExtractResponse extRes = ExtractResponse.parseFrom(response.body().bytes());
            PBBusinessMessage lastPbMes = PBBusinessMessage.parseFrom(extRes.getBusinessMessage(0));
            System.out.println("ExtractResponse:");
            System.out.println("batchJobId:" + extRes.getBatchJobId());
            System.out.println("batchType:" + extRes.getType());
            System.out.println("requestId:" + lastPbMes.getRequest().getRequestId());
            System.out.println("refernceId:" + lastPbMes.getRequest().getEnrollmentId());
            System.out.println(lastPbMes.toString());
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testExtract_batchJobId_duplicate() throws IOException {
        ExtractRequest.Builder extReq = ExtractRequest.newBuilder();
        extReq.setBatchJobId(100000000000008l);
        extReq.setType(BatchType.EXTRACT);
        PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();
        PBRequest.Builder pq = PBRequest.newBuilder();
        pq.setRequestId("REQ_100000000000009");
        pq.setEnrollmentId("000000000000000000000000000000123457");
        pq.setRequestType(E_REQUESET_TYPE.INSERT_REFID_DEFAULT);
        PBBiometricsData.Builder pdBiData = PBBiometricsData.newBuilder();
        pdBiData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FIR);
        PBBiometricElement.Builder pbEl = PBBiometricElement.newBuilder();
        pbEl.setFilePath("http://192.168.22.117/test/finger_iris.tar");
        pbEl.setChecksum("130b8c330dc57e2b1314a8eca9c70eda");
        pdBiData.setBiometricElement(pbEl.build());
        pq.setBiometricsData(pdBiData.build());
        pbMsg.setRequest(pq.build());
        extReq.addBusinessMessage(pbMsg.build().toByteString());
        
        OkHttpClient client = new OkHttpClient();
        client.setReadTimeout(5, TimeUnit.MINUTES);
        Request request = new Request.Builder()
            .url("http://10.197.23.100:8883/matchmanager/AIMExtractService/extract")
            .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, extReq.build().toByteArray()))
            .build();
        try {
            Response response = client.newCall(request).execute();
            ExtractResponse extRes = ExtractResponse.parseFrom(response.body().bytes());
            PBBusinessMessage lastPbMes = PBBusinessMessage.parseFrom(extRes.getBusinessMessage(0));
            System.out.println("ExtractResponse:");
            System.out.println("batchJobId:" + extRes.getBatchJobId());
            System.out.println("batchType:" + extRes.getType());
            System.out.println("requestId:" + lastPbMes.getRequest().getRequestId());
            System.out.println("refernceId:" + lastPbMes.getRequest().getEnrollmentId());
            System.out.println(lastPbMes.toString());
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testExtract_requestId_duplicate() throws IOException {
        ExtractRequest.Builder extReq = ExtractRequest.newBuilder();
        extReq.setBatchJobId(100000000000009l);
        extReq.setType(BatchType.EXTRACT);
        PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();
        PBRequest.Builder pq = PBRequest.newBuilder();
        pq.setRequestId("REQ_100000000000008");
        pq.setEnrollmentId("000000000000000000000000000000123458");
        pq.setRequestType(E_REQUESET_TYPE.INSERT_REFID_DEFAULT);
        PBBiometricsData.Builder pdBiData = PBBiometricsData.newBuilder();
        pdBiData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FIR);
        PBBiometricElement.Builder pbEl = PBBiometricElement.newBuilder();
        pbEl.setFilePath("http://192.168.22.117/test/finger_iris.tar");
        pbEl.setChecksum("130b8c330dc57e2b1314a8eca9c70eda");
        pdBiData.setBiometricElement(pbEl.build());
        pq.setBiometricsData(pdBiData.build());
        pbMsg.setRequest(pq.build());
        extReq.addBusinessMessage(pbMsg.build().toByteString());
        
        OkHttpClient client = new OkHttpClient();
        client.setReadTimeout(5, TimeUnit.MINUTES);
        Request request = new Request.Builder()
            .url("http://10.197.23.100:8883/matchmanager/AIMExtractService/extract")
            .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, extReq.build().toByteArray()))
            .build();
        try {
            Response response = client.newCall(request).execute();
            ExtractResponse extRes = ExtractResponse.parseFrom(response.body().bytes());
            PBBusinessMessage lastPbMes = PBBusinessMessage.parseFrom(extRes.getBusinessMessage(0));
            System.out.println("ExtractResponse:");
            System.out.println("batchJobId:" + extRes.getBatchJobId());
            System.out.println("batchType:" + extRes.getType());
            System.out.println("requestId:" + lastPbMes.getRequest().getRequestId());
            System.out.println("refernceId:" + lastPbMes.getRequest().getEnrollmentId());
            System.out.println(lastPbMes.toString());
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testExtract_refernceId_duplicate() throws IOException {
        ExtractRequest.Builder extReq = ExtractRequest.newBuilder();
        extReq.setBatchJobId(1000000000000010l);
        extReq.setType(BatchType.EXTRACT);
        PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();
        PBRequest.Builder pq = PBRequest.newBuilder();
        pq.setRequestId("REQ_1000000000000010");
        pq.setEnrollmentId("000000000000000000000000000000123456");
        pq.setRequestType(E_REQUESET_TYPE.INSERT_REFID_DEFAULT);
        PBBiometricsData.Builder pdBiData = PBBiometricsData.newBuilder();
        pdBiData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FIR);
        PBBiometricElement.Builder pbEl = PBBiometricElement.newBuilder();
        pbEl.setFilePath("http://192.168.22.117/test/finger_iris.tar");
        pbEl.setChecksum("130b8c330dc57e2b1314a8eca9c70eda");
        pdBiData.setBiometricElement(pbEl.build());
        pq.setBiometricsData(pdBiData.build());
        pbMsg.setRequest(pq.build());
        extReq.addBusinessMessage(pbMsg.build().toByteString());
        
        OkHttpClient client = new OkHttpClient();
        client.setReadTimeout(5, TimeUnit.MINUTES);
        Request request = new Request.Builder()
            .url("http://10.197.23.100:8883/matchmanager/AIMExtractService/extract")
            .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, extReq.build().toByteArray()))
            .build();
        try {
            Response response = client.newCall(request).execute();
            ExtractResponse extRes = ExtractResponse.parseFrom(response.body().bytes());
            PBBusinessMessage lastPbMes = PBBusinessMessage.parseFrom(extRes.getBusinessMessage(0));
            System.out.println("ExtractResponse:");
            System.out.println("batchJobId:" + extRes.getBatchJobId());
            System.out.println("batchType:" + extRes.getType());
            System.out.println("requestId:" + lastPbMes.getRequest().getRequestId());
            System.out.println("refernceId:" + lastPbMes.getRequest().getEnrollmentId());
            System.out.println(lastPbMes.toString());
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testSync_nomal() throws InvalidProtocolBufferException {
        E_REQUESET_TYPE reqType = E_REQUESET_TYPE.INSERT_REFURL_DEFAULT;
        SyncRequest.Builder insertReq = SyncRequest.newBuilder();
        insertReq.setBatchJobId(1000000000000010l);
        insertReq.setType(BatchType.ENROLL);
        PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();
        PBRequest.Builder pq = PBRequest.newBuilder();
        pq.setRequestId("REQ_1000000000000011");
        pq.setEnrollmentId("000000000000000000000000000000001185");
        pq.setRequestType(E_REQUESET_TYPE.INSERT_REFURL_DEFAULT);
        PBBiometricsData.Builder pdBiData = PBBiometricsData.newBuilder();
        pdBiData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FIR);
        PBBiometricElement.Builder pbEl = PBBiometricElement.newBuilder();
        if (reqType == E_REQUESET_TYPE.INSERT_REFID_DEFAULT) {
            PBTemplateInfo.Builder template = PBTemplateInfo.newBuilder();
            template.setReferenceId("referenceId1");
        } else if (reqType == E_REQUESET_TYPE.INSERT_REFURL_DEFAULT) {
            pbEl.setFilePath("http://192.168.22.117/UID/DownLoad/Image/MultiModal/TAR/background//0000001.tar");
            pbEl.setChecksum("7976bde555ef09cd251b282d8da285a2");
        }
        pdBiData.setBiometricElement(pbEl.build());
        pq.setBiometricsData(pdBiData.build());
        pbMsg.setRequest(pq.build());
        insertReq.addBusinessMessage(pbMsg.build().toByteString());
        OkHttpClient client = new OkHttpClient();
        client.setReadTimeout(5, TimeUnit.MINUTES);
        Request request = new Request.Builder()
            .url("http://10.197.23.100:8883/matchmanager/AIMSyncService/sync")
            .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, insertReq.build().toByteArray()))
            .build();
        try {
            Response response = client.newCall(request).execute();
            SyncResponse synRes = SyncResponse.parseFrom(response.body().bytes());
            System.out.print(synRes.toString());            
            PBBusinessMessage psMsg = PBBusinessMessage.parseFrom(synRes.getBusinessMessage(0));
            System.out.print(psMsg.toString());
            
        } catch (IOException e) {
           
            e.printStackTrace();
        }
    }
    
    @Test
    public void testSync_batchJob_duplicate() throws InvalidProtocolBufferException {
        E_REQUESET_TYPE reqType = E_REQUESET_TYPE.INSERT_REFURL_DEFAULT;
        SyncRequest.Builder insertReq = SyncRequest.newBuilder();
        insertReq.setBatchJobId(1000000000000010l);
        insertReq.setType(BatchType.ENROLL);
        PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();
        PBRequest.Builder pq = PBRequest.newBuilder();
        pq.setRequestId("REQ_1000000000000012");
        pq.setEnrollmentId("000000000000000000000000000000001186");
        pq.setRequestType(E_REQUESET_TYPE.INSERT_REFURL_DEFAULT);
        PBBiometricsData.Builder pdBiData = PBBiometricsData.newBuilder();
        pdBiData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FIR);
        PBBiometricElement.Builder pbEl = PBBiometricElement.newBuilder();
        if (reqType == E_REQUESET_TYPE.INSERT_REFID_DEFAULT) {
            PBTemplateInfo.Builder template = PBTemplateInfo.newBuilder();
            template.setReferenceId("referenceId1");
        } else if (reqType == E_REQUESET_TYPE.INSERT_REFURL_DEFAULT) {
            pbEl.setFilePath("http://192.168.22.117/UID/DownLoad/Image/MultiModal/TAR/background//0000001.tar");
            pbEl.setChecksum("7976bde555ef09cd251b282d8da285a2");
        }
        pdBiData.setBiometricElement(pbEl.build());
        pq.setBiometricsData(pdBiData.build());
        pbMsg.setRequest(pq.build());
        insertReq.addBusinessMessage(pbMsg.build().toByteString());
        OkHttpClient client = new OkHttpClient();
        client.setReadTimeout(5, TimeUnit.MINUTES);
        Request request = new Request.Builder()
            .url("http://10.197.23.100:8883/matchmanager/AIMSyncService/sync")
            .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, insertReq.build().toByteArray()))
            .build();
        try {
            Response response = client.newCall(request).execute();
            SyncResponse synRes = SyncResponse.parseFrom(response.body().bytes());
            System.out.print(synRes.toString());            
            PBBusinessMessage psMsg = PBBusinessMessage.parseFrom(synRes.getBusinessMessage(0));
            System.out.print(psMsg.toString());
            
        } catch (IOException e) {
           
            e.printStackTrace();
        }
    }
    
    @Test
    public void testSync_requestId_duplicate() throws InvalidProtocolBufferException {
        E_REQUESET_TYPE reqType = E_REQUESET_TYPE.INSERT_REFURL_DEFAULT;
        SyncRequest.Builder insertReq = SyncRequest.newBuilder();
        insertReq.setBatchJobId(1000000000000011l);
        insertReq.setType(BatchType.ENROLL);
        PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();
        PBRequest.Builder pq = PBRequest.newBuilder();
        pq.setRequestId("REQ_100000000000008");
        pq.setEnrollmentId("000000000000000000000000000000001188");
        pq.setRequestType(E_REQUESET_TYPE.INSERT_REFURL_DEFAULT);
        PBBiometricsData.Builder pdBiData = PBBiometricsData.newBuilder();
        pdBiData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FIR);
        PBBiometricElement.Builder pbEl = PBBiometricElement.newBuilder();
        if (reqType == E_REQUESET_TYPE.INSERT_REFID_DEFAULT) {
            PBTemplateInfo.Builder template = PBTemplateInfo.newBuilder();
            template.setReferenceId("referenceId1");
        } else if (reqType == E_REQUESET_TYPE.INSERT_REFURL_DEFAULT) {
            pbEl.setFilePath("http://192.168.22.117/UID/DownLoad/Image/MultiModal/TAR/background//0000001.tar");
            pbEl.setChecksum("7976bde555ef09cd251b282d8da285a2");
        }
        pdBiData.setBiometricElement(pbEl.build());
        pq.setBiometricsData(pdBiData.build());
        pbMsg.setRequest(pq.build());
        insertReq.addBusinessMessage(pbMsg.build().toByteString());
        OkHttpClient client = new OkHttpClient();
        client.setReadTimeout(5, TimeUnit.MINUTES);
        Request request = new Request.Builder()
            .url("http://10.197.23.100:8883/matchmanager/AIMSyncService/sync")
            .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, insertReq.build().toByteArray()))
            .build();
        try {
            Response response = client.newCall(request).execute();
            SyncResponse synRes = SyncResponse.parseFrom(response.body().bytes());
            System.out.print(synRes.toString());            
            PBBusinessMessage psMsg = PBBusinessMessage.parseFrom(synRes.getBusinessMessage(0));
            System.out.print(psMsg.toString());
            
        } catch (IOException e) {
           
            e.printStackTrace();
        }
    }
    
    @Test
    public void testSyncID() {
        SyncRequest syncReq = protobufCreater.createInsertRequest(E_REQUESET_TYPE.INSERT_REFID_DEFAULT);
        OkHttpClient client = new OkHttpClient();
        client.setReadTimeout(5, TimeUnit.MINUTES);
        Request request = new Request.Builder()
            .url("http://10.197.23.100:8883/matchmanager/AIMSyncService/sync")
            .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, syncReq.toByteArray()))
            .build();
        try {
            Response response = client.newCall(request).execute();
            SyncResponse synRes = SyncResponse.parseFrom(response.body().bytes());
            System.out.print(synRes.toString());
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testSyncURL() {
        SyncRequest syncReq = protobufCreater.createInsertRequest(E_REQUESET_TYPE.INSERT_REFURL_DEFAULT);
        OkHttpClient client = new OkHttpClient();
        client.setReadTimeout(5, TimeUnit.MINUTES);
        Request request = new Request.Builder()
            .url("http://10.197.23.100:8883/matchmanager/AIMSyncService/sync")
            .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, syncReq.toByteArray()))
            .build();
        try {
            Response response = client.newCall(request).execute();
            SyncResponse synRes = SyncResponse.parseFrom(response.body().bytes());
            System.out.print(synRes.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testIdentifyByRefUrl() throws InvalidProtocolBufferException {
        E_REQUESET_TYPE type = E_REQUESET_TYPE.IDENTIFY_REFID_DEFAULT;
        IdentifyRequest.Builder iqyReq = IdentifyRequest.newBuilder();
        iqyReq.setBatchJobId(100000000000008l);
        iqyReq.setType(BatchType.IDENTIFY);
        PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();           
        PBRequest.Builder pq = PBRequest.newBuilder();
        pq.setRequestId("REQ_1000000000000011");
        pq.setEnrollmentId("000000000000000000000000000000001185");
        pq.setRequestType(type);
        pq.setMaxResults(10);
        PBBiometricsData.Builder pdBiData = PBBiometricsData.newBuilder();
        pdBiData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FIR);
        PBBiometricElement.Builder pbEl = PBBiometricElement.newBuilder();
        PBTemplateInfo.Builder template = PBTemplateInfo.newBuilder();
        if (type == E_REQUESET_TYPE.IDENTIFY_REFID_DEFAULT) {           
            template.setReferenceId("000000000000000000000000000000001185");          
        } else if (type == E_REQUESET_TYPE.IDENTIFY_DEFAULT) {
            template.setData(ByteString.copyFrom("I am aim uid template".getBytes()));
        }
        pbEl.setTemplateInfo(template.build());
        pdBiData.setBiometricElement(pbEl.build());
        pq.setBiometricsData(pdBiData.build());
        pbMsg.setRequest(pq).build();
        iqyReq.addBusinessMessage(pbMsg.build().toByteString());
        OkHttpClient client = new OkHttpClient();
        client.setReadTimeout(5, TimeUnit.MINUTES);
        Request request = new Request.Builder()
            .url("http://10.197.23.100:8883/matchmanager/AIMInquiryService/inquiry")
            // .url("http://127.0.0.1:8080/matchmanager/AIMInquiryService/inquiry")
            .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, iqyReq.build().toByteArray())).build();
        try {
            Response response = client.newCall(request).execute();
            IdentifyResponse iqyRes = IdentifyResponse.parseFrom(response.body().bytes());
            System.out.println("IdentifyResponse:");
            System.out.println("batchJobId:" + iqyRes.getBatchJobId());
            System.out.println("batchType:" + iqyRes.getType());
            PBBusinessMessage psMsg = PBBusinessMessage.parseFrom(iqyRes.getBusinessMessage(0));
            System.out.println(psMsg.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testIdentifyByRefID() throws InvalidProtocolBufferException {
        E_REQUESET_TYPE type = E_REQUESET_TYPE.IDENTIFY_DEFAULT;
        IdentifyRequest.Builder iqyReq = IdentifyRequest.newBuilder();
        iqyReq.setBatchJobId(11111);
        iqyReq.setType(BatchType.IDENTIFY);
        PBBusinessMessage.Builder pbMsg = PBBusinessMessage.newBuilder();           
        PBRequest.Builder pq = PBRequest.newBuilder();
        pq.setRequestId("request1");
        pq.setEnrollmentId("enroll1");
        pq.setRequestType(type);
        pq.setMaxResults(10);
        PBBiometricsData.Builder pdBiData = PBBiometricsData.newBuilder();
        pdBiData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FIR);
        PBBiometricElement.Builder pbEl = PBBiometricElement.newBuilder();
        PBTemplateInfo.Builder template = PBTemplateInfo.newBuilder();
        if (type == E_REQUESET_TYPE.IDENTIFY_REFID_DEFAULT) {           
            template.setReferenceId("reference1");          
        } else if (type == E_REQUESET_TYPE.IDENTIFY_DEFAULT) {
            template.setData(ByteString.copyFrom("I am aim uid template".getBytes()));
        }
        pbEl.setTemplateInfo(template.build());
        pdBiData.setBiometricElement(pbEl.build());
        pq.setBiometricsData(pdBiData.build());
        pbMsg.setRequest(pq).build();
        iqyReq.addBusinessMessage(pbMsg.build().toByteString());        
        OkHttpClient client = new OkHttpClient();
        client.setReadTimeout(5, TimeUnit.MINUTES);
        Request request = new Request.Builder()
            .url("http://10.197.23.100:8883/matchmanager/AIMInquiryService/inquiry")
            // .url("http://127.0.0.1:8080/matchmanager/AIMInquiryService/inquiry")
            .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, iqyReq.build().toByteArray())).build();
        try {
            Response response = client.newCall(request).execute();
            IdentifyResponse iqyRes = IdentifyResponse.parseFrom(response.body().bytes());
            System.out.println("IdentifyResponse:");
            System.out.println("batchJobId:" + iqyRes.getBatchJobId());
            System.out.println("batchType:" + iqyRes.getType());
            PBBusinessMessage psMsg = PBBusinessMessage.parseFrom(iqyRes.getBusinessMessage(0));
            System.out.println(psMsg.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    
    
    @Test
    public void testGson() {
        IdentifyResponse iqyRes = protobufCreater.createIdentifyResponse();
        Gson gson2 = new GsonBuilder().setPrettyPrinting().create();
        String prettyJson = gson2.toJson(iqyRes.toBuilder());
        System.out.println(prettyJson);
        try (FileWriter writer = new FileWriter("C:/Users/xia/Desktop/test/result.json")) {
            gson2.toJson(iqyRes.toBuilder(), writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Test
    public void testProtobufFromat() throws IOException {
        PBBusinessMessage pbmsg = protobufCreater.createPBBusinessMessage();
        JsonFormat jsonFormat = new JsonFormat();
        String asJson = jsonFormat.printToString(pbmsg);
        // System.out.print(asJson);
        InputStream in = new ByteArrayInputStream(asJson.getBytes("UTF-8"));
        PBBusinessMessage.Builder newPbMsg = PBBusinessMessage.newBuilder();
        jsonFormat.merge(in, newPbMsg);
        FileOutputStream outputStream = new FileOutputStream("C:/Users/xia/Desktop/test/data.json");
        // pbmsg.writeTo(outputStream);
        jsonFormat.print(pbmsg, outputStream);
        outputStream.close();
        
        try (FileWriter file = new FileWriter("C:/Users/xia/Desktop/test/xia.json")) {
            file.write(asJson);
            
        }
        JSONObject jsono = new JSONObject(asJson);
        try (FileWriter file = new FileWriter("C:/Users/xia/Desktop/test/xia3.json")) {
            jsono.write(file);            
        }
        
        // Gson gson2 = new GsonBuilder().setPrettyPrinting().create();
        // String prettyJson = gson2.toJson(pbmsg.toBuilder());
        // System.out.print(prettyJson);
        // try (FileWriter file = new FileWriter("C:/Users/xia/Desktop/test/xia_format.json")) {
        // file.write(prettyJson);
        // }
        
        // System.out.print(newPbMsg.toString());
        // XmlFormat xmlFormat = new XmlFormat();
        // String asXml = xmlFormat.printToString(pbmsg);
        // System.out.print(asXml);
        // PBBusinessMessage.Builder xmlPbMsg = PBBusinessMessage.newBuilder();
        // StringReader xmlIn = new StringReader(asXml);
        // char[] buffer = new char[asXml.length()];
        // xmlIn.read(buffer);
        // InputStream xmInput = new ByteArrayInputStream(new String(buffer).getBytes("UTF-8"));
        // xmlFormat.merge(xmInput, xmlPbMsg);
        // System.out.print(xmlPbMsg.toString());
        // HtmlFormat htmlFormat = new HtmlFormat();
        // String asHtml = htmlFormat.printToString(pbmsg);
        // System.out.print(asHtml);
    }
}
