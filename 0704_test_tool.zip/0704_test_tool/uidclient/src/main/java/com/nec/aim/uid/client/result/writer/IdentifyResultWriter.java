package com.nec.aim.uid.client.result.writer;

import static com.nec.aim.uid.client.common.UidClientConstants.JOB_RESULT_PATH;

import java.io.FileWriter;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.aim.uid.client.manager.UidCommonManager;

import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyResponse;

public class IdentifyResultWriter implements Runnable {
	private static Logger logger = LoggerFactory.getLogger(IdentifyResultWriter.class);
	private IdentifyResponse.Builder identifyResponse;

	public IdentifyResultWriter(IdentifyResponse.Builder iqyRes) {
		this.identifyResponse = iqyRes;
	}

	@Override
	public void run() {
		String outPutPath = UidCommonManager.getValue(JOB_RESULT_PATH);
		outPutPath = outPutPath.endsWith("/") ? outPutPath : outPutPath + "/";
		outPutPath = outPutPath + "/" + identifyResponse.getBatchJobId();
		try (FileWriter writer = new FileWriter(outPutPath)) {
			writer.write("batchJobId: " + String.valueOf(identifyResponse.getBatchJobId()));
			writer.write(System.lineSeparator());
			writer.append("type: " + String.valueOf(identifyResponse.getType()));
			writer.write(System.lineSeparator());
			PBBusinessMessage pbmsg = PBBusinessMessage.parseFrom(identifyResponse.getBusinessMessage(0));
			writer.append(pbmsg.toString());
			logger.info("success writed batchjob({}) result", identifyResponse.getBatchJobId());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
