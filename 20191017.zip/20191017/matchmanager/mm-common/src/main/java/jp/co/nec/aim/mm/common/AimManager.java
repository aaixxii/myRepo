package jp.co.nec.aim.mm.common;

import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.AsyncContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResultItem;
import jp.co.nec.aim.message.proto.BusinessMessage.PBResponse;
import jp.co.nec.aim.message.proto.ExtractService.ExtractResponse;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyResponse;


public class AimManager {
	private static Logger logger = LoggerFactory.getLogger(AimManager.class);
	private static final ConcurrentHashMap<Long, AsyncContext> inquiryJobCtxQueue = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<Long, AsyncContext> extractJobCtxQueue = new ConcurrentHashMap<>();	
	
	private static final ConcurrentHashMap<Long, Object> inquiryLockQueue = new ConcurrentHashMap<>(); 
	private static final ConcurrentHashMap<Long, Object> extractLockQueue = new ConcurrentHashMap<>(); //key is fe_job_id
	private static final ConcurrentHashMap<Long, PBMuExtractJobResultItem> extractJobResutQueue = new ConcurrentHashMap<>(); //key is fe_job_id 
	
	private static final ConcurrentHashMap<Long, IdentifyResponse> inquiryJobResutQueue = new ConcurrentHashMap<>(); //key is top_job_id 	
	

	public static ConcurrentHashMap<Long, AsyncContext> getextractJobCtxQueue() {
		return extractJobCtxQueue;
	}
	
	public static void finishInquiryJob(Long topJobId) {
		inquiryLockQueue.remove(topJobId);
		inquiryJobResutQueue.remove(topJobId);
	}
	
	public static PBMuExtractJobResultItem getExtractJobResult(Long feJobId) {
		return extractJobResutQueue.get(feJobId);
	}
	
	public static void saveToExtractJobResutQueue(Long key, PBMuExtractJobResultItem oneFejobResut) {
		extractJobResutQueue.putIfAbsent(key, oneFejobResut);		
		Object locker = extractLockQueue.get(key);
		synchronized (locker) {			
			locker.notify();
			logger.info("extract job:{} is completed. notified to AimSyncService.");
		}		
	}
	
	public static void finishExtractJob(Long extJobId) {
		extractLockQueue.remove(extJobId);
		extractJobResutQueue.remove(extJobId);
	}
	
	public static void resExtractErr(Long key, PBResponse errRes ) {
		AsyncContext extCtx = extractJobCtxQueue.get(key);
		try {
			errRes.writeTo(extCtx.getResponse().getOutputStream());
		} catch (IOException e) {
			e.printStackTrace();
			//ToDo writing error respose;
		}
		extCtx.complete();		
		
	}	
	
	public static void responseExtractJobResult(Long key, ExtractResponse result) throws IOException {
		AsyncContext extCtx = extractJobCtxQueue.get(key);
		result.writeTo(extCtx.getResponse().getOutputStream());
		logger.info("sucess respose to client, batchJobId:{}, feJobId:{}", result.getBatchJobId(), key);
		extCtx.complete();				
	}
	
	public static void responseInquiyJobResult(Long key, IdentifyResponse result) {
		AsyncContext extCtx = inquiryJobCtxQueue.get(key);
		try {
			result.writeTo(extCtx.getResponse().getOutputStream());
		} catch (IOException e) {
			e.printStackTrace();
			//ToDo writing error respose;
		}
		extCtx.complete();		
	}
	
	public static void addToInquiryJobCtxQueue(Long jobId,  AsyncContext ctx ) {		
		inquiryJobCtxQueue.putIfAbsent(jobId, ctx);
	}
	
	
	public static AsyncContext getInquiryAsncCtxToRespose(Long jobId) {
		return inquiryJobCtxQueue.get(jobId);		
	}
	
	public static void addToExtractJobCtxQueue(Long jobId,  AsyncContext ctx ) {		
		extractJobCtxQueue.putIfAbsent(jobId, ctx);
	}
	
	public static AsyncContext getExtractAsncCtxToRespose(Long jobId) {
		return extractJobCtxQueue.get(jobId);		
	}	

}
