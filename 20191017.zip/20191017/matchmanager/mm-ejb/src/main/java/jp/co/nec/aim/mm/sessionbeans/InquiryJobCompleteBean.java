package jp.co.nec.aim.mm.sessionbeans;

import java.util.Objects;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.message.proto.AIMMessages.PBInquiryJobInfoInternal;
import jp.co.nec.aim.message.proto.AIMMessages.PBMapInquiryJobResult;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBResponseAttribute;
import jp.co.nec.aim.mm.aggregator.Aggregator;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.dao.AggregatorDao;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.dao.UnitDao;
import jp.co.nec.aim.mm.entities.MapReducerEntity;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.exception.ExceptionHelper;
import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.sessionbeans.pojo.AimServiceState;
import jp.co.nec.aim.mm.sessionbeans.pojo.InquiryJobHandler;
import jp.co.nec.aim.mm.util.StopWatch;

/**
 * 
 * @author jinxl
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class InquiryJobCompleteBean {

	private static Logger log = LoggerFactory
			.getLogger(InquiryJobCompleteBean.class);

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;
	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource ds;

	private InquiryJobHandler handler;
	private UnitDao unitdao;
	private ExceptionHelper exception;
	private InquiryJobDao inquiryJobDao;
	private AggregatorDao aggregatorDao;
	@EJB
	private Aggregator aggregator;

	@PostConstruct
	public void init() {
		unitdao = new UnitDao(manager);
		inquiryJobDao = new InquiryJobDao(manager);
		aggregatorDao = new AggregatorDao(ds);
		handler = new InquiryJobHandler(manager, ds, aggregator);
		exception = new ExceptionHelper(new DateDao(ds));
	}

	/**
	 * completeJob
	 * 
	 * @param mapInquiryJobResult
	 */
	public void completeJob(PBMapInquiryJobResult mapInquiryJobResult) {
		if (mapInquiryJobResult.hasResult() && mapInquiryJobResult.getResult().hasResponse()) {
			if (!mapInquiryJobResult.getResult().getResponse().getStatus().toLowerCase().equals("0")
					&& Objects.isNull(mapInquiryJobResult.getResult().getResponse().getErrorMessage())) {
				exception.throwArgException(AimError.INQ_JOB_RESULT_ERR);			
			}	
		}
	

		StopWatch sw = new StopWatch();
		sw.start();
		try {
			long mrId = mapInquiryJobResult.getMrId();
			MapReducerEntity mrUnit = unitdao
					.findAndWarnState(mrId, "complete");
			if (mrUnit == null) {
				return;
			} else {
				updateInquiryJobs(mapInquiryJobResult);
			}
		} catch (Exception e) {
			throw new AimRuntimeException(e.getMessage(), e);
		} finally {
			sw.stop();
			PerformanceLogger.log(getClass().getSimpleName(), "completeJob",
					sw.elapsedTime());

		}
	}

	/**
	 * updateInquiryJobs
	 * 
	 * @param jobResult
	 */
	private void updateInquiryJobs(PBMapInquiryJobResult jobResult) {
		StopWatch sw = new StopWatch();
		sw.start();

		PBInquiryJobInfoInternal jobInfo = jobResult.getJobInfo();
		PBBusinessMessage topJobResult = jobResult.getResult();
		/* get container job Id */
		long planId = jobResult.getPlanId();
		Long containerJobId = inquiryJobDao.getContainerJobId(planId);
		if (containerJobId == null) {
			log.warn("Container job id could not be found with plan id: {}.",
					planId);
			return;
		}

		/* get MR Id */
		long mrId = jobResult.getMrId();

		/* get Top Level Job ID */
		long topleveljobId = jobInfo.getTopLevelJobId();

		Long segmentId = null;	
		String description = null;

		//PBServiceState serviceState = result.getServiceState();
		//ServiceStateType state = serviceState.getState();		
		
			String resposeStatus = topJobResult.getResponse().getStatus().toLowerCase();
			if (resposeStatus.toLowerCase().equals("0")) {
				log.info(
						"Ready to complete container job when state is success. "
								+ "MrId:{}, JobId:{}, ContainerJobId:{}, PlanId:{}, MessageSequence:{}",
						new Object[] { mrId, topleveljobId, containerJobId, planId,
								jobInfo.getMessageSequence() });
				/* complete Container Job */
				boolean bUpdate = completeContainerJob(topleveljobId,
						jobInfo.getMessageSequence(), containerJobId, topJobResult, mrId);
				if (bUpdate) {
					doAggregation(topleveljobId);
				}
			} else {
				log.warn(
						"Ready to fail Inquiry Job when state is error. "
								+ "MrId:{}, JobId:{}, ContainerJobId:{}, PlanId:{}, MessageSequence:{}",
						new Object[] { mrId, topleveljobId, containerJobId, planId,
								jobInfo.getMessageSequence() });
				String errMsg = null;
				if (topJobResult.hasResponse() && topJobResult.getResponse().hasErrorMessage()) {
					errMsg = topJobResult.getResponse().getErrorMessage();
				}	
				PBResponseAttribute responeAttr = null;
				if (topJobResult.hasResponse() && topJobResult.getResponse().getResponseAttributesCount() > 0) {
					responeAttr = topJobResult.getResponse().getResponseAttributesList().get(0);
				}	

				if (Objects.isNull(errMsg)) {
					log.warn("job service state is error, but error message is not existed.");
					return;
				}
				
				if (Objects.isNull(responeAttr)) {
					log.warn("job service state is error, but error messsage created timestamp is not existed.");
					return;
				}
				
				AimServiceState aimServiceState = new AimServiceState(errMsg, resposeStatus, responeAttr.getAttributeValue());
				log.info("errmessage:{}, errCode:{}, falieTime:{}", errMsg, resposeStatus, responeAttr.getAttributeValue());				

				log.warn(
						"CONTAINER_JOB_ID:{}(MR_ID:{}) in JOB_ID:{} failed. Reason = {}",
						containerJobId, mrId, topleveljobId, description);

				handler.failInquiryJob(containerJobId, segmentId, aimServiceState,
						topJobResult.toByteArray(), true);			
			}
	
		sw.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "updateInquiryJobs",
				sw.elapsedTime());
	}

	/**
	 * completeContainerJob
	 * 
	 * @param jobId
	 * @param messageSequence
	 * @param containerJobId
	 * @param inquiryJobResultInternal
	 * @param mrId
	 * @return
	 */
	private boolean completeContainerJob(long jobId, int messageSequence,
			long containerJobId,
			PBBusinessMessage topjobResult, long mrId) {

		/* Serialization */
		byte[] result = topjobResult.toByteArray();
		/* call updateJobResult */
		long remainJobs = aggregatorDao.updateJobResult(jobId, messageSequence,
				containerJobId, result);
		boolean bUpdate = false;
		/* remain_jobs is zero */
		if (remainJobs == 0) {
			bUpdate = true;
		} else if (remainJobs > 0) {
			if (log.isDebugEnabled()) {
				log.debug("RemainJobs for JOB_ID: " + jobId + " (MR_ID: "
						+ mrId + ") is " + remainJobs);
			}
		} else if (remainJobs == -1) {
			log.warn("JOB_ID: " + jobId + " (MR_ID: " + mrId
					+ ") JOB_STATE != WORKING or REMAIN_JOBS <= 0");
		} else if (remainJobs == -2) {
			log.warn("JOB_ID: " + jobId + " (MR_ID: " + mrId
					+ ") Sequence != FAILURE_COUNT, do nothing");
		} else if (remainJobs == -3) {
			log.warn("JOB_ID: " + jobId + " (MR_ID: " + mrId
					+ ") is not WORKING");
		} else if (remainJobs == -4) {
			log.warn("JOB_ID: " + jobId + " (MR_ID: " + mrId
					+ ") Could't get lock");
		} else {
			log.warn("Returned remainJobs: " + remainJobs + " for MR_ID: "
					+ mrId + ", it's not supported");
		}

		return bUpdate;
	}

	/**
	 * doAggregation
	 * 
	 * @param topLevelJobId
	 */
	private void doAggregation(long topLevelJobId) {
		aggregator.doAggregation(topLevelJobId);
	}
}
