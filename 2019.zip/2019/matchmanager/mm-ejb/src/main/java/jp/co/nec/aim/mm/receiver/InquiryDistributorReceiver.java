package jp.co.nec.aim.mm.receiver;

import java.util.Map;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.EJB;
import javax.ejb.MessageDriven;
import javax.jms.BytesMessage;
import javax.jms.Message;
import javax.jms.MessageListener;

import jp.co.nec.aim.mm.constants.JNDIConstants;
import jp.co.nec.aim.mm.exception.EventException;
import jp.co.nec.aim.mm.identify.dispatch.InquiryDispatcher;
import jp.co.nec.aim.mm.identify.planner.CompressUtil;
import jp.co.nec.aim.mm.identify.planner.MuJobExecutePlan;
import jp.co.nec.aim.mm.util.CollectionsUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@MessageDriven(activationConfig = {
		@ActivationConfigProperty(propertyName = "acknowledgeMode", propertyValue = "Auto-acknowledge"),
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
		@ActivationConfigProperty(propertyName = "destination", propertyValue = JNDIConstants.INQUIRY_JOB_DISPATCH_QUEUE) })
public class InquiryDistributorReceiver implements MessageListener {

	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(InquiryDistributorReceiver.class);

	@EJB
	private InquiryDispatcher distributor;

	/**
	 * onMessage
	 */
	public void onMessage(Message message) {
		try {
			if (message instanceof BytesMessage) {
				BytesMessage bMessage = (BytesMessage) message;
				long length = bMessage.getBodyLength();
				if (length <= 0) {
					log.error("BytesMessage bytes is empty when receive event "
							+ "from inquiry planner, message id: {}",
							bMessage.getJMSMessageID());
					return;
				}

				final byte[] bytes = new byte[(int) length];
				bMessage.readBytes(bytes);

				final CompressUtil util = new CompressUtil();
				Map<Long, MuJobExecutePlan> plans = util
						.unzipCompressWithPlanId(bytes);

				if (message.getJMSRedelivered()) {
					log.warn(
							"This InquiryDistributor MDB message"
									+ " was redelivered, plansId: {}, jobIds: {}.. ",
							(CollectionsUtil.isEmpty(plans)) ? "UNKNOWN"
									: CollectionsUtil.extractToString(
											plans.values(), "planId", ","),
							CollectionsUtil.extractToString(plans.values(),
									"jobId", ","));
				}

				distributor.dispatch(plans);
			} else {
				log.warn("message is not the instance of BytesMessage..");
			}
		} catch (Exception e) {
			throw new EventException(e);
		}
	}
}
