package jp.co.nec.aim.mm.validator;

import static jp.co.nec.aim.mm.constants.AimError.ENROLL_BATCH_TYPE_MISS_MATCH;
import static jp.co.nec.aim.mm.constants.AimError.PROTOBUF_ERROR;
import static jp.co.nec.aim.mm.constants.AimError.SYNC_FUNCTIONTYPE;

import java.util.List;
import java.util.Objects;

import javax.persistence.EntityManager;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.InvalidProtocolBufferException;

import jp.co.nec.aim.message.proto.BatchTypeProto.BatchType;
import jp.co.nec.aim.message.proto.BusinessMessage.E_REQUESET_TYPE;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequest;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyRequest;
import jp.co.nec.aim.message.proto.SyncService.SyncRequest;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.FEJobDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.dao.UniqueKeyCheckDao;
import jp.co.nec.aim.mm.entities.BatchJobInfoEntity;
import jp.co.nec.aim.mm.exception.ArgumentException;
import jp.co.nec.aim.mm.exception.ExceptionHelper;

/**
 * Validate the Accept protoBuffer Object from client
 * 
 * @author liuyq
 * 
 */
public final class AcceptorValidator {

	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(AcceptorValidator.class);

	/** Extract job DAO **/
	private FEJobDao feJobDao;
	/** SystemConfig DAO **/
	private SystemConfigDao confDao;	
	private UniqueKeyCheckDao uniqueKeyCheckDao;
	/** ExceptionHelper instance **/
	private ExceptionHelper exception;
	

	/**
	 * AcceptorValidator constructor
	 * 
	 * @param EntityManager
	 */
	public AcceptorValidator(EntityManager em, DataSource dataSource) {
		this.feJobDao = new FEJobDao(em);
		this.confDao = new SystemConfigDao(em);		
		this.uniqueKeyCheckDao = new UniqueKeyCheckDao(em);
		this.exception = new ExceptionHelper(new DateDao(dataSource));
		
	}	
	

	/**
	 * check the inquiry instance PBInquiryJobRequest, if any argument logic
	 * exception occurred, throw the argument exception, servLet will response
	 * the aim error code and message to client.
	 * 
	 * @param request
	 *            PBInquiryJobRequest instance
	 * @return PBInquiryJobRequest.Builder Builder instance
	 */
	public PBBusinessMessage checkInquiryJobRequest(
			final IdentifyRequest request) {		
		long batchJobId = request.getBatchJobId();	
		List<BatchJobInfoEntity> existBatchJobList = uniqueKeyCheckDao.checkBatchJobId(batchJobId, BatchType.IDENTIFY.name());
		if (!Objects.isNull(existBatchJobList) || existBatchJobList.size() > 0 ) {
			exception.throwArgException(AimError.INQ_BATCH_JOB_ID_DUPLICATE); 
		}
		
		BatchType batchType = request.getType();
		if (batchType.ordinal() != 1) {
			exception.throwArgException(AimError.INQ_BATCH_TYPE_MISS_MATCH);
		}		
		PBBusinessMessage pbMes = null;
		try {
			pbMes = PBBusinessMessage.parseFrom(request.getBusinessMessageList().get(0).toByteArray());
		} catch (InvalidProtocolBufferException e1) {
			// TODO Auto-generated catch block
			exception.throwArgException(PROTOBUF_ERROR);
		}
		List<BatchJobInfoEntity> existRequstIdList  = uniqueKeyCheckDao.checkRequestId(pbMes.getRequest().getRequestId(), BatchType.IDENTIFY.name());
		if (!Objects.isNull(existRequstIdList) || existRequstIdList.size() > 0 ) {
			exception.throwArgException(AimError.INQ_REQUST_ID_DUPLICATE); 
		}
		
		E_REQUESET_TYPE reqType = pbMes.getRequest().getRequestType();
		if (reqType.ordinal() != 3 || reqType.ordinal() !=4){
			exception.throwArgException(AimError.INQ_E_REQUESET_TYPE_MISS); 
		}
		if (reqType.ordinal() == 4) {
			try {
				if (Objects.isNull(pbMes.getRequest().getBiometricsData().getBiometricElement().getTemplateInfo().getReferenceId())) {
					exception.throwArgException(AimError.INQ_REQUST_REF_ID_NOT_FOUND);
				}
			} catch (Exception e) {
				exception.throwArgException(AimError.INQ_REQUST_REF_ID_NOT_FOUND);
			}
		}
		
		if (reqType.ordinal() == 3) {
			try {
				if (pbMes.getRequest().getBiometricsData().getBiometricElement().getTemplateInfo().getData() == null ){
					exception.throwArgException(AimError.INQ_REQUST_DATA_NOT_FOUND);
				}
			} catch (Exception e) {
				exception.throwArgException(AimError.INQ_REQUST_DATA_NOT_FOUND);
			}			
		}
		try {
			if (Long.valueOf(pbMes.getRequest().getMaxResults()) == null) {
				exception.throwArgException(AimError.INQ_REQUST_MAX_RESULTS_NOT_FOUND); 
			}
			
		} catch (Exception e) {
			exception.throwArgException(AimError.INQ_REQUST_MAX_RESULTS_NOT_FOUND);
		}	
		
		return pbMes;

	}
	


	/**
	 * check the PBSyncJobRequest instance
	 * 
	 * @param request
	 * @return is check passed
	 * @throws ArgumentException
	 *             SERVLET will receive this exception and response bad request
	 */
	public PBBusinessMessage checkSyncJobRequest(
			final SyncRequest request) throws ArgumentException {
		long batchJobId = request.getBatchJobId();	
		List<BatchJobInfoEntity> existBatchJobList = uniqueKeyCheckDao.checkBatchJobId(batchJobId, BatchType.ENROLL.name());
		if (!Objects.isNull(existBatchJobList) || existBatchJobList.size() > 0 ) {
			exception.throwArgException(AimError.ENROLL_BATCH_JOB_ID_DUPLICATE); 
		}
		BatchType syncType = request.getType();		
		if (syncType.ordinal() != 0) {
			exception.throwArgException(ENROLL_BATCH_TYPE_MISS_MATCH); 
		}
		
		PBBusinessMessage pbm = null;
		try {
			pbm = PBBusinessMessage.parseFrom(request.getBusinessMessage(0));
		} catch (InvalidProtocolBufferException e1) {
			exception.throwArgException(PROTOBUF_ERROR);
		}	
		
		List<BatchJobInfoEntity> existRequstIdList  = uniqueKeyCheckDao.checkRequestId(pbm.getRequest().getRequestId(), BatchType.ENROLL.name());
		if (!Objects.isNull(existRequstIdList) || existRequstIdList.size() > 0 ) {
			exception.throwArgException(AimError.ENROLL_REQUST_ID_DUPLICATE); 
		}
		
		
		PBRequest syncReq = pbm.getRequest();
		E_REQUESET_TYPE insertType = syncReq.getRequestType();
		if (insertType.ordinal() != 1 || insertType.ordinal() != 2 || insertType.ordinal() != 12) {
			exception.throwArgException(AimError.ENROLL_E_REQUESET_TYPE_MISS); 
		}
		
		if (insertType.ordinal() == 1 ) {
			if (syncReq.getRequestType() != E_REQUESET_TYPE.INSERT_REFID_DEFAULT) {
				exception.throwArgException(AimError.ENROLL_E_REQUESET_TYPE_MISS);
			}
			try {
				if (Objects.isNull(syncReq.getBiometricsData().getBiometricElement().getTemplateInfo().getReferenceId()) ) {
					exception.throwArgException(AimError.ENROLL_REQUST_REF_ID_NOT_FOUND);
				}
			} catch (Exception e) {
				exception.throwArgException(AimError.ENROLL_REQUST_REF_ID_NOT_FOUND);
			}
		}
		
		if (insertType.ordinal() == 2 ) {
			if (syncReq.getRequestType() != E_REQUESET_TYPE.INSERT_REFURL_DEFAULT) {
				exception.throwArgException(SYNC_FUNCTIONTYPE);
			}
			try {
				if (Objects.isNull(syncReq.getBiometricsData().getBiometricElement().getFilePath())) {
					exception.throwArgException(AimError.ENROLL_E_REQUESET_TYPE_MISS);
				}						
			} catch (Exception e) {
				exception.throwArgException(AimError.ENROLL_E_REQUESET_TYPE_MISS);
			}			
		}	
		
		if (insertType.ordinal() == 12 ) {
			if (syncReq.getRequestType() != E_REQUESET_TYPE.DELETE_REFID) {
				exception.throwArgException(AimError.ENROLL_E_REQUESET_TYPE_MISS );
			}
			try {
				if (Objects.isNull(syncReq.getEnrollmentId())) {
					exception.throwArgException(AimError.ENROLL_REQUST_REF_ID_NOT_FOUND );
				}						
			} catch (Exception e) {
				exception.throwArgException(AimError.ENROLL_REQUST_REF_ID_NOT_FOUND ); 
			}			
		}
		return pbm;
	}

	
	
	

}
