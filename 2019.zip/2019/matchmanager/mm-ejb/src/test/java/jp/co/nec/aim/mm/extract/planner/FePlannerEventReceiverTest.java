package jp.co.nec.aim.mm.extract.planner;

import javax.annotation.Resource;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import jp.co.nec.aim.mm.constants.JNDIConstants;
import jp.co.nec.aim.mm.receiver.FePlannerEventReceiver;
import mockit.Mock;
import mockit.MockUp;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.Message;
import org.apache.activemq.broker.BrokerService;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class FePlannerEventReceiverTest {
	private BrokerService broker = null;
	private String jmsURL = "tcp://localhost:61616";
	private String plannerQueue = JNDIConstants.EXTRACT_JOB_PLANNER_QUEUE;
	private String mesgToFePlanner = "Please create extract job plan for mus";
	@Resource
	private FePlannerEventReceiver receiver;

	@Before
	public void setUp() throws Exception {
		System.setProperty("com.sun.management.jmxremote.port", "9990");
		System.setProperty("com.sun.management.jmxremote.local.only", "false");
		System.setProperty("com.sun.management.jmxremote.authenticate", "false");
		System.setProperty("com.sun.management.jmxremote.ssl", "false");

		broker = new BrokerService();
		broker.setBrokerName("AIM_JMS_SERVER");
		broker.addConnector(jmsURL);
		broker.setPersistent(false);
		broker.start();
		send(mesgToFePlanner);
	}

	public void send(String msg) throws JMSException {
		ConnectionFactory factory = new ActiveMQConnectionFactory(jmsURL);
		Connection connection = factory.createConnection();
		connection.start();
		final Session session = connection.createSession(false,
				Session.AUTO_ACKNOWLEDGE);
		Destination queue = session.createQueue(plannerQueue);
		MessageProducer producer = session.createProducer(queue);
		TextMessage message = session.createTextMessage(msg);
		producer.send(message);
		connection.close();
	}

	@After
	public void tearDown() throws Exception {
		broker.stop();
	}

	@Test
	public void testOnMessage() throws JMSException {
		new MockUp<FEPlannerManager>() {
			@Mock
			public void makeFEPlans() {
				return;
			}
		};
		ConnectionFactory factory = new ActiveMQConnectionFactory(jmsURL);
		Connection connection = factory.createConnection();
		connection.start();
		final Session session = connection.createSession(false,
				Session.AUTO_ACKNOWLEDGE);
		Destination queue = session.createQueue(plannerQueue);
		MessageConsumer consumer = session.createConsumer(queue);
		consumer.setMessageListener(receiver);
		Message rcvMessage = (Message) consumer.receive();
		TextMessage txtMsg = (TextMessage) rcvMessage;
		Assert.assertEquals(mesgToFePlanner, txtMsg.getText());
	}

}
