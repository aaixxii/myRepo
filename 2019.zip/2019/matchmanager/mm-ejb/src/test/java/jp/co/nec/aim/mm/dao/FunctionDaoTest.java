package jp.co.nec.aim.mm.dao;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.entities.FunctionTypeEntity;
import jp.co.nec.aim.mm.entities.QueueType;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()
@Transactional
public class FunctionDaoTest extends
		AbstractTransactionalJUnit4SpringContextTests {
	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;
	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;

	@Before
	public void setUp() {
	}

	@After
	public void tearDown() {
	}

	@Test
	public void testGetFunction() {
		FunctionDao functionDao = new FunctionDao(entityManager);
		FunctionTypeEntity funtionType = functionDao.getFunction(1);
		Assert.assertEquals(1, funtionType.getId());
		Assert.assertEquals("TI", funtionType.getFunctionName());
		Assert.assertEquals(QueueType.INQUIRY, funtionType.getType());
	}

	@Test
	public void testGetExtractFunction() {
		FunctionDao functionDao = new FunctionDao(entityManager);
		FunctionTypeEntity funtionType = functionDao.getExtractFunction();
		Assert.assertEquals(17, funtionType.getId());
		Assert.assertEquals(QueueType.EXTRACT, funtionType.getType());
	}

	@Test
	public void testGetFunctionByName() {
		FunctionDao functionDao = new FunctionDao(entityManager);
		FunctionTypeEntity funtionType = functionDao
				.getFunctionByName("EXTRACTION");
		Assert.assertEquals(17, funtionType.getId());
	}

	@Test
	public void testGetSearchFunctions() {
		FunctionDao functionDao = new FunctionDao(entityManager);
		List<FunctionTypeEntity> funtionList = functionDao.getSearchFunctions();
		Assert.assertEquals(19, funtionList.size());
		int[] ids = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 10, 11, 18, 19, 20, 21,
				22, 23, 24, 25, 26 };
		for (int i = 0; i < funtionList.size(); i++) {
			FunctionTypeEntity funtionType = funtionList.get(i);
			Assert.assertEquals(ids[i], funtionType.getId());
			Assert.assertEquals(QueueType.INQUIRY, funtionType.getType());
		}
	}

	@Test
	public void testGetExtractTimeouts() {
		FunctionDao functionDao = new FunctionDao(entityManager);
		int timeouts = functionDao.getExtractTimeouts();
		Assert.assertEquals(240000, timeouts);
	}
}
