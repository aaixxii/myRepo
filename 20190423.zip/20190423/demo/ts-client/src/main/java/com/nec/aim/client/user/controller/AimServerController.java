package com.nec.aim.client.user.controller;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import lombok.extern.slf4j.Slf4j;

@RequestMapping("/client")
@RestController
@Slf4j
public class AimServerController {

	@Autowired
	private RestTemplate restTemplate;
	
	private static final String url1 = "http://localhost:8000/serverStatus/";
	private static final String url2 = "http://localhost:8001/serverStatus/";

	private static final AtomicBoolean usedFirst = new AtomicBoolean(false);
	private final ReentrantLock lock = new ReentrantLock();

	@HystrixCommand(fallbackMethod = "getAimServerStatusFallback")
	@GetMapping("/serverStatus")
	public String getAimServerStatus() {
		String serverInfo = null;
		lock.lock();
		try {
			if (!usedFirst.get()) {
				serverInfo = this.restTemplate.getForObject(url1, String.class);
				usedFirst.set(true);
			} else {
				serverInfo = this.restTemplate.getForObject(url2 , String.class);
				usedFirst.set(false);
			}

		} finally {
			lock.unlock();
		}
		//String serverInfo = this.restTemplate.getForObject("http://Server-Provider/serverStatus", String.class);
		log.info(serverInfo);
		return serverInfo;
	}

	public String getAimServerStatusFallback(Throwable throwable) {
		log.error("Fallback called ", throwable);
		return "Localhost status is unknown.";
	}
}
