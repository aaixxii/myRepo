package jp.co.nec.aim.mm.acceptor.service;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.AIMMessages.PBExtractJobResultInternal;
import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPrintType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ImagePositionType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.JobStateType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.TemplateFormatType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplate;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateIndexer;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractOutputPayload;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobBinaryRequest;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobBinaryResponse;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobBinaryResponse.Builder;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobRequest;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobResponse;
import jp.co.nec.aim.message.proto.ExtractService.PBExtractJobResult;
import jp.co.nec.aim.message.proto.JobCommonService.PBDeleteJobRequest;
import jp.co.nec.aim.message.proto.JobCommonService.PBJobResultRequest;
import jp.co.nec.aim.message.proto.JobCommonService.PBJobStatusRequest;
import jp.co.nec.aim.message.proto.JobCommonService.PBJobStatusResponse;
import jp.co.nec.aim.message.proto.JobCommonService.PBListJobIdsResponse;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.CallbackStyle;
import jp.co.nec.aim.mm.constants.JobState;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.FEJobDao;
import jp.co.nec.aim.mm.dao.FunctionDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.entities.FeJobPayloadEntity;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.entities.FeResultEntity;
import jp.co.nec.aim.mm.entities.FunctionTypeEntity;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.exception.ExceptionHelper;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.jms.NotifierEnum;
import jp.co.nec.aim.mm.util.CollectionsUtil;
import jp.co.nec.aim.mm.util.Deflater;
import jp.co.nec.aim.mm.util.PBStateUtil;
import jp.co.nec.aim.mm.validator.AcceptorValidator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Sets;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;

/**
 * AimExtractService <br>
 * The main work flow of Extract <br>
 * 
 * Include following public method:
 * <p>
 * extract, getJobStatus, listJobIds, deleteJob clearJobs, getJobBinary,
 * getJobResult
 * <p>
 * 
 * @author liuyq
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AimExtractService {
	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(AimInquiryService.class);

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;

	@Resource(mappedName = "java:jboss/OracleDS")
	private DataSource dataSource;
	private FunctionDao functionDao;
	private SystemConfigDao configDao;
	private FEJobDao feJobDao;
	private AcceptorValidator validator;
	private DateDao dateDao;
	private ExceptionHelper exception;

	/**
	 * AimExtractService constructor
	 */
	public AimExtractService() {
	}

	@PostConstruct
	private void init() {
		functionDao = new FunctionDao(manager);
		configDao = new SystemConfigDao(manager);
		feJobDao = new FEJobDao(manager);
		validator = new AcceptorValidator(manager, dataSource);
		dateDao = new DateDao(dataSource);
		exception = new ExceptionHelper(dateDao);
	}

	/**
	 * the main work flow of extract
	 * 
	 * @param request
	 *            PBExtractJobRequest instance
	 * @return PBExtractJobResponse instance
	 */
	public PBExtractJobResponse extract(PBExtractJobRequest request,
			boolean isFromServlet) {
		// check priority and callback URL
		validator.checkPBExtractJobRequest(request);

		final FeJobQueueEntity ejq = new FeJobQueueEntity();
		FunctionTypeEntity fte = functionDao.getExtractFunction();
		if (fte == null) {
			throw new AimRuntimeException(
					"Extract function not registered in the database.");
		}
		ejq.setFunctionId((int) fte.getId());
		ejq.setStatus(JobState.QUEUED);
		ejq.setFailureCount(0l);

		Integer priority = (request.hasPriority()) ? request.getPriority()
				: configDao
						.getMMPropertyInt(MMConfigProperty.EXTRACT_DEFAULTS_PRIORITY);
		ejq.setPriority(priority);
		if (request.hasCallBackUrl()) {
			ejq.setCallbackUrl(request.getCallBackUrl());
		}
		ejq.setSubmissionTs(dateDao.getCurrentTimeMS());
		ejq.setCallbackStyle(isFromServlet ? CallbackStyle.PROTOBUF
				: CallbackStyle.XML);
		manager.persist(ejq);

		FeJobPayloadEntity epe = new FeJobPayloadEntity();

		epe.setPayload(request.toByteArray());
		epe.setJobId(ejq.getId());
		manager.persist(epe);
		// manager.flush();

		PBExtractJobResponse.Builder b = PBExtractJobResponse.newBuilder();
		b.setJobId(ejq.getId());
		b.setServiceState(PBStateUtil.creatSuccessState());

		// send event to extract planner
		JmsSender.getInstance().sendToFEJobPlanner(NotifierEnum.ExtractService,
				String.format("create extract job id: %s", b.getJobId()));

		return b.build();
	}

	/**
	 * get inquiry Job Status
	 * 
	 * @param request
	 *            PBJobStatusRequest instance
	 * @return PBJobStatusResponse instance
	 */
	public PBJobStatusResponse getJobStatus(PBJobStatusRequest request) {
		PBJobStatusResponse.Builder b = PBJobStatusResponse.newBuilder();
		long jobId = request.getJobId();

		FeJobQueueEntity feJob = null;
		try {
			feJob = feJobDao.findFeJob(jobId);
		} catch (Exception ex) {
			exception.throwDBException(AimError.EXTRACT_DB, ex, String.format(
					"Exception occurred when find extract job by job id %s",
					jobId));
		}

		if (feJob == null) {
			final String error = String.format(
					"Can not find extract job by job id %s", jobId);
			log.error(error);			
			exception.throwArgException(AimError.MISS_JOBID_ERROR, error, jobId);	
		}

		b.setJobId(jobId);
		JobState jobState = feJob.getStatus();
		switch (jobState) {
		case QUEUED:
			b.setJobState(JobStateType.JOB_STATE_QUEUED);
			break;
		case WORKING:
			b.setJobState(JobStateType.JOB_STATE_WORKING);
			break;
		case DONE:
			b.setJobState(JobStateType.JOB_STATE_DONE);
			break;
		default:
			throw new AimRuntimeException("jobState:" + jobState.name()
					+ " is not support..");
		}
		b.setJobFailed(feJob.getFailedFlag() == null ? false : feJob
				.getFailedFlag());
		b.setServiceState(PBStateUtil.creatSuccessState());
		return b.build();
	}

	/**
	 * list extract JobIds
	 * 
	 * @return PBListJobIdsResponse instance
	 */
	public PBListJobIdsResponse listJobIds() {
		PBListJobIdsResponse.Builder b = PBListJobIdsResponse.newBuilder();
		List<Long> jobIds = null;
		try {
			jobIds = feJobDao.listAllJobIds();
		} catch (Exception ex) {
			exception.throwDBException(AimError.EXTRACT_DB, ex,
					"Exception occurred when list extract job ids");
		}

		if (CollectionsUtil.isNotEmpty(jobIds)) {
			b.addAllJobId(jobIds);
		}		
		b.setServiceState(PBStateUtil.creatSuccessState());
		return b.build();
	}

	/**
	 * delete extract Job with specified job id
	 * 
	 * @param request
	 *            PBDeleteJobRequest instance
	 */
	public void deleteJob(PBDeleteJobRequest request) {
		try {
			feJobDao.deleteExtractJob(request.getJobId());
		} catch (Exception ex) {
			exception.throwDBException(AimError.EXTRACT_DB, ex,
					"Exception occurred when delete extract job.");
		}
	}

	/**
	 * clear all extract Jobs
	 */
	public void clearJobs() {
		try {
			feJobDao.clearJobs();
		} catch (Exception ex) {
			exception.throwDBException(AimError.EXTRACT_DB, ex,
					"Exception occurred when clear extract job.");
		}
	}

	/**
	 * get extract Job Binary result
	 * 
	 * @param request
	 *            PBExtractJobBinaryRequest instance
	 * @return PBExtractJobBinaryResponse instance
	 */
	public PBExtractJobBinaryResponse getJobBinary(
			PBExtractJobBinaryRequest request) {
		PBExtractJobBinaryResponse.Builder b = PBExtractJobBinaryResponse
				.newBuilder();
		long jobId = request.getJobId();
		b.setJobId(jobId);

		// if only job id is specified
		if (request.getKeyedTemplateCount() <= 0) {
			List<FeResultEntity> results = feJobDao.getFeResult(jobId);
			// could not find feResult with only job id
			if (CollectionsUtil.isEmpty(results)) {
				throwFeResultNoFoundException();
			} else {
				setKeyedTemplate(b, results);
				b.setServiceState(PBStateUtil.creatSuccessState());
				return b.build();
			}
		}

		List<PBKeyedTemplate> keyList = request.getKeyedTemplateList();
		for (final PBKeyedTemplate t : keyList) {
			PBKeyedTemplate.Builder builder = PBKeyedTemplate.newBuilder();
			if (!t.hasKey() && t.hasIndexer()) {
				final String error = "Indexr has specified but key not specified..";
				log.error(error);				
				throw new IllegalArgumentException(error);
			}

			try {
				// both key and indexer are not specified
				if (!t.hasKey() && !t.hasIndexer()) {
					List<FeResultEntity> retsWithId = feJobDao
							.getFeResult(jobId);
					setKeyedTemplate(b, retsWithId);
					continue;
				} else if (t.hasKey() && !t.hasIndexer()) {
					// key is specified and indexer not specified
					List<FeResultEntity> retsWithIdKey = feJobDao.getFeResult(
							jobId, t.getKey().name());
					setKeyedTemplate(b, retsWithIdKey);
					builder.setKey(t.getKey());
					continue;
				} else if (t.hasKey() && t.hasIndexer()) {
					// both key and indexer are specified
					int templateIndex = confirmTemplateIndex(t);
					FeResultEntity result = feJobDao.getFeResult(jobId, t
							.getKey().name(), templateIndex);
					builder.setKey(t.getKey());
					builder.setIndexer(t.getIndexer());
					builder.setTemplateBinary(ByteString.copyFrom(result
							.getResultData()));
					b.addKeyedTemplate(builder);
				}
			} catch (Exception ex) {
				exception.throwDBException(AimError.EXTRACT_TEMPLATE_NOT_FOUND,
						ex, ex.getMessage());
			}
		}

		if (b.getKeyedTemplateCount() <= 0) {
			throwFeResultNoFoundException();
		}

		b.setServiceState(PBStateUtil.creatSuccessState());
		return b.build();
	}

	/**
	 * throwFeResultNoFoundException
	 */
	private void throwFeResultNoFoundException() {
		final String error = "Extract result was not found in [FE_RESULT].";
		log.error(error);
		throw new AimRuntimeException(error);
	}

	/**
	 * confirm the TemplateIndex
	 * 
	 * @param t
	 * @return
	 */
	private int confirmTemplateIndex(final PBKeyedTemplate t) {
		PBKeyedTemplateIndexer indexr = t.getIndexer();
		int templateIndex = 0;
		if (indexr.hasFingerPrintType()) {
			templateIndex = indexr.getFingerPrintType().getNumber();
		} else if (indexr.hasPosition()) {
			templateIndex = indexr.getPosition().getNumber();
		} else if (indexr.hasIndex()) {
			templateIndex = indexr.getIndex();
		}
		return templateIndex;
	}

	/**
	 * setResponseWithjobId
	 * 
	 * @param b
	 *            Builder
	 * @param jobId
	 *            jobId
	 */
	private void setKeyedTemplate(Builder b, List<FeResultEntity> results) {
		if (CollectionsUtil.isNotEmpty(results)) {
			for (FeResultEntity feResultEntity : results) {
				PBKeyedTemplate.Builder builder = PBKeyedTemplate.newBuilder();
				builder.setTemplateBinary(ByteString.copyFrom(feResultEntity
						.getResultData()));
				TemplateFormatType key = null;
				try {
					key = TemplateFormatType.valueOf(feResultEntity
							.getTemplateKey());
				} catch (Exception e) {
					exception.throwArgException(
							AimError.EXTRACT_RESULT_TEMPLATE_KEY,
							feResultEntity.getTemplateKey());
				}
				builder.setKey(key);
				int index = feResultEntity.getTemplateIndex();
				if (index != 0) {
					setIndexr(key, builder, index);
				}
				b.addKeyedTemplate(builder);
			}
		}
	}

	/**
	 * get extract Job Result
	 * 
	 * @param request
	 *            PBJobResultRequest instance
	 * @return PBInquiryJobResult instance
	 * @throws IOException
	 */
	public PBExtractJobResult getJobResult(PBJobResultRequest request)
			throws IOException {
		long jobId = request.getJobId();
		PBExtractJobResult.Builder b = PBExtractJobResult.newBuilder();
		FeJobQueueEntity job = null;
		try {
			job = manager.find(FeJobQueueEntity.class, jobId);
		} catch (Exception ex) {
			exception.throwDBException(AimError.EXTRACT_DB, ex, String.format(
					"Exception occurred when find extract job by job id %s",
					jobId));
		}

		if (job == null) {
			final String error =  String.format("Can not find extract job by job id %s", jobId);
					
			log.error(error);			
			exception.throwArgException(AimError.MISS_JOBID_ERROR, error);
		}

		if (job.getStatus() != JobState.DONE) {
			final String error = "Job "
					+ jobId
					+ " is in "
					+ job.getStatus()
					+ " state. Job must be in DONE state before calling getJobResult()";
			log.error(error);
			throw new AimRuntimeException(error);
		}

		if (job.getResult() == null) {
			final String error = "Extract Job " + jobId + " result is null..)";
			log.error(error);
			throw new AimRuntimeException(error);
		}

		PBExtractJobResult result = null;
		try {
			byte[] compressedPayloadInteralResult = job.getResult();
			result = unPressesPayloadExResult(compressedPayloadInteralResult);
		} catch (InvalidProtocolBufferException e) {
			final String error = "InvalidProtocolBufferException occurred "
					+ "when parse from extract result..";
			throw new AimRuntimeException(error, e);
		}

		// b.setServiceState(PBStateUtil.creatSuccessState());
		if (result.hasJobId()) {
			b.setJobId(result.getJobId());
		}
		if (result.hasOutputPayload()) {
			b.setOutputPayload(result.getOutputPayload());
		}
		if (CollectionsUtil.isNotEmpty(result.getKeyedTemplateList())) {
			b.addAllKeyedTemplate(result.getKeyedTemplateList());
		}
		if (result.hasServiceState()) {
			b.setServiceState(result.getServiceState());
		}
		return b.build();
	}

	/**
	 * set PBKeyedTemplateIndexer
	 * 
	 * @param request
	 *            TemplateFormatType key PBKeyedTemplate.Builder builder int
	 *            indexr
	 */
	private void setIndexr(TemplateFormatType key,
			PBKeyedTemplate.Builder builder, int indexr) {
		switch (key) {
		case TEMPLATE_TI:
		case TEMPLATE_TIM:
		case TEMPLATE_TLI:
		case TEMPLATE_TLIS:
		case TEMPLATE_TLIM:
		case TEMPLATE_RDBT:
		case TEMPLATE_RDBTM:
			if (indexr != FingerPrintType.FINGER_PRINT_ROLLED_VALUE
					&& indexr != FingerPrintType.FINGER_PRINT_SLAP_VALUE) {
				exception.throwArgException(AimError.EXTRACT_RESULT_INDEX,
						indexr);
			}
			builder.setIndexer(PBKeyedTemplateIndexer.newBuilder()
					.setFingerPrintType(FingerPrintType.valueOf(indexr)));
			break;
		case TEMPLATE_RDBL:
		case TEMPLATE_RDBLS:
		case TEMPLATE_RDBLM:
		case TEMPLATE_PDB:
			ImagePositionType[] positionTypes = ImagePositionType.values();
			Set<Integer> set = Sets.newHashSet();
			for (ImagePositionType positionType : positionTypes) {
				set.add(positionType.getNumber());
			}
			if (!set.contains(indexr)) {
				exception.throwArgException(AimError.EXTRACT_RESULT_INDEX,
						indexr);
			}
			builder.setIndexer(PBKeyedTemplateIndexer.newBuilder().setPosition(
					ImagePositionType.valueOf(indexr)));
			break;
		case TEMPLATE_FDB:
			builder.setIndexer(PBKeyedTemplateIndexer.newBuilder().setIndex(
					indexr));
			break;
		default:
			break;
		}
	}

	public PBExtractJobResult unPressesPayloadExResult(
			byte[] compressedPayloadExResut) throws IOException {
		byte[] compressedOutputPayload = null;
		PBExtractJobResult.Builder newPBExtractJobResult = PBExtractJobResult
				.newBuilder();
		PBExtractJobResultInternal pbExInternal = PBExtractJobResultInternal
				.parseFrom(ByteString.copyFrom(compressedPayloadExResut));
		if (pbExInternal.hasCompressedOutputPayload()) {
			compressedOutputPayload = pbExInternal.getCompressedOutputPayload()
					.toByteArray();
			byte[] uncompressedOutputPayload = Deflater
					.uncompress(compressedOutputPayload);
			newPBExtractJobResult.setOutputPayload(PBExtractOutputPayload
					.parseFrom(uncompressedOutputPayload));
		}
		newPBExtractJobResult.setServiceState(pbExInternal.getServiceState());
		newPBExtractJobResult.setJobId(pbExInternal.getJobId());
		newPBExtractJobResult.addAllKeyedTemplate(pbExInternal
				.getKeyedTemplateList());
		return newPBExtractJobResult.build();
	}
}
