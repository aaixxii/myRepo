package jp.co.nec.aim.mm.acceptor.script;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.google.common.collect.Lists;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "container-spec", propOrder = { "scope", "containerId",
		"containerIdRolled", "containerIdSlap" })
public class ContainerSpec {
	@XmlElement(required = true)
	protected Integer scope;
	@XmlElement(required = false)
	protected List<Integer> containerId;
	@XmlElement(required = false)
	protected Integer containerIdRolled;
	@XmlElement(required = false)
	protected Integer containerIdSlap;

	/**
	 * Gets the value of the containerId property.
	 * 
	 * <p>
	 * This accessor method returns a reference to the live list, not a
	 * snapshot. Therefore any modification you make to the returned list will
	 * be present inside the JAXB object. This is why there is not a
	 * <CODE>set</CODE> method for the containerId property.
	 * 
	 * <p>
	 * For example, to add a new item, do as follows:
	 * 
	 * <pre>
	 * getContainerId().add(newItem);
	 * </pre>
	 * 
	 * 
	 * <p>
	 * Objects of the following type(s) are allowed in the list {@link Integer }
	 * 
	 * 
	 */
	public List<Integer> getContainerId() {
		if (this.containerId == null) {
			this.containerId = Lists.newArrayList();
		}
		return this.containerId;
	}

	public Integer getScope() {
		return scope;
	}

	public void setScope(Integer scope) {
		this.scope = scope;
	}

	public Integer getContainerIdRolled() {
		return containerIdRolled;
	}

	public void setContainerIdRolled(Integer containerIdRolled) {
		this.containerIdRolled = containerIdRolled;
	}

	public Integer getContainerIdSlap() {
		return containerIdSlap;
	}

	public void setContainerIdSlap(Integer containerIdSlap) {
		this.containerIdSlap = containerIdSlap;
	}

}
