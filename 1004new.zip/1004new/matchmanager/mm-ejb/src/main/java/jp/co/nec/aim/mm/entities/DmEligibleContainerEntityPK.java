package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * The primary key class for the DM_ELIGIBLE_CONTAINERS database table.
 * 
 */
@Embeddable
public class DmEligibleContainerEntityPK implements Serializable {
	// default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name = "DM_ID", insertable = false, updatable = false)
	private long dmId;

	@Column(name = "CONTAINER_ID", insertable = false, updatable = false)
	private long containerId;

	public DmEligibleContainerEntityPK() {
	}

	public long getDmId() {
		return this.dmId;
	}

	public void setDmId(long dmId) {
		this.dmId = dmId;
	}

	public long getContainerId() {
		return this.containerId;
	}

	public void setContainerId(long containerId) {
		this.containerId = containerId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof DmEligibleContainerEntityPK)) {
			return false;
		}
		DmEligibleContainerEntityPK castOther = (DmEligibleContainerEntityPK) other;
		return (this.dmId == castOther.dmId)
				&& (this.containerId == castOther.containerId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.dmId ^ (this.dmId >>> 32)));
		hash = hash * prime
				+ ((int) (this.containerId ^ (this.containerId >>> 32)));

		return hash;
	}
}