package jp.co.nec.aim.mm.constants;

/**
 * 
 * ErrorMessage
 * 
 * @author liuyq
 * 
 */
public class ErrorMessage {

	public static final String SYNC_INSERT_DEL_PAYLOAD_ERROR = "Sync Job(Both insertPayload and delPayload are not specified)";
	public static final String SYNC_IN_INSERT_PAYLOAD_ERROR = "Sync Job (InsertPayload is not specified when function type is insert)";
	public static final String SYNC_TEM_DATA_EMPTY_ERROR = "Sync Job (keyedTemplateData list size is empty  when function type is insert)";
	public static final String SYNC_TEM_TEMREF_ERROR = "Sync Job (Both PBKeyedTemplate and PBKeyedTemplateReference are not specified  when function type is insert)";
	public static final String SYNC_BINARY_FORMATTYPE_ERROR = "Sync Job (templateBinary and TemplateFormatType must be specified when PBKeyedTemplate is not null)";
	public static final String SYNC_KEY_JOBID_ERROR = "Sync Job (FejobId and TemplateFormatType must be correct when PBKeyedTemplateReference is not null)";
	public static final String SYNC_FORMATTYPE_ERROR = "Sync Job (TemplateFormatType is not specified when deletePayload,PBKeyedTemplate is not null)";
	public static final String SYNC_INDEXER_ERROR = "Sync Job (Both position, fingerPrintType and index are not specified when deletePayload,keyedTemplate,indexer is not null)";
	public static final String SYNC_DEL_INDEXER_ERROR = "Sync Job (fingerPrintType can not be specified)";
	public static final String SYNC_GET_TEMPLATE_ERROR = "Sync Job (Can not fetch template binary with job id and template key)";
	public static final String SYNC_UP_INSERT_PLALOAD_ERROR = "Sync Job (InsertPayload is not specified when function type is update)";
	public static final String SYNC_FUNCTIONTYPE_ERROR = "Sync Job (Function type is not support)";
	public static final String SYNC_KEY_INDEXER_ERROR = "Sync Job (The relationship of TemplateFormatType and PBKeyedTemplateIndexer is not correct)";
	public static final String SYNC_DB_ERROR = "Sync Service (DataBase error occurred, error:%s)";
	public static final String SYNC_INTERNAL_ERROR = "Sync Service (Internal Exception occurred, error:%s)";
	public static final String SYNC_CANNOT_FIND_CID_ERROR = "Sync Job (Can not find container id(s))";
	public static final String SYNC_SCOPE_ERROR = "Sync Service (Insert payload Scope incorrect)";
	public static final String SYNC_SCOPEOPTIONS_SCOPE_ERROR = "Sync Job (Specified Scope list in deletePayload was duplicate.)";
	public static final String SYNC_KEYTEMPLATE_DUPLICATE_ERROR = "Sync Job (Specified key and indexer list in insertpayload or deletePayload was duplicate.)";
	public static final String ENROLL_BATCH_TYPE_MISS_MATCH = "Enroll Request (Enroll batch type miss match)";
	public static final String ENROLL_BATCH_JOB_ID_DUPLICATE = "Enroll Request (Enroll batch job id duplicate)";
	public static final String ENROLL_REQUST_ID_DUPLICATE = "Enroll Request (Enroll batch job id duplicate)";
	public static final String ENROLL_REQUST_REF_ID_NOT_FOUND = "Enroll Request (Enroll reference id is not found)";
	public static final String ENROLL_REQUST_REF_URL_NOT_FOUND = "Enroll Request (Enroll file rul is not found)";
	public static final String ENROLL_REQUST_DATA_NOT_FOUND = "Enroll Request (Enroll data is not found)";
	public static final String ENROLL_E_REQUESET_TYPE_MISS = "Enroll Request (Enroll E_REQUESET_TYPE miss)";

	public static final String INQ_FUSION_LIST_ERROR = "Inquiry Job(fusionJobInput list is null or empty)";
	public static final String INQ_TEM_TEMREF_ERROR = "Inquiry Job (Both PBKeyedTemplate and PBKeyedTemplateReference are not specified)";
	public static final String INQ_KEY_INDEXER_ERROR = "Inquiry Job (The relationship of TemplateFormatType and PBKeyedTemplateIndexer is not correct)";
	public static final String INQ_BINARY_FORMATTYPE_ERROR = "Inquiry Job (templateBinary and TemplateFormatType must be specified when PBKeyedTemplate is not null)";
	public static final String INQ_KEY_JOBID_ERROR = "Inquiry Job (FejobId and TemplateFormatType must be correct when PBKeyedTemplateReference is not null)";
	public static final String INQ_GET_TEMPLATE_ERROR = "Inquiry Job (Can not fetch template binary with job id and telmplete key)";
	public static final String INQ_CANNOT_FIND_CID_ERROR = "Inquiry Job (Can not find container id(s))";
	public static final String PRIORITY_OUT_RANGE_ERROR = "Inquiry Job (Priority is out of range)";
	public static final String MAXCANDIDATES_OUT_RANGE_ERROR = "Inquiry Job (MaxCandidates is out of range)";
	public static final String MINSCORE_OUT_RANGE_ERROR = "Inquiry Job (MinScore is out of range)";
	public static final String DYHIT_OUT_RANGE_ERROR = "Inquiry Job (DynThreshHitThreshold is out of range)";
	public static final String DYPOINT_OUT_RANGE_ERROR = "Inquiry Job (DynThreshPercentagePoint is out of range)";
	public static final String INQ_BAD_REQUEST_ERROR = "Inquiry Service (Bad request url)";
	public static final String INQ_DB_ERROR = "Inquiry Service (DataBase error occurred, error:%s)";
	public static final String INQ_INTERNAL_ERROR = "Inquiry Service (Internal Exception occurred, error:%s)";
	public static final String INQ_JOB_RETRY_OVER_ERROR = "Inquiry Service (InquiryJob dead due to mr heatbeat timeout(mrId:%s InquiryJobId:%s).";
	public static final String INQ_JOB_RETRY_ERROR = "Exception occurred when fail(retry) inquiry job, inquiry job %s, MR id: %s";
	public static final String INQ_SCOPE_FINGERPRINTTYPE_ERROR = "Inquiry Service (Scope FingerPrintType is not correct.)";
	public static final String INQ_INDEXR_FINGERPRINTTYPE_ERROR = "Inquiry Service (Indexr FingerPrintType is not correct.)";
	public static final String INQ_RPRINTTYPE_DUPLICATE_ERROR = "Inquiry Service (FingerPrintType is duplicate.)";
	public static final String INQ_TEMPLATE_KEY_ERROR = "Inquiry Service (Function: %s contains Template key: %s)";
	public static final String INQ_FUNCTION_TYPE_ERROR = "Inquiry Service (Function type is incorrect)";
	public static final String INQ_FUSION_WEIGHT_ERROR = "Inquiry Service (Fusion weight is incorrect)";
	public static final String INQ_FUSION_WEIGHT_DUPLICATE_ERROR = "Inquiry Service (Fusion weight is duplicate.)";
	public static final String INQ_JOB_RESULT_ERROR = "Inquiry Job Result state is ERROR or ROLLBACK, but reason is not existed.";
	public static final String INQ_COMBINE_OF_KEY_ERROR = "Inquiry Job (The combination of functionName, TemplateFormatType, Search Side"
			+ " FingerPrintType and File side FingerPrintType is not correct, Search Key: %s)";
	public static final String INQ_SCOPEOPTIONS_SCOPE_ERROR = "Inquiry Job (Specified Scope list was duplicate.)";
	public static final String INQ_KEY_PRINTTYPE_DUPLICATE_ERROR = "Inquiry Job (The combination of (key fingerPrintType) was duplicate.)";
	public static final String INQ_BATCH_TYPE_MISS_MATCH = "Inquiry Request (Inquiry batch type miss match)";
	public static final String INQ_BATCH_JOB_ID_DUPLICATE = "Inquiry Request (Inquiry batch job id duplicate)";
	public static final String INQ_REQUST_ID_DUPLICATE = "Inquiry Request (Inquiry batch job id duplicate)";



	public static final String EXTRACT_BAD_REQUEST_ERROR = "Extract Service(Bad request url)";
	public static final String NOT_SUPPORT_METHOD = "Requied method is not supported(not supported method:%s)";
	public static final String EXTRACT_DB_ERROR = "Extract Service (DataBase error occurred, error:%s)";
	public static final String EXTRACT_INTERNAL_ERROR = "Extract Service (Internal Exception occurred, error:%s)";
	public static final String EXTRACT_JOB_RETRY_OVER_ERROR = "Extract Service (ExtractJob dead due to mu heatbeat timeout(muId:%s ExtractJobId:%s).";
	public static final String EXTRACT_JOB_RETRY_ERROR = "Exception occurred when fail(retry) extract job, Extract job %s, MatchUnit id: %s";
	public static final String EXTRACT_JOB_DUPLICATE_KEY = "Extraction job %d contained DUPLICATE Template Key";
	public static final String EXTRACT_BATCH_TYPE_MISS_MATCH = "Extraction Request (Extract batch type miss match)";
	public static final String EXTRACT_BATCH_JOB_ID_DUPLICATE = "Extraction Request (Extract batch job id duplicate)";
	public static final String EXTRACT_REQUST_ID_DUPLICATE = "Extraction Request (Extract batch job id duplicate)";
	public static final String EXTRACT_REQUST_IMAGE_URL_NOT_SET = "Extraction Request (Extract batch job image url not found)";
	
	

	public static final String EXTRACT_DISPATCHER_FE_LOT_JOB_NOT_FOUND = "Extract Dispatcher (FeLotJob is not found!)";
	public static final String EXTRACT_DISPATCHER_FE_JOB_NOT_FOUND = "Extract Dispatcher (FeJob is not found!)";
	public static final String EXTRACT_DISPATCHER_FE_PAYLOAD_NOT_FOUND = "Extract Dispatcher (Extract payload is not found!)";
	public static final String EXTRACT_DISPATCHER_MU_NOT_FOUND = "Extract Dispatcher (MuId is not found!, Mu Id)";
	public static final String EXTRACT_DISPATCHER_MU_URL_NOT_FOUND = "Extract Dispatcher (Mu URL is not found!)";
	public static final String EXTRACT_DISPATCHER_SEND_RETRY_OVER = "Extract Dispatcher (Failed to post fe jobs to MU!)";
	public static final String EXTRACT_RESULT_INDEX_ERROR = "Get Extract result (Fe results index is out of range, indexr:%s)";
	public static final String EXTRACT_RESULT_TEMPLATE_KEY_ERROR = "Get Extract result (Fe results template key is not correct, key:%s)";
	public static final String EXTRACT_TEMPLATE_NOT_FOUND_ERROR = "Extract Service (Template not found.)";

	public static final String COMPONENT_TYPE_NULL_ERROR = "PBComponentInfo.ComponentType is not correct..";
	public static final String COMPONENT_TYPE_ERROR = "PBComponentInfo.ComponentType(%s) is not support..";
	public static final String COMPONENT_VERSION_ERROR = "PBComponentInfo.version is not correct..";
	public static final String COMPONENT_UNIQUEID_ERROR = "PBComponentInfo.uniqueId is not correct..";
	public static final String COMPONENT_CONTACTURL_ERROR = "PBComponentInfo.contactURL is not correct..";

	public static final String COMPONENT_SEG_ID_ERROR = "Bad segment report: segment ID cannot be negative. Got segment ID: %s";
	public static final String COMPONENT_SEG_STATUS_ERROR = "Bad segment report: For segment %s, segment status must be specified ";
	public static final String COMPONENT_SEG_VER_NULL_ERROR = "Bad segment report: For segment %s, status is 0 or 1 but version is not specified.";
	public static final String COMPONENT_SEG_VER_ERROR = "Bad segment report: For segment %s , status is 0 or 1 but given version is negative. got version: %s.";
	public static final String COMPONENT_SEG_QUEUEVER_ERROR = "Bad segment report: For segment %s, queuedVersion is less that version. got queuedVersion: %s, version: %s.";
	public static final String COMPONENT_SEG_NOTFOUND_ERROR = "Bad segment report: Report segment %S is not exist.";
	public static final String COMPONENT_UNIT_ID_ERROR = "PBExitRequest.id is zero or negative..";
	public static final String COMPONENT_DB_ERROR = "Status Service (DataBase error occurred, error:%s)";
	public static final String COMPONENT_EXTRACT_JOB_RETRY_OVER_ERROR = "Status Service (ExtractJob is failed "
			+ "due to The MU which was assigned this extract job was Exited or Re-Entered. (ExtractJobId:%s).";

	public static final String DISPATCHER_MR_NOT_FOUND_ERROR = "Inquiry dispatcher (Can not find any alive MR)";
	public static final String DISPATCHER_MR_RESPONSE_ERROR = "Inquiry dispatcher (MR(%s) response abnormal http code, Rollback the container job)";
	public static final String DISPATCHER_EXCEPTION_ERROR = "Inquiry dispatcher (%s occurred, error message: %s)";

	public static final String INTERNAL_SERVER_ERROR = "(Internal server Exception occurred, Error message: %s)";
	public static final String SYSTEM_DB_BUSY_ERROR = "(System DB busy due to locked, message: %s)";
	public static final String SYSTEM_DB_ERROR = "(System DB error, error message: %s)";
	public static final String MANAGER_BAD_REQUEST_ERROR = "Manage Service (Bad request url)";
	public static final String LICENSE_ERROR = "(License validation error with specified function name: %s, Error message: %s)";
	public static final String TEMPLATE_VALIDATOR_ERROR = "(Template validation error, Error message: %s)";
	public static final String SCHEDULABLE_ERROR = "(Schedulable service Exception occurred, Error message: %s)";
	public static final String JMS_ERROR = "(Jms Sender Exception occurred, Error message: %s)";
	public static final String PROTOBUF_ERROR = "(Protobuf Exception occurred, Error message: %s)";
	
	public static final String MISS_JOBID_ERROR = "(Required jobid is not exist, Error message: %s)";

	public static final String MU_TIME_OUT = "MatchUnit(ID: %d) timed out (heartbeat)";
	public static final String MR_TIME_OUT = "MapRedecer(ID: %d) timed out (heartbeat)";
	public static final String DM_TIME_OUT = "DataManager(ID: %d) timed out (heartbeat)";

	public static final String MM_START_UP = "Match Manager on %s started up.";
	public static final String AIM_DEFAULT = "";

	public static final String CLASS_CONVERTER_ERROR = "(Class Convert %s occurred, Error message: %s)";

}
