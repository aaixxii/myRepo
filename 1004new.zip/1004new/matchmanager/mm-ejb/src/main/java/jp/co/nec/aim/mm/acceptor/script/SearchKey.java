package jp.co.nec.aim.mm.acceptor.script;

import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPrintType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.TemplateFormatType;
import jp.co.nec.aim.mm.acceptor.script.ScriptManager.ScriptFunction;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * SearchKey
 * 
 * @author liuyq
 * 
 */
public final class SearchKey implements Key {
	private ScriptFunction function; // script function
	private TemplateFormatType templateFmt; // template key
	private FingerPrintType sFinPrint; // search side finger print
	private FingerPrintType fFinPrint; // file side finger print

	/**
	 * SearchKey constructor
	 * 
	 * @param templateFmt
	 *            the instance of TemplateFormatType
	 * @param sFinPrint
	 *            the instance of FingerPrintType
	 */
	public SearchKey(TemplateFormatType templateFmt, FingerPrintType sFinPrint) {
		this.templateFmt = templateFmt;
		this.sFinPrint = sFinPrint;
	}

	/**
	 * SearchKey constructor
	 * 
	 * @param function
	 *            ScriptFunction instance
	 * @param templateFmt
	 *            TemplateFormatType instance
	 * @param sFinPrint
	 *            search side FingerPrintType instance
	 * @param fFinPrint
	 *            file side FingerPrintType instance
	 */
	public SearchKey(ScriptFunction function, TemplateFormatType templateFmt,
			FingerPrintType sFinPrint, FingerPrintType fFinPrint) {
		this.function = function;
		this.templateFmt = templateFmt;
		this.sFinPrint = sFinPrint;
		this.fFinPrint = fFinPrint;
	}

	public ScriptFunction getFunction() {
		return function;
	}

	public void setFunction(ScriptFunction function) {
		this.function = function;
	}

	public TemplateFormatType getTemplateFmt() {
		return templateFmt;
	}

	public void setTemplateFmt(TemplateFormatType templateFmt) {
		this.templateFmt = templateFmt;
	}

	public FingerPrintType getsFinPrint() {
		return sFinPrint;
	}

	public void setsFinPrint(FingerPrintType sFinPrint) {
		this.sFinPrint = sFinPrint;
	}

	public FingerPrintType getfFinPrint() {
		return fFinPrint;
	}

	public void setfFinPrint(FingerPrintType fFinPrint) {
		this.fFinPrint = fFinPrint;
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this, false);
	}

	@Override
	public boolean equals(Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj, false);
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this,
				ToStringStyle.SHORT_PREFIX_STYLE);
	}

	@Override
	public String getFormatType() {
		// TODO Auto-generated method stub
		return null;
	}

	public static void main(String[] args) {
		System.out.println(new SearchKey(ScriptFunction.II,
				TemplateFormatType.TEMPLATE_II,
				FingerPrintType.FINGER_PRINT_SLAP, null));
	}

}
