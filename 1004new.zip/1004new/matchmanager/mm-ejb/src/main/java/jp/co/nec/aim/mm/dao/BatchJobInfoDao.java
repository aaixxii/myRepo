package jp.co.nec.aim.mm.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.entities.BatchJobInfoEntity;

public class BatchJobInfoDao {

	/** log instance **/
	private static final Logger log = LoggerFactory.getLogger(BatchJobInfoDao.class);
	private EntityManager em;

	public BatchJobInfoDao(EntityManager em) {
		this.em = em;
	}
	
	@SuppressWarnings("unchecked")
	public  List<BatchJobInfoEntity> getBatchJobInfo(long jobId, String batchType) {
		Query q = em.createNamedQuery("NQ::batchjobInfo");
		q.setParameter("internalId", jobId);
		q.setParameter("batchType", batchType);
		return (List<BatchJobInfoEntity>) q.getResultList();
	}
	
}
