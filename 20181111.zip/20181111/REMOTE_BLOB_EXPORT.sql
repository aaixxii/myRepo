--------------------------------------------------------
--  �t�@�C�����쐬���܂��� - ���j��-11��-11-2018   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure REMOTE_BLOB_EXPORT
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "UFTEST"."REMOTE_BLOB_EXPORT" (P_LOCAL_DIRECTORY in varchar2) IS 
    l_id VARCHAR2(60 BYTE);
    l_photo_len number;
    l_photo blob;
    l_file      UTL_FILE.FILE_TYPE;
    l_buffer    RAW(32767);
    l_amount    BINARY_INTEGER := 32767;
    l_pos       NUMBER := 1; 
    c_photo_ext varchar2(5);
    l_file_name varchar2(30);
    BEGIN
      c_photo_ext :='.bmp';  

      for rec in
        ( SELECT * FROM BIO_TEMPLATE_DATA_INFO)
      loop
          l_id:=rec.TEMPLATE_DATA_ID;
          l_photo:=rec.TEMPLATE_DATA;
          l_photo_len := DBMS_LOB.getlength(l_photo);
          l_file_name := to_char(l_id)||c_photo_ext;
          --open file
          l_file := UTL_FILE.fopen(P_LOCAL_DIRECTORY,l_file_name,'wb',32767);
          --write file
          WHILE l_pos < l_photo_len LOOP
            DBMS_LOB.read(l_photo, l_amount, l_pos, l_buffer);
            UTL_FILE.put_raw(l_file, l_buffer, TRUE);
            l_pos := l_pos + l_amount;
          END LOOP;
          utl_file.fflush(l_file);
          UTL_FILE.fclose(l_file);
      end loop;

    END REMOTE_BLOB_EXPORT;

/
