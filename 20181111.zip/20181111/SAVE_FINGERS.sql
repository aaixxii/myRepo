--------------------------------------------------------
--  �t�@�C�����쐬���܂��� - ���j��-11��-11-2018   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure SAVE_FINGERS
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "UFTEST"."SAVE_FINGERS" IS
 	v_blob_locater		blob;
	v_offset		integer := 1;
	v_buffer		long raw;
	
	v_file_buffer_size	integer := 32000;
	v_amount		integer := 32000;

	v_totalsize		integer;
	v_filetype		utl_file.file_type;
	v_filename		varchar2(1000) := 'xiaaa_out.jpg';
	v_openmode		varchar2(2) := 'wb';
  
BEGIN
	 select TEMPLATE_DATA into v_blob_locater from BIO_TEMPLATE_DATA_INFO where TEMPLATE_DATA_ID=1; 
	v_totalsize := dbms_lob.getlength(v_blob_locater);
	v_filetype := utl_file.fopen('PHOTO', v_filename, v_openmode, v_file_buffer_size);

	while v_offset < v_totalsize loop
		if v_offset + v_amount > v_totalsize then
			v_amount := v_totalsize - v_offset + 1;
		end if;
		dbms_lob.read(
			v_blob_locater,
			v_amount, 
			v_offset,
			v_buffer
		);

		utl_file.put_raw(
			v_filetype,
			v_buffer,
			true
		);
		v_offset := v_offset + v_amount;
		dbms_output.put_line ( 'Offset : ' || v_offset );
	end loop;
	
	utl_file.fflush(v_filetype);
	utl_file.fclose(v_filetype);

END SAVE_FINGERS;

/
