--------------------------------------------------------
--  �t�@�C�����쐬���܂��� - ���j��-11��-11-2018   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Procedure SAVE_IMAGES
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "UFTEST"."SAVE_IMAGES" (
    START_BIOMETRIC_ID VARCHAR2,
    BIN_ID      IN NUMBER,
    SEGMINET_ID IN NUMBER ) AUTHID CURRENT_USER
IS
  l_id VARCHAR2(60 BYTE);
  v_blob_locater BLOB;
  v_offset INTEGER := 1;
  v_buffer LONG raw;
  l_hour               VARCHAR2(2);
  l_back_log_file_name VARCHAR2(36);
  v_file_buffer_size   INTEGER := 32000;
  v_amount             INTEGER := 32000;
  v_totalsize          INTEGER;
  v_filetype utl_file.file_type;
  v_openmode VARCHAR2(2) := 'wb';
  l_count    NUMBER;
BEGIN
  FOR rec IN
  ( SELECT * FROM BIO_TEMPLATE_DATA_INFO
  )
  LOOP
    l_id           := rec.TEMPLATE_DATA_ID;   
    v_blob_locater := rec.TEMPLATE_DATA;
    v_totalsize    := dbms_lob.getlength(v_blob_locater);
    SELECT TO_CHAR(systimestamp, 'HH24') INTO l_hour FROM dual;
    -- l_back_log_path:= l_back_log_path  || '/' || BIN_ID || '/' || SEGMINET_ID || '/' || l_hour;
    l_back_log_file_name := SEGMINET_ID || '_' || BIN_ID || '_'|| l_id || '.bmp';
    v_totalsize          := dbms_lob.getlength( rec.TEMPLATE_DATA);
    v_filetype           := utl_file.fopen('BLOBS', l_back_log_file_name, v_openmode, v_file_buffer_size);
    WHILE v_offset        < v_totalsize
    LOOP
      IF v_offset                          + v_amount > v_totalsize THEN
        v_amount            := v_totalsize - v_offset + 1;
      END IF;
      dbms_lob.read(rec.TEMPLATE_DATA, v_amount, v_offset, v_buffer );
      utl_file.put_raw( v_filetype, v_buffer, true );
      v_offset := v_offset + v_amount;
     -- dbms_output.put_line ( 'Offset : ' || v_offset );
    END LOOP;
    utl_file.fflush(v_filetype);
    utl_file.fclose(v_filetype);
  END LOOP;
END SAVE_IMAGES ;

/
