package jp.co.nec.aim.mm.acceptor.service;

import static org.junit.Assert.fail;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.CommonEnumTypes.FingerPrintType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ImageFormatType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ImagePositionType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.JobStateType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.CommonEnumTypes.TemplateFormatType;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplate;
import jp.co.nec.aim.message.proto.CommonPayloads.PBKeyedTemplateIndexer;
import jp.co.nec.aim.message.proto.CommonPayloads.PBServiceState;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FaceExtractProcessType;
import jp.co.nec.aim.message.proto.ExtractEnumTypes.FisTypeType;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBAimFormat;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractFaceInput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractFeType;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractFeTypeEvent;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputImage;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractInputPayload;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractIrisOutput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractLatentInput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractOutputPayload;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractTenprintInput;
import jp.co.nec.aim.message.proto.ExtractPayloads.PBExtractTenprintOutput;
import jp.co.nec.aim.message.proto.ExtractService.ExtractRequest;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.dao.FEJobDao;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.exception.ArgumentException;
import jp.co.nec.aim.mm.exception.DataBaseException;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.util.Deflater;
import jp.co.nec.aim.mm.util.ProtobufCreater;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.google.protobuf.ByteString;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()
@Transactional
public class AimExtractServiceTest extends
		AbstractTransactionalJUnit4SpringContextTests {
	@Resource
	private DataSource dataSource;
	@Resource
	private AimExtractService aimExtractService;
	@Resource
	private JdbcTemplate jdbcTemplate;

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;
	
	private ProtobufCreater protobufCreater;

	@Before
	public void setUp() {
		jdbcTemplate.update("delete from FE_JOB_QUEUE");
		jdbcTemplate.update("delete from FE_JOB_PAYLOADS");
		jdbcTemplate.update("delete from FE_RESULTS");
		jdbcTemplate.execute("commit");
		setMockMethod();
		protobufCreater = new ProtobufCreater();
	}

	@After
	public void tearDown() {
		jdbcTemplate.update("delete from FE_JOB_QUEUE");
		jdbcTemplate.update("delete from FE_JOB_PAYLOADS");
		jdbcTemplate.update("delete from FE_RESULTS");
		jdbcTemplate.execute("commit");		
	}

	private void setMockMethod() {
		new MockUp<JmsSender>() {
			@Mock
			private void convertAndSend(String queueName, Object object) {
				return;
			}
		};
	}
	
	@Test
	public void testExtract() {
		ExtractRequest exq = protobufCreater.createExtractRequest();
		aimExtractService.extract(exq, true);
		System.out.print("OKOK");
	}

	


	public byte[] createCompuressedExtractPayload() throws IOException {
		PBExtractOutputPayload.Builder payload = PBExtractOutputPayload
				.newBuilder();
		payload.setTenprintOutput(PBExtractTenprintOutput.newBuilder())
				.setIrisOutput(PBExtractIrisOutput.newBuilder());
		byte[] bytePayload = payload.build().toByteArray();
		byte[] compressBytes = Deflater.compress(bytePayload);
		return compressBytes;
	}

}
