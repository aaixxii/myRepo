use DMDEMO;
source ddl/create_tab.sql
source seed/insert_init_dm_demo_db.sql






