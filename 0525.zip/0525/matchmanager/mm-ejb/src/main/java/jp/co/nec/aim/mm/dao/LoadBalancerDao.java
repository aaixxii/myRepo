package jp.co.nec.aim.mm.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.AIMEnumTypes.ComponentType;
import jp.co.nec.aim.mm.constants.MMEventType;
import jp.co.nec.aim.mm.entities.ContainerEntity;
import jp.co.nec.aim.mm.entities.UnitSegMap;
import jp.co.nec.aim.mm.loadbalancer.SlbMatrix;
import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.procedure.PersistSlbMatrixProcedure;
import jp.co.nec.aim.mm.util.CollectionsUtil;
import jp.co.nec.aim.mm.util.StopWatch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * 
 * @author mozj
 * 
 */
public class LoadBalancerDao {
	private static final Logger log = LoggerFactory
			.getLogger(LoadBalancerDao.class);
	private final EntityManager manager;
	private final DataSource dataSource;
	private final JdbcTemplate jdbcTemplate;

	public LoadBalancerDao(EntityManager manager, DataSource dataSource) {
		this.manager = manager;
		this.dataSource = dataSource;
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	/**
	 * deleteMuSegWithCId
	 * 
	 * @param containerId
	 */
	public void deleteMuSegWithCId(long containerId) {
		jdbcTemplate
				.update("DELETE FROM mu_segments WHERE segment_id"
						+ " IN (SELECT segment_id FROM SEGMENTS WHERE container_id = ?)",
						containerId);
	}

	public void lockForSLB() {
		jdbcTemplate.queryForObject(
				"select NAME from MM_EVENTS where NAME = ? for update",
				String.class, MMEventType.SEGMENT_LOAD_BALANCING.name());
	}

	public void commit() {
		jdbcTemplate.execute("commit");
	}

	@SuppressWarnings("unchecked")
	public List<Long> getSegmentIds(Long containerId) {
		Query q = manager.createNamedQuery("NQ::getSegmentIds");
		q.setParameter("containerId", containerId);
		List<BigDecimal> list = q.getResultList();

		List<Long> ids = new ArrayList<Long>();
		for (int i = 0; i < list.size(); i++) {
			ids.add(list.get(i).longValue());
		}
		return ids;

	}

	@SuppressWarnings("unchecked")
	public List<ContainerEntity> listContainers() {
		Query q = manager.createNamedQuery("NQ::listContainers");
		return q.getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<UnitSegMap> getUnitSegmetMaps(List<Long> unitIds,
			ComponentType type) {
		if (type != ComponentType.MATCH_UNIT
				&& type != ComponentType.DATA_MANAGER) {
			throw new IllegalArgumentException(
					"type must be MATCH_UNIT or DATA_MANAGER.");

		}
		if (CollectionsUtil.isEmpty(unitIds)) {
			throw new IllegalArgumentException(
					"unitIds must no be null or empty.");
		}

		Query q;
		if (type.equals(ComponentType.DATA_MANAGER)) {
			q = manager.createNamedQuery("NQ::getDMSegmetMaps");
		} else {
			q = manager.createNamedQuery("NQ::getMUSegmetMaps");
		}
		q.setParameter("unitIds", unitIds);
		return q.getResultList();
	}

	public void persistUnitSegMaps(boolean[][] matrix, boolean[][] preMatrix,
			List<Long> segIds, List<Long> unitIds, ComponentType type,
			long containerId) {
		if (matrix == null) {
			throw new IllegalArgumentException("matrix is null.");
		}
		if (preMatrix == null) {
			throw new IllegalArgumentException("preMatrix is null.");
		}
		if (segIds == null) {
			throw new IllegalArgumentException("segIds is null.");
		}
		if (unitIds == null) {
			throw new IllegalArgumentException("units is null.");
		}
		if (type == null) {
			throw new IllegalArgumentException("type is null.");
		}
		if (type != ComponentType.MATCH_UNIT
				&& type != ComponentType.DATA_MANAGER) {
			throw new IllegalArgumentException(
					"type must be MATCH_UNIT or DATA_MANAGER.");
		}
		if (matrix.length != unitIds.size()) {
			throw new IllegalArgumentException("matrix.length != units.size()");
		}
		if (matrix.length == 0) {
			log.info("matrix.length == 0");
			return;
		}
		if (CollectionsUtil.isEmpty(segIds)) {
			log.info("segIds.size() == 0");
			return;
		}

		final StopWatch t = new StopWatch();
		t.start();

		PersistSlbMatrixProcedure procedure = new PersistSlbMatrixProcedure(
				dataSource);
		List<SlbMatrix> matrixs = procedure.getMatrixs();
		for (int unitIndex = 0; unitIndex < unitIds.size(); unitIndex++) {
			long unitId = unitIds.get(unitIndex);
			for (int segIndex = 0; segIndex < segIds.size(); segIndex++) {
				long segmentId = segIds.get(segIndex);
				if (matrix[unitIndex][segIndex]) {
					matrixs.add(new SlbMatrix(unitId, segmentId));
				}
			}
		}
		procedure.setContainerId(containerId);
		procedure.setUnitType(type.ordinal());
		procedure.execute();

		t.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "persistUnitSegMaps",
				t.elapsedTime());
	}
}
