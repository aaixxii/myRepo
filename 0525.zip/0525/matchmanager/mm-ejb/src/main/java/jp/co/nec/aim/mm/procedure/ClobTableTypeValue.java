package jp.co.nec.aim.mm.procedure;

import java.io.IOException;
import java.io.Writer;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import jp.co.nec.aim.mm.exception.AimRuntimeException;
import oracle.jdbc.OracleConnection;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.AbstractSqlTypeValue;

import com.google.common.collect.Lists;

/**
 * Class represents CLOB_TABLE_TYPE
 * 
 * @author kurosu
 * 
 */
public class ClobTableTypeValue extends AbstractSqlTypeValue {
	private static final String ALTER_SESSION_SQL = "alter session set events '60025 trace name context forever'";
	private String[] array;
	private List<Clob> clobs;
	private static final String CLOB_TABLE_TYPE = "CLOB_TABLE_TYPE";

	public ClobTableTypeValue(String[] array) {
		this.array = array;
	}

	@Override
	protected Object createTypeValue(Connection conn, int sqlType,
			String typeName) throws SQLException {
		OracleConnection oraConn = conn.unwrap(OracleConnection.class);
		try {
			return oraConn.createARRAY(CLOB_TABLE_TYPE,
					createBLOBArray(oraConn));
		} catch (IOException e) {
			throw new AimRuntimeException(e);
		}
	}

	private Clob[] createBLOBArray(OracleConnection oraConn)
			throws SQLException, IOException {
		clobs = Lists.newArrayListWithCapacity(array.length);
		for (int i = 0; i < array.length; i++) {
			Clob clob = oraConn.createClob();
			Writer writer = clob.setCharacterStream(1L);
			writer.write(array[i]);
			writer.flush();
			writer.close();
			clobs.add(clob);
		}
		return clobs.toArray(new Clob[] {});
	}

	/**
	 * Need to call freeTemporary() after craeteTemporary()
	 * 
	 * @param jdbcTemplate
	 * @throws SQLException
	 */
	public void freeTemporary(JdbcTemplate jdbcTemplate) throws SQLException {
		for (Clob clob : clobs) {
			clob.free();
		}
		jdbcTemplate.execute(ALTER_SESSION_SQL);
	}

}
