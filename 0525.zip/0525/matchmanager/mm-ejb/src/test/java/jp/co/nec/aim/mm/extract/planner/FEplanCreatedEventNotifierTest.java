package jp.co.nec.aim.mm.extract.planner;

import javax.annotation.Resource;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import jp.co.nec.aim.mm.constants.JNDIConstants;
import jp.co.nec.aim.mm.notifier.FEplanCreatedEventNotifier;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.broker.BrokerService;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class FEplanCreatedEventNotifierTest {
	private BrokerService broker = null;
	private String jmsURL = "tcp://localhost:61788";
	private String dispatchQueue = JNDIConstants.EXTRACT_JOB_DISPATCH_QUEUE;
	private String mesgToFEDispatchQueue = "Please send jobs to MUS.";
	@Resource
	private FEplanCreatedEventNotifier sender;

	@Before
	public void setUp() throws Exception {
		broker = new BrokerService();
		broker.setBrokerName("AIM_JMS_SERVER");
		broker.addConnector(jmsURL);
		broker.setPersistent(false);
		broker.start();
		send(mesgToFEDispatchQueue);
	}

	public void send(String msg) throws JMSException {
		ConnectionFactory factory = new ActiveMQConnectionFactory(jmsURL);
		Connection connection = factory.createConnection();
		connection.start();
		final Session session = connection.createSession(false,
				Session.AUTO_ACKNOWLEDGE);
		Destination queue = session.createQueue(dispatchQueue);
		MessageProducer producer = session.createProducer(queue);
		TextMessage message = session.createTextMessage(msg);
		producer.send(message);
		connection.close();
	}

	@After
	public void tearDown() throws Exception {
		broker.stop();
	}

	@Test
	public void testNotify() throws JMSException {
		ConnectionFactory factory = new ActiveMQConnectionFactory(jmsURL);
		Connection connection = factory.createConnection();
		connection.start();
		final Session session = connection.createSession(false,
				Session.AUTO_ACKNOWLEDGE);
		Destination queue = session.createQueue(dispatchQueue);
		MessageConsumer consumer = session.createConsumer(queue);
		consumer.setMessageListener(new MessageListener() {
			@Override
			public void onMessage(Message message) {
				TextMessage txtMsg = (TextMessage) message;
				try {
					Assert.assertEquals(mesgToFEDispatchQueue, txtMsg.getText());
				} catch (JMSException e) {
					e.printStackTrace();
				}
			}
		});
	}
}
