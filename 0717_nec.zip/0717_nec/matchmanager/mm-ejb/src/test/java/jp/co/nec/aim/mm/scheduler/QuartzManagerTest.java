package jp.co.nec.aim.mm.scheduler;

import static org.junit.Assert.assertFalse;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import jp.co.nec.aim.mm.common.JdbcTemplateHelper;
import jp.co.nec.aim.mm.constants.SchedulerEnum;
import jp.co.nec.aim.mm.dao.MatchManagerDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.impl.StdScheduler;
import org.quartz.impl.StdSchedulerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class QuartzManagerTest {

	@Resource
	private DataSource ds;

	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;

	@Resource
	private JdbcTemplate jdbcTemplate;

	private QuartzManager quartzmanager = null;
	private JdbcTemplateHelper helper;
	private SystemConfigDao sysConfigDao;

	private ListCommon common;

	private int intervalInMillis = 10000;
	
	MockUp<MatchManagerDao> mocked;

	@Before
	public void setUp() throws Exception {
		if (helper == null) {
			helper = new JdbcTemplateHelper();
			sysConfigDao = new SystemConfigDao(entityManager);
			common = new ListCommon();
			common.init();
		}
		common.initSysConf(helper, jdbcTemplate, entityManager, sysConfigDao,
				ds);
		QuartzManager.INSTANCE = null;
		quartzmanager = QuartzManager.getInstance(entityManager);
		common.setMockMethods();
		setMockMethods();
	}

	private void setMockMethods() {
		 mocked = new MockUp<MatchManagerDao>() {
			@Mock
			private String getMMUniqueId() {
				return "10.84.75.213";
			}
		};
	}

	@After
	public void tearDown() throws Exception {
		common.initSysConf(helper, jdbcTemplate, entityManager, sysConfigDao,
				ds);		
		common.clear();
		mocked.tearDown();
	}

	@Test
	public void testReScheduler_01() {

		helper.insertMM_SameMMId_mmId10(jdbcTemplate);

		try {
			quartzmanager.startScheduler();
			Thread.sleep(intervalInMillis);
			for (SchedulerEnum schedulerenum : SchedulerEnum.values()) {
				if (schedulerenum.getIntervalProperty() != null) {
					helper.UpdateSystemConfig(jdbcTemplate, schedulerenum
							.getIntervalProperty().getName(), String
							.valueOf(2000));
				}
			}
			common.rescheduler();
			Thread.sleep(intervalInMillis);
		} catch (InterruptedException e) {
			assertFalse(true);
		} finally {
			quartzmanager.shutdownScheduler();
		}
		common.printf(Thread.currentThread().getStackTrace()[1].getClassName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

	}

	@Test
	public void testReScheduler_02() {

		helper.insertMM_SameMMId_mmId10(jdbcTemplate);

		try {

			quartzmanager.startScheduler();

			Thread.sleep(intervalInMillis);
			for (SchedulerEnum schedulerenum : SchedulerEnum.values()) {
				if (schedulerenum.getIntervalProperty() != null) {
					helper.UpdateSystemConfig(jdbcTemplate, schedulerenum
							.getIntervalProperty().getName(), String
							.valueOf(700));
				}
			}
			common.rescheduler();
			Thread.sleep(intervalInMillis);
		} catch (InterruptedException e) {
			assertFalse(true);
		} finally {
			quartzmanager.shutdownScheduler();
		}
		common.printf(Thread.currentThread().getStackTrace()[1].getClassName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

	}

	@Test
	public void testReScheduler_03() {

		helper.insertMM_SameMMId_mmId10(jdbcTemplate);

		try {

			quartzmanager.startScheduler();

			Thread.sleep(intervalInMillis);
			quartzmanager.reScheduler(null);
			assertFalse(true);
		} catch (InterruptedException e) {
			assertFalse(true);
		} catch (IllegalArgumentException e) {
			assertFalse(false);
		} finally {
			quartzmanager.shutdownScheduler();
		}

	}

	@Test
	public void test_canIdoIt_false() {

		helper.insertMM_SameMMId(jdbcTemplate);

		try {
			quartzmanager.startScheduler();

			Thread.sleep(intervalInMillis);
		} catch (InterruptedException e) {
			assertFalse(true);
		} finally {
			quartzmanager.shutdownScheduler();
		}
		common.printf(Thread.currentThread().getStackTrace()[1].getClassName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

	}

	@Test
	public void test_updateLastTimeStamp_Exception() {
		 MockUp<CommonBean> mocked = new MockUp<CommonBean>() {
			@Mock
			public boolean updateLastTimeStamp(SchedulerEnum schedulerEnum) {
				throw new IllegalArgumentException();
			}
		};

		helper.insertMM_SameMMId(jdbcTemplate);

		try {
			quartzmanager.startScheduler();

			Thread.sleep(intervalInMillis);
		} catch (InterruptedException e) {
			assertFalse(true);
		} finally {
			quartzmanager.shutdownScheduler();
			mocked.tearDown();
		}
		common.printf(Thread.currentThread().getStackTrace()[1].getClassName(),
				Thread.currentThread().getStackTrace()[1].getMethodName());

	}

	@Test
	public void test_init_Exception() {
		MockUp<StdSchedulerFactory> mocked = new MockUp<StdSchedulerFactory>() {

			@Mock
			public Scheduler getScheduler() throws SchedulerException {
				throw new SchedulerException();
			}
		};

		helper.insertMM_SameMMId(jdbcTemplate);

		try {

			QuartzManager.INSTANCE = null;
			quartzmanager = QuartzManager.getInstance(entityManager);
			Thread.sleep(intervalInMillis);
		} catch (InterruptedException e) {
			assertFalse(true);
		} catch (Exception e) {
			assertFalse(false);
		} finally {
			quartzmanager.shutdownScheduler();
			mocked.tearDown();
		}

	}


	@Test
	public void test_stop_Exception() {
		MockUp<StdScheduler> mocked = new MockUp<StdScheduler>() {
			@Mock
			void shutdown(boolean waitForJobsToComplete)
					throws SchedulerException {
				throw new SchedulerException();
			}
		};

		helper.insertMM_SameMMId(jdbcTemplate);

		try {
			quartzmanager.startScheduler();

			Thread.sleep(intervalInMillis);
		} catch (InterruptedException e) {
			assertFalse(true);
		} catch (Exception e) {
			assertFalse(false);
		} finally {
			try {
				quartzmanager.shutdownScheduler();
			} catch (Exception e) {
				assertFalse(false);
			} finally {				
				//quartzmanager.shutdownScheduler();
				mocked.tearDown();
			}
		}

	}
}
