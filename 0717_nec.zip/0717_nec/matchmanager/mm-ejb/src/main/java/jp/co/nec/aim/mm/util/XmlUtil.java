/**this is file XmlUtil.java
 * @author xia
   @date 2020/05/30
 */
package jp.co.nec.aim.mm.util;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

import jp.co.nec.aim.mm.exception.XmlException;
import jp.co.nec.aim.mm.sessionbeans.pojo.UidAimAmqResponse;

/**
 * @author xia
 *
 */
public class XmlUtil {
	private static final String REQUEST_ID = "requestId";
	private static final String REF_ID = "referenceId";
	private static final String URL = "referenceUrl";

	public boolean isThisCmd(String xml, String elementName) {
		// elementName is Quality or Insert or Identify or Delete
		SAXReader reader = new SAXReader();
		Document document = null;
		try {
			document = reader.read(new ByteArrayInputStream(xml.getBytes("UTF-8")));
		} catch (DocumentException | UnsupportedEncodingException e) {
			throw new XmlException(e.getMessage(), e.getCause());
		}
		Element rootElement = document.getRootElement();
		Element element = rootElement.element(elementName);
		String cmd = element.getName();
		if (cmd.equals(elementName)) {
			return true;
		} else {
			return false;
		}
	}
	
	@SuppressWarnings("rawtypes")
	public static String getXmlCmd(String xml) {
		SAXReader reader = new SAXReader();
		Document document = null;
		try {
			document = reader.read(new ByteArrayInputStream(xml.getBytes("UTF-8")));
		} catch (DocumentException | UnsupportedEncodingException e) {
			throw new XmlException(e.getMessage(), e.getCause());
		}		
		Element rootElement = document.getRootElement();
		//String xpathExpression = "child::node()";
		//List<Element> nods = rootElement.selectNodes(xpathExpression);
		List node = rootElement.elements();
		 Element first =(Element) node.get(0);
		 return first.getName();
	}

	// for Request and Respose
	public static String getRequestId(String xml) {
		SAXReader reader = new SAXReader();
		Document document = null;
		try {
			document = reader.read(new ByteArrayInputStream(xml.getBytes("UTF-8")));
		} catch (DocumentException | UnsupportedEncodingException e) {
			throw new XmlException(e.getMessage(), e.getCause());
		}
		Element rootElement = document.getRootElement();
		String responseResult = rootElement.attributeValue(REQUEST_ID);
		return responseResult;
	}

	public static String getRefId(String xml, String elementName) {
		// elementName is Insert or Identify or Quality or Delete
		// elementName is quality-payload or insert-payload or identify-payload
		SAXReader reader = new SAXReader();
		Document document = null;
		try {
			document = reader.read(new ByteArrayInputStream(xml.getBytes("UTF-8")));
		} catch (DocumentException | UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		Element rootElement = document.getRootElement();
		Element element = rootElement.element(elementName);
		String refId = element.attributeValue(REF_ID);
		return refId;
	}
	
	public static String getIdentifyAtribute(String xml, String atributeName) {
		SAXReader reader = new SAXReader();
		Document document = null;
		try {
			document = reader.read(new ByteArrayInputStream(xml.getBytes("UTF-8")));
		} catch (DocumentException | UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		Element rootElement = document.getRootElement();
		Element element = rootElement.element("Identify");
		String attributeValue  = element.attributeValue(atributeName);
		return attributeValue;
		
	}

	public static String getUrl(String xml, String elementName) {
		// elementName is Insert or Identify or
		// elementName is quality-payload or insert-payload or identify-payload
		SAXReader reader = new SAXReader();
		Document document = null;
		try {
			document = reader.read(new ByteArrayInputStream(xml.getBytes("UTF-8")));
		} catch (DocumentException | UnsupportedEncodingException e) {
			throw new XmlException(e.getMessage(), e.getCause());
		}
		Element rootElement = document.getRootElement();
		Element element = rootElement.element(elementName);
		String url = element.attributeValue(URL);
		return url;
	}	
	
	public static String dom4jCreateResponseXml(String requestId , String success, String failureReason) throws IOException {
		 Document document = DocumentHelper.createDocument();
		 Element root = document.addElement("Response")
				 .addAttribute("requestId", requestId)
				 .addAttribute("timeStamp", String.valueOf(System.currentTimeMillis()));
		 root.addElement("Return").addAttribute("value", success).addAttribute("failureReason", failureReason);
		 OutputFormat format = OutputFormat.createPrettyPrint();
		 StringWriter sw = new StringWriter();
        XMLWriter writer  = new XMLWriter(sw, format);        
        writer.write(document);
        String resuslt = sw.toString();		 
		return resuslt;		
		
	}
	
	public static UidAimAmqResponse buildFaildXmlReespose(String requestId, String failureReason) throws IOException  {
		UidAimAmqResponse response = new UidAimAmqResponse();
		String xmlRes = dom4jCreateFaildXml(requestId, failureReason);	
		response.setRequestId(requestId);
		response.setXmlResult(xmlRes);
		return response;
	}
	
	public static String dom4jCreateFaildXml(String requestId , String failureReason) throws IOException {
		 Document document = DocumentHelper.createDocument();
		 Element root = document.addElement( "Response")
				 .addAttribute("requestId", requestId)
				 .addAttribute("timeStamp", String.valueOf(System.currentTimeMillis()));
		 root.addElement("Return").addAttribute("value", String.valueOf("2")).addAttribute("failureReason", failureReason);
		 OutputFormat format = OutputFormat.createPrettyPrint();
		 StringWriter sw = new StringWriter();
       XMLWriter writer  = new XMLWriter(sw, format);        
       writer.write(document);
       String resuslt = sw.toString();		 
		return resuslt;		
	}
	
	public static String buildExtractPayload(String refId, String url) throws IOException {
		 Document document = DocumentHelper.createDocument();
		 document.addElement( "quality-payload")
				 .addAttribute("referenceId", refId)
				 .addAttribute("referenceUrl", url);
		 OutputFormat format = OutputFormat.createPrettyPrint();
		 StringWriter sw = new StringWriter();
        XMLWriter writer  = new XMLWriter(sw, format);        
        writer.write(document);
        String resuslt = sw.toString();		 
		return resuslt;
	}
	
	public static String buildInquiryRequest(String requeustid, String refId, String url) throws IOException {
		 Document document = DocumentHelper.createDocument();
		 Element root = document.addElement("Request");
		 root.addElement("Identify")
				 .addAttribute("referenceId", refId)
				 .addAttribute("referenceUrl", url)
				 .addAttribute("maxResults", "10")
				 .addAttribute("targetFPIR", "1")
				 .addAttribute("targetModalityFPIR", "1")
				 .addAttribute("dedupModalityInstance", "1")
				 .addAttribute("missingBiometric", "1")
				 .addAttribute("fullsearch", "false");	
		 root.addAttribute("timeStamp", String.valueOf(System.currentTimeMillis()))
		     .addAttribute("version", "1")
		     .addAttribute("rrequestId", requeustid);		 
		 
		 OutputFormat format = OutputFormat.createPrettyPrint();
		 StringWriter sw = new StringWriter();
        XMLWriter writer  = new XMLWriter(sw, format);        
        writer.write(document);
        String resuslt = sw.toString();		 
		return resuslt;		
	}
	
	public static String buildDeleteRequest(String requeustid,String refId) throws IOException {
		 Document document = DocumentHelper.createDocument();
		 Element root = document.addElement("Request");
		 root.addElement("Delete")
				 .addAttribute("referenceId", refId);		
		 root.addAttribute("timeStamp", String.valueOf(System.currentTimeMillis()))
		     .addAttribute("version", "1")
		     .addAttribute("rrequestId", requeustid);	
		 OutputFormat format = OutputFormat.createPrettyPrint();
		 StringWriter sw = new StringWriter();
        XMLWriter writer  = new XMLWriter(sw, format);        
        writer.write(document);
        String resuslt = sw.toString();		 
		return resuslt;		
		
	}
}
