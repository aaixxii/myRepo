package jp.co.nec.aim.mm.identify.planner;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;

@Entity
@Table(name = "MuCpuAndPressure")
@SqlResultSetMapping(name = "muCpuAndPressure", classes = { @ConstructorResult(targetClass = MuCpuAndPressure.class, columns = {
		@ColumnResult(name = "muId"), @ColumnResult(name = "ability"),
		@ColumnResult(name = "preessure"), @ColumnResult(name = "report_ts") }) })
public class MuCpuAndPressure implements Serializable {
	private static final long serialVersionUID = 4799701678131672576L;
	@Id
	@Column(name = "muId")
	private int muId;
	@Column(name = "ability")
	private double ability;
	@Column(name = "preessure")
	private long pressure;
	@Column(name = "report_ts")
	private long reportTs;

	public int getMuId() {
		return muId;
	}

	public void setMuId(int muId) {
		this.muId = muId;
	}

	public double getAbility() {
		return ability;
	}

	public void setAbility(double ability) {
		this.ability = ability;
	}

	public long getPressure() {
		return pressure;
	}

	public void setPressure(long pressure) {
		this.pressure = pressure;
	}

	public long getReportTs() {
		return reportTs;
	}

	public void setReportTs(long reportTs) {
		this.reportTs = reportTs;
	}
}
