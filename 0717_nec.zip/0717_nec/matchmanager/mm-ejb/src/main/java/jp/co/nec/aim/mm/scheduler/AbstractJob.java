package jp.co.nec.aim.mm.scheduler;

import javax.persistence.EntityManager;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.constants.JNDIConstants;
import jp.co.nec.aim.mm.constants.SchedulerEnum;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.sessionbeans.PollBean;
import jp.co.nec.aim.mm.util.JndiLookup;

import org.jboss.logging.NDC;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author jinxl
 * 
 */
public abstract class AbstractJob implements Job {
	private static final Logger log = LoggerFactory
			.getLogger(AbstractJob.class);
	private CommonBean commonBean;
	public PollBean pollBean;
	protected EntityManager entityManager;
	private DataSource dataSource;
	private DateDao dateDao;

	/**
	 * AbstractJob
	 */
	public AbstractJob() {
		commonBean = JndiLookup.lookUp(JNDIConstants.COMMONBEAN,
				CommonBean.class);

		entityManager = JndiLookup.lookUp(JNDIConstants.EntityManagerName,
				EntityManager.class);
		dataSource = JndiLookup.lookUp(JNDIConstants.DataSourceName,DataSource.class);
		pollBean = JndiLookup.lookUp(JNDIConstants.POLLBEAN, PollBean.class);
		dateDao = new DateDao(dataSource); 
	}

	/**
	 * execute
	 */
	public void execute(JobExecutionContext context)
			throws JobExecutionException {
		if (log.isDebugEnabled()) {
			log.debug("execute() of " + this.getClass().getName()
					+ " is called.");
		}
		/* find current scheduler */
		SchedulerEnum schedulerenum = SchedulerEnum.findJob(this.getClass());
		/* set currentTimemillis */
		schedulerenum.setCurrentTime(dateDao.getCurrentTimeMS());
		
		try {
			NDC.push(getTitle());
			/* call CommonBean's canIDoIt */
			boolean canIDoIt = commonBean.canIDoIt(schedulerenum);

			/* bcanIdoit is false */
			if (!canIDoIt) {
				if (log.isDebugEnabled()) {
					log.debug("I can not do poll.");
				}
				return;
			}

			/* bupdateLastTimeStamp is false */
			if (!commonBean.updateLastTimeStamp(schedulerenum)) {
				if (log.isDebugEnabled()) {
					log.debug("I can not update Last TimeStamp.");
				}
				return;
			}

			/* call executeJob */
			executeJob(context);
		} finally {

			/* set currentTimemillis */
			schedulerenum.setCurrentTime(dateDao.getCurrentTimeMS());
			/* call CommonBean's checkAndRescheduleJob */
			SchedulerEnum schekuler = SchedulerEnum.findJob(this.getClass());
			commonBean.checkAndRescheduleJob(schekuler);
			NDC.clear();
		}
	}

	public abstract void executeJob(JobExecutionContext context)
			throws JobExecutionException;

	protected abstract String getTitle();	

}
