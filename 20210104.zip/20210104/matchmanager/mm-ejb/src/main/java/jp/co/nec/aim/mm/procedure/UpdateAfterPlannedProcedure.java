package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

/**
 *
 * @author xiazp
 *
 */
public class UpdateAfterPlannedProcedure extends StoredProcedure {
	private static final String UPDATE_AFTER_PLANNED = "update_after_planned";

	public UpdateAfterPlannedProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(UPDATE_AFTER_PLANNED);
		declareParameter(new SqlParameter("p_job_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_container_job_id", Types.BIGINT));
		declareParameter(new SqlOutParameter("r_job_id", Types.BIGINT));
		compile();
	}

	/**
	 * @param topJobId
	 * @param contaierId
	 * @param fucntonId
	 * @param planString
	 * @return
	 * @throws DataAccessException
	 * @throws SQLException
	 */
	public Long executeUpdate(Long topJobId, Long containerJobId) throws DataAccessException, SQLException {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_job_id", topJobId);
		map.put("p_container_job_id", containerJobId);
		Map<String, Object> resultMap = execute(map);
		Long jobId = (Long) resultMap.get("r_job_id");
		return jobId;
	}
}
