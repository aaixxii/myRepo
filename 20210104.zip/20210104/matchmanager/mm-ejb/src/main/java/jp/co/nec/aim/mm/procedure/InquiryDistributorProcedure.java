package jp.co.nec.aim.mm.procedure;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import jp.co.nec.aim.mm.identify.dispatch.InqDispatchInfo;
import jp.co.nec.aim.mm.util.CollectionsUtil;

/**
 * InquiryDistributorProcedure
 *
 * @author liuyq
 *
 */
public class InquiryDistributorProcedure extends StoredProcedure {
	private JdbcTemplate jdbcTemplate;
	private static final String SQL = "get_inquiry_distributor_info";
	private Long jobId;
	private Integer functionId;

	/**
	 * InquiryDistributorProcedure
	 *
	 * @param dataSource
	 */
	public InquiryDistributorProcedure(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
		setDataSource(dataSource);
		setSql(SQL);
		declareParameter(new SqlParameter("p_job_id", Types.BIGINT));
		declareParameter(new SqlParameter("p_function_id", Types.INTEGER));
		declareParameter(new SqlOutParameter("tab_name", Types.VARCHAR));
		compile();
	}

	/**
	 * execute
	 *
	 * @return InqDistributorInfo instance
	 */
	public InqDispatchInfo execute() {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_job_id", getJobId());
		map.put("p_function_id", getFunctionId());
		Map<String, Object> resultMap = execute(map);
		String tableName = (String) resultMap.get("tab_name");
		if (StringUtils.isBlank(tableName))
			return null;
		String sql = "select * from " + tableName;
		List<Map<String, Object>> result = jdbcTemplate.queryForList(sql);
		List<InqDispatchInfo> iqyDispatchInfo = new ArrayList<>();
		result.forEach(one -> {
			int failureCount = (int) one.get("failure_count");
			int searchReqIdx = (int) one.get("search_req_idx");
			String jqyXml = (String) one.get("inquiry_lob_xml");
			byte[] iqyJobData = (byte[]) one.get("inquiry_job_data");
			long containerJobTimeout = (long) one.get("container_job_timeout");
			// int internalCadidateSize = (int) one.get("internal_candidate_size");
			long containerJobId = (long) one.get("container_job_id");
			InqDispatchInfo info = new InqDispatchInfo();
			info.setMessageSequence(failureCount);
			info.setRequestIndex(searchReqIdx);
			info.setInquiryRequstXml(jqyXml);
			info.setInquiryData(iqyJobData);
			info.setJobTimeout(containerJobTimeout);
			// info.setInternalMaxCandidates(internalCadidateSize);
			info.setContainerJobId(containerJobId);
			iqyDispatchInfo.add(info);
		});
		if (CollectionsUtil.isEmpty(iqyDispatchInfo)) {
			return null;
		} else {
			return CollectionsUtil.getFirst(iqyDispatchInfo);
		}
	}

	public Long getJobId() {
		return jobId;
	}

	public void setJobId(Long jobId) {
		this.jobId = jobId;
	}

	public Integer getFunctionId() {
		return functionId;
	}

	public void setFunctionId(Integer functionId) {
		this.functionId = functionId;
	}

	/**
	 * CursorMapper
	 *
	 * @author liuyq
	 *
	 */
	@SuppressWarnings("unused")
	private class CursorMapper implements RowMapper<InqDispatchInfo> {
		@Override
		public InqDispatchInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
			final InqDispatchInfo info = new InqDispatchInfo();
			info.setMessageSequence(rs.getInt("failure_count"));
			info.setRequestIndex(rs.getInt("search_request_index"));
			info.setInquiryData(rs.getBytes("inquiry_job_data"));
			info.setJobTimeout(rs.getLong("container_job_timeouts"));
			// info.setInternalMaxCandidates(rs.getInt("internal_candidate_size"));
			info.setContainerJobId(rs.getInt("container_job_id"));
			return info;

		}
	}

}
