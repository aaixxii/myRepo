package jp.co.nec.aim.mm.sessionbeans;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.UncategorizedSQLException;

import jp.co.nec.aim.mm.dao.PartitionDao;
import jp.co.nec.aim.mm.dao.SystemInitDao;
import jp.co.nec.aim.mm.partition.PartitionUtil;
import jp.co.nec.aim.mm.sessionbeans.pojo.AimManager;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class RotationTaskBean {

	private static final Logger logger = LoggerFactory.getLogger(RotationTaskBean.class);

	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;

	private PartitionDao partitionDao;
	private SystemInitDao systemInitDao;

	public RotationTaskBean() {
	}

	@PostConstruct
	public void init() {
		partitionDao = new PartitionDao(dataSource);
		systemInitDao = new SystemInitDao(manager);
	}

	public void createNextPartitionAndClearBefore() {
		String deleteFlag = systemInitDao.getClearFlag();
		if (deleteFlag.toUpperCase().equals("TRUE")) {
			Long saveDaysInMyMem = AimManager.getSegChangeSaveDays();
			Long saveDays = systemInitDao.getSegChangeLogSaveDays();

			// Redmine #19238
			if (saveDays - saveDaysInMyMem > 0) {
				doAdd(saveDaysInMyMem, saveDays);
				saveDaysInMyMem = AimManager.getSegChangeSaveDays();
			} else if (saveDays - saveDaysInMyMem < 0) {
				doReduce(saveDays, saveDaysInMyMem);
				saveDaysInMyMem = AimManager.getSegChangeSaveDays();
			}

			LocalDate now = LocalDate.now();
			LocalDate targetAddDay = now.plusDays(1L);
			long targetAddPno = PartitionUtil.getInstance().caculateHashAtThisToday(targetAddDay);
			LocalDate targetClearDay = now.minusDays(saveDaysInMyMem - 1);
			long targetClearPno = PartitionUtil.getInstance().caculateHashAtThisToday(targetClearDay);
			try {
				try {
					partitionDao.deleteOldPartition(targetClearPno);
					logger.info("Success drop partition for day({}), pNo({})", targetClearDay, targetClearPno);
				} catch (UncategorizedSQLException e) {
					if (e.getSQLException().getErrorCode() == 1507) {
						logger.warn("pNo {} partition is not exist. skip drop partition...", targetClearPno);
					} else {
						throw e;
					}
				}
				try {
					partitionDao.addNewPartition(targetAddPno);
					logger.info("Success add new  partition for day({}), pNo({})", targetAddDay, targetAddPno);
				} catch (UncategorizedSQLException e) {
					if (e.getSQLException().getErrorCode() == 1517) {
						logger.warn("pNo {} partition is exist. skip create new partition...", targetAddPno);
					} else {
						throw e;
					}
				}
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		}
	}

	private void doAdd(Long oldSaveDays, Long newSaveDays) {
		PartitionUtil partitionUtil = PartitionUtil.getInstance();
		LocalDate updateAtToday = LocalDate.now();
		long adjust = partitionUtil.caculateNewAdjustAtThisDay(newSaveDays, oldSaveDays, updateAtToday);
		logger.info("new adjust value is {}", adjust);
		systemInitDao.updateInUsingAdjuist(adjust);
		AimManager.saveSegChangeSaveDays(newSaveDays);
		AimManager.saveInUsingAdjust(adjust);
		List<Long> toBeAddPno = new ArrayList<>();
		for (long i = oldSaveDays; i < newSaveDays; i++) {
			try {
				toBeAddPno.add(Long.valueOf(i));
				partitionDao.createNewPartition(i);
			} catch (UncategorizedSQLException e) {
				if (e.getSQLException().getErrorCode() == 1517) {
					logger.warn("pNo {} partition is exist. skip create new partition...", i);
				} else {
					throw e;
				}
			}
		}
		String str = toBeAddPno.stream().map(one -> one.toString()).collect(Collectors.joining(","));
		logger.info("Added partitions {}", str);

	}

	private void doReduce(Long newNo, Long oldSaveDays) {
		PartitionUtil partitionUtil = PartitionUtil.getInstance();
		LocalDate now = LocalDate.now();
		long hashValueOnNow = partitionUtil.caculateHashAtThisToday(now);
		// Redmine #19238
		if (newNo - 1 == hashValueOnNow) {
			long diffOnTodayToMaxDay = oldSaveDays - hashValueOnNow;
			LocalDate maxDay = now.plusDays(diffOnTodayToMaxDay);
			long diffOnNewDayToMaxDay = oldSaveDays - newNo > 0 ? oldSaveDays - newNo : -1 * (oldSaveDays - newNo);
			LocalDate firstUpdateDay = maxDay.minusDays(diffOnNewDayToMaxDay);
			LocalDate epoch = LocalDate.ofEpochDay(0);
			long epochDays = ChronoUnit.DAYS.between(epoch, firstUpdateDay);
			long adjust = partitionUtil.caculateNewAdjustAtThisDay(newNo, oldSaveDays, firstUpdateDay);
			long newHashValue = (epochDays + adjust) % newNo;
			logger.info("new hash value is {}", newHashValue);
			systemInitDao.updateInUsingAdjuist(adjust);
			AimManager.saveSegChangeSaveDays(newNo);
			AimManager.saveInUsingAdjust(adjust);
			dropUnusedPartition(newNo);
		} else {
			logger.info(
					"SEGMENT_CHANGE_LOG_SAVE_DAYS A decrease change was detected, but it is not the update timing, so the update is skipped.");
		}
	}

	private void dropUnusedPartition(Long newSaveDays) {
		logger.info("Check for unused partitions exist...");
		String dropPNos = partitionDao.dropUnusedPartition(newSaveDays);
		if (dropPNos.length() == 0) {
			logger.info("Unused partitions does not exist.");
		} else {
			logger.info("Drop unused partition:{}", dropPNos);
		}
	}

}
