package jp.co.nec.aim.mm.constants;

/**
 * 
 * ErrorMessage
 * 
 * @author liuyq
 * 
 */
public class InfoMessage {
	public static final String COMPONENT_ENTER_INFO = "%s %s Successfully entered.";
	public static final String COMPONENT_EXIT_INFO = "%s %s -> State EXITED.";
	public static final String MM_START_UP_INFO = "Match Manager on %s started up.";

}
