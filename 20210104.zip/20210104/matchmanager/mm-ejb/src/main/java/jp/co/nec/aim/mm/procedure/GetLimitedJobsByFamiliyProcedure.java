package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.object.StoredProcedure;

/**
 *
 * @author xiazp
 *
 */
public class GetLimitedJobsByFamiliyProcedure extends StoredProcedure {
	private JdbcTemplate jdbcTemplate;
	private static final String GET_LIMITED_JOBS_BY_FAMILIY = "get_limited_num";

	public GetLimitedJobsByFamiliyProcedure(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
		setDataSource(dataSource);
		setSql(GET_LIMITED_JOBS_BY_FAMILIY);
		declareParameter(new SqlOutParameter("r_limit", Types.BIGINT));
		compile();
	}

	/**
	 *
	 * @return
	 * @throws DataAccessException
	 * @throws SQLException
	 */
	public List<Long> getLimitedJobsByFamiliy() throws DataAccessException, SQLException {
		Map<String, Object> map = new HashMap<String, Object>();
		Map<String, Object> resultMap = execute(map);
		Long limit = (Long) resultMap.get("r_limit");
		if (limit == null)
			return null;
		String sql = "SELECT JOB_ID FROM JOB_QUEUE WHERE FAMILY_ID = 1 AND JOB_STATE = 0"
				+ " ORDER BY PRIORITY, FAILURE_COUNT DESC, JOB_ID LIMIT " + limit.toString();
		List<Long> jobIds = jdbcTemplate.queryForList(sql, Long.class);
		return jobIds;
	}
}
