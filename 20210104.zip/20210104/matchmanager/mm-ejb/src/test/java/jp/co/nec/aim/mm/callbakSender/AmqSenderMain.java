package jp.co.nec.aim.mm.callbakSender;

public class AmqSenderMain {	

	public static void main(String[] args) {
		String sendMsg = "11112222333344445556667777";
		SocketSenderMocker sender = new SocketSenderMocker("127.0.0.1", 8888, sendMsg.getBytes());
		Thread task = new Thread(sender);
		task.start();
	}
	

}
