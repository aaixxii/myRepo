package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.nec.aim.dm.dmservice.DmserviceApplication;
import com.nec.aim.dm.dmservice.entity.StorageBox;

@RunWith(SpringRunner.class)  
@SpringBootTest(classes={DmserviceApplication.class})
public class NodeStorageRepositoryImplTest {
	
	@Autowired
	NodeStorageManagerRepository nodeStorageRepository;
	
	@Autowired
    private JdbcTemplate jdbcTemplate;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	@Transactional
	public void testFindAll() throws SQLException {
		List<StorageBox> nodeStorages = nodeStorageRepository.findAll();
		Assert.assertEquals(3, nodeStorages.size());
	}

	@Test
	@Transactional
	public void testFindById() throws SQLException {
		StorageBox result = nodeStorageRepository.findById(3L, "dm_storage3");
		Assert.assertEquals(3, result.getNsmId().intValue());
	}

	@Test
	@Transactional
	public void testFindNeedNodeByRedundancy() throws SQLException {
		List<StorageBox> result = nodeStorageRepository.findNeedNodeByRedundancy(3);
		Assert.assertEquals(3, result.size());
	}

	@Test
	@Transactional
	public void testSetSignalMailFlag() {
		nodeStorageRepository.setSignalMailFlag(1);
		String sql = "select * from node_storage where sb_id = 1 ";
		Map<String, Object> result = jdbcTemplate.queryForMap(sql);
		String mailFalg = (String) result.get("mail_flag");
		Assert.assertEquals("signal", mailFalg);		
	}

}
