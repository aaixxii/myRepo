package com.nec.aim.dm.dmservice.dispatch;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

import javax.sql.rowset.serial.SerialException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import com.nec.aim.dm.dmservice.config.ConfigProperties;
import com.nec.aim.dm.dmservice.constants.SbSegmentsStatusEnum;
import com.nec.aim.dm.dmservice.entity.SegmentInfo;
import com.nec.aim.dm.dmservice.entity.SegmentLoading;
import com.nec.aim.dm.dmservice.entity.StorageBox;
import com.nec.aim.dm.dmservice.exception.DmServiceException;
import com.nec.aim.dm.dmservice.log.PerformanceLogger;
import com.nec.aim.dm.dmservice.persistence.CommitDao;
import com.nec.aim.dm.dmservice.persistence.DmConfigRepository;
import com.nec.aim.dm.dmservice.persistence.NodeStorageManagerRepository;
import com.nec.aim.dm.dmservice.persistence.SegmentLoadRepository;
import com.nec.aim.dm.dmservice.persistence.SegmentRepository;
import com.nec.aim.dm.dmservice.post.HttpPoster;

import jp.co.nec.aim.dm.message.proto.AimDmMessages.PBDmSyncRequest;
import jp.co.nec.aim.dm.message.proto.AimDmMessages.PBTemplateInfo;
import jp.co.nec.aim.dm.message.proto.AimDmMessages.SegmentSyncCommandType;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class Dispatcher {

	@Autowired
	NodeStorageManagerRepository nodeRepository;

	@Autowired
	DmConfigRepository dmConfigRepository;

	@Autowired
	SegmentLoadRepository segmentLoadRepository;

	@Autowired
	SegmentRepository segmentRepository;

	@Autowired
	CommitDao commitDao;

	@Autowired
	ConfigProperties config;

	private ReentrantLock syncLock = new ReentrantLock();

	private enum function {
		NEW, INSERT, DELETE;
	}

	/**
	 * @param activeNodeStorages
	 * @param dmSegReq
	 * @param segInfo
	 * @return
	 */
	public boolean handlePostRequest(List<StorageBox> activeNodeStorages, String syncMode, PBDmSyncRequest dmSegReq,
			SegmentInfo segInfo) {
		String changeType = dmSegReq.getCmd().name().toUpperCase();
		boolean mmReturnValue = true;
		try {
			if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_NEW.name())) { // add segment
				mmReturnValue = processNewSegment(activeNodeStorages, syncMode, segInfo, dmSegReq);
			} else {
				if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT.name())) {
					mmReturnValue = processTempalteInsert(activeNodeStorages, syncMode, segInfo, dmSegReq);
				} else if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE.name())) {
					try {
						if (syncLock.tryLock(100, TimeUnit.MILLISECONDS)) {
							try {
								mmReturnValue = processTempalteDelete(activeNodeStorages, syncMode, segInfo, dmSegReq);
							} finally {
								syncLock.unlock();
							}
						}
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		} catch (SQLException e) {
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			log.error(e.getMessage());
		}
		return mmReturnValue;
	}

	/**
	 * @param changeType
	 * @param segId
	 * @return
	 */
	public List<StorageBox> getActiveNodeStorages(String changeType, Long segId) {
		StopWatch t = new StopWatch();
		t.start();
		List<StorageBox> activeNodeStorages = new ArrayList<>();
		int redundancy = DmServiceManager.getRedundancy().get();
		if (redundancy < 1) {
			log.warn("redundancy is less 1!");
			return activeNodeStorages;
		}
		try {
			if (changeType.equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_NEW.name())) {
				activeNodeStorages = nodeRepository.findNeedNodeByRedundancy(redundancy);
				if (null == activeNodeStorages || activeNodeStorages.size() < 1) {
					log.warn("No active node storages! skip process and return.");
				}
			} else {
				activeNodeStorages = nodeRepository.getNodeStorgeBySegmentId(segId, Integer.valueOf(redundancy));
				if (activeNodeStorages == null || activeNodeStorages.size() < 1) {
					log.warn("No active storage manager which asigned semgent({}). Can't continue process.", segId);
				}
			}
			log.info("activeNodeStorages = {}", activeNodeStorages.size());
			t.stop();
			PerformanceLogger.trace(this.getClass().getSimpleName(), "getActiveNodeStorages", segId.toString(), null,
					t.elapsedTime());
		} catch (SQLException e) {
			log.error(e.getMessage());
		}
		return activeNodeStorages;
	}

	public String getDmSyncMode() throws SQLException {
		return dmConfigRepository.getSyncMode();
	}

	/**
	 * @param activeNodeStorages
	 * @param segInfo
	 * @param dmSegReq
	 * @return
	 * @throws SQLException
	 */
	public boolean processNewSegment(List<StorageBox> activeNodeStorages, String syncMode, SegmentInfo segInfo,
			PBDmSyncRequest dmSegReq) throws SQLException {
		StopWatch t = new StopWatch();
		t.start();
		checkInfo(segInfo, dmSegReq, function.NEW);
		ReturnCheckFlags checkFlags = new ReturnCheckFlags();
		SegmentLoading segLoading = new SegmentLoading();
		segLoading.setSegmentId(segInfo.getSegmentId());
		segInfo.setVersion(-1L);
		segLoading.setLastVersion(-1L);
		try {
			segmentRepository.insertSegment(segInfo);
			boolean segmentUpdateSuccess = true;
			checkFlags.setLastSegmentUpdateSuccess(checkFlags.isLastSegmentUpdateSuccess() && segmentUpdateSuccess);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			boolean segmentUpdateSuccess = false;
			checkFlags.setLastSegmentUpdateSuccess(checkFlags.isLastSegmentUpdateSuccess() && segmentUpdateSuccess);
		}
		for (int i = 0; i < activeNodeStorages.size(); i++) {
			StorageBox sb = activeNodeStorages.get(i);
			segLoading.setNsmId(sb.getNsmId());
			segLoading.setStatus(SbSegmentsStatusEnum.CREATED.toString());
			try {
				segmentLoadRepository.insertSegmentLoad(segLoading);
				boolean segmentLoadUpdateSuccess = true;
				checkFlags.setLastSegmentLoadUpdateSuccess(
						checkFlags.isLastSegmentLoadUpdateSuccess() && segmentLoadUpdateSuccess);
			} catch (Exception e) {
				log.error(e.getMessage(), e);
				boolean segmentLoadUpdateSuccess = false;
				checkFlags.setLastSegmentLoadUpdateSuccess(
						checkFlags.isLastSegmentLoadUpdateSuccess() && segmentLoadUpdateSuccess);
			}
			String nodeUrl = DmServiceManager.getValueFromNodeStorageUrlMap(sb.getNsmId());
			nodeUrl = nodeUrl + config.getNsmWebContent() + config.getNsmSyncMethod();
			log.debug("post url is {}", nodeUrl);
			Boolean result = HttpPoster.post(nodeUrl, dmSegReq);
			if (result.booleanValue()) {
				try {
					if (segInfo.getVersion() == -1L) {
						segmentRepository.updateAfterNew(-1, segInfo.getSegmentId());
					} else if (segInfo.getVersion() == 0L) {
						segmentRepository.updateAfterNew(0, segInfo.getSegmentId());
					}
					boolean segmentLoadUpdateSuccess = true;
					checkFlags.setLastSegmentLoadUpdateSuccess(
							checkFlags.isLastSegmentLoadUpdateSuccess() && segmentLoadUpdateSuccess);
				} catch (Exception e) {
					log.error(e.getMessage(), e);
					checkFlags.setMustSetMailFlag(true);
					boolean segmentLoadUpdateSuccess = false;
					checkFlags.setLastSegmentLoadUpdateSuccess(
							checkFlags.isLastSegmentLoadUpdateSuccess() && segmentLoadUpdateSuccess);
				}
			} else {
				try {
					segmentLoadRepository.updateAfterNew(-9, sb.getNsmId(), segInfo.getSegmentId());
					boolean segmentLoadUpdateSuccess = true;
					checkFlags.setLastSegmentLoadUpdateSuccess(
							checkFlags.isLastSegmentLoadUpdateSuccess() && segmentLoadUpdateSuccess);
				} catch (Exception e) {
					log.error(e.getMessage(), e);
					boolean segmentLoadUpdateSuccess = false;
					checkFlags.setLastSegmentLoadUpdateSuccess(
							checkFlags.isLastSegmentLoadUpdateSuccess() && segmentLoadUpdateSuccess);
				}
				checkFlags.setMustSetMailFlag(true);
			}

			if (checkFlags.isMustSetMailFlag()) {
				try {
					segmentRepository.updateAfterNew(0, segInfo.getSegmentId());
					nodeRepository.setSignalMailFlag(sb.getNsmId());
				} catch (Exception e) {
					log.error(e.getMessage(), e);
					TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
				}
			}
			checkFlags.setMmAnyReturnValue(checkFlags.isMmAnyReturnValue() || result.booleanValue());
			checkFlags.setMmAllReturnValue(checkFlags.isMmAllReturnValue() && result.booleanValue());
			if (!checkFlags.isLastSegmentUpdateSuccess() || !checkFlags.isLastSegmentLoadUpdateSuccess()) {
				commitDao.rollback();
			}
			checkFlags.setMustSetMailFlag(false);
		} // end loop
		boolean mmLastReturnValue = judgment(checkFlags, syncMode);
		t.stop();
		PerformanceLogger.trace(this.getClass().getSimpleName(), "processNewSegment", segInfo.getSegmentId().toString(),
				segInfo.getBioIdEnd().toString(), t.elapsedTime());
		return mmLastReturnValue;
	}

	/**
	 * @param targetNodeStorages
	 * @param segInfo
	 * @param dmSegReq
	 * @return
	 * @throws SerialException
	 * @throws SQLException
	 */
	public boolean processTempalteInsert(List<StorageBox> targetNodeStorages, String syncMode, SegmentInfo segInfo,
			PBDmSyncRequest dmSegReq) throws SerialException, SQLException {
		StopWatch t = new StopWatch();
		t.start();

		checkInfo(segInfo, dmSegReq, function.INSERT);
		ReturnCheckFlags checkFlags = new ReturnCheckFlags();

		SegmentLoading segLoading = new SegmentLoading();
		segLoading.setSegmentId(segInfo.getSegmentId());
		boolean needUpdateSegement = true;
		for (int i = 0; i < targetNodeStorages.size(); i++) {
			StorageBox sb = targetNodeStorages.get(i);
			segLoading.setNsmId(sb.getNsmId());
			Boolean result = null;
			long sbSegmentVersion = -9999;
			try {
				sbSegmentVersion = segmentLoadRepository.getLastVersion(sb.getNsmId(), segInfo.getSegmentId());
			} catch (Exception e) {
				log.error("An unexpected exception has occurred when get last version SB_ID:{}, SEGMENT_ID:{}",
						sb.getNsmId(), segInfo.getSegmentId(), e);
				checkFlags.setMustSetMailFlag(true);
				checkFlags.setLastSegmentLoadUpdateSuccess(false);
			}

			if (needUpdateSegement) {
				checkFlags.setLastSegmentUpdateSuccess(updateSegment(segInfo));
				needUpdateSegement = !checkFlags.isLastSegmentUpdateSuccess();
			}

			if (sbSegmentVersion != -9999) {
				if (segInfo.getVersion() == sbSegmentVersion + 1) {
					log.info(
							"segment version({}) +1 in sb_segmentstable is equeal the verion from mm,"
									+ "mm notify info segmentId = {}, segmentVersion={}.",
							sbSegmentVersion, segInfo.getSegmentId(), segInfo.getVersion());
					checkFlags = doPost(segInfo, dmSegReq, segLoading, sb, checkFlags);
				} else if (segInfo.getVersion() < sbSegmentVersion + 1) {
					log.warn(
							"segment version({}) +1 in sb_segments table is ahead of mm,"
									+ "mm notify info segmentId = {}, segmentVersion={}, downgrade db segments info...",
							sbSegmentVersion, segInfo.getSegmentId(), segInfo.getVersion());
					checkFlags = doPost(segInfo, dmSegReq, segLoading, sb, checkFlags);
				} else {
					log.warn("mm request segment version is ahead of sb_segments table segment version({}) + 1,"
							+ "mm notify info segmentId = {}, segmentVersion={}, only set mail flag and update dm_segment version...",
							sbSegmentVersion, segInfo.getSegmentId(), segInfo.getVersion());
					// This case Redmine #19347
					for (StorageBox stb : targetNodeStorages) {
						setMailFlag(stb);
					}
					return true;
				}
			}

			if (checkFlags.isMustSetMailFlag()) {
				try {
					nodeRepository.setSignalMailFlag(sb.getNsmId());
				} catch (Exception e) {
					log.error(e.getMessage(), e);
					TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
				}
			}
			checkFlags.setMmAnyReturnValue(checkFlags.isMmAnyReturnValue() || checkFlags.isPostResult());
			checkFlags.setMmAllReturnValue(checkFlags.isMmAllReturnValue() && checkFlags.isPostResult());
			if (!checkFlags.isLastSegmentUpdateSuccess() || !checkFlags.isLastSegmentLoadUpdateSuccess()) {
				commitDao.rollback();
			}
			// init one sb flag
			checkFlags.setMustSetMailFlag(false);
			checkFlags.setPostResult(false);
		} // end loop
		boolean mmLastReturnValue = judgment(checkFlags, syncMode);
		t.stop();
		PerformanceLogger.trace(this.getClass().getSimpleName(), "processTempalteInsert",
				segInfo.getSegmentId().toString(), segInfo.getBioIdEnd().toString(), t.elapsedTime());
		return mmLastReturnValue;
	}

	/**
	 * @param targetNodeStorages
	 * @param segInfo
	 * @param dmSegReq
	 * @return
	 * @throws SQLException
	 */
	public boolean processTempalteDelete(List<StorageBox> targetNodeStorages, String syncMode, SegmentInfo segInfo,
			PBDmSyncRequest dmSegReq) throws SQLException {
		StopWatch t = new StopWatch();
		t.start();

		checkInfo(segInfo, dmSegReq, function.DELETE);
		ReturnCheckFlags checkFlags = new ReturnCheckFlags();
		SegmentLoading segLoading = new SegmentLoading();
		segLoading.setSegmentId(segInfo.getSegmentId());

		boolean needUpdateSegement = true;
		for (int i = 0; i < targetNodeStorages.size(); i++) {
			StorageBox sb = targetNodeStorages.get(i);
			segLoading.setNsmId(sb.getNsmId());
			long sbSegmentVersion = -9999;
			try {
				sbSegmentVersion = segmentLoadRepository.getLastVersion(sb.getNsmId(), segInfo.getSegmentId());
			} catch (Exception e) {
				log.error("An unexpected exception has occurred when get last version SB_ID:{}, SEGMENT_ID:{}",
						sb.getNsmId(), segInfo.getSegmentId(), e);
				checkFlags.setMustSetMailFlag(true);
				checkFlags.setLastSegmentLoadUpdateSuccess(false);
			}

			if (needUpdateSegement) {
				checkFlags.setLastSegmentUpdateSuccess(updateSegment(segInfo));
				needUpdateSegement = !checkFlags.isLastSegmentUpdateSuccess();
			}

			if (sbSegmentVersion != -9999) {
				if (segInfo.getVersion() == sbSegmentVersion + 1) {
					log.info(
							"segment version({}) +1 in sb_segmentstable is equeal the verion from mm,"
									+ "mm notify info segmentId = {}, segmentVersion={}.",
							sbSegmentVersion, segInfo.getSegmentId(), segInfo.getVersion());
					checkFlags = doPost(segInfo, dmSegReq, segLoading, sb, checkFlags);
				} else if (segInfo.getVersion() < sbSegmentVersion + 1) {
					log.warn(
							"segment version({}) +1 in sb_segments table is ahead of mm,"
									+ "mm notify info segmentId = {}, segmentVersion={}, downgrade db segments info...",
							sbSegmentVersion, segInfo.getSegmentId(), segInfo.getVersion());
					checkFlags = doPost(segInfo, dmSegReq, segLoading, sb, checkFlags);
				} else {
					log.warn("mm request segment version is ahead of sb_segments table segment version({}) + 1,"
							+ "mm notify info segmentId = {}, segmentVersion={}, only set mail flag and update dm_segment version...",
							sbSegmentVersion, segInfo.getSegmentId(), segInfo.getVersion());
					// This case Redmine #19347
					for (StorageBox stb : targetNodeStorages) {
						setMailFlag(stb);
					}
					return true;
				}
			}

			if (checkFlags.isMustSetMailFlag()) {
				try {
					nodeRepository.setSignalMailFlag(sb.getNsmId());
				} catch (Exception e) {
					log.error(e.getMessage(), e);
					TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
				}
			}
			checkFlags.setMmAnyReturnValue(checkFlags.isMmAnyReturnValue() || checkFlags.isPostResult());
			checkFlags.setMmAllReturnValue(checkFlags.isMmAllReturnValue() && checkFlags.isPostResult());
			if (!checkFlags.isLastSegmentUpdateSuccess() || !checkFlags.isLastSegmentLoadUpdateSuccess()) {
				commitDao.rollback();
			}
			// init one sb flag
			checkFlags.setMustSetMailFlag(false);
			checkFlags.setPostResult(false);
		} // end loop
		boolean mmLastReturnValue = judgment(checkFlags, syncMode);
		t.stop();
		PerformanceLogger.trace(this.getClass().getSimpleName(), "processTempalteDelete",
				segInfo.getSegmentId().toString(), segInfo.getBioIdEnd().toString(), t.elapsedTime());
		return mmLastReturnValue;
	}

	private void checkInfo(SegmentInfo segInfo, PBDmSyncRequest dmSegReq, function func) {
		switch (func) {
		case NEW:
			if (segInfo.getBioIdStart() == null || segInfo.getBioIdEnd() == null) {
				throw new DmServiceException("In new segment, bio_id_start and bio_id_end can't be null");
			}
			break;
		case INSERT:
			String externalId = null;
			byte[] templateData = null;
			if (dmSegReq.hasTemplateData()) {
				PBTemplateInfo tmpData = dmSegReq.getTemplateData();
				externalId = tmpData.getReferenceId();
				templateData = tmpData.getData().toByteArray();
			}
			if (segInfo.getBioIdEnd() == null || externalId == null || templateData == null) {
				throw new DmServiceException(
						"In insert template,  bio_id_end, external id, template data can't be null");
			}
			break;
		case DELETE:
			if (segInfo.getBioIdEnd() == null) {
				throw new DmServiceException("In delete template, bio_id_end, can't be null");
			}
			break;
		default:
			break;
		}

	}

	private boolean updateSegment(SegmentInfo segInfo) {
		try {
			segmentRepository.updateSegment(segInfo);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	private ReturnCheckFlags doPost(SegmentInfo segInfo, PBDmSyncRequest dmSegReq, SegmentLoading segLoading,
			StorageBox sb, ReturnCheckFlags checkFlags) {
		String nodeUrl = DmServiceManager.getValueFromNodeStorageUrlMap(sb.getNsmId());
		nodeUrl = nodeUrl + config.getNsmWebContent() + config.getNsmSyncMethod();
		log.debug("nodeUrl = {}", nodeUrl);
		checkFlags.setPostResult(HttpPoster.post(nodeUrl, dmSegReq));
		if (checkFlags.isPostResult()) {
			StopWatch t2 = new StopWatch();
			t2.start();
			segLoading.setLastVersion(segInfo.getVersion());
			try {
				segmentLoadRepository.updateSegmentLoadNoMailFlag(segLoading);
				boolean segmentLoadUpdateSuccess = true;
				checkFlags.setLastSegmentLoadUpdateSuccess(
						checkFlags.isLastSegmentLoadUpdateSuccess() && segmentLoadUpdateSuccess);
			} catch (Exception e) {
				checkFlags.setMustSetMailFlag(true);
				boolean segmentLoadUpdateSuccess = false;
				checkFlags.setLastSegmentLoadUpdateSuccess(
						checkFlags.isLastSegmentLoadUpdateSuccess() && segmentLoadUpdateSuccess);
			}

			t2.stop();
			PerformanceLogger.trace(this.getClass().getSimpleName(), "updateSegmentLoadNoMailFlag",
					segInfo.getSegmentId().toString(), segInfo.getBioIdEnd().toString(), t2.elapsedTime());
		} else {
			log.warn("Http poster result is false. segmentId = {}, semgnetVersion = {}. setting mail flag.",
					segInfo.getSegmentId(), segInfo.getVersion());
			checkFlags.setMustSetMailFlag(true);
		}
		return checkFlags;
	}

	private void setMailFlag(StorageBox sb) {
		try {
			nodeRepository.setSignalMailFlag(sb.getNsmId());
		} catch (Exception e) {
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}

	}

	private boolean judgment(ReturnCheckFlags checkFlags, String syncMode) {
		boolean result = false;
		if (syncMode.equals("LOG")) {
			result = checkFlags.isLastSegmentUpdateSuccess() && checkFlags.isLastSegmentLoadUpdateSuccess();
		} else if (syncMode.equals("ANY")) {
			log.info(
					"checkFlags.isLastSegmentUpdateSuccess:{} && checkFlags.isLastSegmentLoadUpdateSuccess:{} && checkFlags.isMmAnyReturnValue:{}",
					checkFlags.isLastSegmentUpdateSuccess(), checkFlags.isLastSegmentLoadUpdateSuccess(),
					checkFlags.isMmAnyReturnValue());
			result = checkFlags.isLastSegmentUpdateSuccess() && checkFlags.isLastSegmentLoadUpdateSuccess()
					&& checkFlags.isMmAnyReturnValue();
		} else if (syncMode.equals("ALL")) {
			result = checkFlags.isLastSegmentUpdateSuccess() && checkFlags.isLastSegmentLoadUpdateSuccess()
					&& checkFlags.isMmAnyReturnValue();
		}
		if (!result) {
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return result;
	}

	public String getNsmUrl(Long segId) {
		StopWatch t = new StopWatch();
		t.start();
		List<StorageBox> activeList = null;
		Integer rdundancy = Integer.valueOf(DmServiceManager.getRedundancy().get());
		try {
			activeList = nodeRepository.getNodeStorgeBySegmentId(segId, rdundancy);
		} catch (SQLException e) {
			log.error(e.getMessage());
		}
		String nodeUrl = null;
		if (activeList != null && activeList.size() > 0) {
			Collections.shuffle(activeList);
			for (int i = 0; i < activeList.size(); i++) {
				nodeUrl = DmServiceManager.getValueFromNodeStorageUrlMap(activeList.get(i).getNsmId());
				if (nodeUrl != null && nodeUrl.length() > 0) {
					nodeUrl = nodeUrl + config.getNsmWebContent() + config.getNsmDownloadMeghod();
					nodeUrl = nodeUrl.endsWith("/") ? nodeUrl : nodeUrl + "/";
					nodeUrl = nodeUrl + segId;
					log.info(nodeUrl);
					break;
				}
			}
		} else {
			log.warn("No active dm stroage node manager for process segmentId({}", segId);
			throw new DmServiceException("No active dm stroage node manager for process segmentId:" + segId);
		}
		return nodeUrl;
	}

	/**
	 * @param segId
	 * @return
	 * @throws InterruptedException
	 * @throws ExecutionException
	 */
	public byte[] dispatchDownloadReqeust(Long segId) throws InterruptedException, ExecutionException {
		StopWatch t = new StopWatch();
		t.start();
		List<StorageBox> activeList = null;
		Integer rdundancy = Integer.valueOf(DmServiceManager.getRedundancy().get());
		try {
			activeList = nodeRepository.getNodeStorgeBySegmentId(segId, rdundancy);
		} catch (SQLException e) {
			log.error(e.getMessage());
		}
		;
		if (activeList == null || activeList.size() < 1) {
			throw new DmServiceException("No active dm stroage node manager for process");
		}
		Collections.shuffle(activeList);
		String nodeUrl = DmServiceManager.getValueFromNodeStorageUrlMap(activeList.get(0).getNsmId());
		nodeUrl = nodeUrl + config.getNsmWebContent() + config.getNsmDownloadMeghod() + segId;
		log.info(nodeUrl);
		byte[] result = HttpPoster.getSegment(nodeUrl, segId);
		if (null == result) {
			throw new DmServiceException("faild to get template from " + nodeUrl + ". segId=" + segId);
		}
		t.stop();
		PerformanceLogger.trace(this.getClass().getSimpleName(), "dispatchDownloadReqeust", segId.toString(), null,
				t.elapsedTime());
		return result;
	}

	private class ReturnCheckFlags {

		boolean mmAnyReturnValue = false;
		boolean mmAllReturnValue = true;
		boolean lastSegmentUpdateSuccess = true;
		boolean lastSegmentLoadUpdateSuccess = true;
		boolean mustSetMailFlag = false;
		boolean postResult = false;

		public boolean isMmAnyReturnValue() {
			return mmAnyReturnValue;
		}

		public void setMmAnyReturnValue(boolean mmAnyReturnValue) {
			this.mmAnyReturnValue = mmAnyReturnValue;
		}

		public boolean isMmAllReturnValue() {
			return mmAllReturnValue;
		}

		public void setMmAllReturnValue(boolean mmAllReturnValue) {
			this.mmAllReturnValue = mmAllReturnValue;
		}

		public boolean isLastSegmentUpdateSuccess() {
			return lastSegmentUpdateSuccess;
		}

		public void setLastSegmentUpdateSuccess(boolean lastSegmentUpdateSuccess) {
			this.lastSegmentUpdateSuccess = lastSegmentUpdateSuccess;
		}

		public boolean isLastSegmentLoadUpdateSuccess() {
			return lastSegmentLoadUpdateSuccess;
		}

		public void setLastSegmentLoadUpdateSuccess(boolean lastSegmentLoadUpdateSuccess) {
			this.lastSegmentLoadUpdateSuccess = lastSegmentLoadUpdateSuccess;
		}

		public boolean isMustSetMailFlag() {
			return mustSetMailFlag;
		}

		public void setMustSetMailFlag(boolean mustSetMailFlag) {
			this.mustSetMailFlag = mustSetMailFlag;
		}

		public boolean isPostResult() {
			return postResult;
		}

		public void setPostResult(boolean postResult) {
			this.postResult = postResult;
		}

	}

}
