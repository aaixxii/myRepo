package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;
import java.util.concurrent.locks.ReentrantLock;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.nec.aim.dm.dmservice.entity.SegmentInfo;

@Repository
public class SegmentRepositoryImpl implements SegmentRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private static final String insertSql = "insert into DM_SEGMENTS(SEGMENT_ID,BIO_ID_START,BIO_ID_END, VERSION , UPDATE_TS) values (?,?,?,?,CURRENT_TIMESTAMP())"
			+ "  ON DUPLICATE KEY UPDATE BIO_ID_START=?, BIO_ID_END=?, VERSION=? , UPDATE_TS=CURRENT_TIMESTAMP();";
	private static final String updateSql = "update DM_SEGMENTS set VERSION = ?, UPDATE_TS = CURRENT_TIMESTAMP() where SEGMENT_ID = ?";
	private static final String updateForSegmentCreatedSql = "update DM_SEGMENTS set VERSION = -1, UPDATE_TS = CURRENT_TIMESTAMP() where SEGMENT_ID = ?";
	private static final String setFaildSegmentVer = "update DM_SEGMENTS set VERSION = -9, UPDATE_TS = CURRENT_TIMESTAMP() where SEGMENT_ID = ?";
	private static final String setSuccessSegmentVer = "update DM_SEGMENTS set VERSION = -1, UPDATE_TS = CURRENT_TIMESTAMP() where SEGMENT_ID = ?";
	private static final String updateAfterNew = "update DM_SEGMENTS set VERSION = ? where SEGMENT_ID = ?";

	private ReentrantLock seglLock = new ReentrantLock();

	@Override
	public void insertSegment(SegmentInfo segInfo) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		jdbcTemplate.update(insertSql,
				new Object[] { segInfo.getSegmentId(), segInfo.getBioIdStart(), segInfo.getBioIdEnd(),
						segInfo.getVersion(), segInfo.getBioIdStart(), segInfo.getBioIdEnd(), segInfo.getVersion() });
	}

	@Override
	public void updateSegment(SegmentInfo segInfo) {
		jdbcTemplate.execute("SET @@autocommit=0");
		if (seglLock.tryLock()) {
			try {
				jdbcTemplate.update(updateSql, new Object[] { segInfo.getVersion(), segInfo.getSegmentId() });
			} finally {
				seglLock.unlock();
			}
		}
	}

	public void updateForSegmentCreated(SegmentInfo segInfo) {
		jdbcTemplate.execute("SET @@autocommit=0");
		if (seglLock.tryLock()) {
			try {
				jdbcTemplate.update(updateForSegmentCreatedSql, new Object[] { segInfo.getSegmentId() });
			} finally {
				seglLock.unlock();
			}
		}
	}

	@Override
	public void setFaildSegmentVer(SegmentInfo segInfo) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		if (seglLock.tryLock()) {
			try {
				jdbcTemplate.update(setFaildSegmentVer, new Object[] { segInfo.getSegmentId() });
			} finally {
				seglLock.unlock();
			}
		}
	}

	@Override
	public void setSuccessSegmentVer(SegmentInfo segInfo) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		if (seglLock.tryLock()) {
			try {
				jdbcTemplate.update(setSuccessSegmentVer, new Object[] { segInfo.getSegmentId() });
			} finally {
				seglLock.unlock();
			}
		}
	}

	@Override
	public void updateAfterNew(long version, long segmentId) throws SQLException {
		jdbcTemplate.execute("SET @@autocommit=0");
		if (seglLock.tryLock()) {
			try {
				jdbcTemplate.update(updateAfterNew, new Object[] { version, segmentId });
			} finally {
				seglLock.unlock();
			}
		}
	}
}
