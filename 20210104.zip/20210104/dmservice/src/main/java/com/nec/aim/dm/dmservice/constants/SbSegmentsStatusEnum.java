package com.nec.aim.dm.dmservice.constants;

public enum SbSegmentsStatusEnum {

	CREATED, //
	ONLINE;
}
