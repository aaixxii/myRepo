package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;
import java.util.List;

import com.nec.aim.dm.dmservice.entity.StorageBox;
import com.nec.aim.dm.dmservice.entity.NsmIdUrl;

public interface NodeStorageManagerRepository {
	/**
	 * @return
	 * @throws SQLException
	 */
	public List<StorageBox> findAll()  throws SQLException;
	/**
	 * @param id
	 * @param dmStorageId
	 * @return
	 * @throws SQLException
	 */
	public StorageBox findById(Long id, String dmStorageId)  throws SQLException;	
	/**
	 * @param redundancy
	 * @return
	 * @throws SQLException
	 */
	public List<StorageBox>  findNeedNodeByRedundancy(int redundancy)  throws SQLException;
	/**
	 * @param storageId
	 */
	public void setSignalMailFlag(int storageId);	
	/**
	 * @param segmentId
	 * @param redundancy
	 * @return
	 * @throws SQLException
	 */
	public List<StorageBox> getNodeStorgeBySegmentId(Long segmentId, Integer redundancy) throws SQLException;
	public void commit() throws SQLException;
	public void rollback() throws SQLException;
	/**
	 * @return 
	 * @throws SQLException
	 */
	public List<NsmIdUrl> getNodeStorageUrlAndId() throws SQLException;
}
