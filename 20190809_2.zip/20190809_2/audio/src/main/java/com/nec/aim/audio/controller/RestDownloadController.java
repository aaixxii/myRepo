package com.nec.aim.audio.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.net.URI;
import java.net.URL;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.nec.aim.audio.service.FileUtil;
import com.nec.wrapper.SpeakerDiarizationWrapper;

@RestController
public class RestDownloadController {
	
	 @Value("${audio.tool.path}")
	    private String toolPath;
	 
	 @Value("${audio.tool.config.path}")
	    private String configPath;	
	 
	 @Value("${audio.xml.save.path}")
	    private String xmlFileSavePath;	   


	@GetMapping("/download")
	public ResponseEntity<InputStreamResource> getAudioData(@RequestParam String fileName) throws IOException {
		URL url = Thread.currentThread().getContextClassLoader().getResource("wave/" + fileName);
		File audioFile = new File(url.getPath());
		InputStream in = new FileInputStream(audioFile);
		return ResponseEntity.ok().contentType(MediaType.APPLICATION_OCTET_STREAM).body(new InputStreamResource(in));
	}
	
	@GetMapping("/getMp3Path")
	public String getMp3Path(@RequestParam String fileName) {
		URL url = Thread.currentThread().getContextClassLoader().getResource("wave/" + fileName);
		return url.getPath();		
	}
	
	@GetMapping("/getWavePath")
	public String getWavFilePath() {
		File file = new  File(toolPath);
		 URI url = file.toURI();
		return url.toString();		
	}
	
	
	@RequestMapping(value = "/openTool", produces = MediaType.APPLICATION_XML_VALUE)
	public String openToolOld() {	
			 SpeakerDiarizationWrapper SDWrap = new SpeakerDiarizationWrapper();
			 String strXml = SDWrap.Diariztion(toolPath, configPath);			
			 try {
				saveStringXmlToFile(strXml, xmlFileSavePath);
			} catch (SAXException | IOException | ParserConfigurationException | TransformerException e) {				
				e.printStackTrace();
			}
			 System.out.println(strXml);
		return strXml;		
	}
	
//	@RequestMapping(value = "/openTool", produces = MediaType.APPLICATION_XML_VALUE)
//	public String openTool(@RequestParam String path) {	
//			 SpeakerDiarizationWrapper SDWrap = new SpeakerDiarizationWrapper();
//			 String strXml = SDWrap.Diariztion(path, configPath);			
//			 try {
//				saveStringXmlToFile(strXml, xmlFileSavePath);
//			} catch (SAXException | IOException | ParserConfigurationException | TransformerException e) {				
//				e.printStackTrace();
//			}
//			 System.out.println(strXml);
//		return strXml;		
//	}
	
	@RequestMapping(value = "/getXml", produces = MediaType.APPLICATION_XML_VALUE)
	public String testGetXml() {
		String result = null;
		FileUtil fu = new FileUtil();
		try {
			result =fu.readStringFromDat("C:/Users/xia/Desktop/" + "DiarizationResult.xml");
			System.out.print(result);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "result";
	}
	
	private void saveStringXmlToFile(final String xmlStr, String xmlFilePath) throws SAXException, IOException, ParserConfigurationException, TransformerException {
		 DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		 factory.setNamespaceAware(true);
		 Document doc = factory.newDocumentBuilder().parse(new InputSource(new StringReader(xmlStr)));
	       TransformerFactory transformerFactory = TransformerFactory.newInstance();
	        javax.xml.transform.Transformer transformer = transformerFactory.newTransformer();
	        DOMSource source = new DOMSource(doc);
	        StreamResult result =  new StreamResult(new File(xmlFilePath));
	        transformer.transform(source, result);
	}
}
