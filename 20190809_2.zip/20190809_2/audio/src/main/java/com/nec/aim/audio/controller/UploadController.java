package com.nec.aim.audio.controller;
import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import lombok.extern.slf4j.Slf4j;


@Controller
@Slf4j
public class UploadController {
	
	 @Value("${audio.upload.path}")
	    private String uploadPath;    

	   @PostMapping("/upload")
	    @ResponseBody
	    public String upload(@RequestParam("file") MultipartFile file) {
	        if (file.isEmpty()) 
	            return "file is empty, please select a file.";
	        String fileName = file.getOriginalFilename();
	        uploadPath = uploadPath.endsWith("/") ? uploadPath: uploadPath + "/";	      
	        File dest = new File(uploadPath + fileName);
	        try {
	            file.transferTo(dest);
	           log.info("sucess upload file:" + fileName);
	        } catch (IOException e) {
	            log.error(e.toString(), e);
	        }
	       // return "sucess upload file:" + fileName;
	        return dest.toURI().toString();
	    }
	        
	   @PostMapping("/multiUpload")
	    @ResponseBody
	    public String multiUpload(HttpServletRequest request) {
		   uploadPath = uploadPath.endsWith("/") ? uploadPath: uploadPath + "/";
	        List<MultipartFile> files = ((MultipartHttpServletRequest) request).getFiles("file");	       
	        for (int i = 0; i < files.size(); i++) {
	            MultipartFile file = files.get(i);
	            if (file.isEmpty()) {
	                return "file" + (i++) + "is empty";	            }
	            String fileName = file.getOriginalFilename();
	            File dest = new File(uploadPath + fileName);
	            try {
	                file.transferTo(dest);	               
	            } catch (IOException e) {
	                log.error(e.toString(), e);
	                return "file" + (i++) + "upload failed.";
	            }
	        }
	        return files.size() + "files" + "sucess upload!";
	    } 
}
