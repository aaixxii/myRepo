package com.nec.aim.audio;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.stream.Stream;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.nec.aim.audio.persistence.entity.PersonBioMetrics;
import com.nec.aim.audio.persistence.entity.User;
import com.nec.aim.audio.persistence.repository.PersonBioMetricsRepository;
import com.nec.aim.audio.persistence.repository.UserRepository;

import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class AudioApplication {

	public static void main(String[] args) {
		SpringApplication.run(AudioApplication.class, args);
		log.info("AIM Audio server is running!");
	}
	
	  @Bean
	  ApplicationRunner init(UserRepository repository, PersonBioMetricsRepository pRepository) {
	    return args -> {
	      User user1 = new User(1000L, "audioUser", "audioUser");
	      User user2 = new User(1001L, "aimUser", "aimuser");
	      User user3 = new User(1002L, "xia", "xia");
	      Stream.of(user1, user2, user3).forEach(repository::save);
	      
	     // String ss = Base64.getEncoder().encodeToString("I am template data extracting by mu".getBytes(StandardCharsets.UTF_8));
	      PersonBioMetrics ps1 = new  PersonBioMetrics(Long.parseLong("1000"), "external1", Base64.getEncoder().encodeToString("I am template data extracting by mu1".getBytes(StandardCharsets.UTF_8)), 10000,  new BigDecimal(1));
	      PersonBioMetrics ps2 = new  PersonBioMetrics(Long.parseLong("1001"), "external2", Base64.getEncoder().encodeToString("I am template data extracting by mu2".getBytes(StandardCharsets.UTF_8)), 10000,  new BigDecimal(1));
	      PersonBioMetrics ps3 = new  PersonBioMetrics(Long.parseLong("1002"), "external3", Base64.getEncoder().encodeToString("I am template data extracting by mu3".getBytes(StandardCharsets.UTF_8)), 10000,  new BigDecimal(1));
	      PersonBioMetrics ps4 = new  PersonBioMetrics(Long.parseLong("1003"), "external4", Base64.getEncoder().encodeToString("I am template data extracting by mu4".getBytes(StandardCharsets.UTF_8)), 10000,  new BigDecimal(1));
	      PersonBioMetrics ps5 = new  PersonBioMetrics(Long.parseLong("1004"), "external5", Base64.getEncoder().encodeToString("I am template data extracting by mu5".getBytes(StandardCharsets.UTF_8)), 10000,  new BigDecimal(1));
	      Stream.of(ps1, ps2, ps3, ps4, ps5).forEach(pRepository::save);      
	    };
	  }

}
