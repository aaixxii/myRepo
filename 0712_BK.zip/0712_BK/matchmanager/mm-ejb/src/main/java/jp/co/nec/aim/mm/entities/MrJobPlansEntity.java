package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the BATCH_JOB_PLANS database table.
 * 
 */
@Entity
@Table(name = "MR_JOB_PLANS")
public class MrJobPlansEntity implements Serializable {
	
	private static final long serialVersionUID = -3990695568867606711L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "BATCH_PLAN_ID")
	private long batchJobPlanId;

	@Column(name = "MR_ID")
	private Integer mrId;
	
	@Column(name = "PLANED_TS")
	private long planedTs;

	public MrJobPlansEntity() {
	}

	public long getBatchJobPlanId() {
		return batchJobPlanId;
	}

	public void setBatchJobPlanId(long batchJobPlanId) {
		this.batchJobPlanId = batchJobPlanId;
	}	

	public Integer getMrId() {
		return mrId;
	}

	public void setMrId(Integer mrId) {
		this.mrId = mrId;
	}

	public long getPlanedTs() {
		return planedTs;
	}

	public void setPlanedTs(long planedTs) {
		this.planedTs = planedTs;
	}
}