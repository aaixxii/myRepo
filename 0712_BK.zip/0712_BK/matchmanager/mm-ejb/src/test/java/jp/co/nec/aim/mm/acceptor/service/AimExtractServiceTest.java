package jp.co.nec.aim.mm.acceptor.service;

import java.io.IOException;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.xml.bind.JAXBException;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.util.JaxBUtil;
import jp.co.nec.aim.uid.jaxb.QualityPayload;
import jp.co.nec.aim.uid.jaxb.Request;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()
@Transactional
public class AimExtractServiceTest extends
		AbstractTransactionalJUnit4SpringContextTests {
	@Resource
	private DataSource dataSource;
	@Resource
	private AimExtractService aimExtractService;
	@Resource
	private JdbcTemplate jdbcTemplate;

	@PersistenceContext(unitName = "AIMDB")
	private EntityManager manager;	
	

	@Before
	public void setUp() {
		jdbcTemplate.update("delete from FE_JOB_QUEUE");
		jdbcTemplate.update("delete from FE_JOB_PAYLOADS");	
		jdbcTemplate.execute("commit");
		setMockMethod();
		
	}

	@After
	public void tearDown() {
		jdbcTemplate.update("delete from FE_JOB_QUEUE");
		jdbcTemplate.update("delete from FE_JOB_PAYLOADS");	
		jdbcTemplate.execute("commit");		
	}

	private void setMockMethod() {
		new MockUp<JmsSender>() {
			@Mock
			private void convertAndSend(String queueName, Object object) {
				return;
			}
		};
	}
	
	@Test
	public void testExtract() throws JAXBException, IOException {
		Request requst = new Request();
		QualityPayload qt = new QualityPayload();		
		qt.setReferenceId("test1");
		qt.setReferenceUrl("http://nec/aim");
		requst.setQuality(qt);
		requst.setRequestId("request1");
		requst.setTimeStamp(System.currentTimeMillis());
		requst.setVersion(1.0f);
		JaxBUtil<Request> jt = new JaxBUtil<Request>();
		String xmlReq = jt.marshal(Request.class, requst);		
		long jobId = aimExtractService.extract(xmlReq, true);
		Assert.assertNotNull(jobId);		
	}	
	
	public void testExtract_protobuf_err() {		
	
	}
	
	@Test
	public void testExtractErrorMsg() {
	    long jobId = 1000;
	    AimError testErr = AimError.EXTRACT_RESULT_FAILD;
	    String errMsg = String.format(testErr.getMessage(), jobId);
	    System.out.println(errMsg);
	    testErr.setMessage(errMsg);
	    System.out.println(testErr.getMessage());
	}
}
