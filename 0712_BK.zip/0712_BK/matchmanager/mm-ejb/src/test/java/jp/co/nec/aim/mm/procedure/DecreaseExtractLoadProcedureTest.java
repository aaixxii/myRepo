package jp.co.nec.aim.mm.procedure;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class DecreaseExtractLoadProcedureTest {
	@Resource
	private DataSource ds;
	private DecreaseExtractLoadProcedure procedure;
	@Resource
	private JdbcTemplate jdbcTemplate;

	@Before
	public void setUp() throws Exception {
		procedure = new DecreaseExtractLoadProcedure(ds);
		jdbcTemplate.update("DELETE FROM FE_LOT_JOBS ");
		jdbcTemplate.update("DELETE FROM MATCH_UNITS ");
		
		

	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.update("DELETE FROM MATCH_UNITS ");
	}

	@Test
	public void testExcute() {

		jdbcTemplate
				.update("insert into MATCH_UNITS(MU_ID,UNIQUE_ID,CONTACT_URL,STATE)values(364,1,'http://127.0.0.1:65521/1','WORKING')");
		procedure.setMuId(364l);
		procedure.setLotJobCount(0);
		int pressure = procedure.execute();
		Assert.assertEquals(0, pressure);

	}
}
