//package jp.co.nec.aim.mm.dao;
//
//import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.assertFalse;
//
//import java.util.List;
//
//import javax.annotation.Resource;
//import javax.persistence.EntityManager;
//import javax.persistence.PersistenceContext;
//import javax.sql.DataSource;
//import javax.transaction.Transactional;
//
//
//import jp.co.nec.aim.mm.constants.ConfigProperties;
//import jp.co.nec.aim.mm.constants.ConfigPropertyNames;
//import jp.co.nec.aim.mm.entities.MatchManagerEntity;
//
//import org.junit.After;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(locations = { "/applicationContext.xml" })
//@Transactional
//public class MatchManagerDaoTest {
//
//	@Resource
//	private DataSource ds;
//
//	@PersistenceContext(unitName = "AIMDB")
//	private EntityManager entityManager;
//
//	@Resource
//	private JdbcTemplate jdbcTemplate;
//
//	private MatchManagerDao matchManagerDao;
//
//	private SystemConfigDao systemConfigDao;
//
//	
//	private ConfigProperties configProps;
//
//	@Before
//	public void setUp() throws Exception {
//		configProps = ConfigProperties.getInstance();
//		matchManagerDao = new MatchManagerDao(entityManager);
//		systemConfigDao = new SystemConfigDao(entityManager);
//		
//		
//
//	@After
//	public void tearDown() throws Exception {
//	}
//
//	@Test
//	public void testCreateOrLookupVersion() {
//
//	}
//
//	@Test
//	public void testCreateOrLookup() {
//		String ip = configProps
//				.getPropertyValue(ConfigPropertyNames.MM_IP_ADDRESS);
//		String uniqueId = ip;
//		String connectUrl = "http://" + ip + ":8080/matchmanager";
//		String version = "5.0.0";
//		int result = matchManagerDao.create(uniqueId, version, connectUrl);
//		assertEquals(1, result);
//
//		MatchManagerEntity mm = matchManagerDao.createOrLookup();
//		assertEquals(uniqueId, mm.getUniqueId());
//		assertEquals(connectUrl, mm.getContactUrl());
//		assertEquals(version, mm.getVersion());
//	}
//
//	@Test
//	public void testCreateOrLookupString() {
//		// helper.insertMatchManagers(jdbcTemplate);
//		String ip = configProps
//				.getPropertyValue(ConfigPropertyNames.MM_IP_ADDRESS);
//		String uniqueId = ip;
//		String connectUrl = "http://" + ip + ":8080/matchmanager";
//		String version = "5.0.0";
//		int result = matchManagerDao.create(uniqueId, version, connectUrl);
//		assertEquals(1, result);
//
//		MatchManagerEntity mm = matchManagerDao.createOrLookup(null);
//		assertEquals(uniqueId, mm.getUniqueId());
//		assertEquals(connectUrl, mm.getContactUrl());
//		assertEquals(version, mm.getVersion());
//
//		version = "6.0.0";
//		mm = matchManagerDao.createOrLookup(version);
//		entityManager.refresh(mm);
//		assertEquals(uniqueId, mm.getUniqueId());
//		assertEquals(connectUrl, mm.getContactUrl());
//		assertEquals(version, mm.getVersion());
//	}
//
//	// @Test
//	public void testCreate() {
//		helper.insertMatchManagers(jdbcTemplate);
//		int result = matchManagerDao.create("11.10.23.11", "5.0.0",
//				"11.10.23.11");
//		assertEquals(1, result);
//
//		try {
//			result = matchManagerDao.create("11.10.23.11", "5.0.0",
//					"11.10.23.11");
//			assertEquals(1, result);
//		} catch (Exception ex) {
//			assertFalse(false);
//		}
//	}
//
//	@Test
//	public void testUpdate() {
//		// helper.insertMatchManagers(jdbcTemplate);
//		String version = "5.0.0";
//		int result = matchManagerDao.create("11.10.23.11", "5.0.0",
//				"11.10.23.11");
//		assertEquals(1, result);
//
//		MatchManagerEntity mm = matchManagerDao.lookup("11.10.23.11");
//		assertEquals(version, mm.getVersion());
//		result = matchManagerDao.update("11.10.23.11", "4.0.0", "11.10.23.11");
//		assertEquals(1, result);
//		version = "4.0.0";
//		mm = matchManagerDao.lookup("11.10.23.11");
//		entityManager.refresh(mm);
//		assertEquals(version, mm.getVersion());
//	}
//
//	@Test
//	public void testListDeadMMs() {
//		helper.insertMatchManagers(jdbcTemplate);
//		systemConfigDao.writeAllMissingProperties(ds);
//		List<MatchManagerEntity> mmList = matchManagerDao.listDeadMMs();
//		assertEquals(1, mmList.size());
//	}
//
//	@Test
//	public void testListWorkingMMs() {
//		helper.insertMatchManagers(jdbcTemplate);
//		List<MatchManagerEntity> mmList = matchManagerDao.listWorkingMMs();
//		assertEquals(4, mmList.size());
//	}
//
//}
