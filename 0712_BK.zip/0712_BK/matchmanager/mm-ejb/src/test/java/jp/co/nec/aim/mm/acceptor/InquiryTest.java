package jp.co.nec.aim.mm.acceptor;

import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;

import jp.co.nec.aim.mm.jms.JmsSender;
import mockit.Mock;
import mockit.MockUp;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()
@Transactional
public class InquiryTest extends AbstractTransactionalJUnit4SpringContextTests {
	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;
	@PersistenceContext(unitName = "AIMDB")
	private EntityManager entityManager;
	@Resource
	private Inquiry inquiry;
	
	 private Registration reg;

	@Before
	public void setUp() {
		reg = new Registration(dataSource, entityManager);
		jdbcTemplate.update("delete from job_queue");
		jdbcTemplate.update("delete from container_jobs");
		jdbcTemplate.update("delete from fusion_jobs");
		jdbcTemplate.update("delete from segments");		
		jdbcTemplate.update("delete from PERSON_BIOMETRICS");	
		jdbcTemplate.update("commit");
		setMockMethod();
		
	}

	private void setMockMethod() {
		new MockUp<JmsSender>() {
			@Mock
			private void convertAndSend(String queueName, Object object) {
				return;
			}
		};
	}

	@After
	public void tearDown() {
		jdbcTemplate.update("delete from job_queue");
		jdbcTemplate.update("delete from container_jobs");
		jdbcTemplate.update("delete from fusion_jobs");
		jdbcTemplate.update("delete from segments");
		jdbcTemplate.update("delete from segments");		
		jdbcTemplate.update("delete from PERSON_BIOMETRICS");		
		jdbcTemplate.update("commit");	
		
	}
	

	@Test
	public void testInquiryInquiryJobRequestCommonOptionsBothNull() {
		List<AimInquiryRequest> inquiryRequests = new ArrayList<AimInquiryRequest>();
		CommonOptions options = new CommonOptions();
		try {
			inquiry.inquiry(inquiryRequests, "requestId1", options);			

		} catch (Exception e) {				
		}
	}
	
	@Test
	public void testInquiry_normal() {
		List<AimSyncRequest> syncRequests = Lists.newArrayList();
		byte[] binary = { 1, 2, 2 };
		Record record = new Record(binary, true);
		AimSyncRequest syncRequest = new AimSyncRequest(1, record);	
		syncRequests.add(syncRequest);		
		reg.insert("1", syncRequests);
		
		List<AimInquiryRequest> inquiryRequests = Lists.newArrayList();		
		AimInquiryRequest aimIqyReq = new AimInquiryRequest("MI", 1, "request1", "xml", "iqyReq".getBytes());
		inquiryRequests.add(aimIqyReq );
		CommonOptions options = new CommonOptions();		
		options.setFromServlet(true);
		// options.setMinScore(1);
		options.setMaxCandidates(255);	
		try {
			long jobId = inquiry.inquiry(inquiryRequests, "requestId1", options);
			System.out.print(jobId);
			Assert.assertTrue(jobId > 0);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testInquiryCommonOptions_FunctionNameIsNull() {
		List<AimInquiryRequest> inquiryRequests = Lists.newArrayList();		
		AimInquiryRequest aimIqyReq = new AimInquiryRequest("MI", 1, "request1", "xml", "iqyReq".getBytes());
		inquiryRequests.add(aimIqyReq );
		CommonOptions options = new CommonOptions();		
		options.setFromServlet(true);
		// options.setMinScore(1);
		options.setMaxCandidates(255);	
		try {
			inquiry.inquiry(inquiryRequests, "requestId1", options);

		} catch (Exception e) {					
		}
	}



	@Test
	public void testInquiryOptionsContainerIdISNULL() {
		List<AimInquiryRequest> inquiryRequests = Lists.newArrayList();		
		AimInquiryRequest aimIqyReq = new AimInquiryRequest("MI", 1,"request1", "xmlxml", "iqyReq".getBytes());
		inquiryRequests.add(aimIqyReq );
		CommonOptions options = new CommonOptions();		
		options.setFromServlet(true);
		// options.setMinScore(1);
		options.setMaxCandidates(255);	
		try {
			inquiry.inquiry(inquiryRequests, "requestId1", options);
		} catch (Exception e) {			
			return;
		}		
	}

}
