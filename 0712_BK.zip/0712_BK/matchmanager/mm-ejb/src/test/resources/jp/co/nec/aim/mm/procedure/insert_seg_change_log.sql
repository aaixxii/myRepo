DELETE FROM PERSON_BIOMETRICS;
commit;
DELETE FROM SEGMENT_CHANGE_LOG;
commit;
DELETE FROM SEGMENTS;
commit;
INSERT
INTO segments
  (
    SEGMENT_ID,
    CONTAINER_ID,
    BIO_ID_START,
    BIO_ID_END,
    BINARY_LENGTH,
    RECORD_COUNT,
    VERSION,
    REVISION
   
  )
  VALUES
  (
    1,1,1,1,26,1,5,1
  );
INSERT
INTO segments
  (
    SEGMENT_ID,
    CONTAINER_ID,
    BIO_ID_START,
    BIO_ID_END,
    BINARY_LENGTH,
    RECORD_COUNT,
    VERSION,
    REVISION
    
  )
  VALUES
  (
    2,1,1,1,26,1,10,1
  );
INSERT
INTO PERSON_BIOMETRICS
  (
    BIOMETRICS_ID,
    EXTERNAL_ID, 
    REGISTED_TS,
    CORRUPTED_FLAG,   
    CONTAINER_ID
  )
  VALUES
  (
    1,
    '123',    
   11111,0,1
  );
INSERT
INTO PERSON_BIOMETRICS
  (
    BIOMETRICS_ID,
    EXTERNAL_ID,   
    REGISTED_TS,
    CORRUPTED_FLAG,
    
    CONTAINER_ID
  )
  VALUES
  (
    2,
    '103',
    
    11111,0,1
  );
INSERT
INTO PERSON_BIOMETRICS
  (
    BIOMETRICS_ID,
    EXTERNAL_ID,   
    REGISTED_TS,
    CORRUPTED_FLAG, 
    CONTAINER_ID
  )
  VALUES
  (
    3,
    '113'
    
    ,11111,0,1
  );
INSERT
INTO PERSON_BIOMETRICS
  (
    BIOMETRICS_ID,
    EXTERNAL_ID,   
    REGISTED_TS,
    CORRUPTED_FLAG,
   
    CONTAINER_ID
  )
  VALUES
  (
    4,
    '120',
    
    11111,0,1
  );
INSERT
INTO PERSON_BIOMETRICS
  (
    BIOMETRICS_ID,
    EXTERNAL_ID,   
    REGISTED_TS,
    CORRUPTED_FLAG,
  
    CONTAINER_ID
  )
  VALUES
  (
    5,
    '121',
    
    11111,0,1
  );
INSERT
INTO PERSON_BIOMETRICS
  (
    BIOMETRICS_ID,
    EXTERNAL_ID,
   
    REGISTED_TS,
    CORRUPTED_FLAG,
   
    CONTAINER_ID
  )
  VALUES
  (
    6,
    '122',
   
    11111,0,1
  );
INSERT
INTO SEGMENT_CHANGE_LOG
  (
    SEGMENT_CHANGE_ID,
    BIOMETRICS_ID,
    SEGMENT_ID,
    SEGMENT_VERSION,
    CHANGE_TYPE,
    UPDATE_TS,
    P_NO
  )
  VALUES
  (
    1,1,1,1,0,cast(now() as date),5
  );
INSERT
INTO SEGMENT_CHANGE_LOG
  (
    SEGMENT_CHANGE_ID,
    BIOMETRICS_ID,
    SEGMENT_ID,
    SEGMENT_VERSION,
    CHANGE_TYPE,
      UPDATE_TS,
    P_NO
  )
  VALUES
  (
    2,2,1,2,0,cast(now() as date),5
  );
INSERT
INTO SEGMENT_CHANGE_LOG
  (
    SEGMENT_CHANGE_ID,
    BIOMETRICS_ID,
    SEGMENT_ID,
    SEGMENT_VERSION,
    CHANGE_TYPE,
      UPDATE_TS,
    P_NO
  )
  VALUES
  (
    3,3,1,3,1,cast(now() as date),5
  );
INSERT
INTO SEGMENT_CHANGE_LOG
  (
    SEGMENT_CHANGE_ID,
    BIOMETRICS_ID,
    SEGMENT_ID,
    SEGMENT_VERSION,
    CHANGE_TYPE,
      UPDATE_TS,
    P_NO
  )
  VALUES
  (
    4,4,2,2,0,cast(now() as date),5
  );
INSERT
INTO SEGMENT_CHANGE_LOG
  (
    SEGMENT_CHANGE_ID,
    BIOMETRICS_ID,
    SEGMENT_ID,
    SEGMENT_VERSION,
    CHANGE_TYPE,
      UPDATE_TS,
    P_NO
  )
  VALUES
  (
    5,5,2,4,0,cast(now() as date),5
  );
INSERT
INTO SEGMENT_CHANGE_LOG
  (
    SEGMENT_CHANGE_ID,
    BIOMETRICS_ID,
    SEGMENT_ID,
    SEGMENT_VERSION,CHANGE_TYPE,
      UPDATE_TS,
    P_NO
    )VALUES(6,6,2,3,1,cast(now() as date),5);

    
INSERT INTO SYSTEM_INIT
( 
INIT_ID,
KEY_NAME,
KEY_VALUE)VALUES(10000,'NUM_OF_MAX_FE_LOT', '4');

COMMIT;