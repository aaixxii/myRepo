package jp.co.nec.aim.mm.entities;

public enum QueueType {
	INQUIRY, EXTRACT
}
