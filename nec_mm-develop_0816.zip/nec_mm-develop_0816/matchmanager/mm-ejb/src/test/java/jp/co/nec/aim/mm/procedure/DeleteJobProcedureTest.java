package jp.co.nec.aim.mm.procedure;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class DeleteJobProcedureTest {
	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;
	private DeleteJobProcedure deleteJobProcedure;

	@Before
	public void setUp() throws Exception {
		deleteJobProcedure = new DeleteJobProcedure(dataSource);
		jdbcTemplate.update("delete from JOB_QUEUE");		
		jdbcTemplate.update("commit");
	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.update("delete from JOB_QUEUE");
		jdbcTemplate.update("commit");
	}

	@Test
	public void testExecuteNoDataInDB() {
		deleteJobProcedure.setJobId(new Long(1));
		deleteJobProcedure.execute();

	}

	@Test
	public void testExecute() {
		jdbcTemplate
				.update("insert into JOB_QUEUE(JOB_ID,UIDAI_REQUEST_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID)values(1,'test',4,1,123,0,2345,0,0,1)");
		List<Map<String, Object>> listJobQue = jdbcTemplate
				.queryForList("select * from JOB_QUEUE");
		Assert.assertEquals(1, listJobQue.size());
		deleteJobProcedure.setJobId(new Long(1));
		deleteJobProcedure.execute();
		List<Map<String, Object>> listJobQue1 = jdbcTemplate
				.queryForList("select * from JOB_QUEUE");
		Assert.assertEquals(0, listJobQue1.size());
	}

}
