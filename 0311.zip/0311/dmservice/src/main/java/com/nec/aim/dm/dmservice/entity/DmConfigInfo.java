package com.nec.aim.dm.dmservice.entity;

public class DmConfigInfo {
	
	int configId;
	int key_name;
	int key_value;
	public int getConfigId() {
		return configId;
	}
	public void setConfigId(int configId) {
		this.configId = configId;
	}
	public int getKey_name() {
		return key_name;
	}
	public void setKey_name(int key_name) {
		this.key_name = key_name;
	}
	public int getKey_value() {
		return key_value;
	}
	public void setKey_value(int key_value) {
		this.key_value = key_value;
	}	
}
