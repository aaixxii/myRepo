package jp.co.nec.aim_xm.license.floating;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.log4j.Logger;
import org.springframework.util.StringUtils;

import com.google.common.base.Splitter;

import jp.co.nec.aim_xm.license.exception.InvalidFloatingLicenseException;

public class FloatingLicenseManager {
	final static String DEFAULT_VALUE = "";

	final Logger logger = Logger.getLogger(FloatingLicenseManager.class);

	final List<String> typeList = new ArrayList<>();

	final ConcurrentHashMap<String, String> modalityMap = new ConcurrentHashMap<>();

	final ConcurrentHashMap<String, String> componentMap = new ConcurrentHashMap<>();

	boolean valid;

	ReadWriteLock readWriteLock = new ReentrantReadWriteLock();
	
	String errorCode = DEFAULT_VALUE;
	
	String errorMessage = DEFAULT_VALUE;
	
	public boolean isValid() {
		return valid;
	}

	public List<String> getType() {
		return typeList;
	}

	public void clearAllLicense() {
		readWriteLock.writeLock().lock();
		clear();
		readWriteLock.writeLock().unlock();
	}

	private void clear() {
		typeList.clear();
		modalityMap.clear();
		componentMap.clear();
		valid = false;
		errorCode = DEFAULT_VALUE;
		errorMessage = DEFAULT_VALUE;
	}
	
	public void decompose(String options) {
		readWriteLock.writeLock().lock();
		
		clear();

		Iterable<String> itemIte = Splitter.on(";").trimResults().split(options);
		List<String> keyValueList = new ArrayList<>();
		for (String item : itemIte) {
			Iterable<String> keyValueIte = Splitter.on("=").trimResults().split(item);
			keyValueIte.forEach(keyValueList::add);
			if (keyValueList.get(0).compareTo("COMPONENT") == 0) {
				Iterable<String> valueIte = Splitter.on(",").trimResults().split(keyValueList.get(
					1));
				for (String value : valueIte) {
					componentMap.putIfAbsent(value, DEFAULT_VALUE);
				}
			} else if (keyValueList.get(0).compareTo("MODALITY") == 0) {
				Iterable<String> valueIte = Splitter.on(",").trimResults().split(keyValueList.get(
					1));
				for (String value : valueIte) {
					modalityMap.putIfAbsent(value, DEFAULT_VALUE);
				}
			} else if (keyValueList.get(0).compareTo("TYPE") == 0) {
				Iterable<String> valueIte = Splitter.on(",").trimResults().split(keyValueList.get(
					1));
				valueIte.forEach(typeList::add);
			} else if (keyValueList.get(0).compareTo("VALID") == 0) {
				valid = Boolean.parseBoolean(keyValueList.get(1));
			} else if (keyValueList.get(0).compareTo("ERROR_CODE") == 0) {
				errorCode = keyValueList.get(1);
			} else if (keyValueList.get(0).compareTo("ERROR_MESSAGE") == 0) {
				errorMessage = keyValueList.get(1);
			}
			keyValueList.clear();
		}

		if (logger.isDebugEnabled()) {
			logger.debug("type:" + typeList.toString());
			logger.debug("component:" + componentMap.toString());
			logger.debug("modality:" + modalityMap.toString());
			logger.debug("valid:" + String.valueOf(valid));
			logger.debug("error code:" + errorCode);
			logger.debug("error message:" + errorMessage);
		}
		
		readWriteLock.writeLock().unlock();
	}

	public void checkLicense(String component, String modality)
		throws InvalidFloatingLicenseException {
		readWriteLock.readLock().lock();

		try {
			if (!isValid()) {
				throw new InvalidFloatingLicenseException(errorCode, errorMessage);
			}

			if (!StringUtils.isEmpty(component)) {
				if (!componentMap.containsKey(component)) {
					throw new InvalidFloatingLicenseException("License is not enabled for component:, "
						+ component);
				}
			}

			if (!StringUtils.isEmpty(modality)) {
				if (!modalityMap.containsKey(modality)) {
					throw new InvalidFloatingLicenseException("License is not enabled for modality:, "
						+ modality);
				}
			}
		} finally {
			readWriteLock.readLock().unlock();
		}
	}
}
