package jp.co.nec.aim_xm.license.broker;

import static java.nio.channels.SelectionKey.OP_ACCEPT;
import static java.nio.channels.SelectionKey.OP_READ;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.StandardSocketOptions;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.enterprise.concurrent.ContextService;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;

import com.google.common.base.Throwables;

import jp.co.nec.aim_xm.license.floating.FloatingLicenseManager;

public class LicenseBrokerServer implements InitializingBean {
	final Logger logger = Logger.getLogger(LicenseBrokerServer.class);

	final ExecutorService threadExecutor = Executors.newSingleThreadExecutor();

	ServerSocketChannel serverChannel;

	ContextService contextService;

	FloatingLicenseManager floatingLicenseManager;
	
	int port;
	
	public int getPort() {
		return port;
	}

	public void setContextService(ContextService contextService) {
		this.contextService = contextService;
	}

	public void setFloatingLicenseManager(FloatingLicenseManager floatingLicenseManager) {
		this.floatingLicenseManager = floatingLicenseManager;
	}

	private interface Handler {
		public void handle(SelectionKey key);
	}

	private class AcceptHandler implements Handler {
		@Override
		public void handle(SelectionKey key) {
			try {
				if (key.isAcceptable()) {
					logger.debug("accepted");

					SocketChannel channel = ((ServerSocketChannel)(key.channel())).accept();

					channel.configureBlocking(false);
					channel.register(key.selector(), OP_READ, new IoHandler());
					
					serverChannel.close();
				}
			} catch (IOException ex) {
				logger.error(Throwables.getRootCause(ex).getMessage());
			}
		}
	}

	private class IoHandler implements Handler {
		final static int BUFFER_SIZE = 512;

		@Override
		public void handle(SelectionKey key) {
			if (!key.isReadable()) {
				return;
			}

			SocketChannel channel = null;
			try {
				channel = (SocketChannel)key.channel();
				ByteBuffer buffer = ByteBuffer.allocate(BUFFER_SIZE);
				int numRead = channel.read(buffer);
				if (numRead < 0) {
					logger.error("License agent has stopped.");

					channel.close();
					floatingLicenseManager.clearAllLicense();
					return;
				}

				buffer.flip();
				String license = new String(buffer.array(), 0, numRead, "UTF-8");
				logger.debug("Got a license, " + license);
				
				floatingLicenseManager.decompose(license);
			} catch (IOException ex) {
				logger.error(Throwables.getRootCause(ex).getMessage());
			}
		}
	}

	private class Server implements Runnable {
		@Override
		public void run() {
			try (Selector selector = Selector.open()) {
				serverChannel.register(selector, OP_ACCEPT, new AcceptHandler());

				Set<SelectionKey> keys = null;
				while (true) {
					selector.select();
					keys = selector.selectedKeys();
					if (keys.size() < 1) {
						continue;
					}
					for (Iterator<SelectionKey> ite = keys.iterator(); ite.hasNext();) {
						SelectionKey key = ite.next();
						ite.remove();

						Handler handler = (Handler)key.attachment();
						handler.handle(key);
					}
				}
			} catch (Exception ex) {
				logger.error(Throwables.getRootCause(ex).getMessage());
				return;
			} finally {
				threadExecutor.shutdown();
			}
		}
	}

	private void execContextService() {
		threadExecutor.submit(contextService.createContextualProxy(new Server(), Runnable.class));
	}

	private void initServer()
		throws IOException {
		serverChannel = ServerSocketChannel.open();
		serverChannel.configureBlocking(false);
		serverChannel.setOption(StandardSocketOptions.SO_REUSEADDR, Boolean.TRUE);
		serverChannel.socket().bind(new InetSocketAddress("localhost", 0));
		port = serverChannel.socket().getLocalPort();

		logger.info("License broker server port is " + port);
	}

	@Override
	public void afterPropertiesSet()
		throws Exception {
		logger.debug("called afterPropertiesSet.");
		
		initServer();
		execContextService();
	}
}
