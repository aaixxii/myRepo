package jp.co.nec.aim.license.lmx;

import java.nio.ByteBuffer;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;

public class LmxSocketServer implements Runnable{
	private ServerSocketChannel serverSocketChannel = null;
	private Selector selector;	
	private ByteBuffer lmxBuffer = ByteBuffer.allocate(256);
	
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}
	
	

}
