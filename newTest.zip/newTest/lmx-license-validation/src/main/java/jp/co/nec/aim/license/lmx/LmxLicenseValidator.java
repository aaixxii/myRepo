package jp.co.nec.aim.license.lmx;

public class LmxLicenseValidator {

}
