package jp.co.nec.aim.license.lmx;

public class InvalidFloatingLicenseException extends Exception {
	
	String code = "";
	
	public InvalidFloatingLicenseException() {
	}

	public InvalidFloatingLicenseException(String code, String message) {
		super(message);
		this.code = code;
	}

	public InvalidFloatingLicenseException(String message) {
		super(message);
	}
	
	public String getCode() {
		return code;
	}
}
