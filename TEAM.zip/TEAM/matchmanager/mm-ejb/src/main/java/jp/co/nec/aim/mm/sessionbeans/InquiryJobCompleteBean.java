package jp.co.nec.aim.mm.sessionbeans;

import java.io.IOException;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.ByteString;

import jp.co.nec.aim.message.proto.AIMEnumTypes.ServiceStateType;
import jp.co.nec.aim.message.proto.AIMMessages.PBInquiryJobInfoInternal;
import jp.co.nec.aim.message.proto.AIMMessages.PBInquiryJobInfoOutput;
import jp.co.nec.aim.message.proto.AIMMessages.PBMapInquiryJobResult;
import jp.co.nec.aim.message.proto.AIMMessages.PBServiceStateReason;
import jp.co.nec.aim.mm.callbakSender.AmqExecutorManager;
import jp.co.nec.aim.mm.callbakSender.AmqSocketSender;
import jp.co.nec.aim.mm.constants.ConfigProperties;
import jp.co.nec.aim.mm.constants.ConfigPropertyNames;
import jp.co.nec.aim.mm.constants.UidRequestType;
import jp.co.nec.aim.mm.dao.AggregatorDao;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.dao.SystemInitDao;
import jp.co.nec.aim.mm.dao.UnitDao;
import jp.co.nec.aim.mm.entities.JobQueueEntity;
import jp.co.nec.aim.mm.entities.MapReducerEntity;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.jms.NotifierEnum;
import jp.co.nec.aim.mm.logger.JobDoneLogger;
import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.logger.ProtobufDumpLogger;
import jp.co.nec.aim.mm.sessionbeans.pojo.AimServiceState;
import jp.co.nec.aim.mm.sessionbeans.pojo.UidAimAmqResponse;
import jp.co.nec.aim.mm.util.ObjectUtil;
import jp.co.nec.aim.mm.util.StopWatch;
import jp.co.nec.aim.mm.util.XmlUtil;

/**
 * 
 * @author xiazp
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class InquiryJobCompleteBean {

	private static Logger log = LoggerFactory
			.getLogger(InquiryJobCompleteBean.class);

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;
	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource ds;
	
	@EJB
	private InquiryJobHandler handler;
	private UnitDao unitdao;	
	private InquiryJobDao inquiryJobDao;
	private SystemInitDao systemInitDao;
	private AggregatorDao aggregatorDao;

	@PostConstruct
	public void init() {
		unitdao = new UnitDao(manager);
		inquiryJobDao = new InquiryJobDao(manager, ds);		
		aggregatorDao = new AggregatorDao(ds);
		systemInitDao = new SystemInitDao(manager);				
	}

	/**
	 * completeJob
	 * 
	 * @param mapInquiryJobResult
	 */
	public void completeJob(PBMapInquiryJobResult mapInquiryJobResult) {
		StopWatch sw = new StopWatch();
		sw.start();
		log.info("InquiryJobCompleteBean prepare to update job result to db..");
		try {
			long mrId = mapInquiryJobResult.getMrId();
			MapReducerEntity mrUnit = unitdao
					.findAndWarnState(mrId, "complete");
			if (mrUnit == null) {
				return;
			} else {
				updateInquiryJobs(mapInquiryJobResult);
			}
		} catch (Exception e) {
			throw new AimRuntimeException(e.getMessage(), e);			
		} finally {
			sw.stop();
			PerformanceLogger.log(getClass().getSimpleName(), "completeJob",
					sw.elapsedTime());

		}
	}

	/**
	 * updateInquiryJobs
	 * 
	 * @param jobResult
	 */
    private void updateInquiryJobs(PBMapInquiryJobResult jobResult) {
        StopWatch sw = new StopWatch();
        sw.start();     
        long mrPlanId = jobResult.getPlanId(); 
        
        long mrId = jobResult.getMrId();  
        List<PBInquiryJobInfoInternal> mrJobResults = jobResult.getJobInfoList();
        mrJobResults.forEach(one -> {
        	updateOneResult(one, mrId, mrPlanId);
        }); 
		sw.stop();
		PerformanceLogger.log(getClass().getSimpleName(), "updateInquiryJobs", sw.elapsedTime());     
    }
    
    private void updateOneResult( PBInquiryJobInfoInternal jobInfo, long mrId, long mrPlanId) {       
        PBInquiryJobInfoOutput out = jobInfo.getOut();  
        String xmlRespose = out.getResponse();
        ByteString diagontics = out.getDiagnostics();        
        String requestId = XmlUtil.getRequestId(xmlRespose);        
        long topleveljobId = jobInfo.getTopLevelJobId();       
        long containerJobId = inquiryJobDao.getContainerJobId(Long.valueOf(topleveljobId));
        ProtobufDumpLogger.traceAimJobResult("PBInquiryJobInfoInternal", topleveljobId, mrId, xmlRespose);
     	UidAimAmqResponse mqRespose = new UidAimAmqResponse();
    	mqRespose.setRequestId(requestId);
    	mqRespose.setRequestType(UidRequestType.Identify.name());
    	mqRespose.setXmlResult(xmlRespose);
    	ByteString diagnosticsByteString = jobInfo.getOut().getDiagnostics();
    	if (diagnosticsByteString != null) {
    		 mqRespose.setDiagnostics(diagnosticsByteString.toByteArray());
    	}    	 		        
        Long segmentId = null;
        String description = null; 
        ServiceStateType jobStatus = out.getJobState().getState();
        
		switch (jobStatus) {
        case SERVICE_STATE_SUCCESS:
            log.info(
                    "Ready to complete container job when state is success. "
                        + "MrId:{}, JobId:{}, ContainerJobId:{}, batchjob planId:{}, MessageSequence:{}",
                    new Object[] {
                        mrId, topleveljobId, containerJobId, mrPlanId,
                        jobInfo.getMessageSequence()
                    });
                /* complete Container Job */
                boolean bUpdate = completeContainerJob(topleveljobId,  jobInfo.getMessageSequence(), containerJobId, xmlRespose, diagontics, mrId);
                   
                if (bUpdate) { 
                	//AimManager.saveInquryClientJobResult(String.valueOf(topleveljobId), mqRespose);	
                	completeTopJob(topleveljobId, xmlRespose, diagontics.toByteArray(), bUpdate); 
                	String reqFrom = systemInitDao.getRequestFromSetting();
                	if (reqFrom.toUpperCase().equals("AMQ")) {
                      	log.info("Prepare send identify job result to amq, jobid:{}", topleveljobId);
                    	try {
                    		sendToAmq(mqRespose);
                    	} catch (Exception e) {
                    		log.error(e.getMessage(), e);                    		
                    	} 
                	}
      
                }
                break;
		case SERVICE_STATE_ROLLBACK:
			/* WARN log */
			log.warn(
					"Ready to rollback Inquiry Job when state is rollback. "
							+ "MrId:{}, JobId:{}, ContainerJobId:{}, batchjob planId:{}, MessageSequence:{}",
					new Object[] { mrId, topleveljobId, containerJobId, mrPlanId,
							jobInfo.getMessageSequence() });
			if (!out.getJobState().hasReason()) {
				log.warn("job service state is error, but error reaon is not existed.");
				return;
			}

			 PBServiceStateReason reason = out.getJobState().getReason();
			 description = reason.getDescription();
			log.warn(
					"CONTAINER_JOB_ID:{}(MR_ID:{}) in JOB_ID:{} failed. Reason = {}",
					containerJobId, mrId, topleveljobId, description);
			AimServiceState serviceState = new AimServiceState();
			serviceState.setErrMsg(description);
			serviceState.setErrorcode(reason.getCode());
			serviceState.setFailureTime(reason.getTime());
			log.warn(
					"CONTAINER_JOB_ID:{}(MR_ID:{}) in JOB_ID:{} rollbacked. Reason = {}",
					containerJobId, mrId, topleveljobId, description);
			handler.failInquiryJob(containerJobId, segmentId, serviceState, xmlRespose, false);	
			break;

		case SERVICE_STATE_ERROR:
			/* WARN log */
			log.warn(
					"Ready to fail Inquiry Job when state is error. "
							+ "MrId:{}, JobId:{}, ContainerJobId:{}, batchjob PlanId:{}, MessageSequence:{}",
					new Object[] { mrId, topleveljobId, containerJobId, mrPlanId,
							jobInfo.getMessageSequence() });

			if (!out.getJobState().hasReason()) {
				log.warn("job service state is error, but error reaon is not existed.");
				return;
			}

			 PBServiceStateReason reasonErr = out.getJobState().getReason();
			 description = reasonErr.getDescription();
			log.warn(
					"CONTAINER_JOB_ID:{}(MR_ID:{}) in JOB_ID:{} failed. Reason = {}",
					containerJobId, mrId, topleveljobId, description);
			AimServiceState serviceStateErr = new AimServiceState();
			serviceStateErr.setErrMsg(description);
			serviceStateErr.setErrorcode(reasonErr.getCode());
			serviceStateErr.setFailureTime(reasonErr.getTime());
			handler.failInquiryJob(containerJobId, segmentId, serviceStateErr, xmlRespose, true);			
			//AimManager.saveInquryClientJobResult(String.valueOf(topleveljobId), mqRespose);	
        	completeTopJob(topleveljobId, xmlRespose, diagontics.toByteArray(), false); 
        	String reqFrom = systemInitDao.getRequestFromSetting();
        	if (reqFrom.toUpperCase().equals("AMQ")) {
            	try {
            		sendToAmq(mqRespose);
            	} catch (Exception e) {
            		log.error(e.getMessage(), e);
            	}
        	}     
         	
			break;
		default:
			break;
		}    	
    }

	/**
	 * completeContainerJob
	 * 
	 * @param jobId
	 * @param messageSequence
	 * @param containerJobId
	 * @param inquiryJobResultInternal
	 * @param mrId
	 * @return
	 */
	private boolean completeContainerJob(long jobId, int messageSequence, long containerJobId, String topjobXmlResult, ByteString dignostics, long mrId) {	

		byte[] dignosticsData = null;
		/* Serialization */		
		if (dignostics != null) {
			dignosticsData = dignostics.toByteArray();
		}
		
		/* call updateJobResult */
		long remainJobs = aggregatorDao.updateJobResult(jobId, messageSequence,containerJobId, topjobXmlResult, dignosticsData);
				
		boolean bUpdate = false;
		/* remain_jobs is zero */
		if (remainJobs == 0) {
			bUpdate = true;
		} else if (remainJobs > 0) {
			if (log.isDebugEnabled()) {
				log.info("RemainJobs for JOB_ID: " + jobId + " (MR_ID: "
						+ mrId + ") is " + remainJobs);
			}
		}
		return bUpdate;
	}

	/**
	 * doAggregation
	 * 
	 * @param topLevelJobId
	 * @throws JAXBException 
	 */
	private void completeTopJob(long topLevelJobId, String xmlResult, byte[] dignostics, boolean isSucess)  {		
		JobQueueEntity jobQueue = inquiryJobDao.getTopLevelJob(topLevelJobId);
		aggregatorDao.callCompleteTopLevelJob(jobQueue.getJobId(), xmlResult, dignostics, !isSucess);
		manager.refresh(jobQueue);	 	
		JobDoneLogger jobDoneLogger = new JobDoneLogger(ds);		
			
	 	jobDoneLogger.infoXml(jobQueue, xmlResult, 1);	
		if (ConfigProperties.getInstance().isPropertyValue(
				ConfigPropertyNames.IS_PURGE_CONTAINER_JOBS) && isSucess) {				
			inquiryJobDao.clearAllContainerJob(jobQueue.getJobId());
		}
		/* send Jms to IdentifyPlanner */
		JmsSender.getInstance().sendToInquiryJobPlanner(
				NotifierEnum.Aggregator, "send Msg to IdentifyPlanner");
	}
	
	private void sendToAmq(UidAimAmqResponse mqRespose) throws IOException {     	
    	Integer port = AmqExecutorManager.getInstance().getCallbackIpPort("1");		
		byte[] uidResData = ObjectUtil.serializeAmqResults(mqRespose);		
		AmqSocketSender sendTask = new AmqSocketSender(port, uidResData);
		AmqExecutorManager.getInstance().commitTask(sendTask);		
	}
}
