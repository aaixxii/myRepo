package jp.co.nec.aim.mm.procedure;

import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.nec.aim.mm.extract.planner.MuRemainLots;

import org.springframework.jdbc.core.RowMapper;

public class MuRemainLotsRowMapper implements RowMapper<MuRemainLots> {

	@Override
	public MuRemainLots mapRow(ResultSet rs, int rowNum) throws SQLException {
		MuRemainLots muRemainLots = new MuRemainLots();
		muRemainLots.setMuId(rs.getLong("mu_id"));
		muRemainLots.setCureentLots(rs.getInt("currentlots"));
		muRemainLots.setNumOfExtractor(rs.getInt("num_extractor"));
		muRemainLots.setRemainLots(rs.getInt("remain_lots"));
		return muRemainLots;
	}
}
