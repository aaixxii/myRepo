package jp.co.nec.aim.mm.acceptor;

import java.io.Serializable;



/**
 * InquiryRequest
 * 
 * @author liuyq
 * 
 */
public final class AimInquiryRequest implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -1485113056588337155L;

	private String functionName; // inquiry functionName
	private Integer containerId; // container id list unique
	// Request instance Serialization
	// Fusion job [INQUIRY_JOB_DATA]
	private String request;
	private String requestId;
	private byte[] probeData;

	/**
	 * InquiryRequest
	 * 
	 * @param containerId
	 * @param binary
	 * @param eventId
	 * @param externalId
	 */
	public AimInquiryRequest(String functionName, Integer containerId, String requestId,String request, byte[] probeData) {			
		this.functionName = functionName;
		this.containerId = containerId;
		this.requestId = requestId;
		this.setRequest(request);
		this.probeData = probeData;
	}

	public String getFunctionName() {
		return functionName;
	}

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}	

	public Integer getContainerId() {
		return containerId;
	}

	public void setContainerId(Integer containerId) {
		this.containerId = containerId;
	}

	public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public byte[] getProbeData() {
		return probeData;
	}

	public void setProbeData(byte[] probeData) {
		this.probeData = probeData;
	}
	

}
