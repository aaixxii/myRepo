package jp.co.nec.aim.mm.dao;

import java.sql.SQLException;

import javax.sql.DataSource;

import jp.co.nec.aim.mm.procedure.GetReferenceCountProcedure;

public class ReferenceCountDao {

	private DataSource dataSource;

	public ReferenceCountDao(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public Long getRefCnt() throws SQLException {
		GetReferenceCountProcedure procedure = new GetReferenceCountProcedure(dataSource);
		return procedure.getRefCnt();
	}

}
