package jp.co.nec.aim.mm.identify.planner;

public class MuSegmentMap {
	private Integer muId;
	private Long segmentId;
	private Integer status;
	private Long segmentVersion;
	private Integer containerId;
	private Integer functionId;

	public Integer getMuId() {
		return muId;
	}

	public void setMuId(Integer muId) {
		this.muId = muId;
	}

	public Long getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(Long segmentId) {
		this.segmentId = segmentId;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Long getSegmentVersion() {
		return segmentVersion;
	}

	public void setSegmentVersion(Long segmentVersion) {
		this.segmentVersion = segmentVersion;
	}

	public Integer getContainerId() {
		return containerId;
	}

	public void setContainerId(Integer containerId) {
		this.containerId = containerId;
	}

	public Integer getFunctionId() {
		return functionId;
	}

	public void setFunctionId(Integer functionId) {
		this.functionId = functionId;
	}

}
