package jp.co.nec.aim.mm.exception;

public class UtilException extends AimErrorInfoException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2874681181709291204L;

	public UtilException(String errorCode, String description,String time, String uidCode) {
		super(errorCode,description, time, uidCode);
	}

	public UtilException(Throwable ex) {
		super(ex);
	}
	
	public UtilException(String detail, Throwable ex) {
		super(detail, ex);
	}

}
