package jp.co.nec.aim.mm.sessionbeans;

import java.io.IOException;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.callbakSender.AmqExecutorManager;
import jp.co.nec.aim.mm.callbakSender.AmqSocketSender;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.dao.AggregatorDao;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.dao.SystemInitDao;
import jp.co.nec.aim.mm.entities.ContainerJobEntity;
import jp.co.nec.aim.mm.entities.JobQueueEntity;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.jms.NotifierEnum;
import jp.co.nec.aim.mm.sessionbeans.pojo.AimServiceState;
import jp.co.nec.aim.mm.sessionbeans.pojo.UidAimAmqResponse;
import jp.co.nec.aim.mm.util.ObjectUtil;

/**
 * 
 * @author jinxl
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class InquiryJobHandler {
	private static Logger log = LoggerFactory.getLogger(InquiryJobHandler.class);

	private InquiryJobDao inquiryJobDao;
	private SystemConfigDao systemConfigDao;
	private SystemInitDao systemInitDao;
	private AggregatorDao aggregatorDao;

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;

	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;

	public InquiryJobHandler() {
	}

	/**
	 * Constructor is called by Java EE Container.
	 */
	@PostConstruct
	public void init() {
		inquiryJobDao = new InquiryJobDao(manager, dataSource);
		systemConfigDao = new SystemConfigDao(manager);
		systemInitDao = new SystemInitDao(manager);
		aggregatorDao = new AggregatorDao(dataSource);
	}

	/**
	 * processForceQuitJob
	 * 
	 * @param containerJobId
	 * @param errCode
	 * @param errReason
	 * @param errTime
	 */
	public void failInquiryJob(long containerJobId, String errCode, String errReason, String errTime) {
		manager.flush();
		AimServiceState aimServiceState = new AimServiceState(errCode, errReason, errTime);
		failInquiryJob(containerJobId, null, aimServiceState, errReason, false);
	}

	public void failInquiryJob(long containerJobId, String errCode, String errReason, String result, String errTime) {
		manager.flush();
		AimServiceState aimServiceState = new AimServiceState(errReason, errCode, errTime);
		failInquiryJob(containerJobId, null, aimServiceState, (result == null ? null : result), false);
	}

	/**
	 * processForceQuitJob
	 * 
	 * @param containerJobId
	 * @param segmentId
	 * @param errCode
	 * @param errReason
	 * @param errTime
	 * @param bErr
	 *            ： false->ROLLBACK and TIMEOUT ERROR.true->ERROR
	 */
	public void failInquiryJob(long containerJobId, Long segmentId, AimServiceState serviceState, String bJobResult,
			boolean bErr) {
		ContainerJobEntity containerJob = inquiryJobDao.getContainerJob(containerJobId);
		/* containerJob is null */
		if (null == containerJob) {
			// containerJob is removed.
			log.warn("Container_Job_ID:{} is already removed", new Long(containerJobId));
			return;
		}
		manager.refresh(containerJob);
		/* plan Id is null */
		if (null == containerJob.getPlanId()) {
			// containerJob is already retry.
			log.warn("Container_Job_ID:{} is already retryed", new Long(containerJobId));
			return;
		}
		if (null == bJobResult) {
			log.warn("container Job Result is null! containerJobId:{}", containerJobId);
		}
		/* get SystemConfig's MAX_JOB_FAILURES */
		int maxJobfailure = systemConfigDao.getMMPropertyInt(MMConfigProperty.MAX_JOB_FAILURES);

		JobQueueEntity jobQueue = inquiryJobDao.getJobQueue(containerJobId);
		if (true == bErr || jobQueue.getFailureCount() >= maxJobfailure - 1) {
			log.info("FailureCount is over maxJobfailure. do completee job with faild. job({})", jobQueue.getJobId());
			long jobId = aggregatorDao.failJobResult(serviceState, bJobResult, containerJobId, segmentId);
			if (0 < jobId) {
				log.info("Ready to finish failed top" + " level job: {} asynchronously..", jobQueue.getJobId());
				UidAimAmqResponse uidAmqRes = new UidAimAmqResponse();
				uidAmqRes.setRequestId(jobQueue.getRequestId());
				uidAmqRes.setXmlResult(bJobResult);
				String reqFrom = systemInitDao.getRequestFromSetting();
				if (reqFrom.toUpperCase().equals("AMQ")) {
					Integer port = AmqExecutorManager.getInstance().getCallbackIpPort("1");
					byte[] uidResData = null;
					try {
						uidResData = ObjectUtil.serializeAmqResults(uidAmqRes);
					} catch (IOException e) {
					}
					log.info("send to amq jobId={}", jobId);
					AmqSocketSender sendTask = new AmqSocketSender(port, uidResData);
					AmqExecutorManager.getInstance().commitTask(sendTask);
				}

			} else if (jobId == -1) {
				log.warn("Unaggregated JOB_QUEUE record( id={} ) was not found", jobId);
			} else if (jobId == -2) {
				log.warn(
						"Couldn't lock TopLevelJob ID:{} of CONTAINER_JOB_ID:{} "
								+ "due to Resource is busy, skip do Aggregate the failed top " + "level job.",
						containerJobId, jobQueue.getJobId());
			} else {
				log.warn("failInquiryJob returned Job_Id:" + jobId + "  for CONTAINER_JOB_ID:" + containerJobId
						+ " It's not supported");
			}

			// AimManager.saveInquryClientJobResult(String.valueOf(jobId),
			// uidAmqRes);

		} else {
			// send JMS TO PLANNER
			log.info("Do retry job for jobId({}) and send jms to IdentifyPlanner.", jobQueue.getJobId());
			if (retryJob(jobQueue.getJobId())) {
				/* send Jms to IdentifyPlanner */
				JmsSender.getInstance().sendToInquiryJobPlanner(NotifierEnum.InquiryJobHandler,
						"send msg to IdentifyPlanner");// TODO queueName msg
			}
		}
	}

	/**
	 * retryJob
	 * 
	 * @param topLevelJobId
	 * @return
	 */
	private boolean retryJob(long topLevelJobId) {
		long result = aggregatorDao.retryJob(topLevelJobId);
		if (result >= 0) {
			if (log.isDebugEnabled()) {
				log.debug("JOB_ID:{} was failed and send Message to IdentifyPlanner", topLevelJobId);
			}
			return true;
		}
		if (log.isDebugEnabled()) {
			log.debug("JOB_ID:{} was failed, but do not send Message to IdentifyPlanner", topLevelJobId);
		}
		return false;
	}
}
