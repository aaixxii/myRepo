package jp.co.nec.aim.mm.identify.planner;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.FieldResult;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;

@Entity
@Table(name = "SEGMENTS")
@SqlResultSetMapping(name = "segIdandVersion", entities = @EntityResult(entityClass = SegmentIdAndVeison.class, fields = {
		@FieldResult(name = "segmentId", column = "SEGMENT_ID"),
		@FieldResult(name = "version", column = "VERSION") }))
public class SegmentIdAndVeison implements Serializable {
	private static final long serialVersionUID = -8861340839466910204L;
	@Id
	@Column(name = "SEGMENT_ID")
	private Long segmentId;

	@Column(name = "VERSION")
	private Long version;

	public Long getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(Long segmentId) {
		this.segmentId = segmentId;
	}

	public Long getVersion() {
		return version;
	}

	public void setVersion(Long version) {
		this.version = version;
	}
}
