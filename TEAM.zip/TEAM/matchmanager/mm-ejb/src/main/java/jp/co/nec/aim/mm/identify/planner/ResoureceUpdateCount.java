package jp.co.nec.aim.mm.identify.planner;

public class ResoureceUpdateCount {
	private long updateCount;

	public long getUpdateCount() {
		return updateCount;
	}

	public void setUpdateCount(long updateCount) {
		this.updateCount = updateCount;
	}
}
