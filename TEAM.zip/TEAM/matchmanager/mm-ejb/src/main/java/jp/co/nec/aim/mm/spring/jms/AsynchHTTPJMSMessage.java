package jp.co.nec.aim.mm.spring.jms;

import java.io.Serializable;

import jp.co.nec.aim.mm.jms.NotifierEnum;
import jp.co.nec.aim.mm.jms.ReceiverEnum;

public class AsynchHTTPJMSMessage implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 9025171685634908006L;

	private NotifierEnum notifier;
	private String url;
	private byte[] body;
	private boolean isBinary;

	public AsynchHTTPJMSMessage(NotifierEnum notifier, String url, byte[] body,
			boolean isBinary) {
		this.notifier = notifier;
		this.url = url;
		this.body = body;
		this.isBinary = isBinary;
	}

	public String getURL() {
		return url;
	}

	public byte[] getBody() {
		return body;
	}

	public String getBodyMessage() {
		return new String(body);
	}

	@Override
	public String toString() {
		return "AsynchHTTPJMSMessage(notifier:" + notifier.getNotifierName()
				+ ", receiver:" + ReceiverEnum.AsynchQueue + ", url:" + url
				+ ").";
	}

	public boolean isBinary() {
		return isBinary;
	}
}
