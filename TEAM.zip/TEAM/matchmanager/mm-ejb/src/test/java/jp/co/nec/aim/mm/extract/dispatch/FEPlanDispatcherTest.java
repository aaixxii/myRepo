package jp.co.nec.aim.mm.extract.dispatch;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

import javax.annotation.Resource;
import javax.ejb.AsyncResult;
import javax.ejb.EJB;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobItem;
import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobRequest;
import jp.co.nec.aim.mm.dao.FEPlanDispatchDao;
import jp.co.nec.aim.mm.dao.FEPlanDispatchDaoImpl;
import jp.co.nec.aim.mm.entities.FeJobPayloadEntity;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.entities.FeLotJobEntity;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()
@Transactional
public class FEPlanDispatcherTest {

	@PersistenceContext(unitName = "aim-db")
	protected EntityManager entityManager;

	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;

	@EJB
	private FEPlanDispatcher fEPlanDispatcher;

	private FEPlanDispatchDao dispatchDao;

	@Before
	public void setUp() throws Exception {
		dispatchDao = new FEPlanDispatchDaoImpl(entityManager, jdbcTemplate);
		jdbcTemplate.update("delete from fe_lot_jobs");
		jdbcTemplate.update("delete from fe_job_payloads");
		jdbcTemplate.update("delete from fe_job_queue");
		jdbcTemplate.update("delete from match_units");
		jdbcTemplate.update("delete from fe_job_failure_reasons");
		jdbcTemplate.update("delete from system_config");
		jdbcTemplate.update("delete from system_init");
		jdbcTemplate.execute("commit");
	}

	@After
	public void tearDown() throws Exception {
		dispatchDao = null;
		jdbcTemplate.update("delete from fe_lot_jobs");
		jdbcTemplate.update("delete from fe_job_payloads");
		jdbcTemplate.update("delete from fe_job_queue");
		jdbcTemplate.update("delete from match_units");
		jdbcTemplate.update("delete from fe_job_failure_reasons");
		jdbcTemplate.update("delete from system_config");
		jdbcTemplate.update("delete from system_init");
		jdbcTemplate.execute("commit");
	}

	@Test
	public void testDoDispatch_normal() {
		new MockUp<ExtractRequestPoster>() {
			@Mock
			public boolean postRequest(String Url, int muPostRetryCount,
					byte[] request) {
				return true;
			}
		};

		// prepare feJobTimeOut
		String topLevelTimeOutSql = "select TOP_LEVEL_JOB_TIMEOUTS from function_types where function_id = ?";
		jdbcTemplate.queryForObject(topLevelTimeOutSql,
				new Object[] { new Integer(17) }, Long.class);
		// prepare feLotJob
		Integer muId = 1000;
		String muUrl = "http://www.nec.co.jp";
		long feLotJobId = 8000;
		Long[] feJobIds = { 4000L, 4001L, 4002L, 4003L };
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, CONTACT_URL,STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?,?)";
		jdbcTemplate.update(muSql,
				new Object[] { new Integer(muId), String.valueOf((muId)),
						muUrl, "WORKING", new Integer(5) });
		String feLotJobdSql = "INSERT INTO fe_lot_jobs (LOT_JOB_ID,MU_ID, ASSIGNED_TS, TIMEOUTS)  VALUES(?,?,?,?)";
		jdbcTemplate.update(feLotJobdSql, new Object[] { new Long(feLotJobId),
				new Integer(muId), 400, new Integer(3000) });

		Integer[] priotity = { 0, 1, 2, 3 };
		Integer[] states = { 1, 1, 1, 1 };
		long ts = System.currentTimeMillis();
		String feJobSql = "insert into fe_job_queue(job_id,lot_job_id,mu_id,function_id,PRIORITY,job_state,submission_ts,CALLBACK_STYLE)"
				+ " values(?,?,?,17,?,?,?,0)";
		if (feJobIds != null || feJobIds.length > 0) {
			for (int i = 0; i < feJobIds.length; i++) {
				jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i],
						new Long(feLotJobId), new Integer(muId), priotity[i],
						states[i], new Long(ts) });
			}
		}
		// prepae fePayload
		Long[] payloadIds = { 5L, 4L, 3L, 2L };

		String payLoadSql = "insert into fe_job_payloads(payload_id,payload,job_id) values(?,HEXTORAW('3E00210102CDA000C9'),?)";
		if (payloadIds != null && payloadIds.length > 0) {
			for (int i = 0; i < payloadIds.length; i++) {
				jdbcTemplate.update(payLoadSql, new Object[] { payloadIds[i],
						feJobIds[i] });
			}
		}

		jdbcTemplate.update("delete from system_config");
		String insertSql = "insert into system_config (config_id, property_name, property_value) values "
				+ " (SYSTEM_CONFIG_SEQ.nextval,'BEHAVIOR.MAX_EXTRACT_JOB_FAILURES','5')";
		jdbcTemplate.execute(insertSql);
		String insertMuPostRetryCountSql = "insert into system_config (config_id, property_name, property_value) values "
				+ " (SYSTEM_CONFIG_SEQ.nextval,'BEHAVIOR.MAX_MU_POST_COUNT','3')";
		jdbcTemplate.execute(insertMuPostRetryCountSql);
		jdbcTemplate.execute("commit");
		try {
			boolean isOk = fEPlanDispatcher.doDispatch(feLotJobId);
			Assert.assertTrue(isOk);
		} catch (PersistenceException e) {
			e.printStackTrace();
		}
		FeLotJobEntity feLotJobEntity = entityManager.find(
				FeLotJobEntity.class, feLotJobId);
		Assert.assertEquals(feLotJobId, feLotJobEntity.getLotJobId());
		List<FeJobQueueEntity> results = dispatchDao.getFeJobs(feLotJobId);
		for (FeJobQueueEntity feJob : results) {
			Assert.assertEquals(1000, feJob.getMuId().intValue());
			Assert.assertEquals("WORKING", feJob.getStatus().toString());
		}		
	}

	@Test
	public void testDoDispatch_Poster_failed_do_retry_success() {

		new MockUp<ExtractRequestPoster>() {
			@Mock
			public boolean postRequest(String Url, int muPostRetryCount,
					byte[] request) {
				return false;
			}

			@Mock
			public boolean postRequest(String Url, int muPostRetryCount,
					String message) {
				return false;
			}
		};

		// prepare feJobTimeOut
		String topLevelTimeOutSql = "select TOP_LEVEL_JOB_TIMEOUTS from function_types where function_id = ?";
		jdbcTemplate.queryForObject(topLevelTimeOutSql,
				new Object[] { new Integer(17) }, Long.class);
		// prepare feLotJob
		Integer muId = 1000;
		String muUrl = "http://www.nec.co.jp";
		long feLotJobId = 8000;
		Long[] feJobIds = { 4000L, 4001L, 4002L, 4003L };
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, CONTACT_URL,STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?,?)";
		jdbcTemplate.update(muSql,
				new Object[] { new Integer(muId), String.valueOf((muId)),
						muUrl, "WORKING", new Integer(5) });
		String feLotJobdSql = "INSERT INTO fe_lot_jobs (LOT_JOB_ID,MU_ID, ASSIGNED_TS, TIMEOUTS)  VALUES(?,?,?,?)";
		jdbcTemplate.update(feLotJobdSql, new Object[] { new Long(feLotJobId),
				new Integer(muId), 400, new Integer(3000) });

		Integer[] priotity = { 0, 1, 2, 3 };
		Integer[] states = { 2, 2, 0, 1 };
		long ts = System.currentTimeMillis();
		String feJobSql = "insert into fe_job_queue(job_id,lot_job_id,mu_id,function_id,PRIORITY,job_state,submission_ts,CALLBACK_STYLE)"
				+ " values(?,?,?,17,?,?,?,0)";
		if (feJobIds != null || feJobIds.length > 0) {
			for (int i = 0; i < feJobIds.length; i++) {
				jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i],
						new Long(feLotJobId), new Integer(muId), priotity[i],
						states[i], new Long(ts) });
			}
		}
		// prepae fePayload
		Long[] payloadIds = { 5L, 4L, 3L, 2L };

		String payLoadSql = "insert into fe_job_payloads(payload_id,payload,job_id) values(?,HEXTORAW('3E00210102CDA000C9'),?)";
		if (payloadIds != null && payloadIds.length > 0) {
			for (int i = 0; i < payloadIds.length; i++) {
				jdbcTemplate.update(payLoadSql, new Object[] { payloadIds[i],
						feJobIds[i] });
			}
		}

		String insertSql = "insert into system_config (config_id, property_name, property_value) values "
				+ " (SYSTEM_CONFIG_SEQ.nextval,'BEHAVIOR.MAX_EXTRACT_JOB_FAILURES','5')";
		jdbcTemplate.execute(insertSql);

		String insertSysConfSql = "insert into system_config (config_id, property_name, property_value) values "
				+ " (SYSTEM_CONFIG_SEQ.nextval,'BEHAVIOR.SEND_HTTP_CALLBACKS','true')";
		jdbcTemplate.execute(insertSysConfSql);
		String insertMuPostRetryCountSql = "insert into system_config (config_id, property_name, property_value) values "
				+ " (SYSTEM_CONFIG_SEQ.nextval,'BEHAVIOR.MAX_MU_POST_COUNT','3')";
		jdbcTemplate.execute(insertMuPostRetryCountSql);

		String insertMuExtractLoadSql = "insert into mu_extract_load (mu_id,pressure,update_ts) values (1000,0,0)";
		jdbcTemplate.execute(insertMuExtractLoadSql);
		jdbcTemplate.execute("commit");
		try {
			boolean isOK = fEPlanDispatcher.doDispatch(feLotJobId);
			Assert.assertTrue(!isOK);
		} catch (PersistenceException e) {
			e.printStackTrace();
		}

		String selectFeLotJobSql = "select count(*) from fe_lot_jobs";
		Integer count = jdbcTemplate.queryForObject(selectFeLotJobSql,
				Integer.class);
		Assert.assertEquals(0, count.intValue());		
	}

	@Test
	public void testDoDispatch_feJob_payload_not_exist_do_retry_success() {

		new MockUp<ExtractRequestPoster>() {
			@Mock
			public boolean postRequest(String Url, int muPostRetryCount,
					byte[] request) {
				return true;
			}

			@Mock
			public boolean postRequest(String Url, int muPostRetryCount,
					String message) {
				return true;
			}
		};

		// prepare feJobTimeOut
		String topLevelTimeOutSql = "select TOP_LEVEL_JOB_TIMEOUTS from function_types where function_id = ?";
		jdbcTemplate.queryForObject(topLevelTimeOutSql,
				new Object[] { new Integer(17) }, Long.class);
		// prepare feLotJob
		Integer muId = 1000;
		String muUrl = "http://www.nec.co.jp";
		long feLotJobId = 8000;
		Long[] feJobIds = { 4000L, 4001L, 4002L, 4003L };
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, CONTACT_URL,STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?,?)";
		jdbcTemplate.update(muSql,
				new Object[] { new Integer(muId), String.valueOf((muId)),
						muUrl, "WORKING", new Integer(5) });
		String feLotJobdSql = "INSERT INTO fe_lot_jobs (LOT_JOB_ID,MU_ID, ASSIGNED_TS, TIMEOUTS)  VALUES(?,?,?,?)";
		jdbcTemplate.update(feLotJobdSql, new Object[] { new Long(feLotJobId),
				new Integer(muId), 400, new Integer(3000) });

		Integer[] priotity = { 0, 1, 2, 3 };
		Integer[] states = { 2, 2, 0, 1 };
		long ts = System.currentTimeMillis();
		String feJobSql = "insert into fe_job_queue(job_id,lot_job_id,mu_id,function_id,PRIORITY,job_state,submission_ts,CALLBACK_STYLE)"
				+ " values(?,?,?,17,?,?,?,0)";
		if (feJobIds != null || feJobIds.length > 0) {
			for (int i = 0; i < feJobIds.length; i++) {
				jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i],
						new Long(feLotJobId), new Integer(muId), priotity[i],
						states[i], new Long(ts) });
			}
		}
		// prepae fePayload
		// Long[] payloadIds = { 5L, 4L, 3L, 2L };
		//
		// String payLoadSql =
		// "insert into fe_job_payloads(payload_id,payload,job_id) values(?,HEXTORAW('3E00210102CDA000C9'),?)";
		// if (payloadIds != null && payloadIds.length > 0) {
		// for (int i = 0; i < payloadIds.length; i++) {
		// jdbcTemplate.update(payLoadSql, new Object[] { payloadIds[i],
		// feJobIds[i] });
		// }
		// }

		String insertSql = "insert into system_config (config_id, property_name, property_value) values "
				+ " (SYSTEM_CONFIG_SEQ.nextval,'BEHAVIOR.MAX_EXTRACT_JOB_FAILURES','5')";
		jdbcTemplate.execute(insertSql);

		String insertSysConfSql = "insert into system_config (config_id, property_name, property_value) values "
				+ " (SYSTEM_CONFIG_SEQ.nextval,'BEHAVIOR.SEND_HTTP_CALLBACKS','true')";
		jdbcTemplate.execute(insertSysConfSql);
		String insertMuPostRetryCountSql = "insert into system_config (config_id, property_name, property_value) values "
				+ " (SYSTEM_CONFIG_SEQ.nextval,'BEHAVIOR.MAX_MU_POST_COUNT','3')";
		jdbcTemplate.execute(insertMuPostRetryCountSql);

		String insertMuExtractLoadSql = "insert into mu_extract_load (mu_id,pressure,update_ts) values (1000,0,0)";
		jdbcTemplate.execute(insertMuExtractLoadSql);
		jdbcTemplate.execute("commit");
		try {
			boolean isOK = fEPlanDispatcher.doDispatch(feLotJobId);
			Assert.assertTrue(!isOK);
		} catch (PersistenceException e) {
			e.printStackTrace();
		}

		String selectFeLotJobSql = "select count(*) from fe_lot_jobs";
		Integer count = jdbcTemplate.queryForObject(selectFeLotJobSql,
				Integer.class);
		Assert.assertEquals(0, count.intValue());		
	}

	@Test
	public void testDoDispatch_feLotJob_not_found() {

		new MockUp<ExtractRequestPoster>() {
			@Mock
			public boolean postRequest(String Url, int muPostRetryCount,
					byte[] request) {
				return true;
			}

			@Mock
			public boolean postRequest(String Url, int muPostRetryCount,
					String message) {
				return true;
			}
		};

		// prepare feJobTimeOut
		String topLevelTimeOutSql = "select TOP_LEVEL_JOB_TIMEOUTS from function_types where function_id = ?";
		jdbcTemplate.queryForObject(topLevelTimeOutSql,
				new Object[] { new Integer(17) }, Long.class);
		// prepare feLotJob
		Integer muId = 1000;
		String muUrl = "http://www.nec.co.jp";
		long feLotJobId = 8000;
		// Long[] feJobIds = { 4000L, 4001L, 4002L, 4003L };
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, CONTACT_URL,STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?,?)";
		jdbcTemplate.update(muSql,
				new Object[] { new Integer(muId), String.valueOf((muId)),
						muUrl, "WORKING", new Integer(5) });

		String insertSql = "insert into system_config (config_id, property_name, property_value) values "
				+ " (SYSTEM_CONFIG_SEQ.nextval,'BEHAVIOR.MAX_EXTRACT_JOB_FAILURES','5')";
		jdbcTemplate.execute(insertSql);
		String insertMaxRetryCountSql = "insert into system_config (config_id, property_name, property_value) values "
				+ " (SYSTEM_CONFIG_SEQ.nextval,'BEHAVIOR.MAX_EXTRACT_JOB_FAILURES','5')";
		jdbcTemplate.execute(insertMaxRetryCountSql);

		String insertSysConfSql = "insert into system_config (config_id, property_name, property_value) values "
				+ " (SYSTEM_CONFIG_SEQ.nextval,'BEHAVIOR.SEND_HTTP_CALLBACKS','true')";
		jdbcTemplate.execute(insertSysConfSql);
		String insertMuPostRetryCountSql = "insert into system_config (config_id, property_name, property_value) values "
				+ " (SYSTEM_CONFIG_SEQ.nextval,'BEHAVIOR.MAX_MU_POST_COUNT','3')";
		jdbcTemplate.execute(insertMuPostRetryCountSql);

		String insertMuExtractLoadSql = "insert into mu_extract_load (mu_id,pressure,update_ts) values (1000,0,0)";
		jdbcTemplate.execute(insertMuExtractLoadSql);
		jdbcTemplate.execute("commit");
		try {
			boolean isOK = fEPlanDispatcher.doDispatch(feLotJobId);
			Assert.assertTrue(!isOK);
		} catch (PersistenceException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testDoDispatch_Poster_failed_do_failedFinish_success() {
		new MockUp<ExtractRequestPoster>() {
			@Mock
			public boolean postRequest(String Url, int muPostRetryCount,
					byte[] request) {
				return false;
			}

			@Mock
			public boolean postRequest(String Url, int muPostRetryCount,
					String message) {
				return false;
			}
		};

		// prepare feJobTimeOut
		String topLevelTimeOutSql = "select TOP_LEVEL_JOB_TIMEOUTS from function_types where function_id = ?";
		jdbcTemplate.queryForObject(topLevelTimeOutSql,
				new Object[] { new Integer(17) }, Long.class);
		// prepare feLotJob
		Integer muId = 1000;
		String muUrl = "http://www.nec.co.jp";
		long feLotJobId = 8000;
		Long[] feJobIds = { 4000L, 4001L, 4002L, 4003L };
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, CONTACT_URL,STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?,?)";
		jdbcTemplate.update(muSql,
				new Object[] { new Integer(muId), String.valueOf((muId)),
						muUrl, "WORKING", new Integer(5) });
		String feLotJobdSql = "INSERT INTO fe_lot_jobs (LOT_JOB_ID,MU_ID, ASSIGNED_TS, TIMEOUTS)  VALUES(?,?,?,?)";
		jdbcTemplate.update(feLotJobdSql, new Object[] { new Long(feLotJobId),
				new Integer(muId), 400, new Integer(3000) });

		Integer[] priotity = { 0, 1, 2, 3 };
		Integer[] states = { 2, 2, 0, 1 };
		long ts = System.currentTimeMillis();
		String feJobSql = "insert into fe_job_queue(job_id,lot_job_id,mu_id,function_id,PRIORITY,job_state,submission_ts,FAILURE_COUNT,CALLBACK_STYLE)"
				+ " values(?,?,?,17,?,?,?,3,0)";
		if (feJobIds != null || feJobIds.length > 0) {
			for (int i = 0; i < feJobIds.length; i++) {
				jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i],
						new Long(feLotJobId), new Integer(muId), priotity[i],
						states[i], new Long(ts) });
			}
		}
		// prepae fePayload
		Long[] payloadIds = { 5L, 4L, 3L, 2L };

		String payLoadSql = "insert into fe_job_payloads(payload_id,payload,job_id) values(?,HEXTORAW('3E00210102CDA000C9'),?)";
		if (payloadIds != null && payloadIds.length > 0) {
			for (int i = 0; i < payloadIds.length; i++) {
				jdbcTemplate.update(payLoadSql, new Object[] { payloadIds[i],
						feJobIds[i] });
			}
		}

		String insertSql = "insert into system_init (init_id, key_name, key_value) values "
				+ " (system_init_SEQ.nextval,'NUM_OF_MAX_FE_LOT','2')";

		jdbcTemplate.execute(insertSql);

		String insertSysConfSql = "insert into system_config (config_id, property_name, property_value) values "
				+ " (SYSTEM_CONFIG_SEQ.nextval,'BEHAVIOR.SEND_HTTP_CALLBACKS','true')";
		jdbcTemplate.execute(insertSysConfSql);
		String insertMuPostRetryCountSql = "insert into system_config (config_id, property_name, property_value) values "
				+ " (SYSTEM_CONFIG_SEQ.nextval,'BEHAVIOR.MAX_MU_POST_COUNT','3')";

		String insertFeJobRetryCount = "insert into system_config (config_id, property_name, property_value) values "
				+ " (SYSTEM_CONFIG_SEQ.nextval,'BEHAVIOR.MAX_EXTRACT_JOB_FAILURES','3')";

		jdbcTemplate.execute(insertMuPostRetryCountSql);
		jdbcTemplate.execute(insertFeJobRetryCount);

		String insertMuExtractLoadSql = "insert into mu_extract_load (mu_id,pressure,update_ts) values (1000,0,0)";
		jdbcTemplate.execute(insertMuExtractLoadSql);
		jdbcTemplate.execute("commit");
		try {
			boolean isOK = fEPlanDispatcher.doDispatch(feLotJobId);
			Assert.assertTrue(!isOK);
		} catch (PersistenceException e) {
			e.printStackTrace();
		}

		String feJobFailedReasonsSql = "select count(*) from fe_job_failure_reasons";
		Integer recCount = jdbcTemplate.queryForObject(feJobFailedReasonsSql,
				Integer.class);
		Assert.assertEquals(0, recCount.intValue());		
	}

	@Test
	public void testBuildFeRequest_OK() {
		int feJobs = 2;
		Long[] feJobIds = { 100L, 101L };
		Long[] payLoadIds = { 1L, 2L };
		Long lotJobId = 100L;
		long timeOut = 30000l;
		String[] stringPayLoad = { "this is fejob payload1",
				"this is fejob payload2" };
		List<Long> feJobIdList = new ArrayList<Long>();
		List<FeJobPayloadEntity> payLoadList = new ArrayList<>();
		for (int i = 0; i < feJobIds.length; i++) {
			feJobIdList.add(feJobIds[i]);
			FeJobPayloadEntity payLoad = new FeJobPayloadEntity();
			payLoad.setId(payLoadIds[i]);
			payLoad.setJobId(feJobIds[i]);
			payLoad.setPayload(stringPayLoad[i]);
			payLoadList.add(payLoad);
		}

		PBMuExtractJobRequest results = fEPlanDispatcher.buildFeRequest(
				lotJobId, timeOut, feJobIdList, payLoadList);
		Assert.assertEquals(lotJobId.longValue(), results.getLotJobId());
		Assert.assertEquals(feJobs, results.getJobsCount());
		List<PBMuExtractJobItem> jobList = results.getJobsList();
		for (int i = 0; i < jobList.size(); i++) {
			Assert.assertEquals(feJobIds[i].longValue(), jobList.get(i)
					.getJobId());
			Assert.assertEquals(timeOut, jobList.get(i).getJobTimeout());
			Assert.assertEquals(payLoadList.get(i).getPayload().length(), results
					.getJobsList().get(i).getRequest().length());
		}
	}

	@Test
	public void testBuildFeRequest_timout() {
		int feJobs = 2;
		Long[] feJobIds = { 100L, 101L };
		Long[] payLoadIds = { 1L, 2L };
		Long lotJobId = 100L;
		long timeOut = -1;
		String[] stringPayLoad = { "this is fejob payload1",
				"this is fejob payload2" };
		List<Long> feJobIdList = new ArrayList<Long>();
		List<FeJobPayloadEntity> payLoadList = new ArrayList<>();
		for (int i = 0; i < feJobIds.length; i++) {
			feJobIdList.add(feJobIds[i]);
			FeJobPayloadEntity payLoad = new FeJobPayloadEntity();
			payLoad.setId(payLoadIds[i]);
			payLoad.setJobId(feJobIds[i]);
			payLoad.setPayload(stringPayLoad[i]);
			payLoadList.add(payLoad);
		}

		PBMuExtractJobRequest results = fEPlanDispatcher.buildFeRequest(
				lotJobId, timeOut, feJobIdList, payLoadList);
		Assert.assertEquals(lotJobId.longValue(), results.getLotJobId());
		Assert.assertEquals(feJobs, results.getJobsCount());
		List<PBMuExtractJobItem> jobList = results.getJobsList();
		for (int i = 0; i < jobList.size(); i++) {
			Assert.assertEquals(feJobIds[i].longValue(), jobList.get(i)
					.getJobId());
			Assert.assertEquals(Long.MAX_VALUE, jobList.get(i).getJobTimeout());
			Assert.assertEquals(payLoadList.get(i).getPayload().length(), results
					.getJobsList().get(i).getRequest().length());
		}
	}

	@Test(expected = NullPointerException.class)
	public void testBuildFeRequest_exception() {
		int feJobs = 2;
		Long[] feJobIds = { 100L, 101L };
		Long[] payLoadIds = { 1L, 2L };
		Long lotJobId = 100L;
		long timeOut = 30000l;
		List<Long> feJobIdList = new ArrayList<Long>();
		List<FeJobPayloadEntity> payLoadList = new ArrayList<>();
		for (int i = 0; i < feJobIds.length; i++) {
			feJobIdList.add(feJobIds[i]);
			FeJobPayloadEntity payLoad = new FeJobPayloadEntity();
			payLoad.setId(payLoadIds[i]);
			payLoad.setJobId(feJobIds[i]);
			payLoadList.add(payLoad);
		}

		PBMuExtractJobRequest results = fEPlanDispatcher.buildFeRequest(
				lotJobId, timeOut, feJobIdList, payLoadList);
		Assert.assertEquals(lotJobId.longValue(), results.getLotJobId());
		Assert.assertEquals(feJobs, results.getJobsCount());
		List<PBMuExtractJobItem> jobList = results.getJobsList();
		for (int i = 0; i < jobList.size(); i++) {
			Assert.assertEquals(feJobIds[i].longValue(), jobList.get(i)
					.getJobId());
			Assert.assertEquals(timeOut, jobList.get(i).getJobTimeout());
			Assert.assertEquals(payLoadList.get(i).getPayload().length(), results
					.getJobsList().get(i).getRequest().length());
		}
	}
}
