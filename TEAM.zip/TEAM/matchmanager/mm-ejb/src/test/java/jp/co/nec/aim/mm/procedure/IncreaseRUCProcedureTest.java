package jp.co.nec.aim.mm.procedure;

import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.annotation.Resource;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.common.collect.Lists;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class IncreaseRUCProcedureTest {
	@Resource
	private DataSource dataSource;

	@Resource
	private JdbcTemplate jdbcTemplate;

	private IncreaseRUCProcedure increaseRUCProcedure;

	@Before
	public void setUp() throws Exception {
		increaseRUCProcedure = new IncreaseRUCProcedure(dataSource);
		jdbcTemplate.update("delete from RESOURCE_UPDATE_COUNT");
		jdbcTemplate.update("commit");
	}

	@After
	public void tearDown() throws Exception {
		jdbcTemplate.update("delete from RESOURCE_UPDATE_COUNT");
		jdbcTemplate.update("commit");
	}

	@Test
	public void testIncreaseRUCNoRecord() {
		increaseRUCProcedure.execute();
		List<Map<String, Object>> listRUC = jdbcTemplate
				.queryForList("select * from RESOURCE_UPDATE_COUNT");
		Assert.assertEquals(1, listRUC.size());
		Map<String, Object> mapRuc = listRUC.get(0);
		Assert.assertEquals(1,
				Integer.parseInt(mapRuc.get("UPDATE_COUNT").toString()));
	}

	@Test
	public void testIncreaseRUCHasRecord() {
		jdbcTemplate
				.update("insert into  RESOURCE_UPDATE_COUNT values(1,111111)");
		increaseRUCProcedure.execute();
		List<Map<String, Object>> listRUC = jdbcTemplate
				.queryForList("select * from RESOURCE_UPDATE_COUNT");
		Assert.assertEquals(1, listRUC.size());
		Map<String, Object> mapRuc = listRUC.get(0);
		Assert.assertEquals(2,
				Integer.parseInt(mapRuc.get("UPDATE_COUNT").toString()));
	}

	@Test
	public void testIncreaseRUCNoRecordAndmutip_thread_Excute() {
		ExecutorService service = null;
		try {
			service = Executors.newFixedThreadPool(500);
			List<Callable<Long>> tasks = Lists.newArrayList();
			for (int i = 0; i < 500; i++) {
				tasks.add(new Callable<Long>() {
					@Override
					public Long call() throws Exception {
						IncreaseRUCProcedure procedure = new IncreaseRUCProcedure(
								dataSource);
						;
						procedure.execute();
						return null;
					}
				});
			}

			List<Future<Long>> fList = service.invokeAll(tasks);
			for (Future<Long> f : fList) {
				f.get();
			}

			List<Map<String, Object>> listRUC = jdbcTemplate
					.queryForList("select * from RESOURCE_UPDATE_COUNT");
			Assert.assertEquals(1, listRUC.size());
			Map<String, Object> mapRuc = listRUC.get(0);
			Assert.assertEquals(500,
					Integer.parseInt(mapRuc.get("UPDATE_COUNT").toString()));

		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		} finally {
			if (service != null) {
				service.shutdown();
			}
		}
	}

	@Test
	public void testIncreaseRUCHasRecordAndmutip_thread_Excute() {
		jdbcTemplate
				.update("insert into  RESOURCE_UPDATE_COUNT values(1,111111)");
		jdbcTemplate.update("commit");
		ExecutorService service = null;
		try {
			service = Executors.newFixedThreadPool(10);
			List<Callable<Long>> tasks = Lists.newArrayList();
			for (int i = 0; i < 100; i++) {
				tasks.add(new Callable<Long>() {
					@Override
					public Long call() throws Exception {
						IncreaseRUCProcedure procedure = new IncreaseRUCProcedure(
								dataSource);
						;
						procedure.execute();
						return null;
					}
				});
			}

			List<Future<Long>> fList = service.invokeAll(tasks);
			for (Future<Long> f : fList) {
				f.get();
			}

			List<Map<String, Object>> listRUC = jdbcTemplate
					.queryForList("select * from RESOURCE_UPDATE_COUNT");
			Assert.assertEquals(1, listRUC.size());
			Map<String, Object> mapRuc = listRUC.get(0);
			Assert.assertEquals(101,
					Integer.parseInt(mapRuc.get("UPDATE_COUNT").toString()));

		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		} finally {
			if (service != null) {
				service.shutdown();
			}
		}
	}
}
