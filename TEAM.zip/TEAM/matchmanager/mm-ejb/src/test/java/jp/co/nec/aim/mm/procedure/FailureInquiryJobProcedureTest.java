package jp.co.nec.aim.mm.procedure;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import jp.co.nec.aim.mm.common.JdbcTemplateHelper;
import jp.co.nec.aim.mm.constants.JobState;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.entities.ContainerJobEntity;
import jp.co.nec.aim.mm.entities.JobQueueEntity;
import jp.co.nec.aim.mm.sessionbeans.pojo.AimServiceState;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class FailureInquiryJobProcedureTest {

	@Resource
	private DataSource ds;

	@PersistenceContext(unitName = "aim-db")
	private EntityManager entityManager;

	private InquiryJobDao inquiryjobdao;

	private DateDao datedao;

	private JdbcTemplateHelper helper = new JdbcTemplateHelper();;
	@Resource
	private JdbcTemplate jdbcTemplate;	
	private FailureInquiryJobProcedure failureinquiryjobprocedure;

	@Before
	public void setUp() throws Exception {

		failureinquiryjobprocedure = new FailureInquiryJobProcedure(ds);
		inquiryjobdao = new InquiryJobDao(entityManager);
		datedao = new DateDao(ds);
		helper = new JdbcTemplateHelper();
		helper.deleteInquiryJob(jdbcTemplate);
		helper.deleteMatchManagers(jdbcTemplate);
		helper.deleteSystemConfig(jdbcTemplate);
		helper.deleteMatchManagers(jdbcTemplate);
		helper.deleteFEJobs(jdbcTemplate);
		helper.scene01(jdbcTemplate);
		jdbcTemplate.update("commit");
		
	}

	@After
	public void tearDown() throws Exception {
		helper.deleteInquiryJob(jdbcTemplate);
		helper.deleteMatchManagers(jdbcTemplate);
		helper.deleteSystemConfig(jdbcTemplate);
		helper.deleteMatchManagers(jdbcTemplate);
		helper.deleteFEJobs(jdbcTemplate);
		jdbcTemplate.update("commit");
	}

	@Test
	public void test_jobId1004() {
		String code = "109";
		long containerJobId = 10040;
		Long segmentId = null;
		AimServiceState reason = createAimServiceState();		
		String btr = "ABCDE";
		long jobId = failureinquiryjobprocedure.action(reason,
				btr, containerJobId, segmentId);

		assertEquals(1004, jobId);
		JobQueueEntity jobqueue = inquiryjobdao.getTopLevelJob(jobId);
		assertEquals(1, jobqueue.getFailureCount());
		// assertEquals(null, jobqueue.getAssignedTs());
		ContainerJobEntity containerjob = inquiryjobdao
				.getContainerJob(containerJobId);
		assertEquals(JobState.DONE, containerjob.getJobState());
		assertNotNull(containerjob.getResultTs());
		List<ContainerJobEntity> containerJobs = inquiryjobdao
				.getAllContainerJob(jobId);
		for (ContainerJobEntity containerJob : containerJobs) {
			assertEquals(JobState.DONE, containerJob.getJobState());
			assertNotNull(containerJob.getResultTs());
		}
		Map<String, Object> map = helper.getContainerJobFailureReasons(
				jdbcTemplate, jobId);
		assertEquals(code, map.get("CODE").toString());
		assertEquals(reason.getErrMsg(), map.get("REASON").toString());		
		assertEquals(null, map.get("MR_ID"));
		assertEquals(containerJobId,
				Long.parseLong(map.get("CONTAINER_JOB_ID").toString()));
		assertEquals(null, map.get("SEGMENT_ID"));
	}

	@Test
	public void test_jobId0() {	
		long containerJobId = 10040;
		Long segmentId = new Long(1);
		AimServiceState reason = createAimServiceState();
		String btr = "ABCDE";
		long jobId = failureinquiryjobprocedure.action(reason,
				btr, containerJobId, segmentId);

		assertEquals(1004, jobId);
		JobQueueEntity jobqueue = inquiryjobdao.getTopLevelJob(jobId);
		assertEquals(1, jobqueue.getFailureCount());
		// assertEquals(null, jobqueue.getAssignedTs());
		ContainerJobEntity containerjob = inquiryjobdao
				.getContainerJob(containerJobId);
		assertEquals(JobState.DONE, containerjob.getJobState());
		assertNotNull(containerjob.getResultTs());
		List<ContainerJobEntity> containerJobs = inquiryjobdao
				.getAllContainerJob(jobId);
		for (ContainerJobEntity containerJob : containerJobs) {
			assertEquals(JobState.DONE, containerJob.getJobState());
			assertNotNull(containerJob.getResultTs());
		}
		Map<String, Object> map = helper.getContainerJobFailureReasons(
				jdbcTemplate, jobId);		
		assertEquals(reason.getErrMsg(), map.get("REASON").toString());
		
		assertEquals(null, map.get("MR_ID"));
		assertEquals(containerJobId,
				Long.parseLong(map.get("CONTAINER_JOB_ID").toString()));
		assertEquals(segmentId.longValue(),
				Long.parseLong(map.get("SEGMENT_ID").toString()));
	}

	@Test
	public void test_jobId1004_null() {
		String code = "109";		
		long containerJobId = 10040;
		Long segmentId = null;
		AimServiceState reason = createAimServiceState();
		String btr = "ABCDE";
		long jobId = failureinquiryjobprocedure.action(reason,
				btr, containerJobId, segmentId);

		assertEquals(1004, jobId);
		JobQueueEntity jobqueue = inquiryjobdao.getTopLevelJob(jobId);
		assertEquals(1, jobqueue.getFailureCount());
		// assertEquals(null, jobqueue.getAssignedTs());
		ContainerJobEntity containerjob = inquiryjobdao
				.getContainerJob(containerJobId);
		assertEquals(JobState.DONE, containerjob.getJobState());
		assertNotNull(containerjob.getResultTs());
		List<ContainerJobEntity> containerJobs = inquiryjobdao
				.getAllContainerJob(jobId);
		for (ContainerJobEntity containerJob : containerJobs) {
			assertEquals(JobState.DONE, containerJob.getJobState());
			assertNotNull(containerJob.getResultTs());
		}
		Map<String, Object> map = helper.getContainerJobFailureReasons(
				jdbcTemplate, jobId);
		assertEquals(code, map.get("CODE").toString());
		assertEquals(reason.getErrMsg(),
				map.get("REASON").toString());		
		assertEquals(null, map.get("MR_ID"));
		assertEquals(containerJobId,
				Long.parseLong(map.get("CONTAINER_JOB_ID").toString()));
		assertEquals(null, map.get("SEGMENT_ID"));
	}
	private AimServiceState createAimServiceState() {
		AimServiceState reason = new AimServiceState();
		reason.setErrMsg("muerror");
		reason.setErrorcode("109");
		reason.setFailureTime(datedao.getCurrentTimeMS().toString());
		return reason;
	}

}
