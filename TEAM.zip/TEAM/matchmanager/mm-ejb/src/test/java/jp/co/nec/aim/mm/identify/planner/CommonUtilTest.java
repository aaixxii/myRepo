package jp.co.nec.aim.mm.identify.planner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class CommonUtilTest {
	private CompressUtil util;

	@Before
	public void setUp() throws Exception {
		util = new CompressUtil();
	}

	@After
	public void tearDown() throws Exception {
		util = null;
	}

	@Test
	public void testObjectZipUnZiPWithPlanId() {
		List<MuJobExecutePlan> muPlans = new ArrayList<MuJobExecutePlan>();
		Long[] planIds = { 1000L, 1001L, 1002L, 1003L, 1004L, 1005L };
		Long topJobId = 1L;
		Integer[] functionIds = { 1, 1, 2, 2, 3, 3 };
		Integer[] containerIds = { 1, 2, 312, 313, 17, 18 };
		String plan = "abcdefghijklmnopqrstuvwxyz";
		Integer planedCount = 0;
		long planedTs = System.currentTimeMillis();
		for (int i = 0; i < containerIds.length; i++) {
			MuJobExecutePlan muPlan = new MuJobExecutePlan();
			muPlan.setContainerId(containerIds[i]);
			muPlan.setJobId(topJobId);
			muPlan.setPlan(plan);
			muPlan.setPlanedCount(planedCount);
			muPlan.setPlanedTs(planedTs);
			muPlan.setPlanId(planIds[i]);
			muPlan.setFunctionId(functionIds[i]);
			muPlans.add(muPlan);
		}
		Map<Long, MuJobExecutePlan> mapPlans = new HashMap<Long, MuJobExecutePlan>();
		for (MuJobExecutePlan tmp : muPlans) {
			mapPlans.put(tmp.getPlanId(), tmp);
		}

		byte[] zipedObject = util.zipCompressPlanList(muPlans);
		Map<Long, MuJobExecutePlan> unZiped = (Map<Long, MuJobExecutePlan>) util
				.unzipCompressWithPlanId(zipedObject);
		Assert.assertEquals(mapPlans.size(), unZiped.size());
		Iterator<Entry<Long, MuJobExecutePlan>> it1 = unZiped.entrySet()
				.iterator();
		Iterator<Entry<Long, MuJobExecutePlan>> it2 = mapPlans.entrySet()
				.iterator();
		while (it1.hasNext() && it2.hasNext()) {
			Entry<Long, MuJobExecutePlan> tmp1 = it1.next();
			Entry<Long, MuJobExecutePlan> tmp2 = it2.next();
			Assert.assertEquals(tmp1.getKey(), tmp2.getKey());
			MuJobExecutePlan plan1 = tmp1.getValue();
			MuJobExecutePlan plan2 = tmp2.getValue();
			Assert.assertEquals(plan1.getPlanId(), plan2.getPlanId());
			Assert.assertEquals(plan1.getContainerId(), plan2.getContainerId());
			Assert.assertEquals(plan1.getJobId(), plan2.getJobId());
			Assert.assertEquals(plan1.getPlan(), plan2.getPlan());
			Assert.assertEquals(plan1.getPlanedCount(), plan2.getPlanedCount());
			Assert.assertEquals(plan1.getPlanedTs(), plan2.getPlanedTs());
			Assert.assertEquals(plan1.getFunctionId(), plan2.getFunctionId());
		}

	}

	@Test
	public void testObjectZipUnZiP() {
		List<MuJobExecutePlan> muPlans = new ArrayList<MuJobExecutePlan>();
		Long[] planIds = { 1000L, 1001L, 1002L, 1003L, 1004L, 1005L };
		Long topJobId = 1L;
		Integer[] functionIds = { 1, 1, 2, 2, 3, 3 };
		Integer[] containerIds = { 1, 2, 312, 313, 17, 18 };
		String plan = "abcdefghijklmnopqrstuvwxyz";
		Integer planedCount = 0;
		long planedTs = System.currentTimeMillis();
		for (int i = 0; i < containerIds.length; i++) {
			MuJobExecutePlan muPlan = new MuJobExecutePlan();
			muPlan.setContainerId(containerIds[i]);
			muPlan.setJobId(topJobId);
			muPlan.setPlan(plan);
			muPlan.setPlanedCount(planedCount);
			muPlan.setPlanedTs(planedTs);
			muPlan.setPlanId(planIds[i]);
			muPlan.setFunctionId(functionIds[i]);
			muPlans.add(muPlan);
		}

		byte[] zipedObject = util.zipCompress(muPlans);
		List<MuJobExecutePlan> unZiped = util.unZipCompress(zipedObject);
		Assert.assertEquals(muPlans.size(), unZiped.size());
		for (int i = 0; i < unZiped.size(); i++) {
			Assert.assertEquals(muPlans.get(i).getPlanId(), unZiped.get(i)
					.getPlanId());
			Assert.assertEquals(muPlans.get(i).getContainerId(), unZiped.get(i)
					.getContainerId());
			Assert.assertEquals(muPlans.get(i).getJobId(), unZiped.get(i)
					.getJobId());
			Assert.assertEquals(muPlans.get(i).getPlan(), unZiped.get(i)
					.getPlan());
			Assert.assertEquals(muPlans.get(i).getPlanedCount(), unZiped.get(i)
					.getPlanedCount());
			Assert.assertEquals(muPlans.get(i).getPlanedTs(), unZiped.get(i)
					.getPlanedTs());
			Assert.assertEquals(muPlans.get(i).getFunctionId(), unZiped.get(i)
					.getFunctionId());
		}
	}
}
