package jp.co.nec.aim.mm.dao;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.constants.SystemConfigNamespace;
import jp.co.nec.aim.mm.entities.SystemConfigEntity;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.util.CollectionsUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * @author Erik Vandekieft
 */
public class SystemConfigDao {

	private static Logger log = LoggerFactory.getLogger(SystemConfigDao.class);
	private EntityManager manager;

	public SystemConfigDao(EntityManager manager) {
		this.manager = manager;
	}

	public int getMMPropertyInt(MMConfigProperty prop) {
		return Integer.parseInt(getMMProperty(prop));
	}

	public long getMMPropertyLong(MMConfigProperty prop) {
		return Long.parseLong(getMMProperty(prop));
	}

	public boolean getMMPropertyBool(MMConfigProperty prop) {
		return Boolean.parseBoolean(getMMProperty(prop));
	}

	public double getMMPropertyDouble(MMConfigProperty prop) {
		return Double.parseDouble(getMMProperty(prop));
	}

	public float getMMPropertyFloat(MMConfigProperty prop) {
		return Float.parseFloat(getMMProperty(prop));
	}

	/**
	 * Get a mm property from SYSTEM_CONFIG Table.
	 * 
	 * @param prop
	 * 
	 * @return
	 */
	public String getMMProperty(MMConfigProperty prop) {
		String propName = prop.getName();
		return getMMProperty(propName);
	}

	/**
	 * This method is same getMMProperty(EntityManager, MMConfigProperty)
	 * without one point is propName type.
	 * 
	 * @param propName
	 * @param prop
	 * 
	 * @return
	 */
	public String getMMProperty(String propName) {
		SystemConfigEntity ce = getPropEntity(propName);
		if (ce == null) {
			Properties defaults = getDefaults(SystemConfigNamespace.MM);
			String defaultValue = defaults.getProperty(propName);
			if (defaultValue == null) {
				throw new AimRuntimeException("Missing MM Property: "
						+ propName);
			} else {
				return defaultValue;
			}
		} else {
			return ce.getValue();
		}
	}

	public void writeAllMissingProperties(DataSource dataSource) {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		//jdbcTemplate.execute("LOCK TABLE SYSTEM_CONFIG IN EXCLUSIVE MODE");
		for (SystemConfigNamespace namespace : SystemConfigNamespace.values()) {
			writeMissingPropertiesFromNamespace(namespace);
		}
		jdbcTemplate.execute("commit");
	}

	private void setProperty(String propName, String propVal) {
		SystemConfigEntity ce = getPropEntity(propName);
		if (ce == null) {
			ce = new SystemConfigEntity();
			ce.setName(propName);
			ce.setValue(propVal);
			log.debug("Setting property: " + ce.toString());
			manager.persist(ce);
		} else {
			ce.setValue(propVal);
		}
	}

	private SystemConfigEntity getPropEntity(String propName) {
		Query q = manager.createNamedQuery("NQ::getConfigEntity");
		q.setParameter("name", propName);
		@SuppressWarnings("unchecked")
		List<SystemConfigEntity> results = q.getResultList();
		if (CollectionsUtil.isEmpty(results))
			return null;
		assert (results.size() == 1) : "DUPLICATE property entries for property '"
				+ propName + "'";
		SystemConfigEntity systemConfig = CollectionsUtil.getFirst(results);
		return systemConfig;
	}

	private Properties getDefaults(SystemConfigNamespace namespace) {
		String propFile = namespace.getDefaultPropertiesFilename();
		Properties defaultProperties = new Properties();
		try {
			InputStream is = SystemConfigDao.class.getClassLoader()
					.getResourceAsStream(propFile);
			if (is == null) {
				throw new AimRuntimeException("Unable to find properties file "
						+ propFile);
			}
			defaultProperties.load(is);
			is.close();
			return defaultProperties;
		} catch (IOException e) {
			throw new AimRuntimeException(
					"IOException while loading properties file " + propFile, e);
		}
	}

	private void writeMissingPropertiesFromNamespace(
			SystemConfigNamespace namespace) {
		Properties defaultProperties = getDefaults(namespace);

		Set<Entry<Object, Object>> entrySet = defaultProperties.entrySet();
		for (Entry<Object, Object> e : entrySet) {
			String key = (String) e.getKey();
			try {
				if (getPropEntity(key) == null) {
					setProperty(key, (String) e.getValue());
				}
			} catch (Exception ex) {
				throw new AimRuntimeException(
						"Exception while setting property : Key=" + key
								+ " Value=" + (String) e.getValue(), ex);
			}
		}
	}

}
