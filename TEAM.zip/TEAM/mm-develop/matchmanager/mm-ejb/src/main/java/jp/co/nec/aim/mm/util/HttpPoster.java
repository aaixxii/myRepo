package jp.co.nec.aim.mm.util;

import java.io.IOException;

import jp.co.nec.aim.mm.exception.HttpPostException;

import org.apache.http.HttpEntity;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.SocketConfig;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * HttpPoster
 * 
 * @author liuyq
 * 
 */
public final class HttpPoster {

	/** log instance **/
	private static final Logger log = LoggerFactory.getLogger(HttpPoster.class);

	private static final int SO_TIMEOUT = 5000;
	private static final int CON_TIMEOUT = 5000;
	public static final int DEFAULT_RETRY_COUNT = 3;

	/**
	 * HTTP post with retry count and timeout
	 * 
	 * @param url
	 * @param bytes
	 * @param retryCount
	 * @param timeout
	 * @return
	 * @throws HttpPostException
	 */
	public static final HttpResponseInfo post(final String url, byte[] bytes,
			Integer retryCount, Integer timeout) throws HttpPostException {
		return post(url, bytes, (retryCount != null), true, retryCount,
				timeout, false);
	}

	/**
	 * HTTP post with retry count and timeout
	 * 
	 * @param url
	 * @param body
	 * @param retryCount
	 * @param timeout
	 * @return
	 * @throws HttpPostException
	 */
	public static final HttpResponseInfo post(final String url, String body,
			Integer retryCount, Integer timeout) throws HttpPostException {
		return post(url, body.getBytes(), (retryCount != null), false,
				retryCount, timeout, false);
	}

	/**
	 * post to target URL with header and body, ContextType: text/xml
	 * 
	 * @param url
	 * @param header
	 * @param body
	 * @param doRetry
	 * @return
	 * @throws IOException
	 */
	public static final HttpResponseInfo post(final String url, String body,
			Integer retryCount) throws HttpPostException {
		return post(url, body.getBytes(), (retryCount != null), false,
				retryCount, null, false);
	}

	/**
	 * post to target URL with header and body, ContextType: text/xml
	 * 
	 * @param url
	 * @param header
	 * @param body
	 * @param doRetry
	 * @param timeout
	 * @return
	 * @throws IOException
	 */
	public static final HttpResponseInfo smPost(final String url, String body,
			Integer timeout) throws HttpPostException {
		return post(url, body.getBytes(), false, false, 0, timeout, false);
	}

	/**
	 * post to target URL with header and body, ContextType:
	 * application/octet-stream
	 * 
	 * @param url
	 * @param header
	 * @param bytes
	 * @param doRetry
	 * @return
	 * @throws HttpPostException
	 */
	public static final HttpResponseInfo post(final String url, byte[] bytes,
			Integer retryCount) throws HttpPostException {
		return post(url, bytes, (retryCount != null), true, retryCount, null,
				false);
	}

	/**
	 * post to target URL with header and body, ContextType:
	 * application/octet-stream
	 * 
	 * @param url
	 * @param header
	 * @param bytes
	 * @param doRetry
	 * @return
	 * @throws HttpPostException
	 */
	public static final HttpResponseInfo validatorPost(final String url,
			byte[] bytes) throws HttpPostException {
		return post(url, bytes, true, true, DEFAULT_RETRY_COUNT, null, true);
	}

	/**
	 * post to target URL with header and body,
	 * 
	 * @param url
	 * @param header
	 * @param bytes
	 * @param doRetry
	 * @return
	 * @throws IOException
	 */
	private static final HttpResponseInfo post(final String url, byte[] bytes,
			boolean doRetry, boolean isBinary, Integer retryCount,
			Integer timeout, boolean isResBinary) throws HttpPostException {
		if (log.isDebugEnabled()) {
			log.debug("start http post with specified url: {}.", url);
		}

		int conTimeOut = (timeout == null) ? CON_TIMEOUT : timeout;
		int socketTimeOut = (timeout == null) ? SO_TIMEOUT : timeout;

		PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager();
		SocketConfig socketConfig = SocketConfig.custom().setTcpNoDelay(true)
				.setSoReuseAddress(false).setSoTimeout(socketTimeOut).build();
		cm.setDefaultSocketConfig(socketConfig);

		try (CloseableHttpClient httpClient = doRetry ? HttpClientBuilder
				.create()
				.setConnectionManager(cm)
				.setRetryHandler(
						new RetryHandler(
								(retryCount == null) ? DEFAULT_RETRY_COUNT
										: retryCount)).build()
				: HttpClientBuilder.create().setConnectionManager(cm)
						.disableAutomaticRetries().build()) {

			HttpPost httpPost = new HttpPost(url);

			httpPost.setConfig(RequestConfig.custom()
					.setConnectTimeout(conTimeOut)
					.setConnectionRequestTimeout(conTimeOut)
					.setSocketTimeout(socketTimeOut).build());

			// set bytes
			if (bytes != null) {
				if (isBinary) {
					ByteArrayEntity entity = new ByteArrayEntity(bytes,
							ContentType.APPLICATION_OCTET_STREAM);
					httpPost.setEntity(entity);
				} else {
					final String detail = new String(bytes, "UTF-8");
					StringEntity entity = new StringEntity(detail,
							ContentType.TEXT_XML);
					httpPost.setEntity(entity);
				}
			}

			try (CloseableHttpResponse response = httpClient.execute(httpPost)) {
				int statusCode = response.getStatusLine().getStatusCode();
				byte[] ObjectBytes = null;
				if (isResBinary) {
					HttpEntity reEntity = response.getEntity();
					if (reEntity != null) {
						ObjectBytes = EntityUtils.toByteArray(reEntity);
					}
				}
				return new HttpResponseInfo(statusCode, ObjectBytes);
			}
		} catch (IOException e) {
			throw new HttpPostException(
					"IOException occurred while post to url " + url, e);
		} catch (Exception e) {
			throw new HttpPostException("Exception occurred while post to url "
					+ url, e);
		}
	}

	/**
	 * RetryHandler
	 * 
	 * @author liuyq
	 * 
	 */
	static class RetryHandler implements HttpRequestRetryHandler {

		private final int retryCount;

		/**
		 * default constructor
		 * 
		 * @param retryCount
		 */
		public RetryHandler(int retryCount) {
			this.retryCount = retryCount;
		}

		/**
		 * retryRequest
		 */
		@Override
		public boolean retryRequest(IOException exception, int executionCount,
				HttpContext context) {
			if (log.isDebugEnabled()) {
				log.debug("start HttpPoster retryRequest..");
			}

			if (executionCount < retryCount) {
				log.warn("Http post, Retried connection {}"
						+ " times, which exceeds the maximum"
						+ " retry count of {}.", executionCount, retryCount,
						exception);
			} else {
				// Do not retry if over max retry count
				throw new HttpPostException("retry the request "
						+ executionCount + " times", exception);
			}
			if (log.isDebugEnabled()) {
				log.debug("end HttpPoster retryRequest..");
			}
			return true;
		}
	}

	/**
	 * 
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		System.setProperty("org.apache.commons.logging.Log",
				"org.apache.commons.logging.impl.SimpleLog");
		System.setProperty("org.apache.commons.logging.simplelog.showdatetime",
				"true");
		System.setProperty(
				"org.apache.commons.logging.simplelog.log.org.apache.http",
				"debug");
		System.out.println(HttpPoster.post("http://192.168.1.14:1234",
				new byte[] {}, 10, 100).getStatusCode());

	}
}
