package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.object.StoredProcedure;

/**
 * 
 * @author xiazp
 *
 */
public class GetLimitedJobsByFamiliyProcedure extends StoredProcedure {
	private JdbcTemplate jdbcTemplate;
	private static final String GET_LIMITED_JOBS_BY_FAMILIY = "get_limited_jobs_by_familiy";	

	public GetLimitedJobsByFamiliyProcedure(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
		setDataSource(dataSource);		
		setSql(GET_LIMITED_JOBS_BY_FAMILIY);
		declareParameter(new SqlOutParameter("tab_name", Types.VARCHAR));				
		compile();
	}

	/**
	 * 
	 * @return
	 * @throws DataAccessException
	 * @throws SQLException
	 */
	public List<Long> getLimitedJobsByFamiliy() throws DataAccessException,
			SQLException {
		Map<String, Object> map = new HashMap<String, Object>();
		Map<String, Object> resultMap = execute(map);
		String tableName = (String) resultMap.get("tab_name");		
		if (StringUtils.isBlank(tableName)) return null;
		String sql = "select * from " + tableName;
		List<Long> jobIds = jdbcTemplate.queryForList(sql, Long.class);	
		return jobIds;
	}
}
