package jp.co.nec.aim.mm.spring.jms;

import org.springframework.jms.UncategorizedJmsException;
import org.springframework.jms.core.JmsTemplate;

/**
 * JmsProducer sends JMS Message with Spring JMSTemplate
 * 
 * @author kurosu
 * 
 */
public class JmsProducer {
	/** JmsTemplate will be injected by SpringFramework */
	private JmsTemplate jmsTemplate;
	private QueueStateFactory queueStateFactory;
	/**
	 * Number of messages to leave in Queue. JmsProducer remove messages in
	 * Queue when it's full.
	 */
	private int minMessages;

	/**
	 * 
	 * @param message
	 * @param timeToLive
	 *            Life time of JMS Message. zero means forever.
	 */
	public void sendMessage(Object message, long timeToLive) {
		if (timeToLive < 0) {
			timeToLive = 0;
		}
		jmsTemplate.setExplicitQosEnabled(true);
		jmsTemplate.setTimeToLive(timeToLive);
		try {
			jmsTemplate.convertAndSend(message);
		} catch (UncategorizedJmsException e) {
			synchronized (this) {
				// Spring throws UncategorizedJmsException when Queue is full.
				//removeMessages();
				// Try to send message again.
				jmsTemplate.convertAndSend(message);
			}
		}
	}

//	private void removeMessages() {
//		// String destinationName =
//		// jmsTemplate.getDefaultDestination().toString();
//		String destinationName = "";
//		QueueState state = null;
//		if (destinationName.contains("infoQueue")) {
//			state = queueStateFactory.getInfoQueueState();
//		} else if (destinationName.contains("errorQueue")) {
//			state = queueStateFactory.getErrorQueueState();
//		}
//		if (state != null) {
//			int min;
//			if (minMessages < 0) {
//				min = 0;
//			} else {
//				min = minMessages;
//			}
//			if (state.getMaxSize() <= min) {
//				if (state.getMessageCount() == state.getMaxSize()) {
//					// MessageCount == MaxSize == minMessages, remove only 1
//					// message.
//					// jmsTemplate.receive();
//				}
//			} else {
//				if (min < state.getMessageCount()) {
//					for (int i = min + 1; i <= state.getMessageCount(); i++) {
//						// jmsTemplate.receive();
//					}
//				}
//			}
//		}
//	}

	public JmsTemplate getJmsTemplate() {
		return jmsTemplate;
	}

	public void setJmsTemplate(JmsTemplate jmsTemplate) {
		this.jmsTemplate = jmsTemplate;
	}

	public QueueStateFactory getQueueStateFactory() {
		return queueStateFactory;
	}

	public void setQueueStateFactory(QueueStateFactory queueStateFactory) {
		this.queueStateFactory = queueStateFactory;
	}

	public int getMinMessages() {
		return minMessages;
	}

	public void setMinMessages(int minMessageNum) {
		this.minMessages = minMessageNum;
	}

}
