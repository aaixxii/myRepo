package jp.co.nec.aim.mm.extract.planner;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.ParameterMode;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.StoredProcedureParameter;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

@NamedStoredProcedureQuery(name = "getfirstMuRemainLots", resultClasses = MuRemainLots.class, procedureName = "PROCESS_ONE_MU_LOT", parameters = {
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "p_max_lot ", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.REF_CURSOR, name = "p_refcursor", type = void.class) })
@Entity
@Table(name = "MuRemainLots")
@SqlResultSetMapping(name = "MuRemainLots", classes = { @ConstructorResult(targetClass = MuRemainLots.class, columns = {
		@ColumnResult(name = "muId"), @ColumnResult(name = "currentlots"),
		@ColumnResult(name = "num_extractor"),
		@ColumnResult(name = "remain_lots") }) })
public class MuRemainLots implements Serializable {
	private static final long serialVersionUID = -3299056573454986433L;
	@Id
	@Column(name = "muId")
	private Long muId;
	@Column(name = "cureentLots")
	private Integer cureentLots;
	@Column(name = "num_extractor")
	private Integer numOfExtractor;
	@Column(name = "remain_lots")
	private Integer remainLots;

	public Long getMuId() {
		return muId;
	}

	public void setMuId(Long muId) {
		this.muId = muId;
	}

	public Integer getCureentLots() {
		return cureentLots;
	}

	public void setCureentLots(Integer cureentLots) {
		this.cureentLots = cureentLots;
	}

	public Integer getNumOfExtractor() {
		return numOfExtractor;
	}

	public void setNumOfExtractor(Integer numOfExtractor) {
		this.numOfExtractor = numOfExtractor;
	}

	public Integer getRemainLots() {
		return remainLots;
	}

	public void setRemainLots(Integer remainLots) {
		this.remainLots = remainLots;
	}

	public String toString(Integer muId, Integer curLot, Integer remainLots) {
		return null;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this,
				ToStringStyle.SHORT_PREFIX_STYLE);
	}
}
