package jp.co.nec.aim.mm.dao;

import java.sql.Blob;
import java.sql.SQLException;
import java.time.LocalDate;

import javax.sql.DataSource;
import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;

import org.springframework.jdbc.core.JdbcTemplate;

import jp.co.nec.aim.dm.message.proto.AimDmMessages.SegmentSyncCommandType;
import jp.co.nec.aim.mm.partition.PartitionUtil;
import jp.co.nec.aim.mm.segment.sync.SegSyncInfos;

public class SegmentChangeLogDao {	
	private JdbcTemplate jdbcTemplate;

	private static String insertChangeLogSql = " INSERT INTO SEGMENT_CHANGE_LOG (SEGMENT_ID,SEGMENT_VERSION,CHANGE_TYPE, EXTERNAL_ID,TEMPLATE_DATA, UPDATE_TS, P_NO, BIOMETRICS_ID) "
			+ "VALUES (?, ?, ?, ?, ?, CAST(NOW() AS date), ?, ?)";
	
	public SegmentChangeLogDao(DataSource ds) {		
		jdbcTemplate = new JdbcTemplate(ds);
	}

	public void insertToSegChangeLog(SegSyncInfos segSyncInfo) throws SerialException, SQLException {		
		Long pNo = Long.valueOf(PartitionUtil.getInstance().caculateHashAtThisToday(LocalDate.now()));
		Blob blob = new SerialBlob(segSyncInfo.getTemplateData());
		Integer changeType = null;
		if (segSyncInfo.getCommand().equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_NEW)) {
			changeType = 0;
		} else if (segSyncInfo.getCommand().equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT)){
			changeType = 1;
		}  else if (segSyncInfo.getCommand().equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE)){
			changeType = 2;
		}
		jdbcTemplate.update(insertChangeLogSql, new Object[] {segSyncInfo.getSegmentId(), segSyncInfo.getSegVersion(), changeType, segSyncInfo.getExternalId(),
				blob, pNo, segSyncInfo.getTemplateId()});
	}	
}
