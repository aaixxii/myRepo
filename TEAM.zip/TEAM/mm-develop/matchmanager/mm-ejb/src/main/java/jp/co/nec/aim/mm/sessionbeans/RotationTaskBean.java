package jp.co.nec.aim.mm.sessionbeans;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.dao.PartitionDao;
import jp.co.nec.aim.mm.dao.SystemInitDao;
import jp.co.nec.aim.mm.partition.PartitionUtil;
import jp.co.nec.aim.mm.scheduler.QuartzManager;
import jp.co.nec.aim.mm.sessionbeans.pojo.AimManager;

@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class RotationTaskBean {

	private static final Logger logger = LoggerFactory.getLogger(RotationTaskBean.class);

	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;

	private PartitionDao partitionDao;
	private SystemInitDao systemInitDao;

	public RotationTaskBean() {
	}

	@PostConstruct
	public void init() {
		partitionDao = new PartitionDao(dataSource);
		systemInitDao = new SystemInitDao(manager);
	}

	public void createNextPartitionAndClearBefore() {
		String deleteFlag = systemInitDao.getClearFlag();
		Long saveDaysInMyMem = AimManager.getSegChangeSaveDays();
		//Long adjuistInMyMen = AimManager.getInUsingAdjust();
		Long saveDays = systemInitDao.getSegChangeLogSaveDays();
		//Long adjust = systemInitDao.getInUsingAdjust();
		if (saveDaysInMyMem == saveDays) {
			LocalDate now = LocalDate.now();
			LocalDate targetAddDay = now.plusDays(saveDays);
			long targetAddPno = PartitionUtil.getInstance().caculateHashAtThisToday(targetAddDay);
			LocalDate targetClearDay = now.minusDays(saveDays);
			long targetClearPno = PartitionUtil.getInstance().caculateHashAtThisToday(targetClearDay);
			try {
				if (deleteFlag.toUpperCase().equals("TRUE")) {
					partitionDao.deleteOldPartition(targetClearPno);
					logger.info("Success drop partition for day({}), pNo({})", targetClearDay, targetClearPno);
				}				
				partitionDao.addNewPartition(targetAddPno);
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}			
			logger.info("Success add new  partition for day({}), pNo({})", targetAddDay, targetAddPno);
					
		} else {
			if (saveDays - saveDaysInMyMem > 0) {
				doAdd(saveDaysInMyMem, saveDays);
			} else {			
				doReduce(saveDays, saveDaysInMyMem);
			}
		}	
	}
	
	private void doAdd(Long oldSaveDays, Long newSaveDays) {
		PartitionUtil partitionUtil = PartitionUtil.getInstance();
		LocalDate updateAtToday = LocalDate.now();		
		long adjust = partitionUtil.caculateNewAdjustAtThisDay(newSaveDays, oldSaveDays,updateAtToday);
		logger.info("new adjust value is {}",adjust);			
		//Date sqlDate = Date.valueOf(firstAddDay);
		systemInitDao.updateInUsingAdjuist(adjust);
		List<Long> toBeAddPno = new ArrayList<>();
		for (long i = oldSaveDays; i < newSaveDays; i++) {
			toBeAddPno.add(Long.valueOf(i));
		}	
		partitionDao.createNewPartitions(toBeAddPno);	
		String str = toBeAddPno.stream().map(one -> one.toString()).collect(Collectors.joining(","));
		logger.info("Added partitions {}", str);
	}
	
	private void doReduce(Long newNo, Long oldSaveDays) {
		PartitionUtil partitionUtil = PartitionUtil.getInstance();		
		LocalDate now = LocalDate.now();
		long hashValueOnToday = partitionUtil.caculateHashAtThisToday(now);
		long diffOnTodayToMaxDay = oldSaveDays - hashValueOnToday;
		LocalDate maxDay = now.plusDays(diffOnTodayToMaxDay);		
		long diffOnNewDayToMaxDay = oldSaveDays - newNo > 0 ? oldSaveDays - newNo : -1 * (oldSaveDays - newNo);	
		LocalDate firstUpdateDay = maxDay.minusDays(diffOnNewDayToMaxDay);
		LocalDate epoch = LocalDate.ofEpochDay(0);
		long epochDays = ChronoUnit.DAYS.between(epoch, firstUpdateDay);
		long adjust = partitionUtil.caculateNewAdjustAtThisDay(newNo, oldSaveDays, firstUpdateDay);
		long newHashValue = (epochDays + adjust) % newNo;
		logger.info("new hash value is {}", newHashValue);
		systemInitDao.updateInUsingAdjuist(adjust);						
		QuartzManager qm = QuartzManager.getInstance(manager);
		qm.deleteRotationTask();
		qm.reStartRotationTask(firstUpdateDay);		
	}
}
