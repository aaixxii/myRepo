package com.nec.aim.dm.dmservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.nec.aim.dm.dmservice.config.ShutdownHook;
import com.nec.aim.dm.dmservice.socket.HeartBeatSocketServer;
import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class DmserviceApplication {	
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {		
		SpringApplication.run(DmserviceApplication.class, args);		
		String socketPort = null;
		if (args.length == 3 && args[1] != null) {
			socketPort = args[1];			
			HeartBeatSocketServer.getInstance().start(Integer.valueOf(socketPort));
		} else if (args.length == 2 && args[0] != null) {
			socketPort = args[0];
			HeartBeatSocketServer.getInstance().start(Integer.valueOf(socketPort));	
			try {
				int port = Integer.valueOf(socketPort);
				HeartBeatSocketServer server = new HeartBeatSocketServer();
				HeartBeatSocketServer.getInstance().start(Integer.valueOf(port));
				server.start(port);
			} catch (NumberFormatException e) {
			}
		}
		new ShutdownHook();
		log.info("DM service success started");
	}
}
