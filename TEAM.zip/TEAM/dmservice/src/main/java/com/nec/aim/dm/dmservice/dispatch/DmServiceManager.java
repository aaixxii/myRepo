package com.nec.aim.dm.dmservice.dispatch;

import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DmServiceManager {	
	private static ExecutorService dmJobExecutor = Executors.newCachedThreadPool();
	private static final ConcurrentHashMap<String, List<String>> serviceUrlMap = new ConcurrentHashMap<>();	
	private static final ConcurrentHashMap<Integer, String> NodeStorageUrlMap = new ConcurrentHashMap<>();	
	private static final  AtomicInteger redundancy = new AtomicInteger(1);

	/**
	 * @return
	 */
	public static AtomicInteger getRedundancy() {
		return redundancy;
	}
	
	/**
	 * @param newValue
	 */
	public static void setRedundancy(int newValue) {
		redundancy.set(newValue);		
	}

	/**
	 * @param key
	 * @return
	 */
	public static List<String> getServiceUrlValue(String key) {
		return serviceUrlMap.get(key);
	}
	
	/**
	 * @param key
	 * @param vauleList
	 */
	public static void putSeriveUrl(String key, List<String> vauleList) {
		serviceUrlMap.putIfAbsent(key, vauleList);		
	}
	
	/**
	 * @param key
	 * @return
	 */
	public static String getValueFromNodeStorageUrlMap(Integer key) {
		return NodeStorageUrlMap.get(key);
	}
	
	/**
	 * @param id
	 * @param url
	 */
	public static void putToNodeStorageUrlMap(Integer id, String url) {
		NodeStorageUrlMap.putIfAbsent(id, url);
	}
	
	/**
	 * @param task
	 * @return
	 */
	public static Boolean sumitDmJob(Callable<Boolean> task) {
		Future<Boolean> future = dmJobExecutor.submit(task);
		try {
			return future.get();
		} catch (InterruptedException | ExecutionException e) {
			log.error(e.getMessage(), e);
			return Boolean.FALSE;
		}
	}
	
	/**
	 * @param c
	 * @return
	 */
	public static <T> CompletableFuture<T> callableAsync(Callable<T> c) {
		CompletableFuture<T> cf = new CompletableFuture<>();
		dmJobExecutor.execute(() -> {
			try {
				cf.complete(c.call());

			} catch (Throwable ex) {
				cf.completeExceptionally(ex);
			}
		});
		return cf;
	}
	
	/**
	 * @param c
	 * @return
	 * @throws InterruptedException
	 * @throws ExecutionException
	 */
	public static Boolean submit(Callable<Boolean> c) throws InterruptedException, ExecutionException {
		CompletableFuture<Boolean> cf = new CompletableFuture<>();
		dmJobExecutor.execute(() -> {
			try {
				cf.complete(c.call());
			} catch (Throwable ex) {
				cf.completeExceptionally(ex);
			}
		});
		return cf.get();
	}
	
	/**
	 * @param c
	 * @return
	 * @throws InterruptedException
	 * @throws ExecutionException
	 */
	public static byte[] submitGetRequest(Callable<byte[]> c) throws InterruptedException, ExecutionException {
		CompletableFuture<byte[]> cf = new CompletableFuture<>();
		dmJobExecutor.execute(() -> {
			try {
				cf.complete(c.call());
			} catch (Throwable ex) {
				cf.completeExceptionally(ex);				
			}
		});
		return cf.get();
	}
	
	public static void close() {
		dmJobExecutor.shutdownNow();
	}
	
	/**
	 * @param c
	 * @return
	 * @throws InterruptedException
	 * @throws ExecutionException
	 */
	public static String submitGetBioIdRequest(Callable<String> c) throws InterruptedException, ExecutionException {
		CompletableFuture<String> cf = new CompletableFuture<>();
		dmJobExecutor.execute(() -> {
			try {
				cf.complete(c.call());
			} catch (Throwable ex) {
				cf.completeExceptionally(ex);				
			}
		});
		return cf.get();
	}
	
}
