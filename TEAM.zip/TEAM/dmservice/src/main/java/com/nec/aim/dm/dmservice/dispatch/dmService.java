package com.nec.aim.dm.dmservice.dispatch;

import java.sql.SQLException;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nec.aim.dm.dmservice.entity.NsmIdUrl;
import com.nec.aim.dm.dmservice.exception.DmServiceException;
import com.nec.aim.dm.dmservice.persistence.DmConfigRepository;
import com.nec.aim.dm.dmservice.persistence.NodeStorageManagerRepository;
import com.nec.aim.dm.dmservice.socket.HeartBeatSocketServer;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class dmService {	

	@Autowired
	NodeStorageManagerRepository nodeStorageManagerRepository;
	
	@Autowired
	DmConfigRepository dmConfigRepository;	

	@PostConstruct
	public void getSetting() {
		List<NsmIdUrl> sbList = null;
		try {				
			sbList = nodeStorageManagerRepository.getNodeStorageUrlAndId();
			if (sbList == null || sbList.size() < 1) {
				log.warn("No SB that status in 0 or 1");
			} else {
				log.info("SB size={}", sbList.size());
				sbList.forEach(one -> {
					if (one != null && one.getBasUrl() != null && one.getBasUrl().length() > 0 && one.getStorageId() != null ) {
						DmServiceManager.putToNodeStorageUrlMap(one.getStorageId(), one.getBasUrl());
					}
				});
			}
			int redundancy = dmConfigRepository.getRedundancy();
			if (redundancy < 1) {
				throw new DmServiceException("redundancy is less 1!");
			}
			DmServiceManager.setRedundancy(redundancy);
		} catch (SQLException e) {
			log.error(e.getMessage());
		}
	}

	@PreDestroy
	public void close() {
		DmServiceManager.close();
		HeartBeatSocketServer.getInstance().close();
	}
}
