package com.nec.aim.dm.dmservice;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes={DmserviceApplication.class})
class DmserviceApplicationTests {

	void contextLoads() {
	}

}
