package jp.co.nec.aim.mm.dao;

import static org.junit.Assert.assertEquals;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class SegmentDefragDaoTest {
	@PersistenceContext(unitName = "AIMDB")
	private EntityManager entityManager;
	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;

	private SegmentDefragDao dao;

	@Before
	public void setUp() throws Exception {
		clearDB();

		jdbcTemplate.execute("insert into system_config values(1,"
				+ " 'DEFRAG_TIMEOUT', '100000')");
		jdbcTemplate.update("commit");

		dao = new SegmentDefragDao(dataSource);
	}

	@After
	public void tearDown() throws Exception {
		clearDB();
	}

	private void clearDB() {
		jdbcTemplate.execute("delete from SEGMENT_DEFRAGMENTATION");
		jdbcTemplate.execute("delete from system_config");
		jdbcTemplate.execute("commit");
	}

	@Test
	public void test_initDefragContainerId() {

		dao.initDefragContainerId();
		int containerId = jdbcTemplate.queryForObject(
				"select CONTAINER_ID from SEGMENT_DEFRAGMENTATION",
				Integer.class);
		assertEquals(-1, containerId);

		jdbcTemplate.execute("delete from SEGMENT_DEFRAGMENTATION");
		jdbcTemplate.execute("insert into SEGMENT_DEFRAGMENTATION("
				+ "CONTAINER_ID, START_TS, END_TS) values(1, 0, 0)");
		jdbcTemplate.execute("commit");

		dao.initDefragContainerId();
		containerId = jdbcTemplate.queryForObject(
				"select CONTAINER_ID from SEGMENT_DEFRAGMENTATION",
				Integer.class);
		assertEquals(-1, containerId);
	}

	@Test
	public void test_getDefragContainerId() {
		dao.initDefragContainerId();
		int containerId = dao.getDefragContainerId();
		assertEquals(-1, containerId);

		jdbcTemplate.execute("delete from SEGMENT_DEFRAGMENTATION");
		jdbcTemplate.execute("insert into SEGMENT_DEFRAGMENTATION("
				+ "CONTAINER_ID, START_TS, END_TS) values(1, 0, 0)");
		jdbcTemplate.execute("commit");

		containerId = dao.getDefragContainerId();
		assertEquals(1, containerId);
	}

	@Test
	public void test_setDefragContainerId() {

		dao.initDefragContainerId();
		int containerId = jdbcTemplate.queryForObject(
				"select CONTAINER_ID from SEGMENT_DEFRAGMENTATION",
				Integer.class);
		assertEquals(-1, containerId);

		dao.setDefragContainerId(1);
		containerId = jdbcTemplate.queryForObject(
				"select CONTAINER_ID from SEGMENT_DEFRAGMENTATION",
				Integer.class);
		assertEquals(1, containerId);
	}

	@Test
	public void test_checkTimeOut() {

		jdbcTemplate.execute("insert into SEGMENT_DEFRAGMENTATION("
				+ "CONTAINER_ID, START_TS, END_TS) values(1, "
				+ "match_manager_api.get_epoch_time_num(), "
				+ "match_manager_api.get_epoch_time_num())");
		dao.checkTimeOut();
		int containerId = jdbcTemplate.queryForObject(
				"select CONTAINER_ID from SEGMENT_DEFRAGMENTATION",
				Integer.class);
		assertEquals(1, containerId);

		jdbcTemplate.execute("delete from SEGMENT_DEFRAGMENTATION");
		jdbcTemplate.execute("insert into SEGMENT_DEFRAGMENTATION("
				+ "CONTAINER_ID, START_TS, END_TS) values(1, 0, 0)");

		dao.checkTimeOut();

		containerId = jdbcTemplate.queryForObject(
				"select CONTAINER_ID from SEGMENT_DEFRAGMENTATION",
				Integer.class);
		assertEquals(-1, containerId);
	}

}
