package jp.co.nec.aim.mm.identify.planner;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.dao.IdentifyPlannerDao;
import mockit.Deencapsulation;
import mockit.Mocked;
import mockit.NonStrictExpectations;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.jdbc.core.JdbcTemplate;

public class IdentifyPlanManagerTest2 {
	@PersistenceContext(unitName = "AIMDB")
	protected EntityManager entityManager;
	@Resource
	protected DataSource dataSource;
	@Resource
	protected JdbcTemplate jdbcTemplate;

	@SuppressWarnings("unchecked")
	@Test
	public void testMakeUniqeKey() throws NoSuchMethodException,
			SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {
		Method method = IdentifyPlanManager.class.getDeclaredMethod(
				"makeUniqeKey", List.class);
		method.setAccessible(true);
		IdentifyPlanManager identifyPlanManager = new IdentifyPlanManager();
		List<CombinedJobInfo> jobInfoList = new ArrayList<>();
		Integer[] functionId = { 1, 1, 2, 2, 2, 2, 3, 3 };
		Integer[] containerId = { 110, 110, 210, 210, 210, 210, 310, 310 };
		Long[] contaierJobId = { 1100L, 1101L, 2210L, 2210L, 2210L, 2210L,
				2210L, 3100L, 3100L };
		for (int i = 0; i < functionId.length; i++) {
			CombinedJobInfo combInfo = new CombinedJobInfo(containerId[i],
					functionId[i], contaierJobId[i]);
			jobInfoList.add(combInfo);
		}
		List<MuSegmentMapKey> results = (List<MuSegmentMapKey>) method.invoke(
				identifyPlanManager, jobInfoList);
		Assert.assertEquals(3, results.size());
		for (int i = 0; i < results.size() - 1; i++) {
			Assert.assertTrue(new MuSegmentMapKeyComparator().compare(
					results.get(i), results.get(i + 1)) != 0);

		}
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testMakeUniqeKey1() throws NoSuchMethodException,
			SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {
		Method method = IdentifyPlanManager.class.getDeclaredMethod(
				"makeUniqeKey", List.class);
		method.setAccessible(true);
		IdentifyPlanManager identifyPlanManager = new IdentifyPlanManager();
		List<CombinedJobInfo> jobInfoList = new ArrayList<>();
		Integer[] functionId = { 1, 2, 3, 4, 5 };
		Integer[] containerId = { 10, 11, 12, 13, 14 };
		Long[] contaierJobId = { 20L, 21L, 22L, 23L, 25L };
		for (int i = 0; i < functionId.length; i++) {
			CombinedJobInfo combInfo = new CombinedJobInfo(containerId[i],
					functionId[i], contaierJobId[i]);
			jobInfoList.add(combInfo);
		}
		List<MuSegmentMapKey> results = (List<MuSegmentMapKey>) method.invoke(
				identifyPlanManager, jobInfoList);
		Assert.assertEquals(5, results.size());
		for (int i = 0; i < results.size() - 1; i++) {
			Assert.assertTrue(new MuSegmentMapKeyComparator().compare(
					results.get(i), results.get(i + 1)) != 0);
		}
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testMakeUniqeKey2() throws NoSuchMethodException,
			SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {
		Method method = IdentifyPlanManager.class.getDeclaredMethod(
				"makeUniqeKey", List.class);
		method.setAccessible(true);
		IdentifyPlanManager identifyPlanManager = new IdentifyPlanManager();
		List<CombinedJobInfo> jobInfoList = new ArrayList<>();
		Integer[] functionId = { 1, 2, 2, 2, 5 };
		Integer[] containerId = { 10, 11, 11, 11, 14 };
		Long[] contaierJobId = { 20L, 21L, 21L, 21L, 25L };
		for (int i = 0; i < functionId.length; i++) {
			CombinedJobInfo combInfo = new CombinedJobInfo(containerId[i],
					functionId[i], contaierJobId[i]);
			jobInfoList.add(combInfo);
		}
		List<MuSegmentMapKey> results = (List<MuSegmentMapKey>) method.invoke(
				identifyPlanManager, jobInfoList);
		Assert.assertEquals(3, results.size());
		for (int i = 0; i < results.size() - 1; i++) {
			Assert.assertTrue(new MuSegmentMapKeyComparator().compare(
					results.get(i), results.get(i + 1)) != 0);
		}
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testMakeUniqeKey3() throws NoSuchMethodException,
			SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {
		Method method = IdentifyPlanManager.class.getDeclaredMethod(
				"makeUniqeKey", List.class);
		method.setAccessible(true);
		IdentifyPlanManager identifyPlanManager = new IdentifyPlanManager();
		List<CombinedJobInfo> jobInfoList = new ArrayList<>();
		Integer[] functionId = { 1, 1, 1, 1, 1 };
		Integer[] containerId = { 10, 10, 10, 10, 10 };
		Long[] contaierJobId = { 20L, 20L, 20L, 20L, 20L };
		for (int i = 0; i < functionId.length; i++) {
			CombinedJobInfo combInfo = new CombinedJobInfo(containerId[i],
					functionId[i], contaierJobId[i]);
			jobInfoList.add(combInfo);
		}
		List<MuSegmentMapKey> results = (List<MuSegmentMapKey>) method.invoke(
				identifyPlanManager, jobInfoList);
		Assert.assertEquals(1, results.size());
		for (int i = 0; i < results.size() - 1; i++) {
			Assert.assertTrue(new MuSegmentMapKeyComparator().compare(
					results.get(i), results.get(i + 1)) != 0);
		}
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testMakeUniqeKey4() throws NoSuchMethodException,
			SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {
		Method method = IdentifyPlanManager.class.getDeclaredMethod(
				"makeUniqeKey", List.class);
		method.setAccessible(true);
		IdentifyPlanManager identifyPlanManager = new IdentifyPlanManager();
		List<CombinedJobInfo> jobInfoList = new ArrayList<>();
		Integer[] functionId = { 1, 1, 1, 1, 1 };
		Integer[] containerId = { 11, 11, 11, 11, 10 };
		Long[] contaierJobId = { 20L, 20L, 20L, 20L, 20L };
		for (int i = 0; i < functionId.length; i++) {
			CombinedJobInfo combInfo = new CombinedJobInfo(containerId[i],
					functionId[i], contaierJobId[i]);
			jobInfoList.add(combInfo);
		}
		List<MuSegmentMapKey> results = (List<MuSegmentMapKey>) method.invoke(
				identifyPlanManager, jobInfoList);
		Assert.assertEquals(2, results.size());
		for (int i = 0; i < results.size() - 1; i++) {
			Assert.assertTrue(new MuSegmentMapKeyComparator().compare(
					results.get(i), results.get(i + 1)) != 0);
		}
	}

	@Test
	public void testMuSegmentMapKeyIsWorking1() {
		ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>> testMaps = new ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>>();
		int size = 6;
		Integer[] functionIds = { 1, 2, 3, 4, 5, 6 };
		Integer[] containerIds = { 100, 200, 300, 400, 500, 600 };
		for (int i = 0; i < size; i++) {
			testMaps.put(new MuSegmentMapKey(functionIds[i], containerIds[i]),
					createMuSegMap(size, functionIds[i], containerIds[i]));
		}
		Assert.assertEquals(size, testMaps.size());
		for (int i = 0; i < size; i++) {
			Assert.assertTrue(testMaps.containsKey(new MuSegmentMapKey(
					functionIds[i], containerIds[i])));
		}
	}

	@Test
	public void testMuSegmentMapKeyIsWorking2() {
		ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>> testMaps = new ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>>();
		int size = 6;
		Integer[] functionIds = { 1, 1, 1, 1, 1, 1 };
		Integer[] containerIds = { 100, 100, 100, 100, 100, 100 };
		for (int i = 0; i < size; i++) {
			testMaps.put(new MuSegmentMapKey(functionIds[i], containerIds[i]),
					createMuSegMap(size, functionIds[i], containerIds[i]));
		}
		Assert.assertEquals(1, testMaps.size());
		for (int i = 0; i < size; i++) {
			Assert.assertTrue(testMaps.containsKey(new MuSegmentMapKey(
					functionIds[i], containerIds[i])));
		}
		Iterator<MuSegmentMapKey> it = testMaps.keySet().iterator();
		while (it.hasNext()) {
			Assert.assertEquals(new MuSegmentMapKey(1, 100), it.next());
		}
	}

	@Test
	public void testMuSegmentMapKeyIsWorking3() {
		ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>> testMaps = new ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>>();
		int size = 6;
		Integer[] functionIds = { 1, 2, 3, 4, 5, 6 };
		Integer[] containerIds = { 100, 200, 300, 400, 500, 600 };
		for (int i = 0; i < size; i++) {
			testMaps.put(new MuSegmentMapKey(functionIds[i], containerIds[i]),
					createMuSegMap(size, functionIds[i], containerIds[i]));
		}
		Assert.assertEquals(size, testMaps.size());
		for (int i = 0; i < size; i++) {
			Assert.assertTrue(testMaps.containsKey(new MuSegmentMapKey(
					functionIds[i], containerIds[i])));
		}
		Set<MuSegmentMapKey> keys = testMaps.keySet();
		List<MuSegmentMapKey> keyList = new ArrayList<MuSegmentMapKey>(keys);
		Collections.sort(keyList, new MuSegmentMapKeyComparator());
		for (int i = 0; i < keyList.size(); i++) {
			Assert.assertEquals(new MuSegmentMapKey(functionIds[i],
					containerIds[i]), keyList.get(i));
		}
	}

	@Test
	public void testCalculatingSegmentCount() throws NoSuchMethodException,
			SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {
		IdentifyPlanManager identifyPlanManager = new IdentifyPlanManager();

		Method method = IdentifyPlanManager.class.getDeclaredMethod(
				"calculatingSegmentCount", MuSegmentMapKey.class);
		method.setAccessible(true);

		ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>> segMapList = new ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>>();
		int size = 7;
		Integer[] fuctionIds = { 1, 2, 3, 4, 5, 6, 7 };
		Integer[] containerIds = { 11, 22, 33, 44, 55, 66, 77 };
		int[] sameSegCount = { 5, 6, 7, 8, 9, 0, 10 };
		int[] listSize = { 10, 15, 20, 25, 30, 10, 10 };
		for (int i = 0; i < size; i++) {
			List<MuSegmentMap> tmpList = createTestMuSegMaps(listSize[i],
					fuctionIds[i], containerIds[i], sameSegCount[i]);
			segMapList.put(new MuSegmentMapKey(fuctionIds[i], containerIds[i]),
					tmpList);
		}
		Deencapsulation.setField(identifyPlanManager, "memMuSegmentMaps",
				segMapList);

		for (int i = 0; i < containerIds.length; i++) {
			Integer results = (Integer) method.invoke(identifyPlanManager,
					new MuSegmentMapKey(fuctionIds[i], containerIds[i]));
			if (sameSegCount[i] == 0) {
				Assert.assertEquals((listSize[i] - sameSegCount[i]),
						results.intValue());
			} else {
				Assert.assertEquals((listSize[i] - sameSegCount[i] + 1),
						results.intValue());
			}
		}
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testFetchMuIdsFromMuSegMap() throws NoSuchMethodException,
			SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {
		IdentifyPlanManager identifyPlanManager = new IdentifyPlanManager();
		Method method = IdentifyPlanManager.class.getDeclaredMethod(
				"fetchMuIdsFromMuSegMap", List.class);
		method.setAccessible(true);
		ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>> segMapList = new ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>>();
		List<MuSegmentMapKey> keyList = new ArrayList<>();
		int size = 6;
		Integer[] fuctionIds = { 1, 2, 3, 4, 5, 6 };
		Integer[] containerIds = { 11, 22, 33, 44, 55, 66 };
		int[] sameMuCount = { 5, 6, 7, 8, 0, 10 };
		int[] listSize = { 10, 15, 20, 25, 10, 10 };
		for (int i = 0; i < size; i++) {
			MuSegmentMapKey key = new MuSegmentMapKey(fuctionIds[i],
					containerIds[i]);
			keyList.add(key);
			List<MuSegmentMap> tmpList = createTestMuSegMaps1(listSize[i],
					fuctionIds[i], containerIds[i], sameMuCount[i]);
			segMapList.put(key, tmpList);
		}
		Deencapsulation.setField(identifyPlanManager, "memMuSegmentMaps",
				segMapList);

		for (int i = 0; i < segMapList.size(); i++) {
			Set<Integer> results = (Set<Integer>) method.invoke(
					identifyPlanManager, segMapList.get(keyList.get(i)));
			if (sameMuCount[i] == 0) {
				Assert.assertEquals(listSize[i], results.size());
			} else {
				Assert.assertEquals((listSize[i] - sameMuCount[i] + 1),
						results.size());
			}
		}
	}

	@Test
	public void testDoUpdateMuSegMapsFromDB_ture(
			@Mocked final IdentifyPlannerDao dao) throws NoSuchMethodException,
			SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {
		final Integer containerId = 1;
		final Integer functionId = 1;
		final List<MuSegmentMap> dbMapList = createMuSegMap(5, containerId,
				functionId);
		try {
			new NonStrictExpectations() {
				{
					dao.getNewMuSegMaps(containerId, functionId);
					result = dbMapList;
				}
				{
					dao.getSegmentCount(containerId);
					result = 5;
				}
			};
		} catch (SQLException e) {
			e.printStackTrace();
		}
		IdentifyPlanManager identifyPlanManager = new IdentifyPlanManager();
		Method method = IdentifyPlanManager.class.getDeclaredMethod(
				"doUpdateMuSegMapsFromDB", new Class[] { MuSegmentMapKey.class,
						Long.class });
		method.setAccessible(true);
		ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>> segMapList = new ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>>();

		List<MuSegmentMap> tmpList = createTestMuSegMaps(10, functionId,
				containerId, 0);
		segMapList.put(new MuSegmentMapKey(functionId, containerId), tmpList);
		Deencapsulation.setField(identifyPlanManager, "memMuSegmentMaps",
				segMapList);
		Deencapsulation.setField(identifyPlanManager, "identifyDao", dao);
		MuSegmentMapKey key = new MuSegmentMapKey(1, 1);
		boolean result = (boolean) method.invoke(identifyPlanManager,
				new Object[] { key, 1L });
		Assert.assertTrue(result);
	}

	@Test
	public void testDoUpdateMuSegMapsFromDB_false(
			@Mocked final IdentifyPlannerDao dao) throws NoSuchMethodException,
			SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {
		final Integer containerId = 1;
		final Integer functionId = 1;
		final List<MuSegmentMap> dbMapList = createMuSegMap(5, containerId,
				functionId);

		try {
			new NonStrictExpectations() {
				{
					dao.getNewMuSegMaps(containerId, functionId);
					result = dbMapList;
				}
				{
					dao.getSegmentCount(containerId);
					result = 4;
				}
			};
		} catch (SQLException e) {
			e.printStackTrace();
		}
		IdentifyPlanManager identifyPlanManager = new IdentifyPlanManager();
		Method method = IdentifyPlanManager.class.getDeclaredMethod(
				"doUpdateMuSegMapsFromDB", new Class[] { MuSegmentMapKey.class,
						Long.class });
		method.setAccessible(true);
		ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>> segMapList = new ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>>();

		List<MuSegmentMap> tmpList = createTestMuSegMaps(10, functionId,
				containerId, 0);
		segMapList.put(new MuSegmentMapKey(functionId, containerId), tmpList);
		Deencapsulation.setField(identifyPlanManager, "memMuSegmentMaps",
				segMapList);
		Deencapsulation.setField(identifyPlanManager, "identifyDao", dao);
		MuSegmentMapKey key = new MuSegmentMapKey(1, 1);
		boolean result = (boolean) method.invoke(identifyPlanManager,
				new Object[] { key, 1L });
		Assert.assertTrue(!result);
	}

	@Test
	public void testDoUpdateMuSegMapsFromDB_manyContainers_true(
			@Mocked final IdentifyPlannerDao dao) throws NoSuchMethodException,
			SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {
		final Integer containerId = 1;
		final Integer functionId = 1;
		final List<MuSegmentMap> dbMapList = createMuSegMap(6, containerId,
				functionId);

		try {
			new NonStrictExpectations() {
				{
					dao.getNewMuSegMaps(containerId, functionId);
					result = dbMapList;
				}
				{
					dao.getSegmentCount(containerId);
					result = 6;
				}
			};
		} catch (SQLException e) {
			e.printStackTrace();
		}

		Method method = IdentifyPlanManager.class.getDeclaredMethod(
				"doUpdateMuSegMapsFromDB", new Class[] { MuSegmentMapKey.class,
						Long.class });

		method.setAccessible(true);
		IdentifyPlanManager identifyPlanManager = new IdentifyPlanManager();
		ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>> segMapList = new ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>>();

		int size = 7;
		Integer[] fuctionIds = { 1, 2, 3, 4, 5, 6, 1 };
		Integer[] containerIds = { 1, 22, 33, 44, 55, 66, 1 };
		int[] sameSegCount = { 4, 6, 7, 8, 9, 0, 10 };
		int[] listSize = { 10, 15, 20, 25, 30, 10, 10 };
		for (int i = 0; i < size; i++) {
			List<MuSegmentMap> tmpList = createTestMuSegMaps(listSize[i],
					fuctionIds[i], containerIds[i], sameSegCount[i]);
			segMapList.put(new MuSegmentMapKey(fuctionIds[i], containerIds[i]),
					tmpList);
		}
		Deencapsulation.setField(identifyPlanManager, "memMuSegmentMaps",
				segMapList);
		Deencapsulation.setField(identifyPlanManager, "identifyDao", dao);
		MuSegmentMapKey key = new MuSegmentMapKey(1, 1);
		boolean result = (boolean) method.invoke(identifyPlanManager,
				new Object[] { key, 1L });
		Assert.assertTrue(result);
	}

	@Test
	public void testDoUpdateMuSegMapsFromDB_manyContainers_false(
			@Mocked final IdentifyPlannerDao dao) throws NoSuchMethodException,
			SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {
		final Integer containerId = 1;
		final Integer functionId = 1;
		final List<MuSegmentMap> dbMapList = createMuSegMap(6, containerId,
				functionId);

		try {
			new NonStrictExpectations() {
				{
					dao.getNewMuSegMaps(containerId, functionId);
					result = dbMapList;
				}
				{
					dao.getSegmentCount(containerId);
					result = 5;
				}
			};
		} catch (SQLException e) {
			e.printStackTrace();
		}

		Method method = IdentifyPlanManager.class.getDeclaredMethod(
				"doUpdateMuSegMapsFromDB", new Class[] { MuSegmentMapKey.class,
						Long.class });

		method.setAccessible(true);
		IdentifyPlanManager identifyPlanManager = new IdentifyPlanManager();
		ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>> segMapList = new ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>>();

		int size = 7;
		Integer[] fuctionIds = { 1, 2, 3, 4, 5, 6, 1 };
		Integer[] containerIds = { 1, 22, 33, 44, 55, 66, 1 };
		int[] sameSegCount = { 4, 6, 7, 8, 9, 0, 10 };
		int[] listSize = { 10, 15, 20, 25, 30, 10, 10 };
		for (int i = 0; i < size; i++) {
			List<MuSegmentMap> tmpList = createTestMuSegMaps(listSize[i],
					fuctionIds[i], containerIds[i], sameSegCount[i]);
			segMapList.put(new MuSegmentMapKey(fuctionIds[i], containerIds[i]),
					tmpList);
		}
		Deencapsulation.setField(identifyPlanManager, "memMuSegmentMaps",
				segMapList);
		Deencapsulation.setField(identifyPlanManager, "identifyDao", dao);
		MuSegmentMapKey key = new MuSegmentMapKey(1, 1);
		boolean result = (boolean) method.invoke(identifyPlanManager,
				new Object[] { key, 1L });
		Assert.assertTrue(!result);
	}

	@Test
	public void testDoUpdateMuSegMapsFromMem_true(
			@Mocked final IdentifyPlannerDao dao) throws NoSuchMethodException,
			SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {
		final Integer containerId = 1;
		final Integer functionId = 1;
		Long[] segIds = { 1000L, 1001L, 1002L, 1003L, 1004L, 1005L };
		Long[] segVers = { 10L, 11L, 12L, 13L, 14L, 15L };
		final List<SegmentIdAndVeison> newSegVerList = createSegmentIdAndVersions(
				segIds, segVers);
		try {
			new NonStrictExpectations() {
				{
					dao.getSegmentVersionByContainerId(containerId);
					result = newSegVerList;
				}
				{
					dao.getSegmentCount(containerId);
					result = 12;
				}
			};
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Method method = IdentifyPlanManager.class.getDeclaredMethod(
				"doUpdateMuSegMapsFromMem", new Class[] {
						MuSegmentMapKey.class, Long.class });
		method.setAccessible(true);
		IdentifyPlanManager identifyPlanManager = new IdentifyPlanManager();
		ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>> segMapList = new ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>>();

		List<MuSegmentMap> tmpList = createTestMuSegMapsForCheakVers(12,
				functionId, containerId, segIds);
		segMapList.put(new MuSegmentMapKey(functionId, containerId), tmpList);
		Deencapsulation.setField(identifyPlanManager, "memMuSegmentMaps",
				segMapList);
		Deencapsulation.setField(identifyPlanManager, "identifyDao", dao);

		MuSegmentMapKey key = new MuSegmentMapKey(1, 1);
		boolean result = (boolean) method.invoke(identifyPlanManager,
				new Object[] { key, 1L });
		Assert.assertTrue(result);

	}

	@Test
	public void testDoUpdateMuSegMapsFromMem_false(
			@Mocked final IdentifyPlannerDao dao) throws NoSuchMethodException,
			SecurityException, IllegalAccessException,
			IllegalArgumentException, InvocationTargetException {
		final Integer containerId = 1;
		final Integer functionId = 1;
		Long[] segIds = { 1000L, 1001L, 1002L, 1003L, 1004L, 1005L };
		Long[] segVers = { 10L, 11L, 12L, 13L, 14L, 15L };
		final List<SegmentIdAndVeison> newSegVerList = createSegmentIdAndVersions(
				segIds, segVers);
		try {
			new NonStrictExpectations() {
				{
					dao.getSegmentVersionByContainerId(containerId);
					result = newSegVerList;
				}
				{
					dao.getSegmentCount(containerId);
					result = 11;
				}
			};
		} catch (SQLException e) {
			e.printStackTrace();
		}
		Method method = IdentifyPlanManager.class.getDeclaredMethod(
				"doUpdateMuSegMapsFromMem", new Class[] {
						MuSegmentMapKey.class, Long.class });
		method.setAccessible(true);
		IdentifyPlanManager identifyPlanManager = new IdentifyPlanManager();
		ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>> segMapList = new ConcurrentHashMap<MuSegmentMapKey, List<MuSegmentMap>>();

		List<MuSegmentMap> tmpList = createTestMuSegMapsForCheakVers(12,
				functionId, containerId, segIds);
		segMapList.put(new MuSegmentMapKey(functionId, containerId), tmpList);
		Deencapsulation.setField(identifyPlanManager, "memMuSegmentMaps",
				segMapList);
		Deencapsulation.setField(identifyPlanManager, "identifyDao", dao);

		MuSegmentMapKey key = new MuSegmentMapKey(1, 1);
		boolean result = (boolean) method.invoke(identifyPlanManager,
				new Object[] { key, 1L });
		Assert.assertTrue(!result);

	}

	public List<SegmentIdAndVeison> createSegmentIdAndVersions(Long[] segIds,
			Long[] segVers) {
		List<SegmentIdAndVeison> newSegVersions = new ArrayList<SegmentIdAndVeison>();
		for (int i = 0; i < segIds.length; i++) {
			SegmentIdAndVeison segVer = new SegmentIdAndVeison();
			segVer.setSegmentId(segIds[i]);
			segVer.setVersion(segVers[i]);
			newSegVersions.add(segVer);
		}
		return newSegVersions;
	}

	public List<MuSegmentMap> createTestMuSegMapsForCheakVers(int size,
			Integer functionId, Integer containerId, Long[] sameSegCounts) {
		List<MuSegmentMap> maps = new ArrayList<>();
		for (int i = 0; i < size; i++) {
			MuSegmentMap map = new MuSegmentMap();
			map.setContainerId(containerId);
			map.setFunctionId(functionId);
			if (i < sameSegCounts.length) {
				map.setSegmentId(sameSegCounts[i]);
			} else {
				map.setSegmentId(Long.valueOf(i * 123 + 2));
			}
			map.setMuId(i);
			map.setSegmentVersion(Long.valueOf(i + 2));
			map.setStatus(0);
			maps.add(map);
		}
		return maps;
	}

	public List<MuSegmentMap> createTestMuSegMaps(int size, Integer functionId,
			Integer containerId, int sameSegCount) {
		List<MuSegmentMap> maps = new ArrayList<>();
		Long sameSegmentId = 1111L;
		for (int i = 0; i < size; i++) {
			MuSegmentMap map = new MuSegmentMap();
			map.setContainerId(containerId);
			map.setFunctionId(functionId);
			if (i < sameSegCount) {
				map.setSegmentId(sameSegmentId);
			} else {
				map.setSegmentId(Long.valueOf(i * 100));
			}
			map.setMuId(i);
			map.setSegmentVersion(Long.valueOf(i + 2));
			map.setStatus(0);
			maps.add(map);
		}
		return maps;
	}

	public List<MuSegmentMap> createTestMuSegMaps1(int size,
			Integer functionId, Integer containerId, int sameMuIdCount) {
		List<MuSegmentMap> maps = new ArrayList<>();
		Integer sameMuId = 100;
		for (int i = 0; i < size; i++) {
			MuSegmentMap map = new MuSegmentMap();
			map.setContainerId(containerId);
			map.setFunctionId(functionId);
			if (i < sameMuIdCount) {
				map.setMuId(sameMuId);
			} else {
				map.setMuId(Integer.valueOf(i * 100));
			}
			map.setSegmentId(Long.valueOf(i * 1000 + i));
			map.setSegmentVersion(Long.valueOf(i + 2));
			map.setStatus(0);
			maps.add(map);
		}
		return maps;
	}

	private List<MuSegmentMap> createMuSegMap(int size, Integer containerId,
			Integer functionId) {
		List<MuSegmentMap> dbMap = new ArrayList<>();
		Integer[] muIds = new Integer[size];
		Long[] segmentIds = new Long[size];
		Long[] segmentVersions = new Long[size];
		Integer status = 0;
		for (int i = 0; i < size; i++) {
			muIds[i] = i;
			segmentIds[i] = 100L * i;
			segmentVersions[i] = new Long(i * 1L);
		}
		for (int i = 0; i < size; i++) {
			MuSegmentMap muSegMap = new MuSegmentMap();
			muSegMap.setContainerId(containerId);
			muSegMap.setFunctionId(functionId);
			muSegMap.setMuId(muIds[i]);
			muSegMap.setSegmentId(segmentIds[i]);
			muSegMap.setStatus(status);
			muSegMap.setSegmentVersion(segmentVersions[i]);
			dbMap.add(muSegMap);
		}
		return dbMap;
	}

}
