package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.identify.planner.MuSegmentMap;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class GetNewMuSegMapsProceduresTest extends
		AbstractTransactionalJUnit4SpringContextTests {
	@PersistenceContext(unitName = "AIMDB")
	protected EntityManager entityManager;
	@Resource
	protected DataSource dataSource;
	@Resource
	protected JdbcTemplate jdbcTemplate;
	private GetNewMuSegMapsProcedures identifyPlannerDao;

	@Before
	public void setUp() throws Exception {
		identifyPlannerDao = new GetNewMuSegMapsProcedures(dataSource);
		jdbcTemplate.execute("delete from match_units");
		jdbcTemplate.execute("delete from segments");
		jdbcTemplate.execute("delete from mu_eligible_containers");
		jdbcTemplate.execute("delete from mu_eligible_functions");
		jdbcTemplate.execute("delete from mu_seg_reports");
		jdbcTemplate.execute("delete segment_defragmentation");
		jdbcTemplate.execute("commit");
	}

	@After
	public void tearDown() throws Exception {
		identifyPlannerDao = null;
		jdbcTemplate.execute("delete from match_units");
		jdbcTemplate.execute("delete from segments");
		jdbcTemplate.execute("delete from mu_eligible_containers");
		jdbcTemplate.execute("delete from mu_eligible_functions");
		jdbcTemplate.execute("delete from mu_seg_reports");
		jdbcTemplate.execute("delete segment_defragmentation");
		jdbcTemplate.execute("commit");
	}

	@Test
	public void testGetNewMuSegMaps() {
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,'WORKING',4)";

		String segSql = "insert into segments (SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,"
				+ "BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)"
				+ " values(?, ?, 1, 10, 10, 10, ?, 1, 100)";

		String mecSql = " insert into MU_ELIGIBLE_CONTAINERS(CONTAINER_ID,MU_ID) values(?,?)";
		String mefSql = "insert into MU_ELIGIBLE_FUNCTIONS( FUNCTION_ID,MU_ID) values(?,?)";
		String muSegReportSql = "insert into mu_seg_reports(mu_id,segment_id,status,segment_version) values(?,?,1,?)";
		String defragBeanSql = "insert into segment_defragmentation(container_id,start_ts,end_ts) values(5,2000,3000)";

		Integer containerId = 1;
		Integer functionId = 1;
		Integer[] muIds = { 1, 2, 3, 4 };
		Long[] segIds = { 1000L, 1001L, 1002L, 1003L, 1004L, 1005L, 1006L,
				1007L };
		Long[] segVer = { 1L, 1L, 2L, 2L, 3L, 4L, 5L, 6L };

		for (int i = 0; i < muIds.length; i++) {
			jdbcTemplate.update(
					muSql,
					new Object[] { muIds[i],
							String.valueOf(muIds[i].longValue()) });
			jdbcTemplate.update(mecSql, new Object[] { containerId, muIds[i] });
			jdbcTemplate.update(mefSql, new Object[] { functionId, muIds[i] });
		}

		for (int i = 0; i < segIds.length; i++) {
			jdbcTemplate.update(segSql, new Object[] { segIds[i], containerId,
					segVer[i] });
		}
		int currentMu = 0;
		for (int i = 0; i < segIds.length; i++) {
			if (currentMu >= muIds.length) {
				currentMu = 0;
			}
			jdbcTemplate.update(muSegReportSql, new Object[] {
					muIds[currentMu], segIds[i], segVer[i] });
			currentMu++;
		}
		jdbcTemplate.update(defragBeanSql);
		jdbcTemplate.update("commit");

		try {
			List<MuSegmentMap> results = identifyPlannerDao.getNewMuSegMaps(
					containerId, functionId);
			Assert.assertNotNull(results);
			Assert.assertEquals(8, results.size());

			for (int i = 0; i < results.size(); i++) {

				Assert.assertNotNull(results.get(i).getMuId());
				Assert.assertNotNull(results.get(i).getSegmentId());
				Assert.assertNotNull(results.get(i).getSegmentVersion());
				Assert.assertNotNull(results.get(i).getContainerId());
				Assert.assertNotNull(results.get(i).getFunctionId());
			}
		} catch (DataAccessException | SQLException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testGetNewMuSegMaps_null_data() {
		Integer containerId = 1;
		Integer functionId = 1;
		try {
			List<MuSegmentMap> results = identifyPlannerDao.getNewMuSegMaps(
					containerId, functionId);
			Assert.assertNull(results);
		} catch (DataAccessException | SQLException e) {
			e.printStackTrace();
		}
	}

}
