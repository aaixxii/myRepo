package jp.co.nec.aim.mm.procedure;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import jp.co.nec.aim.mm.common.JdbcTemplateHelper;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class GetAllContainerJobsProcedureTest {

	@Resource
	private DataSource ds;

	@PersistenceContext(unitName = "AIMDB")
	private EntityManager entityManager;

	@Resource
	private JdbcTemplate jdbcTemplate;
	JdbcTemplateHelper helper = new JdbcTemplateHelper();
	private GetAllContainerJobsProcedure getallcontainerjobs;

	@Before
	public void setUp() throws Exception {
		getallcontainerjobs = new GetAllContainerJobsProcedure(ds);

		helper.deleteInquiryJob(jdbcTemplate);
		helper.scene01(jdbcTemplate);
	}

	@After
	public void tearDown() throws Exception {
		helper.deleteInquiryJob(jdbcTemplate);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void test_jobId1005() {
		Map<String, Object> result = getallcontainerjobs.action(1005);
		List<ContainerJobResult> containerJobResultlist = (List<ContainerJobResult>) result
				.get("p_success_refcursor");
		assertEquals(80, containerJobResultlist.size());
	}

	@SuppressWarnings("unchecked")
	@Test
	public void test_jobId1006() {
		Map<String, Object> result = getallcontainerjobs.action(1006);
		List<ContainerJobResult> containerJobResultlist = (List<ContainerJobResult>) result
				.get("p_success_refcursor");
		assertEquals(0, containerJobResultlist.size());
	}

	@SuppressWarnings("unchecked")
	@Test
	public void test_jobId1002() {
		Map<String, Object> result = getallcontainerjobs.action(1002);
		List<ContainerJobResult> containerJobResultlist = (List<ContainerJobResult>) result
				.get("p_success_refcursor");
		assertEquals(0, containerJobResultlist.size());
	}

}
