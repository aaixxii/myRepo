package jp.co.nec.aim.mm.procedure;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.BadSqlGrammarException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.annotation.Repeat;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class UpdateInquiryLoadProcedureTest extends
		AbstractTransactionalJUnit4SpringContextTests {
	@PersistenceContext(unitName = "AIMDB")
	protected EntityManager entityManager;
	@Resource
	protected DataSource dataSource;
	@Resource
	protected JdbcTemplate jdbcTemplate;
	private UpdateInquiryLoadProcedure updateProcedure;

	@Before
	public void setUp() throws Exception {
		updateProcedure = new UpdateInquiryLoadProcedure(dataSource);
	}

	@After
	public void tearDown() throws Exception {
		updateProcedure = null;

	}

	@Test()
	@Repeat(value = 5)
	public void testExecute_insert() {
		// Integer lastMuId =
		// jdbcTemplate.queryForObject("select max(mu_id) from MU_INQUIRY_LOAD",
		// Integer.class) ;
		int muId = 8989;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String deleteMuLoadTabSql = "delete from MU_INQUIRY_LOAD where mu_id=?";
		String deleteMuTabSql = "delete from MATCH_UNITS where mu_id=?";
		// String inquiryLoadSql =
		// "INSERT INTO MU_INQUIRY_LOAD (MU_ID, PRESSURE, UPDATE_TS)  VALUES(?,?,?)";

		jdbcTemplate.update(muSql,
				new Object[] { new Integer(muId), String.valueOf(muId),
						"WORKING", new Integer(8) });
		jdbcTemplate.update(deleteMuLoadTabSql,
				new Object[] { new Integer(muId) });
		updateProcedure.setMuId(Integer.valueOf(muId));
		updateProcedure.setInquiryLoad(5L);
		updateProcedure.execute();
		String selSql = "select * from MU_INQUIRY_LOAD where mu_id=?";
		List<Map<String, Object>> results = jdbcTemplate.queryForList(selSql,
				new Object[] { new Integer(muId) });
		Map<String, Object> resultMap = results.get(0);
		Assert.assertEquals(muId,
				((BigDecimal) resultMap.get("mu_id")).intValue());
		Assert.assertEquals(5,
				((BigDecimal) resultMap.get("pressure")).intValue());

		jdbcTemplate.update(deleteMuLoadTabSql,
				new Object[] { new Integer(muId) });
		jdbcTemplate.update(deleteMuTabSql, new Object[] { new Integer(muId) });
		jdbcTemplate.execute("commit");
	}

	@Test()
	@Repeat(value = 5)
	public void testExecute_Update() {
		// Integer lastMuId =
		// jdbcTemplate.queryForObject("select max(mu_id) from MU_INQUIRY_LOAD",
		// Integer.class) ;
		int muId = 7979;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String deleteMuLoadTabSql = "delete from MU_INQUIRY_LOAD where mu_id=?";
		String deleteMuTabSql = "delete from MATCH_UNITS where mu_id=?";
		String insertMuLoadSql = "INSERT INTO MU_INQUIRY_LOAD (MU_ID, PRESSURE, REPORT_TS)  VALUES(?,?,?)";

		jdbcTemplate.update(muSql,
				new Object[] { new Integer(muId), String.valueOf(muId),
						"WORKING", new Integer(8) });
		jdbcTemplate.update(deleteMuLoadTabSql,
				new Object[] { new Integer(muId) });
		jdbcTemplate.update(insertMuLoadSql, new Object[] { new Integer(muId),
				new Long(1L), new Long(100L) });

		updateProcedure.setMuId(Integer.valueOf(muId));
		updateProcedure.setInquiryLoad(8L);
		updateProcedure.execute();
		String selSql = "select * from MU_INQUIRY_LOAD where mu_id=?";
		List<Map<String, Object>> results = jdbcTemplate.queryForList(selSql,
				new Object[] { new Integer(muId) });
		Map<String, Object> resultMap = results.get(0);
		Assert.assertEquals(muId,
				((BigDecimal) resultMap.get("mu_id")).intValue());
		Assert.assertEquals(8,
				((BigDecimal) resultMap.get("pressure")).intValue());

		jdbcTemplate.update(deleteMuLoadTabSql,
				new Object[] { new Integer(muId) });
		jdbcTemplate.update(deleteMuTabSql, new Object[] { new Integer(muId) });
		jdbcTemplate.execute("commit");
	}

	@Test(expected = BadSqlGrammarException.class)
	public void testExecute_sql_exception() {
		// Integer lastMuId =
		// jdbcTemplate.queryForObject("select max(mu_id) from MU_INQUIRY_LOAD",
		// Integer.class) ;
		int muId = 7979;
		String muSql = "INSERT INTO MATCH_UNITS (MU_IDs, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		String deleteMuLoadTabSql = "delete from MU_INQUIRY_LOAD where mu_id=?";
		String deleteMuTabSql = "delete from MATCH_UNITS where mu_id=?";
		String insertMuLoadSql = "INSERT INTO MU_INQUIRY_LOAD (MU_ID, PRESSURE, REPORT_TS)  VALUES(?,?,?)";

		jdbcTemplate.update(muSql,
				new Object[] { new Integer(muId), String.valueOf(muId),
						"WORKING", new Integer(8) });
		jdbcTemplate.update(deleteMuLoadTabSql,
				new Object[] { new Integer(muId) });
		jdbcTemplate.update(insertMuLoadSql, new Object[] { new Integer(muId),
				new Long(1L), new Long(100L) });

		updateProcedure.setMuId(Integer.valueOf(muId));
		updateProcedure.setInquiryLoad(8L);
		updateProcedure.execute();
		String selSql = "select * from MU_INQUIRY_LOAD where mu_id=?";
		List<Map<String, Object>> results = jdbcTemplate.queryForList(selSql,
				new Object[] { new Integer(muId) });
		Map<String, Object> resultMap = results.get(0);
		Assert.assertEquals(muId,
				((BigDecimal) resultMap.get("mu_id")).intValue());
		Assert.assertEquals(8,
				((BigDecimal) resultMap.get("pressure")).intValue());

		jdbcTemplate.update(deleteMuLoadTabSql,
				new Object[] { new Integer(muId) });
		jdbcTemplate.update(deleteMuTabSql, new Object[] { new Integer(muId) });
		jdbcTemplate.execute("commit");
	}

}
