package jp.co.nec.aim.mm.segment.sync;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentAssignedStateType;

/**
 * 
 * SegDiffPara will transmit to procedure as the parameter Object
 * 
 * @author liuyq
 * 
 */
public class SegDiffPara {
	private long segmentId; // segment id
	private Integer reportVersion; // start segment version
	private Integer latestVersion; // end segment version
	private SegmentAssignedStateType state; // segment state
	private Integer rank; // segment assign rank

	/**
	 * the default constructor
	 * 
	 * @param segmentId
	 *            segment id
	 * @param reportVersion
	 *            report segment version
	 * @param latestVersion
	 *            latest segment version
	 * @param state
	 *            SegmentAssignedStateType
	 */
	public SegDiffPara(long segmentId, Integer reportVersion,
			Integer latestVersion, SegmentAssignedStateType state, Integer rank) {
		this.segmentId = segmentId;
		this.reportVersion = (reportVersion == null) ? 0 : reportVersion;
		this.latestVersion = latestVersion;
		this.state = state;
		this.rank = rank;
	}

	public long getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(long segmentId) {
		this.segmentId = segmentId;
	}

	public Integer getReportVersion() {
		return reportVersion;
	}

	public void setReportVersion(Integer reportVersion) {
		this.reportVersion = reportVersion;
	}

	public Integer getLatestVersion() {
		return latestVersion;
	}

	public void setLatestVersion(Integer latestVersion) {
		this.latestVersion = latestVersion;
	}

	public SegmentAssignedStateType getState() {
		return state;
	}

	public void setState(SegmentAssignedStateType state) {
		this.state = state;
	}

	public Integer getRank() {
		return rank;
	}

	public void setRank(Integer rank) {
		this.rank = rank;
	}
}
