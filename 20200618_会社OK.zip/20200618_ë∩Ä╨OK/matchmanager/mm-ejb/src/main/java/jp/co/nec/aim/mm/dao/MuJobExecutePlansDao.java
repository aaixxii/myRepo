package jp.co.nec.aim.mm.dao;

import jp.co.nec.aim.mm.entities.ExecutePlanEntity;

public class MuJobExecutePlansDao {

	// private DataSource dataSource;

	public ExecutePlanEntity getExecutePlanMap(long planID) {
		ExecutePlanEntity planMap = null;

		return planMap;
	}
}
