package jp.co.nec.aim.mm.loadbalancer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Singleton;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.message.proto.AIMEnumTypes.ComponentType;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.dao.LoadBalancerDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.dao.UnitDao;
import jp.co.nec.aim.mm.entities.ContainerEntity;
import jp.co.nec.aim.mm.entities.UnitSegMap;
import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.logger.PerformanceLogger;
import jp.co.nec.aim.mm.util.CollectionsUtil;
import jp.co.nec.aim.mm.util.StopWatch;
import jp.co.nec.aim.mm.wakeup.ReportWakeUp;
import jp.co.nec.slb.exception.DeployExcrption;
import jp.co.nec.slb.loadbalance.Deployment;
import jp.co.nec.slb.loadbalance.UnitNote;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Maps;

/**
 * @author mozj
 */
@Singleton
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class LoadBalancerBean {
	private static Logger slbLog = LoggerFactory.getLogger("slb");
	@PersistenceContext(unitName = "AIMDB")
	private EntityManager entityManager;
	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;

	private SystemConfigDao sysConfigDao;
	private LoadBalancerDao slbDao;
	private UnitDao unitDao;
	private LoadBalancerUtil slbUtil;
	private ReportWakeUp wakeUp;
	private static Map<Long, LastUnitSegLoad> lastMUSegMap;
	private static Map<Long, LastUnitSegLoad> lastDMSegMap;

	public LoadBalancerBean() {
		// for container
	}

	@PostConstruct
	public void init() {
		sysConfigDao = new SystemConfigDao(entityManager);
		slbDao = new LoadBalancerDao(entityManager, dataSource);
		unitDao = new UnitDao(entityManager);
		slbUtil = new LoadBalancerUtil();
		wakeUp = new ReportWakeUp(entityManager);
		lastMUSegMap = Maps.newHashMap();
		lastDMSegMap = Maps.newHashMap();
	}

	public void clearCache() {
		lastMUSegMap.clear();
		lastDMSegMap.clear();
	}

	/**
	 * Execute Segment Load Balance.
	 */
	public void executeSLB() {
		slbLog.debug("############## LOAD BALANCING ALGORITHM BEGINNING ##############");

		StopWatch sw = new StopWatch();
		sw.start();
		try {
			boolean enabled = sysConfigDao
					.getMMPropertyBool(MMConfigProperty.LOAD_BALANCING_ENABLED);
			if (!enabled) {
				slbLog.info("Could not execute the Segment Load Balance due to Load balancing was disabled.");
				return;
			}

			slbLog.debug("Ready to lock the table MM_EVENTS row [SEGMENT_LOAD_BALANCING]");
			slbDao.lockForSLB();
			slbLog.debug("locked MM_EVENTS row [SEGMENT_LOAD_BALANCING] was release.");

			entityManager.flush();

			int dmRedundancy = sysConfigDao
					.getMMPropertyInt(MMConfigProperty.DEFAULT_DM_MIN_REDUNDANCY);

			List<ContainerEntity> containers = slbDao.listContainers();
			Set<Long> unitList = new TreeSet<Long>();
			for (ContainerEntity container : containers) {
				long containerId = container.getContainerId();
				List<Long> segmentList = slbDao.getSegmentIds(Long
						.valueOf(container.getContainerId()));
				if (CollectionsUtil.isEmpty(segmentList)) {
					continue;
				}

				if (dmRedundancy > 0) {
					List<Long> dmIds = dmLoadBalance(containerId, dmRedundancy,
							segmentList);
					if (dmIds != null) {
						unitList.addAll(dmIds);
					}
				} else {
					slbLog.warn("DM redundancy of CONTAINER_ID=" + containerId
							+ " is " + dmRedundancy + ", it's less than 1!");
				}

				int redundancy = fetchRedundancy(container);
				if (redundancy > 0) {
					List<Long> muIds = muLoadBalance(container, redundancy,
							segmentList);
					if (muIds != null) {
						unitList.addAll(muIds);
					}
				} else {
					slbLog.warn("MU redundancy of CONTAINER_ID=" + containerId
							+ " is " + redundancy + ", it's less than 1!");
				}
			}

			slbDao.commit();

			if (unitList.size() != 0) {
				wakeUp.notifyMessage(unitList);
			}

			slbLog.debug("Load balancing complete. ");
		} catch (Exception e) {
			String message = "unknow Exception when doing Segment Load Balance.";
			slbLog.error(message, e);
			throw new AimRuntimeException(message, e);
		} finally {
			sw.stop();
			PerformanceLogger.log(getClass().getSimpleName(), "executeSLB",
					sw.elapsedTime());
		}
	}

	/**
	 * Fetch redundancy
	 * 
	 * @param container
	 *            ContainerEntity
	 * @return redundancy
	 */
	private int fetchRedundancy(ContainerEntity container) {
		int defaultMinRedundancy = sysConfigDao
				.getMMPropertyInt(MMConfigProperty.DEFAULT_MIN_REDUNDANCY);
		int redundancy = container.getMinRedundancy() == null ? defaultMinRedundancy
				: container.getMinRedundancy();
		return redundancy;
	}

	/**
	 * Judge if Working Mus is over minMusForSLB
	 * 
	 * @param segmentSet
	 * @return
	 */
	private boolean isOverMinMusForSLB(List<UnitNote> unitIds,
			ContainerEntity container) {
		int minMus = sysConfigDao
				.getMMPropertyInt(MMConfigProperty.MIN_MUS_FOR_SLB);

		Integer minMuContainer = container.getMinMuNumForSlb();

		boolean isOver = ((minMuContainer == null) ? minMus : minMuContainer) <= unitIds
				.size();
		return isOver;
	}

	/**
	 * Calculate Segment deployments and update DM_SEGMENTS record of DM.
	 * 
	 * @param containerId
	 * @param dmRedundancy
	 * @return
	 */
	private List<Long> dmLoadBalance(long containerId, int dmRedundancy,
			List<Long> segmentList) {
		// List of DM which is working.
		List<UnitNote> dms = unitDao.listEligibleDMs(containerId);
		if (CollectionsUtil.isEmpty(dms)) {
			slbLog.warn("There is no working or eligible DMs. SLB was not executed.");
			return null;
		}
		int redundancy;
		if (dms.size() <= dmRedundancy) {
			if (dms.size() < dmRedundancy) {
				slbLog.warn("DM Count are less than Redundancy.");
			}
			redundancy = dms.size();
		} else {
			slbLog.warn("Numbers of DM:" + dms.size()
					+ " is bigger than redundancy:" + dmRedundancy);
			redundancy = dmRedundancy;
		}

		List<Long> dmIds = loadBalance(ComponentType.DATA_MANAGER, segmentList,
				dms, redundancy, containerId);

		return dmIds;
	}

	/**
	 * 
	 * @param containerId
	 * @param muRedundancy
	 * @return
	 */
	private List<Long> muLoadBalance(ContainerEntity container,
			int muRedundancy, List<Long> segmentList) {
		long containerId = container.getContainerId();
		List<UnitNote> muList = unitDao.listEligibleMUs(containerId);
		boolean isOver = isOverMinMusForSLB(muList, container);
		if (isOver == false) {
			slbLog.warn("Number of Mus for CONTAINER_ID = " + containerId
					+ " is under than MIN_MUS_FOR_SLB.");
			slbLog.warn("SLB for CONTAINER_ID =" + containerId
					+ " was not executed.");
			// slbLog.info(
			// "Delete the record of MU segment with container id: {}.",
			// containerId);
			// slbDao.deleteMuSegWithCId(containerId);
			return null;
		}

		int redundancy;
		if (muList.size() <= muRedundancy) {
			if (muList.size() < muRedundancy) {
				slbLog.warn("MU Count are less than Redundancy.");
			}
			redundancy = muList.size();
		} else {
			redundancy = muRedundancy;
		}

		List<Long> muIds = loadBalance(ComponentType.MATCH_UNIT, segmentList,
				muList, redundancy, containerId);

		return muIds;
	}

	/**
	 * 
	 * @param type
	 * @param segIds
	 * @param unitList
	 * @param redundancy
	 * @return
	 */
	private List<Long> loadBalance(ComponentType type, List<Long> segIds,
			List<UnitNote> unitList, int redundancy, long containerId) {
		List<Long> unitIdsChanged = new ArrayList<Long>();
		try {
			List<Long> unitIds = new ArrayList<Long>();
			for (UnitNote unit : unitList) {
				unitIds.add(unit.getUnitID());
			}

			boolean needDoSLB = needDoSLB(type, unitIds, segIds, redundancy,
					containerId);
			if (!needDoSLB) {
				return unitIdsChanged;
			}

			StopWatch sw = new StopWatch();
			sw.start();

			List<UnitSegMap> preUnitSegMaps = slbDao.getUnitSegmetMaps(unitIds,
					type);
			boolean[][] preMatrix = slbUtil.createMatrix(preUnitSegMaps,
					segIds, unitIds);
			sw.stop();
			slbLog.debug("create preMatrix used {} ms", sw.elapsedTime());

			sw.start();

			Deployment deploy = new Deployment(unitList, segIds, redundancy);
			boolean[][] matrix = deploy.deploy(preMatrix);

			sw.stop();
			slbLog.debug("Deployment.deploy used {} ms", sw.elapsedTime());

			sw.start();
			slbDao.persistUnitSegMaps(matrix, preMatrix, segIds, unitIds, type,
					containerId);
			sw.stop();
			slbLog.debug("LoadBalancerDao.persistUnitSegMaps used {} ms",
					sw.elapsedTime());

			for (int unitIndex = 0; unitIndex < unitList.size(); unitIndex++) {
				for (int segIndex = 0; segIndex < segIds.size(); segIndex++) {
					if (matrix[unitIndex][segIndex] != preMatrix[unitIndex][segIndex]) {
						long unitId = unitList.get(unitIndex).getUnitID();
						unitIdsChanged.add(unitId);
						break;
					}
				}
			}

			if (unitIdsChanged.isEmpty()) {
				return unitIdsChanged;
			}

			sw.start();

			if (type.equals(ComponentType.MATCH_UNIT)) {
				List<UnitSegMap> unitSegMaps = slbUtil.createUnitSegMaps(
						matrix, segIds, unitIds);
				slbUtil.exportSLBLog(preUnitSegMaps, unitSegMaps);
			}
			sw.stop();
			slbLog.debug("LoadBalancerUtil.exportSLBLog used {} ms",
					sw.elapsedTime());

			return unitIdsChanged;
		} catch (DeployExcrption e) {
			slbLog.error("DeployExcrption when deploy", e);
			return unitIdsChanged;
		}
	}

	private boolean needDoSLB(ComponentType type, List<Long> unitIds,
			List<Long> segIds, int redundancy, Long containerId) {
		boolean needDoSLB = false;
		LastUnitSegLoad lastLoad = null;
		if (type.equals(ComponentType.MATCH_UNIT)) {
			lastLoad = lastMUSegMap.get(containerId);
		} else {
			lastLoad = lastDMSegMap.get(containerId);
		}

		if (lastLoad == null) {
			needDoSLB = true;

			lastLoad = new LastUnitSegLoad();
			if (type.equals(ComponentType.MATCH_UNIT)) {
				lastMUSegMap.put(containerId, lastLoad);
			} else {
				lastDMSegMap.put(containerId, lastLoad);
			}
		} else {
			List<Long> lastUnitsIds = lastLoad.getUnitIds();
			List<Long> lastSegIds = lastLoad.getSegmentIds();
			if (redundancy != lastLoad.getRedundancy()) {
				needDoSLB = true;
			} else if (unitIds.size() != lastUnitsIds.size()
					|| !unitIds.containsAll(lastUnitsIds)) {
				needDoSLB = true;
			} else if (segIds.size() != lastSegIds.size()
					|| !segIds.containsAll(lastSegIds)) {
				needDoSLB = true;
			}
		}

		if (needDoSLB) {
			lastLoad.setRedundancy(redundancy);
			lastLoad.setUnitIds(unitIds);
			lastLoad.setSegmentIds(segIds);
		}

		return needDoSLB;
	}
}
