package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

/**
 * The persistent class for the SYSTEM_CONFIG database table.
 * 
 */
@Entity
@Table(name = "SYSTEM_CONFIG")
@Immutable
public class SystemConfigEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "CONFIG_ID")
	private long configId;

	@Column(name = "PROPERTY_NAME")
	private String name;

	@Column(name = "PROPERTY_VALUE")
	private String value;

	public SystemConfigEntity() {
	}

	public long getConfigId() {
		return this.configId;
	}

	public void setConfigId(long configId) {
		this.configId = configId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}