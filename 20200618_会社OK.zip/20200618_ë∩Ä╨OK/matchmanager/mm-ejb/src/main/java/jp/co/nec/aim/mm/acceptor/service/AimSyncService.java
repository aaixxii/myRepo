package jp.co.nec.aim.mm.acceptor.service;

import static jp.co.nec.aim.mm.constants.MMConfigProperty.INTERVAL_CLIENT_SYNC_RESPONSE_TIMEOUT;

import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.xml.bind.JAXBException;

import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Maps;
import com.google.protobuf.ByteString;

import jp.co.nec.aim.dm.message.proto.AimDmMessages.PBDmSyncRequest;
import jp.co.nec.aim.dm.message.proto.AimDmMessages.PBTargetSegmentVersion;
import jp.co.nec.aim.dm.message.proto.AimDmMessages.PBTemplateInfo;
import jp.co.nec.aim.dm.message.proto.AimDmMessages.SegmentSyncCommandType;
import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResultItem;
import jp.co.nec.aim.mm.acceptor.AimSyncRequest;
import jp.co.nec.aim.mm.acceptor.Record;
import jp.co.nec.aim.mm.acceptor.Registration;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.UidRequestType;
import jp.co.nec.aim.mm.dao.CommitDao;
import jp.co.nec.aim.mm.dao.FEJobDao;
import jp.co.nec.aim.mm.dao.FunctionDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.dm.client.DmJobPoster;
import jp.co.nec.aim.mm.dm.client.mgmt.UidDmJobRunManager;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.entities.FunctionTypeEntity;
import jp.co.nec.aim.mm.exception.UidTimeoutException;
import jp.co.nec.aim.mm.exception.XmlException;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.jms.NotifierEnum;
import jp.co.nec.aim.mm.procedure.FeJobProcedures;
import jp.co.nec.aim.mm.segment.sync.SegSyncInfos;
import jp.co.nec.aim.mm.sessionbeans.pojo.AimAmQExtractResponse;
import jp.co.nec.aim.mm.sessionbeans.pojo.AimManager;
import jp.co.nec.aim.mm.util.XmlUtil;

/**
 * The main work flow of Sync <br>
 * Include following public method:
 * <p>
 * syncData
 * <p>
 * 
 * @author xiazp
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AimSyncService {
	/** log instance **/
	private static Logger log = LoggerFactory.getLogger(AimSyncService.class);
	private static Logger probufDumpLog = LoggerFactory.getLogger("probufdump");

	@PersistenceContext(unitName = "AIMDB")
	private EntityManager manager;

	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;

	private Registration reg;

	private FEJobDao feJobDao;

	private SystemConfigDao sysConfigDao;

	private FunctionDao functionDao;

	private FeJobProcedures feJobProcedures;

	private CommitDao commitDao;

	@EJB
	private AimExtractService aimExService;

	/**
	 * default constructor
	 */
	public AimSyncService() {
	}

	@PostConstruct
	private void init() {
		this.reg = new Registration(dataSource, manager);
		this.feJobDao = new FEJobDao(manager);
		this.functionDao = new FunctionDao(manager);
		this.sysConfigDao = new SystemConfigDao(manager);
		feJobProcedures = new FeJobProcedures(dataSource);
		this.commitDao = new CommitDao(dataSource);
	}

	/**
	 * The main work flow of syncData
	 * 
	 * @param request
	 *            PBSyncJobRequest instance
	 * @return the instance of PBSyncJobResponse
	 * @throws IOException 
	 */
	public AimAmQExtractResponse syncData(String syncRequest) throws IOException {
		return syncData(syncRequest, null);

	}

	/**
	 * The main work flow of syncData
	 * 
	 * @param syncRequest
	 *            PBSyncJobRequest instance
	 * @param delCount
	 *            delete count
	 * @return PBSyncJobResponse instance
	 * @throws IOException 
	 * @throws JAXBException
	 * @throws Exception
	 */
	public AimAmQExtractResponse syncData(final String syncRequest, final AtomicInteger delCount) throws IOException {
		// xml response return:0:notused,1:Successed, 2:Failed
		if (StringUtils.isBlank(syncRequest)) {
			throw new XmlException("insert request is empty");
		}
		if (probufDumpLog.isDebugEnabled()) {
			probufDumpLog.debug(syncRequest);
		}
		String cmd = XmlUtil.getXmlCmd(syncRequest);
		if (StringUtils.isBlank(cmd)) {
			throw new XmlException("Element is empty in sync request.");
		}
		if (!(cmd.equals("Delete") || cmd.equals("Insert"))) {
			throw new XmlException("Sync command is miss, it's must be 'Insert' or 'Delete'!");
		}
		String refId = XmlUtil.getRefId(syncRequest, UidRequestType.Insert.name());
		String requestId = XmlUtil.getRequestId(syncRequest);

		if (cmd.equals("Delete")) {
			return doSyncDelete(syncRequest, refId, delCount);
		}
		AimAmQExtractResponse response = null;
		if (cmd.equals("Insert")) {
			boolean hasTemplate = feJobDao.hasTempalte(refId);
			if (hasTemplate) {
				return doSyncByRefId(syncRequest, refId, requestId);
			}
			String refUrl = XmlUtil.getUrl(syncRequest, UidRequestType.Insert.name());
			if (!StringUtils.isBlank(refUrl)) {
				return doSyncByRefUrl(syncRequest, refId, refUrl);

			} else {
				response = buildFaildXmlReespose(requestId);
			}
		}
		return response;
	}

	private AimAmQExtractResponse doSyncByRefId(final String syncRequest, String refId, String requestId) throws IOException {
		log.info("syncData insert by refernceId begin..");	
		AimAmQExtractResponse mqRespose  = null;
		FeJobQueueEntity feEntity = null;
		try {
			List<FeJobQueueEntity> resultList = feJobDao.getExResult(refId);
			feEntity = resultList.get(0);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			mqRespose = buildFaildXmlReespose(requestId);
			return mqRespose;
		}

		final List<AimSyncRequest> aimRequestList = new ArrayList<>();
		Record record = new Record(feEntity.getTempalteData(), true);
		AimSyncRequest aimReq = new AimSyncRequest(Integer.valueOf(1));
		aimReq.setRecord(record);
		aimRequestList.add(aimReq);
		try {
			// Map<Long, List<SegSyncInfos>> segSyncMap = reg.insert(refId,aimRequestList);			
			SegSyncInfos segSyncInfo = reg.insert(refId, aimReq);
			if (!segSyncInfo.isUpdateSegment()) {
				segSyncInfo.setCommand(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_NEW);
			} else {
				segSyncInfo.setCommand(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT);
			}			
			segSyncInfo.setExternalId(refId);
			segSyncInfo.setTemplateData(feEntity.getTempalteData());
			log.info("success insert into PERSON_BIOMETRICS table reqeustId={}, eenrollmentId={}", refId, refId);
			PBDmSyncRequest dmRequest = buildDmJobRequest(segSyncInfo);
			String url = UidDmJobRunManager.getOneActiveDm();			
			Boolean postResult = DmJobPoster.post(url, dmRequest);
			if (postResult.booleanValue()) {
				commitDao.commit();
				final Map<Long, List<SegSyncInfos>> segSyncMap = Maps.newHashMap();
				List<SegSyncInfos> segSyncList = new ArrayList<>();
				segSyncList.add(segSyncInfo);
				reg.pushOrCallSlb(segSyncMap, segSyncInfo.isUpdateSegment());				
				mqRespose = buildSuccessReespose(requestId, feEntity.getDiagnostcs());				
			} else {
				commitDao.rollback();
				mqRespose = buildFaildXmlReespose(requestId);
			}
		
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			mqRespose = buildFaildXmlReespose(requestId);
		}	
		return mqRespose;
	}

	private AimAmQExtractResponse doSyncByRefUrl(final String syncRequest, String refId, String refUrl) throws IOException {
		// sync by url
		log.info("syncData insert by url begin..");
		AimAmQExtractResponse mqRespose  = null;
		// final FeJobQueueEntity feJob = new FeJobQueueEntity();
		String requestId = XmlUtil.getRequestId(syncRequest);
		FunctionTypeEntity fte = functionDao.getExtractFunction();
		if (fte == null) {
			AimError dbErr = AimError.SYNC_FUNCTIONTYPE;			
			mqRespose = buildFaildXmlReespose(requestId);
			return mqRespose;
//			throw new DataBaseException(dbErr.getErrorCode(), dbErr.getMessage(),
//					String.valueOf(System.currentTimeMillis()), dbErr.getUidCode());
		}

		Long newFeJobId = null;
		try {
			newFeJobId = feJobProcedures.createNewFeJob(refId, requestId, UidRequestType.Insert.name(), syncRequest);
		} catch (Exception e1) {
			feJobDao.deleteExtractJob(newFeJobId);
			Throwable cause = e1.getCause();
			Throwable lastCause = null;
			String errMsg = null;
			while (cause != null) {
				cause = cause.getCause();
				if (cause != null) {
					lastCause = cause;
				}
			}
			if (lastCause != null) {
				errMsg = lastCause.getMessage();
			}
			AimError dbErr = AimError.SYNC_DB;
			errMsg = StringUtils.isNoneEmpty(errMsg) ? errMsg : String.format(dbErr.getMessage(), e1.getMessage());
			dbErr.setMessage(errMsg);
			mqRespose = buildFaildXmlReespose(requestId);
			return mqRespose;
//			throw new DataBaseException(dbErr.getErrorCode(), dbErr.getMessage(),
//					String.valueOf(System.currentTimeMillis()), dbErr.getUidCode());
		}

		JmsSender.getInstance().sendToFEJobPlanner(NotifierEnum.ExtractService,
				String.format("create extract job id: %s", newFeJobId));
		Integer syncJobWaitTime = sysConfigDao.getMMPropertyInt(INTERVAL_CLIENT_SYNC_RESPONSE_TIMEOUT);
		if (Objects.isNull(syncJobWaitTime) || syncJobWaitTime < 0) {
			syncJobWaitTime = 100000;
		}
		String key = String.valueOf(newFeJobId.longValue());
		Object extractJoblocker = new Object();
		AimManager.saveToExtractLockQueue(key, extractJoblocker);
		Optional<PBMuExtractJobResultItem> onejobResult = null;
		synchronized (extractJoblocker) {
			long startGetExtResultTime = System.currentTimeMillis();
			try {
				extractJoblocker.wait(syncJobWaitTime);
			} catch (InterruptedException e) {
				log.error(e.getMessage(), e);
				Thread.currentThread().interrupt();
			}
			try {
				onejobResult = Optional.ofNullable(AimManager.getExtractJobResult(key));
			} catch (NullPointerException e) {
				log.warn("can't get extractResponse, it may be timeout.");
				AimError timeoutErr = AimError.JOB_TIMEOUT;
				String errMsg = String.format(timeoutErr.getMessage(), "sync insert by url job timeout.");
				timeoutErr.setMessage(errMsg);
				throw new UidTimeoutException(timeoutErr.getErrorCode(), timeoutErr.getMessage(),
						String.valueOf(System.currentTimeMillis()), timeoutErr.getUidCode());
			}
			if (onejobResult.isPresent()) {
				log.info("Get insert by url jobId({}) result success", newFeJobId);
				long endGetResultTime = System.currentTimeMillis();
				log.info("*****MM get insert by url job results used time = {}****",
						endGetResultTime - startGetExtResultTime);
			} else {
				log.warn("Got empty PBMuExtractJobResultItem, key={}", key);
				long currentTime = System.currentTimeMillis();
				if (currentTime - startGetExtResultTime >= syncJobWaitTime) {
					log.warn("Timeout is happend! the waiting time = ({}), jobId({})",
							currentTime - startGetExtResultTime, newFeJobId.longValue());
					AimError timeoutErr = AimError.JOB_TIMEOUT;
					String errMsg = String.format(timeoutErr.getMessage(), "sync insert by url job timeout.");
					timeoutErr.setMessage(errMsg);
					throw new UidTimeoutException(timeoutErr.getErrorCode(), timeoutErr.getMessage(),
							String.valueOf(System.currentTimeMillis()), timeoutErr.getUidCode());
				}
			}
		}
		AimManager.finishExtractJob(key);

		//final List<AimSyncRequest> aimRequestByExtList = new ArrayList<>();
		Record recordByExt = new Record(onejobResult.get().getBisonTemplate().toByteArray(), true);

		AimSyncRequest aimReqExt = new AimSyncRequest(Integer.valueOf(1), recordByExt);	
		mqRespose  = new AimAmQExtractResponse();
		try {
			// Map<Long, List<SegSyncInfos>> segSyncMap = reg.insert(refId,aimRequestList);			
			SegSyncInfos segSyncInfo = reg.insert(refId, aimReqExt);
			if (!segSyncInfo.isUpdateSegment()) {
				segSyncInfo.setCommand(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_NEW);
			} else {
				segSyncInfo.setCommand(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT);
			}
			
			segSyncInfo.setExternalId(refId);
			segSyncInfo.setTemplateData(onejobResult.get().getBisonTemplate().toByteArray());			
			log.info("success insert into PERSON_BIOMETRICS table reqeustId={}, eenrollmentId={}", refId, refId);
			PBDmSyncRequest dmRequest = buildDmJobRequest(segSyncInfo);
			String url = UidDmJobRunManager.getOneActiveDm();			
			Boolean postResult = DmJobPoster.post(url, dmRequest);
			if (postResult.booleanValue()) {
				commitDao.commit();
				final Map<Long, List<SegSyncInfos>> segSyncMap = Maps.newHashMap();
				List<SegSyncInfos> segSyncList = new ArrayList<>();
				segSyncList.add(segSyncInfo);
				reg.pushOrCallSlb(segSyncMap, segSyncInfo.isUpdateSegment());	
				mqRespose.setRequestId(requestId);
				mqRespose.setXmlResult(onejobResult.get().getResult());
				mqRespose.setDiagnostics(onejobResult.get().getDiagnostics().toByteArray());
								
			} else {
				commitDao.rollback();
				mqRespose = buildFaildXmlReespose(requestId);
			}
		
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			mqRespose = buildFaildXmlReespose(requestId);
		}	
		byte[] diagnostics = onejobResult.get().getDiagnostics().toByteArray();
		String xmlRespose = onejobResult.get().getResult();
		AimAmQExtractResponse extRespose = new AimAmQExtractResponse(requestId, xmlRespose, diagnostics);
		return extRespose;
	}

	private AimAmQExtractResponse doSyncDelete(String deleteReq, String externalId, final AtomicInteger delCount) throws IOException {
		if (log.isDebugEnabled()) {
			log.debug("syncData delete begin..");
		}
		List<SegSyncInfos> delSyncList = new ArrayList<>();
		int count = reg.delete(externalId, Integer.valueOf(1), delSyncList);
		if (delCount != null) {
			delCount.set(count);
		}
		log.info("delete count={}", count);
		
		delSyncList.forEach(one -> {			
			PBDmSyncRequest dmRequest = buildDmJobRequest(one);
			String url = UidDmJobRunManager.getOneActiveDm();			
			Boolean postResult = DmJobPoster.post(url, dmRequest);
			if (postResult.booleanValue()) {
				commitDao.commit();
				final Map<Long, List<SegSyncInfos>> segSyncMap = Maps.newHashMap();
				List<SegSyncInfos> segSyncList = new ArrayList<>();
				segSyncList.add(one);
				reg.pushOrCallSlb(segSyncMap, one.isUpdateSegment());
			} else {
				commitDao.rollback();
			}			
		});
		
		String requestId = XmlUtil.getRequestId(deleteReq);
		String delXmlRes = dom4jCreateXml(requestId, 2);
		AimAmQExtractResponse extRespose = new AimAmQExtractResponse(requestId, delXmlRes, null);		
		return extRespose;
	}
	
	private String dom4jCreateXml(String requestId , int success) throws IOException {
		 Document document = DocumentHelper.createDocument();
		 Element root = document.addElement( "Response")
				 .addAttribute("requestId", requestId)
				 .addAttribute("timeStamp", String.valueOf(System.currentTimeMillis()));
		 root.addElement("Return").addAttribute("value", String.valueOf(success));
		 OutputFormat format = OutputFormat.createPrettyPrint();
		 StringWriter sw = new StringWriter();
         XMLWriter writer  = new XMLWriter(sw, format);        
         writer.write(document);
         String resuslt = sw.toString();		 
		return resuslt;		
	}
	
	private AimAmQExtractResponse buildSuccessReespose(String requestId, byte[] diagnostics) throws IOException  {
		AimAmQExtractResponse response = new AimAmQExtractResponse();
		String xmlRes = dom4jCreateXml(requestId, 1);		
		response.setRequestId(requestId);
		response.setXmlResult(xmlRes);
		response.setDiagnostics(diagnostics);
		return response;
	}
	

	private AimAmQExtractResponse buildFaildXmlReespose(String requestId) throws IOException  {
		AimAmQExtractResponse response = new AimAmQExtractResponse();
		String xmlRes = dom4jCreateXml(requestId, 2);	
		response.setRequestId(requestId);
		response.setXmlResult(xmlRes);
		return response;
	}

	private  PBDmSyncRequest buildDmJobRequest(SegSyncInfos segSyncInfo) {
		PBDmSyncRequest.Builder pbDmSycReq = PBDmSyncRequest.newBuilder();
		pbDmSycReq.setCmd(segSyncInfo.getCommand());
		pbDmSycReq.setBioIdStart(1L);
		if (segSyncInfo.getCommand().equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_NEW)) {
			long maxEnd = -9999; //todo
			pbDmSycReq.setBioIdEnd(maxEnd);
		} else {
			pbDmSycReq.setBioIdEnd(segSyncInfo.getTemplateId());
		}
		PBTargetSegmentVersion.Builder targetSegment = PBTargetSegmentVersion.newBuilder();
		targetSegment.setId(segSyncInfo.getSegmentId().longValue());
		targetSegment.setVersion(segSyncInfo.getSegVersion());
		pbDmSycReq.setTargetSegment(targetSegment.build());
		if (segSyncInfo.getCommand().equals(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT)) {
			PBTemplateInfo.Builder pbTemplateInfo = PBTemplateInfo.newBuilder();
			pbTemplateInfo.setReferenceId(segSyncInfo.getExternalId());
			pbTemplateInfo.setData(ByteString.copyFrom(segSyncInfo.getTemplateData()));
			pbDmSycReq.setTemplateData(pbTemplateInfo.build());
		}
		return pbDmSycReq.build();
	}
}
