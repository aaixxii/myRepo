package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the SEGMENT_CHANGE_LOG database table.
 * 
 */
@Entity
@Table(name = "SEGMENT_CHANGE_LOG")
@NamedQuery(name = "SegmentChangeLogEntity.findAll", query = "SELECT s FROM SegmentChangeLogEntity s")
public class SegmentChangeLogEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id	
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "SEGMENT_CHANGE_ID")
	private long segmentChangeId;
	
	@Column(name = "P_NO")
	private long pNo;


	@Column(name = "BIOMETRICS_ID")
	private long biometricsId;

	@Column(name = "CHANGE_TYPE")
	private long changeType;

	@Column(name = "SEGMENT_ID")
	private long segmentId;

	@Column(name = "SEGMENT_VERSION")
	private long segmentVersion;
	
	@Lob
	@Column(name = "TEMPLATE_DATA")
	private byte[] biometricData;

	@Column(name = "EXTERNAL_ID")
	private String externalId;

	public SegmentChangeLogEntity() {
	}

	public long getSegmentChangeId() {
		return this.segmentChangeId;
	}

	public void setSegmentChangeId(long segmentChangeId) {
		this.segmentChangeId = segmentChangeId;
	}

	public long getBiometricsId() {
		return this.biometricsId;
	}

	public void setBiometricsId(long biometricsId) {
		this.biometricsId = biometricsId;
	}

	public long getChangeType() {
		return this.changeType;
	}

	public void setChangeType(long changeType) {
		this.changeType = changeType;
	}

	public long getSegmentId() {
		return this.segmentId;
	}

	public void setSegmentId(long segmentId) {
		this.segmentId = segmentId;
	}

	public long getSegmentVersion() {
		return this.segmentVersion;
	}

	public void setSegmentVersion(long segmentVersion) {
		this.segmentVersion = segmentVersion;
	}

	public long getpNo() {
		return pNo;
	}

	public void setpNo(long pNo) {
		this.pNo = pNo;
	}

	public byte[] getBiometricData() {
		return biometricData;
	}

	public void setBiometricData(byte[] biometricData) {
		this.biometricData = biometricData;
	}

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}
	
	

}