package jp.co.nec.aim.mm.scheduler;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.PersistJobDataAfterExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.constants.JNDIConstants;
import jp.co.nec.aim.mm.sessionbeans.CreateNextDayPartitionBean;
import jp.co.nec.aim.mm.util.JndiLookup;


@DisallowConcurrentExecution
@PersistJobDataAfterExecution
public class CreateNextDayPartitiontScheduler implements Job{

	private static final Logger logger = LoggerFactory.getLogger(CreateNextDayPartitiontScheduler.class);
	
	CreateNextDayPartitionBean createNextDayPartitiontBean;
	
	public CreateNextDayPartitiontScheduler() {
		createNextDayPartitiontBean = JndiLookup.lookUp(
				JNDIConstants.CREATENEXTDAYPARTITIONBEAN,CreateNextDayPartitionBean.class);
	}
	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {
	    if (logger.isDebugEnabled()) {
            logger.debug("CreateNextDayPartitiontScheduler is run...");
        }
		createNextDayPartitiontBean.execute();
	}

}
