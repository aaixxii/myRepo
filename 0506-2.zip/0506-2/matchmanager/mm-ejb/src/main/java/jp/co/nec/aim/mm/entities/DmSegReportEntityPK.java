package jp.co.nec.aim.mm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * The primary key class for the DM_SEG_REPORTS database table.
 * 
 */
@Embeddable
public class DmSegReportEntityPK implements Serializable {
	// default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name = "DM_ID", insertable = false, updatable = false)
	private long dmId;

	@Column(name = "SEGMENT_ID")
	private long segmentId;

	public DmSegReportEntityPK() {
	}

	public long getDmId() {
		return this.dmId;
	}

	public void setDmId(long dmId) {
		this.dmId = dmId;
	}

	public long getSegmentId() {
		return this.segmentId;
	}

	public void setSegmentId(long segmentId) {
		this.segmentId = segmentId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof DmSegReportEntityPK)) {
			return false;
		}
		DmSegReportEntityPK castOther = (DmSegReportEntityPK) other;
		return (this.dmId == castOther.dmId)
				&& (this.segmentId == castOther.segmentId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.dmId ^ (this.dmId >>> 32)));
		hash = hash * prime
				+ ((int) (this.segmentId ^ (this.segmentId >>> 32)));

		return hash;
	}
}