package jp.co.nec.aim.mm.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import jp.co.nec.aim.baton.util.DateUtils;
import jp.co.nec.aim.baton.util.StringBuilderNullSuppressCsv;
import jp.co.nec.aim.mm.constants.CallbackStyle;
import jp.co.nec.aim.mm.constants.JobState;

/**
 * The persistent class for the FE_JOB_QUEUE database table.
 * 
 */
@Entity
@Table(name = "FE_JOB_QUEUE")
public class FeJobQueueEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "JOB_ID")
	private long id;
	
	@Column(name = "REFERENCE_ID")
	private String referenceId;

	public String getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

	@Column(name = "ASSIGNED_TS")
	private Long assignedTs;

	@Column(name = "CALLBACK_STYLE")
	@Enumerated(value = EnumType.ORDINAL)
	private CallbackStyle callbackStyle;

	@Column(name = "CALLBACK_URL")
	private String callbackUrl;

	@Column(name = "FAILED_FLAG")
	private Boolean failedFlag;

	@Column(name = "FAILURE_COUNT")
	private Long failureCount;

	@Column(name = "FUNCTION_ID")
	private int functionId;

	@Column(name = "JOB_STATE")
	@Enumerated(value = EnumType.ORDINAL)
	private JobState status;

	@Column(name = "LOT_JOB_ID")
	private Long lotJobId;

	@Column(name = "MU_ID")
	private Integer muId;

	private int priority;

	@Column(name = "\"RESULT\"")
	private byte[] result;

	@Column(name = "RESULT_TS")
	private Long resultTs;

	@Column(name = "SUBMISSION_TS")
	private Long submissionTs;

	public FeJobQueueEntity() {
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Long getAssignedTs() {
		return assignedTs;
	}

	public void setAssignedTs(Long assignedTs) {
		this.assignedTs = assignedTs;
	}

	public CallbackStyle getCallbackStyle() {
		return callbackStyle;
	}

	public void setCallbackStyle(CallbackStyle callbackStyle) {
		this.callbackStyle = callbackStyle;
	}

	public String getCallbackUrl() {
		return callbackUrl;
	}

	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}

	public Boolean getFailedFlag() {
		return failedFlag;
	}

	public void setFailedFlag(Boolean failedFlag) {
		this.failedFlag = failedFlag;
	}

	public Long getFailureCount() {
		return failureCount;
	}

	public void setFailureCount(Long failureCount) {
		this.failureCount = failureCount;
	}

	public int getFunctionId() {
		return functionId;
	}

	public void setFunctionId(int functionId) {
		this.functionId = functionId;
	}

	public JobState getStatus() {
		return status;
	}

	public void setStatus(JobState status) {
		this.status = status;
	}

	public Long getLotJobId() {
		return lotJobId;
	}

	public void setLotJobId(Long lotJobId) {
		this.lotJobId = lotJobId;
	}

	public Integer getMuId() {
		return muId;
	}

	public void setMuId(Integer muId) {
		this.muId = muId;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public byte[] getResult() {
		return result;
	}

	public void setResult(byte[] result) {
		this.result = result;
	}

	public Long getResultTs() {
		return resultTs;
	}

	public void setResultTs(Long resultTs) {
		this.resultTs = resultTs;
	}

	public Long getSubmissionTs() {
		return submissionTs;
	}

	public void setSubmissionTs(Long submissionTs) {
		this.submissionTs = submissionTs;
	}

	@Override
	public String toString() {
		StringBuilderNullSuppressCsv sb = new StringBuilderNullSuppressCsv(256);
		sb.append(id); // JOB_ID
		sb.append(functionId); // FUNCTION_ID
		sb.append(priority); // PRIORITY
		sb.append(status == null ? "" : status.ordinal()); // JOB_STATE
		sb.append(failedFlag); // FAILED_FLAG
		sb.append(muId); // MU_ID
		sb.append(assignedTs == null ? "" : DateUtils.formatDate(new Date(
				assignedTs))); // PROCESS_START_TS
		sb.append(resultTs == null ? "" : DateUtils.formatDate(new Date(
				resultTs))); // RESULTS_TS
		sb.append(submissionTs == null ? "" : DateUtils.formatDate(new Date(
				submissionTs))); // SUBMISSION_TS
		sb.append(failureCount); // FAILURE_COUNT
		sb.append(callbackUrl);
		sb.append(callbackStyle == null ? "" : callbackStyle.name());
		return sb.toString();
	}
}