package jp.co.nec.aim.mm.segment.sync;

import java.io.Serializable;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;

import com.google.protobuf.ByteString;

/**
 * SegSyncInfos used for save the sync information
 * 
 * @author liuyq
 * 
 */
public class SegSyncInfos implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -8112460864475125259L;

	private Long segmentId; // segment id
	private Long segVersion; // segmentVersion
	private Long templateId;// templateId only set when delete
	private boolean isUpdateSegment; // update exist or create new

	private ByteString templateBinary; // save the binary
	private SegmentSyncCommandType command; // insert or delete

	/**
	 * SegSyncInfos constructor
	 * 
	 * @param segmentId
	 * @param templateBinary
	 * @param isUpdateSegment
	 */
	public SegSyncInfos(Long segmentId, Long segVersion,
			ByteString templateBinary, boolean isUpdateSegment,
			SegmentSyncCommandType command) {
		this.segmentId = segmentId;
		this.segVersion = segVersion;
		this.templateBinary = templateBinary;
		this.isUpdateSegment = isUpdateSegment;
		this.command = command;
	}

	/**
	 * SegSyncInfos another constructor
	 * 
	 * @param segmentId
	 * @param segVersion
	 * @param templateId
	 * @param command
	 */
	public SegSyncInfos(long segmentId, long segVersion, long templateId,
			SegmentSyncCommandType command) {
		this.segmentId = segmentId;
		this.segVersion = segVersion;
		this.templateId = templateId;
		this.command = command;
	}

	public Long getSegmentId() {
		return segmentId;
	}

	public void setSegmentId(Long segmentId) {
		this.segmentId = segmentId;
	}

	public ByteString getTemplateBinary() {
		return templateBinary;
	}

	public void setTemplateBinary(ByteString templateBinary) {
		this.templateBinary = templateBinary;
	}

	public boolean isUpdateSegment() {
		return isUpdateSegment;
	}

	public void setUpdateSegment(boolean isUpdateSegment) {
		this.isUpdateSegment = isUpdateSegment;
	}

	public SegmentSyncCommandType getCommand() {
		return command;
	}

	public void setCommand(SegmentSyncCommandType command) {
		this.command = command;
	}

	public Long getSegVersion() {
		return segVersion;
	}

	public void setSegVersion(Long segVersion) {
		this.segVersion = segVersion;
	}

	public Long getTemplateId() {
		return templateId;
	}

	public void setTemplateId(Long templateId) {
		this.templateId = templateId;
	}

}
