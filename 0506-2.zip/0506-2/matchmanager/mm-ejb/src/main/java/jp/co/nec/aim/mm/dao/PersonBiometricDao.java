package jp.co.nec.aim.mm.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import jp.co.nec.aim.mm.entities.PersonBiometricEntity;

/**
 * SegmentDao
 * 
 * @author liuyq
 * 
 */
public class PersonBiometricDao {

	private EntityManager manager;

	public PersonBiometricDao(EntityManager manager) {
		this.manager = manager;
	}

	/**
	 * findPersonBiometric
	 * 
	 * @param bioId
	 * @return PersonBiometric instance
	 */
	public PersonBiometricEntity findPersonBiometric(long bioId) {
		return manager.find(PersonBiometricEntity.class, bioId);
	}
	
	public int delBioByExternalId (String id) {
		Query q = manager.createNamedQuery("NQ::delBioUsingEnrollId");
		q.setParameter("enrollId", id);
		return q.executeUpdate();
	}
	
	@SuppressWarnings("unchecked")
	public PersonBiometricEntity getBioDataByExternalId(String enternalId) {
		Query q = manager.createNamedQuery("NQ::checkEnrollmentID");
		q.setParameter("enrollId", enternalId);		
		List<PersonBiometricEntity> results = q.getResultList();
		if (results.size() > 0) {
			return results.get(0);
		} else {
			return null;
		}
		
		
		
	}

}
