package jp.co.nec.aim.mm.dao;

import java.util.Arrays;
import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.entities.FeJobPayloadEntity;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.entities.FeLotJobEntity;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.annotation.Repeat;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class FEPlanDispatchDaoImplTest extends
		AbstractTransactionalJUnit4SpringContextTests {

	@PersistenceContext(unitName = "aim-db")
	protected EntityManager entityManager;

	@Resource
	private DataSource dataSource;
	@Resource
	private JdbcTemplate jdbcTemplate;

	private FEPlanDispatchDao dispatchDao;

	@Before
	public void setUp() throws Exception {
		dispatchDao = new FEPlanDispatchDaoImpl(entityManager, jdbcTemplate);
		jdbcTemplate.update("delete from fe_lot_jobs");
		jdbcTemplate.update("delete from fe_job_payloads");
		jdbcTemplate.update("delete from fe_job_queue");
		jdbcTemplate.update("delete from match_units");
		jdbcTemplate.execute("commit");
	}

	@After
	public void tearDown() throws Exception {
		dispatchDao = null;
		jdbcTemplate.update("delete from fe_lot_jobs");
		jdbcTemplate.update("delete from fe_job_payloads");
		jdbcTemplate.update("delete from fe_job_queue");
		jdbcTemplate.update("delete from match_units");
		jdbcTemplate.execute("commit");
	}

	@Test
	public void testGetFeLotJob_normal() {
		Integer muId = 1000;
		long feLotJobId = 8000;
		testGetFeLotJobHelp(muId, feLotJobId);
	}

	@Test
	public void testGetFeLotJob_timeout_value() {
		Integer muId = 1000;
		long feLotJobId = 8000;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		jdbcTemplate.update(muSql,
				new Object[] { new Integer(muId), String.valueOf((muId)),
						"working", new Integer(5) });
		String feLotJobdSql = "INSERT INTO fe_lot_jobs (LOT_JOB_ID,MU_ID, ASSIGNED_TS, TIMEOUTS)  VALUES(?,?,?,?)";
		jdbcTemplate.update(feLotJobdSql, new Object[] { new Long(feLotJobId),
				new Integer(muId), 400, new Integer(-1) });
		FeLotJobEntity result = dispatchDao.getFeLotJob(feLotJobId);
		if (result != null && result.getLotJobId() >= 0) {
			Assert.assertNotNull(result);
			Assert.assertEquals(feLotJobId, result.getLotJobId());
			Assert.assertEquals(muId.intValue(), result.getMuId());
			Assert.assertEquals(400, result.getAssignedTs().longValue());
			Assert.assertEquals(-1, result.getTimeouts());
		} else {
			Assert.assertNull(result);
		}

	}

	@Test
	public void testGetFeLotJob_null() {
		Integer muId = 2000;
		long feLotJobId = -1;
		testGetFeLotJobHelp(muId, feLotJobId);
	}

	@Test(expected = DuplicateKeyException.class)
	public void testGetFeLotJob_Exception() {
		Integer muId = 5;
		long feLotJobId = 1;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		jdbcTemplate.update(muSql,
				new Object[] { new Integer(muId), String.valueOf((muId)),
						"working", new Integer(5) });
		testGetFeLotJobHelp(muId, feLotJobId);
	}

	@Test
	@Repeat(value = 10)
	public void testGetFeLotJob_repeat() {
		Integer[] muId = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
		long[] feLotJobId = { 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 };
		for (int i = 0; i < 10; i++) {
			testGetFeLotJobHelp(muId[i], feLotJobId[i]);
		}
	}

	public void testGetFeLotJobHelp(Integer muId, long feLotJobId) {
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		jdbcTemplate.update(muSql,
				new Object[] { new Integer(muId), String.valueOf((muId)),
						"working", new Integer(5) });
		String feLotJobdSql = "INSERT INTO fe_lot_jobs (LOT_JOB_ID,MU_ID, ASSIGNED_TS, TIMEOUTS)  VALUES(?,?,?,?)";
		jdbcTemplate.update(feLotJobdSql, new Object[] { new Long(feLotJobId),
				new Integer(muId), 400, new Integer(3000) });
		FeLotJobEntity result = dispatchDao.getFeLotJob(feLotJobId);
		if (result != null && result.getLotJobId() >= 0) {
			Assert.assertNotNull(result);
			Assert.assertEquals(feLotJobId, result.getLotJobId());
			Assert.assertEquals(muId.intValue(), result.getMuId());
			Assert.assertEquals(400, result.getAssignedTs().longValue());
			Assert.assertEquals(3000, result.getTimeouts());
		} else {
			Assert.assertNull(result);
		}
	}

	@Test
	public void testGetFeJobs_normal() {
		Integer muId = 1000;
		long feLotJobId = 8000;
		Long[] feJobIds = { 4000L, 4001L, 4002L, 4003L };
		testGetFeJobsHelp(muId, feLotJobId, feJobIds);
	}

	@Test
	public void testGetFeJobs_normal_1() {
		Integer muId = 1000;
		long feLotJobId = 8000;
		Long[] feJobIds = { 10L };
		testGetFeJobsHelp(muId, feLotJobId, feJobIds);
	}

	@Test
	@Repeat(value = 10)
	public void testGetFeJobs_repeat() {
		Integer muId = 1000;
		long feLotJobId = 8000;
		Long[] feJobIds = { 10L };
		testGetFeJobsHelp(muId, feLotJobId, feJobIds);
	}

	@Test(expected = DuplicateKeyException.class)
	public void testGetFeJobs_Exception() {
		Integer muId = 1000;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		jdbcTemplate.update(muSql,
				new Object[] { new Integer(muId), String.valueOf((muId)),
						"working", new Integer(5) });
		long feLotJobId = 8000;
		Long[] feJobIds = { 4000L, 4001L, 4002L, 4003L };
		testGetFeJobsHelp(muId, feLotJobId, feJobIds);
	}

	@SuppressWarnings("null")
	public void testGetFeJobsHelp(Integer muId, long feLotJobId, Long[] feJobIds) {
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		jdbcTemplate.update(muSql,
				new Object[] { new Integer(muId), String.valueOf((muId)),
						"working", new Integer(5) });
		String feLotJobdSql = "INSERT INTO fe_lot_jobs (LOT_JOB_ID,MU_ID, ASSIGNED_TS, TIMEOUTS)  VALUES(?,?,?,?)";
		jdbcTemplate.update(feLotJobdSql, new Object[] { new Long(feLotJobId),muId, 400, new Integer(3000) });
				
		Integer[] priotity = { 0, 1, 2, 3 };
		Integer[] states = { 2, 2, 0, 1 };
		long ts = System.currentTimeMillis();
		String feJobSql = "insert into fe_job_queue(job_id,UIDAI_REQUEST_ID,UID_REQUEST_TYPE,lot_job_id,mu_id,function_id,PRIORITY,job_state,submission_ts,CALLBACK_STYLE)"
				+ " values(?,?, 'extract',?,?,17,?,?,?,0)";
		if (feJobIds != null || feJobIds.length > 0) {
			for (int i = 0; i < feJobIds.length; i++) {
				jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i], String.valueOf(i),
						new Long(feLotJobId), muId, priotity[i],
						states[i], new Long(ts) });
			}
		}
		List<FeJobQueueEntity> results = dispatchDao.getFeJobs(feLotJobId);
		if (results != null && results.size() > 0) {
			Assert.assertEquals(feJobIds.length, results.size());
			for (int i = 0; i < results.size(); i++) {
				Assert.assertEquals(feJobIds[i].longValue(), results.get(i)
						.getId());
				Assert.assertEquals(muId.intValue(), results.get(i).getMuId()
						.intValue());
				Assert.assertEquals(feLotJobId, results.get(i).getLotJobId()
						.longValue());
			}
		} else {
			Assert.assertNull(results);
		}
	}

	@Test
	public void testGetFeJobPayLoads_normal_1() {
		Integer muId = 1000;
		Long[] feJobIds = { 4000L, 4001L, 4002L, 4003L };
		Long[] payloadIds = { 5L, 4L, 3L, 2L };
		testGetFeJobPayLoadsHelp(muId, feJobIds, payloadIds);
	}

	@Test
	public void testGetFeJobPayLoads_normal_2() {
		Integer muId = 1000;
		Long[] feJobIds = { 4000L };
		Long[] payloadIds = { 5L };
		testGetFeJobPayLoadsHelp(muId, feJobIds, payloadIds);
	}

	@Test(expected = DuplicateKeyException.class)
	public void testGetFeJobPayLoads_Exception() {
		Integer muId = 1000;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		jdbcTemplate.update(muSql,
				new Object[] { new Integer(muId), String.valueOf((muId)),
						"working", new Integer(5) });
		Long[] feJobIds = { 4000L };
		Long[] payloadIds = { 5L };
		testGetFeJobPayLoadsHelp(muId, feJobIds, payloadIds);
	}

	@Test
	@Repeat(value = 10)
	public void testGetFeJobPayLoads_repeat() {
		Integer muId = 1000;
		Long[] feJobIds = { 4000L };
		Long[] payloadIds = { 5L };
		testGetFeJobPayLoadsHelp(muId, feJobIds, payloadIds);
	}

	public void testGetFeJobPayLoadsHelp(Integer muId, Long[] feJobIds,
			Long[] payloadIds) {
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		jdbcTemplate.update(muSql,
				new Object[] { new Integer(muId), String.valueOf((muId)),
						"working", new Integer(5) });

		Integer[] priotity = { 0, 1, 2, 3 };
		Integer[] states = { 2, 2, 0, 1 };
		long ts = System.currentTimeMillis();
		String feJobSql = "insert into fe_job_queue(job_id,UIDAI_REQUEST_ID,UID_REQUEST_TYPE,mu_id,function_id,PRIORITY,job_state,submission_ts,CALLBACK_STYLE)"
				+ " values(?,?, 'test',?,17,?,?,?,0)";
		for (int i = 0; i < feJobIds.length; i++) {
			jdbcTemplate.update(feJobSql, new Object[] { feJobIds[i], String.valueOf(i),
					new Integer(muId), priotity[i], states[i], new Long(ts) });
		}
		
		jdbcTemplate.execute("commit");

		String payLoadSql = "insert into fe_job_payloads(payload_id,payload,job_id) values(?,'extract payload',?)";
		if (payloadIds != null && payloadIds.length > 0) {
			for (int i = 0; i < payloadIds.length; i++) {
				jdbcTemplate.update(payLoadSql, new Object[] { payloadIds[i],
						feJobIds[i] });
			}
		}

		List<FeJobPayloadEntity> results = dispatchDao.getFeJobPayLoads(Arrays
				.asList(feJobIds));
		if (results != null && results.size() > 0) {
			for (int j = 0; j < results.size(); j++) {
				Assert.assertEquals(payloadIds[j].longValue(), results.get(j)
						.getId());
				Assert.assertEquals(feJobIds[j].longValue(), results.get(j)
						.getJobId());
			}
		}
	}

	@Test
	public void testGetMuUrl_normal() {
		Integer muId = 1000;
		String muUrl = "http://www.nec.co.jp";
		testGetMuUrlHelp(muId, muUrl);
	}

	@Test
	public void testGetMuUrl_null() {
		Integer muId = 1000;
		String muUrl = "";
		testGetMuUrlHelp(muId, muUrl);
	}

	@Test(expected = DuplicateKeyException.class)
	public void testGetMuUrl_Exception() {
		Integer muId = 1000;
		String muUrl = "http://www.nec.co.jp";
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID,CONTACT_URL, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?,?)";
		jdbcTemplate.update(muSql,
				new Object[] { new Integer(muId), String.valueOf(muId), muUrl,
						"working", new Integer(5) });
		testGetMuUrlHelp(muId, muUrl);
	}

	@Test
	@Repeat(value = 5)
	public void testGetMuUrl_repeat() {
		Integer[] muId = { 1, 2, 3, 4, 5 };
		String[] muUrl = { "http://www.nec.co.jp", "http://www.nec.co.jp",
				"http://www.nec.co.jp", "http://www.nec.co.jp",
				"http://www.nec.co.jp" };
		for (int i = 0; i < 5; i++) {
			testGetMuUrlHelp(muId[i], muUrl[i]);
		}
	}

	public void testGetMuUrlHelp(Integer muId, String muUrl) {
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID,CONTACT_URL, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?,?)";
		jdbcTemplate.update(muSql,
				new Object[] { new Integer(muId), String.valueOf(muId), muUrl,
						"working", new Integer(5) });
		String rusult = dispatchDao.getMuUrl(muId);
		if (rusult != null && rusult.length() > 0) {
			Assert.assertEquals(muUrl, rusult);
		} else {
			Assert.assertNull(rusult);
		}
	}

	@Test
	public void testGetFeJobTimeOut() {
		String topLevelTimeOutSql = "select TOP_LEVEL_JOB_TIMEOUTS from function_types where function_id = ?";
		long extractTimeOut = jdbcTemplate.queryForObject(topLevelTimeOutSql,
				new Object[] { new Integer(17) }, Long.class);
		long rusult = dispatchDao.getFeJobTimeOut();
		Assert.assertEquals(extractTimeOut, rusult);
	}

	@Test
	public void testGetMaxExtractJobRetryCount() {
		jdbcTemplate.update("delete from system_config");
		String insertSql = "insert into system_config (property_name, property_value) values "
				+ " ('BEHAVIOR.MAX_EXTRACT_JOB_FAILURES','5')";
		jdbcTemplate.execute(insertSql);
		Integer results = dispatchDao.getMaxExtractJobRetryCount();
		Assert.assertEquals(5, results.intValue());
	}

	@Test	
	public void testUpdateMuExtractLoad_normal() {
		int muId = 1;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		jdbcTemplate.update(muSql,
				new Object[] { new Integer(muId), String.valueOf((muId)),
						"working", new Integer(5) });
		String insSql = "insert into mu_extract_load(mu_id,pressure,update_ts) values(1,2,3000)";
		String querySql = "select pressure from  mu_extract_load ml where ml.mu_id = ?";
		jdbcTemplate.update(insSql);

		dispatchDao.updateMuExtractLoad(muId);
		int newPressure = jdbcTemplate.queryForObject(querySql,
				new Object[] { new Integer(muId) }, Integer.class);
		Assert.assertEquals(1, newPressure);
	}

	@Test
	@Ignore
	public void testUpdateMuExtractLoad_minus() {
		int muId = 1;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		jdbcTemplate.update(muSql,
				new Object[] { new Integer(muId), String.valueOf((muId)),
						"working", new Integer(5) });
		String insSql = "insert into mu_extract_load(mu_id,pressure,update_ts) values(1,0,3000)";
		String querySql = "select pressure from  mu_extract_load ml where ml.mu_id = ?";
		jdbcTemplate.update(insSql);

		dispatchDao.updateMuExtractLoad(muId);
		int newPressure = jdbcTemplate.queryForObject(querySql,
				new Object[] { new Integer(muId) }, Integer.class);
		Assert.assertEquals(0, newPressure);
	}

	@Test
	@Ignore
	public void testUpdateMuExtractLoad_zero() {
		int muId = 1;
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,?,?)";
		jdbcTemplate.update(muSql,
				new Object[] { new Integer(muId), String.valueOf((muId)),
						"working", new Integer(5) });
		String insSql = "insert into mu_extract_load(mu_id,pressure,update_ts) values(1,1,3000)";
		String querySql = "select pressure from  mu_extract_load ml where ml.mu_id = ?";
		jdbcTemplate.update(insSql);

		dispatchDao.updateMuExtractLoad(muId);
		int newPressure = jdbcTemplate.queryForObject(querySql,
				new Object[] { new Integer(muId) }, Integer.class);
		Assert.assertEquals(0, newPressure);
	}
}
