package jp.co.nec.aim.mm.receiver;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.persistence.EntityManager;

import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.JNDIConstants;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.exception.HttpPostException;
import jp.co.nec.aim.mm.sessionbeans.pojo.ExceptionSender;
import jp.co.nec.aim.mm.spring.jms.AsynchHTTPJMSMessage;
import jp.co.nec.aim.mm.util.HttpPoster;
import jp.co.nec.aim.mm.util.JndiLookup;

import org.jboss.logging.NDC;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author jinxl
 */
@MessageDriven(activationConfig = {
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
		@ActivationConfigProperty(propertyName = "destination", propertyValue = JNDIConstants.ASYNCH_QUEUE) })
public class AsynchInquiryPosterReceiver implements MessageListener {
	private static final String SLASH = "/";
	private static final String UNKNOWN = "unknown";
	private static Logger log = LoggerFactory
			.getLogger(AsynchInquiryPosterReceiver.class);
	private EntityManager entityManager;
	private ExceptionSender exceptionSender;

	public AsynchInquiryPosterReceiver() {
	}

	public void onMessage(Message message) {
		AsynchHTTPJMSMessage payload = null;
		entityManager = JndiLookup.lookUp(JNDIConstants.EntityManagerName,
				EntityManager.class);
		exceptionSender = new ExceptionSender();
		String jobId = UNKNOWN;
		String url = UNKNOWN;
		try {
			NDC.push("JMS ONMESSAGE");
			ObjectMessage objMsg = (ObjectMessage) message;
			payload = (AsynchHTTPJMSMessage) objMsg.getObject();
			url = payload.getURL();
			jobId = url.substring(url.lastIndexOf(SLASH)+1);
			if (!message.getJMSRedelivered()) {
				SystemConfigDao configDao = new SystemConfigDao(entityManager);
				final int retryCount = configDao
						.getMMPropertyInt(MMConfigProperty.CLIENT_POST_COUNT);
				if (payload.isBinary()) {
					HttpPoster.post(url, payload.getBody(),
							retryCount);
				} else {
					HttpPoster.post(url, payload.getBodyMessage(),
							retryCount);
				}
				log.info("Finished sending Inquiry job({}) callback to {}.", jobId, url);
			} else {
				log.warn("This MDB message was redelivered; Skipped sending Inquiry job({}) callback.", jobId);
			}
		} catch (JMSException e) {
			String errorMessage = String.format(
					"JMSException while attempting Inquiry job(%s) callback to '%s'.", jobId, url);
			log.error(errorMessage, e);
			exceptionSender.sendAimException(
					AimError.INTERNAL_ERROR.getErrorCode(), errorMessage, e);
		} catch (HttpPostException e) {
			// deliberately not chaining HttpPostException eliminate stack trace
			// chain in log.
			String errorMessage = String.format(
					"HttpPostException while attempting Inquiry job(%s) callback to '%s'.", jobId, url);
			log.error(errorMessage, e);
			exceptionSender.sendAimException(
					AimError.INTERNAL_ERROR.getErrorCode(), errorMessage,
					new Exception(e.getMessage()));
		} catch (RuntimeException e) {
			String errorMessage = String.format(
					"RuntimeException while attempting Inquiry job(%s) callback to '%s'.", jobId, url);
			log.error(errorMessage, e);
			exceptionSender.sendAimException(
					AimError.INTERNAL_ERROR.getErrorCode(), errorMessage, e);
		} finally {
			NDC.clear();
		}
	}
}
