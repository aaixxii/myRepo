DELIMITER $$
DROP PROCEDURE IF EXISTS `transferEmailTempData`$$
CREATE PROCEDURE transferEmailTempData(IN jobId VARCHAR(24))
BEGIN
  DECLARE idval VARCHAR(24) DEFAULT '';
  DECLARE taskIdval VARCHAR(24) DEFAULT '';
  DECLARE groupIdval VARCHAR(24) DEFAULT '';
  DECLARE emailval VARCHAR(50) DEFAULT '';  
  DECLARE infoId VARCHAR(24) DEFAULT '';  
  DECLARE err INT DEFAULT 0;   
  DECLARE counts INT DEFAULT 0;   
  DECLARE isrollback INT DEFAULT 0;    
  DECLARE done INTEGER DEFAULT 0;    
  DECLARE cur CURSOR FOR SELECT id,taskId,groupId,email FROM `t_email_data_temp` WHERE taskId=jobId;    
  DECLARE cur2 CURSOR FOR SELECT id FROM `t_email_info` e WHERE e.`group_id` = groupIdval AND e.`email_address` = emailval;     
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET err=1;
  DECLARE CONTINUE HANDLER FOR NOT FOUND
  SET done=1;   
  START TRANSACTION;   
  OPEN cur;    
  out_loop:LOOP     
    FETCH cur INTO idval,taskIdval,groupIdval,emailval;
    IF done = 1 THEN
      LEAVE out_loop; /*jump to out_loop*/
    END IF;       
    OPEN cur2;
      SET done = 0;
      FETCH cur2 INTO infoId; 
      IF done = 1 THEN  
        INSERT INTO `t_email_info` VALUES(idval,emailval,groupIdval,0,'',NOW(),'admin',NOW(),'admin'); 
        DELETE FROM `t_email_data_temp` WHERE id = idval;  
        SET counts = counts + 1;  
        IF err=1 THEN
          SET isrollback=1;
          ROLLBACK;
        ELSE
          IF counts = 1000 THEN
            COMMIT;           
            SET counts=0;
          END IF;
        END IF;
      ELSE       
        IF done=0 THEN
          DELETE FROM `t_email_data_temp` WHERE id = idval;
        END IF;
      END IF;
      FETCH cur2 INTO infoId;
    CLOSE cur2;       
    SET done=0;    
  END LOOP out_loop;
  CLOSE cur;   
  IF isrollback=0 THEN
    UPDATE `t_email_task` t SET t.`if_finish` = 1 WHERE t.`id`=jobId;
  END IF;  
  END$$
DELIMITER ;