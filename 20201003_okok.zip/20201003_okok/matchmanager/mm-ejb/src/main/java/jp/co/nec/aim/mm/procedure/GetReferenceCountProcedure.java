package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;
import java.sql.Types;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.object.StoredProcedure;

/**
 *
 * @author s-konno
 *
 */

public class GetReferenceCountProcedure extends StoredProcedure {
	private static final String GET_REF_CNT = "get_reference_count";

	public GetReferenceCountProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(GET_REF_CNT);
		setFunction(true);
		declareParameter(new SqlOutParameter("r_reference_count", Types.BIGINT));
		compile();
	}

	public Long getRefCnt() throws SQLException {
		Map<String, Object> resultMap = execute();
		Long refCnt = (Long) resultMap.get("r_reference_count");
		return refCnt;
	}
}
