package jp.co.nec.aim.mm.acceptor.service;

import java.io.IOException;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;

import jp.co.nec.aim.mm.acceptor.AimInquiryRequest;
import jp.co.nec.aim.mm.acceptor.CommonOptions;
import jp.co.nec.aim.mm.acceptor.Inquiry;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.UidRequestType;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.FEJobDao;
import jp.co.nec.aim.mm.dao.FunctionDao;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.dao.MatchManagerDao;
import jp.co.nec.aim.mm.dao.PersonBiometricDao;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.entities.FunctionTypeEntity;
import jp.co.nec.aim.mm.entities.PersonBiometricEntity;
import jp.co.nec.aim.mm.exception.AimIdnetifyException;
import jp.co.nec.aim.mm.exception.ExceptionHelper;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.jms.NotifierEnum;
import jp.co.nec.aim.mm.procedure.FeJobProcedures;
import jp.co.nec.aim.mm.sessionbeans.DmServiceBean;
import jp.co.nec.aim.mm.util.XmlUtil;
import jp.co.nec.aim.mm.validator.AcceptorValidator;

/**
 * The main work flow of inquiry <br>
 * 
 * Include following public method:
 * <p>
 * inquiry, getJobStatus, listJobIds, deleteJob clearJobs, getJobResult,
 * getJobResult
 * <p>
 * 
 * @author xiazp
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AimInquiryService {
	/** log instance **/
	private static Logger log = LoggerFactory.getLogger(AimInquiryService.class);

	@PersistenceContext(unitName = "aim-db")
	private EntityManager manager;

	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;
	@EJB
	DmServiceBean dmServiceBean;
	
	@EJB
	private Inquiry inquiry;
	private InquiryJobDao inquiryJobDao;
	private DateDao dateDao;
	private FEJobDao feJobDao;
	private FunctionDao functionDao;	
	private MatchManagerDao mmDao;
	private FeJobProcedures feJobProcedures;
	private PersonBiometricDao personBiometricDao;	
	private ExceptionHelper exception;

	/**
	 * AimInquiryService default constructor
	 */
	public AimInquiryService() {
	}

	@PostConstruct
	private void init() {
		this.inquiryJobDao = new InquiryJobDao(manager, dataSource);
		this.dateDao = new DateDao(dataSource);
		this.feJobDao = new FEJobDao(manager, dataSource);
		this.functionDao = new FunctionDao(manager);		
		this.mmDao = new MatchManagerDao(manager);
		this.feJobProcedures = new FeJobProcedures(dataSource);
		this.personBiometricDao = new PersonBiometricDao(manager);
		this.exception = new ExceptionHelper(dateDao);
	}

	/**
	 * The main work flow of inquiry
	 * 
	 * @param request
	 *            PBInquiryJobRequest instance
	 * @param isFromServlet
	 *            IS called by SERVLET
	 * @return PBInquiryJobResponse instance
	 * @throws IOException
	 */
	public Boolean inquiry(final String inqRequest, boolean isFromServlet) {
		if (log.isDebugEnabled()) {
			log.debug(inqRequest);
		}
		try {
			String requestId = XmlUtil.getRequestId(inqRequest);
			String cmd = XmlUtil.getXmlCmd(inqRequest);
			String refId = XmlUtil.getRefId(inqRequest, UidRequestType.Identify.name());
			String refUrl = XmlUtil.getUrl(inqRequest, UidRequestType.Identify.name());
			String maxResults = XmlUtil.getIdentifyAtribute(inqRequest, "maxResults");
			AcceptorValidator.checkInquiryRequest(inqRequest, requestId, cmd, refId, refUrl, maxResults);			
			final CommonOptions options = new CommonOptions();
			options.setFromServlet(isFromServlet);
			options.setFunctioName("MI");
			options.setMaxCandidates(Integer.valueOf(maxResults));
			AimInquiryRequest aimInquiryRequest = null;
			byte[] templateData = null;
			if (!StringUtils.isBlank(refId)) {
				templateData = tryGetTemplateFromFeQueue(refId);
				if (templateData == null) {
					PersonBiometricEntity psEntity = personBiometricDao.isHaveBioMetricDataInMyTable(refId);
					if (psEntity != null) {
						try {
							templateData = dmServiceBean.getTemplate(refId);
						} catch (Exception e) {
							AimError aimErr = AimError.INQ_JOB_DM_SERVICE_ERR;
							throw new AimIdnetifyException(aimErr.getMessage(), aimErr.getErrorCode(),
									String.valueOf(System.currentTimeMillis()), aimErr.getUidCode());
						}
					}
				}
				if (templateData != null && templateData.length > 1) {
					aimInquiryRequest = new AimInquiryRequest("MI", Integer.valueOf(1), requestId, inqRequest,
							templateData);
					doGetIdentifyResponse(aimInquiryRequest, options);

				}
			}
			if (templateData == null && !StringUtils.isBlank(refId) && !StringUtils.isBlank(refUrl)) {
				FunctionTypeEntity fte = functionDao.getExtractFunction();
				if (fte == null) {
					AimError dbErr = AimError.SYNC_FUNCTIONTYPE;
					log.error(dbErr.getErrorCode() + dbErr.getUidCode());
					return Boolean.FALSE;
				}
				String myUrl = mmDao.getMyIpAndPort();
				Long newFeJobId = null;
				try {
					newFeJobId = feJobProcedures.createNewFeJob(refId, requestId, UidRequestType.Identify.name(), myUrl,
							inqRequest);
				} catch (Exception e1) {
					feJobDao.deleteExtractJob(newFeJobId);
					log.error(e1.getMessage(), e1);
					return Boolean.FALSE;	
				}

				JmsSender.getInstance().sendToFEJobPlanner(NotifierEnum.ExtractService,
						String.format("create extract job id: %s", newFeJobId));
				log.info("Notify to FEJobPlanner, jobId ={}", newFeJobId);

			}
			return Boolean.TRUE;

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return Boolean.FALSE;
		}
	}

	private byte[] tryGetTemplateFromFeQueue(String refId) {
		byte[] data = null;
		List<FeJobQueueEntity> resultList = feJobDao.getExResult(refId);
		if (resultList != null && resultList.size() > 0) {
			data = resultList.get(0).getTempalteData();
		}
		return data;
	}

	private Long doGetIdentifyResponse(final AimInquiryRequest aimInquiryRequest, final CommonOptions options) {
		String requestId = aimInquiryRequest.getRequestId();
		final List<AimInquiryRequest> aimRequestList = Lists.newArrayList();
		aimRequestList.add(aimInquiryRequest);
		long jobId = inquiry.inquiry(aimRequestList, requestId, options);
		return Long.valueOf(jobId);
	}

	/**
	 * delete the inquiry Job with specified job id
	 * 
	 * @param request
	 *            PBDeleteJobRequest instance
	 */
	public void deleteJob(String deleRequest) {
		String requestId = XmlUtil.getRequestId(deleRequest);
		try {
			inquiryJobDao.deleteJobByRequstId(requestId);
		} catch (Exception ex) {
			exception.throwDBException(AimError.INQ_DB, ex,
					String.format("Exception occurred when when delete " + "inquiry job by requestId %s", requestId));
		}
	}

	/**
	 * clear all inquiry Jobs
	 */
	public void clearJobs() {
		try {
			inquiryJobDao.clearJobs();
		} catch (Exception ex) {
			exception.throwDBException(AimError.INQ_DB, ex, "Exception occurred when clear inquiry job.");
		}
	}
}
