CREATE DEFINER=`aimuser`@`%` PROCEDURE `increase_ruc`()
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
declare l_count int;
declare l_update_count int;
DECLARE t_error INTEGER DEFAULT 0;  
DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;  
START TRANSACTION;
        SELECT COUNT(update_count) into l_count  FROM resource_update_count;
         IF(l_count = 0)
         THEN
           INSERT INTO resource_update_count(update_count, update_ts) VALUES(1, get_epoch_time_num());
         ELSE
           SELECT update_count + 1 into l_update_count FROM resource_update_count ORDER BY update_ts DESC limit 1;
           IF l_update_count < 0 THEN
              set l_update_count := 0;
           END IF;
           UPDATE resource_update_count SET update_count = l_update_count, update_ts = get_epoch_time_num();
         END IF;
         COMMIT;     
END