package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.nec.aim.dm.dmservice.DmserviceApplication;
import com.nec.aim.dm.dmservice.entity.NodeStorage;

@RunWith(SpringRunner.class)  
@SpringBootTest(classes={DmserviceApplication.class})
public class NodeStorageRepositoryImplTest {
	
	@Autowired
	NodeStorageRepository nodeStorageRepository;
	
	@Autowired
    private JdbcTemplate jdbcTemplate;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	@Transactional
	public void testFindAll() throws SQLException {
		List<NodeStorage> nodeStorages = nodeStorageRepository.findAll();
		Assert.assertEquals(3, nodeStorages.size());
	}

	@Test
	@Transactional
	public void testFindById() throws SQLException {
		NodeStorage result = nodeStorageRepository.findById(4L, "dm_storage4");
		Assert.assertEquals(4, result.getStorageId());
	}

	@Test
	@Transactional
	public void testFindNeedNodeByRedundancy() throws SQLException {
		List<NodeStorage> result = nodeStorageRepository.findNeedNodeByRedundancy(3);
		Assert.assertEquals(3, result.size());
		Assert.assertTrue(result.get(0).getSpace() >= result.get(1).getSpace());
		Assert.assertTrue(result.get(1).getSpace()  >= result.get(2).getSpace());
	}

	@Test
	@Transactional
	public void testSetSignalMailFlag() {
		nodeStorageRepository.setSignalMailFlag(1, "dm_storage1");
		String sql = "select * from node_storage where storage_id = 1 and dm_storage_id='dm_storage1'";
		Map<String, Object> result = jdbcTemplate.queryForMap(sql);
		String mailFalg = (String) result.get("mail_flag");
		Assert.assertEquals("signal", mailFalg);		
	}

}
