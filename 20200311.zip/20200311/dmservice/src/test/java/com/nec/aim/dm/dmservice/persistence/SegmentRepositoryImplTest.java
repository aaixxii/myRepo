package com.nec.aim.dm.dmservice.persistence;

import java.sql.SQLException;
import java.util.Map;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.nec.aim.dm.dmservice.DmserviceApplication;
import com.nec.aim.dm.dmservice.entity.SegmentInfo;

@RunWith(SpringRunner.class)  
@SpringBootTest(classes={DmserviceApplication.class})
public class SegmentRepositoryImplTest {
	
	@Autowired
	SegmentRepository segmentRepository;
	
	@Autowired
    private JdbcTemplate jdbcTemplate;

	@Before
	public void setUp() throws Exception {		
		jdbcTemplate.execute("delete from segment_loading");
		jdbcTemplate.execute("delete from segments_info");
	}

	@After
	public void tearDown() throws Exception {
	}

	@Transactional
    @Test
	public void testInsertSegment() throws SQLException {
		SegmentInfo segInfo = new SegmentInfo();
		segInfo.setSegmentId(1000);		
		segmentRepository.insertSegment(segInfo);
		String selectSql = "select * from segments_info where segment_id = 1000";
		Map<String, Object> result = jdbcTemplate.queryForMap(selectSql);
		long segmentId = (long) result.get("segment_id");
		long version = (long) result.get("version");
		long recordCount = (long) result.get("record_count");
		long bio_id_start = (long) result.get("bio_id_start");	
		long bio_id_end  = (long) result.get("bio_id_end");	
		long dataSize = (long) result.get("binary_length");	
		Assert.assertEquals(1000, segmentId);
		Assert.assertEquals(0, version);
		Assert.assertEquals(0, recordCount);
		Assert.assertEquals(0, bio_id_end );
		Assert.assertEquals(0, bio_id_start);	
		Assert.assertEquals(26, dataSize);
		Assert.assertEquals(0, version);
		System.out.print("OKOK");		
	}

	@Transactional
	@Test
	public void testUpdateSegment() throws SQLException {
		SegmentInfo segInfo = new SegmentInfo();
		segInfo.setSegmentId(1000);
		segInfo.setVersion(-1);
		segmentRepository.insertSegment(segInfo);
		segInfo.setBioIdStart(1l);
		segInfo.setBioIdEnd(1l);
		segInfo.setBinaryLegth(36000);		
		segmentRepository.updateSegment(segInfo);		
	
		String selectSql = "select * from segments_info where segment_id = 1000";
		Map<String, Object> result = jdbcTemplate.queryForMap(selectSql);
		long segmentId = (long) result.get("segment_id");
		long version = (long) result.get("version");
		long recordCount = (long) result.get("record_count");
		long bio_id_start = (long) result.get("bio_id_start");	
		long bio_id_end  = (long) result.get("bio_id_end");	
		long dataSize = (long) result.get("binary_length");	
		Assert.assertEquals(1000, segmentId);
		Assert.assertEquals(1, version);
		Assert.assertEquals(1, recordCount);
		Assert.assertEquals(1, bio_id_end );
		Assert.assertEquals(1, bio_id_start);	
		Assert.assertEquals(36080, dataSize);
		jdbcTemplate.execute("commit");
		segmentRepository.updateSegmentAfterDelete(segInfo);
		jdbcTemplate.execute("commit");
		Map<String, Object> result2 = jdbcTemplate.queryForMap(selectSql);
		long segmentId2 = (long) result2.get("segment_id");
		long version2 = (long) result2.get("version");
		long recordCount2 = (long) result2.get("record_count");
		long bio_id_start2 = (long) result2.get("bio_id_start");	
		long bio_id_end2  = (long) result2.get("bio_id_end");				
		Assert.assertEquals(1000, segmentId2);
		Assert.assertEquals(2, version2);
		Assert.assertEquals(0, recordCount2);
		Assert.assertEquals(1, bio_id_end2 );
		Assert.assertEquals(1, bio_id_start2);
		System.out.print("OKOK");		
	}	

	@Test
	public void testUpdateSegmentAfterDelete() throws SQLException {
		SegmentInfo segInfo = new SegmentInfo();
		segInfo.setSegmentId(1000);		
		segmentRepository.insertSegment(segInfo);
		String selectSql = "select * from segments_info where segment_id = 1000";
		Map<String, Object> result = jdbcTemplate.queryForMap(selectSql);
		long segmentId = (long) result.get("segment_id");
		long version = (long) result.get("version");
		long recordCount = (long) result.get("record_count");
		long bio_id_start = (long) result.get("bio_id_start");	
		long bio_id_end  = (long) result.get("bio_id_end");	
		long dataSize = (long) result.get("binary_length");	
		Assert.assertEquals(1000, segmentId);
		Assert.assertEquals(0, version);
		Assert.assertEquals(0, recordCount);
		Assert.assertEquals(0, bio_id_end );
		Assert.assertEquals(0, bio_id_start);	
		Assert.assertEquals(26, dataSize);
		Assert.assertEquals(0, version);
		segmentRepository.updateSegmentAfterDelete(segInfo);
		Map<String, Object> resultAfterDelete = jdbcTemplate.queryForMap(selectSql);
		long segmentId2 = (long) resultAfterDelete.get("segment_id");
		long version2 = (long) resultAfterDelete.get("version");
		long recordCount2 = (long) resultAfterDelete.get("record_count");
		long bio_id_start2 = (long) resultAfterDelete.get("bio_id_start");	
		long bio_id_end2  = (long) resultAfterDelete.get("bio_id_end");	
		long dataSize2 = (long) resultAfterDelete.get("binary_length");	
		Assert.assertEquals(1000, segmentId2);
		Assert.assertEquals(version + 1, version2);
		Assert.assertEquals(recordCount -1, recordCount2);
		Assert.assertEquals(bio_id_end, bio_id_end2);
		Assert.assertEquals(bio_id_start, bio_id_start2);	
		Assert.assertEquals(dataSize -54-36864, dataSize2);	
	}

	@Test
	public void testSetFaildSegmentVer() throws SQLException {
		SegmentInfo segInfo = new SegmentInfo();
		segInfo.setSegmentId(1000);		
		segmentRepository.insertSegment(segInfo);
		String selectSql = "select * from segments_info where segment_id = 1000";
		Map<String, Object> result = jdbcTemplate.queryForMap(selectSql);
		long segmentId = (long) result.get("segment_id");
		long version = (long) result.get("version");
		long recordCount = (long) result.get("record_count");
		long bio_id_start = (long) result.get("bio_id_start");	
		long bio_id_end  = (long) result.get("bio_id_end");	
		long dataSize = (long) result.get("binary_length");	
		Assert.assertEquals(1000, segmentId);
		Assert.assertEquals(0, version);
		Assert.assertEquals(0, recordCount);
		Assert.assertEquals(0, bio_id_end );
		Assert.assertEquals(0, bio_id_start);	
		Assert.assertEquals(26, dataSize);
		Assert.assertEquals(0, version);
		segInfo.setVersion(-9);
		segmentRepository.setFaildSegmentVer(segInfo);
		String sql = "select version from segments_info where segment_id = 1000";
		Long lastVer = jdbcTemplate.queryForObject(sql, Long.class);
		Assert.assertEquals(-9, lastVer.longValue());
		
	}

	@Test
	public void testSetSuccessSegmentVer() throws SQLException {
		SegmentInfo segInfo = new SegmentInfo();
		segInfo.setSegmentId(1000);		
		segmentRepository.insertSegment(segInfo);
		String selectSql = "select * from segments_info where segment_id = 1000";
		Map<String, Object> result = jdbcTemplate.queryForMap(selectSql);
		long segmentId = (long) result.get("segment_id");
		long version = (long) result.get("version");
		long recordCount = (long) result.get("record_count");
		long bio_id_start = (long) result.get("bio_id_start");	
		long bio_id_end  = (long) result.get("bio_id_end");	
		long dataSize = (long) result.get("binary_length");	
		Assert.assertEquals(1000, segmentId);
		Assert.assertEquals(0, version);
		Assert.assertEquals(0, recordCount);
		Assert.assertEquals(0, bio_id_end );
		Assert.assertEquals(0, bio_id_start);	
		Assert.assertEquals(26, dataSize);
		Assert.assertEquals(0, version);
		segInfo.setVersion(-1);
		segmentRepository.setSuccessSegmentVer(segInfo);
		String sql = "select version from segments_info where segment_id = 1000";
		Long lastVer = jdbcTemplate.queryForObject(sql, Long.class);
		Assert.assertEquals(-1, lastVer.longValue());
	}

	@Test
	public void testUpdateAfterNew() throws SQLException {
		SegmentInfo segInfo = new SegmentInfo();
		segInfo.setSegmentId(1000);		
		segmentRepository.insertSegment(segInfo);		
		segmentRepository.updateAfterNew(-1, 1000);
		String selectSql = "select * from segments_info where segment_id =1000";
		Map<String, Object> result = jdbcTemplate.queryForMap(selectSql);
		long segmentId = (long) result.get("segment_id");
		long version = (long) result.get("version");
		Assert.assertEquals(1000, segmentId);
		Assert.assertEquals(-1, version);
		System.out.print("OKOK");
	}
}
