package com.nec.lmx.agent;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.lmx.agent.lmx.LicenseManager;
import com.nec.lmx.agent.socket.LmxSocketMaster;

/**
 * @author xiazp
 * LmxAgent main class
 */
public class LmxAgent {

	public LmxAgent() {
	}

	private static final Logger logger = LoggerFactory.getLogger(LmxAgent.class);
	private static String PORT;
	private static String MAJOR;
	private static String FEATURE;
	private static String LICENSE_SERVER_URL;	

	/**
	* @param str
	* @return 
	* @throws ParseException
	*/
	public static void main(String[] args) {
		LmxAgent LmxAgent = new LmxAgent();
		LmxAgent.handleParameter(args);
		
		String lmxLibPath = System.getProperty("java.library.path");
		if (lmxLibPath == null || lmxLibPath.isEmpty()) {
			logger.error("lmx lib path is invaild: it's empty!");
			System.exit(1);
		}
		logger.info("lmx lib path: {}", lmxLibPath);
		
		String licenseServerUrl = System.getenv("LMX_LICENSE_PATH");
		if (licenseServerUrl == null || licenseServerUrl.isEmpty()) {
			logger.error("License server url is invaild: it's empty!");
			System.exit(1);
		} 
		
		if (isCheckUrl(licenseServerUrl)) {
			LICENSE_SERVER_URL = licenseServerUrl;
			logger.info("lmx license path: {}", licenseServerUrl);
		} else {
			logger.error("License server url is invaild: {}", licenseServerUrl);
			System.exit(1);
		}
		startAgent();
	}

	/**
	* @param str
	* @return 
	* @throws ParseException
	*/
	private void handleParameter(String[] args) {
		if (args.length < 3) {
			pringUsage();
			System.exit(1);
		}

		for (String one : args) {
			if (one == null || one.isEmpty()) {
				logger.warn(one + "can't be empty!");
				pringUsage();
				System.exit(1);
			}
		}

		if (isMatchNumber(args[0])) {
			PORT = args[0];
			logger.info("********port=" + PORT);
		} else {
			logger.warn("port is not a number it's a string:" + args[0]);
			pringUsage();
			System.exit(1);
		}
		
		if (isMatchNumber(args[1])) {
			MAJOR = args[1];
		} else {
			logger.warn("MAJOR is not a number it's a string or char:" + args[1]);
			pringUsage();
			System.exit(1);
		}
		
		if (isMatchFeature(args[2])) {
			FEATURE = args[2];
		} else {
			logger.warn("FEATURE is not a string ,it contain number at first string:" + args[2]);
			pringUsage();
			System.exit(1);
		}
	}
	
	/**
	* @param str
	* @return 
	* @throws ParseException
	*/
	private static void startAgent() {
		LmxSocketMaster agent = new LmxSocketMaster(Integer.valueOf(PORT));
		new Thread(agent).start();
		LicenseManager fm = LicenseManager.getInstance();
		fm.initLmx(LICENSE_SERVER_URL, FEATURE, Integer.valueOf(MAJOR));
	}

	
	/**
	* @param str
	* @return 
	* @throws ParseException
	*/
	private void pringUsage() {
		String lineSeparater = System.getProperties().getProperty("line.separator");
		StringBuilder sb = new StringBuilder();
		sb.append("Usage for boot LmxAgnet:");
		sb.append(lineSeparater);
		sb.append("java - jar lmx-agent.jar port majorversion feature");
		logger.info(sb.toString());
		sb.delete(0, sb.length());
	}

	/**
	* @param str
	* @return 
	* @throws ParseException
	*/
	private boolean isMatchFeature(String name) {
		Pattern p = Pattern.compile("^[a-zA-Z]*[0-9a-zA-Z]$");
		Matcher m = p.matcher(name);
		return m.matches();		
	}

	/**
	* @param str
	* @return 
	* @throws ParseException
	*/
	private boolean isMatchNumber(String any) {
		if (any == null || any.isEmpty()) {
			return false;
		}
		Pattern p = Pattern.compile("^[0-9]*$");
		Matcher m = p.matcher(any);
		return m.matches();
	}

	/**
	* @param str
	* @return 
	* @throws ParseException
	*/
	private static boolean isCheckUrl(String licenseServerUrl) {
		if (licenseServerUrl == null || licenseServerUrl.isEmpty()) {
			return false;
		}
		int index = licenseServerUrl.indexOf("@");
		if (index < 0) {
			return false;
		} else {
			String firstEx = licenseServerUrl.substring(0, index);
			if (!firstEx.matches("^[0-9]*$")) {
				return false;
			} else {
				String tmp = licenseServerUrl.substring(index + 1, licenseServerUrl.length());
				if (tmp == null || tmp.length() < 1) {
					return false;
				} else {
					return true;
				}
			}
		}
	}
}
