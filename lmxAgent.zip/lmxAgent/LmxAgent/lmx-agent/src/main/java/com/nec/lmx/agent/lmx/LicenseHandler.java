package com.nec.lmx.agent.lmx;

import java.text.ParseException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.lmx.agent.lmx.LicenseManager.IllegalLmxOptions;
import com.xformation.lmx.Lmx;
import com.xformation.lmx.Lmx.HeartbeatCheckoutSuccessCallback;
import com.xformation.lmx.LmxException;
import com.xformation.lmx.LmxStatus;

/*
 * FloatLicenseHandler is called after failed in license server heartbeat.<br/>
 * @author xiazp
 * 
 */
public class LicenseHandler {

	private static Logger logger = LoggerFactory.getLogger(LicenseHandler.class);
	private static final LicenseHandler INSTANCE = new LicenseHandler();

	public static LicenseHandler getInstance() {
		return INSTANCE;
	}

	/**
	* @param str
	* @return 
	* @throws ParseException
	*/
	public void initHeatbeatHandler(Lmx lmx) throws LmxException {
		lmx.setHeartbeatCheckoutSuccessCallback(HeartbeatCheckoutSuccessConsumer);
		lmx.setHeartbeatConnectionLostCallback(heartbeatConnectionLostConsumer);
		lmx.setHeartbeatCheckoutFailureCallback(heartbeatCheckoutFailureConsumer);
		lmx.setHeartbeatRetryFailureCallback(heartbeatRetryFailureConsumer);
		lmx.setHeartbeatExitCallback(heartbeatExitConsumer);
	}

	static Lmx.HeartbeatConnectionLostCallback heartbeatConnectionLostConsumer = (host, port, failedHeartbeats) -> {
		logger.warn("Heartbeat connection is lost. host:{}, port:{}", host, port);		
	};

	static Lmx.HeartbeatCheckoutFailureCallback heartbeatCheckoutFailureConsumer = (featureName, used, status) -> {
		logger.warn("HeartbeatCheckoutFailured. featureName:{}, status:{}", featureName, status.name());
	};

	static Lmx.HeartbeatRetryFailureCallback heartbeatRetryFailureConsumer = (featureName, usedLicCount) -> {
		logger.warn("HeartbeatRetryFailure. feature:{}", featureName);		
	};

	static Lmx.HeartbeatExitCallback heartbeatExitConsumer = () -> {
		// This callback cannot be used by manual heatbeat.
		logger.info("Heartbeat ExitCallback Callback run. clear lmx resource.");
	};

	static HeartbeatCheckoutSuccessCallback HeartbeatCheckoutSuccessConsumer = (featureName, usedLicCount) -> {
		logger.info("HeartbeatCheckoutSuccess. feature:{}", featureName);
		LicenseManager licenseManager = LicenseManager.getInstance();
		try {
			licenseManager.addLicense(licenseManager.createLicense(licenseManager
				.getOptionsFromLmxLicense()));
		} catch (LmxException ex) {
			licenseManager.sendError(ex);
		} catch (IllegalLmxOptions ex) {
			licenseManager.sendError(ex.getStatus(), ex.getMessage());
		}
	};
}
