package com.nec.lmx.agent.lmx;

import java.text.ParseException;
import java.util.Date;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xformation.lmx.Lmx;
import com.xformation.lmx.LmxException;
import com.xformation.lmx.LmxHostidType;
import com.xformation.lmx.LmxSettings;
import com.xformation.lmx.LmxStatus;

/*
 * FloatingLicenseManager:
 * 1. get license info from license server and save it to map.<br/>
 * 2. validate license while inquiry job is coming using license info in map.<br/>
 * 
 * @author xiazp
 */
public class LicenseManager {
	private final ConcurrentHashMap<String, String> licenseMap = new ConcurrentHashMap<>();
	private static Logger logger = LoggerFactory.getLogger(LicenseManager.class);
	
	private static final String VALID = "VALID";
	private static String ERR_MESSAGE = "ERR_MESSAGE";
	private static String ERR_CODE = "ERR_CODE";
	private static final long INTERVAL_OF_HEATBEAT = 30 * 1000;

	private Lmx MM_LMX = new Lmx();	

	private int VER_MAJOR;
	private final int VER_MINOR = 0;
	private final int LMX_OPTION = 1;

	private String floatingServeerPath;
	private String FEATURE_NAME;
	// private ReentrantLock managerLocker;

	private static ScheduledExecutorService heatBeatExecutor = Executors.newSingleThreadScheduledExecutor();
	
	private ConcurrentLinkedQueue<String> queue = new ConcurrentLinkedQueue<>();
	
	private LicenseManager() {
	}

	/**
	* @param str
	* @return 
	* @throws ParseException
	*/
	public void initLmx(String floatingSeverInfo, String featureName, int major) {
		this.floatingServeerPath = floatingSeverInfo;
		this.FEATURE_NAME = featureName;
		this.VER_MAJOR = major;
		checkOutFromServer();
		heatBeatExecutor.scheduleAtFixedRate(new Thread(HeatBeatTask), INTERVAL_OF_HEATBEAT, INTERVAL_OF_HEATBEAT,
				TimeUnit.MILLISECONDS);
		logger.info("Floating license manager intialiized.");
	}

	private static final LicenseManager INSTANCE = new LicenseManager();

	/**
	* @param str
	* @return 
	* @throws ParseException
	*/
	public static LicenseManager getInstance() {
		return INSTANCE;
	}

	/*
	 * @param now the current time 
	 * @throws LicenseException
	 */
	/**
	* @param str
	* @return 
	* @throws ParseException
	*/
	public void checkOutFromServer() {
		logger.info("Check feature from license server.");
		try {
			MM_LMX.init();
			LicenseHandler.getInstance().initHeatbeatHandler(MM_LMX);
			MM_LMX.setOption(LmxSettings.LMX_OPT_LICENSE_PATH, floatingServeerPath);
			MM_LMX.setOption(LmxSettings.LMX_OPT_HOSTID_DISABLED, LmxHostidType.LMX_HOSTID_ALL);
			MM_LMX.checkout(FEATURE_NAME, VER_MAJOR, VER_MINOR, LMX_OPTION);
			addLicense(createLicense(getOptionsFromLmxLicense()));
		} catch (LmxException e) {
			sendError(e);
		} catch (IllegalLmxOptions ex) {
			sendError(ex.getStatus(), ex.getMessage());
		}
	}

	/**
	* @param str
	* @return 
	* @throws ParseException
	*/
	public void sendError(LmxException e) {
		LmxStatus status = e.getErrorCode();
		
		licenseMap.clear();
		
		StringBuilder sb = new StringBuilder();
		sb.append(VALID);
		sb.append("=");
		sb.append("FALSE");
		sb.append(";");
		sb.append(ERR_MESSAGE);
		sb.append("=");
		sb.append(e.getMessage());
		sb.append(";");
		sb.append(ERR_CODE);
		sb.append("=");
		sb.append(e.getErrorCode());
		
		addLicense(sb.toString());
		
		logger.warn("Sent status:{} message:{}", status.toString(), e.getMessage());
	}
	
//	private void sendMajorVerError(String errMsg) {			
//		StringBuilder sb = new StringBuilder();	
//		sb.append(VALID);
//		sb.append("=");
//		sb.append("FALSE");
//		sb.append(";");
//		sb.append(ERR_MESSAGE);
//		sb.append("=");
//		sb.append(errMsg);	
//		sb.append(";");
//		sb.append(ERR_CODE);
//		sb.append("=");
//		sb.append(LmxStatus.LMX_BAD_VERSION);				
//		EventNotifier.getInstance().fireOnError(sb.toString());	
//		logger.info("Sended major verion error message");
//	}	

	/**
	* @param str
	* @return 
	* @throws ParseException
	*/
	public void clearLicenseInfoMap() {
		try {
			MM_LMX = null;
			MM_LMX = new Lmx();
			MM_LMX.init();
			MM_LMX.setOption(LmxSettings.LMX_OPT_LICENSE_PATH, this.floatingServeerPath);
			LicenseHandler.getInstance().initHeatbeatHandler(MM_LMX);
		} catch (LmxException e) {
			logger.error(e.getMessage(), e);
		}
		licenseMap.clear();
	}

	/**
	* @param str
	* @return 
	* @throws ParseException
	*/
	public void cleanAllLmxResource() {
		logger.info("Clear all resource at:" + new Date());
		heatBeatExecutor.shutdown();
		licenseMap.clear();
		//MM_LMX.checkin(FEATURE_NAME, Lmx.LMX_ALL_LICENSES);
		MM_LMX.free();
	}

	/**
	* @param str
	* @return 
	* @throws ParseException
	*/
	private void lmxHeartbeat() {
		logger.debug("LMX heatbeat at:" + new Date());
		try {
			MM_LMX.heartbeat(FEATURE_NAME);
			logger.debug("Heartbeat with {} succeeded.", FEATURE_NAME);
		} catch (LmxException e) {
			logger.error(e.getMessage(), e);
			
			checkOutFromServer();
		}
	}
	
	private Runnable HeatBeatTask = () -> {
		lmxHeartbeat();
	};
	
	public String pollLastLicense() {
		String license = null;
		while(!queue.isEmpty()) {
			license = queue.poll();
		}
		return license;
	}
	
	public void addLicense(String license) {
		queue.add(license);
	}
	
	public String createLicense(String option) {		
		String vaild = licenseMap.getOrDefault(VALID, "FALSE");
		StringBuilder sb = new StringBuilder();		
		sb.append(option).append(";").append(VALID).append("=").append(vaild);
		return sb.toString();
	}
	
	public String getOptionsFromLmxLicense() throws LmxException, IllegalLmxOptions {
		String licenseInfo = MM_LMX.getFeatureInfo(FEATURE_NAME).getOptions();
		if (Objects.isNull(licenseInfo) || licenseInfo.isEmpty()) {
			throw new IllegalLmxOptions(LmxStatus.LMX_UNKNOWN_ERROR, "Illegal license options.");
		}
		licenseMap.clear();
		licenseMap.putIfAbsent(FEATURE_NAME, licenseInfo);
		licenseMap.putIfAbsent(VALID, "TRUE");
		return licenseMap.get(FEATURE_NAME);
	}
	
	public void sendError(LmxStatus status, String message) {
		licenseMap.clear();
		
		StringBuilder sb = new StringBuilder();
		sb.append(VALID).append("=").append("FALSE").append(";").append(ERR_MESSAGE).append("=")
			.append(message).append(";").append(ERR_CODE).append("=").append(status.toString());
		addLicense(sb.toString());
		
		logger.warn("Sent status:{} message:{}", status.toString(), message);
	}
	
	@SuppressWarnings("serial")
	class IllegalLmxOptions extends Exception {
		private LmxStatus status;
		
		public IllegalLmxOptions(LmxStatus status, String message) {
			super(message);
			this.status = status;
		}
		
		public LmxStatus getStatus() {
			return status;
		}
	}
}
