
spool build_bison.log

WHENEVER OSERROR  EXIT FAILURE;
WHENEVER SQLERROR EXIT SQL.SQLCODE;

prompt
prompt Creating BISON database objects...
prompt

prompt Creating tables ...
@@ddl/create_bison_table.sql

prompt Creating sequences ...
@@ddl/create_bison_seq.sql

prompt Creating types ...
@@ddl/create_bison_typ.sql

prompt Createing index ...
@@ddl/create_bison_idx.sql

prompt Creating packages ...
@@ddl/create_bison_pks.sql

prompt Creating package bodys ...
@@ddl/create_bison_pkb.sql

prompt
prompt Checking for any invalid objects after installation...
prompt
SELECT Count(*) as "Number of invalid objects" FROM user_objects WHERE status != 'VALID';

prompt
prompt DONE.
prompt

exit success;




