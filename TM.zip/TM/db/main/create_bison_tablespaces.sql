
spool create_tablespaces.log

WHENEVER OSERROR  EXIT FAILURE;
WHENEVER SQLERROR EXIT SQL.SQLCODE;

accept bison_person_bio_diskgroup char prompt 'Enter ASM disk group to create PERSON_BIO tablespaces (need heading plus):';
accept bison_ssdgroup char prompt 'Enter ASM ssd group to create BISON tablespace except PERSON_BIO tablespaces (need heading plus):';

@ddl/create_bison_personbio_tablespaces.sql
@ddl/create_bison_system_tablespaces.sql

exit success;
