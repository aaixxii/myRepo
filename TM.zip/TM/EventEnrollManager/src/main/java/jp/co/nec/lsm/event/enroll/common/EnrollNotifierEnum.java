package jp.co.nec.lsm.event.enroll.common;

/**
 * @author mozj
 */
public enum EnrollNotifierEnum {

	// notifier: Enroll Job Poll Bean
	EnrollJobPollBean("TME_EnrollJobPollBean"),

	// notifier: Enroll Status Manager Bean
	EnrollStatusManagerBean("TME_EnrollStatusManagerBean"),

	// notifier: TME Report service
	EnrollReportService("TME_EnrollReportservice"),

	// notifier: TME Enroll Update Batch Job Service
	EnrollUpdateBatchJobService("TME_EnrollUpdateBatchJobService"),

	// notifier: TME Enroll Segment Sync Service
	EnrollSegmentSyncService("TME_EnrollSegmentSyncService"),

	// notifier: TME Biometrics Deletion Service
	TemplateManagerBean("TME_TemplateManagerBean"),

	// notifier: TME System Initialization service
	EnrollSystemInitializationBean("TME_EnrollSystemInitializationBean"),

	EnrollDeadLevelQueueService("TME_EnrollDeadLevelQueueService");

	private String detailMessage;

	public String getDetailMessage() {
		return detailMessage;
	}

	public void setDetailMessage(String detailMessage) {
		this.detailMessage = detailMessage;
	}

	private EnrollNotifierEnum(String detailMessage) {
		this.detailMessage = detailMessage;
	}
}
