package jp.co.nec.lsm.event.enroll.common;

/**
 * @author mozj
 */
public class EventEnrollRuntimeException extends RuntimeException {

	private static final long serialVersionUID = 7157356057817916135L;

	public EventEnrollRuntimeException(String message) {
		super(message);
	}

	public EventEnrollRuntimeException(String message, Throwable cause) {
		super(message, cause);
	}

	public EventEnrollRuntimeException(Throwable cause) {
		super(cause);
	}

}
