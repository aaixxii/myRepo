package jp.co.nec.lsm.event.enroll.common;

/**
 * @author mozj
 */
public class EnrollEventConstants {
	public static final String JMS_OBJECT_PROPERTY = "JMS_RECEIVER";
	public static final int JBOSS_DEFAULT_JNDI_PORT = 1099;
	public static final String EMPTY_STRING_VALUE = "";
	public static final String DEFAULT_IP_ADDRESS = "127.0.0.1";
}
