package jp.co.nec.lsm.event.enroll;

import jp.co.nec.lsm.event.Event;
import jp.co.nec.lsm.event.enroll.common.EnrollEventConstants;
import jp.co.nec.lsm.event.enroll.common.EnrollNotifierEnum;
import jp.co.nec.lsm.event.enroll.common.EnrollReceiverEnum;

/**
 * @author liuyq <br>
 */
public abstract class EnrollAbstractEvent implements Event {

	/**
     * 
     */
	private static final long serialVersionUID = 1L;
	private String ipAddress = EnrollEventConstants.DEFAULT_IP_ADDRESS;
	private long batchJobId;
	private EnrollNotifierEnum enrollNotifier; // from
	private EnrollReceiverEnum enrollReceiver; // send to

	@Override
	public String getMessageSelector() {
		return getEnrollReceiver().name();
	}

	public String getIpAddress() {
		if (null == ipAddress || "".equals(ipAddress)) {
			ipAddress = EnrollEventConstants.DEFAULT_IP_ADDRESS;
		}
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	@Override
	public String[] getTraceMessage() {
		if (enrollNotifier == null || enrollReceiver == null)
			return null;
		String[] traceMessage = new String[] { "NOTIFIER",
				enrollNotifier.getDetailMessage(), "RECEIVER",
				enrollReceiver.getDetailMessage() };
		return traceMessage;
	}

	@Override
	public long getBatchJobId() {
		return batchJobId;
	}

	public void setBatchJobId(long batchJobId) {
		this.batchJobId = batchJobId;
	}

	public EnrollReceiverEnum getEnrollReceiver() {
		return enrollReceiver;
	}

	public void setEnrollReceiver(EnrollReceiverEnum receiver) {
		this.enrollReceiver = receiver;
	}

	public EnrollNotifierEnum getEnrollNotifier() {
		return enrollNotifier;
	}

	public void setEnrollNotifier(EnrollNotifierEnum notify) {
		this.enrollNotifier = notify;
	}
}
