package jp.co.nec.lsm.tma.servlet.debug;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tm.common.communication.SearchJobInfo;
import jp.co.nec.lsm.tm.common.communication.SegmentMap;
import jp.co.nec.lsm.tm.common.servlet.AbstractTMServlet;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;

/**
 * @author dongqk <br>
 * 
 */
public class TMABatchSegmentJobMapsServlet extends AbstractTMServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6910259607374020249L;
	private final String br = System.getProperty("line.separator");
	private final String spaces = "    ";

	/**
	 * 
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String str = printBatchSegmentJobMap(BatchSegmentJobManager
				.getInstance().getBatchSegmentJobMaps());
		resp.getWriter().write(str);
		resp.getWriter().close();
	}

	/**
	 * 
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req, resp);
	}

	/**
	 * 
	 * @param path
	 */
	private String printBatchSegmentJobMap(
			Map<Long, BatchSegmentJobMap> batchSJobMap) {

		StringBuffer buffer = new StringBuffer();

		List<Long> batchJobIdList = new ArrayList<Long>(batchSJobMap.keySet());

		Collections.sort(batchJobIdList, new BatchJobIdsComparator());

		buffer = printSeparateLine(buffer);
		for (int j = 0, size = batchJobIdList.size(); j < size; j++) {

			BatchSegmentJobMap b = batchSJobMap.get(batchJobIdList.get(j));
			if (null == b) {
				return "";
			}

			buffer.append("BatchJobId: ");
			buffer.append(b.getbJobId());
			buffer.append(spaces);
			buffer.append("BatchJobStatus: ");
			buffer.append(b.getBatchJobStatus());
			buffer.append(spaces);
			buffer.append("FailureCount: ");
			buffer.append(b.getFailureCount());
			buffer.append(spaces);
			buffer.append("StartTime: ");
			buffer.append(format(b.getStartTime()));
			buffer.append(spaces);
			buffer.append("TimeOut: ");
			buffer.append(b.getTimeOut());
			buffer.append(br);

			buffer = printMiddleSeparateLine(buffer);

			for (SearchJobInfo i : b.getSearchJobInfos()) {
				buffer = appendSearchJobInfo(buffer, i);
			}

			buffer = printMiddleSeparateLine(buffer);

			for (Map.Entry<Long, SegmentMap> m : b.getSegmentMaps().entrySet()) {
				SegmentMap s = m.getValue();
				buffer = appendSegmentMap(buffer, s);
			}
			buffer = printSeparateLine(buffer);
		}
		return buffer.toString();
	}

	private StringBuffer appendSegmentMap(StringBuffer buffer, SegmentMap s) {
		buffer.append("SegmentId: ");
		buffer.append(s.getSegmentId());
		buffer.append(spaces);
		buffer.append("bSJobStatus: ");
		buffer.append(s.getBatchSegmentJobStatus());
		buffer.append(spaces);
		buffer.append("MuId: ");
		buffer.append(s.getMuId());
		buffer.append(spaces);
		buffer.append("FailureCount: ");
		buffer.append(s.getFailureCount());
		buffer.append(spaces);
		buffer.append("TargetVersion: ");
		buffer.append(s.getTargetVersion());
		buffer.append(spaces);
		buffer.append("ProcessStartTS: ");
		buffer.append(format(s.getProcessStartTS()));
		buffer.append(spaces);
		buffer.append("ProcessEndTS: ");
		buffer.append(format(s.getProcessEndTS()));
		buffer.append(br);

		return buffer;
	}

	private StringBuffer appendSearchJobInfo(StringBuffer buffer,
			SearchJobInfo i) {
		buffer.append("JobIndex: ").append(i.getJobId()).append(spaces);
		buffer.append("ReferenceId: ").append(i.getReferenceId())
				.append(spaces);
		buffer.append("RequestId: ").append(i.getRequestId()).append(spaces);
		buffer.append("ReturnCode: ").append(i.getReturnCode().toString())
				.append(spaces);
		buffer.append("MaxCandidate: ").append(i.getMaxCandidate());
		buffer.append(br);
		return buffer;
	}

	private StringBuffer printSeparateLine(StringBuffer buffer) {
		buffer.append("**********************************");
		buffer.append(br);
		return buffer;
	}

	private StringBuffer printMiddleSeparateLine(StringBuffer buffer) {
		buffer.append("----------------------------------------");
		buffer.append(br);
		return buffer;
	}

	private String format(Date date) {
		if (null == date) {
			return "";
		}
		return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(date);
	}

	class BatchJobIdsComparator implements Comparator<Long> {
		@Override
		public int compare(Long c1, Long c2) {
			return c1 > c2 ? 1 : 0;
		}
	}
}
