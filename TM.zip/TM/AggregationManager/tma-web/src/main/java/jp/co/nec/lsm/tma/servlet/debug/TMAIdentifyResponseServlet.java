package jp.co.nec.lsm.tma.servlet.debug;

import java.io.IOException;
import java.util.Collection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.lsm.tm.common.servlet.AbstractTMServlet;
import jp.co.nec.lsm.tm.protocolbuffer.identify.IdentifyResultRequestProto.IdentifyResultRequest;
import jp.co.nec.lsm.tma.core.jobs.IdentifyResponseQueue;

import com.acc.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.acc.proto.protobuf.BusinessMessage.CPBCandidate;
import com.acc.proto.protobuf.BusinessMessage.CPBDataBlock;
import com.acc.proto.protobuf.BusinessMessage.CPBProcessInfo;
import com.acc.proto.protobuf.BusinessMessage.CPBRequestParameter;
import com.acc.proto.protobuf.BusinessMessage.CPBResponse;
import com.acc.proto.protobuf.BusinessMessage.CPBResponseAttribute;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;

/**
 * @author dongqk <br>
 * 
 */
public class TMAIdentifyResponseServlet extends AbstractTMServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3829960985785189317L;

	private final String br = System.getProperty("line.separator");
	private final String spaces = "    ";

	/**
	 * 
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		Collection<IdentifyResultRequest> responses = IdentifyResponseQueue
				.getInstance().getAll();

		StringBuilder sb = new StringBuilder();
		for (IdentifyResultRequest response : responses) {
			sb.append(printIdentifyResponse(response));
			sb.append(br);
		}
		resp.getWriter().write(sb.toString());
		resp.getWriter().close();
	}

	/**
	 * 
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req, resp);
	}

	/**
	 * 
	 * @param path
	 */
	private String printIdentifyResponse(IdentifyResultRequest response) {
		StringBuffer buffer = new StringBuffer();

		List<ByteString> jobInfos = response.getBusinessMessageList();

		buffer.append("BatchJobId: ");
		buffer.append(response.getBatchJobId());
		buffer.append(spaces);
		buffer.append("BatchType: ");
		buffer.append(response.getType());
		buffer.append(br);

		try {
			for (int i = 0, size = jobInfos.size(); i < size; i++) {
				CPBBusinessMessage b = CPBBusinessMessage.parseFrom(jobInfos.get(i));
				if (null == b) {
					return "";
				}
				buffer = printMiddleSeparateLine(buffer);
				buffer = appendSearchJobResult(buffer, b);
			}
			buffer = printSeparateLine(buffer);
		} catch (InvalidProtocolBufferException e) {
			e.printStackTrace();
		}
		return buffer.toString();
	}

	private StringBuffer appendSearchJobResult(StringBuffer buffer,
			CPBBusinessMessage b) {
		buffer.append("RequestId: ");
		buffer.append(b.getRequest().getRequestId());
		buffer.append(spaces);
		buffer.append("EnrollmentId: ");
		buffer.append(b.getRequest().getEnrollmentId());
		buffer.append(spaces);
		buffer.append("RequestType: ");
		buffer.append(b.getRequest().getRequestType());
		buffer.append(spaces);
		
		for (CPBRequestParameter param : b.getRequest().getRequestParametersList()) {
			buffer.append(param.getParameterName() + ": ");
			buffer.append(param.getParameterValue());
			buffer.append(spaces);
		}
		buffer.append(br);
		
		CPBResponse response = b.getResponse();
		
		buffer.append("Status: ");
		buffer.append(response.getStatus());
		buffer.append(spaces);
		buffer.append("ErrorMessage: ");
		buffer.append(response.getErrorMessage());
		buffer.append(br);
		
		for (CPBResponseAttribute attr : response.getResponseAttributesList()) {
			buffer.append(attr.getAttributeName() + ": ");
			buffer.append(attr.getAttributeValue());
			buffer.append(spaces);
		}
		
		buffer.append(br);
		buffer = printMiddleSeparateLine(buffer);
		
		CPBDataBlock dataBlock = b.getDataBlock();
		buffer.append("More: ");
		buffer.append(dataBlock.getCandidateList().getMore());
		buffer.append(br);
		
		appendCandidate(buffer, dataBlock.getCandidateList().getCandidatesList());
		
		buffer = printMiddleSeparateLine(buffer);
		
		for (CPBProcessInfo p : dataBlock.getProcessMetric().getProcessMetricList()) {
			buffer.append("ProcessName: ");
			buffer.append(p.getProcessName());
			buffer.append(spaces);
			buffer.append("StartTime: ");
			buffer.append(p.getStartTime());
			buffer.append(spaces);
			buffer.append("EndTime: ");
			buffer.append(p.getEndTime());
			buffer.append(spaces);
		}
		buffer.append(br);
		return buffer;
	}

	private StringBuffer appendCandidate(StringBuffer buffer, List<CPBCandidate> cs) {
		for (CPBCandidate c : cs) {
			buffer.append("EnrollmentId: ");
			buffer.append(c.getEnrollmentId());
			buffer.append(spaces);
			buffer.append("ScaledScore: ");
			buffer.append(c.getScaledScore());
			buffer.append(spaces);
			buffer.append("MatchedFingerPattern: ");
			buffer.append(c.getMatchedFingerPattern());
			buffer.append(br);
			
			buffer = printMiddleSeparateLine(buffer);
		}
		buffer.append(br);
		return buffer;
	}

	private StringBuffer printSeparateLine(StringBuffer buffer) {
		buffer.append("**********************************");
		buffer.append(br);
		return buffer;
	}

	private StringBuffer printMiddleSeparateLine(StringBuffer buffer) {
		buffer.append("----------------------------------------");
		buffer.append(br);
		return buffer;
	}

}
