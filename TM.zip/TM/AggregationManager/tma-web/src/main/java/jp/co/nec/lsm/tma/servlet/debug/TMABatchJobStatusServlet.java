package jp.co.nec.lsm.tma.servlet.debug;

import java.io.IOException;
import java.util.Comparator;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tm.common.communication.SegmentMap;
import jp.co.nec.lsm.tm.common.servlet.AbstractTMServlet;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyJobResult;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;

/**
 * @author dongqk <br>
 * 
 */
public class TMABatchJobStatusServlet extends AbstractTMServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8383145556418812766L;

	private final String br = System.getProperty("line.separator");

	/**
	 * 
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String str = printBatchSegmentJobMap(BatchSegmentJobManager
				.getInstance().getBatchSegmentJobMaps());
		resp.getWriter().write(str);
		resp.getWriter().close();
	}

	/**
	 * 
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req, resp);
	}

	/**
	 * 
	 * @param path
	 */
	private String printBatchSegmentJobMap(
			Map<Long, BatchSegmentJobMap> batchSJobMap) {

		StringBuffer bSegmentAllBuffer = new StringBuffer();
		//
		Map<Long, SegmentMap> segmentMaps;

		bSegmentAllBuffer = printSeparateLine(bSegmentAllBuffer);
		for (Entry<Long, BatchSegmentJobMap> e : batchSJobMap.entrySet()) {
			BatchSegmentJobMap bsJobMap = e.getValue();
			if (null == bsJobMap) {
				return "";
			}
			segmentMaps = bsJobMap.getSegmentMaps();
			for (Map.Entry<Long, SegmentMap> e2 : segmentMaps.entrySet()) {
				bSegmentAllBuffer.append("BatchJobId: ");
				bSegmentAllBuffer.append(String.format("%1$10d", e.getKey()));
				bSegmentAllBuffer.append("\t|\tSegmentId: ");
				bSegmentAllBuffer.append(String.format("%1$10d", e2.getKey()));
				bSegmentAllBuffer.append("\t|\tSegmentStatus: ");
				bSegmentAllBuffer.append(String.format("%1$16s", e2.getValue()
						.getBatchSegmentJobStatus().name()));
				bSegmentAllBuffer.append(br);
			}
			bSegmentAllBuffer = printMiddleSeparateLine(bSegmentAllBuffer);

			printReturnCode(bsJobMap.getbJobId(), bSegmentAllBuffer);

			bSegmentAllBuffer = printSeparateLine(bSegmentAllBuffer);

			bSegmentAllBuffer.append(br);
		}

		return bSegmentAllBuffer.toString();
	}

	private StringBuffer printSeparateLine(StringBuffer buffer) {
		buffer
				.append("********************************************************************************************************");
		buffer.append(br);
		return buffer;
	}

	private StringBuffer printMiddleSeparateLine(StringBuffer buffer) {
		buffer
				.append("-----------------------------------------------------------------------------------------------------------");
		buffer.append(br);
		return buffer;
	}

	private void printReturnCode(long batchJobId, StringBuffer buffer) {
		final String spaces = "    ";

		IdentifyResult result = BatchSegmentJobManager.getInstance()
				.getIdentifyResult(batchJobId);
		int i = 0;
		for (IdentifyJobResult r : result.getSearchJobResults().values()) {
			i++;
			buffer.append("JobIndex: ");
			buffer.append(String.format("%1$3d", r.getJobIndex()));
			buffer.append(spaces);
			buffer.append("ReturnCode: ");
			buffer.append(r.getReturnCode());
			if (i % 2 == 0) {
				buffer.append(br);
			} else {
				buffer.append(spaces);
			}
		}
	}

	/**
	 * according to SegmentId sort, ASC
	 * 
	 */
	class SegmentComparator implements Comparator<Long> {
		@Override
		public int compare(Long c1, Long c2) {
			return c1 > c2 ? 1 : 0;
		}
	}

	/**
	 * according to Entry's key(batchJobId) sort, ASC
	 * 
	 */
	class ResultMapComparator implements
			Comparator<Entry<Long, IdentifyResult>> {
		@Override
		public int compare(Entry<Long, IdentifyResult> o1,
				Entry<Long, IdentifyResult> o2) {
			return o1.getKey() > o2.getKey() ? 1 : 0;
		}
	}

}
