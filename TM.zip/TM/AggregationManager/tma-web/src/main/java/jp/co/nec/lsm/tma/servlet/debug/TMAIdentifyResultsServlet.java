package jp.co.nec.lsm.tma.servlet.debug;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto.Candidate;
import jp.co.nec.lsm.tm.common.servlet.AbstractTMServlet;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyJobResult;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;

import com.acc.proto.protobuf.BusinessMessage.CPBScore;

/**
 * @author dongqk <br>
 * 
 */
public class TMAIdentifyResultsServlet extends AbstractTMServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = -778500736633209189L;

	private final String br = System.getProperty("line.separator");
	private final String spaces = "    ";

	/**
	 * 
	 */
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String str = printIdentifyResultMap(BatchSegmentJobManager
				.getInstance().getIdentifyResults());
		resp.getWriter().write(str);
		resp.getWriter().close();
	}

	/**
	 * 
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req, resp);
	}

	/**
	 * 
	 * @param path
	 */
	private String printIdentifyResultMap(
			Map<Long, IdentifyResult> identifyResultMap) {

		StringBuffer buffer = new StringBuffer();

		List<Long> batchJobIdList = new ArrayList<Long>(identifyResultMap
				.keySet());

		Collections.sort(batchJobIdList, new BatchJobIdsComparator());

		buffer = printSeparateLine(buffer);
		for (int j = 0, size = batchJobIdList.size(); j < size; j++) {
			IdentifyResult result = identifyResultMap
					.get(batchJobIdList.get(j));
			if (null == result) {
				return "";
			}

			buffer.append("BatchJobId: ");
			buffer.append(result.getBatchJobId());
			buffer.append(br);
			buffer.append("SegmentIds: ");
			for (long segmentId : result.getSegmentIds()) {
				buffer.append(segmentId);
				buffer.append(", ");
			}

			buffer.append(br);
			buffer = printMiddleSeparateLine(buffer);

			for (IdentifyJobResult r : result.getSearchJobResults().values()) {
				buffer = appendIdentifyJobResult(buffer, r);
			}
			buffer = printSeparateLine(buffer);
		}
		return buffer.toString();
	}

	private StringBuffer appendIdentifyJobResult(StringBuffer buffer,
			IdentifyJobResult r) {
		buffer.append("JobIndex: ");
		buffer.append(r.getJobIndex());
		buffer.append(spaces);
		buffer.append("RequestId: ");
		buffer.append(r.getRequestId());
		buffer.append(spaces);
		buffer.append("ReferenceId: ");
		buffer.append(r.getReferenceId());
		buffer.append(spaces);
		buffer.append("MaxCandidate: ");
		buffer.append(r.getMaxCandidate());
		buffer.append(spaces);
		buffer.append(br);
		buffer.append("ReturnCode: ");
		buffer.append(r.getReturnCode());
		buffer.append(spaces);
		buffer.append("isOverMaxCandidates: ");
		buffer.append(r.isOverMaxCandidates());

		buffer.append(br);
		buffer.append(spaces);
		buffer = printMiddleSeparateLine(buffer);

		for (Candidate c : r.getCandidates()) {
			buffer = appendCandidate(buffer, c);
		}
		return buffer;
	}

	private StringBuffer appendCandidate(StringBuffer buffer, Candidate c) {
		buffer.append("\tScaledScore: ");
		buffer.append(c.getScaledScore());
		buffer.append(spaces);
		buffer.append("ReferenceId: ");
		buffer.append(c.getReferenceId());
		buffer.append(br);

		List<CPBScore> scoreList = c.getModalScore().getScoreList();
		for (CPBScore score : scoreList) {
			buffer.append(spaces);
			buffer.append("ModalScore-" + score.getModalityType() + "Score: ");
			buffer.append(score.getValue());
			buffer.append(spaces);
			buffer.append("ModalitySubType: ");
			buffer.append(score.getModalitySubType());
			buffer.append(spaces);
			buffer.append("BufferValue1: ");
			buffer.append(score.getBufferValue1());
			buffer.append(spaces);
			buffer.append(br);
		}
		return buffer;
	}

	private StringBuffer printSeparateLine(StringBuffer buffer) {
		buffer.append("**********************************");
		buffer.append(br);
		return buffer;
	}

	private StringBuffer printMiddleSeparateLine(StringBuffer buffer) {
		buffer.append("----------------------------------------");
		buffer.append(br);
		return buffer;
	}

	class BatchJobIdsComparator implements Comparator<Long> {
		@Override
		public int compare(Long c1, Long c2) {
			return c1 > c2 ? 1 : 0;
		}
	}

}
