/**
 * 
 */
package jp.co.nec.lsm.tma.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import jp.co.nec.lsm.tm.common.constants.JNDIConstants;
import jp.co.nec.lsm.tm.common.util.ServiceLocator;
import jp.co.nec.lsm.tma.service.sessionbean.AggregationSystemDownManagerLocal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author dongqk <br>
 * 
 */
public class ShutDownManagerListener implements ServletContextListener {
	private static final Logger log = LoggerFactory
			.getLogger(ShutDownManagerListener.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @seejavax.servlet.ServletContextListener#contextDestroyed(javax.servlet.
	 * ServletContextEvent)
	 */
	public void contextDestroyed(ServletContextEvent sce) {
		printLogMessage("contextDestroyed called, TMA shutdown.");

		AggregationSystemDownManagerLocal asdm = ServiceLocator.getLookUpJndiObject(
				JNDIConstants.TMA_BEAN_SYSTEMSHUTDOWN, AggregationSystemDownManagerLocal.class);

		asdm.shutdown();
		printLogMessage("TMA system successfuly shutdown.");

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.servlet.ServletContextListener#contextInitialized(javax.servlet
	 * .ServletContextEvent)
	 */
	public void contextInitialized(ServletContextEvent sce) {
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @param objects
	 */
	private static void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}

}
