package jp.co.nec.lsm.tma.util;

import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto;
import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto.IdentifyJobResultRequest;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyJobResult;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;

public final class TMAUtilSwitchWeb {

	/**
	 * switch IdentifyResult to IdentifyResultRequest
	 * 
	 * @param identifyResult
	 * @return
	 */
	public final static IdentifyJobResultRequest switchIdentifyResult(IdentifyResult identifyResult) {
		IdentifyJobResultRequest.Builder jobResultRequestBuilder = IdentifyJobResultRequest.newBuilder();
		jobResultRequestBuilder.setGmvId(1000);
		jobResultRequestBuilder.setReadCount(0L);
		jobResultRequestBuilder.setBatchJobId(identifyResult.getBatchJobId()).addAllSegmentId(
				identifyResult.getSegmentIds());

		IdentifyJobResultRequestProto.IdentifyJobResult.Builder jobResultBuilder;

		for (IdentifyJobResult jobResult : identifyResult.getSearchJobResults().values()) {
			if(null != jobResult) {
				jobResultBuilder = IdentifyJobResultRequestProto.IdentifyJobResult.newBuilder();

				jobResultBuilder.setJobIndex(jobResult.getJobIndex()).setReturnCode(jobResult.getReturnCode())
						.addAllCandidate(jobResult.getCandidates());

				jobResultRequestBuilder.addIdentifyJobResult(jobResultBuilder);
			}
		}
		return jobResultRequestBuilder.build();
	}
}
