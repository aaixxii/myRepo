package jp.co.nec.lsm.tma.receiver;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.MessageListener;

import jp.co.nec.lsm.event.Event;
import jp.co.nec.lsm.event.identify.IdentifyMergerJobDoneEvent;
import jp.co.nec.lsm.event.receiver.AbstractEventReceiver;
import jp.co.nec.lsm.tm.common.constants.DeployName;
import jp.co.nec.lsm.tm.common.constants.JNDIConstants;
import jp.co.nec.lsm.tm.common.util.ServiceLocator;
import jp.co.nec.lsm.tma.sessionbean.api.AggregationDeadLevelQueueLocal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author jimy <br>
 * 
 */
@MessageDriven(activationConfig = {
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
		@ActivationConfigProperty(propertyName = "destination", propertyValue = JNDIConstants.AGGREGATION_DLQ_QUEUE) })
public class AggregationDLQEventReceiver extends AbstractEventReceiver
		implements MessageListener {

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(AggregationDLQEventReceiver.class);

	@Override
	protected void dispatchEvent(Event event) {
		// look up the service session bean
		if (!(event instanceof IdentifyMergerJobDoneEvent)) {
			log.error("event is not a instance of IdentifyMergerJobDoneEvent.");
			return;
		}

		String jndiName = DeployName.AGGREGATION_EARFILE + JNDIConstants.SPLIT
				+ JNDIConstants.dLQTmaServiceBeanName + JNDIConstants.LOCAL;

		AggregationDeadLevelQueueLocal dLQService = ServiceLocator
				.getLookUpJndiObject(jndiName,
						AggregationDeadLevelQueueLocal.class);
		dLQService.receiveEventFromDLQ(event.getBatchJobId());
	}
}
