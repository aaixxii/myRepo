package jp.co.nec.lsm.tma.service.sessionbean;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.management.MBeanServer;
import javax.management.ObjectName;

import jp.co.nec.lsm.tm.common.constants.JNDIConstants;
import jp.co.nec.lsm.tm.common.constants.QueueNames;
import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tm.common.util.SafeCloseUtil;
import jp.co.nec.lsm.tm.common.util.ServiceLocator;
import jp.co.nec.lsm.tma.db.dao.AggregationSystemConfigDaoLocal;
import jp.co.nec.lsm.tma.db.dao.AggregationTransactionManagerDaoLocal;
import jp.co.nec.lsm.tma.exception.AggregationRuntimeException;

import org.jboss.mx.util.MBeanServerLocator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author dongqk <br>
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AggregationInitializationBean implements
		AggregationInitializationLocal {

	private static Logger log = LoggerFactory
			.getLogger(AggregationInitializationBean.class);

	@Resource(mappedName = "java:/JmsXA")
	private ConnectionFactory jmsConnectionFactory;
	private Queue queue;
	@EJB
	private AggregationSystemConfigDaoLocal systemConfig;

	@EJB
	private AggregationTransactionManagerDaoLocal aggregationManagerDao;

	/**
	 * constructor
	 */
	public AggregationInitializationBean() {
	}

	/**
	 * init after construct is called
	 */
	@PostConstruct
	public void init() {
		queue = ServiceLocator.getLookUpJndiObject(
				JNDIConstants.AGGREGATION_STARTTIMER_QUEUE, Queue.class);
	}

	/**
	 * start timer
	 * 
	 * @throws JMSException
	 */
	private void startTimer() throws JMSException {
		printLogMessage("Sending Message to TimerManagerMDB");

		Connection connect = null;
		Session session = null;
		MessageProducer producer = null;
		try {
			connect = jmsConnectionFactory.createConnection();
			session = connect.createSession(false, Session.DUPS_OK_ACKNOWLEDGE);
			producer = session.createProducer(queue);
			Message msg = session.createTextMessage();
			producer.send(msg);
		} finally {
			SafeCloseUtil.close(producer);
			SafeCloseUtil.close(session);
			SafeCloseUtil.close(connect);
		}
	}

	/**
	 * 
	 * @param queueName
	 */
	private void removeJmsMessage(String queueName) {
		try {
			MBeanServer mBeanServer = MBeanServerLocator.locateJBoss();
			StringBuilder sb = new StringBuilder();
			sb.append("org.hornetq:module=JMS,name=\"");
			sb.append(queueName);
			sb.append("\",type=Queue");
			ObjectName target = new ObjectName(sb.toString());

			String[] sig = new String[] { "java.lang.String" };
			mBeanServer.invoke(target, "removeMessages", new String[] { "" },
					sig);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}

	/**
	 * initialize Aggregation start timer, sendEnter to TMI
	 */
	@Override
	public void initializeAggregation() {
		printLogMessage("start public function initializeAggregation()...");

		// set start time in TRANSACTION_MANAGERS
		setStartupTime();

		// read properties from file write into DB
		systemConfig.writeAllMissingProperties();

		// remove identify_queue_event message
		removeJmsMessage(QueueNames.AGGREGATION_QUEUE_NAME);

		// remove timer-startup-queue message
		removeJmsMessage(QueueNames.AGGREGATION_STARTTIMER_QUEUE_NAME);

		// remove identify_DLQ_event message
		removeJmsMessage(QueueNames.AGGREGATION_DLQ_QUEUE_NAME);

		try {
			startTimer();
		} catch (JMSException e) {
			log.error("start Timer error..");
			throw new AggregationRuntimeException(
					"Failed to init because of JMSException", e);
		}

		// out put the TMA System Initialization
		if (log.isInfoEnabled()) {
			log.info(InfoLogger.infoOutput("SystemInitializationBean",
					"initialize", "DETAIL",
					"TMA System Initialization successfully.."));
		}

		printLogMessage("end public function initializeAggregation()...");
	}

	/**
	 * insert MM startUpTime into MATCH_MANAGER_TIMES table.
	 */
	private void setStartupTime() {
		aggregationManagerDao.setStartupTime();
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @param objects
	 */
	private static void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}
}
