package jp.co.nec.lsm.tma.service.sessionbean;

import javax.ejb.Stateless;

import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;
import jp.co.nec.lsm.tma.sessionbean.api.AggregationDeadLevelQueueLocal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Stateless
public class AggregationDeadLevelQueueService implements AggregationDeadLevelQueueLocal {

	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(AggregationDeadLevelQueueService.class);

	@Override
	public void receiveEventFromDLQ(long batchJobID) {
		BatchSegmentJobManager queueManager = BatchSegmentJobManager
				.getInstance();
		queueManager.remove(batchJobID);

		if (log.isInfoEnabled()) {
			log.info("receive event from dead letter queue, remove this "
					+ "batch job {} from memory.", batchJobID);
		}
	}
}
