package jp.co.nec.lsm.tma.core.clientapi.response;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectCollection;

import java.util.ArrayList;
import java.util.List;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto.Candidate;
import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tm.common.constants.BusinessMessageConstants;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tm.protocolbuffer.identify.IdentifyResultRequestProto.IdentifyResultRequest;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;

import org.apache.commons.lang.time.StopWatch;
import org.jboss.util.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acc.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.acc.proto.protobuf.BusinessMessage.CPBCandidateList;
import com.acc.proto.protobuf.BusinessMessage.CPBDataBlock;
import com.acc.proto.protobuf.BusinessMessage.CPBDataElement;
import com.acc.proto.protobuf.BusinessMessage.CPBDataGroup;
import com.acc.proto.protobuf.BusinessMessage.CPBModalityDataElement;
import com.acc.proto.protobuf.BusinessMessage.CPBModalityDataGroup;
import com.acc.proto.protobuf.BusinessMessage.CPBProcessInfo;
import com.acc.proto.protobuf.BusinessMessage.CPBProcessMetrics;
import com.acc.proto.protobuf.BusinessMessage.CPBResponse;
import com.acc.proto.protobuf.BusinessMessage.CPBResponseAttribute;
import com.acc.proto.protobuf.BusinessMessage.E_MODALITY_TYPE;
import com.google.protobuf.ByteString;

public class IdentifyResultRequestBuilder {

	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(IdentifyResultRequestSender.class);

	/**
	 * prepare Identify Result of Request basing Identify Batch Job
	 * 
	 * @param identifyResult
	 * @return
	 */
	public static IdentifyResultRequest createIdentifyResultRequest(
			IdentifyResult identifyResult) {
		printLogMessage("start private function createIdentifyResultRequest..");

		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		IdentifyResultRequest.Builder identifyResponse = IdentifyResultRequest
				.newBuilder();

		// create list for IdentifyResponse
		List<ByteString> resultList = prepareIndentifyJobResultInfo(identifyResult);

		// set IdentifyResponse values
		printLogMessage("set IdentifyResponse values..");

		identifyResponse.setBatchJobId(identifyResult.getBatchJobId());
		identifyResponse.addAllBusinessMessage(resultList);
		identifyResponse.setType(BatchType.IDENTIFY);

		// response Transformer the result of batchJob
		printLogMessage(" response Transformer the result of batchJob: "
				+ identifyResult.getBatchJobId() + ".");

		stopWatch.stop();

		PerformanceLogger.performanceOutput(LogConstants.COMPONENT_RESPONSE,
				LogConstants.FUNCTION_CREATE_RESULT_REQUEST, stopWatch
						.getTime());

		printLogMessage("end private function createIdentifyResultRequest..");

		return identifyResponse.build();
	}

	/**
	 * create list for IdentifyResponse
	 * 
	 * @param identifyResult
	 * @return
	 */
	private static List<ByteString> prepareIndentifyJobResultInfo(
			IdentifyResult identifyResult) {
		List<ByteString> resultList = new ArrayList<ByteString>();

		List<CPBBusinessMessage> businessMsgList = BatchSegmentJobManager
				.getInstance().getBatchSegmentJobMap(
						identifyResult.getBatchJobId()).getBusinessMessages();
		// create list for EnrollResponse
		printLogMessage("create list for IdentifyResponse.");

		ObjectCollection<IdentifyJobResult> jobResultSet = identifyResult
				.getSearchJobResults().values();
		int index = 0;
		for (IdentifyJobResult jobResult : jobResultSet) {
			CPBBusinessMessage.Builder bussinessMsg = businessMsgList.get(
					index++).toBuilder();
			// dataBlock
			CPBDataBlock.Builder dataBlock = bussinessMsg.getDataBlockBuilder();

			// protocol buffer required, but tma does not use
			setNotUserData(dataBlock);

			// CPBCandidateList
			setCandidateListData(dataBlock, jobResult);

			// CPBProcessMetrics
			setProcessMetricsData(dataBlock.getProcessMetricBuilder(),
					identifyResult.getBatchJobId());

			// CPBResponse
			setResponseData(bussinessMsg.getResponseBuilder(), jobResult);

			resultList.add(bussinessMsg.build().toByteString());
		}
		return resultList;
	}

	/**
	 * protocol buffer required, but tma does not use
	 * 
	 * @param dataBlock
	 */
	private static void setNotUserData(CPBDataBlock.Builder dataBlock) {
		// CPBDataElement
		CPBDataElement.Builder dataElement = CPBDataElement.newBuilder();
		dataElement.setElementName(Strings.EMPTY)
				.setElementValue(Strings.EMPTY);
		dataBlock.addDataElement(dataElement);

		// CPBDataGroup
		CPBDataGroup.Builder dataGroup = CPBDataGroup.newBuilder();
		dataGroup.setGroupName(Strings.EMPTY).addDataElement(dataElement);
		dataBlock.addDataGroup(dataGroup);

		// CPBModalityDataElement
		CPBModalityDataElement.Builder modalityDataElement = CPBModalityDataElement
				.newBuilder();
		modalityDataElement.setModalityType(E_MODALITY_TYPE.FINGER).setValue(
				Strings.EMPTY);
		dataBlock.addModalityDataElement(modalityDataElement);

		// CPBModalityDataGroup
		CPBModalityDataGroup.Builder modalityDataGroup = CPBModalityDataGroup
				.newBuilder();
		modalityDataGroup.setGroupName(Strings.EMPTY).addModalityDataElement(
				modalityDataElement);
		dataBlock.addModalityDataGroup(modalityDataGroup);
	}

	/**
	 * set Response data
	 * 
	 * @param response
	 * @param jobResult
	 */
	private static void setResponseData(CPBResponse.Builder response,
			IdentifyJobResult jobResult) {
		// CPBResponse
		if (jobResult.getReturnCode() == ReturnCode.JobSuccess) {
			response
					.setStatus(BusinessMessageConstants.RESPONSE_TOPJOB_STATUS_SUCCESS);
		} else {
			response.setStatus(jobResult.getErrorCode()).setErrorMessage(
					jobResult.getErrorMessage());
		}

		// CPBResponseAttribute
		CPBResponseAttribute.Builder responseAttribute = CPBResponseAttribute
				.newBuilder();
		responseAttribute.setAttributeName(
				BusinessMessageConstants.REQUEST_PARAMETER_CREATED_TIMESTAMP)
				.setAttributeValue(
						DateUtil.formatUTC(DateUtil.getCurrentDate()));
		response.addResponseAttributes(responseAttribute);
	}

	/**
	 * set CandidateList Data
	 * 
	 * @param dataBlock
	 * @param jobResult
	 */
	private static void setCandidateListData(CPBDataBlock.Builder dataBlock,
			IdentifyJobResult jobResult) {
		if (jobResult.getReturnCode() == ReturnCode.JobSuccess) {
			CPBCandidateList.Builder candidateList = dataBlock
					.getCandidateListBuilder();
			ObjectArrayList<Candidate> candidates = jobResult.getCandidates();
			for (int i = 0, size = candidates.size(); i < size
					&& i < jobResult.getMaxCandidate(); i++) {
				if (candidates.get(i).getScaledScore() > Integer.MIN_VALUE) {
					candidateList.addCandidates(candidates.get(i)
							.getModalScore());
				}
			}
			candidateList.setMore(jobResult.isOverMaxCandidates());
		}
	}

	/**
	 * set ProcessMetrics Data
	 * 
	 * @param processMetrics
	 * @param jobResult
	 */
	private static void setProcessMetricsData(
			CPBProcessMetrics.Builder processMetrics, long batchJobId) {
		BatchSegmentJobMap batchSegmentJobMap = BatchSegmentJobManager
				.getInstance().getBatchSegmentJobMap(batchJobId);

		CPBProcessInfo.Builder processMetric = CPBProcessInfo.newBuilder();
		processMetric
				.setProcessName(BusinessMessageConstants.REQUEST_PARAMETER_MATCH);
		processMetric.setStartTime(DateUtil.formatUTC(batchSegmentJobMap
				.getInitTime()));
		processMetric.setEndTime(DateUtil.formatUTC(DateUtil.getCurrentDate()));
		processMetrics.addProcessMetric(processMetric);
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @param objects
	 */
	private static void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}
}
