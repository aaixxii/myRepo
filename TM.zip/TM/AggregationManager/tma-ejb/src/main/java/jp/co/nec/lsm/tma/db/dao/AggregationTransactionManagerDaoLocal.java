package jp.co.nec.lsm.tma.db.dao;

import javax.ejb.Local;

/**
 * @author dongqk <br>
 *
 */
@Local
public interface AggregationTransactionManagerDaoLocal {

	public void setStartupTime();

	public void changeTMAToExit();

}
