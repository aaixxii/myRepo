package jp.co.nec.lsm.tma.db.dao;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.lsm.tm.common.constants.ConfigProperty;
import jp.co.nec.lsm.tm.db.common.entityhelpers.SystemConfigHelper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author dongqk <br>
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AggregationSystemConfigDao implements
		AggregationSystemConfigDaoLocal {

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(AggregationSystemConfigDao.class);

	@PersistenceContext(unitName = "tma-unit")
	private EntityManager manager;
	private SystemConfigHelper sysConfigHelper;
	@Resource(mappedName = "java:/OracleDS")
	private DataSource dataSource;
	@PostConstruct
	public void init() {
		sysConfigHelper = new SystemConfigHelper(manager);
	}

	@Override
	public void writeAllMissingProperties() {
		printLogMessage("start public function writeAllMissingProperties()..");

		sysConfigHelper.writeAllMissingProperties(dataSource);

		printLogMessage("end public function writeAllMissingProperties()..");

	}

	/**
	 * constructor
	 */
	public AggregationSystemConfigDao() {
	}

	@Override
	public Long getTMaBatchJobTimeout() {
		return sysConfigHelper
				.getTMPropertyLong(ConfigProperty.TIMEOUTS_TMA_BATCHJOB);
	}

	@Override
	public Integer getTMaBatchJobReRunLimit() {
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.RERUNLIMIT_TMA_BATCHJOB);
	}

	@Override
	public String getPostToTransformerUrl() {
		return sysConfigHelper.getTMProperty(ConfigProperty.IDENTIFY_POST_URL);
	}

	@Override
	public String getTmiIpAddress() {
		return sysConfigHelper.getTMProperty(ConfigProperty.TMI_IP_ADDRESS);
	}

	@Override
	public Integer getTransformerPostTimeout() {
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.TRANSFORMER_POST_CONNECT_TIMEOUT);
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
