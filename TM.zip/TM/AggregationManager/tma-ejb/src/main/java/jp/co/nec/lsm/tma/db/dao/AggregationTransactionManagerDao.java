package jp.co.nec.lsm.tma.db.dao;

import java.util.Date;

import javax.annotation.PostConstruct;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import jp.co.nec.lsm.tm.common.constants.TMType;
import jp.co.nec.lsm.tm.common.constants.TmState;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.common.entities.TransactionManagerEntity;
import jp.co.nec.lsm.tm.db.common.entityhelpers.TransactionManagerHelper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author dongqk <br>
 *
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AggregationTransactionManagerDao implements
		AggregationTransactionManagerDaoLocal {

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(AggregationTransactionManagerDao.class);

	@PersistenceContext(unitName = "tma-unit")
	private EntityManager manager;
	private TransactionManagerHelper tmaHelper;

	@PostConstruct
	public void init() {
		tmaHelper = new TransactionManagerHelper(manager, TMType.TMA);
	}

	/**
	 * constructor
	 */
	public AggregationTransactionManagerDao() {
	}

	@Override
	public void setStartupTime() {
		printLogMessage("start public function setStartupTime()..");

		Date now = DateUtil.getCurrentDate();
		TransactionManagerEntity ame = tmaHelper.createOrLookupVersion(now);
		// set start time
		ame.setLastHeartbeatTs(now);
		manager.persist(ame);

		printLogMessage("end public function setStartupTime()..");
	}

	@Override
	public void changeTMAToExit() {
		Date now = DateUtil.getCurrentDate();
		TransactionManagerEntity ame = tmaHelper.createOrLookupVersion(now);
		ame.setState(TmState.EXITED);
		ame.setLastHeartbeatTs(now);
		ame.setLastPollTs(now);
		manager.merge(ame);
		manager.flush();
		return;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @param objects
	 */
	private static void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}

}
