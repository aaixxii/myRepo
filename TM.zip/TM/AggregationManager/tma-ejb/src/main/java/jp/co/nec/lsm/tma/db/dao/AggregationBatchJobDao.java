package jp.co.nec.lsm.tma.db.dao;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.lsm.tm.db.identify.entities.IdentifyBatchJobDBStatus;
import jp.co.nec.lsm.tm.db.identify.entities.IdentifyBatchJobQueueEntity;
import jp.co.nec.lsm.tm.db.identify.entityhelpers.IdentifyBatchJobHelper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author dongqk <br>
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AggregationBatchJobDao implements AggregationBatchJobDaoLocal {
	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(AggregationBatchJobDao.class);

	/** dataSource instance **/
	@Resource(mappedName = "java:/OracleDS")
	private DataSource dataSource;
	@PersistenceContext(unitName = "tma-unit")
	private EntityManager manager;
	private IdentifyBatchJobHelper identfyJobHelper;

	@PostConstruct
	public void init() {
		identfyJobHelper = new IdentifyBatchJobHelper(manager, dataSource);
		printLogMessage("AggregationBatchJobDao init");
	}

	/**
	 * constructor
	 */
	public AggregationBatchJobDao() {
	}

	/**
	 * getAllRunningBatchJobs
	 */
	@Override
	public List<IdentifyBatchJobQueueEntity> getAllRunningBatchJobs(
			IdentifyBatchJobDBStatus status) {
		printLogMessage("start public function getAllUndoneIdentifyBatchJobs()..");

		List<IdentifyBatchJobQueueEntity> allRunningJobs = identfyJobHelper
				.getAllRunningBatchJobs(status);

		printLogMessage("end public function getAllUndoneIdentifyBatchJobs()..");
		return allRunningJobs;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 *            ,logParame
	 * @return
	 */
	private void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
