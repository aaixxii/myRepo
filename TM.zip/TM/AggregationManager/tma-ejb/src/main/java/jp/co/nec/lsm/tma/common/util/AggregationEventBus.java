package jp.co.nec.lsm.tma.common.util;

import jp.co.nec.lsm.event.identify.IdentifyAbstractEvent;
import jp.co.nec.lsm.event.identify.IdentifyMergerJobDoneEvent;
import jp.co.nec.lsm.event.identify.IdentifySyncSegmentJobDoneEvent;
import jp.co.nec.lsm.event.identify.constants.IdentifyNotifierEnum;
import jp.co.nec.lsm.event.identify.constants.IdentifyReceiverEnum;
import jp.co.nec.lsm.event.identify.notifier.IdentifyNotifier;
import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tm.common.constants.Constants;
import jp.co.nec.lsm.tm.common.httpsender.HttpResponse;
import jp.co.nec.lsm.tm.protocolbuffer.identify.IdentifyResultRequestProto.IdentifyResultRequest;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResultRequestBuilder;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResultRequestSender;
import jp.co.nec.lsm.tma.core.jobs.IdentifyResponseQueue;
import jp.co.nec.lsm.tma.exception.AggregationRuntimeException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author dongqk <br>
 *         This class for sent the notice.
 */
public class AggregationEventBus {
	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(AggregationEventBus.class);

	private AggregationEventBus() {
	}

	/**
	 * send BatchSegmentJobMap which had done to TMI by JMS
	 * 
	 * @param batchSegmentJobMap
	 * @return
	 */
	public static boolean sendBatchSegmentJobMapToTMI(
			BatchSegmentJobMap batchSegmentJobMap, String tmiIpAddress) {
		printLogMessage("start public static function sendBatchSegmentJobMapToTMI..");

		if (null == tmiIpAddress || "".equals(tmiIpAddress)) {
			log.warn("TMI address IP is not given.");
			return false;
		}
		try {
			IdentifyNotifier notifier = new IdentifyNotifier();
			IdentifySyncSegmentJobDoneEvent event = new IdentifySyncSegmentJobDoneEvent(
					batchSegmentJobMap.getbJobId(),
					IdentifyNotifierEnum.IdentifyBatchJobResultService,
					IdentifyReceiverEnum.IdentifySyncWithAggregationServiceBean);
			event.setBatchJobId(batchSegmentJobMap.getbJobId());
			event.setIpAddress(tmiIpAddress);
			event.setBatchSegmentJobMap(batchSegmentJobMap);

			notifier.sendEvent(event);
		} catch (Exception e) {
			log.error("Notify BatchSegmentJobMap To TMI error..", e);
			return false;
		}
		printLogMessage("end public static function sendBatchSegmentJobMapToTMI..");
		return true;
	}

	/**
	 * notify merger batch job Done
	 * 
	 * @param batchJobId
	 */
	public static void notifyBatchjobDone(long batchJobId) {
		printLogMessage("start public static function notifyBatchjobDone..");
		try {
			IdentifyNotifier notifier = new IdentifyNotifier();
			IdentifyAbstractEvent event = new IdentifyMergerJobDoneEvent(
					batchJobId,
					IdentifyNotifierEnum.IdentifyTmaPollbeanService,
					IdentifyReceiverEnum.IdentifyBatchJobResultService);
			notifier.sendEvent(event);
		} catch (Exception e) {
			log.error("Notify BatchJob done error..", e);
		}
		printLogMessage("end public static function notifyBatchjobDone..");
	}

	/**
	 * send IdentifyResultRequest Object to Transformer
	 * 
	 * @response IdentifyResult Object
	 * @return
	 */
	public static boolean sendIdentifyResponseToTransformer(
			IdentifyResult identifyResult, String endPoint, Integer timeout) {
		printLogMessage("start public static function sendIdentifyResponseToTransformer..");

		IdentifyResultRequest response = IdentifyResultRequestBuilder
				.createIdentifyResultRequest(identifyResult);
		sendIdentifyResponseToTransformer(response, endPoint, timeout);

		// just for test
		IdentifyResponseQueue.getInstance().add(response);

		printLogMessage("end public static function sendIdentifyResponseToTransformer..");
		return true;
	}

	/**
	 * sendIdentifyResponseToTransformer
	 * 
	 * @param response
	 * @param endPoint
	 */
	private static void sendIdentifyResponseToTransformer(
			IdentifyResultRequest response, String endPoint, Integer timeout) {
		IdentifyResultRequestSender sender = new IdentifyResultRequestSender();
		HttpResponse httpResponse = sender.sendIdentifyResponse(response,
				endPoint, timeout);

		if (httpResponse.getHttpResponseCode() == Constants.HTTP_RESPONSE_CODE_500) {
			throw new AggregationRuntimeException(
					httpResponse.getHttpResponseErrorMessage());
		}
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @param objects
	 */
	private static void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}
}
