package jp.co.nec.lsm.tma.timer;

import java.util.Collection;

import javax.annotation.Resource;
import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerService;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.jms.Message;
import javax.jms.MessageListener;

import jp.co.nec.lsm.tm.common.constants.JNDIConstants;
import jp.co.nec.lsm.tm.common.util.ServiceLocator;
import jp.co.nec.lsm.tma.common.constants.AggregationConstants;
import jp.co.nec.lsm.tma.timer.AggregationPollLocal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author dongqk <br>
 * 
 */
@MessageDriven(activationConfig = {
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
		@ActivationConfigProperty(propertyName = "destination", propertyValue = JNDIConstants.AGGREGATION_STARTTIMER_QUEUE) })
public class AggregationTimerManagerMDB implements MessageListener {

	private static Logger log = LoggerFactory
			.getLogger(AggregationTimerManagerMDB.class);

	@Resource
	TimerService timerService;
	private AggregationPollLocal pollBean;

	/**
	 * constructor
	 */
	public AggregationTimerManagerMDB() {
	}

	/**
	 * 
	 */
	public void onMessage(Message message) {
		Collection<Timer> existingTimers = timerService.getTimers();
		if (existingTimers.isEmpty()) {
			log.info("REGISTERING NEW TIMER");
			timerService.createTimer(AggregationConstants.POLLING_DURATION,
					AggregationConstants.POLLING_DURATION, null);
		} else {
			log.info("TIMER ALREADY REGISTERED");
		}
	}

	/**
	 * 
	 * @param timer
	 */
	@Timeout
	@TransactionAttribute(TransactionAttributeType.REQUIRED)
	public void timeout(javax.ejb.Timer timer) {
		if (pollBean == null) {
			try {
				pollBean = ServiceLocator
						.getLookUpJndiObject(JNDIConstants.TMA_BEAN_POLL,
								AggregationPollLocal.class);
			} catch (RuntimeException e) {
				log.warn("AggregationPollBean has not bound yet");
			}
		} else {
			pollBean.poll();
		}

	}
}
