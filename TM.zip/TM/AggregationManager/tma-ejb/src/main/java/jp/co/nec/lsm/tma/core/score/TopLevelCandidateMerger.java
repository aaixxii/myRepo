package jp.co.nec.lsm.tma.core.score;

import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;

import java.util.List;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto;
import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto.Candidate;
import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto.IdentifyJobResultRequest;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyJobResult;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;

import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author dongqk <br>
 * According to the BatchJobId and JobId, get each Job Object, merge
 * ScaledScore, For IdentifyResult returned each USC, first, find the
 * corresponding batchJob, and then merge data from job1 to jobn, if the score
 * is higher than now, insert, otherwise give up .
 * 
 */
public class TopLevelCandidateMerger {

	private static Logger log = LoggerFactory.getLogger(TopLevelCandidateMerger.class);

	/**
	 * private constructor
	 */
	private TopLevelCandidateMerger() {
	}

	/**
	 * According to the BatchJobId and JobIndex, get each Job Object, merge
	 * ScaledScore, For IdentifyResult returned each USC, first, find the
	 * corresponding batchJob, and then merge data from job1 to jobn, if the
	 * score is higher than now, insert, otherwise give up
	 * 
	 * @param identifyResult
	 *            one batch Object in TMA Queue
	 * @param resultRequest
	 *            Merged Object from USC
	 */
	public static void mergeTopLevelCandidates(IdentifyResult identifyResult,
			IdentifyJobResultRequest resultRequest) {
		printLogMessage("start public function merge()...");

		StopWatch t = new StopWatch();
		t.start();

		final int resultRequestSize = resultRequest.getIdentifyJobResultCount();

		synchronized (identifyResult) {
			Int2ObjectArrayMap<IdentifyJobResult> topLeveLJobResults = identifyResult.getSearchJobResults();

			for (int i = 0; i < resultRequestSize; i++) {
				// Get IdentifyJobResult from USC
				IdentifyJobResultRequestProto.IdentifyJobResult topLevelJobResultFromUSC = resultRequest
						.getIdentifyJobResult(i);

				int jobIndex = topLevelJobResultFromUSC.getJobIndex();

				// Get SearchJobResult from TMA queue
				IdentifyJobResult topLevelJobResult = topLeveLJobResults.get(jobIndex);
				if (null == topLevelJobResult) {
					log.error(
							"BatchJobId: {}, doesnot have IdentifyJobResult which JobIndex is {} in the TMA queue...",
									new Object[] { identifyResult.getBatchJobId(), jobIndex });
					continue;
				}

				//
				final int candidatesSize = topLevelJobResult.getCandidates().size();
				final int candidatesFromUSCSize = topLevelJobResultFromUSC.getCandidateCount();

				// valid Params Error, if error, return false, else true
				if (!isValidParams(topLevelJobResultFromUSC, topLevelJobResult, candidatesSize, candidatesFromUSCSize)) {
					continue;
				}

				// merge Candidates
				mergeTopLevelCandidate(topLevelJobResult.getCandidates().elements(),
						candidatesSize, topLevelJobResultFromUSC.getCandidateList(), candidatesFromUSCSize);
			}
		}

		t.stop();
		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_TOP_LEVEL_CANDIDATE_MERGER,
				LogConstants.FUNCTION_MERGE, t.getTime());

		printLogMessage("end public function merge()...");
	}

	/**
	 * valid Params Error, if error, return false, else true
	 * 
	 * @param topLevelJobResultFromUSC
	 * @param topLeveLJobResult
	 * @param candidatesSize
	 * @param candidatesFromUSCSize
	 * @return
	 */
	private final static boolean isValidParams(IdentifyJobResultRequestProto.IdentifyJobResult topLevelJobResultFromUSC,
			IdentifyJobResult topLeveLJobResult, int candidatesSize, int candidatesFromUSCSize) {

		if(topLeveLJobResult.getReturnCode() == ReturnCode.JobFailed) {
			return false;
		}

		if (topLevelJobResultFromUSC.getReturnCode() == ReturnCode.JobFailed
				&& topLeveLJobResult.getReturnCode() != ReturnCode.JobFailed) {
			topLeveLJobResult.setReturnCode(ReturnCode.JobFailed);
			topLeveLJobResult.setErrorCode(String.valueOf(topLevelJobResultFromUSC.getErrorCode()));
			topLeveLJobResult.setErrorMessage(topLevelJobResultFromUSC.getErrorMessage());
			topLeveLJobResult.getCandidates().clear();
			return false;
		}

		if (topLeveLJobResult.getMaxCandidate() <= 0) {
			return false;
		}

		if (candidatesSize <= 1) {
			return false;
		}

		return true;
	}

	/**
	 * merge TopLevelJob Candidates
	 * 
	 * @param candidates
	 *            candidates from tma queue
	 * @param candidatesSize
	 * @param candidateListFromUSC
	 *            candidates from USC
	 * @param candidateListFromUSCSize
	 */
	public final static void mergeTopLevelCandidate(Object[] candidates, int candidatesSize,
			List<Candidate> candidateListFromUSC, int candidateListFromUSCSize) {

		// the last one in the queue > the first one in the IdentifyResult from USC
		if (candidateListFromUSCSize > 0 && 
				((Candidate) candidates[candidatesSize - 1]).getScaledScore() >= candidateListFromUSC.get(0).getScaledScore()) {
			return;
		}

		int i = 0; // outside of the loop, reduce loop times
		for (int j = 0; j < candidateListFromUSCSize; j++) {
			for (; i < candidatesSize; i++) {
				if(candidateListFromUSC.get(j).getReferenceId().equals(((Candidate) candidates[i]).getReferenceId())) {
					break;
				}
				if (candidateListFromUSC.get(j).getScaledScore() > ((Candidate) candidates[i]).getScaledScore()) {
					System.arraycopy(candidates, i, candidates, i + 1, candidatesSize - i - 1);
					candidates[i] = candidateListFromUSC.get(j);
					break;
				}
			}
		}
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @param objects
	 */
	private static void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}

}
