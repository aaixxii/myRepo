package jp.co.nec.lsm.tma.core.jobs;

import it.unimi.dsi.fastutil.longs.LongArraySet;
import it.unimi.dsi.fastutil.objects.ObjectCollection;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import jp.co.nec.lsm.tm.common.communication.BatchJobMapStatus;
import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobStatus;
import jp.co.nec.lsm.tm.common.communication.SegmentMap;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyJobResult;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author dongqk <br>
 *         Singleton, TMA memory data
 * 
 */
public final class BatchSegmentJobManager {

	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(BatchSegmentJobManager.class);

	/** key -> BatchJobId, value -> IdentifyResult */
	private final Map<Long, IdentifyResult> identifyResults = new ConcurrentHashMap<Long, IdentifyResult>();

	/** key -> BatchJobId, value -> batchSegmentJobMaps */
	private final Map<Long, BatchSegmentJobMap> batchSegmentJobMaps = new ConcurrentHashMap<Long, BatchSegmentJobMap>();

	private static BatchSegmentJobManager aggregationQueueManager = new BatchSegmentJobManager();

	/**
	 * private constructor
	 */
	private BatchSegmentJobManager() {
	}

	/**
	 * get this class object instance
	 * 
	 * @return instance object
	 */
	public synchronized static BatchSegmentJobManager getInstance() {
		printLogMessage("call public synchronized static function getInstance()...");
		return aggregationQueueManager;
	}

	/**
	 * add BatchSegmentJobMap into the memory queue
	 * 
	 * @param batchSegmentJobMap
	 */
	public synchronized void add(BatchSegmentJobMap batchSegmentJobMap) {
		batchSegmentJobMaps.put(batchSegmentJobMap.getbJobId(),
				batchSegmentJobMap);
		printLogMessage("add BatchSegmentJobMap into the memory queue...");
	}

	/**
	 * add IdentifyResult into the memory queue
	 * 
	 * @param result
	 */
	public synchronized void add(IdentifyResult result) {
		identifyResults.put(result.getBatchJobId(), result);
		printLogMessage("add IdentifyResult into the memory queue...");
	}

	/**
	 * according to batchJobId, remove BatchSegmentJobMap and IdentifyResult
	 * from the memory queue which has been done
	 * 
	 * @param batchJobId
	 */
	public synchronized void remove(long batchJobId) {
		batchSegmentJobMaps.remove(batchJobId);
		identifyResults.remove(batchJobId);
		printLogMessage("according to batchJobId, remove BatchSegmentJobMap and IdentifyResult from the memory queue which has been done...");
	}

	/**
	 * according to batchJobId, get BatchSegmentJobMap from the memory queue
	 * 
	 * @param batchJobId
	 * @return
	 */
	public BatchSegmentJobMap getBatchSegmentJobMap(long batchJobId) {
		printLogMessage("according to batchJobId, get BatchSegmentJobMap from the memory queue...");
		return batchSegmentJobMaps.get(batchJobId);
	}

	/**
	 * according to batchJobId, get IdentifyResult from the memory queue
	 * 
	 * @param batchJobId
	 * @return
	 */
	public IdentifyResult getIdentifyResult(long batchJobId) {
		printLogMessage("according to batchJobId, get IdentifyResult from the memory queue...");
		return identifyResults.get(batchJobId);
	}

	/**
	 * get BatchSegmentJobMaps map object from the memory queue
	 * 
	 * @return BatchSegmentJobMap map object
	 */
	public Map<Long, BatchSegmentJobMap> getBatchSegmentJobMaps() {
		printLogMessage("get BatchSegmentJobMaps map object from the memory queue...");
		return batchSegmentJobMaps;
	}

	/**
	 * get IdentifyResults map object from the memory queue
	 * 
	 * @return IdentifyResult map object
	 */
	public Map<Long, IdentifyResult> getIdentifyResults() {
		printLogMessage("get IdentifyResults map object from the memory queue...");
		return identifyResults;
	}

	/**
	 * according to batchJobId, set BatchJobStatus in BatchSegmentJobMap from
	 * the memory queue
	 * 
	 * @param batchJobId
	 * @param status
	 */
	public synchronized void setBatchJobStatus(long batchJobId,
			BatchJobMapStatus status) {
		getBatchSegmentJobMap(batchJobId).setBatchJobStatus(status);
		printLogMessage("according to batchJobId, set BatchJobStatus in BatchSegmentJobMap from the memory queue...");
	}

	/**
	 * according to batchJobId, get SegmentJobMap map in BatchSegmentJobMap from
	 * the memory queue
	 * 
	 * @param batchJobId
	 * @return
	 */
	public Map<Long, SegmentMap> getSegmentJobMaps(long batchJobId) {
		printLogMessage("according to batchJobId, get SegmentJobMap map in BatchSegmentJobMap from the memory queue...");
		return getBatchSegmentJobMap(batchJobId).getSegmentMaps();
	}

	/**
	 * according to batchJobId, get SegmentId array in IdentifyResult from the
	 * memory queue
	 * 
	 * @param batchJobId
	 * @return
	 */
	public LongArraySet getSegmentIds(long batchJobId) {
		printLogMessage("according to batchJobId, get SegmentId array in IdentifyResult from the memory queue...");
		return getIdentifyResult(batchJobId).getSegmentIds();
	}

	/**
	 * according to batchJobId, judge whether BatchSegmentJob has already
	 * Received, if receive first, remove this SegmentIds from IndentifyResult
	 * Queue according to args, return false. else, do nothing, return true
	 * 
	 * @param batchJobId
	 * @param segmentIds
	 * @return
	 */
	public synchronized boolean hasBSJAlreadyReceived(long batchJobId,
			Collection<Long> segmentIds) {
		printLogMessage("according to batchJobId, judge whether BatchSegmentJob has already Received...");
		return !getSegmentIds(batchJobId).removeAll(segmentIds);
	}

	/**
	 * set batchSegmentJob status to done according to batchJobId, set
	 * batchSegmentJob status to done in the BatchSegmentJobMap from the memory
	 * queue
	 * 
	 * @param batchJobId
	 * @param segmentIdList
	 */
	public synchronized void setBatchSegmentJobStatusDone(long batchJobId,
			List<Long> segmentIdList) {
		final int idsSize = segmentIdList.size();
		Map<Long, SegmentMap> segmentMaps = getSegmentJobMaps(batchJobId);
		for (int i = 0; i < idsSize; i++) {
			SegmentMap segmentMap = segmentMaps.get(segmentIdList.get(i));
			if (null != segmentMap) {
				segmentMap.setBatchSegmentJobStatus(BatchSegmentJobStatus.DONE);
			}
		}
		printLogMessage("according to batchJobId, set batchSegmentJob status to done in the BatchSegmentJobMap from the memory queue...");
	}

	/**
	 * according to batchJobId, judge whether batchJob is done
	 * 
	 * @param batchJobId
	 * @return
	 */
	public boolean isBatchJobDone(long batchJobId) {
		printLogMessage("according to batchJobId, judge whether batchJob is done...");
		return 0 == getSegmentIds(batchJobId).size();
	}

	/**
	 * 
	 * @param isSendDoneEvent
	 */
	public void changeSendDoneEventFlag(long batchJobId, boolean isSendDoneEvent) {
		getBatchSegmentJobMap(batchJobId).setSendDoneEvent(isSendDoneEvent);
	}

	/**
	 * 
	 * @param batchJobId
	 * @return
	 */
	public boolean isSendDoneEvent(long batchJobId) {
		return getBatchSegmentJobMap(batchJobId).isSendDoneEvent();
	}

	/**
	 * according to batchJobId, set BatchSegmentJobMap Status to
	 * TMA_WORKING_DONE/NOTIFY_TRANSFORMER_DONE/NOTIFY_TMI_DONE
	 * 
	 * @param batchJobId
	 * @param batchJobMapStatus
	 */
	public synchronized void setBatchSegmentJobMapStatusDone(long batchJobId,
			BatchJobMapStatus batchJobMapStatus) {
		getBatchSegmentJobMap(batchJobId).setBatchJobStatus(batchJobMapStatus);
		printLogMessage("according to batchJobId, set BatchSegmentJobMap Status to Done...");
	}

	/**
	 * according to batchJobId, get BatchSegmentJobMap Status
	 * 
	 * @param batchJobId
	 * @return
	 */
	public BatchJobMapStatus getBatchSegmentJobMapStatus(long batchJobId) {
		return getBatchSegmentJobMap(batchJobId).getBatchJobStatus();
	}

	/**
	 * according to batchJobId, set all SearchJobResult's OverMaxCandidates
	 * 
	 * @param batchJobId
	 */
	public synchronized void setOverMaxCandidatesTrue(long batchJobId) {
		ObjectCollection<IdentifyJobResult> jobResultSet = getIdentifyResult(
				batchJobId).getSearchJobResults().values();
		for (IdentifyJobResult jobResult : jobResultSet) {
			jobResult.setOverMaxCandidates(isOverMaxCandidate(jobResult));
		}
		printLogMessage("according to batchJobId, set all SearchJobResult's OverMaxCandidates...");
	}

	/**
	 * clear data in the memory queue
	 */
	public void clear() {
		getBatchSegmentJobMaps().clear();
		getIdentifyResults().clear();
	}

	/**
	 * judge whether Candidates size is greater than maxCandidate<br>
	 * and judge whether the last Candidate in IdentifyJobResult is equals with
	 * DEFAULT_SCORE_MIN_VALUE
	 * 
	 * @param jobResult
	 * @return
	 */
	private boolean isOverMaxCandidate(IdentifyJobResult jobResult) {
		return jobResult.getCandidates().size() > jobResult.getMaxCandidate()
				&& jobResult.getCandidates().get(jobResult.getMaxCandidate())
						.getScaledScore() > Integer.MIN_VALUE;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @param objects
	 */
	private static void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}

}
