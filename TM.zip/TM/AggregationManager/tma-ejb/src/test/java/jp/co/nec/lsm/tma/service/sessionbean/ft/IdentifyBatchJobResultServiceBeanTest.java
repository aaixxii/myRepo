package jp.co.nec.lsm.tma.service.sessionbean.ft;

import it.unimi.dsi.fastutil.objects.ObjectCollection;

import javax.annotation.Resource;

import jp.co.nec.lsm.tm.common.communication.BatchJobMapStatus;
import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tm.protocolbuffer.identify.IdentifyResultRequestProto.IdentifyResultRequest;
import jp.co.nec.lsm.tma.common.util.AggregationEventBus;
import jp.co.nec.lsm.tma.common.util.UtilCreateData;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyJobResult;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;
import jp.co.nec.lsm.tma.exception.AggregationRuntimeException;
import jp.co.nec.lsm.tma.service.sessionbean.IdentifyBatchJobResultServiceBean;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

/**
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class IdentifyBatchJobResultServiceBeanTest {
	@Resource
	IdentifyBatchJobResultServiceBean identifyBatchJobResultServiceBean;

	private final static long bJobIdStart = 10000;
	private final static int bJobCount = 2;
	private final static int jobCount = 10;
	private final static int maxCandidate = 10;
	private final static int segmentIdStart = 1000;
	private final static int segmentCount = 2;

	private BatchSegmentJobManager queueManager;
	@Resource
	protected JdbcTemplate jdbcTemplate;

	@Before
	public void setUp() throws Exception {
		setMockMethod();
		queueManager = BatchSegmentJobManager.getInstance();
		queueManager.clear();
	}

	@After
	public void tearDown() throws Exception {
		queueManager = null;
	}

	private void setMockMethod() {
		new MockUp<AggregationEventBus>() {
			@SuppressWarnings("unused")
			@Mock
			public boolean sendBatchSegmentJobMapToTMI(
					BatchSegmentJobMap batchSegmentJobMap, String tmiIpAddress) {
				return true;
			}

			@SuppressWarnings("unused")
			@Mock
			public void notifyBatchjobDone(long batchJobId) {
				return;
			}

			@SuppressWarnings("unused")
			@Mock
			private void sendIdentifyResponseToTransformer(
					IdentifyResultRequest response, String endPoint,
					Integer timeout) {
				return;
			}
		};
	}

	@Test
	public void testNotifyBatchSegmentJobDone() {
		createIdentifyResultList(bJobIdStart, bJobCount, jobCount,
				maxCandidate + 1, segmentIdStart, segmentCount, maxCandidate);
		BatchSegmentJobMap batchSegmentJobMap = UtilCreateData
				.createBatchSegmentJobMapData(bJobIdStart + 1, jobCount,
						maxCandidate, segmentIdStart, segmentCount);
		batchSegmentJobMap.setBatchJobStatus(BatchJobMapStatus.RUNNING);
		queueManager.add(batchSegmentJobMap);

		long removeBatchJobId = queueManager.getIdentifyResults().keySet()
				.iterator().next();
		try {
			identifyBatchJobResultServiceBean
					.notifyBatchJobDone(removeBatchJobId);
		} catch (AggregationRuntimeException e) {
		}
		queueManager.remove(removeBatchJobId);

		Assert.assertNull(queueManager.getBatchSegmentJobMap(removeBatchJobId));
		Assert.assertNull(queueManager.getIdentifyResult(removeBatchJobId));

		// test BatchSegmentJobMap is null
		try {
			identifyBatchJobResultServiceBean.notifyBatchJobDone(bJobIdStart);
		} catch (AggregationRuntimeException e) {
			Assert.assertNull(queueManager.getBatchSegmentJobMap(bJobIdStart));
			Assert.assertNotNull(queueManager.getIdentifyResult(bJobIdStart));
		}

		// test IdentifyResult is null
		removeBatchJobId++;
		try {
			identifyBatchJobResultServiceBean
					.notifyBatchJobDone(removeBatchJobId);
		} catch (AggregationRuntimeException e) {
			Assert.assertNull(queueManager
					.getBatchSegmentJobMap(removeBatchJobId));
			Assert.assertNull(queueManager.getIdentifyResult(removeBatchJobId));
		}
	}

	private void setUnSuccessTransformerMockMethod() {
		new MockUp<AggregationEventBus>() {
			@SuppressWarnings("unused")
			@Mock
			public boolean sendIdentifyResponseToTransformer(
					IdentifyResult identifyResult, String endPoint,
					Integer timeout) {
				return false;
			}

			@SuppressWarnings("unused")
			@Mock
			public boolean sendBatchSegmentJobMapToTMI(
					BatchSegmentJobMap batchSegmentJobMap, String tmiIpAddress) {
				return false;
			}

		};
	}

	private void setUnSuccessTMIMockMethod() {
		new MockUp<AggregationEventBus>() {
			@SuppressWarnings("unused")
			@Mock
			public boolean sendBatchSegmentJobMapToTMI(
					BatchSegmentJobMap batchSegmentJobMap, String tmiIpAddress) {
				return false;
			}

		};
	}

	@Test
	public void sendTransformerUnSuccess() {
		setUnSuccessTransformerMockMethod();
		createIdentifyResultList(bJobIdStart, bJobCount, jobCount,
				maxCandidate + 1, segmentIdStart, segmentCount, maxCandidate);
		BatchSegmentJobMap batchSegmentJobMap = UtilCreateData
				.createBatchSegmentJobMapData(bJobIdStart + 1, jobCount,
						maxCandidate, segmentIdStart, segmentCount);
		batchSegmentJobMap.setBatchJobStatus(BatchJobMapStatus.RUNNING);
		queueManager.add(batchSegmentJobMap);

		long removeBatchJobId = queueManager.getIdentifyResults().keySet()
				.iterator().next();
		try {
			identifyBatchJobResultServiceBean
					.notifyBatchJobDone(removeBatchJobId);
		} catch (AggregationRuntimeException e) {
			Assert.assertEquals(e.getMessage(),
					"BatchJobId: 10001, send IdentifyResponse to Transformer error.");
		}
	}

	@Test
	public void sendTMIUnSuccess() {
		setUnSuccessTMIMockMethod();
		createIdentifyResultList(bJobIdStart, bJobCount, jobCount,
				maxCandidate + 1, segmentIdStart, segmentCount, maxCandidate);
		BatchSegmentJobMap batchSegmentJobMap = UtilCreateData
				.createBatchSegmentJobMapData(bJobIdStart + 1, jobCount,
						maxCandidate, segmentIdStart, segmentCount);
		batchSegmentJobMap.setBatchJobStatus(BatchJobMapStatus.RUNNING);
		queueManager.add(batchSegmentJobMap);

		long removeBatchJobId = queueManager.getIdentifyResults().keySet()
				.iterator().next();
		try {
			identifyBatchJobResultServiceBean
					.notifyBatchJobDone(removeBatchJobId);
		} catch (AggregationRuntimeException e) {
			Assert.assertEquals(
					e.getMessage(),
					"BatchJobId: 10001, send BatchSegmentJobMap to TMI error, when this BatchSegmentJobMap has been done.");
		}
	}

	/**
	 * create much more IdentifyResult data
	 * 
	 * @param bJobCount
	 */
	private void createIdentifyResultList(long bJobIdStart, int bJobCount,
			int jobCount, int candidateSize, long segmentIdStart,
			int segmentCount, int maxCandidate) {
		IdentifyResult identifyResult = null;
		for (long i = 0; i < bJobCount; i++) {
			identifyResult = UtilCreateData.createIdentifyResultData(
					bJobIdStart + i, jobCount, candidateSize, segmentIdStart,
					segmentCount, maxCandidate);

			// set maxCandidate
			ObjectCollection<IdentifyJobResult> SearchJobResults = identifyResult
					.getSearchJobResults().values();
			for (IdentifyJobResult jobInfo : SearchJobResults) {
				jobInfo.setMaxCandidate(maxCandidate);
			}

			queueManager.add(identifyResult);
			identifyResult = null;
		}
	}

}
