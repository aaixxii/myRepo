package jp.co.nec.lsm.tma.service.sessionbean.pt;

import javax.annotation.Resource;

import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tm.common.exception.TMRuntimeException;
import jp.co.nec.lsm.tma.common.util.TMAUtilSwitchEjb;
import jp.co.nec.lsm.tma.common.util.UtilCreateData;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;
import jp.co.nec.lsm.tma.exception.AggregationRuntimeException;
import jp.co.nec.lsm.tma.service.pojo.IdentifySyncAggregationServiceBean;
import jp.co.nec.lsm.tma.sessionbean.api.BatchSegmentJobMapInitializerRemote;
import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.carrotsearch.junitbenchmarks.AbstractBenchmark;
import com.carrotsearch.junitbenchmarks.BenchmarkOptions;

/**
 * 
 */
@BenchmarkOptions(benchmarkRounds = 5, warmupRounds = 5)
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class IdentifySyncAggregationServiceBeanTest extends AbstractBenchmark {
	@Resource
	BatchSegmentJobMapInitializerRemote batchSegmentJobMapInitializerBean;
	@Resource
	private IdentifySyncAggregationServiceBean identifySyncAggregationServiceBean;

	private BatchSegmentJobManager queueManager;

	private final static long bJobIdStart = 10000;
	private final static int jobIdStart = 100;
	private final static int jobCount = 1000;
	private final static int segmentIdStart = 1000;
	private final static int segmentCount = 20;
	private final static int segmentEachCount = 10;
	private final static int maxCandidate = 10;

	@Before
	public void setUp() throws Exception {
		queueManager = BatchSegmentJobManager.getInstance();
		queueManager.clear();
	}

	@After
	public void tearDown() throws Exception {
		queueManager = null;
	}

	@Test
	public void testMergeIdentifyResult() {
		queueManager.clear();
		Assert.assertEquals(0, queueManager.getBatchSegmentJobMaps().size());
		Assert.assertEquals(0, queueManager.getIdentifyResults().size());

		// create BatchSegmentJobMap data
		BatchSegmentJobMap batchSegmentJobMap = UtilCreateData
				.createBatchSegmentJobMapData(bJobIdStart, jobIdStart,
						jobCount, maxCandidate, segmentIdStart, segmentCount);
		batchSegmentJobMapInitializerBean
				.receiveBatchJobAndInitSpace(batchSegmentJobMap);

		Assert.assertNotNull(queueManager.getBatchSegmentJobMap(bJobIdStart));
		Assert.assertNotNull(queueManager.getIdentifyResult(bJobIdStart));

		try {
			IdentifyResult identifyResult = null;
			// first data from mu
			identifyResult = UtilCreateData.createIdentifyResultData(
					bJobIdStart, jobIdStart, jobCount, maxCandidate,
					segmentIdStart, segmentEachCount, maxCandidate);

			identifySyncAggregationServiceBean.mergeIdentifyResult(TMAUtilSwitchEjb
					.switchIdentifyResult(identifyResult));

			Assert.assertNotNull(queueManager
					.getBatchSegmentJobMap(bJobIdStart));
			Assert.assertNotNull(queueManager.getIdentifyResult(bJobIdStart));
			Assert.assertEquals(queueManager.getIdentifyResults().size(), 1);
			Assert.assertTrue(0 != queueManager.getIdentifyResult(bJobIdStart)
					.getSearchJobResults().get(jobIdStart).getCandidates()
					.get(1).getScaledScore());

			identifyResult = null;

			// second data from mu
			identifyResult = UtilCreateData.createIdentifyResultData(
					bJobIdStart, jobIdStart, jobCount, maxCandidate,
					segmentIdStart + segmentEachCount, segmentEachCount,
					maxCandidate);
			identifySyncAggregationServiceBean.mergeIdentifyResult(TMAUtilSwitchEjb
					.switchIdentifyResult(identifyResult));

			Assert.assertNotNull(queueManager
					.getBatchSegmentJobMap(bJobIdStart));
			Assert.assertNotNull(queueManager.getIdentifyResult(bJobIdStart));
			Assert.assertEquals(queueManager.getIdentifyResults().size(), 1);
			Assert.assertTrue(0 != queueManager.getIdentifyResult(bJobIdStart)
					.getSearchJobResults().get(jobIdStart).getCandidates()
					.get(1).getScaledScore());

			identifyResult = null;
		} catch (Exception e) {
			if (e instanceof TMRuntimeException) {
				Assert.assertNotNull(queueManager
						.getBatchSegmentJobMap(bJobIdStart));
				Assert.assertNotNull(queueManager
						.getIdentifyResult(bJobIdStart));
			} else {
				throw new AggregationRuntimeException(e.getMessage());
			}
		}
	}

}
