package jp.co.nec.lsm.tma.core.clientapi.response;

import static javax.servlet.http.HttpServletResponse.SC_OK;
import static org.apache.commons.io.IOUtils.write;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.lsm.tm.common.httpsender.HttpResponse;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tm.protocolbuffer.identify.IdentifyResultRequestProto.IdentifyResultRequest;
import jp.co.nec.lsm.tma.common.util.HttpTestServer;
import junit.framework.Assert;

import org.junit.Test;
import org.mortbay.jetty.Handler;
import org.mortbay.jetty.HttpConnection;
import org.mortbay.jetty.Request;
import org.mortbay.jetty.handler.AbstractHandler;

import com.google.protobuf.ByteString;

public class IdentifyResultRequestSenderTest {

	private HttpTestServer _server;

	public void setUp() throws Exception {
		_server = new HttpTestServer(65513);
		_server.start(getMockHandler());
	}

	public void tearDown() throws Exception {
		_server.stop();
	}

	public static Handler getMockHandler() {
		Handler handler = new AbstractHandler() {
			public void handle(String target, HttpServletRequest request,
					HttpServletResponse response, int dispatch)
					throws IOException, ServletException {
				Request baseRequest = request instanceof Request ? (Request) request
						: HttpConnection.getCurrentConnection().getRequest();
				response.setStatus(SC_OK);
				write("http ok", response.getOutputStream());
				response.setContentType("text/html;charset=utf-8");
				response.setCharacterEncoding("UTF-8");
				baseRequest.setHandled(true);
			}
		};
		return handler;
	}

	@Test
	public void testSendIdentifyResponse() throws Exception {
		try {
			setUp();
			IdentifyResultRequestSender sender = new IdentifyResultRequestSender();

			IdentifyResultRequest.Builder builder = IdentifyResultRequest
					.newBuilder();
			builder.setBatchJobId(1L);
			builder.setType(BatchType.IDENTIFY);
			builder.addBusinessMessage(ByteString.EMPTY);

			HttpResponse reponse = sender.sendIdentifyResponse(builder.build(),
					"http://127.0.0.1:65513/test", 20000);
			Assert.assertEquals(reponse.getHttpResponseCode(), 200);
		} finally {
			tearDown();
		}
	}
}
