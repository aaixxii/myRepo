package jp.co.nec.lsm.tma.timer;

import static org.junit.Assert.assertTrue;

import java.util.Calendar;
import java.util.Date;

import javax.annotation.Resource;
import javax.ejb.EJB;

import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.protocolbuffer.identify.IdentifyResultRequestProto.IdentifyResultRequest;
import jp.co.nec.lsm.tma.common.util.AggregationEventBus;
import jp.co.nec.lsm.tma.common.util.UtilCreateData;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;
import jp.co.nec.lsm.tma.db.dao.AggregationSystemConfigDaoLocal;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class AggregationPollBeanTest {

	private final static long bJobIdStart = 10000;
	private final static long bJobCount = 1;
	private final static long segmentIdStart = 0;
	private final static int segmentCount = 20;
	private final static int jobCount = 1000;
	private final static int maxCandidate = 10;
	@Resource
	private JdbcTemplate jdbcTemplate;

	private BatchSegmentJobManager queueManager;

	@EJB
	private AggregationSystemConfigDaoLocal sysConfigDao;

	@Resource
	private AggregationPollBean pollBean;

	@Before
	public void setUp() throws Exception {
		setMockMethod();
		queueManager = BatchSegmentJobManager.getInstance();
		queueManager.clear();
	}

	@After
	public void tearDown() throws Exception {
		queueManager = null;
	}

	private void setMockMethod() {
		new MockUp<AggregationEventBus>() {
			@SuppressWarnings("unused")
			@Mock
			public boolean sendBatchSegmentJobMapToTMI(
					BatchSegmentJobMap batchSegmentJobMap, String tmiIpAddress) {
				return true;
			}

			@SuppressWarnings("unused")
			@Mock
			public void notifyBatchjobDone(long batchJobId) {
				return;
			}

			@SuppressWarnings("unused")
			@Mock
			private void sendIdentifyResponseToTransformer(
					IdentifyResultRequest response, String endPoint,
					Integer timeout) {
				return;
			}
		};
	}

	@Test
	public void testPoll() {
		// get batch job limit time from DB
		long defaultBatchJobTimeout = sysConfigDao.getTMaBatchJobTimeout();
		defaultBatchJobTimeout = defaultBatchJobTimeout <= 0 ? 3600000
				: defaultBatchJobTimeout;
		// get batch job limit rerun times From DB
		int reRunLimit = sysConfigDao.getTMaBatchJobReRunLimit();
		reRunLimit = reRunLimit <= 0 ? 3 : reRunLimit;
		//
		Date startTime = new Date(DateUtil.getCurrentDate().getTime()
				- defaultBatchJobTimeout);

		for (int i = 0; i < reRunLimit; i++) {
			runCase(defaultBatchJobTimeout >> i, reRunLimit, startTime, i);
			try {
				pollBean.poll();
			} catch (Exception e) {
			}
			if (null != queueManager.getBatchSegmentJobMap(bJobIdStart)
					&& queueManager.getBatchSegmentJobMap(bJobIdStart)
							.getFailureCount() < reRunLimit) {
				assertTrue(defaultBatchJobTimeout >> (i + 1) == queueManager
						.getBatchSegmentJobMap(bJobIdStart).getTimeOut());
				assertTrue(i + 1 == queueManager.getBatchSegmentJobMap(
						bJobIdStart).getFailureCount());
			}
		}
	}

	@Test
	public void testBatchJobTimeout() {
		// get batch job limit time from DB
		long defaultBatchJobTimeout = -1;
		// get batch job limit rerun times From DB
		int reRunLimit = sysConfigDao.getTMaBatchJobReRunLimit();
		//
		Date startTime = new Date(
				(Calendar.getInstance().getTimeInMillis() - 86400000));

		runCase(defaultBatchJobTimeout, reRunLimit, startTime);

		try {
			pollBean.poll();
		} catch (Exception e) {
		}
		if (null != queueManager.getBatchSegmentJobMap(bJobIdStart)
				&& queueManager.getBatchSegmentJobMap(bJobIdStart)
						.getFailureCount() < reRunLimit) {
			assertTrue(1 == queueManager.getBatchSegmentJobMap(bJobIdStart)
					.getFailureCount());
		}
	}

	@Test
	public void testReRunLimit() {
		// get batch job limit time from DB
		long defaultBatchJobTimeout = sysConfigDao.getTMaBatchJobTimeout();
		// get batch job limit rerun times From DB
		int reRunLimit = -1;
		//
		Date startTime = new Date(
				(Calendar.getInstance().getTimeInMillis() - 86400000));

		runCase(defaultBatchJobTimeout, reRunLimit, startTime, 5);

		try {
			pollBean.poll();
		} catch (Exception e) {
		}
		assertTrue(null == queueManager.getBatchSegmentJobMap(bJobIdStart));
		assertTrue(null == queueManager.getIdentifyResult(bJobIdStart));
	}

	@Test
	public void testStartTime() {

		// get batch job limit time from DB
		long defaultBatchJobTimeout = sysConfigDao.getTMaBatchJobTimeout();
		// get batch job limit rerun times From DB
		int reRunLimit = sysConfigDao.getTMaBatchJobReRunLimit();
		//
		Date startTime = null;

		runCase(defaultBatchJobTimeout, reRunLimit, startTime);
		prepareJobDateInDBQueueed(1);

		try {
			pollBean.poll();
		} catch (Exception e) {
		}
		if (null != queueManager.getBatchSegmentJobMap(bJobIdStart)
				&& queueManager.getBatchSegmentJobMap(bJobIdStart)
						.getFailureCount() < reRunLimit) {
			assertTrue(defaultBatchJobTimeout == queueManager
					.getBatchSegmentJobMap(bJobIdStart).getTimeOut());
			Assert.assertNotNull(queueManager
					.getBatchSegmentJobMap(bJobIdStart).getStartTime());
			assertTrue(0 == queueManager.getBatchSegmentJobMap(bJobIdStart)
					.getFailureCount());
		}
	}

	private void runCase(long defaultBatchJobTimeout, int reRunLimit,
			Date startTime) {
		runCase(defaultBatchJobTimeout, reRunLimit, startTime, 0);
	}

	private void runCase(long defaultBatchJobTimeout, int reRunLimit,
			Date startTime, int failureCount) {
		for (int i = 0; i < bJobCount; i++) {
			BatchSegmentJobMap batchSegmentJobMap = UtilCreateData
					.createBatchSegmentJobMapData(bJobIdStart + i, jobCount,
							maxCandidate, segmentIdStart, segmentCount);
			batchSegmentJobMap.setStartTime(startTime);
			batchSegmentJobMap.setFailureCount(failureCount);
			batchSegmentJobMap.setTimeOut(defaultBatchJobTimeout);
			queueManager.add(batchSegmentJobMap);

			queueManager.add(UtilCreateData.createIdentifyResultData(
					bJobIdStart + i, jobCount, maxCandidate, segmentIdStart, 0,
					maxCandidate));
		}
	}

	private void prepareJobDateInDBQueueed(int jobNumber) {
		jdbcTemplate.execute("delete FROM IDENTIFY_BATCH_JOB_QUEUE");
		jdbcTemplate
				.execute("insert into IDENTIFY_BATCH_JOB_QUEUE "
						+ "(BATCHJOB_ID, BATCHJOB_STATUS, ENQUEUE_TS, START_TS, BYURL_COUNT) "
						+ "values (10000, 2, systimestamp, systimestamp, 20)");

	}

}
