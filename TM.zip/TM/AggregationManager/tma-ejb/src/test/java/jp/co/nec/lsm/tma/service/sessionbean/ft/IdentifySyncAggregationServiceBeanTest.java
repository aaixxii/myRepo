package jp.co.nec.lsm.tma.service.sessionbean.ft;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.Map.Entry;

import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;

import javax.annotation.Resource;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto.Candidate;
import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tm.common.communication.SearchJobInfo;
import jp.co.nec.lsm.tm.common.exception.TMRuntimeException;
import jp.co.nec.lsm.tm.protocolbuffer.identify.IdentifyResultRequestProto.IdentifyResultRequest;
import jp.co.nec.lsm.tma.common.util.TMAUtilSwitchEjb;
import jp.co.nec.lsm.tma.common.util.UtilCreateData;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyJobResult;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResultRequestBuilder;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;
import jp.co.nec.lsm.tma.exception.AggregationRuntimeException;
import jp.co.nec.lsm.tma.service.pojo.IdentifySyncAggregationServiceBean;
import jp.co.nec.lsm.tma.sessionbean.api.BatchSegmentJobMapInitializerRemote;
import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.acc.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.acc.proto.protobuf.BusinessMessage.CPBDataBlock;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;

/**
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class IdentifySyncAggregationServiceBeanTest {
	@Resource
	BatchSegmentJobMapInitializerRemote batchSegmentJobMapInitializerBean;
	@Resource
	private IdentifySyncAggregationServiceBean identifySyncAggregationServiceBean;

	private BatchSegmentJobManager queueManager;

	private final static long bJobIdStart = 10000;
	private final static int jobIdStart = 100;
	private final static int jobCount = 1000;
	private final static int segmentIdStart = 1000;
	private static int segmentCount = 2;
	private static int segmentEachCount = 1;
	private static int maxCandidate = 10;

	@Before
	public void setUp() throws Exception {
		queueManager = BatchSegmentJobManager.getInstance();
		queueManager.clear();

		Assert.assertEquals(0, queueManager.getBatchSegmentJobMaps().size());
		Assert.assertEquals(0, queueManager.getIdentifyResults().size());

		// create BatchSegmentJobMap data
		BatchSegmentJobMap batchSegmentJobMap = UtilCreateData
				.createBatchSegmentJobMapData(bJobIdStart, jobIdStart,
						jobCount, maxCandidate, segmentIdStart, segmentCount);
		batchSegmentJobMapInitializerBean
				.receiveBatchJobAndInitSpace(batchSegmentJobMap);

		assertNotNull(queueManager.getBatchSegmentJobMap(bJobIdStart));
		assertNotNull(queueManager.getIdentifyResult(bJobIdStart));
	}

	@After
	public void tearDown() throws Exception {
		queueManager = null;
	}

	@Test
	public void testMergeIdentifyResult2Segment1USC() {
		try {
			IdentifyResult identifyResult = null;
			// first from mu
			identifyResult = UtilCreateData.createIdentifyResultData(
					bJobIdStart, jobIdStart, jobCount, maxCandidate,
					segmentIdStart, segmentCount, maxCandidate);

			// modify memory data
			identifyResult.getSearchJobResults().put(jobIdStart + jobCount - 1, null);
			identifyResult.getSearchJobResults().get(jobIdStart + jobCount - 2).setMaxCandidate(0);
			identifyResult.getSearchJobResults().get(jobIdStart + jobCount - 3).setCandidates(new ObjectArrayList<Candidate>());
			identifyResult.getSearchJobResults().get(jobIdStart + jobCount - 4).setReturnCode(ReturnCode.JobFailed);

			identifySyncAggregationServiceBean.mergeIdentifyResult(TMAUtilSwitchEjb
					.switchIdentifyResult(identifyResult));

			assertNotNull(queueManager.getBatchSegmentJobMap(bJobIdStart));
			assertNotNull(queueManager.getIdentifyResult(bJobIdStart));
			assertEquals(queueManager.getIdentifyResults().size(), 1);
			assertTrue(0 != queueManager.getIdentifyResult(bJobIdStart)
					.getSearchJobResults().get(jobIdStart).getCandidates()
					.get(1).getScaledScore());

			identifyResult = null;
		} catch (Exception e) {
			if (e instanceof TMRuntimeException) {
				assertNotNull(queueManager
						.getBatchSegmentJobMap(bJobIdStart));
				assertNotNull(queueManager
						.getIdentifyResult(bJobIdStart));
			} else {
				throw new AggregationRuntimeException("");
			}
		}
	}

	@Test
	public void testMergeIdentifyResult2Segment2USC() {
		try {
			IdentifyResult identifyResult = null;
			// first data from mu
			identifyResult = UtilCreateData.createIdentifyResultData(
					bJobIdStart, jobIdStart, jobCount, maxCandidate,
					segmentIdStart, segmentEachCount, maxCandidate);

			// modify memory data
			identifyResult.getSearchJobResults().put(jobIdStart + jobCount - 1, null);
			identifyResult.getSearchJobResults().get(jobIdStart + jobCount - 2).setMaxCandidate(0);
			identifyResult.getSearchJobResults().get(jobIdStart + jobCount - 3).setCandidates(new ObjectArrayList<Candidate>());
			identifyResult.getSearchJobResults().get(jobIdStart + jobCount - 4).setReturnCode(ReturnCode.JobFailed);

			identifySyncAggregationServiceBean.mergeIdentifyResult(TMAUtilSwitchEjb
					.switchIdentifyResult(identifyResult));

			assertNotNull(queueManager.getBatchSegmentJobMap(bJobIdStart));
			assertNotNull(queueManager.getIdentifyResult(bJobIdStart));
			assertEquals(queueManager.getIdentifyResults().size(), 1);
			assertTrue(0 != queueManager.getIdentifyResult(bJobIdStart)
					.getSearchJobResults().get(jobIdStart).getCandidates()
					.get(1).getScaledScore());

			identifyResult = null;

			// second data from mu
			identifyResult = UtilCreateData.createIdentifyResultData(
					bJobIdStart, jobIdStart, jobCount, maxCandidate,
					segmentIdStart + segmentEachCount, segmentEachCount,
					maxCandidate);

			identifyResult.getSearchJobResults().put(jobIdStart + jobCount - 5, null);
			identifyResult.getSearchJobResults().get(jobIdStart + jobCount - 6).setMaxCandidate(0);
			identifyResult.getSearchJobResults().get(jobIdStart + jobCount - 7).setCandidates(new ObjectArrayList<Candidate>());
			identifyResult.getSearchJobResults().get(jobIdStart + jobCount - 8).setReturnCode(ReturnCode.JobFailed);

			identifySyncAggregationServiceBean.mergeIdentifyResult(TMAUtilSwitchEjb
					.switchIdentifyResult(identifyResult));

			assertNotNull(queueManager.getBatchSegmentJobMap(bJobIdStart));
			assertNotNull(queueManager.getIdentifyResult(bJobIdStart));
			assertEquals(queueManager.getIdentifyResults().size(), 1);
			assertTrue(0 != queueManager.getIdentifyResult(bJobIdStart)
					.getSearchJobResults().get(jobIdStart).getCandidates()
					.get(1).getScaledScore());

			identifyResult = null;
		} catch (Exception e) {
			if (e instanceof TMRuntimeException) {
				assertNotNull(queueManager
						.getBatchSegmentJobMap(bJobIdStart));
				assertNotNull(queueManager
						.getIdentifyResult(bJobIdStart));
			} else {
				throw new AggregationRuntimeException("");
			}
		}
	}

	@Test
	public void testMergeIdentifyResult3Segment2USC() {
		segmentCount = 3;

		try {
			IdentifyResult identifyResult = null;
			// first data from mu
			identifyResult = UtilCreateData.createIdentifyResultData(
					bJobIdStart, jobIdStart, jobCount, maxCandidate,
					segmentIdStart, segmentEachCount, maxCandidate);

			// modify memory data
			identifyResult.getSearchJobResults().put(jobIdStart + jobCount - 1, null);
			identifyResult.getSearchJobResults().get(jobIdStart + jobCount - 2).setMaxCandidate(0);
			identifyResult.getSearchJobResults().get(jobIdStart + jobCount - 3).setCandidates(new ObjectArrayList<Candidate>());
			identifyResult.getSearchJobResults().get(jobIdStart + jobCount - 4).setReturnCode(ReturnCode.JobFailed);

			identifySyncAggregationServiceBean.mergeIdentifyResult(TMAUtilSwitchEjb
					.switchIdentifyResult(identifyResult));

			assertNotNull(queueManager.getBatchSegmentJobMap(bJobIdStart));
			assertNotNull(queueManager.getIdentifyResult(bJobIdStart));
			assertEquals(queueManager.getIdentifyResults().size(), 1);
			assertTrue(0 != queueManager.getIdentifyResult(bJobIdStart)
					.getSearchJobResults().get(jobIdStart).getCandidates()
					.get(1).getScaledScore());

			identifyResult = null;

			// second data from mu
			identifyResult = UtilCreateData.createIdentifyResultData(
					bJobIdStart, jobIdStart, jobCount, maxCandidate,
					segmentIdStart + segmentEachCount, segmentEachCount,
					maxCandidate);

			identifyResult.getSearchJobResults().put(jobIdStart + jobCount - 5, null);
			identifyResult.getSearchJobResults().get(jobIdStart + jobCount - 6).setMaxCandidate(0);
			identifyResult.getSearchJobResults().get(jobIdStart + jobCount - 7).setCandidates(new ObjectArrayList<Candidate>());
			identifyResult.getSearchJobResults().get(jobIdStart + jobCount - 8).setReturnCode(ReturnCode.JobFailed);

			identifySyncAggregationServiceBean.mergeIdentifyResult(TMAUtilSwitchEjb
					.switchIdentifyResult(identifyResult));

			assertNotNull(queueManager.getBatchSegmentJobMap(bJobIdStart));
			assertNotNull(queueManager.getIdentifyResult(bJobIdStart));
			assertEquals(queueManager.getIdentifyResults().size(), 1);
			assertTrue(0 != queueManager.getIdentifyResult(bJobIdStart)
					.getSearchJobResults().get(jobIdStart).getCandidates()
					.get(1).getScaledScore());

			identifyResult = null;

			// third data from mu
			identifyResult = UtilCreateData.createIdentifyResultData(
					bJobIdStart, jobIdStart, jobCount, maxCandidate,
					segmentIdStart + segmentEachCount * 2, segmentEachCount,
					maxCandidate);

			identifyResult.getSearchJobResults().put(jobIdStart + jobCount - 9, null);
			identifyResult.getSearchJobResults().get(jobIdStart + jobCount - 10).setMaxCandidate(0);
			identifyResult.getSearchJobResults().get(jobIdStart + jobCount - 11).setCandidates(new ObjectArrayList<Candidate>());
			identifyResult.getSearchJobResults().get(jobIdStart + jobCount - 12).setReturnCode(ReturnCode.JobFailed);

			identifySyncAggregationServiceBean.mergeIdentifyResult(TMAUtilSwitchEjb
					.switchIdentifyResult(identifyResult));

			identifyResult = null;
		} catch (Exception e) {
			if (e instanceof TMRuntimeException) {
				assertNotNull(queueManager
						.getBatchSegmentJobMap(bJobIdStart));
				assertNotNull(queueManager
						.getIdentifyResult(bJobIdStart));
			} else {
				throw new AggregationRuntimeException("");
			}
		}
	}

	@Test
	public void testMergeIdentifyResultNull() {
		//Verify the data from MU is valid.
		queueManager.clear();
		try {
			identifySyncAggregationServiceBean.mergeIdentifyResult(null);
		} catch (Exception e) {
			assertNull(queueManager
					.getBatchSegmentJobMap(bJobIdStart));
			assertNull(queueManager
					.getIdentifyResult(bJobIdStart));
		}
	}

	@Test
	public void testMergeIdentifyResultNotNullBatchSegmentJobMapNull() {
		//Verify the data whether is the requirements of the query data for the TMI.
		queueManager.clear();
		BatchSegmentJobMap batchSegmentJobMap = queueManager.getBatchSegmentJobMap(bJobIdStart);
		assertNull(batchSegmentJobMap);

		IdentifyResult identifyResult = UtilCreateData.createIdentifyResultData(
				bJobIdStart, jobIdStart, jobCount, maxCandidate,
				segmentIdStart, segmentEachCount, maxCandidate);

		identifySyncAggregationServiceBean.mergeIdentifyResult(TMAUtilSwitchEjb
				.switchIdentifyResult(identifyResult));
	}

	@Test
	public void testReceiveBatchJobAnd() {
		queueManager.clear();
		maxCandidate = 0;

		long batchJobId = bJobIdStart;

		BatchSegmentJobMap batchSegmentJobMap = UtilCreateData.createBatchSegmentJobMapData(
				batchJobId, jobIdStart, jobCount, maxCandidate, segmentIdStart,
				segmentCount);

		batchSegmentJobMapInitializerBean
				.receiveBatchJobAndInitSpace(batchSegmentJobMap);

		Assert.assertNotNull(queueManager.getBatchSegmentJobMap(batchJobId));
		
		for (SearchJobInfo jobInfo : queueManager.getBatchSegmentJobMap(batchJobId).getSearchJobInfos()) {
			Assert.assertEquals(0, jobInfo.getMaxCandidate());
		}

		Assert.assertNotNull(queueManager.getIdentifyResult(batchJobId));
		Int2ObjectArrayMap<IdentifyJobResult> jobResultMap = queueManager.getIdentifyResult(batchJobId).getSearchJobResults();
		for (Entry<Integer, IdentifyJobResult> entry : jobResultMap.entrySet()) {
			Assert.assertEquals(maxCandidate + 1, entry.getValue().getCandidates().size());
		}

		// test Prepare IdentifyResultRequest
		IdentifyResultRequest resultRequest = IdentifyResultRequestBuilder.createIdentifyResultRequest(queueManager.getIdentifyResult(batchJobId));
		
		Assert.assertEquals(jobCount, resultRequest.getBusinessMessageCount());
		
		try {
			for (int i = 0; i < jobCount; i++) {
				ByteString byteString = resultRequest.getBusinessMessage(i);
				CPBBusinessMessage businessMsg = CPBBusinessMessage.parseFrom(byteString);
				// CPBDataBlock
				CPBDataBlock dataBlock = businessMsg.getDataBlock();
				Assert.assertEquals(0, dataBlock.getCandidateList().getCandidatesCount());
				Assert.assertFalse(dataBlock.getCandidateList().getMore());
			}
		} catch (InvalidProtocolBufferException e) {
			e.printStackTrace();
		}
		
		int[] memoryScores = { 9999 };
		IdentifyResult identifyResult = UtilCreateData.createIdentifyResultData(
				bJobIdStart, jobIdStart, jobCount, memoryScores,
				segmentCount, maxCandidate);
		identifySyncAggregationServiceBean.mergeIdentifyResult(TMAUtilSwitchEjb
				.switchIdentifyResult(identifyResult));
		
		// test Prepare IdentifyResultRequest
		resultRequest = IdentifyResultRequestBuilder.createIdentifyResultRequest(queueManager.getIdentifyResult(batchJobId));
		
		Assert.assertEquals(jobCount, resultRequest.getBusinessMessageCount());
		
		try {
			for (int i = 0; i < jobCount; i++) {
				ByteString byteString = resultRequest.getBusinessMessage(i);
				CPBBusinessMessage businessMsg = CPBBusinessMessage.parseFrom(byteString);
				// CPBDataBlock
				CPBDataBlock dataBlock = businessMsg.getDataBlock();
				Assert.assertEquals(0, dataBlock.getCandidateList().getCandidatesCount());
				Assert.assertFalse(dataBlock.getCandidateList().getMore());
			}
		} catch (InvalidProtocolBufferException e) {
			e.printStackTrace();
		}
	}
}
