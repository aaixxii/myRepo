package jp.co.nec.lsm.tma.common.util;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto;
import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto.Candidate;
import jp.co.nec.lsm.proto.identify.IdentifyJobResultRequestProto.IdentifyJobResultRequest;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyJobResult;
import jp.co.nec.lsm.tma.core.clientapi.response.IdentifyResult;

public final class TMAUtilSwitchEjb {

	/**
	 * switch IdentifyResult to IdentifyResultRequest
	 * 
	 * @param identifyResult
	 * @return
	 */
	public final static IdentifyJobResultRequest switchIdentifyResult(IdentifyResult identifyResult) {
		IdentifyJobResultRequest.Builder jobResultRequestBuilder = IdentifyJobResultRequest.newBuilder();
		jobResultRequestBuilder.setGmvId(1000);
		jobResultRequestBuilder.setReadCount(0L);
		jobResultRequestBuilder.setBatchJobId(identifyResult.getBatchJobId()).addAllSegmentId(
				identifyResult.getSegmentIds());

		IdentifyJobResultRequestProto.IdentifyJobResult.Builder jobResultBuilder;

		for (IdentifyJobResult jobResult : identifyResult.getSearchJobResults().values()) {
			if(null != jobResult) {
				jobResultBuilder = IdentifyJobResultRequestProto.IdentifyJobResult.newBuilder();

				jobResultBuilder.setJobIndex(jobResult.getJobIndex()).setReturnCode(jobResult.getReturnCode())
						.addAllCandidate(jobResult.getCandidates());

				jobResultRequestBuilder.addIdentifyJobResult(jobResultBuilder);
			}
		}
		return jobResultRequestBuilder.build();
	}

	/**
	 * candidate ObjectArrayList to Object array
	 * 
	 * @param candidateList
	 * @return
	 */
	public static Object[] switchCandidates(ObjectArrayList<Candidate> candidateList) {
		return candidateList.elements();
	}

}
