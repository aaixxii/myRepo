package jp.co.nec.lsm.tma.service.sessionbean;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.lsm.tm.common.constants.ConfigProperty;
import jp.co.nec.lsm.tm.common.constants.SystemConfigNamespace;
import jp.co.nec.lsm.tm.common.constants.TMType;
import jp.co.nec.lsm.tm.common.constants.TmState;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.common.util.Version;
import jp.co.nec.lsm.tm.db.common.entities.TransactionManagerEntity;
import jp.co.nec.lsm.tm.db.common.entityhelpers.SystemConfigHelper;
import jp.co.nec.lsm.tm.db.common.entityhelpers.TransactionManagerHelper;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class AggregationInitializationBeanTest {
	@Resource
	private AggregationInitializationLocal initializationBean;
	@PersistenceContext(unitName = "tma-unit")
	private EntityManager manager;

	private Properties properties = new Properties();
	private TransactionManagerHelper tmHelper;

	protected JdbcTemplate jdbcTemplate;
	@Resource
	private DataSource dataSource;

	@Before
	public void setUp() throws Exception {
		setMockMethodJMS();
		setMockMethodVersion();
	}

	private void setMockMethodJMS() {
		new MockUp<AggregationInitializationBean>() {
			@Mock
			@SuppressWarnings("unused")
			public void removeJmsMessage(String queueName) {
				return;
			}

			@Mock
			@SuppressWarnings("unused")
			public void startTimer() {
				return;
			}
		};
	}

	private void setMockMethodVersion() {
		new MockUp<Version>() {
			@Mock
			@SuppressWarnings("unused")
			public String readVersion(String warFile, String groupId,
					String artifactId) {
				return "1.0.0";
			}
		};
	}

	@PostConstruct
	public void init() {
		tmHelper = new TransactionManagerHelper(manager, TMType.TMA);
		jdbcTemplate = new JdbcTemplate(dataSource);
		try {
			InputStream is = ConfigProperty.class.getClassLoader()
					.getResourceAsStream(
							SystemConfigNamespace.TM
									.getDefaultPropertiesFilename());
			properties.load(is);
			is.close();
		} catch (IOException e) {
		}
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testInitialization() {

		jdbcTemplate.execute("delete from SYSTEM_CONFIG");

		initializationBean.initializeAggregation();

		SystemConfigHelper helper = new SystemConfigHelper(manager);
		Set<Entry<Object, Object>> entrySet = properties.entrySet();
		for (Entry<Object, Object> e : entrySet) {
			String key = (String) e.getKey();
			String value = properties.getProperty(key);
			assertEquals(helper.getTMProperty(key), value);
		}

		TransactionManagerEntity tm = tmHelper.createOrLookup(DateUtil
				.getCurrentDate());

		// 2 - assert concerning information
		assertNotNull(tm);
		assertNotNull(tm.getLastHeartbeatTs());
		assertNotNull(tm.getLastPollTs());
		assertEquals(TmState.WORKING, tm.getState());
	}

}
