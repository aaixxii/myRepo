package jp.co.nec.lsm.tma.service.sessionbean.ft;

import javax.annotation.Resource;

import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tma.common.util.UtilCreateData;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;
import jp.co.nec.lsm.tma.exception.AggregationRuntimeException;
import jp.co.nec.lsm.tma.sessionbean.api.BatchSegmentJobMapInitializerRemote;
import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

/**
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class BatchSegmentJobMapInitializerBeanTest {
	
	@Resource
	BatchSegmentJobMapInitializerRemote batchSegmentJobMapInitializerBean;

	private BatchSegmentJobManager queueManager;

	private final static long bJobIdStart = 10000;
	private final static int jobIdStart = 100;
	private final static int jobCount = 1000;
	private final static int segmentIdStart = 1000;
	private final static int segmentCount = 20;
	private final static int maxCandidate = 10;

	@Before
	public void setUp() throws Exception {
		queueManager = BatchSegmentJobManager.getInstance();
		queueManager.clear();
	}

	@After
	public void tearDown() throws Exception {
		queueManager = null;
	}

	@Test
	public void testReceiveBatchJobAndInitSpace() {
		queueManager.clear();
		Assert.assertEquals(0, queueManager.getBatchSegmentJobMaps().size());
		Assert.assertEquals(0, queueManager.getIdentifyResults().size());

		long batchJobId = bJobIdStart;

		// test BatchSegmentJobMap is null
		BatchSegmentJobMap batchSegmentJobMap = null;
		try {
			batchSegmentJobMapInitializerBean
					.receiveBatchJobAndInitSpace(batchSegmentJobMap);
		} catch (AggregationRuntimeException e) {
			Assert.assertNull(queueManager.getBatchSegmentJobMap(batchJobId));
			Assert.assertNull(queueManager.getIdentifyResult(batchJobId));
		}

		// test SearchJobInfo list is null
		batchJobId = bJobIdStart + 1;

		batchSegmentJobMap = UtilCreateData.createBatchSegmentJobMapData(
				batchJobId, jobIdStart, jobCount, maxCandidate, segmentIdStart,
				segmentCount);
		batchSegmentJobMap.setSearchJobInfos(null);

		try {
			batchSegmentJobMapInitializerBean
					.receiveBatchJobAndInitSpace(batchSegmentJobMap);
		} catch (AggregationRuntimeException e) {
			Assert.assertNull(queueManager.getBatchSegmentJobMap(batchJobId));
			Assert.assertNull(queueManager.getIdentifyResult(batchJobId));
		}

		// test other
		batchJobId = bJobIdStart + 2;

		batchSegmentJobMap = UtilCreateData.createBatchSegmentJobMapData(
				batchJobId, jobIdStart, jobCount, maxCandidate, segmentIdStart,
				segmentCount);

		batchSegmentJobMap.getSearchJobInfos().set(0, null);
		
		Assert.assertNotNull(batchSegmentJobMap.getStartTime());

		batchSegmentJobMapInitializerBean
				.receiveBatchJobAndInitSpace(batchSegmentJobMap);

		Assert.assertNotNull(batchSegmentJobMap.getStartTime());

		Assert.assertNotNull(queueManager.getBatchSegmentJobMap(batchJobId));
		Assert.assertEquals(segmentCount, queueManager
				.getSegmentIds(batchJobId).size());
		Assert.assertEquals(jobCount,
				queueManager.getBatchSegmentJobMap(batchJobId)
						.getSearchJobInfos().size());

		Assert.assertNotNull(queueManager.getIdentifyResult(batchJobId));
		Assert.assertEquals(segmentCount,
				queueManager.getSegmentJobMaps(batchJobId).size());
		Assert.assertEquals(jobCount - 1, queueManager
				.getIdentifyResult(batchJobId).getSearchJobResults().size());
	}

}
