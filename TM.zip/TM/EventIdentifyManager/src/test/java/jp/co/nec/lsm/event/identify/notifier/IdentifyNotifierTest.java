package jp.co.nec.lsm.event.identify.notifier;

import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.jms.Queue;

import jp.co.nec.lsm.event.Event;
import jp.co.nec.lsm.event.identify.IdentifyAbstractEvent;
import jp.co.nec.lsm.event.identify.IdentifyPrepareTemplateEvent;
import jp.co.nec.lsm.event.identify.constants.IdentifyNotifierEnum;
import jp.co.nec.lsm.event.identify.constants.IdentifyReceiverEnum;
import jp.co.nec.lsm.tm.common.constants.JNDIConstants;
import jp.co.nec.lsm.tm.common.util.ServiceLocator;
import junit.framework.Assert;
import mockit.Mock;
import mockit.MockUp;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.broker.BrokerService;
import org.apache.activemq.command.ActiveMQQueue;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.jms.connection.SingleConnectionFactory;
import org.springframework.jms.listener.DefaultMessageListenerContainer;

public class IdentifyNotifierTest {

	private ConnectionFactory jmsFactory;
	private Queue queueDestination;

	private  Event receivedEvent;
	private  boolean isNotReceived = true;
	private int rerunLimit = 50;
	long batchJobId = 12122L;

	static BrokerService broker = new BrokerService();

	@BeforeClass
	public static void startService() throws Exception {
		broker.setBrokerName("one");
		broker.setPersistent(false);
		broker.start();
	}

	@AfterClass
	public static void stopService() throws Exception {
		broker.stop();
	}

	/**
	 * setMockMethod
	 */
	public void setJMSMockMethod(final String jndiQueueName) {
		new MockUp<ServiceLocator>() {
			@SuppressWarnings("unused")
			@Mock
			private Object lookUpJndiObject(String jndiName) {
				if (jndiName.equals(JNDIConstants.CONNECTION_FACTORY)) {
					return jmsFactory;
				} else if (jndiName.equals(jndiQueueName)) {
					return queueDestination;
				}
				return null;
			}

			@SuppressWarnings("unused")
			@Mock
			private Object lookUpJndiObjectReomte(String jndiName, String ip) {
				if (jndiName.equals(JNDIConstants.CONNECTION_FACTORY)) {
					return jmsFactory;
				} else if (jndiName.equals(jndiQueueName)) {
					return queueDestination;
				}
				return null;
			}
		};
	}

	@Test
	public void testSendPrepareTemplateEvent() throws Exception {
		setJMSMockMethod("queue/identify_prepare_template_event");
		DefaultMessageListenerContainer listener = null;
		try {
			listener = startServiceAndListener("identify_prepare_template_event");
			Thread thread = new Thread(new Runnable() {
				@Override
				public void run() {
					IdentifyNotifier notify = new IdentifyNotifier();
					IdentifyAbstractEvent event = new IdentifyPrepareTemplateEvent(
							12122L, IdentifyNotifierEnum.IdentifyAcceptService,
							IdentifyReceiverEnum.IdentifyPrepareTemplateService);
					notify.sendEvent(event);
				}
			});

			thread.start();
			thread.join();
			assertResult(12122L,
					IdentifyReceiverEnum.IdentifyPrepareTemplateService.name());
		} finally {
			if (listener != null) {
				listener.stop();
				listener.destroy();
			}
			
		}
	}

	@Test
	public void testSendSyncWithAggregationEvent() throws Exception {
		setJMSMockMethod("queue/identify_queue_event");
		DefaultMessageListenerContainer listener = null;
		try {
			listener = startServiceAndListener("identify_queue_event");
			Thread thread = new Thread(new Runnable() {
				@Override
				public void run() {
					IdentifyNotifier notify = new IdentifyNotifier();
					IdentifyAbstractEvent event = new IdentifyPrepareTemplateEvent(
							1213222L,
							IdentifyNotifierEnum.IdentifyAcceptService,
							IdentifyReceiverEnum.IdentifySyncWithAggregationServiceBean);
					notify.sendEvent(event);
				}
			});

			thread.start();
			thread.join();

			assertResult(1213222L,
					IdentifyReceiverEnum.IdentifySyncWithAggregationServiceBean
							.name());
		} finally {
			if (listener != null) {
				listener.stop();
				listener.destroy();
			}
		}
	}

	@Test
	public void testSendBatchJobResultEvent() throws Exception {
		setJMSMockMethod("queue/aggregation_queue_event");
		DefaultMessageListenerContainer listener = null;
		try {
			listener = startServiceAndListener("aggregation_queue_event");
			Thread thread = new Thread(new Runnable() {
				@Override
				public void run() {
					IdentifyNotifier notify = new IdentifyNotifier();
					IdentifyAbstractEvent event = new IdentifyPrepareTemplateEvent(
							12132223L,
							IdentifyNotifierEnum.IdentifyAcceptService,
							IdentifyReceiverEnum.IdentifyBatchJobResultService);
					notify.sendEvent(event);
				}
			});

			thread.start();
			thread.join();

			assertResult(12132223L,
					IdentifyReceiverEnum.IdentifyBatchJobResultService.name());
		} finally {
			if (listener != null) {
				listener.stop();
				listener.destroy();
			}
		}
	}

	@Test
	public void testJobPollTimerEvent() throws Exception {
		setJMSMockMethod("queue/identify_queue_event");
		DefaultMessageListenerContainer listener = null;
		try {
			listener = startServiceAndListener("identify_queue_event");
			Thread thread = new Thread(new Runnable() {
				@Override
				public void run() {
					IdentifyNotifier notify = new IdentifyNotifier();
					IdentifyAbstractEvent event = new IdentifyPrepareTemplateEvent(
							12132225L,
							IdentifyNotifierEnum.IdentifyAcceptService,
							IdentifyReceiverEnum.IdentifyJobPollTimerStartBean);
					notify.sendEvent(event);
				}
			});

			thread.start();
			thread.join();

			assertResult(12132225L,
					IdentifyReceiverEnum.IdentifyJobPollTimerStartBean.name());
		} finally {
			if (listener != null) {
				listener.stop();
				listener.destroy();
			}
		}
	}

	@Test
	public void testUSCPollTimerEvent() throws Exception {
		setJMSMockMethod("queue/identify_queue_event");
		
		DefaultMessageListenerContainer listener = null;
		try {
			listener = startServiceAndListener("identify_queue_event");
			Thread thread = new Thread(new Runnable() {
				@Override
				public void run() {
					IdentifyNotifier notify = new IdentifyNotifier();
					IdentifyAbstractEvent event = new IdentifyPrepareTemplateEvent(
							12132226L,
							IdentifyNotifierEnum.IdentifyAcceptService,
							IdentifyReceiverEnum.IdentifyUSCPollTimerStartBean);
					notify.sendEvent(event);
				}
			});

			thread.start();
			thread.join();

			assertResult(12132226L,
					IdentifyReceiverEnum.IdentifyUSCPollTimerStartBean.name());
		} finally {
			if (listener != null) {
				listener.stop();
				listener.destroy();
			}
		}
	}

	@Test
	public void testDeliveryCheckEvent() throws Exception {
		setJMSMockMethod("queue/identify_queue_event");
		DefaultMessageListenerContainer listener = null;
		try {
			listener = startServiceAndListener("identify_queue_event");
			Thread thread = new Thread(new Runnable() {
				@Override
				public void run() {
					IdentifyNotifier notify = new IdentifyNotifier();
					IdentifyAbstractEvent event = new IdentifyPrepareTemplateEvent(
							12132227L,
							IdentifyNotifierEnum.IdentifyAcceptService,
							IdentifyReceiverEnum.BatchJobDeliveryCheckPollTimerStarterBean);
					notify.sendEvent(event);
				}
			});
			thread.start();
			thread.join();
			assertResult(
					12132227L,
					IdentifyReceiverEnum.BatchJobDeliveryCheckPollTimerStarterBean
							.name());
		} finally {
			if (listener != null) {
				listener.stop();
				listener.destroy();
			}
		}
	}

	@Test
	public void testGetIdentifyBatchJobEvent() throws Exception {
		setJMSMockMethod("queue/identify_queue_event");
		DefaultMessageListenerContainer listener = null;
		try {
			listener = startServiceAndListener("identify_queue_event");
			Thread thread = new Thread(new Runnable() {
				@Override
				public void run() {
					IdentifyNotifier notify = new IdentifyNotifier();
					IdentifyAbstractEvent event = new IdentifyPrepareTemplateEvent(
							12132228L,
							IdentifyNotifierEnum.IdentifyAcceptService,
							IdentifyReceiverEnum.GetIdentifyBatchJobPollTimerStarterBean);
					notify.sendEvent(event);
				}
			});
			thread.start();
			thread.join();
			assertResult(
					12132228L,
					IdentifyReceiverEnum.GetIdentifyBatchJobPollTimerStarterBean
							.name());
		} finally {
			if (listener != null) {
				listener.stop();
				listener.destroy();
			}
		}
	}

	@Test
	public void testPrepareSegmentJobEvent() throws Exception {
		setJMSMockMethod("queue/identify_queue_event");
		DefaultMessageListenerContainer listener = null;
		try {
			listener = startServiceAndListener("identify_queue_event");
			Thread thread = new Thread(new Runnable() {
				@Override
				public void run() {
					IdentifyNotifier notify = new IdentifyNotifier();
					IdentifyAbstractEvent event = new IdentifyPrepareTemplateEvent(
							12132229L,
							IdentifyNotifierEnum.IdentifyAcceptService,
							IdentifyReceiverEnum.IdentifyPrepareSegmentJobService);
					notify.sendEvent(event);
				}
			});
			thread.start();
			thread.join();
			assertResult(12132229L,
					IdentifyReceiverEnum.IdentifyPrepareSegmentJobService
							.name());
		} finally {
			if (listener != null) {
				listener.stop();
				listener.destroy();
			}
		}
	}

	/**
	 * startServiceAndListener
	 * 
	 * @throws Exception
	 */
	private DefaultMessageListenerContainer startServiceAndListener(
			String queueName) throws Exception {

		jmsFactory = new ActiveMQConnectionFactory(
				"vm://localhost?broker.persistent=false");
		queueDestination = new ActiveMQQueue(queueName);
		final SingleConnectionFactory singleConnectionFactory1 = new SingleConnectionFactory(
				jmsFactory);

		DefaultMessageListenerContainer listener = new DefaultMessageListenerContainer();
		listener.setConnectionFactory(singleConnectionFactory1);
		listener.setDestination(queueDestination);

		listener.setMessageListener(new MessageListener() {
			public void onMessage(Message message) {
				if (message instanceof ObjectMessage) {
					ObjectMessage objMsg = (ObjectMessage) message;
					try {
						receivedEvent = (Event) objMsg.getObject();
					} catch (JMSException e) {
					}
				}
				isNotReceived = false;
			}
		});
		listener.afterPropertiesSet();
		listener.start();
		Thread.sleep(1000);
		return listener;
	}

	/**
	 * asserts
	 */
	private void assertResult(long batchJobId, String seletorName) {
		int run = 0;
		while (isNotReceived && run++ <= rerunLimit) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		if (run > rerunLimit) {
			Assert.fail();
		}

		if (receivedEvent == null) {
			Assert.fail();
		}

		long receivedBatchJobId = receivedEvent.getBatchJobId();
		String messageSeletor = receivedEvent.getMessageSelector();

		Assert.assertEquals(batchJobId, receivedBatchJobId);
		Assert.assertEquals(messageSeletor, seletorName);
	}
}
