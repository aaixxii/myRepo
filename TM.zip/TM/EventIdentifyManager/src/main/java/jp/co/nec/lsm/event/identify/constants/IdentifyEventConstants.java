package jp.co.nec.lsm.event.identify.constants;

/**
 * @author liuyq <br>
 *         identify enent
 * 
 */
public class IdentifyEventConstants {
	/** default jboss jndi port **/
	public static final int JBOSS_DEFAULT_JNDI_PORT = 1099;
	/** default string empty **/
	public static final String EMPTY_STRING_VALUE = "";
	/** default local IP address **/
	public static final String DEFAULT_IP_ADDRESS = "127.0.0.1";
	public static final int BATCH_JOB_FAILURE_COUNT = 5;
	public static final int BATCH_JOB_TIME_OUT = 300000;
	
}
