package jp.co.nec.lsm.event.identify;

import jp.co.nec.lsm.event.Event;
import jp.co.nec.lsm.event.identify.constants.IdentifyEventConstants;
import jp.co.nec.lsm.event.identify.constants.IdentifyNotifierEnum;
import jp.co.nec.lsm.event.identify.constants.IdentifyReceiverEnum;

/**
 * @author jimy <br>
 * 
 */
public abstract class IdentifyAbstractEvent implements Event {

	/**
	 * serialVersionUID default 1L
	 */
	private static final long serialVersionUID = 1L;

	private String ipAddress = IdentifyEventConstants.DEFAULT_IP_ADDRESS;
	private long batchJobId;
	private IdentifyNotifierEnum identifyNotifier; // from
	private IdentifyReceiverEnum identifyReceiver; // send to

	@Override
	public String getMessageSelector() {
		return getIdentifyReceiver().name();
	}

	/**
	 * getIpAddress
	 * 
	 * @return ipAddress
	 */
	public String getIpAddress() {
		if (null == ipAddress || "".equals(ipAddress)) {
			ipAddress = IdentifyEventConstants.DEFAULT_IP_ADDRESS;
		}
		return ipAddress;
	}

	/**
	 * setIpAddress
	 * 
	 * @param ipAddress
	 */
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	@Override
	public String[] getTraceMessage() {
		if (identifyNotifier == null || identifyReceiver == null)
			return null;
		String[] traceMessages = new String[] { "NOTIFIER",
				identifyNotifier.getDetailMessage(), "RECEIVER",
				identifyReceiver.getDetailMessage() };
		return traceMessages;
	}

	@Override
	public long getBatchJobId() {
		return batchJobId;
	}

	public void setBatchJobId(long batchJobId) {
		this.batchJobId = batchJobId;
	}

	public IdentifyReceiverEnum getIdentifyReceiver() {
		return identifyReceiver;
	}

	public void setIdentifyReceiver(IdentifyReceiverEnum receiver) {
		this.identifyReceiver = receiver;
	}

	public IdentifyNotifierEnum getIdentifyNotifier() {
		return identifyNotifier;
	}

	public void setIdentifyNotifier(IdentifyNotifierEnum notify) {
		this.identifyNotifier = notify;
	}
}
