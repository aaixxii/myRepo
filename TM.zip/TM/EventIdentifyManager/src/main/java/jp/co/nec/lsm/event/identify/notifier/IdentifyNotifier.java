package jp.co.nec.lsm.event.identify.notifier;

import jp.co.nec.lsm.event.identify.IdentifyAbstractEvent;
import jp.co.nec.lsm.event.identify.constants.IdentifyEventRuntimeException;
import jp.co.nec.lsm.event.sender.EventSender;
import jp.co.nec.lsm.event.sender.EventSenderJMSLocalImpl;
import jp.co.nec.lsm.event.sender.EventSenderJMSRemoteImpl;
import jp.co.nec.lsm.tm.common.constants.JNDIConstants;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author liuyq <br>
 * 
 */
public class IdentifyNotifier implements IdentifyEventNotifier {
	/** log instance **/
	private static Logger log = LoggerFactory.getLogger(IdentifyNotifier.class);

	protected IdentifyAbstractEvent event;

	@Override
	public void sendEvent(IdentifyAbstractEvent event) {
		printLogMessage("start public function eventNotify.");

		EventSender eventSender = null;

		switch (event.getIdentifyReceiver()) {

		case IdentifySyncWithAggregationServiceBean:
			eventSender = EventSenderJMSRemoteImpl.getInstance(
					event.getIpAddress(), JNDIConstants.IDENTIFY_QUEUE);
			break;
		case IdentifyBatchJobResultService:
			eventSender = EventSenderJMSLocalImpl
					.getInstance(JNDIConstants.AGGREGATION_QUEUE);
			break;
		case IdentifyPrepareTemplateService:
			eventSender = EventSenderJMSLocalImpl
					.getInstance(JNDIConstants.IDENTIFY_PREPARE_TMEPLATE_QUEUE);
			break;
		case IdentifyJobPollTimerStartBean:
		case IdentifyUSCPollTimerStartBean:
		case BatchJobDeliveryCheckPollTimerStarterBean:
		case GetIdentifyBatchJobPollTimerStarterBean:
		case IdentifyPrepareSegmentJobService:
			eventSender = EventSenderJMSLocalImpl
					.getInstance(JNDIConstants.IDENTIFY_QUEUE);
			break;

		default:
			throw new IdentifyEventRuntimeException(
					"the event is not support..");
		}

		IdentifyAbstractEvent identifyEvent = (IdentifyAbstractEvent) event;
		eventSender.convertAndSend(identifyEvent);
		printLogMessage("end public function eventNotify.");

	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
