package jp.co.nec.lsm.event.identify.notifier;

import jp.co.nec.lsm.event.identify.IdentifyAbstractEvent;

/**
 * @author liuyq <br>
 * 
 */
public interface IdentifyEventNotifier {
	public void sendEvent(IdentifyAbstractEvent event);
}
