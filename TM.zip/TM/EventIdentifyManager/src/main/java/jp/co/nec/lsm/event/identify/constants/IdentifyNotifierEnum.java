package jp.co.nec.lsm.event.identify.constants;

/**
 * @author liuyq <br>
 * 
 */
public enum IdentifyNotifierEnum {

	// notifier: TMI System Initialization service
	SystemInitializationBean("TMI_SystemInitializationBean"),
	
	// notifier: TMI Accepted service
	IdentifyAcceptService("TMI_AcceptService"),

	// notifier: TMI PrepareTemplate service
	IdentifyPrepareTemplateService("TMI_PrepareTemplateService"),

	// notifier: TMI PrepareSegmentJob service
	IdentifyPrepareSegmentJobService("TMI_PrepareSegmentJobService"),

	// notifier: TMA SyncAggregation service
	IdentifySyncAggregationService("TMA_SyncAggregationService"),

	// notifier: TMA BatchJobResult service
	IdentifyBatchJobResultService("TMA_BatchJobResultService"),

	// notifier: TMA Poll bean service
	IdentifyTmaPollbeanService("TMA_PollbeanService")
	;

	private String detailMessage;

	public String getDetailMessage() {
		return detailMessage;
	}

	public void setDetailMessage(String detailMessage) {
		this.detailMessage = detailMessage;
	}

	private IdentifyNotifierEnum(String detailMessage) {
		this.detailMessage = detailMessage;
	}
}
