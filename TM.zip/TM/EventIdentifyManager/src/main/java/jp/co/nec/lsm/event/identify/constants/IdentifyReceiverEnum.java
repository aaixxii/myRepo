package jp.co.nec.lsm.event.identify.constants;

/**
 * @author liuyq <br>
 * 
 */
public enum IdentifyReceiverEnum {
	// receiver: TMI PrepareTemplate service
	IdentifyPrepareTemplateService("TMI_PrepateTemplateService"),

	// receiver: TMI PrepareTemplate service
	IdentifyPrepareSegmentJobService("TMI_PrepareSegmentJobService"),

	// receiver: TMA SyncAggregation Service
	IdentifySyncAggregationService("TMA_SyncAggregationService"),

	// receiver: TMA BatchJobResult service
	IdentifyBatchJobResultService("TMA_BatchJobResultService"),

	// receiver: TMI SyncWithAggregation Service
	IdentifySyncWithAggregationServiceBean("TMI_SyncWithAggregationService"),

	// receiver: TMI job poll Service
	IdentifyJobPollTimerStartBean("TMI_JobPollTimerStartBeanService"),

	// receiver: TMI usc poll Service
	IdentifyUSCPollTimerStartBean("TMI_USCPollTimerStartBeanService"),

	// receiver: TMI usc poll Service
	BatchJobDeliveryCheckPollTimerStarterBean(
			"TMI_BatchJobDeliveryCheckPollTimerStarterBean"),

	// receiver: TMI usc poll Service
	GetIdentifyBatchJobPollTimerStarterBean(
			"TMI_GetIdentifyBatchJobPollTimerStarterBean");

	private String detailMessage;

	public String getDetailMessage() {
		return detailMessage;
	}

	public void setDetailMessage(String detailMessage) {
		this.detailMessage = detailMessage;

	}

	private IdentifyReceiverEnum(String detailMessage) {
		this.detailMessage = detailMessage;
	}
}
