package jp.co.nec.lsm.event.identify;

import jp.co.nec.lsm.event.identify.constants.IdentifyNotifierEnum;
import jp.co.nec.lsm.event.identify.constants.IdentifyReceiverEnum;

/**
 * @author dongqk <br>
 * 
 */
public class BatchJobDeliveryCheckPollBeanEvent extends IdentifyAbstractEvent {
	private static final long serialVersionUID = 1L;

	public BatchJobDeliveryCheckPollBeanEvent() {
	}

	public BatchJobDeliveryCheckPollBeanEvent(long batchJobId,
			IdentifyNotifierEnum identifyNotifier,
			IdentifyReceiverEnum identifyReceiver) {
		setBatchJobId(batchJobId);
		setIdentifyNotifier(identifyNotifier);
		setIdentifyReceiver(identifyReceiver);
	}
}
