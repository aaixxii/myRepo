package jp.co.nec.lsm.event.exception;

import jp.co.nec.lsm.tm.common.exception.TMRuntimeException;

/**
 * @author jimy <br>
 * EventRuntimeException
 */
public class EventRuntimeException extends TMRuntimeException {

	private static final long serialVersionUID = 7157356057817916135L;

	public EventRuntimeException(String message) {
		super(message);
	}

	public EventRuntimeException(String message, Throwable cause) {
		super(message, cause);
	}

	public EventRuntimeException(Throwable cause) {
		super(cause);
	}

}
