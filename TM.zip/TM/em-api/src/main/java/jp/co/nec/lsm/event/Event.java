package jp.co.nec.lsm.event;

import java.io.Serializable;

/**
 * @author jimy <br>
 *         interface Event
 */
public interface Event extends Serializable {
	/** get event batch job id **/
	public long getBatchJobId();

	/** get output trace message **/
	public String[] getTraceMessage();

	/** get JMS message selector **/
	public abstract String getMessageSelector();

}
