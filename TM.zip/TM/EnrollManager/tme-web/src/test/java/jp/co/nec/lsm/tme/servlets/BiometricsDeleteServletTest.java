package jp.co.nec.lsm.tme.servlets;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.concurrent.ConcurrentLinkedQueue;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.lsm.event.Event;
import jp.co.nec.lsm.event.sender.AbstractEventSender;
import jp.co.nec.lsm.tm.common.constants.Constants;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tm.protocolbuffer.deletion.DeleteRequestProto.DeleteRequest;
import jp.co.nec.lsm.tme.core.jobs.DeletionJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalDeletionJob;
import mockit.Mock;
import mockit.MockUp;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.acc.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.acc.proto.protobuf.BusinessMessage.CPBRequest;
import com.acc.proto.protobuf.BusinessMessage.E_REQUESET_TYPE;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class BiometricsDeleteServletTest {
	@Resource
	private JdbcTemplate jdbcTemplate;
	@Resource
	BiometricsDeleteServlet deleteSevlet;

	@Before
	public void setUp() throws ServletException {
		DeletionJobManager deletionJobManager = DeletionJobManager
				.getInstance();
		ConcurrentLinkedQueue<LocalDeletionJob> deleteJobQueue = deletionJobManager
				.getDeletionJobQueue();
		for (LocalDeletionJob deleteJob : deleteJobQueue) {
			deleteJobQueue.remove(deleteJob);
		}

		deleteSevlet.init();

		cleanDB();
	}

	@After
	public void tearDown() {
		cleanDB();
	}

	/**
	 * 
	 */
	private void cleanDB() {
		jdbcTemplate.execute("delete FROM PERSON_BIOMETRICS");
		jdbcTemplate.execute("delete FROM SEGMENT_VERSION_DETAIL");
		jdbcTemplate.execute("delete FROM SEGMENTS");
	}

	@Test
	public void testDoPost_Success() throws ServletException {
		long batchJobId = 4531;

		cleanDB();

		preparePersonBiometics(10);
		prepareSegment(1, 10);

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		DeleteRequest deleteRequest = prepareDeleteRequest(batchJobId);

		byte[] context = deleteRequest.toByteArray();
		req.setContent(context);

		setMockMethod();

		deleteSevlet.doPost(req, resp);

		assertEquals(HttpServletResponse.SC_OK, resp.getStatus());
		assertTrue(0 < resp.getContentLength());
	}

	@Test
	public void testDoPost_InternalError() throws ServletException {
		long batchJobId = 4532;

		new MockUp<AbstractEventSender>() {
			@SuppressWarnings("unused")
			@Mock
			public void convertAndSend(Event message) {
				throw new RuntimeException();
			}
		};

		cleanDB();

		preparePersonBiometics(10);
		prepareSegment(1, 10);

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		DeleteRequest deleteRequest = prepareDeleteRequest(batchJobId);

		byte[] context = deleteRequest.toByteArray();
		req.setContent(context);

		deleteSevlet.doGet(req, resp);

		assertEquals(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, resp
				.getStatus());
		assertEquals(114, resp.getContentLength());
	}

	@Test
	public void testDoPost_BadRequest() throws ServletException {

		cleanDB();

		preparePersonBiometics(10);
		prepareSegment(1, 10);

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		DeleteRequest deleteRequest = prepareDeleteRequest(-123);

		byte[] context = deleteRequest.toByteArray();
		req.setContent(context);

		deleteSevlet.doPost(req, resp);
		assertEquals(HttpServletResponse.SC_BAD_REQUEST, resp.getStatus());
		assertEquals(120, resp.getContentLength());
	}

	@Test
	public void testDoPost_NoContext() throws ServletException {
		cleanDB();

		preparePersonBiometics(3);
		prepareSegment(1, 3);

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		setMockMethod();

		deleteSevlet.doPost(req, resp);

		assertEquals(HttpServletResponse.SC_OK, resp.getStatus());
		assertTrue(0 == resp.getContentLength());
	}

	@Test
	public void testDoPost_NoFind() throws ServletException {
		long batchJobId = 4562;

		cleanDB();

		preparePersonBiometics(3);
		prepareSegment(1, 3);

		MockHttpServletRequest req = new MockHttpServletRequest();
		MockHttpServletResponse resp = new MockHttpServletResponse();

		DeleteRequest deleteRequest = prepareDeleteRequest(batchJobId);

		byte[] context = deleteRequest.toByteArray();
		req.setContent(context);

		setMockMethod();

		deleteSevlet.doPost(req, resp);

		assertEquals(HttpServletResponse.SC_OK, resp.getStatus());
		assertTrue(0 < resp.getContentLength());
	}

	/**
	 * 
	 * @param batchJobId
	 * @return
	 */
	private DeleteRequest prepareDeleteRequest(long batchJobId) {
		DeleteRequest.Builder deleteRequest = DeleteRequest.newBuilder();
		deleteRequest.setBatchJobId(batchJobId);
		deleteRequest.setType(BatchType.DELETE);

		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setRequestId(String.format("%036d", 6));
		request.setRequestType(E_REQUESET_TYPE.DELETE);
		request.setEnrollmentId(String.format("%036d", 6));

		CPBBusinessMessage.Builder businessMessage = CPBBusinessMessage
				.newBuilder();
		businessMessage.setRequest(request);

		deleteRequest
				.addBusinessMessage(businessMessage.build().toByteString());
		return deleteRequest.build();
	}

	/**
	 * 
	 * @param count
	 */
	private void preparePersonBiometics(int count) {
		for (int i = 1; i <= count; i++) {
			String sql = "INSERT INTO person_biometrics( biometrics_id, reference_id,"
					+ " biometric_data, biometric_data_len, date_added ) VALUES("
					+ i
					+ ",'"
					+ (String.format("%036d", i))
					+ "', '0', 13632, systimestamp)";
			jdbcTemplate.execute(sql);
		}
	}

	/**
	 * 
	 * @param count
	 * @param lastRecordCount
	 */
	private void prepareSegment(int count, int lastRecordCount) {
		int startId = -1;
		int endId = -1;
		int segLength = -1;
		for (int i = 1; i <= count; i++) {
			startId = ((i - 1) * 15 + 1);
			if (i == count) {
				endId = startId + lastRecordCount - 1;
			} else {
				endId = (i * 15);
			}
			segLength = (endId - startId + 1) * Constants.PERSON_TEMPLATE_SIZE;
			String segSQL = "INSERT INTO SEGMENTS(SEGMENT_ID, BIO_ID_START, BIO_ID_END,"
					+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, VERSION, GENERATION,"
					+ " BINARY_LENGTH_UNCOMPACTED ) VALUES ( "
					+ i
					+ ", "
					+ startId
					+ ","
					+ endId
					+ ","
					+ segLength
					+ ","
					+ (endId - startId + 1) + ", 0,0," + segLength + ")";
			jdbcTemplate.execute(segSQL);

			String segDetailSQL = "INSERT INTO SEGMENT_VERSION_DETAIL(SEGMENT_ID,VERSION,"
					+ " BIO_ID_START, BIO_ID_END,UPDATE_TS,RECORD_COUNT, CHANGE_TYPE) VALUES ( "
					+ i
					+ ", 0,"
					+ startId
					+ ","
					+ endId
					+ ",systimestamp,"
					+ (endId - startId + 1) + ", 0)";
			jdbcTemplate.execute(segDetailSQL);
		}
	}

	/**
	 * setMockMethod
	 */
	private void setMockMethod() {
		new MockUp<AbstractEventSender>() {
			@SuppressWarnings("unused")
			@Mock
			public void convertAndSend(Event message) {
				return;
			}
		};
	}
}
