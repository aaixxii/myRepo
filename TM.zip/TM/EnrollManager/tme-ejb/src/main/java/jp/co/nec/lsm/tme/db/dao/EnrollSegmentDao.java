package jp.co.nec.lsm.tme.db.dao;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.lsm.tm.db.common.entities.SegmentEntity;
import jp.co.nec.lsm.tm.db.common.entityhelpers.SegmentHelper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author liuj <br>
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class EnrollSegmentDao implements EnrollSegmentDaoLocal {
	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager manager;
	@Resource(mappedName = "java:/OracleDS")
	protected DataSource dataSource;

	private SegmentHelper segHelper;

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(EnrollSegmentDao.class);

	@PostConstruct
	public void init() {
		segHelper = new SegmentHelper(manager);
		printLogMessage("EnrollSegmentDao init");

	}

	/**
	 * constructor
	 */
	public EnrollSegmentDao() {
	}

	/**
	 * get all Segments Information.
	 * 
	 * @return list of EnrollSegmentEntity
	 */
	@Override
	public List<SegmentEntity> getAllSegmentsInfo() {
		printLogMessage("start public function getAllSegmentsInfo()..");

		List<SegmentEntity> segmentEntities = segHelper.getAllSegmentsInfo();

		printLogMessage("end public function getAllSegmentsInfo()..");
		return segmentEntities;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
