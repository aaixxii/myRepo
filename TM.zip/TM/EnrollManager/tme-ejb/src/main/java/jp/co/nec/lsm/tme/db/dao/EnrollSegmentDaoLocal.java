package jp.co.nec.lsm.tme.db.dao;

import java.util.List;

import javax.ejb.Local;

import jp.co.nec.lsm.tm.db.common.entities.SegmentEntity;

/**
 * @author liuj <br>
 * 
 */
@Local
public interface EnrollSegmentDaoLocal {

	/**
	 * get all Segments Information.
	 * 
	 * @return list of EnrollSegmentEntity
	 */
	public List<SegmentEntity> getAllSegmentsInfo();

}
