package jp.co.nec.lsm.tme.common.constants;

/***
 * @author mozj Constant definition of class.
 */
public class EnrollConstants {
	public static final int POLLING_JOB_DURATION = 5000;
	public static final int POLLING_MFE_TIMEOUT_DURATION = 5000;
	public static final int DEFAULT_INTERVAL = 5000;
	public static final int EXTRACT_JOB_START_INDEX = 1;
	public static final float DEFAULT_PERFORMANCE_FACTOR = 1f;

	public static final String HTTP_SOCKET_SENDBUFFER = "http.socket.sendbuffer";
	public static final int SEGMENT_UPDATE_SENDBUFFER_VALUE = 4 * 1024 * 1024;

	public static final String ENROLL_BATCHJOB_COMMAND_INSERT = "insert";
	public static final String ENROLL_BATCHJOB_COMMAND_DELETE = "delete";
	public static final String IDENTIFY_BATCHJOB_COMMAND_SEARCH = "search";
	public static final String EXTRACTJOB_SUCCESS_CODE = "0";
	public static final String INSERT_PROCCESS_NAME = "deletion";

	public static final String DELETEJOB_SUCCESS_CODE = "0";
	public static final String DELETE_PROCCESS_NAME = "deletion";

	public static final double DEFAULT_JOB_MULTIPLE = 1.5;

	public static final int DEFAULT_OFFSET_DIFF = -100;

	public static final int ERROR_CODE_LENGTH = 9;
	
	public static final String TIMER_STARTED_BEAN = "EnrollJobPollTimerStarterBean";
}
