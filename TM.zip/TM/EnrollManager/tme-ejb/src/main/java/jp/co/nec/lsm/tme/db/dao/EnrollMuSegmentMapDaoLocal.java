package jp.co.nec.lsm.tme.db.dao;

import java.util.List;

import javax.ejb.Local;

import jp.co.nec.lsm.proto.common.CommonProto.ComponentType;
import jp.co.nec.lsm.tm.db.common.entities.MatchUnitEntity;
import jp.co.nec.lsm.tm.db.common.entities.MuSegmentEntity;
import jp.co.nec.lsm.tm.db.common.entities.SegmentEntity;

/**
 * @author liuj <br>
 * 
 */
@Local
public interface EnrollMuSegmentMapDaoLocal {
	/**
	 * Find MuSegMapEntity of USC
	 * 
	 * @return List of MuSegMapEntity
	 */
	public List<MuSegmentEntity> findMuSegMapOfMU();

	/**
	 * Find MuSegMapEntity of DM
	 * 
	 * @return List of MuSegMapEntity
	 */
	public List<MuSegmentEntity> findMuSegMapOfDM();

	/**
	 * Find List of EnrollTMEUnitEntity(USC) which is concerned with MU_SEGMENTS
	 * 
	 * @return List of EnrollTMEUnitEntity
	 */
	public List<MatchUnitEntity> findUscInMuSegMap();

	/**
	 * Find List of EnrollTMEUnitEntity(DM) which is concerned with MU_SEGMENTS
	 * 
	 * @return List of EnrollTMEUnitEntity
	 */
	public List<MatchUnitEntity> findDMsInMuSegMap();

	/**
	 * Find List of SegmentEntity which is concerned with MU_SEGMENTS
	 * 
	 * @return List of SegmentEntity
	 */
	public List<SegmentEntity> findSegmentsInMuSegMap();

	/**
	 * update new MU-Segment Maps information into database
	 * 
	 * @param newMatrix
	 *            new MU-Segment Maps(boolean)
	 * @param muEntities
	 *            MU Entities list
	 * @param segmentEntities
	 *            segment Entities list
	 * @param muSegMaps
	 *            MU-Segment Maps list
	 */
	public void updateMuSegMap(boolean[][] newMatrix,
			List<MatchUnitEntity> muEntities,
			List<SegmentEntity> segmentEntities,
			List<MuSegmentEntity> muSegMaps, ComponentType unitType);

	/**
	 * Find EnrollTMEUnitEntity of TMEUnit
	 * 
	 * @return List of EnrollTMEUnitEntity
	 */
	public List<MatchUnitEntity> findUnitBySegId(ComponentType type,
			long segmentId);

	/**
	 * Find List of UnitEntity which is concerned with MU_SEGMENTS
	 * 
	 * @return List of UnitEntity
	 */
	public List<MatchUnitEntity> findWorkingUnitInMuSegMapByUnitType(
			ComponentType unitType);
}
