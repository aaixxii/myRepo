package jp.co.nec.lsm.tme.db.dao;

import javax.ejb.Local;

import jp.co.nec.lsm.tm.db.common.entities.TransactionManagerEntity;

/**
 * @author liuj <br>
 * 
 */
@Local
public interface EnrollTransactionManagerDaoLocal {

	/**
	 * Create or update MATCH_MANAGERS TABLE. this method judge called at an
	 * initial boot timing and "update MATCH_MANAGERS set version=parameter;".
	 * 
	 * @return
	 */
	public TransactionManagerEntity createOrLookup();

	void changeTMEToExit();
}
