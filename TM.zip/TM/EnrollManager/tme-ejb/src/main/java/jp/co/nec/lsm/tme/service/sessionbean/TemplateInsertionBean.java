package jp.co.nec.lsm.tme.service.sessionbean;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Singleton;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import jp.co.nec.lsm.slb.core.DeployException;
import jp.co.nec.lsm.tm.common.communication.PersonReferenceID;
import jp.co.nec.lsm.tm.common.communication.SegmentPosition;
import jp.co.nec.lsm.tm.common.log.BatchJobStatusLogger;
import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollJobQueueEntity;
import jp.co.nec.lsm.tme.common.constants.EnrollConstants;
import jp.co.nec.lsm.tme.common.util.EnrollEventBus;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobInfo;
import jp.co.nec.lsm.tme.db.dao.EnrollBatchJobQueueDaoLocal;
import jp.co.nec.lsm.tme.db.dao.EnrollJobQueueDaoLocal;
import jp.co.nec.lsm.tme.db.dao.EnrollPersonBiometricDaoLocal;
import jp.co.nec.lsm.tme.sessionbeans.api.SegmentLoadBalanceManagerLocal;

import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author mozj <br>
 *         register all extract result of the extraction completed batch job
 *         into database, and update segment information. And then update batch
 *         job information into database
 * 
 */
@Singleton
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class TemplateInsertionBean implements TemplateInsertionLocal {
	@EJB
	private EnrollBatchJobQueueDaoLocal batchJobQueueDao;
	@EJB
	private EnrollJobQueueDaoLocal jobQueueDao;
	@EJB
	private EnrollPersonBiometricDaoLocal personBiometricDao;
	@EJB
	private SegmentLoadBalanceManagerLocal slbManager;

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(TemplateInsertionBean.class);

	/**
	 * constructor
	 */
	public TemplateInsertionBean() {
	}

	/**
	 * register templates of the batch job found by batch Job Id into DB
	 */
	@Override
	@Lock(LockType.WRITE)
	public void insertTemplates(long batchJobId) {
		printLogMessage("start public function UpdateEnrollBatchJob()..");

		try {
			if (log.isInfoEnabled()) {
				log.info(InfoLogger.serialExecutionInfoOutput(
						LogConstants.COMPONENT_UPDATEBATCH_JOB_BEAN,
						LogConstants.FUNCTION_UPDATE_ENROLL_BATCH_JOB,
						LogConstants.DETAIL_ACTION_START, batchJobId, Thread
								.currentThread().getId()));
			}

			StopWatch stopWatch = new StopWatch();
			stopWatch.start();
			EnrollBatchJobManager queueManage = EnrollBatchJobManager
					.getInstance();
			// get the extracted batch job
			LocalEnrollBatchJob enrollBatchJob = queueManage
					.getCompleteBatchJob(batchJobId);
			if (enrollBatchJob == null) {
				log.warn("can not find batch Job {} from local enroll queue.",
						batchJobId);
				return;
			}

			enrollBatchJob.setInsertStartTS(DateUtil.getCurrentDate());

			// register all extract result of the extraction completed batch
			// job into database, and update segment information. And then
			// update batch job information into database
			completeExtractBatchJob(enrollBatchJob);

			try {
				// get boolean[][] for new MU-Segment Maps, and update into DB
				slbManager.excuteSLB();
			} catch (DeployException e) {
				log.error(
						"Call SLB error after registered extract job result.",
						e);
			}

			// commit
			batchJobQueueDao.commit();

			// change batch Job Status and Insert End Time
			enrollBatchJob.setBatchJobStatus(EnrollBatchJobStatus.REGISTERED);
			enrollBatchJob.setInsertEndTS(DateUtil.getCurrentDate());

			EnrollEventBus.notifySegmentSync(batchJobId);

			stopWatch.stop();

			PerformanceLogger.performanceOutput(
					LogConstants.COMPONENT_UPDATEBATCH_JOB_BEAN,
					LogConstants.FUNCTION_UPDATE_ENROLL_BATCH_JOB, stopWatch
							.getTime(), LogConstants.KEY_BATCH_JOB_ID,
					new Long(batchJobId).toString());
		} finally {
			if (log.isInfoEnabled()) {
				log.info(InfoLogger.serialExecutionInfoOutput(
						LogConstants.COMPONENT_UPDATEBATCH_JOB_BEAN,
						LogConstants.FUNCTION_UPDATE_ENROLL_BATCH_JOB,
						LogConstants.DETAIL_ACTION_END, batchJobId, Thread
								.currentThread().getId()));
			}
		}
		printLogMessage("end public function UpdateEnrollBatchJob()..");
	}

	/**
	 * register all extract result of the extraction completed batch job into
	 * database, and update segment information. And then update batch job
	 * information into database
	 * 
	 * @param batchJobId
	 *            extraction completed batch job Id
	 * @return true operation success; false operation failure
	 */
	public void completeExtractBatchJob(LocalEnrollBatchJob enrollBatchJob) {
		long batchJobId = enrollBatchJob.getBatchJobId();
		// register all extract result of the extraction completed batch job
		// into database.
		printLogMessage(
				"register extract result of batch Job {} and update segment information.",
				batchJobId);

		List<SegmentPosition> segPos = null;
		if (enrollBatchJob.hasSuccessedExtractJob()) {
			// register all extract result of the extraction completed batch job
			// into database.
			List<String> duplicateIds = new ArrayList<String>();
			List<PersonReferenceID> personReferenceIDList = new ArrayList<PersonReferenceID>();
			segPos = personBiometricDao.updateBiometrics(enrollBatchJob,
					duplicateIds, personReferenceIDList);

			if (segPos == null || segPos.isEmpty()) {
				String message = "Can not get SegmentPosition data when update batchjob:"
						+ batchJobId + " from table SEGMENT_VERSION_DETAIL";
				log.warn(message);
			}
			// Check Duplication Reference Id by DB
			enrollBatchJob.makeDuplicatedExtractJobsFailed(duplicateIds);

			// save BiometicIds into extract job info
			enrollBatchJob.saveBiometicIdsInfo(personReferenceIDList);

			// save Segment Version Detail Information into local enroll queue
			enrollBatchJob.setSegmentPosition(segPos);
		}

		if (log.isInfoEnabled()) {
			BatchJobStatusLogger.outputBatchJobStatus(
					LogConstants.STATUS_CATEGORY_TME, enrollBatchJob
							.getBatchJobId(), EnrollBatchJobStatus.REGISTERED
							.name());
		}

		// persist Job Info into DB
		persistJobInfo(batchJobId, enrollBatchJob, segPos);

		printLogMessage("end public function CompleteExtractBatchJob()..");

	}

	/**
	 * persist Job Info into DB
	 * 
	 * @param batchJobId
	 * @param enrollBatchJob
	 * @param segPos
	 */
	private void persistJobInfo(long batchJobId,
			LocalEnrollBatchJob enrollBatchJob, List<SegmentPosition> segPos) {
		printLogMessage("persist batch job information into database.");

		// persist batch job information into database
		batchJobQueueDao.persistBatchJobStatus(batchJobId,
				EnrollBatchJobStatus.REGISTERED, segPos);

		// persist all extract job information of batchJobId into database
		List<EnrollJobQueueEntity> extractJobEntities = jobQueueDao
				.getAllExtractJobInfo(batchJobId);

		printLogMessage("merge extract Job result to database into database.");

		// update extract result information
		for (int i = 0; i < extractJobEntities.size(); i++) {
			EnrollJobQueueEntity extractJobEntity = extractJobEntities.get(i);
			LocalExtractJobInfo localExtractJob = enrollBatchJob
					.getExtractJobInfo(extractJobEntity.getJobIndex());

			if (localExtractJob == null) {
				continue;
			}
			extractJobEntity.setReturnCode(localExtractJob.getReturnCode());
			String errorCode = localExtractJob.getErrorCode();
			if (errorCode.length() > EnrollConstants.ERROR_CODE_LENGTH) {
				extractJobEntity.setErrorCode(errorCode.substring(0,
						EnrollConstants.ERROR_CODE_LENGTH));
			} else {
				extractJobEntity.setErrorCode(errorCode);
			}
			extractJobEntity.setErrorMessage(localExtractJob.getErrorMessage());
			if (localExtractJob.getResponse() == null) {
				log.warn("Response CPBBusinessMessage is null,"
						+ " eroll batch job id: {}, job index: {} ",
						batchJobId, extractJobEntity.getJobIndex());
			} else {
				extractJobEntity.setResponse(localExtractJob.getResponse()
						.toByteArray());
			}
		}

		// update extract job result to database
		jobQueueDao.updateExctractJobQueue(extractJobEntities);
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 *            ,logParame
	 * @return
	 */
	private void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}
}
