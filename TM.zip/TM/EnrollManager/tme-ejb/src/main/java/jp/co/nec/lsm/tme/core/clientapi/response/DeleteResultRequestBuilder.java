package jp.co.nec.lsm.tme.core.clientapi.response;

import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tm.protocolbuffer.deletion.DeleteResultRequestProto.DeleteResultRequest;
import jp.co.nec.lsm.tme.common.constants.EnrollConstants;
import jp.co.nec.lsm.tme.core.jobs.LocalDeletionJob;

import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acc.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.acc.proto.protobuf.BusinessMessage.CPBDataBlock;
import com.acc.proto.protobuf.BusinessMessage.CPBProcessInfo;
import com.acc.proto.protobuf.BusinessMessage.CPBProcessMetrics;
import com.acc.proto.protobuf.BusinessMessage.CPBResponse;
import com.google.protobuf.ByteString;

public class DeleteResultRequestBuilder {
	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(DeleteResultRequestBuilder.class);

	/**
	 * prepare Enroll Result of Request basing Enroll Batch Job
	 * 
	 * @param batchJob
	 *            Enroll Batch Job
	 * @return Enroll Result of Request
	 */
	public static DeleteResultRequest createDeleteResultRequest(
			LocalDeletionJob batchJob) {
		printLogMessage("start public function createDeleteResultRequest.");

		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		DeleteResultRequest.Builder deleteResponse = DeleteResultRequest
				.newBuilder();

		// create ExtractResultInfo list for EnrollResponse
		ByteString resultByteString = prepareDeleteJobResultInfo(batchJob);

		// set DeleteResultRequest values
		deleteResponse.setBatchJobId(batchJob.getBatchJobId());
		deleteResponse.addBusinessMessage(resultByteString);
		deleteResponse.setType(BatchType.DELETE);

		// response Transformer the result of batchJob
		printLogMessage(" response Transformer the result of batchJob: "
				+ batchJob.getBatchJobId() + ".");

		stopWatch.stop();

		PerformanceLogger.performanceOutput("Response",
				"createDeleteResultRequest", stopWatch.getTime());

		printLogMessage("end public function createDeleteResultRequest.");

		return deleteResponse.build();
	}

	/**
	 * 
	 * @param deleteJob
	 * @return
	 */
	private static ByteString prepareDeleteJobResultInfo(
			LocalDeletionJob batchJob) {
		printLogMessage("start private function prepareDeleteJobResultInfo.");

		CPBResponse.Builder response = CPBResponse.newBuilder();
		response.setStatus(batchJob.getErrorCode());
		response.setErrorMessage(batchJob.getErrorMessage());

		CPBProcessInfo.Builder processInfo = CPBProcessInfo.newBuilder();
		processInfo.setProcessName(EnrollConstants.DELETE_PROCCESS_NAME);
		processInfo.setStartTime(DateUtil.formatUTC(batchJob.getStartTime()));
		processInfo.setEndTime(DateUtil.formatUTC(DateUtil.getCurrentDate()));

		CPBProcessMetrics.Builder processMetrics = CPBProcessMetrics
				.newBuilder();
		processMetrics.addProcessMetric(processInfo);

		CPBDataBlock.Builder dataBlock = CPBDataBlock.newBuilder();
		dataBlock.setProcessMetric(processMetrics);

		CPBBusinessMessage.Builder responseMessage = CPBBusinessMessage
				.newBuilder();
		responseMessage.setRequest(batchJob.getRequest());
		responseMessage.setResponse(response);
		responseMessage.setDataBlock(dataBlock);

		printLogMessage("end private function prepareDeleteJobResultInfo.");
		return responseMessage.build().toByteString();
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
