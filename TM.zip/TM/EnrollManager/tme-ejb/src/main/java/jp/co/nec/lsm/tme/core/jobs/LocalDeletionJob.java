package jp.co.nec.lsm.tme.core.jobs;

import java.util.Date;

import jp.co.nec.lsm.tm.common.communication.SegmentPosition;
import jp.co.nec.lsm.tm.common.constants.EnrollErrorMessage;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tme.common.constants.EnrollConstants;

import com.acc.proto.protobuf.BusinessMessage.CPBRequest;

public class LocalDeletionJob {

	private long batchJobId;

	private boolean isSynchronized;

	private CPBRequest request;

	private long segmentId;

	private long version;

	private long biometricsId;

	private String referenceId;

	private String errorCode;

	private String errorMessage;

	private Date startTime;

	private Date endTime;

	public LocalDeletionJob() {
		errorCode = EnrollConstants.DELETEJOB_SUCCESS_CODE;
		errorMessage = "";
		isSynchronized = false;
		setStartTime(DateUtil.getCurrentDate());
	}

	public LocalDeletionJob(long batchJobId, CPBRequest request) {
		this.batchJobId = batchJobId;
		this.request = request;
		this.referenceId = request.getEnrollmentId();
		errorCode = EnrollConstants.DELETEJOB_SUCCESS_CODE;
		errorMessage = "";
		isSynchronized = false;
		setStartTime(DateUtil.getCurrentDate());
	}

	public LocalDeletionJob(long segmentId, long version, long biometricsId,
			String referenceId) {
		this.segmentId = segmentId;
		this.version = version;
		this.biometricsId = biometricsId;
		this.referenceId = referenceId;
		errorCode = EnrollConstants.DELETEJOB_SUCCESS_CODE;
		errorMessage = "";
		isSynchronized = false;
		setStartTime(DateUtil.getCurrentDate());
	}

	public void setSegmentPosition(SegmentPosition segmentPosition) {
		this.segmentId = segmentPosition.getSegmentId();
		this.version = segmentPosition.getVersion();
		this.biometricsId = segmentPosition.getIndexStart();
	}

	public void setSegmentId(long segmentId) {
		this.segmentId = segmentId;
	}

	public long getSegmentId() {
		return segmentId;
	}

	public void setVersion(long version) {
		this.version = version;
	}

	public long getVersion() {
		return version;
	}

	public void setBiometricsId(long biometricsId) {
		this.biometricsId = biometricsId;
	}

	public long getBiometricsId() {
		return biometricsId;
	}

	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

	public String getReferenceId() {
		return referenceId;
	}

	public String getSummary() {
		String br = System.getProperty("line.separator");
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("segment Id: ");
		stringBuilder.append(segmentId);
		stringBuilder.append("\t  version: ");
		stringBuilder.append(version);
		stringBuilder.append("\t  biometrics Id: ");
		stringBuilder.append(biometricsId);
		stringBuilder.append("\t  reference Id: ");
		stringBuilder.append(referenceId);
		stringBuilder.append(br);
		return null;
	}

	public void setBatchJobId(long batchJobId) {
		this.batchJobId = batchJobId;
	}

	public long getBatchJobId() {
		return batchJobId;
	}

	public void setRequest(CPBRequest request) {
		this.request = request;
	}

	public CPBRequest getRequest() {
		return request;
	}

	public void setSynchronized(boolean isSynchronized) {
		this.isSynchronized = isSynchronized;
	}

	public boolean isSynchronized() {
		return isSynchronized;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void makeSyncByNoFindData(String message) {
		errorCode = EnrollErrorMessage.REFERENCEID_NOT_FIND.getErrorCode();
		errorMessage = message;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public Date getEndTime() {
		return endTime;
	}
}
