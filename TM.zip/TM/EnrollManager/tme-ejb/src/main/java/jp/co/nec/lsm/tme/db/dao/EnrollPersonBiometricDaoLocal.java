package jp.co.nec.lsm.tme.db.dao;

import java.util.List;

import javax.ejb.Local;

import jp.co.nec.lsm.tm.common.communication.PersonReferenceID;
import jp.co.nec.lsm.tm.common.communication.SegmentPosition;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;

/**
 * @author liuj <br>
 * 
 */
@Local
public interface EnrollPersonBiometricDaoLocal {

	/**
	 * register all extract result of the extraction completed batch job into
	 * database.
	 * 
	 * @param enrollBatchJob
	 *            batch job
	 * @return inserted biometrics Ids
	 */
	public List<SegmentPosition> updateBiometrics(
			LocalEnrollBatchJob enrollBatchJob, List<String> duplicateIds,
			List<PersonReferenceID> personReferenceIDList);
	/**
	 * delete Biometrics from Person_biometrics by referenceId
	 * 
	 * @param referenceId
	 * @return
	 */
	public SegmentPosition deleteBiometrics(String referenceId);
}
