package jp.co.nec.lsm.tme.core.segment.loadbalance;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import jp.co.nec.lsm.proto.common.CommonProto.ComponentType;
import jp.co.nec.lsm.slb.appointed.AppointedDeployer;
import jp.co.nec.lsm.slb.core.DeployException;
import jp.co.nec.lsm.slb.core.Deployer;
import jp.co.nec.lsm.slb.core.Param;
import jp.co.nec.lsm.tm.common.constants.MUState;
import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.db.common.entities.MatchUnitEntity;
import jp.co.nec.lsm.tm.db.common.entities.MuSegmentEntity;
import jp.co.nec.lsm.tm.db.common.entities.SegmentEntity;
import jp.co.nec.lsm.tme.db.dao.EnrollMatchUnitDaoLocal;
import jp.co.nec.lsm.tme.db.dao.EnrollMuSegmentMapDaoLocal;
import jp.co.nec.lsm.tme.db.dao.EnrollSegmentDaoLocal;
import jp.co.nec.lsm.tme.db.dao.EnrollSystemConfigDaoLocal;
import jp.co.nec.lsm.tme.sessionbeans.api.SegmentLoadBalanceManagerLocal;

import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author zhulk
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class SegmentLoadBalanceManager implements
		SegmentLoadBalanceManagerLocal {

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(SegmentLoadBalanceManager.class);

	@EJB
	private EnrollMuSegmentMapDaoLocal muSegmentMapDao;
	@EJB
	private EnrollSegmentDaoLocal segmentDao;
	@EJB
	private EnrollSystemConfigDaoLocal systemConfigDao;
	@EJB
	private EnrollMatchUnitDaoLocal matchUnitDao;

	/**
	 * constructor
	 */
	public SegmentLoadBalanceManager() {
	}

	/**
	 * get boolean[][] for new MU-Segment Maps, and update changes into DB
	 * 
	 * 1. prepare Parameters for redeploy
	 * 
	 * 2. get boolean[][] for new MU-Segment Maps
	 * 
	 * 3. update changes into DB
	 * 
	 * @return boolean[][] for new MU-Segment Maps
	 * @throws EnrollDeployException
	 */
	public void excuteSLB() throws DeployException {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		boolean isSLBEnable = systemConfigDao.getSlbEnabled();
		if (isSLBEnable == false) {
			log.warn("Don't do SLB because SLB is disable.");
			return;
		}

		// get deployed Segment entities
		List<SegmentEntity> preSegmentEntities = muSegmentMapDao
				.findSegmentsInMuSegMap();
		// get all Segment entities
		List<SegmentEntity> segmentEntities = segmentDao.getAllSegmentsInfo();

		// check whether There are segments which have been created
		if (preSegmentEntities.size() == segmentEntities.size()) {
			if (log.isInfoEnabled()) {
				log.info(InfoLogger.infoOutput(
						LogConstants.COMPONENT_SEGMENT_LOAD_BALACE_MANAGER,
						LogConstants.FUNCTION_EXCUTE_SLB_TME, "DETAIL",
						"There is not segment which has been created."));
			}
			return;
		}

		// reDeploy for USC and persist into DB
		reDeployForUSC(preSegmentEntities, segmentEntities);

		// reDeploy for DM and persist into DB
		reDeployForDM(preSegmentEntities, segmentEntities);

		stopWatch.stop();

		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_SEGMENT_LOAD_BALACE_MANAGER,
				LogConstants.FUNCTION_EXCUTE_SLB_TME, stopWatch.getTime());

		return;
	}

	/**
	 * do reDeploy for USC and persist MU_SegmentMaps into DB
	 * 
	 * @param preSegmentEntities
	 * @param segmentEntities
	 * @throws DeployException
	 */
	private void reDeployForUSC(List<SegmentEntity> preSegmentEntities,
			List<SegmentEntity> segmentEntities) throws DeployException {

		// get USC Entity List
		List<MatchUnitEntity> uscEntities = matchUnitDao
				.getMatchUnitsByTypeAndState(ComponentType.USC, MUState.WORKING);
		// check if the working USC number
		int uscNumber = uscEntities.size();
		if (uscNumber == 0) {
			log.warn("There is no working USC for doing SLB.");
			return;
		}
		// check if the working usc is under MIN_USCS_FOR_SLB
		if (isUnderMinUSCForSlb(uscNumber)) {
			log.warn("Don't do SLB because of working USCs number limit.");
			return;
		}

		// get redundancy of segment from SYSTEM_CONFIG table
		Integer redundancy = systemConfigDao.getMinUSCRedundancy();
		// check if the working usc is under redundancy
		if (redundancy > uscEntities.size()) {
			log
					.warn(
							"Don't do SLB because of Redundancy: {} > Working USCs Number: {}.",
							new Object[] { redundancy, uscEntities.size() });
			return;
		}

		// get MuSegment entities of USC
		List<MuSegmentEntity> preUSCSegmentMaps = muSegmentMapDao
				.findMuSegMapOfMU();
		// get old UscSegment entities of USC
		List<MatchUnitEntity> preUSCEntities = muSegmentMapDao
				.findUscInMuSegMap();

		// reDeploy for USC and persist into DB
		reDeployForUnit(preUSCEntities, uscEntities, preSegmentEntities,
				segmentEntities, preUSCSegmentMaps, redundancy,
				ComponentType.USC);
	}

	/**
	 * do reDeploy for DM and persist MU_SegmentMaps into DB
	 * 
	 * @param preSegmentEntities
	 * @param segmentEntities
	 * @throws DeployException
	 */
	private void reDeployForDM(List<SegmentEntity> preSegmentEntities,
			List<SegmentEntity> segmentEntities) throws DeployException {

		// get DM Entity List
		List<MatchUnitEntity> dmEntities = matchUnitDao
				.getMatchUnitsByTypeAndState(ComponentType.DM, MUState.WORKING);

		// check if the working DM number
		int dmNumber = dmEntities.size();
		if (dmNumber == 0) {
			log.warn("There is no working DM for doing SLB.");
			return;
		}
		// check if the working DM is under MIN_DMS_FOR_SLB
		if (isUnderMinDMForSlb(dmNumber)) {
			log.warn("Don't do SLB because of working DMs number limit.");
			return;
		}

		// get redundancy of segment from SYSTEM_CONFIG table
		Integer dmRedundancy = systemConfigDao.getMinDMRedundancy();
		// check if the working usc is under redundancy
		if (dmRedundancy > dmNumber) {
			log.warn("Change Redundancy: {} to Working DMs Number: {}.",
					new Object[] { dmRedundancy, dmNumber });
			dmRedundancy = dmNumber;
		}

		// get MuSegment entities of DM
		List<MuSegmentEntity> preDMSegmentMaps = muSegmentMapDao
				.findMuSegMapOfDM();
		// get all UscSegment entities of DM
		List<MatchUnitEntity> preDMEntities = muSegmentMapDao
				.findDMsInMuSegMap();

		// reDeploy for USC and persist into DB
		reDeployForUnit(preDMEntities, dmEntities, preSegmentEntities,
				segmentEntities, preDMSegmentMaps, dmRedundancy,
				ComponentType.DM);
	}

	/**
	 * reDeploy for TM Unit and persist into DB
	 * 
	 * @param muEntities
	 * @param preSegmentEntities
	 * @param segmentEntities
	 * @param muSegMaps
	 * @param redundancy
	 * @return
	 * @throws DeployException
	 */
	private void reDeployForUnit(List<MatchUnitEntity> preMUEntities,
			List<MatchUnitEntity> muEntities,
			List<SegmentEntity> preSegmentEntities,
			List<SegmentEntity> segmentEntities,
			List<MuSegmentEntity> muSegMaps, Integer redundancy,
			ComponentType unitType) throws DeployException {
		printLogMessage("start private function reDeployForUnit.");
		if (log.isInfoEnabled()) {
			log.info(InfoLogger.slbInfoOutput(LogConstants.DETAIL_REDUNDANCY,
					String.valueOf(redundancy),
					LogConstants.DETAIL_ALL_UNIT_NUM, String.valueOf(muEntities
							.size()), LogConstants.DETAIL_ALL_SEGMENT_NUM,
					String.valueOf(segmentEntities.size()),
					LogConstants.DETAIL_PRE_UNIT_NUM, String
							.valueOf(preMUEntities.size()),
					LogConstants.DETAIL_PRE_SEGMENT_NUM, String
							.valueOf(preSegmentEntities.size())));
		}
		// 1. prepare Parameters for redeploy
		// prepare Param for new MU-Segment Maps
		printLogMessage("prepare Param for new MU-Segment Maps.");
		Param param = prepareParam(muEntities, redundancy, segmentEntities
				.size());

		// prepare old Param
		printLogMessage("prepare Param for old MU-Segment Maps.");
		Param preParam = prepareParam(muEntities, redundancy,
				preSegmentEntities.size());

		// prepare old MU-Segment Maps
		boolean[][] preMatrix = preparePreMatrix(muEntities,
				preSegmentEntities, muSegMaps);

		// 2. get boolean[][] for new MU-Segment Maps
		Deployer deploye = new AppointedDeployer();
		printLogMessage("get boolean[][] for new MU-Segment Maps.");

		boolean[][] newMatrix = null;
		if (preMUEntities.size() != 0 && preSegmentEntities.size() != 0) {
			newMatrix = deploye.reDeploy(preMatrix, preParam, param);
		} else {
			newMatrix = deploye.deploy(param);
		}

		// 3. update changes into DB
		// update new MU-Segment Maps information into database
		printLogMessage("update new MU-Segment Maps information into database.");

		if (newMatrix != null) {
			muSegmentMapDao.updateMuSegMap(newMatrix, muEntities,
					segmentEntities, muSegMaps, unitType);
		} else {
			log
					.warn("Can't update MU-Segment table because newMatrix is null.");
		}

		printLogMessage("end private function reDeployForUnit.");

		return;
	}

	/**
	 * isUnderMinUSCForSlb
	 * 
	 * @param allMuEntities
	 * @return
	 */
	private boolean isUnderMinUSCForSlb(int uscNumber) {
		// if the working USC is under the MIN_USC_FOR_SLB
		// skip run slb
		int minUSCForSlb = systemConfigDao.getMinUscForSlb();
		if (uscNumber < minUSCForSlb) {
			log
					.warn(
							"the working USC(number: {}) is under the [MIN_USCS_FOR_SLB]({})",
							uscNumber, minUSCForSlb);
			return true;
		}
		return false;
	}

	/**
	 * isUnderMinDMForSlb
	 * 
	 * @param allMuEntities
	 * @return
	 */
	private boolean isUnderMinDMForSlb(int dmNumber) {
		// if the working USC is under the MIN_USC_FOR_SLB
		// skip run slb
		int minDMForSlb = systemConfigDao.getMinDMForSlb();
		if (dmNumber < minDMForSlb) {
			log
					.warn(
							"the working DM(number: {}) is under the [MIN_DMS_FOR_SLB]({})",
							dmNumber, minDMForSlb);
			return true;
		}
		return false;
	}

	/**
	 * prepare boolean[][] for old MU-Segment Maps
	 * 
	 * @param muEntities
	 *            mu Entities List
	 * @param preSegmentEntities
	 *            segment Entities list
	 * @param muSegMaps
	 *            MU-Segment Maps list
	 * @return boolean[][] for old MU-Segment Maps
	 */
	public boolean[][] preparePreMatrix(List<MatchUnitEntity> muEntities,
			List<SegmentEntity> preSegmentEntities,
			List<MuSegmentEntity> muSegMaps) {
		printLogMessage("start public function preparePreMatrix()..");

		// initiate variable
		int preSegmentCount = preSegmentEntities.size();
		int muCount = muEntities.size();
		boolean[][] preMatrix = new boolean[muCount][preSegmentCount];

		// prepare boolean[][] for old MU-Segment Maps
		printLogMessage("prepare boolean[][] for old MU-Segment Maps...");

		int matrixMu = 0;
		int matrixSeg = 0;
		for (MuSegmentEntity mse : muSegMaps) {
			matrixMu = -1;
			matrixSeg = -1;
			// find deployed Mu Index to prepare boolean[][]
			for (int muIndex = 0; muIndex < muCount; muIndex++) {
				if (muEntities.get(muIndex).getId() == mse.getMuId()) {
					matrixMu = muIndex;
					break;
				}
			}

			// find deployed segment Index to prepare boolean[][]
			for (int segIndex = 0; segIndex < preSegmentCount; segIndex++) {
				if (preSegmentEntities.get(segIndex).getSegmentId() == mse
						.getSegmentId()) {
					matrixSeg = segIndex;
					break;
				}
			}

			// prepare MU-Segment Maps values
			if (matrixMu != -1 && matrixSeg != -1) {
				preMatrix[matrixMu][matrixSeg] = true;
			}
		}

		printLogMessage("end public function preparePreMatrix()..");

		return preMatrix;
	}

	/**
	 * prepare Parameter for Mu-Segment deploy
	 * 
	 * @param muEntities
	 *            mu Entities List
	 * @param redundancy
	 *            redundancy number of Segment
	 * @param segs
	 *            segments number
	 * @return Parameter for Mu-Segment deploy
	 */
	private Param prepareParam(List<MatchUnitEntity> muEntities,
			Integer redundancy, int segs) {
		printLogMessage("start private function prepareParam()..");

		// prepare Mu nodes for param
		int nodeLength = muEntities.size();
		String[] newNodes = new String[nodeLength];
		for (int index = 0; index < nodeLength; index++) {
			newNodes[index] = String.valueOf(muEntities.get(index).getId());
		}

		// set values into param
		Param param = new Param(newNodes, segs, redundancy);

		printLogMessage("end private function prepareParam()..");

		return param;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
