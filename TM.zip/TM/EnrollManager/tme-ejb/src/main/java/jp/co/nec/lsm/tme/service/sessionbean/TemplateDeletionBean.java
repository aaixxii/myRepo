package jp.co.nec.lsm.tme.service.sessionbean;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import jp.co.nec.lsm.tm.common.communication.SegmentPosition;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.common.validator.ValidationResult;
import jp.co.nec.lsm.tm.protocolbuffer.deletion.DeleteResultRequestProto.DeleteResultRequest;
import jp.co.nec.lsm.tme.common.util.EnrollEventBus;
import jp.co.nec.lsm.tme.core.clientapi.request.validator.DeleteRequestValidator;
import jp.co.nec.lsm.tme.core.clientapi.response.DeleteResultRequestBuilder;
import jp.co.nec.lsm.tme.core.jobs.DeletionJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalDeletionJob;
import jp.co.nec.lsm.tme.db.dao.EnrollPersonBiometricDaoLocal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author mozj <br>
 *         add the enroll request into local enroll queue.
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class TemplateDeletionBean implements TemplateDeletionLocal {
	@EJB
	private EnrollPersonBiometricDaoLocal personBiometricDao;

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(TemplateDeletionBean.class);

	/**
	 * constructor
	 */
	public TemplateDeletionBean() {
	}

	/**
	 * delete Biometrics from Person_biometrics by referenceId
	 */
	@Override
	public DeleteResultRequest deleteTemplate(Long batchJobId,
			String referenceId) {
		printLogMessage("strat public function deleteBiometrics");

		DeletionJobManager deletionJobManager = DeletionJobManager
				.getInstance();
		LocalDeletionJob deletejob = deletionJobManager
				.getDeletionJob(batchJobId);
		if (deletejob == null) {
			log.warn("Cannot find LocalDeletionJob:(batchjobId {}).",
					batchJobId);
			return null;
		}

		ValidationResult result = DeleteRequestValidator.validateRequest(
				batchJobId, deletejob.getRequest());

		if (result != null && result.hasErrors()) {
			deletejob.setErrorCode(result.getRequestError().get(0)
					.getErrorCode());
			deletejob.setErrorMessage(result.getRequestError().get(0)
					.getInvalidReason());
			// delete Deletion Job
			DeletionJobManager.getInstance().deleteDeletionJob(deletejob);

			return createDeleteResultRequest(deletejob);
		}

		// delete Biometrics from Person_biometrics by referenceId
		printLogMessage(
				"delete Biometrics from Person_biometrics by referenceId {}.",
				referenceId);
		DeleteResultRequest deleteResult = null;
		SegmentPosition segmentPosition = personBiometricDao
				.deleteBiometrics(referenceId);
		if (segmentPosition == null) {
			String message = "Delete Job ( Cannot find referenceId: " + referenceId + " ).";
			log.warn(message);

			deletejob.makeSyncByNoFindData(message);

			deleteResult = createDeleteResultRequest(deletejob);
			// delete Deletion Job
			DeletionJobManager.getInstance().deleteDeletionJob(deletejob);
		} else {
			deletejob.setSegmentPosition(segmentPosition);

			// Notify EnrollSegmentSyncServiceBean that Segment synchronization.
			EnrollEventBus.notifyDeleteSync(batchJobId);

			deleteResult = createDeleteResultRequest(deletejob);
		}

		printLogMessage("end public function deleteBiometrics");
		return deleteResult;
	}

	/**
	 * 
	 * @return
	 */
	private DeleteResultRequest createDeleteResultRequest(
			LocalDeletionJob batchJob) {

		batchJob.setEndTime(DateUtil.getCurrentDate());

		DeleteResultRequest deleteResult = DeleteResultRequestBuilder
				.createDeleteResultRequest(batchJob);

		return deleteResult;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 *            ,logParame
	 * @return
	 */
	private void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}
}
