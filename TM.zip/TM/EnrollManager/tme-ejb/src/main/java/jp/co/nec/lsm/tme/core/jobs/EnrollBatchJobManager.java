package jp.co.nec.lsm.tme.core.jobs;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import jp.co.nec.lsm.tm.common.communication.SegmentPosition;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author zhulk <br>
 *         This class of used to manage EnrollQueue.
 * 
 */
public class EnrollBatchJobManager {
	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(EnrollBatchJobManager.class);

	private static EnrollBatchJobManager enrollQueueManager;

	public synchronized static EnrollBatchJobManager getInstance() {
		if (enrollQueueManager == null) {
			enrollQueueManager = new EnrollBatchJobManager();
		}
		return enrollQueueManager;
	}

	private ConcurrentLinkedQueue<LocalEnrollBatchJob> batchJobQueue;

	private EnrollBatchJobManager() {
		batchJobQueue = new ConcurrentLinkedQueue<LocalEnrollBatchJob>();
	}

	/**
	 * get local enroll queue instance
	 * 
	 * @return local enroll queue instance
	 */
	public ConcurrentLinkedQueue<LocalEnrollBatchJob> getEnrollLinkQueue() {
		printLogMessage("called public function getEnrollLinkQueue()..");

		return batchJobQueue;
	}

	/**
	 * add an enroll Batch Job into local enroll queue.
	 */
	public void addEnrollBatchJob(LocalEnrollBatchJob enrollBatchJob) {
		printLogMessage("start public function addEnrollBatchJob()..");
		synchronized (batchJobQueue) {
			batchJobQueue.add(enrollBatchJob);
		}
		printLogMessage("end public function addEnrollBatchJob()..");

	}

	/**
	 * get Enroll Batch Job By batchJob Id
	 * 
	 * @param batchJobId
	 *            Enroll Batch Job Id
	 * @return Enroll Batch Job
	 */
	public LocalEnrollBatchJob getEnrollBatchJobById(long batchJobId) {
		printLogMessage("start public function getEnrollBatchJobById().");

		Iterator<LocalEnrollBatchJob> iterator = batchJobQueue.iterator();

		// loop the enroll local queue to get the enroll batch job.
		printLogMessage("get the enroll batch job by batchJobId " + batchJobId);

		while (iterator.hasNext()) {
			LocalEnrollBatchJob batchJob = iterator.next();
			if (batchJobId == batchJob.getBatchJobId()) {
				return batchJob;
			}
		}

		printLogMessage("end public function getEnrollBatchJobById().");

		return null;
	}

	/**
	 * get Not Synchronized Enroll Batch Job List
	 * 
	 * @return Enroll Batch Job List
	 */
	public List<LocalEnrollBatchJob> getNotSynchronizedEnrollBatchJobs() {
		printLogMessage("start public function getNotSynchronizedEnrollBatchJobs().");

		Iterator<LocalEnrollBatchJob> iterator = batchJobQueue.iterator();

		// loop the enroll local queue to get the enroll batch job.
		List<LocalEnrollBatchJob> unSynchedEnrollBatchJobs = new ArrayList<LocalEnrollBatchJob>();
		while (iterator.hasNext()) {
			LocalEnrollBatchJob batchJob = iterator.next();
			if (batchJob.isBatchJobStatus(EnrollBatchJobStatus.REGISTERED)) {
				unSynchedEnrollBatchJobs.add(batchJob);
			}
		}
		if (unSynchedEnrollBatchJobs.isEmpty()) {
			return unSynchedEnrollBatchJobs;
		}

		LocalEnrollBatchJob[] arrays = new LocalEnrollBatchJob[unSynchedEnrollBatchJobs
				.size()];
		Arrays.sort(unSynchedEnrollBatchJobs.toArray(arrays),
				new Comparator<LocalEnrollBatchJob>() {
					@Override
					public int compare(final LocalEnrollBatchJob entry1,
							final LocalEnrollBatchJob entry2) {
						return compareOrderBySegmentIdAndVersion(entry1, entry2);
					}
				});

		unSynchedEnrollBatchJobs = Arrays.asList(arrays);

		printLogMessage("Not synchronized enroll batch jobs count: "
				+ unSynchedEnrollBatchJobs.size());

		printLogMessage("end public function getNotSynchronizedEnrollBatchJobs().");

		return unSynchedEnrollBatchJobs;
	}

	/**
	 * 
	 * @param entry1
	 * @param entry2
	 * @return
	 */
	private int compareOrderBySegmentIdAndVersion(LocalEnrollBatchJob entry1,
			LocalEnrollBatchJob entry2) {
		if (entry1 == null || entry1.getSegmentPosition() == null
				|| entry1.getSegmentPosition().isEmpty()) {
			return -1;
		}
		if (entry2 == null || entry2.getSegmentPosition() == null
				|| entry2.getSegmentPosition().isEmpty()) {
			return 1;
		}
		SegmentPosition segPos = entry1.getSegmentPosition().get(0);
		SegmentPosition segPosInList = entry2.getSegmentPosition().get(0);
		if (segPos.getSegmentId() == segPosInList.getSegmentId()
				&& segPos.getVersion() < segPosInList.getVersion()) {
			return -1;
		} else if (segPos.getSegmentId() < segPosInList.getSegmentId()) {
			return -1;
		}
		return 1;
	}

	/**
	 * 
	 * @param batchJobId
	 * @return
	 */
	public LocalEnrollBatchJob getCompleteBatchJob(long batchJobId) {
		printLogMessage("start public function GetCompleteBatchJob()..");

		LocalEnrollBatchJob batchJob = getEnrollBatchJobById(batchJobId);
		// mantis 499 Need null check when retrying update batch job
		if (batchJob == null) {
			return null;
		}

		if (!batchJob.isBatchJobStatus(EnrollBatchJobStatus.EXTRACTED)) {
			log.warn("the batch job {} is not EXTRACTED...", batchJobId);
			return null;
		}

		printLogMessage("end public function GetCompleteBatchJob()..");

		return batchJob;
	}

	/**
	 * 
	 * @param batchJob
	 * @return
	 */
	public boolean deleteCompleteBatchJob(LocalEnrollBatchJob batchJob) {
		printLogMessage("start public function DeleteCompleteBatchJob()..");
		synchronized (batchJobQueue) {
			if (!batchJob.isBatchJobStatus(EnrollBatchJobStatus.RETURNED)) {
				log.warn("the batch job {} is not RETURNED...", batchJob
						.getBatchJobId());
				return false;
			}

			boolean bResult = batchJobQueue.remove(batchJob);

			printLogMessage("start public function DeleteCompleteBatchJob()..");

			return bResult;
		}
	}

	/**
	 * get enrollinkQueue Summary
	 * 
	 * @return Summary Information
	 */
	public String getSummary() {
		printLogMessage("start public function getSummary()..");

		StringBuffer stringBuffer = new StringBuffer();
		// get identifyLinkQueue iterator
		Iterator<LocalEnrollBatchJob> iterator = batchJobQueue.iterator();

		// do loop until find a instance match batchJobId
		while (iterator.hasNext()) {
			LocalEnrollBatchJob ebj = iterator.next();
			if (ebj == null) {
				printLogMessage("this BatchIdentifyQueue instance is null");

				continue;
			}

			stringBuffer.append("\n");
			stringBuffer
					.append("======================================================");
			stringBuffer.append("\n");

			stringBuffer.append(ebj.getSummary());

			stringBuffer
					.append("======================================================");
			stringBuffer.append("\n");
		}

		printLogMessage("end public function getSummary()..");

		return stringBuffer.toString();
	}

	public int getNotCompletedBatchJobCount() {
		printLogMessage("start public function getNotCompletedBatchJobCount().");
		int notCompeletedBjb = batchJobQueue.size();
		return notCompeletedBjb;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
