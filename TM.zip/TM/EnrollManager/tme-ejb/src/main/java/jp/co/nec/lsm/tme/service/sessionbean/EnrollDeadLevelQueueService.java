package jp.co.nec.lsm.tme.service.sessionbean;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import jp.co.nec.lsm.event.enroll.common.EnrollNotifierEnum;
import jp.co.nec.lsm.tm.common.log.BatchJobStatusLogger;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tme.common.util.EnrollEventBus;
import jp.co.nec.lsm.tme.core.jobs.DeletionJobManager;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalDeletionJob;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.sessionbeans.api.EnrollDeadLevelQueueServiceLocal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author mozj <br>
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class EnrollDeadLevelQueueService implements
		EnrollDeadLevelQueueServiceLocal {

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(EnrollDeadLevelQueueService.class);

	/**
	 * 
	 */
	@Override
	public void deleteEnrollJobFromMemory(long batchJobId) {
		printLogMessage("start public function deleteEnrollJobFromMemory().");

		// get enroll batch job
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		LocalEnrollBatchJob enrollBatchJob = queueManage
				.getEnrollBatchJobById(batchJobId);
		if (enrollBatchJob == null) {
			log.warn("Can not find the batch job(BatchJobId: {}).", batchJobId);
			return;
		}

		if (log.isInfoEnabled()) {
			log.info("delete Enroll Batch Job from memory"
					+ " without responsing to transformer.");
		}

		// TODO need to changing the batch job status in database?

		// delete a completed batch job from local enroll queue
		enrollBatchJob.setBatchJobStatus(EnrollBatchJobStatus.RETURNED);
		queueManage.deleteCompleteBatchJob(enrollBatchJob);

		printLogMessage("end public function deleteEnrollJobFromMemory().");
	}

	/**
	 * 
	 */
	@Override
	public void deleteDeleteJobFromMemory(long batchJobId) {
		printLogMessage("start public function deleteDeleteJobFromMemory().");

		deleteDeleteJob(batchJobId);

		printLogMessage("end public function deleteDeleteJobFromMemory().");
	}

	/**
	 * 
	 */
	@Override
	public void makeEnrollJobComplated(long batchJobId) {
		// TODO Auto-generated method stub

	}

	/**
	 * 
	 */
	@Override
	public void makeBatchJobJobSynced(long batchJobId, boolean isEnrollJob) {
		printLogMessage("start public function makeEnrollJobSynced().");

		if (isEnrollJob) {
			printLogMessage("make Enroll Batch Job Synced.");
			makeEnrollBatchJobSynced(batchJobId);
		} else {
			printLogMessage("delete Deletion Job.");
			deleteDeleteJob(batchJobId);
		}

		printLogMessage("end public function makeEnrollJobSynced().");
	}

	/**
	 * 
	 * @param batchJobId
	 * @return
	 */
	private void deleteDeleteJob(long batchJobId) {
		printLogMessage("start private function deleteDeleteJob().");

		DeletionJobManager deletionJobManager = DeletionJobManager
				.getInstance();
		LocalDeletionJob deletejob = deletionJobManager
				.getDeletionJob(batchJobId);
		if (deletejob == null) {
			log.warn("Cannot find LocalDeletionJob:(batchjobId {}).",
					batchJobId);
			return;
		}

		// delete Deletion Job
		deletionJobManager.deleteDeletionJob(deletejob);

		printLogMessage("end private function deleteDeleteJob().");
		return;
	}

	/**
	 * 
	 * @param batchJobId
	 * @return
	 */
	private void makeEnrollBatchJobSynced(long batchJobId) {
		printLogMessage("start private function makeEnrollBatchJobSynced().");

		// get enroll batch job
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		LocalEnrollBatchJob enrollBatchJob = queueManage
				.getEnrollBatchJobById(batchJobId);
		if (enrollBatchJob == null) {
			log.warn("Can not find the batch job(BatchJobId: {}).", batchJobId);
			return;
		}

		if (enrollBatchJob.isBatchJobStatus(EnrollBatchJobStatus.REGISTERED)) {

			// change enroll Batch Job Status and set synchronize end time
			enrollBatchJob.setBatchJobStatus(EnrollBatchJobStatus.SYNCHRONIZED);
			enrollBatchJob.setSyncEndTS(DateUtil.getCurrentDate());

			if (log.isInfoEnabled()) {
				BatchJobStatusLogger.outputBatchJobStatus(
						LogConstants.STATUS_CATEGORY_TME, batchJobId,
						EnrollBatchJobStatus.SYNCHRONIZED.name());
			}

			// Notify EnrollResponseServiceBean that Enroll Segment
			// synchronization.
			EnrollEventBus.notifyResponse(enrollBatchJob.getBatchJobId(),
					EnrollNotifierEnum.EnrollDeadLevelQueueService);
		} else {
			log.warn("Batch job status is incorrect. now is {}, need {}",
					enrollBatchJob.getBatchJobStatus().name(),
					EnrollBatchJobStatus.REGISTERED.name());
		}

		printLogMessage("end private function makeEnrollBatchJobSynced().");
		return;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
