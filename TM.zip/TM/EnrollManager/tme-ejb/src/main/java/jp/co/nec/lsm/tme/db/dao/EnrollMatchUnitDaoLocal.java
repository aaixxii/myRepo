package jp.co.nec.lsm.tme.db.dao;

import java.util.Date;
import java.util.List;

import javax.ejb.Local;

import jp.co.nec.lsm.proto.common.CommonProto.ComponentType;
import jp.co.nec.lsm.tm.common.constants.MUState;
import jp.co.nec.lsm.tm.db.common.entities.MatchUnitEntity;

/**
 * @author liuj <br>
 * 
 */
@Local
public interface EnrollMatchUnitDaoLocal {

	/**
	 * find EnrollTMEUnitEntity by match unit Id
	 * 
	 * @param uniqueId
	 *            match unit Id
	 * @return EnrollTMEUnitEntity
	 */
	public MatchUnitEntity search(String uniqueId);

	/**
	 * update EnrollTMEUnitEntity information
	 * 
	 * @param uniqueId
	 *            match unit Id
	 * @return EnrollTMEUnitEntity
	 */
	public void update(MatchUnitEntity enrollTMEUnit, ComponentType type,
			String url, Long ramSpace, Long diskSpace, Float performanceFactor,
			Integer numCPUs, String version);

	/**
	 * 
	 * @param type
	 * @param uniqueId
	 * @param url
	 * @param ramSpace
	 * @param diskSpace
	 * @param performanceFactor
	 * @param numCPUs
	 * @param version
	 * @return
	 */
	public MatchUnitEntity add(ComponentType type, String uniqueId, String url,
			Long ramSpace, Long diskSpace, Float performanceFactor,
			Integer numCPUs, String version);

	/**
	 * 
	 * @param muId
	 * @return
	 */
	public MatchUnitEntity findAndWarnState(long muId);

	/**
	 * 
	 * @param muId
	 * @return
	 */
	public boolean isWorkingUnitExist(long unitId);

	/**
	 * 
	 * @param mu
	 *            EnrollTMEUnitEntity
	 */
	public void mergeEnrollTMEUnitEntity(MatchUnitEntity enrollTMEUnit);

	/**
	 * get Match Units By Type And State from MUTCH_UNITS
	 * 
	 * @param type
	 *            Match Unit Type
	 * @param state
	 *            Match Unit State
	 * @return list of EnrollTMEUnitEntity
	 */
	public List<MatchUnitEntity> getMatchUnitsByTypeAndState(
			ComponentType type, MUState state);

	/**
	 * update MatchUnits state
	 * 
	 * @param em
	 * @param oldState
	 * @param newState
	 */
	public void updateMatchUnits(MUState oldState, MUState newState);

	/**
	 * get list of Timed Out EnrollTMEUnitEntity From Report time
	 * 
	 * @param minStart
	 * @return list of EnrollTMEUnitEntity
	 */
	public List<MatchUnitEntity> getTimedOutUtilsFromReport(Date minStart);
}
