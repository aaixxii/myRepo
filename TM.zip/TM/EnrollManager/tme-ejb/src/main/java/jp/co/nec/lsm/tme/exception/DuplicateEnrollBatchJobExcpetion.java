package jp.co.nec.lsm.tme.exception;

/**
 * @author zhulk <br>
 */
public class DuplicateEnrollBatchJobExcpetion extends EnrollRuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8805895846078291032L;

	public DuplicateEnrollBatchJobExcpetion(String message) {
		super(message);
	}

	public DuplicateEnrollBatchJobExcpetion(String message, Throwable cause) {
		super(message, cause);
	}

	public DuplicateEnrollBatchJobExcpetion(long batchJobId, Throwable cause) {
		super("batch Job: " + batchJobId + "is existed.", cause);
	}

	public DuplicateEnrollBatchJobExcpetion(long batchJobId) {
		super("batch Job: " + batchJobId + "is existed.");
	}

	public DuplicateEnrollBatchJobExcpetion(Throwable cause) {
		super(cause);
	}

}
