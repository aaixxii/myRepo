package jp.co.nec.lsm.tme.db.dao;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.lsm.proto.common.CommonProto.ComponentType;
import jp.co.nec.lsm.tm.common.constants.SegAssignmentRank;
import jp.co.nec.lsm.tm.db.common.entities.MatchUnitEntity;
import jp.co.nec.lsm.tm.db.common.entities.MuSegmentEntity;
import jp.co.nec.lsm.tm.db.common.entities.SegmentEntity;
import jp.co.nec.lsm.tm.db.common.entityhelpers.MuSegMapHelper;
import jp.co.nec.lsm.tm.db.common.procedure.MuSegmentObject;
import jp.co.nec.lsm.tm.db.common.procedure.MuSegmentUpdateProcedure;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author liuj <br>
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class EnrollMuSegmentMapDao implements EnrollMuSegmentMapDaoLocal {
	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager manager;
	@Resource(mappedName = "java:/OracleDS")
	protected DataSource dataSource;

	private MuSegMapHelper muSegMapHelper;

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(EnrollMuSegmentMapDao.class);

	@PostConstruct
	public void init() {
		printLogMessage("EnrollMuSegmentMapDao init");
		muSegMapHelper = new MuSegMapHelper(manager);
	}

	/**
	 * constructor
	 */
	public EnrollMuSegmentMapDao() {
	}

	/**
	 * Find MuSegMapEntity of USC
	 * 
	 * @return List of MuSegMapEntity
	 */
	@Override
	public List<MuSegmentEntity> findMuSegMapOfMU() {
		printLogMessage("start public function findMuSegMapOfMU()..");

		// Find MuSegMapEntity of USC
		List<MuSegmentEntity> muSegList = muSegMapHelper.findMuSegMapOfMU();

		printLogMessage("end public function findMuSegMapOfMU()..");

		return muSegList;
	}

	/**
	 * Find MuSegMapEntity of DM
	 * 
	 * @return List of MuSegMapEntity
	 */
	@Override
	public List<MuSegmentEntity> findMuSegMapOfDM() {
		printLogMessage("start public function findMuSegMapOfDM()..");

		// Find MuSegMapEntity of DM
		List<MuSegmentEntity> muSegList = muSegMapHelper.findMuSegMapOfDM();

		printLogMessage("end public function findMuSegMapOfDM()..");

		return muSegList;
	}

	/**
	 * Find List of EnrollTMEUnitEntity(USC) which is concerned with MU_SEGMENTS
	 * 
	 * @return List of EnrollTMEUnitEntity
	 */
	@Override
	public List<MatchUnitEntity> findUscInMuSegMap() {
		printLogMessage("start public function findUscInMuSegMap()..");

		// Find List of EnrollTMEUnitEntity(MFE) which is concerned with
		// MU_SEGMENTS
		List<MatchUnitEntity> muList = muSegMapHelper.findUscInMuSegMap();

		printLogMessage("end public function findUscInMuSegMap()..");

		return muList;
	}

	/**
	 * Find List of EnrollTMEUnitEntity(DM) which is concerned with MU_SEGMENTS
	 * 
	 * @return List of EnrollTMEUnitEntity
	 */
	@Override
	public List<MatchUnitEntity> findDMsInMuSegMap() {
		printLogMessage("start public function findDMsInMuSegMap()..");

		// Find List of EnrollTMEUnitEntity(MFE) which is concerned with
		// MU_SEGMENTS
		List<MatchUnitEntity> muList = muSegMapHelper.findDMsInMuSegMap();

		printLogMessage("end public function findDMsInMuSegMap()..");

		return muList;
	}

	/**
	 * Find List of SegmentEntity which is concerned with MU_SEGMENTS
	 * 
	 * @return List of SegmentEntity
	 */
	@Override
	public List<SegmentEntity> findSegmentsInMuSegMap() {
		printLogMessage("start public function findSegmentsInMuSegMap()..");

		// Find List of SegmentEntity which is concerned with MU_SEGMENTS
		List<SegmentEntity> preSegmentEntities = muSegMapHelper
				.findSegmentsInMuSegMap();

		printLogMessage("end public function findSegmentsInMuSegMap()..");

		return preSegmentEntities;
	}

	/**
	 * update new MU-Segment Maps information into database
	 * 
	 * @param newMatrix
	 *            new MU-Segment Maps(boolean)
	 * @param muEntities
	 *            MU Entities list
	 * @param segmentEntities
	 *            segment Entities list
	 * @param muSegMaps
	 *            MU-Segment Maps list
	 */
	@Override
	public void updateMuSegMap(boolean[][] newMatrix,
			List<MatchUnitEntity> muEntities,
			List<SegmentEntity> segmentEntities,
			List<MuSegmentEntity> muSegMaps, ComponentType unitType) {
		printLogMessage("start public function UpdateMuSegMap()..");

		long muId = 0;
		long segmentId = 0;

		checkParam(newMatrix, muEntities, segmentEntities, muSegMaps);

		List<MuSegmentObject> newMuSegMaps = new ArrayList<MuSegmentObject>();

		// update new MU-Segment Maps information into database
		for (int muIndex = 0; muIndex < muEntities.size(); muIndex++) {
			for (int segIndex = 0; segIndex < segmentEntities.size(); segIndex++) {
				// initiate variable
				muId = muEntities.get(muIndex).getId();
				segmentId = segmentEntities.get(segIndex).getSegmentId();

				// update new MU-Segment Maps information into database
				if (newMatrix[muIndex][segIndex]) {
					MuSegmentObject muSegmentObject = new MuSegmentObject(muId,
							segmentId, SegAssignmentRank.PRIMARY.ordinal(), 1);
					newMuSegMaps.add(muSegmentObject);
				}
			}
		}

		MuSegmentUpdateProcedure muSegmentProcedure = new MuSegmentUpdateProcedure(
				dataSource);
		muSegmentProcedure.execute(newMuSegMaps, unitType.ordinal());

		printLogMessage("end public function UpdateMuSegMap()..");
	}
	
	/**
	 * Find List of UnitEntity which is concerned with MU_SEGMENTS
	 * 
	 * @return List of UnitEntity
	 */
	@Override
	public List<MatchUnitEntity> findWorkingUnitInMuSegMapByUnitType(
			ComponentType unitType) {
		printLogMessage("start public function findWorkingUnitInMuSegMapByUnitType()..");
		// Find List of IdentifyUnitEntity(USC) which is concerned with
		// MU_SEGMENTS
		List<MatchUnitEntity> muList = muSegMapHelper
				.findWorkingUnitInMuSegMapByUnitType(unitType);
		printLogMessage("end public function findWorkingUnitInMuSegMapByUnitType()..");
		return muList;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

	/**
	 * 
	 * @param newMatrix
	 * @param muEntities
	 * @param segmentEntities
	 * @param muSegMaps
	 */
	private void checkParam(boolean[][] newMatrix,
			List<MatchUnitEntity> muEntities,
			List<SegmentEntity> segmentEntities, List<MuSegmentEntity> muSegMaps) {
		boolean isVaid = true;
		if (newMatrix == null || muEntities == null || segmentEntities == null
				|| muSegMaps == null) {
			isVaid = false;
		} else if (newMatrix.length == 0
				|| newMatrix.length != muEntities.size()) {
			isVaid = false;
		} else if (newMatrix[0].length == 0
				|| newMatrix[0].length != segmentEntities.size()) {
			isVaid = false;
		}

		if (isVaid == false) {
			throw new IllegalArgumentException(
					"Illegal Argument when call updateMuSegMap().");
		}
	}

	/**
	 * Find EnrollTMEUnitEntity of TMEUnit
	 * 
	 * @return List of EnrollTMEUnitEntity
	 */
	@Override
	public List<MatchUnitEntity> findUnitBySegId(ComponentType type,
			long segmentId) {
		printLogMessage("start public function findUnitBySegId()..");
		if (type == null) {
			throw new IllegalArgumentException(
					"ComponentType Illegal when call findUnitBySegId().");
		}
		List<MatchUnitEntity> unitList = muSegMapHelper.findUnitBySegId(type,
				segmentId);

		printLogMessage("start public function findUnitBySegId()..");
		return unitList;
	}
}
