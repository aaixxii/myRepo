package jp.co.nec.lsm.tme.timer;

import javax.ejb.Local;


/**
 * @author zhulk
 */
@Local
public interface EnrollMFETimeoutPollLocal {
	/**
	 * deadMM, Timeout Mu by Heart Beat and Report, Sgemt Job Timeout and Extrat
	 * Job Timeout
	 */
	public void poll();	
}
