package jp.co.nec.lsm.tme.core.clientapi.request.validator;

import jp.co.nec.lsm.tm.common.constants.RequestSpecConstants;

public class EnrollRequestSpec {
	public static final int REQUEST_ID_LENGTH = RequestSpecConstants.REQUEST_ID_LENGTH;
	public static final int REFERENCE_ID_LENGTH = RequestSpecConstants.REFERENCE_ID_LENGTH;
}
