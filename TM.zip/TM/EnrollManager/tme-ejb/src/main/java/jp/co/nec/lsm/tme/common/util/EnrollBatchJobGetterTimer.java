package jp.co.nec.lsm.tme.common.util;

import java.util.Date;

public class EnrollBatchJobGetterTimer {
	private Date nextGetJobTime;
	private boolean isOverHighLevelLimit = false;
	private int notCompleteJobs;
	
	private boolean isStop = false;

	private static EnrollBatchJobGetterTimer batchJobGetterTimer;

	private EnrollBatchJobGetterTimer() {
	}

	public static EnrollBatchJobGetterTimer getInstance() {
		if (batchJobGetterTimer == null) {
			batchJobGetterTimer = new EnrollBatchJobGetterTimer();
		}
		return batchJobGetterTimer;
	}

	public void setNextGetJobTime(Date nextGetJobTime) {
		this.nextGetJobTime = nextGetJobTime;
	}

	public Date getNextGetJobTime() {
		return nextGetJobTime;
	}

	public boolean isOverHighLevelLimit() {
		return isOverHighLevelLimit;
	}

	public void setOverHighLevelLimit(boolean isOverHighLevelLimit) {
		this.isOverHighLevelLimit = isOverHighLevelLimit;
	}

	public int getNotCompleteJobs() {
		return notCompleteJobs;
	}

	public void setNotCompleteJobs(int notCompleteJobs) {
		this.notCompleteJobs = notCompleteJobs;
	}

	public void setStop(boolean isStop) {
		this.isStop = isStop;
	}

	public boolean isStop() {
		return isStop;
	}

}
