package jp.co.nec.lsm.tme.receiver;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.MessageListener;

import jp.co.nec.lsm.event.Event;
import jp.co.nec.lsm.event.enroll.EnrollExtractJobCompletedEvent;
import jp.co.nec.lsm.event.receiver.AbstractEventReceiver;
import jp.co.nec.lsm.tm.common.constants.DeployName;
import jp.co.nec.lsm.tm.common.constants.JNDIConstants;
import jp.co.nec.lsm.tm.common.util.ServiceLocator;
import jp.co.nec.lsm.tme.service.sessionbean.TemplateManagerBean;
import jp.co.nec.lsm.tme.sessionbeans.api.TemplateManagerLocal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author liuyq <br>
 */
@MessageDriven(activationConfig = {
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
		@ActivationConfigProperty(propertyName = "destination", propertyValue = JNDIConstants.TEMPLATE_MANAGER_QUEUE),
		@ActivationConfigProperty(propertyName = "messageSelector", propertyValue = "messageReceiver = 'TemplateManagerBean'") })
public class ExtractJobCompletedEventReceiver extends AbstractEventReceiver
		implements MessageListener {

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(ExtractJobCompletedEventReceiver.class);

	/**
	 * receiver: EnrollUpdateBatchJobService.. after all extract jobs are done,
	 * notify the EnrollUpdateBatchJobService
	 * 
	 * @param event
	 */
	@Override
	protected void dispatchEvent(Event event) {
		printLogMessage("start private function dispatchEvent()..");

		// look up the service session bean
		if (!(event instanceof EnrollExtractJobCompletedEvent)) {
			log.error("event is not a ExtractJobCompletedEvent instance.");
			return;
		}

		String jndiName = DeployName.ENROLL_EARFILE + JNDIConstants.SPLIT
				+ TemplateManagerBean.class.getSimpleName()
				+ JNDIConstants.LOCAL;
		TemplateManagerLocal template = ServiceLocator.getLookUpJndiObject(
				jndiName, TemplateManagerLocal.class);
		// do service session bean
		template.insertTemplates(event.getBatchJobId());

		printLogMessage("end private function dispatchEvent()..");

	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
