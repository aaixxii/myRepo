package jp.co.nec.lsm.tme.timer;

import java.util.Collection;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerService;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import jp.co.nec.lsm.tm.common.constants.JNDIConstants;
import jp.co.nec.lsm.tm.common.util.ServiceLocator;
import jp.co.nec.lsm.tme.common.constants.EnrollConstants;
import jp.co.nec.lsm.tme.sessionbeans.api.EnrollMFEPollTimerStarterLocal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author mozj <br>
 *         start timer
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class EnrollMFEPollTimerStarterBean implements
		EnrollMFEPollTimerStarterLocal {
	private static Logger log = LoggerFactory
			.getLogger(EnrollMFEPollTimerStarterBean.class);
	@Resource
	TimerService timerService;
	private EnrollMFETimeoutPollLocal pollBean;

	@PostConstruct
	public void init() {
		printLogMessage("CNTR: EnrollUSCPollTimerStarterBean init");
	}

	/**
	 * constructor
	 */
	public EnrollMFEPollTimerStarterBean() {
	}

	/**
	 * 
	 */
	public void startTimer() {
		Collection<Timer> existingTimers = timerService.getTimers();
		if (existingTimers.isEmpty()) {
			printLogMessage("REGISTERING NEW TIMER");

			timerService.createTimer(
					EnrollConstants.POLLING_MFE_TIMEOUT_DURATION,
					EnrollConstants.POLLING_MFE_TIMEOUT_DURATION, null);
		} else {
			printLogMessage("TIMER ALREADY REGISTERED");
		}
	}

	/**
	 * 
	 * @param timer
	 */
	@Timeout
	public void timeout(javax.ejb.Timer timer) {
		if (pollBean == null) {
			try {
				pollBean = ServiceLocator.getLookUpJndiObject(
						JNDIConstants.TME_MFE_TIMEOUT_BEAN_POLL,
						EnrollMFETimeoutPollLocal.class);
			} catch (Exception e) {
				log.warn("EnrollMFEPollBean has not bound yet.");
			}
		} else {
			try {
				pollBean.poll();
			} catch (Exception e) {
				log.warn("EnrollMFEPollBean poll error.", e);
			}
		}

	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
