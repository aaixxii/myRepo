package jp.co.nec.lsm.tme.db.dao;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.sql.DataSource;

import jp.co.nec.lsm.tm.common.communication.PersonReferenceID;
import jp.co.nec.lsm.tm.common.communication.SegmentPosition;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.db.enroll.procedure.AddBiometricsProcedure;
import jp.co.nec.lsm.tm.db.enroll.procedure.BiometricsDeletionProcedure;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.exception.EnrollRuntimeException;

import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;

/**
 * @author liuj <br>
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class EnrollPersonBiometricDao implements EnrollPersonBiometricDaoLocal {

	@Resource(mappedName = "java:/OracleDS")
	protected DataSource dataSource;

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(EnrollPersonBiometricDao.class);

	@PostConstruct
	public void init() {
		printLogMessage("EnrollPersonBiometricDao init");
	}

	/**
	 * constructor
	 */
	public EnrollPersonBiometricDao() {
	}

	/**
	 * register all extract result of the extraction completed batch job into
	 * database.
	 * 
	 * @param enrollBatchJob
	 *            batch job
	 * @return inserted biometrics Ids
	 */
	@Override
	public synchronized List<SegmentPosition> updateBiometrics(
			LocalEnrollBatchJob enrollBatchJob, List<String> duplicateIds,
			List<PersonReferenceID> personReferenceIDList) {
		printLogMessage("start private function UpdateBiometrics()..");

		if (enrollBatchJob == null || duplicateIds == null
				|| personReferenceIDList == null) {
			String message = "Illegal Argument, can't add biometrics template.";
			log.warn(message);
			throw new IllegalArgumentException(message);
		}

		try {
			StopWatch stopWatch = new StopWatch();
			stopWatch.start();

			AddBiometricsProcedure addBioPro = new AddBiometricsProcedure(
					dataSource);
			// set biometrics data
			addBioPro.setBiometicsDate(enrollBatchJob.getSuccessJobTemplate());
			// register data into DB
			List<SegmentPosition> svdiList = addBioPro.execute(duplicateIds,
					personReferenceIDList);

			stopWatch.stop();

			PerformanceLogger.performanceOutput(
					LogConstants.COMPONENT_PERSON_BIOMETRICS_DAO,
					LogConstants.FUNCTION_UPDATE_BIOMETRICS, stopWatch
							.getTime());

			printLogMessage("end private function UpdateBiometrics()..");
			return svdiList;
		} catch (DataAccessException e) {
			throw new EnrollRuntimeException(
					"Failed to register person template.", e);
		}
	}

	/**
	 * delete Biometrics from Person_biometrics by referenceId
	 * 
	 * @param referenceId
	 * @return
	 */
	@Override
	public SegmentPosition deleteBiometrics(String referenceId) {
		BiometricsDeletionProcedure biometricsDeletion = new BiometricsDeletionProcedure(
				dataSource);
		SegmentPosition segmentPosition = biometricsDeletion
				.execute(referenceId);
		return segmentPosition;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
