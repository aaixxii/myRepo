package jp.co.nec.lsm.tme.db.entityhelpers;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.lsm.proto.common.CommonProto.ComponentType;
import jp.co.nec.lsm.tm.common.constants.MUState;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.common.entities.MatchUnitEntity;
import jp.co.nec.lsm.tm.db.common.entities.MuContactEntity;
import jp.co.nec.lsm.tm.db.common.entityhelpers.MatchUnitHelper;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class MatchUnitHelperTest {
	@Resource
	private DataSource dataSource;
	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager entityManager;
	private JdbcTemplate jdbcTemplate;
	private boolean ture;

	/**
	 * initialize the object of JdbcTemplate
	 */
	@Before
	public void setUp() {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testpersistBatchJob]<br/>
	 * 1 - clear concerning table in database for testing<br/>
	 * 2 - prepare TMEMatchUnitHelper For test<br/>
	 * 3 - call add, insert BatchJob into database<br/>
	 * 4 - assert concerning information<br/>
	 */
	@Test
	public void testAdd() {
		// 1 - clear concerning table in database for testing
		prepareDeleteConcerningTable();
		// 2 - prepare TMEMatchUnitHelper For test
		String uniqueId = "I'm uniqueue";
		String url = "http://localhost:8080/hoge";
		Long ramSpace = new Long(1234);
		Long diskSpace = new Long(4321);
		Float performanceFactor = new Float(3.2);
		Integer numCPUs = new Integer(3);
		Date now = DateUtil.getCurrentDate();
		String version = "2.3";
		MatchUnitHelper helper = new MatchUnitHelper(entityManager);
		// 3 - call add, insert BatchJob into database
		helper.add(ComponentType.MFE, uniqueId, url, ramSpace, diskSpace,
				performanceFactor, numCPUs, now, version);

		// 4 - assert concerning information
		{
			// assert match_units
			String sql = "select * from match_units";
			List<Map<String, Object>> list = jdbcTemplate.queryForList(sql);
			assertEquals(1, list.size());
			Map<String, Object> map = list.get(0);
			assertEquals(uniqueId, (String) map.get("UNIQUE_ID"));
			assertEquals(url, (String) map.get("CONTACT_URL"));
			assertEquals(numCPUs.intValue(), ((BigDecimal) map
					.get("NUMBER_OF_CPUS")).intValue());
			assertEquals(ramSpace.intValue(), ((BigDecimal) map
					.get("PRIMARY_SIZE")).intValue());
			assertEquals(diskSpace.intValue(), ((BigDecimal) map
					.get("SECONDARY_SIZE")).intValue());
		}
		{
			// assert mu_contacts
			String sql = "select * from mu_contacts";
			List<Map<String, Object>> list = jdbcTemplate.queryForList(sql);
			assertEquals(1, list.size());
			Map<String, Object> map = list.get(0);
			assertEquals(now, map.get("LAST_CONTACT_TS"));
			assertEquals(now, map.get("LAST_REPORT_TS"));
			assertEquals(1, ((BigDecimal) map.get("IDLE_FLAG")).intValue());
		}
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testpersistBatchJob]<br/>
	 * 1 - prepare data For Update test<br/>
	 * 2 - call update, to update database<br/>
	 * 3 - assert concerning information<br/>
	 * 4 - prepare data For Update1 test<br/>
	 * 5 - call update1, to update database<br/>
	 */
	@Test
	public void testUpdate() {
		MatchUnitHelper muHelper = new MatchUnitHelper(entityManager);
		prepareDeleteConcerningTable();
		// 1 - prepare data For Update test
		MatchUnitEntity mu = prepareUpdate();

		// 2 - call update, to update database
		muHelper.update(mu, ComponentType.MFE, "http://1234567.com", DateUtil
				.getCurrentDate(), new Long(1024), new Long(2048), 4,
				"versionx", new Float(1));

		// 3 - assert concerning information
		assertEquals(MUState.WORKING, mu.getState());
		assertEquals(ComponentType.MFE, mu.getType());
		assertEquals(true, mu.getTimes().getIdle());
		assertEquals("versionx", mu.getVersion());

		// 4 - prepare data For Update1 test
		MatchUnitEntity mu1 = prepareUpdate1();

		// 5 - call update1, to update database
		muHelper.update(mu1, ComponentType.MFE, "http://1234567.com", DateUtil
				.getCurrentDate(), new Long(1024), new Long(2048), 4,
				"versionx", new Float(1));

		// 3 - assert concerning information
		assertEquals(MUState.STOPPED, mu1.getState());
		assertEquals(ComponentType.MFE, mu1.getType());
		assertEquals(true, mu1.getTimes().getIdle());
		assertEquals("versionx", mu1.getVersion());
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testpersistBatchJob]<br/>
	 * 1 - clear concerning table in database for testing<br/>
	 * 2 - prepare TMEMatchUnitHelper For test<br/>
	 * 3 - call add, insert data into database<br/>
	 * 4 - call search, to get specified data<br/>
	 * 5 - assert concerning information<br/>
	 */
	@Test
	public void testSearch() {
		// 1 - clear concerning table in database for testing
		prepareDeleteConcerningTable();

		// 2 - prepare TMEMatchUnitHelper For test
		String uniqueId = "I'm uniqueue";
		String url = "http://localhost:8080/hoge";
		Long ramSpace = new Long(1234);
		Long diskSpace = new Long(4321);
		Float performanceFactor = new Float(3.2);
		Integer numCPUs = new Integer(3);
		Date now = DateUtil.getCurrentDate();
		String version = "2.3";
		MatchUnitHelper helper = new MatchUnitHelper(entityManager);
		// 3 - call add, insert data into database
		helper.add(ComponentType.MFE, uniqueId, url, ramSpace, diskSpace,
				performanceFactor, numCPUs, now, version);

		// 4 - call search, to get specified data
		MatchUnitEntity pIDUnitEntity = helper.search("I'm uniqueue");

		// 5 - assert concerning information
		{

			assertEquals(uniqueId, (String) pIDUnitEntity.getUniqueId());
			assertEquals(url, pIDUnitEntity.getURL());
			assertEquals(ComponentType.MFE, pIDUnitEntity.getType());
			assertEquals(version, pIDUnitEntity.getVersion());
		}

	}

	/**
	 * prepare data for testupdate method
	 * 
	 * 1 - prepare Data For TMEMatchUnitHelper
	 * 
	 * @return
	 */
	private MatchUnitEntity prepareUpdate() {
		MatchUnitEntity mu = new MatchUnitEntity();
		MuContactEntity muContactEntity = new MuContactEntity();
		{
			muContactEntity.setIdle(ture);
			muContactEntity.setLastContactTime(DateUtil.getCurrentDate());
			muContactEntity.setLastReportTime(DateUtil.getCurrentDate());
			muContactEntity.setMuId(2L);
		}
		mu.setBalanced(ture);
		mu.setId(5L);
		mu.setNumCPUs((short) 2);
		mu.setRevision(4);
		mu.setURL("http://1234567");
		mu.setUniqueId("unique");
		mu.setType(ComponentType.MFE);
		mu.setState(MUState.WORKING);
		mu.setPerformanceFactor(1.1f);
		mu.setPrimarySize(4L);
		mu.setSecondarySize(20L);
		mu.setVersion("version");
		mu.setTimes(muContactEntity);
		return mu;

	}

	/**
	 * prepare data for testupdate method 1 - prepare Data For
	 * TMEMatchUnitHelper
	 * 
	 * @return
	 */
	private MatchUnitEntity prepareUpdate1() {
		MatchUnitEntity mu = new MatchUnitEntity();
		MuContactEntity muContactEntity = new MuContactEntity();
		{
			muContactEntity.setIdle(ture);
			muContactEntity.setLastContactTime(DateUtil.getCurrentDate());
			muContactEntity.setLastReportTime(DateUtil.getCurrentDate());
			muContactEntity.setMuId(2L);
		}
		mu.setBalanced(ture);
		mu.setId(5L);
		mu.setNumCPUs((short) 2);
		mu.setRevision(4);
		mu.setURL("http://1234567");
		mu.setUniqueId("unique");
		mu.setType(ComponentType.MFE);
		mu.setState(MUState.STOPPED);
		mu.setPerformanceFactor(1.1f);
		mu.setPrimarySize(4L);
		mu.setSecondarySize(20L);
		mu.setVersion("version");
		mu.setTimes(muContactEntity);
		return mu;

	}

	/**
	 * clear concerning table in database for testing
	 */
	private void prepareDeleteConcerningTable() {
		jdbcTemplate.execute("delete FROM MU_SEGMENTS");
		jdbcTemplate.execute("delete FROM MU_CONTACTS");
		jdbcTemplate.execute("delete FROM MATCH_UNITS");
	}

}
