package jp.co.nec.lsm.tme.service.sessionbean;

import static org.junit.Assert.*;

import java.util.concurrent.ConcurrentLinkedQueue;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.tm.common.constants.EnrollErrorMessage;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tme.core.jobs.DeletionJobManager;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalDeletionJob;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobInfo;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobStatus;
import jp.co.nec.lsm.tme.service.sessionbean.EnrollDeadLevelQueueService;
import jp.co.nec.lsm.tme.util.TMETestUtil;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

public class EnrollDeadLevelQueueServiceTest {
	EnrollDeadLevelQueueService deadLevelQueueService;

	@Before
	public void setUp() {
		deadLevelQueueService = new EnrollDeadLevelQueueService();
		cleanMemoryQueue();

		setMockMethod();
	}

	@After
	public void tearDown() {

		cleanMemoryQueue();
	}

	/**
	 * 
	 */
	private void cleanMemoryQueue() {
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue = queueManage
				.getEnrollLinkQueue();

		for (LocalEnrollBatchJob enrollBatchJob : enrollLinkQueue) {
			enrollLinkQueue.remove(enrollBatchJob);
		}

		DeletionJobManager deletionJobManager = DeletionJobManager
				.getInstance();

		ConcurrentLinkedQueue<LocalDeletionJob> deletionJobQueue = deletionJobManager
				.getDeletionJobQueue();

		for (LocalDeletionJob deletionJob : deletionJobQueue) {
			deletionJobQueue.remove(deletionJob);
		}
	}

	/**
	 * setMockMethod
	 */
	private void setMockMethod() {
		TMETestUtil.setJMSMockMethod();
	}

	/**
	 * 
	 * @param batchJobId
	 * @param status
	 */
	private void prepareEnrollBatchJob(long batchJobId, int jobCount,
			EnrollBatchJobStatus status) {

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();

		LocalEnrollBatchJob enrollBatchJob = TMETestUtil
				.prepareDateforEnrollResultRequest(batchJobId, jobCount);

		enrollBatchJob.setBatchJobStatus(status);

		queueManage.addEnrollBatchJob(enrollBatchJob);
	}

	/**
	 * 
	 * @param batchJobId
	 * @param status
	 */
	private void prepareDeleetBatchJob(long batchJobId) {
		DeletionJobManager deletionJobManager = DeletionJobManager
				.getInstance();

		LocalDeletionJob deletejob = new LocalDeletionJob();

		deletejob.setBatchJobId(batchJobId);

		deletionJobManager.enqueueDeletionJob(deletejob);
	}

	@Test
	public void testDeleteEnrollJobFromMemory() {
		long batchJobId = 314543;
		int jobCount = 10;

		prepareEnrollBatchJob(batchJobId, jobCount,
				EnrollBatchJobStatus.SYNCHRONIZED);

		deadLevelQueueService.deleteEnrollJobFromMemory(batchJobId);

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		LocalEnrollBatchJob enrollBatchJob = queueManage
				.getEnrollBatchJobById(batchJobId);

		assertNull(enrollBatchJob);
	}

	@Test
	public void testDeleteEnrollJobFromMemory_NoFind() {
		long batchJobId = 874543;
		int jobCount = 10;

		prepareEnrollBatchJob(batchJobId, jobCount,
				EnrollBatchJobStatus.SYNCHRONIZED);

		deadLevelQueueService.deleteEnrollJobFromMemory(batchJobId + 1);

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		LocalEnrollBatchJob enrollBatchJob = queueManage
				.getEnrollBatchJobById(batchJobId);

		assertNotNull(enrollBatchJob);
	}

	@Test
	public void testDeleteDeleteJobFromMemory() {
		long batchJobId = 64543;

		prepareDeleetBatchJob(batchJobId);

		deadLevelQueueService.deleteDeleteJobFromMemory(batchJobId);

		DeletionJobManager deletionJobManager = DeletionJobManager
				.getInstance();
		LocalDeletionJob deletejob = deletionJobManager
				.getDeletionJob(batchJobId);

		assertNull(deletejob);
	}

	@Test
	public void testDeleteDeleteJobFromMemory_NoFind() {
		long batchJobId = 122543;

		prepareDeleetBatchJob(batchJobId);

		deadLevelQueueService.deleteDeleteJobFromMemory(batchJobId + 1);

		DeletionJobManager deletionJobManager = DeletionJobManager
				.getInstance();
		LocalDeletionJob deletejob = deletionJobManager
				.getDeletionJob(batchJobId);

		assertNotNull(deletejob);
	}

	@Ignore
	@Test
	public void testMakeEnrollJobComplated() {
		long batchJobId = 123543;
		int jobCount = 10;

		prepareEnrollBatchJob(batchJobId, jobCount,
				EnrollBatchJobStatus.EXTRACTED);

		deadLevelQueueService.makeEnrollJobComplated(batchJobId);

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		LocalEnrollBatchJob enrollBatchJob = queueManage
				.getEnrollBatchJobById(batchJobId);

		assertNotNull(enrollBatchJob);
		assertEquals(EnrollBatchJobStatus.REGISTERED, enrollBatchJob
				.getBatchJobStatus());
		for (int i = 1; i <= jobCount; i++) {
			LocalExtractJobInfo extractJob = enrollBatchJob
					.getExtractJobInfo(i);
			assertTrue(extractJob.isStatus(LocalExtractJobStatus.DONE));
			assertEquals(ReturnCode.JobFailed, extractJob.getReturnCode());
			assertEquals(EnrollErrorMessage.ENROLL_BATCHJOB_UNKNOWN
					.getErrorCode(), extractJob.getErrorCode());
			assertNotNull(extractJob.getErrorMessage());
		}
	}

	@Test
	public void testMakeBatchJobJobSynced_Enroll() {
		long batchJobId = 5634943;
		int jobCount = 10;

		prepareEnrollBatchJob(batchJobId, jobCount,
				EnrollBatchJobStatus.REGISTERED);

		deadLevelQueueService.makeBatchJobJobSynced(batchJobId, true);

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		LocalEnrollBatchJob enrollBatchJob = queueManage
				.getEnrollBatchJobById(batchJobId);

		assertNotNull(enrollBatchJob);
		assertEquals(EnrollBatchJobStatus.SYNCHRONIZED, enrollBatchJob
				.getBatchJobStatus());
		assertNotNull(enrollBatchJob.getSyncEndTS());
	}

	@Test
	public void testMakeBatchJobJobSynced_Enroll_NoFind() {
		long batchJobId = 129233;
		int jobCount = 10;

		prepareEnrollBatchJob(batchJobId, jobCount,
				EnrollBatchJobStatus.REGISTERED);

		deadLevelQueueService.makeBatchJobJobSynced(batchJobId + 1, true);

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		LocalEnrollBatchJob enrollBatchJob = queueManage
				.getEnrollBatchJobById(batchJobId);

		assertNotNull(enrollBatchJob);
		assertEquals(EnrollBatchJobStatus.REGISTERED, enrollBatchJob
				.getBatchJobStatus());
		assertNotNull(enrollBatchJob.getSyncEndTS());
	}

	@Test
	public void testMakeBatchJobJobSynced_Enroll_InvalidStatus() {
		long batchJobId = 34943;
		int jobCount = 10;

		prepareEnrollBatchJob(batchJobId, jobCount,
				EnrollBatchJobStatus.EXTRACTING);

		deadLevelQueueService.makeBatchJobJobSynced(batchJobId + 1, true);

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		LocalEnrollBatchJob enrollBatchJob = queueManage
				.getEnrollBatchJobById(batchJobId);

		assertNotNull(enrollBatchJob);
		assertEquals(EnrollBatchJobStatus.EXTRACTING, enrollBatchJob
				.getBatchJobStatus());
		assertNotNull(enrollBatchJob.getSyncEndTS());
	}

	@Test
	public void testMakeBatchJobJobSynced_DeleteJob() {
		long batchJobId = 23443;

		prepareDeleetBatchJob(batchJobId);

		deadLevelQueueService.makeBatchJobJobSynced(batchJobId, false);

		DeletionJobManager deletionJobManager = DeletionJobManager
				.getInstance();
		LocalDeletionJob deletejob = deletionJobManager
				.getDeletionJob(batchJobId);

		assertNull(deletejob);
	}

	@Test
	public void testMakeBatchJobJobSynced_DeleteJob_NoFind() {
		long batchJobId = 45363;

		prepareDeleetBatchJob(batchJobId);

		deadLevelQueueService.makeBatchJobJobSynced(batchJobId + 1, false);

		DeletionJobManager deletionJobManager = DeletionJobManager
				.getInstance();
		LocalDeletionJob deletejob = deletionJobManager
				.getDeletionJob(batchJobId);

		assertNotNull(deletejob);
	}
}
