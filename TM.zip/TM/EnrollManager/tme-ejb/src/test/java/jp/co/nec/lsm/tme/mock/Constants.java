package jp.co.nec.lsm.tme.mock;

import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;

public class Constants {

	// URL
	public static final String CLIENT_IP = "192.168.1.127";
	public static final String JBOSS_IP = "192.168.1.184";
	public static final String POST_URL = "http://" + JBOSS_IP
			+ ":8080/enrollmanager/";

	// port
	public static final int TRANSFORMER_REQUEST_PORT = 2344;
	public static final int TRANSFORMER_RECEIVE_PORT = 2345;
	public static final int MFE_RECEIVE_PORT = 2346;
	public static final int DM_RECEIVE_PORT = 2347;
	public static final int USC_RECEIVE_PORT = 2348;
	public static final int TEMPLATE_SIZE = 13632;

	// sevlet
	public static final String ENROLL_ACCEPT_SEVLET = "EnrollAccept";
	public static final String EXTRACTJOB_ASSIGN_SEVLET = "ExtractJobAssign";
	public static final String ENROLL_REPORT_SEVLET = "EnrollReport";
	public static final String REPORT_STATESEVLET = "ReportState";
	public static final String STATUS_SEVLET = "Status";
	public static final String ENTER_SEVLET = "Enter";
	public static final String EXIT_SEVLET = "Exit";
	public static final String DELETE_SEVLET = "Delete";

	// time
	public static final int HTTP_SOCKET_SEND_TIMEOUT = 20000;
	public static final int HTTP_SOCKET_RECIEVER_WAIT_TIME = 4000;
	public static final int BATCH_JOB_SEND_INTERVAL = 2000;
	public static final int EXTRACT_JOB_RESULT_SEND_INTERVAL = 1000;
	public static final int MFE_REQUST_WAIT_TIME = 5000;

	// Batch Job / Extract Job
	public static final int EXTRACT_JOB_COUNT = 20;
	public static final int BATCH_JOB_COUNT = 5;
	public static final long BATCH_JOB_START_ID = 16;
	public static final BatchType BATCH_JOB_TYPE = BatchType.ENROLL;
	public static final String REFERENCE_ID = "_referent_test_id_";
	public static final String REFERENCE_URL = "_referent_test_url_";
	public static final int MFE_REQUEST_JOB_NUMBER = 5;
	public static final double FAILED_EXTRACT_JOB_RATE = 0;

	public static final int THREAD_POOL_NUM = 2;

	// unit
	public static final String MFE_UNIQUE_ID = "MFE:" + CLIENT_IP;
	public static final String USC_UNIQUE_ID = "USC:" + CLIENT_IP;
	public static final String DM_UNIQUE_ID = "DM:" + CLIENT_IP;
	public static final String MFE_CONTACT_URL = "http://" + CLIENT_IP + ":"
			+ MFE_RECEIVE_PORT;
	public static final String USC_CONTACT_URL = "http://" + CLIENT_IP + ":"
			+ USC_RECEIVE_PORT;
	public static final String DM_CONTACT_URL = "http://" + CLIENT_IP + ":"
			+ DM_RECEIVE_PORT;
}
