package jp.co.nec.lsm.tme.core.gmvapi.request.sender;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import jp.co.nec.lsm.proto.segment.SegmentUpdateRequestProto.SegmentUpdateRequest;
import jp.co.nec.lsm.proto.segment.SegmentUpdateResponseProto.SegmentUpdateResponse;

import org.apache.commons.httpclient.HttpException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class SegmentUpdateRequestSenderTest {
	int port = 13187;

	@Before
	public void setUp() {

	}

	@After
	public void tearDown() {

	}

	@Test
	public void testSendRequest() {
		// receive Message class
		class ReceiveResponse extends Thread {

			public ReceiveResponse() {
			}

			public void run() {
				receiveMessage(port);
			}
		}
		// start receiveMessage thread
		new ReceiveResponse().start();

		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		// prepare data for test
		String url = "http://127.0.0.1:" + port;
		SegmentUpdateRequest segmentUpdateRequst = prepareSegmentPosition();

		// call sendRequest
		SegmentUpdateRequestSender sender = new SegmentUpdateRequestSender();
		SegmentUpdateResponse segmentUpdateResponse = sender.sendRequest(123,
				url, segmentUpdateRequst);

		// assert result
		assertNotNull(segmentUpdateResponse);
		assertEquals(120, segmentUpdateResponse.getGmvId());
		assertEquals(segmentUpdateRequst.getRecordCount(),
				segmentUpdateResponse.getRecordCount());
		assertEquals(segmentUpdateRequst.getSegmentId(), segmentUpdateResponse
				.getSegmentId());
		assertEquals(segmentUpdateRequst.getVersionTo(), segmentUpdateResponse
				.getVersion());

	}

	/**
	 * prepare SegmentPosition
	 * 
	 * @param segPos
	 * @throws IOException
	 * @throws HttpException
	 */
	private SegmentUpdateRequest prepareSegmentPosition() {
		// create a new Segment Update Request
		SegmentUpdateRequest.Builder segUpdReq = SegmentUpdateRequest
				.newBuilder();
		// set Segment Update Request information
		segUpdReq.setSegmentId(1);
		segUpdReq.setMaxSegmentSize(1);
		segUpdReq.setVersionFrom(0);
		segUpdReq.setVersionTo(0);
		segUpdReq.addAllDeleteIdList(new ArrayList<String>());

		// get Reference Id list
		List<String> referenceIds = new ArrayList<String>();
		referenceIds.add("test reference id");
		// set Person Biometrics templates
		byte[] template = { 1, 2, 3, 4, 5, 6 };
		segUpdReq.setRecordCount(referenceIds.size());
		segUpdReq.setTemplate(ByteString.copyFrom(template));

		return segUpdReq.build();
	}

	/**
	 * Call back
	 * 
	 * @param port
	 *            - listening Port
	 * @return
	 */
	private String receiveMessage(int port) {
		String returnResult = "failure";
		ServerSocket serverSocket = null;
		Socket socket = null;
		try {
			// Ready to Listening a Port
			serverSocket = new ServerSocket(port);
			socket = serverSocket.accept();

			try {
				Thread.sleep(4000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			InputStream in = socket.getInputStream();
			byte[] res = new byte[999999];
			in.read(res);

			byte[] data = getBodyByte(res);
			try {
				SegmentUpdateRequest up = SegmentUpdateRequest.parseFrom(data);

				SegmentUpdateResponse.Builder sur = SegmentUpdateResponse
						.newBuilder();
				sur.setGmvId(120);
				sur.setRecordCount(up.getRecordCount());
				sur.setSegmentId(up.getSegmentId());
				sur.setVersion(up.getVersionTo());
				byte[] body = sur.build().toByteArray();

				String responseHead = "HTTP/1.1 200 OK\r\n\r\n";
				byte[] head = responseHead.getBytes();

				socket.getOutputStream().write(getResponse(head, body));

				returnResult = "";

			} catch (InvalidProtocolBufferException e) {
				e.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				// close serverSocket socket BufferedReader stream
				if (socket != null) {
					socket.close();
				}
				if (serverSocket != null) {
					serverSocket.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return returnResult;
	}

	/**
	 * 
	 * @param head
	 * @param body
	 * @return
	 */
	private byte[] getResponse(byte[] head, byte[] body) {
		byte[] response = new byte[head.length + body.length];
		for (int i = 0; i < head.length; i++) {
			response[i] = head[i];
		}
		for (int j = 0; j < body.length; j++) {
			response[head.length + j] = body[j];
		}
		return response;
	}

	/**
	 * 
	 * @param bytes
	 * @return
	 */
	public byte[] getBodyByte(byte[] bytes) {
		int index = -1;
		int d1 = 0;
		int d2 = 0;
		int d3 = 0;
		int d4 = 0;
		for (int i = 0; i < bytes.length; i++) {
			d1 = bytes[i];
			d2 = bytes[i + 1];
			d3 = bytes[i + 2];
			d4 = bytes[i + 3];
			if (d1 == 13 && d2 == 10 && d3 == 13 && d4 == 10) {
				index = i + 4;
				break;
			}
		}
		ArrayList<Integer> data = new ArrayList<Integer>();
		int delIndex = 0;
		for (int j = 0;; j++) {
			int res = bytes[j + index];
			if (res == 0) {
				if (delIndex == j + index - 1) {
					break;
				}
				delIndex = j + index;
			}
			data.add(res);
		}
		byte[] a = new byte[data.size() - 1];
		for (int i = 0; i < data.size() - 1; i++) {
			a[i] = data.get(i).byteValue();
		}
		return a;
	}

}
