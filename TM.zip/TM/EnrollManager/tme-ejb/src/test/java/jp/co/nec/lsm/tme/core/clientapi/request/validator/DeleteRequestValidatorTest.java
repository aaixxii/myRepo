package jp.co.nec.lsm.tme.core.clientapi.request.validator;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import jp.co.nec.lsm.tm.common.validator.ValidationResult;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tm.protocolbuffer.deletion.DeleteRequestProto.DeleteRequest;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.acc.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.acc.proto.protobuf.BusinessMessage.CPBRequest;
import com.acc.proto.protobuf.BusinessMessage.E_REQUESET_TYPE;

public class DeleteRequestValidatorTest {

	@Before
	public void setUp() {

	}

	@After
	public void tearDown() {

	}

	/**
	 * 
	 */
	@Test
	public void testValidate_BatchJobId() {
		// prepare EnrollRequest for test
		DeleteRequest.Builder deleteRequest = DeleteRequest.newBuilder();
		deleteRequest.setBatchJobId(-123);
		deleteRequest.setType(BatchType.DELETE);

		CPBBusinessMessage.Builder businessMessage = CPBBusinessMessage
				.newBuilder();
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setRequestId(String.format("%036d", 15645));
		request.setEnrollmentId(String.format("%036d", 15645));
		request.setRequestType(E_REQUESET_TYPE.DELETE);
		businessMessage.setRequest(request.build());

		deleteRequest
				.addBusinessMessage(businessMessage.build().toByteString());
		List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>();
		businessMessageList.add(businessMessage.build());

		// call EnrollRequestValidator.validate()
		ValidationResult result = DeleteRequestValidator.validate(deleteRequest
				.build(), businessMessageList);

		// assert result
		assertEquals(1, result.getRequestError().size());
	}

	/**
	 * 
	 */
	@Test
	public void testValidate_BatchJobTyp() {
		// prepare EnrollRequest for test
		DeleteRequest.Builder deleteRequest = DeleteRequest.newBuilder();
		deleteRequest.setBatchJobId(123);
		deleteRequest.setType(BatchType.ENROLL);

		CPBBusinessMessage.Builder businessMessage = CPBBusinessMessage
				.newBuilder();
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setRequestId(String.format("%036d", 15645));
		request.setEnrollmentId(String.format("%036d", 15645));
		request.setRequestType(E_REQUESET_TYPE.DELETE);
		businessMessage.setRequest(request.build());

		deleteRequest
				.addBusinessMessage(businessMessage.build().toByteString());
		List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>();
		businessMessageList.add(businessMessage.build());

		// call EnrollRequestValidator.validate()
		ValidationResult result = DeleteRequestValidator.validate(deleteRequest
				.build(), businessMessageList);

		// assert result
		assertEquals(1, result.getRequestError().size());
	}

	/**
	 * 
	 */
	@Test
	public void testValidate_BusinessMessageCount_0() {
		// prepare EnrollRequest for test
		DeleteRequest.Builder deleteRequest = DeleteRequest.newBuilder();
		deleteRequest.setBatchJobId(123);
		deleteRequest.setType(BatchType.DELETE);

		List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>();

		// call EnrollRequestValidator.validate()
		ValidationResult result = DeleteRequestValidator.validate(deleteRequest
				.build(), businessMessageList);

		// assert result
		assertEquals(1, result.getRequestError().size());
	}

	/**
	 * 
	 */
	@Test
	public void testValidate_BusinessMessageCount_2() {
		// prepare EnrollRequest for test
		DeleteRequest.Builder deleteRequest = DeleteRequest.newBuilder();
		deleteRequest.setBatchJobId(123);
		deleteRequest.setType(BatchType.DELETE);

		CPBBusinessMessage.Builder businessMessage = CPBBusinessMessage
				.newBuilder();
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setRequestId(String.format("%036d", 15645));
		request.setEnrollmentId(String.format("%036d", 15645));
		request.setRequestType(E_REQUESET_TYPE.DELETE);
		businessMessage.setRequest(request.build());

		List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>();
		businessMessageList.add(businessMessage.build());
		businessMessageList.add(businessMessage.build());

		// call EnrollRequestValidator.validate()
		ValidationResult result = DeleteRequestValidator.validate(deleteRequest
				.build(), businessMessageList);

		// assert result
		assertEquals(1, result.getRequestError().size());
	}

	/**
	 * 
	 */
	@Test
	public void testValidate_RequestId() {
		// prepare EnrollRequest for test
		DeleteRequest.Builder deleteRequest = DeleteRequest.newBuilder();
		deleteRequest.setBatchJobId(123);
		deleteRequest.setType(BatchType.DELETE);

		CPBBusinessMessage.Builder businessMessage = CPBBusinessMessage
				.newBuilder();
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setRequestId(String.format("%030d", 15645));
		request.setEnrollmentId(String.format("%036d", 15645));
		request.setRequestType(E_REQUESET_TYPE.DELETE);
		businessMessage.setRequest(request.build());

		deleteRequest
				.addBusinessMessage(businessMessage.build().toByteString());
		List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>();
		businessMessageList.add(businessMessage.build());

		// call EnrollRequestValidator.validate()
		ValidationResult result = DeleteRequestValidator.validateRequest(deleteRequest
				.build().getBatchJobId(), businessMessageList.get(0).getRequest());

		// assert result
		assertEquals(1, result.getRequestError().size());
	}

	/**
	 * 
	 */
	@Test
	public void testValidate_EnrollmentId_length() {
		// prepare EnrollRequest for test
		DeleteRequest.Builder deleteRequest = DeleteRequest.newBuilder();
		deleteRequest.setBatchJobId(123);
		deleteRequest.setType(BatchType.DELETE);

		CPBBusinessMessage.Builder businessMessage = CPBBusinessMessage
				.newBuilder();
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setRequestId(String.format("%036d", 15645));
		request.setEnrollmentId(String.format("%030d", 15645));
		request.setRequestType(E_REQUESET_TYPE.DELETE);
		businessMessage.setRequest(request.build());

		deleteRequest
				.addBusinessMessage(businessMessage.build().toByteString());
		List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>();
		businessMessageList.add(businessMessage.build());

		// call EnrollRequestValidator.validate()
		ValidationResult result = DeleteRequestValidator.validateRequest(deleteRequest
				.build().getBatchJobId(), businessMessageList.get(0).getRequest());

		// assert result
		assertEquals(1, result.getRequestError().size());
	}

	/**
	 * 
	 */
	@Test
	public void testValidate_NoEnrollmentId() {
		// prepare EnrollRequest for test
		DeleteRequest.Builder deleteRequest = DeleteRequest.newBuilder();
		deleteRequest.setBatchJobId(123);
		deleteRequest.setType(BatchType.DELETE);

		CPBBusinessMessage.Builder businessMessage = CPBBusinessMessage
				.newBuilder();
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setRequestId(String.format("%036d", 15645));
		request.setRequestType(E_REQUESET_TYPE.DELETE);
		businessMessage.setRequest(request.build());

		deleteRequest
				.addBusinessMessage(businessMessage.build().toByteString());
		List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>();
		businessMessageList.add(businessMessage.build());

		// call EnrollRequestValidator.validate()
		ValidationResult result = DeleteRequestValidator.validateRequest(deleteRequest
				.build().getBatchJobId(), businessMessageList.get(0).getRequest());

		// assert result
		assertEquals(1, result.getRequestError().size());
	}

	/**
	 * 
	 */
	@Test
	public void testValidate_RequestType() {
		// prepare EnrollRequest for test
		DeleteRequest.Builder deleteRequest = DeleteRequest.newBuilder();
		deleteRequest.setBatchJobId(123);
		deleteRequest.setType(BatchType.DELETE);

		CPBBusinessMessage.Builder businessMessage = CPBBusinessMessage
				.newBuilder();
		CPBRequest.Builder request = CPBRequest.newBuilder();
		request.setRequestId(String.format("%036d", 15645));
		request.setEnrollmentId(String.format("%036d", 15645));
		request.setRequestType(E_REQUESET_TYPE.INSERT);
		businessMessage.setRequest(request.build());

		deleteRequest
				.addBusinessMessage(businessMessage.build().toByteString());
		List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>();
		businessMessageList.add(businessMessage.build());

		// call EnrollRequestValidator.validate()
		ValidationResult result = DeleteRequestValidator.validateRequest(deleteRequest
				.build().getBatchJobId(), businessMessageList.get(0).getRequest());

		// assert result
		assertEquals(1, result.getRequestError().size());
	}
}
