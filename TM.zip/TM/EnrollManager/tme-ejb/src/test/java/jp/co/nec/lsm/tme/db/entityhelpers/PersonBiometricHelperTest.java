package jp.co.nec.lsm.tme.db.entityhelpers;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.lsm.tm.common.communication.PersonReferenceID;
import jp.co.nec.lsm.tm.common.communication.PersonTemplate;
import jp.co.nec.lsm.tm.common.communication.SegmentPosition;
import jp.co.nec.lsm.tm.db.common.entityhelpers.PersonBiometricsHelper;
import jp.co.nec.lsm.tm.db.enroll.procedure.AddBiometricsProcedure;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.protobuf.ByteString;

/**
 * Test Class for TMEPersonBiometricHelper
 * 
 * 
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class PersonBiometricHelperTest {

	@Resource
	private DataSource dataSource;
	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager entityManager;

	/**
	 * 
	 * Test Case<br/>
	 * Test [testgetReferenceIds]<br/>
	 * 1 - prepare LocalEnrollBatchJobInfo For test<br/>
	 * 2 - call setBiometicsDate, insert LocalEnrollBatchJobInfo into Segment<br/>
	 * 3 - assert ReferenceId information<br/>
	 */
	@Test
	public void testgetReferenceIds() {
		cleardatabase();
		PersonBiometricsHelper personBiometricHelper = new PersonBiometricsHelper(
				entityManager);
		AddBiometricsProcedure addBiometricsProcedure = new AddBiometricsProcedure(
				dataSource);
		List<String> duplicateIds = new ArrayList<String>();
		List<PersonReferenceID> personReferenceIDList = new ArrayList<PersonReferenceID>();

		// 1 - prepare LocalEnrollBatchJobInfo For test
		List<PersonTemplate> jobInfo = prepareLocalEnrollBatchJobInfo();

		// 2 - call setBiometicsDate, add LocalEnrollBatchJobInfo into Segment
		addBiometricsProcedure.setBiometicsDate(jobInfo);
		List<SegmentPosition> list = addBiometricsProcedure.execute(
				duplicateIds, personReferenceIDList);

		// 3 - assert ReferenceId information<br/>
		assertEquals(1, list.size());
		for (SegmentPosition segmentPosition : list) {
			List<String> refId = personBiometricHelper.getReferenceIds(
					segmentPosition.getIndexStart(), segmentPosition
							.getIndexEnd());

			assertEquals(refId.size(), jobInfo.size());

			int count = 0;
			for (int i = 0; i < refId.size(); i++) {
				for (int j = 1; j <= jobInfo.size(); j++) {
					if (refId.get(i)
							.equals(jobInfo.get(j - 1).getReferenceId())) {
						count++;
						break;
					}
				}
			}
			assertEquals(count, refId.size());

		}
	}

	/**
	 * clear disturbing data in database
	 */
	private void cleardatabase() {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
		jdbcTemplate.execute("delete FROM PERSON_BIOMETRICS");
		jdbcTemplate.execute("delete FROM MU_SEGMENTS");
		jdbcTemplate.execute("delete FROM SEGMENT_VERSION_DETAIL");
		jdbcTemplate.execute("delete FROM SEGMENTS");
		jdbcTemplate.execute("delete FROM SYSTEM_CONFIG");
		jdbcTemplate.execute("insert into SYSTEM_CONFIG (CONFIG_ID,"
				+ "PROPERTY_NAME,PROPERTY_VALUE)"
				+ " values (1,'BEHAVIOR.MAX_SEGMENT_SIZE','10000000')");
	}

	/**
	 * prepare data for Template
	 * 
	 * @param jobId
	 * @return
	 */
	private ByteString prepareTemplate(String jobId) {
		int len = 200;
		byte[] bs = new byte[len];
		for (int j = 0; j < len; j++) {
			if (j < jobId.length()) {
				bs[j] = jobId.getBytes()[j];
			} else {
				bs[j] = (byte) 15;// (j % 100 + 10);
			}
		}
		return ByteString.copyFrom(bs);
	}

	/**
	 * prepare data for LocalEnrollBatchJobInfo
	 * 
	 * @return
	 */
	private List<PersonTemplate> prepareLocalEnrollBatchJobInfo() {

		List<PersonTemplate> jobinfo = new ArrayList<PersonTemplate>();
		for (int i = 1; i <= 20; i++) {
			byte[] bs = prepareTemplate(String.valueOf(i)).toByteArray();

			PersonTemplate localEnrollBatchJobInfo = new PersonTemplate();
			localEnrollBatchJobInfo.setReferenceId("reference" + i);
			localEnrollBatchJobInfo.setBiometicsData(bs);
			jobinfo.add(localEnrollBatchJobInfo);

		}
		return jobinfo;
	}
}
