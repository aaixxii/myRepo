package jp.co.nec.lsm.tme.mock;

import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;

import jp.co.nec.lsm.proto.segment.SegmentUpdateRequestProto.SegmentUpdateRequest;
import jp.co.nec.lsm.proto.segment.SegmentUpdateResponseProto.SegmentUpdateResponse;

import com.google.protobuf.InvalidProtocolBufferException;

public class MatchScroeUnitMock {
	private final int port = Constants.USC_RECEIVE_PORT;
	private final int recievetime = Constants.HTTP_SOCKET_RECIEVER_WAIT_TIME;

	public static void main(String[] args) {
		MatchScroeUnitMock client = new MatchScroeUnitMock();
		for (int i = 0; i < 1000; i++) {
			String result = client.receiveMessage(client.port);

			if (result == "") {
				System.out.println("USC recieve is successful.");
			} else {
				System.out.println("USC recieve is failure.");
			}
		}
	}

	/**
	 * wait for MM to Call back
	 * 
	 * @param port
	 *            - listening Port
	 * @return
	 */
	private String receiveMessage(int port) {
		String returnResult = "failure";
		ServerSocket serverSocket = null;
		Socket socket = null;
		try {
			// Ready to Listening a Port
			serverSocket = new ServerSocket(port);
			socket = serverSocket.accept();

			try {
				Thread.sleep(recievetime);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			InputStream in = socket.getInputStream();
			byte[] res = new byte[999999];
			in.read(res);

			byte[] data = MockCommon.getBodyByte(res);
			try {
				SegmentUpdateRequest up = SegmentUpdateRequest.parseFrom(data);

				SegmentUpdateResponse.Builder sur = SegmentUpdateResponse
						.newBuilder();
				sur.setGmvId(120);
				sur.setRecordCount(up.getRecordCount());
				sur.setSegmentId(up.getSegmentId());
				sur.setVersion(up.getVersionTo());
				byte[] body = sur.build().toByteArray();

				String responseHead = "HTTP/1.1 200 OK\r\n\r\n";
				byte[] head = responseHead.getBytes();

				socket.getOutputStream().write(getResponse(head, body));

				returnResult = "";

			} catch (InvalidProtocolBufferException e) {
				e.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				// close serverSocket socket BufferedReader stream
				if (socket != null) {
					socket.close();
				}
				if (serverSocket != null) {
					serverSocket.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return returnResult;
	}

	private byte[] getResponse(byte[] head, byte[] body) {
		byte[] response = new byte[head.length + body.length];
		for (int i = 0; i < head.length; i++) {
			response[i] = head[i];
		}
		for (int j = 0; j < body.length; j++) {
			response[head.length + j] = body[j];
		}
		return response;
	}

}
