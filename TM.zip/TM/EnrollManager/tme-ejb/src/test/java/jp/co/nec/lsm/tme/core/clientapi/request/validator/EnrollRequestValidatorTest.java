package jp.co.nec.lsm.tme.core.clientapi.request.validator;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import jp.co.nec.lsm.tm.common.validator.ValidationResult;
import jp.co.nec.lsm.tm.common.validator.ValidationResultError;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tm.protocolbuffer.enroll.EnrollRequestProto.EnrollRequest;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.acc.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.acc.proto.protobuf.BusinessMessage.CPBRequest;
import com.acc.proto.protobuf.BusinessMessage.E_REQUESET_TYPE;
import com.google.protobuf.ByteString;

public class EnrollRequestValidatorTest {

	private final String referenceID = "QueueManager_";

	@Before
	public void setUp() {

	}

	@After
	public void tearDown() {

	}

	/**
	 * 
	 */
	@Test
	public void testValidate_BatchJob() {
		// prepare EnrollRequest for test
		EnrollRequest.Builder enrollRequest = EnrollRequest.newBuilder();
		enrollRequest.setBatchJobId(-10);
		enrollRequest.setType(BatchType.DELETE);
		enrollRequest.addBusinessMessage(ByteString.EMPTY);

		List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>();

		// call EnrollRequestValidator.validate()
		ValidationResult result = EnrollRequestValidator.validate(enrollRequest
				.build(), businessMessageList, 1000);

		// assert result
		assertEquals(3, result.getRequestError().size());
		for (ValidationResultError error : result.getRequestError()) {
			assertEquals(false, error.isValid());
			assertEquals(false, error.getInvalidReason().isEmpty());
		}
	}

	/**
	 * 
	 */
	@Test
	public void testValidate_ExtractJobCount() {
		long batchJobId = 123;
		int jobCount = 1023;

		// prepare EnrollRequest for test
		EnrollRequest.Builder enrollRequest = EnrollRequest.newBuilder();
		enrollRequest.setBatchJobId(batchJobId);
		enrollRequest.setType(BatchType.ENROLL);
		enrollRequest.addBusinessMessage(ByteString.EMPTY);

		// prepare EnrollRequest for test
		List<CPBBusinessMessage> businessMessageList = prepareBusinessMessageList(
				batchJobId, jobCount);

		// call EnrollRequestValidator.validate()
		ValidationResult result = EnrollRequestValidator.validate(enrollRequest
				.build(), businessMessageList, 1000);

		// assert result
		assertEquals(1, result.getRequestError().size());
		for (ValidationResultError error : result.getRequestError()) {
			assertEquals(false, error.isValid());
			assertEquals(false, error.getInvalidReason().isEmpty());
		}

	}

	/**
	 * prepare data for EnrollRequest
	 * 
	 * @param batchJobId
	 * @param extractJobCount
	 * @return
	 */
	private List<CPBBusinessMessage> prepareBusinessMessageList(
			long batchJobId, int extractJobCount) {

		List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>();

		for (int i = 1; i <= extractJobCount; i++) {

			CPBBusinessMessage.Builder businessMessage = CPBBusinessMessage
					.newBuilder();
			CPBRequest.Builder request = CPBRequest.newBuilder();
			request.setRequestId(String.valueOf(15 + i));
			request.setEnrollmentId(referenceID + String.format("%02d", i));
			request.setRequestType(E_REQUESET_TYPE.DELETE);
			businessMessage.setRequest(request.build());

			businessMessageList.add(businessMessage.build());
		}

		return businessMessageList;
	}
}
