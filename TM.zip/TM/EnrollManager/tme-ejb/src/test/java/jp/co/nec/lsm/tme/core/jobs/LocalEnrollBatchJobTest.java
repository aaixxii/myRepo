package jp.co.nec.lsm.tme.core.jobs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.tm.common.constants.Constants;
import jp.co.nec.lsm.tm.common.constants.EnrollErrorMessage;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.acc.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.acc.proto.protobuf.BusinessMessage.CPBRequest;
import com.acc.proto.protobuf.BusinessMessage.E_REQUESET_TYPE;
import com.google.protobuf.ByteString;

public class LocalEnrollBatchJobTest {

	private int jobNumber = 100;
	private final String referentID = "QueueManager_";

	@Before
	public void setUp() {

	}

	@After
	public void tearDown() {

	}

	/**
	 * test function makeDuplicatedExtractJobsFailed
	 */
	@Test
	public void testMakeDuplicatedExtractJobsFailed() {
		final long batchID = 9765L;
		int listCount = jobNumber / 2;
		// prepare LocalEnrollBatchJob for test
		LocalEnrollBatchJob enrollBatchJob = prepareLocalEnrollBatchJob(
				batchID, jobNumber);
		// prepare duplication ReferenceIds for test
		List<String> duplicateIds = new ArrayList<String>();
		for (int i = 1; i <= listCount; i++) {
			LocalExtractJobInfo extractjob = enrollBatchJob
					.getExtractJobInfo(i);
			duplicateIds.add(extractjob.getReferenceId());
		}

		// call makeDuplicatedExtractJobsFailed
		enrollBatchJob.makeDuplicatedExtractJobsFailed(duplicateIds);

		// assert result
		// assert all Extract Job Info
		for (int i = 1; i < jobNumber; i++) {
			LocalExtractJobInfo extractjob = enrollBatchJob
					.getExtractJobInfo(i);
			if (i <= listCount) {
				assertEquals(ReturnCode.JobFailed, extractjob.getReturnCode());
				assertEquals(EnrollErrorMessage.REFERENCEID_DUPLICATED
						.getErrorCode(), extractjob.getErrorCode());
				assertNotNull(extractjob.getErrorMessage());
			} else {
				assertEquals(ReturnCode.JobSuccess, extractjob.getReturnCode());
				assertEquals(null, extractjob.getErrorCode());
				assertEquals(null, extractjob.getErrorMessage());
			}
		}
	}

	/**
	 * test function getTemplateArray
	 */
	@Test
	public void testGetTemplateArray() {
		final long batchID = 9875L;
		int listCount = jobNumber / 2;
		// prepare LocalEnrollBatchJob for test
		LocalEnrollBatchJob enrollBatchJob = prepareLocalEnrollBatchJob(
				batchID, jobNumber);
		// prepare ReferenceIds for test
		List<String> referenceIds = new ArrayList<String>();
		for (int i = 1; i <= listCount; i++) {
			LocalExtractJobInfo extractjob = enrollBatchJob
					.getExtractJobInfo(i);
			referenceIds.add(extractjob.getReferenceId());
		}
		// call getTemplateArray
		byte[] template = enrollBatchJob.getTemplateArray(referenceIds);

		// assert result
		assertEquals(Constants.PERSON_TEMPLATE_SIZE * listCount,
				template.length);
		int index = 1;
		for (int pos = 0; pos < template.length;) {
			LocalExtractJobInfo extractjob = enrollBatchJob
					.getExtractJobInfo(index);
			for (int j = 0; j < extractjob.getTemplate().length; j++) {
				assertEquals(template[pos], extractjob.getTemplate()[j]);
				pos++;
			}
			index++;
		}

	}

	/**
	 * test function getTemplateArray
	 */
	@Test
	public void testGetTemplateArray_BIO_ID() {
		final long batchID = 9815L;
		int listCount = jobNumber / 2;
		// prepare LocalEnrollBatchJob for test
		LocalEnrollBatchJob enrollBatchJob = prepareLocalEnrollBatchJob(
				batchID, jobNumber);
		// call getTemplateArray
		byte[] template = enrollBatchJob.getTemplateArray(1, listCount);

		// assert result
		assertEquals(Constants.PERSON_TEMPLATE_SIZE * listCount,
				template.length);
		int index = 1;
		for (int pos = 0; pos < template.length;) {
			LocalExtractJobInfo extractjob = enrollBatchJob
					.getExtractJobInfo(index);
			for (int j = 0; j < extractjob.getTemplate().length; j++) {
				assertEquals(template[pos], extractjob.getTemplate()[j]);
				pos++;
			}
			index++;
		}

	}

	/**
	 * 
	 * @param batchJobId
	 * @param jobCount
	 * @return
	 */
	private LocalEnrollBatchJob prepareLocalEnrollBatchJob(long batchJobId,
			int jobCount) {
		LocalEnrollBatchJob enrollBatchJob = new LocalEnrollBatchJob();
		enrollBatchJob.setBatchJobId(batchJobId);
		enrollBatchJob.setBatchJobStatus(EnrollBatchJobStatus.QUEUED);
		enrollBatchJob.setBatchJobType(BatchType.ENROLL);
		enrollBatchJob.setEnqueueTS(DateUtil.getCurrentDate());
		enrollBatchJob.setExtractEndTS(DateUtil.getCurrentDate());

		for (int i = 1; i <= jobCount; i++) {
			LocalExtractJobInfo jobInfo = new LocalExtractJobInfo();
			jobInfo.setFailureCount(i);
			jobInfo.setJobId(i);
			jobInfo.setReferenceId(referentID + i);
			jobInfo.setRequestId(String.valueOf(i));
			jobInfo.setReturnCode(ReturnCode.JobSuccess);
			jobInfo.setStatus(LocalExtractJobStatus.EXTRACTING);
			jobInfo.setTemplate(prepareTemplate(String.valueOf(i))
					.toByteArray());
			jobInfo.setBiometricId(i);
			// CPBRequest
			CPBRequest.Builder request = CPBRequest.newBuilder();
			request.setRequestId(String.format("%018d", batchJobId)
					+ String.format("%018d", i));
			request
					.setEnrollmentId("QueueManager_"
							+ String.format("%023d", i));
			request.setRequestType(E_REQUESET_TYPE.INSERT);
			CPBBusinessMessage.Builder businessMessage = CPBBusinessMessage
					.newBuilder();
			businessMessage.setRequest(request);
			jobInfo.setRequest(businessMessage.build());

			enrollBatchJob.putExtractJobInfo(jobInfo);
		}
		return enrollBatchJob;
	}

	/**
	 * 
	 * @param jobId
	 * @return
	 */
	private ByteString prepareTemplate(String jobId) {
		int len = Constants.PERSON_TEMPLATE_SIZE;
		byte[] bs = new byte[len];
		for (int j = 0; j < len; j++) {
			if (j < jobId.length()) {
				bs[j] = jobId.getBytes()[j];
			} else {
				bs[j] = (byte) (j % 100 + 10);
			}
		}
		return ByteString.copyFrom(bs);
	}

}
