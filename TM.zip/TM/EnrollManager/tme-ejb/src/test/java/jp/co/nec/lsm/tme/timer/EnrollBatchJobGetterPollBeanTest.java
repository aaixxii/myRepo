package jp.co.nec.lsm.tme.timer;

import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.annotation.Resource;
import javax.sql.DataSource;

import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tme.common.util.EnrollBatchJobGetterTimer;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.util.TMETestUtil;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.acc.proto.protobuf.BusinessMessage.CPBBusinessMessage;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollBatchJobGetterPollBeanTest {

	@Resource
	private DataSource dataSource;
	@Resource
	private EnrollBatchJobGetterPollBean pollBean;

	private JdbcTemplate jdbcTemplate;
	private boolean loopFalg = true;
	private long fistTime = 0;
	private long secndTime = 0;

	ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue;

	@Before
	public void setUp() {
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		enrollLinkQueue = queueManage.getEnrollLinkQueue();

		for (LocalEnrollBatchJob enrollBatchJob : enrollLinkQueue) {
			enrollLinkQueue.remove(enrollBatchJob);
		}

		jdbcTemplate = new JdbcTemplate(dataSource);

		fistTime = 0;
		secndTime = 0;

		clearDB();
	}

	@After
	public void tearDown() {
		clearDB();
	}

	/**
	 * 
	 */
	private void clearDB() {
		jdbcTemplate.execute("delete from SYSTEM_CONFIG");
		jdbcTemplate.execute("commit");
	}

	/**
	 * 
	 */
	private void updateDB(int port) {
		jdbcTemplate
				.execute("insert into SYSTEM_CONFIG (CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)"
						+ " values (1,'INTERVALS.ENROLL_JOBFETCH_FOR_HIGH_LEVEL','15000')");
		jdbcTemplate
				.execute("insert into SYSTEM_CONFIG (CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)"
						+ " values (2,'INTERVALS.ENROLL_JOBFETCH_FOR_NORMAL_LEVEL','10000')");
		jdbcTemplate
				.execute("insert into SYSTEM_CONFIG (CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)"
						+ " values (3,'INTERVALS.ENROLL_JOBFETCH_FOR_LOW_LEVEL','5000')");
		jdbcTemplate
				.execute("insert into SYSTEM_CONFIG (CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)"
						+ " values (4,'BATCHJOB_COUNT.ENROLL_JOBFETCH_FOR_HIGH_LEVEL','5')");
		jdbcTemplate
				.execute("insert into SYSTEM_CONFIG (CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)"
						+ " values (5,'BATCHJOB_COUNT.ENROLL_JOBFETCH_FOR_LOW_LEVEL','3')");
		jdbcTemplate
				.execute("insert into SYSTEM_CONFIG (CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)"
						+ " values (6,'TRANSFORMER.ENROLL_GETBATCHJOB_URL','http://127.0.0.1:"
						+ port + "')");
		jdbcTemplate
				.execute("insert into SYSTEM_CONFIG (CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)"
						+ " values (7,'TRANSFORMER.ENROLL_GET_JOB_COUNT','100')");
		jdbcTemplate
				.execute("insert into SYSTEM_CONFIG (CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)"
						+ " values (8,'TRANSFORMER.ENROLL_GET_BATCHJOB_COUNT','1')");

		jdbcTemplate
				.execute("insert into SYSTEM_CONFIG (CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)"
						+ " values (9,'TRANSFORMER.ENROLL_TURNAROUNDTIME_SEC','10')");

		jdbcTemplate
				.execute("insert into SYSTEM_CONFIG (CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)"
						+ " values (10,'ENROLL_SERVICE.ENABLED','TRUE')");
		jdbcTemplate.execute("commit");
	}

	@Test
	public void testPoll_low() {
		long batchJobStartId = 826;
		int batchJobCount = 2;
		int extractJonCount = 12;
		int port = 6622;
		int poolTimes = 0;

		updateDB(port);
		startReceiveThread(port);

		enqueueBatchJobs(batchJobStartId, batchJobCount, extractJonCount);

		while (loopFalg && ++poolTimes < 55 * 3) {
			pollBean.poll();

			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
			}
		}
		assertResult(5500, 4500);
	}

	@Test
	public void testPoll_nomal() {
		long batchJobStartId = 8146;
		int batchJobCount = 4;
		int extractJonCount = 12;
		int port = 6522;
		int poolTimes = 0;

		updateDB(port);
		startReceiveThread(port);

		enqueueBatchJobs(batchJobStartId, batchJobCount, extractJonCount);

		while (loopFalg && ++poolTimes < 105 * 3) {
			pollBean.poll();
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
			}
		}

		assertResult(10500, 9500);
	}

	@Test
	public void testPoll_high() {
		long batchJobStartId = 8746;
		int batchJobCount = 6;
		int extractJonCount = 12;
		int port = 6537;
		int poolTimes = 0;

		updateDB(port);

		startReceiveThread(port);

		enqueueBatchJobs(batchJobStartId, batchJobCount, extractJonCount);

		while (loopFalg && ++poolTimes < 155 * 3) {
			pollBean.poll();

			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
			}
		}

		assertResult(15500, 14500);
	}

	@Test
	public void testPoll_highLimits() {
		long batchJobStartId = 9746;
		int batchJobCount = 9;
		int extractJonCount = 12;
		int port = 6837;
		int poolTimes = 0;

		updateDB(port);

		class SubThread extends Thread {

			public SubThread() {
			}

			public void run() {
				for (int i = 0; i < 2;) {
					EnrollBatchJobGetterTimer batchJobGetterTimer = EnrollBatchJobGetterTimer
							.getInstance();
					Date nextGetJobTime = batchJobGetterTimer
							.getNextGetJobTime();

					if (nextGetJobTime != null) {
						if (i == 0) {
							fistTime = nextGetJobTime.getTime();
							i++;
						} else if (i == 1
								&& fistTime != nextGetJobTime.getTime()) {
							secndTime = nextGetJobTime.getTime();
							i++;
						}
					}

					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
					}
				}

				loopFalg = false;
			}
		}

		enqueueBatchJobs(batchJobStartId, batchJobCount, extractJonCount);

		EnrollBatchJobGetterTimer batchJobGetterTimer = EnrollBatchJobGetterTimer
				.getInstance();
		batchJobGetterTimer.setNextGetJobTime(null);

		new SubThread().start();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		while (loopFalg && ++poolTimes < 155 * 3) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
			}

			pollBean.poll();
		}

		assertResult(15500, 14500);
	}

	/**
	 * 
	 * @param highLimit
	 * @param loeLimit
	 */
	private void assertResult(long highLimit, long lowLimit) {

		long intervalTime = secndTime - fistTime;

		assertTrue(intervalTime < highLimit && intervalTime > lowLimit);
	}

	/**
	 * 
	 */
	private void startReceiveThread(int port) {
		class ReceiveResponse extends Thread {

			private int port;

			public ReceiveResponse(int port) {
				this.port = port;
			}

			public void run() {
				for (int i = 0; i < 2; i++) {
					receiveMessage(port);

					if (i == 0) {
						fistTime = DateUtil.getCurrentDate().getTime();
					} else if (i == 1) {
						secndTime = DateUtil.getCurrentDate().getTime();
					}
				}

				loopFalg = false;
			}
		}

		new ReceiveResponse(port).start();

		try {
			Thread.sleep(300);
		} catch (InterruptedException e) {
		}
	}

	/**
	 * 
	 * @param batchJobStartId
	 * @param batchJobCount
	 * @param extractJonCount
	 */
	private void enqueueBatchJobs(long batchJobStartId, int batchJobCount,
			int extractJonCount) {
		for (long batchJobId = batchJobStartId; batchJobId < batchJobStartId
				+ batchJobCount; batchJobId++) {
			List<CPBBusinessMessage> businessMessageList = new ArrayList<CPBBusinessMessage>();
			for (int i = 0; i < extractJonCount; i++) {
				CPBBusinessMessage request = TMETestUtil.preperaResponse(
						batchJobId, i + 1);
				businessMessageList.add(request);
			}

			LocalEnrollBatchJob enrollBatchJob = LocalEnrollBatchJob
					.createEnrollBatchJob(batchJobId, BatchType.ENROLL,
							businessMessageList, DateUtil.getCurrentDate());

			EnrollBatchJobManager.getInstance().addEnrollBatchJob(
					enrollBatchJob);
		}
	}

	/**
	 * wait for MM to Call back
	 * 
	 * @param port
	 * 
	 * @param port
	 *            - listening Port
	 * @return
	 */
	private String receiveMessage(int port) {
		// byte[] data = null;

		ServerSocket serverSocket = null;
		Socket socket = null;
		try {
			// Ready to Listening a Port
			serverSocket = new ServerSocket(port);
			socket = serverSocket.accept();

			try {
				Thread.sleep(4000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			InputStream in = socket.getInputStream();
			byte[] res = new byte[999999];
			in.read(res);

			PrintWriter writer = null;
			writer = new PrintWriter(socket.getOutputStream(), true);
			writer.println("HTTP/1.1 200 OK\r\n");
		} catch (IOException e) {
			e.printStackTrace();
			return "failure";
		} finally {
			try {
				// close serverSocket socket BufferedReader stream
				if (socket != null) {
					socket.close();
				}
				if (serverSocket != null) {
					serverSocket.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
				return "failure";
			}
		}

		return null;
	}
}
