package jp.co.nec.lsm.tme.db.procedure;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.lsm.tm.common.communication.SegmentPosition;
import jp.co.nec.lsm.tm.common.constants.Constants;
import jp.co.nec.lsm.tm.db.enroll.procedure.BiometricsDeletionProcedure;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class BiometricsDeletionProcedureTest {
	@PersistenceContext(unitName = "tme-ngi")
	protected EntityManager entityManager;
	@Resource
	protected DataSource dataSource;
	@Resource
	protected JdbcTemplate jdbcTemplate;

	private String referenceId = "BiometricsDeletion_referenceId_";

	@Before
	public void setUp() {
		clearDatabase();
	}

	@After
	public void tearDown() {
		clearDatabase();
	}

	@Test
	public void testBiometricsDeletion_Deleted() {
		BiometricsDeletionProcedure biometricsDeletion = new BiometricsDeletionProcedure(
				dataSource);

		preparePersonBiometics(10);
		prepareSegment(1, 10);

		// update an existing segment and create a new segment
		String deleteReferenceId = referenceId + String.format("%05d", 5);
		SegmentPosition segPos = biometricsDeletion.execute(deleteReferenceId);

		String sql_delete_biometrics = "select * FROM PERSON_BIOMETRICS WHERE REFERENCE_ID = '"
				+ deleteReferenceId + "'";
		String sql_person_biometrics = "select * FROM PERSON_BIOMETRICS";
		String sql_segment_version_detail = "select * FROM SEGMENT_VERSION_DETAIL ORDER BY SEGMENT_ID, VERSION";
		String sql_segments = "select * FROM SEGMENTS ORDER BY SEGMENT_ID";

		List<Map<String, Object>> list_person_biometrics = jdbcTemplate
				.queryForList(sql_person_biometrics);
		List<Map<String, Object>> list_delete_biometrics = jdbcTemplate
				.queryForList(sql_delete_biometrics);
		List<Map<String, Object>> list_segment_version_detail1 = jdbcTemplate
				.queryForList(sql_segment_version_detail);
		List<Map<String, Object>> list_segments1 = jdbcTemplate
				.queryForList(sql_segments);

		assertEquals(9, list_person_biometrics.size());
		assertEquals(0, list_delete_biometrics.size());

		assertEquals(2, list_segment_version_detail1.size());
		assertEquals("0", list_segment_version_detail1.get(0).get("VERSION")
				.toString());
		assertEquals("9", list_segment_version_detail1.get(0).get(
				"RECORD_COUNT").toString());
		assertEquals("0", list_segment_version_detail1.get(0)
				.get("CHANGE_TYPE").toString());
		assertEquals("1", list_segment_version_detail1.get(1).get("VERSION")
				.toString());
		assertEquals("0", list_segment_version_detail1.get(1).get(
				"RECORD_COUNT").toString());
		assertEquals("5", list_segment_version_detail1.get(1).get(
				"BIO_ID_START").toString());
		assertEquals("1", list_segment_version_detail1.get(1)
				.get("CHANGE_TYPE").toString());
		assertEquals(deleteReferenceId, list_segment_version_detail1.get(1)
				.get("REFERENCE_ID").toString());

		assertEquals(1, list_segments1.size());
		assertEquals("1", list_segments1.get(0).get("VERSION").toString());
		assertEquals("9", list_segments1.get(0).get("RECORD_COUNT").toString());
		assertEquals("1", list_segments1.get(0).get("GENERATION").toString());
		assertEquals(String.format("%d", 9 * Constants.PERSON_TEMPLATE_SIZE),
				list_segments1.get(0).get("BINARY_LENGTH_COMPACTED").toString());
		assertEquals(String.format("%d", 10 * Constants.PERSON_TEMPLATE_SIZE),
				list_segments1.get(0).get("BINARY_LENGTH_UNCOMPACTED")
						.toString());

		assertEquals(1, segPos.getSegmentId());
		assertEquals(1, segPos.getVersion());
		assertEquals(5, segPos.getIndexStart());
	}

	@Test
	public void testBiometricsDeletion_NoFind() {
		BiometricsDeletionProcedure biometricsDeletion = new BiometricsDeletionProcedure(
				dataSource);

		preparePersonBiometics(10);
		prepareSegment(1, 10);

		// update an existing segment and create a new segment
		String deleteReferenceId = referenceId + String.format("%05d", 15);
		SegmentPosition segPos = biometricsDeletion.execute(deleteReferenceId);

		String sql_delete_biometrics = "select * FROM PERSON_BIOMETRICS WHERE REFERENCE_ID = '"
				+ deleteReferenceId + "'";
		String sql_person_biometrics = "select * FROM PERSON_BIOMETRICS";
		String sql_segment_version_detail = "select * FROM SEGMENT_VERSION_DETAIL ORDER BY SEGMENT_ID, VERSION";
		String sql_segments = "select * FROM SEGMENTS ORDER BY SEGMENT_ID";

		List<Map<String, Object>> list_person_biometrics = jdbcTemplate
				.queryForList(sql_person_biometrics);
		List<Map<String, Object>> list_delete_biometrics = jdbcTemplate
				.queryForList(sql_delete_biometrics);
		List<Map<String, Object>> list_segment_version_detail1 = jdbcTemplate
				.queryForList(sql_segment_version_detail);
		List<Map<String, Object>> list_segments1 = jdbcTemplate
				.queryForList(sql_segments);

		assertEquals(10, list_person_biometrics.size());
		assertEquals(0, list_delete_biometrics.size());

		assertEquals(1, list_segment_version_detail1.size());
		assertEquals("0", list_segment_version_detail1.get(0).get("VERSION")
				.toString());
		assertEquals("10", list_segment_version_detail1.get(0).get(
				"RECORD_COUNT").toString());
		assertEquals("0", list_segment_version_detail1.get(0)
				.get("CHANGE_TYPE").toString());

		assertEquals(1, list_segments1.size());
		assertEquals("0", list_segments1.get(0).get("VERSION").toString());
		assertEquals("10", list_segments1.get(0).get("RECORD_COUNT").toString());
		assertEquals("0", list_segments1.get(0).get("GENERATION").toString());
		assertEquals(String.format("%d", 10 * Constants.PERSON_TEMPLATE_SIZE),
				list_segments1.get(0).get("BINARY_LENGTH_COMPACTED").toString());
		assertEquals(String.format("%d", 10 * Constants.PERSON_TEMPLATE_SIZE),
				list_segments1.get(0).get("BINARY_LENGTH_UNCOMPACTED")
						.toString());

		assertNull(segPos);
	}

	private void clearDatabase() {
		jdbcTemplate.execute("delete FROM PERSON_BIOMETRICS");
		jdbcTemplate.execute("delete FROM SEGMENT_VERSION_DETAIL");
		jdbcTemplate.execute("delete FROM SEGMENTS");
	}

	private void preparePersonBiometics(int count) {
		for (int i = 1; i <= count; i++) {
			String sql = "INSERT INTO person_biometrics( biometrics_id, reference_id,"
					+ " biometric_data, biometric_data_len, date_added ) VALUES("
					+ i
					+ ",'"
					+ (referenceId + String.format("%05d", i))
					+ "', '0', 13632, systimestamp)";
			jdbcTemplate.execute(sql);
		}
	}

	private void prepareSegment(int count, int lastRecordCount) {
		int startId = -1;
		int endId = -1;
		int segLength = -1;
		for (int i = 1; i <= count; i++) {
			startId = ((i - 1) * 15 + 1);
			if (i == count) {
				endId = startId + lastRecordCount - 1;
			} else {
				endId = (i * 15);
			}
			segLength = (endId - startId + 1) * Constants.PERSON_TEMPLATE_SIZE;
			String segSQL = "INSERT INTO SEGMENTS(SEGMENT_ID, BIO_ID_START, BIO_ID_END,"
					+ " BINARY_LENGTH_COMPACTED, RECORD_COUNT, VERSION, GENERATION,"
					+ " BINARY_LENGTH_UNCOMPACTED ) VALUES ( "
					+ i
					+ ", "
					+ startId
					+ ","
					+ endId
					+ ","
					+ segLength
					+ ","
					+ (endId - startId + 1) + ", 0,0," + segLength + ")";
			jdbcTemplate.execute(segSQL);

			String segDetailSQL = "INSERT INTO SEGMENT_VERSION_DETAIL(SEGMENT_ID,VERSION,"
					+ " BIO_ID_START, BIO_ID_END,UPDATE_TS,RECORD_COUNT, CHANGE_TYPE) VALUES ( "
					+ i
					+ ", 0,"
					+ startId
					+ ","
					+ endId
					+ ",systimestamp,"
					+ (endId - startId + 1) + ", 0)";
			jdbcTemplate.execute(segDetailSQL);
		}
	}
}
