package jp.co.nec.lsm.tme.db.entityhelpers;

import java.sql.Types;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.lsm.proto.common.CommonProto.ComponentType;
import jp.co.nec.lsm.tm.common.constants.MUState;
import jp.co.nec.lsm.tm.db.common.entities.MatchUnitEntity;
import jp.co.nec.lsm.tm.db.common.entities.MuSegmentEntity;
import jp.co.nec.lsm.tm.db.common.entities.MuSegmentPK;

import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

/**
 * Super Test class of LoadBalancerBean
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
/**
 * Test Class for AbstractHelperTest
 */
public abstract class AbstractHelperTest {
	@PersistenceContext(unitName = "tme-ngi")
	protected EntityManager entityManager;
	@Resource
	protected DataSource dataSource;
	@Resource
	protected JdbcTemplate jdbcTemplate;

	// @Resource
	// protected LobHandler lobHandler;

	public AbstractHelperTest() {
		super();
	}

	/**
	 * Start Specified Match Unit
	 * 
	 * @param muId
	 * @param binId
	 */
	public void startMu(int muId, int binId) {
		startTMEUnitEntity(ComponentType.USC.ordinal(), muId, binId);
	}

	/**
	 * Stop Specified Match Unit
	 * 
	 * @param muId
	 */
	public void stopMu(int muId) {
		String sql = "update match_units set state='"
				+ MUState.STOPPED.toString() + "' where mu_id=?";
		jdbcTemplate.update(sql, new Object[] { new Long(muId) },
				new int[] { Types.BIGINT });
	}

	/**
	 * Start Specified Data Manager
	 * 
	 * @param id
	 * @param binId
	 */
	public void startDM(int id, int binId) {
		startTMEUnitEntity(ComponentType.DM.ordinal(), id, binId);
	}

	/**
	 * Stop Specified Data Manager
	 * 
	 * @param id
	 */
	public void stopDM(int id) {
		stopMu(id);
	}

	/**
	 * Update match_units through specified arguments
	 * 
	 * @param type
	 * @param muId
	 * @param binId
	 */
	private void startTMEUnitEntity(int type, int muId, int binId) {
		MatchUnitEntity mu = entityManager.find(MatchUnitEntity.class,
				new Long(muId));
		if (mu == null) {
			{
				String sql = "insert into match_units (mu_id, unique_id, state, TYPE, "
						+ "revision, IP_ADDRESS, balanced_flag) values(?, ?, 'WORKING', ?, 0, '111', 0)";
				jdbcTemplate.update(sql, new Object[] { new Long(muId),
						new Long(muId), new Long(type) }, new int[] {
						Types.BIGINT, Types.BIGINT, Types.BIGINT });
			}
			// // set mus eligible for bin_id=3
			// {
			// String sql =
			// "insert into mu_eligible_bins (mu_id, bin_id) values(?, ?)";
			// jdbcTemplate.update(sql, new Object[] { new Long(muId), new
			// Long(binId) },
			// new int[] { Types.BIGINT, Types.BIGINT });
			// }
		} else {
			String sql = "update match_units set state='WORKING', balanced_flag=0 where mu_id=?";
			jdbcTemplate.update(sql, new Object[] { new Long(muId) });

		}
	}

	/**
	 * Set MuSegments by specified muId and segmentId
	 * 
	 * @param muId
	 * @param segmentId
	 */
	public void setMuSegments(long muId, long segmentId) {
		MuSegmentPK muSegReport = new MuSegmentPK();
		muSegReport.setMuId(muId);
		muSegReport.setSegmentId(segmentId);
		MuSegmentEntity muSegMap = entityManager.find(
				MuSegmentEntity.class, muSegReport);
		if (muSegMap == null) {
			String sql = "insert into mu_segments (mu_id, segment_id, rank) values(?, ?, 1)";
			int[] argTypes = new int[] { Types.BIGINT, Types.BIGINT };
			jdbcTemplate.update(sql, new Object[] { new Long(muId),
					new Long(segmentId) }, argTypes);
		}
	}

	/**
	 * update system_config table through some condition below
	 * 
	 * @param redundancy
	 */
	public void changeRedundancy(int redundancy) {
		String sql = "update system_config set property_value=? where property_name='LOAD_BALANCER.DEFAULT_MIN_REDUNDANCY'";
		jdbcTemplate.update(sql, new Object[] { new Long(redundancy) });
	}

	/**
	 * update system_config table through some condition below
	 * 
	 * @param redundancy
	 */
	public void changeDMRedundancy(int redundancy) {
		String sql = "update system_config set property_value=? where property_name='LOAD_BALANCER.DEFAULT_DM_MIN_REDUNDANCY'";
		jdbcTemplate.update(sql, new Object[] { new Long(redundancy) });
	}

	/**
	 * prepare data for Test
	 * 
	 * @param segs
	 * @param segmentSetId
	 */
	public void prepareSegments(int segs, int segmentSetId) {
		String sql = "insert into segments (SEGMENT_ID,BIO_ID_START,BIO_ID_END,"
				+ "BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,GENERATION,BINARY_LENGTH_UNCOMPACTED)"
				+ " values(?, 1, 10, 10, 10, 1, 1, 100)";
		long max = 0;
		for (long id = max + 1; id <= max + segs; id++) {
			jdbcTemplate.update(sql, new Object[] { new Long(id) },
					new int[] { Types.BIGINT });
		}
	}

	/**
	 * Insert segments item into DataBase
	 * 
	 * @param segs
	 *            number of Segments to add
	 */
	public void addSegments(int segs) {
		String sql = "insert into segments (SEGMENT_ID,BIO_ID_START,BIO_ID_END,"
				+ "BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,GENERATION,BINARY_LENGTH_UNCOMPACTED)"
				+ " values(?,  1, 10, 10, 10, 1, 1, 100)";
		long maxId = jdbcTemplate
				.queryForLong("select MAX(SEGMENT_ID) from segments");
		long startId = maxId + 1L;
		long endId = startId + segs - 1L;
		for (long id = startId; id <= endId; id++) {
			jdbcTemplate.update(sql, new Object[] { new Long(id) },
					new int[] { Types.BIGINT });
		}
	}

}