package jp.co.nec.lsm.tme.spring.jndi;

import java.util.Map;

import org.apache.xbean.spring.context.impl.XBeanXmlBeanFactory;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.core.io.Resource;

/**
 * TMESpringInitialContextFactory is the class to support JNDI with Spring. Default
 * TMESpringInitialContextFactory has bug, can't read property file. We need to
 * define subclass by ourselves.<br/>
 * For more Information, http://www.stbbs.net/blog/2008/06/springjndi_25.html
 * 
 */
public class TMESpringInitialContextFactory extends
		org.apache.xbean.spring.jndi.SpringInitialContextFactory {

	@Override
	protected BeanFactory createContext(Resource resource) {
		BeanFactory factory = super.createContext(resource);
		Map<String, BeanFactoryPostProcessor> postProcessors = ((XBeanXmlBeanFactory) factory)
				.getBeansOfType(BeanFactoryPostProcessor.class);
		for (Map.Entry<String, BeanFactoryPostProcessor> pp : postProcessors.entrySet()) {
			pp.getValue().postProcessBeanFactory((XBeanXmlBeanFactory) factory);
		}
		return factory;
	}
}
