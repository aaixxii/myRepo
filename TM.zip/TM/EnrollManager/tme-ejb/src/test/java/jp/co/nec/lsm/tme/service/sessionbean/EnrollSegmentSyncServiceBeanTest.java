package jp.co.nec.lsm.tme.service.sessionbean;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.annotation.Resource;
import javax.sql.DataSource;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.proto.segment.SegmentUpdateRequestProto.SegmentUpdateRequest;
import jp.co.nec.lsm.proto.segment.SegmentUpdateResponseProto.SegmentUpdateResponse;
import jp.co.nec.lsm.tm.common.communication.SegmentPosition;
import jp.co.nec.lsm.tm.common.constants.Constants;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tme.core.jobs.DeletionJobManager;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalDeletionJob;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobInfo;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobStatus;
import jp.co.nec.lsm.tme.util.TMETestUtil;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.protobuf.ByteString;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollSegmentSyncServiceBeanTest {
	@Resource
	private DataSource dataSource;
	@Resource
	private EnrollSegmentSyncServiceBean segmentSyncBean;
	JdbcTemplate jdbcTemplate;
	int port = 14287;


	private final String requestID = "request34_abcde1234_abcde1234_1234";
	private final String referenceID = "abcde1234_abcde1234_abcde1234_12";

	@Before
	public void setUp() {

		jdbcTemplate = new JdbcTemplate(dataSource);
		cleanMemory();

		cleanDB();
	}

	private void cleanMemory() {

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue = queueManage
				.getEnrollLinkQueue();

		for (LocalEnrollBatchJob enrollbatchJob : enrollLinkQueue) {
			enrollLinkQueue.remove(enrollbatchJob);
		}

		ConcurrentLinkedQueue<LocalDeletionJob> deletionJobQueue = DeletionJobManager
				.getInstance().getDeletionJobQueue();

		for (LocalDeletionJob deletionJob : deletionJobQueue) {
			deletionJobQueue.remove(deletionJob);
		}
	}

	@After
	public void tearDown() {
		cleanMemory();
		cleanDB();
	}

	private void cleanDB() {
		jdbcTemplate.execute("delete FROM MU_SEGMENTS");
		jdbcTemplate.execute("delete FROM SEGMENT_VERSION_DETAIL");
		jdbcTemplate.execute("delete FROM SEGMENTS");
		jdbcTemplate.execute("delete FROM SYSTEM_CONFIG");
		jdbcTemplate.execute("delete FROM MU_CONTACTS");
		jdbcTemplate.execute("delete FROM MATCH_UNITS");
	}

	/**
	 * setMockMethod
	 */
	private void setMockMethod() {
		TMETestUtil.setJMSMockMethod();
	}

	/**
	 * 
	 */
	@Test
	public void testSynchronizeSegment_OneEnrollNoSegPos() {

		long batchJobId = 1480;
		int segmentCount = 1;
		int jobCount = 18;
		int maxSegSize = 120454;
		cleanMemory();
		setMockMethod();

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();

		// 1 - prepare EnrollRequest For test
		LocalEnrollBatchJob enrollBatchJob = prepareDateforEnrollResultRequest(
				batchJobId, jobCount, false, segmentCount, 0);

		// 2 - call add BatchJob into database
		queueManage.addEnrollBatchJob(enrollBatchJob);

		cleanDB();
		prepareMu_Segment(segmentCount);
		prepareSystemConfig(maxSegSize);

		// 3 - assert concerning information
		segmentSyncBean.synchronizeSegment(batchJobId);

		LocalEnrollBatchJob enrollBatchJobSyc = queueManage
				.getEnrollBatchJobById(batchJobId);
		assertEquals(EnrollBatchJobStatus.SYNCHRONIZED, enrollBatchJobSyc
				.getBatchJobStatus());
	}

	/**
	 * 
	 *
	 */
	@Test
	public void testSynchronizeSegment_OneEnrollTowSegPos() {

		long batchJobId = 1482;
		int segmentCount = 2;
		int receiveTimes = 8;
		int jobCount = 2;
		int maxSegSize = 120454;
		int[][] checkArray = { { 1, 2 }, { 1, 2 }, { 2, 0 }, { 2, 0 },
				{ 1, 2 }, { 1, 2 }, { 2, 0 }, { 2, 0 } };

		new ReceiveResponse(receiveTimes, checkArray).start();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		cleanMemory();
		setMockMethod();

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();

		// 1 - prepare EnrollRequest For test
		LocalEnrollBatchJob enrollBatchJob = prepareDateforEnrollResultRequest(
				batchJobId, jobCount, true, segmentCount, 2);

		// 2 - call add BatchJob into database
		queueManage.addEnrollBatchJob(enrollBatchJob);

		cleanDB();

		prepareMu_Segment(segmentCount);
		prepareSystemConfig(maxSegSize);

		// 3 - assert concerning information
		segmentSyncBean.synchronizeSegment(batchJobId);

		LocalEnrollBatchJob enrollBatchJobSyc = queueManage
				.getEnrollBatchJobById(batchJobId);
		assertEquals(EnrollBatchJobStatus.SYNCHRONIZED, enrollBatchJobSyc
				.getBatchJobStatus());
	}

	/**
	 * 
	 *
	 */
	@Test
	public void testSynchronizeSegment_TwoDeletion() {

		long batchJobId = 1483;
		int segmentCount = 2;
		int receiveTimes = 8;
		int maxSegSize = 120454;
		int[][] checkArray = { { 1, 1 }, { 1, 1 }, { 1, 1 }, { 1, 1 },
				{ 2, 1 }, { 2, 1 }, { 2, 1 }, { 2, 1 } };
		cleanMemory();
		setMockMethod();

		new ReceiveResponse(receiveTimes, checkArray).start();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		DeletionJobManager queueManage = DeletionJobManager.getInstance();

		queueManage.enqueueDeletionJob(new LocalDeletionJob(segmentCount, 1,
				432, "testReferenceId_1"));
		queueManage.enqueueDeletionJob(new LocalDeletionJob(segmentCount - 1,
				1, 232, "testReferenceId_2"));

		cleanDB();

		prepareMu_Segment(segmentCount);
		prepareSystemConfig(maxSegSize);

		// 3 - assert concerning information
		segmentSyncBean.synchronizeSegment(batchJobId);

		ConcurrentLinkedQueue<LocalDeletionJob> deletionJobQueue = DeletionJobManager
				.getInstance().getDeletionJobQueue();
		assertEquals(0, deletionJobQueue.size());
	}

	/**
	 * 
	 *
	 */
	@Test
	public void testSynchronizeSegment_OneEnrollTwoDeletion() {

		long batchJobId = 1484;
		int segmentCount = 2;
		int receiveTimes = 16;
		int jobCount = 2;
		int maxSegSize = 120454;
		int[][] checkArray = { { 1, 0 }, { 1, 0 }, { 1, 0 }, { 1, 0 },
				{ 1, 1 }, { 1, 1 }, { 1, 1 }, { 1, 1 }, { 1, 2 }, { 1, 2 },
				{ 2, 0 }, { 2, 0 }, { 1, 2 }, { 1, 2 }, { 2, 0 }, { 2, 0 } };
		cleanMemory();
		setMockMethod();

		new ReceiveResponse(receiveTimes, checkArray).start();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		EnrollBatchJobManager enrollQueueManage = EnrollBatchJobManager
				.getInstance();

		// 1 - prepare EnrollRequest For test
		LocalEnrollBatchJob enrollBatchJob = prepareDateforEnrollResultRequest(
				batchJobId, jobCount, true, segmentCount, 2);

		// 2 - call add BatchJob into database
		enrollQueueManage.addEnrollBatchJob(enrollBatchJob);

		DeletionJobManager deleteQueueManage = DeletionJobManager.getInstance();

		deleteQueueManage.enqueueDeletionJob(new LocalDeletionJob(
				segmentCount - 1, 1, 232, "testReferenceId_2"));
		deleteQueueManage.enqueueDeletionJob(new LocalDeletionJob(
				segmentCount - 1, 0, 132, "testReferenceId_1"));

		cleanDB();

		prepareMu_Segment(segmentCount);
		prepareSystemConfig(maxSegSize);

		// 3 - assert concerning information
		segmentSyncBean.synchronizeSegment(batchJobId);

		ConcurrentLinkedQueue<LocalDeletionJob> deletionJobQueue = DeletionJobManager
				.getInstance().getDeletionJobQueue();
		assertEquals(0, deletionJobQueue.size());

		LocalEnrollBatchJob enrollBatchJobSyc = enrollQueueManage
				.getEnrollBatchJobById(batchJobId);
		assertEquals(EnrollBatchJobStatus.SYNCHRONIZED, enrollBatchJobSyc
				.getBatchJobStatus());
	}

	/**
	 * 
	 * @param segmentCount
	 */
	private void prepareMu_Segment(int segmentCount) {
		for (int i = 1; i <= 2; i++) {
			String sql = "INSERT INTO MATCH_UNITS(MU_ID, UNIQUE_ID, CONTACT_URL, "
					+ "STATE, TYPE, REVISION, IP_ADDRESS, BALANCED_FLAG) VALUES("
					+ (i * 100)
					+ ", "
					+ (i * 100)
					+ ", 'http://127.0.0.1:"
					+ port + "', 'WORKING', 0, 1, 'swefdsdgsdf', 1)";
			jdbcTemplate.execute(sql);
		}

		for (int i = 1; i <= 2; i++) {
			String sql = "INSERT INTO MATCH_UNITS(MU_ID, UNIQUE_ID, CONTACT_URL, "
					+ "STATE, TYPE, REVISION, IP_ADDRESS, BALANCED_FLAG) VALUES("
					+ i
					+ ", "
					+ i
					+ ", 'http://127.0.0.1:"
					+ port
					+ "', 'WORKING', 2, 1, 'swefdsdgsdf', 1)";
			jdbcTemplate.execute(sql);
		}

		for (int i = 1; i <= segmentCount; i++) {
			String segmentsSql = "insert into segments (SEGMENT_ID,BIO_ID_START,BIO_ID_END,"
					+ "BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,GENERATION,BINARY_LENGTH_UNCOMPACTED)"
					+ " values(" + i + ",  1,123,23123, 12, 1, 2, 12312)";
			jdbcTemplate.execute(segmentsSql);
		}

		for (int i = 1; i <= 2; i++) {
			for (int j = 1; j <= segmentCount; j++) {
				String dmSql = "insert into MU_SEGMENTS (MU_ID,SEGMENT_ID,RANK)"
						+ " values(" + (i * 100) + "," + j + ", 0)";
				jdbcTemplate.execute(dmSql);

				String uscSql = "insert into MU_SEGMENTS (MU_ID,SEGMENT_ID,RANK)"
						+ " values(" + i + "," + j + ", 0)";
				jdbcTemplate.execute(uscSql);
			}
		}
	}

	/**
	 * 
	 * @param maxSegSize
	 */
	private void prepareSystemConfig(int maxSegSize) {
		jdbcTemplate.execute("insert into SYSTEM_CONFIG ("
				+ "CONFIG_ID,PROPERTY_NAME,PROPERTY_VALUE)"
				+ " values (1,'BEHAVIOR.MAX_SEGMENT_SIZE','" + maxSegSize
				+ "')");
	}

	/**
	 * prepare Data For EnrollResponse
	 * 
	 * @return
	 */
	private LocalEnrollBatchJob prepareDateforEnrollResultRequest(
			long batchJobId, int count, boolean isAddedSegPos,
			int segmentCount, int segPosCont) {
		LocalEnrollBatchJob enrollBatchJob = new LocalEnrollBatchJob();
		enrollBatchJob.setBatchJobId(batchJobId);
		enrollBatchJob.setBatchJobStatus(EnrollBatchJobStatus.REGISTERED);
		enrollBatchJob.setBatchJobType(BatchType.ENROLL);
		enrollBatchJob.setEnqueueTS(DateUtil.getCurrentDate());
		enrollBatchJob.setExtractEndTS(DateUtil.getCurrentDate());
		enrollBatchJob.setExtractStartTS(DateUtil.getCurrentDate());
		enrollBatchJob.setInsertEndTS(DateUtil.getCurrentDate());
		enrollBatchJob.setInsertStartTS(DateUtil.getCurrentDate());
		enrollBatchJob.setSyncEndTS(DateUtil.getCurrentDate());
		enrollBatchJob.setSyncStartTS(DateUtil.getCurrentDate());
		enrollBatchJob.setBatchJob_start_TS(DateUtil.getCurrentDate());

		for (int i = 1; i <= count; i++) {
			LocalExtractJobInfo info = new LocalExtractJobInfo();
			info.setExtractEndTS(DateUtil.getCurrentDate());
			info.setExtractStartTS(DateUtil.getCurrentDate());
			info.setFailureCount(i);
			info.setJobId(i);
			info.setMUId(23);
			info.setReferenceId(referenceID
					+ String.format("%02d%02d", batchJobId, i));
			info.setRequestId(requestID + String.format("%02d", i));
			info.setReturnCode(ReturnCode.JobSuccess);
			info.setStatus(LocalExtractJobStatus.DONE);
			info.setTemplate(prepareTemplate(String.valueOf(i)).toByteArray());
			info.setBiometricId(i);

			enrollBatchJob.putExtractJobInfo(info);
		}

		if (isAddedSegPos) {
			List<SegmentPosition> segmentPositions = new ArrayList<SegmentPosition>();
			SegmentPosition segPosition = new SegmentPosition();
			segPosition.setSegmentId(segmentCount - 1);
			segPosition.setVersion(2);
			segPosition.setIndexStart(1);
			segPosition.setIndexEnd(new Long(count / 2));
			segmentPositions.add(segPosition);

			if (segPosCont > segmentPositions.size()) {
				SegmentPosition segPosition2 = new SegmentPosition();
				segPosition2.setSegmentId(segmentCount);
				segPosition2.setVersion(0);
				segPosition2.setIndexStart(count / 2 + 1);
				segPosition2.setIndexEnd(new Long(count));
				segmentPositions.add(segPosition2);
			}
			enrollBatchJob.setSegmentPosition(segmentPositions);
		}
		return enrollBatchJob;
	}

	/**
	 * prepare ByteString for LocalEnrollBatchJobInfo 1 - prepare Data For
	 * EnrollResponse
	 * 
	 * @param jobId
	 * @return
	 */
	private ByteString prepareTemplate(String jobId) {
		int len = Constants.PERSON_TEMPLATE_SIZE;
		byte[] bs = new byte[len];
		for (int j = 0; j < len; j++) {
			if (j < jobId.length()) {
				bs[j] = jobId.getBytes()[j];
			} else {
				bs[j] = (byte) 15;// (j % 100 + 10);
			}
		}
		return ByteString.copyFrom(bs);
	}

	// ************************************************************//
	// ************************************************************//
	// ************************************************************//
	class ReceiveResponse extends Thread {
		int receiveTimes;
		int[][] chechArray;

		public ReceiveResponse(int receiveTimes, int[][] chechArray) {
			this.receiveTimes = receiveTimes;
			this.chechArray = chechArray;
		}

		public void run() {
			for (int i = 0; i < receiveTimes; i++) {
				receiveMessage(i, chechArray);
			}

		}
	}

	/**
	 * wait for TM to Call back
	 * 
	 * @param port
	 *            - listening Port
	 * @return
	 */
	private String receiveMessage(int index, int[][] chechArray) {
		byte[] data = null;

		ServerSocket serverSocket = null;
		Socket socket = null;
		try {
			// Ready to Listening a Port
			serverSocket = new ServerSocket(port);
			socket = serverSocket.accept();

			try {
				Thread.sleep(4000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			InputStream in = socket.getInputStream();
			byte[] res = new byte[999999];
			in.read(res);

			data = getBodyByte(res);

			if (data == null) {
				return "failure";
			}

			SegmentUpdateRequest up = SegmentUpdateRequest.parseFrom(data);
			if (chechArray != null) {
				if (chechArray[index][0] == up.getSegmentId()
						&& chechArray[index][1] == up.getVersionFrom()
						&& chechArray[index][1] == up.getVersionTo()) {

				} else {
					return "";
				}
			}
			SegmentUpdateResponse.Builder sur = SegmentUpdateResponse
					.newBuilder();
			sur.setGmvId(120);
			sur.setRecordCount(up.getRecordCount());
			sur.setSegmentId(up.getSegmentId());
			sur.setVersion(up.getVersionTo());
			byte[] body = sur.build().toByteArray();

			String responseHead = "HTTP/1.1 200 OK\r\n\r\n";
			byte[] head = responseHead.getBytes();

			socket.getOutputStream().write(getResponse(head, body));
		} catch (IOException e) {
			e.printStackTrace();
			return "failure";
		} finally {
			try {
				// close serverSocket socket BufferedReader stream
				if (socket != null) {
					socket.close();
				}
				if (serverSocket != null) {
					serverSocket.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
				return "failure";
			}
		}

		return null;
	}

	/**
	 * 
	 * @param bytes
	 * @return
	 */
	public byte[] getBodyByte(byte[] bytes) {
		int index = -1;
		int d1 = 0;
		int d2 = 0;
		int d3 = 0;
		int d4 = 0;
		for (int i = 0; i < bytes.length; i++) {
			d1 = bytes[i];
			d2 = bytes[i + 1];
			d3 = bytes[i + 2];
			d4 = bytes[i + 3];
			if (d1 == 13 && d2 == 10 && d3 == 13 && d4 == 10) {
				index = i + 4;
				break;
			}
		}
		ArrayList<Integer> data = new ArrayList<Integer>();
		int delIndex = 0;
		for (int j = 0;; j++) {
			int res = bytes[j + index];
			if (res == 0) {
				if (delIndex == j + index - 1) {
					break;
				}
				delIndex = j + index;
			}
			data.add(res);
		}
		byte[] a = new byte[data.size() - 1];
		for (int i = 0; i < data.size() - 1; i++) {
			a[i] = data.get(i).byteValue();
		}
		return a;
	}

	/**
	 * 
	 * @param head
	 * @param body
	 * @return
	 */
	private byte[] getResponse(byte[] head, byte[] body) {
		byte[] response = new byte[head.length + body.length];
		for (int i = 0; i < head.length; i++) {
			response[i] = head[i];
		}
		for (int j = 0; j < body.length; j++) {
			response[head.length + j] = body[j];
		}
		return response;
	}

	// ************************************************************//
	// ************************************************************//
	// ************************************************************//
}
