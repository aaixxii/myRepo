package jp.co.nec.lsm.tme.db.procedure;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.sql.DataSource;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollJobQueueEntity;
import jp.co.nec.lsm.tm.db.enroll.procedure.ExctractJobInsertProcedure;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class ExctractJobInsertProcedureTest {

	@Resource
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;

	private String requestId = "RequestId901234567890123456789.+-*/=";
	private String referenceId = "ReferenceId1234567890123456789.+-*/=";

	@Before
	public void setUp() {
		jdbcTemplate = new JdbcTemplate(dataSource);
		// clean DB
		cleanEnrollJobQueue();
	}

	@After
	public void tearDown() {
		// clean DB
		cleanEnrollJobQueue();
	}

	/**
	 * clean DB
	 */
	private void cleanEnrollJobQueue() {
		jdbcTemplate.execute("delete from ENROLL_JOB_QUEUE");
		jdbcTemplate.execute("delete from ENROLL_BATCH_JOB_QUEUE");
	}

	/**
	 * 
	 * @param args
	 */
	@Test
	public void testExctractJobInsertProcedure() {
		long batchJobId = 510;
		int jobCount = 1000;

		ExctractJobInsertProcedure insertProcedure = new ExctractJobInsertProcedure(
				dataSource);

		// clean DB
		cleanEnrollJobQueue();
		// prepare test data
		List<EnrollJobQueueEntity> extractJobObjectList = prepareEnrollJobQueueEntityList(
				batchJobId, jobCount);
		jdbcTemplate.execute("insert into ENROLL_BATCH_JOB_QUEUE(BATCHJOB_ID, "
				+ "BATCHJOB_STATUS, ENQUEUE_TS) values(" + batchJobId + ", "
				+ EnrollBatchJobStatus.QUEUED.getIntValues()
				+ ", TO_DATE('29-02-2012 12:00:00', 'DD-MM-YYYY HH24.MI.SS'))");

		// call execute()
		Integer executeCount = insertProcedure.execute(extractJobObjectList);

		// assert result
		List<Map<String, Object>> recordList = jdbcTemplate
				.queryForList("select * from ENROLL_JOB_QUEUE order by JOB_INDEX");

		assertNotNull(executeCount);
		assertEquals(jobCount, (int) executeCount);

		assertEquals(jobCount, recordList.size());
		for (int i = 0; i < jobCount; i++) {
			Map<String, Object> record = recordList.get(i);
			assertEquals(batchJobId, Long.parseLong(record.get("BATCHJOB_ID")
					.toString()));
			assertEquals(i + 1, Integer.parseInt(record.get("JOB_INDEX")
					.toString()));
			assertEquals(requestId, record.get("REQUEST_ID").toString());
			assertEquals(referenceId, record.get("REFERENCE_ID").toString());
			assertEquals(ReturnCode.NotUsed.ordinal(), Integer.parseInt(record
					.get("RETURN_CODE").toString()));
			byte[] data = (byte[]) record.get("REQUEST");
			byte[] data2 = new byte[] { (byte) (i + 1), 1, 2, 3, 4, 5, 6, 7, 8,
					9 };
			for (int j = 0; j < data.length; j++) {
				assertEquals(data2[j], data[j]);
			}
		}

		// clean DB
		cleanEnrollJobQueue();

	}

	/**
	 * 
	 * @param batchJobId
	 * @param jobCount
	 * @return
	 */
	private List<EnrollJobQueueEntity> prepareEnrollJobQueueEntityList(
			long batchJobId, int jobCount) {
		List<EnrollJobQueueEntity> extractJobObjectList = new ArrayList<EnrollJobQueueEntity>();

		for (int i = 1; i <= jobCount; i++) {
			EnrollJobQueueEntity extractJobEntity = new EnrollJobQueueEntity();

			extractJobEntity.setBatchJobId(batchJobId);
			extractJobEntity.setJobIndex(i);
			extractJobEntity.setRequestId(requestId);
			extractJobEntity.setReferenceId(referenceId);
			extractJobEntity.setRequest(new byte[] { (byte) i, 1, 2, 3, 4, 5,
					6, 7, 8, 9 });
			extractJobEntity.setReturnCode(ReturnCode.NotUsed);

			extractJobObjectList.add(extractJobEntity);
		}

		return extractJobObjectList;
	}
}
