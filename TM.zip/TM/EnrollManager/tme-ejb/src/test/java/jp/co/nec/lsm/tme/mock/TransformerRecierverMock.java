package jp.co.nec.lsm.tme.mock;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;

import jp.co.nec.lsm.tm.protocolbuffer.enroll.EnrollResultRequestProto.EnrollResultRequest;

import com.acc.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;

public class TransformerRecierverMock {

	private final int recievetime = Constants.HTTP_SOCKET_RECIEVER_WAIT_TIME;
	private final int resPort = Constants.TRANSFORMER_RECEIVE_PORT;
	private final int reqPort = Constants.TRANSFORMER_REQUEST_PORT;

	private final int topLevelJobCount = Constants.EXTRACT_JOB_COUNT;
	private final int batchJobCount = Constants.BATCH_JOB_COUNT;

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		TransformerRecierverMock client = new TransformerRecierverMock();

		// client.new ReceiveRequest().start();

		client.new ReceiveResponse().start();

		return;
	}

	/**
	 * 
	 * 
	 *
	 */
	class ReceiveRequest extends Thread {

		public void run() {
			TransformerRecierverMock client = new TransformerRecierverMock();
			while (true) {
				client.receiveMessage(reqPort, topLevelJobCount);

				System.out.println("receive get batchJob request."
						+ new Date().toString());
			}
		}
	}

	/**
	 * 
	 * 
	 *
	 */
	class ReceiveResponse extends Thread {

		public void run() {
			TransformerRecierverMock client = new TransformerRecierverMock();
			for (int i = 0; i < batchJobCount;) {
				String result = client
						.receiveMessage(resPort, topLevelJobCount);

				if (result == "") {
					System.out.println("Enroll Batch Job is successful."
							+ new Date().toString());
				} else {
					System.out.println("Enroll Batch Job is failure."
							+ new Date().toString());
				}
			}
		}
	}

	/**
	 * wait for MM to Call back
	 * 
	 * @param port
	 *            - listening Port
	 * @return
	 */
	private String receiveMessage(int port, int jobCount) {
		byte[] data = null;

		ServerSocket serverSocket = null;
		Socket socket = null;
		try {
			// Ready to Listening a Port
			serverSocket = new ServerSocket(port);
			socket = serverSocket.accept();

			try {
				Thread.sleep(recievetime);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			PrintWriter writer = null;
			writer = new PrintWriter(socket.getOutputStream(), true);
			writer.println("HTTP/1.1 200 OK\r\n");

			if (jobCount < 0) {
				return "";
			}

			InputStream in = socket.getInputStream();
			byte[] res = new byte[999999];
			in.read(res);

			data = MockCommon.getBodyByte(res);

		} catch (IOException e) {
			e.printStackTrace();
			return "failure";
		} finally {
			try {
				// close serverSocket socket BufferedReader stream
				if (socket != null) {
					socket.close();
				}
				if (serverSocket != null) {
					serverSocket.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
				return "failure";
			}
		}

		if (data == null) {
			return "failure";
		}
		try {
			EnrollResultRequest enrollResponse = EnrollResultRequest
					.parseFrom(data);

			if (jobCount == enrollResponse.getBusinessMessageCount()) {
				for (ByteString bussinessMessage : enrollResponse
						.getBusinessMessageList()) {
					CPBBusinessMessage resultMessage = CPBBusinessMessage
							.parseFrom(bussinessMessage);
					if (resultMessage == null) {
						break;
					}
				}
				System.out.println("receive batchJob "
						+ enrollResponse.getBatchJobId()
						+ " response. **********");
				return "";
			} else {
				return "failure";
			}
		} catch (InvalidProtocolBufferException e) {
			return "";
		}
	}
}
