package jp.co.nec.lsm.tme.service.sessionbean;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.sql.DataSource;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.tm.common.constants.Constants;
import jp.co.nec.lsm.tm.common.constants.MUState;
import jp.co.nec.lsm.tm.common.constants.SystemConfigNamespace;
import jp.co.nec.lsm.tm.common.constants.TMType;
import jp.co.nec.lsm.tm.common.constants.TmState;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.common.entities.MatchUnitEntity;
import jp.co.nec.lsm.tm.db.common.entities.SystemConfigEntity;
import jp.co.nec.lsm.tm.db.common.entities.TransactionManagerEntity;
import jp.co.nec.lsm.tm.db.common.entityhelpers.MatchUnitHelper;
import jp.co.nec.lsm.tm.db.common.entityhelpers.SystemConfigHelper;
import jp.co.nec.lsm.tm.db.common.entityhelpers.TransactionManagerHelper;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobQueueEntity;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollJobQueueEntity;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobInfo;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobStatus;
import jp.co.nec.lsm.tme.db.dao.EnrollSystemConfigDao;
import jp.co.nec.lsm.tme.exception.EnrollRuntimeException;
import jp.co.nec.lsm.tme.util.TMETestUtil;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.protobuf.InvalidProtocolBufferException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollSystemInitializationBeanTest {
	@Resource(mappedName = "java:/OracleDS")
	private DataSource dataSource;
	private MatchUnitHelper muHelper;
	private SystemConfigHelper sysConfigHelper;
	private TransactionManagerHelper tmHelper;
	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager manager;
	protected JdbcTemplate jdbcTemplate;

	@Resource
	EnrollSystemInitializationBean sysInitBean;
	@Resource
	private EnrollSystemConfigDao systemConfigDao;

	/**
	 * initialize
	 */
	@Before
	public void setUp() {
		int i = 0;

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue = queueManage
				.getEnrollLinkQueue();

		if (!enrollLinkQueue.isEmpty()) {
			for (i = 1; i <= enrollLinkQueue.size(); i++) {
				enrollLinkQueue.poll();
			}
		}

		muHelper = new MatchUnitHelper(manager);
		tmHelper = new TransactionManagerHelper(manager, TMType.TME);
		sysConfigHelper = new SystemConfigHelper(manager);
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	/**
	 * 
	 * 
	 * Test Case<br/>
	 * Test [testInitializeTME]<br/>
	 * 1 - clear database to avoid disturbing<br/>
	 * 2 - prepare EnrollBatchJobQueueEntity/EnrollJobQueueEntity For test<br/>
	 * 3 - call initializeTME, to initialize system<br/>
	 * 
	 * @throws Exception
	 */
	@Test
	public void testInitializeTME() throws Exception {

		// 1 - clear database to avoid disturbing
		jdbcTemplate.execute("delete FROM TRANSACTION_MANAGERS");
		jdbcTemplate.execute("delete FROM SYSTEM_CONFIG");
		jdbcTemplate.execute("delete FROM ENROLL_JOB_QUEUE");
		jdbcTemplate.execute("delete FROM ENROLL_BATCH_JOB_QUEUE");

		// 2 - prepare EnrollBatchJobQueueEntity/EnrollJobQueueEntity For test
		for (int i = 101; i <= 103; i++) {
			EnrollBatchJobQueueEntity batchJob = new EnrollBatchJobQueueEntity();
			batchJob.setBatchjobId(i);
			if (i == 101) {
				batchJob.setBatchjobStatus(EnrollBatchJobStatus.QUEUED
						.getIntValues());
			} else if (i == 102) {
				batchJob.setBatchjobStatus(EnrollBatchJobStatus.REGISTERED
						.getIntValues());
			} else {
				batchJob.setBatchjobStatus(EnrollBatchJobStatus.RETURNED
						.getIntValues());
			}
			batchJob.setSegmentId1st(i);
			batchJob.setVersion1st(i);
			batchJob.setIndexStart1st(i);
			batchJob.setIndexEnd1st(i);

			batchJob.setSegmentId2nd(i + 1);
			batchJob.setVersion2nd(i + 1);
			batchJob.setIndexStart2nd(i + 1);
			batchJob.setIndexEnd2nd(i + 1);

			batchJob.setSegmentId3rd(i + 2);
			batchJob.setVersion3rd(i + 2);
			batchJob.setIndexStart3rd(i + 2);
			batchJob.setIndexEnd3rd(i + 2);

			batchJob.setEnqueueTs(DateUtil.getCurrentDate());

			manager.persist(batchJob);
		}

		for (int j = 101; j <= 103; j++) {
			for (int i = 1; i <= 10; i++) {

				EnrollJobQueueEntity job = new EnrollJobQueueEntity();
				job.setBatchJobId(j);
				job.setJobIndex(i);
				job.setReferenceId("" + (100000 + i));
				job.setRequestId(String.valueOf(i * i));
				if (j == 101) {
					job.setReturnCode(ReturnCode.NotUsed);
				} else {
					job.setReturnCode(ReturnCode.JobSuccess);
				}
				job.setErrorCode(String.format("%03d", j) + "_5_"
						+ String.format("%03d", i));
				job.setErrorMessage(String.format("%03d", j) + "_ErrorMessage_"
						+ String.format("%03d", i));
				job.setRequest(TMETestUtil.preperaResponse(j, i).toByteArray());
				job
						.setResponse(TMETestUtil.preperaResponse(j, i)
								.toByteArray());
				manager.persist(job);

			}
		}

		setMockMethod();

		// 3 - call initializeTME, to initialize system
		sysInitBean.initializeTME();

		testSetStartupTime();
		testWriteAllMissingProperties();
		testChangePidUnitState();
		testRecoverUnCompletedEnrollBatchJob();
	}

	/**
	 * setMockMethod
	 */
	private void setMockMethod() {
		TMETestUtil.setJMSMockMethod();
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testRecoverUnCompletedEnrollBatchJob]<br/>
	 * 1 - query database to get data<br/>
	 * 2 - assert concerning information<br/>
	 * 
	 * @param queueManage
	 * @throws InvalidProtocolBufferException
	 */
	@SuppressWarnings("unchecked")
	public void testRecoverUnCompletedEnrollBatchJob()
			throws InvalidProtocolBufferException {

		// 1 - query database to get data
		Query query = manager
				.createQuery("FROM EnrollBatchJobQueueEntity WHERE batchjobStatus != :batchjobStatus");
		query.setParameter("batchjobStatus", EnrollBatchJobStatus.RETURNED
				.getIntValues());
		List<EnrollBatchJobQueueEntity> dbEnrollBatchJobs = query
				.getResultList();

		// 2 - assert concerning information
		assertEquals(2, dbEnrollBatchJobs.size());

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		for (EnrollBatchJobQueueEntity dbBatchJob : dbEnrollBatchJobs) {

			long bid = dbBatchJob.getBatchjobId();
			LocalEnrollBatchJob batchJob = queueManage
					.getEnrollBatchJobById(bid);
			EnrollBatchJobStatus bs = batchJob.getBatchJobStatus();

			if (bid == 101) {
				assertEquals(bs, EnrollBatchJobStatus.QUEUED);
				assertNotNull(batchJob.getEnqueueTS());
			} else if (bid == 102) {
				assertEquals(bs, EnrollBatchJobStatus.SYNCHRONIZED);
				assertNotNull(batchJob.getSyncEndTS());
				assertEquals(10, batchJob.getCompletedExtractJobCount());

				assertEquals(batchJob.getSegmentPosition().get(0)
						.getSegmentId(), dbBatchJob.getSegmentId1st());
				assertEquals(batchJob.getSegmentPosition().get(0).getVersion(),
						dbBatchJob.getVersion1st());
				assertEquals(batchJob.getSegmentPosition().get(0)
						.getIndexStart(), dbBatchJob.getIndexStart1st());
				assertEquals(batchJob.getSegmentPosition().get(0).getIndexEnd()
						.longValue(), dbBatchJob.getIndexEnd1st());

				assertEquals(batchJob.getSegmentPosition().get(1)
						.getSegmentId(), dbBatchJob.getSegmentId2nd());
				assertEquals(batchJob.getSegmentPosition().get(1).getVersion(),
						dbBatchJob.getVersion2nd());
				assertEquals(batchJob.getSegmentPosition().get(1)
						.getIndexStart(), dbBatchJob.getIndexStart2nd());
				assertEquals(batchJob.getSegmentPosition().get(1).getIndexEnd()
						.longValue(), dbBatchJob.getIndexEnd2nd());

				assertEquals(batchJob.getSegmentPosition().get(2)
						.getSegmentId(), dbBatchJob.getSegmentId3rd());
				assertEquals(batchJob.getSegmentPosition().get(2).getVersion(),
						dbBatchJob.getVersion3rd());
				assertEquals(batchJob.getSegmentPosition().get(2)
						.getIndexStart(), dbBatchJob.getIndexStart3rd());
				assertEquals(batchJob.getSegmentPosition().get(2).getIndexEnd()
						.longValue(), dbBatchJob.getIndexEnd3rd());
			} else {
				assertEquals(1, 0);
			}

			Query queryjob = manager
					.createQuery("FROM EnrollJobQueueEntity WHERE batchJobId = :batchJobId");
			queryjob.setParameter("batchJobId", bid);
			List<EnrollJobQueueEntity> dbEnrollBatchJobInfos = queryjob
					.getResultList();

			assertEquals(batchJob.getExtractJobCount(), dbEnrollBatchJobInfos
					.size());

			int count = 0;
			for (int j = 1; j <= batchJob.getExtractJobCount(); j++) {
				LocalExtractJobInfo jobInfo = batchJob.getExtractJobInfo(j);
				for (EnrollJobQueueEntity dbJobInfo : dbEnrollBatchJobInfos) {
					if (jobInfo.getJobId() == dbJobInfo.getJobIndex()) {
						assertEquals(jobInfo.getRequestId(), dbJobInfo
								.getRequestId());
						assertEquals(jobInfo.getReturnCode(), dbJobInfo
								.getReturnCode());
						assertEquals(jobInfo.getReferenceId(), dbJobInfo
								.getReferenceId());
						assertEquals(jobInfo.getErrorCode(), dbJobInfo
								.getErrorCode());
						assertEquals(jobInfo.getErrorMessage(), dbJobInfo
								.getErrorMessage());
						if (bid == 101) {
							assertTrue(jobInfo
									.isStatus(LocalExtractJobStatus.READY));
						} else if (bid == 102) {
							assertTrue(jobInfo
									.isStatus(LocalExtractJobStatus.DONE));
						}
						assertEquals(jobInfo.getMUId(), 0);
						assertEquals(jobInfo.getFailureCount(), 0);
						assertEquals(jobInfo.getBiometricId(), -1);
						assertEquals(jobInfo.getTemplate(), null);

						byte[] dataReq = jobInfo.getRequest().toByteArray();
						assertTrue(dataReq.length > 0);
						for (int i = 0; i < dataReq.length; i++) {
							assertEquals(dataReq[i], dbJobInfo.getRequest()[i]);
						}

						if (bid == 102) {
							byte[] dataRes = jobInfo.getResponse()
									.toByteArray();
							assertTrue(dataRes.length > 0);
							for (int i = 0; i < dataRes.length; i++) {
								assertEquals(dataRes[i], dbJobInfo
										.getResponse()[i]);
							}
						}

						count++;
						break;
					}
				}
			}
			assertEquals(dbEnrollBatchJobInfos.size(), 10);
			assertEquals(dbEnrollBatchJobInfos.size(), count);
		}

	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testSetStartupTime]<br/>
	 * 1 - query database to get data<br/>
	 * 2 - assert concerning information<br/>
	 */
	public void testSetStartupTime() {

		// 1 - query database to get data
		TransactionManagerEntity tm = tmHelper.createOrLookup(DateUtil
				.getCurrentDate());

		// 2 - assert concerning information
		assertNotNull(tm);
		assertNotNull(tm.getLastHeartbeatTs());
		assertNotNull(tm.getLastPollTs());
		assertEquals(TmState.WORKING, tm.getState());
		assertEquals(getTMEUniqueId(), tm.getUniqueId());
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testWriteAllMissingProperties]<br/>
	 * 1 - assert concerning information<br/>
	 */
	public void testWriteAllMissingProperties() {
		for (SystemConfigNamespace namespace : SystemConfigNamespace.values()) {
			Properties defaultProperties = getDefaults(namespace);

			// 1 - assert concerning information
			Set<Entry<Object, Object>> entrySet = defaultProperties.entrySet();
			for (Entry<Object, Object> e : entrySet) {
				String key = (String) e.getKey();
				if (getPropEntity(manager, namespace.name(), key) == null) {
					String value = sysConfigHelper.getTMProperty(key);
					assertEquals(e.getValue(), value);
				}
			}
		}
	}

	/**
	 * /**
	 * 
	 * Test Case<br/>
	 * Test [testUpdateMuSegMap]<br/>
	 * 1 - query database to get data<br/>
	 * 2 - assert concerning information<br/>
	 */
	@SuppressWarnings("unchecked")
	public void testChangePidUnitState() {

		// 1 - query database to get data
		Query query = manager.createNamedQuery("NQ::listWorkingUnits");
		query.setParameter("workingState", MUState.TIMED_OUT.toString());
		List<MatchUnitEntity> list = query.getResultList();

		// 2 - assert concerning information
		for (MatchUnitEntity mu : list) {
			MatchUnitEntity mue = muHelper.search(mu.getUniqueId());
			assertEquals(MUState.TIMED_OUT, mue.getState());
		}
	}

	/**
	 * @param namespace
	 * @return
	 */
	private Properties getDefaults(SystemConfigNamespace namespace) {
		String propFile = namespace.getDefaultPropertiesFilename();
		Properties defaultProperties = new Properties();
		try {
			InputStream is = SystemConfigHelper.class.getClassLoader()
					.getResourceAsStream(propFile);
			if (is == null) {
				throw new EnrollRuntimeException(
						"Unable to find properties file " + propFile);
			}
			defaultProperties.load(is);
			is.close();
			return defaultProperties;
		} catch (IOException e) {
			throw new EnrollRuntimeException(
					"IOException while loading properties file " + propFile, e);
		}
	}

	/**
	 * @param manager
	 * @param namespace
	 * @param propName
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private SystemConfigEntity getPropEntity(EntityManager manager,
			String namespace, String propName) {
		Query q = manager.createNamedQuery("NQ::getConfigEntity");
		q.setParameter("propName", propName);
		List<SystemConfigEntity> results = q.getResultList();
		if (results.isEmpty())
			return null;
		assert (results.size() == 1) : "DUPLICATE property entries for property '"
				+ propName + "'";
		return results.get(0);
	}

	/**
	 * Get an ip-address of TME from pid.tm.properties.
	 * 
	 * If the ip-address is not gotten from properties, it must be missing the
	 * default setting. Therefore It is not necessary to send SM and get the
	 * real ip of NIC.
	 * 
	 * @return
	 */
	private String getTMEUniqueId() {
		String mmUniqueId = systemConfigDao.getTMEIpAddress();
		if (mmUniqueId == null) {
			mmUniqueId = Constants.DEFAULT_TME_UNIQUE_ID;
			// basically, we prefer to use numeric IP address but will use
			// hostname otherwise.
			// worst-case scenario we use the default above.
			try {
				mmUniqueId = InetAddress.getLocalHost().getHostName();

				Enumeration<NetworkInterface> interfaces = java.net.NetworkInterface
						.getNetworkInterfaces();
				while (interfaces.hasMoreElements()) {
					NetworkInterface ni = interfaces.nextElement();
					// log.debug("Interface: " + ni.getDisplayName());
					Enumeration<InetAddress> addrs = ni.getInetAddresses();
					while (addrs.hasMoreElements()) {
						InetAddress addr = addrs.nextElement();
						// log.debug("Address: " + addr.getHostAddress());
						if (!addr.isLoopbackAddress()) {
							mmUniqueId = addr.getHostAddress();
						}
					}
				}
			} catch (SocketException e) {
				throw new EnrollRuntimeException(e);
			} catch (UnknownHostException e) {
				throw new EnrollRuntimeException(e);
			}
		}
		return mmUniqueId + Constants.COLON + systemConfigDao.getTMEWebPort();
	}

}