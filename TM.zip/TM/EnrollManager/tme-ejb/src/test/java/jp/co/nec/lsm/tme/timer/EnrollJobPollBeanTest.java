package jp.co.nec.lsm.tme.timer;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.Date;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.lsm.tm.common.constants.ConfigProperty;
import jp.co.nec.lsm.tm.db.common.entityhelpers.SystemConfigHelper;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobInfo;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobStatus;
import jp.co.nec.lsm.tme.service.sessionbean.EnrollAcceptServiceBean;
import jp.co.nec.lsm.tme.util.TMETestUtil;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.acc.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.acc.proto.protobuf.BusinessMessage.CPBRequest;
import com.acc.proto.protobuf.BusinessMessage.E_REQUESET_TYPE;

/**
 * 
 * Test Class for EnrollPollBean Test Case Test [testEnrollPollBean] 1 - prepare
 * data for EnrollPollBean 2 - timeoutMuByHeartBeat 3 - poll
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollJobPollBeanTest {

	@Resource
	EnrollAcceptServiceBean enrollAcceptServiceBean;
	@Resource
	private DataSource dataSource;
	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager manager;
	private JdbcTemplate jdbcTemplate;
	@Resource
	private EnrollJobPollBean pollBean;
	private SystemConfigHelper sysConfigHelper;

	ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue;

	/**
	 * clear disturbing data for testing
	 */
	@Before
	public void setUp() {
		int i = 0;

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		enrollLinkQueue = queueManage.getEnrollLinkQueue();

		if (!enrollLinkQueue.isEmpty()) {
			for (i = 1; i <= enrollLinkQueue.size(); i++) {
				enrollLinkQueue.poll();
			}
		}
		jdbcTemplate = new JdbcTemplate(dataSource);
		sysConfigHelper = new SystemConfigHelper(manager);
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testpoll]<br/>
	 * 
	 * 1 - prepare MatchUnit/TransactionManager For test<br/>
	 * 2 - clear database to avoid disturbing<br/>
	 * 3 - call poll<br/>
	 * 4 - query database to get data<br/>
	 * 5 - assert concerning information<br/>
	 */
	@Test
	public void testpoll() {
		long batchJobId = 160;
		int jobCount = 16;

		// 1 - clear database to avoid disturbing
		jdbcTemplate.execute("delete FROM ENROLL_BATCH_JOB_QUEUE");
		jdbcTemplate.execute("delete FROM ENROLL_JOB_QUEUE");
		jdbcTemplate.execute("delete FROM SYSTEM_CONFIG");
		jdbcTemplate.execute("insert into SYSTEM_CONFIG (CONFIG_ID,"
				+ "PROPERTY_NAME,PROPERTY_VALUE)"
				+ " values (1,'BEHAVIOR.MAX_EXTRACT_JOB_FAILURES','3')");

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();

		// 2 - prepare LocalEnrollBatchJob/LocalEnrollBatchJobInfo For test
		for (int i = 0; i < 2; i++) {
			LocalEnrollBatchJob enrollBatchJob = new LocalEnrollBatchJob();
			enrollBatchJob.setBatchJobType(BatchType.ENROLL);
			enrollBatchJob.setBatchJobId(batchJobId + i);
			enrollBatchJob.setBatchJobStatus(EnrollBatchJobStatus.EXTRACTING);
			for (int j = 1; j <= jobCount; j++) {
				LocalExtractJobInfo batchJob = new LocalExtractJobInfo();
				batchJob.setJobId(j);
				batchJob.setStatus(LocalExtractJobStatus.EXTRACTING);
				batchJob.setMUId(5);
				batchJob.setExtractStartTS(new Date(10000));
				if (j <= jobCount / 2 && i == 0) {
					batchJob.setFailureCount(1);
				} else {
					batchJob.setFailureCount(2);
				}

				// CPBRequest
				CPBRequest.Builder request = CPBRequest.newBuilder();
				request.setRequestId(String.format("%018d", batchJobId)
						+ String.format("%018d", j));
				request.setEnrollmentId("QueueManager_"
						+ String.format("%023d", j));
				request.setRequestType(E_REQUESET_TYPE.INSERT);
				CPBBusinessMessage.Builder businessMessage = CPBBusinessMessage
						.newBuilder();
				businessMessage.setRequest(request);
				batchJob.setRequest(businessMessage.build());

				// 3 - call addOneEnrollBatchJobInfo, to insert one
				// EnrollBatchJobInfo into database
				enrollBatchJob.putExtractJobInfo(batchJob);
			}
			queueManage.addEnrollBatchJob(enrollBatchJob);
		}
		setMockMethod();

		// 5 - call timeoutMuProccess
		pollBean.poll();

		// 6 - query database to get data
		Integer maxExtractFailure = sysConfigHelper
				.getTMPropertyInt(ConfigProperty.MAX_EXTRACT_JOB_FAILURES);
		EnrollBatchJobManager queueManage2 = EnrollBatchJobManager
				.getInstance();

		// 7 - assert concerning information
		for (int i = 0; i < 2; i++) {
			LocalEnrollBatchJob enrollBatchJob = queueManage2
					.getEnrollBatchJobById(batchJobId + i);
			for (int j = 1; j <= enrollBatchJob.getExtractJobCount(); j++) {
				LocalExtractJobInfo batchJob = enrollBatchJob
						.getExtractJobInfo(j);
				if (batchJob.getFailureCount() < maxExtractFailure) {
					assertEquals(2, batchJob.getFailureCount());
					assertTrue(batchJob.isStatus(LocalExtractJobStatus.READY));
					assertNull(batchJob.getExtractStartTS());
				} else {

					assertTrue(batchJob.isStatus(LocalExtractJobStatus.DONE));
					assertNotNull(batchJob.getExtractEndTS());

				}
			}
			if (i == 0) {
				assertEquals(EnrollBatchJobStatus.EXTRACTING, enrollBatchJob
						.getBatchJobStatus());
				assertEquals(jobCount / 2, enrollBatchJob
						.getCompletedExtractJobCount());
			} else {
				assertEquals(EnrollBatchJobStatus.EXTRACTED, enrollBatchJob
						.getBatchJobStatus());
				assertEquals(jobCount, enrollBatchJob
						.getCompletedExtractJobCount());
			}
		}

	}

	/**
	 * setMockMethod
	 */
	private void setMockMethod() {
		TMETestUtil.setJMSMockMethod();
	}
}
