package jp.co.nec.lsm.tme.core.clientapi.response;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.tm.common.httpsender.HttpResponse;
import jp.co.nec.lsm.tm.protocolbuffer.enroll.EnrollResultRequestProto.EnrollResultRequest;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobInfo;
import jp.co.nec.lsm.tme.util.TMETestUtil;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.protobuf.InvalidProtocolBufferException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollResultRequestSenderTest {
	int port = 13345;

	@Before
	public void setUp() {

	}

	@After
	public void tearDown() {

	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testprepareEnrollResultRequest]<br/>
	 * 1 - prepare DateforEnrollResultRequest/EnrollResultRequest For test<br/>
	 * 2 - assert concerning information<br/>
	 */
	@Test
	public void testSendEnrollResponse() {
		long batchJobId = 1023;
		int jobCount = 20;

		// 1 - prepare LocalEnrollBatchJob For test
		LocalEnrollBatchJob batchJob = TMETestUtil
				.prepareDateforEnrollResultRequest(batchJobId, jobCount);

		for (int i = 1; i <= jobCount; i++) {
			LocalExtractJobInfo extractJobInfo = batchJob.getExtractJobInfo(i);
			extractJobInfo.setReturnCode(ReturnCode.JobSuccess);
		}

		// call EnrollResponse.prepareEnrollResultRequest
		EnrollResultRequest enrollResultRequest = EnrollResultRequestBuilder
				.createEnrollResultRequest(batchJob);
		class ReceiveResponse extends Thread {
			int jobCount;

			public ReceiveResponse(int jobCount) {
				this.jobCount = jobCount;
			}

			public void run() {
				receiveMessage(jobCount);
			}
		}

		new ReceiveResponse(jobCount).start();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		// 2 - call sendEnrollResponse
		try {
			String url = "http://127.0.0.1:" + port;
			ResultRequestSender sender = new ResultRequestSender();
			HttpResponse returnedByte = sender.sendResponse(enrollResultRequest
					.toByteArray(), batchJobId, url, 5);

			assertNotNull(returnedByte);
			assertEquals(0, returnedByte.getHttpResponseBody().length);
		} catch (Exception e) {
			fail();
		}
	}

	/**
	 * wait for MM to Call back
	 * 
	 * @param port
	 *            - listening Port
	 * @return
	 */
	private String receiveMessage(int jobCount) {
		byte[] data = null;

		ServerSocket serverSocket = null;
		Socket socket = null;
		try {
			// Ready to Listening a Port
			serverSocket = new ServerSocket(port);
			socket = serverSocket.accept();

			try {
				Thread.sleep(4000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			InputStream in = socket.getInputStream();
			byte[] res = new byte[999999];
			in.read(res);

			data = getBodyByte(res);
			if (data == null) {
				return "failure";
			}
			try {
				EnrollResultRequest enrollResponse = EnrollResultRequest
						.parseFrom(data);

				if (jobCount == enrollResponse.getBusinessMessageCount()) {

				} else {
					return "failure";
				}
			} catch (InvalidProtocolBufferException e) {
				e.printStackTrace();
				return "failure";
			}
			PrintWriter writer = null;
			writer = new PrintWriter(socket.getOutputStream(), true);
			writer.println("HTTP/1.1 200 OK\r\n");

		} catch (IOException e) {
			e.printStackTrace();
			return "failure";
		} finally {
			try {
				// close serverSocket socket BufferedReader stream
				if (socket != null) {
					socket.close();
				}
				if (serverSocket != null) {
					serverSocket.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
				return "failure";
			}
		}
		return null;
	}

	/**
	 * 
	 * @param bytes
	 * @return
	 */
	public byte[] getBodyByte(byte[] bytes) {
		int index = -1;
		int d1 = 0;
		int d2 = 0;
		int d3 = 0;
		int d4 = 0;
		for (int i = 0; i < bytes.length; i++) {
			d1 = bytes[i];
			d2 = bytes[i + 1];
			d3 = bytes[i + 2];
			d4 = bytes[i + 3];
			if (d1 == 13 && d2 == 10 && d3 == 13 && d4 == 10) {
				index = i + 4;
				break;
			}
		}
		ArrayList<Integer> data = new ArrayList<Integer>();
		int delIndex = 0;
		for (int j = 0;; j++) {
			int res = bytes[j + index];
			if (res == 0) {
				if (delIndex == j + index - 1) {
					break;
				}
				delIndex = j + index;
			}
			data.add(res);
		}
		byte[] a = new byte[data.size() - 1];
		for (int i = 0; i < data.size() - 1; i++) {
			a[i] = data.get(i).byteValue();
		}
		return a;
	}

}
