package jp.co.nec.lsm.tme.mock;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

import jp.co.nec.lsm.proto.common.CommonProto.ComponentType;
import jp.co.nec.lsm.proto.control.EnterRequestProto.EnterRequest;
import jp.co.nec.lsm.proto.control.EnterResponseProto.EnterResponse;
import jp.co.nec.lsm.proto.control.ExitRequestProto.ExitRequest;
import jp.co.nec.lsm.proto.segment.ReportStateRequestProto.ReportStateRequest;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.ByteArrayRequestEntity;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.params.HttpClientParams;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.InvalidProtocolBufferException;

public class MockCommon {
	private static Logger log = LoggerFactory.getLogger(MockCommon.class);

	private static boolean isStrop = false;

	public static boolean isTestStoped() {
		return isStrop;
	}

	public static void setTestStoped() {
		isStrop = true;
	}

	/**
	 * 
	 * @param uniqueId
	 * @param contactURL
	 * @param type
	 * @param timeOut
	 * @return
	 */
	public static int enter(String uniqueId, String contactURL,
			ComponentType type, int timeOut) {
		EnterRequest.Builder enterRequest = EnterRequest.newBuilder();
		enterRequest.setUniqueId(uniqueId);
		enterRequest.setContactURL(contactURL);
		enterRequest.setType(type);
		enterRequest.setVersion("1.1.0");
		enterRequest.setNumberOfCpus(2);
		enterRequest.setPrimarySize(134123);
		enterRequest.setSecondarySize(124315412);
		enterRequest.setBalancedFlag(1);
		enterRequest.setPerformanceFactor(3.0f);
		enterRequest.setRevision(2);

		byte[] stream = sendRequest(
				Constants.POST_URL + Constants.ENTER_SEVLET, enterRequest
						.build().toByteArray(), timeOut);

		try {
			EnterResponse enterResponse = EnterResponse.parseFrom(stream);
			return enterResponse.getGmvId();
		} catch (InvalidProtocolBufferException e) {
			e.printStackTrace();
			return -1;
		}
	}

	/**
	 * 
	 * @param gmvId
	 * @param timeOut
	 */
	public static void exit(int gmvId, int timeOut) {

		ExitRequest.Builder exitResponse = ExitRequest.newBuilder();
		exitResponse.setGmvId(gmvId);

		sendRequest(Constants.POST_URL + Constants.EXIT_SEVLET, exitResponse
				.build().toByteArray(), timeOut);
	}

	/**
	 * 
	 * @param gmvId
	 * @param timeOut
	 */
	public static byte[] reportState(int gmvId, int timeOut) {

		ReportStateRequest.Builder reportStateRequest = ReportStateRequest
				.newBuilder();
		reportStateRequest.setGmvId(gmvId);

		return sendRequest(Constants.POST_URL + Constants.REPORT_STATESEVLET,
				reportStateRequest.build().toByteArray(), timeOut);
	}

	/**
	 * 
	 * @param constent
	 * @param body
	 * @param timeOut
	 * @return
	 */
	public static byte[] sendRequest(String constentURL, byte[] body,
			int timeOut) {
		HttpClientParams hcp = new HttpClientParams();
		hcp.setSoTimeout(timeOut);
		HttpClient client = new HttpClient(hcp);
		PostMethod post = new PostMethod(constentURL);

		int result = 0;
		byte[] stream = null;
		try {
			if (body != null) {
				ByteArrayRequestEntity e = new ByteArrayRequestEntity(body);
				post.setRequestEntity(e);
				result = client.executeMethod(post);

				if (result == 200) {
					stream = post.getResponseBody().clone();
				}
				System.out.println(result);
			}
		} catch (Exception e) {
			log.debug(e.getMessage());
		} finally {
			if (post != null) {
				post.releaseConnection();
			}
		}
		return stream;
	}

	/**
	 * wait for MM to Call back
	 * 
	 * @param port
	 *            - listening Port
	 * @return
	 */
	public static byte[] receiveMessage(int port, byte[] body) {

		ServerSocket serverSocket = null;
		Socket socket = null;
		try {
			// Ready to Listening a Port
			serverSocket = new ServerSocket(port);
			socket = serverSocket.accept();

			try {
				Thread.sleep(4000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			PrintWriter writer = null;
			writer = new PrintWriter(socket.getOutputStream(), true);
			writer.println("HTTP/1.1 200 OK\r\n");

			InputStream in = socket.getInputStream();
			byte[] res = new byte[999999];
			in.read(res);

			return getBodyByte(res);

		} catch (IOException e) {
			throw new RuntimeException(e);
		} finally {
			try {
				// close serverSocket socket BufferedReader stream
				if (socket != null) {
					socket.close();
				}
				if (serverSocket != null) {
					serverSocket.close();
				}
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
	}

	/**
	 * 
	 * @param bytes
	 * @return
	 */
	public static byte[] getBodyByte(byte[] bytes) {
		int index = -1;
		int d1 = 0;
		int d2 = 0;
		int d3 = 0;
		int d4 = 0;
		for (int i = 0; i < bytes.length; i++) {
			d1 = bytes[i];
			d2 = bytes[i + 1];
			d3 = bytes[i + 2];
			d4 = bytes[i + 3];
			if (d1 == 13 && d2 == 10 && d3 == 13 && d4 == 10) {
				index = i + 4;
				break;
			}
		}
		ArrayList<Integer> data = new ArrayList<Integer>();
		int delIndex = 0;
		for (int j = 0;; j++) {
			int res = bytes[j + index];
			if (res == 0) {
				if (delIndex == j + index - 1) {
					break;
				}
				delIndex = j + index;
			}
			data.add(res);
		}
		byte[] a = new byte[data.size() - 1];
		for (int i = 0; i < data.size() - 1; i++) {
			a[i] = data.get(i).byteValue();
		}
		return a;
	}

}
