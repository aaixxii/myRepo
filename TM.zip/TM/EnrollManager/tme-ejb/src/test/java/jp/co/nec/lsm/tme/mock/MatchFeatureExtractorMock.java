package jp.co.nec.lsm.tme.mock;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.xml.ws.http.HTTPException;

import jp.co.nec.lsm.proto.common.CommonProto.ComponentType;
import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.proto.extract.ExtractJobRequestProto.ExtractJobRequest;
import jp.co.nec.lsm.proto.extract.ExtractJobResponseProto.ExtractJobResponse;
import jp.co.nec.lsm.proto.extract.ExtractJobResultRequestProto.ExtractJobResult;
import jp.co.nec.lsm.proto.extract.ExtractJobResultRequestProto.ExtractJobResultRequest;
import jp.co.nec.lsm.tme.util.TMETestUtil;

import com.google.protobuf.ByteString;

public class MatchFeatureExtractorMock {

	private final String post_requst = Constants.POST_URL
			+ Constants.EXTRACTJOB_ASSIGN_SEVLET;
	private final String post_result = Constants.POST_URL
			+ Constants.ENROLL_REPORT_SEVLET;
	private final int timeOut = Constants.HTTP_SOCKET_SEND_TIMEOUT;
	private final int requestJobNumber = Constants.MFE_REQUEST_JOB_NUMBER;
	private final long sleepTime = Constants.EXTRACT_JOB_RESULT_SEND_INTERVAL;
	private final long waitTime = Constants.MFE_REQUST_WAIT_TIME;
	private final String uniqueId = Constants.MFE_UNIQUE_ID;
	private final String contactURL = Constants.MFE_CONTACT_URL;
	private final ComponentType type = ComponentType.MFE;
	private final int loopCount = (Constants.EXTRACT_JOB_COUNT
			/ Constants.MFE_REQUEST_JOB_NUMBER + 1)
			* Constants.BATCH_JOB_COUNT / Constants.THREAD_POOL_NUM;
	private final double failedRate = Constants.FAILED_EXTRACT_JOB_RATE;

	private static final int thread_pool_num = Constants.THREAD_POOL_NUM;
	private static final int template_size = Constants.TEMPLATE_SIZE;

	/**
	 * @param args
	 * @throws IOException
	 * @throws HTTPException
	 * @throws InterruptedException
	 */
	public static void main(String[] args) throws HTTPException, IOException,
			InterruptedException {

		List<MFETask> postArray = new ArrayList<MFETask>();
		for (int i = 0; i < thread_pool_num; i++) {
			postArray.add(new MFETask(String.format("%03d", i)));
		}

		ExecutorService service = null;
		try {
			service = Executors.newFixedThreadPool(thread_pool_num);
			service.invokeAll(postArray);
		} finally {
			if (service != null) {
				service.shutdown();
			}
		}
	}

	public static class MFETask implements Callable<String> {

		String uniqueIndex = "";

		public MFETask(String uniqueIndex) {
			this.uniqueIndex = uniqueIndex;
		}

		public MFETask() {
		}

		public String call() throws Exception {

			int muId = 1;
			byte[] stream = null;

			MatchFeatureExtractorMock client = new MatchFeatureExtractorMock();
			int successCount = (int) (client.requestJobNumber * (1 - client.failedRate));

			muId = MockCommon.enter(client.uniqueId + uniqueIndex,
					client.contactURL, client.type, client.timeOut);

			int i = 0;
			while (i < client.loopCount) {

				i++;
				if (MockCommon.reportState(muId, client.timeOut) == null) {
					muId = MockCommon.enter(client.uniqueId + uniqueIndex,
							client.contactURL, client.type, client.timeOut);
				}

				Thread.sleep(client.waitTime);

				ExtractJobRequest jobRequestFirst = client
						.prepareExtractJobRequest(muId);

				stream = MockCommon.sendRequest(client.post_requst,
						jobRequestFirst.toByteArray(), client.timeOut);

				Thread.sleep(client.sleepTime);

				if (stream == null) {
					continue;
				}

				ExtractJobResponse extractJob = null;
				try {
					extractJob = ExtractJobResponse.parseFrom(stream);
				} catch (Exception e) {
					continue;
				}

				ExtractJobResultRequest extractResult = client
						.prepareExtractResult(extractJob, successCount,
								client.requestJobNumber - successCount);

				stream = MockCommon.sendRequest(client.post_result,
						extractResult.toByteArray(), client.timeOut);
				if (stream == null) {
				}
			}

			MockCommon.exit(muId, client.timeOut);
			return null;
		}

	}

	private ExtractJobRequest prepareExtractJobRequest(int muId) {
		ExtractJobRequest.Builder jobRequest = ExtractJobRequest.newBuilder();
		jobRequest.setGmvId(muId);
		jobRequest.setMaxExtractJob(requestJobNumber);
		return jobRequest.build();
	}

	/**
	 * 
	 * @return
	 */
	private ByteString prepareTemplate(String jobId) {
		int len = template_size;
		byte[] bs = new byte[len];
		for (int j = 0; j < len; j++) {
			if (j < jobId.length()) {
				bs[j] = jobId.getBytes()[j];
			} else {
				bs[j] = (byte) 15;// (j % 100 + 10);
			}
		}
		return ByteString.copyFrom(bs);
	}

	/**
	 * 
	 * @param extractJob
	 * @return
	 */
	private ExtractJobResultRequest prepareExtractResult(
			ExtractJobResponse extractJob, int successCount, int failureCount) {
		ExtractJobResultRequest.Builder extractResult = ExtractJobResultRequest
				.newBuilder();
		extractResult.setBatchJobId(extractJob.getBatchJobId());
		List<ExtractJobResult> extractJobResult = new ArrayList<ExtractJobResult>();

		for (int i = 1; i <= extractJob.getExtractJobCount(); i++) {
			ExtractJobResult.Builder jobResult = ExtractJobResult.newBuilder();
			jobResult.setJobIndex(extractJob.getExtractJobList().get(i - 1)
					.getJobIndex());
			if (i <= successCount) {
				jobResult.setReturnCode(ReturnCode.JobSuccess);
				jobResult.setErrorCode(0);
				jobResult.setErrorMessage("Success!");
				// jobResult.setTemplate(ByteString.EMPTY);
				jobResult.setTemplate(prepareTemplate(String.valueOf(jobResult
						.getJobIndex())));
			} else {
				jobResult.setReturnCode(ReturnCode.JobFailed);
				jobResult.setErrorCode(801548795);
				jobResult.setErrorMessage("JobFailed!");
				jobResult.setTemplate(ByteString.EMPTY);
			}
			jobResult.setResponse(TMETestUtil.preperaResponse(
					extractJob.getBatchJobId(), i).toByteString());
			extractJobResult.add(jobResult.build());
		}
		extractResult.addAllExtractJobResult(extractJobResult);

		return extractResult.build();
	}

}
