package jp.co.nec.lsm.tme.timer;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.lsm.proto.common.CommonProto.ComponentType;
import jp.co.nec.lsm.tm.common.constants.ConfigProperty;
import jp.co.nec.lsm.tm.common.constants.MUState;
import jp.co.nec.lsm.tm.common.exception.TMRuntimeException;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.common.entities.MatchUnitEntity;
import jp.co.nec.lsm.tm.db.common.entities.MuContactEntity;
import jp.co.nec.lsm.tm.db.common.entityhelpers.SystemConfigHelper;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.EnrollExtractJobFailManager;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobInfo;
import jp.co.nec.lsm.tme.core.jobs.LocalExtractJobStatus;
import jp.co.nec.lsm.tme.exception.EnrollRuntimeException;
import jp.co.nec.lsm.tme.service.sessionbean.EnrollAcceptServiceBean;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import com.acc.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.acc.proto.protobuf.BusinessMessage.CPBRequest;
import com.acc.proto.protobuf.BusinessMessage.E_REQUESET_TYPE;

/**
 * 
 * Test Class for EnrollPollBean Test Case Test [testEnrollPollBean] 1 - prepare
 * data for EnrollPollBean 2 - timeoutMuByHeartBeat 3 - poll
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollMFETimeoutPollBeanTest {

	@Resource
	EnrollAcceptServiceBean enrollAcceptServiceBean;
	@Resource
	private DataSource dataSource;
	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager manager;
	private JdbcTemplate jdbcTemplate;

	@Resource
	private EnrollMFETimeoutPollBean mfePollBean;
	private SystemConfigHelper sysConfigHelper;

	ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue;

	/**
	 * clear disturbing data for testing
	 */
	@Before
	public void setUp() {
		int i = 0;

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		enrollLinkQueue = queueManage.getEnrollLinkQueue();

		if (!enrollLinkQueue.isEmpty()) {
			for (i = 1; i <= enrollLinkQueue.size(); i++) {
				enrollLinkQueue.poll();
			}
		}
		jdbcTemplate = new JdbcTemplate(dataSource);
		sysConfigHelper = new SystemConfigHelper(manager);
	}

	/**
	 * prepare data for TMEUnitEntity 1 - prepare data for EnrollPollBean
	 * 
	 * @return
	 */
	private MatchUnitEntity prepareTMEUnitEntity() {
		MatchUnitEntity mu = new MatchUnitEntity();
		MuContactEntity muContactEntity = new MuContactEntity();
		{
			muContactEntity.setIdle(true);
			muContactEntity.setLastContactTime(DateUtil.getCurrentDate());
			muContactEntity.setLastReportTime(DateUtil.getCurrentDate());
			muContactEntity.setMuId(2L);
		}
		mu.setBalanced(true);
		mu.setId(5L);
		mu.setNumCPUs((short) 2);
		mu.setRevision(4);
		mu.setURL("http://1234567");
		mu.setUniqueId("unique");
		mu.setType(ComponentType.MFE);
		mu.setState(MUState.WORKING);
		mu.setPerformanceFactor(1.1f);
		mu.setPrimarySize(4L);
		mu.setSecondarySize(20L);
		mu.setVersion("version");
		mu.setTimes(muContactEntity);
		return mu;

	}

	/**
	 * 
	 * prepare data for MatchUnit
	 * 
	 */
	private void prepareInsertMatchUnit() {
		jdbcTemplate.execute("delete FROM match_units");
		jdbcTemplate.execute("delete FROM MU_CONTACTS");
		jdbcTemplate
				.execute("insert into match_units "
						+ "(mu_id, unique_id, state, TYPE, revision, IP_ADDRESS, balanced_flag) values"
						+ "(1, 1, 'WORKING', 1, 1, 1, 1)");
		jdbcTemplate
				.execute("insert into match_units "
						+ "(mu_id, unique_id, state, TYPE, revision, IP_ADDRESS, balanced_flag) values"
						+ "(2, 2, 'WORKING', 1, 1, 2, 1)");

		jdbcTemplate
				.execute("insert into match_units "
						+ "(mu_id, unique_id, state, TYPE, revision, IP_ADDRESS, balanced_flag) values"
						+ "(3, 3, 'WORKING', 1, 1, 3, 1)");
		jdbcTemplate
				.execute("insert into match_units "
						+ "(mu_id, unique_id, state, TYPE, revision, IP_ADDRESS, balanced_flag) values"
						+ "(4, 4, 'WORKING', 1, 1, 4, 1)");

		jdbcTemplate
				.execute("insert into match_units "
						+ "(mu_id, unique_id, state, TYPE, revision, IP_ADDRESS, balanced_flag) values"
						+ "(5, 5, 'WORKING', 1, 1, 5, 1)");
		// insert MU_CONTACTS
		jdbcTemplate
				.execute("insert into MU_CONTACTS "
						+ "(MU_ID, LAST_CONTACT_TS, LAST_REPORT_TS, IDLE_FLAG) values"
						+ "(1, to_date( '1999-10-20   12:00:00 ', 'yyyy-mm-dd   hh24:mi:ss '),to_date( '1999-10-20   12:00:00 ', 'yyyy-mm-dd   hh24:mi:ss '), 0)");
		jdbcTemplate
				.execute("insert into MU_CONTACTS "
						+ "(MU_ID, LAST_CONTACT_TS, LAST_REPORT_TS, IDLE_FLAG) values"
						+ "(2,to_date( '1999-10-20   12:00:00 ', 'yyyy-mm-dd   hh24:mi:ss '),to_date( '1999-10-20   12:00:00 ', 'yyyy-mm-dd   hh24:mi:ss ') , 0)");

		jdbcTemplate
				.execute("insert into MU_CONTACTS "
						+ "(MU_ID, LAST_CONTACT_TS, LAST_REPORT_TS, IDLE_FLAG) values"
						+ "(3, to_date( '1999-10-20   12:00:00 ', 'yyyy-mm-dd   hh24:mi:ss '),to_date( '1999-10-20   12:00:00 ', 'yyyy-mm-dd   hh24:mi:ss '), 2)");
		jdbcTemplate
				.execute("insert into MU_CONTACTS "
						+ "(MU_ID, LAST_CONTACT_TS, LAST_REPORT_TS, IDLE_FLAG) values"
						+ "(4, to_date( '1999-10-20   12:00:00 ', 'yyyy-mm-dd   hh24:mi:ss '),to_date( '1999-10-20   12:00:00 ', 'yyyy-mm-dd   hh24:mi:ss '), 2)");

		jdbcTemplate
				.execute("insert into MU_CONTACTS "
						+ "(MU_ID, LAST_CONTACT_TS, LAST_REPORT_TS, IDLE_FLAG) values"
						+ "(5, to_date( '1999-10-20   12:00:00 ', 'yyyy-mm-dd   hh24:mi:ss '),to_date( '1999-10-20   12:00:00 ', 'yyyy-mm-dd   hh24:mi:ss '), 0)");
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testtimeoutMuByHeartBeat]<br/>
	 * 1 - clear database to avoid disturbing<br/>
	 * 2 - prepare EnterRequest For test<br/>
	 * 3 - call addOneEnrollBatchJobInfo, to insert one EnrollBatchJobInfo into
	 * database<br/>
	 * 4 - prepare TMEUnitEntity For test<br/>
	 * 5 - call timeoutMuProccess<br/>
	 * 6 - query database to get data<br/>
	 * 7 - assert concerning information<br/>
	 */
	@Test
	public void testtimeoutMuByHeartBeat() {
		long batchJobId = 16;
		int jobCount = 16;

		// 1 - clear database to avoid disturbing
		jdbcTemplate.execute("delete FROM ENROLL_BATCH_JOB_QUEUE");
		jdbcTemplate.execute("delete FROM ENROLL_JOB_QUEUE");
		jdbcTemplate.execute("delete FROM SYSTEM_CONFIG");
		jdbcTemplate.execute("insert into SYSTEM_CONFIG (CONFIG_ID,"
				+ "PROPERTY_NAME,PROPERTY_VALUE)"
				+ " values (1,'BEHAVIOR.MAX_EXTRACT_JOB_FAILURES','3')");

		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();

		// 2 - prepare LocalEnrollBatchJob/LocalEnrollBatchJobInfo For test
		for (int i = 0; i < 2; i++) {
			LocalEnrollBatchJob enrollBatchJob = new LocalEnrollBatchJob();
			enrollBatchJob.setBatchJobId(batchJobId + i);
			enrollBatchJob.setBatchJobStatus(EnrollBatchJobStatus.EXTRACTING);
			for (int j = 1; j <= jobCount; j++) {
				LocalExtractJobInfo batchJob = new LocalExtractJobInfo();
				batchJob.setJobId(j);
				batchJob.setStatus(LocalExtractJobStatus.EXTRACTING);
				batchJob.setMUId(5);
				batchJob.setExtractStartTS(new Date(10000));
				if (j <= jobCount / 2 && i == 0) {
					batchJob.setFailureCount(1);
				} else {
					batchJob.setFailureCount(2);
				}
				// CPBRequest
				CPBRequest.Builder request = CPBRequest.newBuilder();
				request.setRequestId(String.format("%018d", batchJobId)
						+ String.format("%018d", j));
				request.setEnrollmentId("QueueManager_"
						+ String.format("%023d", j));
				request.setRequestType(E_REQUESET_TYPE.INSERT);
				CPBBusinessMessage.Builder businessMessage = CPBBusinessMessage
						.newBuilder();
				businessMessage.setRequest(request);
				batchJob.setRequest(businessMessage.build());
				// 3 - call addOneEnrollBatchJobInfo, to insert one
				// EnrollBatchJobInfo into database
				enrollBatchJob.putExtractJobInfo(batchJob);
			}
			queueManage.addEnrollBatchJob(enrollBatchJob);
		}

		// 4 - prepare TMEUnitEntity For test
		MatchUnitEntity mu = prepareTMEUnitEntity();

		// 5 - call timeoutMuProccess
		try {
			EnrollExtractJobFailManager failManager = new EnrollExtractJobFailManager();
			mfePollBean.timeoutMuProccess(mu.getId(), failManager);
		} catch (Exception ex) {
			if (ex instanceof TMRuntimeException) {
			} else {
				throw new EnrollRuntimeException(ex);
			}
		}

		// 6 - query database to get data
		Integer maxExtractFailure = sysConfigHelper
				.getTMPropertyInt(ConfigProperty.MAX_EXTRACT_JOB_FAILURES);
		EnrollBatchJobManager queueManage2 = EnrollBatchJobManager
				.getInstance();

		// 7 - assert concerning information
		for (int i = 0; i < 2; i++) {
			LocalEnrollBatchJob enrollBatchJob = queueManage2
					.getEnrollBatchJobById(batchJobId + i);
			for (int j = 1; j <= enrollBatchJob.getExtractJobCount(); j++) {
				LocalExtractJobInfo batchJob = enrollBatchJob
						.getExtractJobInfo(j);
				if (batchJob.getFailureCount() < maxExtractFailure) {
					assertEquals(2, batchJob.getFailureCount());
					assertTrue(batchJob.isStatus(LocalExtractJobStatus.READY));
					assertNull(batchJob.getExtractStartTS());
				} else {

					assertTrue(batchJob.isStatus(LocalExtractJobStatus.DONE));
					assertNotNull(batchJob.getExtractEndTS());

				}
			}
			if (i == 0) {
				assertEquals(EnrollBatchJobStatus.EXTRACTING, enrollBatchJob
						.getBatchJobStatus());
				assertEquals(jobCount / 2, enrollBatchJob
						.getCompletedExtractJobCount());
			} else {
				assertEquals(EnrollBatchJobStatus.EXTRACTING, enrollBatchJob
						.getBatchJobStatus());
				assertEquals(jobCount, enrollBatchJob
						.getCompletedExtractJobCount());
			}
		}

	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testpoll]<br/>
	 * 
	 * 1 - prepare MatchUnit/TransactionManager For test<br/>
	 * 2 - clear database to avoid disturbing<br/>
	 * 3 - call poll<br/>
	 * 4 - query database to get data<br/>
	 * 5 - assert concerning information<br/>
	 */
	@Test
	public void testpoll() {

		jdbcTemplate.execute("delete FROM ENROLL_BATCH_JOB_QUEUE");
		jdbcTemplate.execute("delete FROM ENROLL_JOB_QUEUE");
		jdbcTemplate.execute("delete FROM SYSTEM_CONFIG");
		jdbcTemplate.execute("insert into SYSTEM_CONFIG (CONFIG_ID,"
				+ "PROPERTY_NAME,PROPERTY_VALUE)"
				+ " values (1,'BEHAVIOR.MAX_EXTRACT_JOB_FAILURES','3')");
		// 1 - prepare MatchUnit/TransactionManager For test
		// prepareInsertTransactionManager();
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		enrollLinkQueue = queueManage.getEnrollLinkQueue();

		for (LocalEnrollBatchJob batchJob : enrollLinkQueue) {
			enrollLinkQueue.remove(batchJob);
		}
		prepareInsertMatchUnit();

		// 2 - clear database to avoid disturbing
		String sql1 = "SELECT mu.* FROM MATCH_UNITS mu INNER JOIN MU_CONTACTS "
				+ "muc ON muc.MU_ID = mu.MU_ID WHERE mu.STATE = 'TIMED_OUT' AND "
				+ "muc.LAST_REPORT_TS  is not null";

		// 3 - call poll
		mfePollBean.poll();
		manager.flush();

		// 4 - query database to get data
		List<Map<String, Object>> deadMUs = jdbcTemplate.queryForList(sql1);

		// 5 - assert concerning information
		assertEquals(5, deadMUs.size());
		for (Map<String, Object> deadMU : deadMUs) {
			Object db = deadMU.get("state");// Integer.valueOf(db).intValue();
			assertEquals(MUState.TIMED_OUT.toString(), db);
		}
	}
}
