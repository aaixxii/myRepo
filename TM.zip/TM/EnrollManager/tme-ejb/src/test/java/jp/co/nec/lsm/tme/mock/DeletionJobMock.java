package jp.co.nec.lsm.tme.mock;

import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tm.protocolbuffer.deletion.DeleteRequestProto.DeleteRequest;
import jp.co.nec.lsm.tm.protocolbuffer.deletion.DeleteResultRequestProto.DeleteResultRequest;

import com.acc.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.acc.proto.protobuf.BusinessMessage.CPBRequest;
import com.acc.proto.protobuf.BusinessMessage.E_REQUESET_TYPE;
import com.google.protobuf.InvalidProtocolBufferException;

public class DeletionJobMock {

	private static final String post_url = Constants.POST_URL;
	private static final int timeout = Constants.HTTP_SOCKET_SEND_TIMEOUT;

	private static final long batchJobStartId = Constants.BATCH_JOB_START_ID;
	private static final String referentID = Constants.REFERENCE_ID;

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		for (int index = 1; index <= Constants.EXTRACT_JOB_COUNT; index++) {
			DeleteRequest.Builder deleteRequest = DeleteRequest.newBuilder();
			deleteRequest.setBatchJobId(index + batchJobStartId * 10000);
			deleteRequest.setType(BatchType.DELETE);

			CPBBusinessMessage.Builder businessMessage = CPBBusinessMessage
					.newBuilder();
			CPBRequest.Builder request = CPBRequest.newBuilder();
			request.setRequestId(String.format("%09d", batchJobStartId)
					+ referentID + String.format("%09d", index));
			request.setEnrollmentId(String.format("%09d", batchJobStartId)
					+ referentID + String.format("%09d", index));
			request.setRequestType(E_REQUESET_TYPE.DELETE);
			businessMessage.setRequest(request.build());

			deleteRequest.addBusinessMessage(businessMessage.build()
					.toByteString());

			byte[] result = MockCommon.sendRequest(post_url
					+ Constants.DELETE_SEVLET, deleteRequest.build()
					.toByteArray(), timeout);

			try {
				DeleteResultRequest deleteResult = DeleteResultRequest
						.parseFrom(result);

				System.out.println(deleteResult.toString());
			} catch (InvalidProtocolBufferException e) {
				e.printStackTrace();
			}
		}

	}

}
