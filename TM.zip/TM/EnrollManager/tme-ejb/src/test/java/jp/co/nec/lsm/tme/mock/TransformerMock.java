package jp.co.nec.lsm.tme.mock;

import java.util.ArrayList;
import java.util.List;

import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tm.protocolbuffer.enroll.EnrollRequestProto.EnrollRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acc.proto.protobuf.BusinessMessage.CPBBiometricElement;
import com.acc.proto.protobuf.BusinessMessage.CPBBiometricsData;
import com.acc.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.acc.proto.protobuf.BusinessMessage.CPBRequest;
import com.acc.proto.protobuf.BusinessMessage.E_BIOMETRIC_DATA_FORMAT;
import com.acc.proto.protobuf.BusinessMessage.E_REQUESET_TYPE;
import com.google.protobuf.ByteString;

public class TransformerMock {

	private static Logger log = LoggerFactory.getLogger(TransformerMock.class);

	private final String post_url = Constants.POST_URL;
	private final int timeout = Constants.HTTP_SOCKET_SEND_TIMEOUT;

	private final int batchJobSendInterval = Constants.BATCH_JOB_SEND_INTERVAL;

	private final int topLevelJobCount = Constants.EXTRACT_JOB_COUNT;
	private final int batchJobCount = Constants.BATCH_JOB_COUNT;
	private final long batchJobStartId = Constants.BATCH_JOB_START_ID;
	private final BatchType batchJobType = Constants.BATCH_JOB_TYPE;
	private final String referentID = Constants.REFERENCE_ID;
	// private final String referentURL = Constants.REFERENCE_URL;
	private final String referentURL = "http://192.168.1.31/tools/Sdata/";
	private final String[] image = new String[] { "7411/resident.7411",
			"7411/resident.74110", "7411/resident.74111",
			"7411/resident.74112", "7411/resident.74113",
			"7411/resident.74114", "7411/resident.74115",
			"7411/resident.74116", "7411/resident.74117",
			"7411/resident.74118", "7411/resident.74119", "7412/resident.7412",
			"7412/resident.74120", "7412/resident.74121",
			"7412/resident.74122", "7412/resident.74123",
			"7412/resident.74124", "7412/resident.74125",
			"7412/resident.74126", "7412/resident.74127",
			"7412/resident.74128", "7412/resident.74129" };

	private final String[] md5CheckSum = new String[] {
			"483d9d14b8973370bc7bb45420c78b69",
			"d7198c4dee3f3d68205db5026e173814",
			"dfcc678230418a060b492290c5bcc832",
			"e1482ecce68dcf278223e2965e88d81d",
			"154b5f0ed0f4e3fe08603f777e126ae0",
			"29729c53e8e04d99660a11cddc2b2386",
			"bee7369f1ea19b77464e5818013b75ba",
			"1a1ac4014df00af3d460ac09d00fbd47",
			"de50c205f9b6850df3972218d1f31fb2",
			"ef7ff0be70dc5cb9280ab275a969b415",
			"f57bd96bb4dde8e611418ce608583cbd",

			"23bf9968f57fd8e8ee43cd77d2e9dd4e",
			"034a82b0171e86a8fbef732d407c24a1",
			"ee945248f857f2d1500c061f3a267e1d",
			"f40e935d102bd7a1be23f8bf3781237e",//
			"14b92aafdd80e4b87ad9ea4e2680002f",
			"7509b4a04c13f86bae0b83d8b3af0ccb",
			"e3851763bd5bc5150113dbabc3b26507",
			"64c6a4f277fb82b81fe4bf85cc09041e",
			"5b3a6409d087e59cc78605197ec9f1b3",
			"4ba5e124c7e69442aa868998e12f0fb1",
			"91309017f54e4bc4a4aae588a9f2694b" };

	// private boolean isReceiveRequest = false;

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		TransformerMock client = new TransformerMock();

		for (int i = 0; i < client.batchJobCount; i++) {
			EnrollRequest request = client.prepareEnrollRequest(
					client.batchJobStartId + i, client.topLevelJobCount,
					client.batchJobType);

			byte[] body = MockCommon.sendRequest(client.post_url
					+ Constants.ENROLL_ACCEPT_SEVLET, request.toByteArray(),
					client.timeout);
			if (body == null) {
				log.debug("TransformerMock:  EnrollAccept request error");
			}

			try {
				Thread.sleep(client.batchJobSendInterval / 50);
			} catch (InterruptedException e) {

			}
		}

		return;
	}

	/**
	 * 
	 * @param batchJobId
	 * @param extractJobCount
	 * @return
	 */
	private EnrollRequest prepareEnrollRequest(long batchJobId,
			int extractJobCount, BatchType type) {

		EnrollRequest.Builder enrollrequest = EnrollRequest.newBuilder();
		enrollrequest.setBatchJobId(batchJobId);
		enrollrequest.setType(type);

		List<ByteString> businessMessageList = new ArrayList<ByteString>();

		for (int i = 1; i <= extractJobCount; i++) {

			// CPBBiometricElement
			CPBBiometricElement.Builder biometricElement = CPBBiometricElement
					.newBuilder();
			biometricElement.setFilePath(referentURL
					+ image[(i - 1) % image.length]);
			biometricElement.setChecksum(md5CheckSum[(i - 1) % image.length]);

			// CPBBiometricsData
			CPBBiometricsData.Builder biometricsData = CPBBiometricsData
					.newBuilder();
			biometricsData
					.setDataFormat(E_BIOMETRIC_DATA_FORMAT.BIOMETRIC_INLINE_FMR);
			biometricsData.setBiometricElement(biometricElement);

			// // CPBRequestParameter
			// CPBRequestParameter.Builder requestParameter =
			// CPBRequestParameter
			// .newBuilder();
			// requestParameter.setParameterName("fingerImageSelectionMode");
			// requestParameter.setParameterValue("ParameterValue");

			// CPBRequest
			CPBRequest.Builder request = CPBRequest.newBuilder();
			request.setRequestId(String.format("%036d", 15 + i));
			request.setEnrollmentId(String.format("%09d", batchJobId)
					+ referentID + String.format("%09d", i));
			request.setCaptureYear(2010);
			request.setBirthYear(1968);
			request.setSex("M");
			request.setRegionCode("15");
			request.setRequestType(E_REQUESET_TYPE.INSERT);
			request.setBiometricsData(biometricsData);

			// CPBBusinessMessage
			CPBBusinessMessage.Builder businessMessage = CPBBusinessMessage
					.newBuilder();
			businessMessage.setRequest(request.build());

			businessMessageList.add(businessMessage.build().toByteString());
		}

		enrollrequest.addAllBusinessMessage(businessMessageList);
		return enrollrequest.build();
	}

}
