package jp.co.nec.lsm.tme.sessionbeans.api;

import java.util.List;

import javax.ejb.Local;

import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tm.protocolbuffer.enroll.EnrollRequestProto.EnrollRequest;

import com.acc.proto.protobuf.BusinessMessage.CPBBusinessMessage;

/**
 * @author mozj <br>
 * 
 */
@Local
public interface EnrollAcceptServiceLocal {
	public void doAccept(Long batchJobId, BatchType batchType,
			List<CPBBusinessMessage> businessMessageList);

	/**
	 * validate all data in enroll request whether there are correct.
	 * 
	 * @param request
	 *            enroll request from Transformer
	 * @return false: there are incorrect data in enroll request. true: all data
	 *         in enroll request are correct.
	 */
	public void validateRequest(EnrollRequest enrollRequest,
			List<CPBBusinessMessage> businessMessageList);
}
