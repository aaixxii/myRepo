package jp.co.nec.lsm.tme.sessionbeans.api;

import javax.ejb.Local;

/**
 * @author mozj <br>
 * 
 */
@Local
public interface EnrollDeadLevelQueueServiceLocal {
	public void deleteEnrollJobFromMemory(long batchJobId);

	public void deleteDeleteJobFromMemory(long batchJobId);

	public void makeBatchJobJobSynced(long batchJobId, boolean isEnrollJob);

	public void makeEnrollJobComplated(long batchJobId);
}
