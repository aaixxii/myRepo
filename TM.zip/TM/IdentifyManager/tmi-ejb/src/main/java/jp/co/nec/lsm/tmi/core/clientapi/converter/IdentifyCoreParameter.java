package jp.co.nec.lsm.tmi.core.clientapi.converter;

import jp.co.nec.lsm.tmi.core.jobs.TopLevelJobType;

import com.google.protobuf.ByteString;

public class IdentifyCoreParameter {
	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

	public String getReferenceUrl() {
		return referenceUrl;
	}

	public void setReferenceUrl(String referenceUrl) {
		this.referenceUrl = referenceUrl;
	}

	public String getCheckSum() {
		return checkSum;
	}

	public void setCheckSum(String checkSum) {
		this.checkSum = checkSum;
	}

	public int getMaxCandidate() {
		return maxCandidate;
	}

	public void setMaxCandidate(int maxCandidate) {
		this.maxCandidate = maxCandidate;
	}

	public int getTargetFPIR() {
		return targetFPIR;
	}

	public void setTargetFPIR(int targetFPIR) {
		this.targetFPIR = targetFPIR;
	}

	public TopLevelJobType getTopLevelJobType() {
		return topLevelJobType;
	}

	public void setTopLevelJobType(TopLevelJobType topLevelJobType) {
		this.topLevelJobType = topLevelJobType;
	}

	public ByteString getBusinessMessage() {
		return businessMessage;
	}

	public void setBusinessMessage(ByteString businessMessage) {
		this.businessMessage = businessMessage;
	}

	private String requestId;
	private String referenceId;
	private String referenceUrl;
	private String checkSum;
	private int maxCandidate;
	private int targetFPIR;
	private ByteString businessMessage;
	private TopLevelJobType topLevelJobType;
}
