package jp.co.nec.lsm.tmi.core.gmvapi.request.sender;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import jp.co.nec.lsm.tm.common.httpsender.HttpRequestSender;
import jp.co.nec.lsm.tm.common.httpsender.HttpResponse;
import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tmi.common.constants.IdentifyConstants;
import jp.co.nec.lsm.tmi.core.jobs.RapidEncoderRequestInfo;

import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.HttpMethodRetryHandler;
import org.apache.commons.httpclient.params.HttpClientParams;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExtractRequestSender {

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(ExtractRequestSender.class);

	/**
	 * sendExtractRequest
	 * 
	 * @param url
	 * @param rederenceUrl
	 * @param retryMaxCount
	 * @return BatchJobTemplateInfos instance
	 */
	public static HttpResponse sendExtractRequest(String url,
			final Long batchJobId, RapidEncoderRequestInfo referenceURLs,
			final int retryMaxCount) {
		// sendExtractRequest
		try {
			Map<String, Object> httpClientParameters = new HashMap<String, Object>();
			httpClientParameters.put(IdentifyConstants.HTTP_SOCKET_SENDBUFFER,
					IdentifyConstants.SEGMENT_UPDATE_SENDBUFFER_VALUE);
			final int topLevelJobId = referenceURLs.getJobIndex();
			httpClientParameters.put(HttpClientParams.RETRY_HANDLER,
					new HttpMethodRetryHandler() {
						public boolean retryMethod(HttpMethod httpMethod,
								IOException ioe, int executionCount) {
							if (executionCount > retryMaxCount) {
								log
										.warn(
												"TopLeveljob id : {} of BatchJob id : {} Send extract request,"
														+ " Retried connection {}  times,"
														+ " which exceeds the maximum"
														+ " retry count of {}",
												new Object[] { topLevelJobId,
														batchJobId,
														executionCount,
														retryMaxCount });
								return false;
							}
							log.warn(
									"TopLeveljob id : {} of BatchJob id : {} Send extract request, "
											+ "Retrying request - attempt {}"
											+ " of {}", new Object[] {
											topLevelJobId, batchJobId,
											executionCount, retryMaxCount });
							return true;
						}
					});

			HttpRequestSender httpRequestSender = new HttpRequestSender(
					httpClientParameters);
			Map<String, String> extractRequestHeader = buildExtractRequestHeader(
					batchJobId, referenceURLs);
			if (log.isInfoEnabled()) {
				log.info(InfoLogger.httpURLInfoOutput(batchJobId, url));
			}
			HttpResponse httpResponse = httpRequestSender.sendPostRequest(url,
					batchJobId, null, extractRequestHeader);

			if (log.isInfoEnabled()) {
				log.info("Finished post to {}  status: {} for batchJob {}.",
						new Object[] { url, httpResponse.getHttpResponseCode(),
								batchJobId });
			}
			return httpResponse;
		} catch (Exception ex) {
			String message = "Identify Job ( Exception occurred when send extract request to"
					+ " rapid encoder, url:" + url + " ) ";
			log.error(message, ex);
			// if has error return directly
			HttpResponse error = new HttpResponse();
			error.setHttpResponseCode(IdentifyConstants.BAD_REQUEST_CODE);
			error.setReponseMessage(message);
			return error;
		}
	}

	/**
	 * buildExtractRequest
	 * 
	 * @return RequestToMFE
	 */
	private static Map<String, String> buildExtractRequestHeader(
			Long batchJobId, RapidEncoderRequestInfo requestInfo) {
		Map<String, String> extractRequestHeader = new HashMap<String, String>();
		extractRequestHeader.put("BatchJobID", batchJobId.toString());
		extractRequestHeader.put("JobIndex", String.valueOf(requestInfo
				.getJobIndex()));
		extractRequestHeader.put("ReferenceURL", requestInfo.getReferenceURL());
		extractRequestHeader.put("MD5CheckSum", requestInfo.getmD5CheckSum());
		return extractRequestHeader;
	}

}
