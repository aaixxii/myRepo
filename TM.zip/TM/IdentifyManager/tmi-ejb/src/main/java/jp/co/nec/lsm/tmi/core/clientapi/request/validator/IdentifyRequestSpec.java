package jp.co.nec.lsm.tmi.core.clientapi.request.validator;

import jp.co.nec.lsm.tm.common.constants.RequestSpecConstants;

public class IdentifyRequestSpec {
	public static final int REQUEST_ID_LENGTH = RequestSpecConstants.REQUEST_ID_LENGTH;
	public static final int REFERENCE_ID_LENGTH = RequestSpecConstants.REFERENCE_ID_LENGTH;
}
