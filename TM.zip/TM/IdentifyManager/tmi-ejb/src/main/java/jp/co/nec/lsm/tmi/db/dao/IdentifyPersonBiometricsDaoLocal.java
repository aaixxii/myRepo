package jp.co.nec.lsm.tmi.db.dao;

import java.util.List;

import javax.ejb.Local;

import jp.co.nec.lsm.tm.db.identify.procedure.BatchJobTemplateInfos;

/**
 * @author liuyq <br>
 */
@Local
public interface IdentifyPersonBiometricsDaoLocal {
	
	/**
	 * search Templates using ReferenceIds
	 * 
	 * @param referenceIds
	 * @param batchJobId
	 * @return IdentifyBatchJobTemplateInfos
	 */
	public List<BatchJobTemplateInfos> getTemplates(
			List<String> referenceIds, long batchJobId);
	/**
	 * set Bad template's CorruptedFlag
	 * 
	 * @param biometricData
	 * @return 
	 */
	public void setBadtemplateCorruptedFlag(String referenceId);
}
