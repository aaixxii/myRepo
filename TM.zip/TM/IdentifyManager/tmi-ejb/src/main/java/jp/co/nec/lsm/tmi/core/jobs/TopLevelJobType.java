package jp.co.nec.lsm.tmi.core.jobs;

public enum TopLevelJobType {
	IDENTIFY_BY_REFERENCEID,
	IDENTIFY_BY_REFERENCEURL,
	IDENTIFY_REQUESTTYPE_ERROR;
}
