package jp.co.nec.lsm.tmi.core.jobs;

import java.util.List;

import jp.co.nec.lsm.proto.identify.IdentifyJobRequestProto.SegmentVersion;
import jp.co.nec.lsm.proto.identify.IdentifyJobResponseProto.IdentifyJobResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author jimy <br>
 */
public class IdentifyJobResponseFactory {

	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(IdentifyJobResponseFactory.class);

	/**
	 * Generate response instance PutidentifyJob
	 * 
	 * @param requestSegInfos
	 *            filtered SegInfos
	 * @param identifyQueueMap
	 *            batch child job queue info
	 * @return response instance PutidentifyJob
	 */
	public static IdentifyJobResponse create(
			List<SegmentVersion> filterSegmentInfo,
			LocalIdentifyBatchJob batchJob,String tmaReceiverUrl) {
		printLogMessage("start private function createBatchSegmentJobResponse()..");

		IdentifyJobResponse.Builder putIdentifyJob = IdentifyJobResponse
				.newBuilder();
		putIdentifyJob.setBatchJobId(batchJob.getbJobId());
		
		if (tmaReceiverUrl == null) {
			putIdentifyJob.setAggregatorURL("");
		} else {
			putIdentifyJob.setAggregatorURL(tmaReceiverUrl);
		}

		// save PutIdentifyJob -> JobInfo, ->jobCount
		printLogMessage("start construct JobInfo and save to PutIdentifyJob.Builder.. ");

		putIdentifyJob.setIdentifyJobs(batchJob.getSearchJobs());
		printLogMessage("end construct JobInfo and save to PutIdentifyJob.Builder.. ");

		printLogMessage("start construct SegmentInfo and save to PutIdentifyJob.Builder.. ");

		// save PutIdentifyJob -> segmentInfo, ->segmentCount
		for (SegmentVersion segmentVersion : filterSegmentInfo) {
			putIdentifyJob.addSegmentId(segmentVersion.getSegmentId());
		}
		printLogMessage("end construct SegmentInfo and save to PutIdentifyJob.Builder.. ");

		printLogMessage("end private function createBatchSegmentJobResponse()..");

		return putIdentifyJob.build();
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
