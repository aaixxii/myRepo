package jp.co.nec.lsm.tmi.common.constants;

/**
 * @author liuyq <br>
 * 
 */
public class IdentifyConstants {
	public static final String EMPTY_STRING_VALUE = "";
	public static final float DEFAULT_UNIT_PERFORMANCE_FACTOR = 1;
	public static final int DEFAULT_ID_LENGTH = 36;

	public static final int POLLING_JOB_DURATION = 5000;
	public static final int POLLING_USC_TIMEOUT_DURATION = 5000;
	public static final int POLLING_GETBATCHJOB_DURATION = 5000;
	public static final int POLLING_DELIVERYCHECK_DURATION = 5000;

	public static final int TOPLEVEL_JOB_START_INDEX = 1;

	public static final String DEFAULT_DM_SEGS_STRING = "/segs/";
	public static final String SUMMARY_SPLIT = "======================================================";
	public static final String SPACE = "    ";

	public static final String HTTP_SOCKET_SENDBUFFER = "http.socket.sendbuffer";
	public static final int SEGMENT_UPDATE_SENDBUFFER_VALUE = 4 * 1024 * 1024;
	public static final int SLB_LOOP_SLEEP_TIME = 5000;

	public static final String SUCCESSFUL_ERROR_CODE = "0";
	public static final int DEFAULT_FAILURE_COUNT = 0;

	public static final double DEFAULT_JOB_MULTIPLE = 1.5;
	public static final double DEFAULT_OFFSET_DIFF = -100;

	public static final String TIMER_STARTED_BEAN = "GetIdentifyBatchJobPollTimerStarterBean";
	public static final int BAD_REQUEST_CODE = -1;
	public static final int DEFAULT_UNNORMAL_POLL_INTERVALS = 5000;

}
