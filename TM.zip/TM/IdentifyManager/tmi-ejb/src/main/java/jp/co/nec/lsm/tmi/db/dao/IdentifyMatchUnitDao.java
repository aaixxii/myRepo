package jp.co.nec.lsm.tmi.db.dao;

import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import jp.co.nec.lsm.proto.common.CommonProto.ComponentType;
import jp.co.nec.lsm.proto.control.EnterRequestProto.EnterRequest;
import jp.co.nec.lsm.tm.common.constants.MUState;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.common.util.MUUtil;
import jp.co.nec.lsm.tm.db.common.entities.MatchUnitEntity;
import jp.co.nec.lsm.tm.db.common.entityhelpers.ContactTimesSPHelper;
import jp.co.nec.lsm.tm.db.common.entityhelpers.MatchUnitHelper;
import jp.co.nec.lsm.tmi.common.constants.IdentifyConstants;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author liuyq <br>
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class IdentifyMatchUnitDao implements IdentifyMatchUnitDaoLocal {
	private static Logger log = LoggerFactory
			.getLogger(IdentifyMatchUnitDao.class);
	@PersistenceContext(unitName = "tmi-unit")
	private EntityManager manager;

	private MatchUnitHelper muHelper;

	@PostConstruct
	public void init() {
		muHelper = new MatchUnitHelper(manager);
		printLogMessage("CNTR: PollBean init");
	}

	/**
	 * constructor
	 */
	public IdentifyMatchUnitDao() {
	}

	@Override
	public List<MatchUnitEntity> listTimedOutFromHeartbeat(Date minHeartbeat) {
		List<MatchUnitEntity> deadMUs = muHelper
				.listTimedOutFromHeartbeat(minHeartbeat);
		return deadMUs;
	}

	@Override
	public List<MatchUnitEntity> findMuByTypeAndStatus(ComponentType type,
			MUState state) {
		printLogMessage("start public function findMuByType()..");

		List<MatchUnitEntity> iue = muHelper.findMuByTypeAndState(type, state);

		printLogMessage("end public function findMuByType()..");
		return iue;
	}

	@Override
	public MatchUnitEntity addOrUpdateUnit(EnterRequest enterRequest) {
		printLogMessage("start public function addOrUpdateUnit()..");

		MatchUnitEntity unit = muHelper.search(enterRequest.getUniqueId());
		Date now = DateUtil.getCurrentDate();
		if (unit != null) {
			muHelper.update(
					unit, //
					enterRequest.getType(), //
					enterRequest.getContactURL(),//
					now, //
					enterRequest.getPrimarySize(), //
					enterRequest.getSecondarySize(),//
					enterRequest.getNumberOfCpus(),//
					enterRequest.getVersion(),
					IdentifyConstants.DEFAULT_UNIT_PERFORMANCE_FACTOR);
		} else {
			unit = muHelper.add(enterRequest.getType(), //
					enterRequest.getUniqueId(),//
					enterRequest.getContactURL(),//
					enterRequest.getPrimarySize(), //
					enterRequest.getSecondarySize(),//
					IdentifyConstants.DEFAULT_UNIT_PERFORMANCE_FACTOR,//
					enterRequest.getNumberOfCpus(), //
					now,//
					enterRequest.getVersion());

			printLogMessage("NEW lsm unit has entered the system.");
		}
		manager.flush();

		printLogMessage("end public function addOrUpdateUnit()..");
		return unit;
	}

	@Override
	public MatchUnitEntity search(int unitId) {
		MatchUnitEntity unit = muHelper.search(unitId);
		return unit;
	}

	@Override
	public boolean isWorkingUnitExist(int unitId) {
		MatchUnitEntity unit = muHelper.search(unitId);
		if (unit == null) {
			log.warn(
					"unit id:{} is not found in match_unit, need to re enter ",
					unitId);
			return false;
		} else {
			if (!MUUtil.isWorkingState(unit.getState())) {
				log
						.warn(
								"unit id: {}  expected to be in state WORKING, instead was in {}",
								unitId, unit.getState());
				return false;

			}
		}
		return true;
	}

	/**
	 * set mu state to timeout
	 * 
	 * @param mu
	 * @param reason
	 */
	@Override
	public void timeoutMatchUnit(MatchUnitEntity mu) {
		mu.setState(MUState.TIMED_OUT);
		manager.flush();
	}

	@Override
	public void exitMatchUnit(MatchUnitEntity mu) {
		mu.setState(MUState.EXITED);
		manager.flush();
	}

	@Override
	public void persitUnitStatusContact(long unitId) {
		ContactTimesSPHelper.updateContactTimes(manager, unitId, true, true);
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
