package jp.co.nec.lsm.tmi.core.jobs;

import java.util.Collection;
import java.util.List;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.proto.identify.IdentifyJobResponseProto.IdentifyJob;
import jp.co.nec.lsm.proto.identify.IdentifyJobResponseProto.IdentifyJobs;
import jp.co.nec.lsm.tm.common.constants.IdentifyErrorMessage;
import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tm.db.identify.procedure.BatchJobTemplateInfos;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.ByteString;

public class BatchJobBuilder {
	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(BatchJobBuilder.class);

	/**
	 * Save into IdentifyQueue
	 * 
	 * @param templatesInfo
	 * @param jobQueues
	 * @param batchIdentifyQueue
	 */
	public static void build(List<BatchJobTemplateInfos> templatesInfo,
			Collection<LocalIdentifyTopLevelJob> topLevelJobs,
			LocalIdentifyBatchJob batchJob) {
		printLogMessage("end private function build()..");

		if (templatesInfo.isEmpty()) {
			log.warn(
					"batchJobId: {} queried for template, but couldn't get any template.",
					batchJob.getbJobId());
		} else {
			printLogMessage("batchJobId: {} queried for template..",
					batchJob.getbJobId());
		}

		if (log.isInfoEnabled()) {
			log.info(InfoLogger.infoOutput(
					"IdentifyPreparetemplateServiceBean",
					"savetemplateToLocalQueue", "DETAIL", "batchJobId:"
							+ batchJob.getbJobId() + " queried for template"));
		}

		IdentifyJobs.Builder jobinfos = IdentifyJobs.newBuilder();

		// loop topLevelJobs from local queue
		for (LocalIdentifyTopLevelJob topLevelJob : topLevelJobs) {
			// the flag means template is exist or not
			boolean isExsitTemplate = false;

			// build IdentifyJob instance
			IdentifyJob.Builder jobinfo = jobinfos.addIdentifyJobBuilder();
			// job Index
			jobinfo.setJobIndex((int) topLevelJob.getJobIndex());
			ByteString businessMessage = topLevelJob.getBusinessMessage();
			if (businessMessage != null) {
				jobinfo.setRequest(businessMessage);
			} else {
				jobinfo.setRequest(ByteString.EMPTY);
			}
			// if top level job has error
			if (topLevelJob.isToplevelJobError()) {
				jobinfo.setIdentifyTemplate(ByteString.copyFrom(new byte[] {}));
				continue;
			}

			// find the template from templatesInfo instance
			for (BatchJobTemplateInfos item : templatesInfo) {
				if (item.isByReferenceUrl()) {
					if (item.getReferenceUrl().equals(
							topLevelJob.getReferenceURL())) {
						isExsitTemplate = true;

						if (item.isRapidExtractError()) {
							topLevelJob.setiReturnCode(ReturnCode.JobFailed);
							topLevelJob.setErrorCode(item.getError()
									.getErrorCode());
							topLevelJob.setErrorMessage(item.getErrorMessage());
							jobinfo.setIdentifyTemplate(ByteString
									.copyFrom(new byte[] {}));
						} else {
							jobinfo.setIdentifyTemplate(ByteString
									.copyFrom(item.getBiometricData()));
						}

						break;
					}
				} else {
					if (item.getReferenceId().equals(
							topLevelJob.getReferenceId())) {
						// find template
						isExsitTemplate = true;
						jobinfo.setIdentifyTemplate(ByteString.copyFrom(item
								.getBiometricData()));
						break;
					}
				}
			}

			// can not find template in db
			// set the template to dummy
			if (!isExsitTemplate) {
				topLevelJob.setiReturnCode(ReturnCode.JobFailed);
				topLevelJob
						.setErrorCode(IdentifyErrorMessage.GET_TEMPLATE_ERROR
								.getErrorCode());
				topLevelJob
						.setErrorMessage("Identify Job ( template Not Found )");
				jobinfo.setIdentifyTemplate(ByteString.copyFrom(new byte[] {}));
			}
		}

		// build the search jobs
		batchJob.setSearchJobs(jobinfos.build().toByteString());

		printLogMessage("end private function saveTemplateToLocalQueue()..");
		return;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 *            ,logParame
	 * @return
	 */
	private static void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}
}
