package jp.co.nec.lsm.tmi.core.jobs;

import java.util.Iterator;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author jimy <br>
 *         this class is used for IdentifyQueue Manager include following method
 * 
 */
public class IdentifyBatchJobManager {
	private static Logger log = LoggerFactory
			.getLogger(IdentifyBatchJobManager.class);
	/**
	 * Local Queue of identify <FIFO>
	 **/
	private ConcurrentLinkedQueue<LocalIdentifyBatchJob> batchJobQueue;

	/** private instance **/
	private static IdentifyBatchJobManager identifyQueueManager;

	/**
	 * get singleton queue manager instance
	 * 
	 * @return queue manager instance
	 */
	public synchronized static IdentifyBatchJobManager getInstance() {
		if (identifyQueueManager == null) {
			identifyQueueManager = new IdentifyBatchJobManager();
		}
		return identifyQueueManager;
	}

	/**
	 * constructor method init field identifyLinkQueue.
	 */
	private IdentifyBatchJobManager() {
		printLogMessage("start public function IdentifyQueueManager()..");
		batchJobQueue = new ConcurrentLinkedQueue<LocalIdentifyBatchJob>();
		printLogMessage("end public function IdentifyQueueManager()..");
	}

	/**
	 * fetch BatchIdentifyQueue instance from Local Queue using batchJobId
	 * 
	 * @param batchJobId
	 * @return BatchIdentifyQueue instance
	 */
	public LocalIdentifyBatchJob getBatchJob(long batchJobId) {
		printLogMessage("start public function getBatchIdentifyQueue()..");

		// get identifyLinkQueue iterator
		Iterator<LocalIdentifyBatchJob> iterator = batchJobQueue.iterator();

		while (iterator.hasNext()) {
			LocalIdentifyBatchJob batchJob = iterator.next();
			if (batchJobId == batchJob.getbJobId()) {
				printLogMessage("find a instance match batchJobId: {}",
						new Object[] { batchJobId });
				return batchJob;
			}
		}

		printLogMessage("end public function getBatchIdentifyQueue()..");
		return null;
	}

	/**
	 * add batchIdentifyQueue into LocalQueue identifyLinkQueue
	 * 
	 * @param batchIdentifyQueue
	 */
	public boolean add(LocalIdentifyBatchJob batchJob) {
		printLogMessage("start public function add()..");

		if (batchJob == null) {
			log.error("batchIdentifyQueue instance is null");
			return false;
		}

		boolean isSuccessful = batchJobQueue.add(batchJob);
		if (isSuccessful) {
			printLogMessage("Successful to add batchIdentifyQueue into identifyLinkQueue");
		} else {
			log.error("Failed to add batchIdentifyQueue into identifyLinkQueue");
		}

		printLogMessage("end public function add()..");
		return isSuccessful;
	}

	/**
	 * remove BatchIdentifyQueue using batchJobId
	 * 
	 * @return isSuccessful
	 */
	public boolean remove(long batchJobId) {
		printLogMessage("start public function remove()..");
		LocalIdentifyBatchJob biq = getBatchJob(batchJobId);
		if (biq == null) {
			printLogMessage(
					"the BatchIdentifyQueue with batchJobId: {} is null",
					batchJobId);
			return false;
		}

		boolean isSuccessful = batchJobQueue.remove(biq);
		if (isSuccessful) {
			printLogMessage("Successful to remove batchIdentifyQueue from identifyLinkQueue");

		} else {
			log.error("Failed to remove batchIdentifyQueue from identifyLinkQueue");
		}

		printLogMessage("end public function remove()..");
		return isSuccessful;
	}

	/**
	 * check Duplicate BatchJobId
	 * 
	 * @return Duplicate return true
	 */
	public boolean isExistDuplicateBatchJobId(long batchJobId) {
		LocalIdentifyBatchJob batchJob = this.getBatchJob(batchJobId);
		if (batchJob == null) {
			return false;
		}
		return true;
	}

	/**
	 * 
	 * @return
	 */
	public Iterator<LocalIdentifyBatchJob> getBatchJobQueue() {
		return batchJobQueue.iterator();
	}

	/**
	 * 
	 * @return
	 */
	public Integer getNotCompletedBatchJobCount() {
		printLogMessage("start public function getNotCompletedBatchJobCount().");
		return batchJobQueue.size();
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 *            ,logParame
	 * @return
	 */
	private void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}

}
