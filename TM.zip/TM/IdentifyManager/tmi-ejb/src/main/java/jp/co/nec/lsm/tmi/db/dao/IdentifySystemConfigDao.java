package jp.co.nec.lsm.tmi.db.dao;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.lsm.tm.common.constants.ConfigProperty;
import jp.co.nec.lsm.tm.common.constants.Constants;
import jp.co.nec.lsm.tm.db.common.entityhelpers.SystemConfigHelper;
import jp.co.nec.lsm.tmi.core.loadbalance.IdentifySLBEnabled;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author liuyq <br>
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class IdentifySystemConfigDao implements IdentifySystemConfigDaoLocal {

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(IdentifySystemConfigDao.class);

	@PersistenceContext(unitName = "tmi-unit")
	private EntityManager manager;
	private SystemConfigHelper sysConfigHelper;
	@Resource(mappedName = "java:/OracleDS")
	private DataSource dataSource;
	@PostConstruct
	public void init() {
		sysConfigHelper = new SystemConfigHelper(manager);
	}

	@Override
	public void writeAllMissingProperties() {
		printLogMessage("start public function writeAllMissingProperties()..");
		sysConfigHelper.writeAllMissingProperties(dataSource);

		printLogMessage("end public function writeAllMissingProperties()..");

	}

	/**
	 * constructor
	 */
	public IdentifySystemConfigDao() {
	}

	@Override
	public String getDmDownloadUrl() {
		return sysConfigHelper.getTMProperty(ConfigProperty.DM_DOWNLOAD_URL);
	}

	@Override
	public Long getBatchJobTimeout() {
		return sysConfigHelper
				.getTMPropertyLong(ConfigProperty.TIMEOUTS_TMI_BATCHJOB);
	}

	@Override
	public Integer getHeartBeatTimeout() {
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.TIMEOUTS_TMI_UNIT_HEARTBEAT);
	}

	@Override
	public Integer getBatchJobReRunLimit() {
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.RERUNLIMIT_TMI_BATCHJOB_REDELIVERY);
	}

	@Override
	public Integer getSendBSJMapRetryIntervals() {
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.RETRYINTERVALS_TMI_SEND_BATCHSEGMENTJOBMAP);
	}

	@Override
	public Integer getSendBSJMapRetryLimit() {
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.RETRYLIMIT_TMI_SEND_BATCHSEGMENTJOBMAP);
	}

	@Override
	public Integer getDmMinRedundancy() {
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.DM_MIN_REDUNDANCY);
	}

	@Override
	public Integer getUscMinRedundancy() {
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.USC_MIN_REDUNDANCY);
	}

	@Override
	public Integer getTmiPollingTime() {
		return sysConfigHelper.getTMPropertyInt(ConfigProperty.TMI_POLLING);
	}

	@Override
	public void setSlbStatus(IdentifySLBEnabled enabled) {
		sysConfigHelper.setProperty(
				ConfigProperty.SEGMENT_LOAD_BALANCER_ENABLED, enabled.name());
	}

	@Override
	public boolean getSlbEnabled() {
		return sysConfigHelper
				.getTMPropertyBoolean(ConfigProperty.SEGMENT_LOAD_BALANCER_ENABLED);
	}

	@Override
	public int getMinUscForSlb() {
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.MIN_USCS_FOR_SLB);
	}

	@Override
	public int getMinDmForSlb() {
		return sysConfigHelper.getTMPropertyInt(ConfigProperty.MIN_DMS_FOR_SLB);
	}

	@Override
	public Integer getRetryMaxCount() {
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.RETRYLIMIT_TMI_POST_TO_RAPIDMFE);
	}

	@Override
	public Integer getHighLevelIdentifyBatchJobs() {
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.BATCHJOB_COUNT_IDENTIFY_JOBFETCH_FOR_HIGH_LEVEL);
	}

	@Override
	public Integer getLowLevelIdentifyBatchJobs() {
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.BATCHJOB_COUNT_IDENTIFY_JOBFETCH_FOR_LOW_LEVEL);
	}

	@Override
	public Integer getIntervalForIdentifyHighLevel() {
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.INTERVALS_IDENTIFY_JOBFETCH_FOR_HIGH_LEVEL);
	}

	@Override
	public Integer getIntervalForIdentifyLowLevel() {
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.INTERVALS_IDENTIFY_JOBFETCH_FOR_LOW_LEVEL);
	}

	@Override
	public Integer getIntervalForIdentifyNormalLevel() {
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.INTERVALS_IDENTIFY_JOBFETCH_FOR_NORMAL_LEVEL);
	}

	@Override
	public String getBatchJobFromTransformerUrl() {
		return sysConfigHelper
				.getTMProperty(ConfigProperty.IDENTIFY_GETBATCHJOB_URL);
	}

	@Override
	public String getJobCountToTransformer() {
		return sysConfigHelper
				.getTMProperty(ConfigProperty.TRANSFORMER_TMI_GET_JOB_COUNT);
	}

	@Override
	public String getBatchJobCountToTransformer() {
		return sysConfigHelper
				.getTMProperty(ConfigProperty.TRANSFORMER_TMI_GET_BATCHJOB_COUNT);
	}

	@Override
	public Integer getMaxResults() {
		return sysConfigHelper
				.getTMPropertyInt(ConfigProperty.DEFAULT_TMI_GET_MAXRESULTS);
	}

	@Override
	public String getRapidEncoder() {
		return sysConfigHelper
				.getTMProperty(ConfigProperty.TMI_RAPIDENCODER_URL);
	}

	@Override
	public String getTurnAroundTime() {
		return sysConfigHelper
				.getTMProperty(ConfigProperty.TRANSFORMER_TMI_TURNAROUNDTIME);
	}

	@Override
	public boolean getIdentifyServiceEnabled() {
		return sysConfigHelper
				.getTMPropertyBoolean(ConfigProperty.IDENTIFY_SERVICE_ENABLED);
	}

	/**
	 * get identify web context name
	 * 
	 * @return identify web context name
	 */
	public String getTMIWebContextName() {
		return sysConfigHelper
				.getTMProperty(ConfigProperty.TMI_WEB_CONTEXT_NAME);

	}

	/**
	 * get Web Port number
	 * 
	 * @return Web Port number
	 */
	public String getTMIWebPort() {
		return sysConfigHelper.getTMProperty(ConfigProperty.TMI_WEB_PORT_NUM);

	}

	/**
	 * get tma job receiver url
	 * 
	 * @return Web Port number
	 */
	@Override
	public String getTmaReceiverUrl() {
		String tmaIp = getTmaIpAddress();
		String tmaWebPort = sysConfigHelper
				.getTMProperty(ConfigProperty.TMA_WEB_PORT_NUM);
		String jobReceiverUrl = sysConfigHelper
				.getTMProperty(ConfigProperty.TMA_JOB_RECEIVER_URL);
		return Constants.HTTP + tmaIp + Constants.COLON + tmaWebPort
				+ jobReceiverUrl;
	}

	/**
	 * get tma ip address
	 * 
	 * @return Web Port number
	 */
	@Override
	public String getTmaIpAddress() {
		return sysConfigHelper.getTMProperty(ConfigProperty.TMA_IP_ADDRESS);
	}

	/**
	 * get tmi job receiver url
	 * 
	 * @return Web Port number
	 */
	@Override
	public String getTmiBatchJobReceiverUrl() {
		String tmiIp = getTmiIpAddress();
		String tmiWebPort = sysConfigHelper
				.getTMProperty(ConfigProperty.TMI_WEB_PORT_NUM);
		String jobReceiverUrl = sysConfigHelper
				.getTMProperty(ConfigProperty.TMI_BATCHJOB_RECEIVER_URL);
		return Constants.HTTP + tmiIp + Constants.COLON + tmiWebPort
				+ jobReceiverUrl;
	}

	/**
	 * get tmi ip address
	 * 
	 * @return Web Port number
	 */
	public String getTmiIpAddress() {
		return sysConfigHelper.getTMProperty(ConfigProperty.TMI_IP_ADDRESS);
	}

	/**
	 * get tma web context name
	 * 
	 * @return identify web context name
	 */
	public String getTMAWebContextName() {
		return sysConfigHelper
				.getTMProperty(ConfigProperty.TMA_WEB_CONTEXT_NAME);
	}

	/**
	 * get tma Web Port number
	 * 
	 * @return Web Port number
	 */
	public String getTMAWebPort() {
		return sysConfigHelper.getTMProperty(ConfigProperty.TMA_WEB_PORT_NUM);
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
