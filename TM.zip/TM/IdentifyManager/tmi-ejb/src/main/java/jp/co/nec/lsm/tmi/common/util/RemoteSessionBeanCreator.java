package jp.co.nec.lsm.tmi.common.util;

import jp.co.nec.lsm.tm.common.constants.JNDIConstants;
import jp.co.nec.lsm.tm.common.util.ServiceLocator;
import jp.co.nec.lsm.tma.sessionbean.api.BatchSegmentJobMapInitializerRemote;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author liuyq <br>
 */
public class RemoteSessionBeanCreator {

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(RemoteSessionBeanCreator.class);

	/**
	 * 
	 * @param sleepTime
	 * @param retryLimit
	 * @return
	 */
	public static BatchSegmentJobMapInitializerRemote retryLookupRemoteBean(
			int sleepTime, int retryLimit, String ip) {
		int retryTime = 0;
		while (retryTime < retryLimit) {
			BatchSegmentJobMapInitializerRemote remote = (BatchSegmentJobMapInitializerRemote) ServiceLocator
					.lookUpJndiObjectReomte(
							JNDIConstants.TMA_BEAN_BATCHSEGMENTJOB_INIT, ip);
			if (remote == null) {
				// do retry
				retryTime += 1;
				threadSleep(sleepTime);
			} else {
				return remote;
			}
		}
		return null;
	}

	/**
	 * 
	 * @param sleepTime
	 */
	private static void threadSleep(int sleepTime) {
		try {
			Thread.sleep(sleepTime);
		} catch (InterruptedException e) {
			log
					.error(
							"thread sleep error when send batchSegmentJobMap to aggregation manager..",
							e);
		}
	}
}
