package jp.co.nec.lsm.tmi.core.jobs;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;

import com.google.protobuf.ByteString;

/**
 * @author liuyq <br>
 */
public class LocalIdentifyTopLevelJob {
	private long bJobId;
	private int jobIndex;
	private LocalIdentifyJobStatus identifyJobStatus;

	private String requestId;
	private String referenceId;
	private String referenceURL;
	private TopLevelJobType topLevelType;

	private String MD5CheckSum;
	private int maxCandidates;
	private ByteString businessMessage;

	private int failureCount;

	private ReturnCode iReturnCode = ReturnCode.JobSuccess;
	private String errorCode;
	private String errorMessage;
	private byte[] template;

	public long getbJobId() {
		return bJobId;
	}

	public void setBatchJobID(long bJobId) {
		this.bJobId = bJobId;
	}

	public int getJobIndex() {
		return jobIndex;
	}

	public void setJobIndex(int jobId) {
		this.jobIndex = jobId;
	}

	public LocalIdentifyJobStatus getIdentifyJobStatus() {
		return identifyJobStatus;
	}

	public void setIdentifyJobStatus(LocalIdentifyJobStatus identifyJobStatus) {
		this.identifyJobStatus = identifyJobStatus;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

	public String getReferenceURL() {
		return referenceURL;
	}

	public void setReferenceURL(String referenceURL) {
		this.referenceURL = referenceURL;
	}

	public TopLevelJobType getTopLevelType() {
		return topLevelType;
	}

	public void setTopLevelType(TopLevelJobType topLevelType) {
		this.topLevelType = topLevelType;
	}

	public int getMaxCandidates() {
		return maxCandidates;
	}

	public void setMaxCandidates(int maxCandidates) {
		this.maxCandidates = maxCandidates;
	}

	public String getMD5CheckSum() {
		return MD5CheckSum;
	}

	public void setMD5CheckSum(String mD5CheckSum) {
		MD5CheckSum = mD5CheckSum;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public void setbJobId(long bJobId) {
		this.bJobId = bJobId;
	}

	public int getFailureCount() {
		return failureCount;
	}

	public void setFailureCount(int failureCount) {
		this.failureCount = failureCount;
	}

	public ReturnCode getiReturnCode() {
		return iReturnCode;
	}

	public void setiReturnCode(ReturnCode iReturnCode) {
		this.iReturnCode = iReturnCode;
	}

	public byte[] getTemplate() {
		return template;
	}

	public void setTemplate(byte[] template) {
		this.template = template;
	}

	public boolean isToplevelJobError() {
		return this.getiReturnCode() == ReturnCode.JobFailed;
	}

	public ByteString getBusinessMessage() {
		return businessMessage;
	}

	public void setBusinessMessage(ByteString businessMessage) {
		this.businessMessage = businessMessage;
	}

	public boolean isUsingReferenceID() {
		return this.getTopLevelType() == TopLevelJobType.IDENTIFY_BY_REFERENCEID ? true
				: false;
	}

	public boolean isUsingReferenceURL() {
		return this.getTopLevelType() == TopLevelJobType.IDENTIFY_BY_REFERENCEURL ? true
				: false;
	}

	public boolean isSuccessed() {
		return iReturnCode == ReturnCode.JobSuccess;
	}
}
