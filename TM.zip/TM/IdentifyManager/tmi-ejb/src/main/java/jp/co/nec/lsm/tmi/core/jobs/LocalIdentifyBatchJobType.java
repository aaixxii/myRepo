package jp.co.nec.lsm.tmi.core.jobs;

/**
 * @author liuyq <br>
 */
public enum LocalIdentifyBatchJobType {
	BY_ID_ONLY,
	BY_URL_CONTAINS;
}
