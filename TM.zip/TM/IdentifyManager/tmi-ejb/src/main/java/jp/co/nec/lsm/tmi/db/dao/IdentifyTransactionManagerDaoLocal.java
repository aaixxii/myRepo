package jp.co.nec.lsm.tmi.db.dao;

import javax.ejb.Local;

/**
 * @author liuyq <br>
 */
@Local
public interface IdentifyTransactionManagerDaoLocal {

	public void setStartupTime();
	public void changeTMIToExit();

}
