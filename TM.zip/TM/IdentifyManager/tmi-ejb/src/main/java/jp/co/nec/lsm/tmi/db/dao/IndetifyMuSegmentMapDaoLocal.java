package jp.co.nec.lsm.tmi.db.dao;

import java.util.List;

import javax.ejb.Local;

import jp.co.nec.lsm.proto.common.CommonProto.ComponentType;
import jp.co.nec.lsm.tm.db.common.entities.MatchUnitEntity;
import jp.co.nec.lsm.tm.db.common.entities.MuSegmentEntity;
import jp.co.nec.lsm.tm.db.common.entities.SegmentEntity;
import jp.co.nec.lsm.tm.db.identify.entities.AppointedMuSegmentEntity;

/**
 * @author liuyq <br>
 */
@Local
public interface IndetifyMuSegmentMapDaoLocal {

	/**
	 * Find List of EnrollTMEUnitEntity(MFE) which is concerned with MU_SEGMENTS
	 * 
	 * @return List of EnrollTMEUnitEntity
	 */
	public List<MatchUnitEntity> findUnitInMuSegMapByUnitType(
			ComponentType unitType);

	/**
	 * Find List of SegmentEntity which is concerned with MU_SEGMENTS
	 * 
	 * @return List of SegmentEntity
	 */
	public List<SegmentEntity> findSegmentsInMuSegMap(
			ComponentType unitType);

	/**
	 * Find MuSegMapEntity of USC
	 * 
	 * @return List of MuSegMapEntity
	 */
	public List<AppointedMuSegmentEntity> findPreMuSegMapByUnitTpye(
			ComponentType unitType);

	/**
	 * Find List of IdentifyUnitEntity which is concerned with MU_SEGMENTS
	 * 
	 * @return List of EnrollTMEUnitEntity
	 */
	public List<MatchUnitEntity> findPreUnitInMuSegMap(ComponentType unitType);

	/**
	 * Find List of SegmentEntity which is concerned with MU_SEGMENTS
	 * 
	 * @return List of SegmentEntity
	 */
	public List<SegmentEntity> findPreSegmentsInMuSegMapByUnitType(
			ComponentType unitType);

	/**
	 * updata AppointedMuSegment with MuSegment
	 * 
	 * @return
	 */
	public void updataAppointedMuSegment();

	/**
	 * clearMuSegment
	 */
	public void clearMuSegmetByUnitType(ComponentType unitType);

	/**
	 * update new MU-Segment Maps information into database
	 * 
	 * @param newMatrix
	 *            new MU-Segment Maps(boolean)
	 * @param muEntities
	 *            MU Entities list
	 * @param segmentEntities
	 *            segment Entities list
	 * @param muSegMaps
	 *            MU-Segment Maps list
	 */
	public void updateMuSegMap(boolean[][] newMatrix,
			List<MatchUnitEntity> muEntities,
			List<SegmentEntity> segmentEntities,
			List<MuSegmentEntity> muSegMaps,
			ComponentType unitType);

	/**
	 * findMuSegMapByUnitType
	 * 
	 * @param unitType
	 *            unitType
	 * @return
	 */
	public List<MuSegmentEntity> findMuSegMapByUnitType(
			ComponentType unitType);
}
