package jp.co.nec.lsm.tmi.db.dao;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tm.db.identify.entities.IdentifyBatchJobDBStatus;
import jp.co.nec.lsm.tm.db.identify.entities.IdentifyBatchJobQueueEntity;
import jp.co.nec.lsm.tm.db.identify.entities.IdentifyJobQueueEntity;
import jp.co.nec.lsm.tm.db.identify.entityhelpers.IdentifyBatchJobHelper;
import jp.co.nec.lsm.tmi.core.clientapi.converter.TransformerJobQueueConverter;
import jp.co.nec.lsm.tmi.sessionbean.para.LocalIdentifyRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author liuyq <br>
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class IdentifyBatchJobDao implements IdentifyBatchJobDaoLocal {
	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(IdentifyBatchJobDao.class);

	/** dataSource instance **/
	@Resource(mappedName = "java:/OracleDS")
	private DataSource dataSource;
	@PersistenceContext(unitName = "tmi-unit")
	private EntityManager manager;
	private IdentifyBatchJobHelper identfyJobHelper;
	@EJB
	private IdentifySystemConfigDaoLocal identifySystemConfigDao;

	@PostConstruct
	public void init() {
		identfyJobHelper = new IdentifyBatchJobHelper(manager, dataSource);
		printLogMessage("IdentifyPrepareTemplateServiceBean init");
	}

	/**
	 * constructor
	 */
	public IdentifyBatchJobDao() {
	}

	/**
	 * get Batch Job Entity by Batch Job Id
	 * 
	 * @param batchJobId
	 * @return
	 */
	@Override
	public IdentifyBatchJobQueueEntity getBatchJobEntitybyId(long batchJobId) {
		return identfyJobHelper.getBatchJobEntitybyId(batchJobId);
	}

	/**
	 * 
	 */
	@Override
	public boolean persistBatchJob(LocalIdentifyRequest identifyBatchRequest) {
		// entity instance for database
		IdentifyBatchJobQueueEntity batchJobQueueEntity = new IdentifyBatchJobQueueEntity();
		List<IdentifyJobQueueEntity> jobQueueEntities = new ArrayList<IdentifyJobQueueEntity>();
		TransformerJobQueueConverter.convertToEntity(identifyBatchRequest,
				batchJobQueueEntity, jobQueueEntities, identifySystemConfigDao);

		boolean isBatchIdDuplicate = identfyJobHelper.persistBatchJob(
				batchJobQueueEntity, jobQueueEntities, dataSource);
		return isBatchIdDuplicate;
	}

	/**
	 * 
	 */
	@Override
	public List<Long> getAllUndoneIdentifyBatchJobs(
			IdentifyBatchJobDBStatus status) {
		printLogMessage("start public function getAllUndoneIdentifyBatchJobs()..");

		List<Long> allUnfinishedJobs = identfyJobHelper
				.getAllUndoneIdentifyBatchJobIDs(status);

		if (allUnfinishedJobs == null || allUnfinishedJobs.isEmpty()) {
			// no UnDone BatchJobs in database
			if (log.isInfoEnabled()) {
				log.info(InfoLogger.infoOutput("SystemInitializationBean",
						"findUnDoneJobs", "DETAIL",
						"there is no UnDone BatchJobs in database"));
			}
			return null;

		}

		printLogMessage("end public function getAllUndoneIdentifyBatchJobs()..");
		return allUnfinishedJobs;
	}

	/**
	 * 
	 */
	@Override
	public List<IdentifyJobQueueEntity> getAllIdentifyJobs(long batchJobId) {
		printLogMessage("start public function getAllIdentifyJobs()..");

		List<IdentifyJobQueueEntity> identifyJobs = identfyJobHelper
				.getAllIdentifyJobs(batchJobId);
		if (identifyJobs == null || identifyJobs.isEmpty()) {
			// this BatchJob has no top level job in database
			if (log.isInfoEnabled()) {
				log.info(InfoLogger.infoOutput("SystemInitializationBean",
						"findUnDoneJobs", "DETAIL", "this BatchJob(BatchJobID:"
								+ batchJobId
								+ "has no top level job in database"));
			}
			return null;
		}

		printLogMessage("end public function getAllIdentifyJobs()..");
		return identifyJobs;
	}

	@Override
	public void persistBatchJobStatusAndEndTs(long batchJobId,
			IdentifyBatchJobDBStatus status) {
		identfyJobHelper.persistBatchJobStatusAndEndTs(batchJobId, status);
	}

	@Override
	public void persistBatchJobStatusAndStartTS(long batchJobId,
			IdentifyBatchJobDBStatus status) {
		identfyJobHelper.persistBatchJobStatusAndStartTS(batchJobId, status);
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 *            ,logParame
	 * @return
	 */
	private void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
