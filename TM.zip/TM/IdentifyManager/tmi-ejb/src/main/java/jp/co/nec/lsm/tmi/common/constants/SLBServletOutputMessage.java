package jp.co.nec.lsm.tmi.common.constants;

public class SLBServletOutputMessage {
	public static final String SLB_SERVLET_OUTPUT_START_SKIP = "SLB already started, skip start operation..";
	public static final String SLB_SERVLET_OUTPUT_START = "\r\n SLB enabled is :true";

	public static final String SLB_SERVLET_OUTPUT_STOP_SKIP = "SLB already stoped, skip stop operation..";
	public static final String SLB_SERVLET_OUTPUT_STOP = "Success stop SLB, SLB enabled is :false";

	public static final String SLB_SERVLET_OUTPUT_ENABLE_SKIP = "SLB already enabled. skip enable operation..";
	public static final String SLB_SERVLET_OUTPUT_ENABLE = "Success enable SLB flag, SLB enabled is :true";

	public static final String SLB_SERVLET_OUTPUT_DISABLE_SKIP = "SLB already disabled. skip disabled operation..";
	public static final String SLB_SERVLET_OUTPUT_DISABLE = "Success disabled SLB flag, SLB enabled is :false";

	public static final String SLB_SERVLET_OUTPUT_EXECUTE_SKIP = "SLB flag is enable, skip execute slb operation..";
	public static final String SLB_SERVLET_OUTPUT_EXECUTE_DM = "Success execute DM SLB..\r\n";
	public static final String SLB_SERVLET_OUTPUT_EXECUTE_USC = "Success execute USC SLB..";

	public static final String SLB_SERVLET_OUTPUT_EXECUTE_NOSEGMENT = "segment is not found. skip execute slb..";

	public static final String SLB_SERVLET_OUTPUT_EXECUTE_MINUSC = "working USC is under the number of min USC for slb, skip execute slb for USC..";
	public static final String SLB_SERVLET_OUTPUT_EXECUTE_MINDM = "working DM is under the number of min DM for slb, skip execute slb for DM..\r\n";

	public static final String SLB_SERVLET_OUTPUT_EXECUTE_NODM = "there is no working DM, skip DM segment load balance.\r\n";
	public static final String SLB_SERVLET_OUTPUT_EXECUTE_NOUSC = "there is no working USC, skip USC segment load balance.";
}
