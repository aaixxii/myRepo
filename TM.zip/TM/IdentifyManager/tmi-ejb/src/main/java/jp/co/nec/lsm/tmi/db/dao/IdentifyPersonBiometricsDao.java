package jp.co.nec.lsm.tmi.db.dao;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.db.common.entityhelpers.PersonBiometricsHelper;
import jp.co.nec.lsm.tm.db.identify.procedure.BatchJobTemplateInfos;
import jp.co.nec.lsm.tm.db.identify.procedure.FetchBatchTemplatesProcedure;
import jp.co.nec.lsm.tmi.exception.IdentifyRuntimeException;

import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author liuyq <br>
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class IdentifyPersonBiometricsDao implements
		IdentifyPersonBiometricsDaoLocal {
	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(IdentifyPersonBiometricsDao.class);

	/** dataSource instance **/
	@Resource(mappedName = "java:/OracleDS")
	private DataSource dataSource;
	@PersistenceContext(unitName = "tmi-unit")
	private EntityManager manager;
	private PersonBiometricsHelper personBiometricsHelper;

	@PostConstruct
	public void init() {
		personBiometricsHelper = new PersonBiometricsHelper(manager);
		printLogMessage("IdentifyPrepareTemplateServiceBean init");

	}

	/**
	 * constructor
	 */
	public IdentifyPersonBiometricsDao() {
	}

	/**
	 * get Templates from DB
	 * 
	 * @param batchIdentifyQueue
	 * @return PutIdentifyJob.Builder instance
	 */
	@Override
	public List<BatchJobTemplateInfos> getTemplates(List<String> referenceIds,
			long batchJobId) {
		printLogMessage("start public function callGetTemplatesWithReferenceIds()..");
		StopWatch t = new StopWatch();
		t.start();
		try {
			// call Procedure to select templates by referenceIds
			FetchBatchTemplatesProcedure templatesProcedure = new FetchBatchTemplatesProcedure(
					dataSource);
			// set oracle fetchSize
			// templatesProcedure.setFetchSize(500);
			log.info("now our fetchsize is: {}", templatesProcedure
					.getJdbcTemplate().getFetchSize());
			// set search condition
			templatesProcedure.setReferenceId(referenceIds);
			// get search result
			List<BatchJobTemplateInfos> templatesInfo = templatesProcedure
					.execute();
			printLogMessage("start public function callGetTemplatesWithReferenceIds()..");

			t.stop();
			PerformanceLogger.performanceOutput("IdentifyPersonBiometricsDao",
					"callTemplatesWithReferenceIds", t.getTime());

			return templatesInfo;
		} catch (Exception e) {
			String message = "execute GetBatchTemplatesProcedure error: "
					+ e.getMessage() + " batchJobId: " + batchJobId;
			throw new IdentifyRuntimeException(message, e);
		}
	}

	@Override
	/**
	 * set Bad template's CorruptedFlag
	 * 
	 * @param biometricData
	 * @return 
	 */
	public void setBadtemplateCorruptedFlag(String referenceId) {
		printLogMessage("start public function setBadtemplateCorruptedFlag()..");
		try {
			personBiometricsHelper.setBadtemplateCorruptedFlag(referenceId);
		} catch (Exception e) {
			throw new IdentifyRuntimeException(
					"Failed to persistBatchJob because of Exception", e);
		}
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
