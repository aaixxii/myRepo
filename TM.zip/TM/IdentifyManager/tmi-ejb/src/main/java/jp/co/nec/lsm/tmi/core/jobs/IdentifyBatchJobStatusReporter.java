package jp.co.nec.lsm.tmi.core.jobs;

import java.util.Collection;
import java.util.Iterator;

import jp.co.nec.lsm.tm.common.communication.SegmentMap;
import jp.co.nec.lsm.tmi.common.constants.IdentifyConstants;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class IdentifyBatchJobStatusReporter {
	private static Logger log = LoggerFactory
			.getLogger(IdentifyBatchJobManager.class);

	/**
	 * get identifyLinkQueue Summary
	 * 
	 * @return Summary Information
	 */
	public static String reportJobSummary() {
		printLogMessage("start public function getSummary()..");
		IdentifyBatchJobManager identifyJobManager = IdentifyBatchJobManager
				.getInstance();
		StringBuilder sb = new StringBuilder();
		// get identifyLinkQueue iterator
		Iterator<LocalIdentifyBatchJob> iterator = identifyJobManager
				.getBatchJobQueue();

		// check iterator is null or empty
		if (iterator == null || !iterator.hasNext()) {

			printLogMessage("identifyLinkQueue instance is null or empty");
			return null;
		}

		// do loop until find a instance match batchJobId
		while (iterator.hasNext()) {
			LocalIdentifyBatchJob biq = iterator.next();
			if (biq == null) {

				printLogMessage("this BatchIdentifyQueue instance is null");
				continue;
			}

			// create Batch Job Summary of biq
			String biqSummary = createBatchJobSummary(biq);
			sb.append(biqSummary);
		}

		printLogMessage("end public function getSummary()..");
		return sb.toString();
	}

	/**
	 * create Batch Job Summary of biq
	 * 
	 * @param biq
	 * @return
	 */
	private static String createBatchJobSummary(LocalIdentifyBatchJob batchJob) {
		final String br = System.getProperty("line.separator");
		StringBuilder sb = new StringBuilder();
		Collection<SegmentMap> segmentMaps = batchJob.getSegmentMapValues();
		int segmentMapsSize = segmentMaps.size();

		addHeader(sb, br);

		sb.append("batch job id:");
		sb.append(batchJob.getbJobId());
		sb.append(br);
		sb.append("batch job failure count:");
		sb.append(batchJob.getFailureCount());
		sb.append(br);
		sb.append("batch job status:");
		sb.append(batchJob.getBatchJobStatus().toString());
		sb.append(br);
		sb.append("batch sub job count:");
		sb.append(batchJob.getTopLevelJobs().size());
		sb.append(br);
		sb.append("batch segment job count:");
		sb.append(segmentMapsSize);
		sb.append(br);

		for (SegmentMap segmentMap : segmentMaps) {
			sb.append("segment job id:");
			sb.append(segmentMap.getSegmentId());
			sb.append(IdentifyConstants.SPACE);
			sb.append("segment job version:");
			sb.append(segmentMap.getTargetVersion());
			sb.append(IdentifyConstants.SPACE);
			sb.append("segment job status:");
			sb.append(segmentMap.getBatchSegmentJobStatus().name());
			sb.append(IdentifyConstants.SPACE);
			sb.append("segment job failure count:");
			sb.append(segmentMap.getFailureCount());
			sb.append(IdentifyConstants.SPACE);
			sb.append("segment job assigned Mu id:");
			sb.append(segmentMap.getMuId());
			sb.append(IdentifyConstants.SPACE);
			sb.append(br);
		}

		addFooter(sb, br);

		return sb.toString();
	}

	/**
	 * create header
	 * 
	 * @param sb
	 *            ,br
	 * @return
	 */
	private static void addHeader(StringBuilder sb, String br) {
		sb.append(br);
		sb.append(IdentifyConstants.SUMMARY_SPLIT);
		sb.append(br);
	}

	/**
	 * create footer
	 * 
	 * @param sb
	 *            ,br
	 * @return
	 */
	private static void addFooter(StringBuilder sb, String br) {
		sb.append(IdentifyConstants.SUMMARY_SPLIT);
		sb.append(br);
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
