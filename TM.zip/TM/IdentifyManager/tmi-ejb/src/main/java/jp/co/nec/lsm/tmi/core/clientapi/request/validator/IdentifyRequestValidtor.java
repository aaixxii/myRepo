package jp.co.nec.lsm.tmi.core.clientapi.request.validator;

import java.util.ArrayList;
import java.util.List;

import jp.co.nec.lsm.tm.common.constants.IdentifyErrorMessage;
import jp.co.nec.lsm.tm.common.validator.ValidationResult;
import jp.co.nec.lsm.tm.common.validator.ValidationResultError;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tm.protocolbuffer.identify.IdentifyRequestProto.IdentifyRequest;
import jp.co.nec.lsm.tmi.db.dao.IdentifySystemConfigDaoLocal;
import jp.co.nec.lsm.tmi.sessionbean.para.LocalIdentifyRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acc.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;

/**
 * @author liuyq <br>
 */
public class IdentifyRequestValidtor {
	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(IdentifyRequestValidtor.class);

	public static ValidationResult validateAndConvert(IdentifyRequest request,
			LocalIdentifyRequest localIdentifyRequest,
			IdentifySystemConfigDaoLocal systemConfigDao)
			throws InvalidProtocolBufferException {
		ValidationResult result = new ValidationResult();

		// check batchJobId is not over zero
		long batchJobId = request.getBatchJobId();
		ValidationResultError error = validateBatchJobIdNotOverZero(batchJobId);
		result.addErrorIfNeccessary(error);
		if (error != null) {
			return result;
		}

		// check Batch job type is identify
		error = ValidatBatchJobType(request);
		result.addErrorIfNeccessary(error);
		if (error != null) {
			return result;
		}

		// convert to LocalIdentifyRequest instance
		List<CPBBusinessMessage> businessMessages = new ArrayList<CPBBusinessMessage>();
		List<ByteString> businessMessageStrings = request
				.getBusinessMessageList();
		for (ByteString businessMessageString : businessMessageStrings) {
			try {
				CPBBusinessMessage businessMessage = CPBBusinessMessage
						.parseFrom(businessMessageString);
				businessMessages.add(businessMessage);
			} catch (InvalidProtocolBufferException ex) {
				log.error("error occured in parse CPBBusinessMessage."
						+ " skip this top level job..", ex);
				continue;
			}
		}

		// add log to display the pass and reject information
		if (log.isInfoEnabled()) {
			int totalCount = businessMessageStrings.size();
			int successCount = businessMessages.size();
			int failureCount = totalCount - successCount;
			log.info(
					"the CPBBusinessMessage from transformer serialize completely,"
							+ " reject job count: {}, receive job count: {}, "
							+ "total count: {}.", new Object[] { failureCount,
							successCount, totalCount });
		}

		// check Job Count
		// Job count would be from 1 to 1000
		error = ValidatBusinessMessageIsEmpty(businessMessages);
		result.addErrorIfNeccessary(error);
		if (error != null) {
			return result;
		}

		// get from system config TRANSFORMER.IDENTIFY_GET_JOB_COUNT
		int maxTopLevelJob = Integer.parseInt(systemConfigDao
				.getJobCountToTransformer());

		// if top level job count is under 1000(default)
		error = validateNotOverMaxNumOfTopLevelJobs(businessMessages,
				maxTopLevelJob);
		result.addErrorIfNeccessary(error);
		if (error != null) {
			return result;
		}

		localIdentifyRequest.setBatchJobId(batchJobId);
		localIdentifyRequest.setType(request.getType());
		localIdentifyRequest.setBusinessMessages(businessMessages);
		return result;
	}

	/**
	 * 
	 * @param batchJobId
	 * @return
	 */
	private static ValidationResultError validateBatchJobIdNotOverZero(
			long batchJobId) {
		if (batchJobId <= 0) {
			String errorInfo = "Identify Job ( Identify batch Job Id "
					+ "is not over zero. ) ";
			log.error(errorInfo);
			return constructError(0, false, errorInfo, "");
		}
		return null;
	}

	/**
	 * ValidatBatchJobIdIsUnderZero
	 * 
	 * @param request
	 */
	private static ValidationResultError ValidatBatchJobType(
			IdentifyRequest request) {
		// check Batch Job Type is Identify
		if (request.getType() != BatchType.IDENTIFY) {
			String errorInfo = "Identify Job ( IdentifyRequest "
					+ "BatchJob type is not IDENTIFY )";
			log.error(errorInfo);
			return constructError(0, false, errorInfo, "");
		}
		return null;
	}

	/**
	 * ValidatTopLevelJobIsEmpty
	 * 
	 * @param topLevelJobs
	 * @param batchJobId
	 * @return
	 */
	private static ValidationResultError ValidatBusinessMessageIsEmpty(
			List<CPBBusinessMessage> businessMessages) {
		// check Batch Job Id is under zero
		if (businessMessages.isEmpty()) {
			String errorInfo = "Identify Job ( IdentifyRequest has"
					+ " no top level job )";
			log.error(errorInfo);
			return constructError(0, false, errorInfo,
					IdentifyErrorMessage.TOP_LEVEL_JOB_EMPTY.getErrorCode());
		}
		return null;
	}

	/**
	 * validateNotOverMaxNumOfTopLevelJobs
	 * 
	 * @param topLevelJobs
	 * @param batchJobId
	 * @return ValidationResultError
	 */
	private static ValidationResultError validateNotOverMaxNumOfTopLevelJobs(
			List<CPBBusinessMessage> messageList, int maxTopLevelJob) {
		// check Batch Job Id is under zero
		if (messageList.size() > maxTopLevelJob) {
			String errorInfo = "Identify Job ( IdentifyRequest top level job is over "
					+ maxTopLevelJob + " ) ";
			log.error(errorInfo);
			return constructError(0, false, errorInfo,
					IdentifyErrorMessage.TOP_LEVEL_JOB_OVER_LIMIT
							.getErrorCode());
		}
		return null;
	}

	/**
	 * 
	 * @param valid
	 * @param invalidReason
	 * @return
	 */
	private static ValidationResultError constructError(int jobIndex,
			boolean valid, String invalidReason, String errorCode) {
		ValidationResultError error = new ValidationResultError();
		error.setJobIndex(jobIndex);
		error.setValid(valid);
		error.setErrorCode(errorCode);
		error.setInvalidReason(invalidReason);
		return error;
	}
}
