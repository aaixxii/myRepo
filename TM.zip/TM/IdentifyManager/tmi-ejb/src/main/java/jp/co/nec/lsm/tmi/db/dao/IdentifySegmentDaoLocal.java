package jp.co.nec.lsm.tmi.db.dao;

import java.util.List;

import javax.ejb.Local;

import jp.co.nec.lsm.tm.db.common.entities.SegmentEntity;

/**
 * @author liuyq <br>
 */
@Local
public interface IdentifySegmentDaoLocal {

	public List<SegmentEntity> findAllSegmentsInfo();

	public List<SegmentEntity> findSegmentsInfoByUnitId(int unitId);
}
