package jp.co.nec.lsm.tmi.core.jobs;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import jp.co.nec.lsm.proto.identify.IdentifyJobRequestProto.SegmentVersion;
import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tm.common.communication.SegmentMap;
import jp.co.nec.lsm.tm.common.log.BatchJobStatusLogger;
import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tmi.common.constants.IdentifyConstants;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.ByteString;

/**
 * @author liuyq <br>
 */
public class LocalIdentifyBatchJob {
	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(LocalIdentifyBatchJob.class);

	private long bJobId;
	private LocalIdentifyBatchJobStatus batchJobStatus;

	private int byURLCount = 0;
	private LocalIdentifyBatchJobType batchJobType;
	private int failureCount = 0;
	/** key -> jobIndex, value -> IdentifyTopLevelJob */
	private Map<Integer, LocalIdentifyTopLevelJob> topLevelJobMap = new ConcurrentHashMap<Integer, LocalIdentifyTopLevelJob>();
	/** searchJobs will give USC **/
	private ByteString searchJobs = ByteString.EMPTY;
	/** batchSegmentJobMap **/
	private BatchSegmentJobMap batchSegmentJobMap = new BatchSegmentJobMap();

	/** start time when accept queue **/
	private Date enqueuedTime;
	/** 1 batch job when running **/
	/** 2 TMI timeout check start time **/
	private Date startTS;
	/** batch job end time **/
	private Date endTS;

	public long getbJobId() {
		return bJobId;
	}

	public void setBatchJobID(long bJobId) {
		this.bJobId = bJobId;
	}

	public LocalIdentifyBatchJobStatus getBatchJobStatus() {
		return batchJobStatus;
	}

	public void setBatchJobStatus(LocalIdentifyBatchJobStatus batchJobStatus) {
		this.batchJobStatus = batchJobStatus;
	}

	public Date getStartTS() {
		return startTS;
	}

	public void setStartTS(Date startTS) {
		this.startTS = startTS;
	}

	public Date getEndTS() {
		return endTS;
	}

	public void setEndTS(Date endTS) {
		this.endTS = endTS;
	}

	private Map<Integer, LocalIdentifyTopLevelJob> getTopLevelJobMap() {
		return topLevelJobMap;
	}

	public void setTopLevelJobMap(
			Map<Integer, LocalIdentifyTopLevelJob> identifyQueueMap) {
		this.topLevelJobMap = identifyQueueMap;
	}

	public BatchSegmentJobMap getBatchSegmentJobMap() {
		return batchSegmentJobMap;
	}

	public void setBatchSegmentJobMap(BatchSegmentJobMap batchSegmentJobMap) {
		this.batchSegmentJobMap = batchSegmentJobMap;
	}

	public ByteString getSearchJobs() {
		return searchJobs;
	}

	public void setSearchJobs(ByteString searchJobs) {
		this.searchJobs = searchJobs;
	}

	public int getFailureCount() {
		return failureCount;
	}

	public void setFailureCount(int failureCount) {
		this.failureCount = failureCount;
	}

	public int getByURLCount() {
		return byURLCount;
	}

	public void setByURLCount(int byURLCount) {
		this.byURLCount = byURLCount;
	}

	public LocalIdentifyBatchJobType getBatchJobType() {
		return batchJobType;
	}

	public void setBatchJobType(LocalIdentifyBatchJobType batchJobType) {
		this.batchJobType = batchJobType;
	}

	public Date getEnqueuedTime() {
		return enqueuedTime;
	}

	public void setEnqueuedTime(Date enqueuedTime) {
		this.enqueuedTime = enqueuedTime;
	}

	// /////////////////////////////////////////////////////////////////////////
	// /////////////////////////job status manager//////////////////////////////
	// /////////////////////////////////////////////////////////////////////////
	/**
	 * if this batch job status is in READYTO_DELIVERYING then set this batch
	 * job status to RUNNING
	 */
	public void setDeliveredBatchJobStaus() {
		if (this.getBatchJobStatus() == LocalIdentifyBatchJobStatus.READYTO_DELIVERYING) {
			this.setBatchJobStatus(LocalIdentifyBatchJobStatus.RUNNING);
			// this.setBatchJobStartTS(DateUtil.getCurrentDate());
		}
	}

	/**
	 * check Status
	 * 
	 * @return boolean
	 */
	public boolean isStatus(LocalIdentifyBatchJobStatus jobStatus) {
		return getBatchJobStatus() == jobStatus;
	}

	/**
	 * check Status
	 * 
	 * @return boolean
	 */
	public boolean isContainsReferenceURL() {
		return getBatchJobType() == LocalIdentifyBatchJobType.BY_URL_CONTAINS;
	}

	/**
	 * change BatchSegmentJob status and batch job status
	 * 
	 * @param requestSegInfos
	 *            filtered SegInfos
	 * @param muId
	 *            muId
	 */
	public void changeBatchSegmentJobStatusToDelivering(
			List<SegmentVersion> filteredSegmentInfo, long muId) {
		if (log.isDebugEnabled()) {
			log.debug("start function changeBatchSegmentJobStatus()..");
		}

		// if this batch job status is in READYTO_DELIVERYING
		// then set this batch job status to RUNNING
		this.setDeliveredBatchJobStaus();

		// output the info log
		if (log.isInfoEnabled()) {
			BatchJobStatusLogger.outputBatchJobStatus(
					LogConstants.STATUS_CATEGORY_TMI, this.getbJobId(),
					LocalIdentifyBatchJobStatus.RUNNING.name());
		}

		// get BatchSegmentJobMap from batchIdentifyQueue
		BatchSegmentJobMap bsjm = this.getBatchSegmentJobMap();

		// if this batch segment job status is in WAIT then set this batch
		// segment job status to RUNNING
		bsjm.setDeliveredBatchJobMapStaus();

		// set filtered each segment job status to [RUNNING]
		// set mu id and start time
		bsjm.changeBatchSegmentJobsStatusToDelivered(filteredSegmentInfo, muId);

		if (log.isDebugEnabled()) {
			log.debug("end function changeBatchSegmentJobStatus()..");
		}
		return;
	}

	/**
	 * rollbackBatchJobStatus
	 */
	public BatchSegmentJobMap rollbackBatchJobStatus() {
		this.setBatchJobStatus(LocalIdentifyBatchJobStatus.READYTO_DELIVERYING);
		this.getBatchSegmentJobMap().rollbackSegmentJobStatus();
		return this.getBatchSegmentJobMap();
	}

	/**
	 * 
	 * @param uscId
	 * @return
	 */
	public void rollbackBatchJobStatusByUsc(long uscId) {
		// if batchJob status is delivering check
		if (this.getBatchJobStatus() == LocalIdentifyBatchJobStatus.RUNNING) {
			this.getBatchSegmentJobMap().rollbackSegmentJobStatusByUsc(uscId);
		}
	}

	// /////////////////////////////////////////////////////////////////////////
	// /////////////////////////batch job manager///////////////////////////////
	// /////////////////////////////////////////////////////////////////////////
	/**
	 * retry BatchSegmentJob
	 */
	public BatchSegmentJobMap retryBatchSegmentJob(Date bjobstime) {
		// add rerun time
		// re set the batch start time
		this.setStartTS(bjobstime);
		// rollback segmentJobStatus
		BatchSegmentJobMap batchSegmentJobMap = this.getBatchSegmentJobMap();
		batchSegmentJobMap.rollbackSegmentJobStatus();
		return batchSegmentJobMap;
	}

	/**
	 * isOverMaxFailureCount
	 * 
	 * @param maxFailureCount
	 * @return
	 */
	public boolean isOverMaxFailureCount(int maxFailureCount) {
		int failureCount = this.getFailureCount();
		this.setFailureCount(failureCount + 1);
		if (log.isInfoEnabled()) {
			log.info(InfoLogger.infoOutput(
					LogConstants.COMPONENT_JOB_POLL_BEAN_TMI,
					LogConstants.FUNCTION_POLL, "DETAIL",
					LogConstants.DETAIL_BATCH_JOB_ID,
					LogConstants.KEY_VALUE_SEPARATOR,
					String.valueOf(this.getbJobId()),
					LogConstants.LOG_ITEM_SEPARATOR,
					LogConstants.DETAIL_FAILURE_COUNT,
					LogConstants.KEY_VALUE_SEPARATOR,
					String.valueOf(failureCount),
					LogConstants.LOG_ITEM_SEPARATOR,
					LogConstants.DETAIL_RERUN_LIMIT,
					LogConstants.KEY_VALUE_SEPARATOR,
					String.valueOf(maxFailureCount)));
		}

		if (getFailureCount() >= maxFailureCount) {
			return true;
		}
		return false;
	}

	/**
	 * get batch segment job segment map information
	 * 
	 * @return batch segment job segment map information
	 */
	public Collection<SegmentMap> getSegmentMapValues() {
		return this.getBatchSegmentJobMap().getSegmentMaps().values();
	}

	/**
	 * filterBatchSegmentJobStatusAndVersion
	 * 
	 * @param filteredSegmentInfo
	 * @param requestSegInfos
	 */
	public void filterBatchSegmentJobStatusAndVersion(
			List<SegmentVersion> filteredSegmentInfo,
			List<SegmentVersion> requestSegInfos) {
		this.getBatchSegmentJobMap().filter(filteredSegmentInfo,
				requestSegInfos, this.getFailureCount());
	}

	/**
	 * check batch segment job map is empty
	 * 
	 * @return
	 */
	public boolean hasSegmentJobs() {
		BatchSegmentJobMap bsjm = this.getBatchSegmentJobMap();
		return bsjm.hasSegmentJobs();
	}

	/**
	 * check batch identify job is empty
	 * 
	 * @return
	 */
	public boolean hasTopLevelJobs() {
		// get child identify job queue
		Map<Integer, LocalIdentifyTopLevelJob> identifyQueueMap = this
				.getTopLevelJobMap();
		// if has no child job, skip ..
		if (identifyQueueMap == null || identifyQueueMap.isEmpty()) {
			log.warn(
					"batch job id: {} has no child identify job queue, job number: {}.",
					this.getbJobId(), identifyQueueMap.size());
			return false;
		}
		return true;
	}

	/**
	 * if TMA timeout, tma will send the BatchSegmentJobMap to TMI to sync
	 * segmentJob Status
	 * 
	 * @param mapFromAggre
	 */
	public void syncWithAggreSegJobStatus(BatchSegmentJobMap mapFromAggre) {
		// set batch job failure count
		this.setFailureCount(this.getFailureCount() + 1);
		BatchSegmentJobMap bsjm = this.getBatchSegmentJobMap();
		bsjm.syncWithAggregationSegJobStatus(mapFromAggre);
	}

	/**
	 * getTopLevelJobs
	 * 
	 * @return Collection<LocalIdentifyTopLevelJob>
	 */
	public Collection<LocalIdentifyTopLevelJob> getTopLevelJobs() {
		return this.getTopLevelJobMap().values();
	}

	/**
	 * addTopLevelJob
	 * 
	 * @param topLevelJob
	 */
	public void addTopLevelJob(LocalIdentifyTopLevelJob topLevelJob) {
		// get child identify job queue
		Map<Integer, LocalIdentifyTopLevelJob> topLevelJobs = this
				.getTopLevelJobMap();
		synchronized (topLevelJobs) {
			// each batch job has duplicate jobId ,begin from 1
			int jobIndex = topLevelJobs.size()
					+ IdentifyConstants.TOPLEVEL_JOB_START_INDEX;
			topLevelJob.setJobIndex(jobIndex);
			topLevelJobs.put(jobIndex, topLevelJob);
		}
	}

	/**
	 * getTopLevelJobById
	 * 
	 * @return
	 */
	public LocalIdentifyTopLevelJob getTopLevelJobById(Integer jobId) {
		return this.getTopLevelJobMap().get(jobId);
	}

	/**
	 * getTopLevelJobsCount
	 * 
	 * @return
	 */
	public int getTopLevelJobsCount() {
		return this.getTopLevelJobMap().size();
	}

	/**
	 * isStartOrEndTimeNull
	 * 
	 * @return
	 */
	public boolean isStartOrEndTimeNull() {
		return this.getEndTS() == null || this.getStartTS() == null;
	}

}
