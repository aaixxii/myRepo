package jp.co.nec.lsm.tmi.common.util;

import java.util.Date;

import jp.co.nec.lsm.tmi.common.constants.IdentifyConstants;

public class IdentifyBatchJobGetterTimer {

	private static IdentifyBatchJobGetterTimer batchJobGetterTimer;

	private IdentifyBatchJobGetterTimer() {
	}

	public static IdentifyBatchJobGetterTimer getInstance() {
		if (batchJobGetterTimer == null) {
			batchJobGetterTimer = new IdentifyBatchJobGetterTimer();
		}
		return batchJobGetterTimer;
	}

	private Date nextGetJobTime;
	private boolean isOverHighLevelLimit = false;
	private int notCompleteJobs;
	private int intervals = IdentifyConstants.DEFAULT_UNNORMAL_POLL_INTERVALS;
	private boolean isStop = false;
	
	public int getIntervals() {
		return intervals;
	}

	public void setIntervals(int intervals) {
		this.intervals = intervals;
	}

	

	public int getNotCompleteJobs() {
		return notCompleteJobs;
	}

	public void setNotCompleteJobs(int notCompleteJobs) {
		this.notCompleteJobs = notCompleteJobs;
	}

	public boolean isOverHighLevelLimit() {
		return isOverHighLevelLimit;
	}

	public void setOverHighLevelLimit(boolean isOverHighLevelLimit) {
		this.isOverHighLevelLimit = isOverHighLevelLimit;
	}

	public void setNextGetJobTime(Date nextGetJobTime) {
		this.nextGetJobTime = nextGetJobTime;
	}

	public Date getNextGetJobTime() {
		return nextGetJobTime;
	}

	public void setStop(boolean isStop) {
		this.isStop = isStop;
	}

	public boolean isStop() {
		return isStop;
	}
}
