package jp.co.nec.lsm.tmi.exception;

import jp.co.nec.lsm.tm.common.exception.TMRuntimeException;

/**
 * @author liuyq <br>
 */
public class IdentifyRuntimeException extends TMRuntimeException {

	private static final long serialVersionUID = 7157356057817916135L;

	public IdentifyRuntimeException(String message) {
		super(message);
	}

	public IdentifyRuntimeException(String message, Throwable cause) {
		super(message, cause);
	}

	public IdentifyRuntimeException(Throwable cause) {
		super(cause);
	}

}
