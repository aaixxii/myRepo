package jp.co.nec.lsm.tmi.db.dao;

import java.util.Date;
import java.util.List;

import javax.ejb.Local;

import jp.co.nec.lsm.proto.common.CommonProto.ComponentType;
import jp.co.nec.lsm.proto.control.EnterRequestProto.EnterRequest;
import jp.co.nec.lsm.tm.common.constants.MUState;
import jp.co.nec.lsm.tm.db.common.entities.MatchUnitEntity;

/**
 * @author liuyq <br>
 */
@Local
public interface IdentifyMatchUnitDaoLocal {

	public List<MatchUnitEntity> listTimedOutFromHeartbeat(Date minHeartbeat);

	public List<MatchUnitEntity> findMuByTypeAndStatus(ComponentType type,
			MUState state);

	public MatchUnitEntity addOrUpdateUnit(EnterRequest enterRequest);

	public void persitUnitStatusContact(long unitId);
	
	public MatchUnitEntity search(int unitId);

	public boolean isWorkingUnitExist(int unitId);

	public void timeoutMatchUnit(MatchUnitEntity mu);

	public void exitMatchUnit(MatchUnitEntity mu);

}
