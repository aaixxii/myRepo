package jp.co.nec.lsm.tmi.core.jobs;

public class RapidEncoderRequestInfo {
	private int jobIndex;
	private String referenceURL;
	private String mD5CheckSum;

	public int getJobIndex() {
		return jobIndex;
	}

	public void setJobIndex(int jobIndex) {
		this.jobIndex = jobIndex;
	}

	public String getReferenceURL() {
		return referenceURL;
	}

	public void setReferenceURL(String referenceURL) {
		this.referenceURL = referenceURL;
	}

	public String getmD5CheckSum() {
		return mD5CheckSum;
	}

	public void setmD5CheckSum(String mD5CheckSum) {
		this.mD5CheckSum = mD5CheckSum;
	}

}
