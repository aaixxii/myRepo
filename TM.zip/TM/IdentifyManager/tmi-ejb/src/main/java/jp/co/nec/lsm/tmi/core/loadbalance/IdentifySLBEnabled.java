package jp.co.nec.lsm.tmi.core.loadbalance;

/**
 * @author liuyq <br>
 */
public enum IdentifySLBEnabled {
	TRUE,
	FALSE
}
