package jp.co.nec.lsm.tmi.core.clientapi.converter;

import java.util.List;

import jp.co.nec.lsm.tm.common.log.BatchJobStatusLogger;
import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.common.validator.ValidationResult;
import jp.co.nec.lsm.tm.db.identify.entities.IdentifyBatchJobDBStatus;
import jp.co.nec.lsm.tm.db.identify.entities.IdentifyBatchJobDBType;
import jp.co.nec.lsm.tm.db.identify.entities.IdentifyBatchJobQueueEntity;
import jp.co.nec.lsm.tm.db.identify.entities.IdentifyJobQueueEntity;
import jp.co.nec.lsm.tmi.core.jobs.LocalIdentifyBatchJob;
import jp.co.nec.lsm.tmi.core.jobs.LocalIdentifyBatchJobStatus;
import jp.co.nec.lsm.tmi.core.jobs.LocalIdentifyBatchJobType;
import jp.co.nec.lsm.tmi.core.jobs.LocalIdentifyTopLevelJob;
import jp.co.nec.lsm.tmi.core.jobs.TopLevelJobFactory;
import jp.co.nec.lsm.tmi.db.dao.IdentifySystemConfigDaoLocal;
import jp.co.nec.lsm.tmi.sessionbean.para.LocalIdentifyRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acc.proto.protobuf.BusinessMessage.CPBBusinessMessage;

public class TransformerJobQueueConverter {
	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(TransformerJobQueueConverter.class);

	/**
	 * transform from IdentifyRequest To BatchIdentifyQueue
	 * 
	 * @param identifyBatchRequest
	 *            request instance from transformer
	 * @param batchIdentifyQueue
	 *            local queue instance
	 */
	public static void convertToBatchJob(LocalIdentifyRequest identifyRequest,
			LocalIdentifyBatchJob batchJob, ValidationResult validation,
			IdentifySystemConfigDaoLocal identifySystemConfigDao) {
		printLogMessage("start private function convertToBatchJob()..");

		// construct batchJob -> batchId and BatchJobStatus
		long batchJobId = identifyRequest.getBatchJobId();
		batchJob.setBatchJobID(batchJobId);
		batchJob.setBatchJobStatus(LocalIdentifyBatchJobStatus.READYTO_PREPARE_TEMPLATE);
		batchJob.setEnqueuedTime(DateUtil.getCurrentDate());

		if (log.isInfoEnabled()) {
			BatchJobStatusLogger
					.outputBatchJobStatus(
							LogConstants.STATUS_CATEGORY_TMI,
							batchJob.getbJobId(),
							LocalIdentifyBatchJobStatus.READYTO_PREPARE_TEMPLATE
									.name());
		}

		// add top levels job to batchJob
		int hasURLCount = addBatchTopLevelJob(identifyRequest, batchJob,
				validation, identifySystemConfigDao);

		batchJob.setByURLCount(hasURLCount);
		if (hasURLCount > 0) {
			batchJob.setBatchJobType(LocalIdentifyBatchJobType.BY_URL_CONTAINS);
		} else {
			batchJob.setBatchJobType(LocalIdentifyBatchJobType.BY_ID_ONLY);
		}

		if (log.isInfoEnabled()) {
			log.info(InfoLogger.referenceUrlInfoOutput(batchJob
					.getBatchJobType().name(), hasURLCount));
		}

		printLogMessage("end public function delivery()..");

	}

	/**
	 * convertToEntity
	 * 
	 * @param identifyRequest
	 * @param batchJobQueueEntity
	 * @param jobQueueEntities
	 */
	public static void convertToEntity(LocalIdentifyRequest identifyRequest,
			IdentifyBatchJobQueueEntity batchJobQueueEntity,
			List<IdentifyJobQueueEntity> jobQueueEntities,
			IdentifySystemConfigDaoLocal identifySystemConfigDao) {
		printLogMessage("start public function convertToEntity()..");

		long batchJobId = identifyRequest.getBatchJobId();
		batchJobQueueEntity.setBatchjobId(batchJobId);
		batchJobQueueEntity.setBatchjobStatus(IdentifyBatchJobDBStatus.QUEUEED
				.getIntValues());
		batchJobQueueEntity.setEnqueueTs(DateUtil.getCurrentDate());

		int hasURLCount = convertToTopLevelJobEntity(identifyRequest,
				jobQueueEntities, batchJobId, identifySystemConfigDao);
		batchJobQueueEntity.setByURLCount(hasURLCount);
		if (hasURLCount > 0) {
			batchJobQueueEntity
					.setJobType(IdentifyBatchJobDBType.BY_URL_CONTAINS);
		} else {
			batchJobQueueEntity.setJobType(IdentifyBatchJobDBType.BY_ID_ONLY);
		}

		if (log.isInfoEnabled()) {
			log.info(InfoLogger.referenceUrlInfoOutput(batchJobQueueEntity
					.getJobType().name(), hasURLCount));
		}

		printLogMessage("end public function convertToEntity()..");
	}

	/**
	 * convertToTopLevelJobEntity
	 * 
	 * @param identifyRequest
	 * @param jobQueueEntities
	 * @param batchJobId
	 * @return int
	 */
	private static int convertToTopLevelJobEntity(
			LocalIdentifyRequest identifyRequest,
			List<IdentifyJobQueueEntity> jobQueueEntities, long batchJobId,
			IdentifySystemConfigDaoLocal identifySystemConfigDao) {
		int hasURLCount = 0;
		int jobIdIndex = 1;
		List<CPBBusinessMessage> businessMessages = identifyRequest
				.getBusinessMessages();

		for (CPBBusinessMessage businessMessage : businessMessages) {
			// construct entity instance IdentifyJobQueueEntity
			IdentifyJobQueueEntity ijqe = TopLevelJobFactory
					.constructTopLevelJobQueueEntity(batchJobId, jobIdIndex,
							businessMessage, identifySystemConfigDao);
			// if has referenceUrl
			if (ijqe.isUsingReferenceUrl()) {
				hasURLCount++;
			}
			jobQueueEntities.add(ijqe);
			jobIdIndex++;
		}
		return hasURLCount;
	}

	/**
	 * convertToTopLevelJobEntity
	 * 
	 * @param identifyRequest
	 * @param jobQueueEntities
	 * @param batchJobId
	 * @return int
	 */
	private static int addBatchTopLevelJob(
			LocalIdentifyRequest identifyRequest,
			LocalIdentifyBatchJob batchJob, ValidationResult validation,
			IdentifySystemConfigDaoLocal identifySystemConfigDao) {
		int hasURLCount = 0;
		int jobIdIndex = 1;
		long batchJobId = batchJob.getbJobId();
		List<CPBBusinessMessage> businessMessages = identifyRequest
				.getBusinessMessages();
		for (CPBBusinessMessage businessMessage : businessMessages) {
			// construct entity instance IdentifyJobQueueEntity
			LocalIdentifyTopLevelJob topLevelJob = TopLevelJobFactory
					.constructTopLevelJobQueue(batchJobId, jobIdIndex,
							businessMessage, validation,
							identifySystemConfigDao);
			if (!topLevelJob.isToplevelJobError()) {
				// if has referenceUrl
				if (!topLevelJob.getReferenceURL().isEmpty()) {
					hasURLCount++;
				}
			}
			batchJob.addTopLevelJob(topLevelJob);
			jobIdIndex++;
		}
		return hasURLCount;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
