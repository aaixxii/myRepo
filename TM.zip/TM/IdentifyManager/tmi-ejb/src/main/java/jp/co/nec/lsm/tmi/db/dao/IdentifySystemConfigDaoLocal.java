package jp.co.nec.lsm.tmi.db.dao;

import javax.ejb.Local;

import jp.co.nec.lsm.tmi.core.loadbalance.IdentifySLBEnabled;

/**
 * @author liuyq <br>
 */
@Local
public interface IdentifySystemConfigDaoLocal {

	public void writeAllMissingProperties();

	public String getDmDownloadUrl();

	public Long getBatchJobTimeout();

	public Integer getHeartBeatTimeout();

	public Integer getBatchJobReRunLimit();

	public Integer getSendBSJMapRetryIntervals();

	public Integer getSendBSJMapRetryLimit();

	public Integer getDmMinRedundancy();

	public Integer getUscMinRedundancy();

	public Integer getTmiPollingTime();

	public void setSlbStatus(IdentifySLBEnabled enabled);

	public boolean getSlbEnabled();

	public int getMinUscForSlb();

	public int getMinDmForSlb();

	public Integer getRetryMaxCount();

	public Integer getHighLevelIdentifyBatchJobs();

	public Integer getLowLevelIdentifyBatchJobs();

	public Integer getIntervalForIdentifyHighLevel();

	public Integer getIntervalForIdentifyLowLevel();

	public Integer getIntervalForIdentifyNormalLevel();

	public String getBatchJobFromTransformerUrl();

	public String getJobCountToTransformer();

	public String getBatchJobCountToTransformer();

	public Integer getMaxResults();
	
	public String getRapidEncoder();
	
	public String getTurnAroundTime();
	
	public String getTmaReceiverUrl();
	
	public String getTmaIpAddress();
	
	public String getTmiBatchJobReceiverUrl();
	
	public boolean getIdentifyServiceEnabled();
}
