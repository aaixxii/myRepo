package jp.co.nec.lsm.tmi.db.dao;

import java.util.List;

import javax.ejb.Local;

import jp.co.nec.lsm.tm.db.identify.entities.IdentifyBatchJobDBStatus;
import jp.co.nec.lsm.tm.db.identify.entities.IdentifyBatchJobQueueEntity;
import jp.co.nec.lsm.tm.db.identify.entities.IdentifyJobQueueEntity;
import jp.co.nec.lsm.tmi.sessionbean.para.LocalIdentifyRequest;


/**
 * @author liuyq <br>
 */
@Local
public interface IdentifyBatchJobDaoLocal {

	/**
	 * persist BatchJob into dataBase
	 * 
	 * @param identifyBatchRequest
	 */
	public boolean persistBatchJob(LocalIdentifyRequest identifyBatchRequest);

	public List<Long> getAllUndoneIdentifyBatchJobs(
			IdentifyBatchJobDBStatus status);

	public List<IdentifyJobQueueEntity> getAllIdentifyJobs(long batchJobId);

	public void persistBatchJobStatusAndEndTs(long batchJobId,
			IdentifyBatchJobDBStatus status);

	public void persistBatchJobStatusAndStartTS(long batchJobId,
			IdentifyBatchJobDBStatus status);

	IdentifyBatchJobQueueEntity getBatchJobEntitybyId(long batchJobId);

}
