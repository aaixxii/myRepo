package jp.co.nec.lsm.tmi.db.dao;

import java.util.Date;

import javax.annotation.PostConstruct;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import jp.co.nec.lsm.tm.common.constants.TMType;
import jp.co.nec.lsm.tm.common.constants.TmState;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.common.entities.TransactionManagerEntity;
import jp.co.nec.lsm.tm.db.common.entityhelpers.TransactionManagerHelper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author liuyq <br>
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class IdentifyTransactionManagerDao implements
		IdentifyTransactionManagerDaoLocal {

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(IdentifyTransactionManagerDao.class);

	@PersistenceContext(unitName = "tmi-unit")
	private EntityManager manager;
	private TransactionManagerHelper tmiHelper;

	@PostConstruct
	public void init() {
		tmiHelper = new TransactionManagerHelper(manager, TMType.TMI);
	}

	/**
	 * constructor
	 */
	public IdentifyTransactionManagerDao() {
	}

	@Override
	public void setStartupTime() {
		printLogMessage("start public function setStartupTime()..");

		Date now = DateUtil.getCurrentDate();
		TransactionManagerEntity ime = tmiHelper.createOrLookupVersion(now);
		// set start time
		ime.setLastHeartbeatTs(now);
		manager.persist(ime);

		printLogMessage("end public function setStartupTime()..");

	}

	@Override
	public void changeTMIToExit() {
		Date now = DateUtil.getCurrentDate();
		TransactionManagerEntity tmi = tmiHelper.createOrLookupVersion(now);
		tmi.setState(TmState.EXITED);
		tmi.setLastHeartbeatTs(now);
		tmi.setLastPollTs(now);
		manager.merge(tmi);
		manager.flush();
		return;
	}
	
	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
