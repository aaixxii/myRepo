package jp.co.nec.lsm.tmi.core.jobs;

import java.math.BigDecimal;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.tm.common.constants.BusinessMessageConstants;
import jp.co.nec.lsm.tm.common.validator.ValidationResult;
import jp.co.nec.lsm.tm.common.validator.ValidationResultError;
import jp.co.nec.lsm.tm.db.identify.entities.IdentifyJobQueueEntity;
import jp.co.nec.lsm.tmi.common.constants.IdentifyConstants;
import jp.co.nec.lsm.tmi.core.clientapi.converter.IdentifyCoreParameter;
import jp.co.nec.lsm.tmi.core.clientapi.request.validator.IdentifyRequestSpec;
import jp.co.nec.lsm.tmi.db.dao.IdentifySystemConfigDaoLocal;

import org.jboss.util.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acc.proto.protobuf.BusinessMessage.CPBBiometricElement;
import com.acc.proto.protobuf.BusinessMessage.CPBBiometricsData;
import com.acc.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.acc.proto.protobuf.BusinessMessage.CPBRequest;
import com.acc.proto.protobuf.BusinessMessage.E_REQUESET_TYPE;
import com.google.protobuf.ByteString;

/**
 * @author jimy <br>
 */
public class TopLevelJobFactory {
	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(TopLevelJobFactory.class);

	/**
	 * construct LocalIdentifyTopLevelJob using businessMessage
	 * 
	 * @param batchJobId
	 * @param jobIndex
	 * @param businessMessage
	 * @param validation
	 * @param identifySystemConfigDao
	 * @return LocalIdentifyTopLevelJob instance
	 */
	public static LocalIdentifyTopLevelJob constructTopLevelJobQueue(
			long batchJobId, int jobIndex, CPBBusinessMessage businessMessage,
			ValidationResult validation,
			IdentifySystemConfigDaoLocal identifySystemConfigDao) {
		printLogMessage("start private function constructIdentifyLocalQueue()..");

		// LocalIdentifyTopLevelJob instance constructor
		LocalIdentifyTopLevelJob topLevelJob = new LocalIdentifyTopLevelJob();
		topLevelJob.setBatchJobID(batchJobId);
		topLevelJob
				.setIdentifyJobStatus(LocalIdentifyJobStatus.READYTO_PREPARE_TEMPLATE);
		topLevelJob.setJobIndex(jobIndex);
		// has top job level error
		ValidationResultError error = validation.findErrorByjobIndex(jobIndex);

		IdentifyCoreParameter parameter = convertToIdentifyPara(
				businessMessage, identifySystemConfigDao);
		topLevelJob.setMaxCandidates(parameter.getMaxCandidate());
		topLevelJob.setReferenceId(parameter.getReferenceId());
		topLevelJob.setReferenceURL(parameter.getReferenceUrl());
		topLevelJob.setRequestId(parameter.getRequestId());
		topLevelJob.setMD5CheckSum(parameter.getCheckSum());
		topLevelJob.setTopLevelType(parameter.getTopLevelJobType());
		topLevelJob.setBusinessMessage(parameter.getBusinessMessage());
		topLevelJob.setFailureCount(IdentifyConstants.DEFAULT_FAILURE_COUNT);
		topLevelJob.setTemplate(new byte[] {});

		if (error != null) {
			topLevelJob.setErrorCode(error.getErrorCode());
			topLevelJob.setErrorMessage(error.getInvalidReason());
			topLevelJob.setiReturnCode(ReturnCode.JobFailed);
		} else {
			topLevelJob.setErrorCode(IdentifyConstants.SUCCESSFUL_ERROR_CODE);
			topLevelJob.setErrorMessage(Strings.EMPTY);
			topLevelJob.setiReturnCode(ReturnCode.JobSuccess);
		}

		printLogMessage("end private function constructIdentifyLocalQueue()..");
		return topLevelJob;
	}

	/**
	 * convert the entity jobs to local queue <br>
	 * this is batch job recovery operation
	 * 
	 * @param batchJobId
	 * @param jobInfo
	 * @return LocalIdentifyTopLevelJob instance
	 */
	public static LocalIdentifyTopLevelJob constructIdentifyLocalQueue(
			long batchJobId, IdentifyJobQueueEntity jobInfo) {
		printLogMessage("start private function constructIdentifyLocalQueue()..");

		LocalIdentifyTopLevelJob topLevelJob = new LocalIdentifyTopLevelJob();
		topLevelJob.setBatchJobID(batchJobId);
		topLevelJob.setJobIndex((int) jobInfo.getJobIndex());
		topLevelJob
				.setIdentifyJobStatus(LocalIdentifyJobStatus.READYTO_PREPARE_TEMPLATE);
		topLevelJob.setRequestId(jobInfo.getRequestId());
		if (jobInfo.getReferenceId() != null) {
			topLevelJob.setReferenceId(jobInfo.getReferenceId());
			topLevelJob
					.setTopLevelType(TopLevelJobType.IDENTIFY_BY_REFERENCEID);
		}

		if (jobInfo.getReferenceUrl() != null) {
			topLevelJob.setReferenceURL(jobInfo.getReferenceUrl());
			topLevelJob
					.setTopLevelType(TopLevelJobType.IDENTIFY_BY_REFERENCEURL);
		}

		topLevelJob.setMaxCandidates(jobInfo.getMaxCandidates().intValue());

		byte[] request = jobInfo.getRequest();
		if (request == null) {
			log.warn("find jobInfo BusinessMessage null "
					+ "while recovery from database. batch job id: {}, "
					+ "job index: {}.", batchJobId, jobInfo.getJobIndex());
		} else {
			topLevelJob.setBusinessMessage(ByteString.copyFrom(jobInfo
					.getRequest()));
		}

		topLevelJob.setFailureCount(IdentifyConstants.DEFAULT_FAILURE_COUNT);
		topLevelJob.setiReturnCode(ReturnCode.JobSuccess);
		topLevelJob.setErrorCode(IdentifyConstants.SUCCESSFUL_ERROR_CODE);
		topLevelJob.setErrorMessage(Strings.EMPTY);
		topLevelJob.setTemplate(new byte[] {});
		printLogMessage("end private function constructIdentifyLocalQueue()..");
		return topLevelJob;
	}

	/**
	 * construct TopLevelJobQueue Entity
	 * 
	 * @param batchJobId
	 * @param jobIdIndex
	 * @param businessMessage
	 * @param identifySystemConfigDao
	 * @return IdentifyJobQueueEntity instance
	 */
	public static IdentifyJobQueueEntity constructTopLevelJobQueueEntity(
			long batchJobId, long jobIdIndex,
			CPBBusinessMessage businessMessage,
			IdentifySystemConfigDaoLocal identifySystemConfigDao) {
		printLogMessage("start private function constructIdentifyJobQueueEntity()..");

		// database jobQueueEntity constructor
		IdentifyJobQueueEntity ijqe = new IdentifyJobQueueEntity();
		ijqe.setBatchjobId(batchJobId);
		ijqe.setJobIndex(jobIdIndex);

		IdentifyCoreParameter parameter = convertToIdentifyPara(
				businessMessage, identifySystemConfigDao);
		ijqe.setMaxCandidates(new BigDecimal(parameter.getMaxCandidate()));
		ijqe.setReferenceId(parameter.getReferenceId(),
				IdentifyRequestSpec.REFERENCE_ID_LENGTH);
		ijqe.setReferenceUrl(parameter.getReferenceUrl());
		ijqe.setRequestId(parameter.getRequestId(),
				IdentifyRequestSpec.REQUEST_ID_LENGTH);
		ijqe.setMd5CheckSum(parameter.getCheckSum());
		ijqe.setRequest(parameter.getBusinessMessage().toByteArray());

		TopLevelJobType requestType = parameter.getTopLevelJobType();
		if (requestType == TopLevelJobType.IDENTIFY_BY_REFERENCEURL) {
			ijqe.setUsingReferenceUrl(true);
		} else {
			ijqe.setUsingReferenceUrl(false);
		}

		printLogMessage("end private function constructIdentifyJobQueueEntity()..");
		return ijqe;
	}

	/**
	 * convertToIdentifyPara
	 * 
	 * @param businessMessage
	 * @return IdentifyCoreParameter
	 */
	public static IdentifyCoreParameter convertToIdentifyPara(
			CPBBusinessMessage businessMessage,
			IdentifySystemConfigDaoLocal identifySystemConfigDao) {
		CPBBusinessMessage.Builder builder = businessMessage.toBuilder();
		CPBRequest.Builder cpbRequest = builder.getRequestBuilder();
		CPBBiometricsData cpbBiometricsData = cpbRequest.getBiometricsData();
		CPBBiometricElement cpbBiometricElement = cpbBiometricsData
				.getBiometricElement();

		String requestId = cpbRequest.getRequestId();
		String referenceId = cpbRequest.getEnrollmentId();
		String referenceUrl = cpbBiometricElement.getFilePath();
		String checkSum = cpbBiometricElement.getChecksum();

		int maxCandidate = cpbRequest.getMaxResults();
		// if maxCandidate = -1
		if (maxCandidate == BusinessMessageConstants.DEFAULT_MAX_CANDIDATE) {
			maxCandidate = identifySystemConfigDao.getMaxResults();
			cpbRequest.setMaxResults(maxCandidate);
		} else if (maxCandidate <= 0) {
			maxCandidate = BusinessMessageConstants.DEFAULT_MAX_RESULTS_TMA;
			cpbRequest
					.setMaxResults(BusinessMessageConstants.DEFAULT_MAX_RESULTS_USC);
		}

		// TargetFPIR
		int targetFPIR;
		if (cpbRequest.hasTargetFpir()) {
			targetFPIR = cpbRequest.getTargetFpir();
		} else {
			targetFPIR = BusinessMessageConstants.DEFAULT_TARGET_FPIR;
			cpbRequest
					.setTargetFpir(BusinessMessageConstants.DEFAULT_TARGET_FPIR);
		}

		// construct IdentifyCoreParameter
		return buildCoreParameter(cpbRequest, requestId, referenceId,
				referenceUrl, checkSum, maxCandidate, targetFPIR,
				builder.build());
	}

	/**
	 * buildCoreParameter
	 * 
	 * @param cpbRequest
	 * @param referenceId
	 * @param referenceUrl
	 * @param checkSum
	 * @param maxCandidate
	 * @param targetFPIR
	 * @return IdentifyCoreParameter
	 */
	private static IdentifyCoreParameter buildCoreParameter(
			CPBRequest.Builder cpbRequest, String requestId,
			String referenceId, String referenceUrl, String checkSum,
			int maxCandidate, int targetFPIR, CPBBusinessMessage businessMessage) {
		IdentifyCoreParameter para = new IdentifyCoreParameter();
		para.setRequestId(requestId);
		para.setReferenceId(referenceId);
		para.setReferenceUrl(referenceUrl);
		para.setCheckSum(checkSum);
		para.setMaxCandidate(maxCandidate);
		para.setTargetFPIR(targetFPIR);
		para.setBusinessMessage(businessMessage.toByteString());

		E_REQUESET_TYPE requestType = cpbRequest.getRequestType();
		if (requestType == E_REQUESET_TYPE.IDENTIFY_REFID_DEFAULT) {
			para.setTopLevelJobType(TopLevelJobType.IDENTIFY_BY_REFERENCEID);
		} else if (requestType == E_REQUESET_TYPE.IDENTIFY_REFURL_DEFAULT) {
			para.setTopLevelJobType(TopLevelJobType.IDENTIFY_BY_REFERENCEURL);
		} else {
			para.setTopLevelJobType(TopLevelJobType.IDENTIFY_REQUESTTYPE_ERROR);
		}
		return para;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
