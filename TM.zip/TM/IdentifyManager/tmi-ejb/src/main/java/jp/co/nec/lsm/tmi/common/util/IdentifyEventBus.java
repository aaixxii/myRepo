package jp.co.nec.lsm.tmi.common.util;

import jp.co.nec.lsm.event.identify.BatchJobDeliveryCheckPollBeanEvent;
import jp.co.nec.lsm.event.identify.GetBatchJobPollTimerEvent;
import jp.co.nec.lsm.event.identify.IdentifyAbstractEvent;
import jp.co.nec.lsm.event.identify.IdentifyPrepareTemplateEvent;
import jp.co.nec.lsm.event.identify.IdentifyStartJobPollbeanTimerEvent;
import jp.co.nec.lsm.event.identify.IdentifyStartUSCPollbeanTimerEvent;
import jp.co.nec.lsm.event.identify.IdentifyTemplatePreparedEvent;
import jp.co.nec.lsm.event.identify.constants.IdentifyNotifierEnum;
import jp.co.nec.lsm.event.identify.constants.IdentifyReceiverEnum;
import jp.co.nec.lsm.event.identify.notifier.IdentifyNotifier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/****
 * @author dongqk <br>
 *         This class for sent the notice.
 */
public class IdentifyEventBus {
	/** log instance **/
	private static Logger log = LoggerFactory.getLogger(IdentifyEventBus.class);

	/**
	 * 
	 * @param batchJobId
	 */
	public static void notifyPrepareTemplateServiceFromAccpet(long batchJobId) {
		printLogMessage("start public static function notifyPrepareTemplateService..");

		IdentifyNotifier notifier = new IdentifyNotifier();
		IdentifyAbstractEvent event = new IdentifyPrepareTemplateEvent(
				batchJobId, IdentifyNotifierEnum.IdentifyAcceptService,
				IdentifyReceiverEnum.IdentifyPrepareTemplateService);
		notifier.sendEvent(event);

		printLogMessage("end public static function notifyPrepareTemplateService..");
	}

	/**
	 * notify PrepareTemplate event
	 * 
	 * @param batchJobId
	 */
	public static void notifyPrepareSegmentJob(long batchJobId) {
		printLogMessage("start public static function notifyPrepareSegmentJob..");

		IdentifyNotifier notifier = new IdentifyNotifier();
		IdentifyAbstractEvent event = new IdentifyTemplatePreparedEvent(
				batchJobId,
				IdentifyNotifierEnum.IdentifyPrepareTemplateService,
				IdentifyReceiverEnum.IdentifyPrepareSegmentJobService);
		notifier.sendEvent(event);

		printLogMessage("end public static function notifyPrepareSegmentJob..");
	}

	/**
	 * notify notifyPrepareTemplateService event
	 * 
	 * @param batchJobId
	 */
	public static void notifyPrepareTemplateService(long batchJobId) {
		printLogMessage("start public static function notifyPrepareTemplateService..");

		IdentifyNotifier notifier = new IdentifyNotifier();
		IdentifyAbstractEvent event = new IdentifyPrepareTemplateEvent(
				batchJobId, IdentifyNotifierEnum.SystemInitializationBean,
				IdentifyReceiverEnum.IdentifyPrepareTemplateService);
		notifier.sendEvent(event);

		printLogMessage("end public static function notifyPrepareTemplateService..");
	}

	/**
	 * notify pollbean timer event
	 */
	public static void notifyStartJobPollTimerService() {
		printLogMessage("start public static function notifyStartJobPollTimerService..");

		IdentifyNotifier notifier = new IdentifyNotifier();
		IdentifyAbstractEvent event = new IdentifyStartJobPollbeanTimerEvent(
				0L, IdentifyNotifierEnum.SystemInitializationBean,
				IdentifyReceiverEnum.IdentifyJobPollTimerStartBean);
		notifier.sendEvent(event);

		printLogMessage("end public static function notifyStartJobPollTimerService..");
	}

	/**
	 * notify pollbean timer event
	 */
	public static void notifyStartUSCPollTimerService() {
		printLogMessage("start public static function notifyStartUSCPollTimerService..");

		IdentifyNotifier notifier = new IdentifyNotifier();
		IdentifyAbstractEvent event = new IdentifyStartUSCPollbeanTimerEvent(
				0L, IdentifyNotifierEnum.SystemInitializationBean,
				IdentifyReceiverEnum.IdentifyUSCPollTimerStartBean);
		notifier.sendEvent(event);

		printLogMessage("end public static function notifyStartUSCPollTimerService..");
	}

	/**
	 * notify pollbean timer event
	 */
	public static void notifyDeliveryCheckPollTimerService() {
		printLogMessage("start public static function notifyDeliveryCheckPollTimerService..");

		IdentifyNotifier notifier = new IdentifyNotifier();
		IdentifyAbstractEvent event = new BatchJobDeliveryCheckPollBeanEvent(
				0L, IdentifyNotifierEnum.SystemInitializationBean,
				IdentifyReceiverEnum.BatchJobDeliveryCheckPollTimerStarterBean);
		notifier.sendEvent(event);

		printLogMessage("end public static function notifyDeliveryCheckPollTimerService..");
	}

	/**
	 * notify pollbean timer event
	 */
	public static void notifyGetBatchJobPollTimerService() {
		printLogMessage("start public static function notifyGetBatchJobPollTimerService..");

		IdentifyNotifier notifier = new IdentifyNotifier();
		IdentifyAbstractEvent event = new GetBatchJobPollTimerEvent(
				0L, IdentifyNotifierEnum.SystemInitializationBean,
				IdentifyReceiverEnum.GetIdentifyBatchJobPollTimerStarterBean);
		notifier.sendEvent(event);

		printLogMessage("end public static function notifyGetBatchJobPollTimerService..");
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 *            ,logParame
	 * @return
	 */
	private static void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}
}
