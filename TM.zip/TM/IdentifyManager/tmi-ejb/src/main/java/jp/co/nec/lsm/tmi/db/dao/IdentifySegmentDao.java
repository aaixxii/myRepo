package jp.co.nec.lsm.tmi.db.dao;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import jp.co.nec.lsm.tm.db.common.entities.SegmentEntity;
import jp.co.nec.lsm.tm.db.common.entityhelpers.SegmentHelper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author liuyq <br>
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class IdentifySegmentDao implements IdentifySegmentDaoLocal {
	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(IdentifySegmentDao.class);

	/** SegmentHelper instance **/
	private SegmentHelper segmentHelper;
	/** EntityManager instance **/
	@PersistenceContext(unitName = "tmi-unit")
	private EntityManager manager;

	/**
	 * Construct function <br>
	 * 
	 * @param
	 * @return void
	 */
	@PostConstruct
	public void init() {
		segmentHelper = new SegmentHelper(manager);
	}

	/**
	 * constructor
	 */
	public IdentifySegmentDao() {
	}

	@Override
	public List<SegmentEntity> findAllSegmentsInfo() {
		// select segments from Database
		List<SegmentEntity> segMentInfos = segmentHelper
				.getAllSegmentsInfo();
		if (segMentInfos == null || segMentInfos.isEmpty()) {
			log.warn("there is no segment in Database.");
		}
		return segMentInfos;
	}

	@Override
	public List<SegmentEntity> findSegmentsInfoByUnitId(int unitId) {
		// select segments from Database
		List<SegmentEntity> segMentInfos = segmentHelper
				.getSegmentsInfoByUnitId(unitId);
		return segMentInfos;
	}

}
