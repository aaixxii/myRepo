package jp.co.nec.lsm.tmi.core.jobs;

/**
 * @author liuyq <br>
 */
public enum LocalIdentifyJobStatus {
	READYTO_PREPARE_TEMPLATE, 
	TEMPLATE_PREPARING,
	READYTO_PREPARE_SEGMENTJOB,
	SEGMENTJOB_PREPARING,
	READYTO_DELIVERYING,
	INDENTIFYING,
	DONE
}
