package jp.co.nec.lsm.tmi.db.dao;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.lsm.proto.common.CommonProto.ComponentType;
import jp.co.nec.lsm.tm.common.constants.SegAssignmentRank;
import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.db.common.entities.MatchUnitEntity;
import jp.co.nec.lsm.tm.db.common.entities.MuSegmentEntity;
import jp.co.nec.lsm.tm.db.common.entities.SegmentEntity;
import jp.co.nec.lsm.tm.db.common.entityhelpers.MuSegMapHelper;
import jp.co.nec.lsm.tm.db.common.procedure.MuSegmentObject;
import jp.co.nec.lsm.tm.db.common.procedure.MuSegmentUpdateProcedure;
import jp.co.nec.lsm.tm.db.identify.entities.AppointedMuSegmentEntity;
import jp.co.nec.lsm.tm.db.identify.procedure.AppointedMuSegmentUpdateProcedure;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author liuyq <br>
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class IndetifyMuSegmentMapDao implements IndetifyMuSegmentMapDaoLocal {
	@PersistenceContext(unitName = "tmi-unit")
	private EntityManager manager;
	@Resource(mappedName = "java:/OracleDS")
	protected DataSource dataSource;

	private MuSegMapHelper muSegMapHelper;

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(IndetifyMuSegmentMapDao.class);

	@PostConstruct
	public void init() {
		muSegMapHelper = new MuSegMapHelper(manager);
	}

	/**
	 * constructor
	 */
	public IndetifyMuSegmentMapDao() {
	}

	/**
	 * Find MuSegMapEntity of USC
	 * 
	 * @return List of MuSegMapEntity
	 */
	@Override
	public List<MuSegmentEntity> findMuSegMapByUnitType(ComponentType unitType) {
		if (log.isDebugEnabled()) {
			log.debug("start public function findMuSegMapByUnitType()..");
		}
		// Find MuSegMapEntity of unit type
		List<MuSegmentEntity> muSegList = muSegMapHelper
				.findMuSegMapByUnitType(unitType);
		if (log.isDebugEnabled()) {
			log.debug("end public function findMuSegMapByUnitType()..");
		}

		return muSegList;
	}

	/**
	 * Find List of IdentifyUnitEntity(UNIT) which is concerned with MU_SEGMENTS
	 * 
	 * @return List of IdentifyUnitEntity
	 */
	@Override
	public List<MatchUnitEntity> findUnitInMuSegMapByUnitType(
			ComponentType unitType) {
		printLogMessage("start public function findUnitInMuSegMapByUnitType()..");
		// Find List of IdentifyUnitEntity(USC) which is concerned with
		// MU_SEGMENTS
		List<MatchUnitEntity> muList = muSegMapHelper
				.findUnitInMuSegMapByUnitType(unitType);
		printLogMessage("end public function findUnitInMuSegMapByUnitType()..");
		return muList;
	}

	/**
	 * Find List of SegmentEntity which is concerned with MU_SEGMENTS
	 * 
	 * @return List of SegmentEntity
	 */
	@Override
	public List<SegmentEntity> findSegmentsInMuSegMap(ComponentType unitType) {
		printLogMessage("start public function findSegmentsInMuSegMap()..");

		// Find List of SegmentEntity which is concerned with MU_SEGMENTS
		List<SegmentEntity> preSegmentEntities = muSegMapHelper
				.findSegmentsInMuSegMap(unitType);

		printLogMessage("end public function findSegmentsInMuSegMap()..");

		return preSegmentEntities;
	}

	/**
	 * Find MuSegMapEntity of USC
	 * 
	 * @return List of MuSegMapEntity
	 */
	@Override
	public List<AppointedMuSegmentEntity> findPreMuSegMapByUnitTpye(
			ComponentType unitType) {
		printLogMessage("start public function findPreMuSegMapByUnitTpye()..");
		// Find MuSegMapEntity of USC
		List<AppointedMuSegmentEntity> muSegList = muSegMapHelper
				.findPreMuSegMapByType(unitType);
		printLogMessage("end public function findPreMuSegMapByUnitTpye()..");
		return muSegList;
	}

	/**
	 * Find List of IdentifyUnitEntity(USC) which is concerned with MU_SEGMENTS
	 * 
	 * @return List of IdentifyUnitEntity
	 */
	@Override
	public List<MatchUnitEntity> findPreUnitInMuSegMap(ComponentType unitType) {
		printLogMessage("start public function findPreUnitInMuSegMap()..");
		// Find List of IdentifyUnitEntity(USC) which is concerned with
		// MU_SEGMENTS
		List<MatchUnitEntity> muList = muSegMapHelper
				.findPreUnitInMuSegMap(unitType);
		printLogMessage("end public function findPreUnitInMuSegMap()..");
		return muList;
	}

	/**
	 * Find List of SegmentEntity which is concerned with MU_SEGMENTS
	 * 
	 * @return List of SegmentEntity
	 */
	@Override
	public List<SegmentEntity> findPreSegmentsInMuSegMapByUnitType(
			ComponentType unitType) {
		printLogMessage("start public function findPreSegmentsInMuSegMapByUnitType()..");
		// Find List of SegmentEntity which is concerned with MU_SEGMENTS
		List<SegmentEntity> preSegmentEntities = muSegMapHelper
				.findPreSegmentsInMuSegMapByUnitType(unitType);
		printLogMessage("end public function findPreSegmentsInMuSegMapByUnitType()..");
		return preSegmentEntities;
	}

	/**
	 * updata AppointedMuSegment with MuSegment
	 * 
	 * @return
	 */
	@Override
	public void updataAppointedMuSegment() {
		printLogMessage("start public function updataAppointedMuSegment()..");
		if (log.isInfoEnabled()) {
			log.info(InfoLogger.slbInfoOutput(LogConstants.KEY_FUNC,
					LogConstants.FUNCTION_UPDATA_APPOINTED_MUSEGMENT));
		}
		AppointedMuSegmentUpdateProcedure appMuSegmentProcedure = new AppointedMuSegmentUpdateProcedure(
				dataSource);
		appMuSegmentProcedure.execute();
		printLogMessage("end public function updataAppointedMuSegment()..");
	}

	/**
	 * 
	 */
	@Override
	public void clearMuSegmetByUnitType(ComponentType unitType) {
		printLogMessage("start public function clearMuSegment()..");
		muSegMapHelper.clearMuSegmetByUnitType(unitType);
		printLogMessage("end public function clearMuSegment()..");
	}

	/**
	 * update new MU-Segment Maps information into database
	 * 
	 * @param newMatrix
	 *            new MU-Segment Maps(boolean)
	 * @param muEntities
	 *            MU Entities list
	 * @param segmentEntities
	 *            segment Entities list
	 * @param muSegMaps
	 *            MU-Segment Maps list
	 */
	@Override
	public void updateMuSegMap(boolean[][] newMatrix,
			List<MatchUnitEntity> muEntities,
			List<SegmentEntity> segmentEntities,
			List<MuSegmentEntity> muSegMaps, ComponentType unitType) {
		printLogMessage("start public function UpdateMuSegMap()..");

		long muId = 0;
		long segmentId = 0;

		checkParam(newMatrix, muEntities, segmentEntities, muSegMaps);

		List<MuSegmentObject> newMuSegMaps = new ArrayList<MuSegmentObject>();

		// update new MU-Segment Maps information into database
		for (int muIndex = 0; muIndex < muEntities.size(); muIndex++) {
			for (int segIndex = 0; segIndex < segmentEntities.size(); segIndex++) {
				// initiate variable
				muId = muEntities.get(muIndex).getId();
				segmentId = segmentEntities.get(segIndex).getSegmentId();

				// update new MU-Segment Maps information into database
				if (newMatrix[muIndex][segIndex]) {
					MuSegmentObject muSegmentObject = new MuSegmentObject(muId,
							segmentId, SegAssignmentRank.PRIMARY.ordinal(), 1);
					newMuSegMaps.add(muSegmentObject);
				}
			}
		}

		MuSegmentUpdateProcedure muSegmentProcedure = new MuSegmentUpdateProcedure(
				dataSource);
		muSegmentProcedure.execute(newMuSegMaps, unitType.ordinal());

		printLogMessage("end public function UpdateMuSegMap()..");
	}

	/**
	 * 
	 * @param newMatrix
	 * @param muEntities
	 * @param segmentEntities
	 * @param muSegMaps
	 */
	private void checkParam(boolean[][] newMatrix,
			List<MatchUnitEntity> muEntities,
			List<SegmentEntity> segmentEntities, List<MuSegmentEntity> muSegMaps) {
		boolean isVaid = true;
		if (newMatrix == null || muEntities == null || segmentEntities == null
				|| muSegMaps == null) {
			isVaid = false;
		} else if (newMatrix.length == 0
				|| newMatrix.length != muEntities.size()) {
			isVaid = false;
		} else if (newMatrix[0].length == 0
				|| newMatrix[0].length != segmentEntities.size()) {
			isVaid = false;
		}

		if (isVaid == false) {
			throw new IllegalArgumentException(
					"Illegal Argument when call updateMuSegMap().");
		}
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
