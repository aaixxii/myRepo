package jp.co.nec.lsm.tmi.core.jobs;

/**
 * @author liuyq <br>
 */
public enum LocalIdentifyBatchJobStatus {
	READYTO_PREPARE_TEMPLATE,
	TEMPLATE_PREPARING,
	READYTO_PREPARE_SEGMENT_JOB,
	SEGMENT_JOB_PREPARING,
	READYTO_DELIVERYING,
	RUNNING,
	DONE,
	ABORTED
}
