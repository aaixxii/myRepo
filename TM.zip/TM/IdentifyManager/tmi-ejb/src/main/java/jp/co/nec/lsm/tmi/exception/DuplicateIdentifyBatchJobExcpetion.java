package jp.co.nec.lsm.tmi.exception;

/**
 * @author liuyq <br>
 */
public class DuplicateIdentifyBatchJobExcpetion extends
		IdentifyRuntimeException {

	private static final long serialVersionUID = -8841278776671276642L;

	public DuplicateIdentifyBatchJobExcpetion(String message) {
		super(message);
	}

	public DuplicateIdentifyBatchJobExcpetion(String message, Throwable cause) {
		super(message, cause);
	}

	public DuplicateIdentifyBatchJobExcpetion(long batchJobId, Throwable cause) {
		super("batch Job: " + batchJobId + "is existed.", cause);
	}

	public DuplicateIdentifyBatchJobExcpetion(long batchJobId) {
		super("batch Job: " + batchJobId + "is existed.");
	}

	public DuplicateIdentifyBatchJobExcpetion(Throwable cause) {
		super(cause);
	}

}
