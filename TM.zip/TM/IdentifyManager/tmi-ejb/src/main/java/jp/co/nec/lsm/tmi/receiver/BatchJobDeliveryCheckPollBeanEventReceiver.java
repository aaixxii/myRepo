package jp.co.nec.lsm.tmi.receiver;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.MessageListener;

import jp.co.nec.lsm.event.Event;
import jp.co.nec.lsm.event.identify.BatchJobDeliveryCheckPollBeanEvent;
import jp.co.nec.lsm.event.receiver.AbstractEventReceiver;
import jp.co.nec.lsm.tm.common.constants.DeployName;
import jp.co.nec.lsm.tm.common.constants.JNDIConstants;
import jp.co.nec.lsm.tm.common.util.ServiceLocator;
import jp.co.nec.lsm.tmi.sessionbean.api.BatchJobDeliveryCheckPollTimerStarterLocal;
import jp.co.nec.lsm.tmi.timer.BatchJobDeliveryCheckPollTimerStarterBean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author dongqk <br>
 * 
 */
@MessageDriven(activationConfig = {
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
		@ActivationConfigProperty(propertyName = "destination", propertyValue = JNDIConstants.IDENTIFY_QUEUE),
		@ActivationConfigProperty(propertyName = "messageSelector", propertyValue = "messageReceiver = 'BatchJobDeliveryCheckPollTimerStarterBean'") })
public class BatchJobDeliveryCheckPollBeanEventReceiver extends
		AbstractEventReceiver implements MessageListener {

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(BatchJobDeliveryCheckPollBeanEventReceiver.class);

	@Override
	protected void dispatchEvent(Event event) {
		// look up the service session bean
		if (!(event instanceof BatchJobDeliveryCheckPollBeanEvent)) {
			log
					.error("event is not a instance of BatchJobDeliveryCheckPollBeanEvent.");
			return;
		}

		String jndiName = DeployName.IDENTIFY_EARFILE
				+ JNDIConstants.SPLIT
				+ BatchJobDeliveryCheckPollTimerStarterBean.class.getSimpleName()
				+ JNDIConstants.LOCAL;
		BatchJobDeliveryCheckPollTimerStarterLocal timerService = ServiceLocator
				.getLookUpJndiObject(jndiName,
						BatchJobDeliveryCheckPollTimerStarterLocal.class);

		// do service session bean
		timerService.startTimer();
	}
}
