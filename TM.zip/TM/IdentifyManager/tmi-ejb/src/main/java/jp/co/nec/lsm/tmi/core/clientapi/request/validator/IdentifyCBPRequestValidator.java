package jp.co.nec.lsm.tmi.core.clientapi.request.validator;

import java.util.ArrayList;
import java.util.List;

import jp.co.nec.lsm.tm.common.constants.IdentifyErrorMessage;
import jp.co.nec.lsm.tm.common.validator.ValidationResult;
import jp.co.nec.lsm.tm.common.validator.ValidationResultError;
import jp.co.nec.lsm.tmi.sessionbean.para.LocalIdentifyRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acc.proto.protobuf.BusinessMessage.CPBBiometricElement;
import com.acc.proto.protobuf.BusinessMessage.CPBBiometricsData;
import com.acc.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.acc.proto.protobuf.BusinessMessage.CPBRequest;
import com.acc.proto.protobuf.BusinessMessage.E_REQUESET_TYPE;
import com.google.protobuf.InvalidProtocolBufferException;

public class IdentifyCBPRequestValidator {
	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(IdentifyCBPRequestValidator.class);

	/**
	 * 
	 * @param request
	 * @param localIdentifyRequest
	 * @return
	 * @throws InvalidProtocolBufferException
	 */
	public static ValidationResult validateTopLevelJob(
			LocalIdentifyRequest request) throws InvalidProtocolBufferException {
		printLogMessage("start private function validateTopLevelJob()..");

		ValidationResult result = new ValidationResult();
		// batchJobId
		long batchJobId = request.getBatchJobId();

		// topLevelJobs
		List<CPBBusinessMessage> cpbBusinessMessages = request
				.getBusinessMessages();

		List<String> duplicateRequestIDs = new ArrayList<String>();

		int jobIndex = 1;
		for (CPBBusinessMessage businessMessage : cpbBusinessMessages) {
			CPBRequest cpbRequest = businessMessage.getRequest();

			// check Request Id is empty or 36 bytes
			if (validateRequestId(jobIndex, cpbRequest.getRequestId(),
					batchJobId, result)) {
				jobIndex++;
				continue;
			}

			// check Request Id is Duplicate
			if (validateRequestIdDuplicate(jobIndex, cpbRequest.getRequestId(),
					batchJobId, result, duplicateRequestIDs)) {
				jobIndex++;
				continue;
			}

			// check Request type
			if (validateRequestType(jobIndex, cpbRequest, batchJobId, result)) {
				jobIndex++;
				continue;
			}

			// if request type is IDENTIFY_REFID_DEFAULT
			// check Reference Id length(By ReferenceID)
			if (validateRequestTypeReferenceId(cpbRequest, jobIndex,
					batchJobId, result)) {
				jobIndex++;
				continue;
			}

			// if request type is IDENTIFY_REFURL_DEFAULT
			// check Reference Id length(By ReferenceURL)
			if (validateRequestTypeReferenceUrl(cpbRequest, jobIndex,
					batchJobId, result)) {
				jobIndex++;
				continue;
			}

			// check max result is empty or incorrect
			if (validateMaxResults(cpbRequest, jobIndex, batchJobId, result)) {
				jobIndex++;
				continue;
			}

			// check TargetFPIR is exist or not
			if (validateTargetFPIR(cpbRequest, jobIndex, batchJobId, result)) {
				jobIndex++;
				continue;
			}

			jobIndex++;
		}

		printLogMessage("end private function validateTopLevelJob()..");
		return result;
	}

	/**
	 * validateRequestTypeReferenceUrl
	 * 
	 * @return ValidationResultError
	 */
	private static boolean validateRequestTypeReferenceUrl(
			CPBRequest cpbRequest, int jobIndex, long batchJobId,
			ValidationResult result) {
		if (cpbRequest.getRequestType() == E_REQUESET_TYPE.IDENTIFY_REFURL_DEFAULT) {
			CPBBiometricsData cpbBiometricsData = cpbRequest
					.getBiometricsData();
			// check CPBBiometricsData
			if (cpbBiometricsData == null) {
				String errorInfo = "Identify Job ( cpbBiometricsData is null skip.. )";
				log.warn(errorInfo);
				result.addError(constructError(jobIndex, false, errorInfo,
						IdentifyErrorMessage.CPBBIOMETRICSDATA_INCORRECT
								.getErrorCode()));
				return true;
			}

			CPBBiometricElement cpbBiometricElement = cpbBiometricsData
					.getBiometricElement();
			// check CPBBiometricsData
			if (cpbBiometricElement == null) {
				String errorInfo = "Identify Job ( cpbBiometricElement is null skip.. )";
				log.warn(errorInfo);
				result.addError(constructError(jobIndex, false, errorInfo,
						IdentifyErrorMessage.CPBBIOMETRICSELEMENT_INCORRECT
								.getErrorCode()));
				return true;
			}

			String filepath = cpbBiometricElement.getFilePath();
			if (filepath.isEmpty()) {
				String errorInfo = "Identify Job ( filepath is empty. )";
				log.error(errorInfo);
				result.addError(constructError(jobIndex, false, errorInfo,
						IdentifyErrorMessage.FILEPATH_EMPTY.getErrorCode()));
				return true;
			}
		}
		return false;
	}

	/**
	 * validateMaxResults
	 * 
	 * @return
	 */
	private static boolean validateMaxResults(CPBRequest cpbRequest,
			int jobIndex, long batchJobId, ValidationResult result) {
		// check max candidate exist
		if (!cpbRequest.hasMaxResults()) {
			String errorInfo = "Identify Job ( max results is not exist.. )";
			log.error(errorInfo);
			result.addError(constructError(jobIndex, false, errorInfo,
					IdentifyErrorMessage.MAX_RESULTS_NOT_EXIST.getErrorCode()));
			return true;
		}

		int maxResults = cpbRequest.getMaxResults();
		if (maxResults <= 0 && maxResults != -1) {
			String errorInfo = "Identify Job ( max results = " + maxResults
					+ " is incorrect. )";
			log.error(errorInfo);
			result.addError(constructError(jobIndex, false, errorInfo,
					IdentifyErrorMessage.MAX_RESULTS_INCORRECT.getErrorCode()));
			return true;
		}
		return false;
	}

	/**
	 * validateMaxResults
	 * 
	 * @return
	 */
	private static boolean validateTargetFPIR(CPBRequest cpbRequest,
			int jobIndex, long batchJobId, ValidationResult result) {
		// check TargetFpir
		if (!cpbRequest.hasTargetFpir()) {
			String errorInfo = "Identify Job ( TargetFPIR is not exist.. )";
			log.error(errorInfo);
			result.addError(constructError(jobIndex, false, errorInfo,
					IdentifyErrorMessage.TARGETFPIR_NOT_EXIST.getErrorCode()));
			return true;
		}
		return false;
	}

	/**
	 * 
	 * @param jobIndex
	 * @param cpbRequest
	 * @param batchJobId
	 * @return
	 */
	private static boolean validateRequestType(int jobIndex,
			CPBRequest cpbRequest, long batchJobId, ValidationResult result) {
		E_REQUESET_TYPE requestType = cpbRequest.getRequestType();
		if (!(requestType == E_REQUESET_TYPE.IDENTIFY_REFID_DEFAULT || requestType == E_REQUESET_TYPE.IDENTIFY_REFURL_DEFAULT)) {
			String errorInfo = "Identify Job ( request type is not "
					+ "in IDENTIFY_REFID_DEFAULT"
					+ " or IDENTIFY_REFURL_DEFAULT )";
			log.error(errorInfo);
			result.addError(constructError(jobIndex, false, errorInfo,
					IdentifyErrorMessage.REQUEST_TYPE_INCORRECT.getErrorCode()));
			return true;
		}
		return false;
	}

	/**
	 * validateRequestIdIsNullOrEmpty
	 * 
	 * @return ValidationResultError
	 */
	private static boolean validateRequestId(int jobIndex, String requestId,
			long batchJobId, ValidationResult result) {
		if (requestId == null || requestId.isEmpty()) {
			String errorInfo = "Identify Job ( one searchJob of IdentifyRequest "
					+ "has no Request Id )";
			log.error(errorInfo);
			result.addError(constructError(jobIndex, false, errorInfo,
					IdentifyErrorMessage.REQUESTID_LENGTH_INCORRECT
							.getErrorCode()));
			return true;
		} else {
			// check length of Request Id
			if (IdentifyRequestSpec.REQUEST_ID_LENGTH != requestId.length()) {
				String errorInfo = "Identify Job ( Request Id :"
						+ requestId + " 's length is :" + requestId.length()
						+ " not enough 36 Byte )";
				log.error(errorInfo);
				result.addError(constructError(jobIndex, false, errorInfo,
						IdentifyErrorMessage.REQUESTID_LENGTH_INCORRECT
								.getErrorCode()));
				return true;
			}
		}
		return false;
	}

	/**
	 * validateRequestIdDuplicate
	 * 
	 * @param jobIndex
	 * @param requestId
	 * @param batchJobId
	 * @param result
	 * @param duplicateRequestIDs
	 * @return
	 */
	private static boolean validateRequestIdDuplicate(int jobIndex,
			String requestId, long batchJobId, ValidationResult result,
			List<String> duplicateRequestIDs) {
		if (duplicateRequestIDs.contains(requestId)) {
			String errorInfo = "Identify Job ( RequestId Duplicate, RequestId:"
					+ requestId + " )";
			log.error(errorInfo);
			result.addError(constructError(jobIndex, false, errorInfo,
					IdentifyErrorMessage.REQUESTID_DUPLICATE.getErrorCode()));
			duplicateRequestIDs.add(requestId);
			return true;
		}
		duplicateRequestIDs.add(requestId);

		return false;
	}

	/**
	 * validateRequestTypeReferenceId
	 * 
	 * @return ValidationResultError
	 */
	private static boolean validateRequestTypeReferenceId(
			CPBRequest cpbRequest, int jobIndex, long batchJobId,
			ValidationResult result) {
		if (cpbRequest.getRequestType() == E_REQUESET_TYPE.IDENTIFY_REFID_DEFAULT) {
			String referenceId = cpbRequest.getEnrollmentId();
			if (IdentifyRequestSpec.REFERENCE_ID_LENGTH != referenceId.length()) {
				String errorInfo = "Identify Job (  Reference Id :"
						+ referenceId + " 's length is :"
						+ referenceId.length() + " not enough 36 Byte ) ";
				log.error(errorInfo);
				result.addError(constructError(jobIndex, false, errorInfo,
						IdentifyErrorMessage.REFERENCEID_LENGTH_INCORRECT
								.getErrorCode()));
				return true;
			}
		}
		return false;
	}

	/**
	 * constructError
	 * 
	 * @param jobIndex
	 * @param valid
	 * @param invalidReason
	 * @param errorCode
	 * @return
	 */
	private static ValidationResultError constructError(int jobIndex,
			boolean valid, String invalidReason, String errorCode) {
		ValidationResultError error = new ValidationResultError();
		error.setJobIndex(jobIndex);
		error.setValid(valid);
		error.setErrorCode(errorCode);
		error.setInvalidReason(invalidReason);
		return error;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
