package jp.co.nec.lsm.tmi.sessionbean.api;

import javax.ejb.Local;

/**
 * @author liuyq <br>
 */
@Local
public interface IdentifyPrepareTemplateServiceLocal {
	public void prepareTemplateMain(long batchJobId);
}
