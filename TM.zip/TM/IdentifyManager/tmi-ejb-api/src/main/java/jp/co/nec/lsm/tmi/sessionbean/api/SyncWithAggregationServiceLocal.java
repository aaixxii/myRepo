package jp.co.nec.lsm.tmi.sessionbean.api;

import javax.ejb.Local;

import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;

/**
 * @author liuyq <br>
 */
@Local
public interface SyncWithAggregationServiceLocal {
	public void syncWithAggregation(BatchSegmentJobMap bsjm);
}
