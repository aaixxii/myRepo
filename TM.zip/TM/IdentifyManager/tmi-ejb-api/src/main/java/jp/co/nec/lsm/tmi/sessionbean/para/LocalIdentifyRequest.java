package jp.co.nec.lsm.tmi.sessionbean.para;

import java.util.ArrayList;
import java.util.List;

import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;

import com.acc.proto.protobuf.BusinessMessage.CPBBusinessMessage;

public class LocalIdentifyRequest {
	public long getBatchJobId() {
		return batchJobId;
	}

	public void setBatchJobId(long batchJobId) {
		this.batchJobId = batchJobId;
	}

	public BatchType getType() {
		return type;
	}

	public void setType(BatchType type) {
		this.type = type;
	}

	public List<CPBBusinessMessage> getBusinessMessages() {
		return businessMessages;
	}

	public void setBusinessMessages(List<CPBBusinessMessage> businessMessages) {
		this.businessMessages = businessMessages;
	}

	private long batchJobId;
	private BatchType type;
	private List<CPBBusinessMessage> businessMessages = new ArrayList<CPBBusinessMessage>();

}
