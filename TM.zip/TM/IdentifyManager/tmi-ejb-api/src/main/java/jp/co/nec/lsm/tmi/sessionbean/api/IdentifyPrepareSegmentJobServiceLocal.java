package jp.co.nec.lsm.tmi.sessionbean.api;

import javax.ejb.Local;

/**
 * @author liuyq <br>
 */
@Local
public interface IdentifyPrepareSegmentJobServiceLocal {
	public void prepareSegmentJob(long batchJobId);
}
