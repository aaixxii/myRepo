package jp.co.nec.lsm.tmi.sessionbean.api;

/**
 * @author dongqk <br>
 * 
 */
public interface BatchJobDeliveryCheckPollTimerStarterLocal {
	public void startTimer();
}
