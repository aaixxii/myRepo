package jp.co.nec.lsm.tmi.sessionbean.api;

import javax.ejb.Local;

import jp.co.nec.lsm.tmi.sessionbean.para.LocalIdentifyRequest;


/**
 * @author liuyq <br>
 */
@Local
public interface IdentifyAccpetServiceLocal {

	public void doAccept(LocalIdentifyRequest identifyBatchRequest);

}
