package jp.co.nec.lsm.tmi.sessionbean.api;
/**
 * @author liuyq <br>
 */
public interface IdentifyJobPollTimerStarterLocal {
	public void startTimer();
}
