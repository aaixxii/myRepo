package jp.co.nec.lsm.tmi.sessionbean.api;

public interface GetIdentifyBatchJobPollTimerStarterLocal {
	public void startTimer();
}
