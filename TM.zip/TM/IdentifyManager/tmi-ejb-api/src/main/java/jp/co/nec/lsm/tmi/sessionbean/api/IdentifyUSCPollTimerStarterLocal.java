package jp.co.nec.lsm.tmi.sessionbean.api;

public interface IdentifyUSCPollTimerStarterLocal {
	public void startTimer();
}
