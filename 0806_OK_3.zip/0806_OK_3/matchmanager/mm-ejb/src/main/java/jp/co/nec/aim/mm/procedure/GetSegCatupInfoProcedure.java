package jp.co.nec.aim.mm.procedure;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import jp.co.nec.aim.mm.exception.AimRuntimeException;
import jp.co.nec.aim.mm.segment.sync.CatchUpInfo;
import jp.co.nec.aim.mm.segment.sync.SegDiffPara;
import jp.co.nec.aim.mm.util.CollectionsUtil;

/**
 * Get the segment template history that version between <br>
 * latest and report version (batch fetch with MULTIP-SEGMENT ID)
 * 
 * @author liuyq
 * 
 */
public class GetSegCatupInfoProcedure extends StoredProcedure {
	private JdbcTemplate jdbcTemplate;
	/** SQL **/
	private static final String SQL = "get_seg_catchup_info";
	private List<SegDiffPara> segDiffParas = Lists.newArrayList(); 
	private int unitType;	

	/**
	 * GetSegCatupInfoProcedure constructor
	 * 
	 * @param dataSource
	 *            DataSource instance
	 */
	public GetSegCatupInfoProcedure(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
		setDataSource(dataSource);
		setSql(SQL);
		declareParameter(new SqlParameter("p_component_type", Types.INTEGER));
		declareParameter(new SqlParameter("diff_tab", Types.VARCHAR));
		declareParameter(new SqlOutParameter("tab_name", Types.VARCHAR));
		compile();
	}
	
	public List<CatchUpInfo> execute() {
		if (CollectionsUtil.isEmpty(segDiffParas)) {
			throw new AimRuntimeException("segDiffParas is null or empty"
					+ " when call GetSegCatupInfoProcedure");
		}
		jdbcTemplate.execute("DROP TEMPORARY TABLE IF EXISTS seg_diff_tab");
		String tabSql =	"CREATE TEMPORARY TABLE seg_diff_tab ("
			      + "seg_id BIGINT(38),"
			      + "report_ver BIGINT(38),"
			      + "last_ver BIGINT(38)"
				  +  ") ENGINE = InnoDB";
		jdbcTemplate.execute(tabSql);
		 String doSql = "insert into seg_diff_tab(seg_id,report_ver,last_ver) values(?,?,?)";		
		 segDiffParas.forEach(one -> {		
			 jdbcTemplate.update(doSql, new Object[] {one.getSegmentId(),one.getReportVersion(),one.getLatestVersion() });
		 });
		 jdbcTemplate.execute("commit");

		final Map<String, Object> map = Maps.newHashMap();
		map.put("p_component_type", getUnitType());
		map.put("diff_tab", "seg_diff_tab");
		Map<String, Object> resultMap = execute(map);
		String tableName = (String) resultMap.get("tab_name");
		if (StringUtils.isBlank(tableName)) return null;			
		String sql = "select * from " + tableName;
		final List<Map<String, Object>> result = jdbcTemplate.queryForList(sql);
		final List<CatchUpInfo> catchUpList = new ArrayList<>();
		for (int i = 0; i < result.size(); i++) {
			CatchUpInfo cf = new CatchUpInfo();
			try {
				Map<String, Object> one = result.get(i);
				Long segId = (Long) one.get("segmentId");
				Long biometrocsId = (Long) one.get("biometrocsId");
				Long segVer = (Long) one.get("segVer");
				Integer changType = (Integer) one.get("changType");
				if (!Objects.isNull(one.get("bioData"))) {
					byte[] bioData = (byte[]) one.get("bioData");
					cf.setBytes(bioData);
				}
				if (!Objects.isNull(one.get("eventId"))) {
					Integer evnetId = (Integer) one.get("eventId");
					cf.setEventId(evnetId);
				}
				String extId = (String) one.get("extId");				
				cf.setSegmentId(segId);
				cf.setTemplateId(biometrocsId);
				cf.setVersion(segVer);
				cf.setCommand(changType);
				cf.setExternalId(extId);				
				catchUpList.add(cf);
			} catch (Exception e) {
			}
		}		
		return catchUpList;
	}

	/**
	 * getSegDiffParas
	 * 
	 * @return SegDiffPara list
	 */
	public List<SegDiffPara> getSegDiffParas() {
		return segDiffParas;
	}	

	public int getUnitType() {
		return unitType;
	}

	public void setUnitType(int unitType) {
		this.unitType = unitType;
	}		


	/**
	 * CursorMapper
	 * 
	 * @author liuyq
	 * 
	 */
	@SuppressWarnings("unused")
	private class CursorMapper implements RowMapper<CatchUpInfo> {
		@Override
		public CatchUpInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
			final CatchUpInfo catchup = new CatchUpInfo();
			long segId = rs.getLong("SEGMENT_ID");
			if (segId <= 0) {
				return null;
			}
			long templateId = rs.getLong("BIOMETRICS_ID");
			long version = rs.getLong("SEGMENT_VERSION");
			int type = rs.getInt("CHANGE_TYPE");
			byte[] templateBytes = rs.getBytes("BIOMETRIC_DATA");
			String externalId = rs.getString("EXTERNAL_ID");
			int eventId = rs.getInt("EVENT_ID");

			catchup.setEventId(eventId);
			catchup.setSegmentId(segId);
			catchup.setTemplateId(templateId);
			catchup.setVersion(version);
			catchup.setCommand(type);
			catchup.setBytes(templateBytes);
			catchup.setExternalId(externalId);
			return catchup;
		}
	}
}
