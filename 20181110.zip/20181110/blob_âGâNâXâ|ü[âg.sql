--------------------------------------------------------
--  �t�@�C�����쐬���܂��� - �y�j��-11��-10-2018   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Function SAVE_BLOB
--------------------------------------------------------

  CREATE OR REPLACE EDITIONABLE FUNCTION "XMPERF"."SAVE_BLOB" 
(
  FULL_PATH IN VARCHAR2 
, file_name IN VARCHAR2 
, biometric_id IN VARCHAR2
) RETURN VARCHAR2
 AUTHID CURRENT_USER IS 
   l_file      UTL_FILE.FILE_TYPE;
   l_buffer    RAW(32767);
   l_amount    BINARY_INTEGER := 32767;
   l_pos       INTEGER := 1;
   l_blob      BLOB;
   l_blob_len  INTEGER; 
   l_sql       VARCHAR2(50);
   
BEGIN 
   l_sql := 'CREATE OR REPLACE DIRECTORY BLOBS AS FULL_PATH';
    execute immediate l_sql;
     l_sql := 'GRANT READ, WRITE ON DIRECTORY BLOBS TO FULL_PATH';
      execute immediate l_sql;
   SELECT TEMPLATE_DATA into l_blob FROM BIO_TEMPLATE_DATA_INFO WHERE TEMPLATE_DATA_ID= biometric_id; 
   l_blob_len := DBMS_LOB.getlength(l_blob);
   l_file := UTL_FILE.fopen('BLOBS', FULL_PATH, 'wb', l_amount);
    WHILE l_pos <= l_blob_len LOOP
      DBMS_LOB.read(l_blob, l_amount, l_pos, l_buffer);
      UTL_FILE.put_raw(l_file, l_buffer, TRUE);
      l_pos := l_pos + l_amount;
    END LOOP; 
    UTL_FILE.fclose(l_file);
    EXCEPTION
      WHEN OTHERS THEN   
        IF UTL_FILE.is_open(l_file) THEN
           UTL_FILE.fclose(l_file);
        END IF;
        RETURN 'Faild'; 
  RETURN 'Sucessed';
END SAVE_BLOB;

/
