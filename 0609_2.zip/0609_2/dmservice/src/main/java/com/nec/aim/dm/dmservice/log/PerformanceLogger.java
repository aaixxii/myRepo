package com.nec.aim.dm.dmservice.log;



import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PerformanceLogger {
	//private static Logger log = LoggerFactory.getLogger("PerformanceLogger");

	// Basic Items
	private static final String KEY_VALUE_SEPARATOR = "===";
	private static final String LOG_ITEM_SEPARATOR = "<>";

	// Key-Values
	private static final String KEY_FORMAT = "FORMAT";
	private static final String KEY_CATEGORY = "CATEGORY";
	private static final String KEY_COMPONENT = "COMPONENT";
	private static final String KEY_FUNCTION = "FUNC";
	private static final String JOB_ID = "JOBID";
	private static final String  REQUST_ID= "requestId";
	private static final String PRIORITY = "priority";
	private static final String KEY_CLASS = "CLASS";
	private static final String KEY_ELAPSED_TIME = "ELAPSED_TIME";	

	private static final String VALUE_FORMAT = "NSV";
	private static final String VALUE_CATEGORY = "PERF";

	private PerformanceLogger() {
	}	
	

	public static final void trace( String functionName, String segmentId, String bioId, long elapsedTime) {
		// Don't throw exception because logger must not affect application
		// behavior	
		if (functionName == null) {
			return;
		}

		String performanceLogMessage = buildPerformanceLog("DmService", functionName, String.valueOf(segmentId), String.valueOf(bioId), elapsedTime);

		if (log.isTraceEnabled()) {
			log.trace(performanceLogMessage);
		}
	}

	private static final String buildPerformanceLog(String componentName, String functionName, 
			String segmentId, String bioId,  long elapsedTime) {
		StringBuilder logMessage = new StringBuilder();

		appendKeyAndValue(logMessage, KEY_FORMAT, VALUE_FORMAT);
		appendLogItemSeparator(logMessage);

		appendKeyAndValue(logMessage, KEY_CATEGORY, VALUE_CATEGORY);
		appendLogItemSeparator(logMessage);

		appendKeyAndValue(logMessage, KEY_COMPONENT, componentName);
		appendLogItemSeparator(logMessage);

		appendKeyAndValue(logMessage, KEY_FUNCTION, functionName);
		appendLogItemSeparator(logMessage);
		
		if (segmentId != null) {
			appendKeyAndValue(logMessage, JOB_ID, segmentId);
			appendLogItemSeparator(logMessage);	
		}
		
		if (bioId != null) {
			appendKeyAndValue(logMessage, REQUST_ID, bioId);
			appendLogItemSeparator(logMessage);	
		}
		
		appendKeyAndValue(logMessage, KEY_ELAPSED_TIME, new Long(elapsedTime).toString());
		String performanceLogMessage = logMessage.toString();
		return performanceLogMessage;
	}

	private static final void appendKeyAndValue(StringBuilder logMessage, String key, String value) {
		logMessage.append(key);
		logMessage.append(KEY_VALUE_SEPARATOR);
		logMessage.append(value);
	}

	private static final void appendLogItemSeparator(StringBuilder logMessage) {
		logMessage.append(LOG_ITEM_SEPARATOR);
	}
}
