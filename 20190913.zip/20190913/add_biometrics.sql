CREATE DEFINER=`aimuser`@`%` PROCEDURE `add_biometrics`(
	IN p_external_id  varchar(64),
	IN p_event_id  int,
    IN  p_container_id  int,
	IN p_biometric_data   MEDIUMBLOB,
    OUT p_seg_id  int,
    OUT p_seg_version int,
	OUT p_biometric_id int,
    out p_seg_created int
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
    declare l_seg_created int;
	declare l_biometrics_id int;
    declare l_data_len int;
    declare tmp_container_id int;
     declare tmp_max_segment_size long;
     declare tmp_binary_length_uncompacted long;
     declare iserted_count int;
     declare ftech_last_seg_rec_cut int;
     DECLARE t_error INTEGER DEFAULT 0; 
     DECLARE not_found INTEGER DEFAULT 0; 
     declare cur cursor for select * from ctain_id_max_seg_size for update;
      declare cur1 cursor for select * from last_seg_rec for update;
     DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;  
      DECLARE CONTINUE HANDLER FOR NOT FOUND SET not_found=1;  
	 DROP TEMPORARY TABLE IF EXISTS ctain_id_max_seg_size;
	create temporary table ctain_id_max_seg_size(container_id int,max_segment_size long) engine=memory; 
	DROP TEMPORARY TABLE IF EXISTS last_seg_rec;
	create temporary table last_seg_rec(binary_length_uncompacted long) engine=memory; 
    call  check_container(p_container_id);
   SELECT OCTET_LENGTH(p_biometric_data) into l_data_len from dual;
   insert into ctain_id_max_seg_size(container_id, max_segment_size) values (
       (SELECT container_id, max_segment_size FROM CONTAINERS c WHERE c.CONTAINER_ID = p_container_id)  
    );
    
INSERT INTO PERSON_BIOMETRICS
            (CONTAINER_ID,
             EXTERNAL_ID,
             BIOMETRIC_DATA,
             BIOMETRIC_DATA_LEN,
             REGISTED_TS,
             EVENT_ID)
VALUES      ( P_CONTAINER_ID,
              P_EXTERNAL_ID,
              P_BIOMETRIC_DATA,
              L_DATA_LEN,
              Get_epoch_time_num(),--systimestamp,
              P_EVENT_ID ); 
        select max(biometrics_id) into  p_biometric_id from person_biometrics;
        open cur;
         lable_loop: loop
           FETCH cur INTO  tmp_container_id, tmp_max_segment_size;
             insert into last_seg_rec values (
				(SELECT  s. binary_length_uncompacted
			    FROM  segments s
                WHERE s.CONTAINER_ID = tmp_container_id
                    AND  s.segment_id IN
                         ( SELECT MAX(s2.segment_id)
                              FROM segments s2
                         WHERE s2.CONTAINER_ID = tmp_container_id))             
             );
             SELECT ROW_COUNT() into iserted_count;
             if iserted_count > 0 then
                open cur1;
                loop
                  fetch cur1 into tmp_binary_length_uncompacted;
                   SELECT ROW_COUNT() into ftech_last_seg_rec_cut;
                   if ftech_last_seg_rec_cut > 0 then
                         IF tmp_binary_length_uncompacted + l_data_len + 54 < tmp_max_segment_size  THEN 						
                           set  l_seg_created = update_existing_segment(tmp_binary_length_uncompacted, l_data_len);
						 ELSE 
                           set  l_seg_created := create_new_segment(tmp_container_id, l_biometrics_id, l_data_len);
						 END IF; 
					else 
                      set l_seg_created = create_new_segment(tmp_container_id, l_biometrics_id, l_data_len);
                    end if;
				 end loop;
                 close cur1;			
             end if;           
		end loop;
        close cur;
        set p_seg_created =l_seg_created;
     if t_error=1 then
        rollback;
         set p_seg_created = -1;
		  set p_seg_id= -1;
          set p_seg_version= -1;
	      set p_biometric_id= -1;
          set  p_seg_created = -1;
	 else 
	   commit;
	 end if;  
END