CREATE DEFINER=`aimuser`@`%` PROCEDURE `check_container_formats_new`(
     in p_function_id int,
     in  p_candidate_containers VARCHAR(1024),
     out result varchar(1024)
)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
my_label:BEGIN
    -- p_candidate_containers="1,2,3,321,322,323"； 
      declare tmp_count int;
      DECLARE l_actual_format_name VARCHAR(255);
      DECLARE l_target_format_name VARCHAR(255);
      DECLARE l_target_format_id int;
       DECLARE l_length int;
      DECLARE l_function_name VARCHAR(20);
      declare v_idx int default 999 ;
      declare v_tmp_str varchar(20);
	  DECLARE t_error INTEGER DEFAULT 0;      
	  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;
	  DROP TEMPORARY TABLE IF EXISTS arr_container_ids;
      create temporary table arr_container_ids(id int) engine=memory; 
		while v_idx > 0 do
          SET v_idx = INSTR(p_candidate_containers,',');
          SET v_tmp_str = substr(p_candidate_containers,1,v_idx-1);    
          insert into arr_container_ids (id)  values( CAST(v_tmp_str AS UNSIGNED));
          set p_candidate_containers=substr(p_candidate_containers,v_idx +1 ,LENGTH(p_candidate_containers)); 
          if v_idx +1 = LENGTH(p_candidate_containers) then
           insert into arr_container_ids (id)  values( CAST(p_candidate_containers AS UNSIGNED));
          end if;         
      end while;  
      select count(id) into l_length from arr_container_ids;

		select count(*) into tmp_count from  (select c.CONTAINER_ID
        from CONTAINERS c
        where c.CONTAINER_ID in (select id from arr_container_ids)) AS q1;
        if tmp_count != l_length then
         set result = 'containerId miss match!';
         leave my_label;
        end if;    
        
        set tmp_count = 0;
       	select count(*) into tmp_count from (select c.CONTAINER_ID,c.FORMAT_ID 
        from CONTAINERS c ,  FUNCTION_TYPES f  
	    where c.FORMAT_ID = f.TARGET_FORMAT_ID
        and c.FORMAT_ID is not null
        and f.TARGET_FORMAT_ID is not null
        and c.CONTAINER_ID in (select id from arr_container_ids)) as q2 ;
		if tmp_count != l_length then
         set result = 'FORMAT_ID miss match';
         leave my_label;
        end if;
        
         set tmp_count = 0;
		select count(*) into tmp_count from (select c.CONTAINER_ID,c.FORMAT_ID 
        from CONTAINERS c ,  FORMAT_TYPES f  
	    where c.FORMAT_ID = f.FORMAT_ID
        and c.FORMAT_ID is not null
        and f.FORMAT_ID is not null
        and c.CONTAINER_ID in (select id from arr_container_ids)) as q3; 
		if tmp_count != l_length then
         set result = 'FORMAT_ID miss match';
         leave my_label;
        end if;        
        
  		select count(*)  from         
		(SELECT  f.TARGET_FORMAT_ID, f.FUNCTION_NAME	
        FROM FUNCTION_TYPES f
        WHERE f.function_id = p_function_id) as q4;
        if tmp_count < 1 then 
          set result = 'function name miss match';
           leave my_label;
		end if;
        
	   set tmp_count = 0;      
		select count(*) into tmp_count from (select c.CONTAINER_NAME
        from CONTAINERS c ,  FORMAT_TYPES f  
	    where c.FORMAT_ID = f.FORMAT_ID     
        and c.CONTAINER_ID in (select id from arr_container_ids) 
        and EXISTS (select fy.FORMAT_NAME from FORMAT_TYPES fy where fy.FORMAT_ID =c.FORMAT_ID)) as q5;        
		if tmp_count != l_length then 
          set result = 'format name miss match';
           leave my_label;
		end if;	
          select "OK" into  result;
END