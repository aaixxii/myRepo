package com.nec.aim.dm.dmservice.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.nec.aim.dm.dmservice.dispatch.Dispatcher;
import com.nec.aim.dm.dmservice.dispatch.StopWatch;
import com.nec.aim.dm.dmservice.entity.NodeStorageManager;
import com.nec.aim.dm.dmservice.entity.SegmentInfo;
import com.nec.aim.dm.dmservice.exception.DmServiceException;
import com.nec.aim.dm.dmservice.log.PerformanceLogger;

import jp.co.nec.aim.dm.message.proto.AimDmMessages.PBDmSyncRequest;
import jp.co.nec.aim.dm.message.proto.AimDmMessages.PBDmSyncResponce;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class SegmentController extends HttpServlet {
	private static final long serialVersionUID = 8978225136377187339L;

	@Autowired
	Dispatcher dispatcher;

	/**
	 * @param req
	 * @param res
	 */
	@RequestMapping(value = "/dmSyncSegment", method = RequestMethod.POST)
	public void dmSegmentHandler(HttpServletRequest req, HttpServletResponse res) {
		log.info("Received dmSyncSegment from {}", req.getRemoteHost());
		StopWatch t = new StopWatch();
		t.start();
		PBDmSyncResponce.Builder dmRes = PBDmSyncResponce.newBuilder();
		try {
			PBDmSyncRequest dmSegReq = PBDmSyncRequest.parseFrom(req.getInputStream());
			String changeType = dmSegReq.getCmd().name().toUpperCase();
			SegmentInfo segmentInfo = checkRequest(dmSegReq);
			String dmSyncMode = dispatcher.getDmSyncMode();
			boolean OK = dmSyncMode.toUpperCase().equals("LOG") || dmSyncMode.toUpperCase().equals("ANY")
					|| dmSyncMode.toUpperCase().equals("ALL");
			if (!OK) {
				log.warn("Got incorrect DmSyncMode from database. is not in (LOG,ANY,ALL), is't" + dmSyncMode);
				dmSyncMode = "ANY";
			}
			List<NodeStorageManager> activeNodeStorages = dispatcher.getActiveNodeStorages(changeType,
					segmentInfo.getSegmentId());
			if (null == activeNodeStorages || activeNodeStorages.size() < 1) {
				dmRes.setSuccess(false);
				dmRes.build().writeTo(res.getOutputStream());
				return;
			}
			boolean result = dispatcher.handlePostRequest(activeNodeStorages, dmSyncMode, dmSegReq, segmentInfo);
			dmRes.setSuccess(result);
			t.stop();
			log.info("Response to client, response = {} used time {}", result, t.elapsedTime());
			PerformanceLogger.trace(this.getClass().getSimpleName(), "dmSegmentHandler",
					segmentInfo.getSegmentId().toString(), segmentInfo.getBioIdEnd().toString(), t.elapsedTime());
			dmRes.build().writeTo(res.getOutputStream());
		} catch (Exception e) {
			log.error(e.getMessage());
			dmRes.setSuccess(false);
			try {
				dmRes.build().writeTo(res.getOutputStream());
			} catch (IOException e1) {
				log.error(e1.getMessage());
			}
		}
	}

	/**
	 * @param dmSegReq
	 * @return
	 * @throws SQLException
	 * @throws DmServiceException
	 */
	public SegmentInfo checkRequest(PBDmSyncRequest dmSegReq) throws SQLException, DmServiceException {
		StopWatch t = new StopWatch();
		t.start();
		Long bioId_start = null;
		Long bioId_end = null;
		Long segId = null;
		Long segVer = null;
		try {
			bioId_start = Long.valueOf(dmSegReq.getBioIdStart());
			bioId_end = Long.valueOf(dmSegReq.getBioIdEnd());
			segId = Long.valueOf(dmSegReq.getTargetSegment().getId());
			segVer = Long.valueOf(dmSegReq.getTargetSegment().getVersion());
		} catch (Exception e) {
			throw new DmServiceException(e);
		}

		SegmentInfo segInfo = new SegmentInfo();
		segInfo.setSegmentId(segId);
		segInfo.setVersion(segVer);
		if (bioId_start != null) {
			segInfo.setBioIdStart(bioId_start);
		}

		if (bioId_end != null) {
			segInfo.setBioIdEnd(bioId_end);
		}
		t.stop();
		PerformanceLogger.trace(this.getClass().getSimpleName(), "checkRequest", segId.toString(), null,
				t.elapsedTime());
		return segInfo;
	}
}
