package com.nec.aim.dm.dmservice.dispatch;

import java.sql.SQLException;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nec.aim.dm.dmservice.config.ConfigProperties;
import com.nec.aim.dm.dmservice.entity.NodeStorageManager;
import com.nec.aim.dm.dmservice.persistence.NodeStorageManagerRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class DownloadService {

	@Autowired
	NodeStorageManagerRepository nodeRepository;

	@Autowired
	ConfigProperties config;

	public String getNsmUrl(Long segId) {
		StopWatch t = new StopWatch();
		t.start();
		List<NodeStorageManager> activeList = null;
		Integer rdundancy = Integer.valueOf(DmServiceManager.getRedundancy().get());
		try {
			activeList = nodeRepository.getNodeStorgeBySegmentId(segId, rdundancy);
		} catch (SQLException e) {
			log.error(e.getMessage());
		}
		String nodeUrl = null;
		if (activeList != null && activeList.size() > 0) {
			Collections.shuffle(activeList);
			for (int i = 0; i < activeList.size(); i++) {
				nodeUrl = activeList.get(i).getUrl();
				log.info("nodeUrl = {}", nodeUrl);
				if (nodeUrl != null && nodeUrl.length() > 0) {
					nodeUrl = nodeUrl + config.getNsmWebContent() + config.getNsmDownloadMeghod();
					nodeUrl = nodeUrl.endsWith("/") ? nodeUrl : nodeUrl + "/";
					nodeUrl = nodeUrl + segId;
					log.info(nodeUrl);
					break;
				}
			}
		} else {
			log.warn("No active dm stroage node manager for process segmentId:{}", segId);
		}
		return nodeUrl;
	}

}
