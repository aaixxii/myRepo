package jp.co.nec.aim.mm.identify.planner;

public class JobInfoFromDB {
	private Long topJobId;
	private int familyId;
	private Integer functionId;
	private Integer containerId;
	private Long containerJobId;
	
	public JobInfoFromDB() {		
	}
	
public JobInfoFromDB(Long topJobId, int familyId, Integer fucId, Integer containerId, Long containerJobId) {
	this.topJobId = topJobId;
	this.familyId = familyId;
	this.functionId = fucId;
	this.containerId = containerId;
	this.containerJobId = containerJobId;		
	}

	public Long getContainerJobId() {
		return containerJobId;
	}

	public void setContainerJobId(Long containerJobId) {
		this.containerJobId = containerJobId;
	}

	public Long getTopJobId() {
		return topJobId;
	}

	public void setTopJobId(Long topJobId) {
		this.topJobId = topJobId;
	}

	public Integer getFunctionId() {
		return functionId;
	}

	public void setFunctionId(Integer functionId) {
		this.functionId = functionId;
	}

	public Integer getContainerId() {
		return containerId;
	}

	public void setContainerId(Integer containerIds) {
		this.containerId = containerIds;
	}

	public int getFamilyId() {
		return familyId;
	}

	public void setFamilyId(int familyId) {
		this.familyId = familyId;
	}

}
