package jp.co.nec.aim.mm.dm.client;

import java.util.Comparator;

import jp.co.nec.aim.mm.exception.AimRuntimeException;

/**
 * @author xia
 *
 */
public class DmIndexInfo implements Comparator<DmIndexInfo>{
	private Integer dmId;
	private String url;
	private int active;
	public Integer getDmId() {
		return dmId;
	}
	public void setDmId(Integer dmId) {
		this.dmId = dmId;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public int getActive() {
		return active;
	}
	public void setActive(int active) {
		this.active = active;
	}
	
	/* (non-Javadoc)
	 * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
	 */
	@Override
	public int compare(DmIndexInfo o1, DmIndexInfo o2) {
		if (o1 == null || o2 == null) {
			throw new AimRuntimeException("Compare object(DmIndexInfo) can't be null");
		}
		
		int result = -999;
		if (o1.getActive() == o2.getActive()) {
			result = 0;
		} else if (o1.getActive() > o2.getActive()) {
			result = -1;
		} else if (o1.getActive() < o2.getActive()) {
			result = 1;
		}
		return result;
	}	
}
