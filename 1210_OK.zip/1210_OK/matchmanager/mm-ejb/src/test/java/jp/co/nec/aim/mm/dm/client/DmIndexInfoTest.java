/**this is file DmIndexInfoTest.java
 * @author xia
   @date 2020/11/25
 */
package jp.co.nec.aim.mm.dm.client;

import java.util.Arrays;
import java.util.Collections;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


/**
 * @author xia
 *
 */
public class DmIndexInfoTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCompare() {
		DmIndexInfo[] dmList = new DmIndexInfo[10];
		for (int i = 0; i < 10; i++) {
			DmIndexInfo info = new DmIndexInfo();
			info.setUrl("url" + i);
			info.setDmId(i);
			if (i % 2 == 0) {
				info.setActive(0);
			} else {
				info.setActive(-1);
			}
			dmList[i] = info;
		}

		for (DmIndexInfo one : dmList) {
			System.out.println(one.getActive());
		}

		System.out.println("===========================");
		java.util.List<DmIndexInfo> tmpDmList = Arrays.asList(dmList);
		Collections.shuffle(tmpDmList);
		Collections.sort(tmpDmList, new DmIndexInfo());
		for (DmIndexInfo one : dmList) {
			System.out.println(one.getActive());
		}
	}

}
