package jp.co.nec.aim.mm.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import jp.co.nec.aim.mm.constants.Constants;
import jp.co.nec.aim.mm.entities.FeJobPayloadEntity;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.entities.FeResultEntity;
import jp.co.nec.aim.mm.util.CollectionsUtil;

public class FEJobDao {

	private EntityManager entityManager;

	public FEJobDao(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@SuppressWarnings("unchecked")
	public List<Long> listAllJobIds() {
		Query q = entityManager.createNamedQuery("NQ::allExtractJobIds");
		return q.getResultList();
	}
	
	@SuppressWarnings("unchecked")
	public List<FeJobQueueEntity> getExResult(String refId) {
		Query q = entityManager.createNamedQuery("NQ::getExResulst");
		q.setParameter("refId", refId);
		return (List<FeJobQueueEntity>) q.getResultList();
		
	}

	public int clearJobs() {
		Query q = entityManager.createNamedQuery("NQ::clearExtractJobs");
		return q.executeUpdate();
	}

	public void deleteExtractJob(long extractJobId) {
		Query q = entityManager.createNamedQuery("NQ::call_delete_extract_job");
		q.setParameter("extractJobId", extractJobId);
		q.executeUpdate();
	}
	
	public int delExtJobByRefId(String refId) {
		Query q = entityManager.createNamedQuery("NQ::deleteExtJobByRefernceId");
		q.setParameter("referenceId", refId);		
		return q.executeUpdate();
	}	

	public FeJobQueueEntity findFeJob(long id) {
		return (FeJobQueueEntity) entityManager
				.find(FeJobQueueEntity.class, id);
	}

//	 public FeLotJobEntity findLotJob(Long id) {
//	 return (FeLotJobEntity) entityManager.find(FeLotJobEntity.class, id);
//	 }
	
	 public FeJobPayloadEntity getFeJobPayload(Long feJobId) {
	 Query q = entityManager.createNamedQuery("NQ::getFeJobPayload");
	 q.setParameter("feJobId", feJobId);
	 return (FeJobPayloadEntity) q.getSingleResult();
	 }

	/**
	 * getFeResult
	 * 
	 * @param jobId
	 * @return list of FeResultEntity
	 */
	@SuppressWarnings("unchecked")
	public List<FeResultEntity> getFeResult(long jobId) {
		Query q = entityManager.createNamedQuery("NQ::getFeResultByjobId");
		q.setParameter("jobId", jobId);
		return (List<FeResultEntity>) q.getResultList();
	}

	/**
	 * get FeResult with feJob id and template key
	 * 
	 * @param jobId
	 *            fe job id
	 * @param key
	 *            template key
	 * @return the record of FeResult
	 */
	public List<FeResultEntity> getFeResult(long jobId, String key) {
		Query q = entityManager.createNamedQuery("NQ::getFeResult");
		q.setParameter("jobId", jobId);
		q.setParameter("templateKey", key);
		@SuppressWarnings("unchecked")
		List<FeResultEntity> feResults = (List<FeResultEntity>) q
				.getResultList();
		if (CollectionsUtil.isEmpty(feResults)) {
			return null;
		}
		return feResults;
	}

	public FeResultEntity getFeResult(long jobId, String key, int indexr) {
		Query q = entityManager.createNamedQuery("NQ::getFeResultByIndexr");
		q.setParameter("jobId", jobId);
		q.setParameter("templateKey", key);
		q.setParameter("templateIndex", indexr);
		return (FeResultEntity) q.getSingleResult();
	}

	/**
	 * delete FE_LOT_JOBS by lotJobId
	 * 
	 * @param lotJobId
	 */
	public void deleteLotJob(Long lotJobId) {
		if (lotJobId == null) {
			return;
		}

		Query q = entityManager.createNamedQuery("NQ::deleteLotJob");
		q.setParameter("lotJobId", lotJobId);
		q.executeUpdate();
	}

	/**
	 * get Timed Out Extract Jobs List
	 * 
	 * @return Timed Out Extract Jobs List
	 */
	@SuppressWarnings("unchecked")
	public List<FeJobQueueEntity> listTimedOutExtractJobs() {
		Query q = entityManager.createNamedQuery("NQ::listTimedOutExtractJobs");
		q.setParameter("rownum", Constants.MAX_TIMED_OUT_JOB_BATCH);
		return q.getResultList();
	}

	/**
	 * get Extract Jobs which muId is timeout or exit
	 * 
	 * @param muId
	 * @return Extract Jobs List
	 */
	@SuppressWarnings("unchecked")
	public List<FeJobQueueEntity> listDeadExtractJobs(long muId) {
		Query q = entityManager.createNamedQuery("NQ::listDeadExtractJobs");
		q.setParameter("muId", muId);
		return q.getResultList();
	}

}
