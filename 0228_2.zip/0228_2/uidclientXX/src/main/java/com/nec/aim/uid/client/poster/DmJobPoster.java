package com.nec.aim.uid.client.poster;

import static com.nec.aim.uid.client.common.UidClientConstants.DM_CONCURRENT_COUNT;
import static com.nec.aim.uid.client.common.UidClientConstants.DM_SERVICES_URLS;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.ByteString;
import com.nec.aim.uid.client.exception.UidClientException;
import com.nec.aim.uid.client.manager.UidCommonManager;
import com.nec.aim.uid.client.proerties.PropertyNames;
import com.nec.aim.uid.client.util.FileUtil;
import com.nec.aim.uid.client.util.StopWatch;
import com.squareup.okhttp.Call;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import jp.co.nec.aim.message.proto.AIMMessages.PBTargetSegmentVersion;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;

public class DmJobPoster {
	private static Logger logger = LoggerFactory.getLogger(DmJobPoster.class);
	private static long postTimeOut = 6000;
	private static final MediaType MEDIA_TYPE_PLAINTEXT = MediaType.parse("text/plain; charset=utf-8");	
	
	public static void addJobToDm(List<String> fileList) {
		for (String one : fileList) {
			 buildDmJobRequest(one);
		}
	}
	
	private static void buildDmJobRequest(String dmRequestFile) {
		Properties prop = new Properties();
		PBDmSyncRequest.Builder dmRequest = PBDmSyncRequest.newBuilder();
		try (InputStream input = new FileInputStream(dmRequestFile)) {
			prop.load(input);			
			String dmUrl = UidCommonManager.getValue(DM_SERVICES_URLS);
			String concurentJobCount = prop.getProperty(DM_CONCURRENT_COUNT);
			int conCurJobCount = -9999;
			if (concurentJobCount != null && !concurentJobCount.equals("-1")) {
				conCurJobCount = Integer.valueOf(conCurJobCount);
			} else {
			    conCurJobCount = 1;
			}
			String dmReqCmd = prop.getProperty(PropertyNames.DM_REQ_CMD.name());
			if (!dmReqCmd.isEmpty() && !dmReqCmd.equals("-1")) {
			    if (dmReqCmd.equals("INSERT")) {
			        dmRequest.setCmd(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT);
			    } else if (dmReqCmd.equals("DELETE")) {
			        dmRequest.setCmd(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_DELETE);
			    }
				
			}
			String dmReqBioId = prop.getProperty(PropertyNames.DM_REQ_BIO_ID.name());
			if (!dmReqBioId.isEmpty() && !dmReqBioId.equals("-1")) {
				dmRequest.setBioId(Long.valueOf(dmReqCmd));
			}
			PBTemplateInfo.Builder templateInfo = PBTemplateInfo.newBuilder();
			String dmReqExternalId = prop.getProperty(PropertyNames.DM_REQ_REF_ID.name());
			if (!dmReqExternalId.isEmpty() && !dmReqExternalId.equals("-1")) {
				templateInfo.setReferenceId(dmReqExternalId);
			}
			String dmReqTemplatePath = prop.getProperty(PropertyNames.DM_REQ_TEMPLATE_DATA_PATH.name());
			if (!dmReqTemplatePath.isEmpty() && !dmReqTemplatePath.equals("-1")) {
				 byte[] data = FileUtil.getDataFromFile(dmReqTemplatePath);		          
				 templateInfo.setData(ByteString.copyFrom(data));		          		         
			}
			dmRequest.setTemplateData(templateInfo.build());
			String dmReqSegId = prop.getProperty(PropertyNames.DM_REQ_SEG_ID.name());
			if (!dmReqSegId.isEmpty() && !dmReqSegId.equals("-1")) {
				dmRequest.setCmd(SegmentSyncCommandType.valueOf(dmReqCmd));
			}
			PBTargetSegmentVersion.Builder segVerBuilder = PBTargetSegmentVersion.newBuilder();
			String dmReqSegVer = prop.getProperty(PropertyNames.DM_REQ_SEG_VER.name());
			if (!dmReqSegVer.isEmpty() && !dmReqSegVer.equals("-1")) {
				segVerBuilder.setVersion(Long.valueOf(dmReqSegVer));				
			}
			dmRequest.setTargetSegments(segVerBuilder);
			Boolean result = post(dmUrl, dmRequest.build());
			logger.info("Success send dm request to DM cluster.");
			logger.info("Get response from dm,result ={}", result);
			
			String dmDownloadSegId = prop.getProperty(PropertyNames.DM_DOWNLOAD_SEG_ID.name());
			if (!dmDownloadSegId.isEmpty() && !dmDownloadSegId.equals("-1")) {
				byte[] downloaded = getSegment(dmUrl, Long.valueOf(dmDownloadSegId));
				if (downloaded != null) {
					logger.info("Download segmentData from dm , data size  ={}", downloaded.length);
				}
			}

		} catch (Exception e) {
			throw new UidClientException(e.getMessage(), e);
		} finally {
			prop.clear();
			prop = null;
		}
	}

	public static Boolean post(String url, PBDmSyncRequest dmSegReq) {
		Callable<Boolean> newPostTask = () -> {
			OkHttpClient client = new OkHttpClient();
			client.setConnectTimeout(postTimeOut / 4, TimeUnit.MILLISECONDS);
			client.setReadTimeout(postTimeOut / 4, TimeUnit.MILLISECONDS);
			client.setWriteTimeout(postTimeOut / 2, TimeUnit.MILLISECONDS);
			final StopWatch t = new StopWatch();
			t.start();
			Request request = new Request.Builder().url(url)
					.post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, dmSegReq.toByteArray())).build();
			try {
				Response response = client.newCall(request).execute();				
				t.stop();
				logger.info("Post PBDmSyncRequest(bioId={}) to {} used time={}, and status={}", dmSegReq.getBioId(),
						url, t.elapsedTime(), response.code());
				if (response.isSuccessful()) {
					return Boolean.valueOf(true);
				} else {
					return Boolean.valueOf(false);
				}
				
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
				return Boolean.valueOf(false);
			}
		};
		try {
			return UidDmJobRunManager.submit(newPostTask);
		} catch (InterruptedException | ExecutionException e) {
			logger.error(e.getMessage(), e);
			return Boolean.valueOf(false);
		}
	}

	public static byte[] getSegment(String getUrl, Long segId) throws InterruptedException, ExecutionException {
		Callable<byte[]> newGetTask = () -> {
			OkHttpClient client = new OkHttpClient();
			client.setConnectTimeout(postTimeOut / 4, TimeUnit.MILLISECONDS);
			client.setReadTimeout(postTimeOut / 4, TimeUnit.MILLISECONDS);
			client.setWriteTimeout(postTimeOut / 2, TimeUnit.MILLISECONDS);
			final StopWatch t = new StopWatch();
			t.start();
			Request request = new Request.Builder().get().url(getUrl).build();
			Call call = client.newCall(request);
			Response response = call.execute();
			t.stop();
			logger.info("Post getSegment request(segmentId={}) to {} used time={}, and status={}", segId,
					getUrl, t.elapsedTime(), response.code());
			if (response.isSuccessful()) {
				 return response.body().bytes();
			} else {
				return null;
			}			
		};		
		return UidDmJobRunManager.submitGetRequest(newGetTask);		
	}
}
