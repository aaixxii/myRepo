package com.nec.aim.uid.client.manager;

import static com.nec.aim.uid.client.common.UidClientConstants.COMMON_PROPERTY_FULL_NAME;
import static com.nec.aim.uid.client.common.UidClientConstants.CONCURRENT_THEAD_COUNT;
import static com.nec.aim.uid.client.common.UidClientConstants.DEFALUT_MM_BASE_URL;
import static com.nec.aim.uid.client.common.UidClientConstants.DM_CONCURRENT_COUNT;
import static com.nec.aim.uid.client.common.UidClientConstants.DM_SERVICES_URLS;
import static com.nec.aim.uid.client.common.UidClientConstants.EXTRACT_JOB_SETING_FILE_FULL_NAME;
import static com.nec.aim.uid.client.common.UidClientConstants.IDENDIFY_JOB_SETING_FILE_FULL_NAME;
import static com.nec.aim.uid.client.common.UidClientConstants.JOB_REQUEST_PATH;
import static com.nec.aim.uid.client.common.UidClientConstants.JOB_RESULT_PATH;
import static com.nec.aim.uid.client.common.UidClientConstants.JOB_TEMPLATES_PATH;
import static com.nec.aim.uid.client.common.UidClientConstants.MM_BASE_URL;
import static com.nec.aim.uid.client.common.UidClientConstants.MM_IP;
import static com.nec.aim.uid.client.common.UidClientConstants.MM_PORT;
import static com.nec.aim.uid.client.common.UidClientConstants.MM_WEB_CONTENT;
import static com.nec.aim.uid.client.common.UidClientConstants.MONITOR_PATH;
import static com.nec.aim.uid.client.common.UidClientConstants.PICKUP_MM_ALGORITHM;
import static com.nec.aim.uid.client.common.UidClientConstants.SEQUENCE_PATH;
import static com.nec.aim.uid.client.common.UidClientConstants.SYNC_JOB_SETING_FILE_FULL_NAME;

import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.log4j.PropertyConfigurator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.aim.uid.client.proerties.PropertyNames;
import com.nec.aim.uid.client.proerties.PropertyUtil;
import com.nec.aim.uid.client.util.ClientUtil;



public class UidCommonManager {
	public static final UidCommonManager manager = new UidCommonManager();
	private static final ConcurrentHashMap<String, String> keyValueMap = new ConcurrentHashMap<>();
	private static Logger logger = LoggerFactory.getLogger(UidCommonManager.class);
	
	//private static final Random sRandom = new Random(System.currentTimeMillis());
	
	private static final ConcurrentHashMap<String, Long> timesMap = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<String, Integer> priorityMap = new ConcurrentHashMap<>();
	private static final ConcurrentHashMap<String, Object> lockerMap = new ConcurrentHashMap<>();
	private static final Lock timesMapLock = new ReentrantLock();

	public UidCommonManager() {		
	}
	
	public static Object getLock(String jobId) {
		if (jobId == null) {
			return null;
		} else {
			return lockerMap.get(jobId);
		}
	}
	
	public static void putLocker(String jobId, Object locker) {
		if (jobId != null && locker != null) {
			lockerMap.put(jobId, locker);
		}
	}
	
	public static void removeLock(String jobId) {
		if (jobId != null) {
			lockerMap.remove(jobId);
		}
	}	
	
	public static ConcurrentHashMap<String, Long> getTimesMap() {
		timesMapLock.lock();
		try {
			return timesMap;
		} finally {
			timesMapLock.unlock();
		}
	}

	public static UidCommonManager getInstance() {
		return manager;
	}
	
	
	public int getMapSize() {
		return keyValueMap.size();
	}

	public void putData(String key, String value) {
		keyValueMap.putIfAbsent(key, value);
	}

	public static String getValue(String key) {
		return keyValueMap.get(key);
	}
	
	public static void  putPriority(String jobId, Integer priroty) {
		priorityMap.putIfAbsent(jobId, priroty);
	}
	
	public static Integer getPriority(String jobId) {
		return priorityMap.get(jobId);
	}
	
	public static void removePriority(String jobId) {
		priorityMap.remove(jobId);
	}
	
	public void getBasePath() {
		String myPath = UidCommonManager.class.getProtectionDomain().getCodeSource().getLocation().getPath();		
		String uidBaseDir = myPath.substring(0, myPath.length() - 18);			
		//URL myUrl = Thread.currentThread().getContextClassLoader().getResource(""); it's ok too
		//URL configUrl = Thread.currentThread().getContextClassLoader().getResource("config");		
		String commonProperyFullPath = uidBaseDir + "/" + "config" + "/" + "uid.common.properties";
		String loggerPath =  uidBaseDir + "/" + "config" + "/" + "log4j.properties";
		PropertyConfigurator.configure(loggerPath);		
		String jobReqeustPath = uidBaseDir + "/" + "jobrequests";
		String extractJobSetFileFullName = jobReqeustPath + "/" + "uid.extract.properties";
		String identifyJobSetFileFullName = jobReqeustPath + "/" + "uid.identify.properties";
		String syncJobSetFileFullName = jobReqeustPath + "/" + "uid.sync.properties";
		String templatesPath = uidBaseDir + "/" + "templates";		
		String jobresultPath = uidBaseDir + "/" + "jobresults";	
		String sequencesPath = uidBaseDir + "/" + "sequence";	
		String monitorPath = uidBaseDir + "/" + "monitor";	
		keyValueMap.putIfAbsent(COMMON_PROPERTY_FULL_NAME, commonProperyFullPath);
		keyValueMap.putIfAbsent(EXTRACT_JOB_SETING_FILE_FULL_NAME, extractJobSetFileFullName);
		keyValueMap.putIfAbsent(IDENDIFY_JOB_SETING_FILE_FULL_NAME, identifyJobSetFileFullName);
		keyValueMap.putIfAbsent(SYNC_JOB_SETING_FILE_FULL_NAME, syncJobSetFileFullName);
		keyValueMap.putIfAbsent(JOB_REQUEST_PATH, jobReqeustPath);
		keyValueMap.putIfAbsent(JOB_RESULT_PATH, jobresultPath);
		keyValueMap.putIfAbsent(SEQUENCE_PATH, sequencesPath);
		keyValueMap.putIfAbsent(MONITOR_PATH, monitorPath);
		keyValueMap.putIfAbsent(JOB_TEMPLATES_PATH, templatesPath);	
	}
	
	public void buildEachMMBaseUrl(String[] serverIds, String[] ports) {
		// int pickUp = sRandom.nextInt(serverIpCount);
		String mmContent = keyValueMap.get(MM_WEB_CONTENT);
		for (int i = 0; i < serverIds.length; i++) {
			String baseUrl = "http://" + serverIds[i] + ":" + ports[i] + "/" + mmContent + "/";
			keyValueMap.putIfAbsent(MM_BASE_URL + i, baseUrl);
		}
		keyValueMap.putIfAbsent(DEFALUT_MM_BASE_URL, keyValueMap.get(MM_BASE_URL + 0));
		System.out.print(keyValueMap.get(DEFALUT_MM_BASE_URL));

	}

	public boolean getAllProperties() {
		getBasePath();
		ClientUtil cu = new ClientUtil();		
		try {
			String propertyFileFullName = keyValueMap.get(COMMON_PROPERTY_FULL_NAME);	
			PropertyUtil util = new PropertyUtil(propertyFileFullName);
			String mmWebContent = util.getPropertyValue(PropertyNames.MM_WEB_CONTENT.name());
			if (Objects.isNull(mmWebContent)) {
				logger.error("mm web content is empty!");				
				return false;
			}
			keyValueMap.putIfAbsent(MM_WEB_CONTENT , mmWebContent);
			String concurrentCount = util.getPropertyValue(PropertyNames.CONCURRENT_COUNT.name());
			if (!Objects.isNull(concurrentCount)) {
				keyValueMap.putIfAbsent(CONCURRENT_THEAD_COUNT, concurrentCount);
			} else {
				keyValueMap.putIfAbsent(CONCURRENT_THEAD_COUNT, "30");
			}
			String pickUpMMAlg = util.getPropertyValue(PropertyNames.PICKUP_MM_ALG.name());
			if (!Objects.isNull(pickUpMMAlg)) {
				keyValueMap.putIfAbsent(PICKUP_MM_ALGORITHM, pickUpMMAlg);
			} else {
				keyValueMap.putIfAbsent(PICKUP_MM_ALGORITHM, "FIRST");
			}
			//for dm
			String dmConnectionString = util.getPropertyValue(PropertyNames.DM_SERVICE_CONN_STR.name());
			if (!dmConnectionString.isEmpty()) {
				keyValueMap.putIfAbsent(DM_SERVICES_URLS , dmConnectionString);
			}
			String dmConcurrentCount = util.getPropertyValue(PropertyNames.DM_CONCURRENT_COUNT.name());
			if (!dmConcurrentCount.isEmpty()) {
				keyValueMap.putIfAbsent(DM_CONCURRENT_COUNT , dmConcurrentCount);
			}			
			
			String serverIds = util.getPropertyValue(PropertyNames.MM_IP_ADDRESS_LIST.name());
			
			String serverPorts = util.getPropertyValue(PropertyNames.MM_PORT_LIST.name());
			
			if (Objects.isNull(serverIds) || Objects.isNull(serverPorts)) {
				String error = "There are miss in xm.client.properties is! serverId or port is empty!";
				logger.error(error);
				return false;
			}
			 String[] serverIdArr = serverIds.split(",");
			String[] serverPortArr = serverPorts.split(",");
			if (serverIdArr.length != serverPortArr.length) {
				logger.error("The count of server ips is not equal the count of server of ports");
				return false;
			}	
		
			for (int i = 0; i < serverIdArr.length; i++) {
				keyValueMap.putIfAbsent(MM_IP + i , serverIdArr[i]);
				keyValueMap.putIfAbsent(MM_PORT + i , serverPortArr[i]);
				if (!cu.checkIP(serverIdArr[i])) {
					logger.error("Server ip is incorrect! ip:" + serverIdArr[i]);
					return false;
				}				
				if (!cu.isMatchNumber(serverPortArr[i])) {
					logger.error("Server port is incorrect! port:" + serverPortArr[i]);
					return false;
				}
			}
			
			buildEachMMBaseUrl(serverIdArr, serverPortArr);
			return true;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return false;
		} finally {
			cu = null;
		}
	}

	public void shutdown() {
		keyValueMap.clear();
	}
}
