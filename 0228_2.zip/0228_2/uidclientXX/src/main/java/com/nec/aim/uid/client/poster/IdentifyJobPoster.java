package com.nec.aim.uid.client.poster;

import static com.nec.aim.uid.client.common.UidClientConstants.DEFALUT_MM_BASE_URL;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Objects;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.ByteString;
import com.nec.aim.uid.client.common.SequenceIdCreator;
import com.nec.aim.uid.client.common.SequenceIdType;
import com.nec.aim.uid.client.exception.UidClientException;
import com.nec.aim.uid.client.logger.PerformanceLogger;
import com.nec.aim.uid.client.manager.ExecutorManager;
import com.nec.aim.uid.client.manager.UidCommonManager;
import com.nec.aim.uid.client.result.writer.IdentifyResultWriter;
import com.nec.aim.uid.client.util.FileUtil;
import com.nec.aim.uid.client.util.StopWatch;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import jp.co.nec.aim.message.proto.BatchTypeProto.BatchType;
import jp.co.nec.aim.message.proto.BusinessMessage.E_BIOMETRIC_DATA_FORMAT;
import jp.co.nec.aim.message.proto.BusinessMessage.E_REQUESET_TYPE;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBiometricElement;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBiometricsData;
import jp.co.nec.aim.message.proto.BusinessMessage.PBBusinessMessage;
import jp.co.nec.aim.message.proto.BusinessMessage.PBParameterGroup;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequest;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequestParameter;
import jp.co.nec.aim.message.proto.BusinessMessage.PBRequestParameters;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyRequest;
import jp.co.nec.aim.message.proto.InquiryService.IdentifyResponse;

public class IdentifyJobPoster implements Runnable {
	private String iqyParaFilePath;
	private Long iqyJobTimeOut;
	private String mmBaseUrl;
	private long batchId;
	private String requestId;
	private Properties prop = new Properties();
	private static Logger logger = LoggerFactory.getLogger("HttpPostLogger");
	private static final String IDENTIFY_URL = "AIMInquiryService/inquiry";

	private static final MediaType MEDIA_TYPE_PLAINTEXT = MediaType.parse("text/plain; charset=utf-8");

	public IdentifyJobPoster(String paraFilePath) {
		this.iqyParaFilePath = paraFilePath;
	}

	@Override
	public void run() {		
		IdentifyResponse iqyRes = null;
		IdentifyRequest iqyReq = buildIdentifyRequest();
//		 NumberFormat nfNum = NumberFormat.getNumberInstance();
//		 nfNum.setMinimumIntegerDigits(64);
//		 nfNum.setGroupingUsed(false);
		logger.trace("prepare post identify job batchJobId={}, requestId={}", batchId, requestId);
		String iqyPostUrl = mmBaseUrl.endsWith("/") ? mmBaseUrl + IDENTIFY_URL : mmBaseUrl + "/" + IDENTIFY_URL;
		OkHttpClient client = new OkHttpClient();
		client.setConnectTimeout(iqyJobTimeOut / 4, TimeUnit.MILLISECONDS);
		client.setReadTimeout(iqyJobTimeOut / 4, TimeUnit.SECONDS);
		client.setWriteTimeout(iqyJobTimeOut / 2, TimeUnit.SECONDS);
		final StopWatch t = new StopWatch();
		t.start();
		Request request = new Request.Builder().url(iqyPostUrl)
				.post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, iqyReq.toByteArray())).build();
		t.stop();
		PerformanceLogger.trace("identifyPost", batchId, requestId, t.elapsedTime());
		try {
			Response response = client.newCall(request).execute();
			iqyRes = IdentifyResponse.parseFrom(response.body().bytes());
			IdentifyResultWriter writeTask = new IdentifyResultWriter(iqyRes.toBuilder());
			ExecutorManager.getInstance().commitWriteTask(writeTask);
			logger.trace("batchJobId:{} http status:{}", this.batchId, response.code());
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}

	private IdentifyRequest buildIdentifyRequest() {
		IdentifyRequest.Builder iqyReq = IdentifyRequest.newBuilder();
		batchId = SequenceIdCreator.createNextSequence(SequenceIdType.BATCHJOB_ID);		
		iqyReq.setBatchJobId(batchId);
		PBBusinessMessage.Builder iqyPbMsg = PBBusinessMessage.newBuilder();
		PBRequest.Builder req = PBRequest.newBuilder();
		requestId = String.valueOf(SequenceIdCreator.createNextSequence(SequenceIdType.REQUST_ID));
		req.setRequestId(requestId);
		try (InputStream input = new FileInputStream(iqyParaFilePath)) {
			prop.load(input);
			mmBaseUrl = UidCommonManager.getValue(DEFALUT_MM_BASE_URL);	
			if (Objects.isNull(mmBaseUrl)) {
				throw new UidClientException("Can't resoved mmBaseUrl.");
			}
			iqyJobTimeOut = Long.valueOf(prop.getProperty("INQURIY_JOB_TIME_OUT"));
			if (Objects.isNull(iqyJobTimeOut) || iqyJobTimeOut < 0) {
				iqyJobTimeOut = Long.valueOf(10000);
			}
			String batchJobType = prop.getProperty("BATCH_TYPE");
			String refernceId = UUID.randomUUID().toString().toUpperCase();
			String maxResultCount = prop.getProperty("MAX_RESULTS_COUNT");
			String targetFpir = prop.getProperty("TARGET_FPIR");
			String bioDataFormat = prop.getProperty("E_BIOMETRIC_DATA_FORMAT");
			if (batchJobType == null || bioDataFormat == null) {
				throw new UidClientException("batchJobType or bioDataFormat is null!");				
			}
			iqyReq.setType(BatchType.valueOf(batchJobType));
			if (maxResultCount != null) {
				req.setMaxResults(Integer.valueOf(maxResultCount).intValue());
			}
			if (targetFpir != null) {
				req.setTargetFpir(Integer.valueOf(targetFpir).intValue());
			}			
			req.setEnrollmentId(refernceId);
			PBBiometricsData.Builder bioData = PBBiometricsData.newBuilder();
			PBBiometricElement.Builder bioElement = PBBiometricElement.newBuilder();
			String eRequestType = prop.getProperty("E_REQUESET_TYPE");
			if (eRequestType == null) {
				throw new UidClientException("RequestType is null!");
			}
			req.setRequestType(E_REQUESET_TYPE.valueOf(eRequestType));
			PBTemplateInfo.Builder template = PBTemplateInfo.newBuilder();
			if (eRequestType.toUpperCase().equals("IDENTIFY_DEFAULT")) {
				String binaryDataPath = prop.getProperty("BINARY_DATA_FILE_PATH");
				byte[] templateData = readBinaryData(binaryDataPath);
				template.setData(ByteString.copyFrom(templateData));
			} else if (eRequestType.toUpperCase().equals("IDENTIFY_REFID_DEFAULT")) {
				String templateRefId = prop.getProperty("TEMPLATE_REFERENCE_ID");
				template.setReferenceId(templateRefId);
			}
			bioElement.setTemplateInfo(template.build());
			bioData.setBiometricElement(bioElement.build());
			bioData.setDataFormat(E_BIOMETRIC_DATA_FORMAT.valueOf(bioDataFormat));
			req.setBiometricsData(bioData.build());
			Integer groupNameCount = Integer.valueOf(prop.getProperty("GROUP_NAME_COUNT"));
			if (!Objects.isNull(groupNameCount) && groupNameCount.intValue() > 0) {
				PBRequestParameters.Builder iqyReqParam = PBRequestParameters.newBuilder();
				for (int i = 1; i <= groupNameCount; i++) {
					String requestParamters = prop.getProperty("REQUEST_PARAMETER" + i);
					String[] paramArr = requestParamters.split("#");
					String gpName = paramArr[0];
					String keyValusList = paramArr[1];
					String[] keyValueArr = keyValusList.split(",");
					PBParameterGroup.Builder pbPG = PBParameterGroup.newBuilder();
					pbPG.setGroupName(gpName);
					for (int j = 0; j < keyValueArr.length; j++) {
						PBRequestParameter.Builder pbParam = PBRequestParameter.newBuilder();
						String[] tmp = keyValueArr[j].split(":");
						pbParam.setParameterName(tmp[0]);
						pbParam.setParameterValue(tmp[1]);
						pbPG.addRequestParameter(pbParam.build());
					}
					iqyReqParam.addParameterGroup(pbPG.build());
				}

				req.setRequestParameters(iqyReqParam.build());
				iqyPbMsg.setRequest(req.build());
				iqyReq.addBusinessMessage(iqyPbMsg.build().toByteString());
				logger.info("created inqury request, batchJobId={}, batchtype={}", batchId, batchJobType);
			}

		} catch (Exception e) {
			throw new UidClientException(e.getMessage(), e);
		}
		return iqyReq.build();
	}

	private byte[] readBinaryData(String filePath) {
		byte[] data = FileUtil.getDataFromFile(filePath);
		return data;
	}
}
