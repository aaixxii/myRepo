package com.nec.aim.uid.client;

import java.util.*;
import java.util.stream.Collectors;

public class Sort {

    public static void main(String[] args) {        
        Map<Integer, Integer> map = new HashMap<>();
        map.put(21, 10);
        map.put(11, 12);
        map.put(2, 10);
        Map<Integer, Integer> result = map.entrySet().stream()
                .sorted(Map.Entry.<Integer, Integer>comparingByValue().reversed()
                        .thenComparing(Map.Entry.comparingByKey()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));

        for (Map.Entry<Integer, Integer> sorted : result.entrySet()) {
            System.out.printf("Key is %d  value is %d \n", sorted.getKey(), sorted.getValue());
        }
    }
	// InputStream input = new FileInputStream(sequecFilePath);
	// prop.load(input);
	// long batchJobId = Long.valueOf(prop.getProperty("BATCH_JOB_ID"));
	// lastBatchJobId = new AtomicLong(batchJobId);
	// long reqeustId = Long.valueOf(prop.getProperty("REQUEST_Id"));
	// lastReqeustId = new AtomicLong(reqeustId);
	// long enrollmentId = Long.valueOf(prop.getProperty("ENROLLMENT_ID"));
	// lastEnrollmentId = new AtomicLong(enrollmentId);
	// input.close();
	// FileOutputStream out = new FileOutputStream(sequecFilePath);
	// prop.setProperty("BATCH_JOB_ID",
	// String.valueOf(lastBatchJobId.get()));
	// prop.setProperty("REQUEST_Id", String.valueOf(lastReqeustId.get()));
	// prop.setProperty("ENROLLMENT_ID",
	// String.valueOf(lastEnrollmentId.get()));
	// prop.store(out, null);
	// out.close();
}