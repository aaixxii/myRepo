package com.nec.aim.uid.client;

import java.io.IOException;
import java.net.URL;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.google.protobuf.ByteString;
import com.nec.aim.uid.client.util.FileUtil;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import jp.co.nec.aim.message.proto.AIMEnumTypes.SegmentSyncCommandType;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;
import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncResponce;
import jp.co.nec.aim.message.proto.AIMMessages.PBTargetSegmentVersion;
import jp.co.nec.aim.message.proto.BusinessMessage.PBTemplateInfo;

public class DmPoster {
    private static final MediaType MEDIA_TYPE_PLAINTEXT = MediaType.parse("text/plain; charset=utf-8");   
    
    private static AtomicLong lastBatchJobId;
    
    private static AtomicLong lastReqeustId;
    
    private static AtomicLong lastEnrollmentId;
    
    private String sequecFilePath;
    
    @Before
    public void setUp() throws Exception {
        URL url = Thread.currentThread().getContextClassLoader().getResource("uid.sequece.properties");
        sequecFilePath = url.getPath();
        PropertiesConfiguration propsConfig = new PropertiesConfiguration();
        propsConfig.setEncoding("UTF-8");
        propsConfig.load(sequecFilePath);
        long batchJobId = propsConfig.getLong("BATCH_JOB_ID");
        lastBatchJobId = new AtomicLong(batchJobId);
        long reqeustId = propsConfig.getLong("REQUEST_Id");
        lastReqeustId = new AtomicLong(reqeustId);
        long enrollmentId = propsConfig.getLong("ENROLLMENT_ID");
        lastEnrollmentId = new AtomicLong(enrollmentId);
        propsConfig = null;
    }
    
    @After
    public void tearDown() throws Exception {
        try {
            PropertiesConfiguration properties = new PropertiesConfiguration(sequecFilePath);
            properties.setProperty("BATCH_JOB_ID", String.valueOf(lastBatchJobId.get()));
            properties.setProperty("REQUEST_Id", String.valueOf(lastReqeustId.get()));
            properties.setProperty("ENROLLMENT_ID", String.valueOf(lastEnrollmentId.incrementAndGet()));
            properties.save();
            properties = null;
        } catch (ConfigurationException e) {
            System.out.println(e.getMessage());
        }
    }  
    
    @Test
    public void testSyncDmInsert() {
    	  final PBDmSyncRequest.Builder dmSyncReq = PBDmSyncRequest.newBuilder();
    	  dmSyncReq.setCmd(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT);
    	  dmSyncReq.setBioId(1);
          PBTemplateInfo.Builder templateInfo = PBTemplateInfo.newBuilder();
          templateInfo.setReferenceId("necuid1");
          byte[] data = FileUtil.getDataFromFile("C:\\Users\\xia\\Desktop\\0219\\ext_result.bat");
          templateInfo.setData(ByteString.copyFrom(data));
          dmSyncReq.setTemplateData(templateInfo.build());
          PBTargetSegmentVersion.Builder segVer = PBTargetSegmentVersion.newBuilder();
          segVer.setId(18);
          segVer.setVersion(1000); 
          dmSyncReq.setTargetSegments(segVer.build());
          OkHttpClient client = new OkHttpClient();
          client.setReadTimeout(1000, TimeUnit.MINUTES);
          Request request = new Request.Builder()                         
                   //.url("http://192.168.232.146:8080/zkpdm/dmSyncSegment")
                   .url("http://127.0.0.1:8080/dmlsb/dmSyncSegment")
                  .post(RequestBody.create(MEDIA_TYPE_PLAINTEXT, dmSyncReq.build().toByteArray())).build();
              try {
                  Response response = client.newCall(request).execute();           
                  PBDmSyncResponce dmRes = PBDmSyncResponce.parseFrom(response.body().bytes());
                  boolean result = dmRes.getSuccess();
                  System.out.println(result); 
              } catch (IOException e) {
                  e.printStackTrace();
              }    	
    }
    
    @SuppressWarnings("unused")
	private PBDmSyncRequest createDmRequest(long bioId, long segId, long segVersion, String refId) {    	
     	  final PBDmSyncRequest.Builder dmSyncReq = PBDmSyncRequest.newBuilder();
    	  dmSyncReq.setCmd(SegmentSyncCommandType.SEGMENT_SYNC_COMMAND_INSERT);
    	  dmSyncReq.setBioId(bioId);
          PBTemplateInfo.Builder templateInfo = PBTemplateInfo.newBuilder();
          templateInfo.setReferenceId(refId);
          byte[] data = FileUtil.getDataFromFile("C:\\Users\\xia\\Desktop\\0219\\ext_result.bat");
          templateInfo.setData(ByteString.copyFrom(data));
          dmSyncReq.setTemplateData(templateInfo.build());
          PBTargetSegmentVersion.Builder segVer = PBTargetSegmentVersion.newBuilder();
          segVer.setId(segId);
          segVer.setVersion(segVersion); 
          dmSyncReq.setTargetSegments(segVer.build());
          return dmSyncReq.build();    	
    }  
}
