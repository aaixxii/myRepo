package com.nec.aim.uid.client.proerties;

public enum PropertyNames {	
    DM_WEB_CONTENT,//
	DM_SERVICE_CONN_STR,//
	DM_CONCURRENT_COUNT,//
	DM_REQ_CMD,//
	DM_REQ_BIO_ID,//
	DM_REQ_REF_ID,//
	DM_REQ_TEMPLATE_DATA_PATH,//
	DM_REQ_SEG_ID,//
	DM_REQ_SEG_VER,//
	DM_DOWNLOAD_SEG_ID;

}
