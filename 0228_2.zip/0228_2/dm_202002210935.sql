-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.19 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             10.3.0.5771
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for dm
CREATE DATABASE IF NOT EXISTS `dm` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `dm`;

-- Dumping structure for table dm.action_schedule
CREATE TABLE IF NOT EXISTS `action_schedule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_type` tinyint NOT NULL DEFAULT '0',
  `start_time` datetime NOT NULL,
  `status` tinyint NOT NULL DEFAULT '0',
  `TS` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  KEY `action_type` (`action_type`),
  KEY `start_time` (`start_time`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Data exporting was unselected.

-- Dumping structure for table dm.change_log
CREATE TABLE IF NOT EXISTS `change_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `segment_id` int NOT NULL,
  `operation` int NOT NULL COMMENT '0 : Create, 1 : Read, 2 : Update, 3 : Delete',
  `template` blob NOT NULL,
  `version` bigint NOT NULL,
  `TS` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  KEY `segment_id` (`segment_id`),
  KEY `operation` (`operation`),
  CONSTRAINT `FK_change_log_segment_info` FOREIGN KEY (`segment_id`) REFERENCES `segment_info` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Data exporting was unselected.

-- Dumping structure for table dm.dm_info
CREATE TABLE IF NOT EXISTS `dm_info` (
  `name` char(50) NOT NULL,
  `value` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='DM basic defination, such as Template size, redundancy ... etc';

-- Data exporting was unselected.

-- Dumping structure for table dm.master
CREATE TABLE IF NOT EXISTS `master` (
  `node_id` int NOT NULL,
  `token_start` timestamp NOT NULL,
  `TS` timestamp NOT NULL,
  KEY `FK_master_node` (`node_id`),
  CONSTRAINT `FK_master_node` FOREIGN KEY (`node_id`) REFERENCES `node` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Data exporting was unselected.

-- Dumping structure for table dm.node
CREATE TABLE IF NOT EXISTS `node` (
  `id` int NOT NULL AUTO_INCREMENT,
  `address` varchar(50) NOT NULL,
  `disk_size` int NOT NULL DEFAULT '0',
  `space` int NOT NULL DEFAULT '0',
  `status` tinyint NOT NULL DEFAULT '0',
  `TS` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `address` (`address`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Data exporting was unselected.

-- Dumping structure for table dm.segment_info
CREATE TABLE IF NOT EXISTS `segment_info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `from` bigint NOT NULL,
  `to` bigint NOT NULL,
  `version` bigint NOT NULL,
  `TS` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Data exporting was unselected.

-- Dumping structure for table dm.segment_loading
CREATE TABLE IF NOT EXISTS `segment_loading` (
  `segment_uuid` varchar(255) NOT NULL,
  `node_id` int NOT NULL,
  `segment_id` int NOT NULL,
  `version` bigint NOT NULL,
  `TS` timestamp NOT NULL,
  PRIMARY KEY (`segment_uuid`),
  KEY `node_id` (`node_id`),
  KEY `segment_id` (`segment_id`),
  CONSTRAINT `FK_segment_loading_node` FOREIGN KEY (`node_id`) REFERENCES `node` (`id`),
  CONSTRAINT `FK_segment_loading_segment_info` FOREIGN KEY (`segment_id`) REFERENCES `segment_info` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Data exporting was unselected.

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
