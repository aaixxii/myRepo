Hibernate4ExampleUsingPostgreSQL
================================

This application demonistrates the How to interact with the PostgreSQL db by using Hibernate.
