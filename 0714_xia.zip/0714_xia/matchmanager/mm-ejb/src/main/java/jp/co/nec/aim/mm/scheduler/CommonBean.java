package jp.co.nec.aim.mm.scheduler;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.constants.SchedulerEnum;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.MMEventsDao;
import jp.co.nec.aim.mm.dao.MatchManagerDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.entities.MatchManagerEntity;
import jp.co.nec.aim.mm.entities.MmEventEntity;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author jinxl
 * 
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class CommonBean {
	private static final Logger log = LoggerFactory.getLogger(CommonBean.class);

	private SystemConfigDao systemConfigDao;
	private MMEventsDao mmEventsDao;
	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;
	@PersistenceContext(unitName = "AIMDB")
	private EntityManager entityManager;
	private MatchManagerDao mmDao;
	private DateDao dateDao;

	/**
	 * CommonBean
	 */
	public CommonBean() {
	}

	@PostConstruct
	public void init() {
		systemConfigDao = new SystemConfigDao(entityManager);
		mmEventsDao = new MMEventsDao(entityManager);
		mmDao = new MatchManagerDao(entityManager);
		dateDao = new DateDao(dataSource);
	}

	/**
	 * checkAndRescheduleJob
	 */
	public void checkAndRescheduleJob(SchedulerEnum currentScheduler) {
		if (log.isDebugEnabled()) {
			log.debug("checkAndRescheduleJob start..");
		}
		/* loop SchedulerEnum.values(); */
		MMConfigProperty mmconfigproperty = currentScheduler
				.getIntervalProperty();
		if (mmconfigproperty == null) {
			return;
		}
		/* Get Property Intervals; */
		Long lcurrent = systemConfigDao.getMMPropertyLong(mmconfigproperty);
		Long lorgInterval = currentScheduler.getIntervalInMillis();
		/* the older IntervalInMillis is not the same as the new one; */
		if (!lcurrent.equals(lorgInterval)) {
			/* SchedulerEnum Set IntervalInMillis */
			currentScheduler.setIntervalInMillis(lcurrent);

			/* Get delayInMillis */
			Long diffMillis = dateDao.getCurrentTimeMS().longValue()
					- currentScheduler.getCurrentTime();

			Long delayInMillis = lcurrent - diffMillis;

			/* When delayInMillis less than zero, delayInMillis Set zero. */
			delayInMillis = delayInMillis <= 0 ? 0 : delayInMillis;

			/* Set DelayMillis */
			currentScheduler.setDelayMillis(delayInMillis.intValue());

			log.info("rescheduleJob:{}, org intervalInMillis: {}, "
					+ "new intervalInMillis: {}, delayMillis: {},"
					+ "currentTime:{},lastTime:{}..", currentScheduler
					.getClazz().getSimpleName(), lorgInterval, lcurrent,
					delayInMillis, dateDao.getCurrentTimeMS().longValue(),
					currentScheduler.getCurrentTime());

			/* reScheduler */
			QuartzManager.getInstance(entityManager).reScheduler(
					currentScheduler);
		}

		if (log.isDebugEnabled()) {
			log.debug("checkAndRescheduleJob end..");
		}
	}

	/**
	 * canIDoIt
	 * 
	 * @param schedulerEnum
	 * @return
	 */
	public boolean canIDoIt(SchedulerEnum schedulerEnum) {
		if (null == schedulerEnum) {
			throw new IllegalArgumentException("schedulerEnum is null");
		}

		MmEventEntity mmEvent = mmEventsDao.getLastMmEventEntity(schedulerEnum
				.getMMEventType());
		if (mmEvent == null) {
			// First time of JobAggregation
			return true;
		}
		MatchManagerEntity mm = mmDao.createOrLookup();
		if (mmEvent.getMmId() == mm.getMmId()) {
			if (log.isDebugEnabled()) {
				// I did it last time. I'll do it next!
				log.debug(schedulerEnum.getSchedulerName()
						+ ":I did it last time. I'll do it next!");
			}
			return true;
		} else {
			if (psssedEnough(schedulerEnum)) {
				log.info("It has passed enouth. mm_id = " + mm.getMmId()
						+ " will hijack!");
				return true;
			} else {
				return false;
			}
		}
	}

	/**
	 * psssedEnough
	 * 
	 * @param schedulerEnum
	 * @return
	 */
	private boolean psssedEnough(SchedulerEnum schedulerEnum) {
		if (log.isDebugEnabled()) {
			// I did it last time. I'll do it next!
			log.debug(schedulerEnum.getSchedulerName()
					+ ":Other node did it last time. Checking for passed time.");
		}
		if (null == schedulerEnum) {
			throw new IllegalArgumentException("schedulerEnum is null");
		}

		Long limit = systemConfigDao.getMMPropertyLong(schedulerEnum
				.getLimitProperty());
		Long interval = systemConfigDao.getMMPropertyLong(schedulerEnum
				.getIntervalProperty());

		Long count = mmEventsDao.passedEnough(schedulerEnum.getMMEventType()
				.name(), limit, interval);

		if (count == 1) {
			log.info("schedulerEnum:"
					+ schedulerEnum.getClazz().getSimpleName() + " limit:"
					+ limit + " interval:" + interval);
			return true;
		} else {
			return false;
		}
	}

	/**
	 * updateLastTimeStamp
	 * 
	 * @param schedulerEnum
	 * @return
	 */
	public boolean updateLastTimeStamp(SchedulerEnum schedulerEnum) {
		if (null == schedulerEnum) {
			throw new IllegalArgumentException("schedulerEnum is null");
		}

		try {
			MatchManagerEntity mm = mmDao.createOrLookup();
			mmEventsDao.setLast(mm.getMmId(), schedulerEnum.getMMEventType());
		} catch (Exception ex) {
			log.error(
					"Exception occurred when updateLastTimeStamp, schedulerEnum: "
							+ schedulerEnum.name(), ex);
			return false;
		}
		return true;
	}
}
