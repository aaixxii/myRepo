package jp.co.nec.aim.mm.procedure;

import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

public class UpdateInquiryTrafficProcedure extends StoredProcedure {
	private static final String SQL = "update_inquiry_traffic";
	private long topJobId;

	public UpdateInquiryTrafficProcedure(DataSource dataSource) {
		setDataSource(dataSource);
		setSql(SQL);
		declareParameter(new SqlParameter("p_top_job_id", Types.INTEGER));
		compile();
	}

	public void updateInquiryTraffic(long topJobId) throws DataAccessException,
			SQLException {
		if (topJobId < 0) {
			throw new IllegalArgumentException("topJobId is null or empty"
					+ " when updateInquiryTraffic");
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("p_top_job_id", topJobId);
		execute(map);
	}

	public long getTopJobId() {
		return topJobId;
	}

	public void setTopJobId(long topJobId) {
		this.topJobId = topJobId;
	}

}
