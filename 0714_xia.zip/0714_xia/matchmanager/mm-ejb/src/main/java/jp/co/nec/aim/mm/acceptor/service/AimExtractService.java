package jp.co.nec.aim.mm.acceptor.service;

import java.io.IOException;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;
import javax.xml.bind.JAXBException;

import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.JobState;
import jp.co.nec.aim.mm.constants.MMConfigProperty;
import jp.co.nec.aim.mm.constants.UidRequestType;
import jp.co.nec.aim.mm.dao.FEJobDao;
import jp.co.nec.aim.mm.dao.FunctionDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.entities.FeJobPayloadEntity;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.entities.FunctionTypeEntity;
import jp.co.nec.aim.mm.exception.ArgumentException;
import jp.co.nec.aim.mm.exception.DataBaseException;
import jp.co.nec.aim.mm.exception.XmlException;
import jp.co.nec.aim.mm.jms.JmsSender;
import jp.co.nec.aim.mm.jms.NotifierEnum;
import jp.co.nec.aim.mm.util.XmlUtil;
import jp.co.nec.aim.mm.validator.AcceptorValidator;

/**
 * AimExtractService <br>
 * The main work flow of Extract <br>
 * 
 * Include following public method:
 * <p>
 * extract, getJobStatus, listJobIds, deleteJob clearJobs, getJobBinary,
 * getJobResult
 * <p>
 * 
 * @author xiazp
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AimExtractService {
	/** log instance **/
	private static Logger log = LoggerFactory.getLogger(AimExtractService.class);	
	@PersistenceContext(unitName = "AIMDB")
	private EntityManager manager;	

	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;
	private FunctionDao functionDao;
	private SystemConfigDao configDao;
	private FEJobDao feJobDao;
	// private DateDao dateDao;

	/**
	 * AimExtractService constructor
	 */
	public AimExtractService() {
	}

	@PostConstruct
	private void init() {
		functionDao = new FunctionDao(manager);
		configDao = new SystemConfigDao(manager);
		feJobDao = new FEJobDao(manager);
		// dateDao = new DateDao(dataSource);

	}

	/**
	 * the main work flow of extract
	 * 
	 * @param request
	 *            PBExtractJobRequest instance
	 * @return PBExtractJobResponse instance
	 * @throws IOException 
	 * @throws JAXBException
	 * @throws UnsupportedEncodingException
	 */

	public Long extract(String extractRequest, boolean isFromServlet) throws IOException {
		if (StringUtils.isBlank(extractRequest)) {
			throw new XmlException("extract request is empty");
		}	
		if (log.isDebugEnabled()) {
			log.debug(extractRequest);
		}
		String requestId = XmlUtil.getRequestId(extractRequest);
		String cmd = XmlUtil.getXmlCmd(extractRequest);
		String refId = XmlUtil.getRefId(extractRequest, UidRequestType.Quality.name());
		String refUrl = XmlUtil.getUrl(extractRequest, UidRequestType.Quality.name());
		
		AcceptorValidator.checkExtractRequest(extractRequest, requestId, cmd, refId, refUrl);
		if (!StringUtils.isBlank(refId)) {
			if (feJobDao.hasTempalte(refId)) {
				log.info("There is a result in mm db for requestId:{}, get it's result from db..", requestId);
				try {					
				} catch (Exception e) {
					List<FeJobQueueEntity> resultList = feJobDao.getExResult(refId);
					if (resultList != null && resultList.size() > 0) {
						FeJobQueueEntity extjobEntity = resultList.get(0);
						String extResult = extjobEntity.getResult();
						log.info("prepare to send extract result to amq, jobId:{}", extjobEntity.getLotJobId());
						return extjobEntity.getLotJobId();
					}
				}				
			}
		}
		
		final FeJobQueueEntity ejq = new FeJobQueueEntity();
		FunctionTypeEntity fte = functionDao.getExtractFunction();
		if (fte == null) {
			AimError aimErr = AimError.EXTRACT_FUNCTION_TYPE_NOT_FOUND;
			String errMsg = String.format(aimErr.getMessage() + " . Function Type is null.");			
			aimErr.setMessage(errMsg);
			throw new DataBaseException(aimErr.getErrorCode(), aimErr.getMessage(), String.valueOf(System.currentTimeMillis()), aimErr.getUidCode());
		}
		
		ejq.setFunctionId((int) fte.getId());
		ejq.setReferenceId(refId);
		ejq.setStatus(JobState.QUEUED);
		ejq.setRequestId(requestId);
		ejq.setRequestType(UidRequestType.Quality.name());
		ejq.setFailureCount(0L);
		Integer priority = configDao.getMMPropertyInt(MMConfigProperty.EXTRACT_DEFAULTS_PRIORITY);
		ejq.setPriority(priority);
		ejq.setSubmissionTs(System.currentTimeMillis());
		manager.flush();
		manager.persist(ejq);

		FeJobPayloadEntity epe = new FeJobPayloadEntity();
		epe.setPayload(extractRequest);
		epe.setJobId(ejq.getId());
		manager.persist(epe);
		// send event to extract planner
		JmsSender.getInstance().sendToFEJobPlanner(NotifierEnum.ExtractService,
				String.format("create extract job id: %s", ejq.getId()));

		Long efJobId = Long.valueOf(ejq.getId());
		return efJobId;
//		long extractJobWaitTime = configDao.getMMPropertyLong(INTERVAL_CLIENT_EXTRACT_RESPONSE_TIMEOUT);
//		Optional<String> xmlResultOptional = null;		
//		try {
//			Object extLocker = new Object();
//			AimManager.saveExtractClientJobLocker(efJobId, extLocker);
//			synchronized (extLocker) {
//				long startGetExtResultTime = System.currentTimeMillis();
//				log.info("Go to waiting extractjob results! jobId={}", efJobId);
//				try {
//					extLocker.wait(extractJobWaitTime);
//				} catch (InterruptedException e) {
//					log.error(e.getMessage(), e);
//					Thread.currentThread().interrupt();
//					AimError aimEx = AimError.EXTRACT_INTERNAL;
//					String errMsg = String.format(e.getMessage(), "extract job internal erro.");
//					aimEx.setMessage(errMsg);
//					xmlResult = buildFaildXmlRespose(requestId, "2", aimEx.getUidCode());					
//				}
//				try {
//					xmlResultOptional = Optional.ofNullable(AimManager.getExtractClientResponse(efJobId));
//				} catch (NullPointerException e) {
//					log.warn("can't get extractResponse, it may be timeout.");
//					AimError timeoutEx = AimError.JOB_TIMEOUT;
//					String errMsg = String.format(e.getMessage(), "extract job timeout.");
//					timeoutEx.setMessage(errMsg);
//					xmlResult = buildFaildXmlRespose(requestId, "2", timeoutEx.getUidCode());
//				}
//
//				if (xmlResultOptional.isPresent()) {
//					log.info("Get job({}) result success", efJobId);
//					long endGetResultTime = System.currentTimeMillis();
//					log.info("*****MM get job results used time = {}****", endGetResultTime - startGetExtResultTime);
//					xmlResult = xmlResultOptional.get();
//				} else {
//					log.warn("Got empty extractResponse, key={}", efJobId);
//					long currentTime = System.currentTimeMillis();
//					if (currentTime - startGetExtResultTime >= extractJobWaitTime) {
//						log.warn("Timeout is happend! the waiting time = ({}), jobId({})",
//								currentTime - startGetExtResultTime, efJobId);
//						AimError timeoutEx = AimError.JOB_TIMEOUT;
//						String errMsg = String.format(timeoutEx.getMessage(), "extract job timeout.");
//						timeoutEx.setMessage(errMsg);
//						xmlResult = buildFaildXmlRespose(requestId, "2", timeoutEx.getUidCode());
//					}
//				}
//			}
//			AimManager.finishExtractClientJob(efJobId);
//		} catch (Exception ex) {
//			AimError aimEx = AimError.EXTRACT_INTERNAL;
//			String errMsg = String.format(aimEx.getMessage(), "extract job internal error.");
//			aimEx.setMessage(errMsg);
//			xmlResult = buildFaildXmlRespose(requestId, "2", aimEx.getUidCode());
//		}
		
	}

	/**
	 * delete extract Job with specified job id
	 * 
	 * @param request
	 *            PBDeleteJobRequest instance
	 */
	public void deleteJob(String deleRequest) {
		if (StringUtils.isBlank(deleRequest)) {
			throw new XmlException("Delete request is empty");
		}
		String refId = null;		
		refId = XmlUtil.getRefId(deleRequest, UidRequestType.Quality.name());

		if (StringUtils.isBlank(refId)) {
			AimError referIdErr = AimError.MISS_REFERENCE_ID_ERROR;
			String errMsg = String.format(referIdErr.getMessage() + " . Can not found referenceId in DeleteJobRequest");
			referIdErr.setMessage(errMsg);
			throw new ArgumentException(referIdErr.getErrorCode(), referIdErr.getMessage(),
					String.valueOf(System.currentTimeMillis()), referIdErr.getUidCode());
		}
		try {
			int deleteCout = feJobDao.delExtJobByRefId(refId);
			if (deleteCout < 1) {
				log.warn("delete count={}", deleteCout);
			} else {
				log.info("success delete extractJob,deleteCount={}", deleteCout);
			}
		} catch (Exception ex) {
			log.error(ex.getMessage());
		}
	}

	/**
	 * clear all extract Jobs
	 */
	public void clearJobs() {
		try {
			int clearCount = feJobDao.clearJobs();
			log.info("clear job count={}", clearCount);
		} catch (Exception ex) {
			log.error(ex.getMessage());
		}
	}
	
	@SuppressWarnings("unused")
	private String buildFaildXmlRespose(String requestId , String success, String failureReason) throws IOException {
		 Document document = DocumentHelper.createDocument();
		 Element root = document.addElement( "Response")
				 .addAttribute("requestId", requestId)
				 .addAttribute("timeStamp", String.valueOf(System.currentTimeMillis()));
		 root.addElement("Return").addAttribute("value", String.valueOf(success));
		 root.addElement("Return").addAttribute("failureReason", String.valueOf(failureReason));
		 OutputFormat format = OutputFormat.createPrettyPrint();
		 StringWriter sw = new StringWriter();
       XMLWriter writer  = new XMLWriter(sw, format);        
       writer.write(document);
       String resuslt = sw.toString();		 
		return resuslt;		
	}
}
