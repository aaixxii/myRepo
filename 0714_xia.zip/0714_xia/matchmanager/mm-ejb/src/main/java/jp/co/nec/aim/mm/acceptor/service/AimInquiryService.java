package jp.co.nec.aim.mm.acceptor.service;

import static jp.co.nec.aim.mm.constants.MMConfigProperty.INTERVAL_CLIENT_SYNC_RESPONSE_TIMEOUT;

import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;

import jp.co.nec.aim.message.proto.AIMMessages.PBMuExtractJobResultItem;
import jp.co.nec.aim.mm.acceptor.AimInquiryRequest;
import jp.co.nec.aim.mm.acceptor.CommonOptions;
import jp.co.nec.aim.mm.acceptor.Inquiry;
import jp.co.nec.aim.mm.constants.AimError;
import jp.co.nec.aim.mm.constants.UidRequestType;
import jp.co.nec.aim.mm.dao.DateDao;
import jp.co.nec.aim.mm.dao.FEJobDao;
import jp.co.nec.aim.mm.dao.FunctionDao;
import jp.co.nec.aim.mm.dao.InquiryJobDao;
import jp.co.nec.aim.mm.dao.PersonBiometricDao;
import jp.co.nec.aim.mm.dao.SystemConfigDao;
import jp.co.nec.aim.mm.entities.FeJobQueueEntity;
import jp.co.nec.aim.mm.entities.FunctionTypeEntity;
import jp.co.nec.aim.mm.entities.PersonBiometricEntity;
import jp.co.nec.aim.mm.exception.AimIdnetifyException;
import jp.co.nec.aim.mm.exception.ExceptionHelper;
import jp.co.nec.aim.mm.procedure.FeJobProcedures;
import jp.co.nec.aim.mm.sessionbeans.DmServiceBean;
import jp.co.nec.aim.mm.sessionbeans.pojo.AimManager;
import jp.co.nec.aim.mm.util.XmlUtil;
import jp.co.nec.aim.mm.validator.AcceptorValidator;

/**
 * The main work flow of inquiry <br>
 * 
 * Include following public method:
 * <p>
 * inquiry, getJobStatus, listJobIds, deleteJob clearJobs, getJobResult,
 * getJobResult
 * <p>
 * 
 * @author xiazp
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AimInquiryService {
	/** log instance **/
	private static Logger log = LoggerFactory.getLogger(AimInquiryService.class);

	@PersistenceContext(unitName = "AIMDB")
	private EntityManager manager;

	@Resource(mappedName = "java:jboss/MySqlDS")
	private DataSource dataSource;
	@EJB
	DmServiceBean dmServiceBean;
	@EJB
	private Inquiry inquiry;
	private InquiryJobDao inquiryJobDao;
	private DateDao dateDao;
	private FEJobDao feJobDao;
	private FunctionDao functionDao;
	private SystemConfigDao sysConfigDao;
	private FeJobProcedures feJobProcedures;
	private PersonBiometricDao personBiometricDao;
	private ExceptionHelper exception;

	/**
	 * AimInquiryService default constructor
	 */
	public AimInquiryService() {
	}

	@PostConstruct
	private void init() {
		this.inquiryJobDao = new InquiryJobDao(manager, dataSource);
		this.dateDao = new DateDao(dataSource);
		this.feJobDao = new FEJobDao(manager);
		this.functionDao = new FunctionDao(manager);
		this.sysConfigDao = new SystemConfigDao(manager);
		this.feJobProcedures = new FeJobProcedures(dataSource);
		this.personBiometricDao = new PersonBiometricDao(manager);
		this.exception = new ExceptionHelper(dateDao);
	}

	/**
	 * The main work flow of inquiry
	 * 
	 * @param request
	 *            PBInquiryJobRequest instance
	 * @param isFromServlet
	 *            IS called by SERVLET
	 * @return PBInquiryJobResponse instance
	 * @throws IOException
	 */
	public Long inquiry(final String inqRequest, boolean isFromServlet) {
		if (log.isDebugEnabled()) {
			log.debug(inqRequest);
		}		
		String requestId = XmlUtil.getRequestId(inqRequest);
		String cmd = XmlUtil.getXmlCmd(inqRequest);
		String refId = XmlUtil.getRefId(inqRequest, UidRequestType.Identify.name());
		String refUrl = XmlUtil.getUrl(inqRequest, UidRequestType.Identify.name());
		String maxResults = XmlUtil.getIdentifyAtribute(inqRequest, "maxResults");
		AcceptorValidator.checkInquiryRequest(inqRequest, requestId, cmd, refId, refUrl, maxResults);
		Long jobId = null;
		final CommonOptions options = new CommonOptions();
		options.setFromServlet(isFromServlet);
		options.setFunctioName("MI");
		options.setMaxCandidates(Integer.valueOf(maxResults));
		AimInquiryRequest aimInquiryRequest = null;
		byte[] templateData = null;
		if (!StringUtils.isBlank(refId)) {
			templateData = tryGetTemplateFromFeQueue(refId);
			if (templateData == null) {
				PersonBiometricEntity psEntity = personBiometricDao.isHaveBioMetricDataInMyTable(refId);
				if (psEntity != null) {
					try {
						templateData = dmServiceBean.getTemplate(refId);
					} catch (Exception e) {
						AimError aimErr = AimError.INQ_JOB_DM_SERVICE_ERR;
						throw new AimIdnetifyException(aimErr.getMessage(), aimErr.getErrorCode(),
								String.valueOf(System.currentTimeMillis()), aimErr.getUidCode());
					}
				}
			}
		}

		if (templateData == null && !StringUtils.isBlank(refId) && !StringUtils.isBlank(refUrl)) {
			templateData = doExtract(inqRequest, refId, requestId, refUrl);
			if (templateData == null) {
				log.warn("Get template by extracting is faild!");
				AimError aimErr = AimError.EXTRACT_INTERNAL;
				throw new AimIdnetifyException(aimErr.getMessage(), aimErr.getErrorCode(),
						String.valueOf(System.currentTimeMillis()), aimErr.getUidCode());
			}
		}

		if (templateData != null && templateData.length > 1) {
			aimInquiryRequest = new AimInquiryRequest("MI", Integer.valueOf(1), requestId, inqRequest, templateData);
			jobId = doGetIdentifyResponse(aimInquiryRequest, options);
		}
		return jobId;
	}

	private byte[] tryGetTemplateFromFeQueue(String refId) {
		byte[] data = null;
		List<FeJobQueueEntity> resultList = feJobDao.getExResult(refId);
		if (resultList != null && resultList.size() > 0) {
			data = resultList.get(0).getTempalteData();
		}
		return data;
	}

	private Long doGetIdentifyResponse(final AimInquiryRequest aimInquiryRequest, final CommonOptions options) {
		String requestId = aimInquiryRequest.getRequestId();
		final List<AimInquiryRequest> aimRequestList = Lists.newArrayList();
		aimRequestList.add(aimInquiryRequest);
		long jobId = inquiry.inquiry(aimRequestList, requestId, options);
		return Long.valueOf(jobId);
		// UidAimAmqResponse aqmRes = null;
		// long identifyJobWaitTime =
		// sysConfigDao.getMMPropertyLong(INTERVAL_CLIENT_SEARCH_RESPONSE_TIMEOUT);
		// Optional<UidAimAmqResponse> identifyResponse = null;
		// String topJobId = String.valueOf(jobId);
		// Object idyLocker = new Object();
		// AimManager.saveInquryClientJobLocker(topJobId, idyLocker);
		// synchronized (idyLocker) {
		// long startGetExtResultTime = System.currentTimeMillis();
		// log.info("Go to waiting identifyjob results! jobId={}", topJobId);
		// try {
		// idyLocker.wait(identifyJobWaitTime);
		// } catch (InterruptedException e) {
		// log.error(e.getMessage(), e);
		// Thread.currentThread().interrupt();
		// }
		// try {
		// identifyResponse =
		// Optional.ofNullable(AimManager.getIdentifyClientResponse(topJobId));
		// } catch (NullPointerException e) {
		// log.warn("can't get identifyResponse, it may be timeout.");
		// AimError aimErr = AimError.INQ_INTERNAL;
		// String errMsg = String.format(e.getMessage(), "inquriy job internal
		// error.");
		// aimErr.setMessage(errMsg);
		// aqmRes = new UidAimAmqResponse();
		// String xmlRes = null;
		// try {
		// xmlRes = XmlUtil.dom4jCreateResponseXml(requestId, "2",
		// aimErr.getUidCode());
		// } catch (IOException e1) {
		// xmlRes = e1.getMessage();
		// }
		// aqmRes.setRequestId(requestId);
		// aqmRes.setXmlResult(xmlRes);
		//
		// }
		//
		// if (identifyResponse.isPresent()) {
		// log.info("Get job({}) result success", topJobId);
		// long endGetResultTime = System.currentTimeMillis();
		// log.info("*****MM get job results used time = {}****",
		// endGetResultTime - startGetExtResultTime);
		// } else {
		// log.warn("Got empty identifyResponse, key={}", topJobId);
		// long currentTime = System.currentTimeMillis();
		// if (currentTime - startGetExtResultTime >= identifyJobWaitTime) {
		// log.warn("Timeout is happend! the waiting time = ({}), jobId({})",
		// currentTime - startGetExtResultTime, topJobId);
		// AimError timeoutErr = AimError.JOB_TIMEOUT;
		// String errMsg = String.format(timeoutErr.getMessage(), "inquriy job
		// timeout.");
		// timeoutErr.setMessage(errMsg);
		// aqmRes = new UidAimAmqResponse();
		// String xmlRes = null;
		// try {
		// xmlRes = XmlUtil.dom4jCreateResponseXml(requestId, "2",
		// timeoutErr.getUidCode());
		// } catch (IOException e1) {
		// xmlRes = e1.getMessage();
		// }
		// aqmRes.setRequestId(requestId);
		// aqmRes.setXmlResult(xmlRes);
		// }
		// }
		// }
		// AimManager.finishInquryClientJob(topJobId);
		// aqmRes = identifyResponse.get();
		// return aqmRes;
	}

	private byte[] doExtract(String inqRequest, String refId, String requestId, String url) {
	
		FunctionTypeEntity fte = functionDao.getExtractFunction();
		if (fte == null) {
			return null;
		}
		Long newFeJobId = null;
		try {
			newFeJobId = feJobProcedures.createNewFeJob(refId, requestId, UidRequestType.Identify.name(), inqRequest);					
			log.info("succss create feJob({})", newFeJobId);
		} catch (Exception e1) {
			feJobDao.deleteExtractJob(newFeJobId);
			return null;
		}

		Integer syncJobWaitTime = sysConfigDao.getMMPropertyInt(INTERVAL_CLIENT_SYNC_RESPONSE_TIMEOUT);
		if (Objects.isNull(syncJobWaitTime) || syncJobWaitTime < 0) {
			syncJobWaitTime = 100000;
		}
		String key = String.valueOf(newFeJobId.longValue());
		Object extractJoblocker = new Object();
		AimManager.saveToExtractLockQueue(key, extractJoblocker);
		Optional<PBMuExtractJobResultItem> onejobResult = null;
		synchronized (extractJoblocker) {
			long startGetExtResultTime = System.currentTimeMillis();
			try {
				extractJoblocker.wait(syncJobWaitTime);
			} catch (InterruptedException e) {
				log.error(e.getMessage(), e);
				Thread.currentThread().interrupt();				
			}
			try {
				onejobResult = Optional.ofNullable(AimManager.getExtractJobResult(key));
			} catch (NullPointerException e) {
				log.warn("can't get extractResponse, it may be timeout.");
				return null;
			}
			if (onejobResult.isPresent()) {
				log.info("Get inquiry by url jobId({}) result success", newFeJobId);
				long endGetResultTime = System.currentTimeMillis();
				log.info("*****MM get identify by url job results used time = {}****",
						endGetResultTime - startGetExtResultTime);
			} else {
				log.warn("Got empty PBMuExtractJobResultItem, key={}", key);
				long currentTime = System.currentTimeMillis();
				if (currentTime - startGetExtResultTime >= syncJobWaitTime) {
					log.warn("Timeout is happend! the waiting time = ({}), jobId({})",
							currentTime - startGetExtResultTime, newFeJobId);
					return null;
				}
			}
		}
		byte[] extResult = onejobResult.get().getBisonTemplate().toByteArray();
		AimManager.finishExtractJob(key);
		return extResult;
	}

	/**
	 * delete the inquiry Job with specified job id
	 * 
	 * @param request
	 *            PBDeleteJobRequest instance
	 */
	public void deleteJob(String deleRequest) {
		String requestId = XmlUtil.getRequestId(deleRequest);
		try {
			inquiryJobDao.deleteJobByRequstId(requestId);
		} catch (Exception ex) {
			exception.throwDBException(AimError.INQ_DB, ex,
					String.format("Exception occurred when when delete " + "inquiry job by requestId %s", requestId));
		}
	}

	/**
	 * clear all inquiry Jobs
	 */
	public void clearJobs() {
		try {
			inquiryJobDao.clearJobs();
		} catch (Exception ex) {
			exception.throwDBException(AimError.INQ_DB, ex, "Exception occurred when clear inquiry job.");
		}
	}
}
