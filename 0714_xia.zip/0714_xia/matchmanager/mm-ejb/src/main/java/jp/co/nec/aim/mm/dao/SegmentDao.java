package jp.co.nec.aim.mm.dao;

import javax.persistence.EntityManager;

import jp.co.nec.aim.mm.entities.SegmentEntity;

/**
 * SegmentDao
 * 
 * @author liuyq
 * 
 */
public class SegmentDao {

	private EntityManager manager;

	public SegmentDao(EntityManager manager) {
		this.manager = manager;
	}

	/**
	 * findSegment
	 * 
	 * @param segId
	 * @return SegmentEntity instance
	 */
	public SegmentEntity findSegment(long segId) {
		return manager.find(SegmentEntity.class, segId);
	}

}
