package jp.co.nec.aim.mm.acceptor;

/**
 * 
 * @author liuyq
 * 
 */
public class CommonOptions {	
	private Integer maxCandidates;
	// private Integer minScore;	
	private boolean isFromServlet;
	private String functioName;

	public Integer getMaxCandidates() {
		return maxCandidates;
	}

	public void setMaxCandidates(Integer maxCandidates) {
		this.maxCandidates = maxCandidates;
	}

	// public Integer getMinScore() {
	// return minScore;
	// }
	//
	// public void setMinScore(Integer minScore) {
	// this.minScore = minScore;
	// }	

	public boolean isFromServlet() {
		return isFromServlet;
	}

	public void setFromServlet(boolean isFromServlet) {
		this.isFromServlet = isFromServlet;
	}

	public String getFunctioName() {
		return functioName;
	}

	public void setFunctioName(String functioName) {
		this.functioName = functioName;
	}

}
