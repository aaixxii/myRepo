package jp.co.nec.aim.mm.procedure;

import java.sql.Types;
import java.util.List;

import javax.annotation.Resource;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import jp.co.nec.aim.mm.identify.dispatch.InqDispatchInfo;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.google.common.collect.Lists;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class InquiryDistributorProcedureTest {
	@Resource
	private DataSource ds;
	private InquiryDistributorProcedure inquiryDistributorProcedure;
	@Resource
	private JdbcTemplate jdbcTemplate;

	@Before
	public void setUp() throws Exception {
		inquiryDistributorProcedure = new InquiryDistributorProcedure(ds);
		jdbcTemplate.update("delete from  container_jobs");
		jdbcTemplate.update("delete from  fusion_jobs");
		jdbcTemplate.update("delete from  job_queue");
		jdbcTemplate.update("delete from  mu_job_execute_plans");
		jdbcTemplate.update("delete from  map_reducers");
		jdbcTemplate.update("delete from LAST_ASSIGNED_MR");
		jdbcTemplate.update("commit");
		jdbcTemplate
				.update("insert into job_queue(JOB_ID,UIDAI_REQUEST_ID,PRIORITY,JOB_STATE,SUBMISSION_TS,CALLBACK_STYLE,TIMEOUTS,FAILURE_COUNT,REMAIN_JOBS,FAMILY_ID)values(1,'test',5,0,123,0,10,0,0,1)");
		jdbcTemplate
				.update("insert into fusion_jobs(FUSION_JOB_ID,FUNCTION_ID,JOB_ID,INQUIRY_PROBE_DATA,SEARCH_REQUEST_INDEX)values(1,1,1,?,1)",
						new Object[] { new SqlLobValue("111"), },new int[] { Types.BLOB });
						
		jdbcTemplate
				.update("insert into fusion_jobs(FUSION_JOB_ID,FUNCTION_ID,JOB_ID,INQUIRY_PROBE_DATA,SEARCH_REQUEST_INDEX)values(2,1,1,?,1)",
						new Object[] { new SqlLobValue("2345"), },
						new int[] { Types.BLOB });

		jdbcTemplate
				.update("insert into container_jobs(CONTAINER_JOB_ID,CONTAINER_ID,FUSION_JOB_ID,PLAN_ID)values(1,1,1,1)");
		jdbcTemplate
				.update("insert into container_jobs(CONTAINER_JOB_ID,CONTAINER_ID,FUSION_JOB_ID,PLAN_ID)values(2,1,2,1)");

		jdbcTemplate
				.update("insert into map_reducers values (1,1,'192.168.1.6','192.162.1.1','WORKING',1)");
		jdbcTemplate
				.update("insert into LAST_ASSIGNED_MR values (1,11111111111)");
		jdbcTemplate.update("commit");
	}

	@After
	public void tearDown() throws Exception {

		jdbcTemplate.update("delete from  container_jobs");
		jdbcTemplate.update("delete from  fusion_jobs");
		jdbcTemplate.update("delete from  job_queue");
		jdbcTemplate.update("delete from  mu_job_execute_plans");
		jdbcTemplate.update("delete from  map_reducers");
		jdbcTemplate.update("delete from LAST_ASSIGNED_MR");
		jdbcTemplate.update("commit");

	}

	@Test
	public void testExcute() {
		inquiryDistributorProcedure.setJobId(1l);
		inquiryDistributorProcedure.setFunctionId(1);
		inquiryDistributorProcedure.setPlanId(1l);
		InqDispatchInfo info = inquiryDistributorProcedure.execute();
		List<Long> list = Lists.newArrayList();
		list.add(1l);
		list.add(1l);
		Assert.assertEquals(1, info.getRequestIndex());
		byte[] bytes = info.getInquiryData();
		System.out.println(new String(bytes));
		Assert.assertEquals("111", new String(bytes));
	}

	/*
	 * @Test public void testExcutePanIdIsNotExist() {
	 * inquiryDistributorProcedure.setPlanId(1); InqDispatchInfo info =
	 * inquiryDistributorProcedure.execute(); Assert.assertEquals(null, info); }
	 */

	public static void main(String[] args) {
		for (byte b : "111".getBytes()) {
			System.out.println(b);
		}
	}

}
