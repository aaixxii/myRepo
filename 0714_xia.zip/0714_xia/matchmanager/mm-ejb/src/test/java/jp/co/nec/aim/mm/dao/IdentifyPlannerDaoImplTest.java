package jp.co.nec.aim.mm.dao;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.sql.DataSource;

import jp.co.nec.aim.mm.entities.ContainerJobEntity;
import jp.co.nec.aim.mm.entities.ExecutePlanEntity;
import jp.co.nec.aim.mm.entities.JobQueueEntity;
import jp.co.nec.aim.mm.identify.planner.JobInfoFromDB;
import jp.co.nec.aim.mm.identify.planner.MuCpuAndPressure;
import jp.co.nec.aim.mm.identify.planner.MuSegmentMap;
import jp.co.nec.aim.mm.identify.planner.SegmentIdAndVeison;
import jp.co.nec.aim.mm.identify.planner.TopJobInfo;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class IdentifyPlannerDaoImplTest extends
		AbstractTransactionalJUnit4SpringContextTests {

	@PersistenceContext(unitName = "AIMDB")
	protected EntityManager entityManager;
	@Resource(mappedName = "java:jboss/MySqlDS")
	protected DataSource dataSource;
	@Resource
	protected JdbcTemplate jdbcTemplate;
	private IdentifyPlannerDao identifyPlannerDao;

	@Before
	public void setUp() throws Exception {
		identifyPlannerDao = new IdentifyPlannerDaoImpl(dataSource,
				entityManager);
		jdbcTemplate.execute("delete from job_queue");
		jdbcTemplate.execute("delete from match_units");
		jdbcTemplate.execute("delete from mu_inquiry_load");
		jdbcTemplate.execute("delete from segments");
		jdbcTemplate.execute("delete from resource_update_count");
		jdbcTemplate.execute("delete from map_reducers");
		jdbcTemplate.execute("delete from mu_eligible_containers");
		jdbcTemplate.execute("delete from mu_eligible_functions");
		jdbcTemplate.execute("delete from mu_seg_reports");
		jdbcTemplate.execute("delete from mu_job_execute_plans");
		jdbcTemplate.execute("delete segment_defragmentation");
		jdbcTemplate.execute("commit");
	}

	@After
	public void tearDown() throws Exception {
		identifyPlannerDao = null;
		jdbcTemplate.execute("delete from job_queue");
		jdbcTemplate.execute("delete from match_units");
		jdbcTemplate.execute("delete from mu_inquiry_load");
		jdbcTemplate.execute("delete from segments");
		jdbcTemplate.execute("delete from resource_update_count");
		jdbcTemplate.execute("delete from map_reducers");
		jdbcTemplate.execute("delete from mu_eligible_containers");
		jdbcTemplate.execute("delete from mu_eligible_functions");
		jdbcTemplate.execute("delete from mu_seg_reports");
		jdbcTemplate.execute("delete from mu_job_execute_plans");
		jdbcTemplate.execute("delete segment_defragmentation");
		jdbcTemplate.execute("commit");
	}

	@Test
	public void testGetSegmentVersionByContainerId_normal()
			throws PersistenceException, SQLException {
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,'working',4)";

		String segSql = "insert into segments (SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,"
				+ "BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)"
				+ " values(?, ?, 1, 10, 10, 10, ?, 1, 100)";

		Integer containerId = 1;
		Integer[] muIds = { 1, 2, 3, 4 };
		Long[] segIds = { 1000L, 1001L, 1002L, 1003L, 1004L, 1005L, 1006L,
				1007L };
		Long[] segVer = { 1L, 1L, 2L, 2L, 3L, 4L, 5L, 6L };

		for (int i = 0; i < muIds.length; i++) {
			jdbcTemplate.update(
					muSql,
					new Object[] { muIds[i],
							String.valueOf(muIds[i].longValue()) });

		}
		for (int i = 0; i < segIds.length; i++) {
			jdbcTemplate.update(segSql, new Object[] { segIds[i], containerId,
					segVer[i] });
		}
		jdbcTemplate.execute("commit");
		List<SegmentIdAndVeison> results = identifyPlannerDao
				.getSegmentVersionByContainerId(containerId);
		Assert.assertEquals(8, results.size());
		for (int i = 0; i < results.size(); i++) {
			Assert.assertEquals(segIds[i], results.get(i).getSegmentId());
			Assert.assertEquals(segVer[i], results.get(i).getVersion());
		}
	}

	@Test
	public void testGetSegmentVersionByContainerId_no_data()
			throws PersistenceException, SQLException {
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,'working',4)";

		String segSql = "insert into segments (SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,"
				+ "BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)"
				+ " values(?, ?, 1, 10, 10, 10, ?, 1, 100)";

		Integer containerId = 1;
		Integer[] muIds = { 1, 2, 3, 4 };
		Long[] segIds = { 1000L, 1001L, 1002L, 1003L, 1004L, 1005L, 1006L,
				1007L };
		Long[] segVer = { 1L, 1L, 2L, 2L, 3L, 4L, 5L, 6L };

		for (int i = 0; i < muIds.length; i++) {
			jdbcTemplate.update(
					muSql,
					new Object[] { muIds[i],
							String.valueOf(muIds[i].longValue()) });

		}
		for (int i = 0; i < segIds.length; i++) {
			jdbcTemplate.update(segSql, new Object[] { segIds[i], containerId,
					segVer[i] });
		}
		jdbcTemplate.execute("commit");
		List<SegmentIdAndVeison> results = identifyPlannerDao
				.getSegmentVersionByContainerId(containerId + 1);
		Assert.assertEquals(0, results.size());
	}

	@Test
	public void testGetNewMuSegMaps_normal() {
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,'WORKING',4)";

		String segSql = "insert into segments (SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,"
				+ "BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)"
				+ " values(?, ?, 1, 10, 10, 10, ?, 1, 100)";

		String mecSql = " insert into MU_ELIGIBLE_CONTAINERS(CONTAINER_ID,MU_ID) values(?,?)";
		String mefSql = "insert into MU_ELIGIBLE_FUNCTIONS( FUNCTION_ID,MU_ID) values(?,?)";
		String muSegReportSql = "insert into mu_seg_reports(mu_id,segment_id,status,segment_version) values(?,?,1,?)";
		String defragBeanSql = "insert into segment_defragmentation(container_id,start_ts,end_ts) values(5,2000,3000)";

		Integer containerId = 1;
		Integer functionId = 1;
		Integer[] muIds = { 1, 2, 3, 4 };
		Long[] segIds = { 1000L, 1001L, 1002L, 1003L, 1004L, 1005L, 1006L,
				1007L };
		Long[] segVer = { 1L, 1L, 2L, 2L, 3L, 4L, 5L, 6L };

		for (int i = 0; i < muIds.length; i++) {
			jdbcTemplate.update(
					muSql,
					new Object[] { muIds[i],
							String.valueOf(muIds[i].longValue()) });
			jdbcTemplate.update(mecSql, new Object[] { containerId, muIds[i] });
			jdbcTemplate.update(mefSql, new Object[] { functionId, muIds[i] });
		}

		for (int i = 0; i < segIds.length; i++) {
			jdbcTemplate.update(segSql, new Object[] { segIds[i], containerId,
					segVer[i] });
		}
		int currentMu = 0;
		for (int i = 0; i < segIds.length; i++) {
			if (currentMu >= muIds.length) {
				currentMu = 0;
			}
			jdbcTemplate.update(muSegReportSql, new Object[] {
					muIds[currentMu], segIds[i], segVer[i] });
			currentMu++;
		}
		jdbcTemplate.update(defragBeanSql);
		jdbcTemplate.update("commit");

		try {
			List<MuSegmentMap> results = identifyPlannerDao.getNewMuSegMaps(
					containerId, functionId);
			Assert.assertNotNull(results);
			Assert.assertEquals(8, results.size());

			for (int i = 0; i < results.size(); i++) {

				Assert.assertNotNull(results.get(i).getMuId());
				Assert.assertNotNull(results.get(i).getSegmentId());
				Assert.assertNotNull(results.get(i).getSegmentVersion());
				Assert.assertNotNull(results.get(i).getContainerId());
				Assert.assertNotNull(results.get(i).getFunctionId());

			}
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testGetNewMuSegMaps_no_data() {
		String muSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_EXTRACTORS) "
				+ "VALUES(?,?,'WORKING',4)";

		String segSql = "insert into segments (SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,"
				+ "BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)"
				+ " values(?, ?, 1, 10, 10, 10, ?, 1, 100)";

		String mecSql = " insert into MU_ELIGIBLE_CONTAINERS(CONTAINER_ID,MU_ID) values(?,?)";
		String mefSql = "insert into MU_ELIGIBLE_FUNCTIONS( FUNCTION_ID,MU_ID) values(?,?)";
		String muSegReportSql = "insert into mu_seg_reports(mu_id,segment_id,status,segment_version) values(?,?,1,?)";

		Integer containerId = 1;
		Integer functionId = 1;
		Integer[] muIds = { 1, 2, 3, 4 };
		Long[] segIds = { 1000L, 1001L, 1002L, 1003L, 1004L, 1005L, 1006L,
				1007L };
		Long[] segVer = { 1L, 1L, 2L, 2L, 3L, 4L, 5L, 6L };

		for (int i = 0; i < muIds.length; i++) {
			jdbcTemplate.update(
					muSql,
					new Object[] { muIds[i],
							String.valueOf(muIds[i].longValue()) });
			jdbcTemplate.update(mecSql, new Object[] { containerId, muIds[i] });
			jdbcTemplate.update(mefSql, new Object[] { functionId, muIds[i] });
		}

		for (int i = 0; i < segIds.length; i++) {
			jdbcTemplate.update(segSql, new Object[] { segIds[i], containerId,
					segVer[i] });
		}
		int currentMu = 0;
		for (int i = 0; i < segIds.length; i++) {
			if (currentMu >= muIds.length) {
				currentMu = 0;
			}
			jdbcTemplate.update(muSegReportSql, new Object[] {
					muIds[currentMu], segIds[i], segVer[i] });
			currentMu++;
		}

		jdbcTemplate.update("commit");

		try {
			List<MuSegmentMap> results = identifyPlannerDao.getNewMuSegMaps(
					containerId + 1, functionId);
			Assert.assertNull(results);
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testGetLimitedJobsByFamiliy_normal() {
		String jobQueueSql = "insert into job_queue(job_id,priority,job_state,submission_ts,callback_style,failure_count,remain_jobs,family_id)"
				+ " values(?,?,0,3000,0,?,0,?)";
		Integer[] jobIds = { 1000, 1001, 1002, 1003, 1004 };
		BigDecimal[] priority = { new BigDecimal(1), new BigDecimal(1),
				new BigDecimal(1), new BigDecimal(2), new BigDecimal(1) };
		BigDecimal[] failureCount = { new BigDecimal(3), new BigDecimal(2),
				new BigDecimal(0), new BigDecimal(0), new BigDecimal(0) };
		BigDecimal[] familyIds = { new BigDecimal(1), new BigDecimal(1),
				new BigDecimal(1), new BigDecimal(1), new BigDecimal(1) };
		for (int i = 0; i < jobIds.length; i++) {
			jdbcTemplate.update(jobQueueSql, new Object[] { jobIds[i],
					priority[i], failureCount[i], familyIds[i] });
		}
		String updateIdenityTrafficSql = "update inquiry_traffic set JOB_EXEC_COUNT= 0";
		jdbcTemplate.update(updateIdenityTrafficSql);
		jdbcTemplate.update("commit");
		try {
			List<Long> results = identifyPlannerDao.getLimitedJobsByFamiliy();
			Assert.assertNotNull(results);
			Assert.assertTrue(results.size() > 0);
			Collections.sort(results);
			for (int i = 0; i < results.size(); i++) {
				Assert.assertEquals(jobIds[i].intValue(), results.get(i)
						.intValue());
			}
		} catch (DataAccessException e) {

			e.printStackTrace();
		}
	}

	@Test
	public void testGetLimitedJobsByFamiliy_null() {
		try {
			List<Long> results = identifyPlannerDao.getLimitedJobsByFamiliy();
			Assert.assertNull(results);
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testGetLimitedJobsByFamiliy_remainJob0() {
		String jobQueueSql = "insert into job_queue(job_id,priority,job_state,submission_ts,callback_style,failure_count,remain_jobs,family_id)"
				+ " values(?,?,2,3000,0,?,0,?)";
		Integer[] jobIds = { 1000, 1001, 1002, 1003, 1004 };
		BigDecimal[] priority = { new BigDecimal(1), new BigDecimal(1),
				new BigDecimal(1), new BigDecimal(2), new BigDecimal(1) };
		BigDecimal[] failureCount = { new BigDecimal(3), new BigDecimal(2),
				new BigDecimal(0), new BigDecimal(0), new BigDecimal(0) };
		BigDecimal[] familyIds = { new BigDecimal(1), new BigDecimal(1),
				new BigDecimal(1), new BigDecimal(1), new BigDecimal(1) };
		for (int i = 0; i < jobIds.length; i++) {
			jdbcTemplate.update(jobQueueSql, new Object[] { jobIds[i],
					priority[i], failureCount[i], familyIds[i] });
		}

		String updateIdenityTrafficSql = "update inquiry_traffic  set JOB_EXEC_COUNT= 1000";
		jdbcTemplate.update(updateIdenityTrafficSql);
		jdbcTemplate.update("commit");
		try {
			List<Long> results = identifyPlannerDao.getLimitedJobsByFamiliy();
			Assert.assertNull(results);
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
		String recoverSql = "update inquiry_traffic  set JOB_EXEC_COUNT= 0";
		jdbcTemplate.update(recoverSql);
		jdbcTemplate.update("commit");
	}

	@Test
	public void testUpdateAfterPlanned() {
		String jobQueueSql = "insert into job_queue(job_id,priority,job_state,submission_ts,callback_style,failure_count,remain_jobs,family_id)"
				+ " values(?,1,0,3000,0,0,1,1)";
		String fusionJobSql = "insert into fusion_jobs(fusion_job_id,function_id,job_id,search_request_index) values(?,1,?,?)";
		String contaiJobSql = "insert into container_jobs(container_job_id,container_id,fusion_job_id,job_state) values(?,?,?,0)";
		Long jobId = 10L;
		Long[] fusionJobId = { 200L, 201L };
		Long[] containerJobId = { 300L, 301L };
		Integer containerId = 1;
		Integer functionId = 1;
		String planStrings = "abcdefjhijklmnopqrstuvwxyz";

		jdbcTemplate.update(jobQueueSql, new Object[] { jobId });
		for (int i = 0; i < 2; i++) {
			jdbcTemplate.update(fusionJobSql, new Object[] { fusionJobId[i],
					jobId, new Integer(i) });
			jdbcTemplate.update(contaiJobSql, new Object[] { containerJobId[i],
					containerId, fusionJobId[i] });
		}
		jdbcTemplate.update("commit");
		Long results = null;
		try {
			results = identifyPlannerDao.updateAfterPlanned(jobId,
					containerId, containerJobId[0].longValue(), functionId,
					planStrings);
		} catch (DataAccessException e) {
			e.printStackTrace();
		}
		Assert.assertNotNull(results);
		String selectJobQueue = "select failure_count from job_queue where job_id = ?";
		String getMaxPlanId = "select max(plan_id) from mu_job_execute_plans";
		Integer failureCount = jdbcTemplate.queryForObject(selectJobQueue,
				new Object[] { jobId }, Integer.class);
		Long planId = jdbcTemplate.queryForObject(getMaxPlanId, Long.class);

		JobQueueEntity jobQueue = entityManager.find(JobQueueEntity.class,
				jobId.longValue());
		Assert.assertEquals(1, jobQueue.getJobState().ordinal());
		Assert.assertNotNull(jobQueue.getAssignedTs());

		ContainerJobEntity containerJob1 = entityManager.find(
				ContainerJobEntity.class, containerJobId[0]);
		Assert.assertEquals(1, containerJob1.getJobState().ordinal());
		Assert.assertEquals(planId, containerJob1.getPlanId());

		ContainerJobEntity containerJob2 = entityManager.find(
				ContainerJobEntity.class, containerJobId[0]);
		Assert.assertEquals(1, containerJob2.getJobState().ordinal());
		Assert.assertEquals(planId, containerJob2.getPlanId());

		ExecutePlanEntity jobPlan = entityManager.find(ExecutePlanEntity.class,
				planId);
		Assert.assertEquals(planId.longValue(), jobPlan.getPlanId());
		Assert.assertEquals(failureCount.intValue() + 1,
				jobPlan.getPlanedCount());
		Assert.assertEquals(planStrings, jobPlan.getPlan());
	}

	@Test
	public void testGetJobInfoForCreatePlans_normal() {
		String jobQueueSql = "insert into job_queue(job_id,priority,job_state,submission_ts,callback_style,failure_count,remain_jobs,family_id)"
				+ " values(?,1,0,3000,0,0,0,?)";
		String fusionJobSql = "insert into fusion_jobs(fusion_job_id,function_id,job_id,search_request_index) values(?,?,?,?)";
		String contaiJobSql = "insert into container_jobs(container_job_id,container_id,fusion_job_id,job_state) values(?,?,?,0)";
		String defragBeanSql = "insert into segment_defragmentation(container_id,start_ts,end_ts) values(5,2000,3000)";

		Long[] jobIds = { 1000L, 1001L, 1002L };
		int[] familyIds = { 1, 1, 1 };
		int[] functionIds = { 1, 1, 1 };
		long[][] fusionJobIds = new long[jobIds.length][2];
		long[][] containerJobIds = new long[jobIds.length][2];
		int[][] searchIndexs = new int[jobIds.length][2];
		int[][] containerIds = new int[jobIds.length][2];

		long baseFusionJobId = 2000l;
		long containerJobId = 5000l;
		int searchIndex = 0;
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 2; j++) {
				fusionJobIds[i][j] = baseFusionJobId++;
				containerJobIds[i][j] = containerJobId++;
				searchIndexs[i][j] = searchIndex++;
				if (i == 0 && j == 0 || i == 0 && j == 1) {
					containerIds[i][j] = 1;
				}
				if (i == 1 && j == 0 || i == 1 && j == 1) {
					containerIds[i][j] = 1;
				}
				if (i == 2 && j == 0 || i == 2 && j == 1) {
					containerIds[i][j] = 1;
				}

			}
		}
		for (int i = 0; i < jobIds.length; i++) {
			jdbcTemplate.update(jobQueueSql, new Object[] { jobIds[i],
					new Long(familyIds[i]) });
		}
		for (int i = 0; i < fusionJobIds.length; i++) {
			for (int j = 0; j < fusionJobIds[0].length; j++) {
				jdbcTemplate.update(fusionJobSql, new Object[] {
						new Long(fusionJobIds[i][j]),
						new Integer(functionIds[i]), new Long(jobIds[i]),
						new Integer(searchIndexs[i][j]) });
			}
		}

		for (int i = 0; i < containerJobIds.length; i++) {
			for (int j = 0; j < containerJobIds[0].length; j++) {
				jdbcTemplate.update(contaiJobSql, new Object[] {
						new Long(containerJobIds[i][j]),
						new Integer(containerIds[i][j]),
						new Long(fusionJobIds[i][j]) });
			}
		}
		jdbcTemplate.update(defragBeanSql);
		jdbcTemplate.update("commit");
		List<JobInfoFromDB> results = null;

		try {
			results = identifyPlannerDao.getJobInfoForCreatePlans(jobIds);
		} catch (DataAccessException e) {
			e.printStackTrace();
		}

		long resultsContainerJobId = 5000l;
		Assert.assertNotNull(results);
		Assert.assertEquals(3, results.size());
		for (int i = 0; i < results.size(); i++) {
			Assert.assertEquals(jobIds[i], results.get(i).getTopJobId());
			Assert.assertEquals(familyIds[i], results.get(i).getFamilyId());
			if (results.get(i).getTopJobId() == 1000L) {
				Assert.assertEquals(1, results.get(i).getFunctionId().intValue());
				Assert.assertEquals(1, results.get(i).getFunctionId().intValue());
				Assert.assertEquals(1, results.get(i).getContainerId().intValue());
				Assert.assertEquals(1, results.get(i).getContainerId().intValue());
				Assert.assertEquals(resultsContainerJobId++, results.get(i).getContainerJobId().intValue());
				Assert.assertEquals(resultsContainerJobId++, results.get(i).getContainerJobId().intValue());
			}
			if (results.get(i).getTopJobId() == 1001L) {
				Assert.assertEquals(1, results.get(i).getFunctionId().intValue());
				Assert.assertEquals(1, results.get(i).getFunctionId().intValue());
				Assert.assertEquals(1, results.get(i).getContainerId().intValue());
				Assert.assertEquals(1, results.get(i).getContainerId().intValue());
				Assert.assertEquals(resultsContainerJobId++, results.get(i).getContainerJobId().intValue());
						
				Assert.assertEquals(resultsContainerJobId++, results.get(i).getContainerJobId().intValue());
			}
			if (results.get(i).getTopJobId() == 1002L) {
				Assert.assertEquals(1, results.get(i).getFunctionId().intValue());
				Assert.assertEquals(1, results.get(i).getFunctionId().intValue());
				Assert.assertEquals(1, results.get(i).getContainerId().intValue());
				Assert.assertEquals(1, results.get(i).getContainerId().intValue());
				Assert.assertEquals(resultsContainerJobId++, results.get(i).getContainerJobId().intValue());
				Assert.assertEquals(resultsContainerJobId++, results.get(i).getContainerJobId().intValue());
						
			}
		}

	}

	@Test
	public void testGetJobInfoForCreatePlans_null() {
		Long[] jobIds = { 1000L };
		try {
			List<JobInfoFromDB> results = identifyPlannerDao
					.getJobInfoForCreatePlans(jobIds);
			Assert.assertNull(results);

		} catch (DataAccessException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testGetRUCFromDB_normal() {
		long ts = System.currentTimeMillis();
		String insertRUCsql = "insert into resource_update_count (UPDATE_COUNT,UPDATE_TS)"
				+ " values (?,?)";
		jdbcTemplate.update(insertRUCsql, new Object[] { new Long(100),
				new Long(ts) });
		jdbcTemplate.execute("commit");
		Long results;
		try {
			results = identifyPlannerDao.getRUCFromDB();
			Assert.assertEquals(100l, results.longValue());
		} catch (PersistenceException | SQLException e) {
			e.printStackTrace();
		}

	}

	@Test(expected = NoResultException.class)
	public void testGetRUCFromDB_null() throws PersistenceException,
			SQLException {
		identifyPlannerDao.getRUCFromDB();
	}

	@Test
	public void testSetRUC_normal1() {
		long updateTs = System.currentTimeMillis();
		long oldRUC = 1000;
		String insertRUCsql = "insert into resource_update_count (UPDATE_COUNT,UPDATE_TS)"
				+ "values (?,?)";
		jdbcTemplate.update(insertRUCsql, new Object[] { new Long(oldRUC),
				new Long(updateTs) });
		jdbcTemplate.execute("commit");
		long newRUC = 5000;
		try {
			identifyPlannerDao.setRUC(newRUC);
		} catch (PersistenceException | SQLException e) {
			e.printStackTrace();
		}
		long result;
		try {
			result = identifyPlannerDao.getRUCFromDB();
			Assert.assertEquals(newRUC, result);
		} catch (PersistenceException | SQLException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testSetRUC_normal2() {
		long newRUC = 5000;
		long result = -1;
		try {
			identifyPlannerDao.setRUC(newRUC);
			result = identifyPlannerDao.getRUCFromDB();
		} catch (PersistenceException | SQLException e) {
			e.printStackTrace();
		}

		Assert.assertEquals(newRUC, result);
	}

	@Test
	public void testGetSegmentCount() {
		int containerId = 1;
		int count = 5;
		String insertSegmentSql = "insert into segments (SEGMENT_ID,CONTAINER_ID,BIO_ID_START,BIO_ID_END,"
				+ "BINARY_LENGTH_COMPACTED,RECORD_COUNT,VERSION,REVISION,BINARY_LENGTH_UNCOMPACTED)"
				+ " values(?, 1, 1, 10, 10, 10, 1, 1, 100)";
		long[] segmentIds = { 1000, 1001, 1002, 1003, 1004 };
		for (int i = 0; i < count; i++) {
			jdbcTemplate.update(insertSegmentSql, new Object[] { new Long(
					segmentIds[i]) });
		}
		jdbcTemplate.execute("commit");
		Integer results = -1;
		try {
			results = identifyPlannerDao.getSegmentCount(containerId);
			Assert.assertEquals(count, results.intValue());
		} catch (PersistenceException | SQLException e) {
			e.printStackTrace();
		}

	}

	@Test
	public void testGetSegmentCount_results0() {
		int containerId = 1;
		Integer results;
		try {
			results = identifyPlannerDao.getSegmentCount(containerId);
			Assert.assertEquals(0, results.intValue());
		} catch (PersistenceException | SQLException e) {
			e.printStackTrace();
		}

	}

	@Test
	public void testGetMuCpuAndPressure_normal() {
		Integer[] muIds = { 1, 2, 3, 4, 5 };
		String[] muStatus = { "WORKING", "WORKING", "WORKING", "WORKING",
				"WORKING" };
		Integer[] muCpus = { 4, 8, 12, 8, 16 };
		Long[] muPressure = { 4l, 5l, 6l, 7l, 8l };
		Double[] reportedPerformanceFactor = { 1.8D, 1.8D, 2.4D, 1.8D, 2.4D };
		Long updateTS = new Long(System.currentTimeMillis());
		String insertMuSql = "INSERT INTO MATCH_UNITS (MU_ID, UNIQUE_ID, STATE, NUMBER_OF_MATCHERS,REPORTED_PERFORMANCE_FACTOR) "
				+ "VALUES(?,?,?,?,?)";
		String inquiryLoadSql = "INSERT INTO MU_INQUIRY_LOAD (MU_ID, PRESSURE, REPORT_TS)  VALUES(?,?,?)";

		for (int i = 0; i < muIds.length; i++) {
			jdbcTemplate.update(insertMuSql,
					new Object[] { muIds[i], muIds[i].toString(), muStatus[i],
							muCpus[i], reportedPerformanceFactor[i] });
			jdbcTemplate.update(inquiryLoadSql, new Object[] { muIds[i],
					muPressure[i], updateTS });
			jdbcTemplate.execute("commit");
		}

		List<MuCpuAndPressure> muCpuAndPressureRsults = null;
		Set<Integer> muIdInset = new HashSet<Integer>();
		for (int i = 0; i < muIds.length; i++) {
			muIdInset.add(muIds[i]);
		}
		try {
			muCpuAndPressureRsults = identifyPlannerDao
					.getMuCpuAndPressure(muIdInset);
		} catch (PersistenceException | SQLException e) {
			e.printStackTrace();
		}
		for (int i = 0; i < muCpuAndPressureRsults.size(); i++) {
			Assert.assertEquals(muIds[i].longValue(), muCpuAndPressureRsults
					.get(i).getMuId());
			Assert.assertEquals(muPressure[i].longValue(),
					muCpuAndPressureRsults.get(i).getPressure());
			double expected = muCpus[i] * reportedPerformanceFactor[i];
			double real = muCpuAndPressureRsults.get(i).getAbility();
			Assert.assertTrue(expected - real < 0.000001);
			Assert.assertEquals(updateTS.longValue(), muCpuAndPressureRsults
					.get(i).getReportTs());
		}
	}

	@Test
	public void testGetMuCpuAndPressure_null() {
		Integer[] muIds = { 1, 2, 3, 4, 5 };
		List<MuCpuAndPressure> muCpuAndPressureRsults = null;
		Set<Integer> muIdInset = new HashSet<Integer>();
		for (int i = 0; i < muIds.length; i++) {
			muIdInset.add(muIds[i]);
		}
		try {
			muCpuAndPressureRsults = identifyPlannerDao
					.getMuCpuAndPressure(muIdInset);
			Assert.assertNull(muCpuAndPressureRsults);
		} catch (PersistenceException | SQLException e) {
			e.printStackTrace();
		}

	}

	@Test
	public void testGetWorkingMR() {
		String insertMrSql = "insert into map_reducers(mr_id,unique_id,state) values(?,?,'WORKING')";
		Long[] mrIds = { 1000L, 1001L, 1002L, 1003L, 1004L };
		String[] uniqueIds = { "1000", "1001", "1002", "1003", "1004" };
		for (int i = 0; i < mrIds.length; i++) {
			jdbcTemplate.update(insertMrSql, new Object[] { mrIds[i],
					uniqueIds[i] });
		}
		jdbcTemplate.execute("commit");
		Integer results;
		try {
			results = identifyPlannerDao.getWorkingMR();
			Assert.assertEquals(5, results.intValue());
		} catch (PersistenceException | SQLException e) {
			e.printStackTrace();
		}

	}

	@Test
	public void testGetWorkingMR_result0() {
		Integer results;
		try {
			results = identifyPlannerDao.getWorkingMR();
			Assert.assertEquals(0, results.intValue());
		} catch (PersistenceException | SQLException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testDeleteFeLotJob() {

	}

	@Test
	public void testRollbackMuExtractLoad() {

	}

	@Test
	public void testRollbackFeJobQueue() {

	}

	@Test
	public void testUpdateInquiryTraffic() throws PersistenceException,
			SQLException {
		Integer familyId = 1;
		String jobQueueSql = "insert into job_queue(job_id,priority,job_state,submission_ts,callback_style,failure_count,remain_jobs,family_id)"
				+ " values(1000,2,2,3000,0,0,0,1)";
		jdbcTemplate.update(jobQueueSql);
		String seletJobExecCount = "select job_exec_count from inquiry_traffic it where it.family_id = ?";
		int pre = jdbcTemplate.queryForObject(seletJobExecCount,
				new Object[] { familyId }, Integer.class);
		jdbcTemplate.execute("commit");
		identifyPlannerDao.updateInquiryTraffic(1000l);
		int after = jdbcTemplate.queryForObject(seletJobExecCount,
				new Object[] { familyId }, Integer.class);
		Assert.assertEquals(pre + 1, after);
	}

	@Test
	public void testUpdateInquiryTraffic_over_jobLimt_count()
			throws DataAccessException, SQLException {
		Integer familyId = 1;
		long[] topJobId = { 1000l, 1001l, 1002l, 1003l, 1004l };
		String jobQueueSql = "insert into job_queue(job_id,priority,job_state,submission_ts,callback_style,failure_count,remain_jobs,family_id)"
				+ " values(?,2,1,3000,0,0,0,1)";
		for (int i = 0; i < topJobId.length; i++) {
			jdbcTemplate.update(jobQueueSql, topJobId[i]);
		}
		String updateTrafficJobExcuteCountSql = "UPDATE inquiry_traffic set job_exec_count = 16 where family_id = ?";
		jdbcTemplate.update(updateTrafficJobExcuteCountSql, familyId);
		jdbcTemplate.execute("commit");
		identifyPlannerDao.updateInquiryTraffic(1000l);
		String seletJobExecCount = "select job_exec_count from inquiry_traffic it where it.family_id = ?";
		int after = jdbcTemplate.queryForObject(seletJobExecCount,
				new Object[] { familyId }, Integer.class);
		Assert.assertEquals(5, after);
	}

	@Test
	public void testUpdateInquiryTraffic_job_excute_count_minus()
			throws DataAccessException, SQLException {
		Integer familyId = 1;
		long[] topJobId = { 1000l, 1001l, 1002l, 1003l, 1004l };
		String jobQueueSql = "insert into job_queue(job_id,priority,job_state,submission_ts,callback_style,failure_count,remain_jobs,family_id)"
				+ " values(?,2,1,3000,0,0,0,1)";
		for (int i = 0; i < topJobId.length; i++) {
			jdbcTemplate.update(jobQueueSql, topJobId[i]);
		}
		String updateTrafficJobExcuteCountSql = "UPDATE inquiry_traffic set job_exec_count = -10 where family_id = ?";
		jdbcTemplate.update(updateTrafficJobExcuteCountSql, familyId);
		jdbcTemplate.execute("commit");
		identifyPlannerDao.updateInquiryTraffic(1000l);
		String seletJobExecCount = "select job_exec_count from inquiry_traffic it where it.family_id = ?";
		int after = jdbcTemplate.queryForObject(seletJobExecCount,
				new Object[] { familyId }, Integer.class);
		Assert.assertEquals(5, after);
	}

	@Test
	public void testConvert() {
		List<TopJobInfo> listRessults = new ArrayList<TopJobInfo>();
		List<JobInfoFromDB> listDb = new ArrayList<JobInfoFromDB>();
		long[] topJobIds = { 1000l, 1000l, 1001l, 1001l, 1002l, 1002l };
		int[] functionId = { 1, 1, 2, 2, 3, 3 };
		int[] containerId = { 11, 12, 21, 22, 31, 32 };
		long[] containerJobId = { 111, 121, 211, 221, 311, 321 };

		for (int i = 0; i < 6; i++) {
			JobInfoFromDB dbJob = new JobInfoFromDB();
			dbJob.setTopJobId(topJobIds[i]);
			dbJob.setFunctionId(functionId[i]);
			dbJob.setContainerId(containerId[i]);
			dbJob.setContainerJobId(containerJobId[i]);
			listDb.add(dbJob);
		}
		listRessults = identifyPlannerDao.convert(listDb);
		Assert.assertEquals(3, listRessults.size());
		for (int i = 0; i < 3; i++) {
			if (listRessults.get(i).getTopJobId().longValue() == 1000) {
				Assert.assertEquals(1, listRessults.get(i)
						.getCombinedJobInfoList().get(0).getFunctionId()
						.intValue());
				Assert.assertEquals(11, listRessults.get(i)
						.getCombinedJobInfoList().get(0).getContainerId()
						.intValue());
				Assert.assertEquals(111, listRessults.get(i)
						.getCombinedJobInfoList().get(0).getContaierJobId()
						.longValue());

				Assert.assertEquals(1, listRessults.get(i)
						.getCombinedJobInfoList().get(1).getFunctionId()
						.intValue());
				Assert.assertEquals(12, listRessults.get(i)
						.getCombinedJobInfoList().get(1).getContainerId()
						.intValue());
				Assert.assertEquals(121, listRessults.get(i)
						.getCombinedJobInfoList().get(1).getContaierJobId()
						.longValue());
			}

			if (listRessults.get(i).getTopJobId().longValue() == 1001) {
				Assert.assertEquals(2, listRessults.get(i)
						.getCombinedJobInfoList().get(0).getFunctionId()
						.intValue());
				Assert.assertEquals(21, listRessults.get(i)
						.getCombinedJobInfoList().get(0).getContainerId()
						.intValue());
				Assert.assertEquals(2, listRessults.get(i)
						.getCombinedJobInfoList().get(1).getFunctionId()
						.intValue());
				Assert.assertEquals(22, listRessults.get(i)
						.getCombinedJobInfoList().get(1).getContainerId()
						.intValue());
				Assert.assertEquals(211, listRessults.get(i)
						.getCombinedJobInfoList().get(0).getContaierJobId()
						.longValue());
				Assert.assertEquals(221, listRessults.get(i)
						.getCombinedJobInfoList().get(1).getContaierJobId()
						.longValue());
			}
			if (listRessults.get(i).getTopJobId().longValue() == 1002) {
				Assert.assertEquals(3, listRessults.get(i)
						.getCombinedJobInfoList().get(0).getFunctionId()
						.intValue());
				Assert.assertEquals(31, listRessults.get(i)
						.getCombinedJobInfoList().get(0).getContainerId()
						.intValue());
				Assert.assertEquals(3, listRessults.get(i)
						.getCombinedJobInfoList().get(1).getFunctionId()
						.intValue());
				Assert.assertEquals(32, listRessults.get(i)
						.getCombinedJobInfoList().get(1).getContainerId()
						.intValue());
				Assert.assertEquals(311, listRessults.get(i)
						.getCombinedJobInfoList().get(0).getContaierJobId()
						.longValue());
				Assert.assertEquals(321, listRessults.get(i)
						.getCombinedJobInfoList().get(1).getContaierJobId()
						.longValue());
			}
		}
	}
}
