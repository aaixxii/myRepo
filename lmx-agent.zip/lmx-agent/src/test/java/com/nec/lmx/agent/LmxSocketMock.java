package com.nec.lmx.agent;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.SocketChannel;

public class LmxSocketMock {
	private SocketChannel socketChannel;
	

	private static final LmxSocketMock lmxSocket = new LmxSocketMock();

	public static LmxSocketMock getInstance() {
		return lmxSocket;
	}

	public LmxSocketMock() {		
	}

	public void init(int port) {
		try {			
			InetSocketAddress hostAddress = new InetSocketAddress("localhost", port); 
			socketChannel = SocketChannel.open(hostAddress);			
			socketChannel.configureBlocking(false);
			socketChannel.socket().setKeepAlive(true);
			socketChannel.socket().setSoTimeout(500000);
			System.out.println("Connecting to local Server on port:" + port);
			
			System.out.println("Connecting to" + socketChannel.socket().getInetAddress() + ":" + socketChannel.socket().getPort());

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void sendLinceseInfo(String licenseInfo) {
		int any = 0;
		try {
			byte[] bodys = licenseInfo.getBytes("UTF-8");			
			ByteBuffer sendBuff = ByteBuffer.allocate(bodys.length);
			sendBuff.order(ByteOrder.BIG_ENDIAN);
			sendBuff.put(bodys);
			sendBuff.flip();
			try {
				while (sendBuff.hasRemaining()) {
					any = socketChannel.write(sendBuff);
					System.out.println("Send as : " + any);
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			sendBuff.clear();
			System.out.println("Success send data to server.");

			try {
				Thread.sleep(1 * 60 * 60 * 1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
