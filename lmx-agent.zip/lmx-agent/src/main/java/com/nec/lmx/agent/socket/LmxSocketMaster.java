package com.nec.lmx.agent.socket;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.lmx.agent.event.EventNotifier;

public class LmxSocketMaster implements Runnable {
	private Selector selector;
	private SocketChannel socketChannel;
	private static Logger logger = LoggerFactory.getLogger(LmxSocketMaster.class);

	public LmxSocketMaster(int port) {
		try {			
			InetSocketAddress hostAddress = new InetSocketAddress("localhost", port);
			socketChannel = SocketChannel.open(hostAddress);
			socketChannel.configureBlocking(false);
			socketChannel.socket().setReuseAddress(true);
			socketChannel.socket().setKeepAlive(true);
			selector = Selector.open();
			socketChannel.register(selector, SelectionKey.OP_WRITE);
			LmxSocketSender.getInstance().init(socketChannel);
			logger.info(
					"Connected to" + socketChannel.socket().getInetAddress() + ":" + socketChannel.socket().getPort());				

		} catch (IOException e) {
			logger.error(e.getMessage(), e);
			System.exit(1);
		}
	}

	@Override
	public void run() {
		SelectionKey key = null;
		try {
			while (selector.select() > 0) {
				if (!socketChannel.isConnected() || !socketChannel.isOpen()) {
					String socketChannlClosed = "SocketChannel of LmxAgent is closed!";
					EventNotifier.getInstance().fireOnError(socketChannlClosed);
					logger.error(socketChannlClosed);
					System.exit(1);
				} else {
					logger.debug("LmxSocket still active on {}.", new Date());
				}
				Set<SelectionKey> keys = selector.selectedKeys();
				Iterator<SelectionKey> keyIterator = keys.iterator();
				while (keyIterator.hasNext()) {
					key = (SelectionKey) keyIterator.next();
					keyIterator.remove();
					if (!key.isValid()) {
						continue;
					}
				}
				Thread.sleep(5000);
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			try {
				if (key != null) {
					key.cancel();
					key.channel().close();
				}
			} catch (Exception ex) {
				logger.error(e.getMessage(), e);
			}
		}
	}
}
