package com.nec.lmx.agent;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nec.lmx.agent.lmx.LicenseManager;
import com.nec.lmx.agent.socket.LmxSocketMaster;

/**
 * @author xiazp
 *
 */
public class LmxAgent {

	public LmxAgent() {
	}

	private static final Logger logger = LoggerFactory.getLogger(LmxAgent.class);
	private static String PORT;
	private static String FEATURE;
	private static String MAJOR;
	private static String LICENSE_SERVER_URL;
	

	public static void main(String[] args) {
		LmxAgent LmxAgent = new LmxAgent();
		LmxAgent.handleParameter(args);

		String licenseServerUrl = System.getProperty("java.lmx.license.path");
		if (licenseServerUrl == null || licenseServerUrl.isEmpty()) {
			logger.error("License server url is invaild: it's empty!");
			System.exit(1);
		}
		if (isCheckUrl(licenseServerUrl)) {
			LICENSE_SERVER_URL = licenseServerUrl;
		} else {
			logger.error("License server url is invaild: {}", licenseServerUrl);
			System.exit(1);
		}
		startAgent();
	}

	private void handleParameter(String[] args) {
		if (args.length < 3) {
			pringUsage();
			System.exit(1);
		}

		for (String one : args) {
			if (one == null || one.isEmpty()) {
				logger.warn(one + "can't be empty!");
				pringUsage();
				System.exit(1);
			}
		}

		if (isMatchNumber(args[0])) {
			PORT = args[0];
		} else {
			logger.warn("port is not a number it's a string:" + args[0]);
			pringUsage();
			System.exit(1);
		}
		
		if (isMatchFeature(args[1])) {
			FEATURE = args[1];
		} else {
			logger.warn("FEATURE is not a string ,it contain number:" + args[1]);
			pringUsage();
			System.exit(1);
		}
		
		if (isMatchNumber(args[2])) {
			MAJOR = args[2];
		} else {
			logger.warn("MAJOR is not a number it's a string or char:" + args[2]);
			pringUsage();
			System.exit(1);
		}
	}
	
	private static void startAgent() {
		LmxSocketMaster agent = new LmxSocketMaster(Integer.valueOf(PORT));
		new Thread(agent).start();
		LicenseManager fm = LicenseManager.getInstance();
		fm.initLmx(LICENSE_SERVER_URL, FEATURE, Integer.valueOf(MAJOR));
	}

	
	private void pringUsage() {
		String lineSeparater = System.getProperties().getProperty("line.separator");
		StringBuilder sb = new StringBuilder();
		sb.append("Usage for boot LmxAgnet:");
		sb.append(lineSeparater);
		sb.append("java - jar lmx-agent.jar port feature majorversion");
		logger.info(sb.toString());
		sb.delete(0, sb.length());
	}

	private boolean isMatchFeature(String name) {
		Pattern p = Pattern.compile("^[a-zA-Z]*[0-9a-zA-Z]$");
		Matcher m = p.matcher(name);
		return m.matches();		
	}

	private boolean isMatchNumber(String any) {
		if (any == null || any.isEmpty()) {
			return false;
		}
		Pattern p = Pattern.compile("^[0-9]*$");
		Matcher m = p.matcher(any);
		return m.matches();
		// return port.matches("^[0-9]*$");
	}

	private static boolean isCheckUrl(String licenseServerUrl) {
		if (licenseServerUrl == null || licenseServerUrl.isEmpty()) {
			return false;
		}
		int index = licenseServerUrl.indexOf("@");
		if (index < 0) {
			return false;
		} else {
			String firstEx = licenseServerUrl.substring(0, index);
			if (!firstEx.matches("^[0-9]*$")) {
				return false;
			} else {
				String tmp = licenseServerUrl.substring(index + 1, licenseServerUrl.length());
				if (tmp == null || tmp.length() < 1) {
					return false;
				} else {
					return true;
				}
			}
		}
	}

	@SuppressWarnings("unused")
	private static void checkLmxLibPath() {
		String myPath = LmxAgent.class.getProtectionDomain().getCodeSource().getLocation().getPath();
		String myBaseDir = myPath.substring(0, myPath.length() - "lib/lmx-agent.jar".length());
		myBaseDir = myBaseDir.endsWith("/") ? myBaseDir.substring(0, myBaseDir.length() - 1) : myBaseDir;
		String lmxLibPath = myBaseDir + "license/lmx/linux_x64";
		lmxLibPath = System.getProperty("java.library.path");
		System.setProperty("java.library.path", lmxLibPath);
		System.loadLibrary("liblmxjava.so");
	}

	@SuppressWarnings("unused")
	private static void checkLmxLicensePath() {

	}
}
