/**
 * 
 */
package com.nec.lmx.agent;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author 000001A006PBP
 *
 */
public class LmxAgent {
	
	public LmxAgent() {		
	}
	
	private static Logger logger = LoggerFactory.getLogger(LmxAgent.class);
	
	private static final String START = "start";
	private static final String SHUTDONW = "shutdown";
	
	private  String PORT;
	private  String LICENSE_SERVER_URL;

	

	
	
	public static void main(String[] args) {	
		LmxAgent LmxAgent = new LmxAgent();
		LmxAgent.handleParameter(args);

	}
	
	private void handleParameter(String[] args) {		
		if (args.length == 0) {			
			pringUsage();
			System.exit(0);
		} 
		
		if (args.length == 1) {
		  if (args[0].toUpperCase().equals(SHUTDONW)) {
			  shutdown(); 
		  } else {
			  logger.info("Invaild parameter!");
			  pringUsage();
				System.exit(0);
		  }				
			
		} else if(args.length == 2) {
			if (Integer.valueOf(args[0]) < 0) {
				pringUsage();
				System.exit(0);
			} else {
				this.PORT = args[0];
			}
			
			if (args[1].isEmpty() || args[1].length() < 9) {
				pringUsage();
				System.exit(0);
			} else {
				this.LICENSE_SERVER_URL = args[1];
			}			
		}
		
	}
	
	private void pringUsage() {
		String lineSeparater = System.getProperties().getProperty("line.separator");
		StringBuilder sb = new StringBuilder();
		sb.append("Usage for boot LmxAgnet:");
		sb.append(lineSeparater);
		sb.append("LmxAgent port serverUrl");
		logger.info(sb.toString());		
		sb.delete(0, sb.length());

		sb.append("Usage for stop LmxAgnet:");
		sb.append(lineSeparater);
		sb.append("LmxAgent shutdown");
		logger.info(sb.toString());		

	}
	
	private void shutdown() {
		//ToDo release all resource
	}
	
	private void start() {
		
	}

	
	

}
