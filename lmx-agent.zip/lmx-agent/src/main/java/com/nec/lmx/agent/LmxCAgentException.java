package com.nec.lmx.agent;

public class LmxCAgentException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -969272397827439848L;
	
	/**
	 * @param message
	 */
	public LmxCAgentException (String message) {
		super(message);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public LmxCAgentException (String message, Throwable cause) {
		super(message, cause);
	}
}
