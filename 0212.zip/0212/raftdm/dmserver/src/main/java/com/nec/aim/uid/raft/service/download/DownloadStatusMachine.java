package com.nec.aim.uid.raft.service.download;

import java.util.concurrent.atomic.AtomicLong;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alipay.sofa.jraft.Iterator;
import com.alipay.sofa.jraft.core.StateMachineAdapter;

public class DownloadStatusMachine  extends StateMachineAdapter {
	
	 private static final Logger logger = LoggerFactory.getLogger(DownloadStatusMachine.class);
	 
	  private final AtomicLong    leaderTerm = new AtomicLong(-1);
	  
	    public boolean isLeader() {
	        return this.leaderTerm.get() > 0;
	    }

	@Override
	public void onApply(Iterator iter) {
		// TODO Auto-generated method stub
		
	}

}
