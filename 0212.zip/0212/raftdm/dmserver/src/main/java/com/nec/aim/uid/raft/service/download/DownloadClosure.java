package com.nec.aim.uid.raft.service.download;

import com.alipay.sofa.jraft.Closure;
import com.alipay.sofa.jraft.Status;

public class DownloadClosure implements Closure {

	@Override
	public void run(Status status) {
		// TODO Auto-generated method stub
		
	}

}
