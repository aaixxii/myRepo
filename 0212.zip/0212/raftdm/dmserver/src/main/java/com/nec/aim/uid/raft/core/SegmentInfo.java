package com.nec.aim.uid.raft.core;

import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class SegmentInfo {
	private long segId;
	private int lastPosition;
	private boolean isUsing;
	private int recordcount;
	private ReadWriteLock locker;
	private boolean corrupted;
	
	public SegmentInfo(long segmentId) {
		this.segId = segmentId;
		this.locker = new ReentrantReadWriteLock();
		this.lastPosition = 0;
		this.recordcount = 1;
		this.corrupted = false;
		this.isUsing = true;
	}

	public long getSegId() {
		return segId;
	}

	public void setSegId(long segId) {
		this.segId = segId;
	}

	public int getLastPosition() {
		return lastPosition;
	}

	public void setLastPosition(int lastPosition) {
		this.lastPosition = lastPosition;
	}

	public boolean isUsing() {
		return isUsing;
	}

	public void setUsing(boolean isUsing) {
		this.isUsing = isUsing;
	}

	public ReadWriteLock getLocker() {
		return locker;
	}

	public void setLocker(ReadWriteLock locker) {
		this.locker = locker;
	}

	public boolean isCorrupted() {
		return corrupted;
	}

	public void setCorrupted(boolean corrupted) {
		this.corrupted = corrupted;
	}

	public int getRecordcount() {
		return recordcount;
	}

	public void setRecordcount(int recordcount) {
		this.recordcount = recordcount;
	}
	
}
