package com.nec.aim.uid.raft.service.download;

import java.io.IOException;

public interface DownloadService {	
	public byte[] getSegmentData(long segmentId) throws IOException ;
}
