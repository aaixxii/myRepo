package com.nec.aim.uid.raft.service.segment;

import com.google.protobuf.InvalidProtocolBufferException;

import jp.co.nec.aim.message.proto.AIMMessages.PBDmSyncRequest;

public interface SegmentService {
	
	public Boolean handerRequest(PBDmSyncRequest dmSegRequest)
			throws InvalidProtocolBufferException;

}
