package jp.co.nec.lsm.tme.servlets;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.common.servlet.AbstractTMServlet;
import jp.co.nec.lsm.tme.db.dao.EnrollSystemConfigDaoLocal;
import jp.co.nec.lsm.tme.exception.EnrollRuntimeException;
import jp.co.nec.lsm.tme.service.sessionbean.EnrollRecoveryServiceLocal;
import jp.co.nec.lsm.tme.service.sessionbean.EnrollRoleStateTransitionManager;

import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EnrollRoleStateTransitionServlet extends AbstractTMServlet {

	private static final String FADE_OUT = "fadeout";
	private static final String WAKE_UP = "wakeup";
	private static final String QUICK_VIEW = "quickview";
	private static final String TRUE = "true";
	private static final String FALSE = "false";
	private static final String PARA_COMMAND = "command";
	private static final String PARA_RECOVERY = "recovery";
	private static final String CONTENT_TYPE = "text/plain";

	/**
	 * 
	 */
	private static final long serialVersionUID = -3120931148133419614L;
	private static Logger log = LoggerFactory
			.getLogger(EnrollRoleStateTransitionServlet.class);

	private EnrollRoleStateTransitionManager manager = new EnrollRoleStateTransitionManager();
	@EJB
	private EnrollRecoveryServiceLocal recoveryService;
	@EJB
	private EnrollSystemConfigDaoLocal systemConfigDao;

	/**
	 * doGet
	 */
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		res.setContentType(CONTENT_TYPE);
		String command = req.getParameter(PARA_COMMAND);
		if (command == null) {
			String errorMessage = "command is empty or error..";
			writeErrorToResponse(req, res, HttpServletResponse.SC_BAD_REQUEST,
					errorMessage, new EnrollRuntimeException(errorMessage));
			return;
		}

		String recovery = req.getParameter(PARA_RECOVERY);
		if (recovery == null) {
			log
					.warn("recovery Parameter is not given, using default value(false).");
			recovery = FALSE;
		}

		try {
			StopWatch t = new StopWatch();
			t.start();

			// Recover uncompleted enrollBatchJob.
			if (recovery.toLowerCase().equals(TRUE)
					&& command.toLowerCase().equals(WAKE_UP)) {
				recoveryService.recoverUnCompletedBatchJob();
			}

			String output = processCommand(command, recovery);
			writeResultToResponse(output, res);

			t.stop();
			PerformanceLogger.performanceOutput(
					LogConstants.COMPONENT_TRANSITION_SERVLET,
					LogConstants.FUNCTION_DO_GET, t.getTime());
		} catch (Exception e) {
			writeErrorToResponse(req, res,
					HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e
							.getMessage(), e);
		}
	}

	/**
	 * processCommand
	 * 
	 * @throws InterruptedException
	 */
	private String processCommand(String command, String recoveryCommand)
			throws InterruptedException {

		String output = null;
		String lowerCommand = command.toLowerCase();
		if (lowerCommand.equals(FADE_OUT)) {
			output = manager.fadeOut();
		} else if (lowerCommand.equals(WAKE_UP)) {
			boolean isNecessaryRecovery = Boolean.parseBoolean(recoveryCommand);
			output = manager.wakeUp(recoveryService, isNecessaryRecovery);
		} else if (lowerCommand.equals(QUICK_VIEW)) {
			output = manager.quickView(systemConfigDao);
		} else {
			String errorMessage = "command is not support, fadecout, "
					+ "wakeup and quickview is supported..";
			log.error(errorMessage);
			throw new EnrollRuntimeException(errorMessage);
		}
		return output;
	}

	/**
	 * doPost
	 */
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		doGet(req, res);
	}
}
