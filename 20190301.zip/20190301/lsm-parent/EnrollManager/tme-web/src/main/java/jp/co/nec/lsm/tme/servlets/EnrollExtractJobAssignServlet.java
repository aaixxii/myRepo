package jp.co.nec.lsm.tme.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.nec.lsm.proto.extract.ExtractJobRequestProto.ExtractJobRequest;
import jp.co.nec.lsm.proto.extract.ExtractJobResponseProto.ExtractJobResponse;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.common.servlet.AbstractTMServlet;
import jp.co.nec.lsm.tm.common.util.ServletRequestUtil;
import jp.co.nec.lsm.tme.service.pojo.EnrollExtractJobAssignServiceBean;

import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author mozj assigned extract jobs to MFE.
 * 
 * @web.servlet name="ExtractJobAssignServletRemote"
 * @web.servlet-mapping url-pattern="/ExtractJobAssign"
 */
public class EnrollExtractJobAssignServlet extends AbstractTMServlet {

	/**
	 * serialVersionUID value
	 */
	private static final long serialVersionUID = 3678990807917599914L;

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(EnrollExtractJobAssignServlet.class);

	/** Extract Job Assign Service instance **/
	private EnrollExtractJobAssignServiceBean extractJobAssignService;

	public void init() throws ServletException {
		extractJobAssignService = new EnrollExtractJobAssignServiceBean();
	}

	/**
	 * assigned extract jobs to MFE.
	 */
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		printLogMessage("start public function doGet()..");

		if (ServletRequestUtil.isRequestContextSizeEmpty(req)) {
			log.warn("Received an empty POST request");
			return;
		}

		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		ExtractJobRequest jobRequest = null;
		try {
			// parse ExtractJobRequest from Input Stream
			jobRequest = ExtractJobRequest.parseFrom(req.getInputStream());
		} catch (Exception ex) {
			writeErrorToResponse(req, res, HttpServletResponse.SC_BAD_REQUEST,
					"parse ExtractJobRequest object error", ex);
			return;
		}

		try {
			// get Extract Jobs which would be send to MFE.
			ExtractJobResponse extractJob = extractJobAssignService
					.doAssign(jobRequest);
			// send Extract Jobs to MFE.
			if (extractJob != null) {
				res.setStatus(HttpServletResponse.SC_OK);
				res.setContentType("application/octet-stream");
				res.setContentLength(extractJob.getSerializedSize());
				extractJob.writeTo(res.getOutputStream());
				res.flushBuffer();
				stopWatch.stop();
				PerformanceLogger.performanceOutput(
						LogConstants.COMPONENT_ASSIGNJOB_SERVLET_TME,
						LogConstants.FUNCTION_DO_GET, stopWatch
								.getTime());

			} else {
				res.setStatus(HttpServletResponse.SC_NO_CONTENT);
				res.setContentLength(0);
			}
		} catch (Exception ex) {
			writeErrorToResponse(req, res,
					HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
					"enroll Extract job assign error.", ex);
			return;
		}
		printLogMessage("end public function doGet()..");
	}

	/**
	 * assigned extract jobs to MFE.
	 */
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		doGet(req, res);
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
