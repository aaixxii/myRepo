package jp.co.nec.lsm.tme.db.dao;

import static org.junit.Assert.assertEquals;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class EnrollBatchJobQueueDaoTest {
    
    @PersistenceContext(unitName = "tme-ngi")
    private EntityManager entityManager;

	@Resource
	protected JdbcTemplate jdbcTemplate;
	
	EnrollBatchJobQueueDaoLocal batchJobQueueDao;

	@Before
	public void setUp() {
	    batchJobQueueDao = new EnrollBatchJobQueueDao(entityManager);
	    
           
	}

	@After
	public void tearDown() {

	}

	@Test
	public void testPersistBatchJob_Param() {

		jdbcTemplate.execute("delete FROM ENROLL_BATCH_JOB_QUEUE");

		batchJobQueueDao.persistBatchJob(null);

		String sql = "select * FROM ENROLL_BATCH_JOB_QUEUE ";
		jdbcTemplate.execute(sql);
		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql);

		assertEquals(0, list.size());
	}

	@Test
	public void testPersistBatchJobStatus_Param() {

		jdbcTemplate.execute("delete FROM ENROLL_BATCH_JOB_QUEUE");

		batchJobQueueDao.persistBatchJobStatus(122, new Date(), null, null);

		String sql = "select * FROM ENROLL_BATCH_JOB_QUEUE ";
		jdbcTemplate.execute(sql);
		List<Map<String, Object>> list = jdbcTemplate.queryForList(sql);

		assertEquals(0, list.size());
	}
}
