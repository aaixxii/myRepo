package jp.co.nec.lsm.tme.db.entityhelpers;

/**
 * Test Class for SystemInitHelper
 */
import static org.junit.Assert.assertEquals;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Enumeration;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.tm.common.constants.ConfigProperty;
import jp.co.nec.lsm.tm.common.constants.Constants;
import jp.co.nec.lsm.tm.common.constants.TMType;
import jp.co.nec.lsm.tm.common.constants.TmState;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.common.entities.TransactionManagerEntity;
import jp.co.nec.lsm.tm.db.common.entityhelpers.SystemConfigHelper;
import jp.co.nec.lsm.tm.db.common.entityhelpers.TransactionManagerHelper;
import jp.co.nec.lsm.tme.exception.EnrollRuntimeException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "/applicationContext.xml" })
@Transactional
public class TransactionManagerHelperTest {
	@PersistenceContext(unitName = "tme-ngi")
	private EntityManager entityManager;
	@Resource
	protected JdbcTemplate jdbcTemplate;

	private SystemConfigHelper systemConfigHelper;

	/**
	 * 
	 * Test Case<br/>
	 * Test [testCreateOrLookup]<br/>
	 * 1 - call getTMEUniqueId, to gain local IP<br/>
	 * 2 - prepare EnrollTransactionManagerEntity For test<br/>
	 * 3 - call persist, insert data into database<br/>
	 * 4 - query database to get data<br/>
	 * 5 - assert concerning information<br/>
	 */
	@Test
	public void testCreateOrLookup() {

		// clear database to avoid disturbing
		jdbcTemplate.execute("delete FROM TRANSACTION_MANAGERS");

		TransactionManagerHelper tmHelper = new TransactionManagerHelper(
				entityManager, TMType.TME);
		TransactionManagerEntity tm = new TransactionManagerEntity();

		// 1 - call getTMEUniqueId, to gain local IP
		String uiniqueId = getTMEUniqueId();

		// 2 - prepare EnrollTransactionManagerEntity For test
		tm.setUniqueId(uiniqueId);
		tm.setState(TmState.WORKING);
		tm.setLastHeartbeatTs(DateUtil.getCurrentDate());
		tm.setContactUrl("http://localhost:8080/ngi");
		tm.setVersion("2.1.0");
		tm.setLastPollTs(DateUtil.getCurrentDate());

		// 3 - call persist, insert data into database
		entityManager.persist(tm);

		// 4 - query database to get data
		TransactionManagerEntity actualMU = tmHelper.createOrLookup(DateUtil
				.getCurrentDate(), "2.1.0");

		// 5 - assert concerning information
		assertEquals(tm.getVersion(), actualMU.getVersion());
		assertEquals(uiniqueId, actualMU.getUniqueId());
	}

	/**
	 * 
	 * Test Case<br/>
	 * Test [testGetMUUniqueId]<br/>
	 * 1 - call getTMEUniqueId, to gain local IP<br/>
	 * 2 - prepare EnrollTransactionManagerEntity For test<br/>
	 * 3 - call persist, insert data into database<br/>
	 * 4 - call changeTMEState, to change TMETransactionManagerHelper status<br/>
	 * 5 - assert concerning information<br/>
	 */
	@Test
	public void testGetMUUniqueId() {
		jdbcTemplate.execute("delete FROM TRANSACTION_MANAGERS");
		TransactionManagerHelper tmHelper = new TransactionManagerHelper(
				entityManager, TMType.TME);

		TransactionManagerEntity tm = new TransactionManagerEntity();

		// 1 - call getTMEUniqueId, to gain local IP
		String uiniqueId = getTMEUniqueId();

		// 2 - prepare EnrollTransactionManagerEntity For test
		tm.setUniqueId(uiniqueId);
		tm.setState(TmState.WORKING);
		tm.setLastHeartbeatTs(DateUtil.getCurrentDate());
		tm.setContactUrl("http://localhost:8080/ngi");
		tm.setVersion("2.1.0");
		tm.setLastPollTs(DateUtil.getCurrentDate());

		// 3 - call persist, insert data into database
		entityManager.persist(tm);

		// 4 - call changeTMEState, to change TMETransactionManagerHelper status
		tmHelper.changeTMState();

		// 5 - assert concerning information
		assertEquals(TmState.EXITED, tm.getState());
	}

	/**
	 * Get an ip-address of TME from pid.tm.properties.
	 * 
	 * If the ip-address is not gotten from properties, it must be missing the
	 * default setting. Therefore It is not necessary to send SM and get the
	 * real ip of NIC.
	 * 
	 * @return
	 */
	private String getTMEUniqueId() {
		systemConfigHelper = new SystemConfigHelper(entityManager);
		String mmUniqueId = systemConfigHelper
				.getTMProperty(ConfigProperty.TME_IP_ADDRESS);
		if (mmUniqueId == null) {

			mmUniqueId = Constants.DEFAULT_TME_UNIQUE_ID;

			// basically, we prefer to use numeric IP address but will use
			// hostname otherwise.
			// worst-case scenario we use the default above.
			try {
				mmUniqueId = InetAddress.getLocalHost().getHostName();

				Enumeration<NetworkInterface> interfaces = java.net.NetworkInterface
						.getNetworkInterfaces();
				while (interfaces.hasMoreElements()) {
					NetworkInterface ni = interfaces.nextElement();
					// log.debug("Interface: " + ni.getDisplayName());
					Enumeration<InetAddress> addrs = ni.getInetAddresses();
					while (addrs.hasMoreElements()) {
						InetAddress addr = addrs.nextElement();
						// log.debug("Address: " + addr.getHostAddress());
						if (!addr.isLoopbackAddress()) {
							mmUniqueId = addr.getHostAddress();
						}
					}
				}
			} catch (SocketException e) {
				throw new EnrollRuntimeException("SocketException", e);
			} catch (UnknownHostException e) {
				throw new EnrollRuntimeException("UnknownHostException", e);
			}
		}
		return mmUniqueId
				+ Constants.COLON
				+ systemConfigHelper
						.getTMProperty(ConfigProperty.TME_WEB_PORT_NUM);
	}
}