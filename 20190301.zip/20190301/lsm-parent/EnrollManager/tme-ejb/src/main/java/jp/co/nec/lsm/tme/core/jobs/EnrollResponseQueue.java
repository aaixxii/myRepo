package jp.co.nec.lsm.tme.core.jobs;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;

import jp.co.nec.lsm.tm.protocolbuffer.enroll.EnrollResultRequestProto.EnrollResultRequest;
import jp.co.nec.lsm.tme.common.constants.EnrollConstants;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;

/**
 * EnrollResponseQueue
 * 
 * @author liuyq
 * 
 */
public final class EnrollResponseQueue {
	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(EnrollResponseQueue.class);

	/** the responseMap to keep the response information to memory **/
	private final Map<Long, EnrollResultRequest> responseMap = new ConcurrentHashMap<Long, EnrollResultRequest>();;

	/** this instance **/
	private final static EnrollResponseQueue queue = new EnrollResponseQueue();

	/** the max capacity of this queue **/
	public static final int MAX_CAPACITY = EnrollConstants.MAX_CAPACITY;

	/** the key of ALL_TLJ_SIZE **/
	public static final String ALL_TLJ_SIZE = "allTljSize";

	/** the key of correctTljSize **/
	public static final String CORRECT_TLJ_SIZE = "correctTljSize";

	/** the status of correct top level job **/
	private static final String CORRECT_TLJ_STATUS = "0";

	/**
	 * private constructor
	 */
	private EnrollResponseQueue() {
	}

	/**
	 * get the singleton instance
	 * 
	 * @return singleton instance
	 */
	public synchronized static final EnrollResponseQueue getInstance() {
		return queue;
	}

	/**
	 * add the latest instance to queue and remove the oldest.
	 * 
	 * @param response
	 */
	public final void add(final EnrollResultRequest response) {
		if (response == null) {
			log.error("add reponse to queue but response is null"
					+ " while createEnrollResultRequest..");
			return;
		}

		responseMap.put(response.getBatchJobId(), response);
		final int currentSize = responseMap.size();
		final int removeSize = currentSize - MAX_CAPACITY;
		if (removeSize > 0) {
			Set<Long> keys = new TreeSet<Long>(responseMap.keySet());
			Object[] sortedKeys = keys.toArray();
			for (int i = 0; i < removeSize; i++) {
				responseMap.remove(sortedKeys[i]);
			}
		}
	}

	/**
	 * clearAll memory
	 */
	public void clearAll() {
		this.responseMap.clear();
	}

	/**
	 * getResponseMap
	 * 
	 * @return Set<Entry<Long, EnrollResultRequest>>
	 */
	public Set<Entry<Long, EnrollResultRequest>> getResponseMapEntry() {
		return this.responseMap.entrySet();
	}

	public Set<Long> getResponseMapKeySet() {
		return this.responseMap.keySet();
	}

	/**
	 * responseStatistics
	 * 
	 * @return Map<Long, Statistics>
	 */
	public final Map<Long, Statistics> responseStatistics() {
		if (responseMap.isEmpty()) {
			log.info("the response cache queue is empty..");
			return new HashMap<Long, Statistics>();
		}

		final int size = responseMap.size();
		final Map<Long, Statistics> statisticsMap = new HashMap<Long, Statistics>(
				size);

		final Set<Entry<Long, EnrollResultRequest>> entrySet = responseMap
				.entrySet();
		for (final Entry<Long, EnrollResultRequest> entry : entrySet) {
			final Long batchJobId = entry.getKey();
			final EnrollResultRequest request = entry.getValue();

			int total = request.getBusinessMessageCount();
			int correct = 0;
			final List<ByteString> messageBytes = request
					.getBusinessMessageList();
			for (final ByteString bytes : messageBytes) {
				CPBBusinessMessage message;
				try {
					message = CPBBusinessMessage.parseFrom(bytes);
				} catch (InvalidProtocolBufferException e) {
					log.error("parse message error", e);
					continue;
				}

				if (message.hasResponse()) {
					if (message.getResponse().getStatus()
							.equals(CORRECT_TLJ_STATUS)) {
						correct++;
					}
				}
			}

			statisticsMap.put(batchJobId, new Statistics(total, correct));
		}
		return statisticsMap;
	}

	/**
	 * the Statistics of top level job count
	 * 
	 * @author liuyq
	 * 
	 */
	public static final class Statistics {
		private Integer allTljSize;
		private Integer correctTljSize;

		public Statistics(Integer allTljSize, Integer correctTljSize) {
			this.allTljSize = allTljSize;
			this.correctTljSize = correctTljSize;
		}

		public Integer getAllTljSize() {
			return allTljSize;
		}

		public Integer getCorrectTljSize() {
			return correctTljSize;
		}
	}
}
