package jp.co.nec.lsm.tme.core.clientapi.response;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import jp.co.nec.lsm.tm.common.httpsender.HttpRequestSender;
import jp.co.nec.lsm.tm.common.httpsender.HttpResponse;
import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tme.exception.EnrollRuntimeException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.InvalidProtocolBufferException;

/**
 * @author zhulk <br>
 *         This class used for response the result of batchJob or prepare Enroll
 *         Result.
 */
public class ResultRequestSender {
	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(ResultRequestSender.class);

	/**
	 * response the result of batchJob
	 * 
	 * @param batchJob
	 * @return
	 * @throws InvalidProtocolBufferException
	 */
	public HttpResponse sendResponse(byte[] responseData, long batchJobId,
			String url) {
		printLogMessage("start public function sendResponse..");
		// response result to url
		try {
			InputStream inputStream = null;
			if (responseData != null) {
				inputStream = new ByteArrayInputStream(responseData);
			}

			HttpRequestSender httpRequestSender = new HttpRequestSender();
			if (log.isInfoEnabled()) {
				log.info(InfoLogger.httpURLInfoOutput(batchJobId, url));
			}
			HttpResponse httpResponse = httpRequestSender.sendPostRequest(url,
					batchJobId, inputStream, null);
			if (log.isInfoEnabled()) {
				log.info("Finished post to {}  status: {} for batchJob {}.",
						new Object[] { url, httpResponse.getHttpResponseCode(),
								batchJobId });
			}
			printLogMessage("end public function sendResponse..");
			return httpResponse;
		} catch (Exception e) {
			String message = "Exception when post batchJob " + batchJobId
					+ " to " + url;
			log.error(message);
			throw new EnrollRuntimeException(message, e);
		}
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
