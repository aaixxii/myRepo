package jp.co.nec.lsm.tme.core.jobs;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import jp.co.nec.lsm.proto.common.CommonProto.ReturnCode;
import jp.co.nec.lsm.proto.extract.ExtractJobResponseProto.ExtractJob;
import jp.co.nec.lsm.proto.extract.ExtractJobResultRequestProto.ExtractJobResult;
import jp.co.nec.lsm.proto.extract.ExtractJobResultRequestProto.ExtractJobResultRequest;
import jp.co.nec.lsm.tm.common.communication.PersonReferenceID;
import jp.co.nec.lsm.tm.common.communication.PersonTemplate;
import jp.co.nec.lsm.tm.common.communication.SegmentPosition;
import jp.co.nec.lsm.tm.common.constants.EnrollErrorMessage;
import jp.co.nec.lsm.tm.common.log.BatchJobStatusLogger;
import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.validator.ValidationResult;
import jp.co.nec.lsm.tm.common.validator.ValidationResultError;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tm.protocolbuffer.common.BatchTypeProto.BatchType;
import jp.co.nec.lsm.tme.common.constants.EnrollConstants;
import jp.co.nec.lsm.tme.common.util.ResponseMessageBuilder;
import jp.co.nec.lsm.tme.core.clientapi.request.validator.EnrollCBPRequestValidator;
import jp.co.nec.lsm.tme.exception.EnrollRuntimeException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBBusinessMessage;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBRequest;
import com.nec.everest.proto.protobuf.BusinessMessage.CPBResponse;

/**
 * @author zhulk <br>
 * 
 */
public class LocalEnrollBatchJob {

	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(LocalEnrollBatchJob.class);

	private long batchJobId;

	private BatchType batchJobType;

	private EnrollBatchJobStatus batchJobStatus;

	private ConcurrentHashMap<Integer, LocalExtractJobInfo> jobInfo;

	private String syncGmv;

	private Date enqueue_TS;

	private Date extract_start_TS;

	private Date extract_end_TS;

	private Date insert_start_TS;

	private Date insert_end_TS;

	private Date sync_start_TS;

	private Date sync_end_TS;

	private Date batchJob_start_TS;

	private Date batchJob_end_TS;

	private int extractJobIndex;

	private List<SegmentPosition> segmentPositions;

	public LocalEnrollBatchJob() {
		extractJobIndex = EnrollConstants.EXTRACT_JOB_START_INDEX;
		batchJobStatus = EnrollBatchJobStatus.QUEUED;
		jobInfo = new ConcurrentHashMap<Integer, LocalExtractJobInfo>();
	}

	/**
	 * get the value of BatchJobId property
	 */
	public long getBatchJobId() {
		return batchJobId;
	}

	/**
	 * set the value of BatchJobId property
	 */
	public void setBatchJobId(long jobId) {
		this.batchJobId = jobId;
	}

	/**
	 * get the value of JobCount property
	 */
	public int getExtractJobCount() {
		return jobInfo.size();
	}

	/**
	 * get the value of BatchJobStatus property
	 */
	public EnrollBatchJobStatus getBatchJobStatus() {
		return batchJobStatus;
	}

	/**
	 * set the value of BatchJobStatus property
	 */
	public void setBatchJobStatus(EnrollBatchJobStatus status) {
		this.batchJobStatus = status;
	}

	/**
	 * set an EnrollBatchJobInfothe Object into JobInfo property
	 */
	public void putExtractJobInfo(LocalExtractJobInfo info) {
		this.jobInfo.put(info.getJobId(), info);
	}

	public void setSyncGmv(String syncGmv) {
		this.syncGmv = syncGmv;
	}

	public String getSyncGmv() {
		return syncGmv;
	}

	/**
	 * set the value of enqueue_TS property
	 */
	public void setEnqueueTS(Date enqueue_TS) {
		this.enqueue_TS = enqueue_TS;
	}

	/**
	 * get the value of enqueue_TS property
	 */
	public Date getEnqueueTS() {
		return enqueue_TS;
	}

	/**
	 * set the value of extract_start_TS property
	 */
	public void setExtractStartTS(Date extract_start_TS) {
		this.extract_start_TS = extract_start_TS;
	}

	/**
	 * get the value of extract_start_TS property
	 */
	public Date getExtractStartTS() {
		return extract_start_TS;
	}

	/**
	 * set the value of extract_end_TS property
	 */
	public void setExtractEndTS(Date extract_end_TS) {
		this.extract_end_TS = extract_end_TS;
	}

	/**
	 * get the value of extract_end_TS property
	 */
	public Date getExtractEndTS() {
		return extract_end_TS;
	}

	/**
	 * set the value of insert_start_TS property
	 */
	public void setInsertStartTS(Date insert_start_TS) {
		this.insert_start_TS = insert_start_TS;
	}

	/**
	 * get the value of insert_start_TS property
	 */
	public Date getInsertStartTS() {
		return insert_start_TS;
	}

	/**
	 * set the value of insert_end_TS property
	 */
	public void setInsertEndTS(Date insert_end_TS) {
		this.insert_end_TS = insert_end_TS;
	}

	/**
	 * get the value of insert_end_TS property
	 */
	public Date getInsertEndTS() {
		return insert_end_TS;
	}

	/**
	 * set the value of sync_start_TS property
	 */
	public void setSyncStartTS(Date sync_start_TS) {
		this.sync_start_TS = sync_start_TS;
	}

	/**
	 * get the value of sync_start_TS property
	 */
	public Date getSyncStartTS() {
		return sync_start_TS;
	}

	/**
	 * set the value of sync_end_TS property
	 */
	public void setSyncEndTS(Date sync_end_TS) {
		this.sync_end_TS = sync_end_TS;
	}

	/**
	 * get the value of sync_end_TS property
	 */
	public Date getSyncEndTS() {
		return sync_end_TS;
	}

	public Date getBatchJob_start_TS() {
		return batchJob_start_TS;
	}

	public void setBatchJob_start_TS(Date batchJobStartTS) {
		batchJob_start_TS = batchJobStartTS;
	}

	public Date getBatchJob_end_TS() {
		return batchJob_end_TS;
	}

	public void setBatchJob_end_TS(Date batchJobEndTS) {
		batchJob_end_TS = batchJobEndTS;
	}

	/**
	 * set the value of batchJobType property
	 */
	public void setBatchJobType(BatchType batchJobType) {
		this.batchJobType = batchJobType;
	}

	/**
	 * set the value of segmentPositions property
	 */
	public void setSegmentPosition(List<SegmentPosition> segmentPosition) {
		this.segmentPositions = segmentPosition;
	}

	/**
	 * 
	 * @param jobIndex
	 * @return
	 */
	public LocalExtractJobInfo getExtractJobInfo(Integer jobIndex) {
		return jobInfo.get(jobIndex);
	}

	/**
	 * get the value of segmentPositions property
	 */
	public List<SegmentPosition> getSegmentPosition() {
		return segmentPositions;
	}

	// /////////////////////////////////////////////////////////////////
	// // job info validate ////
	// /////////////////////////////////////////////////////////////////
	/**
	 * set the value of BatchJobStatus property
	 */
	public boolean isBatchJobStatus(EnrollBatchJobStatus status) {
		return this.batchJobStatus == status;
	}

	/**
	 * get the value of batchJobType property
	 */
	public boolean isBatchJobType(BatchType type) {
		return batchJobType == type;
	}

	/**
	 * get the value of batchJobType property
	 */
	public BatchType getBatchJobType() {
		return batchJobType;
	}

	/**
	 * 
	 * @return
	 */
	public boolean areAllExtractJobsDone() {
		int extractJobCount = jobInfo.size();
		for (int i = EnrollConstants.EXTRACT_JOB_START_INDEX; i <= extractJobCount; i++) {
			LocalExtractJobInfo extractjob = jobInfo.get(i);
			if (!extractjob.isStatus(LocalExtractJobStatus.DONE)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 
	 * @return
	 */
	public boolean isNoExtrctJobAssigned() {
		int extractJobCount = jobInfo.size();
		for (int i = EnrollConstants.EXTRACT_JOB_START_INDEX; i <= extractJobCount; i++) {
			LocalExtractJobInfo extractjob = jobInfo.get(i);
			if (!extractjob.isStatus(LocalExtractJobStatus.READY)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 
	 * @return
	 */
	public boolean hasSuccessedExtractJob() {
		int extractJobCount = jobInfo.size();
		for (int i = EnrollConstants.EXTRACT_JOB_START_INDEX; i <= extractJobCount; i++) {
			LocalExtractJobInfo extractjob = jobInfo.get(i);
			if (extractjob.isSuccessed()) {
				return true;
			}
		}
		return false;
	}

	public int getAssignedExtractJobCount() {
		int assignedExtractJobCount = 0;
		int extractJobCount = jobInfo.size();
		for (int i = EnrollConstants.EXTRACT_JOB_START_INDEX; i <= extractJobCount; i++) {
			LocalExtractJobInfo extractjob = jobInfo.get(i);
			if (!extractjob.isStatus(LocalExtractJobStatus.READY)) {
				assignedExtractJobCount++;
			}
		}
		return assignedExtractJobCount;
	}

	public int getSuccessExtractJobCount() {
		int successExtractJobCount = 0;
		int extractJobCount = jobInfo.size();
		for (int i = EnrollConstants.EXTRACT_JOB_START_INDEX; i <= extractJobCount; i++) {
			LocalExtractJobInfo extractjob = jobInfo.get(i);
			if (extractjob.isSuccessed()) {
				successExtractJobCount++;
			}
		}
		return successExtractJobCount;
	}

	public int getExtractingJobCount() {
		int extractingJobCount = 0;
		int extractJobCount = jobInfo.size();
		for (int i = EnrollConstants.EXTRACT_JOB_START_INDEX; i <= extractJobCount; i++) {
			LocalExtractJobInfo extractjob = jobInfo.get(i);
			if (extractjob.isStatus(LocalExtractJobStatus.EXTRACTING)) {
				extractingJobCount++;
			}
		}
		return extractingJobCount;
	}

	public int getCompletedExtractJobCount() {
		int completedExtractJobCount = 0;
		int extractJobCount = jobInfo.size();
		for (int i = EnrollConstants.EXTRACT_JOB_START_INDEX; i <= extractJobCount; i++) {
			LocalExtractJobInfo extractjob = jobInfo.get(i);
			if (extractjob.isStatus(LocalExtractJobStatus.DONE)) {
				completedExtractJobCount++;
			}
		}
		return completedExtractJobCount;
	}

	/**
	 * make LocalEnrollBatchJobInfo Failed which Oracle Exception
	 * 
	 * @param enrollBatchJob
	 */
	public void makeDBExceptionFailed() {
		// make LocalEnrollBatchJobInfo Failed which Oracle Exception
		int extractJobCount = jobInfo.size();
		for (int i = EnrollConstants.EXTRACT_JOB_START_INDEX; i <= extractJobCount; i++) {
			LocalExtractJobInfo extractjobInfo = jobInfo.get(i);
			if (extractjobInfo.isSuccessed()) {
				extractjobInfo.setReturnCode(ReturnCode.JobFailed);
				extractjobInfo.setReSendable(true);
				extractjobInfo.setStatus(LocalExtractJobStatus.DONE);
				extractjobInfo
						.setErrorCode(EnrollErrorMessage.ENROLL_ORACLE_EXCEPTION
								.getErrorCode());
				extractjobInfo.setErrorMessage("Oracle Exception.");

				CPBRequest request = extractjobInfo.getRequest().getRequest();
				CPBBusinessMessage response = ResponseMessageBuilder
						.createBusinessMessageByRequest(request,
								ReturnCode.JobFailed, extractjobInfo
										.getErrorCode(), extractjobInfo
										.getErrorMessage(), extractjobInfo
										.getReSendable());

				extractjobInfo.setResponse(response);
			}
		}
	}

	/**
	 * check Duplication Reference Ids base on DB
	 * 
	 * @param enrollBatchJob
	 */
	public void makeDuplicatedExtractJobsFailed(List<String> duplicateIds) {
		// make LocalEnrollBatchJobInfo Failed which Reference Id is duplication
		// base on database
		int extractJobCount = jobInfo.size();
		for (String referenceId : duplicateIds) {
			for (int i = EnrollConstants.EXTRACT_JOB_START_INDEX; i <= extractJobCount; i++) {
				LocalExtractJobInfo extractjobInfo = jobInfo.get(i);
				if (extractjobInfo.isSuccessed()
						&& extractjobInfo.getReferenceId().equals(referenceId)) {
					extractjobInfo.setReturnCode(ReturnCode.JobFailed);
					extractjobInfo.setReSendable(false);
					extractjobInfo.setStatus(LocalExtractJobStatus.DONE);
					extractjobInfo
							.setErrorCode(EnrollErrorMessage.REFERENCEID_DUPLICATED
									.getErrorCode());
					extractjobInfo
							.setErrorMessage("Enroll Job ( Failed because of reference id duplication).");

					CPBRequest request = extractjobInfo.getRequest()
							.getRequest();
					CPBBusinessMessage response = ResponseMessageBuilder
							.createBusinessMessageByRequest(request,
									ReturnCode.JobFailed, extractjobInfo
											.getErrorCode(), extractjobInfo
											.getErrorMessage(), extractjobInfo
											.getReSendable());

					extractjobInfo.setResponse(response);
					break;
				}
			}
		}
	}

	/**
	 * save BiometicIds into extract job info
	 * 
	 * @param personReferenceIDList
	 */
	public void saveBiometicIdsInfo(
			List<PersonReferenceID> personReferenceIDList) {
		int extractJobCount = jobInfo.size();
		for (int j = 0; j < personReferenceIDList.size(); j++) {
			PersonReferenceID personReferenceID = personReferenceIDList.get(j);
			String referenceId = personReferenceID.getReferenceId();
			for (int i = EnrollConstants.EXTRACT_JOB_START_INDEX; i <= extractJobCount; i++) {
				LocalExtractJobInfo extractjobInfo = jobInfo.get(i);
				if (extractjobInfo.isSuccessed()
						&& extractjobInfo.getReferenceId().equals(referenceId)) {
					extractjobInfo.setBiometricId(personReferenceID
							.getBiometricId());
					break;
				}
			}
		}
	}

	/**
	 * create Enroll Batch Job based Enroll Request from Transformer
	 * 
	 * @param request
	 *            Enroll Request from Transformer
	 * @return Enroll Batch Job
	 */
	public static LocalEnrollBatchJob createEnrollBatchJob(Long batchJobId,
			BatchType batchType, List<CPBBusinessMessage> businessMessageList,
			Date now) {
		printLogMessage("start private function createEnrollBatchJob()..");

		LocalEnrollBatchJob enrollBatchJob = new LocalEnrollBatchJob();
		enrollBatchJob.setBatchJobId(batchJobId);
		enrollBatchJob.setBatchJobType(batchType);
		enrollBatchJob.setBatchJobStatus(EnrollBatchJobStatus.QUEUED);
		enrollBatchJob.setEnqueueTS(now);

		if (log.isInfoEnabled()) {
			BatchJobStatusLogger.outputBatchJobStatus(
					LogConstants.STATUS_CATEGORY_TME, enrollBatchJob
							.getBatchJobId(), EnrollBatchJobStatus.QUEUED
							.name());
		}

		List<String> requestIdlist = new ArrayList<String>();
		printLogMessage("loop the EnrollJobInfo to add extract jobs...");
		for (int i = 0; i < businessMessageList.size(); i++) {
			CPBBusinessMessage businessMessage = businessMessageList.get(i);

			LocalExtractJobInfo extractJob = enrollBatchJob
					.createExtractJobInfo(businessMessage);

			ValidationResult validationResult = EnrollCBPRequestValidator
					.validate(batchJobId, extractJob.getJobId(),
							businessMessage.getRequest());
			if (validationResult != null && validationResult.hasErrors()) {
				List<ValidationResultError> resultErrorList = validationResult
						.getRequestError();
				makeExtractJobFailed(resultErrorList.get(0).getErrorCode(),
						resultErrorList.get(0).getInvalidReason(),
						enrollBatchJob, extractJob, now);

			} else if (requestIdlist.contains(extractJob.getRequestId())) {
				makeDuplicateRequestIdExtractJobFailed(enrollBatchJob,
						extractJob, now);
			}

			requestIdlist.add(extractJob.getRequestId());
			enrollBatchJob.putExtractJobInfo(extractJob);
		}

		if (log.isInfoEnabled()) {
			log.info(InfoLogger.infoOutput(
					LogConstants.COMPONENT_ACCEPT_SERVICE_BEAN_TME,
					LogConstants.FUNCTION_CREATE_ENROLL_BATCH_JOB, "DETAIL",
					"added " + enrollBatchJob.getExtractJobCount()
							+ " extract jobs to batch job : " + batchJobId
							+ "."));
		}

		printLogMessage("end private function createEnrollBatchJob()..");
		return enrollBatchJob;
	}

	/**
	 * 
	 * @param enrollBatchJob
	 * @param extractJob
	 * @param now
	 */
	private static void makeDuplicateRequestIdExtractJobFailed(
			LocalEnrollBatchJob enrollBatchJob, LocalExtractJobInfo extractJob,
			Date now) {

		// String errorCode = EnrollErrorMessage.REQUESTID_DUPLICATED
		// .getErrorCode();
		// String errorMessage =
		// "Extract Job (Request Id is Duplication. BatchJob Id: "
		// + enrollBatchJob.getBatchJobId()
		// + " jobIndex: "
		// + extractJob.getJobId()
		// + " Request Id: "
		// + extractJob.getRequestId() + ").";
		//
		// makeExtractJobFailed(errorCode, errorMessage, enrollBatchJob,
		// extractJob, now);
		//
		// log.warn(errorMessage);
	}

	/**
	 * 
	 * @param resultError
	 * @param extractJob
	 * @param now
	 */
	private static void makeExtractJobFailed(String errorCode,
			String errorMessage, LocalEnrollBatchJob enrollBatchJob,
			LocalExtractJobInfo extractJob, Date now) {
		extractJob.setStatus(LocalExtractJobStatus.DONE);
		extractJob.setReturnCode(ReturnCode.JobFailed);
		extractJob.setErrorCode(errorCode);
		extractJob.setReSendable(false);
		extractJob.setErrorMessage(errorMessage);
		extractJob.setExtractStartTS(now);
		extractJob.setExtractEndTS(now);
		CPBRequest request = extractJob.getRequest().getRequest();
		CPBBusinessMessage response = ResponseMessageBuilder
				.createBusinessMessageByRequest(request, ReturnCode.JobFailed,
						errorCode, errorMessage, extractJob.getReSendable());

		extractJob.setResponse(response);

		log.warn(errorMessage);

		if (enrollBatchJob.isBatchJobStatus(EnrollBatchJobStatus.QUEUED)) {
			enrollBatchJob.setBatchJobStatus(EnrollBatchJobStatus.EXTRACTING);
			enrollBatchJob.setExtractStartTS(now);
			enrollBatchJob.setBatchJob_start_TS(now);

			if (log.isInfoEnabled()) {
				BatchJobStatusLogger.outputBatchJobStatus(
						LogConstants.STATUS_CATEGORY_TME, enrollBatchJob
								.getBatchJobId(),
						EnrollBatchJobStatus.EXTRACTING.name());
			}
		}
	}

	/**
	 * 
	 * @param extractResult
	 * @param now
	 */
	public void updateBatchJob(ExtractJobResultRequest extractResult, Date now) {
		printLogMessage("start public function updateBatchJob");
		int count = 0;
		List<ExtractJobResult> extractJobResultList = extractResult
				.getExtractJobResultList();
		for (int i = 0; i < extractJobResultList.size(); i++) {
			ExtractJobResult jobResult = extractJobResultList.get(i);
			// fetch Enroll Batch Job Info by Job Index.
			LocalExtractJobInfo extractJobinfo = jobInfo.get(jobResult
					.getJobIndex());
			if (extractJobinfo != null
					&& extractJobinfo
							.isStatus(LocalExtractJobStatus.EXTRACTING)) {

				// update batch Job info based Extract Job Result.
				updateExtractJob(jobResult, extractJobinfo, now);

				count++;

				printLogMessage("extract job " + jobResult.getJobIndex()
						+ " of batch Job " + batchJobId + " is done.");

			} else {
				log
						.warn(
								"can not find extract job info(JobIndex: {}, job status: EXTRACTING)",
								jobResult.getJobIndex());
			}
		}

		if (log.isInfoEnabled()) {
			log.info(InfoLogger.infoOutput(
					LogConstants.COMPONENT_REPORT_SERVICE_BEAN,
					LogConstants.FUNCTION_UPDATE_BATCH_JOB, "DETAIL", "update "
							+ count + " extract jobs of batch job "
							+ batchJobId + "."));
		}
		printLogMessage("end public function updateBatchJob");
	}

	/**
	 * 
	 * @param jobResult
	 * @param extractJobinfo
	 * @param now
	 * @throws InvalidProtocolBufferException
	 */
	private void updateExtractJob(ExtractJobResult jobResult,
			LocalExtractJobInfo extractJobinfo, Date now) {
		extractJobinfo.setTemplate(jobResult.getTemplate().toByteArray());
		extractJobinfo.setReturnCode(jobResult.getReturnCode());
		extractJobinfo.setErrorCode(new Integer(jobResult.getErrorCode())
				.toString());
		if (jobResult.getReturnCode() != ReturnCode.JobSuccess) {
			extractJobinfo.setReSendable(jobResult.getResendable());
			extractJobinfo.setErrorMessage(jobResult.getErrorMessage());
		}

		CPBBusinessMessage.Builder businessMessage = null;
		try {
			businessMessage = CPBBusinessMessage.parseFrom(
					jobResult.getResponse()).toBuilder();
		} catch (InvalidProtocolBufferException e) {
			String message = "Parse Error From ExtractJobResult's Response. BatchJob Id: "
					+ batchJobId
					+ " ExtractJob Index: "
					+ extractJobinfo.getJobId();
			log.error(message);
			throw new EnrollRuntimeException(message, e);
		}
		businessMessage.setRequest(extractJobinfo.getRequest().getRequest());
		extractJobinfo.setResponse(businessMessage.build());
		extractJobinfo.setStatus(LocalExtractJobStatus.DONE);
		extractJobinfo.setExtractEndTS(now);
	}

	/**
	 * 
	 */
	public void complete(Date now) {
		batchJobStatus = EnrollBatchJobStatus.EXTRACTED;
		extract_end_TS = now;
	}

	/**
	 * 
	 * @return
	 */
	public List<PersonTemplate> getSuccessJobTemplate() {
		List<PersonTemplate> jobTemplateList = new ArrayList<PersonTemplate>();
		int extractJobCount = jobInfo.size();
		for (int i = EnrollConstants.EXTRACT_JOB_START_INDEX; i <= extractJobCount; i++) {
			LocalExtractJobInfo extractjob = jobInfo.get(i);
			if (extractjob.isSuccessed()) {
				jobTemplateList.add(extractjob.createLocalPersonTemplate());
			}
		}

		return jobTemplateList;
	}

	/**
	 * 
	 * @param referenceIds
	 * @return
	 */
	public byte[] getTemplateArray(List<String> referenceIds, int templateSize) {
		byte[] template = new byte[referenceIds.size() * templateSize];
		int pos = 0;
		int extractJobCount = jobInfo.size();
		for (String referenceId : referenceIds) {
			for (int index = EnrollConstants.EXTRACT_JOB_START_INDEX; index <= extractJobCount; index++) {
				LocalExtractJobInfo extractjob = jobInfo.get(index);
				if (extractjob.isSuccessed()
						&& extractjob.getReferenceId().equals(referenceId)) {
					for (int i = 0; i < extractjob.getTemplate().length; i++) {
						template[pos] = extractjob.getTemplate()[i];
						pos++;
					}
					break;
				}
			}
		}

		return template;
	}

	/**
	 * 
	 * @param referenceIds
	 * @return
	 */
	public byte[] getTemplateArray(long bioStartId, long bioEndId,
			int templateSize) {
		int pos = 0;
		int extractJobCount = jobInfo.size();
		List<LocalExtractJobInfo> extractjobList = new ArrayList<LocalExtractJobInfo>();
		for (int index = EnrollConstants.EXTRACT_JOB_START_INDEX; index <= extractJobCount; index++) {
			LocalExtractJobInfo extractjob = jobInfo.get(index);
			long biometricId = extractjob.getBiometricId();
			if (extractjob.isSuccessed() && bioStartId <= biometricId
					&& biometricId <= bioEndId) {
				extractjobList.add(extractjob);
			}
		}

		byte[] template = new byte[extractjobList.size() * templateSize];
		for (int j = 0; j < extractjobList.size(); j++) {
			LocalExtractJobInfo extractjob = extractjobList.get(j);
			for (int i = 0; i < extractjob.getTemplate().length; i++) {
				template[pos] = extractjob.getTemplate()[i];
				pos++;
			}
		}
		return template;
	}

	/**
	 * 
	 * @param jobInfoList
	 * @param muId
	 * @param nRequestJobNumber
	 * @param now
	 */
	public List<ExtractJob> getAssignedExtractJobList(int muId,
			int nRequestJobNumber, Date now) {
		List<ExtractJob> jobInfoList = new ArrayList<ExtractJob>();
		// loop extract jobs for assigning extract jobs to MFE.
		for (int i = EnrollConstants.EXTRACT_JOB_START_INDEX; i <= jobInfo
				.size(); i++) {
			// when assigned nRequestJobNumber Extract Jobs, stop assigning
			if (jobInfoList.size() >= nRequestJobNumber) {
				break;
			}

			LocalExtractJobInfo extractJobInfo = jobInfo.get(i);

			if (extractJobInfo == null)
				continue;
			// check Enroll Batch Job status. Only the extract jobs
			// which status is READY will be assigned.
			if (!extractJobInfo.isStatus(LocalExtractJobStatus.READY)) {
				continue;
			}
			// create an Extract Job for assigning
			ExtractJob extractJob = extractJobInfo.createExtractJob();
			jobInfoList.add(extractJob);

			// change status and time of the assigned extract job
			extractJobInfo.changeStatusToEXTRACTING(muId, now);

			printLogMessage("Assigned extract Job " + i + " of batch job "
					+ batchJobId + " to MuId " + muId);
		}
		return jobInfoList;
	}

	/**
	 * create ExtractResultInfo list for EnrollResponse
	 * 
	 * @param batchJob
	 *            Enroll Batch Job
	 * @return ExtractResultInfo list
	 */
	public List<ByteString> prepareEnrollJobResultInfo() {
		List<ByteString> resultList = new ArrayList<ByteString>();

		// create ExtractResultInfo list for EnrollResponse
		printLogMessage("create ExtractResultInfo list for EnrollResponse.");

		for (int i = EnrollConstants.EXTRACT_JOB_START_INDEX; i <= jobInfo
				.size(); i++) {
			LocalExtractJobInfo extractJobInfo = jobInfo.get(i);

			ByteString result = ByteString.EMPTY;
			CPBBusinessMessage message = extractJobInfo.getResponse();
			ReturnCode returnCode = extractJobInfo.getReturnCode();
			String errorCode = extractJobInfo.getErrorCode();
			String reSendable = extractJobInfo.getReSendable();
			String errorMessage = extractJobInfo.getErrorMessage();
			if (message == null) {
				CPBRequest request = extractJobInfo.getRequest().getRequest();
				CPBBusinessMessage businessMessage = ResponseMessageBuilder
						.createBusinessMessageByRequest(request, returnCode,
								errorCode, errorMessage, reSendable);
				result = businessMessage.toByteString();
			} else {
				CPBBusinessMessage.Builder businessMessage = message
						.toBuilder();
				CPBResponse response = ResponseMessageBuilder
						.rebuildCPBResponse(businessMessage.getResponse(),
								returnCode, errorCode, errorMessage, reSendable);

				businessMessage.setResponse(response);
				result = businessMessage.build().toByteString();
			}

			// add ExtractResultInfo into list
			resultList.add(result);
		}

		return resultList;
	}

	/**
	 * 
	 * @param jobinfo
	 * @return
	 */
	public LocalExtractJobInfo createExtractJobInfo(CPBBusinessMessage request) {
		LocalExtractJobInfo info = new LocalExtractJobInfo();
		info.setJobId(extractJobIndex);
		info.setRequestId(request.getRequest().getRequestId());
		info.setStatus(LocalExtractJobStatus.READY);
		info.setReferenceId(request.getRequest().getEnrollmentId());
		info.setRequest(request);

		extractJobIndex++;
		return info;
	}

	/**
	 * 
	 * @param extractJobinfo
	 */
	public void retryExtractJob(LocalExtractJobInfo extractJobinfo) {
		extractJobinfo.retry();
	}

	/**
	 * 
	 * @param extractJobinfo
	 * @param now
	 */
	public void doneExtractJobByInternalError(
			LocalExtractJobInfo extractJobinfo, Date now) {
		extractJobinfo.doneByInternalError(now);
	}

	/**
	 * 
	 * @return
	 */
	public String getSummary() {
		int assignedExtractJobCount = 0;
		int completedExtractJobCount = 0;
		String br = System.getProperty("line.separator");
		StringBuilder stringBuilder = new StringBuilder();

		stringBuilder.append("batch job id: ");
		stringBuilder.append(batchJobId);
		stringBuilder.append(br);

		stringBuilder.append("batch job status: ");
		stringBuilder.append(batchJobStatus.toString());
		stringBuilder.append(br);

		stringBuilder.append("extract job count: ");
		stringBuilder.append(jobInfo.size());
		stringBuilder.append(br);

		for (int i = EnrollConstants.EXTRACT_JOB_START_INDEX; i <= jobInfo
				.size(); i++) {
			LocalExtractJobInfo extractjob = jobInfo.get(i);
			if (!extractjob.isStatus(LocalExtractJobStatus.READY)) {
				assignedExtractJobCount++;
			}
			if (extractjob.isStatus(LocalExtractJobStatus.DONE)) {
				completedExtractJobCount++;
			}
		}

		stringBuilder.append("assigned extract job count: ");
		stringBuilder.append(assignedExtractJobCount);
		stringBuilder.append(br);

		stringBuilder.append("completed extract job count: ");
		stringBuilder.append(completedExtractJobCount);
		stringBuilder.append(br);

		for (int i = EnrollConstants.EXTRACT_JOB_START_INDEX; i <= jobInfo
				.size(); i++) {
			LocalExtractJobInfo extractjob = jobInfo.get(i);
			stringBuilder.append(extractjob.getSummary());
		}

		return stringBuilder.toString();
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

}
