package jp.co.nec.lsm.tme.service.pojo;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import jp.co.nec.lsm.proto.extract.ExtractJobRequestProto.ExtractJobRequest;
import jp.co.nec.lsm.proto.extract.ExtractJobResponseProto.ExtractJob;
import jp.co.nec.lsm.proto.extract.ExtractJobResponseProto.ExtractJobResponse;
import jp.co.nec.lsm.tm.common.log.BatchJobStatusLogger;
import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;

import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author mozj <br>
 *         assigned extract jobs to MFE.
 */
public class EnrollExtractJobAssignServiceBean {

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(EnrollExtractJobAssignServiceBean.class);

	/**
	 * constructor
	 */
	public EnrollExtractJobAssignServiceBean() {
	}

	/**
	 * assigned extract jobs to MFE.
	 */
	public ExtractJobResponse doAssign(ExtractJobRequest jobRequest) {
		if (jobRequest == null) {
			throw new IllegalArgumentException(
					"ExtractJobRequest can not be null.");
		}

		printLogMessage("start public function doAssign()..");

		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		Integer gmvID = jobRequest.getGmvId();
		Integer maxExtractjob = jobRequest.getMaxExtractJob();

		if (log.isInfoEnabled()) {
			log.info(InfoLogger.deliveryJobInfoOutput(
					LogConstants.INFO_ENROLL_JOB_DELIVERY_REQUEST,
					LogConstants.DETAIL_MFE_ID, gmvID.toString(),
					"RequestMaxExtractJob", maxExtractjob.toString()));
		}

		// assigned extract jobs to MFE.
		ExtractJobResponse extractJob = fetchExtractJobs(gmvID, maxExtractjob);

		if (extractJob != null) {
			if (log.isInfoEnabled()) {
				log.info(InfoLogger.deliveryJobInfoOutput(
						LogConstants.INFO_ENROLL_JOB_DELIVERY_RESPONSE,
						LogConstants.DETAIL_MFE_ID, gmvID.toString(),
						LogConstants.DETAIL_BATCH_JOB_ID,
						Long.valueOf(extractJob.getBatchJobId()).toString(),
						"deliveryJobNumber",
						Integer.valueOf(extractJob.getExtractJobCount())
								.toString()));
			}
		} else {
			if (log.isInfoEnabled()) {
				log.info(InfoLogger.deliveryJobInfoOutput(
						LogConstants.INFO_ENROLL_JOB_DELIVERY_RESPONSE,
						LogConstants.DETAIL_MFE_ID, gmvID.toString(),
						LogConstants.DETAIL_BATCH_JOB_ID,
						LogConstants.DETAIL_EMPTY));
			}
		}

		stopWatch.stop();

		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_EXTRACT_JOB_ASSIGN_SERVICE_BEAN,
				LogConstants.FUNCTION_DOASSIGN, stopWatch.getTime());

		printLogMessage("end public function doAssign()..");
		return extractJob;
	}

	/**
	 * fetch unassigned extract jobs to assigned to MFE, then change the jobs
	 * status.
	 * 
	 * @param muId
	 *            MFE Id
	 * @param nRequestJobNumber
	 *            the number of request extract jobs
	 * @return Extract Job Response to USC
	 */
	public ExtractJobResponse fetchExtractJobs(int muId, int nRequestJobNumber) {
		printLogMessage("start public function fetchExtractJobs()..");

		// get local enroll queue
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		ConcurrentLinkedQueue<LocalEnrollBatchJob> enrollLinkQueue = queueManage
				.getEnrollLinkQueue();

		List<ExtractJob> jobInfoList = null;
		Iterator<LocalEnrollBatchJob> iterator = enrollLinkQueue.iterator();

		// loop batch jobs for assigning extract jobs to MFE.
		printLogMessage("loop the enroll local queue to assign extract jobs.");

		long batchJobId = 0;
		while (iterator.hasNext()) {
			LocalEnrollBatchJob batchJob = iterator.next();
			// check Enroll Batch Job status. Only find from the batch job which
			// status is QUEUED and EXTRACTING.
			if (batchJob.isBatchJobStatus(EnrollBatchJobStatus.QUEUED)
					|| batchJob
							.isBatchJobStatus(EnrollBatchJobStatus.EXTRACTING)) {

				//
				jobInfoList = prepareAssignedExtractJobList(batchJob, muId,
						nRequestJobNumber);
				if (jobInfoList != null && !jobInfoList.isEmpty()) {
					batchJobId = batchJob.getBatchJobId();
					break;
				}
			}
		}

		// no unassigned extract job for MFE
		if (jobInfoList == null || jobInfoList.isEmpty()) {
			log.info("There is no unassigned extract job for MFE(id : {}).",
					muId);
			return null;
		}

		if (log.isInfoEnabled()) {
			log.info(InfoLogger.infoOutput(
					LogConstants.COMPONENT_EXTRACT_JOB_ASSIGN_SERVICE_BEAN,
					LogConstants.FUNCTION_FETCH_EXTRACT_JOBS, "DETAIL",
					"assign " + jobInfoList.size()
							+ " extract jobs to MFE(id : " + muId + ")."));
		}

		// create ExtractJobResponse
		ExtractJobResponse extractJob = createExtractJobResponse(batchJobId,
				jobInfoList);

		printLogMessage("end public function fetchExtractJobs()..");
		return extractJob;
	}

	/**
	 * 
	 * @param batchJob
	 * @param jobInfoList
	 * @param muId
	 * @param nRequestJobNumber
	 * @return
	 */
	private List<ExtractJob> prepareAssignedExtractJobList(
			LocalEnrollBatchJob batchJob, int muId, int nRequestJobNumber) {
		Date now = DateUtil.getCurrentDate();

		List<ExtractJob> jobInfoList = null;
		synchronized (batchJob) {
			jobInfoList = batchJob.getAssignedExtractJobList(muId,
					nRequestJobNumber, now);
		}
		// change status and AssignedCount of the enroll batch job
		if (jobInfoList != null && !jobInfoList.isEmpty()) {

			if (batchJob.isBatchJobStatus(EnrollBatchJobStatus.QUEUED)) {
				batchJob.setBatchJobStatus(EnrollBatchJobStatus.EXTRACTING);
				batchJob.setExtractStartTS(now);
				batchJob.setBatchJob_start_TS(now);

				if (log.isInfoEnabled()) {
					BatchJobStatusLogger.outputBatchJobStatus(
							LogConstants.STATUS_CATEGORY_TME,
							batchJob.getBatchJobId(),
							EnrollBatchJobStatus.EXTRACTING.name());
				}
			}

		}

		return jobInfoList;
	}

	/***
	 * create ExtractJobResponse
	 * 
	 * @param batchJobId
	 * @param jobInfoList
	 * @return
	 */
	private ExtractJobResponse createExtractJobResponse(long batchJobId,
			List<ExtractJob> jobInfoList) {
		ExtractJobResponse.Builder extractJob = ExtractJobResponse.newBuilder();
		extractJob.addAllExtractJob(jobInfoList);
		extractJob.setBatchJobId(batchJobId);
		return extractJob.build();
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
