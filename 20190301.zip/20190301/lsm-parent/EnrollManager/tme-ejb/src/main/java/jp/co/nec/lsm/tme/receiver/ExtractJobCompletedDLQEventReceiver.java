package jp.co.nec.lsm.tme.receiver;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.MessageListener;

import jp.co.nec.lsm.event.Event;
import jp.co.nec.lsm.event.enroll.EnrollExtractJobCompletedEvent;
import jp.co.nec.lsm.event.receiver.AbstractEventReceiver;
import jp.co.nec.lsm.tm.common.constants.DeployName;
import jp.co.nec.lsm.tm.common.constants.JNDIConstants;
import jp.co.nec.lsm.tm.common.util.ServiceLocator;
import jp.co.nec.lsm.tme.service.sessionbean.EnrollDeadLevelQueueService;
import jp.co.nec.lsm.tme.sessionbeans.api.EnrollDeadLevelQueueServiceLocal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author liuyq <br>
 */
@MessageDriven(activationConfig = {
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
		@ActivationConfigProperty(propertyName = "destination", propertyValue = JNDIConstants.DLQ),
		@ActivationConfigProperty(propertyName = "messageSelector", propertyValue = "messageReceiver = 'TemplateManagerBean'") })
public class ExtractJobCompletedDLQEventReceiver extends AbstractEventReceiver
		implements MessageListener {

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(ExtractJobCompletedDLQEventReceiver.class);

	/**
	 * receiver: EnrollResponseService.. after Enroll Segment Sync Service done
	 * notify EnrollResponseService
	 * 
	 * @param event
	 */
	@Override
	protected void dispatchEvent(Event event) {
		printLogMessage("start private function dispatchEvent()..");

		// look up the service session bean
		if (!(event instanceof EnrollExtractJobCompletedEvent)) {
			log.error("event is not a EnrollExtractJobCompletedEvent instance.");
			return;
		}
		EnrollExtractJobCompletedEvent etue = (EnrollExtractJobCompletedEvent) event;
		String jndiName = DeployName.ENROLL_EARFILE + JNDIConstants.SPLIT
				+ EnrollDeadLevelQueueService.class.getSimpleName()
				+ JNDIConstants.LOCAL;

		EnrollDeadLevelQueueServiceLocal template = ServiceLocator
				.getLookUpJndiObject(jndiName,
						EnrollDeadLevelQueueServiceLocal.class);
		template.receiveEventFromDLQ(etue.getBatchJobId(), true);

		printLogMessage("end private function dispatchEvent()..");

	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
