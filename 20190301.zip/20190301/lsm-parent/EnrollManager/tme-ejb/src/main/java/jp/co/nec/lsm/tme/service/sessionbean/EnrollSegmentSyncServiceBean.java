package jp.co.nec.lsm.tme.service.sessionbean;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Singleton;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import jp.co.nec.lsm.event.enroll.common.EnrollNotifierEnum;
import jp.co.nec.lsm.proto.common.CommonProto.ComponentType;
import jp.co.nec.lsm.proto.segment.SegmentUpdateRequestProto.SegmentUpdateRequest;
import jp.co.nec.lsm.proto.segment.SegmentUpdateResponseProto.SegmentUpdateResponse;
import jp.co.nec.lsm.tm.common.communication.SegmentPosition;
import jp.co.nec.lsm.tm.common.constants.Constants;
import jp.co.nec.lsm.tm.common.constants.SegmentDeleteSyn;
import jp.co.nec.lsm.tm.common.log.BatchJobStatusLogger;
import jp.co.nec.lsm.tm.common.log.InfoLogger;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.common.entities.MatchUnitEntity;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tme.common.util.EnrollEventBus;
import jp.co.nec.lsm.tme.core.gmvapi.request.sender.SegmentUpdateRequestSender;
import jp.co.nec.lsm.tme.core.jobs.DeletionJobManager;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalDeletionJob;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.db.dao.EnrollMuSegmentMapDaoLocal;
import jp.co.nec.lsm.tme.db.dao.EnrollSystemConfigDaoLocal;
import jp.co.nec.lsm.tme.exception.EnrollRuntimeException;
import jp.co.nec.lsm.tme.sessionbeans.api.EnrollSegmentSyncServiceLocal;

import org.apache.commons.httpclient.HttpException;
import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.protobuf.ByteString;

/**
 * @author mozj <br>
 */
@Singleton
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class EnrollSegmentSyncServiceBean implements
		EnrollSegmentSyncServiceLocal {
	@EJB
	private EnrollMuSegmentMapDaoLocal muSegmentMapDao;
	@EJB
	private EnrollSystemConfigDaoLocal systemConfigDao;

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(EnrollSegmentSyncServiceBean.class);

	/**
	 * constructor
	 */
	public EnrollSegmentSyncServiceBean() {
	}

	/**
	 * The method used to synchronize Segment by batchJobId.
	 * 
	 * @throws InterruptedException
	 */
	@Override
	@Lock(LockType.WRITE)
	public void synchronizeSegment(long batchJobId) {
		printLogMessage("start public function SegmentSync()..");
		if (log.isInfoEnabled()) {
			log.info(InfoLogger.serialExecutionInfoOutput(
					LogConstants.COMPONENT_SEGMENT_SYNC_SERVICE_BEAN,
					LogConstants.FUNCTION_SYSNCHRONIZE_SEGMENT,
					LogConstants.DETAIL_ACTION_START, batchJobId, Thread
							.currentThread().getId()));
		}
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		try {
			EnrollBatchJobManager queueManage = EnrollBatchJobManager
					.getInstance();
			// get Not Synchronized Enroll Batch Job List
			List<LocalEnrollBatchJob> unSynchedEnrollBatchJobs = queueManage
					.getNotSynchronizedEnrollBatchJobs();

			String segmentDeleteSyn = systemConfigDao.getSegmentDeleteSyn();
			boolean isSynDelete = SegmentDeleteSyn.DB.name().equals(
					segmentDeleteSyn);

			// synchronize Local Enroll Batch Job and delete job
			List<LocalDeletionJob> deletionJobs = DeletionJobManager
					.getInstance().getNotSynchronizedDeletionJobs();
			for (LocalEnrollBatchJob enrollBatchJob : unSynchedEnrollBatchJobs) {
				// synchronize all Younger deletion Job to DM and USC
				if (!isSynDelete) {
					synchronizeAllYoungerDeletionJobs(deletionJobs,
							enrollBatchJob);
				}

				// Synchronize SegmentPosition to USC and DM
				synchronizeUnsynchronizedBatchJob(enrollBatchJob);
			}

			// Synchronize all deletion Job to DM and USC
			if (!isSynDelete) {
				synchronizeAllDeletionJobs();
			}

		} finally {
			if (log.isInfoEnabled()) {
				log.info(InfoLogger.serialExecutionInfoOutput(
						LogConstants.COMPONENT_SEGMENT_SYNC_SERVICE_BEAN,
						LogConstants.FUNCTION_SYSNCHRONIZE_SEGMENT,
						LogConstants.DETAIL_ACTION_END, batchJobId, Thread
								.currentThread().getId()));
			}
		}

		stopWatch.stop();

		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_SEGMENT_SYNC_SERVICE_BEAN,
				LogConstants.FUNCTION_SYSNCHRONIZE_SEGMENT,
				stopWatch.getTime(), LogConstants.KEY_BATCH_JOB_ID, new Long(
						batchJobId).toString());
		printLogMessage("end public function SegmentSync()..");
		return;
	}

	/**
	 * synchronize all Younger deletion Job to DM and USC
	 * 
	 * @param enrollBatchJob
	 */
	private void synchronizeAllYoungerDeletionJobs(
			List<LocalDeletionJob> deletionJobs,
			LocalEnrollBatchJob enrollBatchJob) {
		// Synchronize Younger Deletion Job to DM and USC
		for (LocalDeletionJob deletionJob : deletionJobs) {
			if (isYoungerSegmentVersionJob(deletionJob, enrollBatchJob)) {
				if (!deletionJob.isDeleted()) {
					continue;
				}

				try {
					synchronizeDeletionJob(deletionJob);
				} finally {
					// increase the sync count due to
					// this service rerun reach to the limit
					// dlq service can delete this deletion job
					// avoid to memory leak
					deletionJob.increaseSyncCount();
				}
				deletionJob.setSynchronized(true);

				// EnrollEventBus.notifyDeleteResponse(
				// deletionJob.getBatchJobId(),
				// EnrollNotifierEnum.EnrollSegmentSyncService);

				// delete Deletion Job
				DeletionJobManager.getInstance().deleteDeletionJob(deletionJob);
			}
		}
	}

	/**
	 * Synchronize all deletion Job to DM and USC
	 */
	private void synchronizeAllDeletionJobs() {
		// Synchronize Deletion Job to DM and USC
		List<LocalDeletionJob> deletionJobs = DeletionJobManager.getInstance()
				.getNotSynchronizedDeletionJobs();
		for (LocalDeletionJob deletionJob : deletionJobs) {
			if (!deletionJob.isDeleted()) {
				continue;
			}

			try {
				synchronizeDeletionJob(deletionJob);
			} finally {
				// this place need to increase the count
				deletionJob.increaseSyncCount();
			}
			deletionJob.setSynchronized(true);

			// EnrollEventBus.notifyDeleteResponse(deletionJob.getBatchJobId(),
			// EnrollNotifierEnum.EnrollSegmentSyncService);

			// delete Deletion Job
			DeletionJobManager.getInstance().deleteDeletionJob(deletionJob);
		}
	}

	/**
	 * Synchronize Deletion Job to DM and USC
	 * 
	 * @param deletionJob
	 */
	private void synchronizeDeletionJob(LocalDeletionJob deletionJob) {
		printLogMessage("start private function synchronizeDeletionJob()..");
		// get DM Entity List
		List<MatchUnitEntity> dmList = muSegmentMapDao
				.findWorkingUnitInMuSegMapByUnitType(ComponentType.DM);

		if (dmList.size() != 0) {
			// Synchronize Deletion Job to DM
			boolean bPostToUSC = synchronizeDeletionJobToDM(deletionJob);
			if (bPostToUSC == false) {
				log.warn("No DM in the system need to synchronizing segment.");
				return;
			}
		} else {
			log.warn("No working DM in the system for synchronize segment.");
			return;
		}

		String segmentDeleteSyn = systemConfigDao.getSegmentDeleteSyn();
		boolean isSynUSC = SegmentDeleteSyn.ALL.name().equals(segmentDeleteSyn);
		if (!isSynUSC) {
			log.warn("Skip synchronize Deletion Job to USC.");
			return;
		}

		// get USC Entity List
		List<MatchUnitEntity> muList = muSegmentMapDao
				.findWorkingUnitInMuSegMapByUnitType(ComponentType.USC);
		if (muList.size() != 0) {
			// Synchronize Deletion Job to USC
			synchronizeDeletionJobToUSC(deletionJob);
		} else {
			log.warn("No working USC in the system for synchronize segment.");
		}

		printLogMessage("end private function synchronizeDeletionJob()..");
	}

	/**
	 * Synchronize Deletion Job to USC
	 * 
	 * @param deletionJob
	 */
	private void synchronizeDeletionJobToUSC(LocalDeletionJob deletionJob) {
		// prepare SegmentPosition For USC
		SegmentUpdateRequest segmentUpdateRequest = prepareSegmentPosition(deletionJob);

		List<MatchUnitEntity> uscList = findUnittoSynchronize(
				ComponentType.USC, deletionJob.getSegmentId());

		if (log.isInfoEnabled()) {
			log.info("Synchronize Deletion Job to USCs.");
		}
		synchronizeToUSCs(deletionJob.getBatchJobId(), uscList,
				segmentUpdateRequest, deletionJob.getVersion());
	}

	/**
	 * Synchronize Deletion Job to DM
	 * 
	 * @param deletionJob
	 * @return
	 */
	private boolean synchronizeDeletionJobToDM(LocalDeletionJob deletionJob) {

		// prepare SegmentPosition For DM
		SegmentUpdateRequest segmentUpdateRequest = prepareSegmentPosition(deletionJob);

		List<MatchUnitEntity> dmList = findUnittoSynchronize(ComponentType.DM,
				deletionJob.getSegmentId());

		if (log.isInfoEnabled()) {
			log.info("Synchronize Deletion Job to DMs.");
		}

		// post SegmentPosition to DM
		boolean isSegmentSynchronized = synchronizeToDMs(
				deletionJob.getBatchJobId(), dmList, segmentUpdateRequest,
				deletionJob.getVersion());

		if (isSegmentSynchronized == false && !dmList.isEmpty()) {
			String message = "Synchronize Deletion Job to DM error.";
			log.error(message);
			throw new EnrollRuntimeException(message);
		}

		return isSegmentSynchronized;
	}

	/**
	 * 
	 * @param deletionJob
	 * @param enrollBatchJob
	 * @return
	 */
	private boolean isYoungerSegmentVersionJob(LocalDeletionJob deletionJob,
			LocalEnrollBatchJob enrollBatchJob) {
		List<SegmentPosition> segmentPositions = enrollBatchJob
				.getSegmentPosition();
		for (SegmentPosition segmentPosition : segmentPositions) {
			if (deletionJob.getSegmentId() == segmentPosition.getSegmentId()
					&& deletionJob.getVersion() < segmentPosition.getVersion()) {
				return true;
			}
		}
		return false;
	}

	/**
	 * prepare SegmentPosition
	 * 
	 * @param segPos
	 * @throws IOException
	 * @throws HttpException
	 */
	private SegmentUpdateRequest prepareSegmentPosition(
			LocalDeletionJob deletionJob) {
		// create a new Segment Update Request
		SegmentUpdateRequest.Builder segUpdReq = SegmentUpdateRequest
				.newBuilder();
		// set Segment Update Request information
		segUpdReq.setSegmentId(deletionJob.getSegmentId());
		segUpdReq.setVersionFrom(deletionJob.getVersion());
		segUpdReq.setVersionTo(deletionJob.getVersion());
		segUpdReq.addDeleteIdList(deletionJob.getReferenceId());
		segUpdReq.setRecordCount(1);

		return segUpdReq.build();
	}

	/**
	 * Synchronize SegmentPosition to USC and DM
	 * 
	 * @param enrollBatchJob
	 */
	private void synchronizeUnsynchronizedBatchJob(
			LocalEnrollBatchJob enrollBatchJob) {
		enrollBatchJob.setSyncStartTS(DateUtil.getCurrentDate());

		// notify USC and DM that segments have be update.
		try {
			synchronize(enrollBatchJob);
		} catch (InterruptedException e) {
			String message = "Interrupted thread error in EnrollSegmentSyncServiceBean.";
			log.error(message);
			throw new EnrollRuntimeException(message);
		}

		// change enroll Batch Job Status and set synchronize end time
		enrollBatchJob.setBatchJobStatus(EnrollBatchJobStatus.SYNCHRONIZED);
		enrollBatchJob.setSyncEndTS(DateUtil.getCurrentDate());

		if (log.isInfoEnabled()) {
			BatchJobStatusLogger.outputBatchJobStatus(
					LogConstants.STATUS_CATEGORY_TME,
					enrollBatchJob.getBatchJobId(),
					EnrollBatchJobStatus.SYNCHRONIZED.name());
		}

		// Notify EnrollResponseServiceBean that Enroll Segment
		// synchronization.
		EnrollEventBus.notifyResponse(enrollBatchJob.getBatchJobId(),
				EnrollNotifierEnum.EnrollSegmentSyncService);
	}

	/**
	 * Synchronize SegmentPosition to USC and DM
	 * 
	 * @param slbData
	 * @param enrollBatchJob
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws HttpException
	 */
	private void synchronize(LocalEnrollBatchJob enrollBatchJob)
			throws InterruptedException {
		printLogMessage("start private function Synchronize()..");

		// get SegmentPosition List
		List<SegmentPosition> segmentPositionList = enrollBatchJob
				.getSegmentPosition();
		// get USC Entity List
		List<MatchUnitEntity> muList = muSegmentMapDao
				.findWorkingUnitInMuSegMapByUnitType(ComponentType.USC);
		// get DM Entity List
		List<MatchUnitEntity> dmList = muSegmentMapDao
				.findWorkingUnitInMuSegMapByUnitType(ComponentType.DM);

		if (segmentPositionList == null || segmentPositionList.isEmpty()) {
			log.warn("There is no SegmentPosition in batch job {}.",
					enrollBatchJob.getBatchJobId());
			return;
		}

		if (dmList.size() != 0) {
			// Synchronize SegmentPosition to DM
			boolean bPostToUSC = synchronizeSegmentPositionToDM(
					segmentPositionList, enrollBatchJob);
			if (bPostToUSC == false) {
				log.warn("No DM in the system need to synchronizing segment.");
				return;
			}
		} else {
			log.warn("No working DM in the system for synchronize segment.");
			return;
		}

		if (muList.size() != 0) {
			// Synchronize SegmentPosition to USC
			synchronizeSegmentPositionToUSC(segmentPositionList, enrollBatchJob);
		} else {
			log.warn("No working USC in the system for synchronize segment.");
		}

		printLogMessage("end private function Synchronize()..");

	}

	/***
	 * Synchronize SegmentPosition to DM
	 * 
	 * @param svdiLis
	 * @param enrollBatchJob
	 * @return
	 * @throws InterruptedException
	 */
	private boolean synchronizeSegmentPositionToDM(
			List<SegmentPosition> svdList, LocalEnrollBatchJob enrollBatchJob)
			throws InterruptedException {

		List<Boolean> allSegmentSynchronized = new ArrayList<Boolean>();

		for (int i = 0; i < svdList.size(); i++) {
			SegmentPosition segPos = svdList.get(i);
			// prepare SegmentPosition For DM
			SegmentUpdateRequest segmentUpdateRequest = prepareSegmentPosition(
					segPos, enrollBatchJob);

			List<MatchUnitEntity> dmList = findUnittoSynchronize(
					ComponentType.DM, segPos.getSegmentId());

			if (!dmList.isEmpty()) {
				// post SegmentPosition to DM
				boolean isSegmentSynchronized = synchronizeToDMs(
						enrollBatchJob.getBatchJobId(), dmList,
						segmentUpdateRequest, segPos.getVersion());

				allSegmentSynchronized.add(isSegmentSynchronized);
			}
		}

		if (log.isInfoEnabled()) {
			log.info("Synchronize Enroll Batch Job : {} to DMs.",
					enrollBatchJob.getBatchJobId());
		}

		if (allSegmentSynchronized.isEmpty()) {
			return false;
		} else if (areAllSegementSynchronized(allSegmentSynchronized) == false) {
			String message = "Synchronize SegmentPosition to DM error.";
			log.error(message);
			throw new EnrollRuntimeException(message);
		}

		return true;
	}

	/**
	 * 
	 * @param allSegmentSynchronized
	 * @return
	 */
	private boolean areAllSegementSynchronized(
			List<Boolean> allSegmentSynchronized) {
		for (Boolean isSegmentSynchronized : allSegmentSynchronized) {
			if (isSegmentSynchronized == false) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Synchronize SegmentPosition to USC
	 * 
	 * @param svdiLis
	 * @param enrollBatchJob
	 */
	private void synchronizeSegmentPositionToUSC(List<SegmentPosition> svdList,
			LocalEnrollBatchJob enrollBatchJob) {
		printLogMessage("loop to Synchronize SegmentPosition to USC");

		for (SegmentPosition segPos : svdList) {
			// prepare SegmentPosition For USC
			SegmentUpdateRequest segmentUpdateRequest = prepareSegmentPosition(
					segPos, enrollBatchJob);

			List<MatchUnitEntity> uscList = findUnittoSynchronize(
					ComponentType.USC, segPos.getSegmentId());
			synchronizeToUSCs(enrollBatchJob.getBatchJobId(), uscList,
					segmentUpdateRequest, segPos.getVersion());
		}

		if (log.isInfoEnabled()) {
			log.info("Synchronize Enroll Batch Job : {} to USCs.",
					enrollBatchJob.getBatchJobId());
		}
	}

	/**
	 * 
	 * @param type
	 * @param segmentPosition
	 * @return
	 */
	private List<MatchUnitEntity> findUnittoSynchronize(ComponentType type,
			long segmentId) {
		return muSegmentMapDao.findUnitBySegId(type, segmentId);
	}

	/**
	 * 
	 * @param dmList
	 * @param segmentPosition
	 * @return
	 */
	private boolean synchronizeToDMs(long batchJobId,
			List<MatchUnitEntity> dmList,
			SegmentUpdateRequest segmentUpdateRequest, long version) {
		boolean isSegmentSynchronized = false;
		String dmPush = systemConfigDao.getDMPushURL();
		for (MatchUnitEntity dm : dmList) {

			printLogMessage("Synchronize to DM: {}", dm.getId());

			// post SegmentPosition to DM
			int nResult = postSegmentUpdateRequest(batchJobId, dm.getURL()
					+ dmPush, segmentUpdateRequest, version);
			if (nResult == Constants.HTTP_RESPONSE_CODE_200) {
				isSegmentSynchronized = true;
			}
		}

		return isSegmentSynchronized;
	}

	/**
	 * 
	 * @param dmList
	 * @param segmentPosition
	 * @return
	 */
	private void synchronizeToUSCs(long batchJobId,
			List<MatchUnitEntity> uscList,
			SegmentUpdateRequest segmentUpdateRequest, long version) {

		for (MatchUnitEntity usc : uscList) {
			// Synchronize to USC
			printLogMessage("Synchronize to USC:{}", usc.getId());

			// post SegmentPosition to USC
			postSegmentUpdateRequest(batchJobId, usc.getURL(),
					segmentUpdateRequest, version);
		}
	}

	/**
	 * prepare SegmentPosition
	 * 
	 * @param segPos
	 * @throws IOException
	 * @throws HttpException
	 */
	private SegmentUpdateRequest prepareSegmentPosition(SegmentPosition segPos,
			LocalEnrollBatchJob enrollBatchJob) {
		// create a new Segment Update Request
		SegmentUpdateRequest.Builder segUpdReq = SegmentUpdateRequest
				.newBuilder();

		Long maxSegmentSize = systemConfigDao.getMaxSegmentSize();
		int templateSize = systemConfigDao.getTemplateSize();

		// set Segment Update Request information
		segUpdReq.setSegmentId(segPos.getSegmentId());
		segUpdReq.setMaxSegmentSize(maxSegmentSize);
		segUpdReq.setVersionFrom(segPos.getVersion());
		segUpdReq.setVersionTo(segPos.getVersion());

		// set Person Biometrics templates
		byte[] template = enrollBatchJob.getTemplateArray(
				segPos.getIndexStart(), segPos.getIndexEnd(), templateSize);
		segUpdReq.setRecordCount(template.length / templateSize);
		segUpdReq.setTemplate(ByteString.copyFrom(template));

		return segUpdReq.build();
	}

	/**
	 * post body to url
	 * 
	 * @param url
	 * @param body
	 */
	private int postSegmentUpdateRequest(long batchJobId, String url,
			SegmentUpdateRequest segmentUpdateRequest, long version) {
		if (url == null) {
			throw new IllegalArgumentException("URL can not be null.");
		}
		if (url.isEmpty()) {
			throw new IllegalArgumentException("URL can not be empty.");
		}
		if (segmentUpdateRequest == null) {
			throw new IllegalArgumentException(
					"SegmentUpdateRequest can not be null.");
		}

		int result = 0;

		SegmentUpdateRequestSender segmentUpdateRequestSender = new SegmentUpdateRequestSender();
		SegmentUpdateResponse segmentUpdateResponse = segmentUpdateRequestSender
				.sendRequest(batchJobId, url, segmentUpdateRequest);

		if (segmentUpdateResponse != null) {
			printLogMessage("Updated Segment: {} is successful.",
					segmentUpdateResponse.getSegmentId());
			result = Constants.HTTP_RESPONSE_CODE_200;
		} else {
			String message = "Synchronizing segment failed. DM/USC: " + url
					+ " failed synchronizing segment. Detail: SegmentID:"
					+ segmentUpdateRequest.getSegmentId() + " ,Version:"
					+ version + " is not responsed.";
			log.warn(message);
		}

		return result;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 *            ,logParame
	 * @return
	 */
	private void printLogMessage(String logMessage, Object... objects) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage, objects);
		}
	}
}
