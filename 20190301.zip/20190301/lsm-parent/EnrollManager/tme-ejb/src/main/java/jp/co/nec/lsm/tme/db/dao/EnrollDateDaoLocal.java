package jp.co.nec.lsm.tme.db.dao;

import java.util.Date;

import javax.ejb.Local;

@Local
public interface EnrollDateDaoLocal {
	public Date getDatabaseDate();
}
