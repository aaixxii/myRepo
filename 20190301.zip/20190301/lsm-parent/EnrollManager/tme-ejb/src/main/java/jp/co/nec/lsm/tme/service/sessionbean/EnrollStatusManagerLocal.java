package jp.co.nec.lsm.tme.service.sessionbean;

import javax.ejb.Local;

import jp.co.nec.lsm.proto.control.EnterRequestProto.EnterRequest;
import jp.co.nec.lsm.proto.control.EnterResponseProto.EnterResponse;
import jp.co.nec.lsm.proto.segment.ReportStateRequestProto.ReportStateRequest;
import jp.co.nec.lsm.tm.common.core.jobs.ReportResponseReturn;



/**
 * @author liuj
 */
@Local
public interface EnrollStatusManagerLocal {
	public EnterResponse enter(EnterRequest enterRequest);

	public void exit(long muId);

	public ReportResponseReturn reportState(ReportStateRequest reportStateRequest);
}
