package jp.co.nec.lsm.tme.service.sessionbean;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import jp.co.nec.lsm.tm.common.constants.Constants;
import jp.co.nec.lsm.tm.common.httpsender.HttpResponse;
import jp.co.nec.lsm.tm.common.log.BatchJobStatusLogger;
import jp.co.nec.lsm.tm.common.log.BatchJobTimeLogger;
import jp.co.nec.lsm.tm.common.log.LogConstants;
import jp.co.nec.lsm.tm.common.log.PerformanceLogger;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.db.enroll.entities.EnrollBatchJobStatus;
import jp.co.nec.lsm.tm.protocolbuffer.enroll.EnrollResultRequestProto.EnrollResultRequest;
import jp.co.nec.lsm.tme.core.clientapi.response.EnrollResultRequestBuilder;
import jp.co.nec.lsm.tme.core.clientapi.response.ResultRequestSender;
import jp.co.nec.lsm.tme.core.jobs.EnrollBatchJobManager;
import jp.co.nec.lsm.tme.core.jobs.LocalEnrollBatchJob;
import jp.co.nec.lsm.tme.db.dao.EnrollBatchJobQueueDaoLocal;
import jp.co.nec.lsm.tme.db.dao.EnrollSystemConfigDaoLocal;
import jp.co.nec.lsm.tme.exception.EnrollRuntimeException;
import jp.co.nec.lsm.tme.sessionbeans.api.EnrollResponseServiceLocal;

import org.apache.commons.lang.time.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author mozj <br>
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class EnrollResponseServiceBean implements EnrollResponseServiceLocal {
	@EJB
	private EnrollBatchJobQueueDaoLocal batchJobQueueDao;
	@EJB
	private EnrollSystemConfigDaoLocal systemConfigDao;

	/** log instance **/
	private static final Logger log = LoggerFactory
			.getLogger(EnrollResponseServiceBean.class);

	/**
	 * constructor
	 */
	public EnrollResponseServiceBean() {
	}

	/**
	 * response Transformer the result of batchJob, and then delete a completed
	 * batch job from local enroll queue.
	 */
	@Override
	public void doResponse(long batchJobId) {
		printLogMessage("start public function doResponse()..");

		StopWatch stopWatch = new StopWatch();
		stopWatch.start();

		// get enroll batch job
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		LocalEnrollBatchJob batchJob = queueManage
				.getEnrollBatchJobById(batchJobId);
		if (batchJob == null) {
			log.warn("Can not find the batch job(BatchJobId: {}).", batchJobId);
			return;
		}

		// check Enroll Batch Job status
		if (batchJob.isBatchJobStatus(EnrollBatchJobStatus.SYNCHRONIZED)) {
			synchronized (batchJob) {
				sendResultRequest(batchJob);
			}
		}

		if (batchJob.isBatchJobStatus(EnrollBatchJobStatus.RETURNED)) {
			// delete enroll batch Job from local queue and update status into
			// database
			deleteCompleteBatchJob(batchJob);
		} else {
			log.warn("The batch job {} is not SYNCHRONIZED or RETURNED.",
					batchJob.getBatchJobId());
		}

		stopWatch.stop();

		PerformanceLogger.performanceOutput(
				LogConstants.COMPONENT_RESPONSE_SERVICE_BEAN,
				LogConstants.FUNCTION_DORESPONSE, stopWatch.getTime(),
				LogConstants.KEY_BATCH_JOB_ID, new Long(batchJobId).toString());
		printLogMessage("end public function doResponse()..");

		return;
	}

	/**
	 * 
	 * @param batchJob
	 */
	private void sendResultRequest(LocalEnrollBatchJob batchJob) {
		// get URL from tme_properties and then response to transformer.
		String url = systemConfigDao.getPostToTransformerUrl();

		EnrollResultRequest enrollResult = EnrollResultRequestBuilder
				.createEnrollResultRequest(batchJob);

		ResultRequestSender sender = new ResultRequestSender();

		HttpResponse httpResponse = sender.sendResponse(
				enrollResult.toByteArray(), batchJob.getBatchJobId(), url);

		if (httpResponse.getHttpResponseCode() == Constants.HTTP_RESPONSE_CODE_500) {
			throw new EnrollRuntimeException(
					httpResponse.getHttpResponseErrorMessage());
		}

		batchJob.setBatchJobStatus(EnrollBatchJobStatus.RETURNED);
		batchJob.setBatchJob_end_TS(DateUtil.getCurrentDate());

		if (log.isInfoEnabled()) {
			BatchJobStatusLogger.outputBatchJobStatus(
					LogConstants.STATUS_CATEGORY_TME, batchJob.getBatchJobId(),
					EnrollBatchJobStatus.RETURNED.name());
		}

		if (batchJob.getBatchJob_end_TS() == null
				|| batchJob.getBatchJob_start_TS() == null) {
			log.warn("batchjob start time or end time for output performance log is null..");
		} else {
			double batchJobTimes = DateUtil.calcElapsed(
					batchJob.getBatchJob_start_TS(),
					batchJob.getBatchJob_end_TS());
			if (log.isInfoEnabled()) {
				BatchJobTimeLogger.outputBatchJobTimes(
						LogConstants.STATUS_CATEGORY_TME, batchJob
								.getBatchJobId(), batchJobTimes, batchJob
								.getExtractJobCount(), null, batchJob
								.getBatchJobType().name(), DateUtil
								.formatDate(batchJob.getBatchJob_start_TS()),
						DateUtil.formatDate(batchJob.getBatchJob_end_TS()));
			}
		}
	}

	/**
	 * delete a completed batch job from local enroll queue. And then change the
	 * batch job status in database
	 * 
	 * @param enrollBatchJob
	 *            batch job to deleting
	 * @return true operation success; false operation failure
	 */
	public boolean deleteCompleteBatchJob(LocalEnrollBatchJob enrollBatchJob) {
		printLogMessage("start public function DeleteCompleteBatchJob()..");

		// persist batch job information into database
		printLogMessage("change the batch job status in database.");
		batchJobQueueDao.persistBatchJobStatus(enrollBatchJob.getBatchJobId(),
				enrollBatchJob.getBatchJob_end_TS(),
				EnrollBatchJobStatus.RETURNED, null);

		// delete a completed batch job from local enroll queue
		EnrollBatchJobManager queueManage = EnrollBatchJobManager.getInstance();
		boolean result = queueManage.deleteCompleteBatchJob(enrollBatchJob);

		printLogMessage("end public function DeleteCompleteBatchJob()..");
		return result;
	}

	/**
	 * print Debug Log Message
	 * 
	 * @param logMessage
	 * @return
	 */
	private static void printLogMessage(String logMessage) {
		if (log.isDebugEnabled()) {
			log.debug(logMessage);
		}
	}
}
