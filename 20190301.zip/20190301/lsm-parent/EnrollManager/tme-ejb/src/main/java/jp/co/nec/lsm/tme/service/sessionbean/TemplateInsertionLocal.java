package jp.co.nec.lsm.tme.service.sessionbean;

import javax.ejb.Local;

/**
 * @author mozj <br>
 * 
 */
@Local
public interface TemplateInsertionLocal {
	void insertTemplates(long batchJobId);
}
