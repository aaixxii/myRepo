package jp.co.nec.lsm.tme.exception;

import jp.co.nec.lsm.tm.common.exception.TMRuntimeException;

/**
 * @author zhulk <br>
 */
public class EnrollRuntimeException extends TMRuntimeException {

	private static final long serialVersionUID = 7157356057817916135L;

	public EnrollRuntimeException(String message) {
		super(message);
	}

	public EnrollRuntimeException(String message, Throwable cause) {
		super(message, cause);
	}
}
