package jp.co.nec.lsm.tma.service.sessionbean;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.Queue;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.broker.BrokerService;
import org.apache.activemq.command.ActiveMQQueue;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jms.connection.SingleConnectionFactory;
import org.springframework.jms.listener.DefaultMessageListenerContainer;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

import jp.co.nec.lsm.event.Event;
import jp.co.nec.lsm.event.sender.AbstractEventSender;
import jp.co.nec.lsm.tm.common.constants.ConfigProperty;
import jp.co.nec.lsm.tm.common.constants.JNDIConstants;
import jp.co.nec.lsm.tm.common.constants.SystemConfigNamespace;
import jp.co.nec.lsm.tm.common.constants.TMType;
import jp.co.nec.lsm.tm.common.constants.TmState;
import jp.co.nec.lsm.tm.common.util.DateUtil;
import jp.co.nec.lsm.tm.common.util.ServiceLocator;
import jp.co.nec.lsm.tm.common.util.Version;
import jp.co.nec.lsm.tm.db.common.entities.TransactionManagerEntity;
import jp.co.nec.lsm.tm.db.common.entityhelpers.SystemConfigHelper;
import jp.co.nec.lsm.tm.db.common.entityhelpers.TransactionManagerHelper;
import junit.framework.Assert;
import mockit.Deencapsulation;
import mockit.Expectations;
import mockit.Mock;
import mockit.MockUp;
import mockit.Mocked;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Transactional
public class AggregationInitializationBeanTest {
	
	@EJB
	private AggregationInitializationBean initializationBean;
	@PersistenceContext(unitName = "tma-unit")
	private EntityManager manager;

	private Properties properties = new Properties();
	private TransactionManagerHelper tmHelper;

	protected JdbcTemplate jdbcTemplate;
	@Resource
	private DataSource dataSource;
	
	@Mocked	
	private ConnectionFactory jmsConnectionFactory;
	
	@Mocked
	private Queue queue;
	

	@Before
	public void setUp() throws Exception {

	}
	
	public void setJMSMockMethod(final String queueName) {
		new MockUp<ServiceLocator>() {
			@Mock
			private Object lookUpJndiObject(String jndiName) {
				if (jndiName.equals(JNDIConstants.CONNECTION_FACTORY)) {
					return jmsFactory;
				} else if (jndiName.equals(queueName)) {
					return queueDestination;
				}
				return null;
			}
		};
	}

	private void setMockMethodJMS() {
		new MockUp<AggregationInitializationBean>() {
			@Mock
			public void removeJmsMessage(String queueName) {
				return;
			}

			@Mock
			public void startTimer() {
				return;
			}
		};
	}
	public static void setJMSMockMethod() {
		new MockUp<AbstractEventSender>() {
			@Mock
			public void convertAndSend(Event message) {
				return;
			}
		};
	}
	
	private void setMockMethodVersion() {
		new MockUp<Version>() {
			@Mock
			public String readVersion(String warFile, String groupId,
					String artifactId) {
				return "1.0.0";
			}
		};
	}

	@PostConstruct
	public void init() {
		tmHelper = new TransactionManagerHelper(manager, TMType.TMA);
		jdbcTemplate = new JdbcTemplate(dataSource);
		try {
			InputStream is = ConfigProperty.class.getClassLoader()
					.getResourceAsStream(
							SystemConfigNamespace.TM
									.getDefaultPropertiesFilename());
			properties.load(is);
			is.close();
		} catch (IOException e) {
		}
	}

	@After
	public void tearDown() throws Exception {
	}

	private ConnectionFactory jmsFactory;
	private Queue queueDestination;
	private transient boolean isNotReceived = true;
	private int rerunLimit = 50;

	/**
	 * startServiceAndListener
	 * 
	 * @throws Exception
	 */
	private DefaultMessageListenerContainer startServiceAndListener(
			String queueName) throws Exception {
		jmsFactory = new ActiveMQConnectionFactory(
				"vm://localhost?broker.persistent=false");
		queueDestination = new ActiveMQQueue(queueName);
		final SingleConnectionFactory singleConnectionFactory1 = new SingleConnectionFactory(
				jmsFactory);

		DefaultMessageListenerContainer listener = new DefaultMessageListenerContainer();
		listener.setConnectionFactory(singleConnectionFactory1);
		listener.setDestination(queueDestination);

		listener.setMessageListener(new MessageListener() {
			public void onMessage(Message message) {
				isNotReceived = false;
			}
		});
		listener.afterPropertiesSet();
		listener.start();
		Thread.sleep(1000);
		return listener;
	}


	@Test
	public void testStartTimer() throws Exception {
		DefaultMessageListenerContainer listener = null;
		BrokerService broker = null;

		try {
			broker = new BrokerService();
			broker.setBrokerName("one");
			broker.setPersistent(false);
			broker.start();

			listener = startServiceAndListener("timer-startup-queue");
			Thread thread = new Thread(new Runnable() {
				@Override
				public void run() {
					Method method = null;
					Field fieldFactory = null;
					Field fieldQueue = null;
					try {
						AggregationInitializationBean obj = new AggregationInitializationBean();
						Class<?> clazz = obj.getClass();
						fieldFactory = clazz
								.getDeclaredField("jmsConnectionFactory");
						fieldFactory.setAccessible(true);
						fieldFactory.set(obj, jmsFactory);

						fieldQueue = clazz.getDeclaredField("queue");
						fieldQueue.setAccessible(true);
						fieldQueue.set(obj, queueDestination);

						method = obj.getClass().getDeclaredMethod("startTimer");
						method.setAccessible(true);
						method.invoke(obj);
					} catch (Exception e) {
						Assert.fail();
					} finally {
						if (fieldFactory != null) {
							fieldFactory.setAccessible(false);
						}

						if (fieldQueue != null) {
							fieldQueue.setAccessible(false);
						}

						if (method != null) {
							method.setAccessible(false);
						}
					}
				}
			});
			thread.start();
			thread.join();

			assertResult();

		} finally {
			if (listener != null) {
				listener.stop();
				listener.destroy();
			}

			if (broker != null) {
				broker.stop();
			}
		}
	}

	/**
	 * asserts
	 */
	private void assertResult() {
		int run = 0;
		while (isNotReceived && run++ <= rerunLimit) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		if (run > rerunLimit) {
			Assert.fail();
		}
	}

	@Test
	public void testRemoveJmsMessageError() {
		Method method = null;
		try {
			AggregationInitializationBean obj = new AggregationInitializationBean();
			method = obj.getClass().getDeclaredMethod("removeJmsMessage",
					String.class);

			method.setAccessible(true);
			method.invoke(obj, "");
		} catch (Exception e) {
		} finally {
			if (method != null) {
				method.setAccessible(false);
			}
		}
	}


	@Test
	public void testInitialization() throws JMSException {
		setMockMethodJMS();
		//setMockMethodVersion();
		setJMSMockMethod();
		jdbcTemplate.execute("delete from SYSTEM_CONFIG");
		
		 Deencapsulation.setField(initializationBean, jmsConnectionFactory);	
	
	        new Expectations() {
	            {               
	            	jmsConnectionFactory.createConnection(); 
	            		result = new  ActiveMQConnectionFactory("vm://localhost?broker.persistent=false");
	            		                              
	            }
	        };         
	       
	        queue = new ActiveMQQueue(JNDIConstants.AGGREGATION_STARTTIMER_QUEUE);

	        Deencapsulation.setField(initializationBean, queue);	
	
	    


		initializationBean.initializeAggregation();

		SystemConfigHelper helper = new SystemConfigHelper(manager);
		Set<Entry<Object, Object>> entrySet = properties.entrySet();
		for (Entry<Object, Object> e : entrySet) {
			String key = (String) e.getKey();
			String value = properties.getProperty(key);
			assertEquals(helper.getTMProperty(key), value);
		}

		TransactionManagerEntity tm = tmHelper.createOrLookup(DateUtil
				.getCurrentDate());

		// 2 - assert concerning information
		assertNotNull(tm);
		assertNotNull(tm.getLastHeartbeatTs());
		assertNotNull(tm.getLastPollTs());
		assertEquals(TmState.WORKING, tm.getState());
	}

}
