package jp.co.nec.lsm.tma.db.dao;

import java.util.List;

import javax.ejb.Local;

import jp.co.nec.lsm.tm.db.identify.entities.IdentifyBatchJobDBStatus;
import jp.co.nec.lsm.tm.db.identify.entities.IdentifyBatchJobQueueEntity;

/**
 * @author dongqk <br>
 */
@Local
public interface AggregationBatchJobDaoLocal {

	public List<IdentifyBatchJobQueueEntity> getAllRunningBatchJobs(
			IdentifyBatchJobDBStatus status);
}
