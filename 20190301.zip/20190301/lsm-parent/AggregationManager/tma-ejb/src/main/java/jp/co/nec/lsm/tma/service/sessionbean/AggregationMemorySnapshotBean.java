package jp.co.nec.lsm.tma.service.sessionbean;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;

import jp.co.nec.lsm.tm.common.communication.BatchSegmentJobMap;
import jp.co.nec.lsm.tm.protocolbuffer.identify.IdentifyResultRequestProto.IdentifyResultRequest;
import jp.co.nec.lsm.tma.core.jobs.BatchSegmentJobManager;
import jp.co.nec.lsm.tma.core.jobs.IdentifyResponseQueue;
import jp.co.nec.lsm.tma.sessionbean.api.AggregationMemorySnapshotRemote;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author liuyq <br>
 *         AggregationMemorySnapshot <br>
 *         this class is the interface of TMA memory job snapshot <br>
 *         TMI can communicate with this interface in order to output the whole
 *         memory job status completely
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class AggregationMemorySnapshotBean implements
		AggregationMemorySnapshotRemote {

	/** log instance **/
	private static Logger log = LoggerFactory
			.getLogger(AggregationMemorySnapshotBean.class);

	private BatchSegmentJobManager jobManager = BatchSegmentJobManager
			.getInstance();

	/**
	 * return the TMA whole memory job snapshot
	 */
	@Override
	public Map<Long, BatchSegmentJobMap> getBatchSegmentJobMap(Long batchJobId) {
		if (log.isInfoEnabled()) {
			log.info("Get the aggregation memory job snapshot from identify "
					+ "with batch job id: {}", batchJobId);
		}

		Map<Long, BatchSegmentJobMap> allMap = jobManager
				.getBatchSegmentJobMaps();

		// if the batch job user request is null. return all job memory
		if (batchJobId == null) {
			return allMap;
		}

		Map<Long, BatchSegmentJobMap> retMap = new ConcurrentHashMap<Long, BatchSegmentJobMap>();
		// the batch job user request is error. return empty job memory
		if (batchJobId <= 0L) {
			return retMap;
		}

		// the batch job user request is not in aggregation memory
		// return empty job memory
		if (allMap.get(batchJobId) == null) {
			return retMap;
		}

		// the batch job user request is correct and in aggregation memory
		// return only this BatchSegmentJobMap to tMI
		retMap.put(batchJobId, allMap.get(batchJobId));
		return retMap;
	}

	/**
	 * return the TMA whole memory job snapshot
	 */
	@Override
	public Map<Long, IdentifyResultRequest> getIdentifyResultRequest() {
		if (log.isInfoEnabled()) {
			log.info("Get the aggregation memory job IdentifyResultRequest snapshot from identify..");
		}

		return IdentifyResponseQueue.getInstance().getResponseMap();
	}
}
