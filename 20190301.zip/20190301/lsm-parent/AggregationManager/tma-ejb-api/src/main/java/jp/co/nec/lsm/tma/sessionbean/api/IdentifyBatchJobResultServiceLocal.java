package jp.co.nec.lsm.tma.sessionbean.api;

import javax.ejb.Local;

/**
 * @author dongqk <br>
 * the Batch had been done
 * 1. Find in IdentifyResultMap has disposed of BatchJob, stored in IdentifyResponse.
 * 2. the BatchSegmentJobMap treated by AggregationService has been sent to TMI through by JMS.
 * 3. remove BatchSegmetnJobMap from MemoryQueue that which BatchJob had operated done.
 * remove IdentifyResultInner from MemoryQueue that which BatchJob had operated done.
 * 
 */
@Local
public interface IdentifyBatchJobResultServiceLocal {

	/**
	 * the Batch had been done
	 * 1. Find in IdentifyResultMap has disposed of BatchJob, stored in IdentifyResponse.
	 * 2. the BatchSegmentJobMap treated by AggregationService has been sent to TMI through by JMS.
	 * 3. remove BatchSegmetnJobMap from MemoryQueue that which BatchJob had operated done.
	 * remove IdentifyResultInner from MemoryQueue that which BatchJob had operated done.
	 * 
	 * @param batchJobId
	 *            which has been operated done
	 */
	public void notifyBatchJobDone(long batchJobId);

}
