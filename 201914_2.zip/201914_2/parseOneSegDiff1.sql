CREATE DEFINER=`aimuser`@`%` PROCEDURE `parseOneSegDiff`(
	IN one_seg_diff VARCHAR(256),
  -- IN  table_name VARCHAR(20),
	OUT err int
)
BEGIN
-- oneSegDiff={segmentId:1000;reportVersion:1;lastVersion:5}
	DECLARE i int DEFAULT 1;
	DECLARE v_idx int DEFAULT 0;
	DECLARE seg_diff varchar(32);
	DECLARE v_tmp  varchar(256);
	DECLARE str_segment  varchar(32);
	DECLARE v_segmentId   int(38);
	DECLARE str_reportVersion varchar(32);
	DECLARE v_reportVersion  int(38);
	DECLARE str_latestVersion varchar(32);
	DECLARE v_latestVersion  int(38);
	DECLARE t_error integer DEFAULT 0;
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;  
    DROP TEMPORARY TABLE IF EXISTS segment_diffs;
   CREATE TEMPORARY TABLE segment_diffs (
      segmentId int(38),
      reportVersion int(38),
      latestVersion int(38)
     ) ENGINE = MEMORY;

	SET str_segment =  SUBSTRING_INDEX(one_seg_diff,';',1);
	SET v_idx = INSTR(str_segment,':');
	SET v_segmentId = substr(str_segment,v_idx +1 ,LENGTH(str_segment));   
	SET str_reportVersion =  SUBSTRING_INDEX(one_seg_diff,';',2);
	SET  v_idx = INSTR(str_reportVersion, ';');
	SET str_reportVersion = SUBSTR(str_reportVersion, v_idx + 1, LENGTH(str_reportVersion));
	SET v_idx = INSTR(str_reportVersion,':');
	SET v_reportVersion = substr(str_reportVersion,v_idx +1 ,LENGTH(str_reportVersion));  
	SET str_latestVersion =  SUBSTRING_INDEX(one_seg_diff,';',-1);
	SET v_idx = INSTR(str_latestVersion,':');    
	SET v_latestVersion = substr(str_latestVersion,v_idx +1 ,LENGTH(str_latestVersion));  
	INSERT INTO segment_diffs VALUES(v_segmentId,v_reportVersion,v_latestVersion);
	SET @mySql = CONCAT('INSERT INTO ', table_name, ' VALUES(', v_segmentId,',', v_reportVersion,',', v_latestVersion,');'); 
	PREPARE stmt1 FROM @mySql;
	EXECUTE stmt1;
	DEALLOCATE PREPARE stmt1;  
    IF t_error=1 then
      SET err = 1;
      ROLLBACK;
	ELSE
      SET err = 0;
      COMMIT;
	END IF;
END