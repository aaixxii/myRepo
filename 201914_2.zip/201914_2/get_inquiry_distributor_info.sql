CREATE DEFINER=`aimuser`@`%` PROCEDURE `get_inquiry_distributor_info`(
 in p_job_id  int,
  in p_function_id int,
  in p_plan_id int
  )
    READS SQL DATA
    SQL SECURITY INVOKER
BEGIN    
    DECLARE t_error INTEGER DEFAULT 0;  
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error=1;  
    
 SELECT jq.FAILURE_COUNT,
       fj.SEARCH_REQUEST_INDEX,
       fj.INQUIRY_JOB_DATA,
       ft.CONTAINER_JOB_TIMEOUTS,
       greatest(jq.MAX_CANDIDATES, nvl(ft.INTERNAL_CANDIDATE_SIZE, 0)) AS
       internal_candidate_size,
       cj.CONTAINER_JOB_ID
FROM   JOB_QUEUE jq,
       FUSION_JOBS fj,
       FUNCTION_TYPES ft,
       CONTAINER_JOBS cj
WHERE  jq.JOB_ID = fj.JOB_ID
       AND fj.FUNCTION_ID = ft.FUNCTION_ID
       AND fj.FUSION_JOB_ID = cj.FUSION_JOB_ID
       AND jq.JOB_ID = p_job_id
       AND fj.FUNCTION_ID = p_function_id
       AND cj.PLAN_ID = p_plan_id; 
END