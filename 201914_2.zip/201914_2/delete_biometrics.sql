CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_biometrics`(
IN p_external_id varchar(20),
IN p_event_id int,
IN p_container_ids varchar(1024),
OUT r_deleted_record_count int)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
begin_lab:
  BEGIN
    DECLARE l_person_id bigint(38);
    DECLARE l_new_binary_len_comp int(16);
    DECLARE l_new_rec_count bigint(38);
    DECLARE l_new_version bigint(38);
    DECLARE l_new_revision bigint(38);
    DECLARE tmp_biometrics_id bigint(38);
    DECLARE tmp_container_id int(8);
    DECLARE tmp_biometric_data_len int(16);
    DECLARE l_deleted_record_count int DEFAULT 0;
    DECLARE l_count int DEFAULT 0;
    DECLARE tp_segment_id bigint(38);
    DECLARE tp_record_count bigint(38);
    DECLARE tp_binary_length_compacted int(16);
    DECLARE tp_version bigint(38);
    DECLARE tp_revision bigint(38);
    DECLARE del_count int(11) DEFAULT 0;
    DECLARE v_result int;
    DECLARE not_found int DEFAULT 0;
    DECLARE t_error integer DEFAULT 0;
    DECLARE v_idx int DEFAULT 999;
    DECLARE v_tmp_str varchar(64);
    DECLARE v_id int;
    DECLARE cur CURSOR FOR
    SELECT
      *
    FROM tmp_person_biometrics;
    DECLARE both_event_container_cur CURSOR FOR
    SELECT
      biometrics_id,
      container_id,
      biometric_data_len
    FROM person_biometrics
    WHERE external_id = p_external_id
    AND event_id = p_event_id
    AND container_id IN (SELECT
        id
      FROM tmp_container_ids)
    ORDER BY container_id, biometrics_id;
    DECLARE event_only_cur CURSOR FOR
    SELECT
      biometrics_id,
      container_id,
      biometric_data_len
    FROM person_biometrics
    WHERE external_id = p_external_id
    AND event_id = p_event_id
    ORDER BY container_id, biometrics_id;
    DECLARE container_only_cur CURSOR FOR
    SELECT
      biometrics_id,
      container_id,
      biometric_data_len
    FROM person_biometrics
    WHERE external_id = p_external_id
    AND container_id IN (SELECT
        id
      FROM tmp_container_ids)
    ORDER BY container_id, biometrics_id;
    DECLARE event_container_null_cur CURSOR FOR
    SELECT
      *
    FROM person_biometrics
    WHERE external_id = p_external_id
    ORDER BY container_id, biometrics_id;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET not_found = 1;
    SET @@autocommit = 0;
    DROP TEMPORARY TABLE IF EXISTS tmp_person_biometrics;
    CREATE TEMPORARY TABLE tmp_person_biometrics (
      BIOMETRICS_ID bigint(38),
      CONTAINER_ID int(8),
      BIOMETRIC_DATA_LEN int(16)
    );
    CALL strToTable(p_container_ids, "tmp_container_ids", @err);
    SELECT
      @err INTO v_result;
    IF v_result != 0 THEN
      SET r_deleted_record_count = 0;
      LEAVE begin_lab;
    END IF;
    IF (p_event_id IS NOT NULL)
      AND (p_container_ids IS NOT NULL) THEN
      OPEN both_event_container_cur;
    both_event_container_cur_lab:
      LOOP
        FETCH both_event_container_cur INTO tmp_biometrics_id, tmp_container_id, tmp_biometric_data_len;
        IF not_found = 1 THEN
          LEAVE both_event_container_cur_lab;
        END IF;
        INSERT INTO tmp_person_biometrics
          VALUES (tmp_biometrics_id, tmp_container_id, tmp_biometric_data_len);
      END LOOP;
      CLOSE both_event_container_cur;
    ELSEIF (p_event_id IS NOT NULL)
      AND (p_container_ids IS NULL) THEN
      OPEN event_only_cur;
    event_only_cur_lab:
      LOOP
        FETCH event_only_cur INTO tmp_biometrics_id, tmp_container_id, tmp_biometric_data_len;
        IF not_found = 1 THEN
          LEAVE event_only_cur_lab;
        END IF;
        INSERT INTO tmp_person_biometrics
          VALUES (tmp_biometrics_id, tmp_container_id, tmp_biometric_data_len);
      END LOOP;
      CLOSE event_only_cur;
    ELSEIF (p_event_id IS NULL)
      AND (p_container_ids IS NOT NULL) THEN
      OPEN container_only_cur;
    container_only_cur_lab:
      LOOP
        FETCH container_only_cur INTO tmp_biometrics_id, tmp_container_id, tmp_biometric_data_len;
        IF not_found = 1 THEN
          LEAVE container_only_cur_lab;
        END IF;
        INSERT INTO tmp_person_biometrics
          VALUES (tmp_biometrics_id, tmp_container_id, tmp_biometric_data_len);
      END LOOP;
      CLOSE container_only_cur;
    ELSEIF (p_event_id IS NULL)
      AND (p_container_ids IS NULL) THEN
      OPEN event_container_null_cur;
    event_container_null_cur_lab:
      LOOP
        FETCH event_container_null_cur INTO tmp_biometrics_id, tmp_container_id, tmp_biometric_data_len;
        IF not_found = 1 THEN
          LEAVE event_container_null_cur_lab;
        END IF;
        INSERT INTO tmp_person_biometrics
          VALUES (tmp_biometrics_id, tmp_container_id, tmp_biometric_data_len);
      END LOOP;
      CLOSE container_only_cur;
    END IF;
    IF t_error <=> 1 THEN
      SET r_deleted_record_count = 0;
      LEAVE begin_lab;
    END IF;

    SET not_found = 0;
    OPEN cur;
  lable_loop:
    LOOP
      FETCH cur INTO tmp_biometrics_id, tmp_container_id, tmp_biometric_data_len;
      IF not_found = 1 THEN
        LEAVE lable_loop;
      END IF;
      SET del_count = update_seg_for_del(tmp_biometrics_id, tmp_container_id, tmp_biometric_data_len);
      IF del_count <=> 1 THEN
        SET r_deleted_record_count = r_deleted_record_count + 1;
      ELSE
        SET t_error = 1;
      END IF;
    END LOOP;
    CLOSE cur;
    IF t_error = 1 THEN
      ROLLBACK;
      SET r_deleted_record_count = -1;
    ELSE
      COMMIT;
    END IF;
  END