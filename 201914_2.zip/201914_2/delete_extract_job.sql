CREATE DEFINER=`aimuser`@`%` PROCEDURE `delete_extract_job`(
OUT del_count int)
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
  DECLARE t_error integer DEFAULT 0;
  DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET t_error = 1;
  DELETE
    FROM FE_JOB_QUEUE
  WHERE JOB_ID = p_extract_job_id;
  SELECT
    ROW_COUNT() INTO del_count;
  IF t_error = 1 THEN
    ROLLBACK;
    SET del_count = -1;
  ELSE
    COMMIT;
  END IF;
END