package jp.co.alsok.g6.db.entity.com;

import java.io.Serializable;
import java.util.Date;

public class KAcntUserLoginSts implements Serializable {
    /**
     * LN_利用者アカウント共通論理番号
     */
    private String LN_ACNT_USER_COMMON;

    /**
     * 最終ログイン日時
     */
    private Date LAST_LOGIN_TS;

    /**
     * 最終ログアウト日時
     */
    private Date LAST_LOGOUT_TS;

    /**
     * ログイン状態フラグ
     */
    private String FLG_LOGIN_STS;

    /**
     * ログイン失敗回数
     */
    private String CNT_LOGIN_ERR;

    /**
     * 選択言語種別
     */
    private String SELECT_LANG;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * K_ACNT_USER_LOGIN_STS
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_利用者アカウント共通論理番号
     * @return LN_ACNT_USER_COMMON LN_利用者アカウント共通論理番号
     */
    public String getLN_ACNT_USER_COMMON() {
        return LN_ACNT_USER_COMMON;
    }

    /**
     * LN_利用者アカウント共通論理番号
     * @param LN_ACNT_USER_COMMON LN_利用者アカウント共通論理番号
     */
    public void setLN_ACNT_USER_COMMON(String LN_ACNT_USER_COMMON) {
        this.LN_ACNT_USER_COMMON = LN_ACNT_USER_COMMON == null ? null : LN_ACNT_USER_COMMON.trim();
    }

    /**
     * 最終ログイン日時
     * @return LAST_LOGIN_TS 最終ログイン日時
     */
    public Date getLAST_LOGIN_TS() {
        return LAST_LOGIN_TS;
    }

    /**
     * 最終ログイン日時
     * @param LAST_LOGIN_TS 最終ログイン日時
     */
    public void setLAST_LOGIN_TS(Date LAST_LOGIN_TS) {
        this.LAST_LOGIN_TS = LAST_LOGIN_TS;
    }

    /**
     * 最終ログアウト日時
     * @return LAST_LOGOUT_TS 最終ログアウト日時
     */
    public Date getLAST_LOGOUT_TS() {
        return LAST_LOGOUT_TS;
    }

    /**
     * 最終ログアウト日時
     * @param LAST_LOGOUT_TS 最終ログアウト日時
     */
    public void setLAST_LOGOUT_TS(Date LAST_LOGOUT_TS) {
        this.LAST_LOGOUT_TS = LAST_LOGOUT_TS;
    }

    /**
     * ログイン状態フラグ
     * @return FLG_LOGIN_STS ログイン状態フラグ
     */
    public String getFLG_LOGIN_STS() {
        return FLG_LOGIN_STS;
    }

    /**
     * ログイン状態フラグ
     * @param FLG_LOGIN_STS ログイン状態フラグ
     */
    public void setFLG_LOGIN_STS(String FLG_LOGIN_STS) {
        this.FLG_LOGIN_STS = FLG_LOGIN_STS == null ? null : FLG_LOGIN_STS.trim();
    }

    /**
     * ログイン失敗回数
     * @return CNT_LOGIN_ERR ログイン失敗回数
     */
    public String getCNT_LOGIN_ERR() {
        return CNT_LOGIN_ERR;
    }

    /**
     * ログイン失敗回数
     * @param CNT_LOGIN_ERR ログイン失敗回数
     */
    public void setCNT_LOGIN_ERR(String CNT_LOGIN_ERR) {
        this.CNT_LOGIN_ERR = CNT_LOGIN_ERR == null ? null : CNT_LOGIN_ERR.trim();
    }

    /**
     * 選択言語種別
     * @return SELECT_LANG 選択言語種別
     */
    public String getSELECT_LANG() {
        return SELECT_LANG;
    }

    /**
     * 選択言語種別
     * @param SELECT_LANG 選択言語種別
     */
    public void setSELECT_LANG(String SELECT_LANG) {
        this.SELECT_LANG = SELECT_LANG == null ? null : SELECT_LANG.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}