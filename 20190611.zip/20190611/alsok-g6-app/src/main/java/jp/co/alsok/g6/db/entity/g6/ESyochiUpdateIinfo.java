package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class ESyochiUpdateIinfo implements Serializable {
    /**
     * GC番号
     */
    private String GC_NUM;

    /**
     * LN_SGS論理番号
     */
    private String LN_SGS;

    /**
     * 事案発生日付
     */
    private String JIAN_HASSEI_TS;

    /**
     * 結果欄
     */
    private String KEKKA;

    /**
     * 表示色
     */
    private String COLOR_FLG_K;

    /**
     * 最終更新日時
     */
    private Date LASTUPD_TS;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * E_SYOCHI_UPDATE_IINFO
     */
    private static final long serialVersionUID = 1L;

    /**
     * GC番号
     * @return GC_NUM GC番号
     */
    public String getGC_NUM() {
        return GC_NUM;
    }

    /**
     * GC番号
     * @param GC_NUM GC番号
     */
    public void setGC_NUM(String GC_NUM) {
        this.GC_NUM = GC_NUM == null ? null : GC_NUM.trim();
    }

    /**
     * LN_SGS論理番号
     * @return LN_SGS LN_SGS論理番号
     */
    public String getLN_SGS() {
        return LN_SGS;
    }

    /**
     * LN_SGS論理番号
     * @param LN_SGS LN_SGS論理番号
     */
    public void setLN_SGS(String LN_SGS) {
        this.LN_SGS = LN_SGS == null ? null : LN_SGS.trim();
    }

    /**
     * 事案発生日付
     * @return JIAN_HASSEI_TS 事案発生日付
     */
    public String getJIAN_HASSEI_TS() {
        return JIAN_HASSEI_TS;
    }

    /**
     * 事案発生日付
     * @param JIAN_HASSEI_TS 事案発生日付
     */
    public void setJIAN_HASSEI_TS(String JIAN_HASSEI_TS) {
        this.JIAN_HASSEI_TS = JIAN_HASSEI_TS == null ? null : JIAN_HASSEI_TS.trim();
    }

    /**
     * 結果欄
     * @return KEKKA 結果欄
     */
    public String getKEKKA() {
        return KEKKA;
    }

    /**
     * 結果欄
     * @param KEKKA 結果欄
     */
    public void setKEKKA(String KEKKA) {
        this.KEKKA = KEKKA == null ? null : KEKKA.trim();
    }

    /**
     * 表示色
     * @return COLOR_FLG_K 表示色
     */
    public String getCOLOR_FLG_K() {
        return COLOR_FLG_K;
    }

    /**
     * 表示色
     * @param COLOR_FLG_K 表示色
     */
    public void setCOLOR_FLG_K(String COLOR_FLG_K) {
        this.COLOR_FLG_K = COLOR_FLG_K == null ? null : COLOR_FLG_K.trim();
    }

    /**
     * 最終更新日時
     * @return LASTUPD_TS 最終更新日時
     */
    public Date getLASTUPD_TS() {
        return LASTUPD_TS;
    }

    /**
     * 最終更新日時
     * @param LASTUPD_TS 最終更新日時
     */
    public void setLASTUPD_TS(Date LASTUPD_TS) {
        this.LASTUPD_TS = LASTUPD_TS;
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}