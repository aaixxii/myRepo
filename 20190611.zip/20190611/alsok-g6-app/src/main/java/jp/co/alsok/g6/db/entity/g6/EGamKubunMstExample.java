package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EGamKubunMstExample {
    /**
     * E_GAM_KUBUN_MST
     */
    protected String orderByClause;

    /**
     * E_GAM_KUBUN_MST
     */
    protected boolean distinct;

    /**
     * E_GAM_KUBUN_MST
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public EGamKubunMstExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * E_GAM_KUBUN_MST null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andID_GAM_KBNIsNull() {
            addCriterion("ID_GAM_KBN is null");
            return (Criteria) this;
        }

        public Criteria andID_GAM_KBNIsNotNull() {
            addCriterion("ID_GAM_KBN is not null");
            return (Criteria) this;
        }

        public Criteria andID_GAM_KBNEqualTo(String value) {
            addCriterion("ID_GAM_KBN =", value, "ID_GAM_KBN");
            return (Criteria) this;
        }

        public Criteria andID_GAM_KBNNotEqualTo(String value) {
            addCriterion("ID_GAM_KBN <>", value, "ID_GAM_KBN");
            return (Criteria) this;
        }

        public Criteria andID_GAM_KBNGreaterThan(String value) {
            addCriterion("ID_GAM_KBN >", value, "ID_GAM_KBN");
            return (Criteria) this;
        }

        public Criteria andID_GAM_KBNGreaterThanOrEqualTo(String value) {
            addCriterion("ID_GAM_KBN >=", value, "ID_GAM_KBN");
            return (Criteria) this;
        }

        public Criteria andID_GAM_KBNLessThan(String value) {
            addCriterion("ID_GAM_KBN <", value, "ID_GAM_KBN");
            return (Criteria) this;
        }

        public Criteria andID_GAM_KBNLessThanOrEqualTo(String value) {
            addCriterion("ID_GAM_KBN <=", value, "ID_GAM_KBN");
            return (Criteria) this;
        }

        public Criteria andID_GAM_KBNLike(String value) {
            addCriterion("ID_GAM_KBN like", value, "ID_GAM_KBN");
            return (Criteria) this;
        }

        public Criteria andID_GAM_KBNNotLike(String value) {
            addCriterion("ID_GAM_KBN not like", value, "ID_GAM_KBN");
            return (Criteria) this;
        }

        public Criteria andID_GAM_KBNIn(List<String> values) {
            addCriterion("ID_GAM_KBN in", values, "ID_GAM_KBN");
            return (Criteria) this;
        }

        public Criteria andID_GAM_KBNNotIn(List<String> values) {
            addCriterion("ID_GAM_KBN not in", values, "ID_GAM_KBN");
            return (Criteria) this;
        }

        public Criteria andID_GAM_KBNBetween(String value1, String value2) {
            addCriterion("ID_GAM_KBN between", value1, value2, "ID_GAM_KBN");
            return (Criteria) this;
        }

        public Criteria andID_GAM_KBNNotBetween(String value1, String value2) {
            addCriterion("ID_GAM_KBN not between", value1, value2, "ID_GAM_KBN");
            return (Criteria) this;
        }

        public Criteria andKINDIsNull() {
            addCriterion("KIND is null");
            return (Criteria) this;
        }

        public Criteria andKINDIsNotNull() {
            addCriterion("KIND is not null");
            return (Criteria) this;
        }

        public Criteria andKINDEqualTo(String value) {
            addCriterion("KIND =", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDNotEqualTo(String value) {
            addCriterion("KIND <>", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDGreaterThan(String value) {
            addCriterion("KIND >", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDGreaterThanOrEqualTo(String value) {
            addCriterion("KIND >=", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDLessThan(String value) {
            addCriterion("KIND <", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDLessThanOrEqualTo(String value) {
            addCriterion("KIND <=", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDLike(String value) {
            addCriterion("KIND like", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDNotLike(String value) {
            addCriterion("KIND not like", value, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDIn(List<String> values) {
            addCriterion("KIND in", values, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDNotIn(List<String> values) {
            addCriterion("KIND not in", values, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDBetween(String value1, String value2) {
            addCriterion("KIND between", value1, value2, "KIND");
            return (Criteria) this;
        }

        public Criteria andKINDNotBetween(String value1, String value2) {
            addCriterion("KIND not between", value1, value2, "KIND");
            return (Criteria) this;
        }

        public Criteria andNMIsNull() {
            addCriterion("NM is null");
            return (Criteria) this;
        }

        public Criteria andNMIsNotNull() {
            addCriterion("NM is not null");
            return (Criteria) this;
        }

        public Criteria andNMEqualTo(String value) {
            addCriterion("NM =", value, "NM");
            return (Criteria) this;
        }

        public Criteria andNMNotEqualTo(String value) {
            addCriterion("NM <>", value, "NM");
            return (Criteria) this;
        }

        public Criteria andNMGreaterThan(String value) {
            addCriterion("NM >", value, "NM");
            return (Criteria) this;
        }

        public Criteria andNMGreaterThanOrEqualTo(String value) {
            addCriterion("NM >=", value, "NM");
            return (Criteria) this;
        }

        public Criteria andNMLessThan(String value) {
            addCriterion("NM <", value, "NM");
            return (Criteria) this;
        }

        public Criteria andNMLessThanOrEqualTo(String value) {
            addCriterion("NM <=", value, "NM");
            return (Criteria) this;
        }

        public Criteria andNMLike(String value) {
            addCriterion("NM like", value, "NM");
            return (Criteria) this;
        }

        public Criteria andNMNotLike(String value) {
            addCriterion("NM not like", value, "NM");
            return (Criteria) this;
        }

        public Criteria andNMIn(List<String> values) {
            addCriterion("NM in", values, "NM");
            return (Criteria) this;
        }

        public Criteria andNMNotIn(List<String> values) {
            addCriterion("NM not in", values, "NM");
            return (Criteria) this;
        }

        public Criteria andNMBetween(String value1, String value2) {
            addCriterion("NM between", value1, value2, "NM");
            return (Criteria) this;
        }

        public Criteria andNMNotBetween(String value1, String value2) {
            addCriterion("NM not between", value1, value2, "NM");
            return (Criteria) this;
        }

        public Criteria andLN_SIGSUBFIsNull() {
            addCriterion("LN_SIGSUBF is null");
            return (Criteria) this;
        }

        public Criteria andLN_SIGSUBFIsNotNull() {
            addCriterion("LN_SIGSUBF is not null");
            return (Criteria) this;
        }

        public Criteria andLN_SIGSUBFEqualTo(String value) {
            addCriterion("LN_SIGSUBF =", value, "LN_SIGSUBF");
            return (Criteria) this;
        }

        public Criteria andLN_SIGSUBFNotEqualTo(String value) {
            addCriterion("LN_SIGSUBF <>", value, "LN_SIGSUBF");
            return (Criteria) this;
        }

        public Criteria andLN_SIGSUBFGreaterThan(String value) {
            addCriterion("LN_SIGSUBF >", value, "LN_SIGSUBF");
            return (Criteria) this;
        }

        public Criteria andLN_SIGSUBFGreaterThanOrEqualTo(String value) {
            addCriterion("LN_SIGSUBF >=", value, "LN_SIGSUBF");
            return (Criteria) this;
        }

        public Criteria andLN_SIGSUBFLessThan(String value) {
            addCriterion("LN_SIGSUBF <", value, "LN_SIGSUBF");
            return (Criteria) this;
        }

        public Criteria andLN_SIGSUBFLessThanOrEqualTo(String value) {
            addCriterion("LN_SIGSUBF <=", value, "LN_SIGSUBF");
            return (Criteria) this;
        }

        public Criteria andLN_SIGSUBFLike(String value) {
            addCriterion("LN_SIGSUBF like", value, "LN_SIGSUBF");
            return (Criteria) this;
        }

        public Criteria andLN_SIGSUBFNotLike(String value) {
            addCriterion("LN_SIGSUBF not like", value, "LN_SIGSUBF");
            return (Criteria) this;
        }

        public Criteria andLN_SIGSUBFIn(List<String> values) {
            addCriterion("LN_SIGSUBF in", values, "LN_SIGSUBF");
            return (Criteria) this;
        }

        public Criteria andLN_SIGSUBFNotIn(List<String> values) {
            addCriterion("LN_SIGSUBF not in", values, "LN_SIGSUBF");
            return (Criteria) this;
        }

        public Criteria andLN_SIGSUBFBetween(String value1, String value2) {
            addCriterion("LN_SIGSUBF between", value1, value2, "LN_SIGSUBF");
            return (Criteria) this;
        }

        public Criteria andLN_SIGSUBFNotBetween(String value1, String value2) {
            addCriterion("LN_SIGSUBF not between", value1, value2, "LN_SIGSUBF");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andID_GAM_KBNLikeInsensitive(String value) {
            addCriterion("upper(ID_GAM_KBN) like", value.toUpperCase(), "ID_GAM_KBN");
            return (Criteria) this;
        }

        public Criteria andKINDLikeInsensitive(String value) {
            addCriterion("upper(KIND) like", value.toUpperCase(), "KIND");
            return (Criteria) this;
        }

        public Criteria andNMLikeInsensitive(String value) {
            addCriterion("upper(NM) like", value.toUpperCase(), "NM");
            return (Criteria) this;
        }

        public Criteria andLN_SIGSUBFLikeInsensitive(String value) {
            addCriterion("upper(LN_SIGSUBF) like", value.toUpperCase(), "LN_SIGSUBF");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * E_GAM_KUBUN_MST
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * E_GAM_KUBUN_MST null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}