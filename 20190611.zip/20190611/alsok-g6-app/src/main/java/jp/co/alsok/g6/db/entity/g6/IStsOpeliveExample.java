package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class IStsOpeliveExample {
    /**
     * I_STS_OPELIVE
     */
    protected String orderByClause;

    /**
     * I_STS_OPELIVE
     */
    protected boolean distinct;

    /**
     * I_STS_OPELIVE
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public IStsOpeliveExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * I_STS_OPELIVE null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLN_OPELIVEIsNull() {
            addCriterion("LN_OPELIVE is null");
            return (Criteria) this;
        }

        public Criteria andLN_OPELIVEIsNotNull() {
            addCriterion("LN_OPELIVE is not null");
            return (Criteria) this;
        }

        public Criteria andLN_OPELIVEEqualTo(String value) {
            addCriterion("LN_OPELIVE =", value, "LN_OPELIVE");
            return (Criteria) this;
        }

        public Criteria andLN_OPELIVENotEqualTo(String value) {
            addCriterion("LN_OPELIVE <>", value, "LN_OPELIVE");
            return (Criteria) this;
        }

        public Criteria andLN_OPELIVEGreaterThan(String value) {
            addCriterion("LN_OPELIVE >", value, "LN_OPELIVE");
            return (Criteria) this;
        }

        public Criteria andLN_OPELIVEGreaterThanOrEqualTo(String value) {
            addCriterion("LN_OPELIVE >=", value, "LN_OPELIVE");
            return (Criteria) this;
        }

        public Criteria andLN_OPELIVELessThan(String value) {
            addCriterion("LN_OPELIVE <", value, "LN_OPELIVE");
            return (Criteria) this;
        }

        public Criteria andLN_OPELIVELessThanOrEqualTo(String value) {
            addCriterion("LN_OPELIVE <=", value, "LN_OPELIVE");
            return (Criteria) this;
        }

        public Criteria andLN_OPELIVELike(String value) {
            addCriterion("LN_OPELIVE like", value, "LN_OPELIVE");
            return (Criteria) this;
        }

        public Criteria andLN_OPELIVENotLike(String value) {
            addCriterion("LN_OPELIVE not like", value, "LN_OPELIVE");
            return (Criteria) this;
        }

        public Criteria andLN_OPELIVEIn(List<String> values) {
            addCriterion("LN_OPELIVE in", values, "LN_OPELIVE");
            return (Criteria) this;
        }

        public Criteria andLN_OPELIVENotIn(List<String> values) {
            addCriterion("LN_OPELIVE not in", values, "LN_OPELIVE");
            return (Criteria) this;
        }

        public Criteria andLN_OPELIVEBetween(String value1, String value2) {
            addCriterion("LN_OPELIVE between", value1, value2, "LN_OPELIVE");
            return (Criteria) this;
        }

        public Criteria andLN_OPELIVENotBetween(String value1, String value2) {
            addCriterion("LN_OPELIVE not between", value1, value2, "LN_OPELIVE");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_PARIsNull() {
            addCriterion("LN_DEV_PAR is null");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_PARIsNotNull() {
            addCriterion("LN_DEV_PAR is not null");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_PAREqualTo(String value) {
            addCriterion("LN_DEV_PAR =", value, "LN_DEV_PAR");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_PARNotEqualTo(String value) {
            addCriterion("LN_DEV_PAR <>", value, "LN_DEV_PAR");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_PARGreaterThan(String value) {
            addCriterion("LN_DEV_PAR >", value, "LN_DEV_PAR");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_PARGreaterThanOrEqualTo(String value) {
            addCriterion("LN_DEV_PAR >=", value, "LN_DEV_PAR");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_PARLessThan(String value) {
            addCriterion("LN_DEV_PAR <", value, "LN_DEV_PAR");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_PARLessThanOrEqualTo(String value) {
            addCriterion("LN_DEV_PAR <=", value, "LN_DEV_PAR");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_PARLike(String value) {
            addCriterion("LN_DEV_PAR like", value, "LN_DEV_PAR");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_PARNotLike(String value) {
            addCriterion("LN_DEV_PAR not like", value, "LN_DEV_PAR");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_PARIn(List<String> values) {
            addCriterion("LN_DEV_PAR in", values, "LN_DEV_PAR");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_PARNotIn(List<String> values) {
            addCriterion("LN_DEV_PAR not in", values, "LN_DEV_PAR");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_PARBetween(String value1, String value2) {
            addCriterion("LN_DEV_PAR between", value1, value2, "LN_DEV_PAR");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_PARNotBetween(String value1, String value2) {
            addCriterion("LN_DEV_PAR not between", value1, value2, "LN_DEV_PAR");
            return (Criteria) this;
        }

        public Criteria andLN_DEVIsNull() {
            addCriterion("LN_DEV is null");
            return (Criteria) this;
        }

        public Criteria andLN_DEVIsNotNull() {
            addCriterion("LN_DEV is not null");
            return (Criteria) this;
        }

        public Criteria andLN_DEVEqualTo(String value) {
            addCriterion("LN_DEV =", value, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVNotEqualTo(String value) {
            addCriterion("LN_DEV <>", value, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVGreaterThan(String value) {
            addCriterion("LN_DEV >", value, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVGreaterThanOrEqualTo(String value) {
            addCriterion("LN_DEV >=", value, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVLessThan(String value) {
            addCriterion("LN_DEV <", value, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVLessThanOrEqualTo(String value) {
            addCriterion("LN_DEV <=", value, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVLike(String value) {
            addCriterion("LN_DEV like", value, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVNotLike(String value) {
            addCriterion("LN_DEV not like", value, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVIn(List<String> values) {
            addCriterion("LN_DEV in", values, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVNotIn(List<String> values) {
            addCriterion("LN_DEV not in", values, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVBetween(String value1, String value2) {
            addCriterion("LN_DEV between", value1, value2, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_DEVNotBetween(String value1, String value2) {
            addCriterion("LN_DEV not between", value1, value2, "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_ALSOKIsNull() {
            addCriterion("LN_ACNT_ALSOK is null");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_ALSOKIsNotNull() {
            addCriterion("LN_ACNT_ALSOK is not null");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_ALSOKEqualTo(String value) {
            addCriterion("LN_ACNT_ALSOK =", value, "LN_ACNT_ALSOK");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_ALSOKNotEqualTo(String value) {
            addCriterion("LN_ACNT_ALSOK <>", value, "LN_ACNT_ALSOK");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_ALSOKGreaterThan(String value) {
            addCriterion("LN_ACNT_ALSOK >", value, "LN_ACNT_ALSOK");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_ALSOKGreaterThanOrEqualTo(String value) {
            addCriterion("LN_ACNT_ALSOK >=", value, "LN_ACNT_ALSOK");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_ALSOKLessThan(String value) {
            addCriterion("LN_ACNT_ALSOK <", value, "LN_ACNT_ALSOK");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_ALSOKLessThanOrEqualTo(String value) {
            addCriterion("LN_ACNT_ALSOK <=", value, "LN_ACNT_ALSOK");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_ALSOKLike(String value) {
            addCriterion("LN_ACNT_ALSOK like", value, "LN_ACNT_ALSOK");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_ALSOKNotLike(String value) {
            addCriterion("LN_ACNT_ALSOK not like", value, "LN_ACNT_ALSOK");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_ALSOKIn(List<String> values) {
            addCriterion("LN_ACNT_ALSOK in", values, "LN_ACNT_ALSOK");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_ALSOKNotIn(List<String> values) {
            addCriterion("LN_ACNT_ALSOK not in", values, "LN_ACNT_ALSOK");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_ALSOKBetween(String value1, String value2) {
            addCriterion("LN_ACNT_ALSOK between", value1, value2, "LN_ACNT_ALSOK");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_ALSOKNotBetween(String value1, String value2) {
            addCriterion("LN_ACNT_ALSOK not between", value1, value2, "LN_ACNT_ALSOK");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONIsNull() {
            addCriterion("LN_ACNT_USER_COMMON is null");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONIsNotNull() {
            addCriterion("LN_ACNT_USER_COMMON is not null");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONEqualTo(String value) {
            addCriterion("LN_ACNT_USER_COMMON =", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONNotEqualTo(String value) {
            addCriterion("LN_ACNT_USER_COMMON <>", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONGreaterThan(String value) {
            addCriterion("LN_ACNT_USER_COMMON >", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONGreaterThanOrEqualTo(String value) {
            addCriterion("LN_ACNT_USER_COMMON >=", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONLessThan(String value) {
            addCriterion("LN_ACNT_USER_COMMON <", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONLessThanOrEqualTo(String value) {
            addCriterion("LN_ACNT_USER_COMMON <=", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONLike(String value) {
            addCriterion("LN_ACNT_USER_COMMON like", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONNotLike(String value) {
            addCriterion("LN_ACNT_USER_COMMON not like", value, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONIn(List<String> values) {
            addCriterion("LN_ACNT_USER_COMMON in", values, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONNotIn(List<String> values) {
            addCriterion("LN_ACNT_USER_COMMON not in", values, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONBetween(String value1, String value2) {
            addCriterion("LN_ACNT_USER_COMMON between", value1, value2, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONNotBetween(String value1, String value2) {
            addCriterion("LN_ACNT_USER_COMMON not between", value1, value2, "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andOPE_PERM_CONTI_TSTMIsNull() {
            addCriterion("OPE_PERM_CONTI_TSTM is null");
            return (Criteria) this;
        }

        public Criteria andOPE_PERM_CONTI_TSTMIsNotNull() {
            addCriterion("OPE_PERM_CONTI_TSTM is not null");
            return (Criteria) this;
        }

        public Criteria andOPE_PERM_CONTI_TSTMEqualTo(Date value) {
            addCriterion("OPE_PERM_CONTI_TSTM =", value, "OPE_PERM_CONTI_TSTM");
            return (Criteria) this;
        }

        public Criteria andOPE_PERM_CONTI_TSTMNotEqualTo(Date value) {
            addCriterion("OPE_PERM_CONTI_TSTM <>", value, "OPE_PERM_CONTI_TSTM");
            return (Criteria) this;
        }

        public Criteria andOPE_PERM_CONTI_TSTMGreaterThan(Date value) {
            addCriterion("OPE_PERM_CONTI_TSTM >", value, "OPE_PERM_CONTI_TSTM");
            return (Criteria) this;
        }

        public Criteria andOPE_PERM_CONTI_TSTMGreaterThanOrEqualTo(Date value) {
            addCriterion("OPE_PERM_CONTI_TSTM >=", value, "OPE_PERM_CONTI_TSTM");
            return (Criteria) this;
        }

        public Criteria andOPE_PERM_CONTI_TSTMLessThan(Date value) {
            addCriterion("OPE_PERM_CONTI_TSTM <", value, "OPE_PERM_CONTI_TSTM");
            return (Criteria) this;
        }

        public Criteria andOPE_PERM_CONTI_TSTMLessThanOrEqualTo(Date value) {
            addCriterion("OPE_PERM_CONTI_TSTM <=", value, "OPE_PERM_CONTI_TSTM");
            return (Criteria) this;
        }

        public Criteria andOPE_PERM_CONTI_TSTMIn(List<Date> values) {
            addCriterion("OPE_PERM_CONTI_TSTM in", values, "OPE_PERM_CONTI_TSTM");
            return (Criteria) this;
        }

        public Criteria andOPE_PERM_CONTI_TSTMNotIn(List<Date> values) {
            addCriterion("OPE_PERM_CONTI_TSTM not in", values, "OPE_PERM_CONTI_TSTM");
            return (Criteria) this;
        }

        public Criteria andOPE_PERM_CONTI_TSTMBetween(Date value1, Date value2) {
            addCriterion("OPE_PERM_CONTI_TSTM between", value1, value2, "OPE_PERM_CONTI_TSTM");
            return (Criteria) this;
        }

        public Criteria andOPE_PERM_CONTI_TSTMNotBetween(Date value1, Date value2) {
            addCriterion("OPE_PERM_CONTI_TSTM not between", value1, value2, "OPE_PERM_CONTI_TSTM");
            return (Criteria) this;
        }

        public Criteria andIMG_SV_IPIsNull() {
            addCriterion("IMG_SV_IP is null");
            return (Criteria) this;
        }

        public Criteria andIMG_SV_IPIsNotNull() {
            addCriterion("IMG_SV_IP is not null");
            return (Criteria) this;
        }

        public Criteria andIMG_SV_IPEqualTo(String value) {
            addCriterion("IMG_SV_IP =", value, "IMG_SV_IP");
            return (Criteria) this;
        }

        public Criteria andIMG_SV_IPNotEqualTo(String value) {
            addCriterion("IMG_SV_IP <>", value, "IMG_SV_IP");
            return (Criteria) this;
        }

        public Criteria andIMG_SV_IPGreaterThan(String value) {
            addCriterion("IMG_SV_IP >", value, "IMG_SV_IP");
            return (Criteria) this;
        }

        public Criteria andIMG_SV_IPGreaterThanOrEqualTo(String value) {
            addCriterion("IMG_SV_IP >=", value, "IMG_SV_IP");
            return (Criteria) this;
        }

        public Criteria andIMG_SV_IPLessThan(String value) {
            addCriterion("IMG_SV_IP <", value, "IMG_SV_IP");
            return (Criteria) this;
        }

        public Criteria andIMG_SV_IPLessThanOrEqualTo(String value) {
            addCriterion("IMG_SV_IP <=", value, "IMG_SV_IP");
            return (Criteria) this;
        }

        public Criteria andIMG_SV_IPLike(String value) {
            addCriterion("IMG_SV_IP like", value, "IMG_SV_IP");
            return (Criteria) this;
        }

        public Criteria andIMG_SV_IPNotLike(String value) {
            addCriterion("IMG_SV_IP not like", value, "IMG_SV_IP");
            return (Criteria) this;
        }

        public Criteria andIMG_SV_IPIn(List<String> values) {
            addCriterion("IMG_SV_IP in", values, "IMG_SV_IP");
            return (Criteria) this;
        }

        public Criteria andIMG_SV_IPNotIn(List<String> values) {
            addCriterion("IMG_SV_IP not in", values, "IMG_SV_IP");
            return (Criteria) this;
        }

        public Criteria andIMG_SV_IPBetween(String value1, String value2) {
            addCriterion("IMG_SV_IP between", value1, value2, "IMG_SV_IP");
            return (Criteria) this;
        }

        public Criteria andIMG_SV_IPNotBetween(String value1, String value2) {
            addCriterion("IMG_SV_IP not between", value1, value2, "IMG_SV_IP");
            return (Criteria) this;
        }

        public Criteria andVOC_SV_IPIsNull() {
            addCriterion("VOC_SV_IP is null");
            return (Criteria) this;
        }

        public Criteria andVOC_SV_IPIsNotNull() {
            addCriterion("VOC_SV_IP is not null");
            return (Criteria) this;
        }

        public Criteria andVOC_SV_IPEqualTo(String value) {
            addCriterion("VOC_SV_IP =", value, "VOC_SV_IP");
            return (Criteria) this;
        }

        public Criteria andVOC_SV_IPNotEqualTo(String value) {
            addCriterion("VOC_SV_IP <>", value, "VOC_SV_IP");
            return (Criteria) this;
        }

        public Criteria andVOC_SV_IPGreaterThan(String value) {
            addCriterion("VOC_SV_IP >", value, "VOC_SV_IP");
            return (Criteria) this;
        }

        public Criteria andVOC_SV_IPGreaterThanOrEqualTo(String value) {
            addCriterion("VOC_SV_IP >=", value, "VOC_SV_IP");
            return (Criteria) this;
        }

        public Criteria andVOC_SV_IPLessThan(String value) {
            addCriterion("VOC_SV_IP <", value, "VOC_SV_IP");
            return (Criteria) this;
        }

        public Criteria andVOC_SV_IPLessThanOrEqualTo(String value) {
            addCriterion("VOC_SV_IP <=", value, "VOC_SV_IP");
            return (Criteria) this;
        }

        public Criteria andVOC_SV_IPLike(String value) {
            addCriterion("VOC_SV_IP like", value, "VOC_SV_IP");
            return (Criteria) this;
        }

        public Criteria andVOC_SV_IPNotLike(String value) {
            addCriterion("VOC_SV_IP not like", value, "VOC_SV_IP");
            return (Criteria) this;
        }

        public Criteria andVOC_SV_IPIn(List<String> values) {
            addCriterion("VOC_SV_IP in", values, "VOC_SV_IP");
            return (Criteria) this;
        }

        public Criteria andVOC_SV_IPNotIn(List<String> values) {
            addCriterion("VOC_SV_IP not in", values, "VOC_SV_IP");
            return (Criteria) this;
        }

        public Criteria andVOC_SV_IPBetween(String value1, String value2) {
            addCriterion("VOC_SV_IP between", value1, value2, "VOC_SV_IP");
            return (Criteria) this;
        }

        public Criteria andVOC_SV_IPNotBetween(String value1, String value2) {
            addCriterion("VOC_SV_IP not between", value1, value2, "VOC_SV_IP");
            return (Criteria) this;
        }

        public Criteria andCALL_STSIsNull() {
            addCriterion("CALL_STS is null");
            return (Criteria) this;
        }

        public Criteria andCALL_STSIsNotNull() {
            addCriterion("CALL_STS is not null");
            return (Criteria) this;
        }

        public Criteria andCALL_STSEqualTo(String value) {
            addCriterion("CALL_STS =", value, "CALL_STS");
            return (Criteria) this;
        }

        public Criteria andCALL_STSNotEqualTo(String value) {
            addCriterion("CALL_STS <>", value, "CALL_STS");
            return (Criteria) this;
        }

        public Criteria andCALL_STSGreaterThan(String value) {
            addCriterion("CALL_STS >", value, "CALL_STS");
            return (Criteria) this;
        }

        public Criteria andCALL_STSGreaterThanOrEqualTo(String value) {
            addCriterion("CALL_STS >=", value, "CALL_STS");
            return (Criteria) this;
        }

        public Criteria andCALL_STSLessThan(String value) {
            addCriterion("CALL_STS <", value, "CALL_STS");
            return (Criteria) this;
        }

        public Criteria andCALL_STSLessThanOrEqualTo(String value) {
            addCriterion("CALL_STS <=", value, "CALL_STS");
            return (Criteria) this;
        }

        public Criteria andCALL_STSLike(String value) {
            addCriterion("CALL_STS like", value, "CALL_STS");
            return (Criteria) this;
        }

        public Criteria andCALL_STSNotLike(String value) {
            addCriterion("CALL_STS not like", value, "CALL_STS");
            return (Criteria) this;
        }

        public Criteria andCALL_STSIn(List<String> values) {
            addCriterion("CALL_STS in", values, "CALL_STS");
            return (Criteria) this;
        }

        public Criteria andCALL_STSNotIn(List<String> values) {
            addCriterion("CALL_STS not in", values, "CALL_STS");
            return (Criteria) this;
        }

        public Criteria andCALL_STSBetween(String value1, String value2) {
            addCriterion("CALL_STS between", value1, value2, "CALL_STS");
            return (Criteria) this;
        }

        public Criteria andCALL_STSNotBetween(String value1, String value2) {
            addCriterion("CALL_STS not between", value1, value2, "CALL_STS");
            return (Criteria) this;
        }

        public Criteria andLIVE_STSIsNull() {
            addCriterion("LIVE_STS is null");
            return (Criteria) this;
        }

        public Criteria andLIVE_STSIsNotNull() {
            addCriterion("LIVE_STS is not null");
            return (Criteria) this;
        }

        public Criteria andLIVE_STSEqualTo(String value) {
            addCriterion("LIVE_STS =", value, "LIVE_STS");
            return (Criteria) this;
        }

        public Criteria andLIVE_STSNotEqualTo(String value) {
            addCriterion("LIVE_STS <>", value, "LIVE_STS");
            return (Criteria) this;
        }

        public Criteria andLIVE_STSGreaterThan(String value) {
            addCriterion("LIVE_STS >", value, "LIVE_STS");
            return (Criteria) this;
        }

        public Criteria andLIVE_STSGreaterThanOrEqualTo(String value) {
            addCriterion("LIVE_STS >=", value, "LIVE_STS");
            return (Criteria) this;
        }

        public Criteria andLIVE_STSLessThan(String value) {
            addCriterion("LIVE_STS <", value, "LIVE_STS");
            return (Criteria) this;
        }

        public Criteria andLIVE_STSLessThanOrEqualTo(String value) {
            addCriterion("LIVE_STS <=", value, "LIVE_STS");
            return (Criteria) this;
        }

        public Criteria andLIVE_STSLike(String value) {
            addCriterion("LIVE_STS like", value, "LIVE_STS");
            return (Criteria) this;
        }

        public Criteria andLIVE_STSNotLike(String value) {
            addCriterion("LIVE_STS not like", value, "LIVE_STS");
            return (Criteria) this;
        }

        public Criteria andLIVE_STSIn(List<String> values) {
            addCriterion("LIVE_STS in", values, "LIVE_STS");
            return (Criteria) this;
        }

        public Criteria andLIVE_STSNotIn(List<String> values) {
            addCriterion("LIVE_STS not in", values, "LIVE_STS");
            return (Criteria) this;
        }

        public Criteria andLIVE_STSBetween(String value1, String value2) {
            addCriterion("LIVE_STS between", value1, value2, "LIVE_STS");
            return (Criteria) this;
        }

        public Criteria andLIVE_STSNotBetween(String value1, String value2) {
            addCriterion("LIVE_STS not between", value1, value2, "LIVE_STS");
            return (Criteria) this;
        }

        public Criteria andALL_RING_FLGIsNull() {
            addCriterion("ALL_RING_FLG is null");
            return (Criteria) this;
        }

        public Criteria andALL_RING_FLGIsNotNull() {
            addCriterion("ALL_RING_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andALL_RING_FLGEqualTo(String value) {
            addCriterion("ALL_RING_FLG =", value, "ALL_RING_FLG");
            return (Criteria) this;
        }

        public Criteria andALL_RING_FLGNotEqualTo(String value) {
            addCriterion("ALL_RING_FLG <>", value, "ALL_RING_FLG");
            return (Criteria) this;
        }

        public Criteria andALL_RING_FLGGreaterThan(String value) {
            addCriterion("ALL_RING_FLG >", value, "ALL_RING_FLG");
            return (Criteria) this;
        }

        public Criteria andALL_RING_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("ALL_RING_FLG >=", value, "ALL_RING_FLG");
            return (Criteria) this;
        }

        public Criteria andALL_RING_FLGLessThan(String value) {
            addCriterion("ALL_RING_FLG <", value, "ALL_RING_FLG");
            return (Criteria) this;
        }

        public Criteria andALL_RING_FLGLessThanOrEqualTo(String value) {
            addCriterion("ALL_RING_FLG <=", value, "ALL_RING_FLG");
            return (Criteria) this;
        }

        public Criteria andALL_RING_FLGLike(String value) {
            addCriterion("ALL_RING_FLG like", value, "ALL_RING_FLG");
            return (Criteria) this;
        }

        public Criteria andALL_RING_FLGNotLike(String value) {
            addCriterion("ALL_RING_FLG not like", value, "ALL_RING_FLG");
            return (Criteria) this;
        }

        public Criteria andALL_RING_FLGIn(List<String> values) {
            addCriterion("ALL_RING_FLG in", values, "ALL_RING_FLG");
            return (Criteria) this;
        }

        public Criteria andALL_RING_FLGNotIn(List<String> values) {
            addCriterion("ALL_RING_FLG not in", values, "ALL_RING_FLG");
            return (Criteria) this;
        }

        public Criteria andALL_RING_FLGBetween(String value1, String value2) {
            addCriterion("ALL_RING_FLG between", value1, value2, "ALL_RING_FLG");
            return (Criteria) this;
        }

        public Criteria andALL_RING_FLGNotBetween(String value1, String value2) {
            addCriterion("ALL_RING_FLG not between", value1, value2, "ALL_RING_FLG");
            return (Criteria) this;
        }

        public Criteria andIMG_RECV_PORTIsNull() {
            addCriterion("IMG_RECV_PORT is null");
            return (Criteria) this;
        }

        public Criteria andIMG_RECV_PORTIsNotNull() {
            addCriterion("IMG_RECV_PORT is not null");
            return (Criteria) this;
        }

        public Criteria andIMG_RECV_PORTEqualTo(Integer value) {
            addCriterion("IMG_RECV_PORT =", value, "IMG_RECV_PORT");
            return (Criteria) this;
        }

        public Criteria andIMG_RECV_PORTNotEqualTo(Integer value) {
            addCriterion("IMG_RECV_PORT <>", value, "IMG_RECV_PORT");
            return (Criteria) this;
        }

        public Criteria andIMG_RECV_PORTGreaterThan(Integer value) {
            addCriterion("IMG_RECV_PORT >", value, "IMG_RECV_PORT");
            return (Criteria) this;
        }

        public Criteria andIMG_RECV_PORTGreaterThanOrEqualTo(Integer value) {
            addCriterion("IMG_RECV_PORT >=", value, "IMG_RECV_PORT");
            return (Criteria) this;
        }

        public Criteria andIMG_RECV_PORTLessThan(Integer value) {
            addCriterion("IMG_RECV_PORT <", value, "IMG_RECV_PORT");
            return (Criteria) this;
        }

        public Criteria andIMG_RECV_PORTLessThanOrEqualTo(Integer value) {
            addCriterion("IMG_RECV_PORT <=", value, "IMG_RECV_PORT");
            return (Criteria) this;
        }

        public Criteria andIMG_RECV_PORTIn(List<Integer> values) {
            addCriterion("IMG_RECV_PORT in", values, "IMG_RECV_PORT");
            return (Criteria) this;
        }

        public Criteria andIMG_RECV_PORTNotIn(List<Integer> values) {
            addCriterion("IMG_RECV_PORT not in", values, "IMG_RECV_PORT");
            return (Criteria) this;
        }

        public Criteria andIMG_RECV_PORTBetween(Integer value1, Integer value2) {
            addCriterion("IMG_RECV_PORT between", value1, value2, "IMG_RECV_PORT");
            return (Criteria) this;
        }

        public Criteria andIMG_RECV_PORTNotBetween(Integer value1, Integer value2) {
            addCriterion("IMG_RECV_PORT not between", value1, value2, "IMG_RECV_PORT");
            return (Criteria) this;
        }

        public Criteria andVOC_RECV_PORTIsNull() {
            addCriterion("VOC_RECV_PORT is null");
            return (Criteria) this;
        }

        public Criteria andVOC_RECV_PORTIsNotNull() {
            addCriterion("VOC_RECV_PORT is not null");
            return (Criteria) this;
        }

        public Criteria andVOC_RECV_PORTEqualTo(Integer value) {
            addCriterion("VOC_RECV_PORT =", value, "VOC_RECV_PORT");
            return (Criteria) this;
        }

        public Criteria andVOC_RECV_PORTNotEqualTo(Integer value) {
            addCriterion("VOC_RECV_PORT <>", value, "VOC_RECV_PORT");
            return (Criteria) this;
        }

        public Criteria andVOC_RECV_PORTGreaterThan(Integer value) {
            addCriterion("VOC_RECV_PORT >", value, "VOC_RECV_PORT");
            return (Criteria) this;
        }

        public Criteria andVOC_RECV_PORTGreaterThanOrEqualTo(Integer value) {
            addCriterion("VOC_RECV_PORT >=", value, "VOC_RECV_PORT");
            return (Criteria) this;
        }

        public Criteria andVOC_RECV_PORTLessThan(Integer value) {
            addCriterion("VOC_RECV_PORT <", value, "VOC_RECV_PORT");
            return (Criteria) this;
        }

        public Criteria andVOC_RECV_PORTLessThanOrEqualTo(Integer value) {
            addCriterion("VOC_RECV_PORT <=", value, "VOC_RECV_PORT");
            return (Criteria) this;
        }

        public Criteria andVOC_RECV_PORTIn(List<Integer> values) {
            addCriterion("VOC_RECV_PORT in", values, "VOC_RECV_PORT");
            return (Criteria) this;
        }

        public Criteria andVOC_RECV_PORTNotIn(List<Integer> values) {
            addCriterion("VOC_RECV_PORT not in", values, "VOC_RECV_PORT");
            return (Criteria) this;
        }

        public Criteria andVOC_RECV_PORTBetween(Integer value1, Integer value2) {
            addCriterion("VOC_RECV_PORT between", value1, value2, "VOC_RECV_PORT");
            return (Criteria) this;
        }

        public Criteria andVOC_RECV_PORTNotBetween(Integer value1, Integer value2) {
            addCriterion("VOC_RECV_PORT not between", value1, value2, "VOC_RECV_PORT");
            return (Criteria) this;
        }

        public Criteria andIMG_SEND_PORTIsNull() {
            addCriterion("IMG_SEND_PORT is null");
            return (Criteria) this;
        }

        public Criteria andIMG_SEND_PORTIsNotNull() {
            addCriterion("IMG_SEND_PORT is not null");
            return (Criteria) this;
        }

        public Criteria andIMG_SEND_PORTEqualTo(Integer value) {
            addCriterion("IMG_SEND_PORT =", value, "IMG_SEND_PORT");
            return (Criteria) this;
        }

        public Criteria andIMG_SEND_PORTNotEqualTo(Integer value) {
            addCriterion("IMG_SEND_PORT <>", value, "IMG_SEND_PORT");
            return (Criteria) this;
        }

        public Criteria andIMG_SEND_PORTGreaterThan(Integer value) {
            addCriterion("IMG_SEND_PORT >", value, "IMG_SEND_PORT");
            return (Criteria) this;
        }

        public Criteria andIMG_SEND_PORTGreaterThanOrEqualTo(Integer value) {
            addCriterion("IMG_SEND_PORT >=", value, "IMG_SEND_PORT");
            return (Criteria) this;
        }

        public Criteria andIMG_SEND_PORTLessThan(Integer value) {
            addCriterion("IMG_SEND_PORT <", value, "IMG_SEND_PORT");
            return (Criteria) this;
        }

        public Criteria andIMG_SEND_PORTLessThanOrEqualTo(Integer value) {
            addCriterion("IMG_SEND_PORT <=", value, "IMG_SEND_PORT");
            return (Criteria) this;
        }

        public Criteria andIMG_SEND_PORTIn(List<Integer> values) {
            addCriterion("IMG_SEND_PORT in", values, "IMG_SEND_PORT");
            return (Criteria) this;
        }

        public Criteria andIMG_SEND_PORTNotIn(List<Integer> values) {
            addCriterion("IMG_SEND_PORT not in", values, "IMG_SEND_PORT");
            return (Criteria) this;
        }

        public Criteria andIMG_SEND_PORTBetween(Integer value1, Integer value2) {
            addCriterion("IMG_SEND_PORT between", value1, value2, "IMG_SEND_PORT");
            return (Criteria) this;
        }

        public Criteria andIMG_SEND_PORTNotBetween(Integer value1, Integer value2) {
            addCriterion("IMG_SEND_PORT not between", value1, value2, "IMG_SEND_PORT");
            return (Criteria) this;
        }

        public Criteria andFL_RATEIsNull() {
            addCriterion("FL_RATE is null");
            return (Criteria) this;
        }

        public Criteria andFL_RATEIsNotNull() {
            addCriterion("FL_RATE is not null");
            return (Criteria) this;
        }

        public Criteria andFL_RATEEqualTo(String value) {
            addCriterion("FL_RATE =", value, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATENotEqualTo(String value) {
            addCriterion("FL_RATE <>", value, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATEGreaterThan(String value) {
            addCriterion("FL_RATE >", value, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATEGreaterThanOrEqualTo(String value) {
            addCriterion("FL_RATE >=", value, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATELessThan(String value) {
            addCriterion("FL_RATE <", value, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATELessThanOrEqualTo(String value) {
            addCriterion("FL_RATE <=", value, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATELike(String value) {
            addCriterion("FL_RATE like", value, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATENotLike(String value) {
            addCriterion("FL_RATE not like", value, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATEIn(List<String> values) {
            addCriterion("FL_RATE in", values, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATENotIn(List<String> values) {
            addCriterion("FL_RATE not in", values, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATEBetween(String value1, String value2) {
            addCriterion("FL_RATE between", value1, value2, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andFL_RATENotBetween(String value1, String value2) {
            addCriterion("FL_RATE not between", value1, value2, "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andPX_SIZEIsNull() {
            addCriterion("PX_SIZE is null");
            return (Criteria) this;
        }

        public Criteria andPX_SIZEIsNotNull() {
            addCriterion("PX_SIZE is not null");
            return (Criteria) this;
        }

        public Criteria andPX_SIZEEqualTo(String value) {
            addCriterion("PX_SIZE =", value, "PX_SIZE");
            return (Criteria) this;
        }

        public Criteria andPX_SIZENotEqualTo(String value) {
            addCriterion("PX_SIZE <>", value, "PX_SIZE");
            return (Criteria) this;
        }

        public Criteria andPX_SIZEGreaterThan(String value) {
            addCriterion("PX_SIZE >", value, "PX_SIZE");
            return (Criteria) this;
        }

        public Criteria andPX_SIZEGreaterThanOrEqualTo(String value) {
            addCriterion("PX_SIZE >=", value, "PX_SIZE");
            return (Criteria) this;
        }

        public Criteria andPX_SIZELessThan(String value) {
            addCriterion("PX_SIZE <", value, "PX_SIZE");
            return (Criteria) this;
        }

        public Criteria andPX_SIZELessThanOrEqualTo(String value) {
            addCriterion("PX_SIZE <=", value, "PX_SIZE");
            return (Criteria) this;
        }

        public Criteria andPX_SIZELike(String value) {
            addCriterion("PX_SIZE like", value, "PX_SIZE");
            return (Criteria) this;
        }

        public Criteria andPX_SIZENotLike(String value) {
            addCriterion("PX_SIZE not like", value, "PX_SIZE");
            return (Criteria) this;
        }

        public Criteria andPX_SIZEIn(List<String> values) {
            addCriterion("PX_SIZE in", values, "PX_SIZE");
            return (Criteria) this;
        }

        public Criteria andPX_SIZENotIn(List<String> values) {
            addCriterion("PX_SIZE not in", values, "PX_SIZE");
            return (Criteria) this;
        }

        public Criteria andPX_SIZEBetween(String value1, String value2) {
            addCriterion("PX_SIZE between", value1, value2, "PX_SIZE");
            return (Criteria) this;
        }

        public Criteria andPX_SIZENotBetween(String value1, String value2) {
            addCriterion("PX_SIZE not between", value1, value2, "PX_SIZE");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNull() {
            addCriterion("INSERT_ID is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIsNotNull() {
            addCriterion("INSERT_ID is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDEqualTo(String value) {
            addCriterion("INSERT_ID =", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotEqualTo(String value) {
            addCriterion("INSERT_ID <>", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThan(String value) {
            addCriterion("INSERT_ID >", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_ID >=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThan(String value) {
            addCriterion("INSERT_ID <", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLessThanOrEqualTo(String value) {
            addCriterion("INSERT_ID <=", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLike(String value) {
            addCriterion("INSERT_ID like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotLike(String value) {
            addCriterion("INSERT_ID not like", value, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDIn(List<String> values) {
            addCriterion("INSERT_ID in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotIn(List<String> values) {
            addCriterion("INSERT_ID not in", values, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDBetween(String value1, String value2) {
            addCriterion("INSERT_ID between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDNotBetween(String value1, String value2) {
            addCriterion("INSERT_ID not between", value1, value2, "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNull() {
            addCriterion("INSERT_NM is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIsNotNull() {
            addCriterion("INSERT_NM is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMEqualTo(String value) {
            addCriterion("INSERT_NM =", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotEqualTo(String value) {
            addCriterion("INSERT_NM <>", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThan(String value) {
            addCriterion("INSERT_NM >", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMGreaterThanOrEqualTo(String value) {
            addCriterion("INSERT_NM >=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThan(String value) {
            addCriterion("INSERT_NM <", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLessThanOrEqualTo(String value) {
            addCriterion("INSERT_NM <=", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLike(String value) {
            addCriterion("INSERT_NM like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotLike(String value) {
            addCriterion("INSERT_NM not like", value, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMIn(List<String> values) {
            addCriterion("INSERT_NM in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotIn(List<String> values) {
            addCriterion("INSERT_NM not in", values, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMBetween(String value1, String value2) {
            addCriterion("INSERT_NM between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMNotBetween(String value1, String value2) {
            addCriterion("INSERT_NM not between", value1, value2, "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNull() {
            addCriterion("INSERT_TS is null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIsNotNull() {
            addCriterion("INSERT_TS is not null");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSEqualTo(Date value) {
            addCriterion("INSERT_TS =", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotEqualTo(Date value) {
            addCriterion("INSERT_TS <>", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThan(Date value) {
            addCriterion("INSERT_TS >", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS >=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThan(Date value) {
            addCriterion("INSERT_TS <", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSLessThanOrEqualTo(Date value) {
            addCriterion("INSERT_TS <=", value, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSIn(List<Date> values) {
            addCriterion("INSERT_TS in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotIn(List<Date> values) {
            addCriterion("INSERT_TS not in", values, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andINSERT_TSNotBetween(Date value1, Date value2) {
            addCriterion("INSERT_TS not between", value1, value2, "INSERT_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNull() {
            addCriterion("UPDATE_ID is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIsNotNull() {
            addCriterion("UPDATE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDEqualTo(String value) {
            addCriterion("UPDATE_ID =", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotEqualTo(String value) {
            addCriterion("UPDATE_ID <>", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThan(String value) {
            addCriterion("UPDATE_ID >", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID >=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThan(String value) {
            addCriterion("UPDATE_ID <", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_ID <=", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLike(String value) {
            addCriterion("UPDATE_ID like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotLike(String value) {
            addCriterion("UPDATE_ID not like", value, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDIn(List<String> values) {
            addCriterion("UPDATE_ID in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotIn(List<String> values) {
            addCriterion("UPDATE_ID not in", values, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDBetween(String value1, String value2) {
            addCriterion("UPDATE_ID between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDNotBetween(String value1, String value2) {
            addCriterion("UPDATE_ID not between", value1, value2, "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNull() {
            addCriterion("UPDATE_NM is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIsNotNull() {
            addCriterion("UPDATE_NM is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMEqualTo(String value) {
            addCriterion("UPDATE_NM =", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotEqualTo(String value) {
            addCriterion("UPDATE_NM <>", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThan(String value) {
            addCriterion("UPDATE_NM >", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMGreaterThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM >=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThan(String value) {
            addCriterion("UPDATE_NM <", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLessThanOrEqualTo(String value) {
            addCriterion("UPDATE_NM <=", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLike(String value) {
            addCriterion("UPDATE_NM like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotLike(String value) {
            addCriterion("UPDATE_NM not like", value, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMIn(List<String> values) {
            addCriterion("UPDATE_NM in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotIn(List<String> values) {
            addCriterion("UPDATE_NM not in", values, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMBetween(String value1, String value2) {
            addCriterion("UPDATE_NM between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMNotBetween(String value1, String value2) {
            addCriterion("UPDATE_NM not between", value1, value2, "UPDATE_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNull() {
            addCriterion("UPDATE_TS is null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIsNotNull() {
            addCriterion("UPDATE_TS is not null");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSEqualTo(Date value) {
            addCriterion("UPDATE_TS =", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotEqualTo(Date value) {
            addCriterion("UPDATE_TS <>", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThan(Date value) {
            addCriterion("UPDATE_TS >", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSGreaterThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS >=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThan(Date value) {
            addCriterion("UPDATE_TS <", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSLessThanOrEqualTo(Date value) {
            addCriterion("UPDATE_TS <=", value, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSIn(List<Date> values) {
            addCriterion("UPDATE_TS in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotIn(List<Date> values) {
            addCriterion("UPDATE_TS not in", values, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andUPDATE_TSNotBetween(Date value1, Date value2) {
            addCriterion("UPDATE_TS not between", value1, value2, "UPDATE_TS");
            return (Criteria) this;
        }

        public Criteria andLN_OPELIVELikeInsensitive(String value) {
            addCriterion("upper(LN_OPELIVE) like", value.toUpperCase(), "LN_OPELIVE");
            return (Criteria) this;
        }

        public Criteria andLN_DEV_PARLikeInsensitive(String value) {
            addCriterion("upper(LN_DEV_PAR) like", value.toUpperCase(), "LN_DEV_PAR");
            return (Criteria) this;
        }

        public Criteria andLN_DEVLikeInsensitive(String value) {
            addCriterion("upper(LN_DEV) like", value.toUpperCase(), "LN_DEV");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_ALSOKLikeInsensitive(String value) {
            addCriterion("upper(LN_ACNT_ALSOK) like", value.toUpperCase(), "LN_ACNT_ALSOK");
            return (Criteria) this;
        }

        public Criteria andLN_ACNT_USER_COMMONLikeInsensitive(String value) {
            addCriterion("upper(LN_ACNT_USER_COMMON) like", value.toUpperCase(), "LN_ACNT_USER_COMMON");
            return (Criteria) this;
        }

        public Criteria andIMG_SV_IPLikeInsensitive(String value) {
            addCriterion("upper(IMG_SV_IP) like", value.toUpperCase(), "IMG_SV_IP");
            return (Criteria) this;
        }

        public Criteria andVOC_SV_IPLikeInsensitive(String value) {
            addCriterion("upper(VOC_SV_IP) like", value.toUpperCase(), "VOC_SV_IP");
            return (Criteria) this;
        }

        public Criteria andCALL_STSLikeInsensitive(String value) {
            addCriterion("upper(CALL_STS) like", value.toUpperCase(), "CALL_STS");
            return (Criteria) this;
        }

        public Criteria andLIVE_STSLikeInsensitive(String value) {
            addCriterion("upper(LIVE_STS) like", value.toUpperCase(), "LIVE_STS");
            return (Criteria) this;
        }

        public Criteria andALL_RING_FLGLikeInsensitive(String value) {
            addCriterion("upper(ALL_RING_FLG) like", value.toUpperCase(), "ALL_RING_FLG");
            return (Criteria) this;
        }

        public Criteria andFL_RATELikeInsensitive(String value) {
            addCriterion("upper(FL_RATE) like", value.toUpperCase(), "FL_RATE");
            return (Criteria) this;
        }

        public Criteria andPX_SIZELikeInsensitive(String value) {
            addCriterion("upper(PX_SIZE) like", value.toUpperCase(), "PX_SIZE");
            return (Criteria) this;
        }

        public Criteria andINSERT_IDLikeInsensitive(String value) {
            addCriterion("upper(INSERT_ID) like", value.toUpperCase(), "INSERT_ID");
            return (Criteria) this;
        }

        public Criteria andINSERT_NMLikeInsensitive(String value) {
            addCriterion("upper(INSERT_NM) like", value.toUpperCase(), "INSERT_NM");
            return (Criteria) this;
        }

        public Criteria andUPDATE_IDLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_ID) like", value.toUpperCase(), "UPDATE_ID");
            return (Criteria) this;
        }

        public Criteria andUPDATE_NMLikeInsensitive(String value) {
            addCriterion("upper(UPDATE_NM) like", value.toUpperCase(), "UPDATE_NM");
            return (Criteria) this;
        }
    }

    /**
     * I_STS_OPELIVE
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * I_STS_OPELIVE null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}