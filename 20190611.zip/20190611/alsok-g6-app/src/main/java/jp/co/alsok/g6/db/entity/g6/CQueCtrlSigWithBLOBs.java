package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class CQueCtrlSigWithBLOBs extends CQueCtrlSig implements Serializable {
    /**
     * ファイル種別
     */
    private String FILE_KIND;

    /**
     * SOAP電文
     */
    private String SOAP_MSG;

    /**
     * C_QUE_CTRL_SIG
     */
    private static final long serialVersionUID = 1L;

    /**
     * ファイル種別
     * @return FILE_KIND ファイル種別
     */
    public String getFILE_KIND() {
        return FILE_KIND;
    }

    /**
     * ファイル種別
     * @param FILE_KIND ファイル種別
     */
    public void setFILE_KIND(String FILE_KIND) {
        this.FILE_KIND = FILE_KIND == null ? null : FILE_KIND.trim();
    }

    /**
     * SOAP電文
     * @return SOAP_MSG SOAP電文
     */
    public String getSOAP_MSG() {
        return SOAP_MSG;
    }

    /**
     * SOAP電文
     * @param SOAP_MSG SOAP電文
     */
    public void setSOAP_MSG(String SOAP_MSG) {
        this.SOAP_MSG = SOAP_MSG == null ? null : SOAP_MSG.trim();
    }
}