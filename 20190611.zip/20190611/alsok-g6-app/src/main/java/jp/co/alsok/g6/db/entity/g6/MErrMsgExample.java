package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.List;

public class MErrMsgExample {
    /**
     * M_ERR_MSG
     */
    protected String orderByClause;

    /**
     * M_ERR_MSG
     */
    protected boolean distinct;

    /**
     * M_ERR_MSG
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public MErrMsgExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * M_ERR_MSG null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andERR_CDIsNull() {
            addCriterion("ERR_CD is null");
            return (Criteria) this;
        }

        public Criteria andERR_CDIsNotNull() {
            addCriterion("ERR_CD is not null");
            return (Criteria) this;
        }

        public Criteria andERR_CDEqualTo(String value) {
            addCriterion("ERR_CD =", value, "ERR_CD");
            return (Criteria) this;
        }

        public Criteria andERR_CDNotEqualTo(String value) {
            addCriterion("ERR_CD <>", value, "ERR_CD");
            return (Criteria) this;
        }

        public Criteria andERR_CDGreaterThan(String value) {
            addCriterion("ERR_CD >", value, "ERR_CD");
            return (Criteria) this;
        }

        public Criteria andERR_CDGreaterThanOrEqualTo(String value) {
            addCriterion("ERR_CD >=", value, "ERR_CD");
            return (Criteria) this;
        }

        public Criteria andERR_CDLessThan(String value) {
            addCriterion("ERR_CD <", value, "ERR_CD");
            return (Criteria) this;
        }

        public Criteria andERR_CDLessThanOrEqualTo(String value) {
            addCriterion("ERR_CD <=", value, "ERR_CD");
            return (Criteria) this;
        }

        public Criteria andERR_CDLike(String value) {
            addCriterion("ERR_CD like", value, "ERR_CD");
            return (Criteria) this;
        }

        public Criteria andERR_CDNotLike(String value) {
            addCriterion("ERR_CD not like", value, "ERR_CD");
            return (Criteria) this;
        }

        public Criteria andERR_CDIn(List<String> values) {
            addCriterion("ERR_CD in", values, "ERR_CD");
            return (Criteria) this;
        }

        public Criteria andERR_CDNotIn(List<String> values) {
            addCriterion("ERR_CD not in", values, "ERR_CD");
            return (Criteria) this;
        }

        public Criteria andERR_CDBetween(String value1, String value2) {
            addCriterion("ERR_CD between", value1, value2, "ERR_CD");
            return (Criteria) this;
        }

        public Criteria andERR_CDNotBetween(String value1, String value2) {
            addCriterion("ERR_CD not between", value1, value2, "ERR_CD");
            return (Criteria) this;
        }

        public Criteria andERR_LVLIsNull() {
            addCriterion("ERR_LVL is null");
            return (Criteria) this;
        }

        public Criteria andERR_LVLIsNotNull() {
            addCriterion("ERR_LVL is not null");
            return (Criteria) this;
        }

        public Criteria andERR_LVLEqualTo(String value) {
            addCriterion("ERR_LVL =", value, "ERR_LVL");
            return (Criteria) this;
        }

        public Criteria andERR_LVLNotEqualTo(String value) {
            addCriterion("ERR_LVL <>", value, "ERR_LVL");
            return (Criteria) this;
        }

        public Criteria andERR_LVLGreaterThan(String value) {
            addCriterion("ERR_LVL >", value, "ERR_LVL");
            return (Criteria) this;
        }

        public Criteria andERR_LVLGreaterThanOrEqualTo(String value) {
            addCriterion("ERR_LVL >=", value, "ERR_LVL");
            return (Criteria) this;
        }

        public Criteria andERR_LVLLessThan(String value) {
            addCriterion("ERR_LVL <", value, "ERR_LVL");
            return (Criteria) this;
        }

        public Criteria andERR_LVLLessThanOrEqualTo(String value) {
            addCriterion("ERR_LVL <=", value, "ERR_LVL");
            return (Criteria) this;
        }

        public Criteria andERR_LVLLike(String value) {
            addCriterion("ERR_LVL like", value, "ERR_LVL");
            return (Criteria) this;
        }

        public Criteria andERR_LVLNotLike(String value) {
            addCriterion("ERR_LVL not like", value, "ERR_LVL");
            return (Criteria) this;
        }

        public Criteria andERR_LVLIn(List<String> values) {
            addCriterion("ERR_LVL in", values, "ERR_LVL");
            return (Criteria) this;
        }

        public Criteria andERR_LVLNotIn(List<String> values) {
            addCriterion("ERR_LVL not in", values, "ERR_LVL");
            return (Criteria) this;
        }

        public Criteria andERR_LVLBetween(String value1, String value2) {
            addCriterion("ERR_LVL between", value1, value2, "ERR_LVL");
            return (Criteria) this;
        }

        public Criteria andERR_LVLNotBetween(String value1, String value2) {
            addCriterion("ERR_LVL not between", value1, value2, "ERR_LVL");
            return (Criteria) this;
        }

        public Criteria andERR_NMIsNull() {
            addCriterion("ERR_NM is null");
            return (Criteria) this;
        }

        public Criteria andERR_NMIsNotNull() {
            addCriterion("ERR_NM is not null");
            return (Criteria) this;
        }

        public Criteria andERR_NMEqualTo(String value) {
            addCriterion("ERR_NM =", value, "ERR_NM");
            return (Criteria) this;
        }

        public Criteria andERR_NMNotEqualTo(String value) {
            addCriterion("ERR_NM <>", value, "ERR_NM");
            return (Criteria) this;
        }

        public Criteria andERR_NMGreaterThan(String value) {
            addCriterion("ERR_NM >", value, "ERR_NM");
            return (Criteria) this;
        }

        public Criteria andERR_NMGreaterThanOrEqualTo(String value) {
            addCriterion("ERR_NM >=", value, "ERR_NM");
            return (Criteria) this;
        }

        public Criteria andERR_NMLessThan(String value) {
            addCriterion("ERR_NM <", value, "ERR_NM");
            return (Criteria) this;
        }

        public Criteria andERR_NMLessThanOrEqualTo(String value) {
            addCriterion("ERR_NM <=", value, "ERR_NM");
            return (Criteria) this;
        }

        public Criteria andERR_NMLike(String value) {
            addCriterion("ERR_NM like", value, "ERR_NM");
            return (Criteria) this;
        }

        public Criteria andERR_NMNotLike(String value) {
            addCriterion("ERR_NM not like", value, "ERR_NM");
            return (Criteria) this;
        }

        public Criteria andERR_NMIn(List<String> values) {
            addCriterion("ERR_NM in", values, "ERR_NM");
            return (Criteria) this;
        }

        public Criteria andERR_NMNotIn(List<String> values) {
            addCriterion("ERR_NM not in", values, "ERR_NM");
            return (Criteria) this;
        }

        public Criteria andERR_NMBetween(String value1, String value2) {
            addCriterion("ERR_NM between", value1, value2, "ERR_NM");
            return (Criteria) this;
        }

        public Criteria andERR_NMNotBetween(String value1, String value2) {
            addCriterion("ERR_NM not between", value1, value2, "ERR_NM");
            return (Criteria) this;
        }

        public Criteria andRECOVER_MSGIsNull() {
            addCriterion("RECOVER_MSG is null");
            return (Criteria) this;
        }

        public Criteria andRECOVER_MSGIsNotNull() {
            addCriterion("RECOVER_MSG is not null");
            return (Criteria) this;
        }

        public Criteria andRECOVER_MSGEqualTo(String value) {
            addCriterion("RECOVER_MSG =", value, "RECOVER_MSG");
            return (Criteria) this;
        }

        public Criteria andRECOVER_MSGNotEqualTo(String value) {
            addCriterion("RECOVER_MSG <>", value, "RECOVER_MSG");
            return (Criteria) this;
        }

        public Criteria andRECOVER_MSGGreaterThan(String value) {
            addCriterion("RECOVER_MSG >", value, "RECOVER_MSG");
            return (Criteria) this;
        }

        public Criteria andRECOVER_MSGGreaterThanOrEqualTo(String value) {
            addCriterion("RECOVER_MSG >=", value, "RECOVER_MSG");
            return (Criteria) this;
        }

        public Criteria andRECOVER_MSGLessThan(String value) {
            addCriterion("RECOVER_MSG <", value, "RECOVER_MSG");
            return (Criteria) this;
        }

        public Criteria andRECOVER_MSGLessThanOrEqualTo(String value) {
            addCriterion("RECOVER_MSG <=", value, "RECOVER_MSG");
            return (Criteria) this;
        }

        public Criteria andRECOVER_MSGLike(String value) {
            addCriterion("RECOVER_MSG like", value, "RECOVER_MSG");
            return (Criteria) this;
        }

        public Criteria andRECOVER_MSGNotLike(String value) {
            addCriterion("RECOVER_MSG not like", value, "RECOVER_MSG");
            return (Criteria) this;
        }

        public Criteria andRECOVER_MSGIn(List<String> values) {
            addCriterion("RECOVER_MSG in", values, "RECOVER_MSG");
            return (Criteria) this;
        }

        public Criteria andRECOVER_MSGNotIn(List<String> values) {
            addCriterion("RECOVER_MSG not in", values, "RECOVER_MSG");
            return (Criteria) this;
        }

        public Criteria andRECOVER_MSGBetween(String value1, String value2) {
            addCriterion("RECOVER_MSG between", value1, value2, "RECOVER_MSG");
            return (Criteria) this;
        }

        public Criteria andRECOVER_MSGNotBetween(String value1, String value2) {
            addCriterion("RECOVER_MSG not between", value1, value2, "RECOVER_MSG");
            return (Criteria) this;
        }

        public Criteria andERR_CDLikeInsensitive(String value) {
            addCriterion("upper(ERR_CD) like", value.toUpperCase(), "ERR_CD");
            return (Criteria) this;
        }

        public Criteria andERR_LVLLikeInsensitive(String value) {
            addCriterion("upper(ERR_LVL) like", value.toUpperCase(), "ERR_LVL");
            return (Criteria) this;
        }

        public Criteria andERR_NMLikeInsensitive(String value) {
            addCriterion("upper(ERR_NM) like", value.toUpperCase(), "ERR_NM");
            return (Criteria) this;
        }

        public Criteria andRECOVER_MSGLikeInsensitive(String value) {
            addCriterion("upper(RECOVER_MSG) like", value.toUpperCase(), "RECOVER_MSG");
            return (Criteria) this;
        }
    }

    /**
     * M_ERR_MSG
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * M_ERR_MSG null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}