package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class CFileSendDetailKey implements Serializable {
    /**
     * LN_ファイル送信論理番号
     */
    private String LN_FILE_SEND;

    /**
     * 処理通番
     */
    private String PROCESS_NUM;

    /**
     * C_FILE_SEND_DETAIL
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_ファイル送信論理番号
     * @return LN_FILE_SEND LN_ファイル送信論理番号
     */
    public String getLN_FILE_SEND() {
        return LN_FILE_SEND;
    }

    /**
     * LN_ファイル送信論理番号
     * @param LN_FILE_SEND LN_ファイル送信論理番号
     */
    public void setLN_FILE_SEND(String LN_FILE_SEND) {
        this.LN_FILE_SEND = LN_FILE_SEND == null ? null : LN_FILE_SEND.trim();
    }

    /**
     * 処理通番
     * @return PROCESS_NUM 処理通番
     */
    public String getPROCESS_NUM() {
        return PROCESS_NUM;
    }

    /**
     * 処理通番
     * @param PROCESS_NUM 処理通番
     */
    public void setPROCESS_NUM(String PROCESS_NUM) {
        this.PROCESS_NUM = PROCESS_NUM == null ? null : PROCESS_NUM.trim();
    }
}