package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class MFxPush implements Serializable {
    /**
     * 種別
     */
    private String KIND;

    /**
     * 差出人名称
     */
    private String FROM_NM;

    /**
     * タイトル
     */
    private String TITLE;

    /**
     * M_FX_PUSH
     */
    private static final long serialVersionUID = 1L;

    /**
     * 種別
     * @return KIND 種別
     */
    public String getKIND() {
        return KIND;
    }

    /**
     * 種別
     * @param KIND 種別
     */
    public void setKIND(String KIND) {
        this.KIND = KIND == null ? null : KIND.trim();
    }

    /**
     * 差出人名称
     * @return FROM_NM 差出人名称
     */
    public String getFROM_NM() {
        return FROM_NM;
    }

    /**
     * 差出人名称
     * @param FROM_NM 差出人名称
     */
    public void setFROM_NM(String FROM_NM) {
        this.FROM_NM = FROM_NM == null ? null : FROM_NM.trim();
    }

    /**
     * タイトル
     * @return TITLE タイトル
     */
    public String getTITLE() {
        return TITLE;
    }

    /**
     * タイトル
     * @param TITLE タイトル
     */
    public void setTITLE(String TITLE) {
        this.TITLE = TITLE == null ? null : TITLE.trim();
    }
}