package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class EKbInfJianKey implements Serializable {
    /**
     * LN_警備情報論理番号
     */
    private String LN_KB_INF;

    /**
     * LN_事案論理番号
     */
    private String LN_JIAN;

    /**
     * E_KB_INF_JIAN
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_警備情報論理番号
     * @return LN_KB_INF LN_警備情報論理番号
     */
    public String getLN_KB_INF() {
        return LN_KB_INF;
    }

    /**
     * LN_警備情報論理番号
     * @param LN_KB_INF LN_警備情報論理番号
     */
    public void setLN_KB_INF(String LN_KB_INF) {
        this.LN_KB_INF = LN_KB_INF == null ? null : LN_KB_INF.trim();
    }

    /**
     * LN_事案論理番号
     * @return LN_JIAN LN_事案論理番号
     */
    public String getLN_JIAN() {
        return LN_JIAN;
    }

    /**
     * LN_事案論理番号
     * @param LN_JIAN LN_事案論理番号
     */
    public void setLN_JIAN(String LN_JIAN) {
        this.LN_JIAN = LN_JIAN == null ? null : LN_JIAN.trim();
    }
}