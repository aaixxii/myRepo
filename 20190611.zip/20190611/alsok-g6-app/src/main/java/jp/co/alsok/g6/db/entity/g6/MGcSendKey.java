package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class MGcSendKey implements Serializable {
    /**
     * 警備サービス種別コード
     */
    private String KB_SERVICE_CD;

    /**
     * 信号種別1
     */
    private String SIG_KIND_1;

    /**
     * 信号種別2
     */
    private String SIG_KIND_2;

    /**
     * M_GC_SEND
     */
    private static final long serialVersionUID = 1L;

    /**
     * 警備サービス種別コード
     * @return KB_SERVICE_CD 警備サービス種別コード
     */
    public String getKB_SERVICE_CD() {
        return KB_SERVICE_CD;
    }

    /**
     * 警備サービス種別コード
     * @param KB_SERVICE_CD 警備サービス種別コード
     */
    public void setKB_SERVICE_CD(String KB_SERVICE_CD) {
        this.KB_SERVICE_CD = KB_SERVICE_CD == null ? null : KB_SERVICE_CD.trim();
    }

    /**
     * 信号種別1
     * @return SIG_KIND_1 信号種別1
     */
    public String getSIG_KIND_1() {
        return SIG_KIND_1;
    }

    /**
     * 信号種別1
     * @param SIG_KIND_1 信号種別1
     */
    public void setSIG_KIND_1(String SIG_KIND_1) {
        this.SIG_KIND_1 = SIG_KIND_1 == null ? null : SIG_KIND_1.trim();
    }

    /**
     * 信号種別2
     * @return SIG_KIND_2 信号種別2
     */
    public String getSIG_KIND_2() {
        return SIG_KIND_2;
    }

    /**
     * 信号種別2
     * @param SIG_KIND_2 信号種別2
     */
    public void setSIG_KIND_2(String SIG_KIND_2) {
        this.SIG_KIND_2 = SIG_KIND_2 == null ? null : SIG_KIND_2.trim();
    }
}