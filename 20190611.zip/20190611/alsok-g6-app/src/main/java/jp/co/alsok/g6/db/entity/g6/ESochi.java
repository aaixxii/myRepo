package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class ESochi implements Serializable {
    /**
     * LN_事案論理番号
     */
    private String LN_JIAN;

    /**
     * 内容１
     */
    private String SOCHI_NAIYOU01;

    /**
     * 内容２
     */
    private String SOCHI_NAIYOU02;

    /**
     * 内容３
     */
    private String SOCHI_NAIYOU03;

    /**
     * 内容４
     */
    private String SOCHI_NAIYOU04;

    /**
     * 内容５
     */
    private String SOCHI_NAIYOU05;

    /**
     * 内容６
     */
    private String SOCHI_NAIYOU06;

    /**
     * 内容７
     */
    private String SOCHI_NAIYOU07;

    /**
     * 内容８
     */
    private String SOCHI_NAIYOU08;

    /**
     * 内容９
     */
    private String SOCHI_NAIYOU09;

    /**
     * 内容１０
     */
    private String SOCHI_NAIYOU10;

    /**
     * 内容１１
     */
    private String SOCHI_NAIYOU11;

    /**
     * 内容１２
     */
    private String SOCHI_NAIYOU12;

    /**
     * 内容１３
     */
    private String SOCHI_NAIYOU13;

    /**
     * 内容１４
     */
    private String SOCHI_NAIYOU14;

    /**
     * 内容１５
     */
    private String SOCHI_NAIYOU15;

    /**
     * 内容１６
     */
    private String SOCHI_NAIYOU16;

    /**
     * 内容１７
     */
    private String SOCHI_NAIYOU17;

    /**
     * 内容１８
     */
    private String SOCHI_NAIYOU18;

    /**
     * 内容１９
     */
    private String SOCHI_NAIYOU19;

    /**
     * 内容２０
     */
    private String SOCHI_NAIYOU20;

    /**
     * 内容２１
     */
    private String SOCHI_NAIYOU21;

    /**
     * 内容２２
     */
    private String SOCHI_NAIYOU22;

    /**
     * 内容２３
     */
    private String SOCHI_NAIYOU23;

    /**
     * 内容２４
     */
    private String SOCHI_NAIYOU24;

    /**
     * 内容２５
     */
    private String SOCHI_NAIYOU25;

    /**
     * 内容２６
     */
    private String SOCHI_NAIYOU26;

    /**
     * 内容２７
     */
    private String SOCHI_NAIYOU27;

    /**
     * 内容２８
     */
    private String SOCHI_NAIYOU28;

    /**
     * 内容２９
     */
    private String SOCHI_NAIYOU29;

    /**
     * 内容３０
     */
    private String SOCHI_NAIYOU30;

    /**
     * 内容３１
     */
    private String SOCHI_NAIYOU31;

    /**
     * 内容３２
     */
    private String SOCHI_NAIYOU32;

    /**
     * 内容３３
     */
    private String SOCHI_NAIYOU33;

    /**
     * 内容３４
     */
    private String SOCHI_NAIYOU34;

    /**
     * 内容３５
     */
    private String SOCHI_NAIYOU35;

    /**
     * 結果１
     */
    private String KEKKA01;

    /**
     * 結果２
     */
    private String KEKKA02;

    /**
     * 結果３
     */
    private String KEKKA03;

    /**
     * 結果４
     */
    private String KEKKA04;

    /**
     * 結果５
     */
    private String KEKKA05;

    /**
     * 結果６
     */
    private String KEKKA06;

    /**
     * 結果７
     */
    private String KEKKA07;

    /**
     * 結果８
     */
    private String KEKKA08;

    /**
     * 結果９
     */
    private String KEKKA09;

    /**
     * 結果１０
     */
    private String KEKKA10;

    /**
     * 時間１
     */
    private String TIME01;

    /**
     * 時間２
     */
    private String TIME02;

    /**
     * 時間３
     */
    private String TIME03;

    /**
     * 時間４
     */
    private String TIME04;

    /**
     * 時間５
     */
    private String TIME05;

    /**
     * 時間６
     */
    private String TIME06;

    /**
     * 時間７
     */
    private String TIME07;

    /**
     * 時間８
     */
    private String TIME08;

    /**
     * 時間９
     */
    private String TIME09;

    /**
     * 時間１０
     */
    private String TIME10;

    /**
     * 時間１１
     */
    private String TIME11;

    /**
     * 時間１２
     */
    private String TIME12;

    /**
     * 時間１３
     */
    private String TIME13;

    /**
     * 時間１４
     */
    private String TIME14;

    /**
     * 時間１５
     */
    private String TIME15;

    /**
     * 時間１６
     */
    private String TIME16;

    /**
     * 時間１７
     */
    private String TIME17;

    /**
     * 時間１８
     */
    private String TIME18;

    /**
     * 時間１９
     */
    private String TIME19;

    /**
     * 時間２０
     */
    private String TIME20;

    /**
     * 時間２１
     */
    private String TIME21;

    /**
     * 時間２２
     */
    private String TIME22;

    /**
     * 時間２３
     */
    private String TIME23;

    /**
     * 時間２４
     */
    private String TIME24;

    /**
     * 時間２５
     */
    private String TIME25;

    /**
     * 時間２６
     */
    private String TIME26;

    /**
     * 時間２７
     */
    private String TIME27;

    /**
     * 時間２８
     */
    private String TIME28;

    /**
     * 時間２９
     */
    private String TIME29;

    /**
     * 時間３０
     */
    private String TIME30;

    /**
     * 時間３１
     */
    private String TIME31;

    /**
     * 時間３２
     */
    private String TIME32;

    /**
     * 時間３３
     */
    private String TIME33;

    /**
     * 時間３４
     */
    private String TIME34;

    /**
     * 時間３５
     */
    private String TIME35;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * E_SOCHI
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_事案論理番号
     * @return LN_JIAN LN_事案論理番号
     */
    public String getLN_JIAN() {
        return LN_JIAN;
    }

    /**
     * LN_事案論理番号
     * @param LN_JIAN LN_事案論理番号
     */
    public void setLN_JIAN(String LN_JIAN) {
        this.LN_JIAN = LN_JIAN == null ? null : LN_JIAN.trim();
    }

    /**
     * 内容１
     * @return SOCHI_NAIYOU01 内容１
     */
    public String getSOCHI_NAIYOU01() {
        return SOCHI_NAIYOU01;
    }

    /**
     * 内容１
     * @param SOCHI_NAIYOU01 内容１
     */
    public void setSOCHI_NAIYOU01(String SOCHI_NAIYOU01) {
        this.SOCHI_NAIYOU01 = SOCHI_NAIYOU01 == null ? null : SOCHI_NAIYOU01.trim();
    }

    /**
     * 内容２
     * @return SOCHI_NAIYOU02 内容２
     */
    public String getSOCHI_NAIYOU02() {
        return SOCHI_NAIYOU02;
    }

    /**
     * 内容２
     * @param SOCHI_NAIYOU02 内容２
     */
    public void setSOCHI_NAIYOU02(String SOCHI_NAIYOU02) {
        this.SOCHI_NAIYOU02 = SOCHI_NAIYOU02 == null ? null : SOCHI_NAIYOU02.trim();
    }

    /**
     * 内容３
     * @return SOCHI_NAIYOU03 内容３
     */
    public String getSOCHI_NAIYOU03() {
        return SOCHI_NAIYOU03;
    }

    /**
     * 内容３
     * @param SOCHI_NAIYOU03 内容３
     */
    public void setSOCHI_NAIYOU03(String SOCHI_NAIYOU03) {
        this.SOCHI_NAIYOU03 = SOCHI_NAIYOU03 == null ? null : SOCHI_NAIYOU03.trim();
    }

    /**
     * 内容４
     * @return SOCHI_NAIYOU04 内容４
     */
    public String getSOCHI_NAIYOU04() {
        return SOCHI_NAIYOU04;
    }

    /**
     * 内容４
     * @param SOCHI_NAIYOU04 内容４
     */
    public void setSOCHI_NAIYOU04(String SOCHI_NAIYOU04) {
        this.SOCHI_NAIYOU04 = SOCHI_NAIYOU04 == null ? null : SOCHI_NAIYOU04.trim();
    }

    /**
     * 内容５
     * @return SOCHI_NAIYOU05 内容５
     */
    public String getSOCHI_NAIYOU05() {
        return SOCHI_NAIYOU05;
    }

    /**
     * 内容５
     * @param SOCHI_NAIYOU05 内容５
     */
    public void setSOCHI_NAIYOU05(String SOCHI_NAIYOU05) {
        this.SOCHI_NAIYOU05 = SOCHI_NAIYOU05 == null ? null : SOCHI_NAIYOU05.trim();
    }

    /**
     * 内容６
     * @return SOCHI_NAIYOU06 内容６
     */
    public String getSOCHI_NAIYOU06() {
        return SOCHI_NAIYOU06;
    }

    /**
     * 内容６
     * @param SOCHI_NAIYOU06 内容６
     */
    public void setSOCHI_NAIYOU06(String SOCHI_NAIYOU06) {
        this.SOCHI_NAIYOU06 = SOCHI_NAIYOU06 == null ? null : SOCHI_NAIYOU06.trim();
    }

    /**
     * 内容７
     * @return SOCHI_NAIYOU07 内容７
     */
    public String getSOCHI_NAIYOU07() {
        return SOCHI_NAIYOU07;
    }

    /**
     * 内容７
     * @param SOCHI_NAIYOU07 内容７
     */
    public void setSOCHI_NAIYOU07(String SOCHI_NAIYOU07) {
        this.SOCHI_NAIYOU07 = SOCHI_NAIYOU07 == null ? null : SOCHI_NAIYOU07.trim();
    }

    /**
     * 内容８
     * @return SOCHI_NAIYOU08 内容８
     */
    public String getSOCHI_NAIYOU08() {
        return SOCHI_NAIYOU08;
    }

    /**
     * 内容８
     * @param SOCHI_NAIYOU08 内容８
     */
    public void setSOCHI_NAIYOU08(String SOCHI_NAIYOU08) {
        this.SOCHI_NAIYOU08 = SOCHI_NAIYOU08 == null ? null : SOCHI_NAIYOU08.trim();
    }

    /**
     * 内容９
     * @return SOCHI_NAIYOU09 内容９
     */
    public String getSOCHI_NAIYOU09() {
        return SOCHI_NAIYOU09;
    }

    /**
     * 内容９
     * @param SOCHI_NAIYOU09 内容９
     */
    public void setSOCHI_NAIYOU09(String SOCHI_NAIYOU09) {
        this.SOCHI_NAIYOU09 = SOCHI_NAIYOU09 == null ? null : SOCHI_NAIYOU09.trim();
    }

    /**
     * 内容１０
     * @return SOCHI_NAIYOU10 内容１０
     */
    public String getSOCHI_NAIYOU10() {
        return SOCHI_NAIYOU10;
    }

    /**
     * 内容１０
     * @param SOCHI_NAIYOU10 内容１０
     */
    public void setSOCHI_NAIYOU10(String SOCHI_NAIYOU10) {
        this.SOCHI_NAIYOU10 = SOCHI_NAIYOU10 == null ? null : SOCHI_NAIYOU10.trim();
    }

    /**
     * 内容１１
     * @return SOCHI_NAIYOU11 内容１１
     */
    public String getSOCHI_NAIYOU11() {
        return SOCHI_NAIYOU11;
    }

    /**
     * 内容１１
     * @param SOCHI_NAIYOU11 内容１１
     */
    public void setSOCHI_NAIYOU11(String SOCHI_NAIYOU11) {
        this.SOCHI_NAIYOU11 = SOCHI_NAIYOU11 == null ? null : SOCHI_NAIYOU11.trim();
    }

    /**
     * 内容１２
     * @return SOCHI_NAIYOU12 内容１２
     */
    public String getSOCHI_NAIYOU12() {
        return SOCHI_NAIYOU12;
    }

    /**
     * 内容１２
     * @param SOCHI_NAIYOU12 内容１２
     */
    public void setSOCHI_NAIYOU12(String SOCHI_NAIYOU12) {
        this.SOCHI_NAIYOU12 = SOCHI_NAIYOU12 == null ? null : SOCHI_NAIYOU12.trim();
    }

    /**
     * 内容１３
     * @return SOCHI_NAIYOU13 内容１３
     */
    public String getSOCHI_NAIYOU13() {
        return SOCHI_NAIYOU13;
    }

    /**
     * 内容１３
     * @param SOCHI_NAIYOU13 内容１３
     */
    public void setSOCHI_NAIYOU13(String SOCHI_NAIYOU13) {
        this.SOCHI_NAIYOU13 = SOCHI_NAIYOU13 == null ? null : SOCHI_NAIYOU13.trim();
    }

    /**
     * 内容１４
     * @return SOCHI_NAIYOU14 内容１４
     */
    public String getSOCHI_NAIYOU14() {
        return SOCHI_NAIYOU14;
    }

    /**
     * 内容１４
     * @param SOCHI_NAIYOU14 内容１４
     */
    public void setSOCHI_NAIYOU14(String SOCHI_NAIYOU14) {
        this.SOCHI_NAIYOU14 = SOCHI_NAIYOU14 == null ? null : SOCHI_NAIYOU14.trim();
    }

    /**
     * 内容１５
     * @return SOCHI_NAIYOU15 内容１５
     */
    public String getSOCHI_NAIYOU15() {
        return SOCHI_NAIYOU15;
    }

    /**
     * 内容１５
     * @param SOCHI_NAIYOU15 内容１５
     */
    public void setSOCHI_NAIYOU15(String SOCHI_NAIYOU15) {
        this.SOCHI_NAIYOU15 = SOCHI_NAIYOU15 == null ? null : SOCHI_NAIYOU15.trim();
    }

    /**
     * 内容１６
     * @return SOCHI_NAIYOU16 内容１６
     */
    public String getSOCHI_NAIYOU16() {
        return SOCHI_NAIYOU16;
    }

    /**
     * 内容１６
     * @param SOCHI_NAIYOU16 内容１６
     */
    public void setSOCHI_NAIYOU16(String SOCHI_NAIYOU16) {
        this.SOCHI_NAIYOU16 = SOCHI_NAIYOU16 == null ? null : SOCHI_NAIYOU16.trim();
    }

    /**
     * 内容１７
     * @return SOCHI_NAIYOU17 内容１７
     */
    public String getSOCHI_NAIYOU17() {
        return SOCHI_NAIYOU17;
    }

    /**
     * 内容１７
     * @param SOCHI_NAIYOU17 内容１７
     */
    public void setSOCHI_NAIYOU17(String SOCHI_NAIYOU17) {
        this.SOCHI_NAIYOU17 = SOCHI_NAIYOU17 == null ? null : SOCHI_NAIYOU17.trim();
    }

    /**
     * 内容１８
     * @return SOCHI_NAIYOU18 内容１８
     */
    public String getSOCHI_NAIYOU18() {
        return SOCHI_NAIYOU18;
    }

    /**
     * 内容１８
     * @param SOCHI_NAIYOU18 内容１８
     */
    public void setSOCHI_NAIYOU18(String SOCHI_NAIYOU18) {
        this.SOCHI_NAIYOU18 = SOCHI_NAIYOU18 == null ? null : SOCHI_NAIYOU18.trim();
    }

    /**
     * 内容１９
     * @return SOCHI_NAIYOU19 内容１９
     */
    public String getSOCHI_NAIYOU19() {
        return SOCHI_NAIYOU19;
    }

    /**
     * 内容１９
     * @param SOCHI_NAIYOU19 内容１９
     */
    public void setSOCHI_NAIYOU19(String SOCHI_NAIYOU19) {
        this.SOCHI_NAIYOU19 = SOCHI_NAIYOU19 == null ? null : SOCHI_NAIYOU19.trim();
    }

    /**
     * 内容２０
     * @return SOCHI_NAIYOU20 内容２０
     */
    public String getSOCHI_NAIYOU20() {
        return SOCHI_NAIYOU20;
    }

    /**
     * 内容２０
     * @param SOCHI_NAIYOU20 内容２０
     */
    public void setSOCHI_NAIYOU20(String SOCHI_NAIYOU20) {
        this.SOCHI_NAIYOU20 = SOCHI_NAIYOU20 == null ? null : SOCHI_NAIYOU20.trim();
    }

    /**
     * 内容２１
     * @return SOCHI_NAIYOU21 内容２１
     */
    public String getSOCHI_NAIYOU21() {
        return SOCHI_NAIYOU21;
    }

    /**
     * 内容２１
     * @param SOCHI_NAIYOU21 内容２１
     */
    public void setSOCHI_NAIYOU21(String SOCHI_NAIYOU21) {
        this.SOCHI_NAIYOU21 = SOCHI_NAIYOU21 == null ? null : SOCHI_NAIYOU21.trim();
    }

    /**
     * 内容２２
     * @return SOCHI_NAIYOU22 内容２２
     */
    public String getSOCHI_NAIYOU22() {
        return SOCHI_NAIYOU22;
    }

    /**
     * 内容２２
     * @param SOCHI_NAIYOU22 内容２２
     */
    public void setSOCHI_NAIYOU22(String SOCHI_NAIYOU22) {
        this.SOCHI_NAIYOU22 = SOCHI_NAIYOU22 == null ? null : SOCHI_NAIYOU22.trim();
    }

    /**
     * 内容２３
     * @return SOCHI_NAIYOU23 内容２３
     */
    public String getSOCHI_NAIYOU23() {
        return SOCHI_NAIYOU23;
    }

    /**
     * 内容２３
     * @param SOCHI_NAIYOU23 内容２３
     */
    public void setSOCHI_NAIYOU23(String SOCHI_NAIYOU23) {
        this.SOCHI_NAIYOU23 = SOCHI_NAIYOU23 == null ? null : SOCHI_NAIYOU23.trim();
    }

    /**
     * 内容２４
     * @return SOCHI_NAIYOU24 内容２４
     */
    public String getSOCHI_NAIYOU24() {
        return SOCHI_NAIYOU24;
    }

    /**
     * 内容２４
     * @param SOCHI_NAIYOU24 内容２４
     */
    public void setSOCHI_NAIYOU24(String SOCHI_NAIYOU24) {
        this.SOCHI_NAIYOU24 = SOCHI_NAIYOU24 == null ? null : SOCHI_NAIYOU24.trim();
    }

    /**
     * 内容２５
     * @return SOCHI_NAIYOU25 内容２５
     */
    public String getSOCHI_NAIYOU25() {
        return SOCHI_NAIYOU25;
    }

    /**
     * 内容２５
     * @param SOCHI_NAIYOU25 内容２５
     */
    public void setSOCHI_NAIYOU25(String SOCHI_NAIYOU25) {
        this.SOCHI_NAIYOU25 = SOCHI_NAIYOU25 == null ? null : SOCHI_NAIYOU25.trim();
    }

    /**
     * 内容２６
     * @return SOCHI_NAIYOU26 内容２６
     */
    public String getSOCHI_NAIYOU26() {
        return SOCHI_NAIYOU26;
    }

    /**
     * 内容２６
     * @param SOCHI_NAIYOU26 内容２６
     */
    public void setSOCHI_NAIYOU26(String SOCHI_NAIYOU26) {
        this.SOCHI_NAIYOU26 = SOCHI_NAIYOU26 == null ? null : SOCHI_NAIYOU26.trim();
    }

    /**
     * 内容２７
     * @return SOCHI_NAIYOU27 内容２７
     */
    public String getSOCHI_NAIYOU27() {
        return SOCHI_NAIYOU27;
    }

    /**
     * 内容２７
     * @param SOCHI_NAIYOU27 内容２７
     */
    public void setSOCHI_NAIYOU27(String SOCHI_NAIYOU27) {
        this.SOCHI_NAIYOU27 = SOCHI_NAIYOU27 == null ? null : SOCHI_NAIYOU27.trim();
    }

    /**
     * 内容２８
     * @return SOCHI_NAIYOU28 内容２８
     */
    public String getSOCHI_NAIYOU28() {
        return SOCHI_NAIYOU28;
    }

    /**
     * 内容２８
     * @param SOCHI_NAIYOU28 内容２８
     */
    public void setSOCHI_NAIYOU28(String SOCHI_NAIYOU28) {
        this.SOCHI_NAIYOU28 = SOCHI_NAIYOU28 == null ? null : SOCHI_NAIYOU28.trim();
    }

    /**
     * 内容２９
     * @return SOCHI_NAIYOU29 内容２９
     */
    public String getSOCHI_NAIYOU29() {
        return SOCHI_NAIYOU29;
    }

    /**
     * 内容２９
     * @param SOCHI_NAIYOU29 内容２９
     */
    public void setSOCHI_NAIYOU29(String SOCHI_NAIYOU29) {
        this.SOCHI_NAIYOU29 = SOCHI_NAIYOU29 == null ? null : SOCHI_NAIYOU29.trim();
    }

    /**
     * 内容３０
     * @return SOCHI_NAIYOU30 内容３０
     */
    public String getSOCHI_NAIYOU30() {
        return SOCHI_NAIYOU30;
    }

    /**
     * 内容３０
     * @param SOCHI_NAIYOU30 内容３０
     */
    public void setSOCHI_NAIYOU30(String SOCHI_NAIYOU30) {
        this.SOCHI_NAIYOU30 = SOCHI_NAIYOU30 == null ? null : SOCHI_NAIYOU30.trim();
    }

    /**
     * 内容３１
     * @return SOCHI_NAIYOU31 内容３１
     */
    public String getSOCHI_NAIYOU31() {
        return SOCHI_NAIYOU31;
    }

    /**
     * 内容３１
     * @param SOCHI_NAIYOU31 内容３１
     */
    public void setSOCHI_NAIYOU31(String SOCHI_NAIYOU31) {
        this.SOCHI_NAIYOU31 = SOCHI_NAIYOU31 == null ? null : SOCHI_NAIYOU31.trim();
    }

    /**
     * 内容３２
     * @return SOCHI_NAIYOU32 内容３２
     */
    public String getSOCHI_NAIYOU32() {
        return SOCHI_NAIYOU32;
    }

    /**
     * 内容３２
     * @param SOCHI_NAIYOU32 内容３２
     */
    public void setSOCHI_NAIYOU32(String SOCHI_NAIYOU32) {
        this.SOCHI_NAIYOU32 = SOCHI_NAIYOU32 == null ? null : SOCHI_NAIYOU32.trim();
    }

    /**
     * 内容３３
     * @return SOCHI_NAIYOU33 内容３３
     */
    public String getSOCHI_NAIYOU33() {
        return SOCHI_NAIYOU33;
    }

    /**
     * 内容３３
     * @param SOCHI_NAIYOU33 内容３３
     */
    public void setSOCHI_NAIYOU33(String SOCHI_NAIYOU33) {
        this.SOCHI_NAIYOU33 = SOCHI_NAIYOU33 == null ? null : SOCHI_NAIYOU33.trim();
    }

    /**
     * 内容３４
     * @return SOCHI_NAIYOU34 内容３４
     */
    public String getSOCHI_NAIYOU34() {
        return SOCHI_NAIYOU34;
    }

    /**
     * 内容３４
     * @param SOCHI_NAIYOU34 内容３４
     */
    public void setSOCHI_NAIYOU34(String SOCHI_NAIYOU34) {
        this.SOCHI_NAIYOU34 = SOCHI_NAIYOU34 == null ? null : SOCHI_NAIYOU34.trim();
    }

    /**
     * 内容３５
     * @return SOCHI_NAIYOU35 内容３５
     */
    public String getSOCHI_NAIYOU35() {
        return SOCHI_NAIYOU35;
    }

    /**
     * 内容３５
     * @param SOCHI_NAIYOU35 内容３５
     */
    public void setSOCHI_NAIYOU35(String SOCHI_NAIYOU35) {
        this.SOCHI_NAIYOU35 = SOCHI_NAIYOU35 == null ? null : SOCHI_NAIYOU35.trim();
    }

    /**
     * 結果１
     * @return KEKKA01 結果１
     */
    public String getKEKKA01() {
        return KEKKA01;
    }

    /**
     * 結果１
     * @param KEKKA01 結果１
     */
    public void setKEKKA01(String KEKKA01) {
        this.KEKKA01 = KEKKA01 == null ? null : KEKKA01.trim();
    }

    /**
     * 結果２
     * @return KEKKA02 結果２
     */
    public String getKEKKA02() {
        return KEKKA02;
    }

    /**
     * 結果２
     * @param KEKKA02 結果２
     */
    public void setKEKKA02(String KEKKA02) {
        this.KEKKA02 = KEKKA02 == null ? null : KEKKA02.trim();
    }

    /**
     * 結果３
     * @return KEKKA03 結果３
     */
    public String getKEKKA03() {
        return KEKKA03;
    }

    /**
     * 結果３
     * @param KEKKA03 結果３
     */
    public void setKEKKA03(String KEKKA03) {
        this.KEKKA03 = KEKKA03 == null ? null : KEKKA03.trim();
    }

    /**
     * 結果４
     * @return KEKKA04 結果４
     */
    public String getKEKKA04() {
        return KEKKA04;
    }

    /**
     * 結果４
     * @param KEKKA04 結果４
     */
    public void setKEKKA04(String KEKKA04) {
        this.KEKKA04 = KEKKA04 == null ? null : KEKKA04.trim();
    }

    /**
     * 結果５
     * @return KEKKA05 結果５
     */
    public String getKEKKA05() {
        return KEKKA05;
    }

    /**
     * 結果５
     * @param KEKKA05 結果５
     */
    public void setKEKKA05(String KEKKA05) {
        this.KEKKA05 = KEKKA05 == null ? null : KEKKA05.trim();
    }

    /**
     * 結果６
     * @return KEKKA06 結果６
     */
    public String getKEKKA06() {
        return KEKKA06;
    }

    /**
     * 結果６
     * @param KEKKA06 結果６
     */
    public void setKEKKA06(String KEKKA06) {
        this.KEKKA06 = KEKKA06 == null ? null : KEKKA06.trim();
    }

    /**
     * 結果７
     * @return KEKKA07 結果７
     */
    public String getKEKKA07() {
        return KEKKA07;
    }

    /**
     * 結果７
     * @param KEKKA07 結果７
     */
    public void setKEKKA07(String KEKKA07) {
        this.KEKKA07 = KEKKA07 == null ? null : KEKKA07.trim();
    }

    /**
     * 結果８
     * @return KEKKA08 結果８
     */
    public String getKEKKA08() {
        return KEKKA08;
    }

    /**
     * 結果８
     * @param KEKKA08 結果８
     */
    public void setKEKKA08(String KEKKA08) {
        this.KEKKA08 = KEKKA08 == null ? null : KEKKA08.trim();
    }

    /**
     * 結果９
     * @return KEKKA09 結果９
     */
    public String getKEKKA09() {
        return KEKKA09;
    }

    /**
     * 結果９
     * @param KEKKA09 結果９
     */
    public void setKEKKA09(String KEKKA09) {
        this.KEKKA09 = KEKKA09 == null ? null : KEKKA09.trim();
    }

    /**
     * 結果１０
     * @return KEKKA10 結果１０
     */
    public String getKEKKA10() {
        return KEKKA10;
    }

    /**
     * 結果１０
     * @param KEKKA10 結果１０
     */
    public void setKEKKA10(String KEKKA10) {
        this.KEKKA10 = KEKKA10 == null ? null : KEKKA10.trim();
    }

    /**
     * 時間１
     * @return TIME01 時間１
     */
    public String getTIME01() {
        return TIME01;
    }

    /**
     * 時間１
     * @param TIME01 時間１
     */
    public void setTIME01(String TIME01) {
        this.TIME01 = TIME01 == null ? null : TIME01.trim();
    }

    /**
     * 時間２
     * @return TIME02 時間２
     */
    public String getTIME02() {
        return TIME02;
    }

    /**
     * 時間２
     * @param TIME02 時間２
     */
    public void setTIME02(String TIME02) {
        this.TIME02 = TIME02 == null ? null : TIME02.trim();
    }

    /**
     * 時間３
     * @return TIME03 時間３
     */
    public String getTIME03() {
        return TIME03;
    }

    /**
     * 時間３
     * @param TIME03 時間３
     */
    public void setTIME03(String TIME03) {
        this.TIME03 = TIME03 == null ? null : TIME03.trim();
    }

    /**
     * 時間４
     * @return TIME04 時間４
     */
    public String getTIME04() {
        return TIME04;
    }

    /**
     * 時間４
     * @param TIME04 時間４
     */
    public void setTIME04(String TIME04) {
        this.TIME04 = TIME04 == null ? null : TIME04.trim();
    }

    /**
     * 時間５
     * @return TIME05 時間５
     */
    public String getTIME05() {
        return TIME05;
    }

    /**
     * 時間５
     * @param TIME05 時間５
     */
    public void setTIME05(String TIME05) {
        this.TIME05 = TIME05 == null ? null : TIME05.trim();
    }

    /**
     * 時間６
     * @return TIME06 時間６
     */
    public String getTIME06() {
        return TIME06;
    }

    /**
     * 時間６
     * @param TIME06 時間６
     */
    public void setTIME06(String TIME06) {
        this.TIME06 = TIME06 == null ? null : TIME06.trim();
    }

    /**
     * 時間７
     * @return TIME07 時間７
     */
    public String getTIME07() {
        return TIME07;
    }

    /**
     * 時間７
     * @param TIME07 時間７
     */
    public void setTIME07(String TIME07) {
        this.TIME07 = TIME07 == null ? null : TIME07.trim();
    }

    /**
     * 時間８
     * @return TIME08 時間８
     */
    public String getTIME08() {
        return TIME08;
    }

    /**
     * 時間８
     * @param TIME08 時間８
     */
    public void setTIME08(String TIME08) {
        this.TIME08 = TIME08 == null ? null : TIME08.trim();
    }

    /**
     * 時間９
     * @return TIME09 時間９
     */
    public String getTIME09() {
        return TIME09;
    }

    /**
     * 時間９
     * @param TIME09 時間９
     */
    public void setTIME09(String TIME09) {
        this.TIME09 = TIME09 == null ? null : TIME09.trim();
    }

    /**
     * 時間１０
     * @return TIME10 時間１０
     */
    public String getTIME10() {
        return TIME10;
    }

    /**
     * 時間１０
     * @param TIME10 時間１０
     */
    public void setTIME10(String TIME10) {
        this.TIME10 = TIME10 == null ? null : TIME10.trim();
    }

    /**
     * 時間１１
     * @return TIME11 時間１１
     */
    public String getTIME11() {
        return TIME11;
    }

    /**
     * 時間１１
     * @param TIME11 時間１１
     */
    public void setTIME11(String TIME11) {
        this.TIME11 = TIME11 == null ? null : TIME11.trim();
    }

    /**
     * 時間１２
     * @return TIME12 時間１２
     */
    public String getTIME12() {
        return TIME12;
    }

    /**
     * 時間１２
     * @param TIME12 時間１２
     */
    public void setTIME12(String TIME12) {
        this.TIME12 = TIME12 == null ? null : TIME12.trim();
    }

    /**
     * 時間１３
     * @return TIME13 時間１３
     */
    public String getTIME13() {
        return TIME13;
    }

    /**
     * 時間１３
     * @param TIME13 時間１３
     */
    public void setTIME13(String TIME13) {
        this.TIME13 = TIME13 == null ? null : TIME13.trim();
    }

    /**
     * 時間１４
     * @return TIME14 時間１４
     */
    public String getTIME14() {
        return TIME14;
    }

    /**
     * 時間１４
     * @param TIME14 時間１４
     */
    public void setTIME14(String TIME14) {
        this.TIME14 = TIME14 == null ? null : TIME14.trim();
    }

    /**
     * 時間１５
     * @return TIME15 時間１５
     */
    public String getTIME15() {
        return TIME15;
    }

    /**
     * 時間１５
     * @param TIME15 時間１５
     */
    public void setTIME15(String TIME15) {
        this.TIME15 = TIME15 == null ? null : TIME15.trim();
    }

    /**
     * 時間１６
     * @return TIME16 時間１６
     */
    public String getTIME16() {
        return TIME16;
    }

    /**
     * 時間１６
     * @param TIME16 時間１６
     */
    public void setTIME16(String TIME16) {
        this.TIME16 = TIME16 == null ? null : TIME16.trim();
    }

    /**
     * 時間１７
     * @return TIME17 時間１７
     */
    public String getTIME17() {
        return TIME17;
    }

    /**
     * 時間１７
     * @param TIME17 時間１７
     */
    public void setTIME17(String TIME17) {
        this.TIME17 = TIME17 == null ? null : TIME17.trim();
    }

    /**
     * 時間１８
     * @return TIME18 時間１８
     */
    public String getTIME18() {
        return TIME18;
    }

    /**
     * 時間１８
     * @param TIME18 時間１８
     */
    public void setTIME18(String TIME18) {
        this.TIME18 = TIME18 == null ? null : TIME18.trim();
    }

    /**
     * 時間１９
     * @return TIME19 時間１９
     */
    public String getTIME19() {
        return TIME19;
    }

    /**
     * 時間１９
     * @param TIME19 時間１９
     */
    public void setTIME19(String TIME19) {
        this.TIME19 = TIME19 == null ? null : TIME19.trim();
    }

    /**
     * 時間２０
     * @return TIME20 時間２０
     */
    public String getTIME20() {
        return TIME20;
    }

    /**
     * 時間２０
     * @param TIME20 時間２０
     */
    public void setTIME20(String TIME20) {
        this.TIME20 = TIME20 == null ? null : TIME20.trim();
    }

    /**
     * 時間２１
     * @return TIME21 時間２１
     */
    public String getTIME21() {
        return TIME21;
    }

    /**
     * 時間２１
     * @param TIME21 時間２１
     */
    public void setTIME21(String TIME21) {
        this.TIME21 = TIME21 == null ? null : TIME21.trim();
    }

    /**
     * 時間２２
     * @return TIME22 時間２２
     */
    public String getTIME22() {
        return TIME22;
    }

    /**
     * 時間２２
     * @param TIME22 時間２２
     */
    public void setTIME22(String TIME22) {
        this.TIME22 = TIME22 == null ? null : TIME22.trim();
    }

    /**
     * 時間２３
     * @return TIME23 時間２３
     */
    public String getTIME23() {
        return TIME23;
    }

    /**
     * 時間２３
     * @param TIME23 時間２３
     */
    public void setTIME23(String TIME23) {
        this.TIME23 = TIME23 == null ? null : TIME23.trim();
    }

    /**
     * 時間２４
     * @return TIME24 時間２４
     */
    public String getTIME24() {
        return TIME24;
    }

    /**
     * 時間２４
     * @param TIME24 時間２４
     */
    public void setTIME24(String TIME24) {
        this.TIME24 = TIME24 == null ? null : TIME24.trim();
    }

    /**
     * 時間２５
     * @return TIME25 時間２５
     */
    public String getTIME25() {
        return TIME25;
    }

    /**
     * 時間２５
     * @param TIME25 時間２５
     */
    public void setTIME25(String TIME25) {
        this.TIME25 = TIME25 == null ? null : TIME25.trim();
    }

    /**
     * 時間２６
     * @return TIME26 時間２６
     */
    public String getTIME26() {
        return TIME26;
    }

    /**
     * 時間２６
     * @param TIME26 時間２６
     */
    public void setTIME26(String TIME26) {
        this.TIME26 = TIME26 == null ? null : TIME26.trim();
    }

    /**
     * 時間２７
     * @return TIME27 時間２７
     */
    public String getTIME27() {
        return TIME27;
    }

    /**
     * 時間２７
     * @param TIME27 時間２７
     */
    public void setTIME27(String TIME27) {
        this.TIME27 = TIME27 == null ? null : TIME27.trim();
    }

    /**
     * 時間２８
     * @return TIME28 時間２８
     */
    public String getTIME28() {
        return TIME28;
    }

    /**
     * 時間２８
     * @param TIME28 時間２８
     */
    public void setTIME28(String TIME28) {
        this.TIME28 = TIME28 == null ? null : TIME28.trim();
    }

    /**
     * 時間２９
     * @return TIME29 時間２９
     */
    public String getTIME29() {
        return TIME29;
    }

    /**
     * 時間２９
     * @param TIME29 時間２９
     */
    public void setTIME29(String TIME29) {
        this.TIME29 = TIME29 == null ? null : TIME29.trim();
    }

    /**
     * 時間３０
     * @return TIME30 時間３０
     */
    public String getTIME30() {
        return TIME30;
    }

    /**
     * 時間３０
     * @param TIME30 時間３０
     */
    public void setTIME30(String TIME30) {
        this.TIME30 = TIME30 == null ? null : TIME30.trim();
    }

    /**
     * 時間３１
     * @return TIME31 時間３１
     */
    public String getTIME31() {
        return TIME31;
    }

    /**
     * 時間３１
     * @param TIME31 時間３１
     */
    public void setTIME31(String TIME31) {
        this.TIME31 = TIME31 == null ? null : TIME31.trim();
    }

    /**
     * 時間３２
     * @return TIME32 時間３２
     */
    public String getTIME32() {
        return TIME32;
    }

    /**
     * 時間３２
     * @param TIME32 時間３２
     */
    public void setTIME32(String TIME32) {
        this.TIME32 = TIME32 == null ? null : TIME32.trim();
    }

    /**
     * 時間３３
     * @return TIME33 時間３３
     */
    public String getTIME33() {
        return TIME33;
    }

    /**
     * 時間３３
     * @param TIME33 時間３３
     */
    public void setTIME33(String TIME33) {
        this.TIME33 = TIME33 == null ? null : TIME33.trim();
    }

    /**
     * 時間３４
     * @return TIME34 時間３４
     */
    public String getTIME34() {
        return TIME34;
    }

    /**
     * 時間３４
     * @param TIME34 時間３４
     */
    public void setTIME34(String TIME34) {
        this.TIME34 = TIME34 == null ? null : TIME34.trim();
    }

    /**
     * 時間３５
     * @return TIME35 時間３５
     */
    public String getTIME35() {
        return TIME35;
    }

    /**
     * 時間３５
     * @param TIME35 時間３５
     */
    public void setTIME35(String TIME35) {
        this.TIME35 = TIME35 == null ? null : TIME35.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}