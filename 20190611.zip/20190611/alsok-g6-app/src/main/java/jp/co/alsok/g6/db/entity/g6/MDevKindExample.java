package jp.co.alsok.g6.db.entity.g6;

import java.util.ArrayList;
import java.util.List;

public class MDevKindExample {
    /**
     * M_DEV_KIND
     */
    protected String orderByClause;

    /**
     * M_DEV_KIND
     */
    protected boolean distinct;

    /**
     * M_DEV_KIND
     */
    protected List<Criteria> oredCriteria;

    /**
     *
     * @mbg.generated
     */
    public MDevKindExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    /**
     *
     * @mbg.generated
     */
    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public String getOrderByClause() {
        return orderByClause;
    }

    /**
     *
     * @mbg.generated
     */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public boolean isDistinct() {
        return distinct;
    }

    /**
     *
     * @mbg.generated
     */
    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    /**
     *
     * @mbg.generated
     */
    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * M_DEV_KIND null
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andDEV_KIND_CDIsNull() {
            addCriterion("DEV_KIND_CD is null");
            return (Criteria) this;
        }

        public Criteria andDEV_KIND_CDIsNotNull() {
            addCriterion("DEV_KIND_CD is not null");
            return (Criteria) this;
        }

        public Criteria andDEV_KIND_CDEqualTo(String value) {
            addCriterion("DEV_KIND_CD =", value, "DEV_KIND_CD");
            return (Criteria) this;
        }

        public Criteria andDEV_KIND_CDNotEqualTo(String value) {
            addCriterion("DEV_KIND_CD <>", value, "DEV_KIND_CD");
            return (Criteria) this;
        }

        public Criteria andDEV_KIND_CDGreaterThan(String value) {
            addCriterion("DEV_KIND_CD >", value, "DEV_KIND_CD");
            return (Criteria) this;
        }

        public Criteria andDEV_KIND_CDGreaterThanOrEqualTo(String value) {
            addCriterion("DEV_KIND_CD >=", value, "DEV_KIND_CD");
            return (Criteria) this;
        }

        public Criteria andDEV_KIND_CDLessThan(String value) {
            addCriterion("DEV_KIND_CD <", value, "DEV_KIND_CD");
            return (Criteria) this;
        }

        public Criteria andDEV_KIND_CDLessThanOrEqualTo(String value) {
            addCriterion("DEV_KIND_CD <=", value, "DEV_KIND_CD");
            return (Criteria) this;
        }

        public Criteria andDEV_KIND_CDLike(String value) {
            addCriterion("DEV_KIND_CD like", value, "DEV_KIND_CD");
            return (Criteria) this;
        }

        public Criteria andDEV_KIND_CDNotLike(String value) {
            addCriterion("DEV_KIND_CD not like", value, "DEV_KIND_CD");
            return (Criteria) this;
        }

        public Criteria andDEV_KIND_CDIn(List<String> values) {
            addCriterion("DEV_KIND_CD in", values, "DEV_KIND_CD");
            return (Criteria) this;
        }

        public Criteria andDEV_KIND_CDNotIn(List<String> values) {
            addCriterion("DEV_KIND_CD not in", values, "DEV_KIND_CD");
            return (Criteria) this;
        }

        public Criteria andDEV_KIND_CDBetween(String value1, String value2) {
            addCriterion("DEV_KIND_CD between", value1, value2, "DEV_KIND_CD");
            return (Criteria) this;
        }

        public Criteria andDEV_KIND_CDNotBetween(String value1, String value2) {
            addCriterion("DEV_KIND_CD not between", value1, value2, "DEV_KIND_CD");
            return (Criteria) this;
        }

        public Criteria andKIND_CDIsNull() {
            addCriterion("KIND_CD is null");
            return (Criteria) this;
        }

        public Criteria andKIND_CDIsNotNull() {
            addCriterion("KIND_CD is not null");
            return (Criteria) this;
        }

        public Criteria andKIND_CDEqualTo(String value) {
            addCriterion("KIND_CD =", value, "KIND_CD");
            return (Criteria) this;
        }

        public Criteria andKIND_CDNotEqualTo(String value) {
            addCriterion("KIND_CD <>", value, "KIND_CD");
            return (Criteria) this;
        }

        public Criteria andKIND_CDGreaterThan(String value) {
            addCriterion("KIND_CD >", value, "KIND_CD");
            return (Criteria) this;
        }

        public Criteria andKIND_CDGreaterThanOrEqualTo(String value) {
            addCriterion("KIND_CD >=", value, "KIND_CD");
            return (Criteria) this;
        }

        public Criteria andKIND_CDLessThan(String value) {
            addCriterion("KIND_CD <", value, "KIND_CD");
            return (Criteria) this;
        }

        public Criteria andKIND_CDLessThanOrEqualTo(String value) {
            addCriterion("KIND_CD <=", value, "KIND_CD");
            return (Criteria) this;
        }

        public Criteria andKIND_CDLike(String value) {
            addCriterion("KIND_CD like", value, "KIND_CD");
            return (Criteria) this;
        }

        public Criteria andKIND_CDNotLike(String value) {
            addCriterion("KIND_CD not like", value, "KIND_CD");
            return (Criteria) this;
        }

        public Criteria andKIND_CDIn(List<String> values) {
            addCriterion("KIND_CD in", values, "KIND_CD");
            return (Criteria) this;
        }

        public Criteria andKIND_CDNotIn(List<String> values) {
            addCriterion("KIND_CD not in", values, "KIND_CD");
            return (Criteria) this;
        }

        public Criteria andKIND_CDBetween(String value1, String value2) {
            addCriterion("KIND_CD between", value1, value2, "KIND_CD");
            return (Criteria) this;
        }

        public Criteria andKIND_CDNotBetween(String value1, String value2) {
            addCriterion("KIND_CD not between", value1, value2, "KIND_CD");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPEIsNull() {
            addCriterion("MODEL_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPEIsNotNull() {
            addCriterion("MODEL_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPEEqualTo(String value) {
            addCriterion("MODEL_TYPE =", value, "MODEL_TYPE");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPENotEqualTo(String value) {
            addCriterion("MODEL_TYPE <>", value, "MODEL_TYPE");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPEGreaterThan(String value) {
            addCriterion("MODEL_TYPE >", value, "MODEL_TYPE");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPEGreaterThanOrEqualTo(String value) {
            addCriterion("MODEL_TYPE >=", value, "MODEL_TYPE");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPELessThan(String value) {
            addCriterion("MODEL_TYPE <", value, "MODEL_TYPE");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPELessThanOrEqualTo(String value) {
            addCriterion("MODEL_TYPE <=", value, "MODEL_TYPE");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPELike(String value) {
            addCriterion("MODEL_TYPE like", value, "MODEL_TYPE");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPENotLike(String value) {
            addCriterion("MODEL_TYPE not like", value, "MODEL_TYPE");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPEIn(List<String> values) {
            addCriterion("MODEL_TYPE in", values, "MODEL_TYPE");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPENotIn(List<String> values) {
            addCriterion("MODEL_TYPE not in", values, "MODEL_TYPE");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPEBetween(String value1, String value2) {
            addCriterion("MODEL_TYPE between", value1, value2, "MODEL_TYPE");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPENotBetween(String value1, String value2) {
            addCriterion("MODEL_TYPE not between", value1, value2, "MODEL_TYPE");
            return (Criteria) this;
        }

        public Criteria andFW_FLGIsNull() {
            addCriterion("FW_FLG is null");
            return (Criteria) this;
        }

        public Criteria andFW_FLGIsNotNull() {
            addCriterion("FW_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andFW_FLGEqualTo(String value) {
            addCriterion("FW_FLG =", value, "FW_FLG");
            return (Criteria) this;
        }

        public Criteria andFW_FLGNotEqualTo(String value) {
            addCriterion("FW_FLG <>", value, "FW_FLG");
            return (Criteria) this;
        }

        public Criteria andFW_FLGGreaterThan(String value) {
            addCriterion("FW_FLG >", value, "FW_FLG");
            return (Criteria) this;
        }

        public Criteria andFW_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("FW_FLG >=", value, "FW_FLG");
            return (Criteria) this;
        }

        public Criteria andFW_FLGLessThan(String value) {
            addCriterion("FW_FLG <", value, "FW_FLG");
            return (Criteria) this;
        }

        public Criteria andFW_FLGLessThanOrEqualTo(String value) {
            addCriterion("FW_FLG <=", value, "FW_FLG");
            return (Criteria) this;
        }

        public Criteria andFW_FLGLike(String value) {
            addCriterion("FW_FLG like", value, "FW_FLG");
            return (Criteria) this;
        }

        public Criteria andFW_FLGNotLike(String value) {
            addCriterion("FW_FLG not like", value, "FW_FLG");
            return (Criteria) this;
        }

        public Criteria andFW_FLGIn(List<String> values) {
            addCriterion("FW_FLG in", values, "FW_FLG");
            return (Criteria) this;
        }

        public Criteria andFW_FLGNotIn(List<String> values) {
            addCriterion("FW_FLG not in", values, "FW_FLG");
            return (Criteria) this;
        }

        public Criteria andFW_FLGBetween(String value1, String value2) {
            addCriterion("FW_FLG between", value1, value2, "FW_FLG");
            return (Criteria) this;
        }

        public Criteria andFW_FLGNotBetween(String value1, String value2) {
            addCriterion("FW_FLG not between", value1, value2, "FW_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_FLGIsNull() {
            addCriterion("SD_FLG is null");
            return (Criteria) this;
        }

        public Criteria andSD_FLGIsNotNull() {
            addCriterion("SD_FLG is not null");
            return (Criteria) this;
        }

        public Criteria andSD_FLGEqualTo(String value) {
            addCriterion("SD_FLG =", value, "SD_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_FLGNotEqualTo(String value) {
            addCriterion("SD_FLG <>", value, "SD_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_FLGGreaterThan(String value) {
            addCriterion("SD_FLG >", value, "SD_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_FLGGreaterThanOrEqualTo(String value) {
            addCriterion("SD_FLG >=", value, "SD_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_FLGLessThan(String value) {
            addCriterion("SD_FLG <", value, "SD_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_FLGLessThanOrEqualTo(String value) {
            addCriterion("SD_FLG <=", value, "SD_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_FLGLike(String value) {
            addCriterion("SD_FLG like", value, "SD_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_FLGNotLike(String value) {
            addCriterion("SD_FLG not like", value, "SD_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_FLGIn(List<String> values) {
            addCriterion("SD_FLG in", values, "SD_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_FLGNotIn(List<String> values) {
            addCriterion("SD_FLG not in", values, "SD_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_FLGBetween(String value1, String value2) {
            addCriterion("SD_FLG between", value1, value2, "SD_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_FLGNotBetween(String value1, String value2) {
            addCriterion("SD_FLG not between", value1, value2, "SD_FLG");
            return (Criteria) this;
        }

        public Criteria andID_ICONIsNull() {
            addCriterion("ID_ICON is null");
            return (Criteria) this;
        }

        public Criteria andID_ICONIsNotNull() {
            addCriterion("ID_ICON is not null");
            return (Criteria) this;
        }

        public Criteria andID_ICONEqualTo(String value) {
            addCriterion("ID_ICON =", value, "ID_ICON");
            return (Criteria) this;
        }

        public Criteria andID_ICONNotEqualTo(String value) {
            addCriterion("ID_ICON <>", value, "ID_ICON");
            return (Criteria) this;
        }

        public Criteria andID_ICONGreaterThan(String value) {
            addCriterion("ID_ICON >", value, "ID_ICON");
            return (Criteria) this;
        }

        public Criteria andID_ICONGreaterThanOrEqualTo(String value) {
            addCriterion("ID_ICON >=", value, "ID_ICON");
            return (Criteria) this;
        }

        public Criteria andID_ICONLessThan(String value) {
            addCriterion("ID_ICON <", value, "ID_ICON");
            return (Criteria) this;
        }

        public Criteria andID_ICONLessThanOrEqualTo(String value) {
            addCriterion("ID_ICON <=", value, "ID_ICON");
            return (Criteria) this;
        }

        public Criteria andID_ICONLike(String value) {
            addCriterion("ID_ICON like", value, "ID_ICON");
            return (Criteria) this;
        }

        public Criteria andID_ICONNotLike(String value) {
            addCriterion("ID_ICON not like", value, "ID_ICON");
            return (Criteria) this;
        }

        public Criteria andID_ICONIn(List<String> values) {
            addCriterion("ID_ICON in", values, "ID_ICON");
            return (Criteria) this;
        }

        public Criteria andID_ICONNotIn(List<String> values) {
            addCriterion("ID_ICON not in", values, "ID_ICON");
            return (Criteria) this;
        }

        public Criteria andID_ICONBetween(String value1, String value2) {
            addCriterion("ID_ICON between", value1, value2, "ID_ICON");
            return (Criteria) this;
        }

        public Criteria andID_ICONNotBetween(String value1, String value2) {
            addCriterion("ID_ICON not between", value1, value2, "ID_ICON");
            return (Criteria) this;
        }

        public Criteria andDEV_KIND_CDLikeInsensitive(String value) {
            addCriterion("upper(DEV_KIND_CD) like", value.toUpperCase(), "DEV_KIND_CD");
            return (Criteria) this;
        }

        public Criteria andKIND_CDLikeInsensitive(String value) {
            addCriterion("upper(KIND_CD) like", value.toUpperCase(), "KIND_CD");
            return (Criteria) this;
        }

        public Criteria andMODEL_TYPELikeInsensitive(String value) {
            addCriterion("upper(MODEL_TYPE) like", value.toUpperCase(), "MODEL_TYPE");
            return (Criteria) this;
        }

        public Criteria andFW_FLGLikeInsensitive(String value) {
            addCriterion("upper(FW_FLG) like", value.toUpperCase(), "FW_FLG");
            return (Criteria) this;
        }

        public Criteria andSD_FLGLikeInsensitive(String value) {
            addCriterion("upper(SD_FLG) like", value.toUpperCase(), "SD_FLG");
            return (Criteria) this;
        }

        public Criteria andID_ICONLikeInsensitive(String value) {
            addCriterion("upper(ID_ICON) like", value.toUpperCase(), "ID_ICON");
            return (Criteria) this;
        }
    }

    /**
     * M_DEV_KIND
     */
    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * M_DEV_KIND null
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}