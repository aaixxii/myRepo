package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class CEigyoSoshiki extends CEigyoSoshikiKey implements Serializable {
    /**
     * 適用開始年月日
     */
    private String TEKIYO_KAISHI_YMD;

    /**
     * 適用終了年月日
     */
    private String TEKIYO_SHURYO_YMD;

    /**
     * 組織名称
     */
    private String SOSHIKI_NM;

    /**
     * 組織略称
     */
    private String SOSHIKI_RNM;

    /**
     * 上位組織コード
     */
    private String JOI_SOSHIKI_CD;

    /**
     * 支社部組織コード
     */
    private String SHISHABU_SOSHIKI_CD;

    /**
     * 共通費配賦元対象本社部門組織フラグ
     */
    private String KTH_HIFMT_TIS_HNS_BMN_SSK_FLG;

    /**
     * 共通費配賦先対象全社セグメントフラグ
     */
    private String KTH_HIFSK_TIS_ZNS_SEGMENT_FLG;

    /**
     * 研究開発部門組織区分
     */
    private String KNKY_KIHTS_BMN_SSHK_KBN;

    /**
     * 費用負担部門組織コード
     */
    private String HIYO_FUTAN_BUMON_SOSHIKI_CD;

    /**
     * 経費一次承認部門組織コード
     */
    private String KIH_ICHJ_SHNN_BMN_SSHK_CD;

    /**
     * 支社組織コード
     */
    private String SHISHA_SOSHIKI_CD;

    /**
     * 地域本部組織コード
     */
    private String CHIIKI_HOMBU_SOSHIKI_CD;

    /**
     * 事業本部参照可フラグ
     */
    private String JIGYO_HOMBU_SANSHOKA_FLG;

    /**
     * 全社参照可フラグ
     */
    private String ZENSHA_SANSHOKA_FLG;

    /**
     * 支社部コード（人事）
     */
    private String SHISHABU_CD;

    /**
     * 組織ランク番号
     */
    private Integer SOSHIKI_RANK_NO;

    /**
     * ランク０１組織コード
     */
    private String RANK_01_SOSHIKI_CD;

    /**
     * ランク０２組織コード
     */
    private String RANK_02_SOSHIKI_CD;

    /**
     * ランク０３組織コード
     */
    private String RANK_03_SOSHIKI_CD;

    /**
     * ランク０４組織コード
     */
    private String RANK_04_SOSHIKI_CD;

    /**
     * ランク０５組織コード
     */
    private String RANK_05_SOSHIKI_CD;

    /**
     * ランク０６組織コード
     */
    private String RANK_06_SOSHIKI_CD;

    /**
     * ランク０７組織コード
     */
    private String RANK_07_SOSHIKI_CD;

    /**
     * ランク０８組織コード
     */
    private String RANK_08_SOSHIKI_CD;

    /**
     * ランク０９組織コード
     */
    private String RANK_09_SOSHIKI_CD;

    /**
     * ランク１０組織コード
     */
    private String RANK_10_SOSHIKI_CD;

    /**
     * ランク１１組織コード
     */
    private String RANK_11_SOSHIKI_CD;

    /**
     * ランク１２組織コード
     */
    private String RANK_12_SOSHIKI_CD;

    /**
     * ランク１３組織コード
     */
    private String RANK_13_SOSHIKI_CD;

    /**
     * ランク１４組織コード
     */
    private String RANK_14_SOSHIKI_CD;

    /**
     * ランク１５組織コード
     */
    private String RANK_15_SOSHIKI_CD;

    /**
     * ランク１６組織コード
     */
    private String RANK_16_SOSHIKI_CD;

    /**
     * ランク１７組織コード
     */
    private String RANK_17_SOSHIKI_CD;

    /**
     * ランク１８組織コード
     */
    private String RANK_18_SOSHIKI_CD;

    /**
     * ランク１９組織コード
     */
    private String RANK_19_SOSHIKI_CD;

    /**
     * ランク２０組織コード
     */
    private String RANK_20_SOSHIKI_CD;

    /**
     * ランク０１組織名称
     */
    private String RANK_01_SOSHIKI_NM;

    /**
     * ランク０２組織名称
     */
    private String RANK_02_SOSHIKI_NM;

    /**
     * ランク０３組織名称
     */
    private String RANK_03_SOSHIKI_NM;

    /**
     * ランク０４組織名称
     */
    private String RANK_04_SOSHIKI_NM;

    /**
     * ランク０５組織名称
     */
    private String RANK_05_SOSHIKI_NM;

    /**
     * ランク０６組織名称
     */
    private String RANK_06_SOSHIKI_NM;

    /**
     * ランク０７組織名称
     */
    private String RANK_07_SOSHIKI_NM;

    /**
     * ランク０８組織名称
     */
    private String RANK_08_SOSHIKI_NM;

    /**
     * ランク０９組織名称
     */
    private String RANK_09_SOSHIKI_NM;

    /**
     * ランク１０組織名称
     */
    private String RANK_10_SOSHIKI_NM;

    /**
     * ランク１１組織名称
     */
    private String RANK_11_SOSHIKI_NM;

    /**
     * ランク１２組織名称
     */
    private String RANK_12_SOSHIKI_NM;

    /**
     * ランク１３組織名称
     */
    private String RANK_13_SOSHIKI_NM;

    /**
     * ランク１４組織名称
     */
    private String RANK_14_SOSHIKI_NM;

    /**
     * ランク１５組織名称
     */
    private String RANK_15_SOSHIKI_NM;

    /**
     * ランク１６組織名称
     */
    private String RANK_16_SOSHIKI_NM;

    /**
     * ランク１７組織名称
     */
    private String RANK_17_SOSHIKI_NM;

    /**
     * ランク１８組織名称
     */
    private String RANK_18_SOSHIKI_NM;

    /**
     * ランク１９組織名称
     */
    private String RANK_19_SOSHIKI_NM;

    /**
     * ランク２０組織名称
     */
    private String RANK_20_SOSHIKI_NM;

    /**
     * 予備項目01
     */
    private String YOBI_KOMOKU_01;

    /**
     * 予備項目02
     */
    private String YOBI_KOMOKU_02;

    /**
     * 予備項目03
     */
    private String YOBI_KOMOKU_03;

    /**
     * 予備項目04
     */
    private String YOBI_KOMOKU_04;

    /**
     * 予備項目05
     */
    private String YOBI_KOMOKU_05;

    /**
     * 予備項目06
     */
    private String YOBI_KOMOKU_06;

    /**
     * 予備項目07
     */
    private String YOBI_KOMOKU_07;

    /**
     * 予備項目08
     */
    private String YOBI_KOMOKU_08;

    /**
     * 予備項目09
     */
    private String YOBI_KOMOKU_09;

    /**
     * 予備項目10
     */
    private String YOBI_KOMOKU_10;

    /**
     * 登録タイムスタンプ
     */
    private Date REGST_TMSTMP;

    /**
     * 登録者会社コード
     */
    private String REGSTR_CO_CD;

    /**
     * 登録者組織コード
     */
    private String REGSTR_SOSHIKI_CD;

    /**
     * 登録者社員番号
     */
    private String REGSTR_EMP_NO;

    /**
     * 登録画面ＩＤ
     */
    private String REGST_GAMEN_ID;

    /**
     * 登録プログラムＩＤ
     */
    private String REGST_PGM_ID;

    /**
     * 更新タイムスタンプ
     */
    private Date UPD_TMSTMP;

    /**
     * 更新者会社コード
     */
    private String UPDTR_CO_CD;

    /**
     * 更新者組織コード
     */
    private String UPDTR_SOSHIKI_CD;

    /**
     * 更新者社員番号
     */
    private String UPDTR_EMP_NO;

    /**
     * 更新画面ＩＤ
     */
    private String UPD_GAMEN_ID;

    /**
     * 更新プログラムＩＤ
     */
    private String UPD_PGM_ID;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * C_EIGYO_SOSHIKI
     */
    private static final long serialVersionUID = 1L;

    /**
     * 適用開始年月日
     * @return TEKIYO_KAISHI_YMD 適用開始年月日
     */
    public String getTEKIYO_KAISHI_YMD() {
        return TEKIYO_KAISHI_YMD;
    }

    /**
     * 適用開始年月日
     * @param TEKIYO_KAISHI_YMD 適用開始年月日
     */
    public void setTEKIYO_KAISHI_YMD(String TEKIYO_KAISHI_YMD) {
        this.TEKIYO_KAISHI_YMD = TEKIYO_KAISHI_YMD == null ? null : TEKIYO_KAISHI_YMD.trim();
    }

    /**
     * 適用終了年月日
     * @return TEKIYO_SHURYO_YMD 適用終了年月日
     */
    public String getTEKIYO_SHURYO_YMD() {
        return TEKIYO_SHURYO_YMD;
    }

    /**
     * 適用終了年月日
     * @param TEKIYO_SHURYO_YMD 適用終了年月日
     */
    public void setTEKIYO_SHURYO_YMD(String TEKIYO_SHURYO_YMD) {
        this.TEKIYO_SHURYO_YMD = TEKIYO_SHURYO_YMD == null ? null : TEKIYO_SHURYO_YMD.trim();
    }

    /**
     * 組織名称
     * @return SOSHIKI_NM 組織名称
     */
    public String getSOSHIKI_NM() {
        return SOSHIKI_NM;
    }

    /**
     * 組織名称
     * @param SOSHIKI_NM 組織名称
     */
    public void setSOSHIKI_NM(String SOSHIKI_NM) {
        this.SOSHIKI_NM = SOSHIKI_NM == null ? null : SOSHIKI_NM.trim();
    }

    /**
     * 組織略称
     * @return SOSHIKI_RNM 組織略称
     */
    public String getSOSHIKI_RNM() {
        return SOSHIKI_RNM;
    }

    /**
     * 組織略称
     * @param SOSHIKI_RNM 組織略称
     */
    public void setSOSHIKI_RNM(String SOSHIKI_RNM) {
        this.SOSHIKI_RNM = SOSHIKI_RNM == null ? null : SOSHIKI_RNM.trim();
    }

    /**
     * 上位組織コード
     * @return JOI_SOSHIKI_CD 上位組織コード
     */
    public String getJOI_SOSHIKI_CD() {
        return JOI_SOSHIKI_CD;
    }

    /**
     * 上位組織コード
     * @param JOI_SOSHIKI_CD 上位組織コード
     */
    public void setJOI_SOSHIKI_CD(String JOI_SOSHIKI_CD) {
        this.JOI_SOSHIKI_CD = JOI_SOSHIKI_CD == null ? null : JOI_SOSHIKI_CD.trim();
    }

    /**
     * 支社部組織コード
     * @return SHISHABU_SOSHIKI_CD 支社部組織コード
     */
    public String getSHISHABU_SOSHIKI_CD() {
        return SHISHABU_SOSHIKI_CD;
    }

    /**
     * 支社部組織コード
     * @param SHISHABU_SOSHIKI_CD 支社部組織コード
     */
    public void setSHISHABU_SOSHIKI_CD(String SHISHABU_SOSHIKI_CD) {
        this.SHISHABU_SOSHIKI_CD = SHISHABU_SOSHIKI_CD == null ? null : SHISHABU_SOSHIKI_CD.trim();
    }

    /**
     * 共通費配賦元対象本社部門組織フラグ
     * @return KTH_HIFMT_TIS_HNS_BMN_SSK_FLG 共通費配賦元対象本社部門組織フラグ
     */
    public String getKTH_HIFMT_TIS_HNS_BMN_SSK_FLG() {
        return KTH_HIFMT_TIS_HNS_BMN_SSK_FLG;
    }

    /**
     * 共通費配賦元対象本社部門組織フラグ
     * @param KTH_HIFMT_TIS_HNS_BMN_SSK_FLG 共通費配賦元対象本社部門組織フラグ
     */
    public void setKTH_HIFMT_TIS_HNS_BMN_SSK_FLG(String KTH_HIFMT_TIS_HNS_BMN_SSK_FLG) {
        this.KTH_HIFMT_TIS_HNS_BMN_SSK_FLG = KTH_HIFMT_TIS_HNS_BMN_SSK_FLG == null ? null : KTH_HIFMT_TIS_HNS_BMN_SSK_FLG.trim();
    }

    /**
     * 共通費配賦先対象全社セグメントフラグ
     * @return KTH_HIFSK_TIS_ZNS_SEGMENT_FLG 共通費配賦先対象全社セグメントフラグ
     */
    public String getKTH_HIFSK_TIS_ZNS_SEGMENT_FLG() {
        return KTH_HIFSK_TIS_ZNS_SEGMENT_FLG;
    }

    /**
     * 共通費配賦先対象全社セグメントフラグ
     * @param KTH_HIFSK_TIS_ZNS_SEGMENT_FLG 共通費配賦先対象全社セグメントフラグ
     */
    public void setKTH_HIFSK_TIS_ZNS_SEGMENT_FLG(String KTH_HIFSK_TIS_ZNS_SEGMENT_FLG) {
        this.KTH_HIFSK_TIS_ZNS_SEGMENT_FLG = KTH_HIFSK_TIS_ZNS_SEGMENT_FLG == null ? null : KTH_HIFSK_TIS_ZNS_SEGMENT_FLG.trim();
    }

    /**
     * 研究開発部門組織区分
     * @return KNKY_KIHTS_BMN_SSHK_KBN 研究開発部門組織区分
     */
    public String getKNKY_KIHTS_BMN_SSHK_KBN() {
        return KNKY_KIHTS_BMN_SSHK_KBN;
    }

    /**
     * 研究開発部門組織区分
     * @param KNKY_KIHTS_BMN_SSHK_KBN 研究開発部門組織区分
     */
    public void setKNKY_KIHTS_BMN_SSHK_KBN(String KNKY_KIHTS_BMN_SSHK_KBN) {
        this.KNKY_KIHTS_BMN_SSHK_KBN = KNKY_KIHTS_BMN_SSHK_KBN == null ? null : KNKY_KIHTS_BMN_SSHK_KBN.trim();
    }

    /**
     * 費用負担部門組織コード
     * @return HIYO_FUTAN_BUMON_SOSHIKI_CD 費用負担部門組織コード
     */
    public String getHIYO_FUTAN_BUMON_SOSHIKI_CD() {
        return HIYO_FUTAN_BUMON_SOSHIKI_CD;
    }

    /**
     * 費用負担部門組織コード
     * @param HIYO_FUTAN_BUMON_SOSHIKI_CD 費用負担部門組織コード
     */
    public void setHIYO_FUTAN_BUMON_SOSHIKI_CD(String HIYO_FUTAN_BUMON_SOSHIKI_CD) {
        this.HIYO_FUTAN_BUMON_SOSHIKI_CD = HIYO_FUTAN_BUMON_SOSHIKI_CD == null ? null : HIYO_FUTAN_BUMON_SOSHIKI_CD.trim();
    }

    /**
     * 経費一次承認部門組織コード
     * @return KIH_ICHJ_SHNN_BMN_SSHK_CD 経費一次承認部門組織コード
     */
    public String getKIH_ICHJ_SHNN_BMN_SSHK_CD() {
        return KIH_ICHJ_SHNN_BMN_SSHK_CD;
    }

    /**
     * 経費一次承認部門組織コード
     * @param KIH_ICHJ_SHNN_BMN_SSHK_CD 経費一次承認部門組織コード
     */
    public void setKIH_ICHJ_SHNN_BMN_SSHK_CD(String KIH_ICHJ_SHNN_BMN_SSHK_CD) {
        this.KIH_ICHJ_SHNN_BMN_SSHK_CD = KIH_ICHJ_SHNN_BMN_SSHK_CD == null ? null : KIH_ICHJ_SHNN_BMN_SSHK_CD.trim();
    }

    /**
     * 支社組織コード
     * @return SHISHA_SOSHIKI_CD 支社組織コード
     */
    public String getSHISHA_SOSHIKI_CD() {
        return SHISHA_SOSHIKI_CD;
    }

    /**
     * 支社組織コード
     * @param SHISHA_SOSHIKI_CD 支社組織コード
     */
    public void setSHISHA_SOSHIKI_CD(String SHISHA_SOSHIKI_CD) {
        this.SHISHA_SOSHIKI_CD = SHISHA_SOSHIKI_CD == null ? null : SHISHA_SOSHIKI_CD.trim();
    }

    /**
     * 地域本部組織コード
     * @return CHIIKI_HOMBU_SOSHIKI_CD 地域本部組織コード
     */
    public String getCHIIKI_HOMBU_SOSHIKI_CD() {
        return CHIIKI_HOMBU_SOSHIKI_CD;
    }

    /**
     * 地域本部組織コード
     * @param CHIIKI_HOMBU_SOSHIKI_CD 地域本部組織コード
     */
    public void setCHIIKI_HOMBU_SOSHIKI_CD(String CHIIKI_HOMBU_SOSHIKI_CD) {
        this.CHIIKI_HOMBU_SOSHIKI_CD = CHIIKI_HOMBU_SOSHIKI_CD == null ? null : CHIIKI_HOMBU_SOSHIKI_CD.trim();
    }

    /**
     * 事業本部参照可フラグ
     * @return JIGYO_HOMBU_SANSHOKA_FLG 事業本部参照可フラグ
     */
    public String getJIGYO_HOMBU_SANSHOKA_FLG() {
        return JIGYO_HOMBU_SANSHOKA_FLG;
    }

    /**
     * 事業本部参照可フラグ
     * @param JIGYO_HOMBU_SANSHOKA_FLG 事業本部参照可フラグ
     */
    public void setJIGYO_HOMBU_SANSHOKA_FLG(String JIGYO_HOMBU_SANSHOKA_FLG) {
        this.JIGYO_HOMBU_SANSHOKA_FLG = JIGYO_HOMBU_SANSHOKA_FLG == null ? null : JIGYO_HOMBU_SANSHOKA_FLG.trim();
    }

    /**
     * 全社参照可フラグ
     * @return ZENSHA_SANSHOKA_FLG 全社参照可フラグ
     */
    public String getZENSHA_SANSHOKA_FLG() {
        return ZENSHA_SANSHOKA_FLG;
    }

    /**
     * 全社参照可フラグ
     * @param ZENSHA_SANSHOKA_FLG 全社参照可フラグ
     */
    public void setZENSHA_SANSHOKA_FLG(String ZENSHA_SANSHOKA_FLG) {
        this.ZENSHA_SANSHOKA_FLG = ZENSHA_SANSHOKA_FLG == null ? null : ZENSHA_SANSHOKA_FLG.trim();
    }

    /**
     * 支社部コード（人事）
     * @return SHISHABU_CD 支社部コード（人事）
     */
    public String getSHISHABU_CD() {
        return SHISHABU_CD;
    }

    /**
     * 支社部コード（人事）
     * @param SHISHABU_CD 支社部コード（人事）
     */
    public void setSHISHABU_CD(String SHISHABU_CD) {
        this.SHISHABU_CD = SHISHABU_CD == null ? null : SHISHABU_CD.trim();
    }

    /**
     * 組織ランク番号
     * @return SOSHIKI_RANK_NO 組織ランク番号
     */
    public Integer getSOSHIKI_RANK_NO() {
        return SOSHIKI_RANK_NO;
    }

    /**
     * 組織ランク番号
     * @param SOSHIKI_RANK_NO 組織ランク番号
     */
    public void setSOSHIKI_RANK_NO(Integer SOSHIKI_RANK_NO) {
        this.SOSHIKI_RANK_NO = SOSHIKI_RANK_NO;
    }

    /**
     * ランク０１組織コード
     * @return RANK_01_SOSHIKI_CD ランク０１組織コード
     */
    public String getRANK_01_SOSHIKI_CD() {
        return RANK_01_SOSHIKI_CD;
    }

    /**
     * ランク０１組織コード
     * @param RANK_01_SOSHIKI_CD ランク０１組織コード
     */
    public void setRANK_01_SOSHIKI_CD(String RANK_01_SOSHIKI_CD) {
        this.RANK_01_SOSHIKI_CD = RANK_01_SOSHIKI_CD == null ? null : RANK_01_SOSHIKI_CD.trim();
    }

    /**
     * ランク０２組織コード
     * @return RANK_02_SOSHIKI_CD ランク０２組織コード
     */
    public String getRANK_02_SOSHIKI_CD() {
        return RANK_02_SOSHIKI_CD;
    }

    /**
     * ランク０２組織コード
     * @param RANK_02_SOSHIKI_CD ランク０２組織コード
     */
    public void setRANK_02_SOSHIKI_CD(String RANK_02_SOSHIKI_CD) {
        this.RANK_02_SOSHIKI_CD = RANK_02_SOSHIKI_CD == null ? null : RANK_02_SOSHIKI_CD.trim();
    }

    /**
     * ランク０３組織コード
     * @return RANK_03_SOSHIKI_CD ランク０３組織コード
     */
    public String getRANK_03_SOSHIKI_CD() {
        return RANK_03_SOSHIKI_CD;
    }

    /**
     * ランク０３組織コード
     * @param RANK_03_SOSHIKI_CD ランク０３組織コード
     */
    public void setRANK_03_SOSHIKI_CD(String RANK_03_SOSHIKI_CD) {
        this.RANK_03_SOSHIKI_CD = RANK_03_SOSHIKI_CD == null ? null : RANK_03_SOSHIKI_CD.trim();
    }

    /**
     * ランク０４組織コード
     * @return RANK_04_SOSHIKI_CD ランク０４組織コード
     */
    public String getRANK_04_SOSHIKI_CD() {
        return RANK_04_SOSHIKI_CD;
    }

    /**
     * ランク０４組織コード
     * @param RANK_04_SOSHIKI_CD ランク０４組織コード
     */
    public void setRANK_04_SOSHIKI_CD(String RANK_04_SOSHIKI_CD) {
        this.RANK_04_SOSHIKI_CD = RANK_04_SOSHIKI_CD == null ? null : RANK_04_SOSHIKI_CD.trim();
    }

    /**
     * ランク０５組織コード
     * @return RANK_05_SOSHIKI_CD ランク０５組織コード
     */
    public String getRANK_05_SOSHIKI_CD() {
        return RANK_05_SOSHIKI_CD;
    }

    /**
     * ランク０５組織コード
     * @param RANK_05_SOSHIKI_CD ランク０５組織コード
     */
    public void setRANK_05_SOSHIKI_CD(String RANK_05_SOSHIKI_CD) {
        this.RANK_05_SOSHIKI_CD = RANK_05_SOSHIKI_CD == null ? null : RANK_05_SOSHIKI_CD.trim();
    }

    /**
     * ランク０６組織コード
     * @return RANK_06_SOSHIKI_CD ランク０６組織コード
     */
    public String getRANK_06_SOSHIKI_CD() {
        return RANK_06_SOSHIKI_CD;
    }

    /**
     * ランク０６組織コード
     * @param RANK_06_SOSHIKI_CD ランク０６組織コード
     */
    public void setRANK_06_SOSHIKI_CD(String RANK_06_SOSHIKI_CD) {
        this.RANK_06_SOSHIKI_CD = RANK_06_SOSHIKI_CD == null ? null : RANK_06_SOSHIKI_CD.trim();
    }

    /**
     * ランク０７組織コード
     * @return RANK_07_SOSHIKI_CD ランク０７組織コード
     */
    public String getRANK_07_SOSHIKI_CD() {
        return RANK_07_SOSHIKI_CD;
    }

    /**
     * ランク０７組織コード
     * @param RANK_07_SOSHIKI_CD ランク０７組織コード
     */
    public void setRANK_07_SOSHIKI_CD(String RANK_07_SOSHIKI_CD) {
        this.RANK_07_SOSHIKI_CD = RANK_07_SOSHIKI_CD == null ? null : RANK_07_SOSHIKI_CD.trim();
    }

    /**
     * ランク０８組織コード
     * @return RANK_08_SOSHIKI_CD ランク０８組織コード
     */
    public String getRANK_08_SOSHIKI_CD() {
        return RANK_08_SOSHIKI_CD;
    }

    /**
     * ランク０８組織コード
     * @param RANK_08_SOSHIKI_CD ランク０８組織コード
     */
    public void setRANK_08_SOSHIKI_CD(String RANK_08_SOSHIKI_CD) {
        this.RANK_08_SOSHIKI_CD = RANK_08_SOSHIKI_CD == null ? null : RANK_08_SOSHIKI_CD.trim();
    }

    /**
     * ランク０９組織コード
     * @return RANK_09_SOSHIKI_CD ランク０９組織コード
     */
    public String getRANK_09_SOSHIKI_CD() {
        return RANK_09_SOSHIKI_CD;
    }

    /**
     * ランク０９組織コード
     * @param RANK_09_SOSHIKI_CD ランク０９組織コード
     */
    public void setRANK_09_SOSHIKI_CD(String RANK_09_SOSHIKI_CD) {
        this.RANK_09_SOSHIKI_CD = RANK_09_SOSHIKI_CD == null ? null : RANK_09_SOSHIKI_CD.trim();
    }

    /**
     * ランク１０組織コード
     * @return RANK_10_SOSHIKI_CD ランク１０組織コード
     */
    public String getRANK_10_SOSHIKI_CD() {
        return RANK_10_SOSHIKI_CD;
    }

    /**
     * ランク１０組織コード
     * @param RANK_10_SOSHIKI_CD ランク１０組織コード
     */
    public void setRANK_10_SOSHIKI_CD(String RANK_10_SOSHIKI_CD) {
        this.RANK_10_SOSHIKI_CD = RANK_10_SOSHIKI_CD == null ? null : RANK_10_SOSHIKI_CD.trim();
    }

    /**
     * ランク１１組織コード
     * @return RANK_11_SOSHIKI_CD ランク１１組織コード
     */
    public String getRANK_11_SOSHIKI_CD() {
        return RANK_11_SOSHIKI_CD;
    }

    /**
     * ランク１１組織コード
     * @param RANK_11_SOSHIKI_CD ランク１１組織コード
     */
    public void setRANK_11_SOSHIKI_CD(String RANK_11_SOSHIKI_CD) {
        this.RANK_11_SOSHIKI_CD = RANK_11_SOSHIKI_CD == null ? null : RANK_11_SOSHIKI_CD.trim();
    }

    /**
     * ランク１２組織コード
     * @return RANK_12_SOSHIKI_CD ランク１２組織コード
     */
    public String getRANK_12_SOSHIKI_CD() {
        return RANK_12_SOSHIKI_CD;
    }

    /**
     * ランク１２組織コード
     * @param RANK_12_SOSHIKI_CD ランク１２組織コード
     */
    public void setRANK_12_SOSHIKI_CD(String RANK_12_SOSHIKI_CD) {
        this.RANK_12_SOSHIKI_CD = RANK_12_SOSHIKI_CD == null ? null : RANK_12_SOSHIKI_CD.trim();
    }

    /**
     * ランク１３組織コード
     * @return RANK_13_SOSHIKI_CD ランク１３組織コード
     */
    public String getRANK_13_SOSHIKI_CD() {
        return RANK_13_SOSHIKI_CD;
    }

    /**
     * ランク１３組織コード
     * @param RANK_13_SOSHIKI_CD ランク１３組織コード
     */
    public void setRANK_13_SOSHIKI_CD(String RANK_13_SOSHIKI_CD) {
        this.RANK_13_SOSHIKI_CD = RANK_13_SOSHIKI_CD == null ? null : RANK_13_SOSHIKI_CD.trim();
    }

    /**
     * ランク１４組織コード
     * @return RANK_14_SOSHIKI_CD ランク１４組織コード
     */
    public String getRANK_14_SOSHIKI_CD() {
        return RANK_14_SOSHIKI_CD;
    }

    /**
     * ランク１４組織コード
     * @param RANK_14_SOSHIKI_CD ランク１４組織コード
     */
    public void setRANK_14_SOSHIKI_CD(String RANK_14_SOSHIKI_CD) {
        this.RANK_14_SOSHIKI_CD = RANK_14_SOSHIKI_CD == null ? null : RANK_14_SOSHIKI_CD.trim();
    }

    /**
     * ランク１５組織コード
     * @return RANK_15_SOSHIKI_CD ランク１５組織コード
     */
    public String getRANK_15_SOSHIKI_CD() {
        return RANK_15_SOSHIKI_CD;
    }

    /**
     * ランク１５組織コード
     * @param RANK_15_SOSHIKI_CD ランク１５組織コード
     */
    public void setRANK_15_SOSHIKI_CD(String RANK_15_SOSHIKI_CD) {
        this.RANK_15_SOSHIKI_CD = RANK_15_SOSHIKI_CD == null ? null : RANK_15_SOSHIKI_CD.trim();
    }

    /**
     * ランク１６組織コード
     * @return RANK_16_SOSHIKI_CD ランク１６組織コード
     */
    public String getRANK_16_SOSHIKI_CD() {
        return RANK_16_SOSHIKI_CD;
    }

    /**
     * ランク１６組織コード
     * @param RANK_16_SOSHIKI_CD ランク１６組織コード
     */
    public void setRANK_16_SOSHIKI_CD(String RANK_16_SOSHIKI_CD) {
        this.RANK_16_SOSHIKI_CD = RANK_16_SOSHIKI_CD == null ? null : RANK_16_SOSHIKI_CD.trim();
    }

    /**
     * ランク１７組織コード
     * @return RANK_17_SOSHIKI_CD ランク１７組織コード
     */
    public String getRANK_17_SOSHIKI_CD() {
        return RANK_17_SOSHIKI_CD;
    }

    /**
     * ランク１７組織コード
     * @param RANK_17_SOSHIKI_CD ランク１７組織コード
     */
    public void setRANK_17_SOSHIKI_CD(String RANK_17_SOSHIKI_CD) {
        this.RANK_17_SOSHIKI_CD = RANK_17_SOSHIKI_CD == null ? null : RANK_17_SOSHIKI_CD.trim();
    }

    /**
     * ランク１８組織コード
     * @return RANK_18_SOSHIKI_CD ランク１８組織コード
     */
    public String getRANK_18_SOSHIKI_CD() {
        return RANK_18_SOSHIKI_CD;
    }

    /**
     * ランク１８組織コード
     * @param RANK_18_SOSHIKI_CD ランク１８組織コード
     */
    public void setRANK_18_SOSHIKI_CD(String RANK_18_SOSHIKI_CD) {
        this.RANK_18_SOSHIKI_CD = RANK_18_SOSHIKI_CD == null ? null : RANK_18_SOSHIKI_CD.trim();
    }

    /**
     * ランク１９組織コード
     * @return RANK_19_SOSHIKI_CD ランク１９組織コード
     */
    public String getRANK_19_SOSHIKI_CD() {
        return RANK_19_SOSHIKI_CD;
    }

    /**
     * ランク１９組織コード
     * @param RANK_19_SOSHIKI_CD ランク１９組織コード
     */
    public void setRANK_19_SOSHIKI_CD(String RANK_19_SOSHIKI_CD) {
        this.RANK_19_SOSHIKI_CD = RANK_19_SOSHIKI_CD == null ? null : RANK_19_SOSHIKI_CD.trim();
    }

    /**
     * ランク２０組織コード
     * @return RANK_20_SOSHIKI_CD ランク２０組織コード
     */
    public String getRANK_20_SOSHIKI_CD() {
        return RANK_20_SOSHIKI_CD;
    }

    /**
     * ランク２０組織コード
     * @param RANK_20_SOSHIKI_CD ランク２０組織コード
     */
    public void setRANK_20_SOSHIKI_CD(String RANK_20_SOSHIKI_CD) {
        this.RANK_20_SOSHIKI_CD = RANK_20_SOSHIKI_CD == null ? null : RANK_20_SOSHIKI_CD.trim();
    }

    /**
     * ランク０１組織名称
     * @return RANK_01_SOSHIKI_NM ランク０１組織名称
     */
    public String getRANK_01_SOSHIKI_NM() {
        return RANK_01_SOSHIKI_NM;
    }

    /**
     * ランク０１組織名称
     * @param RANK_01_SOSHIKI_NM ランク０１組織名称
     */
    public void setRANK_01_SOSHIKI_NM(String RANK_01_SOSHIKI_NM) {
        this.RANK_01_SOSHIKI_NM = RANK_01_SOSHIKI_NM == null ? null : RANK_01_SOSHIKI_NM.trim();
    }

    /**
     * ランク０２組織名称
     * @return RANK_02_SOSHIKI_NM ランク０２組織名称
     */
    public String getRANK_02_SOSHIKI_NM() {
        return RANK_02_SOSHIKI_NM;
    }

    /**
     * ランク０２組織名称
     * @param RANK_02_SOSHIKI_NM ランク０２組織名称
     */
    public void setRANK_02_SOSHIKI_NM(String RANK_02_SOSHIKI_NM) {
        this.RANK_02_SOSHIKI_NM = RANK_02_SOSHIKI_NM == null ? null : RANK_02_SOSHIKI_NM.trim();
    }

    /**
     * ランク０３組織名称
     * @return RANK_03_SOSHIKI_NM ランク０３組織名称
     */
    public String getRANK_03_SOSHIKI_NM() {
        return RANK_03_SOSHIKI_NM;
    }

    /**
     * ランク０３組織名称
     * @param RANK_03_SOSHIKI_NM ランク０３組織名称
     */
    public void setRANK_03_SOSHIKI_NM(String RANK_03_SOSHIKI_NM) {
        this.RANK_03_SOSHIKI_NM = RANK_03_SOSHIKI_NM == null ? null : RANK_03_SOSHIKI_NM.trim();
    }

    /**
     * ランク０４組織名称
     * @return RANK_04_SOSHIKI_NM ランク０４組織名称
     */
    public String getRANK_04_SOSHIKI_NM() {
        return RANK_04_SOSHIKI_NM;
    }

    /**
     * ランク０４組織名称
     * @param RANK_04_SOSHIKI_NM ランク０４組織名称
     */
    public void setRANK_04_SOSHIKI_NM(String RANK_04_SOSHIKI_NM) {
        this.RANK_04_SOSHIKI_NM = RANK_04_SOSHIKI_NM == null ? null : RANK_04_SOSHIKI_NM.trim();
    }

    /**
     * ランク０５組織名称
     * @return RANK_05_SOSHIKI_NM ランク０５組織名称
     */
    public String getRANK_05_SOSHIKI_NM() {
        return RANK_05_SOSHIKI_NM;
    }

    /**
     * ランク０５組織名称
     * @param RANK_05_SOSHIKI_NM ランク０５組織名称
     */
    public void setRANK_05_SOSHIKI_NM(String RANK_05_SOSHIKI_NM) {
        this.RANK_05_SOSHIKI_NM = RANK_05_SOSHIKI_NM == null ? null : RANK_05_SOSHIKI_NM.trim();
    }

    /**
     * ランク０６組織名称
     * @return RANK_06_SOSHIKI_NM ランク０６組織名称
     */
    public String getRANK_06_SOSHIKI_NM() {
        return RANK_06_SOSHIKI_NM;
    }

    /**
     * ランク０６組織名称
     * @param RANK_06_SOSHIKI_NM ランク０６組織名称
     */
    public void setRANK_06_SOSHIKI_NM(String RANK_06_SOSHIKI_NM) {
        this.RANK_06_SOSHIKI_NM = RANK_06_SOSHIKI_NM == null ? null : RANK_06_SOSHIKI_NM.trim();
    }

    /**
     * ランク０７組織名称
     * @return RANK_07_SOSHIKI_NM ランク０７組織名称
     */
    public String getRANK_07_SOSHIKI_NM() {
        return RANK_07_SOSHIKI_NM;
    }

    /**
     * ランク０７組織名称
     * @param RANK_07_SOSHIKI_NM ランク０７組織名称
     */
    public void setRANK_07_SOSHIKI_NM(String RANK_07_SOSHIKI_NM) {
        this.RANK_07_SOSHIKI_NM = RANK_07_SOSHIKI_NM == null ? null : RANK_07_SOSHIKI_NM.trim();
    }

    /**
     * ランク０８組織名称
     * @return RANK_08_SOSHIKI_NM ランク０８組織名称
     */
    public String getRANK_08_SOSHIKI_NM() {
        return RANK_08_SOSHIKI_NM;
    }

    /**
     * ランク０８組織名称
     * @param RANK_08_SOSHIKI_NM ランク０８組織名称
     */
    public void setRANK_08_SOSHIKI_NM(String RANK_08_SOSHIKI_NM) {
        this.RANK_08_SOSHIKI_NM = RANK_08_SOSHIKI_NM == null ? null : RANK_08_SOSHIKI_NM.trim();
    }

    /**
     * ランク０９組織名称
     * @return RANK_09_SOSHIKI_NM ランク０９組織名称
     */
    public String getRANK_09_SOSHIKI_NM() {
        return RANK_09_SOSHIKI_NM;
    }

    /**
     * ランク０９組織名称
     * @param RANK_09_SOSHIKI_NM ランク０９組織名称
     */
    public void setRANK_09_SOSHIKI_NM(String RANK_09_SOSHIKI_NM) {
        this.RANK_09_SOSHIKI_NM = RANK_09_SOSHIKI_NM == null ? null : RANK_09_SOSHIKI_NM.trim();
    }

    /**
     * ランク１０組織名称
     * @return RANK_10_SOSHIKI_NM ランク１０組織名称
     */
    public String getRANK_10_SOSHIKI_NM() {
        return RANK_10_SOSHIKI_NM;
    }

    /**
     * ランク１０組織名称
     * @param RANK_10_SOSHIKI_NM ランク１０組織名称
     */
    public void setRANK_10_SOSHIKI_NM(String RANK_10_SOSHIKI_NM) {
        this.RANK_10_SOSHIKI_NM = RANK_10_SOSHIKI_NM == null ? null : RANK_10_SOSHIKI_NM.trim();
    }

    /**
     * ランク１１組織名称
     * @return RANK_11_SOSHIKI_NM ランク１１組織名称
     */
    public String getRANK_11_SOSHIKI_NM() {
        return RANK_11_SOSHIKI_NM;
    }

    /**
     * ランク１１組織名称
     * @param RANK_11_SOSHIKI_NM ランク１１組織名称
     */
    public void setRANK_11_SOSHIKI_NM(String RANK_11_SOSHIKI_NM) {
        this.RANK_11_SOSHIKI_NM = RANK_11_SOSHIKI_NM == null ? null : RANK_11_SOSHIKI_NM.trim();
    }

    /**
     * ランク１２組織名称
     * @return RANK_12_SOSHIKI_NM ランク１２組織名称
     */
    public String getRANK_12_SOSHIKI_NM() {
        return RANK_12_SOSHIKI_NM;
    }

    /**
     * ランク１２組織名称
     * @param RANK_12_SOSHIKI_NM ランク１２組織名称
     */
    public void setRANK_12_SOSHIKI_NM(String RANK_12_SOSHIKI_NM) {
        this.RANK_12_SOSHIKI_NM = RANK_12_SOSHIKI_NM == null ? null : RANK_12_SOSHIKI_NM.trim();
    }

    /**
     * ランク１３組織名称
     * @return RANK_13_SOSHIKI_NM ランク１３組織名称
     */
    public String getRANK_13_SOSHIKI_NM() {
        return RANK_13_SOSHIKI_NM;
    }

    /**
     * ランク１３組織名称
     * @param RANK_13_SOSHIKI_NM ランク１３組織名称
     */
    public void setRANK_13_SOSHIKI_NM(String RANK_13_SOSHIKI_NM) {
        this.RANK_13_SOSHIKI_NM = RANK_13_SOSHIKI_NM == null ? null : RANK_13_SOSHIKI_NM.trim();
    }

    /**
     * ランク１４組織名称
     * @return RANK_14_SOSHIKI_NM ランク１４組織名称
     */
    public String getRANK_14_SOSHIKI_NM() {
        return RANK_14_SOSHIKI_NM;
    }

    /**
     * ランク１４組織名称
     * @param RANK_14_SOSHIKI_NM ランク１４組織名称
     */
    public void setRANK_14_SOSHIKI_NM(String RANK_14_SOSHIKI_NM) {
        this.RANK_14_SOSHIKI_NM = RANK_14_SOSHIKI_NM == null ? null : RANK_14_SOSHIKI_NM.trim();
    }

    /**
     * ランク１５組織名称
     * @return RANK_15_SOSHIKI_NM ランク１５組織名称
     */
    public String getRANK_15_SOSHIKI_NM() {
        return RANK_15_SOSHIKI_NM;
    }

    /**
     * ランク１５組織名称
     * @param RANK_15_SOSHIKI_NM ランク１５組織名称
     */
    public void setRANK_15_SOSHIKI_NM(String RANK_15_SOSHIKI_NM) {
        this.RANK_15_SOSHIKI_NM = RANK_15_SOSHIKI_NM == null ? null : RANK_15_SOSHIKI_NM.trim();
    }

    /**
     * ランク１６組織名称
     * @return RANK_16_SOSHIKI_NM ランク１６組織名称
     */
    public String getRANK_16_SOSHIKI_NM() {
        return RANK_16_SOSHIKI_NM;
    }

    /**
     * ランク１６組織名称
     * @param RANK_16_SOSHIKI_NM ランク１６組織名称
     */
    public void setRANK_16_SOSHIKI_NM(String RANK_16_SOSHIKI_NM) {
        this.RANK_16_SOSHIKI_NM = RANK_16_SOSHIKI_NM == null ? null : RANK_16_SOSHIKI_NM.trim();
    }

    /**
     * ランク１７組織名称
     * @return RANK_17_SOSHIKI_NM ランク１７組織名称
     */
    public String getRANK_17_SOSHIKI_NM() {
        return RANK_17_SOSHIKI_NM;
    }

    /**
     * ランク１７組織名称
     * @param RANK_17_SOSHIKI_NM ランク１７組織名称
     */
    public void setRANK_17_SOSHIKI_NM(String RANK_17_SOSHIKI_NM) {
        this.RANK_17_SOSHIKI_NM = RANK_17_SOSHIKI_NM == null ? null : RANK_17_SOSHIKI_NM.trim();
    }

    /**
     * ランク１８組織名称
     * @return RANK_18_SOSHIKI_NM ランク１８組織名称
     */
    public String getRANK_18_SOSHIKI_NM() {
        return RANK_18_SOSHIKI_NM;
    }

    /**
     * ランク１８組織名称
     * @param RANK_18_SOSHIKI_NM ランク１８組織名称
     */
    public void setRANK_18_SOSHIKI_NM(String RANK_18_SOSHIKI_NM) {
        this.RANK_18_SOSHIKI_NM = RANK_18_SOSHIKI_NM == null ? null : RANK_18_SOSHIKI_NM.trim();
    }

    /**
     * ランク１９組織名称
     * @return RANK_19_SOSHIKI_NM ランク１９組織名称
     */
    public String getRANK_19_SOSHIKI_NM() {
        return RANK_19_SOSHIKI_NM;
    }

    /**
     * ランク１９組織名称
     * @param RANK_19_SOSHIKI_NM ランク１９組織名称
     */
    public void setRANK_19_SOSHIKI_NM(String RANK_19_SOSHIKI_NM) {
        this.RANK_19_SOSHIKI_NM = RANK_19_SOSHIKI_NM == null ? null : RANK_19_SOSHIKI_NM.trim();
    }

    /**
     * ランク２０組織名称
     * @return RANK_20_SOSHIKI_NM ランク２０組織名称
     */
    public String getRANK_20_SOSHIKI_NM() {
        return RANK_20_SOSHIKI_NM;
    }

    /**
     * ランク２０組織名称
     * @param RANK_20_SOSHIKI_NM ランク２０組織名称
     */
    public void setRANK_20_SOSHIKI_NM(String RANK_20_SOSHIKI_NM) {
        this.RANK_20_SOSHIKI_NM = RANK_20_SOSHIKI_NM == null ? null : RANK_20_SOSHIKI_NM.trim();
    }

    /**
     * 予備項目01
     * @return YOBI_KOMOKU_01 予備項目01
     */
    public String getYOBI_KOMOKU_01() {
        return YOBI_KOMOKU_01;
    }

    /**
     * 予備項目01
     * @param YOBI_KOMOKU_01 予備項目01
     */
    public void setYOBI_KOMOKU_01(String YOBI_KOMOKU_01) {
        this.YOBI_KOMOKU_01 = YOBI_KOMOKU_01 == null ? null : YOBI_KOMOKU_01.trim();
    }

    /**
     * 予備項目02
     * @return YOBI_KOMOKU_02 予備項目02
     */
    public String getYOBI_KOMOKU_02() {
        return YOBI_KOMOKU_02;
    }

    /**
     * 予備項目02
     * @param YOBI_KOMOKU_02 予備項目02
     */
    public void setYOBI_KOMOKU_02(String YOBI_KOMOKU_02) {
        this.YOBI_KOMOKU_02 = YOBI_KOMOKU_02 == null ? null : YOBI_KOMOKU_02.trim();
    }

    /**
     * 予備項目03
     * @return YOBI_KOMOKU_03 予備項目03
     */
    public String getYOBI_KOMOKU_03() {
        return YOBI_KOMOKU_03;
    }

    /**
     * 予備項目03
     * @param YOBI_KOMOKU_03 予備項目03
     */
    public void setYOBI_KOMOKU_03(String YOBI_KOMOKU_03) {
        this.YOBI_KOMOKU_03 = YOBI_KOMOKU_03 == null ? null : YOBI_KOMOKU_03.trim();
    }

    /**
     * 予備項目04
     * @return YOBI_KOMOKU_04 予備項目04
     */
    public String getYOBI_KOMOKU_04() {
        return YOBI_KOMOKU_04;
    }

    /**
     * 予備項目04
     * @param YOBI_KOMOKU_04 予備項目04
     */
    public void setYOBI_KOMOKU_04(String YOBI_KOMOKU_04) {
        this.YOBI_KOMOKU_04 = YOBI_KOMOKU_04 == null ? null : YOBI_KOMOKU_04.trim();
    }

    /**
     * 予備項目05
     * @return YOBI_KOMOKU_05 予備項目05
     */
    public String getYOBI_KOMOKU_05() {
        return YOBI_KOMOKU_05;
    }

    /**
     * 予備項目05
     * @param YOBI_KOMOKU_05 予備項目05
     */
    public void setYOBI_KOMOKU_05(String YOBI_KOMOKU_05) {
        this.YOBI_KOMOKU_05 = YOBI_KOMOKU_05 == null ? null : YOBI_KOMOKU_05.trim();
    }

    /**
     * 予備項目06
     * @return YOBI_KOMOKU_06 予備項目06
     */
    public String getYOBI_KOMOKU_06() {
        return YOBI_KOMOKU_06;
    }

    /**
     * 予備項目06
     * @param YOBI_KOMOKU_06 予備項目06
     */
    public void setYOBI_KOMOKU_06(String YOBI_KOMOKU_06) {
        this.YOBI_KOMOKU_06 = YOBI_KOMOKU_06 == null ? null : YOBI_KOMOKU_06.trim();
    }

    /**
     * 予備項目07
     * @return YOBI_KOMOKU_07 予備項目07
     */
    public String getYOBI_KOMOKU_07() {
        return YOBI_KOMOKU_07;
    }

    /**
     * 予備項目07
     * @param YOBI_KOMOKU_07 予備項目07
     */
    public void setYOBI_KOMOKU_07(String YOBI_KOMOKU_07) {
        this.YOBI_KOMOKU_07 = YOBI_KOMOKU_07 == null ? null : YOBI_KOMOKU_07.trim();
    }

    /**
     * 予備項目08
     * @return YOBI_KOMOKU_08 予備項目08
     */
    public String getYOBI_KOMOKU_08() {
        return YOBI_KOMOKU_08;
    }

    /**
     * 予備項目08
     * @param YOBI_KOMOKU_08 予備項目08
     */
    public void setYOBI_KOMOKU_08(String YOBI_KOMOKU_08) {
        this.YOBI_KOMOKU_08 = YOBI_KOMOKU_08 == null ? null : YOBI_KOMOKU_08.trim();
    }

    /**
     * 予備項目09
     * @return YOBI_KOMOKU_09 予備項目09
     */
    public String getYOBI_KOMOKU_09() {
        return YOBI_KOMOKU_09;
    }

    /**
     * 予備項目09
     * @param YOBI_KOMOKU_09 予備項目09
     */
    public void setYOBI_KOMOKU_09(String YOBI_KOMOKU_09) {
        this.YOBI_KOMOKU_09 = YOBI_KOMOKU_09 == null ? null : YOBI_KOMOKU_09.trim();
    }

    /**
     * 予備項目10
     * @return YOBI_KOMOKU_10 予備項目10
     */
    public String getYOBI_KOMOKU_10() {
        return YOBI_KOMOKU_10;
    }

    /**
     * 予備項目10
     * @param YOBI_KOMOKU_10 予備項目10
     */
    public void setYOBI_KOMOKU_10(String YOBI_KOMOKU_10) {
        this.YOBI_KOMOKU_10 = YOBI_KOMOKU_10 == null ? null : YOBI_KOMOKU_10.trim();
    }

    /**
     * 登録タイムスタンプ
     * @return REGST_TMSTMP 登録タイムスタンプ
     */
    public Date getREGST_TMSTMP() {
        return REGST_TMSTMP;
    }

    /**
     * 登録タイムスタンプ
     * @param REGST_TMSTMP 登録タイムスタンプ
     */
    public void setREGST_TMSTMP(Date REGST_TMSTMP) {
        this.REGST_TMSTMP = REGST_TMSTMP;
    }

    /**
     * 登録者会社コード
     * @return REGSTR_CO_CD 登録者会社コード
     */
    public String getREGSTR_CO_CD() {
        return REGSTR_CO_CD;
    }

    /**
     * 登録者会社コード
     * @param REGSTR_CO_CD 登録者会社コード
     */
    public void setREGSTR_CO_CD(String REGSTR_CO_CD) {
        this.REGSTR_CO_CD = REGSTR_CO_CD == null ? null : REGSTR_CO_CD.trim();
    }

    /**
     * 登録者組織コード
     * @return REGSTR_SOSHIKI_CD 登録者組織コード
     */
    public String getREGSTR_SOSHIKI_CD() {
        return REGSTR_SOSHIKI_CD;
    }

    /**
     * 登録者組織コード
     * @param REGSTR_SOSHIKI_CD 登録者組織コード
     */
    public void setREGSTR_SOSHIKI_CD(String REGSTR_SOSHIKI_CD) {
        this.REGSTR_SOSHIKI_CD = REGSTR_SOSHIKI_CD == null ? null : REGSTR_SOSHIKI_CD.trim();
    }

    /**
     * 登録者社員番号
     * @return REGSTR_EMP_NO 登録者社員番号
     */
    public String getREGSTR_EMP_NO() {
        return REGSTR_EMP_NO;
    }

    /**
     * 登録者社員番号
     * @param REGSTR_EMP_NO 登録者社員番号
     */
    public void setREGSTR_EMP_NO(String REGSTR_EMP_NO) {
        this.REGSTR_EMP_NO = REGSTR_EMP_NO == null ? null : REGSTR_EMP_NO.trim();
    }

    /**
     * 登録画面ＩＤ
     * @return REGST_GAMEN_ID 登録画面ＩＤ
     */
    public String getREGST_GAMEN_ID() {
        return REGST_GAMEN_ID;
    }

    /**
     * 登録画面ＩＤ
     * @param REGST_GAMEN_ID 登録画面ＩＤ
     */
    public void setREGST_GAMEN_ID(String REGST_GAMEN_ID) {
        this.REGST_GAMEN_ID = REGST_GAMEN_ID == null ? null : REGST_GAMEN_ID.trim();
    }

    /**
     * 登録プログラムＩＤ
     * @return REGST_PGM_ID 登録プログラムＩＤ
     */
    public String getREGST_PGM_ID() {
        return REGST_PGM_ID;
    }

    /**
     * 登録プログラムＩＤ
     * @param REGST_PGM_ID 登録プログラムＩＤ
     */
    public void setREGST_PGM_ID(String REGST_PGM_ID) {
        this.REGST_PGM_ID = REGST_PGM_ID == null ? null : REGST_PGM_ID.trim();
    }

    /**
     * 更新タイムスタンプ
     * @return UPD_TMSTMP 更新タイムスタンプ
     */
    public Date getUPD_TMSTMP() {
        return UPD_TMSTMP;
    }

    /**
     * 更新タイムスタンプ
     * @param UPD_TMSTMP 更新タイムスタンプ
     */
    public void setUPD_TMSTMP(Date UPD_TMSTMP) {
        this.UPD_TMSTMP = UPD_TMSTMP;
    }

    /**
     * 更新者会社コード
     * @return UPDTR_CO_CD 更新者会社コード
     */
    public String getUPDTR_CO_CD() {
        return UPDTR_CO_CD;
    }

    /**
     * 更新者会社コード
     * @param UPDTR_CO_CD 更新者会社コード
     */
    public void setUPDTR_CO_CD(String UPDTR_CO_CD) {
        this.UPDTR_CO_CD = UPDTR_CO_CD == null ? null : UPDTR_CO_CD.trim();
    }

    /**
     * 更新者組織コード
     * @return UPDTR_SOSHIKI_CD 更新者組織コード
     */
    public String getUPDTR_SOSHIKI_CD() {
        return UPDTR_SOSHIKI_CD;
    }

    /**
     * 更新者組織コード
     * @param UPDTR_SOSHIKI_CD 更新者組織コード
     */
    public void setUPDTR_SOSHIKI_CD(String UPDTR_SOSHIKI_CD) {
        this.UPDTR_SOSHIKI_CD = UPDTR_SOSHIKI_CD == null ? null : UPDTR_SOSHIKI_CD.trim();
    }

    /**
     * 更新者社員番号
     * @return UPDTR_EMP_NO 更新者社員番号
     */
    public String getUPDTR_EMP_NO() {
        return UPDTR_EMP_NO;
    }

    /**
     * 更新者社員番号
     * @param UPDTR_EMP_NO 更新者社員番号
     */
    public void setUPDTR_EMP_NO(String UPDTR_EMP_NO) {
        this.UPDTR_EMP_NO = UPDTR_EMP_NO == null ? null : UPDTR_EMP_NO.trim();
    }

    /**
     * 更新画面ＩＤ
     * @return UPD_GAMEN_ID 更新画面ＩＤ
     */
    public String getUPD_GAMEN_ID() {
        return UPD_GAMEN_ID;
    }

    /**
     * 更新画面ＩＤ
     * @param UPD_GAMEN_ID 更新画面ＩＤ
     */
    public void setUPD_GAMEN_ID(String UPD_GAMEN_ID) {
        this.UPD_GAMEN_ID = UPD_GAMEN_ID == null ? null : UPD_GAMEN_ID.trim();
    }

    /**
     * 更新プログラムＩＤ
     * @return UPD_PGM_ID 更新プログラムＩＤ
     */
    public String getUPD_PGM_ID() {
        return UPD_PGM_ID;
    }

    /**
     * 更新プログラムＩＤ
     * @param UPD_PGM_ID 更新プログラムＩＤ
     */
    public void setUPD_PGM_ID(String UPD_PGM_ID) {
        this.UPD_PGM_ID = UPD_PGM_ID == null ? null : UPD_PGM_ID.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }
}