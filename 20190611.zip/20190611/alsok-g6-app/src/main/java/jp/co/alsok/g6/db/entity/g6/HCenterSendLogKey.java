package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;

public class HCenterSendLogKey implements Serializable {
    /**
     * LN_制御装置論理番号
     */
    private String LN_CTL_DEV;

    /**
     * 世代管理番号
     */
    private String GEN_MNG_NUM;

    /**
     * 表示順
     */
    private String ORDER_NUM;

    /**
     * H_CENTER_SEND_LOG
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_制御装置論理番号
     * @return LN_CTL_DEV LN_制御装置論理番号
     */
    public String getLN_CTL_DEV() {
        return LN_CTL_DEV;
    }

    /**
     * LN_制御装置論理番号
     * @param LN_CTL_DEV LN_制御装置論理番号
     */
    public void setLN_CTL_DEV(String LN_CTL_DEV) {
        this.LN_CTL_DEV = LN_CTL_DEV == null ? null : LN_CTL_DEV.trim();
    }

    /**
     * 世代管理番号
     * @return GEN_MNG_NUM 世代管理番号
     */
    public String getGEN_MNG_NUM() {
        return GEN_MNG_NUM;
    }

    /**
     * 世代管理番号
     * @param GEN_MNG_NUM 世代管理番号
     */
    public void setGEN_MNG_NUM(String GEN_MNG_NUM) {
        this.GEN_MNG_NUM = GEN_MNG_NUM == null ? null : GEN_MNG_NUM.trim();
    }

    /**
     * 表示順
     * @return ORDER_NUM 表示順
     */
    public String getORDER_NUM() {
        return ORDER_NUM;
    }

    /**
     * 表示順
     * @param ORDER_NUM 表示順
     */
    public void setORDER_NUM(String ORDER_NUM) {
        this.ORDER_NUM = ORDER_NUM == null ? null : ORDER_NUM.trim();
    }
}