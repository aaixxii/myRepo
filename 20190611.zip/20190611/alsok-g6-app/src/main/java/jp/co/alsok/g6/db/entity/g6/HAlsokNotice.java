package jp.co.alsok.g6.db.entity.g6;

import java.io.Serializable;
import java.util.Date;

public class HAlsokNotice implements Serializable {
    /**
     * LN_ALSOKお知らせ履歴論理番号
     */
    private String LN_H_ALSOK_NOTICE;

    /**
     * お知らせ登録日時
     */
    private Date RGST_TS;

    /**
     * タイトル
     */
    private String TITLE;

    /**
     * 送信予定日時
     */
    private Date SEND_TS;

    /**
     * 送信タイプ
     */
    private String SEND_TYPE;

    /**
     * 送信方法
     */
    private String SEND_METHOD;

    /**
     * 送信対象サービス種別
     */
    private String FLG_ML_SEND_SVC_KIND;

    /**
     * LN_配信トリガ論理番号
     */
    private String LN_ML_TRIG;

    /**
     * 登録者ID
     */
    private String INSERT_ID;

    /**
     * 登録者名
     */
    private String INSERT_NM;

    /**
     * 登録日時
     */
    private Date INSERT_TS;

    /**
     * 更新者ID
     */
    private String UPDATE_ID;

    /**
     * 更新者名
     */
    private String UPDATE_NM;

    /**
     * 更新日時
     */
    private Date UPDATE_TS;

    /**
     * 本文
     */
    private String BODY;

    /**
     * H_ALSOK_NOTICE
     */
    private static final long serialVersionUID = 1L;

    /**
     * LN_ALSOKお知らせ履歴論理番号
     * @return LN_H_ALSOK_NOTICE LN_ALSOKお知らせ履歴論理番号
     */
    public String getLN_H_ALSOK_NOTICE() {
        return LN_H_ALSOK_NOTICE;
    }

    /**
     * LN_ALSOKお知らせ履歴論理番号
     * @param LN_H_ALSOK_NOTICE LN_ALSOKお知らせ履歴論理番号
     */
    public void setLN_H_ALSOK_NOTICE(String LN_H_ALSOK_NOTICE) {
        this.LN_H_ALSOK_NOTICE = LN_H_ALSOK_NOTICE == null ? null : LN_H_ALSOK_NOTICE.trim();
    }

    /**
     * お知らせ登録日時
     * @return RGST_TS お知らせ登録日時
     */
    public Date getRGST_TS() {
        return RGST_TS;
    }

    /**
     * お知らせ登録日時
     * @param RGST_TS お知らせ登録日時
     */
    public void setRGST_TS(Date RGST_TS) {
        this.RGST_TS = RGST_TS;
    }

    /**
     * タイトル
     * @return TITLE タイトル
     */
    public String getTITLE() {
        return TITLE;
    }

    /**
     * タイトル
     * @param TITLE タイトル
     */
    public void setTITLE(String TITLE) {
        this.TITLE = TITLE == null ? null : TITLE.trim();
    }

    /**
     * 送信予定日時
     * @return SEND_TS 送信予定日時
     */
    public Date getSEND_TS() {
        return SEND_TS;
    }

    /**
     * 送信予定日時
     * @param SEND_TS 送信予定日時
     */
    public void setSEND_TS(Date SEND_TS) {
        this.SEND_TS = SEND_TS;
    }

    /**
     * 送信タイプ
     * @return SEND_TYPE 送信タイプ
     */
    public String getSEND_TYPE() {
        return SEND_TYPE;
    }

    /**
     * 送信タイプ
     * @param SEND_TYPE 送信タイプ
     */
    public void setSEND_TYPE(String SEND_TYPE) {
        this.SEND_TYPE = SEND_TYPE == null ? null : SEND_TYPE.trim();
    }

    /**
     * 送信方法
     * @return SEND_METHOD 送信方法
     */
    public String getSEND_METHOD() {
        return SEND_METHOD;
    }

    /**
     * 送信方法
     * @param SEND_METHOD 送信方法
     */
    public void setSEND_METHOD(String SEND_METHOD) {
        this.SEND_METHOD = SEND_METHOD == null ? null : SEND_METHOD.trim();
    }

    /**
     * 送信対象サービス種別
     * @return FLG_ML_SEND_SVC_KIND 送信対象サービス種別
     */
    public String getFLG_ML_SEND_SVC_KIND() {
        return FLG_ML_SEND_SVC_KIND;
    }

    /**
     * 送信対象サービス種別
     * @param FLG_ML_SEND_SVC_KIND 送信対象サービス種別
     */
    public void setFLG_ML_SEND_SVC_KIND(String FLG_ML_SEND_SVC_KIND) {
        this.FLG_ML_SEND_SVC_KIND = FLG_ML_SEND_SVC_KIND == null ? null : FLG_ML_SEND_SVC_KIND.trim();
    }

    /**
     * LN_配信トリガ論理番号
     * @return LN_ML_TRIG LN_配信トリガ論理番号
     */
    public String getLN_ML_TRIG() {
        return LN_ML_TRIG;
    }

    /**
     * LN_配信トリガ論理番号
     * @param LN_ML_TRIG LN_配信トリガ論理番号
     */
    public void setLN_ML_TRIG(String LN_ML_TRIG) {
        this.LN_ML_TRIG = LN_ML_TRIG == null ? null : LN_ML_TRIG.trim();
    }

    /**
     * 登録者ID
     * @return INSERT_ID 登録者ID
     */
    public String getINSERT_ID() {
        return INSERT_ID;
    }

    /**
     * 登録者ID
     * @param INSERT_ID 登録者ID
     */
    public void setINSERT_ID(String INSERT_ID) {
        this.INSERT_ID = INSERT_ID == null ? null : INSERT_ID.trim();
    }

    /**
     * 登録者名
     * @return INSERT_NM 登録者名
     */
    public String getINSERT_NM() {
        return INSERT_NM;
    }

    /**
     * 登録者名
     * @param INSERT_NM 登録者名
     */
    public void setINSERT_NM(String INSERT_NM) {
        this.INSERT_NM = INSERT_NM == null ? null : INSERT_NM.trim();
    }

    /**
     * 登録日時
     * @return INSERT_TS 登録日時
     */
    public Date getINSERT_TS() {
        return INSERT_TS;
    }

    /**
     * 登録日時
     * @param INSERT_TS 登録日時
     */
    public void setINSERT_TS(Date INSERT_TS) {
        this.INSERT_TS = INSERT_TS;
    }

    /**
     * 更新者ID
     * @return UPDATE_ID 更新者ID
     */
    public String getUPDATE_ID() {
        return UPDATE_ID;
    }

    /**
     * 更新者ID
     * @param UPDATE_ID 更新者ID
     */
    public void setUPDATE_ID(String UPDATE_ID) {
        this.UPDATE_ID = UPDATE_ID == null ? null : UPDATE_ID.trim();
    }

    /**
     * 更新者名
     * @return UPDATE_NM 更新者名
     */
    public String getUPDATE_NM() {
        return UPDATE_NM;
    }

    /**
     * 更新者名
     * @param UPDATE_NM 更新者名
     */
    public void setUPDATE_NM(String UPDATE_NM) {
        this.UPDATE_NM = UPDATE_NM == null ? null : UPDATE_NM.trim();
    }

    /**
     * 更新日時
     * @return UPDATE_TS 更新日時
     */
    public Date getUPDATE_TS() {
        return UPDATE_TS;
    }

    /**
     * 更新日時
     * @param UPDATE_TS 更新日時
     */
    public void setUPDATE_TS(Date UPDATE_TS) {
        this.UPDATE_TS = UPDATE_TS;
    }

    /**
     * 本文
     * @return BODY 本文
     */
    public String getBODY() {
        return BODY;
    }

    /**
     * 本文
     * @param BODY 本文
     */
    public void setBODY(String BODY) {
        this.BODY = BODY == null ? null : BODY.trim();
    }
}